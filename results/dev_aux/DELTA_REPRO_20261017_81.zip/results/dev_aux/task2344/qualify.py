"""Independent new-family/source/prior-orbit and actual semantic-prefix audit."""

from pathlib import Path

from collections import Counter

import json,hashlib,time

from generic_chess.rules.compiler import compile_ruleset_for_execution

from generic_chess.rules.serialization import deserialize_ruleset

from generic_chess.session.session import GameSession

from generic_chess.session.serialization import deserialize_game_record

from generic_chess.session.result import SessionStatus

from scripts.generic_proof_rnb_bridge import actor_state,uci,orbit

from results.dev_aux.task2251.study import Guide

from results.dev_aux.task2153.stop_evidence import EvidenceStopReader

OUT=Path('results/dev_aux/task2344')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def key(x):return ''.join(x[:-1])+str(x[-1])

def run():

 t=time.perf_counter();stop=EvidenceStopReader(Path.cwd());read=lambda p:json.loads(Path(p).read_text());f=Path('results/dev_aux/task2341');plan=read(f/'plan.json');data=read(f/'inputs.json');rows=data['roots'];assert len(rows)==16 and data['price_queries']==0

 for n,h in plan['pins'].items():assert sha(n)==h

 prior={};old=set()

 for task in(2251,2257,2258,2270,2330):

  rr=read(f'results/dev_aux/task{task}/inputs.json')['roots'];gg={r['group']for r in rr};prior[task]=len(gg);old.update(gg)

 assert len({r['group']for r in rows})==16 and not old.intersection(r['group']for r in rows)

 needed={key(r['board'])for r in rows};reference={}
 for i,line in enumerate(Path('results/dev_aux/task2249/labels.jsonl').open(encoding='utf-8')):
  if i%1024==0:stop()
  rr=json.loads(line)
  if key(rr['board'])in needed:reference[key(rr['board'])]=rr
 assert len(reference)==16;checked=[]

 for r in rows:

  stop();c=compile_ruleset_for_execution(deserialize_ruleset(Path(r['rules']).read_text()));s=GameSession.replay(c,deserialize_game_record(json.dumps(r['record'])));raw=actor_state(s.state);assert list(raw)==r['board']and min(key(x)for x in orbit(raw))==r['group'];assert hashlib.sha256(('RN81-generic-policy-learning-reserve:'+r['group']).encode()).hexdigest()==r['order_sha'];assert len(s.to_record().actions)==1 and s.result.status is SessionStatus.ONGOING;assert hashlib.sha256(repr(s.state).encode()).hexdigest()==r['state_sha']

  ref=reference[key(raw)];assert ref['label']==r['target_label']and(ref['label']=='DRAW'or ref['rank']>=5);assert ref['inventory']in('KKRnn','KKrNN');assert len(s.legal_actions())>=2 and {uci(a)for a in s.legal_actions()}=={e['action']for e in ref['actions']}

  utilities=[-e['child_value']for e in ref['actions']];assert len(set(utilities))>=2 and utilities==r['target_action_utilities']

  parent=GameSession(c);action=s.to_record().actions[0];assert actor_state(parent.state)==tuple(r['parent_board']);assert sum(x is not None for x in parent.state.position.board)==sum(x is not None for x in s.state.position.board)==5

  for a in s.legal_actions():

   child=GameSession.replay(c,s.to_record());child.submit(a);assert child.result.status is SessionStatus.ONGOING

  checked.append(dict(family=r['family'],group=r['group'],label=ref['label'],rank=ref['rank'],legal_actions=len(s.legal_actions()),actual_prefix_plies=1,utilities=utilities))

 assert Counter(r['label']for r in checked)=={'WIN':8,'DRAW':8};assert [r['order_sha']for r in rows]==sorted(r['order_sha']for r in rows)

 r=dict(status='PASS_ALL16_ACTUAL_PREFIXES_AND_PRIOR_ORBIT_EXCLUSION',families=16,prior_unique_groups=len(old),prior_by_task=prior,labels=dict(Counter(r['label']for r in checked)),actual_prefix_plies=16,rows=checked,seconds=time.perf_counter()-t,scope='ALLnewinputs/sourcepins/publicsemantics/legalchildren/fullGameRecords/D4colororbits/disjointALLpriorconditionalRNfamilies checked. Exposedcanonicalreferenceconditionalmu, NOTnewrule/labelholdout/pricefitting orreward. Existing586328state3.168Medgeprepayment andloadcostexplicit; notgenericonlinediscovery.')

 with(OUT/'result.json').open('x')as f:json.dump(r,f,indent=2)

 print(json.dumps({k:v for k,v in r.items()if k!='rows'}))

if __name__=='__main__':run()

