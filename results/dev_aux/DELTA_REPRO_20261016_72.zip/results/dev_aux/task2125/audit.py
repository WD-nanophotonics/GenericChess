from pathlib import Path
from dataclasses import replace
from fractions import Fraction
import json,time,math
from scripts.generic_royal_actor import RoyalActor
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import action_to_dict
from generic_chess.session.session import GameSession
from generic_chess.session.result import SessionStatus
from scripts.generic_proof_rnb_bridge import actor_state,uci
OUT=Path('results/dev_aux/task2125')
def run():
 start=time.perf_counter();deadline=start+180;labels={r['index']:r for r in(json.loads(x)for x in Path('results/dev_aux/task2094/labels.jsonl').read_text().splitlines())};rows=[json.loads(x)for x in Path('results/dev_aux/task2124/population.jsonl').read_text().splitlines()];actor=RoyalActor(3);ratios=list(map(Fraction,['1/4','1/2','3/4','1','3/2','2','3']));publicnodes=0;count=0;leafcount=0
 def order(name):return json.dumps(dict(kind='board',**{'from':[ord(name[0])-97,int(name[1])-1],'to':[ord(name[2])-97,int(name[3])-1]},promotion_target_id=None),sort_keys=True)
 def coefficient(raw):return tuple(sum(1 if c.isupper()else-1 for c in raw[:-1]if c.upper()==typ)for typ in('N','B'))
 base=deserialize_ruleset(Path('results/dev_aux/task2093/rules.json').read_text(encoding='utf-8'))
 for i,row in enumerate(rows):
  if time.perf_counter()>=deadline:raise TimeoutError('original180cap')
  raw=tuple(row['board']);literal=sorted(actor.moves(raw),key=lambda pair:order(pair[0]));q={e['action']:-e['child_value']for e in labels[row['index']]['actions']};assert set(q)=={a for a,_ in literal};tree=[]
  for a,child in literal:
   replies=actor.moves(child);ll=[]
   if not replies:ll=[dict(terminal=1 if actor.attacked(child,actor.king(child,child[-1]),1-child[-1])else 0)]
   else:
    for _,leaf in replies:
     moves=actor.moves(leaf)
     if not moves:ll.append(dict(terminal=-1 if actor.attacked(leaf,actor.king(leaf,leaf[-1]),1-leaf[-1])else 0))
     else:ll.append(dict(coeff=coefficient(leaf)))
   tree.append((a,ll));leafcount+=len(ll)
  sets=[];first=[];good=[];allgood=[]
  for r in ratios:
   def score(t):return (math.inf if t['terminal']==1 else-math.inf if t['terminal']==-1 else 0)if'terminal'in t else t['coeff'][0]*r+t['coeff'][1]
   values=[min(map(score,ll))for _,ll in tree];best=max(values);aa=[a for(a,_),v in zip(tree,values)if v==best];sets.append(tuple(aa));first.append(aa[0]);good.append(any(q[a]==max(q.values())for a in aa));allgood.append(all(q[a]==max(q.values())for a in aa))
  expected=dict(price_sensitive_top_sets=len(set(sets))>1,price_sensitive_first=len(set(first))>1,no_positive_price_any_top_optimal=not any(good),no_positive_price_all_top_optimal=not any(allgood),no_positive_price_first_optimal=not any(q[a]==max(q.values())for a in first));
  if not all(row[k]==v for k,v in expected.items()):
   failure=dict(index=row['index'],board=raw,reported=row,recomputed=expected,root_actions=tree,q=q,first_actions=first,sets=sets);(OUT/'mismatch.json').write_text(json.dumps(failure,indent=2),encoding='utf-8');raise AssertionError('independentmismatchindex'+str(row['index']))
  count+=1
  if i<64:
   board=tuple(None if ch=='.'else Piece(int(ch.islower()),ch.upper(),ch.upper())for ch in raw[:-1]);rule=replace(base,initial_position=tuple(tuple(board[y:y+3])for y in range(0,9,3)),initial_setup_options=());c=compile_ruleset_for_execution(rule);s=GameSession(c);assert actor_state(s.state)==raw
   def public(current,depth):
    nonlocal publicnodes
    publicnodes+=1;state=actor_state(current.state);literal=dict(actor.moves(state));legal={uci(a):a for a in current.legal_actions()};assert set(legal)==set(literal)
    if current.result.status is not SessionStatus.ONGOING:
     assert not literal;return
    if not depth:return
    for name,a in legal.items():
     child=GameSession.replay(c,current.to_record());child.submit(a);assert actor_state(child.state)==literal[name];public(child,depth-1)
   public(s,2)
 result=dict(status='PASS_ALL9800_LITERAL_TWO_PLY_AND64_PUBLIC_HISTORY_TREES',population_roots=count,literal_leaf_count=leafcount,public_roots=64,public_nodes=publicnodes,global_rational_representatives=[str(r)for r in ratios],seconds=time.perf_counter()-start,scope='Independent literal-move/material implementation andglobalpartition, actualCoreSessionfrontiers/terminal on64predeclaredroots; full2093censusalreadycheckedALLCoreedges againstactor. Fresh2plycannotthirdrepeat or96draw. No newgame/PN/pricefit/holdoutclaim.')
 (OUT/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':run()

