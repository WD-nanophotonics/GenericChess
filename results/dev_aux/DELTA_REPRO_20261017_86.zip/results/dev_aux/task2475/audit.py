
"""Read-only relevance check of pinned PRIMARY guard fixes against own frozen rule closure."""
from pathlib import Path
from dataclasses import fields,is_dataclass
from collections import Counter
import json,hashlib,time,subprocess
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.serialization import deserialize_ruleset
from results.dev_aux.task2392.reader import SharedDeleteStopReader
OUT=Path('results/dev_aux/task2475')
def refs(value,path=''):
 out=[]
 if is_dataclass(value):
  if type(value).__name__=='CompiledSquareRef':out.append(dict(path=path,kind=value.kind))
  for f in fields(value):out+=refs(getattr(value,f.name),path+'.'+f.name)
 elif isinstance(value,(list,tuple)):
  for i,v in enumerate(value):out+=refs(v,path+f'[{i}]')
 return out
def run():
 t=time.perf_counter();p=json.loads((OUT/'plan.json').read_text());stop=SharedDeleteStopReader(Path.cwd());rows=[]
 for name,h in p['pins'].items():
  stop();assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
  c=compile_ruleset_for_execution(deserialize_ruleset(Path(name).read_text()))
  row=dict(path=name,sha=h,compiled_type=type(c).__name__,rules_fingerprint=c.ruleset_fingerprint,semantic_patterns=0,state_guards=0,subject_bound_guards=0,nonstandard_exists_comparisons=0,source_dependent_drop_guard_patterns=[],unbound_drop_source_offset_patterns=[],native_execution_used_by_85_producers=False)
  if hasattr(c,'ir'):
   row['semantic_patterns']=len(c.ir.patterns);geometry=c.ir.geometry
   for pat in c.ir.patterns:
    row['state_guards']+=len(pat.guards)
    row['subject_bound_guards']+=sum(g.subject_ref is not None for g in pat.guards)
    row['nonstandard_exists_comparisons']+=sum(g.aggregation=='exists'and(g.comparison,g.value)!=('eq',1)for g in pat.guards)
    if any(geometry[g].kind=='drop'for g in pat.geometry_ids):
     guardrefs=refs(pat.guards)
     if any(r['kind']in('source','offset_from_source','path_step')for r in guardrefs):row['source_dependent_drop_guard_patterns'].append(pat.pattern_id)
     if any(r['kind']=='offset_from_source'for r in refs(pat)):row['unbound_drop_source_offset_patterns'].append(pat.pattern_id)
  row['intersects_known_fix_conditions']=bool(row['subject_bound_guards']or row['nonstandard_exists_comparisons']or row['source_dependent_drop_guard_patterns']or row['unbound_drop_source_offset_patterns'])
  rows.append(row)
 assert not any(r['intersects_known_fix_conditions']for r in rows)
 result=dict(status='PASS_NO_FROZEN85_RULE_INTERSECTION_WITH_PINNED_GUARD_FIXES',primary_sha=p['primary_sha'],rules=len(rows),compiled_types=dict(Counter(r['compiled_type']for r in rows)),rows=rows,seconds=time.perf_counter()-t,scope=p['scope']+' This is source-condition relevance, not execution ofPRIMARYpatch orall-domainsemantic equivalence. Complete62actualreferencedrules include NEW8unqueriedreserverules: compilingIR isnotpricefitnessquery. No Nativebackend usedinown85source. The34semanticrules allstate-guardempty; effectsuse boundboard-source, nooffset-from-source droppattern.')
 (OUT/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='rows'}))
if __name__=='__main__':run()
