"""Frozen paired actual-rule strength evaluation on training-exposed generated rules."""
from pathlib import Path
import json,random,time,hashlib,datetime
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset
from generic_chess.session.session import GameSession
from results.dev_aux.task2525.run import RecordedSessionEnv,replay_bound
from results.dev_aux.task2492.learning import Model
from results.dev_aux.task2504.search import TrainingSearch
from results.dev_aux.task2392.reader import SharedDeleteStopReader
D=Path('results/dev_aux/task2531');T=Path('results/dev_aux/task2527')
def run():
 assert not(D/'started.json').exists();assert Path('results/dev_aux/task2528/result.json').exists();ss=json.loads(Path('.local_agent/session.json').read_text());assert(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(ss['started_at'])).total_seconds()<70*60;p=json.loads((D/'plan.json').read_text());train=json.loads(Path(p['training']).read_text());assert train['status']in('COMPLETE','PARTIAL_CAP'); assert len(train['arms'])<=16
 arms={(r['generator_seed'],r['seed']):r for r in train['arms']};compiled={gs:compile_ruleset(ruleset_from_dict(json.loads((T/('rules-'+str(gs)+'.json')).read_text())))for gs in p['generator_seeds']if(T/('rules-'+str(gs)+'.json')).exists()};stop=SharedDeleteStopReader(Path.cwd());stop();began=time.perf_counter();rows=[];status='COMPLETE';(D/'started.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),plan_sha=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest())))
 for n,h in p['pins'].items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
 with(D/'games.jsonl').open('x')as gf,(D/'queries.jsonl').open('x')as qf:
  for slot in p['slots']:
   gs,seed,family,color,treatment=slot
   if (gs,seed)not in arms or (treatment!='initial'and not any('n'+str(x['target_nodes'])==treatment for x in arms[gs,seed]['snapshots'])):continue
   a=arms[gs,seed];w=a['initial']if treatment=='initial'else next(x['weights']for x in a['snapshots']if 'n'+str(x['target_nodes'])==treatment);model=Model(w);foe=Model(p['foe_weights']);env=RecordedSessionEnv(GameSession(compiled[gs]),a['channels']);rng=random.Random(gs*1000000+family)
   for _ in range(p['prefix_plies']):
    if env.terminal()is not None:break
    env.push(rng.choice(sorted(env.actions(),key=repr)))
   replay_bound(env);prefix=env.record();game_began=time.perf_counter();nodes=0;nq=0;outcome=None;reason='HORIZON_UNKNOWN'
   for ply in range(p['H']):
    stop();outcome=env.terminal()
    if outcome is not None:reason='ACTUAL_TERMINAL';break
    left=p['cap_seconds']-(time.perf_counter()-began)
    if left<=0:reason='GLOBAL_CAP_UNKNOWN';status='PARTIAL_CAP';break
    actor=env.player();current=model if actor==color else foe;before=env.record();state=env.session.state;seconds=min(left,p['seconds_per_query']);r=TrainingSearch(p['depth'],quiet=False).search(env,current,nodes=p['nodes_per_query'],seconds=seconds,seed=gs*100000000+family*1000+ply+p['ordering_seed_offset'],cancel=stop);nodes+=r.nodes;nq+=1;assert env.record()==before and env.session.state==state
    if r.complete:env.push(r.action);replay_bound(env)
    qf.write(json.dumps(dict(slot=slot,ply=ply,record_before=before,record_after=env.record(),weights=list(current.weights),complete=r.complete,nodes=r.nodes,seconds=r.seconds,value=r.value,reason=r.reason,effective_node_limit=p['nodes_per_query'],effective_wall_limit=seconds,global_remaining_before_query=left),separators=(',',':'))+'\n');qf.flush()
    if not r.complete:reason='SEARCH_RESOURCE_UNKNOWN';break
   actual=env.terminal()
   if actual is not None:outcome=actual;reason='ACTUAL_TERMINAL'
   reward=None if outcome is None else outcome*(1 if color==0 else-1);row=dict(slot=slot,generator_seed=gs,seed=seed,family=family,color=color,treatment=treatment,weights=w,channels=a['channels'],initial_record=prefix,record=env.record(),outcome=outcome,reward=reward,ending=reason,nodes=nodes,queries=nq,seconds=time.perf_counter()-game_began);rows.append(row);gf.write(json.dumps(row,separators=(',',':'))+'\n');gf.flush()
   if len(rows)%32==0:print(json.dumps(dict(games=len(rows),seconds=time.perf_counter()-began)),flush=True)
   if status!='COMPLETE':break
 result=dict(status=status,expected=len(p['slots']),actual=len(rows),missing=len(p['slots'])-len(rows),nodes=sum(r['nodes']for r in rows),queries=sum(r['queries']for r in rows),actual_terminal=sum(r['outcome']is not None for r in rows),unknown=sum(r['outcome']is None for r in rows),seconds=time.perf_counter()-began,scope=p['scope']);(D/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
if __name__=='__main__':run()
