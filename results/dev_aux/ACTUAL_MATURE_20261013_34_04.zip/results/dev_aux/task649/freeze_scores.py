import json,hashlib,time
from pathlib import Path
from fractions import Fraction as F
R=Path.cwd();O=R/'results/dev_aux/task649';O.mkdir(exist_ok=True);d=json.loads((R/'results/dev_aux/task645/declaration.json').read_bytes());old=json.loads((R/'results/dev_aux/task599/result.json').read_bytes());new=json.loads((R/'results/dev_aux/task647/result.json').read_bytes());freeze=json.loads((R/'results/dev_aux/task645/all_endpoints_frozen.json').read_bytes());assert new['status']=='COMPLETE' and freeze['before_any_new_development'];ep=json.loads((R/'results/dev_aux/task646/endpoints.json').read_bytes());gs={}
for task in [599,647]:gs[task]=[json.loads(x) for x in (R/f'results/dev_aux/task{task}/games.jsonl').open(encoding='utf-8')]
# ONLYliteralinput/scoretablefreeze, no source reference descriptors yet; independentphysicalaudit621 requiredbeforefinalsummary.
rows=[];models=[]
def value(g,metric):
 winner=g['termination']['winner']
 if metric=='quantity':return F(g['raw_quantity'],19)
 if metric=='mixed':return F(g['goal'])
 if winner is None:return F(0)
 if metric=='terminal':return F(32 if winner==g['color'] else -32)
 return F(13-len(g['actions'])) if winner==g['color'] else F(-13)
for e in ep['endpoints']:
 st=e['start'];a=next(x for x in old['rows'] if 'terminal-'+st+'-initial' in x['names']);b=next(x for x in new['rows'] if st+'-endpoint' in x['names']);aa=[gs[599][s['line']-1] for s in a['batch']['sources']];bb=[gs[647][s['line']-1] for s in b['batch']['sources']];assert len(aa)==len(bb)==40 and [(g['root'],g['color']) for g in aa]==[(g['root'],g['color']) for g in bb];families=sorted({g['root']['source_family'] for g in aa});mm=[]
 for metric in ['quantity','fast','terminal','mixed']:
  diffs=[value(y,metric)-value(x,metric) for x,y in zip(aa,bb)];mm.append(dict(metric=metric,initial_mean=str(sum(value(x,metric) for x in aa)/40),endpoint_mean=str(sum(value(x,metric) for x in bb)/40),gain=str(sum(diffs)/40),by_family=[dict(family=f,gain=str(sum(diffs[i] for i,x in enumerate(aa) if x['root']['source_family']==f)/sum(x['root']['source_family']==f for x in aa))) for f in families],leave_one=[dict(omit=f,gain=str(sum(diffs[i] for i,x in enumerate(aa) if x['root']['source_family']!=f)/sum(x['root']['source_family']!=f for x in aa))) for f in families]))
 us=[u for u in ep['updates'] if u['start']==st];models.append(dict(start=st,initial=e['initial'],endpoint=e['endpoint'],accepted=sum(F(u['accepted_gain'])>0 for u in us),metrics=mm,initial_mates=sum(g['termination']['kind']=='checkmate' for g in aa),endpoint_mates=sum(g['termination']['kind']=='checkmate' for g in bb),root_family_count=3))
 for i,(x,y) in enumerate(zip(aa,bb)):rows.append(dict(start=st,root=x['root']['index'],family=x['root']['source_family'],color=x['color'],initial_plies=len(x['actions']),endpoint_plies=len(y['actions']),initial_termination=x['termination'],endpoint_termination=y['termination'],initial_source=a['batch']['sources'][i],endpoint_source=b['batch']['sources'][i]))
out=dict(status='ALL_FAST_DEV_SCORE_TABLE_FROZEN',models=models,rows=rows,initial_sources_reused=True,actual_new_development_games=80,initial_source_sha256=hashlib.sha256((R/'results/dev_aux/task599/games.jsonl').read_bytes()).hexdigest(),new_source_sha256=hashlib.sha256((R/'results/dev_aux/task647/games.jsonl').read_bytes()).hexdigest(),new_go=0,source_reference_read_here=False,scope='ALL2newfastendpoints/all40devcells+BOTHstarts initialraw599source reuse underSAMEoriginalsearch/RNG/cap/fullhistory. Alreadyexposeddevelopment3families, no newindependentholdout. No source reference inthis scoretable, freezebeforedescriptivecomparison. Independent621physical audit required tofinalclaim.');(O/'score_table_frozen.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps([dict(start=m['start'],accepted=m['accepted'],mates=[m['initial_mates'],m['endpoint_mates']],gains={x['metric']:x['gain'] for x in m['metrics']}) for m in models]))