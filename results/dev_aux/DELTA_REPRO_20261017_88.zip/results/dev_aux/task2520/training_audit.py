"""Independent scalar interval gradient / forward lambda update and legal-record replay."""
from pathlib import Path
from collections import defaultdict,Counter
from math import tanh,isclose,isfinite,sqrt
import json,hashlib,random,chess,time
OUT=Path('results/dev_aux/task2520');TRAIN=Path('results/dev_aux/task2518')
def near(a,b):return isclose(a,b,rel_tol=1e-10,abs_tol=1e-12)
def feat(board):return tuple(len(board.pieces(t,True))-len(board.pieces(t,False))for t in range(1,6))
def outcome(board):
 o=board.outcome(claim_draw=True);return None if o is None else 0 if o.winner is None else 1 if o.winner else-1

def training():
 started=time.perf_counter();p=json.loads((TRAIN/'plan.json').read_text());done=json.loads((TRAIN/'result.json').read_text());activation=json.loads((TRAIN/'activation.json').read_text());assert hashlib.sha256(Path(p['calibration']).read_bytes()).hexdigest()==activation['calibration_sha'];eps=[json.loads(x)for x in(TRAIN/'episodes.jsonl').read_text().splitlines()];by=defaultdict(list);nodecount=Counter();counts=Counter();methods=defaultdict(Counter);current={};samplechecks=[];curves=[]
 for n,h in p['pins'].items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
 # Streaming receipts keeps all-node logs bounded in memory by one episode.
 ef=iter(eps);ep=next(ef,None);decisions=(json.loads(x)for x in(TRAIN/'decisions.jsonl').open());pending=[]
 def close(ep,rr):
  key=ep['seed'],ep['method'];seed,method=key
  if key not in current:
   rng=random.Random(seed);current[key]=[1.]+[rng.uniform(.5,1.5)for _ in range(4)]
  assert current[key]==ep['initial_weights'];w=list(current[key]);b=chess.Board(ep['initial_record']['initial']);expected=chess.Board();rng=random.Random(p['opening_seed_base']+ep['game'])
  for _ in range(p['opening_plies']):
   if outcome(expected)is not None:break
   expected.push(rng.choice(sorted(expected.legal_moves,key=lambda m:m.uci())))
  assert ep['initial_record']['moves']==[m.uci()for m in expected.move_stack]
  for u in ep['initial_record']['moves']:
   m=chess.Move.from_uci(u);assert m in b.legal_moves;b.push(m);counts['prefix_plies']+=1
  preds=[];grads=[];sample_n=active_n=0;weighted_loss=0.;actual_changes=0
  assert len(rr)==ep['searches']
  for i,d in enumerate(rr):
   assert (d['seed'],d['method'],d['game'])==(ep['seed'],ep['method'],ep['game']);assert d['ply']==i and d['root_fen']==b.fen();assert d['weights_before']==w;assert 0<d['effective_node_limit']<=p['nodes_per_query'];assert 0<d['effective_wall_limit']<=p['seconds_per_query'];assert d['effective_wall_limit']<=d['global_remaining_before_query'];assert 0<=d['nodes']<=d['effective_node_limit'];nodecount[key]+=d['nodes'];assert d['total_nodes']==nodecount[key];counts['queries']+=1;methods[method]['queries']+=1;methods[method]['search_microseconds']+=round(d['seconds']*1e6)
   if not d['complete']:
    assert i==len(rr)-1 and not d['samples']and all(d[k]is None for k in('action','value','pv_phi','prediction','gradient'));assert d['weights_after']==w;counts['failed_queries']+=1;methods[method]['failed_query_nodes']+=d['nodes'];continue
   if d['pv_terminal']:assert d['value']in(-1000000.,0.,1000000.)and d['pv_phi']is None;grad=[0.]*5
   else:
    assert d['value']==sum(a*v for a,v in zip(w,d['pv_phi']));pred=tanh(d['value']/10);grad=[0. if j==0 else v*(1-pred*pred)/10 for j,v in enumerate(d['pv_phi'])]
   pred=tanh(d['value']/10);assert pred==d['prediction'];assert all(near(a,v)for a,v in zip(grad,d['gradient']));preds.append(pred);grads.append(grad)
   if i<4 and ep['game']==0:samplechecks.append(dict(seed=seed,method=method,game=0,ply=i))
   if method in('root','tree'):
    n=len(d['samples']);assert n>0;assert d['effective_eta']==(activation['eta_root']if method=='root'else activation['eta_tree']);assert n==(1 if method=='root'else d['full_search_sample_count']);delta=[0.]*5;loss=0.;active=0;root_delta=None;nonroot_active=0
    for index,(phi,lower,upper,depth)in enumerate(d['samples']):
     a=-1. if lower is None else tanh(lower/10);z=1. if upper is None else tanh(upper/10);assert a<=z;value=tanh(sum(x*v for x,v in zip(phi,w))/10);error=a-value if value<a else z-value if value>z else 0.;g=[0. if j==0 else x*(1-value*value)/10 for j,x in enumerate(phi)];piece_delta=[error*x for x in g];delta=[x+y for x,y in zip(delta,piece_delta)];loss+=error*error/2;active+=error!=0
     kind='LOWER'if upper is None else'UPPER'if lower is None else'EXACT';methods[method][kind+'_samples']+=1;methods[method][kind+'_active']+=error!=0;methods[method]['inactive_bounds']+=kind!='EXACT'and error==0
     if index==n-1:
      assert depth==p['depth']and tuple(phi)==feat(b)and lower==upper==d['value'];root_delta=piece_delta;methods[method]['root_active']+=error!=0
     else:nonroot_active+=error!=0
    expected=[v+d['effective_eta']*x/n for v,x in zip(w,delta)];expected[0]=1.;assert all(near(a,v)for a,v in zip(expected,d['weights_after']));assert d['update']['samples']==n and d['update']['active']==active;assert near(d['update']['loss'],loss/n)
    methods[method]['all_node_samples']+=n;methods[method]['active_samples']+=active;methods[method]['nonroot_active']+=nonroot_active;methods[method]['root_zero_tree_nonzero_queries']+=not any(root_delta)and any(delta);methods[method]['delta_mean_l1_micro']+=round(sum(abs(x)for x in delta)*d['effective_eta']/n*1e6);methods[method]['delta_root_l1_micro']+=round(sum(abs(x)for x in root_delta)*d['effective_eta']*1e6)
    sample_n+=n;active_n+=active;weighted_loss+=loss;actual_changes+=w!=d['weights_after'];w=d['weights_after']
   else:assert d['weights_after']==w and not d['samples']
   m=chess.Move.from_uci(d['action']);assert m in b.legal_moves;b.push(m);counts['training_plies']+=1
  assert b.fen()==ep['record']['fen']and[m.uci()for m in b.move_stack]==ep['record']['moves'];actual=outcome(b);assert actual==ep['outcome'];assert(actual is not None)==(ep['ending']=='ACTUAL_TERMINAL')
  if method=='td':
   errors=[preds[i+1]-preds[i]for i in range(max(0,len(preds)-1))]
   if preds and actual is not None:errors.append(float(actual)-preds[-1])
   credit=[0.]*5;future=0.
   for i in reversed(range(len(preds))):
    future=(errors[i]if i<len(errors)else 0.)+p['lambda']*future
    credit=[v+g*future for v,g in zip(credit,grads[i])]
   expected=[v+p['eta']*x for v,x in zip(w,credit)];expected[0]=1.;assert all(near(a,v)for a,v in zip(expected,ep['weights']));assert ep['stats']['samples']==len(errors);assert near(ep['stats']['loss'],sum(e*e/2 for e in errors)/max(1,len(errors)));methods[method]['td_terms']+=len(errors);methods[method]['nonzero_td_errors']+=sum(e!=0 for e in errors)
  else:
   assert w==ep['weights'];assert sample_n==ep['stats']['samples']and active_n==ep['stats']['active']and actual_changes==ep['stats']['query_updates'];assert near(ep['stats']['loss'],weighted_loss/max(1,sample_n));methods[method]['nonzero_query_updates']+=actual_changes
  counts['episodes']+=1;counts['actual_terminal_episodes']+=actual is not None;counts['censored_episodes']+=actual is None;methods[method]['episodes']+=1;methods[method]['actual_terminal_episodes']+=actual is not None;methods[method]['nonzero_episode_updates']+=ep['initial_weights']!=ep['weights'];current[key]=ep['weights'];curves.append(dict(seed=seed,method=method,game=ep['game'],nodes=nodecount[key],seconds=ep['seconds'],weights=ep['weights'],loss=ep['stats']['loss'],outcome=actual,samples=ep['stats']['samples']))
 for d in decisions:
  assert ep is not None
  if(d['seed'],d['method'],d['game'])!=(ep['seed'],ep['method'],ep['game']):
   close(ep,pending);pending=[];ep=next(ef,None);assert ep is not None
  pending.append(d)
 if ep is not None:close(ep,pending);assert next(ef,None)is None
 for a in done['arms']:
  key=a['seed'],a['method'];assert current[key]==a['weights']and nodecount[key]==a['nodes']
 assert sum(nodecount.values())==done['nodes'];result=dict(status='PASS_ALL_QUERY_UPDATES_AND_ACTUAL_TRAINING_RECORDS',counts=dict(counts),methods={k:dict(v)for k,v in methods.items()},arms=[{k:v for k,v in a.items()if k!='checkpoints'}for a in done['arms']],curves=curves,search_replay_slots=samplechecks,scope='Independent scalar one-sided STATIC transformed gradients for EVERY Root/Tree query; actualfrozenTRAINfactor/effectiveeta/fullsearchsamplecount checked. Rootusesonlyroot; TreeMEANallinteriors. NO TD training inthiscontrol. All legal actualChessrecords/censors/effectivebudgets/sourcepins checked. Same rulelibrary, not externalengine. RootandTree BOTHperquery/static/half-squared, but differentnodesets andon-policydata; initialRMSmatchONLY. NoTDtraining/objectiveinthiscontrol. Sourcepins raw archiveauthority.',audit_seconds=time.perf_counter()-started);(OUT/'training-audit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items()if k not in('curves','arms','search_replay_slots')}))
if __name__=='__main__':training()
