from pathlib import Path
from dataclasses import replace
from copy import copy
import json,time
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import action_to_dict
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import *
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from results.dev_aux.task2392.reader import SharedDeleteStopReader
OUT=Path('results/dev_aux/task2400')
def definition(kind):
 base=deserialize_ruleset(Path('results/dev_aux/task2315/rules.json').read_text())
 # Change only the future captured actor's BASE; surviving full board becomes identical.
 rows=[list(r)for r in base.initial_position];rows[2][0]=Piece(1,'P','R',True)
 setup=base.initial_setup_options[0] # preserve actual required initial base inventory
 masks={k:tuple(tuple(False for x in row)for row in mm)for k,mm in base.drop_allowed.items()}
 act=RuleSemanticAction(name='hand_R_unlocks_rook_quiet',type_ids=('R',),geometry=RuleGeometrySpec('legacy_atoms',atom_kind='ray'),target_relation='empty',composition='replace_legacy',replace_selector=RuleReplaceSelector(('R',),'board','empty',geometry_kind='ray',replace_all_matching=True),path_constraints=(RulePathConstraint('path_clear'),),effects=(RuleActionEffect('remove_from_hand',piece_type_ref=RuleTypeRef('explicit',type_id='R')),RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target'))),invariants=(RuleInvariant('own_anchor_safe'),))
 rs=replace(base,drop_allowed=masks,initial_setup_options=(setup,),semantic_actions=(base.semantic_actions[1],act))
 if kind=='unsupported_guard':
  guard=RuleStateGuard('count','self',RuleTypeRef('explicit',type_id='R'),'base','any','hand',RuleSpatialSelector('any'),'ge',1)
  rs=replace(rs,semantic_actions=(base.semantic_actions[1],replace(act,effects=act.effects[1:],state_guards=(guard,))))
 if kind=='declaration':
  d=RuleDeclaration('stock_rule_win',0,weighted_metric=RuleWeightedMaterialMetric(weights={'R':1},include_hands=True),outcome_bands=(RuleDeclarationOutcomeBand(1,'WIN'),),failure_outcome='LOSS')
  rs=replace(rs,semantic_actions=(base.semantic_actions[1],),declarations=(d,))
 return rs
def ready(c,setup):
 s=GameSession(c,**({}if setup is None else dict(initial_setup_key=setup)))
 for src,dst,semantic in(((0,1),(0,2),True),((3,0),(3,1),False)):
  a,=[a for a in s.legal_actions()if hasattr(a,'from_square')and(a.from_square.file,a.from_square.rank)==src and(a.to_square.file,a.to_square.rank)==dst and a.pattern_id.startswith('sem_')==semantic];s.submit(a)
 return s
def run():
 start=time.perf_counter();stop=SharedDeleteStopReader(Path.cwd());stop();results={}
 for kind in('unsupported_guard','consume','declaration'):
  stop();rs=definition(kind);(OUT/(kind+'-rules.json')).write_text(serialize_ruleset(rs),encoding='utf-8')
  if kind=='unsupported_guard':
   try:compile_ruleset_for_execution(rs)
   except ValueError as e:
    assert 'HAND_PREDICATE_UNSUPPORTED'in str(e);results[kind]=dict(status='REJECTED_BY_ACTUAL_COMPILER',error=str(e))
   else:raise AssertionError('unsupported hand guard unexpectedly admitted')
   continue
  c=compile_ruleset_for_execution(rs);a,b=[ready(c,setup)for setup in(None,'swapped_bases')];assert tuple(None if p is None else(p.owner,p.current_type_id)for p in a.state.position.board)==tuple(None if p is None else(p.owner,p.current_type_id)for p in b.state.position.board) and a.state.position.aux_state==b.state.position.aux_state and a.state.position.side_to_move==b.state.position.side_to_move
  assert dict(a.state.position.hands[0].counts)=={'R':1}and dict(b.state.position.hands[0].counts)=={'P':1}
  assert not any(v for masks in rs.drop_allowed.values()for row in masks for v in row)
  rows=[]
  for setup,s in zip((None,'swapped_bases'),(a,b)):
   actions=s.legal_actions();assert all(action_to_dict(x)['kind']!='semantic_drop'for x in actions)
   r=dict(setup=setup,root_record=json.loads(serialize_game_record(s.to_record())),hands=[dict(h.counts)for h in s.state.position.hands],legal_actions=[action_to_dict(x)for x in actions],actual_status=s.result.status.value)
   if kind=='consume':
    consuming=[x for x in actions if x.pattern_id.startswith('sem_01')];assert len(consuming)==(6 if setup is None else 0)
    children=[]
    for x in consuming:
     ch=copy(s);ch.submit(x);assert not ch.state.position.hands[0].counts;re=GameSession.replay(c,ch.to_record());assert re.state==ch.state and re.result==ch.result;children.append(dict(record=json.loads(serialize_game_record(ch.to_record())),status=ch.result.status.value))
    r['consuming_children']=children
   else:
    s.declare('stock_rule_win');assert s.result.winner==(0 if setup is None else 1);re=GameSession.replay(c,s.to_record());assert re.result==s.result;r.update(actual_winner=s.result.winner,actual_status=s.result.status.value,actual_record=json.loads(serialize_game_record(s.to_record())))
   rows.append(r)
  results[kind]=dict(status='PASS_ACTUAL_COMPLETE_CORE_HISTORY',same_current_type_owner_board=True,full_base_board_equal=False,rows=rows)
 out=dict(status='QUALIFIED_NO_DROP_MASK_IS_INSUFFICIENT',controls=results,seconds=time.perf_counter()-start,scope='Constructed same-current-type-board countercontrols; surviving base types also differ under inventory-preserving setups, so not full-Position equivalence. Constructed semantic/adjudication countercontrols, not training labels or price evidence. Guard unsupported retained, not bypassed. Board-action hand consumption changes legalchoices; independent declared actual rule changes WIN/LOSS. Explicit declaration weights define this synthetic rule, not human/evaluator-price fitting. No product/default/Core/PRIMARY changes. Inert-hand proof remains limited to2396 simpleclass; complete-domain hand-zero classifier not implemented.')
 (OUT/'result.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in out.items()if k!='controls'}))
if __name__=='__main__':run()
