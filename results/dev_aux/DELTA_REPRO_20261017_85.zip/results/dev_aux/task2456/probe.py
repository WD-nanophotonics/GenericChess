"""Actual floating-point normal-search qualification of ideal rational faces."""
from pathlib import Path
from fractions import Fraction as F
from dataclasses import fields
import json,time,hashlib,datetime
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from results.dev_aux.task2148.normal import SessionCompleteMaterialSearch
from results.dev_aux.task2397.material import material
from results.dev_aux.task2392.reader import SharedDeleteStopReader
from results.dev_aux.task2175.receipt import choice_value
from results.dev_aux.task2447.arrangement import fold
OUT=Path('results/dev_aux/task2456')
def run():
 assert (OUT/'started.json').exists();p=json.loads((OUT/'plan.json').read_text());stop=SharedDeleteStopReader(Path.cwd());t=time.perf_counter();original=json.loads((OUT/'started.json').read_text());remaining=max(0.,p['cap_seconds']-(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(original['utc'])).total_seconds());deadline=t+remaining;faces=json.loads(Path(p['faces']).read_text());nodes=[json.loads(x)for x in Path(p['nodes']).read_text().splitlines()];root=json.loads(Path(p['root']).read_text());c=compile_ruleset_for_execution(deserialize_ruleset(Path(root['rules']).read_text()));s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));snapshot=s.state;rows=[]
 for name,h in p['pins'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h
 def cancel():stop();return time.perf_counter()>=deadline
 for face in faces:
  if cancel():break
  point=tuple(map(F,face['point']));a,b=map(float,point);quantized=(F(a),F(b));ideal=fold(nodes,point);q=fold(nodes,quantized);normal=SessionCompleteMaterialSearch(c,lambda pos,target:material(pos,target,{'R':a,'N':1.,'B':1.},{'R':b,'N':1.,'B':1.},excluded_type_ids={'K'}),max_depth=3);receipt=normal.choose(s,max_nodes=8192,seconds=min(3.,max(0.,deadline-time.perf_counter())),cancel=cancel);r={f.name:(choice_value(v)if f.name=='choice'else v)for f in fields(receipt)for v in[getattr(receipt,f.name)]};actual=next((i for i,(ch,j)in enumerate(nodes[0]['children'])if ch==r['choice']),None);rows.append(dict(kind=face['kind'],index=face['index'],rational_point=face['point'],float_point=[a.hex(),b.hex()],ideal_action=ideal[0],quantized_exact_action=q[0],actual_action=actual,input_quantization_changes_action=ideal[0]!=q[0],actual_vs_exact_quantized_action=actual!=q[0],receipt=r));assert s.state==snapshot
 (OUT/'queries.json').write_text(json.dumps(rows,indent=2));result=dict(status='COMPLETE_FLOAT_NORMAL_FACE_QUALIFICATION'if len(rows)==len(faces)else'PARTIAL_NO_CAP_EXTENSION',queries=len(rows),expected=len(faces),ordinary_D3=sum(r['receipt']['completed_depth']==3 for r in rows),quantization_action_changes=sum(r['input_quantization_changes_action']for r in rows),float_arithmetic_action_changes=sum(r['actual_vs_exact_quantized_action']for r in rows if r['receipt']['completed_depth']==3),seconds=time.perf_counter()-t,scope=p['scope']);(OUT/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
if __name__=='__main__':run()
