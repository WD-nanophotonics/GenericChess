"""Per-arm exact feature spans and signal counts; no fitting or model selection."""
from pathlib import Path
from fractions import Fraction
from collections import Counter,defaultdict
from math import tanh,sqrt
import json,time
O=Path('results/dev_aux/task2557')
def rank_add(basis,phi):
 if len(basis)==6:return
 v=list(map(Fraction,phi))
 for pivot,row in basis:
  a=v[pivot]
  if a:v=[x-a*y for x,y in zip(v,row)]
 pivot=next((j for j,x in enumerate(v)if x),None)
 if pivot is None:return
 z=v[pivot];basis.append((pivot,[x/z for x in v]));basis.sort(key=lambda x:x[0])
def run(source_filter=None):
 began=time.perf_counter();rows=[];bins=defaultdict(Counter)
 for label,source in json.loads((O/'diagnostic-plan.json').read_text())['sources'].items():
  if source_filter is not None and label!=source_filter:continue
  D=Path(source);p=json.loads((D/'plan.json').read_text());done=json.loads((D/'result.json').read_text());stats=defaultdict(Counter);seen=defaultdict(list);active=defaultdict(list);hist=defaultdict(Counter);bygid={};episodes={}
  for line in(D/'games.jsonl').open():
   g=json.loads(line);episodes[g['gameid']]=g;bygid[g['gameid']]=[]
  for line in(D/'queries.jsonl').open():
   q=json.loads(line);key=q['generator_seed'],q['method'],q['seed'];c=stats[key];c['queries']+=1;c['nodes']+=q['nodes'];c['candidate_queries']+=q['actor']==q['color'];c['incomplete_queries']+=not q['complete']
   if not q['observed']:continue
   c['observations']+=1;pred=tanh(q['value']/10);c['saturated_abs_prediction_ge_99']+=abs(pred)>=.99;c['terminal_PV_observations']+=q['pv_terminal']
   if q['method']=='TD':
    c['TD_terminal_PV_zero_gradient']+=q['pv_terminal'];bygid[q['gameid']].append((pred,q['pv_phi'],q['pv_terminal']))
    if not q['pv_terminal']:rank_add(seen[key],q['pv_phi'])
   else:
    for s in q['samples']:
     phi=s['phi'];rank_add(seen[key],phi);v=tanh(sum(a*b for a,b in zip(q['weights'],phi))/10);lo=tanh(float(s['lower'])/10);hi=tanh(float(s['upper'])/10);e=lo-v if v<lo else hi-v if v>hi else 0.;kind='exact'if s['lower']==s['upper']else'upper'if float(s['lower'])==float('-inf')else'lower';bk=(label,)+key+(min(3,max(0,(q['total_nodes']-q['nodes'])//50000)),);bins[bk]['loss_sum']+=e*e/2;bins[bk]['samples']+=1;hist[key][str(s['depth'])+'_'+kind]+=1;c['tree_samples']+=1;c['tree_active']+=e!=0;c['tree_loss_sum']+=e*e/2
     if e!=0:rank_add(active[key],phi)
  for gid,obs in bygid.items():
   g=episodes[gid];key=g['generator_seed'],g['method'],g['seed']
   if g['method']!='TD':continue
   c=stats[key];errors=[obs[i+1][0]-obs[i][0]for i in range(len(obs)-1)];c['transition_terms']+=len(errors)
   if g['outcome']is not None and obs:
    end=g['outcome']-obs[-1][0];errors.append(end);c['endpoint_terms']+=1;c['nonzero_endpoint_terms']+=end!=0
   bk=(label,)+key+(min(3,max(0,(g['total_nodes']-1)//50000)),);bins[bk]['loss_sum']+=sum(e*e/2 for e in errors);bins[bk]['samples']+=len(errors);c['td_terms']+=len(errors);c['td_loss_sum']+=sum(e*e/2 for e in errors);future=0.
   for i in reversed(range(len(obs))):
    future=(errors[i]if i<len(errors)else 0.)+p['lam']*future
    if not obs[i][2]and future!=0:rank_add(active[key],obs[i][1]);c['nonzero_credited_nonterminal_observations']+=1
  for a in done['arms']:
   key=a['generator_seed'],a['method'],a['seed'];assert stats[key]['nodes']==a['nodes'];w=a['weights'];norm=sqrt(sum(x*x for x in w));rows.append(dict(training=label,rule=key[0],method=key[1],seed=key[2],raw_weights=w,L2_norm=norm,unit_L2=[x/norm for x in w]if norm else None,observed_feature_rank=len(seen[key]),active_credit_feature_rank=len(active[key]),observed_basis=[dict(pivot=i,row=list(map(str,v)))for i,v in seen[key]],active_basis=[dict(pivot=i,row=list(map(str,v)))for i,v in active[key]],counts=dict(stats[key]),sample_depth_bounds=dict(hist[key]),games=a['games'],episode_updates=a['updates'],query_updates=a['query_updates'],actual_terminal=sum(g['outcome']is not None for g in episodes.values()if(g['generator_seed'],g['method'],g['seed'])==key)))
 pairs=[]
 for label in['D2','D3']:
  for gs in sorted(set(x['rule']for x in rows)):
   for method in['TD','TreeStrap']:
    rr=[x for x in rows if(x['training'],x['rule'],x['method'])==(label,gs,method)];cs=[]
    for i,a in enumerate(rr):
     for b in rr[i+1:]:
      if a['unit_L2']is not None and b['unit_L2']is not None:cs.append(dict(seeds=[a['seed'],b['seed']],cosine=sum(x*y for x,y in zip(a['unit_L2'],b['unit_L2']))))
    pairs.append(dict(training=label,rule=gs,method=method,pairs=cs))
 out=dict(status='ALL_RECORDED_ARMS_SIGNAL_AND_EXACT_SPANS_NO_SELECTION',rows=rows,pairs=pairs,loss_bins=[dict(training=a,rule=g,method=m,seed=z,bucket=b,paid_node_upper=(b+1)*50000,loss_sum=v['loss_sum'],samples=v['samples'],mean=v['loss_sum']/max(1,v['samples']))for(a,g,m,z,b),v in sorted(bins.items())],seconds=time.perf_counter()-began,scope=json.loads((O/'diagnostic-plan.json').read_text())['limits']);(O/('signals.json'if source_filter is None else'signals-'+source_filter+'.json')).write_text(json.dumps(out,indent=2));print(json.dumps(dict(status=out['status'],arms=len(rows),observed_full_rank=sum(x['observed_feature_rank']==6 for x in rows),active_full_rank=sum(x['active_credit_feature_rank']==6 for x in rows),seconds=out['seconds'])))
if __name__=='__main__':run()
