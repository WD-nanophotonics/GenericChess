from pathlib import Path
from dataclasses import fields
import json,hashlib,datetime
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.session.result import SessionStatus
out=Path('results/dev_aux/task2385');out.mkdir();old=Path('results/dev_aux/task2358');base=json.loads((old/'plan.json').read_text());roots=json.loads((old/'inputs.json').read_text());newroots=[];slots=[];variants=['REMOVAL_NO_DROPS','HAND_NO_DROPS','HAND_WITH_DROPS']
for v,variant in enumerate(variants):
 for family,r in enumerate(roots):
  raw=json.loads(Path(r['rules']).read_text());raw['capture_disposition']='remove_from_game'if v==0 else'capture_to_hand'
  if v==2:
   size=raw['board_size'];raw['drop_allowed']={key:[[bool(key in('R','N'))for _ in range(size*size)]for _ in(0,1)]for key in raw['drop_allowed']}
  path=out/f'rules-v{v}-f{family}.json';path.write_text(serialize_ruleset(deserialize_ruleset(json.dumps(raw))),encoding='utf-8');c=compile_ruleset_for_execution(deserialize_ruleset(path.read_text()));s=GameSession(c)
  for a in deserialize_game_record(json.dumps(r['record'])).actions:s.submit(a)
  assert s.result.status is SessionStatus.ONGOING
  newroots.append(dict(index=len(newroots),rules=path.as_posix(),record=json.loads(serialize_game_record(s.to_record())),state_sha=hashlib.sha256(repr(s.state).encode()).hexdigest(),family=family,variant=variant,source_rules=r['rules'],source_record=r['record'],scope='Existing8TRAINfamilies/actualsameprefixactionsundernewdeclaredrules. Newfingerprint/actualrecord; oldcanonicalWDLlabelsNOTtransported. Exposedstarts/rulemechanismresponseonly, noholdout/refit.'))
# Interleave complete role/price pairs across variants to reduce order/cap bias.
for family in range(8):
 for color in(0,1):
  for v in(range(3)if(family+color)%2==0 else reversed(range(3))):
   for price in((1.,1.5)if(family+color+v)%2==0 else(1.5,1.)):
    slots.append(dict(slot=len(slots),root=v*8+family,opponent=0,candidate_color=color,ratio=price,arm='LOW_ONLY_INCREMENTAL'))
(out/'inputs.json').write_text(json.dumps(newroots,indent=2),encoding='utf-8');(out/'slots.json').write_text(json.dumps(slots,indent=2),encoding='utf-8')
pilot=Path('results/dev_aux/task2354/pilot.py').read_text();pilot=pilot.replace("OUT=Path('results/dev_aux/task2355')","OUT=Path('results/dev_aux/task2385')").replace('from results.dev_aux.task2153.stop_evidence import EvidenceStopReader','from results.dev_aux.task2379.reader import FreshFileIOStopReader as EvidenceStopReader\nfrom results.dev_aux.task2376.material import material as semantic_material')
start=pilot.index('   def material(pos,target,ratio):');end=pilot.index("   cfg=p['candidate']",start)
pilot=pilot[:start]+'''   def material(pos,target,ratio):
    return semantic_material(pos,target,{t.type_id:(ratio if t.type_id=='R'else 1.)for t in definition.piece_types if not t.is_anchor},excluded_type_ids=anchors)
'''+pilot[end:]
pilot=pilot.replace("__import__('results.dev_aux.task2273.incremental_adapted'","__import__('results.dev_aux.task2384.incremental'")
pilot=pilot.replace("sum(pc is not None for pc in s.state.position.board)+sum(n for h in s.state.position.hands for _,n in h.counts)<=4", "sum(pc is not None for pc in s.state.position.board)<=4 and sum(pc is not None for pc in s.state.position.board)+sum(n for h in s.state.position.hands for _,n in h.counts)<=8")
(out/'pilot.py').write_text(pilot,encoding='utf-8')
q=dict(base);q.update(input=(out/'inputs.json').as_posix(),input_sha=hashlib.sha256((out/'inputs.json').read_bytes()).hexdigest(),slots_sha=hashlib.sha256((out/'slots.json').read_bytes()).hexdigest(),expected_games=96,one_cap_seconds=2100,forecast_seconds=1500,candidate_prices=[1.,1.5],opponents=[dict(base['opponents'][0],ratio=2.)],H=96,scope='FIXEDoldTRAINprices1/1.5, same8exposedTRAINfamilies/roles/foe2. THREEprogressiverulevariantsremove/noDROP,hand/noDROP,hand/DROP; actual96ply/repetitionmaxterminals only, U/missingunknown. No fitter/newinitialfamily/unknownruleholdout/canonicalteacher/humanlabel. SAMEnewoptinfullpolicy/typefeatures/BOARD4TOTAL8gate/freshFileIO/exception-correctedselector16 acrossALLvariants/prices. Phasebudgets unchangedasymmetriccandidate/foe. Notcausalcomparisonagainstold82S norreuseoldoutcomes. Foreligibility countsincludehands; no product/PRIMARY/defaultadoption. One original2100cap/noextension; partial slots allretained.',variants=variants)
q['pins']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()for name in['results/dev_aux/task2385/pilot.py','results/dev_aux/task2379/reader.py','results/dev_aux/task2376/material.py','results/dev_aux/task2384/incremental.py','results/dev_aux/task2384/correction.json','results/dev_aux/task2357/selection.json']+[r['rules']for r in newroots]}
(out/'plan.json').write_text(json.dumps(q,indent=2),encoding='utf-8');(out/'registration.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),question='Does actual-rule price1.5vs1 response change along capture-retention/dropmechanisms underSAMEcorrectedcompleteplayer?',potential_outcomes='Priceadvantage survives/disappears/reverses or allcensored/insensitive; distinguish terminalcoverage/proofexecution andmissing. No refitanyresult.',incremental_cost='96newgames ONE2100s cap forecast1500; prequery fixed8families96slots. Estimatedunder2h, no priorDotreviewrequired. Older114proofqueriesclosed.',cheaper_alternative='Existingcompositealreadyexposesdeadtotalinventorygate butcannotmeasureactualW-L utility/priceinteraction; currentpanelneededbeforelargerlearning.',frozen_after='2381closed cost/correctness results andDotexceptionexit advice; beforeANY2385fitness',no_concurrent_producer=True),indent=2),encoding='utf-8')
print(json.dumps(dict(roots=len(newroots),slots=len(slots),candidate=q['candidate'],foe=q['opponents'])))
