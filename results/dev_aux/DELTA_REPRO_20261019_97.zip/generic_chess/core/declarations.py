"""Pure, action-independent declaration/claim assessment."""

from __future__ import annotations

from dataclasses import dataclass

from .attacks import is_in_check
from .coordinates import BoardShape
from .errors import ensure_ruleset_match
from .position import GameState, Position


class InvalidDeclarationError(ValueError):
    """The caller selected an unknown or incorrectly bound declaration."""


@dataclass(frozen=True, slots=True)
class DeclarationAssessment:
    declaration_id: str
    actor: int
    outcome: str
    weighted_score: int | None = None


def _declarations(compiled):
    return tuple(getattr(compiled, "declarations", ()))


def _state_parts(state):
    if isinstance(state, GameState):
        return state.position, state.ply_count
    raise TypeError("declaration assessment requires authoritative GameState context")


def _owner_matches(selector: str, piece_owner: int, actor: int) -> bool:
    if selector == "any":
        return True
    if selector == "self":
        return piece_owner == actor
    return piece_owner != actor


def _compare(op: str, left: int, right: int) -> bool:
    return {
        "eq": left == right,
        "ne": left != right,
        "lt": left < right,
        "le": left <= right,
        "gt": left > right,
        "ge": left >= right,
    }.get(op, False)


def _fixed_index(ref, shape: BoardShape) -> int | None:
    if ref is None or ref.kind != "fixed" or ref.square is None:
        return None
    file, rank = ref.square
    if not (0 <= file < shape.width and 0 <= rank < shape.height):
        return None
    return rank * shape.width + file


def _spatial_holds(spatial, index: int, declaration, shape: BoardShape) -> bool:
    if spatial.kind == "zone":
        zone = declaration.zones.get(spatial.zone_id)
        return zone is not None and index in zone.squares
    if spatial.kind == "exact" and spatial.refs:
        return index == _fixed_index(spatial.refs[0], shape)
    return False


def _guard_holds(guard, position: Position, declaration, actor: int) -> bool:
    shape = position.board_shape
    if guard.location != "board":
        return False
    if guard.subject_ref is not None:
        indices = (_fixed_index(guard.subject_ref, shape),)
    else:
        indices = range(len(position.board))
    count = 0
    for index in indices:
        if index is None:
            continue
        piece = position.board[index]
        if piece is None or not _owner_matches(guard.owner, piece.owner, actor):
            continue
        if guard.type_ref.kind == "explicit":
            selected = (
                piece.base_type_id
                if guard.compare_field == "base"
                else piece.current_type_id
            )
            if selected != guard.type_ref.type_id:
                continue
        elif guard.type_ref.kind != "any":
            return False
        if guard.promoted != "any" and ((guard.promoted == "yes") != piece.promoted):
            continue
        if not _spatial_holds(guard.spatial, index, declaration, shape):
            continue
        count += 1
    value = (1 if count else 0) if guard.aggregation == "exists" else count
    return _compare(guard.comparison, value, guard.value)


def _in_check(position: Position, actor: int, compiled) -> bool:
    from .semantic_executor import semantic_engine_for

    engine = semantic_engine_for(compiled)
    return engine.in_check(position, actor) if engine is not None else is_in_check(position, actor, compiled)


def _score(position: Position, declaration, actor: int) -> int:
    metric = declaration.weighted_metric
    if metric is None:
        return 0
    shape = position.board_shape
    weights = dict(metric.weights)
    score = 0
    for index, piece in enumerate(position.board):
        if piece is None or not _owner_matches(metric.owner, piece.owner, actor):
            continue
        if metric.spatial is not None and not _spatial_holds(
            metric.spatial, index, declaration, shape
        ):
            continue
        type_id = piece.base_type_id if metric.compare_field == "base" else piece.current_type_id
        score += weights.get(type_id, 0)
    if metric.include_hands:
        for owner, hand in enumerate(position.hands):
            if not _owner_matches(metric.owner, owner, actor):
                continue
            for type_id, count in hand.items():
                score += weights.get(type_id, 0) * count
    return score


def _assess_declaration_position(
    position: Position, ply: int, compiled, declaration_id: str
) -> DeclarationAssessment:
    """Assess an authoritative position/ply pair for Core and search callers."""
    ensure_ruleset_match(position, compiled)
    matches = [d for d in _declarations(compiled) if d.declaration_id == declaration_id]
    if not matches:
        raise InvalidDeclarationError(f"unknown declaration ID {declaration_id!r}")
    declaration = matches[0]
    actor = position.side_to_move
    if declaration.owner != actor:
        raise InvalidDeclarationError(
            f"declaration {declaration_id!r} belongs to player {declaration.owner}, not player {actor}"
        )
    score = _score(position, declaration, actor) if declaration.weighted_metric else None
    valid = all(_guard_holds(g, position, declaration, actor) for g in declaration.state_guards)
    if declaration.require_not_in_check and _in_check(position, actor, compiled):
        valid = False
    if declaration.ply_limit is not None and ply >= declaration.ply_limit:
        valid = False
    if not valid:
        outcome = declaration.failure_outcome
    else:
        outcome = declaration.failure_outcome
        for band in declaration.outcome_bands:
            if score is not None and score >= band.threshold:
                outcome = band.outcome
                break
    return DeclarationAssessment(declaration.declaration_id, actor, outcome, score)


def assess_declaration(state, compiled, declaration_id: str) -> DeclarationAssessment:
    """Assess one explicitly selected declaration without changing state."""
    position, ply = _state_parts(state)
    return _assess_declaration_position(position, ply, compiled, declaration_id)


def available_declarations(state, compiled) -> tuple[DeclarationAssessment, ...]:
    """Return only non-losing declarations belonging to the side to move."""
    position, _ = _state_parts(state)
    ensure_ruleset_match(position, compiled)
    out = []
    for declaration in _declarations(compiled):
        if declaration.owner != position.side_to_move:
            continue
        assessment = _assess_declaration_position(
            position, state.ply_count, compiled, declaration.declaration_id
        )
        if assessment.outcome != "LOSS":
            out.append(assessment)
    return tuple(out)


def _available_declarations_position(position: Position, ply: int, compiled):
    """Private search bridge using an explicit authoritative runtime pair."""
    ensure_ruleset_match(position, compiled)
    return tuple(
        assessment
        for declaration in _declarations(compiled)
        if declaration.owner == position.side_to_move
        for assessment in (
            _assess_declaration_position(
                position, ply, compiled, declaration.declaration_id
            ),
        )
        if assessment.outcome != "LOSS"
    )


__all__ = [
    "DeclarationAssessment",
    "InvalidDeclarationError",
    "assess_declaration",
    "available_declarations",
    "_assess_declaration_position",
    "_available_declarations_position",
]
