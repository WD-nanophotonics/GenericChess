"""Independent minimax/finite-difference/rule-boundary checks for new learner."""
import math,random
import chess
import pytest
from results.dev_aux.task2492.learning import Model,Sample,Receipt,AlphaBeta,TreeStrap,TDLeaf,interval_error
from results.dev_aux.task2492.adapters import ChessEnv

class Tree:
 def __init__(self,leaves):self.leaves=leaves;self.path=[]
 def player(self):return len(self.path)%2
 def features(self):return (0.,float(self.leaves[self.path[0]][self.path[1]])) if len(self.path)==2 else (0.,100.+self.path[0]) if self.path else (0.,0.)
 def terminal(self):return None
 def actions(self):return range(2) if len(self.path)<2 else ()
 def in_check(self):return False
 def tactical(self,a):return False
 def push(self,a):self.path.append(a)
 def pop(self):self.path.pop()

def receipt(samples=(),value=0.,phi=(0.,1.),terminal=False,complete=True):return Receipt(None,value,phi,terminal,tuple(samples),1,complete,0,0.,'test')

def test_all_bounds_against_exhaustive_minimax():
 for seed in range(40):
  rng=random.Random(seed);leaves=[[rng.randint(-8,8)for _ in range(2)]for _ in range(2)]
  env=Tree(leaves);r=AlphaBeta(2,0).search(env,Model([1,1]),seed=seed)
  assert r.complete and r.value==max(map(min,leaves)) and env.path==[]
  assert r.samples[-1].lower==r.samples[-1].upper==r.value
  # Each depth1 trace occurs in shuffled root order; its value interval MUST
  # contain one of the independent exact minimax child values.
  for s in r.samples[:-1]:assert s.lower<=min(leaves[int(s.phi[1]-100)])<=s.upper

def test_one_sided_loss_is_zero_inside_and_correct_outside():
 assert interval_error(5,3,math.inf)==0
 assert interval_error(1,3,math.inf)==2
 assert interval_error(-5,-math.inf,-3)==0
 assert interval_error(-1,-math.inf,-3)==-2
 with pytest.raises(ValueError):interval_error(0,2,1)

def test_batch_target_and_gradient_are_frozen_and_pawn_fixed():
 m=Model([1,1]);s=Sample((4.,1.),8,math.inf,1);p=m.prediction(s.phi);g=m.gradient(s.phi)[1]
 r=TreeStrap(.1).update(m,receipt([s]))
 assert m.weights[0]==1 and m.weights[1]==pytest.approx(1+.1*(math.tanh(.8)-p)*g)
 assert r['active']==1

def test_td_white_orientation_terminal_and_unknown():
 m=Model([1,1]);td=TDLeaf(eta=.1,lam=.5);td.observe(m,receipt(value=1));before=list(m.weights)
 td.finish(m,None);assert m.weights==before and td.previous is None
 td.observe(m,receipt(value=1));td.finish(m,-1);assert m.weights[1]<before[1] and m.weights[0]==1

def test_model_gradient_finite_difference_and_partial_search_discards():
 m=Model([1,.7,1.8]);phi=(2.,-1.,3.);g=m.gradient(phi)
 for i in (1,2):
  old=m.weights[i];m.weights[i]=old+1e-6;a=m.prediction(phi);m.weights[i]=old-1e-6;b=m.prediction(phi);m.weights[i]=old
  assert g[i]==pytest.approx((a-b)/2e-6,abs=1e-8)
 e=ChessEnv();record=e.record();r=AlphaBeta(2,0).search(e,m if False else Model([1]*5),nodes=2)
 assert not r.complete and not r.samples and r.action is None and e.record()==record

def test_chess_perft_and_special_rules():
 b=chess.Board()
 def perft(d):
  if not d:return 1
  n=0
  for move in list(b.legal_moves):b.push(move);n+=perft(d-1);b.pop()
  return n
 assert perft(1)==20 and perft(2)==400 and perft(3)==8902
 castle=chess.Board('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');assert castle.parse_uci('e1g1') in castle.legal_moves
 ep=chess.Board('7k/8/8/3pP3/8/8/8/K7 w - d6 0 1');assert ep.is_en_passant(ep.parse_uci('e5d6'))
 promo=chess.Board('7k/P7/8/8/8/8/8/K7 w - - 0 1');assert len([m for m in promo.legal_moves if m.promotion])==4

def test_chess_actual_mate_stalemate_and_claim_history():
 e=ChessEnv(chess.Board('7k/6Q1/6K1/8/8/8/8/8 b - - 0 1'));assert e.terminal()==1
 e=ChessEnv(chess.Board('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1'));assert e.terminal()==0
 b=chess.Board()
 for u in ['g1f3','g8f6','f3g1','f6g8']*2:b.push_uci(u)
 assert ChessEnv(b).terminal()==0 and ChessEnv(chess.Board(b.fen())).terminal() is None

def test_no_mate_solver_search_dependency():
 e=ChessEnv(chess.Board('7k/8/5KQ1/8/8/8/8/8 w - - 0 1'));r=AlphaBeta(1,0).search(e,Model([1]*5))
 assert r.complete and r.value==1_000_000 and r.pv_terminal
 e.push(r.action);assert e.terminal()==1


def test_predicted_terminal_preserves_prior_eligibility_until_actual_outcome():
 m=Model([1,1]);td=TDLeaf(eta=.1,lam=.5)
 td.observe(m,receipt(value=1,phi=(0.,1.)))
 td.observe(m,receipt(value=1_000_000,phi=None,terminal=True))
 before=list(m.weights);elig=tuple(td.elig)
 assert td.previous==(1.,(0.,0.)) and elig[1]>0
 stats=td.finish(m,-1)
 assert stats['changed'] and m.weights[1]==pytest.approx(before[1]-.1*2*.5*elig[1])
 assert td.previous is None


def test_bound_tie_does_not_replace_true_better_root_action():
 # One min subtree may return its first equal cutoff BEFORE its losing child.
 for seed in range(100):
  t=Tree([[5,5],[5,-5]])
  r=AlphaBeta(2,0).search(t,Model([1,1]),seed=seed)
  assert r.value==5 and r.action==0 and r.pv_phi==(0.,5.)
