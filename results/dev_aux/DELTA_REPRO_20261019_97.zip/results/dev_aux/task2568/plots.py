"""All4initials training curves and actual finite W-L bounds, no bestseed."""
from pathlib import Path
import json,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path('results/dev_aux/task2568');METHODS=['TD','TC','WDL'];COLORS=['#555555','#2277aa','#d97800'];SEEDS=[1977,8173,27182,31415];STYLES=['-','--',':','-.']
def training():
 t=json.loads((D/'result.json').read_text());games=list(map(json.loads,(D/'games.jsonl').open()));signals=json.loads((D/'signals.json').read_text());fig,axs=plt.subplots(2,3,figsize=(13,7),constrained_layout=True)
 for j,ax in enumerate(axs.flat):
  if j==5:ax.axis('off');ax.text(0,.95,'ALL 4 initializations\n1977 solid / 8173 dashed\n27182 dotted / 31415 dash-dot\nPawn fixed at 1; D2 / no qsearch\nNo human material priors\nTC fixed lambda, not full replica\nWDL positive-only proposal domain\nTD/TC signed finite domain',va='top',fontsize=10);continue
  for a in t['arms']:
   key=[a['seed'],a['method']];s=[x for x in signals if x['key']==key];x=[0]+[x['nodes']/1000 for x in s];y=[a['initial'][j]]+[x['weights'][j]for x in s];ax.step(x,y,where='post',color=COLORS[METHODS.index(a['method'])],ls=STYLES[SEEDS.index(a['seed'])],lw=1,alpha=.8)
  ax.set(title=['Pawn','Knight','Bishop','Rook','Queen'][j],xlabel='Both-actor TRAIN search nodes (thousands)',ylabel='Raw coefficient');ax.grid(alpha=.2)
 for m,c in zip(METHODS,COLORS):axs.flat[0].plot([],[],color=c,label=m)
 axs.flat[0].legend(fontsize=8);fig.suptitle('Chess97: all seeded trajectories; weights are not a convergence or strength test');fig.savefig(D/'weights.png',dpi=140);plt.close(fig)
 fig,axs=plt.subplots(1,3,figsize=(14,4),constrained_layout=True)
 for a in t['arms']:
  method=a['method'];s=[x for x in signals if x['key']==[a['seed'],method]];x=np.array([x['nodes']for x in s])/1000;c=COLORS[METHODS.index(method)];ls=STYLES[SEEDS.index(a['seed'])]
  if method!='WDL':axs[0].plot(x,[x['loss']for x in s],color=c,ls=ls,alpha=.65)
  axs[1].plot(x,np.cumsum([x['terms']for x in s]),color=c,ls=ls,alpha=.65)
  if method=='TC':
   for j in range(1,5):axs[2].plot(x,[x['tc_rates'][j]for x in s],color=c,ls=ls,alpha=.3,lw=.7)
 axs[0].set(title='TD residual on changing training data',ylabel='Mean half squared residual');axs[0].set_ylim(bottom=0);axs[1].set(title='Completed TD terms, not independent labels',ylabel='Cumulative terms');axs[2].set(title='TC old coordinate rates (all free channels)',ylabel='Raw coherence rate');axs[2].set_ylim(-.02,1.02)
 for m,c in zip(METHODS,COLORS):axs[1].plot([],[],color=c,label=m)
 axs[1].legend(fontsize=8)
 for ax in axs:ax.set_xlabel('Both-actor TRAIN search nodes (thousands)');ax.grid(alpha=.2)
 fig.savefig(D/'signals.png',dpi=140);plt.close(fig)
def strength():
 base=json.loads((D/'summary.json').read_text());extra=json.loads(Path('results/dev_aux/task2570/summary.json').read_text())
 fig,axs=plt.subplots(2,2,figsize=(14,9),constrained_layout=True)
 keys=['TD-initial','TC-initial','WDL-initial','TC-TD','TD-WDL','TC-WDL']
 for ax,foe in zip(axs.flat,['uniform','random99031','uniform_nonpawn2','lograndom65537']):
  r=base if foe in ['uniform','random99031']else extra
  for i,key in enumerate(keys):
   lo,hi=r['contrasts'][key]['by_foe'][foe]['bounds'];ax.vlines(i,lo,hi,color='black',lw=3);ax.scatter([i,i],[lo,hi],color='black',marker='_')
   for j,seed in enumerate(SEEDS):
    l,h=r['contrasts'][key]['by_seed'][str(seed)][foe]['bounds'];xx=i+(j-1.5)*.12;ax.vlines(xx,l,h,alpha=.35,lw=1,color=COLORS[i%3]);ax.scatter([xx,xx],[l,h],alpha=.55,s=14,color=COLORS[i%3])
  ax.axhline(0,color='gray',ls='--');ax.set_xticks(range(len(keys)),keys,rotation=30,ha='right');ax.set(title=foe,ylabel='Actual paired W-L difference');ax.grid(axis='y',alpha=.2)
 fig.suptitle('Chess97 finite panels: black aggregate; all4seeds left-to-right1977/8173/27182/31415' + chr(10) + 'UNKNOWN/missing bounds, not CIs; ALL fixed endpoints, no bestseed selection');fig.savefig(D/'strength.png',dpi=140);plt.close(fig)

if __name__=='__main__':globals()[sys.argv[1]]()
