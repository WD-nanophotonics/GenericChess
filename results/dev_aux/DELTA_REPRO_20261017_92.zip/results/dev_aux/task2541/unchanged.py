"""Natural negative control: a genuinely unchanged price model must deploy identically."""
from pathlib import Path
import json,time
D=Path('results/dev_aux/task2539');E=Path('results/dev_aux/task2540');O=Path('results/dev_aux/task2541')
def run():
 began=time.perf_counter();t=json.loads((D/'result.json').read_text());p=json.loads((E/'plan.json').read_text());index={tuple(r['slot']):r for r in map(json.loads,(E/'games.jsonl').read_text().splitlines())};failed={k for k,r in index.items()if r['ending']=='GLOBAL_CAP_UNKNOWN'}
 for line in(E/'queries.jsonl').open():
  q=json.loads(line)
  if not q['complete']:failed.add(tuple(q['slot']))
 rows=[]
 for a in t['arms']:
  if a['weights']!=a['initial']:continue
  count=equal=resource_unknown=missing=0
  for f in p['families']:
   for c in(0,1):
    for foe in p['opponents']:
     key=(a['generator_seed'],a['seed'],f,c,a['method'],foe);base=key[:4]+('initial',foe);x=index.get(key);y=index.get(base)
     if x is None or y is None:missing+=1;continue
     assert x['weights']==y['weights']==a['initial']and x['initial_record']==y['initial_record'];count+=1
     if key not in failed and base not in failed:assert x['record']==y['record']and x['reward']==y['reward'];equal+=1
     else:assert x['outcome']is None or y['outcome']is None;resource_unknown+=1
  rows.append(dict(rule=a['generator_seed'],method=a['method'],seed=a['seed'],paired=count,exact_full_records_and_reward=equal,resource_unknown=resource_unknown,missing=missing))
 out=dict(status='PASS_UNCHANGED_MODEL_NATURAL_NEGATIVE_CONTROL',arms=len(rows),rows=rows,pairs=sum(r['paired']for r in rows),identical=sum(r['exact_full_records_and_reward']for r in rows),resource_unknown=sum(r['resource_unknown']for r in rows),missing=sum(r['missing']for r in rows),seconds=time.perf_counter()-began,scope='SelectedONLYbyexactparameteridentity, notgood/badfitness. Samefrozenroot/role/foe/searchseed andcompletequeriesmustgiveidenticalactualfullrecords/reward; genuinequeryresourcefailuresremainunknown. Thisisnegativecontrol/notnewgames/strengthselection.')
 (O/'unchanged.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
if __name__=='__main__':run()
