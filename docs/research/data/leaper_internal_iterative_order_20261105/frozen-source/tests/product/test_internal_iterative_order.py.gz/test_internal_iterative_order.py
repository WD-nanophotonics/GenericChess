"""Shared-budget internal shallow ordering: value, context and abort contracts."""
from dataclasses import replace
import pytest
from scripts import leaper_design as L
from generic_chess.ai.alphabeta import search
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession


def fixture():
    c=L.compile_rule(L.definition(1,2));return c,GameSession(c)


def limits(depth=4,nodes=200000):
    return SearchLimits(max_depth=depth,max_nodes=nodes,max_time_seconds=10,quiescence_max_depth=0)


def player(c,on):
    return AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,
                           tuning=SearchTuning(use_pvs=True,use_internal_iterative_order=on))


def test_default_off_and_exact_fixeddepth_score_parity_with_actual_seed_work(monkeypatch):
    c,s=fixture();before=s.to_record()
    # Controlled TT-miss contract fixture guarantees eligibility; not fitness.
    monkeypatch.setattr(TranspositionTable,'probe',lambda *args:None)
    off=player(c,False).choose_action(s,limits())
    on=player(c,True).choose_action(s,limits())
    assert off.completed_depth==on.completed_depth==4 and off.score==on.score
    assert off.iid_attempts==off.iid_completed==off.iid_budget_events==0
    assert on.iid_attempts==on.iid_completed>0 and on.iid_hints>0
    assert on.iid_budget_events>0 and on.iid_budget_events<=on.nodes+on.qnodes
    assert on.runtime_depth_balanced and s.to_record()==before
    replay=GameSession.replay(c,before)
    for a in on.principal_variation:replay.submit(a)


def test_seed_never_runs_at_root_or_recursively_and_discards_its_score(monkeypatch):
    c,s=fixture();monkeypatch.setattr(TranspositionTable,'probe',lambda *args:None)
    original=search.negamax;seeds=[];contexts=[]
    def wrapped(state,depth,alpha,beta,ply,ctx,*args,**kwargs):
        if not contexts or contexts[-1] is not ctx:contexts.append(ctx)
        if ctx._iid_active:
            seeds.append((ply,depth,ctx.stats.iid_attempts))
            attempts=ctx.stats.iid_attempts
            result=original(state,depth,alpha,beta,ply,ctx,*args,**kwargs)
            assert ctx.stats.iid_attempts==attempts
            # Ordering-only must ignore even a clearly impossible seed value.
            return replace(result,score=123456789)
        return original(state,depth,alpha,beta,ply,ctx,*args,**kwargs)
    baseline=player(c,False).choose_action(s,limits())
    monkeypatch.setattr(search,'negamax',wrapped)
    got=player(c,True).choose_action(s,limits())
    assert got.completed_depth==4 and got.score==baseline.score
    assert seeds and all(ply>0 for ply,depth,attempt in seeds)
    assert all(not ctx._iid_active for ctx in contexts)


def test_cancel_during_shallow_work_balances_runtime_and_restores_guard(monkeypatch):
    c,s=fixture();before=s.to_record();token=CancellationToken();contexts=[]
    monkeypatch.setattr(TranspositionTable,'probe',lambda *args:None)
    original=search.negamax
    def wrapped(state,depth,alpha,beta,ply,ctx,*args,**kwargs):
        if ctx._iid_active:
            contexts.append(ctx);token.cancel()
        return original(state,depth,alpha,beta,ply,ctx,*args,**kwargs)
    monkeypatch.setattr(search,'negamax',wrapped)
    d=player(c,True).choose_action(s,limits(),cancel_token=token)
    assert d.termination_reason=='cancelled' and d.runtime_depth_balanced
    assert contexts and all(not ctx._iid_active for ctx in contexts)
    assert d.iid_attempts>d.iid_completed and d.iid_budget_events>0
    assert s.to_record()==before and d.action in s.legal_actions()


def test_shallow_budget_counts_toward_same_inclusive_limit(monkeypatch):
    c,s=fixture();before=s.to_record();monkeypatch.setattr(TranspositionTable,'probe',lambda *args:None)
    d=player(c,True).choose_action(s,limits(depth=64,nodes=160))
    assert d.nodes+d.qnodes<=160 and d.runtime_depth_balanced
    assert d.termination_reason=='node_limit' and s.to_record()==before
    assert d.iid_budget_events<=d.nodes+d.qnodes


def test_existing_tt_action_prevents_iid_on_that_node(monkeypatch):
    c,s=fixture();original=search.MoveOrderer.order;seen=[]
    def observe(self,state,actions,evaluator,depth,tt_move,previous,tuning,**kwargs):
        if tt_move is not None:assert tt_move in actions
        seen.append(tt_move)
        return original(self,state,actions,evaluator,depth,tt_move,previous,tuning,**kwargs)
    monkeypatch.setattr(search.MoveOrderer,'order',observe)
    d=player(c,True).choose_action(s,limits())
    assert d.completed_depth==4 and any(a is not None for a in seen)
    assert d.runtime_depth_balanced


def test_tt_and_ordering_are_required_for_candidate():
    c,s=fixture();on=SearchTuning(use_internal_iterative_order=True)
    with pytest.raises(ValueError):AlphaBetaPlayer(c,tuning=on,use_tt=False)
    with pytest.raises(ValueError):AlphaBetaPlayer(c,tuning=on,use_ordering=False)
