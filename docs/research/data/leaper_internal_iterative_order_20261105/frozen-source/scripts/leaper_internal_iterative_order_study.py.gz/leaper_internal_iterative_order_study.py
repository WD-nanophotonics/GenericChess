"""One frozen internal iterative ordering consumer on actual Player."""
from pathlib import Path
from datetime import datetime,timezone
import json,copy,gzip,hashlib,time
from scripts.leaper_pvs_quality_pilot import make_session,CallerDeadline,provider_metrics,metric_delta
from scripts.leaper_relative_history_pilot import memory_snapshot,native_identity
from scripts.research_record import record_value,write_record
from generic_chess.rules.schema import ruleset_from_dict,compute_fingerprint
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from tools.local_agent import session

def stamp():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def prepare(base):
 b=Path(base);assert not(b/'inputs.json').exists();source=Path('docs/research/data/leaper_bound_trials_20261031/q-bound-quality-20261031/inputs.json.gz');old=json.loads(gzip.decompress(source.read_bytes()))['rows'];template=old[0]['RuleSet']
 triples=[
 ([(1,0),(-1,0),(0,1)],[(1,1),(-1,-1),(0,2)],[(2,0),(-1,1),(0,-1)]),
 ([(0,1),(0,-1),(1,1)],[(1,0),(-1,0),(-1,2)],[(1,1),(-1,-1),(2,-1)]),
 ([(1,1),(-1,1),(0,-1)],[(1,0),(-1,0),(0,2)],[(2,1),(-1,-1),(0,-2)]),
 ([(1,0),(0,1),(0,-2)],[(1,1),(-1,1),(-1,-1)],[(2,0),(-2,1),(0,-1)]),
 ([(1,1),(-1,0),(0,1)],[(0,-1),(1,0),(-1,2)],[(2,1),(-1,-1),(0,-2)]),
 ([(1,0),(-1,1),(0,-1)],[(1,1),(0,2),(-1,-1)],[(2,0),(-2,0),(1,-1)]),
 ([(0,1),(-1,0),(1,-1)],[(1,1),(-1,1),(0,-2)],[(2,1),(-1,0),(0,-1)]),
 ([(1,1),(0,-1),(-1,0)],[(1,0),(-1,1),(0,2)],[(2,0),(-1,-1),(0,-2)])]
 homes=[[('K',0,0),('A',1,0),('B',0,1),('C',1,1)],
        [('K',0,1),('A',1,1),('B',0,2),('C',2,0)]]
 write_record(b/'literal-before-Core.json',dict(board=5,triples=triples,homes=homes,max_ply=64,repetition=4,source_template_sha256=sha(source),selection='ALL8fixednewmovementtriples/2homes beforeCore;nooutcomeadmission/filter/replacement;notpopulationholdout;primitiveleapsexposed'))
 signatures=[]
 for triple in triples:signatures.append(tuple(tuple(sorted(map(tuple,offsets))) for offsets in triple))
 assert len(set(signatures))==8
 for stage in ['root-gap-20261031','mtdf-feasibility-20261031','q-bound-quality-20261031']:
  prev=json.loads(gzip.decompress(Path('docs/research/data/leaper_bound_trials_20261031',stage,'inputs.json.gz').read_bytes()))['rows']
  for row in prev:
   sig=tuple(tuple(sorted(tuple(a['offset']) for a in typ['movement_atoms'])) for typ in row['RuleSet']['piece_types'][1:])
   assert sig not in signatures # actualmovementtriples,not metadata/layout novelty
 rows=[]
 for f,triple in enumerate(triples):
  for layout,home in enumerate(homes):
   r=copy.deepcopy(template);r.update(board_size=5,initial_position=[[None]*5 for _ in range(5)],max_ply=64,repetition_limit=4,metadata={})
   for typ,offsets in zip(r['piece_types'][1:],triple):typ['movement_atoms']=[dict(kind='leap',offset=list(o)) for o in offsets]
   for owner in (0,1):
    for typ,x,y in home:
     if owner:x,y=4-x,4-y
     assert r['initial_position'][y][x] is None
     r['initial_position'][y][x]=dict(owner=owner,base_type_id=typ,current_type_id=typ,promoted=False)
   fp=compute_fingerprint(ruleset_from_dict(r));rows.append(dict(id=f'iid-f{f}-h{layout}',family=f,layout=layout,RuleSet=r,fingerprint=fp,record=dict(schema_version=1,ruleset_fingerprint=fp,actions=[],resigned_by=None),prefix_length=0,exposure='newcomplete movementtriples DEVELOPMENT;primitiveexposure;nooutcomeselection/holdoutclaim'))
 assert len({r['fingerprint'] for r in rows})==16;write_record(b/'inputs.json',dict(rows=rows))

def run(base):
 b=Path(base);f=json.loads((b/'frozen.json').read_text());assert sha(__file__)==f['producer_sha256'] and sha(b/'qualified-inputs.json')==f['input_sha256']
 for p,h in f['sources'].items():assert sha(p)==h
 rows=json.loads((b/'qualified-inputs.json').read_text())['rows'];tick=time.perf_counter();returns=[];error=None
 try:
  for ri,row in enumerate(rows):
   c,s=make_session(row)
   for on in ((False,True) if ri%2==0 else (True,False)):
    if session.stopped():raise RuntimeError('userstop')
    if memory_snapshot().get('rss_bytes',0)>1610612736:raise RuntimeError('RSScap')
    if time.perf_counter()-tick+4>=120:raise RuntimeError('batchcap')
    if datetime.now(timezone.utc)>=datetime.fromisoformat(f['deadline_utc']):raise RuntimeError('engineeringdeadline')
    start=stamp();t=time.perf_counter();cpu=time.process_time();before=s.to_record()
    p=AlphaBetaPlayer(c,use_disk_cache=False,tuning=SearchTuning(use_pvs=True,use_internal_iterative_order=on),use_native_semantic_legality=True,use_native_semantic_availability=True,use_native_semantic_check=True);pm=provider_metrics(p);remaining=3-(time.perf_counter()-t);assert remaining>0 and pm['present']
    limits=SearchLimits(max_depth=64,max_nodes=2000000,max_time_seconds=remaining,quiescence_max_depth=4,quiescence_hard_max_depth=8);d=p.choose_action(s,limits,cancel_token=CallerDeadline(t+3));end=stamp();wall=time.perf_counter()-t
    r=dict(slot=len(returns),root=ri,on=on,started_at=start,ended_at=end,wall_seconds=wall,cpu_seconds=time.process_time()-cpu,record_before=record_value(before),decision=record_value(d),actual_limits=record_value(limits),actual_tuning=record_value(p._tuning),provider_delta=metric_delta(pm,provider_metrics(p)),timing_eligible=wall<=3.1)
    write_record(b/f'return-{len(returns):03}.json',r);returns.append(r)
    if start<end:session.record_work(start,end,'research',str(b/f'return-{len(returns)-1:03}.json'))
    assert before==s.to_record() and d.runtime_depth_balanced and d.native_legality_fallbacks==d.native_legality_operational_failures==0
    pv=type(s).replay(c,before)
    for a in d.principal_variation:pv.submit(a)
    assert d.action in s.legal_actions() if d.action is not None else d.choice_kind in ('DECLARATION','TERMINAL')
    assert d.iid_attempts>=d.iid_completed>=d.iid_hints and d.iid_budget_events<=d.nodes+d.qnodes
    print(json.dumps(dict(slot=r['slot'],root=ri,on=on,depth=d.completed_depth,attempts=d.iid_attempts,hints=d.iid_hints,seconds=wall)),flush=True)
 except Exception as e:error=type(e).__name__+':'+str(e)
 pairs=[]
 for ri,row in enumerate(rows):
  pair=[next((r for r in returns if r['root']==ri and r['on']==on),None) for on in (False,True)]
  if not all(pair):continue
  off,on=pair;changed=(off['decision']['action'],off['decision']['declaration'],off['decision']['choice_kind'])!=(on['decision']['action'],on['decision']['declaration'],on['decision']['choice_kind'])
  pairs.append(dict(root=ri,family=row['family'],layout=row['layout'],actual=on['decision']['iid_hints']>0,Q4=all(r['decision']['result_ordinary_qdepth']==4 for r in pair),changed=changed,timed=all(r['timing_eligible'] for r in pair)))
 stable=[family for family in range(8) if sum(p['family']==family and p['actual'] and p['Q4'] and p['changed'] and p['timed'] for p in pairs)==2]
 gate=len(returns)==32 and len(stable)>=2 and all(p['timed'] and p['Q4'] for p in pairs)
 summary=dict(status='PASS_ACTION_VARIATION_ONLY' if gate else 'STOP_GATE_FAILED',returns=len(returns),NOT_RUN=list(range(len(returns),32)),pairs=pairs,stable_two_layout_families=stable,error=error,seconds=time.perf_counter()-tick,default='OFF',games='NOT_STARTED;newprospectiveplanonlyifgatePASS',limits='stablemeansbothfixedlayouts,notrepeatedsameroottiming;actiondifferenceisnotquality/WDL')
 write_record(b/'summary.json',summary);print(json.dumps(summary));return summary
if __name__=='__main__':
 import sys
 (prepare if sys.argv[1]=='prepare' else run)(sys.argv[2])
