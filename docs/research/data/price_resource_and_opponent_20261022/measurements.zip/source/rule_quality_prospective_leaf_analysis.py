import sys,json,hashlib
from pathlib import Path
from fractions import Fraction
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-leaf-next');r=json.loads((D/'results.json').read_text());w=json.loads((D/'inputs.json').read_text())['worlds'];rows=[];stats={}
for world in range(12):
 for role in (0,1):
  a,b=[next(x for x in r['slots'] if x['world']==world and x['candidate_role']==role and x['leaf_order_arm']==arm)for arm in(0,1)]
  rows.append({'world':world,'role':role,'static':a['candidate_utility_interval'],'unit':b['candidate_utility_interval'],'effect':[b['candidate_utility_interval'][0]-a['candidate_utility_interval'][1],b['candidate_utility_interval'][1]-a['candidate_utility_interval'][0]],'same_outcome':a['candidate_utility_interval']==b['candidate_utility_interval']})
for arm,label in [(0,'Static'),(1,'UnitLeaf')]:
 games=[json.loads((D/x['receipt']).read_text())for x in r['slots']if x['leaf_order_arm']==arm];q=[q for g in games for q in g['queries']if q['policy']=='D1'];stats[label]={'outcomes':dict(Counter(str(g['candidate_utility_interval'])for g in games)),'terminal':dict(Counter(g['terminal']['status']for g in games)),'candidate_queries':len(q),'floor_queries':sum(len(g['queries'])for g in games)-len(q),'nodes':sum(x['decision']['nodes']for x in q),'paid_candidate_seconds':sum(x['seconds']for x in q),'max_candidate_seconds':max(x['seconds']for x in q),'sources':dict(Counter(x['decision']['result_source']for x in q)),'depths':dict(Counter(x['decision']['completed_depth']for x in q)),'ordinary_qdepths':dict(Counter(x['decision']['result_ordinary_qdepth']for x in q))}
res={'question':r['registration']['question'],'effect':[str(sum(Fraction(x['effect'][j])for x in rows)/24)for j in(0,1)],'pairs':rows,'cost':stats,'unique_rules':len({hashlib.sha256(json.dumps(x['rule'],sort_keys=True).encode()).hexdigest()for x in w}),'family_effects':[{'world':i,'config':w[i]['config'],'effect':[str(sum(Fraction(x['effect'][j])for x in rows if x['world']==i)/2)for j in(0,1)]}for i in range(12)],'scope':'12fresh fixedconfigurations;no generationfailures,no populationCI/no default. Unit candidate changes leafprices+promotiongain;ordering commonStatic;no qhorizonclaim.'}
write_record(D/'paired-analysis.json',res);print(json.dumps(res,indent=2))
