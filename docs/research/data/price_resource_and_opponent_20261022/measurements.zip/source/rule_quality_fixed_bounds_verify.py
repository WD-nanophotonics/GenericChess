import json,sys,itertools
from pathlib import Path
from fractions import Fraction
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-fixed-search';Q=P/'prospective-q1-fixed-search';r=json.loads((D/'results.json').read_text());q=json.loads((Q/'results.json').read_text());expected=json.loads((D/'paired-analysis.json').read_text());assert r['status']==q['status']=='CLOSED';allslots=r['slots']+q['slots'];names={'UnitD1-StaticSelf':lambda z:z['B']-z['A'],'StaticD2-StaticSelf':lambda z:z['C']-z['A'],'UnitD2-StaticSelf':lambda z:z['D']-z['A'],'leaf_D1_B-A':lambda z:z['B']-z['A'],'leaf_D2_D-C':lambda z:z['D']-z['C'],'resource_Static_C-A':lambda z:z['C']-z['A'],'resource_Unit_D-B':lambda z:z['D']-z['B'],'interaction_D-C-B+A':lambda z:z['D']-z['C']-z['B']+z['A'],'q1-q4_Static_C1-C':lambda z:z['C1']-z['C'],'q1-q4_Unit_D1-D':lambda z:z['D1']-z['D'],'leaf_q1_D1-C1':lambda z:z['D1']-z['C1']}
out={'method':'Separateenumerationofallbinaryendpointassignments perworld,explicitoppositeAselfroles;averageworldmin/max. Not new outcomes or samplingconfidence.','worlds':[],'vertices':0}
for world in range(12):
 slots=[x for x in allslots if x['world']==world];assert all(x['status']=='finished'for x in slots);keys=[(x['arm'],x['candidate_role'])for x in slots];ranges=[tuple(dict.fromkeys(x['candidate_utility_interval']))for x in slots];extrema={name:[None,None]for name in names};roleext={str(role):{name:[None,None]for name in names}for role in(0,1)};count=0
 for values in itertools.product(*ranges):
  z=dict(zip(keys,map(Fraction,values)));z['A',1]=-z['A',0];count+=1
  cells={label:(z[label,0]+z[label,1])/2 for label in('A','B','C','D','C1','D1')};assert cells['A']==0
  for name,formula in names.items():
   value=formula(cells);extrema[name]=[value if x is None else (min(x,value)if j==0 else max(x,value))for j,x in enumerate(extrema[name])]
   for role in(0,1):
    value=formula({label:z[label,role]for label in cells});roleext[str(role)][name]=[value if x is None else(min(x,value)if j==0 else max(x,value))for j,x in enumerate(roleext[str(role)][name])]
 assert {k:list(map(str,v))for k,v in extrema.items()}==expected['families'][world]['effects'];out['worlds'].append({'world':world,'vertices':count,'extrema':{k:list(map(str,v))for k,v in extrema.items()},'role_extrema':{role:{k:list(map(str,v))for k,v in data.items()}for role,data in roleext.items()}});out['vertices']+=count
out['effects']={name:[str(sum(Fraction(w['extrema'][name][j])for w in out['worlds'])/12)for j in(0,1)]for name in names};assert out['effects']==expected['effects']
for role in(0,1):assert {name:[str(sum(Fraction(w['role_extrema'][str(role)][name][j])for w in out['worlds'])/12)for j in(0,1)]for name in names}==expected['role_effects'][str(role)]
out['all_passed']=True;write_record(D/'bounds-qualified.json',out);print('BOUNDSQUAL',out['vertices'],len(names),'allaggregate/world/roleintervalsmatch')
