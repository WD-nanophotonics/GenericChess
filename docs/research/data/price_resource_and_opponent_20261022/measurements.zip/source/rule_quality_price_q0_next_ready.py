import json,sys,hashlib
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-price-q0-next');r=json.loads((D/'inputs.json').read_text());assert r['status']=='PREPARED_NOTRUN'and r['Player_queries']==r['fitness_games']==0 and not r['failures'];out={'question':'Are allfuturefreshpriceinputs readywithfulltypeprices andstrictinitialhistory before fitness?','status':'RUNNING','ready':[],'metadata_failures':[],'Player_queries':0,'input_sha256':hashlib.sha256((D/'inputs.json').read_bytes()).hexdigest()};write_record(D/'readiness.json',out)
for w in r['worlds']:
 try:
  c=compile_rule(ruleset_from_dict(w['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(w['initial_record'])));assert record_value(s.state)==w['initial_full_state'];assert len(s.legal_actions())==w['initial_legal_actions'];base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;board={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()};hand={t:0 if m.is_anchor or base.hand_value_by_base_type[t]==0 else 900 for t,m in c.support.type_metadata.items()};unit=replace(base,board_value_by_type=board,hand_value_by_base_type=hand,promotion_gain_by_type={t:0 for t in board},median_non_anchor_value=1000,piece_profiles={t:replace(p,normalized_board_value=board[t],normalized_hand_value=hand[t],promotion_option_value=0)for t,p in base.piece_profiles.items()});assert set(base.board_value_by_type)==set(board)==set(base.hand_value_by_base_type);path=D/f'profile-{w["index"]:02d}.json';write_record(path,{'static':record_value(base),'unit':record_value(unit)});out['ready'].append({'world':w['index'],'declared_type_count':len(board),'full_initial_state_passed':True,'strict_record_passed':True,'profile_file':path.name,'profile_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'future_types_retained':True,'opening_preference':w['config']['require_no_opening_win_in_one']})
 except Exception as e:out['metadata_failures'].append({'world':w['index'],'stage':'profile_or_initial_input_qualification','error':repr(e),'generation_not_relabelled_failure':True})
 write_record(D/'readiness.json',out)
out['status']='PREPARED_NOTRUN';write_record(D/'readiness.json',out);print('FUTUREREADY',len(out['ready']),len(out['metadata_failures']),out['Player_queries'])
