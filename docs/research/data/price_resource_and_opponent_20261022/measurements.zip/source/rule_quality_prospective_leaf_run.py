import json,sys,time,random,traceback,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from rule_quality_floor_policy import floor_action
D=P/'prospective-leaf-next';D.mkdir(exist_ok=True,parents=True)
from dataclasses import replace
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
class Adapter:
 def __init__(self,leaf,order):self.evaluate=leaf.evaluate;self.type_value=order.type_value;self.capture_order_value=order.capture_order_value
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.benchmark.runner import _timing_invalid
src=D/'inputs.json';inp=json.loads(src.read_text(encoding='utf-8'));worlds={w['index']:w for w in inp['worlds']};reg=json.loads((D/'registration.json').read_text(encoding='utf-8'));assert inp['status']=='PREPARED_NOTRUN' and inp['fitness_queries']==0 and len(worlds)==12
assert not(D/'results.json').exists()
execution={'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'registration_sha256':hashlib.sha256((D/'registration.json').read_bytes()).hexdigest(),'shuffle_seed':202610220502,'arms':{'0':'Staticleaf/Staticorder','1':'Unitleaf/Staticorder'},'fixed_before_fitness':True,'scope':'Fresh finite12-configuration check;not population inference/default activation;fulltypes/promotion/drop/aux/history andactualqreserve.'}
write_record(D/'execution-registration.json',execution)
slots=[{'slot':4*w+2*role+arm,'world':w,'candidate_role':role,'leaf_order_arm':arm,'status':'not_started','candidate_utility_interval':[-1,1]}for w in range(12)for role in(0,1)for arm in(0,1)];order=list(range(48));random.Random(execution['shuffle_seed']).shuffle(order)
out={'registration':reg,'execution_registration':execution,'slots':slots,'execution_order':order,'status':'RUNNING','candidate_queries':0,'floor_queries':0,'failures':[]};contexts={};tick=time.perf_counter();write_record(D/'results.json',out)
for ix in order:
 if time.perf_counter()-tick>=reg['whole_cap_seconds']:break
 slot=slots[ix];w=slot['world'];role=slot['candidate_role']
 if w not in worlds:slot['status']='generation_unavailable';continue
 t=time.perf_counter();raw=worlds[w]['rule'];rh=digest(raw)
 if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
 c=contexts[rh];s=GameSession(c);assert record_value(s.state)==worlds[w]['initial_full_state'];assert record_value(s.to_record())==worlds[w]['initial_record'];base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;board={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()};hand={t:0 if m.is_anchor or base.hand_value_by_base_type[t]==0 else 900 for t,m in c.support.type_metadata.items()};unit=replace(base,board_value_by_type=board,hand_value_by_base_type=hand,promotion_gain_by_type={t:0 for t in board},median_non_anchor_value=1000,piece_profiles={t:replace(p,normalized_board_value=board[t],normalized_hand_value=hand[t],promotion_option_value=0)for t,p in base.piece_profiles.items()});es=Evaluator(c,base,EvaluationConfig());eu=Evaluator(c,unit,EvaluationConfig());mixed=Adapter(es,es)if slot['leaf_order_arm']==0 else Adapter(eu,es);player=AlphaBetaPlayer(c,evaluator_override=mixed,use_disk_cache=False);seed=worlds[w]['config']['seed']*1009;rng={0:random.Random(seed),1:random.Random(seed+1)};row={**slot,'rule_sha256':rh,'initial_record':record_value(s.to_record()),'initial_state':record_value(s.state),'profiles':{'static':record_value(base),'unit':record_value(unit),'dynamics':record_value(EvaluationConfig())},'queries':[],'failure':None,'censor':None};path=D/f'game-{ix:03d}.json';write_record(path,row)
 try:
  while not s.state.terminal_status.is_terminal and s.state.ply_count<reg['caller_plies']:
   if time.perf_counter()-tick>=reg['whole_cap_seconds']:row['censor']='whole_cap';break
   actor=s.state.position.side_to_move;row['current_record']=record_value(s.to_record());write_record(path,row);qstart=time.perf_counter()
   if actor==role:
    dec=player.choose_action(s,SearchLimits(**reg['limits']));elapsed=time.perf_counter()-qstart;action=dec.action;receipt={'root_ply':s.state.ply_count,'actor':actor,'policy':'D1','decision':record_value(dec),'seconds':elapsed};out['candidate_queries']+=1
   else:
    action,detail=floor_action(s,rng[actor],reg['limits']['max_time_seconds']);elapsed=time.perf_counter()-qstart;receipt={'root_ply':s.state.ply_count,'actor':actor,'policy':'FLOOR','action':record_value(action),'floor':detail,'seconds':elapsed};out['floor_queries']+=1
   row['queries'].append(receipt);write_record(path,row)
   if _timing_invalid(elapsed,reg['limits']['max_time_seconds']):row['censor']='timing_invalid';break
   if action is None:row['censor']='incomplete_floor_or_candidate_no_action';break
   s.submit(action)
 except Exception as e:row['failure']={'error':repr(e),'traceback':traceback.format_exc()};out['failures'].append({'slot':ix,**row['failure']})
 row.update(final_record=record_value(s.to_record()),final_state=record_value(s.state),terminal=record_value(s.result),seconds=time.perf_counter()-t);row.pop('current_record',None);fallback=any(q['policy']=='D1'and(q['decision']['result_source']in('fallback','legal_fallback','root_scan_fallback')or q['decision']['termination_reason']=='fallback')for q in row['queries']);operational=any(q['policy']=='D1'and q['decision']['native_legality_operational_failures']for q in row['queries']);row['eligible']=not(row['failure']or row['censor']or fallback or operational);row['fallback']=fallback;row['operational_failure']=operational;value=None if not row['eligible']or row['terminal']['status']in('ongoing','no_contest')else 0 if row['terminal']['winner']is None else 1 if row['terminal']['winner']==role else-1;row['candidate_utility_interval']=[value,value]if value is not None else[-1,1];row['status']='finished';write_record(path,row);slot.update(status='finished',receipt=path.name,terminal=row['terminal'],candidate_utility_interval=row['candidate_utility_interval'],eligible=row['eligible'],plies=s.state.ply_count,seconds=row['seconds']);write_record(D/'results.json',out);print('COMPETENCE',ix,w,role,row['terminal'],row['candidate_utility_interval'],s.state.ply_count,round(time.perf_counter()-tick,1),flush=True)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;out['unattempted_slots']=[x['slot']for x in slots if x['status']=='not_started'];write_record(D/'results.json',out);print('CLOSED',out['candidate_queries'],out['floor_queries'],len(out['unattempted_slots']),round(out['seconds'],1),flush=True)
