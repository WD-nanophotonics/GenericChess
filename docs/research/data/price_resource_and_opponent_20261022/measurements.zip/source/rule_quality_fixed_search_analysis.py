import json,sys,hashlib
from pathlib import Path
from fractions import Fraction
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-fixed-search';Q=P/'prospective-q1-fixed-search'
r=json.loads((D/'results.json').read_text());assert r['status']=='CLOSED'
cells={};variables={};cost={};sources={}
for x in r['slots']:
 key=(x['arm'],x['world'],x['candidate_role']);variables[key]=x['candidate_utility_interval'];cells[key]=(key,1)
 if x['arm']=='A':cells['A',x['world'],1]=(key,-1)
if (Q/'results.json').exists():
 qr=json.loads((Q/'results.json').read_text());assert qr['status']=='CLOSED'
 for x in qr['slots']:
  key=(x['arm'],x['world'],x['candidate_role']);variables[key]=x['candidate_utility_interval'];cells[key]=(key,1)
else:qr=None
contrasts={'UnitD1-StaticSelf':{'B':1,'A':-1},'StaticD2-StaticSelf':{'C':1,'A':-1},'UnitD2-StaticSelf':{'D':1,'A':-1},'leaf_D1_B-A':{'B':1,'A':-1},'leaf_D2_D-C':{'D':1,'C':-1},'resource_Static_C-A':{'C':1,'A':-1},'resource_Unit_D-B':{'D':1,'B':-1},'interaction_D-C-B+A':{'D':1,'C':-1,'B':-1,'A':1}}
if qr:contrasts.update({'q1-q4_Static_C1-C':{'C1':1,'C':-1},'q1-q4_Unit_D1-D':{'D1':1,'D':-1},'leaf_q1_D1-C1':{'D1':1,'C1':-1}})
def bound(weights,worlds,roles):
 coeff={}
 for w in worlds:
  for role in roles:
   for label,scale in weights.items():
    var,sign=cells[label,w,role];coeff[var]=coeff.get(var,0)+Fraction(scale*sign,len(worlds)*len(roles))
 endpoints=[]
 for end in(0,1):endpoints.append(sum(scale*Fraction(variables[var][end if scale>0 else 1-end])for var,scale in coeff.items()))
 return list(map(str,endpoints))
out={'question':'Are priceandqresource effects stableagainstfixedStaticsearch ratherthanFLOOR?','scope':'Finitecensoringbounds over12configurationintentionblocks;allmissing/UNKNOWN retained. ExactAselfutilitycoupled acrossroles;otherpolicy tailsindependent. No samplingCI/SPRT/default claim.','effects':{k:bound(v,range(12),(0,1))for k,v in contrasts.items()},'families':[{'world':w,'effects':{k:bound(v,[w],(0,1))for k,v in contrasts.items()}}for w in range(12)],'role_effects':{str(role):{k:bound(v,range(12),(role,))for k,v in contrasts.items()}for role in(0,1)},'cost':{},'closed_producers':[str(D)] if not qr else[str(D),str(Q)],'missing_slots':{str(D):r['unattempted_slots']}}
for directory,rr in [(D,r)]+([(Q,qr)]if qr else[]):
 for label in rr['registration']['arms']:
  ss=[x for x in rr['slots']if x['arm']==label];gs=[json.loads((directory/x['receipt']).read_text())for x in ss if x['status']=='finished'];qs=[q for g in gs for q in g['queries']];candidate=[q for q in qs if q['candidate']];opponent=[q for q in qs if not q['candidate']];out['cost'][label]={'planned_physical_games':len(ss),'finished':len(gs),'eligible':sum(g['eligible']for g in gs),'outcomes':dict(Counter(str(g['candidate_utility_interval'])for g in gs)),'opponent_immediate_win_after_candidate':sum(any(q['candidate'] and j+1<len(g['queries']) and not g['queries'][j+1]['candidate'] and g['queries'][j+1]['decision']['result_source']=='root_immediate_win' for j,q in enumerate(g['queries']))for g in gs),'candidate_queries':len(candidate),'opponent_queries':len(opponent),'main_nodes':sum(q['decision']['nodes']for q in candidate),'qnodes':sum(q['decision']['qnodes']for q in candidate),'paid_candidate_seconds':sum(q['seconds']for q in candidate),'paid_opponent_seconds':sum(q['seconds']for q in opponent),'actual_depth_q_source':dict(Counter(str((q['requested_depth'],q['decision']['completed_depth'],q['decision']['result_ordinary_qdepth'],q['decision']['result_source']))for q in candidate)),'causes':dict(Counter(q['decision']['termination_reason']for q in candidate)),'actual_fallbacks':sum(g['fallback']for g in gs),'operational_failures':sum(g['operational_failure']for g in gs),'censors':dict(Counter(str(g['censor'])for g in gs))}
 out['missing_slots'][str(directory)]=rr['unattempted_slots']
write_record(D/'paired-analysis.json',out);print(json.dumps({'effects':out['effects'],'outcomes':{k:v['outcomes']for k,v in out['cost'].items()},'missing':out['missing_slots']},indent=2))
