import json,sys
from pathlib import Path
from fractions import Fraction
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-fixed-search';Q=P/'prospective-q1-fixed-search';r=json.loads((D/'results.json').read_text());q=json.loads((Q/'results.json').read_text());a=json.loads((D/'paired-analysis.json').read_text());f=json.loads((P/'prospective-leaf-next/paired-analysis.json').read_text());out={'question':'Which observedprice/search candidates lie on a finiteutility-paidcostfrontier,and do opponent effects reversewithinindividualrules?','scope':'PosthocaggregatefinitePareto usingpaidcandidatePlayerseconds/main+qnodes;not CI/Paretoproof forpopulation ornewrankingacrossdifferentopponents. Aselfrole1costusesoriginalopponentqueries,notduplicatecandidatecost. Clockconcurrency remains. No default/learnergate.','cells':{},'dominance':[],'family_opponent_interaction':[]}
for directory,raw in[(D,r),(Q,q)]:
 for label in raw['registration']['arms']:
  ss=[x for x in raw['slots']if x['arm']==label];assert all(x['status']=='finished'and x['eligible']for x in ss);gs=[json.loads((directory/x['receipt']).read_text())for x in ss];qs=[x for g in gs for x in g['queries']if label=='A'or x['candidate']];u=['0','0']if label=='A'else[str(sum(Fraction(x['candidate_utility_interval'][j])for x in ss)/24)for j in(0,1)];out['cells'][label]={'utility':u,'role_frames':24,'physical_games':len(gs),'candidate_role_queries':len(qs),'mean_paid_candidate_seconds_per_role':sum(x['seconds']for x in qs)/24,'mean_main_plus_qnodes_per_role':sum(x['decision']['nodes']+x['decision']['qnodes']for x in qs)/24,'mean_runtime_pushes_per_role':sum(x['decision']['runtime_pushes']for x in qs)/24}
for i,x in out['cells'].items():
 for j,y in out['cells'].items():
  if i==j:continue
  lo=Fraction(x['utility'][0])-Fraction(y['utility'][1]);hi=Fraction(x['utility'][1])-Fraction(y['utility'][0]);cost=x['mean_paid_candidate_seconds_per_role']<=y['mean_paid_candidate_seconds_per_role']and x['mean_main_plus_qnodes_per_role']<=y['mean_main_plus_qnodes_per_role']
  if lo>=0 and cost:out['dominance'].append({'candidate':i,'comparator':j,'utility_difference':[str(lo),str(hi)],'paid_cost_and_node_means_no_larger':True})
for w in range(12):
 fs=next(x for x in f['family_effects']if x['world']==w)['effect'];ss=a['families'][w]['effects']['leaf_D1_B-A'];contrast=[str(Fraction(ss[0])-Fraction(fs[1])),str(Fraction(ss[1])-Fraction(fs[0]))];out['family_opponent_interaction'].append({'world':w,'FLOOR_leaf_effect':fs,'fixedStaticD1_leaf_effect':ss,'search_minus_FLOOR':contrast})
write_record(D/'finite-cost-frontier-and-opponent-interaction.json',out);print('FRONTIER',out['dominance']);print('EXPOSEDOPPONENTREVERSALS',[x for x in out['family_opponent_interaction']if x['world']in(4,7)]);print('CELLUTILITYCOST',out['cells'])
