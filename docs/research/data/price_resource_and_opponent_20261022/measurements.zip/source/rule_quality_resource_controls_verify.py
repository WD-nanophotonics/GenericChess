import json,sys,time
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-leaf-next');worlds={w['index']:w for w in json.loads((D/'inputs.json').read_text())['worlds']};src=json.loads((D/'outcome-divergence-diagnosis.json').read_text());contexts={};out={'question':'Do all exhibited immediate-loss witnesses and resource-control choices preserve full actualhistory/PVs?','scope':'SeparateCoreliteralproof qualification;not scalarqsearch minimaxvalue,all-gameWDL or independentengine.','cases':[],'controls':[],'pv_plies':0};tick=time.perf_counter()
for case in src['cases']:
 w=case['world'];c=compile_rule(ruleset_from_dict(worlds[w]['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(case['common_record'])));assert record_value(s.state)==case['common_full_state'];contexts[w]=(c,s)
 for choice in case['choices']:
  _,ch=next((a,ch)for a,ch in legal_successors(s.state,c)if record_value(a)==choice['selected_action']);assert record_value(ch)==choice['full_after_choice'];actual=list(legal_successors(ch,c))if not ch.terminal_status.is_terminal else [];assert len(actual)==len(choice['opponent_replies']);wins=0
  for(a,g),saved in zip(actual,choice['opponent_replies']):
   assert record_value(a)==saved['action']and record_value(g.terminal_status)==saved['terminal']
   if g.terminal_status.winner==1-case['role']:assert record_value(g)==saved['full_child_state'];wins+=1
  assert wins==choice['opponent_immediate_wins'];out['cases'].append({'world':w,'arm':choice['arm'],'all_legal_replies':len(actual),'immediate_losses':wins,'fullCorewitness_passed':True})
for file,expected in [('outcome-divergence-depth-control.json',8),('outcome-divergence-q-resource-control.json',8),('outcome-divergence-node-control.json',16)]:
 r=json.loads((D/file).read_text());assert r['status']=='CLOSED'and len(r['rows'])==expected and not r['missing_queries']
 for row in r['rows']:
  c,s=contexts[row['world']];dec=row['decision'];assert dec['runtime_depth_balanced'];_,ch=next((a,ch)for a,ch in legal_successors(s.state,c)if record_value(a)==dec['action']);assert record_value(ch)==row['full_after_choice'];actual=[(a,g)for a,g in legal_successors(ch,c)if g.terminal_status.winner==1-s.state.position.side_to_move]if not ch.terminal_status.is_terminal else[];assert len(actual)==len(row['opponent_immediate_wins'])
  for(a,g),saved in zip(actual,row['opponent_immediate_wins']):assert record_value(a)==saved['action']and record_value(g)==saved['full_state']
  pv=s.state
  for raw in dec['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);out['pv_plies']+=1
  out['controls'].append({'file':file,'world':row['world'],'arm':row['arm'],'completed_depth':dec['completed_depth'],'main_nodes':dec['nodes'],'qnodes':dec['qnodes'],'total_nodes':dec['nodes']+dec['qnodes'],'immediate_losses':len(actual),'passed':True})
out['seconds']=time.perf_counter()-tick;out['all_passed']=True;write_record(D/'resource-controls-qualified.json',out);print('CONTROLQUAL',len(out['cases']),len(out['controls']),out['pv_plies'],out['seconds'])
