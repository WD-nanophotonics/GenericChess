import json,sys,hashlib,ast,re
from pathlib import Path
from fractions import Fraction
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-node-adjacent-rung';r=json.loads((D/'results.json').read_text());assert r['status']=='CLOSED'and not r['unattempted_slots'];rows=r['slots'];effect=[str(sum(Fraction(x['candidate_utility_interval'][j])for x in rows)/24)for j in(0,1)];out={'question':r['registration']['question'],'direct4096versus2048':effect,'outcomes':dict(Counter(str(x['candidate_utility_interval'])for x in rows)),'all24plannedslots':True,'families':[{'world':w,'effect':[str(sum(Fraction(x['candidate_utility_interval'][j])for x in rows if x['world']==w)/2)for j in(0,1)]}for w in range(12)],'physical_games':24,'queries':r['queries'],'producer_seconds':r['seconds'],'scope':'Actualdirectrung,notcommon-foedifference;finitecensoringbound,notCI/untruncatedminimaxpathology/optimalstrategytheorem;all12rules andUNKNOWN kept.'};write_record(D/'paired-analysis.json',out);print('ADJACENT',out)
