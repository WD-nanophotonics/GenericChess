import json,sys,itertools
from pathlib import Path
from fractions import Fraction
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-node-ladder';Q=P/'prospective-node-q0-control';r=json.loads((D/'results.json').read_text());q=json.loads((Q/'results.json').read_text());assert r['status']==q['status']=='CLOSED';cells={};variables={};groups={}
for directory,raw in[(D,r),(Q,q)]:
 for x in raw['slots']:
  key=(x['arm'],x['world'],x['candidate_role']);variables[key]=x['candidate_utility_interval'];cells[key]=(key,1)
  if x['arm']=='A':
   if x['status']=='finished'and x['eligible']:cells['A',x['world'],1]=(key,-1)
   else:var=('A_virtual_unverified',x['world'],1);variables[var]=[-1,1];cells['A',x['world'],1]=(var,1)
formulas={'N2-N1':{'B':1,'A':-1},'N4-N1':{'C':1,'A':-1},'N4-N2':{'C':1,'B':-1},'q0-q1_atN2':{'Q0':1,'B':-1},'q0N2-N1':{'Q0':1,'A':-1}}
def bound(cs,worlds):
 coeff={}
 for w in worlds:
  for role in(0,1):
   for arm,scale in cs.items():
    var,sign=cells[arm,w,role];coeff[var]=coeff.get(var,0)+Fraction(scale*sign,2*len(worlds))
 return [str(sum(scale*Fraction(variables[var][j if scale>0 else 1-j])for var,scale in coeff.items()))for j in(0,1)]
out={'question':r['registration']['question'],'scope':'Finiteallplanned12-configurationbounds;not populationCI orformaloptimalresourceladder. N=1024/2048/4096main+qvisits;semanticpreviewwork/wallreportedseparately. No deadline inqueries. Aselfcouplingonlyobservedeligiblephysicalgames;unattempted/invalidvirtualrolesindependentUNKNOWN.','effects':{k:bound(v,list(range(12)))for k,v in formulas.items()},'families':[{'world':w,'effects':{k:bound(v,[w])for k,v in formulas.items()}}for w in range(12)],'cost':{},'unattempted':{D.name:r['unattempted_slots'],Q.name:q['unattempted_slots']},'all_raw_failures':r['failures']+q['failures']}
for directory,raw in[(D,r),(Q,q)]:
 for arm in raw['registration']['arms']:
  ss=[x for x in raw['slots']if x['arm']==arm];gs=[json.loads((directory/x['receipt']).read_text())for x in ss if x['status']=='finished'];qs=[x for g in gs for x in g['queries']];candidate=[x for x in qs if x['candidate']];opponent=[x for x in qs if not x['candidate']];out['cost'][arm]={'physical_games':len(gs),'planned_physical_games':len(ss),'eligible':sum(g['eligible']for g in gs),'outcomes':dict(Counter(str(g['candidate_utility_interval'])for g in gs)),'terminal':dict(Counter(g['terminal']['status']for g in gs)),'candidate_queries':len(candidate),'opponent_queries':len(opponent),'paid_candidate_seconds':sum(x['seconds']for x in candidate),'paid_opponent_seconds':sum(x['seconds']for x in opponent),'producer_seconds':raw['seconds'],'main_nodes':sum(x['decision']['nodes']for x in candidate),'qnodes':sum(x['decision']['qnodes']for x in candidate),'runtime_pushes':sum(x['decision']['runtime_pushes']for x in candidate),'actual_sources':dict(Counter(str((x['decision']['completed_depth'],x['decision']['result_ordinary_qdepth'],x['decision']['result_source']))for x in candidate)),'control_causes':dict(Counter(x['decision']['termination_reason']for x in candidate)),'fallback_games':sum(g['fallback']for g in gs),'operational_failure_games':sum(g['operational_failure']for g in gs),'censor_causes':dict(Counter(str(g['censor'])for g in gs))}
# Independent per-world exhaustive endpoint assignment qualification.
vertices=0
for family in out['families']:
 w=family['world'];active={var for arm in ('A','B','C','Q0')for role in(0,1)for var,sign in[cells[arm,w,role]]};keys=list(active);observed={k:[None,None]for k in formulas}
 for values in itertools.product(*(tuple(dict.fromkeys(variables[k]))for k in keys)):
  vals=dict(zip(keys,map(Fraction,values)));vertices+=1;means={arm:sum(sign*vals[var]for role in(0,1)for var,sign in[cells[arm,w,role]])/2 for arm in('A','B','C','Q0')}
  for name,cs in formulas.items():
   v=sum(scale*means[arm]for arm,scale in cs.items());lo,hi=observed[name];observed[name]=[v if lo is None else min(lo,v),v if hi is None else max(hi,v)]
 assert {k:list(map(str,v))for k,v in observed.items()}==family['effects']
out['independent_endpoint_vertices_verified']=vertices;out['all_bounds_passed']=True;write_record(D/'paired-analysis.json',out);print(json.dumps({'effects':out['effects'],'outcomes':{k:v['outcomes']for k,v in out['cost'].items()},'missing':out['unattempted'],'verified_vertices':vertices},indent=2))
