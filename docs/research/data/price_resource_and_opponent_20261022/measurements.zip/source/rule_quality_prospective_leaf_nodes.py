import json,sys,time
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-leaf-next');source=json.loads((D/'outcome-divergence-diagnosis.json').read_text());worlds={w['index']:w for w in json.loads((D/'inputs.json').read_text())['worlds']};path=D/'outcome-divergence-node-control.json';assert not path.exists();out={'question':'At matched total-node budgets withoutclockpolling,when does D2 ordinaryq4 stop retaining the proven immediatelylosingStaticD1 action compared withq1?','scope':'Posthocworld4commonhistory;16coldplannedqueries at4nodebudgets with2leaves/2qdepths. Newfixed-nodecontrol,not repeatedtimingorwholegamefitness,notuntruncateddepthpathology. No defaultorpositionpatch.','registration':{'worlds':[4],'conditions':[(q,n)for n in(1024,4096,16384,65536)for q in(1,4)],'limits':{'max_nodes':8192,'max_time_seconds':None,'quiescence_max_depth':4,'quiescence_hard_max_depth':8},'whole_cap_seconds':240,'expected_seconds':100,'execution':'Nodecapboundedindividualquery,no deadline;checkwholecapbefore eachquery; retain anymissing,notrefill.'},'rows':[],'status':'RUNNING'};write_record(path,out);tick=time.perf_counter()
class Adapter:
 def __init__(self,leaf,order):self.evaluate=leaf.evaluate;self.type_value=order.type_value;self.capture_order_value=order.capture_order_value
for case in source['cases'][:1]:
 w=case['world'];c=compile_rule(ruleset_from_dict(worlds[w]['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(case['common_record'])));assert record_value(s.state)==case['common_full_state'];base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;board={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()};hand={t:0 if m.is_anchor or base.hand_value_by_base_type[t]==0 else 900 for t,m in c.support.type_metadata.items()};unit=replace(base,board_value_by_type=board,hand_value_by_base_type=hand,promotion_gain_by_type={t:0 for t in board},median_non_anchor_value=1000,piece_profiles={t:replace(p,normalized_board_value=board[t],normalized_hand_value=hand[t],promotion_option_value=0)for t,p in base.piece_profiles.items()});es=Evaluator(c,base,EvaluationConfig());eu=Evaluator(c,unit,EvaluationConfig())
 for leaf,qdepth,nodes in [(leaf,q,n)for q,n in out['registration']['conditions']for leaf in('Static','Unit')]:
  depth=2
  if time.perf_counter()-tick>=240:break
  player=AlphaBetaPlayer(c,evaluator_override=Adapter(es if leaf=='Static'else eu,es),use_disk_cache=False);t=time.perf_counter();limits={**out['registration']['limits'],'quiescence_max_depth':qdepth,'max_nodes':nodes};dec=player.choose_action(s,SearchLimits(max_depth=depth,**limits));row={'world':w,'arm':leaf+str(depth)+'q'+str(qdepth)+'N'+str(nodes),'limits':limits,'decision':record_value(dec),'seconds':time.perf_counter()-t};out['rows'].append(row);write_record(path,out)
  actor=s.state.position.side_to_move;a,ch=next((a,ch)for a,ch in legal_successors(s.state,c)if a==dec.action);replies=[]
  if not ch.terminal_status.is_terminal:
   for b,g in legal_successors(ch,c):
    if g.terminal_status.winner==1-actor:replies.append({'action':record_value(b),'terminal':record_value(g.terminal_status),'full_state':record_value(g)})
  pv=s.state
  for raw in record_value(dec)['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw)
  row.update(full_after_choice=record_value(ch),opponent_immediate_wins=replies,literal_pv_verified=True);write_record(path,out);print(w,leaf,depth,qdepth,nodes,dec.completed_depth,dec.nodes+dec.qnodes,len(replies),dec.termination_reason,flush=True)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;out['missing_queries']=16-len(out['rows']);write_record(path,out)
