import json,sys
from pathlib import Path
from fractions import Fraction
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
from generic_chess.rules.schema import ruleset_from_dict
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-node-ladder';Q=P/'prospective-node-q0-control';worlds={w['index']:w for w in json.loads((P/'prospective-leaf-next/inputs.json').read_text())['worlds']};out={'question':'Does observed-prefix cost dominance imply fullcontinued-game cost dominance when someoutcomes areUNKNOWN?','scope':'No newmoves/search/capextension. Conservativeanalyticupperbound onCOUNTEDmain+qvisits only,notwalltime/primitivework. Forongoinggamesatmost max_ply-currentply remainingcandidatecalls,evenwithoutassumingalternation. Currentrules havefinite512clock andnoautomaticpending/custom/declaration/reset actions. RawUNKNOWNunchanged.','cells':{},'pairs':[]}
for directory in(D,Q):
 raw=json.loads((directory/'results.json').read_text());assert raw['status']=='CLOSED'and not raw['unattempted_slots']
 for arm,config in raw['registration']['arms'].items():
  ss=[x for x in raw['slots']if x['arm']==arm];lo=0;hi=0;unknown=0;gamebounds=[]
  for slot in ss:
   g=json.loads((directory/slot['receipt']).read_text());assert g['eligible'];rule=ruleset_from_dict(worlds[slot['world']]['rule']);assert rule.max_ply==512 and not rule.automatic_adjudications and not rule.declarations and not rule.semantic_actions and not rule.consecutive_action_adjudications
   qs=[x for x in g['queries']if arm=='A'or x['candidate']];observed=sum(x['decision']['nodes']+x['decision']['qnodes']for x in qs);ongoing=g['terminal']['status']=='ongoing';remaining=max(0,rule.max_ply-g['final_state']['ply_count'])if ongoing else 0;extra=remaining*config['nodes'];lo+=observed;hi+=observed+extra;unknown+=ongoing;gamebounds.append({'slot':slot['slot'],'ongoing':ongoing,'observed_nodes':observed,'remaining_rule_plies':remaining,'additional_counted_node_upper':extra})
  # Aselfincludesbothactors,which togethermakeatmostremainingtrueplies calls;
  # otherarms includeonlycandidate anduseconservativeallremainingcallbound.
  out['cells'][arm]={'observed_candidate_role_frames':24,'physical_games':len(ss),'ongoing_physical_games':unknown,'mean_counted_nodes_fullcontinuation_interval':[str(Fraction(lo,24)),str(Fraction(hi,24))],'pergamebounds':gamebounds}
for i,j in [('Q0','B'),('Q0','C'),('C','B')]:
 a=out['cells'][i]['mean_counted_nodes_fullcontinuation_interval'];b=out['cells'][j]['mean_counted_nodes_fullcontinuation_interval'];out['pairs'].append({'candidate':i,'comparator':j,'fullcontinuation_countednode_cost_difference':[str(Fraction(a[0])-Fraction(b[1])),str(Fraction(a[1])-Fraction(b[0]))]})
out['conclusion']='Q0costadvantage isobserved96-prefix,not proven lowerfullcontinued-gamecost;utilityUNKNOWN andresourcecensoring bothkept. Thisdoesnotauthorizeexecuting beyond96orrequireexactWDL.';write_record(D/'continuation-cost-bounds.json',out);print('FULLCOUNTEDNODEBOUNDS',{k:v['mean_counted_nodes_fullcontinuation_interval']for k,v in out['cells'].items()});print('COSTDIFF',out['pairs'])

