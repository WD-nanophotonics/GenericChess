import time
from generic_chess.core.transition import legal_successors
def floor_action(s,rng,seconds=1.0):
 tick=time.perf_counter();legal=[];actor=s.state.position.side_to_move;winner=None;complete=True
 for a,ch in legal_successors(s.state,s.compiled):
  legal.append(a)
  if time.perf_counter()-tick>=seconds:complete=False;break
  if ch.terminal_status.winner==actor:winner=a;break
 action=winner if winner is not None else legal[rng.randrange(len(legal))]if complete and legal else None
 return action,{'winning_action_found':winner is not None,'enumerated_children':len(legal),'complete_or_winning':complete,'seconds':time.perf_counter()-tick}
