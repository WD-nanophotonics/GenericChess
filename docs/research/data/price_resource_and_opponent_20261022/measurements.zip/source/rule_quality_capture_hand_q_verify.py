import json,sys,time
from pathlib import Path
from dataclasses import fields
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-leaf-next');r=json.loads((D/'capture-hand-q-cost-control.json').read_text());source=json.loads((D/'outcome-divergence-node-control.json').read_text());assert r['status']=='CLOSED'and not r['missing_cells'];out={'rows':[],'pv_plies':0,'new_queries':0,'exact_reuses':0,'scope':'FullCoreaction/history/PV andonefield intervention qualification;notindependentscalarqvalue/WDL orisolatedhardwaretiming. Handzeroaltersleafonly,realstockretained.'};tick=time.perf_counter();states={};rules={}
for row in r['rows']:
 mode=row['mode'];rules[mode]=row['rule'];c=compile_rule(ruleset_from_dict(row['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(row['record'])));assert record_value(s.state)==row['full_state'];states[mode]=s.state;dec=row['decision'];assert dec['runtime_depth_balanced'];_,child=next((a,ch)for a,ch in legal_successors(s.state,c)if record_value(a)==dec['action']);pv=s.state
 for raw in dec['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);out['pv_plies']+=1
 assert row['profile']['board_value_by_type']==row['ordering_profile']['board_value_by_type'];assert row['profile']['promotion_gain_by_type']==row['ordering_profile']['promotion_gain_by_type']
 if row['hand_profile']=='zero':assert not any(row['profile']['hand_value_by_base_type'].values())
 else:assert row['profile']==row['ordering_profile']
 if row['reused']:
  old=next(x for x in source['rows']if x['arm']==f"Static2q{row['qdepth']}N65536");assert old['decision']==dec and old['seconds']==row['seconds'];out['exact_reuses']+=1
 else:out['new_queries']+=1
 out['rows'].append({'mode':mode,'hand_profile':row['hand_profile'],'qdepth':row['qdepth'],'completed_depth':dec['completed_depth'],'total_nodes':dec['nodes']+dec['qnodes'],'runtime_pushes':dec['runtime_pushes'],'selected_action':dec['action'],'reused':row['reused'],'passed':True})
assert {k:v for k,v in rules['pocket'].items()if k!='capture_disposition'}=={k:v for k,v in rules['remove'].items()if k!='capture_disposition'};diff=[f.name for f in fields(states['pocket'].position)if getattr(states['pocket'].position,f.name)!=getattr(states['remove'].position,f.name)];assert set(diff)=={'hands','ruleset_fingerprint'}
for q in(1,4):
 a,b=[next(x for x in r['rows']if x['mode']=='remove'and x['hand_profile']==h and x['qdepth']==q)['decision']for h in('full','zero')]
 for key in ['action','score','principal_variation','completed_depth','nodes','qnodes','runtime_pushes','runtime_pops','legal_generation_calls','evaluation_calls']:assert a[key]==b[key]
out['position_difference_fields']=diff;out['emptyhand_negative_controls_passed']=True;out['all_passed']=True;out['seconds']=time.perf_counter()-tick;write_record(D/'capture-hand-q-cost-qualified.json',out);print('CAPTURECOSTQUAL',len(out['rows']),out['new_queries'],out['exact_reuses'],out['pv_plies'],out['seconds'])
