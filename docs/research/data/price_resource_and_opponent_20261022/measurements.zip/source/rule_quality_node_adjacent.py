import json,sys,time,traceback,hashlib,random
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.benchmark.runner import _timing_invalid
P=Path('.local_agent/rule-quality-prefix-next-20261022');I=P/'prospective-leaf-next/inputs.json';D=P/'prospective-node-adjacent-rung';D.mkdir(exist_ok=True)
class Adapter:
 def __init__(self,leaf,order):self.evaluate=leaf.evaluate;self.type_value=order.type_value;self.capture_order_value=order.capture_order_value
reg={'question':'Does4096q1 beat2048q1 directly,ratherthanjust havinghigherutilityagainstcommon1024opponent?','changed_premise':'Commonfoecurve:2048-1024[1/3,7/12],4096-1024[1/2,3/4],difference[-1/12,5/12]. ThatdifferenceisNOTdirect4096vs2048,so cannot establishnextresourcerung. Thisdirectmatch is the neededmissingcomparison,not repeatedfrozenfitness.','input_sha256':hashlib.sha256(I.read_bytes()).hexdigest(),'all_configurations':list(range(12)),'arms':{'C42':{'leaf':'static','depth':64,'nodes':4096}},'opponent':'FixedStaticleaf/Staticordering,Node2048,maxdepth64,q1hard8,nodeonly/no deadline;eachownTTfreshpergame,persistswithin,diskOFF.','limits':{'max_nodes':2048,'max_time_seconds':None,'quiescence_max_depth':1,'quiescence_hard_max_depth':8},'caller_plies':96,'whole_cap_seconds':1800,'expected_seconds':1200,'planned_role_slots':24,'physical_games':24,'exact_reuse':'None;all24plannedrolesonall12inputs,no replacement. Previouscommonfoeoutcomeskeptdistinct.','comparison':'Directcandidate4096balancedutilityin[-1,1];positivefinitebound supports thisrung here,zero-crossing staysinconclusive,negativewouldrejectmonotonicityhere. NoSPRT/Elo/population oroptimalstrategyladderclaim.','shuffle_seed':202610220600,'scope':'Exposedrosterdevelopment;fullsemantics/history. AllUNKNOWN/fallbacks/failures/unattempted retained. Nopricefit/default/AUXwork/newworker. 1800swholecap notextended.'}
assert not(D/'results.json').exists();write_record(D/'registration.json',reg)
worlds={w['index']:w for w in json.loads(I.read_text())['worlds']};slots=[{'slot':len([]),'world':w,'arm':arm,'candidate_role':role,'status':'not_started','candidate_utility_interval':[-1,1]}for w in range(12)for arm in('C42',)for role in(0,1)]
for ix,x in enumerate(slots):x['slot']=ix
order=list(range(len(slots)));random.Random(reg['shuffle_seed']).shuffle(order);out={'registration':reg,'slots':slots,'execution_order':order,'status':'RUNNING','queries':0,'failures':[]};write_record(D/'results.json',out);tick=time.perf_counter();contexts={}
for ix in order:
 if time.perf_counter()-tick>=reg['whole_cap_seconds']:break
 slot=slots[ix];w=slot['world'];role=slot['candidate_role'];t=time.perf_counter();raw=worlds[w]['rule'];rh=hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest()
 try:
  if w not in contexts:
   c=compile_rule(ruleset_from_dict(raw));base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;board={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()};hand={t:0 if m.is_anchor or base.hand_value_by_base_type[t]==0 else 900 for t,m in c.support.type_metadata.items()};unit=replace(base,board_value_by_type=board,hand_value_by_base_type=hand,promotion_gain_by_type={t:0 for t in board},median_non_anchor_value=1000,piece_profiles={t:replace(p,normalized_board_value=board[t],normalized_hand_value=hand[t],promotion_option_value=0)for t,p in base.piece_profiles.items()});contexts[w]=(c,base,unit);write_record(D/f'profile-{w:02d}.json',{'rule':raw,'static':record_value(base),'unit':record_value(unit),'dynamics':record_value(EvaluationConfig())})
  c,base,unit=contexts[w];s=GameSession(c);assert record_value(s.state)==worlds[w]['initial_full_state'];es=Evaluator(c,base,EvaluationConfig());eu=Evaluator(c,unit,EvaluationConfig());candidate=AlphaBetaPlayer(c,evaluator_override=Adapter(es if reg['arms'][slot['arm']]['leaf']=='static'else eu,es),use_disk_cache=False);opponent=AlphaBetaPlayer(c,evaluator_override=Adapter(es,es),use_disk_cache=False);players={role:candidate,1-role:opponent};row={**slot,'queries':[],'failure':None,'censor':None,'initial_record':record_value(s.to_record()),'rule_sha256':rh};path=D/f'game-{ix:03d}.json';write_record(path,row)
  try:
   while not s.state.terminal_status.is_terminal and s.state.ply_count<reg['caller_plies']:
    if time.perf_counter()-tick>=reg['whole_cap_seconds']:row['censor']='whole_cap';break
    actor=s.state.position.side_to_move;depth=reg['arms'][slot['arm']]['depth']if actor==role else 64;row['current_record']=record_value(s.to_record());write_record(path,row);qt=time.perf_counter();limits={**reg['limits'],'max_nodes':reg['arms'][slot['arm']]['nodes']}if actor==role else reg['limits'];dec=players[actor].choose_action(s,SearchLimits(max_depth=depth,**limits));elapsed=time.perf_counter()-qt;q={'root_ply':s.state.ply_count,'actor':actor,'candidate':actor==role,'requested_depth':depth,'limits':limits,'decision':record_value(dec),'seconds':elapsed};row['queries'].append(q);out['queries']+=1;write_record(path,row)
    if _timing_invalid(elapsed,reg['limits']['max_time_seconds']):row['censor']='timing_invalid';break
    if dec.action is None:row['censor']='candidate_or_opponent_no_action';break
    s.submit(dec.action)
  except Exception as e:row['failure']={'error':repr(e),'traceback':traceback.format_exc()};out['failures'].append({'slot':ix,**row['failure']})
  row.update(final_record=record_value(s.to_record()),final_state=record_value(s.state),terminal=record_value(s.result),seconds=time.perf_counter()-t);row.pop('current_record',None);fallback=any(q['decision']['result_source']in('fallback','legal_fallback','root_scan_fallback')or q['decision']['termination_reason']=='fallback'for q in row['queries']);operational=any(q['decision']['native_legality_operational_failures']for q in row['queries']);row['eligible']=not(row['failure']or row['censor']or fallback or operational);row['fallback']=fallback;row['operational_failure']=operational;value=None if not row['eligible']or row['terminal']['status']in('ongoing','no_contest')else 0 if row['terminal']['winner']is None else 1 if row['terminal']['winner']==role else-1;row['candidate_utility_interval']=[value,value]if value is not None else[-1,1];row['status']='finished';write_record(path,row);slot.update(status='finished',receipt=path.name,terminal=row['terminal'],candidate_utility_interval=row['candidate_utility_interval'],eligible=row['eligible'],plies=s.state.ply_count,seconds=row['seconds'])
 except Exception as e:slot.update(status='setup_failed',error=repr(e),traceback=traceback.format_exc());out['failures'].append(dict(slot))
 write_record(D/'results.json',out);print('FIXED',ix,w,slot['arm'],role,slot.get('terminal'),slot['candidate_utility_interval'],slot.get('plies'),round(time.perf_counter()-tick,1),flush=True)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;out['unattempted_slots']=[x['slot']for x in slots if x['status']=='not_started'];write_record(D/'results.json',out);print('CLOSED',len(slots),out['queries'],len(out['unattempted_slots']),round(out['seconds'],1),flush=True)
