import json,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-price-q0-next';D.mkdir(exist_ok=True);assert not(D/'registration.json').exists();configs=[]
for n in(4,6,8):
 for preset in('classic_like','free_random'):
  for symmetry in('bilateral','none'):configs.append({'seed':202610221100+len(configs),'board_size':n,'setup_preset':preset,'movement_symmetry':symmetry,'allow_hybrid':True,'max_generation_attempts':16,'require_no_opening_win_in_one':False})
reg={'question':'Does Unit-leaf advantage survive NEWbase-generatorrules at commonnode2048/q0 against fixedStatic2048/q0?','changed_premise':'FreshfilteredrosterUnitD1effectpositivebutq1D2priceeffectuncertain;Node2048q0utility-q1[0,1/3]andlowerpaidcost. Need pricecontrast incheaperresourcepolicyandunfilteredbase-generator scope,not a default/learner change.','prospective_configs':configs,'planned_role_slots':48,'planned_physical_games_if_all_generation_succeeds':36,'arms':['Staticleaf/Staticorder','Unitleaf/Staticorder'],'roles':[0,1],'opponent':'FixedStaticleaf/Staticordering,node2048,maxdepth64,q0(no qentry withdefaultcheckonlyOFF),ownTTpergame,diskOFF.','limits':{'max_depth':64,'max_nodes':2048,'max_time_seconds':None,'quiescence_max_depth':0,'quiescence_hard_max_depth':8},'caller_plies':96,'whole_cap_seconds':1800,'expected_seconds':900,'exact_reuse':'EligibleStaticselfgame sourceforbothroleframes oppositeutility;differentcandidateUNKNOWNtails independent;no oldgame reuse','price':'CompleteUnitCURRENTboard1000/BASEhand900,anchor0,preserveStaticprovedinert handzeros,promgain0;defaultdynamicweights2/5/3;commonStaticmaterialorderinputs.','selection':'All12configs/seed/conditionsfixedBEFOREgeneration;no opening-win preference,oracleoutcome filtering/replacement/humanlabels. May containtrivialopeningwins,retainthem. Fulltargetincludespromotion/drop/aux/relevanthistory;thisprototype is generatedlegacy-movementsubset,notallsemanticruleclaims.','preparation_only':True,'Player_queries':0,'fitness_games':'NOTRUN','generation_hard_cap_seconds':180,'no_default_AUX_training_change':True};write_record(D/'registration.json',reg);out={'registration':reg,'worlds':[],'failures':[],'Player_queries':0,'fitness_games':0,'status':'PREPARING'};tick=time.perf_counter()
for i,cfg in enumerate(configs):
 if time.perf_counter()-tick>=180:out['failures'].append({'index':i,'status':'preparation_whole_cap_unattempted','config':cfg});continue
 try:
  g=generate_game(GeneratorConfig(**cfg));raw=ruleset_to_dict(g.ruleset);entry={'index':i,'config':cfg,'rule':raw,'generation_report':record_value(g.generation_report)};out['worlds'].append(entry);write_record(D/'inputs.json',out);c=compile_rule(g.ruleset);s=GameSession(c);entry.update(initial_record=record_value(s.to_record()),initial_full_state=record_value(s.state),initial_legal_actions=len(s.legal_actions()));write_record(D/'inputs.json',out)
 except Exception as e:out['failures'].append({'index':i,'config':cfg,'error':repr(e),'traceback':traceback.format_exc()});write_record(D/'inputs.json',out)
out['status']='PREPARED_NOTRUN';out['seconds']=time.perf_counter()-tick;write_record(D/'inputs.json',out);print('NEXTQ0INPUTS',len(out['worlds']),len(out['failures']),out['Player_queries'],round(out['seconds'],3))
