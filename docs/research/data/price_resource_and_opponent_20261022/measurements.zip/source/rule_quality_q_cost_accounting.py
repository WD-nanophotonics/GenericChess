import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-leaf-next');r=json.loads((D/'outcome-divergence-node-control.json').read_text());out={'question':'Could making justthe alreadytimed legal/evaluation/ordering blocks free put thecompleteq4traversal under1s?','scope':'ObservedcompletedD2node-onlytraversal,scopedAmdahlaccounting,not hardwareindependentlowerbound ornewtimingrun. Instrumentedblocksaredisjoint persearchsource;otherwork/measurementoverhead/concurrentload remains. No runtime/AUX implementation change.','rows':[]}
for row in r['rows']:
 if not row['arm'].endswith('N65536'):continue
 d=row['decision'];subtotal=sum(d[k]for k in ('legal_generation_seconds','evaluation_seconds','ordering_seconds'));out['rows'].append({'arm':row['arm'],'completed_depth':d['completed_depth'],'elapsed_seconds':d['elapsed_seconds'],'measured_three_blocks':subtotal,'remaining_observed_seconds':d['elapsed_seconds']-subtotal,'main_nodes':d['nodes'],'qnodes':d['qnodes'],'total_nodes':d['nodes']+d['qnodes'],'runtime_pushes':d['runtime_pushes'],'runtime_pushes_are_successful_actual_transitions':True,'checking_drops':d['checking_drop_qactions'],'quiet_drops_classified_out':d['nonchecking_drop_excluded'],'all_three_free_same_observed_work_under1s':d['elapsed_seconds']-subtotal<1})
write_record(D/'q-cost-accounting.json',out);print(out)
