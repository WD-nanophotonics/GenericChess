import json,sys,time
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-leaf-next');res=json.loads((D/'results.json').read_text());analysis=json.loads((D/'paired-analysis.json').read_text());worlds={w['index']:w for w in json.loads((D/'inputs.json').read_text())['worlds']};out={'question':'What actual firstpolicy divergence precedes the two changed freshFLOOR outcomes?','scope':'Explicitposthoc2pairs,fullCoreimmediatewin continuations;not all-defenseWDL/no oracletraining/no patch. No newPlayergames.','cases':[]};tick=time.perf_counter()
for pair in analysis['pairs']:
 if pair['same_outcome']:continue
 w,role=pair['world'],pair['role'];c=compile_rule(ruleset_from_dict(worlds[w]['rule']));slots=[next(x for x in res['slots']if x['world']==w and x['candidate_role']==role and x['leaf_order_arm']==arm)for arm in(0,1)];games=[json.loads((D/x['receipt']).read_text())for x in slots];records=[deserialize_game_record(json.dumps(g['final_record']))for g in games];n=next(i for i,(a,b)in enumerate(zip(*(r.actions for r in records)))if a!=b);s=GameSession.replay(c,replace(records[0],actions=records[0].actions[:n]));row={'world':w,'role':role,'first_divergence':n,'common_record':record_value(s.to_record()),'common_full_state':record_value(s.state),'outcome_pair':pair,'choices':[]};assert s.state.position.side_to_move==role
 for arm in(0,1):
  action=records[arm].actions[n];a,ch=next((a,ch)for a,ch in legal_successors(s.state,c)if a==action);q=next(q for q in games[arm]['queries']if q['root_ply']==n);replies=[]
  if not ch.terminal_status.is_terminal:
   for b,grand in legal_successors(ch,c):replies.append({'action':record_value(b),'terminal':record_value(grand.terminal_status),'full_child_state':record_value(grand) if grand.terminal_status.winner==1-role else None})
  row['choices'].append({'arm':arm,'selected_action':record_value(a),'full_after_choice':record_value(ch),'decision':q['decision'],'opponent_replies':replies,'opponent_immediate_wins':sum(x['terminal']['winner']==1-role for x in replies)})
 out['cases'].append(row);write_record(D/'outcome-divergence-diagnosis.json',out)
out['seconds']=time.perf_counter()-tick;write_record(D/'outcome-divergence-diagnosis.json',out);print('DIVERGENCES',[(x['world'],x['role'],x['first_divergence'],[(y['arm'],y['opponent_immediate_wins'],y['decision']['score'])for y in x['choices']])for x in out['cases']])
