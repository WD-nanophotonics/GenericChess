import json,sys,time
from pathlib import Path
from dataclasses import replace,fields
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-leaf-next');path=D/'capture-hand-q-cost-control.json';assert not path.exists();case=json.loads((D/'outcome-divergence-diagnosis.json').read_text())['cases'][0];world=next(w for w in json.loads((D/'inputs.json').read_text())['worlds']if w['index']==4);raw=world['rule'];rawremove={**raw,'capture_disposition':'remove_from_game'};node=json.loads((D/'outcome-divergence-node-control.json').read_text());reg={'question':'Is the newq4costamplification tied to actualcapturedstock,orjust itsleafhandprice?','scope':'Posthocworld4fulltwo-plyhistory;singlecapture-fieldintervention/newrule,not same-RuleSetboardimpossibility orpurecostcausality. Samehistorylegalinboth,fullboard/side/aux/promotion fixed;handsreconstructedfromcaptures,notsyntheticdeletion. FrozenpocketStaticboard/gain/order reusedexplicitly;cross-modepayoffs/legalfrontiers maychange.','expected_seconds':30,'whole_cap_seconds':120,'limits':{'max_depth':2,'max_nodes':65536,'max_time_seconds':None,'quiescence_hard_max_depth':8},'cells':'2capturemodes x2leafhandpriceprofiles(full/zero)x2q(1/4);2pocketfullcoldqueries exactsource reuses,6newqueries;nocaprefill','no_default_change':True};out={'registration':reg,'rows':[],'status':'RUNNING'};write_record(path,out);tick=time.perf_counter();contexts={}
class Adapter:
 def __init__(self,leaf,order):self.evaluate=leaf.evaluate;self.type_value=order.type_value;self.capture_order_value=order.capture_order_value
pocket=compile_rule(ruleset_from_dict(raw));base=AlphaBetaPlayer(pocket,use_disk_cache=False).evaluation_profile;zero=replace(base,hand_value_by_base_type={t:0 for t in base.hand_value_by_base_type},piece_profiles={t:replace(p,normalized_hand_value=0)for t,p in base.piece_profiles.items()});original=deserialize_game_record(json.dumps(case['common_record']));baseline=GameSession.replay(pocket,original)
for mode,rr in [('pocket',raw),('remove',rawremove)]:
 c=compile_rule(ruleset_from_dict(rr));rec=replace(original,ruleset_fingerprint=GameSession(c).to_record().ruleset_fingerprint);s=GameSession.replay(c,rec);diff=[f.name for f in fields(s.state.position)if getattr(s.state.position,f.name)!=getattr(baseline.state.position,f.name)];assert set(diff)<= {'ruleset_fingerprint','hands'};contexts[mode]=(c,s);assert {k:v for k,v in raw.items()if k!='capture_disposition'}=={k:v for k,v in rr.items()if k!='capture_disposition'}
 for hand,profile in [('full',base),('zero',zero)]:
  for qdepth in(1,4):
   if time.perf_counter()-tick>=120:break
   row={'mode':mode,'hand_profile':hand,'qdepth':qdepth,'rule':rr,'record':record_value(rec),'full_state':record_value(s.state),'position_differences':diff,'profile':record_value(profile),'ordering_profile':record_value(base),'reused':mode=='pocket'and hand=='full'};out['rows'].append(row);write_record(path,out)
   if row['reused']:
    saved=next(x for x in node['rows']if x['arm']==f'Static2q{qdepth}N65536');row.update(decision=saved['decision'],seconds=saved['seconds'],reuse_source='outcome-divergence-node-control.json:'+saved['arm'])
   else:
    es=Evaluator(c,profile,EvaluationConfig());order=Evaluator(c,base,EvaluationConfig());player=AlphaBetaPlayer(c,evaluator_override=Adapter(es,order),use_disk_cache=False);t=time.perf_counter();dec=player.choose_action(s,SearchLimits(quiescence_max_depth=qdepth,**reg['limits']));row.update(decision=record_value(dec),seconds=time.perf_counter()-t)
   write_record(path,out);dec=row['decision'];pv=s.state
   for a in dec['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==a) if False else next((aa,ch)for aa,ch in legal_successors(pv,c)if record_value(aa)==a)
   row['literal_pv_passed']=True;write_record(path,out);print('CAPQ',mode,hand,qdepth,dec['completed_depth'],dec['nodes']+dec['qnodes'],dec['runtime_pushes'],round(row['seconds'],3),row['reused'],flush=True)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;out['missing_cells']=8-len(out['rows']);write_record(path,out)
