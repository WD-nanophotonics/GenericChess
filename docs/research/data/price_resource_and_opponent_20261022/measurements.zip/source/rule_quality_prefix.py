from pathlib import Path
import json,hashlib
P=Path('.local_agent/rule-quality-prefix-next-20261022')
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
