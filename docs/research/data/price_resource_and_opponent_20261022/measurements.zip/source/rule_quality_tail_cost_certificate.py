import json,sys
from pathlib import Path
from fractions import Fraction
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-node-ladder';Q=P/'prospective-node-q0-control';p=D/'continuation-cost-bounds.json';r=json.loads(p.read_text());node=json.loads((D/'results.json').read_text());q0=json.loads((Q/'results.json').read_text());actual={};tails=[]
for label,rr,where in [('Q0',q0,Q),('C',node,D)]:
 n=0
 for slot in rr['slots']:
  if slot['arm']!=label:continue
  g=json.loads((where/slot['receipt']).read_text());n+=sum(x['decision']['nodes']+x['decision']['qnodes']for x in g['queries']if x['candidate'])
  if label=='Q0'and g['terminal']['status']=='ongoing':tails.append({'slot':slot['slot'],'world':slot['world'],'recorded_plies':len(g['final_record']['actions']),'remaining_rule_plies':512-g['final_state']['ply_count'],'per_future_candidate_query_node_cap':2048})
 actual[label]=n
extra=sum(x['remaining_rule_plies']*x['per_future_candidate_query_node_cap']for x in tails);gap=actual['C']-(actual['Q0']+extra);assert gap>0;assert Fraction(r['cells']['Q0']['mean_counted_nodes_fullcontinuation_interval'][1])==Fraction(actual['Q0']+extra,24)
r['conclusion']='VersusB(2048q1), observed-prefixcostadvantagedoesnotprove fullcontinuedownnodecostdominance. VersusC(4096q1/common1024foe), Q0haslowerfullcontinuedCANDIDATEcounted-node upperboundthanCalreadypaidlowerbound,evenwithconservativetail. UtilityQ0-C[-1/6,1/6]remainsunidentified;nooverallPareto/defaultorwall/primitive/totalmatchcostclaim.'
r['Q0_vs_C_counted_cost_certificate']={'same_fixed_opponent':'Static1024q1,NOTdirectadjacent-rung2048foe','role_frames_each':24,'Q0_already_paid_candidate_nodes':actual['Q0'],'Q0_ongoing_cases':tails,'Q0_future_candidate_node_upper':extra,'Q0_full_candidate_node_upper':actual['Q0']+extra,'C_already_paid_candidate_nodes_lower':actual['C'],'strict_total_candidate_node_gap_lower':gap,'per_role_gap_lower':str(Fraction(gap,24)),'Q0_minus_C_utility_interval':['-1/6','1/6'],'assumptions':'Fixed512trueclock,noautomaticpending/custom/declaration/reset actions;futurequerynodes<=registeredcap;atmostonequeryperactualply. No continuations executed. Boundcountssearchvisitsonly.'};write_record(p,r);print('TAILCOSTCERT',r['Q0_vs_C_counted_cost_certificate'])
