import json,sys,time,random,traceback,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from rule_quality_floor_policy import D,floor_action
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.benchmark.runner import _timing_invalid
src=Path('.local_agent/rule-quality-survey-20261022/inputs.json');inp=json.loads(src.read_text());worlds={w['index']:w for w in inp['worlds']};pre=json.loads((D/'cost-preflight.json').read_text());assert pre['status']=='CLOSED'and max(x['decision_seconds']for x in pre['rows']if x['arm']=='floor')<1
reg={'question':'Does existing default D1 show competence beyond a no-evaluation immediateWIN floor against that fixedfloor opponent?','changed_premise':'D1/RNG advantage can conflate immediate terminal recognition with useful nontrivial evaluation/search. Newcounterfactuals identifylarge no-learningfloor effects.','selection':'All24original prospectiveconfiguration slots;22acceptedfullrules+2generationrefusals;D1candidate bothroles48intendedgames44available. No newgeneration orfavorableworldselection.','input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate':'ExistingAlphaBetaPlayer defaultprofile/Nativeadmission,depth1,q4hard8,nodes8192,1s perdecision;freshplayer/game,TTpersistswithin own game;diskcacheOFF.','opponent':'FixedCoreFLOOR: firstactualruleWIN1 elseuniformlegal withoriginalpair0swap0 actorRNGstream;1s decisioncap;incompletescan censors instead of inventedfallback. Samepolicy inbothcandidate roles.','source_baseline':'ExactalreadyderivedFLOOR/FLOOR pair0swap0 gameperworld,oppositecandidate roleframes;zero-sum meanbaselineutility0evenifUNKNOWN. Thisdoesnot couplecandidateUNKNOWN withdifferentpolicybaseline.','caller_plies':96,'whole_cap_seconds':900,'expected_seconds':600,'limits':{'max_depth':1,'max_nodes':8192,'max_time_seconds':1.0,'quiescence_max_depth':4,'quiescence_hard_max_depth':8},'shuffle_seed':202610220422,'cost_preflight':str(D/'cost-preflight.json'),'cost_preflight_max_seconds':max(x['decision_seconds']for x in pre['rows']if x['arm']=='floor'),'scope':'Newfinitecompetence diagnostic,not pricelearning/transfer,Elo,populationquality ordefaultactivation. AllUNKNOWN/fallback/invalidturns retained;no caprefill.'};assert not(D/'results.json').exists();write_record(D/'registration.json',reg);slots=[{'slot':2*w+role,'world':w,'candidate_role':role,'status':'not_started','candidate_utility_interval':[-1,1]}for w in range(24)for role in(0,1)];order=list(range(48));random.Random(reg['shuffle_seed']).shuffle(order);out={'registration':reg,'slots':slots,'execution_order':order,'status':'RUNNING','candidate_queries':0,'floor_queries':0,'failures':[]};contexts={};tick=time.perf_counter();write_record(D/'results.json',out)
for ix in order:
 if time.perf_counter()-tick>=reg['whole_cap_seconds']:break
 slot=slots[ix];w=slot['world'];role=slot['candidate_role']
 if w not in worlds:slot['status']='generation_unavailable';continue
 t=time.perf_counter();raw=worlds[w]['rule'];rh=digest(raw)
 if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
 c=contexts[rh];s=GameSession(c);player=AlphaBetaPlayer(c,use_disk_cache=False);seed=worlds[w]['config']['seed']*1009;rng={0:random.Random(seed),1:random.Random(seed+1)};row={**slot,'queries':[],'failure':None,'censor':None};path=D/f'game-{ix:03d}.json';write_record(path,row)
 try:
  while not s.state.terminal_status.is_terminal and s.state.ply_count<reg['caller_plies']:
   if time.perf_counter()-tick>=reg['whole_cap_seconds']:row['censor']='whole_cap';break
   actor=s.state.position.side_to_move;row['current_record']=record_value(s.to_record());write_record(path,row);qstart=time.perf_counter()
   if actor==role:
    dec=player.choose_action(s,SearchLimits(**reg['limits']));elapsed=time.perf_counter()-qstart;action=dec.action;receipt={'root_ply':s.state.ply_count,'actor':actor,'policy':'D1','decision':record_value(dec),'seconds':elapsed};out['candidate_queries']+=1
   else:
    action,detail=floor_action(s,rng[actor],reg['limits']['max_time_seconds']);elapsed=time.perf_counter()-qstart;receipt={'root_ply':s.state.ply_count,'actor':actor,'policy':'FLOOR','action':record_value(action),'floor':detail,'seconds':elapsed};out['floor_queries']+=1
   row['queries'].append(receipt);write_record(path,row)
   if _timing_invalid(elapsed,reg['limits']['max_time_seconds']):row['censor']='timing_invalid';break
   if action is None:row['censor']='incomplete_floor_or_candidate_no_action';break
   s.submit(action)
 except Exception as e:row['failure']={'error':repr(e),'traceback':traceback.format_exc()};out['failures'].append({'slot':ix,**row['failure']})
 row.update(final_record=record_value(s.to_record()),final_state=record_value(s.state),terminal=record_value(s.result),seconds=time.perf_counter()-t);row.pop('current_record',None);fallback=any(q['policy']=='D1'and(q['decision']['result_source']in('fallback','legal_fallback','root_scan_fallback')or q['decision']['termination_reason']=='fallback')for q in row['queries']);operational=any(q['policy']=='D1'and q['decision']['native_legality_operational_failures']for q in row['queries']);row['eligible']=not(row['failure']or row['censor']or fallback or operational);row['fallback']=fallback;row['operational_failure']=operational;value=None if not row['eligible']or row['terminal']['status']in('ongoing','no_contest')else 0 if row['terminal']['winner']is None else 1 if row['terminal']['winner']==role else-1;row['candidate_utility_interval']=[value,value]if value is not None else[-1,1];row['status']='finished';write_record(path,row);slot.update(status='finished',receipt=path.name,terminal=row['terminal'],candidate_utility_interval=row['candidate_utility_interval'],eligible=row['eligible'],plies=s.state.ply_count,seconds=row['seconds']);write_record(D/'results.json',out);print('COMPETENCE',ix,w,role,row['terminal'],row['candidate_utility_interval'],s.state.ply_count,round(time.perf_counter()-tick,1),flush=True)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;out['unattempted_slots']=[x['slot']for x in slots if x['status']=='not_started'];write_record(D/'results.json',out);print('CLOSED',out['candidate_queries'],out['floor_queries'],len(out['unattempted_slots']),round(out['seconds'],1),flush=True)
