import json,sys,hashlib,time
from pathlib import Path
from dataclasses import replace
from collections import Counter,defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest,restricted_class
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
r=json.loads((P/'whole-results.json').read_text());assert r['status']=='CLOSED'and not r['unattempted_slots']and not r['failures'];worlds={};sources={};contexts={};verified={};tick=time.perf_counter();out={'verified_roots':0,'verified_children':0,'source_full_history_plies':0,'rows':[],'strata':[],'paired':[],'scope':'Independent reader and GameSession.submit qualification over sharedCore;not independentrules engine or WDL census.'}
for mode,rp,ip in [('pocket','.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-random-20261022/results.json','.local_agent/rule-quality-capture-20261022/inputs.json')]:
 sources[mode]={g['slot']:g for g in json.loads(Path(rp).read_text())['games']};worlds[mode]={w['index']:w for w in json.loads(Path(ip).read_text())['worlds']}
for i,row in enumerate(r['rows']):
 mode=row['mode'];g=sources[mode][row['game_slot']];raw=worlds[mode][row['world']]['rule'];rec=deserialize_game_record(json.dumps(g['final_record']));prefix=row['prefix'];item={'mode':mode,'world':row['world'],'slot':row['game_slot'],'prefix':prefix,'boardsize':ruleset_from_dict(raw).board_shape.width}
 if row['classification']=='unavailable_after_terminal':
  assert len(rec.actions)<prefix and g['terminal']['status']!='ongoing';item.update(classification='terminal_before_prefix',terminal=g['terminal'],actual_terminal_ply=len(rec.actions));out['rows'].append(item);continue
 rec=replace(rec,actions=rec.actions[:prefix]);rr=record_value(rec);assert digest({'rule':raw,'record':rr})==row['input_sha256'];p=P/'receipts'/(row['receipt_tag']+'.json');receipt=json.loads(p.read_text());assert receipt['input_sha256']==row['input_sha256'];h=row['input_sha256']
 if h not in verified:
  rh=digest(raw)
  if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
  c=contexts[rh];s=GameSession.replay(c,rec);assert record_value(s.state)==receipt['full_state'];actions=s.legal_actions();assert len(actions)==receipt['branching'];assert len({digest(x['action'])for x in receipt['children']})==len(actions)
  for a,ch in zip(actions,receipt['children']):
   assert record_value(a)==ch['action'];child=GameSession.replay(c,rec);child.submit(a);assert digest(record_value(child.state))==ch['full_child_sha256'];assert record_value(child.state.terminal_status)==ch['terminal'];out['verified_children']+=1
  assert restricted_class(ruleset_from_dict(raw),s.state)==receipt['closed_preconditions'];assert receipt['winning_children']==sum(ch['terminal']['winner']==receipt['actor']for ch in receipt['children']);assert not(receipt['restricted_closed_draw']and receipt['winning_children']);verified[h]=True;out['verified_roots']+=1;out['source_full_history_plies']+=prefix
 item.update(classification=row['classification'],branching=receipt['branching'],winning_children=receipt['winning_children'],terminal=receipt['root_terminal'],input_sha256=h,receipt_tag=row['receipt_tag']);out['rows'].append(item)
 if i%160==0:print('VERIFY',i,out['verified_roots'],out['verified_children'],round(time.perf_counter()-tick,2),flush=True)
for mode in('pocket','remove'):
 for prefix in(0,4,16,64):
  rows=[x for x in out['rows']if x['mode']==mode and x['prefix']==prefix];counts=Counter(x['classification']for x in rows);active=[x for x in rows if x['classification']not in('observed_terminal','terminal_before_prefix')];nwin=sum(x.get('winning_children',0)>0 for x in active);rngwin=sum(x['winning_children']/x['branching']for x in active)/len(active);out['strata'].append({'mode':mode,'prefix':prefix,'intended_views':192,'generation_missing':16,'accepted_views':len(rows),'counts':dict(counts),'ongoing_views':len(active),'immediate_win_views':nwin,'uniform_next_turn_win_probability_mean':rngwin,'conditional_on_win_opportunity':sum(x['winning_children']/x['branching']for x in active if x['winning_children'])/nwin if nwin else None,'unique_ongoing_fullstates':len({x['input_sha256']for x in active})})
for prefix in(0,4,16,64):
 pa={(x['world'],x['slot']):x for x in out['rows']if x['mode']=='pocket'and x['prefix']==prefix};pb={(x['world'],x['slot']):x for x in out['rows']if x['mode']=='remove'and x['prefix']==prefix};assert pa.keys()==pb.keys();tab=Counter((pa[k]['classification'],pb[k]['classification'])for k in pa);survive=[k for k in pa if pa[k]['classification']not in('observed_terminal','terminal_before_prefix')and pb[k]['classification']not in('observed_terminal','terminal_before_prefix')];out['paired'].append({'prefix':prefix,'classification_pairs':[{'pocket':a,'remove':b,'views':n}for(a,b),n in tab.items()],'both_ongoing_views':len(survive),'pocket_immediatewin_on_both_ongoing':sum(pa[k].get('winning_children',0)>0 for k in survive),'remove_immediatewin_on_both_ongoing':sum(pb[k].get('winning_children',0)>0 for k in survive),'warning':'Same configuration/policyseed pairs,not same laterfullstate;intervention changes actionsampling support.'})
out['seconds']=time.perf_counter()-tick;write_record(P/'qualification-and-summary.json',out);print('QUALIFIED',out['verified_roots'],out['verified_children'],round(out['seconds'],2));print(json.dumps(out['strata'],indent=2))
