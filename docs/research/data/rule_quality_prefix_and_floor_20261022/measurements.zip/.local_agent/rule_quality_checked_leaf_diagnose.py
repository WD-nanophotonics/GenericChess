import json,sys,time
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig,MATE_SCORE
D=P/'floor-unit-control';f=json.loads((D/'first-divergence-failure.json').read_text())['cases'][0];w=next(w for w in json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text())['worlds']if w['index']==f['world']);c=compile_rule(ruleset_from_dict(w['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(f['common_full_record'])));base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;ev=Evaluator(c,base,EvaluationConfig());actor=s.state.position.side_to_move;out={'question':'What concrete legal response invalidates the naiveoneply bestchild explanation of actualD1?','source_failure':str(D/'first-divergence-failure.json'),'actual_search_contract':'resultordinaryqdepth0 still permits forcedcheckevasions up tohard8. No product/testexpectation changed.','roots':[]};tick=time.perf_counter()
for raw in f['children']:
 if raw['static']!=f['full_D1_maxima'][0]:continue
 a,ch=next((a,ch)for a,ch in legal_successors(s.state,c)if record_value(a)==raw['action']);assert semantic_engine_for(c).in_check(ch.position,ch.position.side_to_move);row={'naive_best_action':record_value(a),'naive_static_value':raw['static'],'opponent_in_check':True,'responses':[]}
 for b,leaf in legal_successors(ch,c):
  check=semantic_engine_for(c).in_check(leaf.position,leaf.position.side_to_move);t=leaf.terminal_status;value=(0 if t.winner is None else MATE_SCORE-2 if t.winner==actor else -MATE_SCORE+2)if t.is_terminal else ev.evaluate(leaf);r={'reply':record_value(b),'full_leaf_state':record_value(leaf),'root_in_check_after_reply':check,'literal_leaf_value':value,'ordinaryq0_stops_here':not check or t.is_terminal,'undercuts_actual_selected_score':(not check or t.is_terminal)and value<f['returned_scores'][0]};row['responses'].append(r)
 assert any(x['undercuts_actual_selected_score']for x in row['responses']);out['roots'].append(row)
out['seconds']=time.perf_counter()-tick;out['causal_model_failure_confirmed']=True;write_record(D/'checked-leaf-diagnosis.json',out);print('CHECKEDLEAF',[(x['naive_static_value'],len(x['responses']),[(y['literal_leaf_value'],y['root_in_check_after_reply'],y['undercuts_actual_selected_score'])for y in x['responses']])for x in out['roots']])
