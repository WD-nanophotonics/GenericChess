import json,sys,time,hashlib,traceback
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest,measure
from scripts.research_record import write_record,record_value
from generic_chess.session.serialization import deserialize_game_record
reg=json.loads((P/'whole-registration.json').read_text());cat=json.loads((P/'catalog.json').read_text());sources={};worlds={};reuse={}
for mode,resultpath,inputpath in [('pocket','.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-random-20261022/results.json','.local_agent/rule-quality-capture-20261022/inputs.json')]:
 p=Path(resultpath);assert hashlib.sha256(p.read_bytes()).hexdigest()==reg['sources'][resultpath];sources[mode]={g['slot']:g for g in json.loads(p.read_text())['games']};worlds[mode]={w['index']:w for w in json.loads(Path(inputpath).read_text())['worlds']}
for p in sorted((P/'receipts').glob('preflight-*.json')):
 r=json.loads(p.read_text());reuse[r['input_sha256']]=r
out={'registration':reg,'rows':[],'new_unique_scans':0,'exact_reuse_views':0,'unattempted_slots':[],'status':'RUNNING','failures':[]};tick=time.perf_counter()
try:
 for i,row in enumerate(cat):
  if time.perf_counter()-tick>=reg['whole_hard_cap_seconds']:out['unattempted_slots']=list(range(i,len(cat)));break
  if row['status']!='available_full_history':out['rows'].append({**row,'classification':'unavailable_after_terminal'});continue
  mode=row['mode'];g=sources[mode][row['game_slot']];assert hashlib.sha256(json.dumps(g['final_record'],sort_keys=True).encode()).hexdigest()==row['source_full_record_sha256'];rec=deserialize_game_record(json.dumps(g['final_record']));rec=replace(rec,actions=rec.actions[:row['prefix']]);item={'mode':mode,'world':row['world'],'source_game_slot':row['game_slot'],'prefix':row['prefix'],'rule':worlds[mode][row['world']]['rule'],'record':record_value(rec)};h=digest({'rule':item['rule'],'record':item['record']})
  if h in reuse:r=reuse[h];out['exact_reuse_views']+=1;reused=True
  else:r=measure(item,f'whole-{i:04d}');reuse[h]=r;out['new_unique_scans']+=1;reused=False
  out['rows'].append({**row,'receipt_tag':r['tag'],'input_sha256':h,'exact_reuse':reused,'root_terminal':r['root_terminal'],'branching':r['branching'],'winning_children':r['winning_children'],'restricted_closed_draw':r['restricted_closed_draw'],'classification':'observed_terminal'if r['root_terminal']['status']!='ongoing'else'restricted_closed_draw'if r['restricted_closed_draw']else'immediate_win_available'if r['winning_children']else'neither_proven'})
  if i%80==0:write_record(P/'whole-results.json',out);print(i,'unique',out['new_unique_scans'],'reused',out['exact_reuse_views'],round(time.perf_counter()-tick,2),flush=True)
 out['status']='CLOSED'if not out['unattempted_slots']else'CENSORED'
except Exception as e:out['status']='FAILED';out['failures'].append({'error':repr(e),'traceback':traceback.format_exc()});raise
finally:out['seconds']=time.perf_counter()-tick;write_record(P/'whole-results.json',out);print(out['status'],len(out['rows']),out['new_unique_scans'],round(out['seconds'],2),flush=True)
