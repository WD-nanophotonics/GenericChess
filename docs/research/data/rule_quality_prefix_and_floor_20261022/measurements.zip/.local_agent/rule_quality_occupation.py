import sys,json,time
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest,restricted_class
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=P/'occupation';D.mkdir(exist_ok=True);reg={'question':'Is closed-class occupation a late depletion mechanism and does time-weighted sampling overstate its game-level prevalence?','selection':'All208originalunique fullhistories plus exact352views,rawterminals/UNKNOWN unchanged. No new search/game/training.','measures':['Exact firstclosedentry ply and actualclosedturn count','Board+hand instance counts and actualpromotion/drop incidence','Gamebalanced versus turnweighted closure occupation,not populationCI'],'expected_seconds':120,'hard_cap_seconds':300};write_record(D/'registration.json',reg);tick=time.perf_counter();out={'registration':reg,'games':[],'status':'RUNNING','failures':[]};contexts={}
for mode,rp,ip in [('pocket','.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-random-20261022/results.json','.local_agent/rule-quality-capture-20261022/inputs.json')]:
 src=json.loads(Path(rp).read_text());worlds={w['index']:w for w in json.loads(Path(ip).read_text())['worlds']};by={}
 for g in src['games']:
  if time.perf_counter()-tick>=reg['hard_cap_seconds']:out['status']='CENSORED';break
  if g['reused_from']is not None:
   old=by[g['reused_from']];row={**old,'world':g['world'],'slot':g['slot'],'reuse_source_slot':g['reused_from']};out['games'].append(row);by[g['slot']]=row;continue
  rule=ruleset_from_dict(worlds[g['world']]['rule']);rh=digest(worlds[g['world']]['rule'])
  if rh not in contexts:contexts[rh]=compile_rule(rule)
  s=GameSession(contexts[rh]);rec=deserialize_game_record(json.dumps(g['final_record']));frames=[]
  for k in range(len(rec.actions)+1):
   pcs=[x for x in s.state.position.board if x];h=sum(x.total()for x in s.state.position.hands);frames.append({'ply':k,'board_instances':len(pcs),'hand_instances':h,'current_promoted_instances':sum(x.promoted for x in pcs),'restricted_closed_draw':all(restricted_class(rule,s.state).values()),'full_state_sha256':digest(record_value(s.state))})
   if k<len(rec.actions):s.submit(rec.actions[k])
  assert record_value(s.state)==g['final_state'];closed=[x['ply']for x in frames if x['restricted_closed_draw']];counts=[x['board_instances']+x['hand_instances']for x in frames];assert all(x==counts[0]for x in counts)if mode=='pocket'else all(b<=a for a,b in zip(counts,counts[1:]));turns=frames[:-1];row={'mode':mode,'world':g['world'],'slot':g['slot'],'reuse_source_slot':None,'source_full_record':g['final_record'],'frames':frames,'actual_turns':len(rec.actions),'raw_terminal':g['terminal'],'first_closed_ply':closed[0]if closed else None,'closed_turns':sum(x['restricted_closed_draw']for x in turns),'promoted_turns':sum(x['current_promoted_instances']>0 for x in turns),'drop_actions':sum('drop'in a.get('kind','')for a in g['final_record']['actions']),'initial_instances':counts[0],'final_instances':counts[-1]};by[g['slot']]=row;out['games'].append(row);write_record(D/f'{mode}-{g["slot"]:03d}.json',row)
 out['status']='CLOSED'if out['status']=='RUNNING'else out['status']
out['seconds']=time.perf_counter()-tick;out['summary']=[]
for mode in('pocket','remove'):
 rows=[g for g in out['games']if g['mode']==mode];unique=[g for g in rows if g['reuse_source_slot']is None];out['summary'].append({'mode':mode,'views':len(rows),'actual_unique_games':len(unique),'gameviews_ever_closed':sum(g['first_closed_ply']is not None for g in rows),'unique_games_ever_closed':sum(g['first_closed_ply']is not None for g in unique),'firstentry_plies':dict(Counter(g['first_closed_ply']for g in unique if g['first_closed_ply']is not None)),'view_turns':sum(g['actual_turns']for g in rows),'view_closed_turns':sum(g['closed_turns']for g in rows),'unique_turns':sum(g['actual_turns']for g in unique),'unique_closed_turns':sum(g['closed_turns']for g in unique),'gamebalanced_closed_turn_fraction':sum(g['closed_turns']/g['actual_turns']if g['actual_turns']else 0 for g in unique)/len(unique),'unique_promoted_turns':sum(g['promoted_turns']for g in unique),'unique_drop_actions':sum(g['drop_actions']for g in unique)})
write_record(D/'results.json',out);print(out['status'],round(out['seconds'],2));print(json.dumps(out['summary'],indent=2))
