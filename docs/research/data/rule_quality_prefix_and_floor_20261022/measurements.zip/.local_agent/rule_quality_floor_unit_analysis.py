import json,sys,time
from pathlib import Path
from fractions import Fraction
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P
from scripts.research_record import write_record
S=P/'floor-competence';U=P/'floor-unit-control';a=json.loads((S/'results.json').read_text());b=json.loads((U/'results.json').read_text());assert a['status']==b['status']=='CLOSED';sa={x['slot']:x for x in a['slots']};ub={x['slot']:x for x in b['slots']};out={'question':'Does rule-derived defaultprice outperform a complete UnitON control in the newfixed-FLOOR competence envelope?','scope':'Wholepricepolicy:leaf/order/promotiongain jointly changed,dynamicweights held. Exposed22acceptedslots/13uniquerules;not learnedprice,universalwinner ordefaultchange. DifferentpolicyUNKNOWN notcoupled.','pairs':[]}
for k in sorted(sa):
 x,y=sa[k],ub[k];assert x['world']==y['world']and x['candidate_role']==y['candidate_role'];out['pairs'].append({'slot':k,'world':x['world'],'role':x['candidate_role'],'status_static':x['status'],'status_unit':y['status'],'static':x['candidate_utility_interval'],'unit':y['candidate_utility_interval'],'unit_minus_static':[y['candidate_utility_interval'][0]-x['candidate_utility_interval'][1],y['candidate_utility_interval'][1]-x['candidate_utility_interval'][0]]if x['status']==y['status']=='finished'else[-2,2]})
valid=[x for x in out['pairs']if x['status_static']==x['status_unit']=='finished'];out['accepted_effect']=[str(sum(Fraction(x['unit_minus_static'][j])for x in valid)/len(valid))for j in(0,1)];out['hypothetical_plannedcompletion']=[str(sum(Fraction(x['unit_minus_static'][j])for x in out['pairs'])/len(out['pairs']))for j in(0,1)];out['accepted_roles']=len(valid);out['missing_roles']=len(out['pairs'])-len(valid);out['families']=[]
for world in range(24):
 rows=[x for x in valid if x['world']==world]
 if rows:out['families'].append({'world':world,'effect':[str(sum(Fraction(x['unit_minus_static'][j])for x in rows)/2)for j in(0,1)],'raw_pairs':rows})
for name,raw,directory in [('Static',a,S),('UnitON',b,U)]:
 queries=[q for slot in raw['slots']if slot['status']=='finished'for q in json.loads((directory/slot['receipt']).read_text())['queries']];d1=[q for q in queries if q['policy']=='D1'];out[name+'_cost']={'candidate_queries':len(d1),'floor_queries':len(queries)-len(d1),'actual_search_nodes':sum(q['decision']['nodes']for q in d1),'evaluation_calls':sum(q['decision']['evaluation_calls']for q in d1),'paid_candidate_seconds':sum(q['seconds']for q in d1),'paid_floor_seconds':sum(q['seconds']for q in queries if q['policy']=='FLOOR'),'producer_seconds':raw['seconds'],'price_table_build_cost_in_producer_not_turn':True,'backend_source_counts':dict(Counter(q['decision']['result_source']for q in d1))}
write_record(U/'paired-analysis.json',out);print('UNIT_MINUS_STATIC',out['accepted_effect'],out['hypothetical_plannedcompletion']);print('FAMILIES',[(x['world'],x['effect'])for x in out['families']]);print('COST',out['Static_cost'],out['UnitON_cost'])
