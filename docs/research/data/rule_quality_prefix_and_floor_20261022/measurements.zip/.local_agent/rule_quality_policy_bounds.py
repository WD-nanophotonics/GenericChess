import json,sys,itertools
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P
from scripts.research_record import write_record
D=P/'terminal-floor-factorial';data=json.loads((D/'results.json').read_text());occupation=json.loads((P/'occupation/results.json').read_text());closed={(g['mode'],g['slot']):g['first_closed_ply']is not None for g in occupation['games']};out={'question':'Which finite utility contrasts survive without assuming different post-cap policies share the same UNKNOWN outcome?','correction':'The original summary is valid only if all four prefixpolicies switch to a common continuation value atply96. Equal savedprefixes with different continuingpolicies are not generally the same unobserved outcome. Raw results neverchanged. Preserve conditional summary;this supersedes its unqualified fullpolicy interpretation.','partial_order':'For firstplayer utility: C<=A<=B and C<=D<=B,from immediateWIN policy weakdominance ignoring computationcost. Knownactualterminals fixed;different censoredpolicycells otherwise distinct. Exactduplicateviews remain the same policy/sourcecontext.','enumeration':'For4variables with order constraints and observed constants -1/0/1,the feasibleorderpolytope has extremevalues among -1/0/1. Enumerate all81 assignments;objectives affine. Bounds are finitecompletion sensitivities,not populationCI or proof of attainable realpolicy endpoints.','layers':[]}
objectives={'B-A':lambda v:v['B']-v['A'],'D-C':lambda v:v['D']-v['C'],'interaction':lambda v:v['D']-v['C']-v['B']+v['A'],'rolebalanced_gain':lambda v:Fraction(v['B']-v['C'],2)}
for analytic in(False,True):
 layer={'use_separate_closed_draw_proof':analytic,'strata':[],'per_source':[]}
 for mode in('pocket','remove'):
  rows=[r for r in data['games']if r['mode']==mode];sums={k:[Fraction(),Fraction()]for k in objectives}
  for row in rows:
   domains={}
   for cell,record in row['cells'].items():
    t=record['terminal']
    if t['status']=='ongoing':domains[cell]=[0]if analytic and closed[mode,row['slot']]and record['first_activation_ply']is None else[-1,0,1]
    else:assert t['status']!='no_contest';domains[cell]=[0 if t['winner']is None else 1 if t['winner']==0 else -1]
   feasible=[]
   for vals in itertools.product(*(domains[c]for c in('A','B','C','D'))):
    v=dict(zip(('A','B','C','D'),vals))
    if v['C']<=v['A']<=v['B']and v['C']<=v['D']<=v['B']:feasible.append(v)
   assert feasible,(mode,row['slot'],domains);bounds={k:[min(fn(v)for v in feasible),max(fn(v)for v in feasible)]for k,fn in objectives.items()}
   for k,pair in bounds.items():sums[k][0]+=pair[0];sums[k][1]+=pair[1]
   if row['exact_source_reuse']is None:layer['per_source'].append({'mode':mode,'world':row['world'],'slot':row['slot'],'domains':domains,'feasible_vertex_assignments':len(feasible),'effects':{k:list(map(str,pair))for k,pair in bounds.items()}})
  layer['strata'].append({'mode':mode,'views':len(rows),'bounds':{k:[str(x/len(rows))for x in pair]for k,pair in sums.items()},'generationmissing_views':16,'rawUNKNOWNnotrelabeled':True})
 out['layers'].append(layer)
write_record(D/'policy-distinct-bounds.json',out);print(json.dumps([{k:v for k,v in layer.items()if k!='per_source'}for layer in out['layers']],indent=2));print('CORRECTED policy-distinct UNKNOWN;old common-tail calculation retained')
