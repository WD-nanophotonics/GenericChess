"""Core two-turn terminal opportunity census, not an all-game solver."""
import sys,json,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest,contexts
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
D=P/'two-turn';D.mkdir(exist_ok=True)
def scan(item,tag):
 tick=time.perf_counter();rh=digest(item['rule'])
 if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(item['rule']))
 c=contexts[rh];s=GameSession.replay(c,deserialize_game_record(json.dumps(item['record'])));actor=s.state.position.side_to_move;rows=[];edges=0
 for a,ch in legal_successors(s.state,c):
  replies=[];count=0
  if not ch.terminal_status.is_terminal:
   for b,leaf in legal_successors(ch,c):
    count+=1
    if leaf.terminal_status.winner==1-actor:replies.append({'action':record_value(b),'terminal':record_value(leaf.terminal_status),'full_state_sha256':digest(record_value(leaf))})
  edges+=count;rows.append({'action':record_value(a),'child_terminal':record_value(ch.terminal_status),'full_child_sha256':digest(record_value(ch)),'reply_branching':count,'opponent_winning_replies':replies})
 r={'tag':tag,'input_sha256':digest({'rule':item['rule'],'record':item['record']}),'mode':item['mode'],'world':item['world'],'prefix':item['prefix'],'boardsize':ruleset_from_dict(item['rule']).board_shape.width,'root_terminal':record_value(s.state.terminal_status),'root_state_sha256':digest(record_value(s.state)),'actor':actor,'children':rows,'reply_edges':edges,'seconds':time.perf_counter()-tick};r['immediate_win_actions']=sum(x['child_terminal']['winner']==actor for x in rows);r['immediate_loss_actions']=sum(x['child_terminal']['winner']==1-actor or bool(x['opponent_winning_replies'])for x in rows);r['other_actions']=len(rows)-r['immediate_win_actions']-r['immediate_loss_actions'];r['exact_win_loss_choice']=r['immediate_win_actions']>0 and r['immediate_loss_actions']>0;write_record(D/(tag+'.json'),r);return r
if __name__=='__main__':
 tick=time.perf_counter();items=json.loads((P/'preflight-inputs.json').read_text())['inputs'];out={'question':'Does a fixed natural prefix contain demonstrably winning and losing next actions,not just branching or delayed random outcomes?','phase':'metadata-selected24 preflight','frozen_inputs':str(P/'preflight-inputs.json'),'status':'RUNNING','results':[],'failures':[]}
 try:
  for i,item in enumerate(items):
   r=scan(item,f'preflight-{i:03d}');out['results'].append({k:r[k]for k in('tag','input_sha256','mode','world','prefix','boardsize','immediate_win_actions','immediate_loss_actions','other_actions','exact_win_loss_choice','reply_edges','seconds')});write_record(D/'preflight-results.json',out);print(i,r['mode'],r['boardsize'],r['prefix'],r['immediate_win_actions'],r['immediate_loss_actions'],r['reply_edges'],round(r['seconds'],3),flush=True)
  out['status']='CLOSED'
 except Exception as e:out['status']='FAILED';out['failures'].append({'error':repr(e),'traceback':traceback.format_exc()});raise
 finally:out['seconds']=time.perf_counter()-tick;write_record(D/'preflight-results.json',out)
