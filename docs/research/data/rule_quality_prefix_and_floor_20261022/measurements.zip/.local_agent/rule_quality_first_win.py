import json,sys,time,traceback
from pathlib import Path
from dataclasses import replace
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=P/'first-win';D.mkdir(exist_ok=True)
reg=json.loads((P/'first-win-counterfactual-registration.json').read_text());dense=json.loads((P/'dense/results.json').read_text());assert dense['status']=='CLOSED'and not dense['unattempted_games']and not dense['failures'];out={'registration':reg,'status':'RUNNING','games':[],'failures':[]};tick=time.perf_counter();contexts={}
for mode,rp,ip in [('pocket','.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-random-20261022/results.json','.local_agent/rule-quality-capture-20261022/inputs.json')]:
 src=json.loads(Path(rp).read_text());worlds={w['index']:w for w in json.loads(Path(ip).read_text())['worlds']};by={}
 for g in src['games']:
  if time.perf_counter()-tick>=reg['hard_cap_seconds']:out['status']='CENSORED';break
  if g['reused_from']is not None:
   old=by[g['reused_from']];r={**old,'world':g['world'],'slot':g['slot'],'exact_source_reuse':g['reused_from']};out['games'].append(r);by[g['slot']]=r;continue
  raw=worlds[g['world']]['rule'];rh=digest(raw)
  if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
  c=contexts[rh];rec=deserialize_game_record(json.dumps(g['final_record']));trajectory=json.loads((P/'dense'/f'{mode}-{g["slot"]:03d}.json').read_text());assert trajectory['status']=='CLOSED';turns=trajectory['turns'];assert len(turns)==len(rec.actions)+1;first=next((x for x in turns[:-1]if x['classes'].get('WIN1',0)),None);closed=next((x['ply']for x in turns if x['restricted_closed_draw']),None)
  if first:
   k=first['ply'];assert k<len(rec.actions)and k<96;s=GameSession.replay(c,replace(rec,actions=rec.actions[:k]));assert digest(record_value(s.state))==first['full_state_sha256'];witness=first['winning_witness'];a=next(a for a in s.legal_actions()if record_value(a)==witness['action']);same_action=a==rec.actions[k];actor=s.state.position.side_to_move;s.submit(a);write_record(D/(mode+'-raw-'+str(g['slot'])+'.json'),{'source_slot':g['slot'],'first_ply':k,'full_record':record_value(s.to_record()),'full_state':record_value(s.state)});assert s.state.terminal_status.winner==actor;assert digest(record_value(s.state))==witness['full_child_sha256'];assert s.state.terminal_status.winner==trajectory['turns'][k+1]['raw_terminal']['winner']if same_action else True
   r={'mode':mode,'world':g['world'],'slot':g['slot'],'exact_source_reuse':None,'source_full_record_sha256':trajectory['source_full_record_sha256'],'original_terminal':g['terminal'],'first_activation_ply':k,'winning_actor':s.state.terminal_status.winner,'first_original_closed_ply':closed,'closed_entry_averted':closed is not None and k<closed,'actual_action_changed':not same_action,'derived_record':record_value(s.to_record()),'derived_full_state':record_value(s.state),'derived_terminal':record_value(s.result),'derived_plies':len(s.history),'source_prefix_preserved':True}
  else:r={'mode':mode,'world':g['world'],'slot':g['slot'],'exact_source_reuse':None,'source_full_record_sha256':trajectory['source_full_record_sha256'],'original_terminal':g['terminal'],'first_activation_ply':None,'winning_actor':None,'first_original_closed_ply':closed,'closed_entry_averted':False,'actual_action_changed':False,'derived_record':g['final_record'],'derived_full_state':g['final_state'],'derived_terminal':g['terminal'],'derived_plies':len(rec.actions),'source_prefix_preserved':True}
  by[g['slot']]=r;out['games'].append(r);write_record(D/f'{mode}-{g["slot"]:03d}.json',r)
if out['status']=='RUNNING':out['status']='CLOSED'
out['seconds']=time.perf_counter()-tick;out['summary']=[]
for mode in('pocket','remove'):
 rows=[x for x in out['games']if x['mode']==mode];out['summary'].append({'mode':mode,'views':len(rows),'actual_unique_counterfactuals':sum(x['exact_source_reuse']is None for x in rows),'original_terminal_counts':dict(Counter(x['original_terminal']['status']for x in rows)),'derived_terminal_counts':dict(Counter(x['derived_terminal']['status']for x in rows)),'firstWIN_activations':sum(x['first_activation_ply']is not None for x in rows),'changed_actions':sum(x['actual_action_changed']for x in rows),'original_closed_views':sum(x['first_original_closed_ply']is not None for x in rows),'closed_entry_averted':sum(x['closed_entry_averted']for x in rows),'generation_missing_views':16,'unattempted_views':176-len(rows),'raw_originals_unchanged':True})
write_record(D/'results.json',out);print(out['status'],round(out['seconds'],2));print(json.dumps(out['summary'],indent=2))
