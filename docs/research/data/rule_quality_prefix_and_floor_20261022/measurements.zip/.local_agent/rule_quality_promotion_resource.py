import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.core.semantic_executor import semantic_engine_for
D=P/'opening-resource';out={'question':'Does promotion provide an alternate on-board defense when capturedhandstock is removed?','registration':'All4legal firstpromotionchoices None/P/A/B times2legal replypromotionchoices None/B times2capturemodes;fixedcoordinates fromsavedwitness;no WDL beyondactualtwo-turnterminal/onelegaldefense.','status':'RUNNING','cases':[]};tick=time.perf_counter()
for mode,ip in [('pocket','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-20261022/inputs.json')]:
 raw=next(w for w in json.loads(Path(ip).read_text())['worlds']if w['index']==20)['rule'];c=compile_rule(ruleset_from_dict(raw))
 for promo in(None,'P','A','B'):
  for rp in(None,'B'):
   s=GameSession(c);a=next(a for a in s.legal_actions()if getattr(a,'from_square',None)and(a.from_square.file,a.from_square.rank)==(5,1)and(a.to_square.file,a.to_square.rank)==(2,7)and a.promotion_target_id==promo);s.submit(a);b=next(a for a in s.legal_actions()if getattr(a,'from_square',None)and(a.from_square.file,a.from_square.rank)==(1,7)and(a.to_square.file,a.to_square.rank)==(4,1)and a.promotion_target_id==rp);s.submit(b);responses=[]
   for z in s.legal_actions():
    t=GameSession.replay(c,s.to_record());t.submit(z);responses.append({'action':record_value(z),'full_child_state':record_value(t.state),'actor0_check_after':semantic_engine_for(c).in_check(t.state.position,0)})
   row={'mode':mode,'first_promotion':promo,'reply_promotion':rp,'full_record':record_value(s.to_record()),'full_state':record_value(s.state),'terminal':record_value(s.state.terminal_status),'responses':responses};out['cases'].append(row);write_record(D/'promotion-factorial.json',out)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;write_record(D/'promotion-factorial.json',out);print('PROMOTIONFACTORIAL',len(out['cases']),round(out['seconds'],3))
