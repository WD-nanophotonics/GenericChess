import json,sys
from pathlib import Path
from fractions import Fraction
from collections import defaultdict,Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P
from scripts.research_record import write_record
D=P/'terminal-floor-factorial';data=json.loads((D/'results.json').read_text());pref=json.loads((P/'whole-results.json').read_text());opening={(r['mode'],r['world']):r.get('winning_children',0)>0 for r in pref['rows']if r['prefix']==0};configs={w['index']:w['config']for w in json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text())['worlds']}
def interval(rows,cell):
 vals=[]
 for x in rows:
  t=x['cells'][cell]['terminal'];vals.append((-1,1)if t['status']=='ongoing'else(0,0)if t['winner']is None else(1,1)if t['winner']==0 else(-1,-1))
 return [str(sum((Fraction(x[j])for x in vals),Fraction())/len(vals))for j in(0,1)]if vals else None
out={'question':'Does a firstside-bias conclusion survive completecensoring,openingtactics and ruleweighting?','scope':'Posthoc descriptive decomposition of same exposedfinitecohort,not filterselection,balancedoptimalplay,populationCI or restoredmissinggeneration.','strata':[]}
for mode in('pocket','remove'):
 rows=[r for r in data['games']if r['mode']==mode]
 groups={'all_accepted_22slots_176views':rows,'equal13unique_rules_104actualstreams':[r for r in rows if r['exact_source_reuse']is None],'no_initial_WIN1_rules_descriptive':[r for r in rows if not opening[mode,r['world']]],'initial_WIN1_rules_descriptive':[r for r in rows if opening[mode,r['world']]]}
 for size in(4,6,8):groups['boardsize'+str(size)]=[r for r in rows if configs[r['world']]['board_size']==size]
 for name,sub in groups.items():out['strata'].append({'mode':mode,'group':name,'views':len(sub),'firstplayer_utility_intervals':{cell:interval(sub,cell)for cell in('A','B','C','D')},'D_outcomes':dict(Counter((r['cells']['D']['terminal']['status'],str(r['cells']['D']['terminal']['winner']))for r in sub))if False else[{'status':k[0],'winner':k[1],'views':v}for k,v in Counter((r['cells']['D']['terminal']['status'],r['cells']['D']['terminal']['winner'])for r in sub).items()]})
write_record(D/'firstside-decomposition.json',out);print([(r['mode'],r['group'],r['views'],r['firstplayer_utility_intervals']['A'],r['firstplayer_utility_intervals']['D'])for r in out['strata']])
