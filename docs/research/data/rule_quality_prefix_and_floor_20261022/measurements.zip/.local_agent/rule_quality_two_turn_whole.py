import sys,json,time,traceback
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from rule_quality_two_turn import D,scan
from scripts.research_record import write_record,record_value
from generic_chess.session.serialization import deserialize_game_record
pre=json.loads((D/'preflight-results.json').read_text());whole=json.loads((P/'whole-results.json').read_text());unique={r['input_sha256']:r for r in whole['rows']if r.get('input_sha256')};mean=sum(x['seconds']for x in pre['results'])/len(pre['results']);reg={'question':'How often do fixed natural prefixes admit both a provable immediate win and a move conceding an immediate reply win?','premise':'One-ply opportunities do not prove alternativeactions differ in outcome;24metadata-selected two-turnpreflights show exact W/L contrasts on one8board initialstate.','frozen_parent_registration':str(P/'whole-registration.json'),'preflight_count':24,'preflight_seconds':pre['seconds'],'unique_full_inputs':len(unique),'expected_seconds':mean*len(unique)*4,'hard_cap_seconds':900,'scope':'Enumerate Core legalchildren and terminalopponentreplies only;fullhistory preserved;no recursive graph/learner/default changes.','reuse':'Reuse24preflight returns and exact completeinput hashes;retain1408view rows/128generationmissing and postterminal unavailable separately.','interpretation':'At least one immediatewin plus at least one nextreplyloss proves some next choices differ in WDL. Otheractions/no tactic remain unproved. Not every tactically different root needs learnedprices.','cheaper_alternative':'Oneplyscan alreadycomplete;cannot label nonwinningalternatives as losses without replywitness.','status':'FROZEN BEFORE WHOLE'};write_record(D/'whole-registration.json',reg);print('REGISTERED',len(unique),round(reg['expected_seconds'],2),flush=True)
worlds={mode:{w['index']:w for w in json.loads(Path(path).read_text())['worlds']}for mode,path in [('pocket','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-20261022/inputs.json')]};reuse={}
for p in D.glob('preflight-???.json'):
 r=json.loads(p.read_text());reuse[r['input_sha256']]=r
out={'registration':reg,'results':[],'status':'RUNNING','failures':[],'unattempted_hashes':[],'new_unique_scans':0,'preflight_reuses':0};tick=time.perf_counter()
try:
 for i,(h,row)in enumerate(unique.items()):
  if time.perf_counter()-tick>=reg['hard_cap_seconds']:out['unattempted_hashes']=list(unique)[i:];break
  if h in reuse:r=reuse[h];out['preflight_reuses']+=1
  else:
   parent=json.loads((P/'receipts'/(row['receipt_tag']+'.json')).read_text());item={'mode':row['mode'],'world':row['world'],'prefix':row['prefix'],'rule':worlds[row['mode']][row['world']]['rule'],'record':parent['record']};assert digest({'rule':item['rule'],'record':item['record']})==h;r=scan(item,f'whole-{i:04d}');out['new_unique_scans']+=1
  out['results'].append({k:r[k]for k in('tag','input_sha256','mode','world','prefix','boardsize','immediate_win_actions','immediate_loss_actions','other_actions','exact_win_loss_choice','reply_edges','seconds')})
  if i%60==0:write_record(D/'whole-results.json',out);print('TWOTURN',i,out['new_unique_scans'],round(time.perf_counter()-tick,2),flush=True)
 out['status']='CLOSED'if not out['unattempted_hashes']else'CENSORED'
except Exception as e:out['status']='FAILED';out['failures'].append({'error':repr(e),'traceback':traceback.format_exc()});raise
finally:out['seconds']=time.perf_counter()-tick;write_record(D/'whole-results.json',out);print(out['status'],len(out['results']),round(out['seconds'],2),flush=True)
