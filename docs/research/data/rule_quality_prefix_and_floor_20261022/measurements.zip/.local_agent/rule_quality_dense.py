"""Dense diagnostics on all already-recorded random trajectories. No new play."""
import sys,json,time,traceback,hashlib
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest,restricted_class
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from dataclasses import replace
D=P/'dense';D.mkdir(exist_ok=True)
worlds={};sources={};tasks=[]
for mode,rp,ip in [('pocket','.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-random-20261022/results.json','.local_agent/rule-quality-capture-20261022/inputs.json')]:
 sources[mode]=json.loads(Path(rp).read_text());worlds[mode]={w['index']:w for w in json.loads(Path(ip).read_text())['worlds']};tasks.extend((g['world'],g['pair'],g['swap'],mode,g)for g in sources[mode]['games']if g['reused_from']is None)
tasks.sort(key=lambda x:x[:4]);turns=sum(len(g['final_record']['actions'])for *_,g in tasks);parent=json.loads((P/'two-turn/whole-results.json').read_text());estimate=turns*parent['seconds']/len(parent['results']);reg={'question':'Do sparse fixed prefixes miss meaningful tactical choices and when do actual random trajectories enter a checked no-mate class?','changed_premise':'570 fixedprefix states contain local W/Lcontrasts but most laterfixedprefixes have no such witness;fixedprefixes can miss briefopportunities.','selection':'ALL208actualunique existingrandomtrajectories,all16398actualturn roots plusfinalstates;alternatevariants withinworld/pair/swap. Include all176views pervariant through exactsource reuse. No oracle/statevalue selection,newgames or training.','planned_unique_games':len(tasks),'planned_actual_turns':turns,'expected_seconds':estimate,'hard_cap_seconds':2400,'expected_total_with_recording_seconds':estimate*1.5,'source_hashes':json.loads((P/'registration.json').read_text())['sources'],'reuse':'Existing fixedprefix two-turn returns by exactfullrule+canonicalfullrecord hash;onlyroot historiesidentical reused.','output':'Compact perroot actual action counts,rawterminal,fullstatehash,firstW/Lreplywitnesses,chosenactionclass;canonical sourcefullrecord+rule retained. No omittedsemanticfields.','scope':'Two-turnterminalcertificates lowerbound localdecision information,not allWDL,pricelearnability,qualitythreshold or genericwinner. Posthoc alltrajectory descriptive view.','cheaper_alternative':'Fixedprefix pass finished;doesnot measure firstentry,duration,or missed between-prefix opportunities. No newPlayercalls or fullgraph.'};assert turns==16398 and len(tasks)==208;write_record(D/'registration.json',reg);print('DENSE_REGISTER',len(tasks),turns,round(estimate,2),flush=True)
cache={}
for p in (P/'two-turn').glob('*.json'):
 if p.name in('preflight-results.json','whole-results.json','summary.json','whole-registration.json'):continue
 r=json.loads(p.read_text());cache[r['input_sha256']]=r
contexts={};out={'registration':reg,'status':'RUNNING','games':[],'failures':[],'new_turn_scans':0,'fixedprefix_reuses':0,'new_reply_edges':0,'unattempted_games':[]};tick=time.perf_counter()
def compact(s,raw,rec,k,key,known):
 actor=s.state.position.side_to_move
 if known is not None:children=known['children'];reply_edges=known['reply_edges'];secs=0.0
 else:
  t=time.perf_counter();children=[];reply_edges=0
  for a,ch in legal_successors(s.state,s.compiled):
   win_count=0;first=None;nb=0
   if not ch.terminal_status.is_terminal:
    for b,leaf in legal_successors(ch,s.compiled):
     nb+=1
     if leaf.terminal_status.winner==1-actor:
      win_count+=1
      if first is None:first={'action':record_value(b),'terminal':record_value(leaf.terminal_status),'full_state_sha256':digest(record_value(leaf))}
   reply_edges+=nb;children.append({'action':record_value(a),'child_terminal':record_value(ch.terminal_status),'full_child_sha256':digest(record_value(ch)),'reply_branching':nb,'opponent_winning_count':win_count,'first_opponent_winning_reply':first})
  secs=time.perf_counter()-t
 def oppwin(ch):return len(ch['opponent_winning_replies'])if 'opponent_winning_replies'in ch else ch['opponent_winning_count']
 def label(ch):return 'WIN1'if ch['child_terminal']['winner']==actor else'LOSS1_OR_REPLY2'if ch['child_terminal']['winner']==1-actor or oppwin(ch)>0 else'DRAW1'if ch['child_terminal']['status']not in('ongoing','no_contest')else'UNKNOWN'
 classes=Counter(label(ch)for ch in children);chosen=record_value(rec.actions[k])if k<len(rec.actions)else None;selected=next((label(ch)for ch in children if ch['action']==chosen),None);w=next((ch for ch in children if label(ch)=='WIN1'),None);l=next((ch for ch in children if label(ch)=='LOSS1_OR_REPLY2'),None)
 def witness(ch):
  if ch is None:return None
  first=(ch.get('opponent_winning_replies')or[None])[0]if 'opponent_winning_replies'in ch else ch['first_opponent_winning_reply']
  return {'action':ch['action'],'child_terminal':ch['child_terminal'],'full_child_sha256':ch['full_child_sha256'],'reply':first}
 return {'ply':k,'input_sha256':key,'full_state_sha256':digest(record_value(s.state)),'raw_terminal':record_value(s.state.terminal_status),'branching':len(children),'classes':dict(classes),'exact_win_loss_choice':bool(w and l),'restricted_closed_draw':all(restricted_class(raw,s.state).values()),'chosen_action_class':selected,'winning_witness':witness(w),'losing_witness':witness(l),'reply_edges':reply_edges,'seconds':secs,'exact_fixedprefix_reuse':known is not None,'child_class_digest':digest([{'action':ch['action'],'class':label(ch),'reply_count':oppwin(ch)}for ch in children])}
try:
 for ti,(_,_,_,mode,g)in enumerate(tasks):
  raw=worlds[mode][g['world']]['rule'];rh=digest(raw)
  if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
  c=contexts[rh];rule=ruleset_from_dict(raw);rec=deserialize_game_record(json.dumps(g['final_record']));s=GameSession(c);game={'mode':mode,'source_game_slot':g['slot'],'world':g['world'],'source_full_record_sha256':hashlib.sha256(json.dumps(g['final_record'],sort_keys=True).encode()).hexdigest(),'rule_sha256':rh,'turns':[],'status':'RUNNING'};path=D/f'{mode}-{g["slot"]:03d}.json'
  for k in range(len(rec.actions)+1):
   if time.perf_counter()-tick>=reg['hard_cap_seconds']:game['status']='CENSORED';break
   rr=record_value(replace(rec,actions=rec.actions[:k]));key=digest({'rule':raw,'record':rr});known=cache.get(key);row=compact(s,rule,rec,k,key,known);game['turns'].append(row);write_record(path,game)
   if known is None:out['new_turn_scans']+=1;out['new_reply_edges']+=row['reply_edges']
   else:out['fixedprefix_reuses']+=1
   if k<len(rec.actions):s.submit(rec.actions[k])
  if game['status']=='RUNNING':game['status']='CLOSED';assert record_value(s.state)==g['final_state']
  write_record(path,game);out['games'].append({'mode':mode,'source_game_slot':g['slot'],'world':g['world'],'status':game['status'],'recorded_states':len(game['turns']),'path':path.as_posix()});write_record(D/'results.json',out);print('DENSE',ti,mode,g['world'],g['slot'],len(game['turns']),out['new_turn_scans'],round(time.perf_counter()-tick,1),flush=True)
  if game['status']=='CENSORED':out['unattempted_games']=[{'mode':m,'slot':z['slot']}for _,_,_,m,z in tasks[ti+1:]];break
 out['status']='CLOSED'if not out['unattempted_games']and all(x['status']=='CLOSED'for x in out['games'])else'CENSORED'
except Exception as e:out['status']='FAILED';out['failures'].append({'error':repr(e),'traceback':traceback.format_exc()});raise
finally:out['seconds']=time.perf_counter()-tick;write_record(D/'results.json',out);print(out['status'],len(out['games']),out['new_turn_scans'],round(out['seconds'],1),flush=True)
