import json,sys,time
from pathlib import Path
from dataclasses import fields
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
D=P/'opening-resource';D.mkdir(exist_ok=True);reg={'question':'Do matchedinitial two-turn branches change terminal vulnerability because capturedstock permits defenses,despite identical physical boards?','selection':'ALLmatched22acceptedinitial rule slots,exact13rule pairsdeduplicated;all symmetric differences in saved opponent-winning replysets. No newgames/training/default changes.','expected_seconds':60,'hard_cap_seconds':180,'scope':'One-field capture-disposition intervention,not same-RuleSet board-only value impossibility. Sourcefullrules/history unchanged;completeCorelegaldefenses retained.'};write_record(D/'registration.json',reg);whole=json.loads((P/'whole-results.json').read_text());two=json.loads((P/'two-turn/whole-results.json').read_text());by={r['input_sha256']:r for r in two['results']};initial={(r['mode'],r['world']):r for r in whole['rows']if r['prefix']==0};worlds={mode:{w['index']:w for w in json.loads(Path(path).read_text())['worlds']}for mode,path in [('pocket','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-20261022/inputs.json')]};out={'registration':reg,'pairs':[],'differences':[],'status':'RUNNING'};seen=set();tick=time.perf_counter()
def find(s,raw):return next(a for a in s.legal_actions()if record_value(a)==raw)
for w in sorted(worlds['pocket']):
 ra=worlds['pocket'][w]['rule'];rb=worlds['remove'][w]['rule'];a=ruleset_from_dict(ra);b=ruleset_from_dict(rb);key=digest({'a':ra,'b':rb})
 if key in seen:continue
 seen.add(key);assert {k:v for k,v in ra.items()if k!='capture_disposition'}=={k:v for k,v in rb.items()if k!='capture_disposition'};ca,cb=compile_rule(a),compile_rule(b);ta=json.loads((P/'two-turn'/(by[initial['pocket',w]['input_sha256']]['tag']+'.json')).read_text());tb=json.loads((P/'two-turn'/(by[initial['remove',w]['input_sha256']]['tag']+'.json')).read_text());ma={digest(ch['action']):ch for ch in ta['children']};mb={digest(ch['action']):ch for ch in tb['children']};assert ma.keys()==mb.keys();n=0
 for actionkey in ma:
  x,y=ma[actionkey],mb[actionkey];rx={digest(r['action']):r for r in x['opponent_winning_replies']};ry={digest(r['action']):r for r in y['opponent_winning_replies']}
  for replykey in sorted(rx.keys()^ry.keys()):
   if time.perf_counter()-tick>=reg['hard_cap_seconds']:raise RuntimeError('boundedopeningresourcecap')
   reply=(rx.get(replykey)or ry[replykey])['action'];ss=[]
   for c in(ca,cb):
    s=GameSession(c);s.submit(find(s,x['action']));s.submit(find(s,reply));ss.append(s)
   pa,pb=ss[0].state.position,ss[1].state.position;diff=[f.name for f in fields(pa)if getattr(pa,f.name)!=getattr(pb,f.name)];assert set(diff)<= {'ruleset_fingerprint','hands'};entry={'world':w,'first_action':x['action'],'reply':reply,'position_fields_different':diff,'pocket_record':record_value(ss[0].to_record()),'remove_record':record_value(ss[1].to_record()),'pocket_full_state':record_value(ss[0].state),'remove_full_state':record_value(ss[1].state),'pocket_legal_responses':[record_value(z)for z in ss[0].legal_actions()],'remove_legal_responses':[record_value(z)for z in ss[1].legal_actions()]};out['differences'].append(entry);n+=1;write_record(D/'results.json',out)
 out['pairs'].append({'world':w,'initial_actions':len(ma),'terminal_reply_symmetric_differences':n})
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;write_record(D/'results.json',out);print('OPENINGRESOURCE',len(out['pairs']),len(out['differences']),round(out['seconds'],3));print([(d['world'],d['position_fields_different'],d['pocket_full_state']['terminal_status'],d['remove_full_state']['terminal_status'],len(d['pocket_legal_responses']),len(d['remove_legal_responses']))for d in out['differences']])
