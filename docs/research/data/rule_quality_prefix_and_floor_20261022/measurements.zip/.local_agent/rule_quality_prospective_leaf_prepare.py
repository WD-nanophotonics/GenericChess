import json,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P
from scripts.research_record import write_record,record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
D=P/'prospective-leaf-next';D.mkdir(exist_ok=True);configs=[]
for n in(4,6,8):
 for preset in('classic_like','free_random'):
  for symmetry in('bilateral','none'):configs.append({'seed':202610220900+len(configs),'board_size':n,'setup_preset':preset,'movement_symmetry':symmetry,'allow_hybrid':True,'max_generation_attempts':16,'require_no_opening_win_in_one':True})
reg={'question':'Does the newUnit-leaf edge overStatic-leaf survive a fresh predeclared rulesample with commonStaticordering and fixedFLOOR opponent?','premise':'Exposedacceptedleaf effects[3/22,7/22]Staticordering and[1/22,7/22]Unitordering arepositive,butplannedgeneration sensitivitiescrosszero andolderD2envelopesdisagree. No universalwinner ordefaultactivation.','prospective_configs':configs,'planned_game_slots':48,'arms':['Staticleaf/Staticorder','Unitleaf/Staticorder'],'roles':[0,1],'opponent':'SameFLOOR ruleWIN1elseuniformlocalRNG;fixedrole streams deriveconfigseed*1009+owner;candidatealgorithms unchanged.','caller_plies':96,'limits':{'max_depth':1,'max_nodes':8192,'max_time_seconds':1,'quiescence_max_depth':4,'quiescence_hard_max_depth':8},'whole_cap_seconds':900,'expected_seconds':180,'selection':'All12configs fixedbeforegeneration,16attemptlimit,no replacement/pricefitnessselection. OpeningpreferenceON onlyinthisdeclarednewexperiment,not a changedproductiondefault;fullpromotion/drop/futuretype/history retained.','no_coupled_UNKNOWN':'Differentcandidatepoliciesmaydivergeaftercap evenwhen savedprefixsame;independentfutureutility intervals unless extra proof.','status':'PREPAREINPUTS ONLY;fitnessgamesNOTRUN;no humanlabels,AUXwork,training ornewworker'};assert not(D/'registration.json').exists();write_record(D/'registration.json',reg);out={'registration':reg,'worlds':[],'failures':[],'fitness_queries':0,'status':'PREPARING'};tick=time.perf_counter()
for i,cfg in enumerate(configs):
 try:
  g=generate_game(GeneratorConfig(**cfg));raw=ruleset_to_dict(g.ruleset);entry={'index':i,'config':cfg,'rule':raw,'generation_report':record_value(g.generation_report)};out['worlds'].append(entry);write_record(D/'inputs.json',out);c=compile_rule(g.ruleset);s=GameSession(c);entry.update(initial_record=record_value(s.to_record()),initial_full_state=record_value(s.state),initial_legal_actions=len(s.legal_actions()));write_record(D/'inputs.json',out)
 except Exception as e:out['failures'].append({'index':i,'config':cfg,'error':repr(e),'traceback':traceback.format_exc()});write_record(D/'inputs.json',out)
out['status']='PREPARED_NOTRUN';out['seconds']=time.perf_counter()-tick;write_record(D/'inputs.json',out);print('NEXTINPUTS',len(out['worlds']),len(out['failures']),out['fitness_queries'],round(out['seconds'],3))
