import json,sys,time,random,traceback
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
D=P/'terminal-floor-factorial';data=json.loads((D/'results.json').read_text());assert data['status']=='CLOSED';derived={(g['mode'],g['slot']):g for g in data['games']};out={'status':'RUNNING','qualified_unique_policy_cells':0,'actual_uniform_actions':0,'candidate_oneply_scans':0,'activated':0,'unchanged':0,'failures':[],'scope':'Fresh exactRNG/Coreexecution ofbothone-sidedfloorcells with original96plycaller;no assumedsharedpostcap policyutility.'};contexts={};tick=time.perf_counter()
try:
 for cell,role in [('B',0),('C',1)]:
  for mode,rp,ip in [('pocket','.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-random-20261022/results.json','.local_agent/rule-quality-capture-20261022/inputs.json')]:
   src=json.loads(Path(rp).read_text());worlds={w['index']:w for w in json.loads(Path(ip).read_text())['worlds']}
   for g in src['games']:
    if g['reused_from']is not None:continue
    raw=worlds[g['world']]['rule'];rh=digest(raw)
    if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
    c=contexts[rh];rec=deserialize_game_record(json.dumps(g['final_record']));s=GameSession.replay(c,replace(rec,actions=()));seed=worlds[g['world']]['config']['seed']*1009+g['pair']*2;rng={0:random.Random(seed+g['swap']),1:random.Random(seed+1-g['swap'])};activation=None
    for k in range(96):
     if s.state.terminal_status.is_terminal:break
     actor=s.state.position.side_to_move;win=None
     if actor==role:
      legal=[]
      for a,ch in legal_successors(s.state,c):
       legal.append(a)
       if ch.terminal_status.winner==actor:win=a;break
      out['candidate_oneply_scans']+=1
     else:legal=s.legal_actions()
     if win is not None:activation=k;s.submit(win);out['activated']+=1;break
     assert k<len(rec.actions);a=legal[rng[actor].randrange(len(legal))];assert a==rec.actions[k];s.submit(a);out['actual_uniform_actions']+=1
    row=derived[mode,g['slot']]['cells'][cell];observed={'cell':cell,'mode':mode,'slot':g['slot'],'activation':activation,'full_record':record_value(s.to_record()),'full_state':record_value(s.state)};write_record(D/f'verifier-{cell}-{mode}-{g["slot"]:03d}.json',observed);assert activation==row['first_activation_ply'];assert observed['full_record']==row['full_record'];assert observed['full_state']==row['full_state'];assert s.state.ply_count<=96
    if activation is None:out['unchanged']+=1;assert observed['full_record']==g['final_record'];assert observed['full_state']==g['final_state']
    out['qualified_unique_policy_cells']+=1
    if out['qualified_unique_policy_cells']%32==0:write_record(D/'qualification.json',out);print('FLOORFACTORQUAL',out['qualified_unique_policy_cells'],round(time.perf_counter()-tick,1),flush=True)
 out['status']='CLOSED'
except Exception as e:out['status']='FAILED';out['failures'].append({'error':repr(e),'traceback':traceback.format_exc()});raise
finally:out['seconds']=time.perf_counter()-tick;write_record(D/'qualification.json',out);print(out['status'],out['qualified_unique_policy_cells'],round(out['seconds'],1),flush=True)
