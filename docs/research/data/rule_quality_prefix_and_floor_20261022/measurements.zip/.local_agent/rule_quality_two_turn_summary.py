import json,sys
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P
from scripts.research_record import write_record
D=P/'two-turn';r=json.loads((D/'whole-results.json').read_text());p=json.loads((P/'whole-results.json').read_text());by={x['input_sha256']:x for x in r['results']};out={'scope':'SharedCore depth-two terminal witnesses;counts are finite repeatedviews,not independentstates/populationCI,fullWDL coverage or learnedprice utility.','strata':[],'unique_roots':len(by),'reply_edges':sum(x['reply_edges']for x in r['results']),'whole_seconds':r['seconds']}
for mode in('pocket','remove'):
 for prefix in(0,4,16,64):
  rows=[x for x in p['rows']if x['mode']==mode and x['prefix']==prefix and x.get('input_sha256')];a=[by[x['input_sha256']]for x in rows];ongo=[z for x,z in zip(rows,a)if x['root_terminal']['status']=='ongoing'];out['strata'].append({'mode':mode,'prefix':prefix,'available_views':len(a),'ongoing_views':len(ongo),'exact_win_loss_choice_views':sum(x['exact_win_loss_choice']for x in ongo),'oneply_win_views':sum(x['immediate_win_actions']>0 for x in ongo),'reply_loss_exposure_views':sum(x['immediate_loss_actions']>0 for x in ongo),'all_actions_lose_within_reply_views':sum(x['immediate_loss_actions']>0 and x['other_actions']==0 and x['immediate_win_actions']==0 for x in ongo),'other_unknown_actions_retained':sum(x['other_actions']for x in ongo)})
write_record(D/'summary.json',out);print(json.dumps(out,indent=2));total=0
for rp in('.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-capture-random-20261022/results.json'):
 d=json.loads(Path(rp).read_text());n=sum(len(g['final_record']['actions'])for g in d['games']if g['reused_from']is None);total+=n;print(rp,'turns',n)
print('allturn estimate using paidmean',total*r['seconds']/len(by))
