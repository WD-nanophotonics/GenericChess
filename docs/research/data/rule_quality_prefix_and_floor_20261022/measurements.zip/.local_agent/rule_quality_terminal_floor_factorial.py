import json,sys,time
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
from collections import Counter,defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=P/'terminal-floor-factorial';D.mkdir(exist_ok=True);reg=json.loads((P/'terminal-floor-factorial-registration.json').read_text());allfirst=json.loads((P/'first-win/results.json').read_text());assert allfirst['status']=='CLOSED';dby={(x['mode'],x['slot']):x for x in allfirst['games']};out={'registration':reg,'status':'RUNNING','games':[],'failures':[]};contexts={};tick=time.perf_counter()
for mode,rp,ip in [('pocket','.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-random-20261022/results.json','.local_agent/rule-quality-capture-20261022/inputs.json')]:
 src=json.loads(Path(rp).read_text());worlds={w['index']:w for w in json.loads(Path(ip).read_text())['worlds']};by={}
 for g in src['games']:
  if time.perf_counter()-tick>reg['hard_cap_seconds']:raise RuntimeError('factorialbudget')
  if g['reused_from']is not None:r={**by[g['reused_from']],'world':g['world'],'slot':g['slot'],'exact_source_reuse':g['reused_from']};out['games'].append(r);by[g['slot']]=r;continue
  raw=worlds[g['world']]['rule'];rh=digest(raw)
  if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
  c=contexts[rh];rec=deserialize_game_record(json.dumps(g['final_record']));dense=json.loads((P/'dense'/f'{mode}-{g["slot"]:03d}.json').read_text());cells={'A':{'first_activation_ply':None,'full_record':g['final_record'],'full_state':g['final_state'],'terminal':g['terminal']},'D':{'first_activation_ply':dby[mode,g['slot']]['first_activation_ply'],'full_record':dby[mode,g['slot']]['derived_record'],'full_state':dby[mode,g['slot']]['derived_full_state'],'terminal':dby[mode,g['slot']]['derived_terminal']}}
  for cell,role in [('B',0),('C',1)]:
   first=next((x for x in dense['turns'][:-1]if x['classes'].get('WIN1',0)and x['ply']%2==role),None)
   if first is None:cells[cell]=dict(cells['A']);continue
   k=first['ply'];s=GameSession.replay(c,replace(rec,actions=rec.actions[:k]));assert s.state.position.side_to_move==role;w=first['winning_witness'];a=next(a for a in s.legal_actions()if record_value(a)==w['action']);s.submit(a);cellrow={'first_activation_ply':k,'full_record':record_value(s.to_record()),'full_state':record_value(s.state),'terminal':record_value(s.result)};write_record(D/f'{mode}-{g["slot"]:03d}-{cell}.json',cellrow);assert s.result.winner==role;assert digest(record_value(s.state))==w['full_child_sha256'];cells[cell]=cellrow
  r={'mode':mode,'world':g['world'],'slot':g['slot'],'exact_source_reuse':None,'cells':cells};out['games'].append(r);by[g['slot']]=r
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;write_record(D/'results.json',out)
def sym(terminal,key):
 if terminal['status']=='ongoing':return Fraction(),{key:Fraction(1)}
 assert terminal['status']!='no_contest';return Fraction(0 if terminal['winner']is None else 1 if terminal['winner']==0 else -1),{}
def lin(items):
 const=Fraction();coeff=defaultdict(Fraction)
 for scale,(c,cs)in items:
  const+=scale*c
  for k,v in cs.items():coeff[k]+=scale*v
 return const,{k:v for k,v in coeff.items()if v}
def bounds(x):return [str(x[0]-sum(map(abs,x[1].values()),Fraction())),str(x[0]+sum(map(abs,x[1].values()),Fraction()))]
summary={'scope':'Finite utility effects with exactsame UNKNOWN variable for unchangedsource/cells;no independentimputation/poplulationCI. Effectis game-policyterminalfloor excluding computationcost,not learnedprices.','strata':[]}
for mode in('pocket','remove'):
 rows=[r for r in out['games']if r['mode']==mode];effects=defaultdict(list)
 for row in rows:
  key=(mode,row['exact_source_reuse']if row['exact_source_reuse']is not None else row['slot']);s={k:sym(v['terminal'],key)for k,v in row['cells'].items()};effects['B-A'].append(lin([(1,s['B']),(-1,s['A'])]));effects['D-C'].append(lin([(1,s['D']),(-1,s['C'])]));effects['interaction'].append(lin([(1,s['D']),(-1,s['C']),(-1,s['B']),(1,s['A'])]));effects['rolebalanced_gain_vs_RNG'].append(lin([(Fraction(1,2),s['B']),(-Fraction(1,2),s['C'])]));effects['rolebalanced_gain_vs_FLOOR'].append(lin([(Fraction(1,2),s['D']),(-Fraction(1,2),s['C']),(Fraction(1,2),s['B']),(-Fraction(1,2),s['D'])]));assert effects['rolebalanced_gain_vs_RNG'][-1]==effects['rolebalanced_gain_vs_FLOOR'][-1]
 agg={k:bounds(lin([(Fraction(1,len(rows)),x)for x in xs]))for k,xs in effects.items()};summary['strata'].append({'mode':mode,'views':len(rows),'unique':sum(r['exact_source_reuse']is None for r in rows),'cells':{cell:dict(Counter(r['cells'][cell]['terminal']['status']for r in rows))for cell in('A','B','C','D')},'first_player_win_counts':{cell:sum(r['cells'][cell]['terminal']['winner']==0 for r in rows)for cell in('A','B','C','D')},'effects_firstplayer_utility':agg,'generationmissing_views':16,'no_refill':True})
write_record(D/'summary.json',summary);print('FACTORIAL',len(out['games']),round(out['seconds'],3));print(json.dumps(summary,indent=2))
