import json,sys,time,random
from pathlib import Path
from fractions import Fraction
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from rule_quality_prefix import P
D=P/'crossed-price-next/full'
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
r=json.loads((D/'results.json').read_text());assert r['status']=='CLOSED'and not r['unattempted_slots'];worlds={w['index']:w for w in json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text())['worlds']};contexts={};out={'games':[],'candidate_queries':0,'floor_queries':0,'history_plies':0,'pv_plies':0,'candidate_sources':{},'failures':[],'scope':'Separate fullCorehistory/PV and exactfloorpolicy/RNG qualification;not independentengine,randomsample or universalD1 superiority.'};sources=Counter();tick=time.perf_counter()
for slot in r['slots']:
 if slot['status']=='generation_unavailable':continue
 g=json.loads((D/slot['receipt']).read_text());w=slot['world'];role=slot['candidate_role']
 if w not in contexts:contexts[w]=compile_rule(ruleset_from_dict(worlds[w]['rule']))
 c=contexts[w];s=GameSession(c);rec=deserialize_game_record(json.dumps(g['final_record']));seed=worlds[w]['config']['seed']*1009;rng={0:random.Random(seed),1:random.Random(seed+1)};assert len(g['queries'])==len(rec.actions)
 for qi,(a,q)in enumerate(zip(rec.actions,g['queries'])):
  actor=s.state.position.side_to_move;assert q['root_ply']==qi and q['actor']==actor;legal=list(legal_successors(s.state,c))
  if q['policy']=='D1':
   dec=q['decision'];assert dec['runtime_depth_balanced'];assert record_value(a)==dec['action'];pv=s.state
   for raw in dec['principal_variation']:_,pv=next((b,ch)for b,ch in legal_successors(pv,c)if record_value(b)==raw);out['pv_plies']+=1
   if dec['result_source']=='root_immediate_win':assert pv.terminal_status.winner==actor
   sources[(dec['completed_depth'],dec['result_ordinary_qdepth'],dec['result_source'])]+=1;out['candidate_queries']+=1
  else:
   win=next((b for b,ch in legal if ch.terminal_status.winner==actor),None);expected=win if win is not None else legal[rng[actor].randrange(len(legal))][0];assert expected==a;assert q['floor']['winning_action_found']==(win is not None);assert q['floor']['complete_or_winning'];out['floor_queries']+=1
  s.submit(a);out['history_plies']+=1
 assert record_value(s.state)==g['final_state'];assert record_value(s.result)==g['terminal'];out['games'].append({'slot':slot['slot'],'world':w,'candidate_role':role,'eligible':g['eligible'],'terminal':g['terminal'],'candidate_utility_interval':g['candidate_utility_interval'],'full_history_and_policy_verified':True})
out['candidate_sources']={str(k):v for k,v in sources.items()};out['seconds']=time.perf_counter()-tick;out['all_passed']=True;write_record(D/'qualified.json',out);print('CROSSEDQUAL',len(out['games']),out['candidate_queries'],out['floor_queries'],out['history_plies'],out['pv_plies'],round(out['seconds'],3))
