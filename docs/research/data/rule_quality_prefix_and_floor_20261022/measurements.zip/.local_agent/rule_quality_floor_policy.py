import sys,json,time,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.core.transition import legal_successors
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from rule_quality_prefix import P
D=P/'floor-competence';D.mkdir(exist_ok=True)
def floor_action(s,rng,seconds=1.0):
 tick=time.perf_counter();legal=[];actor=s.state.position.side_to_move;winner=None;complete=True
 for a,ch in legal_successors(s.state,s.compiled):
  legal.append(a)
  if time.perf_counter()-tick>=seconds:complete=False;break
  if ch.terminal_status.winner==actor:winner=a;break
 action=winner if winner is not None else legal[rng.randrange(len(legal))]if complete and legal else None
 return action,{'winning_action_found':winner is not None,'enumerated_children':len(legal),'complete_or_winning':complete,'seconds':time.perf_counter()-tick}
if __name__=='__main__':
 inputs=json.loads((P/'preflight-inputs.json').read_text());out={'question':'Is terminal-floor control operationally affordable before testing nontrivial D1 competence against it?','selection':'Same24metadata-selected fullstates,one matcheduniform/floor turn each,no repetition/outcomeselection. Corebotharms;not incrementaldefaultNative cost.','rows':[],'status':'RUNNING'};tick=time.perf_counter()
 for i,item in enumerate(inputs['inputs']):
  c=compile_rule(ruleset_from_dict(item['rule']));rec=deserialize_game_record(json.dumps(item['record']))
  for arm in(['uniform','floor']if i%2==0 else['floor','uniform']):
   s=GameSession.replay(c,rec);rng=random.Random(202610220400+i);t=time.perf_counter()
   if arm=='uniform':legal=s.legal_actions();a=legal[rng.randrange(len(legal))];detail={'enumerated_children':0,'complete_or_winning':True}
   else:a,detail=floor_action(s,rng)
   elapsed=time.perf_counter()-t;row={'input':i,'mode':item['mode'],'world':item['world'],'prefix':item['prefix'],'arm':arm,'action':record_value(a),'decision_seconds':elapsed,'detail':detail};out['rows'].append(row);write_record(D/'cost-preflight.json',out);assert a is not None;s.submit(a)
 out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;write_record(D/'cost-preflight.json',out);print('FLOORCOST',len(out['rows']),round(out['seconds'],3),'max',max(x['decision_seconds']for x in out['rows']if x['arm']=='floor'))
