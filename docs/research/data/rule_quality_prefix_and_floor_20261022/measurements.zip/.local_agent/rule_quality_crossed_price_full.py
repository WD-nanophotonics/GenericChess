import json,sys,time,random,traceback,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from rule_quality_floor_policy import floor_action
D=P/'crossed-price-next/full';D.mkdir(exist_ok=True,parents=True)
from dataclasses import replace
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
class Adapter:
 def __init__(self,leaf,order):self.evaluate=leaf.evaluate;self.type_value=order.type_value;self.capture_order_value=order.capture_order_value
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.benchmark.runner import _timing_invalid
src=Path('.local_agent/rule-quality-survey-20261022/inputs.json');inp=json.loads(src.read_text());worlds={w['index']:w for w in inp['worlds']};pre=json.loads((P/'floor-competence/cost-preflight.json').read_text());assert pre['status']=='CLOSED'and max(x['decision_seconds']for x in pre['rows']if x['arm']=='floor')<1
reg={'question':'Whichpart ofthe newwholeprice edge is leaf versusordering,under the samefixedFLOOR opponent?','changed_premise':'UnitON-Static[1/22,7/22]acceptedwholeprice effect;two crossedcoldprototypes passfullPV/sameleafscore. Need missing twofactorialcells,not leaf-only attribution fromdiagonals.','selection':'All24original prospectiveconfiguration slots;22acceptedfullrules+2generationrefusals;Two crossedleaf/order arms timesbothroles96intendedgames88available. No newgeneration orfavorableworldselection.','input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate':'Three-methodAdapter with StaticLeaf/UnitOrder arm0 orUnitLeaf/StaticOrder arm1;defaultdynamicweights retained;existingAlphaBeta Nativelegality,depth1,q4hard8,nodes8192,1s perdecision;freshplayer/game,TTpersistswithin own game;diskcacheOFF.','opponent':'FixedCoreFLOOR: firstactualruleWIN1 elseuniformlegal withoriginalpair0swap0 actorRNGstream;1s decisioncap;incompletescan censors instead of inventedfallback. Samepolicy inbothcandidate roles.','source_baseline':'Reuse44StaticLeaf/StaticOrder and44UnitLeaf/UnitOrder games fromfloor-competence andfloor-unit-control asdiagonals. DifferentcandidatepolicyUNKNOWN remain distinctevenifsame96plyprefix;no common-tail assumption.','caller_plies':96,'whole_cap_seconds':900,'expected_seconds':600,'limits':{'max_depth':1,'max_nodes':8192,'max_time_seconds':1.0,'quiescence_max_depth':4,'quiescence_hard_max_depth':8},'shuffle_seed':202610220422,'cost_preflight':str(P/'floor-competence/cost-preflight.json'),'cost_preflight_max_seconds':max(x['decision_seconds']for x in pre['rows']if x['arm']=='floor'),'scope':'Newfinitecompetence diagnostic,not pricelearning/transfer,Elo,populationquality ordefaultactivation. AllUNKNOWN/fallback/invalidturns retained;no caprefill.'};assert not(D/'results.json').exists();write_record(D/'registration.json',reg);slots=[{'slot':4*w+2*role+arm,'world':w,'candidate_role':role,'leaf_order_arm':arm,'status':'not_started','candidate_utility_interval':[-1,1]}for w in range(24)for role in(0,1)for arm in(0,1)];order=list(range(96));random.Random(reg['shuffle_seed']).shuffle(order);out={'registration':reg,'slots':slots,'execution_order':order,'status':'RUNNING','candidate_queries':0,'floor_queries':0,'failures':[]};contexts={};tick=time.perf_counter();write_record(D/'results.json',out)
for ix in order:
 if time.perf_counter()-tick>=reg['whole_cap_seconds']:break
 slot=slots[ix];w=slot['world'];role=slot['candidate_role']
 if w not in worlds:slot['status']='generation_unavailable';continue
 t=time.perf_counter();raw=worlds[w]['rule'];rh=digest(raw)
 if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
 c=contexts[rh];s=GameSession(c);base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;board={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()};hand={t:0 if m.is_anchor or base.hand_value_by_base_type[t]==0 else 900 for t,m in c.support.type_metadata.items()};unit=replace(base,board_value_by_type=board,hand_value_by_base_type=hand,promotion_gain_by_type={t:0 for t in board},median_non_anchor_value=1000,piece_profiles={t:replace(p,normalized_board_value=board[t],normalized_hand_value=hand[t],promotion_option_value=0)for t,p in base.piece_profiles.items()});es=Evaluator(c,base,EvaluationConfig());eu=Evaluator(c,unit,EvaluationConfig());mixed=Adapter(es,eu)if slot['leaf_order_arm']==0 else Adapter(eu,es);player=AlphaBetaPlayer(c,evaluator_override=mixed,use_disk_cache=False);seed=worlds[w]['config']['seed']*1009;rng={0:random.Random(seed),1:random.Random(seed+1)};row={**slot,'queries':[],'failure':None,'censor':None};path=D/f'game-{ix:03d}.json';write_record(path,row)
 try:
  while not s.state.terminal_status.is_terminal and s.state.ply_count<reg['caller_plies']:
   if time.perf_counter()-tick>=reg['whole_cap_seconds']:row['censor']='whole_cap';break
   actor=s.state.position.side_to_move;row['current_record']=record_value(s.to_record());write_record(path,row);qstart=time.perf_counter()
   if actor==role:
    dec=player.choose_action(s,SearchLimits(**reg['limits']));elapsed=time.perf_counter()-qstart;action=dec.action;receipt={'root_ply':s.state.ply_count,'actor':actor,'policy':'D1','decision':record_value(dec),'seconds':elapsed};out['candidate_queries']+=1
   else:
    action,detail=floor_action(s,rng[actor],reg['limits']['max_time_seconds']);elapsed=time.perf_counter()-qstart;receipt={'root_ply':s.state.ply_count,'actor':actor,'policy':'FLOOR','action':record_value(action),'floor':detail,'seconds':elapsed};out['floor_queries']+=1
   row['queries'].append(receipt);write_record(path,row)
   if _timing_invalid(elapsed,reg['limits']['max_time_seconds']):row['censor']='timing_invalid';break
   if action is None:row['censor']='incomplete_floor_or_candidate_no_action';break
   s.submit(action)
 except Exception as e:row['failure']={'error':repr(e),'traceback':traceback.format_exc()};out['failures'].append({'slot':ix,**row['failure']})
 row.update(final_record=record_value(s.to_record()),final_state=record_value(s.state),terminal=record_value(s.result),seconds=time.perf_counter()-t);row.pop('current_record',None);fallback=any(q['policy']=='D1'and(q['decision']['result_source']in('fallback','legal_fallback','root_scan_fallback')or q['decision']['termination_reason']=='fallback')for q in row['queries']);operational=any(q['policy']=='D1'and q['decision']['native_legality_operational_failures']for q in row['queries']);row['eligible']=not(row['failure']or row['censor']or fallback or operational);row['fallback']=fallback;row['operational_failure']=operational;value=None if not row['eligible']or row['terminal']['status']in('ongoing','no_contest')else 0 if row['terminal']['winner']is None else 1 if row['terminal']['winner']==role else-1;row['candidate_utility_interval']=[value,value]if value is not None else[-1,1];row['status']='finished';write_record(path,row);slot.update(status='finished',receipt=path.name,terminal=row['terminal'],candidate_utility_interval=row['candidate_utility_interval'],eligible=row['eligible'],plies=s.state.ply_count,seconds=row['seconds']);write_record(D/'results.json',out);print('COMPETENCE',ix,w,role,row['terminal'],row['candidate_utility_interval'],s.state.ply_count,round(time.perf_counter()-tick,1),flush=True)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;out['unattempted_slots']=[x['slot']for x in slots if x['status']=='not_started'];write_record(D/'results.json',out);print('CLOSED',out['candidate_queries'],out['floor_queries'],len(out['unattempted_slots']),round(out['seconds'],1),flush=True)
