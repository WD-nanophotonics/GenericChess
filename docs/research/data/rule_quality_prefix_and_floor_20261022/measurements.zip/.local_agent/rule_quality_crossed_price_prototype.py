import json,sys,time
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.limits import SearchLimits
D=P/'crossed-price-next';D.mkdir(exist_ok=True);w=json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text())['worlds'][0];c=compile_rule(ruleset_from_dict(w['rule']));config=EvaluationConfig();base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;board={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()};hand={t:0 if m.is_anchor or base.hand_value_by_base_type[t]==0 else 900 for t,m in c.support.type_metadata.items()};unit=replace(base,board_value_by_type=board,hand_value_by_base_type=hand,promotion_gain_by_type={t:0 for t in board},median_non_anchor_value=1000,piece_profiles={t:replace(p,normalized_board_value=board[t],normalized_hand_value=hand[t],promotion_option_value=0)for t,p in base.piece_profiles.items()});ev={'Static':Evaluator(c,base,config),'Unit':Evaluator(c,unit,config)}
class Adapter:
 def __init__(self,leaf,order):self.evaluate=leaf.evaluate;self.type_value=order.type_value;self.capture_order_value=order.capture_order_value
reg={'question':'Does the newwholepricepolicy edge survive fixedordering,or depend on leaf/order interaction?','premise':'UnitON-Static vsfixedFLOOR[1/22,7/22]accepted;wholepricepolicy cannotidentify leaf contribution. Oneplyargmax shortcuts fail at checkedleaves;useactualmaintainedsearch with hardcheck8.','next_full_phase':'NOTRUN.88available/96intended newgames:two crossedcells times2roles times24originalslots;reuse88existingdiagonalgames,all8missinggenroles retained.','expected_seconds':180,'hard_cap_seconds':900,'opponent':'Same fixedFLOOR/RNGstreams and1s/depth1/nodes8192/q4hard8/caller96 protocol;freshplayer,TTwithin game,diskOFF.','prototype_selection':'One metadatafirstoriginalworld0initialroot,not outcome-selected;two coldactual queries tovalidate existing3methodAdapter with fullsemantics. Not strength evidence.'};write_record(D/'registration.json',reg);s=GameSession(c);write_record(D/'prototype-input.json',{'rule':w['rule'],'record':record_value(s.to_record()),'static_profile':record_value(base),'unit_profile':record_value(unit),'config':record_value(config)});out={'registration':reg,'queries':[]};limits=SearchLimits(max_depth=1,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=4,quiescence_hard_max_depth=8)
for leaf,order in [('Static','Unit'),('Unit','Static')]:
 player=AlphaBetaPlayer(c,evaluator_override=Adapter(ev[leaf],ev[order]),use_disk_cache=False);t=time.perf_counter();d=player.choose_action(s,limits);row={'leaf':leaf,'order':order,'decision':record_value(d),'seconds':time.perf_counter()-t};out['queries'].append(row);write_record(D/'prototype-results.json',out);assert d.completed_depth==1;assert any(a==d.action for a in s.legal_actions());st=s.state
 for a in d.principal_variation:st=next(ch for b,ch in legal_successors(st,c)if b==a)
 baseline=json.loads((P/('floor-competence'if leaf=='Static'else'floor-unit-control')/'game-000.json').read_text());ref=baseline['queries'][0]['decision'];row['same_leaf_complete_score_matches_diagonal']=d.score==ref['score'];row['full_literal_PV_legal']=True;assert row['same_leaf_complete_score_matches_diagonal'];write_record(D/'prototype-results.json',out)
print('CROSSEDPROTOTYPE',[(x['leaf'],x['order'],x['decision']['score'],x['same_leaf_complete_score_matches_diagonal'],x['full_literal_PV_legal'])for x in out['queries']]);print('fullfactorialNOTRUN;no caprefill,normaldefaultunchanged')
