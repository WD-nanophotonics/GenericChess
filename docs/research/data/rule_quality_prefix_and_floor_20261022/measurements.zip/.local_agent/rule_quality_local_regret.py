import json,sys
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
from rule_quality_prefix import P
D=P/'two-turn';whole=json.loads((D/'whole-results.json').read_text());prefix=json.loads((P/'whole-results.json').read_text());out={'question':'Can local terminal witnesses provide a truthful decision-loss bound without complete WDL or selecting training data?','scope':'Uniformfirstaction then adversarial continuation;oneplyWIN1 is optimal+1. Unknownchild WDL remains[-1,1]. This is diagnostic lowerbound,not empirical matchperformance or a learning gain.','roots':[],'strata':[]};by={}
for item in whole['results']:
 r=json.loads((D/(item['tag']+'.json')).read_text());a=r['actor'];children=r['children'];w=sum(ch['child_terminal']['winner']==a for ch in children);l=sum(ch['child_terminal']['winner']==1-a or bool(ch['opponent_winning_replies'])for ch in children);d=sum(ch['child_terminal']['status']not in('ongoing','no_contest')and ch['child_terminal']['winner']is None for ch in children);u=len(children)-w-l-d;n=len(children)
 assert min(w,l,d,u)>=0
 row={'input_sha256':r['input_sha256'],'mode':r['mode'],'world':r['world'],'prefix':r['prefix'],'branching':n,'WIN1':w,'LOSS1_OR_REPLY2':l,'DRAW1':d,'UNKNOWN':u,'optimal_plus1_certified':bool(w),'uniform_first_action_adversarial_value_interval':[str(Fraction(w-l-u,n)),str(Fraction(w-l+u,n))]if n else None,'regret_interval_if_root_WIN':[str(Fraction(2*l+d,n)),str(Fraction(2*l+d+2*u,n))]if w else None};out['roots'].append(row);by[row['input_sha256']]=row
for mode in('pocket','remove'):
 for k in(0,4,16,64):
  rows=[by[x['input_sha256']]for x in prefix['rows']if x['mode']==mode and x['prefix']==k and x.get('input_sha256')and x['root_terminal']['status']=='ongoing'];wins=[x for x in rows if x['optimal_plus1_certified']];bounds=[sum((Fraction(x['regret_interval_if_root_WIN'][j])for x in wins),Fraction())/len(wins)for j in(0,1)]if wins else None;out['strata'].append({'mode':mode,'prefix':k,'ongoing_views':len(rows),'certified_WIN_views':len(wins),'conditional_uniform_regret_interval_on_WIN':list(map(str,bounds))if bounds else None,'unconditional_nonnegative_regret_lowerbound_over_ongoing':str(sum((Fraction(x['regret_interval_if_root_WIN'][0])for x in wins),Fraction())/len(rows))if rows else None})
write_record(D/'local-regret-bounds.json',out);print(json.dumps(out['strata'],indent=2));print('Rootknown28',[(x['mode'],x['world'],x['regret_interval_if_root_WIN'])for x in out['roots']if x['prefix']==0 and x['world']==16])
