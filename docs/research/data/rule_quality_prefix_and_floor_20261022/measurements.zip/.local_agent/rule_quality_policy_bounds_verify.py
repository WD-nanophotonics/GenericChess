import json,sys,itertools,time
from pathlib import Path
from fractions import Fraction
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P
from scripts.research_record import write_record
D=P/'terminal-floor-factorial';r=json.loads((D/'policy-distinct-bounds.json').read_text());cache={};out={'method':'Independent4D halfspace-vertex intersection solver;enumeratedomainvalue grids are not reused. Boundedorderpolytope vertices found fromall4plane intersections;Gaussianlinear solve and allinequality feasibility.','checked_source_layer_cases':0,'unique_domain_patterns':0,'qualified_objective_extrema':0,'failures':[]};tick=time.perf_counter();objectives={'B-A':np.array([-1,1,0,0.]),'D-C':np.array([0,0,-1,1.]),'interaction':np.array([1,-1,-1,1.]),'rolebalanced_gain':np.array([0,.5,-.5,0.])}
for layer in r['layers']:
 for row in layer['per_source']:
  ds=tuple(tuple(row['domains'][k])for k in('A','B','C','D'))
  if ds not in cache:
   aa=[];bb=[]
   for i,d in enumerate(ds):
    e=np.zeros(4);e[i]=1;aa.extend([e,-e]);bb.extend([max(d),-min(d)])
   aa.extend([np.array([1,-1,0,0]),np.array([-1,0,1,0]),np.array([0,-1,0,1]),np.array([0,0,1,-1])]);bb.extend([0,0,0,0]);A=np.array(aa);b=np.array(bb);vertices=[]
   for ix in itertools.combinations(range(len(b)),4):
    M=A[list(ix)];v=b[list(ix)]
    if abs(np.linalg.det(M))<1e-10:continue
    x=np.linalg.solve(M,v)
    if np.max(A@x-b)<=1e-8:vertices.append(x)
   assert vertices;cache[ds]={k:[float(min(np.dot(v,x)for x in vertices)),float(max(np.dot(v,x)for x in vertices))]for k,v in objectives.items()}
  for k,expected in row['effects'].items():
   got=cache[ds][k];assert all(abs(float(Fraction(y))-x)<1e-8 for x,y in zip(got,expected)),(row,k,got,expected);out['qualified_objective_extrema']+=1
  out['checked_source_layer_cases']+=1
out['unique_domain_patterns']=len(cache);out['seconds']=time.perf_counter()-tick;out['all_passed']=True;write_record(D/'policy-bounds-qualification.json',out);print(json.dumps(out,indent=2))
