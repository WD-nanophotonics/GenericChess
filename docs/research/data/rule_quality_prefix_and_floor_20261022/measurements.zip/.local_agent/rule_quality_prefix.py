"""Fixed label-blind prefix census of existing full trajectories; no new play/search."""
import json,sys,time,hashlib,traceback
from pathlib import Path
from collections import Counter
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.generation.piece_generator import KING_ATOMS
P=Path('.local_agent/rule-quality-prefix-next-20261022')
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def restricted_class(rule,state):
 pcs=[x for x in state.position.board if x]
 k=next((t for t in rule.piece_types if t.type_id=='K'),None)
 checks={'two_distinct_owners':len(pcs)==2 and {x.owner for x in pcs}=={0,1},'unpromotedK':all(x.base_type_id=='K'and x.current_type_id=='K'and not x.promoted for x in pcs),'empty_hands':not any(h.total()for h in state.position.hands),'no_aux':not state.position.aux_state,'remove_capture':rule.capture_disposition=='remove_from_game','draw_repetition':rule.repetition_policy=='draw','draw_stalemate':rule.stalemate_result=='draw','finite_clock':rule.max_ply is not None and 0<rule.max_ply<=512,'no_custom_actions':not rule.semantic_actions,'no_declarations':not rule.declarations,'no_automatic':not rule.automatic_adjudications,'no_consecutive':not rule.consecutive_action_adjudications,'no_target_conditions':not rule.repeated_cycle_target_conditions,'no_progress_override':rule.no_progress_draw is None,'no_pass':not rule.pass_enabled,'king_geometry':k is not None and k.movement_atoms==KING_ATOMS and k.is_anchor and not k.is_promotable and not k.promotion_target_ids}
 return checks
contexts={}
def measure(item,tag):
 tick=time.perf_counter();raw=item['rule'];rh=digest(raw)
 if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
 c=contexts[rh];rule=ruleset_from_dict(raw);rec=deserialize_game_record(json.dumps(item['record']));sess=GameSession.replay(c,rec);replayed=time.perf_counter();state=sess.state;owner=state.position.side_to_move;children=[]
 for a,ch in legal_successors(state,c):
  children.append({'action':record_value(a),'terminal':record_value(ch.terminal_status),'full_child_sha256':digest(record_value(ch))})
 r={'tag':tag,'mode':item['mode'],'world':item['world'],'source_game_slot':item['source_game_slot'],'prefix':item['prefix'],'boardsize':rule.board_shape.width,'input_sha256':digest({'rule':raw,'record':item['record']}),'rule_sha256':rh,'full_state':record_value(state),'record':item['record'],'root_terminal':record_value(state.terminal_status),'actor':owner,'branching':len(children),'children':children,'winning_children':sum(x['terminal']['winner']==owner for x in children),'closed_preconditions':restricted_class(rule,state),'replay_seconds':replayed-tick,'seconds':time.perf_counter()-tick}
 r['restricted_closed_draw']=all(r['closed_preconditions'].values());write_record(P/'receipts'/f'{tag}.json',r);return r
if __name__=='__main__':
 mode=sys.argv[1];tick=time.perf_counter();out={'phase':mode,'status':'RUNNING','results':[],'failures':[],'scope':'SharedCore exact existing fullhistory prefix diagnostics;no newgames,solver,training or default changes.'}
 try:
  if mode=='preflight':items=json.loads((P/'preflight-inputs.json').read_text(encoding='utf-8'))['inputs']
  else:raise ValueError(mode)
  for i,item in enumerate(items):
   r=measure(item,f'preflight-{i:03d}');out['results'].append({k:r[k]for k in('tag','mode','world','source_game_slot','prefix','boardsize','input_sha256','branching','winning_children','restricted_closed_draw','replay_seconds','seconds')});write_record(P/(mode+'-results.json'),out);print(i,r['mode'],r['boardsize'],r['prefix'],r['branching'],r['winning_children'],round(r['seconds'],4),flush=True)
  out['status']='CLOSED'
 except Exception as e:out['status']='FAILED';out['failures'].append({'error':repr(e),'traceback':traceback.format_exc()});raise
 finally:out['seconds']=time.perf_counter()-tick;write_record(P/(mode+'-results.json'),out)
