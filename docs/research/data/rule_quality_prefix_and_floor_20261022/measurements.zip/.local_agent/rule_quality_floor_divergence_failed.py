import json,sys,time
from pathlib import Path
from dataclasses import replace
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig,MATE_SCORE
D=P/'floor-unit-control';S=P/'floor-competence';a=json.loads((S/'results.json').read_text());b=json.loads((D/'results.json').read_text());aa={x['slot']:x for x in a['slots']};bb={x['slot']:x for x in b['slots']};worlds={w['index']:w for w in json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text())['worlds']};out={'question':'Are first wholepolicy differences only sharedleaf ties,or do pricechanges alter actualD1 argmax supports?','scope':'Posthocfirstdivergence atcommoncompletehistory;FULLD1 Coretrees,notWDL/nonlinearlearninggate or leaf-onlyutility effect. Actualordinaryqdepth0 checked.','cases':[],'identical_trajectories':[],'failures':[]};contexts={};tick=time.perf_counter()
for k in sorted(aa):
 if aa[k]['status']!='finished':continue
 ga=json.loads((S/aa[k]['receipt']).read_text());gb=json.loads((D/bb[k]['receipt']).read_text());ra=deserialize_game_record(json.dumps(ga['final_record']));rb=deserialize_game_record(json.dumps(gb['final_record']));n=next((i for i,(x,y)in enumerate(zip(ra.actions,rb.actions))if x!=y),None)
 if n is None:assert ra==rb;out['identical_trajectories'].append(k);continue
 w=aa[k]['world'];role=aa[k]['candidate_role']
 if w not in contexts:
  c=compile_rule(ruleset_from_dict(worlds[w]['rule']));config=EvaluationConfig();base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;board={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()};hand={t:0 if m.is_anchor or base.hand_value_by_base_type[t]==0 else 900 for t,m in c.support.type_metadata.items()};unit=replace(base,board_value_by_type=board,hand_value_by_base_type=hand,promotion_gain_by_type={t:0 for t in board},median_non_anchor_value=1000,piece_profiles={t:replace(p,normalized_board_value=board[t],normalized_hand_value=hand[t],promotion_option_value=0)for t,p in base.piece_profiles.items()});saved=json.loads((D/f'profile-{w:02d}.json').read_text());assert record_value(base)==saved['static_profile'];assert record_value(unit)==saved['unit_profile'];contexts[w]=(c,Evaluator(c,base,config),Evaluator(c,unit,config))
 c,es,eu=contexts[w];s=GameSession.replay(c,replace(ra,actions=ra.actions[:n]));assert s.state.position.side_to_move==role;qa=next(q for q in ga['queries']if q['root_ply']==n);qb=next(q for q in gb['queries']if q['root_ply']==n);assert qa['policy']==qb['policy']=='D1';assert qa['decision']['completed_depth']==qb['decision']['completed_depth']==1;assert qa['decision']['result_ordinary_qdepth']==qb['decision']['result_ordinary_qdepth']==0;children=[]
 for action,ch in legal_successors(s.state,c):
  t=ch.terminal_status
  values=[0 if t.winner is None else MATE_SCORE-1 if t.winner==role else -MATE_SCORE+1]*2 if t.is_terminal else[-es.evaluate(ch),-eu.evaluate(ch)]
  children.append({'action':record_value(action),'full_child_sha256':digest(record_value(ch)),'terminal':record_value(t),'static':values[0],'unit':values[1]})
 maxima=[max(x[key]for x in children)for key in('static','unit')];supports=[{digest(x['action'])for x in children if x[key]==mx}for key,mx in zip(('static','unit'),maxima)];chosen=[digest(record_value(ra.actions[n])),digest(record_value(rb.actions[n]))];row={'slot':k,'world':w,'candidate_role':role,'first_divergence_ply':n,'common_full_record':record_value(s.to_record()),'common_full_state_sha256':digest(record_value(s.state)),'children':children,'full_D1_maxima':maxima,'returned_scores':[qa['decision']['score'],qb['decision']['score']],'argmax_support_sizes':list(map(len,supports)),'argmax_intersection_size':len(supports[0]&supports[1]),'both_selected_actions_shared_argmax':all(z in supports[0]&supports[1]for z in chosen),'chosen_membership':[chosen[0]in supports[0],chosen[1]in supports[1]],'static_action':record_value(ra.actions[n]),'unit_action':record_value(rb.actions[n])};out['cases'].append(row);write_record(D/'first-divergence.json',out);assert all(row['chosen_membership']);assert row['returned_scores']==maxima
out['seconds']=time.perf_counter()-tick;out['summary']={'changed_trajectory_slots':len(out['cases']),'identical_trajectory_slots':len(out['identical_trajectories']),'disjoint_argmax_slots':sum(x['argmax_intersection_size']==0 for x in out['cases']),'shared_tie_selected_slots':sum(x['both_selected_actions_shared_argmax']for x in out['cases']),'literal_full_D1_tree_qualified':True};write_record(D/'first-divergence.json',out);print(json.dumps(out['summary']));print('CASES',[(x['world'],x['candidate_role'],x['first_divergence_ply'],x['argmax_support_sizes'],x['argmax_intersection_size'])for x in out['cases']])
