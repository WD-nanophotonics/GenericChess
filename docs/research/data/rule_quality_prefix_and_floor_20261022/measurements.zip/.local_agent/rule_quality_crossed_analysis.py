import json,sys
from pathlib import Path
from fractions import Fraction
from collections import Counter,defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record
A=json.loads((P/'floor-competence/results.json').read_text());D=json.loads((P/'floor-unit-control/results.json').read_text());X=json.loads((P/'crossed-price-next/full/results.json').read_text());assert all(r['status']=='CLOSED'and not r['unattempted_slots']for r in(A,D,X));cells={}
for label,raw in [('A',A),('D',D)]:
 for x in raw['slots']:cells[x['world'],x['candidate_role'],label]=x
for x in X['slots']:cells[x['world'],x['candidate_role'],'B'if x['leaf_order_arm']==0 else'C']=x
coeff={'whole_D-A':{'D':1,'A':-1},'leaf_C-A_staticorder':{'C':1,'A':-1},'leaf_D-B_unitorder':{'D':1,'B':-1},'order_B-A_staticleaf':{'B':1,'A':-1},'order_D-C_unitleaf':{'D':1,'C':-1},'interaction_D-C-B+A':{'D':1,'C':-1,'B':-1,'A':1}}
out={'scope':'FixedsameFLOOR opponent,allfourcandidatecells;differentcandidateUNKNOWN distinct. Wholepriceeffect isnot leafeffect. Posthocexposedcohort andfinitebounds,not samplingCI/defaultchoice.','cell_mapping':{'A':'Staticleaf/Staticorder','B':'Staticleaf/Unitorder','C':'Unitleaf/Staticorder','D':'Unitleaf/Unitorder'},'pairs':[],'summary':{},'families':[]}
for w in range(24):
 for role in(0,1):
  row={label:cells[w,role,label]for label in('A','B','C','D')};valid=all(s['status']=='finished'for s in row.values());bounds={}
  for name,cs in coeff.items():
   pair=[]
   for endpoint in(0,1):
    pair.append(sum(scale*Fraction(row[label]['candidate_utility_interval'][endpoint if scale>0 else 1-endpoint])for label,scale in cs.items()))
   bounds[name]=list(map(str,pair))
  out['pairs'].append({'world':w,'role':role,'valid':valid,'effects':bounds})
valid=[x for x in out['pairs']if x['valid']];worlds=json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text())['worlds'];first={}
for w in worlds:first.setdefault(digest(w['rule']),w['index'])
for name,rows in [('accepted22slots44roles',valid),('planned24slots48roles_hypotheticalcompletion',out['pairs']),('unique13fullrules26roles_descriptive',[r for r in valid if r['world']in first.values()])]:out['summary'][name]={key:[str(sum(Fraction(r['effects'][key][j])for r in rows)/len(rows))for j in(0,1)]for key in coeff}
for w in range(24):
 rows=[r for r in valid if r['world']==w]
 if rows:out['families'].append({'world':w,'effects':{key:[str(sum(Fraction(r['effects'][key][j])for r in rows)/2)for j in(0,1)]for key in coeff}})
out['cell_outcomes']={label:dict(Counter('UNKNOWN'if s['candidate_utility_interval'][0]!=s['candidate_utility_interval'][1]else str(s['candidate_utility_interval'][0])for(w,role,k),s in cells.items()if k==label and s['status']=='finished'))for label in('A','B','C','D')};write_record(P/'crossed-price-next/full/factorial-analysis.json',out);print(json.dumps(out['summary'],indent=2));print(out['cell_outcomes'])
