"""Independent positive-witness and actual-policy qualification using full Core states."""
import json,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from rule_quality_prefix import P,digest
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import apply_action,legal_successors
from generic_chess.core.movegen import legal_actions
D=P/'dense';idx=json.loads((D/'results.json').read_text());assert idx['status']=='CLOSED';occupation=json.loads((P/'occupation/results.json').read_text());assert occupation['status']=='CLOSED';occ={(g['mode'],g['slot']):g for g in occupation['games']if g['reuse_source_slot']is None};sources={};worlds={};contexts={};out={'status':'RUNNING','checked_games':0,'checked_actual_roots':0,'checked_final_states':0,'winning_witnesses':0,'losing_witnesses':0,'actual_chosen_classifications':0,'failures':[],'scope':'Separate reader over sharedCore:all actual parentstates/history+positiveWIN/LOSSwitnesses+actualchosenclassifications. Doesnot independently reenumerate every unused alternative reply count or implement a second rules engine.'};tick=time.perf_counter()
for mode,rp,ip in [('pocket','.local_agent/rule-quality-random-20261022/results.json','.local_agent/rule-quality-survey-20261022/inputs.json'),('remove','.local_agent/rule-quality-capture-random-20261022/results.json','.local_agent/rule-quality-capture-20261022/inputs.json')]:
 sources[mode]={g['slot']:g for g in json.loads(Path(rp).read_text())['games']};worlds[mode]={w['index']:w for w in json.loads(Path(ip).read_text())['worlds']}
def actual_action(state,c,description):return next(a for a in legal_actions(state,c)if record_value(a)==description)
try:
 for gi,meta in enumerate(idx['games']):
  mode=meta['mode'];slot=meta['source_game_slot'];g=sources[mode][slot];raw=worlds[mode][g['world']]['rule'];rh=digest(raw)
  if rh not in contexts:contexts[rh]=compile_rule(ruleset_from_dict(raw))
  c=contexts[rh];rec=deserialize_game_record(json.dumps(g['final_record']));s=GameSession.replay(c,__import__('dataclasses').replace(rec,actions=()));data=json.loads(Path(meta['path']).read_text());frames=occ[mode,slot]['frames'];assert data['status']=='CLOSED'and len(data['turns'])==len(frames)==len(rec.actions)+1
  for k,row in enumerate(data['turns']):
   state=s.state;actor=state.position.side_to_move;assert digest(record_value(state))==row['full_state_sha256']==frames[k]['full_state_sha256'];assert row['restricted_closed_draw']==frames[k]['restricted_closed_draw'];assert sum(row['classes'].values())==row['branching'];assert row['exact_win_loss_choice']==bool(row['winning_witness']and row['losing_witness'])
   for name,expected in [('winning_witness',actor),('losing_witness',1-actor)]:
    w=row[name]
    if not w:continue
    a=actual_action(state,c,w['action']);child=apply_action(state,a,c);assert digest(record_value(child))==w['full_child_sha256'];assert record_value(child.terminal_status)==w['child_terminal']
    if name=='winning_witness':assert child.terminal_status.winner==actor;out['winning_witnesses']+=1
    else:
     if w['reply']is not None:
      b=actual_action(child,c,w['reply']['action']);leaf=apply_action(child,b,c);assert digest(record_value(leaf))==w['reply']['full_state_sha256'];assert record_value(leaf.terminal_status)==w['reply']['terminal'];assert leaf.terminal_status.winner==expected
     else:assert child.terminal_status.winner==expected
     out['losing_witnesses']+=1
   if k<len(rec.actions):
    s.submit(rec.actions[k]);ch=s.state;winner=ch.terminal_status.winner
    if winner==actor:actual='WIN1'
    elif winner==1-actor:actual='LOSS1_OR_REPLY2'
    elif ch.terminal_status.is_terminal and ch.terminal_status.status.value!='no_contest':actual='DRAW1'
    else:actual='LOSS1_OR_REPLY2'if any(leaf.terminal_status.winner==1-actor for _,leaf in legal_successors(ch,c))else'UNKNOWN'
    assert actual==row['chosen_action_class'],(mode,slot,k,actual,row['chosen_action_class']);out['actual_chosen_classifications']+=1;out['checked_actual_roots']+=1
   else:assert row['chosen_action_class']is None;out['checked_final_states']+=1
  assert record_value(s.state)==g['final_state'];out['checked_games']+=1
  if gi%20==0:write_record(D/'qualification.json',out);print('DENSEQUAL',gi,out['checked_actual_roots'],out['winning_witnesses'],out['losing_witnesses'],round(time.perf_counter()-tick,1),flush=True)
 out['status']='CLOSED'
except Exception as e:out['status']='FAILED';out['failures'].append({'error':repr(e),'traceback':traceback.format_exc()});raise
finally:out['seconds']=time.perf_counter()-tick;write_record(D/'qualification.json',out);print(out['status'],out['checked_games'],out['checked_actual_roots'],round(out['seconds'],1),flush=True)
