"""Actual typed-action and interruption contracts for optional capture slots."""
import copy
import gzip
import json
from collections import Counter
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
import pytest
from generic_chess.ai.alphabeta import capture_exchange as exchange
from generic_chess.ai.alphabeta.ordering import MoveOrderer
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.actions import action_target_square, action_source_square
from generic_chess.core.coordinates import square_to_index
from generic_chess.core.movement import RayAtom
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession


def fixture():
    path=Path(__file__).resolve().parents[2]/'docs/research/data/leaper_bound_trials_20261031/q-bound-quality-20261031/inputs.json.gz'
    rule=copy.deepcopy(json.loads(gzip.decompress(path.read_bytes()))['rows'][0]['RuleSet'])
    rule['initial_position']=[[None]*6 for _ in range(6)]
    homes=[[("K",0,0),("A",1,2),("A",3,2),("B",2,1),("B",4,1),("C",2,4)],
           [("K",5,5),("A",2,2),("A",4,2),("B",1,3),("B",3,3),("C",3,1)]]
    atoms=[[(1,0),(-1,0),(0,1),(1,1),(3,1)],[(1,1),(-1,1),(0,-1),(2,0),(-2,-1)],[(1,0),(0,1),(0,-1),(-1,-1),(2,2)]]
    for typ,offsets in zip(rule['piece_types'][1:],atoms):
        typ['movement_atoms']=[dict(kind='leap',offset=list(x)) for x in offsets]
    for owner,home in enumerate(homes):
        for typ,x,y in home:
            rule['initial_position'][y][x]=dict(owner=owner,base_type_id=typ,current_type_id=typ,promoted=False)
    c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(rule))
    s=GameSession(c)
    return c,s,AlphaBetaPlayer(c,use_disk_cache=False)._evaluator


def test_fixed_typed_slots_tt_duplicates_and_stable_ties(monkeypatch):
    c,s,e=fixture();before=s.to_record();actions=list(s.legal_actions())
    caps=[a for a in actions if exchange.eligible_capture(s.state,a,c)]
    assert len(caps)>=3
    tt=caps[0];actions.append(caps[-1]);stats=SearchStatistics();orderer=MoveOrderer(c,stats)
    off=SearchTuning();on=replace(off,use_geometric_capture_order=True)
    baseline=orderer.order(s.state,actions,e,3,tt,None,off)
    # Force a reversal of known distinct baseline capture scores. This tests
    # the consumer contract, independently of proxy arithmetic/model accuracy.
    ranks={a:i for i,a in enumerate(baseline)}
    monkeypatch.setattr(exchange,'geometric_score',lambda state,a,*args:ranks[a])
    got=orderer.order(s.state,actions,e,3,tt,None,on)
    slots=[i for i,a in enumerate(baseline) if a!=tt and exchange.eligible_capture(s.state,a,c)]
    assert Counter(got)==Counter(baseline) and got[0]==tt
    assert all(got[i]==a for i,a in enumerate(baseline) if i not in slots)
    assert [got[i] for i in slots]==sorted([baseline[i] for i in slots],key=lambda a:-ranks[a])
    assert stats.capture_exchange_frontiers==1 and stats.capture_exchange_reorders==1
    monkeypatch.setattr(exchange,'geometric_score',lambda *args:0)
    assert orderer.order(s.state,actions,e,3,tt,None,on)==baseline
    assert s.to_record()==before


def test_zero_single_capture_and_q_never_score(monkeypatch):
    c,s,e=fixture();actions=list(s.legal_actions());caps=[a for a in actions if exchange.eligible_capture(s.state,a,c)]
    quiet=[a for a in actions if a not in caps];o=MoveOrderer(c);on=SearchTuning(use_geometric_capture_order=True)
    def forbidden(*args):raise AssertionError('unnecessary model work')
    monkeypatch.setattr(exchange,'geometric_score',forbidden)
    for subset,tt in [(quiet,None),(quiet+caps[:1],None),(quiet+caps[:2],caps[0])]:
        assert o.order(s.state,subset,e,2,tt,None,on)==o.order(s.state,subset,e,2,tt,None,SearchTuning())
    assert o.order(s.state,actions,e,0,None,None,on)==o.order(s.state,actions,e,0,None,None,SearchTuning())


def test_cancel_during_scoring_keeps_input_and_state_unchanged():
    c,s,e=fixture();before=s.to_record();actions=list(s.legal_actions());original=list(actions);stats=SearchStatistics();o=MoveOrderer(c,stats);polls=0
    class Abort(Exception):pass
    def stop():
        nonlocal polls
        polls+=1
        if polls>len(actions)+8:raise Abort()
    with pytest.raises(Abort):o.order(s.state,actions,e,2,None,None,SearchTuning(use_geometric_capture_order=True),checkpoint=stop)
    assert actions==original and s.to_record()==before
    assert stats.capture_exchange_frontiers==stats.capture_exchange_actions==0


def test_owner_relative_geometry_matches_direct_atom_arithmetic():
    c,s,e=fixture();board=s.state.position.board;n=c.board_size
    for a in s.legal_actions():
        if not exchange.eligible_capture(s.state,a,c):continue
        victim,mover,own,enemy,royals=exchange.exchange_inputs(s.state,a,c,e)
        source=square_to_index(action_source_square(a),n);target=action_target_square(a);target_index=square_to_index(target,n);moving=board[source]
        expected=[[],[]];kings=[0,0]
        for i,piece in enumerate(board):
            if piece is None or i in (source,target_index):continue
            sign=1 if piece.owner==0 else -1
            if not any((i%n+sign*atom.offset[0],i//n+sign*atom.offset[1])==(target.file,target.rank) for atom in c.types_by_id[piece.current_type_id].movement_atoms):continue
            side=int(piece.owner!=moving.owner)
            if c.types_by_id[piece.current_type_id].is_anchor:kings[side]+=1
            else:expected[side].append(e.type_value(piece.current_type_id))
        assert (own,enemy,royals)==(*expected,kings)


def test_royal_actor_and_royal_victim_never_enter_slots():
    c,s,e=fixture();a=next(x for x in s.legal_actions() if exchange.eligible_capture(s.state,x,c));board=list(s.state.position.board)
    for square in (action_source_square(a),action_target_square(a)):
        i=square_to_index(square,c.board_size);saved=board[i];board[i]=replace(saved,base_type_id='K',current_type_id='K')
        state=replace(s.state,position=replace(s.state.position,board=tuple(board)))
        assert not exchange.eligible_capture(state,a,c)
        board[i]=saved


def test_constructor_rejects_staged_disabled_ordering_and_nonleaps():
    c,s,e=fixture();on=SearchTuning(use_geometric_capture_order=True)
    exchange.certify_plain_geometry(c)
    with pytest.raises(ValueError):AlphaBetaPlayer(c,tuning=replace(on,use_staged_move_picker=True))
    with pytest.raises(ValueError):AlphaBetaPlayer(c,tuning=on,use_ordering=False)
    types=dict(c.types_by_id);types['A']=replace(types['A'],movement_atoms=(RayAtom((1,0)),))
    with pytest.raises(ValueError):exchange.certify_plain_geometry(replace(c,_legacy_compiled=replace(c._legacy_compiled,types_by_id=types)))
    patterns=list(c.ir.patterns);capture_index=next(i for i,p in enumerate(patterns) if p.target.kind=='target_enemy');del patterns[capture_index]
    with pytest.raises(ValueError):exchange.certify_plain_geometry(replace(c,ir=replace(c.ir,patterns=tuple(patterns))))


def test_actual_player_cancel_and_full_iteration_leave_record_unchanged():
    c,s,e=fixture();before=s.to_record();on=SearchTuning(use_geometric_capture_order=True,use_pvs=True)
    p=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,tuning=on)
    class Cancel:
        def is_cancelled(self):return True
    aborted=p.choose_action(s,SearchLimits(max_depth=3,max_nodes=50000,max_time_seconds=2,quiescence_max_depth=0),cancel_token=Cancel())
    assert aborted.runtime_depth_balanced and s.to_record()==before
    d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=50000,max_time_seconds=5,quiescence_max_depth=0))
    assert d.completed_depth==2 and d.action in s.legal_actions()
    assert d.capture_exchange_frontiers>0 and d.runtime_depth_balanced and s.to_record()==before
