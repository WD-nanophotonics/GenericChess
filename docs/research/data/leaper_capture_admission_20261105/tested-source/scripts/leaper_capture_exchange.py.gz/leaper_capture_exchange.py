"""Compatibility imports for saved research readers; product never imports scripts."""
from generic_chess.ai.alphabeta.capture_exchange import (
    certify_plain_geometry, material_exchange, eligible_capture, exchange_inputs,
    geometric_score, reorder_capture_slots,
)
