import json,sys,time,traceback,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.limits import SearchLimits
P=Path('.local_agent/rule-quality-prefix-next-20261022');B=P/'prospective-price-q0-next';C=P/'prospective-price-q-interaction';D=P/'prospective-captureonly-feasibility';D.mkdir(exist_ok=True);assert not(D/'registration.json').exists();inputs=json.loads((B/'inputs.json').read_text());cr=json.loads((C/'results.json').read_text());reg={'question':'Can theexistingcapture-onlyq1switchreducetheobservedq1primitivework enough tojustifya24gamenode2048utilitytest?','changed_premise':'NEWStaticq1-q0utility[-5/12,-1/6],2.32Mvs0.90Mpaidpushes;simpledepth/mate1explanationfails. Existingcapture-onlypolicyomitsquietchecks,knownnotgenericallysafe. Newfixed-node2048regime/12initialrootsisnottheclosedoldD1panel.','configs':'All12samecompleteinitialstates;Staticleaf/Staticmaterialorder/dynamics2/5/3;maxdepth64,node2048,q1hard8,noquerydeadline,freshownTT,diskOFF;ONLYuse_capture_only_qsearch=True.','expected_seconds':30,'whole_cap_seconds':120,'planned_new_queries':12,'reuse':'12exactCStaticq1candidate-role0initialcoldreturns,0reruns;allworldsbeforeobservedoutcomes,2WIN1kept. Rootsareexposed,notindependentutility/learningholdout.','cost_checkpoint':'Ifall12newqueriesretainedandtotalruntime_pushes<=0.8*fullq1,preparebutdoNOTyetexecute24wholegames;otherwisedeferthisroute. ThisislocalresearchROI,notglobalgate/defaultactivation.','interpretation':'No wholescoredgamesorWDLclaim;Nodevisits,pushes,completeddepth/actions/sourceandwallseparate. Concurrentloadlimitswallcomparison. Knownquietcheckomissionsretained;never prune semantics/history inrealrules.','input_sha256':hashlib.sha256((B/'inputs.json').read_bytes()).hexdigest()};write_record(D/'registration.json',reg);out={'registration':reg,'rows':[],'missing':[],'failures':[],'status':'RUNNING'};write_record(D/'results.json',out);tick=time.perf_counter()
class Adapter:
 def __init__(self,e):self.evaluate=e.evaluate;self.type_value=e.type_value;self.capture_order_value=e.capture_order_value
for w in inputs['worlds']:
 if time.perf_counter()-tick>=120:out['missing'].append(w['index']);continue
 try:
  c=compile_rule(ruleset_from_dict(w['rule']));s=GameSession(c);assert record_value(s.state)==w['initial_full_state'];base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;ev=Evaluator(c,base,EvaluationConfig());p=AlphaBetaPlayer(c,evaluator_override=Adapter(ev),use_disk_cache=False,tuning=SearchTuning(use_capture_only_qsearch=True));oldslot=next(x for x in cr['slots']if x['arm']=='C'and x['world']==w['index']and x['candidate_role']==0);old=json.loads((C/oldslot['receipt']).read_text())['queries'][0];assert old['actor']==0 and old['candidate']and old['root_ply']==0;qt=time.perf_counter();dec=p.choose_action(s,SearchLimits(max_depth=64,max_nodes=2048,max_time_seconds=None,quiescence_max_depth=1,quiescence_hard_max_depth=8));row={'world':w['index'],'fullq1_exact_reuse':old,'captureonly_decision':record_value(dec),'seconds':time.perf_counter()-qt};out['rows'].append(row);write_record(D/'results.json',out);pv=s.state
  for raw in row['captureonly_decision']['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw)
  assert dec.nodes+dec.qnodes<=2048 and dec.runtime_depth_balanced;row['literal_pv_and_node_contract_passed']=True
 except Exception as e:out['failures'].append({'world':w['index'],'error':repr(e),'traceback':traceback.format_exc()})
 write_record(D/'results.json',out)
full=sum(x['fullq1_exact_reuse']['decision']['runtime_pushes']for x in out['rows']);cap=sum(x['captureonly_decision']['runtime_pushes']for x in out['rows']);out.update(status='CLOSED',seconds=time.perf_counter()-tick,fullq1_pushes=full,captureonly_pushes=cap,push_ratio=cap/full if full else None,changed_actions=sum(x['captureonly_decision']['action']!=x['fullq1_exact_reuse']['decision']['action']for x in out['rows']),cost_checkpoint_passed=len(out['rows'])==12 and not out['failures']and not out['missing']and cap<=.8*full);write_record(D/'results.json',out);print({k:out[k]for k in['status','seconds','fullq1_pushes','captureonly_pushes','push_ratio','changed_actions','cost_checkpoint_passed']})
