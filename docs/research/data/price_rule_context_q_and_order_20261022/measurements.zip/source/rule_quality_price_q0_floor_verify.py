import json,sys,time,random,hashlib
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-price-q0-floor';B=P/'prospective-price-q0-next';r=json.loads((D/'results.json').read_text());assert r['status']=='CLOSED';assert hashlib.sha256((B/'inputs.json').read_bytes()).hexdigest()==r['registration']['input_sha256'];worlds={w['index']:w for w in json.loads((B/'inputs.json').read_text())['worlds']};out={'scope':'IndependentCorephysicalhistory/PV and exactFLOORaction/RNGreader;no newgames/search,WDLleafprooforindependentengine claim. Missing/failed plannedslotsretained.','games':[],'candidate_queries':0,'floor_queries':0,'history_plies':0,'pv_plies':0,'not_finished':[]};tick=time.perf_counter();contexts={};sources=Counter()
for slot in r['slots']:
 if slot['status']!='finished':out['not_finished'].append({'slot':slot['slot'],'status':slot['status']});continue
 g=json.loads((D/slot['receipt']).read_text());w=slot['world'];role=slot['candidate_role']
 if w not in contexts:contexts[w]=compile_rule(ruleset_from_dict(worlds[w]['rule']))
 c=contexts[w];s=GameSession(c);rec=deserialize_game_record(json.dumps(g['final_record']));assert record_value(s.to_record())==g['initial_record'];assert len(g['queries'])in(len(rec.actions),len(rec.actions)+1);rng={a:random.Random(worlds[w]['config']['seed']*1009+a)for a in(0,1)}
 for i,q in enumerate(g['queries']):
  actor=s.state.position.side_to_move;assert q['root_ply']==s.state.ply_count and q['actor']==actor and q['candidate']==(actor==role)
  if q['candidate']:
   dec=q['decision'];assert q['requested_depth']==64;assert q['limits']['max_nodes']==2048 and q['limits']['quiescence_max_depth']==0 and q['limits']['max_time_seconds']is None;assert dec['runtime_depth_balanced'] and dec['nodes']+dec['qnodes']<=2048 and dec['qnodes']==0;pv=s.state
   for raw in dec['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);out['pv_plies']+=1
   if dec['result_source']=='root_immediate_win':assert pv.terminal_status.winner==actor
   action=dec['action'];sources[(dec['completed_depth'],dec['result_source'],dec['termination_reason'])]+=1;out['candidate_queries']+=1
  else:
   children=list(legal_successors(s.state,c));winner=next((a for a,ch in children if ch.terminal_status.winner==actor),None);expected=winner if winner is not None else children[rng[actor].randrange(len(children))][0] if children else None;action=q['action'];assert action==record_value(expected);assert q['floor']['winning_action_found']==(winner is not None);assert q['floor']['complete_or_winning'];out['floor_queries']+=1
  if i<len(rec.actions):assert action==record_value(rec.actions[i]);s.submit(rec.actions[i]);out['history_plies']+=1
  else:assert g['failure']or g['censor']
 assert record_value(s.state)==g['final_state'] and record_value(s.result)==g['terminal'];v=None if not g['eligible']or g['terminal']['status']in('ongoing','no_contest')else 0 if g['terminal']['winner']is None else 1 if g['terminal']['winner']==role else-1;assert g['candidate_utility_interval']==([v,v]if v is not None else[-1,1]);out['games'].append({'slot':slot['slot'],'world':w,'role':role,'eligible':g['eligible'],'history_policy_verified':True})
out['candidate_sources']={str(k):v for k,v in sources.items()};out['all_retained_games_passed']=True;out['all_planned_finished']=not out['not_finished'];out['seconds']=time.perf_counter()-tick;write_record(D/'qualified.json',out);print('FLOORQUAL',len(out['games']),out['candidate_queries'],out['floor_queries'],out['history_plies'],out['pv_plies'],out['seconds'])
