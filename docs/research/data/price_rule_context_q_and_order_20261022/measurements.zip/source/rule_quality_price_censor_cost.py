import sys,json,hashlib
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
from generic_chess.rules.schema import ruleset_from_dict
P=Path('.local_agent/rule-quality-prefix-next-20261022');B=P/'prospective-price-q0-next';inputs={w['index']:w for w in json.loads((B/'inputs.json').read_text())['worlds']};out={'question':'Canidenticalcappedprefixesoroldtwo-KingclosurejustifycouplingnewUnit/UnitorderUNKNOWNtailsorcomplete-costdominance?','scope':'Descriptivefullstate+validatedrule-clock conditionalcounted-nodebound;no continuationplay,norawUNKNOWNrelabel,nobudgetrefill. Ownmain+qvisitsonly,notwall/primitive/totalmatchcost. All13censoredsourcegameshave10to30nonanchorboardpieces;oneDworld9hasemptystock,othersnonempty. Oldtwo-Kingclosureisnotapplicablebecauseboardconditionfails.','arms':{},'tails':[]}
for directory,arms in [(B,['A','B']),(P/'prospective-price-q-interaction',['C','D']),(P/'prospective-price-q0-order',['G'])]:
 r=json.loads((directory/'results.json').read_text());an=json.loads((directory/('paired-analysis.json'if directory==B else'factorial-analysis.json'if directory.name.endswith('interaction')else'order-analysis.json')).read_text())
 for arm in arms:
  cost=an['cost'][arm];paid=cost['balanced_role_candidate_nodes'];remaining_budget=0
  for slot in [x for x in r['slots']if x['arm']==arm and x['status']=='finished']:
   g=json.loads((directory/slot['receipt']).read_text());rule=ruleset_from_dict(inputs[slot['world']]['rule']);assert rule.max_ply==512 and not rule.automatic_adjudications and not rule.consecutive_action_adjudications and not rule.declarations and not rule.semantic_actions and not rule.repeated_cycle_target_conditions and rule.no_progress_draw is None
   if g['terminal']['status']!='ongoing':continue
   assert g['eligible'];state=g['final_state'];pos=state['position'];pieces=[x for x in pos['board']if x];stock=sum(n for h in pos['hands']for t,n in h['counts']);nonanchor=sum(x['current_type_id']!='K'for x in pieces);assert nonanchor>0;left=512-state['ply_count'];remaining_budget+=left*2048;out['tails'].append({'arm':arm,'world':slot['world'],'role':slot['candidate_role'],'ply':state['ply_count'],'board_pieces':len(pieces),'nonanchor_pieces':nonanchor,'promoted_pieces':sum(x['promoted']for x in pieces),'stock_count':stock,'full_state_sha256':hashlib.sha256(json.dumps(state,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'future_own_query_upper':left,'own_nodes_upper':left*2048,'source_self_game_reframed_bothroles':arm=='A'})
  out['arms'][arm]={'paid_own_nodes_rolebalanced':paid,'hypothetical_full_continuation_own_node_interval':[paid,paid+remaining_budget],'unknown_tail_node_allowance':remaining_budget,'virtualselfrolesnotdoublecharged':arm=='A'}
lo=out['arms']['G']['hypothetical_full_continuation_own_node_interval'];hi=out['arms']['B']['hypothetical_full_continuation_own_node_interval'];out['GminusB_fullown_countednodes_interval']=[lo[0]-hi[1],lo[1]-hi[0]];out['decision']='Ordereffect[-1/6,1/3]andcompletecostbothunidentified;keepindependenttails despite twoexactshared96plyhistories. No closure/WDL/framework escalation.';write_record(B/'censoring-and-fullcost-bounds.json',out);print(json.dumps({'arms':out['arms'],'GminusB':out['GminusB_fullown_countednodes_interval'],'tails':len(out['tails'])}))
