import sys,json,time,hashlib
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.core.transition import legal_successors
P=Path('.local_agent/rule-quality-prefix-next-20261022');B=P/'prospective-price-q0-next';C=P/'prospective-price-q-interaction';ws={w['index']:w for w in json.loads((B/'inputs.json').read_text())['worlds']};tick=time.perf_counter();out={'question':'Areall24newcostpilotreturnssemanticallylegal,andwhatwork/allocationchangedratherthanjustactioncount?','scope':'FullCoreliteralPV,exactunchangedbaseline-returnreusechecks;notnewbaselinequeries,independentengine,valueprooforstrengthtest. Coldfirstcalls/diskOFF. Cross-runtimingnotacontrolledspeedclaim.','pilots':{},'new_queries':0,'newPVedges':0}
for directory,flag,newkey,oldkey,arm,source in [(P/'prospective-captureonly-feasibility','capture-onlyq1','captureonly_decision','fullq1_exact_reuse','C',C),(P/'prospective-checkonly-feasibility','check-onlyq0','checkonly_decision','pureq0_exact_reuse','A',B)]:
 r=json.loads((directory/'results.json').read_text());base=json.loads((source/'results.json').read_text());assert r['status']=='CLOSED' and len(r['rows'])==12 and not r['failures']and not r['missing'];summary={'worlds':[],'original_totals':{},'new_totals':{}};metrics=['nodes','qnodes','runtime_pushes','in_check_qnodes','checking_move_qactions','checking_drop_qactions','capture_qactions','promotion_qactions']
 for x in r['rows']:
  w=x['world'];c=compile_rule(ruleset_from_dict(ws[w]['rule']));s=GameSession(c);assert record_value(s.state)==ws[w]['initial_full_state'];slot=next(y for y in base['slots']if y['arm']==arm and y['world']==w and y['candidate_role']==0);original=json.loads((source/slot['receipt']).read_text())['queries'][0];assert original==x[oldkey];new=x[newkey];assert new['nodes']+new['qnodes']<=2048 and new['runtime_depth_balanced'];pv=s.state
  for raw in new['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);out['newPVedges']+=1
  if new['result_source']=='root_immediate_win':assert pv.terminal_status.winner==0
  out['new_queries']+=1;old=original['decision'];summary['worlds'].append({'world':w,'changed_action':new['action']!=old['action'],'changed_score':new['score']!=old['score'],'old_depth':old['completed_depth'],'new_depth':new['completed_depth'],'old_score':old['score'],'new_score':new['score'],'old_pushes':old['runtime_pushes'],'new_pushes':new['runtime_pushes'],'new_qnodes':new['qnodes'],'new_check_qnodes':new['in_check_qnodes'],'source':new['result_source']})
  for k in metrics:summary['original_totals'][k]=summary['original_totals'].get(k,0)+old[k];summary['new_totals'][k]=summary['new_totals'].get(k,0)+new[k]
 summary['changed_action_worlds']=[x['world']for x in summary['worlds']if x['changed_action']];summary['score_change_count']=sum(x['changed_score']for x in summary['worlds']);summary['push_ratio']=r['push_ratio'];summary['cost_checkpoint_passed']=r['cost_checkpoint_passed'];summary['all12newPVandoriginalreuse_verified']=True;out['pilots'][flag]=summary
out['seconds']=time.perf_counter()-tick;write_record(P/'pilot-independent-qualified.json',out);print(json.dumps(out,indent=2))
