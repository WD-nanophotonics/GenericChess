import json,sys,itertools
from pathlib import Path
from fractions import Fraction
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-price-q0-remove');r=json.loads((D/'results.json').read_text());assert r['status']=='CLOSED'
cells={};variables={};sources={}
for x in r['slots']:
 key=(x['arm'],x['world'],x['candidate_role']);variables[key]=x['candidate_utility_interval'];cells[key]=(key,1);sources[key]=x
 if x['arm']=='A':
  if x['status']=='finished' and x['eligible']:cells['A',x['world'],1]=(key,-1)
  else:
   v=('A_unverified_virtual',x['world'],1);variables[v]=[-1,1];cells['A',x['world'],1]=(v,1)
def bound(worlds):
 coefficients={}
 for w in worlds:
  for role in (0,1):
   for arm,scale in [('B',1),('A',-1)]:
    var,sign=cells[arm,w,role];coefficients[var]=coefficients.get(var,0)+Fraction(scale*sign,2*len(worlds))
 return [str(sum(scale*Fraction(variables[var][side if scale>0 else 1-side]) for var,scale in coefficients.items())) for side in (0,1)]
out={'question':r['registration']['question'],'effect':bound(list(range(12))),'families':[{'world':w,'effect':bound([w])} for w in range(12)],'cost':{},'raw_failures':r['failures'],'unattempted':r['unattempted_slots'],'scope':'Finite all12planned-config effect,not populationCI orisolated filtereffect; allunknowncandidate tails independent; selfrole source exactoppositeonlyeligible. Nozero-valuedunknownimputation.'}
for arm in ['A','B']:
 ss=[x for x in r['slots'] if x['arm']==arm];gs=[json.loads((D/x['receipt']).read_text()) for x in ss if x['status']=='finished'];qs=[q for g in gs for q in g['queries']];cs=[q for q in qs if q['candidate']];opp=[q for q in qs if not q['candidate']];balanced=qs if arm=='A' else cs
 out['cost'][arm]={'physical_games':len(gs),'outcomes':dict(Counter(str(g['candidate_utility_interval']) for g in gs)),'terminal_status':dict(Counter(g['terminal']['status'] for g in gs)),'candidate_queries':len(cs),'opponent_queries':len(opp),'candidate_seconds':sum(q['seconds'] for q in cs),'opponent_seconds':sum(q['seconds'] for q in opp),'balanced_role_candidate_queries':len(balanced),'balanced_role_candidate_seconds':sum(q['seconds'] for q in balanced),'balanced_role_candidate_nodes':sum(q['decision']['nodes']+q['decision']['qnodes'] for q in balanced),'balanced_role_runtime_pushes':sum(q['decision']['runtime_pushes'] for q in balanced),'balanced_role_denominator':24,'actual_depth_source':dict(Counter(str((q['decision']['completed_depth'],q['decision']['result_source'],q['decision']['termination_reason'])) for q in balanced)),'fallback_games':sum(g['fallback'] for g in gs),'operational_failure_games':sum(g['operational_failure'] for g in gs)}
vertices=0
for row in out['families']:
 w=row['world'];ks=list({v for a in ['A','B'] for role in (0,1) for v,sgn in [cells[a,w,role]]});values=[]
 for ends in itertools.product(*(tuple(dict.fromkeys(variables[k])) for k in ks)):
  vals=dict(zip(ks,map(Fraction,ends)));v=sum(Fraction(scale*sgn,2)*vals[k] for a,scale in [('B',1),('A',-1)] for role in (0,1) for k,sgn in [cells[a,w,role]]);values.append(v);vertices+=1
 assert list(map(str,[min(values),max(values)]))==row['effect']
out['endpoint_vertices_verified']=vertices;out['leave_one_config_out']=[{'omitted':w,'effect':bound([j for j in range(12) if j!=w])} for w in range(12)];out['producer_seconds']=r['seconds'];write_record(D/'paired-analysis.json',out);print(json.dumps(out,indent=2))
