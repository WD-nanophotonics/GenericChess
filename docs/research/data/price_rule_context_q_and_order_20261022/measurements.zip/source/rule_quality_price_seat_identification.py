import json,sys
from pathlib import Path
from fractions import Fraction
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-price-q0-next');r=json.loads((D/'paired-analysis.json').read_text());d=json.loads((D/'policy-divergence.json').read_text());rows=[]
for w in range(12):
 pair=[x for x in d['cases']if x['world']==w];changes=[]
 for x in pair:
  a,b=x['static_utility'],x['unit_utility'];changes.append([str(Fraction(b[0]-a[1])),str(Fraction(b[1]-a[0]))])
 rows.append({'world':w,'role0_effect':changes[0],'role1_effect':changes[1],'paired_role_mean':r['families'][w]['effect'],'resolved_reciprocal_reversal':all(x['static_utility'][0]==x['static_utility'][1] and x['unit_utility'][0]==x['unit_utility'][1] and x['static_utility']!=x['unit_utility']for x in pair) and sum(Fraction(z[0])for z in changes)==0})
# Formalized proposed alternative is only an algebraic check, not a new fitness/proof framework.
# For any finite role-balanced zero-sum two-policy matchup x, self-play means=0,
# B-A vsA=x, B-A vsB=0-(-x)=x. A third opponent is necessary to expose
# opponent interaction in this balanced mean; no12newUnit-selfgames can change it.
vals=[Fraction(-1),Fraction(-1,2),Fraction(0),Fraction(1,2),Fraction(1)]
assert all(x==0-(-x) for x in vals)
out={'question':'Can reciprocal seat effects be hidden by role averaging,andwould12additionalUnitselfgamesresolveopponentrobustness?','rows':rows,'reciprocal_reversal_worlds':[x['world']for x in rows if x['resolved_reciprocal_reversal']],'algebra':'Letx=balancedutilityofBvsA. BalancedAself=Bself=0 evenwhenonephysicalselfoutcomeUNKNOWN,providedoppositeroleviewissameeligiblegame. AvsB=-xbyreframingthesamephysicalmatches. Then(B-A)vsA=x and(B-A)vsB=0-(-x)=x;interaction0identically. Thisdoesnotcoupleindependentunknownfuturepolicies.','consequence':'DoNOTlaunchUnitselfgamesmerelyforrolebalancedutilityinteraction. UsealreadyregisteredthirdFLOORopponentinstead. Costorper-seatquestionscouldneedselfgames,butarenotclaimedanswered.','no_new_games_or_queries':True};write_record(D/'seat-and-opponent-identification.json',out);print('reciprocalseatreversals',out['reciprocal_reversal_worlds'],'Unitselfutilityonlyalternative avoided12games')
