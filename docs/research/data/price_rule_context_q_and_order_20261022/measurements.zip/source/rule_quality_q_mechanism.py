import sys,json,time,traceback,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-q-mechanism');src=json.loads((D/'inputs.json').read_text());reg=src['registration'];assert not(D/'results.json').exists();tick=time.perf_counter();out={'registration':reg,'status':'RUNNING','queries':[],'witnesses':[],'failures':[],'missing':[]};write_record(D/'results.json',out)
def expired():return time.perf_counter()-tick>=reg['whole_cap_seconds']
def digest(x):return hashlib.sha256(json.dumps(record_value(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
for case in src['cases']:
 c=compile_rule(ruleset_from_dict(case['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(case['common_record'])));assert record_value(s.state)==case['common_full_state'];base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;ev=Evaluator(c,base,EvaluationConfig())
 for control in reg['cold_controls']:
  if expired():out['missing'].append({'case':case['case'],'control':control['name'],'cause':'whole_cap'});continue
  try:
   p=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False);qt=time.perf_counter();dec=p.choose_action(s,SearchLimits(max_depth=control['max_depth'],max_nodes=control['max_nodes'],max_time_seconds=None,quiescence_max_depth=control['q'],quiescence_hard_max_depth=8));row={'case':case['case'],'world':case['world'],'role':case['role'],'control':control,'decision':record_value(dec),'seconds':time.perf_counter()-qt};out['queries'].append(row);write_record(D/'results.json',out);pv=s.state
   for raw in row['decision']['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw)
   row['literal_PV_verified']=True;write_record(D/'results.json',out)
  except Exception as e:out['failures'].append({'case':case['case'],'control':control['name'],'error':repr(e),'traceback':traceback.format_exc()});write_record(D/'results.json',out)
 for policy,q in zip(['originalq0','originalq1'],case['original_queries']):
  row={'case':case['case'],'world':case['world'],'role':case['role'],'policy':policy,'selected_action':q['decision']['action'],'opponent_immediate_win':None,'win_within3':'UNKNOWN','reply_witnesses':[],'reply_count':0,'visited_edges':0};actor=case['role']
  if expired():row['cap']='whole_cap';out['witnesses'].append(row);continue
  _,ch=next((a,ch)for a,ch in legal_successors(s.state,c)if record_value(a)==row['selected_action']);row['child_state_sha256']=digest(ch)
  if ch.terminal_status.is_terminal:row['win_within3']='WIN'if ch.terminal_status.winner==actor else'NOT_WIN_WITHIN3'
  else:
   assert ch.position.side_to_move==1-actor;complete=True;failed=False
   for reply,g in legal_successors(ch,c):
    row['reply_count']+=1;row['visited_edges']+=1
    if expired():complete=False;break
    if g.terminal_status.winner==1-actor:row['opponent_immediate_win']={'action':record_value(reply),'terminal':record_value(g.terminal_status),'state_sha256':digest(g)};failed=True;break
    if g.terminal_status.is_terminal:
     if g.terminal_status.winner!=actor:failed=True;row['counterexample_reply']=record_value(reply);break
     row['reply_witnesses'].append({'reply':record_value(reply),'already_terminal_win':True});continue
    assert g.position.side_to_move==actor;win=None;owncomplete=True
    for action,last in legal_successors(g,c):
     row['visited_edges']+=1
     if expired():complete=False;owncomplete=False;break
     if last.terminal_status.winner==actor:win={'action':record_value(action),'terminal':record_value(last.terminal_status),'state_sha256':digest(last)};break
    if not owncomplete:break
    if win is None:failed=True;row['counterexample_reply']=record_value(reply);break
    row['reply_witnesses'].append({'reply':record_value(reply),'winning_response':win})
   row['win_within3']='NOT_WIN_WITHIN3'if failed else'WIN'if complete and row['reply_count']>0 else'UNKNOWN';row['all_replies_complete']=complete and not failed
  out['witnesses'].append(row);write_record(D/'results.json',out)
 print('MECHANISM',case['case'],case['world'],case['role'],len(out['queries']),[(x['policy'],x['win_within3'],bool(x['opponent_immediate_win']))for x in out['witnesses']if x['case']==case['case']],round(time.perf_counter()-tick,1),flush=True)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;write_record(D/'results.json',out);print('MECHANISMCLOSED',len(out['queries']),len(out['witnesses']),len(out['missing']),len(out['failures']),out['seconds'],flush=True)
