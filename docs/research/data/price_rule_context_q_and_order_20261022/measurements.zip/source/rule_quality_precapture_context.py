import sys,json,time,hashlib
from pathlib import Path
from collections import Counter
from dataclasses import replace
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
P=Path('.local_agent/rule-quality-prefix-next-20261022');A=P/'prospective-price-q0-next';B=P/'prospective-price-q0-remove';ra,rb=[json.loads((d/'results.json').read_text())for d in[A,B]];assert ra['status']==rb['status']=='CLOSED';ia,ib=[{w['index']:w for w in json.loads((d/'inputs.json').read_text())['worlds']}for d in[A,B]];aa={(x['world'],x['arm'],x['candidate_role']):x for x in ra['slots']};bb={(x['world'],x['arm'],x['candidate_role']):x for x in rb['slots']};out={'question':'Can capturemodechangeactualselectedsearchactionsBEFOREanyrealcapturewhilephysicalroot/currentboard-and-promotiontables/fullrootleafscoreareequal?','scope':'Boardandpromotionpricesfixed;BASEhandpricesdifferasinertremoveinventorycorrectlyrequires,andfuturelegality/resourcesdiffer. Exactsameinitialfullrulesexceptcapturemode;all36plannedphysicalpairframes,posthocmetadata-onlymechanism,notWDLaliaswithinsameRuleSet. Fullrules/futurelegalresourcesdiffer;bothplayersknowthemode. Missingpairsretained,notpopulationfraction.','rows':[],'missing':[]};tick=time.perf_counter()
def physical(p):return {k:v for k,v in record_value(p).items()if k!='ruleset_fingerprint'}
for key,xa in aa.items():
 xb=bb[key]
 if xa['status']!='finished' or xb['status']!='finished':out['missing'].append({'world':key[0],'arm':key[1],'role':key[2],'pocket':xa['status'],'remove':xb['status']});continue
 ga,gb=[json.loads((d/x['receipt']).read_text())for d,x in[(A,xa),(B,xb)]];recs=[deserialize_game_record(json.dumps(g['final_record']))for g in[ga,gb]];n=next((j for j,(a,b)in enumerate(zip(*(r.actions for r in recs)))if a!=b),None);row={'world':key[0],'arm':key[1],'role':key[2],'first_divergence':n,'same_complete_trajectory':recs[0].actions==recs[1].actions,'both_games_eligible':ga['eligible']and gb['eligible']}
 if n is not None:
  comps=[compile_rule(ruleset_from_dict(w[key[0]]['rule']))for w in[ia,ib]];ss=[GameSession(c)for c in comps];prior_capture=False
  for j in range(n):
   before=sum(z is not None for z in ss[0].state.position.board)
   for s,r in zip(ss,recs):s.submit(r.actions[j])
   after=sum(z is not None for z in ss[0].state.position.board);prior_capture|=after<before
  row['before_any_real_capture']=not prior_capture
  if not prior_capture:
   assert physical(ss[0].state.position)==physical(ss[1].state.position);assert record_value(ss[0].legal_actions())==record_value(ss[1].legal_actions());scores=[]
   for c,s,d in zip(comps,ss,[A,B]):
    base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile
    if key[1]=='B':
     board={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()};hand={t:0 if m.is_anchor or base.hand_value_by_base_type[t]==0 else 900 for t,m in c.support.type_metadata.items()};base=replace(base,board_value_by_type=board,hand_value_by_base_type=hand,promotion_gain_by_type={t:0 for t in board},median_non_anchor_value=1000,piece_profiles={t:replace(p,normalized_board_value=board[t],normalized_hand_value=hand[t],promotion_option_value=0)for t,p in base.piece_profiles.items()})
    scores.append(Evaluator(c,base,EvaluationConfig()).evaluate(s.state))
   assert scores[0]==scores[1];row.update(full_physical_root_equal=True,oneply_legal_actions_equal=True,full_root_leaf_scores=scores,actor=ss[0].state.position.side_to_move,common_records=[record_value(s.to_record())for s in ss],actions=[record_value(r.actions[n])for r in recs],query_sources=[{k:next(q for q in g['queries']if q['root_ply']==n)['decision'][k]for k in['nodes','qnodes','completed_depth','score','result_source']}for g in[ga,gb]])
 out['rows'].append(row)
out['summary']={'planned_pairs':len(aa),'available_pairs':len(out['rows']),'missing_pairs':len(out['missing']),'diverged_pairs':sum(x['first_divergence']is not None for x in out['rows']),'diverged_before_real_capture':sum(x.get('before_any_real_capture',False)for x in out['rows']),'initial_turn_divergence':sum(x['first_divergence']==0 for x in out['rows'])};out['seconds']=time.perf_counter()-tick;write_record(B/'pre-capture-context-diagnosis.json',out);print(json.dumps(out['summary']))
