import json,sys,time,traceback,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.limits import SearchLimits
P=Path('.local_agent/rule-quality-prefix-next-20261022');B=P/'prospective-price-q0-next';C=P/'prospective-price-q-interaction';D=P/'prospective-checkonly-feasibility';D.mkdir(exist_ok=True);assert not(D/'registration.json').exists();inputs=json.loads((B/'inputs.json').read_text());cr=json.loads((B/'results.json').read_text());reg={'question':'Canexistingcheck-onlyq0preservemandatoryleafcheckevasionswithoutfullq1cost,justifyinga24gameutilitytest?','changed_premise':'NEWq1negativeandcapture-onlyq1pilotadds7.96%pusheswith0changedactions,soNOcapture-onlygames. Cheapalternativealreadyexists: q0withcheck-onlyONprotectsmandatoryevasionsatcheckedleaves,omitsordinaryqcaptures/quietchecks. Thisfullnode2048regimeisnotoldD1qreserveprooforfullq1.','configs':'All12samecompleteinitialstates;Staticleaf/Staticmaterialorder/dynamics2/5/3;maxdepth64,node2048,q0check-onlyhard8,noquerydeadline,freshownTT,diskOFF;ONLYuse_check_only_qsearch=True,ordinaryqdepth0.','expected_seconds':30,'whole_cap_seconds':120,'planned_new_queries':12,'reuse':'12exactAStaticq0self-role0initialcoldreturns,0reruns;allworldsbeforeobservedoutcomes,2WIN1kept. Rootsareexposed,notindependentutility/learningholdout.','cost_checkpoint':'Ifall12returnsvalidandtotalpushes<=1.25*pureq0withsomechangedactions,preparebutNOTexecute24wholegames. Thisisprospectivelocalcostforecast,notstrength/equivalenceprooforuniversalengineeringgate.','interpretation':'No whole-gamesorWDLclaim;Nodevisits,pushes,completeddepth/actions/sourceandwallseparate. Concurrentloadlimitswallcomparison. Knownquietcheckomissionsretained;never prune semantics/history inrealrules.','input_sha256':hashlib.sha256((B/'inputs.json').read_bytes()).hexdigest()};write_record(D/'registration.json',reg);out={'registration':reg,'rows':[],'missing':[],'failures':[],'status':'RUNNING'};write_record(D/'results.json',out);tick=time.perf_counter()
class Adapter:
 def __init__(self,e):self.evaluate=e.evaluate;self.type_value=e.type_value;self.capture_order_value=e.capture_order_value
for w in inputs['worlds']:
 if time.perf_counter()-tick>=120:out['missing'].append(w['index']);continue
 try:
  c=compile_rule(ruleset_from_dict(w['rule']));s=GameSession(c);assert record_value(s.state)==w['initial_full_state'];base=AlphaBetaPlayer(c,use_disk_cache=False).evaluation_profile;ev=Evaluator(c,base,EvaluationConfig());p=AlphaBetaPlayer(c,evaluator_override=Adapter(ev),use_disk_cache=False,tuning=SearchTuning(use_check_only_qsearch=True));oldslot=next(x for x in cr['slots']if x['arm']=='A'and x['world']==w['index']and x['candidate_role']==0);old=json.loads((B/oldslot['receipt']).read_text())['queries'][0];assert old['actor']==0 and old['candidate']and old['root_ply']==0;qt=time.perf_counter();dec=p.choose_action(s,SearchLimits(max_depth=64,max_nodes=2048,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=8));row={'world':w['index'],'pureq0_exact_reuse':old,'checkonly_decision':record_value(dec),'seconds':time.perf_counter()-qt};out['rows'].append(row);write_record(D/'results.json',out);pv=s.state
  for raw in row['checkonly_decision']['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw)
  assert dec.nodes+dec.qnodes<=2048 and dec.runtime_depth_balanced;row['literal_pv_and_node_contract_passed']=True
 except Exception as e:out['failures'].append({'world':w['index'],'error':repr(e),'traceback':traceback.format_exc()})
 write_record(D/'results.json',out)
full=sum(x['pureq0_exact_reuse']['decision']['runtime_pushes']for x in out['rows']);cap=sum(x['checkonly_decision']['runtime_pushes']for x in out['rows']);out.update(status='CLOSED',seconds=time.perf_counter()-tick,pureq0_pushes=full,checkonly_pushes=cap,push_ratio=cap/full if full else None,changed_actions=sum(x['checkonly_decision']['action']!=x['pureq0_exact_reuse']['decision']['action']for x in out['rows']),cost_checkpoint_passed=len(out['rows'])==12 and not out['failures']and not out['missing']and cap<=1.25*full and any(x['checkonly_decision']['action']!=x['pureq0_exact_reuse']['decision']['action']for x in out['rows']));write_record(D/'results.json',out);print({k:out[k]for k in['status','seconds','pureq0_pushes','checkonly_pushes','push_ratio','changed_actions','cost_checkpoint_passed']})
