import sys,json,time,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig,MATE_SCORE
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-q-mechanism');src=json.loads((D/'inputs.json').read_text());r=json.loads((D/'results.json').read_text());assert r['status']=='CLOSED';tick=time.perf_counter();out={'question':'Are originalq1actions inferiorincompleteq0D2,andisanyoriginalchoiceanimmediateopponentmateblunder?','scope':'Sixposthocoutcomechangedroots,completeCoreD2withsameStaticdynamics;notterminalWDL/independentengine/genericreferencegate. NOT_WIN_WITHIN3counterexamplesvalidatedseparately. Earlycounterexampleinoriginalwin3scannerdoesNOTprovetherearenootherimmediatewinningopponentreplies.','cases':[],'all_cold_PVs':0,'Core_edges':0,'status':'RUNNING','missing':[]};write_record(D/'independent-qualified.json',out)
def digest(x):return hashlib.sha256(json.dumps(record_value(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def terminal_value(state,actor,ply):return 0 if state.terminal_status.winner is None else MATE_SCORE-ply if state.terminal_status.winner==actor else -MATE_SCORE+ply
for case in src['cases']:
 if time.perf_counter()-tick>300:out['missing'].append(case['case']);continue
 c=compile_rule(ruleset_from_dict(case['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(case['common_record'])));assert record_value(s.state)==case['common_full_state'];actor=case['role'];p=AlphaBetaPlayer(c,use_disk_cache=False);ev=Evaluator(c,p.evaluation_profile,EvaluationConfig());legal=list(legal_successors(s.state,c));branches=[]
 for a,ch in legal:
  out['Core_edges']+=1
  if ch.terminal_status.is_terminal:value=terminal_value(ch,actor,1);replies=[]
  else:
   assert ch.position.side_to_move==1-actor;replies=list(legal_successors(ch,c));assert replies;vals=[]
   for b,g in replies:
    out['Core_edges']+=1;assert g.terminal_status.is_terminal or g.position.side_to_move==actor;vals.append(terminal_value(g,actor,2)if g.terminal_status.is_terminal else ev.evaluate(g))
   value=min(vals)
  branches.append({'action':record_value(a),'value_D2q0':value,'reply_count':len(replies),'immediate_opponent_win_replies':[{'action':record_value(b),'terminal':record_value(g.terminal_status),'state_sha256':digest(g)}for b,g in replies if g.terminal_status.winner==1-actor]})
 best=max(x['value_D2q0']for x in branches);controls=[]
 for q in [q for q in r['queries']if q['case']==case['case']]:
  dec=q['decision'];assert dec['nodes']+dec['qnodes']<=q['control']['max_nodes'] and dec['runtime_depth_balanced'];pv=s.state
  for raw in dec['principal_variation']:_,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);out['all_cold_PVs']+=1
  if q['control']['name']=='q0D2reference':assert dec['completed_depth']==2 and dec['termination_reason']=='completed_depth';assert dec['score']==best
  controls.append({'name':q['control']['name'],'score':dec['score'],'depth':dec['completed_depth'],'ordinary_qdepth':dec['result_ordinary_qdepth'],'action':dec['action'],'same_as_originalq0':dec['action']==case['original_queries'][0]['decision']['action'],'same_as_originalq1':dec['action']==case['original_queries'][1]['decision']['action'],'main_nodes':dec['nodes'],'qnodes':dec['qnodes'],'runtime_pushes':dec['runtime_pushes'],'termination':dec['termination_reason'],'seconds':q['seconds']})
 originals=[]
 for name,q in zip(['q0','q1'],case['original_queries']):
  br=next(x for x in branches if x['action']==q['decision']['action']);originals.append({'policy':name,'value_D2q0':br['value_D2q0'],'gap_to_best_D2q0':best-br['value_D2q0'],'immediate_loss_reply_count':len(br['immediate_opponent_win_replies']),'returned_depth':q['decision']['completed_depth'],'returned_qdepth':q['decision']['result_ordinary_qdepth'],'nodes':q['decision']['nodes'],'qnodes':q['decision']['qnodes'],'source':q['decision']['result_source']})
 for w in [w for w in r['witnesses']if w['case']==case['case']]:
  _,ch=next((a,ch)for a,ch in legal if record_value(a)==w['selected_action']);assert digest(ch)==w['child_state_sha256']
  if 'counterexample_reply'in w:
   _,g=next((b,g)for b,g in legal_successors(ch,c)if record_value(b)==w['counterexample_reply']);assert g.terminal_status.winner!=actor
   if not g.terminal_status.is_terminal:assert not any(z.terminal_status.winner==actor for a,z in legal_successors(g,c))
  assert w['win_within3']=='NOT_WIN_WITHIN3'
 out['cases'].append({'case':case['case'],'world':case['world'],'role':actor,'full_D2q0_best':best,'full_D2q0_support_size':sum(x['value_D2q0']==best for x in branches),'branches':branches,'original_actions':originals,'cold_controls':controls,'all_existing_counterexamples_verified':True});write_record(D/'independent-qualified.json',out);print('ROOTREF',case['case'],case['world'],actor,best,originals,flush=True)
out['status']='CLOSED';out['seconds']=time.perf_counter()-tick;out['all_passed']=not out['missing'];write_record(D/'independent-qualified.json',out);print('QMECHQUAL',len(out['cases']),out['Core_edges'],out['all_cold_PVs'],out['seconds'])
