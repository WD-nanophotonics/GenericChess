import json,sys,hashlib,time
from pathlib import Path
from dataclasses import replace
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=Path('.local_agent/rule-quality-prefix-next-20261022/prospective-price-q0-next');r=json.loads((D/'results.json').read_text());assert r['status']=='CLOSED';worlds={w['index']:w for w in json.loads((D/'inputs.json').read_text())['worlds']};base={x['world']:x for x in r['slots'] if x['arm']=='A'};rows=[];tick=time.perf_counter();contexts={}
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
for x in r['slots']:
 if x['arm']!='B' or x['status']!='finished':continue
 a=json.loads((D/base[x['world']]['receipt']).read_text());b=json.loads((D/x['receipt']).read_text());ra=deserialize_game_record(json.dumps(a['final_record']));rb=deserialize_game_record(json.dumps(b['final_record']));n=next((i for i,(u,v) in enumerate(zip(ra.actions,rb.actions)) if u!=v),None);row={'world':x['world'],'candidate_role':x['candidate_role'],'static_source_slot':base[x['world']]['slot'],'unit_source_slot':x['slot'],'static_utility':a['candidate_utility_interval'] if x['candidate_role']==0 else [-a['candidate_utility_interval'][1],-a['candidate_utility_interval'][0]],'unit_utility':b['candidate_utility_interval'],'first_divergence_ply':n,'identical_full_records':ra==rb,'same_prefix_but_different_lengths':n is None and ra!=rb}
 if n is not None:
  w=x['world'];c=contexts.setdefault(w,compile_rule(ruleset_from_dict(worlds[w]['rule'])));s=GameSession.replay(c,replace(ra,actions=ra.actions[:n]));assert record_value(s.state)==record_value(GameSession.replay(c,replace(rb,actions=rb.actions[:n])).state);assert s.state.position.side_to_move==x['candidate_role'];qa=next(q for q in a['queries'] if q['root_ply']==n);qb=next(q for q in b['queries'] if q['root_ply']==n);row.update(common_full_record=record_value(s.to_record()),common_full_state_sha256=digest(record_value(s.state)),static_action=record_value(ra.actions[n]),unit_action=record_value(rb.actions[n]),paired_query_metadata=[{k:q[k] for k in ['seconds','limits','requested_depth']}|{'decision':{k:q['decision'][k] for k in ['action','score','completed_depth','nodes','qnodes','runtime_pushes','result_source','termination_reason','principal_variation']}} for q in [qa,qb]])
 rows.append(row)
out={'question':'Did Unit andStaticpricepolicies actuallydiverge innewq0games despite unresolved/no finiteadvantage?','scope':'Exactsamecompletehistory untilfirstactiondifference; ownTTandprices arepartofpolicy. Differentpostdivergence outcomes not singlemoveWDLproof. No newqueries;all24roleframes retained.','cases':rows,'summary':{'role_frames':len(rows),'changed_trajectories':sum(x['first_divergence_ply']is not None for x in rows),'identical_trajectories':sum(x['identical_full_records'] for x in rows),'resolved_same_outcome':sum(x['static_utility']==x['unit_utility'] and x['static_utility'][0]==x['static_utility'][1] for x in rows),'both_ongoing_not_coupled':sum(x['static_utility']==x['unit_utility']==[-1,1] for x in rows),'resolved_different_outcome':sum(x['static_utility']!=x['unit_utility'] and x['static_utility'][0]==x['static_utility'][1] and x['unit_utility'][0]==x['unit_utility'][1] for x in rows)},'seconds':time.perf_counter()-tick};write_record(D/'policy-divergence.json',out);print(json.dumps(out['summary']))
