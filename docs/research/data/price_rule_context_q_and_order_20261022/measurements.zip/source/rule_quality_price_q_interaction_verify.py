import json,sys,time,hashlib
from pathlib import Path
from fractions import Fraction
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
P=Path('.local_agent/rule-quality-prefix-next-20261022');D=P/'prospective-price-q-interaction';I=P/'prospective-price-q0-next/inputs.json'
r=json.loads((D/'results.json').read_text());assert r['status']=='CLOSED';assert hashlib.sha256(I.read_bytes()).hexdigest()==r['registration']['input_sha256'];worlds={w['index']:w for w in json.loads(I.read_text())['worlds']};contexts={};out={'scope':'IndependentfullCorehistory/PV/terminal qualification;actualrequested/completeddepths reported. Not scalarqvalue or generic-equivalence proof. No repeated games.','games':[],'queries':0,'history_plies':0,'pv_plies':0,'errors':[],'unattempted':r['unattempted_slots']};tick=time.perf_counter();counts=Counter()
for slot in r['slots']:
 if slot['status']!='finished':out['errors'].append({'slot':slot['slot'],'source_status':slot['status']});continue
 g=json.loads((D/slot['receipt']).read_text());w=slot['world'];role=slot['candidate_role']
 if w not in contexts:contexts[w]=compile_rule(ruleset_from_dict(worlds[w]['rule']))
 c=contexts[w];s=GameSession(c);rec=deserialize_game_record(json.dumps(g['final_record']));assert record_value(s.to_record())==g['initial_record'];assert len(g['queries'])in (len(rec.actions),len(rec.actions)+1)
 for qi,q in enumerate(g['queries']):
  assert q['root_ply']==s.state.ply_count;actor=s.state.position.side_to_move;assert q['actor']==actor;assert q['candidate']==(actor==role);expected_depth=r['registration']['arms'][slot['arm']]['depth']if q['candidate']else 64;assert q['requested_depth']==expected_depth;limits=q['limits'];assert limits['max_time_seconds']is None;assert limits['max_nodes']==(r['registration']['arms'][slot['arm']]['nodes']if q['candidate']else 2048);assert limits['quiescence_max_depth']==(1 if q['candidate'] else 0);assert q['candidate'] or q['decision']['qnodes']==0;dec=q['decision'];assert dec['runtime_depth_balanced'];assert dec['nodes']+dec['qnodes']<=limits['max_nodes'];pv=s.state
  for raw in dec['principal_variation']:
   _,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);out['pv_plies']+=1
  if dec['result_source']=='root_immediate_win':assert pv.terminal_status.winner==actor
  counts[(slot['arm'],'candidate'if q['candidate']else'opponent',expected_depth,dec['completed_depth'],dec['result_ordinary_qdepth'],dec['result_source'])]+=1;out['queries']+=1
  if qi<len(rec.actions):assert record_value(rec.actions[qi])==dec['action'];s.submit(rec.actions[qi]);out['history_plies']+=1
  else:assert g['censor']or g['failure'];assert qi==len(rec.actions)
 assert record_value(s.state)==g['final_state'];assert record_value(s.result)==g['terminal'];value=None if not g['eligible']or g['terminal']['status']in('ongoing','no_contest')else 0 if g['terminal']['winner']is None else 1 if g['terminal']['winner']==role else-1;assert g['candidate_utility_interval']==([value,value]if value is not None else[-1,1]);out['games'].append({'slot':slot['slot'],'world':w,'arm':slot['arm'],'role':role,'eligible':g['eligible'],'terminal':g['terminal'],'utility':g['candidate_utility_interval'],'verified':True})
out['actual_depth_sources']={str(k):v for k,v in counts.items()};out['seconds']=time.perf_counter()-tick;out['all_retained_games_passed']=True;write_record(D/'qualified.json',out);print('FIXEDQUAL',len(out['games']),out['queries'],out['history_plies'],out['pv_plies'],out['seconds'])
