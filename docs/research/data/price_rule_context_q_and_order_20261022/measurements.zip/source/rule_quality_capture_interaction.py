import sys,json,itertools
from pathlib import Path
from fractions import Fraction
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
P=Path('.local_agent/rule-quality-prefix-next-20261022');dirs={'pocket':P/'prospective-price-q0-next','remove':P/'prospective-price-q0-remove'};cells={};variables={};raw={}
for env,d in dirs.items():
 r=json.loads((d/'results.json').read_text());assert r['status']=='CLOSED';raw[env]=r
 for x in r['slots']:
  key=(env,x['arm'],x['world'],x['candidate_role']);variables[key]=x['candidate_utility_interval'];cells[key]=(key,1)
  if x['arm']=='A':
   if x['status']=='finished'and x['eligible']:cells[env,'A',x['world'],1]=(key,-1)
   else:v=(env,'A_virtual_unverified',x['world'],1);variables[v]=[-1,1];cells[env,'A',x['world'],1]=(v,1)
forms={'price_pocket':{('pocket','B'):1,('pocket','A'):-1},'price_remove':{('remove','B'):1,('remove','A'):-1},'capture_by_price_interaction':{('remove','B'):1,('remove','A'):-1,('pocket','B'):-1,('pocket','A'):1}}
def bound(coefs,worlds):
 cs={}
 for w in worlds:
  for role in(0,1):
   for (env,arm),scale in coefs.items():v,sign=cells[env,arm,w,role];cs[v]=cs.get(v,0)+Fraction(scale*sign,2*len(worlds))
 return [str(sum(c*Fraction(variables[v][side if c>=0 else 1-side])for v,c in cs.items()))for side in(0,1)]
out={'question':'Does changingcapturecustodyalterthescopedStatic/Unitwhole-policypriceeffectatcommon2048q0?','scope':'OnlycaptureRuleSetfieldchanged,allotherfullfields/initialphysicalroots/actions/board+promotionpricesheldfixed. Handpricescorrectlyreflectinertremovehands. Bothplayersoperateunderthenewrule. No isolatedleafhandpriceorboard-onlyWDLimpossibilityclaim. All12plannedconfigs andmissing/censoredrolesincluded;newRuleSetfuturetailsindependentofoldpocket,evenidenticalprefixes.','effects':{k:bound(v,list(range(12)))for k,v in forms.items()},'families':[{'world':w,'effects':{k:bound(v,[w])for k,v in forms.items()}}for w in range(12)],'unattempted':{e:r['unattempted_slots']for e,r in raw.items()},'source_failures':{e:r['failures']for e,r in raw.items()},'independent_endpoint_vertices':0}
for family in out['families']:
 w=family['world'];ks=list({v for env in dirs for a in ['A','B']for role in(0,1)for v,sgn in[cells[env,a,w,role]]});mins={k:None for k in forms};maxs={k:None for k in forms}
 for ends in itertools.product(*(tuple(dict.fromkeys(variables[k]))for k in ks)):
  vals=dict(zip(ks,map(Fraction,ends)));out['independent_endpoint_vertices']+=1
  for name,coefs in forms.items():
   v=sum(Fraction(scale*sgn,2)*vals[k]for(env,a),scale in coefs.items()for role in(0,1)for k,sgn in[cells[env,a,w,role]]);mins[name]=v if mins[name]is None else min(mins[name],v);maxs[name]=v if maxs[name]is None else max(maxs[name],v)
 assert {k:list(map(str,[mins[k],maxs[k]]))for k in forms}==family['effects']
write_record(dirs['remove']/'capture-interaction.json',out);print(json.dumps({'effects':out['effects'],'unattempted':out['unattempted'],'vertices':out['independent_endpoint_vertices']}))
