"""Independent replay of completed game receipts using the existing full Core."""
import json,time,sys
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import record_value,write_record
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import action_to_dict
from generic_chess.core.transition import apply_action,legal_successors
from generic_chess.ai.benchmark.runner import _timing_invalid
P=Path('.local_agent/root-clock-20261022');status=json.loads((P/'results.json').read_text(encoding='utf-8'));worlds=json.loads((P/'inputs.json').read_text(encoding='utf-8'))['worlds'];target=P/'verified.json';out=json.loads(target.read_text(encoding='utf-8')) if target.exists() else {'games':[],'failures':[]};done={r['slot'] for r in out['games']};contexts={};begin=time.perf_counter()
for slot in status['slots']:
 if slot['status']!='finished' or slot['slot'] in done:continue
 w=next(w for w in worlds if w['seed']==slot['seed']);c=contexts.get(w['seed'])
 if c is None:c=contexts[w['seed']]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(w['rule']))
 g=json.loads((P/slot['receipt']).read_text(encoding='utf-8'));record=deserialize_game_record(json.dumps(g['final_record']));s=GameSession(c);states=[s.state]
 for a in record.actions:s.submit(a);states.append(s.state)
 assert record_value(s.state)==g['final_state'];assert record_value(s.state.terminal_status)==g['raw_terminal']
 row={'slot':slot['slot'],'seed':w['seed'],'history_plies':len(record.actions),'queries':len(g['queries']),'pv_plies':0,'literal_win1_proofs':0,'sources':{},'query_policy':{},'fallbacks':0,'time_invalid':0,'operational_failures':0,'raw_result':g['raw_result'],'utility_interval':g['utility_interval'],'scope':'Literal PV legality/full state and terminal authority, not unseen q-tail/full-WDL certification.'};counts=Counter();policies=Counter();samples=[]
 for q in g['queries']:
  d=q['decision'];k=q['root_ply'];st=states[k];counts[(q['policy'],d['result_source'])]+=1;policies[(q['policy'],d['completed_depth'],d['result_ordinary_qdepth'],d['result_check_hard_qdepth'])]+=1
  assert d['runtime_depth_balanced'];assert q['actor']==st.position.side_to_move
  if d['action'] is not None:
   legal=[a for a,ch in legal_successors(st,c)];a=next(a for a in legal if record_value(a)==d['action'])
   if q['applied']:assert record.actions[k]==a
  pv=st
  for raw in d['principal_variation']:
   a,ch=next((a,ch) for a,ch in legal_successors(pv,c) if record_value(a)==raw);pv=ch;row['pv_plies']+=1
  if d['result_source']=='root_immediate_win':assert pv.terminal_status.is_terminal and pv.terminal_status.winner==st.position.side_to_move;row['literal_win1_proofs']+=1
  row['fallbacks']+=d['result_source'] in {'fallback','legal_fallback','root_scan_fallback'} or d['termination_reason']=='fallback';row['time_invalid']+=_timing_invalid(q['seconds'],1);row['operational_failures']+=d['native_legality_operational_failures']
 row['sources']={str(k):v for k,v in counts.items()};row['query_policy']={str(k):v for k,v in policies.items()};out['games'].append(row);write_record(target,out);print('VERIFIED',slot['slot'],row['queries'],row['pv_plies'],flush=True)
out['verified_games']=len(out['games']);out['query_count']=sum(r['queries'] for r in out['games']);out['pv_plies']=sum(r['pv_plies'] for r in out['games']);out['history_plies']=sum(r['history_plies'] for r in out['games']);out['pass_seconds']=time.perf_counter()-begin;out['coverage_status']='Only files whose producer marks finished; running files not read.';write_record(target,out);print('CORE',out['verified_games'],out['query_count'],out['pv_plies'],round(out['pass_seconds'],3),flush=True)
