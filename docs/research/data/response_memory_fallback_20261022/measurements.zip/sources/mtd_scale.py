"""MTD(f) feasibility over the existing alpha-beta kernel; full-PV cost included."""
import json,time,random,sys,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
import generic_chess.ai.alphabeta.search as search
P=Path('.local_agent/counter-20261022');reg=json.loads((P/'mtd-scale-registration.json').read_text(encoding='utf-8'));worlds=json.loads((P/'inputs.json').read_text(encoding='utf-8'))['worlds'];assert not(P/'mtd-scale-results.json').exists();original=search._aspiration_iteration;current=None

def mtd_iteration(state,depth,guess,ctx):
 lower,upper=-search.INF,search.INF;iteration={'depth':depth,'initial_guess':guess,'passes':[],'converged':False};current['iterations'].append(iteration)
 while lower<upper:
  if len(iteration['passes'])>=reg['per_iteration_pass_cap']:raise search.SearchAborted('mtd_pass_limit')
  beta=guess+1 if guess==lower else guess
  tick=time.perf_counter();before=ctx.stats.nodes;result=search.negamax(state,depth,beta-1,beta,0,ctx,pv_node=False);guess=result.score
  if guess<beta:upper=guess
  else:lower=guess
  iteration['passes'].append({'beta':beta,'score':guess,'lower':lower,'upper':upper,'nodes':ctx.stats.nodes-before,'seconds':time.perf_counter()-tick,'bound_action':record_value(result.best_action)})
  assert lower<=upper
 iteration['converged']=True;iteration['value']=guess;before=ctx.stats.nodes;tick=time.perf_counter()
 # require_full_pv is true for BOTH arms. A numeric bound is not an exact move/PV.
 exact=search.negamax(state,depth,-search.INF,search.INF,0,ctx,pv_node=True)
 iteration.update(reconstruction_nodes=ctx.stats.nodes-before,reconstruction_seconds=time.perf_counter()-tick,reconstructed_score=exact.score,reconstructed_action=record_value(exact.best_action));assert exact.score==guess
 return exact

class ScaleEvaluator:
 def __init__(self,original,factor):self.original=original;self.factor=factor;self.calls=0;self.clipped=0;self.max_abs_raw=0
 def __getattr__(self,name):return getattr(self.original,name)
 def evaluate(self,state):
  from generic_chess.ai.evaluation.config import MAX_STATIC_EVAL
  raw=self.original.evaluate(state);value=raw*self.factor;self.calls+=1;self.max_abs_raw=max(self.max_abs_raw,abs(raw));self.clipped+=abs(value)>MAX_STATIC_EVAL;return value

search._aspiration_iteration=mtd_iteration;begin=time.perf_counter();contexts={};plan=[]
for w in worlds:
 c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(w['rule']));contexts[w['seed']]=c
 for root in w['roots']:
  if root['terminal']['status']!='ongoing' or len(root['record']['actions'])!=root['target']:continue
  for depth in reg['depths']:
   for arm in reg['arms']:
    for scale in reg['leaf_factors']:plan.append((w,root,depth,arm,scale))
random.Random(reg['shuffle_seed']).shuffle(plan);out={'protocol':reg,'planned_queries':len(plan),'rows':[],'failures':[]};write_record(P/'mtd-scale-results.json',out)
for w,root,depth,arm,scale in plan:
 if time.perf_counter()-begin>=reg['whole_seconds']:break
 c=contexts[w['seed']];session=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));before=session.state,session.to_record(),session._search_witnesses
 current={'seed':w['seed'],'prefix':root['target'],'depth':depth,'arm':arm,'leaf_factor':scale,'iterations':[]};out['rows'].append(current);write_record(P/'mtd-scale-results.json',out);tick=time.perf_counter()
 try:
  player=AlphaBetaPlayer(c,use_disk_cache=False,tuning=SearchTuning(use_aspiration=arm=='mtd_fullPV',aspiration_start_depth=2,require_full_pv=True));player._evaluator=ScaleEvaluator(player._evaluator,scale);current['setup_seconds']=time.perf_counter()-tick;tick=time.perf_counter();decision=player.choose_action(session,SearchLimits(max_depth=depth,max_nodes=reg['nodes'],max_time_seconds=reg['query_seconds'],quiescence_max_depth=0,quiescence_hard_max_depth=0));current['decision']=record_value(decision);current['query_seconds']=time.perf_counter()-tick;current['leaf_trace']={'calls':player._evaluator.calls,'clipped':player._evaluator.clipped,'max_abs_raw':player._evaluator.max_abs_raw};write_record(P/'mtd-scale-results.json',out);assert before==(session.state,session.to_record(),session._search_witnesses)
 except Exception as e:
  current['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};out['failures'].append({'seed':w['seed'],'prefix':root['target'],'depth':depth,'arm':arm,'failure':current['failure']})
 out['wall_seconds']=time.perf_counter()-begin;write_record(P/'mtd-scale-results.json',out);print('MTD',len(out['rows']),w['seed'],root['target'],depth,arm,current.get('decision',{}).get('completed_depth'),round(out['wall_seconds'],3),flush=True)
out.update(closed=True,wall_seconds=time.perf_counter()-begin,missing_queries=len(plan)-len(out['rows']));write_record(P/'mtd-scale-results.json',out)
