"""Aux-delta q inclusion feasibility using the unchanged search and full Core."""
import sys,json,time,random,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import record_value,write_record
from scripts.semantic_probe_cost import unit_evaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
import generic_chess.ai.alphabeta.search as search
import generic_chess.ai.alphabeta.quiescence as qmod
P=Path('.local_agent/aux-frontier-20261022');reg=json.loads((P/'registration.json').read_text(encoding='utf-8'));assert not(P/'results.json').exists();start=time.perf_counter();worlds=json.loads(Path('.local_agent/root-allocation-20261022/semantic-budget-inputs.json').read_text(encoding='utf-8'))['worlds'];controls=json.loads(Path('.local_agent/counter-20261022/inputs.json').read_text(encoding='utf-8'))['worlds'];worlds+=[{**w,'roots':[r for r in w['roots']if r['target']==0]}for w in controls];write_record(P/'inputs.json',{'worlds':worlds});contexts={};roots={};out={'protocol':reg,'inventory':[],'rows':[],'failures':[]};original=qmod.material_inventory

def augmented(position):
 inventory=original(position);inventory[('aux_marker',position.aux_state)]=1;return inventory

for w in worlds:
 rule=ruleset_from_dict(w['rule']);c=(compile_ruleset_for_execution(rule)if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule));contexts[w['seed']]=c
 for root in w['roots']:
  s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));key=(w['seed'],root['target']);roots[key]=s
  if s.state.terminal_status.is_terminal:continue
  children=legal_successors(s.state,c);noisy=qmod.classify_noisy(s.state,children,c);quiet_aux=[a for a,ch in children if ch.position.aux_state!=s.state.position.aux_state and a not in noisy]
  out['inventory'].append({'seed':key[0],'prefix':key[1],'legal_count':len(children),'default_noisy':len(noisy),'quiet_aux_changes':[record_value(a)for a in quiet_aux],'aux_state':record_value(s.state.position.aux_state),'negative_control':key[0]>=202610227001})
plan=[((r['seed'],r['prefix']),arm)for r in out['inventory']for arm in('baseline','aux_delta')];random.Random(reg['shuffle_seed']).shuffle(plan);out['planned_queries']=len(plan);write_record(P/'results.json',out)
for key,arm in plan:
 if time.perf_counter()-start>=reg['whole_seconds']:break
 qmod.material_inventory=search.material_inventory=augmented if arm=='aux_delta'else original
 c=contexts[key[0]];s=roots[key];before=s.state,s.to_record(),s._search_witnesses;row={'seed':key[0],'prefix':key[1],'arm':arm};out['rows'].append(row);write_record(P/'results.json',out);tick=time.perf_counter()
 try:
  player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=unit_evaluator(c));row['setup_seconds']=time.perf_counter()-tick;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=4,quiescence_hard_max_depth=8));row['decision']=record_value(d);row['query_seconds']=time.perf_counter()-tick;row['native_provider_available']=player.native_legality_provider is not None;write_record(P/'results.json',out);assert before==(s.state,s.to_record(),s._search_witnesses)
  pv=s.state;plies=0
  for raw in row['decision']['principal_variation']:
   a,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);plies+=1
  row['Core_PV_plies']=plies
 except Exception as e:row['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};out['failures'].append({'seed':key[0],'prefix':key[1],'arm':arm,'failure':row['failure']})
 out['wall_seconds']=time.perf_counter()-start;write_record(P/'results.json',out);print('AUX',len(out['rows']),key,arm,row.get('decision',{}).get('completed_depth'),flush=True)
out.update(closed=True,wall_seconds=time.perf_counter()-start,missing_queries=len(plan)-len(out['rows']));write_record(P/'results.json',out)
