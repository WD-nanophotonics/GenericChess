"""Thin paired driver for the maintained full-state cost caller; no search code."""
import json,time,random,subprocess,sys,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
P=Path('.local_agent/counter-20261022');reg=json.loads((P/'registration.json').read_text(encoding='utf-8'));assert not(P/'curve-status.json').exists()
tick=time.perf_counter();out={'worlds':[],'failures':[]};contexts=[];status={'stage':'generation','completed':[],'failures':[],'planned_queries':432};write_record(P/'curve-status.json',status)
for cfg in reg['configs']:
 if time.perf_counter()-tick>=reg['whole_seconds']:break
 try:
  start=time.perf_counter();g=generate_game(GeneratorConfig(**cfg));c=compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=GameSession(c);w={'seed':cfg['seed'],'config':cfg,'rule':ruleset_to_dict(g.ruleset),'generation_report':record_value(g.generation_report),'roots':[]};out['worlds'].append(w);walk=random.Random(cfg['seed']+1)
  for prefix in reg['prefixes']:
   while s.state.ply_count<prefix and not s.state.terminal_status.is_terminal:s.submit(walk.choice(s.legal_actions()))
   w['roots'].append({'target':prefix,'record':record_value(s.to_record()),'terminal':record_value(s.state.terminal_status)})
  w['setup_seconds']=time.perf_counter()-start;write_record(P/f"input-{cfg['seed']}.json",{'worlds':[w]})
 except Exception as e:out['failures'].append({'config':cfg,'error':str(e),'type':type(e).__name__,'traceback':traceback.format_exc()})
 write_record(P/'inputs.json',out);print('INPUT',cfg['seed'],flush=True)
plan=[(w['seed'],d,v) for w in out['worlds'] for d in reg['depths'] for v in reg['variants']];random.Random(reg['shuffle_seed']).shuffle(plan);status.update(stage='queries',execution_order=plan);write_record(P/'curve-status.json',status)
for seed,d,v in plan:
 if time.perf_counter()-tick>=reg['whole_seconds']:break
 path=P/f'curve-{seed}-d{d}-{v}.json';cmd=[sys.executable,'scripts/semantic_probe_cost.py','--input',str(P/f'input-{seed}.json'),'--output',str(path),'--seed-count','1','--prefixes','0','12','--variants','legal','--depth',str(d),'--qdepth','0','--nodes',str(reg['nodes']),'--seconds',str(reg['query_seconds']),'--total-seconds','20']
 if v in ('counter','both'):cmd+=['--countermove']
 if v in ('staged','both'):cmd+=['--staged-move-picker']
 start=time.perf_counter();r=subprocess.run(cmd,text=True,encoding='utf-8',errors='replace',capture_output=True);status['completed'].append({'seed':seed,'depth':d,'variant':v,'returncode':r.returncode,'file':path.name,'process_seconds':time.perf_counter()-start});
 if r.returncode:status['failures'].append({'seed':seed,'depth':d,'variant':v,'stdout':r.stdout,'stderr':r.stderr})
 status['wall_seconds']=time.perf_counter()-tick;write_record(P/'curve-status.json',status);print('CURVE',len(status['completed']),seed,d,v,round(status['wall_seconds'],3),flush=True)
status.update(stage='closed',wall_seconds=time.perf_counter()-tick,unexecuted_processes=len(plan)-len(status['completed']));write_record(P/'curve-status.json',status);print('CLOSED',status['wall_seconds'],flush=True)
