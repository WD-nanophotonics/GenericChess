"""Root budget comparison on published complete semantic inputs; existing APIs only."""
import sys,json,time,random,zipfile,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import record_value,write_record
from scripts.semantic_probe_cost import unit_evaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
P=Path('.local_agent/root-allocation-20261022');reg=json.loads((P/'semantic-budget-registration.json').read_text(encoding='utf-8'));assert not(P/'semantic-budget-results.json').exists();begin=time.perf_counter();worlds=[]
with zipfile.ZipFile('docs/research/data/search_windows_20261022/measurements.zip')as z:
 for name in ['unit-square-inputs.json','unit-drop-inputs.json']+[f'unit-token-input-{i}.json'for i in range(4)]:worlds+=json.loads(z.read(name))['worlds']
write_record(P/'semantic-budget-inputs.json',{'worlds':worlds,'source_commit':'60e1b23c87002f81f19994bd68f9ffa20437a57b'})
contexts={};roots={};out={'protocol':reg,'inventory':[],'rows':[],'failures':[]};plan=[]
for w in worlds:
 rule=ruleset_from_dict(w['rule']);c=(compile_ruleset_for_execution(rule)if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule));contexts[w['seed']]=c
 for root in w['roots']:
  s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));key=(w['seed'],root['target']);roots[key]=s
  if s.state.terminal_status.is_terminal:continue
  tick=time.perf_counter();successors=legal_successors(s.state,c);out['inventory'].append({'seed':w['seed'],'prefix':root['target'],'legal_count':len(successors),'win1_actions':[record_value(a)for a,ch in successors if ch.terminal_status.is_terminal and ch.terminal_status.winner==s.state.position.side_to_move],'full_aux_state':record_value(s.state.position.aux_state),'inventory_seconds':time.perf_counter()-tick,'history_plies':len(s.to_record().actions)})
  for n in reg['budgets']:
   for arm in reg['arms']:plan.append((key,n,arm))
random.Random(202610229912).shuffle(plan);out['planned_queries']=len(plan);write_record(P/'semantic-budget-results.json',out)
for key,n,arm in plan:
 if time.perf_counter()-begin>=reg['whole_seconds']:break
 s=roots[key];c=contexts[key[0]];before=s.state,s.to_record(),s._search_witnesses;row={'seed':key[0],'prefix':key[1],'nodes':n,'arm':arm};out['rows'].append(row);write_record(P/'semantic-budget-results.json',out);tick=time.perf_counter()
 try:
  player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=unit_evaluator(c),tuning=SearchTuning(use_root_tactical=arm=='scan_on'));row['setup_seconds']=time.perf_counter()-tick;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=n,max_time_seconds=reg['query_seconds'],quiescence_max_depth=4,quiescence_hard_max_depth=8));row['decision']=record_value(d);row['query_seconds']=time.perf_counter()-tick;row['native_provider_available']=player.native_legality_provider is not None;write_record(P/'semantic-budget-results.json',out);assert before==(s.state,s.to_record(),s._search_witnesses)
  pv=s.state;steps=0
  for raw in row['decision']['principal_variation']:
   a,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);steps+=1
  if d.result_source=='root_immediate_win':assert pv.terminal_status.is_terminal and pv.terminal_status.winner==s.state.position.side_to_move
  row['Core_PV_plies']=steps
 except Exception as e:row['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};out['failures'].append({'seed':key[0],'prefix':key[1],'nodes':n,'arm':arm,'failure':row['failure']})
 out['wall_seconds']=time.perf_counter()-begin;write_record(P/'semantic-budget-results.json',out);print('SEMANTIC',len(out['rows']),key,n,arm,row.get('decision',{}).get('result_source'),flush=True)
out.update(closed=True,wall_seconds=time.perf_counter()-begin,missing_queries=len(plan)-len(out['rows']));write_record(P/'semantic-budget-results.json',out)
