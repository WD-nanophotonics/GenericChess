"""Private q0 first-iteration fallback reuse; existing search/kernel unchanged."""
import json,time,random,sys,traceback
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import record_value,write_record
from scripts.semantic_probe_cost import unit_evaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
import generic_chess.ai.alphabeta.search as search
P=Path('.local_agent/partial-fallback-20261022');reg=json.loads((P/'registration.json').read_text(encoding='utf-8'));original=search.negamax;capture=None

def observe(state,depth,alpha,beta,ply,ctx,*a,**kw):
 result=original(state,depth,alpha,beta,ply,ctx,*a,**kw)
 if capture is not None and ply==1 and depth==0 and ctx.first_main_iteration_complete is False:
  action=kw.get('prev_action') if 'prev_action'in kw else (a[0] if a else None)
  if action is not None:
   value=-result.score;capture['completed_children']+=1
   if capture['best']is None or value>capture['best'][0]:capture['best']=(value,action)
 return result
search.negamax=observe
class PartialPlayer(AlphaBetaPlayer):
 def __init__(self,*a,partial=False,**kw):super().__init__(*a,**kw);self.partial=partial;self.observation=None
 def choose_action(self,session,limits,**kw):
  global capture
  capture={'completed_children':0,'best':None};d=super().choose_action(session,limits,**kw);self.observation={'completed_children':capture['completed_children'],'best_value':capture['best'][0]if capture['best']else None,'best_action':record_value(capture['best'][1])if capture['best']else None,'substituted':False}
  if self.partial and d.choice_kind=='ACTION'and d.result_source=='legal_fallback'and capture['best']is not None:
   self.observation['substituted']=d.action!=capture['best'][1];d=replace(d,action=capture['best'][1])
  capture=None;return d

def main():
 assert not(P/'results.json').exists();start=time.perf_counter();worlds=json.loads(Path('.local_agent/aux-frontier-20261022/inputs.json').read_text(encoding='utf-8'))['worlds'];write_record(P/'inputs.json',{'worlds':worlds});contexts={};roots={};out={'protocol':reg,'references':[],'rows':[],'failures':[]}
 for w in worlds:
  rule=ruleset_from_dict(w['rule']);c=(compile_ruleset_for_execution(rule)if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule));contexts[w['seed']]=c;ev=unit_evaluator(c)
  for root in w['roots']:
   s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));key=(w['seed'],root['target']);roots[key]=s
   if s.state.terminal_status.is_terminal:continue
   values=[{'action':record_value(a),'value':-search.reference_minimax(ch,0,ev,c,ply=1)[0]}for a,ch in legal_successors(s.state,c)];refscore,_=search.reference_minimax(s.state,1,ev,c);out['references'].append({'seed':key[0],'prefix':key[1],'best_value':refscore,'children':values,'history_plies':len(s.to_record().actions)})
 plan=[((r['seed'],r['prefix']),n,arm)for r in out['references']for n in reg['budgets']for arm in reg['arms']];random.Random(2026102299988).shuffle(plan);out['planned_queries']=len(plan);write_record(P/'results.json',out)
 for key,n,arm in plan:
  if time.perf_counter()-start>=reg['whole_seconds']:break
  c=contexts[key[0]];s=roots[key];before=s.state,s.to_record(),s._search_witnesses;row={'seed':key[0],'prefix':key[1],'nodes':n,'arm':arm};out['rows'].append(row);write_record(P/'results.json',out);tick=time.perf_counter()
  try:
   player=PartialPlayer(c,use_disk_cache=False,evaluator_override=unit_evaluator(c),tuning=SearchTuning(use_root_tactical=False),partial=arm=='no_scan_partial');row['setup_seconds']=time.perf_counter()-tick;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=n,max_time_seconds=.5,quiescence_max_depth=0,quiescence_hard_max_depth=0));row['decision']=record_value(d);row['query_seconds']=time.perf_counter()-tick;row['observation']=player.observation;write_record(P/'results.json',out);assert before==(s.state,s.to_record(),s._search_witnesses)
   if d.action is not None:assert any(record_value(a)==record_value(d.action)for a in s.legal_actions())
  except Exception as e:row['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};out['failures'].append({'seed':key[0],'prefix':key[1],'nodes':n,'arm':arm,'failure':row['failure']})
  out['wall_seconds']=time.perf_counter()-start;write_record(P/'results.json',out)
 out.update(closed=True,wall_seconds=time.perf_counter()-start,missing_queries=len(plan)-len(out['rows']));write_record(P/'results.json',out);print('PARTIAL',len(out['rows']),len(out['failures']),round(out['wall_seconds'],3),flush=True)
if __name__=='__main__':main()
