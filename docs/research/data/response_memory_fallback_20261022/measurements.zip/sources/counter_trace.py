"""Observation only: original search/evaluator/orderer still execute every operation."""
import json,time,sys,traceback
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import record_value,write_record
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
import generic_chess.ai.alphabeta.search as search
from generic_chess.ai.alphabeta.ordering import MoveOrderer
P=Path('.local_agent/counter-20261022');assert not(P/'mechanism.json').exists();inputs=json.loads((P/'inputs.json').read_text(encoding='utf-8'));stack=[];current={};original=search.negamax
class TraceOrderer(MoveOrderer):
 def __init__(self):super().__init__();self.writers={}
 def record_countermove(self,prev,response):
  row=current;side=stack[-1];old=self.writers.get(prev);row['writes']+=1
  if old:
   row['overwrites']+=1;row['response_changes']+=old[1]!=response;row['cross_side_overwrites']+=old[0]!=side
  self.writers[prev]=(side,response);super().record_countermove(prev,response)
 def order(self,state,actions,evaluator,depth,tt_move,prev_action,tuning):
  row=current;counter=self._countermoves.get(prev_action);writer=self.writers.get(prev_action);side=state.position.side_to_move
  row['ordered_nodes']+=1
  actual=super().order(state,actions,evaluator,depth,tt_move,prev_action,tuning)
  if counter is not None:
   row['lookups_present']+=1;row['counter_legal']+=counter in actions
   if counter in actions:
    row['cross_side_legal']+=writer[0]!=side
    base=super().order(state,actions,evaluator,depth,tt_move,prev_action,replace(tuning,use_countermove=False))
    if actual!=base:
     row['changed_orders']+=1;row['cross_side_changed']+=writer[0]!=side
     if len(row['examples'])<3:row['examples'].append({'state':record_value(state),'previous_action':record_value(prev_action),'counter':record_value(counter),'writer_side':writer[0],'reader_side':side,'base_rank':base.index(counter),'counter_rank':actual.index(counter)})
  return actual

def traced(state,*a,**kw):
 stack.append(state.position.side_to_move)
 try:return original(state,*a,**kw)
 finally:stack.pop()
search.MoveOrderer=TraceOrderer;search.negamax=traced
out={'question':'Does existing full-sort countermove materially reorder legal actions, and are side-free keys observed to cross-contaminate?', 'scope':'Instrumentation adds extra sorting; never timing evidence or policy utility. Complete current action identity preserved; all search/evaluation operations still performed. No default/product key change.','rows':[]};started=time.perf_counter()
for world in inputs['worlds']:
 for root in world['roots']:
  if time.perf_counter()-started>=150:break
  c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(world['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));
  if s.state.terminal_status.is_terminal or s.state.ply_count!=root['target']:continue
  current={k:0 for k in ['writes','overwrites','response_changes','cross_side_overwrites','ordered_nodes','lookups_present','counter_legal','cross_side_legal','changed_orders','cross_side_changed']};current.update(seed=world['seed'],prefix=root['target'],examples=[]);out['rows'].append(current);write_record(P/'mechanism.json',out)
  player=AlphaBetaPlayer(c,use_disk_cache=False,tuning=SearchTuning(use_countermove=True));limits=SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0);before=s.state,s.to_record(),s._search_witnesses;tick=time.perf_counter()
  try:current['decision']=record_value(player.choose_action(s,limits))
  except Exception as e:current['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
  current['instrumented_seconds']=time.perf_counter()-tick;assert before==(s.state,s.to_record(),s._search_witnesses);assert not stack;write_record(P/'mechanism.json',out);print('TRACE',world['seed'],root['target'],current['changed_orders'],current['cross_side_changed'],flush=True)
out['wall_seconds']=time.perf_counter()-started;write_record(P/'mechanism.json',out)
