import json,time,statistics,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import record_value,write_record
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
P=Path('.local_agent/counter-20261022');status=json.loads((P/'curve-status.json').read_text(encoding='utf-8'))
if status['stage']!='closed':print('Curve active; analysis not run');raise SystemExit(2)
assert not(P/'curve-analysis.json').exists();start=time.perf_counter();inputs=json.loads((P/'inputs.json').read_text(encoding='utf-8'));contexts={};pvplies=0;rows=[];failures=[];reference_root_histories=0
for w in inputs['worlds']:
 c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(w['rule']));contexts[w['seed']]=(c,{r['target']:r for r in w['roots']})
for call in status['completed']:
 result=json.loads((P/call['file']).read_text(encoding='utf-8'));c,roots=contexts[call['seed']]
 failures.extend(result['failures'])
 for row in result['rows']:
  d=row['decision'];root=roots[row['prefix']];s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));reference_root_histories+=len(s.to_record().actions);before=s.state
  assert d['runtime_depth_balanced']
  if d['action'] is not None:assert any(record_value(a)==d['action'] for a in s.legal_actions())
  if d['choice_kind']=='DECLARATION':assert d['declaration'] is not None
  for raw in d['principal_variation']:
   a=next(a for a in s.legal_actions() if record_value(a)==raw);s.submit(a);pvplies+=1
  if d['result_source']=='root_immediate_win':assert s.state.terminal_status.is_terminal and s.state.terminal_status.winner==before.position.side_to_move
  rows.append({'seed':call['seed'],'prefix':row['prefix'],'depth':call['depth'],'variant':call['variant'],'setup':row['player_setup_seconds'],'seconds':row['query_seconds'],'decision':d})
index={(r['seed'],r['prefix'],r['depth'],r['variant']):r for r in rows};comparisons=[]
for depth in (3,4,5):
 for base,candidate in [('base','counter'),('staged','both'),('base','staged'),('base','both')]:
  pairs=[];extra=lost=0
  for key,a in index.items():
   seed,prefix,d,v=key
   if d!=depth or v!=base:continue
   b=index.get((seed,prefix,d,candidate))
   if b is None:continue
   da,db=a['decision'],b['decision'];extra+=db['completed_depth']>da['completed_depth'];lost+=db['completed_depth']<da['completed_depth']
   if da['result_source']!='main_iteration' or db['result_source']!='main_iteration' or da['completed_depth']!=depth or db['completed_depth']!=depth:continue
   assert (da['result_ordinary_qdepth'],da['result_check_hard_qdepth'])==(db['result_ordinary_qdepth'],db['result_check_hard_qdepth'])
   pairs.append({'seed':seed,'prefix':prefix,'same_score':da['score']==db['score'],'same_action':da['action']==db['action'],'cold_ratio':(b['seconds']+b['setup'])/(a['seconds']+a['setup']),'saved_seconds':a['seconds']+a['setup']-b['seconds']-b['setup'],'node_ratio':db['nodes']/max(1,da['nodes'])})
  comparisons.append({'depth':depth,'base':base,'candidate':candidate,'complete_pairs':len(pairs),'extra_returned_depths':extra,'lost_returned_depths':lost,'median_cold_ratio':statistics.median(p['cold_ratio'] for p in pairs) if pairs else None,'median_saved_seconds':statistics.median(p['saved_seconds'] for p in pairs) if pairs else None,'score_mismatches':sum(not p['same_score'] for p in pairs),'action_changes':sum(not p['same_action'] for p in pairs),'pairs':pairs})
out={'queries':len(rows),'failures':failures,'pv_plies':pvplies,'root_history_plies':reference_root_histories,'curve_seconds':status['wall_seconds'],'validation_seconds':time.perf_counter()-start,'comparisons':comparisons,'missing_processes':status['unexecuted_processes'],'rule_setups':len(inputs['worlds']),'generation_failures':inputs['failures']};write_record(P/'curve-analysis.json',out);print(json.dumps({k:v for k,v in out.items() if k!='comparisons'}));print(json.dumps([{k:v for k,v in x.items() if k!='pairs'} for x in comparisons]))
