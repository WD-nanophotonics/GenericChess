"""Descriptive saved role-pair join. No Player, solver, or game continuation."""
import json,hashlib
from pathlib import Path
from collections import Counter
from scripts.leaper_pvs_quality_pilot import make_session
from scripts.verify_leaper_pvs_quality_pilot import action
from scripts.research_record import record_value
from tools.local_agent.common import write_json
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.semantic_executor import semantic_engine_for

base=Path('.local_agent/capture-q-policy-games-20261105')
out=Path('.local_agent/latency-observer-20261105')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
inputs=load(base/'inputs.json')['rows'];frozen=load(base/'frozen.json')
assert hashlib.sha256((base/'inputs.json').read_bytes()).hexdigest()==frozen['input_sha256']
rows=[];hashes={'inputs.json':hashlib.sha256((base/'inputs.json').read_bytes()).hexdigest()}
for family in range(6):
 games=[load(base/f'game-{2*family+k:02}.json') for k in range(2)]
 for k,g in enumerate(games):
  assert g['slot']==frozen['game_slots'][2*family+k]
  assert g['slot']['family']==family and g['slot']['ONseat']==k
  name=f'game-{2*family+k:02}.json';hashes[name]=hashlib.sha256((base/name).read_bytes()).hexdigest()
 assert games[0]['initial_record']==games[1]['initial_record']
 shared=[];first=None
 for ply,(na,nb) in enumerate(zip(*(g['returns'] for g in games))):
  records=[load(base/n) for n in (na,nb)]
  for n,r in zip((na,nb),records):hashes[n]=hashlib.sha256((base/n).read_bytes()).hexdigest()
  a,b=records
  assert a['family']==b['family']==family and a['ply']==b['ply']==ply
  assert a['record_before']==b['record_before'],'do not compare beyond identical full history'
  assert a['actor']==b['actor'] and a['on']!=b['on']
  if a['decision']['action']==b['decision']['action']:
   shared.append(a['decision']['action']);continue
  c,root=make_session(inputs[family])
  root=GameSession.replay(c,deserialize_game_record(json.dumps(a['record_before'])))
  assert record_value(root.to_record())==a['record_before']
  before=Counter(p.owner for p in root.state.position.board if p is not None)
  choices=[]
  for n,r in zip((na,nb),records):
   child=GameSession.replay(c,root.to_record());typed=action(r['decision']['action'],child)
   child.submit(typed)
   after=Counter(p.owner for p in child.state.position.board if p is not None)
   counts={str(owner):before[owner]-after[owner] for owner in (0,1)}
   d=r['decision']
   choices.append(dict(return_path=n,on=r['on'],actor=r['actor'],action=record_value(typed),
    retained_depth=d['completed_depth'],result_source=d['result_source'],termination=d['termination_reason'],
    wall_seconds=r['wall_seconds'],timing_eligible=r['timing_eligible'],
    piece_count_reduction=counts,opponent_in_check=semantic_engine_for(c).in_check(child.state.position,child.state.position.side_to_move),
    immediate_Core_result=record_value(child.result),child_record_sha256=digest(record_value(child.to_record())),
    checking_move_qclassifications=d['checking_move_qactions'],nodes=d['nodes'],qnodes=d['qnodes']))
  first=dict(ply=ply,actor=a['actor'],complete_record_sha256=digest(a['record_before']),
    shared_actions=shared,choices=choices,typed_actions_distinct=action(a['decision']['action'],root)!=action(b['decision']['action'],root))
  assert first['typed_actions_distinct'];break
 rows.append(dict(family=family,game_eligibility=[g['eligible'] for g in games],literal_final_results=[g['literal_result'] for g in games],
  first_common_history_divergence=first,matching_decisions_before=len(shared),
  limits='Same complete game history, not same live TT/elapsed schedule. First divergence is descriptive, not an isolated policy effect or WDL/regret label. Later differing histories not joined.'))
old=load(base/'first-pair-descriptive.json')['first_commonhistory_choice_divergence'];new=rows[0]['first_common_history_divergence']
assert new['ply']==old['ply'] and [v['action'] for v in new['choices']]==[old['firstgame_action'],old['secondgame_action']]
write_json(out/'saved-choice-join.json',dict(status='PASS_SAVED_TYPED_COMMON_HISTORY_JOIN',families=rows,newly_examined_families=[1,2,3,4,5],old_family0_crosscheck=True,
 newPlayer=0,newSolver=0,newGames=0,Core_child_submissions=sum(2 for r in rows if r['first_common_history_divergence']),source_sha256=hashes,
 qualification='Original 12-slot gate remains FAILED; timing-ineligible games remain ineligible; no strength or default claim.'))
print(json.dumps([dict(family=r['family'],ply=r['first_common_history_divergence']['ply'] if r['first_common_history_divergence'] else None,choices=[dict(on=c['on'],depth=c['retained_depth'],capture=c['piece_count_reduction'],check=c['opponent_in_check']) for c in r['first_common_history_divergence']['choices']] if r['first_common_history_divergence'] else []) for r in rows]))
