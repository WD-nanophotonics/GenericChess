"""One frozen selective-observer qualification; serial fresh Python processes."""
from pathlib import Path
from datetime import datetime,timezone
from contextlib import nullcontext
import copy,gzip,hashlib,json,subprocess,sys,time
from scripts.research_record import record_value,write_record
from scripts.leaper_pvs_quality_pilot import make_session,CallerDeadline,provider_metrics,metric_delta
from scripts.leaper_relative_history_pilot import native_identity,memory_snapshot
from scripts.leaper_latency_observer import FrontierObserver
from generic_chess.rules.schema import ruleset_from_dict,compute_fingerprint
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from tools.local_agent import session
from tools.local_agent.slack_transport import save_plugin_original


def stamp():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))


def prepare(base):
 b=Path(base);assert not (b/'inputs.json').exists()
 source=Path('docs/research/data/leaper_capture_q_policy_20261105/inputs.json.gz');old=json.loads(gzip.decompress(source.read_bytes()))['rows'];rows=[]
 home=[('K',0,0),('A',1,1),('B',2,1),('C',1,2)]
 write_record(b/'literal-before-Core.json',dict(source_sha256=sha(source),source_families=[0,1],board=5,home=home,mirror='(4-x,4-y)',max_ply=128,prefix='twolegalCoreplies;firstcanonicalatply0,lastcanonicalatply1;retainterminal/rejectionwithoutreplacement',claim='newcontrolledpositions/history,notoldgamequeries/holdout/strength;existingmovementdefinitionsasDATA'))
 for index in (0,1):
  rule=copy.deepcopy(old[index]['RuleSet']);rule.update(board_size=5,initial_position=[[None]*5 for _ in range(5)],max_ply=128,metadata={})
  for tid in rule['drop_allowed']:rule['drop_allowed'][tid]=[[False]*25,[False]*25]
  for owner in (0,1):
   for typ,x,y in home:
    if owner:x,y=4-x,4-y
    assert rule['initial_position'][y][x] is None
    rule['initial_position'][y][x]=dict(owner=owner,base_type_id=typ,current_type_id=typ,promoted=False)
  fp=compute_fingerprint(ruleset_from_dict(rule));rows.append(dict(id=f'latency-new-{index}',RuleSet=rule,fingerprint=fp,record=dict(schema_version=1,ruleset_fingerprint=fp,actions=[],resigned_by=None)))
 write_record(b/'literal-inputs.json',dict(rows=rows))
 for row in rows:
  c,s=make_session(row);steps=[]
  for ply in range(2):
   if s.result.status.value!='ongoing':break
   actions=sorted(s.legal_actions(),key=repr);chosen=actions[0 if ply==0 else -1];s.submit(chosen);steps.append(record_value(chosen))
  row['record']=record_value(s.to_record());row['prepared_state']=record_value(s.state);row['Core_prefix']=steps;row['result']=record_value(s.result)
 write_record(b/'inputs.json',dict(rows=rows))


def player(c):return AlphaBetaPlayer(c,use_disk_cache=False,tuning=SearchTuning(use_pvs=True),use_native_semantic_legality=True,use_native_semantic_availability=True,use_native_semantic_check=True)
def cache(p):return dict(TT_entries=len(p._tt),TT_generation=p._tt.generation,public_actions=len(getattr(p.native_legality_provider._metrics_local,'public_cache',{})))


def call(c,s,seconds,depth,on,p=None):
 before=s.to_record();start=stamp();tick=time.perf_counter();cpu=time.process_time();obs=FrontierObserver(deadline=tick+seconds) if on else None
 with (obs if on else nullcontext()):
  if p is None:p=player(c)
  cache_before=cache(p);pm=provider_metrics(p);assert pm['present']
  remaining=seconds-(time.perf_counter()-tick);assert remaining>0
  limits=SearchLimits(max_depth=depth,max_nodes=2000000,max_time_seconds=remaining,quiescence_max_depth=4,quiescence_hard_max_depth=8)
  d=p.choose_action(s,limits,cancel_token=CallerDeadline(tick+seconds))
 end=stamp();wall=time.perf_counter()-tick
 r=dict(started_at=start,ended_at=end,wall_seconds=wall,CPU_seconds=time.process_time()-cpu,on=on,record_before=record_value(before),decision=record_value(d),limits=record_value(limits),tuning=record_value(p._tuning),provider_delta=metric_delta(pm,provider_metrics(p)),cache_before=cache_before,cache_after=cache(p),observation=obs.snapshot() if obs else None,memory_after=memory_snapshot())
 return r,p,before


def child(base,index):
 b=Path(base);f=load(b/'frozen.json');slot=f['slots'][index]
 for p,h in f['sources'].items():assert sha(p)==h
 assert sha(b/'inputs.json')==f['inputs_sha256']
 row=load(b/'inputs.json')['rows'][slot['root']];c,s=make_session(row);identity=native_identity();p=None;pre=None
 if slot['warm']:
  pre,p,before=call(c,s,2,3,False);pre['kind']='D3_CONTEXT_PREPARATION';write_record(b/f'prewarm-{index:02}.json',pre)
  assert pre['decision']['completed_depth']==3 and before==s.to_record() and pre['decision']['runtime_depth_balanced']
 r,p,before=call(c,s,slot['seconds'],slot['depth'],slot['on'],p);r.update(slot=index,spec=slot,native_identity=identity,process_id=__import__('os').getpid())
 write_record(b/f'return-{index:02}.json',r) # original return precedes interpretation
 assert before==s.to_record() and r['decision']['runtime_depth_balanced'] and r['decision']['native_legality_fallbacks']==r['decision']['native_legality_operational_failures']==0
 assert r['decision']['action'] in s.legal_actions()
 if slot['on']:
  obs=r['observation'];assert obs['valid'] and obs['entries']==obs['exits']
  assert obs['entries']-obs['exception_exits']==r['decision']['native_legality_calls']
 print(json.dumps(dict(slot=index,root=slot['root'],kind=slot['kind'],on=slot['on'],seconds=r['wall_seconds'],depth=r['decision']['completed_depth'],frontiers=None if not slot['on'] else r['observation']['entries'])),flush=True)


def nonclock(value):
 if isinstance(value,dict):return {k:nonclock(v) for k,v in value.items() if 'seconds' not in k and not k.startswith('time_to_')}
 if isinstance(value,list):return [nonclock(v) for v in value]
 return value


def run(base):
 b=Path(base);f=load(b/'frozen.json');assert not (b/'run-start.json').exists();write_record(b/'run-start.json',dict(at=stamp(),one_serial_runner=True))
 completed=[];attempted=[];error=None;pilot_tick=time.perf_counter();probe_tick=None;qualification=None
 for index,slot in enumerate(f['slots']):
  if index==8:
   rows=[load(b/f'return-{i:02}.json') for i in range(8)];conditions=[]
   for root in (0,1):
    group=[r for r in rows if r['spec']['root']==root];reference=nonclock(group[0]['decision']);conditions.append(all(nonclock(r['decision'])==reference and r['decision']['completed_depth']==3 for r in group))
   off=sum(r['wall_seconds'] for r in rows if not r['on']);on=sum(r['wall_seconds'] for r in rows if r['on']);cpu_valid=all(r['CPU_seconds']>0 for r in rows)
   qualification=dict(status='PASS_FINITE_SCREEN' if all(conditions) and cpu_valid and on/off<=1.05 else 'STOP_OBSERVER_GATE',returns=8,exact_work_by_root=conditions,wall_OFF=off,wall_ON=on,wall_ratio=on/off,CPU_positive=cpu_valid,limits='8freshserialprocesses/coldPlayerTT/publiccache;notguarantee5staildisturbance/identicalallocatorlayout')
   write_record(b/'qualification.json',qualification)
   if qualification['status']!='PASS_FINITE_SCREEN':break
   probe_tick=time.perf_counter()
  timeout=3.5 if slot['kind']=='validation' else 9 if slot['warm'] else 7
  tick=pilot_tick if slot['kind']=='validation' else probe_tick;cap=10 if slot['kind']=='validation' else 30
  if session.stopped():error='USER_STOP';break
  if datetime.now(timezone.utc)>=datetime.fromisoformat(f['deadline_utc']):error='WHOLE_CAP';break
  if time.perf_counter()-tick+timeout+.2>=cap:error=slot['kind']+'_DISPATCH_CAP';break
  if memory_snapshot().get('rss_bytes',0)>1610612736:error='RSS_CAP';break
  attempted.append(index);invoked=time.perf_counter()
  try:
   proc=subprocess.run([sys.executable,'-X','utf8','-m','scripts.leaper_latency_probe','case',str(b),str(index)],capture_output=True,timeout=timeout)
   save_plugin_original(b/f'case-{index:02}.stdout',proc.stdout+b'\nSTDERR\n'+proc.stderr)
   write_record(b/f'invocation-{index:02}.json',dict(slot=index,returncode=proc.returncode,total_process_wall_seconds=time.perf_counter()-invoked,scope='startup+constructor/choose+record/teardown;notobservergateclock'))
  except subprocess.TimeoutExpired as exc:
   save_plugin_original(b/f'case-{index:02}-timeout.stdout',(exc.output or b'')+b'\nSTDERR\n'+(exc.stderr or b''));error='OWNED_CHILD_TIMEOUT';proc=None
  for name in [f'prewarm-{index:02}.json',f'return-{index:02}.json']:
   p=b/name
   if p.exists():
    r=load(p)
    if r['started_at']<r['ended_at']:session.record_work(r['started_at'],r['ended_at'],'validation' if slot['kind']=='validation' or name.startswith('prewarm') else 'research',str(p))
  if proc is None or proc.returncode:
   error=error or 'CHILD_CONTRACT_FAILURE';break
  completed.append(index);print(proc.stdout.decode('utf-8'),end='',flush=True)
 result=dict(status='OBSERVER_PROBES_COMPLETE' if len(completed)==12 else 'STOP_FINITE_GATE',completed=completed,attempted=attempted,failed_attempts=[i for i in attempted if i not in completed],NOT_RUN=[i for i in range(12) if i not in attempted],qualification=qualification,error=error,default='UNCHANGED',new_games=0,new_solver=0,limits='atmost8measuredfixedwork+2explicitD3contextpreparations+4timedprobes;noadditionalcalls/refill;freshprocessesareboundedserialscientificruns,notAgents/workers')
 write_record(b/'summary.json',result);print(json.dumps(result));return result
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare(sys.argv[2])
 elif sys.argv[1]=='case':child(sys.argv[2],int(sys.argv[3]))
 else:run(sys.argv[2])
