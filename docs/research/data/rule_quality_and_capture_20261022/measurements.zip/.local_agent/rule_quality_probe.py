import json,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.benchmark.tactical_probe import probe_terminal_only
P=Path('.local_agent/rule-quality-20261022');O=Path('.local_agent/rule-quality-probe-20261022');O.mkdir(exist_ok=True)
reg={'question':'Do structural choices on the actual saved D2-vsD1 paths support bounded terminal distinctions,or mostly unresolved mass?','selection':'All8planned worlds,owner0 D2/D1 arm;prefix0,4,8,16,32,64 when exists including terminal. No selected outcome,oracle,label or re-generation. Prefix histories remain complete.','depth':4,'nodes':256,'whole_cap_seconds':600,'estimate_seconds':120,'scope':'Existing shared terminal-only probe,not AUX solver or complete-game WDL. Absent prefixes/failed slots explicit,terminal roots not learnable ordinary choices. No learning or quality admission gate.','decision':'Resolved tactical choices qualify a narrow shallow-win interpretation;mostlyUNKNOWN means do not claim absence of strategic choice or escalate fullWDL survey.'}
assert not(O/'results.json').exists();write_record(O/'registration.json',reg);worlds=json.loads((P/'inputs.json').read_text(encoding='utf-8'))['worlds'];out={'registration':reg,'slots':[],'inputs':[],'failed':[]};tick=time.perf_counter()
for w in worlds:
 g=json.loads((P/f'game-{4*w["index"]+1:03d}.json').read_text(encoding='utf-8'));rec=deserialize_game_record(json.dumps(g['final_record']));c=compile_rule(ruleset_from_dict(w['rule']));s=GameSession(c)
 for k in range(len(rec.actions)+1):
  if k in(0,4,8,16,32,64):out['inputs'].append({'world':w['index'],'prefix':k,'record':record_value(s.to_record()),'state':record_value(s.state),'terminal':record_value(s.result),'legal_count':len(s.legal_actions())})
  if k<len(rec.actions):s.submit(rec.actions[k])
 for k in(0,4,8,16,32,64):out['slots'].append({'world':w['index'],'prefix':k,'status':'ready'if k<=len(rec.actions)else'absent_after_game','result':None})
write_record(O/'inputs.json',{'registration':reg,'inputs':out['inputs']});contexts={};write_record(O/'results.json',out)
for slot in out['slots']:
 if slot['status']!='ready':continue
 if time.perf_counter()-tick>=reg['whole_cap_seconds']:break
 inp=next(i for i in out['inputs']if i['world']==slot['world']and i['prefix']==slot['prefix']);w=worlds[slot['world']];c=contexts.get(slot['world'])
 if c is None:c=contexts[slot['world']]=compile_rule(ruleset_from_dict(w['rule']))
 s=GameSession.replay(c,deserialize_game_record(json.dumps(inp['record'])));t=time.perf_counter()
 try:r=probe_terminal_only(s,depth=4,node_budget=256);slot.update(status='finished',result=record_value(r),seconds=time.perf_counter()-t)
 except Exception as e:slot.update(status='error',failure={'message':str(e),'traceback':traceback.format_exc()});out['failed'].append(slot.copy())
 out['seconds']=time.perf_counter()-tick;write_record(O/'results.json',out);print('PROBE',slot['world'],slot['prefix'],slot['status'],slot['result'],round(out['seconds'],2),flush=True)
out['seconds']=time.perf_counter()-tick;write_record(O/'results.json',out);print('CLOSED',out['seconds'],flush=True)
