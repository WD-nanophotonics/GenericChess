"""Posthoc source-assisted no-mate closed-subclass check; no graph/solver/training."""
import json,sys,time,hashlib
from pathlib import Path
from dataclasses import fields
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.generation.piece_generator import KING_ATOMS
P=Path('.local_agent/rule-quality-capture-random-20261022');I=Path('.local_agent/rule-quality-capture-20261022/inputs.json');data=json.loads((P/'results.json').read_text(encoding='utf-8'));worlds={w['index']:w for w in json.loads(I.read_text(encoding='utf-8'))['worlds']};out={'scope':'Posthoc analytic subclass,not neworacle-selectedtraining/exhaustivegraph or relabelled rawdraws. Everyoriginal96plycensored record retained. No AUX solver execution.','preconditions':'Exactlytwo unpromotedbase/currentKanchors with8adjacentLeaps,no hands oraux;no othersemanticcreation/declarations/adjudication/pass,drawstalemate/repetition,finite512clock. Geometry is owner-symmetric.','argument':['Anchors are not capturable and neither king may move into opponent attack.','For the identical eight-adjacent symmetric geometry,a king checking its opponent would itself be adjacent and attacked,so that transition is illegal.','Emptyhands/no ordinary actors/no semanticcreation/no kingpromotion preserve the two-king emptyhand class under everylegal continuation.','Therefore CHECKMATE cannot occur. All other permitted terminal causes are draws;finite max_ply ensures termination. This is a conditional source-based inductive argument,not a new full-game WDL table.'],'states':[],'source_files':{},'failures':[]};tick=time.perf_counter()
for name in('generic_chess/core/semantic_executor.py','generic_chess/core/movegen.py','generic_chess/core/terminal.py','generic_chess/generation/piece_generator.py'):
 out['source_files'][name]=hashlib.sha256(Path(name).read_bytes()).hexdigest()
contexts={}
for g in data['games']:
 p=g['final_state']['position'];pieces=[x for x in p['board']if x];hands=sum(v for h in p['hands']for _,v in h['counts'])
 if len(pieces)!=2 or any(x['base_type_id']!='K'or x['current_type_id']!='K'or x['promoted']for x in pieces)or hands or p['aux_state']:continue
 w=worlds[g['world']];rule=ruleset_from_dict(w['rule']);checks={'remove_capture':rule.capture_disposition=='remove_from_game','draw_repetition':rule.repetition_policy=='draw','draw_stalemate':rule.stalemate_result=='draw','clock512':rule.max_ply==512,'no_custom_actions':not rule.semantic_actions,'no_declarations':not rule.declarations,'no_automatic':not rule.automatic_adjudications,'no_consecutive':not rule.consecutive_action_adjudications,'no_target_conditions':not rule.repeated_cycle_target_conditions,'no_progress_override':rule.no_progress_draw is None,'no_pass':not rule.pass_enabled};k=next(t for t in rule.piece_types if t.type_id=='K');checks['king_geometry']=k.movement_atoms==KING_ATOMS and k.is_anchor and not k.is_promotable and not k.promotion_target_ids;assert all(checks.values()),checks
 c=contexts.get(g['world'])
 if c is None:c=contexts[g['world']]=compile_rule(rule)
 sess=GameSession.replay(c,deserialize_game_record(json.dumps(g['final_record'])));assert record_value(sess.state)==g['final_state'];engine=semantic_engine_for(c);assert not any(engine.in_check(sess.state.position,o)for o in(0,1));children=[]
 for a,ch in legal_successors(sess.state,c):
  pcs=[x for x in ch.position.board if x];assert len(pcs)==2 and {x.owner for x in pcs}=={0,1};assert all(x.base_type_id=='K'and x.current_type_id=='K'and not x.promoted for x in pcs);assert not any(h.total()for h in ch.position.hands);assert not any(engine.in_check(ch.position,o)for o in(0,1));assert ch.terminal_status.winner is None;children.append({'action':record_value(a),'child_state_sha256':hashlib.sha256(json.dumps(record_value(ch),sort_keys=True).encode()).hexdigest(),'terminal':record_value(ch.terminal_status)})
 out['states'].append({'slot':g['slot'],'world':g['world'],'reused_from':g['reused_from'],'raw_terminal':g['terminal'],'raw_first_score_interval':g['first_score_interval'],'rule_checks':checks,'full_record':g['final_record'],'full_state_sha256':hashlib.sha256(json.dumps(g['final_state'],sort_keys=True).encode()).hexdigest(),'legal_children':children,'separate_analytic_label':'DRAW under stated legal-Core continuation/preconditions;rawobservedONGOINGnotrewritten'})
out['checked_states']=len(out['states']);out['actual_unique_states']=sum(x['reused_from']is None for x in out['states']);out['one_step_edges']=sum(len(x['legal_children'])for x in out['states']);out['seconds']=time.perf_counter()-tick;write_record(P/'king-only-closure.json',out);print('KINGCLOSED',out['checked_states'],out['actual_unique_states'],out['one_step_edges'],round(out['seconds'],3),flush=True)
