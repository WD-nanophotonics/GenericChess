import json,sys,time,hashlib,traceback
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict,RuleDeclaration,RuleDeclarationOutcomeBand,RuleWeightedMaterialMetric,RuleAutomaticAdjudication
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
W=Path('.local_agent/rule-quality-hand-witness-20261022');out={'witness':None,'boundary_controls':[],'failures':[]};tick=time.perf_counter();study=json.loads((W/'results.json').read_text(encoding='utf-8'));proof=study['proof'];worlds={w['index']:w for w in json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text(encoding='utf-8'))['worlds']};rule=ruleset_from_dict(worlds[proof['world']]['rule']);c=compile_rule(rule);s=GameSession.replay(c,deserialize_game_record(json.dumps(proof['root_record'])));a,ch=next((a,ch)for a,ch in legal_successors(s.state,c)if record_value(a)==proof['drop']);replies=list(legal_successors(ch,c));cert=proof['reply_certificates'];assert len(replies)==len(cert);seen=[]
for reply,after in replies:
 row=next(x for x in cert if x['opponent_reply']==record_value(reply));winning,leaf=next((a,t)for a,t in legal_successors(after,c)if record_value(a)==row['winning_response']['action']);assert leaf.terminal_status.is_terminal and leaf.terminal_status.winner==proof['actor'];assert record_value(leaf)==row['winning_response']['final_state'];seen.append({'reply':record_value(reply),'response':record_value(winning),'terminal':record_value(leaf.terminal_status)})
assert len(seen)==len(cert);out['witness']={'pass':True,'root_record':proof['root_record'],'drop':proof['drop'],'all_reply_count':len(replies),'all_replies':seen,'world':proof['world'],'actor':proof['actor'],'scope':'IndependentfullCorelegal-frontier reconstruction,not independentrulesimplementation. Only thisroot WIN,not all53candidatechildren solved.'}
closed=json.loads(Path('.local_agent/rule-quality-capture-random-20261022/king-only-closure.json').read_text(encoding='utf-8'));case=next(x for x in closed['states']if x['raw_terminal']['status']=='ongoing');parents={w['index']:w for w in json.loads(Path('.local_agent/rule-quality-capture-20261022/inputs.json').read_text(encoding='utf-8'))['worlds']};base=ruleset_from_dict(parents[case['world']]['rule']);rec=deserialize_game_record(json.dumps(case['full_record']));actor=GameSession.replay(compile_rule(base),rec).state.position.side_to_move
variants=[('declaration_WIN',replace(base,declarations=(RuleDeclaration('quality_boundary_win',owner=actor,weighted_metric=RuleWeightedMaterialMetric(weights={'K':0}),outcome_bands=(RuleDeclarationOutcomeBand(0,'WIN'),)),))),('automatic_NO_CONTEST',replace(base,automatic_adjudications=(RuleAutomaticAdjudication('quality_boundary_no_contest',trigger_ply=len(rec.actions)),)))]
write_record(W/'boundary-inputs.json',{'source_case':case,'scope':'NEW rule-goal boundarycontrols with exactlegal actionsequence,not rewriting oldcensored outcomes. Full definedpromotion/drop/history retained.','variants':[{'name':n,'rule':ruleset_to_dict(r)}for n,r in variants]})
for name,new in variants:
 row={'name':name,'source_world':case['world'],'source_slot':case['slot'],'original_raw_terminal':case['raw_terminal']}
 try:
  cc=compile_rule(new);rr=replace(rec,ruleset_fingerprint=cc.ruleset_fingerprint);ss=GameSession.replay(cc,rr);row.update(record=record_value(ss.to_record()),state_before_claim=record_value(ss.state),result_before_claim=record_value(ss.result),theorem_precondition_rejected=bool(new.declarations or new.automatic_adjudications))
  if name=='declaration_WIN':
   choices=ss.available_declarations();row['available']=record_value(choices);ss.declare('quality_boundary_win');assert ss.result.winner==actor;row['result_after_claim']=record_value(ss.result)
  else:assert ss.result.status.value=='no_contest'and ss.result.winner is None
  out['boundary_controls'].append(row)
 except Exception as e:out['failures'].append({'name':name,'message':str(e),'traceback':traceback.format_exc(),'partial':row})
out['seconds']=time.perf_counter()-tick;write_record(W/'independent-qualification.json',out);print('PROOFQUALIFIED',out['witness']['all_reply_count'],len(out['boundary_controls']),len(out['failures']),round(out['seconds'],3));print(json.dumps(out['witness'],ensure_ascii=False)[:1500]);print([(x['name'],x['result_before_claim'])for x in out['boundary_controls']])
