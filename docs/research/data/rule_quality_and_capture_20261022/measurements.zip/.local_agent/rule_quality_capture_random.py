import json,time,sys,random,traceback,hashlib
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.benchmark.game_quality import _play_policy_game_with_trace,QualityObservation,profile_from_observations
P=Path('.local_agent/rule-quality-capture-random-20261022');P.mkdir(exist_ok=True);src=Path('.local_agent/rule-quality-capture-20261022/inputs.json');inp=json.loads(src.read_text(encoding='utf-8'));worlds={w['index']:w for w in inp['worlds']};reg={'question':'Does NEW remove-from-game capture reduce uniform-policy censoring or change actual draw/choice structure relative to the FIXED pocket counterparts?','input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'planned_rule_slots':24,'pairs_per_rule':4,'games_per_pair':2,'caller_cap':96,'whole_cap_seconds':600,'estimate_seconds':120,'seeds':'configseed*1009+pair*2;swapstreams between seats for second game;bothfilterflags of sameconfig use identical localstreamseeds. No outcome/oracle selection. Only capture disposition changes; same seeds are common random numbers,not guaranteed same paths after legal frontiers diverge. Old outcomes/cutoffs unchanged.','scope':'192intended slots;16unavailable from2original generationrefusals;atmost176actualrandomgames. Rule fullsemantics/history unchanged,actualterminals and censoring distinguished. No fake rule draws or independentstateCI. Firstscoreconditional/finitebounds distinct;no direct random-vssearch strength or learning utility claim.'};assert not(P/'results.json').exists();write_record(P/'registration.json',reg);out={'registration':reg,'games':[],'failures':[],'unavailable_slots':[]};tick=time.perf_counter();cache={}
for i in range(24):
 if i not in worlds:
  out['unavailable_slots'].extend({'world':i,'pair':pair,'swap':swap,'reason':'original_generation_refusal'}for pair in range(4)for swap in range(2));continue
 w=worlds[i];c=compile_rule(ruleset_from_dict(w['rule']))
 for pair in range(4):
  seed=w['config']['seed']*1009+pair*2
  for swap in range(2):
   if time.perf_counter()-tick>=reg['whole_cap_seconds']:break
   key=(c.ruleset_fingerprint,seed,swap);start=time.perf_counter()
   if key in cache:
    old=cache[key];out['games'].append({**old,'world':i,'reused_from':old['slot'],'slot':len(out['games'])});write_record(P/'results.json',out);continue
   try:
    s,b=_play_policy_game_with_trace(c,{0:random.Random(seed+swap),1:random.Random(seed+1-swap)},96);terminal=s.result;valid=terminal.status.value not in('ongoing','no_contest');v=(.5 if terminal.winner is None else float(terminal.winner==0))if valid else None;o=QualityObservation(b,len(s.history),terminal.status.value if terminal.status.value!='ongoing'else'CENSORED',v,None if v is None else 1-v,terminal_winner=terminal.winner);g={'slot':len(out['games']),'world':i,'pair':pair,'swap':swap,'fingerprint':c.ruleset_fingerprint,'final_record':record_value(s.to_record()),'final_state':record_value(s.state),'terminal':record_value(terminal),'branching':b,'first_score_interval':[v,v]if v is not None else[0,1],'quality':profile_from_observations([o]).to_dict(),'seconds':time.perf_counter()-start,'reused_from':None};out['games'].append(g);cache[key]=g;write_record(P/'results.json',out)
   except Exception as e:out['failures'].append({'world':i,'pair':pair,'swap':swap,'message':str(e),'traceback':traceback.format_exc()});write_record(P/'results.json',out)
 print('RANDOM',i,len(out['games']),round(time.perf_counter()-tick,2),flush=True)
out['seconds']=time.perf_counter()-tick;out['executed_unique_games']=sum(g['reused_from']is None for g in out['games']);out['unattempted_slots']=192-len(out['games'])-len(out['unavailable_slots']);write_record(P/'results.json',out);print('CLOSED',len(out['games']),out['executed_unique_games'],len(out['unavailable_slots']),out['unattempted_slots'],out['seconds'],flush=True)
