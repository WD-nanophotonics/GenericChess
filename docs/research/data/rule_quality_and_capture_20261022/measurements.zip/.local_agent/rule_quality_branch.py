"""Small frozen production-generator quality preflight; shared full Core only."""
import json,sys,time,traceback,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from collections import Counter
from dataclasses import replace
from scripts.research_record import write_record,record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.benchmark.runner import _timing_invalid,_adjudicate
P=Path('.local_agent/rule-quality-branch-20261022');reg=json.loads((P/'registration.json').read_text(encoding='utf-8'))
if sys.argv[1]=='prepare':
 assert not (P/'inputs.json').exists()
 out={'registration':reg,'worlds':[],'failures':[]};tick=time.perf_counter()
 for i,cfg in enumerate(reg['prospective_configs']):
  t=time.perf_counter()
  try:
   g=generate_game(GeneratorConfig(**cfg));c=compile_rule(g.ruleset);s=GameSession(c)
   out['worlds'].append({'index':i,'config':cfg,'rule':ruleset_to_dict(g.ruleset),'generation_report':record_value(g.generation_report),'initial_record':record_value(s.to_record()),'initial_state':record_value(s.state),'opening_legal':len(s.legal_actions()),'seconds':time.perf_counter()-t})
  except Exception as e:out['failures'].append({'index':i,'config':cfg,'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'seconds':time.perf_counter()-t})
  write_record(P/'inputs.json',out)
 out['seconds']=time.perf_counter()-tick;write_record(P/'inputs.json',out);print('PREPARED',len(out['worlds']),len(out['failures']),out['seconds'],flush=True);sys.exit()
assert sys.argv[1]=='run' and not (P/'results.json').exists()
inputs=json.loads((P/'inputs.json').read_text(encoding='utf-8'));worlds={w['index']:w for w in inputs['worlds']};tick=time.perf_counter();out={'registration':reg,'slots':[{'slot':2*i+a,'world':i,'arm':a,'depths':((1,1),(2,2))[a],'status':'not_started','d2_utility_interval':[-1,1]} for i in range(2) for a in range(2)],'queries':0,'failures':[]};order=list(range(4));random.Random(reg['shuffle_seed']).shuffle(order);out['execution_order']=order;write_record(P/'results.json',out)
for k in order:
 if time.perf_counter()-tick>=reg['whole_seconds']:break
 slot=out['slots'][k];i=slot['world'];t=time.perf_counter()
 if i not in worlds:slot['status']='generation_failed';write_record(P/'results.json',out);continue
 row={**slot,'queries':[],'failure':None};path=P/f'game-{k:03d}.json';write_record(path,row);s=None
 try:
  c=compile_rule(ruleset_from_dict(worlds[i]['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(worlds[i]["opening_record"])));players=[AlphaBetaPlayer(c,use_disk_cache=False)for _ in range(2)]
  while not s.state.terminal_status.is_terminal and s.state.ply_count<reg['caller_plies']:
   if time.perf_counter()-tick>=reg['whole_seconds']:row['censor']='batch_cap';break
   actor=s.state.position.side_to_move;limits=SearchLimits(max_depth=slot['depths'][actor],max_nodes=reg['nodes'],max_time_seconds=reg['seconds'],quiescence_max_depth=reg["qdepth"],quiescence_hard_max_depth=reg["hard_qdepth"])
   row['current_record']=record_value(s.to_record());write_record(path,row);start=time.perf_counter();d=players[actor].choose_action(s,limits);elapsed=time.perf_counter()-start
   row['queries'].append({'root_ply':s.state.ply_count,'actor':actor,'limits':record_value(limits),'decision':record_value(d),'seconds':elapsed,'legal_count':len(s.legal_actions())});out['queries']+=1;write_record(path,row)
   if d.choice_kind=='DECLARATION':s.declare(d.declaration.declaration_id);break
   if d.action is None:raise ValueError('nonterminal player returned no action')
   s.submit(d.action)
 except Exception as e:row['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};out['failures'].append({'slot':k,**row['failure']})
 row['wall_seconds']=time.perf_counter()-t
 if s is not None:
  row.update(final_record=record_value(s.to_record()),final_state=record_value(s.state),terminal=record_value(s.result));d2side=0 if slot['arm']!=2 else 1;row['raw_result']=_adjudicate(s,d2side)
 fallback=any(q['decision']['result_source'] in {'fallback','legal_fallback','root_scan_fallback'}or q['decision']['termination_reason']=='fallback'for q in row['queries']);invalid=any(_timing_invalid(q['seconds'],reg['seconds'])for q in row['queries']);operational=any(q['decision']['native_legality_operational_failures']for q in row['queries']);row.update(fallback=fallback,timing_invalid=invalid,operational_failure=operational)
 row['eligible']=not(row['failure']or fallback or invalid or operational);v={'candidate_win':1,'candidate_loss':-1,'rule_draw':0}.get(row.get('raw_result'));row['d2_utility_interval']=[v,v]if row['eligible']and v is not None else[-1,1];row['status']='finished';row.pop('current_record',None);write_record(path,row)
 slot.update(status='finished',receipt=path.name,eligible=row['eligible'],d2_utility_interval=row['d2_utility_interval'],raw_result=row.get('raw_result'),plies=len(s.history)if s else None,queries=len(row['queries']),wall_seconds=row['wall_seconds']);out['wall_seconds']=time.perf_counter()-tick;write_record(P/'results.json',out);print('GAME',k,i,slot['arm'],row.get('raw_result'),row['d2_utility_interval'],slot['plies'],round(out['wall_seconds'],2),flush=True)
out['wall_seconds']=time.perf_counter()-tick;out['unexecuted_games']=sum(s['status']!='finished'for s in out['slots']);write_record(P/'results.json',out);print('CLOSED',out['queries'],out['unexecuted_games'],out['wall_seconds'],flush=True)
