import json,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
P=Path('.local_agent/rule-quality-hand-witness-20261022');r=json.loads((P/'results.json').read_text(encoding='utf-8'));proof=r['proof'];parent={w['index']:w for w in json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text(encoding='utf-8'))['worlds']};rem={w['index']:w for w in json.loads(Path('.local_agent/rule-quality-capture-20261022/inputs.json').read_text(encoding='utf-8'))['worlds']};raw=json.loads(Path('.local_agent/rule-quality-capture-random-20261022/results.json').read_text(encoding='utf-8'))['games'][proof['source_slot']];reg={'question':'Does onepredeclaredsamebudgetq0D3control find the certifiedwinwhereexistingq4D3retainedD1,or is nominalextra-depth advice still unsupported?','cases':'Newly provedpocketWIN and restrictedsourcekingonlyDRAW,not learnerlabels or oldfitness reruns.','depths':[3],'nodes':8192,'seconds':1,'qdepth':0,'hard_qdepth':0,'selected_action_certificate_budget':512,'estimate_seconds':15,'scope':'ONEnewcoldplayercall;existingq4resultretainednotrerun;sameprocess;setupandqueryclockseparate. Failure to certify a differentaction is not WDLerror;otherwinningactions unexplored. No algorithm/default/price/AUX change.'};out={'registration':reg,'inputs':[{'name':'pocket_WIN','world':proof['world'],'rule':parent[proof['world']]['rule'],'record':proof['root_record']},{'name':'remove_DRAW','world':proof['world'],'rule':rem[proof['world']]['rule'],'record':raw['final_record']}],'results':[],'failures':[]};assert not(P/'recognition-q0-control.json').exists();write_record(P/'recognition-q0-inputs.json',out|{'results':[]});tick=time.perf_counter()
for inp in out['inputs'][:1]:
 for depth in reg['depths']:
  start=time.perf_counter();row={'case':inp['name'],'depth':depth}
  try:
   c=compile_rule(ruleset_from_dict(inp['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(inp['record'])));player=AlphaBetaPlayer(c,use_disk_cache=False);row['setup_seconds']=time.perf_counter()-start;limits=SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0);t=time.perf_counter();d=player.choose_action(s,limits);row.update(decision=record_value(d),query_seconds=time.perf_counter()-t,caller_seconds=time.perf_counter()-start);out['results'].append(row);write_record(P/'recognition-q0-control.json',out)
   legal=list(legal_successors(s.state,c));a,ch=next((a,ch)for a,ch in legal if record_value(a)==record_value(d.action));pv=s.state
   for aa in d.principal_variation:pv=next(child for act,child in legal_successors(pv,c)if act==aa)
   row['literal_pv_legal']=True
   if inp['name']=='remove_DRAW':row['restricted_draw_reference']='Source-assistedclosedclassproof;chosenlegalmove preservesclass';assert ch.terminal_status.winner is None
   else:
    cert=[];edges=0;status='all_reply_mate1_certified'
    for reply,after in legal_successors(ch,c):
     found=None
     for move,leaf in legal_successors(after,c):
      edges+=1
      if leaf.terminal_status.is_terminal and leaf.terminal_status.winner==s.state.position.side_to_move:found={'response':record_value(move),'terminal':record_value(leaf.terminal_status)};break
      if edges>=reg['selected_action_certificate_budget']:status='certificate_budget_unknown';break
     if found is None:
      if status!='certificate_budget_unknown':status='not_certified_mate3_not_WDL_loss'
      break
     cert.append({'reply':record_value(reply),**found})
    row.update(selected_action_certificate_status=status,selected_certificate_edges=edges,selected_all_reply_witnesses=cert)
  except Exception as e:out['failures'].append({'case':inp['name'],'depth':depth,'message':str(e),'traceback':traceback.format_exc()})
  write_record(P/'recognition-q0-control.json',out);print('RECOGNITION',inp['name'],depth,row.get('decision',{}).get('score'),row.get('decision',{}).get('completed_depth'),row.get('selected_action_certificate_status'),round(time.perf_counter()-tick,3),flush=True)
out['seconds']=time.perf_counter()-tick;write_record(P/'recognition-q0-control.json',out)
