"""Missing low rung: uniform legal vs existing D1q4, complete saved rules."""
import json,sys,time,traceback,random,hashlib
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.benchmark.runner import _timing_invalid,_adjudicate
P=Path('.local_agent/rule-quality-low-rung-20261022');P.mkdir(exist_ok=True);src=Path('.local_agent/rule-quality-survey-20261022/inputs.json');inputs=json.loads(src.read_text(encoding='utf-8'));worlds={w['index']:w for w in inputs['worlds']};reg={'question':'Does uniformlegal->D1q4 add an actual lower skill step on SAME prospective24intendedslots,or does the search-only D2/D1 comparison misdescribe competitiveness?','input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'planned_games':48,'nodes':8192,'seconds':1,'depth':1,'qdepth':4,'hard_qdepth':8,'caller_cap':96,'whole_cap_seconds':1800,'estimate_seconds':600,'seed':'uniform stream configseed*1009+959,identical seed on both role assignments;no labels/oracle/outcome selection.','scope':'44possibleNEWgames+4unavailable from original2refusals. Same seed/conditiongrid;all flags and fields retained. Random action receives real timing/legality,not fabricated PlayerDecision or nodecount. Existing RNG/RNG observations are descriptive,not independent controls. No Elo,learner,default or AUXchange.'};assert not(P/'results.json').exists();write_record(P/'registration.json',reg);out={'registration':reg,'slots':[{'slot':2*i+owner,'world':i,'owner':owner,'status':'not_started','utility_interval':[-1,1]}for i in range(24)for owner in(0,1)],'search_queries':0,'random_turns':0,'failures':[]};order=list(range(48));random.Random(202610221499).shuffle(order);out['execution_order']=order;write_record(P/'results.json',out);tick=time.perf_counter()
for k in order:
 if time.perf_counter()-tick>=reg['whole_cap_seconds']:break
 slot=out['slots'][k];i=slot['world'];owner=slot['owner']
 if i not in worlds:slot['status']='generation_failed';write_record(P/'results.json',out);continue
 row={**slot,'queries':[],'random_turns':[],'failure':None};path=P/f'game-{k:03d}.json';write_record(path,row);start=time.perf_counter();s=None
 try:
  c=compile_rule(ruleset_from_dict(worlds[i]['rule']));s=GameSession(c);player=AlphaBetaPlayer(c,use_disk_cache=False);rng=random.Random(worlds[i]['config']['seed']*1009+959)
  while not s.state.terminal_status.is_terminal and s.state.ply_count<reg['caller_cap']:
   if time.perf_counter()-tick>=reg['whole_cap_seconds']:row['censor']='batch_cap';break
   actor=s.state.position.side_to_move;row['current_record']=record_value(s.to_record());write_record(path,row);t=time.perf_counter()
   if actor==owner:
    limits=SearchLimits(max_depth=1,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=4,quiescence_hard_max_depth=8);d=player.choose_action(s,limits);elapsed=time.perf_counter()-t;row['queries'].append({'root_ply':s.state.ply_count,'actor':actor,'limits':record_value(limits),'decision':record_value(d),'seconds':elapsed,'legal_count':len(s.legal_actions())});out['search_queries']+=1;write_record(path,row)
    if d.choice_kind=='DECLARATION':s.declare(d.declaration.declaration_id);break
    if d.action is None:raise ValueError('ongoing D1returned no action')
    s.submit(d.action)
   else:
    actions=s.legal_actions();a=actions[rng.randrange(len(actions))];elapsed=time.perf_counter()-t;row['random_turns'].append({'root_ply':s.state.ply_count,'actor':actor,'legal_count':len(actions),'action':record_value(a),'seconds':elapsed});out['random_turns']+=1;write_record(path,row);s.submit(a)
 except Exception as e:row['failure']={'message':str(e),'traceback':traceback.format_exc()};out['failures'].append({'slot':k,**row['failure']})
 if s is not None:row.update(final_record=record_value(s.to_record()),final_state=record_value(s.state),terminal=record_value(s.result),raw_result=_adjudicate(s,owner))
 fallback=any(q['decision']['result_source']in{'fallback','legal_fallback','root_scan_fallback'}or q['decision']['termination_reason']=='fallback'for q in row['queries']);timing=any(_timing_invalid(q['seconds'],1)for q in row['queries']+row['random_turns']);ops=any(q['decision']['native_legality_operational_failures']for q in row['queries']);eligible=not(row['failure']or fallback or timing or ops);v={'candidate_win':1,'candidate_loss':-1,'rule_draw':0}.get(row.get('raw_result'));u=[v,v]if eligible and v is not None else[-1,1];row.update(status='finished',eligible=eligible,utility_interval=u,fallback=fallback,timing_invalid=timing,operational_failure=ops,wall_seconds=time.perf_counter()-start);row.pop('current_record',None);write_record(path,row);slot.update(status='finished',receipt=path.name,eligible=eligible,utility_interval=u,raw_result=row.get('raw_result'),queries=len(row['queries']),random_turns=len(row['random_turns']),plies=len(s.history)if s else None,wall_seconds=row['wall_seconds']);out['wall_seconds']=time.perf_counter()-tick;write_record(P/'results.json',out);print('LOW',k,i,owner,row.get('raw_result'),u,slot['plies'],round(out['wall_seconds'],2),flush=True)
out['wall_seconds']=time.perf_counter()-tick;write_record(P/'results.json',out);print('CLOSED',out['search_queries'],out['random_turns'],out['wall_seconds'],flush=True)
