"""Bounded existential all-defense mate3 witness; existing Core/probe, no new solver."""
import json,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.benchmark.tactical_probe import probe_terminal_only
P=Path('.local_agent/rule-quality-hand-witness-20261022');P.mkdir(exist_ok=True);src=Path('.local_agent/rule-quality-capture-random-20261022');counter=json.loads((src/'same-board-pocket-counterfactual.json').read_text(encoding='utf-8'));worlds={w['index']:w for w in json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text(encoding='utf-8'))['worlds']};reg={'question':'Can LEGALLY reconstructed reserve stock turn one of the SAME board-only king positions from source-proved draw into an all-defense win,or does it merely inflate legal choices?','selection':'All9unique pocketcounterfactuals in retainedslotorder;checkingstockdrop children inCorelegalorder. Posthoc structural existential witness search,not holdout/successrate/training.','probe':'Existing terminal_only depth2,node256 per checkingdrop child;OPPchild loss0 requires allrootreplies known. Independently construct fullCore reply->mate1certificate before accepting.','whole_cap_seconds':600,'estimate_seconds':180,'stop':'First independently verified mate3 certificate or fixedcap;not allcandidate WDLscan. Missingunattemptedslots remainunknown;do not rerun frozen games.','scope':'Handfulsource-derived counterfactualstates preserve fullhistory/declaredtypes/promo/drop. No AUXsolver,learner,default or statefilterAPI.'};assert not(P/'results.json').exists();write_record(P/'registration.json',reg);out={'registration':reg,'inputs':[],'slots':[],'proof':None,'failures':[]};tick=time.perf_counter();contexts={}
for case in counter['cases']:
 if case['counterfactual_reuse_from']is not None:continue
 c=compile_rule(ruleset_from_dict(worlds[case['world']]['rule']));contexts[case['world']]=c;sess=GameSession.replay(c,deserialize_game_record(json.dumps(case['counterfactual_record'])));eng=semantic_engine_for(c);actor=sess.state.position.side_to_move;board0=sum(x is not None for x in sess.state.position.board);hands0=sum(h.total()for h in sess.state.position.hands)
 for a,ch in legal_successors(sess.state,c):
  if sum(x is not None for x in ch.position.board)!=board0+1 or sum(h.total()for h in ch.position.hands)!=hands0-1 or not eng.in_check(ch.position,1-actor):continue
  after=GameSession.replay(c,sess.to_record());after.submit(a);idx=len(out['slots']);out['inputs'].append({'index':idx,'source_slot':case['slot'],'world':case['world'],'actor':actor,'root_record':case['counterfactual_record'],'drop':record_value(a),'after_drop_record':record_value(after.to_record()),'after_drop_state':record_value(after.state)});out['slots'].append({'index':idx,'status':'not_started'})
write_record(P/'inputs.json',{'registration':reg,'inputs':out['inputs']});write_record(P/'results.json',out);print('WITNESSREADY',len(out['slots']),round(time.perf_counter()-tick,3),flush=True)
for slot,inp in zip(out['slots'],out['inputs']):
 if time.perf_counter()-tick>=reg['whole_cap_seconds']or out['proof']is not None:break
 c=contexts[inp['world']];sess=GameSession.replay(c,deserialize_game_record(json.dumps(inp['after_drop_record'])));t=time.perf_counter()
 try:
  r=probe_terminal_only(sess,depth=2,node_budget=256);slot.update(status='finished',probe=record_value(r),seconds=time.perf_counter()-t);write_record(P/'results.json',out)
  if r.value==0.0:
   cert=[]
   for reply,after_reply in legal_successors(sess.state,c):
    wins=[{'action':record_value(a),'terminal':record_value(ch.terminal_status),'final_state':record_value(ch)}for a,ch in legal_successors(after_reply,c)if ch.terminal_status.is_terminal and ch.terminal_status.winner==inp['actor']];assert wins,('probe loss failed independentCoreallreplywitness',slot['index']);cert.append({'opponent_reply':record_value(reply),'winning_response':wins[0]})
   assert cert;out['proof']={'input_index':slot['index'],'all_legal_replies':len(cert),'reply_certificates':cert,'source_slot':inp['source_slot'],'root_record':inp['root_record'],'drop':inp['drop'],'world':inp['world'],'actor':inp['actor']};write_record(P/'results.json',out)
 except Exception as e:slot.update(status='failed',failure={'message':str(e),'traceback':traceback.format_exc()});out['failures'].append(slot.copy());write_record(P/'results.json',out)
 out['seconds']=time.perf_counter()-tick;write_record(P/'results.json',out);print('WITNESS',slot['index'],slot['status'],slot.get('probe'),bool(out['proof']),round(out['seconds'],3),flush=True)
out['seconds']=time.perf_counter()-tick;out['unattempted']=sum(s['status']=='not_started'for s in out['slots']);write_record(P/'results.json',out);print('CLOSED',len(out['slots'])-out['unattempted'],out['unattempted'],bool(out['proof']),out['seconds'],flush=True)
