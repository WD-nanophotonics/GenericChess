import json,sys,time
from pathlib import Path
from collections import Counter
from statistics import median
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.benchmark.game_quality import QualityObservation,profile_from_observations
P=Path('.local_agent/rule-quality-20261022');out={'cohorts':[]};tick=time.perf_counter()
for dirname in ('root-allocation-20261022','root-clock-20261022'):
 src=Path('.local_agent')/dirname;inputs=json.loads((src/'inputs.json').read_text(encoding='utf-8'));res=json.loads((src/'results.json').read_text(encoding='utf-8'));worlds={w['seed']:w for w in inputs['worlds']};contexts={};rows=[]
 for slot in res['slots']:
  if slot['status']!='finished':rows.append({'slot':slot['slot'],'status':slot['status'],'utility':[-1,1]});continue
  g=json.loads((src/slot['receipt']).read_text(encoding='utf-8'));w=worlds[slot['seed']];c=contexts.setdefault(slot['seed'],compile_rule(ruleset_from_dict(w['rule'])));s=GameSession(c);record=deserialize_game_record(json.dumps(g['final_record']));bs=[]
  for a in record.actions:bs.append(len(s.legal_actions()));s.submit(a)
  assert record_value(s.state)==g['final_state'];terminal=s.state.terminal_status;status=terminal.status.value;winner=terminal.winner;actual_terminal=terminal.is_terminal;eligible=g['eligible'];score=(.5 if winner is None else float(winner==0))if actual_terminal and status!='no_contest' and eligible else None
  ob=QualityObservation(tuple(bs),len(record.actions),status if actual_terminal else 'CENSORED',score,None if score is None else 1-score);profile=profile_from_observations([ob]);rows.append({'slot':slot['slot'],'seed':slot['seed'],'owner':slot['owner'],'fingerprint':c.ruleset_fingerprint,'board':w['config']['board_size'],'setup':w['config']['setup_preset'],'rule_max_ply':w['rule']['max_ply'],'plies':len(record.actions),'terminal_status':status,'winner':winner,'actual_rule_terminal':actual_terminal,'eligible':eligible,'first_score':score,'first_score_interval':[score,score]if score is not None else[0,1],'branchings':bs,'diagnostic_profile':profile.to_dict(),'full_record_replayed':True})
 bystatus=Counter(r['terminal_status'] for r in rows);unique={json.dumps((r['fingerprint'],r['branchings'],r['terminal_status'],r['winner'])) for r in rows};cohort={'name':dirname,'games':rows,'observations':len(rows),'status_counts':dict(bystatus),'distinct_path_summaries_not_independent_games':len(unique),'censored':sum(not r['actual_rule_terminal']for r in rows),'eligible':sum(r['eligible']for r in rows),'first_score_finite_interval':[sum(r['first_score_interval'][i]for r in rows)/len(rows)for i in (0,1)],'median_length':median(r['plies']for r in rows),'full_history_plies':sum(r['plies']for r in rows),'scope':'Exposed two different clock cohorts, not filter contrast nor depth ladder; repeated role paths not independent evidence.'};out['cohorts'].append(cohort);write_record(P/'retrospective.json',out);print(dirname,{k:v for k,v in cohort.items()if k not in ('games','scope')},flush=True)
out['seconds']=time.perf_counter()-tick;write_record(P/'retrospective.json',out)
