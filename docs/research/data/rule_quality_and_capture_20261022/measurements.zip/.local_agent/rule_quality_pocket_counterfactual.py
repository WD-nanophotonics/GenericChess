"""Legal full-history counterfactual: same moves, original capture-to-hand rule."""
import json,sys,time,traceback,hashlib
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
P=Path('.local_agent/rule-quality-capture-random-20261022');closed=json.loads((P/'king-only-closure.json').read_text(encoding='utf-8'));raw=json.loads((P/'results.json').read_text(encoding='utf-8'));parents={w['index']:w for w in json.loads(Path('.local_agent/rule-quality-survey-20261022/inputs.json').read_text(encoding='utf-8'))['worlds']};out={'scope':'Posthoc9unique/18view legal-historycounterfactuals. SAME actionsequence under originalcapture-to-hand rule,not inventedhands or replacementofoldUNKNOWN. Rulefingerprint necessarilytranslated;eachprefixreplayed byCore. No WDLoracle/training/default/AUXwork.','cases':[],'failures':[]};tick=time.perf_counter();cache={}
for st in closed['states']:
 g=raw['games'][st['slot']];w=parents[g['world']];c=compile_rule(ruleset_from_dict(w['rule']));key=(c.ruleset_fingerprint,json.dumps(g['final_record']['actions'],sort_keys=True))
 if key in cache:out['cases'].append({**cache[key],'slot':g['slot'],'world':g['world'],'counterfactual_reuse_from':cache[key]['slot']});continue
 row={'slot':g['slot'],'world':g['world'],'source_remove_record':g['final_record'],'counterfactual_reuse_from':None}
 try:
  rec=deserialize_game_record(json.dumps(g['final_record']));translated=replace(rec,ruleset_fingerprint=c.ruleset_fingerprint);row['counterfactual_record']=record_value(translated);write_record(P/'same-board-pocket-counterfactual.json',out|{'pending_case':row});sess=GameSession.replay(c,translated);row['counterfactual_state']=record_value(sess.state);old=g['final_state']['position'];new=row['counterfactual_state']['position'];diff=[k for k in old.keys()|new.keys()if old.get(k)!=new.get(k)];row['actual_position_difference_keys']=diff;assert set(diff)<= {'ruleset_fingerprint','hands'};assert old['board']==new['board'];children=[];hand0=sum(h.total()for h in sess.state.position.hands);board0=sum(x is not None for x in sess.state.position.board)
  for a,ch in legal_successors(sess.state,c):
   board=sum(x is not None for x in ch.position.board);hands=sum(h.total()for h in ch.position.hands);children.append({'action':record_value(a),'child_state_sha256':hashlib.sha256(json.dumps(record_value(ch),sort_keys=True).encode()).hexdigest(),'actual_stock_drop':board==board0+1 and hands==hand0-1,'terminal':record_value(ch.terminal_status)})
  row.update(legal_children=children,hand_entities=hand0,actual_stock_drops=sum(x['actual_stock_drop']for x in children),immediate_winning_children=sum(x['terminal']['winner']==sess.state.position.side_to_move and x['terminal']['status']!='ongoing'for x in children),counterfactual_terminal=record_value(sess.result));out['cases'].append(row);cache[key]=row
 except Exception as e:out['failures'].append({'slot':g['slot'],'world':g['world'],'message':str(e),'traceback':traceback.format_exc(),'partial_case':row})
 write_record(P/'same-board-pocket-counterfactual.json',out)
out['seconds']=time.perf_counter()-tick;write_record(P/'same-board-pocket-counterfactual.json',out);print('POCKETCOUNTER',len(out['cases']),len(cache),len(out['failures']),'drops',sum(x['actual_stock_drops']for x in out['cases']),'win1',sum(x['immediate_winning_children']for x in out['cases']),round(out['seconds'],2),flush=True)
