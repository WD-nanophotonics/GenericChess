import json,sys,time,random,hashlib
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
P=Path(sys.argv[1]);src=Path(sys.argv[2]);r=json.loads((P/'results.json').read_text(encoding='utf-8'));worlds={w['index']:w for w in json.loads(src.read_text(encoding='utf-8'))['worlds']};assert hashlib.sha256(src.read_bytes()).hexdigest()==r['registration']['input_sha256'];out={'validated':[],'history_plies':0,'executed_unique_games':0,'reuse_views':0,'source_input_sha256':r['registration']['input_sha256']};contexts={};tick=time.perf_counter()
for g in r['games']:
 w=worlds[g['world']]
 if g['reused_from']is not None:
  old=r['games'][g['reused_from']];ow=worlds[old['world']];assert w['rule']==ow['rule'];assert w['config']['seed']==ow['config']['seed'];assert all(g[k]==old[k]for k in('pair','swap','fingerprint','final_record','final_state','terminal','branching','first_score_interval','quality','seconds'));out['reuse_views']+=1;out['validated'].append({'slot':g['slot'],'world':g['world'],'exact_reuse_from':g['reused_from'],'full_rule_and_record_equal':True});continue
 c=contexts.get(g['world'])
 if c is None:c=contexts[g['world']]=compile_rule(ruleset_from_dict(w['rule']))
 s=GameSession(c);rec=deserialize_game_record(json.dumps(g['final_record']));seed=w['config']['seed']*1009+g['pair']*2;rng={0:random.Random(seed+g['swap']),1:random.Random(seed+1-g['swap'])};branch=[];total_entities=[]
 for a in rec.actions:
  legal=s.legal_actions();branch.append(len(legal));actor=s.state.position.side_to_move;assert legal[rng[actor].randrange(len(legal))]==a;s.submit(a);total_entities.append(sum(x is not None for x in s.state.position.board)+sum(h.total()for h in s.state.position.hands))
 assert branch==g['branching'];assert record_value(s.state)==g['final_state'];assert record_value(s.result)==g['terminal'];out['history_plies']+=len(rec.actions);out['executed_unique_games']+=1;out['validated'].append({'slot':g['slot'],'world':g['world'],'history_plies':len(rec.actions),'exact_rng_sequence_verified':True,'terminal':g['terminal'],'entities_initial':sum(x is not None for x in GameSession(c).state.position.board),'entities_final':total_entities[-1]if total_entities else None,'entity_count_nondecreasing':all(b>=a for a,b in zip(total_entities,total_entities[1:])),'entity_count_nonincreasing':all(b<=a for a,b in zip(total_entities,total_entities[1:]))});write_record(P/'verified.json',out)
out['seconds']=time.perf_counter()-tick;out['validated_views']=len(out['validated']);out['scope']='FullsharedCore/RNGreconstruction,exactreuses notnewgameexecution;not independentrulesimplementation or populationCI.';write_record(P/'verified.json',out);print('RNGVERIFIED',out['executed_unique_games'],out['reuse_views'],out['history_plies'],round(out['seconds'],2),flush=True)
