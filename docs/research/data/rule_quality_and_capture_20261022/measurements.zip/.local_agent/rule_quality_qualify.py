import json,sys,time
from pathlib import Path
from collections import Counter
from statistics import median
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution as compile_rule
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import legal_successors
from generic_chess.benchmark.game_quality import QualityObservation,profile_from_observations
P=Path(sys.argv[1]);data=json.loads((P/'results.json').read_text(encoding='utf-8'));worlds={w['index']:w for w in json.loads((P/'inputs.json').read_text(encoding='utf-8'))['worlds']};out={'games':[],'pv_plies':0,'history_plies':0,'queries':0};contexts={};tick=time.perf_counter()
for slot in data['slots']:
 if slot['status']!='finished':continue
 g=json.loads((P/slot['receipt']).read_text(encoding='utf-8'));w=worlds[slot['world']];c=contexts.get(w['index'])
 if c is None:c=contexts[w['index']]=compile_rule(ruleset_from_dict(w['rule']))
 s=GameSession(c);states=[s.state];record=deserialize_game_record(json.dumps(g['final_record']));branch=[]
 for a in record.actions:branch.append(len(s.legal_actions()));s.submit(a);states.append(s.state)
 assert record_value(s.state)==g['final_state'];assert record_value(s.result)==g['terminal'];out['history_plies']+=len(record.actions);prices=Counter();actual_policy=Counter()
 for q in g['queries']:
  st=states[q['root_ply']];d=q['decision'];legal=list(legal_successors(st,c));assert len(legal)==q['legal_count'];assert d['runtime_depth_balanced'];assert q['actor']==st.position.side_to_move
  if d['action'] is not None:assert any(record_value(a)==d['action']for a,ch in legal)
  pv=st
  for raw in d['principal_variation']:
   a,pv=next((a,ch)for a,ch in legal_successors(pv,c)if record_value(a)==raw);out['pv_plies']+=1
  if d['result_source']=='root_immediate_win':assert pv.terminal_status.is_terminal and pv.terminal_status.winner==q['actor']
  actual_policy[(q['limits']['max_depth'],d['completed_depth'],d['result_ordinary_qdepth'],d['result_source'])]+=1;out['queries']+=1
 status=s.result.status.value;real_terminal=status!='ongoing';score=(.5 if s.result.winner is None else float(s.result.winner==0))if real_terminal and status!='no_contest'and g['eligible']else None
 ob=QualityObservation(tuple(branch),len(record.actions),status if real_terminal else 'CENSORED',score,None if score is None else 1-score,terminal_winner=s.result.winner);profile=profile_from_observations([ob]);out['games'].append({'slot':slot['slot'],'world':w['index'],'arm':slot['arm'],'fingerprint':c.ruleset_fingerprint,'filter':w['config']['require_no_opening_win_in_one'],'board':w['config']['board_size'],'setup':w['config']['setup_preset'],'terminal':g['terminal'],'eligible':g['eligible'],'d2_or_deeper_utility_interval':g['d2_utility_interval'],'plies':len(record.actions),'queries':len(g['queries']),'policy_strata':{str(k):v for k,v in actual_policy.items()},'quality':profile.to_dict(),'wall_seconds':g['wall_seconds']});write_record(P/'qualified.json',out);print('QUALIFIED',slot['slot'],out['queries'],out['pv_plies'],round(time.perf_counter()-tick,2),flush=True)
out['seconds']=time.perf_counter()-tick;out['scope']='All completed receipts,full Core literal PV and complete histories;no unseen q proof/full WDL/independent rule implementation.';write_record(P/'qualified.json',out)
