"""PRIMARY independent closed-data gradient geometry; no learner imports or updates."""
from pathlib import Path
import json, math, collections, time, hashlib
import numpy as np
import sys
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(".local_agent/td-tree-20261017");X=D/"exact/results/dev_aux"
start=time.monotonic();groups={};witnesses=[];checked=0;finite=[]
def zero_stats():
 return dict(queries=0,samples=0,error_active=0,usable_samples=0,root_zero=0,tree_zero=0,both_zero=0,root_zero_tree_nonzero=0,noncollinear=0,opposed=0,tree_energy=0.,root_energy=0.,outside_root_energy=0.,sum_cos=0.,cos_count=0,matrix=[])
def direction(samples,w):
 out=np.zeros(4);active=usable=0
 for phi,lo,hi,depth in samples:
  v=math.tanh(math.fsum(x*y for x,y in zip(phi,w))/10)
  a=-1. if lo is None else math.tanh(lo/10);b=1. if hi is None else math.tanh(hi/10)
  err=a-v if v<a else b-v if v>b else 0.
  g=np.array(phi[1:],dtype=float)*(1-v*v)*err/10
  active+=int(abs(err)>1e-14);usable+=int(np.linalg.norm(g)>1e-14);out+=g
 return out/max(1,len(samples)),active,usable
def loss(samples,w):
 val=0.
 for phi,lo,hi,_ in samples:
  v=math.tanh(math.fsum(x*y for x,y in zip(phi,w))/10)
  a=-1. if lo is None else math.tanh(lo/10);b=1. if hi is None else math.tanh(hi/10)
  val+=(a-v if v<a else b-v if v>b else 0.)**2/2
 return val/max(1,len(samples))
def inspect(study,r,cal=False):
 global checked
 samples=r["samples"];w=r["weights"]if cal else r["weights_before"]
 t,active,usable=direction(samples,w);root,_,_=direction(samples[-1:],w)
 key=(study,r["seed"],r.get("method","calibration"));g=groups.setdefault(key,zero_stats())
 t2=float(t@t);r2=float(root@root);dot=float(t@root);tz=t2<1e-28;rz=r2<1e-28
 orth=t if rz else t-root*(dot/r2);o2=float(orth@orth)
 g["queries"]+=1;g["samples"]+=len(samples);g["error_active"]+=active;g["usable_samples"]+=usable
 for n,b in (("root_zero",rz),("tree_zero",tz),("both_zero",rz and tz),("root_zero_tree_nonzero",rz and not tz),("noncollinear",not tz and not rz and o2>t2*1e-12),("opposed",not tz and not rz and dot<0)):g[n]+=int(b)
 g["tree_energy"]+=t2;g["root_energy"]+=r2;g["outside_root_energy"]+=o2
 if not rz and not tz:g["sum_cos"]+=dot/math.sqrt(t2*r2);g["cos_count"]+=1
 g["matrix"].append(t.tolist())
 if cal:
  assert np.allclose(t,r["tree_direction"][1:],atol=1e-13,rtol=1e-10)
  assert np.allclose(root,r["root_direction"][1:],atol=1e-13,rtol=1e-10)
 elif r["method"]=="tree":
  expected=np.array(w[1:])+t*r.get("effective_eta",.05)
  assert np.allclose(expected,r["weights_after"][1:],atol=1e-12,rtol=1e-10)
 else:
  expected=np.array(w[1:])+root*r["effective_eta"]
  assert np.allclose(expected,r["weights_after"][1:],atol=1e-12,rtol=1e-10)
 checked+=1
 if not tz and (cal and len([x for x in finite if x["study"]=="calibration"])<8):
  fd=[]
  for i in range(1,5):
   u=list(w);v=list(w);u[i]+=1e-8;v[i]-=1e-8
   fd.append(-(loss(samples,u)-loss(samples,v))/2e-8)
  err=max(abs(x-y)for x,y in zip(t,fd));
  if err>=1e-9: print("FD_FAILURE",r["seed"],r.get("family"),t.tolist(),fd,err,flush=True)
  assert err<1e-9
  finite.append(dict(study="calibration",seed=r["seed"],family=r["family"],max_error=err))
 if o2>1e-12 and len(witnesses)<8:witnesses.append(dict(study=study,seed=r["seed"],family=r.get("family"),game=r.get("game"),ply=r.get("ply"),root=root.tolist(),tree=t.tolist(),orthogonal_energy=o2))
 assert time.monotonic()-start<180
for line in(X/"task2517/queries.jsonl").open():
 r=json.loads(line);assert r["complete"];inspect("initial64TRAIN",r,True)
for task,study in (("task2512","A"),("task2518","B")):
 for line in(X/task/"decisions.jsonl").open():
  r=json.loads(line)
  if r["complete"] and r["method"] in ("root","tree"):inspect(study,r)
rows=[]
for (study,seed,method),g in groups.items():
 mat=np.array(g.pop("matrix"));sing=np.linalg.svd(mat,compute_uv=False)
 g["gradient_rank"]=int(np.linalg.matrix_rank(mat));g["singular_values"]=sing.tolist()
 g["tree_RMS"]=math.sqrt(g["tree_energy"]/g["queries"]);g["root_RMS"]=math.sqrt(g["root_energy"]/g["queries"])
 g["outside_root_energy_fraction"]=g["outside_root_energy"]/g["tree_energy"]if g["tree_energy"] else None
 g["mean_cos_on_both_nonzero"]=g["sum_cos"]/g["cos_count"]if g["cos_count"]else None
 rows.append(dict(study=study,seed=seed,method=method,**g))
write_json(D/"gradient-geometry.json",dict(status="PASS_INDEPENDENT_STATIC_GRADIENT_GEOMETRY",checked_queries=checked,seconds=time.monotonic()-start,rows=rows,finite_difference=finite,witnesses=witnesses,numerics="Nonzero norm>1e-14, active error>1e-14; geometry relative orthogonal energy1e-12. Counts not independent samples. Results include all zero/inactive denominator terms; pawn held fixed.",scope="Independent scalar arithmetic, no imported learner, applied update agreement and no weight modifications. Calibration128frozen initial64ply TRAIN vs changing A/B16ply selfplay are distinct. Orthogonal component proves different local direction, not useful information, causal mediation, strength or stable prices. B root logs only root sample: cannot reconstruct omitted full Tree batch, no guessed geometry."))
print([(r["study"],r["seed"],r["method"],r["queries"],r["root_zero_tree_nonzero"],r["noncollinear"],round(r["outside_root_energy_fraction"]or 0,4),r["gradient_rank"])for r in rows])

