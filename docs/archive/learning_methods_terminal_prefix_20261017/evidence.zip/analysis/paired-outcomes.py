"""PRIMARY independent paired outcome arithmetic and descriptive sensitivity."""
from pathlib import Path
import json,collections,sys,time,math,random
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(".local_agent/td-tree-20261017");X=D/"exact/results/dev_aux";start=time.monotonic()
panels=[];total=0
for label,path,treatments in (("A_endpoint","task2513/endpoint",("td","tree")),("A_midpoint","task2513/midpoint",("td","tree")),("A_different_foe","task2516/different_foe",("td","tree")),("B_endpoint","task2519/root_control",("root","tree"))):
 rr=[json.loads(l)for l in(X/path/"games.jsonl").open()];idx={(r["seed"],r["family"],r["color"],r["treatment"]):r for r in rr};assert len(idx)==len(rr);seeds=sorted({r["seed"]for r in rr});families=sorted({r["family"]for r in rr});assert len(rr)==len(seeds)*len(families)*6;total+=len(rr)
 def interval(s,f,c,t):
  v=idx[s,f,c,t]["reward"];return(-1,1)if v is None else(v,v)
 compares=[]
 for a,b in((treatments[0],"initial"),(treatments[1],"initial"),(treatments[1],treatments[0])):
  cells=np.array([[[sum(interval(s,f,c,a)[j]-interval(s,f,c,b)[1-j]for c in(0,1))/2 for j in(0,1)]for f in families]for s in seeds])
  pooled=cells.mean(axis=(0,1));byseed=cells.mean(axis=1)
  # Sample seed and family axes independently, retaining their Cartesian product.
  rng=np.random.default_rng(2026101701);reps=20000
  sw=rng.multinomial(len(seeds),[1/len(seeds)]*len(seeds),size=reps)/len(seeds)
  fw=rng.multinomial(len(families),[1/len(families)]*len(families),size=reps)/len(families)
  draws=np.einsum("rs,sfj,rf->rj",sw,cells,fw)
  env=[float(np.quantile(draws[:,0],.025,method="lower")),float(np.quantile(draws[:,1],.975,method="lower"))]
  lose_seed=[cells[[i for i in range(len(seeds))if i!=k]].mean(axis=(0,1)).tolist()for k in range(len(seeds))]
  lose_family=[cells[:,[i for i in range(len(families))if i!=k]].mean(axis=(0,1)).tolist()for k in range(len(families))]
  compares.append(dict(candidate=a,baseline=b,pooled_bounds=pooled.tolist(),per_seed=[dict(seed=s,bounds=v.tolist())for s,v in zip(seeds,byseed)],crossed_descriptive_20000=env,leave_one_seed=lose_seed,leave_one_family_extrema=[min(x[0]for x in lose_family),max(x[1]for x in lose_family)]))
  # Direct shared baseline is canceled algebraically, never subtract marginal CIs.
  assert np.all(cells[:,:,0]<=cells[:,:,1])
 tallies=[dict(seed=s,treatment=t,counts=dict(collections.Counter("U"if r["reward"]is None else"W"if r["reward"]==1 else"L"if r["reward"]==-1 else"D"for r in rr if r["seed"]==s and r["treatment"]==t)))for s in seeds for t in("initial",*treatments)]
 panels.append(dict(label=label,physical_games=len(rr),initial_physical_games=sum(r["treatment"]=="initial"for r in rr),actual_terminal=sum(r["reward"]is not None for r in rr),unknown=sum(r["reward"]is None for r in rr),families=len(families),seeds=seeds,compares=compares,tallies=tallies))
orders=[]
for task,study in(("task2512","A"),("task2518","B")):
 done=json.loads((X/task/"result.json").read_text())
 for a in done["arms"]:
  w=a["weights"];orders.append(dict(study=study,seed=a["seed"],method=a["method"],initial=a["initial"],final=w,ordinal_indices_low_to_high=sorted(range(1,5),key=lambda j:w[j]),pairwise=[dict(i=i,j=j,difference=w[i]-w[j])for i in range(1,5)for j in range(i+1,5)]))
assert total==960
write_json(D/"paired-outcomes.json",dict(status="PASS_PRIMARY_INDEPENDENT_PAIRED_OUTCOMES",games=total,panels=panels,weights=orders,seconds=time.monotonic()-start,scope="Own arithmetic and new fixed20k multinomial seed/family resampling. Different RNG/replicate count from owner's5k: descriptive envelopes not exact reproduction endpoints, calibrated hypothesis tests or general methodwinner. Families reused across4seeds/bothroles; initial physicalbaseline once. A/Bdifferentcohorts notsame learningcurve. AllU[-1,+1], no seed/model selection or human-price references."))
print([(p["label"],p["actual_terminal"],p["unknown"],[(c["candidate"],c["baseline"],c["pooled_bounds"],c["crossed_descriptive_20000"])for c in p["compares"]])for p in panels])

