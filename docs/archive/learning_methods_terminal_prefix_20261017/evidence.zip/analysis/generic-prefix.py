"""Prospective PRIMARY generic prefix exposure; uniform typed actions, no search/learning."""
from pathlib import Path
import json,sys,time,random,hashlib,traceback,collections
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.generation.generator import generate_game
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.result import SessionStatus
D=Path(".local_agent/td-tree-20261017");O=D/"generic-prefix-v2";O.mkdir(exist_ok=False)
slots=[dict(slot=i,board=n,preset=p,seed=960000+i,walk_seed=970000+i)for i,(n,p,k)in enumerate((n,p,k)for n in(4,6,8)for p in("classic_like","bilateral_random","free_random")for k in range(8))]
plan=dict(question="Does the Chess16-to64 material-exposure premise transfer mechanically to unfamiliar generated rules without selecting survivors?",slots=slots,horizons=[16,64],cap_seconds=1200,forecast_minutes=10,max_generation_attempts=32,scope="Prospective72generatedlegacyatom rules with hybrid moves, promotion/drop/completeGameSessionhistory; not allmechanism-domain coverage. Uniform typed legalaction bindings, no reward/search/learning, no hand/current/base or history truncation, defaultopeningpreferenceFalse. Missing generation/terminal-beforeprefix/cap remain absent, never absorbing padded examples. Conditionalexposure notbalance/usefulness/strength. No AUXprograms or checkout.")
plan["source_sha256"]={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in("generic_chess/generation/generator.py","generic_chess/generation/config.py","generic_chess/core/transition.py","generic_chess/core/semantic_executor.py","generic_chess/session/session.py")}
write_json(O/"plan.json",plan);start=time.monotonic();write_json(O/"started.json",dict(utc=__import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()))
rows=[];rules=[];edges=0;status="COMPLETE";reason=None
def poll():
 if time.monotonic()-start>=plan["cap_seconds"]:raise TimeoutError("FROZEN_GLOBAL_CAP")
 for n in("rollout","advisor","slack"):
  v=json.loads((Path(".local_agent")/(n+".json")).read_bytes())
  if v.get("stopped")or v.get("user_paused"):raise InterruptedError("EXPLICIT_STOP")
def view(s,types):
 b=collections.Counter();h=collections.Counter()
 for p in s.state.position.board:
  if p:b[p.current_type_id]+=1 if p.owner==0 else -1
 for owner,hand in enumerate(s.state.position.hands):
  for t,num in hand.counts:h[t]+=(1 if owner==0 else -1)*num
 return dict(board={t:b[t]for t in types},hand={t:h[t]for t in types})
with(O/"edges.jsonl").open("x",encoding="utf8")as log:
 try:
  for slot in slots:
   poll();t=time.monotonic();row=dict(**slot,checkpoints=[])
   try:g=generate_game(GeneratorConfig(seed=slot["seed"],board_size=slot["board"],setup_preset=slot["preset"],allow_hybrid=True,max_generation_attempts=32))
   except GenerationError as e:
    row.update(status="GENERATION_ABSENT",error=str(e),seconds=time.monotonic()-t);rows.append(row);print(slot["slot"],row["status"],flush=True);continue
   poll();c=compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=GameSession(c);types=sorted(t.type_id for t in g.ruleset.piece_types);anchors={t.type_id for t in g.ruleset.piece_types if t.is_anchor}
   assert not g.ruleset.declarations
   rules.append(dict(slot=slot["slot"],ruleset=json.loads(serialize_ruleset(g.ruleset)),report=record_value(g.generation_report)))
   rng=random.Random(slot["walk_seed"]);row["generation_attempts"]=g.generation_report.generation_attempts;row["typed_actions"]=dict(drop=0,promotion=0,board=0);row["names"]=[(k,t)for k in("board","hand")for t in types];row["opening"]=view(s,types)
   for ply in range(65):
    poll();result=s.result;assert len(s.state.history)==s.state.ply_count+1
    if ply in(16,64):
     fs=view(s,types);row["checkpoints"].append(dict(ply=ply,features=fs,nonzero_free=any(v for k in fs for t,v in fs[k].items()if t not in anchors),nonzero_hand=any(fs["hand"].values()),promoted=sum(p is not None and p.promoted for p in s.state.position.board),fullstate=record_value(s.state),record=record_value(s.to_record()),result=record_value(result),ongoing=result.status is SessionStatus.ONGOING))
    if result.status is not SessionStatus.ONGOING:
     row["ending"]="ACTUAL_"+result.status.value;row["terminal_ply"]=ply;break
    if ply==64:row["ending"]="PREFIX64_ONGOING";break
    actions=s.legal_actions();assert actions;actions=sorted(actions,key=lambda a:json.dumps(record_value(a),sort_keys=True,separators=(",",":")));a=rng.choice(actions);before=s.state;stamp=time.monotonic();s.submit(a);elapsed=time.monotonic()-stamp
    data=record_value(a);drop="base_type_id"in data;promotion=data.get("promotion_target_id")is not None;row["typed_actions"]["drop"if drop else"board"]+=1;row["typed_actions"]["promotion"]+=promotion;edges+=1
    log.write(json.dumps(dict(slot=slot["slot"],ply=ply,legal_actions=len(actions),action=data,after_key=s.state.history[-1].position_key,history_length=len(s.state.history),submit_seconds=elapsed),separators=(",",":"))+"\n");log.flush()
   row.update(status="RETURNED",seconds=time.monotonic()-t,final_record=record_value(s.to_record()),final_result=record_value(s.result));rows.append(row)
   write_json(O/"progress.json",dict(status="RUNNING",closed_slots=len(rows),edges=edges,seconds=time.monotonic()-start))
   write_json(O/"partial-results.json",dict(rows=rows,rules=rules))
   print(slot["slot"],row["ending"],row.get("terminal_ply",64),row["typed_actions"],round(row["seconds"],3),flush=True)
 except(TimeoutError,InterruptedError)as e:status="PARTIAL";reason=str(e)
 except Exception as e:status="ERROR";reason=repr(e);traceback.print_exc()
write_json(O/"result.json",dict(status=status,reason=reason,planned=len(slots),returned=len(rows),unstarted=len(slots)-len(rows),edges=edges,rows=rows,rules=rules,seconds=time.monotonic()-start))
print("CLOSED",status,len(rows),edges,round(time.monotonic()-start,3),reason,flush=True)

