"""Closed generic records: feature coverage/stability is not return usefulness."""
from pathlib import Path
import json,math,sys,time,hashlib,collections
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(".local_agent/td-tree-20261017");O=D/"generic-prefix-v2";v=json.loads((O/"result.json").read_bytes());plan=json.loads((O/"plan.json").read_bytes())
for p,h in plan["source_sha256"].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
write_json(D/"feature-stability-plan.json",dict(question="Can cheap typed counts support rule-only candidate feature analysis without conflating temporal stability with W/L usefulness?",decision="Compute Clune's overall variance/adjacent squared-change quotient on ALLclosed72paths, include turn andplynegativecontrols, markconstant/zero-denominator. Observedrank/countedstability never selectsfeatures or prices without outcomes.",forecast_seconds=30,cap_seconds=120,new_search_training_games=0))
start=time.monotonic();rules={x["slot"]:x["ruleset"]for x in v["rules"]};rows=[];states=edges=0
def feature(s,ids):
 b=collections.Counter();h=collections.Counter()
 for p in s.state.position.board:
  if p:b[p.current_type_id]+=1 if p.owner==0 else -1
 for owner,hand in enumerate(s.state.position.hands):
  for t,num in hand.counts:h[t]+=(1 if owner==0 else -1)*num
 return[b[t]for t in ids]+[h[t]for t in ids]
for row in v["rows"]:
 if row["status"]!="RETURNED":continue
 rule=deserialize_ruleset(json.dumps(rules[row["slot"]]));c=compile_legacy_ruleset_for_semantic_execution(rule);s=GameSession(c);ids=sorted(t.type_id for t in rule.piece_types if not t.is_anchor);names=[k+":"+t for k in("board","hand")for t in ids];xx=[feature(s,ids)];checks={x["ply"]:x for x in row["checkpoints"]}
 for a in row["final_record"]["actions"]:
  act=SemanticBoardMove(a["pattern_id"],a["geometry_id"],a["actor_type_id"],Square(**a["from_square"]),Square(**a["to_square"]),a["promotion_target_id"])if"from_square"in a else SemanticDropMove(a["pattern_id"],a["geometry_id"],a["base_type_id"],Square(**a["to_square"]))
  s.submit(act);edges+=1;xx.append(feature(s,ids));n=s.state.ply_count
  assert len(s.state.history)==n+1
  if n in checks:assert record_value(s.state)==checks[n]["fullstate"]and record_value(s.to_record())==checks[n]["record"]
 assert record_value(s.to_record())==row["final_record"]and record_value(s.result)==row["final_result"]
 a=np.array(xx,float);states+=len(a);series=np.column_stack((a,np.arange(len(a)),np.arange(len(a))%2));entries=[]
 for j,name in enumerate(names+["negative_control:ply","negative_control:turn"]):
  x=series[:,j];var=float(np.var(x));adj=float(np.mean(np.diff(x)**2))if len(x)>1 else 0.
  entries.append(dict(name=name,nonzero_states=int(np.count_nonzero(x)),variance=var,adjacent_squared_change=adj,stability=None if adj==0 else var/adj,status="CONSTANT"if var==0 else"NO_ADJACENT_VARIATION"if adj==0 else"DEFINED"))
 sing=np.linalg.svd(a,compute_uv=False);rows.append(dict(slot=row["slot"],board=row["board"],preset=row["preset"],states=len(xx),rank=int(np.linalg.matrix_rank(a)),dimensions=len(names),never_excited=[name for j,name in enumerate(names)if not np.any(a[:,j])],singular_values=sing.tolist(),features=entries,ending=row["ending"]))
 assert time.monotonic()-start<120
 for n in("rollout","advisor","slack"):
  f=json.loads((Path(".local_agent")/(n+".json")).read_bytes());assert not(f.get("stopped")or f.get("user_paused"))
write_json(D/"feature-stability.json",dict(status="PASS_ALL_CLOSED_TYPED_FEATURE_READ",rules=len(rows),states=states,edges=edges,rows=rows,seconds=time.monotonic()-start,source="Clune2007 p3: populationoverallvariance divided by mean adjacent squaredchange. Constant explicitlyundefined; no formula renormalization.",scope="Same72closedpaths including terminals, fullstates/history/records match, notnewgames. Typedboardcurrent/handbase allnonanchors included. Plyandturn are negativecontrols, notcandidateweights. Highstability/rank alone gives no payoff correlation, uniqueprices, generalization or utility; common-rule type spelling is not shared parameters. No GDL parser/abstract solver/feature learner introduced."))
print("CLOSED",len(rows),states,edges,round(time.monotonic()-start,3),"rank_ranges",min(r["rank"]for r in rows),max(r["rank"]for r in rows))

