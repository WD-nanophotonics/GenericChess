"""PRIMARY: paired prefix exposure and old pilot Root gradients, no search or fit."""
from pathlib import Path
import json,math,collections,sys,time
import numpy as np
import chess
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(".local_agent/td-tree-20261017");X=D/"exact/results/dev_aux";old=Path(".local_agent/learning-cost-20261017/peer87/exact/results/dev_aux/task2505/queries.jsonl")
begin=time.monotonic()
def feat(b):return [len(b.pieces(t,True))-len(b.pieces(t,False))for t in range(1,6)]
rs=[json.loads(l)for l in(X/"task2517/queries.jsonl").open()];boardrecords={}
for r in rs:
 record=r["record"];f=r["family"]
 if f in boardrecords:assert boardrecords[f]==record
 else:boardrecords[f]=record
rows=[]
for f,rec in boardrecords.items():
 b=chess.Board(rec["initial"]);prefix=rec["moves"];assert len(prefix)<=64
 for step in range(65):
  if step in (16,32,64):
   o=b.outcome(claim_draw=True);rows.append(dict(family=f,ply=step,actual_length=min(step,len(prefix)),phi=feat(b),free_input=any(feat(b)[1:]),current_pieces=len(b.piece_map()),legal_actions=len(list(b.legal_moves)),terminal=None if o is None else str(o.termination),promoted_bitboard=int(b.promoted),full_moves=prefix[:step],fen=b.fen()))
  if step==64:break
  if step<len(prefix):
   m=chess.Move.from_uci(prefix[step]);assert m in b.legal_moves;b.push(m)
  else:assert b.outcome(claim_draw=True)is not None
summaries=[]
for n in(16,32,64):
 rr=[r for r in rows if r["ply"]==n];mat=np.array([r["phi"][1:]for r in rr],float);sing=np.linalg.svd(mat,compute_uv=False)
 summaries.append(dict(ply=n,families=len(rr),nonzero_free_input=sum(r["free_input"]for r in rr),terminal=sum(r["terminal"]is not None for r in rr),rank=int(np.linalg.matrix_rank(mat)),singular_values=sing.tolist(),mean_legal_actions=sum(r["legal_actions"]for r in rr)/len(rr),mean_pieces=sum(r["current_pieces"]for r in rr)/len(rr),promoted_states=sum(r["promoted_bitboard"]!=0 for r in rr)))
rr=[json.loads(l)for l in old.open()];pilot=collections.defaultdict(lambda:dict(n=0,zero=0,ss=0.,free_input=0));pairs=collections.defaultdict(list)
for r in rr:
 key=(r["seed"],r["quiet"]);pairs[(r["seed"],r["family"])].append(r)
 b=chess.Board(r["record"]["initial"])
 for u in r["record"]["moves"]:b.push_uci(u)
 phi=feat(b);w=r["initial"];v=math.tanh(sum(x*y for x,y in zip(phi,w))/10);target=math.tanh(r["value"]/10);g=[(target-v)*x*(1-v*v)/10 for x in phi[1:]];s=pilot[key];s["n"]+=1;s["zero"]+=not any(g);s["free_input"]+=any(phi[1:]);s["ss"]+=sum(x*x for x in g)
for rs0 in pairs.values():assert len(rs0)==2 and rs0[0]["record"]==rs0[1]["record"]
pilotrows=[dict(seed=s[0],quiet=s[1],**v,RMS=math.sqrt(v["ss"]/v["n"]))for s,v in pilot.items()]
write_json(D/"prefix-exposure.json",dict(status="PASS_CLOSED_PAIRED_PREFIX_EXPOSURE",scope="Truncate SAME32 full64ply recorded Chess TRAIN paths at16/32/64, no regenerated path, search, learning, targets or hyperparameter fit. Four seeds repeat same boards; count32independentfamilies, not128. This is geometric coverage only, not stronger player/cross-rule proof. Original87pilot reused/exposed, plain/q2 target pairs correlated.",rows=rows,summaries=summaries,old87_initial_pilot=pilotrows,old87_receipts=len(rr),old87_pairs=len(pairs),seconds=time.monotonic()-begin))
print(json.dumps(dict(summaries=summaries,oldpilot=pilotrows)))


