from pathlib import Path
import sys,json,time,importlib.util,statistics,collections
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';sys.path[:0]=[str(R),str(P)]
from core_teacher import SearchMetadataAdapter,stopped,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,SearchLimits,record_value,write_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
spec=importlib.util.spec_from_file_location('compactprofile._native_core',P/'compact_profile_native_core.pyd');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);original=module.semantic_engine_search;raw={}
def tap(*a,**k):
 z=original(*a,**k);raw.clear();raw.update(z);return z
module.semantic_engine_search=tap
plan=json.loads((P/'compact-profile-plan.json').read_bytes());rows=[];start=time.perf_counter()
for case in plan['cases']:
 stopped();d=json.loads((P/case['root']).read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));before=record_value(s.state);nrs=dict(normal=compile_native_semantic_rules(c),private_counter=compile_native_semantic_rules(c,backend_module=module));payload=json.loads((P/'compact-payloads'/f"{case['seed']}-16.json").read_bytes())
 for rep in range(2):
  pair=[]
  for arm in plan['arms']if rep==0 else list(reversed(plan['arms'])):
   stopped()
   if time.perf_counter()-start>180:raise TimeoutError('Frozenwholecap')
   e=SemanticSearchEngine(c,nrs[arm],board_values=d['board_values'],hand_values=d['hand_values'],compact_values=payload,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);sec=time.perf_counter()-t;assert record_value(s.state)==before;row=dict(seed=case['seed'],board=case['board'],rep=rep,arm=arm,payload=f"compact-payloads/{case['seed']}-16.json",result=record_value(r),caller_seconds=sec,root_restored=True)
   if arm=='private_counter':row['metrics']={k:int(v)for k,v in raw.items()if k.startswith('private_compact_')}
   rows.append(row);pair.append(row);write_record(P/'compact-profile-progress.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start))
  a={k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'};b={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'};assert a==b,(case['seed'],rep);print('COMPACT_PROFILE',case['seed'],rep,pair[0]['result']['completed_depth'],round(pair[0]['caller_seconds'],4),round(pair[1]['caller_seconds'],4),flush=True)
write_record(P/'compact-profile-results.json',dict(complete=True,rows=rows,queries=len(rows),games=0,training=0,seconds=time.perf_counter()-start,scope=plan['scope']))
for board in(4,8,12):
 xs=[x for x in rows if x['board']==board and x['arm']=='private_counter'];print('FRACTIONS',board,'dynamic',[round(x['metrics']['private_compact_dynamic_ns']/x['metrics']['private_compact_ns'],4)for x in xs],'dense',[round(x['metrics']['private_compact_dense_ns']/x['metrics']['private_compact_ns'],4)for x in xs],flush=True)