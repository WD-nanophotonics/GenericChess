"""Bounded Native finite-teacher and root-order comparison; no learning or games."""
from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R));P=R/'.local_agent/alias-teacher-20261016';O=R/'.local_agent/matched-d2-20261016'
from scripts.research_record import record_value,write_record
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.reserve_refresh_diagnostic import stopped
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine,_module
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits

def digest(s):return hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest()
def main():
 old=json.loads((O/'plan.json').read_bytes());cases=[];(P/'roots').mkdir(exist_ok=True)
 for case in old['cases']:
  d=json.loads((O/case['root']).read_bytes());d={k:d[k]for k in('seed','ruleset','game_record','state','before_sha256','board_values','hand_values')};write_record(P/'roots'/f"{case['seed']}.json",d)
  hints=[]
  for ac in case['forced_actions'].values():
   if ac not in hints:hints.append(ac)
  cases.append(dict(seed=case['seed'],board=case['board'],root=f"roots/{case['seed']}.json",hints=hints,provenance='8alreadyexposedparents,22previousfourcellfirstactions; no selectionfromnewteacher/cost'))
 plan=dict(status='FROZEN_BEFORE_NEW_QUERIES',question='Do affordable stronger finite action-Q labels give root hints that save bounded Native work, or does target choice need cost-aware evaluation?',cases=cases,teacher=dict(depth=5,nodes=262144,seconds=32,q=0,tt_mb=0),root=dict(depth=6,nodes=[512,4096,65536],seconds=4,q=0,tt_mb=0),teacher_slots=22,root_slots=90,max_queries=112,expected_seconds=850,whole_seconds=1500,scope='SubsetactionfiniteD6Q withcompletefullgeneratedrules/history, NOTglobaloptimalWDL/exactteacher/model/generalization. No newAUXsolver/learning/games or changeoldcaps. Cheapalternative14fixturequeriesalreadyclosed; positive/negativefullrulebudgeteffects canchangefuturelabelobjective, noautomaticadoption.')
 write_record(P/'finite-teacher-plan.json',plan);rows=[];start=time.perf_counter();module=_module();original=module.semantic_engine_search;rawbox=[]
 def tap(*args,**kwargs):
  raw=original(*args,**kwargs);rawbox.append(dict(raw));return raw
 module.semantic_engine_search=tap
 def execute(s,nr,d,limits,hint=None):
  before=digest(s);e=SemanticSearchEngine(s.compiled,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False)
  rawbox.clear();t=time.perf_counter();res=e.search(s,SearchLimits(max_depth=limits['depth'],max_nodes=limits['nodes'],max_time_seconds=limits['seconds'],quiescence_max_depth=0,quiescence_hard_max_depth=0),root_order_hint=hint,root_window_pruning=True);sec=time.perf_counter()-t
  assert digest(s)==before;raw=rawbox[-1];return dict(result=record_value(res),caller_seconds=sec,root_restored=True,raw_counters={k:raw[k]for k in('root_tie_refinements','beta_cutoffs','nodes','qnodes','legal_generation_count','transition_count')})
 def save(row):
  rows.append(row);write_record(P/'finite-teacher-progress.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start));print(row['phase'],row['seed'],row.get('hint_index'),row.get('nodes_cap'),row['kind'],row.get('result',{}).get('completed_depth'),round(row.get('caller_seconds',0),3),flush=True)
 try:
  for case in cases:
   stopped();d=json.loads((P/case['root']).read_bytes());raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=compile_native_semantic_rules(c);root=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));assert digest(root)==d['before_sha256'];legal=tuple(root.legal_actions());hints=[next(a for a in legal if record_value(a)==ad)for ad in case['hints']]
   for i,ac in enumerate(hints):
    stopped();row=dict(phase='teacher',seed=case['seed'],hint_index=i,action=record_value(ac))
    if time.perf_counter()-start>=1500:save(dict(**row,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
    s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));s.submit(ac);row['child_state']=record_value(s.state)
    if s.state.terminal_status.is_terminal:
     q=0 if s.state.terminal_status.winner is None else (99999999 if s.state.terminal_status.winner==root.state.position.side_to_move else -99999999);save(dict(**row,kind='ACTUAL_TERMINAL_CHILD',finite_root_q=q));continue
    rec=execute(s,nr,d,plan['teacher']);q=-rec['result']['score'];q=q-1 if q>50000000 else q+1 if q< -50000000 else q
    save(dict(**row,kind='ACTUAL_QUERY',**rec,finite_root_q=q if rec['result']['completed_depth']==5 else None,label='COMPLETED_FINITE_D6'if rec['result']['completed_depth']==5 else 'PARTIAL_NOT_D6'))
   for ni,nodes in enumerate(plan['root']['nodes']):
    order=list(range(-1,len(hints)));order=order if ni%2==0 else list(reversed(order))
    for i in order:
     stopped();row=dict(phase='root',seed=case['seed'],hint_index=i,nodes_cap=nodes,hint=None if i<0 else record_value(hints[i]))
     if time.perf_counter()-start>=1500:save(dict(**row,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
     rec=execute(root,nr,d,dict(plan['root'],nodes=nodes),None if i<0 else hints[i]);save(dict(**row,kind='ACTUAL_QUERY',**rec))
 finally:module.semantic_engine_search=original
 write_record(P/'finite-teacher-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,queries=sum(r['kind']=='ACTUAL_QUERY'for r in rows),games=0,training=0,scope=plan['scope']))
 print('FINITE_TEACHER_CLOSED',len(rows),round(time.perf_counter()-start,3),flush=True)
if __name__=='__main__':main()