from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';OLD=R/'.local_agent/matched-d2-20261016';P.mkdir(exist_ok=True)
sys.path[:0]=[str(R),str(R/'.local_agent/playability-mu-20261016')]
import core_control as cc
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
source=json.loads((OLD/'aux-action-alias-verified.json').read_bytes());plan=json.loads((OLD/'next-hint-budget-plan-private.json').read_bytes())
write_record(P/'plan.json',dict(plan,status='FROZEN_BEFORE_QUERY',input_source='aux-action-alias-verified.json',input_tier='source-exposed fixture; no population inference',source_revision='af48292d3384e5e819e1f29ab76ccd8bbb1db399'))
write_record(P/'input.json',source)
c=compile_ruleset_for_execution(deserialize_ruleset(json.dumps(source['ruleset'])));nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(source['game_record'])));before=cc.p.digest(s);actions=list(s.legal_actions());assert len(actions)==2
rows=[];start=time.perf_counter()
for i,nodes in enumerate(plan['nodes']):
 order=actions if i%2==0 else list(reversed(actions))
 for hint in order:
  cc.p.stopped()
  if time.perf_counter()-start>plan['whole_seconds']:
   rows.append(dict(nodes=nodes,hint=record_value(hint),kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
  engine=SemanticSearchEngine(c,nr,board_values=plan['values'],hand_values=plan['values'],tt_megabytes=0,ordering_cache_enabled=False)
  t=time.perf_counter();res=engine.search(s,SearchLimits(max_depth=3,max_nodes=nodes,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_order_hint=hint,root_window_pruning=True);seconds=time.perf_counter()-t
  assert cc.p.digest(s)==before
  row=dict(nodes_cap=nodes,hint=record_value(hint),kind='ACTUAL_QUERY',result=record_value(res),caller_seconds=seconds,pv_edges=cc.p.audit(s,nr,res),root_restored=True)
  rows.append(row);write_record(P/'results.json',dict(complete=False,rows=rows,queries=len(rows),games=0,training=0))
  print(nodes,hint.pattern_id,res.completed_depth,res.score,None if res.action is None else res.action.pattern_id,res.nodes,res.termination_reason,flush=True)
write_record(P/'results.json',dict(complete=True,rows=rows,queries=sum(x['kind']=='ACTUAL_QUERY'for x in rows),games=0,training=0,seconds=time.perf_counter()-start))