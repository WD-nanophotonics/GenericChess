"""Uniform new-legal-action teacher coverage control, no fitting or games."""
from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';sys.path[:0]=[str(R),str(P)]
from core_teacher import Material,SearchMetadataAdapter,stopped,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,AlphaBetaPlayer,SearchTuning,SearchLimits,record_value,write_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules

def main():
 old=json.loads((P/'finite-teacher-plan.json').read_bytes());cases=[];objects={}
 for case in old['cases']:
  d=json.loads((P/case['root']).read_bytes());raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));used={json.dumps(a,sort_keys=True)for a in case['hints']};candidates=[a for a in s.legal_actions()if json.dumps(record_value(a),sort_keys=True)not in used]
  def rank(a):return hashlib.sha256((str(case['seed'])+'|actioncoverage20261016|'+json.dumps(record_value(a),sort_keys=True)).encode()).hexdigest()
  selected=sorted(candidates,key=rank)[:16];cases.append(dict(seed=case['seed'],board=case['board'],root=case['root'],available_nonprior_actions=len(candidates),actions=[record_value(a)for a in selected]));objects[case['seed']]=(d,c,nr)
 plan=dict(status='FROZEN_BEFORE_NEW_ACTION_LABELS',question='Did previous policy-selected actions overstate finite-teacher coverage? Test a label-independent hash sample of OTHER legal actions on the same complete-rule exposed parents.',cases=cases,selection='excludeALLprior22teacheractions; SHA256(seed|actioncoverage20261016|canonicalaction), firstmin16perroot beforeanynewquery, nooutcomereplacement',depth=3,nodes=65536,seconds=8,q=0,tt_mb=0,whole_seconds=1200,expected_seconds=600,max_queries=2*sum(len(c['actions'])for c in cases),scope='Exploratorynewactionlabels withinEXPOSED8parents, NOTfreshfamily/holdout/WDL. Allpromotion/drop/aux/history retained. ExistingCore/Nativeequalfiniteobjective, recordpartialnotD4. No learning/solver/game/capextension orchangedq/profile/default. Cheapalternative22selectedlabelsalreadyavailable; changedselection testscoveragebias, notunchangedreplication.')
 write_record(P/'action-coverage-plan.json',plan);rows=[];start=time.perf_counter()
 for case in cases:
  d,c,nr=objects[case['seed']]
  for i,ad in enumerate(case['actions']):
   stopped();s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));ac=next(x for x in s.legal_actions()if record_value(x)==ad);s.submit(ac);before=record_value(s.state)
   for backend in ('Core','Native')if i%2==0 else('Native','Core'):
    row=dict(seed=case['seed'],board=case['board'],action_index=i,action=ad,backend=backend)
    if time.perf_counter()-start>=1200:rows.append(dict(**row,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
    if s.state.terminal_status.is_terminal:rows.append(dict(**row,kind='ACTUAL_TERMINAL_CHILD',terminal=record_value(s.state.terminal_status)));continue
    stopped();t=time.perf_counter();limits=SearchLimits(max_depth=3,max_nodes=65536,max_time_seconds=8,quiescence_max_depth=0,quiescence_hard_max_depth=0)
    if backend=='Core':r=AlphaBetaPlayer(c,evaluator_override=Material(d['board_values'],d['hand_values']),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,limits)
    else:r=SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False).search(s,limits,root_window_pruning=True)
    elapsed=time.perf_counter()-t;assert record_value(s.state)==before;rows.append(dict(**row,kind='ACTUAL_QUERY',result=record_value(r),caller_seconds=elapsed,root_restored=True));write_record(P/'action-coverage-progress.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start));print('ACTION_COVERAGE',case['seed'],i,backend,r.completed_depth,round(elapsed,3),flush=True)
 write_record(P/'action-coverage-results.json',dict(complete=True,rows=rows,queries=sum(x['kind']=='ACTUAL_QUERY'for x in rows),slots=len(rows),games=0,training=0,seconds=time.perf_counter()-start,scope=plan['scope']))
 print('ACTION_COVERAGE_CLOSED',len(rows),time.perf_counter()-start,flush=True)
if __name__=='__main__':main()