from pathlib import Path
import sys,sysconfig,subprocess,shutil,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';S=P/'compact-profile-source';S.mkdir(exist_ok=False)
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
s=(S/'native_module.c').read_text(encoding='utf-8-sig');mark='static int gc_semantic_compact_residual('
i=s.index(mark);s=s[:i]+'static uint64_t private_compact_ns=0, private_compact_dynamic_ns=0, private_compact_dense_ns=0, private_compact_calls=0;\n'+s[i:]
i=s.index(mark,s.index(mark)+1);j=s.index('static int gc_semantic_spatial_feature_vector(',i);part=s[i:j]
old='    const GCSemanticCompactModel *model = profile->compact;';assert part.count(old)==1;part=part.replace(old,old+'\n    uint64_t private_start=gc_monotonic_ns(); private_compact_calls++;')
old='''    } else if (!gc_semantic_dynamic_feature_vector(rules, position, dynamic)) {
        return 0;
    }''';assert part.count(old)==1
part=part.replace(old,'''    } else {
        uint64_t t=gc_monotonic_ns();
        int ok=gc_semantic_dynamic_feature_vector(rules, position, dynamic);
        private_compact_dynamic_ns+=gc_monotonic_ns()-t;
        if(!ok)return 0;
    }''')
part=part.replace('    double hidden[32];','    uint64_t private_dense_start=gc_monotonic_ns();\n    double hidden[32];')
old='    *out = result * model->target_scale;';assert part.count(old)==1;part=part.replace(old,old+'\n    private_compact_dense_ns+=gc_monotonic_ns()-private_dense_start;\n    private_compact_ns+=gc_monotonic_ns()-private_start;')
s=s[:i]+part+s[j:];old='static PyObject *gc_semantic_engine_search(PyObject *self, PyObject *args) {';assert s.count(old)==1;s=s.replace(old,old+'\n    private_compact_ns=private_compact_dynamic_ns=private_compact_dense_ns=private_compact_calls=0;')
old='        gc_semantic_set_u64(out, "ordering_cache_hits", cache_hits) != 0 ||';assert s.count(old)==1
s=s.replace(old,''.join('        gc_semantic_set_u64(out, "'+k+'", '+k+') != 0 ||\n'for k in('private_compact_ns','private_compact_dynamic_ns','private_compact_dense_ns','private_compact_calls'))+old);(S/'native_module.c').write_bytes(s.encode())
plan=dict(question='Does existing compact leaf cost come from derived semantic features or width16 dense inference?',source_sha256=hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),cases=[c for c in json.loads((P/'finite-teacher-plan.json').read_bytes())['cases']if c['board']<16],width=16,repetitions=2,arms=['normal','private_counter'],depth=2,nodes=4096,seconds=None,whole_seconds=180,expected_seconds=45,max_queries=24,scope='Attributiononly, untrainedzero-outputpayloadsamefunctional; privateownedCaddsclocks/counters ONLY, no optimization orproduct/AUXchange. Timerbiasedsubsetfractionsnotfullpartition; compareallnon-timefields.')
(P/'compact-profile-plan.json').write_bytes((json.dumps(plan,indent=2)+'\n').encode());cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/'compact_profile_native_core.pyd')];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);out=dict(returncode=r.returncode,seconds=time.perf_counter()-t,command=cmd,stdout=r.stdout.decode(errors='replace'),stderr=r.stderr.decode(errors='replace'),source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()});(P/'compact-profile-build-private.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print('COMPACT_PROFILE_BUILD',r.returncode,out['seconds'],out['stderr'][-1000:],flush=True);sys.exit(r.returncode)