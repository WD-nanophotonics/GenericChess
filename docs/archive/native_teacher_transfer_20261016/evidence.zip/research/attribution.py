from pathlib import Path
import json,sys,time
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';sys.path.insert(0,str(R))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine,_module
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
plan=dict(question='Why does better finite-Q root hint need more work: actual root tie refinements or failedhint?',cases=[dict(window=w,hint=h)for w in(True,False)for h in('sem_01_aV','sem_02_aU')],depth=3,nodes=128,seconds=1,tt=0,q=0,max_queries=4,whole_seconds=20,scope='Changedquestion/counters onexposedfixture, NOTextend10curve/learnedcost/population claim')
write_record(P/'attribution-plan.json',plan)
d=json.loads((P/'input.json').read_bytes());values=json.loads((P/'plan.json').read_bytes())['values'];c=compile_ruleset_for_execution(deserialize_ruleset(json.dumps(d['ruleset'])));nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));module=_module();original=module.semantic_engine_search;observed=[]
def tap(*args,**kw):
 raw=original(*args,**kw);observed.append(record_value(dict(raw)));return raw
module.semantic_engine_search=tap
rows=[];start=time.perf_counter()
try:
 for case in plan['cases']:
  if time.perf_counter()-start>20:raise TimeoutError('Attributionwholecap')
  hint=next(a for a in s.legal_actions()if a.pattern_id==case['hint']);e=SemanticSearchEngine(c,nr,board_values=values,hand_values=values,tt_megabytes=0,ordering_cache_enabled=False)
  result=e.search(s,SearchLimits(max_depth=3,max_nodes=128,max_time_seconds=1,quiescence_max_depth=0),root_order_hint=hint,root_window_pruning=case['window'])
  raw=observed[-1];rows.append(dict(case=case,result=record_value(result),raw=raw));print(case,result.nodes,result.score,result.action.pattern_id,raw['root_tie_refinements'],flush=True)
finally:module.semantic_engine_search=original
write_record(P/'attribution-results.json',dict(complete=True,rows=rows,queries=len(rows),games=0,training=0,seconds=time.perf_counter()-start,scope=plan['scope']))