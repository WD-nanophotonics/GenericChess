from pathlib import Path
import json,collections,itertools,statistics
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';d=json.loads((P/'finite-teacher-results.json').read_bytes());rows=d['rows'];teachers={(r['seed'],r['hint_index']):r for r in rows if r['phase']=='teacher'};roots=[r for r in rows if r['phase']=='root'];base={(r['seed'],r['nodes_cap']):r for r in roots if r['hint_index']==-1};pairs=[]
for r in roots:
 if r['hint_index']<0:continue
 b=base[r['seed'],r['nodes_cap']];a=r['result'];z=b['result'];t=teachers[r['seed'],r['hint_index']]
 pairs.append(dict(seed=r['seed'],nodes_cap=r['nodes_cap'],hint_index=r['hint_index'],teacher_complete=t['result']['completed_depth']==5,finite_q=t['finite_root_q'],retained_depth_delta=a['completed_depth']-z['completed_depth'],same_action=a['action']==z['action'],same_score=a['score']==z['score'],both_D6=a['completed_depth']==z['completed_depth']==6,nodes=a['nodes'],baseline_nodes=z['nodes'],node_ratio=a['nodes']/z['nodes']if z['nodes']else None,caller_ratio=r['caller_seconds']/b['caller_seconds']if b['caller_seconds']else None,tie_refinements=r['raw_counters']['root_tie_refinements'],baseline_tie_refinements=b['raw_counters']['root_tie_refinements']))
qpairs=[]
for seed in sorted({x[0]for x in teachers}):
 ts=[t for (s,i),t in teachers.items()if s==seed and t['finite_root_q']is not None]
 for a,b in itertools.combinations(ts,2):
  if a['finite_root_q']==b['finite_root_q']:continue
  better,worse=(a,b)if a['finite_root_q']>b['finite_root_q']else(b,a)
  for nodes in(512,4096,65536):
   x=next(r for r in roots if(r['seed'],r['hint_index'],r['nodes_cap'])==(seed,better['hint_index'],nodes));y=next(r for r in roots if(r['seed'],r['hint_index'],r['nodes_cap'])==(seed,worse['hint_index'],nodes));xr=x['result'];yr=y['result'];joint=xr['completed_depth']==yr['completed_depth']==6
   qpairs.append(dict(seed=seed,nodes_cap=nodes,better_hint=better['hint_index'],worse_hint=worse['hint_index'],finite_q_gap=better['finite_root_q']-worse['finite_root_q'],retained_depth_delta=xr['completed_depth']-yr['completed_depth'],both_D6=joint,better_nodes=xr['nodes'],worse_nodes=yr['nodes'],better_fewer_nodes=xr['nodes']<yr['nodes']if joint else None))
out=dict(complete=True,new_queries=112,teacher_queries=22,root_queries=90,teacher_complete=11,teacher_partial=11,teacher_completion_by_board={str(b):collections.Counter(t['result']['completed_depth']for t in teachers.values()if t['seed']//100%10==b//4)for b in()},pairs=pairs,complete_finite_Q_pairs=qpairs,scope='Exploratory eight exposedparents, dependenthintcomparisons. FiniteD6Q onlyifchildD5complete; partialscoresneverD6, actionQsubset notallactions/WDL. All90rootoutputs retainrequested-vsactualdepth/caps; depthalone notstrength.')
(P/'finite-teacher-analysis.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
print('PAIRS',len(pairs),collections.Counter('deeper'if x['retained_depth_delta']>0 else'shallower'if x['retained_depth_delta']<0 else'same'for x in pairs))
for nodes in(512,4096,65536):
 ps=[x for x in pairs if x['nodes_cap']==nodes];print('BUDGET',nodes,'depth',collections.Counter(x['retained_depth_delta']for x in ps),'changedactions',sum(not x['same_action']for x in ps),'jointD6',sum(x['both_D6']for x in ps))
print('QPAIRS',len(qpairs),collections.Counter((x['nodes_cap'],x['retained_depth_delta'])for x in qpairs))
print('JOINT_D6_PAIRS',[(x['seed'],x['hint_index'],round(x['node_ratio'],3),x['finite_q'],x['tie_refinements'])for x in pairs if x['both_D6']])
print('TEACHERS',[(s,i,t['result']['completed_depth'],t['finite_root_q'],round(t['caller_seconds'],3))for(s,i),t in teachers.items()])