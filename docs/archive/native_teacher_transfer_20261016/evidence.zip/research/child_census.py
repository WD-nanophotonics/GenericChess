"""One-ply semantic redundancy census on frozen exposed roots, no search or fit."""
from pathlib import Path
import sys,json,time,hashlib,collections
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';sys.path[:0]=[str(R),str(P)]
from core_teacher import SearchMetadataAdapter,stopped,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,record_value,write_record
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import position_identity_key
from generic_chess.learning.policy_v1 import action_v1_components
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action,expected_snapshot
from generic_chess.native import semantic as sem

def main():
 old=json.loads((P/'finite-teacher-plan.json').read_bytes());plan=dict(question='Do distinct/neural-distinguishable legal action patterns sometimes yield the exact same full child, unlike the opposite V1 aux alias?',roots=[dict(seed=x['seed'],root=x['root'])for x in old['cases']],all_legal=True,whole_seconds=120,expected_seconds=15,scope='Posthoc8exposedroots/all846legalactions; diagnostictransitions notgames. FullCorestate/historygrouping, allNativechildrenchecked. Notuniversalredundancyfrequency, permissiontodeduportruncate, searchspeed orNNquality.')
 write_record(P/'child-census-plan.json',plan);start=time.perf_counter();rows=[]
 for case in plan['roots']:
  stopped();d=json.loads((P/case['root']).read_bytes());raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));np0=pack_semantic_search_position(c,nr,s);groups={};actions=[]
  for ac in s.legal_actions():
   stopped()
   if time.perf_counter()-start>120:raise TimeoutError('Wholecensuscap')
   child=apply_action(s.state,ac,c);body=json.dumps(record_value(child),sort_keys=True);sha=hashlib.sha256(body.encode()).hexdigest();base,cats=action_v1_components(c,s.state.position,ac);vec=json.dumps(dict(base=base.tolist(),categories=list(cats)),sort_keys=True);vf=hashlib.sha256(vec.encode()).hexdigest();packed=pack_semantic_action(nr,s.state.position,ac);np1=sem.make_checked(nr,np0,packed);snap=sem.snapshot(nr,np1);want=expected_snapshot(child.position,nr,c)
   for k in('board','hands','aux_state','side'):assert record_value(snap[k])==record_value(want[k])
   assert snap['ply']==child.ply_count
   assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(p,c))for p in list(s._search_witnesses)+[child.position]]
   assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in child.history)
   assert sem.terminal_status(nr,np1)==dict(status=child.terminal_status.status.value,winner=child.terminal_status.winner)
   item=dict(action=record_value(ac),native_packed=int(packed),child_sha256=sha,v1_sha256=vf);actions.append(item)
   if sha in groups:assert groups[sha]['body']==body
   else:groups[sha]=dict(body=body,actions=[])
   groups[sha]['actions'].append(item)
  duplicates=[dict(child_sha256=sha,actions=g['actions'],child=json.loads(g['body']))for sha,g in groups.items()if len(g['actions'])>1];rows.append(dict(**case,legal_count=len(actions),unique_children=len(groups),duplicate_branches=len(actions)-len(groups),duplicate_groups=duplicates,actions=actions));print('CHILD_CENSUS',case['seed'],len(actions),len(groups),len(duplicates),flush=True)
 write_record(P/'child-census-results.json',dict(complete=True,rows=rows,diagnostic_transitions=sum(r['legal_count']for r in rows),queries=0,games=0,training=0,seconds=time.perf_counter()-start,scope=plan['scope']))
if __name__=='__main__':main()