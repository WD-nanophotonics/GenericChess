from pathlib import Path
import json,sys,time
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';sys.path[:0]=[str(R),str(P)]
from core_teacher import Material,SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,AlphaBetaPlayer,SearchTuning,SearchLimits,record_value,write_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
w=json.loads((P/'rename-work-analysis.json').read_bytes());changed=[r for r in w['rows']if not r['literal_action_equal']];assert len(changed)==1;row=changed[0];seed=row['seed'];m=next(r for r in json.loads((P/'rename-contract-map-results.json').read_bytes())['rows']if r['seed']==seed);rr=next(r for r in json.loads((P/'rename-results.json').read_bytes())['rows']if r['seed']==seed);inv={v:k for k,v in rr['mapping'].items()};pm={v:k for k,v in m['pattern_map'].items()};gm={v:k for k,v in m['geometry_map'].items()};ad=dict(row['target_action']);ad['pattern_id']=pm[ad['pattern_id']];ad['geometry_id']=gm[ad['geometry_id']]
for k in('actor_type_id','base_type_id','promotion_target_id'):
 if ad.get(k)is not None:ad[k]=inv[ad[k]]
actions=[rr['search'][0]['action'],ad];plan=dict(question='Is the one changed cosmeticD2choice a finite tie or actual value discrepancy?',seed=seed,actions=actions,depth=1,nodes=4096,seconds=1,max_queries=4,whole_seconds=10,scope='Posthoconechangedchoiceamong8cosmeticpairs; all-Core/Native exactfiniteoneplychildren, notWDL orpopulation/strongtransfer.')
write_record(P/'rename-tie-plan.json',plan);d=json.loads((P/f'roots/{seed}.json').read_bytes());raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=compile_native_semantic_rules(c);rows=[];start=time.perf_counter()
for i,action in enumerate(actions):
 s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));a=next(a for a in s.legal_actions()if record_value(a)==action);s.submit(a)
 for backend in('Core','Native'):
  limits=SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0)
  if backend=='Core':r=AlphaBetaPlayer(c,evaluator_override=Material(d['board_values'],d['hand_values']),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,limits)
  else:r=SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False).search(s,limits,root_window_pruning=True)
  assert r.completed_depth==1;rows.append(dict(seed=seed,action_index=i,action=action,backend=backend,result=record_value(r),child_state=record_value(s.state),finite_root_q=-r.score));print('RENAME_TIE',i,backend,-r.score,flush=True)
assert len({r['finite_root_q']for r in rows})==1
write_record(P/'rename-tie-results.json',dict(complete=True,rows=rows,queries=4,games=0,training=0,seconds=time.perf_counter()-start,scope=plan['scope']))