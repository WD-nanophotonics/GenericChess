"""Structural feature-update census; recomputed deltas, NOT incremental NNUE."""
from pathlib import Path
import sys,json,time,collections,hashlib,statistics
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';sys.path[:0]=[str(R),str(P)]
from core_teacher import SearchMetadataAdapter,stopped,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,record_value,write_record
from scripts.position_features import SparsePositionEncoder
from generic_chess.core.transition import apply_action

def abs_features(enc,p):
 i,v=enc.encode(p,(0,0,0));return {int(a):float(b)for a,b in zip(i,v)}
def king_features(compiled,p):
 anchors={t.type_id for t in compiled.piece_types if t.is_anchor};loc=collections.defaultdict(list);n=p.board_size()
 for i,x in enumerate(p.board):
  if x is not None and x.current_type_id in anchors:loc[x.owner].append(i)
 if len(loc[0])!=1 or len(loc[1])!=1:return None,None
 a,b=loc[0][0],loc[1][0];kk={('kingking',a,b):1.0};rel={}
 for owner in(0,1):
  anchor=loc[owner][0];ax,ay=anchor%n,anchor//n
  for i,x in enumerate(p.board):
   if x is None:continue
   token=('kingpiece',owner,x.owner,x.current_type_id,x.base_type_id,bool(x.promoted),i%n-ax,i//n-ay);rel[token]=rel.get(token,0)+1.0
 return kk,rel

def delta(a,b):return sum(a.get(k,0)!=b.get(k,0)for k in a.keys()|b.keys())
def main():
 old=json.loads((P/'finite-teacher-plan.json').read_bytes());census=json.loads((P/'child-census-results.json').read_bytes());cs={x['seed']:x for x in census['rows']};plan=dict(question='Before choosing king-relative interactions, how much sparse first-layer update opportunity remains when anchors move under actual generated rules?',roots=old['cases'],distribution='all846legaloneplyalternatives on8EXPOSEDroots; uniformperroot summary, notplayedmovefrequency/population',features='existingabsoluteSparsePosition zerodynamic, plus symbolickingking or bothowneranchor-relative current/base/promoted actorcounts. Keepabsolutehands/aux; Positiononlyhistorynotencoded.',whole_seconds=120,expected_seconds=10,scope='0search/game/training. DeltasfromTWO fullrecomputations, NOTfastincrementalextractor/inference/speedclaim. Exactlyoneanchorperowner scope checked; genericfulltargetnotredefined.')
 write_record(P/'feature-delta-plan.json',plan);rows=[];start=time.perf_counter()
 for case in old['cases']:
  stopped();d=json.loads((P/case['root']).read_bytes());raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));enc=SparsePositionEncoder(c);f0=abs_features(enc,s.state.position);k0,r0=king_features(c,s.state.position);assert k0 is not None;known={json.dumps(x['action'],sort_keys=True):x['child_sha256']for x in cs[case['seed']]['actions']};anchors={t.type_id for t in c.piece_types if t.is_anchor};items=[]
  for ac in s.legal_actions():
   stopped()
   if time.perf_counter()-start>120:raise TimeoutError('Wholecap')
   child=apply_action(s.state,ac,c);sha=hashlib.sha256(json.dumps(record_value(child),sort_keys=True).encode()).hexdigest();assert known[json.dumps(record_value(ac),sort_keys=True)]==sha;f=abs_features(enc,child.position);k,r=king_features(c,child.position);assert k is not None
   anchor_move=getattr(ac,'actor_type_id',None)in anchors;items.append(dict(action=record_value(ac),child_sha256=sha,anchor_move=anchor_move,drop=hasattr(ac,'base_type_id'),promotion=getattr(ac,'promotion_target_id',None)is not None,absolute_active_before=len(f0),absolute_active_after=len(f),absolute_delta=delta(f0,f),kingking_delta=delta(k0,k),relative_active_before=len(r0),relative_active_after=len(r),relative_delta=delta(r0,r),relative_augmentation_delta_fraction=delta(r0,r)/max(1,len(r))))
  row=dict(seed=case['seed'],dimension=enc.dimension,rows=items);rows.append(row);print('DELTA',case['seed'],len(items),sum(x['anchor_move']for x in items),statistics.median(x['absolute_delta']for x in items),statistics.median(x['relative_delta']for x in items),flush=True)
 write_record(P/'feature-delta-results.json',dict(complete=True,rows=rows,diagnostic_transitions=sum(len(r['rows'])for r in rows),queries=0,games=0,training=0,seconds=time.perf_counter()-start,scope=plan['scope']))
if __name__=='__main__':main()