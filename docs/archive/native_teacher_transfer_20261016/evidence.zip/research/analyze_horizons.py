from pathlib import Path
import json,itertools,collections,statistics
P=Path('.local_agent/alias-teacher-20261016');h=json.loads((P/'horizon-results.json').read_bytes());t=json.loads((P/'finite-teacher-results.json').read_bytes());co=json.loads((P/'core-teacher-results.json').read_bytes())
def native_units(score,backend):
 if backend=='Core'and abs(score)>50000000:return (1 if score>0 else-1)*(100000000-(1000000000-abs(score)))
 return score
def parent_q(score):
 q=-score;return q-1 if q>50000000 else q+1 if q< -50000000 else q
checks=[];target={};by={(r['seed'],r['hint_index'],r['depth'],r['backend']):r for r in h['rows']}
for r in h['rows']:
 if r['backend']!='Native':continue
 key=r['seed'],r['hint_index'],r['depth'];c=by[(*key,'Core')];n=r['result'];z=c['result'];complete=n['completed_depth']==z['completed_depth']==r['depth']
 if complete:assert n['score']==native_units(z['score'],'Core')
 checks.append(dict(seed=r['seed'],hint_index=r['hint_index'],child_depth=r['depth'],joint_complete=complete,native_depth=n['completed_depth'],core_depth=z['completed_depth'],score_equal=True if complete else None))
 if n['completed_depth']==r['depth']:target[(r['seed'],r['hint_index'],r['depth']+1)]=parent_q(n['score'])
for r in t['rows']:
 if r['phase']=='teacher'and r['finite_root_q']is not None:target[r['seed'],r['hint_index'],6]=r['finite_root_q']
extra=[]
for c in co['rows']:
 key=c['seed'],c['hint_index'];z=c['result'];d=z['completed_depth'];n=next(r for r in t['rows']if r['phase']=='teacher'and(r['seed'],r['hint_index'])==key)
 if d==n['result']['completed_depth']:
  assert native_units(z['score'],'Core')==n['result']['score'];extra.append(dict(seed=key[0],hint_index=key[1],depth=d,scope='D5requestsameactualdepth',score_equal=True))
 elif d==3:
  nr=by[(*key,3,'Native')];assert nr['result']['completed_depth']==3 and native_units(z['score'],'Core')==nr['result']['score'];extra.append(dict(seed=key[0],hint_index=key[1],depth=d,scope='CoreD5requestretainedD3vsseparateNativeD3',score_equal=True))
contrasts=[]
for seed in sorted({k[0]for k in target}):
 ids=sorted({k[1]for k in target if k[0]==seed})
 for a,b in itertools.combinations(ids,2):
  for low,high in((2,4),(4,6),(2,6)):
   keys=[(seed,a,low),(seed,b,low),(seed,a,high),(seed,b,high)]
   if any(k not in target for k in keys):continue
   x=target[keys[0]]-target[keys[1]];y=target[keys[2]]-target[keys[3]];kind='STRICT_REVERSAL'if x*y<0 else'TIE_CHANGED'if(x==0)!=(y==0)else'SAME_ORDER_OR_TIE';contrasts.append(dict(seed=seed,action_pair=[a,b],horizons=[low,high],lower_gap=x,higher_gap=y,kind=kind))
out=dict(complete=True,joint_checks=checks,additional_retained_horizon_checks=extra,finite_targets=[dict(seed=k[0],hint_index=k[1],root_horizon=k[2],q=v)for k,v in sorted(target.items())],pair_contrasts=contrasts,scope='Dependent exploratorywithin8exposedfamilies, partialscoresneverrequestedhorizon, finiteQnotWDL orlearnability/performance. Reversalsmotivateprovenance, notrequiringexactQfit/forcingdepthinputAPI.')
(P/'horizon-analysis.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print('JOINT',sum(x['joint_complete']for x in checks),'of',len(checks),'extra',len(extra));print('CONTRASTS',collections.Counter((tuple(x['horizons']),x['kind'])for x in contrasts));print('FLIPS',[(x['seed'],x['action_pair'],x['horizons'],x['lower_gap'],x['higher_gap'])for x in contrasts if x['kind']=='STRICT_REVERSAL'])
f=json.loads((P/'feature-delta-results.json').read_bytes());allrows=[x for r in f['rows']for x in r['rows']];print('FEATUREDELTA',len(allrows),'anchors',sum(x['anchor_move']for x in allrows),'drops',sum(x['drop']for x in allrows),'promotions',sum(x['promotion']for x in allrows))
for a in(False,True):
 xs=[x for x in allrows if x['anchor_move']==a];print('ANCHOR',a,len(xs),'abs',statistics.median(x['absolute_delta']for x in xs),'rel',statistics.median(x['relative_delta']for x in xs),'relfraction',statistics.median(x['relative_augmentation_delta_fraction']for x in xs))