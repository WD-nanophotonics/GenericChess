"""Post-hoc mapping diagnosis, not another search or learned transfer."""
from pathlib import Path
import json,runpy,dataclasses,time
P=Path('.local_agent/alias-teacher-20261016');ns=runpy.run_path(str(P/'rename_control.py'),run_name='inspect_only');rv=ns['record_value'];ren=ns['renamed'];data=json.loads((P/'rename-results.json').read_bytes());rows=[];start=time.perf_counter()
for old in data['rows']:
 d=json.loads((P/old['root']).read_bytes());c=ns['compile'](d['ruleset']);cr=ns['compile'](old['renamed_ruleset']);m=old['mapping'];inv={v:k for k,v in m.items()};target_names={p.name:p for p in cr.ir.patterns};pm={};gm={};contract_checks=0
 for p in c.ir.patterns:
  name=p.name
  for a,b in m.items():
   if name.startswith('legacy_'+a+'_'):name='legacy_'+b+'_'+name[len('legacy_'+a+'_'):];break
  t=target_names[name];pm[p.pattern_id]=t.pattern_id
  assert len(p.geometry_ids)==len(t.geometry_ids)
  for a,b in zip(p.geometry_ids,t.geometry_ids):
   ga=rv(c.ir.geometry[a]);gb=rv(cr.ir.geometry[b]);ga.pop('geometry_id',None);gb.pop('geometry_id',None);assert ren(ga,m)==gb
   if a in gm:assert gm[a]==b
   gm[a]=b
  a=ren(rv(p),m);b=rv(t)
  for k in('pattern_id','name','geometry_ids','replaced_pattern_ids'):a.pop(k);b.pop(k)
  assert a==b;contract_checks+=1
 def map_ac(ac):
  out=dataclasses.replace(ac,pattern_id=pm[ac.pattern_id],geometry_id=gm[ac.geometry_id])
  if hasattr(out,'actor_type_id'):return dataclasses.replace(out,actor_type_id=m[ac.actor_type_id],promotion_target_id=None if ac.promotion_target_id is None else m[ac.promotion_target_id])
  return dataclasses.replace(out,base_type_id=m[ac.base_type_id])
 s=ns['GameSession'](c);sr=ns['GameSession'](cr)
 for ac in ns['deserialize_game_record'](json.dumps(d['game_record'])).actions:
  ar=map_ac(ac);assert ar in sr.legal_actions();s.submit(ac);sr.submit(ar);assert ns['pos'](s.state.position,{})==ns['pos'](sr.state.position,inv)
 acts=list(s.legal_actions());targets=list(sr.legal_actions());assert set(map_ac(a)for a in acts)==set(targets)
 source_types=tuple(sorted(c.support.type_metadata));target_types=tuple(sorted(cr.support.type_metadata));ix={t:i for i,t in enumerate(target_types)};nt=len(source_types)
 for a in acts:
  ar=map_ac(a);v,k=ns['action_v1_components'](c,s.state.position,a);vr,kr=ns['action_v1_components'](cr,sr.state.position,ar);expected=tuple(ix[m[source_types[i]]]if i<nt else nt for i in k[:3])+(k[3],);assert ns['np'].array_equal(v,vr)and kr==expected
 rows.append(dict(seed=old['seed'],pattern_contracts=contract_checks,legal_action_bijection=len(acts),pattern_map=pm,geometry_map=gm,v1_base_and_permuted_categories_equal=True,prior_successor_only_mismatches=len(old['v1_base_differences'])));print('CONTRACT_MAP',old['seed'],contract_checks,len(acts),flush=True)
out=dict(complete=True,rows=rows,seconds=time.perf_counter()-start,queries=0,games=0,training=0,scope='Posthocdiagnosisof4succ-onlymapcollisions. Existinglegacycompiler names identifycorrespondingpatterns, completecontract/geometrycomparison verifies8specificmaps. Actualbijection846legalactions/fullprefix/V1features. No newNativequery/learner/genericmapper or strategictransferclaim; alloriginalfailures retained.')
(P/'rename-contract-map-results.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())