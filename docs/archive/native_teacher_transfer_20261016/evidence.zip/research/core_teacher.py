from pathlib import Path
import sys,json,time
R=Path.cwd();sys.path.insert(0,str(R));P=R/'.local_agent/alias-teacher-20261016'
from scripts.research_record import record_value,write_record
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.reserve_refresh_diagnostic import stopped
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
class Material:
 def __init__(self,bv,hv):self.bv=bv;self.hv=hv
 def evaluate(self,s):
  owner=s.position.side_to_move
  return sum((1 if x.owner==owner else -1)*self.bv[x.current_type_id]for x in s.position.board if x is not None)+sum((1 if o==owner else -1)*self.hv[t]*n for o,h in enumerate(s.position.hands)for t,n in h.items())
 def type_value(self,t):return self.bv[t]
 def capture_order_value(self,m,c):return 10*self.bv[c.current_type_id]-self.bv[m.current_type_id]
def main():
 native=json.loads((P/'finite-teacher-results.json').read_bytes());old=json.loads((P/'finite-teacher-plan.json').read_bytes());cases={x['seed']:x for x in old['cases']};selected=[x for x in native['rows']if x['phase']=='teacher'];assert len(selected)==22
 plan=dict(question='Does an independent existing all-Core search validate complete Native finiteD6 subsetlabels, and what does equal262144nodes/32s actually cost/complete?',source='finite-teacher-plan.json / finite-teacher-results.json',slots=[dict(seed=x['seed'],hint_index=x['hint_index'],action=x['action'])for x in selected],depth=5,nodes=262144,seconds=32,whole_seconds=800,expected_seconds=600,scope='Independentsearchalgorithm/sharedCoresemantics, fullrecords/promotion/drop retained. Notnewsolver/WDL/strongteacher/games/training. Compareonlybothcomplete; partialscoresnotD6labels. Samecaps asNative; no result-driven extension.')
 write_record(P/'core-teacher-plan.json',plan);start=time.perf_counter();rows=[];cache={}
 for slot in plan['slots']:
  stopped();case=cases[slot['seed']];d=json.loads((P/case['root']).read_bytes())
  if slot['seed']not in cache:
   raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));cache[slot['seed']]=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
  c=cache[slot['seed']];s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));ac=next(a for a in s.legal_actions()if record_value(a)==slot['action']);s.submit(ac)
  if time.perf_counter()-start>=800:rows.append(dict(**slot,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
  if s.state.terminal_status.is_terminal:rows.append(dict(**slot,kind='ACTUAL_TERMINAL_CHILD'));continue
  before=record_value(s.state);print('CORE_TEACHER_START',slot['seed'],slot['hint_index'],flush=True);t=time.perf_counter()
  r=AlphaBetaPlayer(c,evaluator_override=Material(d['board_values'],d['hand_values']),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,SearchLimits(max_depth=5,max_nodes=262144,max_time_seconds=32,quiescence_max_depth=0,quiescence_hard_max_depth=0));sec=time.perf_counter()-t;assert record_value(s.state)==before
  row=dict(**slot,kind='ACTUAL_QUERY',result=record_value(r),caller_seconds=sec,root_restored=True);rows.append(row);write_record(P/'core-teacher-progress.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start));print('CORE_TEACHER_DONE',slot['seed'],slot['hint_index'],r.completed_depth,r.score,round(sec,3),flush=True)
 write_record(P/'core-teacher-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,queries=sum(x['kind']=='ACTUAL_QUERY'for x in rows),games=0,training=0,scope=plan['scope']))
if __name__=='__main__':main()