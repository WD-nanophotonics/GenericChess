import json
from pathlib import Path
P=Path('.local_agent/alias-teacher-20261016');d=json.loads((P/'rename-results.json').read_bytes());maps={r['seed']:r for r in json.loads((P/'rename-contract-map-results.json').read_bytes())['rows']};rows=[]
for r in d['rows']:
 a,b=r['search'];mp=maps[r['seed']];x=dict(a['action']);x['pattern_id']=mp['pattern_map'][x['pattern_id']];x['geometry_id']=mp['geometry_map'][x['geometry_id']]
 for k in('actor_type_id','base_type_id','promotion_target_id'):
  if x.get(k)is not None:x[k]=r['mapping'][x[k]]
 row=dict(seed=r['seed'],source_nodes=a['nodes'],target_nodes=b['nodes'],ratio=b['nodes']/a['nodes'],both_depth2=a['completed_depth']==b['completed_depth']==2,score_equal=a['score']==b['score'],contract_mapped_source_action=x,target_action=b['action'],literal_action_equal=x==b['action']);rows.append(row);print('RENAME_WORK',r['seed'],a['nodes'],b['nodes'],row['literal_action_equal'])
out=dict(complete=True,rows=rows,queries=0,games=0,training=0,scope='Derivativeof16actualD2queries, canonicalorder/work maydependonrenamedIDs. Equalfiniteobjectives notuniqueaction/no-costtransfer; no newqueries orstrategy-strength claim.')
(P/'rename-work-analysis.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())