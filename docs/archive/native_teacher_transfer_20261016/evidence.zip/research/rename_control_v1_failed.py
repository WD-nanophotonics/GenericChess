"""Cosmetic type-renaming control, not cross-rule learned transfer."""
from pathlib import Path
import sys,json,time,hashlib,copy
import numpy as np
R=Path.cwd();sys.path.insert(0,str(R));P=R/'.local_agent/alias-teacher-20261016'
from scripts.research_record import record_value,write_record
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.position_features import SparsePositionEncoder
from scripts.reserve_refresh_diagnostic import stopped
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.learning.policy_v1 import action_v1_components
from generic_chess.native import SemanticSearchEngine,semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action,expected_snapshot
from generic_chess.core.transition import apply_action
from generic_chess.ai.limits import SearchLimits

def renamed(x,m):
 if isinstance(x,str):return m.get(x,x)
 if isinstance(x,list):return [renamed(v,m)for v in x]
 if isinstance(x,dict):return {m.get(k,k):renamed(v,m)for k,v in x.items()}
 return x

def compile(rs):
 r=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(rs)));return SearchMetadataAdapter(ir=r.ir,_legacy_compiled=r._legacy_compiled,support=r.support)
def key(a):return json.dumps(record_value(a),sort_keys=True)
def pos(p,m):
 d=renamed(record_value(p),m);d.pop('ruleset_fingerprint')
 for hand in d['hands']:hand['counts']=sorted(hand['counts'])
 return d

def physical(a,m):
 d=renamed(record_value(a),m)
 for k in ('pattern_id','geometry_id'):d.pop(k,None)
 return json.dumps(d,sort_keys=True)
def mapped_action(source,target,ac,m,inv):
 wanted=physical(ac,m);oldchild=apply_action(source.state,ac,source.compiled)
 candidates=[x for x in target.legal_actions()if physical(x,{})==wanted]
 good=[x for x in candidates if pos(oldchild.position,{})==pos(apply_action(target.state,x,target.compiled).position,inv)]
 if not good:raise AssertionError('No mechanically matching checked action')
 return sorted(good,key=repr)[0]

def main():
 fp=json.loads((P/'finite-teacher-plan.json').read_bytes());plan=dict(question='Can an explicit exact type-axis mapping preserve feature computation and complete-rule behavior under cosmetic renaming, without treating genuine rule changes as equivalent?',cases=[dict(seed=c['seed'],root=c['root'])for c in fp['cases']],mapping='reverse sortedtypeIDs T00...; compiledpattern/geometryIDs alsochange: mapactuallegalactions byphysicaltypedfields ANDcheckedchildagreement, replaycompletelegalprefix; newfingerprint binding retained',dynamic=[0,0,0],random_width=16,random_seed=20261016,child_indices='firsttwo/lasttwo repr-sorteduniquelegalactions perroot',native_depth=2,native_nodes=65536,native_seconds=4,whole_seconds=120,expected_seconds=15,scope='CosmeticbijectiveIDcontrol only; randomdiscardedinference,0training/solver/games. Notrule-change strategictransfer oruniversalincrementalNNUE.')
 write_record(P/'rename-plan.json',dict(plan,prequery_failure='Originaldirectpattern/geometryIDreuse rejectedbycheckedrecordreplay; correctedexplicitsemanticmapping beforeanysearch; v0sourcepreserved'));rows=[];start=time.perf_counter()
 for case in plan['cases']:
  stopped()
  if time.perf_counter()-start>120:raise TimeoutError('Wholecap')
  d=json.loads((P/case['root']).read_bytes());c=compile(d['ruleset']);types=tuple(sorted(c.support.type_metadata));m={t:f'T{len(types)-1-i:02d}'for i,t in enumerate(types)};inv={v:k for k,v in m.items()};rs=renamed(d['ruleset'],m);cr=compile(rs);rec=renamed(d['game_record'],m);rec['ruleset_fingerprint']=cr.ruleset_fingerprint
  s0=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));s=GameSession(c);sr=GameSession(cr)
  for ac in deserialize_game_record(json.dumps(d['game_record'])).actions:
   ar=mapped_action(s,sr,ac,m,inv);s.submit(ac);sr.submit(ar)
  assert record_value(s.state)==record_value(s0.state);rec=json.loads(serialize_game_record(sr.to_record()));assert pos(s.state.position,{})==pos(sr.state.position,inv);assert record_value(s.state.terminal_status)==record_value(sr.state.terminal_status)
  assert[(e.actor,e.gave_check)for e in s.state.history]==[(e.actor,e.gave_check)for e in sr.state.history]
  es=SparsePositionEncoder(c);et=SparsePositionEncoder(cr);n=es.shape.area;nt=len(types);mp=list(range(es.dimension))
  for o in(0,1):
   for i,t in enumerate(types):
    j=et.type_index[m[t]]
    for sq in range(n):
     mp[(o*nt+i)*n+sq]=(o*nt+j)*n+sq;mp[es.base_offset+(o*nt+i)*n+sq]=et.base_offset+(o*nt+j)*n+sq
    mp[es.hand_offset+o*nt+i]=et.hand_offset+o*nt+j
  a=es.dense(s.state.position,(0,0,0));b=et.dense(sr.state.position,(0,0,0));assert len(mp)==len(set(mp));mapped=np.zeros_like(a);mapped[mp]=a;assert np.array_equal(mapped,b)
  rng=np.random.default_rng(20261016);w=rng.normal(size=(16,len(a)));wr=np.zeros_like(w);wr[:,mp]=w;h=w@a;hr=wr@b;error=float(np.max(np.abs(h-hr)));assert error<1e-12
  legal=sorted(s.legal_actions(),key=repr);target=list(sr.legal_actions());assert sorted(physical(x,m)for x in legal)==sorted(physical(x,{})for x in target)
  checked=0
  for ac in legal:
   ar=mapped_action(s,sr,ac,m,inv);v,k=action_v1_components(c,s.state.position,ac);vr,kr=action_v1_components(cr,sr.state.position,ar);expected=tuple(et.type_index[m[types[i]]]if i<nt else nt for i in k[:3])+(k[3],);assert np.array_equal(v,vr)and expected==kr;checked+=1
  childrows=[];nr=compile_native_semantic_rules(c);nrr=compile_native_semantic_rules(cr)
  for i in sorted({0,1,len(legal)-2,len(legal)-1}):
   if i<0 or i>=len(legal):continue
   ac=legal[i];ar=mapped_action(s,sr,ac,m,inv);x=apply_action(s.state,ac,c);y=apply_action(sr.state,ar,cr);assert pos(x.position,{})==pos(y.position,inv)and record_value(x.terminal_status)==record_value(y.terminal_status)
   for sess,native,act,ch in((s,nr,ac,x),(sr,nrr,ar,y)):
    np0=pack_semantic_search_position(sess.compiled,native,sess);np1=sem.make_checked(native,np0,pack_semantic_action(native,sess.state.position,act));snapshot=sem.snapshot(native,np1);expected_snapshot0=expected_snapshot(ch.position,native,sess.compiled)
    for f in('board','hands','aux_state','side'):assert record_value(snapshot[f])==record_value(expected_snapshot0[f])
    assert sem.terminal_status(native,np1)==dict(status=ch.terminal_status.status.value,winner=ch.terminal_status.winner)
   childrows.append(dict(action=record_value(ac),mapped_action=record_value(ar),source_child=record_value(x),target_child=record_value(y)))
  search=[]
  for sess,native,bv,hv in((s,nr,d['board_values'],d['hand_values']),(sr,nrr,renamed(d['board_values'],m),renamed(d['hand_values'],m))):
   result=SemanticSearchEngine(sess.compiled,native,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False).search(sess,SearchLimits(max_depth=2,max_nodes=65536,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);search.append(record_value(result))
  joint=all(r['completed_depth']==2 for r in search)
  if joint:assert search[0]['score']==search[1]['score']
  row=dict(**case,mapping=m,renamed_ruleset=rs,renamed_record=rec,dimension=len(a),feature_permutation=mp,random_forward_max_error=error,legal_actions_checked=checked,child_rows=childrows,search=search,joint_complete=joint,scope=plan['scope']);rows.append(row);print('RENAME',case['seed'],checked,len(childrows),error,joint,search[0]['score'],search[1]['score'],flush=True)
 write_record(P/'rename-results.json',dict(complete=True,rows=rows,queries=16,games=0,training=0,seconds=time.perf_counter()-start,scope=plan['scope']))
if __name__=='__main__':main()