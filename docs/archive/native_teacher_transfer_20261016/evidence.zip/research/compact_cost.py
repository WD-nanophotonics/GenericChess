"""Existing Native compact residual cost only: exact zero output, no training."""
from pathlib import Path
import sys,json,time,hashlib,numpy as np
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';sys.path[:0]=[str(R),str(P)]
from core_teacher import SearchMetadataAdapter,stopped,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,SearchLimits,record_value,write_record
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules

def main():
 old=json.loads((P/'finite-teacher-plan.json').read_bytes());plan=dict(question='Does the existing Native width16/32 residual interface offer affordable inference on these complete-rule roots before any training or newNNUEengineering?',cases=old['cases'],arms=['baseline','width16_zero_residual','width32_zero_residual'],repetitions=2,depth=2,nodes=4096,seconds=1,tt_mb=0,q=0,whole_seconds=90,expected_seconds=20,max_slots=48,model='Untrainedrandomhiddenweights seed20261016width, finite normalization, outputweights/biasexactzero. Samebaselinevaluefunctional. No checkpoint orlearnedquality. CurrentNative4096inputlimit retained; recordactualrefusal, do NOTtruncateposition/rules orsilentlyfallback.',scope='Cost/compatibilityprobe, notstrength/learning/AUXmodeladoption. Existinginputomitsboardbase/history, approximationexplicit; fullrules/searchhistoryunchanged. Actualfeatureconstruction/denseinference/profilepathallcharged, noattributiontosizealone.')
 write_record(P/'compact-cost-plan.json',plan);(P/'compact-payloads').mkdir(exist_ok=True);rows=[];start=time.perf_counter()
 for case in plan['cases']:
  stopped();d=json.loads((P/case['root']).read_bytes());raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));before=record_value(s.state);dim=len(semantic_state_features(s.state.position,c,(0,0,0)));base_ids=sorted(t.type_id for t in c.piece_types);payloads={};creation={}
  for width in(16,32):
   t=time.perf_counter();rng=np.random.default_rng(20261016+width);payload=dict(input_mean=[0.0]*dim,input_scale=[1.0]*dim,target_scale=1.0,hidden_weights=rng.normal(0,.01,size=(width,dim)).tolist(),hidden_bias=[0.0]*width,output_weights=[0.0]*width,output_bias=0.0,width=width,hand_type_indices=[nr.type_ids.index(tid)for tid in base_ids]);payloads[width]=payload;creation[width]=time.perf_counter()-t
   write_record(P/'compact-payloads'/f"{case['seed']}-{width}.json",payload)
  for rep in range(2):
   arms=plan['arms']if rep==0 else list(reversed(plan['arms']))
   for arm in arms:
    stopped();row=dict(seed=case['seed'],board=case['board'],repetition=rep,arm=arm,dimension=dim)
    if time.perf_counter()-start>=90:rows.append(dict(**row,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
    width=16 if arm.startswith('width16')else 32 if arm.startswith('width32')else None;payload=payloads.get(width);t=time.perf_counter()
    try:e=SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],compact_values=payload,tt_megabytes=0,ordering_cache_enabled=False)
    except(ValueError,TypeError)as ex:
     rows.append(dict(**row,kind='ACTUAL_REFUSAL',error=type(ex).__name__+': '+str(ex),binding_seconds=time.perf_counter()-t));print('COMPACT_REFUSAL',case['seed'],arm,dim,str(ex),flush=True);continue
    bind=time.perf_counter()-t;t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);sec=time.perf_counter()-t;assert record_value(s.state)==before;rows.append(dict(**row,kind='ACTUAL_QUERY',payload=None if width is None else f"compact-payloads/{case['seed']}-{width}.json",payload_construction_seconds=creation.get(width,0),binding_seconds=bind,caller_seconds=sec,result=record_value(r),root_restored=True));write_record(P/'compact-cost-progress.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start));print('COMPACT',case['seed'],arm,rep,r.completed_depth,round(sec,4),flush=True)
 write_record(P/'compact-cost-results.json',dict(complete=True,rows=rows,queries=sum(r['kind']=='ACTUAL_QUERY'for r in rows),refusals=sum(r['kind']=='ACTUAL_REFUSAL'for r in rows),slots=len(rows),seconds=time.perf_counter()-start,games=0,training=0,scope=plan['scope']))
if __name__=='__main__':main()