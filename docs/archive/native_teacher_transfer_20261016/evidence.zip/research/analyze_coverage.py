from pathlib import Path
import json,collections,statistics
P=Path('.local_agent/alias-teacher-20261016');d=json.loads((P/'action-coverage-results.json').read_bytes());plan=json.loads((P/'action-coverage-plan.json').read_bytes());groups=collections.defaultdict(dict)
for r in d['rows']:groups[r['seed'],r['action_index']][r['backend']]=r
pairs=[]
for key,g in sorted(groups.items()):
 a,b=g['Core'],g['Native'];assert a['action']==b['action'];ca,na=a['result'],b['result'];joint=ca['completed_depth']==na['completed_depth']==3
 def normal(v):return (1 if v>0 else-1)*(100000000-(1000000000-abs(v)))if abs(v)>50000000 else v
 if joint:assert normal(ca['score'])==na['score']
 pairs.append(dict(seed=key[0],action_index=key[1],board=a['board'],core_depth=ca['completed_depth'],native_depth=na['completed_depth'],joint_complete=joint,score_equal=True if joint else None,core_seconds=a['caller_seconds'],native_seconds=b['caller_seconds'],caller_ratio=b['caller_seconds']/a['caller_seconds'],action=a['action']))
summary=[]
for board in(4,8,12,16):
 xs=[x for x in pairs if x['board']==board];summary.append(dict(board=board,actions=len(xs),native_complete=sum(x['native_depth']==3 for x in xs),core_complete=sum(x['core_depth']==3 for x in xs),all_joint_scores_equal=True,median_native_core_caller_ratio_on_joint=statistics.median(x['caller_ratio']for x in xs if x['joint_complete']),native_seconds=sum(x['native_seconds']for x in xs),core_seconds=sum(x['core_seconds']for x in xs)))
out=dict(complete=True,source_results='action-coverage-results.json',queries=d['queries'],seconds=d['seconds'],pairs=pairs,summary=summary,joint_complete=sum(x['joint_complete']for x in pairs),scope='Newlabel-independentactionsubset, exposedparents/unequalavailableactions. Noholdout/modeltraining/WDL, selectiondiffersfromprior22. Costratios conditionalonjointcompletion/sharedhost; allcensorskept.')
(P/'action-coverage-analysis.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(summary));print('JOINT',out['joint_complete'],'QUERIES',d['queries'],'SECONDS',d['seconds'])
f=P/'consumer_all.py';s=f.read_text();needle="for row in read('rename-results.json')['rows']:";addition="""for row in read('rename-tie-results.json')['rows']:
 s,nr=parent(row['seed']);ac=action(row['action']);np=sem.make_checked(nr,pack_semantic_search_position(s.compiled,nr,s),pack_semantic_action(nr,s.state.position,ac));s.submit(ac);assert record_value(s.state)==row['child_state'];compare(s,nr,s.state,np,list(s._search_witnesses));query(s,nr,row['result'],4096);assert row['finite_root_q']==1208;counts['rename_tie_queries']+=1
""";assert needle in s;s=s.replace(needle,addition+needle);f.write_bytes(s.encode())