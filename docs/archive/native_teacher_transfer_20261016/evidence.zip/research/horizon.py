from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/'.local_agent/alias-teacher-20261016';sys.path[:0]=[str(R),str(P)]
from core_teacher import Material,SearchMetadataAdapter,stopped,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,AlphaBetaPlayer,SearchTuning,SearchLimits,record_value,write_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules

def main():
 original=json.loads((P/'finite-teacher-plan.json').read_bytes());plan=dict(question='Are finite action-Q ranking labels horizon-dependent, so mixed-depth labels need declared provenance rather than pretending a universal action value?',cases=original['cases'],depths=[1,3],nodes=65536,seconds=8,whole_seconds=800,expected_seconds=180,max_queries=88,scope='Posthypothesis exploratorysame22actions/8exposedparents, noindependentvalidation/training/WDL. ExistingD5teacher suppliesrootD6 onlyifcomplete; newD1/D3rootD2/D4labels retain allcensors. IndependentCorealgorithm/sharedrules, Nativeallfullrecords.')
 write_record(P/'horizon-plan.json',plan);start=time.perf_counter();rows=[]
 for case in plan['cases']:
  stopped();d=json.loads((P/case['root']).read_bytes());raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=compile_native_semantic_rules(c)
  for i,ad in enumerate(case['hints']):
   s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));ac=next(x for x in s.legal_actions()if record_value(x)==ad);s.submit(ac);assert not s.state.terminal_status.is_terminal;before=record_value(s.state)
   for depth in plan['depths']:
    for backend in ('Core','Native')if(i+depth)%2 else('Native','Core'):
     stopped();row=dict(seed=case['seed'],hint_index=i,action=ad,depth=depth,root_horizon=depth+1,backend=backend)
     if time.perf_counter()-start>=800:rows.append(dict(**row,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
     t=time.perf_counter();limits=SearchLimits(max_depth=depth,max_nodes=65536,max_time_seconds=8,quiescence_max_depth=0,quiescence_hard_max_depth=0)
     if backend=='Core':result=AlphaBetaPlayer(c,evaluator_override=Material(d['board_values'],d['hand_values']),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,limits)
     else:result=SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False).search(s,limits,root_window_pruning=True)
     sec=time.perf_counter()-t;assert record_value(s.state)==before;out=dict(**row,kind='ACTUAL_QUERY',result=record_value(result),caller_seconds=sec,root_restored=True);rows.append(out);write_record(P/'horizon-progress.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start));print('HORIZON',case['seed'],i,depth,backend,result.completed_depth,round(sec,3),flush=True)
 write_record(P/'horizon-results.json',dict(complete=True,rows=rows,queries=sum(x['kind']=='ACTUAL_QUERY'for x in rows),seconds=time.perf_counter()-start,games=0,training=0,scope=plan['scope']))
if __name__=='__main__':main()