"""Owned generated-code/container accounting; borrowed IR/module objects excluded."""
import sys,types,json,importlib.util
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('probe',B/'compiled_effect_probe.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
from generic_chess.rules.builtins import build_builtin_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
rows=[]
for game in ('western_chess','standard_shogi'):
 c=compile_ruleset_for_execution(build_builtin_ruleset(game));meta=p.prepare(c)
 seen=set();codebytes=0;bytecodes=0;fnbytes=0;dictbytes=sys.getsizeof(p.plans);tuples=0;envs=set();functions=set()
 def account_code(code):
  global codebytes,bytecodes
  if id(code) in seen:return
  seen.add(id(code));codebytes+=sys.getsizeof(code);bytecodes+=len(code.co_code)
  for x in code.co_consts:
   if isinstance(x,types.CodeType):account_code(x)
 for pattern,fn in p.plans.values():
  tuples+=sys.getsizeof((pattern,fn));env=fn.__globals__
  if id(env) not in envs:envs.add(id(env));dictbytes+=sys.getsizeof(env)
  for v in env.values():
   if isinstance(v,types.FunctionType) and v.__code__.co_filename.startswith('<private compiled') and id(v) not in functions:
    functions.add(id(v));fnbytes+=sys.getsizeof(v);account_code(v.__code__)
 rows.append(dict(game=game,**meta,unique_envs=len(envs),generated_functions=len(functions),unique_code_objects=len(seen),owned_code_shallow_bytes=codebytes,bytecode_bytes=bytecodes,owned_function_shallow_bytes=fnbytes,owned_dictionary_shallow_bytes=dictbytes,plan_tuple_shallow_bytes=tuples))
(B/'compiled-effect-ownership.json').write_text(json.dumps(dict(scope='Object-size accounting, not total retained heap: excludes borrowed module/IR/keys/constants and allocator overhead; source bytes not resident-size estimate. Pattern/effect dataclasses are frozen; unsafe object.__setattr__ mutation is outside this private preparation assumption.',rows=rows),indent=2)+'\n',encoding='utf-8')
print(rows)
