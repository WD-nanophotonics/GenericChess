"""One live-module effect hook observation: copied globals are not deployment-compatible instrumentation."""
import sys,importlib.util,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('compiler_probe',B/'compiled_effect_probe.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.session.session import GameSession
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));e=semantic_engine_for(c);position=GameSession(c).state.position
a,binding=next(e.iter_legal_action_bindings(position));p.prepare(c)
original=p.m._apply_effect;rows=[]
for name,fn in [('original',p.baseline),('compiled',p.candidate)]:
 fault=RuntimeError('single live module effect hook');hits=[0]
 def effect(*args,**kwargs):hits[0]+=1;raise fault
 p.m._apply_effect=effect
 caught=None;child=None
 try:
  try:child=fn(e,position,a,binding)
  except RuntimeError as exc:caught=exc
 finally:p.m._apply_effect=original
 rows.append(dict(arm=name,hook_hits=hits[0],escaped_original_fault=caught is fault,returned_child=child is not None))
assert rows[0]['escaped_original_fault'] and rows[1]['hook_hits']==0 and rows[1]['returned_child']
(B/'compiled-effect-hook-negative.json').write_text(json.dumps(dict(rows=rows,scope='One ordinary Chess transition through explicit prepared carrier. Module _apply_effect hook substitution is bypassed by specialized per-effect functions; copied globals are not transparent dynamic instrumentation. Finite semantic agreement does not establish injection/monitor compatibility. This private negative is not a new product gate or claim the unmodified rules differ.'),indent=2)+'\n',encoding='utf-8')
print(rows)
