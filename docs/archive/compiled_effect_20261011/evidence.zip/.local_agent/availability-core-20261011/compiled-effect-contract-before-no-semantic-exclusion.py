"""Unmodified semantic transition oracle against mechanically compiled pattern functions."""
import sys,importlib.util,time
from pathlib import Path
from collections import Counter
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,B/file);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
p=load('compiled_effect','compiled_effect_probe.py');c=load('caller','installed_control.py')
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.ir import CompiledSemanticRuleset
from generic_chess.rules.compiler import compile_semantic_ruleset

def run():
 t=time.perf_counter();groups=[]
 for case in c.CASES:
  compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=c.CoreBoard(case,compiled);groups.append((case['id'],compiled,board.initial.position))
 for size in (4,6):
  for seed in (7,21):
   game=generate_game(GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));compiled=compile_semantic_ruleset(game.ruleset);groups.append((f'generated{size}-{seed}',CompiledSemanticRuleset(ir=compiled.ir,support=compiled.support),c.GameSession(compiled).state.position))
 out=dict(complete=False,scope='Original unmodified transition oracle vs exact prepared pure/compat IR.12exposed roots, all legal bindings, per-checkpoint cancellation on first8/root; no timing/holdout/full-domain proof.',rows=[],transitions=0,cancellation_cells=0,effect_kinds={})
 kinds=Counter()
 for name,compiled,position in groups:
  c.stopped();assert time.perf_counter()-t<120
  engine=semantic_engine_for(compiled);before=position;bindings=list(engine.iter_legal_action_bindings(position));setup=p.prepare(compiled);checks=0
  for j,(action,binding) in enumerate(bindings):
   kinds.update(e.kind for e in binding.pattern.effects)
   callbacks=[0,0];values=[]
   for arm,fn in enumerate((p.baseline,p.candidate)):
    def checkpoint():callbacks[arm]+=1
    values.append(fn(engine,position,action,binding,checkpoint))
   assert values[0]==values[1] and callbacks[0]==callbacks[1]
   assert position==before;out['transitions']+=1
   if j<8:
    for stop in range(1,callbacks[0]+1):
     for fn in (p.baseline,p.candidate):
      fault=RuntimeError('one caller checkpoint');n=0
      def checkpoint():
       nonlocal n
       n+=1
       if n==stop:raise fault
      try:fn(engine,position,action,binding,checkpoint)
      except RuntimeError as exc:assert exc is fault and n==stop
      else:raise AssertionError('checkpoint omitted')
      assert position==before;checks+=1;out['cancellation_cells']+=1
  # An otherwise equivalent semantic carrier is not the prepared object and
  # must use the original transition instead of cached source authority.
  other=replace(compiled);foreign_engine=semantic_engine_for(other)
  if bindings:
   a,binding=bindings[0];assert p.candidate(foreign_engine,position,a,binding)==p.baseline(foreign_engine,position,a,binding)
  out['rows'].append(dict(root=name,bindings=len(bindings),callback_fault_cells=checks,preparation=setup,carrier=type(compiled).__name__))
 out.update(complete=True,effect_kinds=dict(kinds),seconds_descriptive=time.perf_counter()-t);c.write_record(B/'compiled-effect-contract.json',out);print(out['transitions'],out['cancellation_cells'],out['effect_kinds'],flush=True)
if __name__=='__main__':run()
