import subprocess,time,json
from pathlib import Path
from datetime import datetime,timezone
b=Path(__file__).parent
start=datetime.now(timezone.utc)
assert datetime.fromisoformat('2026-10-11T05:10:00+00:00') <= start < datetime.fromisoformat('2026-10-11T05:10:45+00:00'), 'outside explicit ACK slot'
t=time.perf_counter()
p=subprocess.run(['.venv/Scripts/python.exe',str(b/'compiled_effect_control.py')],capture_output=True,text=True,timeout=240)
end=datetime.now(timezone.utc)
out={'ack_ts':'1791694370.092259','start_utc':start.isoformat(),'end_utc':end.isoformat(),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-t,'primary_cpu_overlap':False,'aux_ack_is_atomic_lock':False,'within_slot':end<datetime.fromisoformat('2026-10-11T05:15:00+00:00')}
(b/'compiled-effect-slot.json').write_text(json.dumps(out,indent=2)+'\n')
print(p.stdout,p.stderr);assert out['within_slot'] and p.returncode==0
