"""Structural compilation reuse candidates; no speed or semantic acceptance claim."""
import sys,json
from collections import Counter
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
roots=[(g,compile_ruleset_for_execution(build_builtin_ruleset(g))) for g in ('western_chess','standard_shogi')]
for size in (4,6):
 for seed in (7,21):
  roots.append((f'generated{size}-{seed}',compile_legacy_ruleset_for_semantic_execution(generate_game(GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True)).ruleset)))
rows=[]
for name,compiled in roots:
 groups=Counter(tuple(e.kind for e in p.effects) for p in compiled.ir.patterns)
 rows.append(dict(root=name,patterns=len(compiled.ir.patterns),kind_sequence_groups=len(groups),groups=[dict(kinds=list(k),patterns=n) for k,n in groups.items()]))
Path(__file__).with_name('compiled-effect-shape-reuse.json').write_text(json.dumps(dict(rows=rows,question='Could code sharing by declared effect-kind sequence remove measured setup/ownership burden while retaining all runtime operands?',inference='Possible next premise: shared generated code takes effects from actual pattern at original ordered indices instead of owning every pattern operand in duplicated globals. Frozen patterns bind semantics; duplicate kind sequence is not identical rule or action. No equivalence/performance claim and no new caller batch launched.'),indent=2)+'\n',encoding='utf-8')
print([(r['root'],r['patterns'],r['kind_sequence_groups']) for r in rows])
