from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import pytest
import count_candidate as c
with c.installed():
 result=pytest.main(['-q','tests/product/test_qsearch_semantic_effects.py','tests/product/test_qsearch_correctness.py','tests/product/test_native_cancellation.py','--basetemp=.local_agent/frame-reply-20261014/pytest-candidate-v2','-o','cache_dir=.local_agent/frame-reply-20261014/pytest-cache','--junitxml=.local_agent/frame-reply-20261014/candidate-tests-v2-private.xml'])
raise SystemExit(result)
