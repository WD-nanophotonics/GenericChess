from pathlib import Path
import sys,time,random,json,types
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core import semantic_executor as se
D=Path('.local_agent/frame-reply-20261014')
class LazyWitness:
 def __init__(self,e,pos,checked,checkpoint=None):
  self.e=e;self.parent=pos;self.side=pos.side_to_move;self.anchor=se._own_anchor(pos,e.support,self.side);self.checked=checked;self.checkpoint=checkpoint
  self.reused=0;self.fallback=0;self.rows=0
 def unchanged(self,child,written,support):
  changed=[]
  for i in written:
   old,new=self.parent.board[i],child.board[i]
   if old==new:continue
   if i==self.anchor or (new is not None and (new.owner!=self.side or getattr(support.type_metadata.get(new.current_type_id),'is_anchor',False))) or (old is not None and old.owner==self.side and getattr(support.type_metadata.get(old.current_type_id),'is_anchor',False)):
    self.fallback+=1;return False
   changed.append(i)
  if self.anchor is None or not self.e._capture_reads_local_board():
   self.fallback+=1;return False
  owner=1-self.side;key=(str(owner),self.anchor);endpoints=self.e.semantic._incoming_attack_endpoints
  if endpoints is None:
   self.fallback+=1;return False
  for source,typed in endpoints.get(key,{}).items():
   se._checkpoint(self.checkpoint)
   piece=self.parent.board[source]
   if piece is None or piece.owner!=owner:continue
   for rank,pattern,gid,end in typed.get(piece.current_type_id,()):
    self.rows+=1;se._checkpoint(self.checkpoint)
    if source in changed:
     self.fallback+=1;return False
    g=self.e.ir.geometry[gid]
    if g.kind!='leap':
     path=g.paths[str(owner)][source]
     if any(i in path[:end] for i in changed):
      self.fallback+=1;return False
  self.reused+=1;return True
def has(e,pos,checked,checkpoint=None,stats=None):
 witness=LazyWitness(e,pos,checked,checkpoint)
 original=e._trial_child_if_s3_legal
 def trial(self,pattern,position,action,binding,checkpoint=None,**kw):
  if position is pos and not kw.get('safety'):
   return original(pattern,position,action,binding,checkpoint=checkpoint,safety=witness)
  return original(pattern,position,action,binding,checkpoint=checkpoint,**kw)
 e._trial_child_if_s3_legal=types.MethodType(trial,e)
 try:return e.has_legal_action(pos,checkpoint)
 finally:
  e._trial_child_if_s3_legal=original
  if stats is not None:stats.update(reused=witness.reused,fallback=witness.fallback,dependency_rows=witness.rows)
