from pathlib import Path
from itertools import product
import json
D=Path('.local_agent/frame-reply-20261014')
# All labels are actual complete outcomes at one frozen root. Unknowns share
# each action's single latent outcome across prices, not separate random labels.
def regret_bounds(domains,selected):
 others=[v for i,v in enumerate(domains) if i!=selected]
 if not others:return (0,0)
 return (max(0,max(min(v) for v in others)-max(domains[selected])),
         max(0,max(max(v) for v in others)-min(domains[selected])))
def gain_bounds(domains,old,new):
 return (0,0) if old==new else (min(domains[new])-max(domains[old]),max(domains[new])-min(domains[old]))
rows=[];checked=0
choices=[(-1,), (0,), (1,),(-1,0),(0,1),(-1,0,1)]
for n in range(1,5):
 for domains in product(choices,repeat=n):
  outcomes=list(product(*domains))
  for selected in range(n):
   values=[max(v)-v[selected] for v in outcomes]
   assert regret_bounds(domains,selected)==(min(values),max(values))
   for new in range(n):
    gains=[v[new]-v[selected] for v in outcomes]
    assert gain_bounds(domains,selected,new)==(min(gains),max(gains))
    checked+=1
examples=[
 dict(name='same-action uncertain category',domains=[[-1,0,1],[1]],old=0,new=0),
 dict(name='one legal action unknown',domains=[[-1,0,1]],old=0,new=0),
 dict(name='different choices equally winning',domains=[[1],[1],[-1]],old=0,new=1),
 dict(name='true gain',domains=[[-1],[1]],old=0,new=1)]
for x in examples:
 x['gain_bounds']=gain_bounds(x['domains'],x['old'],x['new'])
 x['old_regret_bounds']=regret_bounds(x['domains'],x['old'])
 x['new_regret_bounds']=regret_bounds(x['domains'],x['new'])
# Two-root cancellation: changes are real but meanW-L and meanregret identical.
v=[(-1,1),(1,-1)]
assert sum(b-a for a,b in v)==0
data=dict(complete=True,exhaustive_cases=checked,examples=examples,cancellation=dict(per_root_gains=[2,-2],mean_gain=0),scope='Exact finite mathematical diagnostic of shared action-label uncertainty, not new games/API calls or AUX validation. Prevents naive independent label intervals from inventing benefit/harm when the same uncertain action is selected. Rootdistribution/optimalcontinuation remain conditional.')
(D/'uncertainty-bounds.json').write_bytes(json.dumps(data,indent=2).encode())
print(checked,examples)
