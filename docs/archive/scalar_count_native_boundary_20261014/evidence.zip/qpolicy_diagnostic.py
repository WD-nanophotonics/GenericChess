from pathlib import Path
import sys,json,random,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/frame-reply-20261014')
diff=json.loads((D/'qpolicy-differences.json').read_text())['differences']
assert diff
case=diff[0]
write_record(D/'qpolicy-diagnostic-declaration.json',dict(question='Does first observed q0/q4 actiondifference expose an immediate terminal-loss witness?',selection='lowestseed/lowestbudget firstdifference fromclosed frozenresource, adaptive diagnostic notvalidation',case=case,search_calls=0,fuse_seconds=90,scope='FullCore childandallnextlegalreplies only, no fullWDL/optimality, no positionpatch/qpolicy/defaultchange. Do not addrootsorbudgets tofindgain.'))
seed=case['seed'];sample=next(x for x in json.loads((D/'count-resource/samples.json').read_text())['samples'] if x['seed']==seed);n=sample['size']
g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True))
assert json.loads(p.serialize_ruleset(g.ruleset))==sample['ruleset']
c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(seed+21000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
assert record_value(s.state)==sample['state']
before=s.to_record();start=time.perf_counter();rows=[]
for name in ['q0','q4']:
 action=next(a for a in s.legal_actions() if record_value(a)==case[name]);child=apply_action(s.state,action,c);replies=legal_actions(child,c);outcomes=[]
 for reply in replies:
  assert time.perf_counter()-start<90;p.rr.stopped();after=apply_action(child,reply,c)
  outcomes.append(dict(action=record_value(reply),terminal=after.terminal_status.status.value,winner=after.terminal_status.winner,opponent_immediate_win=after.terminal_status.is_terminal and after.terminal_status.winner==1-s.state.position.side_to_move))
 rows.append(dict(policy=name,action=record_value(action),child_terminal=child.terminal_status.status.value,child_winner=child.terminal_status.winner,reply_count=len(replies),opponent_immediate_wins=sum(x['opponent_immediate_win'] for x in outcomes),replies=outcomes))
assert before==s.to_record()
write_record(D/'qpolicy-diagnostic.json',dict(complete=True,case=case,rows=rows,history_restored=True,search_calls=0,elapsed_seconds=time.perf_counter()-start,scope='Adaptive firstdifference finite immediate-terminal diagnostic. Absenceofopponentimmediatewin isnot generalsafety orbetterqpolicy; changedcrossdepthscores notutility. Original64resource unchanged.'))
print([(x['policy'],x['reply_count'],x['opponent_immediate_wins']) for x in rows])
