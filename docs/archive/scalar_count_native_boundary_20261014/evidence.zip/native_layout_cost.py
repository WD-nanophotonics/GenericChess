from pathlib import Path
import sys,json,ctypes as c,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.native.semantic import search_runtime_sizes
D=Path('.local_agent/frame-reply-20261014')
class Piece(c.Structure):
 _fields_=[('base',c.c_uint16),('current',c.c_uint16),('owner',c.c_uint8),('promoted',c.c_uint8),('occupied',c.c_uint8)]
class Aux(c.Structure):
 _fields_=[('kind',c.c_uint8),('has_value',c.c_uint8),('supplied',c.c_uint8),('bool_value',c.c_int32),('square',c.c_uint16)]
def position(squares):
 class Pos(c.Structure):
  _fields_=[('rules_fingerprint',c.c_char*65),('board',Piece*squares),('hand_counts',(c.c_uint16*64)*2),('side_to_move',c.c_uint8),('ply',c.c_uint16),('aux',(Aux*3)*8),('history_lo',c.c_uint64*1025),('history_hi',c.c_uint64*1025),('history_digest',(c.c_uint64*4)*1025),('history_actor',c.c_uint8*1025),('history_gave_check',c.c_uint8*1025),('history_len',c.c_uint16),('history_exact',c.c_uint8),('history_events_exact',c.c_uint8)]
 return Pos
actual=search_runtime_sizes();old=position(256);wide=position(576)
assert actual['position_bytes']==c.sizeof(old),(actual,c.sizeof(old))
rows=[]
for n in [1,9,33,129,1025]:
 def volume(cls):return cls.history_lo.offset+50*n+c.sizeof(cls)-cls.history_len.offset
 rows.append(dict(live_history=n,old_live_copy_bytes=volume(old),hypothetical_global576_live_copy_bytes=volume(wide),additional_bytes=volume(wide)-volume(old)))
data=dict(complete=True,actual_native_sizes=actual,ctypes_current_position_bytes=c.sizeof(old),layout_matches_actual_binary=True,piece_bytes=c.sizeof(Piece),aux_bytes=c.sizeof(Aux),current_fixed_copy_bytes=old.history_lo.offset,hypothetical576_fixed_copy_bytes=wide.history_lo.offset,rows=rows,
 scope='Current ABI model independently matches actual installed sizeof.576 layout is a hypothetical change only; bytevolume includes copiedalignment, not measured memorybus traffic or walltime. Existing livehistory-copy code is retained. No newNativebuild/ABI/cap, no globalmacroproposal adopted.')
(D/'native-layout-cost.json').write_bytes(json.dumps(data,indent=2).encode())
print(actual,c.sizeof(old),old.history_lo.offset,wide.history_lo.offset,rows)
