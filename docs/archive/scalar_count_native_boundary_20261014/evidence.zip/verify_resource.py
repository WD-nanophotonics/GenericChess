from pathlib import Path
import json
D=Path('.local_agent/frame-reply-20261014')
r=json.loads((D/'count-resource/rows.json').read_text(encoding='utf-8'));assert r['complete']
f=['action','score','principal_variation','completed_depth','choice_kind','declaration','result_source','result_ordinary_qdepth','result_check_hard_qdepth']
pairs=[]
for seed in [2026102011,2026102012,2026102013,2026102014]:
 for q in [0,4]:
  for seconds in [16,64]:
   for rep in [0,1]:
    a=[x for x in r['rows'] if x['seed']==seed and x['q']==q and x['seconds']==seconds and x['rep']==rep]
    if not a:continue
    assert len(a)==2
    old,new=[next(x for x in a if x['arm']==arm) for arm in ['original','candidate']]
    assert old['history_restored'] and new['history_restored'] and old['pv_core_legal'] and new['pv_core_legal']
    assert not old['actual_provider'] and not new['actual_provider']
    same=old['decision']['completed_depth']==new['decision']['completed_depth']
    if same:assert all(old['decision'].get(k)==new['decision'].get(k) for k in f),(seed,q,seconds,rep)
    pairs.append(dict(seed=seed,q=q,seconds=seconds,rep=rep,old_depth=old['decision']['completed_depth'],new_depth=new['decision']['completed_depth'],same_depth_tuple_equal=same,old_reason=old['decision']['termination_reason'],new_reason=new['decision']['termination_reason']))
assert len(r['rows'])+sum(x['unexecuted_cells'] for x in r['unavailable'])==64
out=dict(complete=True,actual_calls=len(r['rows']),unavailable=r['unavailable'],elapsed_seconds=r['elapsed_seconds'],pairs=pairs,deeper=sum(x['new_depth']>x['old_depth'] for x in pairs),same=sum(x['new_depth']==x['old_depth'] for x in pairs),shallower=sum(x['new_depth']<x['old_depth'] for x in pairs),retained_fields=f,scope='4new fullgeneratedrules/q0negativecontrol/q4,16/64s, bothorders. Moreattemptedwork is not retaineddepth gain; q0may also show ordinaryload drift though candidateunused. No horizon extensions/pricefitting or holdoutreset.')
(D/'count-resource/verification.json').write_bytes(json.dumps(out,indent=2).encode())
differences=[]
for seed in [2026102011,2026102012,2026102013,2026102014]:
 for sec in [16,64]:
  matches=[next((x for x in r['rows'] if x['seed']==seed and x['q']==q and x['seconds']==sec and x['rep']==0 and x['arm']=='original'),None) for q in [0,4]]
  if all(matches) and matches[0]['decision']['action']!=matches[1]['decision']['action']:
   differences.append(dict(seed=seed,seconds=sec,q0=matches[0]['decision']['action'],q4=matches[1]['decision']['action']))
(D/'qpolicy-differences.json').write_bytes(json.dumps(dict(complete=True,differences=differences,scope='Exploratory q0/q4 action differences, not utility/WDL gains or sparsecount effects.'),indent=2).encode())
print(out['actual_calls'],out['deeper'],out['same'],out['shallower'],r['elapsed_seconds'])
print('qpolicy differences',differences)
