from pathlib import Path
import sys,json,time
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from rule_semantics_ir_fixtures import _semantic_ruleset,_king_type,_ref
from generic_chess.core.movement import RayAtom,LeapAtom
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.schema import RuleAuxState,RuleSemanticAction,RuleGeometrySpec,RuleSlotGuard,RulePathConstraint,RuleActionEffect,RuleInvariant,RuleReplaceSelector
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.core import semantic_executor as se
from generic_chess.core.position import GameState
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
D=Path('.local_agent/frame-reply-20261014')
write_record(D/'wide-aux-v2-declaration.json',dict(question='Can existing Core check_provider handle realpush _gave_check at>255coordinates, fullaux truthflip and active-query rollback? Nativewide notimplemented.',sizes=[18,24],aux=[None,'anchor_square'],negative_actual_capture_rows=True,search_calls=0,scope='Synthetic typed roots, empty declaredhistory; normal Core fulllegality/push/terminal/history. Core provider witness only; no Nativewide/cancel latency claim or existingcodec/cap change.'))
rows=[]
for n in [18,24]:
 board=[None]*(n*n);board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K')
 for rank in range(n-2):board[rank*n+n-1]=Piece(0,'R','R')
 bsrc=(n-2)*n+n-3;board[bsrc]=Piece(0,'B','B')
 token=RuleAuxState(name='gate_square',value_kind='square_or_none',scope='global',lifetime='persistent',initial=None)
 action=RuleSemanticAction(name='gated_capture',type_ids=('R',),geometry=RuleGeometrySpec(kind='legacy_atoms',atom_kind='ray'),target_relation='enemy',composition='replace_legacy',replace_selector=RuleReplaceSelector(type_ids=('R',),action_family='board',target_relation='enemy',geometry_kind='ray',replace_all_matching=True),aux_state=(token,),slot_guards=(RuleSlotGuard(slot_name='gate_square',comparison='eq',square_ref=_ref('target')),),path_constraints=(RulePathConstraint('path_clear'),),effects=(RuleActionEffect('remove',square_ref=_ref('target'),disposition='capture_to_hand',piece_owner='opponent'),RuleActionEffect('move',from_ref=_ref('source'),to_ref=_ref('target'))),invariants=(RuleInvariant('own_anchor_safe'),))
 definition=_semantic_ruleset((_king_type(),PieceType('R','R',(RayAtom((0,1)),RayAtom((0,-1)))),PieceType('B','B',(LeapAtom((1,0)),))), (action,),n=n,rows=[tuple(board[r*n:(r+1)*n]) for r in range(n)])
 c=compile_ruleset_for_execution(definition);base=GameSession(c).state.position;slot=next(s.slot_id for s in c.ir.aux_slots if s.value_kind=='square_or_none')
 (D/f'wide-aux-v2-{n}-rules.json').write_bytes(serialize_ruleset(definition).encode())
 for enabled in [False,True]:
  pos=replace(base,aux_state=(((slot,-1),(n-1,n-1) if enabled else None),))
  state=GameState(pos,0,(),TerminalResult(TerminalStatus.ONGOING),())
  e=se.SemanticEngine(c);metrics=dict(provider_calls=0,bindings=0,provider_seconds=0.)
  old=e._make_binding
  def binding(*a,**kw):metrics['bindings']+=1;return old(*a,**kw)
  e._make_binding=binding
  def provider(p,side,checkpoint=None):
   metrics['provider_calls']+=1;t=time.perf_counter()
   try:return e.in_check(p,side,checkpoint=checkpoint)
   finally:metrics['provider_seconds']+=time.perf_counter()-t
  runtime=SearchPathRuntime.from_state(state,c,check_provider=provider)
  move=next(a for a in runtime.legal_actions() if getattr(a,'from_square',None) is not None and a.from_square.rank==n-2 and a.from_square.file==n-3 and a.to_square.rank==n-2 and a.to_square.file==n-2)
  def snap():return(runtime.position,runtime.ply_count,runtime.current_identity,runtime.runtime_hash,tuple(runtime.history),runtime.terminal_status,len(runtime._frames))
  before=snap();t=time.perf_counter()
  with runtime.pushed(move):
   assert runtime.in_check(1)==enabled
   assert runtime.history[-1].gave_check==enabled
   child_terminal=runtime.terminal_status.status.value
  caller=time.perf_counter()-t;assert snap()==before
  assert metrics['bindings']>=n-2 and metrics['provider_calls']==1
  normal=dict(metrics)
  cancel=dict(requested=False)
  metrics['bindings']=0
  in_provider=False
  def cancel_provider(p,side,checkpoint=None):
   nonlocal_holder[0]=True
   try:return e.in_check(p,side,checkpoint=checkpoint)
   finally:nonlocal_holder[0]=False
  nonlocal_holder=[False]
  runtime._check_provider=cancel_provider
  def checkpoint():
   if nonlocal_holder[0] and metrics['bindings']>0:
    cancel['requested']=True;cancel['request_time']=time.perf_counter();raise RuntimeError('active scalar callback cancel')
  try:
   runtime.push(move,checkpoint=checkpoint)
   raise AssertionError('cancel missing')
  except RuntimeError as exc:assert str(exc)=='active scalar callback cancel'
  cancel['rollback_time']=time.perf_counter();assert cancel['requested'] and snap()==before
  rows.append(dict(size=n,aux_enabled=enabled,source_gt255=any(i>255 and x is not None and x.current_type_id=='R' for i,x in enumerate(pos.board)),anchor_gt255=n*n-1,expected_child_check=enabled,normal_provider=normal,core_caller_seconds=caller,child_terminal=child_terminal,position_history_identity_depth_restored=True,active_core_cancel_observed=True,rollback_after_callback_seconds=cancel['rollback_time']-cancel['request_time'],scope='Core callback injection, not async scheduledrequest or Native GIL latency.'))
write_record(D/'wide-aux-v2-controls.json',dict(complete=True,rows=rows,actual_runtime_pushes=8,search_calls=0,scope='4normal and4cancelled Core realpush provider calls. Fullaux truthflip andactive capture rows, >255 coords. No Nativewide support/speed demonstrated, syntheticroots not a reachablegamecurriculum.'))
print(rows)
