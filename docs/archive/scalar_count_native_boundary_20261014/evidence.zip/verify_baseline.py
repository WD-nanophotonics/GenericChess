from pathlib import Path
import json,hashlib,ast,xml.etree.ElementTree as ET
D=Path('.local_agent/frame-reply-20261014')
files=['generic_chess/ai/alphabeta/quiescence.py','generic_chess/ai/alphabeta/search.py','generic_chess/core/semantic_executor.py','generic_chess/core/search_runtime.py']
r={'base_commit':'071042ee0add38761cf2992c881f7f44d00784bb','baseline_files':{f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files},'candidate':hashlib.sha256((D/'count_candidate.py').read_bytes()).hexdigest(),'production_changed':False,'declaration_limit':'candidate_source_sha in reused generic declaration binds unchanged semantic_executor; this explicit record also binds actual count/search baseline. Candidate private source hash binds actual monkeypatch. No frozen result/declaration rewritten.'}
(D/'baseline-binding.json').write_bytes(json.dumps(r,indent=2).encode())
(D/'original_quiescence.py').write_bytes(Path(files[0]).read_bytes())
(D/'original_search.py').write_bytes(Path(files[1]).read_bytes())
root=ET.parse(D/'candidate-tests-v2-private.xml').getroot()
suites=[root] if root.tag=='testsuite' else root.findall('testsuite')
out={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
assert out==dict(tests=35,failures=0,errors=0,skipped=0)
(D/'candidate-test-summary.json').write_bytes(json.dumps(dict(out,scope='Private candidate monkeypatch on existing qsemantic/qcorrectness/nativecancel cases; not a new2429 fullsuite or product adoption'),indent=2).encode())
f=json.loads((D/'count-fixed/rows.json').read_text(encoding='utf-8'));assert f['complete'] and len(f['rows'])==8
times={'elapsed_seconds','time_to_first_legal_action','time_to_first_completed_iteration','ordering_seconds','legal_generation_seconds','evaluation_seconds'}
pairs=[]
for seed in [2026101991,2026101994]:
 for rep in [0,1]:
  a,b=[next(x for x in f['rows'] if x['seed']==seed and x['rep']==rep and x['arm']==arm) for arm in ['original','candidate']]
  assert {k:v for k,v in a['decision'].items() if k not in times}=={k:v for k,v in b['decision'].items() if k not in times}
  pairs.append(dict(seed=seed,rep=rep,old_seconds=a['wall'],new_seconds=b['wall'],saving_fraction=1-b['wall']/a['wall'],all_non_time_work_equal=True))
(D/'count-fixed/verification.json').write_bytes(json.dumps(dict(complete=True,actual_search_calls=8,pairs=pairs,decision='No cost-only adoption yet: scalar44-66percent lower doesnotyield uniformcaller saving. Four purposecalls laterconfirm1024actuallyreachescount;512doesnot. Do not manufacture reruns/strongfactor frommicro.'),indent=2).encode())
print(out,pairs)
