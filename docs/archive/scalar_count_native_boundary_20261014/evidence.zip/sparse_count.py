from pathlib import Path
import sys,json,time,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.ai.alphabeta import quiescence as q
D=Path('.local_agent/frame-reply-20261014')
def sparse_count(position,side):
 return sum(1 for piece in position.board if piece is not None and piece.owner!=side)
write_record(D/'count-declaration.json',dict(question='Can retaining complete board reads but emitting only actual enemies remove generator zero yields?',seeds=[2026101991,2026101994],sizes=[8,24],states=8,repeats=10000,orders=2,search_calls=0,changed_premise='Same standalone scalar count; no combined inventory/delta consumer or cache. Originalall cells emitted booleans, candidate only enemy cells emits1.'))
rows=[]
for seed,size in [(2026101991,8),(2026101994,24)]:
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(seed+19000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 for state in range(8):
  pos=s.state.position
  for side in [0,1]:
   expected=q.enemy_board_count(pos,side);assert sparse_count(pos,side)==expected
   trials=[]
   for rep in range(2):
    for arm in (['original','sparse'] if rep==0 else ['sparse','original']):
     fn=q.enemy_board_count if arm=='original' else sparse_count;t=time.perf_counter()
     for _ in range(10000):assert fn(pos,side)==expected
     trials.append(dict(rep=rep,arm=arm,seconds=time.perf_counter()-t))
   rows.append(dict(seed=seed,size=size,state=state,side=side,count=expected,trials=trials))
  if s.state.terminal_status.is_terminal:break
  s.submit(sorted(s.legal_actions(),key=repr)[0])
write_record(D/'count-rows.json',dict(complete=True,rows=rows,search_calls=0))
print([(r['size'],r['state'],r['side'],round(r['trials'][1]['seconds']/r['trials'][0]['seconds'],3)) for r in rows])
