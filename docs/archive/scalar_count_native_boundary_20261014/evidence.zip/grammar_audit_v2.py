from pathlib import Path
import sys,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests/product'))
sys.path.insert(0,str(ROOT/'tests'))
from generic_chess.core import semantic_executor as se
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from test_compiled_endpoint_fallback import DEFINITIONS
from test_s3_full_frontier import counter
from scripts.research_record import write_record
from lazy_candidate import LazyWitness,has
from count_candidate import count,ORIGINAL,installed
D=Path('.local_agent/frame-reply-20261014')
rows=[];trials=0;reused=0;fallback=0
for no,definition in enumerate(DEFINITIONS):
 c=compile_ruleset_for_execution(definition);s=GameSession(c);e=se.SemanticEngine(c)
 for ply in range(4):
  p=s.state.position;checked=e.in_check(p,p.side_to_move)
  assert count(p,0)==ORIGINAL(p,0) and count(p,1)==ORIGINAL(p,1)
  assert e.has_legal_action(p)==has(e,p,checked)
  n=0;yes=0;nope=0
  for pattern in e._patterns:
   for a,b in e._iter_candidates(pattern,p):
    ctx=LazyWitness(e,p,checked)
    old=e._trial_child_if_s3_legal(pattern,p,a,b)
    new=e._trial_child_if_s3_legal(pattern,p,a,b,safety=ctx)
    assert old==new
    if ctx.reused:
     written=set();child=e._transition(p,a,b,written_squares=written)
     assert checked==e.in_check(child,p.side_to_move)
    n+=1;yes+=ctx.reused;nope+=ctx.fallback
  trials+=n;reused+=yes;fallback+=nope
  rows.append(dict(fixture=no,ply=ply,trials=n,reused=yes,fallback=nope,exact_child=True,first_reply=True,counts=True))
  if s.state.terminal_status.is_terminal:break
  s.submit(sorted(s.legal_actions(),key=repr)[0])
controls=[]
for name in ['guard','enemy_retype','other_invariant']:
 e,p=counter(name);checked=e.in_check(p,p.side_to_move)
 old=e.has_legal_action(p);assert has(e,p,checked)==old
 for pattern in e._patterns:
  for a,b in e._iter_candidates(pattern,p):
   ctx=LazyWitness(e,p,checked)
   assert e._trial_child_if_s3_legal(pattern,p,a,b)==e._trial_child_if_s3_legal(pattern,p,a,b,safety=ctx)
 controls.append(dict(name=name,full_child_equal=True))
write_record(D/'grammar-audit.json',dict(complete=True,rows=rows,trials=trials,reused=reused,fallback=fallback,controls=controls,search_calls=0,decision='Lazy candidate remains rejected on measured overhead; finite semantic proof does not establish useful deployment. Countvalid complete states parity, no production changed.'))
print(len(rows),trials,reused,fallback,controls)
