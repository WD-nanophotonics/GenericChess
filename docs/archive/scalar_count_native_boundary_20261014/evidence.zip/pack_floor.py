from pathlib import Path
import sys,time,json
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core import semantic_executor as se
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider as Provider
D=Path('.local_agent/frame-reply-20261014')
write=lambda name,value:(D/name).write_bytes(json.dumps(value,indent=2).encode())
write('pack-floor-declaration.json',dict(question='Does existing exact Python state-only payload cost leave headroom for proposed readonly scalar seam on active>255auxflip inputs?',sizes=[18,24],aux=[False,True],repeats=2000,orders=2,Nativewidecalls=0,scope='Existing payload builder only, no Cimport/Nativequery or newcapsule. Lowercomponent-cost control not wholecaller speed or implementation acceptance.'))
rows=[]
for n in [18,24]:
 definition=deserialize_ruleset((D/f'wide-aux-v2-{n}-rules.json').read_text())
 c=compile_ruleset_for_execution(definition);base=GameSession(c).state.position;e=se.SemanticEngine(c);slot=next(s.slot_id for s in c.ir.aux_slots if s.value_kind=='square_or_none')
 provider=object.__new__(Provider);provider.type_map={tid:i for i,tid in enumerate(sorted(c.support.type_metadata))};provider.type_ids=tuple(provider.type_map)
 for enabled in [False,True]:
  pos=replace(base,aux_state=(((slot,-1),(n-1,n-1) if enabled else None),))
  assert e.in_check(pos,1)==enabled
  payload=provider._state_only_payload(pos,0)
  assert len(payload['board'])==n*n and payload['aux_state']==pos.aux_state
  assert payload['board'][-1] is not None
  trials=[]
  for rep in [0,1]:
   for arm in (['Corecheck','payload_only'] if rep==0 else ['payload_only','Corecheck']):
    t=time.perf_counter()
    for _ in range(2000):
     if arm=='Corecheck':assert e.in_check(pos,1)==enabled
     else:provider._state_only_payload(pos,0)
    trials.append(dict(rep=rep,arm=arm,seconds=time.perf_counter()-t))
  rows.append(dict(size=n,enabled=enabled,trials=trials,fullaux_preserved=True,boardcells=n*n))
write('pack-floor.json',dict(complete=True,rows=rows,search_calls=0,Nativewidecalls=0,scope='Counterbalanced known Python payload floor only. Excludes Cparse/import/query/fallback/wholecaller/activecancel; cannot upgrade to Nativewide support or speedfactor.'))
print(rows)
