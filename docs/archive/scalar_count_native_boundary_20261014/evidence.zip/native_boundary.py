from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.native.semantic import pack_action,unpack_action
D=Path('.local_agent/frame-reply-20261014')
fields=dict(to=7,**{'from':2},promotion=255,base=3,kind=2,pattern=12,geometry=1023,actor_current=5)
rows=[]
for field in ['to','from']:
 for value in [255,256,575]:
  x=dict(fields);x[field]=value
  try:
   p=pack_action(x);assert unpack_action(p)==x
   rows.append(dict(field=field,value=value,accepted=True))
  except ValueError as e:
   rows.append(dict(field=field,value=value,accepted=False,error=str(e)))
assert all(x['accepted']==(x['value']==255) for x in rows)
def frozen_unchecked(to,source):
 return to|(source<<8)|(255<<16)|(3<<24)|(2<<32)|(12<<36)|(1023<<44)|(5<<56)
assert frozen_unchecked(256,0)==frozen_unchecked(0,1)
sources=['generic_chess/_native/native_types.h','generic_chess/_native/native_semantic_rules.c','generic_chess/_native/native_semantic_runtime.c','generic_chess/_native/native_semantic_state.h','generic_chess/ai/alphabeta/native_legality.py']
data=dict(complete=True,actual_public_pack_calls=6,search_calls=0,rows=rows,
 counterexample=dict(old_unchecked_layout_equal=True,pair1=dict(to=256,source=0),pair2=dict(to=0,source=1)),
 source_sha256={s:hashlib.sha256(Path(s).read_bytes()).hexdigest() for s in sources},
 conclusion='Current Native boundary failsclosed at packedsource/target8bits despite internaluint16square types. Raising board-size guard orGC_MAX_SQUARES alone is unsafe: fields overlap. A read-only scalar extension would separately need storage/compiler boundaries; fulllegal/search route requires distinct versioned encoding. No productioncap/ABI/build changed.',
 scope='Finite interface feasibility and actual public refusal, no unsupported unsafe kernel query, sourceupgrade or proof of completeNative domain.')
(D/'native-boundary.json').write_bytes(json.dumps(data,indent=2).encode())
print(rows)
