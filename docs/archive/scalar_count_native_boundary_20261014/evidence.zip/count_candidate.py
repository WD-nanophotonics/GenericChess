from contextlib import contextmanager
from generic_chess.ai.alphabeta import quiescence as q, search as s
ORIGINAL=q.enemy_board_count
def count(position,side):
 return sum(1 for piece in position.board if piece is not None and piece.owner!=side)
@contextmanager
def installed():
 oldq,olds=q.enemy_board_count,s.enemy_board_count
 q.enemy_board_count=s.enemy_board_count=count
 try:yield
 finally:q.enemy_board_count,s.enemy_board_count=oldq,olds
