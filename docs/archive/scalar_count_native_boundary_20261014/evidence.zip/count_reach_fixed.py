from pathlib import Path
import sys,random,time,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta import quiescence as q,search as search
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from count_candidate import count
D=Path('.local_agent/frame-reply-20261014')
write_record(D/'count-reach-fixed-declaration.json',dict(question='Is sparse-count candidate inactive atq0 and how many actual zero yields canq4 avoid?',seed=2026101994,size=24,prefix=8,q=[4],nodes=[512,1024],seconds=64,planned_calls=4,scope='Counting instrumentation only, not speed evidence; actual original count authority maintained. No frozenresource producer/source changed.'))
g=p.generate_game(p.GeneratorConfig(seed=2026101994,board_size=24,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(2026101994+19000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec);rows=[]
oldq,olds=q.enemy_board_count,search.enemy_board_count
for nodes,arm in [(512,'original'),(512,'sparse'),(1024,'original'),(1024,'sparse')]:
 depth=4
 fn=oldq if arm=='original' else count
 stats=dict(calls=0,board_cells=0,enemy_yields=0)
 def observed(pos,side):
  answer=fn(pos,side);stats['calls']+=1;stats['board_cells']+=len(pos.board);stats['enemy_yields']+=answer;return answer
 q.enemy_board_count=search.enemy_board_count=observed
 try:
  before=s.to_record();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
  d=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=nodes,max_time_seconds=64,quiescence_max_depth=depth,quiescence_hard_max_depth=8))
  assert before==s.to_record()
 finally:q.enemy_board_count,search.enemy_board_count=oldq,olds
 rows.append(dict(q=depth,nodes=nodes,arm=arm,decision=record_value(d),counts=stats,history_restored=True))
assert rows[0]['counts']['calls']==rows[1]['counts']['calls']==0
assert rows[2]['counts']['calls']==rows[3]['counts']['calls']>0
write_record(D/'count-reach-fixed.json',dict(complete=True,actual_search_calls=4,rows=rows,scope='Actual countcalls/cells/ones measured; avoiding generator yields does not avoid boardreads or transitions/terminal/history. No profiledfraction or wallgain inferred.'))
print([(r['nodes'],r['arm'],r['counts']) for r in rows])
