from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,traceback,collections
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R)]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import RuleNoProgressDraw
from generic_chess.session.session import GameSession
from generic_chess.core import search_runtime,terminal
from generic_chess.core.position import GameState
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
class Unity:
 def evaluate(self,state):return sum((1 if z.owner==state.position.side_to_move else -1)for z in state.position.board if z is not None)
 def type_value(self,t):return 0 if t=='K'else 1
 def capture_order_value(self,moving,captured):return self.type_value(captured.current_type_id)
start=time.perf_counter();rows=[];stats=collections.Counter();old=search_runtime.terminal_from_search_runtime;plan=json.loads((D/'q-boundary-plan.json').read_bytes());current_q=[0]
def checked(rt,checkpoint=None):
 result=old(rt,checkpoint)
 if result.status==terminal.TerminalStatus.NO_PROGRESS_DRAW:
  counts,hist=terminal._repeated_cycle_target_history_projection(rt)
  state=GameState(rt.position,rt.ply_count,counts,result,hist)
  assert terminal.terminal_result(state,rt.compiled)==result
  stats['NP_terminal_complete_Core_checks']+=1
  frame=sys._getframe(1)
  for _ in range(9):
   if frame is None:break
   if frame.f_code.co_name=='_quiescence_runtime':stats['actual_q_NP_terminals_checked']+=1;break
   frame=frame.f_back
 return result
search_runtime.terminal_from_search_runtime=checked
with(D/'q-boundary-events.jsonl').open('x',encoding='utf8')as log:
 for z in json.loads((R/'.local_agent/mechanism-mix-20261017/inputs.json').read_bytes())['rows'][:6]:
  for threshold,capture,movers in plan['policy_axes']:
   rule=replace(deserialize_ruleset(json.dumps(z['ruleset'])),no_progress_draw=RuleNoProgressDraw(threshold,capture,tuple(movers)));c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c)
   for q,hard in plan['q_axes']:
    assert time.perf_counter()-start<plan['whole_seconds']
    for n in('rollout','advisor','slack'):
     f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
    before=s.state;w=s._search_witnesses;t=time.perf_counter();old_stats=dict(stats)
    try:
     p=AlphaBetaPlayer(c,evaluator_override=Unity(),use_disk_cache=False,use_native_semantic_legality=False,tt_max_entries=10000);v=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=q,quiescence_hard_max_depth=hard));elapsed=time.perf_counter()-t
     assert v.action in s.legal_actions()and s.state is before and s._search_witnesses is w
     pv=copy(s);states=[]
     for a in v.principal_variation:pv.submit(a);states.append(record_value(pv.state))
     row={'family':z['family_index'],'threshold':threshold,'reset_capture':capture,'q':q,'hard':hard,'status':'returned','seconds':elapsed,'decision':record_value(v),'full_PV_states':states,'probe_delta':{k:stats[k]-old_stats.get(k,0)for k in stats},'parent_preserved':True}
    except Exception as e:row={'family':z['family_index'],'threshold':threshold,'q':q,'status':'error','error':{'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()}}
    rows.append(row);log.write(json.dumps(row)+'\n');log.flush();print(z['family_index'],threshold,q,row['status'],None if row['status']=='error'else(v.completed_depth,v.termination_reason),flush=True)
search_runtime.terminal_from_search_runtime=old
with(D/'q-boundary-results.json').open('x',encoding='utf8')as f:json.dump({'complete':len(rows)==24,'rows':rows,'errors':sum(x['status']=='error'for x in rows),'stats':dict(stats),'seconds':time.perf_counter()-start,'scope':'Instrumented actual Core q integration; no wall speed/strength, qdefault or all-domain proof claim.'},f,indent=2)
print('DONE',dict(stats),flush=True)
