from pathlib import Path
import json,hashlib,zipfile,re
import sys
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
R=Path.cwd();D=R/'.local_agent/no-progress-context-20261017';A=R/'docs/archive/no_progress_context_20261017';A.mkdir(exist_ok=True);assert not any(A.iterdir()), 'Archive directory must be empty after first preflight refusal'
manifest=json.loads((D/'publication-source-manifest.json').read_bytes());source=D/'publication-source'
for name in manifest:
 q=R/name
 if q.exists() and name!='generic_chess/learning/alphasho_bridge.py':(source/name).write_bytes(q.read_bytes())
manifest={name:hashlib.sha256((source/name).read_bytes()).hexdigest()for name in manifest};write_json(D/'publication-source-manifest.json',manifest)
assert json.loads((D/'qualified-full-result.json').read_bytes())['returncode']==0
assert json.loads((D/'public-source-tests-qualified-result.json').read_bytes())['returncode']==0
assert json.loads((D/'source-reader-public-results.json').read_bytes())['complete']
files={};maps=[]
def put(name,data,original=None):
 assert name not in files and not name.startswith('/')and '..'not in Path(name).parts
 files[name]=data
 if original is not None:maps.append({'member':name,'private_original_sha256':hashlib.sha256(original).hexdigest(),'publication_sha256':hashlib.sha256(data).hexdigest(),'changed':original!=data})
def clean(v):
 if isinstance(v,str):
  for old,new in((str(R),'<WORKSPACE>'),(str(R).replace('\\','/'),'<WORKSPACE>'),(str(Path.home()),'<USER_HOME>'),(str(Path.home()).replace('\\','/'),'<USER_HOME>')):v=v.replace(old,new)
  return v
 if isinstance(v,list):return[clean(x)for x in v]
 if isinstance(v,dict):return{clean(k):clean(x)for k,x in v.items()}
 return v
for name in manifest:put('source/'+name,(source/name).read_bytes())
# Only project scientific/qualification evidence, never raw Slack/account/receipt
# stores. Outgoing JSON copies remove local personal path strings, not numbers.
exclude={'aux82-fixed-report-original.md'}
for q in D.iterdir():
 if not q.is_file()or q.name in exclude or 'owned-process'in q.name:continue
 if q.suffix not in('.json','.py','.log','.txt')and not q.name.endswith(('.json.v1','.py.first')):continue
 raw=q.read_bytes();name='evidence/'+q.name
 if q.suffix=='.json'or q.name.endswith('.json.v1'):
  data=(json.dumps(clean(json.loads(raw)),indent=2,ensure_ascii=True)+'\n').encode()
 else:data=clean(raw.decode('utf-8-sig')).encode()
 if q.name in ('source-reader-results.json','source-reader-public-results.json'):name='recorded/'+q.name
 put(name,data,raw)
for folder,names in{
 'no-progress-prototype-20261017':['controls.json','long-prefix-128.json','long-prefix-512.json','long-prefix-1024.json'],
 'mechanism-mix-20261017':['inputs.json','frontiers.json'],
 'no-progress-counter-20261017':['results.json','ambiguity-timing.json']}.items():
 for name in names:
  raw=(R/'.local_agent'/folder/name).read_bytes();put('support/'+folder+'/'+name,(json.dumps(clean(json.loads(raw)),indent=2)+'\n').encode(),raw)
# Reconstruct each exact executed package by applying only differing files to
# final source; inventory identifies original package paths and exact bytes.
versions={'replay_baseline':R/'.local_agent/no-progress-prototype-20261017/source/generic_chess','context_v2':D/'source/generic_chess','product_v3':D/'product-source/generic_chess','private_v4':D/'v4-source/generic_chess'}
for label,folder in versions.items():
 inv={}
 for q in sorted(folder.rglob('*')):
  if not q.is_file()or '__pycache__'in q.parts or q.suffix in('.pyd','.dll','.pyc'):continue
  rel='generic_chess/'+q.relative_to(folder).as_posix()
  if rel=='generic_chess/learning/alphasho_bridge.py':continue
  raw=q.read_bytes();inv[rel]=hashlib.sha256(raw).hexdigest()
  normal=source/rel
  if not normal.exists()or normal.read_bytes()!=raw:put('source_overlays/'+label+'/'+rel,raw)
 put('source_overlays/'+label+'/inventory.json',(json.dumps(inv,indent=2)+'\n').encode())
for q in (D/'v1-overlay').glob('*.py'):put('source_overlays/context_v1/generic_chess/core/'+q.name,q.read_bytes())
put('source_overlays/context_v1/README.txt',b'Apply replay_baseline overlay then these3 context_v1 files. It retains the actual witness-permutation admission failure. Do not activate it.\n')
# Actual outgoing contents check, not an origin-based prohibition.
hits=[]
for name,b in files.items():
 text=b.decode('utf8')
 if re.search(r'C:[\\/]Users[\\/](?!<)',text):hits.append((name,'personal absolute path'))
 if re.search(r'xox[baprs]-[A-Za-z0-9-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----',text):hits.append((name,'credential literal'))
assert not hits,hits
archive=A/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,b in sorted(files.items()):z.writestr(name,b)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for name,b in files.items():assert z.read(name)==b
summary={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'members':len(files),'source_files':len(manifest),'normal_full_tests':2971,'restored_source_tests':206,'source_reader_fullstate_occurrences':2386,'source_reader_q_receipts':24,'normal_C_and_kernel_unchanged':True,'publication_copies':maps,'members_manifest':{n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}for n,b in sorted(files.items())}}
write_json(A/'manifest.json',summary);write_json(D/'archive-built.json',{'archive_bytes':summary['archive_bytes'],'archive_sha256':summary['archive_sha256'],'members':summary['members'],'source_files':len(manifest),'all_members_hash_and_CRC_verified':True,'no_sensitive_actual_content_hits':True})
write_json(A/'restoration.json',{'build':json.loads((D/'public-source-build-result.json').read_bytes()),'tests':json.loads((D/'public-source-tests-qualified-result.json').read_bytes()),'reader':json.loads((D/'source-reader-public-results.json').read_bytes()),'source_manifest':manifest,'source_private_failure_preserved':True})
print({k:v for k,v in summary.items()if k not in('publication_copies','members_manifest')})
