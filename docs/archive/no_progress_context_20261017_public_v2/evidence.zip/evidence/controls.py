from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(D/'source'),str(R/'tests'),str(R)]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core import terminal
from generic_chess.core.adjudication import IncompleteAdjudicationHistoryError
from generic_chess.session.session import GameSession
from scripts.research_record import record_value
from scripts.full_q_refresh_comparison import runtime_state

def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def compiled(rule):
 r=deserialize_ruleset(json.dumps(rule));return replace((compile_semantic_ruleset(r) if r.semantic_actions else compile_legacy_ruleset_for_semantic_execution(r)),_legacy_compiled=None)
def replay(c,actions):
 s=GameSession(c)
 for a in actions:s.submit(decode(a))
 return s

def snap(rt):return runtime_state(rt),rt._np_context,rt.search_key(),tuple(rt.history)
checks=[];start=time.perf_counter();twins=[]
data=json.loads((R/'.local_agent/no-progress-prototype-20261017/controls.json').read_bytes());c=compiled(data['ruleset'])
for row in data['counter_controls']:
 s=replay(c,row['record']['actions']);rt=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses,hash_override=7);before=snap(rt);n=0
 for a in s.legal_actions():
  ch=copy(s);ch.submit(a);rt.push(a)
  assert rt.position==ch.state.position and rt.terminal_status==ch.state.terminal_status
  counts,history=terminal._repeated_cycle_target_history_projection(rt)
  assert counts==ch.state.repetition_counts and history==ch.state.history
  rt.pop();assert snap(rt)==before;n+=1
 twins.append(rt);checks.append({'label':row['label'],'all_children':n,'context':rt._np_context,'undo_full_history_key':True})
assert twins[0].search_key()!=twins[1].search_key()
# Exact accepted spawn prefixes and threshold rollback, not early rejection.
a=json.loads((R/'.local_agent/no-progress-counter-20261017/ambiguity-timing.json').read_bytes());c=compiled(a['ruleset']);s=GameSession(c);rt=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses,hash_override=7)
for v in a['accepted_actions']:
 act=decode(v);s.submit(act);rt.push(act)
 assert rt.position==s.state.position and rt.terminal_status==s.state.terminal_status
assert rt._np_context[1]=='no-progress history capture fact is ambiguous at action 1'
before=snap(rt);act=decode(a['rejected_threshold_action'])
for label,fn in [('Core',lambda:copy(s).submit(act)),('private_runtime',lambda:rt.push(act))]:
 try:fn()
 except IncompleteAdjudicationHistoryError as e:assert str(e)==a['threshold_failure']['message']
 else:raise AssertionError(label+' accepted threshold ambiguity')
assert snap(rt)==before
# Re-import accepted three-ply prefix preserves deferred error provenance.
imported=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses)
assert imported._np_context==rt._np_context
# Existing precedence: repetition wins over ambiguous NP; NP wins over max.
from generic_chess.core.terminal import terminal_result,terminal_from_search_runtime
cc=replace(c,support=replace(c.support,repetition_limit=1))
rt.compiled=cc
assert terminal_from_search_runtime(rt)==terminal_result(s.state,cc)
assert terminal_from_search_runtime(rt).status.value=='repetition'
rt.compiled=c
# Exception/cancellation after context update must roll back exact NP state.
original=__import__('generic_chess.core.search_runtime',fromlist=['x']);old=original.terminal_from_search_runtime
class Cancelled(BaseException):pass
def fail(*args,**kwargs):raise Cancelled('injected after context update')
original.terminal_from_search_runtime=fail
try:
 try:rt.push(act)
 except Cancelled:pass
 else:raise AssertionError('cancel not propagated')
finally:original.terminal_from_search_runtime=old
assert snap(rt)==before
# Forged record paired with unchanged full witnesses still fails exact root replay.
bad=replace(s.state,history=s.state.history[:1]+(replace(s.state.history[1],gave_check=not s.state.history[1].gave_check),)+s.state.history[2:])
try:SearchPathRuntime(bad,c,history_witnesses=s._search_witnesses)
except IncompleteAdjudicationHistoryError:pass
else:raise AssertionError('forged record admitted')
checks.append({'label':'spawn','accepted_prefix_plies':3,'same_threshold_error':a['threshold_failure'],'reimport_deferred_error':True,'repetition_precedes_error':True,'injected_BaseException_rollback':True,'forged_record_rejected_even_with_witnesses':True})
out={'complete':True,'checks':checks,'seconds':time.perf_counter()-start,'scope':'Private context only, exact retained full history keys; observed controls not generic proof or hard timer qualification.'}
with(D/('controls-results-'+sys.argv[1]+'.json')).open('x',encoding='utf8')as f:json.dump(out,f,indent=2)
print(out)
