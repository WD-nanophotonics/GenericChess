from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,random,hashlib,collections,traceback
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(D/'source'),str(R/'tests'),str(R)]
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import RuleNoProgressDraw
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.terminal import _repeated_cycle_target_history_projection
from generic_chess.core.actions import SemanticDropMove
from scripts.research_record import record_value
from scripts.full_q_refresh_comparison import runtime_state
plan=json.loads((D/'policy-axis-plan.json').read_bytes());start=time.perf_counter();stats=collections.Counter();rows=[];inputs=[];ending='complete'
for z in json.loads((R/'.local_agent/mechanism-mix-20261017/inputs.json').read_bytes())['rows']:
 for axis,(threshold,capture,movers)in enumerate(plan['policy_axes']):
  rule=replace(deserialize_ruleset(json.dumps(z['ruleset'])),no_progress_draw=RuleNoProgressDraw(threshold,capture,tuple(movers)))
  inputs.append({'family':z['family_index'],'axis':axis,'rule':json.loads(serialize_ruleset(rule))})
with(D/'policy-axis-inputs.json').open('x',encoding='utf8')as f:json.dump(inputs,f,indent=2)
def stop():
 if time.perf_counter()-start>plan['whole_seconds']:raise TimeoutError('frozen whole900s cap')
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('project stop')
def snap(rt):return runtime_state(rt),rt._np_context,rt.search_key(),tuple(rt.history)
with(D/'policy-axis-events.jsonl').open('x',encoding='utf8')as log:
 for z in inputs:
  for seed in plan['walk_policies']:
   stop();rng=random.Random(seed+z['family']*100+z['axis']*10000);c=replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(z['rule']))),_legacy_compiled=None);s=GameSession(c);rt=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses,hash_override=7);root=snap(rt);actions=[];branches=[];failure=None
   try:
    while not s.state.terminal_status.is_terminal and s.state.ply_count<plan['max_plies']:
     stop();legal=tuple(sorted(s.legal_actions(),key=repr));assert tuple(sorted(rt.legal_actions(),key=repr))==legal
     # Freeze stochastic action ranks from this policy BEFORE child outcomes.
     picks=rng.sample(range(len(legal)),min(plan['branch_samples_per_parent'],len(legal)));chosen=picks[0]
     for j in picks:
      a=legal[j];before=snap(rt);child=copy(s)
      try:child.submit(a);core_error=None
      except Exception as e:core_error=(type(e).__name__,str(e))
      try:rt.push(a);runtime_error=None
      except Exception as e:runtime_error=(type(e).__name__,str(e))
      assert core_error==runtime_error,(core_error,runtime_error)
      if core_error:
       assert snap(rt)==before;stats['matched_errors']+=1
       if j==chosen:raise ValueError('chosen action has matched authoritative error: '+str(core_error))
       continue
      assert rt.position==child.state.position and rt.terminal_status==child.state.terminal_status and rt.ply_count==child.state.ply_count
      counts,hist=_repeated_cycle_target_history_projection(rt);assert counts==child.state.repetition_counts and hist==child.state.history
      branches.append({'parent_ply':s.state.ply_count,'action':record_value(a),'child':record_value(child.state),'context':rt._np_context})
      stats['full_Core_runtime_children']+=1;stats['promotions']+=getattr(a,'promotion_target_id',None)is not None;stats['drops']+=isinstance(a,SemanticDropMove);stats['np_terminal_children']+=child.state.terminal_status.status.value=='no_progress_draw'
      rt.pop();assert snap(rt)==before;stats['full_undo_checks']+=1
     a=legal[chosen];s.submit(a);rt.push(a);actions.append(record_value(a));stats['chosen_transitions']+=1
     assert rt.position==s.state.position and rt.terminal_status==s.state.terminal_status
    for _ in actions:rt.pop()
    assert snap(rt)==root
   except Exception as e:
    failure={'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()};ending='observed_failure'
   row={'family':z['family'],'axis':z['axis'],'policy_seed':seed,'actions':actions,'final_state':record_value(s.state),'record':record_value(s.to_record()),'all_branch_receipts':branches,'failure':failure,'status':'error'if failure else('terminal'if s.state.terminal_status.is_terminal else'administration24ply_UNKNOWN')}
   rows.append(row);log.write(json.dumps(row)+'\n');log.flush();print('walk',len(rows),row['family'],row['axis'],row['status'],len(actions),flush=True)
   if failure:break
  if ending!='complete':break
out={'complete':len(rows)==72 and ending=='complete','ending':ending,'rows':rows,'stats':dict(stats),'seconds':time.perf_counter()-start,'missing_walks':72-len(rows),'scope':'Controlled policy interventions on exposed mechanism mixtures. Administrative24ply is UNKNOWN, no game rewards/training/strength or universal generic correctness claim.'}
with(D/'policy-axis-results.json').open('x',encoding='utf8')as f:json.dump(out,f,indent=2)
print('DONE',out['complete'],out['stats'],out['seconds'],flush=True)
