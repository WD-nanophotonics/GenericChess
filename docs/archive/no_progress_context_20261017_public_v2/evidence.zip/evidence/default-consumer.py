from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,traceback
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R)]
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.schema import RuleNoProgressDraw
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
start=time.perf_counter();rows=[];plan=json.loads((D/'default-consumer-plan.json').read_bytes())
with(D/'default-consumer-events.jsonl').open('x',encoding='utf8')as f:
 for z in json.loads((R/'.local_agent/mechanism-mix-20261017/inputs.json').read_bytes())['rows']:
  rule=deserialize_ruleset(json.dumps(z['ruleset']));added=rule.no_progress_draw is None
  if added:rule=replace(rule,no_progress_draw=RuleNoProgressDraw(8,True))
  c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c)
  for flag in plan['settings']['requested_native_legality']:
   assert time.perf_counter()-start<plan['whole_seconds']
   for n in('rollout','advisor','slack'):
    v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not v.get('stopped')and not v.get('user_paused')
   before=s.state;w=s._search_witnesses;t=time.perf_counter()
   try:
    player=AlphaBetaPlayer(c,use_disk_cache=False,profile_cache=EvaluationProfileCache(use_disk=False),use_native_semantic_legality=flag,tt_max_entries=10000);init=time.perf_counter()-t;t=time.perf_counter();r=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-t;pv=copy(s);states=[]
    for a in r.principal_variation:pv.submit(a);states.append(record_value(pv.state))
    assert r.action in s.legal_actions()and s.state is before and s._search_witnesses is w
    row={'family':z['family_index'],'requested_native_legality':flag,'actual_provider_created':player.native_legality_provider is not None,'actual_search_backend':'Core','status':'returned','initialization_seconds':init,'choose_seconds':elapsed,'default_profile_present':player.evaluation_profile is not None,'decision':record_value(r),'full_PV_states':states,'full_root':record_value(s.state),'parent_preserved':True,'explicitly_added_np_to_pass_rule':added}
   except Exception as e:row={'family':z['family_index'],'requested_native_legality':flag,'status':'error','error':{'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()}}
   rows.append(row);f.write(json.dumps(row)+'\n');f.flush();print(z['family_index'],flag,row['status'],None if row['status']=='error'else(r.completed_depth,round(elapsed,3)),flush=True)
out={'complete':len(rows)==24,'rows':rows,'errors':sum(x['status']=='error'for x in rows),'seconds':time.perf_counter()-start,'scope':'Actual existing default profile/evaluation/ordering consumer on exposed rule mixtures, q0limit specified. No default/profile/Native policy change, no training or WDL.'}
with(D/'default-consumer-results.json').open('x',encoding='utf8')as f:json.dump(out,f,indent=2)
print('DONE',out['errors'],out['seconds'],flush=True)
