from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,collections
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(D/'source'),str(R/'tests'),str(R)]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.schema import RuleNoProgressDraw
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
from generic_chess.core.terminal import _repeated_cycle_target_history_projection
from generic_chess.core.adjudication import no_progress_draw_status
from scripts.research_record import record_value
from scripts.full_q_refresh_comparison import runtime_state
start=time.perf_counter();stats=collections.Counter();cases=[];cap=300

def stop():
 assert time.perf_counter()-start<cap
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def snapshot(rt):return runtime_state(rt),rt._np_context,rt.search_key(),tuple(rt.history)
def check(s,rt,a):
 stop();before=snapshot(rt);child=copy(s);child.submit(a);rt.push(a)
 assert rt.position==child.state.position and rt.terminal_status==child.state.terminal_status and rt.ply_count==child.state.ply_count
 counts,hist=_repeated_cycle_target_history_projection(rt);assert counts==child.state.repetition_counts and hist==child.state.history
 stats['runtime_Core_fullstate_children']+=1
 if getattr(a,'promotion_target_id',None) is not None:stats['promotion_children']+=1
 if isinstance(a,SemanticDropMove):stats['drop_children']+=1
 rt.pop();assert snapshot(rt)==before;stats['full_undo_checks']+=1
 return child
# ALL12 existing genuine composites, plus actual capture/reply/drop records.
inputs=json.loads((R/'.local_agent/mechanism-mix-20261017/inputs.json').read_bytes())['rows'];old=json.loads((R/'.local_agent/no-progress-counter-20261017/results.json').read_bytes())
for row in inputs:
 rule=deserialize_ruleset(json.dumps(row['ruleset']));added=rule.no_progress_draw is None
 if added:rule=replace(rule,no_progress_draw=RuleNoProgressDraw(8,True))
 c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c);rt=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses,hash_override=7)
 for a in s.legal_actions():check(s,rt,a)
 witness=next(z for z in old['cases']if z.get('family_index')==row['family_index'])
 chain=witness['capture_reply_drop']
 if chain:
  for edge in chain['edges']:
   a=decode(edge['action']);ch=check(s,rt,a);rt.push(a);s=ch
   assert record_value(s.state)==edge['fullstate']
  stats['capture_reply_drop_records']+=1
 cases.append({'family_index':row['family_index'],'new_np_policy_for_even_only':added,'initial_count':len(GameSession(c).legal_actions()),'chain_steps':len(chain['edges'])if chain else 0})
 print('family',row['family_index'],dict(stats),flush=True)
# Actual complete1024record: compare every position/history to immutable
# NP-disabled replay; exact authoritative NP checked at128/512/1024. Its reset
# counter remains<6 throughout; no state/history/action omission.
z=json.loads((R/'.local_agent/no-progress-prototype-20261017/long-prefix-1024.json').read_bytes());c=replace(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset']))),_legacy_compiled=None);off=replace(c,support=replace(c.support,no_progress_draw=None));s=GameSession(off);rt=SearchPathRuntime(GameSession(c).state,c,history_witnesses=GameSession(c)._search_witnesses,hash_override=7);initial=snapshot(rt);long=[]
for i,v in enumerate(z['record']['actions'],1):
 stop();a=decode(v);s.submit(a);rt.push(a)
 assert rt.position==s.state.position and rt.ply_count==s.state.ply_count and rt.terminal_status==s.state.terminal_status
 assert rt._np_context[0]<6 and rt._np_context[1] is None
 if i in(128,512,1024):
  counts,hist=_repeated_cycle_target_history_projection(rt);assert counts==s.state.repetition_counts and hist==s.state.history
  assert no_progress_draw_status(c.no_progress_draw,s.state.position,i,s.state.repetition_counts,s.state.history,c) is None
  long.append({'ply':i,'context':rt._np_context,'history':len(hist),'public_key_counts_equal':True})
assert record_value(s.state)==z['state']
for i in range(1024):rt.pop()
assert snapshot(rt)==initial;stats['long_pushes']=stats['long_pops']=1024
out={'complete':True,'stats':dict(stats),'cases':cases,'long':long,'seconds':time.perf_counter()-start,'scope':'All12retained semantic mixtures, actual chains and1024real record; not new unseen families, generic proof, independent WDL or actual caller hardtimer qualification.'}
with(D/'coverage-results.json').open('x',encoding='utf8')as f:json.dump(out,f,indent=2)
print('DONE',out['stats'],out['seconds'],flush=True)
