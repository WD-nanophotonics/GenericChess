from pathlib import Path
from dataclasses import replace
import sys,json,time,ast
R=Path.cwd();D=Path(__file__).resolve().parent;arm=sys.argv[1];S=D/('product-source'if arm=='v3'else'v4-source');sys.path[:0]=[str(S),str(R)]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.terminal import _repeated_cycle_target_history_projection
from generic_chess.session.session import GameSession
from scripts.research_record import record_value
parts=[n for n in ast.parse((D/'callers.py').read_text(encoding='utf8')).body if isinstance(n,ast.FunctionDef)and n.name=='decode'];exec(compile(ast.Module(body=parts,type_ignores=[]),'frozen-decode','exec'))
z=json.loads((R/'.local_agent/no-progress-prototype-20261017/long-prefix-512.json').read_bytes());c=replace(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset']))),_legacy_compiled=None);off=replace(c,support=replace(c.support,no_progress_draw=None));s=GameSession(off)
for a in z['record']['actions']:s.submit(decode(a))
assert record_value(s.state)==z['state'];s._compiled=c;rows=[];start=time.perf_counter()
for supplied in(False,True):
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
 t=time.perf_counter();rt=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses if supplied else None);elapsed=time.perf_counter()-t;assert elapsed<180
 counts,hist=_repeated_cycle_target_history_projection(rt);assert counts==s.state.repetition_counts and hist==s.state.history and rt.terminal_status==s.state.terminal_status
 rows.append({'supplied':supplied,'seconds':elapsed,'full_history_length':len(hist),'reconstruction_attempts':rt.history_reconstruction_attempts,'exact_fullstate_history_counts_preserved':True,'counter':record_value(rt._no_progress_context)});print(arm,supplied,elapsed,flush=True)
with(D/f'witnessless-{arm}-results.json').open('x',encoding='utf8')as f:json.dump({'complete':True,'rows':rows,'seconds':time.perf_counter()-start,'scope':'Actual optional from_state import, not full caller speedup. Caller budgets are checked after this currently indivisible root construction.'},f,indent=2)
