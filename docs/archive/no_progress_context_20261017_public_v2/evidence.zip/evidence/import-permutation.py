from pathlib import Path
from dataclasses import replace
import sys,json
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(D/'source'),str(R)]
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.actions import SemanticBoardMove
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
z=json.loads((R/'.local_agent/no-progress-prototype-20261017/controls.json').read_bytes());c=replace(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset']))),_legacy_compiled=None);s=GameSession(c)
for a in z['counter_controls'][0]['record']['actions']:s.submit(SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id']))
w=list(s._search_witnesses);w[1],w[2]=w[2],w[1]
try:r=SearchPathRuntime(s.state,c,history_witnesses=w);out={'forged_witness_admitted':True,'counter':r._np_context,'history_length':len(r.history)}
except Exception as e:out={'forged_witness_admitted':False,'error':{'type':type(e).__name__,'message':str(e)}}
with(D/('import-negative-'+sys.argv[1]+'.json')).open('x',encoding='utf8')as f:json.dump(out,f,indent=2)
print(out)
