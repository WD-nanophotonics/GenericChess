from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,traceback
R=Path.cwd();D=Path(__file__).resolve().parent;arm=sys.argv[1];source=D/'source' if arm.startswith('context') else R/'.local_agent/no-progress-prototype-20261017/source';sys.path[:0]=[str(source),str(R/'tests'),str(R)]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value

def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
class Constant:
 def evaluate(self,state):return 77
 def type_value(self,t):return 0 if t=='K'else 1000
 def capture_order_value(self,moving,captured):return 10*self.type_value(captured.current_type_id)-self.type_value(moving.current_type_id)
plan=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();roots=[]
x=json.loads((R/'.local_agent/no-progress-prototype-20261017/controls.json').read_bytes())
for row in x['counter_controls']:roots.append({'label':row['label'],'ruleset':x['ruleset'],'record':row['record'],'state':row['parent']})
for n in (128,512,1024):
 z=json.loads((R/f'.local_agent/no-progress-prototype-20261017/long-prefix-{n}.json').read_bytes());roots.append(dict(z,label=f'prefix{n}'))
inputs=json.loads((R/'.local_agent/mechanism-mix-20261017/inputs.json').read_bytes())['rows'];fr=next(z for z in json.loads((R/'.local_agent/mechanism-mix-20261017/frontiers.json').read_bytes()) if z['family_index']%2 and z['ply']==4 and not z.get('absent_search'));rule=next(z['ruleset']for z in inputs if z['family_index']==fr['family_index']);roots.append({'label':f"mix{fr['family_index']}",'ruleset':rule,'record':fr['record'],'state':fr['full_state']})
rows=[]
with(D/f'{arm}-events.jsonl').open('x',encoding='utf8')as log:
 for root in roots:
  t=time.perf_counter();rule=deserialize_ruleset(json.dumps(root['ruleset']));c=replace((compile_semantic_ruleset(rule) if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule)),_legacy_compiled=None)
  # Reconstruct frozen long input under NP-disabled view only; exact full-state
  # equality is required before restoring policy. Not reported as NP execution.
  replay_c=replace(c,support=replace(c.support,no_progress_draw=None)) if root['label'].startswith('prefix') else c
  s=GameSession(replay_c)
  for a in root['record']['actions']:s.submit(decode(a))
  assert record_value(s.state)==root['state'];s._compiled=c;prep=time.perf_counter()-t
  for tt in plan['TT']:
   assert time.perf_counter()-start<plan['whole_seconds']
   for n in('rollout','advisor','slack'):
    f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
   before=s.state;w=s._search_witnesses;t=time.perf_counter()
   try:
    player=AlphaBetaPlayer(c,evaluator_override=Constant(),use_disk_cache=False,use_tt=tt,tt_max_entries=10000,use_ordering=False,use_native_semantic_legality=False)
    result=player.choose_action(s,SearchLimits(max_depth=plan['depth'],max_nodes=plan['nodes'],max_time_seconds=plan['call_seconds'],quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t
    pv=copy(s);states=[]
    for a in result.principal_variation:pv.submit(a);states.append(record_value(pv.state))
    row={'arm':arm,'label':root['label'],'TT':tt,'status':'returned','seconds':wall,'input_preparation_seconds':prep,'decision':record_value(result),'full_PV_states':states,'parent_preserved':s.state is before and s._search_witnesses is w,'history_length':len(s.state.history),'root':record_value(s.state)}
   except Exception as e:row={'arm':arm,'label':root['label'],'TT':tt,'status':'error','seconds':time.perf_counter()-t,'error':{'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()}}
   rows.append(row);log.write(json.dumps(row)+'\n');log.flush();print(arm,root['label'],tt,row['status'],round(row['seconds'],3),None if row['status']=='error'else result.completed_depth,flush=True)
with(D/f'{arm}-results.json').open('x',encoding='utf8')as f:json.dump({'complete':len(rows)==12,'rows':rows,'seconds':time.perf_counter()-start,'scope':'Frozen fresh paired caller costs; no new games/fit, no original timing rerun claim, no Native execution.'},f,indent=2)
