from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,collections
D=Path(__file__).resolve().parent;R=D.parents[1];S=D/'publication-source';sys.path[:0]=[str(S),str(S/'tests')]
import generic_chess
assert Path(generic_chess.__file__).resolve().is_relative_to(S.resolve())
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.terminal import _repeated_cycle_target_history_projection
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from scripts.research_record import record_value

def prohibited(*args,**kwargs):raise AssertionError('Source reader must not execute search or training')
AlphaBetaPlayer.choose_action=prohibited

def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def snap(rt):return rt.position,rt.ply_count,rt.terminal_status,rt.search_key(),tuple(rt.history),dict(rt.repetition_counts),rt._no_progress_context
start=time.perf_counter();stats=collections.Counter();inputs={(x['family'],x['axis']):x for x in json.loads((D/'product-policy-axis-inputs.json').read_bytes())};rows=json.loads((D/'product-policy-axis-results.json').read_bytes())['rows']
for row in rows:
 for n in('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not z.get('stopped')and not z.get('user_paused')
 assert time.perf_counter()-start<300
 rule=inputs[row['family'],row['axis']]['rule'];c=replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(rule))),_legacy_compiled=None);s=GameSession(c);rt=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses,hash_override=7);initial=snap(rt);branches=collections.defaultdict(list)
 for b in row['all_branch_receipts']:branches[b['parent_ply']].append(b)
 for selected in row['actions']:
  for b in branches[s.state.ply_count]:
   a=decode(b['action']);child=copy(s);child.submit(a);assert record_value(child.state)==b['child'];before=snap(rt);rt.push(a)
   assert rt.position==child.state.position and rt.terminal_status==child.state.terminal_status
   counts,hist=_repeated_cycle_target_history_projection(rt);assert counts==child.state.repetition_counts and hist==child.state.history
   assert record_value(rt._no_progress_context)==b['context'];rt.pop();assert snap(rt)==before;stats['all_branch_fullstates']+=1
  a=decode(selected);s.submit(a);rt.push(a);assert rt.position==s.state.position and rt.terminal_status==s.state.terminal_status;stats['chosen_fullstates']+=1
 assert record_value(s.state)==row['final_state']and record_value(s.to_record())==row['record']
 for _ in row['actions']:rt.pop()
 assert snap(rt)==initial;stats['root_fullstates_and_undo']+=1
print('SOURCE_READER_POLICY',dict(stats),flush=True)
# Also check all recorded selected full PV states from the nonzero-q controls;
# q search itself is never re-executed.
base={z['family_index']:z for z in json.loads((R/'.local_agent/mechanism-mix-20261017/inputs.json').read_bytes())['rows']}
from generic_chess.rules.schema import RuleNoProgressDraw
for row in json.loads((D/'q-boundary-results.json').read_bytes())['rows']:
 assert row['status']=='returned'
 movers=()if row['threshold']==2 else('TP',)
 rule=replace(deserialize_ruleset(json.dumps(base[row['family']]['ruleset'])),no_progress_draw=RuleNoProgressDraw(row['threshold'],row['reset_capture'],movers));c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c)
 for a,expected in zip(row['decision']['principal_variation'],row['full_PV_states']):s.submit(decode(a));assert record_value(s.state)==expected;stats['q_caller_PV_fullstates']+=1
 stats['q_caller_receipts']+=1
out={'complete':True,'source_search_disabled':True,'stats':dict(stats),'seconds':time.perf_counter()-start,'scope':'Exact selected source/public-state/history/undo receipt replay. No old wall clock, search, fit, solver, independent WDL or unseen-rule claim.'}
with(D/'source-reader-public-results.json').open('x',encoding='utf8')as f:json.dump(out,f,indent=2)
print('DONE',out,flush=True)
