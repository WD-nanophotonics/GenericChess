from pathlib import Path
import subprocess,sys,time,json,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;R=Path.cwd();base=D/'qualified-full-tmp';assert not base.exists();start=time.perf_counter();cmd=[sys.executable,'-m','pytest','-o','addopts=','-o','cache_dir='+str(D/'qualified-full-cache'),'--basetemp='+str(base),'-q']
files=[Path('generic_chess/core')/n for n in('no_progress_context.py','adjudication.py','identity.py','search_runtime.py','terminal.py')]+[Path('generic_chess/ai/alphabeta/player.py'),Path('generic_chess/ai/evaluation/profile.py')]
bind={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files};write_json(D/'qualified-source-binding.json',bind)
with(D/'qualified-full.log').open('x',encoding='utf8')as log:
 proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT);write_json(D/'qualified-full-owned-process.json',{'pid':proc.pid,'command':cmd})
 try:
  while proc.poll()is None:
   if time.perf_counter()-start>900:raise TimeoutError('whole900s regression limit')
   for n in('rollout','advisor','slack'):
    z=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
    if z.get('stopped')or z.get('user_paused'):raise InterruptedError('project stop')
   try:proc.wait(timeout=2)
   except subprocess.TimeoutExpired:pass
 except BaseException:proc.terminate();proc.wait(timeout=10);raise
assert bind=={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
write_json(D/'qualified-full-result.json',{'returncode':proc.returncode,'seconds':time.perf_counter()-start,'all_default_four_layers':True,'omissions':[],'source_binding':'qualified-source-binding.json'})
print('QUALIFIED_FULL',proc.returncode,time.perf_counter()-start);print((D/'qualified-full.log').read_text(encoding='utf8')[-7000:])
