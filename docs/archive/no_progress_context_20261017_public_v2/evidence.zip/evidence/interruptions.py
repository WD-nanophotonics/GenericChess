from pathlib import Path
from dataclasses import replace
import sys,json,time,ast
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(D/'source'),str(R)]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core import no_progress_context as npc
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from scripts.research_record import record_value
parts=[n for n in ast.parse((D/'callers.py').read_text(encoding='utf8')).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in('decode','Constant')];exec(compile(ast.Module(body=parts,type_ignores=[]),'frozen-shared-definitions','exec'))
z=json.loads((R/'.local_agent/no-progress-prototype-20261017/long-prefix-1024.json').read_bytes());c=replace(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset']))),_legacy_compiled=None);off=replace(c,support=replace(c.support,no_progress_draw=None));s=GameSession(off)
for a in z['record']['actions']:s.submit(decode(a))
assert record_value(s.state)==z['state'];s._compiled=c
limits=SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0)
oldadvance=npc.advance;oldprepare=npc.prepare;oldfactory=SearchPathRuntime.from_state;rows=[];captured=[]
def record_factory(cls,*args,**kwargs):
 rt=oldfactory(*args,**kwargs);captured.append(rt);return rt
SearchPathRuntime.from_state=classmethod(record_factory)
for mode in ('pre_cancel','during_root_replay','after_child_context','fake_root_deadline'):
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
  
 token=CancellationToken();fired=[];count=[0];inroot=[False];offset=[0.0];original_clock=time.monotonic
 def advance(*args,**kwargs):
  result=oldadvance(*args,**kwargs);count[0]+=1
  if (mode=='during_root_replay'and inroot[0]and count[0]==1)or(mode=='after_child_context'and not inroot[0]and not fired):
   fired.append(time.perf_counter());token.cancel()
  return result
 def prepare(*args,**kwargs):
  inroot[0]=True
  try:return oldprepare(*args,**kwargs)
  finally:
   inroot[0]=False
   if mode=='fake_root_deadline':offset[0]=10.0;fired.append(time.perf_counter())
 npc.advance=advance;npc.prepare=prepare
 if mode=='pre_cancel':token.cancel();fired.append(time.perf_counter())
 if mode=='fake_root_deadline':time.monotonic=lambda:original_clock()+offset[0]
 before=s.state;w=s._search_witnesses;t=time.perf_counter()
 try:
  r=AlphaBetaPlayer(c,evaluator_override=Constant(),use_disk_cache=False,use_tt=False,use_ordering=False,use_native_semantic_legality=False).choose_action(s,limits,cancel_token=token)
 finally:time.monotonic=original_clock;npc.advance=oldadvance;npc.prepare=oldprepare
 assert r.termination_reason==('time_limit'if mode=='fake_root_deadline'else'cancelled')
 assert r.action in s.legal_actions()and s.state is before and s._search_witnesses is w
 rt=captured[-1];rt.assert_balanced();assert rt.position==s.state.position and len(rt.history)==1025
 rows.append({'mode':mode,'reason':r.termination_reason,'depth':r.completed_depth,'seconds':time.perf_counter()-t,'event_to_return_seconds':time.perf_counter()-fired[0],'history_length':len(rt.history),'balanced':True,'decision':record_value(r),'root_replay_indivisible':True})
SearchPathRuntime.from_state=oldfactory
# Caller may not import forged ONGOING for a real no-progress terminal.
base=json.loads((R/'.local_agent/no-progress-prototype-20261017/controls.json').read_bytes());cc=replace(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(base['ruleset']))),_legacy_compiled=None);q=GameSession(cc)
for a in base['counter_controls'][0]['record']['actions']:q.submit(decode(a))
a=next(a for a in q.legal_actions()if getattr(a,'from_square',None)==Square(0,0));q.submit(a);assert q.state.terminal_status.status==TerminalStatus.NO_PROGRESS_DRAW
forged=replace(q.state,terminal_status=TerminalResult(TerminalStatus.ONGOING))
try:SearchPathRuntime(forged,cc,history_witnesses=q._search_witnesses)
except ValueError as e:forged_error=str(e)
else:raise AssertionError('forged terminal admitted')
out={'complete':True,'calls':4,'rows':rows,'forged_ongoing_root_refused':forged_error,'scope':'Actual caller cancellation and fake-clock controls on1024real history, not a hard deadline or bound on longer/more expensive root replay.'}
with(D/'interruptions-results.json').open('x',encoding='utf8')as f:json.dump(out,f,indent=2)
print({k:v for k,v in out.items()if k!='rows'});print([(x['mode'],x['reason'],round(x['event_to_return_seconds'],4))for x in rows])
