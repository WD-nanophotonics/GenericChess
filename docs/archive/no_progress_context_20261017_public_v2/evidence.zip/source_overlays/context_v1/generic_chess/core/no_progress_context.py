"""PRIVATE feasibility source; no production activation or reduced history key."""
from dataclasses import replace
import json
from .adjudication import IncompleteAdjudicationHistoryError as Error
from .actions import action_from_dict,action_is_board,action_source_square
from .coordinates import square_to_index


def advance(context,before,after,action,policy,ply):
    count,error=context
    if error is not None:
        return context
    mover=None
    if action_is_board(action):
        source=action_source_square(action)
        if source is None:
            return count,f"no-progress history action {ply} has no source square"
        piece=before.board[square_to_index(source,before.board_shape)]
        if piece is None or piece.owner!=before.side_to_move:
            return count,f"no-progress history mover is unknown at action {ply}"
        mover=piece.current_type_id
    capture=False
    if policy.reset_on_capture:
        totals=lambda p:[sum(z is not None and z.owner==o for z in p.board)+p.hands[o].total() for o in (0,1)]
        b=totals(before);a=totals(after);actor=before.side_to_move
        delta=[a[o]-b[o] for o in (0,1)]
        if delta[1-actor]<0 and delta[actor] in (0,-delta[1-actor]):
            capture=True
        elif any(delta):
            return count,f"no-progress history capture fact is ambiguous at action {ply}"
    return (0 if capture or mover in policy.reset_mover_type_ids else count+1),None


def prepare(state,compiled):
    # Root authority is checked ONCE; local children retain full runtime history.
    # Root preparation is currently indivisible with respect to caller token.
    policy=compiled.no_progress_draw
    if policy is None:return None
    h=state.history
    if not isinstance(h,(tuple,list)) or len(h)!=state.ply_count+1 or not h or h[0].actor!=-1:
        raise Error("no-progress context requires complete initial history")
    replay_compiled=replace(compiled,support=replace(compiled.support,no_progress_draw=None)) if hasattr(compiled,'support') else replace(compiled,no_progress_draw=None)
    from .transition import initial_state,apply_action
    replay=initial_state(replay_compiled)
    if replay.history[0]!=h[0]:
        setups=replay_compiled.support.initial_setup_options if hasattr(replay_compiled,'support') else replay_compiled.initial_setup_positions
        for key in setups:
            candidate=initial_state(replay_compiled,key)
            if candidate.history[0]==h[0]:replay=candidate;break
        else:raise Error("no-progress history root is not a declared initial setup")
    context=(0,None)
    for ply,record in enumerate(h[1:],1):
        action=action_from_dict(json.loads(record.action_signature))
        before=replay.position;replay=apply_action(replay,action,replay_compiled)
        if replay.history[-1]!=record:raise Error(f"no-progress history action {ply} does not replay exactly")
        context=advance(context,before,replay.position,action,policy,ply)
    if replay.position!=state.position or replay.ply_count!=state.ply_count or replay.repetition_counts!=tuple(state.repetition_counts):
        raise Error("no-progress history does not reconstruct the supplied state")
    return context


def status(runtime):
    policy=runtime.compiled.no_progress_draw
    if policy is None or runtime.ply_count<policy.threshold_plies:return None
    count,error=runtime._np_context
    if error is not None:raise Error(error)
    return policy.outcome if count>=policy.threshold_plies else None
