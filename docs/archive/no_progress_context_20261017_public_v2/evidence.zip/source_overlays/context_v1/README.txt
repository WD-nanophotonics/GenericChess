Apply replay_baseline overlay then these3 context_v1 files. It retains the actual witness-permutation admission failure. Do not activate it.
