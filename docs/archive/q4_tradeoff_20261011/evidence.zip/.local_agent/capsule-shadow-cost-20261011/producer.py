import ast,collections,hashlib,json,random,sys,time
from pathlib import Path
src=Path('.local_agent/native_capsule_q4.py').read_text(encoding='utf-8');exec(src.split('B=Path(')[0],globals());cl=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef));exec(compile(ast.Module(body=[cl],type_ignores=[]),'<capsule-runtime>','exec'),globals())
from generic_chess.core.search_runtime import SearchPathRuntime
class CoreTerminalCapsule(CapsuleRuntime):
 def __init__(self,initial,c,witnesses):
  self.shadow=SearchPathRuntime(initial,c,history_witnesses=witnesses);super().__init__(initial,c,witnesses)
 @property
 def terminal_status(self):return self.shadow.terminal_status
 def push(self,a,checkpoint=None):
  super().push(a,checkpoint);self.shadow.push(a,checkpoint=checkpoint)
 def pop(self):self.shadow.pop();super().pop()
 def assert_balanced(self):super().assert_balanced();self.shadow.assert_balanced()
B=Path('.local_agent/capsule-shadow-cost-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
d=dict(depth=1,q=4,hardq=8,nodes=32768,seconds=60)
write_record(B/'declaration.json',dict(question='Does preservingCore terminal authority through dual runtime retain a useful capsule cost advantage, or duplicate the dominant work?',root='seed1008-ply8',calls=2,limits=d,driver='unchanged lexical q4 recursion/Python frozen leaf',scope='Finite changed-premise dualexecution diagnostic, not interleaved benchmark or productfallback; allconversion included',decision='Exact matched work is required. Measured cost selects whether to pursue dualbridge or mechanical terminal-policy support; no default/cap changes',expected_seconds='~40s, under1h'))
fn=json.loads(Path('.local_agent/native-capsule-q4-20261011/driver.json').read_bytes())['changed_function'].replace('rt = CapsuleRuntime(initial, c, witnesses)','rt = CoreTerminalCapsule(initial, c, witnesses)');exec(fn,globals())
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec);s=p.GameSession(c);rng=random.Random(8008)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
rows=[]
for order in range(2):
 p.rr.stopped();v=search(c,s.state,s._search_history_witnesses,ev,True);rows.append(dict(order=order,**v));write_record(B/'result.json',dict(complete=False,rows=rows));print(order,v['reason'],v['wall'],flush=True)
ref=next(x for x in json.loads(Path('.local_agent/native-capsule-q4-20261011/result.json').read_bytes())['rows'] if x['root']=='seed1008-ply8' and x['depth']==1)
for r in rows:
 for k in ('work','score','action','trace'):assert r[k]==ref[k]
write_record(B/'result.json',dict(complete=True,rows=rows,all_exact=True))
