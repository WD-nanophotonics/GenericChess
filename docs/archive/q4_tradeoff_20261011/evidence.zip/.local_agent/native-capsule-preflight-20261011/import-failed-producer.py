"""Bounded Native-capsule transition bridge with unchanged Python lexicalq4.
C state/history/terminal retained; Python frozen evaluator reconstructed from snapshot.
"""
import ast,collections,hashlib,json,random,sys,time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.quiescence import enemy_board_count,material_inventory,noisy_child
from generic_chess.ai.alphabeta.search import INF,terminal_score
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.core.position import Position,Hands
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position,pack_semantic_action
from generic_chess.native import semantic as ns
B=Path('.local_agent/native-capsule-q4-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('Frozen output exists')
d=dict(question='Can existing Native full-state/checked-transition APIs remove dominant Core push/identity cost without changing the tested lexicalq4 work or frozen Python leaf evaluator?',roots=['seed1006-ply0','seed1006-ply8','seed1008-ply0','seed1008-ply8'],depths=[1,2],q=4,hardq=8,nodes=100000,seconds=90,orders=2,calls=16,maximum_seconds=1440,expected_seconds='~2-10min, interruptible, under1h',scope='Post-exposure finite capsule adapter, not full-Native searchkernel, productfallback, q4 support certification or full generated-domain proof. C history/aux/terminal preserved; Python evaluator unchanged and full Position snapshot reconstructed, conversion charged. Cached views are per immutable capsule, not search transpositions. Pops restore retained parent capsules, not measured C unmake.',decision='Require exact work/trace/action/score match with fixed-driver recordedCore/Native-legality at same depth. Mismatch is semantic/algorithm failure, not speedup. If matched and faster, consider Native state interface before costly fullkernel q4 work; no default changes.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
class CapsuleRuntime:
 def __init__(self,initial,c,witnesses):
  self.compiled=c;self.native=compile_native_semantic_rules(c);self.capsule=pack_semantic_search_position(c,self.native,SimpleNamespace(compiled=c,state=initial,_search_witnesses=witnesses));self.cache=None;self.term=None;self.stack=[];self.legal_provider_calls=0;self.legal_provider_fallbacks=0;self.legal_provider_operational_failures=0;self.views=0;self.transitions=0;self.rawmap={};assert self.position==initial.position and self.terminal_status==initial.terminal_status
 def attach_stats(self,stats):self.stats=stats
 def full_snapshot(self):return ns.snapshot(self.native,self.capsule)
 @property
 def position(self):
  if self.cache is None:
   s=self.full_snapshot();ids=self.native.type_ids
   board=tuple(None if x is None else Piece(int(x[2]),ids[int(x[0])],ids[int(x[1])],bool(x[3])) for x in s['board']);hands=tuple(Hands(tuple(sorted((ids[i],int(v)) for i,v in enumerate(h) if v))) for h in s['hands']);self.cache=Position(board,hands,int(s['side']),self.compiled.ruleset_fingerprint,s['aux_state']);self.ply_count=int(s['ply']);self.views+=1
  return self.cache
 @property
 def terminal_status(self):
  if self.term is None:
   t=ns.terminal_status(self.native,self.capsule);self.term=TerminalResult(TerminalStatus(t['status']),t['winner'])
  return self.term
 @property
 def state(self):return SimpleNamespace(position=self.position,terminal_status=self.terminal_status,ply_count=self.ply_count)
 def in_check(self,owner,checkpoint=None):
  if checkpoint:checkpoint()
  return ns.in_check(self.native,self.capsule,owner)
 def legal_actions(self,checkpoint=None):
  if checkpoint:checkpoint()
  self.legal_provider_calls+=1;raw=ns.transient_legal_actions(self.native,self.capsule);self.rawmap={ns.public_action(self.native,a):a for a in raw};return tuple(self.rawmap)
 def push(self,action,checkpoint=None):
  if checkpoint:checkpoint()
  raw=self.rawmap[action] if action in self.rawmap else pack_semantic_action(self.native,self.position,action)
  old=(self.capsule,self.cache,self.term,self.rawmap)
  child=ns.make_checked(self.native,self.capsule,raw);self.stack.append(old);self.capsule=child;self.cache=self.term=None;self.rawmap={};self.transitions+=1
 def pop(self):self.capsule,self.cache,self.term,self.rawmap=self.stack.pop()
 def assert_balanced(self):assert not self.stack
source=Path('.local_agent/generated_thin_q4.py').read_text();fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='search');code=ast.unparse(fn).replace('rt = SearchPathRuntime(initial, c, history_witnesses=witnesses, legal_binding_provider=provider)','rt = CapsuleRuntime(initial, c, witnesses)').replace('p.runtime_state(rt)','rt.full_snapshot()');assert 'SearchPathRuntime(' not in code
exec(compile(code,'<native-capsule-driver>','exec'),globals())
write_record(B/'driver.json',dict(original_function_sha256=hashlib.sha256(ast.unparse(fn).encode()).hexdigest(),changed_function=code,only_change='Runtime construction/restoration witness; recursion, scores, qpolicy and lexical ordering unchanged'))
original=json.loads(Path('.local_agent/q4-prospective-20261011-repaired/samples.json').read_bytes())['samples'];roots=[]
for seed in (1006,1008):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec);s=p.GameSession(c);rng=random.Random(seed+7000)
 for ply in range(9):
  if ply in (0,8):
   name=f'seed{seed}-ply{ply}';old=next(x for x in original if x.get('root')==name);assert record_value(s.state)==old['initial'] and record_value(profile)==old['profile'];roots.append((name,c,s.state,s._search_history_witnesses,ev))
  if ply<8:s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
rows=[]
for name,c,initial,w,ev in roots:
 for depth in d['depths']:
  d['depth']=depth
  for order in range(2):
   p.rr.stopped();start=time.perf_counter();v=search(c,initial,w,ev,True);caller=time.perf_counter()-start;rows.append(dict(root=name,depth=depth,order=order,backend='Native full-state capsules + Python lexicalq4 + frozen Python evaluator',caller_seconds=caller,**v));write_record(B/'result.json',dict(complete=False,rows=rows));print(name,depth,order,v['reason'],v['score'],v['work'],round(v['wall'],3),flush=True)
write_record(B/'result.json',dict(complete=True,rows=rows))