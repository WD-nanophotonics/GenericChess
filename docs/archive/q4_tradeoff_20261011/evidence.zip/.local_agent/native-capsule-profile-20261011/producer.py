import ast,cProfile,json,pstats
from pathlib import Path
src=Path('.local_agent/native_capsule_q4.py').read_text(encoding='utf-8');exec(src.split("B=Path(")[0],globals());tree=ast.parse(src);cl=next(n for n in tree.body if isinstance(n,ast.ClassDef));exec(compile(ast.Module(body=[cl],type_ignores=[]),'<capsule-runtime>', 'exec'),globals());exec(json.loads(Path('.local_agent/native-capsule-q4-20261011/driver.json').read_bytes())['changed_function'],globals())
B=Path('.local_agent/native-capsule-profile-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
d=dict(depth=1,q=4,hardq=8,nodes=32768,seconds=60)
write_record(B/'declaration.json',dict(question='After capsule state substitution, does frozen Python leaf reconstruction/evaluation dominate the residual work?',calls=1,root='seed1008-ply8',limits=d,scope='Instrumented finite diagnosis; overlapping inclusive spans and profiler overhead, not speed controls or product certification',decision='Choose leaf-boundary or recursive dispatch optimization only if measured dominant; no default adoption'))
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec);s=p.GameSession(c);rng=random.Random(8008)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
p.rr.stopped();prof=cProfile.Profile();prof.enable()
try:r=search(c,s.state,s._search_history_witnesses,ev,True)
finally:prof.disable();prof.dump_stats(str(B/'profile.pstats'))
pst=pstats.Stats(prof);rows=[dict(file=k[0],line=k[1],function=k[2],primitive_calls=v[0],calls=v[1],exclusive_seconds=v[2],inclusive_seconds=v[3]) for k,v in pst.stats.items()];rows.sort(key=lambda x:x['exclusive_seconds'],reverse=True);write_record(B/'result.json',dict(complete=True,search=r,total_calls=pst.total_calls,profile_total_seconds=pst.total_tt,functions=rows));print(r['reason'],r['wall'],rows[:12],flush=True)
