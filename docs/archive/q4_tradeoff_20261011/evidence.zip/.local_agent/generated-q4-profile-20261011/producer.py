"""One post-exposure profile; instrumentation clocks are not speed controls."""
import ast,collections,cProfile,hashlib,json,pstats,random,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.quiescence import enemy_board_count,material_inventory,noisy_child
from generic_chess.ai.alphabeta.search import INF,terminal_score
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.statistics import SearchStatistics
B=Path('.local_agent/generated-q4-profile-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('Frozen output exists')
write_record(B/'declaration.json',dict(question='Native legality occupies1.91 of12.50s in matchedD1 seed1008-ply8; which remaining function family dominates measured driver work?',root='seed1008-ply8',native_requested=True,driver='exact AST of completed D1 search()',depth=1,q=4,hardq=8,nodes=32768,seconds=60,calls=1,scope='Instrumented post-exposure diagnosis, not exclusive timing/performance comparison. Inclusive function clocks overlap; profiler overhead can change deadline completion.',decision='Use the dominant family to choose a concrete transition/identity/evaluation investigation; do not infer a speedup, alter defaults or retry until complete.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
d=json.loads(Path('.local_agent/generated-thin-q4-20261011/declaration.json').read_bytes())
source=Path('.local_agent/generated_thin_q4.py').read_text();fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='search');exec(compile(ast.Module(body=[fn],type_ignores=[]),'<frozen-generated-driver>','exec'),globals())
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec);s=p.GameSession(c);rng=random.Random(8008)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
p.rr.stopped();prof=cProfile.Profile();prof.enable()
try:r=search(c,s.state,s._search_history_witnesses,ev,True)
finally:prof.disable();prof.dump_stats(str(B/'profile.pstats'))
pst=pstats.Stats(prof);rows=[dict(file=k[0],line=k[1],function=k[2],primitive_calls=v[0],calls=v[1],exclusive_seconds=v[2],inclusive_seconds=v[3]) for k,v in pst.stats.items()];rows.sort(key=lambda x:x['exclusive_seconds'],reverse=True)
write_record(B/'result.json',dict(complete=True,search=r,total_calls=pst.total_calls,profile_total_seconds=pst.total_tt,functions=rows))
print(r['reason'],r['work'],r['wall'],flush=True)
print(json.dumps(rows[:18],indent=2),flush=True)