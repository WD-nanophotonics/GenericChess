from pathlib import Path
import json,sys
from dataclasses import replace
sys.path.insert(0,str(Path.cwd()))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.chess_development import root_from_fen
from scripts.research_record import record_value,write_record
from generic_chess.core.position import HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as ns
from types import SimpleNamespace
b=Path('.local_agent/stalemate-history-oracle-20261011');b.mkdir(exist_ok=True)
if (b/'declaration.json').exists():raise RuntimeError('frozen output exists')
write_record(b/'declaration.json',dict(question='On the same frozen nolegal/no-check frontier, does stalemate retain precedence when imported exact identity repetition also reaches4?',policies=['draw','loss'],repetition_records=4,ply=3,actors=[-1,0,1,0],checks=[False]*4,scope='Crafted identity/history precedence control, not legally reachable game or newperformance sample. Hash/witness exact; no legaltrajectory claim',expected=dict(draw=dict(status='stalemate',winner=None),loss=dict(status='stalemate',winner=0)),decision='Use recomputedCore status/winner and supportedNative draw as pre-extension precedence oracle; retain lossguardfailure'))
original=root_from_fen('7k/5K2/6Q1/8/8/8/8/8 b - - 0 1',compile_ruleset_for_execution(build_builtin_ruleset('western_chess')));rows=[]
for policy in ('draw','loss'):
 c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),stalemate_result=policy));pos=replace(original.position,ruleset_fingerprint=c.ruleset_fingerprint);key=position_identity_key(pos,c);hist=tuple(HistoryRecord(key,a,'',False) for a in (-1,0,1,0));s=replace(original,position=pos,ply_count=3,history=hist);t=terminal_result(s,c);s=replace(s,terminal_status=t);assert t.status.value=='stalemate' and t.winner==(None if policy=='draw' else 0)
 n=compile_native_semantic_rules(c);cap=pack_semantic_search_position(c,n,SimpleNamespace(compiled=c,state=s,_search_witnesses=(pos,)*4));saved=ns.snapshot(n,cap);assert not ns.transient_legal_actions(n,cap) and not ns.in_check(n,cap,1)
 try:actual=ns.terminal_status(n,cap);error=None
 except NativeUnsupportedRuleError as e:actual=None;error=str(e)
 assert (actual==dict(status='stalemate',winner=None)) if policy=='draw' else error is not None
 assert ns.snapshot(n,cap)==saved;rows.append(dict(policy=policy,core=record_value(t),state=record_value(s),native=actual,failure=error,snapshot=saved))
write_record(b/'result.json',dict(complete=True,rows=rows));print('Two crafted repetition/stalemate precedence oracles retained')
