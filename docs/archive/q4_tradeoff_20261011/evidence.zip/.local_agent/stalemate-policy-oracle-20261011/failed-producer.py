import json,sys,hashlib
from pathlib import Path
from dataclasses import replace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.chess_development import root_from_fen
from scripts.research_record import record_value,write_record
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as ns
from types import SimpleNamespace
from generic_chess.core.movegen import legal_actions
from generic_chess.core.terminal import terminal_result
B=Path('.local_agent/stalemate-policy-oracle-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
fen='7k/5K2/6Q1/8/8/8/8/8 b - - 0 1'
write_record(B/'declaration.json',dict(question='Can the exact physical nolegal/no-check frontier distinguish draw/loss policy without changing moves or bypassing Native support?',fen=fen,policies=['draw','loss'],calls=2,expected=dict(draw=dict(status='stalemate',winner=None),loss=dict(status='stalemate',winner=0)),scope='Pre-extension Core oracle and Native legality/support preflight only, not rebuilt terminal/backend certification',decision='Preserve expectedloss support failure; use this frozenpair for an eventual mechanicallybound terminal policy extension',estimated_cost='seconds, no search/training'))
rows=[]
for policy in ('draw','loss'):
 c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),stalemate_result=policy));s=root_from_fen(fen,c);t=terminal_result(s,c);assert t.status.value=='stalemate' and t.winner==(None if policy=='draw' else 0);assert not tuple(legal_actions(s,c));n=compile_native_semantic_rules(c);cap=pack_semantic_search_position(c,n,SimpleNamespace(compiled=c,state=s,_search_witnesses=(s.position,)));saved=ns.snapshot(n,cap);assert not ns.transient_legal_actions(n,cap) and not ns.in_check(n,cap,s.position.side_to_move)
 try:actual=ns.terminal_status(n,cap);failure=None
 except NativeUnsupportedRuleError as e:actual=None;failure=str(e)
 assert (actual==dict(status='stalemate',winner=None)) if policy=='draw' else failure is not None
 assert ns.snapshot(n,cap)==saved;rows.append(dict(policy=policy,ruleset_fingerprint=c.ruleset_fingerprint,state=record_value(s),core=record_value(t),native=actual,failure=failure,snapshot=saved))
assert rows[0]['state']['position']['board']==rows[1]['state']['position']['board'] and rows[0]['state']['position']['aux_state']==rows[1]['state']['position']['aux_state']
write_record(B/'result.json',dict(complete=True,rows=rows,physical_frontier_equal=True));print([(x['policy'],x['core'],x['failure']) for x in rows])
