import ast,json
from pathlib import Path
src=Path('.local_agent/native_capsule_q4.py').read_text(encoding='utf-8');exec(src.split('B=Path(')[0],globals());cl=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef));exec(compile(ast.Module(body=[cl],type_ignores=[]),'<capsule-runtime>','exec'),globals())
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
B=Path('.local_agent/capsule-state-dependency-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
selected={'chess-ep':'e5d6','chess-promotion':'a7a8q','shogi-promotion':'5c5b+','shogi-drop':'R*5e'}
write_record(B/'declaration.json',dict(question='Does capsule adapter preserve concrete EP auxiliary, promotion/base identity, drops/hands and checked history across a supported effect and its replies?',cases=selected,replies='first2 repr-sorted legal after selected effect',max_states=16,scope='Finite declared builtins state dependency, no full-domain/TT/cancellation or speed certification',decision='Mismatch scopes adapter and blocks integration; equality permits caller contract work with frozen Python leaf. No search cohort rerun',estimated_cost='seconds to under1min'))
rows=[]
for case in CASES:
 if case['id'] not in selected:continue
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));core=CoreBoard(case,c);rt=CapsuleRuntime(core.initial,c,core.witnesses);saved=rt.full_snapshot()
 def check(stage):
  assert rt.position==core.runtime.position and rt.terminal_status==core.runtime.terminal_status
  assert set(rt.legal_actions())==set(core.runtime.legal_actions())
  fresh=pack_semantic_search_position(c,rt.native,SimpleNamespace(compiled=c,state=core.runtime.state,_search_witnesses=tuple(core.runtime.history_position_witnesses))) if hasattr(core.runtime,'history_position_witnesses') else None
  rows.append(dict(case=case['id'],stage=stage,position=record_value(rt.position),terminal=record_value(rt.terminal_status),snapshot=rt.full_snapshot(),legal_count=len(rt.legal_actions()),core_history=record_value(core.runtime.history)))
 check('root');actions={core.label(a):a for a in core.runtime.legal_actions()};a=actions[selected[case['id']]];core.push(a);rt.push(a)
 try:
  check('effect')
  for i,b in enumerate(sorted(core.runtime.legal_actions(),key=repr)[:2]):
   core.push(b);rt.push(b)
   try:check(f'reply{i}')
   finally:core.pop();rt.pop()
 finally:core.pop();rt.pop()
 assert rt.full_snapshot()==saved;core.runtime.assert_balanced();rt.assert_balanced()
write_record(B/'result.json',dict(complete=True,rows=rows,cases=len(selected)));print('matched states',len(rows))
