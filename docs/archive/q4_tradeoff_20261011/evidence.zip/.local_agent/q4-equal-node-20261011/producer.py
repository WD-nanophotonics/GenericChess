"""Equal-node attribution after prospective time-bound depth displacement.
Reuses frozen roots, changes resource condition equally in both policies.
"""
import hashlib,json,sys,time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.core.search_runtime import SearchPathRuntime as R
from generic_chess.ai.limits import SearchLimits
B=Path('.local_agent/q4-equal-node-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('Frozen output exists')
d=dict(question='Does refresh displace depth under the same work cap, beyond clock variation?',roots=['seed1006-ply8','seed1008-ply8'],nodes=[6144,12288,24576],seconds=64,q=4,hardq=8,max_depth=12,orders=2,backends=['Core','Native actual'],arms=['baseline','fullq4_refresh'],calls=48,maximum_total_search_seconds=3072,estimated_seconds='~15-25min from observed4s visit rates; interruptible, under1h single run',decision='Loss under equal-node caps disproves clock-only explanation. Inspect successful refresh overhead and actual backend/time-cap exceptions; do not extend original4s evidence or promote default.',scope='Post-exposure development attribution on the two named roots; fixedsample/weights, no humanlabels/newholdout',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
p.rr.POLICY_SOURCES['clear']=p.rr.MODIFIED.replace('ctx.qdepth_limit = min(1, original_q)','ctx.qdepth_limit = original_q')
prepared=[]
for name in d['roots']:
 seed=int(name.split('-')[0][4:]);g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);s=p.GameSession(c);rng=p.random.Random(seed+7000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 original_sample=next(x for x in json.loads(Path('.local_agent/q4-prospective-20261011-repaired/samples.json').read_bytes())['samples'] if x.get('root')==name)
 ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);assert original_sample['initial']==record_value(s.state) and original_sample['profile']==record_value(profile)
 prepared.append((name,c,s.state,s._search_history_witnesses,p.Evaluator(c,profile,ec),s.legal_actions()))
runtimes=[];captured=[];oa=R.attach_stats;of=pm.SearchStatistics;original=pm.run_root_search;rows=[]
def attach(rt,st):
 value=oa(rt,st);runtimes.append((rt,p.runtime_state(rt)));return value
def factory():
 s=SearchStatistics();captured.append(s);return s
try:
 R.attach_stats=attach;pm.SearchStatistics=factory
 for name,c,initial,w,ev,legal in prepared:
  for nodes in d['nodes']:
   for order in range(2):
    for native in ((False,True) if order==0 else (True,False)):
     for arm in (('baseline','fullq4_refresh') if order==0 else ('fullq4_refresh','baseline')):
      p.rr.stopped();events=[];runtimes.clear();captured.clear();pm.run_root_search=original if arm=='baseline' else p.rr.make_refresh(events,expected_state=initial)
      player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=native,use_disk_cache=False)
      t=time.perf_counter();v=player.choose_action(SimpleNamespace(compiled=c,state=initial,_search_witnesses=w),SearchLimits(max_depth=12,max_nodes=nodes,max_time_seconds=64,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
      rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot and v.action in legal
      rows.append(dict(root=name,max_nodes=nodes,seconds=64,native_requested=native,order=order,arm=arm,wall=wall,decision=record_value(v),stats=record_value(captured[0]),events=events,root_restored=True))
      write_record(B/'result.json',dict(complete=False,rows=rows));print(name,nodes,order,native,arm,v.completed_depth,v.result_ordinary_qdepth,v.termination_reason,round(wall,3),flush=True)
 write_record(B/'result.json',dict(complete=True,rows=rows))
finally:R.attach_stats=oa;pm.SearchStatistics=of;pm.run_root_search=original