import json,hashlib
from pathlib import Path
from collections import Counter
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import full_q_refresh_comparison as p
from generic_chess.core.position import Position,Hands
from generic_chess.core.pieces import Piece
from generic_chess.core.attacks import anchor_square
B=Path('.local_agent/native-leaf-compatibility-20261011');r=json.loads((B/'result.json').read_bytes());comps=[]
for seed in (1006,1008):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();prof=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,prof,ec)
 for x in r['rows']:
  if not x['root'].startswith(str(seed)):continue
  raw=x['position'];pos=Position(tuple(None if z is None else Piece(**z) for z in raw['board']),tuple(Hands(tuple(tuple(z) for z in h['counts'])) for h in raw['hands']),raw['side_to_move'],raw['ruleset_fingerprint'],tuple(raw['aux_state']));state=type('State',(),{'position':pos})();att=ev._attack_maps(state);mat=sum((1 if z.owner==0 else -1)*prof.board_value_by_type[z.current_type_id] for z in pos.board if z)+sum((1 if owner==0 else -1)*count*prof.hand_value_by_base_type[t] for owner in (0,1) for t,count in pos.hands[owner].counts);mob=2*(len(att[0])-len(att[1]));promotion=sum(ev._promotion_bonus(z,i) for i,z in enumerate(pos.board) if z);anchor=5*(ev._anchor_escape(pos,0,att[1])-ev._anchor_escape(pos,1,att[0])-10*(anchor_square(pos,0,c) in att[1])+10*(anchor_square(pos,1,c) in att[0]));sign=1 if pos.side_to_move==0 else -1;assert sign*(mat+mob+promotion+anchor)==x['python'];nf=x['native_features'];assert sign*(mat+2*nf[0]+3*nf[1]+5*nf[2])==x['native'];comps.append(dict(root=x['root'],action=x['action'],owner0_python=dict(material=mat,mobility=mob,promotion=promotion,anchor=anchor),owner0_native=dict(material=mat,mobility=2*nf[0],promotion=3*nf[1],anchor=5*nf[2]),delta=x['delta']))
counts={k:sum(x['owner0_python'][k]!=x['owner0_native'][k] for x in comps) for k in ('material','mobility','promotion','anchor')};out=dict(leaves=len(comps),mismatches=r['mismatches'],component_mismatch_counts=counts,decision='Native uses checked candidate-action counts versus Python distinct pseudoattack squares, plus different promotion/anchor definitions. Different evaluator families, not an interface error to fix by label fitting. Preserve frozenPython leaf for capsule cost attribution.',source_sha256=hashlib.sha256(Path('generic_chess/_native/native_module.c').read_bytes()).hexdigest(),components=comps);(B/'analysis.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(counts)
