"""Offline one-second delivery comparison on existing synthetic UI roots.
Current sandbox search, frozen per-root UI leaf inputs, cold Core players.
Not an end-to-end UI test or a change to the frozen ui-test branch.
"""
import hashlib,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.core.search_runtime import SearchPathRuntime as R
from generic_chess.ai.limits import SearchLimits
B=Path('.local_agent/q4-ui-offline-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('Frozen output exists')
games=Path('.local_agent/ui-product-20261010/games-final.json')
d=dict(question='At the frozenUI1s resource condition, what support is delivered and what completed depth is displaced?',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),games_sha256=hashlib.sha256(games.read_bytes()).hexdigest(),roots='All existing recordedUI-role roots; no exposedlabel fit, result filtering or new games',arms=['baseline','fullq4_refresh'],orders=2,backend='Core only, actual counters checked',max_depth=None,max_nodes=None,seconds=1,q=4,hardq=8,estimated_max_calls=120,decision='No automatic q-over-depth ranking. Report support gains, lost depth, legal reserve on abort. Keep defaults; close unconditionalrefresh route if tradeoff persists, no cap growth/adaptive rescue.',scope='Offline current sandbox prototype and coldplayers; frozen perroot evaluation/material reconstructed from records. Does not claim persistentUI TT/controller latency or reported user-game reproduction.')
write_record(B/'declaration.json',d)
p.rr.POLICY_SOURCES['clear']=p.rr.MODIFIED.replace('ctx.qdepth_limit = min(1, original_q)','ctx.qdepth_limit = original_q')
roots=list(p.rr.queen_roots(games,all_ui=True));write_record(B/'roots.json',dict(roots=[dict(name=n,state=record_value(s.state),witnesses=record_value(s._search_history_witnesses),config=record_value(e._config),profile=record_value(e._profile)) for n,s,e in roots]))
rows=[];runtimes=[];captured=[];oa=R.attach_stats;of=pm.SearchStatistics;original=pm.run_root_search
def attach(rt,st):
 value=oa(rt,st);runtimes.append((rt,p.runtime_state(rt)));return value
def factory():
 v=SearchStatistics();captured.append(v);return v
try:
 R.attach_stats=attach;pm.SearchStatistics=factory
 for name,s,ev in roots:
  initial=s.state;w=s._search_history_witnesses;legal=s.legal_actions()
  for order in range(2):
   for arm in (('baseline','fullq4_refresh') if order==0 else ('fullq4_refresh','baseline')):
    p.rr.stopped();events=[];runtimes.clear();captured.clear();pm.run_root_search=original if arm=='baseline' else p.rr.make_refresh(events,expected_state=initial)
    player=AlphaBetaPlayer(s.compiled,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False)
    t=time.perf_counter();v=player.choose_action(s,SearchLimits(max_depth=None,max_nodes=None,max_time_seconds=1,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot and s.state==initial and s._search_history_witnesses==w and v.action in legal
    assert captured[0].native_legality_calls==captured[0].native_legality_enabled==0
    rows.append(dict(root=name,native_requested=False,order=order,arm=arm,seconds=1,wall=wall,decision=record_value(v),stats=record_value(captured[0]),events=events,root_restored=True))
    write_record(B/'result.json',dict(complete=False,rows=rows));print(name,order,arm,v.completed_depth,v.result_ordinary_qdepth,round(wall,3),flush=True)
 write_record(B/'result.json',dict(complete=True,rows=rows))
finally:R.attach_stats=oa;pm.SearchStatistics=of;pm.run_root_search=original