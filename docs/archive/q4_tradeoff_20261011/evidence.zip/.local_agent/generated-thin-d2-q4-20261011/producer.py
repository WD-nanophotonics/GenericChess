"""Fixed-driver q4 cost bridge on previously exposed generated roots.
No iterative reserve/refresh, TT, PVS or ordering. Core/Native legality only.
"""
import collections,hashlib,json,random,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.quiescence import enemy_board_count,material_inventory,noisy_child
from generic_chess.ai.alphabeta.search import INF,terminal_score
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.statistics import SearchStatistics
B=Path('.local_agent/generated-thin-d2-q4-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('Frozen output exists')
d=dict(question='At the next ordinary depth, does the matched lexicalq4 driver complete on the same exposed roots or exhaust its work bound before fullsearch; choose full-kernel versus Python transition work accordingly?',roots=['seed1006-ply0','seed1006-ply8','seed1008-ply0','seed1008-ply8'],depth=2,q=4,hardq=8,nodes=100000,seconds=90,orders=2,calls=16,maximum_search_seconds=1440,decision='Matched complete traces permit backend cost attribution; cap/hardq is UNKNOWN, not a depth comparison. High physically applied quiet rejection identifies an interface opportunity, not permission to omit generated transition effects. No change to defaults and no repeated frozen builtin comparison.',scope='Exposed development roots and default frozen profiles from prospective cohort. No terminal-declaration shortcut, iteration reserve, TT, PVS or heuristic ordering. Primitive score semantics and shared noisy_child retained. Runtime complete history preserved; generated cohort has no declaration mechanisms. Clock observation under ordinary concurrent load, not exclusive benchmark.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
original=json.loads(Path('.local_agent/q4-prospective-20261011-repaired/samples.json').read_bytes())['samples'];roots=[]
for seed in (1006,1008):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec);s=p.GameSession(c);rng=random.Random(seed+7000)
 for ply in range(9):
  if ply in (0,8):
   name=f'seed{seed}-ply{ply}';old=next(x for x in original if x.get('root')==name);assert record_value(s.state)==old['initial'] and record_value(profile)==old['profile'];roots.append((name,c,s.state,s._search_history_witnesses,ev))
  if ply<8:s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))

def search(c,initial,witnesses,ev,native):
 provider=NativeSemanticLegalityProvider.try_create(c,strict=True) if native else None
 if native:assert provider is not None
 rt=SearchPathRuntime(initial,c,history_witnesses=witnesses,legal_binding_provider=provider);stats=SearchStatistics();rt.attach_stats(stats);saved=p.runtime_state(rt);work=collections.Counter();trace=hashlib.sha256();start=time.perf_counter();best=None;bestscore=-INF
 def poll():
  if work['main']+work['q']>=d['nodes']:raise RuntimeError('nodes')
  if time.perf_counter()-start>=d['seconds']:raise RuntimeError('time')
 def terminal(ply):return terminal_score(rt.terminal_status,rt.position.side_to_move,ply) if rt.terminal_status.is_terminal else None
 def actions():
  work['legal']+=1
  result=tuple(sorted(rt.legal_actions(checkpoint=poll),key=repr));trace.update(('A:'+','.join(repr(x) for x in result)+';').encode());return result
 def q(alpha,beta,ply,qd):
  poll();work['q']+=1;t=terminal(ply)
  if t is not None:return t
  check=rt.in_check(rt.position.side_to_move,checkpoint=poll)
  if check:
   work['checked_q']+=1
   if qd>=d['hardq']:raise RuntimeError('hardq')
  else:
   work['eval']+=1;v=ev.evaluate(rt.state)
   if v>=beta:return v
   alpha=max(alpha,v)
   if qd>=d['q']:return alpha
  side=rt.position.side_to_move;enemies=enemy_board_count(rt.position,side);inventory=material_inventory(rt.position)
  for action in actions():
   poll();rt.push(action,checkpoint=poll);work['physical_push']+=1
   try:
    noisy=check or noisy_child(action,rt.state,side,enemies,inventory,lambda:rt.in_check(rt.position.side_to_move,checkpoint=poll))
    if not noisy:work['quiet_rejected']+=1;continue
    v=-q(-beta,-alpha,ply+1,qd+1)
   finally:rt.pop();work['physical_pop']+=1
   trace.update(f'Q:{ply}:{repr(action)}:{v};'.encode())
   if v>=beta:return v
   alpha=max(alpha,v)
  return alpha
 def main(left,alpha,beta,ply):
  nonlocal best,bestscore
  poll();work['main']+=1;t=terminal(ply)
  if t is not None:return t
  if not left:return q(alpha,beta,ply,0)
  value=-INF
  for action in actions():
   poll();rt.push(action,checkpoint=poll);work['physical_push']+=1
   try:v=-main(left-1,-beta,-alpha,ply+1)
   finally:rt.pop();work['physical_pop']+=1
   trace.update(f'M:{ply}:{repr(action)}:{v};'.encode())
   if ply==0:
    work['root_completed']+=1
    if best is None or v>bestscore:best,bestscore=action,v
   value=max(value,v);alpha=max(alpha,value)
   if alpha>=beta:break
  return value
 try:score=main(d['depth'],-INF,INF,0);reason='complete'
 except RuntimeError as e:
  if str(e) not in ('nodes','time','hardq'):raise
  score=None;reason=str(e)
 rt.assert_balanced();assert p.runtime_state(rt)==saved and work['physical_push']==work['physical_pop']
 return dict(reason=reason,score=score,action=record_value(best),work=dict(work),wall=time.perf_counter()-start,trace=trace.hexdigest(),stats=record_value(stats),provider_calls=rt.legal_provider_calls,provider_fallbacks=rt.legal_provider_fallbacks,provider_operational_failures=rt.legal_provider_operational_failures,root_restored=True)
rows=[]
for name,c,initial,w,ev in roots:
 for order in range(2):
  for native in ((False,True) if order==0 else (True,False)):
   p.rr.stopped();v=search(c,initial,w,ev,native);rows.append(dict(root=name,order=order,native_requested=native,**v));write_record(B/'result.json',dict(complete=False,rows=rows));print(name,order,native,v['reason'],v['score'],v['work'],round(v['wall'],3),flush=True)
write_record(B/'result.json',dict(complete=True,rows=rows))