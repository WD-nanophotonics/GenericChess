import ast,json
from pathlib import Path
src=Path('.local_agent/native_capsule_q4.py').read_text(encoding='utf-8');exec(src.split('B=Path(')[0],globals());cl=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef));exec(compile(ast.Module(body=[cl],type_ignores=[]),'<capsule-runtime>','exec'),globals())
B=Path('.local_agent/native-leaf-compatibility-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
write_record(B/'declaration.json',dict(question='Can the existing three Native dynamic weights represent the exact frozen production evaluator at the capsule boundary?',roots=['1006-ply0','1006-ply8','1008-ply0','1008-ply8'],selection='root plus first16 repr-sorted legal children perroot, no result-based sample change',maximum_leaves=68,weights=[2,3,5],scale=1,scope='Exposed finite compatibility diagnosis, not learning or evaluator fitting',decision='Any mismatch forbids treating this Native evaluator as sameleaf speed control. RetainPython evaluator; do not fit weights to exposed labels. If equal, still require larger semantic support before adoption',expected_cost='seconds, no fullsearch or additionalworker'))
rows=[]
for seed in (1006,1008):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec);s=p.GameSession(c);rng=random.Random(seed+7000)
 for ply in range(9):
  if ply in (0,8):
   rt=CapsuleRuntime(s.state,c,s._search_history_witnesses);saved=rt.full_snapshot();actions=[None]+sorted(rt.legal_actions(),key=repr)[:16];bv=tuple(profile.board_value_by_type.get(i,0) for i in rt.native.type_ids);hv=tuple(profile.hand_value_by_base_type.get(i,0) for i in rt.native.type_ids)
   for a in actions:
    if a is not None:rt.push(a)
    try:
     py=ev.evaluate(rt.state);features=ns.dynamic_features(rt.native,rt.capsule);native=ns.evaluate(rt.native,rt.capsule,board_values=bv,hand_values=hv,dynamic_values=(2,3,5),evaluator_scale=1);rows.append(dict(root=f'{seed}-ply{ply}',action=record_value(a),python=py,native=native,native_features=features,delta=native-py,terminal=record_value(rt.terminal_status),position=record_value(rt.position)))
    finally:
     if a is not None:rt.pop()
   assert rt.full_snapshot()==saved
  if ply<8:s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
write_record(B/'result.json',dict(complete=True,rows=rows,mismatches=sum(x['delta']!=0 for x in rows)));print(len(rows),sum(x['delta']!=0 for x in rows));print([(x['root'],x['python'],x['native']) for x in rows if x['delta']][:10])
