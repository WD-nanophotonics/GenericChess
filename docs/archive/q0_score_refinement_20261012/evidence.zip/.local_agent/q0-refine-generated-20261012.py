"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/q0-refine-generated-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does score-only exactroot refinement preserve finite q0 values on new generated histories with independent plain Core reference?',seeds=[2026101201,2026101202,2026101203,2026101204],board_sizes=[4,8,4,8],roots=[0,8],walk='Random(seed+9000) choice of repr-sorted legal actions, natural terminal/unsupported roots retained, no resampling',depths=[2,3],arms=['baseline','score_only','CorePlain'],orders=[0,1],maxcalls=96,seconds=30,nodes=1000000,whole_batch_seconds=1200,q=0,scope='Predeclared generator cohort; complete compiled histories/aux/promotion/drop execution preserved. Candidate uses counter-onlyphase augmentation, full rootbest==-finalbranch diagnostic; same behavior confirmed342036node/fulltuple ongen2. Same fixed rulederived board/hand leaf with zero dynamics; Native min2,cold1MiB; CoreTTfree/unordered noPVS/native legality availability actual. Complete Native tuples must agree; Core complete values checked, independent tieorders need not match. Incomplete cells unknown, no cap extension or humanfitting. Exposed method not universal holdout. Expected5-12min, producer20min cost fuse checked beforecell. No default/UI/additional worker.'))
modules={}
for arm in ['baseline','score_only']:
 spec=importlib.util.spec_from_file_location('transfer_'+arm+'._native_core',(ROOT/'.local_agent/q0-refine-phase-20261012/phase' if arm=='score_only' else ROOT/'.local_agent/q0-refine-score-20261012'/arm)/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules[arm]=m
write_record(out/'modules.json',{k:dict(path=m.__file__,sha256=__import__('hashlib').sha256(Path(m.__file__).read_bytes()).hexdigest()) for k,m in modules.items()})
rows=[]
import random
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
class Frozen:
 def __init__(self,bv,hv):self.bv=bv;self.hv=hv
 def evaluate(self,s):
  p=s.position;v=[0,0]
  for pc in p.board:
   if pc:v[pc.owner]+=self.bv[pc.current_type_id]
  for side,h in enumerate(p.hands):
   for tid,n in h.counts:v[side]+=self.hv[tid]*n
  return v[p.side_to_move]-v[1-p.side_to_move]
 def type_value(self,tid):return self.bv[tid]
 def capture_order_value(self,a,b):return 10*self.type_value(b.current_type_id)-self.type_value(a.current_type_id)
samples=[];start=time.perf_counter();censored=False
for seed in [2026101201,2026101202,2026101203,2026101204]:
 cfg=GeneratorConfig(seed=seed,board_size=4 if seed%2 else 8,setup_preset='bilateral_random',allow_hybrid=True)
 g=generate_game(cfg);src=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);session=GameSession(c);rng=random.Random(seed+9000)
 profile=build_ruleset_profile(c,EvaluationConfig());bv=dict(profile.board_value_by_type);hv=dict(profile.hand_value_by_base_type);ordering=LearnableMaterialCheckpoint.from_profile(c,profile,dynamic_weights={})
 for ply in range(9):
  acts=sorted(session.legal_actions(),key=repr)
  if ply in [0,8]:
   name=f'seed{seed}-ply{ply}';samples.append(dict(root=name,config=record_value(cfg),rules=json.loads(serialize_ruleset(g.ruleset)),state=record_value(session.state),witnesses=record_value(session._search_witnesses),board=bv,hand=hv,included=bool(acts) and session.result.status.value=='ongoing'));write_record(out/'samples.json',samples)
   if samples[-1]['included']:
    state=session.state
    for depth in [2,3]:
     for order,arms in enumerate([['baseline','score_only','CorePlain'],['CorePlain','score_only','baseline']]):
      for arm in arms:
       for flag in ['rollout','advisor','slack']:
        f=json.loads((ROOT/'.local_agent'/(flag+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused')
       if time.perf_counter()-start>1200:censored=True;break
       native._MODULE=modules['baseline' if arm=='CorePlain' else arm];provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
       engine=AlphaBetaPlayer(c,evaluator_override=Frozen(bv,hv),use_tt=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=False,use_root_tactical=False)) if arm=='CorePlain' else SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2)
       raw=[];old=modules[arm].semantic_engine_search if arm!='CorePlain' else None
       if old:
        def counted(*a):
         d=old(*a);raw.append(dict(d));return d
        modules[arm].semantic_engine_search=counted
       before=record_value(state);t=time.perf_counter();lim=SearchLimits(max_depth=depth,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0,quiescence_hard_max_depth=0);r=engine.choose_action(session,lim) if arm=='CorePlain' else engine.search(session,lim,root_window_pruning=True);elapsed=time.perf_counter()-t;
       if old:modules[arm].semantic_engine_search=old
       if arm=='score_only':assert raw[0]['research_pv_mismatches']==0
       assert record_value(session.state)==before;ss=state
       for a in r.principal_variation:assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
       assert r.action in acts
       rows.append(dict(root=name,depth=depth,order=order,arm=arm,seconds=elapsed,result=record_value(r),canonical_value_checks={k:v for k,v in raw[0].items() if k.startswith('research_')} if arm=='score_only' else None,pv_legal=True,root_restored=True));write_record(out/'result.json',dict(complete=False,censored=censored,rows=rows));print(name,depth,order,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,flush=True)
      if censored:break
     if censored:break
  if censored or ply==8 or not acts or session.result.status.value!='ongoing':break
  session.submit(rng.choice(acts))
 if censored:break
write_record(out/'result.json',dict(complete=True,censored=censored,rows=rows,seconds=time.perf_counter()-start))
