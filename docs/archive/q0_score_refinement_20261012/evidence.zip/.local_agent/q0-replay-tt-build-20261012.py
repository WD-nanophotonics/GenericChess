import os,sys,sysconfig,subprocess,time,hashlib,json
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
out=ROOT/'.local_agent/q0-replay-tt-20261012';out.mkdir(exist_ok=True);source=(ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
base=(ROOT/'.local_agent/q0-refine-phase-20261012/phase/native_module.c').read_text(encoding='utf-8')
write_record(out/'declaration.json',dict(question='Can simply enabling valid nonPV TT score probes in canonical replay preserve full canonical output?',calls=12,fixed_depth=4,roots=['gen0','gen2','Shogi0'],orders=[0,1],TT_MiB=1,min_depth=2,seconds=64,nodes=None,scope='Private negative-or-positive decision check, existingscore-only baseline and naiveTT score reuse duringreplay nonPV. Encodedcanonical action order, exacthorizon/history/leaf/commit unchanged. Completedvalue/action/PV/actualfinalvaluechecks all recorded; truncation/tiechange rejectsnaiveadoption. No new publicAPI/PVS/reconstruction/default/UI. Expected<2min,max768s<13min; no rescue. A changed outputcontract is not a samesupportspeedup.'))
rows=[]
for name,flag in [('baseline',0),('replay_TT',1)]:
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';variant=base
 if flag:
  needle='    if (ctx->tt != NULL && !pv_replay) {';assert variant.count(needle)==1
  variant=variant.replace(needle,'    if (ctx->tt != NULL && (!pv_replay || !pv_node)) {')
 p.write_text(variant,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));args=[str(ROOT/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(ROOT/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython'+str(sys.version_info.major)+str(sys.version_info.minor)]+[str(p if f.name=='native_module.c' else f) for f in sorted((ROOT/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)];t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:];rows.append(dict(arm=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size));print(name,'built',flush=True)
assert (ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')==source;write_record(out/'build-summary.json',dict(variants=rows,productsource_unchanged=True))
