"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/q0-generated-delivery-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does score-only refinement change equal16s caller delivery on all7 saved prospective generator roots?',calls=42,roots='All7 ongoing roots from frozen4seed D2/D3cohort; naturalearlyterminal remains excluded/recorded, no successfulrootselection',arms=['baseline','score_only','CorePVS'],orders=[0,1],seconds=16,nodes=1000000,maxdepth=12,q=0,Native_TT_MiB=1,Core_TT_entries=250000,scope='Method/roots exposed from preceding finitecorrectness cohort. Same rulederived fixed board/hand leaf and full suppliedhistory/witnesses, min2Native ordering, cold independent tables. Retain fulltuple/depth/PV legality/actualbackend and variable reversepairs, no walltime or native/Core equalnodeprimitiveclaim. Counts include incomplete nextiteration. Max672s11.2min, expected6-9min; no withinbatch extension/default/UI/humanfit. Original limits stayimmutable.'))
modules={}
for arm in ['baseline','score_only']:
 spec=importlib.util.spec_from_file_location('transfer_'+arm+'._native_core',(ROOT/'.local_agent/q0-refine-phase-20261012/phase' if arm=='score_only' else ROOT/'.local_agent/q0-refine-score-20261012'/arm)/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules[arm]=m
write_record(out/'modules.json',{k:dict(path=m.__file__,sha256=__import__('hashlib').sha256(Path(m.__file__).read_bytes()).hexdigest()) for k,m in modules.items()})
rows=[]
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.position import Position,Hands,GameState,HistoryRecord
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.rules.schema import ruleset_from_dict
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)
class Frozen:
 def __init__(self,bv,hv):self.bv=bv;self.hv=hv
 def evaluate(self,s):
  p=s.position;v=[0,0]
  for pc in p.board:
   if pc:v[pc.owner]+=self.bv[pc.current_type_id]
  for side,h in enumerate(p.hands):
   for tid,n in h.counts:v[side]+=self.hv[tid]*n
  return v[p.side_to_move]-v[1-p.side_to_move]
 def type_value(self,tid):return self.bv[tid]
 def capture_order_value(self,a,b):return 10*self.type_value(b.current_type_id)-self.type_value(a.current_type_id)
samples=json.loads((ROOT/'.local_agent/q0-refine-generated-20261012/samples.json').read_bytes())
for sample in samples:
 if not sample['included']:continue
 src=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(sample['rules']));c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 d=sample['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));witnesses=tuple(position(x) for x in sample['witnesses']);session=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 bv=sample['board'];hv=sample['hand'];ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
 for order,arms in enumerate([['baseline','score_only','CorePVS'],['CorePVS','score_only','baseline']]):
  for arm in arms:
   for flag in ['rollout','advisor','slack']:
    f=json.loads((ROOT/'.local_agent'/(flag+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused')
   native._MODULE=modules['baseline' if arm=='CorePVS' else arm];provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
   engine=AlphaBetaPlayer(c,evaluator_override=Frozen(bv,hv),use_tt=True,use_ordering=True,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=True)) if arm=='CorePVS' else SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2)
   before=record_value(state);t=time.perf_counter();lim=SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=16,quiescence_max_depth=0,quiescence_hard_max_depth=0);r=engine.choose_action(session,lim) if arm=='CorePVS' else engine.search(session,lim,root_window_pruning=True);elapsed=time.perf_counter()-t;assert record_value(state)==before;ss=state
   for action in r.principal_variation:assert action in legal_actions(ss,c);ss=apply_action(ss,action,c)
   assert r.action in legal_actions(state,c)
   rows.append(dict(root=sample['root'],arm=arm,order=order,seconds=elapsed,result=record_value(r),pv_legal=True,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(sample['root'],order,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
