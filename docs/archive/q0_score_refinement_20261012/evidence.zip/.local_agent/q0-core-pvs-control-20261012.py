"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/q0-core-pvs-control-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does existing Core PVS alone explain the remaining Native/Core Shogi depth gap?',calls=8,roots=['generated1091 savedturn2','shogi-middle savedturn0'],arms=['CoreAB','CorePVS'],orders=[0,1],seconds=64,nodes=None,maxdepth=12,q=0,TT_entries=250000,scope='Two preselected exposed roots, same Core implementation/evaluator/ordering/native legality/availability, only existinguse_pvs toggled. Fresh independent TT, reverseorders. Compare delivered depth/value/PV and actual counters; no alignedNative algorithm proof, primitive or playing claim. No result-driven extension. Expected8.5min,max512s kernel belowhour. This chooses whether a new NativePVS kernel is justified, not automatically implementingit.'))
modules={'current':native._module()}
write_record(out/'modules.json',{k:dict(path=m.__file__,sha256=__import__('hashlib').sha256(Path(m.__file__).read_bytes()).hexdigest()) for k,m in modules.items()})
saved=json.loads((ROOT/'.local_agent/q0-played-consumer-after-20261012/result.json').read_bytes());inputs=json.loads((ROOT/'.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes());rows=[]
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)
class Frozen:
 def __init__(self,bv,hv):self.bv=bv;self.hv=hv
 def evaluate(self,s):
  p=s.position;v=[0,0]
  for pc in p.board:
   if pc:v[pc.owner]+=self.bv[pc.current_type_id]
  for side,h in enumerate(p.hands):
   for tid,n in h.counts:v[side]+=self.hv[tid]*n
  return v[p.side_to_move]-v[1-p.side_to_move]
 def type_value(self,tid):return self.bv[tid]
 def capture_order_value(self,a,b):return 10*self.type_value(b.current_type_id)-self.type_value(a.current_type_id)
for name,path in saved['paths'].items():
 c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(inputs[name]['rules']))) if name in inputs else compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'))
 ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
 bv,hv=(inputs[name]['board'],inputs[name]['hand']) if name in inputs else(VALUES['shogi'],VALUES['shogi'])
 for turn in ([2] if name=='generated1091' else [0]):
  d=path['turns'][turn]['before'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));witnesses=tuple(position(x) for x in path['initial_witnesses'])+tuple(position(x['after']['position']) for x in path['turns'][:turn]);session=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
  for seconds in [64]:
   for order,arms in enumerate([['CoreAB','CorePVS'],['CorePVS','CoreAB']]):
    for arm in arms:
     for flag in ['rollout','advisor','slack']:
      f=json.loads((ROOT/'.local_agent'/ (flag+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused'), 'User stop'
     native._MODULE=modules['current'];provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
     engine=AlphaBetaPlayer(c,evaluator_override=Frozen(bv,hv),use_tt=True,use_ordering=True,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=arm=='CorePVS'))
     before=record_value(state);t=time.perf_counter();lim=SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0);r=engine.choose_action(session,lim);elapsed=time.perf_counter()-t;assert record_value(state)==before;ss=state
     for a in r.principal_variation:assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
     assert r.action in legal_actions(state,c);rows.append(dict(root=name,turn=turn,budget_seconds=seconds,arm=arm,order=order,seconds=elapsed,result=record_value(r),pv_legal=True,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(name,turn,seconds,order,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
