import os,sys,sysconfig,subprocess,time,hashlib,json
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
out=ROOT/'.local_agent/q0-origin-20261012';out.mkdir(exist_ok=True);source=(ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
base=source.replace('    uint32_t pv_stride;\n    uint64_t nodes;','    uint32_t pv_stride;\n    int replay_origin;\n    uint64_t replay_refine;\n    uint64_t replay_final;\n    uint64_t replay_other;\n    uint64_t nodes;');assert base!=source
base=base.replace('    ctx->nodes++;','    ctx->nodes++;\n    if (pv_replay) { if(ctx->replay_origin==1) ctx->replay_refine++; else if(ctx->replay_origin==2) ctx->replay_final++; else ctx->replay_other++; }')
a='            ctx->root_tie_refinements++;';assert base.count(a)==1
base=base.replace(a,a+'\n            int old_origin=ctx->replay_origin; ctx->replay_origin=1;')
a='            if (ctx->control != 0) { ctx->root_tie_aborts++; break; }';assert base.count(a)==1
base=base.replace(a,'            ctx->replay_origin=old_origin;\n'+a)
a='        int branch = gc_semantic_iterative_negamax(\n            ctx, ply + 1, depth - 1, -GC_SEMANTIC_PROBE_INF,';assert base.count(a)==1
base=base.replace(a,'        int old_origin=ctx->replay_origin; ctx->replay_origin=2;\n'+a)
a='        if (ctx->control != 0) return 0;\n        /* Keep the already selected';assert base.count(a)==1
base=base.replace(a,'        ctx->replay_origin=old_origin;\n'+a)
marker='"s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K}",';assert base.count(marker)==1
base=base.replace(marker,'"s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K}",')
base=base.replace('        "tt_allocated_bytes", ctx.tt == NULL ?', '        "replay_refine", ctx.replay_refine,\n        "replay_final", ctx.replay_final,\n        "replay_other", ctx.replay_other,\n        "tt_allocated_bytes", ctx.tt == NULL ?')
write_record(out/'declaration.json',dict(question='Which replay origin dominates gen2 min2 D4?',source_base='62b1d208b4ffc0ac2b358b1a2448c8265281bca1',calls=4,depths=[3,4],orders=[0,1],TT_MiB=1,seconds=64,nodes=None,scope='Counter-only private currentC, no order/kernel/default changes. Fullhistory savedgen2, exactroot q0 min2. Compare frozen triplet and counts. Expected60s, maximum256s.'))
rows=[]
for name,flag in [('origin',0)]:
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text('#define GC_RESEARCH_RESTORE_TT '+str(flag)+'\n'+base,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));args=[str(ROOT/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(ROOT/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython'+str(sys.version_info.major)+str(sys.version_info.minor)]+[str(p if f.name=='native_module.c' else f) for f in sorted((ROOT/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)];t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:];rows.append(dict(arm=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size));print(name,'built',flush=True)
assert (ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')==source;write_record(out/'build-summary.json',dict(variants=rows,productsource_unchanged=True))
