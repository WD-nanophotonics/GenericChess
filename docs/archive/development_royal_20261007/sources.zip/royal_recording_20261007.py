"""Static same-record byte comparison; no timed-game throughput inference."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import record_value,write_record
p=ROOT/'.local_agent/royal-20261007';out=p/'recording.json';assert not out.exists()
def encoded(v):return (json.dumps(record_value(v),indent=None,allow_nan=False)+'\n').encode('utf-8')
start=time.perf_counter();rows=[]
for cohort in ('direct','classical','reference'):
 raw=(p/(cohort+'.json')).read_bytes();v=json.loads(raw);assert v['complete'] and len(v['games'])==12
 old_bytes=new_bytes=0;count=0;completed=[];decision_rows=0
 for g in v['games']:
  tags={k:g[k] for k in ('id','table','royal_color','opponent_mode')}
  for n in range(1,len(g['moves'])+1):
   active=dict(**tags,white=g['white'],black=g['black'],initial_fen=g['initial_fen'],moves=g['moves'][:n],opening_uci=g['opening_uci'],end='ply_limit',winner=None,finished=False)
   old=dict(declaration=v['declaration'],cohort=cohort,games=completed,complete=False,active_game=active)
   new=dict(cohort=cohort,**active)
   a,b=encoded(old),encoded(new)
   # Old completed games remain in the durable cohort file. Only their repeated
   # inclusion on every new action is removed. Active rows are identical.
   assert json.loads(a)['active_game']=={k:z for k,z in json.loads(b).items() if k!='cohort'}
   old_bytes+=len(a);new_bytes+=len(b);count+=1
  completed.append(g);decision_rows+=len(g['moves'])
 assert completed==v['games']
 observed=v['recording_cost']
 assert observed['active']['writes']==count
 assert observed['active']['bytes']==new_bytes
 rows.append(dict(cohort=cohort,source_sha256=hashlib.sha256(raw).hexdigest(),action_snapshots=count,all_decision_rows_retained=decision_rows,old_whole_report_action_bytes=old_bytes,new_active_action_bytes=new_bytes,action_byte_reduction_percent=100*(old_bytes-new_bytes)/old_bytes,observed_cost_before_final_save=observed,observed_cohort_bytes_additional=observed['cohort']['bytes'],invariants='All identical active rows; same completed games/final states remain in cohort saves. No selected-move/PV/counter projection or omitted history.'))
write_record(out,dict(complete=True,scope='Counterfactual serialization of identical completed records under the existing lossless serializer. Exact action bytes; not old/new game speedup, physical IO latency, live durability fault acceptance or playing-strength proof. Cohort saves and final marker are additional actual overhead. Active crash frontier is separate from last completed cohort.',rows=rows,measurement_wall_seconds=time.perf_counter()-start))
print(json.dumps(rows),flush=True)
