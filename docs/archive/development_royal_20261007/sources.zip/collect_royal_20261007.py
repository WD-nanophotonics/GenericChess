"""Portable complete development evidence; archive verification, not promotion."""
import sys,json,hashlib,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'.local_agent/royal-20261007';a=ROOT/'docs/archive/development_royal_20261007';a.mkdir(exist_ok=True)
out=ROOT/'docs/research/data/chess_royal_20261007.json';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def norm(x):
 if isinstance(x,str):return x.replace(str(ROOT),'{PROJECT_ROOT}').replace(ROOT.as_posix(),'{PROJECT_ROOT}')
 if isinstance(x,list):return [norm(v) for v in x]
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
 return x
raw=(p/'build.json').read_bytes();build=json.loads(raw);assert build['complete']
write_record(p/'build-portable.json',dict(original_local_sha256=sha(raw),normalization='Project absolute paths replaced with {PROJECT_ROOT}; original local report retained.',report=norm(build)))
groups={};files=[p/n for n in ('declaration.json','game-declaration.json','build-portable.json','features.json','direct-roots.json','native-gc-roots.json','adverse.json','recording.json')]
for cohort in ('direct','classical','reference'):
 v=json.loads((p/(cohort+'.json')).read_bytes());r=json.loads((p/(cohort+'-replay.json')).read_bytes())
 assert v['complete'] and r['complete'] and len(r['games'])==12 and not r['errors']
 methods={}
 for g in r['games']:
  z=methods.setdefault(g['table'],dict(wins=0,losses=0,draws=0,unfinished=0))
  key='unfinished' if not g['finished'] else 'draws' if g['winner'] is None else 'wins' if g['winner']==g['royal_color'] else 'losses';z[key]+=1
 groups[cohort]=dict(methods=methods,cells=r['games'],wall_seconds=v['wall_seconds'],recording_cost_before_final_save=v['recording_cost'],replay=dict(streams=12,played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0))
 files.extend(p/n for n in (cohort+'.json',cohort+'-replay.json'))
def contrast(filename,left,right):
 v=json.loads((p/filename).read_bytes());assert v['complete'];z=dict(same=0,finite_better=0,finite_worse=0,finite_equal=0,mate=[])
 for r in v['rows']:
  m={x['mode']:x['move'] for x in r['choices']};l,b=m[left],m[right]
  if l==b:z['same']+=1;continue
  x,y=r['references'][l],r['references'][b]
  if x['cp'] is None or y['cp'] is None:z['mate'].append(dict(game=r['game'],threshold=r['threshold'],side=r['side'],left_move=l,right_move=b,left=x,right=y));continue
  delta=x['cp']-y['cp'];z['finite_better' if delta>0 else 'finite_worse' if delta<0 else 'finite_equal']+=1
 return dict(declaration=v['declaration'],sampling=v['selected_source_game_indices'],roots=len(v['rows']),contrast=z,interpretation='Exposed finite-reference diagnostics. Not error rates or isolated feature/price effects; small cp deltas uncertain.')
contrasts=dict(royal_activity=contrast('direct-roots.json','royal','activity'),native_gc=contrast('native-gc-roots.json','native','gc_geometric'),royal_classical=contrast('classical-roots.json','royal','classical'))
files.append(p/'classical-roots.json')
entries={};sources={}
def archive(path,items,target):
 assert not path.exists()
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in items:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b)
   z.writestr(n,b);target[n]=dict(bytes=len(b),sha256=sha(b))
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and set(z.namelist())==set(target)
  for n,h in target.items():assert sha(z.read(n))==h['sha256']
archive(a/'raw.zip',[(f,f.name) for f in files],entries)
names=('build_royal_20261007.py','royal_features_20261007.py','royal_games_20261007.py','replay_royal_20261007.py','royal_direct_roots_20261007.py','royal_native_gc_20261007.py','royal_classical_roots_20261007.py','royal_adverse_20261007.py','royal_recording_20261007.py','collect_royal_20261007.py','multipv_player_20261007.py')
upstream=ROOT/'.local_agent/mature-search/Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d'
archive(a/'sources.zip',[(ROOT/'.local_agent'/n,n) for n in names]+[(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(ROOT/'scripts/research_record.py','shared-research_record.py'),(p/'evaluate-royal.cpp','evaluate-royal.cpp'),(p/'royal.patch','royal.patch'),(upstream/'src/evaluate.cpp','pinned-evaluate.cpp'),(upstream/'Copying.txt','upstream-Copying.txt'),(ROOT/'.local_agent/mature-search/material-variants.ini','material-variants.ini'),(ROOT/'.local_agent/mature-openings/suite.json','suite.json')],sources)
features=json.loads((p/'features.json').read_bytes());assert features['complete'] and len(features['static'])==108
adverse=json.loads((p/'adverse.json').read_bytes());assert adverse['complete']
summary=dict(scope='StandardChess exposed development, fixed arbitrary4royal-zone term. No coefficient fitting, price calibration, default/Elo/generic-strength claim. Geometric pseudo-zone includes occupied neighbors; not legal escape or safety proof.',source_pin='9f778da667f6e07dae1e85d3e2ea204fc6dee94d',parent_sha='04b411d2a6bc4c6c96ab193bee2ee400251eb433',cleanup_sha='f2a62a97a541ae79355bc264e0c34c96fcf6f32e',build=norm(build),declaration=json.loads((p/'game-declaration.json').read_bytes()),feature_checks=dict(actual_root_children=len(features['rows']),native_static=len(features['static']),mismatches=0,rows=features['rows']),groups=groups,root_diagnostics=contrasts,adverse=adverse,recording=json.loads((p/'recording.json').read_bytes()),raw_entries=entries,sources=sources,raw_archive=a.relative_to(ROOT).as_posix()+'/raw.zip',sources_archive=a.relative_to(ROOT).as_posix()+'/sources.zip',raw_zip_sha256=sha((a/'raw.zip').read_bytes()),sources_zip_sha256=sha((a/'sources.zip').read_bytes()),production_changes='None; shared search/table/default APIs unchanged',public_push='held')
write_record(out,summary);write_record(a/'index.json',dict(raw_entries=entries,sources=sources,portable_sha256=sha(out.read_bytes())))
print(json.dumps(dict(groups={k:dict(methods=v['methods'],wall_seconds=v['wall_seconds'],replay=v['replay']) for k,v in groups.items()},contrasts=contrasts,sha256=sha(out.read_bytes()))),flush=True)
