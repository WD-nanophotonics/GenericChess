"""One declared royal-zone pilot through the unchanged shared game entry."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/royal-20261007';config=ROOT/'.local_agent/mature-search/material-variants.ini'
bins={'royal':p/'fairy-royal.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe','classical':ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe'}
ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
cohort=sys.argv[1];assert cohort in ('direct','classical','reference')
declfile=p/'game-declaration.json'
if not declfile.exists():
 decl=dict(question='Does fixed royal-zone pressure add useful feedback beyond activity without retuning?',term=json.loads((p/'declaration.json').read_bytes())['term'],design='36prospectively fixed streams:12royal/activity,12royal/classical,12royal/fullstrengthreference. Each two existing prefixes x three unchanged gc tables x both colors. Local1sec SinglePV1 Threads1 Hash16 NNUEfalse; reference50000nodes/1sec;160subsequentplies; fresh hash/game per cell. Cohorts sequential with stop checks every action. Retain losses/unfinished/interruption; no silent rerun or coefficient search.',decision='Practical exposed development, not exact WDL/Elo/holdout/generic strength or default promotion. A weak/negative pilot is not a reason to increase its weight retrospectively.',cost='Each direct/classical cohort <=1920requestedlocal sec; reference<=960local+960fuse sec plus Core/logging. One game at a time. All bounded interruptible, no extra models/workers.',recording='Existing atomic serializer: per-action snapshot of active game, cohort save after every completed game and finally. Same complete final game schema and all rows/history; no new CLI/protocol. Separately count active/cohort writes/bytes/time. Changed producer recording affects elapsed time, not per-player search condition; no old/new throughput causal claim.',binary_sha256={k:sha(f) for k,f in bins.items()},reference_sha256=sha(ref),config_sha256=sha(config),adapter_sha256=sha(ROOT/'scripts/chess_development.py'))
 d.write_record(declfile,decl)
decl=json.loads(declfile.read_bytes());assert all(sha(f)==decl['binary_sha256'][k] for k,f in bins.items())
assert json.loads((p/'features.json').read_bytes())['complete']
class Player(d.UciMaterial):
 def __init__(self,*args,mode,**kw):super().__init__(*args,**kw);self.mode=mode
 def choose(self):
  m,r=super().choose();r.update(leaf_mode=self.mode,leaf_binary_sha256=decl['binary_sha256'][self.mode],requested_seconds=1);return m,r
def stopcheck():
 for n in ('rollout','advisor','slack'):
  v=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if v.get('user_paused') or v.get('stopped'):raise KeyboardInterrupt('User stop retained')
out=p/(cohort+'.json');active=p/(cohort+'-active.json');assert not out.exists()
report=dict(declaration=decl,cohort=cohort,games=[],complete=False)
cost={k:dict(writes=0,bytes=0,seconds=0.) for k in ('active','cohort')}
def save(kind,value):
 t=time.perf_counter();target=active if kind=='active' else out;d.write_record(target,value,indent=None);cost[kind]['writes']+=1;cost[kind]['bytes']+=target.stat().st_size;cost[kind]['seconds']+=time.perf_counter()-t
suite=json.loads((ROOT/'.local_agent/mature-openings/suite.json').read_bytes());c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());start=time.perf_counter();save('cohort',report)
try:
 for case in suite['cases']:
  for policy in d.POLICIES:
   for color in (0,1):
    stopcheck();opponent_mode='activity' if cohort=='direct' else cohort
    with chess.engine.SimpleEngine.popen_uci([str(bins['royal']),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci(str(ref) if cohort=='reference' else [str(bins[opponent_mode]),'load',str(config)],timeout=15) as other:
     e.configure({'Threads':1,'Hash':16,'Use NNUE':False});other.configure({'Threads':1,'Hash':16,**({'UCI_LimitStrength':False} if cohort=='reference' else {'Use NNUE':False})})
     local=Player(e,case['fen'],policy,1,mode='royal');external=d.UciOpponent(other,case['fen'],50000) if cohort=='reference' else Player(other,case['fen'],policy,1,mode=opponent_mode)
     tags=dict(id=case['id'],table=policy,royal_color=color,opponent_mode=opponent_mode)
     def progress(game):save('active',dict(cohort=cohort,**tags,**game));stopcheck()
     g=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=external,local_external=local,prefix=case['opening_uci'])
     report['games'].append(dict(**tags,**g));save('cohort',report)
     print(cohort,len(report['games']),case['id'],policy,color,g['end'],g['winner'],g['plies_played'],flush=True)
 report['complete']=True
finally:report.update(wall_seconds=time.perf_counter()-start,recording_cost={k:dict(v) for k,v in cost.items()});save('cohort',report)
save('active',dict(cohort=cohort,complete=report['complete'],completed_games=len(report['games'])))
print('COMPLETE',cohort,report['complete'],report['wall_seconds'],cost,flush=True)
