"""Actual Core escape/check evidence and independent geometry/native controls."""
import sys,json,hashlib,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
from generic_chess.core.semantic_executor import semantic_engine_for
p=ROOT/'.local_agent/royal-20261007';out=p/'features.json';assert not out.exists()
decl=json.loads((p/'declaration.json').read_bytes());source=ROOT/'.local_agent/classical-control-20261007/direct-roots.json';raw=source.read_bytes();v=json.loads(raw)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());sem=semantic_engine_for(c)
def geometry(b):
 covered={};zone={};pressure={}
 for color in chess.COLORS:
  covered[color]=set().union(*(set(b.attacks(s)) for s,pc in b.piece_map().items() if pc.color==color and pc.piece_type!=chess.KING))
  k=b.king(color);zone[color]=set(b.attacks(k))|{k}
 for color in chess.COLORS:pressure[color]=len(covered[not color]&zone[color])
 return dict(coverage_white=len(covered[True]),coverage_black=len(covered[False]),pressure_white=pressure[True],pressure_black=pressure[False],activity_native=4*(len(covered[True])-len(covered[False])),royal_native=4*(len(covered[True])-len(covered[False])-pressure[True]+pressure[False]))
report=dict(declaration=decl,source_sha256=hashlib.sha256(raw).hexdigest(),scope='Eight fixed actual diagnostic roots and distinct selected children; Core actual legal escapes/check versus occupancy-inclusive native pseudo-zone feature. Exact geometry does not imply exact safety; no fitted coefficients.',rows=[],static=[],complete=False)
fens=[]
for i,r in enumerate(v['rows']):
 g=json.loads((ROOT/'.local_agent/classical-control-20261007/direct.json').read_bytes())['games'][r['game']]
 for move in [None]+sorted({x['move'] for x in r['choices']}):
  prefix=r['history_prefix']+([] if move is None else [move]);s,_=d.replay_prefix(g['initial_fen'],c,prefix);b=chess.Board(g['initial_fen'])
  for m in prefix:b.push_uci(m)
  actions={d.uci(a):a for a in d.iter_legal_actions(s,c)};assert set(actions)=={m.uci() for m in b.legal_moves}
  for color in chess.COLORS:assert sem.in_check(s.position,0 if color else 1)==b.is_attacked_by(not color,b.king(color))
  actor_king=b.king(b.turn);escapes=[m for m in actions if chess.parse_square(m[:2])==actor_king and max(abs(chess.square_file(chess.parse_square(m[2:4]))-chess.square_file(actor_king)),abs(chess.square_rank(chess.parse_square(m[2:4]))-chess.square_rank(actor_king)))<=1]
  report['rows'].append(dict(root=i,game=r['game'],selected_child=move,actor=s.position.side_to_move,fen=b.fen(en_passant='fen'),history_prefix=prefix,core_in_check=sem.in_check(s.position,s.position.side_to_move),core_one_step_royal_escapes=escapes,geometry=geometry(b)))
  fens.append((b.fen(en_passant='fen'),r['policy']))
d.write_record(out,report)
static_positions=[(chess.STARTING_FEN,policy) for policy in d.POLICIES]+fens
binary=p/'fairy-royal.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini'
for fen,policy in static_positions:
 for mirror in (False,True):
  original=chess.Board(fen);original=original.mirror() if mirror else original
  for turn in chess.COLORS:
   b=original.copy();b.turn=turn
   if b.is_check():continue
   weights=d.material_tables()[policy];material=sum((1 if pc.color else -1)*weights.get(pc.symbol().upper(),0) for pc in b.piece_map().values());f=geometry(b);expected=(material+f['royal_native'])/208
   commands=f'uci\nsetoption name UCI_Variant value gc_{policy}\nsetoption name Use NNUE value false\nisready\nposition fen {b.fen(en_passant="fen")}\neval\nquit\n'
   run=subprocess.run([str(binary),'load',str(config)],input=commands,text=True,capture_output=True,timeout=15);found=re.search(r'Final evaluation\s+([+-]?[0-9.]+)',run.stdout);observed=float(found.group(1)) if found else None
   report['static'].append(dict(fen=b.fen(en_passant='fen'),policy=policy,mirror=mirror,expected_white_pawn=expected,observed_white_pawn=observed,geometry=f,stdout=run.stdout,stderr=run.stderr,exit_code=run.returncode));d.write_record(out,report,indent=None)
   assert run.returncode==0 and observed is not None and abs(observed-expected)<=.0101
report['complete']=True;d.write_record(out,report)
print('features',len(report['rows']),'native static',len(report['static']),'zero mismatches',flush=True)
print([(r['root'],r['selected_child'],r['geometry']['pressure_white'],r['geometry']['pressure_black'],r['core_one_step_royal_escapes']) for r in report['rows'] if r['selected_child'] is None],flush=True)
