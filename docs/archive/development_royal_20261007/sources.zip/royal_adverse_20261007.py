"""New royal term at one retained safety failure; no retuning or old reruns."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/royal-20261007';out=p/'adverse.json';assert not out.exists()
source=ROOT/'.local_agent/activity-safety-20261007/forced.json';raw=source.read_bytes();x=json.loads(raw)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());state,_=d.replay_prefix(chess.STARTING_FEN,c,x['history_prefix'])
b=chess.Board(chess.STARTING_FEN)
for m in x['history_prefix']:b.push_uci(m)
assert b.fen(en_passant='fen')==x['fen']
assert {d.uci(a) for a in d.iter_legal_actions(state,c)}=={m.uci() for m in b.legal_moves}
def geometry(b):
 cover={color:set().union(*(set(b.attacks(s)) for s,pc in b.piece_map().items() if pc.color==color and pc.piece_type!=chess.KING)) for color in chess.COLORS}
 zone={color:{b.king(color)}|set(b.attacks(b.king(color))) for color in chess.COLORS}
 pressure={color:len(cover[not color]&zone[color]) for color in chess.COLORS}
 return dict(coverage_white=len(cover[True]),coverage_black=len(cover[False]),pressure_white=pressure[True],pressure_black=pressure[False],royal_native=4*(len(cover[True])-len(cover[False])-pressure[True]+pressure[False]))
report=dict(complete=False,question='Does the new frozen royal term distinguish the retained bad g6g5 root?',declaration='One exposed linearBlack root with full history. New royal build only, two fresh SinglePV1 calls1/4sec Threads1 Hash16 NNUEfalse,5requested seconds. Three already observed candidate children immediate geometry; no coefficient fitting or unchanged old-engine reruns. Static equality cannot predict searched leaf values.',source_sha256=hashlib.sha256(raw).hexdigest(),fen=x['fen'],history_prefix=x['history_prefix'],geometry={'root':geometry(b)},rows=[])
for move in ('g6g5','g6f5','c6c5'):
 child=b.copy(stack=True);child.push_uci(move);report['geometry'][move]=geometry(child)
write=lambda:d.write_record(out,report);write()
for sec in (1,4):
 for name in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused')
 with chess.engine.SimpleEngine.popen_uci([str(p/'fairy-royal.exe'),'load',str(ROOT/'.local_agent/mature-search/material-variants.ini')],timeout=15) as e:
  e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=d.UciMaterial(e,chess.STARTING_FEN,'linear_mixture',sec)
  d.replay_prefix(chess.STARTING_FEN,c,x['history_prefix'],(player,));move,row=player.choose();assert move in {m.uci() for m in b.legal_moves}
  check=b.copy(stack=True)
  for m in row['pv']:check.push_uci(m)
  report['rows'].append(dict(requested_seconds=sec,**row));write();print(sec,move,row.get('score'),row.get('engine_depth'),flush=True)
report['complete']=True;write();print(report['geometry'],flush=True)
