"""Single declared nonroyal attack-union pilot, isolated from pure binary."""
import sys,os,json,time,hashlib,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];p=ROOT/'.local_agent/mature-search'
src=p/'Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d/src'
out=ROOT/'.local_agent/royal-20261007';out.mkdir(exist_ok=True)
assert not (out/'declaration.json').exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
decl=dict(question='Does royal-zone pressure add useful practical feedback beyond the existing nonroyal union?',
 scope='Standard Chess development only, pseudo attacks include friendly occupied squares and pinned pieces; excludes King attacks from coverage; royal zone is King current square plus its one-step pseudo destinations, including occupied neighbors, not legal escapes or exact safety.',
 term='4 native units times coverageDelta-pressureWhite+pressureBlack; pressureOwner counts unique enemy nonroyal attacked squares in its royal zone. Terminal-anchor geometry motivates one unit per threatened zone cell; same arbitrary4 scale as activity, frozen before feature/outcome reads, no fitting. All tables Pawn208;4/208Pawn=1.923cp per unique attacked square. One arbitrary small pilot weight declared before outcomes; not old SharedDynamic equivalence or tuned optimum.',
 decision='Retain positive and adverse static/root/game results. No tuning. Use actual exposed roots diagnostically; fresh declared games are development, not holdout/Elo. Accept only optional further experiment or defer, not default promotion.',
 unchanged='Material tables, normal SEE/search objects, pruning, threads1/hash16. Timed comparisons same conditions; activity overhead changes reachable nodes and is recorded.',
 pure_binary_sha256=sha(p/'build/fairy-material.exe'),source_eval_sha256=sha(src/'evaluate.cpp'))
(out/'declaration.json').write_text(json.dumps(decl,indent=2))
s=(src/'evaluate.cpp').read_text();needle='  if (pos.side_to_move() == BLACK) material = -material;'
assert s.count(needle)==1
code='''  // Declared standard-Chess pilot: nonroyal pseudo attack union, common scale.
  Bitboard covered[COLOR_NB] = {};
  for (Color c : {WHITE, BLACK})
      for (PieceType pt : {PAWN, KNIGHT, BISHOP, ROOK, QUEEN})
      {
          Bitboard b = pos.pieces(c, pt);
          while (b) covered[c] |= pos.attacks_from(c, pt, pop_lsb(b));
      }
  Bitboard royalZone[COLOR_NB] = {};
  for (Color c : {WHITE, BLACK})
  {
      royalZone[c] = pos.pieces(c, KING);
      Bitboard b = pos.pieces(c, KING);
      while (b) royalZone[c] |= pos.attacks_from(c, KING, pop_lsb(b));
  }
  int pressureWhite = popcount(covered[BLACK] & royalZone[WHITE]);
  int pressureBlack = popcount(covered[WHITE] & royalZone[BLACK]);
  material += 4 * (popcount(covered[WHITE]) - popcount(covered[BLACK]) - pressureWhite + pressureBlack);
'''
new=s.replace(needle,code+needle).replace('material leaf without positional terms.','material leaf plus declared nonroyal attack-union and royal-zone pressure pilot.')
copy=out/'evaluate-royal.cpp';copy.write_text(new)
(out/'royal.patch').write_text(__import__('difflib').unified_diff(s.splitlines(True),new.splitlines(True),fromfile='evaluate-pure.cpp',tofile='evaluate-royal.cpp').__iter__().__next__() if False else ''.join(__import__('difflib').unified_diff(s.splitlines(True),new.splitlines(True),fromfile='evaluate-pure.cpp',tofile='evaluate-royal.cpp')))
base=[sys.executable,'-m','ziglang','c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-fno-exceptions','-fno-strict-aliasing','-DNDEBUG','-DIS_64BIT','-DNNUE_EMBEDDING_OFF','-DGENERICCHESS_MATERIAL_DEVELOPMENT']
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(p/'zig-global-cache'),ZIG_LOCAL_CACHE_DIR=str(p/'zig-local-cache'))
report=dict(declaration=decl,commands=[],complete=False);start=time.perf_counter()
obj=out/'evaluate.cpp.o';commands=[base+['-I',str(src),'-c',str(copy),'-o',str(obj)]]
sources=json.loads((p/'build-report.json').read_bytes())['sources']
binary=out/'fairy-royal.exe'
commands.append(base+[str(obj if f=='evaluate.cpp' else p/'build'/(f.replace('/','_')+'.o')) for f in sources]+['-o',str(binary),'-lpthread','-ladvapi32','-Wl,--stack,8388608'])
report['reused_objects']={f:sha(p/'build'/(f.replace('/','_')+'.o')) for f in sources if f!='evaluate.cpp'}
for cmd in commands:
 r=subprocess.run(cmd,cwd=src,env=env,capture_output=True,text=True,timeout=120)
 report['commands'].append(dict(command=cmd,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
 (out/'build.json').write_text(json.dumps(report,indent=2));print('command',r.returncode,flush=True)
 if r.returncode:break
else:report.update(complete=True,binary_sha256=sha(binary))
report['wall_seconds']=time.perf_counter()-start
assert sha(p/'build/fairy-material.exe')==decl['pure_binary_sha256'];assert sha(src/'evaluate.cpp')==decl['source_eval_sha256']
(out/'build.json').write_text(json.dumps(report,indent=2));print(report['complete'],report['wall_seconds'],flush=True)
