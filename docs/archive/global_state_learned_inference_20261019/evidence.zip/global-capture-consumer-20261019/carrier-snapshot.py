from pathlib import Path
from dataclasses import replace
from copy import copy
import json,time,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.core.identity import position_identity_key
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.snapshot import SearchSnapshot
D=Path(__file__).resolve().parent;start=time.perf_counter();p=json.loads((D/'prepared.json').read_bytes());baseline=json.loads((D/'result.json').read_bytes());rule=ruleset_from_dict(p['rule']);c=compile_semantic_ruleset(rule);nr=compile_native_semantic_rules(c)
wrong=compile_semantic_ruleset(replace(rule,semantic_actions=tuple(replace(a,aux_state=tuple(replace(x,scope='per_owner')for x in a.aux_state))for a in rule.semantic_actions)))
assert wrong.ruleset_fingerprint!=c.ruleset_fingerprint
rows=[];Native_queries=main=pv_edges=refused=0
def poll():
 assert time.perf_counter()-start<30
 for n in('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
for parent,old in zip(p['parents'],baseline['rows']):
 poll();s=GameSession.replay(c,deserialize_game_record(json.dumps(parent['record'])));before=(s.state,s.to_record(),s.history,s._search_witnesses)
 cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='global_static256_carrier',board_weights={t:float(v)for t,v in p['board_values'].items()},hand_weights={t:float(v)for t,v in p['hand_values'].items()},material_scale=1.,value_scale=1.,reference_median=256.,training_updates=0)
 cp.validate_ruleset(c)
 try:cp.validate_ruleset(wrong)
 except ValueError:refused+=1
 else:raise AssertionError('wrongscope accepted')
 e=SemanticSearchEngine(c,nr,checkpoint=cp,tt_megabytes=0);tick=time.perf_counter()
 z=e.search(s,SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(1,30-(time.perf_counter()-start)),quiescence_max_depth=0),root_window_pruning=True)
 zz=record_value(z);o=next(x['result']for x in old['native']if x['mode']);eq={k:zz[k]==o[k]for k in('score','action','decision_line','completed_depth','nodes','qnodes')};assert all(eq.values())
 leaf=copy(s)
 for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);pv_edges+=1
 assert old['core']['complete'] and next(x for x in old['native']if x['mode'])['score_matches_Core']
 snap=SearchSnapshot(copy(s),SearchLimits(max_depth=2),c.ruleset_fingerprint,position_identity_key(s.state.position,c),1)
 restored=GameSession.replay(c,deserialize_game_record(serialize_game_record(s.to_record())))
 assert (restored.state,restored.to_record(),restored.history,restored._search_witnesses,restored.result)==(s.state,s.to_record(),s.history,s._search_witnesses,s.result)
 actions=s.legal_actions()
 if actions:restored.submit(actions[0]);s.submit(actions[-1])
 assert (snap.session.state,snap.session.to_record(),snap.session.history,snap.session._search_witnesses)==before
 assert snap.root_key==position_identity_key(snap.session.state.position,c)
 rows.append(dict(phase=parent['phase'],checkpoint=cp.to_dict(),native=zz,equal_fields=eq,existing_Core_target_reused=True,wrong_scope_fingerprint_refused=True,snapshot_root_key=record_value(snap.root_key),snapshot_state=record_value(snap.session.state),record_roundtrip_before_mutation=True,parent_snapshot_unchanged_after_actual_branches=True,native_seconds=time.perf_counter()-tick))
 Native_queries+=1;main+=z.nodes;del e
write_json(D/'carrier-snapshot-result.json',dict(status='PASS_EXISTING_CARRIER_AND_SESSION_SNAPSHOT',rows=rows,Native_queries=Native_queries,Native_main=main,Native_PV_edges=pv_edges,Core_queries=0,reused_Core_targets=4,refused_wrongscope=refused,distinct_wrongscope_rules=1,snapshot_roundtrips=4,seconds=time.perf_counter()-start,new_games=0,optimizer_updates=0,scope='Existingcheckpoint parity/scopefingerprint and existingSearchSnapshot(copy(session))+GameRecord replay onexact4globalparents. No new fullSession-JSON API, no AUXmodel/formatmigration; originalCoretargets reused notrerun.'))
print('GLOBAL_CARRIER_SNAPSHOT',Native_queries,main,pv_edges,refused,time.perf_counter()-start)
