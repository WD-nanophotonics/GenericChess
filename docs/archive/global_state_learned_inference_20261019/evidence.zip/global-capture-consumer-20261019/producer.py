"""Consume the previously prepared complete compound rule without regeneration."""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import snapshot_matches,pack_semantic_action
from generic_chess.native.semantic import snapshot,guarded_actions,public_action,make_checked,terminal_status
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent
start=time.perf_counter();deadline=start+max(0,90-(time.time()-(D/'plan.json').stat().st_mtime))
p=json.loads(Path('docs/research/data/global_capture_next_20261019/prepared.json').read_bytes())
assert hashlib.sha256(Path('docs/research/data/global_capture_next_20261019/prepared.json').read_bytes()).hexdigest()==json.loads((D/'plan.json').read_bytes())['input_sha256']
assert len(p['parents'])==4 and p['status']=='PREPARED_ACTUAL_GLOBAL_CAPTURE'
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
class Stop:
 def __init__(self):self.next=0;self.flag=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.05
   for n in ('rollout','advisor','slack'):
    f=json.loads(Path('.local_agent',n+'.json').read_bytes());self.flag|=bool(f.get('stopped')or f.get('user_paused'))
  return self.flag or now>=deadline
stop=Stop()
def poll():
 if stop.is_cancelled():raise TimeoutError('STOP_OR_CONTINUOUS90S')
class Material:
 def evaluate(self,s):
  v=sum((1 if x.owner==0 else-1)*p['board_values'][x.current_type_id]for x in s.position.board if x)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in p['hand_values'].items())
  return v*(1 if s.position.side_to_move==0 else-1)
rows=[];counts=dict(parents=0,children=0,compound_children=0,Native_queries=0,Core_queries=0,Native_main=0,Native_q=0,Core_main=0,Core_q=0,pv_edges=0);status='COMPLETE';error=None
try:
 c=compile_semantic_ruleset(ruleset_from_dict(p['rule']));nr=compile_native_semantic_rules(c);special={x.pattern_id for x in c.ir.patterns if x.name=='global_capture_type_right'}
 for parent in p['parents']:
  poll();s=GameSession.replay(c,deserialize_game_record(json.dumps(parent['record'])));assert digest(s.state)==parent['state_sha256'] and digest(s._search_witnesses)==parent['witness_sha256']
  original=(s.state,s.to_record(),s.history,s._search_witnesses);root=pack_semantic_search_position(c,nr,s);snap=snapshot(nr,root);aa=s.legal_actions();assert set(aa)=={public_action(nr,x)for x in guarded_actions(nr,root)}
  assert snapshot_matches(snap,s.state.position,nr,c)
  slot,=c.ir.aux_slots;assert slot.scope=='global';logical=dict(s.state.position.aux_state).get((slot.slot_id,-1),slot.initial);assert logical==(1 if parent['phase']in('initial','before_trigger')else 0);assert logical or not any(getattr(a,'pattern_id',None)in special for a in aa)
  assert terminal_status(nr,root)['status']==s.state.terminal_status.status.value
  row=dict(global_right=logical,global_owner_tag=-1,phase=parent['phase'],state_sha256=digest(s.state),witness_sha256=digest(s._search_witnesses),children=[],native=[],core=None)
  for a in aa:
   poll();child=make_checked(nr,root,pack_semantic_action(nr,s.state.position,a));cs=GameSession.replay(c,s.to_record());cs.submit(a);got=snapshot(nr,child);fresh=snapshot(nr,pack_semantic_search_position(c,nr,cs));assert got==fresh and snapshot_matches(got,cs.state.position,nr,c)
   assert terminal_status(nr,child)['status']==cs.state.terminal_status.status.value
   row['children'].append(dict(action=record_value(a),child_state_sha256=digest(cs.state),child_witness_sha256=digest(cs._search_witnesses),native_snapshot_sha256=digest(got),compound=getattr(a,'pattern_id',None)in special))
   counts['children']+=1;counts['compound_children']+=getattr(a,'pattern_id',None)in special
  for mode in (False,True):
   poll();e=SemanticSearchEngine(c,nr,board_values=p['board_values'],hand_values=p['hand_values'],tt_megabytes=0);t=time.perf_counter();z=e.search(s,SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(1,deadline-time.perf_counter()),quiescence_max_depth=0),None,root_window_pruning=mode)
   rr=dict(mode=mode,result=record_value(z),seconds=time.perf_counter()-t);leaf=GameSession.replay(c,s.to_record())
   for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['pv_edges']+=1
   rr['leaf_state_sha256']=digest(leaf.state);row['native'].append(rr);counts['Native_queries']+=1;counts['Native_main']+=z.nodes;counts['Native_q']+=z.qnodes;del e
  poll();st=SearchStatistics();t=time.perf_counter();a,score,pv,cause=run_root_search(s.state,c,Material(),TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(1,deadline-time.perf_counter()),quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
  ref=dict(action=record_value(a),score=score,pv=record_value(pv),cause=cause,statistics=record_value(st),seconds=time.perf_counter()-t,complete=st.completed_depth==2 or cause=='root_immediate_win')
  mapped=score-900000000 if score>=900000000 else score+900000000 if score<=-900000000 else score
  for n in row['native']:
   n['comparable']=bool(ref['complete']and n['result']['completed_depth']==2);n['score_matches_Core']=n['result']['score']==mapped if n['comparable']else None
   if n['comparable']:assert n['score_matches_Core']
  row['core']=ref;counts['Core_queries']+=1;counts['Core_main']+=st.nodes;counts['Core_q']+=st.qnodes
  assert original==(s.state,s.to_record(),s.history,s._search_witnesses)and snap==snapshot(nr,root)
  rows.append(row);counts['parents']+=1
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
out=dict(status=status,error=error,counts=counts,rows=rows,seconds=time.perf_counter()-start,global_cap_seconds=90,input_sha256=hashlib.sha256(Path('docs/research/data/global_capture_next_20261019/prepared.json').read_bytes()).hexdigest(),scope='One generated GLOBALsharedright fullrule/four realparents, finite q0 scalar/edge/history controls. Not full domain/utility/compound pricing. Incomplete slots UNKNOWN; no regeneration or refill.')
write_json(D/'result.json',out)
print(json.dumps({k:v for k,v in out.items()if k!='rows'}))
