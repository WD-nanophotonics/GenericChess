"""Existing carrier/snapshot receipt verification without new Native calls."""
from pathlib import Path
from copy import copy
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.core.identity import position_identity_key
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.alphabeta.snapshot import SearchSnapshot
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;start=time.perf_counter();p=json.loads((D/'prepared.json').read_bytes());old=json.loads((D/'result.json').read_bytes());z=json.loads((D/'carrier-snapshot-result.json').read_bytes());c=compile_semantic_ruleset(ruleset_from_dict(p['rule']))
for parent,baseline,row in zip(p['parents'],old['rows'],z['rows']):
 s=GameSession.replay(c,deserialize_game_record(json.dumps(parent['record'])));cp=LearnableMaterialCheckpoint.from_dict(row['checkpoint']);cp.validate_ruleset(c)
 assert cp.board_weights==p['board_values']and cp.hand_weights==p['hand_values']and cp.material_scale==1
 reference=next(x['result']for x in baseline['native']if x['mode'])
 for k in('score','action','decision_line','completed_depth','nodes','qnodes'):assert row['native'][k]==reference[k]and row['equal_fields'][k]
 snapshot=SearchSnapshot(copy(s),SearchLimits(max_depth=2),c.ruleset_fingerprint,position_identity_key(s.state.position,c),1)
 assert record_value(snapshot.session.state)==row['snapshot_state']and record_value(snapshot.root_key)==row['snapshot_root_key']
 before=(snapshot.session.state,snapshot.session.to_record(),snapshot.session.history,snapshot.session._search_witnesses)
 restored=GameSession.replay(c,deserialize_game_record(serialize_game_record(s.to_record())))
 assert before==(restored.state,restored.to_record(),restored.history,restored._search_witnesses)
 if s.legal_actions():s.submit(s.legal_actions()[-1]);restored.submit(restored.legal_actions()[0])
 assert before==(snapshot.session.state,snapshot.session.to_record(),snapshot.session.history,snapshot.session._search_witnesses)
write_json(D/'carrier-reader-result.json',dict(status='PASS_EXISTING_CARRIER_SNAPSHOT_REPLAY',parents=4,Native_calls=0,Core_searches=0,seconds=time.perf_counter()-start,timing_note='Original per-row native_seconds includes post-search snapshot checks; not isolated caller speed. Scope-fingerprint refusals are original executed receipts, not rerun here.'))
print('CARRIER_READER_PASS',time.perf_counter()-start)
