"""Verify exact published lines/models and legacy-to-semantic full replay."""
from pathlib import Path
from copy import copy
import json,sys,hashlib,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D/'inputs.json').read_bytes());S=json.loads((D/'selected-original-eval-rows.json').read_bytes());inventory=json.loads((D/'source-inventory.json').read_bytes())
for item in inventory['files']:
 b=(D/'published-source'/item['path']).read_bytes();assert len(b)==item['bytes']and hashlib.sha256(b).hexdigest()==item['sha256']
arms=json.loads((D/'published-source/results/dev_aux/task2588/generic/result.json').read_bytes())['arms'];arms={(a['generator_seed'],a['seed']):a for a in arms};mapped=0;many=0
for root,original in zip(I['roots'],S['rows']):
 assert original['source_line']==root['source_line']and hashlib.sha256(original['original_line'].encode()).hexdigest()==root['source_line_sha256']==original['sha256']
 row=json.loads(original['original_line']);assert row==original['row']and row['initial_record']==root['legacy_record']
 r=next(r for r in I['rules']if r['generator_seed']==root['generator_seed']);c=compile_ruleset(ruleset_from_dict(r['rule']));sc=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rule']));a=GameSession(c);b=GameSession(sc)
 for step in root['action_mapping']:
  legal=[x for x in a.legal_actions()if record_value(x)==step['legacy']];assert len(legal)==1;child=copy(a);child.submit(legal[0]);matches=[]
  for candidate in b.legal_actions():
   aa=record_value(candidate);physical={k:v for k,v in aa.items()if k in step['legacy']}
   if physical!=step['legacy']:continue
   sub=copy(b);sub.submit(candidate);assert sub.state.position==child.state.position and sub.result==child.result;matches.append(candidate)
  assert len(matches)==step['physical_variants']and matches;many+=len(matches)>1
  chosen=next(x for x in matches if record_value(x)==step['semantic']);a=child;b.submit(chosen);mapped+=1
 assert json.loads(serialize_game_record(a.to_record()))==root['legacy_record']and json.loads(serialize_game_record(b.to_record()))==root['semantic_record']
for m in I['models']:
 arm=arms[(m['generator_seed'],m['seed'])]
 if m['method']=='Cold@100k':assert m['weights']==arm['weights']and m['snapshot_nodes']==arm['nodes']==100000
 else:assert m['weights']==m['initial']and m['snapshot_nodes']==0
write_json(D/'provenance-reader-result.json',dict(status='PASS_PUBLISHED_BYTES_MODELS_AND_MAPPED_ROOTS',source_files=len(inventory['files']),roots=32,models=32,mapped_prefix_edges=mapped,multiple_semantic_bindings=many,seconds=time.perf_counter()-start,new_games=0,new_queries=0,optimizer_updates=0,scope='Pinned published bytes and selected original source lines; different source Core versions remain documented. No source AUX code executed, no original EVAL audit/rerun or new role inferred.'))
print('PROVENANCE_PASS',len(inventory['files']),mapped,many,time.perf_counter()-start)
