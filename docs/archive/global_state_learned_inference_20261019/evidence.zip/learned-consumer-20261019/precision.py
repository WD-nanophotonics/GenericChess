"""Derive finite-tree quantization bounds and an existing-schema deployment bundle."""
from pathlib import Path
from collections import Counter
import json,time,math,sys
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from generic_chess.learning.material import LearnableMaterialCheckpoint
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D/'inputs.json').read_bytes());Z=json.loads((D/'result.json').read_bytes());models={f"{m['generator_seed']}-{m['seed']}-{m['method']}":m for m in I['models']};trees={(t['generator_seed'],t['family']):t['tree']for t in Z['trees']};roots={(r['generator_seed'],r['family']):r for r in I['roots']};rows=[];bundle=[]
def mm(n,w,side,scale=None):
 if n['terminal']is not None:return n['terminal']*1000000*side
 if 'children'not in n:return side*sum(x*y for x,y in zip(n['phi'],w))
 v=[mm(c['child'],w,side,scale)for c in n['children']];return(max if n['depth']%2==0 else min)(v)
def error(n,w,quant):
 if n['terminal']is not None:return 0.
 if 'children'not in n:return abs(sum(x*(q-v)for x,q,v in zip(n['phi'],quant,w)))
 return max(error(c['child'],w,quant)for c in n['children'])
for q in Z['queries']:
 if q['mode']:continue
 w=models[q['model']]['weights'];tree=trees[(q['generator_seed'],q['family'])]
 # Recover side from the stored current Core tree receipt: native value is STM.
 # Replay data records may start from a non-default setup, so do not assume parity.
 from generic_chess.rules.schema import ruleset_from_dict
 from generic_chess.rules.compiler import compile_ruleset
 from generic_chess.session.session import GameSession
 from generic_chess.session.serialization import deserialize_game_record
 rule=next(r for r in I['rules']if r['generator_seed']==q['generator_seed'])
 s=GameSession.replay(compile_ruleset(ruleset_from_dict(rule['rule'])),deserialize_game_record(json.dumps(roots[(q['generator_seed'],q['family'])]['legacy_record'])))
 side=1 if s.state.position.side_to_move==0 else -1
 quant=[round(v*q['scale'])/q['scale']for v in w];eps=error(tree,w,quant);vals=[mm(c['child'],w,side)for c in tree['children']];best=max(vals);distinct=sorted(set(vals),reverse=True);gap=distinct[0]-distinct[1]if len(distinct)>1 else None
 # Native terminal distance/1e8 band is not the float target's flat 1e6 band.
 # Bound applies to the quantized material tree with IDENTICAL float terminals.
 quantvals=[mm(c['child'],quant,side)for c in tree['children']]
 assert all(abs(a-b)<=eps+1e-8 for a,b in zip(vals,quantvals))
 bad=[a for a,b in zip(vals,quantvals)if abs(b-max(quantvals))<1e-10 and best-a>1e-9]
 robust=gap is not None and gap>2*eps+1e-9
 if robust:assert not bad
 rows.append(dict(model=q['model'],family=q['family'],scale=q['scale'],max_absolute_leaf_error=eps,best_to_next_distinct_gap=gap,float_optimal_action_count=sum(abs(v-best)<1e-9 for v in vals),sufficient_set_preservation_bound=robust,matched_terminal_quantized_optimum_has_float_suboptimal=bool(bad),actual_Native_float_regret=q['float_regret']))
for cid,payload in Z['checkpoints'].items():
 if payload['material_scale']!=256:continue
 cp=LearnableMaterialCheckpoint.from_dict(payload)
 bundle.append(dict(model=cid.rsplit('-scale',1)[0],checkpoint_id=cp.checkpoint_id,config_hash=cp.config_hash,checkpoint=payload))
summary=[]
for scale in(1,256,1000):
 rs=[r for r in rows if r['scale']==scale];summary.append(dict(scale=scale,contexts=len(rs),positive_Native_regret=sum(r['actual_Native_float_regret']>1e-9 for r in rs),sufficient_bound_pass=sum(r['sufficient_set_preservation_bound']for r in rs),maximum_leaf_error=max(r['max_absolute_leaf_error']for r in rs),matching_terminal_quantized_suboptimal_ties=sum(r['matched_terminal_quantized_optimum_has_float_suboptimal']for r in rs)))
write_json(D/'precision-result.json',dict(rows=rows,summary=summary,seconds=time.perf_counter()-start,new_queries=0,scope='Retrospective finite-tree sensitivity. Error bound uses identical terminal bands, excludes Native mate-distance difference. Not an all-state guarantee, model selection, strength, new training or sufficient budget to learn.'))
write_json(D/'bound-checkpoints-scale256.json',dict(source_sha=I['source_sha'],channels=I['channels'],entries=bundle,scope='32 bound original initial/final models, raw weights and signs unchanged. Existing schema2; scale256 is qualified on this exposed panel, not universally exact. Use only exact RuleSet fingerprint; value_scale10, tanh(raw/10); no P normalization or optimizer changes.'))
print('PRECISION',summary,'bundles',len(bundle),time.perf_counter()-start)
