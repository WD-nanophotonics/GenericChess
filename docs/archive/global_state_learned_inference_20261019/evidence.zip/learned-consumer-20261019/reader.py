"""Independent full Core replay and receipt arithmetic; never search Native."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,hashlib,time,math
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.semantic_engine import SemanticSearchEngine
D=Path(__file__).resolve().parent;start=time.perf_counter();counts=Counter()
def forbidden(*a,**k):raise AssertionError('Independent reader cannot search Native')
SemanticSearchEngine.search=forbidden
I=json.loads((D/'inputs.json').read_bytes());Z=json.loads((D/'result.json').read_bytes())
assert Z['status']=='COMPLETE'and Z['error']is None
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def key(a):
 if hasattr(a,'from_square'):return ['board',a.from_square.file,a.from_square.rank,a.to_square.file,a.to_square.rank,getattr(a,'promotion_target_id',None)]
 return ['drop',a.base_type_id,a.to_square.file,a.to_square.rank]
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
def phi(s):
 p=s.state.position
 return [sum((1 if x.owner==0 else -1)for x in p.board if x is not None and x.current_type_id==t)if k=='board'else p.hands[0].count(t)-p.hands[1].count(t)for k,t in I['channels']]
def terminal(s):
 if s.result.status.value=='ongoing':return None
 assert s.result.status.value!='no_contest'and s.result.declaration_outcome not in('RESTART','NO_CONTEST')
 return 0 if s.result.winner is None else 1 if s.result.winner==0 else -1
compiled={};sem={};sessions={};tree_by={}
for r in I['rules']:
 gs=r['generator_seed'];rule=ruleset_from_dict(r['rule']);compiled[gs]=compile_ruleset(rule);sem[gs]=compile_legacy_ruleset_for_semantic_execution(rule)
 assert compiled[gs].ruleset_fingerprint==sem[gs].ruleset_fingerprint==r['fingerprint']
for root,receipt in zip(I['roots'],Z['trees']):
 assert receipt['complete']and(root['generator_seed'],root['family'])==(receipt['generator_seed'],receipt['family'])
 gs=root['generator_seed'];s=GameSession.replay(compiled[gs],deserialize_game_record(json.dumps(root['legacy_record'])));ss=GameSession.replay(sem[gs],deserialize_game_record(json.dumps(root['semantic_record'])))
 assert digest(s.state)==root['legacy_state_sha256']and digest(ss.state)==root['semantic_state_sha256']and digest(ss._search_witnesses)==root['semantic_witness_sha256']
 assert s._search_witnesses==ss._search_witnesses and s.state.position==ss.state.position and s.result==ss.result
 keymap=dict(root['explicit_history_key_isomorphism'])
 assert len(s.state.history)==len(ss.state.history)
 for a,b in zip(s.state.history,ss.state.history):
  assert keymap[a.position_key]==b.position_key and a.actor==b.actor and a.gave_check==b.gave_check
 counts['history_records']+=len(s.history)
 def replay(current,n):
  assert n['state_sha256']==digest(current.state)and n['witness_sha256']==digest(current._search_witnesses)and n['phi']==phi(current)and n['terminal']==terminal(current)
  counts['tree_nodes']+=1
  if n['terminal']is not None or n['depth']==2:assert 'children'not in n;return
  legal=sorted(current.legal_actions(),key=repr);assert len(legal)==len(n['children'])
  for a,child in zip(legal,n['children']):
   assert record_value(a)==child['action']and key(a)==child['key'];sub=copy(current);sub.submit(a);counts['tree_edges']+=1;replay(sub,child['child'])
 replay(s,receipt['tree']);sessions[(gs,root['family'])]=(s,ss);tree_by[(gs,root['family'])]=receipt['tree'];counts['roots']+=1
models={f"{m['generator_seed']}-{m['seed']}-{m['method']}":m for m in I['models']}
for cid,payload in Z['checkpoints'].items():
 cp=LearnableMaterialCheckpoint.from_dict(payload);restored=LearnableMaterialCheckpoint.from_dict(json.loads(json.dumps(cp.to_dict())))
 assert restored.to_dict()==payload and restored.checkpoint_id==cp.checkpoint_id and restored.config_hash==cp.config_hash
 model=models[cid.rsplit('-scale',1)[0]];cp.validate_ruleset(sem[model['generator_seed']])
 assert [cp.board_weights[t]if k=='board'else cp.hand_weights[t]for k,t in I['channels']]==model['weights']and cp.value_scale==10 and not cp.dynamic_weights
 counts['checkpoint_roundtrips']+=1
def mm(n,w,mate,distance,side):
 if n['terminal']is not None:return side*n['terminal']*(mate-n['depth']if distance else mate)
 if 'children'not in n:return side*sum(x*y for x,y in zip(n['phi'],w))
 scores=[mm(x['child'],w,mate,distance,side)for x in n['children']]
 return(max if n['depth']%2==0 else min)(scores)
summary=[]
for q in Z['queries']:
 gs=q['generator_seed'];s,ss=sessions[(gs,q['family'])];tree=tree_by[(gs,q['family'])];w=models[q['model']]['weights'];scale=q['scale'];cp=LearnableMaterialCheckpoint.from_dict(Z['checkpoints'][q['checkpoint_id']]);side=1 if s.state.position.side_to_move==0 else -1
 ints=[round(v*scale)for v in w];f={json.dumps(c['key']):mm(c['child'],w,1e6,False,side)for c in tree['children']};iv={json.dumps(c['key']):mm(c['child'],ints,100000000,True,side)for c in tree['children']};a=decode(q['result']['action']);ak=json.dumps(key(a))
 assert q['integer_optimum']==max(iv.values())==q['result']['score']and iv[ak]==max(iv.values())and q['complete']
 assert q['float_optimum']==max(f.values())and q['float_action_value']==f[ak]and q['float_regret']==max(f.values())-f[ak]
 l=copy(s);sl=copy(ss)
 for raw in q['result']['decision_line']:
  a=decode(raw)
  if isinstance(a,str):l.declare(a);sl.declare(a)
  else:
   matches=[x for x in l.legal_actions()if key(x)==key(a)];assert len(matches)==1;l.submit(matches[0]);sl.submit(a)
  assert l.state.position==sl.state.position and l.result==sl.result;counts['PV_edges']+=1
 assert digest(l.state)==q['legacy_PV_leaf_sha256']and digest(sl.state)==q['semantic_PV_leaf_sha256']and l._search_witnesses==sl._search_witnesses
 raw=sum(x*y for x,y in zip(phi(s),w));carrier=sum((1 if x.owner==0 else -1)*cp.board_weights.get(x.current_type_id,0)for x in s.state.position.board if x)+sum((s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t))*v for t,v in cp.hand_weights.items())
 assert math.isclose(raw,carrier,abs_tol=1e-12,rel_tol=1e-12)and math.isclose(math.tanh(raw/10),math.tanh(carrier/cp.value_scale),abs_tol=1e-12)
 counts['queries']+=1
for scale in(1,256,1000):
 qs=[q for q in Z['queries']if q['scale']==scale];bad=[q for q in qs if q['float_regret']>1e-9]
 summary.append(dict(scale=scale,queries=len(qs),unique_model_roots=len({(q['model'],q['family'])for q in qs}),positive_float_regret=len(bad),unique_positive_regret=len({(q['model'],q['family'])for q in bad}),maximum_raw_float_regret=max(q['float_regret']for q in qs),integer_target_mismatch=0))
write_json(D/'reader-result.json',dict(status='PASS_CORE_REPLAY_AND_RECEIPT_ARITHMETIC',counts=dict(counts),scales=summary,seconds=time.perf_counter()-start,Native_calls=0,new_games=0,optimizer_updates=0,scope='Current Core full trees, exact bound raw models, source-exposed records. Not original AUX execution, WDL, transfer or all-domain guarantee.'))
print('LEARNED_CORE_READER',dict(counts),summary,time.perf_counter()-start)
