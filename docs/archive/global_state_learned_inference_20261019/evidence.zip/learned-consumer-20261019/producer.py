"""Finite D2 inference contract, not AUX training, EVAL rerun or a WDL solver."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib,math
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits

D=Path(__file__).resolve().parent
P=json.loads((D/'plan.json').read_bytes());I=json.loads((D/'inputs.json').read_bytes())
start=time.perf_counter();last_poll=-1.;counts=Counter();trees=[];queries=[];checkpoints={};status='COMPLETE';error=None
assert not(D/'result.json').exists()

def poll():
 global last_poll
 now=time.perf_counter()
 if now-start>=P['global_seconds']:raise TimeoutError('FROZEN_GLOBAL900S')
 if now-last_poll>=.05:
  last_poll=now
  for n in('rollout','advisor','slack'):
   f=json.loads(Path('.local_agent',n+'.json').read_bytes())
   if f.get('stopped')or f.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')

def digest(x):return hashlib.sha256(json.dumps(record_value(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def akey(a):
 if hasattr(a,'from_square'):return ['board',a.from_square.file,a.from_square.rank,a.to_square.file,a.to_square.rank,getattr(a,'promotion_target_id',None)]
 return ['drop',a.base_type_id,a.to_square.file,a.to_square.rank]
def features(s):
 p=s.state.position;v=[]
 for kind,t in I['channels']:
  v.append(sum((1 if x.owner==0 else -1)for x in p.board if x is not None and x.current_type_id==t)if kind=='board'else p.hands[0].count(t)-p.hands[1].count(t))
 return v
def terminal(s):
 r=s.result
 if r.status.value=='ongoing':return None
 if r.status.value=='no_contest'or r.declaration_outcome in('RESTART','NO_CONTEST'):raise ValueError('NON_SCORING_TERMINAL')
 return 0 if r.winner is None else 1 if r.winner==0 else -1

compiled={};semantics={};natives={}
for r in I['rules']:
 gs=r['generator_seed'];rule=ruleset_from_dict(r['rule']);compiled[gs]=compile_ruleset(rule);semantics[gs]=compile_legacy_ruleset_for_semantic_execution(rule)
 assert compiled[gs].ruleset_fingerprint==semantics[gs].ruleset_fingerprint==r['fingerprint']
 assert not compiled[gs].declarations
 natives[gs]=compile_native_semantic_rules(semantics[gs])
train=json.loads((D/'published-source/results/dev_aux/task2588/generic/result.json').read_bytes())
arms={(a['generator_seed'],a['seed']):a for a in train['arms']}

try:
 for root in I['roots']:
  poll();gs=root['generator_seed'];family=root['family'];s=GameSession.replay(compiled[gs],deserialize_game_record(json.dumps(root['legacy_record'])))
  ss=GameSession.replay(semantics[gs],deserialize_game_record(json.dumps(root['semantic_record'])))
  assert digest(s.state)==root['legacy_state_sha256']and digest(ss.state)==root['semantic_state_sha256']
  assert s.state.position==ss.state.position and s.result==ss.result
  edge_start=counts['Core_edges'];local=Counter();entry=dict(generator_seed=gs,family=family,complete=False,tree=None)
  def walk(current,depth,path):
   poll()
   if counts['Core_edges']>=P['max_Core_edges']or counts['Core_edges']-edge_start>=P['max_root_Core_edges']:raise TimeoutError('FROZEN_CORE_EDGE_CAP')
   term=terminal(current);node=dict(depth=depth,terminal=term,phi=features(current),state_sha256=digest(current.state),witness_sha256=digest(current._search_witnesses))
   local['nodes']+=1
   if term is not None or depth==2:return node
   children=[]
   for a in sorted(current.legal_actions(),key=repr):
    poll();child=copy(current);child.submit(a);counts['Core_edges']+=1;local['edges']+=1
    children.append(dict(action=record_value(a),key=akey(a),child=walk(child,depth+1,path+[a])))
   assert children
   node['children']=children
   return node
  try:
   entry['tree']=walk(s,0,[]);entry['complete']=True;counts['closed_Core_roots']+=1
  except TimeoutError as exc:
   entry['error']=str(exc);counts['Core_UNKNOWN_roots']+=1
  entry['paid_counts']=dict(local);trees.append(entry)
  if not entry['complete']:
   if time.perf_counter()-start>=P['global_seconds']:raise TimeoutError('FROZEN_GLOBAL900S')
   continue
  tree=entry['tree']
  if tree['terminal']is not None:
   counts['terminal_roots']+=1;continue
  assert {json.dumps(akey(a))for a in s.legal_actions()}=={json.dumps(akey(a))for a in ss.legal_actions()}
  models=[a for a in I['models']if a['generator_seed']==gs]
  for model in models:
   w=model['weights'];mkey=f"{gs}-{model['seed']}-{model['method']}";original=arms[(gs,model['seed'])]
   if model['method']=='Cold@100k':assert w==original['weights']and model['snapshot_nodes']==original['nodes']==100000
   updates=0 if model['method']=='Cold@0'else original['updates']
   def values(node,coefs,mate,distance,side):
    if node['terminal']is not None:return node['terminal']*(mate-node['depth']if distance else mate)*side
    if 'children'not in node:return sum(x*y for x,y in zip(node['phi'],coefs))*side
    vv=[values(c['child'],coefs,mate,distance,side)for c in node['children']]
    return max(vv)if node['depth']%2==0 else min(vv)
   side=1 if s.state.position.side_to_move==0 else -1
   fv={json.dumps(c['key']):values(c['child'],w,1000000.,False,side)for c in tree['children']};fbest=max(fv.values())
   for scale in P['material_scales']:
    poll();bw={t:0. for t in natives[gs].type_ids};hw=dict(bw)
    for(kind,t),value in zip(I['channels'],w):(bw if kind=='board'else hw)[t]=float(value)
    cp=LearnableMaterialCheckpoint(ruleset_fingerprint=semantics[gs].ruleset_fingerprint,evaluation_profile_version='AUX105_raw_bound_inference',board_weights=bw,hand_weights=hw,material_scale=scale,value_scale=10.,training_updates=updates,training_seed=model['seed'],generation=0 if model['method']=='Cold@0'else 1)
    assert [cp.board_weights[t]if k=='board'else cp.hand_weights[t]for k,t in I['channels']]==w
    cp.validate_ruleset(semantics[gs]);cid=mkey+'-scale'+str(scale)
    if cid not in checkpoints:checkpoints[cid]=cp.to_dict()
    iw=[round(v*scale)for v in w];iv={json.dumps(c['key']):values(c['child'],iw,100000000,True,side)for c in tree['children']};ibest=max(iv.values())
    for mode in P['modes']:
     poll();before=(ss.state,ss.to_record(),ss.history,ss._search_witnesses);e=SemanticSearchEngine(semantics[gs],natives[gs],checkpoint=cp,tt_megabytes=0);tick=time.perf_counter()
     z=e.search(ss,SearchLimits(max_depth=2,max_nodes=P['Native_nodes'],max_time_seconds=min(P['query_seconds'],P['global_seconds']-(time.perf_counter()-start)),quiescence_max_depth=0),root_window_pruning=mode)
     elapsed=time.perf_counter()-tick;del e;zr=record_value(z);complete=z.completed_depth==2 or(abs(z.score)>90000000 and not z.used_fallback)
     key=json.dumps(akey(z.action))if z.action is not None else None;valid=key in fv
     raw_value=sum(x*y for x,y in zip(features(s),w));carrier_raw=sum((1 if x.owner==0 else -1)*bw[x.current_type_id]for x in s.state.position.board if x)+sum((s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t))*v for t,v in hw.items())
     assert math.isclose(raw_value,carrier_raw,abs_tol=1e-12,rel_tol=1e-12)
     sl=copy(ss);ll=copy(s)
     for a in z.decision_line:
      if isinstance(a,str):sl.declare(a);ll.declare(a)
      else:
       match=[b for b in ll.legal_actions()if akey(b)==akey(a)];assert len(match)==1;ll.submit(match[0]);sl.submit(a);counts['Native_PV_edges']+=1
      assert sl.state.position==ll.state.position and sl.result==ll.result
     assert before==(ss.state,ss.to_record(),ss.history,ss._search_witnesses)
     row=dict(query=counts['Native_queries'],generator_seed=gs,family=family,model=mkey,checkpoint_id=cid,scale=scale,mode=mode,result=zr,caller_seconds=elapsed,complete=complete,physical_action_valid=valid,float_optimum=fbest,float_action_value=fv.get(key),float_regret=fbest-fv[key]if complete and valid else None,integer_optimum=ibest,integer_action_value=iv.get(key),integer_score_equal=z.score==ibest if complete else None,integer_action_optimal=iv.get(key)==ibest if complete else None,raw_predictor_equal=True,legacy_PV_leaf_sha256=digest(ll.state),semantic_PV_leaf_sha256=digest(sl.state),physical_PV_witnesses_equal=ll._search_witnesses==sl._search_witnesses)
     queries.append(row);counts['Native_queries']+=1;counts['Native_main']+=z.nodes;counts['Native_q']+=z.qnodes;counts['Native_complete']+=complete
     counts['integer_mismatch']+=bool(complete and(row['integer_score_equal']is False or row['integer_action_optimal']is False));counts['positive_float_regret']+=bool(row['float_regret']is not None and row['float_regret']>1e-9)
  print('LEARNED_D2_ROOT',gs,family,dict(local),counts['Native_queries'],flush=True)
except BaseException as exc:
 status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,trees=trees,queries=queries,checkpoints=checkpoints,counts=dict(counts),seconds=time.perf_counter()-start,optimizer_updates=0,new_games=0,scope='CurrentCore finiteD2 targets onalloriginalexposedroots/allinitial-and100k rawmodels, explicitlegacy-to-semantic replay. Modelcoefficients/signs/predictortanhscale10 preserved, onlyexistingfixedpointscales vary. Not originalAUXsearch-code/WDL replay, holdout, strength/trainingcredit or all-domain equivalence; terminaldistance/optimalsettie distinction explicit. OriginalcacheCoreUNKNOWN remainsunfilled.'))
print('LEARNED_D2_COMPLETE',status,error,dict(counts),time.perf_counter()-start,flush=True)
