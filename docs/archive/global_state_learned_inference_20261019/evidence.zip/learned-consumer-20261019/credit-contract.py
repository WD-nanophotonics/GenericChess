"""Exact optimal-leaf credit ambiguity; no source learner or searches executed."""
from pathlib import Path
import json,sys,time,math
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;start=time.perf_counter();rows=[]
for panel in(D,D.parent/'learned-prospective-20261019'):
 I=json.loads((panel/'inputs.json').read_bytes());Z=json.loads((panel/'result.json').read_bytes());models={f"{m['generator_seed']}-{m['seed']}-{m['method']}":m for m in I['models']}
 queries=[q for q in Z['queries']if q['scale']==256 and q['mode']is True]
 for q in queries:
  assert time.perf_counter()-start<120
  tree=next(t['tree']for t in Z['trees']if(t['generator_seed'],t['family'])==(q['generator_seed'],q['family']));w=models[q['model']]['weights'];leaves={}
  # Values use player0 perspective, so root side must be recovered explicitly.
  from generic_chess.rules.schema import ruleset_from_dict
  from generic_chess.rules.compiler import compile_ruleset
  from generic_chess.session.session import GameSession
  from generic_chess.session.serialization import deserialize_game_record
  root=next(r for r in I['roots']if(r['generator_seed'],r['family'])==(q['generator_seed'],q['family']));rule=next(r for r in I['rules']if r['generator_seed']==q['generator_seed']);s=GameSession.replay(compile_ruleset(ruleset_from_dict(rule['rule'])),deserialize_game_record(json.dumps(root['legacy_record'])));root_side=s.state.position.side_to_move
  def recurse(n):
   if n['terminal']is not None:
    v=n['terminal']*1e6;signature=('terminal',n['terminal']);leaves[n['state_sha256']]=(v,signature);return v,{signature}
   if 'children'not in n:
    v=sum(x*y for x,y in zip(n['phi'],w));signature=('material',*n['phi']);leaves[n['state_sha256']]=(v,signature);return v,{signature}
   children=[recurse(c['child'])for c in n['children']];own=(root_side+n['depth'])%2==0;best=(max if own else min)(v for v,_ in children);selected=set()
   for v,sigs in children:
    if v==best:selected.update(sigs)
   return best,selected
  best,sigs=recurse(tree);gradients=set()
  for sig in sigs:
   if sig[0]=='terminal':grad=(0.,)*len(w)
   else:
    raw=sum(x*y for x,y in zip(sig[1:],w));factor=(1-math.tanh(raw/10)**2)/10;grad=tuple(x*factor for x in sig[1:])
   gradients.add(grad)
  leaf_value,actual_signature=leaves[q['legacy_PV_leaf_sha256']];native_exact_leaf_in_set=actual_signature in sigs
  rows.append(dict(panel=panel.name,model=q['model'],family=q['family'],float_value_player0=best,exact_optimal_leaf_feature_or_terminal_signatures=len(sigs),exact_gradient_vectors=len(gradients),ambiguous_gradient=len(gradients)>1,Native_leaf_in_exact_optimal_signature_set=native_exact_leaf_in_set,Native_leaf_raw_value=leaf_value,actual_Native_float_regret=q['float_regret']))
summary=[]
for panel in(D.name,'learned-prospective-20261019'):
 rs=[r for r in rows if r['panel']==panel];summary.append(dict(panel=panel,contexts=len(rs),ambiguous_gradients=sum(r['ambiguous_gradient']for r in rs),multiple_optimal_leaf_signatures=sum(r['exact_optimal_leaf_feature_or_terminal_signatures']>1 for r in rs),Native_leaf_outside_exact_signature_set=sum(not r['Native_leaf_in_exact_optimal_signature_set']for r in rs),maximum_gradient_vectors=max(r['exact_gradient_vectors']for r in rs)))
write_json(D/'credit-contract-result.json',dict(summary=summary,rows=rows,seconds=time.perf_counter()-start,new_queries=0,optimizer_updates=0,new_games=0,scope='Strict exactfloatbackedupties in existingclosedtrees only. Multiplegradients show possiblecreditambiguity, not actualAUX-versusNativegradientmismatch. SourceAUX randomordering/subnodeintervalsamples and optimizerremainunexecuted/unmigrated. Rawscalaroptimality alone doesnot establishlearningcredit/trajectoryidentity.'))
print('CREDIT_CONTRACT',summary,time.perf_counter()-start)
