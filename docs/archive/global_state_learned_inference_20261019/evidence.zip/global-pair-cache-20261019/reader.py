"""Replay saved global contexts/PVs; do not refill UNKNOWN Core targets."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.semantic_engine import SemanticSearchEngine
def forbidden(*a,**k):raise AssertionError('No Native search or UNKNOWN Core completion')
SemanticSearchEngine.search=forbidden
D=Path(__file__).resolve().parent;start=time.perf_counter();counts=Counter();I=json.loads((D/'inputs.json').read_bytes());Z=json.loads((D/'result.json').read_bytes());analysis=[]
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
assert Z['status']=='COMPLETE'
for r,z in zip(I['rows'],Z['rows']):
 assert r['name']==z['name'];c=compile_semantic_ruleset(ruleset_from_dict(r['rule']));sessions={}
 for b,p in r['parents'].items():
  s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));sessions[b]=s
  assert digest(s.state)==p['state_sha256']and digest(s._search_witnesses)==p['witness_sha256'];assert not z['references'][b]['complete'];counts['UNKNOWN_left_unfilled']+=1
 a=sessions['keep'].state.position;b=sessions['spend'].state.position
 assert(a.board,a.hands,a.side_to_move,a.ply_count)==(b.board,b.hands,b.side_to_move,b.ply_count)if hasattr(a,'ply_count')else(a.board,a.hands,a.side_to_move)==(b.board,b.hands,b.side_to_move)
 assert sessions['keep'].state.ply_count==sessions['spend'].state.ply_count and a.aux_state!=b.aux_state and sessions['keep'].state.history!=sessions['spend'].state.history
 for q in z['queries']:
  s=sessions[q['branch']];assert digest(s.state)==q['state_sha256']and digest(s._search_witnesses)==q['witness_sha256']and q['Core_scalar_equal']is None and not q['Core_comparable']
  l=copy(s)
  for raw in q['result']['decision_line']:
   act=decode(raw);l.declare(act)if isinstance(act,str)else l.submit(act);counts['PV_edges']+=1
  assert digest(l.state)==q['leaf_state_sha256'];counts['Native_receipts']+=1
 for mode in(False,True):
  cold={q['branch']:q['result']['score']for q in z['queries']if q['mode']==mode and q['TT_megabytes']==0}
  assert all(q['result']['score']==cold[q['branch']]for q in z['queries']if q['mode']==mode)
  analysis.append(dict(name=r['name'],mode=mode,Native_spend_minus_keep=cold['spend']-cold['keep'],cold_warm_scalar_coherent=True))
 counts['rules']+=1
write_json(D/'reader-result.json',dict(status='PASS_CORE_CONTEXT_PV_AND_COHERENCE_REPLAY_ONLY',counts=dict(counts),analysis=analysis,seconds=time.perf_counter()-start,Native_calls=0,Core_searches=0,scope='16 original Core targets stay UNKNOWN. Native cold/warm coherence is not independently Core-backed value equality or all-domain cache correctness.'))
print('GLOBAL_PAIR_READER',dict(counts),time.perf_counter()-start)
