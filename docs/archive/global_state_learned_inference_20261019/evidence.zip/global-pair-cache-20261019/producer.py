from pathlib import Path
from copy import copy
from collections import Counter
import json,time,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());inp=json.loads((D/'inputs.json').read_bytes());start=time.perf_counter();counts=Counter();rows=[];differences=[];status='COMPLETE';error=None
assert not(D/'result.json').exists()
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
class Stop:
 def is_cancelled(self):
  if time.perf_counter()-start>=P['consumer_cap_seconds']:return True
  for n in('rollout','advisor','slack'):
   f=json.loads(Path('.local_agent',n+'.json').read_bytes())
   if f.get('stopped')or f.get('user_paused'):return True
  return False
stop=Stop()
def poll():
 if stop.is_cancelled():raise TimeoutError('STOP_OR_FROZEN240S')
class Material:
 def __init__(self,r):self.b=r['board_values'];self.h=r['hand_values']
 def evaluate(self,s):
  p=s.position
  return(sum((1 if x.owner==0 else-1)*self.b[x.current_type_id]for x in p.board if x)+sum((p.hands[0].count(t)-p.hands[1].count(t))*v for t,v in self.h.items()))*(1 if p.side_to_move==0 else-1)
try:
 for r in inp['rows']:
  poll();row=dict(name=r['name'],status=r['status'],references={},queries=[])
  if r['status']!='PREPARED_SAME_PHYSICAL_DIFFERENT_CONTEXT'or r['Native_admission']!='SUPPORTED':rows.append(row);counts['input_UNKNOWN']+=1;continue
  c=compile_semantic_ruleset(ruleset_from_dict(r['rule']));nr=compile_native_semantic_rules(c);sessions={k:GameSession.replay(c,deserialize_game_record(json.dumps(v['record'])))for k,v in r['parents'].items()}
  for branch,s in sessions.items():
   poll();assert digest(s.state)==r['parents'][branch]['state_sha256']and digest(s._search_witnesses)==r['parents'][branch]['witness_sha256'];st=SearchStatistics();tick=time.perf_counter()
   a,v,pv,cause=run_root_search(s.state,c,Material(r),TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(1,P['consumer_cap_seconds']-(time.perf_counter()-start)),quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
   mapped=v-900000000 if v>=900000000 else v+900000000 if v<=-900000000 else v
   row['references'][branch]=dict(action=record_value(a),score=v,mapped_score=mapped,pv=record_value(pv),cause=cause,statistics=record_value(st),complete=st.completed_depth==2 or cause=='root_immediate_win',seconds=time.perf_counter()-tick)
   counts['Core_queries']+=1;counts['Core_main']+=st.nodes
  def query(e,branch,mode,tt,order,index):
   poll();s=sessions[branch];before=(s.state,s.to_record(),s.history,s._search_witnesses);tick=time.perf_counter()
   z=e.search(s,SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(1,P['consumer_cap_seconds']-(time.perf_counter()-start)),quiescence_max_depth=0),root_window_pruning=mode)
   elapsed=time.perf_counter()-tick;ref=row['references'][branch];complete=z.completed_depth==2 or(ref['cause']=='root_immediate_win'and abs(z.score)>90000000 and not z.used_fallback)
   comparable=complete and ref['complete'];equal=z.score==ref['mapped_score']if comparable else None;leaf=copy(s)
   for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['Native_PV_edges']+=1
   assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
   qr=dict(branch=branch,mode=mode,TT_megabytes=tt,order=order,index=index,state_sha256=digest(s.state),witness_sha256=digest(s._search_witnesses),result=record_value(z),caller_seconds=elapsed,Core_comparable=comparable,Core_scalar_equal=equal,leaf_state_sha256=digest(leaf.state))
   row['queries'].append(qr);counts['Native_queries']+=1;counts['Native_main']+=z.nodes;counts['Native_q']+=z.qnodes;counts['tt_hits']+=z.tt_hits;counts['tt_probes']+=z.tt_probes;counts['comparable']+=comparable
   if comparable and not equal:differences.append(dict(name=r['name'],branch=branch,mode=mode,TT=tt,order=order,index=index,Native=z.score,Core=ref['mapped_score']))
  for mode in P['modes']:
   for branch in('keep','spend'):
    e=SemanticSearchEngine(c,nr,board_values=r['board_values'],hand_values=r['hand_values'],tt_megabytes=0);query(e,branch,mode,0,'cold',0);del e
   for oi,order in enumerate(P['orders']):
    e=SemanticSearchEngine(c,nr,board_values=r['board_values'],hand_values=r['hand_values'],tt_megabytes=4)
    for index,branch in enumerate(order):query(e,branch,mode,4,oi,index)
    del e
  if all(x['complete']for x in row['references'].values()):
   row['spend_minus_keep_Core']=row['references']['spend']['score']-row['references']['keep']['score'];counts['complete_Core_pairs']+=1;counts['unequal_Core_targets']+=row['spend_minus_keep_Core']!=0
  rows.append(row);counts['rules']+=1;print('GLOBAL_PAIR_CACHE_RULE',r['name'],len(row['queries']),row.get('spend_minus_keep_Core'),flush=True)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,rows=rows,counts=dict(counts),differences=differences,seconds=time.perf_counter()-start,scope='SameD2/q0 cold/warm complete-context finitecorrectness check. Paths/aux/history alllegitimate anddifferent; no aux-onlyhashisolation, no deepercachedshalloworacle, no root-score-PVleaf/TTspeed/fitness/populationclaim. Allinput/missingreference/queryslots explicitUNKNOWN.'))
print('GLOBAL_PAIR_CACHE_DONE',status,error,dict(counts),'differences',len(differences),time.perf_counter()-start)
