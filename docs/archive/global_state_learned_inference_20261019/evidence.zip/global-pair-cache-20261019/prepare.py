from pathlib import Path
from dataclasses import replace,asdict
from copy import copy
import sys,json,time,random,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import *
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
D=Path(__file__).resolve().parent;start=time.perf_counter();assert not(D/'inputs.json').exists();rows=[]
def poll():
 assert time.perf_counter()-start<180
 for n in('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def saved(s):return dict(record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state),state_sha256=digest(s.state),witness_sha256=digest(s._search_witnesses))
for seed in range(761001,761005):
 for size in(6,8):
  poll();cfg=GeneratorConfig(seed=seed,board_size=size,setup_preset='classic_like',movement_symmetry='none',allow_hybrid=True,max_generation_attempts=64)
  try:g=generate_game(cfg)
  except Exception as exc:rows.append(dict(name=f'{seed}-{size}',status='GENERATION_REFUSAL',error=repr(exc)));continue
  types=tuple(t.type_id for t in g.ruleset.piece_types if not t.is_anchor);target=sorted(t.type_id for t in g.ruleset.piece_types if not t.is_anchor and not t.is_promotable)[0]
  common=dict(type_ids=types,geometry=RuleGeometrySpec(kind='leap',offset=(1,2),owner_relative=True),target_relation='empty',composition='augment',aux_state=(RuleAuxState('shared_capture_right','bool','global','persistent',1),),slot_guards=(RuleSlotGuard('shared_capture_right',value=1),),invariants=(RuleInvariant('own_anchor_safe'),))
  move=RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target'));spend=RuleActionEffect('set_bool',slot_name='shared_capture_right',value=0)
  keep=RuleSemanticAction(name='keep_shared',effects=(move,),**common);deny=RuleSemanticAction(name='spend_shared',effects=(move,spend),**common)
  capture=RuleSemanticAction(name='capture_shared',effects=(move,RuleActionEffect('remove',square_ref=RuleSquareRef('offset_from_source',offset=(0,1),owner_relative=True),piece_owner='opponent',disposition='capture_to_hand'),RuleActionEffect('set_current_type',square_ref=RuleSquareRef('target'),type_ref=RuleTypeRef('explicit',target)),spend),**common)
  rule=replace(g.ruleset,semantic_actions=(keep,deny,capture),metadata={**g.ruleset.metadata,'research_recipe':'shared_right_same_physical_keep_spend'})
  c=compile_semantic_ruleset(rule);slot,=c.ir.aux_slots;assert slot.scope=='global';ids={name:{x.pattern_id for x in c.ir.patterns if x.name==name}for name in('keep_shared','spend_shared','capture_shared')}
  try:compile_native_semantic_rules(c);admission='SUPPORTED';refusal=None
  except NativeUnsupportedRuleError as exc:admission='REFUSED';refusal=str(exc)
  profile=build_ruleset_profile(g.compiled_ruleset,EvaluationConfig());anchors={t.type_id for t in rule.piece_types if t.is_anchor}
  b={t:0 if t in anchors else round(v*.256)for t,v in profile.board_value_by_type.items()};h={t:0 if t in anchors else round(v*.256)for t,v in profile.hand_value_by_base_type.items()}
  row=dict(name=f'{seed}-{size}',config=asdict(cfg),rule=ruleset_to_dict(rule),status='NO_PAIR_WITHIN48',Native_admission=admission,Native_refusal=refusal,board_values=b,hand_values=h,patterns={k:sorted(v)for k,v in ids.items()},ordinary_prefix_plies=0,parents=None)
  s=GameSession(c);rng=random.Random(seed*1000+size)
  for ply in range(48):
   poll();aa=s.legal_actions()
   if not aa:row['status']='TERMINAL_BEFORE_PAIR';break
   found=None
   for a in sorted((a for a in aa if getattr(a,'pattern_id',None)in ids['keep_shared']),key=repr):
    poll();d=next((x for x in aa if getattr(x,'pattern_id',None)in ids['spend_shared']and x.from_square==a.from_square and x.to_square==a.to_square and x.actor_type_id==a.actor_type_id),None)
    if d is None:continue
    sk=copy(s);sk.submit(a);caps=[x for x in sk.legal_actions()if getattr(x,'pattern_id',None)in ids['capture_shared']]
    if caps:found=(a,d,sk,caps);break
   if found:
    a,d,sk,caps=found;sd=copy(s);sd.submit(d);pk,pd=sk.state.position,sd.state.position
    assert(pk.board,pk.hands,pk.side_to_move,sk.state.ply_count)==(pd.board,pd.hands,pd.side_to_move,sd.state.ply_count)
    assert dict(pk.aux_state).get((slot.slot_id,-1),slot.initial)==1 and dict(pd.aux_state)[(slot.slot_id,-1)]==0
    assert not any(getattr(x,'pattern_id',None)in ids['capture_shared']for x in sd.legal_actions())
    row.update(status='PREPARED_SAME_PHYSICAL_DIFFERENT_CONTEXT',ordinary_prefix_plies=ply,parent=saved(s),parents={'keep':saved(sk),'spend':saved(sd)},actual_keep=record_value(a),actual_spend=record_value(d),opponent_captures_after_keep=record_value(caps),physical_board_hands_side_ply_equal=True,full_state_equal=sk.state==sd.state,history_equal=sk.history==sd.history)
    break
   ordinary=[a for a in aa if getattr(a,'pattern_id',None)not in set.union(*ids.values())]
   if not ordinary:row['status']='NO_ORDINARY_CONTINUATION';break
   s.submit(rng.choice(ordinary));row['ordinary_prefix_plies']=ply+1
  if row['parents']is None:row['bounded_end']=saved(s)
  rows.append(row);print('GLOBAL_PAIR_INPUT',row['name'],row['status'],row['ordinary_prefix_plies'],flush=True)
write_json(D/'inputs.json',dict(rows=rows,planned_rules=8,prepared_pairs=sum(x['status']=='PREPARED_SAME_PHYSICAL_DIFFERENT_CONTEXT'for x in rows),seconds=time.perf_counter()-start,Native_queries=0,Core_root_queries=0,new_games=0,optimizer_updates=0,scope='First rule-only oppositecapture opportunity afterquietKEEP versusSPEND within48fixedordinaryplies. SamecompleteRuleSet/physicalboard/hands/side/ply, legitimateaux/history contexts differ. No isolatedauxhash/population/fitnessclaim; failures retained/no regeneration.'))
