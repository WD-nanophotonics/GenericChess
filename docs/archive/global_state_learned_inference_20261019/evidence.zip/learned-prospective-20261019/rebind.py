"""Actual checkpoint rebinding and warm reuse of the existing engine."""
from pathlib import Path
from copy import copy
import json,sys,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;A=D.parent/'learned-consumer-20261019';start=time.perf_counter();I=json.loads((D/'inputs.json').read_bytes());Z=json.loads((D/'result.json').read_bytes());bundle=json.loads((A/'bound-checkpoints-scale256.json').read_bytes());compiled={r['generator_seed']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rule']))for r in I['rules']};rows=[];PV=main=0;controls=[]
def digest(x):return hashlib.sha256(json.dumps(record_value(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
for gs,c in compiled.items():
 root=min((r for r in I['roots']if r['generator_seed']==gs and r['source_terminal']['status']=='ongoing'),key=lambda r:r['family']);s=GameSession.replay(c,deserialize_game_record(json.dumps(root['semantic_record'])));before=(s.state,s.history,s.to_record(),s._search_witnesses)
 models=sorted((m for m in bundle['entries']if int(m['model'].split('-')[0])==gs),key=lambda m:m['model']);e=SemanticSearchEngine(c,compile_native_semantic_rules(c),checkpoint=LearnableMaterialCheckpoint.from_dict(models[0]['checkpoint']),tt_megabytes=4)
 schedule=[(m,'changed_binding')for m in models]+[(models[0],'return_first'),(models[0],'same_id_warm')]
 for index,(item,phase)in enumerate(schedule):
  assert time.perf_counter()-start<60
  for name in('rollout','advisor','slack'):
   f=json.loads(Path('.local_agent',name+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
  oldcapsule=e._capsule;oldid=e.checkpoint_id;cp=LearnableMaterialCheckpoint.from_dict(item['checkpoint']);e.bind_checkpoint(cp)
  assert e.checkpoint_id==cp.checkpoint_id
  if cp.checkpoint_id==oldid:assert e._capsule is oldcapsule
  else:assert e._capsule is not oldcapsule
  old=next(q for q in Z['queries']if(q['model'],q['family'],q['scale'],q['mode'])==(item['model'],root['family'],256,True))
  z=e.search(s,SearchLimits(max_depth=3,max_nodes=200000,max_time_seconds=min(2,60-(time.perf_counter()-start)),quiescence_max_depth=0),root_window_pruning=True);assert z.completed_depth==3 and z.score==old['integer_optimum'];l=copy(s)
  for a in z.decision_line:l.declare(a)if isinstance(a,str)else l.submit(a);PV+=1
  assert before==(s.state,s.history,s.to_record(),s._search_witnesses);main+=z.nodes
  rows.append(dict(generator_seed=gs,family=root['family'],model=item['model'],phase=phase,checkpoint_id=e.checkpoint_id,capsule_reused=oldcapsule is e._capsule,reused_closed_Core_integer_optimum=old['integer_optimum'],result=record_value(z),PV_leaf_state_sha256=digest(l.state),tt_info=e.tt_info()))
 oldcapsule=e._capsule;oldid=e.checkpoint_id;oldvalues=e.native_evaluator_values;wrong=next(m for m in bundle['entries']if int(m['model'].split('-')[0])!=gs)
 try:e.bind_checkpoint(LearnableMaterialCheckpoint.from_dict(wrong['checkpoint']))
 except ValueError:pass
 else:raise AssertionError('Wrong RuleSet rebind accepted')
 assert e._capsule is oldcapsule and e.checkpoint_id==oldid and e.native_evaluator_values==oldvalues;controls.append(dict(generator_seed=gs,wrong_rule_atomic_refusal=True));del e
write_json(D/'rebind-result.json',dict(status='PASS_EXISTING_REBIND_AND_WARM_CONSUMER',rows=rows,controls=controls,Native_queries=len(rows),Native_main=main,Native_PV_edges=PV,Core_queries=0,new_games=0,optimizer_updates=0,seconds=time.perf_counter()-start,scope='All32actualrawmodelbindings plus4return-first/4sameIDwarmcalls,4wrongRuleSetatomicrefusals. SameD3closedintegerreferences reused; no globalcacheUNKNOWNrefill, TTperformance/strength/newAPI/AUXlearning claim.'))
print('REBIND_PASS',len(rows),main,PV,time.perf_counter()-start)
