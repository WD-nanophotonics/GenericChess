"""Exercise the actually serialized bound artifact with the existing Native API."""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;R=Path.cwd();start=time.perf_counter();I=json.loads((D/'inputs.json').read_bytes());Z=json.loads((D/'result.json').read_bytes());bundle=json.loads((D.parent/'learned-consumer-20261019/bound-checkpoints-scale256.json').read_bytes());rows=[];compiled={};native={};main=0
for r in I['rules']:
 gs=r['generator_seed'];compiled[gs]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rule']));native[gs]=compile_native_semantic_rules(compiled[gs])
for item in sorted(bundle['entries'],key=lambda x:x['model']):
 assert time.perf_counter()-start<60
 for name in('rollout','advisor','slack'):
  flags=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
 gs=int(item['model'].split('-')[0]);cp=LearnableMaterialCheckpoint.from_dict(item['checkpoint']);assert cp.checkpoint_id==item['checkpoint_id']and cp.config_hash==item['config_hash']
 c=compiled[gs];cp.validate_ruleset(c)
 root=min((r for r in I['roots']if r['generator_seed']==gs and r['source_terminal']['status']=='ongoing'),key=lambda r:r['family'])
 s=GameSession.replay(c,deserialize_game_record(json.dumps(root['semantic_record'])));before=(s.state,s.history,s.to_record(),s._search_witnesses)
 old=next(q for q in Z['queries']if(q['model'],q['family'],q['scale'],q['mode'])==(item['model'],root['family'],256,True))
 e=SemanticSearchEngine(c,native[gs],checkpoint=cp,tt_megabytes=0);tick=time.perf_counter();z=e.search(s,SearchLimits(max_depth=3,max_nodes=200000,max_time_seconds=min(2,60-(time.perf_counter()-start)),quiescence_max_depth=0),root_window_pruning=True);seconds=time.perf_counter()-tick;del e;actual=record_value(z)
 fields={k:actual[k]==old['result'][k]for k in('score','action','decision_line','completed_depth','nodes','qnodes')};assert all(fields.values())
 assert before==(s.state,s.history,s.to_record(),s._search_witnesses);main+=z.nodes
 refused=0
 for othergs,other in compiled.items():
  if othergs==gs:continue
  try:cp.validate_ruleset(other)
  except ValueError:refused+=1
  else:raise AssertionError('Wrong RuleSet accepted')
 rows.append(dict(model=item['model'],family=root['family'],checkpoint_id=cp.checkpoint_id,Native_result=actual,equal_fields=fields,reused_closed_Core_tree=True,wrong_rule_refusals=refused,caller_seconds=seconds))
write_json(D/'serialized-consumer-result.json',dict(status='PASS_JSON_TO_NATIVE_BOUND_CONSUMER',rows=rows,Native_queries=len(rows),Native_main=main,wrong_rule_refusals=sum(r['wrong_rule_refusals']for r in rows),Core_queries=0,new_games=0,optimizer_updates=0,seconds=time.perf_counter()-start,scope='All32existing-schema rawcheckpoint JSON artifacts atscale256 match existing constructed-objectD3receipts, preservingparentfullstate/history. No newformat/default/learner or strengthclaim; reusedclosedCoretargets, not independentreferences.'))
print('SERIALIZED_CONSUMER_PASS',len(rows),main,time.perf_counter()-start)
