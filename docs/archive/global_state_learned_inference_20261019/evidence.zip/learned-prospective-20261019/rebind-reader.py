"""Core PV/closed-target and binding-receipt verification, no Native calls."""
from pathlib import Path
from copy import copy
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D/'inputs.json').read_bytes());Z=json.loads((D/'result.json').read_bytes());R=json.loads((D/'rebind-result.json').read_bytes());compiled={r['generator_seed']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rule']))for r in I['rules']};edges=0
def digest(x):return hashlib.sha256(json.dumps(record_value(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
for row in R['rows']:
 old=next(q for q in Z['queries']if(q['model'],q['family'],q['scale'],q['mode'])==(row['model'],row['family'],256,True));assert row['result']['score']==old['integer_optimum']==row['reused_closed_Core_integer_optimum']and row['result']['completed_depth']==3
 root=next(r for r in I['roots']if(r['generator_seed'],r['family'])==(row['generator_seed'],row['family']));s=GameSession.replay(compiled[row['generator_seed']],deserialize_game_record(json.dumps(root['semantic_record'])));l=copy(s)
 for raw in row['result']['decision_line']:l.declare(raw)if isinstance(raw,str)else l.submit(decode(raw));edges+=1
 assert digest(l.state)==row['PV_leaf_state_sha256']
 if row['phase']=='return_first':assert not row['capsule_reused']
 if row['phase']=='same_id_warm':assert row['capsule_reused']
assert len(R['rows'])==40 and all(x['wrong_rule_atomic_refusal']for x in R['controls'])and edges==120
write_json(D/'rebind-reader-result.json',dict(status='PASS_CORE_REBIND_RECEIPTS',Native_receipts=40,PV_edges=edges,atomic_wrongrule_refusal_receipts=4,Native_calls=0,Core_searches=0,seconds=time.perf_counter()-start,scope='Actualbindingidentity/atomicity checks are originalexecutedreceipts; thisreader independentlychecksallPVs andexistingclosedintegertargets only. No original16UNKNOWNCoretargets refilled.'))
print('REBIND_READER_PASS',edges,time.perf_counter()-start)
