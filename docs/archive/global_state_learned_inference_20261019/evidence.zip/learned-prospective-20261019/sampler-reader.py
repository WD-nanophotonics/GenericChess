"""Verify prespecified random prefixes without generating new inputs/searches."""
from pathlib import Path
import json,sys,random,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D/'inputs.json').read_bytes());P=json.loads((D/'plan.json').read_bytes());edges=terminals=0
assert hashlib.sha256((D/'inputs.json').read_bytes()).hexdigest()==P['inputs_sha256']
for r in I['rules']:
 gs=r['generator_seed'];c=compile_ruleset(ruleset_from_dict(r['rule']))
 for family,plies in zip(P['prefix_seeds'],(4,8,12,16)):
  row=next(x for x in I['roots']if(x['generator_seed'],x['family'])==(gs,family));s=GameSession(c);rng=random.Random((gs<<20)+family);mapping=row['action_mapping']
  for j in range(plies):
   aa=sorted(s.legal_actions(),key=repr)
   if not aa:break
   a=aa[rng.randrange(len(aa))];assert record_value(a)==mapping[j]['legacy'];s.submit(a);edges+=1
  assert json.loads(serialize_game_record(s.to_record()))==row['legacy_record']and s.state.ply_count==row['actual_prefix']
  terminals+=s.result.status.value!='ongoing'
write_json(D/'sampler-reader-result.json',dict(status='PASS_FIXED_RANDOM_PREFIXES',roots=16,prefix_edges=edges,terminal_roots=terminals,new_queries=0,seconds=time.perf_counter()-start,scope='Same4originalRuleSets, newdeterministicrandomprefixes; not broaderdomain, populationorstrengthholdout. No value-based input/model selection.'))
print('PROSPECTIVE_SAMPLER_PASS',edges,terminals,time.perf_counter()-start)
