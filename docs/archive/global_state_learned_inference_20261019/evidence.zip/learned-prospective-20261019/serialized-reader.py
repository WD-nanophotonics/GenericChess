"""Verify saved JSON-to-Native receipts and actual Python predictor algebra."""
from pathlib import Path
import json,sys,time,math
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.learning.features import material_features,linear_value,non_anchor_type_ids
from generic_chess.learning.tdleaf import _normalized_value
D=Path(__file__).resolve().parent;A=D.parent/'learned-consumer-20261019';start=time.perf_counter();Z=json.loads((D/'result.json').read_bytes());S=json.loads((D/'serialized-consumer-result.json').read_bytes());bundle=json.loads((A/'bound-checkpoints-scale256.json').read_bytes());models={x['model']:x for x in bundle['entries']};compiled={};sem={};predictors=0;refusals=0
for I in(json.loads((A/'inputs.json').read_bytes()),json.loads((D/'inputs.json').read_bytes())):
 for r in I['rules']:
  gs=r['generator_seed'];rule=ruleset_from_dict(r['rule']);compiled[gs]=compile_ruleset(rule);sem[gs]=compile_legacy_ruleset_for_semantic_execution(rule)
 for root in I['roots']:
  gs=root['generator_seed'];s=GameSession.replay(compiled[gs],deserialize_game_record(json.dumps(root['legacy_record'])));features=material_features(s.state.position,non_anchor_type_ids(compiled[gs]),perspective=0)
  for item in bundle['entries']:
   if int(item['model'].split('-')[0])!=gs:continue
   cp=LearnableMaterialCheckpoint.from_dict(item['checkpoint']);cp.ensure_within_limits();cp.validate_ruleset(sem[gs]);w=next(m['weights']for m in I['models']if m['generator_seed']==gs and f"{gs}-{m['seed']}-{m['method']}"==item['model'])
   phi=[sum((1 if p.owner==0 else -1)for p in s.state.position.board if p is not None and p.current_type_id==t)if k=='board'else s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t)for k,t in I['channels']];raw=sum(x*y for x,y in zip(phi,w))
   assert math.isclose(raw,linear_value(features,cp.board_weights,cp.hand_weights),abs_tol=1e-12,rel_tol=1e-12)
   assert math.isclose(math.tanh(raw/10),_normalized_value(features,cp.board_weights,cp.hand_weights,cp.value_scale),abs_tol=1e-12,rel_tol=1e-12);predictors+=1
for row in S['rows']:
 cp=LearnableMaterialCheckpoint.from_dict(models[row['model']]['checkpoint']);assert cp.checkpoint_id==row['checkpoint_id']
 old=next(q for q in Z['queries']if(q['model'],q['family'],q['scale'],q['mode'])==(row['model'],row['family'],256,True))
 for k in row['equal_fields']:assert row['equal_fields'][k]and row['Native_result'][k]==old['result'][k]
 gs=int(row['model'].split('-')[0])
 for othergs,c in sem.items():
  if gs==othergs:continue
  try:cp.validate_ruleset(c)
  except ValueError:refusals+=1
  else:raise AssertionError('Mismatched RuleSet admitted')
assert refusals==S['wrong_rule_refusals']==96
write_json(D/'serialized-reader-result.json',dict(status='PASS_SERIALIZED_RECEIPTS_AND_PYTHON_PREDICTOR',Native_receipts=len(S['rows']),wrong_rule_refusals=refusals,raw_python_predictors=predictors,Native_calls=0,Core_searches=0,new_games=0,optimizer_updates=0,seconds=time.perf_counter()-start,scope='Actual existing material_features/linear_value/normalized_value agree with source feature contract on both panels, including negative coefficients. Raw terminal evaluation here is algebra only; no change to terminal training targets.'))
print('SERIALIZED_READER_PASS',len(S['rows']),refusals,predictors,time.perf_counter()-start)
