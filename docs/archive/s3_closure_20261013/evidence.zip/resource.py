from pathlib import Path
import ast,sys,time,json,random,hashlib
from contextlib import nullcontext
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import candidate_writes as candidate
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core import semantic_executor as se
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/s3-closure-20261013');out=D/'resource';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does private actual-write S3 influence retain useful q0/q4 decisions on four previously exposed roots at16/64seconds? No new holdout or production adoption.',seeds=[2026101961,2026101962,2026101963,2026101964],sizes=[18,20,18,20],prefix=8,rng_offset=16000,q=[0,4],seconds=[16,64],orders=2,arms=['original','candidate'],max_depth=12,max_nodes=None,hardq=8,planned_calls=64,requested_search_seconds=2560,fuse=3300,expected_run_minutes=45,no_resample=True,backend='Core explicit, Native>16 unavailable not changed',comparison='same rules/evaluator/profile/complete history; retain all cases, errors, partials/caps; same-depth tuples and work distinct from horizon gains; ordinary concurrent load',candidate_private_sha=hashlib.sha256((D/'candidate_writes.py').read_bytes()).hexdigest(),candidate_source_sha=hashlib.sha256(Path(se.__file__).read_bytes()).hexdigest()))
rows=[];samples=[];unavailable=[];start=time.perf_counter()
try:
 for seed,size in zip([2026101961,2026101962,2026101963,2026101964],[18,20,18,20]):
  p.rr.stopped();assert time.perf_counter()-start<3300
  g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support)
  s=p.GameSession(c);rng=random.Random(seed+16000);walk=[]
  try:
   for _ in range(8):
    acts=sorted(s.legal_actions(),key=repr)
    if not acts or s.result.status.value!='ongoing':raise ValueError('prefix unavailable')
    a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
   if s.result.status.value!='ongoing':raise ValueError('rootterminal')
  except (ValueError,RuntimeError,NotImplementedError) as e:
   unavailable.append(dict(seed=seed,error_type=type(e).__name__,error=str(e),unexecuted_cells=16,resampled=False));write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable));continue
  ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
  samples.append(dict(seed=seed,size=size,ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk,index_present=c._incoming_attack_paths is not None,endpoint_rows=sum(len(r) for sources in (c._incoming_attack_endpoints or {}).values() for typed in sources.values() for r in typed.values()),evaluation_config=record_value(ec),profile=record_value(profile)))
  write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable))
  before=s.to_record()
  for q in [0,4]:
   for seconds in [16,64]:
    for rep in range(2):
     for arm in (['original','candidate'] if rep==0 else ['candidate','original']):
      p.rr.stopped();assert time.perf_counter()-start<3300
      player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
      t=time.perf_counter()
      with candidate.installed() if arm=='candidate' else nullcontext():
       d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=seconds,quiescence_max_depth=q,quiescence_hard_max_depth=8))
       stats=dict(candidate.STATS) if arm=='candidate' else {}
      wall=time.perf_counter()-t
      assert before==s.to_record();child=s.state
      for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
      rows.append(dict(seed=seed,size=size,q=q,seconds=seconds,rep=rep,arm=arm,wall=wall,decision=record_value(d),actual_provider=player.native_legality_provider is not None,history_restored=True,pv_core_legal=True,private_stats=stats))
      write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable));print(seed,q,seconds,rep,arm,round(wall,3),d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
finally:assert se.SemanticEngine.in_check is candidate.OLD_CHECK and not candidate.ACTIVE

