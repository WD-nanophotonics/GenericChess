from pathlib import Path
import sys,random,time,json,collections
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.core import semantic_executor as se
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/s3-closure-20261013')
write_record(D/'caller-declaration.json',dict(question='Which actual consumers request only existence versus complete frontier? Final scoped profile spends2.10-2.12 seconds preparing4308 contexts; caller cardinality may change next interface choice.',seed=2026101962,size=20,prefix=8,rng_offset=16000,q=0,depth=6,nodes=4096,seconds=64,planned_calls=1,scope='Original production S3, lightweight generator-consumption/caller observation only. Instrumented walltime is not speed evidence. Compare fullnon-time result/work to original fixed plane.',decision='If substantial one-action existence consumers pay preparation, target an explicit existing full-frontier caller before broad S3 setup. Otherwise inspect one preparation primitive; no new engine/framework.'))
g=p.generate_game(p.GeneratorConfig(seed=2026101962,board_size=20,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(2026101962+16000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
ec=p.EvaluationConfig();prof=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,prof,ec);before=s.to_record();original=se.SemanticEngine.iter_legal_action_bindings;groups={}
def observed(self,position,checkpoint=None,*,source=None,target=None):
 frame=sys._getframe(1);names=[]
 while frame is not None and len(names)<18:
  names.append((Path(frame.f_code.co_filename).name,frame.f_code.co_name,frame.f_lineno));frame=frame.f_back
 del frame
 key=tuple(names);yielded=0;exhausted=False
 try:
  for item in original(self,position,checkpoint=checkpoint,source=source,target=target):
   yielded+=1;yield item
  exhausted=True
 finally:
  entry=groups.setdefault(key,collections.Counter());entry['frontiers']+=1;entry['yielded']+=yielded;entry['exhausted']+=int(exhausted);entry['first_only']+=int(yielded==1 and not exhausted);entry['zero']+=int(yielded==0)
se.SemanticEngine.iter_legal_action_bindings=observed
try:
 p.rr.stopped();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=4096,max_time_seconds=64,quiescence_max_depth=0,quiescence_hard_max_depth=8));wall=time.perf_counter()-t;assert before==s.to_record()
finally:se.SemanticEngine.iter_legal_action_bindings=original
baseline=json.loads((D/'scoped-fixed/rows.json').read_text(encoding='utf-8'))['rows']
old=next(r['decision'] for r in baseline if r['seed']==2026101962 and r['rep']==0 and r['arm']=='original')
cur=record_value(d);times={'elapsed_seconds','time_to_first_legal_action','time_to_first_completed_iteration','ordering_seconds','legal_generation_seconds','evaluation_seconds'}
diff=[k for k in old if k not in times and old[k]!=cur[k]];assert not diff
rows=[dict(chain=list(key),**dict(counts)) for key,counts in groups.items()];rows.sort(key=lambda r:r['frontiers'],reverse=True)
write_record(D/'caller-rows.json',dict(complete=True,actual_search_calls=1,decision=cur,full_non_time_work_equal=True,history_restored=True,instrumented_wall=wall,rows=rows,total_frontiers=sum(r['frontiers'] for r in rows),first_only_frontiers=sum(r['first_only'] for r in rows),exhausted_frontiers=sum(r['exhausted'] for r in rows),actual_native=player.native_legality_provider is not None))
print('actual consumption',[(r['frontiers'],r['first_only'],r['exhausted'],r['chain'][:6]) for r in rows[:6]],flush=True)
