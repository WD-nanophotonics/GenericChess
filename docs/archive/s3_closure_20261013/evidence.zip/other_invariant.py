from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from rule_semantics_ir_fixtures import _king_type,_ray_type,_semantic_ruleset,_ref
from generic_chess.rules.schema import RuleSemanticAction,RuleGeometrySpec,RuleReplaceSelector,RuleActionEffect,RuleInvariant
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
import candidate_safe as cand
D=Path('.local_agent/s3-closure-20261013')
pattern=RuleSemanticAction(name='own_anchor_and_remote_safety',type_ids=('B',),geometry=RuleGeometrySpec(kind='leap',offset=(-1,0)),target_relation='empty',composition='replace_legacy',replace_selector=RuleReplaceSelector(type_ids=('B',),action_family='board',target_relation='empty',geometry_kind='leap',replace_all_matching=True),effects=(RuleActionEffect('move',from_ref=_ref('source'),to_ref=_ref('target')),),invariants=(RuleInvariant('own_anchor_safe'),RuleInvariant('squares_not_attacked',square_refs=(_ref('fixed',square=(3,0),owner_relative=False),))))
rows=[[None]*4 for _ in range(4)];rows[0][0]=Piece(0,'K','K');rows[3][1]=Piece(1,'K','K');rows[3][3]=Piece(1,'R','R');rows[1][3]=Piece(0,'B','B')
rules=_semantic_ruleset((_king_type(),_ray_type('R',(RayAtom((0,-1)),RayAtom((0,1)))),_ray_type('B',(LeapAtom((-1,0)),))), (pattern,),n=4,rows=tuple(tuple(x) for x in rows))
c=compile_ruleset_for_execution(rules);s=GameSession(c);e=SemanticEngine(c);pos=s.state.position;e._private_capture_eligible=cand.eligible(e)
ctx=cand.prepare(e,pos,None);assert ctx is not None and not ctx[4];assert 6 not in ctx[3] and 7 not in ctx[3]
assert not e.is_square_attacked(pos,3,1)
w=[]
for p in e._patterns:
 for a,b in e._iter_candidates(p,pos):
  if p.name!='own_anchor_and_remote_safety':continue
  assert b.source==7 and b.target==6
  child=e._transition(pos,a,b);assert not e.in_check(child,0) and e.is_square_attacked(child,3,1)
  assert e._trial_child_if_s3_legal(p,pos,a,b) is None
  with cand.installed() as stats:
   e._private_s3_context=ctx
   assert e._trial_child_if_s3_legal(p,pos,a,b) is None
   assert stats.get('skipped',0)==1
   e._private_s3_context=None
  w.append(dict(action=record_value(a),anchor_influence=sorted(ctx[3]),child_anchor_safe=True,remote_square=3,remote_parent_attacked=False,remote_child_attacked=True,original_rejects=True,candidate_reuses_anchor_but_other_invariant_rejects=True))
assert w
baseline=e.legal_actions(pos)
with cand.installed():assert e.legal_actions(pos)==baseline
write_record(D/'other-invariant-counter.json',dict(complete=True,ruleset=record_value(rules),witnesses=w,full_ordered_frontier_equal=True,source='Dot source-derived candidate executed by PRIMARY; no Dot local execution claimed',scope='Valid complete DSL with two distinct S3 invariants. Reuse only own-anchor branch in original S3 loop; never return child early.'))
print(w)
