from pathlib import Path
import sys,time,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
sys.path.insert(0,str(ROOT/'tests/product'))
import candidate_writes as cand
from generic_chess.core import semantic_executor as se
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from test_compiled_endpoint_fallback import DEFINITIONS
from scripts.research_record import write_record
D=Path('.local_agent/s3-closure-20261013')
rows=[]
for no,rules in enumerate(DEFINITIONS):
 c=compile_ruleset_for_execution(rules);s=GameSession(c);engine=se.SemanticEngine(c)
 for ply in range(4):
  pos=s.state.position;original=tuple(engine.iter_legal_action_bindings(pos))
  children=[engine._transition(pos,a,b) for a,b in original]
  with cand.installed() as stats:
   other=tuple(engine.iter_legal_action_bindings(pos));assert other==original
   assert [engine._transition(pos,a,b) for a,b in other]==children
   counts=dict(stats)
  rows.append(dict(fixture=no,ply=ply,eligible=cand.eligible(engine),actions=len(original),stats=counts,frontier_children_equal=True))
  if not original or s.state.terminal_status.is_terminal:break
  s.submit(sorted(s.legal_actions(),key=repr)[0])
# Independently trace full write closure on actual transitions incl promotion/aux/drop.
transitions=0
for rules in DEFINITIONS:
 c=compile_ruleset_for_execution(rules);s=GameSession(c);e=se.SemanticEngine(c);pos=s.state.position
 for p in e._patterns:
  for a,b in e._iter_candidates(p,pos):
   with cand.installed():
    t=[pos,None,None];cand.ACTIVE.append(t)
    try:
     try:child=e._transition(pos,a,b)
     except RuntimeError:continue
     changed={i for i,(x,y) in enumerate(zip(pos.board,child.board)) if x!=y}
     assert t[2] is not None and changed<=t[2]
     transitions+=1
    finally:cand.ACTIVE.pop()
# The retained valid remote guard example must decline and preserve S3 rejection.
ns=dict(__name__='retained_counter',__file__=str(ROOT/'.local_agent/fallback-integration-20261013/s3-guard-counter.py'))
exec(compile((ROOT/'.local_agent/fallback-integration-20261013/s3-guard-counter.py').read_text(encoding='utf-8').replace("D=Path('.local_agent/fallback-integration-20261013')","D=Path('.local_agent/s3-closure-20261013')"),'retained-guard-counter','exec'),ns)
assert not cand.eligible(ns['engine'])
guard_baseline=ns['engine'].legal_actions(ns['position'])
with cand.installed() as stats:
 assert ns['engine'].legal_actions(ns['position'])==guard_baseline
 assert stats.get('skipped',0)==0
# Cancel and recover actual frontier, clear local state including nested trials.
c=compile_ruleset_for_execution(DEFINITIONS[0]);e=se.SemanticEngine(c);pos=GameSession(c).state.position
baseline=e.legal_actions(pos)
cancel=[]
for at in [1,4,16,64,256]:
 count=[0]
 def stop():
  count[0]+=1
  if count[0]>=at:raise InterruptedError('finite cancellation')
 with cand.installed():
  try:tuple(e.iter_legal_action_bindings(pos,checkpoint=stop))
  except InterruptedError:pass
  else:raise AssertionError('did not cancel')
  assert getattr(e,'_private_s3_context',None) is None and getattr(e,'_private_s3_trial',None) is None and not cand.ACTIVE
  assert e.legal_actions(pos)==baseline
 cancel.append(at)
write_record(D/'grammar-rows.json',dict(complete=True,rows=rows,actual_transition_write_closure=transitions,remote_guard_declined=True,cancel_recovery=cancel,production_installed=False))
print('grammar',len(rows),'writeclosure',transitions,'cancel',cancel,flush=True)
