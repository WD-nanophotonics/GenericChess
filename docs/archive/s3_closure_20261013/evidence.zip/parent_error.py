from pathlib import Path
import sys,types,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));sys.path.insert(0,str(ROOT/'tests/product'))
from dataclasses import replace
import candidate_writes as c
from generic_chess.core import semantic_executor as se
from generic_chess.rules.compiler import compile_ruleset_for_execution
from test_compiled_endpoint_fallback import DEFINITIONS
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
D=Path('.local_agent/s3-closure-20261013')
rules=compile_ruleset_for_execution(DEFINITIONS[0]);pos=GameSession(rules).state.position
# Fault seam only: no pseudo candidates. Original frontier need not perform check.
def engine():
 e=se.SemanticEngine(rules)
 e._iter_candidates=types.MethodType(lambda self,*a,**kw:iter(()),e)
 def bad(*a,**kw):raise RuntimeError('parent-only required binding')
 e._make_binding=bad
 return e
# Initial standard Chess king has no geometrically reaching enemy actor, so use own king as target? Use valid retained counter with guards removed.
ns=dict(__file__=str(ROOT/'.local_agent/fallback-integration-20261013/s3-guard-counter.py'))
s=(ROOT/'.local_agent/fallback-integration-20261013/s3-guard-counter.py').read_text(encoding='utf-8')
s=s[:s.index("parent=engine.in_check")]
s=s.replace("D=Path('.local_agent/fallback-integration-20261013')","D=Path('.local_agent/s3-closure-20261013/error-fixture')")
(D/'error-fixture').mkdir(exist_ok=True)
exec(compile(s,'retained-rule-counter','exec'),ns)
rules=ns['c'];pos=ns['position']
rules=replace(rules,ir=replace(rules.ir,patterns=tuple(replace(p,guards=()) for p in rules.ir.patterns)))
original=engine().legal_actions(pos);assert original==()
try:
 with c.installed():engine().legal_actions(pos)
except RuntimeError as exc:failure=str(exc)
else:raise AssertionError('expected extra parent-only failure')
write_record(D/'parent-error.json',dict(original_frontier=[],candidate_error=failure,scope='Injected missing frontier and required binding failure; valid rule counter with guard removed, not actual public search failure',decision='Private v1 cannot be production adopted on this error contract. Test optional parent observation decline, preserve checkpoint errors and actual child errors. Running v1 resource remains normal supported-input diagnostic, not patched live.'))
print(failure)
