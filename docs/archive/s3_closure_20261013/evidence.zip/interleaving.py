from pathlib import Path
import sys,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core.semantic_executor import SemanticEngine
import candidate_safe as cand
D=Path('.local_agent/s3-closure-20261013')
g=p.generate_game(p.GeneratorConfig(seed=2026101961,board_size=18,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);rng=random.Random(2026101961+16000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
pos=s.state.position;s.submit(sorted(s.legal_actions(),key=repr)[0]);other=s.state.position
e=SemanticEngine(c);assert cand.eligible(e)
with cand.installed():
 a=e.iter_legal_action_bindings(pos);b=e.iter_legal_action_bindings(other)
 next(a);next(b);a.close();b.close()
 assert e._private_s3_context is not None and e._private_s3_context[0] is pos
 leaked=True;e._private_s3_context=None
write_record(D/'interleaving-error.json',dict(complete=True,seed=2026101961,size=18,first_prefix=8,second_prefix=9,original_iterators='No introduced S3 context field',private_safe_error='Out-of-order close of two partial iterators leaves parent context on compiled engine',leaked_parent_reference=leaked,semantics_wrong_output_observed=False,decision='Do not production-install generator-suspended engine context. Scope it around each actual next()/close() operation; test partial/exhaust/cancel before revised prospective transfer. Safe-resource predeclaration version not executed yet, preserve it as superseded source declaration.'))
print('observed private engine parent retention after out-of-order close')
