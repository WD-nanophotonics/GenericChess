from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from rule_semantics_ir_fixtures import _king_type,_ray_type,_semantic_ruleset,_ref,_own_anchor
from generic_chess.rules.schema import RuleSemanticAction,RuleGeometrySpec,RuleReplaceSelector,RuleTypeRef,RuleActionEffect
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
import candidate_safe as cand
D=Path('.local_agent/s3-closure-20261013')
move=RuleSemanticAction(name='quiet_move_retypes_remote_enemy',type_ids=('B',),geometry=RuleGeometrySpec(kind='leap',offset=(-1,0)),target_relation='empty',composition='replace_legacy',replace_selector=RuleReplaceSelector(type_ids=('B',),action_family='board',target_relation='empty',geometry_kind='leap',replace_all_matching=True),effects=(RuleActionEffect('move',from_ref=_ref('source'),to_ref=_ref('target')),RuleActionEffect('set_current_type',square_ref=_ref('fixed',square=(0,2),owner_relative=False),type_ref=RuleTypeRef('explicit','R'))),invariants=_own_anchor())
rows=[[None]*4 for _ in range(4)];rows[0][0]=Piece(0,'K','K');rows[3][3]=Piece(1,'K','K');rows[2][0]=Piece(1,'A','A');rows[2][3]=Piece(0,'B','B')
rules=_semantic_ruleset((_king_type(),_ray_type('A',(LeapAtom((1,0)),)),_ray_type('R',(RayAtom((0,-1)),RayAtom((0,1)))),_ray_type('B',(LeapAtom((-1,0)),))), (move,),n=4,rows=tuple(tuple(x) for x in rows))
c=compile_ruleset_for_execution(rules);s=GameSession(c);e=SemanticEngine(c);pos=s.state.position
assert cand.eligible(e);e._private_capture_eligible=True;context=cand.prepare(e,pos,None);assert context is not None and not context[4]
witness=[]
for p in e._patterns:
 for a,b in e._iter_candidates(p,pos):
  if b.source!=11 or b.target!=10 or p.name!='quiet_move_retypes_remote_enemy':continue
  child=e._transition(pos,a,b);changed=[i for i,(x,y) in enumerate(zip(pos.board,child.board)) if x!=y]
  assert all(i not in context[3] for i in changed)
  assert e.in_check(child,0) and e._trial_child_if_s3_legal(p,pos,a,b) is None
  with cand.installed() as stats:
   e._private_capture_eligible=True;e._private_s3_context=context
   assert e._trial_child_if_s3_legal(p,pos,a,b) is None
   assert stats.get('skipped',0)==0
   e._private_s3_context=None
  witness.append(dict(action=record_value(a),changed=changed,old_geometry_influence=sorted(context[3]),old_enemy_type='A',new_enemy_type='R',parent_check=False,child_check=True,original_S3_rejects=True,writeclosure_falls_back=True))
assert witness
write_record(D/'enemy-retype-counter.json',dict(complete=True,ruleset=record_value(rules),witnesses=witness,scope='Valid complete DSL enemy-retype effect outside old enemy path influence; exact transition retained; new/enemy changed actor forces original S3 query. No action-size assumption or game-specific rule restriction.'))
print(witness)
