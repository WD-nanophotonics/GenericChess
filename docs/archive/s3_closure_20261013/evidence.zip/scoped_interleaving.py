from pathlib import Path
import sys,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core.semantic_executor import SemanticEngine
import candidate_scoped as cand
D=Path('.local_agent/s3-closure-20261013')
g=p.generate_game(p.GeneratorConfig(seed=2026101961,board_size=18,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);rng=random.Random(2026101961+16000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
pos=s.state.position;s.submit(sorted(s.legal_actions(),key=repr)[0]);other=s.state.position
e=SemanticEngine(c);assert cand.eligible(e)
baseline_a=tuple(e.iter_legal_action_bindings(pos));baseline_b=tuple(e.iter_legal_action_bindings(other))
with cand.installed():
 a=e.iter_legal_action_bindings(pos);b=e.iter_legal_action_bindings(other)
 ax=next(a);assert e._private_s3_context is None
 bx=next(b);assert e._private_s3_context is None
 assert ax==baseline_a[0] and bx==baseline_b[0]
 a.close();b.close()
 assert e._private_s3_context is None and not cand.ACTIVE
 assert tuple(e.iter_legal_action_bindings(pos))==baseline_a
 assert tuple(e.iter_legal_action_bindings(other))==baseline_b
write_record(D/'interleaving-repair.json',dict(complete=True,seed=2026101961,size=18,first_prefix=8,second_prefix=9,partial_yield_context_released=True,out_of_order_close_released=True,retry_full_frontiers_equal=True,production_installed=False))
print('scoped yield/close/retry parent lifecycle qualified')
