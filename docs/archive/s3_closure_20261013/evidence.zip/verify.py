from pathlib import Path
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.research_record import write_record
D=Path('.local_agent/s3-closure-20261013')
TIME={'elapsed_seconds','time_to_first_legal_action','time_to_first_completed_iteration','ordering_seconds','legal_generation_seconds','evaluation_seconds'}
RETAINED=['action','score','principal_variation','completed_depth','choice_kind','declaration','result_source','result_ordinary_qdepth','result_check_hard_qdepth']
summary={}
for folder,expected,kind in [('resource',64,'resource'),('scoped-fixed',16,'fixed'),('scoped-resource',32,'resource'),('scoped-profile',4,'fixed'),('scoped-escape',8,'resource'),('full-caller',4,'fixed')]:
 path=D/folder/'rows.json'
 if not path.exists():continue
 obj=json.loads(path.read_text(encoding='utf-8'))
 if not obj.get('complete'):continue
 rows=obj['rows'];keys={}
 for row in rows:
  key=tuple(row.get(x) for x in ['seed','size','q','seconds','rep'])
  group=keys.setdefault(key,{})
  assert row['arm'] not in group
  group[row['arm']]=row
 pairs=[]
 for key,g in keys.items():
  assert set(g)=={'original','candidate'}
  old,new=g['original'],g['candidate'];a,b=old['decision'],new['decision']
  dif=[k for k in a if k not in TIME and a[k]!=b[k]]
  retained=[k for k in RETAINED if a[k]!=b[k]]
  oldwall=old.get('wall',old.get('profile_wall'));newwall=new.get('wall',new.get('profile_wall'))
  pairs.append(dict(key=key,old_depth=a['completed_depth'],new_depth=b['completed_depth'],old_termination=a['termination_reason'],new_termination=b['termination_reason'],retained_differences=retained,all_non_time_work_equal=not dif,non_time_differences=dif,old_wall=oldwall,new_wall=newwall,matched_work_saving=(oldwall-newwall)/oldwall if not dif else None))
 assert all(row['history_restored'] for row in rows)
 assert all(row.get('pv_core_legal',True) for row in rows)
 assert len(rows)+sum(x.get('unexecuted_cells',0) for x in obj.get('unavailable',[]))==expected
 if kind=='fixed':assert all(x['all_non_time_work_equal'] for x in pairs)
 item=dict(complete=True,actual_calls=len(rows),planned=expected,unavailable=obj.get('unavailable',[]),pairs=pairs,deeper=sum(x['new_depth']>x['old_depth'] for x in pairs),same=sum(x['new_depth']==x['old_depth'] for x in pairs),shallower=sum(x['new_depth']<x['old_depth'] for x in pairs),same_depth_tuple_mismatches=[x for x in pairs if x['new_depth']==x['old_depth'] and x['retained_differences']],history_restored=True,pvs_checked=folder!='scoped-profile',elapsed_seconds=obj['elapsed_seconds'])
 write_record(D/folder/'verification.json',item);summary[folder]=dict(actual_calls=len(rows),pairs=len(pairs),deeper=item['deeper'],same=item['same'],shallower=item['shallower'],same_depth_tuple_mismatch_count=len(item['same_depth_tuple_mismatches']),fixed_all_non_time_work_equal=all(x['all_non_time_work_equal'] for x in pairs))
write_record(D/'verification.json',dict(closed_planes=summary,actual_closed_calls=sum(x['actual_calls'] for x in summary.values()),scope='Only complete rows/planes; pending omitted, not assumed complete',time_fields_excluded=sorted(TIME),retained_fields=RETAINED))
print(json.dumps(summary))
