from pathlib import Path
import sys,random,time,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
import candidate_writes as candidate
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.core import semantic_executor as se
D=Path('.local_agent/s3-closure-20261013')
write_record(D/'writes-audit-declaration.json',dict(seeds=[2026101961,2026101962,2026101963,2026101964],sizes=[18,20,18,20],prefix=8,states=4,question='Does full-child board closure with no capture guard retain ordered full S0-S4/frontier and exact children, and reduce frontier cost?',scope='Private experiment; whole-board scan, no production cache or compiler field; all capture state/slot/zone guards decline; full transition/S4/history retained',repeats=4,search_calls=0,fuse_seconds=600,decision='Only if ordered parity and lower measured whole-frontier cost run paired fixed/public searches; otherwise reject this implementation and retain alternate primitive question.'))
rows=[];start=time.perf_counter()
for seed,size in zip([2026101961,2026101962,2026101963,2026101964],[18,20,18,20]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);rng=random.Random(seed+16000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 for state_no in range(4):
  pos=s.state.position;engine=se.SemanticEngine(c)
  original=tuple(engine.iter_legal_action_bindings(pos))
  child_original=[engine._trial_child_if_s3_legal(b.pattern,pos,a,b) for a,b in original]
  with candidate.installed() as stats:
   other=tuple(engine.iter_legal_action_bindings(pos));counts=dict(stats)
   assert other==original
   child_candidate=[engine._trial_child_if_s3_legal(b.pattern,pos,a,b) for a,b in other]
   assert child_candidate==child_original
   assert engine._private_s3_context is None and engine._private_s3_trial is None
  timings=[]
  for rep in range(4):
   for arm in (['original','candidate'] if rep%2==0 else ['candidate','original']):
    t=time.perf_counter()
    if arm=='candidate':
     with candidate.installed():act=engine.legal_actions(pos)
    else:act=engine.legal_actions(pos)
    timings.append(dict(rep=rep,arm=arm,seconds=time.perf_counter()-t))
    assert act==tuple(a for a,b in original)
  rows.append(dict(seed=seed,size=size,state_no=state_no,actions=len(original),stats=counts,timings=timings,ordered_full_S4_equal=True,full_child_equal=True))
  write_record(D/'writes-audit-rows.json',dict(complete=False,rows=rows));print(seed,state_no,len(original),counts,timings,flush=True)
  if not original:break
  s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 assert time.perf_counter()-start<600
write_record(D/'writes-audit-rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
