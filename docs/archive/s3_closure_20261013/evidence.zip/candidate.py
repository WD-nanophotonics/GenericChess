"""Private scoped S3 experiment. No production installation or persistent position cache."""
from contextlib import contextmanager
from generic_chess.core import semantic_executor as se
from generic_chess.rules.ir import geometry_paths_to
OLD_ITER=se.SemanticEngine.iter_legal_action_bindings
OLD_TRIAL=se.SemanticEngine._trial_child_if_s3_legal
OLD_CHECK=se.SemanticEngine.in_check
OLD_TRANS=se.SemanticEngine._transition
STATS={}
def eligible(engine):
    allowed={'path_clear','path_count_eq','path_count_range','path_first_blocker_owner','path_last_blocker_owner'}
    return all(not(p.guards or p.slot_guards or p.square_zone_guards) and all(q.kind in allowed for q in p.path)
               for p in engine._patterns if p.target.kind=='target_enemy')
def prepare(engine,pos,checkpoint):
    if not eligible(engine): return None
    side=pos.side_to_move;anchor=se._own_anchor(pos,engine.support,side)
    if anchor is None:return None
    influence={anchor};sources=se._sources_by_owner_type(pos)
    for p in engine._patterns:
        se._checkpoint(checkpoint)
        if p.target.kind!='target_enemy':continue
        for tid in p.type_ids:
            for source,piece in sources.get((1-side,tid),()):
                for gid in p.geometry_ids:
                    se._checkpoint(checkpoint)
                    g=engine.ir.geometry.get(gid)
                    if g is None or g.kind=='drop' or g.atom_source is not None and g.atom_source[0]!=tid:continue
                    for path in geometry_paths_to(g,str(1-side),source,anchor):
                        influence.add(source);influence.update(path)
    return pos,side,anchor,influence,OLD_CHECK(engine,pos,side,checkpoint=checkpoint)
def iter_bindings(self,pos,checkpoint=None,*,source=None,target=None):
    previous=getattr(self,'_private_s3_context',None)
    self._private_s3_context=prepare(self,pos,checkpoint)
    STATS['frontiers']=STATS.get('frontiers',0)+1
    try:yield from OLD_ITER(self,pos,checkpoint=checkpoint,source=source,target=target)
    finally:self._private_s3_context=previous
def trial(self,pattern,pos,action,binding,checkpoint=None):
    previous=getattr(self,'_private_s3_trial',None)
    self._private_s3_trial=[pos,None]
    try:return OLD_TRIAL(self,pattern,pos,action,binding,checkpoint=checkpoint)
    finally:self._private_s3_trial=previous
def transition(self,pos,action,binding,checkpoint=None):
    child=OLD_TRANS(self,pos,action,binding,checkpoint=checkpoint)
    t=getattr(self,'_private_s3_trial',None)
    if t is not None and t[0] is pos:t[1]=child
    return child
def check(self,pos,side,checkpoint=None):
    ctx=getattr(self,'_private_s3_context',None);t=getattr(self,'_private_s3_trial',None)
    if ctx is None or t is None or ctx[0] is not t[0] or pos is not t[1] or side!=ctx[1]:
        return OLD_CHECK(self,pos,side,checkpoint=checkpoint)
    se._checkpoint(checkpoint)
    parent,_,anchor,influence,checked=ctx
    # Full child already exists. Every actual board change is observed, including compound/promotion effects.
    safe=True
    for i,(old,new) in enumerate(zip(parent.board,pos.board)):
        if old==new:continue
        if i in influence or new is not None and (new.owner!=side or self.support.type_metadata[new.current_type_id].is_anchor):
            safe=False;break
        if old is not None and old.owner==side and self.support.type_metadata[old.current_type_id].is_anchor:
            safe=False;break
    if not safe:return OLD_CHECK(self,pos,side,checkpoint=checkpoint)
    STATS['skipped']=STATS.get('skipped',0)+1
    return checked
@contextmanager
def installed():
    STATS.clear()
    se.SemanticEngine.iter_legal_action_bindings=iter_bindings
    se.SemanticEngine._trial_child_if_s3_legal=trial
    se.SemanticEngine._transition=transition
    se.SemanticEngine.in_check=check
    try:yield STATS
    finally:
        se.SemanticEngine.iter_legal_action_bindings=OLD_ITER
        se.SemanticEngine._trial_child_if_s3_legal=OLD_TRIAL
        se.SemanticEngine._transition=OLD_TRANS
        se.SemanticEngine.in_check=OLD_CHECK
