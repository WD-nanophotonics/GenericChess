from pathlib import Path
import sys,time,inspect,textwrap,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta import ordering
from scripts.search_backend_comparison import CASES,CoreBoard,supported_search
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011';old=ordering.MoveOrderer.order;cache={};counts={}
def key(action):
 v=cache.get(action)
 if v is not None:counts['hits']+=1;return v
 counts['misses']+=1;v=str(action)
 if len(cache)>=2048:cache.clear();counts['clears']+=1
 cache[action]=v;counts['peak']=max(counts['peak'],len(cache));return v
source=textwrap.dedent(inspect.getsource(old));assert source.count('str(a)')==1;source=source.replace('str(a)','key(a)');ns=dict(ordering.__dict__,key=key);exec(compile(source,'<ordering-key-prototype>','exec'),ns)
r=dict(complete=False,plan=(B/'order-key-plan.md').read_text(),candidate_source=source,rows=[])
try:
 for name in ('chess-middle','shogi-drop'):
  case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));p=NativeSemanticLegalityProvider.try_create(c,strict=True);assert p
  for mode in ('core','native_legality'):
   for arm in ('off','on','on','off'):
    stopped();cache.clear();counts.update(hits=0,misses=0,clears=0,peak=0);p._metrics_local.public_cache={};ordering.MoveOrderer.order=ns['order'] if arm=='on' else old;b=CoreBoard(case,c);v=supported_search(b,2,30,100000,provider=p if mode=='native_legality' else None);assert b.restored();r['rows'].append(dict(root=name,mode=mode,arm=arm,cache=dict(counts),gross_final_dict_and_string_bytes=sys.getsizeof(cache)+sum(sys.getsizeof(x) for x in cache.values()),**v));write_record(B/'order-key.json',r);print(name,mode,arm,round(v['wall_seconds'],5),dict(counts),flush=True)
finally:ordering.MoveOrderer.order=old
r['complete']=True;r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(B/'order-key.json',r)
