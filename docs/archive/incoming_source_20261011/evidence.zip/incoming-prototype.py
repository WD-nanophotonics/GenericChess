from pathlib import Path
import sys,time,inspect,hashlib,textwrap
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
original=se.SemanticEngine.is_square_attacked
plans={}
source=inspect.getsource(original)
start=source.index('        incoming = ');end=source.index('        sources_by_owner_type = ',start)
new='''        incoming = self.semantic._incoming_attack_paths
        if incoming is not None:
            _checkpoint(checkpoint)
            selected = []
            groups = plans[id(self.semantic)].get((str(by_owner), square), {})
            for source, piece in enumerate(position.board):
                _checkpoint(checkpoint)
                if piece is not None and piece.owner == by_owner:
                    selected.extend(groups.get((source, piece.current_type_id), ()))
            selected.sort(key=lambda entry: entry[0])
            for rank, row in selected:
                _checkpoint(checkpoint)
                pattern, tid, source, gid, path = row
                piece = position.board[source]
                binding = self._make_binding(pattern, gid, tid, piece, source, square, None, path, position)
                if self._path_holds(pattern.path, position, binding, by_owner, checkpoint=checkpoint) and self._guards_hold(pattern, position, binding, by_owner, checkpoint=checkpoint):
                    return True
            return False
'''
source=source[:start]+new+source[end:]
ns=dict(se.__dict__,plans=plans);exec(textwrap.dedent(source),ns);candidate=ns['is_square_attacked']
def build(c):
 plan={}
 for key,rows in c._incoming_attack_paths.items():
  groups={}
  for rank,row in enumerate(rows):groups.setdefault((row[2],row[1]),[]).append((rank,row))
  plan[key]={k:tuple(v) for k,v in groups.items()}
 plans[id(c)]=plan
 return plan
def main():
 r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_source=source,rows=[],construction=[])
 try:
  for case in CASES:
   stopped();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
   tick=time.perf_counter();plan=build(c)
   r['construction'].append(dict(case=case['id'],seconds=time.perf_counter()-tick,groups=sum(len(v) for v in plan.values()),rows=sum(len(v) for g in plan.values() for v in g.values())))
   for arm in ('old','actor','actor','old'):
    se.SemanticEngine.is_square_attacked=original if arm=='old' else candidate
    d=minimal_ab(CoreBoard(case,c),2,seconds=30,node_limit=100000,cooperative=True)
    r['rows'].append(dict(case=case['id'],arm=arm,**d));write_record(B/'incoming-prototype.json',r);print(case['id'],arm,d['wall_seconds'],flush=True)
  r['complete']=True;write_record(B/'incoming-prototype.json',r)
 finally:se.SemanticEngine.is_square_attacked=original
if __name__=='__main__':main()
