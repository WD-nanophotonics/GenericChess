from pathlib import Path
import sys,time,json,hashlib,importlib.util
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import semantic_executor as se
from rule_semantics_ir_fixtures import cannon_ruleset,castling_ruleset,en_passant_ruleset,nifu_ruleset,uchifuzume_ruleset,weird_rulesets
from scripts.search_backend_comparison import CoreBoard,CASES
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
spec=importlib.util.spec_from_file_location('prototype',B/'incoming-source.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[]);roots=[]
for case in CASES:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);roots.append((case['id'],c,b.initial.position))
for i,rule in enumerate((cannon_ruleset(),castling_ruleset(),en_passant_ruleset(),nifu_ruleset(),uchifuzume_ruleset(),*weird_rulesets())):
 c=compile_ruleset_for_execution(rule);roots.append((f'mechanism-{i}',c,se.SemanticEngine(c)._initial_position()))
start=time.perf_counter()
for name,c,parent in roots:
 stopped();assert time.perf_counter()-start<300;p.build(c);e=se.SemanticEngine(c);actions=e.legal_actions(parent);positions=[parent]+[e.apply(parent,a) for a in actions]
 counts={'queries':0,'true':0,'baseline_polls':0,'actor_polls':0,'baseline_rows_upper':0,'actor_selected_rows_upper':0,'cancelled':0};distribution={}
 for position in positions:
  for owner in (0,1):
   for square in range(len(position.board)):
    key=(str(owner),square);rows=c._incoming_attack_paths[key];active=sum(1 for row in rows if position.board[row[2]] is not None and position.board[row[2]].owner==owner and position.board[row[2]].current_type_id==row[1]);distribution[len(rows)]=distribution.get(len(rows),0)+1
    polls=[0,0]
    def a():polls[0]+=1
    def b():polls[1]+=1
    old=p.original(e,position,square,owner,checkpoint=a);new=p.candidate(e,position,square,owner,checkpoint=b);assert old==new
    counts['queries']+=1;counts['true']+=old;counts['baseline_polls']+=polls[0];counts['actor_polls']+=polls[1];counts['baseline_rows_upper']+=len(rows);counts['actor_selected_rows_upper']+=active
    def cancel():raise InterruptedError('incoming audit')
    for method in (p.original,p.candidate):
     try:method(e,position,square,owner,checkpoint=cancel)
     except InterruptedError:counts['cancelled']+=1
     else:raise AssertionError('entry poll missing')
 r['rows'].append(dict(root=name,positions=len(positions),counts=counts,row_cardinality_distribution=distribution));write_record(B/'incoming-source-audit.json',r);print(name,counts,flush=True)
r.update(complete=True,wall=time.perf_counter()-start);write_record(B/'incoming-source-audit.json',r)
