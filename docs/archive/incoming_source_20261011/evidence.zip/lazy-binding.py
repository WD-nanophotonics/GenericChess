from pathlib import Path
import sys,time,inspect,textwrap,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta import native_legality as nl
from scripts.search_backend_comparison import CASES,CoreBoard,supported_search
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
counts={'made':0,'forced':0}
class LazyPair:
 def __init__(self,provider,position,action,pattern,checkpoint):self.provider=provider;self.position=position;self.action=action;self.pattern=pattern;self.checkpoint=checkpoint;self.value=None;counts['made']+=1
 def __iter__(self):
  if self.value is None:
   if self.checkpoint:self.checkpoint()
   self.value=(self.action,self.provider.engine._make_binding_from_action(self.position,self.action,self.pattern));counts['forced']+=1
   if self.checkpoint:self.checkpoint()
  return iter(self.value)
source=textwrap.dedent(inspect.getsource(nl.NativeSemanticLegalityProvider.__call__))
anchor="""        binding = self.engine._make_binding_from_action(
            position, semantic_action, pattern
        )"""
assert source.count(anchor)==1
source=source.replace(anchor,'        lazy = LazyPair(self,position,semantic_action,pattern,checkpoint)').replace('pairs.append((public, (semantic_action, binding)))','pairs.append((public, lazy))')
ns=dict(nl.__dict__,LazyPair=LazyPair);exec(compile(source,'<lazy-native-binding-prototype>','exec'),ns)
class LazyProvider(nl.NativeSemanticLegalityProvider):__call__=ns['__call__']
r=dict(complete=False,declaration=(B/'lazy-binding-plan.md').read_text(),candidate_source=source,rows=[])
for name in ('chess-middle','shogi-drop'):
 case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
 for arm in ('eager','lazy','lazy','eager'):
  stopped();p=(LazyProvider if arm=='lazy' else nl.NativeSemanticLegalityProvider).try_create(c,strict=True);assert p is not None;p._metrics_local.public_cache={};counts.update(made=0,forced=0);b=CoreBoard(case,c);v=supported_search(b,2,30,100000,provider=p);assert b.restored();r['rows'].append(dict(root=name,arm=arm,lazy_counts=dict(counts),**v));write_record(B/'lazy-binding.json',r);print(name,arm,v['wall_seconds'],dict(counts),flush=True)
r['complete']=True;r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(B/'lazy-binding.json',r)
