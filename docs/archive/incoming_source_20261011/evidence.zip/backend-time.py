from pathlib import Path
import sys,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.search_backend_comparison import CASES,CoreBoard,supported_search
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
r=dict(complete=False,declaration='Two old roots, existing1second budget; supported q0 depth6 coldTT/order, same Core history/material/tie policy; Core/Native reversed pairs, native syntax cache fresh. Compile outside timing. No tuning on outcomes.',rows=[])
for name in ('chess-middle','shogi-drop'):
 case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));p=NativeSemanticLegalityProvider.try_create(c,strict=True)
 assert p is not None
 for mode in ('core','native_legality','native_legality','core'):
  stopped();p._metrics_local.public_cache={};b=CoreBoard(case,c);v=supported_search(b,6,1,100000,provider=p if mode=='native_legality' else None);assert b.restored();r['rows'].append(dict(root=name,mode=mode,**v));write_record(B/'backend-time.json',r);print(name,mode,v['move'],v['statistics']['completed_depth'],flush=True)
r['complete']=True;r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(B/'backend-time.json',r)
