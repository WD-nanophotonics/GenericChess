from pathlib import Path
import sys,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/skippable-contract-20261011'
source=(B/'lazy-binding.py').read_text();ns={};exec(compile(source[:source.index("r=dict(complete=False")],'<lazy-definitions>','exec'),ns)
LazyProvider=ns['LazyProvider'];nl=ns['nl'];CoreBoard=ns['CoreBoard'];CASES=ns['CASES'];build=ns['build_builtin_ruleset'];compile_rules=ns['compile_ruleset_for_execution'];write=ns['write_record']
def own(obj):return sys.getsizeof(obj)+(sys.getsizeof(obj.__dict__) if hasattr(obj,'__dict__') else 0)
r=dict(complete=False,scope='Gross tuple/object/dict containers only, borrowed public syntax/pattern/action/position/engine/path/integers excluded. Not RSS. LazyPair retains full immutable parent plus provider/checkpoint references; lifetime must be explicit in a future interface.',rows=[])
for name in ('chess-middle','shogi-drop'):
 case=next(c for c in CASES if c['id']==name);c=compile_rules(build('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);p=nl.NativeSemanticLegalityProvider.try_create(c,strict=True);q=LazyProvider.try_create(c,strict=True);eager=p(b.initial.position,b.initial.ply_count);lazy=q(b.initial.position,b.initial.ply_count)
 def measure(pairs,lazy):
  total=sys.getsizeof(pairs)
  for public,binding in pairs:
   total+=sys.getsizeof((public,binding))+own(binding)
   if lazy and binding.value is not None:total+=sys.getsizeof(binding.value)+own(binding.value[1])
   elif not lazy:total+=own(binding[1])
  return total
 before=measure(lazy,True);e=measure(eager,False)
 for public,pair in lazy:tuple(pair)
 after=measure(lazy,True);r['rows'].append(dict(root=name,actions=len(eager),eager_gross=e,lazy_unforced_gross=before,lazy_all_forced_gross=after))
r['complete']=True;r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write(B/'lazy-binding-memory.json',r);print(r)
