from pathlib import Path
import sys,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.search_backend_comparison import CASES,CoreBoard,ChessBoard,ShogiBoard,minimal_ab,audit_pair,supported_search
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='8old roots: refreshed exact lexical minimal D2 Core source-group ON / Core Native legality / specialized; same material and lexical order,30sec100k. Native syntax cache cleared before each timed run; compile/audit outside limits. Full depth1 state/frontier/material/terminal audit; actual provider metrics. Supported algorithm separate (coldTT/order/q0 D2), never equate its node definition with minimal. No blocked DLL changes or Native full search claim.',rows=[],audits=[])
for case in CASES:
 stopped();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
 if provider is None:raise RuntimeError('Native provider unavailable; do not relabel fallback')
 specialized=lambda:ChessBoard(case) if case['game']=='chess' else ShogiBoard(case)
 audit=audit_pair(CoreBoard(case,c,provider=provider),specialized(),1);r['audits'].append(dict(case=case['id'],states=audit,provider_compile_seconds=provider.compile_seconds))
 modes=('core','native_legality','specialized','supported_core','supported_native_legality')
 for mode in modes+tuple(reversed(modes)):
  stopped();provider._metrics_local.public_cache={};board=specialized() if mode=='specialized' else CoreBoard(case,c,provider=provider if mode=='native_legality' else None)
  if mode.startswith('supported'):d=supported_search(board,2,30,100000,provider=provider if mode=='supported_native_legality' else None)
  else:d=minimal_ab(board,2,seconds=30,node_limit=100000,cooperative=True)
  assert board.restored();r['rows'].append(dict(case=case['id'],backend=mode,**d));write_record(B/'backend-refresh.json',r);print(case['id'],mode,d['wall_seconds'],flush=True)
r['complete']=True;write_record(B/'backend-refresh.json',r)
