from pathlib import Path
import sys,time,inspect,hashlib,textwrap
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
original=se.SemanticEngine._guard_holds
source=(B/'guard-shortcircuit-candidate.py').read_text()
ns=dict(se.__dict__);exec(source,ns);candidate=ns['_guard_holds']
def main():
 r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_source=source,rows=[],construction=[])
 try:
  for case in CASES:
   stopped();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
   for arm in ('old','actor','actor','old'):
    se.SemanticEngine._guard_holds=original if arm=='old' else candidate
    d=minimal_ab(CoreBoard(case,c),2,seconds=30,node_limit=100000,cooperative=True)
    r['rows'].append(dict(case=case['id'],arm=arm,**d));write_record(B/'guard-shortcircuit-fixed.json',r);print(case['id'],arm,d['wall_seconds'],flush=True)
  r['complete']=True;write_record(B/'guard-shortcircuit-fixed.json',r)
 finally:se.SemanticEngine._guard_holds=original
if __name__=='__main__':main()
