from pathlib import Path
import sys,cProfile,pstats,json,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,ChessBoard,ShogiBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record,record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
B=ROOT/'.local_agent/skippable-contract-20261011';r={'complete':False,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[]};start=time.perf_counter()
for name in ('chess-middle','shogi-middle','shogi-drop'):
 case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses
 for mode in ('minimal-core','minimal-specialized','supported-core'):
  stopped();assert time.perf_counter()-start<120
  if mode=='minimal-specialized':board=ChessBoard(case) if case['game']=='chess' else ShogiBoard(case)
  else:board=b
  def run():
   if mode=='supported-core':return record_value(AlphaBetaPlayer(c,evaluator_override=b.material,use_native_semantic_legality=False,use_tt=False).choose_action(s,SearchLimits(max_depth=2,max_time_seconds=30,max_nodes=100000,quiescence_max_depth=0,quiescence_hard_max_depth=0)))
   return minimal_ab(board,2,seconds=30,node_limit=100000)
  before=run();prof=cProfile.Profile();prof.enable();value=run();prof.disable();after=run();stats=pstats.Stats(prof)
  calls=[]
  for (file,line,fn),(cc,nc,tt,ct,callers) in stats.stats.items():calls.append({'file':file.replace(str(ROOT),'<ROOT>'),'line':line,'function':fn,'primitive_calls':cc,'total_calls':nc,'exclusive':tt,'inclusive':ct})
  r['rows'].append({'root':name,'mode':mode,'unprofiled_before':before,'profiled_result':value,'unprofiled_after':after,'profiled_total':stats.total_tt,'top_exclusive':sorted(calls,key=lambda x:x['exclusive'],reverse=True)[:35],'top_inclusive':sorted(calls,key=lambda x:x['inclusive'],reverse=True)[:35]});write_record(B/'cost-profile.json',r);print(name,mode,stats.total_tt,flush=True)
r.update(complete=True,wall=time.perf_counter()-start);write_record(B/'cost-profile.json',r)
