from pathlib import Path
import sys,time,json,hashlib
from dataclasses import replace
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.rules import ir
B=Path('.local_agent/skippable-contract-20261011')
from scripts.research_record import write_record
r=json.loads((B/'incoming-installed.json').read_text());wall=json.loads((B/'incoming-supported-wall.json').read_text());out=[]
for case in dict.fromkeys(x['case'] for x in r['rows']):
 for mode in ('minimal','supported'):
  rows=[x for x in r['rows'] if x['case']==case and x['mode']==mode];d=[x['result'] for x in rows]
  sig=[(x['move'],x['score'],x['completed_depth'],x['work']) if mode=='minimal' else (x['action'],x['score'],x['completed_depth'],x['nodes'],x['qnodes'],x['beta_cutoffs'],x['successors_searched']) for x in d];assert all(x==sig[0] for x in sig)
  if mode=='supported':
   rows=[x for x in wall['rows'] if x['case']==case];assert all((x['result']['action'],x['result']['score'],x['result']['completed_depth'],x['result']['nodes'],x['result']['qnodes'],x['result']['beta_cutoffs'],x['result']['successors_searched'])==sig[0] for x in rows)
  def elapsed(x):return x['result']['wall_seconds'] if mode=='minimal' else x['external_wall']
  old=sum(elapsed(x) for x in rows if x['arm']=='off')/2;new=sum(elapsed(x) for x in rows if x['arm']=='on')/2;out.append(dict(case=case,mode=mode,off=old,on=new,fraction=new/old-1))
write_record(B/'incoming-installed-summary.json',dict(rows=out,complete=True,comparison='fixed action/score/depth/work exact; minimal internal perf wall; supported external wall includes board/session/player prep; coarse elapsed evidence retained',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
r=json.loads((B/'incoming-time.json').read_text());out=[]
for case in ('chess-middle','shogi-drop'):
 for q,budgets in ((0,(.05,.1,.25,1)),(4,(.1,1))):
  for seconds in budgets:
   rows=[x for x in r['rows'] if x['case']==case and x['q']==q and x['seconds']==seconds]
   out.append(dict(case=case,q=q,seconds=seconds,off=[(x['result']['completed_depth'],x['result']['nodes'],x['result']['qnodes']) for x in rows if x['arm']=='off'],on=[(x['result']['completed_depth'],x['result']['nodes'],x['result']['qnodes']) for x in rows if x['arm']=='on'],action_equal=len({str(x['result']['action']) for x in rows})==1))
write_record(B/'incoming-time-summary.json',dict(rows=out,decision='No robust extra completed layer in48calls; one Shogi q4 .1sec noisy D1 on-only outlier. Local fixed-work saving retained without player-strength claim.'))
source_helper=ir._incoming_attack_sources;out=[]
try:
 for game in ('western_chess','standard_shogi'):
  c=compile_ruleset_for_execution(build_builtin_ruleset(game));g=c._incoming_attack_sources;owned=sys.getsizeof(g);entries=0;sources=0;types=0
  for key,group in g.items():
   owned+=sys.getsizeof(group);sources+=len(group)
   for source,typed in group.items():
    owned+=sys.getsizeof(typed);types+=len(typed)
    for tid,ranked in typed.items():
     owned+=sys.getsizeof(ranked)
     for entry in ranked:owned+=sys.getsizeof(entry)+sys.getsizeof(entry[0]);entries+=1
  times=[]
  for arm in ('off','on','on','off','off','on'):
   ir._incoming_attack_sources=source_helper if arm=='on' else lambda incoming:None;tick=time.perf_counter();other=replace(c);elapsed=time.perf_counter()-tick;assert other.ir.serialized()==c.ir.serialized();times.append(dict(arm=arm,seconds=elapsed))
  ir._incoming_attack_sources=source_helper
  out.append(dict(game=game,owned_containers_and_rank_int_bytes=owned,entries=entries,sources=sources,types=types,construction=times,excludes='borrowed IR rows/patterns/type/source/key objects; rank int size is gross sum, possibly shared small ints; not resident-memory delta'))
finally:ir._incoming_attack_sources=source_helper
write_record(B/'incoming-construction.json',dict(rows=out,scope='compile-owned extra metadata shared by engines; existing65536-row fuse controls source partition; bounded source groups retain fallback'))
print(json.loads((B/'incoming-installed-summary.json').read_text()))
print(out)
