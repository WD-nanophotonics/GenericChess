from pathlib import Path
import sys,time,cProfile,pstats,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/skippable-contract-20261011'
source=(B/'lazy-binding.py').read_text();ns={};exec(compile(source[:source.index("r=dict(complete=False")],'<lazy-definitions>','exec'),ns)
LazyProvider=ns['LazyProvider'];nl=ns['nl'];CoreBoard=ns['CoreBoard'];CASES=ns['CASES'];build=ns['build_builtin_ruleset'];compile_rules=ns['compile_ruleset_for_execution'];write=ns['write_record'];search=ns['supported_search']
r=dict(complete=False,scope='Explanatory eager/lazy bridge body attribution; four q0D2 profiles, same tree material history order TT; direct exclusive categories partition only, no sum of inclusive costs or untraced speed claim.',rows=[])
for name in ('chess-middle','shogi-drop'):
 case=next(c for c in CASES if c['id']==name);c=compile_rules(build('western_chess' if case['game']=='chess' else 'standard_shogi'))
 for mode in ('eager','lazy'):
  p=(LazyProvider if mode=='lazy' else nl.NativeSemanticLegalityProvider).try_create(c,strict=True);assert p;b=CoreBoard(case,c);p._metrics_local.public_cache={};profile=cProfile.Profile();profile.enable();v=search(b,2,30,100000,provider=p);profile.disable();assert b.restored();stats=pstats.Stats(profile);calls=[];groups={}
  for (file,line,fn),(cc,nc,tt,ct,callers) in stats.stats.items():
   f=file.replace(str(ROOT),'<ROOT>');group='other'
   if 'native_legality.py' in file or 'native/semantic.py' in file.replace('\\','/') or file in ('<lazy-native-binding-prototype>','<lazy-definitions>'):group='native_bridge_body'
   elif fn in ('_make_binding_from_action','_path_for_geometry'):group='binding_reconstruction_body'
   elif 'search_runtime.py' in file or 'terminal.py' in file:group='core_state_history_terminal_body'
   elif 'semantic_executor.py' in file:group='other_semantic_body'
   groups[group]=groups.get(group,0)+tt;calls.append(dict(file=f,line=line,function=fn,primitive=cc,total=nc,exclusive=tt,inclusive=ct,group=group))
  r['rows'].append(dict(root=name,mode=mode,profile_total=stats.total_tt,exclusive_groups=groups,search=v,calls=calls));write(B/'lazy-binding-profile.json',r);print(name,mode,groups,flush=True)
r['complete']=True;r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write(B/'lazy-binding-profile.json',r)
