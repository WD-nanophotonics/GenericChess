from pathlib import Path
import sys,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
B=ROOT/'.local_agent/skippable-contract-20261011'
source=(B/'lazy-binding.py').read_text();ns={};exec(compile(source[:source.index("r=dict(complete=False")],'<lazy-definitions>','exec'),ns)
LazyProvider=ns['LazyProvider'];nl=ns['nl'];CoreBoard=ns['CoreBoard'];CASES=ns['CASES'];build=ns['build_builtin_ruleset'];compile_rules=ns['compile_ruleset_for_execution'];write=ns['write_record']
r=dict(complete=False,checks=0,roots=[],cancellation=[],error_stage={})
class Cancelled(Exception):pass
for case in CASES:
 c=compile_rules(build('western_chess' if case['game']=='chess' else 'standard_shogi'));p=nl.NativeSemanticLegalityProvider.try_create(c,strict=True);q=LazyProvider.try_create(c,strict=True);assert p and q;b=CoreBoard(case,c);pos=b.initial.position;eager=p(pos,b.initial.ply_count);lazy=q(pos,b.initial.ply_count);assert [x[0] for x in eager]==[x[0] for x in lazy]
 # Parent bindings survive a real advancing/returning path; immutable parent is explicit.
 actions=b.legal_actions();b.push(actions[0]);b.pop();assert b.restored()
 for (a,v),(aa,vv) in zip(eager,lazy):assert a==aa and v==tuple(vv);r['checks']+=1
 r['roots'].append(dict(root=case['id'],actions=len(eager)))
 # cancellation before deferred materialization, then fresh retry from retained immutable input.
 armed=[False]
 def poll():
  if armed[0]:raise Cancelled('deferred materialization cancelled')
 pair=q(pos,b.initial.ply_count,poll)[0][1];armed[0]=True
 try:tuple(pair)
 except Cancelled:pass
 else:raise AssertionError('no cancel')
 assert pair.value is None;armed[0]=False;assert tuple(pair)==eager[0][1];r['cancellation'].append(case['id'])
# Deliberate invalid binding-stage failure demonstrates a changed interface, not adoption.
case=CASES[0];c=compile_rules(build('western_chess'));p=nl.NativeSemanticLegalityProvider.try_create(c,strict=True);q=LazyProvider.try_create(c,strict=True);b=CoreBoard(case,c);old=p.engine._make_binding_from_action
try:
 def bad(*args):raise ValueError('synthetic binding-stage fault')
 p.engine._make_binding_from_action=bad
 try:p(b.initial.position,b.initial.ply_count)
 except ValueError as e:r['error_stage']['eager_call']=str(e)
 pairs=q(b.initial.position,b.initial.ply_count);r['error_stage']['lazy_call_returns']=True
 try:tuple(pairs[0][1])
 except ValueError as e:r['error_stage']['lazy_force']=str(e)
finally:p.engine._make_binding_from_action=old
r['complete']=True;r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write(B/'lazy-binding-audit.json',r);print(r)
