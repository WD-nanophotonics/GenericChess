from pathlib import Path
import sys,time,cProfile,pstats,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.search_backend_comparison import CASES,CoreBoard,supported_search
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Dot replacement-cost diagnostic, not a timing benchmark: current Chess-middle/Shogi-drop q0D2, material/TT/order/tacticalFalse fixed,30sec100k; same Core history/terminals. Heavy profile separate from pre/post unprofiled wall. Native syntax cache fresh each search; no full Native search or DLL rebuild.',rows=[])
for name in ('chess-middle','shogi-drop'):
 case=next(c for c in CASES if c['id']==name);t=time.perf_counter();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));compiled_seconds=time.perf_counter()-t;t=time.perf_counter();provider=NativeSemanticLegalityProvider.try_create(c,strict=True);provider_setup=time.perf_counter()-t
 if provider is None:raise RuntimeError('Native control unavailable')
 for mode in ('core','native_legality'):
  stopped();board=CoreBoard(case,c)
  def run():
   provider._metrics_local.public_cache={}
   value=supported_search(board,2,30,100000,provider=provider if mode=='native_legality' else None)
   assert board.restored()
   return value
  before=run();prof=cProfile.Profile();prof.enable();value=run();prof.disable();after=run();ps=pstats.Stats(prof);calls=[]
  for (file,line,fn),(cc,nc,tt,ct,callers) in ps.stats.items():calls.append(dict(file=file.replace(str(ROOT),'<ROOT>'),line=line,function=fn,primitive=cc,total=nc,exclusive=tt,inclusive=ct))
  focus=[x for x in calls if x['function'] in ('iter_legal_action_bindings','_make_binding_from_action','_path_for_geometry','_transition','_apply_transition_triggers','is_square_attacked','_state_only_payload','pack_position','transient_legal_actions','_decode_action','terminal_result','terminal_result_with_legal','_terminal_without_actions')]
  r['rows'].append(dict(root=name,mode=mode,compiled_seconds=compiled_seconds,provider_setup_seconds=provider_setup,provider_compile_seconds=provider.compile_seconds,before=before,profiled=value,after=after,profile_total=ps.total_tt,focus=focus,top_exclusive=sorted(calls,key=lambda x:x['exclusive'],reverse=True)[:20]));write_record(B/'backend-ledger.json',r);print(name,mode,'profile',ps.total_tt,'coregen',[(x['function'],x['total']) for x in focus],flush=True)
r['complete']=True;write_record(B/'backend-ledger.json',r)
