from pathlib import Path
import sys,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from dataclasses import replace
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.rules.ir import _incoming_attack_sources
from generic_chess.core.semantic_executor import SemanticEngine
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.research_record import write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
case=next(c for c in CASES if c['id']=='chess-middle');c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));board=CoreBoard(case,c);e=SemanticEngine(c);position=board.initial.position
# Diagnostic replacement retains exact row objects but concentrates duplicates
# into one endpoint. This is an upper-bound scheduling stress, not public
# compiler input or a generated-rule performance claim.
key,eligible=next((key,tuple(row for row in rows if position.board[row[2]] is not None and position.board[row[2]].owner==int(key[0]) and position.board[row[2]].current_type_id==row[1])) for key,rows in c._incoming_attack_paths.items() if any(position.board[row[2]] is not None and position.board[row[2]].owner==int(key[0]) and position.board[row[2]].current_type_id==row[1] for row in rows))
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='synthetic duplicate concentrated endpoint upper-bound; keeps original dynamic guard/row objects, not compiler-support or universal latency',rows=[])
for count in (65536,):
 rows=tuple(eligible[i%len(eligible)] for i in range(count));compiled=replace(c);object.__setattr__(compiled,'_incoming_attack_paths',{key:rows});plan=_incoming_attack_sources({key:rows});object.__setattr__(compiled,'_incoming_attack_sources',plan);engine=SemanticEngine(compiled)
 for arm in ('off','on','on','off'):
  object.__setattr__(compiled,'_incoming_attack_sources',plan if arm=='on' else None);polls=[];start=time.perf_counter()
  actual=engine.is_square_attacked(position,key[1],int(key[0]),checkpoint=lambda:polls.append(time.perf_counter()));finish=time.perf_counter();gaps=[b-a for a,b in zip([start]+polls,polls+[finish])]
  stopped=[]
  for stop_at in (1,2,3):
   calls=[0]
   def cancel():
    calls[0]+=1
    if calls[0]==stop_at:raise InterruptedError('boundary')
   try:engine.is_square_attacked(position,key[1],int(key[0]),checkpoint=cancel)
   except InterruptedError:stopped.append(dict(at=stop_at,cancelled=True,calls=calls[0]))
   else:stopped.append(dict(at=stop_at,cancelled=False,calls=calls[0]))
  r['rows'].append(dict(count=count,arm=arm,value=actual,wall=finish-start,polls=len(polls),maximum_gap=max(gaps),cancel_probes=stopped));write_record(B/'incoming-boundary-clean.json',r)
 r['rows'][-1]['pair_value_equal']=len({x['value'] for x in r['rows'] if x['count']==count})==1
r['complete']=True;write_record(B/'incoming-boundary-clean.json',r);print(r)
