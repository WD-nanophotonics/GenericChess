from pathlib import Path
import sys,random,time,hashlib
from dataclasses import replace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
from scripts.reserve_refresh_diagnostic import stopped
B=ROOT/'.local_agent/skippable-contract-20261011';start=time.perf_counter();r=dict(complete=False,plan=(B/'generated-source-plan.md').read_text(),rows=[],queries=0,positions=0)
for seed in range(2026101101,2026101105):
 stopped();cfg=GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True,max_generation_attempts=25)
 try:g=generate_game(cfg)
 except Exception as e:r['rows'].append(dict(seed=seed,error=type(e).__name__,message=str(e)));write_record(B/'generated-source.json',r);continue
 c=compile_semantic_ruleset(g.ruleset);old=replace(c);object.__setattr__(old,'_incoming_attack_sources',None);full=replace(c);object.__setattr__(full,'_incoming_attack_sources',None);object.__setattr__(full,'_incoming_attack_paths',None);engines=[SemanticEngine(x) for x in (c,old,full)];session=GameSession(c);rng=random.Random(seed);row=dict(seed=seed,rules=record_value(ruleset_to_dict(g.ruleset)),attempts=g.generation_report.generation_attempts,positions=0,queries=0,actions=[])
 for ply in range(9):
  stopped();assert time.perf_counter()-start<120;pos=session.state.position
  for owner in (0,1):
   for square in range(len(pos.board)):
    a=[e.is_square_attacked(pos,square,owner) for e in engines];assert a[0]==a[1]==a[2];row['queries']+=1;r['queries']+=1
  row['positions']+=1;r['positions']+=1;actions=session.legal_actions()
  if not actions:break
  action=rng.choice(sorted(actions,key=str));row['actions'].append(record_value(action));session.submit(action)
 r['rows'].append(row);write_record(B/'generated-source.json',r);print(seed,row['positions'],row['queries'],flush=True)
r['complete']=True;r['wall']=time.perf_counter()-start;r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(B/'generated-source.json',r)
