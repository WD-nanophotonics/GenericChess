from pathlib import Path
import sys,random,json,hashlib,itertools,time
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from generic_chess.core import semantic_executor as se
from generic_chess.core.pieces import Piece
from generic_chess.rules.ir import CompiledStatePredicate as Guard,CompiledSpatialSelector as Spatial,CompiledSquareRef as Ref,CompiledTypeRef as Type
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from test_rectangular_semantic_action_b4b import _rectangular_single_capture_ruleset
from scripts.research_record import write_record
base=ROOT/'.local_agent/skippable-contract-20261011'
ns=dict(se.__dict__);exec(compile((base/'guard-shortcircuit-candidate.py').read_text(),'<guard-line-v2>','exec'),ns);new=ns['_guard_holds'];old=se.SemanticEngine._guard_holds
rng=random.Random(20261011);result=dict(complete=False,seed=20261011,checks=0,by_shape={},disagreements=[],paired_errors=0,cancel_checks=0,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());started=time.perf_counter()
for game in ('western_chess','standard_shogi','rectangle'):
 rules=_rectangular_single_capture_ruleset() if game=='rectangle' else build_builtin_ruleset(game)
 compiled=compile_ruleset_for_execution(rules);eng=se.semantic_engine_for(compiled);initial=eng._initial_position();shape=eng.support.board_shape
 ids=list(eng.support.type_metadata);types=[Type('any'),Type('action_base'),Type('action_current')]+[Type('explicit',i) for i in ids[:2]]
 refs=[Ref('source'),Ref('target'),Ref('path_step',step=0),Ref('path_step',step=100),Ref('offset_from_source',offset=(1,0)),Ref('offset_from_target',offset=(0,-1)),Ref('fixed',square=(shape.width-1,shape.height-1),owner_relative=True),Ref('fixed',square=(0,0),owner_relative=False)]
 refs.extend(Ref('aux_slot_square',slot_id=s.slot_id) for s in eng.ir.aux_slots if s.value_kind=='square_or_none')
 n=0
 for trial in range(2400):
  board=tuple(None if rng.random()<.55 else Piece(rng.randrange(2),rng.choice(ids),rng.choice(ids),rng.choice((True,False))) for _ in range(shape.area))
  pos=replace(initial,board=board);side=rng.randrange(2);binding=se._ActionBinding(None,'audit',side,ids[0],ids[0],ids[-1],rng.choice((None,rng.randrange(shape.area))),rng.randrange(shape.area),None,(rng.randrange(shape.area),))
  ref=rng.choice(refs);spatial=Spatial(rng.choice(('same_file','same_rank')),refs=(ref,));subject=rng.choice((None,None,Ref('source'),Ref('target'),Ref('path_step',step=100)))
  guard=Guard(rng.choice(('count','exists')),rng.choice(('self','opponent','any')),rng.choice(types),rng.choice(('base','current')),rng.choice(('yes','no','any')),'board',spatial,rng.choice(('eq','ne','lt','le','gt','ge')),rng.randrange(5),subject)
  def outcome(fn):
   try:return dict(value=fn(eng,guard,pos,binding,side))
   except Exception as exc:return dict(error=type(exc).__name__,message=str(exc))
  a=outcome(old);b=outcome(new)
  if a!=b:result['disagreements'].append(dict(game=game,trial=trial,guard=repr(guard),binding=repr(binding),board=repr(board),old=a,new=b))
  elif 'error' in a:result['paired_errors']+=1
  result['checks']+=1;n+=1
 result['by_shape'][game]=dict(width=shape.width,height=shape.height,checks=n,ref_kinds=sorted({r.kind for r in refs}))
 # Invalid refs, empty boards and zero counts must still observe cancellation.
 pos=replace(initial,board=(None,)*shape.area);binding=se._ActionBinding(None,'audit',0,ids[0],ids[0],ids[0],None,0,None,())
 for kind in ('same_file','same_rank'):
  guard=Guard('count','any',Type('any'),'base','any','board',Spatial(kind,(Ref('source'),)),'eq',0)
  for fn in (old,new):
   def cancel():raise RuntimeError('audit cancellation')
   try:fn(eng,guard,pos,binding,0,checkpoint=cancel)
   except RuntimeError as e:assert str(e)=='audit cancellation';result['cancel_checks']+=1
   else:raise AssertionError('cancellation lost')
result['complete']=True;result['wall']=time.perf_counter()-started;write_record(base/'guard-shortcircuit-audit.json',result);print(json.dumps(result,indent=2))
