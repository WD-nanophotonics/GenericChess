from pathlib import Path
import sys,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record,record_value
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
B=ROOT/'.local_agent/skippable-contract-20261011'
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
for case in CASES:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));plan=c._incoming_attack_sources
 for mode in ('minimal','supported'):
  for arm in ('off','on','on','off'):
   stopped();object.__setattr__(c,'_incoming_attack_sources',plan if arm=='on' else None);b=CoreBoard(case,c)
   if mode=='minimal':d=minimal_ab(b,2,seconds=30,node_limit=100000,cooperative=True)
   else:
    s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses
    d=record_value(AlphaBetaPlayer(c,evaluator_override=b.material,use_native_semantic_legality=False,use_tt=False).choose_action(s,SearchLimits(max_depth=2,max_time_seconds=30,max_nodes=100000,quiescence_max_depth=0,quiescence_hard_max_depth=0)))
    assert s.state==b.initial and s._search_history_witnesses==b.witnesses
   r['rows'].append(dict(case=case['id'],mode=mode,arm=arm,result=d));write_record(B/'incoming-installed.json',r);print(case['id'],mode,arm,flush=True)
 object.__setattr__(c,'_incoming_attack_sources',plan)
r['complete']=True;write_record(B/'incoming-installed.json',r)
