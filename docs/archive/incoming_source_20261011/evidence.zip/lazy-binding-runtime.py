from pathlib import Path
import sys,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/skippable-contract-20261011'
source=(B/'lazy-binding.py').read_text();ns={};exec(compile(source[:source.index("r=dict(complete=False")],'<lazy-definitions>','exec'),ns)
LazyProvider=ns['LazyProvider'];CoreBoard=ns['CoreBoard'];CASES=ns['CASES'];build=ns['build_builtin_ruleset'];compile_rules=ns['compile_ruleset_for_execution'];write=ns['write_record']
class Interrupted(Exception):pass
r=dict(complete=False,scope='Prototype runtime rollback for lazy tuple consumption. Synthetic checkpoint exceptions before/after binding and operational fault. Not live wall/cancel-token latency or automatic provider fallback.',rows=[])
for case in CASES:
 c=compile_rules(build('western_chess' if case['game']=='chess' else 'standard_shogi'))
 for when in ('before','after','binding_fault'):
  p=LazyProvider.try_create(c,strict=True);assert p;b=CoreBoard(case,c,provider=p);actions=b.actions();action=actions[0][1];pair=b.runtime._bindings[action];old=p.engine._make_binding_from_action;counter=[0]
  def poll():
   counter[0]+=1
   if counter[0]==(1 if when=='before' else 2):raise Interrupted('synthetic deferred boundary')
  pair.checkpoint=poll if when!='binding_fault' else None
  def bad(*args):raise ValueError('synthetic deferred binding fault')
  if when=='binding_fault':p.engine._make_binding_from_action=bad
  before=b.snapshot()
  try:b.push(action)
  except (Interrupted,ValueError) as e:error=type(e).__name__
  else:raise AssertionError('no abort')
  assert b.snapshot()==before and b.restored();b.runtime.assert_balanced();retained=pair.value is not None
  p.engine._make_binding_from_action=old;pair.checkpoint=None;b.push(action);b.pop();assert b.restored();b.runtime.assert_balanced()
  r['rows'].append(dict(root=case['id'],boundary=when,error=error,retained_binding=retained,restored=True,retry=True))
r['complete']=True;r['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write(B/'lazy-binding-runtime.json',r);print(len(r['rows']),'restored/retried')
