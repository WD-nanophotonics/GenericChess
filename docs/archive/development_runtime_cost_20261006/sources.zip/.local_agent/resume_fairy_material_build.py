"""Explicit changed-premise continuation: freeze banner date, keep first failure."""
import pathlib,json,subprocess,sys,time,hashlib,os
ROOT=pathlib.Path(__file__).resolve().parents[1];p=ROOT/'.local_agent/mature-search'
old=json.loads((p/'build-report.json').read_bytes());assert not old['complete'] and old['commands'][-1]['source']=='misc.cpp' and '-Wdate-time' in old['commands'][-1]['stderr']
sha=old['revision'];src=p/f'Fairy-Stockfish-{sha}'/'src';out=p/'build'
base=[sys.executable,'-m','ziglang','c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-fno-exceptions','-fno-strict-aliasing','-DNDEBUG','-DIS_64BIT','-DNNUE_EMBEDDING_OFF','-DGENERICCHESS_MATERIAL_DEVELOPMENT','-D__DATE__="Sep 22 2026"','-Wno-builtin-macro-redefined']
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(p/'zig-global-cache'),ZIG_LOCAL_CACHE_DIR=str(p/'zig-local-cache'))
report=dict(scope='Resume failed misc.cpp with deterministic source-commit banner date, no source/search changes; original build-report.json retained',revision=sha,original_report_sha256=hashlib.sha256((p/'build-report.json').read_bytes()).hexdigest(),commands=[],reused_objects={},complete=False)
start=time.perf_counter()
for source in old['sources']:
 flags=[json.loads((ROOT/'.local_agent'/(x+'.json')).read_bytes()) for x in ('rollout','advisor','slack')]
 if any(x.get('user_paused') or x.get('stopped') for x in flags):raise SystemExit('User stop retained')
 obj=out/(source.replace('/','_')+'.o')
 if obj.exists() and any(x['source']==source and x.get('exit_code')==0 for x in old['commands']):
  report['reused_objects'][source]=hashlib.sha256(obj.read_bytes()).hexdigest();continue
 cmd=base+['-c',str(src/source),'-o',str(obj)];r=subprocess.run(cmd,cwd=src,capture_output=True,text=True,timeout=90,env=env)
 report['commands'].append(dict(source=source,command=cmd[3:],exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));(p/'build-date-fixed-report.json').write_text(json.dumps(report,indent=2));print(source,r.returncode,flush=True)
 if r.returncode:break
else:
 binary=out/'fairy-material.exe';cmd=base+[str(out/(s.replace('/','_')+'.o')) for s in old['sources']]+['-o',str(binary),'-lpthread','-ladvapi32','-Wl,--stack,8388608'];r=subprocess.run(cmd,cwd=src,capture_output=True,text=True,timeout=90,env=env)
 report['link']=dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr)
 if not r.returncode:report.update(complete=True,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
report['wall_seconds']=time.perf_counter()-start;(p/'build-date-fixed-report.json').write_text(json.dumps(report,indent=2));print('complete',report['complete'],report['wall_seconds'],flush=True)
