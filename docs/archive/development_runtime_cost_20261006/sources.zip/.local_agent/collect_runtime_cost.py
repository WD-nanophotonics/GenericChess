"""One portable research record and inert exact producers, after computations."""
import sys,json,hashlib,zipfile,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'.local_agent';out=ROOT/'docs/research/data/chess_runtime_cost_results_20261006.json';assert not out.exists()
names=['chess_runtime_profile_20261006.json','chess_runtime_terminal_replay_20261006.json','chess_runtime_cost_curve_20261006.json','chess_runtime_cost_summary_20261006.json','chess_runtime_cost_games_20261006.json','chess_runtime_cost_game_replay_20261006.json','chess_runtime_unit_loss_reference_20261006.json','chess_unit_early_bishop_control_20261006.json','shogi_runtime_capture_drop_20261006.json']
reports={}
for name in names:
 raw=(p/name).read_bytes();body=json.loads(raw)
 if name!='chess_runtime_profile_20261006.json' and name!='chess_runtime_cost_summary_20261006.json':assert body['complete'],name
 transform=None
 if name=='chess_runtime_profile_20261006.json':
  encoded=json.dumps(body).replace(str(ROOT).replace('\\','\\\\'),'WORKSPACE').replace('C:\\\\Users\\\\wdai\\\\','LOCAL_USER/')
  body=json.loads(encoded);transform='Profile path labels normalized to WORKSPACE/LOCAL_USER; numeric observations unchanged; local raw retains originalSHA.'
 reports[name]=dict(raw_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw),transformation=transform,body=body)
games=reports['chess_runtime_cost_games_20261006.json']['body'];summary=[]
for q in (0,2):
 gs=[g for g in games['games'] if g['qdepth']==q];local=[r for g in gs for r in g['moves'] if r['policy']!='uci_reference']
 wins=sum(g['winner']==(0 if g['white']!='uci_reference' else 1) for g in gs if g['winner'] is not None)
 losses=sum(g['winner']!=(0 if g['white']!='uci_reference' else 1) for g in gs if g['winner'] is not None)
 summary.append(dict(qdepth=q,games=len(gs),wins=wins,losses=losses,draws=sum(g['winner'] is None and g['finished'] for g in gs),unfinished=sum(not g['finished'] for g in gs),played_plies=sum(g['plies_played'] for g in gs),depths=dict(collections.Counter(r['statistics']['completed_depth'] for r in local)),reasons=dict(collections.Counter(r['reason'] for r in local)),local_search_seconds=sum(r['wall_seconds'] for r in local)))
archive=ROOT/'docs/archive/development_runtime_cost_20261006';archive.mkdir(exist_ok=True)
producer=reports['chess_runtime_cost_curve_20261006.json']['body']['producer_sha256'];index={}
drivers=['profile_qcapture_runtime.py','runtime_cost_baseline.py','replay_runtime_terminal_cost.py','run_runtime_cost_development.py','analyze_runtime_cost.py','replay_runtime_cost_games.py','diagnose_unit_q2_loss.py','unit_early_bishop_control.py','shogi_practical_capture_drop.py','run_runtime_post_checks.py','build_fairy_material.py','resume_fairy_material_build.py','probe_fairy_material.py','probe_fairy_actual_bishop.py','play_fairy_material.py','replay_fairy_material_games.py','acquire_fairy_source.py','collect_runtime_cost.py']
with zipfile.ZipFile(archive/'sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in list(producer)+['tests/test_runtime_terminal_check_cost.py']+['.local_agent/'+x for x in drivers]:
  raw=(ROOT/name).read_bytes();sha=hashlib.sha256(raw).hexdigest()
  if name in producer:assert sha==producer[name],name
  z.writestr(name,raw);index[name]=dict(sha256=sha,bytes=len(raw))
write_record(archive/'sources.json',dict(scope='Exact deferred-terminal producers and diagnostic drivers; inert evidence, not active policy',sources=index,archive_sha256=hashlib.sha256((archive/'sources.zip').read_bytes()).hexdigest()))
mature={}
for name in ('acquisition.json','fairy-revision.json','build-report.json','build-resume-report.json','build-date-fixed-report.json','probe-results.json','actual-bishop-results.json','playing-results.json','playing-replay.json'):
 f=p/'mature-search'/name
 if f.exists():
  raw=f.read_bytes();body=json.loads(raw)
  # Build diagnostics contain local command paths; normalize portable labels.
  text=json.dumps(body).replace(str(ROOT).replace('\\','\\\\'),'WORKSPACE').replace('C:\\\\Users\\\\wdai\\\\','LOCAL_USER/')
  mature[name]=dict(raw_sha256=hashlib.sha256(raw).hexdigest(),body=json.loads(text),transformation='Local path labels normalized; raw retained locally')
for name in ('material.patch','FEASIBILITY.md','material-variants.ini'):
 f=p/'mature-search'/name
 if f.exists():(archive/name).write_bytes(f.read_bytes())
result=dict(scope='Exposed development resources/play/finite proxies and synthetic Shogi approximation; no calibratedWDL/holdout/Elo/scientific completion. No public push.',reports=reports,games_summary=summary,mature=mature,archive='docs/archive/development_runtime_cost_20261006/sources.json',complete=True)
write_record(out,result);print(json.dumps(summary,indent=2));print('portable',out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
