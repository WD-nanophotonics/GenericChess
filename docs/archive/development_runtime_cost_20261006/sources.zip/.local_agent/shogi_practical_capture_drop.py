"""Two new full-stock discriminating development roots; explicit hand point."""
import sys,json,hashlib,time
from pathlib import Path
from fractions import Fraction as F
from dataclasses import replace,asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.core.transition import initial_state,legal_successors,apply_action
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.position import Hands
from generic_chess.ai.alphabeta.search import run_root_search,terminal_score
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.audit_exchange_custody import synthetic_state
from scripts.shogi_full_affine_inventory import FullAffineInventory,BASES
from scripts.shogi_static_inventory import quantize
from scripts.shogi_exact_contact_family import exact_board_means
from scripts.resource_mode_context import resource_ledger
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/shogi_runtime_capture_drop_20261006.json';assert not out.exists()
c=compile_ruleset_for_execution(build_standard_shogi_ruleset());initial=initial_state(c)
board=list(initial.position.board)
for source,target in ((10,40),(64,43),(58,49)):
 assert board[source] is not None and board[target] is None
 board[target]=board[source];board[source]=None
capture=synthetic_state(c,replace(initial.position,board=tuple(board),side_to_move=0))
board2=list(board);rook=board2[40];bishop=board2[16];assert rook.current_type_id=='R' and bishop.current_type_id=='B';board2[40]=None;board2[16]=None
drop=synthetic_state(c,replace(initial.position,board=tuple(board2),hands=(Hands((('B',1),('R',1))),initial.position.hands[1]),side_to_move=0))
class PointInventory:
 def __init__(self,weights):
  self.affine=FullAffineInventory(c,weights);self.held={base:quantize(F(1,2)*weights[base]) for base in BASES};self.calls=0
 def evaluate(self,state):
  row=self.affine.row(state);value=row[0]+sum(row[i+1]*self.held[base] for i,base in enumerate(BASES));self.calls+=1
  return value if state.position.side_to_move==0 else -value
limits=SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8,quiescence_max_nodes=2048)
means=exact_board_means('geometric_half');weights={k:v/means['TR'] for k,v in means.items()}
report=dict(scope='Two new synthetic full-conserved-stock Shogi roots, not claimed historically reachable/heldout/WDL/strength. Explicit approximate held point h(base)=one-half normalized board(base), shared across every leaf; not certified deployed held law.',question='Can existing full board coefficients plus declared held approximation run a discriminating capture/drop comparison without exact-hand-proof gates?',cost='Four equal2ply2048node10sec calls, one-ply rows for tie/choice diagnostics, no worker or price fitting',limits=asdict(limits),sources_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['scripts/shogi_full_affine_inventory.py','scripts/shogi_exact_contact_family.py','generic_chess/core/terminal.py','generic_chess/ai/alphabeta/search.py']},roots=[],complete=False)
for name,root in [('capture',capture),('drop',drop)]:
 resource_ledger(c,root.position,'shogi');assert not root.terminal_status.is_terminal
 rr=dict(name=name,root=record_value(root),models=[]);report['roots'].append(rr)
 for policy,w in [('geometric_half',weights),('unit',{k:F(1) for k in weights})]:
  e=PointInventory(w);children=list(legal_successors(root,c));oneply={str(a):(-terminal_score(child.terminal_status,child.position.side_to_move,1) if child.terminal_status.is_terminal else -e.evaluate(child)) for a,child in children};best=max(oneply.values());ties=sorted(k for k,v in oneply.items() if v==best)
  stats=SearchStatistics();started=time.perf_counter();a,score,pv,reason=run_root_search(root,c,e,TranspositionTable(),limits,None,stats,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=True))
  assert a in {a for a,_ in children};chosen=apply_action(root,a,c);resource_ledger(c,chosen.position,'shogi')
  runtime=SearchPathRuntime.from_state(root,c)
  with runtime.pushed(a):assert runtime.position==chosen.position and runtime.terminal_status==chosen.terminal_status
  runtime.assert_balanced()
  r=dict(policy=policy,board_weights=e.affine.weights,held_weights=e.held,oneply_best=best,oneply_ties=ties,oneply_rows=oneply,selected=str(a),score=score,pv=[str(x) for x in pv],reason=reason,wall_seconds=time.perf_counter()-started,statistics=asdict(stats),legal_actions=len(children),evaluations=e.calls)
  rr['models'].append(r);write_record(out,report);print(name,policy,r['selected'],reason,stats.completed_depth,'oneplyties',len(ties),flush=True)
report['complete']=True;write_record(out,report)
