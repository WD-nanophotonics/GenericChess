import json,hashlib,collections
from pathlib import Path
p=Path('.local_agent');r=json.loads((p/'chess_runtime_cost_curve_20261006.json').read_bytes());assert r['complete'] and len(r['rows'])==288
rows=r['rows']; groups=[]; parity=[]
for q in (0,2):
 pair={}
 for row in rows:
  if row['qdepth']==q:pair.setdefault((row['case_id'],row['policy']),{})[row['version']]=row
 for version in ('baseline','deferred'):
  selected=[r for r in rows if r['qdepth']==q and r['version']==version]
  groups.append(dict(qdepth=q,version=version,count=len(selected),depths=dict(collections.Counter(x['statistics']['completed_depth'] for x in selected)),reasons=dict(collections.Counter(x['reason'] for x in selected)),answers=sum(x['answer_hit'] for x in selected),wall_seconds=sum(x['wall_seconds'] for x in selected),nodes=sum(x['statistics']['nodes'] for x in selected),qnodes=sum(x['statistics']['qnodes'] for x in selected),runtime_pushes=sum(x['statistics']['runtime_pushes'] for x in selected)))
 shared=[];errors=[]
 for key,versions in pair.items():
  a,b=versions['baseline'],versions['deferred']
  if a['statistics']['completed_depth']==b['statistics']['completed_depth']==4:
   shared.append((a,b))
   fields=('move','score'); stats=('nodes','qnodes','runtime_pushes')
   if any(a[k]!=b[k] for k in fields) or any(a['statistics'][k]!=b['statistics'][k] for k in stats):errors.append(dict(case=key,baseline={k:a[k] for k in fields},deferred={k:b[k] for k in fields}))
 parity.append(dict(qdepth=q,shared_complete=len(shared),mismatches=errors,baseline_seconds=sum(a['wall_seconds'] for a,b in shared),deferred_seconds=sum(b['wall_seconds'] for a,b in shared)))
out=dict(scope='All fixed cost/depth outcomes; wall comparison restricted to identical complete4ply work. Single sequential development batch, not statistical speed/strength certification.',groups=groups,shared_complete=parity,input_sha256=hashlib.sha256((p/'chess_runtime_cost_curve_20261006.json').read_bytes()).hexdigest())
(p/'chess_runtime_cost_summary_20261006.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
