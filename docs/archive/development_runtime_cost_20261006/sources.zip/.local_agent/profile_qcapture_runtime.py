"""Fixed actual root20; profiling is diagnostic, not deployment timing."""
import sys,json,cProfile,pstats,hashlib
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/chess_runtime_profile_20261006.json';assert not out.exists()
raw=(ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json').read_bytes();game=json.loads(raw)['games'][0]
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());s=d.root_from_fen(game['initial_fen'],c);w=[s.position]
for r in game['moves'][:20]:
 s=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==r['move']),c);w.append(s.position)
provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
report=dict(scope='cProfile diagnostic at prospectively selected actual root20, equal2ply32768nodes30sec, no operational timing/strength claim',input_sha256=hashlib.sha256(raw).hexdigest(),base_sha='f7b8a497804ce2823a7ec216a70bb9da6c6bf3a0',question='Locate classification/semantic runtime overhead before proposing optimization',cost='Two bounded interruptible local calls; no extra worker',rows=[],complete=False)
for q in (0,2):
 limits=d.SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
 tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=q==0,use_ordered_qsearch=True,use_capture_only_qsearch=q>0)
 profile=cProfile.Profile();profile.enable()
 a,row=d.search_move(s,c,'geometric_half',limits,provider=provider,ordering=True,use_tt=True,dynamic='cached_legacy',tuning=tuning,_history_witnesses=tuple(w))
 profile.disable();stats=pstats.Stats(profile)
 functions=[dict(file=Path(k[0]).as_posix(),line=k[1],name=k[2],primitive_calls=v[0],calls=v[1],self_seconds=v[2],cumulative_seconds=v[3]) for k,v in stats.stats.items()]
 row.update(qdepth=q,limits=asdict(limits),tuning=asdict(tuning),total_profile_seconds=stats.total_tt,top_cumulative=sorted(functions,key=lambda x:x['cumulative_seconds'],reverse=True)[:35],top_self=sorted(functions,key=lambda x:x['self_seconds'],reverse=True)[:20])
 report['rows'].append(row);d.write_record(out,report)
 print(q,row['move'],row['reason'],row['statistics']['completed_depth'],round(row['wall_seconds'],3),json.dumps(row['top_cumulative'][:16]),flush=True)
report['complete']=True;d.write_record(out,report)
