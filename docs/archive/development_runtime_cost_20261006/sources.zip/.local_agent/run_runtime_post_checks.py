"""One sequential post-timing chain; no second timed writer."""
from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
assert json.loads((ROOT/'.local_agent/chess_runtime_cost_games_20261006.json').read_bytes())['complete']
tasks=['replay_runtime_cost_games.py','diagnose_unit_q2_loss.py','unit_early_bishop_control.py','shogi_practical_capture_drop.py','build_fairy_material.py']
for name in tasks:
 flags=[json.loads((ROOT/'.local_agent'/(x+'.json')).read_bytes()) for x in ('rollout','advisor','slack')]
 if any(x.get('user_paused') or x.get('stopped') for x in flags):raise SystemExit('User stop retained')
 print('BEGIN',name,flush=True);r=subprocess.run([sys.executable,'-X','utf8',str(ROOT/'.local_agent'/name)],cwd=ROOT)
 print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
build=json.loads((ROOT/'.local_agent/mature-search/build-report.json').read_bytes())
if build['complete']:
 r=subprocess.run([sys.executable,'-X','utf8',str(ROOT/'.local_agent/probe_fairy_material.py')],cwd=ROOT);raise SystemExit(r.returncode)
