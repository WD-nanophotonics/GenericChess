"""Load exact inert baseline terminal function for single-writer comparisons."""
import hashlib,json,sys,types,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
folder=ROOT/'docs/archive/development_before_20261006_runtime_cost'
index=json.loads((folder/'sources.json').read_bytes())
with zipfile.ZipFile(ROOT/index['archive']) as archive:
    raw=archive.read('generic_chess/core/terminal.py')
assert hashlib.sha256(raw).hexdigest()==index['sources']['generic_chess/core/terminal.py']['sha256']
name='generic_chess.core._cost_baseline_terminal'
module=types.ModuleType(name);module.__package__='generic_chess.core';module.__file__='frozen_baseline_terminal.py'
sys.modules[name]=module
exec(compile(raw,module.__file__,'exec'),module.__dict__)
baseline=module.terminal_from_search_runtime
from generic_chess.core import terminal,search_runtime
current=terminal.terminal_from_search_runtime
# Reuse canonical result/enum identities so the current runtime's `is` checks
# see the same statuses. The exact old function body/precedence is unchanged.
module.TerminalStatus=terminal.TerminalStatus
module.TerminalResult=terminal.TerminalResult
def select(version):
    assert version in ('baseline','deferred')
    search_runtime.terminal_from_search_runtime=baseline if version=='baseline' else current
