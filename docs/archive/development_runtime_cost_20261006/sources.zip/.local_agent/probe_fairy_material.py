"""Pinned mature standard-Chess pure-material leaf development prototype."""
import sys,json,time,hashlib,subprocess,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-search';binary=p/'build/fairy-material.exe';assert binary.exists()
src=p/('Fairy-Stockfish-'+json.loads((p/'fairy-revision.json').read_bytes())['sha'])/'src'
suite=json.loads((ROOT/'docs/research/data/chess_development_suite.json').read_bytes())
models={policy:{kind:round(208*value/d.evaluator(policy).weights['P']) for kind,value in d.evaluator(policy).weights.items()} for policy in d.POLICIES}
config=p/'material-variants.ini';lines=[]
for policy,weights in models.items():
 lines += [f'[gc_{policy}:chess]', 'pieceValueMg = '+' '.join(f'{kind.lower()}:{value}' for kind,value in weights.items()),'pieceValueEg = '+' '.join(f'{kind.lower()}:{value}' for kind,value in weights.items()),'']
config.write_text('\n'.join(lines))
report=dict(scope='StandardChess only, pure board material Eval leaf; unchanged mature search/normal SEE/capture ordering keep old PieceValue table. Variant CapturePieceValue overrides concern atomic SEE, not normal Chess SEE. No generic transplant, pure-search attribution, Elo, holdout or price training.',scale='Normalize each model Pawn to upstream internal PawnValueEg208 before outcomes, matching UCI100cp; static one-Pawn eval control required. Shared integer rounding; no price fitting or threshold retuning.',revision=json.loads((p/'fairy-revision.json').read_bytes())['sha'],binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),models=models,cost='24exposed existing suite cases x3models x0.25sec single thread=18sec requested search, no fee/worker',conditions=dict(threads=1,hash_mib=16,seconds_per_search=.25,clear_hash_each_case=True),rows=[],complete=False)
out=p/'probe-results.json';assert not out.exists()
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
report['upstream_smoke']=[]
for args in (['bench','chess','16','1','2','default','depth','classical'],['check',str(src/'variants.ini')],['check',str(config)]):
 result=subprocess.run([str(binary)]+args,cwd=src,text=True,capture_output=True,timeout=45)
 report['upstream_smoke'].append(dict(arguments=args,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr));d.write_record(out,report)
 assert result.returncode==0, 'Upstream basic functionality/configuration smoke failed'
report['static_controls']=[]
for policy in models:
 for stm in ('w','b'):
  fen=f'rnbqkbnr/1ppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR {stm} KQkq - 0 1'
  commands=f'uci\nsetoption name UCI_Variant value gc_{policy}\nsetoption name Use NNUE value false\nisready\nposition fen {fen}\neval\nquit\n'
  result=subprocess.run([str(binary),'load',str(config)],input=commands,cwd=src,text=True,capture_output=True,timeout=15)
  found=re.search(r'Final evaluation\s+([+-]?[0-9.]+)',result.stdout)
  control=dict(policy=policy,fen=fen,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr,white_pawn_units=float(found.group(1)) if found else None)
  report['static_controls'].append(control);d.write_record(out,report)
  assert result.returncode==0 and control['white_pawn_units']==1.0, 'Static one-Pawn difference must show1.00Pawn=100cp for both side orientations'
for policy,weights in models.items():
 with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],cwd=src,timeout=15) as engine:
  engine.configure({'Threads':1,'Hash':16,'Use NNUE':False})
  # python-chess owns UCI_Variant; a standard-legality subclass names the config.
  MaterialBoard=type('MaterialBoard',(chess.Board,),{'uci_variant':f'gc_{policy}'})
  for case in suite['cases']:
   board=MaterialBoard(case['fen']);root=d.root_from_fen(case['fen'],c);assert {m.uci() for m in board.legal_moves}=={d.uci(a) for a in d.iter_legal_actions(root,c)}
   engine.configure({'Clear Hash':None});started=time.perf_counter();info=engine.analyse(board,chess.engine.Limit(time=.25),game=object());move=info['pv'][0].uci();assert move in {m.uci() for m in board.legal_moves}
   row=dict(policy=policy,case_id=case['id'],move=move,answer_hit=move in case['accepted_uci'],depth=info.get('depth'),seldepth=info.get('seldepth'),nodes=info.get('nodes'),time=info.get('time'),wall_seconds=time.perf_counter()-started,score_cp=info['score'].pov(board.turn).score(),score_mate=info['score'].pov(board.turn).mate(),pv=[m.uci() for m in info.get('pv',())]);report['rows'].append(row);d.write_record(out,report)
 print(policy,len(report['rows']),flush=True)
report['complete']=True;d.write_record(out,report)
