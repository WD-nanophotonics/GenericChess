"""New premise from actual prefix: ply7 Bxa3, before original reference points."""
import sys,json,hashlib
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
raw=(ROOT/'.local_agent/chess_qcapture_games_20261006.json').read_bytes();g=next(g for g in json.loads(raw)['games'] if g['black']=='unit' and g['qdepth']==2)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());s=d.root_from_fen(g['initial_fen'],c);author=d.UciOpponent(None,g['initial_fen'],1)
for row in g['moves'][:7]:
 a=next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==row['move']);s=d.apply_action(s,a,c);author.push(row['move'],s)
actual=g['moves'][7]['move'];assert actual=='f8a3' and g['moves'][8]['move']=='b2a3'
report=dict(scope='New explicit changed-premise development control before original ten fixed references: actual ply7 Bxa3 then bxa3 exchanges Bishop for Pawn. Unit values both equally; may be evaluation assumption, not q2 machinery. No fitting/strength claim.',input_sha256=hashlib.sha256(raw).hexdigest(),actual=actual,rows=[],complete=False)
out=ROOT/'.local_agent/chess_unit_early_bishop_control_20261006.json';assert not out.exists()
provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
for policy,q in [('unit',0),('unit',2),('geometric_half',0),('geometric_half',2)]:
 limits=d.SearchLimits(max_depth=4,max_nodes=32768,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
 tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=q==0,use_ordered_qsearch=True,use_capture_only_qsearch=q>0)
 a,r=d.search_move(s,c,policy,limits,provider=provider,ordering=True,use_tt=True,dynamic='cached_legacy',tuning=tuning)
 r.update(qdepth=q,limits=asdict(limits));report['rows'].append(r);d.write_record(out,report)
enginepath=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
report['reference_conditions']=dict(binary_sha256=hashlib.sha256(enginepath.read_bytes()).hexdigest(),threads=1,hash_mib=16,nodes=50000,fresh_game_each_call=True,full_actual_history=True)
with chess.engine.SimpleEngine.popen_uci(str(enginepath),timeout=10) as engine:
 engine.configure({'Threads':1,'Hash':16});board=author.board.copy(stack=True);best=engine.analyse(board,chess.engine.Limit(nodes=50000),game=object())['pv'][0].uci();report['root_best']=best;report['references']={}
 for move in sorted({best,actual}|{r['move'] for r in report['rows']}):
  child=board.copy(stack=True);child.push_uci(move);info=engine.analyse(child,chess.engine.Limit(nodes=50000),game=object());v=info['score'].pov(board.turn);report['references'][move]=dict(cp=v.score(),mate=v.mate(),pv=[m.uci() for m in info.get('pv',())]);d.write_record(out,report)
report['complete']=True;d.write_record(out,report);print([(r['policy'],r['qdepth'],r['move'],r['statistics']['completed_depth']) for r in report['rows']],report['references'])
