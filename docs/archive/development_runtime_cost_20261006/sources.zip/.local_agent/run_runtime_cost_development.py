"""Exact baseline/deferred terminal resource curve then declared real games."""
import sys,json,hashlib,time
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent'));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import runtime_cost_baseline as b
import chess.engine
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
sources={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['generic_chess/core/terminal.py','generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/quiescence.py','scripts/chess_development.py','scripts/chess_shared_dynamic.py','scripts/research_record.py']}
def stop_check():
 for name in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise SystemExit('Explicit user stop retained')
def config(q):
 return d.SearchLimits(max_depth=4,max_nodes=32768,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=32768),SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=q==0,use_ordered_qsearch=True,use_capture_only_qsearch=q>0)
out=ROOT/'.local_agent/chess_runtime_cost_curve_20261006.json';assert not out.exists()
raw=(ROOT/'docs/research/data/chess_development_suite.json').read_bytes();suite=json.loads(raw)
report=dict(scope='All24cases3unchanged prices2qprofiles2terminal implementations; frozen baseline function with canonical enum/result identity adapter, unchanged function body. Same4ply32768nodes5sec. Exposed development cost/completion, not price/strength inference.',question='Does deferring unused check queries improve resources without changing complete results?',cost='288fixed calls max24minutes local single-writer; interruptible, no model worker. Alternating version order by case/policy/q to reduce order bias.',base_sha='f7b8a497804ce2823a7ec216a70bb9da6c6bf3a0',baseline_terminal_sha256=b.index['sources']['generic_chess/core/terminal.py']['sha256'],producer_sha256=sources,suite_sha256=hashlib.sha256(raw).hexdigest(),rows=[],complete=False)
start=time.perf_counter()
for i,case in enumerate(suite['cases']):
 s=d.root_from_fen(case['fen'],c)
 for j,policy in enumerate(d.POLICIES):
  for q in (0,2):
   for version in (('baseline','deferred') if (i+j+q//2)%2==0 else ('deferred','baseline')):
    stop_check();b.select(version);limits,tuning=config(q)
    a,row=d.search_move(s,c,policy,limits,provider=provider,ordering=True,use_tt=True,dynamic='cached_legacy',tuning=tuning)
    row.update(case_id=case['id'],qdepth=q,version=version,limits=asdict(limits),tuning=asdict(tuning),answer_hit=row['move'] in case['accepted_uci']);report['rows'].append(row);d.write_record(out,report)
 print('curve',case['id'],len(report['rows']),flush=True)
report.update(wall_seconds=time.perf_counter()-start,complete=True);d.write_record(out,report)
b.select('deferred')
out=ROOT/'.local_agent/chess_runtime_cost_games_20261006.json';assert not out.exists()
fen='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
enginepath=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
report=dict(scope='Twelve newly declared deferred-terminal real playing cells:3prices2colorsq0/q2, both ordered/PVS/TT/cachedlegacy; max120plies; no Elo/isolated q or price cause. Old stochastic games are contextual evidence, not paired causal baseline.',question='Does practical player remain useful after equivalent terminal cost repair; retain all failures?',cost='Same5sec32768node4ply per move; max60minutes local, interruptible each move, no outcome-driven extension',producer_sha256=sources,profiles={str(q):{'limits':asdict(config(q)[0]),'tuning':asdict(config(q)[1])} for q in (0,2)},opponent=dict(binary_sha256=hashlib.sha256(enginepath.read_bytes()).hexdigest(),threads=1,hash_mib=16,configured_elo=1320,nodes=50000,seconds_fuse=1),max_plies=120,games=[],complete=False)
start=time.perf_counter();d.write_record(out,report)
with chess.engine.SimpleEngine.popen_uci(str(enginepath),timeout=10) as engine:
 engine.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':True,'UCI_Elo':1320})
 for policy in d.POLICIES:
  for color in (0,1):
   white,black=(policy,'uci_reference') if color==0 else ('uci_reference',policy)
   for q in (0,2):
    stop_check();limits,tuning=config(q);external=d.UciOpponent(engine,fen,50000)
    def save(game):
     report['active_game']=dict(policy=policy,color=color,qdepth=q,**game);d.write_record(out,report);stop_check()
     if len(game['moves'])%10==0:print('progress',policy,color,q,len(game['moves']),flush=True)
    game=d.play_game(fen,c,white,black,limits,120,save,provider=provider,ordering=True,use_tt=True,dynamic='cached_legacy',external=external,tuning=tuning)
    report.pop('active_game',None);report['games'].append(dict(qdepth=q,**game));d.write_record(out,report)
    print('game',policy,color,q,game['end'],game['winner'],game['plies_played'],'partial',game['incomplete_searches'],flush=True)
report.update(wall_seconds=time.perf_counter()-start,complete=True);d.write_record(out,report)
