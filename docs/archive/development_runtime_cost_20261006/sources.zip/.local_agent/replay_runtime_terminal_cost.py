"""Every existing played path: immutable, new runtime and exact old terminal."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent'))
import runtime_cost_baseline as b
import scripts.chess_development as d
from generic_chess.core.search_runtime import SearchPathRuntime
out=ROOT/'.local_agent/chess_runtime_terminal_replay_20261006.json';assert not out.exists()
inp=ROOT/'.local_agent/chess_qcapture_games_20261006.json';raw=inp.read_bytes();games=json.loads(raw);assert games['complete']
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
report=dict(scope='All1115 actual old played transitions, unchanged full history and terminal precedence; no strength inference',input_sha256=hashlib.sha256(raw).hexdigest(),baseline_sha256=b.index['sources']['generic_chess/core/terminal.py']['sha256'],current_sha256=hashlib.sha256((ROOT/'generic_chess/core/terminal.py').read_bytes()).hexdigest(),games=[],errors=[],complete=False)
for i,g in enumerate(games['games']):
    s=d.root_from_fen(g['initial_fen'],c);runtime=SearchPathRuntime.from_state(s,c)
    for r in g['moves']:
        a=next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==r['move'])
        s=d.apply_action(s,a,c);runtime.push(a)
        old=b.baseline(runtime)
        if (old.status.value,old.winner)!=(runtime.terminal_status.status.value,runtime.terminal_status.winner):report['errors'].append(dict(game=i,ply=r['ply'],kind='baseline_terminal'))
        assert runtime.position==s.position and runtime.ply_count==s.ply_count
        assert runtime.terminal_status==s.terminal_status
        assert runtime.history[-1].gave_check==s.history[-1].gave_check
    assert d.record_value(s)==g['final_state']
    for _ in g['moves']:runtime.pop()
    runtime.assert_balanced();report['games'].append(dict(index=i,plies=len(g['moves']),winner=g['winner'],end=g['end']));d.write_record(out,report)
report.update(complete=True,plies=sum(x['plies'] for x in report['games']));assert not report['errors'];d.write_record(out,report)
print('played terminal parity',report['plies'],'errors',len(report['errors']))
