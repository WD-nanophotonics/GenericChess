import json,urllib.request,zipfile,io,hashlib
from pathlib import Path
p=Path('.local_agent/mature-search'); r=json.loads((p/'fairy-revision.json').read_bytes()); sha=r['sha']
url=f'https://codeload.github.com/fairy-stockfish/Fairy-Stockfish/zip/{sha}'
raw=urllib.request.urlopen(url,timeout=40).read(20000000)
assert len(raw)<20000000
out=p/'fairy-source.zip';assert not out.exists();out.write_bytes(raw)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 for item in z.infolist():
  target=(p/item.filename).resolve();assert target.is_relative_to(p.resolve())
 z.extractall(p)
(p/'acquisition.json').write_text(json.dumps({'sha':sha,'url':url,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},indent=2))
print(sha,len(raw))
