"""Specific actual-history horizon control after prior complete mature suite."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-search';old=json.loads((ROOT/'.local_agent/chess_unit_early_bishop_control_20261006.json').read_bytes());probe=json.loads((p/'probe-results.json').read_bytes());assert probe['complete']
raw=(ROOT/'.local_agent/chess_qcapture_games_20261006.json').read_bytes();assert old['input_sha256']==hashlib.sha256(raw).hexdigest();g=next(g for g in json.loads(raw)['games'] if g['black']=='unit' and g['qdepth']==2)
report=dict(scope='Three fixed0.25sec mature material choices at exact actual ply7 history; finite same-root child proxies. Own q0PV ends Qxc3 before legal ordinary Queen recapture. Not proof of visited leaves, price fitting, certified regret or causal engine quality.',conditions=probe['conditions'],binary_sha256=probe['binary_sha256'],input_sha256=old['input_sha256'],rows=[],complete=False)
out=p/'actual-bishop-results.json';assert not out.exists();src=p/('Fairy-Stockfish-'+probe['revision'])/'src';binary=p/'build/fairy-material.exe'
for policy in d.POLICIES:
 Board=type('MaterialBoard',(chess.Board,),{'uci_variant':f'gc_{policy}'});board=Board(g['initial_fen'])
 for row in g['moves'][:7]:board.push_uci(row['move'])
 with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(p/'material-variants.ini')],cwd=src,timeout=15) as engine:
  engine.configure({'Threads':1,'Hash':16,'Use NNUE':False});started=time.perf_counter();info=engine.analyse(board,chess.engine.Limit(time=.25),game=object());move=info['pv'][0].uci();assert move in {m.uci() for m in board.legal_moves}
  report['rows'].append(dict(policy=policy,move=move,depth=info.get('depth'),nodes=info.get('nodes'),wall_seconds=time.perf_counter()-started,pv=[m.uci() for m in info.get('pv',())]));d.write_record(out,report)
references=dict(old['references']);path=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe';assert hashlib.sha256(path.read_bytes()).hexdigest()==old['reference_conditions']['binary_sha256']
with chess.engine.SimpleEngine.popen_uci(str(path),timeout=10) as engine:
 engine.configure({'Threads':1,'Hash':16})
 for move in sorted({r['move'] for r in report['rows']}-set(references)):
  child=board.copy(stack=True);child.push_uci(move);info=engine.analyse(child,chess.engine.Limit(nodes=50000),game=object());v=info['score'].pov(board.turn);references[move]=dict(cp=v.score(),mate=v.mate(),pv=[m.uci() for m in info.get('pv',())])
report.update(complete=True,references=references,reference_conditions=old['reference_conditions']);d.write_record(out,report);print(report['rows']);print({r['move']:references[r['move']] for r in report['rows']})
