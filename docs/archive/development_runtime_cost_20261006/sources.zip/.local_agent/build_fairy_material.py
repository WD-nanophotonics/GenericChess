"""Single-process optional mature-search feasibility; pinned source, no install."""
import pathlib,json,re,subprocess,sys,time,hashlib,difflib,os
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=ROOT/'.local_agent/mature-search'; revision=json.loads((p/'fairy-revision.json').read_bytes())['sha']
src=p/f'Fairy-Stockfish-{revision}'/'src'; out=p/'build';out.mkdir(exist_ok=True)
target=src/'evaluate.cpp'; original=target.read_text()
hook='''
#ifdef GENERICCHESS_MATERIAL_DEVELOPMENT
  // Standard-Chess development only: material leaf without positional terms.
  // CapturePieceValue follows variant config; other search thresholds do not.
  int material = 0;
  for (PieceType pt : {PAWN, KNIGHT, BISHOP, ROOK, QUEEN})
      material += EvalPieceValue[MG][pt] * (pos.count(WHITE, pt) - pos.count(BLACK, pt));
  if (pos.side_to_move() == BLACK) material = -material;
  return Value(std::clamp(material, int(VALUE_TB_LOSS_IN_MAX_PLY + 1), int(VALUE_TB_WIN_IN_MAX_PLY - 1)));
#endif
'''
anchor='Value Eval::evaluate(const Position& pos) {'
assert original.count(anchor)==1 and 'GENERICCHESS_MATERIAL_DEVELOPMENT' not in original
patched=original.replace(anchor,anchor+hook);target.write_text(patched)
(p/'material.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),patched.splitlines(True),fromfile='a/src/evaluate.cpp',tofile='b/src/evaluate.cpp')))
make=(src/'Makefile').read_text();sources=re.search(r'SRCS = (.*?)\n\nOBJS',make,re.S).group(1).replace('\\\n',' ').split()
base=[sys.executable,'-m','ziglang','c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-fno-exceptions','-fno-strict-aliasing','-DNDEBUG','-DIS_64BIT','-DNNUE_EMBEDDING_OFF','-DGENERICCHESS_MATERIAL_DEVELOPMENT']
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(p/'zig-global-cache'),ZIG_LOCAL_CACHE_DIR=str(p/'zig-local-cache'))
report={'scope':'Sequential bounded source-build feasibility, no playing-strength claim','revision':revision,'sources':sources,'commands':[],'complete':False,'started_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()}
start=time.perf_counter()
for source in sources:
 for name in ('rollout','advisor','slack'):
  flags=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if flags.get('user_paused') or flags.get('stopped'):raise SystemExit('User stop retained')
 obj=out/(source.replace('/','_')+'.o');cmd=base+['-c',str(src/source),'-o',str(obj)]
 try:result=subprocess.run(cmd,cwd=src,capture_output=True,text=True,timeout=90,env=env)
 except subprocess.TimeoutExpired as error:
  report['commands'].append({'source':source,'command':cmd[3:],'timeout_seconds':90,'stdout':str(error.stdout),'stderr':str(error.stderr)})
  report['stopped']='Actual compiler timeout';break
 report['commands'].append({'source':source,'command':cmd[3:],'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
 (p/'build-report.json').write_text(json.dumps(report,indent=2))
 print(source,result.returncode,flush=True)
 if result.returncode:break
 if time.perf_counter()-start>240:
  report['stopped']='Four-minute cost checkpoint: preserve objects; resume only for concrete build decision';break
else:
 binary=out/'fairy-material.exe';cmd=base+[str(out/(s.replace('/','_')+'.o')) for s in sources]+['-o',str(binary),'-lpthread','-ladvapi32','-Wl,--stack,8388608']
 result=subprocess.run(cmd,cwd=src,capture_output=True,text=True,timeout=90,env=env)
 report['link']={'exit_code':result.returncode,'stderr':result.stderr,'stdout':result.stdout}
 if not result.returncode:report.update(complete=True,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
report['wall_seconds']=time.perf_counter()-start;(p/'build-report.json').write_text(json.dumps(report,indent=2))
print('complete',report['complete'],report['wall_seconds'],flush=True)
