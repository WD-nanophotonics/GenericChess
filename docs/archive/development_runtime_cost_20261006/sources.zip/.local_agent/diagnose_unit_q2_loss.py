"""Preselected ten Black roots of prior61ply loss; exact actual history."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
out=ROOT/'.local_agent/chess_runtime_unit_loss_reference_20261006.json';assert not out.exists()
raw=(ROOT/'.local_agent/chess_qcapture_games_20261006.json').read_bytes();data=json.loads(raw)
game=next(g for g in data['games'] if g['qdepth']==2 and g['black']=='unit');assert game['winner']==0 and len(game['moves'])==61
points=(9,17,25,33,41,49,53,55,57,59)
enginepath=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());s=d.root_from_fen(game['initial_fen'],c);author=d.UciOpponent(None,game['initial_fen'],1)
report=dict(scope='Ten preselected actual Black roots, fixed50000node root/best/selected children with full actual history. Finite standard-Chess proxies, not certified regret or training labels.',points=points,input_sha256=hashlib.sha256(raw).hexdigest(),binary_sha256=hashlib.sha256(enginepath.read_bytes()).hexdigest(),conditions=dict(threads=1,hash_mib=16,nodes_per_call=50000,fresh_game_each_call=True),rows=[],complete=False)
with chess.engine.SimpleEngine.popen_uci(str(enginepath),timeout=10) as engine:
 engine.configure({'Threads':1,'Hash':16})
 for original in game['moves']:
  if original['ply'] in points:
   board=author.board.copy(stack=True);info=engine.analyse(board,chess.engine.Limit(nodes=50000),game=object());best=info['pv'][0].uci();refs={}
   for move in sorted({best,original['move']}):
    child=board.copy(stack=True);child.push_uci(move)
    actual=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==move),c);align=d.UciOpponent(None,game['initial_fen'],1)
    for m in board.move_stack:align.board.push(m)
    align.push(move,actual)
    analysis=engine.analyse(child,chess.engine.Limit(nodes=50000),game=object());score=analysis['score'].pov(board.turn)
    refs[move]=dict(cp=score.score(),mate=score.mate(),nodes=analysis.get('nodes'),pv=[m.uci() for m in analysis.get('pv',())])
   r=dict(ply=original['ply'],selected=original['move'],root_best=best,local_depth=original['statistics']['completed_depth'],local_reason=original['reason'],fen=board.fen(),references=refs);report['rows'].append(r);d.write_record(out,report)
   print(r['ply'],r['selected'],refs[r['selected']],best,refs[best],flush=True)
  a=next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==original['move']);s=d.apply_action(s,a,c);author.push(original['move'],s)
report['complete']=True;d.write_record(out,report)
