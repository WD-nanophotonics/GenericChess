"""Next-step six declared mature material playing cells using existing UCI transport."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-search';binary=p/'build/fairy-material.exe';config=p/'material-variants.ini'
src=p/('Fairy-Stockfish-'+json.loads((p/'fairy-revision.json').read_bytes())['sha'])/'src'
probe=json.loads((p/'probe-results.json').read_bytes());assert probe['complete'] and len(probe['rows'])==72
out=p/'playing-results.json';assert not out.exists()
opponent=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
report=dict(scope='Six predeclared standard-Chess mature pure-material cells3prices2colors,120ply cap. Fixed mature search/old SEE,0.25sec local, weak1320 Stockfish17.1 reference50000nodes/1secfuse. Descriptive development; not same-wall cross-engine causal comparison, Elo, holdout or price fitting.',conditions=probe['conditions'],binary_sha256=probe['binary_sha256'],opponent_sha256=hashlib.sha256(opponent.read_bytes()).hexdigest(),games=[],complete=False)
fen=chess.STARTING_FEN;c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());started=time.perf_counter()
recording={'seconds':0.0,'writes':0,'serialized_bytes':0}
def persist():
 before=time.perf_counter();d.write_record(out,report)
 recording['seconds']+=time.perf_counter()-before;recording['writes']+=1;recording['serialized_bytes']+=out.stat().st_size
def stopped():
 for name in ('rollout','advisor','slack'):
  flags=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if flags.get('user_paused') or flags.get('stopped'):raise SystemExit('User stop retained')
for policy in d.POLICIES:
 for color in (0,1):
  stopped()
  with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],cwd=src,timeout=15) as local_engine,chess.engine.SimpleEngine.popen_uci(str(opponent),timeout=15) as other_engine:
   local_engine.configure({'Threads':1,'Hash':16,'Use NNUE':False});other_engine.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':True,'UCI_Elo':1320})
   local=d.UciOpponent(local_engine,fen,1);local.board=type('MaterialBoard',(chess.Board,),{'uci_variant':f'gc_{policy}'})(fen);local.limit=chess.engine.Limit(time=.25)
   other=d.UciOpponent(other_engine,fen,50000);s=d.root_from_fen(fen,c)
   game=dict(initial_fen=fen,policy=policy,color=color,white=policy if color==0 else 'uci_reference',black=policy if color==1 else 'uci_reference',moves=[],qdepth=None,complete=False)
   report['active_game']=game;persist()
   for ply in range(120):
    stopped()
    if s.terminal_status.is_terminal:break
    legal={d.uci(a):a for a in d.iter_legal_actions(s,c)};assert set(legal)=={m.uci() for m in other.board.legal_moves}
    actor=s.position.side_to_move;player=local if actor==color else other;move,row=player.choose();assert move in legal
    row.update(ply=ply,actor=actor,policy=policy if actor==color else 'uci_reference',legal=True)
    s=d.apply_action(s,legal[move],c);local.push(move,s);other.push(move,s);game['moves'].append(row);persist()
   game.update(complete=True,plies_played=len(game['moves']),end=s.terminal_status.status.value if s.terminal_status.is_terminal else 'ply_limit',winner=s.terminal_status.winner,final_state=d.record_value(s))
   report.pop('active_game');report['games'].append(game);persist();print(policy,color,game['end'],game['winner'],game['plies_played'],flush=True)
report.update(complete=True,wall_seconds=time.perf_counter()-started,recording_cost=dict(recording,scope='Measured initial/per-action/completed-game writes; final summary write excluded'));d.write_record(out,report)
