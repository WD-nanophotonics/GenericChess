"""Actual Core forward chain controls source closure including terminal zero.
No full legal-position reachability, source-frequency, price or strength claim.
"""
from pathlib import Path
from dataclasses import replace
import sys,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from tests.product.test_semantic_empty_guards import guarded_leap
from generic_chess.rules.schema import RuleGeometrySpec
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.pieces import Piece
from scripts.research_record import write_record
base=guarded_leap(())
definition=replace(base,semantic_actions=tuple(replace(a,geometry=RuleGeometrySpec('leap',offset=(0,1))) for a in base.semantic_actions))
c=compile_ruleset_for_execution(definition);e=SemanticEngine(c);template=e._initial_position()
controls=[]
for owner in (0,1):
 graph={}
 for s in range(15):
  board=[None]*15;board[s]=Piece(owner,'H','H')
  pos=replace(template,board=tuple(board),side_to_move=owner)
  actions=e.legal_actions(pos);graph[s]={a.target for a in actions}
  want={s+(5 if owner==0 else -5)} if (s//5<2 if owner==0 else s//5>0) else set()
  assert graph[s]==want
 def closure(seeds):
  seen=set(seeds);pending=list(seen)
  while pending:
   for t in graph[pending.pop()]-seen:seen.add(t);pending.append(t)
  return seen
 origin=0 if owner==0 else 14;middle=origin+(5 if owner==0 else -5);last=middle+(5 if owner==0 else -5)
 for seeds in ((origin,),(origin,middle),(origin,origin)):
  reach=closure(seeds);assert reach=={origin,middle,last}
  mean=sum(len(graph[s]) for s in reach)/len(reach);assert mean==2/3
  controls.append(dict(owner=owner,seeds=seeds,forward_closure=sorted(reach),terminal=last,uniform_source_empty_count=mean,nonzero_filtered_mean=1))
 # Actual sequential effects, not merely a projected graph.
 board=[None]*15;board[origin]=Piece(owner,'H','H');pos=replace(template,board=tuple(board),side_to_move=owner)
 for s,t in ((origin,middle),(middle,last)):
  # Dedicated single-actor graph task keeps actor turn; not a two-player match.
  pos=replace(pos,side_to_move=owner)
  action=next(a for a in e.legal_actions(pos) if a.source==s and a.target==t)
  child=e.apply(pos,action);assert child.board[t]==Piece(owner,'H','H') and child.board[s] is None;pos=child
 assert not e.legal_actions(replace(pos,side_to_move=owner))
write_record(root/'.local_agent/guard-projection-20261009/forward-source-control.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),core_source_positions=30,actual_transitions=4,closure_controls=controls))
print(dict(core_positions=30,actual_transitions=4,closures=len(controls)))
