"""Inverse zone membership: matched Core eligibility/work and local descriptive cost.
No Native, search-strength or cross-machine performance claim.
"""
from pathlib import Path
import sys,inspect,textwrap,hashlib,time,statistics
root=Path.cwd();sys.path[:0]=[str(root)]
import generic_chess.core.semantic_executor as module
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from scripts.research_record import write_record
start=time.perf_counter();old=SemanticEngine._guards_hold
original=textwrap.dedent(inspect.getsource(old));replacement=original.replace('''        zone_squares = tuple(
            (shape.height - 1 - index // shape.width) * shape.width
            + (shape.width - 1 - index % shape.width)
            for index in zone.squares
        )''','''        square_idx = shape.area - 1 - square_idx''')
assert replacement!=original
ns=dict(module.__dict__);exec(compile(replacement,'<inverse_zone_candidate>','exec'),ns);new=ns['_guards_hold']
c=compile_ruleset_for_execution(build_xiangqi_diagnostic_ruleset());e=SemanticEngine(c);pos=e._initial_position();positions=[pos]
for _ in range(5):
 actions=e.legal_actions(pos);pos=e.apply(pos,sorted(actions,key=str)[0]);positions.append(pos)
rows=[]
try:
 for i,pos in enumerate(positions):
  signatures=[];times={'old':[],'inverse':[]}
  for repeat in range(8):
   for name,fn in (('old',old),('inverse',new)) if repeat%2==0 else (('inverse',new),('old',old)):
    SemanticEngine._guards_hold=fn;engine=SemanticEngine(c);checkpoints=[0]
    def checkpoint():checkpoints[0]+=1
    tick=time.perf_counter();actions=engine.legal_actions(pos,checkpoint=checkpoint);elapsed=time.perf_counter()-tick
    signature=(tuple(actions),tuple(sorted(engine.attacked_squares(pos,0))),tuple(sorted(engine.attacked_squares(pos,1))),checkpoints[0])
    if signatures:assert signature==signatures[0]
    signatures.append(signature);times[name].append(elapsed)
  children=[]
  for fn in (old,new):
   SemanticEngine._guards_hold=fn;engine=SemanticEngine(c)
   children.append(tuple(engine.apply(pos,a) for a in engine.legal_actions(pos)))
  assert children[0]==children[1]
  rows.append(dict(ply=i,side=pos.side_to_move,legal_count=len(signatures[0][0]),checkpoint_count=signatures[0][3],times=times,median_ratio=statistics.median(times['inverse'])/statistics.median(times['old']),child_transitions=len(children[0])*2))
finally:SemanticEngine._guards_hold=old
write_record(root/'.local_agent/guard-projection-20261009/zone-execution-cost.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),original_method_sha256=hashlib.sha256(original.encode()).hexdigest(),candidate_method_sha256=hashlib.sha256(replacement.encode()).hexdigest(),declaration='6actual lexical-route Core positions;8alternating legal-list pairs each; fixed checkpoint counts, both attack sets and all child transitions. No search or Native.',rows=rows,seconds=time.perf_counter()-start))
print(dict(rows=[{k:v for k,v in r.items() if k!='times'} for r in rows],seconds=time.perf_counter()-start))
