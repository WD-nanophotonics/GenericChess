"""Source-law sensitivity on fixed internal Xiangqi movement graphs.
No material selection; initial reach is a placement-dependent diagnostic.
Graph ignores blockers, hands, captures changing actor, anchor safety and history.
"""
from pathlib import Path
from collections import Counter
import sys,hashlib,time,json
root=Path.cwd();sys.path[:0]=[str(root)]
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from scripts.research_record import write_record
start=time.perf_counter();definition=build_xiangqi_diagnostic_ruleset()
def neighbors(t,s,owner):
 f,r=s%9,s//9;rr=r if owner==0 else 9-r
 directions={'G':[(1,0),(-1,0),(0,1),(0,-1)],'A':[(1,1),(1,-1),(-1,1),(-1,-1)],'E':[(2,2),(2,-2),(-2,2),(-2,-2)],'H':[(2,1),(2,-1),(-2,1),(-2,-1),(1,2),(1,-2),(-1,2),(-1,-2)],'S':[(0,1 if owner==0 else -1)]+([(1,0),(-1,0)] if rr>=5 else [])}
 if t in ('R','C'):
  return {y*9+x for x in range(9) for y in range(10) if (x==f or y==r) and (x,y)!=(f,r)}
 out=set()
 for df,dr in directions[t]:
  x,y=f+df,r+dr;yy=y if owner==0 else 9-y
  if not(0<=x<9 and 0<=y<10):continue
  if t in ('G','A') and not(3<=f<=5 and rr<3 and 3<=x<=5 and yy<3):continue
  if t=='E' and not(rr<5 and yy<5):continue
  out.add(y*9+x)
 return out

def reachable(graph,seeds):
 found=set(seeds);pending=list(found)
 while pending:
  for nxt in graph[pending.pop()]-found:found.add(nxt);pending.append(nxt)
 return found

def components(graph,domain):
 remaining=set(domain);out=[]
 while remaining:
  s=min(remaining);forward=reachable(graph,{s});reverse={x:{i for i,adj in graph.items() if x in adj} for x in graph}
  group=forward & reachable(reverse,{s});out.append(sorted(group));remaining-=group
 return out

def mean(graph,domain):return sum(len(graph[s]) for s in domain)/len(domain) if domain else 0
results={}
for t in ('G','A','E','H','R','C','S'):
 owners=[]
 for owner in (0,1):
  graph={s:neighbors(t,s,owner) for s in range(90)}
  initial={r*9+f for r,row in enumerate(definition.initial_position) for f,p in enumerate(row) if p is not None and p.owner==owner and p.type_id==t}
  reach=reachable(graph,initial)
  supported={s for s,adj in graph.items() if adj} | set().union(*graph.values())
  comps=components(graph,supported)
  records=[dict(squares=c,size=len(c),mean_empty_degree=mean(graph,c),initial_intersection=sorted(initial&set(c))) for c in comps]
  owners.append(dict(owner=owner,initial=sorted(initial),reachable=sorted(reach),supported=sorted(supported),all_board_mean_degree=mean(graph,range(90)),supported_mean_degree=mean(graph,supported),initial_reach_mean_degree=mean(graph,reach),components=records))
 # Rotation equivalence of directed graph, not just aggregate values.
 assert all({89-n for n in neighbors(t,s,0)}==neighbors(t,89-s,1) for s in range(90))
 results[t]=owners
# Check known restricted pieces and one-way soldier graph explicitly.
assert len(results['G'][0]['reachable'])==9
assert len(results['A'][0]['reachable'])==5
assert len(results['E'][0]['reachable'])==7
assert len(results['S'][0]['reachable'])==55
assert sorted(c['size'] for c in results['A'][0]['components'])==[4,5]
assert all(set(c['squares']).issubset(set(results['S'][0]['supported'])) for c in results['S'][0]['components'])
write_record(root/'.local_agent/guard-projection-20261009/source-components.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),definitions='existing internal Xiangqi rule builder; no human holdout',results=results,seconds=time.perf_counter()-start))
print({t:{'support':len(v[0]['supported']),'initial_reach':len(v[0]['reachable']),'components':dict(Counter(c['size'] for c in v[0]['components'])),'degrees':(v[0]['all_board_mean_degree'],v[0]['supported_mean_degree'],v[0]['initial_reach_mean_degree'])} for t,v in results.items()})
