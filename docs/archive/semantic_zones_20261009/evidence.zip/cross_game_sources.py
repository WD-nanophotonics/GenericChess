"""Conditional source-law diagnostics on existing projection edges.
Uniform forward closure from initial on-board actors, separately for each owner.
This restricted graph omits excluded effects, transformations, drops, safety and
history. Not full game reachability, occupancy frequency or new material prices.
"""
from pathlib import Path
import sys,hashlib,time,types
root=Path.cwd();sys.path[:0]=[str(root)]
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation import semantic
from scripts.research_record import write_record
start=time.perf_counter();source=Path(semantic.__file__).read_text()
# Instrument the qualified product producer locally; unchanged event logic.
source=source.replace('    curves = []','    global observed_edges\n    observed_edges = edges\n    curves = []')
mod=types.ModuleType('generic_chess.ai.evaluation.source_diagnostic');mod.__package__='generic_chess.ai.evaluation'
exec(compile(source,'<source_diagnostic>','exec'),mod.__dict__)
config=EvaluationConfig(density_points=(0.,.125,.5,.875,1.),density_weights=(.2,)*5)
def closure(graph,seeds):
 seen=set(seeds);pending=list(seen)
 while pending:
  for t in graph[pending.pop()]-seen:seen.add(t);pending.append(t)
 return seen
results={}
for game,builder in [('Chess',build_western_chess_ruleset),('Shogi',build_standard_shogi_ruleset),('Xiangqi-internal',build_xiangqi_diagnostic_ruleset)]:
 definition=builder();compiled=compile_ruleset_for_execution(definition);area=compiled.board_shape.area
 rows={}
 for pt in definition.piece_types:
  tid=pt.type_id;row=mod.semantic_opportunity(compiled,tid,config);edges=mod.observed_edges;owners=[]
  for owner in (0,1):
   graph={s:{t for kind in edges for t,events in edges[kind][owner*area+s].items() if mod._path_union(events,.5)>0} for s in range(area)}
   initial={r*compiled.board_shape.width+f for r,line in enumerate(definition.initial_position) for f,p in enumerate(line) if p is not None and p.owner==owner and p.current_type_id==tid}
   reach=closure(graph,initial)
   curves=[]
   for d in config.density_points:
    quiet=sum(mod._path_union(events,d)*(1-d) for s in reach for events in edges['target_empty'][owner*area+s].values())/len(reach) if reach else None
    capture=sum(mod._path_union(events,d)*d/2 for s in reach for events in edges['target_enemy'][owner*area+s].values())/len(reach) if reach else None
    curves.append(dict(density=d,quiet=quiet,capture=capture,total=quiet+capture if reach else None))
   owners.append(dict(owner=owner,initial=sorted(initial),forward_closure=sorted(reach),terminal_zero_sources=sorted(s for s in reach if not graph[s]),curves=curves,raw=sum(w*c['total'] for w,c in zip(config.density_weights,curves)) if reach else None))
   # Retain terminal zeros and invariance under adding duplicate initial seeds.
   assert reach==closure(graph,list(initial)*2)
  rows[tid]=dict(all_board=row,owners=owners,initial_conditioned_raw=sum(o['raw'] for o in owners)/2 if all(o['raw'] is not None for o in owners) else None,is_anchor=pt.is_anchor)
 results[game]=dict(area=area,rows=rows)
write_record(root/'.local_agent/guard-projection-20261009/cross-game-sources.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),product_sha256=hashlib.sha256(Path(semantic.__file__).read_bytes()).hexdigest(),results=results,seconds=time.perf_counter()-start))
print({g:{t:dict(all=round(r['all_board']['raw'],6),conditioned=round(r['initial_conditioned_raw'],6) if r['initial_conditioned_raw'] is not None else None,reach=[len(o['forward_closure']) for o in r['owners']],zeros=[len(o['terminal_zero_sources']) for o in r['owners']],included=len(r['all_board']['included']),excluded=len(r['all_board']['excluded'])) for t,r in v['rows'].items()} for g,v in results.items()})
