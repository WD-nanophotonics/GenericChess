"""Positive-support closure loses prerequisite likelihood.
Fixed rule-only graph diagnostic, not a natural source law or material claim.
Uniform independent occupancy at density .5; initial actor at(0,0).
"""
from pathlib import Path
from dataclasses import replace
import sys,time,types,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import _king_type
from generic_chess.rules.schema import RuleSet,RuleSemanticAction,RuleGeometrySpec,RuleActionEffect,RuleSquareRef,RuleStateGuard,RuleSpatialSelector,RuleTypeRef,RuleSquareZoneGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.evaluation import semantic
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
start=time.perf_counter();source=Path(semantic.__file__).read_text().replace('    curves = []','    global observed_edges\n    observed_edges = edges\n    curves = []')
m=types.ModuleType('generic_chess.ai.evaluation.bridge_diagnostic');m.__package__='generic_chess.ai.evaluation';exec(compile(source,'<bridge_diagnostic>','exec'),m.__dict__)
A=((0,0),(0,1),(0,2));B=tuple((f,r) for f in range(1,5) for r in range(5));leg_cells=[i for i in range(25) if i not in (10,11)]
def zone(kind,cells):return RuleSquareZoneGuard(RuleSquareRef(kind),RuleSpatialSelector('zone',zone_squares=cells),owner_relative=False)
def guard(cell):
 ref=RuleSquareRef('offset_from_source',offset=(cell%5,cell//5-2),owner_relative=False)
 return RuleStateGuard('count','any',RuleTypeRef('any'),'base','any','board',RuleSpatialSelector('exact',refs=(ref,)),comparison='eq',value=0)
def definition(k):
 actions=[]
 families=[('chain',(0,1),(zone('source',A),zone('target',A)),())]+[(f'region{i}',off,(zone('source',B),zone('target',B)),()) for i,off in enumerate(((1,0),(-1,0),(0,1),(0,-1)))]+[('bridge',(1,0),(zone('source',((0,2),)),zone('target',B)),(guard(10),) if k is None else tuple(guard(i) for i in leg_cells[:k]))]
 for name,off,zones,guards in families:
  for relation in ('empty','enemy'):
   effects=() if relation=='empty' else (RuleActionEffect('remove',square_ref=RuleSquareRef('target'),piece_owner='opponent'),)
   actions.append(RuleSemanticAction(name=name+relation,type_ids=('X',),geometry=RuleGeometrySpec('leap',offset=off,owner_relative=False),target_relation=relation,composition='augment',state_guards=guards,square_zone_guards=zones,effects=effects+(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),)))
 board=[None]*25;board[0]=Piece(0,'X','X');board[20]=Piece(0,'K','K');board[24]=Piece(1,'K','K')
 return RuleSet(board_size=5,piece_types=(_king_type(),PieceType('X','X',()),PieceType('Z','Z',())),initial_position=tuple(tuple(board[r*5:r*5+5]) for r in range(5)),drop_allowed={'X':((False,)*25,)*2,'Z':((False,)*25,)*2},semantic_actions=tuple(actions))
def closure(graph,seeds):
 seen=set(seeds);todo=list(seen)
 while todo:
  for t in graph[todo.pop()]-seen:seen.add(t);todo.append(t)
 return seen
rows=[];positions=0
for k in (None,0,4,8,12,16):
 c=compile_ruleset_for_execution(definition(k));e=SemanticEngine(c);template=e._initial_position();row=m.semantic_opportunity(c,'X',EvaluationConfig(density_points=(.5,),density_weights=(1.,)));edges=m.observed_edges
 graph={s:{t for kind in edges for t,events in edges[kind][s].items() if m._path_union(events,.5)>0} for s in range(25)}
 reach=closure(graph,{0});assert len(reach)==(3 if k is None else 23)
 raw=sum(m._path_union(events,.5)*(.5 if kind=='target_empty' else .25) for s in reach for kind in edges for events in edges[kind][s].values())/len(reach)
 # Actual Core bridge availability with every individual prerequisite occupied.
 for blocker in [None]+([] if k is None else leg_cells[:k]):
  for endpoint in (None,0,1):
   board=[None]*25;board[10]=Piece(0,'X','X')
   if blocker is not None:board[blocker]=Piece(1,'Z','Z')
   if endpoint is not None:board[11]=Piece(endpoint,'Z','Z')
   pos=replace(template,board=tuple(board),side_to_move=0)
   action=[a for a in e.legal_actions(pos) if a.source==10 and a.target==11]
   assert bool(action)==(k is not None and blocker is None and endpoint!=0)
   for a in action:
    child=e.apply(pos,a);assert child.board[11]==Piece(0,'X','X') and child.board[10] is None
   positions+=1
 probability=0 if k is None else .5**k
 rows.append(dict(guards=k,bridge_prerequisite_probability=probability,forward_closure=sorted(reach),all_board_raw=row['raw'],uniform_closure_raw=raw))
base=rows[0]
for r in rows[1:]:
 assert abs(r['all_board_raw']-base['all_board_raw']-.75*r['bridge_prerequisite_probability']/25)<1e-12
write_record(root/'.local_agent/guard-projection-20261009/rare-bridge.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),product_sha256=hashlib.sha256(Path(semantic.__file__).read_bytes()).hexdigest(),core_positions=positions,rows=rows,seconds=time.perf_counter()-start))
print(dict(positions=positions,rows=[{k:v for k,v in r.items() if k!='forward_closure'}|{'reach':len(r['forward_closure'])} for r in rows],seconds=time.perf_counter()-start))
