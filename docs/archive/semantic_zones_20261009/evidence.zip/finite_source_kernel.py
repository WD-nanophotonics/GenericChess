"""Finite-horizon source control under an explicit proposal/stay kernel.
No natural occupancy, opponent policy, full-game reachability or material claim.
"""
from pathlib import Path
import hashlib,time
root=Path.cwd();folder=root/'.local_agent/guard-projection-20261009'
# Reuse only the frozen fixture definitions; do not execute its measurements.
base=folder/'rare_bridge.py'
namespace={'__file__':str(base)}
exec(compile(base.read_text().split('rows=[];positions=0')[0],str(base),'exec'),namespace)
m=namespace['m'];compile_rule=namespace['compile_ruleset_for_execution']
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
start=time.perf_counter();rows=[]
for k in (None,0,4,8,12,16):
 c=compile_rule(namespace['definition'](k))
 m.semantic_opportunity(c,'X',EvaluationConfig(density_points=(.5,),density_weights=(1.,)))
 edges=m.observed_edges;matrix=[[0.]*25 for _ in range(25)];reward=[]
 for source in range(25):
  opportunity=0.
  for kind in edges:
   for target,events in edges[kind][source].items():
    value=m._path_union(events,.5)*(.5 if kind=='target_empty' else .25)
    opportunity+=value
    # Propose uniformly among all24other squares; accept this declared event.
    matrix[source][target]+=value/24
  matrix[source][source]=1-sum(matrix[source])
  assert matrix[source][source]>=0 and abs(sum(matrix[source])-1)<1e-12
  reward.append(opportunity)
 distribution=[1.]+[0.]*24;total=0.;records=[]
 aggregate=[1.,0.,0.,0.];q=1/32;b=(0 if k is None else .5**k)/32
 for horizon in range(1,257):
  assert abs(sum(distribution[i] for i in range(25) if i%5)-aggregate[3])<1e-12
  assert all(abs(distribution[i]-aggregate[j])<1e-12 for j,i in enumerate((0,5,10))), (k,horizon,distribution,aggregate,matrix[0],matrix[5],matrix[10])
  total+=sum(p*r for p,r in zip(distribution,reward))
  if horizon in (1,2,8,32,128,256):
   records.append(dict(horizon=horizon,mean_opportunity=total/horizon,
      region_mass=sum(distribution[i] for i in range(25) if i%5),
      probability_mass=sum(distribution)))
  distribution=[sum(distribution[s]*matrix[s][t] for s in range(25)) for t in range(25)]
  a0,a1,a2,arrived=aggregate
  aggregate=[a0*(1-q),a1*(1-q)+a0*q,a2*(1-b)+a1*q,arrived+a2*b]
 rows.append(dict(guards=k,bridge_probability=0 if k is None else .5**k,records=records))
# Coupling: per-step rare bridge acceptance <= .75*p/24. Rewards bounded by3.
# Thus mean reward difference <= .75*p + 3*H*.75*p/24 (deliberately loose).
for row in rows[1:]:
 for baseline,record in zip(rows[0]['records'],row['records']):
  bound=.75*row['bridge_probability']*(1+3*record['horizon']/24)
  record['coupling_bound']=bound
  assert abs(record['mean_opportunity']-baseline['mean_opportunity'])<=bound+1e-12
  assert abs(record['probability_mass']-1)<1e-12
write_record(folder/'finite-source-kernel.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),product_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() if getattr(m,'__file__',None) else hashlib.sha256((root/'generic_chess/ai/evaluation/semantic.py').read_bytes()).hexdigest(),proposal='uniform24other cells, accept independent-occupancy event, otherwise stay; no opponent; rewards before transition',independent_aggregate_checks=1536,rows=rows,seconds=time.perf_counter()-start))
print([dict(guards=r['guards'],final=r['records'][-1]) for r in rows])
