"""Research-only finite source/target zone projection; no full legality or price claim."""
from pathlib import Path
from dataclasses import replace
import sys,time,hashlib,types
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation import semantic
from scripts.research_record import write_record
start=time.perf_counter()
# Private adaptation, exact source pinned. Product remains semantic-opportunity-v2.
source=Path(semantic.__file__).read_text()
source=source.replace('or pattern.slot_guards or pattern.square_zone_guards or pattern.postconditions',
'or pattern.slot_guards or any(g.square_ref.kind not in (\'source\', \'target\') or g.spatial.kind != \'zone\' or g.spatial.zone_id not in ir.zones for g in pattern.square_zone_guards) or pattern.postconditions')
source=source.replace('clear = _guard_empty_cells(pattern, shape, int(owner), source, target)',
'if not zone_holds(pattern, ir, shape, int(owner), source, target):\n                            continue\n                        clear = _guard_empty_cells(pattern, shape, int(owner), source, target)')
mod=types.ModuleType('generic_chess.ai.evaluation.zone_research');mod.__package__='generic_chess.ai.evaluation'
def zone_holds(pattern,ir,shape,owner,source,target):
 for g in pattern.square_zone_guards:
  square=source if g.square_ref.kind=='source' else target
  cells=ir.zones[g.spatial.zone_id].squares
  if g.owner_relative and owner==1:cells=tuple(shape.area-1-i for i in cells)
  if (square in cells)!=(g.relation=='inside'):return False
 return True
mod.zone_holds=zone_holds;exec(compile(source,'<private_zone_projection>','exec'),mod.__dict__)
definition=build_xiangqi_diagnostic_ruleset();mask=(False,)*90
# Inert blockers isolate each mover. Flying-general target-type guard stays excluded.
definition=replace(definition,piece_types=definition.piece_types+(PieceType('Z','Z',()),),drop_allowed={**definition.drop_allowed,'Z':(mask,mask)})
compiled=compile_ruleset_for_execution(definition);engine=SemanticEngine(compiled);template=engine._initial_position()
cfg=EvaluationConfig(density_points=(0.,.125,.5,.875,1.),density_weights=(.2,)*5)
rows={t:mod.semantic_opportunity(compiled,t,cfg) for t in ('G','A','E','H','R','C','S')}
old={t:semantic.semantic_opportunity(compiled,t,cfg) for t in rows}
counts={t:0 for t in ('G','A','E','S')};positions=0
for tid in counts:
 for owner in (0,1):
  for sourceidx in range(90):
   blockers=[None]+[i for i in range(90) if i!=sourceidx] if tid=='E' else [None]
   for blocker in blockers:
    board=[None]*90;board[sourceidx]=Piece(owner,tid,tid)
    if blocker is not None:board[blocker]=Piece(1-owner,'Z','Z')
    pos=replace(template,board=tuple(board),side_to_move=owner)
    actual=engine.attacked_squares(pos,owner)
    # Independent coordinate oracle, not compiled zones or geometry.
    f,r=sourceidx%9,sourceidx//9
    ownr=r if owner==0 else 9-r
    expected=set()
    offsets=((1,0),(-1,0),(0,1),(0,-1)) if tid=='G' else ((1,1),(1,-1),(-1,1),(-1,-1)) if tid=='A' else ((2,2),(2,-2),(-2,2),(-2,-2)) if tid=='E' else ((0,1 if owner==0 else -1),)+(((1,0),(-1,0)) if ownr>=5 else ())
    for df,dr in offsets:
     tf,tr=f+df,r+dr
     if not(0<=tf<9 and 0<=tr<10):continue
     target=tr*9+tf;owntr=tr if owner==0 else 9-tr
     if tid in ('G','A') and not(3<=f<=5 and ownr<3 and 3<=tf<=5 and owntr<3):continue
     if tid=='E' and not(ownr<5 and owntr<5 and blocker!=(r+dr//2)*9+f+df//2):continue
     expected.add(target)
    assert actual==expected,(tid,owner,sourceidx,blocker,actual,expected)
    positions+=1
    if blocker is None:counts[tid]+=len(expected)
for tid,n in counts.items():
 for curve in rows[tid]['curves']:
  d=curve['density'];leg=(1-d) if tid=='E' else 1
  assert abs(curve['quiet']-n/180*(1-d)*leg)<1e-12
  assert abs(curve['capture']-n/180*d/2*leg)<1e-12
# Equivalent zone membership encoded as complement/outside and no rotation after
# explicit separate owner pattern duplication is tested separately if needed.
complement=replace(definition,semantic_actions=tuple(replace(a,square_zone_guards=tuple(replace(g,relation='outside',spatial=replace(g.spatial,zone_squares=tuple((i%9,i//9) for i in range(90) if (i%9,i//9) not in g.spatial.zone_squares))) for g in a.square_zone_guards)) for a in definition.semantic_actions))
other=compile_ruleset_for_execution(complement)
for tid in rows:
 b=mod.semantic_opportunity(other,tid,cfg)
 assert rows[tid]['signature']==b['signature'] and rows[tid]['curves']==b['curves']
write_record(root/'.local_agent/guard-projection-20261009/zone-projection.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),base_product_sha256=hashlib.sha256(Path(semantic.__file__).read_bytes()).hexdigest(),core_positions=positions,empty_endpoint_sums=counts,rows=rows,v2_rows=old,complement_equivalent=True,seconds=time.perf_counter()-start))
print(dict(positions=positions,counts=counts,raw={t:(old[t]['raw'],rows[t]['raw']) for t in rows},included={t:len(rows[t]['included']) for t in rows},seconds=time.perf_counter()-start))
