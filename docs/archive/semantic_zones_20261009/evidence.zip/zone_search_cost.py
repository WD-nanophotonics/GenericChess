"""Frozen-condition public Core search comparison for inverse zone membership.
Supplied unit leaf/ordering table, not default rectangle prices or strength.
"""
from pathlib import Path
import sys,ast,subprocess,time,hashlib,statistics
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'tests/product')]
from test_rectangular_search_override import UnusedProfileCache
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
import generic_chess.core.semantic_executor as module
from generic_chess.core.movegen import legal_actions
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.profile import RuleSetEvaluationProfile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
start=time.perf_counter();definition=build_xiangqi_diagnostic_ruleset();c=compile_ruleset_for_execution(definition)
old_source=subprocess.check_output(['git','show','f5f91dff99db0256482d119fe5414ab7b557f4cd:generic_chess/core/semantic_executor.py'],text=True)
tree=ast.parse(old_source);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SemanticEngine');node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_guards_hold')
ns=dict(module.__dict__);exec(compile(ast.Module(body=[node],type_ignores=[]),'<old_zone_method>','exec'),ns);old=ns['_guards_hold'];new=SemanticEngine._guards_hold
values={p.type_id:0 if p.is_anchor else 100 for p in definition.piece_types}
profile=RuleSetEvaluationProfile(ruleset_fingerprint=c.ruleset_fingerprint,schema_version=1,evaluator_version='unit-zone-cost-control',config_hash='',piece_profiles={},board_value_by_type=values,hand_value_by_base_type=values,promotion_gain_by_type={},median_non_anchor_value=100)
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
base=GameSession(c);first=sorted(legal_actions(base.state,c),key=str)[0]
out=root/'.local_agent/guard-projection-20261009/zone-search-cost.json';assert not out.exists()
result=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='2actual roots(initial/one legal action) x q0/q2 x2alternating repetitions x old/inverse; cold player+TT each call, D2/8192nodes/5sec/qhard8, Core, root tactical off. Compare all non-time fields only for completed equal-depth pairs. Caps remain unknown, no extensions.',complete=False,cases=[])
def signature(d):return {k:v for k,v in d.items() if 'seconds' not in k and not k.startswith('time_to_')}
try:
 for ply in (0,1):
  for q in (0,2):
   for repeat in (0,1):
    pair=[]
    for label,fn in (('old',old),('inverse',new)) if repeat==0 else (('inverse',new),('old',old)):
     SemanticEngine._guards_hold=fn;s=GameSession(c)
     if ply:s.submit(first)
     before=(s.state,s.history,s._search_witnesses)
     player=AlphaBetaPlayer(c,evaluator_override=Evaluator(c,profile,cfg),profile_cache=UnusedProfileCache(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
     tick=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0));wall=time.perf_counter()-tick
     validate_pv(s,decision);assert before==(s.state,s.history,s._search_witnesses)
     d=record_value(decision);assert d['native_legality_calls']==0
     cell=dict(ply=ply,q=q,repeat=repeat,method=label,wall_seconds=wall,decision=d);pair.append(cell);result['cases'].append(cell)
     write_record(out,result);print(ply,q,repeat,label,d['completed_depth'],d['termination_reason'],d['nodes'],d['qnodes'],round(wall,3),flush=True)
    if all(x['decision']['termination_reason']=='completed_depth' for x in pair):assert signature(pair[0]['decision'])==signature(pair[1]['decision'])
finally:SemanticEngine._guards_hold=new
result['complete']=True;result['seconds']=time.perf_counter()-start;write_record(out,result)
