from pathlib import Path
import sys,json,time,math,traceback,collections,statistics
R=Path.cwd();D=R/'.local_agent/binding-reuse-20261017';W=D/'aux86-readonly';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
from results.dev_aux.task2492.learning import AlphaBeta,Model
from results.dev_aux.task2492.adapters import ChessEnv
from results.dev_aux.task2392.reader import SharedDeleteStopReader
import chess
out=D/'episode-signal-mechanism';out.mkdir(exist_ok=True);assert not(out/'started.json').exists()
plan=dict(question='In the actual learned37episodes, how much nonzero update signal comes from ordinary bootstrap, entry into search-terminal anchors and the final actual-outcome residual?' ,cap_seconds=180,forecast_seconds=90,scope='Existing37recordedepisodes only. No new training, model.apply, parameter selection, checkpoint or changed search. Local evaluation of the published same model and source; not independent rule authority.',source_sha='5f3cc0aada9f75794a55f12119f1e78e59039142',eta=.05,lam=.95,scale=10)
write_json(out/'plan.json',plan);write_json(out/'started.json',dict(utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()));start=time.monotonic();stop=SharedDeleteStopReader(R)
curves=[json.loads(s)for s in(W/'results/dev_aux/task2497/curves.jsonl').read_text().splitlines()];games=[json.loads(s)for s in(W/'results/dev_aux/task2497/games.jsonl').read_text().splitlines()];group=collections.defaultdict(list)
for row in curves:group[row['seed'],row['game']].append(row)
prev=collections.defaultdict(int);done=[];queries=0;failure=None;maxerr=0;signal_rows=[];signal_types=[]
try:
 for g in games:
  stop()
  if time.monotonic()-start>=180:raise TimeoutError('aggregate180s mechanism cap')
  cr=group[g['seed'],g['game']];last=cr[-1];assert last['event']=='terminal_or_censor';rr=cr[:-1];env=ChessEnv(chess.Board(g['record']['initial']))
  for u in g['record']['moves'][:16]:env.push(chess.Move.from_uci(u))
  assert len(g['record']['moves'])==16+len(rr)
  vals=[];grads=[];terminal_flags=[];base=rr[0]['before'] if rr else None
  for k,row in enumerate(rr):
   if time.monotonic()-start>=180:raise TimeoutError('aggregate180s mechanism cap')
   assert row['before']==base==row['weights'];before=env.record();model=Model(base)
   r=AlphaBeta(2,0).search(env,model,nodes=min(8192,300000-prev[g['seed']]),seconds=5.,seed=g['seed']*100000+g['game']*1000+k,cancel=stop)
   assert r.complete and r.nodes==row['nodes']-prev[g['seed']],(g['seed'],g['game'],k,r.reason,r.nodes,row['nodes']-prev[g['seed']])
   assert env.record()==before and r.action.uci()==g['record']['moves'][16+k]
   v=math.tanh(r.value/10);grad=[0.]*5 if r.pv_terminal else [0. if i==0 else x*(1-v*v)/10 for i,x in enumerate(r.pv_phi)]
   vals.append(v);grads.append(grad);terminal_flags.append(r.pv_terminal);signal_rows.append(dict(seed=g['seed'],game=g['game'],ply=k,value=v,pv_phi=r.pv_phi,pv_terminal=r.pv_terminal,gradient=grad,action=r.action.uci(),nodes=r.nodes));env.push(r.action);prev[g['seed']]=row['nodes'];queries+=1
  assert env.record()==g['record'] and env.terminal()==last['actual_outcome']==g['outcome']
  # Independent forward-view sum of future discounted TD errors at each leaf.
  errors=[vals[i+1]-v if i+1<len(vals) else None if g['outcome'] is None else g['outcome']-v for i,v in enumerate(vals)]
  elig=[0.]*5;types={};nonzero_errors=informative=0
  for t,e in enumerate(errors):
   if e is None:continue
   elig=[.95*x+y for x,y in zip(elig,grads[t])]
   kind='actual_final'if t==len(vals)-1 else 'search_terminal_entry'if terminal_flags[t+1]and not terminal_flags[t]else 'ordinary_bootstrap'
   d=types.setdefault(kind,dict(terms=0,nonzero_errors=0,informative_terms=0,raw_impulse_L1=0.,net_impulse=[0.]*5));d['terms']+=1;d['nonzero_errors']+=abs(e)>1e-15;d['informative_terms']+=any(abs(e*x)>1e-15 for x in elig);d['raw_impulse_L1']+=sum(abs(e*x)for x in elig);d['net_impulse']=[a+e*x for a,x in zip(d['net_impulse'],elig)]
  signal_types.append(dict(seed=g['seed'],game=g['game'],types=types))
  delta=[sum(grads[i][j]*sum(.95**(t-i)*errors[t] for t in range(i,len(vals)) if errors[t] is not None)for i in range(len(vals)))for j in range(5)]
  expect=[base[j]+.05*delta[j]for j in range(5)] if base else last['weights'];expect[0]=1.
  err=max(abs(a-b)for a,b in zip(expect,last['weights']));maxerr=max(maxerr,err);assert err<1e-11,(g['seed'],g['game'],err)
  assert last['samples']==sum(e is not None for e in errors);prev[g['seed']]=last['nodes']
  done.append(dict(seed=g['seed'],game=g['game'],searches=len(rr),outcome=g['outcome'],max_weight_error=err,changed=last['changed'],terms=last['samples']))
  print('EPISODE',g['seed'],g['game'],len(rr),round(time.monotonic()-start,2),flush=True)
except BaseException as e:failure=dict(type=type(e).__name__,message=str(e),trace=traceback.format_exc())
write_json(out/'result.json',dict(expected_episodes=37,verified_episodes=len(done),queries=queries,max_weight_error=maxerr,seconds=time.monotonic()-start,failure=failure,episodes=done,scope=plan['scope']))
write_json(out/'mechanism.json',dict(receipts=signal_rows,episodes=signal_types,scope='SECOND diagnostic replay of original fixed episodes for new signal attribution; no training/newgames, no change to original study caps. Raw per-term L1 differs from absolute net update; final actual residual and earlier search-terminal anchors are distinct.'))
print('CLOSED',len(done),queries,failure,flush=True)
