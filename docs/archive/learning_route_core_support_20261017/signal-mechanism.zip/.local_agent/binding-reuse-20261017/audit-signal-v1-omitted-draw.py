from pathlib import Path
import sys,json,math
R=Path.cwd();D=R/'.local_agent/binding-reuse-20261017';sys.path.insert(0,str(R));from tools.local_agent.common import write_json
M=json.loads((D/'episode-signal-mechanism/mechanism.json').read_bytes());curves=[json.loads(s)for s in(D/'aux86-readonly/results/dev_aux/task2497/curves.jsonl').read_text(encoding='utf8').splitlines()];by={(r['seed'],r['game'],r['ply']):r for r in curves if 'ply'in r};ends={(r['seed'],r['game']):r for r in curves if 'event'in r};groups={}
for r in M['receipts']:
 w=by[r['seed'],r['game'],r['ply']]['before'];v=r['value'];grad=r['gradient']
 if r['pv_terminal']:assert abs(v)==1 and not any(grad)
 else:
  raw=sum(a*b for a,b in zip(w,r['pv_phi']));assert abs(v-math.tanh(raw/10))<1e-15
  expected=[0. if i==0 else x*(1-v*v)/10 for i,x in enumerate(r['pv_phi'])];assert max(abs(a-b)for a,b in zip(expected,grad))<1e-15
 groups.setdefault((r['seed'],r['game']),[]).append(r)
maxerr=0
for key,rr in groups.items():
 end=ends[key];rr.sort(key=lambda r:r['ply']);target=[rr[i+1]['value']if i+1<len(rr)else end['actual_outcome']for i in range(len(rr))];errors=[None if y is None else y-r['value']for r,y in zip(rr,target)];w=by[key[0],key[1],0]['before']
 delta=[sum(r['gradient'][j]*sum(.95**(k-i)*errors[k]for k in range(i,len(rr))if errors[k]is not None)for i,r in enumerate(rr))*.05 for j in range(5)]
 maxerr=max(maxerr,max(abs(a+b-c)for a,b,c in zip(w,delta,end['weights'])));assert maxerr<1e-11
assert len(groups)==37 and len(M['receipts'])==5299
write_json(D/'signal-receipt-audit.json',dict(verified_episodes=37,receipts=5299,max_weight_error=maxerr,terminal_gradients_zero=True,nonterminal_return_and_gradient_same_leaf=True,scope='Independent arithmetic on actual stored receipts and frozen curve weights. No search/training/games rerun; requires first public capsule inputs.'))
print('SIGNAL_RECEIPT_AUDIT',len(groups),len(M['receipts']),maxerr)
