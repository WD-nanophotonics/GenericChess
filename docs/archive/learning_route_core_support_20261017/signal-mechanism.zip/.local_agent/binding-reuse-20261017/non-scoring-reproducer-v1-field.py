from pathlib import Path
import sys,json,hashlib
R=Path.cwd();D=R/'.local_agent/binding-reuse-20261017';W=D/'aux86-readonly';sys.path[:0]=[str(W),str(R/'tests/product'),str(R/'tests'),str(R)]
from tools.local_agent.common import write_json
from test_finished_session_search import rules,finish
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.session import GameSession
from results.dev_aux.task2492.adapters import SessionEnv
expected=json.loads((D/'aux86-adapter-non-scoring-counterexample.json').read_bytes())['rows'];rows=[]
for kind in ('RESTART','NO_CONTEST'):
 rule=rules(kind);c=compile_legacy_ruleset_for_semantic_execution(rule);s=GameSession(c);finish(s,kind,0);value=SessionEnv(s,()).terminal();record=s.to_record();replayed=GameSession.replay(c,record);assert replayed.result==s.result and value==0
 assert c.fingerprint==next(r for r in expected if r['kind']==kind)['record']['ruleset_fingerprint']
 rows.append(dict(kind=kind,rules=json.loads(serialize_ruleset(rule)),record=__import__('scripts.research_record',fromlist=['record_value']).record_value(record),published_adapter_terminal=value,expected_WDL='NON_SCORING',full_record_replay=True))
write_json(D/'non-scoring-reproducible-rules.json',dict(source_aux_sha='5f3cc0aada9f75794a55f12119f1e78e59039142',product_base='96b96b830e70e4a15a5ca8a24006e21075fc884c',rows=rows,scope='Existing2actualcounterexamples now carry complete serialized rules and executable producer. No source change/newtraining; future Generic adapter ownedAUX, Chess result unaffected.'))
print('NON_SCORING_RULE_REPRO',len(rows))
