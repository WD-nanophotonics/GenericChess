from pathlib import Path
import sys,json,time,hashlib,traceback
R=Path.cwd();D=R/'.local_agent/binding-reuse-20261017';W=D/'aux86-readonly';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
import results.dev_aux.task2500.evaluate as runner
# Reuse the published evaluator/loop; only route private outputs and atomic JSON.
BASE=D/'fixed-learning-depth-transfer';BASE.mkdir(exist_ok=True);assert not (BASE/'logical-started.json').exists()
source=Path(runner.__file__).resolve();assert source== (W/'results/dev_aux/task2500/evaluate.py').resolve()
weights=W/'results/dev_aux/task2497/result.json';arms=json.loads(weights.read_bytes())['arms'];assert [a['seed']for a in arms]==[1977,8173]
plan=dict(question='Does the verified learned-vs-initial price gain persist at D3 rather than only the original D2 finite search, under the SAME new starts/opponent/resources?',changed_premise='AUX86 now delivers two actual frozen learned sets and64closed D2evalgames. Independent13tests/10129ply replay/tallies verified; learned benefit is now a concrete premise, unlike old untrained grids.',source_sha='5f3cc0aada9f75794a55f12119f1e78e59039142',source_files={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [source,W/'results/dev_aux/task2492/learning.py',W/'results/dev_aux/task2492/adapters.py']},weights_sha256=hashlib.sha256(weights.read_bytes()).hexdigest(),weights=[dict(seed=a['seed'],initial=a['initial'],learned=a['weights'])for a in arms],prefix_seeds=list(range(90013,90021)),opening_plies=16,depths=[2,3],qdepth=0,H=512,nodes_per_search=4096,seconds_per_search=5.,foe_weights=[1.]*5,expected_games=128,forecast_seconds=900,whole_cap_seconds=1800,total_logical_forecast_including_review_minutes=45,controls='All2frozenarms retained, bothroles, both treatments, SAMEuniformfoe and perplyseed; same8newfamilies acrossdepths/seeds, not32independentfamilies. No training/price selection/new learner/solver or oldcap extension.',decision='Retain allmissing/U. A D3 loss or broadbounds limits generalization and selects the horizon question for owner; consistent gain strengthens only finite-policy replication. No default/Elo/universalprice claim.',ownership='PRIMARY independent fixed-policy search/evaluation support, using same published AUX learner/search; no edits to AUX checkout/session or competing training. AUX owns further learning changes.')
write_json(BASE/'plan.json',plan);write_json(BASE/'logical-started.json',dict(utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),plan_sha256=hashlib.sha256((BASE/'plan.json').read_bytes()).hexdigest()));start=time.monotonic();failure=None;done=[]
original_write=Path.write_text
# Do not alter the frozen search/adapter or their arguments. JSON endpoint writes
# use the PRIMARY atomic helper; JSONL remains the runner's append-only journal.
def atomic_text(self,data,*args,**kwargs):
 if self.resolve().is_relative_to(BASE.resolve()) and self.suffix=='.json':
  write_json(self,json.loads(data));return len(data)
 return original_write(self,data,*args,**kwargs)
Path.write_text=atomic_text
try:
 for depth in (2,3):
  for n in ('rollout','advisor','slack'):
   flag=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not flag.get('stopped')and not flag.get('user_paused')
  remaining=1800-(time.monotonic()-start)
  if remaining<=0:break
  out=BASE/f'd{depth}';out.mkdir(exist_ok=True);p=dict(weights=str(weights),weights_sha=plan['weights_sha256'],prefix_seeds=plan['prefix_seeds'],opening_plies=16,H=512,depth=depth,qdepth=0,nodes_per_search=4096,seconds_per_search=5.,cap_seconds=remaining,foe_weights=[1.]*5,freeze='PRIMARYprefrozen128slotdepthtransfer; global logical1800s spansBOTHdepths, no reset. Independent fixedpolicy validation using existing AUX public runner; no learning.')
  write_json(out/'plan.json',p);runner.OUT=out;runner.run();done.append(depth);print('DEPTH_DONE',depth,round(time.monotonic()-start,3),flush=True)
except BaseException as e:failure=dict(type=type(e).__name__,message=str(e),trace=traceback.format_exc());print('DEPTH_FAILURE',failure,flush=True)
finally:
 Path.write_text=original_write
 actual=sum(sum(1for _ in (BASE/f'd{d}'/'games.jsonl').open())for d in (2,3)if (BASE/f'd{d}'/'games.jsonl').exists());write_json(BASE/'logical-result.json',dict(done_depths=done,actual_games=actual,expected_games=128,unstarted_games=128-actual,seconds=time.monotonic()-start,failure=failure,training=False,source=str(source),scope='One logical fixed-policy study; noAUXlearning rerun or source change.'))
