from pathlib import Path
import sys,json,time
from dataclasses import replace
from copy import copy
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/binding-reuse-20261017';A=R/'.local_agent/guard-equivalence-20261017/node-admission-transfer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
write_json(D/'fractional-scale-control-plan.json',dict(changed_premise='Predeclared B-only perturbation4calls all returned integral -4/-2: chosen leaf Bdifference0, not evidence of quantization.',question='Does a nonzero known material direction preserve fractional score through current Core?',calls=1,scale=1.0125,prefix=16,family=3,expected_score=-4.05,forecast_seconds=8,whole_cap_seconds=45,scope='Positive precision control only, no rescue of a performance/adoption gate or learner update.'))
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
start=time.monotonic()
def check():
 assert time.monotonic()-start<45
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
inputs=json.loads((A/'consumer-inputs.json').read_bytes());g=json.loads((A/'consumer-game-13.json').read_bytes());rule=deserialize_ruleset(json.dumps(next(i['rule']for i in inputs if i['family']==3)));c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c);types=non_anchor_type_ids(c)
for m in g['moves'][:16]:check();s.submit(decode(m['decision']['action']))
assert record_value(s.state)==g['moves'][15]['child'];before=s.state,s.to_record(),s._search_witnesses
class Uniform:
 def evaluate(self,state):
  f=material_features(state.position,types,perspective=state.position.side_to_move);return 1.0125*sum(f.board_counts+f.hand_counts)
p=AlphaBetaPlayer(c,evaluator_override=Uniform(),use_disk_cache=False,use_native_semantic_legality=False,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));d=p.choose_action(s,SearchLimits(max_depth=1,max_nodes=2048,quiescence_max_depth=0,quiescence_hard_max_depth=0));check();assert d.completed_depth==1 and abs(d.score+4.05)<1e-10 and before==(s.state,s.to_record(),s._search_witnesses);leaf=copy(s)
for a in d.principal_variation:leaf.submit(a)
write_json(D/'fractional-scale-control-result.json',dict(decision=record_value(d),full_leaf=record_value(leaf.state),expected=-4.05,score=d.score,source='Current publicCore96b96b83, evaluator_override direct, fullhistory16 preserved.',seconds=time.monotonic()-start,no_quantization_observed=True,training=False,new_games=0))
print('Fractional wholeCore precision control PASS',d.score)
