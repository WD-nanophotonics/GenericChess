from pathlib import Path
import sys,json,time,traceback
from copy import copy
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/binding-reuse-20261017';A=R/'.local_agent/guard-equivalence-20261017/node-admission-transfer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import MATE_SCORE
START=time.monotonic();rows=[];failure=None;cases=[(2,8,4),(3,13,16),(3,13,32),(3,13,64)]
write_json(D/'pv-consumer-plan.json',dict(question='Does existing fullPV opt-in provide the actual terminal/material leaf underlying cold/warm q0/q1 returned scores for a future same-learner Generic transfer?',cases=cases,calls=16,weights='All nonanchor board+hand1.0125, fixed and unfitted throughout',limits=dict(depth=2,nodes=4096,qdepths=[0,1],hardq=4,root_tactical=False,TT=True,ordering=False,fullPV=True),forecast_seconds=240,whole_cap_seconds=600,decision='If score/leaf equality fails on completed nonterminal returns, diagnose concrete missing consumer contract before transfer; otherwise existing API is sufficient for this scope, no diagnostics framework/default change.',scope='16caller observations only, exposed actual fullhistories, no training or new game. Keep D0/fallback/error/terminal/declaration distinct; no inferred usefulness.'))
def check():
 if time.monotonic()-START>=600:raise TimeoutError('Frozen600s fullPV consumer diagnostic cap')
 for n in ('rollout','advisor','slack'):
  flag=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if flag.get('stopped')or flag.get('user_paused'):raise InterruptedError('Explicit project stop')
def decode(a):
 if not a:return PassAction()
 if 'from_square' in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
try:
 inputs=json.loads((A/'consumer-inputs.json').read_bytes())
 for ci,(family,game,length)in enumerate(cases):
  check();g=json.loads((A/f'consumer-game-{game:02}.json').read_bytes());r=deserialize_ruleset(json.dumps(next(i['rule']for i in inputs if i['family']==family)));c=replace(compile_semantic_ruleset(r),_legacy_compiled=None);s=GameSession(c);types=non_anchor_type_ids(c)
  for m in g['moves'][:length]:check();s.submit(decode(m['decision']['action']))
  assert record_value(s.state)==g['moves'][length-1]['child'];before=s.state,s.to_record(),s._search_witnesses
  class FrozenMaterial:
   def evaluate(self,state):
    f=material_features(state.position,types,perspective=state.position.side_to_move);return 1.0125*sum(f.board_counts+f.hand_counts)
  ev=FrozenMaterial()
  for q in (0,1):
   p=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False,use_tt=True,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
   for warm in (False,True):
    check();t=time.monotonic();d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,quiescence_max_depth=q,quiescence_hard_max_depth=4));check();assert before==(s.state,s.to_record(),s._search_witnesses)
    leaf=copy(s)
    for a in d.principal_variation:check();leaf.submit(a)
    raw=ev.evaluate(leaf.state)*(1 if leaf.state.position.side_to_move==s.state.position.side_to_move else -1)
    terminal=leaf.state.terminal_status.is_terminal
    eligible=d.completed_depth>=1 and bool(d.principal_variation) and d.choice_kind=='ACTION'
    equality=None if not eligible or terminal else abs(raw-d.score)<1e-8
    row=dict(case=ci,family=family,prefix=length,q=q,warm=warm,decision=record_value(d),full_leaf=record_value(leaf.state),full_parent=record_value(s.state),raw_leaf_score_root_side=raw,leaf_terminal=terminal,completed_nonterminal_leaf_equal=equality,scope='No score-equality requirement for fallback/emptyPV/declaration/terminal scale; all retained.',seconds=time.monotonic()-t)
    rows.append(row);write_json(D/f'pv-consumer-{ci}-{q}-{int(warm)}.json',row);print('PV_CONSUMER',ci,q,warm,d.completed_depth,len(d.principal_variation),d.score,raw,equality,round(row['seconds'],2),flush=True)
except Exception as ex:failure=dict(type=type(ex).__name__,message=str(ex),trace=traceback.format_exc());print('PV_CONSUMER_FAILURE',failure,flush=True)
finally:write_json(D/'pv-consumer-result.json',dict(complete=len(rows)==16 and failure is None,rows=rows,failure=failure,seconds=time.monotonic()-START,training=False,new_games=0,all_qualified_equal=all(x['completed_nonterminal_leaf_equal']is not False for x in rows)))
