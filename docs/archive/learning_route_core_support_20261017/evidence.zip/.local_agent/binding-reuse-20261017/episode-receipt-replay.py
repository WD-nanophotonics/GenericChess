from pathlib import Path
import sys,json,time,math,traceback,collections,statistics
R=Path.cwd();D=R/'.local_agent/binding-reuse-20261017';W=D/'aux86-readonly';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
from results.dev_aux.task2492.learning import AlphaBeta,Model
from results.dev_aux.task2492.adapters import ChessEnv
from results.dev_aux.task2392.reader import SharedDeleteStopReader
import chess
out=D/'episode-receipt-replay';out.mkdir(exist_ok=True);assert not(out/'started.json').exists()
plan=dict(question='Do recorded completed frozen-weight searches reproduce played actions and the actual37episode parameter deltas under an independently evaluated forward lambda sum?',cap_seconds=300,forecast_seconds=100,scope='Existing37recordedepisodes only. No new training, model.apply, parameter selection, checkpoint or changed search. Local evaluation of the published same model and source; not independent rule authority.',source_sha='5f3cc0aada9f75794a55f12119f1e78e59039142',eta=.05,lam=.95,scale=10)
write_json(out/'plan.json',plan);write_json(out/'started.json',dict(utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()));start=time.monotonic();stop=SharedDeleteStopReader(R)
curves=[json.loads(s)for s in(W/'results/dev_aux/task2497/curves.jsonl').read_text().splitlines()];games=[json.loads(s)for s in(W/'results/dev_aux/task2497/games.jsonl').read_text().splitlines()];group=collections.defaultdict(list)
for row in curves:group[row['seed'],row['game']].append(row)
prev=collections.defaultdict(int);done=[];queries=0;failure=None;maxerr=0
try:
 for g in games:
  stop()
  if time.monotonic()-start>=300:raise TimeoutError('aggregate300s frozen cap')
  cr=group[g['seed'],g['game']];last=cr[-1];assert last['event']=='terminal_or_censor';rr=cr[:-1];env=ChessEnv(chess.Board(g['record']['initial']))
  for u in g['record']['moves'][:16]:env.push(chess.Move.from_uci(u))
  assert len(g['record']['moves'])==16+len(rr)
  vals=[];grads=[];base=rr[0]['before'] if rr else None
  for k,row in enumerate(rr):
   if time.monotonic()-start>=300:raise TimeoutError('aggregate300s frozen cap')
   assert row['before']==base==row['weights'];before=env.record();model=Model(base)
   r=AlphaBeta(2,0).search(env,model,nodes=min(8192,300000-prev[g['seed']]),seconds=5.,seed=g['seed']*100000+g['game']*1000+k,cancel=stop)
   assert r.complete and r.nodes==row['nodes']-prev[g['seed']],(g['seed'],g['game'],k,r.reason,r.nodes,row['nodes']-prev[g['seed']])
   assert env.record()==before and r.action.uci()==g['record']['moves'][16+k]
   v=math.tanh(r.value/10);grad=[0.]*5 if r.pv_terminal else [0. if i==0 else x*(1-v*v)/10 for i,x in enumerate(r.pv_phi)]
   vals.append(v);grads.append(grad);env.push(r.action);prev[g['seed']]=row['nodes'];queries+=1
  assert env.record()==g['record'] and env.terminal()==last['actual_outcome']==g['outcome']
  # Independent forward-view sum of future discounted TD errors at each leaf.
  errors=[vals[i+1]-v if i+1<len(vals) else None if g['outcome'] is None else g['outcome']-v for i,v in enumerate(vals)]
  delta=[sum(grads[i][j]*sum(.95**(t-i)*errors[t] for t in range(i,len(vals)) if errors[t] is not None)for i in range(len(vals)))for j in range(5)]
  expect=[base[j]+.05*delta[j]for j in range(5)] if base else last['weights'];expect[0]=1.
  err=max(abs(a-b)for a,b in zip(expect,last['weights']));maxerr=max(maxerr,err);assert err<1e-11,(g['seed'],g['game'],err)
  assert last['samples']==sum(e is not None for e in errors);prev[g['seed']]=last['nodes']
  done.append(dict(seed=g['seed'],game=g['game'],searches=len(rr),outcome=g['outcome'],max_weight_error=err,changed=last['changed'],terms=last['samples']))
  print('EPISODE',g['seed'],g['game'],len(rr),round(time.monotonic()-start,2),flush=True)
except BaseException as e:failure=dict(type=type(e).__name__,message=str(e),trace=traceback.format_exc())
write_json(out/'result.json',dict(expected_episodes=37,verified_episodes=len(done),queries=queries,max_weight_error=maxerr,seconds=time.monotonic()-start,failure=failure,episodes=done,scope=plan['scope']))
print('CLOSED',len(done),queries,failure,flush=True)
