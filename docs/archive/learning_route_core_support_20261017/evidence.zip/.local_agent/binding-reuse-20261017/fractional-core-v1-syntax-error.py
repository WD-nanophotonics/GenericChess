from pathlib import Path
import sys,json,time,traceback
from dataclasses import replace
from copy import copy
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/binding-reuse-20261017';A=R/'.local_agent/guard-equivalence-20261017/node-admission-transfer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
START=time.monotonic();rows=[];failure=None
write_json(D/'fractional-core-plan.json',dict(question='Can existing fullCore evaluator_override preserve unit-scale fractional material signals and executable PV without Native quantization or new API?',cases=[dict(family=3,game=13,prefix=16),dict(family=3,game=13,prefix=32)],weights=['allunit','allunit_except_B=1.0125'],calls=4,limits=dict(depth=1,nodes=2048,q0=True,root_tactical=False,TT=False,ordering=False,PVS=False),forecast_seconds=60,whole_cap_seconds=180,claim='Unfitted interface feasibility only, no learner/training/games or strength comparison. Allstates retain drops/promotion/aux/history.'))
def check():
 if time.monotonic()-START>=180:raise TimeoutError('Frozen180s interface check')
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('Explicit stop')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
try:
 inputs=json.loads((A/'consumer-inputs.json').read_bytes());game=json.loads((A/'consumer-game-13.json').read_bytes());rule=deserialize_ruleset(json.dumps(next(i['rule']for i in inputs if i['family']==3)));c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);types=non_anchor_type_ids(c)
 for length in(16,32):
  s=GameSession(c)
  for m in game['moves'][:length]:check();s.submit(decode(m['decision']['action']))
  assert record_value(s.state)==game['moves'][length-1]['child'];parent=s.state,s.to_record(),s._search_witnesses
  for altered in(False,True):
   check();w={t:1.0125 if altered and t=='B'else1. for t in types}
   class FixedMaterial:
    def evaluate(self,state):
     f=material_features(state.position,types,perspective=state.position.side_to_move);return sum(w[t]*(b+h)for t,b,h in zip(types,f.board_counts,f.hand_counts))
   ev=FixedMaterial();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));t=time.monotonic();decision=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=2048,quiescence_max_depth=0,quiescence_hard_max_depth=0));check();assert parent==(s.state,s.to_record(),s._search_witnesses)and decision.completed_depth==1
   leaf=copy(s)
   for a in decision.principal_variation:leaf.submit(a)
   rawroot=ev.evaluate(leaf.state)*(1 if leaf.state.position.side_to_move==s.state.position.side_to_move else-1)
   if not leaf.state.terminal_status.is_terminal:assert abs(rawroot-decision.score)<1e-10
   row=dict(prefix=length,altered=altered,weights=w,decision=record_value(decision),leaf=record_value(leaf.state),fractional_score=decision.score!=int(decision.score),raw_leaf_root_score=rawroot,seconds=time.monotonic()-t);rows.append(row);write_json(D/f'fractional-core-{length}-{int(altered)}.json',row);print('CORE_FRACTION',length,altered,decision.score,round(row['seconds'],3),flush=True)
except Exception as ex:failure=dict(type=type(ex).__name__,message=str(ex),trace=traceback.format_exc());print('CORE_FRACTION_FAILURE',failure,flush=True)
finally:write_json(D/'fractional-core-result.json',dict(complete=len(rows)==4 and failure is None,rows=rows,failure=failure,seconds=time.monotonic()-START,new_games=0,training=False,scope='4actualCore fullhistoryD1calls, no default/model/API change.'))
