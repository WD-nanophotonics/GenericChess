"""Prefrozen smoke learning curves, NOT historical replication or strength proof."""
from pathlib import Path
from dataclasses import asdict
import json,hashlib,random,time,datetime,chess
from results.dev_aux.task2492.learning import Model,AlphaBeta,TreeStrap,TDLeaf
from results.dev_aux.task2492.adapters import ChessEnv
from results.dev_aux.task2392.reader import SharedDeleteStopReader
OUT=Path('results/dev_aux/task2492')
def dump(name,v):
 p=OUT/name;assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n')
def run():
 assert not(OUT/'started.json').exists();plan=json.loads((OUT/'plan.json').read_text());stop=SharedDeleteStopReader(Path.cwd());stop();began=time.perf_counter();dump('started.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),plan_sha=hashlib.sha256((OUT/'plan.json').read_bytes()).hexdigest(),sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in OUT.glob('*.py')},chess_version=chess.__version__))
 results=[]
 with (OUT/'curves.jsonl').open('x')as curve,(OUT/'games.jsonl').open('x')as games:
  for seed in plan['seeds']:
   rng=random.Random(seed);initial=[1.]+[rng.uniform(.5,1.5)for _ in range(4)]
   for method in plan['methods']:
    model=Model(initial);learner=TreeStrap(plan['eta']) if method=='tree' else TDLeaf(plan['eta'],plan['lambda'],coherence=method=='td_tc')
    nodes=updates=samples=changed=0;outcomes={k:0 for k in 'WLDU'};start=time.perf_counter();reason='NODE_BUDGET';fens=[]
    for game in range(plan['max_games']):
     if nodes>=plan['node_budget_per_arm']:break
     env=ChessEnv();opening=random.Random(70000+game)
     for _ in range(plan['opening_plies']):
      if env.terminal() is not None:break
      env.push(opening.choice(sorted(env.actions(),key=lambda a:a.uci())))
     if isinstance(learner,TDLeaf):learner.reset()
     game_nodes=0;ending='HORIZON_UNKNOWN';outcome=None
     for ply in range(plan['H']):
      stop()
      if time.perf_counter()-began>=plan['cap_seconds']:reason='GLOBAL_CAP';ending='GLOBAL_CAP_UNKNOWN';break
      outcome=env.terminal()
      if outcome is not None:ending='ACTUAL_TERMINAL';break
      left=plan['node_budget_per_arm']-nodes
      if left<=0:ending='NODE_BUDGET_UNKNOWN';break
      before=list(model.weights);r=AlphaBeta(plan['depth'],plan['qdepth']).search(env,model,nodes=min(plan['nodes_per_search'],left),seconds=plan['seconds_per_search'],seed=seed*100000+game*1000+ply,cancel=stop)
      nodes+=r.nodes;game_nodes+=r.nodes
      if not r.complete:ending='SEARCH_LIMIT_UNKNOWN';break
      stats=learner.update(model,r)if isinstance(learner,TreeStrap)else learner.observe(model,r)
      samples+=stats['samples'];changed+=bool(stats['changed']);updates+=1
      curve.write(json.dumps(dict(seed=seed,method=method,game=game,ply=ply,nodes=nodes,seconds=time.perf_counter()-start,before=before,weights=model.weights,**stats))+'\n');curve.flush();env.push(r.action)
     actual=env.terminal()
     if actual is not None:outcome=actual;ending='ACTUAL_TERMINAL'
     if isinstance(learner,TDLeaf):
      stats=learner.finish(model,outcome);samples+=stats['samples'];changed+=bool(stats['changed'])
      curve.write(json.dumps(dict(seed=seed,method=method,game=game,event='terminal_or_censor',actual_outcome=outcome,nodes=nodes,weights=model.weights,**stats))+'\n');curve.flush()
     label='U'if outcome is None else'D'if outcome==0 else'W'if outcome==1 else'L';outcomes[label]+=1
     record=dict(seed=seed,method=method,game=game,ending=ending,outcome=outcome,nodes=game_nodes,record=env.record());games.write(json.dumps(record)+'\n');games.flush()
     if reason=='GLOBAL_CAP':break
    if nodes<plan['node_budget_per_arm'] and sum(outcomes.values())==plan['max_games']:reason='MAX_GAMES'
    result=dict(seed=seed,method=method,initial=initial,weights=model.weights,nodes=nodes,search_updates=updates,training_samples=samples,nonzero_update_steps=changed,outcomes=outcomes,seconds=time.perf_counter()-start,reason=reason);results.append(result);print(json.dumps(result),flush=True)
    if reason=='GLOBAL_CAP':break
   if reason=='GLOBAL_CAP':break
 dump('result.json',dict(status='SMOKE_CLOSED',seconds=time.perf_counter()-began,arms=results,claim='Execution/learning signal feasibility only. No convergence/heldout strength/equal-cost grid comparison completed. Unknown is censored, never draw.'))
if __name__=='__main__':run()
