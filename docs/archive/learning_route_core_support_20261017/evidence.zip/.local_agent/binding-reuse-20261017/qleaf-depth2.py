from pathlib import Path
import sys,time,json
from copy import copy
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];D=R/'.local_agent/binding-reuse-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom
from generic_chess.core.actions import BoardMove
from generic_chess.core.coordinates import Square
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.learning.features import material_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
write_json(D/'qleaf-depth2-plan.json',dict(question='Source shows mainPV stops at q entry while qsearch returns only scalar: can a real checking/fork fixture produce different score and publicPV leaf material?',layout=['r.rk','....','..R.','K...'],reason='White must answer file0 check; every quiet escape/block leaves ownR to black capture, so q1 value can differ from pre-q material.',compilers=['legacy','semantic'],qdepths=[0,1],calls=4,limits=dict(depth=2,nodes=20000,hardq=6,TT=False,ordering=False,root_tactical=False,fullPV=True),forecast_seconds=5,whole_cap_seconds=30,scope='One actual fullGameSession integration counterexample only, no game campaign/learner/default change. Existing fullPV guarantees mainline, not necessarily q leaf.'))
start=time.monotonic();rows=[]
rule=make_ruleset(4,[king_type(),T('R',RayAtom((1,0)),RayAtom((-1,0)),RayAtom((0,1)),RayAtom((0,-1)))],lines=['.rrk','....','....','K.R.'])
for name,compiler in [('legacy',compile_ruleset),('semantic',compile_legacy_ruleset_for_semantic_execution)]:
 c=compiler(rule);s=GameSession(c);s.submit(BoardMove(Square(2,0),Square(2,1)));s.submit(BoardMove(Square(1,3),Square(0,3)));parent=s.state,s.to_record(),s._search_witnesses
 class Material:
  def evaluate(self,state):
   f=material_features(state.position,('R',),perspective=state.position.side_to_move);return sum(f.board_counts+f.hand_counts)
 ev=Material()
 for q in (0,1):
  assert time.monotonic()-start<30
  for n in('rollout','advisor','slack'):
   f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
  p=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=20000,quiescence_max_depth=q,quiescence_hard_max_depth=6));leaf=copy(s)
  for a in d.principal_variation:leaf.submit(a)
  raw=ev.evaluate(leaf.state)*(1 if leaf.state.position.side_to_move==s.state.position.side_to_move else -1);assert parent==(s.state,s.to_record(),s._search_witnesses)
  row=dict(compiler=name,q=q,decision=record_value(d),full_parent=record_value(s.state),PV_leaf=record_value(leaf.state),PV_leaf_root_material=raw,score_equal=raw==d.score);rows.append(row);print('QLEAF',name,q,d.completed_depth,d.score,raw,len(d.principal_variation),flush=True)
write_json(D/'qleaf-depth2-result.json',dict(rows=rows,seconds=time.monotonic()-start,scope='Source-predicted actual public wholeSession control. No AUX source or learner executed.'))
