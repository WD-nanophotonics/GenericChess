from pathlib import Path
import sys,json,collections,hashlib
R=Path.cwd();D=R/'.local_agent/binding-reuse-20261017';W=D/'aux86-readonly';sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
sys.path.insert(0,str(W))
import pytest
code=pytest.main(['-q','-o','addopts=','-p','no:cacheprovider','--rootdir='+str(W),'--confcutdir='+str(W),'--basetemp='+str(D/'aux86-test-temp'),'--junitxml='+str(D/'aux86-independent-tests.xml'),str(W/'results/dev_aux/task2492/test_learning.py'),str(W/'results/dev_aux/task2492/test_episode.py')])
assert code==0
import results.dev_aux.task2492.learning as learning
assert Path(learning.__file__).resolve().is_relative_to(W.resolve())
import chess
rows=[json.loads(line)for line in(W/'results/dev_aux/task2500/games.jsonl').read_text().splitlines()];train=[json.loads(line)for line in(W/'results/dev_aux/task2497/games.jsonl').read_text().splitlines()];group={};moves=0;root_overlap=0
train_prefixes={tuple(g['record']['moves'][:16])for g in train}
for g in rows:
 b=chess.Board(g['record']['initial'])
 for u in g['record']['moves']:
  a=chess.Move.from_uci(u);assert a in b.legal_moves;b.push(a);moves+=1
 assert b.fen()==g['record']['fen'];o=b.outcome(claim_draw=True);assert o is not None;z=0 if o.winner is None else 1 if o.winner else -1;assert g['reward']==z*(1 if g['color']==0 else -1)
 assert g['record']['moves'][:16]==g['initial_record']['moves'];root_overlap+=tuple(g['initial_record']['moves'])in train_prefixes
 key=(g['seed'],g['prefix_seed'],g['color']);group.setdefault(key,{})[g['treatment']]=g
summaries=[]
for seed in sorted({g['seed']for g in rows}):
 rr=[g for g in rows if g['seed']==seed];pairs=[pair for key,pair in group.items()if key[0]==seed]
 assert len(pairs)==16 and all(set(p)=={'initial','learned'}and p['initial']['initial_record']==p['learned']['initial_record']for p in pairs)
 tallies={t:{k:sum(g['reward']==v for g in rr if g['treatment']==t)for k,v in [('W',1),('L',-1),('D',0),('U',None)]}for t in ('initial','learned')}
 gain=sum(p['learned']['reward']-p['initial']['reward']for p in pairs)/len(pairs)
 summaries.append(dict(seed=seed,tallies=tallies,mean_W_minus_L_gain=gain,families=8,paired_games=16))
assert len(rows)==64 and moves==10129 and [s['mean_W_minus_L_gain']for s in summaries]==[.25,.5625]and root_overlap==0
write_json(D/'aux86-independent-verification.json',dict(fixed_sha='5f3cc0aada9f75794a55f12119f1e78e59039142',source_sha='10ac0500688c143d9dfc6b0709b56b3c5d443260',new_source_tests=13,loaded_source=str(Path(learning.__file__).resolve()),recorded_games=64,replayed_legal_plies=moves,actual_terminal=64,training_complete_prefix_overlap=root_overlap,paired=summaries,limits='Independent source tests and legal replay/outcome/tally/pair/root-prefix checks only. Did not independently rerun learning or search choices; same python-chess rule authority, not another engine. No universal robustness, uniquevalues or16independentfamilies claim.',training=False,new_games=0))
print('INDEPENDENT AUX86',len(rows),moves,summaries)
