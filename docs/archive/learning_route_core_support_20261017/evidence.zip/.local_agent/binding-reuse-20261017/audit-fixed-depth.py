from pathlib import Path
import sys,json,collections,statistics,math
R=Path.cwd();D=R/'.local_agent/binding-reuse-20261017';sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
import chess
base=D/'fixed-learning-depth-transfer';plan=json.loads((base/'plan.json').read_bytes());rowsall=[];reports=[];plies=0
for depth in (2,3):
 rows=[json.loads(x)for x in(base/f'd{depth}/games.jsonl').read_text().splitlines()];assert len(rows)==64;groups={};endings=collections.Counter();lens=[]
 for g in rows:
  b=chess.Board(g['record']['initial'])
  for u in g['record']['moves']:
   a=chess.Move.from_uci(u);assert a in b.legal_moves;b.push(a);plies+=1
  assert b.fen()==g['record']['fen'];o=b.outcome(claim_draw=True);z=None if o is None else 0 if o.winner is None else 1 if o.winner else -1
  reward=None if z is None else z*(1 if g['color']==0 else -1);assert reward==g['reward']
  assert g['record']['moves'][:16]==g['initial_record']['moves'];assert len(g['initial_record']['moves'])==16
  key=(g['seed'],g['prefix_seed'],g['color']);groups.setdefault(key,{})[g['treatment']]=g;endings[g['ending']]+=1;lens.append(len(g['record']['moves'])-16)
  if g['ending']=='ACTUAL_TERMINAL':assert o is not None
  else:assert reward is None
 out=[]
 for seed in (1977,8173):
  fs=[];pairs=[(k,p)for k,p in groups.items()if k[0]==seed];assert len(pairs)==16
  for k,p in pairs:assert set(p)=={'initial','learned'}and p['initial']['initial_record']==p['learned']['initial_record']
  for family in range(90013,90021):
   pp=[p for k,p in pairs if k[1]==family];assert len(pp)==2
   lower=upper=0
   for p in pp:
    a,b=p['initial']['reward'],p['learned']['reward'];lower+=(b if b is not None else -1)-(a if a is not None else 1);upper+=(b if b is not None else 1)-(a if a is not None else -1)
   fs.append(dict(prefix_seed=family,gain_lower=lower/2,gain_upper=upper/2))
  lo=sum(f['gain_lower']for f in fs)/8;hi=sum(f['gain_upper']for f in fs)/8
  complete=lo==hi;se=statistics.stdev([f['gain_lower']for f in fs])/math.sqrt(8)if complete else None
  out.append(dict(seed=seed,paired_families=fs,gain_bounds=[lo,hi],mean_gain=lo if complete else None,descriptive_t7_interval=[lo-2.364624251*se,hi+2.364624251*se]if complete else None,interval_limit='Exploratory approximate family-level t interval, eight shared families only; no independent-seed pooling or universal guarantee. UNKNOWN supplies only logical[-1,1]reward bounds.'))
 reports.append(dict(depth=depth,actual_slots=64,terminal=sum(g['reward']is not None for g in rows),unknown=sum(g['reward']is None for g in rows),endings=dict(endings),played_plies_after_opening=dict(min=min(lens),max=max(lens),sum=sum(lens)),nodes=sum(g['nodes']for g in rows),seeds=out));rowsall.extend(rows)
assert len(rowsall)==128
write_json(D/'fixed-learning-depth-audit.json',dict(depths=reports,total_replayed_legal_plies=plies,planned_slots=128,actual_slots=128,unstarted=0,source='Same fixed AUX86 standardChess AlphaBeta/ChessEnv; rule replay via same python-chess, not independent engine.',decision='D2 retains scoped positive gain; D3 has no observed terminal rewards and cannot identify direction. Do not fill draws, extend cap, choose best seed or claim deeper strength.',training=False))
print(json.dumps(reports,indent=2));print('PLIES',plies)
