from pathlib import Path
import sys,json,time,traceback
R=Path.cwd();D=R/'.local_agent/binding-reuse-20261017';W=D/'aux86-readonly';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
from results.dev_aux.task2492.learning import AlphaBeta,Model
from results.dev_aux.task2492.adapters import ChessEnv
from results.dev_aux.task2392.reader import SharedDeleteStopReader
import chess
out=D/'d3-stopped-query-diagnosis';out.mkdir(exist_ok=True);assert not(out/'started.json').exists()
write_json(out/'plan.json',dict(question='Are the64D3UNKNOWN caused by node refusal, wall deadline or another loss of targets?',scope='Reexecute only each existing final failed root at original4096nodes/5s and SAME weights/order seed. No moves played, no larger cap or extra evaluation games.',expected_queries=64,cap_seconds=120,forecast_seconds=35));write_json(out/'started.json',dict(utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()));start=time.monotonic();stop=SharedDeleteStopReader(R);arms={a['seed']:a for a in json.loads((W/'results/dev_aux/task2497/result.json').read_bytes())['arms']};rows=[json.loads(s)for s in(D/'fixed-learning-depth-transfer/d3/games.jsonl').read_text().splitlines()];done=[];failure=None
try:
 for g in rows:
  if time.monotonic()-start>=120:raise TimeoutError('frozen120s diagnostic cap')
  env=ChessEnv(chess.Board(g['record']['initial']))
  for u in g['record']['moves']:env.push(chess.Move.from_uci(u))
  p=len(g['record']['moves'])-16;arm=arms[g['seed']];ww=arm['initial']if g['treatment']=='initial'else arm['weights'];ww=ww if env.player()==g['color']else [1.]*5;before=env.record()
  r=AlphaBeta(3,0).search(env,Model(ww),nodes=4096,seconds=5,seed=g['prefix_seed']*10000+p,cancel=stop)
  assert env.record()==before and not r.complete and r.action is None and r.value is None and r.pv_phi is None
  done.append(dict(seed=g['seed'],prefix_seed=g['prefix_seed'],color=g['color'],treatment=g['treatment'],played_plies=p,nodes=r.nodes,seconds=r.seconds,reason=r.reason,node_cap_hit=r.nodes==4096))
except BaseException as e:failure=dict(type=type(e).__name__,message=str(e),trace=traceback.format_exc())
write_json(out/'result.json',dict(expected_queries=64,returned=len(done),node_cap_hits=sum(r['node_cap_hit']for r in done),seconds=time.monotonic()-start,failure=failure,queries=done,training=False,new_games=0));print('D3DIAG',len(done),sum(r['node_cap_hit']for r in done),failure)
