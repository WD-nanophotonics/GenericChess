from pathlib import Path
import sys,json,time,math,hashlib,traceback,collections,os
from copy import copy
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/binding-reuse-20261017';A=R/'.local_agent/guard-equivalence-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
from generic_chess.learning.features import material_features,non_anchor_type_ids
START=time.monotonic();counts=collections.Counter();done=[];failure=None
write_json(D/'pv-signal-plan.json',dict(question='Can existing complete Core GameSession/returned PV supply terminal-aware material-gradient observations for later AUX learner transfer without a new API?',inputs='Exactly24closed already-qualified records:8representation continuations plus16node-admission games; exposed fixedpolicy data, not training/holdout or new learning.',forecast_seconds=540,whole_cap_seconds=900,parameters=dict(weights='All nonanchor board+hand weights fixed1; no human values or update',beta=.1,lambd=.7),outputs='Full Core child/history equality, replayed PV leaf features fixedowner0, terminalPV constant/zero-gradient cases, root-vs-leaf differences, realterminal vs UNKNOWN/NO_CONTEST, terminal residual applied to prior accumulated trace as diagnostic only.',claim='No learner/checkpoint/training/selfplay/search invocation; no actual learning or strength evidence. No AUX source execution/writes.'))
write_json(D/'pv-signal-producer.json',dict(pid=os.getpid(),utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),whole_cap_seconds=900))
def check():
 if time.monotonic()-START>=900:raise TimeoutError('Frozen900s complete PV-feature diagnostic cap')
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('Explicit stop')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def feature(pos,types):
 x=material_features(pos,types,perspective=0);neg=material_features(pos,types,perspective=1);assert neg==x.negated();return x.array()
def verify(label,rule,initial,moves,record):
 check();c=replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(rule))),_legacy_compiled=None);s=GameSession(c);types=non_anchor_type_ids(c);assert record_value(s.state)==initial;points=[];trace=[0.]*(2*len(types));source_hash=hashlib.sha256(json.dumps(rule,sort_keys=True).encode()).hexdigest()
 for m in moves:
  check();decision=m['decision'];before=s.state,s.to_record(),s._search_witnesses;root=feature(s.state.position,types);pv=copy(s)
  for a in decision['principal_variation']:check();pv.submit(decode(a));counts['PV_edges']+=1
  rawleaf=feature(pv.state.position,types);terminal=pv.result.status.value!='ongoing';counts['queries']+=1;counts['root_leaf_feature_different']+=int(root!=rawleaf)
  no_contest=pv.result.status.value=='no_contest'or pv.result.declaration_outcome in('RESTART','NO_CONTEST')
  if terminal:
   counts['terminal_PV']+=1
   value=None if no_contest else 0. if pv.result.winner is None else 1. if pv.result.winner==0 else -1.
   grad=[0.]*len(rawleaf)
  else:
   value=math.tanh(.1*sum(rawleaf));grad=[.1*(1-value*value)*x for x in rawleaf];counts['nonterminal_PV']+=1;counts['nonzero_material_gradient']+=int(any(grad))
  trace=[.7*x+y for x,y in zip(trace,grad)]
  points.append(dict(ply=s.state.ply_count,completed_depth=decision['completed_depth'],PV_length=len(decision['principal_variation']),root_features=root,leaf_features=rawleaf,terminal_PV=terminal,leaf_status=pv.result.status.value,leaf_winner=pv.result.winner,value=value,gradient=grad,eligibility=trace[:],full_leaf=record_value(pv.state)))
  assert before==(s.state,s.to_record(),s._search_witnesses)
  if decision['choice_kind']=='DECLARATION':s.declare(decision['declaration']['declaration_id'])
  else:s.submit(decode(decision['action']));counts['committed_edges']+=1
  assert record_value(s.state)==m['child'];assert len(s.state.history)==s.state.ply_count+1
 assert record_value(s.to_record())==record
 no_contest=s.result.status.value=='no_contest'or s.result.declaration_outcome in('RESTART','NO_CONTEST');actual=s.result.status.value!='ongoing'and not no_contest
 label_value=0. if s.result.winner is None else 1. if s.result.winner==0 else -1.
 counts['records']+=1;counts['actual_terminal'if actual else'no_contest'if no_contest else'administrative_UNKNOWN']+=1
 last=points[-1]if points else None
 terminal_delta=None if not actual or last is None or last['value']is None else label_value-last['value']
 term_contribution=None if terminal_delta is None else [terminal_delta*x for x in last['eligibility']]
 row=dict(label=label,type_ids=types,rule_sha256=source_hash,plies=s.state.ply_count,result=record_value(s.result),points=points,terminal_delta=terminal_delta,terminal_trace_contribution=term_contribution,nonzero_terminal_contribution=bool(term_contribution and any(abs(x)>1e-15 for x in term_contribution)),claim='Counterfactual signal diagnostic under allunit weights only; these are NOT learner updates or trained-policy results.')
 write_json(D/(label+'-pv-signal.json'),row);done.append({k:v for k,v in row.items()if k!='points'});write_json(D/'pv-signal-progress.json',dict(counts=dict(counts),done=done,seconds=time.monotonic()-START));print('PV_SIGNAL',label,s.state.ply_count,s.result.status.value,round(time.monotonic()-START,3),flush=True)
try:
 B=A/'representation-continuation'
 for path in sorted(B.glob('pair-*.json')):
  data=json.loads(path.read_bytes());assert data['status']!='active'
  for arm in (0,1):verify(f'encoding-f{data["family"]}-a{arm}',data['rules'][arm],data['initial_states'][arm],[dict(decision=m['decisions'][arm],child=m['children'][arm])for m in data['moves']],data['records'][arm])
 B=A/'node-admission-transfer';inputs=json.loads((B/'consumer-inputs.json').read_bytes())
 for path in sorted(B.glob('consumer-game-*.json')):
  data=json.loads(path.read_bytes());assert data['status']!='active';verify(f'node-game-{data["game"]}',next(i['rule']for i in inputs if i['family']==data['family']),data['initial_state'],data['moves'],data['record'])
except Exception as e:failure=dict(type=type(e).__name__,message=str(e),trace=traceback.format_exc());print('PV_SIGNAL_FAILURE',failure,flush=True)
finally:write_json(D/'pv-signal-result.json',dict(counts=dict(counts),done=done,failure=failure,complete=counts['records']==24 and failure is None,seconds=time.monotonic()-START,training=False,new_searches=0,new_games=0,scope='Actual full Core replay plus fixed material-gradient observations, exposed prior trajectories only.'))
