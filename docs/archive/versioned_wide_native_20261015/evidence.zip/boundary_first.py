from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(),'<wide_common>','exec'))
from dataclasses import replace
from rule_semantics_ir_fixtures import _semantic_ruleset,_king_type
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.rules.schema import RuleSemanticAction,RuleGeometrySpec,RuleActionEffect,RuleSquareRef,RuleInvariant,RuleDeclaration,RuleDeclarationOutcomeBand,RuleAuxState
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.declarations import available_declarations
from generic_chess.rules.serialization import serialize_ruleset
import random
# Independent Python scalar oracle vs actualC V2 codec; no masks/truncation tolerated.
rng=random.Random(7919);checks=0
for target in [0,255,256,323,1023]:
 for source in [0,255,256,323,1023]:
  for promotion in [0,63,127]:
   for actor in [0,63]:
    f=dict(to=target,**{'from':source},promotion=promotion,base=63,kind=2,pattern=255,geometry=4095,actor_current=actor)
    code=wide.semantic_action_pack(f);assert wide.semantic_action_unpack(code)==f and not code>>63;checks+=1
for _ in range(10000):
 f=dict(to=rng.randrange(1024),**{'from':rng.randrange(1024)},promotion=rng.randrange(128),base=rng.randrange(64),kind=2,pattern=rng.randrange(256),geometry=rng.randrange(4096),actor_current=rng.randrange(64));code=wide.semantic_action_pack(f);expected=sum(f[k]<<shift for k,shift in [('to',0),('from',10),('promotion',20),('base',27),('kind',33),('pattern',37),('geometry',45),('actor_current',57)]);assert code==expected and wide.semantic_action_unpack(code)==f;checks+=1
rejections=[]
for key,value in [('to',1024),('from',1024),('promotion',128),('base',64),('actor_current',64),('pattern',256),('geometry',4096),('kind',1)]:
 f=dict(to=255,**{'from':256},promotion=127,base=0,kind=2,pattern=0,geometry=0,actor_current=0);f[key]=value
 try:wide.semantic_action_pack(f)
 except ValueError:rejections.append([key,value])
 else:raise AssertionError(('accepted-invalid',key,value))
try:wide.semantic_action_unpack(1<<63)
except ValueError:rejections.append(['declaration_tag',63])
else:raise AssertionError('declaration misdecoded')
rows=[]
for n,target in [(16,255),(18,255),(18,256),(18,323),(32,1023)]:
 board=[None]*(n*n);board[0]=Piece(0,'K','K');board[n*n//2+5]=Piece(1,'K','K');board[target-1]=Piece(0,'A','A');board[target]=Piece(1,'B','B')
 A=PieceType('A','A',(LeapAtom((1,0)),));B=PieceType('B','B',tuple(RayAtom(d)for d in [(1,0),(-1,0),(0,1),(0,-1)]))
 promote=RuleSemanticAction(name='wide_transform',type_ids=('A',),geometry=RuleGeometrySpec(kind='leap',offset=(1,0)),target_relation='enemy',composition='augment',effects=(RuleActionEffect('remove',square_ref=RuleSquareRef('target'),piece_owner='opponent',disposition='capture_to_hand'),RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target'))),invariants=(RuleInvariant('own_anchor_safe'),),promotion_mode='explicit',explicit_promotion_type='B')
 r=_semantic_ruleset((_king_type(),A,B),(promote,),n=n,rows=tuple(tuple(board[i:i+n])for i in range(0,n*n,n)),drop_all_true=('B',));r=replace(r,declarations=(RuleDeclaration('wide_neutral',0,outcome_bands=(RuleDeclarationOutcomeBand(0,'NO_CONTEST'),)),),aux_states=(RuleAuxState('high_token','square_or_none','global','persistent',initial=(target%n,target//n)),))
 c=compile_ruleset_for_execution(r);s=GameSession(c);nr=compilewide(c);payload,_=buildwide(c);assert wide.semantic_rules_info(nr.capsule)==payload;np=pack_semantic_search_position(c,nr,s);check_state(c,s,nr,np)
 acts=tuple(s.legal_actions());codes=wide.semantic_guarded_actions(nr.capsule,np);assert set(public(nr,x)for x in codes)==set(acts)
 a,=[a for a in acts if a.pattern_id.startswith('sem_')];code=pack(nr,s.state.position,a);f=wide.semantic_action_unpack(code);assert f['to']==target and f['from']==target-1 and f['promotion']!=127;child=wide.semantic_make_checked(nr.capsule,np,code);s.submit(a);check_state(c,s,nr,child)
 assert s.state.position.hands[0].count('B')==1
 reply=sorted(s.legal_actions(),key=repr)[0];child=wide.semantic_make_checked(nr.capsule,child,pack(nr,s.state.position,reply));s.submit(reply);check_state(c,s,nr,child)
 drop,=[a for a in s.legal_actions()if a.__class__.__name__=='SemanticDropMove' and a.to_square.file==target%n and a.to_square.rank==(target-1)//n and a.to_square!=s.state.position.board[target]] if False else [next(a for a in s.legal_actions()if a.__class__.__name__=='SemanticDropMove' and a.to_square.file==(target-1)%n and a.to_square.rank==(target-1)//n)]
 dc=pack(nr,s.state.position,drop);df=wide.semantic_action_unpack(dc);assert df['from']==1023 and df['promotion']==127
 child=wide.semantic_make_checked(nr.capsule,child,dc);s.submit(drop);snap=check_state(c,s,nr,child)
 decs=available_declarations(s.state,c);actual=sem.available_declarations(nr,child);assert record_value(decs)==record_value(actual),(decs,actual)
 rows.append(dict(n=n,target=target,promotion=f,drop=df,history=len(snap['history']),declarations=record_value(actual),ruleset=json.loads(serialize_ruleset(r)),record=record_value(s.to_record())))
 print(n,target,'promotion/drop/history/declarations exact',flush=True)
(b/'boundary-results.json').write_text(json.dumps({'codec_checks':checks,'rejections':rejections,'rows':rows},indent=2),encoding='utf-8')
print('complete',checks,len(rows))
