import sys,json,time,random
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import generic_chess.generation.generator as g
b=Path('.local_agent/wide-interface-20261015'); rows=[]
original=g.run_soft_filters
def filters(*args):
 r=original(*args);(b/'generation32-first-filters.json').write_text(json.dumps([{'name':x.name,'passed':x.passed,'detail':x.detail}for x in r]),encoding='utf-8');return r
g.run_soft_filters=filters
t=time.perf_counter()
try:
 result=g._try_generate(random.Random(3304),g.GeneratorConfig(seed=3304,board_size=32,setup_preset='bilateral_random',allow_hybrid=True));row={'result':'firstattemptpassed','opening':result.generation_report.opening_legal_moves}
except Exception as error:row={'result':'firstattemptrejected','error':repr(error)}
row['seconds']=time.perf_counter()-t;(b/'generation32-first-attempt.json').write_text(json.dumps(row),encoding='utf-8');print(json.dumps(row))
