from pathlib import Path
import subprocess,sys,json,time
b=Path('.local_agent/wide-interface-20261015');out=b/'fresh';plan=json.loads((out/'declaration.json').read_text());plan['preparation_policy']='BeforeANYqueries, cap45s perremainingdeclaredseed;3304alreadyinterruptedstayscensored/no retry, earlier3memoryonlyinputsdeterministicallyreconstructed; no resample; allactualcostretained.';(out/'declaration.json').write_text(json.dumps(plan,indent=2),encoding='utf-8');samples=[];rows=[]
for seed,n in zip(plan['seeds'],plan['sizes']):
 if seed==3304:
  samples.append(dict(name=f'{seed}-preparation',seed=seed,n=n,included=False,preparation_censored=True,reason='Observedfirstpreparationcost; no repeatedunchangedseed'));rows.append({'seed':seed,'n':n,'status':'previously_censored'});continue
 t=time.perf_counter()
 try:
  r=subprocess.run([sys.executable,str(b/'prepare_one.py'),str(seed),str(n)],capture_output=True,text=True,timeout=45);(out/f'prepare-{seed}.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr;samples+=json.loads((out/f'input-{seed}.json').read_text())['samples'];rows.append({'seed':seed,'n':n,'seconds':time.perf_counter()-t,'status':'frozen'})
 except subprocess.TimeoutExpired as error:
  samples.append(dict(name=f'{seed}-preparation',seed=seed,n=n,included=False,preparation_censored=True,reason='45sprivatepreparationdeadline'));rows.append({'seed':seed,'n':n,'seconds':time.perf_counter()-t,'status':'45s_censored'})
 except Exception as error:
  (out/'preparation-status.json').write_text(json.dumps({'rows':rows,'error':repr(error)},indent=2),encoding='utf-8');raise
 (out/'preparation-status.json').write_text(json.dumps({'rows':rows},indent=2),encoding='utf-8');print(seed,n,rows[-1]['status'],flush=True)
(out/'samples.json').write_text(json.dumps({'samples':samples},indent=2),encoding='utf-8');print('ALLFROZEN',len(samples))
