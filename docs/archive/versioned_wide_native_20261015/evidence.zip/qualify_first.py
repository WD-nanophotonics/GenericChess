from pathlib import Path
import sys,json,inspect,dataclasses,importlib.util,traceback,time
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
b=ROOT/'.local_agent/wide-interface-20261015';old=ROOT/'.local_agent/q-order-20261015'
exec(compile((old/'common_capture.py').read_text(encoding='utf-8'),str(old/'common_capture.py'),'exec'))
b=ROOT/'.local_agent/wide-interface-20261015'
import generic_chess.native.compiler as nc
import generic_chess.native.semantic as sem
import generic_chess.native.mirror as mirror
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.core.state import apply_action
from generic_chess.core.position import position_identity_key
original=native._MODULE
spec=importlib.util.spec_from_file_location('generic_chess._native_core',next(b.glob('_native_core*.pyd')));wide=importlib.util.module_from_spec(spec);spec.loader.exec_module(wide);native._MODULE=wide
ns=dict(nc.__dict__);ns['SEMANTIC_PAYLOAD_VERSION']=5
src=inspect.getsource(nc._native_payload_is_executable).replace('report.board_squares <= 256','report.board_squares <= 1024');exec(src,ns)
src=inspect.getsource(nc.build_semantic_compile_payload).replace('1 <= n <= 16 and n * n <= 256','1 <= n <= 32 and n * n <= 1024');exec(src,ns)
exec(inspect.getsource(nc.compile_native_semantic_rules),ns);compilewide=ns['compile_native_semantic_rules'];buildwide=ns['build_semantic_compile_payload']
# Versioned codec adapter changes only representation sentinels, not public actions.
src=inspect.getsource(sem.public_action).replace('255','127');ps=dict(sem.__dict__);exec(src,ps);public=ps['public_action']
def pack(nr,pos,a):
 fields=mirror._semantic_action_fields(nr,pos,a)
 if fields['promotion']==255:fields['promotion']=127
 if fields['kind']==3:fields['from']=1023
 return wide.semantic_action_pack(fields)
def check_state(c,s,nr,np):
 snap=sem.snapshot(nr,np);ex=mirror.expected_snapshot(s.state.position,nr,c)
 for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(ex[k]),(k,snap[k],ex[k])
 assert snap['ply']==s.state.ply_count
 assert sem.position_key(nr,np)==str(position_identity_key(s.state.position,c))
 assert snap['history_exact'] and snap['history_events_exact'] and len(snap['history'])==len(s.state.history)
 for h,w,e in zip(snap['history'],s._search_witnesses,s.state.history):
  assert ''.join(f'{v:016x}' for v in h)==str(position_identity_key(w,c))
 assert snap['history_events']==tuple((255 if x.actor<0 else x.actor,bool(x.gave_check))for x in s.state.history)
 return snap
cases=generated_cases(old/'fresh/samples.json')+generated_cases(old/'capture_fresh/samples.json')
selected=[x for x in cases if x[0].split('-')[0]in ['2911','2912','3007','3008']]+semantic_cases()
rows=[]
for name,c,s,v,h in selected:
 row={'name':name,'board_size':c.board_size};rows.append(row);t=time.perf_counter()
 try:
  payload,report=buildwide(c);nr=compilewide(c);assert report.native_executable
  assert wide.semantic_rules_info(nr.capsule)==payload
  np=pack_semantic_search_position(c,nr,s);before=check_state(c,s,nr,np)
  actions=tuple(s.legal_actions());codes=wide.semantic_legal_actions(nr.capsule,np) if hasattr(wide,'semantic_legal_actions')else wide.semantic_guarded_actions(nr.capsule,np)
  decoded=tuple(public(nr,x)for x in codes);assert set(decoded)==set(actions),(name,len(decoded),len(actions),set(decoded)^set(actions))
  edge_rows=[]
  # ALL root actions for bounded complete fixtures, retaining exact states/history.
  for code,a in zip(codes,decoded):
   fields=wide.semantic_action_unpack(code);assert pack(nr,s.state.position,a)==code
   child=wide.semantic_make_checked(nr.capsule,np,code);cs=s.clone() if hasattr(s,'clone')else None
   # Core state transition and witnesses come from the actual session submit/undo.
   s.submit(a);snap=check_state(c,s,nr,child);s.undo()
   edge_rows.append({'fields':fields,'action':record_value(a),'key':sem.position_key(nr,child)})
  assert check_state(c,s,nr,np)==before
  row.update(complete=True,actions=len(actions),edges=edge_rows,history=len(before['history']),seconds=time.perf_counter()-t)
 except Exception as e:
  row.update(complete=False,error=repr(e),trace=traceback.format_exc(),seconds=time.perf_counter()-t)
  print(name,row['trace'],flush=True)
 (b/'qualification.json').write_text(json.dumps({'rows':rows},indent=2),encoding='utf-8')
 print(name,row.get('complete'),row.get('actions'),flush=True)
print('done',len(rows),sum(x.get('actions',0)for x in rows))
