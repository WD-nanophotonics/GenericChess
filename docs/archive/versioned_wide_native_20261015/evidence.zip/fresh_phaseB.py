from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(),'<wide_common>','exec'))
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.core.movegen import legal_actions
import generic_chess.native.semantic_engine as em
out=b/'fresh';plan=json.loads((out/'declaration.json').read_text());data=json.loads((out/'samples.json').read_text());assert not(out/'rows_phaseB.json').exists();installed=original;oldpublic=sem.public_action;rows=[];start=time.monotonic();cases=[]
for x in data['samples']:
 if not x['included']:continue
 raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 for av in x['walk']:
  a,=[a for a in s.legal_actions()if record_value(a)==av];s.submit(a)
 assert record_value(s.state)==x['state']and record_value(s.to_record())==x['record'];cases.append((x['name'],c,s))
class Material:
 def __init__(self,c):self.v={tid:0 if mt.is_anchor else 100 for tid,mt in c.support.type_metadata.items()}
 def type_value(self,tid):return self.v[tid]
 def evaluate(self,state):
  side=state.position.side_to_move
  return sum((1 if x.owner==side else -1)*self.v[x.current_type_id]for x in state.position.board if x)+sum((1 if owner==side else -1)*self.v[tid]*count for owner,hand in enumerate(state.position.hands)for tid,count in hand.items())
 def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
def save(complete=False,error=None):
 (out/'rows_phaseB.json').write_text(json.dumps({'complete':complete,'rows':rows,'producer_seconds':time.monotonic()-start,'error':error},indent=2),encoding='utf-8')
try:
 for mode,seconds in [('fixed',5),('resource',2),('resource',16)]:
  for name,c,s in cases:
   for order in [0,1]:
    for arm in (plan['arms']if order==0 else plan['arms'][::-1]):
     p.rr.stopped()
     if time.monotonic()-start>plan['single_producer_fuse_seconds']:raise TimeoutError('predeclared2700sproducerfuse reached; remainingcells unexecuted,not extended')
     native._MODULE=installed if arm=='currentCore'else wide;em.public_action=oldpublic if arm=='currentCore'else public;ev=Material(c);before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter();row={'source_phase':'B_semantic64targets','root':name,'n':c.board_size,'mode':mode,'seconds':seconds,'order':order,'arm':arm};rows.append(row)
     limits=SearchLimits(max_depth=2 if mode=='fixed'else 12,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8)
     if arm=='privatewide1024':
      nr=compilewide(c);e=SemanticSearchEngine(c,nr,board_values=ev.v,hand_values=ev.v,tt_megabytes=0,ordering_cache_enabled=False);row['actual_backend']='completeprivateNativeV2/semantic1024';row['provider_active']=False;prep=time.perf_counter()-t;d=e.search(s,limits,root_window_pruning=True)
     else:
      e=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_native_semantic_check=True,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));row['provider_active']=e.native_legality_provider is not None;row['actual_backend']='Core withinstalledNativeproviders'if row['provider_active']else'Corefallback';prep=time.perf_counter()-t;d=e.choose_action(s,limits)
     row.update(prepare_seconds=prep,caller_seconds=time.perf_counter()-t,result=record_value(d));assert before==(s.state,s.to_record(),s._search_witnesses);row['root_unchanged']=True
     st=s.state
     for a in d.principal_variation:assert a in legal_actions(st,c);st=apply_action(st,a,c)
     row['pv_legal']=True
     save();print(mode,seconds,name,order,arm,'D',d.completed_depth,'actualq',d.result_ordinary_qdepth,d.termination_reason,flush=True)
 save(True)
except BaseException as error:
 save(False,traceback.format_exc());raise
print('FRESHCOMPLETE',len(rows),'seconds',time.monotonic()-start,flush=True)
