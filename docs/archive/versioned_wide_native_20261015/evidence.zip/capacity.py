from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(),'<wide_common>','exec'))
import generic_chess.native.semantic_engine as em
from generic_chess.core.movegen import legal_actions
installed=original
arms={'installedV1cap256':installed,'privateV2cap1024':wide}
for capacity in [256,512]:
 sp=importlib.util.spec_from_file_location('generic_chess._native_core',b/f'wide{capacity}.pyd');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);arms[f'privateV2cap{capacity}']=m
oldpublic=sem.public_action;prior=ROOT/'.local_agent/q-order-20261015';cases=generated_cases(prior/'fresh/samples.json')+generated_cases(prior/'capture_fresh/samples.json');cases=[x for x in cases if x[0].split('-')[0]in['2911','2912','3007','3008']]+semantic_cases()
rows=[];sizes={}
for arm,m in arms.items():native._MODULE=m;sizes[arm]=sem.search_runtime_sizes()
(b/'capacity-sizes.json').write_text(json.dumps(sizes,indent=2),encoding='utf-8')
for index,case in enumerate(cases):
 name,c,s,v,h=case;v={tid:0 if mt.is_anchor else 100 for tid,mt in c.support.type_metadata.items()}
 for q in [0,4]:
  for order in [0,1]:
   names=list(arms);names=names if order==0 else names[::-1]
   for arm in names:
    row={'name':name,'n':c.board_size,'q':q,'order':order,'arm':arm};rows.append(row);native._MODULE=arms[arm];em.public_action=oldpublic if arm.startswith('installed')else public;t=time.perf_counter()
    try:
     nr=nc.compile_native_semantic_rules(c)if arm.startswith('installed')else compilewide(c)
     e=SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False)
    except (nc.NativeUnsupportedRuleError,ValueError)as error:
     if c.board_size<=16:raise
     row.update(declined=str(error),actual_searches=0);continue
    prep=time.perf_counter()-t;before=s.state,s.to_record(),s._search_witnesses;d=e.search(s,SearchLimits(max_depth=2,max_time_seconds=2,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);assert before==(s.state,s.to_record(),s._search_witnesses)
    st=s.state
    for a in d.principal_variation:assert a in legal_actions(st,c);st=apply_action(st,a,c)
    row.update(result=record_value(d),prepare_seconds=prep,caller_seconds=time.perf_counter()-t,actual_searches=1,root_unchanged=True,pv_legal=True)
    (b/'capacity-results.json').write_text(json.dumps({'rows':rows,'complete':False},indent=2),encoding='utf-8')
   print(name,q,order,'closed',flush=True)
(b/'capacity-results.json').write_text(json.dumps({'rows':rows,'complete':True},indent=2),encoding='utf-8');print('allclosed',len(rows))
