from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.chess_development import root_from_fen
from scripts.research_record import record_value
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
b=Path('.local_agent/wide-interface-20261015');fen='7k/8/5K2/8/8/8/R7/8 w - - 0 1';c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c);s._state=root_from_fen(fen,c);s._search_history_witnesses=(s.state.position,)
class Material:
 v={tid:0 if mt.is_anchor else 100 for tid,mt in c.support.type_metadata.items()}
 def type_value(self,tid):return self.v[tid]
 def evaluate(self,st):return sum((1 if p.owner==st.position.side_to_move else -1)*self.v[p.current_type_id]for p in st.position.board if p)
 def capture_order_value(self,moving,captured):return self.v[captured.current_type_id]
rows=[]
for depth in [1,2]:
 for hard in [0,8]:
  for arm in ['core','native']:
   before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter();limits=SearchLimits(max_depth=depth,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=hard)
   if arm=='core':e=AlphaBetaPlayer(c,evaluator_override=Material(),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));d=e.choose_action(s,limits)
   else:e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=Material.v,hand_values=Material.v,tt_megabytes=0,ordering_cache_enabled=False);d=e.search(s,limits,root_window_pruning=True)
   assert before==(s.state,s.to_record(),s._search_witnesses);rows.append({'arm':arm,'depth':depth,'hard':hard,'result':record_value(d),'seconds':time.perf_counter()-t});print(arm,depth,hard,d.completed_depth,d.result_check_hard_qdepth,d.termination_reason,flush=True)
(b/'q0-checked-contract.json').write_text(json.dumps({'fen':fen,'rows':rows,'scope':'Actualpublicinstalledproduction module; materialK0others100/TT0/noorder/root-tacticaloff. ConstructedFENstate, notplayedGameRecord. Nativepublicq0disableq; Coreq0retainsmandatorycheckedevasionsandhardcensor. Sharednumericparametersare notfullbackend-neutralpolicyidentity. No defaultrepairorstrengthclaim.'},indent=2),encoding='utf-8')
