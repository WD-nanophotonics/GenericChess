from pathlib import Path
import subprocess,sys,json,time
b=Path('.local_agent/wide-interface-20261015');t=time.perf_counter();r=subprocess.run([sys.executable,'-m','pytest','-q','-p','no:cacheprovider','--basetemp',str(b/'full-tests')],capture_output=True,text=True,timeout=600);(b/'full-tests.log').write_text(r.stdout+r.stderr,encoding='utf-8');(b/'full-tests.json').write_text(json.dumps({'exit':r.returncode,'seconds':time.perf_counter()-t,'stdout_tail':r.stdout[-2500:]}),encoding='utf-8');print(r.stdout[-2500:]);raise SystemExit(r.returncode)
