from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(),'<wide_common>','exec'))
import random
r=random.Random(15015);rows=[];oldmodule=original
for _ in range(10000):
 f=dict(to=r.randrange(256),**{'from':r.randrange(256)},promotion=r.choice([255,*range(64)]),base=r.randrange(64),kind=r.choice([2,3]),pattern=r.randrange(256),geometry=r.randrange(4096),actor_current=r.randrange(64))
 if f['kind']==3:f['from']=255
 oldcode=oldmodule.semantic_action_pack(f);g=dict(f);g['promotion']=127 if f['promotion']==255 else f['promotion'];g['from']=1023 if f['kind']==3 else f['from'];newcode=wide.semantic_action_pack(g)
 for target,code in [(wide,oldcode),(oldmodule,newcode)]:
  try:target.semantic_action_unpack(code)
  except ValueError:pass
  else:raise AssertionError('mixedcodec accepted')
prior=ROOT/'.local_agent/q-order-20261015';name,c,s,v,h=generated_cases(prior/'capture_fresh/samples.json')[0];native._MODULE=oldmodule;oldnr=nc.compile_native_semantic_rules(c);oldpayload,_=nc.build_semantic_compile_payload(c);oldnp=pack_semantic_search_position(c,oldnr,s);native._MODULE=wide;newnr=compilewide(c);newpayload,_=buildwide(c);newnp=pack_semantic_search_position(c,newnr,s)
for label,fn in [('oldpayload_to_new',lambda:wide.compile_semantic_rules(oldpayload)),('newpayload_to_old',lambda:oldmodule.compile_semantic_rules(newpayload)),('oldrules_to_new',lambda:wide.semantic_position_snapshot(oldnr.capsule,newnp)),('oldposition_to_new',lambda:wide.semantic_position_snapshot(newnr.capsule,oldnp)),('newrules_to_old',lambda:oldmodule.semantic_position_snapshot(newnr.capsule,oldnp)),('newposition_to_old',lambda:oldmodule.semantic_position_snapshot(oldnr.capsule,newnp))]:
 try:fn()
 except ValueError as error:rows.append({'case':label,'rejected':str(error)})
 else:raise AssertionError(label)
(b/'version-isolation.json').write_text(json.dumps({'random_actions':10000,'mixed_codec_rejections':20000,'capsule_payload_cases':rows,'scope':'Fullsupportedruntime type0..63. Oldrawcodec8bitactor contractnotchanged. Cross-kind layoutdomainsdisjoint forvalidsemanticold/newactions; actualCsampleisfinite. No global_MODULEswap proposedforproduct.'},indent=2),encoding='utf-8');print('20000mixedcodec and6payload/capsule rejections verified')
