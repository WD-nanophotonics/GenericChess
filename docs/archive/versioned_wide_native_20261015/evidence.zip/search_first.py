from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(),'<wide_common>','exec'))
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
import generic_chess.native.semantic_engine as engine_mod
engine_mod.public_action=public
prior=ROOT/'.local_agent/q-order-20261015';cases=generated_cases(prior/'fresh/samples.json')+generated_cases(prior/'capture_fresh/samples.json');cases=[x for x in cases if x[0].split('-')[0]in['2911','2912','3007','3008']]+semantic_cases()
plan={'question':'Does private wideV2 fullsearch retain closed D2/q0or4 objectives with Core onall17 frozen roots?','declared_before_queries':True,'cases':[x[0]for x in cases],'q':[0,4],'hard':8,'depth':2,'seconds_per_query':3,'max_nodes':200000,'max_calls':68,'expected_upper_seconds':204,'evaluation':'0anchor/100others board-current andhand-base, no dynamic/spatial/learnedprices; CoreTT/order/root-tactical off, privateNativeTT0/ordercacheoff; public windowexacttrue. Scores onlycompared where samecompleteddepth+actualq; allcensors/negative retained. Development exposed, no strength/timingclaim.','productwideenabled':False}
(b/'search-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
class Material:
 def __init__(self,c):self.v={tid:0 if m.is_anchor else 100 for tid,m in c.support.type_metadata.items()}
 def type_value(self,tid):return self.v[tid]
 def evaluate(self,state):
  side=state.position.side_to_move
  return sum((1 if x.owner==side else -1)*self.v[x.current_type_id]for x in state.position.board if x)+sum((1 if o==side else -1)*self.v[tid]*count for o,h in enumerate(state.position.hands)for tid,count in h.items())
 def capture_order_value(self,moving,captured):return self.v[captured.current_type_id]
rows=[]
for i,case in enumerate(cases):
 name,c,s,v,h=case;ev=Material(c)
 for q in plan['q']:
  pair={'name':name,'n':c.board_size,'requested_q':q};rows.append(pair)
  for arm in (['core','wide']if i%2==0 else ['wide','core']):
   t=time.perf_counter();before=s.state,s.to_record(),s._search_witnesses
   try:
    limits=SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=3,quiescence_max_depth=q,quiescence_hard_max_depth=8)
    if arm=='wide':
     e=SemanticSearchEngine(c,compilewide(c),board_values=ev.v,hand_values=ev.v,tt_megabytes=0,ordering_cache_enabled=False);d=e.search(s,limits,root_window_pruning=True)
    else:
     e=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,use_native_semantic_availability=False,use_native_semantic_check=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));d=e.choose_action(s,limits)
    assert before==(s.state,s.to_record(),s._search_witnesses)
    st=s.state
    for action in d.principal_variation:assert action in p.legal_actions(st,c);st=apply_action(st,action,c)
    pair[arm]={'result':record_value(d),'caller_seconds':time.perf_counter()-t,'root_unchanged':True,'pv_legal':True}
   except Exception as error:pair[arm]={'error':repr(error),'trace':traceback.format_exc(),'caller_seconds':time.perf_counter()-t};print(name,q,arm,pair[arm]['trace'],flush=True)
  (b/'search-results.json').write_text(json.dumps({'plan':plan,'rows':rows},indent=2),encoding='utf-8');print(name,q,{a:pair[a].get('result',{}).get('completed_depth')for a in ['core','wide']},flush=True)
print('closed',len(rows))
