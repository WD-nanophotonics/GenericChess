from pathlib import Path
import subprocess,sys,sysconfig,json,time
b=Path('.local_agent/wide-interface-20261015').resolve();rows=[]
for capacity in [256,512]:
 src=b/f'src{capacity}';src.mkdir(exist_ok=True)
 for p in (b/'src').iterdir():
  s=p.read_text(encoding='utf-8')
  if p.name=='native_semantic_rules.h':assert s.count('#define GC_SEM_MAX_SQUARES 1024')==1;s=s.replace('#define GC_SEM_MAX_SQUARES 1024',f'#define GC_SEM_MAX_SQUARES {capacity}')
  if p.name=='native_module.c':s=s.replace('_private_wide_v2.gc_semantic_',f'_private_wide_v2_cap{capacity}.gc_semantic_')
  (src/p.name).write_bytes(s.encode())
 out=b/f'wide{capacity}.pyd';cmd=[str(Path('.venv/Lib/site-packages/ziglang/zig.exe').resolve()),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in sorted(src.glob('*.c'))],'-o',str(out)];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(b/f'build{capacity}.log').write_text(r.stdout+r.stderr,encoding='utf-8');rows.append({'capacity':capacity,'exit':r.returncode,'seconds':time.perf_counter()-t});assert r.returncode==0,r.stderr
(b/'capacity-builds.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print(rows)
