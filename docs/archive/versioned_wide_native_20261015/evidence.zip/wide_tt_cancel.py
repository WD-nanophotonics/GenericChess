from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(encoding='utf-8'),'<wide_common>','exec'))
import generic_chess.native.semantic_engine as em
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.movegen import legal_actions
import threading
em.public_action=public
inputs=json.loads((b/'fresh/samples.json').read_text(encoding='utf-8'));cases=[_qualified_case(x)for x in inputs['samples']if x['name']in ['3303-ply0','3303-ply8']];assert len(cases)==2
plan={'question':'Can wide24/fullmany-promotion rules retain TTcontext/cancel/reuse correctness?','roots':[x[0]for x in cases],'max_depth':2,'seconds':4,'q_sequence':[1,4,1,4],'hard':8,'TTMiB':64,'controls':'freshTT0 forEVERYsamequery; compareonlysamecompleteddepth/actualq/hard, allcensors preserved. Twoextra cancellation calls/root maxdepth12/1s then sameenginereuseq0D2.','expected_max_seconds':72,'scope':'Developmentmechanismqualification, notstrength/defaultactivation; noextraAgent/longrun.'};(b/'wide-tt-cancel-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8');rows=[]
def make(c,nr,v,tt):return SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=tt,ordering_cache_enabled=False)
for name,c,s,v,h in cases:
 before=s.state,s.to_record(),s._search_witnesses;nr=compilewide(c);shared=make(c,nr,v,64)
 for q in plan['q_sequence']:
  limits=SearchLimits(max_depth=2,max_time_seconds=4,quiescence_max_depth=q,quiescence_hard_max_depth=8);a=make(c,nr,v,0).search(s,limits,root_window_pruning=True);z=shared.search(s,limits,root_window_pruning=True);same=(a.completed_depth,a.result_ordinary_qdepth,a.result_check_hard_qdepth)==(z.completed_depth,z.result_ordinary_qdepth,z.result_check_hard_qdepth)
  if same:assert a.score==z.score
  for d in [a,z]:
   state=s.state
   for action in d.principal_variation:assert action in legal_actions(state,c);state=apply_action(state,action,c)
  rows.append({'root':name,'q':q,'kind':'TTcontext','sameobjective':same,'fresh':record_value(a),'shared':record_value(z)})
 for mode in ['pre','during']:
  token=CancellationToken();timer=None
  if mode=='pre':token.cancel()
  else:timer=threading.Timer(.02,token.cancel);timer.start()
  try:d=shared.search(s,SearchLimits(max_depth=12,max_time_seconds=1,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True)
  finally:
   if timer:timer.cancel();timer.join()
  assert d.action in s.legal_actions();assert d.termination_reason=='cancelled' or d.completed_depth==12
  recovered=shared.search(s,SearchLimits(max_depth=2,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);assert recovered.completed_depth==2;rows.append({'root':name,'kind':'cancel_'+mode,'result':record_value(d),'reused':record_value(recovered)})
 assert before==(s.state,s.to_record(),s._search_witnesses)
(b/'wide-tt-cancel-results.json').write_text(json.dumps({'rows':rows,'root_state_history_unchanged':True},indent=2),encoding='utf-8');print('TTpairs',sum(x['kind']=='TTcontext'for x in rows),'cancel/reuse',sum(x['kind'].startswith('cancel')for x in rows))
