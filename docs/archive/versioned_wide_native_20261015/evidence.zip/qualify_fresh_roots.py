from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(encoding='utf-8'),'<wide_common>','exec'))
inputs=json.loads((b/'fresh/samples.json').read_text(encoding='utf-8'));rows=[];start=time.monotonic()
for x in inputs['samples']:
 if not x['included']:continue
 if time.monotonic()-start>180:raise TimeoutError('freshrootqualification180sfuse; no extraqueries')
 name,c,s,v,h=_qualified_case(x);before=s.state,s.to_record(),s._search_witnesses;nr=compilewide(c);payload,_=buildwide(c);assert wide.semantic_rules_info(nr.capsule)==payload;np=pack_semantic_search_position(c,nr,s);snap=check_state(c,s,nr,np);actions=tuple(s.legal_actions());codes=wide.semantic_guarded_actions(nr.capsule,np);decoded=tuple(public(nr,code)for code in codes);assert set(decoded)==set(actions),name
 for a,code in zip(decoded,codes):assert pack(nr,s.state.position,a)==code
 assert before==(s.state,s.to_record(),s._search_witnesses);rows.append({'name':name,'n':c.board_size,'all_legal_actions':len(actions),'type_count':len(nr.type_ids),'max_promotion_targets':max(len(t['promo_targets'])for t in payload['types']),'full_history_entries':len(snap['history']),'allfields_action_codes_sha256':hashlib.sha256(json.dumps(sorted(codes)).encode()).hexdigest()});print(name,len(actions),'exactfullfrontier',flush=True)
(b/'fresh/root-qualification.json').write_text(json.dumps({'complete':True,'rows':rows,'seconds':time.monotonic()-start,'scope':'ALL18freshfullroot actionsets/codecidentities/rulepayload reconstruction/board+hands+aux+canonicalkey+exacthistory/events. Selected216PVs separatelychecked Core. Notallfuturestates/branches/allgenerateddomainproof.'},indent=2),encoding='utf-8')
