from pathlib import Path
import re,json,hashlib
b=Path('.local_agent/wide-interface-20261015');out=b/'src';out.mkdir(exist_ok=True)
base=Path('generic_chess/_native')
for p in base.iterdir():
 if p.suffix in ('.h','.c'): (out/p.name).write_bytes(p.read_bytes())
changes=[]
def edit(name,old,new,count=None):
 p=out/name;s=p.read_text(encoding='utf-8');n=s.count(old)
 if count is not None:assert n==count,(name,old,n,count)
 assert n,(name,old);p.write_bytes(s.replace(old,new).encode());changes.append([name,old,new,n])
# Isolate semantic storage; legacy structs/board caps are unchanged.
for p in sorted(out.glob('native_semantic*')):
 if 'GC_MAX_SQUARES' in p.read_text(encoding='utf-8'):edit(p.name,'GC_MAX_SQUARES','GC_SEM_MAX_SQUARES')
edit('native_semantic_rules.h','#define GC_SEMANTIC_PAYLOAD_VERSION 4','#define GC_SEMANTIC_PAYLOAD_VERSION 5\n#define GC_SEM_MAX_SQUARES 1024',1)
edit('native_semantic_rules.c','board_size > 16','board_size > 32',1)
# Private version2 action codec: dense63bits; declaration bit63 remains reserved.
fields=[('TO',0,1023),('FROM',10,1023),('PROMO',20,127),('BASE',27,63),('KIND',33,15),('PATTERN',37,255),('GEOMETRY',45,4095),('ACTOR_CURRENT',57,63)]
macro='\n/* PRIVATE V2 carrier; payload5; no production compatibility claim. */\n'
for name,shift,mask in fields:
 macro+=f'#undef GC_ACTION_{name}_SHIFT\n#define GC_ACTION_{name}_SHIFT {shift}u\n#undef GC_ACTION_{name}_MASK\n#define GC_ACTION_{name}_MASK {mask}ull\n'
edit('native_module.c','static PyObject *gc_semantic_action_pack(',macro+'\nstatic PyObject *gc_semantic_action_pack(',1)
p=out/'native_module.c';s=p.read_text();a,z=s.split('/* PRIVATE V2 carrier;',1);z=z.replace('GC_MAX_SQUARES','GC_SEM_MAX_SQUARES');s=a+'/* PRIVATE V2 carrier;'+z;p.write_bytes(s.encode())
# Runtime gets version2 decoding/packing, and distinct sentinels.
for name,shift,mask in fields:
 fn={'TO':'to','FROM':'from','PROMO':'promo','BASE':'base','KIND':'kind','PATTERN':'pattern','GEOMETRY':'geometry','ACTOR_CURRENT':'current'}[name]
 p=out/'native_semantic_runtime.c';s=p.read_text();pattern=rf'(static uint(?:16|8)_t action_{fn}\(uint64_t a\) \{{ return \(uint(?:16|8)_t\)\().*?(\); \}})'
 s,n=re.subn(pattern,lambda m:m[1]+f'(a >> {shift}) & {mask}u'+m[2],s);assert n==1;p.write_bytes(s.encode())
edit('native_semantic_runtime.c','promo == 255','promo == 127')
edit('native_semantic_runtime.c','promo!=255','promo!=127')
edit('native_semantic_runtime.c','= 255;','= 127;')
edit('native_semantic_runtime.c','source != 255','source != 1023',1)
edit('native_semantic_runtime.c','pack_semantic_action(to,255,255,','pack_semantic_action(to,1023,127,',1)
old='''return ((uint64_t)to) | ((uint64_t)from << 8) | ((uint64_t)promo << 16) |
        ((uint64_t)base << 24) | ((uint64_t)kind << 32) |
        ((uint64_t)pattern << 36) | ((uint64_t)geometry << 44) |
        ((uint64_t)current << 56);'''
new=old.replace('<< 8','<< 10').replace('<< 16','<< 20').replace('<< 24','<< 27').replace('<< 32','<< 33').replace('<< 36','<< 37').replace('<< 44','<< 45').replace('<< 56','<< 57')
edit('native_semantic_runtime.c',old,new,1)
# Rewrite only the rawcodec and candidate generator block (history sentinels stay255).
p=out/'native_module.c';s=p.read_text();start=s.index('static PyObject *gc_semantic_action_pack(');end=s.index('static int gc_semantic_target_holds',start);raw=s[start:end]
raw=raw.replace('v[0] > 255','v[0] > 1023').replace('v[1] > 255','v[1] > 1023').replace('v[2] > 255','v[2] > 127').replace('v[3] > 255','v[3] > 63').replace('v[7] > 255','v[7] > 63').replace('v[1] != 255','v[1] != 1023')
for x,y in [(56,57),(44,45),(36,37),(32,33),(24,27),(16,20),(8,10)]:raw=raw.replace('<< '+str(x)+')','<< '+str(y)+')')
a=raw.index('    uint64_t known =');z=raw.index('    if (action & ~known)',a);raw=raw[:a]+'    uint64_t known = UINT64_C(0x7fffffffffffffff);\n'+raw[z:]
raw=raw.replace('((action >> 8) & 0xFFull) != 255ull','GC_ACTION_FROM(action) != 1023ull')
a=raw.index('        "to", action &');raw=raw[:a]+'''        "to", GC_ACTION_TO(action), "from", GC_ACTION_FROM(action),
        "promotion", GC_ACTION_PROMO(action), "base", GC_ACTION_BASE(action),
        "kind", kind, "pattern", (action >> 37) & 255ull,
        "geometry", (action >> 45) & 4095ull, "actor_current", (action >> 57) & 63ull);
}

'''
s=s[:start]+raw+s[end:]
a=s.index('static int gc_semantic_append_board_candidates') if 'static int gc_semantic_append_board_candidates' in s else s.index('    uint16_t promotions[GC_MAX_PROMO_TARGETS + 1];')
z=s.index('static PyObject *gc_semantic_make_checked',a) if 'static PyObject *gc_semantic_make_checked' in s else s.index('static PyObject *gc_semantic_make',a)
block=s[a:z].replace('= 255;','= 127;').replace('(255ull << 8)','(1023ull << 8)').replace('(255ull << 16)','(127ull << 16)')
for x,y in [(56,57),(44,45),(36,37),(32,33),(24,27),(16,20),(8,10)]:block=re.sub(r'<< '+str(x)+r'\b','<< '+str(y),block)
s=s[:a]+block+s[z:]
s=s.replace('(raw & 0xFFu)','GC_ACTION_TO(raw)').replace('((raw >> 8) & 0xFFu)','GC_ACTION_FROM(raw)').replace('((raw >> 16) & 0xFFu) != 0xFFu','GC_ACTION_PROMO(raw) != 127u').replace('((raw >> 32) & 0xFu)','GC_ACTION_KIND(raw)').replace('promo != 255','promo != 127').replace('promo == 255','promo == 127')
p.write_bytes(s.encode())
# Version the private capsule names as well as the payload; never mix modules.
p=out/'native_module.c';s=p.read_text();s=s.replace('"generic_chess.semantic','"generic_chess.private_wide_v2.semantic');p.write_bytes(s.encode())
manifest={'base_git':'5a5e540917a91ee49b276a6a286dbfea9323f312','scope':'PRIVATE compile/state/edge feasibility only; no public default/guard/ABI changes; legacyGC_MAX_SQUARES remains256; semantic1024; codecV2/payload5','changes':changes,'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(out.iterdir())}}
(b/'source-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print('private source generated',len(manifest['source_hashes']))
