from pathlib import Path
import sys,json,inspect,dataclasses,importlib.util,traceback,time
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
b=ROOT/'.local_agent/wide-interface-20261015';old=ROOT/'.local_agent/q-order-20261015'
exec(compile((old/'common_capture.py').read_text(encoding='utf-8'),str(old/'common_capture.py'),'exec'))
b=ROOT/'.local_agent/wide-interface-20261015'
import generic_chess.native.compiler as nc
import generic_chess.native.semantic as sem
import generic_chess.native.mirror as mirror
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.core.transition import apply_action
from types import SimpleNamespace
from generic_chess.core.identity import position_identity_key
original=native._MODULE
spec=importlib.util.spec_from_file_location('generic_chess._native_core',next(b.glob('_native_core*.pyd')));wide=importlib.util.module_from_spec(spec);spec.loader.exec_module(wide);native._MODULE=wide
ns=dict(nc.__dict__);ns['SEMANTIC_PAYLOAD_VERSION']=5
src=inspect.getsource(nc._native_payload_is_executable).replace('report.board_squares <= 256','report.board_squares <= 1024');exec(src,ns)
src=inspect.getsource(nc.build_semantic_compile_payload).replace('1 <= n <= 16 and n * n <= 256','1 <= n <= 32 and n * n <= 1024');exec(src,ns)
exec(inspect.getsource(nc.compile_native_semantic_rules),ns);compilewide=ns['compile_native_semantic_rules'];buildwide=ns['build_semantic_compile_payload']
# Versioned codec adapter changes only representation sentinels, not public actions.
src=inspect.getsource(sem.public_action).replace('255','127');ps=dict(sem.__dict__);exec(src,ps);public=ps['public_action']
def pack(nr,pos,a):
 fields=mirror._semantic_action_fields(nr,pos,a)
 if fields['promotion']==255:fields['promotion']=127
 if fields['kind']==3:fields['from']=1023
 return wide.semantic_action_pack(fields)
def check_state(c,s,nr,np):
 snap=sem.snapshot(nr,np);ex=mirror.expected_snapshot(s.state.position,nr,c)
 for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(ex[k]),(k,snap[k],ex[k])
 assert snap['ply']==s.state.ply_count
 assert sem.position_key(nr,np)==str(position_identity_key(s.state.position,c))
 assert snap['history_exact'] and snap['history_events_exact'] and len(snap['history'])==len(s.state.history)
 for h,w,e in zip(snap['history'],s._search_witnesses,s.state.history):
  assert ''.join(f'{v:016x}' for v in h)==str(position_identity_key(w,c))
 assert snap['history_events']==tuple((255 if x.actor<0 else x.actor,bool(x.gave_check))for x in s.state.history)
 return snap
prior=ROOT/'.local_agent/q-order-20261015'
