from pathlib import Path
import sys,json,time,random,subprocess
root=Path.cwd();sys.path.insert(0,str(root))
import generic_chess.generation.generator as g
from generic_chess.core.movement import LeapAtom,atom_targets
from generic_chess.core.coordinates import Square
from generic_chess.rules.serialization import serialize_ruleset
b=root/'.local_agent/wide-interface-20261015';rows=[]
def unsafe(rules):
 n=rules.board_size;board=[p for row in rules.initial_position for p in row];types={t.type_id:t for t in rules.piece_types};anchors=[(i,p.owner)for i,p in enumerate(board)if p and types[p.current_type_id].is_anchor];hit=[]
 for target,owner in anchors:
  square=Square(target%n,target//n)
  for source,piece in enumerate(board):
   if not piece or piece.owner==owner:continue
   for atom in types[piece.current_type_id].movement_atoms:
    path=atom_targets(n,piece.owner,Square(source%n,source//n),atom)
    if isinstance(atom,LeapAtom):
     if square in path:hit.append(owner)
    elif square in path:
     for to in path:
      if to==square:hit.append(owner);break
      if board[to.rank*n+to.file]is not None:break
   if owner in hit:break
 return sorted(set(hit))
original=g.compile_ruleset
for seed,n in zip(range(3401,3409),[16,18,24,32]*2):
 row={'seed':seed,'n':n};rows.append(row);t=time.perf_counter()
 def compile_probe(rules):
  before=time.perf_counter();row['raw_attacked_owners']=unsafe(rules);row['raw_check_seconds']=time.perf_counter()-before;row['before_compile_seconds']=before-t;row['ruleset']=json.loads(serialize_ruleset(rules));begin=time.perf_counter()
  try:
   result=original(rules);row['compile_result']='accepted';return result
  except Exception as error:
   row['compile_result']=repr(error);raise
  finally:row['compile_seconds']=time.perf_counter()-begin
 g.compile_ruleset=compile_probe
 try:game=g._try_generate(random.Random(seed),g.GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True));row['attempt_result']='accepted'
 except Exception as error:row['attempt_result']=repr(error)
 row['total_seconds']=time.perf_counter()-t
 if 'raw_attacked_owners'in row:
  if row['raw_attacked_owners']:assert 'INITIAL_ANCHOR_ATTACKED'in row['compile_result']
  else:assert 'INITIAL_ANCHOR_ATTACKED'not in row['compile_result']
 (b/'generation-prefilter-diagnostic.json').write_text(json.dumps({'scope':'PRIVATEliteralraw-atom initialattack check vsactualcompiler on8newfirstattempts; nogenerator/productchange,noretries oroldcensorresurrection. Seed3401..3408selectedbeforetheirresults. Scopeonlylegacyatomgenerator, not arbitrarysemanticrules.','rows':rows},indent=2),encoding='utf-8');print(seed,n,row.get('raw_attacked_owners'),round(row.get('compile_seconds',0),3),flush=True)
