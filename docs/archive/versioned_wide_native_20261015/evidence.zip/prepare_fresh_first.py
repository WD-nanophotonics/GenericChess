from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(),'<wide_common>','exec'))
from generic_chess.rules.serialization import serialize_ruleset
import random,os
out=b/'fresh';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
plan={'question':'Does completeprivatewide execution deliver deeper ACTUALq4 results onnewwidefullrules than existingCorefallback, enough to prioritize productversionedwideAPI?','seeds':list(range(3301,3313)),'sizes':[16,18,24,32]*3,'root_plies':[0,8],'selection':'bilateral_random/hybridtrue; randomseed+7000/reprsortedlegalwalk; no terminalresample; freezeALLinputs beforeANYqueries','arms':['currentCore','privatewide1024'],'evaluation':'same0anchor/100nonanchor board-current/hand-base; nohumanlabels/dynamic/spatial/model/fitting','conditions':'TT0/diskoff/plainmain; CoreexistingNativeavailability/check whenactuallysupported, recordprovider/fallback. PrivateNativepayload5/codecV2 completehistory+effects. q4hard8, fixedD2cap5s; resource2s/16s mainmax12, twooppositeorders; callerprep/packing/PV costrecorded outsidekernelbudget. No ownother cost producer concurrently.','max_slots':288,'query_upper_seconds':24*4*(5+2+16),'single_producer_fuse_seconds':2700,'expected_cost':'Atmost2208squerycaps+setup/PV, estimated<45min single boundedrun; no>1hrun orartificialsplitting, noextraAgent/worker/fee. Smaller17roots1301edges/58regressions/272capacityslotsprecede.','decision':'Samecompleteddepth/actualq/hard scores canqualify finiteobjective; mismatchesstop/diagnose. Differentdepth/policies/censors notscoreevidence orstrength. Ifwidefailedorunhelpful prioritizeCore, ifuseful buildversionedpublicroutewitholdABI preserved; noactivationfromthiscurvealone.','source_git':'5a5e540917a91ee49b276a6a286dbfea9323f312','source_sha256':hashlib.sha256((b/'src/native_module.c').read_bytes()).hexdigest()}
(out/'declaration.json').write_text(json.dumps(plan,indent=2),encoding='utf-8');samples=[]
for seed,n in zip(plan['seeds'],plan['sizes']):
 game=p.generate_game(p.GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True));raw=p.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);session=GameSession(c);rng=random.Random(seed+7000);walk=[]
 for ply in range(9):
  actions=tuple(session.legal_actions())
  if ply in plan['root_plies']:samples.append(dict(name=f'{seed}-ply{ply}',seed=seed,n=n,ruleset=json.loads(serialize_ruleset(game.ruleset)),walk=walk.copy(),state=record_value(session.state),record=record_value(session.to_record()),included=bool(actions),legal_count=len(actions)))
  if ply==8:break
  if not actions:samples.append(dict(name=f'{seed}-ply8',seed=seed,n=n,included=False,terminal_at=ply));break
  a=rng.choice(sorted(actions,key=repr));session.submit(a);walk.append(record_value(a))
 print(seed,n,'frozen',flush=True)
(out/'samples.json').write_text(json.dumps({'samples':samples},indent=2),encoding='utf-8');print('ALLFROZEN',len(samples))
