from pathlib import Path
import sys,json,os
CURRENT=Path('.local_agent/wide-interface-20261015').resolve()
PRIVATE=Path('.local_agent').resolve()
reads=[]
def audit(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).resolve()
  if PRIVATE in path.parents:
   if not (CURRENT==path or CURRENT in path.parents):raise PermissionError('Forbiddenoldprivate dependency: '+str(path))
   reads.append(str(path.relative_to(CURRENT)))
sys.addaudithook(audit)
exec(compile((CURRENT/'wide_common.py').read_text(encoding='utf-8'),str(CURRENT/'wide_common.py'),'exec'))
prior=ROOT/'.local_agent/q-order-20261015'
cases=generated_cases(prior/'fresh/samples.json')+generated_cases(prior/'capture_fresh/samples.json')
selected=[x for x in cases if x[0].split('-')[0]in ['2911','2912','3007','3008']]+semantic_cases()
rows=[]
for name,c,s,v,h in selected:
 row={'name':name,'board_size':c.board_size};rows.append(row);t=time.perf_counter()
 try:
  payload,report=buildwide(c);nr=compilewide(c);assert report.native_executable
  assert wide.semantic_rules_info(nr.capsule)==payload
  np=pack_semantic_search_position(c,nr,s);before=check_state(c,s,nr,np)
  actions=tuple(s.legal_actions());codes=wide.semantic_legal_actions(nr.capsule,np) if hasattr(wide,'semantic_legal_actions')else wide.semantic_guarded_actions(nr.capsule,np)
  decoded=tuple(public(nr,x)for x in codes);assert set(decoded)==set(actions),(name,len(decoded),len(actions),set(decoded)^set(actions))
  edge_rows=[]
  # ALL root actions for bounded complete fixtures, retaining exact states/history.
  for code,a in zip(codes,decoded):
   fields=wide.semantic_action_unpack(code);assert pack(nr,s.state.position,a)==code
   child=wide.semantic_make_checked(nr.capsule,np,code)
   # Core state transition and witnesses come from the actual session submit/undo.
   child_state=apply_action(s.state,a,c);cs=SimpleNamespace(state=child_state,_search_witnesses=(*s._search_witnesses,child_state.position));snap=check_state(c,cs,nr,child)
   edge_rows.append({'fields':fields,'action':record_value(a),'key':sem.position_key(nr,child)})
  assert check_state(c,s,nr,np)==before
  row.update(complete=True,actions=len(actions),edges=edge_rows,history=len(before['history']),seconds=time.perf_counter()-t)
 except Exception as e:
  row.update(complete=False,error=repr(e),trace=traceback.format_exc(),seconds=time.perf_counter()-t)
  print(name,row['trace'],flush=True)
 (b/'qualification-replay.json').write_text(json.dumps({'rows':rows},indent=2),encoding='utf-8')
 print(name,row.get('complete'),row.get('actions'),flush=True)
print('done',len(rows),sum(x.get('actions',0)for x in rows))

(CURRENT/'replay-dependency-audit.json').write_text(json.dumps({'old_private_dependencies_permitted':False,'current_private_reads':sorted(set(reads)),'scope':'Actualsame17root1301edge replay withPythonopen audit rejectingallother .local_agent inputs/binaries. Trackedrepo/tests/runtimeimports allowed. Notacleanmachineinstallationtest.'},indent=2),encoding='utf-8')
