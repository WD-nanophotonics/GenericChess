from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
import pytest,json,hashlib
b=Path('.local_agent/wide-interface-20261015')
class Collector:
 def pytest_collection_finish(self,session):
  nodes=[x.nodeid for x in session.items];(b/'full-collection.json').write_text(json.dumps({'collected':len(nodes),'nodeids_sha256':hashlib.sha256('\n'.join(nodes).encode()).hexdigest(),'nodeids':nodes},indent=2),encoding='utf-8');print('EXACTCOLLECTED',len(nodes))
raise SystemExit(pytest.main(['--collect-only','-q','-p','no:cacheprovider'],plugins=[Collector()]))
