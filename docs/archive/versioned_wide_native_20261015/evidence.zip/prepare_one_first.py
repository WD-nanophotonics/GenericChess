from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(),'<wide_common>','exec'))
from generic_chess.rules.serialization import serialize_ruleset
import random,os
out=b/'fresh';samples=[]
seed,n=map(int,sys.argv[1:3])
if True:
 game=p.generate_game(p.GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True));raw=p.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);session=GameSession(c);rng=random.Random(seed+7000);walk=[]
 for ply in range(9):
  actions=tuple(session.legal_actions())
  if ply in plan['root_plies']:samples.append(dict(name=f'{seed}-ply{ply}',seed=seed,n=n,ruleset=json.loads(serialize_ruleset(game.ruleset)),walk=walk.copy(),state=record_value(session.state),record=record_value(session.to_record()),included=bool(actions),legal_count=len(actions)))
  if ply==8:break
  if not actions:samples.append(dict(name=f'{seed}-ply8',seed=seed,n=n,included=False,terminal_at=ply));break
  a=rng.choice(sorted(actions,key=repr));session.submit(a);walk.append(record_value(a))
 print(seed,n,'frozen',flush=True)

(out/f'input-{seed}.json').write_text(json.dumps({'samples':samples},indent=2),encoding='utf-8')
