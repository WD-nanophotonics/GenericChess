from pathlib import Path
import inspect,hashlib,json,time,random
p=Path('.local_agent/wide-interface-20261015/generation_prefilter.py');src=p.read_text(encoding='utf-8-sig');exec(compile(src.split('original=g.compile_ruleset')[0],'<prefilter-helper>','exec'))
from types import SimpleNamespace
baseline=g._try_generate;source=inspect.getsource(baseline);ns=dict(g.__dict__);ns.update(unsafe=unsafe,SimpleNamespace=SimpleNamespace)
line='    initial_position = build_initial_setup(rng, cfg.setup_preset, n, ids)\n';assert source.count(line)==1;source=source.replace(line,'');mark='    promotion_allowed: dict';at=source.index(mark);source=source[:at]+line+"    if unsafe(SimpleNamespace(board_size=n,piece_types=types,initial_position=initial_position)):\n        raise GenerationError('cheap initial anchor attack rejection')\n\n"+source[at:];exec(compile(source,'<private-fast-initial-filter>','exec'),ns);fast=ns['_try_generate'];(b/'private_fast_generator.py').write_bytes(source.encode());plan={'question':'Can existinggenerator reject alreadyunsafe initialboards beforefullmatrixcompile withoutchangingacceptedrules orRNGtrajectory?','seeds':list(range(3501,3509)),'sizes':[16,18,24,32]*2,'max_attempts':16,'order':'alternate baseline/privatefast byseed; sameallfilters/config/RNG, noresample/frozen32reuse','producer_fuse_seconds':240,'expected_cost':'<4minsequentialCPU, noextraAgent/fees; informationalcost beforepossibleproductchoice, notadmissionframework','decision':'Onlyconsideradoptionifactualacceptedrules/RNGstates identical andsavingsjustifyduplicatedpredicatecost; allgenerationfailures/censorsremain. Primitiveusesexistingatom_targets, scopeonlyrawlegacygeneratornotarbitrarysemanticrules.'};(b/'generator-cost-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8');rows=[];begin=time.monotonic()
for idx,(seed,n)in enumerate(zip(plan['seeds'],plan['sizes'])):
 pair={'seed':seed,'n':n};rows.append(pair)
 for arm in (['baseline','fast']if idx%2==0 else ['fast','baseline']):
  if time.monotonic()-begin>240:raise TimeoutError('generatorcost240sfuse')
  fn=baseline if arm=='baseline'else fast;counter={'attempts':0};last={}
  def counted(rng,cfg):
   counter['attempts']+=1
   try:return fn(rng,cfg)
   finally:last['rng_state_sha256']=hashlib.sha256(repr(rng.getstate()).encode()).hexdigest()
  g._try_generate=counted;t=time.perf_counter()
  try:
   game=g.generate_game(g.GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=16));r={'accepted':True,'ruleset_sha256':hashlib.sha256(serialize_ruleset(game.ruleset).encode()).hexdigest(),'report_attempts':game.generation_report.generation_attempts}
  except g.GenerationError as error:r={'accepted':False,'error':str(error)}
  r.update(counter,**last,seconds=time.perf_counter()-t);pair[arm]=r
 assert pair['baseline']['accepted']==pair['fast']['accepted'] and pair['baseline']['attempts']==pair['fast']['attempts'] and pair['baseline']['rng_state_sha256']==pair['fast']['rng_state_sha256']
 if pair['baseline']['accepted']:assert pair['baseline']['ruleset_sha256']==pair['fast']['ruleset_sha256']
 pair['cost_ratio']=pair['fast']['seconds']/pair['baseline']['seconds'];(b/'generator-cost-results.json').write_text(json.dumps({'complete':False,'rows':rows},indent=2),encoding='utf-8');print(seed,n,'accepted',pair['baseline']['accepted'],'attempts',pair['baseline']['attempts'],'ratio',round(pair['cost_ratio'],3),flush=True)
(b/'generator-cost-results.json').write_text(json.dumps({'complete':True,'rows':rows,'seconds':time.monotonic()-begin},indent=2),encoding='utf-8');print('GENERATORCOSTCLOSED')
