from pathlib import Path
import uuid
base=Path('.local_agent/wide-interface-20261015')
key=uuid.uuid4().hex
source=(base/'qualify_replay.py').read_text(encoding='utf-8')
source=source.replace('qualification-replay.json','verification-'+key+'.json')
source=source.replace('replay-dependency-audit.json','verification-dependencies-'+key+'.json')
exec(compile(source,str(base/'qualify_replay.py'),'exec'))
