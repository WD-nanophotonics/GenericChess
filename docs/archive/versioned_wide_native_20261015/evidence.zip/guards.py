from pathlib import Path
exec(compile(Path('.local_agent/wide-interface-20261015/wide_common.py').read_text(),'<wide_common>','exec'))
import pytest
rawpack,rawunpack=wide.semantic_action_pack,wide.semantic_action_unpack
def compatibility_pack(fields):
 f=dict(fields)
 if f['promotion']==255:f['promotion']=127
 if f['kind']==3 and f['from']==255:f['from']=1023
 return rawpack(f)
def compatibility_unpack(code):
 f=rawunpack(code)
 if f['promotion']==127:f['promotion']=255
 if f['kind']==3 and f['from']==1023:f['from']=255
 return f
wide.semantic_action_pack=compatibility_pack;wide.semantic_action_unpack=compatibility_unpack
nc.SEMANTIC_PAYLOAD_VERSION=5;nc.build_semantic_compile_payload=buildwide
class Recorder:
 def pytest_sessionfinish(self,session,exitstatus):
  (b/'guard-results.json').write_text(json.dumps({'exitstatus':exitstatus,'testscollected':session.testscollected,'failed':session.testsfailed,'scope':'PRIVATE width1024/codecV2 internal; boundary adapter converts only V1sentinels for existing smallboard fixtures. RawC codec independentlyqualified. Not production test result or publicwideenable.'},indent=2),encoding='utf-8')
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--basetemp='+str(b/'test-temp'),'tests/product/test_native_semantic_qsearch.py','tests/product/test_native_terminal_declaration_priority.py','tests/product/test_no_contest_search.py'],plugins=[Recorder()]))
