from pathlib import Path
from dataclasses import replace,asdict
import json,time,hashlib
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.generation.filters import run_soft_filters
from generic_chess.rules.schema import *
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.execution import ExecutableSemanticRuleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
D=Path('.local_agent/recombined-window-20261019');assert not(D/'inputs.json').exists()
start=time.perf_counter();rows=[];roots=[]
for seed in range(681001,681009):
 for board in (10,12):
  assert time.perf_counter()-start<120
  for n in ('rollout','advisor','slack'):
   f=json.loads(Path('.local_agent',n+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
  cfg=GeneratorConfig(seed=seed,board_size=board,setup_preset='classic_like',movement_symmetry='none',allow_hybrid=True,max_generation_attempts=64)
  g=generate_game(cfg);target=sorted(t.type_id for t in g.ruleset.piece_types if not t.is_anchor and not t.is_promotable)[0]
  action=RuleSemanticAction(name='mixed_pair_right',type_ids=tuple(t.type_id for t in g.ruleset.piece_types if not t.is_anchor),geometry=RuleGeometrySpec(kind='leap',offset=(1,2),owner_relative=True),target_relation='empty',composition='augment',aux_state=(RuleAuxState('pair_right','bool','per_owner','persistent',1),),slot_guards=(RuleSlotGuard('pair_right',value=1),),effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),RuleActionEffect('shift',from_ref=RuleSquareRef('offset_from_source',offset=(0,1),owner_relative=True),to_ref=RuleSquareRef('offset_from_source',offset=(0,2),owner_relative=True),piece_owner='self'),RuleActionEffect('set_current_type',square_ref=RuleSquareRef('target'),type_ref=RuleTypeRef('explicit',target)),RuleActionEffect('set_bool',slot_name='pair_right',value=0)),invariants=(RuleInvariant('own_anchor_safe'),))
  rule=replace(g.ruleset,semantic_actions=(action,),metadata={**g.ruleset.metadata,'research_recipe':'four_effect_pair_type_right'})
  c=compile_semantic_ruleset(rule);compile_native_semantic_rules(c)
  report=run_soft_filters(replace(cfg,require_no_opening_win_in_one=True),ExecutableSemanticRuleset.from_compiled(c),{t.type_id:t for t in rule.piece_types})
  v=build_ruleset_profile(g.compiled_ruleset,EvaluationConfig());anchors={t.type_id for t in rule.piece_types if t.is_anchor};name=str(seed)+'-'+str(board)
  s=GameSession(c)
  rows.append(dict(name=name,config=asdict(cfg),rule=ruleset_to_dict(rule),target=target,board_values={t:0 if t in anchors else round(x*.256)for t,x in v.board_value_by_type.items()},hand_values={t:0 if t in anchors else round(x*.256)for t,x in v.hand_value_by_base_type.items()},special_pattern_ids=[x.pattern_id for x in c.ir.patterns if x.name=='mixed_pair_right'],final_preference=record_value(report),final_preference_passed=all(x.passed for x in report)))
  roots.append(dict(name=name,phase=0,record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state),history=record_value(s.history),witnesses=record_value(s._search_witnesses)))
write_json(D/'inputs.json',dict(rules=rows,roots=roots,seconds=time.perf_counter()-start,Native_searches=0,Core_searches=0,selection='Allpredeclaredinputs,no outcome/preference rejections'))
print('INPUTS',len(rows),sum(x['final_preference_passed']for x in rows),time.perf_counter()-start)
