"""Cost gate for a known four-effect type-conversion root hint; no child prepass."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;start=time.perf_counter();deadline=start+180
inp=json.loads((D.parent/'recombined-window-20261019/inputs.json').read_bytes());roots={x['name']:x for x in inp['roots']}
assert not(D/'result.json').exists()
counts=Counter();rows=[];status='COMPLETE';error=None
def poll():
 assert time.perf_counter()<deadline
 for n in ('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def hint(c,nr,s,row,allowance):
 t=time.perf_counter();aa=s.legal_actions();choices=[]
 for a in aa:
  if getattr(a,'pattern_id',None)in row['special_pattern_ids']:
   gain=row['board_values'][row['target']]-row['board_values'][a.actor_type_id]
   if gain>0:choices.append((gain,pack_semantic_action(nr,s.state.position,a),a))
 choices.sort(key=lambda x:(-x[0],x[1]));elapsed=time.perf_counter()-t
 return (choices[0][2]if choices and elapsed<allowance else None),dict(status='COMPLETE'if elapsed<allowance else'PRIOR_TIME_CAP',seconds=elapsed,full_legal_count=len(aa),positive_conversion_candidates=[dict(gain=x[0],packed=x[1],action=record_value(x[2]))for x in choices],selected=record_value(choices[0][2])if choices and elapsed<allowance else None)
try:
 for row in inp['rules']:
  poll();c=compile_semantic_ruleset(ruleset_from_dict(row['rule']));nr=compile_native_semantic_rules(c)
  for depth,allowance in ((2,1.),(8,.05)):
   for method in ('baseline','conversion_hint'):
    poll();t=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(roots[row['name']]['record'])));restore=time.perf_counter()-t
    before=(s.state,s.to_record(),s.history,s._search_witnesses);e=SemanticSearchEngine(c,nr,board_values=row['board_values'],hand_values=row['hand_values'],tt_megabytes=0)
    t=time.perf_counter();h=None;pre=None
    if method=='conversion_hint':h,pre=hint(c,nr,s,row,allowance)
    elapsed=time.perf_counter()-t;left=allowance-elapsed
    z=e.search(s,SearchLimits(max_depth=depth,max_nodes=131072 if depth==2 else None,max_time_seconds=left,quiescence_max_depth=0),root_window_pruning=True,root_order_hint=h)if left>0 else None
    total=time.perf_counter()-t
    rr=dict(name=row['name'],depth=depth,allowance=allowance,method=method,restore_seconds=restore,prior=pre,result=record_value(z)if z else None,caller_seconds=total)
    if z:
     leaf=copy(s)
     for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['PV_edges']+=1
     counts['Native_queries']+=1;counts['main']+=z.nodes;counts['q']+=z.qnodes
    assert before==(s.state,s.to_record(),s.history,s._search_witnesses);rows.append(rr);del e
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,rows=rows,counts=dict(counts),seconds=time.perf_counter()-start,scope='ALL16alreadygeneratedfour-effect10/12rules, D2/1s and D8/50ms, baseline vs knownconversion materialgain hint. Full Corelegality cost deducted, no child/evaluator preprocessing, no fit, no arbitrarysemantic generality. Not utility/trainability/default claim. Incomplete remainUNKNOWN.'))
print('CONVERSION_HINT_GATE',status,error,dict(counts),time.perf_counter()-start)
