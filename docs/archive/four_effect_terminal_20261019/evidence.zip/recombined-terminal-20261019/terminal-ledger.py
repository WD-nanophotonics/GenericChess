"""One paired terminal/censoring ledger on the existing64slots; no new games."""
from pathlib import Path
from collections import Counter,defaultdict
import sys,json,time,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=Path(__file__).resolve().parent;start=time.perf_counter();stats=Counter()
p=json.loads((D/'plan.json').read_bytes());inp=json.loads((D/'inputs.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['rows'];res=json.loads((D/'result.json').read_bytes())
rules={x['name']:x for x in inp['rules']};roots={x['name']:x for x in inp['roots']};comp={n:compile_semantic_ruleset(ruleset_from_dict(x['rule']))for n,x in rules.items()};games={x['slot']:x for x in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())}
assert len(slots)==64
cost=defaultdict(lambda:dict(queries=0,main=0,q=0,caller_seconds=0,after96_queries=0,after96_main=0,after96_q=0,after96_caller_seconds=0))
for line in(D/'queries.jsonl').open(encoding='utf8'):
 x=json.loads(line);z=x['result'];r=cost[x['slot']];r['queries']+=1;r['main']+=z['nodes'];r['q']+=z['qnodes'];r['caller_seconds']+=x['caller_seconds']
 if x['relative_ply']>=96:r['after96_queries']+=1;r['after96_main']+=z['nodes'];r['after96_q']+=z['qnodes'];r['after96_caller_seconds']+=x['caller_seconds']
rows=[]
def reward(s,owner):return None if s.result.status.value=='ongoing'else 0 if s.result.winner is None else 1 if s.result.winner==owner else-1
for idx,slot in enumerate(slots):
 assert time.perf_counter()-start<300
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 g=games.get(idx);prefix_reward=None;final_reward=None;reason='MISSING_UNKNOWN';prefix_terminal=False;actual512=False
 if g:
  assert all(g[k]==v for k,v in slot.items());c=comp[g['name']];s=GameSession.replay(c,deserialize_game_record(json.dumps(roots[g['name']]['record'])));record=deserialize_game_record(json.dumps(g['record']))
  for a in record.actions[:96]:s.submit(a);stats['prefix_Core_commits']+=1
  prefix_reward=reward(s,g['owner']);prefix_terminal=prefix_reward is not None;final=GameSession.replay(c,record);assert record_value(final.result)==g['result'];final_reward=reward(final,g['owner']);assert final_reward==g['reward']
  stats['final_record_Core_commits']+=len(record.actions)
  if prefix_terminal:assert prefix_reward==final_reward;reason='AT_OR_BEFORE96_TERMINAL'
  elif final_reward is None:reason='STILL_UNKNOWN'
  elif final.result.winner is not None:reason='AFTER96_WIN_LOSS'
  elif final.result.status.value=='max_ply':
   assert final.state.ply_count==rules[g['name']]['rule']['max_ply']==512 and len(record.actions)==512
   actual512=True;reason='AFTER96_RULE_MAX_DRAW';stats['verified_postsubmit512_terminal']+=1
  elif 'repetition'in final.result.status.value:reason='AFTER96_REPETITION_DRAW'
  else:reason='AFTER96_OTHER_DRAW'
 stats[reason]+=1;rows.append(dict(slot=idx,**slot,prefix96_reward=prefix_reward,actual_rule_reward=final_reward,terminal_class=reason,actual_postsubmit512=actual512,cost=cost[idx],final_reason=g['result']['status']if g else None,final_query_count=len(g['queries'])if g else None))
def pair_interval(x,y):
 return[(-1 if x is None else x)-(1 if y is None else y),(1 if x is None else x)-(-1 if y is None else y)]
pairs=[];summary={}
for foe in p['foes']:
 selected=[x for x in rows if x['foe']==foe];pp=[]
 for name,owner in sorted({(x['name'],x['owner'])for x in selected}):
  a=next(x for x in selected if x['name']==name and x['owner']==owner and x['mode']);b=next(x for x in selected if x['name']==name and x['owner']==owner and not x['mode'])
  old=pair_interval(a['prefix96_reward'],b['prefix96_reward']);new=pair_interval(a['actual_rule_reward'],b['actual_rule_reward'])
  pp.append(dict(name=name,foe=foe,owner=owner,true_slot=a['slot'],false_slot=b['slot'],true_class=a['terminal_class'],false_class=b['terminal_class'],prefix96_contribution_bounds=old,actual_rule_contribution_bounds=new,fully_resolved=a['actual_rule_reward']is not None and b['actual_rule_reward']is not None,both_rule_max_draw=a['terminal_class']==b['terminal_class']=='AFTER96_RULE_MAX_DRAW'))
 pairs+=pp;n=len(pp);old=[sum(x['prefix96_contribution_bounds'][i]for x in pp)/n for i in(0,1)];new=[sum(x['actual_rule_contribution_bounds'][i]for x in pp)/n for i in(0,1)]
 summary[foe]=dict(planned_pairs=n,fully_resolved=sum(x['fully_resolved']for x in pp),both_rule_max_draw_pairs=sum(x['both_rule_max_draw']for x in pp),prefix96_True_minus_False=old,actual_rule_True_minus_False=new,width_reduction=(old[1]-old[0])-(new[1]-new[0]),classes=dict(Counter(x['terminal_class']for x in selected)),cost={k:sum(x['cost'][k]for x in selected)for k in next(iter(cost.values()))})
assert sum(x['queries']for x in cost.values())==res['counts']['queries']
write_json(D/'terminal-ledger.json',dict(status='PASS_PAIRED_TERMINAL_LEDGER',rows=rows,pairs=pairs,summary=summary,counts=dict(stats),seconds=time.perf_counter()-start,producer_seconds=res['seconds'],Native_calls=0,new_games=0,old_UNKNOWN_refilled=0,scope='SameSAVEDnew64trajectories prefix96 bookkeeping vsactualboundedruleterminals; notindependentH96executions, crossbatch causalcomparison, unboundedgame strength or populationeffect. Querycaller increment excludesrecording/restore overhead, wholeproducerwallreportedseparately. Knownside ofUNKNOWNpairs alwaysretained.'))
print('TERMINAL_LEDGER',json.dumps(summary),dict(stats),time.perf_counter()-start)
