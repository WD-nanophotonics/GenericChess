"""Retrospective exact finite-panel certificate/cost curve, no new execution."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;p=json.loads((D/'plan.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['rows'];games={x['slot']:x for x in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};cost={}
for line in(D/'queries.jsonl').open(encoding='utf8'):
 q=json.loads(line);c=cost.setdefault(q['slot'],dict(queries=0,main=0,q=0,caller_seconds=0));c['queries']+=1;c['main']+=q['result']['nodes'];c['q']+=q['result']['qnodes'];c['caller_seconds']+=q['caller_seconds']
def interval(foe,k):
 rr=[(i,x)for i,x in enumerate(slots)if x['foe']==foe];n=sum(not x['mode']for i,x in rr);known=0;u=0
 for i,x in rr:
  r=games[i]['reward']if i<k and i in games else None
  if r is None:u+=1
  else:known+=(1 if x['mode']else-1)*r
 return[(known-u)/n,(known+u)/n]
curve=[]
for k in range(len(slots)+1):
 bb={foe:interval(foe,k)for foe in p['foes']};cc={field:sum(cost.get(i,{}).get(field,0)for i in range(k))for field in('queries','main','q','caller_seconds')}
 curve.append(dict(completed_slots=k,finite_bounds=bb,both_strict_positive=all(v[0]>0 for v in bb.values()),paid_query_cost=cc,recorded_game_service_seconds=sum(games[i]['seconds']for i in range(k)if i in games)))
first=next((x for x in curve if x['both_strict_positive']),None);last=curve[-1]
out=dict(status='PASS_RECORDED_ORDER_FINITE_CERTIFICATE_CURVE',curve=curve,first_strict_positive=first,last=last,omittable_tail_query_cost={k:last['paid_query_cost'][k]-first['paid_query_cost'][k]for k in last['paid_query_cost']}if first else None,new_games=0,new_searches=0,scope='Retrospectiveexistingclosed64fixedtrajectories/originalslotcompletionorder only. Worstcase[-1,1]retainsknownsides, exactfinitepanel certificate notpopulation/statisticalconfidence orhypotheticaltime-budgetedexecutionequivalence. Recordedquery/servicecost only, notactualsavedwholewall; no newrunner/framework/default adopted.')
write_json(D/'stopping-ledger.json',out);print('FINITE_CERTIFICATE',first,'tail',out['omittable_tail_query_cost'])
