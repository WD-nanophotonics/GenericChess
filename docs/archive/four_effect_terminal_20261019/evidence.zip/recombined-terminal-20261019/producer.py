"""Prospective complete compound-window consumer, existing Session runner."""
from pathlib import Path
import sys,json,time,random,hashlib,traceback,os
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
R=Path.cwd();D=Path(__file__).resolve().parent;I=D;P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();counts=Counter();closed=[];current=None;status='COMPLETE';error=None
assert not(D/'games.jsonl').exists()
inp=json.loads((I/'inputs.json').read_bytes());rules={r['name']:r for r in inp['rules']};roots={p['name']:p for p in inp['roots']if p['phase']==0};assert len(rules)==len(roots)==8
slots=[dict(name=name,owner=o,foe=f,mode=m)for name in sorted(rules)for o in P['candidate_owners']for f in P['foes']for m in P['window_modes']];random.Random(P['random_order_seed']).shuffle(slots);assert len(slots)==P['planned_physical']
write_json(D/'slots.json',dict(rows=slots));write_json(D/'inputs.json',inp)
write_json(D/'producer-source.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),clock='singlecontinuousperf_counter includes compilation/recording',reused_inputs_sha256=hashlib.sha256((I/'inputs.json').read_bytes()).hexdigest()))
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 if time.perf_counter()-start>=P['global_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for n in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')
def reward(s,owner):
 if s.result.status.value=='ongoing':return None
 return 0 if s.result.winner is None else 1 if s.result.winner==owner else-1
comp={name:compile_semantic_ruleset(ruleset_from_dict(row['rule']))for name,row in rules.items()}
nr={name:compile_native_semantic_rules(c)for name,c in comp.items()}
try:
 with(D/'queries.jsonl').open('x',encoding='utf8',newline='\n')as ql,(D/'games.jsonl').open('x',encoding='utf8',newline='\n')as gl:
  for index,slot in enumerate(slots):
   poll();name=slot['name'];row=rules[name];c=comp[name];s=GameSession.replay(c,deserialize_game_record(json.dumps(roots[name]['record'])));owner=slot['owner'];tick=time.perf_counter();current=dict(slot=index,**slot);engines=[]
   for side in (0,1):
    b=row['board_values'];h=row['hand_values']
    if side!=owner and slot['foe']=='unit':
     anchors={t['type_id']for t in row['rule']['piece_types']if t['is_anchor']};b={t:0 if t in anchors else 256 for t in b};h={t:0 if t in anchors else 256 for t in h}
    engines.append(SemanticSearchEngine(c,nr[name],board_values=b,hand_values=h,tt_megabytes=0))
   local=Counter();ending='HORIZON_UNKNOWN';first_aux={};qids=[]
   for ply in range(P['horizon']):
    poll()
    if s.result.status.value!='ongoing':ending='ACTUAL_TERMINAL';break
    side=s.state.position.side_to_move;candidate=side==owner;lim=P['candidate']if candidate else P['foe'];before=(s.state,s.to_record(),s.history,s._search_witnesses);beforehash=digest(s.state)
    if P['global_seconds']-(time.perf_counter()-start)<lim['seconds']+.1:raise TimeoutError('GLOBAL_CAP_BEFORE_FULL_QUERY')
    qt=time.perf_counter();z=engines[side].search(s,SearchLimits(max_depth=lim['depth'],max_nodes=lim['nodes'],max_time_seconds=lim['seconds'],quiescence_max_depth=lim['qdepth']),root_window_pruning=slot['mode']if candidate else False);elapsed=time.perf_counter()-qt;assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
    commit=None
    if z.used_fallback or z.completed_depth<1:ending='SEARCH_LIMIT_UNKNOWN'
    elif z.declaration_id is not None:s.declare(z.declaration_id);commit=z.declaration_id
    elif z.action is None:ending='NO_ACTION_UNKNOWN'
    else:
     assert z.action in s.legal_actions();a=z.action;pre=s.state.position;s.submit(a);commit=record_value(a);local['commits']+=1
     local['drops']+=hasattr(a,'base_type_id');local['promotions']+=getattr(a,'promotion_target_id',None)is not None;local['augmented']+=getattr(a,'pattern_id',None)in row['special_pattern_ids']
     local['aux_changes']+=pre.aux_state!=s.state.position.aux_state
    qid=counts['queries'];ql.write(json.dumps(dict(query=qid,slot=index,relative_ply=ply,actor=side,candidate=candidate,before_sha256=beforehash,after_sha256=digest(s.state),committed=commit,result=record_value(z),caller_seconds=elapsed),separators=(',',':'))+'\n');ql.flush();qids.append(qid)
    local['queries']+=1;local['main']+=z.nodes;local['q']+=z.qnodes;counts['queries']+=1;counts['main']+=z.nodes;counts['q']+=z.qnodes
    if ending in ('SEARCH_LIMIT_UNKNOWN','NO_ACTION_UNKNOWN'):break
   if s.result.status.value!='ongoing':ending='ACTUAL_TERMINAL'
   check=GameSession.replay(c,s.to_record());assert(check.state,check.history,check._search_witnesses,check.result)==(s.state,s.history,s._search_witnesses,s.result)
   current.update(ending=ending,reward=reward(s,owner),result=record_value(s.result),record=json.loads(serialize_game_record(s.to_record())),final_state_sha256=digest(s.state),final_witness_sha256=digest(s._search_witnesses),queries=qids,counts=dict(local),seconds=time.perf_counter()-tick)
   gl.write(json.dumps(current,separators=(',',':'))+'\n');gl.flush();closed.append(current);current=None;counts['games']+=1
   del engines
   if counts['games']%8==0:print('AUX_SERVICE_GAMES',counts['games'],counts['queries'],round(time.perf_counter()-start,3),flush=True)
   if ql.tell()+gl.tell()>P['max_output_bytes']:raise TimeoutError('OUTPUT_CAP')
except BaseException as exc:status='INCOMPLETE';error=repr(exc);traceback.print_exc()
write_json(D/'result.json',dict(status=status,error=error,planned=P['planned_physical'],closed=len(closed),missing=P['planned_physical']-len(closed),terminal=sum(g['ending']=='ACTUAL_TERMINAL'for g in closed),unknown=sum(g['reward']is None for g in closed),counts=dict(counts),current_unclosed=current,seconds=time.perf_counter()-start,scope='Prospective8completefour-effect10/12rules/4linkedseeds.64NEWphysicalslots ruleterminalH512, staticcandidate True/False andtwofixedfoes/bothowners. Notpricingcompoundeffects, independentpopulation/default/learning claim. No priorpooling/refill.'))
print('AUX_SERVICE_CLOSED',status,error,len(closed),counts,round(time.perf_counter()-start,3),flush=True)
