"""Audit actual joint-effect lifecycles in saved games, without search."""
from pathlib import Path
from collections import Counter
import sys,os,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square,square_to_index
D=Path(__file__).resolve().parent;start=time.perf_counter();counts=Counter();examples=[]
p=json.loads((D/'inputs.json').read_bytes());rules={x['name']:x for x in p['rules']};roots={x['name']:x for x in p['roots']};cc={n:compile_semantic_ruleset(ruleset_from_dict(x['rule']))for n,x in rules.items()}
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
stream=(json.loads(x)for x in(D/'queries.jsonl').open(encoding='utf8'));q=next(stream,None)
for line in(D/'games.jsonl').open(encoding='utf8'):
 assert time.perf_counter()-start<180
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 g=json.loads(line);row=rules[g['name']];c=cc[g['name']];s=GameSession.replay(c,deserialize_game_record(json.dumps(roots[g['name']]['record'])));slot,=c.ir.aux_slots;uses=Counter()
 while q is not None and q['slot']==g['slot']:
  if q['committed']is not None:
   a=decode(q['committed']);before=s.state.position
   if isinstance(a,str):s.declare(a)
   else:
    target=square_to_index(a.to_square,c.board_size);victim=before.board[target]
    if victim is not None and victim.owner!=before.side_to_move:
     counts['captures_of_current_base_distinct']+=victim.current_type_id!=victim.base_type_id
    s.submit(a);after=s.state.position
    if isinstance(a,SemanticDropMove):
     x=after.board[target];assert x.base_type_id==x.current_type_id==a.base_type_id and not x.promoted;counts['drop_base_current_reset']+=1
    if getattr(a,'pattern_id',None)in row['special_pattern_ids']:
     owner=before.side_to_move;uses[owner]+=1;assert uses[owner]==1
     src=square_to_index(a.from_square,c.board_size);actor=before.board[src];moved=after.board[target];changed=[i for i,(x,y)in enumerate(zip(before.board,after.board))if x!=y];assert len(changed)==4
     assert moved.owner==actor.owner and moved.base_type_id==actor.base_type_id and moved.current_type_id==row['target']and moved.promoted==(row['target']!=actor.base_type_id)
     v0=dict(before.aux_state).get((slot.slot_id,owner),slot.initial);v1=dict(after.aux_state).get((slot.slot_id,owner),slot.initial);other=1-owner
     assert v0==1 and v1==0 and dict(before.aux_state).get((slot.slot_id,other),slot.initial)==dict(after.aux_state).get((slot.slot_id,other),slot.initial)
     counts['compound_commits']+=1;counts['actual_type_changes']+=actor.current_type_id!=row['target'];counts['noop_type_assignments']+=actor.current_type_id==row['target'];counts['oneuse_right_consumptions']+=1
     gain=row['board_values'][row['target']]-row['board_values'][actor.current_type_id];counts['positive_immediate_material_gains']+=gain>0;counts['negative_immediate_material_gains']+=gain<0
     if len(examples)<8:examples.append(dict(name=g['name'],slot=g['slot'],query=q['query'],action=q['committed'],base=actor.base_type_id,before_current=actor.current_type_id,after_current=moved.current_type_id,material_delta=gain,changed=changed,after_sha256=digest(s.state)))
  q=next(stream,None)
 counts['games']+=1
assert q is None
write_json(D/'mechanism-audit.json',dict(status='PASS_ACTUAL_JOINT_EFFECT_LIFECYCLES',counts=dict(counts),examples=examples,seconds=time.perf_counter()-start,search_calls=0,scope='AllactualfullCoregamehistories, fourchangedsquares, base/current/promoted/rightconsumption anddropreset. Capturedchangedtype includes ordinarypromotions; no attribution tocompound withoutancestry. Staticgain != strategicvalue/utility.'))
print('JOINT_EFFECT_AUDIT',dict(counts),time.perf_counter()-start)
