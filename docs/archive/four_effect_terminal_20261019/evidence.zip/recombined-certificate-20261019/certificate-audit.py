"""Independent paired arithmetic of the prospective finite certificate."""
from pathlib import Path
from collections import Counter
import sys,json
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;p=json.loads((D/'plan.json').read_bytes());res=json.loads((D/'result.json').read_bytes());analysis=json.loads((D/'analysis.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['rows'];games={x['slot']:x for x in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};n=len(games)
assert len(slots)==p['planned_physical']==64 and n==res['closed']and sorted(games)==list(range(n))and res['current_unclosed']is None and res['missing']==64-n
for i,g in games.items():assert all(g[k]==v for k,v in slots[i].items())
def bounds(foe,k):
 pairs={}
 for i,x in enumerate(slots):
  if x['foe']==foe:pairs.setdefault((x['name'],x['owner']),{})[x['mode']]=i
 total=[0,0]
 for v in pairs.values():
  ti,fi=v[True],v[False];a=games[ti]['reward']if ti<k else None;b=games[fi]['reward']if fi<k else None
  total[0]+=(-1 if a is None else a)-(1 if b is None else b);total[1]+=(1 if a is None else a)-(-1 if b is None else b)
 return[x/len(pairs)for x in total]
curve=[dict(closed=k,bounds={foe:bounds(foe,k)for foe in p['foes']})for k in range(n+1)]
first=next((x for x in curve if all(v[0]>0 for v in x['bounds'].values())),None)
if res['status']=='CERTIFIED_EARLY':
 assert first is not None and first['closed']==n and first['bounds']==res['certificate']['bounds']
 assert res['certificate']['planned']==64 and res['certificate']['unexecuted']==64-n
else:assert first is None
for foe in p['foes']:assert bounds(foe,n)==analysis['contrasts'][foe]['True_minus_False']
unexecuted=[dict(slot=i,**slots[i],outcome='UNEXECUTED_UNKNOWN',reward_interval=[-1,1])for i in range(n,64)]
out=dict(status='PASS_PROSPECTIVE_FINITE_CERTIFICATE',planned=64,closed=n,actual_early=n<64 and res['status']=='CERTIFIED_EARLY',unexecuted=n and 64-n,all_unexecuted_slots=unexecuted,first_strict_positive=first,paired_independent_curve=curve,known_terminal=sum(g['reward']is not None for g in games.values()),recorded_UNKNOWN=sum(g['reward']is None for g in games.values()),queries=res['counts']['queries'],main=res['counts']['main'],q=res['counts']['q'],producer_seconds=res['seconds'],new_games=0,new_searches=0,scope='Pairedindependentknownsidepreservingintervals overALL64plannedslots; prospectivefirststopverified withoutfutureoutcomes. Missingphysicalslots remainUNKNOWN, notdraws/successes. Conditionalfinitepanelcertificate only, notpopulationconfidence,WDLproof or actualsavedwall forunexecutedwork.')
write_json(D/'certificate-audit.json',out);print('CERTIFICATE_AUDIT',n,64-n,first,res['seconds'])
