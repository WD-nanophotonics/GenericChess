"""Optional coldD3 control on exact actual both-consumed-right histories."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();deadline=start+P['global_seconds'];inp=json.loads((D/'inputs.json').read_bytes());assert not(D/'result.json').exists()
class Stop:
 def __init__(self):self.next=0;self.stop=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in('rollout','advisor','slack'):
    f=json.loads(Path('.local_agent',n+'.json').read_bytes());self.stop|=bool(f.get('stopped')or f.get('user_paused'))
  return self.stop or now>=deadline
stop=Stop()
def poll():
 if stop.is_cancelled():raise TimeoutError('REAL_STOP_OR_GLOBAL900S')
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
class Material:
 def __init__(self,p):self.b=p['board_values'];self.h=p['hand_values']
 def evaluate(self,s):
  v=sum((1 if x.owner==0 else-1)*self.b[x.current_type_id]for x in s.position.board if x)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items())
  return v*(1 if s.position.side_to_move==0 else-1)
rows=[];counts=Counter();status='COMPLETE';error=None
try:
 for p in inp['parents']:
  poll();c=compile_semantic_ruleset(ruleset_from_dict(p['rule']));nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));assert digest(s.state)==p['state_sha256']and digest(s._search_witnesses)==p['witness_sha256'];before=(s.state,s.to_record(),s.history,s._search_witnesses);row=dict(name=p['name'],state_sha256=p['state_sha256'],native=[],core=None);rows.append(row)
  for mode in(False,True):
   poll();e=SemanticSearchEngine(c,nr,board_values=p['board_values'],hand_values=p['hand_values'],tt_megabytes=0);t=time.perf_counter();z=e.search(s,SearchLimits(max_depth=3,max_nodes=P['Native_nodes'],max_time_seconds=min(P['Native_seconds'],deadline-time.perf_counter()),quiescence_max_depth=0),root_window_pruning=mode)
   leaf=copy(s)
   for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['PV_edges']+=1
   row['native'].append(dict(mode=mode,result=record_value(z),seconds=time.perf_counter()-t,leaf_state_sha256=digest(leaf.state)));counts['Native_queries']+=1;counts['Native_main']+=z.nodes;counts['Native_q']+=z.qnodes;del e
  poll();st=SearchStatistics();t=time.perf_counter();a,score,pv,cause=run_root_search(s.state,c,Material(p),TranspositionTable(max_entries=1),SearchLimits(max_depth=3,max_nodes=P['Core_nodes'],max_time_seconds=min(P['Core_seconds'],deadline-time.perf_counter()),quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
  ref=dict(action=record_value(a),score=score,pv=record_value(pv),cause=cause,statistics=record_value(st),seconds=time.perf_counter()-t,complete=st.completed_depth==3 or cause=='root_immediate_win');row['core']=ref;counts['Core_queries']+=1;counts['Core_main']+=st.nodes;counts['Core_q']+=st.qnodes;counts['Core_complete']+=ref['complete'];counts['Core_UNKNOWN']+=not ref['complete']
  mapped=score-900000000 if score>=900000000 else score+900000000 if score<=-900000000 else score
  for x in row['native']:
   x['comparable']=ref['complete']and x['result']['completed_depth']==3;x['score_matches_Core']=x['result']['score']==mapped if x['comparable']else None;counts['comparable']+=x['comparable'];counts['mismatch']+=x['score_matches_Core']is False
  assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
  print('LATE_D3',p['name'],ref['complete'],cause,st.nodes,round(time.perf_counter()-start,3),flush=True)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,rows=rows,counts=dict(counts),seconds=time.perf_counter()-start,planned_roots=P['planned_roots'],missing_inputs=inp['missing_names'],scope='OneoptionalfiniteD3scalarcheck onactualbothconsumed-rightstates. Exposed/event-selected8roots, notWDL/population/utility/admissiongate; interruptedCorework/UNKNOWN retained,no refills. Concurrentloadlimitswallinterpretation.'))
print('LATE_D3_CLOSED',status,error,dict(counts),time.perf_counter()-start,flush=True)
