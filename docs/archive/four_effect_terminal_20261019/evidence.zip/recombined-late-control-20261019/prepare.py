from pathlib import Path
import json,sys,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path('.local_agent/recombined-late-control-20261019');assert not(D/'inputs.json').exists();S=D.parent/'recombined-window-20261019';start=time.perf_counter()
inp=json.loads((S/'inputs.json').read_bytes());rules={x['name']:x for x in inp['rules']if x['name'].endswith('-12')};roots={x['name']:x for x in inp['roots']};games={x['slot']:x for x in map(json.loads,(S/'games.jsonl').read_bytes().splitlines())};selected={};sessions={};compiled={}
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
for line in(S/'queries.jsonl').open(encoding='utf8'):
 assert time.perf_counter()-start<120
 q=json.loads(line);g=games[q['slot']];name=g['name']
 if name not in rules or name in selected:continue
 for n in('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 if q['slot']not in sessions:
  if name not in compiled:compiled[name]=compile_semantic_ruleset(ruleset_from_dict(rules[name]['rule']))
  sessions[q['slot']]=GameSession.replay(compiled[name],deserialize_game_record(json.dumps(roots[name]['record'])))
 s=sessions[q['slot']];assert digest(s.state)==q['before_sha256'];slot,=compiled[name].ir.aux_slots;aux=dict(s.state.position.aux_state)
 if all(aux.get((slot.slot_id,o),slot.initial)==0 for o in(0,1)):
  selected[name]=dict(name=name,rule=rules[name]['rule'],board_values=rules[name]['board_values'],hand_values=rules[name]['hand_values'],record=json.loads(serialize_game_record(s.to_record())),state_sha256=digest(s.state),witness_sha256=digest(s._search_witnesses),actual_source_slot=q['slot'],actual_source_query=q['query'],relative_ply=q['relative_ply'],aux_state=record_value(s.state.position.aux_state),original_receipt=q['result'])
 else:
  if q['committed']is not None:
   a=decode(q['committed']);s.declare(a)if isinstance(a,str)else s.submit(a)
 if len(selected)==len(rules):break
write_json(D/'inputs.json',dict(parents=[selected[n]for n in sorted(selected)],planned_names=sorted(rules),missing_names=sorted(set(rules)-set(selected)),seconds=time.perf_counter()-start,Native_calls=0,new_games=0))
print('LATE_INPUTS',len(selected),'missing',sorted(set(rules)-set(selected)),time.perf_counter()-start)
