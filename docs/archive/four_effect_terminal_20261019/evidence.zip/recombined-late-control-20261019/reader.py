"""Rebuild only closed optional D3 references, preserving partial/native-depth limits."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,os,time,json,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.semantic_engine import SemanticSearchEngine,_core_pv_leaf_dynamic_features
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
def forbidden(*a,**k):raise AssertionError('No Native calls')
SemanticSearchEngine.search=forbidden
D=Path(__file__).resolve().parent;start=time.perf_counter();counts=Counter();R=Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))
class Stop:
 def __init__(self):self.next=0;self.stop=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in('rollout','advisor','slack'):
    f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());self.stop|=bool(f.get('stopped')or f.get('user_paused'))
  return self.stop or now-start>900
stop=Stop()
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
class Material:
 def __init__(self,p):self.b=p['board_values'];self.h=p['hand_values']
 def evaluate(self,s):
  return(sum((1 if x.owner==0 else-1)*self.b[x.current_type_id]for x in s.position.board if x)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items()))*(1 if s.position.side_to_move==0 else-1)
def pvcheck(s,z):
 aa=[decode(x)for x in z['decision_line']];leaf=copy(s)
 for a in aa:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['PV_edges']+=1
 if z.get('dynamic_features'):assert list(_core_pv_leaf_dynamic_features(s,tuple(aa)))==z['dynamic_features']
 counts['Native_receipts']+=1
inp=json.loads((D/'inputs.json').read_bytes());parents={x['name']:x for x in inp['parents']};res=json.loads((D/'result.json').read_bytes())
for row in res['rows']:
 assert not stop.is_cancelled();p=parents[row['name']];c=compile_semantic_ruleset(ruleset_from_dict(p['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));assert digest(s.state)==p['state_sha256']and digest(s._search_witnesses)==p['witness_sha256'];slot,=c.ir.aux_slots;assert all(dict(s.state.position.aux_state).get((slot.slot_id,o),slot.initial)==0 for o in(0,1))
 pvcheck(s,p['original_receipt'])
 for z in row['native']:pvcheck(s,z['result'])
 ref=row['core']
 if ref and ref['complete']:
  st=SearchStatistics();a,v,pv,cause=run_root_search(s.state,c,Material(p),TranspositionTable(max_entries=1),SearchLimits(max_depth=3,max_nodes=250000,max_time_seconds=120,quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
  assert st.completed_depth==3 or cause=='root_immediate_win'
  assert v==ref['score']and record_value(a)==ref['action'];counts['closed_D3_targets']+=1;counts['fresh_Core_main']+=st.nodes;counts['fresh_Core_q']+=st.qnodes
 else:counts['UNKNOWN_not_rerun']+=1
write_json(D/'reader-result.json',dict(status='PASS_CLOSED_D3_CORE_AND_FULL_HISTORIES',counts=dict(counts),seconds=time.perf_counter()-start,Native_calls=0,new_games=0,scope='OnlyoriginalclosedD3targets, actual8bothconsumed-rightparents/allretainedPVreceipts; no UNKNOWNrefill, allNativeincomplete-depthreturns remainseparate. NotWDL/utility/developmentgate.'))
print('LATE_CORE_READER',dict(counts),time.perf_counter()-start)
