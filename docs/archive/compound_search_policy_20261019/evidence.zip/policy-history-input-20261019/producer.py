"""Reuse published real-history records to audit approximate policy state inputs."""
from pathlib import Path
import sys,json,time,hashlib,os
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import dynamic_features
from generic_chess.learning.policy import semantic_state_feature_vector,semantic_action_features
D=Path(__file__).resolve().parent;S=Path('docs/research/data/native_trace_history_20261019');start=time.perf_counter();raw=(S/'witness-inputs.json').read_bytes();data=json.loads(raw);c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(data['rule']));nr=compile_native_semantic_rules(c);rows=[]
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
for p in data['parents']:
 for n in ('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));assert digest(s.state)==p['state_sha256']and digest(s._search_witnesses)==p['witness_sha256'];before=(s.state,s.to_record(),s.history,s._search_witnesses)
 dynamic=dynamic_features(nr,pack_semantic_search_position(c,nr,s));x=semantic_state_feature_vector(s.state.position,c,dynamic);actions=[]
 for a in s.legal_actions():
  child=GameSession.replay(c,s.to_record());child.submit(a)
  assert child.result.winner is None
  value=0 if child.state.terminal_status.is_terminal else sum((1 if pc.owner==0 else-1)*data['checkpoint']['board_weights'][pc.current_type_id]for pc in child.state.position.board if pc)
  value*=1 if s.state.position.side_to_move==0 else-1
  actions.append(dict(action=record_value(a),policy_features=semantic_action_features(c,s.state.position,a).tolist(),root_perspective_D1_value=value,child_state_sha256=digest(child.state),terminal=child.state.terminal_status.is_terminal))
 assert max(a['root_perspective_D1_value']for a in actions)==p['expected_score_native']
 rows.append(dict(witness=p['witness'],record=p['record'],state_sha256=p['state_sha256'],witness_sha256=p['witness_sha256'],ply=s.state.ply_count,state_features=x.tolist(),state_feature_sha256=hashlib.sha256(x.tobytes()).hexdigest(),dynamic=list(dynamic),reference=p['expected_score_native'],actions=actions,optimal_actions=[a['action']for a in actions if a['root_perspective_D1_value']==p['expected_score_native']]))
 assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
assert rows[0]['state_features']==rows[1]['state_features']and rows[0]['state_sha256']!=rows[1]['state_sha256']
assert [(a['action'],a['policy_features'])for a in rows[0]['actions']]==[(a['action'],a['policy_features'])for a in rows[1]['actions']]
intersection=[a for a in rows[0]['optimal_actions']if a in rows[1]['optimal_actions']]
write_json(D/'result.json',dict(status='PASS_FINITE_HISTORY_STATE_ALIAS',rows=rows,optimal_set_intersection=intersection,source_input_sha256=hashlib.sha256(raw).hexdigest(),seconds=time.perf_counter()-start,new_Native_searches=0,new_Core_searches=0,Native_dynamic_queries=2,Core_checked_children=4,new_games=0,scope='Reuseonlytwoalready-publishedcompleteply7records andfourCorechildren. Fullpolicy state/actioninputs equal, exactD1values-2/0 differ. Sharedoptimalaction remains: no policyregret/strengthloss proved. Approximateencoding isnot executionidentity, Native/Core searchretainsfullhistory. NoAUXconsumer/modelmigration/newAPI claim.'))
print('HISTORY_POLICY',rows[0]['reference'],rows[1]['reference'],'sharedopt',len(intersection),time.perf_counter()-start)
