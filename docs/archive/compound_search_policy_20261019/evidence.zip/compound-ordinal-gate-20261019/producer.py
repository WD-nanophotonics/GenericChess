"""Bounded ordinal input gate on frozen complete compound rules; no new games."""
from pathlib import Path
import sys,json,time,hashlib
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;S=D.parent/'compound-window-20261019';inp=json.loads((S/'inputs.json').read_bytes());roots={p['name']:p for p in inp['roots']};start=time.perf_counter();deadline=start+120
class Stop:
 def __init__(self):self.next=0;self.flag=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in ('rollout','advisor','slack'):
    f=json.loads(Path('.local_agent',n+'.json').read_bytes());self.flag|=bool(f.get('stopped')or f.get('user_paused'))
  return self.flag or now>=deadline
stop=Stop()
def poll():
 if stop.is_cancelled():raise TimeoutError('STOP_OR_GLOBAL120S')
class Material:
 def __init__(self,b,h):self.b=b;self.h=h
 def evaluate(self,s):
  v=sum((1 if p.owner==0 else-1)*self.b[p.current_type_id]for p in s.position.board if p)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items())
  return v*(1 if s.position.side_to_move==0 else-1)
def ordinal(row):
 anchors={t['type_id']for t in row['rule']['piece_types']if t['is_anchor']};vals=sorted(row['board_values'][t]for t in row['board_values']if t not in anchors);ranks={v:sum(i+1 for i,x in enumerate(vals)if x==v)/vals.count(v)for v in set(vals)};median=(len(vals)+1)/2
 out={t:0 if t in anchors else round(256*ranks[v]/median)for t,v in row['board_values'].items()}
 for a in out:
  for b in out:
   assert (row['board_values'][a]>row['board_values'][b])-(row['board_values'][a]<row['board_values'][b])==(out[a]>out[b])-(out[a]<out[b])
 return out
rows=[];counts=Counter();status='COMPLETE';error=None
try:
 for r in inp['rules']:
  poll();c=compile_semantic_ruleset(ruleset_from_dict(r['rule']));nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(roots[r['name']]['record'])));before=(s.state,s.to_record(),s.history,s._search_witnesses);row=dict(name=r['name'],static_board=r['board_values'],ordinal_board=ordinal(r),same_hand=r['hand_values'],profiles={})
  for label,b in (('static',r['board_values']),('ordinal',row['ordinal_board'])):
   poll();e=SemanticSearchEngine(c,nr,board_values=b,hand_values=r['hand_values'],tt_megabytes=0);t=time.perf_counter();z=e.search(s,SearchLimits(max_depth=2,max_nodes=131072,max_time_seconds=min(.5,deadline-time.perf_counter()),quiescence_max_depth=0),root_window_pruning=True);rr=dict(native=record_value(z),native_seconds=time.perf_counter()-t);counts['Native']+=1;counts['Native_main']+=z.nodes;counts['Native_q']+=z.qnodes;del e
   poll();st=SearchStatistics();t=time.perf_counter();a,score,pv,cause=run_root_search(s.state,c,Material(b,r['hand_values']),TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(2,deadline-time.perf_counter()),quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses);mapped=score-900000000 if score>=900000000 else score+900000000 if score<=-900000000 else score;complete=st.completed_depth==2 or cause=='immediate_win';rr['core']=dict(score=score,action=record_value(a),pv=record_value(pv),cause=cause,statistics=record_value(st),seconds=time.perf_counter()-t,complete=complete)
   rr['comparable']=complete and z.completed_depth==2;rr['same_score']=z.score==mapped if rr['comparable']else None
   if rr['comparable']:assert rr['same_score']
   row['profiles'][label]=rr;counts['Core']+=1;counts['Core_main']+=st.nodes;counts['Core_q']+=st.qnodes;assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
  row['different_action']=row['profiles']['static']['native']['action']!=row['profiles']['ordinal']['native']['action'];counts['different_action']+=row['different_action'];rows.append(row)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,rows=rows,counts=dict(counts),seconds=time.perf_counter()-start,global_cap_seconds=120,scope='Sixteen alreadyexposednewcompoundinitialparents, numericstatic vsaverageboardrank, EXACTsameweakordering/staticHAND. Initialactiondifferences show inputrelevance only, notcausalutility orpopulationgain. CoreUNKNOWN retained, no games/refill/train.'))
print('ORDINAL_GATE',status,error,dict(counts),time.perf_counter()-start)
