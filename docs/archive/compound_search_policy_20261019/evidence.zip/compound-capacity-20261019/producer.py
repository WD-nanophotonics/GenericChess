"""Whole public Core consumer across Native's declared effect capacity."""
from pathlib import Path
import sys,json,time,hashlib
from dataclasses import replace
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import *
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
D=Path(__file__).resolve().parent;start=time.perf_counter();deadline=start+120
def poll():
 if time.perf_counter()>=deadline:raise TimeoutError('GLOBAL120S')
 for n in ('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('STOP')
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
class Material:
 def __init__(self,b,h):self.b=b;self.h=h
 def evaluate(self,s):
  v=sum((1 if p.owner==0 else-1)*self.b[p.current_type_id]for p in s.position.board if p)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items())
  return v*(1 if s.position.side_to_move==0 else-1)
rows=[];counts=Counter();status='COMPLETE';error=None
try:
 for seed,n in ((661001,8),(661002,12)):
  poll();g=generate_game(GeneratorConfig(seed=seed,board_size=n,setup_preset='classic_like',movement_symmetry='none',allow_hybrid=True,max_generation_attempts=64));v=build_ruleset_profile(g.compiled_ruleset,EvaluationConfig());anchors={t.type_id for t in g.ruleset.piece_types if t.is_anchor};b={t:0 if t in anchors else round(x*.256)for t,x in v.board_value_by_type.items()};h={t:0 if t in anchors else round(x*.256)for t,x in v.hand_value_by_base_type.items()}
  for actors in (4,5,6):
   poll();offsets=(-2,-1,1,2,3)[:actors-1]
   effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),)+tuple(RuleActionEffect('shift',from_ref=RuleSquareRef('offset_from_source',offset=(df,0),owner_relative=True),to_ref=RuleSquareRef('offset_from_source',offset=(df,1),owner_relative=True),piece_owner='self')for df in offsets)
   action=RuleSemanticAction(name='phalanx_'+str(actors),type_ids=tuple(t.type_id for t in g.ruleset.piece_types if not t.is_anchor),geometry=RuleGeometrySpec(kind='leap',offset=(0,1),owner_relative=True),target_relation='empty',composition='augment',effects=effects,invariants=(RuleInvariant('own_anchor_safe'),))
   rule=replace(g.ruleset,semantic_actions=(action,));c=compile_semantic_ruleset(rule);special={p.pattern_id for p in c.ir.patterns if p.name==action.name};row=dict(seed=seed,n=n,actors=actors,rule=ruleset_to_dict(rule),board=b,hand=h,parents=[])
   try:compile_native_semantic_rules(c);row['Native']='SUPPORTED'
   except NativeUnsupportedRuleError as exc:row.update(Native='REFUSED',refusal=str(exc))
   s=GameSession(c)
   for phase in range(3):
    poll();record=json.loads(serialize_game_record(s.to_record()));before=(s.state,s.to_record(),s.history,s._search_witnesses);aa=s.legal_actions();special_aa=[a for a in aa if getattr(a,'pattern_id',None)in special];p=dict(phase=phase,record=record,state_sha256=digest(s.state),witness_sha256=digest(s._search_witnesses),legal=len(aa),special_legal=len(special_aa),decisions=[])
    for enabled in (False,True):
     poll();tick=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=Material(b,h),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=enabled)
     provider=player.native_legality_provider is not None;z=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(1,deadline-time.perf_counter()),quiescence_max_depth=0));elapsed=time.perf_counter()-tick
     assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
     leaf=GameSession.replay(c,s.to_record())
     for a in z.principal_variation:leaf.submit(a);counts['pv_edges']+=1
     committed=None
     if z.action is not None:
      assert z.action in aa;cs=GameSession.replay(c,s.to_record());cs.submit(z.action);committed=dict(state_sha256=digest(cs.state),witness_sha256=digest(cs._search_witnesses));counts['checked_commits']+=1
     p['decisions'].append(dict(native_legality_requested=enabled,provider_active=provider,decision=record_value(z),caller_seconds=elapsed,committed=committed));counts['queries']+=1;counts['main']+=z.nodes;counts['q']+=z.qnodes;counts['completed_D2']+=z.completed_depth==2
     if row['Native']=='REFUSED':assert not provider and z.native_legality_calls==0;counts['explicit_Core_queries']+=1
    x,y=p['decisions'];p['same_completed_scalar']=x['decision']['score']==y['decision']['score']if x['decision']['completed_depth']==y['decision']['completed_depth']==2 else None
    if p['same_completed_scalar']is not None:assert p['same_completed_scalar']
    row['parents'].append(p)
    if phase==0:
     assert special_aa,'PREDEFINED_TRIGGER_UNAVAILABLE'
     action=sorted(special_aa,key=repr)[0];old=s.state.position;s.submit(action);p['trigger']=record_value(action);p['trigger_changed_squares']=sum(a!=b for a,b in zip(old.board,s.state.position.board));assert p['trigger_changed_squares']==actors*2
    elif phase==1:
     if not aa:break
     s.submit(sorted(aa,key=repr)[0])
   rows.append(row);counts['rules']+=1;counts['refused_rules']+=row['Native']=='REFUSED';print('PHALANX',n,actors,row['Native'],counts['queries'],round(time.perf_counter()-start,3),flush=True)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,rows=rows,counts=dict(counts),seconds=time.perf_counter()-start,global_cap_seconds=120,scope='Sixfullgeneratedrules with4/5/6actors at8/12, fullpromotion/drop/history; exactNativecapacityrefusal retained. Existing public AlphaBetaPlayer requestedNativelegality fallsbackCore whenunsupported, no automaticNativeSearchEnginefallbackclaim, default/model/C changes. One-second issearchbudget, nothard wholeAPI deadline. No games/train/newsolver.'))
print('CORE_BOUNDARY',status,error,dict(counts),time.perf_counter()-start)
