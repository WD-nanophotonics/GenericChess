"""Existing hint arithmetic plus reused complete original near reference."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;d=json.loads((D/'result.json').read_bytes());A=json.loads((D.parent/'compound-policy-alias-20261019'/'result.json').read_bytes());root=next(r for r in A['rows']if r['name']==d['name']);pair=root['chosen_pair']['alternatives'];known={json.dumps(r['action'],sort_keys=True):r for r in pair if r['child_reference']['complete']};reused=[]
for r in d['rows']:
 key=json.dumps(r['result']['action'],sort_keys=True);value=None
 if key in known:value=root['root_core']['score']+known[key]['child_reference']['score']
 reused.append(dict(depth=r['depth'],cap=r['cap'],mode=r['mode'],hint=r['hint'],completed_depth=r['result']['completed_depth'],score=r['result']['score'],main=r['result']['nodes'],first_actions=r['result']['root_iteration_first_actions'],actual_apply_count=r['result']['root_hint_apply_count'],D2_regret_from_preexisting_reference=value))
small=[r for r in reused if r['depth']==2 and r['cap']==4096 and r['mode']];assert [r['main']for r in small]==[134,134,160];assert all(r['score']==0 and r['completed_depth']==2 for r in small)
out=dict(status='PASS_FINITE_ORACLE_HINT_INTERPRETATION',rows=reused,same_complete_D2=True,raw_extra_Core_UNKNOWN=2,extra_Core_UNKNOWN_rerun=0,source_hint_action='Source6211swapfirstcandidatewithrequested; permutationonly,nofiltering. Fullpair-onlyordernotinstrumented. Existingdefaultfirstlegalalreadynear; nohint-tooraclebenefit demonstrated.',decision='Noencoderexpansion fromthiswitness; laterdeployablefixedprior isseparatecostgate.',scope='All30originalcalls retained; D4True8192farcompletesD3 versusothersD4, cannotcomparetheirscoresasequaldepth/strength. FiniteD2regret onlyreusedcomplete matchingactionreference; otheractionsUNKNOWN, noCoresupplementrerun.')
write_json(D/'analysis.json',out);print('HINT_ANALYSIS',len(reused),[r['main']for r in small])
