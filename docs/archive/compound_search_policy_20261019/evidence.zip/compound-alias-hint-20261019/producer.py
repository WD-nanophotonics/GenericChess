"""Existing root-order hints on one saved alias witness: cost, not learned utility."""
from pathlib import Path
from copy import copy
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove
from generic_chess.core.coordinates import Square
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());A=json.loads((D.parent/'compound-policy-alias-20261019'/'result.json').read_bytes());row=next(r for r in A['rows']if r['name']==P['name']);start=time.perf_counter();deadline=start+120
def poll():
 if time.perf_counter()>=deadline:raise TimeoutError('CONTINUOUS120S')
 for n in ('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('STOP')
def decode(v):
 d=dict(v);d['from_square']=Square(**d['from_square']);d['to_square']=Square(**d['to_square']);return SemanticBoardMove(**d)
c=compile_semantic_ruleset(ruleset_from_dict(row['rule']));nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(row['record'])));original=(s.state,s.to_record(),s.history,s._search_witnesses)
alts=row['chosen_pair']['alternatives'];hints={'none':None,'near':decode(next(a['action']for a in alts if 'near'in a['action']['pattern_id'])),'far':decode(next(a['action']for a in alts if 'far'in a['action']['pattern_id']))}
rows=[];refs={};status='COMPLETE';error=None
class Material:
 def evaluate(self,st):
  v=sum((1 if p.owner==0 else-1)*row['board'][p.current_type_id]for p in st.position.board if p)+sum((st.position.hands[0].count(t)-st.position.hands[1].count(t))*v for t,v in row['hand'].items())
  return v*(1 if st.position.side_to_move==0 else-1)
class Stop:
 def is_cancelled(self):
  try:poll()
  except(TimeoutError,InterruptedError):return True
  return False
try:
 for depth,cap in P['requests']:
  for mode in (False,True):
   for label,hint in hints.items():
    poll();e=SemanticSearchEngine(c,nr,board_values=row['board'],hand_values=row['hand'],tt_megabytes=0);tick=time.perf_counter();z=e.search(s,SearchLimits(max_depth=depth,max_nodes=cap,max_time_seconds=min(1,deadline-time.perf_counter()),quiescence_max_depth=0),root_window_pruning=mode,root_order_hint=hint);elapsed=time.perf_counter()-tick;assert original==(s.state,s.to_record(),s.history,s._search_witnesses)
    leaf=copy(s)
    for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a)
    rr=dict(depth=depth,cap=cap,mode=mode,hint=label,result=record_value(z),caller_seconds=elapsed,D2_regret=None)
    if z.completed_depth==2:assert z.score==row['root_native']['result']['score']
    if z.action is not None:
     key=repr(z.action)
     if key not in refs:
      assert len(refs)<16;poll();child=copy(s);child.submit(z.action);st=SearchStatistics();a,value,pv,cause=run_root_search(child.state,c,Material(),TranspositionTable(max_entries=1),SearchLimits(max_depth=1,max_nodes=200000,max_time_seconds=min(1,deadline-time.perf_counter()),quiescence_max_depth=0),Stop(),st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=child._search_witnesses)
      refs[key]=dict(action=record_value(z.action),score=value,cause=cause,statistics=record_value(st),complete=st.completed_depth==1 or cause in ('root_immediate_win','terminal_position'))
     ref=refs[key]
     if ref['complete']and abs(ref['score'])<900000000:rr['D2_regret']=row['root_core']['score']+ref['score'];assert rr['D2_regret']>=0
    rows.append(rr);del e
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,name=P['name'],rows=rows,references=list(refs.values()),seconds=time.perf_counter()-start,global_cap_seconds=120,scope='Oneexposedwitness, coldexistingNone/near/far hints andTrue/False. Oraclediagnostic, notlearnedpolicy gain/trainability/wholegamereward; D2regret onlywhenchildreferencecomplete. No training/API/default/game changes.'))
print('HINT_CLOSED',status,error,len(rows),len(refs),time.perf_counter()-start)
