"""Extract the actual after-composition opening-win counterexample, no search."""
from pathlib import Path
from dataclasses import replace
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
D=Path(__file__).resolve().parent;T=D.parent;start=time.perf_counter();F=json.loads((D/'result.json').read_bytes());W=json.loads((T/'compound-window-20261019'/'inputs.json').read_bytes());by={r['name']:r for r in W['rules']};out=[]
for row in F['rows']:
 if row['variants']['base']['all_preferences']and not row['variants']['one_helper']['all_preferences']:
  r=by[row['name']];rule=ruleset_from_dict(r['rule']);base=replace(rule,semantic_actions=());bc=compile_legacy_ruleset_for_semantic_execution(base);bs=GameSession(bc)
  wins=[]
  for a in bs.legal_actions():
   child=GameSession.replay(bc,bs.to_record());child.submit(a)
   if child.result.winner==bs.state.position.side_to_move:wins.append(a)
  assert not wins
  c=compile_semantic_ruleset(rule);s=GameSession(c);winner=None
  for a in s.legal_actions():
   child=GameSession.replay(c,s.to_record());child.submit(a)
   if child.result.winner==s.state.position.side_to_move:winner=(a,child);break
  assert winner is not None;a,child=winner
  out.append(dict(name=row['name'],rule=ruleset_to_dict(rule),base_no_winning_opening_verified=True,winning_action=record_value(a),parent_record=json.loads(serialize_game_record(s.to_record())),child_record=json.loads(serialize_game_record(child.to_record())),child_state=record_value(child.state),changed_squares=sum(x!=y for x,y in zip(s.state.position.board,child.state.position.board))))
write_json(D/'witness.json',dict(status='PASS_POSTCOMPOSITION_WIN_WITNESS',witnesses=out,seconds=time.perf_counter()-start,scope='Actualoneexistingrule basepasses/finalfails; noafter-the-factgameexclusion/defaultchange. To honoroptionalno-opening-win onfuturecomposedrules, checkcompletefinalproduct. Baseprefilteralonecannotguaranteethatproperty. Notgenericbalance/longplayability proof.'))
print('FILTER_WITNESS',[(x['name'],x['winning_action']['pattern_id'],x['changed_squares'],x['child_state']['terminal_status'])for x in out])
