"""Unchanged optional opening filter before/after complete compositions; no refiltered games."""
from pathlib import Path
from dataclasses import replace
import sys,json,time,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.filters import run_soft_filters
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.execution import ExecutableSemanticRuleset
D=Path(__file__).resolve().parent;T=D.parent;W=json.loads((T/'compound-window-20261019'/'inputs.json').read_bytes());A=json.loads((T/'compound-policy-alias-20261019'/'result.json').read_bytes());ar={r['name']:r for r in A['rows']};start=time.perf_counter();rows=[];R=Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))
for r in W['rules']:
 for n in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 assert time.perf_counter()-start<120
 cfg=replace(GeneratorConfig(**r['config']),require_no_opening_win_in_one=True);single=ruleset_from_dict(r['rule']);variants={'base':replace(single,semantic_actions=()),'one_helper':single,'two_helpers':ruleset_from_dict(ar[r['name']]['rule'])};out={}
 for name,rule in variants.items():
  c=ExecutableSemanticRuleset.from_compiled(compile_semantic_ruleset(rule));report=run_soft_filters(cfg,c,{t.type_id:t for t in rule.piece_types});out[name]=dict(no_opening_win=next(x.passed for x in report if x.name=='opening_has_no_win_in_one'),all_preferences=all(x.passed for x in report),report=record_value(report))
 rows.append(dict(name=r['name'],variants=out))
summary={v:dict(pass_no_opening_win=sum(r['variants'][v]['no_opening_win']for r in rows),pass_all_preferences=sum(r['variants'][v]['all_preferences']for r in rows))for v in variants}
summary['base_vs_one_acceptance_changed']=sum(r['variants']['base']['all_preferences']!=r['variants']['one_helper']['all_preferences']for r in rows);summary['base_vs_two_acceptance_changed']=sum(r['variants']['base']['all_preferences']!=r['variants']['two_helpers']['all_preferences']for r in rows)
write_json(D/'result.json',dict(status='PASS_FINITE_FILTER_PLACEMENT_INVENTORY',rows=rows,summary=summary,seconds=time.perf_counter()-start,new_games=0,new_searches=0,scope='48fullreports on16existingbase/onehelper/twohelper variants. Unchangedoptionalpreference andfullCoretransitions. All128closedgames remainincluded; no retrospectivefilter/causalutility/longplayability/defaultclaim. Structuralatompreferences stilllegacy-compatible subset only.'))
print('FILTER_PLACEMENT',summary,time.perf_counter()-start)
