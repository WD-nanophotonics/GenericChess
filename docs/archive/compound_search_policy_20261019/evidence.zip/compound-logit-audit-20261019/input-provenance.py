"""Add explicit model-input/ID provenance; policy logits and searches are not rerun."""
from pathlib import Path
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native.semantic_engine import _core_pv_leaf_dynamic_features
from generic_chess.learning.policy import semantic_state_feature_vector,semantic_action_features,SemanticPolicyV0
from generic_chess.learning.policy_v1 import action_v1_components,SemanticPolicyV1
D=Path(__file__).resolve().parent;A=json.loads((D.parent/'compound-policy-alias-20261019'/'result.json').read_bytes());L=json.loads((D/'result.json').read_bytes());start=time.perf_counter();rows=[];checked=0
for r in A['rows']:
 for n in ('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 c=compile_semantic_ruleset(ruleset_from_dict(r['rule']));nr=compile_native_semantic_rules(c);s=GameSession(c);aa=s.legal_actions();dynamic=_core_pv_leaf_dynamic_features(s,());state=semantic_state_feature_vector(s.state.position,c,dynamic);ids=[int(pack_semantic_action(nr,s.state.position,a))for a in aa];v0=np.stack([semantic_action_features(c,s.state.position,a)for a in aa]);parts=[action_v1_components(c,s.state.position,a)for a in aa];base=np.stack([x[0]for x in parts]);cats=tuple(np.asarray([x[1][j]for x in parts])for j in range(4));errors=[]
 for l in [x for x in L['rows']if x['name']==r['name']]:
  m0=SemanticPolicyV0.from_dict(l['v0_model']);m1=SemanticPolicyV1.from_dict(l['v1_model']);z0=m0.logits(state,v0);z1=m1.logits(state,base,cats);byid=dict(zip(l['native_actions'],l['native_logits']));assert set(ids)==set(byid);e=max(abs(float(z1[i])-byid[k])for i,k in enumerate(ids));assert e<1e-10 and np.allclose(z0,l['python_v0_logits'],rtol=0,atol=1e-12)and np.allclose(z1,l['python_v1_logits'],rtol=0,atol=1e-12);errors.append(e);checked+=len(ids)
 rows.append(dict(name=r['name'],state_features=state.tolist(),Core_root_dynamic=list(dynamic),public_actions=record_value(aa),Native_ids_in_Core_order=ids,reference_Native_policy_max_abs_errors=errors))
write_json(D/'input-provenance.json',dict(status='PASS_CORE_DERIVED_COMPLETE_INPUTS',rows=rows,Native_logit_actions_rechecked=checked,seconds=time.perf_counter()-start,new_Native_searches=0,new_Native_policy_calls=0,new_games=0,scope='ExistingCorefallbackhelper independently reconstructs rootdynamic/stateinputs; fullsavedmodelshashes/actualNativeIDmapping connectall1040recordedlogits. Nativecompile/packing only, no logits/search rerun.'))
print('LOGIT_PROVENANCE',checked,time.perf_counter()-start)
