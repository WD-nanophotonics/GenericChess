"""Audit complete existing policy logits with fixed random weights; no optimizer."""
from pathlib import Path
from collections import Counter
import sys,json,time,hashlib,inspect
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native.semantic import policy_logits,dynamic_features
from generic_chess.learning.policy import SemanticPolicyV0,semantic_action_features,semantic_state_feature_vector
from generic_chess.learning.policy_v1 import SemanticPolicyV1,action_v1_components
D=Path(__file__).resolve().parent;src=json.loads((D.parent/'compound-policy-alias-20261019'/'result.json').read_bytes());start=time.perf_counter();rows=[];counts=Counter()
def poll():
 assert time.perf_counter()-start<120
 for n in ('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
for row in src['rows']:
 poll();c=compile_semantic_ruleset(ruleset_from_dict(row['rule']));nr=compile_native_semantic_rules(c);s=GameSession(c);pos=pack_semantic_search_position(c,nr,s);aa=s.legal_actions();state=semantic_state_feature_vector(s.state.position,c,dynamic_features(nr,pos));v0=np.stack([semantic_action_features(c,s.state.position,a)for a in aa]);parts=[action_v1_components(c,s.state.position,a)for a in aa];base=np.stack([x[0]for x in parts]);cats=tuple(np.asarray([x[1][j]for x in parts],dtype=np.int64)for j in range(4));ids=[int(pack_semantic_action(nr,s.state.position,a))for a in aa];where={a:i for i,a in enumerate(ids)};tc=len(nr.type_ids)
 for seed in (71001,71002):
  poll();rng=np.random.default_rng(seed)
  def ar(shape):return rng.normal(0,.05,shape).tolist()
  common=dict(ruleset_fingerprint=c.ruleset_fingerprint,state_schema_id='semantic-state-v0',state_width=len(state),hidden_width=16,corpus_config={'diagnostic':'fixed_random_no_optimizer'},training_config={'optimizer':None,'updates':0,'seed':seed})
  m0=SemanticPolicyV0(**common,action_schema_id='semantic-action-v0',action_width=24,state_weights=ar((16,len(state))),state_bias=ar((16,)),action_embedding=ar((16,24)),action_bias=ar((24,)))
  z0=m0.logits(state,v0)
  kw=dict(state_weights=ar((16,len(state))),state_bias=ar((16,)),base_weights=ar((16,21)),action_bias=ar((16,)),actor_embedding=ar((tc,16)),promotion_embedding=ar((tc+1,16)),drop_embedding=ar((tc+1,16)),actor_geometry_embedding=ar((tc,3,16)),actor_capture_embedding=ar((tc,16)),actor_promotion_embedding=ar((tc,16)),actor_drop_embedding=ar((tc,16)),beta_base=ar((21,)),beta_actor=ar((tc,)),beta_promotion=ar((tc+1,)),beta_drop=ar((tc+1,)),beta_actor_geometry=ar((tc,3)),beta_actor_capture=ar((tc,)),beta_actor_promotion=ar((tc,)),beta_actor_drop=ar((tc,)))
  m1=SemanticPolicyV1(**common,action_schema_id='semantic-action-v1',type_count=tc,**kw);z1=m1.logits(state,base,cats);native=policy_logits(nr,pos,m1);assert set(native['actions'])==set(ids);byid=dict(zip(native['actions'],native['logits']));error=max(abs(float(z1[i])-byid[k])for i,k in enumerate(ids));assert error<1e-10
  alias=[]
  for group in row['groups']:
   vv=[]
   for alt in group['actions']:
    a=next(a for a in aa if a.pattern_id==alt['action']['pattern_id']and a.geometry_id==alt['action']['geometry_id']and a.from_square.file==alt['action']['from_square']['file']and a.from_square.rank==alt['action']['from_square']['rank']and a.to_square.file==alt['action']['to_square']['file']and a.to_square.rank==alt['action']['to_square']['rank'])
    i=ids.index(int(pack_semantic_action(nr,s.state.position,a)));vv.append((float(z0[i]),float(z1[i]),byid[ids[i]],ids[i]))
   spread=[max(v[j]for v in vv)-min(v[j]for v in vv)for j in range(3)]; assert max(spread)<1e-12, (row['name'],seed,spread,vv)
   alias.append(dict(values=vv,spread=spread,Native_bitwise_equal=len({v[2]for v in vv})==1));counts['alias_model_checks']+=1
  rows.append(dict(name=row['name'],seed=seed,Native_max_abs_error=error,all_legal_actions=len(ids),v0_model=m0.to_dict(),v1_model=m1.to_dict(),native_actions=native['actions'],native_logits=native['logits'],python_v0_logits=z0.tolist(),python_v1_logits=z1.tolist(),alias_checks=alias));counts['models_v0']+=1;counts['models_v1']+=1;counts['Native_logit_calls']+=1;counts['checked_logit_actions']+=len(ids)
sources={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()for name in ('generic_chess/learning/policy.py','generic_chess/learning/policy_v1.py','generic_chess/_native/native_module.c')}
write_json(D/'result.json',dict(status='PASS_FULL_LOGIT_INPUT_AUDIT',counts=dict(counts),rows=rows,source_sha256=sources,seconds=time.perf_counter()-start,optimizer_updates=0,new_searches=0,new_games=0,scope='Twofixedrandomparameterseeds/16rules, allPythonV1/Nativelegalactions/logitsagree. All80buckets shareV0/V1logits. Sourceformulas usefeatures/categoricalindices; rawactionIDonly tie-breaks, notlogitinput. Randommodelsverifyimplementation, nottraining/strength orall-model empiricalproof; mathematicalconclusion requiresfixedstate/fullfeatures.'))
print('LOGIT_AUDIT',dict(counts),time.perf_counter()-start)
