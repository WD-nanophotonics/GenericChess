"""Classify retained Core receipts and audit real compound transitions, no search."""
from pathlib import Path
from collections import Counter
from copy import copy
import sys,json,hashlib,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(__file__).resolve().parent;start=time.perf_counter()
def decode(a):
 if isinstance(a,str):return a
 d=dict(a);d['to_square']=Square(**d['to_square'])
 if 'from_square'in d:d['from_square']=Square(**d['from_square']);return SemanticBoardMove(**d)
 return SemanticDropMove(**d)
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
G=D.parent/'compound-ordinal-gate-20261019';gr=json.loads((G/'result.json').read_bytes());I=json.loads((D/'inputs.json').read_bytes());rules={r['name']:r for r in I['rules']};roots={p['name']:p for p in I['roots']};comp={n:compile_semantic_ruleset(ruleset_from_dict(r['rule']))for n,r in rules.items()};classes=Counter()
for r in gr['rows']:
 c=comp[r['name']];s=GameSession.replay(c,deserialize_game_record(json.dumps(roots[r['name']]['record'])))
 for profile,v in r['profiles'].items():
  cr=v['core'];native=v['native']
  if cr['statistics']['completed_depth']==2:classes['D2_complete']+=1;assert v['same_score']
  elif cr['cause']=='root_immediate_win':
   child=copy(s);child.submit(decode(cr['action']));assert child.result.winner==s.state.position.side_to_move
   assert cr['score']-900000000==native['score']==99999999;classes['verified_win_in_one']+=1
  else:classes['UNKNOWN']+=1
assert sum(classes.values())==32
queries=(json.loads(x)for x in(D/'queries.jsonl').open(encoding='utf8'));q=next(queries,None);stats=Counter();witnesses=[]
for line in(D/'games.jsonl').open(encoding='utf8'):
 g=json.loads(line);c=comp[g['name']];s=GameSession.replay(c,deserialize_game_record(json.dumps(roots[g['name']]['record'])));special=set(rules[g['name']]['special_pattern_ids'])
 while q is not None and q['slot']==g['slot']:
  assert time.perf_counter()-start<120
  if q['committed']is not None:
   a=decode(q['committed']);before=s.state
   if isinstance(a,str):s.declare(a)
   else:
    s.submit(a)
    if getattr(a,'pattern_id',None)in special:
     changed=[i for i,(x,y)in enumerate(zip(before.position.board,s.state.position.board))if x!=y];assert len(changed)==4;stats['actual_twoactor_commits']+=1
     if len(witnesses)<4:witnesses.append(dict(name=g['name'],slot=g['slot'],query=q['query'],action=q['committed'],changed=changed,before=digest(before),after=digest(s.state)))
  q=next(queries,None)
assert q is None
write_json(D/'mechanism-audit.json',dict(status='PASS',ordinal_reference_classes=dict(classes),ordinal_raw_receipt_unchanged=True,compound_physical_counts=dict(stats),witnesses=witnesses,seconds=time.perf_counter()-start,scope='24D2+8directverifiedwin controls, not8UNKNOWN; raw oldcompleteflags preserved. Actual205compound commits alltwoactors/foursquares. No search/newgame/train.'))
print('MECHANISM_AUDIT',dict(classes),dict(stats),time.perf_counter()-start)
