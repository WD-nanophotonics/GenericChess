"""Planned-cell reward bounds and actual costs; no new search."""
from pathlib import Path
from collections import Counter,defaultdict
import sys,json
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());result=json.loads((D/'result.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['rows'];games={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};rows=[]
for idx,slot in enumerate(slots):
 g=games.get(idx)
 if g is not None:assert all(g[k]==v for k,v in slot.items())
 seed,size,variant=slot['name'].split('-',2);rows.append(dict(slot=idx,**slot,seed=int(seed),size=int(size),variant=variant,game=g,reward=None if g is None else g['reward']))
assert len(rows)==128 and len(games)==result['closed']
def bounds(rr):
 n=len(rr);u=sum(v['reward']is None for v in rr);k=sum(v['reward']for v in rr if v['reward']is not None)
 return dict(planned=n,W=sum(v['reward']==1 for v in rr),D=sum(v['reward']==0 for v in rr),L=sum(v['reward']==-1 for v in rr),UNKNOWN=u,reward_bounds=[(k-u)/n,(k+u)/n])
def contrast(rr):
 a={(v['name'],v['owner']):v['reward']for v in rr if v['mode']};b={(v['name'],v['owner']):v['reward']for v in rr if not v['mode']};assert a.keys()==b.keys();n=len(a);lo=hi=0
 for k,x in a.items():
  y=b[k];lo+=(-1 if x is None else x)-(1 if y is None else y);hi+=(1 if x is None else x)-(-1 if y is None else y)
 return[lo/n,hi/n]
contrasts={}
for foe in P['foes']:
 rr=[v for v in rows if v['foe']==foe];per={str(seed):contrast([v for v in rr if v['seed']==seed])for seed in sorted({v['seed']for v in rr})}
 contrasts[foe]=dict(arms={str(m):bounds([v for v in rr if v['mode']==m])for m in (False,True)},True_minus_False=contrast(rr),per_linked_seed=per,descriptive_seed_range=[min(v[0]for v in per.values()),max(v[1]for v in per.values())],by_size={str(n):contrast([v for v in rr if v['size']==n])for n in (6,8)},by_variant={x:contrast([v for v in rr if v['variant']==x])for x in ('compound',)})
work={};groups=defaultdict(list);count=0;main=qnodes=0
for line in(D/'queries.jsonl').open(encoding='utf8'):
 q=json.loads(line);g=games[q['slot']];z=q['result'];count+=1;main+=z['nodes'];qnodes+=z['qnodes'];key=('candidate'if q['candidate']else'foe')+'_'+str(g['mode']);w=work.setdefault(key,dict(queries=0,main=0,q=0,caller_seconds=0,kernel_seconds=0,caller_max_seconds=0,depths=Counter(),qpolicies=Counter(),causes=Counter()))
 w['queries']+=1;w['main']+=z['nodes'];w['q']+=z['qnodes'];w['caller_seconds']+=q['caller_seconds'];w['kernel_seconds']+=z['elapsed_seconds'];w['caller_max_seconds']=max(w['caller_max_seconds'],q['caller_seconds']);w['depths'][z['completed_depth']]+=1;w['qpolicies'][str((z['result_ordinary_qdepth'],z['result_check_hard_qdepth']))]+=1;w['causes'][z['termination_reason']]+=1
 if q['candidate']:groups[(g['name'],q['before_sha256'],z['completed_depth'],z['result_ordinary_qdepth'],z['result_check_hard_qdepth'])].append(dict(mode=g['mode'],score=z['score'],action=z['action']))
matched=score_diff=action_diff=0
for vv in groups.values():
 a=[v for v in vv if not v['mode']];b=[v for v in vv if v['mode']]
 for x in a:
  for y in b:matched+=1;score_diff+=x['score']!=y['score'];action_diff+=x['action']!=y['action']
assert count==result['counts']['queries']and main==result['counts']['main']and qnodes==result['counts']['q']
out=dict(status='PASS_PLANNED_CELL_ARITHMETIC',contrasts=contrasts,work=work,queries=count,main=main,q=qnodes,main_plus_q=main+qnodes,producer_seconds=result['seconds'],matched_complete_policy_pairs=matched,matched_score_differences=score_diff,matched_action_differences=action_diff,missing=result['missing'],physical_terminal=result['terminal'],physical_UNKNOWN=result['unknown'],scope='Eightlinkedseedblocks/2sizes/compoundmechanism/bothroles/fixedfoes. Seedrange is descriptive minlower/maxupper, not a populationconfidenceinterval. All128physicalslots retained, includingUNKNOWN. Same-policy pairs canrepeat dependent contexts, notindependentexamples. No learning/default/piece-price/compound-effect causal gain. Allsame-targetpairs are descriptive, notindependentproof.')
write_json(D/'analysis.json',out)
print(json.dumps(dict(contrasts=contrasts,queries=count,main=main,q=qnodes,matched_policy_pairs=matched,matched_score_differences=score_diff,matched_action_differences=action_diff),indent=2))
