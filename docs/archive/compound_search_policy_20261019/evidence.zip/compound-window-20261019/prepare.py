from pathlib import Path
import sys,json,time,hashlib
from dataclasses import replace,asdict
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import *
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
D=Path(__file__).resolve().parent;start=time.perf_counter();rules=[];roots=[]
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
for seed in range(651001,651009):
 for n in (6,8):
  assert time.perf_counter()-start<120
  for fn in ('rollout','advisor','slack'):
   flags=json.loads(Path('.local_agent',fn+'.json').read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
  cfg=GeneratorConfig(seed=seed,board_size=n,setup_preset='classic_like',movement_symmetry='none',allow_hybrid=True,max_generation_attempts=64)
  g=generate_game(cfg)
  act=RuleSemanticAction(name='generated_pair_shift',type_ids=tuple(t.type_id for t in g.ruleset.piece_types if not t.is_anchor),geometry=RuleGeometrySpec(kind='leap',offset=(1,2),owner_relative=True),target_relation='empty',composition='augment',effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),RuleActionEffect('shift',from_ref=RuleSquareRef('offset_from_source',offset=(0,1),owner_relative=True),to_ref=RuleSquareRef('offset_from_source',offset=(0,2),owner_relative=True),piece_owner='self')),invariants=(RuleInvariant('own_anchor_safe'),))
  rule=replace(g.ruleset,semantic_actions=(act,),metadata={**g.ruleset.metadata,'research_recipe':'prospective_twoactor_window'});c=compile_semantic_ruleset(rule);name=str(seed)+'-'+str(n)+'-compound'
  row=dict(name=name,seed=seed,n=n,rule=ruleset_to_dict(rule),config=asdict(cfg),special_pattern_ids=[p.pattern_id for p in c.ir.patterns if p.name=='generated_pair_shift'])
  try:compile_native_semantic_rules(c);row['status']='SUPPORTED'
  except NativeUnsupportedRuleError as exc:row.update(status='REFUSED',refusal=str(exc))
  v=build_ruleset_profile(g.compiled_ruleset,EvaluationConfig());anchors={t.type_id for t in rule.piece_types if t.is_anchor}
  row['board_values']={t.type_id:0 if t.type_id in anchors else round(v.board_value_by_type[t.type_id]*.256)for t in rule.piece_types};row['hand_values']={t.type_id:0 if t.type_id in anchors else round(v.hand_value_by_base_type[t.type_id]*.256)for t in rule.piece_types}
  s=GameSession(c);row['opening_compound_actions']=sum(getattr(a,'pattern_id',None)in row['special_pattern_ids']for a in s.legal_actions())
  roots.append(dict(name=name,phase=0,record=json.loads(serialize_game_record(s.to_record())),state_sha256=digest(s.state),witness_sha256=digest(s._search_witnesses)));rules.append(row)
write_json(D/'inputs.json',dict(rules=rules,roots=roots))
write_json(D/'prepared-result.json',dict(status='COMPLETE',rules=len(rules),supported=sum(r['status']=='SUPPORTED'for r in rules),opening_compound=sum(r['opening_compound_actions']for r in rules),seconds=time.perf_counter()-start,exclusions='None: no postgeneration filter/fitness/refusal or trigger availability selection. Fullgeneratedtypes/promotion/drop/history retained.'))
print('PREPARED',len(rules),[r['status']for r in rules],sum(r['opening_compound_actions']for r in rules),time.perf_counter()-start)
