"""Actual paid root-prior cost gate, existing APIs, unchanged static leaves."""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path(__file__).resolve().parent)]
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from root_prior import root_prior
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;A=json.loads((D.parent/'compound-policy-alias-20261019'/'result.json').read_bytes());start=time.perf_counter();rows=[];status='COMPLETE';error=None
def poll():
 if time.perf_counter()-start>=120:raise TimeoutError('GLOBAL120S')
 for n in ('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('STOP')
try:
 for row in A['rows']:
  c=compile_semantic_ruleset(ruleset_from_dict(row['rule']));nr=compile_native_semantic_rules(c);s=GameSession(c);before=(s.state,s.to_record(),s.history,s._search_witnesses)
  for depth,seconds in ((2,1.),(8,.05)):
   for use_prior in (False,True):
    poll();e=SemanticSearchEngine(c,nr,board_values=row['board'],hand_values=row['hand'],tt_megabytes=0);tick=time.perf_counter();pr=root_prior(c,nr,s,row['board'],row['hand'],seconds,poll)if use_prior else None;z=None
    if pr is None or pr['status']=='COMPLETE':
     remain=seconds-(time.perf_counter()-tick)
     if remain>.001:z=e.search(s,SearchLimits(max_depth=depth,max_nodes=131072 if depth==2 else None,max_time_seconds=remain,quiescence_max_depth=0),root_window_pruning=True,root_order_hint=None if pr is None else pr['hint'])
    item=dict(name=row['name'],depth=depth,allowance=seconds,use_prior=use_prior,prior=None if pr is None else dict(pr,hint=record_value(pr['hint'])),result=None if z is None else record_value(z),whole_call_seconds=time.perf_counter()-tick)
    if z is not None:
     leaf=GameSession.replay(c,s.to_record())
     for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a)
     if depth==2 and z.completed_depth==2:assert z.score==row['root_native']['result']['score']
    assert before==(s.state,s.to_record(),s.history,s._search_witnesses);rows.append(item);del e
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'gate-result.json',dict(status=status,error=error,rows=rows,seconds=time.perf_counter()-start,global_cap_seconds=120,scope='16exposedtwohelperrules/64coldcalls. Priorcostdeductedfromsamekernelallowance, publicoverheadstillpaid/notguaranteedwholeAPIdeadline. Rootdynamicranking only, unchangedstatic/q0leaf. Fixedconfigcoefficients[1,1,1], no learning/oracle labels/model/API changes. Gateoperationalcost, notutility.'))
print('ROOT_PRIOR_GATE',status,error,len(rows),time.perf_counter()-start)
