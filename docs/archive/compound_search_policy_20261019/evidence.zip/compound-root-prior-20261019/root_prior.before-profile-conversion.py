"""Existing-API full-child root prior; no trained parameters or state truncation."""
import time
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native.semantic import guarded_actions,make_checked,terminal_status,evaluate,public_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import record_value
_cfg=EvaluationConfig()
DYNAMIC=tuple(round(x*.256)for x in (_cfg.dynamic_mobility_weight,_cfg.promotion_potential_weight,_cfg.anchor_escape_weight))
def root_prior(c,nr,s,b,h,allowance,poll):
 start=time.perf_counter();pos=pack_semantic_search_position(c,nr,s);rows=[];best=None;score=None
 actions=guarded_actions(nr,pos)
 if len(actions)>1024:return dict(status='ACTION_CAP',hint=None,rows=[],seconds=time.perf_counter()-start,planned_actions=len(actions))
 for packed in actions:
  poll()
  if time.perf_counter()-start>=allowance:return dict(status='PRIOR_TIME_CAP',hint=None,rows=rows,seconds=time.perf_counter()-start,planned_actions=len(actions))
  child=make_checked(nr,pos,packed);nt=terminal_status(nr,child)
  if nt['status']!='ongoing':
   value=0 if nt.get('winner')in(None,-1)else 100000000 if nt['winner']==s.state.position.side_to_move else-100000000
  else:value=-evaluate(nr,child,board_values=b,hand_values=h,dynamic_values=DYNAMIC)
  a=public_action(nr,packed);rows.append(dict(packed=packed,action=record_value(a),score=value,terminal=nt))
  if score is None or value>score or value==score and packed<best[0]:best=(packed,a);score=value
 elapsed=time.perf_counter()-start
 return dict(status='COMPLETE'if elapsed<allowance else'PRIOR_TIME_CAP',hint=best[1]if best and elapsed<allowance else None,rows=rows,seconds=elapsed,planned_actions=len(actions),dynamic=list(DYNAMIC))
