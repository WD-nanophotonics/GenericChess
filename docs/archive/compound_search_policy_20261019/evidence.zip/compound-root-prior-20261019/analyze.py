"""Direct arithmetic from frozen root-prior calls, no new execution."""
from pathlib import Path
from collections import Counter
import json,sys
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;d=json.loads((D/'gate-result.json').read_bytes());groups={}
for depth in (2,8):
 for mode in (False,True):
  rr=[r for r in d['rows']if r['depth']==depth and r['use_prior']==mode];assert len(rr)==16
  groups[str((depth,mode))]=dict(planned=len(rr),usable=sum(r['result']is not None and r['result']['completed_depth']>=1 for r in rr),depths=dict(Counter(r['result']['completed_depth']for r in rr if r['result'])),main=sum(r['result']['nodes']for r in rr if r['result']),whole_call_seconds=sum(r['whole_call_seconds']for r in rr),prior_seconds=sum(r['prior']['seconds']for r in rr if r['prior']),prior_branches=sum(len(r['prior']['rows'])for r in rr if r['prior']),caller_max=max(r['whole_call_seconds']for r in rr))
out=dict(status='PASS_FROZEN_PRIOR_COST_ARITHMETIC',groups=groups,retained_completed_original_baseline=1,original_continuous_seconds=d['seconds'],D2_prior_over_baseline_wall=groups['(2, True)']['whole_call_seconds']/groups['(2, False)']['whole_call_seconds'],decision='DEFER_NEW_GAMES_AND_ENCODER_API',reason='Prioraddsroughly26percentof50msallowance(24percentofobservedwholecallerwall), D2slower3.44x; D8depthdistributionnotpositiveutility. Reducednodes arenotbenefitwhenfeaturesconsumeallowance. No newgames/training/model/default.',scope='Same16exposedtwohelperrules andequalallowanceprotocol, notwholeAPIharddeadline, generalperformance orlearningclaim.')
write_json(D/'analysis.json',out);print(out)
