"""Pure Core/Python reproduction of complete policy inputs, features and history."""
from pathlib import Path
from collections import Counter
from copy import copy
import sys,json,time,os,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.learning.policy import semantic_action_features,semantic_state_feature_vector,SemanticPolicyV0
from generic_chess.learning.policy_v1 import action_v1_components,SemanticPolicyV1
from generic_chess.learning.features import spatial_occupancy_features,localized_control_features,tactical_interaction_features
from generic_chess.native.semantic_engine import _core_pv_leaf_dynamic_features
D=Path(__file__).resolve().parent;T=D.parent;R=Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()));start=time.perf_counter();counts=Counter()
def load(n,f='result.json'):return json.loads((T/n/f).read_bytes())
def poll():
 assert time.perf_counter()-start<180
 for n in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def decode(a):
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
A=load('compound-policy-alias-20261019');F=load('compound-existing-features-20261019');L=load('compound-logit-audit-20261019');P=load('compound-logit-audit-20261019','input-provenance.json');meta={p['name']:p for p in P['rows']};sessions={}
for r in A['rows']:
 poll();c=compile_semantic_ruleset(ruleset_from_dict(r['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(r['record'])));aa=s.legal_actions();sessions[r['name']]=(c,s)
 for group in r['groups']:
  vectors=[]
  for alt in group['actions']:
   a=decode(alt['action']);assert a in aa;v0=semantic_action_features(c,s.state.position,a);v1,cat=action_v1_components(c,s.state.position,a);assert v0.tolist()==alt['v0']and v1.tolist()==alt['v1']and list(cat)==alt['categories'];child=copy(s);child.submit(a);assert digest(child.state)==alt['state_sha256'];vectors.append((tuple(v0),tuple(v1),cat));counts['alias_children']+=1
  assert len(set(vectors))==1;counts['alias_buckets']+=1
 m=meta[r['name']];state=semantic_state_feature_vector(s.state.position,c,_core_pv_leaf_dynamic_features(s,()));assert state.tolist()==m['state_features']and record_value(aa)==m['public_actions']
 v0=np.stack([semantic_action_features(c,s.state.position,a)for a in aa]);parts=[action_v1_components(c,s.state.position,a)for a in aa];base=np.stack([x[0]for x in parts]);cats=tuple(np.asarray([x[1][j]for x in parts],dtype=np.int64)for j in range(4));ids=m['Native_ids_in_Core_order']
 for l in [p for p in L['rows']if p['name']==r['name']]:
  p0=SemanticPolicyV0.from_dict(l['v0_model']);p1=SemanticPolicyV1.from_dict(l['v1_model']);assert np.allclose(p0.logits(state,v0),l['python_v0_logits'],rtol=0,atol=1e-12);actual=p1.logits(state,base,cats);raw=dict(zip(l['native_actions'],l['native_logits']));assert set(raw)==set(ids);assert max(abs(float(actual[i])-raw[k])for i,k in enumerate(ids))<1e-10;counts['retained_Native_logits_reconstructed']+=len(ids);counts['fixed_models_reconstructed']+=2
for row in F['rows']:
 poll();c,s=sessions[row['name']];types=tuple(sorted(c.support.type_metadata))
 for alt in row['alternatives']:
  a=decode(alt['action']);child=copy(s);child.submit(a);assert record_value(spatial_occupancy_features(child.state.position,types))==alt['spatial'];assert record_value(localized_control_features(child.state.position,c))==alt['localized'];assert tactical_interaction_features(child.state.position,c)==alt['tactical'];assert list(_core_pv_leaf_dynamic_features(s,(a,)))==alt['dynamic'];counts['existing_feature_children']+=1
H=load('policy-history-input-20261019');orig=load('policy-history-input-20261019','witness-inputs.json');c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(orig['rule']));observed=[]
for row in H['rows']:
 poll();s=GameSession.replay(c,deserialize_game_record(json.dumps(row['record'])));assert digest(s.state)==row['state_sha256']and digest(s._search_witnesses)==row['witness_sha256'];x=semantic_state_feature_vector(s.state.position,c,_core_pv_leaf_dynamic_features(s,()));assert x.tolist()==row['state_features'];observed.append(x.tolist());values=[]
 for rec in row['actions']:
  a=decode(rec['action']);child=copy(s);child.submit(a);value=0 if child.state.terminal_status.is_terminal else sum((1 if pc.owner==0 else-1)*orig['checkpoint']['board_weights'][pc.current_type_id]for pc in child.state.position.board if pc)*(1 if s.state.position.side_to_move==0 else-1);assert value==rec['root_perspective_D1_value'];assert semantic_action_features(c,s.state.position,a).tolist()==rec['policy_features'];values.append(value);counts['history_children']+=1
 assert max(values)==row['reference'];counts['history_parents']+=1
assert observed[0]==observed[1]and H['optimal_set_intersection']
write_json(D/'input-reader-result.json',dict(status='PASS_COMPLETE_POLICY_INPUT_FEATURE_HISTORY_RECONSTRUCTION',counts=dict(counts),seconds=time.perf_counter()-start,Native_absent_required=True,new_Native_calls=0,new_games=0,new_training=0,scope='FullrealSession records/80effectaliases, savedcomplete64randommodelparameters, all1040retainedNativeV1logits viaexplicitIDprovenance, existing160childfeatures, twoactualdifferenthistoryrecords/fourchildren. NoNativeexecution/build, universalinjectivity/utility orsharedoptimalsetdisjointness claim.'))
print('INPUT_READER',dict(counts),time.perf_counter()-start)
