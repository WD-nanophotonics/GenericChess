"""Captured-source-ready Core control and PV reader; Native never called."""
from pathlib import Path
from copy import copy
from collections import Counter
import os,sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.semantic_engine import _core_pv_leaf_dynamic_features
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;T=D.parent;R=Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()));start=time.perf_counter();counts=Counter()
def load(d,f='result.json'):return json.loads((T/d/f).read_bytes())
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
class Stop:
 def __init__(self):self.next=0;self.flag=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in ('rollout','advisor','slack'):
    f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());self.flag|=bool(f.get('stopped')or f.get('user_paused'))
  return self.flag or now-start>180
stop=Stop()
def poll():
 if stop.is_cancelled():raise TimeoutError('REAL_STOP_OR180S')
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
class Material:
 def __init__(self,b,h):self.b=b;self.h=h
 def evaluate(self,s):
  v=sum((1 if p.owner==0 else-1)*self.b[p.current_type_id]for p in s.position.board if p)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items())
  return v*(1 if s.position.side_to_move==0 else-1)
def checked_ref(s,c,b,h,ref,depth):
 poll();complete=ref['statistics']['completed_depth']>=depth or ref['cause']in('root_immediate_win','terminal_position')
 if not complete:counts['original_UNKNOWN_not_rerun']+=1;return
 st=SearchStatistics();a,v,pv,cause=run_root_search(s.state,c,Material(b,h),TranspositionTable(max_entries=1),SearchLimits(max_depth=depth,max_nodes=200000,max_time_seconds=3,quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
 assert st.completed_depth>=depth or cause in('root_immediate_win','terminal_position'),cause
 assert v==ref['score']and record_value(a)==ref['action'],(v,ref['score'],record_value(a),ref['action'])
 counts['closed_Core_targets_rebuilt']+=1;counts['fresh_Core_main']+=st.nodes;counts['fresh_Core_q']+=st.qnodes
def pv(s,c,z):
 poll();before=(s.state,s.to_record(),s.history,s._search_witnesses);leaf=copy(s);line=[decode(a)for a in z['decision_line']]
 for a in line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['non_game_PV_edges']+=1
 if z.get('dynamic_features'):assert list(_core_pv_leaf_dynamic_features(s,tuple(line)))==z['dynamic_features']
 assert before==(s.state,s.to_record(),s.history,s._search_witnesses);counts['Native_receipts_Core_replayed']+=1
prepared=json.loads((D/'prepared.json').read_bytes());c=compile_semantic_ruleset(ruleset_from_dict(prepared['rule']));cc=load('compound-consumer-20261019')
for row in cc['rows']:
 p=next(x for x in prepared['parents']if x['phase']==row['phase']);s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));assert digest(s.state)==p['state_sha256'];checked_ref(s,c,prepared['board_values'],prepared['hand_values'],row['core'],2)
 for z in row['native']:pv(s,c,z['result'])
W=load('compound-window-20261019','inputs.json');rules={r['name']:r for r in W['rules']};O=load('compound-ordinal-gate-20261019')
for row in O['rows']:
 r=rules[row['name']];c=compile_semantic_ruleset(ruleset_from_dict(r['rule']));s=GameSession(c);assert row['same_hand']==r['hand_values']
 for label,p in row['profiles'].items():
  b=row['static_board']if label=='static'else row['ordinal_board'];checked_ref(s,c,b,row['same_hand'],p['core'],2);pv(s,c,p['native'])
A=load('compound-policy-alias-20261019');ac={r['name']:r for r in A['rows']};sessions={}
for row in A['rows']:
 c=compile_semantic_ruleset(ruleset_from_dict(row['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(row['record'])));sessions[row['name']]=(c,s);checked_ref(s,c,row['board'],row['hand'],row['root_core'],2);pv(s,c,row['root_native']['result'])
 pair=row['chosen_pair']
 if pair:
  for alt in pair['alternatives']:
   child=copy(s);child.submit(decode(alt['action']));assert digest(child.state)==alt['state_sha256'];checked_ref(child,c,row['board'],row['hand'],alt['child_reference'],1)
C=load('compound-capacity-20261019')
for row in C['rows']:
 c=compile_semantic_ruleset(ruleset_from_dict(row['rule']))
 for p in row['parents']:
  s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));assert digest(s.state)==p['state_sha256']
  for index,d in enumerate(p['decisions']):
   z=d['decision']
   if index==0:
    ref=dict(action=z['action'],score=z['score'],cause=z['termination_reason'],statistics=dict(completed_depth=z['completed_depth']));checked_ref(s,c,row['board'],row['hand'],ref,2)
   leaf=copy(s)
   for a in z['principal_variation']:leaf.submit(decode(a));counts['public_Core_PV_edges']+=1
H=load('compound-alias-hint-20261019');c,s=sessions[H['name']]
for r in H['rows']:pv(s,c,r['result'])
for ref in H['references']:
 if not ref['complete']:counts['original_UNKNOWN_not_rerun']+=1
 else:raise AssertionError('Unplanned fresh hint reference')
P=load('compound-root-prior-20261019','gate-result.json');score_cache={}
for row in P['rows']:
 c,s=sessions[row['name']];r=ac[row['name']];pv(s,c,row['result'])
 if row['result']['completed_depth']==2:assert row['result']['score']==r['root_native']['result']['score']
 prior=row['prior']
 if prior:
  assert prior['status']=='COMPLETE';aa={json.dumps(record_value(a),sort_keys=True)for a in s.legal_actions()};assert aa=={json.dumps(a['action'],sort_keys=True)for a in prior['rows']}
  for v in prior['rows']:
   poll();key=(row['name'],json.dumps(v['action'],sort_keys=True))
   if key not in score_cache:
    a=decode(v['action']);child=copy(s);child.submit(a)
    if child.state.terminal_status.is_terminal:score=0 if child.state.terminal_status.winner is None else 100000000 if child.state.terminal_status.winner==s.state.position.side_to_move else-100000000
    else:
     m=Material(r['board'],r['hand']).evaluate(child.state);dy=_core_pv_leaf_dynamic_features(s,(a,));value0=m*(1 if child.state.position.side_to_move==0 else-1)+sum(x*w for x,w in zip(dy,prior['dynamic']));score=value0*(1 if s.state.position.side_to_move==0 else-1)
    score_cache[key]=score;counts['distinct_full_Core_prior_children']+=1
   assert score_cache[key]==v['score'],(key,score_cache[key],v['score']);counts['prior_score_receipts_checked']+=1
  best=min(prior['rows'],key=lambda v:(-v['score'],v['packed']));assert best['action']==prior['hint']
assert counts['Native_receipts_Core_replayed']==148
write_json(D/'controls-reader-result.json',dict(status='PASS_CLOSED_CORE_CONTROLS_AND_ALL_NON_GAME_PVS',counts=dict(counts),seconds=time.perf_counter()-start,Native_search_disabled=True,original_UNKNOWN_references_rerun=0,scope='OnlyoriginalclosedCoretargets repeated; all148retainednon-gameNativePV/features replayed, fullprior scores reconstructed. Original2hintUNKNOWN notrerun. NoNative/games/training, allCoretargets remainfinite/objective-specific.'))
print('CONTROLS_READER',dict(counts),time.perf_counter()-start)
