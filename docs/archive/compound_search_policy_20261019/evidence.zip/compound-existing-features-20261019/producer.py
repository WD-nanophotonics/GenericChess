"""Finite existing child-feature alternatives for effect aliases, no encoder change."""
from pathlib import Path
from collections import Counter
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove
from generic_chess.core.coordinates import Square
from generic_chess.learning.features import spatial_occupancy_features,localized_control_features,tactical_interaction_features
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native.semantic import make_checked,spatial_features,dynamic_features
from generic_chess.native.semantic_engine import _core_pv_leaf_dynamic_features
D=Path(__file__).resolve().parent;A=json.loads((D.parent/'compound-policy-alias-20261019'/'result.json').read_bytes());start=time.perf_counter();rows=[];counts=Counter();timing=Counter()
def poll():
 if time.perf_counter()-start>=120:raise TimeoutError('CONTINUOUS120S')
 for n in ('rollout','advisor','slack'):
  f=json.loads(Path('.local_agent',n+'.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('STOP')
def decode(v):
 a=dict(v);a['from_square']=Square(**a['from_square']);a['to_square']=Square(**a['to_square']);return SemanticBoardMove(**a)
for row in A['rows']:
 poll();c=compile_semantic_ruleset(ruleset_from_dict(row['rule']));nr=compile_native_semantic_rules(c);s=GameSession(c);root=pack_semantic_search_position(c,nr,s);special=row['chosen_pair'];selected=[v['action']for v in special['alternatives']]if special else[]
 for idx,g in enumerate(row['groups']):
  poll();rr=dict(name=row['name'],bucket=idx,alternatives=[],prespecified_target_pair=all(a in [v['action']for v in g['actions']]for a in selected),known_child_gap=special['child_score_gap']if special and all(a in [v['action']for v in g['actions']]for a in selected)else None)
  for alt in g['actions']:
   a=decode(alt['action']);tick=time.perf_counter();cs=GameSession.replay(c,s.to_record());cs.submit(a);timing['Core_full_child_seconds']+=time.perf_counter()-tick;tick=time.perf_counter();occ=spatial_occupancy_features(cs.state.position,tuple(nr.type_ids));loc=localized_control_features(cs.state.position,c);timing['Core_spatial_control_seconds']+=time.perf_counter()-tick
   tick=time.perf_counter();tactical=tactical_interaction_features(cs.state.position,c);timing['Core_tactical_seconds']+=time.perf_counter()-tick
   tick=time.perf_counter();np=make_checked(nr,root,pack_semantic_action(nr,s.state.position,a));timing['Native_checked_seconds']+=time.perf_counter()-tick;tick=time.perf_counter();nf=spatial_features(nr,np);nd=dynamic_features(nr,np);timing['Native_spatial_dynamic_seconds']+=time.perf_counter()-tick
   flat=tuple(x for owner in (0,1)for t in nr.type_ids for x in occ[str(owner)+':'+t]);assert flat==nf['occupancy']and loc==nf['localized_control'];assert tuple(nd)==_core_pv_leaf_dynamic_features(s,(a,))
   rr['alternatives'].append(dict(action=alt['action'],spatial=record_value(occ),localized=record_value(loc),tactical=tactical,dynamic=list(nd)));counts['children']+=1
  for field in ('spatial','localized','tactical','dynamic'):
   distinct=len({json.dumps(v[field],sort_keys=True)for v in rr['alternatives']})>1;rr['distinguished_by_'+field]=distinct;counts[field+'_distinguished']+=distinct
  rr['distinguished_by_existing_union']=any(rr['distinguished_by_'+x]for x in ('spatial','localized','tactical','dynamic'));counts['union_distinguished']+=rr['distinguished_by_existing_union']
  if rr['known_child_gap']not in(None,0):counts['different_value_pairs']+=1;counts['different_value_spatial_distinguished']+=rr['distinguished_by_spatial'];counts['different_value_union_distinguished']+=rr['distinguished_by_existing_union']
  rows.append(rr)
write_json(D/'result.json',dict(status='PASS_EXISTING_FEATURE_FEASIBILITY',rows=rows,counts=dict(counts),timing=dict(timing),seconds=time.perf_counter()-start,global_cap_seconds=120,new_searches=0,new_games=0,optimizer_updates=0,scope='Only80retainedfeaturealiasbuckets/160actualCorechildren. Existingchildpositionfeaturescanbealternativefutureorderinginputs; no newencoder/schema/model/consumeractivation. ActualPython/Nativefeatureparity onthisfinitecorpus, isolatedcostnotwholepaidorderinggain andNativehistoryfeaturesnotfullhistoryencoding.'))
print('EXISTING_FEATURES',dict(counts),dict(timing),time.perf_counter()-start)
