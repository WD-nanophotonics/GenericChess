"""Effect-distinct action-feature aliases, bounded Core references, no training."""
from pathlib import Path
from dataclasses import replace
from collections import defaultdict,Counter
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict,RuleSquareRef
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.identity import position_identity_key
from generic_chess.learning.policy import semantic_action_features
from generic_chess.learning.policy_v1 import action_v1_components
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action,snapshot_matches
from generic_chess.native.semantic import make_checked,snapshot
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;I=json.loads((D.parent/'compound-window-20261019'/'inputs.json').read_bytes());start=time.perf_counter();deadline=start+120
class Stop:
 def __init__(self):self.next=0;self.flag=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in ('rollout','advisor','slack'):
    f=json.loads(Path('.local_agent',n+'.json').read_bytes());self.flag|=bool(f.get('stopped')or f.get('user_paused'))
  return self.flag or now>=deadline
stop=Stop()
def poll():
 if stop.is_cancelled():raise TimeoutError('STOP_OR_GLOBAL120S')
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
class Material:
 def __init__(self,r):self.r=r
 def evaluate(self,s):
  v=sum((1 if p.owner==0 else-1)*self.r['board_values'][p.current_type_id]for p in s.position.board if p)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.r['hand_values'].items())
  return v*(1 if s.position.side_to_move==0 else-1)
counts=Counter()
def core(s,c,r,depth):
 poll();st=SearchStatistics();t=time.perf_counter();a,v,pv,cause=run_root_search(s.state,c,Material(r),TranspositionTable(max_entries=1),SearchLimits(max_depth=depth,max_nodes=200000,max_time_seconds=min(1,deadline-time.perf_counter()),quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
 counts['Core_queries']+=1;counts['Core_main']+=st.nodes
 return dict(action=record_value(a),score=v,pv=record_value(pv),cause=cause,statistics=record_value(st),seconds=time.perf_counter()-t,complete=st.completed_depth==depth or cause in ('root_immediate_win','terminal_position'))
rows=[];status='COMPLETE';error=None
try:
 for r in I['rules']:
  poll();base=ruleset_from_dict(r['rule']);near=replace(base.semantic_actions[0],name='near_helper_shift');far=replace(near,name='far_helper_shift',effects=(near.effects[0],replace(near.effects[1],to_ref=RuleSquareRef('offset_from_source',offset=(0,3),owner_relative=True))))
  rule=replace(base,semantic_actions=(near,far));c=compile_semantic_ruleset(rule);nr=compile_native_semantic_rules(c);s=GameSession(c);before=(s.state,s.to_record(),s.history,s._search_witnesses);special={p.pattern_id for p in c.ir.patterns if p.name in ('near_helper_shift','far_helper_shift')};root=pack_semantic_search_position(c,nr,s);aa=s.legal_actions();groups=defaultdict(list);ident={}
  row=dict(name=r['name'],rule=ruleset_to_dict(rule),board=r['board_values'],hand=r['hand_values'],record=json.loads(serialize_game_record(s.to_record())),legal=len(aa),groups=[],chosen_pair=None)
  for a in aa:
   poll();v0=semantic_action_features(c,s.state.position,a);v1,cat=action_v1_components(c,s.state.position,a);child=GameSession.replay(c,s.to_record());child.submit(a);snap=snapshot(nr,make_checked(nr,root,pack_semantic_action(nr,s.state.position,a)));assert snapshot_matches(snap,child.state.position,nr,c)and snap==snapshot(nr,pack_semantic_search_position(c,nr,child));counts['checked_edges']+=1
   ident[a]=dict(action=record_value(a),v0=v0.tolist(),v1=v1.tolist(),categories=cat,position_key=str(position_identity_key(child.state.position,c)),state_sha256=digest(child.state))
   if a.pattern_id in special:groups[(tuple(v0),tuple(v1),cat)].append((a,child))
  for key,values in groups.items():
   if len(values)<2:continue
   diff=len({ident[a]['position_key']for a,_ in values})>1
   row['groups'].append(dict(actions=[ident[a]for a,_ in values],different_position=diff));counts['alias_buckets']+=1;counts['different_position_buckets']+=diff
  choices=sorted((values for values in groups.values()if len(values)>=2 and len({ident[a]['position_key']for a,_ in values})>1),key=lambda vv:repr(vv[0][0]))
  if choices:
   pair=[dict(**ident[a],child_reference=core(child,c,r,1))for a,child in sorted(choices[0],key=lambda pair:repr(pair[0]))[:2]]
   assert pair[0]['v0']==pair[1]['v0']and pair[0]['v1']==pair[1]['v1']and pair[0]['categories']==pair[1]['categories']
   complete=all(x['child_reference']['complete']for x in pair);gap=pair[0]['child_reference']['score']-pair[1]['child_reference']['score']if complete else None
   row['chosen_pair']=dict(alternatives=pair,complete=complete,child_score_gap=gap);counts['prespecified_pairs']+=1;counts['complete_pairs']+=complete;counts['unequal_complete_values']+=complete and gap!=0
  ref=core(s,c,r,2);row['root_core']=ref
  e=SemanticSearchEngine(c,nr,board_values=r['board_values'],hand_values=r['hand_values'],tt_megabytes=0);tick=time.perf_counter();z=e.search(s,SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(1,deadline-time.perf_counter()),quiescence_max_depth=0),root_window_pruning=True);row['root_native']=dict(result=record_value(z),seconds=time.perf_counter()-tick);counts['Native_queries']+=1;counts['Native_main']+=z.nodes;del e
  mapped=ref['score']-900000000 if ref['score']>=900000000 else ref['score']+900000000 if ref['score']<=-900000000 else ref['score']
  row['root_comparable']=ref['complete']and z.completed_depth==2;row['root_score_equal']=z.score==mapped if row['root_comparable']else None
  if row['root_comparable']:assert row['root_score_equal']
  assert before==(s.state,s.to_record(),s.history,s._search_witnesses);rows.append(row)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,rows=rows,counts=dict(counts),seconds=time.perf_counter()-start,global_cap_seconds=120,scope='16derivedexposedcompletecompoundrules, sameprimarygeometry/twoeffectcount, differenthelperdestinations. PureV0/V1, no models/learner/API. Onepredefinedpair/rule CoreD1. Nativebranches remainexact; no measuredlearning/strengthloss/all-domainclaim.'))
print('ALIAS_CONTROL',status,error,dict(counts),time.perf_counter()-start)
