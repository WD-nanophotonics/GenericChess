"""Exact completed D2 quiet-q support counts by recursion depth."""
import sys,time,importlib.util
from pathlib import Path
from collections import Counter
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('counts',B/'q_execution_counts.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
base_inc=c.inc;depths=[];extra=Counter()
def inc(kind):
 base_inc(kind)
 if c.qlevel:extra[(c.iteration,depths[-1] if depths else -1,kind)]+=1
def qcall(*a,**kw):
 depths.append(a[3])
 try:return c.quiescence(*a,**kw)
 finally:depths.pop()
def main():
 global extra,depths
 start=time.perf_counter();out=dict(complete=False,question='Is the completed q4 D2 work dominated by discarded candidates or by deeper accepted tactical recursion?',declared=dict(qdepths=[1,4],orders=2,max_depth=2,max_nodes=32768,seconds_ceiling=30,whole_fuse=180),scope='Counting of completed fixed-work pairs, not8second utility timings. Existing one quiet weighted root, same actual hybrid backend. Plain/instrumented same decision/non-time work; qdepth tags do not alter traversal. Python counts omit opaque C trials. Retained parent-object identifiers are not full history identity.',rows=[])
 compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess'));board=c.CoreBoard(c.CASES[0],compiled);e=c.cm.w.weighted(compiled,c.VALUES['chess'])
 c.inc=inc
 for q in (1,4):
  for order in range(2):
   pair=[]
   for measured in ((False,True) if order==0 else (True,False)):
    stopped();assert time.perf_counter()-start<180;c.counts=Counter();c.seen_trials=set();c.seen_formal=set();c.parents={};c.iteration=c.qlevel=c.trialdepth=c.availability=0;depths=[];extra=Counter()
    s=c.GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;c.install(measured)
    if measured:c.sm._quiescence_runtime=qcall
    try:
     t=time.perf_counter();d=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,c.SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=q,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    finally:c.install(False)
    assert s.state is board.initial and d.completed_depth==2;v=record_value(d);pair.append(c.cm.clean(v));out['rows'].append(dict(q=q,order=order,measured=measured,wall=wall,decision=v,counts=[dict(iteration=i,qdepth=depth,kind=k,count=n) for (i,depth,k),n in sorted(extra.items())]))
   assert pair[0]==pair[1];write_record(B/'completed-q-support.json',out);print(q,order,'exact completed work',flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(B/'completed-q-support.json',out)
if __name__=='__main__':main()
