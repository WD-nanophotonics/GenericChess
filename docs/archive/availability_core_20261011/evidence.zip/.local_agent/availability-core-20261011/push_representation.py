"""Fixed-work nested representation stage attribution, no optimization."""
import sys,time,importlib.util
from pathlib import Path
from collections import Counter
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('split',B/'q_cost_split.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
r=q.qc.rtmod
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
module_names=('_runtime_position_identity','_semantic_component_diff_hash','action_to_dict','_identity_equal')
originals={n:getattr(r,n) for n in module_names};original_json=r.json
snapshot_updated=r.RuntimeCountsSnapshot.updated;history_append=r.RuntimeHistoryContext.append
entry_digest=r.RuntimeCountsSnapshot._entry_digest
def setup(active):
 for n,fn in originals.items():setattr(r,n,q.timed(n,fn) if active else fn)
 r.json=SimpleNamespace(dumps=q.timed('json_dumps',original_json.dumps),loads=original_json.loads) if active else original_json
 r.RuntimeCountsSnapshot.updated=q.timed('snapshot_updated',snapshot_updated) if active else snapshot_updated
 r.RuntimeCountsSnapshot._entry_digest=staticmethod(q.timed('entry_digest',entry_digest)) if active else staticmethod(entry_digest)
 r.RuntimeHistoryContext.append=staticmethod(q.timed('history_context_append',history_append)) if active else staticmethod(history_append)
def main():
 start=time.perf_counter();rows=[];c=q.qc.compile_ruleset_for_execution(q.qc.build_builtin_ruleset('western_chess'));board=q.qc.CoreBoard(q.qc.CASES[0],c);e=q.qc.cm.w.weighted(c,q.qc.VALUES['chess'])
 for native in (False,True):
  for order in range(2):
   pair=[]
   for measured in ((False,True) if order==0 else (True,False)):
    stopped();assert time.perf_counter()-start<90;q.reset();p=q.qc.AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=native,use_disk_cache=False)
    s=q.qc.GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses;q.configure(measured,profile=measured);setup(measured)
    try:
     t=time.perf_counter();d=p.choose_action(s,q.qc.SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    finally:setup(False);q.restore()
    assert s.state is board.initial;pair.append(q.qc.cm.clean(record_value(d)))
    rows.append(dict(native=native,order=order,measured=measured,wall=wall,decision=record_value(d),stages=[dict(iteration=i,qphase=phase,stage=n,metric=m,value=v,completed_iteration=(0<i<=d.completed_depth)) for (i,phase,n,m),v in sorted(q.stages.items())]))
   assert pair[0]==pair[1]
 out=dict(complete=True,seconds=time.perf_counter()-start,scope='Same one-root512node weightedq4. Instrumented and plain fixed-work pairs retain decisions/non-time counters. Nested exclusive timings split called wrappers; overhead remains, no timing sum across nested inclusives. No history/hash/action change.',rows=rows)
 write_record(B/'push-representation.json',out)
 for x in rows:
  if x['measured']:print(x['native'],x['order'],x['wall'],{v['stage']:round(v['value'],5) for v in x['stages'] if v['iteration']==2 and v['qphase'] and v['metric']=='exclusive_seconds'})
if __name__=='__main__':main()
