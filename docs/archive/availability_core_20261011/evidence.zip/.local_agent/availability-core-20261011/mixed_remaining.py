"""Remaining declared mixed cells; completed generator cells are not rerun."""
import sys,time,importlib.util,json
from pathlib import Path
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product')]
spec=importlib.util.spec_from_file_location('control',Path(__file__).parent/'installed_control.py');cm=importlib.util.module_from_spec(spec);spec.loader.exec_module(cm)
from generic_chess.learning.round5_benchmark import SearchSemanticCompiled
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from test_f24c_mixed_mechanic_certification import _compiled
from test_f24c_mixed_mechanic_certification_r1 import _simultaneous,_state
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path(__file__).parent
start=time.perf_counter();original=_compiled()
c=SearchSemanticCompiled(ir=original.ir,_legacy_compiled=original._legacy_compiled,support=original.support)
p=_simultaneous(c);state=_state(c,p);cfg=EvaluationConfig();e=Evaluator(c,build_ruleset_profile(c,cfg),cfg)
out=dict(complete=False,scope='Only four remaining predeclared mixed-rich-hand cells, using existing SearchSemanticCompiled read-only legacy profile adapter. Semantics and default evaluator unchanged; no benchmark or training invoked.',prior_partial='unfamiliar-generated-before-mixed-adapter.json',rows=[])
try:
 for order in range(2):
  signatures=[]
  for candidate in ((False,True) if order==0 else (True,False)):
   stopped();assert time.perf_counter()-start<90;cm.install(candidate)
   s=SimpleNamespace(state=state,compiled=c,_search_witnesses=(p,));t=time.perf_counter()
   d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   wall=time.perf_counter()-t;assert s.state is state;signatures.append(cm.clean(record_value(d)))
   out['rows'].append(dict(root='mixed-rich-hand',order=order,candidate=candidate,wall=wall,decision=record_value(d),pattern_count=len(c.ir.patterns),drop_patterns=sum(c._pattern_drop_kinds.values())))
  assert signatures[0]==signatures[1]
finally:cm.install(True)
out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(B/'mixed-remaining.json',out)
print(out['seconds'],[(r['candidate'],r['wall'],r['decision']['completed_depth']) for r in out['rows']])
