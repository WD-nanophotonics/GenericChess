"""Predeclared work curve, not extension of any frozen acceptance test."""
import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('control',B/'installed_control.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.search_backend_comparison import CoreBoard,CASES,VALUES
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
def main():
 start=time.perf_counter();out=dict(complete=False,question='Is fixed q4 D2 completion dominated by the required work envelope after the measured execution savings, versus lower ordinary-q diagnostic support?',decision='Use marginal completed-depth/work curves to choose execution optimization or completion allocation next. No label-fitting, default change or success threshold; q0/1 are scoped controls with changed leaf support, hard checked extension8 retained.',declared=dict(root='chess-middle',qdepths=[0,1,4],node_caps=[512,4096,32768],opposite_orders=2,seconds_per_call=8,whole_fuse=240),scope='New development diagnostic on one already exposed weighted2/5/3 quiet root. All modes share actual hybrid backend, evaluation, ordering, node caps and8second ceiling. Not equal supported horizon, WDL or continuation of frozen tests.',rows=[])
 write_record(B/'completion-work-curve.json',out)
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));case=CASES[0];assert case['id']=='chess-middle';board=CoreBoard(case,c);e=p.w.weighted(c,VALUES['chess'])
 for cap in (512,4096,32768):
  for order in range(2):
   for q in ((0,1,4) if order==0 else (4,1,0)):
    stopped();assert time.perf_counter()-start<240
    s=GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses;t=time.perf_counter()
    d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,SearchLimits(max_depth=2,max_nodes=cap,max_time_seconds=8,quiescence_max_depth=q,quiescence_hard_max_depth=8));assert s.state is board.initial
    out['rows'].append(dict(cap=cap,order=order,q=q,wall=time.perf_counter()-t,decision=record_value(d)));write_record(B/'completion-work-curve.json',out)
    print(cap,order,q,d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(B/'completion-work-curve.json',out)
if __name__=='__main__':main()
