"""Bounded first-action attribution; profiler self times exclude nested calls."""
import sys,time,cProfile,pstats,hashlib
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path('.local_agent/availability-core-20261011')
start=time.perf_counter();deadline=start+180
rows=[];total=cProfile.Profile()
cases=CASES+[dict(id='quiet-stalemate',game='chess',setup='7k/5Q2/6K1/8/8/8/8/8 b - - 0 1',moves=''),dict(id='quiet-checkmate',game='chess',setup='7k/6Q1/6K1/8/8/8/8/8 b - - 0 1',moves='')]
for case in cases:
 stopped();assert time.perf_counter()<deadline
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);engine=semantic_engine_for(c)
 states=[('root',board.initial)]+[(label,apply_action(board.initial,a,c)) for label,a in board.actions()[:16]]
 for label,state in states:
  expected=engine.has_legal_action(state.position);plain=0;profiled=0;p=cProfile.Profile()
  for repeat in range(8):
   stopped();assert time.perf_counter()<deadline
   for measured in ((False,True) if repeat%2==0 else (True,False)):
    t=time.perf_counter()
    if measured:p.enable()
    try:answer=engine.has_legal_action(state.position)
    finally:
     if measured:p.disable()
    elapsed=time.perf_counter()-t;assert answer==expected
    if measured:profiled+=elapsed
    else:plain+=elapsed
  stats=pstats.Stats(p);fns=[]
  for (file,line,name),(pc,nc,tt,ct,callers) in stats.stats.items():
   if 'generic_chess' in file:
    fns.append(dict(file=str(Path(file).relative_to(Path.cwd())),line=line,name=name,primitive_calls=pc,total_calls=nc,self_seconds=tt,inclusive_seconds=ct))
  rows.append(dict(root=case['id'],child=label,answer=expected,plain_seconds=plain,profiled_seconds=profiled,functions=sorted(fns,key=lambda x:-x['self_seconds'])))
out=dict(complete=True,scope='Same118 existing roots/first16lexical children;8opposite-order plain/profiled queries per state. cProfile self times exclude nested calls; inclusive times must not be summed. No speed, future native kernel or equal-time playing claim.',whole_batch_fuse_seconds=180,rows=rows,seconds=time.perf_counter()-start)
write_record(B/'profile.json',out)
summary=[]
for case in cases:
 rs=[r for r in rows if r['root']==case['id']];agg={}
 for r in rs:
  for fn in r['functions']:
   k=(fn['file'],fn['line'],fn['name']);a=agg.setdefault(k,dict(fn,self_seconds=0,inclusive_seconds=0,total_calls=0,primitive_calls=0))
   for f in ('self_seconds','inclusive_seconds','total_calls','primitive_calls'):a[f]+=fn[f]
 summary.append(dict(root=case['id'],states=len(rs),plain=sum(r['plain_seconds'] for r in rs),profiled=sum(r['profiled_seconds'] for r in rs),top_self=sorted(agg.values(),key=lambda x:-x['self_seconds'])[:20]))
write_record(B/'summary.json',summary);print(record_value(summary))
