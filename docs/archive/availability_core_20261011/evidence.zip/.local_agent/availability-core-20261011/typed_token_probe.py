"""Private bounded immutable token memo, exact old-byte oracle, no deployment."""
import sys,time,functools,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('control',B/'installed_control.py');cm=importlib.util.module_from_spec(spec);spec.loader.exec_module(cm)
from generic_chess.core import search_runtime as rt
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.search_backend_comparison import CoreBoard,CASES,VALUES
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
original=rt._component_token
def typed(value):
 t=type(value)
 if t in (int,bool,str,type(None)):return (t,value)
 if t is tuple:return (tuple,tuple(typed(x) for x in value))
 raise TypeError('unsupported memo key')
@functools.lru_cache(maxsize=2048)
def cached(key,address,value):return original(address,value)
def token(address,value):
 try:key=(typed(address),typed(value))
 except TypeError:return original(address,value)
 return cached(key,address,value)
def install(active):rt._component_token=token if active else original
def main():
 start=time.perf_counter();rows=[];oracle=[]
 # These exact encoding aliases were the preceding repair's failure class.
 for value in (None,False,0,True,1,(),(False,), (0,),((False,),),((0,),),((1,'P'),),((1,'P'),(2,'R'))):
  address=('aux',(17,0));a=original(address,value);b=token(address,value);assert a==b
  oracle.append(dict(address=address,value=record_value(value),hash=record_value(a)))
 assert token(('aux',(17,0)),False)!=token(('aux',(17,0)),0)
 # Unsupported mutable/float values stay uncached and preserve old encoder.
 for value in ([1,2], {'v':False}, 0.0, -0.0):assert token(('aux_unknown',(18,-1)),value)==original(('aux_unknown',(18,-1)),value)
 for case in CASES:
  c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);e=cm.w.weighted(c,VALUES[case['game']])
  for repeat in range(4):
   pair=[]
   for active in ((False,True) if repeat%2==0 else (True,False)):
    stopped();assert time.perf_counter()-start<180;cached.cache_clear();install(active)
    s=GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses;t=time.perf_counter()
    try:d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    finally:install(False)
    wall=time.perf_counter()-t;assert s.state is board.initial;pair.append(cm.clean(record_value(d)))
    rows.append(dict(root=case['id'],repeat=repeat,candidate=active,wall=wall,decision=record_value(d),cache_info=cached.cache_info()._asdict()))
   assert pair[0]==pair[1]
 out=dict(complete=True,seconds=time.perf_counter()-start,scope='Private prototype only: per-call cold bounded2048-entry typed immutable component-token memo. Exact old JSON/hash bytes preserved; tuple/int/bool/str/None cached, mutable/float values fallback. Not a state/legality/frontier cache or validation holdout. Work/evaluation/backend equal; no default change.',oracle=oracle,rows=rows)
 write_record(B/'typed-token-probe.json',out)
 for case in CASES:
  totals={a:sum(r['wall'] for r in rows if r['root']==case['id'] and r['candidate']==a) for a in (False,True)}
  print(case['id'],totals[True]/totals[False],flush=True)
if __name__=='__main__':main()
