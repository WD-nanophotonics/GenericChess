"""Resolve JSON stage attribution before attempting lazy history signatures."""
import sys,time,importlib.util
from pathlib import Path
from collections import Counter
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('qc',B/'q_execution_counts.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
r=c.rtmod;original_json=r.json;original_action=r.action_to_dict;counts=Counter()
def action(*a,**kw):
 t=time.perf_counter()
 try:return original_action(*a,**kw)
 finally:counts[(c.iteration,'action_dictionary_calls')]+=1;counts[(c.iteration,'action_dictionary_seconds')]+=time.perf_counter()-t
def dumps(value,*a,**kw):
 kind='action_signature' if isinstance(value,dict) and 'kind' in value else 'hash_token';t=time.perf_counter()
 try:return original_json.dumps(value,*a,**kw)
 finally:counts[(c.iteration,kind+'_calls')]+=1;counts[(c.iteration,kind+'_seconds')]+=time.perf_counter()-t
def main():
 global counts
 start=time.perf_counter();out=dict(complete=False,question='Does actual action-signature serialization justify a lazy internal history representation next?',declared=dict(root='chess-middle',q=4,max_depth=2,max_nodes=32768,max_seconds=30,opposite_orders=2,whole_fuse=180),scope='Separate exclusive action dict/JSON and tuple hash token encoding, plain/instrumented completed fixed-work pairs. JSON payload bytes unchanged. Known signature consumers include repeated-cycle/no-progress adjudication; no lazy/omitted history proposal implemented.',rows=[])
 compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess'));board=c.CoreBoard(c.CASES[0],compiled);e=c.cm.w.weighted(compiled,c.VALUES['chess'])
 for order in range(2):
  pair=[]
  for measured in ((False,True) if order==0 else (True,False)):
   c.iteration=0;c.qlevel=0;counts=Counter();c.install(measured);r.action_to_dict=action if measured else original_action;r.json=SimpleNamespace(dumps=dumps,loads=original_json.loads) if measured else original_json
   s=c.GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;st=c.time.perf_counter()
   try:d=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,c.SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   finally:r.action_to_dict=original_action;r.json=original_json;c.install(False)
   assert s.state is board.initial and d.completed_depth==2;v=c.record_value(d);pair.append(c.cm.clean(v));out['rows'].append(dict(order=order,measured=measured,wall=time.perf_counter()-st,decision=v,counts=[dict(iteration=i,metric=k,value=n) for (i,k),n in sorted(counts.items())]))
   c.stopped();assert time.perf_counter()-start<180
  assert pair[0]==pair[1];c.write_record(B/'signature-cost.json',out);print(order,'exact',flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;c.write_record(B/'signature-cost.json',out)
if __name__=='__main__':main()
