"""Owner-reflected imported boundary controls; not played user histories."""
import sys,time
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution,RuleAutomaticAdjudication
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands,GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import initial_state,legal_actions,apply_action
from generic_chess.core.terminal import terminal_result
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path('.local_agent/availability-core-20261011')
rows=[];start=time.perf_counter()
for kind in ('continuation','reply'):
 for owner in (0,1):
  n=8 if kind=='continuation' else 9;board=[[None]*n for _ in range(n)]
  entries=((0,'Q',0,1),(0,'K',6,0),(1,'K',7,7)) if kind=='continuation' else ((0,'K',4,0),(1,'K',4,8))
  for old,tid,f,r in entries:
   if owner:f,r,old=n-1-f,n-1-r,1-old
   board[r][f]=Piece(old,tid,tid)
  rule=replace(build_builtin_ruleset('western_chess' if kind=='continuation' else 'standard_shogi'),max_ply=1,initial_position=tuple(map(tuple,board)))
  if kind=='continuation':rule=replace(rule,automatic_adjudications=(RuleAutomaticAdjudication('checking-continuation',1),))
  c=compile_ruleset_for_execution(rule);initial=initial_state(c)
  hands=(Hands((('P',1),)),Hands())
  if owner:hands=hands[::-1]
  pos=replace(initial.position,side_to_move=owner,**(dict(hands=hands) if kind=='reply' else {}));key=repetition_identity_key(pos,c)
  s=GameState(pos,0,((key,1),),initial.terminal_status,(HistoryRecord(key,-1,'',False),));s=replace(s,terminal_status=terminal_result(s,c))
  provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None
  rt=SearchPathRuntime.from_state(s,c,history_witnesses=(pos,),legal_binding_provider=provider)
  expected=legal_actions(s,c);assert set(rt.legal_actions())==set(expected)
  if kind=='reply':
   wanted=(4,7) if owner==0 else (4,1)
   action=next(a for a in expected if getattr(a,'from_square',None) is None and (a.to_square.file,a.to_square.rank)==wanted)
   assert not provider.supports_position(pos,0)
  else:
   wanted=(0,7) if owner==0 else (7,0)
   action=next(a for a in expected if (a.to_square.file,a.to_square.rank)==wanted and pos.board[a.from_square.rank*n+a.from_square.file].current_type_id=='Q')
  child=apply_action(s,action,c)
  with rt.pushed(action):
   assert rt.position==child.position and rt.terminal_status==child.terminal_status
   reply=legal_actions(child,c);assert set(rt.legal_actions())==set(reply)
   if kind=='continuation':assert not rt.terminal_status.is_terminal and len(reply)==2
   rows.append(dict(kind=kind,owner=owner,root_actions=len(expected),child_actions=len(reply),position=record_value(pos),action=record_value(action),terminal=record_value(rt.terminal_status),fallbacks=rt.legal_provider_fallbacks,failures=rt.legal_provider_operational_failures))
  rt.assert_balanced();assert rt.position is pos and rt.ply_count==0;stopped()
write_record(B/'reflected-boundary.json',dict(complete=True,scope='Four declared imported roots, two owner-reflected families; public complete sets/selected child/terminal/undo, strict Native capability fallback; no played-history claim.',seconds=time.perf_counter()-start,rows=rows));print([(r['kind'],r['owner'],r['root_actions'],r['child_actions'],r['fallbacks']) for r in rows])
