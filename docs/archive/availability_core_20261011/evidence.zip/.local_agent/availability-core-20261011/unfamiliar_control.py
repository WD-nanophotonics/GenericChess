"""Declared mixed rich-hand and two already exposed generator starts."""
import sys,time,importlib.util
from pathlib import Path
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product')]
spec=importlib.util.spec_from_file_location('control',Path(__file__).parent/'installed_control.py');cmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(cmod)
from generic_chess import compile_legacy_ruleset_for_semantic_execution
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.session.session import GameSession
from generic_chess.learning.round5_benchmark import SearchSemanticCompiled
from generic_chess.rules.schema import ruleset_to_dict
from test_f24c_mixed_mechanic_certification import _compiled,_mixed_ruleset
from test_f24c_mixed_mechanic_certification_r1 import _simultaneous,_state
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path(__file__).parent;out=dict(complete=False,whole_batch_fuse_seconds=240,scope='Two old generated starts size4seed7,size6seed21 and existing simultaneous rich-hand mixed input. Explicit supported semantic compilation, same existing default legacy-input Evaluator and512node q4 caller budgets; semantic legality/check remain Core authority. Mixed static profile inputs are limited, not valuation or full generated-domain coverage.',rows=[],inputs=[])
start=time.perf_counter();deadline=start+240
items=[]
for size,seed in ((4,7),(6,21)):
 game=generate_game(GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));compiled=compile_legacy_ruleset_for_semantic_execution(game.ruleset);s=GameSession(compiled)
 items.append((f'generated-{size}-{seed}',compiled,s.state,s._search_witnesses));out['inputs'].append(dict(name=items[-1][0],ruleset=ruleset_to_dict(game.ruleset),filters=record_value(game.generation_report)))
semantic=_compiled();compiled=SearchSemanticCompiled(ir=semantic.ir,_legacy_compiled=semantic._legacy_compiled,support=semantic.support);p=_simultaneous(compiled);items.append(('mixed-rich-hand',compiled,_state(compiled,p),(p,)));out['inputs'].append(dict(name='mixed-rich-hand',ruleset=ruleset_to_dict(_mixed_ruleset()),position=record_value(p)))
try:
 for name,c,state,witnesses in items:
  cfg=EvaluationConfig();e=Evaluator(c,build_ruleset_profile(c,cfg),cfg)
  engine=semantic_engine_for(c);signatures=[]
  for order in range(2):
   for candidate in ((False,True) if order==0 else (True,False)):
    stopped();assert time.perf_counter()<deadline;cmod.install(candidate)
    t=time.perf_counter();s=SimpleNamespace(state=state,compiled=c,_search_witnesses=witnesses)
    d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    assert s.state is state;signatures.append(cmod.clean(record_value(d)))
    out['rows'].append(dict(root=name,order=order,candidate=candidate,wall=wall,decision=record_value(d),pattern_count=len(c.ir.patterns),drop_patterns=sum(c._pattern_drop_kinds.values())))
   assert signatures[-1]==signatures[-2]
  write_record(B/'unfamiliar-control.json',out);print(name,'complete',flush=True)
finally:cmod.install(True)
out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(B/'unfamiliar-control.json',out)
