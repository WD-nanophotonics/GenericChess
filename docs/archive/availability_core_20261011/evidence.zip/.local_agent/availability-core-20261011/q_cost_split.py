"""One-root execution attribution and single-slot opportunity, no reuse."""
import sys,time,copy,importlib.util
from pathlib import Path
from collections import Counter
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('qc',B/'q_execution_counts.py');qc=importlib.util.module_from_spec(spec);spec.loader.exec_module(qc)
from generic_chess.core.search_runtime import SearchPathRuntime as MutableSearchRuntime
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
last_trial=None;stages=Counter();stack=[]
def timed(name,fn):
 def call(*a,**kw):
  t=time.perf_counter();frame=[0.0];stack.append(frame)
  try:return fn(*a,**kw)
  finally:
   elapsed=time.perf_counter()-t;stack.pop()
   if stack:stack[-1][0]+=elapsed
   key=(qc.iteration,bool(qc.qlevel),name)
   stages[key+('calls',)]+=1;stages[key+('inclusive_seconds',)]+=elapsed;stages[key+('exclusive_seconds',)]+=elapsed-frame[0]
 return call
base_trial=qc.trial;base_transition=qc.transition
def trial(self,parent,action,*a,**kw):
 global last_trial
 last_trial=None
 result=base_trial(self,parent,action,*a,**kw)
 last_trial=(id(parent),action) if result is not None else None
 return result
def transition(self,parent,action,*a,**kw):
 global last_trial
 if not qc.trialdepth:
  qc.inc('single_last_trial_match' if last_trial==(id(parent),action) else 'single_last_trial_miss')
  last_trial=None
 return base_transition(self,parent,action,*a,**kw)
qc.trial=trial;qc.transition=transition
runtime_orig={n:getattr(MutableSearchRuntime,n) for n in ('_push_impl','legal_actions','_gave_check','in_check')}
stage_old={n:qc.old[n] for n in ('_transition','_trial_child_if_s3_legal','has_legal_action','in_check')}
def configure(measured,profile=False):
 qc.install(measured)
 if profile:
  for n,fn in stage_old.items():qc.old[n]=timed('Engine'+n,fn)
  qc.rtmod.terminal_from_search_runtime=timed('terminal',qc.terminal)
  for n,fn in runtime_orig.items():setattr(MutableSearchRuntime,n,timed('Runtime'+n,fn))
def restore():
 for n,fn in stage_old.items():qc.old[n]=fn
 for n,fn in runtime_orig.items():setattr(MutableSearchRuntime,n,fn)
 qc.install(False)
def reset():
 global last_trial,stages,stack
 qc.counts=Counter();qc.seen_trials=set();qc.seen_formal=set();qc.parents={};qc.iteration=qc.qlevel=qc.trialdepth=qc.availability=0
 last_trial=None;stages=Counter();stack=[]
def main():
 start=time.perf_counter();rows=[];producers=[]
 c=qc.compile_ruleset_for_execution(qc.build_builtin_ruleset('western_chess'));board=qc.CoreBoard(qc.CASES[0],c);e=qc.cm.w.weighted(c,qc.VALUES['chess'])
 def session():
  s=qc.GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses;return s
 def player(native):return qc.AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=native,use_disk_cache=False)
 for native in (False,True):
  producer=player(native);pd=producer.choose_action(session(),qc.SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8))
  producers.append(dict(native=native,decision=record_value(pd),tt_entries=len(producer._tt)))
  for warm in (False,True):
   for budget in (1,4):
    for measured in ((False,True) if budget==1 else (True,False)):
     stopped();assert time.perf_counter()-start<240;reset();p=player(native)
     if warm:p._tt=copy.deepcopy(producer._tt);p._tt_q_depths=producer._tt_q_depths
     s=session();configure(measured)
     try:
      t=time.perf_counter();d=p.choose_action(s,qc.SearchLimits(max_depth=4,max_time_seconds=budget,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
     finally:restore()
     assert s.state is board.initial
     counts=[dict(iteration=i,qphase=q,kind=k,count=v,completed_iteration=(0<i<=d.completed_depth)) for (i,q,k),v in sorted(qc.counts.items())]
     rows.append(dict(native_requested=native,warm=warm,budget=budget,measured=measured,wall=wall,decision=record_value(d),counts=counts,retained_parents=len(qc.parents)))
    print('time',native,warm,budget,flush=True)
  pair=[]
  for measured in (False,True):
   reset();p=player(native);s=session();configure(measured,profile=measured)
   try:
    t=time.perf_counter();d=p.choose_action(s,qc.SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
   finally:restore()
   pair.append(qc.cm.clean(record_value(d)))
   rows.append(dict(fixed_profile=True,native_requested=native,measured=measured,wall=wall,decision=record_value(d),counts=[dict(iteration=i,qphase=q,kind=k,count=v,completed_iteration=(0<i<=d.completed_depth)) for (i,q,k),v in sorted(qc.counts.items())],stages=[dict(iteration=i,qphase=q,stage=n,metric=m,value=v,completed_iteration=(0<i<=d.completed_depth)) for (i,q,n,m),v in sorted(stages.items())]))
  assert pair[0]==pair[1]
 out=dict(complete=True,seconds=time.perf_counter()-start,whole_batch_fuse_seconds=240,scope='Existing Chess-middle only. Counts change timed work and are not equal-time utility comparisons; plain calls separately retain original behavior. Warm TT cloned from one512node producer per backend. Last-trial single-slot counters consume/clear after formal transition, do not retain/reuse any child. Fixed nested exclusive stage timing avoids double-counting but includes wrapper overhead. Opaque native trials are unmeasured. No frontier cache, order/evaluator/default changes.',producers=producers,rows=rows)
 write_record(B/'q-cost-split.json',out)
 print('complete',out['seconds'],flush=True)
if __name__=='__main__':main()
