"""Private memo: independent un-memoized full-hash lifecycle and typed tests."""
import sys,time,importlib.util,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('probe',B/'typed_token_probe.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
from generic_chess.core.pieces import Piece
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import legal_successors
from generic_chess.core.actions import action_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from rule_semantics_ir_fixtures import weird_rulesets
from scripts.research_record import write_record,record_value
from scripts.reserve_refresh_diagnostic import stopped
import pytest
def full_oracle(position,c):
 p.install(False)
 try:return p.rt._full_runtime_hash(position,c)
 finally:p.install(True)
def main():
 start=time.perf_counter();fixtures=weird_rulesets();rows=[[None]*8 for _ in range(8)]
 for owner,tid,f,r in ((0,'K',4,0),(1,'K',7,7),(0,'R',0,0),(0,'R',0,1),(0,'R',0,2),(0,'R',1,1),(1,'R',1,3),(1,'R',1,4)):rows[r][f]=Piece(owner,tid,tid)
 c=compile_ruleset_for_execution(replace(fixtures[2],initial_position=tuple(map(tuple,rows)),semantic_actions=(fixtures[1].semantic_actions[0],fixtures[2].semantic_actions[0]),drop_allowed={'R':((True,)*64,)*2,'TP':((False,)*64,)*2}))
 route=(((1,1),(1,3),False),((7,7),(6,7),False),((1,3),(1,4),False),((6,7),(5,7),False),((0,0),(1,1),True),((5,7),(4,7),False),(None,(0,0),False),((4,7),(3,7),False))
 out=dict(complete=False,scope='Existing recombined eight-ply lifecycle, every legal child against full hash with memo disabled. Exact typed auxiliary/history tests also run under private memo; no product cache.',public_children=0,rows=[])
 p.cached.cache_clear();p.install(True);s=GameSession(c)
 try:
  for ply in range(9):
   stopped();assert time.perf_counter()-start<90;rt=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses);pairs=legal_successors(s.state,c);assert tuple(a for a,_ in pairs)==rt.legal_actions()
   for a,child in pairs:
    with rt.pushed(a):
     assert rt.position==child.position and rt.terminal_status==child.terminal_status
     assert rt.runtime_hash==full_oracle(rt.position,c)
    assert rt.position is s.state.position;out['public_children']+=1
   rt.assert_balanced();drops=[a for a,_ in pairs if hasattr(a,'base_type_id')]
   if ply in (2,4,8):assert s.state.position.hands[0].count('R')>0 and not drops
   if ply==5:assert (s.state.position.board[9].current_type_id,dict(s.state.position.aux_state)[(0,-1)])==('TP',1)
   if ply==6:assert dict(s.state.position.aux_state)[(0,-1)]==0 and len(drops)==58
   out['rows'].append(dict(ply=ply,legal=len(pairs),drops=len(drops),hand=record_value(s.state.position.hands),aux=record_value(s.state.position.aux_state)))
   if ply==8:break
   source,target,semantic=route[ply]
   def selected(a):
    if (a.to_square.file,a.to_square.rank)!=target:return False
    if source is None:return hasattr(a,'base_type_id')
    return hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source and a.pattern_id.startswith('sem_')==semantic
   action,=[a for a,_ in pairs if selected(a)];out['rows'][-1]['selected']=action_to_dict(action);s.submit(action)
  out['cache_info']=p.cached.cache_info()._asdict()
  out['typed_test_exit']=int(pytest.main(['tests/product/test_runtime_aux_identity.py','-q','-p','no:cacheprovider']))
  assert out['typed_test_exit']==0;out['complete']=True
 finally:p.install(False);out['seconds']=time.perf_counter()-start;write_record(B/'token-semantics.json',out)
 print(out['complete'],out['public_children'],out['cache_info'],flush=True)
if __name__=='__main__':main()
