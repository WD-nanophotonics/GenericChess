"""Private compile-owned geometry-kind control; no checkpoint removal."""
import sys,time,inspect,textwrap
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
import generic_chess.core.semantic_executor as m
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path('.local_agent/availability-core-20261011')
NAMES=('_iter_candidates','_exists_s3_reply','iter_legal_action_bindings')
ORIGINAL={name:getattr(m.SemanticEngine,name) for name in NAMES}
PROTO={}
EXPR='any(\n            self.ir.geometry[g].kind == "drop"\n            for g in pattern.geometry_ids\n            if g in self.ir.geometry\n        )'
for name,fn in ORIGINAL.items():
 source=textwrap.dedent(inspect.getsource(fn));indent='    ' if name=='_iter_candidates' else '        '
 # Match original indents in the class-method source before dedenting.
 original=inspect.getsource(fn)
 needle=EXPR if name=='_iter_candidates' else EXPR.replace('\n            ','\n                ').replace('\n        )','\n            )')
 assert needle in original,name
 source=textwrap.dedent(original.replace(needle,'self._availability_kind[id(pattern)]'))
 ns=dict(vars(m));exec(compile(source,'private-kind-'+name,'exec'),ns);PROTO[name]=ns[name]
def install(candidate):
 for name,fn in (PROTO if candidate else ORIGINAL).items():setattr(m.SemanticEngine,name,fn)
def groups():
 cases=CASES+[dict(id='quiet-stalemate',game='chess',setup='7k/5Q2/6K1/8/8/8/8/8 b - - 0 1',moves=''),dict(id='quiet-checkmate',game='chess',setup='7k/6Q1/6K1/8/8/8/8/8 b - - 0 1',moves='')]
 result=[]
 for case in cases:
  c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);e=m.semantic_engine_for(c)
  e._availability_kind={id(p):any(e.ir.geometry[g].kind=='drop' for g in p.geometry_ids if g in e.ir.geometry) for p in e._patterns}
  states=[('root',board.initial)]+[(label,apply_action(board.initial,a,c)) for label,a in board.actions()[:16]]
  result.append((case,c,e,states))
 return result
def run():
 start=time.perf_counter();rows=[];gs=groups();deadline=start+180
 try:
  for repeat in range(32):
   for case,c,e,states in gs:
    stopped();assert time.perf_counter()<deadline
    for label,state in states:
     answers=[]
     for candidate in ((False,True) if repeat%2==0 else (True,False)):
      install(candidate);t=time.perf_counter();answer=e.has_legal_action(state.position);seconds=time.perf_counter()-t;answers.append(answer)
      rows.append(dict(root=case['id'],child=label,repeat=repeat,candidate=candidate,answer=answer,seconds=seconds))
     assert answers[0]==answers[1]
 finally:install(False)
 write_record(B/'kind-dispatch.json',dict(complete=True,scope='118same states;32opposite-order queries; same checkpoints and original candidate/trial/postconditions; private direct pattern identity lookup excludes metadata-miss fallback cost, so optimistic before integration.',seconds=time.perf_counter()-start,rows=rows))
 summary=[]
 for case,c,e,states in gs:
  values={a:sum(r['seconds'] for r in rows if r['root']==case['id'] and r['candidate']==a) for a in (False,True)}
  summary.append(dict(root=case['id'],baseline=values[False],candidate=values[True],ratio=values[True]/values[False]))
 write_record(B/'kind-dispatch-summary.json',summary);print(summary)
if __name__=='__main__':run()
