"""Old inline classification versus installed compile-owned classification."""
import sys,time,json,subprocess,importlib.util,statistics
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
import generic_chess.core.semantic_executor as m
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path('.local_agent/availability-core-20261011')
NAMES=('_iter_candidates','_exists_s3_reply','iter_legal_action_bindings')
CURRENT={n:getattr(m.SemanticEngine,n) for n in NAMES}
source=subprocess.check_output(['git','show','9146a2e5b06e3349a588a8dd1abc05cab5d0a78c:generic_chess/core/semantic_executor.py'],text=True)
(B/'baseline-semantic-executor.py').write_text(source,encoding='utf-8',newline='\n')
ns=dict(vars(m));exec(compile(source,'pinned-old-semantic-executor','exec'),ns)
BASELINE={n:getattr(ns['SemanticEngine'],n) for n in NAMES}
spec=importlib.util.spec_from_file_location('weighted',Path('.local_agent/weighted-backend-20261011/bridge.py'));w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
def install(candidate):
 for name,fn in (CURRENT if candidate else BASELINE).items():setattr(m.SemanticEngine,name,fn)
def clean(v):
 if isinstance(v,dict):return {k:clean(x) for k,x in v.items() if 'seconds' not in k and not k.startswith('time_')}
 if isinstance(v,list):return list(map(clean,v))
 return v
def run():
 start=time.perf_counter();deadline=start+600
 groups=[];out=dict(complete=False,baseline_sha='9146a2e5b06e3349a588a8dd1abc05cab5d0a78c',whole_batch_fuse_seconds=600,primitive=[],fixed=[],time=[],scope='Old inline methods vs installed metadata helper, same S3/S4/checkpoints. Fixed512node paired work and cold equal-time caller results are separate; no mature-engine or strength claim.')
 for case in CASES:
  c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);e=m.semantic_engine_for(c)
  states=[('root',board.initial)]+[(label,apply_action(board.initial,a,c)) for label,a in board.actions()[:16]];groups.append((case,c,board,e,states))
 try:
  for repeat in range(16):
   for case,c,board,e,states in groups:
    stopped();assert time.perf_counter()<deadline
    for label,state in states:
     pair=[]
     for candidate in ((False,True) if repeat%2==0 else (True,False)):
      install(candidate);t=time.perf_counter()
      # Batch16 to reduce one-query timer granularity without hiding outliers.
      answers=[e.has_legal_action(state.position) for _ in range(16)]
      elapsed=time.perf_counter()-t;assert len(set(answers))==1;pair.append(answers[0])
      out['primitive'].append(dict(root=case['id'],child=label,repeat=repeat,candidate=candidate,seconds=elapsed,queries=16,answer=answers[0]))
     assert pair[0]==pair[1]
  write_record(B/'installed-control.json',out);print('primitive complete',len(out['primitive']),flush=True)
  for case,c,board,e,states in groups:
   evaluator=w.weighted(c,VALUES[case['game']])
   for repetition in range(4):
    pair=[]
    for candidate in ((False,True) if repetition%2==0 else (True,False)):
     stopped();assert time.perf_counter()<deadline;install(candidate)
     s=GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses
     t=time.perf_counter();decision=AlphaBetaPlayer(c,evaluator_override=evaluator,use_native_semantic_legality=True).choose_action(s,SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
     assert s.state is board.initial;pair.append(record_value(decision));out['fixed'].append(dict(root=case['id'],repeat=repetition,candidate=candidate,wall=wall,decision=record_value(decision)))
    assert clean(pair[0])==clean(pair[1])
   write_record(B/'installed-control.json',out);print('fixed',case['id'],flush=True)
  for case,c,board,e,states in groups:
   evaluator=w.weighted(c,VALUES[case['game']])
   for seconds in (1,4):
    for repetition in range(2):
     for candidate in ((False,True) if repetition%2==0 else (True,False)):
      stopped();assert time.perf_counter()<deadline;install(candidate)
      s=GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses
      t=time.perf_counter();decision=AlphaBetaPlayer(c,evaluator_override=evaluator,use_native_semantic_legality=True).choose_action(s,SearchLimits(max_depth=4,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
      assert s.state is board.initial;out['time'].append(dict(root=case['id'],budget=seconds,repeat=repetition,candidate=candidate,wall=wall,decision=record_value(decision)))
   write_record(B/'installed-control.json',out);print('time',case['id'],flush=True)
 finally:install(True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(B/'installed-control.json',out)
 for case,c,board,e,states in groups:
  vals={a:sum(x['seconds'] for x in out['primitive'] if x['root']==case['id'] and x['candidate']==a) for a in (False,True)}
  fixed={a:sum(x['wall'] for x in out['fixed'] if x['root']==case['id'] and x['candidate']==a) for a in (False,True)}
  print(case['id'],'primitive ratio',vals[True]/vals[False],'fixed ratio',fixed[True]/fixed[False],flush=True)
if __name__=='__main__':run()
