"""Actual caller fallback adjacent to imported S4 reply boundaries."""
import sys,time,importlib.util
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('control',B/'installed_control.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands,GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.transition import initial_state
from generic_chess.core.terminal import terminal_result
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
def comparable(value):
 if isinstance(value,dict):return {k:comparable(v) for k,v in value.items() if 'seconds' not in k and not k.startswith('time_') and not k.startswith('native_') and not k.startswith('runtime_legal_provider')}
 if isinstance(value,list):return list(map(comparable,value))
 return value
def main():
 start=time.perf_counter();out=dict(complete=False,fuse_seconds=120,scope='Imported same Shogi two-kings/pawn-hand position at max_ply1/2/4. Core vs supported hybrid actual q4 caller,512node cap, two reverse orders. Scope routing/decision/work only, not played histories, speed or Native full-domain coverage.',rows=[])
 for cap in (1,2,4):
  board=[[None]*9 for _ in range(9)];board[0][4]=Piece(0,'K','K');board[8][4]=Piece(1,'K','K')
  c=compile_ruleset_for_execution(replace(build_builtin_ruleset('standard_shogi'),max_ply=cap,initial_position=tuple(map(tuple,board))))
  initial=initial_state(c);pos=replace(initial.position,hands=(Hands((('P',1),)),Hands()));key=repetition_identity_key(pos,c)
  state=GameState(pos,0,((key,1),),initial.terminal_status,(HistoryRecord(key,-1,'',False),));state=replace(state,terminal_status=terminal_result(state,c));e=p.w.weighted(c,p.VALUES['shogi'])
  for order in range(2):
   pair=[]
   for native in ((False,True) if order==0 else (True,False)):
    stopped();assert time.perf_counter()-start<120
    session=SimpleNamespace(state=state,compiled=c,_search_witnesses=(pos,));t=time.perf_counter()
    d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=native,use_disk_cache=False).choose_action(session,SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    assert session.state is state;v=record_value(d);pair.append(comparable(v));out['rows'].append(dict(max_ply=cap,order=order,native=native,wall=time.perf_counter()-t,decision=v))
   assert pair[0]==pair[1],(cap,order,pair)
  write_record(B/'boundary-caller.json',out);print(cap,'pass',flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(B/'boundary-caller.json',out)
if __name__=='__main__':main()
