"""Compile constructor time/owned bytes: fixed borrowed IR, old/current setup."""
import sys,time,subprocess,statistics
from pathlib import Path
sys.path[:0]=[str(Path.cwd())]
import generic_chess.rules.ir as m
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path(__file__).parent
source=subprocess.check_output(['git','show','9146a2e5b06e3349a588a8dd1abc05cab5d0a78c:generic_chess/rules/ir.py'],text=True)
(B/'baseline-ir.py').write_text(source,encoding='utf-8',newline='\n')
ns=dict(vars(m));exec(compile(source,'pinned-old-ir','exec'),ns)
baseline=ns['CompiledSemanticRuleset'];rows=[];start=time.perf_counter()
for name in ('western_chess','standard_shogi'):
 compiled=compile_ruleset_for_execution(build_builtin_ruleset(name));kind=compiled._pattern_drop_kinds
 owned=sys.getsizeof(kind)+sum(sys.getsizeof(k) for k in kind)
 # Shared bool singletons and borrowed IR/pattern/geometry objects excluded.
 for repeat in range(12):
  for new in ((False,True) if repeat%2==0 else (True,False)):
   stopped();assert time.perf_counter()-start<90;cls=m.CompiledSemanticRuleset if new else baseline
   t=time.perf_counter()
   values=[cls(ir=compiled.ir,_legacy_compiled=compiled._legacy_compiled,support=compiled.support) for _ in range(4)]
   elapsed=time.perf_counter()-t
   rows.append(dict(game=name,repeat=repeat,candidate=new,batch=4,seconds=elapsed,metadata_owned_bytes=owned,patterns=len(kind)))
   del values
out=dict(complete=True,scope='Constructor-only paired timing on fixed existing IR, not total compiler speed. Owned mapping plus integer keys excludes shared booleans and all borrowed IR.12 opposite-order pairs,4 constructors per arm; no cache or semantic change.',seconds=time.perf_counter()-start,rows=rows)
write_record(B/'setup-cost.json',out)
for name in ('western_chess','standard_shogi'):
 v={new:[r['seconds'] for r in rows if r['game']==name and r['candidate']==new] for new in (False,True)}
 print(name,statistics.median(v[True])/statistics.median(v[False]),[(r['patterns'],r['metadata_owned_bytes']) for r in rows if r['game']==name][:1])
