"""Actual execution multiplicity; no result/cache/order changes."""
import sys,time,importlib.util
from pathlib import Path
from collections import Counter
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core import search_runtime as rtmod
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
spec=importlib.util.spec_from_file_location('control',Path(__file__).parent/'installed_control.py');cm=importlib.util.module_from_spec(spec);spec.loader.exec_module(cm)
B=Path(__file__).parent
old={n:getattr(SemanticEngine,n) for n in ('_iter_candidates','_trial_child_if_s3_legal','_transition','has_legal_action','in_check')}
ng=sm.negamax;q=sm._quiescence_runtime;noisy=sm.noisy_child;gen=sm._runtime_legal_actions;term=rtmod.terminal_from_search_runtime
iteration=0;qlevel=0;trialdepth=0;availability=0;counts=Counter();seen_trials=set();seen_formal=set();parents={}
def inc(kind):counts[(iteration,bool(qlevel),kind)]+=1
def candidates(self,*a,**kw):
 for value in old['_iter_candidates'](self,*a,**kw):inc('S0_S1_eligible_yield');yield value
def trial(self,*a,**kw):
 global trialdepth
 inc('Python_S3_trial');trialdepth+=1
 try:return old['_trial_child_if_s3_legal'](self,*a,**kw)
 finally:trialdepth-=1
def transition(self,parent,action,binding,*a,**kw):
 parents[id(parent)]=parent;key=(id(parent),action)
 if trialdepth:
  inc('availability_transition' if availability else 'frontier_transition');seen_trials.add(key)
 else:
  inc('formal_transition');inc('formal_with_prior_Python_trial' if key in seen_trials else 'formal_without_prior_Python_trial')
  if key in seen_formal:inc('repeated_formal_transition_same_Position_action')
  seen_formal.add(key)
 return old['_transition'](self,parent,action,binding,*a,**kw)
def has(self,*a,**kw):
 global availability
 inc('availability_query');availability+=1
 try:return old['has_legal_action'](self,*a,**kw)
 finally:availability-=1
def check(self,*a,**kw):inc('Core_check_query');return old['in_check'](self,*a,**kw)
def negamax(*a,**kw):
 global iteration
 prev=iteration
 if a[4]==0:iteration=a[1]
 try:return ng(*a,**kw)
 finally:iteration=prev
def quiescence(*a,**kw):
 global qlevel
 if qlevel:inc('recursive_q_child_consumed')
 inc('q_entry');qlevel+=1
 try:return q(*a,**kw)
 finally:qlevel-=1
def classify(*a,**kw):
 result=noisy(*a,**kw);inc('q_classified_included' if result else 'q_classified_excluded');return result
def generated(*a,**kw):
 inc('search_frontier_request');actions=gen(*a,**kw);counts[(iteration,bool(qlevel),'accepted_frontier_actions')]+=len(actions);return actions
def terminal(*a,**kw):inc('terminal_adjudication');return term(*a,**kw)
def install(active):
 for n,fn in zip(old,(candidates,trial,transition,has,check)):setattr(SemanticEngine,n,fn if active else old[n])
 sm.negamax=negamax if active else ng;sm._quiescence_runtime=quiescence if active else q;sm.noisy_child=classify if active else noisy;sm._runtime_legal_actions=generated if active else gen;rtmod.terminal_from_search_runtime=terminal if active else term
def run():
 global counts,seen_trials,seen_formal,parents,iteration,qlevel,trialdepth,availability
 start=time.perf_counter();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));board=CoreBoard(CASES[0],c);e=cm.w.weighted(c,VALUES['chess']);rows=[]
 for native in (False,True):
  for order in range(2):
   pair=[]
   for measured in ((False,True) if order==0 else (True,False)):
    stopped();assert time.perf_counter()-start<180
    counts=Counter();seen_trials=set();seen_formal=set();parents={};iteration=qlevel=trialdepth=availability=0
    s=GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses;install(measured)
    try:
     t=time.perf_counter();d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=native).choose_action(s,SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    finally:install(False)
    assert s.state is board.initial;decision=record_value(d);pair.append(cm.clean(decision))
    rs=[dict(iteration=i,qphase=q,kind=k,count=v,completed_iteration=(0<i<=d.completed_depth)) for (i,q,k),v in sorted(counts.items())]
    rows.append(dict(native_requested=native,order=order,measured=measured,wall=wall,decision=decision,counts=rs,retained_parent_positions=len(parents)))
   assert pair[0]==pair[1]
 out=dict(complete=True,seconds=time.perf_counter()-start,scope='Existing Chess-middle weighted q4 caller512node. S0_S1 eligible yields are not raw geometries; Python_S3 counts exclude opaque C trials. Same retained Position object/action identifies transition recurrence, not full search/history identity. Counts are explanatory, not speed measurements; fixed-work result/nontiming counters agree.',rows=rows)
 write_record(B/'q-execution-counts.json',out)
 for r in rows:
  if r['measured']:
   print('native',r['native_requested'],'order',r['order'],'completed',r['decision']['completed_depth'],'counts',r['counts'],flush=True)
if __name__=='__main__':run()
