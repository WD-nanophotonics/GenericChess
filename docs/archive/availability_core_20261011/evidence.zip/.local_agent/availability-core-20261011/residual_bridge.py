"""Same minimal AB: residual backend cost after private token feasibility."""
import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('probe',B/'typed_token_probe.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
from scripts.search_backend_comparison import minimal_ab,audit_pair
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.research_record import write_record,record_value
from scripts.reserve_refresh_diagnostic import stopped
def main():
 start=time.perf_counter();out=dict(complete=False,whole_batch_fuse_seconds=240,scope='Same minimal lexical alpha-beta D2, same weighted evaluator and eight old roots. Core/hybrid with and without private2048typed memo; specialized matching evaluator adapter includes conversion. Separate full public state/evaluator/terminal/child audit and trace validation; no q/Elo or generic-domain specialized claim.',rows=[],audits=[])
 arms=('core','core-memo','hybrid','hybrid-memo','specialized')
 for case in p.CASES:
  stopped();assert time.perf_counter()-start<240;c=p.compile_ruleset_for_execution(p.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));e=p.cm.w.weighted(c,p.VALUES[case['game']]);factory=p.cm.w.WeightedChess if case['game']=='chess' else p.cm.w.WeightedShogi
  provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None
  left=p.CoreBoard(case,c);left.material=e;right=factory(case,e)
  out['audits'].append(dict(root=case['id'],states=audit_pair(left,right,1)))
  for order in range(2):
   results=[]
   for arm in (arms if order==0 else tuple(reversed(arms))):
    stopped();assert time.perf_counter()-start<240;p.cached.cache_clear();p.install(arm.endswith('-memo'));t=time.perf_counter()
    try:
     if arm=='specialized':board=factory(case,e)
     else:board=p.CoreBoard(case,c,provider if arm.startswith('hybrid') else None);board.material=e
     prepared=time.perf_counter();r=minimal_ab(board,2,seconds=10,node_limit=100000,trace=False)
     assert r['reason']=='completed_depth';r.update(root=case['id'],arm=arm,order=order,setup_seconds=prepared-t,cache_info=p.cached.cache_info()._asdict());out['rows'].append(r);results.append(r)
    finally:p.install(False)
   for r in results[1:]:
    for f in ('move','score','completed_depth','work'):assert r[f]==results[0][f],(case['id'],f)
  # Trace check separately; never included in ordinary fixed-work times.
  left=p.CoreBoard(case,c,provider);left.material=e;p.cached.cache_clear();p.install(True)
  try:a=minimal_ab(left,2,seconds=10,node_limit=100000,trace=True)
  finally:p.install(False)
  b=minimal_ab(factory(case,e),2,seconds=10,node_limit=100000,trace=True);assert a['trace_sha256']==b['trace_sha256'];assert a['work']==b['work']
  out['audits'][-1]['trace_sha256']=a['trace_sha256'];write_record(B/'residual-bridge.json',out);print(case['id'],'complete',flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(B/'residual-bridge.json',out)
 for case in p.CASES:
  sums={arm:sum(r['wall_seconds'] for r in out['rows'] if r['root']==case['id'] and r['arm']==arm) for arm in arms}
  print(case['id'],{a:round(v/sums['specialized'],3) for a,v in sums.items()},flush=True)
if __name__=='__main__':main()
