"""Explicit Agent evidence allowlist; no Slack/account/user input publication."""
from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,re
B=Path('.local_agent/availability-core-20261011');root=Path.cwd()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
tests=[]
for name in ('active-tests','active-tests-clean','active-tests-final'):
 xml=ET.parse(B/(name+'.xml')).getroot();suite=xml.find('testsuite') if xml.tag=='testsuites' else xml
 tests.append(dict(stage=name,tests=int(suite.attrib['tests']),errors=int(suite.attrib['errors']),failures=int(suite.attrib['failures']),skipped=int(suite.attrib['skipped']),seconds=float(suite.attrib['time']),raw_xml_sha256=sha((B/(name+'.xml')).read_bytes()),result=json.loads((B/(name+'-result.json')).read_text()),raw_excluded=True))
save(B/'test-summary.json',dict(stages=tests,default_temp_failure='101setup PermissionError WinError5 scanning existing account tmp directory; no assertion failure or ACL change; project basetemp rerun succeeds. Raw account-bearing logs/XML excluded.'))
save(B/'failure-provenance.json',dict(failures=[
 'Initial profile.py shadowed stdlib cProfile dependency; renamed before profile measurement.',
 'First unfamiliar fixture import lacked tests/product path; no calls completed.',
 'Second unfamiliar run completed generated cells then plain CompiledSemanticRuleset lacked legacy piece_types profile; existing read-only SearchSemanticCompiled adapter used for only remaining mixed cells.',
 'Instrumentation guessed nonexistent runtime aliases and module _entry_digest; corrected to SearchPathRuntime and RuntimeCountsSnapshot method before recorded probes.',
 'Full compiled pickle attempt failed on existing mappingproxy; final serialization test covers new private table only, no full compiled pickle contract.',
 'v2 constructor bytes initially included borrowed tuple keys; source/output preserved before correcting owned-map bytes.',
 'Final boundary assay unchanged product; no source or failed empirical cells overwritten.', 'Archive scanner first matched its own literal account marker; replaced with generic email/path scan. Then historical integration source failed path scan and was excluded; isolated class-only recovery replay supplied.', 'Mainline rewrite initially used Windows default decoding; outgoing diff detected mojibake and was repaired from original Git UTF8 before publication.'
 ],limits='No alleged runtime/AI failure inferred from import/assay assumptions. Initial incomplete generated/mixed outputs and source retained separately.'))
names='completion_work_curve.py completion-work-curve.json completed_q_support.py completed-q-support.json signature_cost.py signature-cost.json semantic_profile_adapter.py unfamiliar_isolated_control.py unfamiliar-isolated-control.json profile-adapter-provenance.json delivery-validation.json baseline-ir.py baseline-semantic-executor.py first_action_profile.py installed_control.py kind_dispatch.py mixed_remaining.py push_representation.py q_cost_split.py q_execution_counts.py reflected_boundary.py residual_bridge.py setup_cost.py setup_cost_borrowed_key_bytes.py token_semantics.py token_time.py typed_token_probe.py unfamiliar_control.py unfamiliar_failed_source.py boundary_caller.py ir-dispatch-v1.py semantic-executor-dispatch-v1.py test-dispatch-v1.py installed-control-v1.json installed-control.json kind-dispatch-summary.json kind-dispatch.json mixed-remaining-v1.json mixed-remaining.json profile.json push-representation.json q-cost-split.json q-execution-counts.json reflected-boundary.json residual-bridge.json setup-cost-v1.json setup-cost-v2-before-byte-correction.json setup-cost.json summary.json token-semantics.json token-time.json typed-token-probe.json unfamiliar-control.json unfamiliar-generated-before-mixed-adapter.json unfamiliar-v1-partial.json boundary-caller.json test-summary.json failure-provenance.json package.py'.split()
inputs=[B/n for n in names]+[p for p in Path('generic_chess').rglob('*.py') if p.name!='alphasho_bridge.py']+list(Path('generic_chess/_native').glob('*.c'))+list(Path('generic_chess/_native').glob('*.h'))
inputs += [Path(p) for p in ['.local_agent/weighted-backend-20261011/bridge.py','scripts/search_backend_comparison.py','scripts/research_record.py','scripts/reserve_refresh_diagnostic.py','scripts/chess_development.py','scripts/audit_lichess_complete_children.py','tests/rule_semantics_ir_fixtures.py','tests/ai_fixtures.py','tests/conftest.py','tests/product/test_pattern_drop_dispatch.py','tests/product/test_actor_capture_dispatch.py','tests/product/test_runtime_aux_identity.py','tests/product/test_semantic_trial_checkpoint.py','tests/product/test_recombined_semantic_lifecycle.py','tests/product/test_native_legality_terminal_boundary.py','tests/product/test_f24c_mixed_mechanic_certification.py','tests/product/test_f24c_mixed_mechanic_certification_r1.py','docs/research/AVAILABILITY_AND_Q_EXECUTION.md','pyproject.toml']]
pins={p.as_posix():sha(p.read_bytes()) for p in inputs if p.as_posix() in ('generic_chess/rules/ir.py','generic_chess/core/semantic_executor.py','generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/player.py','tests/product/test_pattern_drop_dispatch.py')}
native={p.name:sha(p.read_bytes()) for p in Path('generic_chess').glob('_native_core*.pyd')}
save(B/'source-pins.json',dict(final=pins,installed_native=native,rebuild=False,original_base='9146a2e5b06e3349a588a8dd1abc05cab5d0a78c',stages='v1objectID and finalgeometrytuple outputs are separate; typed token prototype not installed product; Native binary unchanged.'))
inputs.append(B/'source-pins.json');dest=Path('docs/archive/availability_core_20261011/evidence.zip');dest.parent.mkdir(parents=True,exist_ok=True);rows=[]
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(inputs),key=lambda p:p.as_posix()):
  raw=p.read_bytes()
  assert not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',raw),p
  assert bytes([67,58,92])+b'Users'+bytes([92]) not in raw,p
  name=p.as_posix();z.writestr(name,raw);rows.append(dict(member=name,bytes=len(raw),sha256=sha(raw)))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for r in rows:assert sha(z.read(r['member']))==r['sha256']
v=dict(schema=1,session_id='d6b54e82-f110-4809-85fe-6521acaf7343',base_sha='9146a2e5b06e3349a588a8dd1abc05cab5d0a78c',science_complete=False,ui_branch_frozen_sha='99c97bb87474c44af94c76571f326ef8a41eb898',scope='Agent-produced code/results and prior published source closure; explicit allowlist excludes raw Slack/account/outbound/history, user/private data, credentials and account-bearing test logs/XML.',archive=dict(path=dest.as_posix(),bytes=dest.stat().st_size,uncompressed_bytes=sum(r['bytes'] for r in rows),members=len(rows),sha256=sha(dest.read_bytes())),source_pins=pins,tests=tests,members=rows)
save(Path('docs/research/data/availability_core_20261011.json'),v);save(B/'archive-index.json',v);print(v['archive'])
