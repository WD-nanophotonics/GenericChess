"""Isolated read-only class snapshot; no historical benchmark integrations."""
from generic_chess.rules.ir import CompiledSemanticRuleset

class SearchSemanticCompiled(CompiledSemanticRuleset):
    """Benchmark adapter exposing legacy metadata to the current search.

    The semantic runtime remains the executable authority (the object is a
    real ``CompiledSemanticRuleset``); the delegated fields are read-only
    geometry metadata that the existing generic search still expects.
    """

    __slots__ = ()

    def __getattr__(self, name: str):
        try:
            return getattr(self._legacy_compiled, name)
        except AttributeError:
            raise AttributeError(name) from None

    @property
    def semantic(self):
        return self
