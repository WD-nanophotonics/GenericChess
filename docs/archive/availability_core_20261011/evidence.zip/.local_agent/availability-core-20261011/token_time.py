"""Predeclared old-root equal-time token probe, no tuning or new games."""
import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('probe',B/'typed_token_probe.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
def main():
 start=time.perf_counter();rows=[]
 for case in p.CASES:
  c=p.compile_ruleset_for_execution(p.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=p.CoreBoard(case,c);e=p.cm.w.weighted(c,p.VALUES[case['game']])
  for seconds in (1,4):
   for repeat in range(2):
    for active in ((False,True) if repeat==0 else (True,False)):
     stopped();assert time.perf_counter()-start<300;p.cached.cache_clear();p.install(active)
     s=p.GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses
     try:
      t=time.perf_counter();d=p.AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,p.SearchLimits(max_depth=4,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
     finally:p.install(False)
     assert s.state is board.initial
     rows.append(dict(root=case['id'],budget=seconds,repeat=repeat,candidate=active,wall=wall,decision=record_value(d),cache_info=p.cached.cache_info()._asdict()))
   write_record(B/'token-time.json',dict(complete=False,rows=rows));print(case['id'],seconds,flush=True)
 out=dict(complete=True,seconds=time.perf_counter()-start,whole_batch_fuse_seconds=300,scope='Eight existing roots, two opposite-order pairs at1/4seconds; same weighted evaluator/hybrid legality/q4/hard8 and per-call cold2048token cache. Time work counts may differ, no fixed-tree speed claim. Action/depth changes are not independent gains. No caps altered, old prototypes retain failures.',rows=rows)
 write_record(B/'token-time.json',out)
if __name__=='__main__':main()
