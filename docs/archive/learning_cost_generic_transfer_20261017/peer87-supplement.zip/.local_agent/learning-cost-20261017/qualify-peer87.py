from pathlib import Path
import subprocess,sys,os,json,time
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';W=D/'peer87/exact';site=R/'.venv/Lib/site-packages';sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
write_json(D/'peer87/qualification-plan.json',dict(question='Do fixed87 source/terminal guard and the actual closed record/update evidence support choosing plain training over more q expansion?',scope='Published copy only:32tests and closed data audits, no train/evaluate/solver producer; independent PRIMARY forward/tally next.',forecast_seconds=45,cap_seconds=180,source='0d9cba18252b7669c4dcf68f228dfd680f296d8e'))
(W/'pytest.ini').write_bytes(b'[pytest]\naddopts=\n')
targets=['results/dev_aux/task2492/test_learning.py','results/dev_aux/task2492/test_episode.py','results/dev_aux/task2501/test_search.py','results/dev_aux/task2504/test_bounded.py','results/dev_aux/task2511/test_generic.py']
code="import sys,pathlib;sys.path[:0]=["+repr(str(W))+","+repr(str(site))+"];import results.dev_aux.task2504.search as s;assert pathlib.Path(s.__file__).resolve().is_relative_to(pathlib.Path.cwd());import pytest;assert pytest.main(['-q','--import-mode=importlib','--confcutdir=.','-c','pytest.ini','--junitxml=primary-tests.xml',"+','.join(repr(t)for t in targets)+"])==0;from results.dev_aux.task2508.training_audit import run;run();from results.dev_aux.task2508.evaluation_audit import run as e;e(2507);e(2510);from results.dev_aux.task2508.credit_diagnostics import run as d;d();from results.dev_aux.task2508.behavior_audit import run as b;b()"
env=dict(os.environ);env['PYTHONPATH']='';env['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';begin=time.monotonic()
with(D/'peer87/qualification.log').open('w',encoding='utf8')as f:
 p=subprocess.run([sys.executable,'-S','-X','utf8','-c',code],cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert p.returncode==0,(p.returncode,'inspect qualification.log')
import zipfile
with zipfile.ZipFile(D/'peer87/DELTA_REPRO_20261017_87.zip')as z:
 for n in('training-audit.json','evaluation-audit.json','curve-evaluation-audit.json','credit-diagnostics.json','behavior-audit.json'):
  assert json.loads(z.read('results/dev_aux/task2508/'+n))==json.loads((W/'results/dev_aux/task2508'/n).read_bytes()),n
a=json.loads((W/'results/dev_aux/task2508/training-audit.json').read_bytes());b=json.loads((W/'results/dev_aux/task2508/evaluation-audit.json').read_bytes());c=json.loads((W/'results/dev_aux/task2508/curve-evaluation-audit.json').read_bytes())
write_json(D/'peer87/qualification.json',dict(source='0d9cba18252b7669c4dcf68f228dfd680f296d8e',status='PASS_FIXED_SOURCE_32_TESTS_CLOSED_AUDITS',seconds=time.monotonic()-begin,tests=32,training_episodes=a['counts']['episodes'],validation_games=b['games']+c['games'],legal_plies=a['counts']['legal_prefix_moves']+a['counts']['legal_training_moves']+b['legal_plies']+c['legal_plies'],scope='PRIMARY executes published owner tests and forward/game auditors on exact source. Same-library closed evidence replay, not independent fresh training, authoring these auditors or full internal-search verification.'))
print('QUALIFICATION_PASS',round(time.monotonic()-begin,2),flush=True)

