from pathlib import Path
import json,sys,math,time,collections
import numpy as np
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';W=D/'peer87/exact/results/dev_aux';sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
write_json(D/'peer87/primary-analysis-plan.json',dict(question='Does independent receipt math/tally support the reported q2-minus-plain contrast while preserving the shared baseline and censoring?',scope='Published frozen317episodes/48017query receipts and931recorded validation games only. No search/training or reward selection.',decision='If arithmetic differs, correct interpretation before adoption. If it agrees, choose plain as cheap current comparison and inspect owner88 method contrast; do not expand q or claim universal ratios.',forecast_seconds=5,cap_seconds=60))
begin=time.monotonic()
def lines(p):return [json.loads(s)for s in p.read_text(encoding='utf8').splitlines()]
eps=lines(W/'task2506/episodes.jsonl');ds=lines(W/'task2506/decisions.jsonl');plan=json.loads((W/'task2506/plan.json').read_bytes());by=collections.defaultdict(list)
for d in ds:by[d['seed'],d['quiet'],d['game']].append(d)
maxerr=0.;nonzero=terms=final_zero=0;failed=0;failednodes=0;per=[]
for e in eps:
 rr=by[e['seed'],e['quiet'],e['game']];complete=[r for r in rr if r['complete']];pred=np.array([r['prediction']for r in complete]);grad=np.array([r['gradient']for r in complete]);errors=np.diff(pred)
 if e['outcome']is not None and len(pred):errors=np.r_[errors,e['outcome']-pred[-1]];final_zero+=errors[-1]==0
 # Literal forward sum through convolution, independent from vector eligibility and owner's scalar recurrence.
 n=len(pred);pad=np.r_[errors,np.zeros(n-len(errors))];future=np.convolve(pad[::-1],plan['lambda']**np.arange(n))[:n][::-1]if n else np.array([])
 credit=np.array([math.fsum(float(g*t)for g,t in zip(grad[:,j],future))for j in range(5)])if n else np.zeros(5)
 expected=np.array(e['initial_weights'])+plan['eta']*credit;expected[0]=1.;err=max(abs(expected-np.array(e['weights'])));maxerr=max(maxerr,float(err));assert err<2e-12
 for r in complete:
  if r['pv_terminal']:assert not any(r['gradient']) and r['pv_phi']is None
  else:
   raw=sum(x*w for x,w in zip(r['pv_phi'],e['initial_weights']));assert raw==r['value'];p=math.tanh(raw/10);assert p==r['prediction'];g=[0 if j==0 else x*(1-p*p)/10 for j,x in enumerate(r['pv_phi'])];assert max(abs(a-b)for a,b in zip(g,r['gradient']))<1e-14
 for r in rr:
  if not r['complete']:failed+=1;failednodes+=r['nodes'];assert all(r[k]is None for k in('action','value','prediction','gradient','pv_phi'))
 terms+=len(errors);nonzero+=any(a!=b for a,b in zip(e['initial_weights'],e['weights']))
results=[]
for task in(2507,2510):
 P=W/f'task{task}';p=json.loads((P/'plan.json').read_bytes());r=lines(P/'games.jsonl');keys={(x['seed'],x['family'],x['color'],x['treatment']):x for x in r};assert len(keys)==len(r);seeds=p['seeds'];families=p['families'];treatments=('initial','plain_trained','q2_trained')if task==2507 else ('initial',*[s+'_'+str(n)for n in p['node_checkpoints']for s in('plain','q2')])
 def reward(s,f,c,t):
  x=keys.get((s,f,c,t),{}).get('reward');return(-1.,1.)if x is None else(float(x),float(x))
 def difference(a,b,ss):
  pairs=[]
  for s in ss:
   for f in families:
    for c in(0,1):
     x=reward(s,f,c,a);y=reward(s,f,c,b);pairs.append((x[0]-y[1],x[1]-y[0]))
  return[sum(x[i]for x in pairs)/len(pairs)for i in(0,1)]
 cs=[('plain_trained','initial'),('q2_trained','initial'),('q2_trained','plain_trained')]if task==2507 else[(a,b)for n in p['node_checkpoints']for a,b in((f'plain_{n}','initial'),(f'q2_{n}','initial'),(f'q2_{n}',f'plain_{n}'))]
 comparisons=[dict(candidate=a,baseline=b,seed=s,bounds=difference(a,b,seeds if s is None else[s]))for a,b in cs for s in seeds+[None]]
 tallies=[dict(seed=s,treatment=t,counts=dict(collections.Counter('U'if x['reward']is None else'W'if x['reward']==1 else'L'if x['reward']==-1 else'D'for x in r if x['seed']==s and x['treatment']==t)))for s in seeds for t in treatments]
 results.append(dict(task=task,physical_games=len(r),planned=len(seeds)*len(families)*2*len(treatments),missing=len(seeds)*len(families)*2*len(treatments)-len(r),unknown_actual_slots=sum(x['reward']is None for x in r),physical_initial_baselines=sum(x['treatment']=='initial'for x in r),nodes=sum(x['nodes']for x in r),tallies=tallies,comparisons=comparisons,unknown_endings=dict(collections.Counter(x['ending']for x in r if x['reward']is None))))
def bounds(task,a,b):return next(c['bounds']for panel in results if panel['task']==task for c in panel['comparisons']if c['candidate']==a and c['baseline']==b and c['seed']is None)
assert bounds(2507,'plain_trained','initial')==[.5,.5];assert bounds(2507,'q2_trained','initial')==[.3046875,.3046875];assert bounds(2507,'q2_trained','plain_trained')==[-.1953125,-.1953125]
p=bounds(2510,'plain_1000000','initial');q=bounds(2510,'q2_1000000','initial');direct=bounds(2510,'q2_1000000','plain_1000000');naive=[q[0]-p[1],q[1]-p[0]]
assert direct==[-.3125,-.0625]
train=json.loads((W/'task2506/result.json').read_bytes())
arms=[dict(seed=a['seed'],quiet=a['quiet'],nodes=a['nodes'],seconds=a['seconds'],games=a['games'],outcomes=a['outcomes'])for a in train['arms']]
result=dict(source='0d9cba18252b7669c4dcf68f228dfd680f296d8e',status='PASS_PRIMARY_FORWARD_CONVOLUTION_AND_TALLY',episodes=len(eps),query_receipts=len(ds),TD_terms=terms,actual_zero_final_residuals=final_zero,nonzero_episode_updates=nonzero,maximum_forward_update_error=maxerr,failed_training_queries=failed,failed_training_query_nodes=failednodes,training_arms=arms,panels=results,shared_baseline_example=dict(plain_gain=p,q2_gain=q,incorrect_loss_of_shared_baseline_correlation_interval=naive,correct_direct_q2_minus_plain=direct,explanation='Pair direct trained rewards: the same initial baseline cancels even when that baseline is missing/UNKNOWN. Subtracting marginal bound intervals needlessly loses this dependency.'),seconds=time.monotonic()-begin,scope='PRIMARY-authored independent receipt arithmetic/tally, not fresh learning/search or statistical population proof. Owner32tests/audits run separately. No seed/checkpoint selection or action continuation.')
write_json(D/'peer87/primary-analysis.json',result);print(json.dumps({k:v for k,v in result.items()if k not in('panels','training_arms')},indent=2))

