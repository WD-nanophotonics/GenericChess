from pathlib import Path
import sys,json,collections,time,math
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';W=D/'peer87/exact';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
import chess
from results.dev_aux.task2492.adapters import ChessEnv
from results.dev_aux.task2492.learning import Model
from results.dev_aux.task2504.search import TrainingSearch
assert Path(sys.modules[TrainingSearch.__module__].__file__).resolve().is_relative_to(W.resolve())
def lines(p):return[json.loads(x)for x in p.read_text(encoding='utf8').splitlines()]
base=W/'results/dev_aux/task2506';ds=lines(base/'decisions.jsonl');ep={(e['seed'],e['quiet'],e['game']):e for e in lines(base/'episodes.jsonl')};by=collections.defaultdict(list)
for r in ds:by[r['seed'],r['quiet'],r['game']].append(r)
keys=[];selection=[]
for arm in ((s,q)for s in(1977,8173,27182,31415)for q in(False,True)):
 rr=[r for r in ds if(r['seed'],r['quiet'])==arm and r['complete']]
 for label,predicate in [('first',lambda r:True),('terminalPV',lambda r:r['pv_terminal']),('nonzeroGradient',lambda r:not r['pv_terminal']and any(r['gradient'])),('qcut',lambda r:arm[1]and r['stats']['q_truncated_leaf_labels']>0),('forcedBeyond2',lambda r:arm[1]and r['stats']['check_evasion_nodes']>0 and r['stats']['max_qply']>2)]:
  r=next((r for r in rr if predicate(r)),None)
  if r is None:continue
  key=(r['seed'],r['quiet'],r['game'],r['ply']);selection.append(dict(label=label,key=key))
  if key not in keys:keys.append(key)
assert len(keys)<=32
write_json(D/'peer87/selected-query-plan.json',dict(question='Do actual completed plain/q2 receipts return the saved selected PV features/actions/gradients across all eight arms, including terminal/cut/forced-evasion paths?',selection=selection,unique_queries=len(keys),selection_basis='First chronological structural receipt per arm/category, not rewards, wins or selected coefficients. Deduplicate overlap.',forecast_seconds=15,whole_cap_seconds=90,query_limits=dict(nodes=8192,seconds=5),scope='Same frozen source/search/weights and full recorded histories; no new training/games or failed-query cause inference. Not all48025searches or independent engine.'))
begin=time.monotonic();rows=[]
for seed,q,g,ply in keys:
 assert time.monotonic()-begin<90
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('user_paused')and not f.get('stopped')
 e=ep[seed,q,g];b=chess.Board(e['initial_record']['initial'])
 for u in e['initial_record']['moves']:b.push_uci(u)
 rr=by[seed,q,g]
 for r in rr[:ply]:assert r['complete'];b.push_uci(r['action'])
 old=rr[ply];assert b.fen()==old['root_fen'];before=(b.fen(),[m.uci()for m in b.move_stack]);env=ChessEnv(b);m=Model(e['initial_weights']);engine=TrainingSearch(2,quiet=q,qstack=96,q_limit=2)
 r=engine.search(env,m,nodes=8192,seconds=5,seed=seed*100000+g*1000+ply)
 assert r.complete and r.action.uci()==old['action']and r.value==old['value']and r.nodes==old['nodes'];assert (None if r.pv_phi is None else list(r.pv_phi))==old['pv_phi'];assert r.pv_terminal==old['pv_terminal']
 grad=[0.]*5 if r.pv_terminal else list(m.gradient(r.pv_phi));assert max(abs(x-y)for x,y in zip(grad,old['gradient']))<1e-14;assert engine.last_stats==old['stats'];assert before==(env.board.fen(),[a.uci()for a in env.board.move_stack])
 rows.append(dict(seed=seed,quiet=q,game=g,ply=ply,action=r.action.uci(),nodes=r.nodes,value=r.value,pv_phi=r.pv_phi,pv_terminal=r.pv_terminal,gradient=grad,stats=engine.last_stats,seconds=r.seconds,full_root_restored=True))
write_json(D/'peer87/selected-query-result.json',dict(status='PASS_SAME_SOURCE_SELECTED_ACTUAL_RECEIPTS',rows=rows,unique_queries=len(rows),seconds=time.monotonic()-begin,scope='Structural convenience sample, same frozen source/parameters/fullhistory. Complete receipt actions/value/phi/terminal/gradients/nodes/stats equal; not new training, all-search replay, population sample or matched-effective-wall failure diagnosis.'))
print('SELECTED_RECEIPTS',len(rows),round(time.monotonic()-begin,3))

