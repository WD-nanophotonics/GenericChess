from pathlib import Path
import json,hashlib,sys,collections
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';O=D/'peer87/full-completed-receipt-replay';sys.path.insert(0,str(R));from tools.local_agent.common import write_json
actual=[json.loads(x)for x in(O/'receipts.jsonl').read_text(encoding='utf8').splitlines()];original=[json.loads(x)for x in(D/'peer87/exact/results/dev_aux/task2506/decisions.jsonl').read_text(encoding='utf8').splitlines()];expected=[r for r in original if r['complete']];assert len(actual)==len(expected)==48017
digest=hashlib.sha256();nodes=0;maxs=0;arms=collections.Counter()
for a,b in zip(actual,expected):
 assert a['complete'];assert all(a[k]==b[k]for k in('seed','quiet','game','ply','action','value','pv_phi','pv_terminal','nodes'));nodes+=a['nodes'];maxs=max(maxs,a['seconds']);arms[str((a['seed'],a['quiet']))]+=1
 digest.update(json.dumps(dict(seed=a['seed'],quiet=a['quiet'],game=a['game'],ply=a['ply'],action=a['action'],value=a['value'],phi=a['pv_phi'],terminal=a['pv_terminal'],nodes=a['nodes']),sort_keys=True,separators=(',',':')).encode())
result=json.loads((O/'result.json').read_bytes());assert result['failure']is None and nodes==result['reexecuted_nodes']==7998701;assert digest.hexdigest()==result['matched_fields_sha256'];assert sum(r['nodes']for r in original if not r['complete'])==1299
write_json(O/'stream-audit.json',dict(status='PASS_ALL_ACTUAL_ROWS_AND_HASH',rows=len(actual),matched_sha256=digest.hexdigest(),nodes=nodes,max_actual_query_seconds=maxs,receipt_stream_sha256=hashlib.sha256((O/'receipts.jsonl').read_bytes()).hexdigest(),original_failed_nodes_not_replayed=1299,scope='Independent read of actual stream vs immutable original completed receipt fields, no search/training or inference of failed-query time causes. Per-call leafgradient/fullroot assertions were executed by original producer; this read verifies emitted fields/hash.'))
print('STREAM',len(actual),nodes,round(maxs,4))

