from pathlib import Path
import sys,json,time,collections,hashlib,traceback
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';W=D/'peer87/exact';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
import chess
from results.dev_aux.task2492.adapters import ChessEnv
from results.dev_aux.task2492.learning import Model
from results.dev_aux.task2504.search import TrainingSearch
assert Path(sys.modules[TrainingSearch.__module__].__file__).resolve().is_relative_to(W.resolve())
O=D/'peer87/full-completed-receipt-replay';O.mkdir(exist_ok=False)
plan=dict(question='Does every completed frozen87 TRAIN query reproduce its actual returned leaf/target/action/node count, beyond the selected18checks?',changed_premise='The current Core qleaf counterexample has opposite material sensitivity; verify that the now-published successful AUX learner consistently uses its own returned leaves across the complete recorded TRAIN population, including rare q/evasion/history paths. A mismatch changes adoption/confidence and is reported, not relabeled.',scope='Read fixed source/weights/complete historical trajectories. Reexecute search only; no TD updates applied, no new training/games/reward selection, no AUX checkout. Same-engine receipt reproduction, not independent rule authority or proof all generated games.',forecast_seconds=1150,whole_cap_seconds=1500,queries='All48017completed, skip original8failed queries because original remaining-pool/effective-wall conditions differ.',query_nodes=8192,query_seconds=5,cheaper_alternative='18structural samples and32tests already pass. Full replay is one bounded qualification of actual successful learner, not a standing development gate or reason to repeat unrelated Core studies.',single_logical_run=True)
write_json(O/'plan.json',plan)
def lines(p):return[json.loads(x)for x in p.read_text(encoding='utf8').splitlines()]
base=W/'results/dev_aux/task2506';ds=lines(base/'decisions.jsonl');eps=lines(base/'episodes.jsonl');by=collections.defaultdict(list)
for r in ds:by[r['seed'],r['quiet'],r['game']].append(r)
begin=time.monotonic();lastflag=0.;rows=[];done=0;used=0;failure=None;arms=collections.Counter();digest=hashlib.sha256();limit_reason=None
def poll(force=False):
 global lastflag
 now=time.monotonic()
 if now-begin>=1500:raise RuntimeError('PRIMARY_WHOLE_CAP')
 if force or now-lastflag>=.5:
  for n in('rollout','advisor','slack'):
   f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
   if f.get('stopped')or f.get('user_paused'):raise RuntimeError('PRIMARY_USER_STOP')
  lastflag=now
write_json(O/'started.json',dict(session_id='2c490439-3148-43c8-9ef9-661741900cbf',planned_complete_queries=sum(r['complete']for r in ds),started_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()))
try:
 with(O/'receipts.jsonl').open('x',encoding='utf8')as out:
  for e in eps:
   b=chess.Board(e['initial_record']['initial'])
   for u in e['initial_record']['moves']:b.push_uci(u)
   m=Model(e['initial_weights']);engine=TrainingSearch(2,quiet=e['quiet'],qstack=96,q_limit=2)
   for old in by[e['seed'],e['quiet'],e['game']]:
    poll(True);assert b.fen()==old['root_fen']
    if not old['complete']:continue
    before=(b.fen(),tuple(b.move_stack));env=ChessEnv(b);effective_seconds=min(5.,1500-(time.monotonic()-begin));qbegin=time.monotonic()
    r=engine.search(env,m,nodes=8192,seconds=effective_seconds,seed=e['seed']*100000+e['game']*1000+old['ply'],cancel=poll)
    row=dict(seed=e['seed'],quiet=e['quiet'],game=e['game'],ply=old['ply'],complete=r.complete,action=None if r.action is None else r.action.uci(),nodes=r.nodes,value=r.value,pv_phi=r.pv_phi,pv_terminal=r.pv_terminal,seconds=time.monotonic()-qbegin,effective_seconds=effective_seconds,reason=r.reason)
    out.write(json.dumps(row,separators=(',',':'))+'\n');out.flush();used+=r.nodes
    assert r.complete and r.action.uci()==old['action']and r.value==old['value']and r.nodes==old['nodes'],('receipt',row,old)
    assert (None if r.pv_phi is None else list(r.pv_phi))==old['pv_phi']and r.pv_terminal==old['pv_terminal'],('leaf',row,old)
    grad=[0.]*5 if r.pv_terminal else list(m.gradient(r.pv_phi));assert max(abs(a-b)for a,b in zip(grad,old['gradient']))<1e-14
    assert engine.last_stats==old['stats'];assert before==(env.board.fen(),tuple(env.board.move_stack))
    digest.update(json.dumps(dict(seed=e['seed'],quiet=e['quiet'],game=e['game'],ply=old['ply'],action=old['action'],value=old['value'],phi=old['pv_phi'],terminal=old['pv_terminal'],nodes=old['nodes']),sort_keys=True,separators=(',',':')).encode())
    done+=1;arms[str((e['seed'],e['quiet']))]+=1;b.push(r.action)
    if done%1000==0:print('REPLAY',done,'nodes',used,'seconds',round(time.monotonic()-begin,2),flush=True)
except Exception as ex:
 failure=dict(type=type(ex).__name__,message=str(ex)[:5000],trace=traceback.format_exc());print('REPLAY_STOP',type(ex).__name__,str(ex)[:200],flush=True)
finally:
 result=dict(status='PASS_ALL_COMPLETED_FROZEN_RECEIPTS'if failure is None and done==48017 else'PARTIAL_OR_FAILED_PRESERVED',completed_queries=done,expected_completed_queries=48017,original_failed_queries_skipped=8,reexecuted_nodes=used,per_arm=dict(arms),seconds=time.monotonic()-begin,matched_fields_sha256=digest.hexdigest(),failure=failure,scope=plan['scope'])
 write_json(O/'result.json',result);print(json.dumps(result),flush=True)

