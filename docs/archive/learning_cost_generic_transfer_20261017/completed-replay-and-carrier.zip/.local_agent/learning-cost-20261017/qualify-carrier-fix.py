from pathlib import Path
import subprocess,sys,json,os,hashlib,time
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';O=D/'carrier-redgreen';O.mkdir(exist_ok=False);Q=O/'source';Q.mkdir();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
begin=time.monotonic();base='c01802cc72948d2309d4c3c072dca98c4b44887e';names=subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines()
for n in names:
 if n.startswith('generic_chess/')or n=='tests/conftest.py':
  p=Q/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',base+':'+n]))
target='tests/product/test_learning_non_scoring.py';p=Q/target;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/target).read_bytes());(Q/'pytest.ini').write_bytes(b'[pytest]\naddopts=\n')
site=R/'.venv/Lib/site-packages';env=dict(os.environ);env['PYTHONPATH']='';env['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
code="import sys,pathlib;sys.path[:0]=["+repr(str(Q))+","+repr(str(Q/'tests'))+","+repr(str(site))+"];import generic_chess.learning.trajectory as t;assert pathlib.Path(t.__file__).resolve().is_relative_to(pathlib.Path.cwd());import pytest;raise SystemExit(pytest.main(['-q','-c','pytest.ini','--confcutdir=.','-p','no:cacheprovider','"+target+"']))"
def run(label):
 p=subprocess.run([sys.executable,'-S','-X','utf8','-c',code],cwd=Q,env=env,capture_output=True,text=True,timeout=30);(O/(label+'.stdout.txt')).write_bytes(p.stdout.encode());(O/(label+'.stderr.txt')).write_bytes(p.stderr.encode());return p
red=run('before');assert red.returncode==1 and '4 failed, 3 passed' in red.stdout,red.stdout[-2000:]
patches=[]
for n in('generic_chess/learning/trajectory.py','generic_chess/learning/arena.py'):
 b=(R/n).read_bytes();(Q/n).write_bytes(b);patches.append(dict(path=n,sha256=hashlib.sha256(b).hexdigest()))
green=run('after');assert green.returncode==0 and '7 passed'in green.stdout,green.stdout
write_json(O/'result.json',dict(status='PASS_CLEAN_SOURCE_RED4FAIL_GREEN7PASS',core_base=base,before_failures=4,before_passes=3,after_passes=7,patched_sources=patches,test_sha256=hashlib.sha256((R/target).read_bytes()).hexdigest(),seconds=time.monotonic()-begin,scope='Two freshPython-S processes, explicitsite/import provenance, trackedCore source without nativebinary; actualSession/selfplaydeclaration collection/serialization/TD rejection/arena pair controls. Only engine choice stubbed, no learner/search/solver run.'))
print('CLEAN_RED_GREEN',round(time.monotonic()-begin,2))

