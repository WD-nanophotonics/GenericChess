from pathlib import Path
import json,math,sys,time,collections
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';W=D/'peer87/exact/results/dev_aux';sys.path.insert(0,str(R));from tools.local_agent.common import write_json
import chess
O=D/'root-signal-coverage';O.mkdir(exist_ok=False)
write_json(O/'plan.json',dict(question='Does RootRMS0 in the eight exposed controls generalize to all existing87TRAIN roots?',scope='Compute static-root prediction and gradient toward each saved frozen search target over all complete historical roots. No Root learner update or newsearch. This uses evolving87weights/trajectories, NOT an independent initial calibration set or88data.',decision='A nonzero whole-corpus RootRMS means the toy degeneracy is not a categorical blocker for a future Rootcontrol. No Tree/Root scale can be chosen because paired Treegradients are not recorded here.',forecast_seconds=5,cap_seconds=60))
def lines(p):return[json.loads(x)for x in p.read_text(encoding='utf8').splitlines()]
ds=lines(W/'task2506/decisions.jsonl');eps=lines(W/'task2506/episodes.jsonl');by=collections.defaultdict(list)
for r in ds:by[r['seed'],r['quiet'],r['game']].append(r)
begin=time.monotonic();groups=collections.defaultdict(lambda:dict(n=0,active_residual=0,free_input=0,nonzero_semigradient=0,squared_norm_sum=0.,residual_squared_sum=0.));total=0;term_target=0
for e in eps:
 b=chess.Board(e['initial_record']['initial'])
 for u in e['initial_record']['moves']:b.push_uci(u)
 w=e['initial_weights']
 for r in by[e['seed'],e['quiet'],e['game']]:
  if not r['complete']:continue
  assert b.fen()==r['root_fen'];phi=tuple(b.pieces_mask(t,chess.WHITE).bit_count()-b.pieces_mask(t,chess.BLACK).bit_count()for t in(1,2,3,4,5));pred=math.tanh(sum(x*y for x,y in zip(phi,w))/10);target=math.tanh(r['value']/10);error=target-pred;grad=[0. if j==0 else error*x*(1-pred*pred)/10 for j,x in enumerate(phi)];norm2=math.fsum(x*x for x in grad);quarter=min(4,1+(r['total_nodes']-1)//250000)
  for key in((e['seed'],e['quiet'],'all'),(e['seed'],e['quiet'],quarter)):
   g=groups[key];g['n']+=1;g['active_residual']+=error!=0;g['free_input']+=any(phi[1:]);g['nonzero_semigradient']+=any(grad);g['squared_norm_sum']+=norm2;g['residual_squared_sum']+=error*error
  total+=1;term_target+=r['pv_terminal'];b.push_uci(r['action'])
 assert time.monotonic()-begin<60
rows=[]
for (seed,q,phase),g in groups.items():rows.append(dict(seed=seed,quiet=q,work_quarter=phase,**g,root_semigradient_RMS=math.sqrt(g['squared_norm_sum']/g['n']),root_residual_RMS=math.sqrt(g['residual_squared_sum']/g['n'])))
assert total==48017
result=dict(status='PASS_ALL_CLOSED_ROOT_SEMIGRADIENT_READ',roots=total,terminal_search_targets=term_target,rows=rows,seconds=time.monotonic()-begin,scope='Static root prediction/semigradient toward saved search values, allzeros included. No TDLeaf gradient substitution, Treegradient inference or update application. All87data/weights exposed and varying across episodes; not a calibration/validation set for88. Zero error and zero feature input distinguished.',decision='Do not generalize eight zero-root examples into a universal Rootcontrol failure. A future calibrated Root/Tree control still requires its own independentTRAIN frozen-tree sample and both gradient streams; no multiplier fit here.')
write_json(O/'result.json',result);print('ROOT_COVERAGE',[(r['seed'],r['quiet'],r['n'],r['nonzero_semigradient'],round(r['root_semigradient_RMS'],8))for r in rows if r['work_quarter']=='all'])

