from pathlib import Path
from copy import copy
import sys,json,time,math
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';sys.path[:0]=[str(R),str(R/'tests')]
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom,LeapAtom
from generic_chess.core.actions import BoardMove
from generic_chess.core.coordinates import Square
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.learning.features import material_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
write_json(D/'qleaf-weighted-plan.json',dict(question='Does the nominal main-PV material derivative have the wrong sign for a real fractional qsearch scalar?',changed_premise='Unit coefficients allow a compiler-order tie to mask the qleaf mismatch. Fixed R1/X2 removes that quiet/capture tie; declared two +.1 perturbations check derivative signs, not fit weights or play strength.',cases=[dict(q=0,R=1.,X=2.),dict(q=1,R=1.,X=2.),dict(q=1,R=1.1,X=2.),dict(q=1,R=1.,X=2.1)],compilers=['legacy','semantic'],total_calls=8,forecast_seconds=5,whole_cap_seconds=30,limits=dict(depth=2,nodes=20000,seconds=3,qhard=6),decision='If actual qscore derivative differs from the replayed main-PV derivative, that public field is insufficient for future q-based learning. No production/API/AUX changes; current owner search returns its own leaf.'))
rule=make_ruleset(4,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1))),T('X',LeapAtom((0,3)))],lines=['..rk','....','..X.','K...'])
begin=time.monotonic();rows=[]
def f(state):
 v=material_features(state.position,('R','X'),perspective=0);return tuple(a+b for a,b in zip(v.board_counts,v.hand_counts))
for name,compiler in [('legacy',compile_ruleset),('semantic',compile_legacy_ruleset_for_semantic_execution)]:
 c=compiler(rule);s=GameSession(c);initial=(record_value(s.state),record_value(s.to_record()))
 for q,w in [(0,(1.,2.)),(1,(1.,2.)),(1,(1.1,2.)),(1,(1.,2.1))]:
  assert time.monotonic()-begin<30
  for n in('rollout','advisor','slack'):
   v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not v.get('user_paused')and not v.get('stopped')
  class Material:
   def evaluate(self,state):return sum(a*b for a,b in zip(f(state),w))*(1 if state.position.side_to_move==0 else -1)
  p=AlphaBetaPlayer(c,evaluator_override=Material(),use_disk_cache=False,use_native_semantic_legality=False,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
  d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=3,quiescence_max_depth=q,quiescence_hard_max_depth=6));leaf=copy(s)
  for a in d.principal_variation:leaf.submit(a)
  phi=f(leaf.state);raw=sum(a*b for a,b in zip(phi,w));recap=copy(leaf);recap_state=None
  if q:
   # The returned main PV stops before this legal tactical continuation.
   recap.submit(BoardMove(Square(1,0),Square(2,1)));recap_state=record_value(recap.state)
   assert f(recap.state)==(1,-1) and not recap.result.is_terminal if hasattr(recap.result,'is_terminal')else f(recap.state)==(1,-1)
   assert abs(sum(a*b for a,b in zip(f(recap.state),w))-d.score)<1e-12
  assert initial==(record_value(s.state),record_value(s.to_record()))
  rows.append(dict(compiler=name,q=q,weights=list(w),decision=record_value(d),root_record=initial[1],root_state=initial[0],main_PV_leaf=record_value(leaf.state),main_PV_features=list(phi),main_PV_material=raw,legal_recapture_full_state=recap_state,legal_recapture_features=list(f(recap.state))if q else None,score_matches_main_PV_material=abs(raw-d.score)<1e-12))
  print(name,q,w,d.score,raw,phi,flush=True)
for name in('legacy','semantic'):
 rs=[r for r in rows if r['compiler']==name];a,b,pr,px=rs
 assert a['score_matches_main_PV_material'] and all(not x['score_matches_main_PV_material']for x in(b,pr,px))
 assert math.isclose((pr['decision']['score']-b['decision']['score'])/.1,1,abs_tol=1e-10)
 assert math.isclose((pr['main_PV_material']-b['main_PV_material'])/.1,-1,abs_tol=1e-10)
 assert math.isclose((px['decision']['score']-b['decision']['score'])/.1,-1,abs_tol=1e-10)
write_json(D/'qleaf-weighted-result.json',dict(rows=rows,new_queries=8,new_training=0,seconds=time.monotonic()-begin,root_unchanged=True,conclusion='Actual returned scalar R derivative +1 versus nominal main-PV derivative -1 in both compilers; X derivative -1 in both. Legal recapture witness explains scalar, but is not a public selected-qleaf identity receipt. Existing API has no selected-qleaf/gradient contract; future integration must not reconstruct one from mainPV. No API/default/product/AUX modification.'))

