from pathlib import Path
import sys,json,time,math
from fractions import Fraction
import numpy as np
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
write_json(D/'signal-span-plan.json',dict(question='Do the four free material coordinates have any unobserved linear direction in the existing successful frozen86 trajectory?',decision='Exact missing direction would motivate changed data collection before interpreting learned ratios. Full local span only rejects this narrow blind-direction diagnosis, not identifies optimal/general prices.',scope='Existing5299 recorded leaves and37 episode signals only; no training/search/new outcomes/weight selection.',forecast_seconds=5,cap_seconds=30))
begin=time.monotonic()
v=json.loads((R/'.local_agent/binding-reuse-20261017/episode-signal-mechanism/mechanism.json').read_bytes())
def exactrank(a):
 a=[[Fraction(x) for x in row]for row in a];row=0
 for col in range(len(a[0])):
  p=next((i for i in range(row,len(a))if a[i][col]),None)
  if p is None:continue
  a[row],a[p]=a[p],a[row];q=a[row][col];a[row]=[x/q for x in a[row]]
  for i in range(row+1,len(a)):
   q=a[i][col];a[i]=[x-q*y for x,y in zip(a[i],a[row])]
  row+=1
 return row
def diag(a):
 a=np.array(a,dtype=float);s=np.linalg.svd(a,compute_uv=False);tol=s[0]*1e-12
 return dict(rows=len(a),singular_values=s.tolist(),rank_relative_tol1e_12=int(sum(s>tol)),condition_nonzero=float(s[0]/s[-1])if s[-1]>tol else None)
out=[]
for seed in (1977,8173):
 rs=[r for r in v['receipts']if r['seed']==seed and not r['pv_terminal']]
 phi=np.array([r['pv_phi'][1:]for r in rs],dtype=np.int64);grad=np.array([r['gradient'][1:]for r in rs]);gram=phi.T@phi
 eps=[e for e in v['episodes']if e['seed']==seed]
 updates=np.array([[sum(t['net_impulse'][j]for t in e['types'].values())for j in range(1,5)]for e in eps])
 named=[]
 for j,t in enumerate(('N','B','R','Q')):
  named.append(dict(type=t,nonzero_leaf_feature_rows=int(sum(phi[:,j]!=0)),gradient_squared_energy=float(grad[:,j]@grad[:,j]),signed_total_episode_impulse=float(updates[:,j].sum()),absolute_episode_impulse=float(abs(updates[:,j]).sum())))
 # Full-rank integer Gram is an exact narrow span claim. Numerical values describe observed data only.
 assert exactrank(gram.tolist())==np.linalg.matrix_rank(phi)
 out.append(dict(seed=seed,free_coordinates=['N','B','R','Q'],terminal_constant_rows=sum(r['seed']==seed and r['pv_terminal']for r in v['receipts']),nonterminal_rows=len(rs),zero_four_feature_rows=int(sum(np.all(phi==0,axis=1))),unique_four_feature_vectors=len(set(map(tuple,phi.tolist()))),integer_gram=gram.tolist(),exact_integer_rank=exactrank(gram.tolist()),raw_feature_span=diag(phi),returned_prediction_gradient_span=diag(grad),episode_total_impulse_span=diag(updates),coordinate_observations=named))
 assert time.monotonic()-begin<30
write_json(D/'signal-span-result.json',dict(rows=out,seconds=time.monotonic()-begin,source='Fixed86 actual5299receipt diagnostic reproduced previously; not new searches or independent rule authority.',decision='Observed four-coordinate feature and gradient span does not establish a unique optimum, good generalization, action sensitivity or equal sampling. No model expansion or additional exploration batch justified solely by a nonexistent exact feature nullspace.',limitations=['Rows within episodes and prefixes are correlated; counts are not effective independent samples.','Targets and selected PV depend on frozen current policy/search; local numerical sensitivity does not identify causal value or a global price vector.','Episode aggregate vectors include cancellation and feedback; no statistical identifiability or causal per-piece attribution follows.']))
print(json.dumps(out,indent=2))

