from pathlib import Path
import json,sys,math,time
import numpy as np
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
v=json.loads((R/'.local_agent/binding-reuse-20261017/episode-signal-mechanism/mechanism.json').read_bytes())
curves=[json.loads(x)for x in(D/'fixed86/results/dev_aux/task2497/curves.jsonl').read_text(encoding='utf8').splitlines()]
weights={(r['seed'],r['game'],r['ply']):r['before']for r in curves if 'ply'in r}
beta0=.1;beta1=math.atanh(.25);out=[];maxerr=0.;begin=time.monotonic()
def quant(v):
 a=sorted(v);return {str(q):float(a[int(q*(len(a)-1))])for q in (0,.1,.5,.9,1)}
for seed in (1977,8173):
 rows=[r for r in v['receipts']if r['seed']==seed];raw=[];g0=[];g1=[];ratio=[];zero=0;term=0
 for r in rows:
  if r['pv_terminal']:term+=1;assert not any(r['gradient']);continue
  phi=np.array(r['pv_phi'],dtype=float);w=np.array(weights[(seed,r['game'],r['ply'])]);m=float(phi@w);h0=math.tanh(beta0*m);h1=math.tanh(beta1*m);assert abs(h0-r['value'])<1e-12
  e0=beta0*(1-h0*h0)*phi[1:];e1=beta1*(1-h1*h1)*phi[1:];maxerr=max(maxerr,max(abs(e0-np.array(r['gradient'][1:]))));raw.append(m);g0.append(float(sum(abs(e0))));g1.append(float(sum(abs(e1))))
  if not any(phi[1:]):zero+=1
  else:ratio.append(beta1*(1-h1*h1)/(beta0*(1-h0*h0)))
 out.append(dict(seed=seed,nonterminal_leaves=len(raw),terminal_constant_leaves=term,zero_feature_gradient_leaves=zero,raw_material_quantiles=quant(raw),current_beta_gradient_L1_quantiles=quant(g0),paper_beta_gradient_L1_quantiles=quant(g1),gradient_ratio_quantiles=quant(ratio),abs_prediction_over_0point95=dict(beta_0point1=sum(abs(math.tanh(beta0*x))>.95 for x in raw),beta_atanh0point25=sum(abs(math.tanh(beta1*x))>.95 for x in raw))))
old=json.loads((D/'calibration-analysis.json').read_bytes())
# Original inline calculation and this restored executable must agree on the substantive results.
assert out==old['rows'],(out,old['rows'])
write_json(D/'calibration-reproduced.json',dict(beta_current=beta0,beta_paper=beta1,rows=out,max_returned_gradient_error=maxerr,original_inline_result_matches=True,seconds=time.monotonic()-begin,claim=old['claim']))
print('CALIBRATION_REPRODUCED',len(v['receipts']),maxerr,round(time.monotonic()-begin,4))

