from pathlib import Path
import sys,json,time,hashlib
from dataclasses import replace
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';W=D/'fixed86';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.coordinates import Square
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from results.dev_aux.task2492.adapters import SessionEnv
from results.dev_aux.task2397.material import channels
from scripts.generic_session_win_proof import SessionChoice
v=json.loads((D/'promotion-input.json').read_bytes());rule=deserialize_ruleset(json.dumps(v['rule']));c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);original=GameSession(c);names=tuple((kind,t)for kind in ('board','hand')for t in sorted(rule.piece_types));env=SessionEnv(original,names);begin=time.monotonic();rows=[];roots=[]
def check():
 assert time.monotonic()-begin<60
 for n in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('user_paused')and not f.get('stopped')
def snap():return(record_value(env.session.state),record_value(env.session.to_record()),record_value(env.session.result),tuple(env.features()))
initial=snap()
for e in v['witness']['capture_reply_drop']['edges']:
 check();a=e['action'];action=SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])if 'from_square'in a else SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']));choice=SessionChoice('ACTION',action=action);available=env.actions();assert choice in available;before=snap();roots.append(before);env.push(choice);after=snap();assert after[0]==e['fullstate'];assert len(env.session.state.history)==env.session.state.ply_count+1
 fs=channels(env.session.state.position,0);expect=tuple(fs[k].get(t,0)for k,t in names);assert expect==env.features();assert channels(env.session.state.position,1)=={k:{t:-n for t,n in values.items()}for k,values in fs.items()}
 rows.append(dict(action=a,feature_channels=list(names),features=list(expect),full_state=after[0],record=after[1],features_by_identity=fs));assert record_value(original.state)==initial[0]and record_value(original.to_record())==initial[1]
for before in reversed(roots):env.pop();assert snap()==before
assert snap()==initial and env.stack==[]
write_json(D/'promotion-result.json',dict(status='PASS_SCOPED_EXISTING_INTERFACE',new_action_executions=3,new_searches=0,new_training=0,rows=rows,initial_full_state=initial[0],full_root_restored=True,original_session_unchanged=True,seconds=time.monotonic()-begin,source_aux_sha='5f3cc0aada9f75794a55f12119f1e78e59039142',scope='One existing fullsemantic NP/aux/promotion/capture/drop path. Complete typed actions and all rule types retained, no Generic strength or all-domain equivalence. Proof helper used ONLYchoices/execute, no prove/verify/search.'))
print('PROMOTION_INTERFACE',len(rows),rows[0]['features_by_identity'],rows[1]['features_by_identity'],rows[2]['features_by_identity'],round(time.monotonic()-begin,3))
