from pathlib import Path
from copy import copy
import sys,json,time
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';sys.path[:0]=[str(R),str(R/'tests')]
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom,LeapAtom
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.learning.features import material_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
write_json(D/'qleaf-victim-plan.json',dict(question='Can a forced immobile victim produce an actual difference between public main PV material and the scalar qsearch result?',changed_premise='Previous checking/fork fixtures accidentally allowed a main-PV leaf with matching material. This rule gives root king moves but no move for the exposed valued X; every main child leaves an available black rook capture.',decision='A mismatch forbids using nominal main PV as actual q-target gradient in future Generic learner integration. Keep existing AUX own leaf-return search; no new public API or strength experiment.',calls=4,depth=1,qdepths=[0,1],whole_cap_seconds=30,forecast_seconds=3,nodes_per_query=20000,seconds_per_query=5,scope='One declared legacy-compatible rule and two compilers, existing Core only; no learning/AUX code/solver.'))
start=time.monotonic();rows=[]
rule=make_ruleset(4,[king_type(),T('R',*(RayAtom(d)for d in((1,0),(-1,0),(0,1),(0,-1)))),T('X',LeapAtom((0,3)))],lines=['..rk','....','..X.','K...'])
for name,compiler in [('legacy',compile_ruleset),('semantic',compile_legacy_ruleset_for_semantic_execution)]:
 c=compiler(rule);s=GameSession(c);initial=record_value(s.state),record_value(s.to_record())
 class Material:
  def evaluate(self,state):
   f=material_features(state.position,('R','X'),perspective=state.position.side_to_move);return sum(f.board_counts+f.hand_counts)
 ev=Material()
 for q in (0,1):
  assert time.monotonic()-start<30
  for n in('rollout','advisor','slack'):
   f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('user_paused')and not f.get('stopped')
  p=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
  d=p.choose_action(s,SearchLimits(max_depth=1,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=6))
  leaf=copy(s)
  for a in d.principal_variation:leaf.submit(a)
  raw=ev.evaluate(leaf.state)*(1 if leaf.state.position.side_to_move==s.state.position.side_to_move else -1)
  assert (record_value(s.state),record_value(s.to_record()))==initial
  rows.append(dict(compiler=name,q=q,decision=record_value(d),root_state=initial[0],root_record=initial[1],main_PV_leaf=record_value(leaf.state),PV_leaf_root_material=raw,score_matches_material=(d.score==raw),root_unchanged=True))
  print(name,q,d.completed_depth,d.score,raw,len(d.principal_variation),flush=True)
write_json(D/'qleaf-victim-result.json',dict(rows=rows,seconds=time.monotonic()-start,new_queries=len(rows),new_training=0,scope='Actual main-PV/scalar boundary on one complete rule, no all-domain claim or new API.'))

