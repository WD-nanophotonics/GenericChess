from pathlib import Path
import json,sys,math
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';sys.path.insert(0,str(R));from tools.local_agent.common import write_json
ds=[json.loads(x)for x in(D/'peer87/exact/results/dev_aux/task2506/decisions.jsonl').read_text(encoding='utf8').splitlines()]
a=json.loads((D/'mean-update-contract/result.json').read_bytes());b=json.loads((D/'mean-update-contract-nonzero/result.json').read_bytes())
rows=[]
for r in a['rows']:
 q=next(x for x in ds if x['seed']==r['seed']and not x['quiet']and x['game']==0 and x['ply']==0)
 active_free=sum(s['active']and any(s['phi'][1:])for s in r['samples'])
 assert active_free==0 and not any(r['mean_update']) and any(q['gradient'])
 rows.append(dict(seed=r['seed'],same_full_initial_root=r['root_record'],all_returned_interior_nodes=r['batch_nodes'],active_residual_nodes=r['active_nodes'],interior_nodes_with_any_free_feature=sum(any(s['phi'][1:])for s in r['samples']),active_nodes_with_any_free_feature=active_free,mean_tree_update=r['mean_update'],selected_PV_phi=q['pv_phi'],selected_PV_gradient=q['gradient'],scope='Availability of nonzero PV eligibility, not proof any TD error/return improvement or all-node training failure. Same one family repeated across initials.'))
later=[dict(seed=r['seed'],batch_nodes=r['batch_nodes'],active_nodes=r['active_nodes'],mean_update=r['mean_update'],padded_with_N_inactive_bounds=r['additional_N_inactive_bounds_update'])for r in b['rows']]
result=dict(status='PASS_SCOPED_ZERO_AND_NONZERO_SIGNAL_CONTRACT',early=rows,later=later,new_search_queries=8,new_training=0,paper='https://papers.nips.cc/paper_files/paper/2009/file/389bc7bb1e1c2a5e7e147703232a88f6-Paper.pdf',source='0d9cba18252b7669c4dcf68f228dfd680f296d8e',decision='Do not interpret upcoming88 whole-regime result purely as added information or normalization. Read its already-recorded intervals for active free-coordinate gradients and update units before choosing one follow-on. No change to running eta/caps or new model/training is requested.',limits=['Four initials share the same first opening, not four independent position families.','First batches all have N35/freegradient0; half/double invariance is vacuous there. Later N26controls have only one nonzero update, halved by adding26synthetic inactive constraints; otherthree stay0.','Inactive-padding and complete-batch duplication are counterfactual frozen-loss probes, not actual new games or new trees.','Paper summed linear losses; this published variant averages transformed losses. Identical eta is not equal update scale; per-query versus per-episode freezing also differs.','No claim TreeStrap cannot learn, a richer network is required, or this explains unpublished88 outcomes.'])
write_json(D/'mean-signal-summary.json',result);print('ZERO_COVERAGE',[(r['seed'],r['active_residual_nodes'],r['active_nodes_with_any_free_feature'])for r in rows]);print('LATER_NONZERO',[(r['seed'],r['mean_update'])for r in later])

