from pathlib import Path
import sys,json,math
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';sys.path.insert(0,str(R));from tools.local_agent.common import write_json
write_json(D/'root-rms-plan.json',dict(question='Is the new Dot proposed TRAIN-only Root/Tree RMS matching well-defined on the actual zero-gradient controls?',scope='Read the eight existing frozen87main-interior batches; no new search/training/calibration choice. This exposed convenience data is NOT a new independent calibration set.',decision='Adopt static-state versus PV-gradient distinction and retain zero cases. If rootRMS is zero, report undefined multiplier rather than invent infinity. Defer any future calibration/batch until owner88 results leave a concrete question.',proposal_root='1792214684.150599',proposal_reply='1792214792.511309'))
results=[]
for kind,folder in(('early','mean-update-contract'),('later','mean-update-contract-nonzero')):
 data=json.loads((D/folder/'result.json').read_bytes());rows=[]
 for r in data['rows']:
  s=r['samples'][-1];w=r['initial_weights'];phi=s['phi'];pred=math.tanh(sum(x*y for x,y in zip(phi,w))/10);lo=math.tanh(s['lower']/10);hi=math.tanh(s['upper']/10);target=lo if pred<lo else hi if pred>hi else pred;err=target-pred
  g=[0. if j==0 else err*x*(1-pred*pred)/10 for j,x in enumerate(phi)];tg=[x/.05 for x in r['mean_update']]
  rows.append(dict(seed=r['seed'],root_semi_gradient=g,tree_mean_semi_gradient=tg,root_gradient_norm=math.sqrt(sum(x*x for x in g)),tree_gradient_norm=math.sqrt(sum(x*x for x in tg)),actual_batch_nodes=r['batch_nodes'],root_is_static_state=True))
 rm=math.sqrt(sum(r['root_gradient_norm']**2 for r in rows)/len(rows));tm=math.sqrt(sum(r['tree_gradient_norm']**2 for r in rows)/len(rows))
 results.append(dict(kind=kind,rows=rows,root_RMS=rm,tree_mean_RMS=tm,tree_to_root_scale=None if rm==0 else tm/rm,zero_included=True,undefined_if_zero_root=rm==0))
assert results[0]['root_RMS']==results[0]['tree_mean_RMS']==0 and results[0]['tree_to_root_scale']is None
write_json(D/'root-rms-result.json',dict(status='PASS_DEGENERATE_CALIBRATION_DIAGNOSIS',panels=results,scope='Exposed eightcase audit of proposed formula, not a fit/calibration parameter or Tree/Root outcome comparison. Four early zero cases give0/0undefined. Later onlyone nonzero case cannot support a robust reusable multiplier. No running88source/eta/cap changes.',adoption='Use STATIC gradient for Root/Tree, PV leaf gradient only for TDLeaf; denominator allreturned nodes including inactive; halfsquared loss/scale explicit. Conditional follow-on is deferred until88publication/decision.'))
print([(x['kind'],x['root_RMS'],x['tree_mean_RMS'],x['tree_to_root_scale'])for x in results])

