from pathlib import Path
from dataclasses import replace
import sys,json,math,time
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';W=D/'peer87/exact';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
import chess
from results.dev_aux.task2492.adapters import ChessEnv
from results.dev_aux.task2492.learning import Model,TreeStrap,Sample
from results.dev_aux.task2504.search import TrainingSearch
O=D/'mean-update-contract-nonzero';O.mkdir(exist_ok=False)
write_json(O/'plan.json',dict(question='Does mean all-node update size depend only on informative targets, and can one fixed eta convert it to the paper sum across actual trees?',scope='Changed premise: first four roots have active residuals but ZERO free gradient, making normalization checks vacuous. Select first later complete plain root per seed with NONPAWN material imbalance, using root counts only, not rewards/parameter updates. Four new queries, all original zero controls retained. Fixed targets, no training/fitness/88source.',forecast_seconds=5,whole_cap_seconds=30,new_search_queries=4,decision='Characterize normalization separately from added node information before interpreting already-running88. Do not change its source/caps/eta or start an ablation.'))
eps=[json.loads(x)for x in(W/'results/dev_aux/task2506/episodes.jsonl').read_text(encoding='utf8').splitlines()];ds=[json.loads(x)for x in(W/'results/dev_aux/task2506/decisions.jsonl').read_text(encoding='utf8').splitlines()];begin=time.monotonic();out=[]
for seed in(1977,8173,27182,31415):
 assert time.monotonic()-begin<30
 chosen=next(r for r in ds if r['seed']==seed and not r['quiet']and r['complete']and any(len(chess.Board(r['root_fen']).pieces(t,chess.WHITE))!=len(chess.Board(r['root_fen']).pieces(t,chess.BLACK))for t in(2,3,4,5)));e=next(x for x in eps if x['seed']==seed and not x['quiet']and x['game']==chosen['game']);b=chess.Board(e['initial_record']['initial'])
 for u in e['initial_record']['moves']:b.push_uci(u)
 for old in ds:
  if old['seed']==seed and not old['quiet']and old['game']==e['game']and old['ply']<chosen['ply']:assert old['complete'];b.push_uci(old['action'])
 assert b.fen()==chosen['root_fen'];m=Model(e['initial_weights']);r=TrainingSearch(2,quiet=False).search(ChessEnv(b),m,nodes=8192,seconds=5,seed=seed*100000+e['game']*1000+chosen['ply']);assert r.complete
 samples=r.samples;N=len(samples)
 def calc(w):
  loss=0.;direction=[0.]*5;active=0;rows=[]
  for s in samples:
   x=sum(a*b for a,b in zip(w,s.phi))/10;pred=math.tanh(x);lo=math.tanh(s.lower/10);hi=math.tanh(s.upper/10);target=lo if pred<lo else hi if pred>hi else pred;error=target-pred;active+=error!=0;loss+=error*error/2
   g=[0. if j==0 else a*(1-pred*pred)/10 for j,a in enumerate(s.phi)]
   direction=[a+error*b for a,b in zip(direction,g)];rows.append(dict(phi=s.phi,lower=s.lower,upper=s.upper,active=error!=0,error=error))
  return loss/N,[x/N for x in direction],active,rows
 loss,direction,active,rows=calc(m.weights);numeric=[]
 for j in range(1,5):
  plus=list(m.weights);minus=list(m.weights);plus[j]+=1e-6;minus[j]-=1e-6;numeric.append((calc(plus)[0]-calc(minus)[0])/2e-6)
 assert max(abs(a+b)for a,b in zip(numeric,direction[1:]))<1e-8
 updated=Model(m.weights);stats=TreeStrap(.05).update(updated,r);delta=[b-a for a,b in zip(m.weights,updated.weights)]
 assert max(abs(a-.05*b)for a,b in zip(delta,direction))<1e-14
 # Add N syntactically valid, completely inactive interval constraints. No informative gradient changes.
 inert=Sample((0.,0.,0.,0.,0.),-math.inf,math.inf,1);padded=replace(r,samples=samples+(inert,)*N);up2=Model(m.weights);padstats=TreeStrap(.05).update(up2,padded);delta2=[b-a for a,b in zip(m.weights,up2.weights)]
 assert padstats['active']==stats['active']
 assert max(abs(a-2*b)for a,b in zip(delta,delta2))<1e-14
 duplicated=replace(r,samples=samples+samples);up3=Model(m.weights);TreeStrap(.05).update(up3,duplicated);assert max(abs(a-b)for a,b in zip(updated.weights,up3.weights))<1e-14
 out.append(dict(seed=seed,root_record=dict(initial=e['initial_record']['initial'],moves=[a.uci()for a in b.move_stack],fen=b.fen()),initial_weights=m.weights,batch_nodes=N,active_nodes=active,active_fraction=active/N,mean_loss=loss,mean_gradient_norm=math.sqrt(sum(x*x for x in direction)),sum_to_mean_factor=N,mean_update=delta,additional_N_inactive_bounds_update=delta2,duplicate_complete_batch_same_update=True,mean_gradient_finite_difference_max_error=max(abs(a+b)for a,b in zip(numeric,direction[1:])),samples=rows))
write_json(O/'result.json',dict(status='PASS_ACTUAL_FROZEN_BATCH_NORMALIZATION_CONTRACT',rows=out,seconds=time.monotonic()-begin,new_searches=4,new_training=0,claim='Mean batch update halves when equally many inactive bounds are added, and is unchanged when the whole batch repeats. Sum/mean differ by actual N at the same frozen model; no global eta matches trees with differing N. This is an intended variant, not a bug or a strength comparison. TD episode freezing/timing also differs; current88 is a whole-regime study.'))
print('MEAN_CONTRACT',[(x['seed'],x['batch_nodes'],x['active_nodes'],round(x['mean_gradient_norm'],7))for x in out])

