from pathlib import Path
import json,sys,time,collections,hashlib
R=Path.cwd();D=R/'.local_agent/learning-cost-20261017';W=D/'peer87/exact';sys.path[:0]=[str(W),str(R)]
from tools.local_agent.common import write_json
import chess
O=D/'free-feature-coverage';O.mkdir(exist_ok=False)
write_json(O/'plan.json',dict(question='Are the four early zero-gradient examples structurally representative or rare within existing87completed TRAIN roots?',decision='If few roots structurally lack every free input, do not generalize small examples into model expansion. If many, inspect actual active-gradient coverage in future88 logs before attributing its regime contrast to information/eta. No architecture or training follows automatically.',scope='Complete existing Chess histories only; classify root and all lawful one-ply child FREE material vectors. A zero root and all-zero children certify zero main-interior feature gradients for this depth2 sampler. Nonzero features do NOT imply active residual, useful gradient, learning success or sample independence.',forecast_seconds=15,cap_seconds=120,new_searches=0,new_training=0,domain='Frozen87Chess trajectories, not Generic games or unseen88data.'))
def lines(p):return[json.loads(x)for x in p.read_text(encoding='utf8').splitlines()]
base=W/'results/dev_aux/task2506';ds=lines(base/'decisions.jsonl');eps=lines(base/'episodes.jsonl');by=collections.defaultdict(list)
for r in ds:by[r['seed'],r['quiet'],r['game']].append(r)
counts=collections.Counter();arms=collections.defaultdict(collections.Counter);classes=collections.Counter();examples={};begin=time.monotonic();lastflag=0.;digest=hashlib.sha256();examined=0;children=0;failure=None
def features(b):return tuple(b.pieces_mask(t,chess.WHITE).bit_count()-b.pieces_mask(t,chess.BLACK).bit_count()for t in(2,3,4,5))
def poll():
 global lastflag
 now=time.monotonic();assert now-begin<120,'wholecap120'
 if now-lastflag>=.5:
  for n in('rollout','advisor','slack'):
   v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not v.get('user_paused')and not v.get('stopped'),'USER_STOP'
  lastflag=now
try:
 with(O/'rows.jsonl').open('x',encoding='utf8')as out:
  for e in eps:
   b=chess.Board(e['initial_record']['initial'])
   for u in e['initial_record']['moves']:b.push_uci(u)
   for old in by[e['seed'],e['quiet'],e['game']]:
    poll();assert b.fen()==old['root_fen']
    if not old['complete']:continue
    phi=features(b);nchildren=nonzerochildren=0
    if any(phi):tag='ROOT_FREE_INPUT_AVAILABLE'
    else:
     before=(b.fen(),tuple(b.move_stack))
     for move in tuple(b.legal_moves):
      b.push(move)
      try:nonzerochildren+=any(features(b));nchildren+=1
      finally:b.pop()
     assert before==(b.fen(),tuple(b.move_stack))
     tag='ONLY_POTENTIAL_CHILD_FREE_INPUT'if nonzerochildren else'CERTIFIED_ZERO_MAIN_INTERIOR_FREE_INPUT'
    row=dict(seed=e['seed'],quiet=e['quiet'],game=e['game'],ply=old['ply'],tag=tag,root_phi=phi,children_scanned=nchildren,nonzero_children=nonzerochildren)
    raw=json.dumps(row,sort_keys=True,separators=(',',':'));out.write(raw+'\n');digest.update(raw.encode());counts[tag]+=1;arms[str((e['seed'],e['quiet']))][tag]+=1;children+=nchildren;examined+=1
    if tag not in examples:examples[tag]=dict(row,full_root_record=dict(initial=e['initial_record']['initial'],moves=[a.uci()for a in b.move_stack],fen=b.fen()))
    b.push_uci(old['action'])
except Exception as ex:failure=dict(type=type(ex).__name__,message=str(ex))
result=dict(status='PASS_ALL_EXISTING_COMPLETED_ROOTS'if failure is None and examined==48017 else'PARTIAL_PRESERVED',completed_roots_examined=examined,expected=48017,oneply_children_examined=children,counts=dict(counts),per_arm={k:dict(v)for k,v in arms.items()},examples=examples,seconds=time.monotonic()-begin,digest_sha256=digest.hexdigest(),failure=failure,scope='A structural sufficient-zero condition over complete historical root/one-ply legal features only. Nonzero child could be terminal and absent from returnedinterior samples; its feature availability is only potential. Active errors/cancellation/target value are not inferred. Repeated trajectories/roles/seeds are not independent samples; no88data, newtraining/search/arena or Generic-domain proof.')
write_json(O/'result.json',result);print(json.dumps({k:v for k,v in result.items()if k not in('per_arm','examples')},indent=2))

