"""Actual Core-owned caller: semantic attack backend and legality attribution."""
import argparse, hashlib, json, random, sys, time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value, write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from scripts.native_core_availability import NativeCoreAvailability
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess.core import search_runtime as runtime_module
import inspect,textwrap
from generic_chess.ai.alphabeta import search as search_module
from scripts.quiet_drop_probe import QuietDropProbe
from generic_chess.ai.alphabeta.tuning import SearchTuning

class CountedSemanticEvaluator(SemanticAttackEvaluator):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.score_calls=self.map_calls=0
    def evaluate(self,state):
        self.score_calls+=1;return super().evaluate(state)
    def _attack_maps(self,state):
        self.map_calls+=1;return super()._attack_maps(state)


from collections import Counter
counts=Counter(); phase='other'
def legal(ctx,checkpoint,checked):
    global phase
    previous=phase;phase='evasion' if checked else 'ordinary_q'
    try:
        actions=search_module._runtime_legal_actions(ctx,checkpoint)
        counts[phase+'_queries']+=1;counts[phase+'_emitted']+=len(actions)
        return actions
    finally:phase=previous

def run(output):
    global counts
    b=Path(output);b.mkdir(exist_ok=True)
    assert not (b/'declaration.json').exists()
    write_record(b/'declaration.json',dict(question='How much full Native legal generation precedes unvisited q actions?',calls=4,node_budget=8192,max_depth=12,seconds=120,q=4,hardq=8,pvs=True,orders=['control,audit','audit,control'],expected_cost='At most480seconds search plus setup, under one hour',decision='Identify a measured eager consumer before adding an interface; no noisy-only full legality replacement. Audit runtime overhead is not speedup.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
    case=next(x for x in CASES if x['id']=='shogi-drop');c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'))
    core=CoreBoard(case,c);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
    s=SimpleNamespace(state=core.initial,_search_witnesses=core.witnesses,legal_actions=core.runtime.legal_actions)
    write_record(b/'samples.json',dict(case=case,state=record_value(s.state),witnesses=record_value(core.witnesses)))
    original_q=search_module._quiescence_runtime;original_native=ns.transient_legal_actions
    original_noisy=search_module.noisy_child
    src=textwrap.dedent(inspect.getsource(original_q))
    src=src.replace('actions = _runtime_legal_actions(ctx, ctx.checkpoint)','actions = eager_legal(ctx, ctx.checkpoint, in_check)')
    src=src.replace('        for action in _order_qactions(state, actions, ply, ctx):','        for action in _order_qactions(state, actions, ply, ctx):\n            eager_counts["evasion_visited"] += 1')
    src=src.replace('    for action in ordered:','    for action in ordered:\n        eager_counts["ordinary_q_visited"] += 1')
    src=src.replace('    if terminal.is_terminal:','    if terminal.is_terminal:\n        eager_counts["q_terminal"] += 1')
    def native(rules,position):
        raw=ns.transient_legal_actions_audit(rules,position)
        for k,v in raw.items():
            if k!='actions':counts[phase+'_'+k]+=v
        counts[phase+'_native_calls']+=1
        return raw['actions']
    def noisy(*a,**kw):
        value=original_noisy(*a,**kw);counts['ordinary_q_noisy' if value else 'ordinary_q_quiet']+=1
        if a[1].terminal_status.is_terminal:counts['ordinary_q_terminal_child']+=1
        return value
    rows=[]
    try:
        for order in range(2):
            for mode in (['control','audit'] if order==0 else ['audit','control']):
                counts=Counter();namespace=dict(search_module.__dict__,eager_legal=legal,eager_counts=counts)
                exec(compile(src,'<research-eager-count>','exec'),namespace)
                search_module._quiescence_runtime=namespace['_quiescence_runtime'] if mode=='audit' else original_q
                ns.transient_legal_actions=native if mode=='audit' else original_native
                search_module.noisy_child=noisy if mode=='audit' else original_noisy
                runtimes=[];saved_attach=SearchPathRuntime.attach_stats
                def attach(rt,stats):
                    value=saved_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return value
                SearchPathRuntime.attach_stats=attach
                try:
                    p.rr.stopped();ev=CountedSemanticEvaluator(c,profile,ec,backend='native');player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=True))
                    t=time.perf_counter();value=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=8192,max_time_seconds=120,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
                    rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot
                    rows.append(dict(order=order,mode=mode,decision=record_value(value),counts=dict(counts),seconds=elapsed,root_restored=True,runtime=dict(provider_calls=rt.legal_provider_calls,fallbacks=rt.legal_provider_fallbacks,failures=rt.legal_provider_operational_failures),availability=player.native_legality_provider.availability_metrics))
                    write_record(b/'result.json',dict(complete=False,rows=rows));print(order,mode,round(elapsed,3),dict(counts),flush=True)
                finally:SearchPathRuntime.attach_stats=saved_attach
    finally:
        search_module._quiescence_runtime=original_q;ns.transient_legal_actions=original_native;search_module.noisy_child=original_noisy
    write_record(b/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run(sys.argv[1])
