"""Independent coordinate/full-board four-ply minimax on predeclared sampled roots."""
import sys,json,hashlib,time,itertools,random
from pathlib import Path
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'surviving-service.json').read_bytes();src=json.loads(raw);out=p/'survivor-oracle.json';assert not out.exists();contexts=list(itertools.permutations(range(16),3));indices=sorted(random.Random(2026100804).sample(range(3360),64));start=time.perf_counter()
r=dict(complete=False,declaration='Independent target-coordinate predicates, full occupancy/capture reconstruction and minimax depth4.64 seed2026100804 context indices per16 mode pairs, both phases=2048 checks. No producer move/DP reuse. Sampling qualifies only inspected roots.',source_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),indices=indices,rows=[]);write_record(out,r)
def destinations(mode,s,board,owner):
 for t in range(16):
  if t==s or board.get(t,(-1,''))[0]==owner:continue
  dx,dy=t%4-s%4,t//4-s//4
  if mode=='N':
   if sorted((abs(dx),abs(dy)))==[1,2]:yield t
   continue
  if not ((mode=='Q' and (dx==0 or dy==0 or abs(dx)==abs(dy))) or (mode=='R' and (dx==0 or dy==0)) or (mode=='B' and abs(dx)==abs(dy))):continue
  sx=(dx>0)-(dx<0);sy=(dy>0)-(dy<0);x,y=s%4+sx,s//4+sy
  while (x,y)!=(t%4,t//4):
   if x+4*y in board:break
   x+=sx;y+=sy
  else:yield t
for row in src['rows']:
 edges=0
 @lru_cache(None)
 def solve(items,side,depth):
  global edges
  board=dict(items)
  if depth==0 or not any(piece[0]==0 for piece in board.values()):return 0
  moving=next(((s,piece) for s,piece in items if piece[0]==side and piece[1]!='inert'),None)
  if moving is None:return solve(items,1-side,depth-1)
  s,piece=moving;aa=list(destinations(piece[1],s,board,side))
  if not aa:return solve(items,1-side,depth-1)
  values=[]
  for t in aa:
   edges+=1;child=dict(board);child.pop(s);victim=child.pop(t,None);child[t]=piece
   reward=(1 if side==0 else -1) if victim is not None else 0
   values.append(reward+solve(tuple(sorted(child.items())),1-side,depth-1))
  return (max if side==0 else min)(values)
 mismatches=[]
 for index in indices:
  s,e,v=contexts[index];board=tuple(sorted(((s,(0,row['actor'])),(e,(1,row['opponent'])),(v,(1,'inert')))))
  for side in (0,1):
   actual=solve(board,side,4);expected=row['orders'][side]['per_root'][index]
   if actual!=expected:mismatches.append(dict(index=index,side=side,actual=actual,expected=expected))
 r['rows'].append(dict(actor=row['actor'],opponent=row['opponent'],checks=128,mismatches=mismatches,full_board_edges=edges));write_record(out,r);print(row['actor'],row['opponent'],len(mismatches),edges,flush=True)
 assert not mismatches
r.update(complete=True,seconds=time.perf_counter()-start,checks=2048);write_record(out,r)
