"""Returned-hand histories: supported entries, static leaf and full PV request."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import SemanticSearchEngine
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'kernel-completed.json').read_bytes();src=json.loads(raw);w=json.loads((p/'native-witness-completed.json').read_bytes());prior=json.loads((ROOT/'.local_agent/joint-exposure-20261008/static-native-control.json').read_bytes());out=p/'returned-history-search.json';assert not out.exists()
r=dict(complete=False,declaration='For each baseG/P choose first recorded return-to-original-hand zero witness, not a result-selected search position. Replay five actual plies. Both entries use frozen static generic-v1 tables, depth3/4,20000nodes/5sec,q0,no root tactics, fresh engine per depth then warm repeat. Require legal action and full PV through completed depth or terminal. No production change; report differing contracts and incomplete score cells explicitly.',source_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[]);write_record(out,r)
class Static:
 def __init__(self,b,h):self.b=b;self.h=h
 def capture_order_value(self,moving_piece,captured_piece):return 10*self.b[captured_piece.current_type_id]-self.b[moving_piece.current_type_id]//10
 def evaluate(self,state):
  pos=state.position;side=pos.side_to_move
  return sum(self.b[x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(self.h[t]*v*(1 if o==side else -1) for o,h in enumerate(pos.hands) for t,v in h.counts)
for case in src['cases']:
 flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused')
 witness=next(x for x in w['rows'] if x['base']==case['base'] and x['returned_original_owner_hand']);drop=next(x['drop'] for x in case['drops'] if x['square']==witness['square'])
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));n=compile_native_semantic_rules(c);s=GameSession(c)
 for v in case['prefix']+[drop,witness['defense']]:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
 tables=next(x for x in prior['rows'] if x['name']=='custody-'+case['base']);e=Static(tables['board_values'],tables['hand_values'])
 row=dict(base=case['base'],square=witness['square'],history=record_value([x.action for x in s.history]),state=record_value(s.state),board_values=e.b,hand_values=e.h,cells=[]);r['rows'].append(row);write_record(out,r)
 for depth in (3,4):
  public=AlphaBetaPlayer(c,evaluator_override=e,use_disk_cache=False,use_native_semantic_legality=True,use_tt=True,use_ordering=True,tt_max_entries=16384,tuning=SearchTuning(use_root_tactical=False))
  native=SemanticSearchEngine(c,n,board_values=e.b,hand_values=e.h,tt_megabytes=1)
  for label,engine in (('public',public),('native',native)):
   for repeat in (0,1):
    start=time.perf_counter();limits=SearchLimits(max_depth=depth,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0)
    d=engine.choose_action(s,limits) if label=='public' else engine.search(s,limits);elapsed=time.perf_counter()-start;validate_pv(s,d)
    probe=GameSession(c)
    for rec in s.history:probe.submit(rec.action)
    for a in d.principal_variation:probe.submit(a)
    full=len(d.principal_variation)>=d.completed_depth or probe.state.terminal_status.is_terminal
    row['cells'].append(dict(depth=depth,entry=label,repeat=repeat,seconds=elapsed,decision=record_value(d),full_pv_contract=full));write_record(out,r)
    print(case['base'],depth,label,repeat,d.completed_depth,d.score,len(d.principal_variation),full,elapsed,flush=True)
r['complete']=True;write_record(out,r)
