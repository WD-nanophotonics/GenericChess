"""Full-PV change on a frozen nonstandard actual capture/reply/drop history."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import SemanticSearchEngine
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;source=ROOT/'.local_agent/joint-exposure-20261008';raw=(source/'static-native-control.json').read_bytes();tables=next(x for x in json.loads(raw)['rows'] if x['name']=='open');hist=json.loads((source/'recombined-history-completed.json').read_bytes());out=p/'recombined-full-pv.json';assert not out.exists()
c=compile_ruleset_for_execution(ruleset_from_dict(tables['definition']));n=compile_native_semantic_rules(c);s=GameSession(c)
for v in hist['preselected_actions']:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
class Static:
 def capture_order_value(self,moving_piece,captured_piece):return 10*tables['board_values'][captured_piece.current_type_id]-tables['board_values'][moving_piece.current_type_id]//10
 def evaluate(self,state):
  pos=state.position;side=pos.side_to_move
  return sum(tables['board_values'][x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(tables['hand_values'][t]*v*(1 if o==side else -1) for o,h in enumerate(pos.hands) for t,v in h.counts)
e=Static();r=dict(complete=False,declaration='Frozen open-leg5x5 actual three-ply capture/reply/drop history. Same static generic-v1 tables, public PVS false/true PV contract and native full PV,depth3/4,cold/warm,20000nodes/5sec/q0. Public PVS on in both output modes; independent Core references20000leaves/15sec at each depth. Incomplete=unknown, default not promoted.',source_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),history=hist['preselected_actions'],calls=[],references=[]);write_record(out,r)
for depth in (3,4):
 for mode in ('public-default','public-full','native-full'):
  engine=SemanticSearchEngine(c,n,board_values=tables['board_values'],hand_values=tables['hand_values'],tt_megabytes=1) if mode=='native-full' else AlphaBetaPlayer(c,evaluator_override=e,use_disk_cache=False,tt_max_entries=16384,tuning=SearchTuning(use_root_tactical=False,use_pvs=True,require_full_pv=mode=='public-full'))
  for repeat in (0,1):
   start=time.perf_counter();limits=SearchLimits(max_depth=depth,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0);d=engine.search(s,limits) if mode=='native-full' else engine.choose_action(s,limits);elapsed=time.perf_counter()-start;validate_pv(s,d)
   check=GameSession(c)
   for rec in s.history:check.submit(rec.action)
   for a in d.principal_variation:check.submit(a)
   full=len(d.principal_variation)>=d.completed_depth or check.state.terminal_status.is_terminal
   if mode!='public-default':assert full
   r['calls'].append(dict(depth=depth,mode=mode,repeat=repeat,seconds=elapsed,full_pv=full,decision=record_value(d)));write_record(out,r);print(depth,mode,repeat,d.completed_depth,d.score,len(d.principal_variation),elapsed,flush=True)
 counted=CountedEvaluator(e,seconds=15,evaluations=20000);start=time.perf_counter()
 try:
  score,action=reference_minimax(s.state,depth,counted,c);ref=dict(complete=True,depth=depth,score=score,action=record_value(action));assert all(x['decision']['score']==score for x in r['calls'] if x['depth']==depth and x['decision']['completed_depth']==depth)
 except ReferenceLimit:ref=dict(complete=False,depth=depth,score=None)
 ref.update(seconds=time.perf_counter()-start,leaf_evaluations=counted.calls);r['references'].append(ref);write_record(out,r)
r['complete']=True;write_record(out,r)
