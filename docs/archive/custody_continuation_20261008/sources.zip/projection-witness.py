"""Replay stochastic paths; local custody labels do not close the transition law."""
import sys,json,random,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;raw=(p/'exchangeable-custody.json').read_bytes();src=json.loads(raw);defs=json.loads((p/'kernel-completed.json').read_bytes());out=p/'projection-witness.json';assert not out.exists()
r=dict(complete=False,declaration='Replay already frozen seeds, do not create a new outcome population. Find two actual hand frontiers with the same tag base/controller/current side/multiplicity but differing legal matching-drop sets. Native whole-history legality verifies selected witnesses. This disproves exact closure of this projection only, not usefulness of an averaged hand coefficient.',source_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),pairs=[]);write_record(out,r);start=time.perf_counter();transitions=0
for case in defs['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));n=compile_native_semantic_rules(c);base=case['base'];seen={};found=False
 for cell in (x for x in src['cells'] if x['base']==base):
  drop=next(x['drop'] for x in case['drops'] if x['square']==cell['square'])
  for trace in cell['trajectories']:
   if not any(e['kind']=='capture_transfer' for e in trace['events']):continue
   s=GameSession(c)
   for v in case['prefix']+[drop]:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
   rng=random.Random(trace['seed']);square=tuple(cell['square']);hand=None
   for ply in range(trace['plies']):
    aa=sorted(s.legal_actions(),key=str);a=aa[rng.randrange(len(aa))];owner=s.state.position.side_to_move
    if isinstance(a,SemanticBoardMove):
     target=(a.to_square.file,a.to_square.rank)
     if (a.from_square.file,a.from_square.rank)==square:square=target
     elif target==square:square=None;hand=owner
    elif isinstance(a,SemanticDropMove) and hand==owner and a.base_type_id==base:
     if rng.randrange(s.state.position.hands[owner].count(base))==0:square=(a.to_square.file,a.to_square.rank);hand=None
    s.submit(a);transitions+=1
    if hand is not None and s.state.position.side_to_move==hand:
     count=s.state.position.hands[hand].count(base);key=(base,hand,hand,count)
     drops=tuple(sorted(str(a) for a in s.legal_actions() if isinstance(a,SemanticDropMove) and a.base_type_id==base))
     point=dict(seed=trace['seed'],starting_drop=cell['square'],ply=ply+1,projection=list(key),legal_drop_count=len(drops),legal_drops=list(drops),history=record_value([x.action for x in s.history]),state=record_value(s.state))
     native_actions={public_action(n,a) for a in guarded_actions(n,pack_semantic_search_position(c,n,s))};assert native_actions==set(s.legal_actions())
     if key in seen and seen[key]['legal_drops']!=list(drops):
      r['pairs'].append(dict(base=base,left=seen[key],right=point));found=True;break
     seen.setdefault(key,point)
   if found:break
  if found:break
 r.setdefault('searched_bases',[]).append(dict(base=base,witness_found=found));write_record(out,r)
r.update(complete=True,transitions=transitions,seconds=time.perf_counter()-start);write_record(out,r)
print([(x['base'],x['left']['legal_drop_count'],x['right']['legal_drop_count']) for x in r['pairs']],transitions,r['seconds'])
