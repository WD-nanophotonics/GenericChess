"""Can the existing exact entries provide complete PV without another cache?"""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.transposition import BoundType,score_from_tt
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'returned-history-search.json').read_bytes();prior=json.loads(raw);definitions=json.loads((p/'kernel-completed.json').read_bytes());out=p/'tt-chain-feasibility.json';assert not out.exists()
r=dict(complete=False,declaration='Inspect existing exact-depth TT action chains immediately after cold searches of frozen returned-hand histories, PVS on/off and full-PV on/off, depth3. Replay through authoritative full-history runtime; every entry must be exact at remaining depth, every action legal and final leaf/terminal value must agree. This measures eligibility only; no production TT reconstruction/cache or budget bypass.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),rows=[]);write_record(out,r)
class Static:
 def __init__(self,b,h):self.b=b;self.h=h
 def capture_order_value(self,moving_piece,captured_piece):return 10*self.b[captured_piece.current_type_id]-self.b[moving_piece.current_type_id]//10
 def evaluate(self,state):
  pos=state.position;side=pos.side_to_move
  return sum(self.b[x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(self.h[t]*v*(1 if o==side else -1) for o,h in enumerate(pos.hands) for t,v in h.counts)
for old in prior['rows']:
 c=compile_ruleset_for_execution(ruleset_from_dict(next(x for x in definitions['cases'] if x['base']==old['base'])['definition']));s=GameSession(c)
 for v in old['history']:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
 e=Static(old['board_values'],old['hand_values'])
 for full in (False,True):
  for pvs in (False,True):
   player=AlphaBetaPlayer(c,evaluator_override=e,use_disk_cache=False,tt_max_entries=16384,tuning=SearchTuning(use_root_tactical=False,require_full_pv=full,use_pvs=pvs));d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
   rt=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=player.native_legality_provider);start=time.perf_counter();entries=[];path=[];reason='depth';root_score=None
   for remaining in range(d.completed_depth,0,-1):
    if rt.terminal_status.is_terminal:reason='terminal';break
    entry=player._tt.probe(rt.search_key())
    entries.append(None if entry is None else dict(depth=entry.depth,bound=entry.bound.name,score=score_from_tt(entry.score,len(path))))
    if entry is None or entry.depth!=remaining or entry.bound is not BoundType.EXACT:reason='missing_or_nonexact';break
    if root_score is None:root_score=score_from_tt(entry.score,0)
    if entry.best_action not in rt.legal_actions():reason='not_legal';break
    path.append(entry.best_action);rt.push(entry.best_action)
   complete=len(path)==d.completed_depth or rt.terminal_status.is_terminal
   leaf=terminal_score(rt.terminal_status,rt.state.position.side_to_move,len(path)) if rt.terminal_status.is_terminal else e.evaluate(rt.state)
   value_agrees=((-1)**len(path))*leaf==d.score if complete else None
   if complete:assert value_agrees
   r['rows'].append(dict(base=old['base'],full=full,pvs=pvs,search_decision=record_value(d),entries=entries,path=record_value(path),complete=complete,reason=reason,value_agrees=value_agrees,replay_seconds=time.perf_counter()-start));write_record(out,r);print(old['base'],full,pvs,complete,reason,len(path),value_agrees,flush=True)
r['complete']=True;write_record(out,r)
