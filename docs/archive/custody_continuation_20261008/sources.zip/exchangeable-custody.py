"""Declared finite stochastic custody continuation; no learned material weights."""
import sys,json,time,hashlib,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;raw=(p/'kernel-completed.json').read_bytes();src=json.loads(raw);out=p/'exchangeable-custody.json';assert not out.exists()
common=set(map(tuple,(x['square'] for x in src['cases'][0]['drops'])))&set(map(tuple,(x['square'] for x in src['cases'][1]['drops'])))
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration=dict(question='Can an explicit full-state stochastic custody process retain capture/reset/drop/return without circular hand prices?',policy='Uniform over canonical sorted legal actions for both players; identical seed list per matched common drop, no optimum or game-strength interpretation. Aggregate same-base hands use exchangeable latent provenance: probability1/count that a matching drop selects the tracked tag.',population='Same six common drops of qualified counterfactual G/TP capture roots;32 trajectories per cell,32 subsequent plies,seed2026100803+trajectory; fixed before result. Whole Core history, nifu and promotion legality retained. Descriptive Monte Carlo under this law, not reachability or universal material coefficients.',reward='Every ordinary capture performed by the tagged entity earns+1 if its current controller is original owner0, -1 if owner1. Tag capture is an ownership transfer, never arbitrary inventory loss penalty. No unknown prices, discount or fitted phase weights. Terminal states stop with no additional game utility.',cost='384trajectories maximum12288 postdrop transitions, serial, persist per trajectory, stop flags before every trajectory; no worker, no altered frozen records.'),cells=[]);write_record(out,r);start=time.perf_counter()
for case in src['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));anchors={x.type_id for x in c.piece_types if x.is_anchor};base=case['base']
 for row in sorted((x for x in case['drops'] if tuple(x['square']) in common),key=lambda x:x['square']):
  s=initial_state(c)
  for v in case['prefix']+[row['drop']]:s=apply_action(s,next(a for a in legal_actions(s,c) if record_value(a)==v),c)
  cell=dict(base=base,square=row['square'],trajectories=[]);r['cells'].append(cell)
  for trial in range(32):
   stop=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not stop.get('user_paused')
   rng=random.Random(2026100803+trial);state=s;tag_square=tuple(row['square']);tag_hand=None;reward=0;events=[];plies=0
   for ply in range(32):
    if state.terminal_status.is_terminal:break
    aa=sorted(legal_actions(state,c),key=str)
    if not aa:break
    a=aa[rng.randrange(len(aa))];owner=state.position.side_to_move
    if isinstance(a,SemanticBoardMove):
     source=(a.from_square.file,a.from_square.rank);target=(a.to_square.file,a.to_square.rank)
     victim=state.position.board[a.to_square.file+9*a.to_square.rank]
     if source==tag_square:
      if victim is not None and victim.owner!=owner and victim.current_type_id not in anchors:
       amount=1 if owner==0 else -1;reward+=amount;events.append(dict(ply=ply,kind='service',owner=owner,reward=amount,target=record_value(victim)))
      tag_square=target
     elif target==tag_square:
      assert victim is not None and victim.base_type_id==base
      tag_square=None;tag_hand=owner;events.append(dict(ply=ply,kind='capture_transfer',owner=owner))
    elif isinstance(a,SemanticDropMove) and tag_hand==owner and a.base_type_id==base:
     count=state.position.hands[owner].count(base);assert count>=1
     selected=rng.randrange(count)==0
     events.append(dict(ply=ply,kind='exchangeable_drop',owner=owner,multiplicity=count,tag_selected=selected))
     if selected:tag_square=(a.to_square.file,a.to_square.rank);tag_hand=None
    state=apply_action(state,a,c);plies+=1
    if tag_square is not None:
     tag=state.position.board[tag_square[0]+9*tag_square[1]];assert tag is not None and tag.base_type_id==base
    else:assert tag_hand in (0,1) and state.position.hands[tag_hand].count(base)>=1
   cell['trajectories'].append(dict(seed=2026100803+trial,reward=reward,plies=plies,events=events,frontier=dict(square=tag_square,hand_owner=tag_hand),terminal=record_value(state.terminal_status)));write_record(out,r)
  print(base,row['square'],'sum',sum(x['reward'] for x in cell['trajectories']),'plies',sum(x['plies'] for x in cell['trajectories']),flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
