"""Rule-only paired original-owner trajectories to the first custody frontier."""
import sys,json,random,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'kernel-completed.json').read_bytes();src=json.loads(raw);out=p/'pretransfer-coupling.json';assert not out.exists();compiled=[compile_ruleset_for_execution(ruleset_from_dict(x['definition'])) for x in src['cases']];anchors={x.type_id for x in compiled[0].piece_types if x.is_anchor};start=time.perf_counter()
r=dict(complete=False,declaration='Original qualified matched nativeG/baseG versus currentTP/baseP at3,3, originally controlled by owner0; no forced capture prefix.64 trajectories,at most32plies,seed2026100805+i. Until first tag capture, uniform matched behavioral action keys couple legal policies. Tag moves ignore only differing G/TP pattern/type IDs; all other semantic metadata retained. Require unique keys and equal sets, no silent projection of duplicate/effect actions. Stop at first custody transfer or terminal; retain paired full frontiers. This isolates pre-transfer contribution and generates unconditioned boundary contexts, not whole prices or historical reachability.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),trajectories=[],frontiers=[],core_transitions=0,paired_action_set_checks=0);write_record(out,r)
def key(a,square):
 if isinstance(a,SemanticBoardMove):
  origin=(a.from_square.file,a.from_square.rank);target=(a.to_square.file,a.to_square.rank)
  return ('board',origin,target,a.promotion_target_id,'tag' if origin==square else (a.actor_type_id,a.pattern_id,a.geometry_id))
 return ('drop',a.base_type_id,(a.to_square.file,a.to_square.rank),a.pattern_id,a.geometry_id)
for trial in range(64):
 flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused')
 sessions=[GameSession(c) for c in compiled];rng=random.Random(2026100805+trial);square=(3,3);service=[0,0];history=[];frontier=False;plies=0
 for ply in range(32):
  terminal=[s.state.terminal_status.is_terminal for s in sessions];assert terminal[0]==terminal[1]
  if terminal[0]:break
  maps=[{json.dumps(key(a,square)):a for a in s.legal_actions()} for s in sessions]
  assert all(len(m)==len(s.legal_actions()) for m,s in zip(maps,sessions));assert maps[0].keys()==maps[1].keys();r['paired_action_set_checks']+=1
  if not maps[0]:break
  chosen=sorted(maps[0])[rng.randrange(len(maps[0]))];actions=[m[chosen] for m in maps];a=actions[0];new_square=square
  if isinstance(a,SemanticBoardMove):
   origin=(a.from_square.file,a.from_square.rank);target=(a.to_square.file,a.to_square.rank)
   if origin==square:
    for i,s in enumerate(sessions):
     victim=s.state.position.board[a.to_square.file+9*a.to_square.rank]
     service[i]+=int(victim is not None and victim.owner==1 and victim.current_type_id not in anchors)
    new_square=target
   elif target==square:frontier=True
  for s,a2 in zip(sessions,actions):s.submit(a2);r['core_transitions']+=1
  history.append(chosen);square=new_square;plies+=1;assert service[0]==service[1]
  if frontier:
   r['frontiers'].append(dict(seed=2026100805+trial,ply=plies,paired_actions=[record_value([x.action for x in s.history]) for s in sessions],paired_states=[record_value(s.state) for s in sessions]));break
 r['trajectories'].append(dict(seed=2026100805+trial,plies=plies,pretransfer_services=service,first_transfer=frontier,terminal=record_value(sessions[0].state.terminal_status)));write_record(out,r)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
print('Paired paths',len(r['trajectories']),'frontiers',len(r['frontiers']),'checks',r['paired_action_set_checks'],'transitions',r['core_transitions'],'seconds',r['seconds'])
