"""Declared PV ablation on frozen returned-hand histories, not speed-only ranking."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv,CountedEvaluator,ReferenceLimit
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;raw=(p/'returned-history-search.json').read_bytes();prior=json.loads(raw);definitions=json.loads((p/'kernel-completed.json').read_bytes());out=p/'full-pv-chain-ablation.json';assert not out.exists()
r=dict(complete=False,source_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_pins={x:hashlib.sha256((ROOT/x).read_bytes()).hexdigest() for x in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/tuning.py')},declaration='Same two frozen five-ply returned-hand G/P histories and static leaf. Public require_full_pv false/true x PVS false/true x depths3/4 x cold/warm, each20000nodes/5sec/q0/no root tactics,fresh TT per cell. Completed requested-depth PV must reach depth or true terminal. Costs, incomplete depths and different tie actions retained. Earlier independent Core depth3 references remain unknown; not repeated here. Existing sufficient-depth cache scores may supply shorter legal PV prefixes, as in the default cache contract. No output-only cache bypass or evaluator change.',rows=[]);write_record(out,r)
class Static:
 def __init__(self,b,h):self.b=b;self.h=h
 def capture_order_value(self,moving_piece,captured_piece):return 10*self.b[captured_piece.current_type_id]-self.b[moving_piece.current_type_id]//10
 def evaluate(self,state):
  pos=state.position;side=pos.side_to_move
  return sum(self.b[x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(self.h[t]*v*(1 if o==side else -1) for o,h in enumerate(pos.hands) for t,v in h.counts)
for old in prior['rows']:
 flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused')
 c=compile_ruleset_for_execution(ruleset_from_dict(next(x for x in definitions['cases'] if x['base']==old['base'])['definition']));s=GameSession(c)
 for v in old['history']:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
 e=Static(old['board_values'],old['hand_values']);row=dict(base=old['base'],calls=[]);r['rows'].append(row)
 for full in (False,True):
  for pvs in (False,True):
   for depth in (3,4):
    player=AlphaBetaPlayer(c,evaluator_override=e,use_disk_cache=False,tt_max_entries=16384,tuning=SearchTuning(use_root_tactical=False,require_full_pv=full,use_pvs=pvs))
    for repeat in (0,1):
     start=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-start;validate_pv(s,d)
     check=GameSession(c)
     for rec in s.history:check.submit(rec.action)
     for a in d.principal_variation:check.submit(a)
     satisfied=len(d.principal_variation)>=d.completed_depth or check.state.terminal_status.is_terminal
     if full:assert satisfied
     row['calls'].append(dict(full_pv=full,pvs=pvs,depth=depth,repeat=repeat,seconds=elapsed,full_contract=satisfied,decision=record_value(d)));write_record(out,r)
     print(old['base'],full,pvs,depth,repeat,d.completed_depth,d.score,len(d.principal_variation),satisfied,elapsed,flush=True)
r['complete']=True;write_record(out,r)
