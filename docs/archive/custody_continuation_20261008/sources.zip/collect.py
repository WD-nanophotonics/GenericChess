"""Small current findings, isolated exact sources/results, physical recovery check."""
import sys,json,hashlib,zipfile,tempfile,collections,re
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/custody_continuation_20261008';a.mkdir(exist_ok=True)
out=ROOT/'docs/research/data/custody_continuation_20261008.json';assert not out.exists()
def read(n):return json.loads((p/n).read_bytes())
kernel=read('kernel-completed.json');mc=read('exchangeable-custody.json');virtual=read('surviving-service.json')
raw_files=[f for f in sorted(p.glob('*.json')) if '-private-' not in f.name]
report=dict(complete=True,scope='Explicit finite tasks and optional search-output contract; no material-price/default/strength promotion',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),sources={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in raw_files},immediate=dict(cost=kernel['cost'],cases=[dict(base=c['base'],best_drop_service=c['best_drop_service'],drops=[dict(square=d['square'],reply_count=len(d['replies']),worst=d['worst_defender_service'],uniform_reply=d['uniform_reply_service'],returns=sum(x['returned_original_owner_hand'] for x in d['replies'])) for d in c['drops']]) for c in kernel['cases']]),native_zero_witnesses=dict(count=len(read('native-witness-completed.json')['rows']),seconds=read('native-witness-completed.json')['seconds']),two_turn=[{k:v for k,v in x.items() if k!='first_reply_checks'} for x in read('two-turn.json')['rows']],stochastic=dict(declaration=mc['declaration'],seconds=mc['seconds'],cells=[dict(base=c['base'],square=c['square'],trajectories=len(c['trajectories']),reward_histogram=dict(collections.Counter(x['reward'] for x in c['trajectories'])),reward_sum=sum(x['reward'] for x in c['trajectories']),plies=sum(x['plies'] for x in c['trajectories']),events=dict(collections.Counter(e['kind'] for x in c['trajectories'] for e in x['events']))) for c in mc['cells']]),projection=[dict(base=x['base'],projection=x['left']['projection'],left_drop_count=x['left']['legal_drop_count'],right_drop_count=x['right']['legal_drop_count'],different_destination_sets=x['left']['legal_drops']!=x['right']['legal_drops']) for x in read('projection-witness.json')['pairs']],survivor=dict(declaration=virtual['declaration'],seconds=virtual['seconds'],roots=sum(x['roots'] for x in virtual['rows']),edges=sum(x['virtual_edges'] for x in virtual['rows']),means={mode:sum(Fraction(x['net_mean']) for row in virtual['rows'] if row['actor']==mode for x in row['orders'])/8 for mode in 'QRBN'},strata=[dict(actor=x['actor'],opponent=x['opponent'],orders=[{k:v for k,v in y.items() if k!='per_root'} for y in x['orders']]) for x in virtual['rows']],independent_checks=read('survivor-oracle.json')['checks']))
report['search_controls']={}
for name in ('returned-history-search.json','full-pv-ablation.json','full-pv-chain-ablation.json','recombined-full-pv.json','tt-chain-feasibility.json'):
 d=read(name);report['search_controls'][name]=dict(declaration=d['declaration'],complete=d['complete'],rows=d.get('rows'),calls=d.get('calls'),references=d.get('references'))
# State/history is already in raw evidence; do not duplicate large roots live.
for row in report['search_controls']['returned-history-search.json']['rows']:
 for k in ('state','history','board_values','hand_values'):row.pop(k,None)
write_record(out,report)
index=dict(original_directory='.local_agent/custody-kernel-20261008',current_result=dict(path=str(out.relative_to(ROOT)).replace('\\','/'),sha256=hashlib.sha256(out.read_bytes()).hexdigest()),archives={},dependencies=[])
for archive,files in (('sources.zip',[f for f in sorted(p.glob('*.py')) if '-private-' not in f.name]),('raw.zip',raw_files)):
 target=a/archive;assert not target.exists();members={}
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f in files:
   body=f.read_bytes();assert not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',body) and not re.search(rb'\b[UT][0-9A-Z]{10,}\b',body) and (b'-----BEGIN '+b'PRIVATE KEY-----') not in body
   z.writestr(f.name,body);members[f.name]=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
 with tempfile.TemporaryDirectory(prefix='extract-',dir=p) as td,zipfile.ZipFile(target) as z:
  assert z.testzip() is None;z.extractall(td)
  for n,m in members.items():assert hashlib.sha256((Path(td)/n).read_bytes()).hexdigest()==m['sha256']
 index['archives'][archive]=dict(sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=members,physically_extracted_rehashed=True)
for archive,n in (('sources.zip','census.py'),('raw.zip','shogi-custody-nifu-safe.json'),('raw.zip','static-native-control.json'),('raw.zip','recombined-history-completed.json')):
 target=ROOT/'docs/archive/joint_service_20261008'/archive
 with zipfile.ZipFile(target) as z:body=z.read(n)
 index['dependencies'].append(dict(archive=str(target.relative_to(ROOT)).replace('\\','/'),member=n,sha256=hashlib.sha256(body).hexdigest()))
# Every raw producer and pinned search/tuning version must resolve to exact bytes.
available={m['sha256'] for ar in index['archives'].values() for m in ar['members'].values()}
available.update(x['sha256'] for x in index['dependencies'])
available.update(hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/tuning.py'))
for f in raw_files:
 d=json.loads(f.read_bytes())
 for pin in [d.get('producer_sha256')]+list(d.get('source_pins',{}).values()):
  if pin:assert pin in available,(f.name,pin)
index['producer_and_source_pins_resolved']=True;write_record(a/'index.json',index)
print('Verified archive members',sum(len(x['members']) for x in index['archives'].values()),'live bytes',out.stat().st_size)
