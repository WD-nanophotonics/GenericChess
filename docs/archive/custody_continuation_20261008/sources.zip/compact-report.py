"""Keep current findings small; detailed decisions remain in verified archives."""
import sys,json,hashlib,zipfile,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/custody_continuation_20261008';out=ROOT/'docs/research/data/custody_continuation_20261008.json';raw=out.read_bytes();r=json.loads(raw);draft=p/'collection-draft.json';assert not draft.exists();draft.write_bytes(raw)
def compact(d):
 return {k:d[k] for k in ('action','score','completed_depth','nodes','qnodes','tt_hits','termination_reason') if k in d}|{'pv_length':len(d.get('principal_variation',[]))}
for control in r['search_controls'].values():
 for row in control.get('rows') or []:
  for call in row.get('cells',[])+row.get('calls',[]):call['decision']=compact(call['decision'])
  if 'search_decision' in row:row['search_decision']=compact(row['search_decision'])
 for call in control.get('calls') or []:call['decision']=compact(call['decision'])
r['derivation_sha256']=hashlib.sha256(raw).hexdigest();r['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(out,r)
index=json.loads((a/'index.json').read_bytes())
for archive,f in (('sources.zip',Path(__file__)),('raw.zip',draft)):
 target=a/archive
 with zipfile.ZipFile(target,'a',zipfile.ZIP_DEFLATED) as z:assert f.name not in z.namelist();body=f.read_bytes();z.writestr(f.name,body)
 entry=index['archives'][archive];entry['members'][f.name]=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest());entry['sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
 with tempfile.TemporaryDirectory(prefix='verify-',dir=p) as td,zipfile.ZipFile(target) as z:
  assert z.testzip() is None;z.extractall(td)
  for name,m in entry['members'].items():assert hashlib.sha256((Path(td)/name).read_bytes()).hexdigest()==m['sha256']
index['current_result']['sha256']=hashlib.sha256(out.read_bytes()).hexdigest();write_record(a/'index.json',index)
print('Current bytes',out.stat().st_size,'archive members',sum(len(x['members']) for x in index['archives'].values()))
