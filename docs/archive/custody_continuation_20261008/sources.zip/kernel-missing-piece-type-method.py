"""Finite signed custody service, all replies; no unknown material prices."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;p.mkdir(exist_ok=True);out=p/'kernel.json';assert not out.exists()
source_path=ROOT/'.local_agent/joint-exposure-20261008/shogi-custody-nifu-safe.json';b=source_path.read_bytes();source=json.loads(b)
r=dict(complete=False,declaration=dict(question='Does a captured-tag service contrast survive all legal defender replies rather than one fixed reply?',design='Same qualified40-entity matched G/TP roots and actual three-ply capture prefix. Black holds captured baseG/P. For every legal tagged drop, White minimizes whether Black can next legally capture an ordinary White entity with that tag; Black maximizes over its tag actions. Other Black actions are outside this one-tag task. Terminal game states and absent tag yield zero within the truncated service task; terminal outcomes and returned owner0 hand state retained separately.',payoff='One unit per final ordinary tagged capture for current owner1, hence -1 for original owner0. Tag loss itself has no -1 inventory penalty. No anchor value, fitted price, gamma choice, game-utility or infinite-lifetime claim. Own-tag recapture is a horizon frontier, not absorbing ownership loss.',policies='Report all drop values: adversarial best-drop max_min service and descriptive uniform legal-drop mean, separately from common-drop population. No success threshold chosen from results.',cost='Finite48drop population xall legal White replies xnext Core tagged actions, one process. Progress per drop; count real transitions/legal calls/time/bytes, no enlarged game search or worker.'),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(b).hexdigest(),cases=[],cost=dict(transitions=0,legal_calls=0,reply_states=0));write_record(out,r);start=time.perf_counter()
def actions(state,c):
 r['cost']['legal_calls']+=1
 return () if state.terminal_status.is_terminal else tuple(legal_actions(state,c))
def advance(state,a,c):r['cost']['transitions']+=1;return apply_action(state,a,c)
def coords(a):return ((a.from_square.file,a.from_square.rank),(a.to_square.file,a.to_square.rank),a.promotion_target_id) if isinstance(a,SemanticBoardMove) else None
for i,base in enumerate(('G','P')):
 flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
 c=compile_ruleset_for_execution(ruleset_from_dict(source['rows'][i]['ruleset']));state=initial_state(c);prefix=[]
 for start_coord,end_coord in (((0,2),(0,3)),((3,5),(3,3)),((0,3),(0,4))):
  a=next(a for a in actions(state,c) if coords(a)==(start_coord,end_coord,None));prefix.append(a);state=advance(state,a,c)
 assert state.position.hands[1].count(base)==1
 drops=sorted((a for a in actions(state,c) if isinstance(a,SemanticDropMove) and a.base_type_id==base),key=str)
 case=dict(base=base,definition=source['rows'][i]['ruleset'],prefix=record_value(prefix),pre_drop_state=record_value(state),drops=[]);r['cases'].append(case);write_record(out,r)
 for drop in drops:
  placed=advance(state,drop,c);square=drop.to_square;index=square.file+9*square.rank
  assert placed.position.board[index].owner==1 and placed.position.board[index].base_type_id==base
  replies=actions(placed,c);row=dict(drop=record_value(drop),square=[square.file,square.rank],after_drop_terminal=record_value(placed.terminal_status),replies=[])
  for reply in sorted(replies,key=str):
   after=advance(placed,reply,c);r['cost']['reply_states']+=1;tag=after.position.board[index]
   live=tag is not None and tag.owner==1 and tag.base_type_id==base
   returned=not live and isinstance(reply,SemanticBoardMove) and reply.to_square==square
   if returned:assert after.position.hands[0].count(base)==placed.position.hands[0].count(base)+1
   tag_actions=[a for a in actions(after,c) if live and isinstance(a,SemanticBoardMove) and a.from_square==square]
   captures=[a for a in tag_actions if (target:=after.position.board[a.to_square.file+9*a.to_square.rank]) is not None and target.owner==0 and not c.piece_type(target.current_type_id).is_anchor]
   row['replies'].append(dict(action=record_value(reply),tag_live=live,returned_original_owner_hand=returned,terminal=record_value(after.terminal_status),tag_actions=record_value(tag_actions),ordinary_captures=record_value(captures),service=int(bool(captures))))
  row['worst_defender_service']=min((x['service'] for x in row['replies']),default=0)
  row['uniform_reply_service']=Fraction(sum(x['service'] for x in row['replies']),len(row['replies'])) if row['replies'] else Fraction(0)
  case['drops'].append(row);r['cost']['seconds']=time.perf_counter()-start;write_record(out,r)
  print(base,row['square'],len(row['replies']),row['worst_defender_service'],str(row['uniform_reply_service']),flush=True)
 case['best_drop_service']=max((x['worst_defender_service'] for x in case['drops']),default=0)
 case['uniform_drop_adversarial_reply_service']=Fraction(sum(x['worst_defender_service'] for x in case['drops']),len(drops))
 case['signed_original_owner_best_drop_value']=-case['best_drop_service'];write_record(out,r)
r['complete']=True;r['cost']['seconds']=time.perf_counter()-start;write_record(out,r)
print('Completed',[(x['base'],x['best_drop_service'],str(x['uniform_drop_adversarial_reply_service'])) for x in r['cases']],r['cost'],flush=True)
