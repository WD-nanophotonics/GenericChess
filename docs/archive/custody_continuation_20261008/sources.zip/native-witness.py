"""Independent native zero-service defenses; nonnegative payoff makes one sufficient."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'kernel-completed.json').read_bytes();src=json.loads(raw)
out=p/'native-witness-completed.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,source_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='For every frozen drop choose the first recorded zero-service defender reply. Replay actual prefix/drop through GameSession; independently make the reply in Native and compare exact legal sets. Classify ordinary captures from Native occupancy. Nonnegative binary service plus a legal zero witness certifies min=0; no price or longer-horizon claim.',rows=[]);write_record(out,r)
for case in src['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));n=compile_native_semantic_rules(c);type_map={tid:i for i,tid in enumerate(n.type_ids)};anchors={type_map[x.type_id] for x in c.piece_types if x.is_anchor}
 for row in case['drops']:
  stop=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not stop.get('user_paused')
  s=GameSession(c)
  for recorded in case['prefix']+[row['drop']]:
   a=next(a for a in s.legal_actions() if record_value(a)==recorded);s.submit(a)
  pos=pack_semantic_search_position(c,n,s)
  defense=next(x for x in row['replies'] if x['service']==0)
  packed=next(a for a in guarded_actions(n,pos) if record_value(public_action(n,a))==defense['action'])
  child=make_checked(n,pos,packed);s.submit(public_action(n,packed))
  snap=snapshot(n,child);assert snap['history_exact'] and snap['history_events_exact']
  acts=[public_action(n,a) for a in guarded_actions(n,child)]
  assert set(acts)==set(s.legal_actions())
  x,y=row['square'];cell=snap['board'][x+9*y];live=cell is not None and cell[2]==1 and cell[0]==type_map[case['base']]
  captures=[]
  for a in acts:
   if live and isinstance(a,SemanticBoardMove) and (a.from_square.file,a.from_square.rank)==(x,y):
    target=snap['board'][a.to_square.file+9*a.to_square.rank]
    if target is not None and target[2]==0 and target[1] not in anchors:captures.append(a)
  assert not captures
  r['rows'].append(dict(base=case['base'],square=row['square'],defense=defense['action'],tag_live=live,returned_original_owner_hand=defense['returned_original_owner_hand'],native_legal_count=len(acts),history_length=len(snap['history']),service=0));write_record(out,r)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
print('Verified',len(r['rows']),'native zero defenses',r['seconds'])
