"""Two action cycles in the frozen virtual context: survival has future service."""
import sys,json,time,itertools,hashlib,importlib.util
from pathlib import Path
from fractions import Fraction
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;dependency=ROOT/'.local_agent/joint-exposure-20261008/census.py';spec=importlib.util.spec_from_file_location('frozen_census',dependency);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=p/'surviving-service.json';assert not out.exists();contexts=list(itertools.permutations(range(16),3));start=time.perf_counter()
r=dict(complete=False,declaration='Frozen4x4 ordered source/activeenemy/passiveenemy contexts3360 per mode pair. Each side receives two action opportunities (four plies), either initial order. Ordinary enemy captures+1; own actor capture-1 once. Capture removes entities, absent/no-action actor passes, no anchors/hands/promotion. Minimax optimizes fresh after every action; survivorship keeps next service. Same unit task, not material weights. Depth2 must equal prior producer at every root before any depth4 interpretation. Persist per mode pair;300sec cost checkpoint; retain all strata and signed paired contributions, no phase fitting or outcome-driven extension.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(dependency.read_bytes()).hexdigest(),rows=[]);write_record(out,r)
for a in ('Q','R','B','N'):
 for o in ('Q','R','B','N'):
  flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused')
  ar,er=m.build(4,a),m.build(4,o);edges=0
  @lru_cache(None)
  def value(s,e,v,side,depth):
   global edges
   if depth==0 or s<0:return 0
   if side==0:
    aa=list(m.moves(ar,s,(),tuple(x for x in (e,v) if x>=0)))
    if not aa:return value(s,e,v,1,depth-1)
    choices=[]
    for t in aa:
     edges+=1;gain=int(t==e or t==v);choices.append(gain+value(t,-1 if t==e else e,-1 if t==v else v,1,depth-1))
    return max(choices)
   if e<0:return value(s,e,v,0,depth-1)
   aa=list(m.moves(er,e,() if v<0 else (v,),(s,)))
   if not aa:return value(s,e,v,0,depth-1)
   choices=[]
   for t in aa:
    edges+=1;choices.append(-1 if t==s else value(s,t,v,0,depth-1))
   return min(choices)
  hist=[{i:0 for i in (-1,0,1,2)} for _ in range(2)];nets=[[],[]]
  for s,e,v in contexts:
   old=m.two_orders(ar,er,s,e,v)
   for side in (0,1):
    assert value(s,e,v,side,2)==old[side][0]
    score=value(s,e,v,side,4);hist[side][score]+=1;nets[side].append(score)
  row=dict(actor=a,opponent=o,roots=len(contexts),orders=[dict(order=label,histogram=hist[i],net_mean=Fraction(sum(nets[i]),len(contexts)),per_root=nets[i]) for i,label in enumerate(('actor_first','opponent_first'))],dp_entries=value.cache_info().currsize,virtual_edges=edges);r['rows'].append(row);write_record(out,r);print(a,o,[str(x['net_mean']) for x in row['orders']],edges,flush=True)
  if time.perf_counter()-start>300:raise RuntimeError('declared cost checkpoint reached; incomplete retained')
r.update(complete=True,seconds=time.perf_counter()-start,depth2_mismatches=0,core_transitions=0);write_record(out,r)
print('complete',r['seconds'])
