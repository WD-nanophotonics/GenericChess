"""One changed horizon premise, fixed common drops, equal interruptible cell limits."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import SemanticBoardMove
from generic_chess.core.coordinates import Square
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;raw=(p/'kernel-completed.json').read_bytes();src=json.loads(raw);out=p/'two-turn.json';assert not out.exists()
common=set(map(tuple,(x['square'] for x in src['cases'][0]['drops'])))&set(map(tuple,(x['square'] for x in src['cases'][1]['drops'])))
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Same six common drops; defender moves first, then tagged owner may make two tagged turns separated by any legal defender move. Binary reward is any ordinary tagged capture before horizon; tag recapture/terminal/no tagged actions gives0 within this task, returned-hand continuation excluded explicitly. Owner maximizes, defender minimizes. Existential/universal short circuit is exact on completed cells. Equal2000 Core transitions/10sec per cell, incomplete=unknown, no outcome-driven extension.',rows=[]);write_record(out,r)
class Limit(Exception):pass
for case in src['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));anchors={x.type_id for x in c.piece_types if x.is_anchor}
 def acts(s):return () if s.terminal_status.is_terminal else tuple(legal_actions(s,c))
 def replay(s,v):return apply_action(s,next(a for a in acts(s) if record_value(a)==v),c)
 for row in sorted((x for x in case['drops'] if tuple(x['square']) in common),key=lambda x:x['square']):
  stop=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not stop.get('user_paused')
  s=initial_state(c)
  for a in case['prefix']+[row['drop']]:s=replay(s,a)
  count=0;calls=0;start=time.perf_counter();certificate=[]
  def advance(s,a):
   global count
   if count>=2000 or time.perf_counter()-start>=10:raise Limit
   count+=1;return apply_action(s,a,c)
  def owner(s,square,remaining):
   global calls
   calls+=1
   if remaining==0 or s.terminal_status.is_terminal:return False
   tag=s.position.board[square.file+9*square.rank]
   if tag is None or tag.owner!=1 or tag.base_type_id!=case['base']:return False
   aa=[a for a in acts(s) if isinstance(a,SemanticBoardMove) and a.from_square==square]
   # Capture-first ordering changes cost only, not truth conditions.
   for a in aa:
    t=s.position.board[a.to_square.file+9*a.to_square.rank]
    if t is not None and t.owner==0 and t.current_type_id not in anchors:return True
   if remaining==1:return False
   for a in aa:
    if defender(advance(s,a),a.to_square,remaining-1):return True
   return False
  def defender(s,square,remaining):
   global calls
   calls+=1
   aa=acts(s)
   if not aa:return False
   for a in sorted(aa,key=str):
    if not owner(advance(s,a),square,remaining):return False
   return True
  try:
   # Retain each inspected first reply and truth result; zero stops immediately.
   force=True
   for a in sorted(acts(s),key=str):
    value=owner(advance(s,a),Square(*row['square']),2)
    certificate.append(dict(reply=record_value(a),force=value))
    if not value:force=False;break
   result=dict(complete=True,force_capture=force)
  except Limit:result=dict(complete=False,force_capture=None)
  result.update(base=case['base'],square=row['square'],transitions=count,calls=calls,seconds=time.perf_counter()-start,first_reply_checks=certificate)
  r['rows'].append(result);write_record(out,r);print(case['base'],row['square'],result['complete'],result['force_capture'],count,result['seconds'],flush=True)
r['complete']=True;write_record(out,r)
