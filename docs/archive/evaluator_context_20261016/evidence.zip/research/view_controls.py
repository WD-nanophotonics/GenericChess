from pathlib import Path
import sys,json,time,importlib.util,statistics
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from scripts.research_record import record_value,write_record
from generic_chess.native import SemanticSearchEngine,semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from test_native_q_history_deferral import cycle,checked_replay
from test_native_pending_continuation import session_after
from phase19c1_native_semantic_fixtures import semantic_corpus
spec=importlib.util.spec_from_file_location('qualview._native_core',P/'view_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
d=json.loads((P/'control-results.json').read_bytes());corpus=dict(semantic_corpus());native={};start=time.perf_counter();states=[];histories=[];queries=[]
def stopped():
 for n in('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if z.get('user_paused')or z.get('stopped'):raise RuntimeError('USER_STOP')
 assert time.perf_counter()-start<180
for row in d['mechanisms']:
 stopped();name=row['fixture'];c=corpus[name]
 if name not in native:native[name]=compile_native_semantic_rules(c,backend_module=m)
 nr=native[name];s=GameSession.replay(c,deserialize_game_record(json.dumps(row['game_record'])));assert record_value(s.state)==row['state'];np=pack_semantic_search_position(c,nr,s);before=sem.snapshot(nr,np);v=sem.dynamic_features(nr,np);assert list(v)==row['features'];assert sem.snapshot(nr,np)==before;states.append(dict(fixture=name,seed=row['seed'],ply=row['ply'],features=v,full_root_restored=True))
for prefix in(0,32,128,512,1023,1024):
 stopped();s=cycle(max_ply=1024,repetition=10000,prefix=prefix);c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','view')};packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};values={};errors={};timings={a:[]for a in nrs};before=record_value(s.state)
 for rep in range(32):
  for a in(('normal','view')if rep%2==0 else('view','normal')):
   tt=time.perf_counter()
   try:values[a]=sem.dynamic_features(nrs[a],packs[a])
   except Exception as exc:errors[a]=type(exc).__name__+': '+str(exc)
   timings[a].append(time.perf_counter()-tt)
 assert values.get('normal')==values.get('view');assert errors.get('normal')==errors.get('view');assert record_value(s.state)==before
 histories.append(dict(prefix=prefix,history_entries=len(s.state.history),features=values,errors=errors,timings=timings,median_ratio=statistics.median(timings['view'])/statistics.median(timings['normal'])));print('VIEW_HISTORY',prefix,histories[-1]['median_ratio'],flush=True)
s=session_after(('e2e4','d7d5','f1b5','c7c6'));c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','view')};before=record_value(s.state)
for q in(0,1,4):
 for tt in(0,1):
  engines={a:SemanticSearchEngine(c,nr,dynamic_values=(2,3,5),tt_megabytes=tt,ordering_cache_enabled=False)for a,nr in nrs.items()}
  for rep in range(2):
   pair=[]
   for a in(('normal','view')if rep==0 else('view','normal')):
    stopped();t=time.perf_counter();r=engines[a].search(s,SearchLimits(max_depth=2,max_nodes=256,max_time_seconds=None,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0),root_window_pruning=True);z=dict(kind='ACTUAL_QUERY',fixture='actual_pending',q=q,tt=tt,rep=rep,arm=a,result=record_value(r),caller_seconds=time.perf_counter()-t);checked_replay(s,nrs[a],r);assert record_value(s.state)==before;queries.append(z);pair.append(z)
   assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
write_record(P/'view-control-results.json',dict(complete=True,states=states,histories=histories,queries=queries,seconds=time.perf_counter()-start,scope='280receiptbound Corefeature positions replayed into private view image;6actualhistory lengths inclfullcapacity error;24actual PENDING q0/1/4 TT0/1 cold/warm fixednode queries and full checked PV history. No new games/fit/AUX execution.'));print('VIEW_CONTROL_DONE',len(states),len(queries),time.perf_counter()-start,flush=True)
