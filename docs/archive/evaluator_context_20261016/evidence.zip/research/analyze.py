from pathlib import Path
import json,statistics,random,collections
P=Path('.local_agent/eval-revisit-20261016')
def read(n):return json.loads((P/n).read_bytes())
def interval(v):
 if len(v)<2:return None
 rng=random.Random(20261016);a=sorted(statistics.median(rng.choices(v,k=len(v)))for _ in range(4000));return[a[99],a[3899]]
def panel(d,arms):
 groups={};counts=collections.Counter();missing=[]
 for r in d['rows']:
  counts[r['kind']]+=1
  if r['kind']!='ACTUAL_QUERY':missing.append(r);continue
  counts['arm_'+r['arm']]+=1;groups.setdefault((r['seed'],r['board'],r['profile'],r['rep']),{})[r['arm']]=r
 out=[];bad=[];pairwise=[]
 for board in(4,8,12,16):
  for profile in('static','dynamic235'):
   pp=[(k,v)for k,v in groups.items()if k[1:3]==(board,profile)];joint=[];completion=collections.Counter();families={};rawratios=[]
   for key,g in pp:
    bit=''.join('1'if a in g and g[a]['result']['completed_depth']==4 else'0'for a in arms);completion[bit]+=1
    if bit!='1'*len(arms):continue
    values=[{k:v for k,v in g[a]['result'].items()if k!='elapsed_seconds'}for a in arms]
    if not all(v==values[0]for v in values):bad.append(list(key))
    costs=[g[a]['caller_seconds']for a in arms];metrics={a+'/'+arms[0]:costs[i]/costs[0]for i,a in enumerate(arms)if i}
    if len(arms)==4:
     metrics.update(D_over_C=costs[3]/costs[2],B_minus_A_seconds=costs[1]-costs[0],D_minus_C_seconds=costs[3]-costs[2],interaction_seconds=(costs[3]-costs[2])-(costs[1]-costs[0]),interaction_ratio=(costs[3]/costs[2])/(costs[1]/costs[0]))
    families.setdefault(key[0],[]).append(metrics);joint.append(dict(key=list(key),costs=dict(zip(arms,costs)),metrics=metrics));rawratios.extend(metrics[a+'/'+arms[0]]for a in arms[1:])
   for numerator in arms[1:]:
    pairfamilies={};patterns=collections.Counter();pairbad=[]
    for key,g in pp:
     a,b=arms[0],numerator;bit=''.join('1'if arm in g and g[arm]['result']['completed_depth']==4 else'0'for arm in(a,b));patterns[bit]+=1
     if bit!='11':continue
     if{k:v for k,v in g[a]['result'].items()if k!='elapsed_seconds'}!={k:v for k,v in g[b]['result'].items()if k!='elapsed_seconds'}:pairbad.append(list(key))
     pairfamilies.setdefault(key[0],[]).append(g[b]['caller_seconds']/g[a]['caller_seconds'])
    vv=[statistics.median(v)for v in pairfamilies.values()];pairwise.append(dict(board=board,profile=profile,numerator=numerator,denominator=arms[0],completion_patterns=dict(patterns),joint_families=len(vv),family_medians=vv,family_median=statistics.median(vv)if vv else None,descriptive_family_interval=interval(vv),non_time_mismatches=pairbad))
   summary={}
   if families:
    for metric in next(iter(families.values()))[0]:
     vals=[statistics.median(row[metric]for row in entries)for entries in families.values()];summary[metric]=dict(family_median=statistics.median(vals),family_medians=vals,descriptive_family_interval=interval(vals))
   out.append(dict(board=board,profile=profile,total_groups=len(pp),joint_complete=len(joint),complete_patterns=dict(completion),joint_families=len(families),metrics=summary,maximum_joint_pair_ratio=max(rawratios,default=None),joint=joint))
 return dict(counts=dict(counts),missing=missing,panels=out,pairwise=pairwise,all_non_time_mismatches=bad,whole_internal_seconds=d['seconds'],scope='Completionconditional within sameprofile; everycensor/failed/notstarted retained. Smallnfamily bootstrap descriptive, notpopulation/strength. No reset/engineconstruction charged in perqueryAPI timer; batchdoescharge both. Cache lifecycle/copyallocation costs therefore not fully isolated byqueryratio.')
out=dict(complete=True,count_panel=read('results.json'),cache_pilot=panel(read('cache-results.json'),['normal','private_cache']),view_components=[dict(seed=r['seed'],board=r['board'],median_ratio=r['median_ratio'])for r in read('view-component-results.json')['rows']],history_cache_ratios=[dict(prefix=r['prefix'],ratio=statistics.median(r['timings']['cache'])/statistics.median(r['timings']['normal']),cache=r['cache'],errors=r['errors'])for r in read('control-results.json')['histories']],history_livecopy_ratios=[dict(prefix=r['prefix'],ratio=r['median_ratio'],errors=r['errors'])for r in read('view-control-results.json')['histories']],transport_history_sensitive=[dict(label=r['label'],features=r['features'],cache=r['cache'])for r in read('control-results.json')['transport']],private_cache_not_production_ready=['Processglobal serial harness table and explicitPythonreset are not querylocal/threadsafe lifecycle.','OriginalperqueryAPI clocks exclude reset/free and engineconstruction; wholebatch includes them.','Saturation/longhistory regressions retained; no normalization or largerkeycapacity adoption.'])
if(P/'transfer-results.json').exists():
 d=read('transfer-results.json');plan=read('transfer-plan.json');out['transfer']=panel(d,['A_normal','B_livecopy','C_cache','D_both']);seen={(r['seed'],r['profile'],r['rep'],r['arm'])for r in d['rows']};rootreason={r['seed']:r['kind']for r in d['roots']};missing=[dict(seed=c['seed'],board=c['board'],profile=p,rep=rep,arm=a,kind='NO_QUERY_RECEIPT',reason=rootreason.get(c['seed'],'MISSING_ROOT_UNKNOWN'))for c in plan['cases']for p in plan['profiles']for rep in range(plan['repetitions'])for a in plan['arms']if(c['seed'],p,rep,a)not in seen];acq=collections.Counter();
 for f in(P/'transfer-roots').glob('*.json'):
  dd=json.loads(f.read_bytes());acq['walks']+=1;acq['plies']+=len(dd['game_record']['actions'])
  for a in dd['game_record']['actions']:
   acq['drops']+=int(a['kind']=='semantic_drop');acq['promotions']+=int(a.get('promotion_target_id')is not None)
 out['coverage']=dict(planned_transfer_slots=plan['planned_slots'],actual_transfer_rows=len(d['rows']),actual_transfer_queries=sum(r['kind']=='ACTUAL_QUERY'for r in d['rows']),explicit_missing_slots=missing,root_kinds=dict(collections.Counter(r['kind']for r in d['roots'])),actual_acquisition=dict(acq),retained_search_receipts=320+sum(r['kind']=='ACTUAL_QUERY'for r in d['rows']),additional_first_harness_queries_without_saved_results=8,new_evaluation_games=0,research_fits=0,scope='Missingtail slots enumerated from frozenplan, never fabricated outcomes; first8failed-harness results unavailable, excluded fromretained/source replay.')
(P/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k in('history_cache_ratios','history_livecopy_ratios')},indent=2));print('CACHE',[(r['board'],r['profile'],r['joint_complete'],r['metrics'])for r in out['cache_pilot']['panels']]);print('TRANSFER_COMPLETE','transfer'in out)
