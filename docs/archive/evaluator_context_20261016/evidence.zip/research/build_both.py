from pathlib import Path
import sys,sysconfig,subprocess,time,json,hashlib,shutil
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';S=P/'both-source';S.mkdir(exist_ok=False)
for f in(P/'cache-source').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
for n in('native_semantic_runtime.c','native_semantic_runtime.h'):shutil.copyfile(P/'view-source'/n,S/n)
p=S/'native_module.c';s=p.read_text();a=s.index('static int gc_private_raw_dynamic_feature_vector(');b=s.index('static int gc_semantic_dynamic_feature_vector(',a);part=s[a:b];assert part.count('        GCSemanticPosition view = *position;')==1;part=part.replace('        GCSemanticPosition view = *position;','        GCSemanticPosition view;\n        gc_semantic_runtime_copy_live_position(&view,position);');s=s[:a]+part+s[b:];p.write_bytes(s.encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/'both_native_core.pyd')];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);out=dict(returncode=r.returncode,seconds=time.perf_counter()-t,stderr=r.stderr.decode(errors='replace'),source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()});(P/'both-build-private.json').write_text(json.dumps(out,indent=2)+'\n');print(r.returncode,out['seconds'],out['stderr']);assert r.returncode==0
