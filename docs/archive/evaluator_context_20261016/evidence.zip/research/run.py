from pathlib import Path
import sys,json,time,importlib.util,traceback,hashlib
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
spec=importlib.util.spec_from_file_location('revisit._native_core',P/'counter_native_core.pyd');counter=importlib.util.module_from_spec(spec);spec.loader.exec_module(counter)
plan=json.loads((P/'plan.json').read_bytes());start=time.perf_counter();rows=[]
def stopped():
 for n in('rollout','advisor','slack'):
  d=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('user_paused')or d.get('stopped'):raise RuntimeError('USER_STOP')
with(P/'queries.jsonl').open('x',encoding='utf-8')as out:
 for case in plan['cases']:
  d=json.loads((R/'.local_agent/api-ready-20261016/roots'/f"{case['seed']}.json").read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in v.board_value_by_type.items()};hv={k:int(round(v))for k,v in v.hand_value_by_base_type.items()};nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=counter)))for a in plan['arms']};before=record_value(s.state)
  for profile in plan['profiles']:
   for rep in range(plan['repetitions']):
    pair=[]
    for arm in(plan['arms']if rep==0 else list(reversed(plan['arms']))):
     stopped();z=dict(**case,profile=profile,rep=rep,arm=arm)
     if time.perf_counter()-start>plan['whole_seconds']:z.update(kind='WHOLE_CAP_NOT_STARTED_UNKNOWN');rows.append(z);continue
     e=SemanticSearchEngine(c,nrs[arm],board_values=bv,hand_values=hv,dynamic_values=(2,3,5)if profile=='dynamic235'else None,tt_megabytes=0,ordering_cache_enabled=False)
     if arm=='counter':counter.private_revisit(True)
     t=time.perf_counter()
     try:
      r=e.search(s,SearchLimits(max_depth=plan['depth'],max_nodes=plan['nodes'],max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-t;z.update(kind='ACTUAL_QUERY',caller_seconds=elapsed,result=record_value(r),root_restored=record_value(s.state)==before);assert z['root_restored']
      if arm=='counter':z['counter']=counter.private_revisit(False)
     except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=str(exc),traceback=traceback.format_exc())
     rows.append(z);pair.append(z);out.write(json.dumps(z)+'\n');out.flush()
    if all(z['kind']=='ACTUAL_QUERY'for z in pair)and len(pair)==2:
     same={k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'};assert same
    print('PAIR',case['seed'],profile,rep,[(z['arm'],z.get('caller_seconds'),z.get('counter'))for z in pair],flush=True)
write_record(P/'results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,queries=len(rows),scope=plan['scope']));print('DONE',len(rows),time.perf_counter()-start,flush=True)
