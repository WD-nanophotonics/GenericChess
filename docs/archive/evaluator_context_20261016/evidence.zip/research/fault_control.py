from pathlib import Path
import sys,sysconfig,subprocess,time,json,shutil,importlib.util,hashlib
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';sys.path[:0]=[str(R/'tests'),str(R)]
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import expected_snapshot
from generic_chess.native import semantic as sem
from scripts.research_record import write_record
import phase19b3_s4_fixtures as f
rows=[];builds=[];start=time.perf_counter()
for arm in('view','cache'):
 S=P/(arm+'-fault-source');S.mkdir(exist_ok=False)
 for z in(P/(arm+'-source')).iterdir():
  if z.suffix in('.c','.h'):shutil.copyfile(z,S/z.name)
 p=S/'native_module.c';s=p.read_text();mark='static int gc_semantic_dynamic_feature_vector(';a=s.index(mark,s.index(mark)+1);b=s.index('static int gc_semantic_compact_residual(',a);part=s[a:b].replace('gc_semantic_dynamic_feature_vector(','gc_test_dynamic_impl(',1);wrapper='''
int gc_test_feature_fault=0,gc_test_feature_scope=0,gc_test_feature_failures=0;
static int gc_semantic_dynamic_feature_vector(const GCSemanticRules *r,const GCSemanticPosition *p,int out[3]) {
 gc_test_feature_scope=1;int ok=gc_test_dynamic_impl(r,p,out);gc_test_feature_scope=0;return ok;
}
static PyObject *gc_test_feature_set(PyObject *self,PyObject *args) {
 (void)self;if(!PyArg_ParseTuple(args,"p",&gc_test_feature_fault))return NULL;gc_test_feature_failures=0;Py_RETURN_NONE;
}
static PyObject *gc_test_feature_get(PyObject *self,PyObject *args) {
 (void)self;(void)args;return PyLong_FromLong(gc_test_feature_failures);
}
''';s=s[:a]+part+wrapper+s[b:];mark='    {"semantic_dynamic_features", gc_semantic_dynamic_features, METH_VARARGS,';s=s.replace(mark,'    {"test_feature_set",gc_test_feature_set,METH_VARARGS,"privatefault"},\n    {"test_feature_failures",gc_test_feature_get,METH_NOARGS,"privatecount"},\n'+mark);p.write_bytes(s.encode());p=S/'native_semantic_runtime.c';s=p.read_text();mark='static int semantic_has_s3_reply(const GCSemanticRules *r, const GCSemanticPosition *position) {';assert s.count(mark)==1;s=s.replace(mark,mark+'\n    extern int gc_test_feature_fault,gc_test_feature_scope,gc_test_feature_failures;\n    if(gc_test_feature_fault && gc_test_feature_scope){gc_test_feature_failures++;return -1;}');p.write_bytes(s.encode());outp=P/(arm+'_fault_native_core.pyd');cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(z)for z in sorted(S.glob('*.c'))],'-o',str(outp)];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);builds.append(dict(arm=arm,returncode=r.returncode,seconds=time.perf_counter()-t,stderr=r.stderr.decode(errors='replace'),source_hashes={z.name:hashlib.sha256(z.read_bytes()).hexdigest()for z in S.iterdir()}));assert r.returncode==0,r.stderr;spec=importlib.util.spec_from_file_location(arm+'fault._native_core',outp);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 for name,builder,pos in [('multiple',f.multiple_replies_ruleset,f.multiple_replies_position),('aux',f.full_child_state_ruleset,f.full_child_state_position)]:
  c=compile_semantic_ruleset(builder());p=pos(c.support);nr=compile_native_semantic_rules(c,backend_module=m);pay=dict(expected_snapshot(p,nr,c),ply=0);pay['board']=[None if z is None else list(z)for z in pay['board']];pay['hands']=[list(z)for z in pay['hands']];np=sem.pack_position(nr,pay);before=sem.snapshot(nr,np)
  if arm=='cache':m.private_cache(True)
  m.test_feature_set(True)
  try:value=sem.dynamic_features(nr,np);error=None
  except Exception as exc:value=None;error=type(exc).__name__+': '+str(exc)
  failures=m.test_feature_failures();m.test_feature_set(False);assert value is None and error=='RuntimeError: semantic dynamic feature extraction failed'and failures>0
  after_failure=m.private_cache(False)if arm=='cache'else None;recovered=sem.dynamic_features(nr,np);after_recover=m.private_cache(False)if arm=='cache'else None;repeat=sem.dynamic_features(nr,np);after_repeat=m.private_cache(False)if arm=='cache'else None;assert recovered==repeat;assert before==sem.snapshot(nr,np)
  if arm=='cache':assert after_failure['hits']==after_recover['hits']==0 and after_repeat['hits']==1
  rows.append(dict(arm=arm,fixture=name,fault_value=value,fault_error=error,injected_nested_failures=failures,recovered=recovered,repeat=repeat,after_failure=after_failure,after_recover=after_recover,after_repeat=after_repeat,root_restored=True));print(rows[-1],flush=True)
write_record(P/'fault-results.json',dict(complete=True,rows=rows,builds=builds,seconds=time.perf_counter()-start,scope='Actual controlled nested S3 negative status, not OS failure. Fresh cold cache failure must not mark vectorvalid; samekey recovery and hit verified. Private faultcontrols not production. No games/fits/AUX execution.'))
