from pathlib import Path
import json,sys,sysconfig,subprocess,time,hashlib,shutil
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';S=P/'cache-source';S.mkdir(exist_ok=False)
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
counter=(P/'counter.inc').read_text();key=counter[counter.index('static size_t rv_key('):counter.index('static void rv_observe(')]
helper='''/* Private feasibility prototype, serial single-query lifetime only. */
#define RC_CAP 4096
#define RC_BYTES 8388608
typedef struct{uint64_t hash;size_t size;unsigned char *key;int vector[3];int valid;}RCRow;
static RCRow rc_rows[RC_CAP];static unsigned long long rc_calls,rc_hits,rc_miss,rc_full,rc_bytes;static uint64_t rc_key_ns;static int rc_enabled;
'''+key+'''
static RCRow *rc_lookup(const GCSemanticRules *r,const GCSemanticPosition *p){
 uint64_t start=gc_monotonic_ns();unsigned char key[sizeof(GCSemanticPosition)+128];size_t n=rv_key(r,p,key);uint64_t h=UINT64_C(14695981039346656037);for(size_t i=0;i<n;i++){h^=key[i];h*=UINT64_C(1099511628211);}unsigned slot=(unsigned)(h%RC_CAP);RCRow *found=NULL;rc_calls++;
 for(unsigned i=0;i<RC_CAP;i++,slot=(slot+1)%RC_CAP){RCRow *row=&rc_rows[slot];
  if(!row->key){if(rc_bytes+n>RC_BYTES)break;row->key=malloc(n);if(!row->key)break;memcpy(row->key,key,n);row->size=n;row->hash=h;rc_bytes+=n;found=row;break;}
  if(row->hash==h && row->size==n && !memcmp(row->key,key,n)){found=row;break;}
 }
 if(!found)rc_full++;rc_key_ns+=gc_monotonic_ns()-start;return found;
}
static PyObject *gc_private_cache(PyObject *self,PyObject *args){
 (void)self;int reset;if(!PyArg_ParseTuple(args,"p",&reset))return NULL;
 if(reset){for(unsigned i=0;i<RC_CAP;i++){free(rc_rows[i].key);memset(&rc_rows[i],0,sizeof(rc_rows[i]));}rc_calls=rc_hits=rc_miss=rc_full=rc_bytes=rc_key_ns=0;rc_enabled=1;}
 return Py_BuildValue("{sK,sK,sK,sK,sK,sK}","calls",rc_calls,"hits",rc_hits,"misses",rc_miss,"full",rc_full,"stored_key_bytes",rc_bytes,"key_ns",rc_key_ns);
}
'''
c=(S/'native_module.c').read_text();mark='static int gc_semantic_dynamic_feature_vector(';i=c.index(mark);c=c[:i]+helper+'\n'+c[i:];i=c.index(mark,c.index(mark)+1);j=c.index('static int gc_semantic_compact_residual(',i);part=c[i:j];part=part.replace('gc_semantic_dynamic_feature_vector(','gc_private_raw_dynamic_feature_vector(',1);wrapper='''static int gc_semantic_dynamic_feature_vector(const GCSemanticRules *rules,const GCSemanticPosition *position,int out[3]){
 RCRow *row=rc_enabled?rc_lookup(rules,position):NULL;
 if(row&&row->valid){memcpy(out,row->vector,sizeof(row->vector));rc_hits++;return 1;}
 rc_miss++;int ok=gc_private_raw_dynamic_feature_vector(rules,position,out);
 if(ok&&row){memcpy(row->vector,out,sizeof(row->vector));row->valid=1;}return ok;
}
''';c=c[:i]+part+wrapper+c[j:];mark='    {"semantic_dynamic_features", gc_semantic_dynamic_features, METH_VARARGS,';assert c.count(mark)==1;c=c.replace(mark,'    {"private_cache",gc_private_cache,METH_VARARGS,"privatecache"},\n'+mark);(S/'native_module.c').write_bytes(c.encode());(P/'cache-helper.inc').write_text(helper+wrapper)
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/'cache_native_core.pyd')];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);out=dict(returncode=r.returncode,seconds=time.perf_counter()-t,stderr=r.stderr.decode(errors='replace'),source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()});(P/'cache-build-private.json').write_text(json.dumps(out,indent=2)+'\n');print(r.returncode,out['seconds'],out['stderr']);assert r.returncode==0
