from pathlib import Path
import sys,json
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from test_native_pending_continuation import session_after
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
s=session_after(('e2e4','d7d5','f1b5','c7c6'));nr=compile_native_semantic_rules(s.compiled);d=json.loads((P/'control-results.json').read_bytes());rows=[]
for row in d['transport']:
 p=sem.pack_position(nr,row['payload']);rows.append(dict(label=row['label'],key=sem.position_key(nr,p),features=sem.dynamic_features(nr,p)))
assert len({r['key']for r in rows})==1;assert rows[0]['features']!=rows[1]['features']
(P/'transport-key-result.json').write_text(json.dumps(dict(complete=True,rows=rows,scope='ActualsameNativepositionkey, different acceptedhistoryeventtransport/directfeatures. Edited history isnot authenticated legal trajectory; no claim physicalboard alone determines feature semantics.'),indent=2)+'\n');print(json.dumps(rows))
