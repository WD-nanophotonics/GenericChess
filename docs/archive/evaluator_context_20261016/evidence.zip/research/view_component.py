from pathlib import Path
import sys,json,time,importlib.util,statistics
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';O=R/'.local_agent/api-ready-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native import SemanticSearchEngine,semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
spec=importlib.util.spec_from_file_location('view._native_core',P/'view_native_core.pyd');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
start=time.perf_counter();rows=[];queries=[]
def stopped():
 for n in('rollout','advisor','slack'):
  d=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('user_paused')or d.get('stopped'):raise RuntimeError('USER_STOP')
 assert time.perf_counter()-start<180
for f in sorted((O/'roots').glob('*.json')):
 stopped();d=json.loads(f.read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=candidate)))for a in('normal','view')};packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};before={a:sem.snapshot(nr,packs[a])for a,nr in nrs.items()};v={};timing={a:[]for a in nrs}
 for rep in range(64):
  for a in(('normal','view')if rep%2==0 else('view','normal')):
   tt=time.perf_counter();v[a]=sem.dynamic_features(nrs[a],packs[a]);timing[a].append(time.perf_counter()-tt)
 assert v['normal']==v['view'];assert before=={a:sem.snapshot(nr,packs[a])for a,nr in nrs.items()};rows.append(dict(seed=d['seed'],board=d['board'],features=v,timings=timing,median_ratio=statistics.median(timing['view'])/statistics.median(timing['normal'])))
 if d['seed']in(61401,61801):
  vv=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in vv.board_value_by_type.items()};hv={k:int(round(v))for k,v in vv.hand_value_by_base_type.items()}
  for profile in('static','dynamic235'):
   for rep in range(2):
    pair=[]
    for a in(('normal','view')if rep==0 else('view','normal')):
     stopped();e=SemanticSearchEngine(c,nrs[a],board_values=bv,hand_values=hv,dynamic_values=(2,3,5)if profile=='dynamic235'else None,tt_megabytes=0,ordering_cache_enabled=False);tt=time.perf_counter();r=e.search(s,SearchLimits(max_depth=8,max_nodes=512,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);q=dict(seed=d['seed'],board=d['board'],arm=a,profile=profile,rep=rep,result=record_value(r),caller_seconds=time.perf_counter()-tt);pair.append(q);queries.append(q)
    assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
 print('VIEW',d['seed'],rows[-1]['median_ratio'],flush=True)
write_record(P/'view-component-results.json',dict(complete=True,rows=rows,queries=queries,seconds=time.perf_counter()-start,scope='Private exact existing live-prefix copy,16exposed roots2048direct evaluations and16counterfree queries. No completed-depth/quality generalization from512nodes. Product/AUX unchanged.'));print('VIEW_DONE',len(rows),len(queries),time.perf_counter()-start)
