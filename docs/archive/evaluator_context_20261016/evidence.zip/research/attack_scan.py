from pathlib import Path
from copy import copy
import sys,sysconfig,subprocess,time,json,shutil,importlib.util,hashlib
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';S=P/'attack-scan-source';S.mkdir(exist_ok=False)
for f in(P/'attack-cost-source').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
p=S/'native_semantic_runtime.c';s=p.read_text();a=s.index('static int private_semantic_attacked_by(');b=s.index('static int semantic_attacked_by(',a);part=s[a:b]
changes=[('    for (uint16_t si=0; si<r->board_size*r->board_size; si++) {','    for (uint16_t si=0; si<r->board_size*r->board_size; si++) {\n        if(private_attack_scope)private_scan[0]++;'),('        if (actor->current_type >= r->type_count) continue;','        if (actor->current_type >= r->type_count) continue;\n        if(private_attack_scope)private_scan[1]++;'),('            uint16_t pi=r->capture_pattern_indices','            if(private_attack_scope)private_scan[2]++;\n            uint16_t pi=r->capture_pattern_indices'),('                uint16_t gid=pattern->geometry_indices','                if(private_attack_scope)private_scan[3]++;\n                uint16_t gid=pattern->geometry_indices'),('                for(uint16_t ti=0;ti<entry->count;ti++)if(entry->squares[ti]==target_square){','                if(private_attack_scope)private_scan[4]++;\n                for(uint16_t ti=0;ti<entry->count;ti++){if(private_attack_scope)private_scan[5]++;if(entry->squares[ti]==target_square){if(private_attack_scope)private_scan[6]++;')]
for old,new in changes:assert part.count(old)==1,old;part=part.replace(old,new)
old='continue;return 1;}';assert part.count(old)==1;part=part.replace(old,'continue;return 1;}}');s=s[:a]+'extern int private_attack_scope;\nunsigned long long private_scan[7]={0};\n'+part+s[b:];p.write_bytes(s.encode());p=S/'native_module.c';s=p.read_text();mark='static PyObject *gc_private_attack_info(';i=s.index(mark);helper='''extern unsigned long long private_scan[7];
static PyObject *gc_private_scan(PyObject *self,PyObject *args){(void)self;int reset;if(!PyArg_ParseTuple(args,"p",&reset))return NULL;if(reset)memset(private_scan,0,sizeof(unsigned long long)*7);return Py_BuildValue("(KKKKKKK)",private_scan[0],private_scan[1],private_scan[2],private_scan[3],private_scan[4],private_scan[5],private_scan[6]);}
''';s=s[:i]+helper+s[i:];mark='    {"private_attack_info",';assert s.count(mark)==1;s=s.replace(mark,'    {"private_scan",gc_private_scan,METH_VARARGS,"privatecensus"},\n'+mark);p.write_bytes(s.encode());outp=P/'attack_scan_native_core.pyd';cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(outp)];r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr
sys.path.insert(0,str(R));from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,GameSession
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
mods={}
for arm,f in [('view','view_native_core.pyd'),('counter','attack_scan_native_core.pyd')]:
 spec=importlib.util.spec_from_file_location('scan_'+arm+'._native_core',P/f);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
rows=[];start=time.perf_counter();keys=('board_cells','attacker_sources','capture_patterns','geometries','path_entries','target_cells','matching_target_occurrences')
for seed in(61401,62601):
 d=json.loads((R/'.local_agent/api-ready-20261016/roots'/f'{seed}.json').read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);parent=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));child=copy(parent);child.submit(sorted(child.legal_actions(),key=repr)[0]);nrs={a:compile_native_semantic_rules(c,backend_module=m)for a,m in mods.items()}
 for kind,s in(('parent',parent),('first_child',child)):
  assert time.perf_counter()-start<120
  for name in('rollout','advisor','slack'):
   z=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(z.get('user_paused')or z.get('stopped'))
  before=record_value(s.state);packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};mods['counter'].private_scan(True);v={a:sem.dynamic_features(nr,packs[a])for a,nr in nrs.items()};assert v['view']==v['counter'];assert record_value(s.state)==before;counts=dict(zip(keys,mods['counter'].private_scan(False)));cells=c.board_size*c.board_size;memory=len(nrs['view'].type_ids)*2*cells*((cells+7)//8);rows.append(dict(seed=seed,board=c.board_size,state_kind=kind,features=v,scan_counts=counts,conservative_membership_bytes=memory,all_guards_retained=True));print('SCAN',rows[-1],flush=True)
write_record(P/'attack-scan-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()},scope='Fouractualexposed full states, no search/game/model or indeximplementation; next initialization/provenance check not productionbenefit. All source and target occurrence semantics preserved.'))
