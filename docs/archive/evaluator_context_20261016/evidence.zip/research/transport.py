from pathlib import Path
from copy import deepcopy
import sys,json,importlib.util,time
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from test_native_pending_continuation import session_after
from generic_chess.native import semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from scripts.research_record import record_value,write_record
spec=importlib.util.spec_from_file_location('transportcache._native_core',P/'cache_native_core.pyd');cache=importlib.util.module_from_spec(spec);spec.loader.exec_module(cache)
s=session_after(('e2e4','d7d5','f1b5','c7c6'));c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=cache)))for a in('normal','cache')};p=pack_semantic_search_position(c,nrs['normal'],s);payload=sem.snapshot(nrs['normal'],p);base=deepcopy(payload);changed=deepcopy(payload);changed['history_events']=list(changed['history_events']);changed['history_events'][3]=(changed['history_events'][3][0],False);cache.private_cache(True);transport=[]
for pay in(base,changed):
 pay['board']=[None if a is None else list(a)for a in pay['board']];pay['hands']=[list(a)for a in pay['hands']];pay['history_events']=[list(a)for a in pay['history_events']]
for label,pay in(('actual_pending',base),('edited_history_event',changed),('actual_pending_again',base)):
 v={a:sem.dynamic_features(nr,sem.pack_position(nr,pay))for a,nr in nrs.items()};assert v['normal']==v['cache'];transport.append(dict(label=label,features=v,cache=cache.private_cache(False),payload=record_value(pay)))
assert transport[0]['features']['normal']!=transport[1]['features']['normal'];assert transport[1]['cache']['hits']==0 and transport[2]['cache']['hits']==1
out=json.loads((P/'control-progress.json').read_bytes());out.update(complete=True,transport=transport,scope='280existingmechanism positions,6actualhistoryprefixes,8retainedsearchqueries. Firstattempt fullresults missing, secondattempt saved thisprogress but snapshot.events tuple was rejected; only transport phase resumed with publiclist shape. PENDING event edit is unauthenticated transport stress, not two actuallegal trajectories. No production/AUX change.');write_record(P/'control-results.json',out);print(json.dumps(transport));print('TRANSPORT_COMPLETE',len(out['mechanisms']),len(out['queries']))
