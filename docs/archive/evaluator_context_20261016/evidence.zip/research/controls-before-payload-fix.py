from pathlib import Path
from copy import copy,deepcopy
from dataclasses import replace
import sys,json,time,random,importlib.util,statistics
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from scripts.research_record import record_value,write_record
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import SemanticSearchEngine,semantic as sem
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.ai.limits import SearchLimits
from test_native_q_history_deferral import cycle,checked_replay
from test_native_pending_continuation import session_after
from phase19c1_native_semantic_fixtures import semantic_corpus
spec=importlib.util.spec_from_file_location('controlcache._native_core',P/'cache_native_core.pyd');cache=importlib.util.module_from_spec(spec);spec.loader.exec_module(cache)
start=time.perf_counter();rows=[];queries=[];histories=[]
def stopped():
 for n in('rollout','advisor','slack'):
  d=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('user_paused')or d.get('stopped'):raise RuntimeError('USER_STOP')
 assert time.perf_counter()-start<180
def oracle(c,p):
 e=SemanticEngine(c);v=[]
 for owner in(0,1):
  view=replace(p,side_to_move=owner);aa=e.legal_actions(view);v.append((len(aa),sum(a.promotion_target_id is not None for a in aa),sum(a.source is not None and c.support.type_metadata[view.board[a.source].current_type_id].is_anchor for a in aa)-10*int(e.in_check(view,owner))))
 return tuple(a-b for a,b in zip(*v))
for name,c in semantic_corpus():
 nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=cache)))for a in('normal','cache')}
 for seed in range(4):
  s=GameSession(c);rng=random.Random(20261016+seed);cache.private_cache(True)
  for ply in range(7):
   stopped();before=record_value(s.state);pack={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};v=sem.dynamic_features(nrs['normal'],pack['normal']);old=cache.private_cache(False);a=sem.dynamic_features(nrs['cache'],pack['cache']);mid=cache.private_cache(False);b=sem.dynamic_features(nrs['cache'],pack['cache']);after=cache.private_cache(False);want=oracle(c,s.state.position);assert a==b==v==want,(name,seed,ply,a,b,v,want);assert after['hits']==mid['hits']+1;assert record_value(s.state)==before
   rows.append(dict(fixture=name,seed=seed,ply=ply,state=before,game_record=json.loads(serialize_game_record(s.to_record())),features=v,cache_before=old,cache_after=after))
   if ply==6 or s.state.terminal_status.is_terminal:break
   aa=s.legal_actions()
   if not aa:break
   s.submit(rng.choice(sorted(aa,key=repr)))
 print('MECHANISM',name,len(rows),flush=True)
for prefix in(0,32,128,512,1023,1024):
 stopped();t=time.perf_counter();s=cycle(max_ply=1024,repetition=10000,prefix=prefix);c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=cache)))for a in('normal','cache')};packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};cache.private_cache(True);values={};errors={};timings={a:[]for a in nrs};before=record_value(s.state)
 for rep in range(32):
  for a in(('normal','cache')if rep%2==0 else('cache','normal')):
   stopped();tt=time.perf_counter()
   try:values[a]=sem.dynamic_features(nrs[a],packs[a])
   except Exception as exc:errors[a]=type(exc).__name__+': '+str(exc)
   timings[a].append(time.perf_counter()-tt)
 assert values.get('normal')==values.get('cache');assert errors.get('normal')==errors.get('cache');assert record_value(s.state)==before
 z=dict(prefix=prefix,history_entries=len(s.state.history),values=values,errors=errors,timings=timings,cache=cache.private_cache(False),acquire_and_direct_seconds=time.perf_counter()-t,game_record=json.loads(serialize_game_record(s.to_record())),state=before);histories.append(z);print('HISTORY',prefix,z['cache'],errors,flush=True)
 if prefix in(0,512):
  bv={'K':0,'Z':0,'F':20,'G':100}
  for rep in range(2):
   pair=[]
   for a in(('normal','cache')if rep==0 else('cache','normal')):
    stopped()
    if a=='cache':cache.private_cache(True)
    e=SemanticSearchEngine(c,nrs[a],board_values=bv,hand_values=bv,dynamic_values=(2,3,5),tt_megabytes=0,ordering_cache_enabled=False);tt=time.perf_counter();r=e.search(s,SearchLimits(max_depth=4,max_nodes=4096,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);zq=dict(kind='ACTUAL_QUERY',prefix=prefix,arm=a,rep=rep,result=record_value(r),caller_seconds=time.perf_counter()-tt);checked_replay(s,nrs[a],r);assert record_value(s.state)==before
    if a=='cache':zq['cache']=cache.private_cache(False)
    pair.append(zq);queries.append(zq)
   assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
s=session_after(('e2e4','d7d5','f1b5','c7c6'));c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=cache)))for a in('normal','cache')};p=pack_semantic_search_position(c,nrs['normal'],s);payload=sem.snapshot(nrs['normal'],p);base=deepcopy(payload);changed=deepcopy(payload);changed['history_events']=list(changed['history_events']);changed['history_events'][3]=(changed['history_events'][3][0],False);cache.private_cache(True);transport=[]
for label,pay in(('actual_pending',base),('edited_history_event',changed),('actual_pending_again',base)):
 stopped();v={a:sem.dynamic_features(nr,sem.pack_position(nr,pay))for a,nr in nrs.items()};assert v['normal']==v['cache'];transport.append(dict(label=label,features=v,cache=cache.private_cache(False),payload=record_value(pay)))
assert transport[0]['features']['normal']!=transport[1]['features']['normal'];assert transport[1]['cache']['hits']==0 and transport[2]['cache']['hits']==1
write_record(P/'control-results.json',dict(complete=True,mechanisms=rows,histories=histories,queries=queries,transport=transport,seconds=time.perf_counter()-start,scope='Existing fixture/newprefix controls. Core vector independent only for mechanism positions away from rulemax. Transport flagedit is not authenticated legal play. Complete histories and raw differences retained, no AUX/model/production changes.'));print('CONTROLS_DONE',len(rows),len(queries),time.perf_counter()-start,flush=True)
