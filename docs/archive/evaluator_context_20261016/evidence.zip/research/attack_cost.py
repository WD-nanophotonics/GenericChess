from pathlib import Path
import sys,sysconfig,json,shutil,subprocess,time,importlib.util,statistics,hashlib
R=Path.cwd();P=R/'.local_agent/eval-revisit-20261016';S=P/'attack-cost-source';S.mkdir(exist_ok=False)
for f in(P/'view-source').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
p=S/'native_semantic_runtime.c';s=p.read_text();a=s.index('static int semantic_attacked_by(');b=s.index('static int semantic_action_delivers_check(',a);part=s[a:b].replace('static int semantic_attacked_by(','static int private_semantic_attacked_by(',1);wrapper='''
unsigned long long private_attack_calls=0,private_attack_ns=0;int private_attack_scope=0;
static int semantic_attacked_by(const GCSemanticRules *r,const GCSemanticPosition *p,uint16_t target_square,uint8_t attacker){
 if(!private_attack_scope)return private_semantic_attacked_by(r,p,target_square,attacker);
 uint64_t t=gc_monotonic_ns();int ok=private_semantic_attacked_by(r,p,target_square,attacker);private_attack_ns+=gc_monotonic_ns()-t;private_attack_calls++;return ok;
}
''';s='#include "native_clock.h"\n'+s[:a]+part+wrapper+s[b:];p.write_bytes(s.encode());p=S/'native_module.c';s=p.read_text();mark='static int gc_semantic_dynamic_feature_vector(';a=s.index(mark,s.index(mark)+1);b=s.index('static int gc_semantic_compact_residual(',a);part=s[a:b].replace('gc_semantic_dynamic_feature_vector(','private_dynamic_feature_vector(',1);wrapper='''
extern unsigned long long private_attack_calls,private_attack_ns;extern int private_attack_scope;
static unsigned long long private_feature_calls=0,private_feature_ns=0;
static int gc_semantic_dynamic_feature_vector(const GCSemanticRules *r,const GCSemanticPosition *p,int out[3]){
 uint64_t t=gc_monotonic_ns();private_attack_scope=1;int ok=private_dynamic_feature_vector(r,p,out);private_attack_scope=0;private_feature_calls++;private_feature_ns+=gc_monotonic_ns()-t;return ok;
}
static PyObject *gc_private_attack_info(PyObject *self,PyObject *args){
 (void)self;int reset;if(!PyArg_ParseTuple(args,"p",&reset))return NULL;if(reset){private_attack_calls=private_attack_ns=private_feature_calls=private_feature_ns=0;}return Py_BuildValue("{sK,sK,sK,sK}","attack_calls",private_attack_calls,"attack_ns",private_attack_ns,"feature_calls",private_feature_calls,"feature_ns",private_feature_ns);
}
''';s=s[:a]+part+wrapper+s[b:];mark='    {"semantic_dynamic_features", gc_semantic_dynamic_features, METH_VARARGS,';s=s.replace(mark,'    {"private_attack_info",gc_private_attack_info,METH_VARARGS,"privateattribution"},\n'+mark);p.write_bytes(s.encode());outp=P/'attack_cost_native_core.pyd';cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(outp)];r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr
sys.path.insert(0,str(R));from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,GameSession
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from scripts.research_record import write_record
mods={}
for arm,f in [('view','view_native_core.pyd'),('counter','attack_cost_native_core.pyd')]:
 spec=importlib.util.spec_from_file_location('val_'+arm+'._native_core',P/f);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
start=time.perf_counter();rows=[]
for f in sorted((R/'.local_agent/api-ready-20261016/roots').glob('*.json')):
 assert time.perf_counter()-start<180
 for n in('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not(z.get('user_paused')or z.get('stopped'))
 d=json.loads(f.read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={a:compile_native_semantic_rules(c,backend_module=m)for a,m in mods.items()};pack={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};before={a:sem.snapshot(nr,pack[a])for a,nr in nrs.items()};timing={a:[]for a in mods};v={};mods['counter'].private_attack_info(True)
 for rep in range(64):
  for arm in(('view','counter')if rep%2==0 else('counter','view')):
   t=time.perf_counter();v[arm]=sem.dynamic_features(nrs[arm],pack[arm]);timing[arm].append(time.perf_counter()-t)
 assert v['view']==v['counter'];assert before=={a:sem.snapshot(nr,pack[a])for a,nr in nrs.items()};audit=mods['counter'].private_attack_info(False);rows.append(dict(seed=d['seed'],board=d['board'],features=v,timings=timing,audit=audit,timed_to_counterfree_median_ratio=statistics.median(timing['counter'])/statistics.median(timing['view']),measured_attack_fraction=audit['attack_ns']/audit['feature_ns']));print('ATTACK_COST',d['seed'],rows[-1]['timed_to_counterfree_median_ratio'],rows[-1]['measured_attack_fraction'],flush=True)
write_record(P/'attack-cost-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()},scope='Direct16existing full roots2048featurecalls. Attacktests within dynamicfeatures, two timerreadscall; overhead retained. No attack skipped/search/game/training/AUXexecution.'))
