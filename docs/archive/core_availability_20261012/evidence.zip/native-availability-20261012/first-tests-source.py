"""Finite availability primitive semantics: actual states, cutoff independence."""
from dataclasses import replace
import pytest
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native import native_available
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.native_core_availability import NativeCoreAvailability
pytestmark=pytest.mark.skipif(not native_available(),reason='native extension unavailable')
@pytest.mark.parametrize('case_id',['chess-ep','chess-promotion','shogi-promotion','shogi-drop'])
def test_availability_is_readonly_and_agrees_with_existing_effect_children(case_id):
    case=next(x for x in CASES if x['id']==case_id)
    c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
    core=CoreBoard(case,c);candidate=NativeCoreAvailability(c);engine=semantic_engine_for(c)
    root=core.runtime.state;candidate.install()
    try:
        assert candidate(core.runtime)==engine.has_legal_action(core.runtime.position)
        for action in core.runtime.legal_actions()[:16]:
            core.runtime.push(action)
            try: assert candidate(core.runtime)==engine.has_legal_action(core.runtime.position)
            finally: core.runtime.pop()
        core.runtime.assert_balanced();assert core.runtime.state==root
    finally:candidate.restore()
    assert candidate.fallbacks==0 and candidate.calls==candidate.imports==candidate.queries

@pytest.mark.parametrize('policy',['draw','loss'])
@pytest.mark.parametrize('repeated',[False,True])
def test_no_action_query_does_not_change_stalemate_or_history_priority(policy,repeated):
    from test_native_terminal_policy_support import _stalemate
    c,native,session,packed=_stalemate(policy,repeated)
    saved=ns.snapshot(native,packed)
    assert ns.has_legal_action(native,packed) is False
    assert ns.snapshot(native,packed)==saved
    from generic_chess.core.search_runtime import SearchPathRuntime
    rt=SearchPathRuntime(session.state,c,history_witnesses=session._search_history_witnesses)
    candidate=NativeCoreAvailability(c)
    assert candidate(rt) is False
    from generic_chess.core import terminal
    candidate.install()
    try:
        from generic_chess.core import search_runtime
        assert search_runtime.terminal_from_search_runtime(rt)==terminal.terminal_from_search_runtime(rt)
    finally:candidate.restore()

def test_query_ignores_ply_cutoff_and_checks_rules_identity():
    c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));case=next(x for x in CASES if x['id']=='chess-ep');core=CoreBoard(case,c);native=compile_native_semantic_rules(c)
    packed=ns.pack_current_position(native,core.runtime.position,ply_count=c.support.max_ply)
    before=ns.snapshot(native,packed)
    assert ns.has_legal_action(native,packed) is True
    assert ns.snapshot(native,packed)==before
    other=compile_native_semantic_rules(compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi')))
    with pytest.raises(ValueError,match='fingerprint'):ns.has_legal_action(other,packed)
