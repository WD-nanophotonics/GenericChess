def root_tactical_scan(
    state: GameState,
    compiled,
    evaluator: Evaluator,
    ctx: _Context,
    handles=None,
) -> tuple[Action | None, Action | None]:
    """Cheap root scan: immediate winning terminal first, else best fast-eval action.

    Returns ``(immediate_win_action, best_action_by_eval)``.  Every root
    successor is examined until the budget ends. Completed child evaluations
    retain their best action for the fallback even when the scan is interrupted.
    """
    best_action: Action | None = None
    best_score = -INF
    started = time.monotonic()
    if ctx.runtime is not None:
        stream = _runtime_legal_actions(ctx, ctx.checkpoint)
        for action in stream:
            ctx.budget.check(ctx.stats, force=True)
            with ctx.runtime.pushed(action, checkpoint=ctx.checkpoint):
                child = ctx.runtime.state
                ctx.stats.nodes += 1
                ctx.stats.root_scan_nodes += 1
                if (
                    child.terminal_status.is_terminal
                    and child.terminal_status.winner == state.position.side_to_move
                ):
                    ctx.stats.root_scan_seconds += time.monotonic() - started
                    return action, best_action
                if child.terminal_status.is_terminal:
                    score = -terminal_score(
                        child.terminal_status,
                        child.position.side_to_move,
                        1,
                    )
                    if score > best_score:
                        best_score = score
                        best_action = action
                        ctx.root_scan_best_action = action
                    continue
                score = 0  # PRIVATE terminal-only policy; main search still evaluates
                if score > best_score:
                    best_score = score
                    best_action = action
                    ctx.root_scan_best_action = action
                ctx.budget.check(ctx.stats, force=True)
        ctx.stats.root_scan_seconds += time.monotonic() - started
        return None, best_action
    if handles is None:
        with ctx.recorder.time_block(AuditMetric.MOVE_GEN):
            successors = legal_successors(state, compiled)
        ctx.budget.check(ctx.stats, force=True)
        stream = iter(successors)
    else:
        stream = handles
    for item in stream:
        ctx.budget.check(ctx.stats, force=True)
        if handles is None:
            action, child = item
        else:
            action = item.action
            child, _child_key = materialize_legal_successor(
                state, item, compiled, checkpoint=ctx.checkpoint
            )
        ctx.stats.nodes += 1
        ctx.stats.root_scan_nodes += 1
        if (
            child.terminal_status.is_terminal
            and child.terminal_status.winner == state.position.side_to_move
        ):
            ctx.stats.root_scan_seconds += time.monotonic() - started
            return action, best_action
        if child.terminal_status.is_terminal:
            score = -terminal_score(
                child.terminal_status,
                child.position.side_to_move,
                1,
            )
            if score > best_score:
                best_score = score
                best_action = action
                ctx.root_scan_best_action = action
            continue
        score = 0  # PRIVATE terminal-only policy; main search still evaluates
        if score > best_score:
            best_score = score
            best_action = action
            ctx.root_scan_best_action = action
        ctx.budget.check(ctx.stats, force=True)
        ctx.budget.check(ctx.stats)
    ctx.stats.root_scan_seconds += time.monotonic() - started
    return None, best_action
