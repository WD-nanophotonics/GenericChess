from pathlib import Path
import sys,json,time
from dataclasses import replace
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')]
from conftest import make_ruleset,king_type
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import MAX_STATIC_EVAL
from scripts.research_record import record_value
from tools.local_agent.common import write_json
D=R/'.local_agent/root-reuse-20261017'
start=time.monotonic()
c=compile_legacy_ruleset_for_semantic_execution(make_ruleset(4,[king_type()],lines=['...k','....','....','K...']))
s=GameSession(c);before=s.state,s.to_record(),s._search_witnesses
class RepeatFailure:
    def __init__(self): self.seen=[];self.calls=0;self.repeat=None
    def evaluate(self,state):
        self.calls+=1
        for old in self.seen:
            if old==state:
                self.repeat=record_value(state)
                raise RuntimeError('EXPLICIT_EVALUATOR_SECOND_VISIT')
        self.seen.append(state)
        return -100
class Huge:
    def evaluate(self,state): return -(MAX_STATIC_EVAL*100)
rows=[]
for kind,e in [('second_visit',RepeatFailure()),('bounded_static',Huge())]:
    for name in ('rollout','advisor','slack'):
        flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if flags.get('stopped') or flags.get('user_paused'): raise InterruptedError('Userstop')
    try:
        d=AlphaBetaPlayer(c,evaluator_override=e,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=True)).choose_action(s,SearchLimits(max_depth=1,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
        assert kind=='bounded_static' and d.score==MAX_STATIC_EVAL and d.completed_depth==1
        rows.append({'kind':kind,'decision':record_value(d),'raw_callback':e.evaluate(s.state),'search_bound':MAX_STATIC_EVAL})
    except RuntimeError as exc:
        assert kind=='second_visit' and str(exc)=='EXPLICIT_EVALUATOR_SECOND_VISIT'
        rows.append({'kind':kind,'error':str(exc),'calls':e.calls,'distinct_complete_children':len(e.seen),'repeated_complete_child':e.repeat})
    assert before==(s.state,s.to_record(),s._search_witnesses)
    assert time.monotonic()-start<30
write_json(D/'contract-result.json',{'complete':True,'calls':2,'rows':rows,'seconds':time.monotonic()-start,'decision':'Reject generic override caching: second visit and signed failures are observable. Reuse rawscan as D1 also fails declarations; any altered scan must be explicit distinct finitepolicy and retain current production default.'})
print([(r['kind'],r.get('error'),r.get('calls'),r.get('decision',{}).get('score')) for r in rows])