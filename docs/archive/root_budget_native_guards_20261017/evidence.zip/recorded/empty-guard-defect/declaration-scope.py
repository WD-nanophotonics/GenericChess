from pathlib import Path
from dataclasses import replace
import sys,json,datetime
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];D=R/'.local_agent/root-reuse-20261017/empty-guard-defect'
from tools.local_agent.common import write_json
from conftest import make_ruleset,king_type
from generic_chess.rules.schema import RuleDeclaration,RuleDeclarationOutcomeBand,RuleWeightedMaterialMetric,RuleStateGuard,RuleTypeRef,RuleSpatialSelector,RuleSquareRef
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.session.session import GameSession
from generic_chess.core.declarations import available_declarations
from scripts.research_record import record_value
rows=[]
for ref in (RuleSquareRef('fixed',square=(20,0)),RuleSquareRef('offset_from_source',offset=(20,0))):
    guard=RuleStateGuard(aggregation='count',owner='any',type_ref=RuleTypeRef('any'),compare_field='base',promoted='any',location='board',spatial=RuleSpatialSelector('exact',refs=(ref,)),comparison='eq',value=0,subject_ref=ref)
    rule=replace(make_ruleset(4,[king_type()],lines=['...k','....','....','K...']),declarations=(RuleDeclaration('guarded',0,state_guards=(guard,),require_not_in_check=False,weighted_metric=RuleWeightedMaterialMetric(weights={'K':1}),outcome_bands=(RuleDeclarationOutcomeBand(1,'WIN'),)),))
    row={'ref':record_value(ref)}
    try:
        c=compile_legacy_ruleset_for_semantic_execution(rule);row['core_compile']='accepted';row['core_options']=record_value(available_declarations(GameSession(c).state,c))
        try:compile_native_semantic_rules(c);row['native_compile']='accepted'
        except Exception as e:row['native_compile']='refused';row['native_failure']={'type':type(e).__name__,'message':str(e)}
    except Exception as e:row['core_compile']='refused';row['core_failure']={'type':type(e).__name__,'message':str(e)}
    rows.append(row)
write_json(D/'declaration-scope-check.json',{'question':'Does similar declaration_guard_holds earlyreturn expose an actuallyadmitted counterpart?','rows':rows,'decision':'Keepdeclarationimplementationunchanged whenbadsubjectiscompiler-refused; do notbroadenobservedpattern-guardfix tospeculativedeclarations.'})
print(json.dumps(rows,indent=2))