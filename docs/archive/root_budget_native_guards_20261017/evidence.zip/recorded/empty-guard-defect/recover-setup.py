from pathlib import Path
import sys
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017/empty-guard-defect'
import pytest
nodes=(D/'setup-retry-nodeids.txt').read_text().splitlines()
assert len(nodes)==200
raise SystemExit(pytest.main(['-q','-o','addopts=','-o','cache_dir=.local_agent/pytest-cache-root-guard','--basetemp=.local_agent/root-reuse-20261017/pytest-tmp-recovery','--junitxml=.local_agent/root-reuse-20261017/empty-guard-defect/full-setup-recovery.xml',*nodes]))