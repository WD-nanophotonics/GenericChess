from pathlib import Path
import sys,json
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017/empty-guard-defect'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.core.movement import LeapAtom
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.position import Hands,Position
from generic_chess.core.semantic_executor import SemanticEngine,_semantic_public_action
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import RuleSet,RuleSemanticAction,RuleGeometrySpec,RuleStateGuard,RuleTypeRef,RuleSquareRef,RuleSpatialSelector,RuleActionEffect
from generic_chess.rules.serialization import serialize_ruleset
rows=[]
for n in (8,16):
    king=PieceType('K','K',(LeapAtom((1,0)),),is_anchor=True);hand=PieceType('H','H',(LeapAtom((1,0)),));board=[None]*(n*n);board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K');ref=RuleSquareRef('source')
    guard=RuleStateGuard(aggregation='count',owner='any',type_ref=RuleTypeRef('any'),compare_field='base',promoted='any',location='board',spatial=RuleSpatialSelector('exact',refs=(ref,)),comparison='eq',value=0,subject_ref=ref)
    action=RuleSemanticAction(name='drop_no_source',type_ids=('H',),geometry=RuleGeometrySpec(kind='drop'),target_relation='empty',state_guards=(guard,),effects=(RuleActionEffect('remove_from_hand',piece_type_ref=RuleTypeRef('action_base')),RuleActionEffect('place',to_ref=RuleSquareRef('target'),piece_type_ref=RuleTypeRef('action_base')),))
    rule=RuleSet(board_size=n,piece_types=(king,hand),initial_position=tuple(tuple(board[r*n:(r+1)*n]) for r in range(n)),drop_allowed={'H':((True,)*(n*n),)*2},semantic_actions=(action,));c=compile_semantic_ruleset(rule);p=Position(tuple(board),(Hands((('H',1),)),Hands.empty()),0,c.ruleset_fingerprint);engine=SemanticEngine(c);native=compile_native_semantic_rules(c);packed=sem.pack_current_position(native,p,ply_count=0)
    core={_semantic_public_action(engine,a) for a in engine.legal_actions(p)};actual={sem.public_action(native,a) for a in sem.guarded_actions(native,packed)}
    row={'board':n,'rule':json.loads(serialize_ruleset(rule)),'position':record_value(p),'core_legal_actions':len(core),'native_legal_actions':len(actual),'missing_actions':record_value(sorted(core-actual,key=str)),'unexpected_actions':record_value(sorted(actual-core,key=str)),'match':core==actual};rows.append(row);print('DROP_SOURCE',n,len(core),len(actual),core==actual,flush=True)
write_json(D/'drop-source-scope-result.json',{'question':'Does an undefined drop source stayundefined when packed0xFF isinside a16board?','rows':rows,'scope':'Current repairedkernel, separateexistingbindingboundary; no broadNativecodec rewrite orCoresemanticchange. RefuseaffectedNativepatterns ifactualmismatch, keepfullCore.'})