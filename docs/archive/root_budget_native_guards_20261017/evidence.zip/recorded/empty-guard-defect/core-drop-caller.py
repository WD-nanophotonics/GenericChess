from pathlib import Path
from dataclasses import replace
import sys,json,time
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017/empty-guard-defect'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.core.movement import LeapAtom
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.coordinates import Square
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.rules.schema import RuleSet,RuleSemanticAction,RuleGeometrySpec,RuleStateGuard,RuleTypeRef,RuleSquareRef,RuleSpatialSelector,RuleActionEffect,RuleAuxState
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
START=time.monotonic();rows=[]
def check():
    if time.monotonic()-START>=120:raise TimeoutError('Frozen120scaller')
    for name in ('rollout','advisor','slack'):
        f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if f.get('stopped') or f.get('user_paused'):raise InterruptedError('Userstop')
for n in (8,16):
    for kind in ('source','offset_from_source'):
        check();king=PieceType('K','K',(LeapAtom((1,0)),),is_anchor=True);hand=PieceType('H','H',(LeapAtom((0,1)),));board=[None]*(n*n);board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K');board[1]=Piece(1,'H','H')
        ref=RuleSquareRef(kind,offset=(0,0) if kind=='offset_from_source' else None)
        guard=RuleStateGuard('count','any',RuleTypeRef('any'),'base','any','board',RuleSpatialSelector('exact',refs=(ref,)),'eq',0,subject_ref=ref)
        action=RuleSemanticAction(name='marked_drop',type_ids=('H',),geometry=RuleGeometrySpec(kind='drop'),target_relation='empty',state_guards=(guard,),aux_state=(RuleAuxState('mark','bool','global','persistent',initial=0),),effects=(RuleActionEffect('remove_from_hand',piece_type_ref=RuleTypeRef('action_base')),RuleActionEffect('place',to_ref=RuleSquareRef('target'),piece_type_ref=RuleTypeRef('action_base')),RuleActionEffect('set_bool',slot_name='mark',value=1)))
        rule=RuleSet(board_size=n,piece_types=(king,hand),initial_position=tuple(tuple(board[r*n:(r+1)*n]) for r in range(n)),drop_allowed={'H':((True,)*(n*n),)*2},semantic_actions=(action,));c=compile_semantic_ruleset(rule);s=GameSession(c)
        first=next(a for a in s.legal_actions() if a.to_square==Square(1,0));s.submit(first);assert s.state.position.hands[0].count('H')==1
        reply=next(a for a in s.legal_actions() if a.to_square==Square(n-2,n-1));s.submit(reply);assert len(s.state.history)==3 and s.state.position.side_to_move==0
        before=s.state,s.to_record(),s._search_witnesses;N=len(s.legal_actions());slot,=c.ir.aux_slots
        class Marker:
            def evaluate(self,state):
                score=100*dict(state.position.aux_state).get((slot.slot_id,-1),0)
                return score if state.position.side_to_move==0 else -score
        p=AlphaBetaPlayer(c,evaluator_override=Marker(),use_disk_cache=False,use_ordering=False,use_native_semantic_legality=True)
        assert (p.native_legality_provider is None)==(n==16)
        d=p.choose_action(s,SearchLimits(max_depth=1,max_nodes=2*N+2,max_time_seconds=20,quiescence_max_depth=0,quiescence_hard_max_depth=0))
        assert before==(s.state,s.to_record(),s._search_witnesses);assert d.completed_depth==1 and d.score==100 and d.runtime_depth_balanced
        s.submit(d.action);assert dict(s.state.position.aux_state)[(slot.slot_id,-1)]==1 and s.state.position.hands[0].count('H')==0 and len(s.state.history)==4
        row={'board':n,'kind':kind,'rule':json.loads(serialize_ruleset(rule)),'parent':record_value(before[0]),'record':record_value(s.to_record()),'root_degree':N,'decision':record_value(d),'child':record_value(s.state),'native_provider_present':p.native_legality_provider is not None};rows.append(row);write_json(D/f'core-drop-caller-{n}-{kind}.json',row);print('ACTUAL_DROP_CALLER',n,kind,N,d.completed_depth,d.score,d.native_legality_calls,flush=True)
write_json(D/'core-drop-caller-result.json',{'complete':len(rows)==4,'calls':len(rows),'rows':rows,'seconds':time.monotonic()-START,'scope':'Actualcapture/reply/drop complete4statehistory withauxmark andsemanticbinding. PureCore16retainsall509rootactions; no Nativewidebinding orstrengthclaim.'})
