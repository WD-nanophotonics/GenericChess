from pathlib import Path
import sys,json,time
from copy import copy
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R))
D=R/'.local_agent/root-reuse-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.ai.alphabeta import search
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
start=time.monotonic()
plan=json.loads((D/'terminal-scan-control-plan.json').read_bytes())
inputs=json.loads((R/'.local_agent/price-measure-20261017/fresh-transfer/consumer-inputs.json').read_bytes())
original=search.root_tactical_scan
namespace=dict(search.__dict__)
exec(compile((D/'terminal-scan-candidate.py').read_text(),str(D/'terminal-scan-candidate.py'),'exec'),namespace)
candidate=namespace['root_tactical_scan']
def check():
    if time.monotonic()-start>=180: raise TimeoutError('Frozen180seconds')
    for name in ('rollout','advisor','slack'):
        flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if flags.get('stopped') or flags.get('user_paused'): raise InterruptedError('Userstop')
def decode(a):
    if not a:return PassAction()
    if 'from_square' in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
    return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
rows=[]
try:
    for index,root in enumerate(plan['roots']):
        check()
        definition=next(z['rule'] for z in inputs if z['family']==root['family'])
        c=replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(definition))),_legacy_compiled=None)
        s=GameSession(c)
        for a in root['prefix']: check();s.submit(decode(a))
        assert record_value(s.state)==root['original_parent']
        cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0)
        profile,scope=build_semantic_opportunity_profile(c,cfg)
        evaluator=SemanticAttackEvaluator(c,profile,cfg,backend='core')
        arms=[]
        before=s.state,s.to_record(),s._search_witnesses
        for enabled in ((False,True) if index%2==0 else (True,False)):
            check();search.root_tactical_scan=candidate if enabled else original
            p=AlphaBetaPlayer(c,evaluator_override=evaluator,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(require_full_pv=True))
            t=time.monotonic()
            d=p.choose_action(s,SearchLimits(max_depth=1,max_nodes=8192,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0))
            elapsed=time.monotonic()-t
            assert before==(s.state,s.to_record(),s._search_witnesses)
            child=copy(s);child.submit(d.action)
            pv=copy(s)
            for a in d.principal_variation:pv.submit(a)
            row={'terminal_only':enabled,'decision':record_value(d),'seconds':elapsed,'child':record_value(child.state),'pv_final':record_value(pv.state),'actual_own_terminal_win':child.state.terminal_status.winner==s.state.position.side_to_move}
            arms.append(row)
            write_json(D/f'terminal-scan-call-{index}-{int(enabled)}.json',{'root':root,'arm':row})
        rows.append({'family':root['family'],'kind':root['kind'],'arms':arms})
        write_json(D/'terminal-scan-control-progress.json',{'rows':rows,'seconds':time.monotonic()-start})
        print('SCAN_PAIR',root['family'],[(a['terminal_only'],round(a['seconds'],4),a['decision']['completed_depth'],a['decision']['evaluation_calls'],a['actual_own_terminal_win']) for a in arms],flush=True)
finally:search.root_tactical_scan=original
write_json(D/'terminal-scan-control-result.json',{'complete':len(rows)==5,'calls':2*len(rows),'rows':rows,'seconds':time.monotonic()-start,'scope':'Distinct private fallback policy; main evaluator/terminal/declarations/full parent/PV unchanged; no productiondefault, holdout, WDL or strength claim.'})