from pathlib import Path
import sys,json,collections,math
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017/existing-flag-transfer'
from tools.local_agent.common import write_json
plan=json.loads((D/'plan.json').read_bytes());result=json.loads((D/'consumer-result.json').read_bytes());games=[json.loads(p.read_bytes()) for p in sorted(D.glob('consumer-game-*.json'))]
assert result['complete'] and len(games)==32 and not result['source_changed']
expected={(f,o,a) for f in range(8) for o in (0,1) for a in ('scan_on','scan_off')};assert {(g['family'],g['candidate_owner'],g['arm']) for g in games}==expected
summary={};pairs=[]
for arm in ('scan_on','scan_off'):
    gs=[g for g in games if g['arm']==arm];qs=[m['decision'] for g in gs for m in g['moves'] if m['candidate']]
    summary[arm]={'games':len(gs),'W':sum(g['reward']==1 for g in gs),'L':sum(g['reward']==-1 for g in gs),'D':sum(g['reward']==0 for g in gs),'UNKNOWN':sum(g['reward'] is None for g in gs),'physical_plies':sum(len(g['moves']) for g in gs),'candidate_calls':len(qs),'candidate_seconds':sum(q['elapsed_seconds'] for q in qs),'candidate_evaluation_seconds':sum(q['evaluation_seconds'] for q in qs),'candidate_evaluation_calls':sum(q['evaluation_calls'] for q in qs),'candidate_nodes':sum(q['nodes']+q['qnodes'] for q in qs),'depths':dict(collections.Counter(q['completed_depth'] for q in qs)),'sources':dict(collections.Counter(q['result_source'] for q in qs)),'terminations':dict(collections.Counter(q['termination_reason'] for q in qs)),'native_legality_calls':sum(q['native_legality_calls'] for q in qs),'max_call_seconds':max(q['elapsed_seconds'] for q in qs)}
for f in range(8):
    for owner in (0,1):
        a=next(g for g in games if (g['family'],g['candidate_owner'],g['arm'])==(f,owner,'scan_on'));b=next(g for g in games if (g['family'],g['candidate_owner'],g['arm'])==(f,owner,'scan_off'))
        x,y=a['reward'],b['reward'];diff=None if x is None or y is None else y-x
        first=next((i for i,(m,n) in enumerate(zip(a['moves'],b['moves'])) if m['decision']['action']!=n['decision']['action'] or m['decision']['declaration']!=n['decision']['declaration']),None)
        pairs.append({'family':f,'owner':owner,'scan_on':x,'scan_off':y,'gain_bounds':[(y if y is not None else -1)-(x if x is not None else 1),(y if y is not None else 1)-(x if x is not None else -1)],'complete_gain':diff,'first_action_divergence_ply':first,'identical_entire_actions':a['record']['actions']==b['record']['actions'],'games':[a['game'],b['game']]})
lo=sum(p['gain_bounds'][0] for p in pairs)/16;hi=sum(p['gain_bounds'][1] for p in pairs)/16
out={'complete':True,'planned_games':32,'physical_plies':result['physical_moves'],'search_calls':result['calls'],'whole_seconds':result['seconds'],'source_unchanged':not result['source_changed'],'summary':summary,'pairs':pairs,'all_pair_mean_gain_bounds':[lo,hi],'complete_pairs':sum(p['complete_gain'] is not None for p in pairs),'complete_pair_gain_counts':dict(collections.Counter(p['complete_gain'] for p in pairs if p['complete_gain'] is not None)),'scope':'Eight prospectivelyseeded rules, SAME fixedmaterialD2/.25s foe, candidateD3/1s, dependentfamily/roles and administrative64plyUNKNOWN. Not genericstrength/Elo/WDL; no model/pricefit.','decision':'No demonstrated net outcome benefit: retain defaultscanON/existingexplicitOFF. Moredepth and lower evalwork alone do not establish usefulpolicy. Do notpoolwith priorfeature-arm/halfsecondcohorts, replaceUNKNOWN, or rerunsamearena.'}
write_json(D/'analysis.json',out)
print(json.dumps({k:v for k,v in out.items() if k!='pairs'},indent=2));print('DIVERGENCES',[(p['family'],p['owner'],p['first_action_divergence_ply']) for p in pairs if p['first_action_divergence_ply'] is not None])