from pathlib import Path
import sys,json,time,importlib.util
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017';G=D/'empty-guard-defect';G.mkdir(exist_ok=True)
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.core.movement import LeapAtom
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.position import Hands,Position
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import attacked_squares,is_square_attacked,pack_current_position,snapshot
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.rules.schema import RuleActionEffect,RuleAuxState,RuleGeometrySpec,RuleSemanticAction,RuleSet,RuleSlotGuard,RuleSpatialSelector,RuleSquareRef,RuleStateGuard,RuleTypeRef
n=5;king=PieceType('K','K',(LeapAtom((1,0)),),is_anchor=True);actor=PieceType('A','A',(LeapAtom((2,0)),));base=PieceType('B','B',(LeapAtom((2,0)),),is_promotable=True,promotion_target_ids=('A',))
board=[None]*25;board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K');board[6]=Piece(0,'A','A');board[11]=Piece(0,'B','A',True)
rows=[]
for name,aggregation,ref,comparison,value in [('offboard_count_zero','count',RuleSquareRef('offset_from_source',offset=(20,0)),'eq',0),('onsource_exists_zero','exists',RuleSquareRef('source'),'eq',0),('onsource_count_one','count',RuleSquareRef('source'),'eq',1)]:
    guard=RuleStateGuard(aggregation=aggregation,owner='any',type_ref=RuleTypeRef('any'),compare_field='base',promoted='any',location='board',spatial=RuleSpatialSelector('exact',refs=(ref,)),comparison=comparison,value=value,subject_ref=ref)
    action=RuleSemanticAction(name='capture_guard',type_ids=('A',),geometry=RuleGeometrySpec(kind='ray',direction=(0,1),min_steps=1,owner_relative=False),target_relation='enemy',state_guards=(guard,),slot_guards=(RuleSlotGuard('enabled',value=1),),aux_state=(RuleAuxState('enabled','bool','global','persistent',initial=1),),effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),))
    rules=RuleSet(board_size=n,piece_types=(king,actor,base),initial_position=tuple(tuple(board[r*n:(r+1)*n]) for r in range(n)),drop_allowed={tid:((False,)*25,)*2 for tid in ('A','B')},promotion_allowed={'B':(frozenset(),frozenset())},promotion_forced={'B':(frozenset(),frozenset())},semantic_actions=(action,))
    c=compile_semantic_ruleset(rules);slot,=c.ir.aux_slots;p=Position(tuple(board),(Hands.empty(),Hands.empty()),0,c.ruleset_fingerprint,aux_state=(((slot.slot_id,-1),1),));engine=SemanticEngine(c);native=compile_native_semantic_rules(c);packed=pack_current_position(native,p,ply_count=0);before=snapshot(native,packed)
    core=engine.attacked_squares(p,0);nat=attacked_squares(native,packed,0);core_scalar=engine.is_square_attacked(p,16,0);nat_scalar=is_square_attacked(native,packed,16,0)
    assert core_scalar==(16 in core) and nat_scalar==(16 in nat) and snapshot(native,packed)==before
    expected_mismatch=name!='onsource_count_one';assert (core!=nat)==expected_mismatch
    row={'case':name,'rule':json.loads(serialize_ruleset(rules)),'position':record_value(p),'core_maps':sorted(core),'native_maps':sorted(nat),'target':16,'core_target':core_scalar,'native_target':nat_scalar,'native_compile_accepted':True,'mismatch':core!=nat};rows.append(row);write_json(G/f'{name}-baseline.json',row);print('ACTUAL_GUARD',name,core_scalar,nat_scalar,'MISMATCH',core!=nat,flush=True)
write_json(G/'baseline-result.json',{'complete':True,'cases':rows,'confirmed':'Existing Native admitted count-offboard-zero and exists-comparison semantics disagree withCore. Not causedbyNP/passprojection; do notadoptprojection or claimall-domain from7087records.','product_source_unchanged_at_reproduction':True})