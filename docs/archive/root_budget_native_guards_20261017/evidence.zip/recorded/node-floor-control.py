from pathlib import Path
import sys,json,time
from dataclasses import replace
from copy import copy
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017';F=D/'existing-flag-transfer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
start=time.monotonic();rows=[]
def check():
    if time.monotonic()-start>=120:raise TimeoutError('Frozen120seconds')
    for name in ('rollout','advisor','slack'):
        f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if f.get('stopped') or f.get('user_paused'):raise InterruptedError('Userstop')
class Constant:
    def evaluate(self,state):return -17
inputs=json.loads((F/'consumer-inputs.json').read_bytes())
for family in (0,3,5):
    inp=next(x for x in inputs if x['family']==family);rule=deserialize_ruleset(json.dumps(inp['rule']))
    c=replace((compile_semantic_ruleset(rule) if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule)),_legacy_compiled=None)
    s=GameSession(c);actions=s.legal_actions();N=len(actions);before=s.state,s.to_record(),s._search_witnesses
    terminal_children=[]
    for a in actions:
        check();ch=copy(s);ch.submit(a)
        assert ch.state.terminal_status.winner!=s.state.position.side_to_move
        terminal_children.append(record_value(ch.state.terminal_status))
    for enabled in (True,False):
        theoretical=2*N+2 if enabled else N+2
        for cap in (theoretical-1,theoretical):
            check()
            d=AlphaBetaPlayer(c,evaluator_override=Constant(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=enabled)).choose_action(s,SearchLimits(max_depth=1,max_nodes=cap,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0))
            assert before==(s.state,s.to_record(),s._search_witnesses)
            assert d.completed_depth==(1 if cap==theoretical else 0)
            row={'family':family,'N':N,'scan_on':enabled,'cap':cap,'forecast_minimum':theoretical,'parent':record_value(s.state),'child_terminal_statuses':terminal_children,'decision':record_value(d)}
            rows.append(row);write_json(D/f'node-floor-call-{family}-{int(enabled)}-{cap}.json',row)
            print('NODE_FLOOR',family,N,enabled,cap,d.completed_depth,d.nodes,d.termination_reason,flush=True)
write_json(D/'node-floor-result.json',{'complete':len(rows)==12,'calls':len(rows),'seconds':time.monotonic()-start,'rows':rows,'conclusion':'Exact current cold q0 nodefloor is2N+2 scanON andN+2 OFF onthreeactualfullrules. Notallq/warmTT/rootdeclaration/winningterminal cases; do notraisefrozencaps.'})