from pathlib import Path
from dataclasses import replace
import sys,json,time
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017';F=D/'attack-projection/warm-wide-consumer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.position import Position,Hands,GameState,HistoryRecord
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
START=time.monotonic();count={'full_record_states':0,'PV_states':0,'owner_map_comparisons':0};cases=[]
def check():
    if time.monotonic()-START>=180:raise TimeoutError('Frozen180sadversediagnostic')
    for name in ('rollout','advisor','slack'):
        f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if f.get('stopped') or f.get('user_paused'):raise InterruptedError('Userstop')
def tup(x):return tuple(tup(y) for y in x) if isinstance(x,list) else x
def position(x):return Position(tuple(None if p is None else Piece(**p) for p in x['board']),tuple(Hands(tup(h['counts'])) for h in x['hands']),x['side_to_move'],x['ruleset_fingerprint'],tup(x['aux_state']),x['board_width'],x['board_height'])
def state(x):
    s=GameState(position(x['position']),x['ply_count'],tup(x['repetition_counts']),TerminalResult(TerminalStatus(x['terminal_status']['status']),x['terminal_status']['winner']),tuple(HistoryRecord(**h) for h in x['history']));assert record_value(s)==x;return s

def decode(a):
    if not a:return PassAction()
    if 'from_square' in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
    return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def compare(s):
    check();a=core._attack_maps(s);b=native._attack_maps(s);assert a==b;assert core.evaluate(s)==native.evaluate(s);count['owner_map_comparisons']+=2
rule=deserialize_ruleset(json.dumps(next(x['rule'] for x in json.loads((F/'consumer-inputs.json').read_bytes()) if x['family']==0)));c=replace(compile_legacy_ruleset_for_semantic_execution(rule),_legacy_compiled=None);assert sum(len(p.guards) for p in c.ir.patterns)==0
cfg=replace(EvaluationConfig(),dynamic_mobility_weight=2,anchor_escape_weight=0,promotion_potential_weight=0);profile,_=build_semantic_opportunity_profile(c,cfg);saved=json.loads((F/'consumer-family-00-profiles.json').read_bytes());assert record_value(profile)==saved['profiles']['attack']['profile'];core=SemanticAttackEvaluator(c,profile,cfg,backend='core');native=SemanticAttackEvaluator(c,profile,cfg,backend='native')
games=[]
for file in sorted(F.glob('consumer-game-*.json')):
    g=json.loads(file.read_bytes())
    if g['family']!=0:continue
    assert g['status']=='actual_terminal';games.append(g);states=[state(g['initial_state'])]+[state(m['child']) for m in g['moves']]
    for s in states:compare(s);count['full_record_states']+=1
    for i,move in enumerate(g['moves']):
        check();rt=SearchPathRuntime.from_state(states[i],c,history_witnesses=tuple(s.position for s in states[:i+1]));before=(rt.position,rt.ply_count,rt.terminal_status,tuple(rt.history),rt._snapshot);pushed=0
        try:
            for encoded in move['decision']['principal_variation']:
                rt.push(decode(encoded));pushed+=1;compare(rt.state);count['PV_states']+=1
        finally:
            for _ in range(pushed):rt.pop()
        assert before==(rt.position,rt.ply_count,rt.terminal_status,tuple(rt.history),rt._snapshot)
    cases.append({'game':g['game'],'arm':g['arm'],'owner':g['candidate_owner'],'reward':g['reward'],'plies':len(g['moves'])})
pairs=[]
for owner in (0,1):
    a=next(g for g in games if g['candidate_owner']==owner and g['arm']=='core_maps');b=next(g for g in games if g['candidate_owner']==owner and g['arm']=='native_maps');first=next((i for i,(x,y) in enumerate(zip(a['moves'],b['moves'])) if x['decision']['action']!=y['decision']['action']),None)
    if first is not None:
        parent=a['initial_state'] if first==0 else a['moves'][first-1]['child'];other=b['initial_state'] if first==0 else b['moves'][first-1]['child'];assert parent==other
        pairs.append({'owner':owner,'first_action_divergence_ply':first,'same_full_parent':True,'parent':parent,'core_decision':a['moves'][first]['decision'],'native_decision':b['moves'][first]['decision'],'rewards':[a['reward'],b['reward']]})
write_json(F/'adverse-diagnostic-result.json',{'complete':len(cases)==4,'counts':count,'cases':cases,'divergences':pairs,'seconds':time.monotonic()-START,'IR_state_guard_count':0,'new_search_calls':0,'new_games':0,'scope':'Newkernel existingNativefeaturequery onpreservedguard-freefamily, fullrecord/PVpaths ONLY. Historicalunrecordedinternalleaves notverified; noindependentruleWDL orstrengthclaim.','decision':'RetainactualfirstWtoLpair andfullinterruptionledger. Checkedfeaturemath equal; finiteoutcomeadversityisnotexcusedbycost/greaterdepth. NoNativefeature/defaultadoption or arenaextension.'})
print('ADVERSE_PATHS',count,flush=True);print('DIVERGENCES',[(x['owner'],x['first_action_divergence_ply'],x['core_decision']['completed_depth'],x['native_decision']['completed_depth'],x['rewards']) for x in pairs],flush=True)
