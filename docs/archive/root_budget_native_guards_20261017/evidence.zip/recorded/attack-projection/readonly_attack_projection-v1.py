from dataclasses import replace
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import pack_current_position,attacked_squares
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator

class ReadOnlyAttackProjection(SemanticAttackEvaluator):
    """PRIVATE feature-only probe. Never a search/terminal/legality adapter."""
    def __init__(self, original_rule, compiled, profile, config):
        super().__init__(compiled,profile,config,backend="core")
        probe=replace(original_rule,no_progress_draw=None,pass_enabled=False,consecutive_action_adjudications=())
        shadow=(compile_semantic_ruleset(probe) if probe.semantic_actions else compile_legacy_ruleset_for_semantic_execution(probe))
        self._projection_original=compiled.ruleset_fingerprint
        self._projection_rule=shadow
        self._projection_native=compile_native_semantic_rules(shadow)
        self._projection_calls=0
    def index_maps(self,position):
        if position.ruleset_fingerprint!=self._projection_original:
            raise ValueError("ATTACK_PROJECTION_ORIGINAL_FINGERPRINT_MISMATCH")
        # Sole copy change is routing fingerprint for this exact S0/S1 query.
        view=replace(position,ruleset_fingerprint=self._projection_rule.ruleset_fingerprint)
        packed=pack_current_position(self._projection_native,view,ply_count=0)
        self._projection_calls+=1
        return tuple(attacked_squares(self._projection_native,packed,owner) for owner in (0,1))
    def _attack_maps(self,state):
        return tuple(frozenset(self._attack_squares[i] for i in indices) for indices in self.index_maps(state.position))
