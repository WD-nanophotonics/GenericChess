from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017/attack-projection'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.position import Position,Hands
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
START=time.monotonic();rows=[];total=0;unique=0;scalar=0;failure=None

def clockcheck():
    if time.monotonic()-START>=600:raise TimeoutError('Frozen600smapreader')
def check():
    clockcheck()
    for name in ('rollout','advisor','slack'):
        f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if f.get('stopped') or f.get('user_paused'):raise InterruptedError('Userstop')
def tup(x):return tuple(tup(y) for y in x) if isinstance(x,list) else x
def decode(p):
    return Position(board=tuple(None if x is None else Piece(**x) for x in p['board']),hands=tuple(Hands(tup(x['counts'])) for x in p['hands']),side_to_move=p['side_to_move'],ruleset_fingerprint=p['ruleset_fingerprint'],aux_state=tup(p['aux_state']),board_width=p['board_width'],board_height=p['board_height'])
try:
    inputs={x['name']:x for x in json.loads((D/'caller-inputs.json').read_bytes())}
    for path in sorted(D.glob('positions-*.json')):
        check();raw=json.loads(path.read_bytes());case=inputs[raw['case']];rule=deserialize_ruleset(json.dumps(raw['original_rule']));c=replace((compile_semantic_ruleset(rule) if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule)),_legacy_compiled=None);engine=semantic_engine_for(c);seen=set();n=0;u=0;sc=0
        for value in raw['positions']:
            check();p=decode(value['position']);assert record_value(p)==value['position'];assert p.ruleset_fingerprint==c.ruleset_fingerprint
            expected=tuple(frozenset(x) for x in value['native_maps'])
            if p not in seen:
                actual=tuple(engine.attacked_squares(p,o,checkpoint=clockcheck) for o in (0,1));assert actual==expected
                # Scalar traversal on first distinct Position in eachcall only.
                if not seen:
                    for o in (0,1):
                        direct=frozenset(i for i in range(len(p.board)) if engine.is_square_attacked(p,i,o,checkpoint=clockcheck));assert direct==expected[o];sc+=len(p.board)
                seen.add(p);u+=1
            else:
                # Cached reader comparisons are exact samefull immutablePosition;
                # still compare everyNative observation to existingCorevalue.
                actual=tuple(engine.attacked_squares(p,o,checkpoint=clockcheck) for o in (0,1));assert actual==expected
            n+=1;total+=1
        unique+=u;scalar+=sc;rows.append({'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'case':raw['case'],'observations':n,'unique_full_positions':u,'scalar_square_checks':sc});write_json(D/'map-reader-progress.json',{'rows':rows,'observations':total,'seconds':time.monotonic()-START});print('MAP_READER',raw['case'],n,u,sc,round(time.monotonic()-START,3),flush=True)
except Exception as exc:failure={'type':type(exc).__name__,'message':str(exc)};raise
finally:write_json(D/'map-reader-result.json',{'complete':failure is None and len(rows)==10,'rows':rows,'observations':total,'unique_positions_per_call_sum':unique,'scalar_square_checks':scalar,'failure':failure,'seconds':time.monotonic()-START,'scope':'DirectCore bulkmap equality everyobservedNativefeaturePosition, scalar traversal eachfirstuniquePosition; sharedcompiledIR notindependentruleproof; no newgames/search.'})
