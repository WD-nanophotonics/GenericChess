from pathlib import Path
import sys,json,time,importlib.util,hashlib
from dataclasses import replace
from copy import copy
from unittest.mock import patch
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/root-reuse-20261017/attack-projection'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta import search
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
spec=importlib.util.spec_from_file_location('private_attack_projection',D/'readonly_attack_projection.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
START=time.monotonic();rows=[];faults=[]
def check():
    if time.monotonic()-START>=240:raise TimeoutError('Frozen240swholecaller')
    for name in ('rollout','advisor','slack'):
        f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if f.get('stopped') or f.get('user_paused'):raise InterruptedError('Userstop')
def decode(a):
    if not a:return PassAction()
    if 'from_square' in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
    return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def compile_rule(rule):return replace((compile_semantic_ruleset(rule) if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule)),_legacy_compiled=None)
control=json.loads((D/'control-result.json').read_bytes())['rows'];names=json.loads((D/'caller-plan.json').read_bytes())['roots'];cases=[]
for name in names[:8]:
    row=next(x for x in control if x['case']==name);cases.append({'name':name,'rule':row['original_rule'],'prefix':row['prefix'],'parent':row['parent']})
old=R/'.local_agent/price-measure-20261017';inputs=json.loads((old/'fresh-transfer/consumer-inputs.json').read_bytes());oldplan=json.loads((old/'root-startup-contract-plan.json').read_bytes())
for family in (5,11):
    row=next(x for x in oldplan['roots'] if x['family']==family);cases.append({'name':f'old-exposed-f{family}-p{row["ply"]}','rule':next(x['rule'] for x in inputs if x['family']==family),'prefix':row['prefix'],'parent':row['original_parent']})
write_json(D/'caller-inputs.json',cases)
class Traced(m.ReadOnlyAttackProjection):
    def __init__(self,*args):super().__init__(*args);self.trace=[]
    def index_maps(self,position):
        maps=super().index_maps(position)
        self.trace.append((position,maps))
        return maps
for index,case in enumerate(cases):
    check();rule=deserialize_ruleset(json.dumps(case['rule']));c=compile_rule(rule);s=GameSession(c)
    for a in case['prefix']:check();s.submit(decode(a))
    assert record_value(s.state)==case['parent'];before=s.state,s.to_record(),s._search_witnesses
    cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0);profile,scope=build_semantic_opportunity_profile(c,cfg)
    arms=[]
    for accelerated in ((False,True) if index%2==0 else (True,False)):
        check();t=time.monotonic();ev=Traced(rule,c,profile,cfg) if accelerated else SemanticAttackEvaluator(c,profile,cfg,backend='core');setup=time.monotonic()-t
        p=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(require_full_pv=True))
        t=time.monotonic();d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.monotonic()-t
        assert before==(s.state,s.to_record(),s._search_witnesses);assert d.native_legality_calls==0 and d.runtime_depth_balanced
        ch=copy(s)
        if d.action is not None:ch.submit(d.action)
        pv=copy(s)
        for a in d.principal_variation:pv.submit(a)
        row={'accelerated':accelerated,'decision':record_value(d),'setup_seconds':setup,'search_seconds':elapsed,'caller_plus_setup_seconds':elapsed+setup,'selected_child':record_value(ch.state),'pv_final':record_value(pv.state),'feature_native_queries':ev._projection_calls if accelerated else 0,'trace_count':len(ev.trace) if accelerated else 0}
        arms.append(row);write_json(D/f'caller-{index:02}-{int(accelerated)}.json',{'case':case,'arm':row})
        if accelerated:write_json(D/f'positions-{index:02}.json',{'case':case['name'],'original_rule':case['rule'],'positions':[{'position':record_value(pos),'native_maps':[sorted(x) for x in maps]} for pos,maps in ev.trace]})
    rows.append({'case':case['name'],'arms':arms});write_json(D/'caller-progress.json',{'rows':rows,'seconds':time.monotonic()-START});print('PROJECTION_CALLER',case['name'],[(a['accelerated'],round(a['caller_plus_setup_seconds'],3),a['decision']['completed_depth'],a['decision']['nodes'],a['feature_native_queries']) for a in arms],flush=True)
# Four exact caller-boundary controls, separate from cost pairs.
case=cases[0];rule=deserialize_ruleset(json.dumps(case['rule']));c=compile_rule(rule);s=GameSession(c);cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0);profile,_=build_semantic_opportunity_profile(c,cfg)
for kind in ('runtime_error','memory_error','cancel_after_query','deadline_after_query'):
    check();before=s.state,s.to_record(),s._search_witnesses;ev=m.ReadOnlyAttackProjection(rule,c,profile,cfg);token=CancellationToken();clock=[0.0];native=m.attacked_squares
    def query(*args):
        if kind=='runtime_error':raise RuntimeError('INJECTED_NATIVE_MAP_FAILURE')
        if kind=='memory_error':raise MemoryError('INJECTED_NATIVE_MAP_MEMORY')
        answer=native(*args)
        if kind=='cancel_after_query':token.cancel()
        if kind=='deadline_after_query':clock[0]=2.0
        return answer
    p=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False)
    error=None;decision=None
    try:
        with patch.object(m,'attacked_squares',query):
            if kind=='deadline_after_query':
                with patch.object(search.time,'monotonic',lambda:clock[0]):decision=p.choose_action(s,SearchLimits(max_depth=1,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0),cancel_token=token)
            else:decision=p.choose_action(s,SearchLimits(max_depth=1,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0),cancel_token=token)
    except (RuntimeError,MemoryError) as exc:error={'type':type(exc).__name__,'message':str(exc)}
    if kind=='runtime_error':assert error=={'type':'RuntimeError','message':'INJECTED_NATIVE_MAP_FAILURE'}
    elif kind=='memory_error':assert error=={'type':'MemoryError','message':'INJECTED_NATIVE_MAP_MEMORY'}
    else:assert decision.termination_reason==('cancelled' if kind=='cancel_after_query' else 'time_limit') and decision.runtime_depth_balanced
    assert before==(s.state,s.to_record(),s._search_witnesses)
    faults.append({'kind':kind,'error':error,'decision':record_value(decision),'full_parent_preserved':True})
    write_json(D/f'fault-{kind}.json',faults[-1]);print('PROJECTION_FAULT',kind,'PASS',flush=True)
try:m.ReadOnlyAttackProjection(replace(rule,max_ply=rule.max_ply+1),c,profile,cfg);raise AssertionError('Wrongruleaccepted')
except ValueError as exc:assert str(exc)=='ATTACK_PROJECTION_RULE_COMPILED_MISMATCH'
write_json(D/'caller-result.json',{'complete':len(rows)==10 and len(faults)==4,'calls':2*len(rows)+len(faults),'rows':rows,'faults':faults,'seconds':time.monotonic()-START,'source_sha256':hashlib.sha256((D/'readonly_attack_projection.py').read_bytes()).hexdigest(),'wrong_rule_constructor_refused':True,'scope':'Same Corefullgame authority; Native onlyS0/S1 maps. Per-position map parity stillrequiresseparatereader; notall-domain or productionadoption.'})