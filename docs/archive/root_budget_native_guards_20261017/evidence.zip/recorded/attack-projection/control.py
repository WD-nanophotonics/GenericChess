from pathlib import Path
import sys,json,time,importlib.util
from dataclasses import replace
from copy import copy
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];D=R/'.local_agent/root-reuse-20261017/attack-projection';old=R/'.local_agent/price-measure-20261017';F=D.parent/'existing-flag-transfer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from conftest import make_ruleset,king_type
spec=importlib.util.spec_from_file_location('private_attack_projection',D/'readonly_attack_projection.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
start=time.monotonic();cases=[];rows=[]
def check():
    if time.monotonic()-start>=180:raise TimeoutError('Frozen180seconds')
    for name in ('rollout','advisor','slack'):
        flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if flags.get('stopped') or flags.get('user_paused'):raise InterruptedError('Userstop')
def compile_rule(rule):return replace((compile_semantic_ruleset(rule) if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule)),_legacy_compiled=None)
def decode(a):
    if not a:return PassAction()
    if 'from_square' in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
    return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
oldinputs=json.loads((old/'consumer-inputs.json').read_bytes())
for family,prefixes in ((0,(0,2,4)),(1,(0,2,4)),(2,(0,2))):
    rule=deserialize_ruleset(json.dumps(next(x['rule'] for x in oldinputs if x['family']==family)))
    game=next(json.loads(p.read_bytes()) for p in sorted(old.glob('consumer-game-*.json')) if json.loads(p.read_bytes())['family']==family)
    for n in prefixes:cases.append((f'NP7-f{family}-p{n}',rule,[decode(x['decision']['action']) for x in game['moves'][:n]],game['initial_state'] if n==0 else game['moves'][n-1]['child']))
inputs=json.loads((F/'consumer-inputs.json').read_bytes())
for family in (3,7):
    rule=deserialize_ruleset(json.dumps(next(x['rule'] for x in inputs if x['family']==family)))
    c=compile_rule(rule);s=GameSession(c);cases.append((f'NP16-f{family}-root',rule,[],record_value(s.state)))
    if family==3:
        a=s.legal_actions()[0];s.submit(a);cases.append(('NP16-f3-child0',rule,[a],record_value(s.state)))
rule=make_ruleset(4,[king_type()],lines=['...k','....','....','K...'],max_ply=1);s=GameSession(compile_rule(rule));cases.append(('max1-kings-root',rule,[],record_value(s.state)))
assert len(cases)==12
for name,rule,prefix,expected in cases:
    check();c=compile_rule(rule);s=GameSession(c)
    for a in prefix:s.submit(a)
    assert record_value(s.state)==expected
    before=s.state,s.to_record(),s._search_witnesses
    cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0)
    profile,scope=build_semantic_opportunity_profile(c,cfg)
    base=SemanticAttackEvaluator(c,profile,cfg,backend='core');t=time.monotonic();projected=m.ReadOnlyAttackProjection(rule,c,profile,cfg);setup=time.monotonic()-t
    fields=('geometry','zones','patterns','aux_slots','triggers','declarations')
    closure={field:getattr(c.ir,field)==getattr(projected._projection_rule.ir,field) for field in fields};assert all(closure.values())
    original_maps=tuple(semantic_engine_for(c).attacked_squares(s.state.position,o) for o in (0,1))
    native_maps=projected.index_maps(s.state.position);assert original_maps==native_maps
    v0=base.evaluate(s.state);v1=projected.evaluate(s.state);assert v0==v1
    try:projected.index_maps(replace(s.state.position,ruleset_fingerprint='foreign'));raise AssertionError('Foreignaccepted')
    except ValueError as exc:assert str(exc)=='ATTACK_PROJECTION_ORIGINAL_FINGERPRINT_MISMATCH'
    assert before==(s.state,s.to_record(),s._search_witnesses)
    row={'case':name,'original_rule':json.loads(serialize_ruleset(rule)),'parent':expected,'prefix':record_value(prefix),'maps':[sorted(x) for x in original_maps],'native_maps':[sorted(x) for x in native_maps],'value':v0,'native_value':v1,'setup_seconds':setup,'ir_closure_equal':closure,'shadow_fingerprint':projected._projection_rule.ruleset_fingerprint,'projection_calls':projected._projection_calls,'full_parent_preserved':True,'foreign_fingerprint_refused':True}
    rows.append(row);write_json(D/f'control-{len(rows)-1:02}.json',row);print('ATTACK_MAP',name,[len(x) for x in original_maps],v0,round(setup,4),flush=True)
write_json(D/'control-result.json',{'complete':len(rows)==12,'states':len(rows),'owner_map_pairs':24,'seconds':time.monotonic()-start,'rows':rows,'scope':'Only frozenread-only S0/S1 maps on12states; alloriginalfullCore GameStates retained, no legal/terminal/search Native substitution or alldomain claim.'})