from pathlib import Path
import sys,importlib.util
W=Path.cwd().resolve()
sys.meta_path[:]=[f for f in sys.meta_path if not getattr(f,'__module__','').startswith('__editable___generic_chess_')]
sys.path[:]=[str(W)]+[p for p in sys.path if p and Path(p).resolve()!=W and not (Path(p)/'generic_chess').is_dir()]
import generic_chess
from generic_chess import native
assert Path(generic_chess.__file__).resolve().is_relative_to(W)
assert native.native_available()
assert Path(native._module().__file__).resolve().is_relative_to(W)
assert native._module().native_capabilities()['semantic_state_guard_comparisons'] is True
import runpy
runpy.run_path(str(W/'.local_agent/root-reuse-20261017/runtime-reader.py'),run_name='__main__')
code=0
wrong=[n for n,m in sys.modules.items() if n.startswith('generic_chess') and getattr(m,'__file__',None) and not Path(m.__file__).resolve().is_relative_to(W)]
assert not wrong,wrong
print('ISOLATED_REBUILT_NATIVE_SOURCE_MODULES',len([n for n in sys.modules if n.startswith('generic_chess')]),'PASS' if code==0 else 'FAIL',flush=True)
raise SystemExit(code)
