import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/generated8_20261008';dest.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
analysis=json.loads((p/'analysis.json').read_bytes());assert analysis['complete']
for name,digest in analysis['inputs'].items():assert sha((p/(name+'.json')).read_bytes())==digest
files=sorted(x for x in p.iterdir() if x.suffix in ('.py','.json'))+[root/'tests/rule_semantics_ir_fixtures.py'];members=[];archive=dest/'sources-raw.zip';assert not archive.exists()
for name in ('transfer','pvs','curve','analysis'):
 data=json.loads((p/(name+'.json')).read_bytes());producer='analyze' if name=='analysis' else name;assert data['producer_sha256']==sha((p/(producer+'.py')).read_bytes())
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  body=f.read_bytes();name=f.relative_to(root).as_posix();z.writestr(name,body);members.append({'path':name,'bytes':len(body),'sha256':sha(body)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for x in members:assert sha((Path(tmp)/x['path']).read_bytes())==x['sha256']
index={'base_commit':'ea934db19a9e39218e9a690f150a1d33286d31c7','archive_sha256':sha(archive.read_bytes()),'members':members,'extracted_rehashed':True,'excluded':'User/private inputs, raw Slack/accounts, credentials and active workflow state.'}
(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
summary={'complete':True,'scope':'Four fresh8x8hybrid rules; separately declared existing-PVS pilot and fair paired development curve. Fixed Native attack evaluator/TT/order/q0; baseline Core/Native legality varied alone. PVS is opt-in and no default changes. Original caps and partial depths retained. Same-depth score parity is not strength or material utility.','archive':'../../archive/generated8_20261008/index.json','archive_sha256':index['archive_sha256'],'analysis':analysis}
(root/'docs/research/data/generated8_20261008.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());print({'members':len(members),'bytes':archive.stat().st_size})
