import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'curve.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'fixture_sha256':sha(root/'tests/rule_semantics_ir_fixtures.py'),'declaration':'Four fresh generator seeds202610082000..2003,6x6 bilateral_random/hybrid, existing simple generator filters. Recombine known zone-capacity P-drop with consumed temp_right eq0 guard and expiring quiet current-type change on generatedX->P; no assumed chess movement/strength.12public plies, deterministic coverage policy capture>semantic>drop>remaining with lexical ties; stop terminal/noactions, retain event zeros. Final reached frontier: independent bounded Coredepth2 reference4000leaf/3sec and paired Core/Native legality with fixed Native-semantic evaluator search depth2/3 each2cold repeats8192nodes/5sec. <=32searchcalls/300sec. No price selection/defaults, no human data or additional workers. Detect compile/parity/history/interface failures, not playing performance.','cases':[]};write_record(out,r)
r['declaration']='New paired development curve after8192node pilot; retain original caps, no holdout restoration. All four8x8roots, baseline versus existing PVS only, Native legality/attack, TT/order,q0,depth3. BOTH methods get16384/32768nodes and20sec, two cold rotated repeats,32calls<=660sec. Determine completed same-depth score parity, real node/work curves and whether PVS savings generalize across this exposed cohort; no default or price tuning. Partial scores remain unknown for requested depth.'
r['cases']=[]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.actions import action_from_dict
try:
 source=json.loads((p/'transfer.json').read_bytes());assert source['complete']
 for old in source['cases']:
  if old['terminal']['status']!='ongoing':continue
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for e in old['route']:s.submit(action_from_dict(e['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':old['seed'],'searches':[]};r['cases'].append(case)
  for cap in (16384,32768):
   for repeat in (0,1):
    for pvs in ((False,True) if repeat==0 else (True,False)):
     assert time.perf_counter()-started<660
     assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
     player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_pvs=pvs));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=cap,max_time_seconds=20,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);case['searches'].append({'cap':cap,'pvs':pvs,'repeat':repeat,'wall_seconds':time.perf_counter()-t,'decision':record_value(d)});write_record(out,r)
   print(old['seed'],cap,[(x['pvs'],x['decision']['completed_depth'],x['decision']['nodes'],x['decision']['score']) for x in case['searches'] if x['cap']==cap],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
