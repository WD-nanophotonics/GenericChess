import json,hashlib,statistics
from pathlib import Path
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
raw={name:json.loads((p/(name+'.json')).read_bytes()) for name in ('transfer','pvs','curve')};assert all(x['complete'] for x in raw.values())
r={'complete':True,'producer_sha256':sha(Path(__file__)),'inputs':{n:sha(p/(n+'.json')) for n in raw},'rows':[],'total_seconds':{n:d['seconds'] for n,d in raw.items()}}
sig=lambda d:tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','completed_depth','principal_variation'))
for base,pilot,curve in zip(raw['transfer']['cases'],raw['pvs']['cases'],raw['curve']['cases']):
 assert base['seed']==pilot['seed']==curve['seed'];row={'seed':base['seed'],'legal_actions':base['legal_actions'],'reference':base['reference'],'original':[],'pvs_pilot':[],'curve':[]};r['rows'].append(row)
 for native in (False,True):
  xs=[x for x in base['searches'] if x['native']==native]
  if all(x['decision']['termination_reason']!='time_limit' for x in xs):assert sig(xs[0]['decision'])==sig(xs[1]['decision'])
  row['original'].append({'native':native,'depths':[x['decision']['completed_depth'] for x in xs],'nodes':[x['decision']['nodes'] for x in xs],'scores':[x['decision']['score'] for x in xs],'seconds':[x['wall_seconds'] for x in xs],'termination':[x['decision']['termination_reason'] for x in xs]})
 for depth in (2,3):
  xs=[x for x in pilot['searches'] if x['depth']==depth];assert sig(xs[0]['decision'])==sig(xs[1]['decision'])
  if xs[0]['decision']['completed_depth']==2:assert xs[0]['decision']['score']==base['reference']['score']
  row['pvs_pilot'].append({'requested_depth':depth,'completed_depth':xs[0]['decision']['completed_depth'],'score':xs[0]['decision']['score'],'nodes':xs[0]['decision']['nodes'],'seconds':[x['wall_seconds'] for x in xs]})
 for cap in (16384,32768):
  methods={mode:[x for x in curve['searches'] if x['cap']==cap and x['pvs']==mode] for mode in (False,True)}
  for xs in methods.values():assert sig(xs[0]['decision'])==sig(xs[1]['decision'])
  a,b=(methods[mode][0]['decision'] for mode in (False,True));common=a['completed_depth']==b['completed_depth'];equal=a['score']==b['score'] if common else None
  if common:assert equal
  row['curve'].append({'cap':cap,'same_depth_score_equal':equal,'same_action':a['action']==b['action'] if common else None,'methods':[{'pvs':mode,'depth':xs[0]['decision']['completed_depth'],'score':xs[0]['decision']['score'],'nodes':xs[0]['decision']['nodes'],'evaluation_calls':xs[0]['decision']['evaluation_calls'],'pvs_researches':xs[0]['decision']['pvs_researches'],'seconds':[x['wall_seconds'] for x in xs],'termination':xs[0]['decision']['termination_reason']} for mode,xs in methods.items()]})
 a,b=(methods[mode][0]['decision'] for mode in (False,True));assert a['completed_depth']==b['completed_depth']==3 and a['score']==b['score']
 row['completed_node_reduction_fraction']=1-b['nodes']/a['nodes'];row['completed_wall_ratio_pvs_over_baseline']=statistics.mean(x['wall_seconds'] for x in methods[True])/statistics.mean(x['wall_seconds'] for x in methods[False])
(p/'analysis.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
print(json.dumps([dict(seed=x['seed'],node_reduction=x['completed_node_reduction_fraction'],wall_ratio=x['completed_wall_ratio_pvs_over_baseline']) for x in r['rows']],indent=2))
