import os,sys,sysconfig,subprocess,time,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
out=R/'.local_agent/q0-ordering-view-digest-fault-20261012';out.mkdir(exist_ok=True)
srcdir=R/'.local_agent/q0-ordering-view-20261012/ordering_view'
base=(srcdir/'native_module.c').read_text(encoding='utf-8');header=(srcdir/'native_semantic_runtime.h').read_text(encoding='utf-8');rt=(srcdir/'native_semantic_runtime.c').read_text(encoding='utf-8')
a='    uint64_t ordering_view_calls;';assert base.count(a)==1
base=base.replace(a,a+'\n    uint64_t ordering_shadow_calls;\n    uint64_t ordering_shadow_mismatches;')
a='        if (!made) continue;';# onlynewmatchedblock? policy legacyotherusesinline not thisunique
assert base.count(a)==1
base=base.replace(a,'''        if (material_only) {
            GCSemanticPosition full_child;
            int full_made = gc_semantic_runtime_make_checked(
                &full_child, ctx->rules, position, actions->data[i]);
            ctx->ordering_shadow_calls++;
            int mismatch = full_made != made;
            if (made && full_made) {
                GCSemanticOrderingKey left, right;
                gc_semantic_order_key_from_position(&left, &child);
                gc_semantic_order_key_from_position(&right, &full_child);
                mismatch |= !gc_semantic_order_key_equal(&left, &right);
                mismatch |= child.ply != full_child.ply;
                mismatch |= child.history_len != position->history_len;
                mismatch |= full_child.history_len != position->history_len + 1;
                mismatch |= memcmp(child.history_digest, position->history_digest,
                    position->history_len * sizeof(position->history_digest[0])) != 0;
                mismatch |= memcmp(child.history_actor, position->history_actor,
                    position->history_len * sizeof(uint8_t)) != 0;
                mismatch |= memcmp(child.history_gave_check, position->history_gave_check,
                    position->history_len * sizeof(uint8_t)) != 0;
                mismatch |= gc_semantic_probe_material(ctx->rules, &child,
                    &ctx->ordering_profile, NULL) != gc_semantic_probe_material(
                    ctx->rules, &full_child, &ctx->ordering_profile, NULL);
            }
            if (mismatch) {
                ctx->ordering_shadow_mismatches++; ctx->control = 4; free(ordered); return 0;
            }
        }
        if (!made) continue;''')
a='        gc_semantic_set_u64(out, "ordering_view_calls", ctx.ordering_view_calls) != 0 ||';assert base.count(a)==1
base=base.replace(a,'        gc_semantic_set_u64(out, "ordering_shadow_calls", ctx.ordering_shadow_calls) != 0 ||\n        gc_semantic_set_u64(out, "ordering_shadow_mismatches", ctx.ordering_shadow_mismatches) != 0 ||\n'+a)
# A private paired API additionally exposes the source-level capacity corner.
where=base.index('static PyObject *gc_semantic_action_delivers_check_debug')
debug='''static PyObject *gc_ordering_view_pair_debug(PyObject *self, PyObject *args) {
    (void)self; PyObject *rules_cap, *pos_cap; unsigned long long action; int force_capacity;
    if (!PyArg_ParseTuple(args, "OOKi", &rules_cap, &pos_cap, &action, &force_capacity)) return NULL;
    GCSemanticRules *rules = PyCapsule_GetPointer(rules_cap, GC_SEM_RULES_CAPSULE);
    GCSemanticPosition *input = PyCapsule_GetPointer(pos_cap, GC_SEM_POSITION_CAPSULE);
    if (!rules || !input) return NULL;
    GCSemanticPosition parent = *input, full, view;
    if (force_capacity) {
        memset(parent.history_digest, 0, sizeof(parent.history_digest));
        memset(parent.history_actor, 0, sizeof(parent.history_actor));
        memset(parent.history_gave_check, 0, sizeof(parent.history_gave_check));
        memset(parent.history_lo, 0, sizeof(parent.history_lo));
        memset(parent.history_hi, 0, sizeof(parent.history_hi));
        parent.history_len = GC_SEM_MAX_PLY + 1;
    }
    int a = gc_semantic_runtime_make_checked(&full, rules, &parent, action);
    int b = gc_semantic_runtime_make_ordering_view(&view, rules, &parent, action);
    return Py_BuildValue("{s:i,s:i,s:i}", "full_made", a, "view_made", b, "forced_capacity", force_capacity);
}

'''
base=base[:where]+debug+base[where:]
needle='    {"semantic_make_checked", gc_semantic_make_checked, METH_VARARGS,'
assert base.count(needle)==1
base=base.replace(needle,'    {"research_ordering_view_pair", gc_ordering_view_pair_debug, METH_VARARGS, "Private paired boundary diagnostic"},\n'+needle)
needle='    return gc_semantic_runtime_make_mode(child, r, parent, action, 1, 0);';assert rt.count(needle)==1
guarded=rt.replace(needle,'    if (parent->history_len >= GC_SEM_MAX_PLY + 1) return 0;\n'+needle)
write_record(out/'declaration.json',dict(question='Does privateview preserve checked failure when serializer returnsfalse?',arms=['shadow_unbounded','shadow_capacity_guarded'],calls=1,roots=['actualChess'],depth=0,orders=2,seconds=64,max_nodes=None,cache=False,scope='Privateallcandidate pairedfullchecked shadow; fullsourceeffects/postconditions retained. Synthetic historycapacity APIcorner checks fullrefusal vsrecord_history0; notclaimedreachablenormalgame becausemax_ply<=1024. Newguardpreservesrefusal; no productadoption orotherguard broadening. Shadowextra worknotdeploymentspeed; no training/userUI/humanfit. Max256s.'))
rows=[]
for arm,rtsrc in [('digest_failure',guarded)]:
 d=out/arm;d.mkdir(exist_ok=True)
 for name,s in [('native_module.c',base),('native_semantic_runtime.c',rtsrc),('native_semantic_runtime.h',header)]: (d/name).write_text(s,encoding='utf-8',newline='\n')
 key=(R/'generic_chess/_native/native_semantic_key.c').read_text()
 needle='int gc_semantic_position_key_digest(const GCSemanticRules *r, const GCSemanticPosition *p, char out_hex[65]) {'
 assert key.count(needle)==1
 key='int gc_research_digest_failure = 0;\n'+key.replace(needle,needle+'\n    if (gc_research_digest_failure) return 0; /* Private paired-call failure. */')
 (d/'native_semantic_key.c').write_text(key,encoding='utf-8')
 module=(d/'native_module.c').read_text()
 module=module.replace('    int a = gc_semantic_runtime_make_checked(&full, rules, &parent, action);','    extern int gc_research_digest_failure;\n    gc_research_digest_failure = 1;\n    int a = gc_semantic_runtime_make_checked(&full, rules, &parent, action);')
 module=module.replace('    return Py_BuildValue("{s:i,s:i,s:i}", "full_made", a, "view_made", b, "forced_capacity", force_capacity);','    gc_research_digest_failure = 0;\n    return Py_BuildValue("{s:i,s:i,s:i}", "full_made", a, "view_made", b, "forced_capacity", force_capacity);')
 (d/'native_module.c').write_text(module,encoding='utf-8')
 binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+str(d),'-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(d/f.name if f.name in ['native_module.c','native_semantic_runtime.c','native_semantic_key.c'] else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:]
 rows.append(dict(arm=arm,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),seconds=time.perf_counter()-t));print(arm,'built',flush=True)
write_record(out/'build.json',rows)
