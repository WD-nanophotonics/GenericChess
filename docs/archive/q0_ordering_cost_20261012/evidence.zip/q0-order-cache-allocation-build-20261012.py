import os,sys,sysconfig,subprocess,time,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
out=R/'.local_agent/q0-order-cache-allocation-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
base=(R/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
a='    engine->busy = 0;\n    Py_DECREF(call_args);\n    return result;';assert base.count(a)==1
s=base.replace(a,'''    engine->busy = 0;
    Py_DECREF(call_args);
    /* Allocated table bytes differ from active lookup capacity and from RSS. */
    if (result != NULL && gc_semantic_set_u64(
            result, "ordering_cache_allocated_bytes",
            engine->ordering_cache == NULL ? 0 : sizeof(*engine->ordering_cache)) != 0) {
        Py_DECREF(result);
        return NULL;
    }
    return result;''')
a='''    engine->ordering_cache = (GCSemanticOrderingCache *)calloc(
        1, sizeof(*engine->ordering_cache));
    if (engine->ordering_cache == NULL) {
        free(engine);
        PyErr_NoMemory();
        return NULL;
    }
    engine->ordering_cache->profile_generation = 1;'''
assert s.count(a)==1
v=s.replace(a,'''    if (ordering_cache_enabled) {
        engine->ordering_cache = (GCSemanticOrderingCache *)calloc(
            1, sizeof(*engine->ordering_cache));
        if (engine->ordering_cache == NULL) {
            free(engine);
            PyErr_NoMemory();
            return NULL;
        }
        engine->ordering_cache->profile_generation = 1;
    }''')
write_record(out/'declaration.json',dict(question='Does explicitlydisabled orderingcache avoid allocation while retaining actualsearch/bind/cancel lifecycle?',base_sha='7b988c9f247fd3eb96ca17daedf28e5c4d93b3cd',arms=['old_allocated','skip_disabled'],scope='Observed existingFalseflag stillcalloc11.1MB. Onlyskipdisabledconstructorallocation andreportactualsizeof retainedtable in persistentkerneloutput, notRSS. DefaultTrue, profiles, rule/history/TT/ordering semantics unchanged. Existingfree(NULL) cleanup supported; bindings recreatecapsulehonorflag. No UI/default/expandingcache ormodel training. Private testsbeforeproduction.'))
rows=[]
for name,src in [('old_allocated',s),('skip_disabled',v)]:
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text(src,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(p if f.name=='native_module.c' else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:]
 rows.append(dict(arm=name,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),seconds=time.perf_counter()-t));print(name,'built',flush=True)
write_record(out/'build.json',rows)
