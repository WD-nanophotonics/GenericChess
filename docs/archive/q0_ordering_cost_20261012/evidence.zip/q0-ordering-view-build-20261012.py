import os,sys,sysconfig,subprocess,time,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
out=R/'.local_agent/q0-ordering-view-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
base=(R/'generic_chess/_native/native_module.c').read_text(encoding='utf-8');rt=(R/'generic_chess/_native/native_semantic_runtime.c').read_text(encoding='utf-8');header=(R/'generic_chess/_native/native_semantic_runtime.h').read_text(encoding='utf-8')
helper='''int gc_semantic_runtime_make_ordering_view(GCSemanticPosition *child,
    const GCSemanticRules *r, const GCSemanticPosition *parent, uint64_t action) {
    return gc_semantic_runtime_make_mode(child, r, parent, action, 1, 0);
}

'''
rt=rt.replace('/* Availability never consumes',helper+'/* Availability never consumes',1)
header=header.replace('/* Readonly S0-S4 action existence probe;', 'int gc_semantic_runtime_make_ordering_view(GCSemanticPosition *, const GCSemanticRules *, const GCSemanticPosition *, uint64_t);\n\n/* Readonly S0-S4 action existence probe;',1)
a='    uint64_t ordering_cache_misses;';assert base.count(a)==1
base=base.replace(a,a+'\n    uint64_t ordering_view_calls;\n    uint64_t ordering_trial_count;\n    uint64_t ordering_history_appends;\n    uint64_t ordering_key_computations;\n    uint64_t ordering_attack_checks;')
a='''        if (!gc_semantic_runtime_make_checked(
                &child, ctx->rules, position, actions->data[i])) {
            continue;
        }'''
assert base.count(a)==1
block='''        int material_only = ctx->ordering_cache == NULL &&
            ctx->ordering_profile.compact == NULL && ctx->ordering_profile.policy == NULL &&
            !ctx->ordering_profile.spatial_supplied && !ctx->ordering_profile.localized_control_supplied &&
            ctx->ordering_profile.dynamic[0] == 0 && ctx->ordering_profile.dynamic[1] == 0 &&
            ctx->ordering_profile.dynamic[2] == 0;
        GCSemanticRuntimeAudit ordering_audit = {0};
        gc_semantic_runtime_audit_start(&ordering_audit);
        int made = USE_VIEW && material_only
            ? gc_semantic_runtime_make_ordering_view(&child, ctx->rules, position, actions->data[i])
            : gc_semantic_runtime_make_checked(&child, ctx->rules, position, actions->data[i]);
        gc_semantic_runtime_audit_stop();
        if (USE_VIEW && material_only) ctx->ordering_view_calls++;
        ctx->ordering_trial_count += ordering_audit.s3_trial_count;
        ctx->ordering_history_appends += ordering_audit.history_appends;
        ctx->ordering_key_computations += ordering_audit.child_canonical_key_computations;
        ctx->ordering_attack_checks += ordering_audit.attack_check_calls;
        if (!made) continue;'''
base=base.replace(a,block)
a='        gc_semantic_set_u64(out, "root_tie_refinements", ctx.root_tie_refinements) != 0 ||';assert base.count(a)==1
extra=''.join('        gc_semantic_set_u64(out, "'+k+'", ctx.'+k+') != 0 ||\n' for k in ['ordering_view_calls','ordering_trial_count','ordering_history_appends','ordering_key_computations','ordering_attack_checks'])
base=base.replace(a,extra+a)
write_record(out/'declaration.json',dict(question='Do discarded purematerial ordering children need canonical history andgavecheck construction?',base_sha='7b988c9f plus tested disabledcacheallocation fix',calls=8,roots=['generated1091-turn2','Shogi0'],depth=5,arms=['full_history','ordering_view'],orders=[0,1],seconds=64,max_nodes=None,TT_MiB=1,min_depth=2,ordering_cache_enabled=False,q=0,scope='Private matchedcounter versions. All exactactionbinding/effects/aux reset/triggers/invariants/postconditions andparenthistory retained; only finalunusedhistoryappend/digest/gavecheck omitted inlocaldiscardedorderingchild. Guarduncached purematerial, nonzero dynamic/spatial/localized/compact/policy fallbacks normalpath. Searchrecursion alwaysoriginalmake_checked/fullhistory; no terminallabel/historytask shrink orglobaltransient flag. Actualmechanism counters perorderingtrial, fulltuple/legality/cost; noclaimallscope/proof/adoption. Expectedunder2min/max512s; oldrecords frozen.'))
rows=[]
for arm,flag in [('full_history',0),('ordering_view',1)]:
 d=out/arm;d.mkdir(exist_ok=True);src=base.replace('USE_VIEW',str(flag))
 for name,s in [('native_module.c',src),('native_semantic_runtime.c',rt),('native_semantic_runtime.h',header)]: (d/name).write_text(s,encoding='utf-8',newline='\n')
 binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+str(d),'-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(d/f.name if f.name in ['native_module.c','native_semantic_runtime.c'] else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:]
 rows.append(dict(arm=arm,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in d.glob('*.[ch]')},binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),seconds=time.perf_counter()-t));print(arm,'built',flush=True)
write_record(out/'build.json',rows)
s=(R/'.local_agent/q0-order-cache-capacity-run-20261012.py').read_text(encoding='utf-8').replace('q0-order-cache-capacity-20261012','q0-ordering-view-20261012').replace('sets4096','full_history').replace('sets8192','ordering_view').replace('ordering_min_depth=2)','ordering_min_depth=2,ordering_cache_enabled=False)')
(R/'.local_agent/q0-ordering-view-run-20261012.py').write_text(s,encoding='utf-8',newline='\n')
