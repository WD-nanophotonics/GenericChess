import sys,json,importlib.util,sysconfig,time
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));import generic_chess.native as native
from scripts.research_record import write_record
p=R/'.local_agent/q0-order-cache-allocation-20261012/old_allocated'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('pytest_trace._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m
import pytest
args=['-q','-p','no:cacheprovider','--basetemp=.local_agent/pytest-q0-cache-oldalloc','tests/product/test_f102_exact_ordering_cache.py::test_cache_enabled_and_disabled_are_search_exact_and_warm_hits_are_reported'];t=time.perf_counter();code=pytest.main(args);write_record(R/'.local_agent/q0-order-cache-allocation-20261012/sensitivity-old-allocation.json',dict(exit_code=code,seconds=time.perf_counter()-t,targets=args,private_module=True));sys.exit(code)
