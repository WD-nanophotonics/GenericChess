import json,sys,sysconfig,importlib.util
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
import generic_chess.native as native
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as ns
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
out=R/'.local_agent/q0-ordering-view-shadow-20261012'
write_record(out/'boundary-declaration.json',dict(calls=4,arms=['shadow_unbounded','shadow_capacity_guarded'],controls=['normalNativeposition','artificialcapacityfilledprefix'],scope='Nativeposition copy withforced history_len1025 andply0 is syntheticcapacity refusal corner, notclaimedreachable/fullgame. Parentoriginalunchanged. Oldfullchecked refuses duecapacity; viewmustnotaccept beyondsameboundary. Normal max_ply<=1024 may precludecorner inreachableplay.')) 
rows=[]
for arm in ['shadow_unbounded','shadow_capacity_guarded']:
 p=out/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('boundaryview_'+arm+'._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c);nr=NativeSemanticLegalityProvider.try_create(c,strict=True).native_rules;pos=pack_semantic_search_position(c,nr,s);before=ns.snapshot(nr,pos);a=ns.guarded_actions(nr,pos)[0]
 for forced in [0,1]:
  r=m.research_ordering_view_pair(nr.capsule,pos,a,forced);assert ns.snapshot(nr,pos)==before
  if not forced:assert r['full_made']==r['view_made']==1
  elif arm=='shadow_unbounded':assert r['full_made']==0 and r['view_made']==1
  else:assert r['full_made']==r['view_made']==0
  rows.append(dict(arm=arm,force_capacity=forced,result=r,parent_unchanged=True))
write_record(out/'boundary-result.json',dict(complete=True,rows=rows,decision='Guardhistorycapacity beforeusing discardedview; boundednormalview unchanged. Sourcecorner isnotclaimeduserincident orreachablegame.'))
d=json.loads((out/'run/result.json').read_bytes());assert d['complete'] and len(d['rows'])==4
count=sum(x['raw']['ordering_shadow_calls'] for x in d['rows']);assert count>0 and all(x['raw']['ordering_shadow_mismatches']==0 for x in d['rows'])
write_record(out/'run/verification.json',dict(calls=4,allcandidate_pair_checks=count,mismatches=0,legal_status_physical_material_ply_and_live_history_prefix=True,extra_shadow_cost_not_deployment=True))
print('syntheticboundaryoldfails/newguardpasses; actualcandidatepairs',count,'mismatch0')
