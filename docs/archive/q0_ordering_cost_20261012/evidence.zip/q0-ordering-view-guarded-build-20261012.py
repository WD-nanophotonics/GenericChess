import os,sys,sysconfig,subprocess,time,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
out=R/'.local_agent/q0-ordering-view-guarded-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
original=R/'.local_agent/q0-ordering-view-20261012/ordering_view';base=(original/'native_module.c').read_text(encoding='utf-8')
rt=(R/'.local_agent/q0-ordering-view-shadow-20261012/shadow_capacity_guarded/native_semantic_runtime.c').read_text(encoding='utf-8');header=(original/'native_semantic_runtime.h').read_text(encoding='utf-8')
needle='        if (1 && material_only) ctx->ordering_view_calls++;';assert base.count(needle)==1
cancel=base.replace(needle,needle+'\n        if (ctx->ordering_view_calls == 5 && ctx->cancel != NULL) gc_cancel_flag_request(ctx->cancel);')
write_record(out/'declaration.json',dict(question='Do guarded transientordering andactual during-ordering cancellation preserve parent/publishediteration/persistentTT recovery?',arms=['guarded','cancel_after_five'],scope='Correctsynthetichistorycapacityrefusal sourcecorner; allnormal fullrules/history/effect/postcondition guards unchanged. Actualnativeflag injectedafter fifthorderingview only whennonNULLtoken, cachedcomplex fallback remains; noUI/default/OSlatencyclaim. Four savedroots fixedD4 controls/cancel/sameTT/cold; nodes/wallbounds declaredinproducer, smallrun.'))
rows=[]
for arm,s in [('guarded',base),('cancel_after_five',cancel)]:
 d=out/arm;d.mkdir(exist_ok=True)
 for name,text in [('native_module.c',s),('native_semantic_runtime.c',rt),('native_semantic_runtime.h',header)]: (d/name).write_text(text,encoding='utf-8',newline='\n')
 binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+str(d),'-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(d/f.name if f.name in ['native_module.c','native_semantic_runtime.c'] else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:]
 rows.append(dict(arm=arm,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),seconds=time.perf_counter()-t));print(arm,'built',flush=True)
write_record(out/'build.json',rows)
