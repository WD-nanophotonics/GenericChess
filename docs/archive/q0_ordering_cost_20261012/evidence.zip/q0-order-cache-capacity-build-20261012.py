import os,sys,sysconfig,subprocess,time,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
out=R/'.local_agent/q0-order-cache-capacity-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
s=(R/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
write_record(out/'declaration.json',dict(question='Does doubling orderingcachecapacity reduce actual completed-horizon cost enough to justify11MB additionalmemory?',base_sha='7b988c9f247fd3eb96ca17daedf28e5c4d93b3cd',calls=8,roots=['generated1091-turn2','Shogi0'],depth=5,arms=['sets4096','sets8192'],orders=[0,1],seconds=64,max_nodes=None,TT_MiB=1,min_depth=2,root_hint=None,q=0,scope='Private singlechangedconstant sets4096to8192, ways1 andexactstructuralkey/profile/historydigest unchanged. Coldengineeachcell; ordinaryconcurrentload/counterbalancedorder. Fulltuple/visitedwork/actualscorecalls/time/memory, no equalmemory or strengthclaim. Oldresultswindows immutable, no capacitytuning afterresults orholdoutclaim. Expectedunder2min; max512s<9min; no worker/fee/default/UIchange.'))
rows=[]
for name,sets in [('sets4096',4096),('sets8192',8192)]:
 needle='#define GC_SEMANTIC_ORDER_CACHE_SETS 4096u';assert s.count(needle)==1;v=s.replace(needle,'#define GC_SEMANTIC_ORDER_CACHE_SETS '+str(sets)+'u')
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text(v,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(p if f.name=='native_module.c' else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:]
 rows.append(dict(arm=name,sets=sets,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),seconds=time.perf_counter()-t));print(name,'built',flush=True)
write_record(out/'build.json',rows)
p=R/'.local_agent/NEXT_WORK.md';memo=p.read_text(encoding='utf-8');old=next(x for x in memo.splitlines() if x.startswith('Segment:'));memo=memo.replace(old,'Segment: f27603db-ae52-4a51-a7fd-f3ef83899cfd; ACTIVE;UTC2026-10-12T12:16:25.002930+00:00;retainclock.');assert len(memo.encode())<=2048;p.write_text(memo,encoding='utf-8',newline='\n')
