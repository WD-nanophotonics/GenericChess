from pathlib import Path
p=Path('generic_chess/ai/alphabeta/native_legality.py');d=p.read_bytes();old=b'        if engine is None:\n            return None\n';assert d.count(old)==1
new=old+b'        # Installed kernels bind these filters to the affected piece instead\n        # of the action actor. Preserve Core legality for this supported subset.\n        if any(\n            effect.kind in ("move", "shift", "remove")\n            and effect.piece_type_ref is not None\n            and effect.piece_type_ref.kind in ("action_base", "action_current")\n            for pattern in engine._patterns for effect in pattern.effects\n        ):\n            return None\n'
p.write_bytes(d.replace(old,new))
