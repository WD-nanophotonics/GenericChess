from pathlib import Path
import subprocess
p=Path('tests/product/test_native_wildcard_capture.py');d=p.read_bytes();base=subprocess.check_output(['git','show','HEAD:tests/product/test_native_wildcard_capture.py']);print('head bytes/crlf',len(base),base.count(b'\r\n'),'local',len(d),d.count(b'\r\n'));marker=b'def test_actor_relative_victim_filter_uses_core_fallback():';i=d.index(marker);prefix=d[:i];tail=d[i:];assert prefix.replace(b'\r\n',b'\n').rstrip()==base.replace(b'\r\n',b'\n').rstrip();p.write_bytes(base.rstrip(b'\r\n')+b'\n\n\n'+tail.replace(b'\r\n',b'\n'))
