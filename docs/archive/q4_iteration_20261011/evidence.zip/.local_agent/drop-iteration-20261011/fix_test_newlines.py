from pathlib import Path
import subprocess
p=Path('tests/product/test_native_wildcard_capture.py');d=p.read_bytes();base=subprocess.check_output(['git','show','HEAD:tests/product/test_native_wildcard_capture.py']);assert b'\r' not in base and d.startswith(base);tail=d[len(base):];p.write_bytes(base+tail.replace(b'\r\n',b'\n'))
