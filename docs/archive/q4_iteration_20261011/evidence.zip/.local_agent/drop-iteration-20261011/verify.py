import json,re
from pathlib import Path
b=Path('.local_agent/drop-iteration-20261011');s=(b/'final-full-regression.log').read_text();print('dots',sum(len(x.split()[0]) for x in s.splitlines() if re.match(r'^\.+(?:\s|$)',x)),'failure_summary',('FAILURES' in s or 'FAILED' in s))
r=json.loads(Path('.local_agent/q4-thin-bridge-20261011/result.json').read_text());out={}
for root in sorted({x['root'] for x in r}):
 a=[x for x in r if x['root']==root];out[root]={'trace_match':len({x['trace'] for x in a})==1,'work_match':all(x['work']==a[0]['work'] for x in a),'decision_match':len({(x['move'],x['score'],x['reason']) for x in a})==1}
print(out);Path('.local_agent/q4-thin-bridge-20261011/verification.json').write_text(json.dumps(out,indent=2))
