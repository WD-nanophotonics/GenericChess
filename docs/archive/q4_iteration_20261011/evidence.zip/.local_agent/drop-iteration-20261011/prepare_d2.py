from pathlib import Path
s=Path('.local_agent/drop_iteration_run.py').read_text(encoding='utf-8-sig')
s=s.replace("B=Path('.local_agent/drop-iteration-20261011')","B=Path('.local_agent/drop-d2-cost-20261011')")
s=s.replace('for obs in (False,True):','for native in (True,False):\n  obs=True')
s=s.replace('use_native_semantic_legality=True','use_native_semantic_legality=native').replace('max_depth=12,max_nodes=8192,max_time_seconds=120','max_depth=2,max_nodes=1000000,max_time_seconds=256')
s=s.replace("'observer':obs","'native_requested':native").replace("'ledger':ledger","'ledger':ledger.copy()")
s=s.replace("print(obs,wall,v.completed_depth,v.score,v.termination_reason,flush=True)","print(native,wall,v.completed_depth,v.score,v.termination_reason,flush=True);ledger=[]")
Path('.local_agent/drop_d2_cost.py').write_text(s,encoding='utf-8')
