import json
from pathlib import Path
p=Path('.local_agent/drop-iteration-20261011');r=json.loads((p/'result.json').read_text(encoding='utf-8-sig'))
a,b=r['rows'];keys=[k for k,v in a['stats'].items() if isinstance(v,(int,bool,str,dict)) and not k.endswith('seconds')]
diff={k:[a['stats'][k],b['stats'][k]] for k in keys if a['stats'][k]!=b['stats'][k]};print('diff',diff)
for x in r['ledger']:print(x['iteration'],x['ply'],x['action'],x['complete'],round(x['wall'],3),x['work']['nodes'],x['work']['qnodes'],x['work']['runtime_pushes'],x.get('score'),x.get('abort'))
(p/'analysis.json').write_text(json.dumps({'counter_difference':diff,'decision_same':a['decision']['action']==b['decision']['action'] and a['decision']['score']==b['decision']['score'],'root_restored':all(x['root_restored'] for x in r['rows']),'iteration_records':[x for x in r['ledger'] if x['ply']==0],'branches': [x for x in r['ledger'] if x['iteration']==2 and x['ply']==1]},indent=2))
