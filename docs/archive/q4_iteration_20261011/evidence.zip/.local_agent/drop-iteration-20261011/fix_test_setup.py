from pathlib import Path
p=Path('tests/product/test_native_wildcard_capture.py');s=p.read_bytes();old=b'SearchPathRuntime(compiled, state)';assert s.count(old)==1;p.write_bytes(s.replace(old,b'SearchPathRuntime(state, compiled)'))
