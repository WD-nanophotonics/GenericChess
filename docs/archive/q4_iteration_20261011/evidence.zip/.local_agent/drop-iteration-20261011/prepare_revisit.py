from pathlib import Path
s=Path('.local_agent/drop_iteration_run.py').read_text(encoding='utf-8-sig')
s=s.replace("B=Path('.local_agent/drop-iteration-20261011')","B=Path('.local_agent/drop-q-revisit-20261011')")
s=s.replace('rows=[];ledger=[];iteration=None','rows=[];ledger=[];iteration=None\nfrom collections import Counter\nrevisits=Counter();positions=Counter();qdepths=Counter();windows=Counter();oq=sm._quiescence_runtime\ndef qobserve(alpha,beta,ply,qdepth,ctx):\n rt=ctx.runtime\n key=(rt.search_key(),qdepth,sm._ordinary_qdepth_limit(ctx),ctx.qhard_depth_limit,alpha,beta)\n revisits[key]+=1;positions[(rt.current_identity,qdepth)]+=1;qdepths[qdepth]+=1;windows[(alpha,beta)]+=1\n return oq(alpha,beta,ply,qdepth,ctx)')
s=s.replace('sm.negamax=observed if obs else old','sm.negamax=observed if obs else old;sm._quiescence_runtime=qobserve if obs else oq')
s=s.replace("{'rows':rows,'ledger':ledger}","{'rows':rows,'ledger':ledger,'revisit':{'calls':sum(revisits.values()),'exact_window_unique':len(revisits),'position_depth_unique':len(positions),'exact_window_repeated_calls':sum(v-1 for v in revisits.values()),'position_depth_repeated_calls':sum(v-1 for v in positions.values()),'qdepths':dict(qdepths),'top_multiplicities':sorted(revisits.values(),reverse=True)[:20]}}")
s=s.replace('finally:sm.negamax=old;','finally:sm._quiescence_runtime=oq;sm.negamax=old;')
Path('.local_agent/drop_q_revisit.py').write_text(s,encoding='utf-8')
