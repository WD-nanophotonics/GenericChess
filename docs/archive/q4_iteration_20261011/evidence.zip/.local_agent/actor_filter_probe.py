import sys,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests/product')]
from test_f24c_mixed_mechanic_certification import _mixed_ruleset,_position,A0,B0,H0,Piece
from generic_chess.rules.schema import RuleTypeRef
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
out=[]
for ref in ('any','action_current','action_base'):
 rule=_mixed_ruleset();actions=[]
 for a in rule.semantic_actions:
  if a.name=='capture_A0_B0_leap':a=replace(a,effects=(replace(a.effects[0],piece_type_ref=RuleTypeRef(ref)),)+a.effects[1:])
  actions.append(a)
 c=compile_semantic_ruleset(replace(rule,semantic_actions=tuple(actions)))
 pos=_position(c,[(1,1,Piece(0,A0,A0)),(2,1,Piece(1,B0,B0)),(0,0,Piece(0,H0,H0)),(6,6,Piece(1,H0,H0))])
 eng=semantic_engine_for(c);p=NativeSemanticLegalityProvider.try_create(c,strict=True)
 core={str(_semantic_public_action(eng,a)) for a in eng.legal_actions(pos)};native={str(a) for a,b in p(pos,0)}
 out.append({'ref':ref,'core_count':len(core),'native_count':len(native),'native_extra':sorted(native-core),'native_missing':sorted(core-native)})
Path('.local_agent/drop-iteration-20261011/actor-filter-result.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
