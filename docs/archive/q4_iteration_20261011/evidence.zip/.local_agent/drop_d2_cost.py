import ast,json,time
from pathlib import Path
B=Path('.local_agent/drop-d2-cost-20261011');B.mkdir(exist_ok=True)
O=Path('.local_agent/physical-publication-20261011');ns=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 ns.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=ns,type_ignores=[]),'<reused>', 'exec'),E)
from generic_chess.ai.alphabeta import search as sm
from generic_chess.core.movegen import legal_actions
case=next(x for x in E['CASES'] if x['id']=='shogi-drop');c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('standard_shogi'));board=E['CoreBoard'](case,c);ev=E['w'].weighted(c,E['VALUES']['shogi'])
fields=['nodes','qnodes','runtime_pushes','runtime_pops','legal_generation_calls','evaluation_calls','in_check_qnodes','capture_qactions','checking_move_qactions','checking_drop_qactions','material_change_qactions','qdepth_cutoffs','stand_pat_cutoffs']
old=sm.negamax;R=E['R'];oa=R.attach_stats;of=E['pm'].SearchStatistics;rows=[];ledger=[];iteration=None

def snap(ctx):return {k:getattr(ctx.stats,k) for k in fields}
def observed(state,depth,alpha,beta,ply,ctx,*args,**kwargs):
 global iteration
 if ply not in (0,1):return old(state,depth,alpha,beta,ply,ctx,*args,**kwargs)
 if ply==0:iteration=depth
 before=snap(ctx);t=time.perf_counter();rec={'iteration':iteration,'depth':depth,'ply':ply,'action':str(kwargs.get('prev_action')),'alpha':alpha,'beta':beta,'complete':False}
 try:
  v=old(state,depth,alpha,beta,ply,ctx,*args,**kwargs);rec.update(complete=True,score=v.score);return v
 except Exception as ex:rec['abort']=str(ex);raise
 finally:
  rec['wall']=time.perf_counter()-t;after=snap(ctx);rec['work']={k:after[k]-before[k] for k in fields};ledger.append(rec)
try:
 R.attach_stats=E['attach'];E['pm'].SearchStatistics=E['factory']
 for native in (True,False):
  obs=True
  E['stopped']();E['runtimes']=[];E['captured']=[];sm.negamax=observed if obs else old
  p=E['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=native,use_disk_cache=False)
  t=time.perf_counter();v=p.choose_action(E['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses),E['SearchLimits'](max_depth=2,max_nodes=1000000,max_time_seconds=256,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
  rt,root=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==root and v.action in legal_actions(board.initial,c)
  rows.append({'native_requested':native,'wall':wall,'decision':E['record_value'](v),'stats':E['record_value'](E['captured'][0]),'root_restored':True})
  (B/'result.json').write_text(json.dumps({'rows':rows,'ledger':ledger.copy()},indent=2)+'\n');print(native,wall,v.completed_depth,v.score,v.termination_reason,flush=True);ledger=[]
finally:sm.negamax=old;R.attach_stats=oa;E['pm'].SearchStatistics=of
