import ast,json,time,hashlib,collections
from pathlib import Path
B=Path('.local_agent/q4-thin-bridge-20261011');B.mkdir(exist_ok=True)
O=Path('.local_agent/physical-publication-20261011');ns=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 ns.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=ns,type_ignores=[]),'<reused>','exec'),E)
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.quiescence import material_inventory,enemy_board_count

def search(board,depth,seconds=30,cap=32768):
 start=time.perf_counter();work=collections.Counter();digest=hashlib.sha256();best=None;bestscore=-2000000
 runtime=getattr(board,'runtime',None);root=E['state'](runtime) if runtime else board.snapshot()
 def poll():
  if work['main']+work['q']>=cap:raise RuntimeError('nodes')
  if time.perf_counter()-start>=seconds:raise RuntimeError('time')
 def state():return E['w'].position_from_snapshot(board.snapshot(),board.evaluator._compiled)
 def checked():
  return runtime.in_check(runtime.position.side_to_move,checkpoint=poll) if runtime else board.board.is_check()
 def push(action):board.push(action);work['physical_push']+=1
 def pop():board.pop();work['physical_pop']+=1
 def q(alpha,beta,ply,qd):
  poll();work['q']+=1;t=board.terminal(ply)
  if t is not None:return t
  check=checked()
  if check:
   work['checked_q']+=1
   if qd>=8:raise RuntimeError('hardq')
  else:
   work['eval']+=1;v=board.evaluate()
   if v>=beta:return v
   alpha=max(alpha,v)
   if qd>=4:return alpha
  work['legal']+=1;actions=board.actions();digest.update(('Q:'+','.join(x[0] for x in actions)+';').encode())
  parent=state();side=parent.position.side_to_move;enemies=enemy_board_count(parent.position,side);inv=material_inventory(parent.position)
  for label,action in actions:
   poll();push(action)
   try:
    child=state()
    noisy=(check or board.terminal(ply+1) is not None or enemy_board_count(child.position,side)<enemies or material_inventory(child.position)!=inv or checked())
    if not noisy:work['quiet_rejected']+=1;continue
    score=-q(-beta,-alpha,ply+1,qd+1)
   finally:pop()
   digest.update(f'QV:{ply}:{label}:{score};'.encode())
   if score>=beta:return score
   alpha=max(alpha,score)
  return alpha
 def main(left,alpha,beta,ply):
  nonlocal best,bestscore
  poll();work['main']+=1;t=board.terminal(ply)
  if t is not None:return t
  if not left:return q(alpha,beta,ply,0)
  work['legal']+=1;actions=board.actions();digest.update(('A:'+','.join(x[0] for x in actions)+';').encode());value=-2000000
  for label,action in actions:
   poll();push(action)
   try:score=-main(left-1,-beta,-alpha,ply+1)
   finally:pop()
   digest.update(f'V:{ply}:{label}:{score};'.encode())
   if ply==0:
    work['root_completed']+=1
    if best is None or score>bestscore:best,bestscore=label,score
   value=max(value,score);alpha=max(alpha,value)
   if alpha>=beta:break
  return value
 if hasattr(board,'checkpoint'):board.checkpoint=poll
 try:score=main(depth,-2000000,2000000,0);reason='complete'
 except RuntimeError as ex:
  if str(ex) not in ('time','nodes','hardq'):raise
  score=None;reason=str(ex)
 finally:
  if hasattr(board,'checkpoint'):board.checkpoint=None
 if runtime:runtime.assert_balanced();assert E['state'](runtime)==root
 else:assert board.restored() and board.snapshot()==root
 return {'move':best,'score':score,'reason':reason,'work':dict(work),'wall':time.perf_counter()-start,'trace':digest.hexdigest(),'restored':True,'provider_calls':runtime.legal_provider_calls if runtime else None,'provider_fallbacks':runtime.legal_provider_fallbacks if runtime else None}

rows=[]
for name in ('chess-ep','shogi-middle','shogi-drop'):
 case=next(x for x in E['CASES'] if x['id']==name);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));ev=E['w'].weighted(c,E['VALUES'][case['game']])
 for arm in ('core','native','specialized'):
  E['stopped']()
  if arm=='specialized':board=(E['w'].WeightedChess if case['game']=='chess' else E['w'].WeightedShogi)(case,ev)
  else:
   provider=NativeSemanticLegalityProvider.try_create(c,strict=True) if arm=='native' else None
   board=E['CoreBoard'](case,c,provider);board.evaluator=ev;board.evaluate=lambda board=board:ev.evaluate(board.runtime.state)
  result=search(board,1);rows.append({'root':name,'arm':arm,**result});(B/'result.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,arm,result['reason'],result['move'],result['score'],result['work'],round(result['wall'],3),flush=True)
