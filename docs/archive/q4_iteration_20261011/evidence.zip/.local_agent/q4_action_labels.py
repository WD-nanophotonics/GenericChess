import ast,json
from pathlib import Path
O=Path('.local_agent/physical-publication-20261011');ns=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 ns.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=ns,type_ignores=[]),'<reused>','exec'),E)
labels={}
for name in ('chess-ep','shogi-middle','shogi-drop'):
 case=next(x for x in E['CASES'] if x['id']==name);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));b=E['CoreBoard'](case,c)
 labels[name]={json.dumps(E['record_value'](a),sort_keys=True):label for label,a in b.actions()}
output={}
for folder in ('q4-completion-policy-20261011','q4-completion-core-20261011'):
 p=Path('.local_agent')/folder/'result.json'
 if p.exists():
  r=json.loads(p.read_bytes());out=[]
  for row in r['rows']:
   out.append({'root':row['root'],'arm':row['arm'],'seconds':row['seconds'],'order':row['order'],'action':labels[row['root']][json.dumps(row['decision']['action'],sort_keys=True)],'depth':row['decision']['completed_depth'],'q':row['decision']['result_ordinary_qdepth']})
  (p.parent/'action-labels.json').write_bytes((json.dumps({'complete':r['complete'],'rows':out},indent=2)+'\n').encode())
r=json.loads(Path('.local_agent/drop-d2-cost-20261011/combined.json').read_bytes())
for source,rows in [('native_snapshot',r['native']['rows']),('final_both',r['final']['rows'])]:
 output[source]=[{'native_requested':row['native_requested'],'depth':row['decision']['completed_depth'],'q':row['decision']['result_ordinary_qdepth'],'score':row['decision']['score'],'action':labels['shogi-drop'][json.dumps(row['decision']['action'],sort_keys=True)]} for row in rows]
Path('.local_agent/drop-d2-cost-20261011/action-labels.json').write_bytes((json.dumps(output,indent=2)+'\n').encode());print(json.dumps(output,indent=2))