import json,collections
from pathlib import Path
for folder in ('q4-completion-policy-20261011','q4-completion-core-20261011'):
 B=Path('.local_agent')/folder
 if not (B/'result.json').exists():continue
 data=json.loads((B/'result.json').read_bytes());rows=data['rows'];summary=[]
 for key in sorted({(x['root'],x['seconds']) for x in rows}):
  g=[x for x in rows if (x['root'],x['seconds'])==key]
  if len(g)!=4:continue
  cell={'root':key[0],'seconds':key[1],'pairs':[]}
  for order in range(2):
   a=next(x for x in g if x['order']==order and x['arm']=='baseline');b=next(x for x in g if x['order']==order and x['arm']=='fullq4_refresh')
   for row in (a,b):
    assert row['root_restored'];s=row['stats'];assert s['runtime_pushes']==s['runtime_pops'];assert len({e['budget_identity'] for e in row['events']})<=1;assert len({e['deadline'] for e in row['events']})<=1
    assert s['native_legality_fallbacks']==0 and s['native_legality_operational_failures']==0
    assert bool(s['native_legality_enabled']) == (folder=='q4-completion-policy-20261011')
    assert (s['native_legality_calls']>0) == (folder=='q4-completion-policy-20261011')
   phases={e['phase']:e for e in b['events']};beg=phases.get('begin');end=phases.get('complete') or phases.get('aborted');refreshwall=None if not beg or not end else end['at']-beg['at'];refreshvisits=None if not beg or not end else end['nodes']+end['qnodes']-beg['nodes']-beg['qnodes']
   if 'aborted' in phases:
    reserve=phases['reserve'];assert all(b['decision'][key]==reserve[key] for key in ('action','score'));assert b['decision']['principal_variation']==reserve['pv'];assert b['decision']['result_ordinary_qdepth']==0
   cell['pairs'].append({'order':order,'baseline_depth':a['decision']['completed_depth'],'refresh_depth':b['decision']['completed_depth'],'baseline_q':a['decision']['result_ordinary_qdepth'],'refresh_q':b['decision']['result_ordinary_qdepth'],'baseline_score':a['decision']['score'],'refresh_score':b['decision']['score'],'action_same':a['decision']['action']==b['decision']['action'],'refresh_completed':'complete' in phases,'refresh_wall':refreshwall,'refresh_visits':refreshvisits,'baseline_visits':a['decision']['nodes']+a['decision']['qnodes'],'policy_visits':b['decision']['nodes']+b['decision']['qnodes'],'deeper_depth_delta':b['decision']['completed_depth']-a['decision']['completed_depth'],'baseline_source':a['decision']['result_source'],'policy_source':b['decision']['result_source']})
  summary.append(cell)
 out={'complete':data['complete'],'calls':len(rows),'wall_sum':sum(x['wall'] for x in rows),'main':sum(x['decision']['nodes'] for x in rows),'q':sum(x['decision']['qnodes'] for x in rows),'physical_pushes':sum(x['stats']['runtime_pushes'] for x in rows),'legal_calls':sum(x['stats']['legal_generation_calls'] for x in rows),'evaluation_calls':sum(x['stats']['evaluation_calls'] for x in rows),'provider_calls':sum(x['stats']['native_legality_calls'] for x in rows),'provider_fallbacks':sum(x['stats']['native_legality_fallbacks'] for x in rows),'cells':summary}
 (B/'analysis.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(folder,len(rows),data['complete']);print(json.dumps(summary,indent=2))