import json
from pathlib import Path
B=Path('.local_agent/q4-thin-cost-20261011');rows=json.loads((B/'result.json').read_bytes());out={}
for root in sorted({x['root'] for x in rows}):
 r=[x for x in rows if x['root']==root];complete=[x for x in r if x['reason']=='complete'];out[root]={'calls':len(r),'complete':len(complete),'all_roots_restored':all(x['restored'] for x in r),'clock_by_arm':{arm:[x['wall'] for x in r if x['arm']==arm] for arm in ('core','native','specialized')},'complete_trace_match':len({x['trace'] for x in complete})==1 if complete else None,'complete_work_match':all(x['work']==complete[0]['work'] for x in complete) if complete else None,'complete_decision_match':len({(x['move'],x['score']) for x in complete})==1 if complete else None,'unknown_reasons':[x['reason'] for x in r if x['reason']!='complete']}
 if complete:out[root]['matched_work']=complete[0]['work']
 else:out[root]['abort_note']='Partial best and trace are not completed-root decisions. Native/specialized node-cap boundary differs by one check/legal call due cooperative polling; no complete same-tree timing claim.'
assert len(rows)==18 and all(x['restored'] for x in rows)
(B/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))