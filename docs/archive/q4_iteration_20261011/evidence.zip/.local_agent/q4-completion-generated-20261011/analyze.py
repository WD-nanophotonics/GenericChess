import json
from pathlib import Path
B=Path('.local_agent/q4-completion-generated-20261011');r=json.loads((B/'result.json').read_bytes());assert r['complete'] and len(r['rows'])==16
cells=[]
for root in ('generated13','generated15'):
 for native in (False,True):
  for order in range(2):
   g=[x for x in r['rows'] if (x['root'],x['native_requested'],x['order'])==(root,native,order)];assert len(g)==2
   a=next(x for x in g if x['arm']=='baseline');b=next(x for x in g if x['arm']=='fullq4_refresh')
   for row in g:
    s=row['stats'];assert row['root_restored'] and s['runtime_pushes']==s['runtime_pops'];assert bool(s['native_legality_enabled'])==native and bool(s['native_legality_calls'])==native and s['native_legality_fallbacks']==0 and s['native_legality_operational_failures']==0
   cells.append({'root':root,'native':native,'order':order,'depths':[a['decision']['completed_depth'],b['decision']['completed_depth']],'ordinary_q':[a['decision']['result_ordinary_qdepth'],b['decision']['result_ordinary_qdepth']],'same_action':a['decision']['action']==b['decision']['action'],'same_score':a['decision']['score']==b['decision']['score'],'refresh_complete':any(e['phase']=='complete' for e in b['events'])})
out={'complete':True,'calls':16,'pairs':cells,'wall_sum':sum(x['wall'] for x in r['rows']),'main':sum(x['decision']['nodes'] for x in r['rows']),'q':sum(x['decision']['qnodes'] for x in r['rows']),'physical_pushes':sum(x['stats']['runtime_pushes'] for x in r['rows']),'legal_calls':sum(x['stats']['legal_generation_calls'] for x in r['rows']),'evaluation_calls':sum(x['stats']['evaluation_calls'] for x in r['rows']),'native_calls':sum(x['stats']['native_legality_calls'] for x in r['rows']),'scope':'Existing exposed development roots13/15 and metadata adapter; no new interface/domain cohort, holdout status or generality proof.'}
(B/'analysis.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(out,indent=2))
p=Path('.local_agent/package_q4_iteration.py');s=p.read_text().replace("'q4-completion-core-20261011'):","'q4-completion-core-20261011','q4-completion-generated-20261011'):").replace("'q4_action_labels.py'):","'q4_action_labels.py','q4_completion_generated.py'):");p.write_bytes(s.encode())