import ast,json,time,hashlib
from pathlib import Path
B=Path('.local_agent/q4-completion-core-20261011');B.mkdir(exist_ok=True)
O=Path('.local_agent/physical-publication-20261011');ns=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 ns.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=ns,type_ignores=[]),'<reused>','exec'),E)
from scripts import reserve_refresh_diagnostic as rr
from generic_chess.core.movegen import legal_actions
# Private policy only; sole changed premise is full configured q4 refresh.
rr.POLICY_SOURCES['clear']=rr.MODIFIED.replace('ctx.qdepth_limit = min(1, original_q)','ctx.qdepth_limit = original_q')
declaration={'question':'Does protected full shallow q4 deliver within unchanged production budgets, and what deeper work is displaced?','roots':['chess-ep','shogi-middle','shogi-drop'],'seconds':[1,4,16,64],'arms':['baseline','fullq4_refresh'],'orders':2,'max_nodes':1000000,'max_depth':12,'q':4,'hardq':8,'calls':40,'max_batch_seconds':700,'additional_unknown':'Does Core backend cost alter shallowq4 deadline feasibility? ChessEP only1/4s because completed16/64q4 baseline already observed; Shogi both use1/4/16/64s. Identical resource pairs, no reinterpretation of old limits.','scope':'Core-only production + same frozen weighted Python evaluator; cold TT; existing reserve retained on refresh abort; no defaults/ordering/pruning changes; TT cleared and disabled during refresh only','decision':'Report completed returned q/depth/action, not strength; no cap growth after failure','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'generated_function_sha256':hashlib.sha256(rr.POLICY_SOURCES['clear'].encode()).hexdigest()}
(B/'declaration.json').write_text(json.dumps(declaration,indent=2)+'\n')
rows=[];R=E['R'];pm=E['pm'];oa=R.attach_stats;of=pm.SearchStatistics;original=pm.run_root_search
try:
 R.attach_stats=E['attach'];pm.SearchStatistics=E['factory']
 for name in declaration['roots']:
  case=next(x for x in E['CASES'] if x['id']==name);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));board=E['CoreBoard'](case,c);ev=E['w'].weighted(c,E['VALUES'][case['game']]);initial=board.initial
  for seconds in ([1,4] if name=='chess-ep' else declaration['seconds']):
   for order in range(2):
    for arm in (('baseline','fullq4_refresh') if order==0 else ('fullq4_refresh','baseline')):
     E['stopped']();events=[];E['runtimes']=[];E['captured']=[]
     pm.run_root_search=original if arm=='baseline' else rr.make_refresh(events,expected_state=initial)
     p=E['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False)
     t=time.perf_counter();v=p.choose_action(E['SimpleNamespace'](compiled=c,state=initial,_search_witnesses=board.witnesses),E['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
     rt,root=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==root and v.action in legal_actions(initial,c)
     assert len({x['budget_identity'] for x in events})<=1 and len({x['deadline'] for x in events})<=1
     row={'root':name,'arm':arm,'order':order,'seconds':seconds,'wall':wall,'decision':E['record_value'](v),'stats':E['record_value'](E['captured'][0]),'events':events,'root_restored':True};rows.append(row)
     (B/'result.json').write_text(json.dumps({'complete':False,'rows':rows},indent=2)+'\n');print(name,seconds,order,arm,v.completed_depth,v.result_ordinary_qdepth,v.score,v.termination_reason,round(wall,3),flush=True)
 (B/'result.json').write_text(json.dumps({'complete':True,'rows':rows},indent=2)+'\n')
finally:R.attach_stats=oa;pm.SearchStatistics=of;pm.run_root_search=original