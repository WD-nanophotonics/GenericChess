import json
from pathlib import Path
B=Path('.local_agent/drop-d2-cost-20261011');r=json.loads((B/'native-first-result.json').read_bytes());ledger=[x for x in r['ledger'] if x['iteration']==2 and x['ply']==1];out=[]
for x in ledger:
 if 'R@d8' in x['action'] or 'R@b9' in x['action']:
  a,b,v=x['alpha'],x['beta'],x['score'];bound='exact-window' if a<v<b else ('child-lower/root-upper' if v>=b else 'child-upper/root-lower')
  out.append({'action_generic':x['action'],'USI':'R*4b' if 'R@d8' in x['action'] else 'R*2a','child_score':v,'root_perspective':-v,'window':[a,b],'returned_bound':bound,'complete':x['complete'],'q_visits':x['work']['qnodes'],'wall':x['wall']})
assert len(out)==2 and all(x['complete'] for x in out)
result={'question':'Do oldreserve and shallowq4 choices agree with the already completedD2 protocol, and are candidate scores exact within recorded windows?','method':'Reuse original Native256s root-child ledger only; no new run, no changed evaluation, no selection/timing benchmark; classify actual recorded windows.','rows':out,'scope':'Finite selectiveD2/q4 executed protocol with actual TT/order; exact-window is observed bound classification, not WDL/global minimax or independent strength evidence. q0 and D1 scores not numerically compared with D2 scores.','decision':'Shallowq4 agrees with completedD2 action in this one exercised root; supports further delivery investigation, not automatic default promotion.'}
(B/'candidate-reference.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result,indent=2))