import json
from pathlib import Path
b=Path('.local_agent/drop-d2-cost-20261011');a=json.loads((b/'native-first-result.json').read_text());z=json.loads((b/'result.json').read_text());(b/'combined.json').write_text(json.dumps({'native':a,'final':z,'ledger_preservation':'first producer overwrote ledger between arms; native first result copied before final Core write; original producer retained'},indent=2))
for row in z['rows']:print(row['native_requested'],round(row['wall'],3),row['decision']['completed_depth'],row['decision']['score'],row['decision']['action'],row['stats']['nodes'],row['stats']['qnodes'])
p=Path('.local_agent/q4_thin_bridge.py');s=p.read_text(encoding='utf-8-sig');s=s.replace("B=Path('.local_agent/q4-thin-bridge-20261011')","B=Path('.local_agent/q4-thin-cost-20261011')")
s=s.replace('def search(board,depth,seconds=30,cap=32768):','def search(board,depth,seconds=120,cap=100000):')
s=s.replace("for arm in ('core','native','specialized'):","for order,arm in [(o,a) for o in range(2) for a in (('core','native','specialized') if o==0 else ('specialized','native','core'))]:")
s=s.replace('result=search(board,1);', 'result=search(board,2);').replace("'arm':arm,**result", "'arm':arm,'order':order,**result")
Path('.local_agent/q4_thin_cost.py').write_text(s,encoding='utf-8')
