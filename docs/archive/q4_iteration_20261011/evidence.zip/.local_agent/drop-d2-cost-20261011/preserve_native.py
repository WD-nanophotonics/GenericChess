import json,shutil
from pathlib import Path
b=Path('.local_agent/drop-d2-cost-20261011');p=b/'result.json';r=json.loads(p.read_text());assert len(r['rows'])==1 and r['rows'][0]['native_requested'];shutil.copyfile(p,b/'native-first-result.json');a=r['rows'][0];print(a['decision']);print([(x['ply'],x['iteration'],round(x['wall'],3),x['work']['qnodes']) for x in r['ledger'] if x['ply']==0]);print('D2branch top',[(x['action'],round(x['wall'],3),x['work']['qnodes']) for x in sorted((x for x in r['ledger'] if x['ply']==1 and x['iteration']==2),key=lambda x:x['wall'],reverse=True)[:5]])
