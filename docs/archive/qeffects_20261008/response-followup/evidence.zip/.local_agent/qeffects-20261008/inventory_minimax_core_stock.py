"""Fixed four-cell hand intervention under one categorical response law."""
import sys,json,time,random,hashlib,math
from pathlib import Path
from fractions import Fraction
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from conftest import make_ruleset,make_state,T,king_type
from generic_chess.core.movement import RayAtom,LeapAtom
from generic_chess.core.actions import action_is_drop,action_target_square,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'inventory-minimax-core-stock.json';assert not out.exists();start=time.perf_counter()
rules=make_ruleset(4,[king_type(),T('R',*(RayAtom(d) for d in ((0,1),(0,-1),(1,0),(-1,0)))),T('N',*(LeapAtom(d) for d in ((1,2),(-1,2),(2,1),(-2,1),(1,-2),(-1,-2),(2,-1),(-2,-1))))],lines=['...k','.r..','..R.','K...'])
c=compile_ruleset_for_execution(rules)
roots=[make_state(c,['...k','.r..','..R.','K...'],hands=(h,())) for h in ((('N',1),('R',1)),(('N',1),('R',2)),(('N',2),('R',1)),(('N',2),('R',2)))]
names=('s','s+A','s+B','s+A+B')
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rules':ruleset_to_dict(rules),'roots':[record_value(s) for s in roots],
 'declaration':'Changed-premise normalization control: baseline already has one R and one N in own hand; four quantities(1,1),(2,1),(1,2),(2,2) share exact initial public legal-action set. Same previous4x4layout,4halfmoves/categorical law/final-initial U. No MC repeat, exact4cells only. Initial drop-category availability and root choice set are fixed; later resource changes remain part of conditional task, not global stock-price identification. Compare I to previous empty-hand square without discarding it. Existing per-cell40000transitions/45sec checkpoint unchanged. One fixed4x4 existing rook-layout family extended with knight; all4common legal counterfactual roots, phase owner0, no opening reachability claim. Own hand A=R/B=N increments only. Both sides categorical equal weight over nonempty ordinary-capture/drop/other-board, uniform within category, canonical actions. U=final ordinary board+hand net control minus each cell initial control; all early terminals retained with no WDL payoff. Four actual halfmoves fixed. No MC sampling in this followup. Independently exact full support4ply for every cell at equal40000Core transitions/45sec per-cell checkpoints; partials unknown, no outcome-driven extension. Exact Fraction expected U and I=U_AB-U_A-U_B+U0, report all signed/zero effects. DeltaB zero/uncertain means no ratio; substantial I means reject fixed compensating ratio on this inventory square. At most local task/response evidence, no default/positive material price/fit/holdout/strength claim.',
 'paths':[],'mc_transitions':0,'exact_cells':[], 'response_contrast':'Both players optimize final-minus-initial control at fixed4actualhalfmoves; max owner0/min owner1; fullCore exact no pruning. Same contexts/resources; categorical early-terminal mass retained only as full-tree support reference, not minimax policy probability. Zero MC. New law declared before evaluation, no ratio selection or WDL/material-price claim.'};write_record(out,r)
def stopped():
 for f in ('rollout.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('stopped') and not d.get('user_paused')
def control(s):
 return sum((1 if x.owner==0 else -1) for x in s.position.board if x is not None and x.current_type_id!='K')+sum((1 if owner==0 else -1)*v for owner,h in enumerate(s.position.hands) for t,v in h.items() if t!='K')
def categories(s):
 groups={}
 for a in sorted(legal_actions(s,c),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True)):
  target=action_target_square(a);occupant=s.position.board[target.rank*4+target.file]
  kind='drop' if action_is_drop(a) else 'capture' if occupant is not None and occupant.owner!=s.position.side_to_move else 'other'
  groups.setdefault(kind,[]).append(a)
 return sorted(groups.items())
for s in roots:assert not s.terminal_status.is_terminal and legal_actions(s,c)
initial=[control(s) for s in roots]
root_support=[sorted(json.dumps(action_to_dict(a),sort_keys=True) for a in legal_actions(s,c)) for s in roots]
assert all(v==root_support[0] for v in root_support)
r['common_initial_action_count']=len(root_support[0])
try:
 for trial in range(0):
  stopped();assert time.perf_counter()-start<90
  rng=random.Random(202610082500+trial);uniforms=[(rng.random(),rng.random()) for _ in range(4)];row={'seed':202610082500+trial,'uniforms':uniforms,'cells':[]}
  for name,s,u0 in zip(names,roots,initial):
   actions=[];events=[]
   for u,v in uniforms:
    if s.terminal_status.is_terminal:break
    groups=categories(s);kind,aa=groups[min(len(groups)-1,int(u*len(groups)))];a=aa[min(len(aa)-1,int(v*len(aa)))];before=control(s);s=apply_action(s,a,c);r['mc_transitions']+=1
    delta=control(s)-before
    expected=(2 if s.position.side_to_move==1 else -2) if kind=='capture' else 0
    assert delta==expected
    actions.append(action_to_dict(a));events.append({'kind':kind,'control_delta':delta})
   row['cells'].append({'name':name,'actions':actions,'events':events,'U':control(s)-u0,'terminal':record_value(s.terminal_status),'final':record_value(s)})
  values=[x['U'] for x in row['cells']];row['contrast']=[values[1]-values[0],values[2]-values[0],values[3]-values[1]-values[2]+values[0]];r['paths'].append(row)
  write_record(out,r)
 samples=list(zip(*(x['contrast'] for x in r['paths'])))
 r['mc_summary']=[{'name':name,'mean':sum(xs)/len(xs),'SE':math.sqrt(sum((x-sum(xs)/len(xs))**2 for x in xs)/(len(xs)-1)/len(xs)),'negative':sum(x<0 for x in xs),'zero':sum(x==0 for x in xs),'positive':sum(x>0 for x in xs)} for name,xs in zip(('DeltaA','DeltaB','I'),samples)];write_record(out,r)
 class Cap(Exception):pass
 for name,root_state,u0 in zip(names,roots,initial):
  stopped();t=time.perf_counter();calls=0;leaves=0;terminal_mass=Fraction(0)
  def visit(s,remaining,mass):
   global calls,leaves,terminal_mass
   if time.perf_counter()-t>=45 or calls>=40000:raise Cap('cost_checkpoint')
   if remaining==0 or s.terminal_status.is_terminal:
    leaves+=1
    if s.terminal_status.is_terminal:terminal_mass+=mass
    return Fraction(control(s)-u0)
   groups=categories(s);assert groups
   values=[]
   for kind,aa in groups:
    weight=Fraction(1,len(groups)*len(aa))
    for a in aa:
     calls+=1;ch=apply_action(s,a,c);values.append(visit(ch,remaining-1,mass*weight))
   return (max(values) if s.position.side_to_move==0 else min(values))
  record={'name':name,'initial_control':u0}
  try:record.update(U=str(visit(root_state,4,Fraction(1))),complete=True)
  except Cap as e:record.update(complete=False,reason=str(e))
  record.update(core_transitions=calls,leaves=leaves,early_terminal_mass=str(terminal_mass),seconds=time.perf_counter()-t);r['exact_cells'].append(record);write_record(out,r);print(name,record,flush=True)
 if all(x['complete'] for x in r['exact_cells']):
  u=[Fraction(x['U']) for x in r['exact_cells']];a,b,i=u[1]-u[0],u[2]-u[0],u[3]-u[1]-u[2]+u[0]
  r['exact_contrasts']={'DeltaA':str(a),'DeltaB':str(b),'I':str(i),'B_after_A':str(b+i),'ratio_defined':b!=0,'ratio':str(a/b) if b else None}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
print('MC',r.get('mc_summary'),'exact',r.get('exact_contrasts'),flush=True)
