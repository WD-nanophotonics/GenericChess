"""Original/product legacy callers under identical qsearch conditions."""
import sys,json,time,hashlib,types
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from ai_fixtures import build_4x4_rooks,build_mate,build_promotion
from conftest import make_state
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'legacy-control.json';assert not out.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def clone(name,source):
 m=types.ModuleType('generic_chess.ai.alphabeta.'+name);m.__package__='generic_chess.ai.alphabeta';sys.modules[m.__name__]=m;exec(source,m.__dict__);return m
q=clone('legacy_old_q',(p/'quiescence-before.py').read_text());s=clone('legacy_old_search',(p/'search-before.py').read_text());s.classify_noisy=q.classify_noisy
r={'complete':False,'producer_sha256':sha(Path(__file__)),'declaration':'Four fixed legacy controls:4x4rooks initial,4x4 quiet-check/hand caller,8x8mate kingfile2,8x8promotion. D3/8192totalnodes/20sec/q4hard8/root tacticaloff/default lexical;2rotatedcoldrepeats16calls<=360sec. Compare original committed classifier and current actual-effects classifier exact signatures and qclassification/runtime work. All caps retained, no winner selection or strength claim. Legacy material-change counter must remain0.','cases':[]};start=time.perf_counter();write_record(out,r)
try:
 for name,c in (('rooks',build_4x4_rooks()),('quietcheck',build_4x4_rooks()),('mate',build_mate(2)),('promotion',build_promotion())):
  game=GameSession(c)
  if name=='quietcheck':game._state=make_state(c,['....','R...','....','K.k.'],hands=([('R',1)],()))
  row={'name':name,'searches':[]};r['cases'].append(row)
  for repeat in (0,1):
   for current in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-start<360
    d=json.loads((root/'.local_agent/rollout.json').read_bytes());assert not d.get('user_paused')
    observed=[]
    def stats():
     z=SearchStatistics();observed.append(z);return z
    player=AlphaBetaPlayer(c,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False));before=game.state;t=time.perf_counter()
    with patch('generic_chess.ai.alphabeta.player.run_root_search',run_root_search if current else s.run_root_search),patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):
     decision=player.choose_action(game,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=20,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    elapsed=time.perf_counter()-t;validate_pv(game,decision);assert game.state==before
    assert decision.material_change_qactions==0
    work={k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','capture_qactions','promotion_qactions','checking_move_qactions','checking_drop_qactions','nonchecking_drop_excluded')}
    assert work['runtime_pushes']==work['runtime_pops'] and work['runtime_depth_balanced']
    row['searches'].append({'current':current,'repeat':repeat,'seconds':elapsed,'decision':record_value(decision),'work':work});write_record(out,r)
  sig=lambda x:json.dumps(({k:x['decision'][k] for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason')},x['work']),sort_keys=True)
  row['exact_signatures']=len({sig(x) for x in row['searches']})==1;assert row['exact_signatures']
  print(name,[(x['current'],x['decision']['score'],round(x['seconds'],3)) for x in row['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
