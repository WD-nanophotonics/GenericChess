"""Fresh recombinations: actual-inventory policy with Core/Native authority."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_to_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'fresh-authority.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'fixture_sha256':sha(root/'tests/rule_semantics_ir_fixtures.py'),'product_hashes':{f:sha(root/f) for f in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/quiescence.py')},'declaration':'Four fresh predeclared seeds202610082400..2403;2400/2401 8x8,2402/2403 6x6 bilateral_random/hybrid. Existing recombination Pdrop temp_right eq0 and quietX->P. Fixed16ply semanticboard>guardedPdrop>capture>other lexical route, retain compile/terminal outcomes. Current actual-inventory classifier only; Core attack+legality versus Native attack+legality, same profile/prices and TT/order/root scanoff. D1/1024totalnodes/30sec/q2hard8/defaultlexicalq,2rotatedcoldrepeats16calls<=660sec checkpoint. Independent fullCorePV replay, exact completed signatures when fixed-node/depth/hard termination, wall partials qualified. This is authority/interface transfer, not material price or strength evidence. Root/route includes actual hand/aux/type events. No retry selection/holdout/user data.','cases':[]}
started=time.perf_counter();write_record(out,r)
fixtures=weird_rulesets();base_drop=fixtures[1].semantic_actions[0];base_quiet=fixtures[2].semantic_actions[0]
def check():
 assert time.perf_counter()-started<660
 for f in ('rollout.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('user_paused',False) and not d.get('stopped',False)
signature=lambda d:tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
try:
 for seed,n in ((202610082400,8),(202610082401,8),(202610082402,6),(202610082403,6)):
  check();g=generate_game(GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True))
  drop=replace(base_drop,type_ids=('P',),replace_selector=replace(base_drop.replace_selector,type_ids=('P',)),slot_guards=(RuleSlotGuard(slot_name='temp_right',value=0),))
  effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id='P')) if e.kind=='set_current_type' else e for e in base_quiet.effects)
  quiet=replace(base_quiet,type_ids=('X',),target_relation='empty',effects=effects)
  rules=replace(g.ruleset,semantic_actions=(drop,quiet));row={'seed':seed,'size':n,'rules':ruleset_to_dict(rules),'route':[],'searches':[]};r['cases'].append(row);write_record(out,r)
  try:c=compile_ruleset_for_execution(rules)
  except Exception as exc:row['compile_failure']=repr(exc);write_record(out,r);continue
  game=GameSession(c)
  for ply in range(16):
   if game.state.terminal_status.is_terminal:break
   actions=game.legal_actions()
   if not actions:break
   def priority(a):
    d=action_to_dict(a);occupant=game.state.position.board[a.to_square.rank*n+a.to_square.file] if hasattr(a,'to_square') else None
    capture=occupant is not None and occupant.owner!=game.state.position.side_to_move
    return (0 if d.get('pattern_id','').startswith('sem_01_') else 1 if d.get('pattern_id','').startswith('sem_00_') else 2 if capture else 3,json.dumps(d,sort_keys=True))
   a=min(actions,key=priority);game.submit(a);row['route'].append({'action':action_to_dict(a),'hands':record_value(game.state.position.hands),'aux':record_value(game.state.position.aux_state),'terminal':record_value(game.state.terminal_status)})
  row['frontier_ply']=game.state.ply_count;row['terminal']=record_value(game.state.terminal_status);write_record(out,r)
  if game.state.terminal_status.is_terminal:continue
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);profile=build_ruleset_profile(c,cfg)
  for repeat in (0,1):
   for native in ((False,True) if repeat==0 else (True,False)):
    check();ev=SemanticAttackEvaluator(c,profile,cfg,backend='native' if native else 'core')
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=native,tuning=SearchTuning(use_root_tactical=False))
    before=game.state;t=time.perf_counter();d=player.choose_action(game,SearchLimits(max_depth=1,max_nodes=1024,max_time_seconds=30,quiescence_max_depth=2,quiescence_hard_max_depth=8));seconds=time.perf_counter()-t
    validate_pv(game,d);assert game.state==before
    if native:assert d.native_legality_calls and d.native_legality_fallbacks==0
    row['searches'].append({'native':native,'repeat':repeat,'seconds':seconds,'decision':record_value(d)});write_record(out,r)
    print(seed,n,native,repeat,d.completed_depth,d.score,d.termination_reason,round(seconds,3),d.material_change_qactions,flush=True)
  row['all_signatures_equal']=len({signature(x['decision']) for x in row['searches']})==1
  if not any(x['decision']['termination_reason']=='time_limit' for x in row['searches']):assert row['all_signatures_equal']
  common={}
  for x in row['searches']:
   d=x['decision'];common.setdefault(d['completed_depth'],set()).add(d['score'])
  assert all(len(v)==1 for k,v in common.items() if k>0)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
