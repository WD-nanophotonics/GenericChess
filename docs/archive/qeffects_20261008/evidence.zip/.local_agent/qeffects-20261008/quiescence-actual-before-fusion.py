"""Conservative generic quiescence search."""

from __future__ import annotations

from ...core.actions import (
    Action,
    action_is_board,
    action_is_drop,
    action_promotion_target_id,
    action_target_square,
)
from ...core.attacks import is_in_check
from ...core.coordinates import square_to_index
from ...core.position import GameState
from .statistics import SearchStatistics


def enemy_board_count(position, side: int) -> int:
    """Conservative material-removal signal, including off-target captures.

    Read the parent count before pushing a mutable runtime view. This does
    not infer capture from a debug name, board geometry or an EP slot.
    """
    return sum(piece is not None and piece.owner != side for piece in position.board)


def material_inventory(position) -> dict[tuple[int, str], int]:
    """Actual board-current/hand-base counts, copied before a mutable push.

    An ordinary drop conserves this inventory. A type/ownership/quantity change
    may not. Balanced type swaps, spatial and auxiliary effects can conserve it;
    this is a limited q inclusion signal, not a complete tactical classifier.
    """
    counts: dict[tuple[int, str], int] = {}
    for piece in position.board:
        if piece is not None:
            key = (piece.owner, piece.current_type_id)
            counts[key] = counts.get(key, 0) + 1
    for owner, hand in enumerate(position.hands):
        for type_id, count in hand.items():
            key = (owner, type_id)
            counts[key] = counts.get(key, 0) + count
    return counts


def classify_noisy(
    state: GameState,
    successors,
    compiled,
    stats: SearchStatistics | None = None,
    *,
    capture_only: bool = False,
) -> list[Action]:
    """Noisy qsearch actions from ``(action, child)`` successor pairs.

    Legacy captures/promotions retain their shortcuts. Semantic actions use
    actual enemy removal and material-inventory change, never promotion/target
    metadata alone. Terminals and checks remain; ordinary quiet drops stay out.
    """
    n = state.position.board_size()
    side = state.position.side_to_move
    parent_enemies = enemy_board_count(state.position, side)
    from ...core.semantic_executor import semantic_engine_for

    semantic_engine = semantic_engine_for(compiled)
    parent_inventory = material_inventory(state.position) if semantic_engine is not None else None
    noisy: list[Action] = []
    for action, child in successors:
        if semantic_engine is None and action_is_board(action):
            if action_promotion_target_id(action) is not None:
                noisy.append(action)
                if stats is not None:
                    stats.promotion_qactions += 1
                continue
            target = action_target_square(action)
            occupant = state.position.board[target.rank * n + target.file]
            if occupant is not None and occupant.owner != side:
                noisy.append(action)
                if stats is not None:
                    stats.capture_qactions += 1
                continue
        if enemy_board_count(child.position, side) < parent_enemies:
            noisy.append(action)
            if stats is not None:
                stats.capture_qactions += 1
            continue
        if parent_inventory is not None and material_inventory(child.position) != parent_inventory:
            noisy.append(action)
            if stats is not None:
                stats.material_change_qactions += 1
                if action_promotion_target_id(action) is not None:
                    stats.promotion_qactions += 1
            continue
        if child.terminal_status.is_terminal:
            noisy.append(action)
            continue
        if capture_only:
            continue
        child_in_check = (
            semantic_engine.in_check(child.position, 1 - side)
            if semantic_engine is not None
            else is_in_check(child.position, 1 - side, compiled)
        )
        if child_in_check:
            noisy.append(action)
            if stats is not None:
                if action_is_drop(action):
                    stats.checking_drop_qactions += 1
                else:
                    stats.checking_move_qactions += 1
            continue
        if action_is_drop(action) and stats is not None:
            stats.nonchecking_drop_excluded += 1
    return noisy
