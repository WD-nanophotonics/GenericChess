"""Publish bounded Agent evidence, verify extracted archive, never Slack state."""
from pathlib import Path
import hashlib,json,statistics,sys,tempfile,zipfile
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/qeffects_20261008';dest.mkdir(parents=True,exist_ok=True)
def read(n):return json.loads((p/(n+'.json')).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,d):path.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
front=read('frontier-audit-final-v2');shared=read('shared-policy-replay');legacy=read('legacy-final-control');eager=read('eager-final-replay');inv=read('inventory-interaction');stock=read('inventory-stock-baseline');cond=read('inventory-stock-root-conditional')
assert all(d['complete'] for d in (front,shared,legacy,eager,inv,stock,cond,read('inventory-native-v5'),read('inventory-stock-native-v2')))
cost=[]
for c in shared['cases']:
 assert c['all_exact'] and c['same_qclasses'];old=[x for x in c['searches'] if not x['shared_fused_product']];new=[x for x in c['searches'] if x['shared_fused_product']]
 cost.append({'seed':c['seed'],'old_median_seconds':statistics.median(x['seconds'] for x in old),'new_median_seconds':statistics.median(x['seconds'] for x in new),'old_work':old[0]['runtime_work'],'new_work':new[0]['runtime_work'],'completed_depth':new[0]['decision']['completed_depth'],'termination_reason':new[0]['decision']['termination_reason'],'score':new[0]['decision']['score']})
for c in legacy['cases']:assert c['exact_signatures']
for c in eager['cases']:assert c['matches_pre_fusion_actual_effects']
qrows=[x for c in front['cases'] for x in c.get('qsearch',[])];assert len(qrows)==6
assert all(x['complete'] for x in qrows)
for c in front['cases']:
 if c.get('qsearch'):assert all(x['score']==c['reference']['score'] for x in c['qsearch'])
summary={'schema':'qeffects-development-20261008','base_commit':'f760bd406d84f3bc01485237394d73a72125f767','science_complete':False,
 'policy':'Semantic q inclusion uses actual enemy-board decrease, owner/current-board+owner/base-hand inventory change, terminal and check. Shared immutable/eager/ordered helper; ordered runtime classifies and recurses in one push. Legacy shortcuts preserved. Promotion diagnostic overlaps actual-change counter. Tuning flags/prices unchanged; default semantic support corrected. Not complete tactical classification or strength evidence.',
 'validation':{'frontiers':sum(len(c['frontiers']) for c in front['cases']),'legal_children':sum(x['actions'] for c in front['cases'] for x in c['frontiers']),'both_capture_modes':True,'branch_core_native_calls':6,'fullwidth_roots':3,'fresh_authority_calls':12,'fresh_early_terminal_retained':1,'fresh_material_change_count':0,'legacy_exact_calls':16,'default_final_replay_calls':4,'full_tests':1648,'test_seconds':165.65},
 'cost':{'original_to_actual_q2':'16 calls preserve choices/scores/depth; extra qwork and roughly1-7% wall cost. Not speedup. Caps preserved.','same_actual_contract_ordered_q4':cost,'ordered_calls':16,'scope':'Serial two rotated cold repeats, same actual-effects semantics/budget/ordering; local times, not universal speed or strength. Three roots retain D1 caps, one completes D2.'},
 'utility':{'law':'Fixed4x4 K/R/N layout, four actual halfmoves; equal mass over nonempty capture/drop/other categories then uniform actions. U=final ordinary board+hand net control minus cell initial control. Early terminals retained without WDL payoff; no opening-reachability claim.','empty_hand':{'exact_contrasts':inv['exact_contrasts'],'exact_cells':inv['exact_cells'],'mc_paths':len(inv['paths'])*4,'mc_transitions':inv['mc_transitions'],'mc_summary':inv['mc_summary'],'native':read('inventory-native-v5')},'common_stock':{'common_initial_actions':stock['common_initial_action_count'],'exact_contrasts':stock['exact_contrasts'],'exact_cells':stock['exact_cells'],'native':read('inventory-stock-native-v2'),'root_conditionals':{'actions':len(cond['conditional_contrasts']),'all_I_zero':all(x['I']=='0' for x in cond['conditional_contrasts']),'R_nonzero_only_after_Rdrop':True,'N_nonzero_only_after_Ndrop':True,'R_nonzero_count':sum(x['DeltaA']!='0' for x in cond['conditional_contrasts']),'N_nonzero_count':sum(x['DeltaB']!='0' for x in cond['conditional_contrasts'])}},'conclusion':'Empty-hand interaction substantial; common-support stock gives opposite-sign increments despite I=0. Root conditionals show finite two-own-turn separation, not global additivity or positive material prices. No horizon sweep/fit.','advisor':'Adopted discrete marginal vs compensating exchange objection and one four-cell check; advisor read old published note, did not independently execute these new numerical results.'},
 'corrections':'Earlier prose said61frontiers; raw recount56nonterminal roots/3580children. Initial audit only persisted Native q rows due one-line-if; final-v2 reruns and persists all6CoreNative calls. Previous outputs/failures retained.',
 'recovery':'docs/archive/qeffects_20261008/index.json'}
assert summary['validation']['frontiers']==56 and summary['validation']['legal_children']==3580
write(root/'docs/research/data/qeffects_20261008.json',summary)
files=[f for f in sorted(p.iterdir()) if f.is_file() and f.suffix in ('.py','.json','.txt')]
files+=[root/'.local_agent/qsemantics-20261008/fresh-reuse.json']
product=['generic_chess/ai/alphabeta/'+n+'.py' for n in ('search','quiescence','statistics','player','tuning')]+['generic_chess/ai/decision.py','tests/product/test_qsearch_semantic_effects.py','tests/product/test_semantic_action_search_classification.py','tests/rule_semantics_ir_fixtures.py','tests/ai_fixtures.py','tests/conftest.py','scripts/research_record.py','scripts/unfamiliar_search.py','pyproject.toml']
files += [root/f for f in product];assert all(f.is_file() for f in files)
records=[];zpath=dest/'evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:
  path=f.relative_to(root).as_posix();b=f.read_bytes();assert 'slack' not in path.lower();z.writestr(path,b);records.append({'path':path,'bytes':len(b),'sha256':sha(b)})
with tempfile.TemporaryDirectory(prefix='qeffects-verify-',dir=p) as tmp:
 target=Path(tmp).resolve();assert target.is_relative_to(p.resolve())
 with zipfile.ZipFile(zpath) as z:
  for m in records:assert (target/m['path']).resolve().is_relative_to(target)
  z.extractall(target)
 for m in records:
  b=(target/m['path']).read_bytes();assert len(b)==m['bytes'] and sha(b)==m['sha256']
index={'base_commit':summary['base_commit'],'archive_sha256':sha(zpath.read_bytes()),'archive_bytes':zpath.stat().st_size,'extracted_rehashed':True,'members':records,'restore':'Isolated checkout base_commit; extract evidence.zip preserving paths. Final product files overlay base for shared_policy_replay/eager_final/frontier_audit_final_v2/legacy_final. For caller_curve/fresh_authority/frontier_audit_v2/v3, restore search-actual-before-fusion.py and quiescence-actual-before-fusion.py over corresponding product paths. Original-before files are immutable clones. Keep final statistics/decision additions. Use separate output checkout or move original results aside: producers refuse overwrites. Recreate environment/Native build from base source, no credentials archived. Do not treat failed producers as acceptance tests.','failures':'Initial frontier constructor; missing test fixture tuning; Native initial/v2/v3/v4 setup failures/incomplete outputs; first stockNative inaccurate MC declaration superseded by metadata-correct v2 rerun; original audit one-line-if omitted Core persistence, fixed final-v2; prose61count corrected56. Wrong test path/old-result failures retained. No capability flags changed, no original records rewritten.','runtime':{'python':sys.version,'platform':sys.platform},'privacy':'Only explicit top-level Agent evidence and code/tests. No user inputs/raw Slack/accounts/credentials/environments or nested pytest temporary repositories.'}
write(dest/'index.json',index)
print({'members':len(records),'archive_bytes':zpath.stat().st_size,'hash':index['archive_sha256'],'local_wall_reductions_percent':[round(100*(1-c['new_median_seconds']/c['old_median_seconds']),2) for c in cost]})
