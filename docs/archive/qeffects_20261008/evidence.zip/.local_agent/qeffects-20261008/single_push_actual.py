"""Local-only ordered qsearch fusion after actual-effect semantics correction."""
import sys,json,time,hashlib,inspect
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
import generic_chess.ai.alphabeta.search as search
from generic_chess.core.coordinates import square_to_index
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'single-push-actual.json';assert not out.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
old='''    for action in ordered:
        if ctx.tuning.use_ordered_qsearch and not _runtime_noisy_actions(ctx, (action,)):
            continue
        with runtime.pushed(action, checkpoint=ctx.checkpoint):
            score = -_quiescence_runtime(-beta, -alpha, ply + 1, qdepth + 1, ctx)
'''
new='''    semantic = semantic_engine_for(ctx.compiled) is not None
    parent_enemies = enemy_board_count(state.position, side)
    parent_inventory = material_inventory(state.position) if semantic else None
    for action in ordered:
        direct_kind = None
        if ctx.tuning.use_ordered_qsearch and not semantic and action_is_board(action):
            occupant = state.position.board[square_to_index(action_target_square(action), state.position.board_size())]
            if action_promotion_target_id(action) is not None:
                direct_kind = "promotion"
            elif occupant is not None and occupant.owner != side:
                direct_kind = "capture"
        with runtime.pushed(action, checkpoint=ctx.checkpoint):
            if ctx.tuning.use_ordered_qsearch:
                if direct_kind == "promotion":
                    ctx.stats.promotion_qactions += 1
                elif direct_kind == "capture" or enemy_board_count(runtime.position, side) < parent_enemies:
                    ctx.stats.capture_qactions += 1
                elif parent_inventory is not None and material_inventory(runtime.position) != parent_inventory:
                    ctx.stats.material_change_qactions += 1
                    if action_promotion_target_id(action) is not None:
                        ctx.stats.promotion_qactions += 1
                elif runtime.terminal_status.is_terminal:
                    pass
                elif ctx.tuning.use_capture_only_qsearch:
                    continue
                elif runtime.in_check(1 - side, checkpoint=ctx.checkpoint):
                    if action_is_drop(action):
                        ctx.stats.checking_drop_qactions += 1
                    else:
                        ctx.stats.checking_move_qactions += 1
                else:
                    if action_is_drop(action):
                        ctx.stats.nonchecking_drop_excluded += 1
                    continue
            score = -_quiescence_runtime(-beta, -alpha, ply + 1, qdepth + 1, ctx)
'''
body=inspect.getsource(search._quiescence_runtime);assert body.count(old)==1
namespace=dict(search.__dict__);namespace['square_to_index']=square_to_index
exec(body.replace(old,new),namespace);prototype=namespace['_quiescence_runtime']
namespace['_quiescence_runtime']=prototype
input_path=root/'.local_agent/qsemantics-20261008/fresh-reuse.json'
cases=json.loads(input_path.read_bytes())['cases']
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(input_path),'product_search_sha256':sha(root/'generic_chess/ai/alphabeta/search.py'),
 'declaration':'Changed premise: actual-inventory classification probes semantic captures and snapshots inventory per ordered candidate. Local clone only. All4recorded2300..2303 q2 frontiers, current actual-effects base versus fused ordered-q classification+recursion; same prices/current-child check. D2/8192totalnodes/30sec/q4hard8/orderedq,TT/order,root scanoff,Nativeattack+legality;2rotatedcoldrepeats16calls<=540sec. Compare exact signatures and all qclassification counters plus actual pushes/wall. Hard/node/time caps retained; no additional budget/default/price change. Deployment requires benefit large enough to justify duplicated classification logic; otherwise retain prototype only.',
 'cases':[]};start=time.perf_counter();write_record(out,r)
def checkpoint():
 assert time.perf_counter()-start<540
 for f in ('rollout.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('stopped') and not d.get('user_paused')
signature=lambda d:tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
try:
 for case in cases:
  checkpoint();c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));game=GameSession(c)
  for step in case['route']:game.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
  ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  row={'seed':case['seed'],'searches':[]};r['cases'].append(row)
  for repeat in (0,1):
   for single in ((False,True) if repeat==0 else (True,False)):
    checkpoint();observed=[]
    def stats():
     z=SearchStatistics();observed.append(z);return z
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True))
    before=game.state;t=time.perf_counter()
    with patch.object(search,'_quiescence_runtime',prototype if single else search._quiescence_runtime),patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):
     d=player.choose_action(game,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    elapsed=time.perf_counter()-t;validate_pv(game,d);assert game.state==before
    z=observed[0];assert z.runtime_depth_balanced and z.runtime_pushes==z.runtime_pops
    row['searches'].append({'single':single,'repeat':repeat,'seconds':elapsed,'decision':record_value(d),'pushes':z.runtime_pushes,'qclasses':{k:getattr(z,k) for k in ('capture_qactions','material_change_qactions','promotion_qactions','checking_move_qactions','checking_drop_qactions','nonchecking_drop_excluded','in_check_qnodes')}});write_record(out,r)
    print(case['seed'],single,repeat,d.completed_depth,d.score,d.termination_reason,z.runtime_pushes,round(elapsed,3),flush=True)
  row['exact_signatures']=len({signature(x['decision']) for x in row['searches']})==1
  row['same_qclasses']=all(x['qclasses']==row['searches'][0]['qclasses'] for x in row['searches'])
  if not any(x['decision']['termination_reason']=='time_limit' for x in row['searches']):assert row['exact_signatures'] and row['same_qclasses']
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
