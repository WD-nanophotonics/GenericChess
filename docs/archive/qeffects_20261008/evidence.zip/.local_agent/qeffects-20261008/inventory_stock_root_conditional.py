"""Independent Native four-cell law, complete four-ply expectation and MC replay."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from conftest import make_state
from dataclasses import replace
from generic_chess.core.position import HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_semantic_ir,_build_semantic_support
from generic_chess.rules.execution import ExecutableSemanticRuleset
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from generic_chess.core.actions import action_is_drop,action_target_square,action_source_square,action_promotion_target_id,action_drop_base_type_id
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'inventory-stock-root-conditional.json';assert not out.exists();source=p/'inventory-stock-baseline.json';src=json.loads(source.read_bytes());start=time.perf_counter()
baseline=compile_ruleset(ruleset_from_dict(src['rules']))
c=ExecutableSemanticRuleset(ir=compile_semantic_ir(baseline),_legacy_compiled=baseline,support=_build_semantic_support(baseline))
n=compile_native_semantic_rules(c);ids={t:i for i,t in enumerate(n.type_ids)};K=ids['K']
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'declaration':'Independently lower same frozen legacy RuleSet into semantic IR for Native execution; public actions mapped to legacy physical fields only between oracle kernels, never product identity merging. This stock followup has zero MC paths; independently enumerate all4fixed4ply categorical cells. Original empty-hand512MC replay remains inventory-native-v5.json. Independently enumerate all4fixed4ply categorical cells using Native guards/make_checked/history, same per-cell40000transition/45sec checks. Compare exact Fraction U/early terminal mass to Core. No material-price/default/strength or speedup claim.',
 'replay_paths':0,'replay_transitions':0,'exact_cells':[], 'root_conditionals':[], 'hypothesis':'Common-support square I=0 because each first own action can expose at most one extra type within only one further own turn. Test every common initial action: conditional I zero; nonzero R marginal only after first R drop; nonzero N marginal only after first N drop. Fixed four-halfmove task, no horizon extension or global additivity claim.'};write_record(out,r)
def checkpoint():
 for f in ('rollout.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('stopped') and not d.get('user_paused')
def control(v):
 return sum((1 if x[2]==0 else -1) for x in v['board'] if x is not None and x[1]!=K)+sum((1 if owner==0 else -1)*v for owner,h in enumerate(v['hands']) for i,v in enumerate(h) if i!=K)
def normalize(a):
 a=public_action(n,a);to=action_target_square(a)
 if action_is_drop(a):return {'kind':'drop','base_type_id':action_drop_base_type_id(a),'to':[to.file,to.rank]}
 fr=action_source_square(a);return {'kind':'board','from':[fr.file,fr.rank],'to':[to.file,to.rank],'promotion_target_id':action_promotion_target_id(a)}
def categories(pos):
 v=snapshot(n,pos);groups={}
 for a in sorted(guarded_actions(n,pos),key=lambda a:json.dumps(normalize(a),sort_keys=True)):
  d=normalize(a);x,y=d['to'];occupant=v['board'][y*4+x]
  kind='drop' if d['kind']=='drop' else 'capture' if occupant is not None and occupant[2]!=v['side'] else 'other'
  groups.setdefault(kind,[]).append(a)
 return sorted(groups.items())
try:
 for j,(hand,expected) in enumerate(zip(((('N',1),('R',1)),(('N',1),('R',2)),(('N',2),('R',1)),(('N',2),('R',2))),src['exact_cells'])):
  checkpoint();game=GameSession(baseline);game._state=make_state(baseline,['...k','.r..','..R.','K...'],hands=(hand,()))
  state=game.state;key=str(position_identity_key(state.position,c))
  game._state=replace(state,history=(HistoryRecord(key,-1,'',False),));game._search_history_witnesses=(state.position,)
  pos0=pack_semantic_search_position(c,n,game);u0=control(snapshot(n,pos0));assert u0==expected['initial_control']
  for row in src['paths']:
   pos=pos0;old=row['cells'][j]
   for (u,v),d in zip(row['uniforms'],old['actions']):
    groups=categories(pos);_,aa=groups[min(len(groups)-1,int(u*len(groups)))];a=aa[min(len(aa)-1,int(v*len(aa)))];assert normalize(a)==d
    pos=make_checked(n,pos,a);r['replay_transitions']+=1
   final=snapshot(n,pos);assert control(final)-u0==old['U'];assert terminal_status(n,pos)==old['terminal']
   expected_pos=old['final']['position'];board=[None if x is None else [ids[x['base_type_id']],ids[x['current_type_id']],x['owner'],int(x['promoted'])] for x in expected_pos['board']];hands=[[dict(h['counts']).get(t,0) for t in n.type_ids] for h in expected_pos['hands']]
   assert record_value(final['board'])==board and final['hands']==hands and final['side']==expected_pos['side_to_move'];assert final['history_exact'] and final['history_events_exact']
   r['replay_paths']+=1
  t=time.perf_counter();calls=0;leaves=0;terminal_mass=Fraction(0);root_rows=[]
  def visit(pos,remaining,mass):
   global calls,leaves,terminal_mass
   assert calls<40000 and time.perf_counter()-t<45
   terminal=terminal_status(n,pos)
   if remaining==0 or terminal['status']!='ongoing':
    leaves+=1
    if terminal['status']!='ongoing':terminal_mass+=mass
    return Fraction(control(snapshot(n,pos))-u0)
   groups=categories(pos);value=Fraction(0)
   for _,aa in groups:
    weight=Fraction(1,len(groups)*len(aa))
    for a in aa:
     calls+=1;conditional=visit(make_checked(n,pos,a),remaining-1,mass*weight);value+=weight*conditional
     if remaining==4:root_rows.append({'action':normalize(a),'weight':str(weight),'U':str(conditional)})
   return value
  value=visit(pos0,4,Fraction(1));assert str(value)==expected['U'] and str(terminal_mass)==expected['early_terminal_mass'];assert calls==expected['core_transitions'] and leaves==expected['leaves']
  r['root_conditionals'].append(root_rows)
  r['exact_cells'].append({'name':expected['name'],'U':str(value),'native_transitions':calls,'leaves':leaves,'early_terminal_mass':str(terminal_mass),'seconds':time.perf_counter()-t});write_record(out,r);print(r['exact_cells'][-1],flush=True)
 rows=r['root_conditionals'];maps=[{json.dumps(x['action'],sort_keys=True):x for x in cell} for cell in rows];assert all(set(m)==set(maps[0]) for m in maps)
 r['conditional_contrasts']=[]
 for key in maps[0]:
  cells=[m[key] for m in maps];assert len({x['weight'] for x in cells})==1
  u=[Fraction(x['U']) for x in cells];da,db,inter=u[1]-u[0],u[2]-u[0],u[3]-u[1]-u[2]+u[0];action=cells[0]['action']
  assert inter==0
  assert da==0 or (action['kind']=='drop' and action['base_type_id']=='R')
  assert db==0 or (action['kind']=='drop' and action['base_type_id']=='N')
  r['conditional_contrasts'].append({'action':action,'weight':cells[0]['weight'],'DeltaA':str(da),'DeltaB':str(db),'I':str(inter)})
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
