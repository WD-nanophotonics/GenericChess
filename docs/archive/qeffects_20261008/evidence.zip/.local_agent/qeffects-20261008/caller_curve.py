"""Predeclared original/product semantic qsupport callers; serial rotated pairs."""
import sys,json,time,hashlib,types
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'tests/product')]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'caller-curve.json';assert not out.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def clone(name,source):
 m=types.ModuleType('generic_chess.ai.alphabeta.'+name)
 m.__package__='generic_chess.ai.alphabeta';sys.modules[m.__name__]=m
 exec(source,m.__dict__);return m
q=clone('before_effect_q', (p/'quiescence-before.py').read_text())
s=clone('before_effect_search', (p/'search-before.py').read_text());s.classify_noisy=q.classify_noisy
source=root/'.local_agent/qsemantics-20261008/fresh-reuse.json'
decl=p/'declaration.json';input_data=json.loads(source.read_bytes())
r={'complete':False,'producer_sha256':sha(Path(__file__)),'inputs':{source.relative_to(root).as_posix():sha(source),decl.relative_to(root).as_posix():sha(decl)},'product_hashes':{f:sha(root/f) for f in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/quiescence.py')},'declaration':json.loads(decl.read_bytes())['paired_callers'],'cases':[]}
started=time.perf_counter();write_record(out,r)
def check():
 assert time.perf_counter()-started<540
 for f in ('rollout.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes())
  assert not d.get('user_paused',False) and not d.get('stopped',False)
try:
 for old in input_data['cases']:
  check();c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));game=GameSession(c)
  for step in old['route']:game.submit(action_from_dict(step['action']))
  assert game.state.ply_count==old['frontier_ply'] and not game.state.terminal_status.is_terminal
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
  ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  row={'seed':old['seed'],'searches':[]};r['cases'].append(row)
  for repeat in (0,1):
   for actual in ((False,True) if repeat==0 else (True,False)):
    check();observed=[]
    def stats():
     z=SearchStatistics();observed.append(z);return z
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False))
    before=game.state;t=time.perf_counter()
    with patch('generic_chess.ai.alphabeta.player.run_root_search',run_root_search if actual else s.run_root_search),patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):
     decision=player.choose_action(game,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=30,quiescence_max_depth=2,quiescence_hard_max_depth=8))
    elapsed=time.perf_counter()-t;validate_pv(game,decision);assert game.state==before
    assert decision.native_legality_fallbacks==0
    work={k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','native_legality_calls','capture_qactions','material_change_qactions','promotion_qactions','checking_move_qactions','checking_drop_qactions','nonchecking_drop_excluded')}
    assert work['runtime_depth_balanced'] and work['runtime_pushes']==work['runtime_pops']
    row['searches'].append({'actual_effects':actual,'repeat':repeat,'seconds':elapsed,'decision':record_value(decision),'runtime_work':work});write_record(out,r)
    print(old['seed'],actual,repeat,decision.completed_depth,decision.score,decision.termination_reason,round(elapsed,3),work['material_change_qactions'],flush=True)
  for actual in (False,True):
   xs=[x for x in row['searches'] if x['actual_effects']==actual]
   sig=lambda x:tuple(json.dumps(x['decision'][k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
   if not any(x['decision']['termination_reason']=='time_limit' for x in xs):assert sig(xs[0])==sig(xs[1])
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
