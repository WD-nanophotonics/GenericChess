"""Independent finite effect classification and branch-observable qsearch."""
import sys, json, time, hashlib
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'tests/product')]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict, action_to_dict
from generic_chess.core.transition import legal_successors
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.quiescence import classify_noisy
from generic_chess.ai.alphabeta.search import INF,_Context,_Budget,quiescence,_runtime_noisy_actions,SearchAborted
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig, MATE_SCORE
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'frontier-audit-final-v2.json';assert not out.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=p/'fresh-authority.json';input_data=json.loads(source.read_bytes())
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(source),
 'declaration':'Audit every predeclared fresh route root and final frontier including terminal outcomes. Independent Counter board-current/hand-base, actual enemy count, Core terminal/check; compare immutable and mutable support in both capture-only settings. First root per seed with nonzero inventory change and not currently checked becomes q1/hard4 Core/Native branch witness. Independent full-width Core qreference, no product classifier, 10000nodes/20sec per root; preserve hard/cost incompletes. Product q1/hard4 max10000nodes/20sec per call. <=600sec total cost checkpoint. No selection on favorable score, no WDL/strength/value claim.',
 'cases':[]};start=time.perf_counter();write_record(out,r)
def checkpoint():
 assert time.perf_counter()-start<600
 for f in ('rollout.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('stopped') and not d.get('user_paused')
def inventory(pos):
 result=Counter((x.owner,x.current_type_id) for x in pos.board if x is not None)
 for owner,hand in enumerate(pos.hands):
  result.update({(owner,t):v for t,v in hand.items()})
 return +result
def reasons(state,child,c):
 side=state.position.side_to_move
 if sum(x is not None and x.owner!=side for x in child.position.board)<sum(x is not None and x.owner!=side for x in state.position.board):return 'removal'
 if inventory(child.position)!=inventory(state.position):return 'inventory'
 if child.terminal_status.is_terminal:return 'terminal'
 if semantic_engine_for(c).in_check(child.position,1-side):return 'check'
 return 'quiet'
class Incomplete(Exception):pass
def reference(state,c,ev):
 calls=0;t=time.perf_counter()
 def visit(s,depth):
  nonlocal calls
  calls+=1
  if calls>10000 or time.perf_counter()-t>20:raise Incomplete('cost_checkpoint')
  terminal=s.terminal_status;side=s.position.side_to_move
  if terminal.is_terminal:
   return 0 if terminal.winner is None else (MATE_SCORE-depth if terminal.winner==side else -MATE_SCORE+depth)
  checked=semantic_engine_for(c).in_check(s.position,side)
  if checked and depth>=4:raise Incomplete('hard_check_limit')
  if not checked and depth>=1:return ev.evaluate(s)
  children=legal_successors(s,c)
  if checked:
   assert children
   return max(-visit(ch,depth+1) for _,ch in children)
  return max([ev.evaluate(s)]+[-visit(ch,depth+1) for _,ch in children if reasons(s,ch,c)!='quiet'])
 try:return {'score':visit(state,0),'complete':True,'calls':calls,'seconds':time.perf_counter()-t}
 except Incomplete as e:return {'complete':False,'reason':str(e),'calls':calls,'seconds':time.perf_counter()-t}
try:
 for old in input_data['cases']:
  checkpoint();row={'seed':old['seed'],'frontiers':[]};r['cases'].append(row)
  if 'compile_failure' in old:row['compile_failure']=old['compile_failure'];continue
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));game=GameSession(c);chosen=None
  for i in range(len(old['route'])+1):
   checkpoint();s=game.state
   if s.terminal_status.is_terminal:row['terminal']=record_value(s.terminal_status);break
   pairs=legal_successors(s,c);why=[reasons(s,ch,c) for _,ch in pairs]
   groups={}
   for (a,ch),reason in zip(pairs,why):
    key=json.dumps(record_value((ch.position,ch.terminal_status)),sort_keys=True)
    groups.setdefault(key,[]).append(reason)
   assert all(len(set(v))==1 for v in groups.values())
   for capture_only in (False,True):
    expect=[a for (a,_),w in zip(pairs,why) if w not in (('quiet','check') if capture_only else ('quiet',))]
    assert classify_noisy(s,pairs,c,capture_only=capture_only)==expect
    rt=SearchPathRuntime(s,c)
    ctx=SimpleNamespace(runtime=rt,compiled=c,stats=SearchStatistics(),checkpoint=lambda:None,tuning=SearchTuning(use_capture_only_qsearch=capture_only))
    assert _runtime_noisy_actions(ctx,[a for a,_ in pairs])==expect
    rt.assert_balanced()
   row['frontiers'].append({'ply':i,'actions':len(pairs),'reasons':dict(Counter(why)),'physical_alias_groups':sum(len(v)>1 for v in groups.values())})
   if chosen is None and 'inventory' in why and not semantic_engine_for(c).in_check(s.position,s.position.side_to_move):chosen=(i,s)
   if i<len(old['route']):game.submit(action_from_dict(old['route'][i]['action']))
   write_record(out,r)
  if chosen:
   i,s=chosen;row['qfrontier_ply']=i
   cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);profile=build_ruleset_profile(c,cfg)
   ev=SemanticAttackEvaluator(c,profile,cfg,backend='core');row['reference']=reference(s,c,ev);row['qsearch']=[];write_record(out,r)
   for native in (False,True):
    checkpoint();ev=SemanticAttackEvaluator(c,profile,cfg,backend='native' if native else 'core')
    provider=NativeSemanticLegalityProvider.try_create(c) if native else None
    if native:assert provider is not None
    rt=SearchPathRuntime(s,c,legal_binding_provider=provider)
    stats=SearchStatistics();limits=SearchLimits(max_nodes=10000,max_time_seconds=20,quiescence_max_depth=1,quiescence_hard_max_depth=4)
    ctx=_Context(c,ev,TranspositionTable(),stats,_Budget(limits,None),SearchTuning(),False,False,1,4,None,runtime=rt)
    t=time.perf_counter();result={'native':native}
    try:result.update(score=quiescence(s,-INF,INF,0,0,ctx),complete=True)
    except SearchAborted as e:result.update(complete=False,reason=str(e))
    rt.assert_balanced();result.update(seconds=time.perf_counter()-t,stats=record_value(stats),native_legal_calls=rt.legal_provider_calls,native_legal_fallbacks=rt.legal_provider_fallbacks)
    if native:assert rt.legal_provider_calls>0 and rt.legal_provider_fallbacks==0
    row['qsearch'].append(result);write_record(out,r)
    if result['complete'] and row['reference']['complete']:assert result['score']==row['reference']['score']
   complete=[x['score'] for x in row['qsearch'] if x['complete']]
   assert len(set(complete))<=1
  print(old['seed'],len(row['frontiers']),row.get('qfrontier_ply'),row.get('reference'),flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
