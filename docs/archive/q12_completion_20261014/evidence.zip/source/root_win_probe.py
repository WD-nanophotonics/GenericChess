from view4 import ROOT,D
from dataclasses import replace
import json,hashlib
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.position import HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.chess_development import root_from_fen
from scripts.research_record import record_value,write_record
out=D/'root-win-v3';out.mkdir(exist_ok=True);assert not(out/'before.json').exists()
source=(ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes();(out/'search-before.py').write_bytes(source)
rows=[]
for policy in ('draw','loss'):
 c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),stalemate_result=policy));s=GameSession(c);original=root_from_fen('k7/2K5/8/1Q6/8/8/8/8 w - - 0 1',compile_ruleset_for_execution(build_builtin_ruleset('western_chess')));position=replace(original.position,ruleset_fingerprint=c.ruleset_fingerprint);key=position_identity_key(position,c);state=replace(original,position=position,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),));state=replace(state,terminal_status=terminal_result(state,c));s._state=state;s._search_history_witnesses=(state.position,);actions=list(s.legal_actions());children=[apply_action(state,a,c) for a in actions];winners=[(i,a,ch) for i,(a,ch) in enumerate(zip(actions,children)) if ch.terminal_status.winner==state.position.side_to_move]
 print(policy,'wins',[(i,str(a),ch.terminal_status.status.value) for i,a,ch in winners],flush=True)
 for i,a,child in winners[:1]:
  player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False);before=(s.state,s.to_record(),s._search_witnesses);d=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=i+1,max_time_seconds=5,quiescence_max_depth=1));assert before==(s.state,s.to_record(),s._search_witnesses)
  rows.append(dict(policy=policy,first_winning_index=i,expected_action=record_value(a),expected_child_terminal=record_value(child.terminal_status),limits_nodes=i+1,decision=record_value(d),history_restored=True));print(policy,'decision',d,flush=True)
write_record(out/'before.json',dict(source_sha256=hashlib.sha256(source).hexdigest(),rows=rows,scope='Same real builtin fixture and original actual Core root order; resource cap immediately after first real winning child, no fabricated terminal label, no filtered/reordered legalset. Existing real fixture reflected horizontally to place stalemate before checkmate in actual Core traversal; adaptive mechanism counterexample, not blind tactical benchmark. Original source preserved while frozen fresh producer retains prechange loaded module.'))
