from view4 import ROOT,D
import json,random,time
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'selected-h4';data=json.loads((out/'rows.json').read_text(encoding='utf-8'));assert data['complete'];g=p.generate_game(p.GeneratorConfig(seed=2026102037,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support);s=p.GameSession(c);rng=random.Random(2026102037+31000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
attacker=data['attacker'];counts=dict(proof_nodes=0,apply_calls=0,all_action_sets_checked=0,defender_counteractions_checked=0);start=time.perf_counter()
def edge(state,item):
 acts=list(legal_actions(state,c));action=next(a for a in acts if record_value(a)==item['action']);counts['apply_calls']+=1;return apply_action(state,action,c)
def verify(state,n,proof):
 counts['proof_nodes']+=1
 if 'terminal' in proof:assert state.terminal_status.is_terminal and record_value(state.terminal_status)==proof['terminal'];return state.terminal_status.winner==attacker
 assert not state.terminal_status.is_terminal
 if 'frontier' in proof:assert n==0;return False
 assert n>0
 attacking=state.position.side_to_move==attacker
 if 'attacker_choice' in proof:assert attacking;v=proof['attacker_choice'];assert verify(edge(state,v),n-1,v['proof']);return True
 if 'defender_counterexample' in proof:assert not attacking;counts['defender_counteractions_checked']+=1;v=proof['defender_counterexample'];assert not verify(edge(state,v),n-1,v['proof']);return False
 key='all_attacker_actions_fail' if attacking else 'all_defender_actions_win';items=proof[key];actual={json.dumps(record_value(a),sort_keys=True) for a in legal_actions(state,c)};assert len(items)==len(actual) and {json.dumps(a['action'],sort_keys=True) for a in items}==actual;counts['all_action_sets_checked']+=1
 for item in items:assert verify(edge(state,item),n-1,item['proof']) is (not attacking)
 return not attacking
verified=[]
for answer in data['answers']:
 assert answer['status']!='unknown';a=next(a for a in s.legal_actions() if record_value(a)==answer['selected_action']);counts['apply_calls']+=1;child=apply_action(s.state,a,c);value=verify(child,3,answer['proof']);assert not value;verified.append(dict(selected_action=answer['selected_action'],verified_opponent_cannot_force_win_by_rootH4=True))
write_record(out/'independent-verification.json',dict(complete=True,verified=verified,counts=counts,elapsed_seconds=time.perf_counter()-start,scope='Separate proof consumer replays Core actions/terminal/fullhistory; validates complete attacker action sets and actual defender counteractions, actual rootH4 remaining3. Does not invoke producing proof algorithm, compared evaluator or search. Goal failure is not rootwin/global safety.'))
print(counts)
