from view4 import ROOT,D
import time,json,random,cProfile,pstats
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
out=D/'q12-profile';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Do successful q-child overhead or full legal-frontier execution dominate the cheaper q1/q2 policies?',seeds=[2026102016,2026102017,2026102018],sizes=[12,18,24],q=[1,2],nodes=1024,depth=6,seconds=30,planned_calls=6,scope='cProfile observer cost, not throughput/speedups. Same originalCore. Inclusive function costs overlap; private hostpath raw pstats excluded from publication, sanitized basename function table saved. Normal concurrent owned fresh curve producer, no exclusive machine claim.'))
rows=[];start=time.perf_counter()
for seed,size in zip([2026102016,2026102017,2026102018],[12,18,24]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support);s=p.GameSession(c);rng=random.Random(seed+31000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 before=(s.state,s.to_record(),s._search_witnesses);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
 for q in (1,2):
  p.rr.stopped();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);prof=cProfile.Profile();t=time.perf_counter();prof.enable()
  try:d=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=1024,max_time_seconds=30,quiescence_max_depth=q,quiescence_hard_max_depth=8))
  finally:prof.disable()
  wall=time.perf_counter()-t;prof.dump_stats(out/f'private-{size}-{q}.pstats');assert before==(s.state,s.to_record(),s._search_witnesses)
  stats=pstats.Stats(prof);functions=[dict(file=Path(k[0]).name,line=k[1],function=k[2],primitive_calls=v[0],total_calls=v[1],self_seconds=v[2],inclusive_seconds=v[3]) for k,v in stats.stats.items()];functions.sort(key=lambda r:r['inclusive_seconds'],reverse=True)
  rows.append(dict(seed=seed,size=size,q=q,wall=wall,decision=record_value(d),functions=functions,full_history_restored=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(size,q,wall,d.runtime_pushes,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
