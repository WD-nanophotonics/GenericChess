from view4 import ROOT,D
import json,random,time
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'fresh-q1-q2';data=json.loads((out/'rows.json').read_text(encoding='utf-8'));assert data['complete']
assert not(out/'terminal-declaration.json').exists()
write_record(out/'terminal-declaration.json',dict(question='Do the actual selected q1/q2 actions allow immediate opponent winning terminals under the same complete generated root/history?',rootH=2,remaining_after_action=1,scope='Only selected action union, all immediate legal replies. Actual Core terminal/winner labels, not compared searchscores. No immediate loss is not forcedrootwin/longterm safety. All declared roots including equalactions/immediatewins retained. Stops/cost cap preserve unknown, no root/action selection by labels.',fuse_seconds=600))
start=time.perf_counter();answers=[]
for seed,size in zip([2026102030,2026102031,2026102032,2026102033,2026102034,2026102035,2026102036,2026102037],[12,18,24,12,18,24,8,8]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support);s=p.GameSession(c);rng=random.Random(seed+31000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 sample=json.loads((out/f'sample-{seed}.json').read_text(encoding='utf-8'));assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
 seen=set()
 for r in data['rows']:
  if r['seed']!=seed:continue
  record=r['decision']['action'];tag=json.dumps(record,sort_keys=True)
  if tag in seen:continue
  seen.add(tag);a=next(a for a in s.legal_actions() if record_value(a)==record);child=apply_action(s.state,a,c);replies=[];complete=True
  for reply in (() if child.terminal_status.is_terminal else legal_actions(child,c)):
   p.rr.stopped()
   if time.perf_counter()-start>600:complete=False;break
   result=apply_action(child,reply,c);replies.append(dict(action=record_value(reply),terminal=record_value(result.terminal_status),ply_count=result.ply_count,history=record_value(result.history)))
  wins=[r for r in replies if r['terminal']['winner']==1-s.state.position.side_to_move]
  answers.append(dict(seed=seed,size=size,selected_action=record,child_terminal=record_value(child.terminal_status),direct_child_opponent_win=child.terminal_status.winner==1-s.state.position.side_to_move,complete=complete,all_legal_replies=len(replies) if complete else None,examined_replies=len(replies),all_immediate_opponent_winning_terminals=wins,replies=replies))
  write_record(out/'terminal-replies.json',dict(complete=all(a['complete'] for a in answers),actions=answers,elapsed_seconds=time.perf_counter()-start));print(seed,size,len(replies),len(wins),complete,flush=True)
write_record(out/'terminal-replies.json',dict(complete=all(a['complete'] for a in answers),actions=answers,elapsed_seconds=time.perf_counter()-start))
