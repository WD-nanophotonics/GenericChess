from view4 import ROOT,D
import ast,hashlib,pytest
from generic_chess.ai.alphabeta import search as searchmod
from scripts.research_record import write_record
source=(D/'root-win-v3/search-before.py').read_text(encoding='utf-8');tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='root_tactical_scan');ns=dict(searchmod.__dict__);exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'recorded_old_root_scan','exec'),ns);searchmod.root_tactical_scan=ns['root_tactical_scan']
result=pytest.main(['-q','-p','no:cacheprovider','tests/product/test_root_terminal_wins.py'])
write_record(D/'root-win-v3/old-regression-result.json',dict(source_sha256=hashlib.sha256(source.encode()).hexdigest(),pytest_exit=int(result),scope='Only old recorded root_tactical_scan function substituted process-locally; new regression fixtures run unchanged. No tracked source change, no running fresh producer alteration. Expected loss2 failures/draw2passes; actual stdout preserved separately.'))
assert result==1, 'old function should fail winner regressions'
