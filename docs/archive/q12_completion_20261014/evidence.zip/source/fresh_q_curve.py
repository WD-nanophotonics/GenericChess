from view4 import *
import time,json
from scripts.research_record import write_record
from generic_chess.ai.alphabeta.tuning import SearchTuning
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
import random,hashlib
out=D/'fresh-q1-q2';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Can a smaller explicit ordinary-q policy avoid retaining only D1/q0 on unfamiliar high-branching rules under the same total allowance?',seeds=[2026102030,2026102031,2026102032,2026102033,2026102034,2026102035,2026102036,2026102037],sizes=[12,18,24,12,18,24,8,8],prefix=8,rng_offset=31000,arms=['q1','q2'],q=[1,2],hardq=8,seconds=[16,64],orders=2,planned_calls=64,expected_minutes=44,fuse_seconds=3000,source='Original production Core/default ordering; only explicit requested ordinaryq1 versusq2 changes, hard checkq8 unchanged; new runtime completed-push metrics exposed',scope='Predeclared fresh generated roots, adaptive development route rather than restored universal holdout; different finite ordinary-q policies, not equivalent horizon or stronger-play claim. Same fullCore/evaluator/TT/ordering/complete mechanisms/history and16/64s. Extra player init charged. No stop/budget/default/UI change; smallerq is existing explicitSearchLimits option. Outcomes distinguish completed actual policy from more partial nodes. No repeated old view/order resource curve or price fitting.'))
rows=[];start=time.perf_counter()
try:
 for seed,size in zip([2026102030,2026102031,2026102032,2026102033,2026102034,2026102035,2026102036,2026102037],[12,18,24,12,18,24,8,8]):
  p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
  c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support)
  s=p.GameSession(c);rng=random.Random(seed+31000);walk=[]
  for _ in range(8):
   acts=sorted(s.legal_actions(),key=repr)
   if not acts or s.result.status.value!='ongoing':raise ValueError('declaredprefix unavailable')
   a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
  assert s.result.status.value=='ongoing'
  write_record(out/f'sample-{seed}.json',dict(seed=seed,size=size,ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk))
  before=(s.state,s.to_record(),s._search_witnesses)
  ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
  for seconds in (16,64):
   for rep in range(2):
    for arm in (('q1','q2') if rep==0 else ('q2','q1')):
     p.rr.stopped();assert time.perf_counter()-start<3000
     t=time.perf_counter()
     player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
     prep=time.perf_counter()-t;search_allowance=max(.001,seconds-prep);search_start=time.perf_counter()
     with installed('baseline'):
      decision=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=search_allowance,quiescence_max_depth=(1 if arm=="q1" else 2),quiescence_hard_max_depth=8))
     wall=time.perf_counter()-search_start;total=time.perf_counter()-t
     assert before==(s.state,s.to_record(),s._search_witnesses)
     child=s.state
     for a in decision.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
     rows.append(dict(seed=seed,size=size,seconds=seconds,rep=rep,arm=arm,prepare_seconds=prep,search_allowance=search_allowance,search_wall=wall,total_caller_wall=total,decision=record_value(decision),full_history_restored=True,pv_core_legal=True))
     write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
     print(seed,size,seconds,rep,arm,round(total,4),decision.completed_depth,decision.nodes,decision.qnodes,decision.result_ordinary_qdepth,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
except BaseException as exc:
 write_record(out/'failure.json',dict(error_type=type(exc).__name__,error=str(exc),saved_calls=len(rows),elapsed_seconds=time.perf_counter()-start));raise
