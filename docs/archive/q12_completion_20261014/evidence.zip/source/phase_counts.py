from view4 import ROOT,D
import ast,contextlib,time,random,hashlib
from collections import Counter
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta import search as searchmod
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'phase-counts';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
source=(ROOT/'generic_chess/ai/alphabeta/search.py').read_text(encoding='utf-8')
write_record(out/'declaration.json',dict(question='How many completed Core pushes belong to main search, q evasion and q candidate classification, and how many classified children are discarded?',seeds=[2026102016,2026102017,2026102018],sizes=[12,18,24],q=[1,2,4],nodes=1024,depth=6,seconds=30,planned_calls=18,fuse_seconds=900,scope='Private AST call-site counters versus original same node condition, fresh player per arm. Instrumentation cost is not ordinary throughput. Same complete transitions, terminal, history, q inclusion, ordering, stops. No product change or skipped quiet/drop child.',source_sha256=hashlib.sha256(source.encode()).hexdigest()))
@contextlib.contextmanager
def instrumented(counts):
 tree=ast.parse(source);definitions=[];replacements={}
 @contextlib.contextmanager
 def tagged(runtime,action,label,checkpoint=None):
  with runtime.pushed(action,checkpoint=checkpoint) as child:
   counts[label+':successful_push']+=1
   try:yield child
   finally:counts[label+':successful_pop']+=1
 oldnoise=searchmod.noisy_child
 def noise(*args,**kwargs):
  result=oldnoise(*args,**kwargs);counts['q_candidate:'+('included' if result else 'discarded')]+=1;return result
 for fn in tree.body:
  if not isinstance(fn,ast.FunctionDef):continue
  calls=[n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='pushed']
  if not calls:continue
  for n in calls:
   label=fn.name
   if fn.name=='_quiescence_runtime':label='q_evasion' if n.lineno<680 else 'q_candidate'
   n.args=[n.func.value,*n.args,ast.Constant(label)];n.func=ast.Name('_tagged_runtime_push',ast.Load())
  definitions.append(fn);replacements[fn.name]=getattr(searchmod,fn.name)
 namespace=dict(searchmod.__dict__);namespace['_tagged_runtime_push']=tagged;namespace['noisy_child']=noise
 exec(compile(ast.fix_missing_locations(ast.Module(body=definitions,type_ignores=[])),'private_phase_count_call_sites','exec'),namespace)
 # Function globals resolve the live search module so recursion and ordinary callees keep their original implementation.
 import types
 for name in replacements:setattr(searchmod,name,types.FunctionType(namespace[name].__code__,{**searchmod.__dict__,'_tagged_runtime_push':tagged,'noisy_child':noise},name,namespace[name].__defaults__))
 try:yield
 finally:
  for name,old in replacements.items():setattr(searchmod,name,old)
rows=[];start=time.perf_counter()
for seed,size in zip([2026102016,2026102017,2026102018],[12,18,24]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support);s=p.GameSession(c);rng=random.Random(seed+31000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 before=(s.state,s.to_record(),s._search_witnesses);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
 for q in (1,2,4):
  for arm in ('original','tagged'):
   p.rr.stopped();assert time.perf_counter()-start<900;counts=Counter();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);t=time.perf_counter()
   with (instrumented(counts) if arm=='tagged' else contextlib.nullcontext()):d=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=1024,max_time_seconds=30,quiescence_max_depth=q,quiescence_hard_max_depth=8))
   wall=time.perf_counter()-t;assert before==(s.state,s.to_record(),s._search_witnesses);child=s.state
   for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
   rows.append(dict(seed=seed,size=size,q=q,arm=arm,counts=dict(counts),decision=record_value(d),wall=wall,full_history_restored=True,pv_core_legal=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(seed,size,q,arm,d.runtime_pushes,dict(counts),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
