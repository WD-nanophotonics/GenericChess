from view4 import ROOT,D
from pathlib import Path
from dataclasses import replace
import ast,random
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.identity import position_identity_key
from generic_chess.core.position import HistoryRecord
from generic_chess.core.terminal import terminal_result
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from scripts.chess_development import root_from_fen
from scripts.search_backend_comparison import CoreBoard
from scripts.research_record import record_value,write_record
out=D/'native-root-win';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does corrected Core-owned winning-terminal delivery survive actual Native legality and optional readonly check/availability interfaces?',cases=['western_draw','western_loss','shogi_checker0','shogi_checker1'],modes=['native_legality','native_all_queries'],arms=['recorded_old','current'],planned_calls=16,scope='Independent bounded actual provider counters, actual complete provider move order and firstwinningchild node boundary. Core history/terminal authority, explicit optional queries, not newdefault or nativeengine change.'))
source=(D/'root-win-v3/search-before.py').read_text(encoding='utf-8');tree=ast.parse(source);fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='root_tactical_scan');ns=dict(sm.__dict__);exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'recorded_old_root_scan','exec'),ns);current=sm.root_tactical_scan;rows=[]
for case in ('western_draw','western_loss','shogi_checker0','shogi_checker1'):
 if case.startswith('western'):
  policy=case.split('_')[1];original=root_from_fen('k7/2K5/8/1Q6/8/8/8/8 w - - 0 1',compile_ruleset_for_execution(build_builtin_ruleset('western_chess')));c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),stalemate_result=policy));pos=replace(original.position,ruleset_fingerprint=c.ruleset_fingerprint);key=position_identity_key(pos,c);state=replace(original,position=pos,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),));state=replace(state,terminal_status=terminal_result(state,c));witnesses=(pos,)
 else:
  checker=int(case[-1]);c=compile_ruleset_for_execution(replace(build_builtin_ruleset('standard_shogi'),stalemate_result='draw'));setup,cycle=(('4k4/3R5/9/9/9/9/9/9/8K b - 1','6b5b 5a6a 5b6b 6a5a') if checker==0 else ('k8/9/9/9/9/9/9/5r3/4K4 w - 1','4h5h 5i4i 5h4h 4i5i'));core=CoreBoard(dict(game='shogi',setup=setup,moves=' '.join((cycle.split()*3)[:-1])),c);state=core.initial;witnesses=core.witnesses
 s=GameSession(c);s._state=state;s._search_history_witnesses=witnesses;before=(s.state,s.to_record(),s._search_witnesses)
 for mode in ('native_legality','native_all_queries'):
  for arm in ('recorded_old','current'):
   player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=True,use_native_semantic_availability=mode=='native_all_queries',use_native_semantic_check=mode=='native_all_queries');provider=player.native_legality_provider;assert provider is not None
   pairs=provider(s.state.position,s.state.ply_count);assert pairs is not None;acts=[a for a,_ in pairs];assert set(acts)==set(s.legal_actions());wins=[(i,a,apply_action(s.state,a,c)) for i,a in enumerate(acts) if apply_action(s.state,a,c).terminal_status.winner==s.state.position.side_to_move];assert wins;index,action,child=wins[0]
   sm.root_tactical_scan=ns['root_tactical_scan'] if arm=='recorded_old' else current
   try:d=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=index+1,max_time_seconds=5,quiescence_max_depth=1))
   finally:sm.root_tactical_scan=current
   assert before==(s.state,s.to_record(),s._search_witnesses);assert d.native_legality_calls>0;assert d.runtime_pushes==d.runtime_pops and d.runtime_depth_balanced
   if arm=='current':assert d.result_source=='root_immediate_win' and d.principal_variation==(action,) and d.score==999999999
   rows.append(dict(case=case,mode=mode,arm=arm,firstwin_index=index,expected_action=record_value(action),expected_terminal=record_value(child.terminal_status),decision=record_value(d),availability_metrics=provider.availability_metrics,check_metrics=provider.check_metrics,full_history_restored=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(case,mode,arm,index,child.terminal_status.status.value,d.result_source,d.native_legality_calls,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))
