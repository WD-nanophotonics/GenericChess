from view4 import ROOT,D
from pathlib import Path
from dataclasses import replace
import ast,time,json
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from scripts.search_backend_comparison import CoreBoard
from scripts.research_record import record_value,write_record
out=D/'history-root-win';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does the same root delivery correction retain real history-dependent continuous-check wins, not just stalemate?',checker=[0,1],arms=['recorded_old','current'],planned_calls=4,scope='Reuse legally replayed existing Shogi terminal fixtures,11moves with fullwitnesses. Real allactions, node boundary after first winningchild. Adaptive mechanism regression not strength or native modification.'))
oldsrc=(D/'root-win-v3/search-before.py').read_text(encoding='utf-8');tree=ast.parse(oldsrc);fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='root_tactical_scan');ns=dict(sm.__dict__);exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'recorded_old_root_scan','exec'),ns);current=sm.root_tactical_scan;rows=[]
for checker in (0,1):
 c=compile_ruleset_for_execution(replace(build_builtin_ruleset('standard_shogi'),stalemate_result='draw'))
 setup,cycle=(('4k4/3R5/9/9/9/9/9/9/8K b - 1','6b5b 5a6a 5b6b 6a5a') if checker==0 else ('k8/9/9/9/9/9/9/5r3/4K4 w - 1','4h5h 5i4i 5h4h 4i5i'))
 core=CoreBoard(dict(game='shogi',setup=setup,moves=' '.join((cycle.split()*3)[:-1])),c);s=GameSession(c);s._state=core.initial;s._search_history_witnesses=core.witnesses;before=(s.state,s.to_record(),s._search_witnesses)
 acts=list(s.legal_actions());wins=[(i,a,apply_action(s.state,a,c)) for i,a in enumerate(acts) if apply_action(s.state,a,c).terminal_status.winner==s.state.position.side_to_move]
 assert wins;index,action,child=wins[0]
 for arm in ('recorded_old','current'):
  sm.root_tactical_scan=ns['root_tactical_scan'] if arm=='recorded_old' else current
  try:d=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False).choose_action(s,SearchLimits(max_depth=4,max_nodes=index+1,max_time_seconds=5,quiescence_max_depth=1))
  finally:sm.root_tactical_scan=current
  assert before==(s.state,s.to_record(),s._search_witnesses)
  rows.append(dict(checker=checker,arm=arm,winner=s.state.position.side_to_move,first_winning_index=index,expected_action=record_value(action),expected_child_terminal=record_value(child.terminal_status),decision=record_value(d),history_restored=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(checker,arm,child.terminal_status,index,d.score,d.result_source,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))
