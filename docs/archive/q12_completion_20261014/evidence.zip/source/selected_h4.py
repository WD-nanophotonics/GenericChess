from view4 import ROOT,D
import json,random,time
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'selected-h4';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Do actual q1/q2 selectedactions on the smallest fresh differingroot allow an opponent forcedwinning terminal by rootH4?',seed=2026102037,size=8,prefix=8,rng_offset=31000,scope='Adaptive selectedunion diagnostic afterH2 cannot distinguish. Rootselectedmove consumes1, attackeropponent gets remaining3. Attacker existential/defender alllegal, terminal/winner only; no comparedscores, no cooperativePV label, no WDL/globalstrength or default. All existingselectedactions retained, no root chosen by terminal label. Stops/180s/100000 actualapplycalls preserveunknown, no extension.',root_halfmoves=4,remaining_after_selected=3,fuse_seconds=180,max_apply_calls=100000))
r=json.loads((D/'fresh-q1-q2/rows.json').read_text(encoding='utf-8'));assert r['complete'];g=p.generate_game(p.GeneratorConfig(seed=2026102037,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support);s=p.GameSession(c);rng=random.Random(2026102037+31000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
sample=json.loads((D/'fresh-q1-q2/sample-2026102037.json').read_text(encoding='utf-8'));assert sample['state']==record_value(s.state) and sample['witnesses']==record_value(s._search_witnesses);assert not getattr(c,'declarations',())
attacker=1-s.state.position.side_to_move;start=time.perf_counter();counts=dict(apply_calls=0,visited=0,terminal_visits=0,frontier_visits=0,legal_lists=0);answers=[]
class Limited(Exception):pass

def poll():
 p.rr.stopped()
 if time.perf_counter()-start>=180 or counts['apply_calls']>=100000:raise Limited()
def apply(state,a):
 poll();counts['apply_calls']+=1;return apply_action(state,a,c)
def prove(state,remaining):
 poll();counts['visited']+=1
 if state.terminal_status.is_terminal:
  counts['terminal_visits']+=1;return state.terminal_status.winner==attacker,dict(terminal=record_value(state.terminal_status))
 if remaining==0:
  counts['frontier_visits']+=1;return False,dict(frontier=True)
 counts['legal_lists']+=1;acts=tuple(legal_actions(state,c));assert acts
 attacking=state.position.side_to_move==attacker;edges=[]
 for a in acts:
  value,childproof=prove(apply(state,a),remaining-1);edge=dict(action=record_value(a),proof=childproof)
  if attacking and value:return True,dict(attacker_choice=edge)
  if not attacking and not value:return False,dict(defender_counterexample=edge)
  edges.append(edge)
 return (False,dict(all_attacker_actions_fail=edges)) if attacking else (True,dict(all_defender_actions_win=edges))
seen=set()
for row in r['rows']:
 if row['seed']!=2026102037:continue
 rec=row['decision']['action'];key=json.dumps(rec,sort_keys=True)
 if key in seen:continue
 seen.add(key);action=next(a for a in s.legal_actions() if record_value(a)==rec);before=dict(counts);t=time.perf_counter()
 try:value,proof=prove(apply(s.state,action),3);status='opponent_forced_win_within_rootH4' if value else 'opponent_cannot_force_win_within_rootH4';answer=dict(selected_action=rec,status=status,proof=proof)
 except Limited:answer=dict(selected_action=rec,status='unknown',reason='declared shared180s/100000apply cap exhausted; no implicit false label')
 answer.update(incremental_counts={k:counts[k]-before[k] for k in counts},elapsed_seconds=time.perf_counter()-t);answers.append(answer);write_record(out/'rows.json',dict(complete=False,attacker=attacker,answers=answers,counts=counts,elapsed_seconds=time.perf_counter()-start));print(answer['status'],answer['incremental_counts'],flush=True)
write_record(out/'rows.json',dict(complete=True,attacker=attacker,answers=answers,counts=counts,elapsed_seconds=time.perf_counter()-start))
