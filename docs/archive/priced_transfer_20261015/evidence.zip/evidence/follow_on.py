from pathlib import Path
import subprocess,sys,json,time,datetime
b=Path('.local_agent/priced-completion-20261015');rows=[];start=time.perf_counter()
for name,cap in [('backend',1100),('interior_transfer',1500)]:
 print('BEGIN',name,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True);t=time.perf_counter()
 with (b/(name+'-run.log')).open('wb')as log:
  r=subprocess.run([sys.executable,str(b/(name+'.py'))],stdout=log,stderr=subprocess.STDOUT,timeout=cap+120)
 row={'study':name,'exit':r.returncode,'seconds':time.perf_counter()-t};rows.append(row);(b/'follow-on-results.json').write_text(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8');print('END',row,flush=True)
 if r.returncode!=0:raise SystemExit('Study failed, no automatic retry')
(b/'follow-on-results.json').write_text(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8')
