from pathlib import Path
import subprocess,sys,json,time,datetime
b=Path('.local_agent/priced-completion-20261015');rows=[];start=time.perf_counter()
for name,cap in [('diagnostic',1000),('tt',1100),('fixed',900),('unit_fixed',900),('q0',1000)]:
 t=time.perf_counter();print('BEGIN',name,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
 with (b/(name+'-run.log')).open('wb') as log:
  try:r=subprocess.run([sys.executable,str(b/(name+'.py'))],stdout=log,stderr=subprocess.STDOUT,timeout=cap+120);code=r.returncode
  except subprocess.TimeoutExpired:code='outer_fuse'
 row={'study':name,'exit':code,'seconds':time.perf_counter()-t};rows.append(row);(b/'study-chain.json').write_text(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8');print('END',row,flush=True)
 if code!=0:raise SystemExit('Study failed; inspect exact original evidence; no automated retry')
(b/'study-chain.json').write_text(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8')
