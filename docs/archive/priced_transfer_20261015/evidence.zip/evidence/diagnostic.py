from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
b=ROOT/'.local_agent/priced-completion-20261015'
d=json.loads((b/'resource-results.json').read_text());assert d['complete'];inputs=json.loads((b/'inputs.json').read_text());spec={x['name']:x for x in inputs['samples']};profiles={r['name']:r for r in d['roots']}
groups={}
for row in d['rows']:groups.setdefault((row['root'],row['seconds'],row['order']),{})[row['arm']]=row
wanted={}
for k,g in groups.items():
 if g['baseline']['result']['action']==g['candidate']['result']['action']:continue
 for r in g.values():
  a=r['result']['action'];wanted.setdefault(k[0],{})[json.dumps(a,sort_keys=True)]=a
class Material:
 def __init__(self,v,h):self.v=v;self.h=h
 def type_value(self,tid):return self.v[tid]
 def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
 def evaluate(self,state):
  p=state.position;side=p.side_to_move
  return sum((1 if x.owner==side else -1)*self.v[x.current_type_id] for x in p.board if x is not None)+sum((1 if owner==side else -1)*count*self.h[tid] for owner,hand in enumerate(p.hands) for tid,count in hand.counts)
rows=[];start=time.perf_counter()
def save(complete=False,error=None):
 (b/'diagnostic-results.json').write_text(json.dumps({'complete':complete,'rows':rows,'seconds':time.perf_counter()-start,'error':error}),encoding='utf-8')
try:
 for name,actions in wanted.items():
  c,s=case(spec[name]);pr=profiles[name];before=record_value(s.to_record());ev=Material(pr['board_values'],pr['hand_values'])
  for key,value in actions.items():
   p.rr.stopped()
   if time.perf_counter()-start>1000:raise TimeoutError('1000s fuse')
   a,=[a for a in s.legal_actions() if record_value(a)==value];child=apply_action(s.state,a,c);witnesses=tuple(s._search_witnesses)+(child.position,)
   player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_tt=False,use_ordering=False,use_native_semantic_legality=False)
   session=SimpleNamespace(compiled=c,state=child,_search_witnesses=witnesses);t=time.perf_counter()
   r=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=8))
   result=record_value(r);known=(r.completed_depth==2 and r.result_ordinary_qdepth==0) or bool(child.terminal_status and child.terminal_status.is_terminal)
   rows.append({'root':name,'action':value,'result':result,'root_value':-r.score if known else None,'known':known,'caller_seconds':time.perf_counter()-t});assert session.state is child and record_value(s.to_record())==before;save()
  print(name,len(actions),len(rows),flush=True)
 save(True);print('COMPLETE',len(rows),time.perf_counter()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
