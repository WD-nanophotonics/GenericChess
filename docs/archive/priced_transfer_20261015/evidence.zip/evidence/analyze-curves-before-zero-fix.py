from pathlib import Path
import json,collections,math
b=Path('.local_agent/priced-completion-20261015')
def gmean(xs):return math.exp(sum(math.log(x)for x in xs)/len(xs)) if xs else None
summary={}
for name in ['resource','tt','fixed','unit-fixed','q0','backend','interior-transfer']:
 file=b/(name+'-results.json')
 if not file.exists():continue
 d=json.loads(file.read_text(encoding='utf-8'));groups=collections.defaultdict(dict)
 for r in d['rows']:groups[(r['root'],r.get('seconds'),r['order'],r.get('temperature'))][r['arm']]=r
 details=[];counts=collections.Counter()
 base,can=('CoreCaller','scopedV2')if name=='backend'else('baseline','candidate')
 for key,grp in groups.items():
  if base not in grp or can not in grp:continue
  a=grp[base]['result'];c=grp[can]['result'];policy=lambda r:(r['completed_depth'],r.get('result_ordinary_qdepth'),r.get('result_check_hard_qdepth'))
  pa,pc=policy(a),policy(c);matching=pa==pc and pa[0]>0;sa=a['score'];sc=c['score']
  if name=='backend' and abs(sc)>50000000:sc=(1 if sc>0 else -1)*(1000000000-(100000000-abs(sc)))
  depth=c['completed_depth']-a['completed_depth'];out='deeper' if depth>0 else 'shallower' if depth<0 else 'same_depth';counts[out]+=1
  if matching:counts['same_policy']+=1
  if matching and sa!=sc:counts['score_error']+=1
  closed=name in ['fixed','unit-fixed'] and pa==(2,4,8) and pc==(2,4,8)
  r={'root':key[0],'seconds':key[1],'order':key[2],'temperature':key[3],'baseline_policy':pa,'candidate_policy':pc,'same_policy':matching,'same_policy_score_error':matching and sa!=sc,'baseline_score_normalized':sa,'candidate_score_normalized':sc,'same_action':a['action']==c['action'],'depth_change':depth,'closed_D2q4':closed,'kernel_ratio':c['elapsed_seconds']/a['elapsed_seconds'],'caller_ratio':grp[can]['caller_seconds']/grp[base]['caller_seconds'],'transition_ratio':c.get('transition_count')/a['transition_count'] if a.get('transition_count') else None,'baseline_q4':pa[1]==4,'candidate_q4':pc[1]==4}
  details.append(r)
 closed=[r for r in details if r['closed_D2q4']]
 summary[name]={'complete':d['complete'],'calls':len(d['rows']),'pairs':len(details),'counts':dict(counts),'same_action':sum(x['same_action']for x in details),'q4_baseline_calls':sum(r['result'].get('result_ordinary_qdepth')==4 for r in d['rows']if r['arm']==base),'q4_candidate_calls':sum(r['result'].get('result_ordinary_qdepth')==4 for r in d['rows']if r['arm']==can),'closedD2q4':len(closed),'closed_kernel_gmean':gmean([r['kernel_ratio']for r in closed]),'closed_caller_gmean':gmean([r['caller_ratio']for r in closed]),'closed_transition_gmean':gmean([r['transition_ratio']for r in closed if r['transition_ratio']]),'closed_kernel_slower':sum(r['kernel_ratio']>1 for r in closed),'seconds':d['seconds'],'no_action_calls':sum(r['result']['action'] is None for r in d['rows']),'errors':[r for r in details if r['same_policy_score_error']],'details':details}
 if name=='tt':
  summary[name]['temperatures']={temp:dict(collections.Counter('deeper'if r['depth_change']>0 else'shallower'if r['depth_change']<0 else'same_depth'for r in details if r['temperature']==temp))for temp in ['cold','warm']}
 if name=='backend':summary[name]['actual_backends']=dict(collections.Counter(r['actual_backend']for r in d['rows']))
if 'fixed'in summary and 'unit-fixed'in summary:
 u={(r['root'],r['order']):r for r in summary['unit-fixed']['details']};common=[]
 for r in summary['fixed']['details']:
  unit=u.get((r['root'],r['order']))
  if unit and unit['closed_D2q4'] and r['closed_D2q4']:common.append({'root':r['root'],'order':r['order'],'unit_transition_ratio':unit['transition_ratio'],'priced_transition_ratio':r['transition_ratio'],'unit_kernel_ratio':unit['kernel_ratio'],'priced_kernel_ratio':r['kernel_ratio']})
 summary['leaf_condition_intersection']={'pairs':len(common),'unit_transition_gmean':gmean([r['unit_transition_ratio']for r in common]),'priced_transition_gmean':gmean([r['priced_transition_ratio']for r in common]),'unit_kernel_gmean':gmean([r['unit_kernel_ratio']for r in common]),'priced_kernel_gmean':gmean([r['priced_kernel_ratio']for r in common]),'rows':common,'limit':'Finite closure intersection; all censors in full summaries. Separate timing batches/shared load, no universal causal timing claim.'}
(b/'curves-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
for k,v in summary.items():print(k,json.dumps({a:z for a,z in v.items()if a not in ['details','rows','errors']}))
