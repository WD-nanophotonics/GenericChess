from pathlib import Path
import sys,importlib.util,pytest,json,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));import generic_chess.native as native
assert native._MODULE is None
path=next((ROOT/'.local_agent/backend-owner-20261015').glob('main_v1*.pyd'));spec=importlib.util.spec_from_file_location('oldmain._native_core',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
class Reports:
 def __init__(self):self.rows=[]
 def pytest_runtest_logreport(self,report):
  if report.when=='call':self.rows.append({'node':report.nodeid,'outcome':report.outcome,'failure':str(report.longrepr) if report.failed else None})
r=Reports();t=time.perf_counter();code=pytest.main(['-q','-p','no:cacheprovider','tests/product/test_native_main_order_pv_witness.py','--basetemp',str(ROOT/'.local_agent/priced-completion-20261015/pv-old-pytest')],plugins=[r]);(ROOT/'.local_agent/priced-completion-20261015/pv-old-test.json').write_text(json.dumps({'exit':int(code),'rows':r.rows,'seconds':time.perf_counter()-t}),encoding='utf-8');raise SystemExit(code)
