from pathlib import Path
import json,hashlib,zipfile,re,datetime,collections
R=Path.cwd();b=R/'.local_agent/priced-completion-20261015'
def read(n):return json.loads((b/n).read_text(encoding='utf-8'))
def put(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf-8')
def clean(s):
 for old,new in [(str(R),'<PROJECT_ROOT>'),(str(R).replace('\\','/'),'<PROJECT_ROOT>'),(str(Path.home()),'<USER_HOME>'),(str(Path.home()).replace('\\','/'),'<USER_HOME>')]:s=s.replace(old,new)
 return s
cs=read('curves-summary.json');goal=read('goal-results.json');assert goal['complete'] and len(goal['rows'])==64
pairs=collections.defaultdict(dict)
for x in goal['rows']:pairs[(x['root'],x['order'])][x['arm']]=x
g=[]
for key,x in pairs.items():
 a,c=x['baseline'],x['candidate'];g.append({'root':key[0],'order':key[1],'stopped':bool(c['raw_goal_completed']),'physical_winning_child':c['physical_winning_child'],'same_action':a['result']['action']==c['result']['action'],'baseline_caller':a['caller_seconds'],'candidate_caller':c['caller_seconds'],'candidate_policy':[c['result']['completed_depth'],c['result']['result_ordinary_qdepth']]})
stops=[x for x in g if x['stopped']]
gs={'complete':True,'calls':64,'pairs':32,'physical_goal_stops':len(stops),'stopped_same_actions':sum(x['same_action'] for x in stops),'baseline_caller_range':[min(x['baseline_caller']for x in stops),max(x['baseline_caller']for x in stops)],'stopped_caller_range':[min(x['candidate_caller']for x in stops),max(x['candidate_caller']for x in stops)],'stopped_paid_seconds_saved':sum(x['baseline_caller']-x['candidate_caller']for x in stops),'seconds':goal['seconds'],'rows':g,'scope':'Private physically verified immediate-terminal decision-goal variant, not analysis default, generic prover or full-domain coverage.'}
put(b/'goal-summary.json',gs)
inter=cs['interior-transfer'];assert inter['complete'] and not inter['errors']
report=(b/'draft-report.md').read_text(encoding='utf-8')
table='|Comparison|Calls/pairs|Deeper / same / shallower|Matching policies with equal scores|Actual q4 calls|\n|---|---:|---:|---:|---:|\n'
for name in ['resource','tt','q0','backend','interior-transfer']:
 x=cs[name];c=x['counts'];table+=f"|{name}|{x['calls']}/{x['pairs']}|{c.get('deeper',0)} / {c.get('same_depth',0)} / {c.get('shallower',0)}|{c.get('same_policy',0)}|{x['q4_baseline_calls']} -> {x['q4_candidate_calls']}|\n"
report=report.replace('[CURVE_TABLE]',table)
report=report.replace('[INTERIOR_TRANSFER]',f"The full interior-only comparison closes128calls/64pairs:6deeper,54same,4shallower; all54matching policies have equal scores,62same actions, q4calls18->18. This mixed result does not justify replacing the shipped ordering. The pilot root is also already an immediate win, making extra post-win analysis an especially weak proxy for useful decision latency.")
backend='''## Decision goal versus post-win depth

The public AlphaBetaPlayer bridge uses static overrides, TT off but its default
ordering/root tactical shortcut. Native is plain exact-root TT0. These are
DIFFERENT algorithms, not a pure backend timer or the UI dynamic evaluator.
Actual routes are32NativeV1legal/CoreSearch,32CoreFallbacklegal/CoreSearch,
64ownedV2full. Core and Native mate scales are explicitly normalized.

Of28greater-depth pairs,16 already return the SAME immediate winning action
in Core (four roots, both budgets/orders). Core finishes in .00395-.07674s;
Native consumes2.003-8.038s. These16 are not useful decision gains. The remaining
48pairs have12greater/36same depth, still with retained-policy limitations.

Six very short Core API timers report zero because monotonic uses15.625ms
GetTickCount64. Raw zeros remain. Caller perf_counter uses high-resolution QPC;
Core API elapsed and C kernel elapsed are not interchangeable. The first
zero-division analysis failure is preserved and fixed without rerunning searches.

A new PRIVATE source-built decision-goal prototype physically applies the chosen
move and recomputes the full true terminal before returning. A mate-like score
only triggers this verification. It acts only after completedD1/exact-root,
nondeclaration rules; actual winner must equal root player. Cancellation/errors
retain their control path. The one extra checked transition is separately counted.
It reports actualD1/q0/root_immediate_win; it does not pretend q4 was completed.
'''
backend+=f"\nAll16original roots/bothorders/2s give64calls and32pairs. {len(stops)}candidate calls stop with verified actual wins; {sum(x['same_action']for x in stops)}return the same literal action as baseline. Caller range {gs['stopped_caller_range'][0]:.6f}-{gs['stopped_caller_range'][1]:.6f}s versus {gs['baseline_caller_range'][0]:.6f}-{gs['baseline_caller_range'][1]:.6f}s; paired saved caller time {gs['stopped_paid_seconds_saved']:.3f}s. All other cases remain in the archive. This changes the requested finite-analysis goal: it is a decision-latency result, not same-analysis speedup or a universal certificate. Product defaults/C are unchanged. Next implement an explicit decision-goal interface while preserving finite-analysis callers, declarations and stop semantics. It neither implements nor modifies AUX's multi-step prover/verifier/cursor.\n\n"
report=report.replace('## An actual supported-rule PV counterexample',backend+'## An actual supported-rule PV counterexample')
report=report.replace('The later interior candidate is separately source-built and evaluated as stated.','The later interior and goal candidates are separately source-built and evaluated as stated.')
report=report.replace('The new54thread explicitly owns the generic proof-tree/verifier/StrategyCursor\nprototype. Dot\'s induction and terminal-before-empty-ALL concern are reference\nadvice; the unpublished implementation has not been read or validated here.',"At final recovery, AUX54 is now published at26fd52997023bf23dc58e8adc0e591ff43fd76d9; its full report was read without checkout writes. It reports56tests, zero observed false wins on3496KRK and922unfamiliar drop-rule roots, and PN42vsAND/OR19 at4096 visits on64roots. These are AUX-reported, not primary reruns/source certification. Capped learning remains unproven. AUX55 continues certificate-tail conversion; its full thread and Dot's fixed-denominator objection were read. Adopt that interpretation, leave implementation/experiments in AUX's lane. Dot's induction/empty-ALL advice is conditional evidence, not execution by Dot.")
report=report.replace('[DELIVERY_AND_NEXT]',"## Delivery and next action\n\nThe only product-code addition is the two-case optimal-PV-prefix regression; product implementation/defaults and UI remain unchanged. Relevant publisher tests and full remote SHA are recorded in the delivery receipt. Technical sources, complete inputs/results, failed diagnostics and source-build replay evidence are in ../archive/priced_transfer_20261015/evidence.zip with member hashes/restore mappings. Six36fileC/H source sets accompany executed drivers; binaries and personal/account records are excluded. Some publication copies have paths sanitized; exact private originals remain.\n\nNext primary work is an explicit immediate-terminal decision-goal mode with finite-analysis compatibility, then bounded cost/stop/decl/TT checks. Canonical-root mixed results do not merit default adoption. V2 publicdispatch remains a separate later interface question. No solver/cursor duplication, universal price claim, Elo campaign or science-complete claim.")
(R/'docs/research/ROOT_ORDER_COST_AND_PRICED_TRANSFER.md').write_text(report,encoding='utf-8')
put(R/'docs/research/data/priced_transfer_20261015.json',{'curves':cs,'goal':gs,'science':'OPEN','product_implementation_changed':False,'source_pin':'41e69e1dd8ab2c459239175d0c4091f90dffb389','tests':'2 new behavioral PV regressions; 24 affected tests pass; final publisher receipt records actual run','auxiliary_report':'26fd52997023bf23dc58e8adc0e591ff43fd76d9','no_auxiliary_checkout_writes':True})
arc=R/'docs/archive/priced_transfer_20261015';arc.mkdir(parents=True,exist_ok=True);members=[]
excluded=('recovery','mid-','final-slack','final-aux','coordination','aux54-','pv-send','primary-wrapper')
files=[]
for p in b.iterdir():
 if not p.is_file() or p.suffix not in ['.py','.json','.log']:continue
 if p.name.startswith(excluded) or p.name in ['auxiliary-assessment.json','source-identity.json']:continue
 files.append(('evidence/'+p.name,p,p.relative_to(R).as_posix()))
# source identity is technical, sanitize string paths without numeric conversion
files.append(('evidence/source-identity.json',b/'source-identity.json',(b/'source-identity.json').relative_to(R).as_posix()))
for label,folder in [('old_v2','.local_agent/wide-interface-20261015/src'),('fullmain_v2','.local_agent/backend-owner-20261015/src_scoped_v2'),('old_main_v1','.local_agent/backend-owner-20261015/src_main_v1'),('production_v1','generic_chess/_native'),('interior_v2','.local_agent/priced-completion-20261015/src_interior_v2'),('goal_v2','.local_agent/priced-completion-20261015/src_goal_v2')]:
 ps=[p for p in (R/folder).iterdir()if p.suffix in ['.c','.h']];assert len(ps)==36,(label,len(ps))
 files += [('source/'+label+'/'+p.name,p,p.relative_to(R).as_posix())for p in ps]
p=R/'.local_agent/backend-owner-20261015/owned_common.py';files.append(('support/owned_common.py',p,p.relative_to(R).as_posix()))
with zipfile.ZipFile(arc/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,p,restore in files:
  raw=p.read_bytes();s=raw.decode('utf-8-sig');safe=clean(s).encode('utf-8');assert not re.search(rb'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',safe),name
  assert b'C:\\Users\\wdai' not in safe and b'<USER_HOME>'not in safe,name
  z.writestr(name,safe);members.append({'name':name,'bytes':len(safe),'sha256':hashlib.sha256(safe).hexdigest(),'original_sha256':hashlib.sha256(raw).hexdigest(),'sanitized_or_normalized':safe!=raw,'restore_to':restore})
with zipfile.ZipFile(arc/'evidence.zip')as z:
 assert z.testzip()is None
 for m in members:assert hashlib.sha256(z.read(m['name'])).hexdigest()==m['sha256']
put(arc/'manifest.json',{'members':members,'count':len(members),'zip_sha256':hashlib.sha256((arc/'evidence.zip').read_bytes()).hexdigest(),'source_pin':'41e69e1dd8ab2c459239175d0c4091f90dffb389','published_bytes_sanitized':True,'private_raw_slack_excluded':True,'binaries_excluded':True})
(arc/'README.md').write_text('''# Source and evidence closure

Source-only technical archive. Pin the project to41e69e1dd8ab2c459239175d0c4091f90dffb389 and add the published PV test, or use this publication commit. Use a NEW checkout/export, existing Python3.12/Zig dependencies and the ignored .local_agent layout. Restore members using manifest restore_to; never overwrite existing unique evidence. No installed binary is supplied. Build replay via build_replay_workspace.py; four-source isolated replay was actually run, not merely proposed. Interior/goal source builds and full saved comparisons are separate evidence. Do not rerun long curves merely to inspect data. Absolute machine paths in publication copies use placeholders; adjust dependency paths if needed. Source/raw and publication hashes distinguish normalization. Exact private originals are retained locally.

Study plans precede their own queries. Adaptive interior/goal work is exposed development. Goal changes the requested stopping objective. Censors, false-prefix failure, raw zero timers and corrections remain. No product V2 activation or generic prover implementation.
''',encoding='utf-8')
put(arc/'segment_review.json',{'science':'OPEN','source_review':'Product implementation unchanged; 2 behavioral regression cases. Private interior guard and physical terminal-goal changes separately inspected. All closed studies retain adverse/censored cases.','archive_members':len(members),'crc_and_all_member_hashes_verified':True,'own_search_producers_closed':True,'auxiliary_overlap':'No sidemission/shared solver/runtime writes; independent published report only.','limitations':['Finite16roots; both32families censored','Dependent played roots/order repeats','Different algorithms and ordinary-q goals','Shared machine timing','Goal prototype changes finite-analysis stopping objective','AUX report read, not reexecuted']})
for path,text in [('docs/research/LOCAL_MAINLINE.md','''ROOT_ORDER_COST_AND_PRICED_TRANSFER.md is current. Product implementation stays41e69e1; new actual-rule PV-prefix regression2pass/affected24pass. Prospective priced q4:64pairs12deeper44same8shallower; TT64mixed/q4calls24->22. Same8closed-pair unit/priced transition .7343/.5289 rejects cross-cohort price-cause inference. Canonical-root transfer6deeper54same4shallower/q4unchanged: no default adoption. PublicCore bridge has16already-wonM1pairs among28greater-depth pairs; depth is not utility. Private physical-terminal goal-stop comparison now closes64calls with actual terminals verified. Next explicit decision-goal API with finite-analysis compatibility; preserve declaration/NC/TT/cancel semantics. V2 remains private; no UI change. AUX54 fixed26fd529 report read, generic prover/verifier/cursor+tail conversion left to AUX; no cross-checkout writes or primary rerun claim.\n\n'''),('docs/operations/BACKEND_HANDOFF.md','''##2026-10-15 priced transfer follow-on

See ../research/ROOT_ORDER_COST_AND_PRICED_TRANSFER.md. No product implementation/default/UI change in this segment; actual-rule optimal-PV regression added. Private interior-only ordering is mixed and not adopted. Private physically verified immediate-goal stop improves decision latency but changes finite-analysis objective, so it requires an explicit caller mode before activation. ProductV1<=16/Corefallback and creating-module ownership remain. AUX generic prover/cursor stays on sidemission.\n\n'''),('docs/operations/COLLABORATION_LOG.md','''##2026-10-15 PRIMARY priced completion / AUX54 solver separation

PRIMARY completes prospective16root priced/q0/TT/fixed/backend comparisons, a legal-rule PV counterexample/regression, source replay, root-order intervention and immediate-terminal decision-goal prototype. See ../research/ROOT_ORDER_COST_AND_PRICED_TRANSFER.md and its hashed archive. Actual product implementation/default/UI unchanged.

DEV_AUX53 fixed59f5eef and54 fixed26fd52997023bf23dc58e8adc0e591ff43fd76d9 reports fully read via remote Git objects. AUX54 reports generic AND/OR+PN trees, full-defense verifier and rank-decreasing cursor,56tests/3496KRK+922unfamiliar roots without observed false wins; learning remains capped/unproven. PRIMARY did not execute or certify that implementation. AUX55 is actively checking physical tail conversion; full request/reply read, no new assignment or duplicate solver.

Concrete Slack ownership messages delivered1792036243.974859 and1792038125.290899; legal-PV evidence1792037019.020239. Same shared account, simple roleIDs, no identity challenges. Reads covered new roots and full primary/AUX54/AUX55 threads with no further pages; exact originals stored privately before assessment. Dot's earlier PV objection became an actual rule-level counterexample; adopt scope restriction and behavioral test. Adopt empty-ALL/terminal and full planned-denominator interpretation as reference, leave implementation in AUX lane. AUX54 now published, replacing the earlier checkpoint's unpublished status. A prior first-excerpt/old52remote inference was corrected from full53evidence, not concealed.

No observed write conflict, cross-checkout/state edit, merge, pause request, new Agent, routine acknowledgement loop or duplicated prover/cursor. Communication produced concrete ownership separation and a reproduced PV mechanism; elapsed response times do not establish wake guarantees or quantified time saved. Primary's one-off M3certificate and physical M1goalstop have narrower roles than AUX generic solver. No unresolved coordination blocker. Final tested sandbox revision/report/archive link is sent to Dot; fixed AUX report: https://github.com/WD-nanophotonics/GenericChess/blob/26fd52997023bf23dc58e8adc0e591ff43fd76d9/results/dev_aux/SEGMENT_20261015_54.md .\n\n''')]:
 p=R/path;s=p.read_text(encoding='utf-8');s=text+s if 'LOCAL_MAINLINE'not in path else s.replace('## Priority and current decision\n\n','## Priority and current decision\n\n'+text,1);p.write_text(s,encoding='utf-8')
print(json.dumps({'members':len(members),'zip_bytes':(arc/'evidence.zip').stat().st_size,'goal':{k:v for k,v in gs.items()if k!='rows'}}))
