from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
source_b=b;b=ROOT/'.local_agent/priced-completion-20261015'
spec=importlib.util.spec_from_file_location('pricedscoped._native_core',next(source_b.glob('scoped_v2*.pyd')));candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
bridges={'baseline':V2Boundary(wide),'candidate':V2Boundary(candidate)}
compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
class Capture(V2Boundary):
 def semantic_engine_search(self,*args):
  out=self.kernel.semantic_engine_search(*args);self.raw=out;return out
spec=importlib.util.spec_from_file_location('goal._native_core',next(b.glob('goal_v2*.pyd')));goal=importlib.util.module_from_spec(spec);spec.loader.exec_module(goal)
bridges={'baseline':Capture(candidate),'candidate':Capture(goal)};compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
inputs=json.loads((b/'inputs.json').read_text());rows=[];roots=[];start=time.monotonic()
def save(complete=False,error=None):
 (b/'goal-results.json').write_text(json.dumps({'complete':complete,'rows':rows,'roots':roots,'seconds':time.monotonic()-start,'error':error,'default_unchanged':native._MODULE is installed}),encoding='utf-8')
try:
 for x in inputs['samples']:
  if not x['included']:continue
  c,s=case(x);pr=next(z for z in json.loads((b/'resource-results.json').read_text())['roots']if z['name']==x['name']);v=pr['board_values'];h=pr['hand_values'];before=record_value(s.to_record());rules={name:compilers[name](c)for name in bridges}
  for order in [0,1]:
   for arm in (list(bridges)if order==0 else list(bridges)[::-1]):
    p.rr.stopped()
    if time.monotonic()-start>360:raise TimeoutError('declared360s goal fuse')
    t=time.perf_counter();engine=SemanticSearchEngine(c,rules[arm],board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);r=engine.search(s,SearchLimits(max_depth=12,max_time_seconds=2,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);caller=time.perf_counter()-t;raw=bridges[arm].raw
    child=apply_action(s.state,r.action,c);physical=child.terminal_status.is_terminal and child.terminal_status.winner==s.state.position.side_to_move
    if raw.get('root_goal_completed'):assert physical and r.completed_depth==1 and r.result_ordinary_qdepth==0 and raw['root_goal_checked_transitions']==1
    assert record_value(s.to_record())==before and native._MODULE is installed
    rows.append({'root':x['name'],'n':x['n'],'order':order,'seconds':2,'arm':arm,'caller_seconds':caller,'result':record_value(r),'physical_winning_child':physical,'child_terminal':record_value(child.terminal_status),'raw_goal_completed':raw.get('root_goal_completed'),'raw_goal_checked':raw.get('root_goal_checked_transitions')});save()
  print(x['name'],len(rows),flush=True)
 save(True);print('COMPLETE',len(rows),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
