from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
source_b=b;b=ROOT/'.local_agent/priced-completion-20261015'
spec=importlib.util.spec_from_file_location('pricedscoped._native_core',next(source_b.glob('scoped_v2*.pyd')));candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
bridges={'baseline':V2Boundary(wide),'candidate':V2Boundary(candidate)}
compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
class Capture(V2Boundary):
 def semantic_engine_search(self,*args):
  out=self.kernel.semantic_engine_search(*args);self.raw=out;return out
bridges={'baseline':Capture(wide),'candidate':Capture(candidate)};compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
x=next(x for x in json.loads((b/'inputs.json').read_text())['samples']if x['name']=='3701-ply0');pr=next(x for x in json.loads((b/'resource-results.json').read_text())['roots']if x['name']==x['name'] and x['name']=='3701-ply0');c,s=case(x);rows=[];start=time.perf_counter();before=record_value(s.to_record())
for order in [0,1]:
 for arm in (list(bridges) if order==0 else list(bridges)[::-1]):
  p.rr.stopped();nr=compilers[arm](c);e=SemanticSearchEngine(c,nr,board_values=pr['board_values'],hand_values=pr['hand_values'],tt_megabytes=0,ordering_cache_enabled=False);r=e.search(s,SearchLimits(max_depth=2,max_time_seconds=8,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True)
  assert r.completed_depth==2 and r.result_ordinary_qdepth==4 and record_value(s.to_record())==before
  rows.append({'arm':arm,'order':order,'raw':record_value(bridges[arm].raw),'result':record_value(r)})
(b/'outlier-results.json').write_text(json.dumps({'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8')
for r in rows:print(r['arm'],r['order'],{k:r['raw'].get(k)for k in ['nodes','qnodes','root_tie_refinements','root_tie_aborts','transition_count','main_binary_order_calls','elapsed_seconds']})
