from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
source_b=b;b=ROOT/'.local_agent/priced-completion-20261015'
spec=importlib.util.spec_from_file_location('pricedscoped._native_core',next(source_b.glob('scoped_v2*.pyd')));candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
bridges={'baseline':V2Boundary(wide),'candidate':V2Boundary(candidate)}
compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
class Material:
 def __init__(self,v,h):self.v=v;self.h=h
 def type_value(self,tid):return self.v[tid]
 def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
 def evaluate(self,state):
  p=state.position;side=p.side_to_move
  return sum((1 if x.owner==side else -1)*self.v[x.current_type_id] for x in p.board if x is not None)+sum((1 if owner==side else -1)*count*self.h[tid] for owner,hand in enumerate(p.hands) for tid,count in hand.counts)
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
inputs=json.loads((b/'inputs.json').read_text(encoding='utf-8'));assert inputs['complete'];rows=[];roots=[];start=time.monotonic()
def save(complete=False,error=None):
 (b/'backend-results.json').write_text(json.dumps({'complete':complete,'rows':rows,'roots':roots,'seconds':time.monotonic()-start,'error':error,'default_unchanged':native._MODULE is installed}),encoding='utf-8')
try:
 for x in inputs['samples']:
  if not x['included']:continue
  prep=time.perf_counter();c,s=case(x);profile=p.build_ruleset_profile(c,p.EvaluationConfig());v={tid:int(round(val)) for tid,val in profile.board_value_by_type.items()};h={tid:int(round(val)) for tid,val in profile.hand_value_by_base_type.items()};before=record_value(s.to_record());ir_profile=time.perf_counter()-prep
  t=time.perf_counter();nr=compilers['candidate'](c);native_compile=time.perf_counter()-t;ev=Material(v,h);roots.append({'name':x['name'],'ir_profile_seconds':ir_profile,'native_compile_seconds':native_compile,'board_values':v,'hand_values':h})
  for seconds in [2,8]:
   for order in [0,1]:
    for arm in (['CoreCaller','scopedV2'] if order==0 else ['scopedV2','CoreCaller']):
     p.rr.stopped();assert native._MODULE is installed
     if time.monotonic()-start>1100:raise TimeoutError('declared1100s backend fuse')
     t=time.perf_counter();limits=SearchLimits(max_depth=12,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8)
     if arm=='CoreCaller':
      engine=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_tt=False,use_native_semantic_legality=True);actual='NativeV1legal/CoreSearch' if engine.native_legality_provider else 'CoreFallbacklegal/CoreSearch';construct=time.perf_counter()-t;r=engine.choose_action(s,limits)
     else:
      engine=SemanticSearchEngine(c,nr,board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);actual='ownedNativeV2full';construct=time.perf_counter()-t;r=engine.search(s,limits,root_window_pruning=True)
     rows.append({'root':x['name'],'n':x['n'],'seconds':seconds,'order':order,'arm':arm,'actual_backend':actual,'constructor_seconds':construct,'caller_seconds':time.perf_counter()-t,'result':record_value(r),'has_action':r.action is not None})
     assert (r.action is None or r.action in s.legal_actions()) and record_value(s.to_record())==before;save()
  print(x['name'],len(rows),flush=True)
 save(True);print('COMPLETE',len(rows),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
