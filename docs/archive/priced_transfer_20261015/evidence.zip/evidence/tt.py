from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
source_b=b;b=ROOT/'.local_agent/priced-completion-20261015'
spec=importlib.util.spec_from_file_location('pricedscoped._native_core',next(source_b.glob('scoped_v2*.pyd')));candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
bridges={'baseline':V2Boundary(wide),'candidate':V2Boundary(candidate)}
compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
inputs=json.loads((b/'inputs.json').read_text(encoding='utf-8'));assert inputs['complete'];rows=[];roots=[];start=time.monotonic()
def save(complete=False,error=None):
 (b/'tt-results.json').write_text(json.dumps({'complete':complete,'rows':rows,'roots':roots,'seconds':time.monotonic()-start,'error':error,'default_unchanged':native._MODULE is installed}),encoding='utf-8')
try:
 for x in inputs['samples']:
  if not x['included'] or not x['name'].endswith('-ply0'):continue
  c,s=case(x);profile=p.build_ruleset_profile(c,p.EvaluationConfig());v={tid:int(round(val)) for tid,val in profile.board_value_by_type.items()};h={tid:int(round(val)) for tid,val in profile.hand_value_by_base_type.items()};before=record_value(s.to_record());rules={name:compilers[name](c) for name in bridges}
  roots.append({'name':x['name'],'board_values':v,'hand_values':h})
  for seconds in [2,8]:
   for order in [0,1]:
    engines={arm:SemanticSearchEngine(c,nr,board_values=v,hand_values=h,tt_megabytes=64,ordering_cache_enabled=False) for arm,nr in rules.items()}
    for temperature in ['cold','warm']:
     for arm in (list(bridges) if order==0 else list(bridges)[::-1]):
      p.rr.stopped();assert native._MODULE is installed
      if time.monotonic()-start>1100:raise TimeoutError('declared1100s fuse')
      t=time.perf_counter();r=engines[arm].search(s,SearchLimits(max_depth=12,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True)
      rows.append({'root':x['name'],'n':x['n'],'order':order,'temperature':temperature,'seconds':seconds,'arm':arm,'caller_seconds':time.perf_counter()-t,'result':record_value(r)})
      assert r.action in s.legal_actions() and record_value(s.to_record())==before;save()
  print(x['name'],len(rows),flush=True)
 save(True);print('COMPLETE',len(rows),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
