from pathlib import Path
import sys,json,time
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from test_native_main_order_pv_witness import phase_graph
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.native.mirror import expected_snapshot
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.identity import position_identity_key
from scripts.research_record import record_value
from types import SimpleNamespace
c=compile_ruleset_for_execution(phase_graph());s=GameSession(c);nr=compile_native_semantic_rules(c);rows=[];edges=0;start=time.perf_counter()
def visit(state,witnesses,depth,path):
 global edges
 ss=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses);pos=pack_semantic_search_position(c,nr,ss);snap=sem.snapshot(nr,pos);expected=expected_snapshot(state.position,nr,c)
 for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(expected[k]),k
 assert sem.position_key(nr,pos)==str(position_identity_key(state.position,c))
 assert snap['history_exact'] and snap['history_events_exact']
 assert len(snap['history'])==len(witnesses)==len(state.history)
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(w,c))for w in witnesses]
 codes=sem.transient_legal_actions(nr,pos);native={sem.public_action(nr,x):x for x in codes};acts=tuple(legal_actions(state,c));assert set(acts)==set(native)
 rows.append({'path':path,'state':record_value(state),'legal_actions':record_value(acts),'native_codes':[native[a]for a in acts],'terminal':record_value(state.terminal_status),'state_history_key_checked':True})
 if depth:
  for a in acts:
   child=apply_action(state,a,c);edges+=1;visit(child,witnesses+(child.position,),depth-1,path+[record_value(a)])
visit(s.state,tuple(s._search_witnesses),4,[])
b=ROOT/'.local_agent/priced-completion-20261015';(b/'pv-full-rule-qualification.json').write_text(json.dumps({'states':len(rows),'edges':edges,'seconds':time.perf_counter()-start,'rows':rows},indent=2),encoding='utf-8');print('QUALIFIED',len(rows),edges)
