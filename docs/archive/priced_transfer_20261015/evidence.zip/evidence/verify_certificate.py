from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
b=ROOT/'.local_agent/priced-completion-20261015';d=json.loads((b/'mate-certificate.json').read_text());x=next(x for x in json.loads((b/'inputs.json').read_text())['samples']if x['name']==d['root']);c,s=case(x);assert not c.ir.declarations;owner=s.state.position.side_to_move;nr=nc.compile_native_semantic_rules(c);checked=0
for row in d['rows']:
 action,=[a for a in s.legal_actions()if record_value(a)==row['action']];child=apply_action(s.state,action,c);assert record_value(child)==row['child'];responses=tuple(legal_actions(child,c));assert len(responses)==len(row['responses'])
 assert {json.dumps(record_value(a),sort_keys=True)for a in responses}=={json.dumps(z['defense'],sort_keys=True)for z in row['responses']}
 for z in row['responses']:
  defense,=[a for a in responses if record_value(a)==z['defense']];state=apply_action(child,defense,c);assert record_value(state)==z['defended_state']
  if z['winning_reply'] is None:continue
  w=z['winning_reply'];a,=[a for a in legal_actions(state,c)if record_value(a)==w['reply']];final=apply_action(state,a,c);assert record_value(final)==w['state'];assert final.terminal_status.is_terminal and final.terminal_status.winner==owner
  ss=SimpleNamespace(compiled=c,state=final,_search_witnesses=tuple(s._search_witnesses)+(child.position,state.position,final.position));pos=pack_semantic_search_position(c,nr,ss);check(c,ss,nr,pos);checked+=1
 if row['certified']:assert responses and all(z['winning_reply']for z in row['responses'])
print('VERIFIED',checked,'terminalwitnesses; candidate all opposing replies covered; baseline unknown')
(b/'mate-certificate-verification.json').write_text(json.dumps({'passed':True,'checked_terminal_witnesses':checked,'all_opposing_frontiers_verified':True,'literal_core_states_and_native_full_history_checked':True}),encoding='utf-8')
