from pathlib import Path
import json,collections,math
b=Path('.local_agent/priced-completion-20261015');d=json.loads((b/'resource-results.json').read_text());groups=collections.defaultdict(dict)
for r in d['rows']:groups[(r['root'],r['seconds'],r['order'])][r['arm']]=r
pairs=[]
for k,g in groups.items():
 if len(g)!=2:continue
 a=g['baseline']['result'];c=g['candidate']['result'];policy=lambda r:(r['completed_depth'],r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])
 pairs.append({'root':k[0],'seconds':k[1],'order':k[2],'baseline_policy':policy(a),'candidate_policy':policy(c),'same_policy':policy(a)==policy(c),'score_same':a['score']==c['score'],'same_action':a['action']==c['action'],'depth_change':c['completed_depth']-a['completed_depth'],'caller_ratio':g['candidate']['caller_seconds']/g['baseline']['caller_seconds'],'baseline_kernel':a['elapsed_seconds'],'candidate_kernel':c['elapsed_seconds'],'baseline_q4':a['result_ordinary_qdepth']==4,'candidate_q4':c['result_ordinary_qdepth']==4})
summary={'complete':d['complete'],'calls':len(d['rows']),'pairs':len(pairs),'deeper':sum(x['depth_change']>0 for x in pairs),'same_depth':sum(x['depth_change']==0 for x in pairs),'shallower':sum(x['depth_change']<0 for x in pairs),'same_policy':sum(x['same_policy'] for x in pairs),'matching_policy_score_errors':[x for x in pairs if x['same_policy'] and not x['score_same']],'same_action':sum(x['same_action'] for x in pairs),'q4_baseline_calls':sum(r['result']['result_ordinary_qdepth']==4 for r in d['rows'] if r['arm']=='baseline'),'q4_candidate_calls':sum(r['result']['result_ordinary_qdepth']==4 for r in d['rows'] if r['arm']=='candidate'),'max_caller_over_budget':max([r['caller_seconds']-r['seconds'] for r in d['rows']] or [0]),'seconds':d['seconds'],'pairs_detail':pairs}
(b/'resource-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in summary.items() if k!='pairs_detail'}))
