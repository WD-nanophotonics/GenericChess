from pathlib import Path
import sys,json,importlib.util,traceback
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from generic_chess.rules.schema import RuleSet,RuleSemanticAction,RuleGeometrySpec,RuleSlotGuard,RuleAuxState,RuleActionEffect,RuleSquareRef,RuleTypeRef,RuleInvariant
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.rules.serialization import serialize_ruleset
from scripts.research_record import record_value
b=ROOT/'.local_agent/priced-completion-20261015'
def fixed(x,y):return RuleSquareRef('fixed',square=(x,y),owner_relative=False)
def phase(k):return fixed(k%4,k//4)
slot=RuleAuxState('phase','square_or_none','global','persistent',initial=(0,0))
actors={'W':(1,0),'B':(1,3)}
# R0->A1; A1->V2,U3; V2->VC4->end; U3->Q5,C6; Q5->end5,end3; C6->end5.
edges=[('r','W',0,1,(0,1),None),('aV','B',1,2,(0,1),None),('aU','B',1,3,(1,1),None),('v','W',2,4,(0,1),None),('vleaf','B',4,7,(0,1),6),('q','W',3,5,(0,1),None),('c','W',3,6,(1,3),None),('q5','B',5,7,(0,1),5),('q3','B',5,7,(1,1),3),('c5','B',6,7,(0,1),5),('endW','W',7,7,(0,1),None),('endB','B',7,7,(0,1),None)]
actions=[]
for name,actor,src,dst,target,val in edges:
 ox,oy=actors[actor];effects=[RuleActionEffect('set_token',slot_name='phase',square_ref=phase(dst))]
 if val is not None:effects.append(RuleActionEffect('set_current_type',square_ref=fixed(2,2),type_ref=RuleTypeRef('explicit',type_id='S'+str(val))))
 actions.append(RuleSemanticAction(name=name,type_ids=(actor,),geometry=RuleGeometrySpec('leap',offset=(target[0]-ox,target[1]-oy),owner_relative=False),target_relation='enemy' if name=='c' else 'empty',slot_guards=(RuleSlotGuard('phase',square_ref=phase(src)),),aux_state=(slot,),effects=tuple(effects),invariants=(RuleInvariant('own_anchor_safe'),)))
board=[[None]*4 for _ in range(4)]
for owner,tid,xy in [(0,'K',(0,0)),(1,'K',(3,3)),(0,'W',(1,0)),(1,'B',(1,3)),(0,'S0',(2,2))]:board[xy[1]][xy[0]]=Piece(owner,tid,tid)
pts=tuple(PieceType(t,t,(),is_anchor=t=='K') for t in ['K','W','B','S0','S3','S5','S6'])
rules=RuleSet(board_size=4,piece_types=pts,initial_position=tuple(tuple(r)for r in board),drop_allowed={t:((False,)*16,)*2 for t in ['W','B','S0','S3','S5','S6']},semantic_actions=tuple(actions))
c=compile_ruleset_for_execution(rules);s=GameSession(c);v={t:0 for t in ['K','W','B','S0']};v.update(S3=3,S5=5,S6=6)
def evalstate(st):return sum((1 if p.owner==st.position.side_to_move else -1)*v[p.current_type_id] for p in st.position.board if p)
node_count=0
def oracle(st,depth):
 global node_count
 node_count+=1
 if depth==0:return evalstate(st)
 acts=legal_actions(st,c);assert acts and not st.terminal_status.is_terminal
 return max(-oracle(apply_action(st,a,c),depth-1)for a in acts)
# Public Core legality and complete finite-depth material tree are independent of native search.
score=oracle(s.state,4);rows=[]
for label,pattern in [('baseline','.local_agent/backend-owner-20261015/main_v1*.pyd'),('unrestricted','.local_agent/backend-owner-20261015/main_v1*.pyd')]:pass
import generic_chess.native as native
modules={'shipped':native._module()}
spec=importlib.util.spec_from_file_location('pvunrestricted._native_core',next((ROOT/'.local_agent/backend-owner-20261015').glob('main_v1*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules['unrestricted']=m
import generic_chess.native.compiler as nc,inspect
for label,module in modules.items():
 space=dict(nc.__dict__);space['_module']=lambda module=module:module;exec(inspect.getsource(nc.compile_native_semantic_rules),space);nr=space['compile_native_semantic_rules'](c);pos=pack_semantic_search_position(c,nr,s)
 for window in [False,True]:
  r=sem.semantic_iterative_search(nr,pos,4,board_values=v,hand_values=v,tt_megabytes=0,root_window_pruning=window)
  st=s.state;prefix=[]
  for i,code in enumerate(r['principal_variation']):
   a=sem.public_action(nr,code);assert a in legal_actions(st,c);child=apply_action(st,a,c);expected=oracle(st,4-i);chosen=-oracle(child,3-i);prefix.append({'ply':i,'action':record_value(a),'expected':expected,'chosen':chosen,'optimal':expected==chosen});st=child
  rows.append({'image':label,'root_window':window,'raw':record_value(r),'prefix':prefix,'all_prefix_optimal':all(x['optimal']for x in prefix)});print(label,window,r['score'],rows[-1]['all_prefix_optimal'],flush=True)
(b/'pv-witness-rules.json').write_text(serialize_ruleset(rules),encoding='utf-8')
(b/'pv-witness-results.json').write_text(json.dumps({'oracle_root':score,'oracle_nodes':node_count,'values':v,'rows':rows},indent=2),encoding='utf-8')
