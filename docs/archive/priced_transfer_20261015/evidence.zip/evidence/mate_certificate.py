from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
b=ROOT/'.local_agent/priced-completion-20261015';data=json.loads((b/'resource-results.json').read_text());x=next(x for x in json.loads((b/'inputs.json').read_text())['samples']if x['name']=='3702-ply8');c,s=case(x);assert not c.ir.declarations
chosen={r['arm']:r['result']['action']for r in data['rows']if r['root']==x['name']};owner=s.state.position.side_to_move;before=record_value(s.to_record());rows=[];start=time.perf_counter();count=0
for arm,value in chosen.items():
 action,=[a for a in s.legal_actions()if record_value(a)==value];child=apply_action(s.state,action,c);responses=[]
 for defense in legal_actions(child,c):
  p.rr.stopped();state=apply_action(child,defense,c);count+=1;mate=None
  for reply in legal_actions(state,c):
   if time.perf_counter()-start>30 or count>=20000:raise TimeoutError('declared30s/20000actions fuse')
   final=apply_action(state,reply,c);count+=1
   if final.terminal_status.is_terminal and final.terminal_status.winner==owner:
    mate={'reply':record_value(reply),'terminal':record_value(final.terminal_status),'state':record_value(final)};break
  responses.append({'defense':record_value(defense),'defended_state':record_value(state),'winning_reply':mate})
 rows.append({'arm':arm,'action':value,'child':record_value(child),'responses':responses,'certified':bool(responses) and all(z['winning_reply']is not None for z in responses),'uncovered':sum(z['winning_reply']is None for z in responses)})
assert record_value(s.to_record())==before
(b/'mate-certificate.json').write_text(json.dumps({'root':x['name'],'root_owner':owner,'ruleset':x['ruleset'],'initial_state':x['state'],'walk':x['walk'],'rows':rows,'seconds':time.perf_counter()-start,'checked_actions':count,'baseline_noncertificate':'UNKNOWN, not a loss; may win at longer horizon'},indent=2),encoding='utf-8')
print([(r['arm'],len(r['responses']),r['certified'],r['uncovered'])for r in rows],count,time.perf_counter()-start)
