from pathlib import Path
import subprocess,sys,json,uuid,shutil,sysconfig,time
ROOT=Path.cwd();b=ROOT/'.local_agent/priced-completion-20261015';out=b/('isolated-replay-'+uuid.uuid4().hex[:8]);out.mkdir();assert out.resolve().is_relative_to(b.resolve())
files=subprocess.check_output(['git','ls-files'],text=True).splitlines()
for name in files+['tests/product/test_native_main_order_pv_witness.py']:
 if name.endswith('.py') and (name.startswith('generic_chess/') or name.startswith('scripts/') or name=='tests/product/test_native_main_order_pv_witness.py'):
  p=out/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,p)
for relative in ['.local_agent/wide-interface-20261015/src','.local_agent/backend-owner-20261015/src_scoped_v2','.local_agent/backend-owner-20261015/src_main_v1','generic_chess/_native']:
 dest=out/relative;dest.mkdir(parents=True,exist_ok=True)
 for p in (ROOT/relative).iterdir():
  if p.suffix in ['.c','.h']:shutil.copyfile(p,dest/p.name)
for relative in ['.local_agent/backend-owner-20261015/owned_common.py','.local_agent/priced-completion-20261015/inputs.json','.local_agent/priced-completion-20261015/resource-results.json','.local_agent/priced-completion-20261015/replay_qualify.py','.local_agent/priced-completion-20261015/mate-certificate.json','.local_agent/priced-completion-20261015/verify_certificate.py','.local_agent/priced-completion-20261015/pv_old_test.py']:
 dest=out/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/relative,dest)
(out/'pytest.ini').write_text('[pytest]\n',encoding='utf-8')
zig=ROOT/'.venv/Lib/site-packages/ziglang/zig.exe';suffix=sysconfig.get_config_var('EXT_SUFFIX');rows=[];start=time.perf_counter()
for src,target in [('.local_agent/wide-interface-20261015/src','.local_agent/wide-interface-20261015/_native_core'),('.local_agent/backend-owner-20261015/src_scoped_v2','.local_agent/backend-owner-20261015/scoped_v2'),('.local_agent/backend-owner-20261015/src_main_v1','.local_agent/backend-owner-20261015/main_v1'),('generic_chess/_native','generic_chess/_native_core')]:
 source=out/src;cmd=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(source),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in sorted(source.glob('*.c'))],'-o',str(out/(target+suffix))];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=180);(b/('replay-build-'+str(len(rows))+'.log')).write_bytes(r.stdout+r.stderr);rows.append({'target':target,'exit':r.returncode,'seconds':time.perf_counter()-t});assert r.returncode==0,rows[-1];print('BUILT',target,flush=True)
commands=[('input-qualification',[sys.executable,'.local_agent/priced-completion-20261015/replay_qualify.py',str(ROOT/'.local_agent')]),('mate-verification',[sys.executable,'.local_agent/priced-completion-20261015/verify_certificate.py']),('shipped-pv',[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','-c','pytest.ini','tests/product/test_native_main_order_pv_witness.py','--basetemp','.local_agent/replay-pytest']),('old-pv',[sys.executable,'.local_agent/priced-completion-20261015/pv_old_test.py'])]
for name,cmd in commands:
 t=time.perf_counter();r=subprocess.run(cmd,cwd=out,capture_output=True,timeout=120);(b/('replay-'+name+'.log')).write_bytes(r.stdout+r.stderr);rows.append({'test':name,'exit':r.returncode,'seconds':time.perf_counter()-t});assert r.returncode==(1 if name=='old-pv' else 0),rows[-1];print('VERIFIED',name,r.returncode,flush=True)
for name in ['replay-qualification.json','mate-certificate-verification.json','pv-old-test.json']:
 shutil.copyfile(out/'.local_agent/priced-completion-20261015'/name,b/('isolated-'+name))
(b/'isolated-replay.json').write_text(json.dumps({'export_path':str(out),'rows':rows,'seconds':time.perf_counter()-start,'source_pin':'41e69e1dd8ab2c459239175d0c4091f90dffb389 plus newPVtest','no_old_private_inputs':True,'complete':True},indent=2),encoding='utf-8');print('ALL_REPLAY_PASS',time.perf_counter()-start)
