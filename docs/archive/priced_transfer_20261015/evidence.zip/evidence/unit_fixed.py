from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
source_b=b;b=ROOT/'.local_agent/priced-completion-20261015'
spec=importlib.util.spec_from_file_location('pricedscoped._native_core',next(source_b.glob('scoped_v2*.pyd')));candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
bridges={'baseline':V2Boundary(wide),'candidate':V2Boundary(candidate)}
compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
inputs=json.loads((b/'inputs.json').read_text(encoding='utf-8'));assert inputs['complete']
rows=[];roots=[];start=time.monotonic()
def save(complete=False,error=None):
 (b/'unit-fixed-results.json').write_text(json.dumps({'complete':complete,'rows':rows,'roots':roots,'seconds':time.monotonic()-start,'error':error,'default_unchanged':native._MODULE is installed}),encoding='utf-8')
try:
 for x in inputs['samples']:
  p.rr.stopped()
  if not x['included']:continue
  prep=time.perf_counter();c,s=case(x);profile=p.build_ruleset_profile(c,p.EvaluationConfig())
  v={tid:0 if mt.is_anchor else 100 for tid,mt in c.support.type_metadata.items()};h=dict(v)
  before=record_value(s.to_record());rules={name:compilers[name](c) for name in bridges};assert all(rules.values()),x['name']
  for name,nr in rules.items():
   pos=pack_semantic_search_position(c,nr,s);check(c,s,nr,pos)
   assert {pack_semantic_action(nr,s.state.position,a) for a in s.legal_actions()}==set(sem.transient_legal_actions(nr,pos))
  roots.append({'name':x['name'],'n':x['n'],'board_values':v,'hand_values':h,'preparation_seconds':time.perf_counter()-prep,'state_checked':True,'full_legal_count':x['legal_count']});save()
  for seconds in [8]:
   for order in [0,1]:
    for arm in (list(bridges) if order==0 else list(bridges)[::-1]):
     p.rr.stopped();assert native._MODULE is installed
     if time.monotonic()-start>900:raise TimeoutError('declared900s fixed-objective fuse')
     t=time.perf_counter();e=SemanticSearchEngine(c,rules[arm],board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False)
     r=e.search(s,SearchLimits(max_depth=2,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True)
     rows.append({'root':x['name'],'n':x['n'],'order':order,'seconds':seconds,'arm':arm,'caller_seconds':time.perf_counter()-t,'result':record_value(r)})
     assert r.action in s.legal_actions() and record_value(s.to_record())==before
     save()
  print(x['name'],len(rows),flush=True)
 save(True);print('COMPLETE',len(rows),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
