from pathlib import Path
import sys,subprocess,time,json
b=Path('.local_agent/priced-completion-20261015');plan=json.loads((b/'plan.json').read_text());rows=[];samples=[];start=time.perf_counter()
for x in plan['families']:
 t=time.perf_counter();seed=x['seed'];n=x['n']
 try:
  r=subprocess.run([sys.executable,str(b/'prepare_one.py'),str(seed),str(n)],capture_output=True,timeout=45)
  (b/f'prepare-{seed}.log').write_bytes(r.stdout+r.stderr)
  row={'seed':seed,'n':n,'exit':r.returncode,'status':'complete' if r.returncode==0 else 'failed','seconds':time.perf_counter()-t}
 except subprocess.TimeoutExpired as e:
  row={'seed':seed,'n':n,'status':'45s_censored','seconds':time.perf_counter()-t}
  (b/f'prepare-{seed}.log').write_bytes((e.stdout or b'')+(e.stderr or b''))
 p=b/f'input-{seed}.json'
 if p.exists():
  data=json.loads(p.read_text(encoding='utf-8'));samples+=data['samples'];row['saved_roots']=len(data['samples'])
 else:row['saved_roots']=0
 rows.append(row)
 (b/'inputs.json').write_text(json.dumps({'complete':False,'samples':samples,'preparation':rows,'seconds':time.perf_counter()-start}),encoding='utf-8')
 print(row,flush=True)
(b/'inputs.json').write_text(json.dumps({'complete':True,'samples':samples,'preparation':rows,'seconds':time.perf_counter()-start}),encoding='utf-8')
