from pathlib import Path
import sys,json,inspect,importlib.util,time
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
# Refuse hidden old private evidence from the producing checkout.
forbidden=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else None
def audit(event,args):
 if event!='open' or not args or not isinstance(args[0],(str,bytes,Path)):return
 p=Path(args[0]).resolve()
 if forbidden and p.is_relative_to(forbidden) and not p.is_relative_to(ROOT):raise RuntimeError('Forbidden old private read: '+str(p))
sys.addaudithook(audit)
exec(compile((ROOT/'.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
assert Path(nc.__file__).resolve().is_relative_to(ROOT)
old=b;b=ROOT/'.local_agent/priced-completion-20261015';spec=importlib.util.spec_from_file_location('replayscoped._native_core',next(old.glob('scoped_v2*.pyd')));candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
bridges={'baseline':V2Boundary(wide),'candidate':V2Boundary(candidate)};compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
data=json.loads((b/'inputs.json').read_text());prices={r['name']:r for r in json.loads((b/'resource-results.json').read_text())['roots']};rows=[];start=time.perf_counter()
for x in data['samples']:
 if not x['included']:continue
 c,s=case(x);before=record_value(s.to_record());pr=prices[x['name']]
 for name,compile_rules in compilers.items():
  nr=compile_rules(c);pos=pack_semantic_search_position(c,nr,s);check(c,s,nr,pos);codes=sem.transient_legal_actions(nr,pos);assert {sem.public_action(nr,z)for z in codes}==set(s.legal_actions())
  e=SemanticSearchEngine(c,nr,board_values=pr['board_values'],hand_values=pr['hand_values'],tt_megabytes=0,ordering_cache_enabled=False)
  r=e.search(s,SearchLimits(max_depth=1,max_nodes=128,max_time_seconds=1,quiescence_max_depth=0),root_window_pruning=True)
  assert r.action in s.legal_actions() and record_value(s.to_record())==before and native._MODULE is installed
  rows.append({'root':x['name'],'image':name,'legal_count':len(codes),'fullstate_history_checked':True,'result':record_value(r)})
(b/'replay-qualification.json').write_text(json.dumps({'rows':rows,'contexts':len(rows),'seconds':time.perf_counter()-start,'old_private_reads_rejected':True,'source_modules_under_export':True,'default_module_unchanged':True}),encoding='utf-8');print('REPLAY',len(rows),time.perf_counter()-start)
