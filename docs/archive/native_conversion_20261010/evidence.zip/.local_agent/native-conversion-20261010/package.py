"""Selected Agent evidence only, with exact-byte member verification."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[2]
work=ROOT/'.local_agent/native-conversion-20261010'
destination=ROOT/'docs/archive/native_conversion_20261010'
destination.mkdir(parents=True,exist_ok=True)
base='c62ffec7f89ed80dbd4950b4788372ba1cf4bbd0'
native_path='generic_chess/ai/alphabeta/native_legality.py'
old=subprocess.check_output(['git','show',base+':'+native_path],cwd=ROOT)
(work/'baseline-native.py').write_bytes(old)
(work/'product-native.py').write_bytes((ROOT/native_path).read_bytes())
failures={
 'sparse_assay':'First generated pilot stopped after16familiar calls: piece_types is a tuple, not mapping.values(). sparse-assay.json remains partial; generated-only follow-on separate. No old numerical rows overwritten.',
 'sparse_oracle':'Three initial prototype oracle failures exposed absent/null and resized-empty-cell handling on synthetic carriers; final presence-aware prototype passes512compound/12auxiliary cases. Not an observed legal production transition defect; production hashing unchanged.',
 'source_limit':'The sparse prototype changed during development without retaining every initial producer version. Final source is recoverable; exact initial sparse source is NOT asserted. Carrier/direct flags and reports distinguish the changed premises.',
 'full_pytest_receipt':'Initial full pytest output was printed without preserving the tool session identifier. Do not claim its unseen final status; a subsequent captured related test result supplies delivery validation.',
 'consult_cli':'First reconcile omitted required request-id and failed before import; corrected call verified complete root and one existing reply. Raw Slack stays ignored, excluded from this package.'}
failures['full_regression']='First captured full suite failed with inaccessible system temp directories and17obsolete Shogi fixtures. Native execution fixtures now explicitly retain legacy draw policy; frozen historical hashes remain draw, current rule fingerprints reflect corrected loss. Project-local temp path used for corrected suite; exact validation status recorded separately.'
failures['encoding']='Current mainline contained one invalid UTF-8 byte97 at offset2800. Replaced only that heading punctuation before documentation update.'
failures['eviction_test']='First constructed pawn-hand fixture has no pawn drop because all initial files already have a pawn; use Gold without changing product. Second fixture externally added2048keys atop existing71 and only hit old keys: that violates the controlled capacity premise. Clear first, then fill2048 and exercise actual miss/eviction. Final63related tests pass; no product repair follows from either invalid premise.'
(work/'failures.json').write_bytes((json.dumps(failures,indent=2)+'\n').encode())
sources=['native_conversion_diagnostic.py','sparse_hash_diagnostic.py','sparse_hash_assay.py','provider_stage_diagnostic.py','public_projection_assay.py','public_projection_product_check.py','public_projection_time_check.py','public_projection_transfer.py','public_projection_qtransfer.py']
paths=[ROOT/'scripts'/s for s in sources]
paths += [ROOT/'tests/development/test_sparse_hash_diagnostic.py',ROOT/'tests/product/test_native_public_projection.py']
paths += [work/name for name in ('decomposition.json','sparse-assay.json','sparse-generated.json','sparse-direct.json','provider-stages.json','public-projection.json','product-check.json','time-check.json','transfer.json','qtransfer.json','failures.json','baseline-native.py','product-native.py','package.py')]
paths += [ROOT/'.local_agent/generated6-20261008'/name for name in ('coverage.json','event-frontiers.json')]
paths += [ROOT/'.local_agent/search-attribution-20261010/utility.json']
paths += [work/'native_check_probe.py',work/'native-check.json']
paths += [work/'board_token_probe.py',work/'board-token.json',work/'recover.py',work/'recovery.json']
paths += [work/name for name in ('full_native_probe.py','full-native.json','terminal_discrepancy.py','terminal-discrepancy.json','kernel-contract.json')]
paths += [ROOT/name for name in ('generic_chess/native/compiler.py','generic_chess/native/semantic.py','generic_chess/native/semantic_engine.py','tests/product/test_native_terminal_policy_support.py')]
members={}
with zipfile.ZipFile(destination/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for path in paths:
  relative=path.relative_to(ROOT).as_posix();data=path.read_bytes()
  assert relative.startswith(('scripts/','tests/','generic_chess/native/','.local_agent/native-conversion-20261010/','.local_agent/generated6-20261008/','.local_agent/search-attribution-20261010/'))
  assert not any(x in relative.lower() for x in ('slack','account','credential','session.json','rollout'))
  z.writestr(relative,data);members[relative]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(destination/'evidence.zip') as z:
 for name,record in members.items():
  data=z.read(name);assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
q=json.loads((work/'qtransfer.json').read_bytes());transfer=json.loads((work/'transfer.json').read_bytes())
index={'schema':1,'base_commit':base,'scope':'Agent-only exposed search execution attribution; no user/private input, raw Slack/account or credentials. ui-test unchanged. Timing is local, not playing strength.',
 'archive':'docs/archive/native_conversion_20261010/evidence.zip','members':members,
 'counts':{'decomposition_calls':12,'sparse_partial_familiar_calls':16,'sparse_generated_calls':16,'sparse_direct_calls':32,'provider_stage_calls':16,'projection_prototype_calls':16,'actual_product_calls':16,'common_time_calls':192,'generated_q_calls':len(q['rows']),'public_children':sum(x['actions'] for x in transfer['rows']),'native_check_probe_calls':16,'related_tests':63,'board_token_calls':32,'full_native_pilot_calls':20},
 'source_boundaries':{'decomposition_sparse_stages':'Use baseline-native.py at base; final sparse source differs from initial pilot as disclosed in failures.json.',
 'projection_prototype':'Frozen original_source in public-projection.json is the actual pre-cache method. Do not rerun its adaptive inspect.getsource against the candidate and call that an old baseline.',
 'product_time_transfer':'Use product-native.py plus baseline_class restoring the original_source receipt; product-check.json pins full candidate hash. Supporting tracked sources use base checkout; no other backend change.',
 'full_native':'Pilot uses pre-guard base c62ffec7; archived compiler/semantic/semantic_engine snapshots are post-pilot explicit loss-policy rejection. No C repair/build claimed. terminal-discrepancy is an explicitly raw installed-kernel fault witness.',
 'inputs':'Exact generated rules/full routes/event roots and original finite-D4 teacher included. Already exposed; never restore holdout status.'},
 'decisions':{'full_native':'adopt explicit terminal/search rejection of unsupported loss; repair versioned kernel semantics before affected profiling','board_token':'defer mixed effects despite96-98percent hits','sparse_hash':'defer mixed effects; live hash unchanged','native_anchor_query':'defer all8paired wall regressions and changed callback granularity; Python authority retained','engine_cache':'defer construction onlyabout2percent of instrumented Native cost','public_projection':'adopt bounded immutable public syntax reuse; full position bindings still rebuilt','decision_utility':'192same-time choices unchanged; no finite-D4 improvement; q0/q2 generated decisions unchanged'},
 'archive_sha256':hashlib.sha256((destination/'evidence.zip').read_bytes()).hexdigest()}
(ROOT/'docs/research/data/native_conversion_20261010.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
print(json.dumps({'members':len(members),'bytes':(destination/'evidence.zip').stat().st_size,'verified':True,'counts':index['counts']}))
