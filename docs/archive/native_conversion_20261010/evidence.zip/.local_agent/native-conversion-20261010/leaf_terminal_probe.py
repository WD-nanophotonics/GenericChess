"""Post-publication bounded Native leaf-terminal cost diagnostic.
Three supported Chess roots;100 warmed calls per operation, two reversed passes.
Packing is outside timing. No move-loss policy, training, Native rebuild or
algorithm change. Costs are primitives, not additive causal search shares.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import terminal_status,guarded_actions,evaluate,snapshot
rows=[]
for case in [x for x in CASES if x['game']=='chess' and x['id']!='chess-mate'][:3]:
 compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));board=CoreBoard(case,compiled)
 session=GameSession(compiled);session._state=board.initial;session._search_history_witnesses=board.witnesses
 native=compile_native_semantic_rules(compiled);position=pack_semantic_search_position(compiled,native,session)
 before=snapshot(native,position);values=tuple(VALUES['chess'][t] for t in native.type_ids)
 ops={'terminal':lambda:terminal_status(native,position),'guarded':lambda:guarded_actions(native,position),'material':lambda:evaluate(native,position,board_values=values,hand_values=values,dynamic_values=(0,0,0))}
 outputs={k:fn() for k,fn in ops.items()};assert outputs['material']==board.evaluate();assert outputs['guarded']
 for order in (list(ops),list(reversed(ops))):
  for name in order:
   flags=[json.loads((ROOT/'.local_agent'/p).read_bytes()) for p in ('rollout.json','advisor.json','slack.json')];assert not any(v.get('stopped') or v.get('user_paused') for v in flags)
   t=perf_counter()
   for _ in range(100):assert ops[name]()==outputs[name]
   rows.append({'case':case['id'],'operation':name,'calls':100,'seconds':perf_counter()-t,'order':order})
 assert snapshot(native,position)==before
report={'schema':1,'scope':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'base_commit':'19ec7b9b28cbf1d56e3767815cd77e2248b82e16','rows':rows,'root_restoration':True,'decision':'Measure terminal/material ratio before reusing candidate buffers; semantic loss repair remains prior for affected rules.'}
Path(__file__).with_name('leaf-terminal.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for case in sorted({r['case'] for r in rows}):
 items=[r for r in rows if r['case']==case];print(case,{name:[round(r['seconds']*1e4,2) for r in items if r['operation']==name] for name in ops})
