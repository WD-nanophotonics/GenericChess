"""Isolated residual-check premise; no production change.

Existing installed Native in_check export replaces only runtime _gave_check.
Position, auxiliary state and ply are repacked every query; Core history/terminal
authority unchanged. Native query is indivisible: callbacks surround the call,
not every Python geometry step. This changed cancellation granularity alone
precludes adoption without a separately justified contract/latency review.
Four familiar/generated roots,4096entries,D8,30sec,2inverse pairs (16calls).
Different decision question from public syntax reuse; no old budget extension.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import json,hashlib
from contextlib import nullcontext
from time import perf_counter
from unittest.mock import patch
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.sparse_hash_assay import GeneratedBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native.semantic import pack_position,in_check

report={'schema':1,'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False}
factories=[]
for case in (CASES[0],CASES[7]):
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
 factories.append((case['id'],c,lambda p,case=case,c=c:CoreBoard(case,c,provider=p)))
coverage=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
for seed in (202610082000,202610082001):
 case=next(x for x in coverage['cases'] if x['seed']==seed)
 board=GeneratedBoard(case,3,provider=None)
 factories.append((f'generated-{seed}-ply3',board.compiled,lambda p,case=case:GeneratedBoard(case,3,provider=p)))
output=Path(__file__).with_name('native-check.json')
def save():output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
start=perf_counter()
try:
 for name,c,factory in factories:
  for repeat in (0,1):
   for changed in ((False,True) if repeat==0 else (True,False)):
    for flag in ('rollout.json','advisor.json','slack.json'):
     s=json.loads((ROOT/'.local_agent'/flag).read_bytes())
     if s.get('stopped') or s.get('user_paused'):raise RuntimeError('project stopped')
    provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
    if provider is None:raise RuntimeError('Native unavailable')
    calls=[0]
    def gave_check(runtime,position,checkpoint=None):
     if checkpoint:checkpoint()
     payload=provider._state_only_payload(position,runtime.ply_count+1)
     native_position=pack_position(provider.native_rules,payload)
     if checkpoint:checkpoint()
     value=in_check(provider.native_rules,native_position,position.side_to_move)
     if checkpoint:checkpoint()
     calls[0]+=1
     return value
    board=factory(provider);board.actions()
    with patch.object(SearchPathRuntime,'_gave_check',gave_check) if changed else nullcontext():
     row=minimal_ab(board,8,seconds=30,node_limit=4096,trace=True)
    row.update(case=name,repeat=repeat,native_check=changed,native_check_calls=calls[0])
    report['rows'].append(row);save()
    print(name,repeat,changed,round(row['wall_seconds'],3),flush=True)
  rows=[x for x in report['rows'] if x['case']==name]
  assert all(x['work']==rows[0]['work'] and x['trace_sha256']==rows[0]['trace_sha256'] for x in rows)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
