from pathlib import Path
import json,hashlib,zipfile,re
root=Path.cwd();work=root/'.local_agent/native-conversion-20261010'
r=json.loads((work/'zero-feature-control.json').read_bytes())
checks=[]
for case in sorted({x['case'] for x in r['search_rows']}):
 rows=[x for x in r['search_rows'] if x['case']==case]
 for a,b in (rows[:2],rows[2:]):
  keys=['score','action','decision_line','completed_depth','principal_variation','nodes','termination_reason']
  assert all(a['result'][k]==b['result'][k] for k in keys)
  checks.append({'case':case,'equal_keys':keys,'speed_ratio':max(a['seconds'],b['seconds'])/min(a['seconds'],b['seconds'])})
r['pair_verification']=checks;r['interpretation']='Explicit zero weights trigger unused dynamic features; absence disables them with identical material/decisions/work on these3supported Chess roots. Existing default is None. Old full-Native zero-profile pilot preserves wasted scheduling and loss-policy bug; do not rewrite it or extrapolate this ratio to every rule.'
(work/'zero-feature-control.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'docs/research/data/native_conversion_20261010.json';index=json.loads(p.read_bytes());archive=root/index['archive']
with zipfile.ZipFile(archive) as z:contents={n:z.read(n) for n in z.namelist()}
for name in ('leaf_terminal_probe.py','leaf-terminal.json','zero_feature_control.py','zero-feature-control.json','supplement_package.py'):
 path=work/name;contents[path.relative_to(root).as_posix()]=path.read_bytes()
for n,b in contents.items():
 assert not re.search(b'icy'+b'woods|gma'+rb'il\.com|xox[baprs]-|C0C6'+b'L21UU20|TYPE=DOT_'+b'REPLY',b)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for n,b in contents.items():z.writestr(n,b)
index['members']={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in contents.items()}
with zipfile.ZipFile(archive) as z:
 for n,v in index['members'].items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
index['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();index['counts'].update({'initial_leaf_primitive_calls':1800,'zero_control_primitive_calls':2400,'zero_control_search_calls':12})
index['decisions']['zero_dynamic']='Use absent unused features for material-only full-Native attribution; no product default change. Existing default already None.6paired512node Chess controls identical decisions/work, old zero-profile pilot unchanged.'
index['validation']['archive_exact_hashes']=len(contents)
index['delivery_failure']='First publish validation used a nonexistent provider test filename; stopped before push. Corrected verified target published105tests at19ec7b9. No hook bypass.'
index['supplement_failure']='Privacy scan matched its own denylist source literals; restored exact published archive, split literals and preflighted all bytes before rewrite. No partial archive published.'
p.write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
print({'members':len(contents),'six_pair_ratios':[round(x['speed_ratio'],2) for x in checks]})
