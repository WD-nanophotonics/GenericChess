"""Direct installed-kernel witness, not a supported public terminal route.

The guarded public API now rejects this unsupported policy. This diagnostic
calls the raw extension deliberately to document its pre-repair behavior.
No security control or machine policy is bypassed; no binary is rebuilt.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import json,hashlib
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native import _module
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.session.session import GameSession
from scripts.search_backend_comparison import CASES,CoreBoard
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));b=CoreBoard(CASES[5],c)
native=compile_native_semantic_rules(c);rows=[]
for label,action in b.actions():
 if label not in ('3c2c+','3c3b+'):continue
 child=apply_action(b.initial,action,c)
 session=GameSession(c);session._state=child;session._search_history_witnesses=b.witnesses+(child.position,)
 packed=pack_semantic_search_position(c,native,session)
 rows.append({'action':label,'Core_status':child.terminal_status.status.value,'Core_winner':child.terminal_status.winner,'Core_legal_count':len(session.legal_actions()),'checked':semantic_engine_for(c).in_check(child.position,child.position.side_to_move),'raw_Native':dict(_module().semantic_terminal(native.capsule,packed))})
assert len(rows)==2 and all(x['Core_winner']==0 and not x['checked'] and x['Core_legal_count']==0 and x['raw_Native']['winner'] is None for x in rows)
p=Path(__file__).with_name('terminal-discrepancy.json')
p.write_bytes((json.dumps({'schema':1,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(Path(_module().__file__).read_bytes()).hexdigest(),'declaration':__doc__,'rows':rows},indent=2)+'\n').encode())
print(json.dumps(rows))
