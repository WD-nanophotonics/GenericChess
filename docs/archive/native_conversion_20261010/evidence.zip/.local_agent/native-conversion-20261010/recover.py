"""Exact source/input recovery, not a rerun or renewed holdout."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[2]
work=ROOT/'.local_agent/native-conversion-20261010'
target=work/'recovery-1'
if target.exists():raise RuntimeError('fresh recovery target required')
target.mkdir()
base='c62ffec7f89ed80dbd4950b4788372ba1cf4bbd0'
archive=work/'recovery-base.zip'
subprocess.run(['git','archive','--format=zip','--output',str(archive),base],cwd=ROOT,check=True)
def extract(z,name):
 p=(target/name).resolve()
 if not p.is_relative_to(target.resolve()):raise ValueError('outside recovery target')
 if name.endswith('/'):p.mkdir(parents=True,exist_ok=True);return
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():extract(z,name)
index=json.loads((ROOT/'docs/research/data/native_conversion_20261010.json').read_bytes())
with zipfile.ZipFile(ROOT/index['archive']) as z:
 assert set(index['members'])==set(z.namelist())
 for name,record in index['members'].items():
  data=z.read(name)
  assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
  extract(z,name)
candidate=target/'.local_agent/native-conversion-20261010/product-native.py'
(target/'generic_chess/ai/alphabeta/native_legality.py').write_bytes(candidate.read_bytes())
assert hashlib.sha256(candidate.read_bytes()).hexdigest()==json.loads((target/'.local_agent/native-conversion-20261010/product-check.json').read_bytes())['product_sha256']
command=[str(ROOT/'.venv/Scripts/python.exe'),'-m','pytest','-q','-p','no:cacheprovider','tests/development/test_sparse_hash_diagnostic.py','tests/product/test_native_public_projection.py']
r=subprocess.run(command,cwd=target,capture_output=True,text=True)
(work/'recovered-tests.txt').write_bytes((r.stdout+r.stderr).encode())
if r.returncode:raise RuntimeError(r.stdout+r.stderr)
probe=target/'recovery_fronts.py'
probe.write_bytes(b'''import json
from pathlib import Path
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
p=Path('.local_agent/generated6-20261008')
c=json.loads((p/'coverage.json').read_bytes());events=json.loads((p/'event-frontiers.json').read_bytes())['cases']
total=0
for event in events:
 case=next(x for x in c['cases'] if x['seed']==event['seed'])
 s=GameSession(compile_ruleset_for_execution(ruleset_from_dict(case['rules'])))
 for step in case['route'][:event['ply']]:s.submit(action_from_dict(step['action']))
 total+=len(tuple(s.legal_actions()))
assert len(events)==22 and total==803
print('22complete recovered full-history roots;803public actions;Core only')
''')
r2=subprocess.run([str(ROOT/'.venv/Scripts/python.exe'),str(probe)],cwd=target,capture_output=True,text=True)
if r2.returncode:raise RuntimeError(r2.stdout+r2.stderr)
(work/'recovery.json').write_bytes((json.dumps({'archive_members_verified':len(index['members']),'candidate_hash_verified':True,'tests':r.stdout,'fronts':r2.stdout,'scope':'Separate base-export Python source plus exact archive; installed editable environment can supply the existing Native extension. Record actual module paths/hash separately; no rebuilt binary or clean-machine availability claim.'},indent=2)+'\n').encode())
print(r.stdout,r2.stdout)
