"""Existing full Native entry inventory, not a matched-algorithm speed claim.

Eight exposed familiar roots and two generated full-history roots, one D2 call
per backend,1sec/100000nodes. Native TT0/root-window-pruningFalse, explicit
material and zero dynamics, no learned ordering/qsearch. Native packed order
differs from lexical Core and Native iterates D1+D2: counts are not equivalent.
First verify native root material and public legality/PV/restoration. Compare
finiteD2 score only when both complete; preserve unsupported/capped/discrepant
rows. This is a new callable/support question, not extension of older cohorts.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import hashlib,json
from dataclasses import asdict
from time import perf_counter
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab,VALUES
from scripts.sparse_hash_assay import GeneratedBoard
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import evaluate
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
report={'schema':1,'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False}
boards=[]
for case in CASES:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
 b=CoreBoard(case,c);boards.append((case['id'],b,VALUES[case['game']]))
coverage=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
for seed in (202610082000,202610082001):
 case=next(x for x in coverage['cases'] if x['seed']==seed);b=GeneratedBoard(case,3)
 boards.append((f'generated-{seed}-ply3',b,b.values))
output=Path(__file__).with_name('full-native.json')
def save():output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
start=perf_counter()
try:
 for name,b,values in boards:
  for flag in ('rollout.json','advisor.json','slack.json'):
   flags=json.loads((ROOT/'.local_agent'/flag).read_bytes())
   if flags.get('stopped') or flags.get('user_paused'):raise RuntimeError('project stopped')
  row={'case':name};report['rows'].append(row);save()
  session=GameSession(b.compiled);session._state=b.initial;session._search_history_witnesses=b.witnesses
  before=(session.state,session.history,tuple(session._search_witnesses))
  t=perf_counter()
  try:
   native=compile_native_semantic_rules(b.compiled)
   engine=SemanticSearchEngine(b.compiled,native,board_values=values,hand_values=values,dynamic_values=(0,0,0),tt_megabytes=0)
   row['setup_seconds']=perf_counter()-t
   packed=pack_semantic_search_position(b.compiled,native,session)
   native_eval=evaluate(native,packed,board_values=tuple(values[t] for t in native.type_ids),hand_values=tuple(values[t] for t in native.type_ids),dynamic_values=(0,0,0))
   row['root_material']={'Core':b.evaluate(),'Native':native_eval};assert native_eval==b.evaluate()
   t=perf_counter();decision=engine.search(session,SearchLimits(max_depth=2,max_nodes=100000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=False)
   row['native_wall_seconds']=perf_counter()-t;row['native']=record_value(asdict(decision))
   validate_pv(session,decision);assert before==(session.state,session.history,tuple(session._search_witnesses))
  except Exception as e:
   row['unsupported_or_failure']={'type':type(e).__name__,'message':str(e)}
  row['core']=minimal_ab(b,2,seconds=1,node_limit=100000,trace=False)
  if 'native' in row and row['native']['completed_depth']==2 and row['core']['reason']=='completed_depth':
   row['joint_complete_score_equal']=row['native']['score']==row['core']['score']
  save();print(name,row.get('unsupported_or_failure'),row.get('joint_complete_score_equal'),row.get('native',{}).get('completed_depth'),row['core']['reason'],flush=True)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
