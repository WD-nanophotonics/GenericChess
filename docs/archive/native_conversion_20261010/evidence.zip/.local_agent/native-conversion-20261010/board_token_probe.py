"""New premise: memoize exact board tokens, keep full component maps.

The failed sparse-map candidates changed scanning/allocation. This candidate
keeps those maps and memoizes only already defined board-cell tokens. Exact
field types stay in keys (bool is not int for JSON hashing). All nonboard and
unsupported components go through the unchanged oracle. Local2048entry cache
per call, no shared/global product cache. Four roots/Core and Native/4096entries/
D8/15sec/2inverse pairs:32calls maximum8minutes, expectedunder1minute.
Decision: only if a consistent reduction survives identical full-state traces
is a later common-time/cancellation assay worthwhile. No product adoption now.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import hashlib,json
from contextlib import nullcontext
from time import perf_counter
from unittest.mock import patch
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.sparse_hash_assay import GeneratedBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import search_runtime as runtime
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
old=runtime._component_token
report={'schema':1,'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False}
factories=[]
for case in (CASES[0],CASES[7]):
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
 factories.append((case['id'],c,lambda p,case=case,c=c:CoreBoard(case,c,provider=p)))
coverage=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
for seed in (202610082000,202610082001):
 case=next(x for x in coverage['cases'] if x['seed']==seed)
 factories.append((f'generated-{seed}-ply3',GeneratedBoard(case,3).compiled,lambda p,case=case:GeneratedBoard(case,3,provider=p)))
output=Path(__file__).with_name('board-token.json')
def save():output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
start=perf_counter()
try:
 for name,c,factory in factories:
  for native in (False,True):
   for repeat in (0,1):
    for changed in ((False,True) if repeat==0 else (True,False)):
     for flag in ('rollout.json','advisor.json','slack.json'):
      flags=json.loads((ROOT/'.local_agent'/flag).read_bytes())
      if flags.get('stopped') or flags.get('user_paused'):raise RuntimeError('project stopped')
     provider=NativeSemanticLegalityProvider.try_create(c,strict=True) if native else None
     if native and provider is None:raise RuntimeError('Native unavailable')
     board=factory(provider);board.actions();cache={};hits=[0];misses=[0];bypasses=[0];clears=[0]
     def token(address,value):
      if address[0]!='board' or not (value is None or isinstance(value,tuple) and len(value)==4 and all(type(x) in (int,str,bool) for x in value)):
       bypasses[0]+=1;return old(address,value)
      key=(address,None if value is None else tuple((type(x),x) for x in value))
      if key in cache:hits[0]+=1;return cache[key]
      misses[0]+=1;result=old(address,value)
      if len(cache)>=2048:cache.clear();clears[0]+=1
      cache[key]=result;return result
     with patch.object(runtime,'_component_token',token) if changed else nullcontext():
      row=minimal_ab(board,8,seconds=15,node_limit=4096,trace=True)
     row.update(case=name,native=native,repeat=repeat,prototype=changed,token_hits=hits[0],token_misses=misses[0],token_bypasses=bypasses[0],cache_entries=len(cache),cache_clears=clears[0])
     report['rows'].append(row);save();print(name,native,repeat,changed,round(row['wall_seconds'],3),flush=True)
   rows=[x for x in report['rows'] if x['case']==name and x['native']==native]
   assert all(x['work']==rows[0]['work'] and x['trace_sha256']==rows[0]['trace_sha256'] for x in rows)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
