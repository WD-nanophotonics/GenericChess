"""Independent full-hash oracle for full-state diff candidates."""
from dataclasses import replace
import random
import pytest
from generic_chess import build_builtin_ruleset, compile_ruleset_for_execution
from generic_chess.core.position import Position, Hands
from generic_chess.core.pieces import Piece
from generic_chess.core import search_runtime as rt
from scripts.sparse_hash_diagnostic import sparse_diff, direct_sparse_diff, ancillary_components


@pytest.mark.parametrize('game', ['western_chess','standard_shogi'])
def test_sparse_hash_compound_identity_changes_match_full_oracle(game):
    compiled=compile_ruleset_for_execution(build_builtin_ruleset(game))
    rng=random.Random(202610100401)
    types=[p.type_id for p in compiled.piece_types]
    # Synthetic identity carriers deliberately vary every piece field, cells,
    # hands, side and auxiliary addresses. They are not claimed legal positions.
    parent=Position((None,)*25,ruleset_fingerprint=compiled.ruleset_fingerprint)
    for _ in range(256):
        board=list(parent.board)
        for index in rng.sample(range(len(board)),rng.randint(1,7)):
            board[index]=None if rng.randrange(3)==0 else Piece(rng.randrange(2),rng.choice(types),rng.choice(types),bool(rng.randrange(2)))
        aux=tuple(sorted((( (i,owner),rng.choice((None,0,1,(2,3)))) for i,owner in ((0,-1),(0,0),(0,1),(99,-1)))))
        child=replace(parent,board=tuple(board),side_to_move=rng.randrange(2),aux_state=aux,
                      hands=tuple(Hands(tuple((t,rng.randrange(1,4)) for t in sorted(rng.sample(types,2)))) for _ in range(2)))
        current=rt._full_runtime_hash(parent,compiled)
        wanted=rt._full_runtime_hash(child,compiled)
        assert sparse_diff(parent,child,compiled,current)==wanted
        assert direct_sparse_diff(parent,child,compiled,current)==wanted
        assert ancillary_components(child,compiled)=={k:v for k,v in rt._component_map(child,compiled).items() if k[0]!='board'}
        parent=child


def test_sparse_hash_aux_default_unknown_and_board_resize():
    compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
    engine=rt.semantic_engine_for(compiled)
    slots=engine.ir.aux_slots
    explicit=tuple(sorted(((slot.slot_id,owner),slot.initial) for slot in slots
                         for owner in ((-1,) if slot.scope=='global' else (0,1))))
    parent=Position((None,)*16,ruleset_fingerprint=compiled.ruleset_fingerprint)
    for n in (16,25,9):
        for aux in ((),explicit,explicit+(((999,-1),None),),explicit+(((999,-1),1),)):
            child=replace(parent,board=(None,)*n,aux_state=aux)
            current=rt._full_runtime_hash(parent,compiled)
            wanted=rt._full_runtime_hash(child,compiled)
            assert direct_sparse_diff(parent,child,compiled,current)==wanted
            assert sparse_diff(parent,child,compiled,current)==wanted
            parent=child
