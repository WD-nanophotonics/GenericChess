"""Complete old/product/public-Core child audit on frozen generated events.

All22already-published6x6 promotion/drop/temporary-right event roots, every
legal action; preserve immutable child positions, terminal/history state and
exact runtime hash oracle. One provider per rule persists across roots to test
warm public reuse. No data-dependent sampling or added holdout status.60second
fuse per root,660seconds total; an incomplete audit fails, never drops its row.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import argparse
import hashlib
import json
from time import perf_counter
from scripts.public_projection_product_check import baseline_class
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.search_runtime import SearchPathRuntime,_full_runtime_hash
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    coverage_path=ROOT/'.local_agent/generated6-20261008/coverage.json'
    events_path=ROOT/'.local_agent/generated6-20261008/event-frontiers.json'
    coverage=json.loads(coverage_path.read_bytes())
    events=sorted(json.loads(events_path.read_bytes())['cases'],key=lambda x:(x['seed'],x['ply']))
    assert len(events)==22
    baseline=baseline_class(json.loads((ROOT/'.local_agent/native-conversion-20261010/public-projection.json').read_bytes()))
    report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                inputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (coverage_path,events_path)},
                complete=False,rows=[])
    a.output.parent.mkdir(parents=True,exist_ok=True)
    start=perf_counter();providers={}
    def save():a.output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
    try:
        for event in events:
            seed=event['seed'];case=next(x for x in coverage['cases'] if x['seed']==seed)
            if seed not in providers:
                c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']))
                old=baseline.try_create(c,strict=True);new=NativeSemanticLegalityProvider.try_create(c,strict=True)
                if old is None or new is None:raise RuntimeError('requested Native unavailable')
                providers[seed]=(c,old,new)
            c,old,new=providers[seed];session=GameSession(c)
            for step in case['route'][:event['ply']]:session.submit(action_from_dict(step['action']))
            row=dict(seed=seed,ply=event['ply'],event=event['event'],actions=0,complete=False)
            report['rows'].append(row);save();root_start=perf_counter()
            def check():
                if perf_counter()-root_start>60 or perf_counter()-start>660:
                    raise RuntimeError('audit fuse exceeded; keep incomplete evidence')
            left=SearchPathRuntime.from_state(session.state,c,history_witnesses=tuple(session._search_witnesses),legal_binding_provider=old)
            right=SearchPathRuntime.from_state(session.state,c,history_witnesses=tuple(session._search_witnesses),legal_binding_provider=new)
            actions=tuple(session.legal_actions())
            assert set(left.legal_actions(check))==set(right.legal_actions(check))==set(actions)
            for action in actions:
                check();expected=apply_action(session.state,action,c)
                left.push(action,check);right.push(action,check)
                try:
                    assert left.position==right.position==expected.position
                    assert left.terminal_status==right.terminal_status==expected.terminal_status
                    assert left.runtime_hash==right.runtime_hash==_full_runtime_hash(expected.position,c)
                    assert left.search_key()==right.search_key()
                    assert left.history==right.history
                    row['actions']+=1
                finally:right.pop();left.pop()
            left.assert_balanced();right.assert_balanced()
            assert left.position==right.position==session.state.position
            row.update(complete=True,seconds=perf_counter()-root_start,cache_entries=len(new._metrics_local.public_cache));save()
            print(seed,event['ply'],row['actions'],round(row['seconds'],3),flush=True)
        report['complete']=True
    finally:
        report['seconds']=perf_counter()-start;save()
    return 0


if __name__=='__main__':raise SystemExit(main())
