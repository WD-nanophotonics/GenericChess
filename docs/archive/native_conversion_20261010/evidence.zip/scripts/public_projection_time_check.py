"""Frozen old-provider/current-product same-time development ablation.

Eight already-exposed roots,0.25/1/4seconds, two reversed pairs and two algorithms
(bare iterative AB, supported cold TT/ordering with q/root-tactical off).
Algorithms are reported separately; work/node counts not equated across them.
Reuse prior complete D4 root/selected-child evidence only at identical rules and
material; newly chosen moves get one5sec/500000entry D3 check, caps stay UNKNOWN.
192calls, at most336search seconds plus bounded child checks, no budget retuning.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import argparse
import hashlib
import json
from scripts.public_projection_product_check import baseline_class
from scripts.search_backend_comparison import (CASES,CoreBoard,ChessBoard,ShogiBoard,
    iterative_minimal,supported_search,minimal_ab,build_builtin_ruleset,compile_ruleset_for_execution)
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.evaluation.config import MATE_THRESHOLD


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    basepath=ROOT/'.local_agent/native-conversion-20261010/public-projection.json'
    Baseline=baseline_class(json.loads(basepath.read_bytes()))
    oldpath=ROOT/'.local_agent/search-attribution-20261010/utility.json'
    previous=json.loads(oldpath.read_bytes())
    references={r['case']:r for r in previous['references']}
    children={(r['case'],r['move']):r['selected_child_D3'] for r in previous['rows'] if r.get('selected_child_D3')}
    report=dict(schema=1,declaration=__doc__,prior_reference_sha256=hashlib.sha256(oldpath.read_bytes()).hexdigest(),
                rows=[],new_child_references=[])
    a.output.parent.mkdir(parents=True,exist_ok=True)
    def save():a.output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
    for case in CASES:
        c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        special=(ChessBoard if case['game']=='chess' else ShogiBoard)(case)
        legal=dict(special.actions())
        for algorithm in ('minimal','supported'):
            for seconds in (.25,1.,4.):
                for repeat in (0,1):
                    for changed in ((False,True) if repeat==0 else (True,False)):
                        provider=(NativeSemanticLegalityProvider if changed else Baseline).try_create(c,strict=True)
                        if provider is None:raise RuntimeError('requested Native unavailable')
                        board=CoreBoard(case,c,provider=provider)
                        row=(iterative_minimal(board,seconds=seconds,max_depth=12) if algorithm=='minimal' else
                             supported_search(board,12,seconds,1000000,provider))
                        row.update(case=case['id'],algorithm=algorithm,seconds=seconds,repeat=repeat,product=changed,
                                   legal=row['move'] in legal,finite_D4_regret=None)
                        assert row['legal']
                        report['rows'].append(row);save()
                        print(case['id'],algorithm,seconds,repeat,changed,row.get('completed_depth',row.get('statistics',{}).get('completed_depth')),flush=True)
        # No instrumentation/reference computation competes with the timed calls.
        for row in [r for r in report['rows'] if r['case']==case['id']]:
            key=(case['id'],row['move'])
            if key not in children:
                child_case=dict(case,moves=(case['moves']+' '+row['move']).strip())
                child=(ChessBoard if case['game']=='chess' else ShogiBoard)(child_case)
                children[key]=minimal_ab(child,3,seconds=5,node_limit=500000)
                report['new_child_references'].append(dict(case=key[0],move=key[1],**children[key]))
            child=children[key];reference=references[case['id']]
            if child['reason']==reference['reason']=='completed_depth':
                value=-child['score']
                if abs(value)>=MATE_THRESHOLD:value+=-1 if value>0 else 1
                row['finite_D4_regret']=reference['score']-value
                assert row['finite_D4_regret']>=0
        save()
    return 0


if __name__=='__main__':raise SystemExit(main())
