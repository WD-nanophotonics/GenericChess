"""Nonoverlapping Native provider stages; instrumentation costs kept separate.

Frozen depth8/25000entry/120second search fuses on middle/drop roots, clean
then timed-provider and reversed pair. Predeclared sampling at4096 and25000
entries tests whether shallow prefix hides high branching conversion costs.
No lazy validation, Native or cancellation contract change.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import argparse
import hashlib
import json
from collections import defaultdict
from time import perf_counter
from scripts.search_backend_comparison import CASES, CoreBoard, minimal_ab
from generic_chess import build_builtin_ruleset, compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.core.semantic_executor import _semantic_public_action


class StageProvider(NativeSemanticLegalityProvider):
    def __init__(self, original):
        super().__init__(original.compiled,original.engine,original.native_rules,strict=True)
        self.stages=defaultdict(float)
        self.calls,self.actions=0,0

    def __call__(self,position,ply_count,checkpoint=None):
        from generic_chess.native.semantic import pack_position,transient_legal_actions
        started=perf_counter()
        if checkpoint is not None: checkpoint()
        t=perf_counter();payload=self._state_only_payload(position,ply_count)
        packed=pack_position(self.native_rules,payload)
        payload_time=perf_counter()-t;self.stages['payload_pack']+=payload_time
        if checkpoint is not None: checkpoint()
        t=perf_counter();raw=transient_legal_actions(self.native_rules,packed)
        self.stages['native_legality_and_return']+=perf_counter()-t
        if checkpoint is not None: checkpoint()
        decoded_start=perf_counter();pairs=[]
        for index,action in enumerate(raw):
            if index and index%64==0 and checkpoint is not None:checkpoint()
            t=perf_counter();semantic=self._decode_action(int(action),position)
            pattern=self.pattern_by_id.get(semantic.pattern_id)
            if pattern is None:raise ValueError('unknown pattern')
            self.stages['decode_pattern']+=perf_counter()-t
            t=perf_counter();binding=self.engine._make_binding_from_action(position,semantic,pattern)
            self.stages['binding']+=perf_counter()-t
            t=perf_counter();public=_semantic_public_action(self.engine,semantic)
            pairs.append((public,(semantic,binding)))
            self.stages['public_pair']+=perf_counter()-t
        if checkpoint is not None:checkpoint()
        total=perf_counter()-started
        self.calls+=1;self.actions+=len(pairs);self.stages['provider_total']+=total
        self._metrics_local.last=dict(payload_seconds=payload_time,
            decode_binding_seconds=perf_counter()-decoded_start,total_seconds=total,actions=len(pairs))
        return tuple(pairs)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    report=dict(schema=1,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
    args.output.parent.mkdir(parents=True,exist_ok=True)
    for case in (CASES[0],CASES[7]):
        c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        for nodes in (4096,25000):
            for repeat in (0,1):
                for timed in ((False,True) if repeat==0 else (True,False)):
                    provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
                    if provider is None:raise RuntimeError('requested Native unavailable')
                    if timed:provider=StageProvider(provider)
                    board=CoreBoard(case,c,provider=provider);board.actions()
                    if timed:
                        provider.stages.clear();provider.calls=provider.actions=0
                    row=minimal_ab(board,8,seconds=120,node_limit=nodes,trace=True)
                    row.update(case=case['id'],nodes_budget=nodes,repeat=repeat,timed=timed)
                    if timed:
                        row.update(stages=dict(provider.stages),provider_calls=provider.calls,provider_actions=provider.actions)
                    report['rows'].append(row)
                    args.output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
                    print(case['id'],nodes,repeat,timed,row['work']['nodes'],round(row['wall_seconds'],3),flush=True)
            rows=[r for r in report['rows'] if r['case']==case['id'] and r['nodes_budget']==nodes]
            assert all(r['work']==rows[0]['work'] and r['trace_sha256']==rows[0]['trace_sha256'] for r in rows)
    return 0


if __name__=='__main__':raise SystemExit(main())
