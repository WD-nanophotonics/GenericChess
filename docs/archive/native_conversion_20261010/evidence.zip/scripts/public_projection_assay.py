"""Bounded public-action reuse, with all Native validation/bindings preserved.

Cached data is immutable public syntax only, owned by one compiled provider;
state-dependent decode checks and bindings always execute. Full cache clears at
2048entries; no persistent disk/global cache. Two fixed25000entry roots and
two generated4096entry roots, two reversed pairs,120sec/call fuse. Conditional
development timings, not universal speed/strength. No product default change.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import argparse
import hashlib
import inspect
import json
import textwrap
from scripts.sparse_hash_assay import GeneratedBoard
from scripts.search_backend_comparison import CASES, CoreBoard, minimal_ab
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta import native_legality as native


class ProjectionProvider(native.NativeSemanticLegalityProvider):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.public_cache={}
        self.public_hits=self.public_misses=self.public_clears=0

    def _project_public(self, packed, semantic):
        key=int(packed)
        public=self.public_cache.get(key)
        if public is not None:
            self.public_hits+=1
            return public
        self.public_misses+=1
        public=native._semantic_public_action(self.engine,semantic)
        if len(self.public_cache)>=2048:
            self.public_cache.clear()
            self.public_clears+=1
        self.public_cache[key]=public
        return public


original_source=inspect.getsource(native.NativeSemanticLegalityProvider.__call__)
needle='public = _semantic_public_action(self.engine, semantic_action)'
assert original_source.count(needle)==1
prototype_source=textwrap.dedent(original_source).replace(needle,'public = self._project_public(packed, semantic_action)')
namespace=dict(native.__dict__)
exec(prototype_source,namespace)
ProjectionProvider.__call__=namespace['__call__']


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                original_source=original_source,prototype_source=prototype_source,rows=[])
    factories=[]
    for case in (CASES[0],CASES[7]):
        c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        factories.append((case['id'],25000,lambda provider,case=case,c=c:CoreBoard(case,c,provider=provider)))
    data=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
    for seed in (202610082000,202610082001):
        case=next(c for c in data['cases'] if c['seed']==seed)
        factories.append((f'generated-{seed}-ply3',4096,lambda provider,case=case:GeneratedBoard(case,3,provider=provider)))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    for name,nodes,factory in factories:
        c=factory(None).compiled
        for repeat in (0,1):
            for proto in ((False,True) if repeat==0 else (True,False)):
                provider=(ProjectionProvider if proto else native.NativeSemanticLegalityProvider).try_create(c,strict=True)
                if provider is None:raise RuntimeError('requested Native unavailable')
                board=factory(provider);board.actions()
                row=minimal_ab(board,8,seconds=120,node_limit=nodes,trace=True)
                row.update(case=name,nodes_budget=nodes,repeat=repeat,prototype=proto)
                if proto:
                    row.update(hits=provider.public_hits,misses=provider.public_misses,
                               clears=provider.public_clears,cache_entries=len(provider.public_cache))
                report['rows'].append(row)
                args.output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
                print(name,repeat,proto,row['work']['nodes'],round(row['wall_seconds'],3),flush=True)
        rows=[r for r in report['rows'] if r['case']==name]
        assert all(r['work']==rows[0]['work'] and r['trace_sha256']==rows[0]['trace_sha256'] for r in rows)
    return 0


if __name__=='__main__':raise SystemExit(main())
