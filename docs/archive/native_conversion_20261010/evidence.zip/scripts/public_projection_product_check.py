"""Compare frozen pre-cache provider against current product on defined work.

Four exposed roots/two reverse pairs. Baseline source comes from the previously
published attribution receipt, not the changing working module. The production
candidate owns a thread-local cache; no counter-heavy prototype timings claimed
as deployment. Each caller retains depth8/node cap/120sec fuse.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import argparse
import hashlib
import inspect
import json
import textwrap
from scripts.sparse_hash_assay import GeneratedBoard
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta import native_legality as native


def baseline_class(receipt):
    class Baseline(native.NativeSemanticLegalityProvider):pass
    ns=dict(native.__dict__)
    exec(textwrap.dedent(receipt['original_source']),ns)
    Baseline.__call__=ns['__call__']
    return Baseline


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    receipt=json.loads((ROOT/'.local_agent/native-conversion-20261010/public-projection.json').read_bytes())
    Baseline=baseline_class(receipt)
    report=dict(schema=1,declaration=__doc__,baseline_source=receipt['original_source'],
                product_source=inspect.getsource(native.NativeSemanticLegalityProvider.__call__),
                product_sha256=hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(),rows=[])
    factories=[]
    for case in (CASES[0],CASES[7]):
        c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        factories.append((case['id'],25000,lambda provider,case=case,c=c:CoreBoard(case,c,provider=provider)))
    data=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
    for seed in (202610082000,202610082001):
        case=next(c for c in data['cases'] if c['seed']==seed)
        factories.append((f'generated-{seed}-ply3',4096,lambda provider,case=case:GeneratedBoard(case,3,provider=provider)))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    for name,nodes,factory in factories:
        c=factory(None).compiled
        for repeat in (0,1):
            for changed in ((False,True) if repeat==0 else (True,False)):
                provider=(native.NativeSemanticLegalityProvider if changed else Baseline).try_create(c,strict=True)
                if provider is None:raise RuntimeError('requested Native unavailable')
                board=factory(provider);board.actions()
                row=minimal_ab(board,8,seconds=120,node_limit=nodes,trace=True)
                row.update(case=name,repeat=repeat,product=changed)
                if changed:
                    cache=provider._metrics_local.public_cache
                    row.update(cache_entries=len(cache),cache_direct_bytes=sys.getsizeof(cache)+sum(
                        sys.getsizeof(k)+sys.getsizeof(v)+sum(sys.getsizeof(getattr(v,field))
                        for field in ('from_square','to_square') if hasattr(v,field)) for k,v in cache.items()),
                        memory_scope='dict/int/public/Squares shallow retained objects; strings shared compiled, allocator/transients not counted')
                report['rows'].append(row)
                a.output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
                print(name,repeat,changed,row['work']['nodes'],round(row['wall_seconds'],3),flush=True)
        rows=[r for r in report['rows'] if r['case']==name]
        assert all(r['work']==rows[0]['work'] and r['trace_sha256']==rows[0]['trace_sha256'] for r in rows)
    return 0


if __name__=='__main__':raise SystemExit(main())
