"""Scoped alternative component diff, preserving complete identity semantics.

Prototype only: scans all cells for changes rather than inferring touched squares
from move coordinates. Compound effects, promotions and arbitrary removals remain
visible. Aux defaults/unknowns use the existing oracle map. No history omission.
"""
from dataclasses import replace
from itertools import zip_longest
from generic_chess.core import search_runtime as runtime


def ancillary_components(position, compiled):
    """Exact existing non-board map without allocating a Position carrier."""
    values = {('ruleset',): compiled.ruleset_fingerprint, ('side',): position.side_to_move}
    for owner, hand in enumerate(position.hands):
        values[('hand', owner)] = tuple(hand.counts)
    engine = runtime.semantic_engine_for(compiled)
    if engine is not None:
        physical, covered = dict(position.aux_state), set()
        for slot in engine.ir.aux_slots:
            for owner in ((-1,) if slot.scope == 'global' else (0, 1)):
                address = (slot.slot_id, owner)
                covered.add(address)
                values[('aux', address)] = physical.get(address, slot.initial)
        for address, value in position.aux_state:
            if address not in covered:
                values[('aux_unknown', address)] = value
    return values


def sparse_diff(parent, child, compiled, current):
    return _diff(parent, child, compiled, current, carrier_components)


def carrier_components(position, compiled):
    return runtime._component_map(replace(position, board=(), board_width=None, board_height=None), compiled)


def direct_sparse_diff(parent, child, compiled, current):
    return _diff(parent, child, compiled, current, ancillary_components)


def _diff(parent, child, compiled, current, components):
    value = current
    missing = object()
    for index, (old_piece, new_piece) in enumerate(zip_longest(parent.board, child.board, fillvalue=missing)):
        if old_piece is new_piece or old_piece == new_piece:
            continue
        address = ('board', index)
        if old_piece is not missing:
            value = runtime._xor(value, runtime._component_token(address, runtime._component_map_cell(parent, index)))
        if new_piece is not missing:
            value = runtime._xor(value, runtime._component_token(address, runtime._component_map_cell(child, index)))
    # This prototype deliberately retains the same full ancillary-state oracle.
    # Temporary metadata carriers have no shape or cells; never used as states
    # for legality, transitions or search. Product would use a shared helper.
    before = components(parent, compiled)
    after = components(child, compiled)
    for address in before.keys() | after.keys():
        old, new = before.get(address), after.get(address)
        if old != new or (address in before) != (address in after):
            if address in before:
                value = runtime._xor(value, runtime._component_token(address, old))
            if address in after:
                value = runtime._xor(value, runtime._component_token(address, new))
    return value
