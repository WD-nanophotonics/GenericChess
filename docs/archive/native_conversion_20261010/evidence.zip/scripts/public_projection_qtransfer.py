"""Existing22event roots, q0/q2 public caller ablation of projection reuse.

Two reversed old/product pairs per q setting; D2/8192nodes/4sec, qhard8 for q2.
176calls (maximum704search seconds plus setup/audit), one serial writer. Unit
material100/non-anchor, hand100, anchor0; fixed leaf/order control, no fit/Elo.
All caps and incomplete depths retained. Validate PV/root restoration and compare
jointly complete deterministic q0/q2 pairs; timed partial choices are not proof.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from dataclasses import asdict
import argparse
import hashlib
import json
from time import perf_counter
from unittest.mock import patch
from scripts.public_projection_product_check import baseline_class
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits


class UnitMaterial:
    def __init__(self,compiled):self.values={p.type_id:0 if p.is_anchor else 100 for p in compiled.piece_types}
    def evaluate(self,state):
        p=state.position
        return sum((1 if x.owner==p.side_to_move else -1)*self.values[x.current_type_id] for x in p.board if x)+sum(
            (1 if o==p.side_to_move else -1)*self.values[t]*n for o,h in enumerate(p.hands) for t,n in h.items())
    def capture_order_value(self,moving,captured):return 10*self.values[captured.current_type_id]-self.values[moving.current_type_id]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    covpath=ROOT/'.local_agent/generated6-20261008/coverage.json';eventpath=ROOT/'.local_agent/generated6-20261008/event-frontiers.json'
    coverage=json.loads(covpath.read_bytes());events=sorted(json.loads(eventpath.read_bytes())['cases'],key=lambda x:(x['seed'],x['ply']))
    assert len(events)==22
    baseline=baseline_class(json.loads((ROOT/'.local_agent/native-conversion-20261010/public-projection.json').read_bytes()))
    report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    def save():a.output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
    start=perf_counter()
    try:
        for event in events:
            case=next(x for x in coverage['cases'] if x['seed']==event['seed'])
            c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));session=GameSession(c)
            for step in case['route'][:event['ply']]:session.submit(action_from_dict(step['action']))
            before=(session.state,session.history,tuple(session._search_witnesses))
            evaluator=UnitMaterial(c)
            for q in (0,2):
                for repeat in (0,1):
                    for changed in ((False,True) if repeat==0 else (True,False)):
                        for flag in ('rollout.json','advisor.json','slack.json'):
                            state=json.loads((ROOT/'.local_agent'/flag).read_bytes())
                            if state.get('stopped') or state.get('user_paused'):raise RuntimeError('project stopped')
                        player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=evaluator,
                            use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False))
                        if not changed:player._native_legality_provider=baseline.try_create(c,strict=True)
                        else:player._native_legality_provider.strict=True
                        stats=[]
                        def make_stats():
                            value=SearchStatistics();stats.append(value);return value
                        t=perf_counter()
                        with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats):
                            decision=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=8192,
                                max_time_seconds=4,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
                        wall=perf_counter()-t;validate_pv(session,decision)
                        assert before==(session.state,session.history,tuple(session._search_witnesses))
                        assert stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops
                        assert stats[0].native_legality_fallbacks==0
                        report['rows'].append(dict(seed=event['seed'],ply=event['ply'],q=q,repeat=repeat,
                            product=changed,wall_seconds=wall,decision=record_value(decision),stats=asdict(stats[0])))
                        save();print(event['seed'],event['ply'],q,repeat,changed,decision.completed_depth,decision.termination_reason,round(wall,3),flush=True)
                    pair=report['rows'][-2:]
                    if all(x['decision']['completed_depth']==2 for x in pair):
                        assert all(pair[0]['decision'][key]==pair[1]['decision'][key] for key in ('action','score','principal_variation'))
        report['complete']=True
    finally:report['seconds']=perf_counter()-start;save()
    return 0


if __name__=='__main__':raise SystemExit(main())
