"""Bounded development cost attribution; no alternative production contract.

Separate clean work from cProfile instrumentation. Exclusive function times
partition instrumented cost; cumulative rows overlap and must not be summed.
"""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import argparse
import cProfile
import hashlib
import json
import pstats
from time import perf_counter
from scripts.search_backend_comparison import CASES, CoreBoard, minimal_ab
from generic_chess import build_builtin_ruleset, compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider


def category(file, name):
    if 'native_legality.py' in file:
        return 'provider_python_conversion'
    if 'native' in file:
        return 'native_wrapper_and_ffi'
    if name in ('_make_binding', '_make_binding_from_action', '_path_for_geometry',
                '_semantic_public_action', 'geometry_candidates', 'index_to_square'):
        return 'binding_public_geometry'
    if any(s in name for s in ('check', 'attacked', 'anchor')):
        return 'check_attack'
    if any(s in name for s in ('hash', 'identity', 'occurrence', 'history', 'snapshot')):
        return 'identity_history'
    if 'semantic_executor.py' in file:
        return 'remaining_semantic_executor'
    if 'search_runtime.py' in file:
        return 'remaining_search_runtime'
    return 'other'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    report = dict(schema=1, nodes=4096, depth=8, fuse_seconds=60,
                  scope='Exposed middle/drop controls; clean reversed pairs and separate cProfile. No strength claim.',
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), rows=[])
    for case in (CASES[0], CASES[7]):
        compiled = compile_ruleset_for_execution(build_builtin_ruleset(
            'western_chess' if case['game'] == 'chess' else 'standard_shogi'))
        provider = NativeSemanticLegalityProvider.try_create(compiled, strict=True)
        if provider is None:
            raise RuntimeError('requested Native unavailable')
        for mode in ('clean_forward', 'clean_reverse', 'profile'):
            arms = ('core', 'native') if mode != 'clean_reverse' else ('native', 'core')
            for arm in arms:
                t = perf_counter()
                board = CoreBoard(case, compiled, provider=provider if arm == 'native' else None)
                board.actions()
                setup = perf_counter()-t
                profile = cProfile.Profile()
                if mode == 'profile':
                    profile.enable()
                row = minimal_ab(board, 8, seconds=60, node_limit=4096, trace=mode == 'profile')
                if mode == 'profile':
                    profile.disable()
                    stats = pstats.Stats(profile)
                    groups, functions = {}, []
                    for (file, line, name), (pc, calls, own, cum, _) in stats.stats.items():
                        group = category(file, name)
                        groups[group] = groups.get(group, 0)+own
                        try:
                            file = str(Path(file).relative_to(ROOT)).replace('\\', '/')
                        except ValueError:
                            file = Path(file).name
                        functions.append(dict(file=file, line=line, name=name, calls=calls,
                                              own_seconds=own, cumulative_seconds=cum))
                    row.update(exclusive_groups=groups, exclusive_total=sum(groups.values()),
                               functions=sorted(functions, key=lambda f:f['own_seconds'], reverse=True))
                row.update(case=case['id'], mode=mode, backend=arm, setup_seconds=setup)
                report['rows'].append(row)
                a.output.parent.mkdir(parents=True, exist_ok=True)
                a.output.write_bytes((json.dumps(report, indent=2)+'\n').encode())
                print(case['id'], mode, arm, row['work']['nodes'], round(row['wall_seconds'],3), flush=True)
    for case in (CASES[0], CASES[7]):
        rows = [r for r in report['rows'] if r['case'] == case['id']]
        assert all(r['work'] == rows[0]['work'] for r in rows)
        assert len({r['trace_sha256'] for r in rows if r['mode']=='profile'}) == 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
