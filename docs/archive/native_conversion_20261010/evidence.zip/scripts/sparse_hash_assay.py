"""Declared fixed-work and history-complete transfer of sparse diff prototype.

Two familiar roots plus two existing generated6 event roots selected by seed,
not outcomes. One frozen table assigns100 to each non-anchor type. Depth8,
4096entry budget,60sec fuse; reversed baseline/prototype pairs. Timings include
all existing legality/cancellation/history work; constructors excluded. Full
profile traces checked separately. This assay is not a player/price test.
"""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dataclasses import replace
import argparse
import hashlib
import json
from time import perf_counter
from unittest.mock import patch
from scripts.sparse_hash_diagnostic import sparse_diff, direct_sparse_diff
from scripts.search_backend_comparison import CASES, CoreBoard, minimal_ab
from generic_chess import build_builtin_ruleset, compile_ruleset_for_execution
from generic_chess.core import search_runtime as rt
from generic_chess.core.actions import action_from_dict, action_to_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider


class GeneratedBoard:
    def __init__(self, case, ply, provider=None):
        self.compiled = compile_ruleset_for_execution(ruleset_from_dict(case['rules']))
        session = GameSession(self.compiled)
        for step in case['route'][:ply]:
            session.submit(action_from_dict(step['action']))
        self.initial = session.state
        self.witnesses = tuple(session._search_witnesses)
        self.runtime = rt.SearchPathRuntime.from_state(self.initial, self.compiled,
            history_witnesses=self.witnesses, legal_binding_provider=provider)
        self.label = lambda action: json.dumps(action_to_dict(action), sort_keys=True,separators=(',',':'))
        self.checkpoint = None
        self.values = {p.type_id:0 if p.is_anchor else 100 for p in self.compiled.piece_types}

    actions = CoreBoard.actions
    push = CoreBoard.push
    pop = CoreBoard.pop
    terminal = CoreBoard.terminal
    restored = CoreBoard.restored
    snapshot = CoreBoard.snapshot

    def evaluate(self):
        p=self.runtime.position
        return sum((1 if x.owner==p.side_to_move else -1)*self.values[x.current_type_id]
                   for x in p.board if x is not None)+sum(
                   (1 if owner==p.side_to_move else -1)*self.values[tid]*n
                   for owner,hand in enumerate(p.hands) for tid,n in hand.items())


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--generated-only',action='store_true')
    p.add_argument('--direct',action='store_true',help='second premise: no metadata-carrier allocations')
    a=p.parse_args()
    old=rt._semantic_component_diff_hash
    inputs=ROOT/'.local_agent/generated6-20261008/coverage.json'
    data=json.loads(inputs.read_bytes())
    report=dict(schema=1,declaration=__doc__,input_sha256=hashlib.sha256(inputs.read_bytes()).hexdigest(),rows=[])
    factories=[]
    for case in (() if a.generated_only else (CASES[0],CASES[7])):
        c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        factories.append((case['id'],lambda case=case,c=c:CoreBoard(case,c)))
    for seed in (202610082000,202610082001):
        case=next(c for c in data['cases'] if c['seed']==seed)
        factories.append((f'generated-{seed}-ply3',lambda case=case:GeneratedBoard(case,3)))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    for name,factory in factories:
        for mode in ('core','native'):
            probe=factory()
            provider=NativeSemanticLegalityProvider.try_create(probe.compiled,strict=True) if mode=='native' else None
            if mode=='native' and provider is None:
                report['rows'].append(dict(case=name,backend=mode,unsupported=True));continue
            for repeat in (0,1):
                for candidate in ((False,True) if repeat==0 else (True,False)):
                    board=factory()
                    if provider is not None:
                        board.runtime=rt.SearchPathRuntime.from_state(board.initial,board.compiled,
                            history_witnesses=board.witnesses,legal_binding_provider=provider)
                    board.actions()
                    with patch.object(rt,'_semantic_component_diff_hash',
                                      (direct_sparse_diff if a.direct else sparse_diff) if candidate else old):
                        row=minimal_ab(board,8,seconds=60,node_limit=4096,trace=True)
                    row.update(case=name,backend=mode,repeat=repeat,prototype=candidate)
                    report['rows'].append(row)
                    a.output.write_bytes((json.dumps(report,indent=2)+'\n').encode())
                    print(name,mode,repeat,candidate,row['work']['nodes'],round(row['wall_seconds'],3),flush=True)
            rows=[r for r in report['rows'] if r['case']==name and r['backend']==mode]
            assert all(r['work']==rows[0]['work'] and r['trace_sha256']==rows[0]['trace_sha256'] for r in rows)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
