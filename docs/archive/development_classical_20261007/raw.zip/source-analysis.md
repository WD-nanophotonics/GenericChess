# Classical control interpretation
Pinned source9f778da667f6e07dae1e85d3e2ea204fc6dee94d.
The sole GENERICCHESS_MATERIAL_DEVELOPMENT occurrence is evaluate.cpp1609:
material builds return from Eval::evaluate before all ordinary classical logic.
Recompiling only evaluate.cpp without that macro restores native classical
Evaluation<NO_TRACE>(pos).value() with Use NNUE=false. All other objects are
identical; hashes and compiler/link commands are preserved in build.json.
psqt.cpp290-303 uses variant pieceValueMg/Eg to set EvalPieceValue,302-345
builds piece-square scores. The same gc tables are loaded in paired controls.
This is not merely adding position bonuses to our static formula: native
material imbalance, pawn structure, mobility, king danger, passed pawns,
threats, space, winnability/scaling, tempo, specialized endgame handlers and
rule50 damping return. evaluate.cpp1483 can bypass ordinary PSQT through
specialized material evaluation; many positional calculations use native
PieceValue. The baseline is a deliberately bundled human-engineered control.
The gc variant name also disables chess-only lazy-evaluation shortcuts at
1510/1539, equally across the paired variant setup, but differently from the
engine's default chess mode. Never infer native default engine strength.
The search source is unchanged, but restoring static values changes pruning,
ordering history and reached nodes. Outcomes identify useful practical
leaf/search coupling, not isolated positional-term causality. Fresh game/hash,
same time and legal Core replay control resources and semantic scope only.
No tuning/default changes and no new human-value holdout access.
