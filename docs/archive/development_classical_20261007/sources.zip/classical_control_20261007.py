"""Frozen same-search classical-leaf development control, no fitting."""
import sys, os, json, time, hashlib, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess, chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/classical-control-20261007';p.mkdir(exist_ok=True)
base=ROOT/'.local_agent/mature-search'
src=base/'Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d/src'
config=base/'material-variants.ini'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
binary=p/'fairy-classical.exe'
bins={'pure':base/'build/fairy-material.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe','classical':binary}
ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
suite=json.loads((ROOT/'.local_agent/mature-openings/suite.json').read_bytes())
def stopcheck():
 for n in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise KeyboardInterrupt('User stop retained')
if sys.argv[1]=='build':
 assert not (p/'declaration.json').exists()
 sources=json.loads((base/'build-report.json').read_bytes())['sources']
 decl=dict(question='Can unchanged search with restored classical leaf play effectively, and how do pure/activity compare under the same tables?',
  scope='Exposed Standard Chess development. Classical human-engineered positional/material machinery is an external benchmark, never a rule-derived candidate or price fitting target. Same gc tables for paired games; classical PSQT/imbalance/endgame heuristics remain native and are a deliberate bundle, not an isolated single term.',
  design='First qualify source/build/options. Then24direct games: two fixed prefixes, three unchanged gc tables, both colors, classical versus pure/activity interleaved. Follow12classical versus fixed full-strength reference games under the same prefixes/tables/colors. All native engines SinglePV1/Threads1/Hash16/NNUEfalse; local1sec, reference50000nodes/1sec,160subsequentplies. Fresh game/hash each cell. Retain failures/unfinished; no silent rerun.',
  decision='Classical success while candidates fail implicates leaf/search coupling rather than basic search capacity; failure cannot establish search incapacity. Neither direction isolates a single classical term or proves generic strength. No coefficient/default promotion.',
  cost='Finite36sequential games; direct upper3840requestedsec, reference upper960local+960referencefuse sec plus Core/recording. One game at a time, stop check each action. Checkpoint after direct cohort before continuing declared reference cohort; no result-dependent budget extension.',
  source_eval_sha256=sha(src/'evaluate.cpp'),config_sha256=sha(config),adapter_sha256=sha(ROOT/'scripts/chess_development.py'),reference_sha256=sha(ref),reused_objects={f:sha(base/'build'/(f.replace('/','_')+'.o')) for f in sources if f!='evaluate.cpp'})
 d.write_record(p/'declaration.json',decl)
 flags=[sys.executable,'-m','ziglang','c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-fno-exceptions','-fno-strict-aliasing','-DNDEBUG','-DIS_64BIT','-DNNUE_EMBEDDING_OFF']
 obj=p/'evaluate.cpp.o';env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(base/'zig-global-cache'),ZIG_LOCAL_CACHE_DIR=str(base/'zig-local-cache'))
 commands=[flags+['-I',str(src),'-c',str(src/'evaluate.cpp'),'-o',str(obj)],flags+[str(obj if f=='evaluate.cpp' else base/'build'/(f.replace('/','_')+'.o')) for f in sources]+['-o',str(binary),'-lpthread','-ladvapi32','-Wl,--stack,8388608']]
 report=dict(complete=False,commands=[]);start=time.perf_counter()
 for cmd in commands:
  r=subprocess.run(cmd,cwd=src,env=env,capture_output=True,text=True,timeout=120)
  report['commands'].append(dict(command=cmd,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));d.write_record(p/'build.json',report)
  print('build',r.returncode,flush=True);assert r.returncode==0,r.stderr
 report.update(complete=True,wall_seconds=time.perf_counter()-start,binary_sha256={k:sha(v) for k,v in bins.items()})
 assert sha(src/'evaluate.cpp')==decl['source_eval_sha256']
 for f,h in decl['reused_objects'].items():assert sha(base/'build'/(f.replace('/','_')+'.o'))==h
 d.write_record(p/'build.json',report);print('built',report['wall_seconds'],flush=True);sys.exit()
decl=json.loads((p/'declaration.json').read_bytes());build=json.loads((p/'build.json').read_bytes());assert build['complete']
for k,v in bins.items():assert sha(v)==build['binary_sha256'][k]
class Player(d.UciMaterial):
 def __init__(self,*args,mode,**kw):super().__init__(*args,**kw);self.mode=mode
 def choose(self):
  m,r=super().choose();r.update(leaf_mode=self.mode,leaf_binary_sha256=build['binary_sha256'][self.mode],requested_seconds=1);return m,r
cohort=sys.argv[1];assert cohort in ('direct','reference')
out=p/(cohort+'.json');assert not out.exists()
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
report=dict(declaration=decl,build_sha256=sha(p/'build.json'),cohort=cohort,games=[],complete=False)
cost=dict(writes=0,bytes=0,seconds=0.)
def save():
 t=time.perf_counter();d.write_record(out,report,indent=None);cost['seconds']+=time.perf_counter()-t;cost['writes']+=1;cost['bytes']+=out.stat().st_size
start=time.perf_counter();save()
try:
 for case in suite['cases']:
  for policy in d.POLICIES:
   for color in (0,1):
    for opponent_mode in (('pure','activity') if cohort=='direct' else ('reference',)):
     stopcheck()
     with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci([str(bins[opponent_mode]),'load',str(config)] if cohort=='direct' else str(ref),timeout=15) as other:
      e.configure({'Threads':1,'Hash':16,'Use NNUE':False});other.configure({'Threads':1,'Hash':16,**({'Use NNUE':False} if cohort=='direct' else {'UCI_LimitStrength':False})})
      local=Player(e,case['fen'],policy,1,mode='classical')
      external=Player(other,case['fen'],policy,1,mode=opponent_mode) if cohort=='direct' else d.UciOpponent(other,case['fen'],50000)
      def progress(game):
       report['active_game']=dict(id=case['id'],classical_color=color,opponent_mode=opponent_mode,table=policy,**game);save();stopcheck()
      game=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=external,local_external=local,prefix=case['opening_uci'])
      report.pop('active_game',None);report['games'].append(dict(id=case['id'],classical_color=color,opponent_mode=opponent_mode,table=policy,**game));save()
      print(cohort,len(report['games']),case['id'],policy,color,opponent_mode,game['end'],game['winner'],game['plies_played'],flush=True)
 report['complete']=True
finally:
 report.update(wall_seconds=time.perf_counter()-start,recording_cost=dict(cost));save()
print('COMPLETE',cohort,report['complete'],report['wall_seconds'],cost,flush=True)
