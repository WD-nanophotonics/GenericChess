"""Verified portable evidence, with private local build paths normalized."""
import sys,json,hashlib,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'.local_agent/classical-control-20261007';a=ROOT/'docs/archive/development_classical_20261007';a.mkdir(exist_ok=True)
out=ROOT/'docs/research/data/chess_classical_20261007.json';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def norm(x):
 if isinstance(x,str):return x.replace(str(ROOT),'{PROJECT_ROOT}').replace(ROOT.as_posix(),'{PROJECT_ROOT}')
 if isinstance(x,list):return [norm(v) for v in x]
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
 return x
build_raw=(p/'build.json').read_bytes();build=json.loads(build_raw)
write_record(p/'build-portable.json',dict(original_local_sha256=sha(build_raw),normalization='Project absolute paths replaced with {PROJECT_ROOT}; original private build report retained locally.',report=norm(build)))
groups={};files=[p/n for n in ('declaration.json','default-declaration.json','build-portable.json','qualification.json','source-analysis.md','direct-roots.json','shogi-silver.json','compact-pv-cost.json')]
for cohort,count in [('direct',24),('reference',12),('default',4)]:
 v=json.loads((p/(cohort+'.json')).read_bytes());r=json.loads((p/(cohort+'-replay.json')).read_bytes())
 assert v['complete'] and r['complete'] and len(r['games'])==count and not r['errors']
 methods={}
 for g in r['games']:
  k=g['table']+'/'+g['opponent_mode'];z=methods.setdefault(k,dict(wins=0,losses=0,draws=0,unfinished=0))
  key='unfinished' if not g['finished'] else 'draws' if g['winner'] is None else 'wins' if g['winner']==g['classical_color'] else 'losses';z[key]+=1
 groups[cohort]=dict(declaration=v['declaration'],methods=methods,cells=r['games'],wall_seconds=v['wall_seconds'],recording_cost_before_final_save=v['recording_cost'],replay=dict(streams=count,played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0))
 files.extend(p/n for n in (cohort+'.json',cohort+'-replay.json'))
roots=json.loads((p/'direct-roots.json').read_bytes());assert roots['complete'];contrasts={}
for right in ('activity','pure'):
 z=dict(same=0,finite_better=0,finite_worse=0,finite_equal=0,mate=[])
 for r in roots['rows']:
  m={x['mode']:x['move'] for x in r['choices']};l,b=m['classical'],m[right]
  if l==b:z['same']+=1;continue
  x,y=r['references'][l],r['references'][b]
  if x['cp'] is None or y['cp'] is None:z['mate'].append(dict(game=r['game'],left=x,right=y));continue
  delta=x['cp']-y['cp'];z['finite_better' if delta>0 else 'finite_worse' if delta<0 else 'finite_equal']+=1
 contrasts[right]=z
entries={};sources={}
def archive(path,items,target):
 assert not path.exists()
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in items:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:\\+Users\\+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b)
   z.writestr(n,b);target[n]=dict(bytes=len(b),sha256=sha(b))
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and set(z.namelist())==set(target)
  for n,h in target.items():assert sha(z.read(n))==h['sha256']
archive(a/'raw.zip',[(f,f.name) for f in files],entries)
names=('classical_control_20261007.py','classical_default_20261007.py','classical_roots_20261007.py','replay_classical_20261007.py','replay_classical_default_20261007.py','shogi_silver_20261007.py','compact_pv_cost_20261007.py','collect_classical_20261007.py','multipv_player_20261007.py')
upstream=ROOT/'.local_agent/mature-search/Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d'
archive(a/'sources.zip',[(ROOT/'.local_agent'/n,n) for n in names]+[(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(upstream/'src/evaluate.cpp','pinned-evaluate.cpp'),(upstream/'Copying.txt','upstream-Copying.txt'),(ROOT/'.local_agent/mature-search/material-variants.ini','material-variants.ini'),(ROOT/'.local_agent/mature-openings/suite.json','suite.json')],sources)
shogi=json.loads((p/'shogi-silver.json').read_bytes());assert shogi['complete']
summary=dict(scope='StandardChess exposed development; classical human-engineered benchmark, not generic rule-derived candidate, price calibration or isolated positional-term effect. No default/Elo/holdout/strength claim. Shogi distinct reachable cooperative prefix control.',source_pin='9f778da667f6e07dae1e85d3e2ea204fc6dee94d',parent_sha='04a756f51642060e4f6e000ac786f7d03a1aa575',build=norm(build),qualification_note='qualification.json options field records option defaults, not configured values; original executed calls explicitly configure Threads1/Hash16/Use NNUEfalse. Build and producers preserve those settings.',groups=groups,root_sampling=dict(declaration=roots['declaration'],games=roots['selected_source_game_indices'],roots=len(roots['rows']),contrasts=contrasts,interpretation='Outcome-conditioned exposed sampling, finite reference cp differences; small deltas unreliable, not tactical error-rate.'),shogi=shogi,compact_pv=json.loads((p/'compact-pv-cost.json').read_bytes()),raw_entries=entries,sources=sources,raw_archive=a.relative_to(ROOT).as_posix()+'/raw.zip',sources_archive=a.relative_to(ROOT).as_posix()+'/sources.zip',raw_zip_sha256=sha((a/'raw.zip').read_bytes()),sources_zip_sha256=sha((a/'sources.zip').read_bytes()),production_changes='None; all search/price/default APIs unchanged',public_push='held')
write_record(out,summary);write_record(a/'index.json',dict(raw_entries=entries,sources=sources,portable_sha256=sha(out.read_bytes())))
print(json.dumps(dict(groups={k:dict(methods=v['methods'],wall_seconds=v['wall_seconds'],replay=v['replay']) for k,v in groups.items()},contrasts=contrasts,sha256=sha(out.read_bytes()))),flush=True)
