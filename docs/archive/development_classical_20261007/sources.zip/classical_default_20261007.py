"""Four ordinary-Chess native classical benchmark cells, not a candidate."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/classical-control-20261007';binary=p/'fairy-classical.exe';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
build=json.loads((p/'build.json').read_bytes());assert sha(binary)==build['binary_sha256']['classical']
decl=dict(question='Is the classical gc bundle failure representative of ordinary native classical search?',changed_premise='Use ordinary Chess board/variant and original native human-engineered prices instead of gc overrides. Also restores chess-name lazy shortcuts, so this is a configuration-bundle benchmark, not pure price isolation or rule-derived candidate.',design='Four prospectively fixed cells: two existing prefixes,both colors; fresh hash/game, SinglePV1 Threads1 Hash16 NNUEfalse, local1sec, referencefullstrength50000nodes/1sec,160subsequentplies. Preserve all adverse/unfinished/interrupted outcomes; no silent rerun, tuning or default change.',cost='At most320requestedlocal+320referencefuse sec plus Core/recording; single game, stop check each action.',decision='A useful native baseline supports practical leaf/configuration coupling exploration; failure remains finite benchmark evidence and cannot prove incapacity. Never fit candidate prices to this human-engineered control.',binary_sha256=sha(binary),reference_sha256=sha(ref),prior='direct/reference cohorts in classical-control-20261007',routing='Existing unit route token selects local_external only; actual leaf policy and table are native_classical, with ordinary chess.Board and UCI_Variant chess.')
assert not (p/'default-declaration.json').exists();d.write_record(p/'default-declaration.json',decl)
class Native(d.UciMaterial):
 def __init__(self,e,fen):
  d.UciOpponent.__init__(self,e,fen,1);self.limit=chess.engine.Limit(time=1);self.policy='native_classical';self.multipv=1;e.configure({'Clear Hash':None})
 def choose(self):
  m,r=super().choose();r.update(leaf_mode='classical',leaf_binary_sha256=sha(binary),requested_seconds=1,variant='chess');return m,r
def stopcheck():
 for n in ('rollout','advisor','slack'):
  v=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if v.get('user_paused') or v.get('stopped'):raise KeyboardInterrupt('User stop retained')
out=p/'default.json';assert not out.exists();report=dict(declaration=decl,games=[],complete=False);cost=dict(writes=0,bytes=0,seconds=0.)
def save():
 t=time.perf_counter();d.write_record(out,report,indent=None);cost['seconds']+=time.perf_counter()-t;cost['writes']+=1;cost['bytes']+=out.stat().st_size
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());suite=json.loads((ROOT/'.local_agent/mature-openings/suite.json').read_bytes());start=time.perf_counter();save()
try:
 for case in suite['cases']:
  for color in (0,1):
   stopcheck()
   with chess.engine.SimpleEngine.popen_uci(str(binary),timeout=15) as e,chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as other:
    e.configure({'Threads':1,'Hash':16,'Use NNUE':False});other.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
    local=Native(e,case['fen']);external=d.UciOpponent(other,case['fen'],50000)
    def progress(g):report['active_game']=dict(id=case['id'],classical_color=color,table='native_classical',opponent_mode='reference',**g);save();stopcheck()
    g=d.play_game(case['fen'],c,'unit' if color==0 else 'uci_reference','uci_reference' if color==0 else 'unit',d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=external,local_external=local,prefix=case['opening_uci'])
    report.pop('active_game',None);report['games'].append(dict(id=case['id'],classical_color=color,table='native_classical',opponent_mode='reference',**g));save();print('default',len(report['games']),case['id'],color,g['end'],g['winner'],g['plies_played'],flush=True)
 report['complete']=True
finally:report.update(wall_seconds=time.perf_counter()-start,recording_cost=dict(cost));save()
print('COMPLETE default',report['complete'],report['wall_seconds'],cost,flush=True)
