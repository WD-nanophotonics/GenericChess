"""Static serialization comparison; no new search or throughput assertion."""
import sys,json,hashlib,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'.local_agent/classical-control-20261007';out=p/'compact-pv-cost.json';assert not out.exists()
report=dict(question='How many bytes does the shared compact MultiPV view remove without changing selected decision/PV/resource metadata?',scope='Projection of completed old raw rows, not a new engine trial or measured game throughput. Preserves original raw sources unchanged.',groups=[])
for folder in ('activity-multipv-direct-20261007','activity-multipv-stronger-20261007'):
 f=ROOT/'.local_agent'/folder/'games.json';raw=f.read_bytes();v=json.loads(raw);assert v['complete']
 old=[r for g in v['games'] for r in g['moves'] if 'multipv_lines' in r];new=[]
 for r in old:
  t=copy.deepcopy(r);t['multipv_lines']=[dict(rank=l.get('rank'),move=l['pv'][0] if l['pv'] else None,depth=l.get('depth'),score_cp=l.get('score_cp'),score_mate=l.get('score_mate'),lowerbound=l.get('lowerbound'),upperbound=l.get('upperbound')) for l in r['multipv_lines']]
  assert {k:x for k,x in t.items() if k!='multipv_lines'}=={k:x for k,x in r.items() if k!='multipv_lines'}
  assert any(l['move']==t['move'] for l in t['multipv_lines'])
  new.append(t)
 a=p/(folder+'-rich-view.json');b=p/(folder+'-compact-view.json');write_record(a,old,indent=None);write_record(b,new,indent=None)
 report['groups'].append(dict(source=folder+'/games.json',source_sha256=hashlib.sha256(raw).hexdigest(),rows=len(old),rich_bytes=a.stat().st_size,compact_bytes=b.stat().st_size,bytes_saved=a.stat().st_size-b.stat().st_size,selected_move_full_pv_top_level_resource_mismatches=0,removed='Nonselected full PVs and duplicate per-line nodes/time; top-level aggregate resources remain exact. These views are not substitutes for archived rich raw evidence.'))
write_record(out,report);print(json.dumps(report['groups']),flush=True)
