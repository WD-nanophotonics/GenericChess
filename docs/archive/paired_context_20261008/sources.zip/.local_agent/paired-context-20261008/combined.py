"""One explicitly recombined rule: transient promotion right plus guarded hand."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import legal_successors
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,terminal_status
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'combined.json';assert not out.exists();started=time.perf_counter()
fixtures=weird_rulesets();guard=fixtures[1].semantic_actions[0];promote=fixtures[2].semantic_actions[0];base=fixtures[2]
board=[[None]*8 for _ in range(8)]
for owner,tid,f,rank in ((0,'K',4,0),(1,'K',7,7),(0,'R',0,0),(0,'R',0,1),(0,'R',0,2),(0,'R',1,1),(1,'R',1,3),(1,'R',1,4)):board[rank][f]=Piece(owner,tid,tid)
definition=replace(base,initial_position=tuple(map(tuple,board)),semantic_actions=(guard,promote),drop_allowed={'R':((True,)*64,(True,)*64),'TP':((False,)*64,(False,)*64)})
c=compile_ruleset_for_execution(definition);s=GameSession(c);nr=compile_native_semantic_rules(c);mirror=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True)
oldpath=ROOT/'.local_agent/lifecycle-20261008/transition-before.py';oldraw=oldpath.read_bytes();ns=dict(__name__='generic_chess.core.transition',__package__='generic_chess.core');exec(compile(oldraw,'frozen_transition_before.py','exec'),ns);old=ns['legal_successors']
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),baseline_sha256=hashlib.sha256(oldraw).hexdigest(),candidate_sha256=hashlib.sha256((ROOT/'generic_chess/core/transition.py').read_bytes()).hexdigest(),definition=ruleset_to_dict(definition),declaration='New recombination, not claim existing fixture already combined: current-type zone-capacity drop guard plus promotion-toTP transient global right. Initial3currentR in zone(0,0),(0,1),(0,2). Actual two captures create hand2; promote zoneR toTP opens capacity; enemy turn expires right; drop fills zone and blocks remaining hand. Nine history roots, all child GameState old/new parity; independent Native selected full route/action/terminal. Alternating old/new twice per root eager only. Public fixed generic-v1 static-only depth2/8192nodes/10sec q0/root-tactical-off: fresh/reused/repeat at ply2,6,8; Core same depth leaf8192/10sec, incomplete unknown. No public speed or valuation claim from eager timing. Frozen path independent of output.',rows=[],route=[],search=[])
write_record(out,r);cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);ev=Evaluator(c,build_ruleset_profile(c,cfg),cfg)
def make():return AlphaBetaPlayer(c,evaluation_config=cfg,use_disk_cache=False,evaluator_override=ev,tuning=SearchTuning(use_root_tactical=False),tt_max_entries=8192)
reused=make();path=[((1,1),(1,3),'board'),((7,7),(6,7),'board'),((1,3),(1,4),'board'),((6,7),(5,7),'board'),((0,0),(1,1),'semantic'),((5,7),(4,7),'board'),(None,(0,0),'drop'),((4,7),(3,7),'board')]
for ply in range(9):
 assert snapshot_matches(mirror.snapshot(),s.state.position,nr,c);nt=terminal_status(nr,mirror.position);assert (nt['status'],nt['winner'])==(s.state.terminal_status.status.value,s.state.terminal_status.winner)
 row=dict(ply=ply,hands=record_value(s.state.position.hands),aux=record_value(s.state.position.aux_state),calls=[]);r['rows'].append(row);expected=None
 for repeat,methods in enumerate((('old','new'),('new','old'))):
  for method in methods:
   before=time.perf_counter();pairs=(old if method=='old' else legal_successors)(s.state,c);elapsed=time.perf_counter()-before
   if expected is None:expected=pairs
   assert pairs==expected;row['calls'].append(dict(method=method,repeat=repeat,seconds=elapsed,successors=len(pairs)))
 row['drop_count']=sum(hasattr(a,'base_type_id') for a,ch in pairs);row['full_state_sha256']=hashlib.sha256(json.dumps(record_value(pairs),sort_keys=True).encode()).hexdigest()
 assert {a for a,ch in pairs}=={public_action(nr,a) for a in guarded_actions(nr,mirror.position)}
 if ply in (2,6,8):
  ref=CountedEvaluator(ev,seconds=10,evaluations=8192)
  try:score,action=reference_minimax(s.state,2,ref,c);reference=dict(complete=True,score=score,action=record_value(action))
  except ReferenceLimit:reference=dict(complete=False,score=None,action=None)
  reference['leaves']=ref.calls;search=dict(ply=ply,reference=reference,calls=[]);r['search'].append(search)
  for label,player in (('fresh',make()),('reused',reused),('repeat',reused)):
   decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,decision)
   equal=decision.score==reference['score'] if reference['complete'] and decision.completed_depth==2 else None;assert equal is not False
   search['calls'].append(dict(label=label,reference_equal=equal,decision=record_value(decision)))
  assert len({(x['decision']['score'],x['decision']['completed_depth']) for x in search['calls']})==1
 write_record(out,r);print('ply',ply,'hand',row['hands'],'aux',row['aux'],'drops',row['drop_count'],flush=True)
 if ply==8:break
 source,target,kind=path[ply];matches=[]
 for a,ch in pairs:
  encoded=record_value(a)
  if (a.to_square.file,a.to_square.rank)!=target:continue
  if kind=='drop':ok=hasattr(a,'base_type_id')
  else:ok=hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source and (a.pattern_id.startswith('sem_') if kind=='semantic' else not a.pattern_id.startswith('sem_'))
  if ok:matches.append(a)
 assert len(matches)==1,(ply,matches);action=matches[0];mirror.push(action,s.state.position);s.submit(action);r['route'].append(record_value(action))
r.update(complete=True,seconds=time.perf_counter()-started);assert r['rows'][2]['drop_count']==0 and r['rows'][6]['drop_count']>0 and r['rows'][8]['drop_count']==0;write_record(out,r)
