"""One actual surviving-piece service delay; no extra population or proof."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'rook-pressure.json';raw=json.loads(src.read_bytes());case=raw['cases'][0];c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));s=initial_state(c);nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True)
path=[((3,2),(4,4)),((8,6),(1,6)),(None,(4,5)),((1,6),(0,6)),((0,0),(1,0)),((8,8),(7,8))];rows=[];route=[]
for ply in range(7):
 actions=legal_actions(s,c);assert set(actions)=={public_action(nr,a) for a in guarded_actions(nr,m.position)};assert snapshot_matches(m.snapshot(),s.position,nr,c);nt=terminal_status(nr,m.position);assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner)
 source_piece=s.position.board[5*9+4];U=len({(a.to_square.file,a.to_square.rank) for a in actions if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==(4,5)}) if s.position.side_to_move==0 else None
 rows.append(dict(ply=ply,side=s.position.side_to_move,source_piece=record_value(source_piece),U=U,terminal=record_value(s.terminal_status),legal_actions=record_value(actions)))
 if ply==6:break
 source,target=path[ply];candidates=[a for a in actions if (a.to_square.file,a.to_square.rank)==target and (hasattr(a,'base_type_id') if source is None else hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source and a.promotion_target_id is None)]
 a,=candidates;m.push(a,s.position);s=apply_action(s,a,c);route.append(record_value(a))
assert rows[4]['U']==0 and rows[4]['source_piece']['owner']==0 and rows[6]['U']>0
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='Actual NcaptureG, enemyR8,6to1,6, recipientGdrop4,5, enemyR1,6to0,6 checksKing0,0. Gsurvives but has0legal endpoints next ownturn. ActualKing0,0to1,0 and enemyK8,8to7,8 restore Gactivity. Entire7root full-history Native/Core transition/legal/terminal parity. Constructive delayed-service witness, not optimal reply/policy or global hand value. Prior minimax endpoint0 is finite activity suppression, not worthlessness. Does not change earlier census or defaults.',route=route,rows=rows)
out=p/'resumed-service.json';assert not out.exists();write_record(out,r);print([(x['ply'],x['U']) for x in rows])
