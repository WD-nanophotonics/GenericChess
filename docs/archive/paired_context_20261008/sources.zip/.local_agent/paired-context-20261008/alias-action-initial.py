"""Consistent opaque IDs across rule fields, capture reset and conditional use."""
import sys,json,hashlib,time
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'rook-pressure.json';raw=json.loads(src.read_bytes());out=p/'alias-qualified.json';assert not out.exists();begin=time.perf_counter()
ids=[x['type_id'] for x in raw['cases'][0]['definition']['piece_types']];mapping={x:'opaque_'+str(len(ids)-1-i).zfill(2) for i,x in enumerate(ids)};assert len(set(mapping.values()))==len(ids);reverse={v:k for k,v in mapping.items()}
def rename(value,mp):
 if isinstance(value,str):return mp.get(value,value)
 if isinstance(value,list):return [rename(x,mp) for x in value]
 if isinstance(value,dict):return {mp.get(k,k):rename(v,mp) for k,v in value.items()}
 return value
def norm(action):return rename(record_value(action),reverse)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),mapping=mapping,declaration='All supported Shogi type/base/current/drop/promotion/guard references consistently mapped to opaque IDs with changed lexical order. Compare all current raw values and board/hand tables by inverse alias. Actual frozen Ncapture and K reply: full Native state/terminal/action parity. Deployment cells selected BEFORE values: all rows where file/rank in(0,4,8), covering edge/center/rookline, retaining only earlier qualified source support. Recompute exact conditional endpoint H and per-source removal probability and compare original. No broad alias proof beyond these observed semantics/population, no human labels/default.',cases=[])
write_record(out,r)
for original in raw['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(rename(original['definition'],mapping)));cfg=EvaluationConfig();profile,scope=build_semantic_opportunity_profile(c,cfg)
 basec=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));baseprofile,basescope=build_semantic_opportunity_profile(basec,cfg)
 assert dict(baseprofile.board_value_by_type)==rename(dict(profile.board_value_by_type),reverse)
 assert dict(baseprofile.hand_value_by_base_type)==rename(dict(profile.hand_value_by_base_type),reverse)
 assert {tid:cell['raw'] for tid,cell in basescope['types'].items()}=={reverse.get(tid,tid):cell['raw'] for tid,cell in scope['types'].items()}
 s=initial_state(c)
 for encoded in original['actual_route']:
  candidates=[a for a in legal_actions(s,c) if norm(a)==encoded];assert len(candidates)==1;s=apply_action(s,candidates[0],c)
 assert s.position.hands[0].count(mapping['G' if original['target']=='G' else 'P'])==1
 nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True);row=dict(target=original['target'],profile_equal=True,cells=[],reply_frontiers=0);r['cases'].append(row)
 for cell in original['cells']:
  file,rank=cell['source']
  if file not in (0,4,8) or rank not in (0,4,8):continue
  drop,=[a for a in legal_actions(s,c) if norm(a)==cell['drop']];child=apply_action(s,drop,c);np=make_checked(nr,m.position,m.direct_pack(drop,s.position));assert snapshot_matches(snapshot(nr,np),child.position,nr,c)
  replies=legal_actions(child,c);nreplies=guarded_actions(nr,np);assert set(replies)=={public_action(nr,a) for a in nreplies};observed=[]
  for na in nreplies:
   action=public_action(nr,na);cs=apply_action(child,action,c);cn=make_checked(nr,np,na);assert snapshot_matches(snapshot(nr,cn),cs.position,nr,c)
   nt=terminal_status(nr,cn);assert (nt['status'],nt['winner'])==(cs.terminal_status.status.value,cs.terminal_status.winner)
   acts=legal_actions(cs,c);assert set(acts)=={public_action(nr,a) for a in guarded_actions(nr,cn)}
   U=len({(a.to_square.file,a.to_square.rank) for a in acts if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==(file,rank)})
   piece=cs.position.board[rank*9+file];survived=piece is not None and piece.owner==0;observed.append(dict(reply=norm(action),survived=survived,U=U,terminal=record_value(cs.terminal_status)));row['reply_frontiers']+=1
  key=lambda x:json.dumps(x,sort_keys=True);assert sorted(observed,key=key)==sorted(cell['continuations'],key=key)
  H=str(F(sum(x['U'] for x in observed),len(observed))) if observed else '0';assert H==cell['H'];row['cells'].append(dict(source=cell['source'],H=H,exact_continuations_equal=True))
 write_record(out,r)
r.update(complete=True,seconds=time.perf_counter()-begin);write_record(out,r);print([(x['target'],len(x['cells']),x['reply_frontiers']) for x in r['cases']],r['seconds'])
