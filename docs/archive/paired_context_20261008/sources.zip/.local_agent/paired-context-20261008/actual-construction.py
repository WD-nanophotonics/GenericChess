"""A scoped actual-context constant family, explicitly not general prices."""
import sys,json,hashlib
from pathlib import Path
from dataclasses import replace
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.semantic_executor import iter_semantic_public_actions
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,guarded_actions,public_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;source=p/'recipient-census.json';raw=json.loads(source.read_bytes());assert raw['complete'];defs=json.loads((p/'rook-pressure.json').read_bytes());rows=[]
for case,original in zip(raw['cases'],defs['cases']):
 c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));s=initial_state(c);actions=legal_actions(s,c)
 captures=[a for a in actions if hasattr(a,'to_square') and (a.to_square.file,a.to_square.rank)==(4,4)];assert len(captures)==1 and record_value(captures[0])==original['actual_route'][0]
 # Current-owner activity is a synthetic legal-only turn probe of the same
 # board. It is not a pass or a certified actual history.
 pos=replace(s.position,side_to_move=1);provider=NativeSemanticLegalityProvider.try_create(c,strict=True);core=list(iter_semantic_public_actions(provider.engine,pos));np=pack_position(provider.native_rules,provider._state_only_payload(pos,0));assert set(core)=={public_action(provider.native_rules,a) for a in guarded_actions(provider.native_rules,np)}
 endpoints={(a.to_square.file,a.to_square.rank) for a in core if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==(4,4)}
 p_capture=F(len(captures),len(actions));H=F(case['H']);A=F(len(endpoints));rows.append(dict(target=case['target'],own_action_count=len(actions),current_A=str(A),capture_probability=str(p_capture),actual_recipient_H=str(H),H_float=float(H),current_legal_endpoints=sorted(endpoints)))
assert rows[0]['current_A']==rows[1]['current_A'] and rows[0]['capture_probability']==rows[1]['capture_probability']
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),declaration='One five-entity pressure context, not a rule-wide coefficient. Uniform current-opponent legal action policy yields actual target capture probability p. A is current-owner distinct legal endpoint count using explicit position-only turn probe; bothG/TP same. H uses actual target capture then all21enemy replies, every legal recipient drop, every enemy reply, then deployed endpoints; no renewal context or chosen reply. A and H share endpoint units but timing/context laws remain different and are stated. Fixed delta in1/2,3/4,1 discounts future service; V=A-p*delta*H and transfer swing V+delta*H. Positive conditional activity constants can be generated without human prices, strictWDL or a unique rule-implied population; this does NOT establish correct game utility, a universal positive table, calibrated discount, opening reachability or a new default. Terminal utility is explicitly outside U and remains separately reported in raw census.',rows=rows,family=[])
A=F(rows[0]['current_A']);q=F(rows[0]['capture_probability']);HG=F(rows[0]['actual_recipient_H']);HP=F(rows[1]['actual_recipient_H'])
for delta in (F(1,2),F(3,4),F(1)):
 values=dict(VG=A-q*delta*HG,VTP=A-q*delta*HP,swingG=A+(1-q)*delta*HG,swingTP=A+(1-q)*delta*HP)
 r['family'].append(dict(delta=str(delta),values={k:str(v) for k,v in values.items()},decimal={k:float(v) for k,v in values.items()},positive=all(v>0 for v in values.values())))
write_record(p/'actual-construction.json',r);print(json.dumps(r,indent=2))
