"""Current geometry risk is not reset-type risk; legal-only semantic check."""
import sys,json,hashlib,time
from pathlib import Path
from dataclasses import replace
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.semantic_executor import iter_semantic_public_actions
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,guarded_actions,public_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'rook-pressure.json';raw=json.loads(src.read_bytes());gr=raw['cases'][0];c=compile_ruleset_for_execution(ruleset_from_dict(gr['definition']));s=initial_state(c)
for encoded in gr['actual_route']:
 a=[a for a in legal_actions(s,c) if record_value(a)==encoded];assert len(a)==1;s=apply_action(s,a[0],c)
provider=NativeSemanticLegalityProvider.try_create(c,strict=True);nr=provider.native_rules;start=time.perf_counter();rows=[]
for cell in gr['cells']:
 sq=tuple(cell['source']);a=[a for a in legal_actions(s,c) if record_value(a)==cell['drop']];assert len(a)==1;child=apply_action(s,a[0],c)
 board=list(child.position.board);board[sq[1]*9+sq[0]]=Piece(0,'P','TP',True);pos=replace(child.position,board=tuple(board))
 core=list(iter_semantic_public_actions(provider.engine,pos));np=pack_position(nr,provider._state_only_payload(pos,child.ply_count));native={public_action(nr,a) for a in guarded_actions(nr,np)};assert set(core)==native
 gold=legal_actions(child,c);assert set(core)==set(gold)
 captures=sum(hasattr(a,'to_square') and (a.to_square.file,a.to_square.rank)==sq for a in core)
 hazard=F(captures,len(core)) if core else F(0);assert hazard==F(cell['capture_probability'])
 rows.append(dict(source=list(sq),legal_replies=len(core),captures=captures,hazard=str(hazard),equal_current_G_TP=True,native_equal=True))
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='G actual postdrop enemyturn positions paired with baseP/currentTP substitutions. Substitutions are synthetic position-only checks; do not claim actual replay or terminal/history parity for them. Core/Native all legal reply sets agree and equal actual G sets. Captures onto source identify removal because enemy has no hand/compound effect in full Shogi; compare with original actual survivor records. This checks p_currentTP=p_currentG in this population, not p_dropP or a universal hazard.',rows=rows,seconds=time.perf_counter()-start)
write_record(p/'current-hazard.json',r);print(len(rows),'equal current hazards;seconds',r['seconds'])
