"""Exact aggregate versus source-paired risk/use, no new compute or labels."""
import json,hashlib
from pathlib import Path
from fractions import Fraction as F
p=Path(__file__).parent;source=p/'rook-pressure.json';raw=json.loads(source.read_bytes());assert raw['complete']
g,pr=raw['cases'];assert len(g['cells'])==len(pr['cells']);N=len(g['cells']);rows=[]
for a,b in zip(g['cells'],pr['cells']):
 assert a['source']==b['source'] and a['A']==b['A']
 rows.append(dict(source=a['source'],A=F(a['A']),p=F(a['capture_probability']),HG=F(a['H']),HP=F(b['H'])))
def mean(key):return sum(x[key] for x in rows)/N
A=mean('A');p0=mean('p');HG=mean('HG');HP=mean('HP');lossG=sum(x['p']*x['HG'] for x in rows)/N;lossP=sum(x['p']*x['HP'] for x in rows)/N
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),declaration='Uses exact previous source-paired census. Current-type hazard p is G-drop removal probability under uniform legal enemy reply, NOT the P-drop hazard; current TP has G geometry but resetP. Current-type equality still needs explicit executor check before identifying pTP=pG. Recipient Hlaw is an explicit renewed-context assumption at same source; it is not the real postcapture recipient state. Pairing E[p_s H_s] differs from product E[p_s]E[H_s]. Delta in1/2,3/4,1 is fixed sensitivity; no human selection/default. H already includes a later deployed-piece survival event; p denotes a distinct earlier original-piece capture event, not discounting the same event twice.',means={k:str(v) for k,v in dict(A=A,p=p0,HG=HG,HP=HP,paired_lossG=lossG,paired_lossP=lossP,independent_lossG=p0*HG,independent_lossP=p0*HP,covG=lossG-p0*HG,covP=lossP-p0*HP).items()},family=[])
for d in (F(1,2),F(3,4),F(1)):
 r['family'].append(dict(delta=str(d),VG=str(A-d*lossG),VTP=str(A-d*lossP),swingG=str(A+d*(HG-lossG)),swingTP=str(A+d*(HP-lossP)),negative_sourceG=sum(x['A']-d*x['p']*x['HG']<0 for x in rows),negative_sourceTP=sum(x['A']-d*x['p']*x['HP']<0 for x in rows)))
(p/'covariance.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(json.dumps(r,indent=2))
