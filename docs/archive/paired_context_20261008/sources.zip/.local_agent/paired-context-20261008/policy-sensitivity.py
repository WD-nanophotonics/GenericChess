"""Finite policy sensitivity from existing complete actual frontiers."""
import json,hashlib
from pathlib import Path
from fractions import Fraction as F
p=Path(__file__).parent;src=p/'recipient-census.json';raw=json.loads(src.read_bytes());assert raw['complete']
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='No new experiment or computation extension. From frozen complete actual capture/reply/drop/reply census compare uniform policies with endpoint-max recipient and endpoint-min opponent. Pure activity ranks terminal0 as defined before; terminal-aware lexicographic comparator keeps ownwin+1/loss-1/otherwise0 first then U, no WDL proof or material calibration. Worst first opponent reply is allowed because complete21reply census exists. This asks whether policy choice and omitted defensive service change interpretation, not whether min/max is the correct static rule-only prior.',cases=[])
for case in raw['cases']:
 rows=[]
 for row in case['rows']:
  drops=[]
  for drop in row['drops']:
   vals=[x['U'] for x in drop['replies']]
   def terminal_key(terminal,U):
    winner=terminal['winner'];return (1 if winner==0 else -1 if winner==1 else 0,U)
   lex=[terminal_key(x['terminal'],x['U']) for x in drop['replies']]
   if not vals:vals=[0];lex=[terminal_key(drop['terminal'],0)]
   drops.append(dict(drop=drop['drop'],uniform=F(drop['H']),worst=min(vals),best=max(vals),worst_lex=min(lex),terminal=drop['terminal']))
  uniform=sum(x['uniform'] for x in drops)/len(drops) if drops else F(0)
  best_uniform=max((x['uniform'] for x in drops),default=F(0));robust=max((x['worst'] for x in drops),default=0);lex_best=max((x['worst_lex'] for x in drops),default=(0,0))
  rows.append(dict(first_reply=row['first_reply'],drop_count=row['drop_count'],uniform=str(uniform),recipient_max_uniform=str(best_uniform),recipient_max_enemy_min=robust,terminal_aware_max_min=lex_best,robust_drops=[x['drop'] for x in drops if x['worst']==robust],immediate_winning_drops=sum(x['terminal']['winner']==0 for x in drops)))
 n=len(rows);uniform=sum(F(x['uniform']) for x in rows)/n;best_uniform=sum(F(x['recipient_max_uniform']) for x in rows)/n
 worst=min(x['recipient_max_enemy_min'] for x in rows);lex_worst=min(tuple(x['terminal_aware_max_min']) for x in rows)
 r['cases'].append(dict(target=case['target'],rows=rows,summary=dict(uniform=str(uniform),uniform_decimal=float(uniform),max_recipient_uniform_enemies=str(best_uniform),max_recipient_uniform_enemies_decimal=float(best_uniform),uniform_first_min_second_max_recipient=str(F(sum(x['recipient_max_enemy_min'] for x in rows),n)),worst_both_enemies_max_recipient=worst,terminal_aware_worst_both_enemies_max_recipient=lex_worst,first_reply_witnesses=[x['first_reply'] for x in rows if x['recipient_max_enemy_min']==worst])))
out=p/'policy-sensitivity.json';assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print([(x['target'],x['summary']) for x in r['cases']])
