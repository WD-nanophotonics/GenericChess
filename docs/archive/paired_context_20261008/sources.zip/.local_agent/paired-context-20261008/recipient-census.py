"""Actual capture-recipient continuation, all first replies; interruptible cells."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action,legal_successors
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;dep=p/'rook-pressure.json';raw=json.loads(dep.read_bytes());out=p/'recipient-census.json';assert not out.exists();started=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(dep.read_bytes()).hexdigest(),declaration='Changed premise: earlier pressure used one chosen enemyK reply and excluded sources. Now preserve actual Ncapture target G or baseP/currentTP in the same fixed five-entity roots and enumerate ALL first enemy replies, then ALL legal recipient hand drops, then ALL enemy replies. Uniform each-stage conditional action distribution; no-drop and terminal branches contribute activity0 and remain in population. U distinct deployed endpoints at recipient next turn, terminal results separate. Complete Core/Native action and transition/terminal parity at every frontier. Each first-reply cell60sec/5000secondreply checkpoint, full run initial300sec checkpoint; no partial population mean. If checkpoint reached, preserve immutable partial and decide whether unresolved ordering warrants a later cell batch, no automatic extension. One local process, no search/learning/labels/defaults. Question: does all-reply actual context retain G>P activity ordering and what selection bias did chosenK reply cause?',cases=[])
write_record(out,r)
for original in raw['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));s=initial_state(c);enc=original['actual_route'][0];caps=[a for a in legal_actions(s,c) if record_value(a)==enc];assert len(caps)==1;s=apply_action(s,caps[0],c)
 nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True);nas=guarded_actions(nr,m.position);assert set(legal_actions(s,c))=={public_action(nr,a) for a in nas}
 case=dict(target=original['target'],first_replies=len(nas),complete=False,rows=[],reply_frontiers=0);r['cases'].append(case);write_record(out,r)
 for firstna in nas:
  if time.perf_counter()-started>300:break
  first=public_action(nr,firstna);own=apply_action(s,first,c);op=make_checked(nr,m.position,firstna);assert snapshot_matches(snapshot(nr,op),own.position,nr,c)
  nt=terminal_status(nr,op);assert (nt['status'],nt['winner'])==(own.terminal_status.status.value,own.terminal_status.winner)
  root_actions=legal_actions(own,c);root_native=guarded_actions(nr,op);assert set(root_actions)=={public_action(nr,a) for a in root_native}
  drops=[a for a in root_actions if hasattr(a,'base_type_id')];row=dict(first_reply=record_value(first),root_terminal=record_value(own.terminal_status),drop_count=len(drops),complete=False,drops=[],reply_frontiers=0);case['rows'].append(row);begin=time.perf_counter()
  for drop,child in ((a,ch) for a,ch in legal_successors(own,c) if hasattr(a,'base_type_id')):
   if time.perf_counter()-begin>60 or row['reply_frontiers']>=5000:break
   dm=NativeSemanticPositionMirror.from_state(c,nr,own,history_certified=True);np=make_checked(nr,op,dm.direct_pack(drop,own.position));assert snapshot_matches(snapshot(nr,np),child.position,nr,c)
   nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(child.terminal_status.status.value,child.terminal_status.winner)
   replies=legal_successors(child,c);nreplies=guarded_actions(nr,np);assert {a for a,ch in replies}=={public_action(nr,a) for a in nreplies};lookup={a:ch for a,ch in replies};sq=drop.to_square;continued=[]
   for na in nreplies:
    reply=public_action(nr,na);cs=lookup[reply];cn=make_checked(nr,np,na);assert snapshot_matches(snapshot(nr,cn),cs.position,nr,c)
    nt=terminal_status(nr,cn);assert (nt['status'],nt['winner'])==(cs.terminal_status.status.value,cs.terminal_status.winner)
    acts=legal_actions(cs,c);assert set(acts)=={public_action(nr,a) for a in guarded_actions(nr,cn)}
    U=len({(a.to_square.file,a.to_square.rank) for a in acts if hasattr(a,'from_square') and a.from_square==sq})
    continued.append(dict(reply=record_value(reply),U=U,terminal=record_value(cs.terminal_status)));row['reply_frontiers']+=1
   row['drops'].append(dict(drop=record_value(drop),terminal=record_value(child.terminal_status),replies=continued,H=str(F(sum(x['U'] for x in continued),len(continued))) if continued else '0'))
  else:row['complete']=True
  row['seconds']=time.perf_counter()-begin;case['reply_frontiers']+=row['reply_frontiers'];write_record(out,r)
  print(case['target'],len(case['rows']),case['first_replies'],'drops',len(row['drops']),'frontiers',row['reply_frontiers'],'complete',row['complete'],'seconds',round(row['seconds'],3),flush=True)
  if not row['complete']:break
 else:case['complete']=True
 if case['complete']:
  for row in case['rows']:row['H']=str(sum(F(d['H']) for d in row['drops'])/row['drop_count']) if row['drop_count'] else '0'
  case['H']=str(sum(F(x['H']) for x in case['rows'])/case['first_replies'])
 write_record(out,r)
r.update(complete=all(x['complete'] for x in r['cases']),seconds=time.perf_counter()-started);write_record(out,r)
print('complete',r['complete'],'seconds',r['seconds'],[(x['target'],x.get('H'),x['reply_frontiers']) for x in r['cases']],flush=True)
