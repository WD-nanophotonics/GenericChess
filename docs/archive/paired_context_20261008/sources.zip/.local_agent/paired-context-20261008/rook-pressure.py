"""Independent declared pressure context, paired board/drop endpoint units."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'rook-pressure.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Independent synthetic actual history, standard Shogi: ownK0,0 N3,2; enemyK8,8 R8,6 targetG or baseP/currentTP4,4. N captures4,4 unpromoted; enemyK to7,8. No default/label fit. Uniform common legal G/P drop sources, excluding opponent already checked by constructed currentG/TP source. A is distinct own endpoints in corresponding ownturn initial board, all hands empty; H is distinct deployed endpoints after actual legal drop and uniform actual enemy reply, captured/terminal0 with terminal result separately retained. Opponent rook introduces real survival variation. Same endpoint units, not same tempo/conditioning. At most60sec/5000enemy frontiers per hand type checkpoint; partial means are never population means. Validate every actual drop/reply full Core/Native board/hand/aux/history/terminal/frontier parity. Fixed illustrative p1/4 delta3/4 is not estimated or selected.',cases=[])
write_record(out,r);base=build_standard_shogi_ruleset();roots={}
for target in ('G','TP'):
 board=[[None]*9 for _ in range(9)]
 for owner,b,t,f,rank in ((0,'K','K',0,0),(0,'N','N',3,2),(1,'K','K',8,8),(1,'R','R',8,6),(1,'P' if target=='TP' else 'G',target,4,4)):board[rank][f]=Piece(owner,b,t,t!=b)
 definition=replace(base,initial_position=tuple(tuple(x) for x in board));c=compile_ruleset_for_execution(definition);s=initial_state(c);route=[]
 for source,dest in (((3,2),(4,4)),((8,8),(7,8))):
  candidates=[a for a in legal_actions(s,c) if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source and (a.to_square.file,a.to_square.rank)==dest and a.promotion_target_id is None];assert len(candidates)==1
  route.append(record_value(candidates[0]));s=apply_action(s,candidates[0],c)
 drops={(a.to_square.file,a.to_square.rank):a for a in legal_actions(s,c) if hasattr(a,'base_type_id')};roots[target]=(definition,c,s,drops,route)
common=sorted(roots['G'][3].keys() & roots['TP'][3].keys());r['common_source_count']=len(common);r['excluded']=[];kept=[]
for square in common:
 s=roots['G'][2];board=list(s.position.board);board[square[1]*9+square[0]]=Piece(0,'G','G');pos=replace(s.position,board=tuple(board),hands=(Hands.empty(),Hands.empty()))
 if semantic_engine_for(roots['G'][1]).in_check(pos,1):r['excluded'].append(list(square))
 else:kept.append(square)
for target in ('G','TP'):
 definition,c,s,drops,route=roots[target];nr=compile_native_semantic_rules(c);mirror=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True)
 row=dict(target=target,definition=ruleset_to_dict(definition),actual_route=route,complete=False,cells=[],reply_frontiers=0);r['cases'].append(row);write_record(out,r);begin=time.perf_counter()
 for square in kept:
  if time.perf_counter()-begin>60 or row['reply_frontiers']>=5000:break
  # Board A is a separately declared valid initial context, never a forged
  # historical state passed off as an actual continuation.
  board=list(s.position.board);board[square[1]*9+square[0]]=Piece(0,'P' if target=='TP' else 'G',target,target=='TP')
  bd=replace(base,initial_position=tuple(tuple(board[k:k+9]) for k in range(0,81,9)));bc=compile_ruleset_for_execution(bd);bs=initial_state(bc)
  ba=legal_actions(bs,bc);bn=compile_native_semantic_rules(bc);bm=NativeSemanticPositionMirror.from_state(bc,bn,bs,history_certified=True);assert set(ba)=={public_action(bn,a) for a in guarded_actions(bn,bm.position)}
  A=len({(a.to_square.file,a.to_square.rank) for a in ba if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==square})
  drop=drops[square];child=apply_action(s,drop,c);np=make_checked(nr,mirror.position,mirror.direct_pack(drop,s.position));assert snapshot_matches(snapshot(nr,np),child.position,nr,c)
  nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(child.terminal_status.status.value,child.terminal_status.winner)
  replies=legal_actions(child,c);nas=guarded_actions(nr,np);assert set(replies)=={public_action(nr,a) for a in nas}
  cell=dict(source=list(square),A=A,drop=record_value(drop),terminal=record_value(child.terminal_status),continuations=[]);row['cells'].append(cell)
  for na in nas:
   action=public_action(nr,na);cs=apply_action(child,action,c);cn=make_checked(nr,np,na);assert snapshot_matches(snapshot(nr,cn),cs.position,nr,c)
   nt=terminal_status(nr,cn);assert (nt['status'],nt['winner'])==(cs.terminal_status.status.value,cs.terminal_status.winner)
   acts=legal_actions(cs,c);assert set(acts)=={public_action(nr,a) for a in guarded_actions(nr,cn)}
   piece=cs.position.board[square[1]*9+square[0]];survived=piece is not None and piece.owner==0
   endpoints={(a.to_square.file,a.to_square.rank) for a in acts if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==square}
   cell['continuations'].append(dict(reply=record_value(action),survived=survived,U=len(endpoints),terminal=record_value(cs.terminal_status)));row['reply_frontiers']+=1
  count=len(replies);cell['H']=str(F(sum(x['U'] for x in cell['continuations']),count)) if count else '0';cell['capture_probability']=str(F(sum(not x['survived'] for x in cell['continuations']),count)) if count else '0'
 else:row['complete']=True
 row['seconds']=time.perf_counter()-begin
 if row['complete']:
  n=len(row['cells']);row['mean_A']=str(F(sum(x['A'] for x in row['cells']),n));row['mean_H']=str(sum(F(x['H']) for x in row['cells'])/n);row['mean_capture_probability']=str(sum(F(x['capture_probability']) for x in row['cells'])/n)
 write_record(out,r);print(target,{k:v for k,v in row.items() if k not in ('definition','actual_route','cells')},flush=True)
r.update(complete=all(x['complete'] for x in r['cases']),seconds=time.perf_counter()-start)
if r['complete']:
 gr,pr=r['cases'];assert [x['A'] for x in gr['cells']]==[x['A'] for x in pr['cells']]
 A=F(gr['mean_A']);HG=F(gr['mean_H']);HP=F(pr['mean_H']);p0=F(1,4);delta=F(3,4)
 r['illustrative']=dict(p=str(p0),delta=str(delta),A=str(A),HG=str(HG),HP=str(HP),VG=str(A-p0*delta*HG),VTP=str(A-p0*delta*HP),swingG=str(A+(1-p0)*delta*HG),swingTP=str(A+(1-p0)*delta*HP))
write_record(out,r)
