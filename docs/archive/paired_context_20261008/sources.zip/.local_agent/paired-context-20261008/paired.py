"""Declared paired endpoint-unit approximation; no label fit/default change."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import initial_state
from generic_chess.core.movegen import legal_actions
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror
from generic_chess.native.semantic import guarded_actions,public_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'paired.json';assert not out.exists();start=time.perf_counter()
dep=ROOT/'.local_agent/lifecycle-20261008/deployment-endpoints.json'
raw=json.loads(dep.read_bytes());byname={r['name']:r for r in raw['rows']}
def coord(d):return (d['action']['to_square']['file'],d['action']['to_square']['rank'])
g={coord(d):d for d in byname['G']['drops']};pawn={coord(d):d for d in byname['TP']['drops']}
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(dep.read_bytes()).hexdigest(),declaration='Pair current G and baseP/currentTP on the same source squares in synthetic initial boards ownK7,6 enemyK7,8 ownN4,4, ownturn0, no hands. Sources are common legal actual G/P drops in earlier capture/reply roots, filtered before numerical evaluation to opponent not already in check. A counts distinct own legal endpoints now. H_G/H_P use earlier complete actual drop/uniform enemy reply endpoint counts at exactly those sources. Same endpoint units and common source law, different timing/conditional reply law explicitly retained. No terminal utility, price truth or opening reachability. Construct V_i=A_i-p*delta*H_base and transfer swing A_i+(1-p)*delta*H_base with declared p in0,1/4,1/2,3/4,1 and delta1/2,3/4,1; no human fitting or defaults. Test positivity at aggregate and per-source levels, exact fractions, equal type/current geometry parity. Incremental work140 Core/Native initial action sets at most;30sec checkpoint, no search.',rows=[],excluded=[])
write_record(out,r);base=build_standard_shogi_ruleset()
for square in sorted(g.keys() & pawn.keys()):
 if time.perf_counter()-start>30:break
 ar={};checked=None
 for current in ('G','TP'):
  board=[[None]*9 for _ in range(9)]
  for owner,b,t,f,rank in ((0,'K','K',7,6),(1,'K','K',7,8),(0,'N','N',4,4),(0,'P' if current=='TP' else 'G',current,*square)):
   board[rank][f]=Piece(owner,b,t,t!=b)
  c=compile_ruleset_for_execution(replace(base,initial_position=tuple(tuple(x) for x in board)));s=initial_state(c);engine=semantic_engine_for(c)
  incheck=engine.in_check(s.position,1)
  if checked is None:checked=incheck
  else:assert checked==incheck
  if incheck:continue
  nr=compile_native_semantic_rules(c);mirror=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True)
  actions=legal_actions(s,c);assert set(actions)=={public_action(nr,a) for a in guarded_actions(nr,mirror.position)}
  own=[a for a in actions if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==square]
  ar[current]=len({(a.to_square.file,a.to_square.rank) for a in own})
 if checked:r['excluded'].append(list(square));continue
 assert ar['G']==ar['TP']
 r['rows'].append(dict(source=list(square),A=ar['G'],H_G=g[square]['mean_next_piece_moves'],H_P=pawn[square]['mean_next_piece_moves'],native_equal=True))
else:r['complete']=True
if r['complete']:
 n=len(r['rows']);A=F(sum(x['A'] for x in r['rows']),n);HG=sum(F(x['H_G']) for x in r['rows'])/n;HP=sum(F(x['H_P']) for x in r['rows'])/n
 r['means']=dict(A=str(A),H_G=str(HG),H_P=str(HP),n=n)
 r['family']=[]
 for delta in (F(1,2),F(3,4),F(1)):
  for hazard in (F(0),F(1,4),F(1,2),F(3,4),F(1)):
   row=dict(delta=str(delta),hazard=str(hazard),V_G=str(A-hazard*delta*HG),V_TP=str(A-hazard*delta*HP),swing_G=str(A+(1-hazard)*delta*HG),swing_TP=str(A+(1-hazard)*delta*HP))
   row['pointwise_negative']={b:sum(F(x['A'])-hazard*delta*F(x['H_'+b])<0 for x in r['rows']) for b in ('G','P')};r['family'].append(row)
 r['aggregate_positive_all']=all(F(x['V_G'])>0 and F(x['V_TP'])>0 for x in r['family'])
r['seconds']=time.perf_counter()-start;write_record(out,r);print({k:v for k,v in r.items() if k not in ('rows','declaration','family')});print(r.get('family'))
