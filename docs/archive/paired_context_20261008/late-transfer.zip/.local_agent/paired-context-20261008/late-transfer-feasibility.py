"""Bounded structural preflight for a different transfer-time observable."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,legal_successors
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'joint-context.json';a=json.loads(src.read_bytes());b=json.loads((p/'rook-pressure.json').read_bytes());out=p/'late-transfer-feasibility.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='Core-only structural preflight, no service/price estimate. Original and changed contexts G/TP. Enumerate noncapturing own first move, every enemy reply, then own third-ply captures of the still-living tagged enemy baseG/P. Unique enemy base tag apart from K/R; track actual moved target square. Bounds30sec/10000thirdply actions, no outcome-based extension. Purpose: establish late transfer support and near-frontier cost before declaring a fixed-total-horizon joint service experiment. Prior first-ply zero paths do not mean no later transfer.',rows=[])
for source,context in ((b,'K0,0'),(a,'K0,1')):
 for case in source['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));s=initial_state(c);tid='G' if case['target']=='G' else 'P'
  def target(state):return [(i%9,i//9) for i,piece in enumerate(state.position.board) if piece is not None and piece.owner==1 and piece.base_type_id==tid]
  row=dict(context=context,target=case['target'],noncapture_first=0,second_frontiers=0,third_actions=0,third_capture_paths=0,witness=None);r['rows'].append(row)
  for first,child in legal_successors(s,c):
   if not target(child):continue
   row['noncapture_first']+=1
   for second,later in legal_successors(child,c):
    row['second_frontiers']+=1;ts=target(later)
    if not ts:continue
    assert len(ts)==1
    for third,end in legal_successors(later,c):
     row['third_actions']+=1;assert row['third_actions']<=10000 and time.perf_counter()-start<30
     if not target(end):
      row['third_capture_paths']+=1
      if row['witness'] is None:row['witness']=record_value((first,second,third))
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print([(x['context'],x['target'],x['third_actions'],x['third_capture_paths']) for x in r['rows']],r['seconds'])
