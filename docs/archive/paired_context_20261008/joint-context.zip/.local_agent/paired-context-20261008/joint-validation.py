import sys,json,hashlib
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'joint-context.json';raw=json.loads(src.read_bytes());assert raw['complete'];old=json.loads((p/'rook-pressure.json').read_bytes());rows=[]
for case in raw['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));s=initial_state(c);nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True)
 acts=guarded_actions(nr,m.position);assert {public_action(nr,a) for a in acts}==set(legal_actions(s,c));assert len(acts)==7
 enc=next(x['actual_route'][0] for x in old['cases'] if x['target']==case['target']);na,=[a for a in acts if record_value(public_action(nr,a))==enc]
 child=apply_action(s,public_action(nr,na),c);np=make_checked(nr,m.position,na);assert snapshot_matches(snapshot(nr,np),child.position,nr,c)
 nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(child.terminal_status.status.value,child.terminal_status.winner)
 j=case['joint_comparison'];cov=(F(j['original_p'])-F(j['changed_p']))*(F(j['original_H'])-F(j['changed_H']))/4;assert cov==F(j['difference'])
 rows.append(dict(target=case['target'],initial_actions_native_core_equal=True,capture_transition_native_core_equal=True,exact_two_context_covariance=str(cov),comparison=j,reply_frontiers=case['reply_frontiers']))
out=p/'joint-validation.json';assert not out.exists();write_record(out,dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),scope='Independent initial legal-set and actual capture replay supplement; exact two-context covariance identity. Only first-ply transfer service through ply4, not all first-transfer times.',rows=rows))
print([(x['target'],x['comparison']['relative_error'],x['reply_frontiers']) for x in rows])
