"""Changed context, same fixed policies/horizon; no parameter selection."""
import sys,json,time,hashlib,copy
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action,legal_successors
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=p/'recipient-census.json';dep=p/'rook-pressure.json';out=p/'joint-context.json';assert not out.exists();start=time.perf_counter()
base=json.loads(dep.read_bytes());prior=json.loads(old.read_bytes());assert prior['complete']
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ('rook-pressure.json','recipient-census.json')},declaration='Predeclared two-context uniform mixture: original ownK0,0 and changed ownK0,1; other five-entity rule/positions unchanged. Uniform initial own legal action; measure the first-ply Ncapture transfer indicator only (other initial actions contribute zero, even if later captures could occur). Then uniform real enemy reply, uniform legal recipient drop, uniform real enemy reply. Total4ply horizon, terminal/no-drop activity0 with terminal separate. Compare E_context[p_c H_c] joint event-service against E_context[p_c] E_context[H_c]. H_c is conditional transfer service with same horizon. This tests context covariance at one fixed transfer time, NOT a full first-transfer-at-any-time process, not material utility. Context choice independent of values; no label fitting/defaults. Reuse original complete census; changed context exhaustive Core/Native parity. Each first-reply cell60sec/5000frontiers, whole300sec checkpoint; bounded single process. Avoid rewriting growing JSON each cell; preserve full partial on checkpoint/failure. Decision: if joint differs, keep context conditioning rather than independent averaged factors.',cases=[])
def parity(c,nr,s,np):
 assert snapshot_matches(snapshot(nr,np),s.position,nr,c)
 nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner)
 assert set(legal_actions(s,c))=={public_action(nr,a) for a in guarded_actions(nr,np)}
try:
 for original in base['cases']:
  definition=copy.deepcopy(original['definition']);definition['initial_position'][1][0]=definition['initial_position'][0][0];definition['initial_position'][0][0]=None
  c=compile_ruleset_for_execution(ruleset_from_dict(definition));s=initial_state(c);enc=original['actual_route'][0];acts=legal_actions(s,c);caps=[a for a in acts if record_value(a)==enc];assert len(caps)==1
  case=dict(target=original['target'],definition=definition,p=str(F(1,len(acts))),initial_actions=len(acts),rows=[],complete=False,reply_frontiers=0);r['cases'].append(case)
  s=apply_action(s,caps[0],c);nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True);parity(c,nr,s,m.position)
  firsts=guarded_actions(nr,m.position)
  for na in firsts:
   begin=time.perf_counter();assert begin-start<300,'whole checkpoint'
   first=public_action(nr,na);own=apply_action(s,first,c);np=make_checked(nr,m.position,na);parity(c,nr,own,np)
   row=dict(first_reply=record_value(first),terminal=record_value(own.terminal_status),drops=[],reply_frontiers=0);case['rows'].append(row)
   for drop,child in ((a,ch) for a,ch in legal_successors(own,c) if hasattr(a,'base_type_id')):
    assert time.perf_counter()-begin<60 and row['reply_frontiers']<5000,'cell checkpoint'
    dm=NativeSemanticPositionMirror.from_state(c,nr,own,history_certified=True);cp=make_checked(nr,np,dm.direct_pack(drop,own.position));parity(c,nr,child,cp)
    replies=dict(legal_successors(child,c));continued=[]
    for rn in guarded_actions(nr,cp):
     reply=public_action(nr,rn);cs=replies[reply];rp=make_checked(nr,cp,rn);parity(c,nr,cs,rp)
     U=len({(a.to_square.file,a.to_square.rank) for a in legal_actions(cs,c) if hasattr(a,'from_square') and a.from_square==drop.to_square})
     continued.append(dict(reply=record_value(reply),U=U,terminal=record_value(cs.terminal_status)));row['reply_frontiers']+=1
    row['drops'].append(dict(drop=record_value(drop),terminal=record_value(child.terminal_status),replies=continued,H=str(F(sum(x['U'] for x in continued),len(continued))) if continued else '0'))
   row['H']=str(sum(F(x['H']) for x in row['drops'])/len(row['drops'])) if row['drops'] else '0';case['reply_frontiers']+=row['reply_frontiers']
   print(case['target'],len(case['rows']),len(firsts),row['reply_frontiers'],round(time.perf_counter()-begin,3),flush=True)
  case['H']=str(sum(F(row['H']) for row in case['rows'])/len(firsts)) if firsts else '0';case['complete']=True
  oldcase=next(x for x in prior['cases'] if x['target']==case['target']);pa=F(1,5);pb=F(case['p']);ha=F(oldcase['H']);hb=F(case['H'])
  joint=(pa*ha+pb*hb)/2;factor=((pa+pb)/2)*((ha+hb)/2)
  case['joint_comparison']=dict(original_p=str(pa),original_H=str(ha),changed_p=str(pb),changed_H=str(hb),joint=str(joint),factorized=str(factor),difference=str(joint-factor),joint_decimal=float(joint),factorized_decimal=float(factor),relative_error=float((factor-joint)/joint) if joint else None)
 r['complete']=True
finally:
 r['seconds']=time.perf_counter()-start;write_record(out,r)
print([(x['target'],x.get('joint_comparison')) for x in r['cases']],r['seconds'])
