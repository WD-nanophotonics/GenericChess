from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/check-only-20261016';S=P/'tt';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;spec=importlib.util.spec_from_file_location('tt_control_check_only._native_core',P/'check_only_native_core.pyd');pilot=importlib.util.module_from_spec(spec);spec.loader.exec_module(pilot)
plan=json.loads((S/'plan.json').read_bytes());cp=dict(question='Does the existingTT16 preserve jointly completed scores on all prospective four-cell roots?',inputs=plan['inputs'],cells=plan['cells'],orders=[['A','B','C','D'],['D','C','B','A']],depth=3,nodes=65536,seconds=6,whole_seconds=240,expected_seconds=60,max_queries=48,decision='Any complete same-objective TTscore mismatch blocks finite method attribution pending diagnosis; equal scores and changed costs alone are not finite benefit. Retain all censors/order differences.')
a.write_record(S/'control-plan.json',cp);rows=[];start=time.perf_counter()
for case in cp['inputs']:
 d=json.loads((S/'roots'/f"{case['seed']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={0:a.nc.compile_native_semantic_rules(c,backend_module=p.m),1:a.nc.compile_native_semantic_rules(c,backend_module=pilot)}
 for order,names in enumerate(cp['orders']):
  for name in names:
   p.stopped();cell=cp['cells'][name];q=int(cell['objective']=='check_only')
   if time.perf_counter()-start>=240:rows.append(dict(**case,order=order,cell=name,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
   t=time.perf_counter();r=a.SemanticSearchEngine(c,nrs[q],board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=cell['tt_megabytes'],ordering_cache_enabled=False).search(s,a.SearchLimits(max_depth=3,max_nodes=65536,max_time_seconds=6,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True)
   rows.append(dict(**case,order=order,cell=name,kind='ACTUAL_QUERY',result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nrs[q],r)))
   print(case['seed'],order,name,r.completed_depth,r.termination_reason,flush=True)
pairs=[]
for case in cp['inputs']:
 for order in (0,1):
  by={r['cell']:r['result']for r in rows if r['seed']==case['seed']and r['order']==order and'result'in r}
  for x,y in [('A','C'),('B','D')]:
   if x in by and y in by:
    complete=by[x]['completed_depth']==by[y]['completed_depth']==3
    pairs.append(dict(seed=case['seed'],order=order,cells=[x,y],joint_complete=complete,score_equal=by[x]['score']==by[y]['score']if complete else None,action_equal=by[x]['action']==by[y]['action']))
a.write_record(S/'control-results.json',dict(complete=True,rows=rows,pairs=pairs,seconds=time.perf_counter()-start));print('TT_CONTROL_CLOSED',len(rows),sum(x['joint_complete']for x in pairs),[x for x in pairs if x['score_equal']is False],flush=True)
