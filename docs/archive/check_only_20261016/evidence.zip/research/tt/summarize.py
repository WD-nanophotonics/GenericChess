from pathlib import Path
import json,random,statistics,collections
P=Path(__file__).resolve().parent;done=json.loads((P/'completion.json').read_bytes());plan=json.loads((P/'plan.json').read_bytes());assert done['complete']and len(done['games'])==42;by={(g['seed'],g['mode']):g for g in done['games']}
def cat(g,role):
 if 'result'not in g or g['result']['status']=='ongoing':return 'UNKNOWN'
 w=g['result']['winner'];return 'DRAW'if w is None else'WIN'if w==role else'LOSS'
value={'WIN':1,'LOSS':-1,'DRAW':0,'UNKNOWN':0};roles=[];families=[];counts={cell:collections.Counter()for cell in 'ABCD'}
for case in plan['inputs']:
 seed=case['seed'];fr=[]
 for role in(0,1):
  cats={cell:cat(by[(seed,'A_control'if cell=='A'else cell+'_role'+str(role))],role)for cell in 'ABCD'}
  vals={cell:value[v]for cell,v in cats.items()}
  contrasts=dict(B_A=vals['B']-vals['A'],C_A=vals['C']-vals['A'],D_A=vals['D']-vals['A'],D_C=vals['D']-vals['C'],interaction=(vals['D']-vals['C'])-(vals['B']-vals['A']))
  for cell,v in cats.items():counts[cell][v]+=1
  row=dict(**case,role=role,categories=cats,contrasts=contrasts);roles.append(row);fr.append(row)
 families.append(dict(**case,contrasts={key:sum(r['contrasts'][key]for r in fr)/2 for key in fr[0]['contrasts']}))
rng=random.Random(202610160901);samples={k:[]for k in families[0]['contrasts']}
for _ in range(10000):
 draw=[]
 for n in(8,12,16):draw.extend(rng.choices([f for f in families if f['n']==n],k=2))
 for k in samples:samples[k].append(statistics.mean(f['contrasts'][k]for f in draw))
contrasts={k:dict(net=sum(r['contrasts'][k]for r in roles),mean=statistics.mean(r['contrasts'][k]for r in roles),family_stratified_bootstrap95=[sorted(v)[249],sorted(v)[9749]])for k,v in samples.items()}
games=[g for g in done['games']if'result'in g];cost={cell:dict(game_seconds=0,candidate_call_seconds=0,opponent_call_seconds=0,queries=0,nodes=0,qnodes=0,tt_hits=0,tt_cutoffs=0)for cell in 'ABCD'};terminations=collections.Counter();refusals=[];transitions={}
for pair in[('A','B'),('A','C'),('C','D')]:transitions['->'.join(pair)]=dict(collections.Counter(r['categories'][pair[0]]+'->'+r['categories'][pair[1]]for r in roles))
for g in games:
 cell=g['mode'][0];x=json.loads((P/f"game-{g['seed']}-{g['mode']}.json").read_bytes());cost[cell]['game_seconds']+=g['seconds']
 for row in x['rows']:
  if not row['execution_allowed']:refusals.append(dict(seed=g['seed'],mode=g['mode'],ply=row['ply'],owner=row['owner'],caller_seconds=row['caller_seconds']))
  cost[cell]['candidate_call_seconds'if cell!='A'and row['actor']==int(g['mode'][-1])else'opponent_call_seconds']+=row['actual_call_seconds']
  for ph in row['phases']:
   r=ph['result'];cost[cell]['queries']+=1
   for key in('nodes','qnodes','tt_hits','tt_cutoffs'):cost[cell][key]+=r[key]
   terminations[row['owner']+':'+r['termination_reason']]+=1
out=dict(complete=True,planned_slots=42,actual_physical_games=len(games),missing=[g for g in done['games']if'result'not in g],cells={k:dict(v)for k,v in counts.items()},contrasts=contrasts,roles=roles,families=families,transitions=transitions,cost=cost,termination=dict(terminations),refusals=refusals,physical_edges=sum(g.get('edges',0)for g in games),batch_seconds=done['seconds'],scope='Six paired families/two perboard, each bothroles clustered. UNKNOWN kept distinct; code0 is only finite statistic, never inferred draw/WDL. Ordinary10000fixed-seed stratified bootstrap is exploratory, not sequential/population guarantee. FixedA opponent; percall engine/TT reset, requested16MiB/actual11MiB. Game-time sums exclude finalfullJSON/summary/init; wholebatch includes these, preparation separate.')
(P/'summary.json').write_bytes(json.dumps(out,indent=2).encode());print('TT_SUMMARY',{k:v for k,v in out.items()if k not in('roles','families','refusals')},flush=True)
