"""Build a private explicit-backend image; never replace the normal extension."""
from pathlib import Path
import sys,sysconfig,subprocess,time,json
R=Path.cwd();P=Path(__file__).resolve().parent;S=P/'source'
out=P/'check_only_native_core.pyd'
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in S.glob('*.c')],'-o',str(out)]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
print('BUILD',r.returncode,time.perf_counter()-t,r.stderr[-1000:]);sys.exit(r.returncode)
