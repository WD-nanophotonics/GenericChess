from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/check-only-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
import test_runtime_aux_identity as f
from test_qsearch_semantic_effects import transform_rules
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.serialization import serialize_game_record
a=p.a;captured=[];old=f.compile_semantic_ruleset
def capture(r):
 captured.append(r);return old(r)
f.compile_semantic_ruleset=capture;c=f._compiled()
actual=json.loads((P/'aux-results.json').read_bytes());actual['root']['ruleset']=json.loads(serialize_ruleset(captured[0]))
assert c.ruleset_fingerprint==actual['root']['game_record']['ruleset_fingerprint']
a.write_record(P/'aux-results.json',actual)
(P/'control-roots').mkdir(exist_ok=True)
for kind in ('transform','nochange','balanced'):
 rs=transform_rules(kind,encoding='effect');c=compile_ruleset_for_execution(rs);s=a.GameSession(c)
 a.write_record(P/'control-roots'/f'{kind}.json',dict(ruleset=json.loads(serialize_ruleset(rs)),game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s),board_values={'K':0,'A':100,'B':900},hand_values={'K':0,'A':100,'B':900}))
print('ROOT_SOURCE_EXPORTED',len(captured),3)
