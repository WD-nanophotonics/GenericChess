from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/check-only-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from test_runtime_aux_identity import _compiled
from generic_chess.core.actions import SemanticBoardMove
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
a=p.a;spec=importlib.util.spec_from_file_location('aux_check_only._native_core',P/'check_only_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=_compiled();s=a.GameSession(c);ac=next(ac for ac in s.legal_actions()if isinstance(ac,SemanticBoardMove)and ac.pattern_id.startswith('sem_'));s.submit(ac)
root=dict(state=a.record_value(s.state),game_record=json.loads(serialize_game_record(s.to_record())),before_sha256=p.digest(s),ir=a.record_value(c.ir),support=a.record_value(c.support),legacy_metadata=False)
assert s.state.position.aux_state and len(s.state.history)==2
rows=[]
for name,mod,q in [('disabled_q0',p.m,0),('check_only',m,1),('ordinary_q1',p.m,1)]:
 nr=a.nc.compile_native_semantic_rules(c,backend_module=mod);np=a.pack_semantic_search_position(c,nr,s);snap=a.sem.snapshot(nr,np)
 for key in ('board','hands','aux_state','side'):assert a.record_value(snap[key])==a.record_value(a.expected_snapshot(s.state.position,nr,c)[key])
 assert {a.pack_semantic_action(nr,s.state.position,ac)for ac in s.legal_actions()}==set(a.sem.guarded_actions(nr,np))
 t=time.perf_counter();r=a.SemanticSearchEngine(c,nr,board_values={'K':0,'A':100},hand_values={'K':0,'A':100},tt_megabytes=0,ordering_cache_enabled=False).search(s,a.SearchLimits(max_depth=3,max_nodes=65536,max_time_seconds=3,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True)
 rows.append(dict(arm=name,result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r),root_snapshot=a.record_value(snap)))
 assert p.digest(s)==root['before_sha256']
a.write_record(P/'aux-results.json',dict(question='Does persistent auxiliary state plus exact event history survive Native search admission and PV replay with no legacy metadata adapter?',root=root,rows=rows,scope='Existing hand-written pure semantic persistent bool fixture; not all generated domains. No loss of promotion/drop/aux/history target. Unitmaterial chosen explicitly, not price inference.'))
print('AUX_CLOSED',[(r['arm'],r['result']['completed_depth'],r['pv_edges'])for r in rows])
