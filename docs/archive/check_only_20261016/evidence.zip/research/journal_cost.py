from pathlib import Path
import json,time,os,hashlib,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
P=Path(__file__).resolve().parent;F=P/'finite';x=json.loads((F/'game-8811-check_role1.json').read_bytes());rows=x['rows']
plan=dict(question='Can a single append-only exact-row research journal remove measured full-prefix recording cost without dropping ANY result field?',basis=dict(game_seconds=x['seconds'],caller_seconds=sum(r['actual_call_seconds']for r in rows),physical_audit_seconds=sum(r['physical_audit_seconds']for r in rows),full_json_bytes=(F/'game-8811-check_role1.json').stat().st_size),cases='One already-closed64-edge game, all64prefixes; two orders rewrite/append vsappend/rewrite. No search/game/default change or frozen producer mutation.',whole_seconds=180,expected_seconds=70,decision='Only adopt for FUTURE research recording if exact roundtrip and measured cost benefit. Current producer remains frozen. No diagnostics API, result-field omission or framework.')
write_record(P/'journal-plan.json',plan);start=time.perf_counter();receipts=[]
for order,names in enumerate([['rewrite','append'],['append','rewrite']]):
 for mode in names:
  t=time.perf_counter();f=P/f'journal-owned-{order}-{mode}.json';totalbytes=0
  if mode=='rewrite':
   for i in range(1,len(rows)+1):
    d=dict(complete=False,case=x['case'],mode=x['mode'],rows=rows[:i],seconds=0);write_record(f,d);totalbytes+=f.stat().st_size
   back=json.loads(f.read_bytes())['rows']
  else:
   with f.open('w',encoding='utf-8',newline='\n')as out:
    for row in rows:
     body=json.dumps(row,allow_nan=False)+'\n';out.write(body);out.flush();os.fsync(out.fileno());totalbytes+=len(body.encode())
   back=[json.loads(line)for line in f.read_text().splitlines()]
  assert back==rows
  receipts.append(dict(order=order,mode=mode,seconds=time.perf_counter()-t,bytes_written=totalbytes,records=len(back),lossless=True,source_rows_sha256=hashlib.sha256(json.dumps(back,sort_keys=True).encode()).hexdigest()))
  # These are redundant benchmark copies only; the actual original remains intact.
  f.unlink()
  print('JOURNAL',receipts[-1],flush=True)
write_record(P/'journal-results.json',dict(complete=True,rows=receipts,seconds=time.perf_counter()-start,scope='Actual same-host disk/serialization measurement of duplicate scientific recording only. No Native search/game/policy reexecution. fsync each append retained; complete row dictionaries including every result/feature field preserved. Current frozen game producer unchanged.'))
