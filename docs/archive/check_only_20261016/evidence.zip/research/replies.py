from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/'.local_agent/check-only-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;triad=json.loads((P/'results.json').read_bytes());pairs=[]
for row in triad['rows']:
 if row['order']==0:
  pairs.append(dict(root_id=row['root_id'],arm=row['arm'],action=row['result']['action']))
plan=dict(question='Do the changed full-depth check-only or ordinaryq1 choices have a literal winning reply at the exposed parents?',cases=pairs,scope='ALL39selected actions, deduplicate identical root/action at execution. Two-second existing literal reply cap, retainUNKNOWN; not all-defense/deeperWDL or outcome filter.',whole_seconds=120,expected_seconds=25)
a.write_record(P/'reply-plan.json',plan);start=time.perf_counter();rows=[];cache={}
for case in pairs:
 p.stopped();key=case['root_id']+':'+json.dumps(case['action'],sort_keys=True)
 if key not in cache:
  d=json.loads((P/'roots'/f"{case['root_id']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));ac=next(x for x in s.legal_actions()if a.record_value(x)==case['action'])
  if time.perf_counter()-start>=120:cache[key]=dict(kind='NOT_STARTED_WHOLE_CAP_UNKNOWN')
  else:cache[key]=a.diagnosis(s,ac)
 rows.append(dict(**case,diagnostic_key=key))
a.write_record(P/'reply-results.json',dict(complete=True,rows=rows,diagnostics=cache,seconds=time.perf_counter()-start));print('LITERAL_CLOSED',len(rows),len(cache),{k:sum(d['kind']==k for d in cache.values())for k in set(d['kind']for d in cache.values())},time.perf_counter()-start,flush=True)
