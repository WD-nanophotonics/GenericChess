from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/check-only-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;spec=importlib.util.spec_from_file_location('key_policy._native_core',P/'key_policy_native_core.pyd');pilot=importlib.util.module_from_spec(spec);spec.loader.exec_module(pilot);mask=(1<<64)-1
def mix(x):
 x=(x^(x>>30))*0xBF58476D1CE4E5B9&mask;x=(x^(x>>27))*0x94D049BB133111EB&mask;return x^(x>>31)
def step(parent,digest,actor,check,index):
 event=(actor<<8)|int(check)
 return [mix(((parent[i]^digest[i]^event^(index*0x9E3779B97F4A7C15&mask)^((i+1)*0xD6E8FEB86659FD93&mask))+parent[(i+1)&3])&mask)for i in range(4)]
def seed(history,events):
 out=[0]*4
 for i,(d,e)in enumerate(zip(history,events)):out=step(out,d,e[0],e[1],i)
 return out
def tag(out,mode):
 out=list(out)
 if mode:out[0]^=0x726f6f742d657861;out[1]^=0x63742d6465707468
 return out
plan=dict(question='Does PRIVATE lookup-only exact-root q0 domain tagging restore adjacent-root reuse at unchanged finite scores/actions/PV?',parents=list(range(13)),modes=[True,False],queries=['cold_parent','warm_same_parent','warm_adjacent','fresh_adjacent'],depth=3,nodes=65536,seconds=6,whole_seconds=300,expected_seconds=50,max_queries=104,scope='ALL13 exposed roots; normalq0/TT16 only, two recordedPV moves to adjacent same-side root. No source/default change or AUXbank. Legacy false and exact true have different search contracts, so compare warm/fresh WITHIN mode only. PRIVATE source reconstructs lookup context after full history folding, rather than original tag-then-fold. Actual baseline is frozen warm-results.json; time is separate-run descriptive, work and complete finite score/action/PV comparisons decide feasibility. No product adoption.')
a.write_record(P/'key-policy-control-plan.json',plan);rows=[];start=time.perf_counter()
for i in plan['parents']:
 for mode in plan['modes']:
  p.stopped()
  d=json.loads((P/'roots'/f'node-{i}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=a.nc.compile_native_semantic_rules(c,backend_module=pilot)
  def engine():return a.SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=16,ordering_cache_enabled=False)
  def query(e,s,label):
   if time.perf_counter()-start>=300:return None
   t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=3,max_nodes=65536,max_time_seconds=6,quiescence_max_depth=0),root_window_pruning=mode)
   rows.append(dict(root=i,exact_root=mode,phase=label,result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r)));return r
  e=engine();r=query(e,s,'cold_parent');same=query(e,s,'warm_same_parent')
  if r is None or len(r.principal_variation)<2:continue
  oldsnap=a.sem.snapshot(nr,a.pack_semantic_search_position(c,nr,s));moves=list(r.principal_variation[:2])
  for ac in moves:
   if s.result.status.value!='ongoing':break
   s.submit(ac)
  if s.result.status.value!='ongoing':continue
  snap=a.sem.snapshot(nr,a.pack_semantic_search_position(c,nr,s));hist=snap['history'];events=snap['history_events'];oldlen=len(oldsnap['history']);inherited=seed(oldsnap['history'],oldsnap['history_events'])
  for j in range(oldlen,len(hist)):inherited=step(inherited,hist[j],events[j][0],events[j][1],j)
  inherited=tag(inherited,mode);reseeded=tag(seed(hist,events),mode)
  rid=f'keywarm-{i}-{int(mode)}';a.write_record(P/'roots'/f'{rid}.json',dict(ruleset=d['ruleset'],game_record=json.loads(__import__('generic_chess.session.serialization',fromlist=['serialize_game_record']).serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s),board_values=d['board_values'],hand_values=d['hand_values']))
  warm=query(e,s,'warm_adjacent');fresh=query(engine(),s,'fresh_adjacent')
  for row in rows:
   if row['root']==i and row['exact_root']==mode and row['phase'].endswith('adjacent'):row.update(root_id=rid,inherited_context=inherited,reseeded_context=reseeded,source_context_equal=inherited==reseeded)
  print('WARM',i,mode,inherited==reseeded,None if warm is None else warm.nodes,None if fresh is None else fresh.nodes,flush=True)
a.write_record(P/'key-policy-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('WARM_CLOSED',len(rows),time.perf_counter()-start,flush=True)
