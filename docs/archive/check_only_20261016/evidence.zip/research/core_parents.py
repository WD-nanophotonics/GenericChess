from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/'.local_agent/check-only-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
a=p.a
class Material:
 def __init__(self,bv,hv):self.bv=bv;self.hv=hv
 def evaluate(self,s):
  side=s.position.side_to_move
  return sum((1 if x.owner==side else -1)*self.bv[x.current_type_id]for x in s.position.board if x is not None)+sum((1 if owner==side else -1)*self.hv[t]*n for owner,hand in enumerate(s.position.hands)for t,n in hand.items())
 def type_value(self,t):return self.bv[t]
 def capture_order_value(self,m,c):return 10*self.bv[c.current_type_id]-self.bv[m.current_type_id]
plan=dict(question='Do actual exposed mixed/promotion/drop/history roots retain finite-score agreement under all-Core check-only, beyond handwritten fixtures?',parents=list(range(13)),depths=[1,2],seconds=5,nodes=65536,whole_seconds=180,expected_seconds=100,scope='ALL13already-exposed parents; same static prices. Core fulllegal path, TT/order/native-legality disabled. Record every timeout/missing; no censors replaced or exact WDL claim.')
a.write_record(P/'core-parent-plan.json',plan);pilot=json.loads((P/'results.json').read_bytes());start=time.perf_counter();rows=[]
for i in plan['parents']:
 d=json.loads((P/'roots'/f'node-{i}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));before=p.digest(s)
 for depth in plan['depths']:
  p.stopped()
  if time.perf_counter()-start>=180:rows.append(dict(root=i,depth=depth,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
  t=time.perf_counter();r=AlphaBetaPlayer(c,evaluator_override=Material(d['board_values'],d['hand_values']),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False,use_check_only_qsearch=True)).choose_action(s,a.SearchLimits(max_depth=depth,max_nodes=65536,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=8))
  row=dict(root=i,depth=depth,result=a.record_value(r),seconds=time.perf_counter()-t,root_restored=p.digest(s)==before,kind='ACTUAL_QUERY')
  # Saved triadD3score is NOT directly compared toD1/D2. Separate matching Native queries below.
  rows.append(row);print(i,depth,r.completed_depth,round(row['seconds'],3),flush=True)
 a.write_record(P/'core-parent-partial.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start))
a.write_record(P/'core-parent-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('CORE_PARENTS_CLOSED',len(rows),time.perf_counter()-start,flush=True)
