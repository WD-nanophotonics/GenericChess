from pathlib import Path
import sys,json,time,importlib.util,threading
R=Path.cwd();P=R/'.local_agent/check-only-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from test_native_semantic_qsearch import fixture,Material,normalize
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
a=p.a;spec=importlib.util.spec_from_file_location('diff_check_only._native_core',P/'check_only_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=dict(question='Does the one-line forced-evasion objective agree with existing all-Core check-only search on real semantic effect fixtures?',cases=['transform','nochange','balanced'],depths=[1,2,3],seconds=5,nodes=65536,whole_seconds=120,expected_seconds=20,decision='A complete-score mismatch rejects qualification and prompts source diagnosis, not silent legacy conversion. Equal scores do not prove all-domain equivalence or identical tie selection.')
a.write_record(P/'differential-plan.json',plan);start=time.perf_counter();rows=[]
for kind in plan['cases']:
 s=fixture(kind);nr=a.nc.compile_native_semantic_rules(s.compiled,backend_module=m)
 for depth in plan['depths']:
  p.stopped()
  if time.perf_counter()-start>=120:raise TimeoutError('whole120')
  before=p.digest(s);lim=a.SearchLimits(max_depth=depth,max_nodes=65536,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=8)
  t=time.perf_counter()
  core=AlphaBetaPlayer(s.compiled,evaluator_override=Material(),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False,use_check_only_qsearch=True)).choose_action(s,lim)
  coretime=time.perf_counter()-t;t=time.perf_counter()
  nat=a.SemanticSearchEngine(s.compiled,nr,board_values=Material.values,hand_values=Material.values,tt_megabytes=0,ordering_cache_enabled=False).search(s,a.SearchLimits(max_depth=depth,max_nodes=65536,max_time_seconds=5,quiescence_max_depth=1,quiescence_hard_max_depth=8),root_window_pruning=True)
  row=dict(case=kind,depth=depth,core=a.record_value(core),native=a.record_value(nat),core_seconds=coretime,native_seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,nat),root_restored=p.digest(s)==before)
  row['joint_complete']=core.completed_depth==nat.completed_depth==depth
  row['score_equal']=core.score==normalize(nat.score) if row['joint_complete']else None
  rows.append(row);a.write_record(P/'differential-partial.json',dict(complete=False,rows=rows))
  print(kind,depth,core.completed_depth,nat.completed_depth,row['score_equal'],flush=True)
# Real mid-search cancellation on first two frozen historical roots. No instruction-exact claim.
cancel=[]
from generic_chess.session.serialization import deserialize_game_record
for i in (0,1):
 d=json.loads((P/'roots'/f'node-{i}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=a.nc.compile_native_semantic_rules(c,backend_module=m);before=p.digest(s);token=a.CancellationToken();timer=threading.Timer(.02,token.cancel);timer.start()
 try:r=a.SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False).search(s,a.SearchLimits(max_depth=16,max_nodes=1000000,max_time_seconds=1,quiescence_max_depth=1,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True)
 finally:timer.cancel();timer.join()
 assert p.digest(s)==before;cancel.append(dict(root=i,result=a.record_value(r),cancelled=token.is_cancelled(),root_restored=True,pv_edges=a.audit(s,nr,r)))
a.write_record(P/'differential-results.json',dict(complete=True,rows=rows,actual_timer_cancellations=cancel,seconds=time.perf_counter()-start,scope='All-Core finite objective differential with existing semantic-effect fixtures, same evaluator. Native terminal scale normalized only. Shared Core rule/compiler; not independent game/WDL proof or all-domain equivalence.'))
print('DIFFERENTIAL_CLOSED',len(rows),flush=True)
