from pathlib import Path
import sys,json,time,importlib.util,os
R=Path.cwd();P=R/'.local_agent/check-only-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
a=p.a;spec=importlib.util.spec_from_file_location('matched_key._native_core',P/'key_policy_native_core.pyd');pilot=importlib.util.module_from_spec(spec);spec.loader.exec_module(pilot);mods=dict(normal=p.m,key_policy=pilot)
plan=dict(question='With matched remaining depth D4parent->D2 after twoPVmoves, does lookup-only q0 tagging avoid meaningful subtree work instead of merely reusing cheap leaves?',changed_premise='Previous D3->D3 objective had only shallow parent entries at child; restored hits did not reduce nodes13/13. Here equal remaining finite depths can supply nonleaf subtrees, which would change whether any further qualification is worth cost.',parents=list(range(13)),orders=[['normal','key_policy'],['key_policy','normal']],phases=['parentD4','warm_childD2','fresh_childD2'],nodes=1000000,seconds=3,whole_seconds=300,expected_seconds=60,max_queries=156,scope='Exposed q0 exact-root/TT16 only. No games/default/API changes. Keep all censors/terminal tails, no privateimage product adoption.',decision='Only substantial saved work/caller cost at jointly complete identical scores/actions/PV justifies later broader qualification; extra hits alone reject. No unchanged rerun or all-domain claim.')
a.write_record(P/'matched-plan.json',plan);rows=[];start=time.perf_counter();journal=P/'matched-rows.jsonl';journal.open('x').close();(P/'matched-roots').mkdir(exist_ok=True)
for i in plan['parents']:
 for order,names in enumerate(plan['orders']):
  for name in names:
   p.stopped();d=json.loads((P/'roots'/f'node-{i}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=a.nc.compile_native_semantic_rules(c,backend_module=mods[name])
   def engine():return a.SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=16,ordering_cache_enabled=False)
   def query(e,depth,phase,root):
    if time.perf_counter()-start>=300:row=dict(root=i,order=order,arm=name,phase=phase,root_id=root,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN');r=None
    else:
     t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=depth,max_nodes=1000000,max_time_seconds=3,quiescence_max_depth=0),root_window_pruning=True)
     row=dict(root=i,order=order,arm=name,phase=phase,root_id=root,kind='ACTUAL_QUERY',result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r))
    rows.append(row)
    with journal.open('a',encoding='utf-8',newline='\n')as f:f.write(json.dumps(row,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
    return r
   e=engine();r=query(e,4,'parentD4','node-'+str(i));rid=f'matched-{i}-{order}-{name}'
   if r is None or len(r.principal_variation)<2:continue
   for ac in r.principal_variation[:2]:
    if s.result.status.value!='ongoing':break
    s.submit(ac)
   a.write_record(P/'matched-roots'/f'{rid}.json',dict(ruleset=d['ruleset'],game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s),board_values=d['board_values'],hand_values=d['hand_values']))
   if s.result.status.value!='ongoing':
    rows.extend([dict(root=i,order=order,arm=name,phase=ph,root_id=rid,kind='ACTUAL_TERMINAL_TAIL_NO_SEARCH')for ph in plan['phases'][1:]]);continue
   warm=query(e,2,'warm_childD2',rid);fresh=query(engine(),2,'fresh_childD2',rid)
   print('MATCHED',i,order,name,None if warm is None else warm.nodes,None if fresh is None else fresh.nodes,flush=True)
a.write_record(P/'matched-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('MATCHED_CLOSED',len(rows),time.perf_counter()-start,flush=True)
