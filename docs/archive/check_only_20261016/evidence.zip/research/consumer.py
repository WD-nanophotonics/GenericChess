"""Search-disabled consumer. Run from product source root; pass evidence directory."""
from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=Path(sys.argv[1])if len(sys.argv)>1 else R/'.local_agent/check-only-20261016'
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.ir import CompiledSemanticRuleset
class Adapter(CompiledSemanticRuleset):
 __slots__=()
 def __getattr__(self,name):return getattr(self._legacy_compiled,name)
 @property
 def semantic(self):return self
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import iter_legal_actions
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine,_module
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from scripts.research_record import record_value
assert Path(nc.__file__).resolve().is_relative_to(R.resolve())
assert Path(_module().__file__).resolve().is_relative_to(R.resolve())
assert Path(compile_legacy_ruleset_for_semantic_execution.__code__.co_filename).resolve().is_relative_to(R.resolve())
def forbidden(*a,**kw):raise AssertionError('Search forbidden in receipt consumer')
SemanticSearchEngine.search=forbidden;_module().semantic_engine_search=forbidden
def read(p):return json.loads((B/p).read_bytes())
def action(d):
 if d is None:return None
 if not d:return PassAction()
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def digest(state):return hashlib.sha256(json.dumps(record_value(state),sort_keys=True).encode()).hexdigest()
cache={};root_states=set();counts=dict(root_loads=0,queries=0,pv_edges=0,physical_games=0,physical_edges=0,one_reply_receipts=0,selected_choice_edges=0)
def load(root):
 key=str(root)
 if key not in cache:
  d=read('roots/'+key+'.json');raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=Adapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=nc.compile_native_semantic_rules(c);cache[key]=(d,c,nr);counts['root_loads']+=1
 d,c,nr=cache[key];s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])))
 assert record_value(s.state)==d['state']and digest(s.state)==d['before_sha256']
 root_states.add(digest(s.state));return s,nr
def compare(s,nr,state,np,witnesses):
 snap=sem.snapshot(nr,np);exp=expected_snapshot(state.position,nr,s.compiled)
 for k in('board','hands','aux_state','side'):assert record_value(snap[k])==record_value(exp[k])
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(w,s.compiled))for w in witnesses]
 assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
def query(s,nr,r,limit=1000000):
 assert r['nodes']>=0 and r['qnodes']>=0 and r['nodes']+r['qnodes']<=limit
 st=s.state;np=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses)
 chosen=action(r['action']);assert chosen is None or chosen in s.legal_actions()
 line=[action(a)for a in r['principal_variation']];had_pv=bool(line)
 if line:assert line[0]==chosen
 if not line and chosen is not None:line=[chosen]
 for a in line:
  np=sem.make_checked(nr,np,pack_semantic_action(nr,st.position,a));st=apply_action(st,a,s.compiled);w.append(st.position);compare(s,nr,st,np,w);counts['pv_edges']+=int(had_pv);counts['selected_choice_edges']+=int(not had_pv)
 if r.get('immediate_win')and r.get('result_source')=='verified_root_child':assert len(line)==1 and st.terminal_status.winner==s.state.position.side_to_move
 counts['queries']+=1
 return st,np

from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
AlphaBetaPlayer.choose_action=forbidden
def load_record(d, *, semantic=False):
 rs=deserialize_ruleset(json.dumps(d['ruleset']))
 if semantic:c=compile_ruleset_for_execution(rs)
 else:
  raw=compile_legacy_ruleset_for_semantic_execution(rs);c=Adapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
 nr=nc.compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])))
 assert record_value(s.state)==d['state']and digest(s.state)==d['before_sha256']
 np=pack_semantic_search_position(c,nr,s);compare(s,nr,s.state,np,list(s._search_witnesses))
 assert {pack_semantic_action(nr,s.state.position,x)for x in s.legal_actions()}==set(sem.guarded_actions(nr,np))
 counts['root_loads']+=1;root_states.add(digest(s.state));return s,nr
start=time.perf_counter()
triad=read('results.json');assert triad['complete']and len(triad['rows'])+len(triad['missing'])==78
for row in triad['rows']:
 s,nr=load(row['root_id']);assert digest(s.state)==row['before_sha256'];query(s,nr,row['result'],65536)
 r=row['result']
 if r['completed_depth']:
  assert (r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==((0,0)if row['arm']=='disabled_q0'else(0,8)if row['arm']=='check_only'or r['completed_depth']==1 else(1,8))
for root in range(13):
 for arm in ('disabled_q0','check_only','ordinary_q1'):
  rr=[r['result']for r in triad['rows']if r['root_id']==f'node-{root}'and r['arm']==arm]
  assert {k:v for k,v in rr[0].items()if k!='elapsed_seconds'}=={k:v for k,v in rr[1].items()if k!='elapsed_seconds'}
aux=read('aux-results.json');s,nr=load_record(aux['root'],semantic=True)
for row in aux['rows']:
 query(s,nr,row['result'],65536);snap=record_value(sem.snapshot(nr,pack_semantic_search_position(s.compiled,nr,s)));assert snap==row['root_snapshot']
diff=read('differential-results.json');assert diff['complete']and len(diff['rows'])==9
for row in diff['rows']:
 s,nr=load_record(read('control-roots/'+row['case']+'.json'),semantic=True);query(s,nr,row['native'],65536)
 assert row['joint_complete']and row['score_equal']and row['root_restored']
 # Core returned full action/line remains a separately replayed receipt.
 core=row['core'];cr=dict(action=core['action'],principal_variation=core['principal_variation'],nodes=0,qnodes=0)
 query(s,nr,cr,65536)
for row in diff['actual_timer_cancellations']:
 s,nr=load('node-'+str(row['root']));query(s,nr,row['result']);assert row['cancelled']and row['root_restored']and row['result']['termination_reason']=='cancelled'
replies=read('reply-results.json');assert replies['complete']and len(replies['rows'])==39
seen=set()
for row in replies['rows']:
 key=row['diagnostic_key']
 if key in seen:continue
 seen.add(key);s,nr=load(row['root_id']);child=apply_action(s.state,action(row['action']),s.compiled);d=replies['diagnostics'][key];observed=[]
 for witness in d.get('rows',[]):
  ac=action(witness['action']);after=apply_action(child,ac,s.compiled);assert record_value(after.terminal_status)==witness['terminal'];observed.append(ac);counts['one_reply_receipts']+=1
 if d.get('complete'):assert set(observed)==set(iter_legal_actions(child,s.compiled))
 if d.get('winning_reply')is not None:assert apply_action(child,action(d['winning_reply']),s.compiled).terminal_status.winner==child.position.side_to_move

if (B/'core-match-results.json').exists():
 match=read('core-match-results.json');assert match['complete']and len(match['rows'])==26
 for row in match['rows']:
  s,nr=load('node-'+str(row['root']));query(s,nr,row['native'],65536)
  core=row['core'];query(s,nr,dict(action=core['action'],principal_variation=core['principal_variation'],nodes=0,qnodes=0),65536)
  assert row['joint_complete']and row['normalized_score_equal']

if (B/'finite/completion.json').exists():
 done=read('finite/completion.json');plan=read('finite/plan.json');assert done['complete']and len(done['games'])==plan['max_games']
 for g in done['games']:
  if 'result'not in g:continue
  s,nr=load_record(read('finite/roots/'+str(g['seed'])+'.json'));game=read(f"finite/game-{g['seed']}-{g['mode']}.json");assert game['complete'];w=list(s._search_witnesses);np=pack_semantic_search_position(s.compiled,nr,s)
  for row in game['rows']:
   assert digest(s.state)==row['before_sha256'];assert len(row['phases'])<=1
   if row['phases']:
    ph=row['phases'][0];r=ph['result'];query(s,nr,r);assert row['selected']==r
    assert row['total_nodes']==ph['used_total_nodes']==r['nodes']+r['qnodes']<=1000000
    q=1 if g['mode'].startswith('check_role')and row['actor']==int(g['mode'][-1])else 0
    assert ph['q']==q
    if r['completed_depth']:assert (r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==((0,8)if q else(0,0))
   if 'action'not in row:assert not row['execution_allowed'];continue
   assert row['execution_allowed']and row['action']==row['selected']['action']and not row['cancelled']and row['caller_seconds']<1
   ac=action(row['action']);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));s.submit(ac);w.append(s.state.position);compare(s,nr,s.state,np,w)
   assert digest(s.state)==row['after_sha256']and record_value(s.result)==row['actual_terminal'];counts['physical_edges']+=1
  assert record_value(s.state)==game['state']and record_value(s.result)==game['result'];counts['physical_games']+=1

if (B/'tt/control-results.json').exists():
 control=read('tt/control-results.json');assert control['complete']and len(control['rows'])==48
 for row in control['rows']:
  s,nr=load_record(read('tt/roots/'+str(row['seed'])+'.json'));r=row['result'];query(s,nr,r,65536)
  assert r['tt_allocated_bytes']==(11534336 if row['cell']in('C','D')else 0)
 for pair in control['pairs']:
  if pair['joint_complete']:assert pair['score_equal']
if (B/'tt/completion.json').exists():
 done=read('tt/completion.json');plan=read('tt/plan.json');assert done['complete']and len(done['games'])==42
 for g in done['games']:
  if 'result'not in g:continue
  s,nr=load_record(read('tt/roots/'+str(g['seed'])+'.json'));path=f"tt/game-{g['seed']}-{g['mode']}";game=read(path+'.json');assert game['complete']
  assert [json.loads(line)for line in(B/(path+'.jsonl')).read_text().splitlines()]==game['rows']
  w=list(s._search_witnesses);np=pack_semantic_search_position(s.compiled,nr,s)
  for row in game['rows']:
   assert digest(s.state)==row['before_sha256'];assert len(row['phases'])<=1
   cell=g['mode'][0]if g['mode']!='A_control'and row['actor']==int(g['mode'][-1])else'A';cfg=plan['cells'][cell];q=int(cfg['objective']=='check_only')
   assert row['owner']==cell and row['objective']==cfg['objective']and row['tt_megabytes']==cfg['tt_megabytes']
   if row['phases']:
    ph=row['phases'][0];r=ph['result'];query(s,nr,r);assert row['selected']==r
    assert row['total_nodes']==ph['used_total_nodes']==r['nodes']+r['qnodes']<=1000000
    assert ph['q']==q and r['tt_allocated_bytes']==(11534336 if cell in('C','D')else 0)
    if r['completed_depth']:assert (r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==((0,8)if q else(0,0))
   if 'action'not in row:assert not row['execution_allowed'];continue
   assert row['execution_allowed']and row['action']==row['selected']['action']and not row['cancelled']and row['caller_seconds']<1
   ac=action(row['action']);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));s.submit(ac);w.append(s.state.position);compare(s,nr,s.state,np,w)
   assert digest(s.state)==row['after_sha256']and record_value(s.result)==row['actual_terminal'];counts['physical_edges']+=1
  assert record_value(s.state)==game['state']and record_value(s.result)==game['result'];counts['physical_games']+=1


for folder in ('finite','tt'):
 if not(B/(folder+'/divergence-results.json')).exists():continue
 d=read(folder+'/divergence-results.json');assert d['complete'];seen=set()
 for row in d['rows']:
  if row['kind']!='FIRST_ACTION_DIFFERENCE':continue
  s,nr=load_record(read(folder+'/divergence-roots/'+row['root_id']+'.json'))
  for act,key in zip(row['actions'],row['diagnostic_keys']):
   if key in seen:continue
   seen.add(key);ac=action(act);child=apply_action(s.state,ac,s.compiled);np=pack_semantic_search_position(s.compiled,nr,s);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));compare(s,nr,child,np,list(s._search_witnesses)+[child.position]);counts['diagnostic_choice_edges']=counts.get('diagnostic_choice_edges',0)+1
   dg=d['diagnostics'][key];observed=[]
   for witness in dg.get('rows',[]):
    reply=action(witness['action']);after=apply_action(child,reply,s.compiled);assert record_value(after.terminal_status)==witness['terminal'];observed.append(reply);counts['one_reply_receipts']+=1
   if dg.get('complete'):assert set(observed)==set(iter_legal_actions(child,s.compiled))
   if dg.get('winning_reply')is not None:assert apply_action(child,action(dg['winning_reply']),s.compiled).terminal_status.winner==child.position.side_to_move


for filename in ('warm-results.json','key-policy-results.json'):
 if not(B/filename).exists():continue
 data=read(filename);assert data['complete']and len(data['rows'])==104
 for row in data['rows']:
  s,nr=load(row.get('root_id','node-'+str(row['root'])));query(s,nr,row['result'],65536)
  if row['phase'].endswith('adjacent'):
   assert row['source_context_equal']==(filename=='key-policy-results.json'or not row['exact_root'])
for i in range(13):
 original={r['phase']:r['result']for r in read('warm-results.json')['rows']if r['root']==i and r['exact_root']}
 pilot={r['phase']:r['result']for r in read('key-policy-results.json')['rows']if r['root']==i and r['exact_root']}
 for phase in original:
  assert all(original[phase][k]==pilot[phase][k]for k in('score','action','declaration_id','principal_variation','completed_depth'))
 assert original['warm_adjacent']['nodes']==pilot['warm_adjacent']['nodes']==pilot['fresh_adjacent']['nodes']
jr=read('journal-results.json');assert jr['complete']and len(jr['rows'])==4
source_rows=read('finite/game-8811-check_role1.json')['rows'];jh=hashlib.sha256(json.dumps(source_rows,sort_keys=True).encode()).hexdigest()
for r in jr['rows']:assert r['lossless']and r['records']==len(source_rows)==64 and r['source_rows_sha256']==jh


if (B/'matched-results.json').exists():
 data=read('matched-results.json');assert data['complete']and len(data['rows'])==156
 assert [json.loads(line)for line in(B/'matched-rows.jsonl').read_text().splitlines()]==data['rows']
 for row in data['rows']:
  if 'result'not in row:continue
  if row['phase']=='parentD4':s,nr=load(row['root_id'])
  else:s,nr=load_record(read('matched-roots/'+row['root_id']+'.json'))
  query(s,nr,row['result'],1000000)
 for root in range(13):
  for order in(0,1):
   for phase in('parentD4','warm_childD2','fresh_childD2'):
    rr=[r['result']for r in data['rows']if r['root']==root and r['order']==order and r['phase']==phase]
    assert len(rr)==2 and all(rr[0][k]==rr[1][k]for k in('score','action','principal_variation','completed_depth'))

counts.update(unique_full_root_states=len(root_states),complete=True,seconds=time.perf_counter()-start,search_execution_forbidden=True,scope='Core/normal Native full-history receipt replay, shared compiler, no new searches/games/proofs and no all-domain or independent-rule/WDL claim.')
(B/'consumer-replay.json').write_bytes(json.dumps(counts,indent=2).encode());print('CONSUMER_PASS',counts,flush=True)
