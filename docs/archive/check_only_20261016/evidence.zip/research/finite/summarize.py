from pathlib import Path
import json,random,collections,statistics
P=Path(__file__).resolve().parent
done=json.loads((P/'completion.json').read_bytes());plan=json.loads((P/'plan.json').read_bytes());assert done['complete']and len(done['games'])==27
by={(g['seed'],g['mode']):g for g in done['games']}
def category(g,role):
 if 'result'not in g or g['result']['status']=='ongoing':return 'UNKNOWN'
 w=g['result']['winner'];return 'DRAW'if w is None else'WIN'if w==role else'LOSS'
score={'WIN':1,'LOSS':-1,'DRAW':0,'UNKNOWN':0};rows=[];families=[];counter=collections.Counter();control=collections.Counter();transitions=collections.Counter()
for case in plan['inputs']:
 seed=case['seed'];base=by[(seed,'q0_control')];vals=[]
 for role in (0,1):
  g=by[(seed,'check_role'+str(role))];x,y=category(base,role),category(g,role);v=score[y]-score[x];vals.append(v);counter[y]+=1;control[x]+=1;transitions[x+'->'+y]+=1;rows.append(dict(seed=seed,n=case['n'],role=role,control=x,candidate=y,delta=v,game_kind=g['kind'],seconds=g.get('seconds'),edges=g.get('edges')))
 families.append(dict(**case,mean_delta=sum(vals)/2))
rng=random.Random(202610160881);samples=[]
for _ in range(10000):
 vals=[]
 for n in (8,12,16):
  fs=[f['mean_delta']for f in families if f['n']==n]
  vals.extend(rng.choices(fs,k=len(fs)))
 samples.append(statistics.mean(vals))
samples.sort()
games=[g for g in done['games']if 'result'in g]
out=dict(question=plan['question'],actual_physical_games=len(games),planned_slots=len(done['games']),missing=[g for g in done['games']if 'result'not in g],candidate=dict(counter),control_roles=dict(control),finite_delta=sum(r['delta']for r in rows),mean_delta=statistics.mean(r['delta']for r in rows),family_stratified_bootstrap95=[samples[249],samples[9749]],bootstrap_scope='10000fixed-seed exploratory resamples of9families, each family bothroles paired,3families perboard retained. Ordinary interval, not sequential/population guarantee. UNKNOWN finite-code0 is not draw or missing success.',transitions=dict(transitions),families=families,rows=rows,seconds_physical=sum(g['seconds']for g in games),candidate_seconds=sum(g['seconds']for g in games if g['mode']!='q0_control'),control_seconds=sum(g['seconds']for g in games if g['mode']=='q0_control'),batch_seconds=done['seconds'],physical_edges=sum(g.get('edges',0)for g in games))
phase=collections.Counter();depth=collections.Counter();refusals=[];actions=collections.Counter()
for g in games:
 x=json.loads((P/f"game-{g['seed']}-{g['mode']}.json").read_bytes())
 for r in x['rows']:
  if not r['execution_allowed']:refusals.append(dict(seed=g['seed'],mode=g['mode'],ply=r['ply'],owner=r['owner'],caller_seconds=r['caller_seconds'],selected=r['selected']))
  if 'action'in r:actions[r['owner']]+=1
  for ph in r['phases']:phase[r['owner']+':'+ph['result']['termination_reason']]+=1;depth[r['owner']+':'+str(ph['result']['completed_depth'])]+=1
out.update(phase_termination=dict(phase),phase_depths=dict(depth),physical_actions=dict(actions),caller_refusals=refusals)
(P/'summary.json').write_bytes(json.dumps(out,indent=2).encode());print('FINITE_SUMMARY',{k:v for k,v in out.items()if k not in('rows','families','caller_refusals','phase_depths')},flush=True)
