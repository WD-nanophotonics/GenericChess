from pathlib import Path
import json,hashlib
P=Path('.local_agent/check-only-20261016');R=Path.cwd()
p=R/'docs/research/LOCAL_MAINLINE.md';s=p.read_text(encoding='utf-8-sig')
start=s.index('Current next choice: distinguish ACTUAL check-only')
end=s.index('\n16normal/reconstruction-counter',start)
replacement="""Current check-only/TT result: actual78triad calls distinguish disabledq0
from true forced-only(0,8). Both completeD3 in26/26, ordinaryq1 in18/26; local
depth is not utility. Fresh9family27game check-only gives4W6L8UNKNOWN versus
5W5L8UNKNOWN, net-2 with oneW-to-L. Fresh6family42game fixed-opponent four cells
A=q0TT0/B=checkTT0/C=q0TT16/D=checkTT16 each treatment net+1versusA. D-C0 and
interaction-1; C preserves2DRAWs that D leavesUNKNOWN, and D trades WIN/UNKNOWN
both ways. D costs364.482s versusC308.557s. Six-family empirical D-C interval0
is cancellation in this sample, not equivalence. Keep q0/TT as cheap baseline;
no new q/default/API/price or broader strength claim. Do not pool cohorts.

All69physical games/2498edges and3063retained Core/Native query/phase receipts
pass the normal search-disabled full-state/history consumer.35Core pairs have
matching finite scores; pure persistentaux works without legacy metadata.
Three earlier auxiliary execution receipts were overwritten during strengthening
and are explicitly missing, not silently counted as retained/replayed.60actual
focused tests pass. Source-only extracted normal rebuild/replay is separately
qualified in the publication receipt; private Native images are provenance.

The recording contrast solves an observed overhead: exact64row append/fsync
takes~.22s/5.34MB versus full-prefix rewrite~25.8s/803MB, complete dictionaries
unchanged. New42game panel uses it uniformly; old27game data/caps stay frozen.
No diagnostics API or general recording framework is introduced.

New actual adjacent-TT study104normal/104private calls restores lookup-key
context identity and extra hits but saves no nodes on13roots. A changed
D4parent-to-D2child control156calls also saves0nodes in52paired groups, all
complete scores/actions/PVs matching. No key-tag rewrite adoption. More hits,
a symbolic identity correction and same-source finite agreement are not useful
speed or all-domain qualification. Legacy-mode censors remain separate.

Current next choice: one bounded NativeTT same-key depth-demotion counter,
BEFORE any retention edit. Source allows shallower replacement solely because
generation advances; direct demotion counts remain0runs, so this is an explicit
new hypothesis, not an established causal explanation or an unchanged rerun.
Use existing13parent/two-PV-move q0 sequences, <=104calls/300s whole/expected60s,
full history/q/mode guards. If no material explanation, stop this route and
inspect dominant q0 stage cost on existing wide inputs. If measured, choose
one scoped retention ablation, not a broad cache rewrite or mandatory WDL proof.
This supersedes the old0build/0query check-only task; all frozen observations
and the search-first scheduling choice remain. Source/results/limits:
CHECK_ONLY_TT_AND_HISTORY_CONTEXT_20261016.md. Normal C/API/prices/default/UI
unchanged; AUX owns its separate solver/learning lane. Science remains OPEN.
"""
s=s[:start]+replacement+s[end:];p.write_bytes(s.encode())
p=R/'docs/operations/COLLABORATION_LOG.md';s=p.read_text(encoding='utf-8-sig')
s+="""

## PRIMARY segment 2026-10-16: check-only/TT finite interaction and failed reuse shortcut

PRIMARY_SANDBOX owns only this sandbox delivery. It executed the previously
prepared forced-only Native prototype, ALL78 triad calls,35 matching all-Core
finite objectives, persistentaux/control/cancellation checks,27fresh fixedq0
games and42further fresh four-cell games. All69games/2498physical edges and3063
retained Core/Native query/phase receipts pass the normal full-history
search-disabled consumer. There is an explicit preliminary retention failure:
six auxiliary searches ran but only the final three full receipts survive.
No overwritten body/timing or successful preservation is invented.

The first finite panel rejects an immediate check-only rollout (net-2/18).
The later TT four cells each show net+1versusfixedA on only6families; D-C0
does not mean equivalence: W/UNKNOWN swaps and2DRAW-to-UNKNOWN remain.
C costs308.557s versusD364.482s. No changed q/default/API/evaluation/price/UI.
Exact-row recording removes measured duplicate-prefix cost without dropping
result fields; it is used uniformly only in the new42game protocol.

PRIMARY separately tests persistent Native history-key tagging:104normal,
104private and156matched-depth calls. Extra identity/hits do not reduce nodes;
the candidate stays unadopted. A single same-key depth-demotion counter is
prepared as a falsifiable next source hypothesis. No AUX prover, bank, cursor,
learner, mutable checkout or work state is copied or edited.

Coordination: recovery and closing read complete PRIMARY root1792058616.873839
(13replies before this delivery) and AUX64root1792092794.124699 (three replies
at closing, including new AUX65delivery1792099199.136089), plus new channel roots
through the existing boundary. Exact raw outputs were saved before assessment.
No new technical Dot reply or acknowledgement gate; no request/send retry or
new worker. Dot's valid-cache versus finite-policy distinction supports explicit
per-call fresh TT conditions here. Another window's two-hour remark does not
replace this chat's current single-run>one-hour necessity rule; both own finite
batches are independently below it.

DEV_AUX fixed64report2bfe7d5e6198ec82a75685c6f51f0f58c8ed4513 and fresh65report
3872124f1eed7bbb1462491460bc5ff39749e7d0 were anonymously READ as REPORTS,
not final solver/learning source, test/game execution or adoption by PRIMARY.
65 reports actual two-new-dataset208-vs416 training, R/N2 and2.5, stronger
fixed-opponent DEV net+10/64, but balanced-four-opponent transfer interval
crosses0, price instability and retained UNKNOWN. It also reports same exposed
TRAIN416payoffs with lower1K proof cost. These support its own more-data/
cross-budget question, not a universal price/default or pooled Native unit.
The cold-bank correction is implemented by its owner; PRIMARY did not rerun it.
No disagreement requires a coordination pause, and the parallel lanes stay
separate. PUBLIC source access, not message delivery, enables later review.

Efficiency/limits: first27game batch1721.389s, new42batch1236.597s, all planned
slots retained. Actual same-host64row recording contrast25.8s versus.22s
includes compact formatting/serialization; it is not machine-exclusive search
speed. Native requestedTT16MiB allocates11MiB. Normal60focused tests actually
pass; an auto-review rejection of hardcoded retrospective test metadata was
resolved by a fresh actual60test execution/direct receipt, no bypass or pending
user consent. Text-guard/path/encoding fixes and the auxiliary data gap are
disclosed in the research evidence. Source-only qualification has shared
Core/compiler/host limits; no claim of full study reexecution or independent WDL.

This entry and the detailed report/data/retained-source capsule are published
together; final full remoteSHA and the single actual Dot delivery receipt are
recorded locally after publication. No claim that Dot has read or executed them.
"""
p.write_bytes(s.encode())
p=P/'local-failures.json';d=json.loads(p.read_bytes());d['items'].append(dict(kind='CONSOLE_ENCODING_FIXED',action='read AUX65 public report',failure='Report bytes were saved before print; cp1252 console could not print Chinese header.',correction='Read the saved UTF8 original through PowerShell, complete report reviewed; original SHA preserved, no network refetch or scientific data change.',impact='No blocker; AUX65tierREPORT_READ_ONLY, not execution.'));p.write_bytes(json.dumps(d,indent=2).encode())
p=R/'docs/research/CHECK_ONLY_TT_AND_HISTORY_CONTEXT_20261016.md';s=p.read_text();s+="""

Closing supplement: the complete AUX64 thread also includes the new AUX65 owner
delivery1792099199.136089. Fixed65 report3872124f1eed7bbb1462491460bc5ff39749e7d0
was read anonymously, SHA7ba24dd021e18734b6fabffe4fe14931f06d9586273110ab96484b4e569ecdf7.
Its prospective cold-policy racing matches FULL on two new training datasets,
with stronger-opponent DEV gain10/64, but balanced-opponent transfer remains
unconfirmed and exact prices vary. These are REPORT_READ findings here, not
PRIMARY source/test/game execution or adoption. The owner retains its own
cross-budget/more-data next step. No Native units or results are pooled.
"""
p.write_bytes(s.encode())
