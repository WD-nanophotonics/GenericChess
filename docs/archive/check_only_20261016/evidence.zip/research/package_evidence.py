"""Freeze checked source and scientific receipts; exact transport originals remain private."""
from pathlib import Path
import sys,json,hashlib,zipfile,subprocess,re
R=Path.cwd();P=R/'.local_agent/check-only-20261016';D=R/'docs/archive/check_only_20261016'
assert json.loads((P/'finite/completion.json').read_bytes())['complete']
assert json.loads((P/'consumer-replay.json').read_bytes())['physical_games']==sum('result'in g for folder in ('finite','tt') for g in json.loads((P/folder/'completion.json').read_bytes())['games'])
assert hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest()=='1c855ae56e946ec6cb8e57f60a36a18cb75cfec2ee8061047469f3e0bee3fac3'
files={}
def add(name,data):
 text=data.decode('utf-8-sig').replace(str(R),'<PROJECT>').replace(str(R).replace('\\','/'),'<PROJECT>')
 text=text.replace('C:\\\\Users\\\\wdai','<USER>').replace('<USER>','<USER>').replace('<USER>','<USER>')
 files[name]=text.replace('\r\n','\n').encode()
for f in sorted(P.rglob('*')):
 if not f.is_file()or any(x in f.parts for x in ('__pycache__','public-copy','zig-public-copy-cache')):continue
 rel=f.relative_to(P).as_posix()
 if f.suffix not in('.json','.jsonl','.py','.patch'):continue
 if any(x in rel for x in ('-private','-partial','recovery-','reconcile-','segment-quality','publication-','outgoing-','send-','delivery-','public-copy','build-private')):continue
 if rel.startswith('source/'):continue
 if rel.startswith('finite/')and f.name.startswith('.'):continue
 add('research/'+rel,f.read_bytes())
for folder,variant in [('source','check_only_source'),('key_policy_source','key_policy_source')]:
 for f in(P/folder).iterdir():
  if f.suffix in('.c','.h'):add('variants/'+variant+'/'+f.name,f.read_bytes())
for rel in subprocess.check_output(['git','ls-files','generic_chess','scripts'],text=True).splitlines():
 if Path(rel).suffix in('.py','.c','.h'):add('source/'+rel,(R/rel).read_bytes())
add('source/pyproject.toml',(R/'pyproject.toml').read_bytes())
add('research/normal-consumer-replay.json',(P/'consumer-replay.json').read_bytes())
# Exact private producers are provenance. Their older helper chains remain pinned in the previous public capsule.
add('research/producer-dependencies.json',json.dumps(dict(prior_fixed_sha='8ece16713f332adbe629f5541ddca88c74514e7f',prior_capsule='docs/archive/q1_component_20261016/evidence.zip',scope='Private historical producer imports refer to existing prior frozen helper paths, not automatic replay instructions. New consumer.py is self-contained with source/ and research/ only; actual source-only replay runs no search/game/proof.'),indent=2).encode())
for name,data in files.items():
 text=data.decode()
 assert not re.search(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',text),(name,'email')
 assert not re.search(r'\bsk-[A-Za-z0-9]{24,}|\bxox[bp]-[A-Za-z0-9-]{12,}|\bghp_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}',text),(name,'possiblecredential')
 for bad in('<USER>','C:\\\\Users\\\\wdai'):assert bad not in text,(name,'privatepath')
D.mkdir(parents=True,exist_ok=True);assert not(D/'evidence.zip').exists(),'Never replace sealed evidence'
with zipfile.ZipFile(D/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert z.testzip()is None
 for name,data in files.items():assert z.read(name)==data
manifest=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),product_changed=False,product_module_sha256=hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),archive_sha256=hashlib.sha256((D/'evidence.zip').read_bytes()).hexdigest(),archive_bytes=(D/'evidence.zip').stat().st_size,member_count=len(files),members=[dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in sorted(files.items())],scope='All current scientific receipts/inputs/plans and provenance, full normal source and private one-line variant source. No binaries, raw account/Slack originals, credentials or private paths. Source-only consumer independently replays complete semantic states/history with search forbidden; shared Core/compiler/host, not independent rule/WDL proof. Old capsules unchanged.')
(D/'manifest.json').write_bytes(json.dumps(manifest,indent=2).encode());print('PACKAGED',manifest['member_count'],manifest['archive_bytes'],manifest['archive_sha256'],flush=True)
