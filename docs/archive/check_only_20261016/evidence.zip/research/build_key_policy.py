from pathlib import Path
import json,shutil,hashlib,subprocess,sysconfig,sys,time
R=Path.cwd();P=R/'.local_agent/check-only-20261016';S=P/'key_policy_source';S.mkdir(exist_ok=True)
base=R/'generic_chess/_native/native_module.c';assert hashlib.sha256(base.read_bytes()).hexdigest()=='1c855ae56e946ec6cb8e57f60a36a18cb75cfec2ee8061047469f3e0bee3fac3'
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
p=S/'native_module.c';s=p.read_text(encoding='utf-8-sig')
mark='    uint32_t tt_iteration_generation;\n    GCSemanticTable *tt;';assert s.count(mark)==1;s=s.replace(mark,mark+'\n    uint64_t tt_node_policy_tag[4]; /* PRIVATE: exact-root q0 domain tag at key lookup, never rolling history. */')
start=s.index('static void gc_semantic_tt_store_node(')
helper="""static const uint64_t *gc_semantic_tt_key_context(
        GCSemanticIterativeContext *ctx, uint32_t ply, uint64_t local[4]) {
    for (int i = 0; i < 4; i++)
        local[i] = ctx->history_context[ply][i] ^ ctx->tt_node_policy_tag[i];
    return local;
}

"""
s=s[:start]+helper+s[start:]
mark='    GCTTBound bound = GC_TT_BOUND_EXACT;';idx=s.index(mark,s.index('static void gc_semantic_tt_store_node('));s=s[:idx]+"    uint64_t key_context[4];\n"+s[idx:]
mark='ctx->tt, position, ctx->history_context[ply], depth,';assert s.count(mark)==2
s=s.replace(mark,'ctx->tt, position, gc_semantic_tt_key_context(ctx, ply, key_context), depth,')
mark='        uint32_t stored_generation = 0;';assert s.count(mark)==1;s=s.replace(mark,mark+'\n        uint64_t key_context[4];')
mark='    gc_semantic_context_seed(position, ctx.history_context[0]);\n    if (ctx.root_window_pruning) {';assert s.count(mark)==1
replacement="""    gc_semantic_context_seed(position, ctx.history_context[0]);
    if (ctx.root_window_pruning && qdepth == 0) {
        ctx.tt_node_policy_tag[0] = UINT64_C(0x726f6f742d657861);
        ctx.tt_node_policy_tag[1] = UINT64_C(0x63742d6465707468);
    }
    if (ctx.root_window_pruning && qdepth > 0) {"""
s=s.replace(mark,replacement);p.write_bytes(s.encode())
plan=dict(question='Can moving only exact-root q0 policy separation from the rolling history to TT key lookup restore adjacent-root reuse while preserving complete history and finite objectives?',basis='Actual104call normal warm study: exact-root adjacent warm nodes equal fresh13/13, source-reconstructed contexts differ13/13; legacy contexts equal but calls budget-censored. This is a source-supported performance candidate, not an observed semantic bug.',source_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),private_source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='PRIVATE normalq0 only, root-window exact mode. q>0 retains original salted history path; q0legacy retains zero tag. Full event/digest history, terminal/aux/actions/profile untouched. Table/context layouts private; no product/API/default adoption or AUXsolver/bank.',decision='Reject any jointly-complete score/action/PV mismatch; compare cold versus warm work separately. Changed TT tie/cache policy under a wall clock is not automatically strength or deterministic latency. Full qualification needed before product adoption.',whole_seconds=300,expected_seconds=60)
(P/'key-policy-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in S.glob('*.c')],'-o',str(P/'key_policy_native_core.pyd')]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
(P/'key-policy-build.json').write_bytes(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t),indent=2).encode());print('KEY_POLICY_BUILD',r.returncode,r.stderr[-1000:]);sys.exit(r.returncode)
