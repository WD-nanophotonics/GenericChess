from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/check-only-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;spec=importlib.util.spec_from_file_location('core_match_check_only._native_core',P/'check_only_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
core=json.loads((P/'core-parent-results.json').read_bytes());a.write_record(P/'core-match-plan.json',dict(question='Matching finite Native calls for the frozen26all-Core checking-parent objectives',cases=[dict(root=r['root'],depth=r['depth'])for r in core['rows']],nodes=65536,seconds=5,whole_seconds=120,expected_seconds=10,scope='Same semantic objective and same static profile; compare complete scores, not canonical action ties. No new labels/solver/cap extension.'))
rows=[];start=time.perf_counter()
for cr in core['rows']:
 i=cr['root'];d=json.loads((P/'roots'/f'node-{i}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=a.nc.compile_native_semantic_rules(c,backend_module=m);t=time.perf_counter()
 r=a.SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False).search(s,a.SearchLimits(max_depth=cr['depth'],max_nodes=65536,max_time_seconds=5,quiescence_max_depth=1,quiescence_hard_max_depth=8),root_window_pruning=True)
 complete=cr['result']['completed_depth']==r.completed_depth==cr['depth'];norm=r.score if abs(r.score)<50000000 else (1 if r.score>0 else-1)*(1000000000-(100000000-abs(r.score)))
 row=dict(root=i,depth=cr['depth'],native=a.record_value(r),core=cr['result'],joint_complete=complete,normalized_score_equal=cr['result']['score']==norm if complete else None,action_equal=cr['result']['action']==a.record_value(r.action),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r));rows.append(row)
a.write_record(P/'core-match-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('CORE_MATCH',len(rows),sum(r['joint_complete']for r in rows),sum(r['normalized_score_equal']is True for r in rows),[(r['root'],r['depth'])for r in rows if r['normalized_score_equal']is False],flush=True)
