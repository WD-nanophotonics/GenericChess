from pathlib import Path
import json,sys,time,importlib.util,hashlib,threading,shutil
R=Path.cwd();P=R/'.local_agent/check-only-20261016';O=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(O)]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;plan=json.loads((P/'plan.json').read_bytes());spec=importlib.util.spec_from_file_location('check_only._native_core',P/'check_only_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mods=dict(disabled_q0=p.m,check_only=m,ordinary_q1=p.m);rows=[];missing=[];start=time.perf_counter()
(P/'roots').mkdir(exist_ok=True)
for parent in plan['parents']:
 src=O/'roots'/f"{parent['root_id']}.json";shutil.copyfile(src,P/'roots'/src.name)
 d=json.loads(src.read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));assert p.digest(s)==parent['before_sha256']
 nrs={name:a.nc.compile_native_semantic_rules(c,backend_module=mod)for name,mod in mods.items()}
 for order,names in enumerate(plan['proposed_conditions']['orders']):
  for name in names:
   p.stopped()
   if time.perf_counter()-start>=240:missing.append(dict(root_id=parent['root_id'],order=order,arm=name));continue
   e=a.SemanticSearchEngine(c,nrs[name],board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter()
   r=e.search(s,a.SearchLimits(max_depth=3,max_nodes=65536,max_time_seconds=6,quiescence_max_depth=0 if name=='disabled_q0'else 1,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True)
   seconds=time.perf_counter()-t
   rows.append(dict(root_id=parent['root_id'],before_sha256=p.digest(s),order=order,arm=name,objective=name,result=a.record_value(r),caller_seconds=seconds,pv_edges=a.audit(s,nrs[name],r)))
   assert p.digest(s)==parent['before_sha256']
   print(parent['root_id'],order,name,r.completed_depth,r.termination_reason,r.result_ordinary_qdepth,r.result_check_hard_qdepth,round(seconds,3),flush=True)
 a.write_record(P/'results-partial.json',dict(complete=False,rows=rows,missing=missing,seconds=time.perf_counter()-start))
a.write_record(P/'results.json',dict(complete=True,rows=rows,missing=missing,seconds=time.perf_counter()-start))
print('TRIAD_CLOSED',len(rows),len(missing),time.perf_counter()-start,flush=True)
