"""Limited forced-action diagnostic in the actual parent iterative q context."""
import sys,runpy,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import json,random
from types import SimpleNamespace
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value as record,write_record as write
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime as Runtime
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from scripts.native_core_availability import NativeCoreAvailability
seed=2026101455
g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True))
src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);session=p.GameSession(c);rng=random.Random(seed+13000)
for _ in range(8):
 assert session.result.status.value=='ongoing'
 session.submit(rng.choice(sorted(session.legal_actions(),key=repr)))
m={'s':session,'c':c,'profile':profile,'ec':ec}
h={'CountedSemanticEvaluator':SemanticAttackEvaluator,'AlphaBetaPlayer':AlphaBetaPlayer,'SearchTuning':SearchTuning,'SearchLimits':SearchLimits}
out=Path(__file__).resolve().parent/'public1455'
import hashlib,json
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does supported mixedq option reproduce archivedprivate1455D2 withoutglobalpatch?',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),calls=1,root=2026101455,depth=2,q=4,hardq=8,seconds=120,nodecap=None,tt=True,scope='Actualpublicconstructor flags and Core/native/fullhistory; comparecompleteaction/score/mainPV andwork toclosedpriorprofile. No timing comparison toprofile or changedoldbudgets/defaults.'))
runtimes=[];stats=[];oldattach=Runtime.attach_stats;oldstats=pm.SearchStatistics
def attach(rt,st):
 v=oldattach(rt,st);runtimes.append((rt,p.runtime_state(rt)));return v
def factory():
 v=SearchStatistics();stats.append(v);return v
try:
 Runtime.attach_stats=attach;pm.SearchStatistics=factory
 av=NativeCoreAvailability(c);player=AlphaBetaPlayer(c,evaluator_override=SemanticAttackEvaluator(c,profile,ec,backend='native'),use_disk_cache=False,use_native_semantic_legality=True,availability_provider=av.for_position,tuning=SearchTuning(use_ordered_qsearch=True,use_ordered_qsearch_in_check=False))
 t=time.perf_counter();value=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=None,max_time_seconds=120,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
 for rt,before in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==before
 record=dict(decision=record_value(value),stats=record_value(stats[0]),seconds=elapsed,root_restored=True)
 write_record(out/'result.json',record);print(value.completed_depth,value.score,value.qnodes,round(elapsed,3),flush=True)
finally:Runtime.attach_stats=oldattach;pm.SearchStatistics=oldstats
