"""Actual Core-owned caller: semantic attack backend and legality attribution."""
import argparse, hashlib, json, random, sys, time,sysconfig,importlib.util
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import generic_chess.native as native
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value, write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from scripts.native_core_availability import NativeCoreAvailability

class CountedSemanticEvaluator(SemanticAttackEvaluator):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.score_calls=self.map_calls=0
    def evaluate(self,state):
        self.score_calls+=1;return super().evaluate(state)
    def _attack_maps(self,state):
        self.map_calls+=1;return super()._attack_maps(state)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
    b=Path(args.output);b.mkdir(parents=True,exist_ok=True)
    if (b/'declaration.json').exists():raise RuntimeError('frozen output exists')
    modes=[('AB-lex',True),('PVS-lex',True),('AB-mixed',True),('PVS-mixed',True)]
    modules={name:native._module() for name,_ in modes}
    declaration=dict(question='Does sourcefirst scalarattack traversal affect actual supported Core Nativelegality readonlyfrontiers while fullattacksets/evaluation stayunchanged?'  ,roots=['1008-ply8','1052-ply8'],modes=modes,orders=2,depths=[2],q=4,hardq=8,nodes=100000,seconds=120,calls=16,expected_seconds='8existingD2 calls <2minutes; currentgeneratedtransfer mayrunconcurrently, ordinaryload disclosed, pairedorder, fullnon-timefields/counters required' ,decision='Complete equal-depth action/score/non-time work must match for evaluator backend attribution; any mismatch investigated without fitting. Both arms retain the same Native legal provider; only runtimeattack loop order differs and complete non-time work must agree. Partial iterations are execution limits, not decision gains. No cap extension/default changes.',scope='Both arms use actual Native semantic attacks and Native legal provider, same weights, original Core history/precedence/order/TT. SameS0-S4 availability primitive, onlyscalarcaptureattack looporder changes. Actual public AlphaBetaPlayer, Core terminal/history/identity/declarations and fresh TT/ordering defaults. Previously observed1051-1052 roots; changed premise is per-instance callback versus module-global injection with seed+15000 walk; adaptive developmental transfer, no independent holdout claim; frozen identical weights/profile, explicit SEMANTIC attack authority. Not legacy evaluation equality or thin-capsule product integration.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    declaration.update(question='After current rule-cost repairs, how much actualCore q4 work/cost comes from existing PVS versus q-ordering?',scope='Changed premise currentNativeclosure andtwoactualCore1008/1052 roots, exposeddevelopment; onlyexisting publictuning flags 2x2PVS/qordered. No newalgorithm/kernel/eval/terminal/default/UIchange. ActualCore q4/hard8 fullhistory.',decision='Sixteen counterbalancedD2 calls; completefull score/action/PV and main/q work/realnullresearch counters inspected. No equality of work required betweenalgorithms; mismatched decisions diagnosed ratherthan tuned or hidden. Timingsnotisolatedrulekernelratio, no WDL.')
    declaration.update(roots=[2026101512,2026101514],depths=[12],budgets=[16,64],nodes=None,calls=64,seconds=None,expected_seconds='Onebounded64call projectproducer max2560queryseconds plussetup, estimated<1hour. Actual earlymate/qhard/unavailability retained, no replacement.',question='How do existingPVS andqordering affect fullCoreq4 completion after currentNative rulecost repairs?',scope='Fourfresh generatedhybridrule roots,8sorteduniformply/fullhistory, samecurrentNativelegality/availability/semanticNativeeval/rulepriceprofile. Onlypublic existing2x2PVS/qordering flags, samebudgets/orders/TT/ordering. NotC-onlyq4; no newkernel or privatecheckhandoff.',decision='Allcompletedfulldecision/iterationwork and errors recorded, same-depth choices compared; classification of differingchoices is algorithm/qwindow sensitivity notautomaticimprovement. No WDL/Elo/default adoption, no result-drivenextension. Earlier1008/1052fixedcells exposeddevelopment, newseeds declared beforeoutcomes.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    declaration.update(question='Does existing PVS add completedusefulsupport to supportedordinary-onlyq ordering?',roots=[2026101512,2026101514],scope='Freshfourgeneratedhybrid8x8fullrule roots,8sorteduniformlegalprefix seed+15000, NativeCore availability/legality/semanticAttackEvaluator fixedrulederivedweights. OnlyexistingPVS and newlysupportedexplicitqscope, 2x2flags. Previousrootplanes immutable; newentry/codehashbound. No UI/default/Elo/newengine/cache/pricefitting.',decision='All64declared16/64sec calls, no nodecap, twoorders. ComparePVS withinlex andwithinmixed andcompareqscope; keepALLsame/loss/unavailable/hard8/time outputs, completedfulltuple/actualnodes/phase/cost. No budgetextension/rescue/gainselector. No samedepthworkequality expected betweenalgorithms. PVS/mixedpositive mayselectexistingoptionalconfig only, not uniformdefault.',base_sha='adabdd73883343545d3078a7313ebea839697ec5',actual_source_files={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path('generic_chess/ai/alphabeta/search.py'),Path('generic_chess/ai/alphabeta/tuning.py')]},expected_seconds='Single64call producer max2560querysec plussetup, estimated<1hour; no artificialsplit/additionalworkers, ordinaryconcurrency. Existingprivateplanes/oldcaps remainfrozen.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    declaration.update(question='Do existingPVS and publicmixedq change exact completed work at the two nonterminal publictransfer horizons?', calls=16, roots=[2026101512,2026101514], depths={'2026101512':2,'2026101514':4}, budgets=[30], maximum_query_seconds=480, expected_seconds='Sixteen bounded calls, max480querysec<1hour; expectedunder5minutes from observedD2/D4 completion. Singlefrozenproducer, no capextension/rescue.', decision='Adaptive exposedsame-rootfixedhorizon attribution control: full score/action/PV/completeddepth, realnullwindow/research/q/runtime/order/eval work and equal-policy horizon. Failure/partial retained, neverincreasebudget. Notnewtransfer or independentholdout; no default or UI adoption.', source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    write_record(b/'declaration.json',declaration)
    roots=[];samples=[]
    for seed in [2026101512,2026101514]:
        g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(seed+15000)
        for _ in range(8):
            if s.result.status.value != 'ongoing':break
            actions=sorted(s.legal_actions(),key=repr)
            if not actions:break
            s.submit(rng.choice(actions))
        if s.result.status.value != 'ongoing' or s.state.ply_count!=8:
            write_record(b/('unavailable-'+str(seed)+'.json'),dict(seed=seed,state=record_value(s.state),result=record_value(s.result),policy='No replacement root'));continue
        roots.append((seed,c,ec,profile,s));samples.append(dict(seed=seed,initial=record_value(s.state),witnesses=record_value(s._search_witnesses),profile=record_value(profile),config=record_value(ec)))
    write_record(b/'samples.json',samples)
    runtimes=[];captured=[];old_attach=SearchPathRuntime.attach_stats;old_stats=pm.SearchStatistics
    imports=queries=0;old_pack=ns.pack_current_position;old_attack=ns.attacked_squares
    from collections import Counter
    physical=Counter();old_transient=ns.transient_legal_actions
    def transient(rules,position):
        audited=ns.transient_legal_actions_audit(rules,position)
        physical['frontiers']+=1;physical['legal_actions']+=len(audited['actions'])
        for key,value in audited.items():
            if key!='actions':physical[key]+=value
        return audited['actions']
    def pack(*a,**kw):
        nonlocal imports;imports+=1;return old_pack(*a,**kw)
    def attack(*a,**kw):
        nonlocal queries;queries+=1;return old_attack(*a,**kw)
    def attach(rt,stats):
        v=old_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return v
    def factory():
        v=SearchStatistics();captured.append(v);return v
    rows=[];start=time.perf_counter()
    try:
        SearchPathRuntime.attach_stats=attach;pm.SearchStatistics=factory;ns.pack_current_position=pack;ns.attacked_squares=attack;ns.transient_legal_actions=transient
        for seed,c,ec,profile,s in roots:
            legal=set(s.legal_actions());saved=s.state
            depth=2 if seed==2026101512 else 4
            for seconds in [30]:
                for order in range(2):
                    for backend,use_native in (modes if order==0 else list(reversed(modes))):
                        p.rr.stopped();runtimes.clear();captured.clear();imports=queries=0;physical.clear();native._MODULE=modules[backend]
                        t=time.perf_counter();ev=CountedSemanticEvaluator(c,profile,ec,backend='native');availability=NativeCoreAvailability(c) if use_native else None;player=AlphaBetaPlayer(c,evaluator_override=ev,tuning=SearchTuning(use_pvs=backend.startswith('PVS'),use_ordered_qsearch=backend.endswith('mixed'),use_ordered_qsearch_in_check=False),use_native_semantic_legality=True,use_disk_cache=False,availability_provider=availability.for_position if availability else None)
                        iterations=[]
                        value=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=None,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8),progress_callback=lambda d,n,q: iterations.append(dict(depth=d,nodes=n,qnodes=q)))
                        elapsed=time.perf_counter()-t
                        assert len(runtimes)==len(captured)==1
                        rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot and s.state==saved and value.action in legal
                        row=dict(seconds_limit=seconds,iterations=iterations,seed=seed,depth_requested=depth,order=order,attack_backend='native',native_legal_requested=True,availability_mode=backend,physical_frontier=dict(physical),availability_counts=None if availability is None else dict(calls=availability.calls,imports=availability.imports,queries=availability.queries,fallbacks=availability.fallbacks,payload_seconds=availability.payload_seconds,query_seconds=availability.query_seconds),provider_created=player.native_legality_provider is not None,caller_seconds=elapsed,score_calls=ev.score_calls,map_calls=ev.map_calls,actual_attack_imports=imports,actual_attack_queries=queries,decision=record_value(value),stats=record_value(captured[0]),root_restored=True)
                        rows.append(row);write_record(b/'result.json',dict(complete=False,rows=rows));print(seed,seconds,order,backend,use_native,value.completed_depth,value.termination_reason,round(elapsed,3),value.score,flush=True)
    finally:
        SearchPathRuntime.attach_stats=old_attach;pm.SearchStatistics=old_stats;ns.pack_current_position=old_pack;ns.attacked_squares=old_attack;ns.transient_legal_actions=old_transient
    write_record(b/'result.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
if __name__=='__main__':main()
