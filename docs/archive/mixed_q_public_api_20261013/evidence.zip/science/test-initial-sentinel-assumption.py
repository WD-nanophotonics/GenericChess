"""Mixed ordering retains actual quiet/checking support and hard abort semantics."""
from dataclasses import replace
import pytest
from ai_fixtures import build_4x4_rooks
from conftest import make_state
from test_qsearch_correctness import _ctx, _evaluator, _king_rook_6, _check_chain_state
from test_qsearch_semantic_effects import transform_rules
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.search import INF, SearchAborted, quiescence
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.limits import SearchLimits


def context(c, state, evaluator, mutable, evasion_order, hard=8):
    ctx = _ctx(c, evaluator, SearchLimits(max_nodes=20000,
        quiescence_max_depth=4, quiescence_hard_max_depth=hard))
    ctx.tuning = SearchTuning(use_ordered_qsearch=True,
                              use_ordered_qsearch_in_check=evasion_order)
    if mutable:
        ctx.runtime = SearchPathRuntime(state, c)
        ctx.runtime.attach_stats(ctx.stats)
    return ctx


def assert_restored(ctx, state):
    if ctx.runtime is not None:
        ctx.runtime.assert_balanced()
        assert ctx.runtime.position == state.position
        assert ctx.runtime.ply_count == state.ply_count
        assert len(ctx.runtime.history) == len(state.history)


@pytest.mark.parametrize('mutable', [False, True])
@pytest.mark.parametrize('evasion_order', [False, True])
def test_scoped_ordering_keeps_quiet_checking_drop_mate(mutable, evasion_order):
    c = build_4x4_rooks()
    state = make_state(c, ['....', 'R...', '....', 'K.k.'], hands=([('R', 1)], ()))
    ctx = context(c, state, _evaluator(c), mutable, evasion_order)
    assert quiescence(state, -INF, INF, 0, 0, ctx) == 999999997
    assert ctx.stats.in_check_qnodes > 0
    assert ctx.stats.checking_drop_qactions > 0
    assert_restored(ctx, state)


@pytest.mark.parametrize('mutable', [False, True])
def test_lexical_evasions_do_not_score_the_hard_limit_checked_leaf(mutable):
    c = _king_rook_6(); state = _check_chain_state(c)
    ctx = context(c, state, _evaluator(c), mutable, False, hard=4)
    # Start at the configured boundary in a genuine checked nonterminal.
    with pytest.raises(SearchAborted, match='^qsearch_check_hard_limit$'):
        quiescence(state, -INF, INF, 0, 4, ctx)
    assert ctx.stats.qsearch_check_hard_limit_aborts == 1
    assert_restored(ctx, state)


@pytest.mark.parametrize('mutable', [False, True])
def test_scoped_ordering_keeps_implicit_semantic_type_change(mutable):
    c = compile_ruleset_for_execution(transform_rules(encoding='effect'))
    state = GameSession(c).state
    cfg = EvaluationConfig(dynamic_mobility_weight=0, anchor_escape_weight=0,
                           promotion_potential_weight=0)
    ev = Evaluator(c, build_ruleset_profile(c, cfg), cfg)
    scores = []
    for enabled in [False, True]:
        ctx = context(c, state, ev, mutable, False)
        ctx.tuning = replace(ctx.tuning, use_ordered_qsearch=enabled)
        ctx.qdepth_limit = 1
        scores.append(quiescence(state, -INF, INF, 0, 0, ctx))
        assert ctx.stats.material_change_qactions > 0
        assert_restored(ctx, state)
    assert scores == [1726, 1726]
