from pathlib import Path
import sys,random,time
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from scripts.native_core_availability import NativeCoreAvailability
from generic_chess.ai.alphabeta import search as sm,player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
b=Path(__file__).resolve().parent;out=b/'old-flag-parity';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
ns=dict(sm.__dict__);exec(compile((b/'before-search.py').read_text(encoding='utf-8'),'<actual-before-search>','exec'),ns);oldroot=pm.run_root_search
write_record(out/'declaration.json',dict(question='Do default/previousall-q options preserveactualcompletebehavior?',roots=[1008,1052],calls=8,max_depth=2,seconds=30,max_run_seconds=240,nodecap=100000,q=4,hardq=8,arms=['actualsavedbefore','publicnewdefault'],qflags=[False,True],scope='Eightactual2x2x2calls only, frozen30sec percall beforeexecution. RelatedknownD2cost~1-5sec, total240secguard<1hour. First120secproposal rejectedBEFOREexecution byautoreview citing32calls; no output/query existed. This boundedalternative preservesD2/fullhistory/nodeconditions; no olddata/budget extension orconsultbypass.'))
rows=[]
try:
 for seed in [1008,1052]:
  g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);cfg=p.EvaluationConfig();profile=p.build_ruleset_profile(c,cfg);s=p.GameSession(c);rng=random.Random(seed+7000)
  for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
  for ordered in [False,True]:
   for mode in ['before','after']:
    p.rr.stopped();pm.run_root_search=ns['run_root_search'] if mode=='before' else oldroot;av=NativeCoreAvailability(c);player=AlphaBetaPlayer(c,evaluator_override=SemanticAttackEvaluator(c,profile,cfg,backend='native'),use_disk_cache=False,use_native_semantic_legality=True,availability_provider=av.for_position,tuning=SearchTuning(use_ordered_qsearch=ordered));t=time.perf_counter();v=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=100000,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8));rows.append(dict(seed=seed,ordered=ordered,mode=mode,decision=record_value(v),seconds=time.perf_counter()-t));write_record(out/'result.json',dict(complete=False,rows=rows));print(seed,ordered,mode,v.completed_depth,v.score,v.qnodes,flush=True)
finally:pm.run_root_search=oldroot
fields=['action','score','principal_variation','completed_depth','nodes','qnodes','choice_kind','declaration','ordering_calls','ordered_moves','qsearch_check_hard_limit_aborts','result_ordinary_qdepth','result_check_hard_qdepth']
for seed in [1008,1052]:
 for ordered in [False,True]:
  pair=[x for x in rows if x['seed']==seed and x['ordered']==ordered];assert all(pair[0]['decision'][f]==pair[1]['decision'][f] for f in fields)
write_record(out/'result.json',dict(complete=True,rows=rows,compared_fields=fields,all_exact=True))
