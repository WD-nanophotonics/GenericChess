import json,sys,random,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value as rec,write_record as write
from collections import Counter
b=Path(__file__).resolve().parent
folder=b/"public-pvs-mixed-transfer"; data=json.loads((folder/"result.json").read_text());assert data["complete"]
rows=data["rows"];assert len(rows)==48
samples=json.loads((folder/"samples.json").read_text());cache={}; replay=[];samplechecked=set()
for row in rows:
 seed=row["seed"];d=row["decision"];key=(seed,json.dumps(d["principal_variation"],sort_keys=True))
 if key not in cache:
  g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset="bilateral_random",allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);s=p.GameSession(c);rng=random.Random(seed+15000)
  for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
  sample=next(x for x in samples if x["seed"]==seed);assert rec(s.state)==sample["initial"];assert rec(s._search_witnesses)==sample["witnesses"];samplechecked.add(seed)
  steps=[]
  for action_json in d["principal_variation"]:
   actions=[a for a in s.legal_actions() if rec(a)==action_json];assert len(actions)==1
   s.submit(actions[0]);steps.append(dict(action=action_json,result=rec(s.result)))
  cache[key]=dict(steps=steps,end=rec(s.result),pv_length=len(steps),independent_core_legal=True)
 assert d["principal_variation"] and d["action"]==d["principal_variation"][0]
 assert row["root_restored"] and row["stats"]["runtime_pushes"]==row["stats"]["runtime_pops"]
 assert row["decision"]["native_legality_fallbacks"]==0
 replay.append(dict(seed=seed,seconds=row["seconds_limit"],order=row["order"],mode=row["availability_mode"],replay=cache[key]))
fields=["action","score","principal_variation","completed_depth","choice_kind","declaration","result_ordinary_qdepth","result_check_hard_qdepth"]
pairs=[]
for seed in sorted(samplechecked):
 for seconds in [16,64]:
  for order in [0,1]:
   cell={x["availability_mode"]:x for x in rows if (x["seed"],x["seconds_limit"],x["order"])==(seed,seconds,order)}
   for q in ["lex","mixed"]:
    a,v=cell["AB-"+q],cell["PVS-"+q];assert all(a["decision"][f]==v["decision"][f] for f in fields)
    pairs.append(dict(axis="PVS",seed=seed,seconds=seconds,order=order,q=q,fulltuple_exact=True,depth=a["decision"]["completed_depth"],exits=[a["decision"]["termination_reason"],v["decision"]["termination_reason"]]))
   for mode in ["AB","PVS"]:
    a,v=cell[mode+"-lex"],cell[mode+"-mixed"];assert all(a["decision"][f]==v["decision"][f] for f in fields)
    pairs.append(dict(axis="qscope",seed=seed,seconds=seconds,order=order,mode=mode,fulltuple_exact=True,depth=a["decision"]["completed_depth"],exits=[a["decision"]["termination_reason"],v["decision"]["termination_reason"]]))
unavailable=json.loads((folder/"unavailable-2026101511.json").read_text());assert unavailable["policy"]=="No replacement root"
out=dict(complete=True,declared_calls=64,actual_calls=48,unavailable_cells=16,unavailable_seed=2026101511,elapsed_seconds=data["elapsed_seconds"],exit_counts=dict(Counter(x["decision"]["termination_reason"] for x in rows)),all_48_decision_pvs_core_legal=True,unique_pvs=len(cache),all_source_roots_exact=True,all_restored=True,all_native_legality_fallbacks_zero=True,fulltuple_fields=fields,pairs=pairs,replays=replay,scope="48actualqueries/16retainedunavailable; all24PVS and24qscope contrasts exactfulltuple atsamecompleteddepth, no addedhorizon/action. IndependentCorelegal/PVterminal verification, not fullWDL/Elo; defaultrequire_full_pv remainsFalse; originalresult/exit/time/work retained.")
write(b/"public-plane-verification.json",out)
print(json.dumps({k:v for k,v in out.items() if k not in ["pairs","replays"]},indent=2))
