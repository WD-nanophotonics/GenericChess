from pathlib import Path
import sys,time,json,importlib.util,hashlib
from dataclasses import asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/eager-binding-20261011'
spec=importlib.util.spec_from_file_location('qa',B/'q-attribution.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.actions import action_to_dict
original_push=SearchPathRuntime.push
trace=[];positions={};orders=[]
def ph(rt):
 text=repr(rt.position);key=hashlib.sha256(text.encode()).hexdigest();positions.setdefault(key,rt.position);return key
def pushed(rt,action,checkpoint=None):
 trace.append(dict(position=ph(rt),depth=rt.depth,action=m.m.label(action),typed=action_to_dict(action)))
 return original_push(rt,action,checkpoint)
def order(self,state,actions,*args,**kwargs):
 out=m.aligned_order(self,state,actions,*args,**kwargs);orders.append(dict(kind='main',position=hashlib.sha256(repr(state.position).encode()).hexdigest(),actions=[m.m.label(x) for x in out],typed=[repr(x) for x in out],depth=args[1],tt=None if args[2] is None else repr(args[2]),killers=[dict(label=m.m.label(x),typed=repr(x)) for x in self._killers.get(args[1],[])],history=[dict(label=m.m.label(x),value=self.history_value(state.position.side_to_move,x),killer=x in self._killers.get(args[1],[])) for x in out]));return out
def qorder(state,actions,ply,ctx):
 out=m.aligned_q(state,actions,ply,ctx);orders.append(dict(kind='q',position=ph(ctx.runtime),actions=[m.m.label(x) for x in out]));return out
def main():
 start=time.perf_counter();r=dict(complete=False,declaration=(B/'q-trace-plan.md').read_text(),rows=[])
 for seed in (2026101103,2026101104):
  g=m.generate_game(m.GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));old=g.compiled_ruleset;new=m.compile_legacy_ruleset_for_semantic_execution(g.ruleset);a,b=m.initial_state(old),m.initial_state(new);wa,wb=[a.position],[b.position]
  for ply in range(6):
   aa,bb=m.groups(a,old),m.groups(b,new);k=sorted(aa,key=lambda x:repr((getattr(aa[x][0],'from_square',None),aa[x][0].to_square,getattr(aa[x][0],'promotion_target_id',None),getattr(aa[x][0],'base_type_id',None))))[(seed+ply)%len(aa)];a=m.apply_action(a,aa[k][0],old);b=m.apply_action(b,bb[k][0],new);wa.append(a.position);wb.append(b.position)
  for arm,c,state,w in [('legacy',old,a,tuple(wa)),('semantic',new,b,tuple(wb))]:
   m.stopped();assert time.perf_counter()-start<120;trace.clear();orders.clear();positions.clear();stats=m.SearchStatistics()
   action,score,pv,reason=m.search.run_root_search(state,c,m.m.Material(g.ruleset.piece_types),m.TranspositionTable(max_entries=65536),m.SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=10,quiescence_max_depth=1,quiescence_hard_max_depth=4),None,stats,use_tt=True,use_ordering=True,tuning=m.SearchTuning(use_root_tactical=False),_history_witnesses=w)
   r['rows'].append(dict(seed=seed,arm=arm,score=score,reason=reason,stats=asdict(stats),trace=list(trace),orders=list(orders)));m.write_record(B/'q-heuristic-trace.json',r)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-start);m.write_record(B/'q-heuristic-trace.json',r)
if __name__=='__main__':
 SearchPathRuntime.push=pushed;m.ordering.MoveOrderer.order=order;m.search._order_qactions=qorder
 try:main()
 finally:SearchPathRuntime.push=original_push;m.ordering.MoveOrderer.order=m.original_order;m.search._order_qactions=m.original_q
