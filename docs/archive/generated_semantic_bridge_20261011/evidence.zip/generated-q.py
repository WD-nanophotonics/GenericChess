from pathlib import Path
import sys,time,json,importlib.util
from dataclasses import asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/eager-binding-20261011'
spec=importlib.util.spec_from_file_location('generated_search',B/'generated-search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess import generate_game,GeneratorConfig,compile_legacy_ruleset_for_semantic_execution,initial_state,legal_actions,apply_action
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped

def visible(a):return (getattr(a,'from_square',None),a.to_square,getattr(a,'promotion_target_id',None),getattr(a,'base_type_id',None))
def main():
 started=time.perf_counter();r=dict(complete=False,declaration=(B/'generated-q-plan.md').read_text(),roots=[],rows=[])
 for seed in range(2026101101,2026101105):
  g=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));old=g.compiled_ruleset;new=compile_legacy_ruleset_for_semantic_execution(g.ruleset);p=NativeSemanticLegalityProvider.try_create(new,strict=True);a,b=initial_state(old),initial_state(new);wa,wb=[a.position],[b.position]
  snapshots=[(0,a,b,tuple(wa),tuple(wb))]
  for ply in range(6):
   aa={visible(x):x for x in legal_actions(a,old)};bb={visible(x):x for x in legal_actions(b,new)};assert set(aa)==set(bb)
   if a.terminal_status.is_terminal or not aa:break
   key=sorted(aa,key=repr)[(seed+ply)%len(aa)];a=apply_action(a,aa[key],old);b=apply_action(b,bb[key],new);assert a.position==b.position;wa.append(a.position);wb.append(b.position)
  snapshots.append((a.ply_count,a,b,tuple(wa),tuple(wb)))
  for ply,a,b,wa,wb in snapshots:
   r['roots'].append(dict(seed=seed,ply=ply,promotion_present=any(x.promoted for x in a.position.board if x),hand_stock=[list(h.items()) for h in a.position.hands],history_length=len(a.history),position_equal=True))
   for q in (0,1):
    arms=[('legacy',old,a,wa,None),('semantic',new,b,wb,None)]+([('hybrid',new,b,wb,p)] if p else [])
    for arm,c,state,witnesses,provider in arms:
     stopped();assert time.perf_counter()-started<480
     if provider:provider._metrics_local.public_cache={}
     stats=SearchStatistics();t=time.perf_counter();action,score,pv,reason=run_root_search(state,c,m.Material(g.ruleset.piece_types),TranspositionTable(max_entries=65536),SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=10,quiescence_max_depth=q,quiescence_hard_max_depth=4),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=witnesses,legal_binding_provider=provider)
     assert action is None or action in legal_actions(state,c)
     r['rows'].append(dict(seed=seed,ply=ply,q=q,arm=arm,action=None if action is None else m.label(action),score=score,pv=[m.label(x) for x in pv],reason=reason,wall_seconds=time.perf_counter()-t,stats=asdict(stats)));write_record(B/'generated-q.json',r)
    print(seed,ply,q,flush=True)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started);write_record(B/'generated-q.json',r)
if __name__=='__main__':main()
