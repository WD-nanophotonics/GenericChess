from pathlib import Path
import sys,json,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));B=ROOT/'.local_agent/eager-binding-20261011'
from conftest import make_ruleset,king_type,T
from generic_chess import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution,initial_state,legal_actions,apply_action
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.declarations import available_declarations
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
def visible(action):return (getattr(action,'from_square',None),action.to_square,getattr(action,'promotion_target_id',None),getattr(action,'base_type_id',None))
def grouped(state,c):
 out={}
 for a in legal_actions(state,c):out.setdefault(visible(a),[]).append(a)
 return out
def same(a,b,ca,cb):
 assert a.position==b.position and a.ply_count==b.ply_count and a.terminal_status==b.terminal_status
 assert len(a.history)==len(b.history);mapping={}
 for x,y in zip(a.history,b.history):
  assert x.actor==y.actor and x.gave_check==y.gave_check
  if x.action_signature:assert visible(action_from_dict(json.loads(x.action_signature)))==visible(action_from_dict(json.loads(y.action_signature)))
  if x.position_key in mapping:assert mapping[x.position_key]==y.position_key
  mapping[x.position_key]=y.position_key
 assert {mapping[k]:n for k,n in a.repetition_counts}==dict(b.repetition_counts)
 assert available_declarations(a,ca)==available_declarations(b,cb)
 for state,c in ((a,ca),(b,cb)):
  rt=SearchPathRuntime.from_state(state,c);assert rt.history_witness_misses==0;before=(rt.position,rt.search_key(),tuple(rt.history),rt.runtime_hash,dict(rt.repetition_counts))
  for action in legal_actions(state,c):
   rt.push(action);rt.pop();assert (rt.position,rt.search_key(),tuple(rt.history),rt.runtime_hash,dict(rt.repetition_counts))==before
 return mapping
started=time.perf_counter();rules=make_ruleset(4,[king_type(),T('P',LeapAtom((1,0)),RayAtom((1,0)))],lines=['...k','....','.P..','K...']);old=compile_ruleset_for_execution(rules);new=compile_legacy_ruleset_for_semantic_execution(rules);a,b=initial_state(old),initial_state(new);aa,bb=grouped(a,old),grouped(b,new);assert set(aa)==set(bb);rows=[];same(a,b,old,new)
for key,bindings in bb.items():
 for binding in bindings:
  stopped();assert time.perf_counter()-started<10
  x=apply_action(a,aa[key][0],old);y=apply_action(b,binding,new);same(x,y,old,new);ra,rb=grouped(x,old),grouped(y,new);assert set(ra)==set(rb);leaves=[]
  for reply_key,replies in rb.items():
   for reply in replies:
    u=apply_action(x,ra[reply_key][0],old);v=apply_action(y,reply,new);same(u,v,old,new);leaves.append(dict(reply=action_to_dict(reply),history=repr(v.history),equivalent=True))
  rows.append(dict(action=action_to_dict(binding),visible=repr(key),replies=leaves,equivalent=True))
prob=[dict(visible=repr(k),legacy_probability=1/len(aa),typed_probability=len(v)/sum(map(len,bb.values())),multiplicity=len(v)) for k,v in bb.items()]
write_record(B/'successor-probe.json',dict(complete=True,declaration=(B/'successor-plan.md').read_text(),typed_root_edges=len(rows),typed_reply_edges=sum(len(x['replies']) for x in rows),unique_root_choices=len(aa),rows=rows,uniform_probabilities=prob,total_variation=.5*sum(abs(x['legacy_probability']-x['typed_probability']) for x in prob),elapsed_seconds=time.perf_counter()-started))
print(len(rows),sum(len(x['replies']) for x in rows),prob)
