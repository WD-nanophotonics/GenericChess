from pathlib import Path
import sys,json,importlib.util
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));B=ROOT/'.local_agent/eager-binding-20261011'
from conftest import make_ruleset,king_type,T,sq
from generic_chess import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution,initial_state,legal_actions,apply_action
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.actions import BoardMove,action_to_dict,action_from_dict
from scripts.research_record import write_record
from scripts.search_backend_comparison import minimal_ab
spec=importlib.util.spec_from_file_location('generated_search',B/'generated-search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rules=make_ruleset(4,[king_type(),T('P',LeapAtom((1,0)),RayAtom((1,0)))],lines=['...k','....','.P..','K...'])
old=compile_ruleset_for_execution(rules);new=compile_legacy_ruleset_for_semantic_execution(rules);a=initial_state(old);b=initial_state(new)
aa=legal_actions(a,old);bb=legal_actions(b,new);group={}
for x in bb:group.setdefault(m.label(x),[]).append(x)
assert {m.label(x) for x in aa}==set(group)
children=[]
for x in aa:
 expected=apply_action(a,x,old)
 for y in group[m.label(x)]:
  actual=apply_action(b,y,new);assert actual.position==expected.position and actual.terminal_status==expected.terminal_status
  assert action_from_dict(action_to_dict(y))==y
  children.append(dict(move=m.label(x),typed_action=action_to_dict(y),history_signature=actual.history[-1].action_signature))
try:apply_action(b,BoardMove(sq(1,1),sq(2,1)),new)
except Exception as ex:ambiguous=dict(type=type(ex).__name__,message=str(ex))
else:ambiguous=None
rows=[]
for arm,c in [('legacy',old),('semantic',new)]:
 board=m.Board(c,rules.piece_types);v=minimal_ab(board,2,seconds=10,node_limit=100000,trace=True,cooperative=True);rows.append(dict(arm=arm,**v))
write_record(B/'overlap-probe.json',dict(complete=True,declaration=(B/'overlap-plan.md').read_text(),legacy_actions=len(aa),semantic_actions=len(bb),duplicates={k:len(v) for k,v in group.items() if len(v)>1},children=children,ambiguous_legacy_action=ambiguous,search=rows))
print(len(aa),len(bb),ambiguous);print([(x['arm'],x['work']) for x in rows])
