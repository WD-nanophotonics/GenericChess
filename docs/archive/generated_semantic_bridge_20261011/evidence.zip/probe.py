from pathlib import Path
import sys,time,inspect,hashlib,json,pickle
from dataclasses import replace,FrozenInstanceError
from unittest.mock import patch
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard,supported_search
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/eager-binding-20261011';cls=se._ActionBinding;fields=tuple(cls.__dataclass_fields__)
source='def fast('+','.join(fields)+'):\n    x=new(cls)\n'+''.join('    set_'+f+'(x,'+f+')\n' for f in fields)+'    return x\n'
ns={'new':object.__new__,'cls':cls};ns.update({'set_'+f:getattr(cls,f).__set__ for f in fields});exec(source,ns);fast=ns['fast']
def err(fn):
 try:return ['return',fn()]
 except Exception as e:return [type(e).__name__,str(e)]
def prep(case):
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));return c,CoreBoard(case,c)
def sig(row):
 return {k:row[k] for k in ('move','score','pv','reason','node_definition')}|{'work':{k:v for k,v in row['statistics'].items() if not k.endswith('_seconds') and not k.startswith('time_to_')}}
def main():
 started=time.perf_counter();r=dict(complete=False,declaration=(B/'plan.md').read_text(),candidate=source,contracts=[],micro=[],search=[]);args=[]
 for case in CASES:
  stopped();c,b=prep(case);p=NativeSemanticLegalityProvider.try_create(c,strict=True);assert p
  bindings=p(b.initial.position,b.initial.ply_count)
  for public,(a,old) in bindings:
   values=tuple(getattr(old,f) for f in fields);new=fast(*values);assert type(new) is cls and new==old and repr(new)==repr(old)
   assert err(lambda:hash(new))==err(lambda:hash(old))
   assert replace(new,target=old.target)==replace(old,target=old.target)
   assert pickle.loads(pickle.dumps(new))==old
   assert err(lambda:setattr(new,'target',-1))==err(lambda:setattr(old,'target',-1))
   args.append(values)
  r['contracts'].append(dict(root=case['id'],bindings=len(bindings),exact=True))
 r['missing_argument']=[err(lambda:cls()),err(lambda:fast())]
 # Function names differ in argument errors; same missing10 fields. Construction helper is internal only.
 for arm in ('original','descriptor','descriptor','original'):
  stopped();fn=cls if arm=='original' else fast;t=time.perf_counter()
  for _ in range(100):
   for values in args:fn(*values)
  r['micro'].append(dict(arm=arm,allocations=100*len(args),seconds=time.perf_counter()-t))
 for name in ('chess-middle','shogi-drop'):
  case=next(x for x in CASES if x['id']==name);c,b=prep(case)
  for arm in ('original','descriptor','descriptor','original'):
   stopped();assert time.perf_counter()-started<120
   p=NativeSemanticLegalityProvider.try_create(c,strict=True);assert p;p._metrics_local.public_cache={};b=CoreBoard(case,c)
   with patch.object(se,'_ActionBinding',cls if arm=='original' else fast):v=supported_search(b,2,30,100000,provider=p)
   assert b.restored();r['search'].append(dict(root=name,arm=arm,**v));write_record(B/'probe.json',r);print(name,arm,v['wall_seconds'],flush=True)
  rows=[x for x in r['search'] if x['root']==name];assert all(sig(x)==sig(rows[0]) for x in rows)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(B/'probe.json',r)
if __name__=='__main__':main()
