from pathlib import Path
import json,hashlib,collections
B=Path(__file__).resolve().parent
names=('generated-q-curves','q-depth-attribution','matched-hash','token-cache','alternate-history','setup-scaling','history-tt')
r={n:json.loads((B/(n+'.json')).read_text()) for n in names}
expected=(96,6,30,30,18,36,24)
for n,count in zip(names,expected):
 assert r[n]['complete'] and len(r[n]['rows'])==count,(n,count)
for n in names:
 for x in r[n]['rows']:
  if 'stats' in x:
   assert x['stats']['runtime_depth_balanced']
   assert x['stats']['runtime_pushes']==x['stats']['runtime_pops']
   assert x['stats']['native_legality_fallbacks']==0
for n in ('matched-hash','token-cache'):
 for seed in (2026101103,2026101104):
  rows=[x for x in r[n]['rows'] if x['seed']==seed]
  a=rows[0]
  for x in rows:
   assert (x['action'],x['score'],x['pv'],x['reason'])==(a['action'],a['score'],a['pv'],a['reason'])
   for k in ('nodes','qnodes','runtime_pushes','evaluation_calls'):
    assert x['stats'][k]==a['stats'][k]
assert sum(x['oracle_calls'] for x in r['matched-hash']['rows'])==1420
assert all(x['equal'] for x in r['setup-scaling']['rows'])
for n in ('alternate-history','history-tt'):
 for arm in ('legacy','semantic'):
  for setup in (None,'a-file','z-file'):
   rows=[x for x in r[n]['rows'] if x['arm']==arm and x['setup']==setup]
   a=rows[0]
   assert all((x['action'],x['score'],x['pv'],x['reason'])==(a['action'],a['score'],a['pv'],a['reason']) for x in rows)
   if n=='history-tt':
    for x in rows:
     s=x['stats']
     if x['mode']=='noTT':assert s['tt_probes']==s['tt_stores']==0
     elif setup and x['mode']=='old_default_only':assert s['tt_probes']==0 and s['tt_skipped_ineligible_nodes']>0
     else:assert s['tt_eligible_nodes']>0 and s['tt_probes']>0 and s['tt_hits']==8 and s['tt_skipped_ineligible_nodes']==0
rows=r['q-depth-attribution']['rows'];a=rows[0]
assert all((x['action'],x['score'],x['pv'],x['reason'])==(a['action'],a['score'],a['pv'],a['reason']) and x['stats']['completed_depth']==4 for x in rows)
assert a['score']==600
curves=r['generated-q-curves']['rows']
assert all(x['action'] is not None and x['stats']['completed_depth']>=1 and x['reason']=='time_limit' for x in curves)
assert all(x['stats']['native_legality_enabled']==(x['arm']=='hybrid') for x in curves)
assert all(x['action']==a['action'] and x['score']==a['score'] for x in curves if x['seed']==2026101101 and x['ply']==6 and x['seconds']==1 and x['arm']=='hybrid')
out=dict(complete=True,counts=dict(zip(names,expected)),q1_time_reasons=dict(collections.Counter(x['reason'] for x in curves)),hash_oracle_children=1420,history_guarded_tt='four alternate arm/setup pairs restored actual lookup/store with8hits; defaults unchanged; noTT controls match returns',input_hashes={n:hashlib.sha256((B/(n+'.json')).read_bytes()).hexdigest() for n in names})
(B/'final-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print(out)
