from pathlib import Path
import sys,time,json,importlib.util
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));B=ROOT/'.local_agent/eager-binding-20261011'
from conftest import make_ruleset,king_type,T
from dataclasses import replace
from generic_chess import generate_game,GeneratorConfig,compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution,initial_state,apply_action,legal_actions
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.search_backend_comparison import minimal_ab,audit_pair
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
spec=importlib.util.spec_from_file_location('generated_search',B/'generated-search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class CanonicalBoard(m.Board):
 def actions(self):
  raw=super().actions();first={}
  for label,a in raw:first.setdefault(label,a)
  return list(first.items())
def configure(c,rules,state,witnesses,canonical=False):
 assert not rules.semantic_actions
 b=(CanonicalBoard if canonical else m.Board)(c,rules.piece_types);b.initial=state;b.witnesses=tuple(witnesses);b.runtime=SearchPathRuntime.from_state(state,c,history_witnesses=b.witnesses);return b
def main():
 started=time.perf_counter();r=json.loads((B/'canonical-probe-partial.json').read_text());r['resume']='Keep six completed overlap fixtures; record invalid remaining starts instead of changing them; run untouched four generator fixtures.';corpus=[]
 for dx,dy in ((1,0),(1,1)):
  for steps in (1,2):
   for disposition in ('capture_to_hand','remove_from_game'):
    rules=make_ruleset(4,[king_type(),T('P',LeapAtom((dx,dy)),RayAtom((dx,dy),max_steps=steps))],lines=['...k','....','.P..','K...']);rules=replace(rules,capture_disposition=disposition);corpus.append((f'overlap-{dx}-{dy}-{steps}-{disposition}',rules,True))
 for seed in range(2026101101,2026101105):
  g=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));corpus.append((str(seed),g.ruleset,False))
 for name,rules,overlap in corpus:
  if any(x['name']==name for x in r['roots']):continue
  try:old=compile_ruleset_for_execution(rules)
  except Exception as ex:
   r.setdefault('invalid_declared_roots',[]).append(dict(name=name,type=type(ex).__name__,message=str(ex)));continue
  new=compile_legacy_ruleset_for_semantic_execution(rules);a,b=initial_state(old),initial_state(new);wa,wb=[a.position],[b.position];root=dict(name=name,aliases=[],audit_positions=0);r['roots'].append(root)
  for ply in range(1 if overlap else 7):
   stopped();assert time.perf_counter()-started<120
   aa={m.label(x):x for x in legal_actions(a,old)};bb={}
   for x in legal_actions(b,new):bb.setdefault(m.label(x),[]).append(x)
   assert set(aa)==set(bb)
   for label,actions in bb.items():
    expected=apply_action(a,aa[label],old)
    for action in actions:
     actual=apply_action(b,action,new);assert expected.position==actual.position and expected.terminal_status==actual.terminal_status
   root['aliases'].append(dict(ply=ply,unique=len(aa),typed=sum(map(len,bb.values()))))
   if overlap:root['audit_positions']=audit_pair(configure(old,rules,a,wa),configure(new,rules,b,wb,True),2)
   if ply in (0,6):
    for arm,c,state,witnesses,canonical in [('legacy',old,a,wa,False),('semanticraw',new,b,wb,False),('canonical',new,b,wb,True)]:
     board=configure(c,rules,state,witnesses,canonical);v=minimal_ab(board,2,seconds=10,node_limit=100000,trace=True,cooperative=True);r['rows'].append(dict(name=name,ply=ply,arm=arm,**v))
    rows=[x for x in r['rows'] if x['name']==name and x['ply']==ply];assert rows[0]['trace_sha256']==rows[2]['trace_sha256'] and rows[0]['work']==rows[2]['work']
   write_record(B/'canonical-probe.json',r)
   if overlap or ply==6 or a.terminal_status.is_terminal or not aa:break
   key=sorted(aa,key=lambda k:repr((getattr(aa[k],'from_square',None),aa[k].to_square,getattr(aa[k],'promotion_target_id',None),getattr(aa[k],'base_type_id',None))))[(int(name)+ply)%len(aa)];a=apply_action(a,aa[key],old);b=apply_action(b,bb[key][0],new);wa.append(a.position);wb.append(b.position)
  print(name,root['audit_positions'],flush=True)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started);write_record(B/'canonical-probe.json',r)
if __name__=='__main__':main()
