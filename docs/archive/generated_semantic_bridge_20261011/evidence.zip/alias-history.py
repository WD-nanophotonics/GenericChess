from pathlib import Path
import sys,json,time,importlib.util
from dataclasses import replace,asdict
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];B=R/'.local_agent/eager-binding-20261011'
from conftest import make_ruleset,king_type,T
from generic_chess import compile_legacy_ruleset_for_semantic_execution,initial_state,legal_actions,apply_action
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.tuning import SearchTuning
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
spec=importlib.util.spec_from_file_location('m',B/'generated-search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
t=time.perf_counter();r=dict(complete=False,declaration=(B/'alias-history-plan.md').read_text(),roots=[],rows=[])
for policy in ('draw','continuous_check_loss'):
 rules=replace(make_ruleset(4,[king_type(),T('P',LeapAtom((1,0)),RayAtom((1,0)))],lines=['...k','....','.P..','K...']),repetition_policy=policy)
 c=compile_legacy_ruleset_for_semantic_execution(rules);root=initial_state(c)
 groups={}
 for a in legal_actions(root,c):groups.setdefault(m.label(a),[]).append(a)
 aliases=next(xs for xs in groups.values() if len(xs)==2);states=[apply_action(root,a,c) for a in aliases];keys=[SearchPathRuntime.from_state(s,c).search_key() for s in states]
 assert states[0].position==states[1].position and states[0].repetition_counts==states[1].repetition_counts and keys[0]==keys[1]
 assert states[0].history[-1].action_signature!=states[1].history[-1].action_signature
 r['roots'].append(dict(policy=policy,exact_key_equal=True,typed_signatures_distinct=True))
 for q in (0,1):
  shared=TranspositionTable(max_entries=4096)
  for mode in ('cold','transfer'):
   for i,s in enumerate(states):
    stopped();assert time.perf_counter()-t<60
    stats=SearchStatistics();table=TranspositionTable(max_entries=4096) if mode=='cold' else shared
    a,v,p,reason=run_root_search(s,c,m.Material(rules.piece_types),table,SearchLimits(max_depth=2,max_nodes=10000,max_time_seconds=2,quiescence_max_depth=q,quiescence_hard_max_depth=4),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
    assert a in legal_actions(s,c)
    r['rows'].append(dict(policy=policy,q=q,mode=mode,alias=i,action=m.label(a),score=v,pv=[m.label(x) for x in p],reason=reason,stats=asdict(stats)))
write_record(B/'alias-history-partial.json',r)
for policy in ('draw','continuous_check_loss'):
 for q in (0,1):
  rows=[x for x in r['rows'] if x['policy']==policy and x['q']==q];a=rows[0]
  print(policy,q,[(x['mode'],x['alias'],x['action'],x['score'],x['pv'],x['reason']) for x in rows])
r.update(complete=True,original_warm_parity_assertion_failed=True,scope='repeat exposed audit to retain missing failure output; warm parity not assumed',elapsed_seconds=time.perf_counter()-t);write_record(B/'alias-history.json',r);print([(x['policy'],x['q'],x['mode'],x['alias'],x['stats']['tt_hits'],x['stats']['nodes']) for x in r['rows']])
