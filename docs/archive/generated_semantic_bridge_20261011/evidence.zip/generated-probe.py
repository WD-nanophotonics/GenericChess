from pathlib import Path
import sys,time,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.compiler import _compile_semantic_ruleset_from_baseline,_validate_semantic_initial_position,compile_semantic_ruleset
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.attacks import is_square_attacked,is_in_check
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.coordinates import Square
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
B=ROOT/'.local_agent/eager-binding-20261011'
def label(a):
 return (getattr(a,'from_square',None),a.to_square,getattr(a,'promotion_target_id',None),getattr(a,'base_type_id',None))
def groups(aa):
 out={}
 for a in aa:out.setdefault(label(a),[]).append(a)
 return out
def main():
 start=time.perf_counter();r=dict(complete=False,declaration=(B/'generated-plan.md').read_text(),rows=[])
 for seed in range(2026101101,2026101105):
  stopped();g=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));base=g.compiled_ruleset
  try:compile_semantic_ruleset(g.ruleset)
  except Exception as ex: public_error=dict(type=type(ex).__name__,message=str(ex))
  else:raise AssertionError('old public gate unexpectedly changed')
  c=_compile_semantic_ruleset_from_baseline(base,g.ruleset);_validate_semantic_initial_position(c)
  engine=SemanticEngine(c)
  row=dict(seed=seed,fingerprint=base.ruleset_fingerprint,public_error=public_error,capabilities=repr(c.ir.capabilities),states=[],mismatches=[]);r['rows'].append(row)
  a=initial_state(base);b=initial_state(c)
  for ply in range(7):
   stopped();assert time.perf_counter()-start<120
   x=groups(legal_actions(a,base));y=groups(legal_actions(b,c));both=set(x)&set(y)
   item=dict(ply=ply,position_equal=a.position==b.position,terminal_equal=a.terminal_status==b.terminal_status,repetition_equal=a.repetition_counts==b.repetition_counts,legacy_actions=sum(map(len,x.values())),semantic_actions=sum(map(len,y.values())),coordinate_sets_equal=set(x)==set(y),child_mismatches=[],child_position_mismatches=[],child_terminal_mismatches=[],attack_mismatches=[],history_checks_equal=[(h.actor,h.gave_check) for h in a.history]==[(h.actor,h.gave_check) for h in b.history]);row['states'].append(item)
   for side in (0,1):
    for sq in ((i%6,i//6) for i in range(36)):
     if is_square_attacked(a.position,Square(*sq),side,base)!=engine.is_square_attacked(b.position,sq[1]*6+sq[0],side):item['attack_mismatches'].append((side,sq))
   for k in sorted(both,key=repr):
    ca=apply_action(a,x[k][0],base)
    for action in y[k]:
     cb=apply_action(b,action,c)
     if ca.position!=cb.position:item['child_position_mismatches'].append(repr(k))
     if ca.terminal_status!=cb.terminal_status:item['child_terminal_mismatches'].append(repr(k))
     if ca.position!=cb.position or ca.terminal_status!=cb.terminal_status or ca.repetition_counts!=cb.repetition_counts:item['child_mismatches'].append(repr(k))
   if not all(item[k] for k in ('position_equal','terminal_equal','repetition_equal','coordinate_sets_equal','history_checks_equal')) or item['child_mismatches'] or item['attack_mismatches']:row['mismatches'].append(ply)
   item['history_equivalence_relation_equal']=[[h.position_key==j.position_key for j in a.history] for h in a.history]==[[h.position_key==j.position_key for j in b.history] for h in b.history]
   write_record(B/'generated-probe.json',r)
   if ply==6 or a.terminal_status.is_terminal or not both:break
   k=sorted(both,key=repr)[(seed+ply)%len(both)];a=apply_action(a,x[k][0],base);b=apply_action(b,y[k][0],c)
  print(seed,len(row['states']),row['mismatches'],flush=True)
 r.update(complete=True,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.perf_counter()-start);write_record(B/'generated-probe.json',r)
if __name__=='__main__':main()
