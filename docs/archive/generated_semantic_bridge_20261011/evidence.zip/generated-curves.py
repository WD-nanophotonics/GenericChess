from pathlib import Path
import sys,time,json,importlib.util
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/eager-binding-20261011'
spec=importlib.util.spec_from_file_location('generated_search',B/'generated-search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from scripts.search_backend_comparison import minimal_ab,supported_search
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
from generic_chess import generate_game,GeneratorConfig,compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
def main():
 start=time.perf_counter();r=json.loads((B/'generated-curves-partial.json').read_text());r['resume']='Keep all36completed curve cells from seeds01..03; run only untouched seed04 after correcting child-root restoration context.'
 for seed in range(2026101104,2026101105):
  g=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));c=compile_legacy_ruleset_for_semantic_execution(g.ruleset);p=NativeSemanticLegalityProvider.try_create(c,strict=True);arms=[('legacy',g.compiled_ruleset,None),('semantic',c,None)]+([('hybrid',c,p)] if p else [])
  if seed==2026101104:
   for arm,cc,provider in arms:
    b=m.Board(cc,g.ruleset.piece_types,provider)
    for label,a in b.actions():
     from generic_chess.core.transition import apply_action
     from generic_chess.core.search_runtime import SearchPathRuntime
     child=m.Board(cc,g.ruleset.piece_types,provider);child.initial=apply_action(b.initial,a,cc);child.witnesses=(b.initial.position,child.initial.position);child.runtime=SearchPathRuntime.from_state(child.initial,cc,history_witnesses=child.witnesses,legal_binding_provider=provider)
     result=minimal_ab(child,1,seconds=10,node_limit=100000,trace=True,cooperative=True)
     # Minimal child's terminal mate offset starts at0; rootD2 uses ply1.
     value=-result['score'];value=value-1 if value>900000000 else value+1 if value<-900000000 else value
     r['root_values'].append(dict(arm=arm,move=label,root_value=value,child_result=result))
  for seconds in (.1,1.):
   for arm,cc,provider in arms+list(reversed(arms)):
    stopped();assert time.perf_counter()-start<180
    if provider:provider._metrics_local.public_cache={}
    b=m.Board(cc,g.ruleset.piece_types,provider);result=supported_search(b,8,seconds,100000,provider=provider);legal={label:a for label,a in b.actions()};assert result['move'] is None or result['move'] in legal
    if result['move'] is not None:b.push(legal[result['move']]);b.pop();assert b.restored()
    r['rows'].append(dict(seed=seed,arm=arm,budget_seconds=seconds,returned_legal=True,**result));write_record(B/'generated-curves.json',r)
   print(seed,seconds,flush=True)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-start);write_record(B/'generated-curves.json',r)
if __name__=='__main__':main()
