from pathlib import Path
import sys,time,json,inspect,textwrap,importlib.util
from dataclasses import replace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));B=ROOT/'.local_agent/eager-binding-20261011'
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import LeapAtom
from generic_chess.rules.schema import RuleInitialSetupOption
from generic_chess import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution,initial_state,apply_action,legal_actions
from generic_chess.core import search_runtime as sr,transition
from generic_chess.core.identity import repetition_identity_key
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
original=sr.SearchPathRuntime._reconstruct_history_witnesses;source=textwrap.dedent(inspect.getsource(original))
old='                    candidate = initial_state(self.compiled, setup_key)\n                    self.history_reconstruction_key_computations += 1\n                    if candidate.history[0] == first:\n                        replayed = candidate\n                        break\n'
new='                    position = (\n                        engine._initial_position(setup_key)\n                        if engine is not None else setups[setup_key]\n                    )\n                    self.history_reconstruction_key_computations += 1\n                    if repetition_identity_key(position, self.compiled) == first.position_key:\n                        candidate = initial_state(self.compiled, setup_key)\n                        self.history_reconstruction_key_computations += 1\n                        if candidate.history[0] != first:\n                            raise ValueError("invalid alternate initial record")\n                        replayed = candidate\n                        break\n'
old='\n'.join(line[4:] for line in old.split('\n'));new='\n'.join(line[4:] for line in new.split('\n'));assert source.count(old)==1;ns=dict(sr.__dict__,repetition_identity_key=repetition_identity_key);exec(source.replace(old,new),ns);prefilter=ns['_reconstruct_history_witnesses']
original_initial=transition.initial_state;initial_calls=0
def initial(*args,**kwargs):
 global initial_calls
 initial_calls+=1
 return original_initial(*args,**kwargs)
def main():
 global initial_calls
 started=time.perf_counter();types=[king_type(),T('P',LeapAtom((1,0)))];base=make_ruleset(8,types,lines=['.......k','........','........','........','........','........','.P......','K.......']);out=dict(complete=False,declaration=(B/'setup-scaling-plan.md').read_text(),rows=[])
 squares=[(f,r) for r in range(1,6) for f in range(8) if (f,r)!=(1,1)][:32]
 for count in (1,8,32):
  options=[]
  for i,(f,r) in enumerate(squares[:count]):
   rows=[list(x) for x in base.initial_position];piece=rows[1][1];rows[1][1]=None;rows[r][f]=piece;options.append(RuleInitialSetupOption(f'p-{i:03}',tuple(tuple(x) for x in rows)))
  rules=replace(base,initial_setup_options=tuple(options))
  for arm,c in [('legacy',compile_ruleset_for_execution(rules)),('semantic',compile_legacy_ruleset_for_semantic_execution(rules))]:
   state=original_initial(c,options[-1].setup_key);witnesses=[state.position]
   for _ in range(3):state=apply_action(state,legal_actions(state,c)[0],c);witnesses.append(state.position)
   reference=sr.SearchPathRuntime.from_state(state,c,history_witnesses=witnesses)
   for mode in ('current','prefilter','witness','witness','prefilter','current'):
    stopped();assert time.perf_counter()-started<120;sr.SearchPathRuntime._reconstruct_history_witnesses=prefilter if mode=='prefilter' else original;transition.initial_state=initial;initial_calls=0;t=time.perf_counter();rt=sr.SearchPathRuntime.from_state(state,c,history_witnesses=witnesses if mode=='witness' else None);wall=time.perf_counter()-t
    assert rt.search_key()==reference.search_key() and rt.tt_eligible and rt.history_witness_misses==0
    before=rt.search_key();rt.push(rt.legal_actions()[0]);rt.pop();assert rt.search_key()==before
    out['rows'].append(dict(options=count,arm=arm,mode=mode,wall_seconds=wall,initial_state_calls=initial_calls,sha_computations=rt.history_reconstruction_key_computations,equal=True));write_record(B/'setup-scaling.json',out)
   transition.initial_state=original_initial;sr.SearchPathRuntime._reconstruct_history_witnesses=original
 out.update(complete=True,elapsed_seconds=time.perf_counter()-started);write_record(B/'setup-scaling.json',out)
if __name__=='__main__':
 try:main()
 finally:transition.initial_state=original_initial;sr.SearchPathRuntime._reconstruct_history_witnesses=original
