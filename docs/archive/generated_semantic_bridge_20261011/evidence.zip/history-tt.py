from pathlib import Path
import sys,time,json,importlib.util,subprocess,ast,hashlib
from dataclasses import replace,asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));B=ROOT/'.local_agent/eager-binding-20261011'
from conftest import king_type,T,make_ruleset
from generic_chess.core.movement import LeapAtom
from generic_chess import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution,initial_state,legal_actions,apply_action
from generic_chess.rules.schema import RuleInitialSetupOption
from generic_chess.core import search_runtime as sr
spec=importlib.util.spec_from_file_location('qs',B/'generated-search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
old_source=subprocess.check_output(['git','show','55350054f3a922bfd03321d17b905104faaebf7d:generic_chess/core/search_runtime.py'],text=True)
cls=next(x for x in ast.parse(old_source).body if isinstance(x,ast.ClassDef) and x.name=='SearchPathRuntime');fn=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='_reconstruct_history_witnesses');old_method_source=ast.get_source_segment(old_source,fn)
import textwrap
ns=dict(sr.__dict__);exec(textwrap.dedent(old_method_source),ns);old_method=ns['_reconstruct_history_witnesses'];new_method=sr.SearchPathRuntime._reconstruct_history_witnesses

def main():
 started=time.perf_counter();types=[king_type(),T('P',LeapAtom((1,0)))];base=make_ruleset(4,types,lines=['...k','....','.P..','K...']);opts=[]
 for name,rank in [('a-file','P...'),('z-file','..P.')]:
  alt=make_ruleset(4,types,lines=['...k','....',rank,'K...']);opts.append(RuleInitialSetupOption(name,alt.initial_position))
 rules=replace(base,initial_setup_options=tuple(opts),repetition_policy="continuous_check_loss");r=dict(complete=False,declaration=(B/'history-tt-plan.md').read_text(),old_method_sha256=hashlib.sha256(old_method_source.encode()).hexdigest(),rows=[])
 for arm,c in [('legacy',compile_ruleset_for_execution(rules)),('semantic',compile_legacy_ruleset_for_semantic_execution(rules))]:
  for setup in (None,'a-file','z-file'):
   state=initial_state(c,setup);w=[state.position]
   for _ in range(3):state=apply_action(state,sorted(legal_actions(state,c),key=m.label)[0],c);w.append(state.position)
   for mode in ('old_default_only','declared_replay','supplied_witness','noTT'):
    stopped();assert time.perf_counter()-started<120;sr.SearchPathRuntime._reconstruct_history_witnesses=old_method if mode=='old_default_only' else new_method;witnesses=tuple(w) if mode=='supplied_witness' else None
    t=time.perf_counter();rt=sr.SearchPathRuntime.from_state(state,c,history_witnesses=witnesses);import_seconds=time.perf_counter()-t;import_stats=dict(attempts=rt.history_reconstruction_attempts,key_computations=rt.history_reconstruction_key_computations,hits=rt.history_witness_hits,misses=rt.history_witness_misses,tt_eligible=rt.tt_eligible)
    stats=SearchStatistics();t=time.perf_counter();action,score,pv,reason=run_root_search(state,c,m.Material(types),TranspositionTable(max_entries=4096),SearchLimits(max_depth=3,max_nodes=10000,max_time_seconds=5,quiescence_max_depth=0),None,stats,use_tt=(mode!="noTT"),use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=witnesses)
    r['rows'].append(dict(arm=arm,setup=setup,mode=mode,root_import_seconds=import_seconds,import_stats=import_stats,wall_seconds=time.perf_counter()-t,action=m.label(action),score=score,pv=[m.label(x) for x in pv],reason=reason,stats=asdict(stats)));write_record(B/'history-tt.json',r)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started);write_record(B/'history-tt.json',r)
if __name__=='__main__':
 try:main()
 finally:sr.SearchPathRuntime._reconstruct_history_witnesses=new_method
