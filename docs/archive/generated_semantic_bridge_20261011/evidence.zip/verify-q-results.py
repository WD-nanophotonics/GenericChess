from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent
load=lambda name:json.loads((B/(name+'.json')).read_text())
qa,qi,base,profile=map(load,('q-attribution','q-identity','generated-q','matched-profile'))
assert all(x['complete'] for x in (qa,qi,base,profile))
assert len(qa['audit'])==28 and len(qa['rows'])==96 and len(qi['rows'])==96 and len(profile['rows'])==18
assert sum(x['legacy_count'] for x in qa['audit'])==421 and sum(x['semantic_count'] for x in qa['audit'])==423
assert all(p['equal'] and not p['legacy_only'] and not p['semantic_only'] for x in qa['audit'] for p in x['policies'])
assert all(not x['event_mismatches'] for x in qa['audit'])
fields=('nodes','qnodes','evaluation_calls','runtime_pushes','runtime_pops','tt_hits','beta_cutoffs','legal_generation_calls')
keys=sorted({(x['seed'],x['ply']) for x in qi['rows']});checks=[]
for key in keys:
 reference=next(x for x in base['rows'] if (x['seed'],x['ply'])==key and x['q']==1 and x['arm']=='legacy')
 for data in (qa,qi):
  cells=[x for x in data['rows'] if (x['seed'],x['ply'])==key]
  assert all(x['score']==reference['score'] and x['reason']==reference['reason'] for x in cells)
  assert all(x['stats']['runtime_depth_balanced'] and x['stats']['native_legality_fallbacks']==0 and x['stats']['completed_depth']==2 for x in cells)
  for x in (y for y in cells if y['arm']=='hybrid'):
   partner=next(y for y in cells if y['arm']=='semantic' and all(y.get(k)==x.get(k) for k in ('main_align','q_align','canonical','identity')))
   assert all(x['stats'][k]==partner['stats'][k] for k in fields)
   assert (x['action'],x['score'],x['pv'])==(partner['action'],partner['score'],partner['pv'])
 matched=[x for x in qi['rows'] if (x['seed'],x['ply'])==key and x['canonical'] and x['identity']];ref=matched[0]
 assert len(matched)==3
 for x in matched:
  assert (x['action'],x['score'],x['pv'],x['reason'])==(ref['action'],ref['score'],ref['pv'],ref['reason'])
  assert all(x['stats'][k]==ref['stats'][k] for k in fields)
 checks.append(dict(seed=key[0],ply=key[1],action=ref['action'],score=ref['score'],work={k:ref['stats'][k] for k in fields},equal=True))
for key in keys[-4:]:pass
for x in profile['rows']:
 ref=next(y for y in qi['rows'] if (y['seed'],y['ply'],y['arm'])==(x['seed'],6,x['arm']) and y['canonical'] and y['identity'])
 assert all(x['stats'][k]==ref['stats'][k] for k in fields)
 assert (x['action'],x['score'],x['pv'],x['reason'])==(ref['action'],ref['score'],ref['pv'],ref['reason'])
 if x['instrumented']:assert abs(x['measurement']['sum_seconds']-x['measurement']['elapsed_seconds'])<1e-9
out=dict(complete=True,audit_states=28,legacy_children=421,typed_children=423,noisy_set_policies=56,factor_calls=192,matched_cells=checks,profile_calls=18,scope='finite pure legacy-lowered diagnostic; not public dedup/order change or arbitrary DSL equivalence',input_hashes={name:hashlib.sha256((B/(name+'.json')).read_bytes()).hexdigest() for name in ('q-attribution','q-identity','generated-q','matched-profile')})
(B/'q-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print(len(checks),out['input_hashes'])
