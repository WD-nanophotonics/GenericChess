from pathlib import Path
import sys,time,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import GeneratorConfig,generate_game,compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.transition import initial_state
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.evaluation.config import MATE_SCORE
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.search_backend_comparison import minimal_ab,supported_search,CoreBoard
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
B=ROOT/'.local_agent/eager-binding-20261011'
def label(a):
 src=getattr(a,'from_square',None);dst=a.to_square
 return json.dumps([None if src is None else [src.file,src.rank],[dst.file,dst.rank],getattr(a,'promotion_target_id',None),getattr(a,'base_type_id',None)],separators=(',',':'))
class Material:
 def __init__(self,types):self.values={t.type_id:0 if t.is_anchor else 100*(i+1) for i,t in enumerate(sorted(types,key=lambda t:t.type_id))}
 def type_value(self,tid):return self.values[tid]
 def evaluate(self,state):
  p=state.position;s=p.side_to_move
  return sum((1 if x.owner==s else -1)*self.values[x.current_type_id] for x in p.board if x)+sum((1 if owner==s else -1)*self.values[tid]*n for owner,hand in enumerate(p.hands) for tid,n in hand.items())
 def capture_order_value(self,moving,captured):return 10*self.type_value(captured.current_type_id)-self.type_value(moving.current_type_id)
class Board(CoreBoard):
 def __init__(self,c,types,provider=None):
  self.compiled=c;self.initial=initial_state(c);self.witnesses=(self.initial.position,);self.material=Material(types);self.label=label;self.checkpoint=None;self.runtime=SearchPathRuntime.from_state(self.initial,c,history_witnesses=self.witnesses,legal_binding_provider=provider)
def main():
 started=time.perf_counter();r=dict(complete=False,declaration=(B/'generated-search-plan.md').read_text(),roots=[],rows=[])
 for seed in range(2026101101,2026101105):
  stopped();g=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));t=time.perf_counter();c=compile_legacy_ruleset_for_semantic_execution(g.ruleset);cs=time.perf_counter()-t;p=NativeSemanticLegalityProvider.try_create(c,strict=True);r['roots'].append(dict(seed=seed,semantic_compile_seconds=cs,native_available=p is not None,native_setup_seconds=None if p is None else p.compile_seconds))
  if p:
   core=Board(c,g.ruleset.piece_types);native=Board(c,g.ruleset.piece_types,p);assert core.actions()==native.actions()
   for (_,aa),(_,bb) in zip(core.actions(),native.actions()):
    core.push(aa);native.push(bb);assert core.snapshot()==native.snapshot();core.pop();native.pop()
  arms=[('legacy',g.compiled_ruleset,None),('semantic',c,None)]+([('hybrid',c,p)] if p else [])
  for algo in ('minimal','supported'):
   for arm,cc,provider in arms+list(reversed(arms)):
    stopped();assert time.perf_counter()-started<180
    if provider:provider._metrics_local.public_cache={}
    board=Board(cc,g.ruleset.piece_types,provider)
    result=minimal_ab(board,2,seconds=10,node_limit=100000,trace=True,cooperative=True) if algo=='minimal' else supported_search(board,2,10,100000,provider=provider)
    assert board.restored();r['rows'].append(dict(seed=seed,algorithm=algo,arm=arm,**result));write_record(B/'generated-search.json',r)
   print(seed,algo,flush=True)
 r.update(complete=True,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.perf_counter()-started);write_record(B/'generated-search.json',r)
if __name__=='__main__':main()
