from pathlib import Path
import sys,inspect,textwrap,ast,time,hashlib,json
from dataclasses import replace
from unittest.mock import patch
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import search_runtime as sr
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.search_backend_comparison import CASES,CoreBoard,supported_search
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/eager-binding-20261011';original=sr._semantic_component_diff_hash
src=textwrap.dedent(inspect.getsource(sr._component_map));tree=ast.parse(src);fn=tree.body[0];fn.name='auxmap';fn.body=[ast.Assign(targets=[ast.Name(id='values',ctx=ast.Store())],value=ast.Dict(keys=[],values=[]))]+fn.body[4:]
# Bind by source locations rather than assumed statement count.
tree=ast.parse(src);fn=tree.body[0];fn.name='auxmap';start=next(i for i,x in enumerate(fn.body) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='engine' for t in x.targets));fn.body=[ast.Assign(targets=[ast.Name(id='values',ctx=ast.Store())],value=ast.Dict(keys=[],values=[]))]+fn.body[start:];ast.fix_missing_locations(tree)
ns=dict(sr.__dict__);exec(compile(tree,'<original-auxmap-only>','exec'),ns);auxmap=ns['auxmap']
def candidate(parent,child,compiled,current):
 if len(parent.board)!=len(child.board) or len(parent.hands)!=len(child.hands):return original(parent,child,compiled,current)
 value=current
 def changed(address,old,new):
  nonlocal value
  if old!=new:value=sr._xor(sr._xor(value,sr._component_token(address,old)),sr._component_token(address,new))
 changed(('side',),parent.side_to_move,child.side_to_move)
 for i,(a,b) in enumerate(zip(parent.board,child.board)):
  if a!=b:changed(('board',i),sr._component_map_cell(parent,i),sr._component_map_cell(child,i))
 for owner,(a,b) in enumerate(zip(parent.hands,child.hands)):changed(('hand',owner),tuple(a.counts),tuple(b.counts))
 before=auxmap(parent,compiled);after=auxmap(child,compiled)
 for address in before.keys()|after.keys():
  old=before.get(address);new=after.get(address)
  if old!=new:
   if address in before:value=sr._xor(value,sr._component_token(address,old))
   if address in after:value=sr._xor(value,sr._component_token(address,new))
 return value

def main():
 start=time.perf_counter();r=dict(complete=False,declaration=(B/'hash-plan.md').read_text(),aux_source=ast.unparse(tree),audit=[],rows=[])
 for case in CASES:
  stopped();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);parent=b.initial.position;h=sr._full_runtime_hash(parent,c);children=[]
  for label,a in b.actions():b.push(a);children.append((label,b.runtime.position));b.pop();assert b.restored()
  for label,child in children:
   x=original(parent,child,c,h);y=candidate(parent,child,c,h);z=sr._full_runtime_hash(child,c);assert x==y==z,(case['id'],label)
  for aux in (parent.aux_state,(),(*parent.aux_state,((999999,-1),0)),(*parent.aux_state,((999999,-1),None))):
   child=replace(parent,aux_state=aux);old=original(parent,child,c,h);new=candidate(parent,child,c,h);full=sr._full_runtime_hash(child,c);assert old==new; r.setdefault('aux_differentials',[]).append(dict(root=case['id'],aux=repr(aux),original_equals_candidate=True,full_equal=old==full))
  r['audit'].append(dict(root=case['id'],children=len(children),aux_controls=4,restored=b.restored()));write_record(B/'hash-probe.json',r)
 for name in ('chess-middle','shogi-drop'):
  case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  for arm in ('original','stream','stream','original'):
   stopped();assert time.perf_counter()-start<120;p=NativeSemanticLegalityProvider.try_create(c,strict=True);assert p;p._metrics_local.public_cache={};b=CoreBoard(case,c)
   with patch.object(sr,'_semantic_component_diff_hash',original if arm=='original' else candidate):v=supported_search(b,2,30,100000,provider=p)
   assert b.restored();r['rows'].append(dict(root=name,arm=arm,**v));write_record(B/'hash-probe.json',r);print(name,arm,v['wall_seconds'],flush=True)
 r.update(complete=True,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.perf_counter()-start);write_record(B/'hash-probe.json',r)
if __name__=='__main__':main()
