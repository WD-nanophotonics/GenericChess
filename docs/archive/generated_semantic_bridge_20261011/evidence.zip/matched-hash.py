from pathlib import Path
import sys,time,json,importlib.util,functools
from dataclasses import asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/eager-binding-20261011'
spec=importlib.util.spec_from_file_location('qi',B/'q-identity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess.core import search_runtime as sr
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
hspec=importlib.util.spec_from_file_location('hp',B/'hash-probe.py');h=importlib.util.module_from_spec(hspec);hspec.loader.exec_module(h)
original_hash=sr._semantic_component_diff_hash
oracle_calls=0
def checked(parent,child,compiled,current):
 global oracle_calls
 old=original_hash(parent,child,compiled,current);new=h.candidate(parent,child,compiled,current);full=sr._full_runtime_hash(child,compiled)
 assert old==new==full
 oracle_calls+=1
 return new
def main():
 global oracle_calls
 started=time.perf_counter();r=dict(complete=False,declaration=(B/'matched-hash-plan.md').read_text(),rows=[])
 m.ordering.MoveOrderer.order=m.aligned_order;m.search._order_qactions=m.aligned_q;m.search._runtime_legal_actions=m.canonical_legal;m.search.MoveOrderer=m.IdentityOrderer
 for seed in (2026101103,2026101104):
  g=m.generate_game(m.GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));old=g.compiled_ruleset;new=m.compile_legacy_ruleset_for_semantic_execution(g.ruleset);provider=m.NativeSemanticLegalityProvider.try_create(new,strict=True);a,b=m.initial_state(old),m.initial_state(new);wa,wb=[a.position],[b.position]
  for ply in range(6):
   aa,bb=m.groups(a,old),m.groups(b,new);k=sorted(aa,key=lambda x:repr((getattr(aa[x][0],'from_square',None),aa[x][0].to_square,getattr(aa[x][0],'promotion_target_id',None),getattr(aa[x][0],'base_type_id',None))))[(seed+ply)%len(aa)];a=m.apply_action(a,aa[k][0],old);b=m.apply_action(b,bb[k][0],new);wa.append(a.position);wb.append(b.position)
  arms=[('legacy',old,a,tuple(wa),None),('semantic',new,b,tuple(wb),None)]+([('hybrid',new,b,tuple(wb),provider)] if provider else [])
  for oracle,hash_arm,arm,c,state,w,prov in [(True,'checked',*x) for x in arms]+[(False,ha,*x) for ha in ('original','stream','stream','original') for x in arms]:
   m.stopped();assert time.perf_counter()-started<120
   if prov:prov._metrics_local.public_cache={}
   stats=m.SearchStatistics();m.original_legal_requests.clear()
   oracle_calls=0;sr._semantic_component_diff_hash=checked if oracle else original_hash if hash_arm=='original' else h.candidate
   t=time.perf_counter()
   try:action,score,pv,reason=m.search.run_root_search(state,c,m.m.Material(g.ruleset.piece_types),m.TranspositionTable(max_entries=65536),m.SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=10,quiescence_max_depth=1,quiescence_hard_max_depth=4),None,stats,use_tt=True,use_ordering=True,tuning=m.SearchTuning(use_root_tactical=False),_history_witnesses=w,legal_binding_provider=prov)
   finally:
    wall=time.perf_counter()-t;sr._semantic_component_diff_hash=original_hash
   r['rows'].append(dict(seed=seed,arm=arm,oracle=oracle,hash_arm=hash_arm,oracle_calls=oracle_calls,action=m.m.label(action),score=score,pv=[m.m.label(x) for x in pv],reason=reason,stats=asdict(stats),wall_seconds=wall));m.write_record(B/'matched-hash.json',r)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started);m.write_record(B/'matched-hash.json',r)
if __name__=='__main__':
 try:main()
 finally:sr._semantic_component_diff_hash=original_hash;m.ordering.MoveOrderer.order=m.original_order;m.search._order_qactions=m.original_q;m.search._runtime_legal_actions=m.original_legal;m.search.MoveOrderer=m.original_class
