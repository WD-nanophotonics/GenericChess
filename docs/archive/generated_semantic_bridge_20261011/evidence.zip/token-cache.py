from pathlib import Path
import sys,time,json,importlib.util,functools
from dataclasses import asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/eager-binding-20261011'
spec=importlib.util.spec_from_file_location('qi',B/'q-identity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess.core import search_runtime as sr
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from collections import OrderedDict
import sys
original_token=sr._component_token
cache=OrderedDict();counters={};cache_mode=False;oracle=False

def supported(v):return type(v) in (str,int,bool,type(None)) or type(v) is tuple and all(supported(x) for x in v)
def cached(address,value):
 key=(address,value)
 if not supported(key):
  counters['bypass']+=1
  return original_token(address,value)
 if key in cache:
  counters['hit']+=1;result=cache[key];cache.move_to_end(key)
 else:
  counters['miss']+=1;result=original_token(address,value);cache[key]=result
  if len(cache)>2048:cache.popitem(last=False);counters['eviction']+=1
 if oracle:assert result==original_token(address,value)
 return result

def cache_bytes():
 seen=set()
 def size(v):
  if id(v) in seen:return 0
  seen.add(id(v));out=sys.getsizeof(v)
  if type(v) is tuple:out+=sum(size(x) for x in v)
  return out
 return sys.getsizeof(cache)+sum(size(k)+size(v) for k,v in cache.items())
def main():
 global oracle,counters
 started=time.perf_counter();r=dict(complete=False,declaration=(B/'token-cache-plan.md').read_text(),rows=[])
 m.ordering.MoveOrderer.order=m.aligned_order;m.search._order_qactions=m.aligned_q;m.search._runtime_legal_actions=m.canonical_legal;m.search.MoveOrderer=m.IdentityOrderer
 for seed in (2026101103,2026101104):
  g=m.generate_game(m.GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));old=g.compiled_ruleset;new=m.compile_legacy_ruleset_for_semantic_execution(g.ruleset);provider=m.NativeSemanticLegalityProvider.try_create(new,strict=True);a,b=m.initial_state(old),m.initial_state(new);wa,wb=[a.position],[b.position]
  for ply in range(6):
   aa,bb=m.groups(a,old),m.groups(b,new);k=sorted(aa,key=lambda x:repr((getattr(aa[x][0],'from_square',None),aa[x][0].to_square,getattr(aa[x][0],'promotion_target_id',None),getattr(aa[x][0],'base_type_id',None))))[(seed+ply)%len(aa)];a=m.apply_action(a,aa[k][0],old);b=m.apply_action(b,bb[k][0],new);wa.append(a.position);wb.append(b.position)
  arms=[('legacy',old,a,tuple(wa),None),('semantic',new,b,tuple(wb),None)]+([('hybrid',new,b,tuple(wb),provider)] if provider else [])
  for oracle,cache_arm,arm,c,state,w,prov in [(True,'checked',*x) for x in arms]+[(False,ha,*x) for ha in ('original','cache','cache','original') for x in arms]:
   m.stopped();assert time.perf_counter()-started<120
   if prov:prov._metrics_local.public_cache={}
   stats=m.SearchStatistics();m.original_legal_requests.clear()
   cache.clear();counters=dict(hit=0,miss=0,eviction=0,bypass=0);sr._component_token=original_token if cache_arm=='original' else cached
   t=time.perf_counter()
   try:action,score,pv,reason=m.search.run_root_search(state,c,m.m.Material(g.ruleset.piece_types),m.TranspositionTable(max_entries=65536),m.SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=10,quiescence_max_depth=1,quiescence_hard_max_depth=4),None,stats,use_tt=True,use_ordering=True,tuning=m.SearchTuning(use_root_tactical=False),_history_witnesses=w,legal_binding_provider=prov)
   finally:
    wall=time.perf_counter()-t;sr._component_token=original_token
   r['rows'].append(dict(seed=seed,arm=arm,oracle=oracle,cache_arm=cache_arm,cache_counters=dict(counters),cache_entries=len(cache),cache_approx_python_bytes=cache_bytes(),action=m.m.label(action),score=score,pv=[m.m.label(x) for x in pv],reason=reason,stats=asdict(stats),wall_seconds=wall));m.write_record(B/'token-cache.json',r)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started);m.write_record(B/'token-cache.json',r)
if __name__=='__main__':
 try:main()
 finally:sr._component_token=original_token;m.ordering.MoveOrderer.order=m.original_order;m.search._order_qactions=m.original_q;m.search._runtime_legal_actions=m.original_legal;m.search.MoveOrderer=m.original_class
