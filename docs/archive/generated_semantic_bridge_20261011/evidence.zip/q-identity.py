from pathlib import Path
import sys,time,json,importlib.util,inspect,textwrap,hashlib
from dataclasses import asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/eager-binding-20261011'
spec=importlib.util.spec_from_file_location('gsearch',B/'generated-search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess import generate_game,GeneratorConfig,compile_legacy_ruleset_for_semantic_execution,initial_state,legal_actions,apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.attacks import is_in_check
from generic_chess.ai.alphabeta.quiescence import classify_noisy,material_inventory,enemy_board_count
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
import generic_chess.ai.alphabeta.search as search
import generic_chess.ai.alphabeta.ordering as ordering
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped

def groups(state,c):
 out={}
 for a in legal_actions(state,c):out.setdefault(m.label(a),[]).append(a)
 return out
original_order=ordering.MoveOrderer.order;original_q=search._order_qactions;original_legal=search._runtime_legal_actions;original_class=search.MoveOrderer
source=textwrap.dedent(inspect.getsource(original_order));assert source.count('str(a)')==1
ns=dict(ordering.__dict__,m=m);exec(source.replace('str(a)','m.label(a)'),ns);aligned_order=ns['order']
def aligned_q(state,actions,ply,ctx):
 assert not ctx.tuning.use_ordered_qsearch
 return sorted(actions,key=m.label)
original_legal_requests=[]
def canonical_legal(ctx,checkpoint):
 actions=original_legal(ctx,checkpoint);first={}
 for action in actions:first.setdefault(m.label(action),action)
 original_legal_requests.append(dict(raw=len(actions),unique=len(first)))
 return list(first.values())
ns_identity=dict(ordering.__dict__,m=m)
assert source.count('action in killers')==1
exec(source.replace('str(a)','m.label(a)').replace('action in killers','m.label(action) in killers'),ns_identity)
class IdentityOrderer(ordering.MoveOrderer):
 order=ns_identity['order']
 def record_killer(self,depth,action):
  key=m.label(action);killers=self._killers.setdefault(depth,[])
  if key in killers:killers.remove(key)
  killers.insert(0,key);del killers[2:]
 def record_history(self,player,action,tuning):
  key=(player,m.label(action));self._history[key]=min(self._history.get(key,0)+1,tuning.history_max)
 def history_value(self,player,action):return self._history.get((player,m.label(action)),0)
def main():
 start=time.perf_counter();r=dict(complete=False,declaration=(B/'q-identity-plan.md').read_text(),order_source_sha256=hashlib.sha256(source.encode()).hexdigest(),audit=[],rows=[])
 for seed in range(2026101101,2026101105):
  g=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));old=g.compiled_ruleset;new=compile_legacy_ruleset_for_semantic_execution(g.ruleset);provider=NativeSemanticLegalityProvider.try_create(new,strict=True);a,b=initial_state(old),initial_state(new);wa,wb=[a.position],[b.position];roots=[]
  for ply in range(7):
   stopped();assert time.perf_counter()-start<120
   aa,bb=groups(a,old),groups(b,new);assert set(aa)==set(bb)
   sa=[(x,apply_action(a,x,old)) for xs in aa.values() for x in xs];sb=[(x,apply_action(b,x,new)) for xs in bb.values() for x in xs]
   row=dict(seed=seed,ply=ply,legacy_count=len(sa),semantic_count=len(sb),policies=[])
   for cap in (False,True):
    s0,s1=SearchStatistics(),SearchStatistics();n0={m.label(x) for x in classify_noisy(a,sa,old,s0,capture_only=cap)};n1={m.label(x) for x in classify_noisy(b,sb,new,s1,capture_only=cap)}
    row['policies'].append(dict(capture_only=cap,equal=n0==n1,legacy_only=sorted(n0-n1),semantic_only=sorted(n1-n0),legacy_stats=asdict(s0),semantic_stats=asdict(s1),included=len(n0)))
   row['event_mismatches']=[]
   engine=semantic_engine_for(new)
   for key,xs in bb.items():
    ca=next(c for x,c in sa if m.label(x)==key)
    for x in xs:
     cb=next(c for y,c in sb if y==x)
     if (ca.position,ca.terminal_status,is_in_check(ca.position,ca.position.side_to_move,old))!=(cb.position,cb.terminal_status,engine.in_check(cb.position,cb.position.side_to_move)):row['event_mismatches'].append(key)
   r['audit'].append(row)
   if ply in (0,6):roots.append((ply,a,b,tuple(wa),tuple(wb)))
   if ply==6 or a.terminal_status.is_terminal or not aa:break
   k=sorted(aa,key=lambda x:repr((getattr(aa[x][0],'from_square',None),aa[x][0].to_square,getattr(aa[x][0],'promotion_target_id',None),getattr(aa[x][0],'base_type_id',None))))[(seed+ply)%len(aa)]
   a=apply_action(a,aa[k][0],old);b=apply_action(b,bb[k][0],new);wa.append(a.position);wb.append(b.position)
  for ply,a,b,wa,wb in roots:
   for canonical,identity in ((False,False),(False,True),(True,False),(True,True)):
    ordering.MoveOrderer.order=aligned_order;search._order_qactions=aligned_q;search._runtime_legal_actions=canonical_legal if canonical else original_legal;search.MoveOrderer=IdentityOrderer if identity else original_class
    for arm,c,state,w,prov in [('legacy',old,a,wa,None),('semantic',new,b,wb,None)]+([('hybrid',new,b,wb,provider)] if provider else []):
     stopped();assert time.perf_counter()-start<120
     if prov:prov._metrics_local.public_cache={}
     original_legal_requests.clear();stats=SearchStatistics();t=time.perf_counter();action,score,pv,reason=search.run_root_search(state,c,m.Material(g.ruleset.piece_types),TranspositionTable(max_entries=65536),SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=10,quiescence_max_depth=1,quiescence_hard_max_depth=4),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=w,legal_binding_provider=prov)
     r['rows'].append(dict(seed=seed,ply=ply,canonical=canonical,identity=identity,canonical_requests=list(original_legal_requests),arm=arm,action=m.label(action),score=score,pv=[m.label(x) for x in pv],reason=reason,wall_seconds=time.perf_counter()-t,stats=asdict(stats)));write_record(B/'q-identity.json',r)
  print(seed,len(roots),flush=True)
 ordering.MoveOrderer.order=original_order;search._order_qactions=original_q;search._runtime_legal_actions=original_legal;search.MoveOrderer=original_class
 r.update(complete=True,elapsed_seconds=time.perf_counter()-start);write_record(B/'q-identity.json',r)
if __name__=='__main__':
 try:main()
 finally:ordering.MoveOrderer.order=original_order;search._order_qactions=original_q;search._runtime_legal_actions=original_legal;search.MoveOrderer=original_class
