# Search factorial/profile qualification

Changed premise is final repaired actual-effect q2 support plus shared ordered-q
fusion, crossing existing PVS and ordered-q caller flags. Earlier lexical q2
PVS and pre-fusion q4 ordering records remain qualified, not overwritten. Four
exposed2300..2303 roots,32cold rotated calls,8192totalnodes/30sec/D2/q2hard8,
Native attack+legality, same profiles/prices/TT/main ordering; root scan disabled.
No product flag/default or price change and no independent holdout/strength claim.
All returned PVs are Core legally replayed and runtime depth balances. Completed
D2 scores agree across cells; baseline2300 only reaches D1, so its score is not
compared as a D2 estimate. All same-cell cold signatures repeat exactly.
Node/work changes reflect different search trees, not equal-work speedups.
Evaluation and legal generation telemetry are nested with Native subcategories;
never sum overlapping fractions. Profile120sec allowance is profiler overhead
headroom, not frozen-comparison extension or fair timing evidence. Its exact
signature is checked against the30sec unprofiled ordered-q result.
Input roots/routes and all caps/failures retained. Base product commit046c6613196fd5f0402d31fd957a82ff0e60265a;
product hashes additionally pin search/runtime. No credentials/private input or
Slack raw record is included. Raw .pstats is Python cProfile machine-generated
research evidence, not a portable executable or model worker.


A subsequent one-caller profile retained the exact30sec unprofiled signature;
37.68sec profiler wall is overhead-qualified. Attack predicates dominate
cumulative cost; constructing all compiled endpoint prefixes and checking each
then rejecting unrelated targets is avoidable work. A target-directed compiled
path iterator preserves minimum steps, leaps, order and duplicate prefixes.
Prototype16cold caller signatures/work/qclasses all agree. Independent unchanged
full attacked-square maps agree on8994queries/70positions and exhaustive
2306346compiled geometry target queries. Cooperative cancellation propagates at
the retained geometry checkpoint. No budget polling is generally throttled.

The tiny product helper is adopted subject to full regressions and post-product
replay. It changes no schema, IR serialization, rules fingerprint, attack
eligibility, S3/S4 contract, price or caller default. Unmatched endpoint callbacks
are removed with the work they guarded; each bounded compiled path lookup still
has the pre-query geometry checkpoint and each match has its checkpoint.
Earlier whole-map cache/Native-existence failures are not overwritten.

Retained setup failures: target_query_replay.py initial textual splice used wrong
indentation and stopped before simulation; v2 corrects it. First authority loader
hit an existing-output guard when importing replay setup and did not run controls;
authority_v2 loads recorded prototype text explicitly. Final product replay uses
the complete original committed semantic executor snapshot as baseline, not a
regenerated claim of original behavior. The profile declaration's stray20? text
has no control meaning; actual one-call limits and exact signature are recorded.
Focused initial pytest emitted an unwritable default-cache warning, no test
failure; the full run uses an ignored local cache. None of these are scientific
negative results or permission bypasses. All original records remain.

Final16actual old/product calls retain all signatures/work/qclasses; full1654
regressions exit0. A separate post-product profile retains the same2300 exact
signature and isolates residual dispatch cost; profile wall is not equal-work
speed evidence. Packaging records quiet pytest dots and exit0 explicitly, since
repository pytest quiet settings omit a textual passed summary.
