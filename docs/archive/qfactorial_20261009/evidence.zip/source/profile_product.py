"""One accounted residual-cost profile, not a speed or default comparison."""
import sys,json,time,cProfile,pstats,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;src=root/'.local_agent/qsemantics-20261008/fresh-reuse.json';old=json.loads(src.read_bytes())['cases'][0];expected=json.loads((p/'search-factorial.json').read_bytes());assert expected['complete'];out=p/'profile-product.json';assert not out.exists();assert not json.loads((root/'.local_agent/rollout.json').read_bytes()).get('user_paused');c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for step in old['route']:s.submit(action_from_dict(step['action']))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True));prof=cProfile.Profile();t=time.perf_counter();prof.enable();decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=120,quiescence_max_depth=2,quiescence_hard_max_depth=8));prof.disable();seconds=time.perf_counter()-t;validate_pv(s,decision);dd=record_value(decision);ee=next(x for x in expected['cases'][0]['searches'] if not x['pvs'] and x['ordered_q'])['decision'];keys=('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason');assert all(dd[k]==ee[k] for k in keys);stats=pstats.Stats(prof);stats.strip_dirs();prof.dump_stats(str(p/'profile-product.pstats'));rows=[]
for (file,line,func),(cc,nc,tt,ct,callers) in stats.stats.items():rows.append({'file':file,'line':line,'function':func,'primitive_calls':cc,'calls':nc,'own_seconds':tt,'cumulative_seconds':ct})
r={'complete':True,'declaration':'One residual-cost profile2300, orderedq true/PVSfalse/q2/8192nodes.120sec headroom ONLY for cProfile overhead, not fair-speed evidence or extension of frozen comparison. Completed signature must equal fixed30sec unprofiled factorial. After target-query product change: quantify residual hotspot on the same2300 caller; no further product patch or default change.','input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'decision':dd,'wall_seconds':seconds,'total_profile_seconds':stats.total_tt,'by_own':sorted(rows,key=lambda x:x['own_seconds'],reverse=True)[:60],'by_cumulative':sorted(rows,key=lambda x:x['cumulative_seconds'],reverse=True)[:90]};out.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('profile complete',seconds,[(x['function'],round(x['own_seconds'],2),round(x['cumulative_seconds'],2)) for x in r['by_own'][:18]],flush=True)
