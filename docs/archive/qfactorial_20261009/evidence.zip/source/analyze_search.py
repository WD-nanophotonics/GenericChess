"""Summarize the fixed q2 factorial with separate measured work categories."""
from pathlib import Path
import json,statistics
p=Path(__file__).parent;d=json.loads((p/'search-factorial.json').read_bytes());assert d['complete'];r={'complete':True,'scope':'Four exposedroots, same final product, q2/8192nodes/30sec; two cold rotated repeats per2x2cell. Same completed score at each root; different explored trees/order ties, no strength/default claim.','cases':[]}
for row in d['cases']:
 cells=[]
 for pp,oo in ((False,False),(True,False),(False,True),(True,True)):
  xs=[x for x in row['searches'] if x['pvs']==pp and x['ordered_q']==oo];w=xs[0]['runtime_work'];sec=statistics.median(x['seconds'] for x in xs);dd=xs[0]['decision'];cells.append({'pvs':pp,'ordered_q':oo,'median_seconds':sec,'completed_depth':dd['completed_depth'],'score':dd['score'],'work':dd['nodes']+dd['qnodes'],'pushes':w['runtime_pushes'],'reason':dd['termination_reason'],'evaluation_fraction':statistics.median(x['runtime_work']['evaluation_seconds'] for x in xs)/sec,'generation_fraction':statistics.median(x['runtime_work']['legal_generation_seconds'] for x in xs)/sec,'native_legality_fraction':statistics.median(x['runtime_work']['native_legality_seconds'] for x in xs)/sec})
 assert all(x['exact'] for x in row['cold_repeat_exact']);r['cases'].append({'seed':row['seed'],'cells':cells,'cold_repeat_exact':True})
encoded=(json.dumps(r,indent=2)+'\n').encode();assert encoded==(p/'search-factorial-analysis.json').read_bytes();print('Search factorial summary independently reconstructed exact')
