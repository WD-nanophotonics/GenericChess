"""Explicit two-purpose evidence archives, privacy scan and extracted hashes."""
from pathlib import Path
import json,hashlib,zipfile,re,statistics
root=Path.cwd();p=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
def load(name):return json.loads((p/name).read_bytes())
for name in ('promotion-aware.json','native-promotion.json','target-integrated.json','native-target.json','representatives.json','native-representatives.json','search-factorial.json','profile-search.json','target-query-replay-v2.json','target-query-product-replay.json','target-query-authority-v2.json'):assert load(name)['complete'],name
search_names={'search-factorial-declaration.json','search_factorial.py','search-factorial.json','search-factorial-analysis.json','analyze_search.py','profile_search.py','profile-search.json','profile-search.pstats','qualification-search.md','semantic-executor-before.py','target-query-declaration.json','target_query_replay.py','target_query_replay_v2.py','target-query-replay-v2.json','target_query_authority.py','target_query_authority_v2.py','target-query-authority-v2.json','target_query_product_replay.py','target-query-product-replay.json','focused-tests.txt','full-tests.txt','profile_product.py','profile-product.json','profile-product.pstats'}
allfiles=[x for x in p.iterdir() if x.is_file()];assert search_names <= {x.name for x in allfiles}
for x in allfiles:
 if x.suffix in ('.py','.json','.md','.txt'):
  text=x.read_text(encoding='utf8');assert not re.search(r'xox[baprs]-[A-Za-z0-9-]+|xapp-[A-Za-z0-9-]+|BEGIN [A-Z ]*PRIVATE KEY|icy' + 'woods|C0C6' + 'L21UU20|U0C6' + 'G6AU6MQ',text),x.name
testlog=(p/'full-tests.txt').read_text();assert '[100%]' in testlog and 'failed' not in testlog and 'ERROR' not in testlog
def archive(label,files,deps):
 folder=root/'docs/archive'/label;folder.mkdir(parents=True,exist_ok=True);z=folder/'evidence.zip';assert not z.exists();records=[]
 inputs=[('source/'+x.name,x) for x in files]+[('dependencies/'+name,path) for name,path in deps]
 assert len({name for name,path in inputs})==len(inputs)
 with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zz:
  for name,path in inputs:
   data=path.read_bytes();zz.writestr(name,data);records.append({'member':name,'original':path.relative_to(root).as_posix(),'bytes':len(data),'sha256':sha(data)})
 verify=p/('extracted-'+label);assert not verify.exists();verify.mkdir()
 with zipfile.ZipFile(z) as zz:
  assert zz.testzip() is None
  for name in zz.namelist():assert (verify/name).resolve().is_relative_to(verify.resolve())
  zz.extractall(verify)
 for record in records:
  bb=(verify/record['member']).read_bytes();assert len(bb)==record['bytes'] and sha(bb)==record['sha256']
 index={'format':1,'scope':'Agent-generated evidence only; no private/user input/rawSlack/account/credentials. Frozen old outputs included explicitly, not restored validation status.','members':records,'member_count':len(records),'total_uncompressed_bytes':sum(x['bytes'] for x in records),'archive_bytes':z.stat().st_size,'archive_sha256':sha(z.read_bytes()),'extracted_hashes_verified':True,'base_product_sha':'046c6613196fd5f0402d31fd957a82ff0e60265a','current_product_hashes':{name:sha((root/name).read_bytes()) for name in ('generic_chess/core/semantic_executor.py','generic_chess/rules/ir.py','generic_chess/ai/alphabeta/search.py')}}
 (folder/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(label,len(records),index['archive_bytes'],index['total_uncompressed_bytes'],flush=True);return index
pawnfiles=[x for x in allfiles if x.name not in search_names];qfiles=[x for x in allfiles if x.name in search_names or x.name=='package_evidence.py']
pawnidx=archive('pawn_bias_20261009',pawnfiles,[('old-cross-game.json',root/'.local_agent/preparation-transfer-20261008/cross-game.json'),('old-cross_game.py',root/'.local_agent/preparation-transfer-20261008/cross_game.py'),('old-task.py',root/'.local_agent/preparation-transfer-20261008/task.py'),('old-cross-game-declaration.json',root/'.local_agent/preparation-transfer-20261008/cross-game-declaration.json'),('old-displacement-role-pilot-v2.json',root/'.local_agent/target-context-20261008/displacement-role-pilot-v2.json')])
qidx=archive('qfactorial_20261009',qfiles,[('fresh-reuse.json',root/'.local_agent/qsemantics-20261008/fresh-reuse.json'),('test_geometry_target_query.py',root/'tests/product/test_geometry_target_query.py')])
summary={'format':1,'science':'OPEN','scope':'Conditional capture tasks, not material prices; no human fit/default/holdout change. Fixed task scope, exact target integration, representative reliability and actual pawn-mask law sensitivity separated.','recovery':'docs/archive/pawn_bias_20261009/index.json','archive_sha256':pawnidx['archive_sha256'],'decomposition':{k:{x:y for x,y in v.items() if x!='rows'} for k,v in load('decomposition.json')['games'].items()},'paired_exact':load('paired-exact.json')['games'],'target_law':load('target-analysis.json')['games'],'support':load('support-analysis.json'),'representatives':load('representatives-analysis.json'),'layer_sensitivity':load('layer-sensitivity.json'),'layer_representatives':load('layer-representatives.json'),'execution':{name:{game:{'rows':len(g['rows']),**{k:v for k,v in g.items() if k in ('transitions','core_transitions','legal_list_queries','capture_list_queries','preparations','reply_classes','seconds','complete')}} for game,g in load(name)['games'].items()} for name in ('promotion-aware.json','native-promotion.json','target-integrated.json','native-target.json','representatives.json','native-representatives.json')},'advisor':'Adopt law-validity versus estimator-reliability distinction and exact same-cohort promotion-layer sensitivity. New3representative collection already completed before reply read; qualified as conditional reliability, not global material validation. Advisor read prior published note, did not execute new results.'}
(root/'docs/research/data/pawn_bias_20261009.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
query=load('target-query-product-replay.json');cost=[]
for row in query['cases']:
 old=statistics.median(x['seconds'] for x in row['searches'] if not x['target_query_prototype']);new=statistics.median(x['seconds'] for x in row['searches'] if x['target_query_prototype']);assert row['all_exact'] and row['same_qclasses'];cost.append({'seed':row['seed'],'before_seconds':old,'product_seconds':new,'local_wall_reduction_fraction':1-new/old,'exact_signature_work_qclasses':True})
prof=load('profile-search.json');qs={'format':1,'scope':'Four exposed caller roots, fixed q2 factorial and exact-signature compiled target query cost change. No strength/default/price/cache or general callback-throttling change.','recovery':'docs/archive/qfactorial_20261009/index.json','archive_sha256':qidx['archive_sha256'],'factorial':load('search-factorial-analysis.json'),'target_query_product_cost':cost,'target_query_authority':load('target-query-authority-v2.json'),'profile':{'wall_seconds':prof['wall_seconds'],'signature_exact':True,'overhead_qualified':True,'top_own':prof['by_own'][:18],'top_cumulative':prof['by_cumulative'][:18]},'full_regression':{'exit_code':0,'passed_dots':1654,'raw_log':(p/'full-tests.txt').read_text().strip()},'post_product_profile':load('profile-product.json'),'current_product_hashes':qidx['current_product_hashes']}
(root/'docs/research/data/qfactorial_20261009.json').write_bytes((json.dumps(qs,indent=2)+'\n').encode())
