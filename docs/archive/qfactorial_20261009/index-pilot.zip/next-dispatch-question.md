# Residual interface question
Product profile:119978 square-attack calls,4400556 matching-prefix iterator calls,
148076 source-index builds. Matching lookup own1.87sec; source-index own1.06sec,
make-binding own.217sec, guards own.024sec. Thus guard/binding micro-optimization
has a low observed own-time ceiling; do not start there merely because code is easy.
The current local pilot only indexes immutable compiled geometry; never position,
action or repetition/history. Index setup is included in the first search but
subsequent calls warm the same index. A useful gain still needs per-caller cold
construction and memory accounting before product consideration. No general
budget-check throttling or price/default change follows from profiler fractions.

Final pilot: small/inconsistent warm-index gain, no product adoption. Do not
spend further cold/memory experiments unless a concrete caller need justifies it.
