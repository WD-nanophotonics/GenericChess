"""A new decision: conditional root effects hidden by equal minimax maxima."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from generic_chess.core.actions import SemanticBoardMove
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=ROOT/'.local_agent/custody-kernel-20261008';raw=(old/'pretransfer-coupling.json').read_bytes();src=json.loads(raw);defs_raw=(old/'kernel-completed.json').read_bytes();defs=json.loads(defs_raw);f=sorted(src['frontiers'],key=lambda x:x['seed'])[0];out=p/'conditional-spectrum.json';assert not out.exists();r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),definition_sha256=hashlib.sha256(defs_raw).hexdigest(),declaration='New conditional-action question, not extension of the frozen optimal-score test. At the same first frontier compare every matched owner0 root action under3 subsequent adversarial plies (total4), full unit-control utility/history and no WDL bonus. Each action gets an independent full alpha/beta window, no root-bound reuse. Equal200000node/60sec aggregate checkpoint per base; unknown actions retained on fuse. Difference can reveal a base continuation effect hidden by equal maxima; equality localizes this task/horizon failure, not all mechanisms. Expected incremental Native work tens of thousands of transitions and seconds, serial/interruptible, no labels.',rows=[]);write_record(out,r)
class Fuse(RuntimeError):pass
for j,case in enumerate(defs['cases']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));n=compile_native_semantic_rules(c);anchors={i for i,t in enumerate(n.type_ids) if c.types_by_id[t].is_anchor};s=GameSession(c)
 for v in f['paired_actions'][j]:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
 root=pack_semantic_search_position(c,n,s)
 def utility(v):return sum((1 if x[2]==0 else -1) for x in v['board'] if x is not None and x[1] not in anchors)+sum((1 if owner==0 else -1)*count for owner,h in enumerate(v['hands']) for t,count in enumerate(h) if t not in anchors)
 initial=utility(snapshot(n,root));row=dict(base=case['base'],nodes=0,transitions=0,cells=[]);r['rows'].append(row);t=time.perf_counter()
 def solve(pos,left,alpha,beta):
  row['nodes']+=1
  if row['nodes']>200000 or time.perf_counter()-t>60:raise Fuse()
  v=snapshot(n,pos);u=utility(v)
  if left==0 or terminal_status(n,pos)['status']!='ongoing':return u
  aa=list(guarded_actions(n,pos));assert aa
  def ordering(a):
   public=public_action(n,a);victim=v['board'][public.to_square.file+9*public.to_square.rank] if isinstance(public,SemanticBoardMove) else None
   return (not(victim is not None and victim[1] not in anchors),str(public))
  aa.sort(key=ordering);maximum=v['side']==0;best=-100 if maximum else 100
  for a in aa:
   row['transitions']+=1;score=solve(make_checked(n,pos,a),left-1,alpha,beta);best=max(best,score) if maximum else min(best,score)
   if maximum:alpha=max(alpha,best)
   else:beta=min(beta,best)
   if alpha>=beta:break
  return best
 for a in sorted(guarded_actions(n,root),key=lambda a:str(public_action(n,a))):
  assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused');cell=dict(action=record_value(public_action(n,a)),complete=False)
  try:row['transitions']+=1;cell.update(complete=True,delta=solve(make_checked(n,root,a),3,-100,100)-initial)
  except Fuse:cell['delta']=None
  row['cells'].append(cell);write_record(out,r)
 row['seconds']=time.perf_counter()-t;write_record(out,r);print(case['base'],'complete',sum(x['complete'] for x in row['cells']),len(row['cells']),'nodes',row['nodes'],'seconds',row['seconds'],flush=True)
maps=[{json.dumps(x['action'],sort_keys=True):x for x in row['cells']} for row in r['rows']];assert maps[0].keys()==maps[1].keys();r['paired']=[dict(action=maps[0][k]['action'],deltas=[maps[j][k]['delta'] for j in (0,1)],complete=all(maps[j][k]['complete'] for j in (0,1))) for k in sorted(maps[0])];r['complete']=True;write_record(out,r);print('different complete actions',sum(x['complete'] and x['deltas'][0]!=x['deltas'][1] for x in r['paired']))
