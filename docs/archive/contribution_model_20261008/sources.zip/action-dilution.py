"""Exact short-horizon decomposition of whole-state control and policy dilution."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=ROOT/'.local_agent/custody-kernel-20261008';raw=(old/'pretransfer-coupling.json').read_bytes();src=json.loads(raw);definition_raw=(old/'kernel-completed.json').read_bytes();cases=json.loads(definition_raw)['cases'];compiled=[compile_ruleset_for_execution(ruleset_from_dict(x['definition'])) for x in cases];native=[compile_native_semantic_rules(c) for c in compiled];anchors={x.type_id for x in compiled[0].piece_types if x.is_anchor};out=p/'action-dilution.json';assert not out.exists();start=time.perf_counter()
def key(a):return json.dumps(record_value(a),sort_keys=True)
def reward(s,a):
 if not isinstance(a,SemanticBoardMove):return 0
 victim=s.position.board[a.to_square.file+9*a.to_square.rank]
 return (2 if s.position.side_to_move==0 else -2) if victim is not None and victim.current_type_id not in anchors else 0
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),definition_sha256=hashlib.sha256(definition_raw).hexdigest(),declaration='Exact1/2-ply uniform legal-action expected ordinary-control delta at all13 existing paired first-transfer frontiers. Counterfactual/exposed population, not universal ordering. Replay full history, compare root action identities and second-ply ordinary capture signatures. A capture numerator shared across cases but differing legal counts identifies action-normalization dilution; retain every reply and Native/Core legal-set checks. No longer horizon, model fitting, TT/evaluator change or WDL utility.',rows=[],core_transitions=0,native_legal_set_checks=0);write_record(out,r)
for f in src['frontiers']:
 assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
 sessions=[];packs=[]
 for c,n,history,saved in zip(compiled,native,f['paired_actions'],f['paired_states']):
  s=GameSession(c)
  for v in history:s.submit(next(a for a in s.legal_actions() if record_value(a)==v));r['core_transitions']+=1
  assert record_value(s.state)==saved;sessions.append(s);packs.append(pack_semantic_search_position(c,n,s))
 maps=[{key(a):a for a in s.legal_actions()} for s in sessions];assert maps[0].keys()==maps[1].keys()
 row=dict(seed=f['seed'],root_legal_count=len(maps[0]),replies=[]);r['rows'].append(row);one=[Fraction(0),Fraction(0)];two=[Fraction(0),Fraction(0)];predicted=Fraction(0)
 for k in sorted(maps[0]):
  cell=dict(root_action=record_value(maps[0][k]),cases=[]);captures=[];num=[];counts=[]
  for j,(c,n,s,pos) in enumerate(zip(compiled,native,sessions,packs)):
   a=maps[j][k];v=reward(s.state,a);child=apply_action(s.state,a,c);r['core_transitions']+=1;aa=legal_actions(child,c) if not child.terminal_status.is_terminal else []
   packed=next(x for x in guarded_actions(n,pos) if public_action(n,x)==a);np=make_checked(n,pos,packed);na=[public_action(n,x) for x in guarded_actions(n,np)] if not child.terminal_status.is_terminal else []
   assert set(na)==set(aa);r['native_legal_set_checks']+=1
   capturekeys={key(x):reward(child,x) for x in aa if reward(child,x)};captures.append(capturekeys);numerator=sum(capturekeys.values());num.append(numerator);counts.append(len(aa));nextmean=Fraction(numerator,len(aa)) if aa else Fraction(0)
   one[j]+=Fraction(v,len(maps[j]));two[j]+=Fraction(v+nextmean,len(maps[j]));cell['cases'].append(dict(base=cases[j]['base'],root_reward=v,next_legal_count=len(aa),next_drop_count=sum(isinstance(x,SemanticDropMove) for x in aa),next_capture_count=len(capturekeys),next_capture_numerator=numerator,next_mean=nextmean,terminal=record_value(child.terminal_status)))
  assert captures[0]==captures[1] and num[0]==num[1]
  term=(Fraction(num[0],counts[0])-Fraction(num[1],counts[1])) if all(counts) else Fraction(0);predicted+=term/len(maps[0]);cell['dilution_difference']=term;row['replies'].append(cell)
 row.update(one_ply=one,two_ply=two,difference=two[0]-two[1],predicted_dilution=predicted);assert row['difference']==predicted
 write_record(out,r);print(f['seed'],'root',row['root_legal_count'],'difference',float(row['difference']),'all dilution',flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print('transitions',r['core_transitions'],'native checks',r['native_legal_set_checks'],'seconds',r['seconds'])
