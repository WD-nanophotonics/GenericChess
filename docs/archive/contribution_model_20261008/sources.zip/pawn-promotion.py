"""Matched partial-law promotion toggle; no human-price selection."""
import sys,json,time,hashlib,itertools,importlib.util
from pathlib import Path
from functools import lru_cache
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;dep=ROOT/'.local_agent/joint-exposure-20261008/census.py';spec=importlib.util.spec_from_file_location('primitive_geometry',dep);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
prior_raw=(p/'partial-pawn-premium.json').read_bytes();prior=json.loads(prior_raw);allcontexts=list(itertools.permutations(range(16),3));indices=[i for i,x in enumerate(allcontexts) if x[0]//4<3];out=p/'pawn-promotion.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(dep.read_bytes()).hexdigest(),prior_sha256=hashlib.sha256(prior_raw).hexdigest(),declaration='Matched partial4x4 pawn task on2520 ordered contexts with initial actor rank0/1/2, excluding invalid last-rank unpromoted starts from both controls. Same pass/capture unit reward/immobile reference,4 opponent primitives,2/4plies,both phases. Toggle no promotion versus automatic Q at the final rank, not full Chess promotion choices/double-step/en-passant/game semantics. This isolates omission bias and source-context effects in an uncalibrated ability ratio; no human fitting/default promotion. Retain both controls, source-rank strata and every paired difference. Serial small exact DP, persist per opponent, stop flags at strata.',indices=indices,rows=[]);write_record(out,r)
def pawn_moves(s,e,v):
 x,y=s%4,s//4
 if y==3:return
 if s+4 not in (e,v):yield s+4
 for dx in (-1,1):
  if 0<=x+dx<4 and x+dx+4*(y+1) in (e,v):yield x+dx+4*(y+1)
for o in ('Q','R','B','N'):
 assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused');er=m.build(4,o);qr=m.build(4,'Q');edges=0
 @lru_cache(None)
 def solve(s,e,v,side,depth,ability,promotion,promoted=False):
  global edges
  if depth==0 or s<0:return 0
  choices=[solve(s,e,v,1-side,depth-1,ability,promotion,promoted)]
  if side==0 and ability:
   aa=m.moves(qr,s,(),tuple(x for x in (e,v) if x>=0)) if promoted else pawn_moves(s,e,v)
   for t in aa:
    edges+=1;choices.append(int(t==e or t==v)+solve(t,-1 if t==e else e,-1 if t==v else v,1,depth-1,ability,promotion,promoted or (promotion and t//4==3)))
  elif side==1 and e>=0:
   for t in m.moves(er,e,() if v<0 else (v,),(s,)):
    edges+=1;choices.append(-1 if t==s else solve(s,t,v,0,depth-1,ability,promotion,promoted))
  return (max if side==0 else min)(choices)
 row=dict(opponent=o,cells=[])
 for depth in (2,4):
  for side in (0,1):
   cell=dict(depth=depth,side=side,roots=[]);previous=next(x for rr in prior['rows'] if rr['opponent']==o for x in rr['cells'] if x['depth']==depth and x['side']==side)
   for i in indices:
    s,e,v=allcontexts[i];baseline=solve(s,e,v,side,depth,False,False);plain=solve(s,e,v,side,depth,True,False);promoted=solve(s,e,v,side,depth,True,True);assert baseline==previous['per_root_passive'][i] and plain==previous['per_root_active'][i];assert promoted>=plain>=baseline
    cell['roots'].append(dict(index=i,rank=s//4,baseline=baseline,plain=plain,promoted=promoted,plain_premium=plain-baseline,promoted_premium=promoted-baseline))
   cell['rank_means']={rank:{field:Fraction(sum(x[field] for x in cell['roots'] if x['rank']==rank),840) for field in ('plain_premium','promoted_premium')} for rank in range(3)};row['cells'].append(cell)
 row['edges']=edges;r['rows'].append(row);write_record(out,r);print(o,'edges',edges,flush=True)
r['means']={depth:{field:Fraction(sum(x[field] for row in r['rows'] for cell in row['cells'] if cell['depth']==depth for x in cell['roots']),4*2*2520) for field in ('plain_premium','promoted_premium')} for depth in (2,4)};r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print(r['means'],'seconds',r['seconds'])
