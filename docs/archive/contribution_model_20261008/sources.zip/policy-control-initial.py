"""Alternative response laws expose normalization, not tune prices."""
import sys,json,hashlib,time
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'action-dilution.json').read_bytes();src=json.loads(raw);out=p/'policy-control.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Reweight the complete recorded1/2-ply action census without new game transitions. Hierarchical policy gives equal mass to each nonempty ordinary-capture, quiet-board, drop category, uniform within category. Alternative minimax maximizes owner0 ordinary-control delta and minimizes owner1, finite2plies/no extra terminal payoff. These are distinct declared response laws; not a universal policy or post-hoc price promotion. Compare exact equalities, not whichever matches human prices.',rows=[]);write_record(out,r)
for old in src['rows']:
 values=[[],[]];balanced=[Fraction(0),Fraction(0)];categories={};same_counts=True
 for v in old['replies']:
  category='capture' if v['cases'][0]['root_reward'] else 'quiet_board';categories.setdefault(category,[]).append(v)
  for j,c in enumerate(v['cases']):
   caps=c['next_capture_count'];drops=c['next_drop_count'];quiet=c['next_legal_count']-caps-drops;nonempty=sum(x>0 for x in (caps,drops,quiet));assert quiet>=0
   c['balanced_next_mean']=Fraction(c['next_capture_numerator'],caps*nonempty) if caps else Fraction(0)
   minimum=-2 if caps else 0;values[j].append(c['root_reward']+minimum)
  same_counts &= [v['cases'][0]['next_capture_count']>0,v['cases'][0]['next_drop_count']>0,v['cases'][0]['next_legal_count']-v['cases'][0]['next_capture_count']-v['cases'][0]['next_drop_count']>0]==[v['cases'][1]['next_capture_count']>0,v['cases'][1]['next_drop_count']>0,v['cases'][1]['next_legal_count']-v['cases'][1]['next_capture_count']-v['cases'][1]['next_drop_count']>0]
 for vv in categories.values():
  for v in vv:
   for j,c in enumerate(v['cases']):balanced[j]+=Fraction(c['root_reward']+c['balanced_next_mean'],len(vv)*len(categories))
 minimax=[max(x) for x in values];r['rows'].append(dict(seed=old['seed'],uniform_difference=old['difference'],balanced_values=balanced,balanced_difference=balanced[0]-balanced[1],same_category_availability=same_counts,minimax=minimax,minimax_difference=minimax[0]-minimax[1]));write_record(out,r)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
for x in r['rows']:print(x['seed'],'balanced',x['balanced_difference'],'minimax',x['minimax_difference'],'category availability',x['same_category_availability'])
