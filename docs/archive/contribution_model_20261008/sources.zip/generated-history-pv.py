"""One generated promotion/drop history, same public output/resource controls."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_is_board,action_is_drop,action_promotion_target_id
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv,CountedEvaluator,ReferenceLimit
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'generated-history-pv-completed.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Existing generator6x6seed21/bilateral_random/hybrid with standard playability filters. Preselect at most12 actual plies: first promotion if unseen, first drop if promotion seen, otherwise first ordinary capture, then first lexical legal action. Stop once promotion and drop occurred, or terminal. No result-selected roots. Hold fixed static generic-v1 board/hand tables with shared memory profile cache. Public full-PV false/true x requested depths4/5 x4096/16384nodes, fresh player then warm repeat,10sec emergency deadline,q0,no root tactics/PVS/aspiration. Core references depth2/3 at20000leaves/15sec; unknown on fuse. Measure eventful history interface/output and resource/result curves; not strength, new weights or universal coverage.',history=[],events=[],calls=[],references=[]);write_record(out,r)
game=generate_game(GeneratorConfig(seed=21,board_size=6,setup_preset='bilateral_random',allow_hybrid=True));c=game.compiled_ruleset;s=GameSession(c);r.update(definition=ruleset_to_dict(game.ruleset),filters=record_value(game.generation_report),fingerprint=c.ruleset_fingerprint)
seen_promotion=False;seen_drop=False
for ply in range(12):
 if s.state.terminal_status.is_terminal:break
 aa=sorted(s.legal_actions(),key=str);prom=[a for a in aa if action_promotion_target_id(a) is not None];drops=[a for a in aa if action_is_drop(a)];caps=[a for a in aa if action_is_board(a) and (v:=s.state.position.board[a.to_square.file+6*a.to_square.rank]) is not None and not c.types_by_id[v.current_type_id].is_anchor]
 candidates=prom if not seen_promotion and prom else drops if seen_promotion and drops else caps if caps else aa
 if not candidates:break
 a=candidates[0];event=dict(ply=ply+1,promotion=action_promotion_target_id(a),drop=action_is_drop(a),capture=a in caps);s.submit(a);seen_promotion |= event['promotion'] is not None;seen_drop |= event['drop'];r['history'].append(record_value(a));r['events'].append(event);write_record(out,r)
 if seen_promotion and seen_drop:break
r['state']=record_value(s.state);r['opening_legal_count']=len(s.legal_actions());r['selected_root_has_promotion']=seen_promotion;r['selected_root_has_drop']=seen_drop
cache=EvaluationProfileCache(use_disk=False);profile=cache.get_or_build(c,EvaluationConfig())[0];board=dict(profile.board_value_by_type);hand=dict(profile.hand_value_by_base_type);r.update(board_values=board,hand_values=hand)
class Static:
 def capture_order_value(self,moving_piece,captured_piece):return 10*board[captured_piece.current_type_id]-board[moving_piece.current_type_id]//10
 def evaluate(self,state):
  pos=state.position;side=pos.side_to_move
  return sum(board[x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(hand[t]*n*(1 if owner==side else -1) for owner,h in enumerate(pos.hands) for t,n in h.counts)
e=Static()
for depth in (2,3):
 counted=CountedEvaluator(e,seconds=15,evaluations=20000);t=time.perf_counter()
 try:score,action=reference_minimax(s.state,depth,counted,c);ref=dict(depth=depth,complete=True,score=score,action=record_value(action))
 except ReferenceLimit:ref=dict(depth=depth,complete=False,score=None)
 ref.update(seconds=time.perf_counter()-t,evaluations=counted.calls);r['references'].append(ref);write_record(out,r)
for full in (False,True):
 for depth in (4,5):
  for cap in (4096,16384):
   assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused');player=AlphaBetaPlayer(c,evaluator_override=e,profile_cache=cache,use_disk_cache=False,tt_max_entries=16384,tuning=SearchTuning(use_root_tactical=False,require_full_pv=full))
   for repeat in (0,1):
    t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=cap,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);check=GameSession(c)
    for rec in s.history:check.submit(rec.action)
    for a in d.principal_variation:check.submit(a)
    satisfied=len(d.principal_variation)>=d.completed_depth or check.state.terminal_status.is_terminal
    if full:assert satisfied
    r['calls'].append(dict(full_pv=full,target_depth=depth,node_cap=cap,repeat=repeat,seconds=time.perf_counter()-t,full_contract=satisfied,native_provider_present=player.native_legality_provider is not None,decision=record_value(d)));write_record(out,r);print(full,depth,cap,repeat,d.completed_depth,d.score,len(d.principal_variation),flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print('events',r['events'],'seconds',r['seconds'])
