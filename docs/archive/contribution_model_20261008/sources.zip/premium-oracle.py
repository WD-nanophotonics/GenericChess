"""Independent coordinate/full-board oracle for matched ability premiums."""
import sys,json,time,hashlib,itertools,random
from pathlib import Path
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'ability-premium.json').read_bytes();src=json.loads(raw);out=p/'premium-oracle.json';assert not out.exists();contexts=list(itertools.permutations(range(16),3));indices=sorted(random.Random(2026100807).sample(range(3360),64));start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Independent coordinate movement predicates, full occupancy/capture reconstruction and both active/passive minimax.64 seed2026100807 sampled indices per16 modepairs,2depths x2phases=4096 premium checks plus8192 individual utility checks. No producer geometry/DP reuse. Qualifies sampled roots only.',indices=indices,rows=[]);write_record(out,r)
def destinations(mode,s,board,owner):
 for t in range(16):
  if t==s or board.get(t,(-1,''))[0]==owner:continue
  dx,dy=t%4-s%4,t//4-s//4
  if mode=='N':
   if sorted((abs(dx),abs(dy)))==[1,2]:yield t
   continue
  if not ((mode=='Q' and (dx==0 or dy==0 or abs(dx)==abs(dy))) or (mode=='R' and (dx==0 or dy==0)) or (mode=='B' and abs(dx)==abs(dy))):continue
  sx=(dx>0)-(dx<0);sy=(dy>0)-(dy<0);x,y=s%4+sx,s//4+sy
  while (x,y)!=(t%4,t//4):
   if x+4*y in board:break
   x+=sx;y+=sy
  else:yield t
for row in src['rows']:
 assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
 edges=0
 @lru_cache(None)
 def solve(items,side,depth,ability):
  global edges
  board=dict(items)
  if depth==0 or not any(piece[0]==0 for piece in board.values()):return 0
  values=[solve(items,1-side,depth-1,ability)]
  moving=next(((s,piece) for s,piece in items if piece[0]==side and piece[1]!='inert'),None)
  if moving is not None and (side==1 or ability):
   s,piece=moving
   for t in destinations(piece[1],s,board,side):
    edges+=1;child=dict(board);child.pop(s);victim=child.pop(t,None);child[t]=piece;reward=(1 if side==0 else -1) if victim is not None else 0
    values.append(reward+solve(tuple(sorted(child.items())),1-side,depth-1,ability))
  return (max if side==0 else min)(values)
 mismatches=[]
 for index in indices:
  s,e,v=contexts[index];board=tuple(sorted(((s,(0,row['actor'])),(e,(1,row['opponent'])),(v,(1,'inert')))))
  for cell in row['cells']:
   active=solve(board,cell['side'],cell['depth'],True);passive=solve(board,cell['side'],cell['depth'],False)
   if (active,passive,active-passive)!=(cell['per_root_active'][index],cell['per_root_passive'][index],cell['per_root_premium'][index]):mismatches.append(dict(index=index,depth=cell['depth'],side=cell['side'],active=active,passive=passive))
 r['rows'].append(dict(actor=row['actor'],opponent=row['opponent'],premium_checks=256,individual_checks=512,mismatches=mismatches,edges=edges));write_record(out,r);assert not mismatches
r.update(complete=True,seconds=time.perf_counter()-start,premium_checks=4096,individual_checks=8192);write_record(out,r);print('Independent checks',r['premium_checks'],r['individual_checks'],'seconds',r['seconds'])
