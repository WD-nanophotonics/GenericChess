"""Predeclared small stratified board-scale check of the changed ability task."""
import sys,json,time,hashlib,random,importlib.util
from pathlib import Path
from functools import lru_cache
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;dependency=ROOT/'.local_agent/joint-exposure-20261008/census.py';spec=importlib.util.spec_from_file_location('primitive_geometry',dependency);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=p/'premium-boundary-expanded.json';assert not out.exists();rng=random.Random(2026100809);sources={'edge':[s for s in range(64) if s%8 in (0,7) or s//8 in (0,7)],'interior':[s for s in range(64) if s%8 not in (0,7) and s//8 not in (0,7)]};contexts=[]
for stratum,ss in sources.items():
 for _ in range(256):
  s=rng.choice(ss);e,v=rng.sample([x for x in range(64) if x!=s],2);contexts.append(dict(stratum=stratum,s=s,e=e,v=v))
start=time.perf_counter();r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(dependency.read_bytes()).hexdigest(),declaration='Same matched immobile-reference/optional-pass4ply task as ability-premium, board8x8.Incremental development batch512 seeded contexts:256edge actor-source/256interior, enemy/target drawn without overlap. Reuse same contexts for8 B/N versus4 opponent modepairs, both phases. Report strata separately;50/50 stratum average is not uniform8x8 occupancy. Decision: initial32-context strata suggest different B-minus-N premiums; narrow sampling uncertainty for this paired mean, and weight edge/interior by28/64 and36/64 to reconstruct declared uniform source law. New seed, no human labels, do not restore holdout qualification. Expected incremental cost about60sec from initial6.47sec/16pairs; not increase chosen after an unfavorable success test. One serial batch, cache cleared per root, stop flags per root,240sec cost checkpoint per pair; incomplete output retained if crossed, no outcome-driven sampling. Not legal games, pawn prices or human fitting.',contexts=contexts,rows=[],virtual_edges=0);write_record(out,r)
for a in ('B','N'):
 for o in ('Q','R','B','N'):
  ar,er=m.build(8,a),m.build(8,o);pair_start=time.perf_counter();row=dict(actor=a,opponent=o,roots=[]);r['rows'].append(row)
  @lru_cache(None)
  def solve(s,e,v,side,depth,ability):
   if depth==0 or s<0:return 0
   choices=[solve(s,e,v,1-side,depth-1,ability)]
   if side==0 and ability:
    for t in m.moves(ar,s,(),tuple(x for x in (e,v) if x>=0)):
     r['virtual_edges']+=1;choices.append(int(t==e or t==v)+solve(t,-1 if t==e else e,-1 if t==v else v,1,depth-1,ability))
   elif side==1 and e>=0:
    for t in m.moves(er,e,() if v<0 else (v,),(s,)):
     r['virtual_edges']+=1;choices.append(-1 if t==s else solve(s,t,v,0,depth-1,ability))
   return (max if side==0 else min)(choices)
  for ctx in contexts:
   assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused');solve.cache_clear();cells=[]
   for side in (0,1):
    active=solve(ctx['s'],ctx['e'],ctx['v'],side,4,True);passive=solve(ctx['s'],ctx['e'],ctx['v'],side,4,False);assert active>=passive;cells.append(dict(side=side,active=active,passive=passive,premium=active-passive))
   row['roots'].append(dict(context=ctx,cells=cells,dp_entries=solve.cache_info().currsize));write_record(out,r)
   if time.perf_counter()-pair_start>240:raise RuntimeError('cost checkpoint; incomplete retained')
  row['seconds']=time.perf_counter()-pair_start;row['strata']={st:Fraction(sum(c['premium'] for x in row['roots'] if x['context']['stratum']==st for c in x['cells']),512) for st in sources};write_record(out,r);print(a,o,row['strata'],row['seconds'],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print('edges',r['virtual_edges'],'seconds',r['seconds'])
