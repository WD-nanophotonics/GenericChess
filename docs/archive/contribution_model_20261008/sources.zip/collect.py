"""Compact current conclusions and isolate exact development evidence."""
import sys,json,math,hashlib,zipfile,tempfile,re
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;archive=ROOT/'docs/archive/contribution_model_20261008';archive.mkdir(exist_ok=True);out=ROOT/'docs/research/data/contribution_model_20261008.json';assert not out.exists()
def read(n):return json.loads((p/n).read_bytes())
raw_names=['whole-state.json','action-dilution.json','policy-control.json','policy-control-corrected.json','tt-provenance.json','ability-premium.json','premium-oracle.json','premium-boundary.json','premium-boundary-expanded.json','boundary-oracle.json','partial-pawn-premium.json','pawn-promotion.json','whole-native-oracle.json','whole-native-oracle-completed.json','generated-history-pv.json','generated-history-pv-completed.json','whole-minimax.json','whole-core-oracle.json','conditional-spectrum.json','record-cadence.json']
mc=read('whole-state.json');dilution=read('action-dilution.json');ability=read('ability-premium.json');boundary=read('premium-boundary-expanded.json');pawn=read('partial-pawn-premium.json');promotion=read('pawn-promotion.json');tt=read('tt-provenance.json');generated=read('generated-history-pv-completed.json');spectrum=read('conditional-spectrum.json')
summary=dict(complete=True,scope='Declared contribution tasks, response/baseline/context bias and full-PV resource contracts; no default material-price or strength promotion',repository_base_sha='d3449839769fe10c0739e31da860fdaec7f85399',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),raw_sources={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in raw_names})
summary['whole_state']=dict(declaration=mc['declaration'],frontier_seed=mc['frontier_seed'],initial_control=mc['initial_control'],trajectories=len(mc['trajectories']),transitions=mc['core_transitions'],seconds=mc['seconds'],summary=mc['summary'],native_oracle={k:v for k,v in read('whole-native-oracle-completed.json').items() if k not in ('producer_sha256','source_sha256','rows')})
summary['dilution']=dict(declaration=dilution['declaration'],core_transitions=dilution['core_transitions'],native_legal_set_checks=dilution['native_legal_set_checks'],seconds=dilution['seconds'],rows=[{k:v for k,v in x.items() if k!='replies'} for x in dilution['rows']],alternative_response=read('policy-control-corrected.json')['rows'],initial_classification_failure='Initial root categorization treated drops as other board moves; corrected category means replace them. Both versions retained; zero paired contrasts unchanged.')
summary['whole_minimax']={k:v for k,v in read('whole-minimax.json').items() if k not in ('producer_sha256','source_sha256','definition_sha256')};summary['whole_core_reference']={k:v for k,v in read('whole-core-oracle.json').items() if k not in ('producer_sha256','source_sha256')};summary['whole_core_reference']['timing_scope']='Core reference overlapped the default test run; unknown cells remain unknown and timing is not an isolated speed comparison.'
summary['conditional_spectrum']=dict(declaration=spectrum['declaration'],rows=[{k:v for k,v in x.items() if k!='cells'} for x in spectrum['rows']],paired=spectrum['paired'])
summary['ability']=dict(declaration=ability['declaration'],means=ability['means'],seconds=ability['seconds'],virtual_edges=sum(x['edges'] for x in ability['rows']),dp_entries=sum(x['dp_entries'] for x in ability['rows']),independent_premium_checks=read('premium-oracle.json')['premium_checks'],independent_individual_checks=read('premium-oracle.json')['individual_checks'],strata=[dict(actor=row['actor'],opponent=row['opponent'],cells=[{k:v for k,v in x.items() if not k.startswith('per_root')} for x in row['cells']]) for row in ability['rows']])
summary['ability']['baseline_is_shared']=True
for o in ('Q','R','B','N'):
 for depth in (2,4):
  for side in (0,1):
   aa=[x['per_root_passive'] for row in ability['rows'] if row['opponent']==o for x in row['cells'] if x['depth']==depth and x['side']==side];assert all(x==aa[0] for x in aa)
summary['ability']['shared_baseline_means']={depth:sum(Fraction(x['passive_mean']) for row in ability['rows'] if row['actor']=='Q' for x in row['cells'] if x['depth']==depth)/8 for depth in (2,4)}
summary['ability']['interpretation']='At a matched context the immobile baseline cancels in actor-to-actor differences. It changes the reference and ratios; nonnegative option premium alone does not calibrate stock prices.'
summary['boundary']=dict(declaration=boundary['declaration'],virtual_edges=boundary['virtual_edges'],seconds=boundary['seconds'],final_raw_bytes=(p/'premium-boundary-expanded.json').stat().st_size,atomic_record_writes=4106,strata=[],independent_premium_checks=read('boundary-oracle.json')['premium_checks'],independent_individual_checks=read('boundary-oracle.json')['individual_checks'])
for st,indices,weight in [('edge',range(256),Fraction(28,64)),('interior',range(256,512),Fraction(36,64))]:
 diffs=[];means={a:[] for a in ('B','N')}
 for i in indices:
  for a in ('B','N'):means[a].append(Fraction(sum(c['premium'] for row in boundary['rows'] if row['actor']==a for c in row['roots'][i]['cells']),8))
  diffs.append(means['B'][-1]-means['N'][-1])
 mean=sum(diffs)/256;se=math.sqrt(sum(float(x-mean)**2 for x in diffs)/255/256)
 summary['boundary']['strata'].append(dict(stratum=st,contexts=256,source_weight=weight,means={a:sum(v)/256 for a,v in means.items()},paired_mean_difference=mean,descriptive_standard_error=se,negative=sum(x<0 for x in diffs),zero=diffs.count(0),positive=sum(x>0 for x in diffs)))
summary['boundary']['weighted_mean_difference']=sum(x['source_weight']*x['paired_mean_difference'] for x in summary['boundary']['strata']);summary['boundary']['weighted_descriptive_standard_error']=math.sqrt(sum((float(x['source_weight'])*x['descriptive_standard_error'])**2 for x in summary['boundary']['strata']))
summary['partial_pawn']=dict(declaration=pawn['declaration'],means=pawn['means'],seconds=pawn['seconds']);summary['promotion']=dict(declaration=promotion['declaration'],means=promotion['means'],seconds=promotion['seconds'],rank_means={depth:{rank:{field:sum(Fraction(cell['rank_means'][str(rank)][field]) for row in promotion['rows'] for cell in row['cells'] if cell['depth']==depth)/8 for field in ('plain_premium','promoted_premium')} for rank in range(3)} for depth in (2,4)})
summary['shared_population_vectors']={}
for depth in (2,4):
 vector={a:Fraction(sum(cell['per_root_premium'][i] for row in ability['rows'] if row['actor']==a for cell in row['cells'] if cell['depth']==depth for i in promotion['indices']),8*2520) for a in ('Q','R','B','N')};denoms={k:Fraction(v) for k,v in promotion['means'][str(depth)].items()};summary['shared_population_vectors'][depth]=dict(population='same2520source-rank0/1/2contexts for every actor; equal opponents/phases',absolute_premiums=vector,pawn_premiums=denoms,ratios={k:{a:v/denominator for a,v in vector.items()} for k,denominator in denoms.items()})
fields=('action','score','completed_depth','principal_variation','nodes','qnodes','tt_hits','termination_reason')
summary['tt_provenance']=dict(declaration=tt['declaration'],seconds=tt['seconds'],rows=[dict(full_pv=row['full_pv'],node_cap=row['node_cap'],repeat=row['repeat'],calls=[dict(label=x['label'],target=x['target'],before=x['before'],after=x['after'],seconds=x['seconds'],decision={k:x['decision'][k] for k in fields}) for x in row['calls']]) for row in tt['rows']])
summary['generated_history']=dict(declaration=generated['declaration'],fingerprint=generated['fingerprint'],events=generated['events'],actual_promotion=generated['selected_root_has_promotion'],actual_drop=generated['selected_root_has_drop'],opening_legal_count=generated['opening_legal_count'],references=generated['references'],seconds=generated['seconds'],calls=[dict(**{k:v for k,v in x.items() if k!='decision'},decision={k:x['decision'][k] for k in fields}) for x in generated['calls']])
summary['record_cadence']={k:v for k,v in read('record-cadence.json').items() if k not in ('producer_sha256','source_sha256')};summary['record_cadence']['timing_scope']='Includes byte-count encoding/checks and atomic writer. A bounded overhead comparison, not production speed or measured total bytes of the earlier512-context producer.'
write_record(out,summary)
index=dict(original_directory='.local_agent/frontier-contribution-20261008',repository_base_sha=summary['repository_base_sha'],current_result=dict(path=str(out.relative_to(ROOT)).replace('\\','/'),sha256=hashlib.sha256(out.read_bytes()).hexdigest()),archives={},dependencies=[],repository_dependencies=[])
sources=sorted(p.glob('*.py'));available=set()
for name,files in [('sources.zip',sources),('raw.zip',[p/n for n in raw_names])]:
 target=archive/name;assert not target.exists();members={}
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f in files:
   b=f.read_bytes();assert not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b) and not re.search(rb'\b[UT][0-9A-Z]{10,}\b',b) and (b'-----BEGIN '+b'PRIVATE KEY-----') not in b;z.writestr(f.name,b);members[f.name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());available.add(members[f.name]['sha256'])
 with tempfile.TemporaryDirectory(prefix='extract-',dir=p) as td,zipfile.ZipFile(target) as z:
  assert z.testzip() is None;z.extractall(td)
  for n,m in members.items():assert hashlib.sha256((Path(td)/n).read_bytes()).hexdigest()==m['sha256']
 index['archives'][name]=dict(sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=members,physically_extracted_rehashed=True)
for path,n in [('docs/archive/joint_service_20261008/sources.zip','census.py')]+[('docs/archive/custody_continuation_20261008/raw.zip',n) for n in ('kernel-completed.json','pretransfer-coupling.json','returned-history-search.json')]:
 with zipfile.ZipFile(ROOT/path) as z:b=z.read(n)
 h=hashlib.sha256(b).hexdigest();available.add(h);index['dependencies'].append(dict(archive=path,member=n,sha256=h))
for path in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/transposition.py'):
 h=hashlib.sha256((ROOT/path).read_bytes()).hexdigest();available.add(h);index['repository_dependencies'].append(dict(path=path,commit=summary['repository_base_sha'],sha256=h))
for n in raw_names:
 d=read(n)
 for pin in [d.get(k) for k in ('producer_sha256','source_sha256','definition_sha256','dependency_sha256','prior_sha256')]+list(d.get('source_pins',{}).values()):
  if pin:assert pin in available,(n,pin)
index['producer_and_source_pins_resolved']=True;write_record(archive/'index.json',index);print('archive members',sum(len(x['members']) for x in index['archives'].values()),'current bytes',out.stat().st_size,'boundary difference',summary['boundary']['weighted_mean_difference'])
