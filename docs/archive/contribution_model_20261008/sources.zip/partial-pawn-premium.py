"""A changed premise: matched immobile reference, optional virtual passes."""
import sys,json,time,hashlib,itertools,importlib.util
from pathlib import Path
from functools import lru_cache
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;dependency=ROOT/'.local_agent/joint-exposure-20261008/census.py';spec=importlib.util.spec_from_file_location('primitive_geometry',dependency);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=p/'partial-pawn-premium.json';assert not out.exists();contexts=list(itertools.permutations(range(16),3));start=time.perf_counter()
def pawn_moves(s,e,v):
 x,y=s%4,s//4
 if y==3:return
 t=s+4
 if t not in (e,v):yield t
 for dx in (-1,1):
  if 0<=x+dx<4:
   t=x+dx+4*(y+1)
   if t==e or t==v:yield t
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(dependency.read_bytes()).hexdigest(),declaration='New counterfactual task, not rescue of prior signed reward normalization. Pawn-specific development extension: ordered4x4 source/activeenemy/passiveenemy population3360 per4 opponent modes. Owner0 partial pawn has one-square empty forward move and enemy-only diagonal capture, always-forward rank; no double move, en-passant or promotion. Includes immobile last-rank roots. This is a declared partial pawn law, NOT full Chess pawn semantics. Enables a scoped descriptive normalization check of2/4ply ability premiums, not a stock price or default selection. No reference labels enter the construction. Both sides may always pass; own baseline actor may only pass but remains occupied/capturable. Ability variant may pass or use its ordinary geometric moves. Reward enemy entity removal+1 and actor loss-1, no anchors/hands/promotions. Compare V(ability)-V(immobile) at2/4plies both initial phases under minimax. Backward strategy inclusion predicts nonnegative premium at every root; positivity is an option premium for this artificial pass task, not stock/material prices. No pawn scaling, human-price fitting or legal-game claim.',rows=[]);write_record(out,r)
for a in ('P',):
 for o in ('Q','R','B','N'):
  assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
  ar,er=None,m.build(4,o);edges=0
  @lru_cache(None)
  def solve(s,e,v,side,depth,ability):
   global edges
   if depth==0 or s<0:return 0
   choices=[solve(s,e,v,1-side,depth-1,ability)]
   if side==0 and ability:
    for t in pawn_moves(s,e,v):
     edges+=1;gain=int(t==e or t==v);choices.append(gain+solve(t,-1 if t==e else e,-1 if t==v else v,1,depth-1,ability))
   elif side==1 and e>=0:
    for t in m.moves(er,e,() if v<0 else (v,),(s,)):
     edges+=1;choices.append(-1 if t==s else solve(s,t,v,0,depth-1,ability))
   return (max if side==0 else min)(choices)
  row=dict(actor=a,opponent=o,cells=[],edges=0)
  for depth in (2,4):
   for side in (0,1):
    passive=[];active=[];premium=[]
    for s,e,v in contexts:
     b=solve(s,e,v,side,depth,False);x=solve(s,e,v,side,depth,True);assert x>=b;passive.append(b);active.append(x);premium.append(x-b)
    row['cells'].append(dict(depth=depth,side=side,passive_mean=Fraction(sum(passive),3360),active_mean=Fraction(sum(active),3360),premium_mean=Fraction(sum(premium),3360),premium_histogram={x:premium.count(x) for x in sorted(set(premium))},per_root_premium=premium,per_root_active=active,per_root_passive=passive))
  row['edges']=edges;row['dp_entries']=solve.cache_info().currsize;r['rows'].append(row);write_record(out,r);print(a,o,[str(x['premium_mean']) for x in row['cells']],flush=True)
r['means']={a:{depth:Fraction(sum(Fraction(x['premium_mean']) for row in r['rows'] if row['actor']==a for x in row['cells'] if x['depth']==depth),8) for depth in (2,4)} for a in ('P',)};r.update(complete=True,seconds=time.perf_counter()-start,nonnegative_violations=0,core_transitions=0);write_record(out,r);print('means',r['means'],'seconds',r['seconds'])
