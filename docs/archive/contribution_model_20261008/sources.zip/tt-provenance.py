"""Deterministic node-budget witnesses of persistent deeper-cache provenance."""
import sys,json,time,hashlib,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=ROOT/'.local_agent/custody-kernel-20261008';raw=(old/'returned-history-search.json').read_bytes();src=json.loads(raw);defs_raw=(old/'kernel-completed.json').read_bytes();defs=json.loads(defs_raw);case=next(x for x in defs['cases'] if x['base']=='P');root=next(x for x in src['rows'] if x['base']=='P');c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));s=GameSession(c)
for v in root['history']:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
class Static:
 def capture_order_value(self,moving_piece,captured_piece):return 10*root['board_values'][captured_piece.current_type_id]-root['board_values'][moving_piece.current_type_id]//10
 def evaluate(self,state):
  pos=state.position;side=pos.side_to_move
  return sum(root['board_values'][x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(root['hand_values'][t]*v*(1 if o==side else -1) for o,h in enumerate(pos.hands) for t,v in h.counts)
out=p/'tt-provenance.json';assert not out.exists();start=time.perf_counter();r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),definition_sha256=hashlib.sha256(defs_raw).hexdigest(),source_pins={x:hashlib.sha256((ROOT/x).read_bytes()).hexdigest() for x in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/transposition.py')},declaration='One frozen full five-ply returned-hand P history and static evaluator. PVS/root-tactics/aspiration off, q0,16384 TT entries. Full-PV false/true. Predeclared node budgets1024,4096,16384; each repeated twice from fresh player: warm-up target4 (possibly interrupted), target3 with retained TT, target3 after reset.30sec emergency cap per call; if it fires classify not deterministic node evidence. Snapshot TT root/depth distributions before/after each call; no TT bypass/default changes. Resource ceilings same per target3, no result-driven extension.',rows=[]);write_record(out,r)
def table(player):
 runtime=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=player.native_legality_provider);entry=player._tt.probe(runtime.search_key())
 return dict(size=len(player._tt),depths=dict(collections.Counter(x.depth for x in player._tt._data.values())),root=None if entry is None else dict(depth=entry.depth,score=entry.score,bound=entry.bound.name,generation=entry.generation,action=record_value(entry.best_action)))
for full in (False,True):
 for cap in (1024,4096,16384):
  for repeat in (0,1):
   assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
   player=AlphaBetaPlayer(c,evaluator_override=Static(),use_disk_cache=False,tt_max_entries=16384,tuning=SearchTuning(use_root_tactical=False,require_full_pv=full));row=dict(full_pv=full,node_cap=cap,repeat=repeat,calls=[]);r['rows'].append(row)
   for label,depth in (('fresh_deeper',4),('retained_shallower',3),('reset_shallower',3)):
    if label=='reset_shallower':player.reset()
    before=table(player);iterations=[];t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=cap,max_time_seconds=30,quiescence_max_depth=0,quiescence_hard_max_depth=0),progress_callback=lambda depth,nodes,qnodes:iterations.append(dict(depth=depth,nodes=nodes,qnodes=qnodes,table=table(player))))
    validate_pv(s,d);row['calls'].append(dict(label=label,target=depth,before=before,after=table(player),iterations=iterations,decision=record_value(d),seconds=time.perf_counter()-t));write_record(out,r);print(full,cap,repeat,label,d.completed_depth,d.score,d.nodes+d.qnodes,d.termination_reason,flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
