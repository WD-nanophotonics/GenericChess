"""Predeclared finite whole-state control comparison, not material prices."""
import sys,json,time,random,hashlib,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import SemanticBoardMove
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;prior=ROOT/'.local_agent/custody-kernel-20261008';raw=(prior/'pretransfer-coupling.json').read_bytes();src=json.loads(raw);definition_raw=(prior/'kernel-completed.json').read_bytes();cases=json.loads(definition_raw)['cases'];frontier=sorted(src['frontiers'],key=lambda x:x['seed'])[0]
out=p/'whole-state.json';assert not out.exists();start=time.perf_counter()
compiled=[compile_ruleset_for_execution(ruleset_from_dict(x['definition'])) for x in cases];anchors={x.type_id for x in compiled[0].piece_types if x.is_anchor}
def utility(state):
 pos=state.position
 return sum((1 if x.owner==0 else -1) for x in pos.board if x is not None and x.current_type_id not in anchors)+sum((1 if owner==0 else -1)*count for owner,hand in enumerate(pos.hands) for base,count in hand.counts if base not in anchors)
def total(state):
 return sum(x is not None and x.current_type_id not in anchors for x in state.position.board)+sum(count for hand in state.position.hands for base,count in hand.counts if base not in anchors)
states=[];replay_count=0
for c,actions,saved in zip(compiled,frontier['paired_actions'],frontier['paired_states']):
 state=initial_state(c)
 for v in actions:state=apply_action(state,next(a for a in legal_actions(state,c) if record_value(a)==v),c);replay_count+=1
 assert record_value(state)==saved;states.append(state)
assert utility(states[0])==utility(states[1]);assert total(states[0])==total(states[1])==38
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),definition_sha256=hashlib.sha256(definition_raw).hexdigest(),frontier_seed=frontier['seed'],frontier_ply=frontier['ply'],initial_control=[utility(s) for s in states],declaration=dict(question='Does whole-state signed ordinary-entity control distinguish base continuation at a preselected paired first-transfer frontier?',population='First frontier in ascending seed order, not result-selected. Qualified counterfactual G/TP roots, historical reachability unproved.',policy='Both players uniform over every legal action, canonical sorted serialized action. Shared pseudorandom uniforms across base cases provide paired sampling, not equal actions after action sets diverge. Seeds2026100806+i for32 trajectories.',utility='Owner0 ordinary board-plus-hand entity count minus owner1 count. Report terminal control minus initial control, no extra WDL payoff. Shogi ordinary capture transfers control for +/-2; drops/promotions change0. This is a declared unit task, never positive material prices or tagged-only service.',horizons=[8,16,32,64],cost='32 paired trajectories,64 plies maximum4096 continuation transitions, serial; persist every trial; stop flags per trial. Outcome changes whether to examine finite whole-state contribution or reject this uniform policy as too weak/noisy, not a success threshold selected after results.'),trajectories=[],core_transitions=0,replay_transitions=replay_count);write_record(out,r)
for trial in range(32):
 assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
 uniforms=[random.Random(2026100806+trial).random()]
 rng=random.Random(2026100806+trial);uniforms=[rng.random() for _ in range(64)];row=dict(seed=2026100806+trial,cases=[])
 for case,c,initial in zip(cases,compiled,states):
  state=initial;actions=[];snapshots={};events=[];plies=0
  for ply,u in enumerate(uniforms):
   if state.terminal_status.is_terminal:break
   aa=sorted(legal_actions(state,c),key=lambda a:json.dumps(record_value(a),sort_keys=True));assert aa
   a=aa[min(len(aa)-1,int(u*len(aa)))];before=utility(state);expected=0
   if isinstance(a,SemanticBoardMove):
    victim=state.position.board[a.to_square.file+9*a.to_square.rank]
    if victim is not None and victim.current_type_id not in anchors:expected=2 if state.position.side_to_move==0 else -2
   state=apply_action(state,a,c);r['core_transitions']+=1;plies+=1;delta=utility(state)-before
   assert delta==expected and total(state)==38
   if delta:events.append(dict(ply=plies,delta=delta))
   actions.append(record_value(a))
   if plies in (8,16,32,64):snapshots[str(plies)]=utility(state)-utility(initial)
  for h in (8,16,32,64):snapshots.setdefault(str(h),utility(state)-utility(initial))
  row['cases'].append(dict(base=case['base'],plies=plies,control_delta=snapshots,events=events,actions=actions,terminal=record_value(state.terminal_status),final_state=record_value(state)))
 r['trajectories'].append(row);write_record(out,r)
 if trial%8==7:print('completed paired trajectories',trial+1,'transitions',r['core_transitions'],flush=True)
r['summary']=[]
for h in (8,16,32,64):
 vals=[[t['cases'][j]['control_delta'][str(h)] for t in r['trajectories']] for j in (0,1)];d=[a-b for a,b in zip(*vals)];mean=sum(d)/len(d);se=math.sqrt(sum((x-mean)**2 for x in d)/(len(d)-1)/len(d))
 r['summary'].append(dict(horizon=h,sums=[sum(x) for x in vals],paired_differences=d,mean_difference=mean,descriptive_standard_error=se))
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print(json.dumps(r['summary']),r['seconds'])
