"""Independent coordinate/full-board oracle for matched ability premiums."""
import sys,json,time,hashlib,itertools,random
from pathlib import Path
from functools import lru_cache
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'premium-boundary-expanded.json').read_bytes();src=json.loads(raw);out=p/'boundary-oracle.json';assert not out.exists();contexts=json.loads(raw)['contexts'];rng=random.Random(2026100810);indices=sorted(rng.sample(range(256),64)+rng.sample(range(256,512),64));start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Independent coordinate movement predicates, full occupancy/capture reconstruction and both active/passive minimax.128 seed2026100810 indices,64 per source stratum, across8 B/N-opponent pairs and2phases=2048 premium/4096 individual utility checks on8x8. Cache cleared per root to bound memory. No producer geometry/DP reuse, qualifies sampled roots only. No producer geometry/DP reuse. Qualifies sampled roots only.',indices=indices,rows=[]);write_record(out,r)
def destinations(mode,s,board,owner):
 for t in range(64):
  if t==s or board.get(t,(-1,''))[0]==owner:continue
  dx,dy=t%8-s%8,t//8-s//8
  if mode=='N':
   if sorted((abs(dx),abs(dy)))==[1,2]:yield t
   continue
  if not ((mode=='Q' and (dx==0 or dy==0 or abs(dx)==abs(dy))) or (mode=='R' and (dx==0 or dy==0)) or (mode=='B' and abs(dx)==abs(dy))):continue
  sx=(dx>0)-(dx<0);sy=(dy>0)-(dy<0);x,y=s%8+sx,s//8+sy
  while (x,y)!=(t%8,t//8):
   if x+8*y in board:break
   x+=sx;y+=sy
  else:yield t
for row in src['rows']:
 assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
 edges=0
 @lru_cache(None)
 def solve(items,side,depth,ability):
  global edges
  board=dict(items)
  if depth==0 or not any(piece[0]==0 for piece in board.values()):return 0
  values=[solve(items,1-side,depth-1,ability)]
  moving=next(((s,piece) for s,piece in items if piece[0]==side and piece[1]!='inert'),None)
  if moving is not None and (side==1 or ability):
   s,piece=moving
   for t in destinations(piece[1],s,board,side):
    edges+=1;child=dict(board);child.pop(s);victim=child.pop(t,None);child[t]=piece;reward=(1 if side==0 else -1) if victim is not None else 0
    values.append(reward+solve(tuple(sorted(child.items())),1-side,depth-1,ability))
  return (max if side==0 else min)(values)
 mismatches=[]
 for index in indices:
  solve.cache_clear();ctx=contexts[index];s,e,v=ctx['s'],ctx['e'],ctx['v'];board=tuple(sorted(((s,(0,row['actor'])),(e,(1,row['opponent'])),(v,(1,'inert')))))
  for cell in row['roots'][index]['cells']:
   active=solve(board,cell['side'],4,True);passive=solve(board,cell['side'],4,False)
   if (active,passive,active-passive)!=(cell['active'],cell['passive'],cell['premium']):mismatches.append(dict(index=index,depth=4,side=cell['side'],active=active,passive=passive))
 r['rows'].append(dict(actor=row['actor'],opponent=row['opponent'],premium_checks=256,individual_checks=512,mismatches=mismatches,edges=edges));write_record(out,r);assert not mismatches
r.update(complete=True,seconds=time.perf_counter()-start,premium_checks=2048,individual_checks=4096);write_record(out,r);print('Independent checks',r['premium_checks'],r['individual_checks'],'seconds',r['seconds'])
