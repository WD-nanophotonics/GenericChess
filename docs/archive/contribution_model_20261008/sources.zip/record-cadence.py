"""Bounded measurement of cumulative-record checkpoint overhead, no rerun."""
import sys,json,time,copy,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;raw=(p/'premium-boundary-expanded.json').read_bytes();src=json.loads(raw);out=p/'record-cadence.json';assert not out.exists()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Serialization/I/O development microbenchmark, NOT a scientific rerun or cost estimate. Use the first64 observed contexts of each8pair as a representative growing JSON payload. Existing atomic write_record, same final bytes, per-root versus per16-root checkpoints, both two repeats alternating order. Count exact encoded UTF8 bytes written, calls and encode+write wall time. Initial/final checkpoints retained, no new format/helper. Output payloads are ignored benchmark files, not new science records. Decision: bounded batch persistence for future bulk producers rather than global durability changes.',runs=[]);write_record(out,r)
for repeat in (0,1):
 for stride in ((1,16) if repeat==0 else (16,1)):
  target=p/('cadence-payload-'+str(stride)+'.json');payload=copy.deepcopy(src);payload['rows']=[];payload['complete']=False;payload['scope']='Observed subset used solely as growing serialization benchmark payload';writes=0;bytes_written=0;t=time.perf_counter()
  def save():
   global writes,bytes_written
   body=(json.dumps(record_value(payload),indent=2,allow_nan=False)+'\n').encode('utf-8');write_record(target,payload);assert target.stat().st_size==len(body);writes+=1;bytes_written+=len(body)
  save()
  for old in src['rows']:
   row={k:v for k,v in old.items() if k not in ('roots','strata','seconds')};row['roots']=[];payload['rows'].append(row)
   for i,root in enumerate(old['roots'][:64],1):
    row['roots'].append(root)
    if i%stride==0:save()
  payload['complete']=True;save();r['runs'].append(dict(repeat=repeat,stride=stride,writes=writes,bytes_written=bytes_written,seconds=time.perf_counter()-t,final_bytes=target.stat().st_size,final_sha256=hashlib.sha256(target.read_bytes()).hexdigest()));write_record(out,r)
assert len({x['final_sha256'] for x in r['runs']})==1;r['complete']=True;write_record(out,r);print(r['runs'])
