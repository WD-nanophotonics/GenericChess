"""Independent Native occupancy/control replay of all whole-state trajectories."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=ROOT/'.local_agent/custody-kernel-20261008';raw=(p/'whole-state.json').read_bytes();src=json.loads(raw);definitions=json.loads((old/'kernel-completed.json').read_bytes());frontiers=json.loads((old/'pretransfer-coupling.json').read_bytes());frontier=next(x for x in frontiers['frontiers'] if x['seed']==src['frontier_seed']);out=p/'whole-native-oracle-completed.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='All64 observed whole-state paths replay through guarded Native actions from exact full-history roots. Compare Native unit control snapshots at8/16/32/64 and full final board/hands/side/terminal with recorded Core state. Different kernels; no Core continuation reused. Qualifies these trajectories, not MC population accuracy or material prices.',rows=[],native_transitions=0);write_record(out,r)
for j,case in enumerate(definitions['cases']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));n=compile_native_semantic_rules(c);types={t:i for i,t in enumerate(n.type_ids)};anchors={types[x.type_id] for x in c.piece_types if x.is_anchor};s=GameSession(c)
 for v in frontier['paired_actions'][j]:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
 root=pack_semantic_search_position(c,n,s)
 def control(v):return sum((1 if x[2]==0 else -1) for x in v['board'] if x is not None and x[1] not in anchors)+sum((1 if owner==0 else -1)*count for owner,h in enumerate(v['hands']) for t,count in enumerate(h) if t not in anchors)
 initial=control(snapshot(n,root))
 for trajectory in src['trajectories']:
  assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused');oldpath=trajectory['cases'][j];pos=root;observed={}
  for ply,v in enumerate(oldpath['actions'],1):
   a=next(a for a in guarded_actions(n,pos) if record_value(public_action(n,a))==v);pos=make_checked(n,pos,a);r['native_transitions']+=1
   if ply in (8,16,32,64):observed[str(ply)]=control(snapshot(n,pos))-initial
  final=snapshot(n,pos)
  for h in (8,16,32,64):observed.setdefault(str(h),control(final)-initial)
  assert observed==oldpath['control_delta'];expected=oldpath['final_state']['position'];board=[None if x is None else [types[x['base_type_id']],types[x['current_type_id']],x['owner'],int(x['promoted'])] for x in expected['board']];hands=[[dict(h['counts']).get(t,0) for t in n.type_ids] for h in expected['hands']]
  assert record_value(final['board'])==board and final['hands']==hands and final['side']==expected['side_to_move'];native_terminal=terminal_status(n,pos);assert native_terminal['status']==oldpath['terminal']['status'] and native_terminal['winner']==oldpath['terminal']['winner'];assert final['history_exact'] and final['history_events_exact']
  r['rows'].append(dict(seed=trajectory['seed'],base=case['base'],plies=oldpath['plies'],control_delta=observed,final_position_equal=True,terminal_equal=True));write_record(out,r)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print('paths',len(r['rows']),'native transitions',r['native_transitions'],'seconds',r['seconds'])
