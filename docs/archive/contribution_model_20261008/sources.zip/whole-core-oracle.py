"""Independent Core legal transitions, reverse-order control minimax."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=ROOT/'.local_agent/custody-kernel-20261008';raw=(p/'whole-minimax.json').read_bytes();src=json.loads(raw);defs=json.loads((old/'kernel-completed.json').read_bytes());prior=json.loads((old/'pretransfer-coupling.json').read_bytes());f=next(x for x in prior['frontiers'] if x['seed']==src['frontier_seed']);out=p/'whole-core-oracle.json';assert not out.exists();r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Independent Core legal transitions, immutable full-history states and reverse lexical action order. Same ordinary-control terminal/leaf payoff, no Native/TT or product WDL utility. First frontier,2/3/4ply references with20000nodes/15sec per case/depth cost checkpoint. Incomplete means unknown, not validation failure/pass. Resources differ from Native and are reported; no speed ratio on incomplete cells.',rows=[]);write_record(out,r)
class Fuse(RuntimeError):pass
for j,case in enumerate(defs['cases']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));anchors={x.type_id for x in c.piece_types if x.is_anchor};s=GameSession(c)
 for v in f['paired_actions'][j]:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
 def utility(state):return sum((1 if x.owner==0 else -1) for x in state.position.board if x is not None and x.current_type_id not in anchors)+sum((1 if owner==0 else -1)*count for owner,h in enumerate(state.position.hands) for base,count in h.counts if base not in anchors)
 row=dict(base=case['base'],cells=[]);r['rows'].append(row)
 for depth in (2,3,4):
  assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused');cell=dict(depth=depth,nodes=0,transitions=0,complete=False);t=time.perf_counter()
  def solve(state,left,alpha,beta):
   cell['nodes']+=1
   if cell['nodes']>20000 or time.perf_counter()-t>15:raise Fuse()
   if left==0 or state.terminal_status.is_terminal:return utility(state)
   aa=sorted(legal_actions(state,c),key=str,reverse=True);assert aa;maximize=state.position.side_to_move==0;best=-100 if maximize else 100
   for a in aa:
    child=apply_action(state,a,c);cell['transitions']+=1;value=solve(child,left-1,alpha,beta)
    best=max(best,value) if maximize else min(best,value)
    if maximize:alpha=max(alpha,best)
    else:beta=min(beta,best)
    if alpha>=beta:break
   return best
  try:
   score=solve(s.state,depth,-100,100);expected=next(x for rr in src['rows'] if rr['base']==case['base'] for x in rr['cells'] if x['depth']==depth);assert score==expected['control'];cell.update(complete=True,control=score,delta=score-utility(s.state),native_equal=True)
  except Fuse:cell.update(control=None,delta=None,native_equal=None)
  cell['seconds']=time.perf_counter()-t;row['cells'].append(cell);write_record(out,r);print(case['base'],depth,cell['complete'],cell['delta'],cell['nodes'],cell['seconds'],flush=True)
r['complete']=True;write_record(out,r)
