"""Finite full-history control minimax, not the product's WDL terminal score."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from generic_chess.core.actions import SemanticBoardMove
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=ROOT/'.local_agent/custody-kernel-20261008';raw=(old/'pretransfer-coupling.json').read_bytes();src=json.loads(raw);definitions_raw=(old/'kernel-completed.json').read_bytes();definitions=json.loads(definitions_raw);f=sorted(src['frontiers'],key=lambda x:x['seed'])[0];out=p/'whole-minimax.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),definition_sha256=hashlib.sha256(definitions_raw).hexdigest(),declaration='First paired first-transfer frontier by seed, same as uniform control pilot. Full Native legality/history, owner0 max/owner1 min ordinary board-plus-hand control at2/3/4plies. Actual terminal stops with existing control utility, NO WDL/mate bonus. Simple diagnostic alpha-beta, no TT, qsearch or unknown prices. Ordinary captures ordered before other lexical public actions. Equal20000visited-node/60sec cost checkpoint per case/depth, incomplete unknown. Earlier exact2ply policy-control is independent expected reference. Outcome distinguishes finite adversarial contribution from uniform action dilution; no result-driven extension or positive stock-price inference.',frontier_seed=f['seed'],rows=[]);write_record(out,r)
class Fuse(RuntimeError):pass
for j,case in enumerate(definitions['cases']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));n=compile_native_semantic_rules(c);anchors={i for i,t in enumerate(n.type_ids) if c.types_by_id[t].is_anchor};s=GameSession(c)
 for v in f['paired_actions'][j]:s.submit(next(a for a in s.legal_actions() if record_value(a)==v))
 pos=pack_semantic_search_position(c,n,s)
 def utility(v):return sum((1 if x[2]==0 else -1) for x in v['board'] if x is not None and x[1] not in anchors)+sum((1 if owner==0 else -1)*count for owner,h in enumerate(v['hands']) for t,count in enumerate(h) if t not in anchors)
 initial=utility(snapshot(n,pos));row=dict(base=case['base'],initial_control=initial,cells=[]);r['rows'].append(row)
 for depth in (2,3,4):
  assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused');cell=dict(depth=depth,complete=False,nodes=0,transitions=0,terminal_nodes=0,cutoffs=0);t=time.perf_counter();write_record(out,r)
  def solve(position,left,alpha,beta):
   cell['nodes']+=1
   if cell['nodes']>20000 or time.perf_counter()-t>60:raise Fuse('cost checkpoint')
   v=snapshot(n,position);u=utility(v);terminal=terminal_status(n,position)['status']!='ongoing'
   if terminal:cell['terminal_nodes']+=1
   if left==0 or terminal:return u,[]
   aa=list(guarded_actions(n,position));assert aa
   def ordering(a):
    public=public_action(n,a);victim=v['board'][public.to_square.file+9*public.to_square.rank] if isinstance(public,SemanticBoardMove) else None
    return (not(victim is not None and victim[1] not in anchors),str(public))
   aa.sort(key=ordering);maximize=v['side']==0;best=-100 if maximize else 100;line=[]
   for a in aa:
    child=make_checked(n,position,a);cell['transitions']+=1;score,tail=solve(child,left-1,alpha,beta)
    if (maximize and score>best) or (not maximize and score<best):best=score;line=[record_value(public_action(n,a))]+tail
    if maximize:alpha=max(alpha,best)
    else:beta=min(beta,best)
    if alpha>=beta:cell['cutoffs']+=1;break
   return best,line
  try:
   score,line=solve(pos,depth,-100,100);cell.update(complete=True,control=score,delta=score-initial,principal_line=line)
  except Fuse:cell.update(control=None,delta=None,principal_line=None)
  cell['seconds']=time.perf_counter()-t;row['cells'].append(cell);write_record(out,r);print(case['base'],depth,cell['complete'],cell['delta'],cell['nodes'],cell['seconds'],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
