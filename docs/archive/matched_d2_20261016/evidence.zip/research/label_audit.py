from pathlib import Path
import json,collections,hashlib,datetime
P=Path(".local_agent/matched-d2-20261016");groups=collections.defaultdict(list);gamecounts={};frozen=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),question="Can exactfullstate actual finite returns be treated as optimalWDL labels across theclosedcommonfuture policies?",stage="analysis specification afterd3labels/beforeallD6labels; descriptive notconfirmatory",condition="compareactualfullbeforestateSHA validatedbysearchdisabledconsumer; normalizeperspective toside-to-move; keepUnknown,physicalgames notdependentcellaliases")
(P/"label-audit-plan.json").write_bytes((json.dumps(frozen,indent=2)+"\n").encode())
def run():
 for panel,file in[("d3q0",P/"results.json"),("d3q1",P/"future-q1/results.json"),("d6both",P/"future-depth6/results.json")]:
  d=json.loads(file.read_bytes());assert d["complete"]
  for g in d["rows"]:
   if g["kind"]!="ACTUAL_GAME":continue
   name=("d6q"+str(g["future_q"]))if panel=="d6both"else panel;gamecounts[name]=gamecounts.get(name,0)+1
   for row in g["rows"]:
    outcome=g["outcome"]
    if row["side"]!=g["actor"]:outcome={"WIN":"LOSS","LOSS":"WIN"}.get(outcome,outcome)
    groups[row["before_sha256"]].append(dict(panel=name,game=g["game_id"],seed=g["seed"],step=row["step"],side=row["side"],side_return=outcome,physicaloutcome=g["outcome"],chosen=row.get("action"),execution_allowed=row["execution_allowed"]))
 rows=[]
 for sha,rs in groups.items():
  panels={x["panel"]for x in rs}
  if len(panels)<2:continue
  outcomes={x["side_return"]for x in rs};rows.append(dict(before_sha256=sha,panels=sorted(panels),opposite_actual_terminals={"WIN","LOSS"}.issubset(outcomes),known_and_unknown=("UNKNOWN"in outcomes and len(outcomes)>1),observations=rs))
 out=dict(complete=True,physical_games=gamecounts,unique_before_hashes=len(groups),crosspolicy_shared_states=len(rows),opposite_terminal_states=sum(x["opposite_actual_terminals"]for x in rows),known_and_unknown_states=sum(x["known_and_unknown"]for x in rows),families_with_opposites=sorted({r["seed"]for x in rows if x["opposite_actual_terminals"]for r in x["observations"]}),rows=rows,scope="Exactfullstatehash includinghistoryfromactualvalidatedreceipts; stateobservationsdependent andnotteachertruth. Differentcommonfuture physicalreturns cannotbe relabeledexactoptimalWDL. A declaredpolicy-mixture approximate expectation is stilllegitimate; nofit/calibrationaccuracy/independentholdout orall-defenseproof.")
 (P/"label-audit.json").write_bytes((json.dumps(out,indent=2)+"\n").encode());print({k:v for k,v in out.items()if k!="rows"})
if __name__=="__main__":run()
