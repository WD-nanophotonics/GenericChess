from pathlib import Path
import json,datetime
P=Path(".local_agent/matched-d2-20261016");Q=P/"cross-future";Q.mkdir()
base=json.loads((P/"plan.json").read_bytes());lo=json.loads((P/"results.json").read_bytes())["rows"];hi=json.loads((P/"future-q1/results.json").read_bytes())["rows"]
def find(gs,seed,cell):return next(x for x in gs if x["seed"]==seed and cell in x["cells"])
eligible=[]
for c in sorted(base["cases"],key=lambda x:x["seed"]):
 if c["forced_actions"]["C"]==c["forced_actions"]["D"]:continue
 if any({find(lo,c["seed"],cell)["outcome"],find(hi,c["seed"],cell)["outcome"]}=={"WIN","LOSS"}for cell in"CD"):eligible.append(c)
assert eligible
c=eligible[0];cases=[]
for aq,oq in[(1,0),(0,1)]:
 z=dict(c,actor_q=aq,opponent_q=oq);z["forced_actions"]={k:v for k,v in c["forced_actions"].items()if k in"CD"};cases.append(z)
plan=dict(base);plan.update(status="FROZEN_BEFORE_CROSS_FUTURE_LABELS",frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=cases,question="Does onlyactorq oronlyopponentq change C/D commonfuture consequences in the firstID actualterminalflipcase?",selection="Afterdiaglabels/completeDotreply; firstseedwithdifferentC/Dactions andatleastonecellactualWINLOSSflipacrossD3commonq0/q1; noextraafterUNKNOWN.",selected_seed=c["seed"],eligible_seeds=[x["seed"]for x in eligible],unique_games=4,planned_cells=4,expected_seconds=10,whole_seconds=360,scope="EXPOSEDonecase unilateralqcontrol, originalactoridentityfixedthroughallmoves; existingD3diagonals reusednotrerun. NoD6splicing, noWDL/default/populationclaim.")
(Q/"plan.json").write_bytes((json.dumps(plan,indent=2)+"\n").encode())
s=(P/"run.py").read_text().replace('P=R/".local_agent/matched-d2-20261016"','P=R/".local_agent/matched-d2-20261016/cross-future"').replace('labels=list("ABCD")if ci%2==0 else list("DCBA")','labels=list("CD")if ci%2==0 else list("DC")').replace('game_id=str(case["seed"])+"-"+str(gi)','game_id=str(case["seed"])+"-a"+str(case["actor_q"])+"o"+str(case["opponent_q"])+"-"+str(gi)').replace('a.load(P/case["root"])','a.load(P.parent/case["root"])').replace('quiescence_max_depth=0','quiescence_max_depth=case["actor_q"]if side==actor else case["opponent_q"],quiescence_hard_max_depth=8').replace('board=case["board"],cells=cells','board=case["board"],actor_q=case["actor_q"],opponent_q=case["opponent_q"],cells=cells')
(Q/"run.py").write_bytes(s.encode())
s=(P/"consumer.py").read_text().replace('s,nr=root(read(case["root"]))','s,nr=root(json.loads((B.parent/case["root"]).read_bytes()))')
(Q/"consumer.py").write_bytes(s.encode())
print("FROZEN_CROSS",c["seed"],plan["eligible_seeds"],flush=True)
