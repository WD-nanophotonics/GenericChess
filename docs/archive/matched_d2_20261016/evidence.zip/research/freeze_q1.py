from pathlib import Path
import json,datetime,shutil
P=Path(".local_agent/matched-d2-20261016");Q=P/"future-q1";Q.mkdir()
plan=json.loads((P/"plan.json").read_bytes());plan.update(status="FROZEN_BEFORE_Q1_FUTURE_LABELS_AFTER_Q0",frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),question="Do firstaction q/valuation consequences persist when commonfuture usesq1insteadq0?",expected_seconds=900,whole_seconds=1800,scope="EXPOSED same22firstactions/8families, newq1futureonly; no newindependentfamilies, no frozenq0capextension orstrength. Onlyqfuturechanges; allnodes/time/physicalhistory retained.")
plan["future"]["q"]=1
(Q/"plan.json").write_bytes((json.dumps(plan,indent=2)+"\n").encode())
shutil.copytree(P/"roots",Q/"roots")
s=(P/"run.py").read_text().replace('P=R/".local_agent/matched-d2-20261016"','P=R/".local_agent/matched-d2-20261016/future-q1"').replace('quiescence_max_depth=0','quiescence_max_depth=1,quiescence_hard_max_depth=8')
(Q/"run.py").write_bytes(s.encode())
(Q/"consumer.py").write_bytes((P/"consumer.py").read_bytes())
s=(P/"summarize.py").read_text().replace('P=Path(".local_agent/matched-d2-20261016")','P=Path(".local_agent/matched-d2-20261016/future-q1")').replace("commonfuture isboundedq0","commonfuture isboundedq1")
(Q/"summarize.py").write_bytes(s.encode())
print("FROZEN22_Q1_FUTURE",plan["frozen_utc"])
