from pathlib import Path
import sys,json,time,datetime
R=Path.cwd();P=R/".local_agent/matched-d2-20261016";O=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(O)]
import assessment as a
import core_control as cc
p=a.p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
def freeze():
 write_record(P/"causal-core-plan.json",dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),question="Does independentlyexecutedpureCore confirm the completedq0/q1finiteobjective at actualPvsXdrop divergence, or reveal a Native-specific issue?",root="first-action-cause/roots/34101.json",qs=[0,1],depth=3,nodes=262144,seconds=45,whole_seconds=180,expected_seconds=60,claim="Optionaldiagnostic thatcanchangeinterpretation, notmandatoryWDL/teacher/approvalgate; allcensorsretained/nocapextension. NativeTT0/CoreTTfalse/orderfalse/nativelegalityfalse/root-tacticalfalse, samequantizedstaticprofiles/fullhistory.",slots=4))
def run():
 plan=json.loads((P/"causal-core-plan.json").read_bytes());d,c,s,nr=a.load(P/plan["root"]);start=time.perf_counter();rows=[];before=p.digest(s)
 for q in plan["qs"]:
  p.stopped();t=time.perf_counter();r=AlphaBetaPlayer(c,evaluator_override=cc.Material(d["board_values"],d["hand_values"]),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,p.SearchLimits(max_depth=3,max_nodes=262144,max_time_seconds=45,quiescence_max_depth=q,quiescence_hard_max_depth=8));ct=time.perf_counter()-t;assert p.digest(s)==before
  t=time.perf_counter();n=p.SemanticSearchEngine(c,nr,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=0,ordering_cache_enabled=False).search(s,p.SearchLimits(max_depth=3,max_nodes=262144,max_time_seconds=45,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);nt=time.perf_counter()-t
  joint=r.completed_depth==n.completed_depth==3;norm=n.score if abs(n.score)<50000000 else(1 if n.score>0 else-1)*(1000000000-(100000000-abs(n.score)))
  row=dict(root=plan["root"],q=q,core=record_value(r),native=record_value(n),core_seconds=ct,native_seconds=nt,joint_complete=joint,normalized_score_equal=r.score==norm if joint else None,root_restored=p.digest(s)==before,pv_edges=p.audit(s,nr,n));rows.append(row)
  with(P/"causal-core-rows.jsonl").open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush()
  print("CAUSAL_CORE",q,joint,r.completed_depth,n.completed_depth,r.score,n.score,ct,flush=True)
 write_record(P/"causal-core-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start,scope=plan["claim"]))
if __name__=="__main__":
 if sys.argv[-1]=="freeze":freeze()
 else:run()
