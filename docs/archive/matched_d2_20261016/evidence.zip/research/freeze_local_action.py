from pathlib import Path
import sys,json,datetime
R=Path.cwd();P=R/".local_agent/matched-d2-20261016";Q=P/"first-action-cause";Q.mkdir();O=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(O)]
import assessment as a
p=a.p
from scripts.research_record import record_value,write_record
from generic_chess.session.serialization import serialize_game_record
case=next(x for x in json.loads((P/"plan.json").read_bytes())["cases"]if x["seed"]==34101);lo=next(x for x in json.loads((P/"results.json").read_bytes())["rows"]if x["seed"]==34101 and"C"in x["cells"]);hi=next(x for x in json.loads((P/"cross-future/results.json").read_bytes())["rows"]if x["actor_q"]==1 and"C"in x["cells"])
d,c,s,nr=a.load(P/case["root"]);s.submit(next(x for x in s.legal_actions()if record_value(x)==case["forced_actions"]["C"]))
i=0
while lo["rows"][i]["action"]==hi["rows"][i]["action"]:
 assert p.digest(s)==lo["rows"][i]["before_sha256"]==hi["rows"][i]["before_sha256"]
 s.submit(next(x for x in s.legal_actions()if record_value(x)==lo["rows"][i]["action"]));i+=1
assert i==1 and p.digest(s)==lo["rows"][i]["before_sha256"]==hi["rows"][i]["before_sha256"]
assert s.state.position.side_to_move==0 and lo["rows"][i]["result"]["completed_depth"]==hi["rows"][i]["result"]["completed_depth"]==3
root=dict(ruleset=d["ruleset"],game_record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state),before_sha256=p.digest(s),board_values=d["board_values"],hand_values=d["hand_values"],provenance="ExactphysicalCforced+sharedprefix reconstructedandboundtobothactualbeforeSHA, nofakehistory")
(Q/"roots").mkdir();write_record(Q/"roots/34101.json",root)
base=json.loads((P/"plan.json").read_bytes());cases=[]
for aq in[0,1]:
 cases.append(dict(seed=34101,board=4,root="roots/34101.json",state_sha256=p.digest(s),actor_q=aq,opponent_q=0,forced_actions={"C":lo["rows"][i]["action"],"D":hi["rows"][i]["action"]}))
base.update(status="FROZEN_BEFORE_LOCAL_ACTION_COUNTERFACTUAL_LABELS",frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=cases,question="At actualCfirstdivergence, does PdropvsXdrop itself alter commonfuture outcomes?",max_future_plies=62,unique_games=4,planned_cells=4,whole_seconds=360,expected_seconds=5,scope="EXPOSED onefullstate4newgames, C/DlabelsONLYlocalq0Pdrop/q1Xdrop, notoldglobalcells; coldfutureenginesatthisstate, TTlifecycleuniform. Not splicedwitholdwarmdiagonals, notoptimalWDL oruniqueerrorblame.")
write_record(Q/"plan.json",base)
src=(P/"cross-future/run.py").read_text().replace('P=R/".local_agent/matched-d2-20261016/cross-future"','P=R/".local_agent/matched-d2-20261016/first-action-cause"').replace('a.load(P.parent/case["root"])','a.load(P/case["root"])')
(Q/"run.py").write_bytes(src.encode())
src=(P/"consumer.py").read_text();(Q/"consumer.py").write_bytes(src.encode());print("FROZEN_LOCAL_ACTION",p.digest(s),i,flush=True)
