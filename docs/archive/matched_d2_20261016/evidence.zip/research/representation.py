from pathlib import Path
import sys,json,time,copy,hashlib,datetime
R=Path.cwd();P=R/".local_agent/matched-d2-20261016";O=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(O)]
import assessment as a
p=a.p
from generic_chess.rules.serialization import deserialize_ruleset
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import record_value,write_record
from generic_chess.native.adapter import pack_semantic_search_position
def freeze():
 write_record(P/"representation-plan.json",dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),question="Does equaltypeaxis/shape sparsePosition input encode changed movement/terminal rules, and does the perRuleSet guard prevent accidentalcrossuse?",source_root="roots/34101.json",variants=["original","X_movement_single_forward_leap","maxply511"],position="Actual GameSession initialposition perexplicitrulevariant, nofakehistoricalprefix; preserveoriginalsetup/types/promotion/drop. Zerodynamicablation explicit.",expected_seconds=10,whole_seconds=60,scope="No training/architecturechange/AUXwork. Samefeaturevector is representationalias acrossdifferentboundmodels, not deployedbug orproof differentoptimalvalue. Confirmmechanic/equalshape isnotmeaning." ))
def run():
 plan=json.loads((P/"representation-plan.json").read_bytes());original=json.loads((P/plan["source_root"]).read_bytes())["ruleset"];start=time.perf_counter();rows=[];encoders=[];sessions=[]
 for v in plan["variants"]:
  p.stopped();rs=copy.deepcopy(original)
  if v=="X_movement_single_forward_leap":next(x for x in rs["piece_types"]if x["type_id"]=="X")["movement_atoms"]=[dict(kind="leap",offset=[0,1])]
  if v=="maxply511":rs["max_ply"]=511
  raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(rs)));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=p.GameSession(c);nr=p.nc.compile_native_semantic_rules(c);enc=SparsePositionEncoder(c);indices,values=enc.encode(s.state.position,(0,0,0));vector=enc.dense(s.state.position,(0,0,0));np=pack_semantic_search_position(c,nr,s);nt=p.sem.terminal_status(nr,np)
  assert nt==dict(status=s.state.terminal_status.status.value,winner=s.state.terminal_status.winner)
  legal=[record_value(x)for x in s.legal_actions()]
  def physical(x):return json.dumps({k:v for k,v in x.items()if k not in["pattern_id","geometry_id"]},sort_keys=True)
  row=dict(variant=v,ruleset=rs,state=record_value(s.state),fingerprint=c.ruleset_fingerprint,dimension=enc.dimension,indices=indices.tolist(),values=values.tolist(),vector_sha256=hashlib.sha256(vector.tobytes()).hexdigest(),dynamic=[0,0,0],legal_actions=legal,physical_actions=sorted(physical(x)for x in legal),terminal=record_value(s.state.terminal_status),native_terminal=nt,fullstate_sha256=p.digest(s))
  rows.append(row);encoders.append(enc);sessions.append(s)
 for i in[1,2]:
  try:encoders[0].encode(sessions[i].state.position,(0,0,0));rejected=False
  except ValueError as ex:rejected=True;rows[i]["cross_guard_error"]=str(ex)
  rows[i].update(vector_equal_original=rows[i]["vector_sha256"]==rows[0]["vector_sha256"],physical_actions_equal_original=rows[i]["physical_actions"]==rows[0]["physical_actions"],original_encoder_rejects_cross_rule=rejected)
 write_record(P/"representation-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start,queries=0,games=0,scope=plan["scope"]));print("REPRESENTATION",[(r["variant"],r["dimension"],len(r["legal_actions"]),r.get("vector_equal_original"),r.get("physical_actions_equal_original"),r.get("original_encoder_rejects_cross_rule"))for r in rows],flush=True)
if __name__=="__main__":
 if sys.argv[-1]=="freeze":freeze()
 else:run()
