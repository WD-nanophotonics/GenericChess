from pathlib import Path
import json,time,collections,random
P=Path(".local_agent/matched-d2-20261016");plan=json.loads((P/"plan.json").read_bytes());data=json.loads((P/"results.json").read_bytes());assert data["complete"]
values={"WIN":1,"LOSS":-1,"DRAW":0,"UNKNOWN":0}
family=[];trans={k:collections.Counter()for k in["B-A","D-C","C-A","D-B"]}
for case in plan["cases"]:
 games=[x for x in data["rows"]if x["seed"]==case["seed"]];out={}
 for g in games:
  for c in g["cells"]:assert c not in out;out[c]=g["outcome"]
 assert set(out)==set("ABCD")
 v={k:values[x]for k,x in out.items()};row=dict(seed=case["seed"],outcomes=out,games=len(games),**{k:v[l]-v[r]for k,l,r in[("B-A","B","A"),("D-C","D","C"),("C-A","C","A"),("D-B","D","B")]});row["interaction"]=row["D-C"]-row["B-A"];family.append(row)
 for k in trans:trans[k][out[k[2]]+"->"+out[k[0]]]+=1
rng=random.Random(36719);summary={}
for k in["B-A","D-C","C-A","D-B","interaction"]:
 vs=[x[k]for x in family];bs=sorted(sum(rng.choice(vs)for _ in vs)/len(vs)for _ in range(10000));summary[k]=dict(mean=sum(vs)/len(vs),net=sum(vs),family_bootstrap95=[bs[249],bs[9749]],family_values=vs)
x=dict(complete=True,physical_games=len(data["rows"]),planned_cells=32,families=family,summary=summary,transitions={k:dict(v)for k,v in trans.items()},outcomes_by_cell={k:dict(collections.Counter(next(x["outcome"]for x in data["rows"]if x["seed"]==c["seed"]and k in x["cells"])for c in plan["cases"]))for k in"ABCD"},cost_seconds=data["seconds"],physical_edges=sum(1+sum("action"in r for r in g.get("rows",[]))for g in data["rows"]if g["kind"]=="ACTUAL_GAME"),queries=sum(len(g.get("rows",[]))for g in data["rows"]),bootstrap=dict(iterations=10000,seed=36719,unit="8exposedfamilies",chosen_after_labels=True),scope="UNKNOWN contributes0 only to descriptive finiteW-L statistic, notdraw/WDL. 32dependentcelllabels from22uniquephysicalgames. EqualcompletedD2 pertainsONLYfirstactionquery; commonfuture isboundedq0, retainedD/censors vary. No population/equivalence/globalstrength or defaultclaim.")
(P/"summary.json").write_bytes((json.dumps(x,indent=2)+"\n").encode());print(json.dumps(x,indent=2))
