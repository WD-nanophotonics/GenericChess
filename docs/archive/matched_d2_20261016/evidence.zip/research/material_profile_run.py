from pathlib import Path
import sys,json,time,importlib.util,os,collections,statistics
R=Path.cwd();P=R/".local_agent/matched-d2-20261016";O=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(O)]
import assessment as a
p=a.p
from scripts.research_record import record_value,write_record
spec=importlib.util.spec_from_file_location("material_attribution._native_core",P/"material_profile_native_core.pyd");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fn=m.semantic_engine_search;observed={}
def capture(*args,**kw):
 out=fn(*args,**kw);observed.clear();observed.update(record_value(out));return out
m.semantic_engine_search=capture
plan=json.loads((P/"material-profile-plan.json").read_bytes());rows=[];start=time.perf_counter();journal=P/"material-profile-rows.jsonl";journal.open("x").close()
for cse in plan["cases"]:
 d,c,s,nr=a.load(P/cse["root"]);pnr=p.nc.compile_native_semantic_rules(c,backend_module=m);before=p.digest(s)
 for q in plan["qs"]:
  for rep in range(2):
   for arm in(["normal","profile"]if rep==0 else["profile","normal"]):
    p.stopped()
    if time.perf_counter()-start>=plan["whole_seconds"]:raise TimeoutError("Frozen600sprofilingcap")
    n=nr if arm=="normal"else pnr;e=p.SemanticSearchEngine(c,n,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=16,ordering_cache_enabled=False);t=time.perf_counter();res=e.search(s,p.SearchLimits(max_depth=3,max_nodes=65536,max_time_seconds=None,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);seconds=time.perf_counter()-t
    row=dict(seed=cse["seed"],board=cse["board"],root=cse["root"],q=q,rep=rep,arm=arm,result=record_value(res),caller_seconds=seconds,pv_edges=p.audit(s,n,res),before_sha256=before,root_restored=p.digest(s)==before);assert row["root_restored"]
    if arm=="profile":row["metrics"]={k:v for k,v in observed.items()if k.startswith("private_material_")}
    rows.append(row)
    with journal.open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush();os.fsync(f.fileno())
   r0,r1=[x["result"]for x in rows[-2:]];assert{k:v for k,v in r0.items()if k!="elapsed_seconds"}=={k:v for k,v in r1.items()if k!="elapsed_seconds"},(cse["seed"],q,rep)
 print("MATERIAL_PROFILE",cse["seed"],len(rows),flush=True)
write_record(P/"material-profile-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start,source="PrivateinstrumentednormalC392, no productactivation"))
summary=[]
for board in[4,8,12,16]:
 for q in[0,1]:
  rr=[x for x in rows if x["board"]==board and x["q"]==q and x["arm"]=="profile"];normal=[x for x in rows if x["board"]==board and x["q"]==q and x["arm"]=="normal"];elapsed=sum(x["result"]["elapsed_seconds"]for x in rr);mat=sum(x["metrics"]["private_material_ns"]for x in rr)/1e9
  summary.append(dict(board=board,q=q,profile_calls=len(rr),material_calls=sum(x["metrics"]["private_material_calls"]for x in rr),material_seconds=mat,profile_kernel_seconds=elapsed,material_fraction_instrumented=mat/elapsed if elapsed else None,profile_normal_caller_ratio=sum(x["caller_seconds"]for x in rr)/sum(x["caller_seconds"]for x in normal)))
write_record(P/"material-profile-summary.json",dict(complete=True,actual_queries=len(rows),normal_profile_non_time_pairs_equal=32,rows=summary,scope="Timersincludeoverhead, kernelpartitionnotexhaustive. Fixednodeexperiment, nottimedstrength/all-domain/NNcost. Bothordersbalance butsharedhostload limit remains. Sourceprivateonly."))
print("MATERIAL_PROFILE_CLOSED",len(rows),time.perf_counter()-start,summary,flush=True)
