from pathlib import Path
import json,collections,random
P=Path(".local_agent/matched-d2-20261016");val={"WIN":1,"LOSS":-1,"DRAW":0,"UNKNOWN":0};panels={}
for name,file in[("d3q0",P/"results.json"),("d3q1",P/"future-q1/results.json"),("d6both",P/"future-depth6/results.json")]:
 d=json.loads(file.read_bytes());assert d["complete"]
 if name=="d6both":
  for q in[0,1]:panels["d6q"+str(q)]=[x for x in d["rows"]if x.get("future_q",int(x["game_id"].split("-q")[1].split("-")[0]))==q]
 else:panels[name]=d["rows"]
cases=json.loads((P/"plan.json").read_bytes())["cases"];allout={};stats={};rng=random.Random(36720)
for panel,gs in panels.items():
 allout[panel]={};families=[]
 for case in cases:
  oo={}
  for g in gs:
   if g["seed"]==case["seed"]:
    for c in g["cells"]:assert c not in oo;oo[c]=g["outcome"]
  assert set(oo)==set("ABCD")
  allout[panel][case["seed"]]=oo;v={c:val[o]for c,o in oo.items()}
  families.append(dict(seed=case["seed"],outcomes=oo,unit_q=v["B"]-v["A"],static_q=v["D"]-v["C"],price_q0=v["C"]-v["A"],price_q1=v["D"]-v["B"],interaction=v["D"]-v["C"]-v["B"]+v["A"]))
 summaries={}
 for k in["unit_q","static_q","price_q0","price_q1","interaction"]:
  vs=[r[k]for r in families];bs=sorted(sum(rng.choice(vs)for _ in vs)/8 for _ in range(10000));summaries[k]=dict(net=sum(vs),mean=sum(vs)/8,family_ci=[bs[249],bs[9749]],family_values=vs)
 stats[panel]=dict(physical_games=len(gs),outcomes={c:dict(collections.Counter(allout[panel][x["seed"]][c]for x in cases))for c in"ABCD"},families=families,summaries=summaries,retained_depths=dict(collections.Counter(str(r["result"]["completed_depth"])for g in gs for r in g.get("rows",[]))),queries=sum(len(g.get("rows",[]))for g in gs),edges=sum(1+sum("action"in r for r in g.get("rows",[]))for g in gs if g["kind"]=="ACTUAL_GAME"),causes=dict(collections.Counter(g["ending_cause"]for g in gs)),cost_seconds=sum(g.get("seconds",0)for g in gs))
contrasts={}
for low,high in[("d3q0","d3q1"),("d3q0","d6q0"),("d3q1","d6q1"),("d6q0","d6q1")]:
 bycell={}
 for c in"ABCD":
  bycell[c]=dict(collections.Counter(allout[low][x["seed"]][c]+"->"+allout[high][x["seed"]][c]for x in cases))
 contrasts[low+"to"+high]=dict(bycell=bycell,scope="Dependent actualsharedfirstactions, differentcommonfuture; notsamefullpolicy orindependentvalidation.")
x=dict(complete=True,panels=stats,contrasts=contrasts,actual_games=sum(len(x)for x in panels.values()),physical_queries=sum(x["queries"]for x in stats.values()),physical_edges=sum(x["edges"]for x in stats.values()),families=8,dependent_cell_labels=128,distinct_parents=8,unique_first_actions=22,analysis="Exploratoryafterlabels bootstrap10K seed36720. UNKNOWN0 only finiteW-L, notDRAW/proof. RequestedD6 notassumedcompleted. Allactualcaps/failures retained; no poolingfamilies ordefault.")
(P/"combined-summary.json").write_bytes((json.dumps(x,indent=2)+"\n").encode())
print(json.dumps(dict(complete=True,actual_games=x["actual_games"],panels={k:dict(outcomes=v["outcomes"],deltas={a:b["net"]for a,b in v["summaries"].items()},causes=v["causes"],depths=v["retained_depths"],cost=v["cost_seconds"])for k,v in stats.items()}),indent=2))
