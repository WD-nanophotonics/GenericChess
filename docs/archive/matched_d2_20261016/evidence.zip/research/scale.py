from pathlib import Path
import sys,json,time,os,datetime
R=Path.cwd();P=R/".local_agent/matched-d2-20261016";O=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(O)]
import assessment as a
p=a.p
from scripts.research_record import record_value,write_record
def freeze():
 plan=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),question="Does common positive4x value scaling change samecompleted finite q0/q1 decisions or only completion/cost, on exposed8parents?",cases=json.loads((P/"plan.json").read_bytes())["cases"],depth=3,nodes=65536,seconds=2,qs=[0,1],prices=["unit","static"],scales=[1,4],slots=64,expected_seconds=60,whole_seconds=240,scope="EXPOSED nofuturelabels/games orAUXratiolearning; algebraic/objective unitcontrol only. Mate scores fixed, noassumedlinearity acrossterminal; nointegeroverflow expected but check. Bothprices scaled, originalUnit100/static~1000levelcontrast still jointshape/unit.")
 write_record(P/"scale-plan.json",plan)
def run():
 plan=json.loads((P/"scale-plan.json").read_bytes());start=time.perf_counter();rows=[]
 for ci,cse in enumerate(plan["cases"]):
  p.stopped();d,c,s,nr=a.load(P/cse["root"]);unit={x.type_id:0 if x.is_anchor else 100 for x in c.piece_types};v={"unit":(unit,unit),"static":(d["board_values"],d["hand_values"])}
  todo=[(price,q,k)for price in plan["prices"]for q in plan["qs"]for k in plan["scales"]]
  if ci%2:todo.reverse()
  for price,q,k in todo:
   p.stopped();row=dict(seed=cse["seed"],root=cse["root"],price=price,q=q,scale=k)
   if time.perf_counter()-start>=plan["whole_seconds"]:rows.append(dict(**row,kind="WHOLE_CAP_NOT_STARTED_UNKNOWN"));continue
   bv,hv=v[price];bv={t:int(n*k)for t,n in bv.items()};hv={t:int(n*k)for t,n in hv.items()};assert max(map(abs,list(bv.values())+list(hv.values())))<1000000
   before=p.digest(s);t=time.perf_counter();res=p.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=16,ordering_cache_enabled=False).search(s,p.SearchLimits(max_depth=3,max_nodes=65536,max_time_seconds=2,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True)
   row.update(kind="ACTUAL_QUERY",board_values=bv,hand_values=hv,result=record_value(res),seconds=time.perf_counter()-t,pv_edges=p.audit(s,nr,res),root_restored=p.digest(s)==before);assert row["root_restored"]
   rows.append(row)
   with(P/"scale-rows.jsonl").open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush();os.fsync(f.fileno())
  print("SCALE_FAMILY",cse["seed"],len(rows),flush=True)
 write_record(P/"scale-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start))
 if len(rows)==64:
  pairs=[]
  for cse in plan["cases"]:
   for price in plan["prices"]:
    for q in plan["qs"]:
     rr=[next(r for r in rows if r["seed"]==cse["seed"]and r["price"]==price and r["q"]==q and r["scale"]==k)for k in[1,4]]
     joint=all(r.get("result",{}).get("completed_depth")==3 for r in rr);v0=rr[0].get("result",{});v1=rr[1].get("result",{})
     pairs.append(dict(seed=cse["seed"],price=price,q=q,joint_complete=joint,action_equal=v0.get("action")==v1.get("action")if joint else None,score4_equal=v0.get("score",0)*4==v1.get("score")if joint and abs(v0["score"])<50000000 and abs(v1["score"])<50000000 else None,depths=[r.get("result",{}).get("completed_depth")for r in rr]))
  write_record(P/"scale-summary.json",dict(complete=True,pairs=pairs,actual_queries=sum(x["kind"]=="ACTUAL_QUERY"for x in rows),joint=sum(x["joint_complete"]for x in pairs),action_changes=sum(x["action_equal"]is False for x in pairs),finite_scaled_score_mismatches=sum(x["score4_equal"]is False for x in pairs),scope=plan["scope"]))
 print("SCALE_CLOSED",time.perf_counter()-start,flush=True)
if __name__=="__main__":
 if sys.argv[-1]=="freeze":freeze()
 else:run()
