from pathlib import Path
import sys,sysconfig,subprocess,shutil,json,time,hashlib,datetime
R=Path.cwd();P=R/".local_agent/matched-d2-20261016";S=P/"material-profile-source";S.mkdir(exist_ok=False)
plan=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),question="Is plainstaticmaterial leaf scanning a large enough kernel cost to justify any incremental-evaluation prototype after q1addsvisits?",cases=json.loads((P/"plan.json").read_bytes())["cases"],qs=[0,1],repetitions=2,arms=["normal","profile"],depth=3,nodes=65536,wall_limit=None,max_queries=64,expected_seconds=90,whole_seconds=600,scope="EXPOSED attribution, fixednodes/no clocksearchstop avoidsinstrumentationchangingcompletedtree. Timerpermaterialcallincludesclockoverhead; upperbiasedcostfraction, notfullpartition. Nooptimization/model/defaultactivation. Buildprivateownedbinary only.")
(P/"material-profile-plan.json").write_bytes((json.dumps(plan,indent=2)+"\n").encode())
for f in(R/"generic_chess/_native").iterdir():
 if f.suffix in[".c",".h"]:shutil.copyfile(f,S/f.name)
f=S/"native_module.c";s=f.read_text(encoding="utf-8-sig");m="    uint32_t tt_iteration_generation;";assert s.count(m)==1;s=s.replace(m,"    uint64_t private_material_ns, private_material_calls;\n"+m)
i=s.index("static int gc_semantic_quiescence(")
helper="""static int private_material(GCSemanticIterativeContext *ctx,const GCSemanticPosition *pos) {
 uint64_t t=gc_monotonic_ns();
 int v=gc_semantic_probe_material(ctx->rules,pos,&ctx->profile,NULL);
 ctx->private_material_ns+=gc_monotonic_ns()-t;
 ctx->private_material_calls++;
 return v;
}
"""
s=s[:i]+helper+s[i:]
for old,new in[("gc_semantic_probe_material(ctx->rules,pos,&ctx->profile,NULL)","private_material(ctx,pos)"),("gc_semantic_probe_material(ctx->rules, position, &ctx->profile, NULL)","private_material(ctx,position)")]:
 # Leave helper original alone.
 idx=s.index("static int gc_semantic_quiescence(");a,b=s[:idx],s[idx:];assert b.count(old)==1;s=a+b.replace(old,new)
m='        gc_semantic_set_u64(out, "ordering_cache_hits", cache_hits) != 0 ||';assert s.count(m)==1;s=s.replace(m,'        gc_semantic_set_u64(out, "private_material_ns", ctx.private_material_ns) != 0 ||\n        gc_semantic_set_u64(out, "private_material_calls", ctx.private_material_calls) != 0 ||\n'+m);f.write_bytes(s.encode())
cmd=[str(R/".venv/Lib/site-packages/ziglang/zig.exe"),"cc","-target","x86_64-windows-gnu","-shared","-O2","-I"+sysconfig.get_path("include"),"-I"+str(S),"-L"+str(Path(sys.base_prefix)/"libs"),"-lpython312",*[str(f)for f in sorted(S.glob("*.c"))],"-o",str(P/"material_profile_native_core.pyd")]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120)
out=dict(returncode=r.returncode,seconds=time.perf_counter()-t,stdout=r.stdout.decode(errors="replace"),stderr=r.stderr.decode(errors="replace"),command=cmd,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()})
(P/"material-profile-build-private.json").write_bytes((json.dumps(out,indent=2)+"\n").encode());print("MATERIAL_PROFILE_BUILD",r.returncode,out["seconds"],out["stderr"][-1500:],flush=True);sys.exit(r.returncode)
