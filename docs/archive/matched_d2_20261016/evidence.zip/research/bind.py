from pathlib import Path
import json,hashlib
P=Path(".local_agent/matched-d2-20261016");O=Path(".local_agent/playability-mu-20261016")
p=json.loads((P/"plan.json").read_bytes());m=json.loads((O/"common-matrix-results.json").read_bytes())
out=[]
for c in p["cases"]:
 r=next(x for x in m["rows"]if x["state_sha256"]==c["state_sha256"])
 assert len(r["native_rows"])==4
 for x in r["native_rows"]:
  assert x["result"]["completed_depth"]==2 and c["forced_actions"][x["cell"]]==x["result"]["action"]
 d=json.loads((P/c["root"]).read_bytes())
 assert d["before_sha256"]==c["state_sha256"]
 out.append(dict(seed=c["seed"],before_sha256=c["state_sha256"],cells=4,all_completed_depth=2))
(P/"paid-binding.json").write_text(json.dumps(dict(status="PASS",rows=out,scope="Actual preexisting matrices/inputactions; original shell validation launch failed NameError due to execcomprehension locals, producer stillstarted; no claims of successful prelaunchbinding check."),indent=2))
print("BIND_PASS",len(out))
