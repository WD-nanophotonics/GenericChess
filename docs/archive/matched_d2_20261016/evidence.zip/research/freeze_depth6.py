from pathlib import Path
import json,datetime
P=Path(".local_agent/matched-d2-20261016");Q=P/"future-depth6";Q.mkdir()
base=json.loads((P/"plan.json").read_bytes());plan=dict(base);cases=[]
for i,c in enumerate(base["cases"]):
 for q in([0,1]if i%2==0 else[1,0]):cases.append(dict(c,future_q=q))
plan.update(status="FROZEN_BEFORE_DEPTH6_FUTURE_LABELS",frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=cases,question="Does requesteddeeper commonfuture change the conditional firstaction contrast, under the same32K/1s ceiling? Actualretaineddepth is measured, notassumed6.",expected_seconds=1500,whole_seconds=2700,game_seconds=90,planned_cells=64,unique_games=44,scope="EXPOSED existing8parents,22forcedactions repeatedunder2commonfutureqpolicies; no newindependentfamilies/training/default. Changedmaximumdepth3to6, samecaller/node/history; finitecensors unchanged. Freezeafterq0D3andpartialq1D3labels; nooutcomeselection/capextension.")
plan["future"]["depth"]=6
(Q/"plan.json").write_bytes((json.dumps(plan,indent=2)+"\n").encode())
s=(P/"run.py").read_text().replace('P=R/".local_agent/matched-d2-20261016"','P=R/".local_agent/matched-d2-20261016/future-depth6"').replace('game_id=str(case["seed"])+"-"+str(gi)','game_id=str(case["seed"])+"-q"+str(case["future_q"])+"-"+str(gi)').replace('a.load(P/case["root"])','a.load(P.parent/case["root"])').replace('max_depth=3,max_nodes=32768,max_time_seconds=.95,quiescence_max_depth=0','max_depth=6,max_nodes=32768,max_time_seconds=.95,quiescence_max_depth=case["future_q"],quiescence_hard_max_depth=8').replace('board=case["board"],cells=cells','board=case["board"],future_q=case["future_q"],cells=cells')
(Q/"run.py").write_bytes(s.encode())
s=(P/"consumer.py").read_text().replace('s,nr=root(read(case["root"]))','s,nr=root(json.loads((B.parent/case["root"]).read_bytes()))')
(Q/"consumer.py").write_bytes(s.encode())
print("FROZEN44_DEPTH6",plan["frozen_utc"])
