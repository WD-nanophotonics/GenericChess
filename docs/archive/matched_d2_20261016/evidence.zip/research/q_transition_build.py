from pathlib import Path
import json,shutil,sys,sysconfig,subprocess,time,hashlib,datetime
R=Path.cwd();P=R/".local_agent/matched-d2-20261016";Q=P/"q1-transition";Q.mkdir()
plan=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),question="Does material-view thenfullcommit savecost for currentq1or merelydoublebuildmostnoisychildren?",changed_premise="Currentq1commonfuture/scalequeries exposecost, materialtimer<1percent; q4olderquiet-historyevidence doesnotmeasureq1noisecomposition.",cases=json.loads((P/"plan.json").read_bytes())["cases"],arms=["normal","counter","fullchecked"],q=1,depth=3,nodes=131072,repetitions=2,max_queries=48,max_time_seconds=None,expected_seconds=90,whole_seconds=600,decision="First requirecompletedfiniteoutputs agree andcounterunchanged; iffullcheckednotusefulcostreject. Noadoptionfromvisits/depth, no defaultorsemanticrulechanges.",scope="EXPOSED8parents, privateisolatedCbuild, no games/model/auxwork. Fixednodesnotwallstrength, allqhard/nodelimitsretained.")
(Q/"plan.json").write_bytes((json.dumps(plan,indent=2)+"\n").encode())
normal=(R/"generic_chess/_native/native_module.c").read_text(encoding="utf-8-sig")
for arm in["counter","fullchecked"]:
 S=Q/(arm+"-source");S.mkdir()
 for f in(R/"generic_chess/_native").iterdir():
  if f.suffix in[".c",".h"]:shutil.copyfile(f,S/f.name)
 s=normal
 if arm=="fullchecked":
  old="int can_defer = !check && gc_semantic_q_history_deferrable(ctx->rules, pos);";assert s.count(old)==1;s=s.replace(old,"int can_defer = 0; /* PRIVATE fullchecked qcontrol */")
 else:
  old="    uint32_t tt_iteration_generation;";assert s.count(old)==1;s=s.replace(old,"    uint64_t private_q_trials, private_q_quiet, private_q_recommits;\n"+old)
  start=s.index("static int gc_semantic_quiescence(");end=s.index("static int gc_semantic_iterative_negamax(",start);part=s[start:end]
  old="ctx->transition_count++;legal++;";assert part.count(old)==1;part=part.replace(old,old+"ctx->private_q_trials++;")
  old="if(!noisy)continue;";assert part.count(old)==1;part=part.replace(old,"if(!noisy){ctx->private_q_quiet++;continue;}")
  old="        if (can_defer) {";assert part.count(old)==1;part=part.replace(old,old+"ctx->private_q_recommits++;")
  s=s[:start]+part+s[end:];old='        gc_semantic_set_u64(out, "ordering_cache_hits", cache_hits) != 0 ||';assert s.count(old)==1
  fields=["trials","quiet","recommits"];s=s.replace(old,"".join('        gc_semantic_set_u64(out, "private_q_'+k+'", ctx.private_q_'+k+') != 0 ||\n'for k in fields)+old)
 (S/"native_module.c").write_bytes(s.encode())
 cmd=[str(R/".venv/Lib/site-packages/ziglang/zig.exe"),"cc","-target","x86_64-windows-gnu","-shared","-O2","-I"+sysconfig.get_path("include"),"-I"+str(S),"-L"+str(Path(sys.base_prefix)/"libs"),"-lpython312",*[str(f)for f in sorted(S.glob("*.c"))],"-o",str(Q/(arm+"_native_core.pyd"))]
 t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120)
 out=dict(returncode=r.returncode,seconds=time.perf_counter()-t,command=cmd,stdout=r.stdout.decode(errors="replace"),stderr=r.stderr.decode(errors="replace"),sources={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()})
 (Q/(arm+"-build-private.json")).write_bytes((json.dumps(out,indent=2)+"\n").encode());print("BUILD",arm,r.returncode,out["seconds"],out["stderr"][-1000:],flush=True);assert r.returncode==0
