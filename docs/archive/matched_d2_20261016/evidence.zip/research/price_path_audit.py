from pathlib import Path
import json,hashlib,datetime
R=Path.cwd();P=R/".local_agent/matched-d2-20261016";O=R/".local_agent/playability-mu-20261016"
source=(R/"generic_chess/_native/native_module.c").read_text()
assert source.count("ctx->profile")==2
records=[]
for row in json.loads((O/"interaction/completion.json").read_bytes())["games"]:
 if row["kind"]!="ACTUAL_GAME":continue
 f=O/"interaction"/("game-"+str(row["seed"])+"-"+row["mode"]+".json")
 for x in json.loads(f.read_bytes())["rows"]:records.append(x["result"])
assert records
for r in records:assert not r["learned_move_ordering"]and not r["policy_ordering"]and r["ordering_evaluations"]==r["policy_state_inferences"]==0
out=dict(complete=True,source_module_sha256=hashlib.sha256((R/"generic_chess/_native/native_module.c").read_bytes()).hexdigest(),actual_prior_queries_checked=len(records),profile_use_lines=[i for i,l in enumerate(source.splitlines(),1)if"ctx->profile"in l],facts=["Onlytwoiterativectxprofileuses: qstandpat anddisabledqleafmaterial.","Plainexact-rootmainordering usescapturebinary+history/canonicalTT, qorderingusescapturebinary+canonicalkey; neitherreadsboard/handpriceprofile.","Learned/policyordering notsupplied inproducer or2480actualreceipts; exported inferencecounts0.","Changing leaf values can endogenously change bounds/TT/history/work/completion; these are mediators of evaluation treatment, not separate directpriceSEE/order knobs."],correction="Previous5fe report sentenceNativeleaf/order/capturetableschangejointly isincorrectforthis configuredC392exact-rootpath. Itwasoverbroad importedcaveat, not sourcefact. Retain oldimmutableSHA/data; correct currentreport/mainline and fixedfuturemessage. No newAPI/orderseparationexperiment needed.",scope="Sourceandactualreceiptconfigurationaudit, no newsearch/WDL/reexecutionofoldgames/claimallNativeorFairybackends.")
(P/"price-path-audit.json").write_bytes((json.dumps(out,indent=2)+"\n").encode());print(out)
