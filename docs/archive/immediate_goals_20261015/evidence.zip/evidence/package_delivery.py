from pathlib import Path
import json,zipfile,hashlib,re,os,datetime,collections,xml.etree.ElementTree as ET
R=Path.cwd();b=R/'.local_agent/immediate-goal-20261015';arc=R/'docs/archive/immediate_goals_20261015';arc.mkdir(parents=True,exist_ok=True)
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write_json(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf-8')
summary=load(b/'summary.json');tests=ET.parse(b/'installed-final-tests.xml').getroot().find('testsuite');assert tests.get('tests')=='2630'and tests.get('errors')==tests.get('failures')=='0';summary['installed_final_tests']={k:v for k,v in tests.attrib.items()if k in ['tests','errors','failures','skipped','time']};summary['replay']=load(b/'replay-qualification.json');summary['missing_played_roots']=[{k:v for k,v in x.items()if k!='final_state'}for x in load(b/'prefix-transfer/missing-played-roots.json')];summary['caller_cost']=load(b/'caller-cost.json');summary['auxiliary']={'fixed_report':'c299879d863eb53119b9eb732b3c4f03fbdbfa9d','full_report_read':True,'primary_reexecuted':False,'lane':'Genericprover/verifier/cursor/physicaltails on sidemission; Primary Native C/Python interfaces only.'}
proto=b/'native-only-results.json'
if proto.exists():
 d=load(proto);assert d['complete'];groups=collections.defaultdict(dict)
 for x in d['rows']:groups[(x['root'],x['order'])][x['arm']]=x
 import math
 ratios=[x['NativeOnly']['caller_seconds']/x['CorePlusNative']['caller_seconds']for x in groups.values()];summary['native_only_private_control']={'complete':True,'timed_calls':len(d['rows']),'paid_warm_calls':d['warm_calls'],'pairs':len(groups),'non_time_errors':d['errors'],'caller_ratio_gmean':math.exp(sum(math.log(x)for x in ratios)/len(ratios)),'seconds':d['seconds'],'postcall_Core_and_Native_PV_state_history_checked':True,'product_adopted':False,'scope':'Exposed35fixture feasibility; full product Core PV validation retained.'};assert not d['errors']
else:raise AssertionError('native-only control not closed')
write_json(b/'delivery-summary.json',summary)
report='''# Immediate terminal goals and explicit semantic backends

The Native semantic engine now offers an explicit physical-win decision goal.
Default finite analysis, UI routing and evaluator formulas are unchanged. An
explicit backend compilation entry also replaces source-exec/module-switch
workarounds for known versioned backends. The optional wide image stays a
source-built research artifact; the installed/default V1 guard remains<=16.
Science is OPEN. No stronger-play, universal price or whole-domain claim.

## Delivered API and truthful completion

`SemanticSearchEngine.search(..., stop_on_immediate_win=True)` and the one-shot
`semantic_iterative_search` opt into a verified root-child decision. False is
the default and retains old-kernel calling compatibility. True requires the
creating backend to advertise the feature; it never silently downgrades.

The proof is the actual terminal result of a fully checked Native child under
complete rules/history, with winner equal to the root player. It is not a
mate-like evaluator score, a declaration, a draw, or a multi-step heuristic.
The flag is committed only after binding the completed child to its root action.
The incomplete root is not entered as a completed finite root TT result.

A prefix win returns `immediate_win=True`, a one-action PV, and
`result_source="verified_root_child"`. `completed_depth` stays0 and completed
ordinary/hard-q policy staysNone: the whole D1 iteration did not finish. A
coincident node/time/cancel stop retains its real termination reason. Existing
finite iterations, fallback and terminal-position sources are distinguished.
The two new result fields are appended, preserving older positional field order.
Full Native checked PV replay and dynamic metadata remain in the product caller.

Real regression: at12nodes the fixture has no proof and uses fallback; at13 it
retains a genuine terminal win while reporting node_budget/D0; at14 it reports
the same proof with root_immediate_win/D0. Both root-window modes, cold/warm TT,
root-ply offsets, actual played perpetual-check history, neutral declarations,
ordinary declarations, draw/max-ply, pre-cancel and raw-parser recovery are
covered. No change to AUX's generic prover, verifier or StrategyCursor.

## Prospective evidence and negative results

Initial fresh seeds3801/3802,3811/3812,3821/3822 cover8/12/16 and ply0/8. All six
families/12roots prepare; full state, hands, auxiliary state, exact SHA history,
actor/check events and all legal actions are checked before comparisons. Static
rule-derived board/current and hand/base profiles are rounded identically. No
human-price fitting, exposed-label training or Xiangqi human holdout reads.

48fixed-node pairs/96calls,64/512nodes, preserve every non-time result field
between the old image and default analysis. No time censors. The intermediate
complete-D1 physical-goal experiment has96resource calls: all48actions equal to
analysis,8actual M1pairs return in2.6-6.0ms and save11.49paired caller seconds.
This changes the stopping goal, not the full requested finite-analysis cost.
Its96cold/warm TTcalls likewise retain all48actions and40matching policies.
Warm calls pay their preceding cold call and retain only their own arm's table.

A full Core census of those12roots finds two genuine M1roots. Complete-D1 mode
still returns a nonwinning fallback at8/32nodes. The exposed private prefix
pilot144calls yields6certified D0decisions versus4complete-D1 decisions; every
advertised proof is verified by a public Core terminal. It is development, not
independent validation.

The next batch was frozen BEFORE its results:24new families, seeds3901..3906,
3911..3916,3921..3926,3931..3936 on4/8/12/16, unchanged bilateral_random/hybrid,
max32attempts,45s preparation cap, repr-sorted Random(seed+7000) walk. It saves
46searchable roots.3904 ends by actual mate atply1 and3923 atply2, so their
ply8roots do not exist; zero-new-search deterministic replay preserves those
coverage outcomes. No replacement, later cap extension or missing-slot erasure.

|New prefix comparison|Calls/pairs|Actual immediate-win gain/loss|Same actions|Matching finite policies|Actual q4 baseline/candidate|
|---|---:|---:|---:|---:|---:|
|1/8s,TT0|368/184|0/0|184|172,all scores equal|92/92|
|1s,TT1,cold+paid warm|192/96|0/0|96|88,all scores equal|44/44|

Both methods return actual M1 in12resource pairs and8TTpairs. Prefix/complete-D1
caller ratio on those wins is.9976(resource) and.9539(TT); total savings only
.00173/.00233seconds. These fresh results do NOT show a general prefix speed,
completion or strength gain. Its demonstrated small-node retention benefit stays
scoped. Neither-nonterminal-action outcomes are UNKNOWN, not draws or proved ties.
Played roots/orders/temperatures are dependent measurements, not independent
families. Ordinary concurrent machine load remains a timing interpretation limit.

Final source differs from the timed prefix by committing the action before the
proof flag and by final metadata handling.120fixed pairs/240calls qualify both
prefix behavior and old default analysis with identical non-time fields. This
is source qualification, not a claim of identical timed binaries or fresh holdout.

## Explicit backend and complete action transport

`compile_native_semantic_rules(compiled, backend_module=module)` captures the
creating backend without changing the global module. Known contract4/256 retains
legacy calls and packets. Contract5/1024 requires explicit semantic capacity,
raw encoding2 and public action-field version1. Unknown contracts fail visibly;
existing unsupported-rule/Core fallback boundaries remain. The compatibility
regression that changes the default during payload construction still passes.

The private wide image supplies public255 no-promotion/drop sentinels at the C
dictionary boundary while keeping the distinct63bit raw codec, payload5 and V2
capsules. Board from-square255 remains a real square for board moves; drop
sentinels are interpreted by kind. Legacy max_squares256 and semantic1024 are
separate advertised capacities. No truncation of promotion, drops or history.

35preserved full-state roots, including live aux, off-target effects, compound
moves, capture/reset/drop, NO_CONTEST and saved32roots, retain4497legal action
identities. Direct-C transport matches70old-shim probe pairs. The real public
explicit entry then executes70queries with the same non-time results and keeps
default V1 rejection above16. Separate32x32 roots actually mate by a drop and a
promotion at target992, with complete Core/Native state/history and D0goal output.
These constructed cases are capability evidence, not whole generated-domain
coverage or a human valuation result. Raw codec checks include96selected corner
combinations and rejection of the declaration/reserved high bit.

The first transport caller ratio.635 was misleading: prequalification always
warmed the direct image last. Ratios by order are.407 and.992. We reject the
aggregate speed interpretation; the decision here is a working, explicit
transport/API boundary. No timing-based automatic wide activation.

## Caller bottleneck and next experiment

Four exposed32goal profiles separate kernel, constructor and caller work. Drop
caller time is48-49ms, kernel.15-.25ms, with45.6-46.7ms in the duplicate Core PV
replay. Promotion caller is3.4-3.6ms with~.12ms kernel. Compilation is separate.
These are scoped method-wrapper timings, not independent universal estimates.

The next private control removes only that unused Core-state traversal while
retaining Native checked replay and all metadata. Both modes receive paid,
counterbalanced warmup; all35fixtures are externally replayed through full Core
and Native states/history after timing. Results are in the data/archive. This
control is NOT adopted in product: its exposed scope still needs an adoption
check against the complete caller contract. It is the executable next task.

## Validation, source closure and collaboration

Actual installed final source:2630active tests pass, zero skips/failures/errors.
The original run's124setup errors were AccessDenied in the old system pytest
scratch directory. A new project-owned basetemp resolves them without changing
machine security, deleting shared files or asking the user. Native build/import
worked; these errors are not evidence of Smart App Control. Failed logs remain.
31new goal cases and2explicit-backend cases pass. Intermediate2624/2628runs are
retained separately and are not relabeled final validation.

A new export actually rebuilds V1 and final V2 from their saved source and runs
33APItests plus35roots/4497legal identities and the two32goals. It blocks reads
from older private inputs and leaves the default module unchanged. The first
qualifier wrongly assumed every legal decision was a board move; it was corrected
to validate actual Core declarations too. Existing Python/Zig dependencies are
used; no clean-machine installer, byte-identical binary or long-curve replay claim.

DEV_AUX55 fixedc299879d863eb53119b9eb732b3c4f03fbdbfa9d report and complete thread
were read. AUX reports1402proof-adopting games physically winning,318tails,
77tests, uncertain price gains, cost/coverage loss under its SMALL trigger and
zero actual hits for its partial-proof retention. Those results are not primary
reruns. AUX owns multi-step proof/verifier/cursor, mutable fallback and learning;
PRIMARY changes Native interfaces only. No checkout/runtime/UI interference,
new Agent, automatic retry or receipt loop. Fixed-denominator and terminal-only
interpretations are reference advice; Dot is not a release gate.

Reviewed technical source, inputs, negative results and failures accompany the
member-hashed archive. Raw account/Slack originals stay private. Current repo is
Private; last connected GitHub read404 is a known access limit, so a sanitized
report/source/evidence bundle is shared directly in the authorized Slack channel.
Delivery proves availability there, not Dot reading/adoption. Git remains final
versioned delivery; exact remote SHA is checked after the tested publisher.
'''
(R/'docs/research/IMMEDIATE_GOALS_AND_EXPLICIT_BACKENDS.md').write_text(report,encoding='utf-8')
# Current, short decision; history stays in purpose reports.
p=R/'docs/research/LOCAL_MAINLINE.md';raw=p.read_bytes();s=raw.decode().replace('\r\n','\n');marker='## Priority and current decision\n\n';note='''IMMEDIATE_GOALS_AND_EXPLICIT_BACKENDS.md is current. Explicit physical-root-win mode now returns honest D0/qNone/sourceverified_root_child, default finite analysis unchanged; actual installed2630tests pass. Final-source120fixed pairs preserve non-time results. Fresh24family/46root prefix study:184resource+96TTpairs allsameactions, sameq4counts, no actualM1gain/loss or general speed claim; small-node proof retention is the benefit. Two absentply8roots ended by actual mate, not replacements. Public explicit backend_module compiles knownversioned transports without global swaps;35fullroots/4497actions and2actual32drop/promo goals pass, defaultV1<=16 remains. Freshtwo-image export/33tests/35roots/2goals closes source/input path. V2 remains an optional source-built research image, not automatic default. Native-only caller replay is a private next candidate after measured45ms duplicate CorePV cost on a32drop goal; full product Corevalidation retained. AUX55fixedc299 fullreport/thread read, no primary rerun or solver/runtime/cursor writes.\n\n''';s=s.replace(marker,marker+note,1).replace('ROOT_ORDER_COST_AND_PRICED_TRANSFER.md is current.','Prior ROOT_ORDER_COST_AND_PRICED_TRANSFER.md:',1);p.write_bytes(s.replace('\n','\r\n'if b'\r\n'in raw else '\n').encode())
for rel,note in [('docs/operations/BACKEND_HANDOFF.md','''## 2026-10-15 immediate goals and explicit backend entry

Native semantic search accepts stop_on_immediate_win=True; defaultFalse keeps finite analysis. A true physical winning child may return before completeD1: immediate_win=True, result_source=verified_root_child, completed_depth0, completedqNone, one-actionPV. Preserve node/time/cancel reasons, do not require depth>0 to recognize this explicit goal, and do not relabel it completedD1/q4. Native rebuild is required for True; old kernels still support False without extra arguments. Existing declarations/fallbacks remain distinct.

compile_native_semantic_rules(...,backend_module=module) owns a known explicit backend contract. DefaultV1<=16/normal routing remains; optional source-builtV2 supplies payload5/1024capacity/encoding2/publicfield1. No global loader swap or automaticwide activation. Complete target semantics/fallback boundaries stay. Source, reproduction and actual32drop/promotion evidence: ../research/IMMEDIATE_GOALS_AND_EXPLICIT_BACKENDS.md. Actual installed2630tests and isolated33APItests pass; no UI change.

'''),('docs/operations/COLLABORATION_LOG.md','''## 2026-10-15 PRIMARY goal/backend entry and DEV_AUX55

PRIMARY delivers explicit physical-root-win/D0source reporting, known backend-module compilation, full2630tests, source-built32drop/promotion closure and frozen goal/cost evidence. Default finite analysis and UI remain. The fresh24family/46root prefix batch has no additional M1events or general speed gain; negative findings are retained. Native-only replay remains a private candidate after actual caller-cost attribution.

DEV_AUX55 fixedc299879d863eb53119b9eb732b3c4f03fbdbfa9d report fully read through remote Git objects: symmetric physical certificate-tail execution, normal fallback for unsupported runtime,77focused tests,1402adopted-proof games physically winning and318tails. Price gains still cross zero; SMALL trigger saves cost with4fewer highR wins; partial retention0actualhits deferred. These are AUX-reported, not PRIMARY reproduced. AUX keeps generic prover/verifier/cursor, fallback runtime and learning on sidemission; PRIMARY changes Native C/compiler/caller only. No cross-checkout/state write, merge, duplicate solver, extra Agent or pause request.

At recovery and final checkpoint read new channel roots plus whole primary/AUX55threads, no remaining pages; exact originals saved before reconcile. The new AUX result was found in its existing thread despite no new roots. Prior ownership messages1792036243.974859/1792038125.290899 remain operative; no routine acknowledgment/wake/retry loop. Adopt Dot's fixed planned-denominator and actual-terminal interpretation as reference, not authority or independent execution. No observed coordination conflict. Concrete complementary outputs avoid duplicate solver work; elapsed collaboration savings are not independently quantified. Ordinary concurrent load is normal and limits timing interpretation only.

Fixed auxiliary report: https://github.com/WD-nanophotonics/GenericChess/blob/c299879d863eb53119b9eb732b3c4f03fbdbfa9d/results/dev_aux/SEGMENT_20261015_55.md . PRIMARY tested sandbox revision/report/archive is sent through the dedicated project Slack with a sanitized evidence attachment because private-GitHub connector access was404; file delivery does not prove Dot read/adopted it. No publication approval gate. Heartbeat remains PAUSED.

''')]:
 p=R/rel;old=p.read_bytes();p.write_bytes(note.replace('\n','\r\n'if b'\r\n'in old else '\n').encode()+old)
# Exclude raw account/transport records and scratch outputs. Preserve exact private originals.
blocked=('recovery-','final-slack-','final-primary-','final-consult-','final-reconcile-','dot-')
files=[]
for p in b.iterdir():
 if p.is_file()and p.suffix in ['.py','.json','.log']and not p.name.startswith(blocked)and not p.name.endswith('-private.json')and p.name not in ['native_only_common_first.py']:
  files.append(('evidence/'+p.name,p,p.relative_to(R).as_posix()))
for p in (b/'prefix-transfer').iterdir():
 if p.is_file()and p.suffix in ['.py','.json','.log']:files.append(('evidence/prefix-transfer/'+p.name,p,p.relative_to(R).as_posix()))
source_groups=[('old_v1',b/'src_old_v1'),('complete_d1_v1',b/'src_complete_d1_v1'),('timed_prefix_v1',b/'src_prefix_v1'),('final_v1',R/'generic_chess/_native'),('normalized_v2',b/'src_normalized_v2'),('final_v2',b/'src_final_v2'),('prior_v2',R/'.local_agent/backend-owner-20261015/src_scoped_v2')]
for label,folder in source_groups:
 ps=[p for p in folder.iterdir()if p.suffix in ['.c','.h']];assert len(ps)==36
 files += [('source/'+label+'/'+p.name,p,p.relative_to(R).as_posix())for p in ps]
for folder in [b/'before',b/'complete_d1_python',b/'wide-merge']:
 for p in folder.rglob('*'):
  if p.is_file()and p.suffix in ['.py','.c','.json','.log']:files.append(('snapshots/'+p.relative_to(b).as_posix(),p,p.relative_to(R).as_posix()))
p=R/'.local_agent/backend-owner-20261015/owned_common.py';files.append(('support/owned_common.py',p,p.relative_to(R).as_posix()))
# Preserve referenced older inputs needed by the recorded driver; these are project technical records.
for rel in ['.local_agent/wide-interface-20261015/qualification-inputs.json','.local_agent/backend-owner-20261015/new32-inputs.json','.local_agent/priced-completion-20261015/inputs.json']:
 p=R/rel;files.append(('support/'+p.parent.name+'/'+p.name,p,rel))
# No JS numeric roundtrip: Python preserves full64bit action values when sanitizing JSON.
tokens=[str(R),R.as_posix(),str(Path.home()),Path.home().as_posix(),Path.home().name,os.environ.get('COMPUTERNAME','')];variants=[]
for token in tokens:
 if not token:continue
 replacement='<PROJECT_ROOT>'if token in [str(R),R.as_posix()]else'<MACHINE>'if token==os.environ.get('COMPUTERNAME')else'<USER>'
 for _ in range(4):variants.append((token,replacement));token=json.dumps(token)[1:-1]
variants.sort(key=lambda x:len(x[0]),reverse=True)
def clean(text):
 for old,new in variants:text=re.sub(re.escape(old),lambda m:new,text,flags=re.I)
 return text
members=[]
with zipfile.ZipFile(arc/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,p,restore in files:
  raw=p.read_bytes();text=raw.decode('utf-8-sig');safe=clean(text).encode('utf-8');assert not re.search(rb'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',safe),name
  assert Path.home().name.lower().encode()not in safe.lower(),name
  z.writestr(name,safe);members.append({'name':name,'bytes':len(safe),'sha256':hashlib.sha256(safe).hexdigest(),'original_sha256':hashlib.sha256(raw).hexdigest(),'publication_copy_changed':safe!=raw,'restore_to':restore})
with zipfile.ZipFile(arc/'evidence.zip')as z:
 assert z.testzip()is None
 for m in members:assert hashlib.sha256(z.read(m['name'])).hexdigest()==m['sha256']
manifest={'count':len(members),'members':members,'zip_sha256':hashlib.sha256((arc/'evidence.zip').read_bytes()).hexdigest(),'personal_account_raw_and_binaries_excluded':True,'all_member_sha_and_crc_checked':True,'source_pin':'90c3352b2171cdfa2f5b79f19aad469055e7c6c5 plus this publication changes','timed_and_final_sources_distinguished':True};write_json(arc/'manifest.json',manifest)
write_json(R/'docs/research/data/immediate_goals_20261015.json',summary)
(arc/'README.md').write_text('''# Source and input closure

Restore only in a NEW project checkout/export at this publication revision. Manifest restore_to gives the original project-relative evidence layout; never overwrite unique existing evidence. Binaries are excluded. Existing Windows Python3.12/Zig dependencies are required.

For the current public API, restore final_v2 source and replay inputs/drivers, then run isolated_replay.py. It actually rebuilds both images and checks33APIcases,35fullstate roots and2high-coordinate32goals without older private inputs. This is not a clean-machine installer or byte-identical binary claim.

Earlier timed curves used intermediate Python/C snapshots supplied here. Restore the matching complete_d1_python/compiler snapshot in a separate export when replaying those stages, not over a live checkout. The final source controls distinguish behavior from timing-source identity. Native-only replay is a private control, not product code. Some publication copies normalize paths/encoding; original and public hashes distinguish them, while exact originals stay private. Python JSON readers retain64bit action integers; avoid floating-point JSON roundtrips.

Plans, missing early-ended walks, setup/driver failures and corrections remain. Raw account/Slack/signed receipts and host-specific XML are excluded; sanitized test counts and logs are included. Every member SHA and ZIP CRC was checked before publication.
''',encoding='utf-8')
write_json(arc/'segment_review.json',{'session_id':'2d0207e0-c26e-444d-b300-51a3026fb5fe','science':'OPEN','installed_final_tests':summary['installed_final_tests'],'all_owned_studies_closed':True,'default_finite_analysis_unchanged':True,'default_wide_backend_not_activated':True,'optional_goal_physical_winner_and_honest_D0_metadata':True,'explicit_public_backend_v2_closure':summary['explicit_v2'],'isolated_source_replay':summary['replay'],'no_auxiliary_prover_cursor_runtime_checkout_writes':True,'archive_members':len(members),'outgoing_current_content_sanitized_and_scanned':True,'limits':['Fresh prefix full-time comparison has no extra actualM1 events or general speed gain','Initial small-node positive cases are exposed development','V2optional source-built artifact, not whole generated-domain/default coverage','Native-only replay private candidate, product Corevalidation retained','AUX55 fullreport read, not primary reexecuted','Private GitHub connector known404; direct Slack evidence used']})
print(json.dumps({'members':len(members),'zip_bytes':(arc/'evidence.zip').stat().st_size,'native_only':summary.get('native_only_private_control'),'tests':summary['installed_final_tests']}))
