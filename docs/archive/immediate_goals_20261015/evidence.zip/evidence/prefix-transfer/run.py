from pathlib import Path
import subprocess,sys,time,json
b=Path('.local_agent/immediate-goal-20261015/prefix-transfer');start=time.perf_counter();rows=[]
for name in ['prepare','compare']:
 remaining=3500-(time.perf_counter()-start)
 if remaining<=0:raise TimeoutError('whole pipeline3500s fuse')
 with (b/(name+'.log')).open('wb')as log:
  r=subprocess.run([sys.executable,str(b/(name+'.py'))],stdout=log,stderr=subprocess.STDOUT,timeout=remaining)
 rows.append({'phase':name,'exit':r.returncode,'elapsed':time.perf_counter()-start});(b/'pipeline.json').write_text(json.dumps({'complete':False,'rows':rows}),encoding='utf-8')
 if r.returncode:raise SystemExit(r.returncode)
(b/'pipeline.json').write_text(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8')
