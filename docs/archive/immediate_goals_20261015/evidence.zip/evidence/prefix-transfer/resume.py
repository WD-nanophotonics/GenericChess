from pathlib import Path
import subprocess,sys,json,time,datetime
b=Path('.local_agent/immediate-goal-20261015/prefix-transfer');plan=json.loads((b/'plan.json').read_text());age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(plan['frozen_at'])).total_seconds();remaining=3500-age;assert remaining>0
with (b/'compare-run.log').open('wb')as log:r=subprocess.run([sys.executable,str(b/'compare.py')],stdout=log,stderr=subprocess.STDOUT,timeout=remaining)
p=b/'pipeline.json';d=json.loads(p.read_text());d['rows'].append({'phase':'compare_after_syntax_fix','exit':r.returncode,'remaining_at_start':remaining});d['complete']=r.returncode==0;p.write_text(json.dumps(d,indent=2),encoding='utf-8');raise SystemExit(r.returncode)
