from pathlib import Path
exec(compile(Path('.local_agent/immediate-goal-20261015/prefix_pilot.py').read_text(encoding='utf-8-sig').split('\ninputs=json.loads')[0],'<prefix_common>','exec'))
b=b/'prefix-transfer';inputs=json.loads((b/'inputs.json').read_text());plan=json.loads((b/'plan.json').read_text());assert inputs['complete'];rows=[];roots=[];start=time.perf_counter()
def save(study,done=False,error=None):(b/(study+'-results.json')).write_text(json.dumps({'complete':done,'rows':rows,'roots':roots,'seconds':time.perf_counter()-start,'error':error}),encoding='utf-8')
for study in ['resource','tt']:
 rows=[];roots=[];start=time.perf_counter();limspec=plan[study]
 try:
  for x in inputs['samples']:
   p.rr.stopped()
   if not x['included']or(study=='tt'and not x['name'].endswith('ply0')):continue
   prep=time.perf_counter();c,s=case(x);profile=p.build_ruleset_profile(c,p.EvaluationConfig());v={z:int(round(y))for z,y in profile.board_value_by_type.items()};h={z:int(round(y))for z,y in profile.hand_value_by_base_type.items()};before=record_value(s.to_record());rules={a:f(c)for a,f in compilers.items()}
   for nr in rules.values():
    pos=pack_semantic_search_position(c,nr,s);snap=sem.snapshot(nr,pos);exp=expected_snapshot(s.state.position,nr,c)
    for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(exp[k])
    assert sem.position_key(nr,pos)==str(position_identity_key(s.state.position,c)) and snap['history_exact'] and snap['history_events_exact']
    assert [''.join(f'{z:016x}'for z in hh)for hh in snap['history']]==[str(position_identity_key(w,c))for w in s._search_witnesses]
    assert set(sem.transient_legal_actions(nr,pos))=={pack_semantic_action(nr,s.state.position,a)for a in s.legal_actions()}
   roots.append({'root':x['name'],'n':x['n'],'board_values':v,'hand_values':h,'preparation_seconds':time.perf_counter()-prep,'full_state_history_legality':True})
   for seconds in limspec['seconds']:
    for order in limspec['orders']:
     for arm in (limspec['arms']if order==0 else limspec['arms'][::-1]):
      e=SemanticSearchEngine(c,rules[arm],board_values=v,hand_values=h,tt_megabytes=limspec['tt'],ordering_cache_enabled=False)
      for temperature in limspec.get('temperature',['cold']):
       p.rr.stopped()
       if time.perf_counter()-start>limspec['fuse']:raise TimeoutError('frozen'+study+' fuse')
       t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=limspec['depth'],max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True);wall=time.perf_counter()-t;raw=bridges[arm].raw
       child=None if r.action is None else apply_action(s.state,r.action,c);physical=child is not None and child.terminal_status.is_terminal and child.terminal_status.winner==s.state.position.side_to_move
       if r.immediate_win:
        assert physical and not r.used_fallback
        if arm=='prefix':assert r.completed_depth==0 and r.result_ordinary_qdepth is None and raw['result_source']=='verified_root_child'
        else:assert r.completed_depth==1 and r.result_ordinary_qdepth==0
       assert record_value(s.to_record())==before and _module()is new
       rows.append({'root':x['name'],'n':x['n'],'order':order,'seconds':seconds,'temperature':temperature,'arm':arm,'caller_seconds':wall,'result':record_value(r),'source':raw.get('result_source','main_iteration'if not r.used_fallback else'fallback'),'physical_winning_child':physical,'terminal':None if child is None else record_value(child.terminal_status)});save(study)
   print(study,x['name'],len(rows),flush=True)
  save(study,True);print('COMPLETE',study,len(rows),time.perf_counter()-start,flush=True)
 except BaseException:save(study,False,traceback.format_exc());raise
