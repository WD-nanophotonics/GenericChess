from pathlib import Path
import sys,json,inspect,importlib.util,time,traceback
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];b=R/'.local_agent/immediate-goal-20261015'
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import _module
import generic_chess.native.compiler as nc
from generic_chess.native import semantic as sem
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.ai.limits import SearchLimits
new=_module();spec=importlib.util.spec_from_file_location('goalold._native_core',next(b.glob('old_v1*.pyd')));old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
ns=dict(nc.__dict__);ns.update(_module=lambda:old,native_available=lambda:True);exec(inspect.getsource(nc.compile_native_semantic_rules),ns);compile_old=ns['compile_native_semantic_rules']
assert not old.native_capabilities().get('semantic_immediate_win_goal',False) and new.native_capabilities()['semantic_immediate_win_goal']
def case(x):
 raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 for a in x['walk']:
  action,=[v for v in s.legal_actions()if record_value(v)==a];s.submit(action)
 assert record_value(s.state)==x['state'];return c,s

def signature(result):return {k:v for k,v in record_value(result).items()if 'elapsed'not in k}
inputs=json.loads((b/'inputs.json').read_text());plan=json.loads((b/'prospective-plan.json').read_text());assert inputs['complete'];allrows=[];rootrows=[]

def run(study):
 rows=[];start=time.perf_counter();spec=plan[study]
 def save(done=False,error=None):
  (b/(study+'-results.json')).write_text(json.dumps({'complete':done,'rows':rows,'roots':rootrows,'seconds':time.perf_counter()-start,'error':error}),encoding='utf-8')
 try:
  for x in inputs['samples']:
   p.rr.stopped()
   if not x['included']:continue
   prep=time.perf_counter();c,s=case(x);prof=p.build_ruleset_profile(c,p.EvaluationConfig());v={t:int(round(z))for t,z in prof.board_value_by_type.items()};h={t:int(round(z))for t,z in prof.hand_value_by_base_type.items()};before=record_value(s.to_record());nrnew=nc.compile_native_semantic_rules(c);nrold=compile_old(c)
   for nr in [nrold,nrnew]:
    pos=pack_semantic_search_position(c,nr,s);snap=sem.snapshot(nr,pos);exp=expected_snapshot(s.state.position,nr,c)
    for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(exp[k]),(x['name'],k)
    assert sem.position_key(nr,pos)==str(position_identity_key(s.state.position,c))
    assert snap['history_exact'] and snap['history_events_exact'] and snap['ply']==s.state.ply_count
    assert [''.join(f'{a:016x}'for a in z)for z in snap['history']]==[str(position_identity_key(w,c))for w in s._search_witnesses]
    assert snap['history_events']==tuple((255if z.actor<0 else z.actor,bool(z.gave_check))for z in s.state.history)
    assert set(sem.transient_legal_actions(nr,pos))=={pack_semantic_action(nr,s.state.position,a)for a in s.legal_actions()}
   rootrows.append({'study':study,'name':x['name'],'n':x['n'],'board_values':v,'hand_values':h,'preparation_seconds':time.perf_counter()-prep,'complete_state_and_legal_checked':True})
   for budget in spec.get('nodes',spec.get('seconds')):
    for order in [0,1]:
     arms=spec['arms']if order==0 else spec['arms'][::-1]
     for arm in arms:
      e=SemanticSearchEngine(c,nrold if arm=='oldanalysis'else nrnew,board_values=v,hand_values=h,tt_megabytes=spec['tt'],ordering_cache_enabled=False)
      for temperature in spec.get('temperature',['cold']):
       p.rr.stopped();assert _module()is new
       if time.perf_counter()-start>spec['batch_fuse']:raise TimeoutError('frozen batch fuse')
       lim=SearchLimits(max_depth=spec['depth'],max_nodes=budget if study=='fixed'else None,max_time_seconds=spec['time_fuse_per_call']if study=='fixed'else budget,quiescence_max_depth=spec['q'],quiescence_hard_max_depth=spec['hard'])
       t=time.perf_counter();result=e.search(s,lim,root_window_pruning=True,stop_on_immediate_win=arm=='goal');seconds=time.perf_counter()-t
       assert record_value(s.to_record())==before and _module()is new
       child=None if result.action is None else apply_action(s.state,result.action,c);win=child is not None and child.terminal_status.is_terminal and child.terminal_status.winner==s.state.position.side_to_move
       if result.immediate_win:assert win and result.completed_depth==1 and result.goal_checked_transitions==1 and result.result_ordinary_qdepth==0
       rows.append({'root':x['name'],'n':x['n'],'order':order,'budget':budget,'temperature':temperature,'arm':arm,'caller_seconds':seconds,'result':record_value(result),'physical_winning_child':win,'child_terminal':None if child is None else record_value(child.terminal_status)});save()
   print(study,x['name'],len(rows),flush=True)
  save(True);print('COMPLETE',study,len(rows),time.perf_counter()-start,flush=True)
 except BaseException:save(False,traceback.format_exc());raise
for study in ['fixed','resource','tt']:run(study)
