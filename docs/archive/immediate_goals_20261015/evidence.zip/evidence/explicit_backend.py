from pathlib import Path
import json,datetime
b=Path('.local_agent/immediate-goal-20261015');p=Path('generic_chess/native/compiler.py');raw=p.read_bytes();(b/'compiler-before-explicit-backend.py').write_bytes(raw);s=raw.decode().replace('\r\n','\n')
(b/'explicit-backend-plan.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observed_gap':'Cnormalized V2 matches full35roots/4497legal actions and70fixed probe pairs, but public compiler hardcodes payload4/256 and requires source-exec workaround.','change':'Explicit optional backend_module binding, select only known payload4/256 or payload5/1024 with version2rawcodec/version1public dictionary markers. No default module swap, automaticV2activation, extra fees or AUXsolver changes.','tests':'Defaultpayload and new goal/source tests; public explicit normalizedV2 all35root fullstate/history/action/probe closure; old rawV2 without dictionary/capacity contract rejected; malformed version/capacity rejected. Final full source suite needed after compiler edit.','limit':'PrivateV2 binary remains a separately source-built optional research backend, no publicdefault wide loader/build activation. Generic target still full domain with explicit unsupported scope.'},indent=2),encoding='utf-8')
def once(a,c):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,c,1)
once('def _native_payload_is_executable(payload, report: NativeSemanticCompilationReport) -> bool:','def _native_payload_is_executable(payload, report: NativeSemanticCompilationReport, *,\n                                  payload_version=SEMANTIC_PAYLOAD_VERSION,\n                                  max_squares=256) -> bool:')
# Only this helper's contract terms change; default behavior is byte-equivalent.
start=s.index('def _native_payload_is_executable(');end=s.index('\ndef build_semantic_compile_payload',start);chunk=s[start:end].replace('== SEMANTIC_PAYLOAD_VERSION','== payload_version').replace('report.board_squares <= 256','report.board_squares <= max_squares');s=s[:start]+chunk+s[end:]
once('def build_semantic_compile_payload(semantic):','def build_semantic_compile_payload(semantic, *,\n                                   _payload_version=SEMANTIC_PAYLOAD_VERSION,\n                                   _max_squares=256):')
start=s.index('def build_semantic_compile_payload(');end=s.index('\ndef compile_native_semantic_rules',start);chunk=s[start:end];chunk=chunk.replace('    n = support.board_size','    if (_payload_version, _max_squares) not in ((4, 256), (5, 1024)):\n        raise NativeUnsupportedRuleError("unknown semantic payload/capacity contract")\n    n = support.board_size',1);chunk=chunk.replace('1 <= n <= 16 and n * n <= 256','1 <= n and n * n <= _max_squares',1);chunk=chunk.replace('"semantic_payload_version": SEMANTIC_PAYLOAD_VERSION','"semantic_payload_version": _payload_version',1);chunk=chunk.replace('semantic_payload_version=SEMANTIC_PAYLOAD_VERSION','semantic_payload_version=_payload_version',1);chunk=chunk.replace('_native_payload_is_executable(payload, report)','_native_payload_is_executable(payload, report,\n        payload_version=_payload_version, max_squares=_max_squares)',1);s=s[:start]+chunk+s[end:]
helper='''def _semantic_backend_contract(backend, *, explicit: bool):
    """Select a known transport contract, separately from legacy capacities."""
    capabilities = getattr(backend, "native_capabilities", None)
    if not callable(capabilities):
        if not explicit:
            return SEMANTIC_PAYLOAD_VERSION, 256  # Existing default facades.
        raise NativeUnsupportedRuleError("explicit semantic backend lacks capabilities")
    caps = capabilities()
    version = caps.get("semantic_payload_version", SEMANTIC_PAYLOAD_VERSION
                       if not explicit else None)
    if version == 4:
        return 4, 256
    if (version == 5 and caps.get("semantic_max_squares") == 1024
            and caps.get("semantic_action_encoding_version") == 2
            and caps.get("semantic_public_action_fields_version") == 1):
        return 5, 1024
    raise NativeUnsupportedRuleError(
        "semantic backend has an unsupported payload/action dictionary contract")


'''
once('def compile_native_semantic_rules(semantic) -> NativeSemanticCompiledRules:',helper+'def compile_native_semantic_rules(semantic, *, backend_module=None) -> NativeSemanticCompiledRules:')
once('    if not native_available():\n        raise NativeUnsupportedRuleError(\n            "native extension is not built; run scripts/build_native_zig.py"\n        )\n    backend = _module()\n    payload, report = build_semantic_compile_payload(semantic)','    if backend_module is None and not native_available():\n        raise NativeUnsupportedRuleError(\n            "native extension is not built; run scripts/build_native_zig.py"\n        )\n    backend = _module() if backend_module is None else backend_module\n    version, max_squares = _semantic_backend_contract(backend, explicit=backend_module is not None)\n    payload, report = build_semantic_compile_payload(semantic,\n        _payload_version=version, _max_squares=max_squares)')
once('    capsule (compile-only contract; no semantic execution)."""','    capsule (compile-only contract; no semantic execution).\n\n    An explicit separately built backend owns its capsules. Only known payload\n    and public-action dictionary contracts are accepted; the global/default\n    module and its fallback routing are unchanged.\n    """')
p.write_bytes(s.replace('\n','\r\n'if b'\r\n'in raw else '\n').encode('utf-8'))
