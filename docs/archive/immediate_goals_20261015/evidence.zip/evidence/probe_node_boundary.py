from pathlib import Path
import sys,importlib.util,json
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
import generic_chess.native as n
assert n._MODULE is None
spec=importlib.util.spec_from_file_location('probe._native_core',next((R/'.local_agent/immediate-goal-20261015').glob('final_v1*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);n._MODULE=m
from test_native_immediate_win_goal import position,make,SearchLimits
rows=[]
for count in range(1,33):
 s=position();r=make(s).search(s,SearchLimits(max_depth=2,max_nodes=count),stop_on_immediate_win=True)
 rows.append({'budget':count,'win':r.immediate_win,'reason':r.termination_reason,'depth':r.completed_depth,'nodes':r.nodes+r.qnodes,'source':r.result_source})
 if r.immediate_win and r.termination_reason=='root_immediate_win':break
Path('.local_agent/immediate-goal-20261015/prefix-node-boundary.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print(rows)
