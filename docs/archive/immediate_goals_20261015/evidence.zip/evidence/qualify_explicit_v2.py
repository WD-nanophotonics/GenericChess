from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8-sig'),'<owned_common>','exec'))
b=ROOT/'.local_agent/immediate-goal-20261015';spec=importlib.util.spec_from_file_location('explicitwide._native_core',next(b.glob('final_v2*.pyd')));v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
inputs=json.loads((b/'v2-boundary-inputs.json').read_text());reference=json.loads((b/'v2-boundary-results.json').read_text());ref={(x['root'],x['order']):x for x in reference['rows']if x['arm']=='shimV2'};rows=[];roots=[];errors=[];start=time.perf_counter()
def sig(d):
 d={k:v for k,v in d.items()if 'elapsed'not in k and k!='goal_checked_transitions'};d.setdefault('result_source','fallback'if d.get('used_fallback')else'main_iteration');return d
try:
 for x in inputs:
  p.rr.stopped();c,s=case(x);before=record_value(s.to_record());t=time.perf_counter();nr=nc.compile_native_semantic_rules(c,backend_module=v2);compile_seconds=time.perf_counter()-t;assert nr.backend_module is v2 and nr.report.semantic_payload_version==5
  if c.board_size>16:
   try:nc.compile_native_semantic_rules(c)
   except nc.NativeUnsupportedRuleError:pass
   else:raise AssertionError('default V1 guard silently raised')
  pos=pack_semantic_search_position(c,nr,s);check(c,s,nr,pos);acts=s.legal_actions();assert set(sem.transient_legal_actions(nr,pos))=={pack_semantic_action(nr,s.state.position,a)for a in acts};values={tid:0 if m.is_anchor else 100for tid,m in c.support.type_metadata.items()};roots.append({'root':x['name'],'n':c.board_size,'legal_count':len(acts),'compile_seconds':compile_seconds,'payload':v2.semantic_rules_info(nr.capsule),'report':record_value(nr.report),'complete_state_history_checked':True})
  for order in [0,1]:
   if time.perf_counter()-start>300:raise TimeoutError('300s explicit public backend closure fuse')
   e=SemanticSearchEngine(c,nr,board_values=values,hand_values=values,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=1,max_nodes=64,max_time_seconds=2));wall=time.perf_counter()-t;rr=record_value(r);old=ref[(x['name'],order)]['result'];difference=[k for k in sig(old)if sig(old)[k]!=sig(rr).get(k)]
   if difference:errors.append({'root':x['name'],'order':order,'different':difference,'old_reason':old['termination_reason'],'new_reason':r.termination_reason})
   rows.append({'root':x['name'],'order':order,'result':rr,'caller_seconds':wall});assert record_value(s.to_record())==before and native._MODULE is installed
  (b/'explicit-v2-results.json').write_text(json.dumps({'complete':False,'rows':rows,'roots':roots,'errors':errors,'seconds':time.perf_counter()-start}),encoding='utf-8');print(x['name'],len(rows),flush=True)
 (b/'explicit-v2-results.json').write_text(json.dumps({'complete':True,'rows':rows,'roots':roots,'errors':errors,'seconds':time.perf_counter()-start}),encoding='utf-8');assert not errors,errors
except BaseException:(b/'explicit-v2-error.log').write_text(traceback.format_exc(),encoding='utf-8');raise
# Actual high-coordinate drop/promotion terminal goals, not rawcodec-only claims.
from dataclasses import replace
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom,LeapAtom
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.terminal import terminal_result
extra=[]
for kind in ['drop','promotion']:
 rook=T('R',RayAtom((0,1)),RayAtom((0,-1)),RayAtom((1,0)),RayAtom((-1,0)));types=[king_type(),rook]
 if kind=='promotion':types.append(T('P',LeapAtom((0,1)),is_promotable=True,targets=('R',)))
 rules=make_ruleset(32,types,auto_promotion=True);board=[[None]*32for _ in range(32)];board[31][31]=Piece(1,'K','K');board[29][30]=Piece(0,'K','K')
 if kind=='promotion':board[30][0]=Piece(0,'P','P')
 rules=replace(rules,initial_position=tuple(tuple(row)for row in board));raw=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 if kind=='drop':
  position=replace(s.state.position,hands=(Hands((('R',1),)),Hands()));key=position_identity_key(position,c);state=replace(s.state,position=position,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),));s._state=replace(state,terminal_status=terminal_result(state,c));s._search_history_witnesses=(position,)
 before=record_value(s.to_record());nr=nc.compile_native_semantic_rules(c,backend_module=v2);pos=pack_semantic_search_position(c,nr,s);check(c,s,nr,pos);acts=s.legal_actions()
 candidates=[a for a in acts if(a.to_square.file,a.to_square.rank)==(0,31)and(kind=='drop'or getattr(a,'promotion_target_id',None)=='R')];assert len(candidates)==1,(kind,len(candidates));hint=candidates[0];assert apply_action(s.state,hint,c).terminal_status.winner==0
 values={z:0 if m.is_anchor else 100for z,m in c.support.type_metadata.items()};e=SemanticSearchEngine(c,nr,board_values=values,hand_values=values,tt_megabytes=1,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=4,max_nodes=128,max_time_seconds=5,quiescence_max_depth=4),root_window_pruning=True,root_order_hint=hint,stop_on_immediate_win=True);wall=time.perf_counter()-t
 assert r.immediate_win and r.completed_depth==0 and r.result_source=='verified_root_child' and r.result_ordinary_qdepth is None and r.action==hint
 child=apply_action(s.state,r.action,c);assert child.terminal_status.is_terminal and child.terminal_status.winner==0;assert record_value(s.to_record())==before and native._MODULE is installed
 extra.append({'kind':kind,'n':32,'ruleset':json.loads(__import__('generic_chess.rules.serialization',fromlist=['serialize_ruleset']).serialize_ruleset(rules)),'root_state':record_value(s.state),'result':record_value(r),'terminal':record_value(child.terminal_status),'caller_seconds':wall,'high_target':992,'full_history_verified':True});print('WIDEGOAL',kind,wall,flush=True)
(b/'explicit-v2-goals.json').write_text(json.dumps({'complete':True,'rows':extra,'scope':'2constructed32board high-square actualdrop/promotion goals, not random-domain/strength validation'}),encoding='utf-8');print('COMPLETE',len(rows),len(extra),time.perf_counter()-start,flush=True)
