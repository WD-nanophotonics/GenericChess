from pathlib import Path
exec(compile(Path('.local_agent/immediate-goal-20261015/compare.py').read_text(encoding='utf-8-sig').split('inputs=json.loads')[0],'<goal_common>','exec'))
from dataclasses import replace
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.terminal import terminal_result
import generic_chess.native.semantic_engine as engmod
spec=importlib.util.spec_from_file_location('profilewide._native_core',next(b.glob('final_v2*.pyd')));wide=importlib.util.module_from_spec(spec);spec.loader.exec_module(wide)
class Timed:
 def __init__(self,kernel):self.kernel=kernel;self.phase='compile';self.times={};self.cache={}
 def __getattr__(self,name):
  f=getattr(self.kernel,name)
  if not callable(f):return f
  if name not in self.cache:
   def run(*args):
    t=time.perf_counter()
    try:return f(*args)
    finally:
     key=self.phase+':'+name;row=self.times.setdefault(key,{'calls':0,'seconds':0.0});row['calls']+=1;row['seconds']+=time.perf_counter()-t
   self.cache[name]=run
  return self.cache[name]
rows=[];original_apply=engmod.apply_action;core_seconds=[0.0]
def timed_apply(*args,**kwargs):
 t=time.perf_counter()
 try:return original_apply(*args,**kwargs)
 finally:core_seconds[0]+=time.perf_counter()-t
engmod.apply_action=timed_apply
try:
 for x in json.loads((b/'explicit-v2-goals.json').read_text())['rows']:
  raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
  if x['kind']=='drop':
   position=replace(s.state.position,hands=(Hands((('R',1),)),Hands()));key=position_identity_key(position,c);state=replace(s.state,position=position,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),));s._state=replace(state,terminal_status=terminal_result(state,c));s._search_history_witnesses=(position,)
  assert record_value(s.state)==x['root_state'];hint,=[a for a in s.legal_actions()if record_value(a)==x['result']['action']];v={t:0 if m.is_anchor else 100for t,m in c.support.type_metadata.items()}
  for order in [0,1]:
   timer=Timed(wide);t=time.perf_counter();nr=nc.compile_native_semantic_rules(c,backend_module=timer);compile_seconds=time.perf_counter()-t;timer.phase='construct';t=time.perf_counter();e=SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);construct_seconds=time.perf_counter()-t;core_seconds[0]=0;timer.phase='search';t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=4,max_nodes=128,max_time_seconds=5,quiescence_max_depth=4),root_window_pruning=True,root_order_hint=hint,stop_on_immediate_win=True);wall=time.perf_counter()-t
   assert r.immediate_win and r.action==hint and r.result_source=='verified_root_child'and record_value(s.state)==x['root_state'];rows.append({'kind':x['kind'],'repeat':order,'compile_seconds':compile_seconds,'construct_seconds':construct_seconds,'search_caller_seconds':wall,'kernel_reported_seconds':r.elapsed_seconds,'Core_PV_replay_seconds':core_seconds[0],'C_calls':timer.times,'result':record_value(r)})
finally:engmod.apply_action=original_apply
(b/'caller-cost.json').write_text(json.dumps({'complete':True,'calls':4,'rows':rows,'scope':'Exposed two32M1 cases/two repeats. Method wrappers add small overhead, ordinary concurrent load. Attributed stages, not independent speedup or goal-general frequency evidence.'},indent=2),encoding='utf-8');print([{k:v for k,v in x.items()if k not in ['result','C_calls']}for x in rows])
