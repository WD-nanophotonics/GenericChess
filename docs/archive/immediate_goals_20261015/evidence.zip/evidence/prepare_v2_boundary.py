from pathlib import Path
import shutil,json,datetime
b=Path('.local_agent/immediate-goal-20261015');src=b/'src_normalized_v2';src.mkdir(exist_ok=True)
plan={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'question':'Is the V2 public dispatch gap fundamentally rule execution, or an explicit capacity/codec/marshalling boundary?','known':'Current V2 advertises legacy max_squares256 despite semantic1024; public compiler hardcodes payload4/<=16; raw V2 no-promotion127/dropfrom1023 conflicts with public255sentinels. Existing own backend binding already prevents global default swaps.','intervention':'Private V2 adds separate semantic capacity/encoding/public-sentinel metadata and normalizes public action dictionaries inside C pack/unpack. Exact63bit action codes/runtime/solver unchanged. No public guard/default activation.','checks':'Existing full17qualification roots plus16priced roots and2saved32roots (dedup byname/state) retain allCorelegal/action/state/history; direct normalized backend vs existing Python V2Boundary, boundedD1/q0/64nodes/2s bothorders. Rawcodec corners0/255/256/1023, base0/63,promotionnone/type63,patterns0/255,geometry0/4095; reservedbit/declaration rejected. Driver and microtimers separate from caller cost; not whole-domain/strength.'};(b/'v2-boundary-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
for p in Path('.local_agent/backend-owner-20261015/src_scoped_v2').iterdir():
 if p.suffix in ['.c','.h']:shutil.copyfile(p,src/p.name)
p=src/'native_module.c';s=p.read_text().replace('\r\n','\n')
a='    PyDict_SetItemString(dict, "semantic_payload_version", value);\n    Py_DECREF(value);';assert s.count(a)==1;s=s.replace(a,a+'''
    value = PyLong_FromLong(1024);
    PyDict_SetItemString(dict, "semantic_max_squares", value); Py_DECREF(value);
    value = PyLong_FromLong(2);
    PyDict_SetItemString(dict, "semantic_action_encoding_version", value); Py_DECREF(value);
    value = PyLong_FromLong(1);
    PyDict_SetItemString(dict, "semantic_public_action_fields_version", value); Py_DECREF(value);''',1)
a='    if (v[0] < 0 || v[0] > 1023 || v[1] < 0 || v[1] > 1023 ||';assert s.count(a)==1;s=s.replace(a,'''    /* Stable public dictionaries keep their existing255sentinels. The raw
     * V2 action/capsule remains distinct and uses its own63bit encoding. */
    if (v[2] == 255) v[2] = 127;
    if (v[4] == GC_ACTION_KIND_SEMANTIC_DROP && v[1] == 255) v[1] = 1023;
'''+a,1)
a='        "to", GC_ACTION_TO(action), "from", GC_ACTION_FROM(action),\n        "promotion", GC_ACTION_PROMO(action), "base", GC_ACTION_BASE(action),';assert s.count(a)==1;s=s.replace(a,'''        "to", GC_ACTION_TO(action), "from", kind == GC_ACTION_KIND_SEMANTIC_DROP
            ? 255ull : GC_ACTION_FROM(action),
        "promotion", GC_ACTION_PROMO(action) == 127ull ? 255ull : GC_ACTION_PROMO(action),
        "base", GC_ACTION_BASE(action),''',1);p.write_text(s,encoding='utf-8')
s=Path('.local_agent/immediate-goal-20261015/build_prefix.py').read_text(encoding='utf-8-sig').replace("src_prefix_v1","src_normalized_v2").replace("prefix_v1","normalized_v2").replace("prefix-build","normalized-build");(b/'build_normalized.py').write_text(s,encoding='utf-8')
