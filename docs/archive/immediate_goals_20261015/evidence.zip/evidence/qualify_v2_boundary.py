from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8-sig'),'<owned_common>','exec'))
b=ROOT/'.local_agent/immediate-goal-20261015'
spec=importlib.util.spec_from_file_location('normalized._native_core',next(b.glob('normalized_v2*.pyd')));normalized=importlib.util.module_from_spec(spec);spec.loader.exec_module(normalized)
spec=importlib.util.spec_from_file_location('existingv2._native_core',next((ROOT/'.local_agent/backend-owner-20261015').glob('scoped_v2*.pyd')));existing=importlib.util.module_from_spec(spec);spec.loader.exec_module(existing)
base=V2Boundary(existing);arms={'shimV2':base,'directV2':normalized};compilers={}
for name,bridge in arms.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
inputs=json.loads((ROOT/'.local_agent/wide-interface-20261015/qualification-inputs.json').read_text())['rows']+json.loads((ROOT/'.local_agent/priced-completion-20261015/inputs.json').read_text())['samples']+json.loads((ROOT/'.local_agent/backend-owner-20261015/new32-inputs.json').read_text())['samples'];seen=set();inputs=[x for x in inputs if x.get('included',True)and not(x['name']in seen or seen.add(x['name']))]
(b/'v2-boundary-inputs.json').write_text(json.dumps(inputs),encoding='utf-8')
codec=[]
for to in [0,255,256,1023]:
 for source in [0,255,256,1023]:
  for promo in [0,63,255]:
   for kind in [2,3]:
    f=dict(to=to,**{'from':source if kind==2 else 255},promotion=promo,base=63,kind=kind,pattern=255,geometry=4095,actor_current=63);a=base.semantic_action_pack(f);z=normalized.semantic_action_pack(f);assert a==z and z<(1<<63);assert normalized.semantic_action_unpack(z)==base.semantic_action_unpack(a)==f;codec.append({'fields':f,'action':z})
for raw in [1<<63,(1<<64)-1]:
 try:normalized.semantic_action_unpack(raw)
 except ValueError:pass
 else:raise AssertionError('reservedbit/declaration accepted as physical action')
rows=[];roots=[];start=time.perf_counter();caps=normalized.native_capabilities();assert caps['semantic_payload_version']==5 and caps['semantic_max_squares']==1024 and caps['max_squares']==256 and caps['semantic_action_encoding_version']==2
try:
 for x in inputs:
  p.rr.stopped();c,s=case(x);before=record_value(s.to_record());v={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()};rules={a:f(c)for a,f in compilers.items()};legals={}
  for a,nr in rules.items():
   pos=pack_semantic_search_position(c,nr,s);check(c,s,nr,pos);legals[a]=set(sem.transient_legal_actions(nr,pos));assert legals[a]=={pack_semantic_action(nr,s.state.position,z)for z in s.legal_actions()}
  assert legals['shimV2']==legals['directV2'];roots.append({'name':x['name'],'n':c.board_size,'legal':len(legals['directV2']),'full_state_history_checked':True})
  for order in [0,1]:
   for arm in (list(arms)if order==0 else list(arms)[::-1]):
    if time.perf_counter()-start>300:raise TimeoutError('300s wide boundary fuse')
    t=time.perf_counter();e=SemanticSearchEngine(c,rules[arm],board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);r=e.search(s,SearchLimits(max_depth=1,max_nodes=64,max_time_seconds=2));wall=time.perf_counter()-t;assert record_value(s.to_record())==before and native._MODULE is installed;rows.append({'root':x['name'],'order':order,'arm':arm,'caller_seconds':wall,'result':record_value(r)})
  (b/'v2-boundary-results.json').write_text(json.dumps({'complete':False,'rows':rows,'roots':roots,'codec':codec,'caps':caps,'seconds':time.perf_counter()-start}),encoding='utf-8');print(x['name'],len(rows),flush=True)
 (b/'v2-boundary-results.json').write_text(json.dumps({'complete':True,'rows':rows,'roots':roots,'codec':codec,'caps':caps,'seconds':time.perf_counter()-start}),encoding='utf-8')
except BaseException:
 (b/'v2-boundary-error.log').write_text(traceback.format_exc(),encoding='utf-8');raise
# Paid codec crossing microbenchmark is separate from actual caller timers.
timers=[];fields=codec[0]['fields'];code=codec[0]['action']
for order in [0,1]:
 for arm in (list(arms)if order==0 else list(arms)[::-1]):
  t=time.perf_counter()
  for i in range(20000):assert arms[arm].semantic_action_pack(fields)==code;arms[arm].semantic_action_unpack(code)
  timers.append({'arm':arm,'order':order,'calls':40000,'seconds':time.perf_counter()-t})
(b/'v2-boundary-codec-timers.json').write_text(json.dumps(timers),encoding='utf-8');print('COMPLETE',len(rows),len(codec),time.perf_counter()-start,flush=True)
