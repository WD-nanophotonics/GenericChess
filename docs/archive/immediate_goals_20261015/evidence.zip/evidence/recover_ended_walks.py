from pathlib import Path
exec(compile(Path('.local_agent/immediate-goal-20261015/compare.py').read_text(encoding='utf-8-sig').split('inputs=json.loads')[0],'<goal_common>','exec'))
import random
folder=b/'prefix-transfer';d=json.loads((folder/'inputs.json').read_text());available={x['name']for x in d['samples']};recovered=[]
for row in d['preparation']:
 seed=row['seed']
 if f'{seed}-ply8'in available:continue
 x=next(z for z in d['samples']if z['seed']==seed);c,s=case(x);rng=random.Random(seed+7000);walk=[]
 while s.state.ply_count<8 and s.legal_actions():
  a=rng.choice(sorted(s.legal_actions(),key=repr));s.submit(a);walk.append(record_value(a))
 assert s.state.ply_count<8 and s.result.status.value!='ongoing'
 recovered.append({'seed':seed,'stopped_ply':s.state.ply_count,'walk':walk,'terminal':record_value(s.state.terminal_status),'final_state':record_value(s.state),'new_search_calls':0,'reason':'Designated ply8root does not exist because unchanged deterministic walk already ended; no replacement/cap extension.'})
(folder/'missing-played-roots.json').write_text(json.dumps(recovered,indent=2),encoding='utf-8');print([(x['seed'],x['stopped_ply'],x['terminal'])for x in recovered])
