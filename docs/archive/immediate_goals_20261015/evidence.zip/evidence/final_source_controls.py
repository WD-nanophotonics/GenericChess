from pathlib import Path
exec(compile(Path('.local_agent/immediate-goal-20261015/prefix_pilot.py').read_text(encoding='utf-8-sig').split('\ninputs=json.loads')[0],'<prefix_common>','exec'))
spec=importlib.util.spec_from_file_location('finalcontrol._native_core',next(b.glob('final_v1*.pyd')));final=importlib.util.module_from_spec(spec);spec.loader.exec_module(final)
comp={}
for key,module in [('old',old),('timedPrefix',prefix),('final',final)]:
 ns=dict(nc.__dict__);ns.update(_module=lambda module=module:module,native_available=lambda:True);exec(inspect.getsource(nc.compile_native_semantic_rules),ns);comp[key]=ns['compile_native_semantic_rules']
inputs=json.loads((b/'inputs.json').read_text());rows=[];errors=[];start=time.perf_counter()
for study,arms,budgets,goal in [('prefix',['timedPrefix','final'],[8,32,128],True),('default',['old','final'],[64,512],False)]:
 for x in inputs['samples']:
  p.rr.stopped()
  if not x['included']:continue
  c,s=case(x);profile=p.build_ruleset_profile(c,p.EvaluationConfig());v={z:int(round(y))for z,y in profile.board_value_by_type.items()};h={z:int(round(y))for z,y in profile.hand_value_by_base_type.items()};rules={a:comp[a](c)for a in arms};before=record_value(s.to_record())
  for nodes in budgets:
   for order in [0,1]:
    pair={}
    for arm in (arms if order==0 else arms[::-1]):
     if time.perf_counter()-start>300:raise TimeoutError('300s final source fixed-control fuse')
     e=SemanticSearchEngine(c,rules[arm],board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=6,max_nodes=nodes,max_time_seconds=10,quiescence_max_depth=4),root_window_pruning=True,stop_on_immediate_win=goal);elapsed=time.perf_counter()-t;pair[arm]=signature(r);assert record_value(s.to_record())==before;rows.append({'study':study,'root':x['name'],'nodes':nodes,'order':order,'arm':arm,'result':record_value(r),'caller_seconds':elapsed})
    if pair[arms[0]]!=pair[arms[1]]:errors.append({'study':study,'root':x['name'],'nodes':nodes,'order':order,'different':[k for k in pair[arms[0]]if pair[arms[0]][k]!=pair[arms[1]].get(k)]})
  print(study,x['name'],len(rows),flush=True)
(b/'final-source-controls.json').write_text(json.dumps({'complete':True,'rows':rows,'errors':errors,'seconds':time.perf_counter()-start,'limit':'Non-time fields, existing prospective cohort; not timing-source identity or independent validation.'}),encoding='utf-8');assert not errors,errors
print('COMPLETE',len(rows),time.perf_counter()-start,flush=True)
