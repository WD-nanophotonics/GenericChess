from pathlib import Path
import shutil,subprocess,sys,sysconfig,json,time
R=Path.cwd();b=R/'.local_agent/immediate-goal-20261015';src=b/'src_old_v1';src.mkdir(exist_ok=True)
for p in (R/'generic_chess/_native').iterdir():
 if p.suffix in ['.c','.h']:shutil.copyfile(p,src/p.name)
shutil.copyfile(b/'before/generic_chess/_native/native_module.c',src/'native_module.c')
out=b/('old_v1'+sysconfig.get_config_var('EXT_SUFFIX'));cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in sorted(src.glob('*.c'))],'-o',str(out)];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=180);(b/'build-old.log').write_bytes(r.stdout+r.stderr);(b/'build-old.json').write_text(json.dumps({'exit':r.returncode,'seconds':time.perf_counter()-t}));assert r.returncode==0
