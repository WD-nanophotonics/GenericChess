from pathlib import Path
import sys,json,importlib.util,time
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];forbidden=Path(sys.argv[1]).resolve()
def audit(event,args):
 if event=='open'and isinstance(args[0],(str,bytes)):
  try:p=Path(args[0]).resolve()
  except (TypeError,OSError):return
  mode=args[1]if len(args)>1 else None;flags=args[2]if len(args)>2 else 0;reading=mode is not None and('r'in str(mode)or'+'in str(mode))or(mode is None and not flags&3)
  if reading and p.is_relative_to(forbidden)and not p.is_relative_to(R):raise AssertionError('older private input read blocked')
sys.addaudithook(audit)
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native import _module
from generic_chess.native import compiler as nc,semantic as sem
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.declarations import available_declarations
from generic_chess.ai.limits import SearchLimits
import generic_chess
assert Path(generic_chess.__file__).resolve().is_relative_to(R)
v1=_module();assert Path(v1.__file__).resolve().is_relative_to(R)
spec=importlib.util.spec_from_file_location('replaywide._native_core',next((R/'replay').glob('wide*.pyd')));v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
def case(x):
 if x.get('recipe'):
  from test_no_contest_search import defender_root
  s=defender_root();a,=[a for a in s.legal_actions()if record_value(a)==x['attack']];s.submit(a);c=s.compiled
 else:
  r=deserialize_ruleset(json.dumps(x['ruleset']))
  if r.semantic_actions:c=compile_ruleset_for_execution(r)
  else:
   raw=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
  s=GameSession(c);walk=x['walk']if x.get('walk')is not None else[record_value(a)for a in deserialize_game_record(json.dumps(x['game_record'])).actions]
  for value in walk:
   a,=[a for a in s.legal_actions()if record_value(a)==value];s.submit(a)
 assert record_value(s.state)==x['state'];return c,s
inputs=json.loads((R/'replay/v2-boundary-inputs.json').read_text());results=[];actions=0;start=time.perf_counter()
for x in inputs:
 c,s=case(x);before=record_value(s.to_record());nr=nc.compile_native_semantic_rules(c,backend_module=v2);pos=pack_semantic_search_position(c,nr,s);snap=sem.snapshot(nr,pos);expected=expected_snapshot(s.state.position,nr,c)
 for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(expected[k])
 assert sem.position_key(nr,pos)==str(position_identity_key(s.state.position,c)) and snap['history_exact'] and snap['history_events_exact']
 assert [''.join(f'{v:016x}'for v in hh)for hh in snap['history']]==[str(position_identity_key(w,c))for w in s._search_witnesses]
 legal=s.legal_actions();assert set(sem.transient_legal_actions(nr,pos))=={pack_semantic_action(nr,s.state.position,a)for a in legal};actions+=len(legal)
 values={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()};r=SemanticSearchEngine(c,nr,board_values=values,hand_values=values,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=1,max_nodes=64,max_time_seconds=2));assert ((r.action in legal) if r.action is not None else any(z.declaration_id==r.declaration_id for z in available_declarations(s.state,c))) and record_value(s.to_record())==before and _module()is v1,(x["name"],r);results.append({'root':x['name'],'depth':r.completed_depth,'score':r.score})
# Rebuild both32goal roots including the held piece; all comparison state retained.
from dataclasses import replace
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.terminal import terminal_result
goals=[]
for x in json.loads((R/'replay/explicit-v2-goals.json').read_text())['rows']:
 rules=deserialize_ruleset(json.dumps(x['ruleset']));raw=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 if x['kind']=='drop':
  position=replace(s.state.position,hands=(Hands((('R',1),)),Hands()));key=position_identity_key(position,c);state=replace(s.state,position=position,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),));s._state=replace(state,terminal_status=terminal_result(state,c));s._search_history_witnesses=(position,)
 assert record_value(s.state)==x['root_state'];a,=[a for a in s.legal_actions()if record_value(a)==x['result']['action']];nr=nc.compile_native_semantic_rules(c,backend_module=v2);v={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()};r=SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=1,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=4,max_nodes=128,max_time_seconds=5,quiescence_max_depth=4),root_window_pruning=True,root_order_hint=a,stop_on_immediate_win=True)
 assert r.immediate_win and r.completed_depth==0 and r.result_source=='verified_root_child'and r.result_ordinary_qdepth is None;ch=apply_action(s.state,r.action,c);assert ch.terminal_status.is_terminal and ch.terminal_status.winner==s.state.position.side_to_move;goals.append(x['kind'])
(R/'replay/qualification.json').write_text(json.dumps({'complete':True,'roots':len(results),'legal_actions':actions,'bounded_searches':len(results)+len(goals),'goals':goals,'no_older_private_reads':True,'no_default_switch':True,'seconds':time.perf_counter()-start,'results':results}),encoding='utf-8');print('FULLSTATE PASS',len(results),actions,goals)
