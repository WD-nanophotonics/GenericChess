import importlib.util,sys
from pathlib import Path
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'tests/product')]
import generic_chess.native as native
assert native._MODULE is None
spec=importlib.util.spec_from_file_location('finalstartup._native_core',next((root/'.local_agent/immediate-goal-20261015').glob('final_v1*.pyd')));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
# Fresh test process, before ANY native rules/position/engine capsule exists.
native._MODULE=module
import pytest
raise SystemExit(pytest.main(['-p','no:cacheprovider','--basetemp','.local_agent/immediate-goal-20261015/pytest-final-image',*sys.argv[1:]]))
