from pathlib import Path
exec(compile(Path('.local_agent/immediate-goal-20261015/compare.py').read_text(encoding='utf-8-sig').split('inputs=json.loads')[0],'<goal_common>','exec'))
inputs=json.loads((b/'inputs.json').read_text());rows=[];start=time.perf_counter()
try:
 for x in inputs['samples']:
  p.rr.stopped()
  if not x['included']:continue
  c,s=case(x);before=record_value(s.to_record());acts=s.legal_actions();wins=[];t=time.perf_counter()
  for i,a in enumerate(acts):
   if time.perf_counter()-start>120:raise TimeoutError('120s actualM1 census fuse')
   ch=apply_action(s.state,a,c)
   if ch.terminal_status.is_terminal and ch.terminal_status.winner==s.state.position.side_to_move:wins.append({'core_index':i,'action':record_value(a),'terminal':record_value(ch.terminal_status)})
  v={z:0 if m.is_anchor else 100 for z,m in c.support.type_metadata.items()};nr=nc.compile_native_semantic_rules(c);budget_rows=[]
  for nodes in [8,32,128]:
   e=SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);r=e.search(s,SearchLimits(max_depth=6,max_nodes=nodes,max_time_seconds=1,quiescence_max_depth=4),root_window_pruning=True,stop_on_immediate_win=True)
   ch=apply_action(s.state,r.action,c);win=ch.terminal_status.is_terminal and ch.terminal_status.winner==s.state.position.side_to_move;budget_rows.append({'nodes':nodes,'result':record_value(r),'chosen_actual_win':win})
  assert record_value(s.to_record())==before;rows.append({'root':x['name'],'legal_actions':len(acts),'winning_actions':wins,'seconds':time.perf_counter()-t,'budget_rows':budget_rows});(b/'root-census.json').write_text(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8');print(x['name'],len(acts),len(wins),[(z['nodes'],z['result']['completed_depth'],z['chosen_actual_win'])for z in budget_rows],flush=True)
 (b/'root-census.json').write_text(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8')
except BaseException:
 (b/'root-census-error.log').write_text(traceback.format_exc(),encoding='utf-8');raise
