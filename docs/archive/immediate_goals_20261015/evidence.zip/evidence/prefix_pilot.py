from pathlib import Path
exec(compile(Path('.local_agent/immediate-goal-20261015/compare.py').read_text(encoding='utf-8-sig').split('inputs=json.loads')[0],'<goal_common>','exec'))
from generic_chess.ai.cancellation import CancellationToken
spec=importlib.util.spec_from_file_location('goalprefix._native_core',next(b.glob('prefix_v1*.pyd')));prefix=importlib.util.module_from_spec(spec);spec.loader.exec_module(prefix)
class Capture:
 def __init__(self,kernel):self.kernel=kernel
 def __getattr__(self,name):return getattr(self.kernel,name)
 def semantic_engine_search(self,*args):self.raw=dict(self.kernel.semantic_engine_search(*args));return self.raw
bridges={'completedD1':Capture(new),'prefix':Capture(prefix)};compilers={}
for name,bridge in bridges.items():
 ns=dict(nc.__dict__);ns.update(_module=lambda bridge=bridge:bridge,native_available=lambda:True);exec(inspect.getsource(nc.compile_native_semantic_rules),ns);compilers[name]=ns['compile_native_semantic_rules']
inputs=json.loads((b/'inputs.json').read_text());rows=[];start=time.perf_counter()
def save(done=False,error=None):(b/'prefix-pilot-results.json').write_text(json.dumps({'complete':done,'rows':rows,'seconds':time.perf_counter()-start,'error':error}),encoding='utf-8')
try:
 for x in inputs['samples']:
  if not x['included']:continue
  c,s=case(x);before=record_value(s.to_record());v={z:0 if m.is_anchor else 100for z,m in c.support.type_metadata.items()};rules={a:f(c)for a,f in compilers.items()}
  for nodes in [8,32,128]:
   for order in [0,1]:
    for arm in (list(bridges)if order==0 else list(bridges)[::-1]):
     p.rr.stopped()
     if time.perf_counter()-start>300:raise TimeoutError('300s pilot fuse')
     e=SemanticSearchEngine(c,rules[arm],board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=6,max_nodes=nodes,max_time_seconds=1,quiescence_max_depth=4),root_window_pruning=True,stop_on_immediate_win=True);seconds=time.perf_counter()-t;raw=bridges[arm].raw;child=apply_action(s.state,r.action,c);win=child.terminal_status.is_terminal and child.terminal_status.winner==s.state.position.side_to_move
     if r.immediate_win:
      assert win
      if arm=='prefix':assert r.completed_depth==0 and r.result_ordinary_qdepth is None and raw['result_source']=='verified_root_child' and not r.used_fallback
      else:assert r.completed_depth==1
     rows.append({'root':x['name'],'nodes':nodes,'order':order,'arm':arm,'result':record_value(r),'source':raw.get('result_source','main_iteration'if not r.used_fallback else'fallback'),'actual_winning_child':win,'caller_seconds':seconds});assert record_value(s.to_record())==before and _module()is new;save()
  print(x['name'],len(rows),flush=True)
 save(True)
except BaseException:save(False,traceback.format_exc());raise
print('COMPLETE',len(rows),time.perf_counter()-start)
