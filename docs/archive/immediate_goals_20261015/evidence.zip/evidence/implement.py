from pathlib import Path
import shutil
R=Path.cwd();b=R/'.local_agent/immediate-goal-20261015'
def edit(rel,fn):
 p=R/rel;raw=p.read_bytes();dest=b/'before'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);s=raw.decode('utf-8');s=fn(s.replace('\r\n','\n'));p.write_bytes(s.replace('\n','\r\n' if b'\r\n'in raw else '\n').encode('utf-8'))
def once(s,a,c):assert s.count(a)==1,(a,s.count(a));return s.replace(a,c,1)
def cedit(s):
 s=once(s,'    PyDict_SetItemString(dict, "semantic_exact_root_windows", value);','    PyDict_SetItemString(dict, "semantic_exact_root_windows", value);\n    PyDict_SetItemString(dict, "semantic_immediate_win_goal", value);')
 # The internal iterative parser appends one optional bool; existing positions stay fixed.
 s=once(s,'    PyObject *root_window_pruning_obj = Py_False;','    PyObject *root_window_pruning_obj = Py_False;\n    PyObject *stop_on_immediate_win_obj = Py_False;')
 s=once(s,'"OOI|OOOOOOOOOIIOIOOOOOOOOIiiOOIIO"','"OOI|OOOOOOOOOIIOIOOOOOOOOIiiOOIIOO"')
 s=once(s,'                          &qmax_nodes_obj)) return NULL;','                          &qmax_nodes_obj, &stop_on_immediate_win_obj)) return NULL;')
 s=once(s,'    if (!PyBool_Check(trace_enabled_obj)) {','    if (!PyBool_Check(stop_on_immediate_win_obj)) {\n        PyErr_SetString(PyExc_TypeError, "semantic stop_on_immediate_win must be a bool");\n        return NULL;\n    }\n    if (!PyBool_Check(trace_enabled_obj)) {')
 s=once(s,'    int used_fallback = 0;\n    uint64_t start_ns = gc_monotonic_ns();','    int used_fallback = 0;\n    int immediate_win = 0;\n    uint64_t goal_checked_transitions = 0;\n    uint64_t start_ns = gc_monotonic_ns();')
 a='''        memcpy(completed_pv, ctx.pv_table,
               sizeof(uint64_t) * completed_len);
    }
    if (!completed_iteration)'''
 c='''        memcpy(completed_pv, ctx.pv_table,
               sizeof(uint64_t) * completed_len);
        /* Decision goal only: a mate-valued scalar triggers physical checking,
         * never substitutes for the full child terminal/winner. A declaration
         * is a different decision and retains the ordinary analysis path.
         * Node values/TT semantics are unchanged; only the caller stop differs. */
        if (stop_on_immediate_win_obj == Py_True && depth == 1 &&
            completed_has_action &&
            !gc_semantic_is_declaration_action(completed_action) &&
            completed_score == gc_semantic_iterative_terminal_score(
                ctx.stack[0].side_to_move, ctx.stack[0].side_to_move,
                ctx.root_ply_offset + 1)) {
            if (!gc_semantic_iterative_check_budget(&ctx, 1)) break;
            goal_checked_transitions++;
            int made_goal = gc_semantic_runtime_make_checked_status(
                &ctx.stack[1], ctx.rules, &ctx.stack[0], completed_action);
            if (made_goal < 0) { ctx.control = 4; break; }
            int goal_winner = -1;
            int goal_terminal = made_goal > 0 ? gc_semantic_terminal_status_known(
                ctx.rules, &ctx.stack[1], &goal_winner, NULL) : 0;
            if (goal_terminal < 0) { ctx.control = 4; break; }
            if (!gc_semantic_iterative_check_budget(&ctx, 1)) break;
            if (goal_terminal && goal_winner == ctx.stack[0].side_to_move) {
                immediate_win = 1;
                break;
            }
        }
    }
    if (!completed_iteration)'''
 s=once(s,a,c)
 s=once(s,'    const char *reason = "completed";\n    if (ctx.control == 1)','    const char *reason = immediate_win ? "root_immediate_win" : "completed";\n    if (ctx.control == 1)')
 s=once(s,'        PyDict_SetItemString(out, "ordering_max_ply", ordering_max_ply_obj) != 0 ||','        gc_semantic_set_u64(out, "immediate_win", immediate_win) != 0 ||\n        gc_semantic_set_u64(out, "goal_checked_transitions", goal_checked_transitions) != 0 ||\n        PyDict_SetItemString(out, "ordering_max_ply", ordering_max_ply_obj) != 0 ||')
 s=once(s,'    PyObject *root_window_pruning = Py_False;','    PyObject *root_window_pruning = Py_False;\n    PyObject *stop_on_immediate_win = Py_False;')
 s=once(s,'"OOI|OOOOOOIIO"','"OOI|OOOOOOIIOO"')
 s=once(s,'                          &trace_enabled, &qdepth, &qhard_depth, &qmax_nodes)) return NULL;','                          &trace_enabled, &qdepth, &qhard_depth, &qmax_nodes,\n                          &stop_on_immediate_win)) return NULL;')
 s=once(s,'    PyObject *call_args = PyTuple_New(32);','    PyObject *call_args = PyTuple_New(33);')
 s=once(s,'    Py_INCREF(qmax_nodes); PyTuple_SET_ITEM(call_args, 31, qmax_nodes);','    Py_INCREF(qmax_nodes); PyTuple_SET_ITEM(call_args, 31, qmax_nodes);\n    Py_INCREF(stop_on_immediate_win); PyTuple_SET_ITEM(call_args, 32, stop_on_immediate_win);')
 s=s.replace('q_hard_depth, q_nodes]) -> result','q_hard_depth, q_nodes, stop_on_immediate_win]) -> result')
 return s
edit('generic_chess/_native/native_module.c',cedit)
def semedit(s):
 marker='\ndef semantic_iterative_search(\n'
 helper='''
def _require_immediate_win_support(enabled: bool, native_rules) -> None:
    if not isinstance(enabled, bool):
        raise TypeError("stop_on_immediate_win must be a bool")
    if enabled and not _backend(native_rules).native_capabilities().get(
        "semantic_immediate_win_goal", False
    ):
        from .compiler import NativeUnsupportedRuleError
        raise NativeUnsupportedRuleError(
            "Native immediate-win decision goal requires a rebuilt kernel"
        )

'''
 s=once(s,marker,helper+marker)
 s=once(s,'    root_window_pruning: bool = False,\n) -> dict:','    root_window_pruning: bool = False,\n    stop_on_immediate_win: bool = False,\n) -> dict:')
 s=once(s,'    _require_root_window_support(root_window_pruning, native_rules)','    _require_root_window_support(root_window_pruning, native_rules)\n    _require_immediate_win_support(stop_on_immediate_win, native_rules)')
 s=once(s,'    flag = None\n    unregister = None\n    if cancel_token is not None:', '    goal_args = ((None,) * 6 + (1, -1, 1, None, False, 0, 0, None, True)\n                 if stop_on_immediate_win else ())\n    flag = None\n    unregister = None\n    if cancel_token is not None:')
 s=once(s,'            root_window_pruning,\n        ))','            root_window_pruning,\n            *goal_args,\n        ))')
 s=once(s,'    raw["used_fallback"] = bool(raw.get("used_fallback", False))','    raw["immediate_win"] = bool(raw.get("immediate_win", False))\n    raw["goal_checked_transitions"] = int(raw.get("goal_checked_transitions", 0))\n    raw["used_fallback"] = bool(raw.get("used_fallback", False))')
 return s
edit('generic_chess/native/semantic.py',semedit)
def engedit(s):
 s=once(s,'from .semantic import public_action, _require_root_window_support','from .semantic import (public_action, _require_root_window_support,\n                       _require_immediate_win_support)')
 s=once(s,'    root_window_pruning: bool = False\n','    root_window_pruning: bool = False\n    immediate_win: bool = False\n    goal_checked_transitions: int = 0\n')
 s=once(s,'        trace_enabled: bool = False,\n    ) -> SemanticIterativeSearchResult:','        trace_enabled: bool = False,\n        stop_on_immediate_win: bool = False,\n    ) -> SemanticIterativeSearchResult:')
 s=once(s,'        _require_root_window_support(root_window_pruning, self._native_rules)','        _require_root_window_support(root_window_pruning, self._native_rules)\n        _require_immediate_win_support(stop_on_immediate_win, self._native_rules)\n        goal_args = ()\n        if stop_on_immediate_win:\n            # Supply existing optional q slots before the appended goal flag.\n            q_args = q_args or (0, 0, None)\n            goal_args = (True,)')
 s=once(s,'                *q_args,\n            ))','                *q_args,\n                *goal_args,\n            ))')
 s=once(s,'            root_window_pruning=bool(raw.get("root_window_pruning", False)),','            root_window_pruning=bool(raw.get("root_window_pruning", False)),\n            immediate_win=bool(raw.get("immediate_win", False)),\n            goal_checked_transitions=int(raw.get("goal_checked_transitions", 0)),')
 s=once(s,'        from requested limits; a hard/q-node abort keeps the last full result.','        from requested limits; a hard/q-node abort keeps the last full result.\n\n        stop_on_immediate_win explicitly opts into a decision goal: after D1,\n        a checked child that actually wins may end the call. The retained D1/q0\n        policy is reported honestly. False retains finite-analysis behavior;\n        a score or declaration alone never certifies a physical winning child.')
 return s
edit('generic_chess/native/semantic_engine.py',engedit)
