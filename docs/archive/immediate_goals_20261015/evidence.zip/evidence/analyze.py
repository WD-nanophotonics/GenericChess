from pathlib import Path
import json,collections,math,xml.etree.ElementTree as E
b=Path('.local_agent/immediate-goal-20261015')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def gm(v):return math.exp(sum(math.log(x)for x in v)/len(v))if v else None
out={}
for folder,studies in [(b,['fixed','resource','tt']),(b/'prefix-transfer',['resource','tt'])]:
 for name in studies:
  d=load(folder/(name+'-results.json'));assert d['complete']and not d.get('error');groups=collections.defaultdict(dict)
  for r in d['rows']:groups[(r['root'],r.get('budget',r.get('seconds')),r['order'],r['temperature'])][r['arm']]=r
  arms=['oldanalysis','newanalysis']if name=='fixed'else(['analysis','goal']if folder==b else['completedD1','prefix']);pairs=[];counts=collections.Counter()
  for key,g in groups.items():
   a,z=[g[k]for k in arms];ra,rz=a['result'],z['result'];wa,wz=a['physical_winning_child'],z['physical_winning_child'];policy=lambda r:(r['completed_depth'],r.get('result_ordinary_qdepth'),r.get('result_check_hard_qdepth'));same=policy(ra)==policy(rz)and ra['completed_depth']>0
   for label,condition in [('actual_M1_gain',wz and not wa),('actual_M1_loss',wa and not wz),('both_actual_M1',wa and wz),('neither_actual_M1',not wa and not wz),('same_action',ra['action']==rz['action']),('same_policy',same),('same_policy_score_error',same and ra['score']!=rz['score']),('baseline_certified',ra['immediate_win']),('candidate_certified',rz['immediate_win'])]:counts[label]+=int(condition)
   pairs.append({'root':key[0],'budget':key[1],'order':key[2],'temperature':key[3],'baseline_physical_M1':wa,'candidate_physical_M1':wz,'baseline_certified':ra['immediate_win'],'candidate_certified':rz['immediate_win'],'baseline_policy':policy(ra),'candidate_policy':policy(rz),'baseline_reason':ra['termination_reason'],'candidate_reason':rz['termination_reason'],'baseline_caller':a['caller_seconds'],'candidate_caller':z['caller_seconds'],'same_policy':same,'same_action':ra['action']==rz['action'],'candidate_score':rz['score']})
  both=[x for x in pairs if x['baseline_physical_M1']and x['candidate_physical_M1']];proven=[x for x in pairs if x['candidate_certified']]
  key=('initial_'if folder==b else'prospective_prefix_')+name
  out[key]={'complete':True,'calls':len(d['rows']),'pairs':len(pairs),'arms':arms,'seconds':d['seconds'],'counts':dict(counts),'baseline_actual_q4':sum(r['result'].get('result_ordinary_qdepth')==4for r in d['rows']if r['arm']==arms[0]),'candidate_actual_q4':sum(r['result'].get('result_ordinary_qdepth')==4for r in d['rows']if r['arm']==arms[1]),'both_M1_caller_gmean_ratio':gm([x['candidate_caller']/x['baseline_caller']for x in both]),'both_M1_saved_caller_seconds':sum(x['baseline_caller']-x['candidate_caller']for x in both),'candidate_certified_caller_range':[min(x['candidate_caller']for x in proven),max(x['candidate_caller']for x in proven)]if proven else None,'pairs_detail':pairs}
  assert not counts['same_policy_score_error'],key
  print(key,json.dumps({k:v for k,v in out[key].items()if k!='pairs_detail'}))
for title,folder in [('initial_inputs',b),('prefix_inputs',b/'prefix-transfer')]:
 d=load(folder/'inputs.json');out[title]={'families':len(d['preparation']),'preparation_statuses':dict(collections.Counter(x['status']for x in d['preparation'])),'saved_roots':len(d['samples']),'searchable_roots':sum(x['included']for x in d['samples']),'excluded':[{'name':x['name'],'terminal':x['state'].get('terminal_status'),'legal_count':x['legal_count']}for x in d['samples']if not x['included']],'preparation_seconds':d['seconds']};print(title,json.dumps(out[title]))
for name in ['full-tests','final-image-full-tests']:
 root=E.parse(b/(name+'.xml')).getroot().find('testsuite');out[name]={k:v for k,v in root.attrib.items()if k in ['tests','errors','failures','skipped','time']}
checks=load(b/'final-source-controls.json');out['final_source_controls']={'calls':len(checks['rows']),'errors':checks['errors'],'per_study_calls':dict(collections.Counter(x['study']for x in checks['rows'])),'seconds':checks['seconds']};assert not checks['errors']
d=load(b/'explicit-v2-results.json');out['explicit_v2']={'calls':len(d['rows']),'roots':len(d['roots']),'legal_actions':sum(x['legal_count']for x in d['roots']),'errors':d['errors'],'seconds':d['seconds']};assert not d['errors'];out['explicit_v2_goals']=load(b/'explicit-v2-goals.json')
# The prequalification ordered shim then direct, so small per-query timers are biased.
d=load(b/'v2-boundary-results.json');groups=collections.defaultdict(dict)
for x in d['rows']:groups[(x['root'],x['order'])][x['arm']]=x
out['v2_timing_correction']={'caller_ratio_by_order':{order:gm([x['directV2']['caller_seconds']/x['shimV2']['caller_seconds']for(k,j),x in groups.items()if j==order])for order in [0,1]},'reason':'Prequalification always ran direct backend last. Order interaction .407 versus .992 invalidates aggregate .635 speedup interpretation. No adoption/performance claim from this timing; use exact work/transport closure.'}
(b/'summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
