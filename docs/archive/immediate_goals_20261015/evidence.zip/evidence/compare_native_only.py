from pathlib import Path
exec(compile(Path('.local_agent/immediate-goal-20261015/compare.py').read_text(encoding='utf-8-sig').split('inputs=json.loads')[0],'<control_common>','exec'))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.declarations import available_declarations
import generic_chess.native.semantic_engine as em
source=Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8-sig');exec(source[source.index('def case('):source.index('\ndef check(')],globals())
space=dict(em.__dict__);exec(compile((b/'native_only_search.py').read_text(),'<native_only_search>','exec'),space)
class NativeOnly(SemanticSearchEngine):search=space['search']
spec=importlib.util.spec_from_file_location('nativeonlywide._native_core',next(b.glob('final_v2*.pyd')));v2=importlib.util.module_from_spec(spec);spec.loader.exec_module(v2)
def validate(r,s,nr):
 state=s.state;pos=pack_semantic_search_position(s.compiled,nr,s)
 for a in r.decision_line:
  if isinstance(a,str):assert any(z.declaration_id==a for z in available_declarations(state,s.compiled));break
  code=pack_semantic_action(nr,state.position,a);pos=sem.make_checked(nr,pos,code);state=apply_action(state,a,s.compiled);snap=sem.snapshot(nr,pos);exp=expected_snapshot(state.position,nr,s.compiled)
  for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(exp[k])
  assert sem.position_key(nr,pos)==str(position_identity_key(state.position,s.compiled)) and snap['history_exact']and snap['history_events_exact']
 if r.immediate_win:assert state.terminal_status.is_terminal and state.terminal_status.winner==s.state.position.side_to_move
rows=[];errors=[];warm=0;start=time.perf_counter();classes={'CorePlusNative':SemanticSearchEngine,'NativeOnly':NativeOnly}
for index,x in enumerate(json.loads((b/'v2-boundary-inputs.json').read_text())):
 p.rr.stopped();c,s=case(x);before=record_value(s.to_record());nr=nc.compile_native_semantic_rules(c,backend_module=v2);v={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()};lim=SearchLimits(max_depth=1,max_nodes=64,max_time_seconds=2)
 for arm in (list(classes)if index%2==0 else list(classes)[::-1]):
  e=classes[arm](c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);e.search(s,lim);warm+=1
 for order in [0,1]:
  pair={}
  for arm in (list(classes)if order==0 else list(classes)[::-1]):
   if time.perf_counter()-start>300:raise TimeoutError('300s native-only caller control fuse')
   t=time.perf_counter();e=classes[arm](c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);construction=time.perf_counter()-t;t=time.perf_counter();r=e.search(s,lim);wall=time.perf_counter()-t;validate(r,s,nr);assert record_value(s.to_record())==before and _module()is new;pair[arm]=signature(r);rows.append({'root':x['name'],'order':order,'arm':arm,'construct_seconds':construction,'caller_seconds':wall,'result':record_value(r)})
  if pair['CorePlusNative']!=pair['NativeOnly']:errors.append({'root':x['name'],'order':order,'different':[k for k in pair['CorePlusNative']if pair['CorePlusNative'][k]!=pair['NativeOnly'].get(k)]})
 (b/'native-only-results.json').write_text(json.dumps({'complete':False,'rows':rows,'errors':errors,'warm_calls':warm,'seconds':time.perf_counter()-start}),encoding='utf-8');print(x['name'],len(rows),flush=True)
(b/'native-only-results.json').write_text(json.dumps({'complete':True,'rows':rows,'errors':errors,'warm_calls':warm,'seconds':time.perf_counter()-start,'product_changed':False,'postcall_fullCore_and_Native_PV_state_history_validation':True}),encoding='utf-8');assert not errors,errors;print('COMPLETE',len(rows),warm,time.perf_counter()-start)
