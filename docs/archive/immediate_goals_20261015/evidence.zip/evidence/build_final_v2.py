from pathlib import Path
import subprocess,json,shutil,sys,sysconfig,time
b=Path('.local_agent/immediate-goal-20261015');d=b/'wide-merge';d.mkdir(exist_ok=True)
files={'base':b/'before/generic_chess/_native/native_module.c','goal':Path('generic_chess/_native/native_module.c'),'wide':b/'src_normalized_v2/native_module.c'}
for name,p in files.items():(d/(name+'.c')).write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
r=subprocess.run(['git','merge-file','-p',str(d/'goal.c'),str(d/'base.c'),str(d/'wide.c')],capture_output=True);(d/'merge-output.c').write_bytes(r.stdout);(d/'merge-stderr.log').write_bytes(r.stderr);(d/'merge.json').write_text(json.dumps({'exit':r.returncode,'source_goal':'finalprefix','source_wide':'normalized V2, full6filecapacity source','base':'pinned90c335 native_module.c before edits','no_product_wide_activation':True}),encoding='utf-8');assert r.returncode==0,'mechanical merge conflict preserved'
src=b/'src_final_v2';src.mkdir(exist_ok=True)
for p in (b/'src_normalized_v2').iterdir():
 if p.suffix in ['.c','.h']:shutil.copyfile(p,src/p.name)
shutil.copyfile(d/'merge-output.c',src/'native_module.c')
out=b/('final_v2'+sysconfig.get_config_var('EXT_SUFFIX'));cmd=[str(Path('.venv/Lib/site-packages/ziglang/zig.exe').resolve()),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src.resolve()),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p.resolve())for p in sorted(src.glob('*.c'))],'-o',str(out.resolve())];start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=180);(b/'final-v2-build.log').write_bytes(r.stdout+r.stderr);(b/'final-v2-build.json').write_text(json.dumps({'exit':r.returncode,'seconds':time.perf_counter()-start}),encoding='utf-8');assert r.returncode==0
