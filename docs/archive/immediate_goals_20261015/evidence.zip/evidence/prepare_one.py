from pathlib import Path
import sys,json,random,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.session.session import GameSession
b=ROOT/'.local_agent/immediate-goal-20261015';seed=int(sys.argv[1]);n=int(sys.argv[2]);start=time.perf_counter()
game=generate_game(GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));raw=p.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c);rng=random.Random(seed+7000);walk=[];samples=[]
for ply in range(9):
 acts=tuple(s.legal_actions())
 if ply in [0,8]:
  samples.append({'name':f'{seed}-ply{ply}','seed':seed,'n':n,'ruleset':json.loads(serialize_ruleset(game.ruleset)),'walk':walk.copy(),'state':record_value(s.state),'record':record_value(s.to_record()),'included':bool(acts),'legal_count':len(acts),'generation_attempts':game.generation_report.generation_attempts});(b/f'input-{seed}.json').write_bytes((json.dumps({'samples':samples,'seconds':time.perf_counter()-start})+'\n').encode())
 if ply==8 or not acts:break
 a=rng.choice(sorted(acts,key=repr));s.submit(a);walk.append(record_value(a))
print(seed,'roots',len(samples),'seconds',time.perf_counter()-start,flush=True)
