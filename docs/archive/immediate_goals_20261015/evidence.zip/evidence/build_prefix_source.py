from pathlib import Path
import json,datetime,shutil
b=Path('.local_agent/immediate-goal-20261015');d={'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changed_premise':'Census finds two genuine fresh M1roots, but the complete-D1 goal returns a nonwinning fallback at8/32nodes. A completed physical root child can certify a winning decision before the entire finite iteration completes.','question':'Can a private prefix variant retain an actual terminal winning child under the SAME8/32/128node budgets without falsely claiming D1/q4 completion?','conditions':'All12original fresh roots, both image orders,8/32/128nodes; True both; rootwindowTrue,TT0,q4hard8,depth6,1s fuse,300s total. Also canceled0nodes/0depth deterministic guards. Candidate must return actual public winningchild, completed_depth0/resultqNone for prefix, explicit result_source verified_root_child; budget/cancel reasons preserved. No auxiliary generic prover/cursor.','decision':'Only further adoption if physical winner/state/history/stop metadata verified; baseline cap failures remain, exposed development, no holdout claim.'};(b/'prefix-plan.json').write_text(json.dumps(d,indent=2),encoding='utf-8')
src=b/'src_prefix_v1';src.mkdir(exist_ok=True)
for p in Path('generic_chess/_native').iterdir():
 if p.suffix in ['.c','.h']:shutil.copyfile(p,src/p.name)
p=src/'native_module.c';s=p.read_text(encoding='utf-8').replace('\r\n','\n')
def once(a,c):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,c,1)
once('    int root_window_pruning;','    int root_window_pruning;\n    int goal_prefix_enabled;\n    int goal_prefix_win;\n    uint64_t goal_prefix_action;\n    int goal_prefix_score;')
once('    ctx.root_window_pruning = root_window_pruning_obj == Py_True;','    ctx.root_window_pruning = root_window_pruning_obj == Py_True;\n    ctx.goal_prefix_enabled = stop_on_immediate_win_obj == Py_True;')
once('''    if (terminal != 0) {
        int score = gc_semantic_iterative_terminal_score(''','''    if (terminal != 0) {
        if (ctx->goal_prefix_enabled && ply == 1 && depth == 0 &&
            winner == ctx->stack[0].side_to_move) ctx->goal_prefix_win = 1;
        int score = gc_semantic_iterative_terminal_score(''')
# Root decision returns before canonical tie refinement or root TT/PV claims.
once('''        int score = -branch;
        /* A later narrowed root child''','''        int score = -branch;
        if (ply == 0 && ctx->goal_prefix_win) {
            ctx->goal_prefix_action = action;
            ctx->goal_prefix_score = score;
            gc_semantic_action_buffer_free(&actions);
            return score;
        }
        /* A later narrowed root child''')
once('''        if (ctx.control != 0) break;
        completed_score = score;''','''        if (ctx.goal_prefix_win) {
            completed_score = ctx.goal_prefix_score;
            completed_has_action = 1;
            completed_action = ctx.goal_prefix_action;
            completed_len = 1;
            completed_pv[0] = completed_action;
            immediate_win = 1;
            /* A real proof remains delivered at a coincident stop boundary;
             * report that stop, rather than inventing a completed iteration. */
            gc_semantic_iterative_check_budget(&ctx, 1);
            break;
        }
        if (ctx.control != 0) break;
        completed_score = score;''')
once('    if (!completed_iteration) {','    if (!completed_iteration && !immediate_win) {')
once('        gc_semantic_set_u64(out, "immediate_win", immediate_win) != 0 ||','        PyDict_SetItemString(out, "result_source", ctx.goal_prefix_win ?\n            PyUnicode_FromString("verified_root_child") : PyUnicode_FromString("main_iteration")) != 0 ||\n        gc_semantic_set_u64(out, "immediate_win", immediate_win) != 0 ||')
# Avoid temporary PyUnicode ownership/leak: add a dedicated owned value below.
s=s.replace('''        PyDict_SetItemString(out, "result_source", ctx.goal_prefix_win ?
            PyUnicode_FromString("verified_root_child") : PyUnicode_FromString("main_iteration")) != 0 ||
''','')
# Existing Python wrapper ignores unknown raw fields; the driver records raw source via capture.
s=s.replace('"termination_reason", reason,','"termination_reason", reason,',1)
p.write_text(s,encoding='utf-8')
