"""Prospective generated-rule auxiliary consumer; finite scope, no learner."""
from pathlib import Path
from dataclasses import replace,asdict
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.rules.schema import (RuleSemanticAction,RuleGeometrySpec,RuleAuxState,RuleSlotGuard,RuleActionEffect,RuleSquareRef,RuleTypeRef,RuleInvariant,ruleset_to_dict)
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter()-(time.time()-(D/'plan.json').stat().st_mtime);deadline=start+P['global_seconds'];stoproot=Path.cwd()
class Stop:
 def __init__(self):self.next=0;self.stopped=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in ('rollout','advisor','slack'):
    f=json.loads((stoproot/'.local_agent'/(n+'.json')).read_bytes());self.stopped|=bool(f.get('stopped')or f.get('user_paused'))
  return self.stopped or now>=deadline
stop=Stop()
def poll():
 if stop.is_cancelled():raise TimeoutError('STOP_OR_GLOBAL_CAP')
 if sum(f.stat().st_size for f in D.iterdir()if f.is_file())>P['max_output_bytes']:raise TimeoutError('OUTPUT_CAP')
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def ref(k,**kw):return RuleSquareRef(k,**kw)
def compose(rule,variant):
 tids=tuple(t.type_id for t in rule.piece_types if not t.is_anchor)
 target=sorted(t.type_id for t in rule.piece_types if not t.is_anchor and not t.is_promotable)[0]
 persistent=variant=='persistent_per_owner'
 slot=RuleAuxState('burst_right','bool','per_owner'if persistent else'global','persistent'if persistent else'expire_next_turn',1 if persistent else 0)
 action=RuleSemanticAction(name='aux_gated_type_shift',type_ids=tids,geometry=RuleGeometrySpec(kind='leap',offset=(0,1),owner_relative=True),target_relation='empty',composition='augment',slot_guards=(RuleSlotGuard('burst_right',value=1 if persistent else 0),),aux_state=(slot,),effects=(RuleActionEffect('move',from_ref=ref('source'),to_ref=ref('target')),RuleActionEffect('set_current_type',square_ref=ref('target'),type_ref=RuleTypeRef('explicit',target)),RuleActionEffect('set_bool',slot_name='burst_right',value=0 if persistent else 1)),invariants=(RuleInvariant('own_anchor_safe'),))
 return replace(rule,semantic_actions=(action,),metadata={**rule.metadata,'research_composition':variant}),target
class Material:
 def __init__(self,b,h):self.b=b;self.h=h
 def evaluate(self,s):
  v=sum((1 if p.owner==0 else-1)*self.b[p.current_type_id]for p in s.position.board if p)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items())
  assert abs(v)<10000000
  return v*(1 if s.position.side_to_move==0 else-1)
counts=dict(generated_base=0,composed=0,Native_calls=0,Core_calls=0,Native_main=0,Native_q=0,Core_main=0,Core_q=0,PV_edges=0,physical_continuations=0)
rules=[];roots=[];comp={};natives={};mode_results=[];references=[];status='COMPLETE';error=None
write_json(D/'continuation-source.json',dict(producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),clock='Onecontinuousperf_counter clock includes generation, compilation, actualprefixes, searches and writing.'))
try:
 saved=json.loads((D/'inputs.json').read_bytes());rules=saved['rules'];roots=saved['roots']
 from generic_chess.rules.schema import ruleset_from_dict
 counts['generated_base']=len({(r['seed'],r['n'])for r in rules});counts['physical_continuations']=32
 for row in rules:
  poll();c=compile_semantic_ruleset(ruleset_from_dict(row['rule']));comp[row['name']]=c;counts['composed']+=1
  if row['status']=='SUPPORTED':natives[row['name']]=compile_native_semantic_rules(c)
 assert len(roots)<=P['max_roots']
 with(D/'native.jsonl').open('x',encoding='utf8',newline='\n')as nq,(D/'core.jsonl').open('x',encoding='utf8',newline='\n')as cq:
  for p in roots:
   poll();row=next(r for r in rules if r.get('name')==p['name']);c=comp[p['name']];s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));assert digest(s.state)==p['state_sha256']and digest(s._search_witnesses)==p['witness_sha256'];before=(s.state,s.to_record(),s.history,s._search_witnesses);actual=[]
   if not s.state.terminal_status.is_terminal and p['name']in natives:
    for req in P['native']:
     for mode in P['native_modes']:
      poll();assert counts['Native_calls']<P['max_native_queries'];e=SemanticSearchEngine(c,natives[p['name']],board_values=row['board_values'],hand_values=row['hand_values'],tt_megabytes=0);tick=time.perf_counter();z=e.search(s,SearchLimits(max_depth=req['depth'],max_nodes=req['nodes'],max_time_seconds=min(req['seconds'],max(.001,deadline-time.perf_counter())),quiescence_max_depth=req['q']),None,root_window_pruning=mode);elapsed=time.perf_counter()-tick
      rr=dict(name=p['name'],phase=p['phase'],request=req,mode=mode,result=record_value(z),seconds=elapsed,parent_sha256=p['state_sha256']);assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
      leaf=GameSession.replay(c,s.to_record())
      for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['PV_edges']+=1
      rr['leaf_state_sha256']=digest(leaf.state);rr['leaf_aux_state']=record_value(leaf.state.position.aux_state);rr['special_PV_actions']=sum(getattr(a,'pattern_id',None)in row['special_pattern_ids']for a in z.decision_line);nq.write(json.dumps(rr,separators=(',',':'))+'\n');nq.flush();actual.append(rr);counts['Native_calls']+=1;counts['Native_main']+=z.nodes;counts['Native_q']+=z.qnodes;del e
   poll()
   if not s.state.terminal_status.is_terminal:
    assert counts['Core_calls']<P['max_Core_calls'];st=SearchStatistics();tick=time.perf_counter();a,score,pv,cause=run_root_search(s.state,c,Material(row['board_values'],row['hand_values']),TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(30,max(.001,deadline-time.perf_counter())),quiescence_max_depth=4),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
    rr=dict(name=p['name'],phase=p['phase'],score=score,action=record_value(a),pv=record_value(pv),cause=cause,statistics=record_value(st),seconds=time.perf_counter()-tick,complete=st.completed_depth==2 and st.result_ordinary_qdepth==4)
    cq.write(json.dumps(rr,separators=(',',':'))+'\n');cq.flush();counts['Core_calls']+=1;counts['Core_main']+=st.nodes;counts['Core_q']+=st.qnodes;assert before==(s.state,s.to_record(),s.history,s._search_witnesses);references.append(rr)
    mapped=score-900000000 if score>=900000000 else score+900000000 if score<=-900000000 else score
    for rrn in actual:
     z=rrn['result'];comparable=rr['complete']and z['completed_depth']==2 and z['result_ordinary_qdepth']==4
     mode_results.append(dict(name=p['name'],phase=p['phase'],request=rrn['request']['label'],mode=rrn['mode'],comparable=comparable,score_equal=z['score']==mapped if comparable else None,action_equal=z['action']==rr['action']if comparable else None))
   print('AUX_GENERATED_ROOT',p['name'],p['phase'],counts['Native_calls'],counts['Core_calls'],round(time.perf_counter()-start,3),flush=True)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,counts=counts,seconds=time.perf_counter()-start,comparisons=mode_results,scope='Finite8base generatedrules/2researchauxcompositions, actualSessiontriggers/replies/fullhistory andactualpolicy. Notautomaticgeneratorcoverage, pricedauxeffects, fitness/learning/defaultgain orall-domaincertification.'))
print('AUX_GENERATED_CLOSED',status,error,counts,round(time.perf_counter()-start,3),flush=True)
