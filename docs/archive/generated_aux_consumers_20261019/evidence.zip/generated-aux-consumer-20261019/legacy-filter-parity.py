"""Legacy reports remain byte-equivalent on saved bases; no regeneration."""
from pathlib import Path
from dataclasses import replace
import sys,json,time,zipfile,types,hashlib,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.filters import run_soft_filters
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset
D=Path(__file__).resolve().parent;A=Path(os.environ.get('GC_PRODUCT_ARCHIVE_ROOT',Path.cwd()/'docs/archive/root_window_q4_service_20261019'));start=time.perf_counter();m=json.loads((A/'manifest.json').read_bytes());assert hashlib.sha256((A/'evidence.zip').read_bytes()).hexdigest()==m['archive_sha256']
with zipfile.ZipFile(A/'evidence.zip')as z:old=z.read('source/generic_chess/generation/filters.py')
mod=types.ModuleType('generic_chess.generation._saved_filters');mod.__package__='generic_chess.generation';sys.modules[mod.__name__]=mod;exec(compile(old,'saved_product_filters.py','exec'),mod.__dict__)
i=json.loads((D/'inputs.json').read_bytes());seen=set();rows=[]
for row in i['rules']:
 key=(row['seed'],row['n'])
 if key in seen:continue
 seen.add(key);r=ruleset_from_dict(row['base_rule']);c=compile_ruleset(r)
 for enabled in (False,True):
  cfg=replace(GeneratorConfig(**row['config']),require_no_opening_win_in_one=enabled);types_by_id={t.type_id:t for t in r.piece_types};a=record_value(mod.run_soft_filters(cfg,c,types_by_id));b=record_value(run_soft_filters(cfg,c,types_by_id));assert a==b;rows.append(dict(seed=row['seed'],size=row['n'],optional_enabled=enabled,report=a))
write_json(D/'legacy-filter-parity-result.json',dict(status='PASS_SAVED_LEGACY_REPORT_PARITY',base_rules=8,reports=16,rows=rows,seconds=time.perf_counter()-start,source_archive_sha256=m['archive_sha256'],new_generation_search_games=0,scope='Exactexistingcapturedoldfilter vsfixedfilter on8savedlegacyRuleSets, bothpreferenceflags. Noallinput/performanceproof orsemantic-onlyatom-filterclaim.'))
print('LEGACY_FILTER_PARITY',len(rows),time.perf_counter()-start)
