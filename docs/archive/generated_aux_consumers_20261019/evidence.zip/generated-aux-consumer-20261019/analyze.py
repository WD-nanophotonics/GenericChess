from pathlib import Path
from collections import Counter
import json,sys,statistics,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(os.environ.get('GC_EXPERIMENT_ROOT',Path(__file__).resolve().parent))
r=json.loads((D/'result.json').read_bytes());i=json.loads((D/'inputs.json').read_bytes());nn=list(map(json.loads,(D/'native.jsonl').read_bytes().splitlines()));cc=list(map(json.loads,(D/'core.jsonl').read_bytes().splitlines()))
assert len(nn)==288 and len(cc)==48
assert sum(v['result']['nodes']for v in nn)==r['counts']['Native_main']
assert sum(v['result']['qnodes']for v in nn)==r['counts']['Native_q']
work={}
for label in ('D2q4','paidq0','paidq4'):
 for mode in (False,True):
  q=[v for v in nn if v['request']['label']==label and v['mode']==mode]
  work[label+'_'+str(mode)]=dict(queries=len(q),completed_D2q4=sum(v['result']['completed_depth']==2 and v['result']['result_ordinary_qdepth']==4 for v in q),depths=dict(Counter(v['result']['completed_depth']for v in q)),qpolicies=dict(Counter(str(v['result']['result_ordinary_qdepth'])for v in q)),causes=dict(Counter(v['result']['termination_reason']for v in q)),main=sum(v['result']['nodes']for v in q),q=sum(v['result']['qnodes']for v in q),caller_seconds=sum(v['seconds']for v in q),kernel_seconds=sum(v['result']['elapsed_seconds']for v in q),special_PV_actions=sum(v['special_PV_actions']for v in q),caller_max_seconds=max(v['seconds']for v in q))
pairs=[]
for label in ('D2q4','paidq0','paidq4'):
 for p in i['roots']:
  q={v['mode']:v for v in nn if v['name']==p['name']and v['phase']==p['phase']and v['request']['label']==label};a=q[False]['result'];b=q[True]['result']
  match=(a['completed_depth'],a['result_ordinary_qdepth'],a['result_check_hard_qdepth'])==(b['completed_depth'],b['result_ordinary_qdepth'],b['result_check_hard_qdepth'])
  pairs.append(dict(name=p['name'],phase=p['phase'],request=label,False_depth=a['completed_depth'],True_depth=b['completed_depth'],same_target_policy=match,score_equal=a['score']==b['score']if match else None,action_equal=a['action']==b['action']if match else None,main_plus_q_False=a['nodes']+a['qnodes'],main_plus_q_True=b['nodes']+b['qnodes']))
out=dict(status='PASS_ARITHMETIC_AND_FINITE_PARITY',core_complete=sum(v['complete']for v in cc),core_not_completed_D2q4=sum(not v['complete']for v in cc),core_exact_win_controls=sum(v['cause']=='root_immediate_win'for v in cc),core_unknown=sum(not v['complete']and v['cause']!='root_immediate_win'for v in cc),core_unknown_cases=[dict(name=v['name'],phase=v['phase'],cause=v['cause'])for v in cc if not v['complete']and v['cause']!='root_immediate_win'],Native_Core_comparable=sum(v['comparable']for v in r['comparisons']),Native_Core_scalar_contradictions=sum(v['score_equal']is False for v in r['comparisons']),work=work,pairs=pairs,same_policy_pairs=sum(v['same_target_policy']for v in pairs),same_policy_score_differences=sum(v['score_equal']is False for v in pairs),same_policy_action_differences=sum(v['action_equal']is False for v in pairs),native_total=r['counts']['Native_main']+r['counts']['Native_q'],Core_total=r['counts']['Core_main']+r['counts']['Core_q'],global_clock_seconds_from_planfile=r['seconds'],scope='Source-derived actual288query/48Core receipts. Samepolicy includesdepth/ordinaryq/hardq. Matchingvalues arefinitecorrectness evidence, notvaluepricing/fitness/all-domainproof. IncompleteCore remainsUNKNOWN/no refill. No performanceclaim fromCore-vsNative unequalwork orconcurrentload.')
write_json(D/'analysis.json',out)
print(json.dumps({k:v for k,v in out.items()if k not in ('pairs','core_unknown_cases')},indent=2))
