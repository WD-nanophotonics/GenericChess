"""Existing pure policy-feature alias inventory; no model or training."""
from pathlib import Path
import sys,json,time,hashlib,os
from collections import defaultdict
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.identity import position_identity_key
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.policy import semantic_action_features
from generic_chess.learning.policy_v1 import action_v1_components
D=Path(__file__).resolve().parent;start=time.perf_counter();data=json.loads((D/'inputs.json').read_bytes());rules={r['name']:r for r in data['rules']};compiled={};counts={k:dict(buckets=0,aliased_actions=0,different_position_buckets=0,different_fullstate_buckets=0)for k in ('coordinates','policy_v0','policy_v1')};witnesses=[];actions=0
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.perf_counter()-start<60
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
for p in data['roots']:
 poll();name=p['name']
 if name not in compiled:compiled[name]=compile_semantic_ruleset(ruleset_from_dict(rules[name]['rule']))
 c=compiled[name];s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));groups={k:defaultdict(list)for k in counts}
 for a in s.legal_actions():
  actions+=1;v0=semantic_action_features(c,s.state.position,a);base,cat=action_v1_components(c,s.state.position,a);child=GameSession.replay(c,s.to_record());child.submit(a)
  ident=dict(action=record_value(a),position_key=str(position_identity_key(child.state.position,c)),state_sha256=digest(child.state),aux_state=record_value(child.state.position.aux_state))
  coord=(getattr(a,'from_square',None),a.to_square,getattr(a,'promotion_target_id',None),getattr(a,'base_type_id',None))
  for k,key in [('coordinates',coord),('policy_v0',tuple(v0)),('policy_v1',(tuple(base),cat))]:groups[k][key].append(ident)
 for kind,gg in groups.items():
  for values in gg.values():
   if len(values)<2:continue
   counts[kind]['buckets']+=1;counts[kind]['aliased_actions']+=len(values);positiondiff=len({v['position_key']for v in values})>1;statediff=len({v['state_sha256']for v in values})>1
   counts[kind]['different_position_buckets']+=positiondiff;counts[kind]['different_fullstate_buckets']+=statediff
   if positiondiff and sum(w['kind']==kind for w in witnesses)<4:witnesses.append(dict(name=name,phase=p['phase'],kind=kind,alternatives=values))
write_json(D/'policy-alias-result.json',dict(status='PASS_FINITE_FEATURE_INVENTORY',parents=len(data['roots']),actions=actions,counts=counts,witnesses=witnesses,seconds=time.perf_counter()-start,no_models_or_training=True,no_Native_search=True,scope='ExistingpureV0/V1 encoders on48exposedparents only. Equalpolicyinputs do not prove actions canmerge; priors mayalias whiletreebranches remainexact. Currentservice usespolicy=None. No observedlearningerror/strengthloss ornewfeatureAPI claim.'))
print('POLICY_FEATURE_ALIAS',actions,counts,time.perf_counter()-start)
