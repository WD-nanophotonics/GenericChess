"""Existing optional opening-win preference before/after this finite composition."""
from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.filters import run_soft_filters
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_semantic_ruleset
from generic_chess.rules.execution import ExecutableSemanticRuleset
from generic_chess.session.session import GameSession
D=Path(__file__).resolve().parent;start=time.perf_counter();i=json.loads((D/'inputs.json').read_bytes());rows=[];bases={}
for row in i['rules']:
 assert time.perf_counter()-start<120
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 cfg=replace(GeneratorConfig(**row['config']),require_no_opening_win_in_one=True);key=(row['seed'],row['n'])
 if key not in bases:
  r=ruleset_from_dict(row['base_rule']);c=compile_ruleset(r);out=run_soft_filters(cfg,c,{t.type_id:t for t in r.piece_types});bases[key]=next(v for v in out if v.name=='opening_has_no_win_in_one')
 r=ruleset_from_dict(row['rule']);raw=compile_semantic_ruleset(r);c=ExecutableSemanticRuleset.from_compiled(raw);out=run_soft_filters(cfg,c,{t.type_id:t for t in r.piece_types});actual=next(v for v in out if v.name=='opening_has_no_win_in_one');s=GameSession(raw);winning=[]
 for a in s.legal_actions():
  child=copy(s);child.submit(a)
  if child.result.winner==s.state.position.side_to_move:winning.append(record_value(a))
 assert actual.passed==(not winning)
 rows.append(dict(name=row['name'],base_preference_passed=bases[key].passed,composed_preference_passed=actual.passed,composed_winning_actions=winning,augmented_winning_actions=sum(a['pattern_id']in row['special_pattern_ids']for a in winning)))
out=dict(status='PASS_FINITE_POSTCOMPOSITION_PREFERENCE_INVENTORY',base_rules=8,compositions=16,base_pass=sum(x.passed for x in bases.values()),composed_pass=sum(x['composed_preference_passed']for x in rows),base_pass_composed_fail=sum(x['base_preference_passed']and not x['composed_preference_passed']for x in rows),base_fail_composed_pass=sum(not x['base_preference_passed']and x['composed_preference_passed']for x in rows),rows=rows,seconds=time.perf_counter()-start,new_search_games_training=0,scope='Existingoptionalpreference only, notretroactivefilteringofanyclosedcell orbalance/prolongedplayproof. AdapterretainsfullIR, promotion/drop/aux/history; legacyatomstructuralfilters areappropriateonlyforthisatom-generatedsubset, notgenericsemantic-onlyadmission.')
write_json(D/'opening-preference-result.json',out)
print('OPENING_PREFERENCE', {k:v for k,v in out.items()if k not in ('rows','scope')})
