"""One-pass full-state Native checked-edge qualification, no search."""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import snapshot_matches,pack_semantic_action
from generic_chess.native.semantic import snapshot,guarded_actions,public_action,make_checked,terminal_status
D=Path(__file__).resolve().parent;start=time.perf_counter();data=json.loads((D/'inputs.json').read_bytes());rules={r['name']:r for r in data['rules']};compiled={};natives={};rows=[];counts=dict(roots=0,children=0,special_children=0,drop_children=0,promotion_children=0);failures=[]
def poll():
 assert time.perf_counter()-start<120
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path.cwd()/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
for p in data['roots']:
 poll();name=p['name'];r=rules[name]
 if name not in compiled:compiled[name]=compile_semantic_ruleset(ruleset_from_dict(r['rule']));natives[name]=compile_native_semantic_rules(compiled[name])
 c=compiled[name];nr=natives[name];s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));before=(s.state,s.history,s.to_record(),s._search_witnesses);root=pack_semantic_search_position(c,nr,s);snap=snapshot(nr,root);aa=s.legal_actions();actual={public_action(nr,x)for x in guarded_actions(nr,root)};assert actual==set(aa);counts['roots']+=1
 assert snapshot_matches(snap,s.state.position,nr,c)
 row=dict(name=name,phase=p['phase'],legal_count=len(aa),children=0,special_children=0,snapshot_field_names=sorted(snap))
 for a in aa:
  poll();child=make_checked(nr,root,pack_semantic_action(nr,s.state.position,a));cs=GameSession.replay(c,s.to_record());cs.submit(a);got=snapshot(nr,child);fresh=snapshot(nr,pack_semantic_search_position(c,nr,cs))
  assert snapshot_matches(got,cs.state.position,nr,c)
  diffs=[k for k in got.keys()|fresh.keys()if got.get(k)!=fresh.get(k)]
  if diffs:failures.append(dict(name=name,phase=p['phase'],action=record_value(a),different_fields=diffs,incremental=got,reimport=fresh))
  assert not diffs,(name,p['phase'],diffs)
  nt=terminal_status(nr,child)
  assert nt['status']==cs.state.terminal_status.status.value,(nt,cs.state.terminal_status)
  counts['children']+=1;row['children']+=1
  if getattr(a,'pattern_id',None)in r['special_pattern_ids']:counts['special_children']+=1;row['special_children']+=1
  if hasattr(a,'base_type_id'):counts['drop_children']+=1
  if getattr(a,'promotion_target_id',None)is not None:counts['promotion_children']+=1
 assert before==(s.state,s.history,s.to_record(),s._search_witnesses)and snapshot(nr,root)==snap
 rows.append(row)
write_json(D/'checked-edges-result.json',dict(status='PASS',counts=counts,rows=rows,failures=failures,seconds=time.perf_counter()-start,global_cap_seconds=120,new_searches=0,scope='Alllegalsingleedges of48storedparents, fullsnapshot includingactualhistoryevents/counts/aux/typeflags. No arbitrarydepth/all-domain proof, fitness or newsearch.'))
print('CHECKED_AUX_EDGES',counts,time.perf_counter()-start)
