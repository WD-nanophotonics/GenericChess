"""Direct newq0 versus ALL priorq4True cells; no old-game rerun."""
from pathlib import Path
from collections import Counter
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;S=D.parent/'generated-aux-service-20261019';P=json.loads((D/'plan.json').read_bytes());assert hashlib.sha256((S/'games.jsonl').read_bytes()).hexdigest()==P['prior_q4_source']['games_sha256']
old={(g['name'],g['owner'],g['foe']):g for g in map(json.loads,(S/'games.jsonl').read_bytes().splitlines())if g['mode']}
new={(g['name'],g['owner'],g['foe']):g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};assert old.keys()==new.keys()and len(new)==64
def bounds(gg):
 n=len(gg);u=sum(g['reward']is None for g in gg);k=sum(g['reward']for g in gg if g['reward']is not None)
 return dict(planned=n,W=sum(g['reward']==1 for g in gg),D=sum(g['reward']==0 for g in gg),L=sum(g['reward']==-1 for g in gg),UNKNOWN=u,reward_bounds=[(k-u)/n,(k+u)/n])
def delta(keys):
 lo=hi=0
 for k in keys:
  a=new[k]['reward'];b=old[k]['reward'];lo+=(-1 if a is None else a)-(1 if b is None else b);hi+=(1 if a is None else a)-(-1 if b is None else b)
 return[lo/len(keys),hi/len(keys)]
out={}
for foe in P['foes']:
 kk=[k for k in new if k[2]==foe];per={str(seed):delta([k for k in kk if k[0].startswith(str(seed)+'-')])for seed in range(631001,631005)}
 out[foe]=dict(explicit_q0=bounds([new[k]for k in kk]),requested_q4_reused=bounds([old[k]for k in kk]),q0_minus_q4=delta(kk),per_seed=per,descriptive_seed_range=[min(v[0]for v in per.values()),max(v[1]for v in per.values())],by_size={str(n):delta([k for k in kk if k[0].split('-')[1]==str(n)])for n in (6,8)},by_variant={v:delta([k for k in kk if k[0].endswith(v)])for v in ('persistent_per_owner','temporary_global')})
queries=0;main=qnodes=0;work={}
for line in(D/'queries.jsonl').open(encoding='utf8'):
 q=json.loads(line);z=q['result'];queries+=1;main+=z['nodes'];qnodes+=z['qnodes'];w=work.setdefault('candidate'if q['candidate']else'foe',dict(queries=0,main=0,q=0,caller_seconds=0,kernel_seconds=0,depths=Counter(),qpolicies=Counter(),causes=Counter()))
 w['queries']+=1;w['main']+=z['nodes'];w['q']+=z['qnodes'];w['caller_seconds']+=q['caller_seconds'];w['kernel_seconds']+=z['elapsed_seconds'];w['depths'][z['completed_depth']]+=1;w['qpolicies'][str((z['result_ordinary_qdepth'],z['result_check_hard_qdepth']))]+=1;w['causes'][z['termination_reason']]+=1
result=json.loads((D/'result.json').read_bytes());assert main==result['counts']['main']and qnodes==result['counts']['q']and queries==result['counts']['queries']
write_json(D/'analysis.json',dict(status='PASS_FULL_REUSED_CONTROL_ARITHMETIC',contrasts=out,new_physical=64,reused_prior_physical=64,logical_cells=128,prior_unknown_kept=12,new_queries=queries,new_main=main,new_q=qnodes,work=work,producer_seconds=result['seconds'],scope='All64newq0 versusALL64priorq4True, fourlinkedseedblocks. No virtualNEW128 physical, oldrefill, independentgames/populationconfidence, sameactualwork/wholecaller timing orqsearchunsoundness claim. Bothvariants retainfullrules/history.'))
print(json.dumps(dict(contrasts=out,new_queries=queries,new_main=main,new_q=qnodes,work=work),indent=2))
