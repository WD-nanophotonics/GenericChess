"""Search-disabled full Session/PV replay of the generated auxiliary service."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.semantic_engine import SemanticSearchEngine
def forbidden(*a,**k):raise AssertionError('Readercannotsearch')
SemanticSearchEngine.search=forbidden
D=Path(__file__).resolve().parent;start=time.perf_counter();P=json.loads((D/'plan.json').read_bytes());res=json.loads((D/'result.json').read_bytes());inp=json.loads((D/'inputs.json').read_bytes());rules={r['name']:r for r in inp['rules']};roots={p['name']:p for p in inp['roots']if p['phase']==0};comp={name:compile_semantic_ruleset(ruleset_from_dict(r['rule']))for name,r in rules.items()};stats=Counter()
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(v):
 if isinstance(v,str):return v
 v=dict(v);v['to_square']=Square(**v['to_square'])
 if 'from_square'in v:v['from_square']=Square(**v['from_square']);return SemanticBoardMove(**v)
 return SemanticDropMove(**v)
def poll():
 assert time.perf_counter()-start<600
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
stream=(json.loads(line)for line in(D/'queries.jsonl').open(encoding='utf8'));nq=next(stream,None)
for line in(D/'games.jsonl').open(encoding='utf8'):
 poll();g=json.loads(line);c=comp[g['name']];s=GameSession.replay(c,deserialize_game_record(json.dumps(roots[g['name']]['record'])));assert digest(s.state)==roots[g['name']]['state_sha256'];final=deserialize_game_record(json.dumps(g['record']));local=Counter();ids=[]
 while nq is not None and nq['slot']==g['slot']:
  q=nq;nq=next(stream,None);z=q['result'];ids.append(q['query']);assert digest(s.state)==q['before_sha256']and s.state.position.side_to_move==q['actor'];assert q['candidate']==(q['actor']==g['owner']);assert z['root_window_pruning']==(g['mode']if q['candidate']else False);assert 0<=z['completed_depth']<=(8 if q['candidate']else 2);parent=(s.state,s.to_record(),s.history,s._search_witnesses);leaf=copy(s)
  for a in z['decision_line']:
   a=decode(a)
   if isinstance(a,str):leaf.declare(a)
   else:leaf.submit(a);stats['PV_Core_edges']+=1
  assert parent==(s.state,s.to_record(),s.history,s._search_witnesses)
  if q['committed']is not None:
   assert z['completed_depth']>=1 and not z['used_fallback'];a=decode(q['committed'])
   if isinstance(a,str):assert a==z['declaration_id'];s.declare(a)
   else:
    assert record_value(a)==z['action']==record_value(final.actions[len(s.history)]);before=s.state.position;s.submit(a);stats['commits']+=1;local['commits']+=1;local['drops']+=isinstance(a,SemanticDropMove);local['promotions']+=getattr(a,'promotion_target_id',None)is not None;local['augmented']+=getattr(a,'pattern_id',None)in rules[g['name']]['special_pattern_ids'];local['aux_changes']+=before.aux_state!=s.state.position.aux_state
    stats['actual_hand_gain_events']+=sum(v for h in s.state.position.hands for t,v in h.counts)>sum(v for h in before.hands for t,v in h.counts)
  assert digest(s.state)==q['after_sha256'];stats['queries']+=1;stats['main']+=z['nodes'];stats['q']+=z['qnodes'];local['queries']+=1;local['main']+=z['nodes'];local['q']+=z['qnodes']
 assert ids==g['queries']and dict(local)==g['counts'],(dict(local),g['counts'])
 assert s.to_record()==final and digest(s.state)==g['final_state_sha256']and digest(s._search_witnesses)==g['final_witness_sha256']and record_value(s.result)==g['result']
 expect=None if s.result.status.value=='ongoing'else 0 if s.result.winner is None else 1 if s.result.winner==g['owner']else-1
 assert expect==g['reward']
 stats['games']+=1;stats['terminal']+=expect is not None;stats['unknown']+=expect is None
 for k in ('drops','promotions','augmented','aux_changes'):stats[k]+=local[k]
assert nq is None and stats['games']==res['closed']and stats['queries']==res['counts']['queries']and stats['main']==res['counts']['main']and stats['q']==res['counts']['q']
write_json(D/'reader-result.json',dict(status='PASS_FULL_SESSIONS_AND_PVS',counts=dict(stats),seconds=time.perf_counter()-start,search_disabled=True,scope='Allrecordedphysicalqueries/PVs/commits/finalrecords andfullhistory/aux/type state. No score-asPVleaf/WDL/missingoutcome claim.'))
print('AUX_SERVICE_READER',dict(stats),time.perf_counter()-start)
