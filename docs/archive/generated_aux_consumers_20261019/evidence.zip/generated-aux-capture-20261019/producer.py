"""Existing Core capture-only q4 feasibility; not Native or utility."""
from pathlib import Path
from copy import copy
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;I=D.parent/'generated-aux-consumer-20261019';P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();deadline=start+P['global_seconds'];data=json.loads((I/'inputs.json').read_bytes());rules={r['name']:r for r in data['rules']};compiled={};rows=[];status='COMPLETE';error=None
class Stop:
 def __init__(self):self.next=0;self.stopped=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in ('rollout','advisor','slack'):
    f=json.loads((Path.cwd()/'.local_agent'/(n+'.json')).read_bytes());self.stopped|=bool(f.get('stopped')or f.get('user_paused'))
  return self.stopped or now>=deadline
stop=Stop()
class Material:
 def __init__(self,r):self.b=r['board_values'];self.h=r['hand_values']
 def evaluate(self,s):
  v=sum((1 if p.owner==0 else-1)*self.b[p.current_type_id]for p in s.position.board if p)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items());return v*(1 if s.position.side_to_move==0 else-1)
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
write_json(D/'source.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256((I/'inputs.json').read_bytes()).hexdigest()))
try:
 with(D/'queries.jsonl').open('x',encoding='utf8',newline='\n')as log:
  for p in data['roots']:
   if stop.is_cancelled():raise TimeoutError('STOP_OR_GLOBAL_CAP')
   name=p['name'];r=rules[name]
   if name not in compiled:compiled[name]=compile_semantic_ruleset(ruleset_from_dict(r['rule']))
   c=compiled[name];s=GameSession.replay(c,deserialize_game_record(json.dumps(p['record'])));assert digest(s.state)==p['state_sha256'];before=(s.state,s.to_record(),s.history,s._search_witnesses);st=SearchStatistics();tick=time.perf_counter()
   a,score,pv,cause=run_root_search(s.state,c,Material(r),TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(30,max(.001,deadline-time.perf_counter())),quiescence_max_depth=4),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(use_capture_only_qsearch=True),_history_witnesses=s._search_witnesses)
   assert before==(s.state,s.to_record(),s.history,s._search_witnesses);leaf=copy(s)
   for action in pv:leaf.submit(action)
   rr=dict(name=name,phase=p['phase'],action=record_value(a),score=score,pv=record_value(pv),cause=cause,statistics=record_value(st),complete=st.completed_depth==2 and st.result_ordinary_qdepth==4,seconds=time.perf_counter()-tick,capture_only=True)
   rows.append(rr);log.write(json.dumps(rr,separators=(',',':'))+'\n');log.flush();print('CAPTURE_ONLY_CORE',len(rows),name,p['phase'],st.completed_depth,st.result_ordinary_qdepth,cause,round(time.perf_counter()-start,3),flush=True)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,planned=48,closed=len(rows),missing=48-len(rows),complete=sum(r['complete']for r in rows),main=sum(r['statistics']['nodes']for r in rows),q=sum(r['statistics']['qnodes']for r in rows),seconds=time.perf_counter()-start,scope='ExistingCorecapture-onlyq4/noNative. ALL48storedparents, changednoisyfrontiertarget; reuseoldfullq4receipts including20UNKNOWN withoutrefill. Feasibility/cost only, notcorrectnessbyfullq4valueequality orfitness.'))
print('CAPTURE_ONLY_CLOSED',status,error,len(rows),round(time.perf_counter()-start,3),flush=True)
