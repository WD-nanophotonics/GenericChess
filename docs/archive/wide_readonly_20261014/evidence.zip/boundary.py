from cimport_smoke import *
from readonly import Unsupported,Row,Guard
from generic_chess.rules.schema import RuleStateGuard,RuleTypeRef,RuleSpatialSelector,RuleSquareRef
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_current_position
from generic_chess import _native_core
import _wide_readonly as native
import ctypes as C
sys.path.insert(0,str(ROOT/'tests'))
from rule_semantics_ir_fixtures import _semantic_ruleset,_king_type
write_record(D/'boundary-declaration.json',dict(question='Do unsupported validguards decline and isolatedcapsule/uint16 buffers reject malformed ranges?',bounds='24board/area576;compiledstatic rows1.4MB; wrong names/bufferlengths/coordinates/owners',no_unsafe_calls=True))
c,p,state=fixture(24,False);provider=Provider(c);board,aux=provider.pack(p);rows=[]
definition=deserialize_ruleset((ROOT/'.local_agent/frame-reply-20261014/wide-aux-v2-24-rules.json').read_text(encoding='utf-8'))
definition=replace(definition,initial_position=tuple(tuple(x if x is not None and x.current_type_id=='K' else None for x in row) for row in definition.initial_position))
action=definition.semantic_actions[0]
guard=RuleStateGuard(aggregation='exists',owner='self',type_ref=RuleTypeRef('explicit','R'),compare_field='current',promoted='any',location='board',spatial=RuleSpatialSelector('same_file',refs=(RuleSquareRef('source'),)))
for label,a in [('stateguard',replace(action,state_guards=(guard,))),('boolaux',replace(action,aux_state=(replace(action.aux_state[0],value_kind='bool',initial=0),),slot_guards=(replace(action.slot_guards[0],square_ref=None,value=1),)))]:
 try:
  cc=compile_ruleset_for_execution(replace(definition,semantic_actions=(a,)))
  try:Provider(cc);raise AssertionError('unsupported accepted')
  except Unsupported as exc:rows.append(dict(label=label,valid_Core_compiled=True,declined=str(exc)))
 except Exception as exc:rows.append(dict(label=label,failed_before_prototype=type(exc).__name__,error=str(exc)))
small=compile_ruleset_for_execution(_semantic_ruleset((_king_type(),),(),n=8))
legacy=NativeSemanticLegalityProvider.try_create(small);assert legacy is not None
legacy_position=pack_current_position(legacy.native_rules,GameSession(small).state.position,ply_count=0)
cases=[
 ('readonly_rules_to_old',lambda:_native_core.semantic_in_check(provider.capsule,legacy_position,1)),
 ('readonly_position_to_old',lambda:_native_core.semantic_in_check(legacy.native_rules.capsule,provider.capsule,1)),
 ('old_rules_to_readonly',lambda:native.query(legacy.native_rules.capsule,board,aux,575,0,None)),
 ('short_board',lambda:native.query(provider.capsule,board[:-1],aux,575,0,None)),
 ('missing_aux',lambda:native.query(provider.capsule,board,[],575,0,None)),
 ('target576',lambda:native.query(provider.capsule,board,aux,576,0,None)),
 ('owner2',lambda:native.query(provider.capsule,board,aux,575,2,None)),
 ('aux576',lambda:native.query(provider.capsule,board,[576,-1,-1],575,0,None)),
 ('bad_cell',lambda:native.query(provider.capsule,[(0,99,0,0)]+board[1:],aux,575,0,None)),
 ('offset_nonmonotonic',lambda:native.compile(24,3,1,b'',b'',b'',bytes((C.c_uint32*1153)(*([1]*1153))))),
 ('source576',lambda:native.compile(24,3,1,bytes(Row(576,0,0,0,0,0,0)),b'',b'',bytes((C.c_uint32*1153)(0,*([1]*1152))))),
 ('path576',lambda:native.compile(24,3,1,b'',bytes((C.c_uint16*1)(576)),b'',bytes((C.c_uint32*1153)(*([0]*1153))))),
]
for label,call in cases:
 try:call();raise AssertionError(label+'accepted')
 except (ValueError,TypeError) as exc:rows.append(dict(label=label,rejected=type(exc).__name__,error=str(exc)))
# Entry/active required callback errors retain their exact exception and leave nextquery usable.
for cls in (RuntimeError,KeyboardInterrupt):
 error=cls('required checkpoint propagation')
 def checkpoint():raise error
 try:provider.query(p,575,0,checkpoint=checkpoint);raise AssertionError('missingrequired')
 except BaseException as exc:assert exc is error
 assert provider(p,1)==False
 rows.append(dict(label=cls.__name__,same_exception_object=True,next_query_usable=True))
write_record(D/'boundary.json',dict(complete=True,rows=rows,checks=len(rows)))
print(json.dumps(rows,indent=2))
