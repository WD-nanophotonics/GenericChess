from chunk_smoke import *
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.ai.cancellation import CancellationToken
import threading
DENSE=48
definition=deserialize_ruleset((ROOT/'.local_agent/frame-reply-20261014/wide-aux-v2-24-rules.json').read_text(encoding='utf-8'))
original=definition.semantic_actions[0]
definition=replace(definition,semantic_actions=(original,)+tuple(replace(original,name=f'scan_{i:02}',composition='augment',replace_selector=None,aux_state=()) for i in range(DENSE)))
write_record(D/'cancel-chunk-token-declaration.json',dict(pattern_copies=DENSE+1,board=24,attempts=8,deadline_after_active_poll_seconds=0.0,mechanism='C scan poll2 signals request thread, existing CancellationToken or event read by actual checkpoint; request thread uses sameprocess only, no Agent/worker. No scan repetitions, busy delay, inserted sleeps or arbitrary workload amplification; genuine49 equivalent guard-bearing capture patterns on compiledDSL. This synthetic mechanism stress tests cancellation, not game distribution/performance.',normal_and_error_rollback=True,full_source_frozen=True))
(D/'dense-rules.json').write_text(serialize_ruleset(definition),encoding='utf-8')
t=time.perf_counter();c=compile_ruleset_for_execution(definition);compile_core=time.perf_counter()-t
p=GameSession(c).state.position
p=replace(p,aux_state=(((0,-1),None),))
state=GameState(p,0,(),TerminalResult(TerminalStatus.ONGOING),())
provider=Provider(c);e=SemanticEngine(c)
assert provider(p,1,checkpoint=lambda:None)==e.in_check(p,1)==False
normal=[];rows=[]
r=SearchPathRuntime.from_state(state,c,check_provider=provider)
move=next(a for a in r.legal_actions() if getattr(a,'from_square',None) is not None and a.from_square.rank==22 and a.from_square.file==21 and a.to_square.rank==22 and a.to_square.file==22)
before=snapshot(r)
for i in range(8):
 active=threading.Event();requested=CancellationToken();stop=threading.Event();times={};inquery=[False];pollcount=[0]
 class Cancelled(RuntimeError):pass
 def worker():
  if not active.wait(2):times['worker_timeout']=True;return
  times['request_executed']=time.perf_counter();times['request_inside_provider']=inquery[0]
  requested.cancel()
 def observer(count):
  pollcount[0]=count
  if count==2:
   times['scheduled_request']=time.perf_counter();active.set()
 def checkpoint():
  if requested.is_cancelled():
   times.setdefault('exception_seen',time.perf_counter());raise Cancelled('active readonly cancellation')
 def checked(p,side,checkpoint=None):
  inquery[0]=True;times['query_enter']=time.perf_counter()
  try:
   anchor=next(i for i,x in enumerate(p.board) if x is not None and x.owner==side and c.support.type_metadata[x.current_type_id].is_anchor)
   return provider.query(p,anchor,1-side,checkpoint=checkpoint,observer=observer)
  finally:times['query_exit']=time.perf_counter();inquery[0]=False
 r._check_provider=checked;thread=threading.Thread(target=worker,name='bounded-project-cancel-request');thread.start();result='completed'
 try:
  with r.pushed(move,checkpoint=checkpoint):pass
 except Cancelled:result='cancelled'
 times['rollback_completed']=time.perf_counter();thread.join(2)
 assert not thread.is_alive() and snapshot(r)==before
 rows.append(dict(attempt=i,result=result,polls=pollcount[0],times=times,restored=True,
  active_request=(times.get('request_executed',float('inf'))<times.get('query_exit',0)),
  execution_delay=times.get('request_executed',0)-times.get('scheduled_request',0),
  rollback_delay=times['rollback_completed']-times.get('request_executed',times['rollback_completed'])))
 write_record(D/'cancel-chunk-token.json',dict(complete=False,rows=rows,core_compile_seconds=compile_core,provider_compile_seconds=provider.compile_seconds,static=provider.compile_counts))
 print(rows[-1],flush=True)
write_record(D/'cancel-chunk-token.json',dict(complete=True,rows=rows,core_compile_seconds=compile_core,provider_compile_seconds=provider.compile_seconds,static=provider.compile_counts,active_cancelled=sum(x['active_request'] and x['result']=='cancelled' for x in rows)))
