from direct_smoke import *
from readonly import Poll,lib,Cell,Row,Guard
import ctypes as C,statistics
def main():
 write_record(D/'direct-cost-declaration.json',dict(sizes=[18,24],aux=[False,True],query_repeats=1000,push_repeats=100,orders=['Core,C','C,Core'],checkpoint=['none','noop'],arms='Core scalar versus complete private pack/Cquery/callback/required Core push+pop',static_compile_excluded_reported_separately=True,scope='same synthetic18/24 roots; no search strength or arbitrary native domain claim'))
 rows=[]
 for n in (18,24):
  for enabled in (False,True):
   c,p,state=fixture(n,enabled);provider=Provider(c);e=SemanticEngine(c)
   for checkmode in ('none','noop'):
    checkpoint=None if checkmode=='none' else (lambda:None)
    for rep in range(2):
     measurements={}
     for arm in (('core','c') if rep==0 else ('c','core')):
      fun=(lambda:e.in_check(p,1,checkpoint=checkpoint)) if arm=='core' else (lambda:provider(p,1,checkpoint=checkpoint))
      t=time.perf_counter()
      for _ in range(1000):assert fun()==enabled
      measurements[arm]=time.perf_counter()-t
     rows.append(dict(kind='scalar',n=n,aux=enabled,checkpoint=checkmode,rep=rep,seconds=measurements,ratio=measurements['c']/measurements['core']))
   for rep in range(2):
    measurements={}
    for arm in (('core','c') if rep==0 else ('c','core')):
     r=SearchPathRuntime.from_state(state,c,check_provider=None if arm=='core' else provider)
     move=next(a for a in r.legal_actions() if getattr(a,'from_square',None) is not None and a.from_square.rank==n-2 and a.from_square.file==n-3 and a.to_square.rank==n-2 and a.to_square.file==n-2)
     before=snapshot(r);t=time.perf_counter()
     for _ in range(100):
      with r.pushed(move,checkpoint=lambda:None):
       assert r.in_check(1)==enabled and r.history[-1].gave_check==enabled
     measurements[arm]=time.perf_counter()-t;assert snapshot(r)==before
    rows.append(dict(kind='pushpop',n=n,aux=enabled,rep=rep,seconds=measurements,ratio=measurements['c']/measurements['core'],full_state_restored=True))
   print(n,enabled,rows[-1],flush=True)
 write_record(D/'direct-cost.json',dict(complete=True,rows=rows,scalar_pairs=16,actual_pushes=1600,provider_stats=provider.stats))
if __name__=='__main__':main()
