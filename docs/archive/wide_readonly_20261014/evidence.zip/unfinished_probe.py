from lazy_smoke import *
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
import cProfile,pstats,random
write_record(D/'unfinished-declaration.json',dict(question='Which actual Core consumers dominate unfinishedfirstq4D2, afterreadonly costsfailedtoretaina newdecision?',seed=2026102017,size=18,prefix=8,rng_offset=31000,q=4,hardq=8,seconds=16,depth=12,nodes=None,actual_calls=1,scope='profiledmechanism diagnosis onexposedroot; noresourcevalidation/speedup/strength; no capextension orqpolicychange. FullCorehistory/session restored.'))
g=p.generate_game(p.GeneratorConfig(seed=2026102017,board_size=18,setup_preset='bilateral_random',allow_hybrid=True))
cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support)
s=p.GameSession(c);rng=random.Random(2026102017+31000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
before=(s.state,s.to_record(),s._search_witnesses);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
prof=cProfile.Profile();prof.enable()
d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=16,quiescence_max_depth=4,quiescence_hard_max_depth=8))
prof.disable();assert before==(s.state,s.to_record(),s._search_witnesses)
stats=pstats.Stats(prof);top=[]
for key,v in sorted(stats.stats.items(),key=lambda item:item[1][2],reverse=True)[:30]:
 top.append(dict(file=Path(key[0]).name,function=key[2],calls=v[1],self_seconds=v[2],inclusive_seconds=v[3]))
selected=[]
for key,v in stats.stats.items():
 if key[2] in ('_transition','_make_binding','_guards_hold','_gave_check','is_square_attacked','legal_actions','generate_qactions','classify','classify_action','get_successor','terminal_from_search_runtime','_runtime_position_identity','_history_context','_checkpoint','semantic_component_diff','_semantic_component_diff_hash','_trial_child_if_s3_legal'):
  selected.append(dict(file=Path(key[0]).name,function=key[2],calls=v[1],self_seconds=v[2],inclusive_seconds=v[3]))
write_record(D/'unfinished-profile.json',dict(complete=True,actual_search_calls=1,profiled_total_seconds=stats.total_tt,top_self=top,selected=selected,decision=record_value(d),full_history_restored=True,scope='Profilerincluded. Selftime andinclusiveoverlappingtimes separate; neither excludesthreadload norpredicts actualunprofiled gain.'))
prof.dump_stats(str(D/'unfinished-private.pstats'))
print(d.completed_depth,d.result_ordinary_qdepth,d.termination_reason,stats.total_tt)
print(top[:12])
