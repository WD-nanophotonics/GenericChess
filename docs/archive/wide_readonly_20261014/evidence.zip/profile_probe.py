from cimport_smoke import *
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
import cProfile,pstats
write_record(D/'profile-declaration.json',dict(root='24auxtrue',q=[0,4],arms=['Core','C'],max_nodes=1024,max_depth=6,max_time=64,scope='profiledbottleneck diagnostic only, not unprofiledwall-speed/completion oradditionalfrozenvalidation. Actual _gave_check inclusive fraction versus whole profiledcall; allS3 remainsCore.'))
rows=[]
for q in (0,4):
 for arm in ('core','c'):
  c,pos,state=fixture(24,True);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
  provider=Provider(c) if arm=='c' else None;player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev,check_provider=provider)
  session=GameSession(c);session._state=state;session._search_history_witnesses=(state.position,)
  before=(session.state,session.to_record(),session._search_witnesses);prof=cProfile.Profile()
  prof.enable();d=player.choose_action(session,SearchLimits(max_depth=6,max_nodes=1024,max_time_seconds=64,quiescence_max_depth=q,quiescence_hard_max_depth=8));prof.disable()
  assert before==(session.state,session.to_record(),session._search_witnesses)
  stats=pstats.Stats(prof);selected=[]
  for key,v in stats.stats.items():
   if key[2] in ('_gave_check','in_check','is_square_attacked','_make_binding','_guards_hold','_transition','legal_actions','query','pack','_runtime_position_identity'):
    selected.append(dict(function=key[2],file=Path(key[0]).name,calls=v[1],self_seconds=v[2],inclusive_seconds=v[3]))
  prof.dump_stats(str(D/f'profile-{q}-{arm}.pstats'))
  rows.append(dict(q=q,arm=arm,profiled_total_seconds=stats.total_tt,selected=selected,decision=record_value(d),provider=None if provider is None else provider.stats))
write_record(D/'profile.json',dict(complete=True,rows=rows,actual_search_calls=4))
print([(r['q'],r['arm'],r['profiled_total_seconds'],next(x for x in r['selected'] if x['function']=='_gave_check')) for r in rows])
