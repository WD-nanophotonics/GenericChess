from cimport_smoke import *
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
out=D/'resource';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Can actual wide readonly hook improve retained search completion at equal resource, despite mixed1024node costs?',roots=['18aux0','18aux1','24aux0','24aux1'],q=[0,4],depth=12,max_nodes=None,seconds=[16,64],hardq=8,orders=['Core,C','C,Core'],planned_calls=64,requested_seconds=2560,expected_minutes=44,fuse_seconds=3400,comparison='predeclared exposed synthetic active-capture controls, not fresh independentholdout. Complete Core legality/transition/aux/history; only _gave_check hook optin. NoNativeactioncodec/cap/default. Same evaluator/TT/tuning; actualcompile cost separately counted in preparation. Configuredq versus retainedpolicy distinct. Ordinaryconcurrentload. Allcases includingnegative/caps retained, noresultdrivenbudgetextension.'))
rows=[];start=time.perf_counter()
try:
 for n in (18,24):
  for enabled in (False,True):
   c,pos,state=fixture(n,enabled);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
   for q in (0,4):
    for seconds in (16,64):
     for rep in range(2):
      for arm in (('core','c') if rep==0 else ('c','core')):
       p.rr.stopped();assert time.perf_counter()-start<3400
       t=time.perf_counter();provider=Provider(c) if arm=='c' else None
       player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev,check_provider=provider)
       session=GameSession(c);session._state=state;session._search_history_witnesses=(state.position,)
       before=(session.state,session.to_record(),session._search_witnesses)
       prep=time.perf_counter()-t;t=time.perf_counter()
       d=player.choose_action(session,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=seconds,quiescence_max_depth=q,quiescence_hard_max_depth=8))
       wall=time.perf_counter()-t
       assert before==(session.state,session.to_record(),session._search_witnesses)
       child=state
       for a in d.principal_variation:
        assert a in legal_actions(child,c);child=apply_action(child,a,c)
       rows.append(dict(n=n,aux=enabled,q=q,seconds=seconds,rep=rep,arm=arm,wall=wall,prepare_seconds=prep,decision=record_value(d),provider=None if provider is None else dict(provider.stats),history_restored=True,pv_core_legal=True))
       write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
       print(n,enabled,q,seconds,rep,arm,round(wall,4),d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
except BaseException as exc:
 write_record(out/'failure.json',dict(type=type(exc).__name__,message=str(exc),saved_calls=len(rows),elapsed=time.perf_counter()-start));raise
