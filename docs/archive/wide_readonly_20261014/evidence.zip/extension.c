/* Isolated readonly feasibility kernel. No old ABI, action, make/unmake or globals.
   Numeric rows come exclusively from compiled Core capture IR.
   Same path-clear occupancy and square-slot equality semantics as existing scalar.
   Unsupported guards are rejected by the Python compiler, never silently omitted. */
#include <stdint.h>
typedef struct {int32_t base,current,owner,promoted;} Cell;
typedef struct {uint32_t source,type,path_offset,path_count,guard_offset,guard_count,clear;} Row;
typedef struct {int32_t slot,owner,ref_kind,absolute,unequal;} Guard;
typedef int (*Poll)(void *);
__declspec(dllexport) int wide_query(uint32_t area, const Cell *board,
 const Row *rows, uint32_t row_count, const uint16_t *paths,
 const Guard *guards,const int32_t *aux,uint32_t target,uint32_t attacker,
 Poll poll,void *context,uint64_t *audit) {
 if(target>=area || attacker>1)return -2;
 audit[0]=audit[1]=audit[2]=audit[3]=0;
 if(poll && poll(context))return -1;
 for(uint32_t j=0;j<row_count;j++){
  audit[0]++;
  if(poll && poll(context))return -1;
  const Row *r=&rows[j]; const Cell *a=&board[r->source];
  if(a->owner!=(int)attacker || a->current!=(int)r->type)continue;
  audit[1]++;
  int eligible=1;
  if(r->clear)for(uint32_t k=0;k<r->path_count;k++){
   audit[2]++;
   if((k&31)==0 && poll && poll(context))return -1;
   if(board[paths[r->path_offset+k]].owner>=0){eligible=0;break;}
  }
  if(!eligible)continue;
  for(uint32_t k=0;k<r->guard_count;k++){
   audit[3]++;
   const Guard *g=&guards[r->guard_offset+k];
   int owner=g->owner<0?0:(int)attacker+1;
   int actual=aux[g->slot*3+owner];
   int expected=g->ref_kind==0?(int)target:g->ref_kind==1?(int)r->source:g->absolute;
   int equal=actual>=0 && actual==expected;
   if(g->unequal?equal:!equal){eligible=0;break;}
  }
  if(eligible)return 1;
 }
 return 0;
}

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdlib.h>
#include <string.h>
typedef struct {uint32_t area,types,slots;Row *rows;uint32_t rows_count;
 uint16_t *paths;uint32_t paths_count;Guard *guards;uint32_t guards_count;
 uint32_t *offsets;} Rules;
static void destroy(PyObject *cap){
 Rules *r=PyCapsule_GetPointer(cap,"_wide_readonly.rules");
 if(r){free(r->rows);free(r->paths);free(r->guards);free(r->offsets);free(r);}
}
static void *copied(const char *p,size_t n){
 void *v=malloc(n?n:1);if(v && n)memcpy(v,p,n);return v;
}
static PyObject *compile_rows(PyObject *self,PyObject *args){
 unsigned n,types,slots; const char *rb,*pb,*gb,*ob;Py_ssize_t rn,pn,gn,on;
 if(!PyArg_ParseTuple(args,"IIIy#y#y#y#",&n,&types,&slots,&rb,&rn,&pb,&pn,&gb,&gn,&ob,&on))return NULL;
 if(n<1||n>24||types<1||types>64||slots>8||rn%sizeof(Row)||pn%2||gn%sizeof(Guard)||on!=(2*n*n+1)*sizeof(uint32_t)){
  PyErr_SetString(PyExc_ValueError,"bad private readonly sizes");return NULL;}
 Rules *r=calloc(1,sizeof(*r));if(!r)return PyErr_NoMemory();
 r->area=n*n;r->types=types;r->slots=slots;r->rows_count=rn/sizeof(Row);
 r->paths_count=pn/2;r->guards_count=gn/sizeof(Guard);
 r->rows=copied(rb,rn);r->paths=copied(pb,pn);r->guards=copied(gb,gn);r->offsets=copied(ob,on);
 if(!r->rows||!r->paths||!r->guards||!r->offsets){free(r->rows);free(r->paths);free(r->guards);free(r->offsets);free(r);return PyErr_NoMemory();}
 int valid=r->offsets[0]==0 && r->offsets[2*r->area]==r->rows_count;
 for(uint32_t i=0;i<2*r->area;i++)if(r->offsets[i]>r->offsets[i+1]||r->offsets[i+1]>r->rows_count)valid=0;
 for(uint32_t i=0;i<r->rows_count;i++){
  Row *x=&r->rows[i];
  if(x->source>=r->area||x->type>=r->types||x->clear>1||
   (uint64_t)x->path_offset+x->path_count>r->paths_count||
   (uint64_t)x->guard_offset+x->guard_count>r->guards_count)valid=0;
 }
 for(uint32_t i=0;i<r->paths_count;i++)if(r->paths[i]>=r->area)valid=0;
 for(uint32_t i=0;i<r->guards_count;i++){
  Guard *g=&r->guards[i];
  if(g->slot<0||g->slot>=(int)slots||(g->owner!=-1&&g->owner!=0)||g->ref_kind<0||g->ref_kind>1||g->unequal<0||g->unequal>1)valid=0;
 }
 if(!valid){free(r->rows);free(r->paths);free(r->guards);free(r->offsets);free(r);PyErr_SetString(PyExc_ValueError,"bad private readonly static indices");return NULL;}
 return PyCapsule_New(r,"_wide_readonly.rules",destroy);
}
typedef struct {PyObject *callable,*etype,*evalue,*etrace;uint64_t polls;} Callback;
static int checkpoint(void *context){
 Callback *c=context; c->polls++;
 PyGILState_STATE state=PyGILState_Ensure();
 PyObject *v=PyObject_CallNoArgs(c->callable);
 if(!v)PyErr_Fetch(&c->etype,&c->evalue,&c->etrace);
 Py_XDECREF(v);int failed=v==NULL;PyGILState_Release(state);return failed;
}
static PyObject *query(PyObject *self,PyObject *args){
 PyObject *cap,*boardobj,*auxobj,*callback=Py_None;unsigned target,attacker;
 if(!PyArg_ParseTuple(args,"OOOII|O",&cap,&boardobj,&auxobj,&target,&attacker,&callback))return NULL;
 Rules *r=PyCapsule_GetPointer(cap,"_wide_readonly.rules");if(!r)return NULL;
 if(target>=r->area||attacker>1||(callback!=Py_None&&!PyCallable_Check(callback))){PyErr_SetString(PyExc_ValueError,"bad query");return NULL;}
 PyObject *b=PySequence_Fast(boardobj,"board sequence"),*a=PySequence_Fast(auxobj,"aux sequence");
 if(!b||!a){Py_XDECREF(b);Py_XDECREF(a);return NULL;}
 Cell *board=calloc(r->area,sizeof(Cell));int32_t *aux=calloc(r->slots*3+1,sizeof(int32_t));PyObject *answer=NULL;
 if(!board||!aux){PyErr_NoMemory();goto cleanup;}
 if(PySequence_Fast_GET_SIZE(b)!=r->area||PySequence_Fast_GET_SIZE(a)!=r->slots*3){PyErr_SetString(PyExc_ValueError,"incomplete board/aux");goto cleanup;}
 for(uint32_t i=0;i<r->area;i++){
  PyObject *item=PySequence_Fast_GET_ITEM(b,i);
  board[i].owner=-1;board[i].base=board[i].current=-1;
  if(item==Py_None)continue;
  PyObject *tuple=PySequence_Fast(item,"cell sequence");if(!tuple)goto cleanup;
  if(PySequence_Fast_GET_SIZE(tuple)!=4){Py_DECREF(tuple);PyErr_SetString(PyExc_ValueError,"bad cell");goto cleanup;}
  long v[4];
  for(int j=0;j<4;j++)v[j]=PyLong_AsLong(PySequence_Fast_GET_ITEM(tuple,j));
  Py_DECREF(tuple);if(PyErr_Occurred())goto cleanup;
  if(v[0]<0||v[0]>=r->types||v[1]<0||v[1]>=r->types||v[2]<0||v[2]>1||v[3]<0||v[3]>1){PyErr_SetString(PyExc_ValueError,"bad cell value");goto cleanup;}
  board[i]=(Cell){v[0],v[1],v[2],v[3]};
 }
 for(uint32_t i=0;i<r->slots*3;i++){
  long v=PyLong_AsLong(PySequence_Fast_GET_ITEM(a,i));if(PyErr_Occurred())goto cleanup;
  if(v<-1||v>=(long)r->area){PyErr_SetString(PyExc_ValueError,"aux range");goto cleanup;}aux[i]=v;
 }
 Callback ctx={callback,NULL,NULL,NULL,0}; uint64_t audit[4]={0};int result;
 uint32_t start=r->offsets[attacker*r->area+target],end=r->offsets[attacker*r->area+target+1];
 Py_BEGIN_ALLOW_THREADS
 result=wide_query(r->area,board,r->rows+start,end-start,r->paths,r->guards,aux,target,attacker,callback==Py_None?NULL:checkpoint,&ctx,audit);
 Py_END_ALLOW_THREADS
 if(ctx.etype){PyErr_Restore(ctx.etype,ctx.evalue,ctx.etrace);goto cleanup;}
 if(result<0){PyErr_SetString(PyExc_RuntimeError,"readonly failed");goto cleanup;}
 answer=Py_BuildValue("(iKKKKK)",result,audit[0],audit[1],audit[2],audit[3],ctx.polls);
cleanup:free(board);free(aux);Py_DECREF(b);Py_DECREF(a);return answer;
}
static PyMethodDef methods[]={{"compile",compile_rows,METH_VARARGS,NULL},{"query",query,METH_VARARGS,NULL},{NULL,NULL,0,NULL}};
static struct PyModuleDef module={PyModuleDef_HEAD_INIT,"_wide_readonly",NULL,-1,methods};
PyMODINIT_FUNC PyInit__wide_readonly(void){return PyModule_Create(&module);}
