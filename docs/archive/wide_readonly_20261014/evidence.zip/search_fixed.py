from cimport_smoke import *
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
import copy
out=D/'search-fixed';out.mkdir(exist_ok=True)
write_record(out/'declaration.json',dict(roots=['18aux0','18aux1','24aux0','24aux1'],q=[0,4],max_depth=6,max_nodes=1024,seconds=64,hardq=8,orders=['Core,C','C,Core'],planned_calls=32,expected_minutes=3,fuse_seconds=600,comparison='same generatedIR/fullhistory/profile/ordering/TT/stops. Candidate only explicit _gave_check hook; alllegaltransition/S3/S4 remainCore; compiletime separate and included totalpreparation; finite scoped subset not generalNative. Ordinary concurrent load. No adaptive cap extension.'))
rows=[];start=time.perf_counter()
for n in (18,24):
 for enabled in (False,True):
  c,pos,state=fixture(n,enabled);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
  for q in (0,4):
   for rep in range(2):
    for arm in (('core','c') if rep==0 else ('c','core')):
     p.rr.stopped();assert time.perf_counter()-start<600
     t=time.perf_counter();provider=CProvider(c) if arm=='c' else None
     player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev,check_provider=provider)
     session=GameSession(c);session._state=state
     before=session.to_record();prep=time.perf_counter()-t;t=time.perf_counter()
     d=player.choose_action(session,SearchLimits(max_depth=6,max_nodes=1024,max_time_seconds=64,quiescence_max_depth=q,quiescence_hard_max_depth=8))
     wall=time.perf_counter()-t
     assert before==session.to_record()
     child=state
     for a in d.principal_variation:
      assert a in legal_actions(child,c);child=apply_action(child,a,c)
     rows.append(dict(n=n,aux=enabled,q=q,rep=rep,arm=arm,wall=wall,prepare_seconds=prep,decision=record_value(d),provider=None if provider is None else dict(provider.stats),static=None if provider is None else provider.compile_counts,full_history_restored=True,pv_core_legal=True))
     write_record(out/'rows.json',dict(complete=False,rows=rows))
     print(n,enabled,q,rep,arm,round(wall,4),d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
