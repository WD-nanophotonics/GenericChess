from lazy_smoke import *
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.core.movegen import legal_actions
import threading
write_record(D/'search-cancel-v3-declaration.json',dict(sizes=[18,24],aux=[False,True],q=4,nodes=1024,time_limit=16,mechanism='ActualAlphaBetaPlayer checkpoint+CancellationToken: observeronlybyowner0/opponentlastanchor, eventatCpoll2; realkernelactive, threadnoinsertedwait. CompleteCorefallback/PV/history. Sixboundedcallswith4basicand2dense, notagentdelegation.'))
rows=[]
for n,dense in ((18,False),(24,False),(24,True)):
 for enabled in (False,True):
  c,pos,state=fixture(n,enabled)
  if dense:
   c=compile_ruleset_for_execution(deserialize_ruleset((D/'dense-rules.json').read_text(encoding='utf-8')))
   pos=replace(GameSession(c).state.position,aux_state=(((0,-1),(n-1,n-1) if enabled else None),))
   state=GameState(pos,0,(),TerminalResult(TerminalStatus.ONGOING),())
  provider=Provider(c);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
  active=threading.Event();token=CancellationToken();times={};inside=[False];query_events=[];active_id=[None];old=provider.query
  def observer(count):
   if token.is_cancelled():
    times.setdefault('cancel_seen_at_C_poll',time.perf_counter());times.setdefault('C_cancel_query_id',active_id[0])
   if count==2 and 'scheduled' not in times:times['scheduled']=time.perf_counter();times['scheduled_query_id']=active_id[0];active.set()
  def query(position,target,attacker,checkpoint=None,observer_unused=None):
   if target==n*n-1 and attacker==0:
    inside[0]=True;event=dict(id=len(query_events),enter=time.perf_counter(),exit=None);query_events.append(event);active_id[0]=event['id']
    try:return old(position,target,attacker,checkpoint=checkpoint,observer=observer)
    finally:event['exit']=time.perf_counter();inside[0]=False;active_id[0]=None
   return old(position,target,attacker,checkpoint=checkpoint)
  provider.query=query
  def request():
   if not active.wait(2):times['request_timeout']=True;return
   times['executed']=time.perf_counter();times['inside']=inside[0];times['executed_query_id']=active_id[0];token.cancel()
  thread=threading.Thread(target=request,name='project-bounded-real-search-cancel');thread.start()
  player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev,check_provider=provider)
  session=GameSession(c);session._state=state;session._search_history_witnesses=(state.position,)
  before=(session.state,session.to_record(),session._search_witnesses)
  decision=player.choose_action(session,SearchLimits(max_depth=6,max_nodes=1024,max_time_seconds=16,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token)
  times['decision_returned']=time.perf_counter();thread.join(2)
  assert not thread.is_alive() and before==(session.state,session.to_record(),session._search_witnesses)
  assert decision.termination_reason=='cancelled',decision.termination_reason
  assert decision.action is not None and decision.action in legal_actions(state,c)
  assert 'executed' in times and 'scheduled' in times
  rows.append(dict(n=n,dense=dense,aux=enabled,times=times,query_events=query_events,active_query_at_request=times['inside'],C_internal_cancel_observed=('cancel_seen_at_C_poll' in times),decision=record_value(decision),full_history_restored=True,returned_legal_fallback=True,execution_to_return=times['decision_returned']-times['executed']))
  print(n,enabled,decision.termination_reason,rows[-1]['execution_to_return'],flush=True)
write_record(D/'search-cancel-v3.json',dict(complete=True,rows=rows,actual_search_calls=6))
# Exact required exceptions must propagate after entering active C, not justentrypoll.
c,pos,state=fixture(24,False);provider=Provider(c);runtime=SearchPathRuntime.from_state(state,c)
move=next(a for a in runtime.legal_actions() if getattr(a,'from_square',None) is not None and a.from_square.rank==22 and a.from_square.file==21)
before=snapshot(runtime);errors=[]
for cls in (RuntimeError,KeyboardInterrupt):
 error=cls('active C callback required error')
 def fail(polls):
  if polls==3:raise error
 def callback(position,side,checkpoint=None):
  return provider.query(position,575,0,checkpoint=checkpoint,observer=fail)
 runtime._check_provider=callback
 try:runtime.push(move,checkpoint=lambda:None);raise AssertionError('activeerror missing')
 except BaseException as exc:assert exc is error
 assert snapshot(runtime)==before and provider(pos,1)==False
 errors.append(dict(type=cls.__name__,exact_exception=True,after_Centry=True,full_runtime_restored=True,next_query_usable=True))
write_record(D/'active-errors-v3.json',dict(complete=True,rows=errors,actual_runtime_failed_pushes=2))
