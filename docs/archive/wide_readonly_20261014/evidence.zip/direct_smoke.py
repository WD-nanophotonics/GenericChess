from pathlib import Path
import sys,json,time,traceback
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from direct_import import CProvider as Provider
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.position import GameState
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.research_record import write_record
D=Path(__file__).resolve().parent
def fixture(n,enabled):
 c=compile_ruleset_for_execution(deserialize_ruleset((ROOT/'.local_agent/frame-reply-20261014'/f'wide-aux-v2-{n}-rules.json').read_text(encoding='utf-8')))
 p=GameSession(c).state.position
 p=replace(p,aux_state=(((0,-1),(n-1,n-1) if enabled else None),))
 state=GameState(p,0,(),TerminalResult(TerminalStatus.ONGOING),())
 return c,p,state
def snapshot(r):
 return (r.position,r.ply_count,r.current_identity,r.runtime_hash,tuple(r.history),r.terminal_status,len(r._frames))
def run():
 write_record(D/'direct-smoke-declaration.json',dict(sizes=[18,24],aux=[False,True],query_all_targets_and_owners=True,normal_runtime_pushes=8,scope='Core-derived static capture row/private C ABI; path_clear/no-path and source/target square-slot eq/ne only; unsupported state/zone/other path or square refs return Core; no action codec/make/history/availability reuse. Full transitions remain Core.'))
 rows=[]
 for n in (18,24):
  for enabled in (False,True):
   c,p,state=fixture(n,enabled);t=time.perf_counter();provider=Provider(c)
   e=SemanticEngine(c);queries=0
   for owner in (0,1):
    for target in range(n*n):
     a=provider.query(p,target,owner);b=e.is_square_attacked(p,target,owner)
     assert a==b,(n,enabled,owner,target,a,b)
     queries+=1
   r=SearchPathRuntime.from_state(state,c,check_provider=provider)
   move=next(a for a in r.legal_actions() if getattr(a,'from_square',None) is not None and a.from_square.rank==n-2 and a.from_square.file==n-3 and a.to_square.rank==n-2 and a.to_square.file==n-2)
   before=snapshot(r);stats=dict(provider.stats)
   with r.pushed(move):
    assert r.in_check(1)==enabled and r.history[-1].gave_check==enabled
   assert snapshot(r)==before
   rows.append(dict(n=n,aux=enabled,static=provider.compile_counts,compile_seconds=provider.compile_seconds,all_target_queries=queries,stats=provider.stats,rollback=True,elapsed=time.perf_counter()-t))
 write_record(D/'direct-smoke.json',dict(complete=True,rows=rows,query_pairs=sum(x['all_target_queries'] for x in rows),actual_runtime_pushes=4))
 print(json.dumps(rows,indent=2))
if __name__=='__main__':run()
