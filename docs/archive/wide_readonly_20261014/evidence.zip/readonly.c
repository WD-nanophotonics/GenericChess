/* Isolated readonly feasibility kernel. No old ABI, action, make/unmake or globals.
   Numeric rows come exclusively from compiled Core capture IR.
   Same path-clear occupancy and square-slot equality semantics as existing scalar.
   Unsupported guards are rejected by the Python compiler, never silently omitted. */
#include <stdint.h>
typedef struct {int32_t base,current,owner,promoted;} Cell;
typedef struct {uint32_t source,type,path_offset,path_count,guard_offset,guard_count,clear;} Row;
typedef struct {int32_t slot,owner,ref_kind,absolute,unequal;} Guard;
typedef int (*Poll)(void);
__declspec(dllexport) int wide_query(uint32_t area, const Cell *board,
 const Row *rows, uint32_t row_count, const uint16_t *paths,
 const Guard *guards,const int32_t *aux,uint32_t target,uint32_t attacker,
 Poll poll,uint64_t *audit) {
 if(target>=area || attacker>1)return -2;
 audit[0]=audit[1]=audit[2]=audit[3]=0;
 if(poll && poll())return -1;
 for(uint32_t j=0;j<row_count;j++){
  audit[0]++;
  if(poll && poll())return -1;
  const Row *r=&rows[j]; const Cell *a=&board[r->source];
  if(a->owner!=(int)attacker || a->current!=(int)r->type)continue;
  audit[1]++;
  int eligible=1;
  if(r->clear)for(uint32_t k=0;k<r->path_count;k++){
   audit[2]++;
   if((k&31)==0 && poll && poll())return -1;
   if(board[paths[r->path_offset+k]].owner>=0){eligible=0;break;}
  }
  if(!eligible)continue;
  for(uint32_t k=0;k<r->guard_count;k++){
   audit[3]++;
   const Guard *g=&guards[r->guard_offset+k];
   int owner=g->owner<0?0:(int)attacker+1;
   int actual=aux[g->slot*3+owner];
   int expected=g->ref_kind==0?(int)target:g->ref_kind==1?(int)r->source:g->absolute;
   int equal=actual>=0 && actual==expected;
   if(g->unequal?equal:!equal){eligible=0;break;}
  }
  if(eligible)return 1;
 }
 return 0;
}
