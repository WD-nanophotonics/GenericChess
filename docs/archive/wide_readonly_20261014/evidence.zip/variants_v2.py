from cimport_smoke import *
from generic_chess.rules.schema import RuleSquareRef,RulePathConstraint,RuleStateGuard,RuleTypeRef,RuleSpatialSelector
from generic_chess.core.pieces import Piece
from generic_chess import _native_core
import _wide_readonly as native
import random,ctypes as C
write_record(D/'variants-v2-declaration.json',dict(sizes=[18,24],scope=['global','per_owner'],comparisons=['eq','ne'],refs=['source','target'],states_per_variant=8,boards='fixedRNG2026101401;typed arbitrary current/base promoted flags and20occupied squares;twoanchors fixed;aux None/matching/unmatching, exactCore alltargets bothowners',declined=['stateguard','pathcount','fixedref','boolaux'],not_reachable_training_curriculum=True,no_fitting=True))
rows=[];rng=random.Random(2026101401);pairs=0
for n in (18,24):
 definition=deserialize_ruleset((ROOT/'.local_agent/frame-reply-20261014'/f'wide-aux-v2-{n}-rules.json').read_text(encoding='utf-8'))
 initial=tuple(tuple(x if x is not None and x.current_type_id=='K' else None for x in row) for row in definition.initial_position)
 definition=replace(definition,initial_position=initial)
 original=definition.semantic_actions[0]
 for scope in ('global','per_owner'):
  for comparison in ('eq','ne'):
   for ref in ('source','target'):
    action=replace(original,aux_state=(replace(original.aux_state[0],scope=scope),),slot_guards=(replace(original.slot_guards[0],comparison=comparison,square_ref=RuleSquareRef(ref)),))
    d=replace(definition,semantic_actions=(action,));c=compile_ruleset_for_execution(d);provider=Provider(c);e=SemanticEngine(c);base=GameSession(c).state.position
    for case in range(8):
     board=[None]*(n*n);board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K')
     for square in rng.sample(range(1,n*n-1),20):
      current=rng.choice(('R','B'));basetype=rng.choice(('R','B'))
      board[square]=Piece(rng.randrange(2),basetype,current,basetype!=current)
     aux=tuple(((0,owner),(None if case%3==0 else ((n-1,n-1) if case%3==1 else (n-1,0)))) for owner in ((-1,) if scope=='global' else (0,1)))
     # Distinct owner values must not alias in per-owner view.
     if scope=='per_owner' and case%3:aux=(((0,0),(n-1,n-1)),((0,1),(n-1,0)))
     pos=replace(base,board=tuple(board),aux_state=aux)
     for owner in (0,1):
      for target in range(n*n):
       assert provider.query(pos,target,owner)==e.is_square_attacked(pos,target,owner),(n,scope,comparison,ref,case,owner,target)
       pairs+=1
    rows.append(dict(n=n,scope=scope,comparison=comparison,ref=ref,cases=8,pairs=8*n*n*2,stats=provider.stats))
    print(n,scope,comparison,ref,'ok',flush=True)
# Concrete capability rejections are not silently computed without guard.
declines=[]
original=definition.semantic_actions[0]
variants={
 'pathcount':replace(original,path_constraints=(RulePathConstraint('path_count_eq',count=0),)),
 'fixedref':replace(original,slot_guards=(replace(original.slot_guards[0],square_ref=RuleSquareRef('fixed',square=(n-1,n-1))),)),
 'stateguard':replace(original,state_guards=(RuleStateGuard(aggregation='exists',owner='self',type_ref=RuleTypeRef('explicit','R'),compare_field='current',promoted='any',location='board',spatial=RuleSpatialSelector('any')),)),
}
for label,action in variants.items():
 try:
  c=compile_ruleset_for_execution(replace(definition,semantic_actions=(action,)))
  try:Provider(c);raise AssertionError('unsupported accepted')
  except Unsupported as exc:declines.append(dict(label=label,error=str(exc)))
 except Exception as exc:
  if isinstance(exc,Unsupported):raise
  declines.append(dict(label=label,failed_before_prototype=type(exc).__name__,error=str(exc)))
c,pos,state=fixture(24,False);provider=Provider(c)
missing=replace(pos,aux_state=())
assert provider(missing,1) is None
r=SearchPathRuntime.from_state(state,c,check_provider=lambda p,side,checkpoint=None:None)
move=next(a for a in r.legal_actions() if getattr(a,'from_square',None) is not None and a.from_square.rank==22 and a.from_square.file==21)
before=snapshot(r)
with r.pushed(move):assert r.history[-1].gave_check==SemanticEngine(c).in_check(r.position,1)
assert snapshot(r)==before
isolations=[]
for name,call in [('old_rules',lambda:_native_core.semantic_in_check(provider.capsule,None,1)),('old_position',lambda:_native_core.semantic_in_check(None,provider.capsule,1))]:
 try:call();raise AssertionError('crossABI accepted')
 except (ValueError,TypeError) as exc:isolations.append(dict(name=name,error=str(exc)))
write_record(D/'variants-v2.json',dict(complete=True,rows=rows,query_pairs=pairs,declines=declines,missing_aux_declines=True,core_none_fallback_push_restored=True,capsule_isolation=isolations))
print(pairs,declines,isolations)
