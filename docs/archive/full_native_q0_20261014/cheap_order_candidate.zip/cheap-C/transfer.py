from pathlib import Path
import sys,json,time,hashlib,importlib.util
from types import SimpleNamespace
base=Path.cwd()/'.local_agent/full-backend-20261014';f=base/'compare.py';ns={'__file__':str(f),'__name__':'loader'};exec(compile(f.read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(f),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
from generic_chess.learning.material import LearnableMaterialCheckpoint
import generic_chess.native as native
out=base/'cheap-C/transfer';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists();names='all available frozen2501--2507 roots0/8; one priorunavailable notresampled,18explicitdecline'
write_record(out/'declaration.json',dict(question='Does the private cheap approximateC ordering transfer to the fixed2501--2507 rule inputs, keeping exact finite results andcompletehistory while changing onlyorderwork?',roots=names,base='8800b7fe, maininstalledkernel unchanged, existingexactmaterialorder',candidate='private copiedCmodule localtarget/promotion/drop delta, no handyield/offtarget simulation; approximateorder only. Fulltraversal legality/history/terminal/TT and existingcanonicalPV unchanged; actualfirstlegalchild guard for uncheckedrank candidates.',conditions='Botharms identical frozenactualstatic leafboard/hand table for4generated roots;flat100/0 semanticcontrols. Samefixedordercheckpoint, TT1MiB,coldengine,ordercacheoff,q0/hard0,rootwindowexactTrue. fixedD2/5s +resource1/4s,maxdepth12,twooppositeorders. No nodecap.',cost='132supportedcalls upper440s, expected<6min; oneboundedprocess, twoDLLimages selectedexplicitly percall and freshrulescapsule. No publishedC/default/UI/ABI/newflag or mainbinary edit; no extraAgent/fee.',decision='Any closedfixedD2fulltuple mismatch rejects candidatependingdiagnosis. Reducedtrialcount notgain byitself; usecaller/depth/retaineddecision curves, preserveworsecases. No exactrank/WDL admissiongate; statedapproximation and fulltarget intact.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
modules={'exact':native._module()};spec=importlib.util.spec_from_file_location('generic_chess._native_core',out.parent/'cheap_native_core.pyd');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate);modules['cheap']=candidate
bindings={'modules':{a:dict(filename=Path(m.__file__).name,sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()) for a,m in modules.items()},'profiles':[]};profiles={x['profile']['ruleset_fingerprint']:x['profile'] for x in json.loads((base/'profile-caller/profiles.json').read_text(encoding='utf-8'))['rows']};rows=[];cases=[]
transfer=json.loads((base/'ordering-transfer/samples.json').read_text(encoding='utf-8'));profiles.update({x['profile']['ruleset_fingerprint']:x['profile'] for x in transfer['setup']})
for x in transfer['samples']:
 if not x.get('included'):continue
 rule=deserialize_ruleset(json.dumps(x['ruleset']));raw=p.compile_legacy_ruleset_for_semantic_execution(rule);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);session=p.GameSession(c)
 for av in x['walk']:
  a,=[a for a in session.legal_actions() if record_value(a)==av];session.submit(a)
 assert record_value(session.state)==x['state']
 try:compile_native_semantic_rules(c)
 except NativeUnsupportedRuleError as error:
  rows.append(dict(root=x['name'],unsupported=str(error),planned_cells=12,actual_searches=0));continue
 cases.append((x['name'],c,session))
for name,c,s in cases:
 prof=profiles.get(c.ruleset_fingerprint)
 if prof:board=prof['board_value_by_type'];hand=prof['hand_value_by_base_type']
 else:board=Material(c).v;hand=board
 cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='private-fixed-material-order',board_weights={tid:float(v) for tid,v in board.items() if not c.support.type_metadata[tid].is_anchor},hand_weights={tid:float(v) for tid,v in hand.items() if not c.support.type_metadata[tid].is_anchor},value_scale=100000,reference_median=100,w_max=100000)
 bindings['profiles'].append(dict(root=name,board=board,hand=hand,ordering_checkpoint=record_value(cp)));write_record(out/'bindings.json',bindings);before=s.state,s.to_record(),s._search_witnesses
 for seconds,depth in [(5,2),(1,12),(4,12)]:
  for order in range(2):
   for arm in (('exact','cheap') if order==0 else ('cheap','exact')):
    p.rr.stopped();native._MODULE=modules[arm];t=time.perf_counter();nr=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,nr,board_values=board,hand_values=hand,ordering_checkpoint=cp,tt_megabytes=1,ordering_cache_enabled=False);prep=time.perf_counter()-t;d=engine.search(s,SearchLimits(max_depth=depth,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);assert before==(s.state,s.to_record(),s._search_witnesses)
    if d.declaration_id is not None:assert any(z.declaration_id==d.declaration_id for z in available_declarations(s.state,c))
    rows.append(dict(root=name,arm=arm,order=order,fixed=depth==2,seconds=seconds,prepare_seconds=prep,caller_seconds=time.perf_counter()-t,decision=record_value(d),root_unchanged=True,actual_module_sha256=bindings['modules'][arm]['sha256']));write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,depth,seconds,order,arm,d.completed_depth,d.score,d.nodes,d.ordering_material_view_trials,flush=True)
native._MODULE=modules['exact'];write_record(out/'rows.json',dict(complete=True,rows=rows))
