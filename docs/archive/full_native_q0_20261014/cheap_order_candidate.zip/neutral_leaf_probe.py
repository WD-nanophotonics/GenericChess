from pathlib import Path
import sys,json
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom
from test_no_contest_search import neutral,compile_session,Constant
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from scripts.research_record import record_value,write_record
rules=make_ruleset(4,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1)),RayAtom((1,0)),RayAtom((-1,0)))],lines=['k...','....','....','..RK'])
s=compile_session(replace(rules,declarations=(neutral(1,'NO_CONTEST','leaf_neutral'),)))
c=s.compiled;before=s.state,s.to_record(),s._search_witnesses
v={tid:0 if z.is_anchor else 100 for tid,z in c.support.type_metadata.items()}
class Ev(Constant):
 def evaluate(self,state):return 100 if state.position.side_to_move==0 else -100
 def type_value(self,tid):return v[tid]
 def capture_order_value(self,moving,captured):return 10*v[captured.current_type_id]-v[moving.current_type_id]
lim=SearchLimits(max_depth=1,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0)
rows=[]
for arm in ['Core','NativeTT0','NativeTT1']:
 if arm=='Core':d=AlphaBetaPlayer(c,evaluator_override=Ev(0),use_tt=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,lim)
 else:d=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=v,hand_values=v,tt_megabytes=0 if arm.endswith('0') else 1,ordering_cache_enabled=False).search(s,lim,root_window_pruning=True)
 row=dict(arm=arm,result=record_value(d))
 if d.action is not None:
  child=compile_session(replace(rules,declarations=(neutral(1,'NO_CONTEST','leaf_neutral'),)));child.submit(d.action);row['actual_child_result']=record_value(child.result);row['actual_declaration_result']=record_value(child.declare('leaf_neutral'))
 rows.append(row);assert before==(s.state,s.to_record(),s._search_witnesses)
write_record(ROOT/'.local_agent/full-backend-20261014/neutral-leaf-probe.json',dict(question='Does q0 Native leaf omit an actual available neutral declaration floor?',rows=rows));print([(x['arm'],x['result']['score'],x['actual_child_result']) for x in rows])
