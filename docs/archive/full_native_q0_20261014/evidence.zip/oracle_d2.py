from pathlib import Path
import json,time
base=Path.cwd()/'.local_agent/full-backend-20261014';ns={'__file__':str(base/'compare.py'),'__name__':'loader'};exec(compile((base/'compare.py').read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(base/'compare.py'),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
out=base/'oracle-D2';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists();write_record(out/'declaration.json',dict(question='Are different fixedD2 choices actual same-value ties or interface errors?',scope='Independent unpruned complete Core D2 with100/0 material; terminal before declaration, WIN at leaf,neutral floor,all legal responses. No TT/Native/q/reuse.20s and100000 successfultransition rootcap; capped rootUNKNOWN, never bestofpartial.',rootset='same19 full roots;no resampling',cost='19*20s<7min; no search-player calls, oracle transitions counted separately'))
rows=[]
class Cap(Exception):pass
for name,c,s in load_cases():
 p.rr.stopped();ev=Material(c);t=time.perf_counter();count=[0];values=[]
 def check():
  p.rr.stopped()
  if count[0]>=100000 or time.perf_counter()-t>=20:raise Cap()
 def advance(st,a):check();ch=apply_action(st,a,c);count[0]+=1;return ch
 def value(st,d,ply):
  check()
  if st.terminal_status.is_terminal:return terminal_score(st.terminal_status,st.position.side_to_move,ply)
  opts=available_declarations(st,c)
  if any(x.outcome=='WIN' for x in opts):return 1000000000-ply
  floor=0 if any(x.outcome in ('NO_CONTEST','RESTART') for x in opts) else -2000000000
  if d==0:return max(ev.evaluate(st),floor)
  best=floor
  for a in legal_actions(st,c):best=max(best,-value(advance(st,a),d-1,ply+1))
  return best
 before=s.state,s.to_record(),s._search_witnesses
 try:
  for a in legal_actions(s.state,c):values.append(dict(action=record_value(a),score=-value(advance(s.state,a),1,1)))
  opts=available_declarations(s.state,c);sc=[x['score'] for x in values]+[1000000000 if x.outcome=='WIN' else 0 for x in opts];result=dict(root=name,complete=True,maxscore=max(sc),declarations=record_value(opts),actions=values)
 except Cap:result=dict(root=name,complete=False,actions=values,reason='cap;no maxset claim')
 assert before==(s.state,s.to_record(),s._search_witnesses);result.update(transitions=count[0],seconds=time.perf_counter()-t,root_unchanged=True);rows.append(result);write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,result['complete'],count[0],round(result['seconds'],3),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))
