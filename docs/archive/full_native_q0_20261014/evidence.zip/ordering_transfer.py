from pathlib import Path
import sys,json,time,random,hashlib
from dataclasses import replace
base=Path.cwd()/'.local_agent/full-backend-20261014';f=base/'compare.py';ns={'__file__':str(f),'__name__':'loader'};exec(compile(f.read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(f),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.material import LearnableMaterialCheckpoint
out=base/'ordering-transfer';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does existing rule-profile child ordering transfer beyond four exposed12/16 roots while preserving exact finite output and1s/4s caller decisions?',premise='First intervention fixedD3 all8three-armtuplegroups match and lesssearchwork pays for checkedorderingviews. This prospective finite transfer isnot fitting weights or extending its budgets.',seeds=list(range(2501,2508)),sizes=[4,8,12,16,8,12,18],roots=[0,8],setup='bilateral_random,allow_hybridTrue,Random(seed+7000)reprsortedlegalwalk; recordimmutable snapshots;no terminalresampling',arms=['plain','flat100_order','frozen_rules_order'],leaf='same existing actual static rule-derived board/current+hand/base tables botharms,all dynamicbonuses0,scale1; ordercheckpoint uses exactlyfrozen ruleprofile,zero trainingupdates/no labels',budgets='fixedD2/5s plusresource1/4s,maxdepth12,oppositearmorders,coldfresh1MiBTT,ordercacheoff,rootwindowexactTrue. Complete initialhistory/events andactual GameSession retained;18 explicitunsupported.',cost='252cells upper720s with shortD2;expected<9min singlejob;no extraAgent/worker/fee,not longrun split',decision='CompleteD2fulltuple discrepancy blocks methodadoption. Transfer mixed/no completiongain narrows scope; positivecompletion doesnot establishWDL. No default/q4/UI/packet change or staticprice validation.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
cache=EvaluationProfileCache(use_disk=False);cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);samples=[];cases=[];setup=[]
for seed,size in zip(range(2501,2508),[4,8,12,16,8,12,18]):
 p.rr.stopped();t=time.perf_counter();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));raw=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);compile_seconds=time.perf_counter()-t;t=time.perf_counter();prof,_=cache.get_or_build(c,cfg);profile_seconds=time.perf_counter()-t;cp=LearnableMaterialCheckpoint.from_profile(c,prof);flat=replace(cp,board_weights={tid:100.0 for tid in cp.board_weights},hand_weights={tid:100.0 for tid in cp.hand_weights});assert cp.training_updates==flat.training_updates==0;setup.append(dict(seed=seed,compile_seconds=compile_seconds,profile_seconds=profile_seconds,profile=record_value(prof),ordering_checkpoint=record_value(cp),flat_ordering_checkpoint=record_value(flat)));s=p.GameSession(c);rng=random.Random(seed+7000);walk=[]
 for ply in range(9):
  actions=tuple(s.legal_actions())
  if ply in (0,8):
   samples.append(dict(name=f'{seed}-ply{ply}',ruleset=json.loads(serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk.copy(),included=bool(actions),legal_count=len(actions)))
   if actions:cases.append((f'{seed}-ply{ply}',c,prof,cp,flat,s.to_record(),s.state,s._search_witnesses))
  if ply==8:break
  if not actions:samples.append(dict(seed=seed,unavailable_ply=8,terminal_at=ply,resampled=False));break
  a=rng.choice(sorted(actions,key=repr));walk.append(record_value(a));s.submit(a)
write_record(out/'samples.json',dict(samples=samples,setup=setup));rows=[]
for name,c,prof,cp,flat,record,st,wit in cases:
 from types import SimpleNamespace
 # Actual immutable root adapter exposes the authoritative result contract.
 s=p.GameSession.replay(c,record);assert s.state==st and s._search_witnesses==wit;before=s.state,s.to_record(),s._search_witnesses
 try:nr=compile_native_semantic_rules(c)
 except NativeUnsupportedRuleError as error:
  rows.append(dict(root=name,unsupported=str(error),planned_cells=18,actual_searches=0));write_record(out/'rows.json',dict(complete=False,rows=rows));continue
 for seconds,depth in [(5,2),(1,12),(4,12)]:
  for order in range(2):
   for arm in (('plain','flat100_order','frozen_rules_order') if order==0 else ('frozen_rules_order','flat100_order','plain')):
    p.rr.stopped();t=time.perf_counter();engine=SemanticSearchEngine(c,nr,board_values=prof.board_value_by_type,hand_values=prof.hand_value_by_base_type,ordering_checkpoint=cp if arm=='frozen_rules_order' else flat if arm=='flat100_order' else None,tt_megabytes=1,ordering_cache_enabled=False);prep=time.perf_counter()-t;d=engine.search(s,SearchLimits(max_depth=depth,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);assert before==(s.state,s.to_record(),s._search_witnesses);rows.append(dict(root=name,arm=arm,order=order,fixed=depth==2,seconds=seconds,prepare_seconds=prep,caller_seconds=time.perf_counter()-t,search=record_value(d),root_unchanged=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,depth,seconds,order,arm,d.completed_depth,d.score,d.nodes,d.ordering_material_view_trials,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))
