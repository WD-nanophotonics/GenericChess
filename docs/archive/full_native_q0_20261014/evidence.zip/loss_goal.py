from pathlib import Path
import json,time,hashlib
base=Path.cwd()/'.local_agent/full-backend-20261014';ns={'__file__':str(base/'compare.py'),'__name__':'loader'};exec(compile((base/'compare.py').read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(base/'compare.py'),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')});rr=p.rr
out=base/'loss-goal';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
producer=ROOT/'.local_agent/root-transfer-20261014/positive_proof.py';consumer=ROOT/'.local_agent/root-transfer-20261014/consume_positive_proof.py'
write_record(out/'declaration.json',dict(question='Is the newly exposed fullNative compound_shift rootlossM6 real against all root-side defenses, rather than an evaluator/PV label?',selection='same resource rootcompound_shift,NativeTT0/1 predicts-100M+6,Coreq0 remains material-200 at1/4s',horizon=6,attacker=0,producer='existing independent literalCore all-defense solver',max_apply_per_case=50000,global_seconds=240,consumer='separate existing exact proof consumer if produced',decision='False retracts winning-band interpretation for this input; true supports finite information availability, not choosing better or shortestmate. UNKNOWN stayscensored; no extension.',source_hashes={str(x.name):hashlib.sha256(x.read_bytes()).hexdigest() for x in (producer,consumer)}))
name,c,s=next(x for x in load_cases() if x[0]=='compound_shift');before=s.state,s.to_record(),s._search_witnesses
text=producer.read_text(encoding='utf-8');frag=text[text.index('class Cap(Exception):'):text.index('rows=[]')];exec(compile(frag,str(producer),'exec'),globals())
try:
 answer,proof=prove(s.state,6,c,0);row=dict(root=name,attacker=0,h=6,proved_within_h=answer,unknown=False,proof=proof,apply_calls=calls,seconds=time.perf_counter()-start)
except Cap:row=dict(root=name,attacker=0,h=6,proved_within_h=None,unknown=True,apply_calls=calls,seconds=time.perf_counter()-start)
assert before==(s.state,s.to_record(),s._search_witnesses);write_record(out/'proof.json',row);print('producer',row['proved_within_h'],row['apply_calls'],row['seconds'],flush=True)
if not row['unknown']:
 text=consumer.read_text(encoding='utf-8');frag=text[text.index('calls=0;nodes=0'):text.index('rows=[]')];exec(compile(frag,str(consumer),'exec'),globals());t=time.perf_counter();v=consume(s.state,6,row['proof'],c,0);assert v is row['proved_within_h'];write_record(out/'independent-consumer.json',dict(verified=True,answer=v,nodes=nodes,actual_transitions=calls,seconds=time.perf_counter()-t,scope='Exact all-defense coverage,full Core terminals/declarations/history; separate consumer without searchscore/PV labels.'))
else:write_record(out/'independent-consumer.json',dict(verified=False,unknown=True,actual_transitions=0))
