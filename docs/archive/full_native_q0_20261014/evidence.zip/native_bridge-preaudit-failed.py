from pathlib import Path
import sys,json,time,hashlib,collections
ROOT=Path.cwd();base=ROOT/'.local_agent/full-backend-20261014';ns={'__file__':str(base/'compare.py'),'__name__':'loader'};exec(compile((base/'compare.py').read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(base/'compare.py'),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
from generic_chess.native import semantic as sem
from generic_chess.ai.evaluation.config import MATE_SCORE
out=base/'state-bridge';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does complete Native state execution save time for the SAME bare Python alpha-beta, separating algorithm/scheduling from Core transition/history cost?',roots='same19 frozen roots; explicit declines18board and declaration-thin scope',fixed_depth='generated4/8 depth4, generated12/16 depth3; active semantic depth4; two orders;10s cap each; trace paired then uninstrumented costpaired',arms=['Core plus Native legality/check/availability','complete Native capsule via existing public operations'],semantics='identical repr public-action ordering,100nonanchor0anchor material,Core1B mate units by exact terminalwinner; complete initial history and events,make_checked preserves childhistory. No TT/q/tactical/restart or homemade rules. Native scalar caller allocation/profile validation remains charged; not a bestpossible primitive C factor.',root_audit='all supported roots and full one-ply successor sets/material/terminal/full snapshot; compare exact imported snapshot includinghistory/events for every child. Count separately from searches.',cost='128calls:16roots*2order*2arms*2trace;10s cap each, upper1280s and expected<12min. Trace runs compare digest/work; uninstrumented runs for timing; do not call censored work matched.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
class NativeBoard:
 semantic_checkpoint_supported=False
 def __init__(self,c,s,ev):
  self.c=c;self.nr=compile_native_semantic_rules(c);self.nr.require_terminal_policy_support();self.initial=pack_semantic_search_position(c,self.nr,s);self.stack=[self.initial];self.initial_state=s.state;self.ev=ev;self.v=tuple(ev.v[t] for t in self.nr.type_ids);self.label=repr;self.root_side=s.state.position.side_to_move
 def actions(self):return sorted([(repr(sem.public_action(self.nr,a)),a) for a in sem.transient_legal_actions(self.nr,self.stack[-1])],key=lambda x:x[0])
 def push(self,a):self.stack.append(sem.make_checked(self.nr,self.stack[-1],a))
 def pop(self):self.stack.pop()
 def terminal(self,ply):
  result=sem.terminal_status(self.nr,self.stack[-1]);winner=result['winner'];side=self.root_side^((len(self.stack)-1)%2)
  return None if result['status']=='ongoing' else 0 if winner is None else MATE_SCORE-ply if winner==side else -MATE_SCORE+ply
 def evaluate(self):return sem.evaluate(self.nr,self.stack[-1],board_values=self.v,hand_values=self.v)
 def restored(self):return len(self.stack)==1 and self.stack[0] is self.initial
 def snapshot(self):
  d=sem.snapshot(self.nr,self.stack[-1]);t=self.nr.type_ids
  return (tuple(None if z is None else (z[2],t[z[0]],t[z[1]],bool(z[3])) for z in d['board']),tuple(tuple(sorted((tid,count) for tid,count in zip(t,h) if count)) for h in d['hands']),d['side'],d['aux_state'],d['ply'])
rows=[];audits=[]
for name,c,s in load_cases():
 p.rr.stopped()
 if c.ir.declarations:audits.append(dict(root=name,declined='thin adapter does not implement declaration competition'));continue
 try:right=NativeBoard(c,s,Material(c))
 except NativeUnsupportedRuleError as e:audits.append(dict(root=name,declined=str(e)));continue
 left=GenericBoard(c,s,Material(c));before=s.state,s.to_record(),s._search_witnesses;checked=[0]
 def audit(remaining):
  a=left.snapshot();b=right.snapshot();assert a==b,(name,a,b);assert left.evaluate()==right.evaluate();assert left.terminal(len(right.stack)-1)==right.terminal(len(right.stack)-1);checked[0]+=1
  # Entire exact history/aux/owner/type import is checked, not only position key.
  st=left.runtime.state
  expected=pack_semantic_search_position(c,right.nr,SimpleNamespace(state=st,_search_witnesses=tuple(s._search_witnesses)+tuple(history_path)))
  assert sem.snapshot(right.nr,expected)==sem.snapshot(right.nr,right.stack[-1])
  if left.terminal(len(right.stack)-1) is not None:return
  la=left.actions();ra=right.actions();assert [x[0] for x in la]==[x[0] for x in ra]
  if remaining:
   for (_,aa),(_,bb) in zip(la,ra):
    left.push(aa);right.push(bb);history_path.append(left.runtime.position)
    try:audit(remaining-1)
    finally:history_path.pop();right.pop();left.pop()
 history_path=[];t=time.perf_counter();audit(1);assert left.restored() and right.restored() and before==(s.state,s.to_record(),s._search_witnesses);audits.append(dict(root=name,states=checked[0],seconds=time.perf_counter()-t,full_history_equal=True));write_record(out/'audits.json',dict(complete=False,rows=audits))
 depth=4 if c.board_size<=8 else 3
 for trace in (True,False):
  for order in range(2):
   for arm in (('CoreNative','capsuleNative') if order==0 else ('capsuleNative','CoreNative')):
    p.rr.stopped();board=GenericBoard(c,s,Material(c)) if arm=='CoreNative' else NativeBoard(c,s,Material(c));t=time.perf_counter();r=bridge.minimal_ab(board,depth,seconds=10,node_limit=10**12,trace=trace,cooperative=arm=='CoreNative');wall=time.perf_counter()-t;assert board.restored();rows.append(dict(root=name,arm=arm,trace=trace,order=order,depth=depth,result=r,caller_seconds=wall,root_unchanged=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,trace,order,arm,r['completed_depth'],r['work']['nodes'],round(wall,4),flush=True)
write_record(out/'audits.json',dict(complete=True,rows=audits));write_record(out/'rows.json',dict(complete=True,rows=rows))
