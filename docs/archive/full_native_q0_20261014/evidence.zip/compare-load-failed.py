from pathlib import Path
import sys,json,time,random,hashlib,traceback
from types import SimpleNamespace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from scripts import full_q_refresh_comparison as p
from scripts import search_backend_comparison as bridge
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic import snapshot
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.declarations import available_declarations
from generic_chess.ai.alphabeta.search import terminal_score,reference_minimax
from test_no_contest_search import defender_root
out=ROOT/'.local_agent/full-backend-20261014';mode=sys.argv[1] if len(sys.argv)>1 else 'prepare'
class Material:
 def __init__(self,c):self.v={tid:0 if t.is_anchor else 100 for tid,t in c.support.type_metadata.items()}
 def evaluate(self,st):
  pos=st.position
  return sum((1 if z.owner==pos.side_to_move else -1)*self.v[z.current_type_id] for z in pos.board if z)+sum((1 if owner==pos.side_to_move else -1)*self.v[tid]*count for owner,h in enumerate(pos.hands) for tid,count in h.counts)
 def type_value(self,tid):return self.v[tid]
 def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
def load_cases():
 samples=json.loads((out/'samples.json').read_text(encoding='utf-8'))['samples'];cases=[]
 for x in samples:
  if not x.get('included'):continue
  if x['kind']=='fixture':
   s=defender_root();a,=[a for a in s.legal_actions() if record_value(a)==x['attack']];s.submit(a);assert record_value(s.state)==x['state'];cases.append((x['name'],s.compiled,s));continue
  r=deserialize_ruleset(json.dumps(x['ruleset']))
  if x['kind']=='generated':
   raw=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
  else:c=compile_ruleset_for_execution(r)
  s=p.GameSession(c)
  for av in x['walk']:
   a,=[a for a in s.legal_actions() if record_value(a)==av];s.submit(a)
  assert record_value(s.state)==x['state'];cases.append((x['name'],c,s))
 return cases
class GenericBoard(bridge.CoreBoard):
 def __init__(self,c,s,ev,native=True):
  self.compiled=c;self.initial=s.state;self.witnesses=s._search_witnesses;self.material=ev;self.checkpoint=None;self.label=repr
  provider=NativeSemanticLegalityProvider.try_create(c) if native else None;self.provider=provider
  self.runtime=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=provider,availability_provider=None if provider is None else provider.has_legal_action,check_provider=None if provider is None else provider.in_check)
def save(rows,complete):write_record(out/(mode+'-rows.json'),dict(complete=complete,rows=rows))
def query(name,c,s,arm,depth,seconds):
 p.rr.stopped();before=(s.state,s.to_record(),s._search_witnesses);ev=Material(c);start=time.perf_counter();decls=tuple(c.ir.declarations)
 if arm.startswith('thin'):
  if decls:return dict(unsupported='minimal adapter lacks general declaration competition; explicit decline, other arms retain complete rules')
  board=GenericBoard(c,s,ev,native=arm!='thinCore');prep=time.perf_counter()-start
  if depth is not None:d=bridge.minimal_ab(board,depth,seconds=seconds,node_limit=10**12,cooperative=True)
  else:d=bridge.iterative_minimal(board,seconds=seconds,node_limit=10**12,max_depth=12)
  board.runtime.assert_balanced();assert p.runtime_state(board.runtime)==p.runtime_state(SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses))
  lookup={repr(a):a for a in s.legal_actions()};a=lookup.get(d['move']);dec=None;d['action']=record_value(a);d['declaration_id']=None
  actual='Core' if board.provider is None else 'Core with actual Native legality/check/availability';d['provider_active']=board.runtime._legal_provider_active
 else:
  limits=SearchLimits(max_depth=12 if depth is None else depth,max_nodes=None,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0)
  if arm.startswith('native'):
   try:
    nr=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,nr,board_values=ev.v,hand_values=ev.v,tt_megabytes=1 if arm=='nativeTT1' else 0,ordering_cache_enabled=False)
    packed=snapshot(nr,pack_semantic_search_position(c,nr,s));assert packed['history_exact'] and packed['history_events_exact'] and len(packed['history'])==len(s.state.history)
   except NativeUnsupportedRuleError as e:return dict(unsupported=str(e),prepare_seconds=time.perf_counter()-start)
   prep=time.perf_counter()-start;value=engine.search(s,limits,root_window_pruning=True);d=record_value(value);dec=value.declaration_id;actual='full semantic Native';a=value.action
  else:
   player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True),use_native_semantic_availability=True,use_native_semantic_check=True)
   prep=time.perf_counter()-start;value=player.choose_action(s,limits);d=record_value(value);dec=None if value.declaration is None else value.declaration.declaration_id;d['declaration_id']=dec;actual='Core with Native provider' if player.native_legality_provider else 'Core fallback';a=value.action
  if dec is not None:assert any(x.declaration_id==dec for x in available_declarations(s.state,c))
  elif a is not None:assert a in s.legal_actions()
  st=s.state
  for x in value.principal_variation:assert x in legal_actions(st,c);st=apply_action(st,x,c)
 assert before==(s.state,s.to_record(),s._search_witnesses)
 return dict(actual_backend=actual,prepare_seconds=prep,caller_seconds=time.perf_counter()-start,search=d,root_unchanged=True,history_records=len(s.state.history))
if mode=='prepare':
 assert not(out/'declaration.json').exists();decl=dict(question='Does complete persistent Native q0 deliver useful decisions/completion on unfamiliar generated and active-semantic rules, versus current Core and same minimal Core bridge?',source='6c9c4fd82ad5b6698cbac65d8afe77c102af1815',generated_seeds=list(range(2401,2406)),sizes=[4,8,12,16,18],roots=[0,8],walk='Random(seed+7000), reprsorted legal; immutable state recorded before further moves, no terminal resampling',semantic_cases='all8 prior full-state played semantic fixtures plus checked_NO_CONTEST',arms=['thinNative','publicCore','nativeTT0','nativeTT1'],controls='fixedD2 with5s cap,two opposite orders; resource1s/4s,two opposite orders; all fresh player/TT. Same100nonanchor/0anchor board/current-hand/base material, no spatial/dynamic/learned eval. q0/hard0, root tactical off. maxdepth12 resource ceiling, no node cap except minimal administrative1e12.',interpretation='Native terminal100M vs Core1B normalize sign/distance; exact shared-D2 action maxsets, not numeric-unit failure. Algorithms/comparators/TT differ; no pure backend timing factor, deeper isnot strength. TT1 is separate Native cache ablation. Caller includes construction and public validation, budget applies kernel/search; no exact wholecaller deadline claim.',unsupported='Explicit decline only, no silent q4 downgrade or projection. Full task retains promotion/drop/aux/history/declarations and>16 board cases.',expected_cost='Resource304calls upper760s plus fixed152calls cap760s; one sequential producer estimated<30min, no extra worker/fee; smaller exact controls precede usefulness audit',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out/'declaration.json',decl)
 samples=[]
 for seed,size in zip(decl['generated_seeds'],decl['sizes']):
  g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));raw=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=p.GameSession(c);rng=random.Random(seed+7000);walk=[]
  for ply in range(9):
   actions=tuple(s.legal_actions())
   if ply in [0,8]:samples.append(dict(name=f'{seed}-ply{ply}',kind='generated',ruleset=json.loads(serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk.copy(),included=bool(actions),legal_count=len(actions)))
   if ply==8:break
   if not actions:samples.append(dict(name=f'{seed}-ply8',included=False,terminal_at=ply));break
   a=rng.choice(sorted(actions,key=repr));s.submit(a);walk.append(record_value(a))
 old=json.loads((ROOT/'.local_agent/root-transfer-20261014/semantic/samples.json').read_text(encoding='utf-8'))
 for x in old['rows']:
  samples.append(dict(name=x['name'],kind='semantic',ruleset=x['ruleset'],state=x['state'],walk=x['game_record']['actions'],included=True))
 s=defender_root();old=json.loads((ROOT/'.local_agent/native-payload-20261014/fallback-real-loss.json').read_text(encoding='utf-8'));a,=[x for x in s.legal_actions() if record_value(x)==old['attack_decision']['action']];s.submit(a)
 samples.append(dict(name='checked_NO_CONTEST',kind='fixture',attack=record_value(a),state=record_value(s.state),walk=record_value(s.to_record())['actions'],included=True))
 write_record(out/'samples.json',dict(samples=samples));print('prepared',len(samples),flush=True)
else:
 assert not(out/(mode+'-rows.json')).exists();rows=[];cases=load_cases()
 for name,c,s in cases:
  for sec in ([5] if mode=='fixed' else [1,4]):
   for order in range(2):
    for arm in (['thinNative','publicCore','nativeTT0','nativeTT1'] if order==0 else ['nativeTT1','nativeTT0','publicCore','thinNative']):
     row=dict(root=name,arm=arm,order=order,seconds=sec,depth=2 if mode=='fixed' else None)
     try:row.update(query(name,c,s,arm,row['depth'],sec))
     except Exception as e:row.update(error=repr(e),traceback=traceback.format_exc());rows.append(row);save(rows,False);raise
     rows.append(row);save(rows,False);print(name,sec,order,arm,row.get('search',{}).get('completed_depth'),row.get('search',{}).get('score'),row.get('unsupported'),flush=True)
 save(rows,True)
