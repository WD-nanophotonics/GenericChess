from pathlib import Path
import json,time
base=Path.cwd()/'.local_agent/full-backend-20261014';f=base/'compare.py';ns={'__file__':str(f),'__name__':'loader'};exec(compile(f.read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(f),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
out=base/'choice-D3';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists();cases={x[0]:x[1:] for x in load_cases()};sources={'flat':json.loads((base/'resource-rows.json').read_text(encoding='utf-8'))['rows'],'profile':json.loads((base/'profile-caller/rows.json').read_text(encoding='utf-8'))['rows']};profiles=json.loads((base/'profile-caller/profiles.json').read_text(encoding='utf-8'))['rows'];prof={row['root'].split('-')[0]:row['profile'] for row in profiles};selected={};pairs=[]
for family,rows in sources.items():
 for x in rows:
  if x['arm'] not in ('nativeTT0','nativeTT1') or 'search' not in x or (family=='profile' and x['mode']!='resource'):continue
  other=next(y for y in rows if y['root']==x['root'] and y['seconds']==x['seconds'] and y['order']==x['order'] and y['arm']=='publicCore' and (family=='flat' or y['mode']=='resource'))
  if x['search']['action']==other['search']['action'] and x['search'].get('declaration_id')==other['search'].get('declaration_id'):continue
  c,s=cases[x['root']]
  if c.ir.declarations:continue
  keys=[]
  for r in (other,x):
   action=r['search']['action'];key=(family,x['root'],json.dumps(action,sort_keys=True));selected[key]=action;keys.append(key)
  pairs.append(dict(family=family,root=x['root'],seconds=x['seconds'],order=x['order'],native_arm=x['arm'],core_depth=other['search']['completed_depth'],native_depth=x['search']['completed_depth'],core_key=keys[0],native_key=keys[1]))
write_record(out/'declaration.json',dict(question='Do observed changed equal-budget choices improve a separately defined fixedD3 static-material diagnostic or merely differ?',selection='All differing paired choices in already closed flat/profile1/4s curves, shared family/evaluator input. No selecting favorableoutcomes; identicalactions needzero newevaluation.',branches=len(selected),pairs=len(pairs),objective='Negated complete pureCore bareAB D2 after actual chosen rootmove, hence rootD3 with original flat100/0 or frozen staticprofile. No Native/TT/q/tactical; complete fullhistory. Different actual delivereddepths stay recorded; a D3-value difference is not WDL, universalgain or evidence a deeper choice is worse.',cost='10s per distinctbranch,240s global, no extension; predeclared capped/notstarted remainUNKNOWN; up to4min. No fullWDL admission requirement.'))
class Static(Material):
 def __init__(self,c,name):self.v=prof[name.split('-')[0]]['board_value_by_type'];self.h=prof[name.split('-')[0]]['hand_value_by_base_type']
 def evaluate(self,st):
  pos=st.position;return sum((1 if z.owner==pos.side_to_move else -1)*self.v[z.current_type_id] for z in pos.board if z)+sum((1 if owner==pos.side_to_move else -1)*self.h[tid]*count for owner,h in enumerate(pos.hands) for tid,count in h.counts)
start=time.perf_counter();results={};rows=[];queries=0
for key,av in selected.items():
 family,name,_=key;c,s=cases[name];left=240-(time.perf_counter()-start)
 if left<=0:results[key]=dict(complete=False,unknown=True,not_started=True);continue
 p.rr.stopped();before=s.state,s.to_record(),s._search_witnesses;a,=[a for a in s.legal_actions() if record_value(a)==av];child=apply_action(s.state,a,c);ev=Material(c) if family=='flat' else Static(c,name);childs=SimpleNamespace(state=child,_search_witnesses=s._search_witnesses+(child.position,));board=GenericBoard(c,childs,ev,native=False);t=time.perf_counter();r=bridge.minimal_ab(board,2,seconds=min(10,left),node_limit=10**12,cooperative=True);queries+=1;score=None
 if r['reason']=='completed_depth':
  score=-r['score']
  if abs(score)>900000000:score=score-1 if score>0 else score+1
 result=dict(complete=r['reason']=='completed_depth',unknown=r['reason']!='completed_depth',value=score,result=r,seconds=time.perf_counter()-t);results[key]=result;rows.append(dict(family=family,root=name,action=av,**result));assert before==(s.state,s.to_record(),s._search_witnesses);write_record(out/'branches.json',dict(complete=False,queries=queries,rows=rows));print(family,name,result['complete'],score,r['work']['nodes'],flush=True)
assessed=[]
for pair in pairs:
 a=results[tuple(pair['core_key'])];b=results[tuple(pair['native_key'])];rec={k:v for k,v in pair.items() if k not in ('core_key','native_key')};rec.update(core_value=a.get('value'),native_value=b.get('value'),complete=a['complete'] and b['complete']);rec['difference']=b['value']-a['value'] if rec['complete'] else None;assessed.append(rec)
write_record(out/'branches.json',dict(complete=True,queries=queries,selected_branches=len(selected),seconds=time.perf_counter()-start,rows=rows,not_started=sum(x.get('not_started',False) for x in results.values())));write_record(out/'pairs.json',dict(rows=assessed,scope='Exposed finite fixedD3 diagnostic only; cannot turn changed choices/deeper output into actualwin claim. FullCore terminals/history/zero declarations where applicable retained.'))
