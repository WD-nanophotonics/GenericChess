from pathlib import Path
import sys,json,time,hashlib
from dataclasses import replace
base=Path.cwd()/'.local_agent/full-backend-20261014';f=base/'compare.py';ns={'__file__':str(f),'__name__':'loader'};source=f.read_text(encoding='utf-8').split("if mode=='prepare':")[0];source=source.replace('hand_values=ev.v','hand_values=ev.h');exec(compile(source,str(f),'exec'),ns)
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.native import semantic as sem
record_value=ns['record_value'];write_record=ns['write_record'];out=base/'profile-caller';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does complete Native q0 remain a useful reference with the actual frozen rule-derived static board/hand vector, and does first profile setup dominate the1s decisionbudget?',changed_premise='Original matched assays used arbitrary100/0 material. This separately binds real existing generator profile, unchanged handdiscount, promotion/currenttype/basehand values; no learned/human labels, no fit or defaultchange.',roots='same10 alreadyexposed generated4/8/12/16/18 roots0/8, no resampling, not newholdout',evaluator='Existing EvaluationConfig with dynamic_mobility_weight,anchor_escape_weight,promotion_potential_weight zero; actual Evaluator staticprofile; Native gets exactboard andhand vectors separately, scale1. Full defaultdynamic model is not claimed aligned.',controls='five cold profileget/build + actual samecache memory hits; fulloneply material equality before search. fixedD2/5s and resource1s/4s,CoreNativeTT0 versus fullNativeTT1,two reversed orders,freshplayers/TT; maxdepth12,q0/hard0,no node limit. Constructor/callervssearchkernel reported.',cost='120cells upper400s;5profile builds+leafaudit expected<3min, total<12min single sequential job;18Native explicitlyunsupported; no extra worker/fee',decision='Mismatching statevalue blocks pairing; otherwise completion/usefulness and coldsetupcost select reuse of existingprofilecache or reject automatic fullNative adoption. Not pricevalidation/universalratio/strength or q4 downgrade.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
cache=EvaluationProfileCache(use_disk=False);cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profiles={};setup=[];start=time.perf_counter();cases=[x for x in ns['load_cases']() if x[0][0].isdigit()];load_seconds=time.perf_counter()-start
for name,c,s in cases:
 if c.ruleset_fingerprint in profiles:continue
 ns['p'].rr.stopped();t=time.perf_counter();prof,hit=cache.get_or_build(c,cfg);cold=time.perf_counter()-t;assert not hit;t=time.perf_counter();hot,hit=cache.get_or_build(c,cfg);warm=time.perf_counter()-t;assert hit and hot==prof;profiles[c.ruleset_fingerprint]=prof;setup.append(dict(root=name,cold_seconds=cold,memory_hit_seconds=warm,profile=record_value(prof),config=record_value(cfg)));write_record(out/'profiles.json',dict(complete=False,load_complete_roots_seconds=load_seconds,rows=setup));print('profile',name,round(cold,4),round(warm,6),flush=True)
class Static:
 def __init__(self,c):
  prof=profiles[c.ruleset_fingerprint];self.v=dict(prof.board_value_by_type);self.h=dict(prof.hand_value_by_base_type);self.ev=Evaluator(c,prof,cfg)
 def evaluate(self,st):return self.ev.evaluate(st)
 def type_value(self,tid):return self.ev.type_value(tid)
 def capture_order_value(self,a,b):return self.ev.capture_order_value(a,b)
ns['Material']=Static;audits=[]
for name,c,s in cases:
 ev=Static(c);t=time.perf_counter();states=[s.state];states.extend(ns['apply_action'](s.state,a,c) for a in ns['legal_actions'](s.state,c));count=0
 try:
  nr=ns['compile_native_semantic_rules'](c);ns['SemanticSearchEngine'](c,nr,board_values=ev.v,hand_values=ev.h,tt_megabytes=0,ordering_cache_enabled=False)
 except ns['NativeUnsupportedRuleError'] as e:audits.append(dict(root=name,declined=str(e)));continue
 for st in states:
  packed=sem.pack_current_position(nr,st.position,ply_count=st.ply_count);v=tuple(ev.v[tid] for tid in nr.type_ids);h=tuple(ev.h[tid] for tid in nr.type_ids);assert ev.evaluate(st)==sem.evaluate(nr,packed,board_values=v,hand_values=h);count+=1
 audits.append(dict(root=name,states=count,seconds=time.perf_counter()-t,equal=True))
write_record(out/'profiles.json',dict(complete=True,load_complete_roots_seconds=load_seconds,rows=setup));write_record(out/'leaf-audits.json',dict(rows=audits,scope='Staticevaluator only, state-only carrier intentionally, not history/terminal proof. Search below imports completehistory.'))
rows=[]
for mode,sec,depth in [('fixed',5,2),('resource',1,None),('resource',4,None)]:
 for name,c,s in cases:
  for order in range(2):
   for arm in (('publicCore','nativeTT1') if order==0 else ('nativeTT1','publicCore')):
    row=dict(root=name,mode=mode,seconds=sec,depth=depth,order=order,arm=arm);row.update(ns['query'](name,c,s,arm,depth,sec));rows.append(row);write_record(out/'rows.json',dict(complete=False,rows=rows));print(mode,name,sec,order,arm,row.get('search',{}).get('completed_depth'),row.get('search',{}).get('score'),row.get('unsupported'),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))
