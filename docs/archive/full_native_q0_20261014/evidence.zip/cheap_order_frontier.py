from pathlib import Path
import json,time,hashlib
base=Path.cwd()/'.local_agent/full-backend-20261014';f=base/'compare.py';ns={'__file__':str(f),'__name__':'loader'};exec(compile(f.read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(f),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
from generic_chess.core.coordinates import square_to_index
out=base/'cheap-order-frontier';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Before adding anynew C ordering path, how often does a verycheap generic currenttarget/promotion/drop material-delta approximation preserve exact childstatic ordering on the complete tested frontiers?',motivation='Observed discardedfullmaterialorderingviews reach millions per caller while buying horizons; a cheaper approximate ordering is eligible without changing legality/search domain. First inspect realcompound/offtarget/hand effects, not assume only conventionalcaptures.',roots='all19 original fullinput roots plus14 freshtransfer roots, includingunsupported18 throughCore. Original/freshgenerated actualfrozenstaticprofiles; eightsemantic+NC100/0 flatcontrol,explicitdifferent evaluator scope.',approximation='current enemy target boardvalue + explicit promotion valuechange; drop boardminushandvalue. Ignores off-targeteffects, handcaptureyield, compoundtransforms/otherconditional effects. No legality filtering/pruning or pricefit; NOT claimed exact.',evidence='All actual Core legal rootactions, actual complete Core apply_action and childstaticeval delta.10s perroot/120s global; capped rootUNKNOWN and no fullmaxset claim. Root state/history restored. Top-tie coverage, not WDL/playinggain. Cost is Python cheapfeature vsCorefulltransition only, not C speedfactor.',decision='If clear specialeffect disagreements, keepthose limits and test approximateordering behavior in a future actualsearch only ifworthcost; do not require exactsorting for development or build framework. No product/default/newkernel/training in thisstage.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
profiles={x['profile']['ruleset_fingerprint']:x['profile'] for x in json.loads((base/'profile-caller/profiles.json').read_text(encoding='utf-8'))['rows']};source=json.loads((base/'ordering-transfer/samples.json').read_text(encoding='utf-8'));profiles.update({x['profile']['ruleset_fingerprint']:x['profile'] for x in source['setup']});cases=load_cases()
for x in source['samples']:
 if not x.get('included'):continue
 rule=deserialize_ruleset(json.dumps(x['ruleset']));raw=p.compile_legacy_ruleset_for_semantic_execution(rule);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=p.GameSession(c)
 for av in x['walk']:
  a,=[a for a in s.legal_actions() if record_value(a)==av];s.submit(a)
 assert record_value(s.state)==x['state'];cases.append((x['name'],c,s))
class Static(Material):
 def __init__(self,c):
  prof=profiles.get(c.ruleset_fingerprint)
  if prof is None:super().__init__(c);self.h=self.v
  else:self.v=prof['board_value_by_type'];self.h=prof['hand_value_by_base_type']
 def evaluate(self,st):
  pos=st.position;return sum((1 if z.owner==pos.side_to_move else -1)*self.v[z.current_type_id] for z in pos.board if z)+sum((1 if owner==pos.side_to_move else -1)*self.h[tid]*count for owner,h in enumerate(pos.hands) for tid,count in h.counts)
start=time.perf_counter();rows=[];count=0
for name,c,s in cases:
 p.rr.stopped();before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter();ev=Static(c);initial=ev.evaluate(s.state);actions=tuple(legal_actions(s.state,c));vals=[];cheap_seconds=0.;full_seconds=0.;complete=True
 for a in actions:
  if time.perf_counter()-start>=120 or time.perf_counter()-t>=10:complete=False;break
  p.rr.stopped();q=time.perf_counter();score=0;pos=s.state.position
  if hasattr(a,'from_square'):
   victim=pos.board[square_to_index(a.to_square,c.board_size)];actor=pos.board[square_to_index(a.from_square,c.board_size)]
   if victim is not None and victim.owner!=pos.side_to_move:score+=ev.v[victim.current_type_id]
   target=getattr(a,'promotion_target_id',None)
   if target is not None:score+=ev.v[target]-ev.v[actor.current_type_id]
  elif hasattr(a,'base_type_id'):score+=ev.v[a.base_type_id]-ev.h[a.base_type_id]
  cheap_seconds+=time.perf_counter()-q;q=time.perf_counter();child=apply_action(s.state,a,c);count+=1;actual=-ev.evaluate(child)-initial;full_seconds+=time.perf_counter()-q;vals.append(dict(action=record_value(a),approx_delta=score,actual_delta=actual,child_terminal=record_value(child.terminal_status)))
 assert before==(s.state,s.to_record(),s._search_witnesses)
 result=dict(root=name,complete=complete,actions_total=len(actions),actions_evaluated=len(vals),actual_child_deltas=vals,cheap_seconds=cheap_seconds,full_Core_seconds=full_seconds,seconds=time.perf_counter()-t,root_unchanged=True)
 if complete and vals:
  exact=max(x['actual_delta'] for x in vals);best=max(x['approx_delta'] for x in vals);chosen=[x for x in vals if x['approx_delta']==best];result.update(exact_max_delta=exact,cheap_best_delta=best,cheap_top_intersects_exact_max=any(x['actual_delta']==exact for x in chosen),cheap_all_top_are_exact_max=all(x['actual_delta']==exact for x in chosen),delta_match_count=sum(x['actual_delta']==x['approx_delta'] for x in vals))
 rows.append(result);write_record(out/'rows.json',dict(complete=False,actual_Core_transitions=count,rows=rows));print(name,complete,len(vals),result.get('cheap_top_intersects_exact_max'),round(result['seconds'],3),flush=True)
write_record(out/'rows.json',dict(complete=True,actual_Core_transitions=count,seconds=time.perf_counter()-start,rows=rows))
