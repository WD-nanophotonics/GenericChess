from pathlib import Path
import sys,json,cProfile,pstats,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
OUT=Path('.local_agent/current-bridge-20261013')
def save(n,v): (OUT/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
assert not (OUT/'cost-plan.json').exists()
save('cost-plan.json',dict(question='Does same-USI/no-profiler fixed tree still show Core runtime cost, and which actual functions account for it?',calls='8 uninstrumented fixed plus2 matching-tree profiled; D3 middle/D6 promotion, two opposite orders',scope='No production change or rerun of equal-time plane; profiler attribution overlaps and adds overhead'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi')); rows=[]; prof=[]
for case in [x for x in CASES if x['id'] in ('shogi-middle','shogi-promotion')]:
    provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
    cb=CoreBoard(case,c,provider=provider); sb=ShogiBoard(case);depth=3 if case['id']=='shogi-middle' else 6
    for rep in range(2):
        for arm,b in ([('specialized',sb),('core_native',cb)] if rep==0 else [('core_native',cb),('specialized',sb)]):
            r=minimal_ab(b,depth,seconds=30,node_limit=10**12,trace=False)
            rows.append(dict(case=case['id'],repeat=rep,arm=arm,**r));save('fixed-cost.json',rows)
            print(case['id'],rep,arm,r['wall_seconds'],r['work']['nodes'],flush=True)
    if case['id']=='shogi-middle':
        for arm,b in [('specialized',sb),('core_native',cb)]:
            pp=cProfile.Profile(); pp.enable()
            r=minimal_ab(b,depth,seconds=30,node_limit=10**12,trace=False)
            pp.disable();pp.dump_stats(str(OUT/(arm+'-private.pstats')))
            stat=pstats.Stats(pp)
            top=[]
            for (filename,line,fn),(cc,nc,tt,ct,callers) in sorted(stat.stats.items(),key=lambda item:item[1][3],reverse=True)[:45]:
                top.append(dict(module=Path(filename).name,line=line,function=fn,primitive_calls=cc,calls=nc,self_seconds=tt,cumulative_seconds=ct))
            prof.append(dict(arm=arm,result=r,functions=top))
            save('profile-summary.json',prof)
            print('profile',arm,r['wall_seconds'],r['work']['nodes'],flush=True)
checks=[]
for case in ['shogi-middle','shogi-promotion']:
    group=[x for x in rows if x['case']==case];x=group[0]
    checks.append(dict(case=case,all_work_result_exact=all((r['move'],r['score'],r['work'],r['completed_depth'])==(x['move'],x['score'],x['work'],x['completed_depth']) for r in group)))
save('cost-checks.json',checks);assert all(x['all_work_result_exact'] for x in checks)
