from pathlib import Path
import sys,json,cProfile,pstats
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
OUT=Path('.local_agent/current-bridge-20261013')
assert not (OUT/'full-availability-profile-plan.json').exists()
(OUT/'full-availability-profile-plan.json').write_bytes(json.dumps(dict(question='After existing availability alignment, which required Core push cost remains?',calls=1,case='shogi-middle',depth=3,seconds=30,expected_nodes=10426,interpretation='Instrumentation attribution only; no throughput/factor addition')).encode())
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));case=next(x for x in CASES if x['id']=='shogi-middle');p=NativeSemanticLegalityProvider.try_create(c,strict=True);b=CoreBoard(case,c,provider=p)
b.runtime=SearchPathRuntime.from_state(b.initial,c,history_witnesses=b.witnesses,legal_binding_provider=p,availability_provider=p.has_legal_action)
pp=cProfile.Profile();pp.enable();r=minimal_ab(b,3,seconds=30,node_limit=10**12);pp.disable();pp.dump_stats(str(OUT/'full-availability-private.pstats'));st=pstats.Stats(pp);rows=[]
for (filename,line,fn),(cc,nc,tt,ct,callers) in sorted(st.stats.items(),key=lambda it:it[1][3],reverse=True)[:55]:
    rows.append(dict(module=Path(filename).name,line=line,function=fn,calls=nc,self_seconds=tt,cumulative_seconds=ct))
assert r['completed_depth']==3 and r['score']==0 and r['move']=='2h2d' and r['work']['nodes']==10426 and r['runtime_counters']['legal_provider_fallbacks']==0
(OUT/'full-availability-profile.json').write_bytes(json.dumps(dict(result=r,availability=p.availability_metrics,functions=rows),indent=2).encode())
print([(x['module'],x['function'],round(x['self_seconds'],4),round(x['cumulative_seconds'],4),x['calls']) for x in rows[:24]],flush=True)
