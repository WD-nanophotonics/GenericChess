from pathlib import Path
import sys,json,time,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
OUT=Path('.local_agent/current-bridge-20261013')
def save(n,v): (OUT/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
plan={'question':'Does full D2 argmax explain differing canonical moves, and is the primitive gap present with identical visited sequences?', 'new_calls':'each actual root child D1 specialized, plus two repeats USI fixedD3 middle/fixedD6 promotion specialized/Core Native and two repeats packed same horizons; no new optimized search/value/default'}
assert (OUT/'qualification-plan.json').exists()
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi')); n=compile_native_semantic_rules(c)
rows=[];argmax=[]
class PackedCore(CoreBoard):
    def actions(self):
        return sorted(super().actions(),key=lambda pair:pack_semantic_action(n,self.runtime.position,pair[1]))
class PackedSpecial(ShogiBoard):
    def actions(self):
        from generic_chess.learning.shogi_rules import sfen_to_gc_state
        from generic_chess.core.movegen import legal_actions
        state=sfen_to_gc_state(c,self.board.sfen())
        labels={gc_action_to_usi(a):a for a in legal_actions(state,c)}
        return sorted(super().actions(),key=lambda pair:pack_semantic_action(n,state.position,labels[pair[0]]))
for case in [x for x in CASES if x['id'] in ('shogi-middle','shogi-promotion')]:
    b=ShogiBoard(case);allvals=[]
    oldterminal=b.terminal
    b.terminal=lambda ply:oldterminal(ply+1)
    for label,move in b.actions():
        b.push(move)
        root_sfen,root_history=b.root_sfen,b.root_history
        b.root_sfen,b.root_history=b.board.sfen(),tuple(b.history)
        try:r=minimal_ab(b,1,seconds=10,node_limit=10**12)
        finally:
            b.root_sfen,b.root_history=root_sfen,root_history
            b.pop()
        assert r['reason']=='completed_depth'
        allvals.append({'move':label,'root_score':-r['score'],'child_work':r['work']})
    b.terminal=oldterminal
    best=max(x['root_score'] for x in allvals)
    argmax.append({'case':case['id'],'depth':2,'score':best,'argmax':[x['move'] for x in allvals if x['root_score']==best],'all_children':allvals,'calls':len(allvals)})
    save('argmax.json',argmax)
    for order in ['USI','packed']:
        provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
        cb=(CoreBoard if order=='USI' else PackedCore)(case,c,provider=provider)
        sb=(ShogiBoard if order=='USI' else PackedSpecial)(case)
        depth=3 if case['id']=='shogi-middle' else 6
        for rep in range(2):
            for name,board in ([('specialized',sb),('core_native',cb)] if rep==0 else [('core_native',cb),('specialized',sb)]):
                r=minimal_ab(board,depth,seconds=30,node_limit=10**12,trace=True)
                rows.append({'case':case['id'],'order':order,'rep':rep,'arm':name,'instrumentation':'trace qualification, not throughput ratio','target_depth':depth,**r})
                save('fixed-qualification.json',rows)
                print(case['id'],order,rep,name,r['reason'],r['score'],r['move'],r['work']['nodes'],round(r['wall_seconds'],4),flush=True)
# Exact traces must match for each shared comparator; no assumption that USI equals packed.
checks=[]
for case in argmax:
    source=[r for r in json.loads((OUT/'rows.json').read_text()) if r['case']==case['case'] and r['mode']=='fixed']
    checks.append({'case':case['case'],'all_four_fixed_scores':all(r['score']==case['score'] for r in source),'all_four_actions_in_argmax':all(r['move'] in case['argmax'] for r in source)})
for name in ['shogi-middle','shogi-promotion']:
    for order in ['USI','packed']:
        group=[r for r in rows if r['case']==name and r['order']==order]
        signatures=[(r['score'],r['move'],r['work'],r['trace_sha256'],r['completed_depth']) for r in group]
        checks.append({'case':name,'order':order,'four_exact_work_trace_result':all(x==signatures[0] for x in signatures)})
save('qualification-checks.json',checks)
assert all(v for x in checks for k,v in x.items() if isinstance(v,bool)),checks
print('all argmax/fulltrace checks pass',flush=True)
