from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
OUT=Path('.local_agent/current-bridge-20261013')
rows=json.loads((OUT/'availability-rows.json').read_text()); checks=[]
for case in ['shogi-middle','shogi-promotion']:
    group=[r for r in rows if r['case']==case and r['mode']=='fixed'];first=group[0]
    checks.append(dict(case=case,all_fixed_result_work_exact=all((r['move'],r['score'],r['work'])==(first['move'],first['score'],first['work']) for r in group),availability_declines=sum(r['availability_delta'].get('declines',0) for r in group)))
assert len(rows)==16 and all(x['all_fixed_result_work_exact'] and x['availability_declines']==0 for x in checks)
(OUT/'availability-checks.json').write_bytes(json.dumps(checks,indent=2).encode())
assert not (OUT/'real-session-plan.json').exists()
(OUT/'real-session-plan.json').write_bytes(json.dumps(dict(question='Does the public interface give same D2 result on actual GameSession played prefix, not snapshot fixture?',calls=2,case='shogi-middle',seconds=10,expected='full result matches frozen fixed entries; full actual history restored')).encode())
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));case=next(x for x in CASES if x['id']=='shogi-middle');session=GameSession(c)
for label in case['moves'].split():
    actions={gc_action_to_usi(a):a for a in session.legal_actions()};session.submit(actions[label])
b=CoreBoard(case,c);assert session.state==b.initial and session._search_witnesses==b.witnesses
p=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),tt_max_entries=65536,use_disk_cache=False,use_native_semantic_availability=True,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=VALUES['shogi'],hand_values=VALUES['shogi'],tt_megabytes=1,ordering_cache_enabled=False)
limits=SearchLimits(max_depth=2,max_time_seconds=10,max_nodes=None,quiescence_max_depth=0,quiescence_hard_max_depth=0)
before=session.to_record();out=[]
for name,call in [('public_core',lambda:p.choose_action(session,limits)),('persistent_native',lambda:e.search(session,limits,root_window_pruning=True))]:
    r=call(); pv=[gc_action_to_usi(a) for a in r.principal_variation]
    frozen=next(x for x in json.loads((OUT/'rows.json').read_text()) if x['case']==case['id'] and x['mode']=='fixed' and x['arm']==name)
    assert (r.completed_depth,r.score,gc_action_to_usi(r.action),pv)==(frozen['depth'],frozen['score'],frozen['move'],frozen['pv'])
    assert session.to_record()==before
    out.append(dict(arm=name,depth=r.completed_depth,score=r.score,action=gc_action_to_usi(r.action),pv=pv,full_record_restored=True,history_records=len(session.state.history),played_actions=len(session.history)))
(OUT/'real-session.json').write_bytes(json.dumps(out,indent=2).encode())
print('16 availability cells verified, zero new reruns; actualGameSession two calls full tuples/history/record match',flush=True)
