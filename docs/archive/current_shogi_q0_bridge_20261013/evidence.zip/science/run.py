"""Current-source Shogi q0 bridge: existing algorithms, explicit mismatches."""
from pathlib import Path
import sys,json,hashlib,time
from dataclasses import asdict
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,VALUES,CoreBoard,ShogiBoard,Material,audit_pair,minimal_ab,iterative_minimal
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.session.result import session_result_from_terminal
OUT=Path('.local_agent/current-bridge-20261013')
def dump(name,data):
    (OUT/name).write_bytes((json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
def stopped():
    return any(json.loads((ROOT/'.local_agent'/name).read_text(encoding='utf-8')).get(key,False) for name,key in [('rollout.json','user_paused'),('slack.json','stopped')])
cases=[dict(c) for c in CASES if c['id'] in ('shogi-middle','shogi-promotion')]
assert len(cases)==2
decl=dict(cases=cases,values=VALUES['shogi'],fixed_depth=2,time_seconds=[1,4],max_depth=12,node_cap=None,
          repeats=2,arms=['minimal_specialized','minimal_core_native','public_core','persistent_native'],
          scope='complete board/drop actions, promotion and full played history; entering-king declarations and 500-ply boundary excluded from this assay only',
          comparison='USI lexical minimal; production Core and ascending packed Native canonical/order algorithms differ. Same node counts are not equal work.',
          constructor_and_audit_outside_budget=True,public_wall_includes_packing_and_PV_validation=True,
          tt='cold reset each call; Core65536 entries; Native1MiB; minimum adapters no TT',
          q='ordinary0 hard0; check-only OFF; Native q0 only',
          fixed_node_limit_for_minimal=10**12,
          sources={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['scripts/search_backend_comparison.py','generic_chess/native/semantic_engine.py','generic_chess/ai/alphabeta/player.py','generic_chess/ai/alphabeta/search.py']})
assert not (OUT/'declaration.json').exists()
dump('declaration.json',decl)
compiled=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'))
native=compile_native_semantic_rules(compiled)
rows=[]; audits=[]
for case in cases:
    base=CoreBoard(case,compiled); special=ShogiBoard(case)
    audit=audit_pair(base,special,1)
    player=AlphaBetaPlayer(compiled,evaluator_override=Material('shogi'),tt_max_entries=65536,use_disk_cache=False,
                          use_native_semantic_legality=True,use_native_semantic_availability=True,
                          tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
    assert player.native_legality_provider is not None
    hybrid=CoreBoard(case,compiled,provider=player.native_legality_provider)
    audit_pair(hybrid,special,1)
    sess=SimpleNamespace(compiled=compiled,state=base.initial,_search_witnesses=base.witnesses,result=session_result_from_terminal(base.initial.terminal_status))
    engine=SemanticSearchEngine(compiled,native,board_values=VALUES['shogi'],hand_values=VALUES['shogi'],tt_megabytes=1,ordering_cache_enabled=False)
    audits.append(dict(case=case['id'],states=audit,root_history=len(sess.state.history),root_ply=sess.state.ply_count,
                       evaluator_values=engine.native_evaluator_values,native_type_ids=native.type_ids))
    dump('audits.json',audits)
    for mode,seconds in [('fixed',20),('time1',1),('time4',4)]:
        for repeat in range(2):
            arms=decl['arms'] if repeat==0 else list(reversed(decl['arms']))
            for arm in arms:
                if stopped(): raise RuntimeError('explicit user stop')
                depth=2 if mode=='fixed' else 12
                limits=SearchLimits(max_depth=depth,max_time_seconds=seconds,max_nodes=None,quiescence_max_depth=0,quiescence_hard_max_depth=0)
                before=sess.state; witnesses=sess._search_witnesses; start=time.perf_counter()
                if arm.startswith('minimal'):
                    b=special if arm=='minimal_specialized' else hybrid
                    r=minimal_ab(b,depth,seconds=seconds,node_limit=10**12,trace=mode=='fixed') if mode=='fixed' else iterative_minimal(b,seconds=seconds,node_limit=10**12,max_depth=depth)
                    pv=[]; reason=r['reason']; score=r['score']; move=r['move']; complete=r['completed_depth']
                    detail=r
                elif arm=='public_core':
                    player.reset()
                    r=player.choose_action(sess,limits)
                    pv=[base.label(a) for a in r.principal_variation]; reason=r.termination_reason;score=r.score;move=None if r.action is None else base.label(r.action);complete=r.completed_depth
                    detail=asdict(r); detail.pop('action',None);detail.pop('principal_variation',None);detail.pop('declaration',None)
                    detail['availability_metrics']=dict(player.native_legality_provider.availability_metrics)
                else:
                    engine.clear_tt()
                    r=engine.search(sess,limits,root_window_pruning=True)
                    assert r.declaration_id is None
                    pv=[base.label(a) for a in r.principal_variation]; reason=r.termination_reason;score=r.score;move=None if r.action is None else base.label(r.action);complete=r.completed_depth
                    detail=asdict(r)
                    for k in ['action','principal_variation','decision_line','root_hint_requested','root_iteration_first_actions']:detail.pop(k,None)
                wall=time.perf_counter()-start
                assert sess.state==before and sess._search_witnesses==witnesses and hybrid.restored() and special.restored()
                state=before
                for label in pv:
                    acts={base.label(a):a for a in legal_actions(state,compiled)}
                    assert label in acts, ('illegal returned PV',label)
                    state=apply_action(state,acts[label],compiled)
                leaf=Material('shogi').evaluate(state) if pv else None
                row=dict(case=case['id'],arm=arm,mode=mode,repeat=repeat,seconds=seconds,depth=complete,move=move,score=score,pv=pv,
                         reason=reason,wall=wall,pv_leaf_static=leaf,root_restored=True,detail=detail)
                rows.append(row);dump('rows.json',rows)
                print(case['id'],mode,repeat,arm,complete,move,score,reason,round(wall,4),flush=True)
dump('closed.json',dict(calls=len(rows),all_restored=True,ended_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()))
