from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
OUT=Path('.local_agent/current-bridge-20261013')
def save(n,v): (OUT/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
assert not (OUT/'availability-plan.json').exists()
save('availability-plan.json',dict(question='Initial minimal Core Native legality does not use public Core Native availability; does that account for its measured gap?',premise='Profile found Core semantic has_legal_action in push0.947/2.578s nested; already supported readonly callback exists',fixed='2 roots D3/D6;8 no-profiler calls; same USI and allwork',time='2 roots1/4s bothorders withnew minimal_core_native_availability only:8calls; original arms frozen, no replacement',cost='about25s additional; no newengine/default/UI/provider'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));rows=[]
for case in [x for x in CASES if x['id'] in ('shogi-middle','shogi-promotion')]:
    provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
    b=CoreBoard(case,c,provider=provider)
    b.runtime=SearchPathRuntime.from_state(b.initial,c,history_witnesses=b.witnesses,legal_binding_provider=provider,availability_provider=provider.has_legal_action)
    spec=ShogiBoard(case);depth=3 if case['id']=='shogi-middle' else 6
    for rep in range(2):
        for arm,board in ([('specialized',spec),('core_native_availability',b)] if rep==0 else [('core_native_availability',b),('specialized',spec)]):
            before=dict(provider.availability_metrics)
            r=minimal_ab(board,depth,seconds=30,node_limit=10**12)
            rows.append(dict(case=case['id'],mode='fixed',repeat=rep,arm=arm,availability_delta={k:v-before[k] for k,v in provider.availability_metrics.items()},**r));save('availability-rows.json',rows)
            print(case['id'],'fixed',rep,arm,r['wall_seconds'],r['work']['nodes'],flush=True)
    for seconds in [1,4]:
        for rep in range(2):
            before=dict(provider.availability_metrics)
            r=iterative_minimal(b,seconds=seconds,node_limit=10**12,max_depth=12)
            rows.append(dict(case=case['id'],mode='time'+str(seconds),repeat=rep,arm='core_native_availability',availability_delta={k:v-before[k] for k,v in provider.availability_metrics.items()},**r));save('availability-rows.json',rows)
            print(case['id'],seconds,rep,'core_native_availability',r['completed_depth'],r['move'],r['score'],r['wall_seconds'],flush=True)
checks=[]
for case in ['shogi-middle','shogi-promotion']:
    group=[r for r in rows if r['case']==case and r['mode']=='fixed'];first=group[0]
    checks.append(dict(case=case,all_fixed_result_work_exact=all((r['move'],r['score'],r['work'])==(first['move'],first['score'],first['work']) for r in group),
                       availability_declines=sum(r['availability_delta']['declines'] for r in group)))
save('availability-checks.json',checks)
assert all(r['all_fixed_result_work_exact'] and r['availability_declines']==0 for r in checks)
