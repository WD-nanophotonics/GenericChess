from pathlib import Path
import sys,json
from dataclasses import asdict
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.result import session_result_from_terminal
OUT=Path('.local_agent/current-bridge-20261013')
assert not (OUT/'tt-contract-plan.json').exists()
(OUT/'tt-contract-plan.json').write_bytes(json.dumps(dict(question='Does existing full-PV versus exactTT/noTT scheduling explain public Core promotion cost?',calls=6,root='shogi-promotion',depth=8,seconds=15,order='opposite triples coldTT65536',interpretation='tt_cutoffs only counts bound cutoff, not exact TT early return; zero is not zero reuse',premise='Samecurrentroot public1/4s D7/D8 versusmatchedbareNativeavailability D8/D9; no default or key edits')).encode())
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));case=next(x for x in CASES if x['id']=='shogi-promotion');b=CoreBoard(case,c);s=SimpleNamespace(compiled=c,state=b.initial,_search_witnesses=b.witnesses,result=session_result_from_terminal(b.initial.terminal_status));rows=[]
for rep in range(2):
    arms=[('full_tt',True,True),('short_tt',False,True),('full_no_tt',True,False)]
    for name,full,tt in (arms if rep==0 else list(reversed(arms))):
        p=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),tt_max_entries=65536,use_disk_cache=False,use_tt=tt,use_native_semantic_availability=True,tuning=SearchTuning(use_root_tactical=False,require_full_pv=full))
        r=p.choose_action(s,SearchLimits(max_depth=8,max_time_seconds=15,max_nodes=None,quiescence_max_depth=0,quiescence_hard_max_depth=0))
        pv=[b.label(a) for a in r.principal_variation]
        assert r.completed_depth==8 and r.score==500 and b.label(r.action)=='5c5b+'
        state=b.initial
        for label in pv:
            actions={b.label(a):a for a in legal_actions(state,c)};assert label in actions;state=apply_action(state,actions[label],c)
        d=asdict(r);d.pop('action');d.pop('principal_variation');d.pop('declaration',None)
        rows.append(dict(arm=name,repeat=rep,pv=pv,full_horizon_line=len(pv)==8,detail=d))
        (OUT/'tt-contract-rows.json').write_bytes(json.dumps(rows,indent=2).encode())
        print(name,rep,r.nodes,r.tt_hits,r.tt_cutoffs,len(pv),r.elapsed_seconds,flush=True)
