from pathlib import Path
import sys,sysconfig,subprocess,time,json
R=Path.cwd();b=R/'.local_agent/q-history-20261015';rows=[]
for label in ('v1','v2'):
 src=b/('quiet_src_'+label);target=b/('quiet_'+label+sysconfig.get_config_var('EXT_SUFFIX'));t=time.perf_counter();r=subprocess.run([str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in sorted(src.glob('*.c'))],'-o',str(target)],capture_output=True,timeout=180);(b/f'quiet-build-{label}.log').write_bytes(r.stdout+r.stderr);rows.append(dict(label=label,exit=r.returncode,seconds=time.perf_counter()-t));assert r.returncode==0,r.stderr.decode(errors='replace')
(b/'quiet-build.json').write_bytes(json.dumps(rows,indent=2).encode());print(rows)
