static int gc_semantic_q_history_deferrable(const GCSemanticRules *r,const GCSemanticPosition *p) {
 if(r->automatic_adjudication_count || !p->history_exact || !p->history_events_exact || p->history_len!=p->ply+1 || p->history_len>=GC_SEM_MAX_PLY+1 || r->repetition_limit<2)return 0;
 unsigned forbidden=r->repetition_limit-1;
 for(unsigned i=0;i<p->history_len;i++){unsigned count=0;for(unsigned j=0;j<p->history_len;j++){if(!memcmp(p->history_digest[i],p->history_digest[j],sizeof(p->history_digest[0])))count++;}if(count>=forbidden)return 0;}
 return 1;
}
/* Only called after proving no automatic rule and no possible next-edge repetition.
 * Transient history is NOT passed to general terminal/repetition authority. */
static int gc_semantic_q_quiet_terminal(const GCSemanticRules *r,const GCSemanticPosition *p,int *winner) {
 int ok=1,has_action=gc_semantic_has_guarded_action(r,p,&ok);if(!ok)return -1;
 if(!has_action){if(gc_semantic_runtime_in_check(r,p,p->side_to_move)){*winner=1-p->side_to_move;return 1;}if(r->stalemate_result==1)*winner=1-p->side_to_move;return 2;}
 if(p->ply>=r->max_ply)return 4;return 0;
}
    int can_defer=!check && gc_semantic_q_history_deferrable(ctx->rules,pos);
    int parent_enemies=0,legal=0;
    unsigned cells=ctx->rules->board_size*ctx->rules->board_size;
    for(unsigned i=0;i<cells;i++)if(pos->board[i].occupied && pos->board[i].owner!=pos->side_to_move)parent_enemies++;
    for(size_t i=0;i<actions.count;i++){
        if(!gc_semantic_iterative_check_budget(ctx,1)){gc_semantic_action_buffer_free(&actions);return 0;}
        GCSemanticPosition *child=&ctx->stack[ply+1];
        int made=can_defer?gc_semantic_runtime_make_material_view_status(child,ctx->rules,pos,actions.data[i]):gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);
        if(made<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}
        if(!made)continue;
        ctx->transition_count++;legal++;
        int noisy=check,child_terminal=-1,child_winner=-1;
        if(!noisy){
            int enemies=0;
            for(unsigned j=0;j<cells;j++)if(child->board[j].occupied && child->board[j].owner!=pos->side_to_move)enemies++;
            noisy=enemies<parent_enemies || gc_semantic_inventory_changed(ctx->rules,pos,child);
            if(!noisy){
                int child_check=(!can_defer && child->history_events_exact &&
                    child->history_len==pos->history_len+1)
                    ? child->history_gave_check[child->history_len-1]
                    : gc_semantic_runtime_in_check(ctx->rules,child,child->side_to_move);
                if(child_check<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}
                noisy=child_check;
            }
            if(!noisy){
                child_terminal=can_defer?gc_semantic_q_quiet_terminal(ctx->rules,child,&child_winner):gc_semantic_terminal_status_known(ctx->rules,child,&child_winner,child->history_digest[child->history_len-1]);
                if(child_terminal<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}
                noisy=child_terminal!=0;
            }
        }
        if(!noisy)continue;
        if(can_defer){int committed=gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);if(committed<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}if(!committed){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}}
