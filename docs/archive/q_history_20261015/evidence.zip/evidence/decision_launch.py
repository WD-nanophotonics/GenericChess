from pathlib import Path
import json,time,subprocess,sys
b=Path('.local_agent/q-history-20261015')
# Bounded readiness wait belongs to this diagnostic only; independent work continues.
for _ in range(180):
 d=json.loads((b/'fresh-results.json').read_text(encoding='utf-8'))
 if d['complete']:break
 time.sleep(1)
else:raise TimeoutError('Fresh producer readiness not completed within180s; no queries launched')
r=subprocess.run([sys.executable,str(b/'decision_diagnostic.py')],capture_output=True,timeout=330);(b/'decision-diagnostic.log').write_bytes(r.stdout+r.stderr);print(r.stdout.decode(errors='replace'));assert r.returncode==0,r.stderr.decode(errors='replace')
