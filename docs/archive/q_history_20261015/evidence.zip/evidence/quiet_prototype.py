from pathlib import Path
import json,datetime,shutil
R=Path.cwd();b=R/'.local_agent/q-history-20261015'
plan=dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),question='Can bounded quiet-child history deferral reduce actual q cost while preserving complete returned policy and full searched histories?',changed_premise='Actual discarded digest share .13-.45 and same-work instrumentation overhead near1.0, unlike earlier endpoint-only bound.',safety='Only noncheck parent, no automatic adjudication rules, exact coherent history, real append capacity, and max recorded identity multiplicity M<repetition_limit-1. Actual searched/noisy/uncertain children use full checked transition. No model/rule exclusion in task; unsupported optimization paths use baseline.',fixed=dict(inputs='same16development initial roots',depth=3,nodes=1024,q=[1,4],hard=8,seconds=12,orders=2,arms=['baseline','quiet_candidate'],batch_fuse_seconds=1200),controls='Existing full35semantic/wide fixtures plus actual repetition/automatic/declaration controls; fullCore/native PV histories. All failures/censors retained; no new games/training/default change.',cost='Private builds<=180s each, frozen comparison<=20min; no single run expected>1hour',adoption='No public adoption without qualified complete metadata/PV/state/history and measured actual useful cost. More depth alone not strength; transient never authoritative search state.')
(b/'quiet-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
helper='''static int gc_semantic_q_history_deferrable(const GCSemanticRules *r,const GCSemanticPosition *p) {
 if(r->automatic_adjudication_count || !p->history_exact || !p->history_events_exact || p->history_len!=p->ply+1 || p->history_len>=GC_SEM_MAX_PLY+1 || r->repetition_limit<2)return 0;
 unsigned forbidden=r->repetition_limit-1;
 for(unsigned i=0;i<p->history_len;i++){unsigned count=0;for(unsigned j=0;j<p->history_len;j++){if(!memcmp(p->history_digest[i],p->history_digest[j],sizeof(p->history_digest[0])))count++;}if(count>=forbidden)return 0;}
 return 1;
}
/* Only called after proving no automatic rule and no possible next-edge repetition.
 * Transient history is NOT passed to general terminal/repetition authority. */
static int gc_semantic_q_quiet_terminal(const GCSemanticRules *r,const GCSemanticPosition *p,int *winner) {
 int ok=1,has_action=gc_semantic_has_guarded_action(r,p,&ok);if(!ok)return -1;
 if(!has_action){if(gc_semantic_runtime_in_check(r,p,p->side_to_move)){*winner=1-p->side_to_move;return 1;}if(r->stalemate_result==1)*winner=1-p->side_to_move;return 2;}
 if(p->ply>=r->max_ply)return 4;return 0;
}
'''
for label,source in [('v1',R/'generic_chess/_native'),('v2',R/'.local_agent/immediate-goal-20261015/src_final_v2')]:
 dest=b/('quiet_src_'+label);dest.mkdir(exist_ok=True)
 for p in source.iterdir():
  if p.suffix in ('.c','.h'):shutil.copyfile(p,dest/p.name)
 p=dest/'native_module.c';s=p.read_text(encoding='utf-8');a=s.index('static int gc_semantic_quiescence(');z=s.index('\nstatic int gc_semantic_iterative_negamax',a);q=s[a:z]
 q=q.replace('    int parent_enemies=0,legal=0;','    int can_defer=!check && gc_semantic_q_history_deferrable(ctx->rules,pos);\n    int parent_enemies=0,legal=0;')
 needle='int made=gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);';assert needle in q
 q=q.replace(needle,'int made=can_defer?gc_semantic_runtime_make_material_view_status(child,ctx->rules,pos,actions.data[i]):gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);')
 q=q.replace('int child_check=(child->history_events_exact &&','int child_check=(!can_defer && child->history_events_exact &&')
 q=q.replace('child_terminal=gc_semantic_terminal_status_known(ctx->rules,child,&child_winner,child->history_digest[child->history_len-1]);','child_terminal=can_defer?gc_semantic_q_quiet_terminal(ctx->rules,child,&child_winner):gc_semantic_terminal_status_known(ctx->rules,child,&child_winner,child->history_digest[child->history_len-1]);')
 needle='        int score=-gc_semantic_quiescence';assert needle in q
 q=q.replace(needle,'''        if(can_defer){int committed=gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);if(committed<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}if(!committed){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}}
        int score=-gc_semantic_quiescence''')
 p.write_bytes((s[:a]+helper+q+s[z:]).encode())
