from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
import collections,hashlib
B=R/'.local_agent/q-history-20261015';start=time.perf_counter();samples=json.loads((prior/'v2-boundary-inputs.json').read_text(encoding='utf-8'));mods={}
for label in ('v1','v2'):
 spec=importlib.util.spec_from_file_location('gate'+label+'._native_core',next(B.glob('gate_'+label+'*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[label]=m
rows=[];roots=[];mismatches=[]
def replay(result,s,nr):
 state=s.state;pos=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses)
 for a in result.decision_line:
  assert state.terminal_status.status.value=='ongoing'
  if isinstance(a,str):assert any(v.declaration_id==a for v in available_declarations(state,s.compiled));continue
  pos=sem.make_checked(nr,pos,pack_semantic_action(nr,state.position,a));state=apply_action(state,a,s.compiled);w.append(state.position);sn=sem.snapshot(nr,pos);expected=expected_snapshot(state.position,nr,s.compiled)
  for k in ('board','hands','aux_state','side'):assert record_value(sn[k])==record_value(expected[k])
  assert sn['ply']==state.ply_count and sn['history_exact'] and sn['history_events_exact']
  assert [''.join(f'{v:016x}'for v in h)for h in sn['history']]==[str(position_identity_key(x,s.compiled))for x in w]
  assert sn['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
  nt=sem.terminal_status(nr,pos);assert nt==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
 return record_value(state.terminal_status)
for x in samples:
 if time.perf_counter()-start>1200:break
 c,s=case(x);label='v1'if c.board_size<=16 else'v2';assert label!='v2'or not c.support.automatic_adjudications
 bs=_module()if label=='v1'else wide;qs=mods[label];nrs={'baseline':nc.compile_native_semantic_rules(c,backend_module=bs),'quiet_candidate':nc.compile_native_semantic_rules(c,backend_module=qs)};nr=nrs['quiet_candidate'];pos=pack_semantic_search_position(c,nr,s);legal=s.legal_actions();assert set(sem.transient_legal_actions(nr,pos))=={pack_semantic_action(nr,s.state.position,a)for a in legal};eligible=qs.q_gate_inspect(nr.capsule,pos);roots.append(dict(name=x['name'],n=c.board_size,eligible=eligible,legal_actions=len(legal)));bv={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()};before=record_value(s.to_record())
 for q in (1,4):
  for order in (0,1):
   pair={}
   for arm in (list(nrs)if order==0 else list(nrs)[::-1]):
    if time.perf_counter()-start>1200:raise TimeoutError('Frozen1200s semantic fuse')
    t=time.perf_counter();res=SemanticSearchEngine(c,nrs[arm],board_values=bv,hand_values=bv,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=3,max_nodes=2048,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;leaf=replay(res,s,nrs[arm]);assert record_value(s.to_record())==before;pair[arm]=res;rows.append(dict(root=x['name'],q=q,order=order,arm=arm,caller_seconds=wall,result=record_value(res),leaf=leaf))
   diff=[k for k,v in signature(pair['baseline']).items() if v!=signature(pair['quiet_candidate']).get(k)];censored=any(v.termination_reason=='time_budget'for v in pair.values())
   if diff:mismatches.append(dict(root=x['name'],q=q,order=order,fields=diff,clock_censored=censored))
 (B/'semantic-results.json').write_bytes(json.dumps(dict(complete=False,roots=roots,rows=rows,mismatches=mismatches,seconds=time.perf_counter()-start)).encode());print(x['name'],len(rows),len(mismatches),round(time.perf_counter()-start,3),flush=True)
from test_native_pv_replay_boundaries import repeated_root
from test_native_pending_continuation import session_after
controls=[]
for name,s in [('actual_repetition',repeated_root()),('pending',session_after(('e2e4','d7d5','f1b5','c7c6'))),('normal_max',session_after(('e2e4','d7d5','f1b5'),trigger=None))]:
 nr=nc.compile_native_semantic_rules(s.compiled,backend_module=mods['v1']);pos=pack_semantic_search_position(s.compiled,nr,s);gate=mods['v1'].q_gate_inspect(nr.capsule,pos);assert not gate if name!='normal_max'else True;controls.append(dict(name=name,gate=gate,status=sem.terminal_status(nr,pos)))
 if s.result.status.value=='ongoing':
  bv={t:0 if m.is_anchor else100 for t,m in s.compiled.support.type_metadata.items()};res=SemanticSearchEngine(s.compiled,nr,board_values=bv,hand_values=bv,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=2,max_nodes=256,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);replay(res,s,nr)
(B/'semantic-results.json').write_bytes(json.dumps(dict(complete=True,roots=roots,rows=rows,mismatches=mismatches,controls=controls,seconds=time.perf_counter()-start)).encode());print('COMPLETE',len(rows),mismatches,controls)
