from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
B=R/'.local_agent/q-history-20261015';P=b;seed=int(sys.argv[1]);n=32 if seed>=4109 else (4 if seed<4020 else 8 if seed<4030 else 12 if seed<4040 else 16)
if n==32:
 x=json.loads((P/f'generation-{seed}-base1024.json').read_text(encoding='utf-8'));raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c);assert record_value(s.state)==x['state'];baseline=wide
else:
 x=json.loads((P/f'input-{seed}.json').read_text(encoding='utf-8'))['samples'][0];c,s=case(x);bspec=importlib.util.spec_from_file_location('frozenbaseline._native_core',next(B.glob('baseline_v1*.pyd')));baseline=importlib.util.module_from_spec(bspec);bspec.loader.exec_module(baseline)
assert n!=32 or not c.support.automatic_adjudications
spec=importlib.util.spec_from_file_location('qattr._native_core',next(B.glob(('quiet_v2'if n==32 else'quiet_v1')+'*.pyd')));instrumented=importlib.util.module_from_spec(spec);spec.loader.exec_module(instrumented)
backends={'baseline':baseline,'quiet_candidate':instrumented};rules={k:nc.compile_native_semantic_rules(c,backend_module=v)for k,v in backends.items()}
profile=p.build_ruleset_profile(c,p.EvaluationConfig());bv={k:int(round(v)) for k,v in profile.board_value_by_type.items()};hv={k:int(round(v))for k,v in profile.hand_value_by_base_type.items()};rows=[];start=time.perf_counter();before=record_value(s.to_record())
for budget in (4,16):
 q=4
 for order in (0,1):
  for arm in (list(backends) if order==0 else list(backends)[::-1]):
   nr=rules[arm];mod=backends[arm]
   if False:mod.q_attribution_reset()
   e=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=12,max_time_seconds=budget,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;metrics=None;leaf=validate(r,s,nr)
   # Full searched-PV history is verified, not just flags. No new timed query.
   state=s.state;np=pack_semantic_search_position(c,nr,s);witnesses=list(s._search_witnesses);events=list(state.history)
   for a in r.principal_variation:
    np=sem.make_checked(nr,np,pack_semantic_action(nr,state.position,a));state=apply_action(state,a,c);witnesses.append(state.position);sn=sem.snapshot(nr,np)
    assert [''.join(f'{v:016x}'for v in h)for h in sn['history']]==[str(position_identity_key(w,c))for w in witnesses]
    assert sn['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
   child=None if r.action is None else apply_action(s.state,r.action,c)
   assert record_value(s.to_record())==before
   row=dict(seed=seed,n=n,q=q,budget=budget,order=order,arm=arm,caller_seconds=wall,result=record_value(r),metrics=metrics,leaf=leaf,selected_child_terminal=None if child is None else record_value(child.terminal_status),root_restored=True);rows.append(row);(B/f'resource-family-{seed}.json').write_bytes(json.dumps(dict(complete=False,rows=rows)).encode());print(seed,q,order,arm,r.completed_depth,r.nodes,round(wall,3),None if metrics is None else (metrics[4],metrics[5],metrics[7]),flush=True)
(B/f'resource-family-{seed}.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,baseline_image_sha256=__import__('hashlib').sha256(Path(baseline.__file__).read_bytes()).hexdigest(),baseline_explicit_immutable=(n==32 or Path(baseline.__file__).parent==B))).encode())
