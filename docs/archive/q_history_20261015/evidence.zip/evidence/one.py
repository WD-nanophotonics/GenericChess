from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
B=R/'.local_agent/q-history-20261015';P=b;seed=int(sys.argv[1]);n=32 if seed>=4109 else (4 if seed<4020 else 8 if seed<4030 else 12 if seed<4040 else 16)
if n==32:
 x=json.loads((P/f'generation-{seed}-base1024.json').read_text(encoding='utf-8'));raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c);assert record_value(s.state)==x['state'];baseline=wide
else:
 x=json.loads((P/f'input-{seed}.json').read_text(encoding='utf-8'))['samples'][0];c,s=case(x);baseline=_module()
assert n!=32 or not c.support.automatic_adjudications
spec=importlib.util.spec_from_file_location('qattr._native_core',next(B.glob(('v2'if n==32 else'v1')+'*.pyd')));instrumented=importlib.util.module_from_spec(spec);spec.loader.exec_module(instrumented)
backends={'baseline':baseline,'instrumented':instrumented};rules={k:nc.compile_native_semantic_rules(c,backend_module=v)for k,v in backends.items()}
profile=p.build_ruleset_profile(c,p.EvaluationConfig());bv={k:int(round(v)) for k,v in profile.board_value_by_type.items()};hv={k:int(round(v))for k,v in profile.hand_value_by_base_type.items()};rows=[];start=time.perf_counter();before=record_value(s.to_record())
for q in (1,4):
 for order in (0,1):
  for arm in (list(backends) if order==0 else list(backends)[::-1]):
   nr=rules[arm];mod=backends[arm]
   if arm=='instrumented':mod.q_attribution_reset()
   e=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=3,max_nodes=1024,max_time_seconds=12,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;metrics=None if arm=='baseline'else mod.q_attribution_get();leaf=validate(r,s,nr);assert record_value(s.to_record())==before
   row=dict(seed=seed,n=n,q=q,order=order,arm=arm,caller_seconds=wall,result=record_value(r),metrics=metrics,leaf=leaf,root_restored=True);rows.append(row);(B/f'family-{seed}.json').write_bytes(json.dumps(dict(complete=False,rows=rows)).encode());print(seed,q,order,arm,r.completed_depth,r.nodes,round(wall,3),None if metrics is None else (metrics[4],metrics[5],metrics[7]),flush=True)
(B/f'family-{seed}.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start)).encode())
