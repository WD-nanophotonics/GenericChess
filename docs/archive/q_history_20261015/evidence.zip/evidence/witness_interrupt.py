from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
import threading,datetime
from generic_chess.ai.cancellation import CancellationToken
B=R/'.local_agent/q-history-20261015'
plan=dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),question='Does private reply reuse honor real mid-search cancellation without damaging root or retained history?',calls=4,delay_seconds=.02,scope='Existing4043root, two orders, final versus private witness, q4/hard8/D32; actual timer cancellation, whole10s fuse, no strength/prospective claim.')
(B/'witness-interrupt-plan.json').write_bytes(json.dumps(plan).encode())
mods={}
for arm,prefix in [('final','final_v1'),('witness','witness_v1')]:
 spec=importlib.util.spec_from_file_location('interrupt'+arm+'._native_core',next(B.glob(prefix+'*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
x=json.loads((b/'input-4043.json').read_text(encoding='utf-8'))['samples'][0];c,s=case(x);bv={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()};before=record_value(s.to_record());rows=[];start=time.perf_counter()
for order in(0,1):
 for arm in(list(mods)if order==0 else list(mods)[::-1]):
  assert time.perf_counter()-start<10
  nr=nc.compile_native_semantic_rules(c,backend_module=mods[arm]);engine=SemanticSearchEngine(c,nr,board_values=bv,hand_values=bv,tt_megabytes=0,ordering_cache_enabled=False);token=CancellationToken();timer=threading.Timer(.02,token.cancel);t=time.perf_counter();timer.start()
  try:r=engine.search(s,SearchLimits(max_depth=32,max_time_seconds=2,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True)
  finally:timer.join(timeout=3)
  assert not timer.is_alive() and token.is_cancelled
  assert record_value(s.to_record())==before
  validate(r,s,nr);assert r.termination_reason=='cancelled',r.termination_reason
  rows.append(dict(order=order,arm=arm,seconds=time.perf_counter()-t,result=record_value(r),root_restored=True))
(B/'witness-interrupt-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,scope='Mid-search wall cancellation, not deterministic injection at the hint instruction; complete finite-result/root check only.')).encode());print('INTERRUPT',len(rows),time.perf_counter()-start)
