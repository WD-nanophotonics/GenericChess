from pathlib import Path
import sys,json,time,importlib.util,hashlib
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];B=R/'.local_agent/q-history-20261015';plan=json.loads((B/'fresh-plan.json').read_text(encoding='utf-8'));status=json.loads((B/'fresh-results.json').read_text(encoding='utf-8'));assert status['complete'],'Frozen fresh producer not yet closed'
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,SemanticSearchEngine
from generic_chess.core.transition import apply_action
from generic_chess.ai.limits import SearchLimits
spec=importlib.util.spec_from_file_location('diag._native_core',next(B.glob('final_v1*.pyd')));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);selection={};groups=[];familydata={}
for family in plan['families']:
 path=B/f"fresh-{family['seed']}.json"
 if not path.exists():continue
 d=json.loads(path.read_text(encoding='utf-8'));familydata[family['seed']]=d
 for ply,setting,order in sorted({(r['ply'],r['setting'],r['order'])for r in d['rows']if r['setting']!='nodes1024'}):
  pair={r['arm']:r for r in d['rows']if(r['ply'],r['setting'],r['order'])==(ply,setting,order)}
  if len(pair)!=2 or pair['baseline']['result']['action']==pair['final_candidate']['result']['action']:continue
  refs={}
  for arm,r in pair.items():
   a=r['result']['action'];key=(family['seed'],ply,json.dumps(a,sort_keys=True));refs[arm]=key;selection.setdefault(key,dict(seed=family['seed'],ply=ply,action=a,memberships=[]))['memberships'].append(dict(setting=setting,order=order,arm=arm))
  groups.append(dict(seed=family['seed'],ply=ply,setting=setting,order=order,actions=refs))
start=time.perf_counter();rows=[];compiled={}
for key,x in sorted(selection.items()):
 if time.perf_counter()-start>=300:rows.append(dict(**x,status='unstarted_fuse',verified_opponent_win=False,negative_is_WDL=False));continue
 seed=x['seed'];d=familydata[seed];sample=next(s for s in d['samples']if s['ply']==x['ply'])
 if seed not in compiled:
  raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(sample['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);compiled[seed]=(c,nc.compile_native_semantic_rules(c,backend_module=mod))
 c,nr=compiled[seed];s=GameSession(c)
 for action in sample['walk']:
  a,=[a for a in s.legal_actions()if record_value(a)==action];s.submit(a)
 assert record_value(s.state)==sample['state'];a,=[a for a in s.legal_actions()if record_value(a)==x['action']];s.submit(a);terminal=record_value(s.state.terminal_status);result=None;verified=False;t=time.perf_counter()
 if not s.state.terminal_status.is_terminal:
  result=SemanticSearchEngine(c,nr,board_values=sample['board_values'],hand_values=sample['hand_values'],tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0),stop_on_immediate_win=True)
  if result.immediate_win:
   child=apply_action(s.state,result.action,c);assert child.terminal_status.is_terminal and child.terminal_status.winner==s.state.position.side_to_move;verified=True
 rows.append(dict(**x,status='physical_terminal'if result is None else'diagnostic_complete',selected_child_terminal=terminal,verified_opponent_win=verified,negative_is_WDL=False,result=None if result is None else record_value(result),seconds=time.perf_counter()-t));(B/'decision-diagnostic.json').write_bytes(json.dumps(dict(complete=False,planned_unique_actions=len(selection),changed_pairs=len(groups),rows=rows,seconds=time.perf_counter()-start)).encode());print(seed,x['ply'],len(rows),len(selection),verified,flush=True)
(B/'decision-diagnostic.json').write_bytes(json.dumps(dict(complete=True,planned_unique_actions=len(selection),changed_pairs=len(groups),rows=rows,groups=groups,seconds=time.perf_counter()-start,scope='Positive replies independently Core-verified; negative/censored is UNKNOWN, not WDL/nonloss. Conditional changed-action development diagnostic, no game outcomes or learning labels.')).encode());print('DIAGNOSTIC COMPLETE',len(rows),sum(r['verified_opponent_win']for r in rows),time.perf_counter()-start)
