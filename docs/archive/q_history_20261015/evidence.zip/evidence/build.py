from pathlib import Path
import sys,sysconfig,subprocess,time,json,hashlib
R=Path.cwd();b=R/'.local_agent/q-history-20261015';rows=[]
for label in ('v1','v2'):
 src=b/('src_'+label);target=b/(label+sysconfig.get_config_var('EXT_SUFFIX'));cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in sorted(src.glob('*.c'))],'-o',str(target)];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=180);(b/f'build-{label}.log').write_bytes(r.stdout+r.stderr);rows.append(dict(label=label,exit=r.returncode,seconds=time.perf_counter()-t,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in src.iterdir()if p.suffix in ('.c','.h')}));assert r.returncode==0,(label,r.stderr.decode(errors='replace'))
(b/'build.json').write_bytes(json.dumps(rows,indent=2).encode());print('BUILT',[(r['label'],r['seconds']) for r in rows])
