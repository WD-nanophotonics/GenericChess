from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
from dataclasses import replace
from test_native_pv_replay_boundaries import repeated_root
import hashlib,collections
B=R/'.local_agent/q-history-20261015';src=inspect.getsource(repeated_root).replace('def repeated_root():','def long_root():').replace('s=GameSession(compile_legacy_ruleset_for_semantic_execution(rules))','s=GameSession(compile_legacy_ruleset_for_semantic_execution(replace(rules,repetition_limit=10000,max_ply=1024)))').replace('range(11)','range(0)');ns=dict(repeated_root.__globals__);ns['replace']=replace;exec(src,ns);s=ns['long_root']();spec=importlib.util.spec_from_file_location('longquiet._native_core',next(B.glob('q2_v1*.pyd')));qm=importlib.util.module_from_spec(spec);spec.loader.exec_module(qm);nrs={a:nc.compile_native_semantic_rules(s.compiled,backend_module=m)for a,m in [('baseline',_module()),('quiet_candidate',qm)]};v={t:0 if m.is_anchor else 100 for t,m in s.compiled.support.type_metadata.items()};rows=[];start=time.perf_counter()
for ply in range(513):
 if ply in (0,32,128,512):
  before=record_value(s.to_record())
  for q in (1,4):
   for order in (0,1):
    for repeat in range(3):
     pair={}
     for arm in (list(nrs)if order==0 else list(nrs)[::-1]):
      assert time.perf_counter()-start<120;t=time.perf_counter();res=SemanticSearchEngine(s.compiled,nrs[arm],board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=3,max_nodes=1024,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;validate(res,s,nrs[arm]);assert record_value(s.to_record())==before;pair[arm]=signature(res);rows.append(dict(ply=ply,q=q,order=order,repeat=repeat,arm=arm,caller_seconds=wall,result=record_value(res)))
     assert pair['baseline']==pair['quiet_candidate']
  print('prefix',ply,'calls',len(rows),round(time.perf_counter()-start,3),flush=True)
 if ply<512:
  a,=s.legal_actions();s.submit(a);assert s.result.status.value=='ongoing'
(B/'long-history-q2-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start)).encode())
