from pathlib import Path
import json,datetime,re,shutil
R=Path.cwd();b=R/'.local_agent/q-history-20261015';prior=R/'.local_agent/pv-contract-20261015';plan=dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),question='What fraction of actual q traversal cost and identity work belongs to quiet discarded children?',premise='Earlier endpoint .166875 ratio does not time actual q traversal. Private counters/timers preserve all semantics; determine whether shortcut implementation is worth total engineering cost.',inputs=dict(wide=list(range(4109,4117)),fresh_small=[4011,4013,4021,4023,4031,4033,4041,4043]),settings=[dict(depth=3,nodes=1024,q=1,hard=8),dict(depth=3,nodes=1024,q=4,hard=8)],orders=2,arms=['baseline','instrumented'],per_query_fuse_seconds=12,batch_fuse_seconds=1200,expected_seconds='<=1536 nominal query fuse seconds but original whole1200s fuse wins; no single run>1hour; censored slots retained',scope='16existing development roots, currentV1 small and historical frozenV2 wide. No unsupported automatic-rule authority claims on historicalV2; reject any automatic fixture there. No new games/price fitting/default/API changes.',decision='Estimate inclusive discarded-make and digest share only for same-work pairs; clock overhead assessed counterbalanced. Large endpoint gains alone never adopt. Preserve full searched history, drops,promotion,aux,declaration/automatic semantics.')
(b/'plan.json').write_bytes(json.dumps(plan,indent=2).encode())
for label,source in [('v1',R/'generic_chess/_native'),('v2',R/'.local_agent/immediate-goal-20261015/src_final_v2')]:
 dest=b/('src_'+label);dest.mkdir(exist_ok=True)
 for p in source.iterdir():
  if p.suffix in ('.c','.h'):shutil.copyfile(p,dest/p.name)
 module=dest/'native_module.c';s=module.read_text(encoding='utf-8');start=s.index('static int gc_semantic_quiescence(');end=s.index('\nstatic int gc_semantic_iterative_negamax',start);q=s[start:end]
 q=q.replace('        int made=gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);','''        uint64_t q_edge_start=gc_monotonic_ns(), q_key_before=gc_q_cost[0], q_count_before=gc_q_cost[1];
        gc_q_attributing=1;
        int made=gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);
        gc_q_attributing=0;
        uint64_t q_edge_ns=gc_monotonic_ns()-q_edge_start;
        uint64_t q_digest_ns=gc_q_cost[0]-q_key_before, q_digest_count=gc_q_cost[1]-q_count_before;
        gc_q_cost[2]+=q_edge_ns;gc_q_cost[3]++;
''')
 assert 'q_edge_start' in q
 q=q.replace('        ctx->transition_count++;legal++;','        ctx->transition_count++;legal++;gc_q_cost[4]++;uint64_t q_classify_start=gc_monotonic_ns();')
 q=q.replace('                child_terminal=gc_semantic_terminal_status_known','                gc_q_cost[12]++;uint64_t q_terminal_start=gc_monotonic_ns();\n                child_terminal=gc_semantic_terminal_status_known')
 q=q.replace('                noisy=child_terminal!=0;','                gc_q_cost[10]+=gc_monotonic_ns()-q_terminal_start;\n                noisy=child_terminal!=0;')
 q=q.replace('        if(!noisy)continue;','''        gc_q_cost[9]+=gc_monotonic_ns()-q_classify_start;
        if(!noisy){gc_q_cost[5]++;gc_q_cost[6]+=q_edge_ns;gc_q_cost[7]+=q_digest_ns;gc_q_cost[8]+=q_digest_count;continue;}
        gc_q_cost[11]++;''')
 s=s[:start]+q+s[end:];s=s.replace('static PyMethodDef gc_methods[] = {','''static PyObject *gc_q_attribution_reset(PyObject *self, PyObject *args){memset(gc_q_cost,0,sizeof(uint64_t)*16);gc_q_attributing=0;Py_RETURN_NONE;}
static PyObject *gc_q_attribution_get(PyObject *self, PyObject *args){PyObject *out=PyTuple_New(16);if(!out)return NULL;for(int i=0;i<16;i++)PyTuple_SET_ITEM(out,i,PyLong_FromUnsignedLongLong(gc_q_cost[i]));return out;}
static PyMethodDef gc_methods[] = {
 {"q_attribution_reset",gc_q_attribution_reset,METH_NOARGS,"PRIVATE instrumentation reset"},
 {"q_attribution_get",gc_q_attribution_get,METH_NOARGS,"PRIVATE instrumentation counters"},''');s=s.replace('#include "native_clock.h"','#include "native_clock.h"\nextern uint64_t gc_q_cost[16];\nextern int gc_q_attributing;');module.write_bytes(s.encode())
 runtime=dest/'native_semantic_runtime.c';s=runtime.read_text(encoding='utf-8');s=s.replace('#include <string.h>','#include <string.h>\n#include "native_clock.h"\nuint64_t gc_q_cost[16]={0};\nint gc_q_attributing=0;')
 needle='if(!gc_semantic_position_key_digest(r,&work,digest))return -1;';assert needle in s
 s=s.replace(needle,'uint64_t q_digest_start=gc_q_attributing?gc_monotonic_ns():0;'+needle+'if(gc_q_attributing){gc_q_cost[0]+=gc_monotonic_ns()-q_digest_start;gc_q_cost[1]++;}')
 runtime.write_bytes(s.encode())
