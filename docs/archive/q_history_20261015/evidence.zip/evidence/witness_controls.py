from pathlib import Path
import sys,importlib.util,pytest
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/q-history-20261015'
import generic_chess.native as native
spec=importlib.util.spec_from_file_location('witnesscontrol._native_core',next(B.glob('witness_v1*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(B/'pytest-witness'),'tests/product/test_native_q_history_deferral.py','tests/product/test_native_semantic_qsearch.py']))
