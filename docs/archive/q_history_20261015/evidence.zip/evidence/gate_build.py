from pathlib import Path
import shutil,subprocess,sys,sysconfig,json,time
R=Path.cwd();b=R/'.local_agent/q-history-20261015';rows=[]
for label in ('v1','v2'):
 dest=b/('gate_src_'+label);dest.mkdir(exist_ok=True)
 for p in (b/('quiet_src_'+label)).iterdir():
  if p.suffix in ('.c','.h'):shutil.copyfile(p,dest/p.name)
 p=dest/'native_module.c';s=p.read_text(encoding='utf-8');s=s.replace('static PyMethodDef gc_methods[] = {','''static PyObject *gc_q_gate_inspect(PyObject *self,PyObject *args){PyObject *a,*b;if(!PyArg_ParseTuple(args,"OO",&a,&b))return NULL;GCSemanticRules *r=PyCapsule_GetPointer(a,GC_SEM_RULES_CAPSULE);GCSemanticPosition *p=PyCapsule_GetPointer(b,GC_SEM_POSITION_CAPSULE);if(!r||!p)return NULL;return PyBool_FromLong(gc_semantic_q_history_deferrable(r,p));}
static PyMethodDef gc_methods[] = {
 {"q_gate_inspect",gc_q_gate_inspect,METH_VARARGS,"Private eligibility observation"},''');p.write_bytes(s.encode());target=b/('gate_'+label+sysconfig.get_config_var('EXT_SUFFIX'));r=subprocess.run([str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(dest),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(x)for x in sorted(dest.glob('*.c'))],'-o',str(target)],capture_output=True,timeout=180);(b/f'gate-build-{label}.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace');rows.append(dict(label=label,exit=r.returncode))
(b/'gate-build.json').write_bytes(json.dumps(rows).encode())
