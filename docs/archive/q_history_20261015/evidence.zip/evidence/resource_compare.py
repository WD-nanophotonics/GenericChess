from pathlib import Path
import sys,subprocess,time,json
b=Path('.local_agent/q-history-20261015');plan=json.loads((b/'resource-plan.json').read_text(encoding='utf-8'));rows=[];start=time.perf_counter()
for seed in plan['families']:
 remain=2400-(time.perf_counter()-start)
 if remain<=0:rows.append(dict(seed=seed,status='unstarted_fuse',planned_queries=8));continue
 t=time.perf_counter()
 try:r=subprocess.run([sys.executable,str(b/'resource_one.py'),str(seed)],capture_output=True,timeout=min(150,remain));output=r.stdout+r.stderr;status='complete'if r.returncode==0 else'failed'
 except subprocess.TimeoutExpired as e:output=(e.stdout or b'')+(e.stderr or b'');status='family_or_batch_censored'
 (b/f'resource-family-{seed}.log').write_bytes(output);rows.append(dict(seed=seed,status=status,seconds=time.perf_counter()-t,planned_queries=8));(b/'resource-results.json').write_bytes(json.dumps(dict(complete=False,rows=rows,seconds=time.perf_counter()-start)).encode());print(rows[-1],flush=True)
(b/'resource-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start)).encode())
