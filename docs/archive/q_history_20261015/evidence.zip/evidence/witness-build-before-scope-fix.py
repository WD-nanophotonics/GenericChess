from pathlib import Path
import sys,sysconfig,subprocess,shutil,json,datetime
R=Path.cwd();B=R/'.local_agent/q-history-20261015';D=B/'witness_src_v1';D.mkdir(exist_ok=True)
(B/'witness-plan.json').write_bytes(json.dumps(dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),question='Can a sibling-local fully rechecked opponent reply witness reduce the measured quiet terminal availability cost?',premise='Measured post-deferral terminal availability26-28percent of12/16kernel, literalcheck14-16percent. Current lazy generator already stops firstlegal, so savings may be too small.',inputs=[4011,4013,4021,4023,4031,4033,4041,4043],calls=32,settings='D3/1024nodes/q4/hard8/5s bothorders; final product vs private witness candidate',fuse_seconds=180,scope='Private feasibility only; per-q-node hint rechecked with EXACT existing normalized S3/S4 probe, failed hint falls back to full enumeration. No history/search/TT/terminal shortcut or product adoption.',decision='Only measured actual same-policy cost can justify further semantic qualification; negative/invalid results reject this route without broad cache infrastructure.'),indent=2).encode())
for p in (B/'final_src_v1').glob('*'):
 if p.suffix in('.c','.h'):shutil.copyfile(p,D/p.name)
p=D/'native_module.c';s=p.read_text(encoding='utf-8');needle='/* Only for a no-automatic-rule child';a=s.index(needle);helper='''/* PRIVATE sibling-local reply witness, never a search or transposition cache. */
typedef struct {GCSemanticAvailabilityProbe base;uint64_t action;int found;} GCQuietReplyProbe;
static uint64_t gc_quiet_witness_hits=0,gc_quiet_witness_misses=0;
static int gc_quiet_reply_visit(void *context,uint64_t action){
 GCQuietReplyProbe *p=context;int status=gc_semantic_runtime_probe_action_status(p->base.rules,&p->base.probe,action);
 if(status<0)p->base.failed=1;if(status>0){p->action=action;p->found=1;}return status!=0;
}
static int gc_quiet_reply_available(const GCSemanticRules *rules,const GCSemanticPosition *position,int *ok,uint64_t *action,int *have){
 GCQuietReplyProbe p;p.base.rules=rules;p.base.failed=0;p.found=0;
 memcpy(&p.base.probe,position,offsetof(GCSemanticPosition,history_lo));p.base.probe.ply=0;p.base.probe.history_len=0;p.base.probe.history_exact=1;p.base.probe.history_events_exact=position->history_events_exact;
 if(*have){int valid=gc_semantic_runtime_probe_action_status(rules,&p.base.probe,*action);if(valid<0){*ok=0;return 0;}if(valid>0){gc_quiet_witness_hits++;return 1;}}
 gc_quiet_witness_misses++;GCSemanticActionBuffer candidates;gc_semantic_action_buffer_init(&candidates);candidates.visit=gc_quiet_reply_visit;candidates.context=&p;
 int generated=gc_semantic_generate_candidate_buffer(rules,position,&candidates);if(!generated||p.base.failed){*ok=0;return 0;}
 *have=p.found;if(p.found)*action=p.action;return candidates.stopped;
}
''';s=s[:a]+helper+s[a:];s=s.replace('                                       int *winner) {','                                       int *winner, uint64_t *reply, int *have_reply) {');s=s.replace('int has_action = gc_semantic_has_guarded_action(rules, position, &ok);\n    if (!ok) return -1;\n    if (!has_action) {\n        if (gc_semantic_runtime_in_check(rules, position, position->side_to_move)) {','int has_action = gc_quiet_reply_available(rules, position, &ok, reply, have_reply);\n    if (!ok) return -1;\n    if (!has_action) {\n        if (gc_semantic_runtime_in_check(rules, position, position->side_to_move)) {')
s=s.replace('    int parent_enemies=0,legal=0;','    uint64_t reply_witness=0;int have_reply_witness=0;\n    int parent_enemies=0,legal=0;');s=s.replace('gc_semantic_q_quiet_terminal(ctx->rules, child, &child_winner)','gc_semantic_q_quiet_terminal(ctx->rules, child, &child_winner, &reply_witness, &have_reply_witness)');s=s.replace('static PyMethodDef gc_methods[] = {','''static PyObject *gc_witness_stats(PyObject*s,PyObject*a){return Py_BuildValue("KK",gc_quiet_witness_hits,gc_quiet_witness_misses);}
static PyMethodDef gc_methods[] = {
 {"witness_stats",gc_witness_stats,METH_NOARGS,"private witness work counts"},''');p.write_bytes(s.encode());r=subprocess.run([str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(D),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(x)for x in sorted(D.glob('*.c'))],'-o',str(B/('witness_v1'+sysconfig.get_config_var('EXT_SUFFIX')))],capture_output=True,timeout=180);(B/'witness-build.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace');s=(B/'post_compare.py').read_text(encoding='utf-8-sig').replace("('post_profile','post_v1')","('post_profile','witness_v1')").replace("if arm=='post_profile':mods[arm].post_reset()","if arm=='post_profile': pass").replace("mods[arm].post_get()","mods[arm].witness_stats()").replace("B/'post-results.json'","B/'witness-results.json'");(B/'witness_compare.py').write_bytes(s.encode())
