from pathlib import Path
import shutil,subprocess,sys,sysconfig,time,json,datetime
R=Path.cwd();b=R/'.local_agent/q-history-20261015';helper='''/* A discarded quiet view may omit only the identity/history append. Any
 * searched child is reconstructed through the complete checked transition. */
static int gc_semantic_q_history_deferrable(const GCSemanticRules *rules,
                                           const GCSemanticPosition *position) {
    if (rules->automatic_adjudication_count ||
        !position->history_exact || !position->history_events_exact ||
        position->history_len != position->ply + 1 ||
        position->history_len >= GC_SEM_MAX_PLY + 1 ||
        rules->repetition_limit < 2) return 0;
    uint32_t forbidden = rules->repetition_limit - 1;
    /* Every multiplicity is <= the number of recorded positions. This exact
     * bound avoids a quadratic scan on real long high-threshold histories. */
    if (position->history_len < forbidden) return 1;
    for (uint16_t i = 0; i < position->history_len; i++) {
        uint32_t count = 0;
        for (uint16_t j = 0; j < position->history_len; j++) {
            if (!memcmp(position->history_digest[i], position->history_digest[j],
                        sizeof(position->history_digest[0])) &&
                ++count >= forbidden) return 0;
        }
    }
    return 1;
}
/* Only for a no-automatic-rule child whose next-edge repetition is impossible.
 * General terminal/repetition authority must never consume transient history. */
static int gc_semantic_q_quiet_terminal(const GCSemanticRules *rules,
                                       const GCSemanticPosition *position,
                                       int *winner) {
    int ok = 1;
    int has_action = gc_semantic_has_guarded_action(rules, position, &ok);
    if (!ok) return -1;
    if (!has_action) {
        if (gc_semantic_runtime_in_check(rules, position, position->side_to_move)) {
            *winner = 1 - position->side_to_move;
            return 1;
        }
        if (rules->stalemate_result == 1) *winner = 1 - position->side_to_move;
        return 2;
    }
    if (position->ply >= rules->max_ply) return 4;
    return 0;
}
'''
for label in ('v1','v2'):
 dest=b/('q2_src_'+label);dest.mkdir(exist_ok=True)
 for p in (b/('quiet_src_'+label)).iterdir():
  if p.suffix in ('.c','.h'):shutil.copyfile(p,dest/p.name)
 p=dest/'native_module.c';s=p.read_text(encoding='utf-8');a=s.index('static int gc_semantic_q_history_deferrable');z=s.index('static int gc_semantic_quiescence',a);p.write_bytes((s[:a]+helper+s[z:]).encode());target=b/('q2_'+label+sysconfig.get_config_var('EXT_SUFFIX'));r=subprocess.run([str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(dest),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(x)for x in sorted(dest.glob('*.c'))],'-o',str(target)],capture_output=True,timeout=180);(b/f'q2-build-{label}.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace')
(b/'q2-plan.json').write_bytes(json.dumps(dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),changed_premise='Observed same-result quadratic gate512ply kernel6.597 regression; cheaper exact bound and early count exit preserve predicate, not result-dependent cap changes.',original_resource_curve_unchanged=True,new_checks='Repeat96real long-history control calls against baseline at same caps; original35semantic fixtures and final installed-source regression remain distinct qualification.',scope='No history truncation or new policy, full fallback preserved'),indent=2).encode())
s=(b/'long_history.py').read_text(encoding='utf-8-sig').replace("'quiet_v1*.pyd'","'q2_v1*.pyd'").replace("B/'long-history-results.json'","B/'long-history-q2-results.json'");(b/'long_history_q2.py').write_bytes(s.encode())
