from pathlib import Path
import json,math,collections,random,statistics
B=Path('.local_agent/q-history-20261015')
def policy(r):return tuple(r[k]for k in('completed_depth','result_ordinary_qdepth','result_check_hard_qdepth'))
def non_time(r):return {k:v for k,v in r.items()if 'elapsed'not in k}
def geometric(xs):return math.exp(statistics.mean(map(math.log,xs)))if xs else None
allrows=[]
for seed in json.loads((B/'resource-plan.json').read_text(encoding='utf-8'))['families']:
 d=json.loads((B/f'resource-family-{seed}.json').read_text(encoding='utf-8'));assert d['complete'];allrows+=d['rows']
invalid={4011,4013};pairs=[]
for seed in sorted({r['seed']for r in allrows}):
 for budget in (4,16):
  for order in (0,1):
   rr={r['arm']:r for r in allrows if(r['seed'],r['budget'],r['order'])==(seed,budget,order)};a,z=rr['baseline'],rr['quiet_candidate'];same=policy(a['result'])==policy(z['result']);pairs.append(dict(seed=seed,n=a['n'],budget=budget,order=order,valid_treatment=seed not in invalid,baseline_policy=policy(a['result']),candidate_policy=policy(z['result']),same_policy=same,same_policy_score_equal=(a['result']['score']==z['result']['score'])if same else None,same_action=a['result']['action']==z['result']['action'],depth_delta=z['result']['completed_depth']-a['result']['completed_depth'],caller_ratio=z['caller_seconds']/a['caller_seconds'],baseline_child=a['selected_child_terminal'],candidate_child=z['selected_child_terminal']))
valid=[p for p in pairs if p['valid_treatment']];summary=dict(complete=True,planned_queries=128,recorded_queries=len(allrows),invalid_query_slots=16,valid_query_slots=112,invalid_families=sorted(invalid),pairs=pairs,valid_summary=dict(pairs=len(valid),deeper=sum(p['depth_delta']>0 for p in valid),same_depth=sum(p['depth_delta']==0 for p in valid),shallower=sum(p['depth_delta']<0 for p in valid),same_policy=sum(p['same_policy']for p in valid),same_policy_score_mismatch=sum(p['same_policy_score_equal']is False for p in valid),same_action=sum(p['same_action']for p in valid)),scope='Original quadratic-gate candidate; two V1 baseline protocol-deviation families retained/excluded, no rerun/replacement. Whole1308.082s. Candidate at fixed wall budget may do more work; not strength.')
(B/'resource-summary.json').write_bytes(json.dumps(summary,indent=2).encode());print('Exposed',summary['valid_summary'])
# Fresh summary requires producer COMPLETE; never overwrite partial cohort as final.
status=json.loads((B/'fresh-results.json').read_text(encoding='utf-8'))
if not status['complete']:print('Fresh still active; summary deferred');raise SystemExit(0)
plan=json.loads((B/'fresh-plan.json').read_text(encoding='utf-8'));rows=[];missing=[];families=[]
for f in plan['families']:
 path=B/f"fresh-{f['seed']}.json"
 if not path.exists():missing.append(dict(seed=f['seed'],reason='no_output',planned_queries=24));continue
 d=json.loads(path.read_text(encoding='utf-8'));rows.extend(dict(**r,seed=f['seed'],n=f['n'])for r in d['rows']);families.append(dict(seed=f['seed'],n=f['n'],complete=d['complete'],roots=len(d['samples']),queries=len(d['rows']),bindings=d['source_bindings']))
 if len(d['rows'])<24:missing.append(dict(seed=f['seed'],reason='missing_roots_or_interrupted',planned_queries=24,recorded_queries=len(d['rows'])))
pairs=[]
for key in sorted({(r['seed'],r['ply'],r['setting'],r['order'])for r in rows}):
 rr={r['arm']:r for r in rows if(r['seed'],r['ply'],r['setting'],r['order'])==key}
 if len(rr)!=2:continue
 a,z=rr['baseline'],rr['final_candidate'];same=policy(a['result'])==policy(z['result']);diff=[k for k,v in non_time(a['result']).items()if v!=non_time(z['result']).get(k)];pairs.append(dict(seed=key[0],ply=key[1],setting=key[2],order=key[3],n=a['n'],same_policy=same,same_policy_score_equal=(a['result']['score']==z['result']['score'])if same else None,same_action=a['result']['action']==z['result']['action'],depth_delta=z['result']['completed_depth']-a['result']['completed_depth'],caller_ratio=z['caller_seconds']/a['caller_seconds'],non_time_mismatches=diff,clock_censored=any(r['result']['termination_reason']=='time_budget'for r in(a,z)),baseline_policy=policy(a['result']),candidate_policy=policy(z['result'])))
fixed=[p for p in pairs if p['setting']=='nodes1024'];wall=[p for p in pairs if p['setting']!='nodes1024'];boards=[]
for n in(4,8,12,16):
 ps=[p for p in fixed if p['n']==n and not p['clock_censored']];byfamily={s:[p['caller_ratio']for p in ps if p['seed']==s]for s in sorted({p['seed']for p in ps})};logs=[math.log(geometric(v))for v in byfamily.values()];rng=random.Random(20261015+n);boot=sorted(math.exp(statistics.mean(rng.choices(logs,k=len(logs))))for _ in range(4000))if logs else[];wp=[p for p in wall if p['n']==n];boards.append(dict(n=n,fixed_pairs=len(ps),families=len(logs),fixed_pair_ratio=geometric([p['caller_ratio']for p in ps]),family_ratio=math.exp(statistics.mean(logs))if logs else None,family_bootstrap95=[boot[int(.025*(len(boot)-1))],boot[int(.975*(len(boot)-1))]]if boot else None,wall_pairs=len(wp),deeper=sum(p['depth_delta']>0 for p in wp),same_depth=sum(p['depth_delta']==0 for p in wp),shallower=sum(p['depth_delta']<0 for p in wp),same_action=sum(p['same_action']for p in wp)))
fresh=dict(complete=True,planned_families=24,recorded_families=len(families),planned_roots=48,recorded_roots=sum(f['roots']for f in families),planned_queries=576,recorded_queries=len(rows),missing=missing,families=families,boards=boards,pairs=pairs,fixed_nonclock_mismatches=[p for p in fixed if p['non_time_mismatches']and not p['clock_censored']],wall_summary=dict(pairs=len(wall),deeper=sum(p['depth_delta']>0 for p in wall),same_depth=sum(p['depth_delta']==0 for p in wall),shallower=sum(p['depth_delta']<0 for p in wall),same_policy=sum(p['same_policy']for p in wall),same_policy_score_mismatch=sum(p['same_policy_score_equal']is False for p in wall),same_action=sum(p['same_action']for p in wall)),seconds=status['seconds'],scope='New predeclared development families, conditional complete-pair cost intervals under normal concurrency; not independent whole-domain generalization/strength. All planned slots/missing retained. Different cold engine construction scope from earlier exposed curve.')
(B/'fresh-summary.json').write_bytes(json.dumps(fresh,indent=2).encode());print('Fresh', {k:v for k,v in fresh.items()if k in('recorded_roots','recorded_queries','missing','boards','wall_summary','seconds')})
