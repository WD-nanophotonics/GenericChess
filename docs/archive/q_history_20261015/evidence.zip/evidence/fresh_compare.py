from pathlib import Path
import subprocess,sys,time,json
b=Path('.local_agent/q-history-20261015');plan=json.loads((b/'fresh-plan.json').read_text(encoding='utf-8'));start=time.perf_counter();rows=[]
for family in plan['families']:
 seed=family['seed'];remain=2400-(time.perf_counter()-start)
 if remain<=0:rows.append(dict(**family,status='unstarted_fuse',planned_queries=24));continue
 t=time.perf_counter()
 try:r=subprocess.run([sys.executable,str(b/'fresh_one.py'),str(seed),str(family['n'])],capture_output=True,timeout=min(150,remain));output=r.stdout+r.stderr;status='complete'if r.returncode==0 else'failed'
 except subprocess.TimeoutExpired as e:output=(e.stdout or b'')+(e.stderr or b'');status='family_or_batch_censored'
 (b/f'fresh-{seed}.log').write_bytes(output);rows.append(dict(**family,status=status,seconds=time.perf_counter()-t,planned_queries=24));(b/'fresh-results.json').write_bytes(json.dumps(dict(complete=False,rows=rows,seconds=time.perf_counter()-start)).encode());print(rows[-1],flush=True)
(b/'fresh-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start)).encode())
