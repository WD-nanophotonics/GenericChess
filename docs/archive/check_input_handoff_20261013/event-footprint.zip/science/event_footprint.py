from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,gc_action_to_usi
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import semantic_executor as se
from scripts.research_record import write_record,record_value
D=Path('.local_agent/tt-transfer-20261013')
assert not (D/'event-footprint-plan.json').exists()
write_record(D/'event-footprint-plan.json',dict(question='Do existingactualtransition events already provide a completewrite footprint forrequiredhashdiff?',search_calls=0,transitions=3,cases=['promotion','drop','capture-promotion'],decision='If events missactualwrites/handchanges, cannotreuse them asgenerichash footprint; no sourcetargetguess ornewruntimecollectionframework'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));engine=se.semantic_engine_for(c);old_init=se._WorkingPosition.__init__;old_position=se._WorkingPosition.to_position;observations=[]
def init(self,parent,support):
    old_init(self,parent,support);self._diagnostic_parent=parent
def finish(self,aux,fingerprint):
    child=old_position(self,aux,fingerprint);parent=self._diagnostic_parent
    changed=[i for i,(a,b) in enumerate(zip(parent.board,child.board)) if a!=b]
    events=[record_value(x) for x in self.events];event_squares=sorted({x[2] for x in self.events})
    observations.append(dict(changed_board_indices=changed,event_squares=event_squares,events=events,missing_indices=sorted(set(changed)-set(event_squares)),hand_changed=parent.hands!=child.hands,aux_changed=parent.aux_state!=child.aux_state))
    return child
results=[]
for case_id,label in [('shogi-promotion','5c5b+'),('shogi-drop','R*5e'),('shogi-middle','8h2b+')]:
    b=CoreBoard(next(x for x in CASES if x['id']==case_id),c);actions={gc_action_to_usi(a):a for a in b.runtime.legal_actions()};a=actions[label];semantic,binding=b.runtime._bindings[a]
    observations.clear();se._WorkingPosition.__init__=init;se._WorkingPosition.to_position=finish
    try:child=engine._transition(b.initial.position,semantic,binding)
    finally:se._WorkingPosition.__init__=old_init;se._WorkingPosition.to_position=old_position
    assert len(observations)==1
    row=dict(case=case_id,action=label,**observations[0]);results.append(row);print(row,flush=True)
assert results[0]['missing_indices'] and results[1]['missing_indices'] and results[2]['hand_changed']
write_record(D/'event-footprint-results.json',dict(transitions=3,search_calls=0,events_not_generic_write_set=True,results=results,source_target_bound_rejected=True,new_collection_framework=False))
