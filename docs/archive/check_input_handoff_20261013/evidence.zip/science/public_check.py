from pathlib import Path
import sys,json,time,hashlib,random
from dataclasses import asdict
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
D=Path('.local_agent/tt-transfer-20261013')
def save(n,x): (D/n).write_bytes((json.dumps(x,indent=2)+'\n').encode('utf-8'))
assert not (D/'public-check-plan.json').exists()
save('public-check-plan.json',dict(question='Does actualdefault-off publicflag reproduce privatecoupled bool/history/work andnet cost?',calls=8,roots=['shogi-middle','shogi-promotion'],depths=[3,8],seconds=15,q=0,hardq=0,tt=True,entry='ActualAlphaBetaPlayer constructor only, no monkeypatch',opposite_orders=True,promoted_hand_aux_history='complete typedfields/witnesses retained',source_hashes={x:hashlib.sha256(Path(x).read_bytes()).hexdigest() for x in ['generic_chess/ai/alphabeta/native_legality.py','generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/player.py']}))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));rows=[]
for case in [x for x in CASES if x['id'] in ('shogi-middle','shogi-promotion')]:
    b=CoreBoard(case,c)
    if case['id']=='shogi-middle':
        s=GameSession(c)
        for label in case['moves'].split():s.submit({gc_action_to_usi(a):a for a in s.legal_actions()}[label])
        assert s.state==b.initial and s._search_witnesses==b.witnesses
    else:s=SimpleNamespace(state=b.initial,_search_witnesses=b.witnesses)
    before=s.state;witness=s._search_witnesses;depth=3 if case['id']=='shogi-middle' else 8
    for rep in range(2):
        for enabled in ([False,True] if rep==0 else [True,False]):
            p=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),tt_max_entries=65536,use_disk_cache=False,use_native_semantic_availability=True,use_native_semantic_check=enabled,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
            start=time.perf_counter();r=p.choose_action(s,SearchLimits(max_depth=depth,max_nodes=None,max_time_seconds=15,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-start
            assert r.completed_depth==depth and s.state==before and s._search_witnesses==witness and r.native_legality_fallbacks==0
            pv=[gc_action_to_usi(a) for a in r.principal_variation];state=before
            for label in pv:
                acts={gc_action_to_usi(a):a for a in legal_actions(state,c)};assert label in acts;state=apply_action(state,acts[label],c)
            d=asdict(r);d.pop('action');d.pop('principal_variation');d.pop('declaration',None)
            rows.append(dict(case=case['id'],enabled=enabled,repeat=rep,wall=wall,action=gc_action_to_usi(r.action),pv=pv,decision=d,availability=p.native_legality_provider.availability_metrics,check=p.native_legality_provider.check_metrics,root_restored=True))
            save('public-check-rows.json',rows)
            print(case['id'],rep,enabled,r.completed_depth,r.nodes,r.qnodes,r.score,round(wall,4),flush=True)
checks=[]
for name in ['shogi-middle','shogi-promotion']:
    group=[x for x in rows if x['case']==name];ref=group[0]
    def sig(x):return x['action'],x['pv'],{k:v for k,v in x['decision'].items() if not(k.endswith('_seconds') or k.startswith('time_to_'))}
    checks.append(dict(case=name,all_complete_nontime_tuple_exact=all(sig(x)==sig(ref) for x in group)))
assert all(x['all_complete_nontime_tuple_exact'] for x in checks)
save('public-check-validation.json',dict(calls=8,checks=checks,all_core_pvs_replayed=True))
