from pathlib import Path
import sys,json,time,hashlib
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,Material,gc_action_to_usi
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
D=Path('.local_agent/tt-transfer-20261013')
def save(name,d): (D/name).write_bytes((json.dumps(d,indent=2)+'\n').encode('utf-8'))
assert not (D/'declaration.json').exists()
case=next(x for x in CASES if x['id']=='shogi-middle')
save('declaration.json',dict(question='Does sparse-root existingTT same-work overhead transfer to realplayed middle root?',case=case,depth=3,seconds=10,node_cap=None,calls=4,orders=['TT,noTT','noTT,TT'],base='ecd988d17c7ad06d55db3e5329d9e570892b6cf2',controls='ActualGameSession,fullPVTrue,Nativelegality+availability,orderingTrue,rootTacticalFalse,q0hard0,TTcold65536 ordisabled,completefullhistory/prices',outcomes='Only identical full tuple/work implies pureoverhead; otherwise record scheduling change. No default/globalTTchange.'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));s=GameSession(c)
for label in case['moves'].split():
    actions={gc_action_to_usi(a):a for a in s.legal_actions()};s.submit(actions[label])
before=s.to_record(); rows=[]
for rep in range(2):
    for tt in ([True,False] if rep==0 else [False,True]):
        assert not json.loads(Path('.local_agent/rollout.json').read_text(encoding='utf-8'))['user_paused']
        p=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),tt_max_entries=65536,use_disk_cache=False,use_tt=tt,use_native_semantic_availability=True,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
        start=time.perf_counter();r=p.choose_action(s,SearchLimits(max_depth=3,max_time_seconds=10,max_nodes=None,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-start
        pv=[gc_action_to_usi(a) for a in r.principal_variation]
        assert r.completed_depth==3 and s.to_record()==before
        state=s.state
        for label in pv:
            actions={gc_action_to_usi(a):a for a in legal_actions(state,c)};assert label in actions;state=apply_action(state,actions[label],c)
        d=asdict(r);d.pop('action');d.pop('principal_variation');d.pop('declaration',None)
        row=dict(tt=tt,repeat=rep,wall=wall,action=gc_action_to_usi(r.action),pv=pv,detail=d,availability=p.native_legality_provider.availability_metrics)
        rows.append(row);save('rows.json',rows);print(tt,rep,r.nodes,r.tt_hits,r.tt_cutoffs,row['action'],r.score,pv,round(wall,4),flush=True)
save('closed.json',dict(calls=4,full_history_records=len(s.state.history),record_restored=s.to_record()==before))
