from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.semantic_executor import semantic_engine_for
D=Path('.local_agent/tt-transfer-20261013')
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));b=CoreBoard(next(x for x in CASES if x['id']=='chess-ep'),c)
p=NativeSemanticLegalityProvider.try_create(c,strict=True);held=[]
fault=RuntimeError('availability first checkpoint cancellation')
def check(position,side,checkpoint=None):
    value=p.in_check(position,side,checkpoint=checkpoint);held.append(position);return value
def availability(position,checkpoint=None):
    assert held and position is held[-1]
    def interrupted():raise fault
    return p.has_legal_action(position,checkpoint=interrupted)
r=SearchPathRuntime.from_state(b.initial,c,history_witnesses=b.witnesses,legal_binding_provider=p,availability_provider=availability,check_provider=check)
def snap():
    return r.position,tuple(r.history),r.ply_count,r.runtime_hash,r.terminal_status,r.depth,r._snapshot,r._history_context
before=snap();action=r.legal_actions()[0]
try:r.push(action)
except RuntimeError as exc:assert exc is fault
else:raise AssertionError('required cancellation missing')
assert len(held)==1
P=held[0];metrics_before=p.availability_metrics;pending_empty=p._metrics_local.check_handoff is None
restored=snap()==before
value=p.has_legal_action(P);imports_delta=p.availability_metrics['imports']-metrics_before.get('imports',0)
out=dict(source_sha256=hashlib.sha256(Path('generic_chess/ai/alphabeta/native_legality.py').read_bytes()).hexdigest(),exact_original_exception=True,native_queries_before_retry=metrics_before.get('queries',0),full_state_history_counts_context_restored=restored,pending_empty_after_cancel=pending_empty,same_exact_object_retry=True,retry_imports_delta=imports_delta,retry_matches_core=value==semantic_engine_for(c).has_legal_action(P))
name=sys.argv[1]
(D/name).write_bytes((json.dumps(out,indent=2)+'\n').encode())
print(out,flush=True)
if name.startswith('fixed'):assert pending_empty and imports_delta==1 and restored and out['native_queries_before_retry']==0 and out['retry_matches_core']
else:assert not pending_empty and imports_delta==0 and restored
