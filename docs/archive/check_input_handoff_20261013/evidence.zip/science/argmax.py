from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
D=Path('.local_agent/tt-transfer-20261013')
assert not (D/'argmax-plan.json').exists()
(D/'argmax-plan.json').write_bytes(json.dumps(dict(question='Are changed TT-on/off D3 root actions both globally optimal under the same finite material target?',calls=42,method='Every existing specialist legal child D2 with exactterminal plyoffset/fullhistory, no selective rootwindow',decision='If not in argmax investigateengine; otherwise preserve tie-contract limitation and shift remainingactualtransport/check cost')).encode())
case=next(x for x in CASES if x['id']=='shogi-middle');b=ShogiBoard(case);oldterm=b.terminal;b.terminal=lambda ply:oldterm(ply+1);rows=[]
for label,move in b.actions():
    b.push(move);oldroot,oldhist=b.root_sfen,b.root_history;b.root_sfen,b.root_history=b.board.sfen(),tuple(b.history)
    try:r=minimal_ab(b,2,seconds=10,node_limit=10**12)
    finally:b.root_sfen,b.root_history=oldroot,oldhist;b.pop()
    assert r['reason']=='completed_depth'
    rows.append(dict(action=label,root_score=-r['score'],work=r['work']))
best=max(x['root_score'] for x in rows)
out=dict(calls=len(rows),score=best,argmax=[x['action'] for x in rows if x['root_score']==best],rows=rows,root_restored=b.restored())
source=json.loads((D/'rows.json').read_text());out['four_actions_optimal']=all(x['action'] in out['argmax'] and x['detail']['score']==best for x in source)
assert out['calls']==42 and out['four_actions_optimal'] and out['root_restored']
(D/'argmax.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
print('D3 fullargmax',best,out['argmax'],'42childcalls;allfourTT choicesoptimal',flush=True)
