from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests/product'));sys.path.insert(0,str(ROOT/'tests'))
from test_runtime_action_history_key import pair
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
D=Path('.local_agent/tt-transfer-20261013')
class Eval:
    def type_value(self,tid):return 0 if tid=='K' else 100
    def capture_order_value(self,moving,captured):return 10*self.type_value(captured.current_type_id)-self.type_value(moving.current_type_id)
    def evaluate(self,state):return sum((1 if x.owner==state.position.side_to_move else -1)*self.type_value(x.current_type_id) for x in state.position.board if x is not None)
assert not (D/'history-gate-plan.json').exists()
write_record(D/'history-gate-plan.json',dict(question='Does one-use state-local transport preserve samePosition/differentconsecutivehistory andCore-owned terminalshortcuts?',calls=4,fixture='Existingproduct test_runtime_action_history_key.pair: leftpass/rightnoop sameposition/ply/count butdifferentnextpass terminal',limits='D2/q0hard0/5s/fullPV/NativelegalityFalse/Corefrontiers, Nativeavailability/check flagsFalse/True',evidence='Complete callerrecords/corefullhistory preserved, compareflags withinhistory notdifferenthistories; activebackend explicit'))
c,left,right=pair();assert left.state.position==right.state.position
rows=[]
for enabled in [False,True]:
    player=AlphaBetaPlayer(c,evaluator_override=Eval(),use_disk_cache=False,use_native_semantic_legality=False,use_native_semantic_availability=enabled,use_native_semantic_check=enabled,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
    for name,s in [('pass-history',left),('noop-history',right)]:
        before=s.to_record();v=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=None,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
        assert s.to_record()==before
        provider=player.native_legality_provider
        rows.append(dict(enabled=enabled,history=name,provider_created=provider is not None,check={} if provider is None else provider.check_metrics,availability={} if provider is None else provider.availability_metrics,decision=record_value(v),record_restored=True))
        print(enabled,name,v.completed_depth,v.score,v.principal_variation,'provider',provider is not None,flush=True)
write_record(D/'history-gate-rows.json',rows)
checks=[]
for name in ['pass-history','noop-history']:
    g=[r for r in rows if r['history']==name]
    sig=[{k:v for k,v in r['decision'].items() if not(k.endswith('_seconds') or k.startswith('time_to_'))} for r in g]
    checks.append(dict(history=name,all_nontime_exact=sig[0]==sig[1]))
assert all(x['all_nontime_exact'] for x in checks)
write_record(D/'history-gate-validation.json',dict(calls=4,checks=checks,sameposition_history_not_cached=True))
