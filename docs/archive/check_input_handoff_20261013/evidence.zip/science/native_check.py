from pathlib import Path
import sys,json,time,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,in_check
D=Path('.local_agent/tt-transfer-20261013')
def save(n,x): (D/n).write_bytes((json.dumps(x,indent=2)+'\n').encode('utf-8'))
assert not (D/'native-check-plan.json').exists()
save('native-check-plan.json',dict(question='Does replacing only mandatory child gave-check with existingNative scalar query save wholecalls after paying fullstatepack?',calls=9,roots=['shogi-middle','shogi-promotion'],depths=[3,6],arms=['original_core_check','fullpack_native_check'],order='two opposite pairs',shadow='one actualmiddleD3 all mandatorygavecheck old/newbool comparison',scope='Privateprocess-only runtime method substitution, complete state/hand/aux payload nohistoryremoval; Core still owns completeactualhistory/terminal/collision/error commits. Only these supportedShogi roots; not publicAPI/fullgenerated transfer.',criteria='Exactwholetrace/work/result/history plus unprofiledwholecall cost in bothorders; reject ifpackcostloses; no newcache/kernel/default or additionalrootbudgethunt'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
original=SearchPathRuntime._gave_check;shadow_count=0;digest=hashlib.sha256()
def native_check(self,position,checkpoint=None):
    if position.ruleset_fingerprint!=provider.native_rules.fingerprint:raise ValueError('private scalarcheck source mismatch')
    if checkpoint is not None:checkpoint()
    packed=pack_position(provider.native_rules,provider._state_only_payload(position,0))
    value=in_check(provider.native_rules,packed,position.side_to_move)
    if checkpoint is not None:checkpoint()
    return value
def shadow(self,position,checkpoint=None):
    global shadow_count
    old=original(self,position,checkpoint);new=native_check(self,position,checkpoint)
    assert old==new,('actualchild check mismatch',position.side_to_move)
    shadow_count+=1;digest.update(bytes([old,position.side_to_move]))
    return old
def board(case):
    b=CoreBoard(case,c,provider=provider)
    b.runtime=SearchPathRuntime.from_state(b.initial,c,history_witnesses=b.witnesses,legal_binding_provider=provider,availability_provider=provider.has_legal_action)
    return b
b=board(next(x for x in CASES if x['id']=='shogi-middle'))
SearchPathRuntime._gave_check=shadow
try:r=minimal_ab(b,3,seconds=30,node_limit=10**12)
finally:SearchPathRuntime._gave_check=original
assert r['reason']=='completed_depth' and shadow_count==10425 and r['work']['nodes']==10426
save('native-check-shadow.json',dict(checks=shadow_count,all_equal=True,digest=digest.hexdigest(),result=r))
print('shadow',shadow_count,'actualCorechilds allboolagree',flush=True)
rows=[]
for case in [x for x in CASES if x['id'] in ('shogi-middle','shogi-promotion')]:
    depth=3 if case['id']=='shogi-middle' else 6;b=board(case)
    for rep in range(2):
        for arm in (['original_core_check','fullpack_native_check'] if rep==0 else ['fullpack_native_check','original_core_check']):
            SearchPathRuntime._gave_check=original if arm=='original_core_check' else native_check
            before_history=b.runtime.history
            try:r=minimal_ab(b,depth,seconds=30,node_limit=10**12,trace=False)
            finally:SearchPathRuntime._gave_check=original
            assert r['reason']=='completed_depth' and b.runtime.history==before_history
            rows.append(dict(case=case['id'],arm=arm,repeat=rep,full_history_restored=True,**r));save('native-check-cost.json',rows)
            print(case['id'],arm,rep,r['work']['nodes'],r['score'],r['move'],r['wall_seconds'],flush=True)
checks=[]
for name in ['shogi-middle','shogi-promotion']:
    group=[r for r in rows if r['case']==name];ref=group[0]
    checks.append(dict(case=name,all_fullwork_result_exact=all((r['work'],r['score'],r['move'],r['completed_depth'])==(ref['work'],ref['score'],ref['move'],ref['completed_depth']) for r in group)))
assert all(x['all_fullwork_result_exact'] for x in checks)
save('native-check-validation.json',dict(calls=9,checks=checks,shadow=shadow_count,history_restored=True,production_changed=False))
