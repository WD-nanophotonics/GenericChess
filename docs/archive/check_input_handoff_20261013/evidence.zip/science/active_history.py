from pathlib import Path
import sys,json
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.learning.shogi_certification import PERPETUAL_CHECK_MOVES,PERPETUAL_CHECK_SFEN,_seed_history
from generic_chess.learning.shogi_rules import sfen_to_gc_state,usi_to_gc_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.position import HistoryRecord
from generic_chess.core.terminal import terminal_result
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.search_backend_comparison import Material
from scripts.research_record import write_record,record_value
D=Path('.local_agent/tt-transfer-20261013')
assert not (D/'active-history-plan.json').exists()
write_record(D/'active-history-plan.json',dict(question='Does activeNative coupledcheck preserve sameexactPosition terminalcontinuous-check versusfreshlegalhistory?',calls=4,fixture='Existingcertification legalperpetualcheckfullcycle thenfreshsnapshot ofsameimmutablePosition',resources='D1/q0hard0/5s/publicflagsFalseTrue/fullwitnesses',meaning='FiniteCorehistoryprecedence, not declaration/fullgenerateddomain proof; terminal noNativequeries, freshactualactivecheck'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));s=GameSession(c);s._state=_seed_history(c,sfen_to_gc_state(c,PERPETUAL_CHECK_SFEN));s._search_history_witnesses=(s._state.position,)
for usi in PERPETUAL_CHECK_MOVES:s.submit(usi_to_gc_action(c,s.state,usi))
assert s.state.terminal_status.is_terminal and s.state.terminal_status.winner==1
P=s.state.position;key=position_identity_key(P,c)
fresh=replace(s.state,ply_count=0,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),))
fresh=replace(fresh,terminal_status=terminal_result(fresh,c))
assert not fresh.terminal_status.is_terminal and fresh.position is P
t=GameSession(c);t._state=fresh;t._search_history_witnesses=(P,)
rows=[]
for enabled in [False,True]:
    player=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),use_disk_cache=False,use_native_semantic_availability=enabled,use_native_semantic_check=enabled,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
    assert player.native_legality_provider is not None
    for name,session in [('terminal-full-history',s),('fresh-same-position',t)]:
        before=session.state;w=session._search_witnesses;v=player.choose_action(session,SearchLimits(max_depth=1,max_nodes=None,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
        assert session.state is before and session._search_witnesses==w
        provider=player.native_legality_provider
        row=dict(enabled=enabled,history=name,decision=record_value(v),actual_native_provider=True,check=provider.check_metrics,availability=provider.availability_metrics,history_records=len(session.state.history),same_position_object=session.state.position is P,root_restored=True)
        rows.append(row)
        if name.startswith('terminal'):
            assert v.action is None and v.termination_reason=='terminal_position' and provider.check_metrics=={} and provider.availability_metrics=={}
        else:
            assert v.completed_depth==1 and v.action in session.legal_actions()
            if enabled:assert provider.check_metrics['queries']>0 and provider.availability_metrics['reused_imports']>0
        print(enabled,name,v.completed_depth,v.score,v.termination_reason,'history',len(session.state.history),flush=True)
write_record(D/'active-history-rows.json',rows)
checks=[]
for name in ['terminal-full-history','fresh-same-position']:
    g=[r for r in rows if r['history']==name];sig=[{k:v for k,v in r['decision'].items() if not(k.endswith('_seconds') or k.startswith('time_to_'))} for r in g];checks.append(dict(history=name,all_nontime_exact=sig[0]==sig[1]))
assert all(x['all_nontime_exact'] for x in checks)
write_record(D/'active-history-validation.json',dict(calls=4,checks=checks,same_exact_position=True,all_active_native_created=True,core_terminal_precedence=True))
