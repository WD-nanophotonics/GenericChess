from pathlib import Path
import sys,json,time,random,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
D=Path('.local_agent/tt-transfer-20261013');out=D/'generated_resource';out.mkdir(exist_ok=True)
assert not (out/'declaration.json').exists()
decl=dict(question='Does the current public flag change completed horizon under equal 1/4s budget on the already exposed four generated roots?',seeds=list(range(2026101601,2026101605)),board_size=8,setup='bilateral_random',hybrid=True,prefix=8,rng_offset=13000,seconds=[1,4],max_nodes=None,q_depths=[0,4],hardq=8,requested_depths=[12,12],repeats=2,flags=[False,True],declared_cells=64,no_replacement=True,wall_max_seconds=900,expected_search_bound=320,scope='Completegeneratedlegacy rules compiledsemanticIR plusread-onlymetadata adapter; promotion/drop/aux/history preserved; finitecohort not completegenerated-domain proof. ActualpublicAlphaBetaPlayer/nohelpers/patches, Nativeattack evaluator fixedbotharms; actualunsupported/unavailable cases retained.',source_hashes={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in ['generic_chess/ai/alphabeta/player.py','generic_chess/ai/alphabeta/native_legality.py','generic_chess/core/search_runtime.py']},limits='No humanprice, pretrainedhumanreference/holdout, extendedoldcap orquietmachine claim')
write_record(out/'declaration.json',decl)
start=time.perf_counter();samples=[];roots=[];unavailable=[]
for seed in decl['seeds']:
    p.rr.stopped()
    try:
        cfg=p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True)
        g=p.generate_game(cfg);source=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
        c=p.SearchMetadataAdapter(ir=source.ir,_legacy_compiled=source._legacy_compiled,support=source.support)
        ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(seed+13000)
        walk=[]
        for _ in range(8):
            if s.result.status.value!='ongoing':raise ValueError('terminal beforedeclaredprefix')
            acts=sorted(s.legal_actions(),key=repr)
            if not acts:raise ValueError('no legalaction beforedeclaredprefix')
            a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
        if s.result.status.value!='ongoing':raise ValueError('terminal atdeclaredroot')
        ev=SemanticAttackEvaluator(c,profile,ec,backend='native')
        roots.append((seed,c,s,ev))
        samples.append(dict(seed=seed,fingerprint=c.ruleset_fingerprint,state=record_value(s.state),witnesses=record_value(s._search_witnesses),profile=record_value(profile),config=record_value(ec),walk=walk))
    except (ValueError,RuntimeError,NotImplementedError) as exc:
        unavailable.append(dict(seed=seed,type=type(exc).__name__,reason=str(exc),declared_unexecuted_cells=16,resampled=False))
        print('unavailable',seed,type(exc).__name__,str(exc),flush=True)
write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable))
rows=[];runtimes=[];oldattach=SearchPathRuntime.attach_stats
def attach(rt,st):
    value=oldattach(rt,st);runtimes.append((rt,p.runtime_state(rt)));return value
try:
    SearchPathRuntime.attach_stats=attach
    for seed,c,s,ev in roots:
        before=s.to_record()
        for q,depth,seconds in [(q,12,seconds) for q in [0,4] for seconds in [1,4]]:
            for rep in range(2):
                for enabled in ([False,True] if rep==0 else [True,False]):
                    p.rr.stopped()
                    if time.perf_counter()-start>=900:raise RuntimeError('declared wholeproducer wall exhausted; keep incomplete')
                    runtimes.clear()
                    player=AlphaBetaPlayer(c,evaluator_override=ev,tt_max_entries=65536,use_disk_cache=False,use_native_semantic_availability=True,use_native_semantic_check=enabled,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
                    t=time.perf_counter();value=player.choose_action(s,SearchLimits(max_depth=depth,max_time_seconds=seconds,max_nodes=None,quiescence_max_depth=q,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
                    assert s.to_record()==before
                    for rt,snap in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==snap
                    state=s.state
                    for a in value.principal_variation:
                        assert a in legal_actions(state,c);state=apply_action(state,a,c)
                    provider=player.native_legality_provider
                    rows.append(dict(seed=seed,q=q,seconds=seconds,depth_requested=depth,enabled=enabled,repeat=rep,wall=elapsed,actual_provider=provider is not None,availability={} if provider is None else provider.availability_metrics,check={} if provider is None else provider.check_metrics,decision=record_value(value),full_root_history_record_restored=True,all_pv_actions_core_legal=True))
                    write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable))
                    print(seed,q,seconds,rep,enabled,value.completed_depth,value.score,value.termination_reason,value.nodes,value.qnodes,round(elapsed,4),flush=True)
finally:SearchPathRuntime.attach_stats=oldattach
write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
