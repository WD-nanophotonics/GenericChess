from pathlib import Path
import sys,json,time,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,in_check,has_legal_action
D=Path('.local_agent/tt-transfer-20261013')
def save(n,x): (D/n).write_bytes((json.dumps(x,indent=2)+'\n').encode('utf-8'))
assert not (D/'coupled-probe-plan.json').exists()
save('coupled-probe-plan.json',dict(question='Can one exact child immutable-state import serve existing mandatory gavecheck andreadonlyavailability, instead of adding a second pack?',changed_premise='Standalone fullpack scalarcheck lost .789->.859 and .775->.875 middle; nowshare onlysameobject state-onlyply0 import with alreadyrequired availability',calls=9,roots=['shogi-middle','shogi-promotion'],depths=[3,6],order='oppositepairs',shadow='one actualD3 childchecks andavailability eachcompare original bool',scope='Privateoneentry exact-position-is capsule reuse; completepayload; threadprocess isolated; Corefullhistory/collision/terminalwinner unchanged; no source-targetdelta/cacheframework/default/API/NativeABI',criterion='Samework/fullresult/fullhistory andunprofiled wholecall win inbothorders, otherwise noadoption'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));provider=NativeSemanticLegalityProvider.try_create(c,strict=True);original_check=SearchPathRuntime._gave_check;original_avail=provider.has_legal_action
metrics=dict(imports=0,check_queries=0,availability_queries=0,reuses=0,misses=0,check_shadows=0,availability_shadows=0);cache=[None,None];shadow_mode=False
def acquire(position,checkpoint):
    if checkpoint is not None:checkpoint()
    if position.ruleset_fingerprint!=provider.native_rules.fingerprint:raise ValueError('private exactprobe source mismatch')
    if cache[0] is position:
        metrics['reuses']+=1;return cache[1]
    metrics['imports']+=1;metrics['misses']+=1
    packed=pack_position(provider.native_rules,provider._state_only_payload(position,0));cache[:]=[position,packed]
    return packed
def check(self,position,checkpoint=None):
    packed=acquire(position,checkpoint);value=in_check(provider.native_rules,packed,position.side_to_move);metrics['check_queries']+=1
    if shadow_mode:
        old=original_check(self,position,checkpoint);assert value==old;metrics['check_shadows']+=1
    if checkpoint is not None:checkpoint()
    return value
def availability(position,checkpoint=None):
    if provider._requires_reply_probe and c.support.max_ply<=1:return original_avail(position,checkpoint)
    value=has_legal_action(provider.native_rules,acquire(position,checkpoint));metrics['availability_queries']+=1
    if shadow_mode:
        old=original_avail(position,checkpoint);assert value==old;metrics['availability_shadows']+=1
    if checkpoint is not None:checkpoint()
    return value
def make(case,candidate):
    b=CoreBoard(case,c,provider=provider);b.runtime=SearchPathRuntime.from_state(b.initial,c,history_witnesses=b.witnesses,legal_binding_provider=provider,availability_provider=availability if candidate else original_avail);return b
case=next(x for x in CASES if x['id']=='shogi-middle');b=make(case,True);shadow_mode=True;SearchPathRuntime._gave_check=check
history=b.runtime.history
try:r=minimal_ab(b,3,seconds=30,node_limit=10**12)
finally:SearchPathRuntime._gave_check=original_check
assert r['work']['nodes']==10426 and b.runtime.history==history and metrics['check_shadows']==10425 and metrics['availability_shadows']==10425
save('coupled-probe-shadow.json',dict(result=r,metrics=dict(metrics),full_history_restored=True))
print('shadow',metrics,flush=True)
shadow_mode=False;rows=[]
for case in [x for x in CASES if x['id'] in ('shogi-middle','shogi-promotion')]:
    depth=3 if case['id']=='shogi-middle' else 6
    for rep in range(2):
        for candidate in ([False,True] if rep==0 else [True,False]):
            cache[:]=[None,None];before=dict(metrics);b=make(case,candidate);hist=b.runtime.history
            SearchPathRuntime._gave_check=check if candidate else original_check
            try:r=minimal_ab(b,depth,seconds=30,node_limit=10**12)
            finally:SearchPathRuntime._gave_check=original_check
            assert r['reason']=='completed_depth' and b.runtime.history==hist
            rows.append(dict(case=case['id'],candidate=candidate,repeat=rep,full_history_restored=True,metrics={k:v-before[k] for k,v in metrics.items()},**r));save('coupled-probe-cost.json',rows)
            print(case['id'],candidate,rep,r['wall_seconds'],r['work']['nodes'],r['move'],r['score'],flush=True)
checks=[]
for name in ['shogi-middle','shogi-promotion']:
    group=[r for r in rows if r['case']==name];ref=group[0];checks.append(dict(case=name,all_work_result_exact=all((r['move'],r['score'],r['work'],r['completed_depth'])==(ref['move'],ref['score'],ref['work'],ref['completed_depth']) for r in group)))
assert all(r['all_work_result_exact'] for r in checks)
save('coupled-probe-validation.json',dict(calls=9,checks=checks,one_entry_object_identity_only=True,production_changed=False))
