from pathlib import Path
import sys,json,types,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,Material,gc_action_to_usi
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from types import SimpleNamespace
D=Path('.local_agent/tt-transfer-20261013')
names=['generic_chess.core.search_runtime','generic_chess.ai.alphabeta.native_legality','generic_chess.ai.alphabeta.search','generic_chess.ai.alphabeta.player']
saved={name:sys.modules[name] for name in names}
assert not (D/'default-source-parity-plan.json').exists()
write_record(D/'default-source-parity-plan.json',dict(question='Does the newNativecheck default-OFF retain actualbefore-source publicdecision/work on normal andexistingNativeavailability q0/q4 paths?',calls=8,cases=['shogi-middle','shogi-promotion'],conditions=[dict(availability=False,q=0,depth=2),dict(availability=True,q=4,depth=1)],seconds=15,nodecap=None,before_source='Fourexactecd988d1 sourceblobs savedbeforepublicedit',scope='Newflag omittedbotharms; no code-default argument injection, no NativeABI changes; budgets unchanged'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));roots=[CoreBoard(case,c) for case in CASES if case['id'] in ('shogi-middle','shogi-promotion')]
rows=[]
try:
    for name in names:
        path=D/'before-public'/(name.rsplit('.',1)[1]+'.py')
        module=types.ModuleType(name);module.__file__=str(path);module.__package__=name.rsplit('.',1)[0]
        sys.modules[name]=module;exec(compile(path.read_text(encoding='utf-8'),str(path),'exec'),module.__dict__)
    before_player=sys.modules[names[-1]].AlphaBetaPlayer
    for phase,Player in [('before',before_player),('current',AlphaBetaPlayer)]:
        if phase=='current':sys.modules.update(saved)
        for root in roots:
            session=SimpleNamespace(state=root.initial,_search_witnesses=root.witnesses);before=session.state
            for av,q,depth in [(False,0,2),(True,4,1)]:
                player=Player(c,evaluator_override=Material('shogi'),tt_max_entries=65536,use_disk_cache=False,use_native_semantic_availability=av,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
                value=player.choose_action(session,SearchLimits(max_depth=depth,max_nodes=None,max_time_seconds=15,quiescence_max_depth=q,quiescence_hard_max_depth=8))
                assert session.state==before
                row=dict(phase=phase,case='shogi-middle' if root.initial.ply_count==8 else 'shogi-promotion',availability=av,q=q,decision=record_value(value))
                rows.append(row);write_record(D/'default-source-parity-rows.json',rows)
                print(phase,row['case'],av,q,value.completed_depth,value.nodes,value.qnodes,value.score,value.termination_reason,flush=True)
finally:sys.modules.update(saved)
checks=[]
for case in ['shogi-middle','shogi-promotion']:
    for av,q in [(False,0),(True,4)]:
        group=[r for r in rows if r['case']==case and r['availability']==av and r['q']==q]
        sig=[{k:v for k,v in r['decision'].items() if not(k.endswith('_seconds') or k.startswith('time_to_'))} for r in group]
        checks.append(dict(case=case,availability=av,q=q,all_before_current_nontime_exact=sig[0]==sig[1]))
assert all(r['all_before_current_nontime_exact'] for r in checks),checks
write_record(D/'default-source-parity-validation.json',dict(calls=8,checks=checks,before_classes_isolated_privateprocess=True))
