"""Declared rule-goal interaction diagnostic, no fitted material coefficient."""
import sys,json,time,random,hashlib
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.schema import RuleInitialSetupOption,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import initial_state,legal_successors
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'goal-feasibility.json';assert not out.exists();start=time.perf_counter();N=2048;types=('Q','R','B','N');rng=random.Random(202610084000);contexts=[];seen=set();attempts=0
def attacks(t,source,target,blocker):
 sf,sr=source%8,source//8;tf,tr=target%8,target//8;df,dr=tf-sf,tr-sr
 if t=='N':return sorted((abs(df),abs(dr)))==[1,2]
 valid=(df==0 or dr==0) if t=='R' else abs(df)==abs(dr) if t=='B' else (df==0 or dr==0 or abs(df)==abs(dr))
 if not valid:return False
 stepf=(df>0)-(df<0);stepr=(dr>0)-(dr<0);f,r=sf+stepf,sr+stepr
 while (f,r)!=(tf,tr):
  if f+8*r==blocker:return False
  f+=stepf;r+=stepr
 return True
while len(contexts)<N:
 attempts+=1;assert attempts<100000
 own,actor,enemy=rng.sample(range(64),3);key=own,actor,enemy
 if key in seen:continue
 if max(abs(own%8-enemy%8),abs(own//8-enemy//8))<=1:continue
 if any(attacks(t,actor,enemy,own) for t in types):continue
 seen.add(key);contexts.append(key)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Predeclared2048unique ordered triples, seed202610084000, uniform sampling without replacement conditional on both Kings safe for ALL Q/R/B/N variants. Same ownKing/actor/enemyKing population for all types; excludes initial checking/adjacent Kings using independent coordinate prefilter, then product compiler validates every alternate setup. Supported Western semantic rules unchanged except all initial castling rights explicitly off;3entity synthetic starts, no standard-opening reachability claim. Enumerate every legal first action, independently replay full child state/terminal in Native. Count immediate wins/drawn stalemates and minimum enemy legal actions: goal proximity and mobility focus are distinct. One250sec checkpoint, partial unknown if interrupted. Mechanism diagnostic only; zero B/N lone-mate count would falsify this as a complete material table, not their usefulness. No labels/default fit, no Elo/positional patch or new evaluator.',contexts=contexts,draw_attempts=attempts,cases=[]);write_record(out,r)
base=build_western_chess_ruleset();actions=tuple(replace(a,aux_state=tuple(replace(slot,initial=0) if slot.value_kind=='bool' else slot for slot in a.aux_state)) for a in base.semantic_actions)
def board(t,ctx):
 rows=[[None]*8 for _ in range(8)]
 for owner,tid,idx in ((0,'K',ctx[0]),(0,t,ctx[1]),(1,'K',ctx[2])):rows[idx//8][idx%8]=Piece(owner,tid,tid)
 return tuple(map(tuple,rows))
try:
 for t in types:
  definition=replace(base,initial_position=board(t,contexts[0]),initial_setup_options=tuple(RuleInitialSetupOption('c%04d'%i,board(t,ctx)) for i,ctx in enumerate(contexts[1:],1)),semantic_actions=actions)
  before=time.perf_counter();c=compile_ruleset_for_execution(definition);nr=compile_native_semantic_rules(c);case=dict(type=t,definition=ruleset_to_dict(definition),compile_seconds=time.perf_counter()-before,complete=False,roots=[],transitions=0);r['cases'].append(case)
  for index,ctx in enumerate(contexts):
   assert time.perf_counter()-start<250,'goal diagnostic checkpoint';s=initial_state(c,None if index==0 else 'c%04d'%index);m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True);pairs=legal_successors(s,c);nas=guarded_actions(nr,m.position);assert {a for a,ch in pairs}=={public_action(nr,a) for a in nas};wins=[];draws=[];min_replies=None;min_actions=[]
   for a,ch in pairs:
    na,=[x for x in nas if public_action(nr,x)==a];np=make_checked(nr,m.position,na);assert snapshot_matches(snapshot(nr,np),ch.position,nr,c);nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(ch.terminal_status.status.value,ch.terminal_status.winner)
    n=len(guarded_actions(nr,np));case['transitions']+=1
    if ch.terminal_status.is_terminal and ch.terminal_status.winner==0:wins.append(record_value(a))
    if ch.terminal_status.status.value=='stalemate' and ch.terminal_status.winner is None:draws.append(record_value(a))
    if min_replies is None or n<min_replies:min_replies=n;min_actions=[record_value(a)]
    elif n==min_replies:min_actions.append(record_value(a))
   case['roots'].append(dict(index=index,legal=len(pairs),wins=wins,drawn_stalemates=draws,min_enemy_replies=min_replies,min_actions=min_actions))
  case.update(complete=True,summary=dict(mate_roots=sum(bool(x['wins']) for x in case['roots']),drawn_stalemate_roots=sum(bool(x['drawn_stalemates']) for x in case['roots']),zero_mobility_without_win=sum(x['min_enemy_replies']==0 and not x['wins'] for x in case['roots'])));write_record(out,r);print(t,case['summary'],case['transitions'],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
