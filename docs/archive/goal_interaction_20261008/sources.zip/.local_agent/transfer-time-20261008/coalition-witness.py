"""Prospective four-cell rule-goal interaction, no fitted prices."""
import sys,json,time,random,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.schema import RuleInitialSetupOption,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.transition import initial_state,legal_successors
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'coalition-witness.json';assert not out.exists();start=time.perf_counter();N=1024;types=('Q','R','B','N');rng=random.Random(202610085000)
def attacks(t,source,target,blockers):
 df,dr=target%8-source%8,target//8-source//8
 if t=='N':return sorted((abs(df),abs(dr)))==[1,2]
 valid=(df==0 or dr==0) if t=='R' else abs(df)==abs(dr) if t=='B' else (df==0 or dr==0 or abs(df)==abs(dr))
 if not valid:return False
 sf,sr=(df>0)-(df<0),(dr>0)-(dr<0);f,r=source%8+sf,source//8+sr
 while (f,r)!=(target%8,target//8):
  if f+8*r in blockers:return False
  f+=sf;r+=sr
 return True
contexts=[('N',46,38,52,63),('B',46,52,38,63)];attempts=0
for ht,own,actor,helper,enemy in contexts:
 assert max(abs(own%8-enemy%8),abs(own//8-enemy//8))>1
 assert not any(attacks(t,actor,enemy,{own,helper}) for t in types)
 assert not attacks(ht,helper,enemy,{own,actor})
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Changed-premise constructive existence check AFTER zero B/N random batch, not expanded validation. Fixed K(g6),B(g5),N(e7),enemyK(h8), owner0; expected Bf6 mate. Swap actor/helper roles while preserving squares of physical B/N. Four virtual intervention cells enumerate every legal first action, full Native/Core parity, all initial castling rights off. If true this distinguishes rare missed support from impossible coalition; it does not estimate prevalence, repair exposed status, fit a table or overwrite random zero. Common all-Q/R/B/N-safe coordinate prefilter is checked independently for both actor roles.',contexts=contexts,draw_attempts=attempts,cases=[]);write_record(out,r)
base=build_western_chess_ruleset();base=replace(base,piece_types=base.piece_types+(PieceType('I','Immobile counterfactual',()),),drop_allowed={**base.drop_allowed,'I':((False,)*64,(False,)*64)})
actions=tuple(replace(a,aux_state=tuple(replace(slot,initial=0) if slot.value_kind=='bool' else slot for slot in a.aux_state)) for a in base.semantic_actions)
def board(t,cell,ctx):
 ht,own,actor,helper,enemy=ctx;rows=[[None]*8 for _ in range(8)]
 for owner,tid,idx in ((0,'K',own),(0,t if cell[0]=='A' else 'I',actor),(0,ht if cell[1]=='H' else 'I',helper),(1,'K',enemy)):rows[idx//8][idx%8]=Piece(owner,tid,tid)
 return tuple(map(tuple,rows))
try:
 # IH and II are actor-independent controls, evaluated once on same population.
 for ht,t,cell in [(ht,t,cell) for ht,t in (('N','B'),('B','N')) for cell in ('AH','IH','AI','II')]:
  subset=[(index,ctx) for index,ctx in enumerate(contexts) if ctx[0]==ht]
  definition=replace(base,initial_position=board(t,cell,subset[0][1]),initial_setup_options=tuple(RuleInitialSetupOption('c%04d'%i,board(t,cell,ctx)) for i,ctx in subset[1:]),semantic_actions=actions)
  before=time.perf_counter();c=compile_ruleset_for_execution(definition);nr=compile_native_semantic_rules(c);case=dict(helper=ht,type=t,cell=cell,definition=ruleset_to_dict(definition),compile_seconds=time.perf_counter()-before,complete=False,roots=[],transitions=0);r['cases'].append(case)
  for index,ctx in subset:
   assert time.perf_counter()-start<300,'coalition cost checkpoint'
   s=initial_state(c,None if index==subset[0][0] else 'c%04d'%index);m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True);pairs=legal_successors(s,c);nas=guarded_actions(nr,m.position);mapped={public_action(nr,a):a for a in nas};assert {a for a,ch in pairs}==set(mapped);wins=[];draws=[]
   for a,ch in pairs:
    np=make_checked(nr,m.position,mapped[a]);assert snapshot_matches(snapshot(nr,np),ch.position,nr,c);nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(ch.terminal_status.status.value,ch.terminal_status.winner);case['transitions']+=1
    if ch.terminal_status.is_terminal and ch.terminal_status.winner==0:wins.append(record_value(a))
    if ch.terminal_status.status.value=='stalemate' and ch.terminal_status.winner is None:draws.append(record_value(a))
   case['roots'].append(dict(index=index,legal=len(pairs),wins=wins,drawn_stalemates=draws))
  case.update(complete=True,mate_roots=sum(bool(x['wins']) for x in case['roots']));write_record(out,r);print(ht,t,cell,case['mate_roots'],case['transitions'],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
