"""Actual capture/drop goal intervention under the product Shogi rules."""
import sys,json,time,hashlib
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import initial_state,apply_action,legal_successors
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'shogi-goal.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Changed semantic mechanism, not another random mate sweep: fixed sparse StandardShogi starts ownK0,0 N3,2 G6,7 B6,5, enemyK8,8 N1,8 and targetP/G4,4. Actual Ncapture3,2to4,4 then enemyN1,8to0,6 yields a real hand and full history. Three predeclared cells:P original rule,P removing ONLY pawn-drop S4 postconditions,G original rule. Enumerate every legal current action/terminal; all route roots and child full Native/Core parity. Test whether pawn-drop-mate prohibition changes terminal-goal opportunity despite genuine hand acquisition; expected P drop8,7 forbidden, allowed and mating withoutS4, G mating drop allowed. Preserve every outcome and competing wins, not just expected witness. Synthetic sparse initial inventory, no opening reachability or material-price/strength claim. One30sec checkpoint, no enlargement.',cases=[]);write_record(out,r)
try:
 for target,enabled in (('P',True),('P',False),('G',True)):
  base=build_standard_shogi_ruleset();rows=[[None]*9 for _ in range(9)]
  for owner,tid,f,rank in ((0,'K',0,0),(0,'N',3,2),(0,'G',6,7),(0,'B',6,5),(1,'K',8,8),(1,'N',1,8),(1,target,4,4)):rows[rank][f]=Piece(owner,tid,tid)
  actions=base.semantic_actions if enabled else tuple(replace(a,postconditions=()) if a.name=='standard_drop_contract' else a for a in base.semantic_actions)
  definition=replace(base,initial_position=tuple(map(tuple,rows)),semantic_actions=actions);c=compile_ruleset_for_execution(definition);nr=compile_native_semantic_rules(c);s=initial_state(c);m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True);np=m.position;case=dict(target=target,pawn_drop_mate_filter=enabled,definition=ruleset_to_dict(definition),route=[],roots=[],winning_actions=[],transitions=0,complete=False);r['cases'].append(case)
  for ply in range(3):
   assert time.perf_counter()-start<30,'Shogi goal cost checkpoint'
   pairs=legal_successors(s,c);nas=guarded_actions(nr,np);mapped={public_action(nr,a):a for a in nas};assert set(mapped)=={a for a,ch in pairs};nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner);case['roots'].append(dict(ply=ply,legal=len(pairs),terminal=record_value(s.terminal_status),hands=record_value(s.position.hands)))
   for a,ch in pairs:
    nc=make_checked(nr,np,mapped[a]);assert snapshot_matches(snapshot(nr,nc),ch.position,nr,c);nt=terminal_status(nr,nc);assert (nt['status'],nt['winner'])==(ch.terminal_status.status.value,ch.terminal_status.winner);case['transitions']+=1
    if ply==2 and ch.terminal_status.is_terminal and ch.terminal_status.winner==0:case['winning_actions'].append(record_value(a))
   if ply<2:
    coords=((3,2),(4,4)) if ply==0 else ((1,8),(0,6));a,=[a for a,ch in pairs if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==coords[0] and (a.to_square.file,a.to_square.rank)==coords[1] and getattr(a,'promotion_target_id',None) is None];s=apply_action(s,a,c);np=make_checked(nr,np,mapped[a]);case['route'].append(record_value(a))
   else:case['drop87_legal']=any(getattr(a,'base_type_id',None)==target and (a.to_square.file,a.to_square.rank)==(8,7) for a,ch in pairs)
  case['complete']=True;write_record(out,r);print(target,enabled,case['drop87_legal'],'wins',len(case['winning_actions']),flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
