"""Explicit equal-order allocation of the retained finite goal observable."""
import json,hashlib
from fractions import Fraction as F
from pathlib import Path
p=Path(__file__).parent;out=p/'goal-allocation.json';assert not out.exists()
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Constructive analysis of frozen four-cell observations, no new simulation. Equal probability for adding actor first versus second: phiA=(mAI-mII+mAH-mIH)/2; phiH=(mIH-mII+mAH-mAI)/2. Per-context identity phiA+phiH=mAH-mII checked exactly. Symmetric order weighting is an explicit allocation convention, NOT uniquely selected by rules or evidence of stable material prices. Immobile occupancy baseline, conditional law and one-ply terminal task remain essential inputs. Fractions are exact averages of finite observed cohorts, not exact population probabilities. No human labels/normalization/defaults. Preserve sparse zeros; zero empirical variance is not zero uncertainty.',dependencies={},rows=[])
for name,law in (('coalition-qualified.json','broad-common-safe'),('coalition-near-qualified.json','edge-distance2-common-safe')):
 src=p/name;raw=json.loads(src.read_bytes());assert raw['complete'];r['dependencies'][name]=hashlib.sha256(src.read_bytes()).hexdigest()
 for ht in ('B','N'):
  for t in ('Q','R','B','N'):
   cs={cell:next(c for c in raw['cases'] if c['helper']==ht and c['type']==(t if cell[0]=='A' else 'I') and c['cell']==cell) for cell in ('AH','IH','AI','II')};a=[];h=[];tot=[];d=[]
   for k in range(len(cs['AH']['roots'])):
    ms={cell:int(bool(c['roots'][k]['wins'])) for cell,c in cs.items()};pa=F(ms['AI']-ms['II']+ms['AH']-ms['IH'],2);ph=F(ms['IH']-ms['II']+ms['AH']-ms['AI'],2);assert pa+ph==ms['AH']-ms['II'];a.append(pa);h.append(ph);tot.append(ms['AH']-ms['II']);d.append(ms['AH']-ms['IH']-ms['AI']+ms['II'])
   mean=lambda xs:str(sum(xs,F(0))/len(xs))
   r['rows'].append(dict(law=law,actor=t,helper=ht,n=len(a),phi_actor=mean(a),phi_helper=mean(h),total_goal_increment=mean(tot),interaction=mean(d),negative_actor_roots=sum(x<0 for x in a),negative_helper_roots=sum(x<0 for x in h)))
out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
for row in r['rows']:print(row['law'],row['actor'],row['helper'],row['phi_actor'],row['phi_helper'])
