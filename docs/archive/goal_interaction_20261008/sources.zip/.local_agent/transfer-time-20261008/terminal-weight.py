"""Exact constructive scalar family and ranking boundary on frozen vectors."""
import json,hashlib
from pathlib import Path
from fractions import Fraction as F
p=Path(__file__).parent;src=p/'shogi-goal-service-qualified.json';raw=json.loads(src.read_bytes());assert raw['complete'];out=p/'terminal-weight.json';assert not out.exists()
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),scope='Algebra on the already exposed exact finite-policy vector, no new simulation, selected weight or human labels. C(lambda)=U+lambda*win applies only to these all-no-loss/no-draw cells. Rule-only illustrative normalization win+U/81 makes terminalwin1 and ongoing endpoint<=80/81 at a leaf; this is an explicit utility convention, not calibrated WDL or uniquely implied price. Independent expected-value comparisons still depend on behavioral/context laws.',rows=[],contrasts=[])
values={}
for c in raw['cases']:
 assert c['terminal_probabilities']['loss']=='0' and c['terminal_probabilities']['draw']=='0';key='G' if c['target']=='G' else 'P-original' if c['pawn_drop_mate_filter'] else 'P-noS4';U=F(c['mean_U']);q=F(c['terminal_probabilities']['win']);values[key]=U,q;r['rows'].append(dict(cell=key,U=str(U),win=str(q),normalized_terminal_activity=str(q+U/81),C_at_lambda0=str(U),C_at_lambda1=str(U+q),C_at_lambda81=str(U+81*q)))
for a,b in (('G','P-original'),('G','P-noS4'),('P-noS4','P-original')):
 u=values[a][0]-values[b][0];q=values[a][1]-values[b][1];root=-u/q if q else None;r['contrasts'].append(dict(a=a,b=b,constant=str(u),lambda_coefficient=str(q),zero_at_lambda=str(root) if root is not None else None,positive_for_all_lambda_ge0=u>0 and q>=0))
for lam in (F(0),F(1),F(81)):
 g=values['G'][0]+lam*values['G'][1]
 for pawn in ('P-original','P-noS4'):r.setdefault('illustrative_ratios',[]).append(dict(lambda_=str(lam),denominator=pawn,G_ratio=str(g/(values[pawn][0]+lam*values[pawn][1]))))
out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode());print(json.dumps(r,indent=2))
