"""Decision effect of terminal-aware versus endpoint-only finite service."""
import json,hashlib
from pathlib import Path
from fractions import Fraction as F
p=Path(__file__).parent;src=p/'shogi-goal-service-qualified.json';raw=json.loads(src.read_bytes());assert raw['complete'];out=p/'goal-decision.json';assert not out.exists()
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),scope='Exact per-drop expected vectors from frozen legal drop/enemyreply census; no new search or sampled population. Endpoint-only versus predeclared board-normalized terminal/activity convention qwin+U/81. This local policy diagnostic is not a product-player regression, price fit, full-game utility or Elo measurement. Keep all tied maximizers; immediate-terminal q1/U0 separate from ongoing branches.',cases=[])
for c in raw['cases']:
 rows=[]
 for d in c['drops']:
  ts=d['immediate_terminal'];terminal=ts['status']!='ongoing';U=F(0) if terminal else sum((F(x['U']) for x in d['replies']),F(0))/len(d['replies']);q=F(int(ts['winner']==0)) if terminal else sum((F(int(x['terminal']['winner']==0)) for x in d['replies']),F(0))/len(d['replies']);rows.append(dict(action=d['drop'],U=str(U),qwin=str(q),normalized=str(q+U/81),immediate_win=terminal and ts['winner']==0))
 best_U=max(F(x['U']) for x in rows);best_C=max(F(x['normalized']) for x in rows);us=[x for x in rows if F(x['U'])==best_U];cs=[x for x in rows if F(x['normalized'])==best_C]
 r['cases'].append(dict(target=c['target'],pawn_drop_mate_filter=c['pawn_drop_mate_filter'],max_U=str(best_U),max_normalized=str(best_C),endpoint_maximizer_count=len(us),endpoint_maximizer_wins=sum(x['immediate_win'] for x in us),normalized_maximizer_count=len(cs),normalized_maximizer_wins=sum(x['immediate_win'] for x in cs),endpoint_witness=us[0],normalized_witness=cs[0],rows=rows))
out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
for c in r['cases']:print(c['target'],c['pawn_drop_mate_filter'],'Ubest',c['max_U'],c['endpoint_maximizer_count'],'winning',c['endpoint_maximizer_wins'],'Cbest',c['max_normalized'],c['normalized_maximizer_count'],'winning',c['normalized_maximizer_wins'])
