"""Exact finite terminal/activity vector after the declared real hand route."""
import sys,json,time,hashlib
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action,legal_successors
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'shogi-goal.json';raw=json.loads(src.read_bytes());assert raw['complete'];out=p/'shogi-goal-service-qualified.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='Prospective exact finite-vector continuation of fixed three Shogi cells, not a new population or fitted utility. Replay actual capture/enemyreply. Uniform legal target drops; after each nonterminal drop all enemy legal replies uniformly. At resulting own turn U=distinct tagged-base on-board legal endpoints, terminal0; separately retain terminalwin/loss/draw/ongoing probability, including immediate winning drops. Initial producer wrongly assumed uniqueG base despite preexisting friendlyG; partialP outputs and source preserved. Corrected actor identity is the actual drop destination: an enemy reply can capture but cannot move the owner0 dropped actor, so endpoint attribution stays exact. Full Native/Core every legal set/child/terminal. Question: can permitting a winning drop LOWER endpoint-only mean through terminal-zero normalization? If so retain terminal/activity vector, not activity-as-utility or arbitrary fitted blend. One30sec checkpoint, no extension.',cases=[]);write_record(out,r)
def verify(s,np,c,nr):
 nas=guarded_actions(nr,np);pairs=legal_successors(s,c);mapped={public_action(nr,a):a for a in nas};assert set(mapped)=={a for a,ch in pairs};nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner)
 for a,ch in pairs:
  nc=make_checked(nr,np,mapped[a]);assert snapshot_matches(snapshot(nr,nc),ch.position,nr,c);nt=terminal_status(nr,nc);assert (nt['status'],nt['winner'])==(ch.terminal_status.status.value,ch.terminal_status.winner)
 return [(a,ch,make_checked(nr,np,mapped[a])) for a,ch in pairs]
try:
 for original in raw['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));nr=compile_native_semantic_rules(c);s=initial_state(c)
  for target in original['route']:
   a,=[a for a in legal_actions(s,c) if record_value(a)==target];s=apply_action(s,a,c)
  m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True);pairs=verify(s,m.position,c,nr);drops=[x for x in pairs if getattr(x[0],'base_type_id',None)==original['target']];assert drops;case=dict(target=original['target'],pawn_drop_mate_filter=original['pawn_drop_mate_filter'],drops=[],complete=False);r['cases'].append(case);U=F(0);prob={name:F(0) for name in ('win','loss','draw','ongoing')};transitions=len(pairs)
  def outcome(st):return 'ongoing' if not st.terminal_status.is_terminal else 'draw' if st.terminal_status.winner is None else 'win' if st.terminal_status.winner==0 else 'loss'
  for a,ch,np in drops:
   assert time.perf_counter()-start<30,'goal-service cost checkpoint';row=dict(drop=record_value(a),immediate_terminal=record_value(ch.terminal_status),replies=[]);case['drops'].append(row)
   if ch.terminal_status.is_terminal:prob[outcome(ch)]+=F(1,len(drops));continue
   replies=verify(ch,np,c,nr);transitions+=len(replies);assert replies
   for reply,after,npa in replies:
    acts=verify(after,npa,c,nr);transitions+=len(acts);idx=a.to_square.file+9*a.to_square.rank;piece=after.position.board[idx];tag=[idx] if piece is not None and piece.owner==0 and piece.base_type_id==original['target'] else []
    val=len({(x.to_square.file,x.to_square.rank) for x,_,_ in acts if tag and hasattr(x,'from_square') and x.from_square.file+9*x.from_square.rank==tag[0]}) if not after.terminal_status.is_terminal else 0
    weight=F(1,len(drops)*len(replies));U+=weight*val;prob[outcome(after)]+=weight;row['replies'].append(dict(action=record_value(reply),U=val,terminal=record_value(after.terminal_status)))
  assert sum(prob.values())==1;case.update(complete=True,legal_drops=len(drops),mean_U=str(U),terminal_probabilities={k:str(v) for k,v in prob.items()},transitions=transitions);write_record(out,r);print(case['target'],case['pawn_drop_mate_filter'],len(drops),str(U),case['terminal_probabilities'],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
