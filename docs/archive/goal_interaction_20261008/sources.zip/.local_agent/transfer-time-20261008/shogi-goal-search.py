"""The actual public player already prioritizes legal terminal wins."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'shogi-goal.json';raw=json.loads(src.read_bytes());assert raw['complete'];out=p/'shogi-goal-search.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='Scope guard before any product utility patch: exact same3actual capture/reply roots and frozen complete legal winning sets. Existing defaultgeneric-v1 evaluator, one-ply512nodes/5sec/q0/root-tacticaloff. Python legality versus existing public Nativeflag,2freshTT repeats. If complete and legal wins exist, selected action must belong to frozen winning set. OriginalP hasnone; report no invented correct nonwinning action. Endpoint-only finite mean is NOT the existing player evaluation/terminal policy. This check decides whether any terminal-priority product fix is actually needed, not strength or new price selection. One30sec checkpoint.',cases=[]);write_record(out,r)
for original in raw['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));s=GameSession(c)
 for target in original['route']:
  a,=[a for a in s.legal_actions() if record_value(a)==target];s.submit(a)
 case=dict(target=original['target'],pawn_drop_mate_filter=original['pawn_drop_mate_filter'],known_winning_actions=original['winning_actions'],searches=[]);r['cases'].append(case)
 for native in (False,True):
  signatures=[]
  for repeat in range(2):
   assert time.perf_counter()-start<30
   player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=native,tt_max_entries=512,tuning=SearchTuning(use_root_tactical=False));before=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=512,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);complete=d.completed_depth==1;win=record_value(d.action) in original['winning_actions'];assert not(complete and original['winning_actions'] and not win);signatures.append((record_value(d.action),d.score,d.completed_depth));case['searches'].append(dict(native_requested=native,native_provider=player.native_legality_provider is not None,repeat=repeat,complete=complete,selected_known_win=win,seconds=time.perf_counter()-before,decision=record_value(d)))
  assert signatures[0]==signatures[1]
 write_record(out,r);print(case['target'],case['pawn_drop_mate_filter'],[(x['native_requested'],x['complete'],x['selected_known_win'],x['decision']['score']) for x in case['searches']],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
