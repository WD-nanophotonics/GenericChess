"""Four-cell paired interactions and witnesses on the frozen population."""
import json,hashlib,statistics,math
from pathlib import Path
from collections import Counter
p=Path(__file__).parent;src=p/'coalition-qualified.json';out=p/'coalition-analysis.json';assert not out.exists();raw=json.loads(src.read_bytes());assert raw['complete']
def stats(xs):
 se=statistics.stdev(xs)/math.sqrt(len(xs));m=statistics.mean(xs);return dict(n=len(xs),mean=m,standard_error=se,normal_approx_95=[m-1.96*se,m+1.96*se])
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),scope='Interaction is paired mAH-mIH-mAI+mII for existence of a legal immediate win. Conditional population and virtual immobile interventions; descriptive goal mechanism, not material prices or causal decomposition of long games. Approximate normal intervals are development diagnostics only, especially sparse counts. No population/weights chosen from results.',rows=[])
for ht in ('B','N'):
 for t in ('Q','R','B','N'):
  cases={cell:next(c for c in raw['cases'] if c['helper']==ht and c['type']==(t if cell[0]=='A' else 'I') and c['cell']==cell) for cell in ('AH','IH','AI','II')};records=[]
  for k in range(512):
   rows={cell:c['roots'][k] for cell,c in cases.items()};indices={v['index'] for v in rows.values()};assert len(indices)==1;index=indices.pop();ms={cell:int(bool(v['wins'])) for cell,v in rows.items()};d=ms['AH']-ms['IH']-ms['AI']+ms['II'];records.append(dict(index=index,cells=ms,interaction=d))
  pos=[x for x in records if x['interaction']>0];neg=[x for x in records if x['interaction']<0]
  witnesses=[]
  for label,selected in (('positive',pos[:3]),('negative',neg[:3])):
   for row in selected:witnesses.append(dict(kind=label,context=raw['contexts'][row['index']],**row,winning_actions={cell:next(x for x in c['roots'] if x['index']==row['index'])['wins'] for cell,c in cases.items()}))
  r['rows'].append(dict(helper=ht,actor=t,cell_mate_counts={cell:c['mate_roots'] for cell,c in cases.items()},interaction=stats([x['interaction'] for x in records]),interaction_counts=dict(Counter(x['interaction'] for x in records)),marginal_with_helper=stats([x['cells']['AH']-x['cells']['IH'] for x in records]),marginal_with_immobile=stats([x['cells']['AI']-x['cells']['II'] for x in records]),witnesses=witnesses))
out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
for x in r['rows']:print(x['helper'],x['actor'],x['cell_mate_counts'],x['interaction_counts'],x['interaction'])
