"""New same-policy searches versus immutable pre-reuse searches."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.unfamiliar_search import _compare_searches
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'deeper-search.json';raw=json.loads(src.read_bytes());population=json.loads((p/'population.json').read_bytes());out=p/'evaluation-search.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='Before-run matched search control after same-call attack-map reuse. SAME6actual-history roots, generic-v1default profile,4ply/4096nodes/5sec/q0, plain/publicbundle2freshTT repeats. Reuse immutable pre-change baseline; require exact score, action, completed-depth and node equality percondition/repeat. Timing local, capped depth remains unknown; no largerbudget or evaluation/ordering-policy change. One120sec checkpoint, no automatic extension.',cells=[]);write_record(out,r)
try:
 for oc in raw['cells']:
  assert time.perf_counter()-start<120
  definition=next(x['definition'] for x in population['rows'] if x['size']==oc['size'] and x['seed']==oc['seed']);c=compile_ruleset_for_execution(definition);s=GameSession(c)
  for target in oc['route']:
   a,=[a for a in s.legal_actions() if record_value(a)==target];s.submit(a)
  cfg=EvaluationConfig();cache=EvaluationProfileCache(use_disk=False);ev=Evaluator(c,cache.get_or_build(c,cfg)[0],cfg);case=dict(size=oc['size'],seed=oc['seed'],searches=[]);r['cells'].append(case)
  _compare_searches(s,ev,cache,oc['reference'],4,case,lambda:write_record(out,r))
  for before,after in zip(oc['searches'],case['searches']):
   assert (before['control'],before['repeat'])==(after['control'],after['repeat'])
   for field in ('action','score','nodes','completed_depth'):assert before['decision'][field]==after['decision'][field],(oc['size'],oc['seed'],field)
  write_record(out,r);print(oc['size'],oc['seed'],'parity',[(x['control'],round(x['observed_search_seconds'],3)) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
