"""Fixed rollout and equal-resource deeper generated-rule control."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,_compare_searches
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'population.json';raw=json.loads(src.read_bytes());assert raw['complete'];out=p/'deeper-search.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='Six already frozen accepted roots. BEFORE evaluation advance each by up to4 actual plies, selecting sorted(str(action)) index(size+seed+ply) modulo legal-count, no evaluated rollout choices. Terminal route remains recorded, not replaced. Existing fixedgeneric-v1/full default features, same-root evaluator bothcontrols. Targetdepth4,4096nodes/5sec/q0, root-tacticaloff,2 fresh-TT repeats eachPythonplain/publicbundle; independentCore4096leaves/5sec. Same existing comparison entry. Incomplete depth4 or reference unknown, never compare shallower scores as depth4; do not enlarge frozen ceilings. One180sec batch checkpoint, declared route and failures retained; completion allows cost localization, not strength or universal acceleration.',cells=[]);write_record(out,r)
try:
 for key in raw['selected']:
  assert time.perf_counter()-start<180,'deeper batch cost checkpoint'
  row=next(x for x in raw['rows'] if x['size']==key['size'] and x['seed']==key['seed']);c=compile_ruleset_for_execution(row['definition']);s=GameSession(c);cache=EvaluationProfileCache(use_disk=False);cfg=EvaluationConfig();profile=cache.get_or_build(c,cfg)[0];ev=Evaluator(c,profile,cfg);case=dict(**key,route=[],searches=[],complete=False);r['cells'].append(case)
  for ply in range(4):
   if s.state.terminal_status.is_terminal:break
   actions=sorted(s.legal_actions(),key=str);assert actions;a=actions[(key['size']+key['seed']+ply)%len(actions)];case['route'].append(record_value(a));s.submit(a)
  case['root_terminal']=record_value(s.state.terminal_status);case['root_legal']=len(s.legal_actions());write_record(out,r)
  if s.state.terminal_status.is_terminal:case['complete']=True;continue
  counted=CountedEvaluator(ev);before=time.perf_counter()
  try:
   score,action=reference_minimax(s.state,4,counted,c);ref=dict(complete=True,score=score,action=record_value(action))
  except ReferenceLimit:ref=dict(complete=False,score=None,action=None)
  ref.update(leaf_evaluations=counted.calls,wall_seconds=time.perf_counter()-before);case['reference']=ref
  _compare_searches(s,ev,cache,ref,4,case,lambda:write_record(out,r));case['complete']=True;write_record(out,r);print(key,'ref',ref['complete'],'search',[(x['control'],x['decision']['completed_depth'],x['decision']['nodes']) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
