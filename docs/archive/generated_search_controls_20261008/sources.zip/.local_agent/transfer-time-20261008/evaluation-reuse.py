"""Same-position map reuse; matched evaluator values before search comparison."""
import sys,json,time,hashlib,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import generic_chess.ai.evaluation.evaluator as module
import generic_chess.core.attacks as attacks
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import legal_successors
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'evaluation-reuse.json';assert not out.exists();raw=json.loads((p/'population.json').read_bytes());routes=json.loads((p/'deeper-search.json').read_bytes());old=types.ModuleType('generic_chess.ai.evaluation.old_control');old.__package__='generic_chess.ai.evaluation';exec(compile((p/'evaluator-before.py').read_bytes(),str(p/'evaluator-before.py'),'exec'),old.__dict__)
start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),before_sha256=hashlib.sha256((p/'evaluator-before.py').read_bytes()).hexdigest(),after_sha256=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),declaration='Prospective before changing product: avoid repeated identical pseudo-attack computation within ONE evaluation, no persistent cache or semantic repair. Six already declared4ply generated roots and all immediate children, bothturns via actual history. Configurations full, mobility-only, anchor-only, zero-dynamic. Fixed profiles and evaluator policy, all old/new scores exactly equal required. Count ALL core/direct pseudo-attacks and3passes time per config/root. No speed extrapolation; source snapshots retained. Sameposition maps only; no moved-anchor or semantic-attack substitution.',cells=[]);write_record(out,r)
original=attacks.pseudo_attacks
try:
 for row in routes['cells']:
  definition=next(x['definition'] for x in raw['rows'] if x['size']==row['size'] and x['seed']==row['seed']);c=compile_ruleset_for_execution(definition);s=GameSession(c)
  for a in row['route']:
   selected,=[x for x in s.legal_actions() if record_value(x)==a];s.submit(selected)
  states=[s.state]+[ch for a,ch in legal_successors(s.state,c)]
  for label,cfg in [('full',EvaluationConfig()),('mobility',EvaluationConfig(anchor_escape_weight=0)),('anchor',EvaluationConfig(dynamic_mobility_weight=0)),('zero',EvaluationConfig(anchor_escape_weight=0,dynamic_mobility_weight=0))]:
   profile=build_ruleset_profile(c,cfg);results=[]
   for name,cls in [('before',old.Evaluator),('after',module.Evaluator)]:
    calls=[0]
    def counted(*args,**kwargs):calls[0]+=1;return original(*args,**kwargs)
    attacks.pseudo_attacks=counted;old.pseudo_attacks=counted;module.pseudo_attacks=counted;ev=cls(c,profile,cfg);before=time.perf_counter();values=[ev.evaluate(st) for repeat in range(3) for st in states];elapsed=time.perf_counter()-before;results.append(dict(version=name,attack_maps=calls[0],seconds=elapsed,values=values))
   assert results[0]['values']==results[1]['values'];r['cells'].append(dict(size=row['size'],seed=row['seed'],config=label,states=len(states),results=results));write_record(out,r)
 r['complete']=True
finally:
 attacks.pseudo_attacks=original;module.pseudo_attacks=original;r['seconds']=time.perf_counter()-start;write_record(out,r)
print('cells',len(r['cells']),'attackmaps',[(x['config'],x['results'][0]['attack_maps'],x['results'][1]['attack_maps']) for x in r['cells']])
