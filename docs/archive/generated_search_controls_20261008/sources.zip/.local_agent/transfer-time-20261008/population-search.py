"""Existing search entry on six preselected nontrivial openings."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.unfamiliar_search import run_rule
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'population.json';raw=json.loads(src.read_bytes());assert raw['complete'];out=p/'population-search.json';assert not out.exists()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='Six roots selected in population declaration before evaluation. Existing run_rule depth2, generic-v1 evaluator unchanged, Python plain versus public bundle each2 fresh-TT repeats,4096nodes/5sec/q0; separate Core minimax4096leaves/5sec. Capped cells unknown. No speed/strength/ranking claim; first3 accepted seeds per board size is a deliberately biased exposed diagnostic population.',cells=[]);write_record(out,r)
for key in raw['selected']:
 row=next(x for x in raw['rows'] if x['size']==key['size'] and x['seed']==key['seed']);dest=p/('search-%s-%s.json'%(key['size'],key['seed']))
 report=run_rule(dest,row['definition'],depth=2)
 r['cells'].append(dict(**key,file=dest.name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),reference_complete=report['reference']['complete'],repeat_equal=report['repeat_equal'],searches=[dict(control=x['control'],complete=x['complete'],reference_equal=x['reference_score_equal'],nodes=x['decision']['nodes'],score=x['decision']['score'],seconds=x['observed_search_seconds']) for x in report['searches']]))
 write_record(out,r);print(key,r['cells'][-1],flush=True)
r['complete']=True;write_record(out,r)
