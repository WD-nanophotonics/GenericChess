"""Opaque IDs, full actual history, and declared tie/PV contracts."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution,compile_semantic_ir
from generic_chess.core.transition import initial_state,apply_action,legal_successors
from generic_chess.core.movegen import legal_actions
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=ROOT/'.local_agent/paired-context-20261008/combined-qualified.json';raw=json.loads(src.read_bytes());assert raw['complete'];out=p/'alias-search.json';assert not out.exists();start=time.perf_counter()
mapping={'K':'opaque_z9','R':'opaque_a1','TP':'opaque_m5'};reverse={v:k for k,v in mapping.items()}
def rename(value,mp):
 if isinstance(value,str):return mp.get(value,value)
 if isinstance(value,list):return [rename(x,mp) for x in value]
 if isinstance(value,dict):return {mp.get(k,k):rename(v,mp) for k,v in value.items()}
 return value
base=compile_ruleset_for_execution(ruleset_from_dict(raw['definition']));alias=compile_ruleset_for_execution(ruleset_from_dict(rename(raw['definition'],mapping)))
def pname(name):
 for new,old in reverse.items():name=name.replace('legacy_'+new+'_','legacy_'+old+'_')
 return name
def pkey(pattern,mp):return pname(pattern.name),tuple(sorted(mp.get(t,t) for t in pattern.type_ids))
ids={}
for oi,ni in ((base.ir,alias.ir),(compile_semantic_ir(base._legacy_compiled),compile_semantic_ir(alias._legacy_compiled))):
 old={pkey(x,{}):x for x in oi.patterns};assert len(old)==len(oi.patterns)
 for pattern in ni.patterns:
  original=old[pkey(pattern,reverse)];ids[pattern.pattern_id]=original.pattern_id
  assert len(pattern.geometry_ids)==len(original.geometry_ids)
  for ng,og in zip(pattern.geometry_ids,original.geometry_ids):
   new=rename(record_value(ni.geometry[ng]),reverse);oldg=record_value(oi.geometry[og]);new.pop('geometry_id');oldg.pop('geometry_id');assert new==oldg
   assert ids.get(ng,og)==og;ids[ng]=og
def norm(action):return rename(rename(record_value(action),reverse),ids)
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
compiled=[base,alias];profiles=[build_ruleset_profile(c,cfg) for c in compiled];assert dict(profiles[0].board_value_by_type)==rename(dict(profiles[1].board_value_by_type),reverse)
evs=[Evaluator(c,profile,cfg) for c,profile in zip(compiled,profiles)]
def make(i,full):return AlphaBetaPlayer(compiled[i],evaluation_config=cfg,use_disk_cache=False,evaluator_override=evs[i],tt_max_entries=8192,tuning=SearchTuning(use_root_tactical=False,require_full_pv=full))
sessions=[GameSession(c) for c in compiled];reused={(i,full):make(i,full) for i in (0,1) for full in (False,True)}
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),mapping=mapping,definition=raw['definition'],declaration='Original actual8action recombined capture/promotion/transient-right/drop route, all9roots. Bijective opaque type rename changes lexical/compiler order. Fixed generic-v1 static-only evaluator tables must match. Full mapped legal sets and position components at every root. Depth2/8192nodes/10sec/q0/root-tactical-off, both default/full-PV contracts, fresh/reused/warm search. Reference allrootaction values at depth2 with8192leaf/10sec checkpoint per root. Score/optimality required, exact chosen action/PV equality merely observed: str(action) tie-breaking contains identifiers. Capped references/calls unknown. No speed or material-price claim.',rows=[]);write_record(out,r)
for ply in range(9):
 assert time.perf_counter()-start<180,'alias batch checkpoint'
 sets=[[record_value(x) if i==0 else norm(x) for x in legal_actions(s.state,compiled[i])] for i,s in enumerate(sessions)]
 key=lambda x:json.dumps(x,sort_keys=True)
 assert sorted(sets[0],key=key)==sorted(sets[1],key=key)
 for field in ('board','hands','side_to_move','aux_state'):
  assert record_value(getattr(sessions[0].state.position,field))==rename(record_value(getattr(sessions[1].state.position,field)),reverse)
 row=dict(ply=ply,legal_actions=len(sets[0]),calls=[],reference=[]);r['rows'].append(row)
 for i in (0,1):
  counted=CountedEvaluator(evs[i],seconds=10,evaluations=8192);values=[]
  try:
   for action,child in legal_successors(sessions[i].state,compiled[i]):
    score,_=reference_minimax(child,1,counted,compiled[i],ply=1);values.append(dict(action=record_value(action) if i==0 else norm(action),score=-score))
   reference=dict(complete=True,values=values,best=max(x['score'] for x in values))
  except ReferenceLimit:reference=dict(complete=False,values=[],best=None)
  reference['leaves']=counted.calls;row['reference'].append(reference)
  for full in (False,True):
   for label,player in (('fresh',make(i,full)),('reused',reused[i,full]),('warm',reused[i,full])):
    before=time.perf_counter();decision=player.choose_action(sessions[i],SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(sessions[i],decision)
    normalized=record_value(decision) if i==0 else rename(rename(record_value(decision),reverse),ids)
    complete=decision.completed_depth==2
    optimal=next(x['score'] for x in values if x['action']==normalized['action'])==reference['best'] if complete and reference['complete'] else None
    assert optimal is not False
    if complete and reference['complete']:assert decision.score==reference['best']
    if full and complete:assert len(decision.principal_variation)==2
    row['calls'].append(dict(alias=bool(i),full_pv=full,label=label,complete=complete,optimal=optimal,seconds=time.perf_counter()-before,decision=normalized))
 if all(x['complete'] for x in row['reference']):assert sorted(row['reference'][0]['values'],key=key)==sorted(row['reference'][1]['values'],key=key)
 write_record(out,r);print(ply,'legal',len(sets[0]),'refs',[x['complete'] for x in row['reference']],flush=True)
 if ply<8:
  for i in (0,1):
   action,=[a for a in legal_actions(sessions[i].state,compiled[i]) if (record_value(a) if i==0 else norm(a))==raw['route'][ply]];sessions[i].submit(action)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
