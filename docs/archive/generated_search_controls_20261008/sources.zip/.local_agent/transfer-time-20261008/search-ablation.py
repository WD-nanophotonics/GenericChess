"""Fill missing TT/order controls, reuse completed frozen endpoints."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'deeper-search.json';pop=p/'population.json';old=json.loads(src.read_bytes());population=json.loads(pop.read_bytes());assert old['complete'];out=p/'search-ablation.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in (src,pop)},declaration='Changed decision: localize generated-rule completed-depth benefit/cost to TT versus ordering, because actual native providers absent in ALL initial deeper calls. Reuse plain/both frozen endpoints; add TT-only and order-only on exact6four-ply-history roots. Same4096nodes/5sec/depth4/q0/root-tacticaloff, samegeneric-v1default profile,2freshTT repeats. No ceiling expansion; fullPV not required. Completed equal-depth scores must agree when both complete; different-depth scores are not parity failures. One120sec checkpoint. No native acceleration or player-strength claim; profile code only if new ablation identifies a concrete cost decision.',cells=[]);write_record(out,r)
try:
 for oc in old['cells']:
  definition=next(x['definition'] for x in population['rows'] if x['size']==oc['size'] and x['seed']==oc['seed']);c=compile_ruleset_for_execution(definition);s=GameSession(c)
  for target in oc['route']:
   a,=[a for a in s.legal_actions() if record_value(a)==target];s.submit(a)
  cfg=EvaluationConfig();cache=EvaluationProfileCache(use_disk=False);ev=Evaluator(c,cache.get_or_build(c,cfg)[0],cfg);case=dict(size=oc['size'],seed=oc['seed'],searches=[],repeat_equal={});r['cells'].append(case)
  if s.state.terminal_status.is_terminal:case['terminal']=True;continue
  for label,tt,ordering in (('tt_only',True,False),('order_only',False,True)):
   signatures=[]
   for repeat in range(2):
    assert time.perf_counter()-start<120,'ablation cost checkpoint'
    player=AlphaBetaPlayer(c,evaluation_config=cfg,profile_cache=cache,use_disk_cache=False,use_tt=tt,use_ordering=ordering,use_native_semantic_legality=False,evaluator_override=ev,tt_max_entries=4096,tuning=SearchTuning(use_root_tactical=False));before=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);signatures.append((record_value(d.action),d.score,d.completed_depth));case['searches'].append(dict(control=label,repeat=repeat,complete=d.completed_depth==4,observed_seconds=time.perf_counter()-before,decision=record_value(d)))
   case['repeat_equal'][label]=signatures[0]==signatures[1]
  complete_scores={x['decision']['score'] for x in oc['searches']+case['searches'] if x['complete']};assert len(complete_scores)<=1
  write_record(out,r);print(case['size'],case['seed'],[(x['control'],x['decision']['completed_depth'],x['decision']['nodes']) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
