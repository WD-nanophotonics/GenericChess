"""Declared generator population; filter before any evaluation/search."""
import sys,time,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.generation.generator import generate_game
from generic_chess.core.transition import initial_state,legal_successors
from generic_chess.rules.schema import ruleset_to_dict
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'population.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Before any evaluation: seeds0..11 each board4/6, bilateral_random, hybridTrue, generator100attempt ceiling. Existing generator filters retained. Additional diagnostic population excludes initial terminal/zero moves or ANY legal first action yielding a terminal win for mover. Enumerate all first actions, preserve exclusions and exact definitions. Select first3 accepted seeds per size in numeric order for fixed-depth2 existing search, not selected by values. No claim good games, balanced rules or representative all-rule distribution. Per-process120sec checkpoint; generation exhaustion is a recorded exclusion, other exceptions propagate.',rows=[],selected=[])
write_record(out,r)
for size in (4,6):
 selected=0
 for seed in range(12):
  assert time.perf_counter()-start<120,'population checkpoint'
  cfg=GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=100)
  before=time.perf_counter();row=dict(size=size,seed=seed);r['rows'].append(row)
  try:game=generate_game(cfg)
  except GenerationError as e:
   row.update(accepted=False,reason='generator_exhaustion',error=str(e),seconds=time.perf_counter()-before);write_record(out,r);continue
  state=initial_state(game.compiled_ruleset);pairs=legal_successors(state,game.compiled_ruleset)
  wins=[record_value(a) for a,ch in pairs if ch.terminal_status.is_terminal and ch.terminal_status.winner==state.position.side_to_move]
  reason='initial_terminal' if state.terminal_status.is_terminal else 'no_legal_action' if not pairs else 'immediate_winning_action' if wins else 'accepted'
  row.update(definition=ruleset_to_dict(game.ruleset),fingerprint=game.compiled_ruleset.ruleset_fingerprint,generator_report=record_value(game.generation_report),opening_actions=len(pairs),terminal=record_value(state.terminal_status),immediate_wins=wins,accepted=reason=='accepted',reason=reason,seconds=time.perf_counter()-before)
  if row['accepted'] and selected<3:r['selected'].append(dict(size=size,seed=seed));selected+=1
  write_record(out,r);print(size,seed,reason,len(pairs),len(wins),flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
