"""Differential full-feature evaluation on actual semantic histories."""
import sys,json,hashlib,types,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'evaluation-semantic.json';assert not out.exists();start=time.perf_counter();old=types.ModuleType('generic_chess.ai.evaluation.old_control');old.__package__='generic_chess.ai.evaluation';exec(compile((p/'evaluator-before.py').read_bytes(),str(p/'evaluator-before.py'),'exec'),old.__dict__)
combined_path=ROOT/'.local_agent/paired-context-20261008/combined-qualified.json';combined=json.loads(combined_path.read_bytes());shogi=json.loads((p/'shogi-goal.json').read_bytes());r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies={str(x.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(x.read_bytes()).hexdigest() for x in (combined_path,p/'shogi-goal.json',p/'evaluator-before.py',ROOT/'generic_chess/ai/evaluation/evaluator.py')},declaration='Prospective broader product qualification after map reuse: full default and mobility-only/anchor-only/zero-dynamic configurations on ALL9executed combined capture/promotion/right/drop roots, each of3actualShogi capture/reply routes (3roots each), and canonicalWestern initial plus8fixed lexical-index actual plies. Preserve unchanged semantic-legacy evaluation limitations; no attack/progression repair or human fit. Exact before/after values required, histories/aux/hands are real. No speed claim for tiny cells, no new persistent cache, one30sec checkpoint.',cases=[]);write_record(out,r)
definitions=[('combined',ruleset_from_dict(combined['definition']),combined['route'])]+[('shogi-%s-%s'%(x['target'],x['pawn_drop_mate_filter']),ruleset_from_dict(x['definition']),x['route']) for x in shogi['cases']]+[('western',build_western_chess_ruleset(),None)]
for name,definition,route in definitions:
 c=compile_ruleset_for_execution(definition);s=GameSession(c);configs=[('full',EvaluationConfig()),('mobility',EvaluationConfig(anchor_escape_weight=0)),('anchor',EvaluationConfig(dynamic_mobility_weight=0)),('zero',EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0))];evaluators=[]
 for label,cfg in configs:
  profile=build_ruleset_profile(c,cfg);evaluators.append((label,old.Evaluator(c,profile,cfg),Evaluator(c,profile,cfg)))
 case=dict(name=name,roots=[]);r['cases'].append(case)
 for ply in range((len(route) if route is not None else 8)+1):
  assert time.perf_counter()-start<30
  row=dict(ply=ply,side=s.state.position.side_to_move,hands=record_value(s.state.position.hands),aux_state=record_value(s.state.position.aux_state),scores={});case['roots'].append(row)
  for label,before,after in evaluators:
   a=before.evaluate(s.state);b=after.evaluate(s.state);assert a==b,(name,ply,label,a,b);row['scores'][label]=a
  if (route is not None and ply==len(route)) or (route is None and ply==8) or s.state.terminal_status.is_terminal:break
  actions=s.legal_actions()
  if route is None:a=sorted(actions,key=str)[(ply+2)%len(actions)]
  else:a,=[a for a in actions if record_value(a)==route[ply]]
  row['next_action']=record_value(a);s.submit(a)
 write_record(out,r)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print('roots',sum(len(c['roots']) for c in r['cases']),'exact value pairs',4*sum(len(c['roots']) for c in r['cases']))
