"""Existing Core minimal-q0 versus C iterative-q0 system paths; not pure executor ratio."""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from types import SimpleNamespace
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.rules.schema import ruleset_from_dict
from scripts.native_core_availability import NativeCoreAvailability
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.full_q_refresh_comparison import runtime_state
from scripts.research_record import record_value,write_record
from scripts.search_backend_comparison import Work,Exhausted
from time import perf_counter
import hashlib
from dataclasses import asdict
from generic_chess.ai.evaluation.config import MATE_SCORE
def matched_ab(board, depth, *, seconds=30, node_limit=100000, trace=False, cooperative=False):
    """Identical algorithm and lexicographic actions across backend adapters.

    Nodes count all recursive entries including root and terminal leaves;
    pushes count successful child transitions. Time is checked before each node.
    Completed earlier root children survive a budget exception; no fake D-depth.
    """
    work, digest = Work(), hashlib.sha256()
    runtime_fields = ('pushes', 'pops', 'legal_provider_calls', 'legal_provider_actions',
                      'legal_provider_seconds', 'legal_provider_payload_seconds',
                      'legal_provider_decode_binding_seconds', 'legal_provider_fallbacks',
                      'legal_provider_operational_failures', 'child_external_key_computations',
                      'history_reconstruction_attempts', 'opaque_history_child_external_key_computations')
    runtime = getattr(board, 'runtime', None)
    before = {name: getattr(runtime, name, 0) for name in runtime_fields} if runtime else {}
    start = perf_counter()
    def deadline_checkpoint():
        if perf_counter()-start >= seconds:
            raise Exhausted
    if hasattr(board, 'checkpoint'):
        board.checkpoint = deadline_checkpoint if cooperative else None
    best_move, best_score = None, -MATE_SCORE*2

    def visit(left, alpha, beta, ply, pv_node):
        nonlocal best_move, best_score
        if work.nodes >= node_limit or perf_counter()-start >= seconds:
            raise Exhausted
        work.nodes += 1
        work.terminal_queries += 1
        terminal = board.terminal(ply)
        if terminal is not None or left == 0:
            work.leaves += 1
            value = terminal if terminal is not None else board.evaluate()
            if trace:
                digest.update(f'L:{ply}:{value};'.encode())
            return value
        work.legal_queries += 1
        actions = board.actions()
        if trace:
            digest.update(('A:' + ','.join(label for label, _ in actions) + ';').encode())
        value = -MATE_SCORE*2
        for index, (label, action) in enumerate(actions):
            board.push(action)
            work.pushes += 1
            try:
                child_alpha,child_beta = (-1000000000,1000000000) if pv_node or ply==0 else (-beta,-alpha)
                score = -visit(left-1, child_alpha, child_beta, ply+1, True if ply==0 else pv_node and index==0)
            finally:
                board.pop()
            if trace:
                digest.update(f'V:{ply}:{label}:{score};'.encode())
            if ply == 0:
                work.root_completed += 1
                if best_move is None or score > best_score or (score==best_score and label<best_move):
                    best_move, best_score = label, score
            value = max(value, score)
            alpha = max(alpha, value)
            if alpha >= beta:
                work.cutoffs += 1
                break
        return value

    try:
        score = visit(depth, -1000000000, 1000000000, 0, True)
        reason = 'completed_depth'
    except Exhausted:
        score, reason = (best_score if best_move is not None else None), 'budget'
    finally:
        if hasattr(board, 'checkpoint'):
            board.checkpoint = None
    if not board.restored():
        raise AssertionError('search failed to restore root')
    return dict(move=best_move, score=score, reason=reason, wall_seconds=perf_counter()-start,
                completed_depth=depth if reason == 'completed_depth' else 0,
                work=asdict(work), trace_sha256=digest.hexdigest() if trace else None,
                runtime_counters={name: getattr(runtime, name, 0)-value for name, value in before.items()},
                native_provider_active=None if runtime is None else runtime._legal_provider_active)

B=Path(sys.argv[1]);B.mkdir(parents=True,exist_ok=True);assert not (B/'declaration.json').exists()
write_record(B/'declaration.json',dict(question='Can adapting the existing minimalAB windows/order to the existing C path produce actual matched D1+D2 work without modifying C?',cases=['chess-ep','shogi-promotion','1090','1091'],depth=2,calls=16,q=0,tt=0,ordering='Both existing Native candidate order and minimum packed root tie; Core private source-derived full PV/root window scheduling, TT0, D1+D2',terminal_scale='Core adapter matches C iterative100000000-ply; originalCore1e9 preserved separately',bounds='Core100000nodes/60s; C100000nodes/60s/maxD2; normal concurrent load, eachbatchunder1h',decision='Require actual iterative Node/push counts and score/canonical action. Native Core legal queries still eagerly validate entire frontier; C checks as traversed and performs fallback/terminal work. Even matched tree count is not pure language cost or q4 prediction.',source='Pinned6862c0bd existing search entries; no new C kernel or engine changes'))
class Board:
 def __init__(self,c,s,values):
  self.compiled=c;self.values=values;self.provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert self.provider is not None
  self.availability=NativeCoreAvailability(c)
  self.runtime=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=self.provider,availability_provider=self.availability.for_position)
  self.saved=runtime_state(self.runtime);self.checkpoint=None
 def actions(self):return [(f'{pack_semantic_action(self.provider.native_rules,self.runtime.position,a):016x}',a) for a in self.runtime.legal_actions(checkpoint=self.checkpoint)]
 def push(self,a):self.runtime.push(a,checkpoint=self.checkpoint)
 def pop(self):self.runtime.pop()
 def evaluate(self):
  p=self.runtime.position;side=p.side_to_move
  return sum((1 if x.owner==side else -1)*self.values[x.current_type_id] for x in p.board if x)+sum((1 if owner==side else -1)*self.values[tid]*n for owner,h in enumerate(p.hands) for tid,n in h.items())
 def terminal(self,ply):
  t=self.runtime.terminal_status
  if not t.is_terminal:return None
  return 0 if t.winner is None else (100000000-ply if t.winner==self.runtime.position.side_to_move else -100000000+ply)
 def restored(self):return runtime_state(self.runtime)==self.saved
rows=[]
for key in ['chess-ep','shogi-promotion','1090','1091']:
 if key.isdigit():
  samples=json.loads(Path('.local_agent/aux-quiet-20261012/'+('active-mixed-premise.json' if key=='1091' else 'mixed-premise.json')).read_text());sample=next(x for x in samples if str(x['seed'])==key);c=compile_ruleset_for_execution(ruleset_from_dict(sample['rules']));s=GameSession(c)
  for _ in range(4):
   aa=s.legal_actions();aux=[a for a in aa if 'promotion_grants_one_turn_right' in a.pattern_id];s.submit(aux[0] if aux else sorted(aa,key=repr)[0])
 else:
  case=next(x for x in CASES if x['id']==key);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));core=CoreBoard(case,c);s=SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses)
 provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None
 values={tid:100*(i+1) for i,tid in enumerate(provider.native_rules.type_ids)}
 native=provider.native_rules;pos=pack_semantic_search_position(c,native,s);before=ns.snapshot(native,pos)
 board=Board(c,s,values);root_terminal=ns.terminal_status(native,pos);assert root_terminal['status']==board.runtime.terminal_status.status.value and root_terminal['winner']==board.runtime.terminal_status.winner
 write_record(B/(key+'-sample.json'),dict(state=record_value(s.state),witnesses=record_value(s._search_witnesses),values=values,root_native_snapshot=before))
 for order in range(2):
  for mode in (['core','native'] if order==0 else ['native','core']):
   started=time.perf_counter()
   if mode=='core':
    board=Board(c,s,values);result1=matched_ab(board,1,seconds=60,node_limit=100000,cooperative=True);result=matched_ab(board,2,seconds=60,node_limit=100000,cooperative=True);result['iterative_nodes']=result1['work']['nodes']+result['work']['nodes'];result['iterative_pushes']=result1['work']['pushes']+result['work']['pushes']
    assert board.restored();board.runtime.assert_balanced();actual=dict(result,provider=board.runtime._legal_provider_active,availability=dict(calls=board.availability.calls,fallbacks=board.availability.fallbacks))
   else:
    result=ns.semantic_iterative_search(native,pos,2,max_nodes=100000,max_time_seconds=60,board_values=values,hand_values=values,tt_megabytes=0);assert ns.snapshot(native,pos)==before
    actual=result
   rows.append(dict(case=key,order=order,mode=mode,seconds=time.perf_counter()-started,result=record_value(actual),root_restored=True));write_record(B/'result.json',dict(complete=False,rows=rows));print(key,order,mode,round(rows[-1]['seconds'],4),actual.get('score'),actual.get('nodes',actual.get('work',{}).get('nodes')),flush=True)
write_record(B/'result.json',dict(complete=True,rows=rows))
