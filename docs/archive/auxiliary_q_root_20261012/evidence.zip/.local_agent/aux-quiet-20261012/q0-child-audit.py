from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
from pathlib import Path
import sys, json, time
from types import SimpleNamespace
from generic_chess import build_builtin_ruleset, compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.rules.schema import ruleset_from_dict
from scripts.native_core_availability import NativeCoreAvailability
from scripts.search_backend_comparison import CASES, CoreBoard, minimal_ab
from scripts.full_q_refresh_comparison import runtime_state
from scripts.research_record import record_value, write_record
class Board:

    def __init__(self, c, s, values):
        self.compiled = c
        self.values = values
        self.provider = NativeSemanticLegalityProvider.try_create(c, strict=True)
        assert self.provider is not None
        self.availability = NativeCoreAvailability(c)
        self.runtime = SearchPathRuntime.from_state(s.state, c, history_witnesses=s._search_witnesses, legal_binding_provider=self.provider, availability_provider=self.availability.for_position)
        self.saved = runtime_state(self.runtime)
        self.checkpoint = None

    def actions(self):
        return sorted([(str(a), a) for a in self.runtime.legal_actions(checkpoint=self.checkpoint)])

    def push(self, a):
        self.runtime.push(a, checkpoint=self.checkpoint)

    def pop(self):
        self.runtime.pop()

    def evaluate(self):
        p = self.runtime.position
        side = p.side_to_move
        return sum(((1 if x.owner == side else -1) * self.values[x.current_type_id] for x in p.board if x)) + sum(((1 if owner == side else -1) * self.values[tid] * n for owner, h in enumerate(p.hands) for tid, n in h.items()))

    def terminal(self, ply):
        t = self.runtime.terminal_status
        if not t.is_terminal:
            return None
        return 0 if t.winner is None else 100000000 - ply if t.winner == self.runtime.position.side_to_move else -100000000 + ply

    def restored(self):
        return runtime_state(self.runtime) == self.saved
B=Path(sys.argv[1]);B.mkdir(parents=True,exist_ok=True)
for key in ['chess-ep','shogi-promotion','1090','1091']:
 if key.isdigit():
     samples = json.loads(Path('.local_agent/aux-quiet-20261012/' + ('active-mixed-premise.json' if key == '1091' else 'mixed-premise.json')).read_text())
     sample = next((x for x in samples if str(x['seed']) == key))
     c = compile_ruleset_for_execution(ruleset_from_dict(sample['rules']))
     s = GameSession(c)
     for _ in range(4):
         aa = s.legal_actions()
         aux = [a for a in aa if 'promotion_grants_one_turn_right' in a.pattern_id]
         s.submit(aux[0] if aux else sorted(aa, key=repr)[0])
 else:
     case = next((x for x in CASES if x['id'] == key))
     c = compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game'] == 'chess' else 'standard_shogi'))
     core = CoreBoard(case, c)
     s = SimpleNamespace(compiled=c, state=core.initial, _search_witnesses=core.witnesses)
 provider = NativeSemanticLegalityProvider.try_create(c, strict=True)
 assert provider is not None
 values = {tid: 100 * (i + 1) for i, tid in enumerate(provider.native_rules.type_ids)}
 native = provider.native_rules
 pos = pack_semantic_search_position(c, native, s)
 before = ns.snapshot(native, pos)
 board = Board(c, s, values)
 root_terminal = ns.terminal_status(native, pos)
 assert root_terminal['status'] == board.runtime.terminal_status.status.value and root_terminal['winner'] == board.runtime.terminal_status.winner
 write_record(B / (key + '-sample.json'), dict(state=record_value(s.state), witnesses=record_value(s._search_witnesses), values=values, root_native_snapshot=before))
 from generic_chess.core.transition import apply_action
 from generic_chess.ai.evaluation.config import MATE_SCORE
 rows=[]
 raw=ns.transient_legal_actions(native,pos)
 public=[ns.public_action(native,a) for a in raw]
 assert tuple(public)==tuple(board.runtime.legal_actions())
 for packed,a in zip(raw,public):
  child=ns.make_checked(native,pos,packed)
  state=apply_action(s.state,a,c)
  expected=pack_semantic_search_position(c,native,SimpleNamespace(compiled=c,state=state,_search_witnesses=(*s._search_witnesses,state.position)))
  assert ns.snapshot(native,child)==ns.snapshot(native,expected)
  with board.runtime.pushed(a):
   assert board.runtime.position==state.position
   score=board.evaluate();native_score=ns.evaluate(native,child,board_values=values,hand_values=values)
   assert score==native_score
   tt=ns.terminal_status(native,child);assert tt['status']==board.runtime.terminal_status.status.value and tt['winner']==board.runtime.terminal_status.winner
   rows.append(dict(action=record_value(a),packed=packed,material=score,terminal=tt,history_length=len(state.history),aux=record_value(state.position.aux_state)))
 assert board.restored();board.runtime.assert_balanced();assert ns.snapshot(native,pos)==before
 write_record(B/(key+'-children.json'),dict(complete=True,rows=rows,full_native_history_and_core_child_equal=True))
 print(key,len(rows),'full child/history/material/terminal exact',flush=True)
 
