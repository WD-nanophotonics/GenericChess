"""Actual Core-owned caller: semantic attack backend and legality attribution."""
import argparse, hashlib, json, random, sys, time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value, write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from scripts.native_core_availability import NativeCoreAvailability
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess.core import search_runtime as runtime_module
import inspect,textwrap
from generic_chess.ai.alphabeta import search as search_module
from scripts.quiet_drop_probe import QuietDropProbe
from scripts.quiet_action_probe import QuietActionProbe
from generic_chess.ai.alphabeta.tuning import SearchTuning

class CountedSemanticEvaluator(SemanticAttackEvaluator):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.score_calls=self.map_calls=0
    def evaluate(self,state):
        self.score_calls+=1;return super().evaluate(state)
    def _attack_maps(self,state):
        self.map_calls+=1;return super()._attack_maps(state)



from collections import Counter
from generic_chess.core.semantic_executor import _semantic_public_action
class LazyLegal:
    """Research-only full logical legal collection; no truncated legal cache."""
    def __init__(self,ctx,counters):
        self.runtime=ctx.runtime;self.position=self.runtime.position;self.ply=self.runtime.ply_count;self.provider=self.runtime._legal_binding_provider;self.checkpoint=ctx.checkpoint;self.counts=counters
        assert self.provider.supports_position(self.position,self.ply)
        self.native=ns.pack_position(self.provider.native_rules,self.provider._state_only_payload(self.position,self.ply))
        raw=ns.candidate_actions(self.provider.native_rules,self.native);self.counts['candidates']+=len(raw)
        self.rows=[];self.valid={};self.bindings={}
        cache=getattr(self.provider._metrics_local,'public_cache',None)
        if cache is None:cache={};self.provider._metrics_local.public_cache=cache
        for packed in raw:
            public=cache.get(packed)
            if public is None:
                public=ns.public_action(self.provider.native_rules,packed);self.counts['syntax_misses']+=1
                if len(cache)>=2048:cache.clear();self.counts['syntax_clears']+=1
                cache[packed]=public
            else:self.counts['syntax_hits']+=1
            self.rows.append((str(public),public,packed,None))
        self.rows.sort(key=lambda x:x[0]);assert len({x[1] for x in self.rows})==len(self.rows)
        self.by_public={x[1]:x for x in self.rows}
    def accept(self,row):
        _,public,packed,semantic=row
        if public in self.valid:return self.valid[public]
        self.checkpoint();self.counts['trials']+=1
        try:child=ns.make_checked(self.provider.native_rules,self.native,packed)
        except ValueError as exc:
            if str(exc)!='semantic action is not valid for the current position':raise
            self.valid[public]=False;self.counts['rejected']+=1;return False
        del child
        semantic=self.provider._decode_action(packed,self.position)
        assert _semantic_public_action(self.provider.engine,semantic)==public
        binding=self.provider.engine._make_binding_from_action(self.position,semantic,self.provider.pattern_by_id[semantic.pattern_id])
        self.bindings[public]=(semantic,binding);self.valid[public]=True;self.counts['accepted']+=1
        return True
    def __iter__(self):
        for row in self.rows:
            if self.accept(row):yield row[1]
    def __contains__(self,action):
        row=self.by_public.get(action)
        return row is not None and self.accept(row)
    def __bool__(self):return next(iter(self),None) is not None

class BatchLegal(LazyLegal):
    def __iter__(self):
        for start in range(0,len(self.rows),BATCH_SIZE):
            chunk=self.rows[start:start+BATCH_SIZE]
            pending=[row for row in chunk if row[1] not in self.valid]
            if pending:
                self.checkpoint();self.counts['chunk_calls']+=1;self.counts['trials']+=len(pending)
                accepted=set(ns.transient_legal_subset(self.provider.native_rules,self.native,tuple(row[2] for row in pending)))
                for _,public,packed,_ in pending:
                    valid=packed in accepted;self.valid[public]=valid
                    if not valid:self.counts['rejected']+=1;continue
                    semantic=self.provider._decode_action(packed,self.position)
                    assert _semantic_public_action(self.provider.engine,semantic)==public
                    binding=self.provider.engine._make_binding_from_action(self.position,semantic,self.provider.pattern_by_id[semantic.pattern_id])
                    self.bindings[public]=(semantic,binding);self.counts['accepted']+=1
            for row in chunk:
                if self.valid[row[1]]:yield row[1]

BATCH_SIZE=8
counts=Counter()
def legal(ctx,checkpoint):
    runtime=ctx.runtime
    if runtime._legal_cache is not None:return runtime._legal_cache
    provider=runtime._legal_binding_provider
    if provider is None or not runtime._legal_provider_active or ctx.compiled.support.pass_enabled or not provider.supports_position(runtime.position,runtime.ply_count):return search_module._runtime_legal_actions(ctx,checkpoint)
    counts['collections']+=1;ctx.stats.legal_generation_calls+=1
    collection=BatchLegal(ctx,counts);runtime._legal_cache=collection;runtime._bindings=collection.bindings
    return collection

def order(state,actions,ply,ctx):
    assert not ctx.tuning.use_ordered_qsearch
    return iter(actions) if isinstance(actions,LazyLegal) else sorted(actions,key=str)

def run(output,nodes=1000000,seconds=1,key="1006"):
    global counts,BATCH_SIZE
    b=Path(output);b.mkdir(parents=True,exist_ok=True);assert not (b/'declaration.json').exists()
    write_record(b/'declaration.json',dict(question='Does mechanical auxiliary recombination preserve exact D2/q4 and quiet-board caller savings?',calls=4,root=key,orders=['quiet_drop,quiet_all','quiet_all,quiet_drop'],max_depth=12,nodes=nodes,seconds=seconds,q=4,hardq=8,pvs=True,scope='Existing generated1089/1090 with mechanical temporary auxiliary recombination; full4ply witnesses; 1/16/64/256second delivery, maxD12/node1000000; same Native leaf/legality/availability, PVS and Core authority. no pass or ordered-q. Complete logical legality collection with exact Native per-candidate S3/S4, Core push/history/terminal/check/TT remain. Native checked child capsule is discarded; no second recursive runtime. Native per-action allocation/hash overhead retained. Existing bounded per-provider public syntax cache may be read before legality, but actual current-position decode/source checks and complete binding happen on every accepted candidate. No cached legality/child/history; Native exact checks precede accepted cache use. Research-only private runtime cache representation; not product interface or full domain.',decision='Actual returned action score depth/q/support and backend work per frozen budget.1090 chosen because feasibility delivers completeD2;1089 immediate-win-only preserved/excluded from cost comparison. Exposed development cohort, no old caps changed.',expected_cost=f'Maximum{seconds*4}seconds plus setup, under one hour',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
    from generic_chess.rules.schema import ruleset_from_dict
    samples=json.loads(Path('.local_agent/aux-quiet-20261012/mixed-premise.json').read_text(encoding='utf-8'))
    sample=next(x for x in samples if str(x['seed'])==key)
    c=compile_ruleset_for_execution(ruleset_from_dict(sample['rules']));s=p.GameSession(c);case=dict(id=key,seed=sample['seed'],recombined='existing auxiliary expiry with generated actor; promotion type change explicitly removed')
    for _ in range(4):
        aa=s.legal_actions();aux=[a for a in aa if 'promotion_grants_one_turn_right' in a.pattern_id];s.submit(aux[0] if aux else sorted(aa,key=repr)[0])
    assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
    ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
    write_record(b/'samples.json',dict(case=case,state=record_value(s.state),witnesses=record_value(s._search_witnesses)))
    original=search_module._quiescence_runtime;src=textwrap.dedent(inspect.getsource(original)).replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)')
    rows=[]
    try:
        for repeat in range(2):
            for mode in (['quiet_drop','quiet_all'] if repeat==0 else ['quiet_all','quiet_drop']):
                BATCH_SIZE=8
                counts=Counter();probe=(QuietDropProbe if mode=='quiet_drop' else QuietActionProbe)(shadow=False);active=src.replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n');namespace=dict(search_module.__dict__,lazy_legal=legal,lazy_order=order,quiet_drop_probe=probe);exec(compile(active,'<research-lazy-legal>','exec'),namespace);search_module._quiescence_runtime=namespace['_quiescence_runtime']
                runtimes=[];old=SearchPathRuntime.attach_stats
                def attach(rt,stats):
                    v=old(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return v
                SearchPathRuntime.attach_stats=attach
                try:
                    p.rr.stopped();ev=CountedSemanticEvaluator(c,profile,ec,backend='native');player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=True));t=time.perf_counter();value=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
                    rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot
                    rows.append(dict(order=repeat,mode=mode,decision=record_value(value),counts=dict(counts),drop_counts=dict(probe.counts),seconds=elapsed,root_restored=True,runtime=dict(provider_calls=rt.legal_provider_calls,fallbacks=rt.legal_provider_fallbacks,failures=rt.legal_provider_operational_failures),availability=player.native_legality_provider.availability_metrics))
                    write_record(b/'result.json',dict(complete=False,rows=rows));print(repeat,mode,round(elapsed,3),value.completed_depth,value.score,value.nodes,value.qnodes,dict(counts),flush=True)
                finally:SearchPathRuntime.attach_stats=old
    finally:search_module._quiescence_runtime=original
    write_record(b/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':
    for seconds in [1,16,64,256]:run(Path(sys.argv[1])/str(seconds),seconds=seconds,key='1090')
