from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
sys.path.insert(0,'tests');sys.path.insert(0,'tests/development')
from test_quiet_action_probe import context
from rule_semantics_ir_fixtures import weird_rulesets
from scripts.quiet_action_probe import QuietActionProbe
from generic_chess.ai.alphabeta.quiescence import enemy_board_count,material_inventory
from scripts.research_record import record_value
ctx=context(weird_rulesets()[2],['.......k','........','........','........','........','........','R.......','K.......'])
rt=ctx.runtime;states=[]
for phase in range(2):
 root=rt.position;probe=QuietActionProbe(shadow=True);engine=probe.prepare(ctx);assert engine is not None
 enemies=enemy_board_count(root,root.side_to_move);inventory=material_inventory(root)
 changes=[]
 for a in rt.legal_actions():
  semantic,binding=rt._bindings[a];child=engine._transition(root,semantic,binding)
  probe.exclude(ctx,a,engine,enemies,inventory)
  with rt.pushed(a):assert rt.position==child
  if child.aux_state!=root.aux_state:changes.append(dict(action=record_value(a),aux=record_value(child.aux_state)))
 assert rt.position is root;rt.assert_balanced()
 states.append(dict(phase=phase,side=root.side_to_move,aux=record_value(root.aux_state),counts=dict(probe.counts),aux_changed_children=changes))
 if phase==0:
  a=next(a for a in rt.legal_actions() if 'promotion_grants_one_turn_right' in a.pattern_id)
  rt.push(a)
Path('.local_agent/aux-quiet-20261012/shadow.json').write_text(json.dumps(dict(states=states,root_restored_each_phase=True),indent=2)+'\n',encoding='utf-8')
print(json.dumps(states,indent=2))
