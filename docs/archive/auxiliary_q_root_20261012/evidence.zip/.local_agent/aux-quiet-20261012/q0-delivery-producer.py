"""Existing Core minimal-q0 versus C iterative-q0 system paths; not pure executor ratio."""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from types import SimpleNamespace
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.rules.schema import ruleset_from_dict
from scripts.native_core_availability import NativeCoreAvailability
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab,iterative_minimal
from scripts.full_q_refresh_comparison import runtime_state
from scripts.research_record import record_value,write_record
B=Path(sys.argv[1]);B.mkdir(parents=True,exist_ok=True);assert not (B/'declaration.json').exists()
write_record(B/'declaration.json',dict(question='Do existing Core-minimal and compiled C q0 system paths deliver different finite support under common clock budgets?',cases=['chess-ep','shogi-promotion','1090','1091'],max_depth=12,calls=16,node_limit=10000000,seconds=[1,16,64,256],q=0,tt=0,ordering='C native candidate order; Core public lexical order, explicit difference',terminal_scale='Core adapter matches C iterative100000000-ply; originalCore1e9 preserved separately',bounds='Both10millionnodes and1/16/64/256s/maxD12; Nodecap declared before any new curve, avoids a low work ceiling masking time capability; no old q4/100k fixed controls changed. Maximum1348search seconds(~22.5min) plus bounded setup, under1h; owned q4 curve overlap/ordinary concurrent load.',decision='Actual returned depth/q0/decision and resource termination, no same-tree/compiled-only claim. This exposed root differs from q4 curves in leaf/algorithm. New resource curve cannot restore unexposed validation; no cap extension after results. C iteration/PV fullwindows and native token tie versus existing Core lexical tie are explicit.',source='Pinned6862c0bd existing search entries; no new C kernel or engine changes'))
class Board:
 def __init__(self,c,s,values):
  self.compiled=c;self.values=values;self.provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert self.provider is not None
  self.availability=NativeCoreAvailability(c)
  self.runtime=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=self.provider,availability_provider=self.availability.for_position)
  self.saved=runtime_state(self.runtime);self.checkpoint=None
 def actions(self):return sorted([(str(a),a) for a in self.runtime.legal_actions(checkpoint=self.checkpoint)])
 def push(self,a):self.runtime.push(a,checkpoint=self.checkpoint)
 def pop(self):self.runtime.pop()
 def evaluate(self):
  p=self.runtime.position;side=p.side_to_move
  return sum((1 if x.owner==side else -1)*self.values[x.current_type_id] for x in p.board if x)+sum((1 if owner==side else -1)*self.values[tid]*n for owner,h in enumerate(p.hands) for tid,n in h.items())
 def terminal(self,ply):
  t=self.runtime.terminal_status
  if not t.is_terminal:return None
  return 0 if t.winner is None else (100000000-ply if t.winner==self.runtime.position.side_to_move else -100000000+ply)
 def restored(self):return runtime_state(self.runtime)==self.saved
rows=[]
for key in ['1090']:
 if key.isdigit():
  samples=json.loads(Path('.local_agent/aux-quiet-20261012/'+('active-mixed-premise.json' if key=='1091' else 'mixed-premise.json')).read_text());sample=next(x for x in samples if str(x['seed'])==key);c=compile_ruleset_for_execution(ruleset_from_dict(sample['rules']));s=GameSession(c)
  for _ in range(4):
   aa=s.legal_actions();aux=[a for a in aa if 'promotion_grants_one_turn_right' in a.pattern_id];s.submit(aux[0] if aux else sorted(aa,key=repr)[0])
 else:
  case=next(x for x in CASES if x['id']==key);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));core=CoreBoard(case,c);s=SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses)
 provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None
 values={tid:100*(i+1) for i,tid in enumerate(provider.native_rules.type_ids)}
 native=provider.native_rules;pos=pack_semantic_search_position(c,native,s);before=ns.snapshot(native,pos)
 board=Board(c,s,values);root_terminal=ns.terminal_status(native,pos);assert root_terminal['status']==board.runtime.terminal_status.status.value and root_terminal['winner']==board.runtime.terminal_status.winner
 write_record(B/(key+'-sample.json'),dict(state=record_value(s.state),witnesses=record_value(s._search_witnesses),values=values,root_native_snapshot=before))
 for budget in [1,16,64,256]:
  for order in range(2):
   for mode in (['core','native'] if order==0 else ['native','core']):
    started=time.perf_counter()
    if mode=='core':
     board=Board(c,s,values);result=iterative_minimal(board,seconds=budget,node_limit=10000000,max_depth=12)
     assert board.restored();board.runtime.assert_balanced();actual=dict(result,provider=board.runtime._legal_provider_active,availability=dict(calls=board.availability.calls,fallbacks=board.availability.fallbacks))
    else:
     result=ns.semantic_iterative_search(native,pos,12,max_nodes=10000000,max_time_seconds=budget,board_values=values,hand_values=values,tt_megabytes=0);assert ns.snapshot(native,pos)==before
     actual=result
    rows.append(dict(case=key,order=order,mode=mode,budget=budget,seconds=time.perf_counter()-started,result=record_value(actual),root_restored=True));write_record(B/'result.json',dict(complete=False,rows=rows));print(key,order,mode,round(rows[-1]['seconds'],4),actual.get('score'),actual.get('nodes',actual.get('work',{}).get('nodes')),flush=True)
 write_record(B/'result.json',dict(complete=True,rows=rows))
