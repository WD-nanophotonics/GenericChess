from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,'tests')
from dataclasses import replace
from scripts import full_q_refresh_comparison as p
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess import compile_ruleset_for_execution
from scripts.research_record import record_value
rows=[]
for seed in range(1091,1101):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True))
 action=weird_rulesets()[2].semantic_actions[0]
 tid=next(pt.type_id for pt in g.ruleset.piece_types if not pt.is_anchor)
 # Recombine existing one-turn auxiliary creation with a generated actor, but
 # preserve its current type: this probes auxiliary mechanics without adding
 # an unrelated promotion target to the generated type catalogue.
 effects=tuple(e for e in action.effects if e.kind!='set_current_type')
 action=replace(action,type_ids=(tid,),effects=effects)
 rules=replace(g.ruleset,semantic_actions=(action,))
 c=compile_ruleset_for_execution(rules);s=p.GameSession(c)
 from generic_chess.rules.schema import ruleset_to_dict
 source=ruleset_to_dict(rules)
 for ply in range(4):
  assert s.result.status.value=='ongoing'
  aa=s.legal_actions();aux=[a for a in aa if 'promotion_grants_one_turn_right' in a.pattern_id]
  a=aux[0] if aux else sorted(aa,key=repr)[0]
  s.submit(a)
 if not any(v==1 for _,v in s.state.position.aux_state):
  print(seed, "inactive auxiliary root",flush=True);continue
 from generic_chess.core.transition import apply_action
 wins=[a for a in s.legal_actions() if (lambda child: child.terminal_status.is_terminal and child.terminal_status.winner==s.state.position.side_to_move)(apply_action(s.state,a,c))]
 if wins:
  print(seed, "one-ply terminal win",len(wins),flush=True);continue
 rows.append(dict(seed=seed,tid=tid,legal=len(s.legal_actions()),ply=s.state.ply_count,aux=record_value(s.state.position.aux_state),rules=source,state=record_value(s.state),witnesses=record_value(s._search_witnesses)));break
Path('.local_agent/aux-quiet-20261012/active-mixed-premise.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print([(r['seed'],r['tid'],r['legal'],r['aux']) for r in rows])
