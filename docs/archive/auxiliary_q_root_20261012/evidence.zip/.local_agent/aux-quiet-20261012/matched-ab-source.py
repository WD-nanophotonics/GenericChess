from scripts.search_backend_comparison import Work,Exhausted
from time import perf_counter
import hashlib
from dataclasses import asdict
from generic_chess.ai.evaluation.config import MATE_SCORE
def matched_ab(board, depth, *, seconds=30, node_limit=100000, trace=False, cooperative=False):
    """Identical algorithm and lexicographic actions across backend adapters.

    Nodes count all recursive entries including root and terminal leaves;
    pushes count successful child transitions. Time is checked before each node.
    Completed earlier root children survive a budget exception; no fake D-depth.
    """
    work, digest = Work(), hashlib.sha256()
    runtime_fields = ('pushes', 'pops', 'legal_provider_calls', 'legal_provider_actions',
                      'legal_provider_seconds', 'legal_provider_payload_seconds',
                      'legal_provider_decode_binding_seconds', 'legal_provider_fallbacks',
                      'legal_provider_operational_failures', 'child_external_key_computations',
                      'history_reconstruction_attempts', 'opaque_history_child_external_key_computations')
    runtime = getattr(board, 'runtime', None)
    before = {name: getattr(runtime, name, 0) for name in runtime_fields} if runtime else {}
    start = perf_counter()
    def deadline_checkpoint():
        if perf_counter()-start >= seconds:
            raise Exhausted
    if hasattr(board, 'checkpoint'):
        board.checkpoint = deadline_checkpoint if cooperative else None
    best_move, best_score = None, -MATE_SCORE*2

    def visit(left, alpha, beta, ply, pv_node):
        nonlocal best_move, best_score
        if work.nodes >= node_limit or perf_counter()-start >= seconds:
            raise Exhausted
        work.nodes += 1
        work.terminal_queries += 1
        terminal = board.terminal(ply)
        if terminal is not None or left == 0:
            work.leaves += 1
            value = terminal if terminal is not None else board.evaluate()
            if trace:
                digest.update(f'L:{ply}:{value};'.encode())
            return value
        work.legal_queries += 1
        actions = board.actions()
        if trace:
            digest.update(('A:' + ','.join(label for label, _ in actions) + ';').encode())
        value = -MATE_SCORE*2
        for index, (label, action) in enumerate(actions):
            board.push(action)
            work.pushes += 1
            try:
                child_alpha,child_beta = (-1000000000,1000000000) if pv_node or ply==0 else (-beta,-alpha)
                score = -visit(left-1, child_alpha, child_beta, ply+1, True if ply==0 else pv_node and index==0)
            finally:
                board.pop()
            if trace:
                digest.update(f'V:{ply}:{label}:{score};'.encode())
            if ply == 0:
                work.root_completed += 1
                if best_move is None or score > best_score or (score==best_score and label<best_move):
                    best_move, best_score = label, score
            value = max(value, score)
            alpha = max(alpha, value)
            if alpha >= beta:
                work.cutoffs += 1
                break
        return value

    try:
        score = visit(depth, -1000000000, 1000000000, 0, True)
        reason = 'completed_depth'
    except Exhausted:
        score, reason = (best_score if best_move is not None else None), 'budget'
    finally:
        if hasattr(board, 'checkpoint'):
            board.checkpoint = None
    if not board.restored():
        raise AssertionError('search failed to restore root')
    return dict(move=best_move, score=score, reason=reason, wall_seconds=perf_counter()-start,
                completed_depth=depth if reason == 'completed_depth' else 0,
                work=asdict(work), trace_sha256=digest.hexdigest() if trace else None,
                runtime_counters={name: getattr(runtime, name, 0)-value for name, value in before.items()},
                native_provider_active=None if runtime is None else runtime._legal_provider_active)
