import sys, time, json, hashlib
from pathlib import Path
sys.path[:0] = [str(Path.cwd()), str(Path.cwd() / 'tests')]
from generic_chess.core import search_runtime as m
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.actions import action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess import build_builtin_ruleset, compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.search_backend_comparison import CASES, CoreBoard
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import record_value, write_record
from rule_semantics_ir_fixtures import STRESS_GROUPS, weird_rulesets
B = Path(__file__).parent

def tail(position, compiled):
    values = {('ruleset',): compiled.ruleset_fingerprint, ('side',): position.side_to_move}
    for owner, hand in enumerate(position.hands):
        values[('hand', owner)] = tuple(hand.counts)
    engine = semantic_engine_for(compiled)
    if engine is not None:
        physical = dict(position.aux_state)
        covered = set()
        for slot in engine.ir.aux_slots:
            for owner in ((-1,) if slot.scope == 'global' else (0, 1)):
                address = (slot.slot_id, owner)
                covered.add(address)
                values[('aux', address)] = physical.get(address, slot.initial)
        for address, value in position.aux_state:
            if address not in covered:
                values[('aux_unknown', address)] = value
    return values

def candidate(parent, child, compiled, current):
    value = current
    for i, (a, b) in enumerate(zip(parent.board, child.board)):
        if a is b:
            continue
        old = None if a is None else (a.owner, a.base_type_id, a.current_type_id, a.promoted)
        new = None if b is None else (b.owner, b.base_type_id, b.current_type_id, b.promoted)
        if old != new:
            value = m._xor(m._xor(value, m._component_token(('board', i), old)), m._component_token(('board', i), new))
    before, after = tail(parent, compiled), tail(child, compiled)
    for address in before.keys() | after.keys():
        old, new = before.get(address), after.get(address)
        if ((address in before) != (address in after) or old != new
                or (address[0] in ('aux', 'aux_unknown') and not m._aux_value_equal(old, new))):
            if address in before:
                value = m._xor(value, m._component_token(address, old))
            if address in after:
                value = m._xor(value, m._component_token(address, new))
    return value

def roots():
    for case in CASES:
        c = compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game'] == 'chess' else 'standard_shogi'))
        b = CoreBoard(case, c)
        yield case['id'], c, b.initial, b.witnesses
    for name, factory in STRESS_GROUPS.items():
        c = compile_ruleset_for_execution(factory())
        s = GameSession(c)
        yield name, c, s.state, s._search_witnesses
    for i, rule in enumerate(weird_rulesets()):
        c = compile_ruleset_for_execution(rule)
        s = GameSession(c)
        yield 'weird-' + str(i), c, s.state, s._search_witnesses

class BatchLimit(Exception):
    pass

def traverse():
    started = time.perf_counter()
    deadline = started + 300  # ONE whole-batch fuse, not a per-root allowance.
    result = dict(complete=False, source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  maximum_depth=3, per_root_push_cap=2000, whole_batch_fuse_seconds=300, rows=[])
    old = m._semantic_component_diff_hash
    m._semantic_component_diff_hash = candidate
    def check():
        stopped()
        if time.perf_counter() > deadline:
            raise BatchLimit('whole-batch300second fuse')
    try:
        for name, c, s, w in roots():
            check()
            start = time.perf_counter()
            rt = m.SearchPathRuntime.from_state(s, c, history_witnesses=w)
            counts = dict(pushes=0, public_successors=0, promoted_changes=0, hand_changes=0,
                          aux_changes=0, multi_cell_changes=0, terminal_children=0)
            digest = hashlib.sha256()
            capped = [False]
            row = dict(root=name, ruleset=c.ruleset_fingerprint, counts=counts, complete=False)
            result['rows'].append(row)
            def walk(public, depth):
                if depth == 3 or public.terminal_status.is_terminal:
                    return
                for action in rt.legal_actions():
                    if counts['pushes'] >= 2000:
                        capped[0] = True
                        return
                    if counts['pushes'] % 100 == 0:
                        check()
                    before, priorhash = rt.position, rt.runtime_hash
                    expected = apply_action(public, action, c)
                    counts['public_successors'] += 1
                    with rt.pushed(action):
                        counts['pushes'] += 1
                        assert rt.position == expected.position and rt.ply_count == expected.ply_count and rt.terminal_status == expected.terminal_status, (name, depth, str(action), 'state')
                        assert rt.runtime_hash == m._full_runtime_hash(rt.position, c), (name, depth, str(action), 'hash')
                        changed = sum(a != b for a, b in zip(before.board, rt.position.board))
                        counts['multi_cell_changes'] += changed > 2
                        counts['hand_changes'] += before.hands != rt.position.hands
                        counts['aux_changes'] += before.aux_state != rt.position.aux_state
                        counts['terminal_children'] += expected.terminal_status.is_terminal
                        counts['promoted_changes'] += any(a is not None and b is not None and a.current_type_id != b.current_type_id for a, b in zip(before.board, rt.position.board))
                        digest.update(json.dumps((action_to_dict(action), record_value(rt.runtime_hash), record_value(rt.position.aux_state), record_value(rt.terminal_status)), sort_keys=True).encode())
                        walk(expected, depth + 1)
                    assert rt.position is before and rt.runtime_hash == priorhash
            try:
                walk(s, 0)
            finally:
                rt.assert_balanced()
                row.update(seconds=time.perf_counter()-start, capped=capped[0], digest=digest.hexdigest())
                write_record(B/'traversal.json', result)
            row['complete'] = True
            write_record(B/'traversal.json', result)
            print(name, row['seconds'], counts, capped[0], flush=True)
    except BatchLimit as exc:
        result['stop_reason'] = str(exc)
    finally:
        m._semantic_component_diff_hash = old
        result['seconds'] = time.perf_counter()-started
        write_record(B/'traversal.json', result)
    result['complete'] = len(result['rows']) == 18 and all(row['complete'] for row in result['rows'])
    write_record(B/'traversal.json', result)

if __name__ == '__main__':
    traverse()
