"""Existing S0 candidate + checked make early exit; scoped feasibility only."""
import sys,time,json
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.transition import apply_action
from generic_chess.native.semantic import pack_position,candidate_actions,make_checked
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
b=Path('.local_agent/scalar-hash-20261011')
cases=CASES+[dict(id='quiet-stalemate',game='chess',setup='7k/5Q2/6K1/8/8/8/8/8 b - - 0 1',moves=''),dict(id='quiet-checkmate',game='chess',setup='7k/6Q1/6K1/8/8/8/8/8 b - - 0 1',moves='')]
groups=[]
for case in cases:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None
 states=[('root',board.initial)]+[(label,apply_action(board.initial,a,c)) for label,a in board.actions()[:16]]
 groups.append((case,semantic_engine_for(c),provider,states))
def probe(engine,p,state):
 assert p.supports_position(state.position,state.ply_count)
 native=pack_position(p.native_rules,p._state_only_payload(state.position,state.ply_count));candidates=candidate_actions(p.native_rules,native);attempts=0
 for action in candidates:
  attempts+=1
  try:make_checked(p.native_rules,native,action)
  except ValueError as exc:
   if str(exc)!='semantic action is not valid for the current position':raise
  else:return True,len(candidates),attempts
 return engine.pass_is_legal(state.position),len(candidates),attempts
out=dict(scope='Existing S0 full candidates plus individually checked Native make, early exit; only supported below-cutoff positions. Each checked make still allocates child and hashes/appends history, not a true transient early-exit kernel. No new DLL or product integration.',rows=[],complete=False);start=time.perf_counter()
for repeat in range(4):
 for case,engine,p,states in groups:
  stopped();assert time.perf_counter()-start<180
  for label,state in states:
   pair=[]
   for native in ((False,True) if repeat%2==0 else (True,False)):
    t=time.perf_counter();value=probe(engine,p,state) if native else (engine.has_legal_action(state.position),None,None);elapsed=time.perf_counter()-t
    out['rows'].append(dict(root=case['id'],child=label,repeat=repeat,native=native,answer=value[0],candidates=value[1],attempts=value[2],seconds=elapsed));pair.append(value[0])
   assert pair[0]==pair[1]
out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(b/'candidate-availability.json',out)
summary=[]
for case in cases:
 rows=[r for r in out['rows'] if r['root']==case['id']];a=sum(r['seconds'] for r in rows if not r['native']);z=sum(r['seconds'] for r in rows if r['native']);summary.append(dict(root=case['id'],native_to_core_total_cost=z/a,native_attempts=sum(r['attempts'] for r in rows if r['native'])))
write_record(b/'candidate-availability-summary.json',summary);print('calls',len(out['rows']),summary)
