"""Does automatic checking continuation invalidate ongoing=>below-max assumption?"""
import sys,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution,RuleAutomaticAdjudication
from generic_chess.core.pieces import Piece
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.audit_lichess_complete_children import uci
b=Path('.local_agent/scalar-hash-20261011');rows=[[None]*8 for _ in range(8)];rows[1][0]=Piece(0,'Q','Q');rows[0][6]=Piece(0,'K','K');rows[7][7]=Piece(1,'K','K')
c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),max_ply=1,initial_position=tuple(map(tuple,rows)),automatic_adjudications=(RuleAutomaticAdjudication('checking-continuation',1),)))
s=GameSession(c);s.submit(next(a for a in s.legal_actions() if uci(a)=='a2a8'));p=NativeSemanticLegalityProvider.try_create(c,strict=True);assert p is not None
rt=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=p)
v=dict(ply=s.state.ply_count,status=s.state.terminal_status.status.value,public_actions=[uci(a) for a in s.legal_actions()],runtime_actions=[uci(a) for a in rt.legal_actions()],raw_native_count=len(p(s.state.position,s.state.ply_count,None)))
assert v['status']=='ongoing' and v['public_actions'] and not v['runtime_actions'];(b/'pending-cutoff-before.json').write_text(json.dumps(v,indent=2),encoding='utf-8');print(v)
