import sys,time,json,importlib.util,hashlib
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path('.local_agent/scalar-hash-20261011')
spec=importlib.util.spec_from_file_location('pilot',B/'projection.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
spec=importlib.util.spec_from_file_location('weighted',Path('.local_agent/weighted-backend-20261011/bridge.py'));w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta import search
from scripts.research_record import record_value,write_record
from generic_chess.core import terminal
namespace=dict(terminal.__dict__);exec(compile((B/'checked_terminal_candidate.py').read_text(encoding='utf-8'),str(B/'checked_terminal_candidate.py'),'exec'),namespace);candidate=namespace['terminal_from_search_runtime'];original_terminal=p.m.terminal_from_search_runtime;ctx=search._Context;t=time.perf_counter();deadline=t+300
result=dict(complete=False,whole_batch_fuse_seconds=300,rows=[],fixed_parity=[],scope='Eight old canonical development roots, weighted2/5/3 frozen evaluator; Existing supported Native legality plus Core q4, unchanged main search; Checked-child exact frontier reuse through supported Native provider; old Core-prefix negatives retained, no integration')
def clean(d):return {k:v for k,v in d.items() if 'seconds' not in k and not k.startswith('time_')}
try:
 for case in CASES:
  c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);s=GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses;e=w.weighted(c,VALUES[case['game']]);before=s.state
  for mode in ('nodes','time1','time4'):
   for order in range(2):
    pair=[]
    for experimental in ((False,True) if order==0 else (True,False)):
     p.stopped();assert time.perf_counter()<deadline
     contexts=[]
     def context(*a,**kw):x=ctx(*a,**kw);contexts.append(x);return x
     search._Context=context;p.m.terminal_from_search_runtime=candidate if experimental else original_terminal
     engine=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=True)
     limits=SearchLimits(max_depth=4,max_nodes=512 if mode=='nodes' else None,max_time_seconds=5 if mode=='nodes' else (1 if mode=='time1' else 4),quiescence_max_depth=4,quiescence_hard_max_depth=8)
     start=time.perf_counter();d=engine.choose_action(s,limits);elapsed=time.perf_counter()-start
     rt=contexts[0].runtime;rt.assert_balanced();assert s.state==before and rt.position==before.position and rt.runtime_hash==p.m._full_runtime_hash(rt.position,c)
     assert d.action in s.legal_actions()
     row=dict(root=case['id'],mode=mode,order=order,projection=experimental,wall=elapsed,decision=record_value(d),statistics=record_value(contexts[0].stats));result['rows'].append(row);pair.append(row);write_record(B/'checked-terminal-cost.json',result)
    if mode=='nodes':assert clean(pair[0]['decision'])==clean(pair[1]['decision']) and {k:v for k,v in clean(pair[0]['statistics']).items() if not k.startswith('native_')}=={k:v for k,v in clean(pair[1]['statistics']).items() if not k.startswith('native_')};result['fixed_parity'].append([case['id'],order])
 result['complete']=True
finally:
 p.m.terminal_from_search_runtime=original_terminal;search._Context=ctx;result['seconds']=time.perf_counter()-t;write_record(B/'checked-terminal-cost.json',result)
print('complete',result['complete'],'rows',len(result['rows']),'seconds',result['seconds'])
