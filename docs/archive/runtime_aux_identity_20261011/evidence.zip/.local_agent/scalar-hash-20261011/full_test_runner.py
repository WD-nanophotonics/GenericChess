from pathlib import Path
import subprocess,json,time
p=Path('.local_agent/scalar-hash-20261011')
args=[str(Path('.venv/Scripts/python.exe').resolve()),'-m','pytest','-q','-p','no:cacheprovider','--basetemp=.local_agent/pytest-runs/typed-aux-full-20261011']
t=time.perf_counter();r=subprocess.run(args,capture_output=True,text=True);v=dict(args=args,exit_code=r.returncode,seconds=time.perf_counter()-t,stdout=r.stdout,stderr=r.stderr);(p/'full-tests.json').write_text(json.dumps(v,indent=2),encoding='utf-8');print(r.stdout[-1500:]);print('exit',r.returncode,'seconds',v['seconds']);raise SystemExit(r.returncode)
