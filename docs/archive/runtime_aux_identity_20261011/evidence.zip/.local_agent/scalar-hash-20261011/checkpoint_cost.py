import sys,time,json,importlib.util,statistics
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path('.local_agent/scalar-hash-20261011')
from generic_chess.core.semantic_executor import SemanticEngine
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
spec=importlib.util.spec_from_file_location('generic_chess.core.old_semantic_callback',B/'semantic_executor_before_checkpoint.py');old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
original=SemanticEngine._trial_child_if_s3_legal;start=time.perf_counter();deadline=start+180;out=dict(complete=False,whole_batch_fuse_seconds=180,rows=[])
roots=[(case,compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))) for case in CASES]
try:
 for cooperative in (False,True):
  for repeat in range(4):
   for case,c in roots:
    pair=[]
    for fixed in ((False,True) if repeat%2==0 else (True,False)):
     stopped();assert time.perf_counter()<deadline
     SemanticEngine._trial_child_if_s3_legal=original if fixed else old.SemanticEngine._trial_child_if_s3_legal
     r=minimal_ab(CoreBoard(case,c),3,seconds=5,node_limit=512,cooperative=cooperative)
     row=dict(root=case['id'],cooperative=cooperative,repeat=repeat,fixed=fixed,**r);pair.append(row);out['rows'].append(row);write_record(B/'checkpoint-cost.json',out)
    sign=lambda r:(r['move'],r['score'],r['reason'],r['work'])
    assert sign(pair[0])==sign(pair[1])
 out['complete']=True
finally:SemanticEngine._trial_child_if_s3_legal=original;out['seconds']=time.perf_counter()-start;write_record(B/'checkpoint-cost.json',out)
print('complete',out['complete'],'rows',len(out['rows']),'seconds',out['seconds'])
