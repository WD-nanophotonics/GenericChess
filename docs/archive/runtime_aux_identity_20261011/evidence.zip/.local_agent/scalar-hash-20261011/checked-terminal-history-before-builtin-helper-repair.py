import sys,importlib.util,inspect,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import search_runtime as m,terminal
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.search_backend_comparison import CoreBoard
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value
b=Path('.local_agent/scalar-hash-20261011');n=dict(terminal.__dict__);exec(compile((b/'checked_terminal_candidate.py').read_text(encoding='utf-8'),str(b/'checked_terminal_candidate.py'),'exec'),n)
r=build_builtin_ruleset('western_chess');c=compile_ruleset_for_execution(replace(r,max_ply=1));case=dict(game='chess',setup='7k/8/8/8/8/8/8/Q5K1 w - - 0 1',moves='');board=CoreBoard(case,c);provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None;rt=m.SearchPathRuntime.from_state(board.initial,c,history_witnesses=board.witnesses,legal_binding_provider=provider);action=next(a for label,a in board.actions() if label=='a1a8');expected=apply_action(board.initial,action,c);old=m.terminal_from_search_runtime;m.terminal_from_search_runtime=n['terminal_from_search_runtime']
try:
 with rt.pushed(action):
  actual=rt.legal_actions();v=dict(expected_terminal=record_value(expected.terminal_status),runtime_terminal=record_value(rt.terminal_status),legal_cache_count=len(actual),terminal_equal=rt.terminal_status==expected.terminal_status,checked_child=rt._frames[-1].child_in_check,native_calls=rt.legal_provider_calls);assert rt.terminal_status.is_terminal
finally:m.terminal_from_search_runtime=old;rt.assert_balanced()
(b/'checked-terminal-history-boundary-before.json').write_text(json.dumps(v,indent=2),encoding='utf-8');print(v)
