import sys,time,json,importlib.util,hashlib
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path('.local_agent/scalar-hash-20261011')
from generic_chess.core import search_runtime as m
import scripts.search_backend_comparison as bridge
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
spec=importlib.util.spec_from_file_location('generic_chess.core.oldruntime',B/'search_runtime_before.py');old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
spec=importlib.util.spec_from_file_location('pilot',B/'projection.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
start=time.perf_counter();deadline=start+240;result=dict(complete=False,whole_batch_fuse_seconds=240,scope='Canonical eight existing roots; matched frozen arbitrary material, lexical minimal AB; repair overhead separate from projection; no playing strength claim',rows=[])
roots=[(case,compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))) for case in bridge.CASES]
original=bridge.SearchPathRuntime;hashfun=m._semantic_component_diff_hash
try:
 for repeat in range(4):
  for case,c in roots:
   for arm in (('old','repair','projection') if repeat%2==0 else ('projection','repair','old')):
    stopped();assert time.perf_counter()<deadline,'whole batch fuse'
    bridge.SearchPathRuntime=old.SearchPathRuntime if arm=='old' else m.SearchPathRuntime
    m._semantic_component_diff_hash=p.candidate if arm=='projection' else hashfun
    board=bridge.CoreBoard(case,c);r=bridge.minimal_ab(board,3,seconds=5,node_limit=512,trace=False)
    result['rows'].append(dict(root=case['id'],repeat=repeat,arm=arm,**r));write_record(B/'canonical-cost.json',result)
 for case,c in roots:
  control=[]
  for arm in ('old','repair','projection'):
   stopped();assert time.perf_counter()<deadline
   bridge.SearchPathRuntime=old.SearchPathRuntime if arm=='old' else m.SearchPathRuntime;m._semantic_component_diff_hash=p.candidate if arm=='projection' else hashfun
   r=bridge.minimal_ab(bridge.CoreBoard(case,c),2,seconds=5,node_limit=5000,trace=True);control.append(dict(arm=arm,**r))
  signatures=[(r['move'],r['score'],r['reason'],r['work'],r['trace_sha256']) for r in control];assert all(s==signatures[0] for s in signatures)
  result.setdefault('trace_controls',[]).append(dict(root=case['id'],rows=control));write_record(B/'canonical-cost.json',result)
 result['complete']=True
finally:
 bridge.SearchPathRuntime=original;m._semantic_component_diff_hash=hashfun;result['seconds']=time.perf_counter()-start;write_record(B/'canonical-cost.json',result)
print('complete',result['complete'],'rows',len(result['rows']),'seconds',result['seconds'])
