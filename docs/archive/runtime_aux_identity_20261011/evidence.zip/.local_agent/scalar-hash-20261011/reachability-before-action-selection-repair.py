import sys,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from rule_semantics_ir_fixtures import _king_type,_semantic_ruleset
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.schema import RuleAuxState,RuleSemanticAction,RuleGeometrySpec,RuleActionEffect,RuleSquareRef,RuleInvariant,ruleset_to_dict,ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.actions import SemanticBoardMove,action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime,_full_runtime_hash,_runtime_position_identity
from generic_chess.core.identity import position_identity_key
from scripts.research_record import write_record,record_value
B=Path('.local_agent/scalar-hash-20261011');r={'rows':[],'complete':False}
for initial in (0,1):
 for value in (0,1,False,True):
  flag=RuleAuxState('flag','bool','global','persistent',initial)
  action=RuleSemanticAction(name='write',type_ids=('A',),geometry=RuleGeometrySpec(kind='leap',offset=(1,0)),target_relation='empty',composition='augment',aux_state=(flag,),effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),RuleActionEffect('set_bool',slot_name='flag',value=value)),invariants=(RuleInvariant('own_anchor_safe'),))
  rows=[[None]*5 for _ in range(5)];rows[0][0]=Piece(0,'K','K');rows[4][4]=Piece(1,'K','K');rows[1][1]=Piece(0,'A','A')
  rule=_semantic_ruleset((_king_type(),PieceType('A','A',())),(action,),n=5,rows=tuple(tuple(x) for x in rows))
  row={'initial':initial,'value':value,'value_type':type(value).__name__}
  try:ruleset_from_dict(ruleset_to_dict(rule));row['json_parser']='accepted'
  except Exception as e:row['json_parser']=type(e).__name__+': '+str(e)
  try:
   c=compile_semantic_ruleset(rule);s=initial_state(c);rt=SearchPathRuntime(s,c);a=next(a for a in rt.legal_actions() if isinstance(a,SemanticBoardMove));child=apply_action(s,a,c);rt.push(a)
   row.update(action=action_to_dict(a),child_aux=record_value(child.position.aux_state),runtime_aux=record_value(rt.position.aux_state),delta_full_equal=rt.runtime_hash==_full_runtime_hash(rt.position,c),public_runtime_state_equal=rt.position==child.position,root_hash=record_value(_full_runtime_hash(s.position,c)),delta_hash=record_value(rt.runtime_hash),full_hash=record_value(_full_runtime_hash(rt.position,c)))
   rt.pop();assert rt.position==s.position and rt.runtime_hash==_full_runtime_hash(s.position,c)
   row['object_compile']='accepted'
  except Exception as e:row['object_compile']=type(e).__name__+': '+str(e)
  r['rows'].append(row);write_record(B/'reachability.json',r);print(initial,repr(value),row.get('delta_full_equal'),row['object_compile'])
r['complete']=True;write_record(B/'reachability.json',r)
