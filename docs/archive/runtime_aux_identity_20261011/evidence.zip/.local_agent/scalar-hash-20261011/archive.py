from pathlib import Path
import json,hashlib,zipfile,subprocess
B=Path('.local_agent/scalar-hash-20261011')
root=Path.cwd();dest=root/'docs/archive/runtime_aux_identity_20261011/evidence.zip';dest.parent.mkdir(parents=True,exist_ok=True)
inputs=[p for p in B.iterdir() if p.is_file() and p.suffix in ('.py','.json','.txt','.md') and 'slack' not in p.name and p.name not in ('archive-index.json',)]
inputs += list(Path('generic_chess').rglob('*.py'))
inputs += list(Path('generic_chess/_native').glob('*.c'))+list(Path('generic_chess/_native').glob('*.h'))
inputs += [Path(p) for p in ('scripts/search_backend_comparison.py','scripts/research_record.py','scripts/reserve_refresh_diagnostic.py','scripts/chess_development.py','scripts/audit_lichess_complete_children.py','tests/rule_semantics_ir_fixtures.py','tests/product/test_runtime_aux_identity.py','tests/product/test_semantic_trial_checkpoint.py','tests/product/test_recombined_semantic_lifecycle.py','.local_agent/weighted-backend-20261011/bridge.py')]
inputs += [Path('docs/architecture/ADR-038-production-native-legality-routing.md'),Path('docs/research/RUNTIME_AUX_IDENTITY.md')]
rows=[]
inputs += [Path('tests/product/test_native_legality_terminal_boundary.py'),Path('tests/conftest.py'),Path('tests/ai_fixtures.py')]
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(inputs),key=lambda p:p.as_posix()):
  raw=p.read_bytes();name=p.as_posix();z.writestr(name,raw);rows.append(dict(member=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for r in rows:assert hashlib.sha256(z.read(r['member'])).hexdigest()==r['sha256']
v=dict(schema=1,base_sha='8c3da7b0db64f061371513e7131b1a8f22a63af1',session_id='683b2e1a-3517-44d7-b986-d237a50d6b14',science_complete=False,ui_branch_frozen_sha='99c97bb87474c44af94c76571f326ef8a41eb898',scope='Agent-produced source/results/evidence; no user/private input or raw Slack/account/credential records',limits=['checked_terminal_cost.py and checked_terminal_frontier_audit.py are unexecuted preparations; candidate rejected before those assays','cancellation pre-fix values recovered from complete stdout; original JSON bytes overwritten','availability first ID-only count is invalid due recycled object IDs; corrected counter retains references','native sources do not establish installed binary rebuild; DLL unchanged','hybrid projection assay precedes separate checkpoint repair; original and final source stages separately pinned by final-source-pins.json and delivery-source-pins.json'],archive=dict(path=dest.relative_to(root).as_posix(),bytes=dest.stat().st_size,uncompressed_bytes=sum(r['bytes'] for r in rows),members=len(rows),sha256=hashlib.sha256(dest.read_bytes()).hexdigest()),members=rows)
Path('docs/research/data/runtime_aux_identity_20261011.json').write_text(json.dumps(v,indent=2),encoding='utf-8');(B/'archive-index.json').write_text(json.dumps(v,indent=2),encoding='utf-8');print(v['archive'])
