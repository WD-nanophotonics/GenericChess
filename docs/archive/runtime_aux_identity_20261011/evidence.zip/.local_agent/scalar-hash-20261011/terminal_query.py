import sys,time,json,statistics,hashlib
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import position_identity_key
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path('.local_agent/scalar-hash-20261011')
def run():
 start=time.perf_counter();deadline=start+300
 out=dict(complete=False,whole_batch_fuse_seconds=300,first_lexical_children_per_root=16,repetitions=16,scope='Core lazy legal-availability versus existing Native complete-frontier boolean proxy; compiled provider cache warm; this is not a new native any-action API or whole search timing',states=[],rows=[])
 cases=CASES+[dict(id='quiet-stalemate',game='chess',setup='7k/5Q2/6K1/8/8/8/8/8 b - - 0 1',moves=''),dict(id='quiet-checkmate',game='chess',setup='7k/6Q1/6K1/8/8/8/8/8 b - - 0 1',moves='')]
 groups=[]
 for case in cases:
  stopped();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);engine=semantic_engine_for(c);provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None
  states=[('root',board.initial)]+[(label,apply_action(board.initial,a,c)) for label,a in board.actions()[:16]]
  groups.append((case,c,engine,provider,states))
  for label,state in states:
   core=engine.legal_actions(state.position);pairs=provider(state.position,state.ply_count,None);assert set(a for a,_ in pairs)==set(__import__('generic_chess.core.movegen',fromlist=['legal_actions']).legal_actions(state,c)) if not state.terminal_status.is_terminal else True
   # Availability is geometric/semantic board actions, before history terminal policy.
   expected=bool(core);assert bool(pairs)==expected==engine.has_legal_action(state.position)
   out['states'].append(dict(root=case['id'],child=label,position_key=position_identity_key(state.position,c),position=record_value(state.position),ply=state.ply_count,history=record_value(state.history),legal_count=len(pairs),has_action=expected))
 write_record(B/'terminal-query.json',out)
 for repeat in range(16):
  for case,c,engine,provider,states in groups:
   stopped();assert time.perf_counter()<deadline
   for label,state in states:
    values={}
    for native in ((False,True) if repeat%2==0 else (True,False)):
     t=time.perf_counter();answer=bool(provider(state.position,state.ply_count,None)) if native else engine.has_legal_action(state.position);elapsed=time.perf_counter()-t;values[native]=answer
     out['rows'].append(dict(root=case['id'],child=label,repeat=repeat,native_full_proxy=native,answer=answer,seconds=elapsed))
    assert values[False]==values[True]
  if repeat%4==3:write_record(B/'terminal-query.json',out)
 out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(B/'terminal-query.json',out)
 print('complete',out['complete'],'states',len(out['states']),'calls',len(out['rows']),'seconds',out['seconds'])
if __name__=='__main__':run()
