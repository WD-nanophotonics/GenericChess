def terminal_from_search_runtime(runtime, checkpoint=None) -> TerminalResult:
    """Compute terminal status from a Core-owned mutable search path.

    The runtime supplies mutable occurrence counts and history evidence so
    child pushes do not materialize a public ``GameState`` or copy the full
    repetition tuple.  Rule precedence intentionally mirrors
    :func:`_terminal_from_parts` and the semantic executor.
    """
    from .semantic_executor import semantic_engine_for

    position = runtime.position
    compiled = runtime.compiled
    engine = semantic_engine_for(compiled)
    repeated_target_history = None
    if getattr(compiled, "repeated_cycle_target_conditions", ()):
        _require_complete_runtime_rule_history(runtime)
        if runtime.occurrence_count() >= 2:
            repeated_target_history = _repeated_cycle_target_history_projection(runtime)
    consecutive = consecutive_action_adjudication_status(
        getattr(compiled, "consecutive_action_adjudications", ()),
        runtime.ply_count,
        runtime.history,
        history_complete=getattr(runtime, "_history_complete", False),
    )
    if consecutive == "DRAW":
        return TerminalResult(TerminalStatus.ACTION_CLASS_DRAW)
    # Terminal probing only needs one legal action.  Full legal-set
    # materialization is intentionally deferred to the next search node;
    # root tactical scans may inspect many children without recursing into
    # them, and must not pay for every complete child action set.
    if engine is not None:
        checked_child = bool(runtime._frames and
            runtime._frames[-1].child_identity is runtime._identity and
            runtime._frames[-1].child_in_check is True)
        if checked_child and runtime._legal_provider_active and runtime._legal_binding_provider is not None:
            has_legal = bool(runtime.legal_actions(checkpoint))
        else:
            has_legal = engine.has_legal_action(position, checkpoint=checkpoint)
    else:
        has_legal = has_legal_action(position, compiled)
    if not has_legal:
        # Check only distinguishes mate from stalemate when no action exists.
        # Runtime history independently retains each transition's gave_check.
        if engine is not None:
            checked = engine.in_check(position, position.side_to_move, checkpoint=checkpoint)
        else:
            checked = is_in_check(position, position.side_to_move, compiled)
        if checked:
            return TerminalResult(TerminalStatus.CHECKMATE, 1 - position.side_to_move)
        support = getattr(compiled, "support", None)
        if support is not None:
            stalemate_result = support.stalemate_result
        else:
            stalemate_result = getattr(compiled, "stalemate_result", "draw")
        winner = (
            1 - position.side_to_move
            if stalemate_result == "loss"
            else None
        )
        return TerminalResult(TerminalStatus.STALEMATE, winner)
    if repeated_target_history is not None:
        repeated_target_result = _repeated_cycle_target_result(
            position,
            runtime.ply_count,
            repeated_target_history[0],
            compiled,
            repeated_target_history[1],
        )
        if repeated_target_result is not None:
            return repeated_target_result
    if getattr(compiled, "repetition_policy", "draw") == "continuous_check_loss":
        perpetual = _runtime_perpetual_check_result(runtime)
        if perpetual is not None:
            return perpetual
    limit = getattr(compiled, "repetition_limit", compiled.support.repetition_limit if hasattr(compiled, "support") else 4)
    if runtime.occurrence_count() >= limit:
        return TerminalResult(TerminalStatus.REPETITION)
    automatic = automatic_adjudication_status(
        getattr(compiled, "automatic_adjudications", ()),
        runtime.ply_count,
        runtime.history,
        history_complete=getattr(runtime, "_history_complete", False),
    )
    if automatic == "NO_CONTEST":
        return TerminalResult(TerminalStatus.NO_CONTEST)
    if automatic == "PENDING":
        return TerminalResult(TerminalStatus.ONGOING)
    max_ply = getattr(compiled, "max_ply", compiled.support.max_ply if hasattr(compiled, "support") else 512)
    if runtime.ply_count >= max_ply:
        return TerminalResult(TerminalStatus.MAX_PLY)
    return TerminalResult(TerminalStatus.ONGOING)
