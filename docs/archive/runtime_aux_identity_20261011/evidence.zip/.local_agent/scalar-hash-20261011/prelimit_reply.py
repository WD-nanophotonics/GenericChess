"""Actual Shogi checking pawn-drop at max-1: pure S3 reply vs filtered Native."""
import sys,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands
from generic_chess.core.actions import DropMove
from generic_chess.core.transition import initial_state,legal_actions
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
b=Path('.local_agent/scalar-hash-20261011');rows=[[None]*9 for _ in range(9)];rows[0][4]=Piece(0,'K','K');rows[8][4]=Piece(1,'K','K')
out=[]
for limit in (1,2):
 c=compile_ruleset_for_execution(replace(build_builtin_ruleset('standard_shogi'),max_ply=limit,initial_position=tuple(map(tuple,rows))))
 initial=initial_state(c);pos=replace(initial.position,hands=(Hands((('P',1),)),Hands()));key=repetition_identity_key(pos,c)
 state=GameState(pos,0,((key,1),),initial.terminal_status,(HistoryRecord(key,-1,'',False),))
 p=NativeSemanticLegalityProvider.try_create(c,strict=True);assert p is not None
 actions=legal_actions(state,c);native=[a for a,_ in p(state.position,0,None)];target=next(a for a in actions if getattr(a,'from_square',None) is None and a.to_square.file==4 and a.to_square.rank==7)
 out.append(dict(max_ply=limit,public_count=len(actions),native_count=len(native),checking_pawn_drop_native=target in native))
assert not out[0]['checking_pawn_drop_native'] and out[1]['checking_pawn_drop_native'];(b/'prelimit-reply-before.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(out)
