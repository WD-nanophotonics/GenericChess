import sys,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from rule_semantics_ir_fixtures import _king_type,_semantic_ruleset
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.schema import RuleAuxState,RuleSemanticAction,RuleGeometrySpec,RuleActionEffect,RuleSquareRef,RuleInvariant
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.actions import SemanticBoardMove,action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime,_full_runtime_hash,_runtime_position_identity,_identity_equal
from generic_chess.core.identity import position_identity_key
from generic_chess.core.position import HistoryRecord
from generic_chess.ai.alphabeta.transposition import TranspositionTable,BoundType
from scripts.research_record import write_record,record_value
B=Path('.local_agent/scalar-hash-20261011')
def compiled(initial,value):
 flag=RuleAuxState('flag','bool','global','persistent',initial)
 action=RuleSemanticAction(name='write',type_ids=('A',),geometry=RuleGeometrySpec(kind='leap',offset=(1,0)),target_relation='empty',composition='augment',aux_state=(flag,),effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),RuleActionEffect('set_bool',slot_name='flag',value=value)),invariants=(RuleInvariant('own_anchor_safe'),))
 rows=[[None]*5 for _ in range(5)];rows[0][0]=Piece(0,'K','K');rows[4][4]=Piece(1,'K','K');rows[1][1]=Piece(0,'A','A')
 return compile_semantic_ruleset(_semantic_ruleset((_king_type(),PieceType('A','A',())),(action,),n=5,rows=tuple(tuple(x) for x in rows)))
def imported(c,aux):
 state=initial_state(c);p=replace(state.position,aux_state=aux);key=position_identity_key(p,c)
 return replace(state,position=p,repetition_counts=((key,1),),history=(HistoryRecord(key,-1,''),))
def execute():
 r={'complete':False,'rows':[],'scope':'Actual declared legal writes from supplied typed-scalar roots; forced hash controls are collision tests, not observed natural hash collision or strength evidence.'}
 for initial in (0,1):
  for value in (0,1):
   c=compiled(initial,value);s=imported(c,(((0,-1),bool(value)),));rt=SearchPathRuntime.from_state(s,c);a=next(a for a in rt.legal_actions() if isinstance(a,SemanticBoardMove) and a.pattern_id.startswith("sem_"));child=apply_action(s,a,c)
   rt.push(a);row=dict(initial=initial,write=value,delta_full_equal=rt.runtime_hash==_full_runtime_hash(rt.position,c),public_runtime_equal=rt.position==child.position,root_public_key=position_identity_key(s.position,c),child_public_key=position_identity_key(rt.position,c),child_aux=record_value(rt.position.aux_state),delta=record_value(rt.runtime_hash),full=record_value(_full_runtime_hash(rt.position,c)))
   rt.pop();rt.assert_balanced();r['rows'].append(row);write_record(B/'import-partial.json',r)
 c=compiled(0,1);controls=[]
 for aux in ((((0,-1),1),),(((0,-1),True),)):
  s=imported(c,aux);rt=SearchPathRuntime.from_state(s,c,hash_override=17,history_witnesses=(s.position,));controls.append(rt)
 a,b=controls;table=TranspositionTable();table.store(a.search_key(),2,12345,BoundType.EXACT,None)
 r['forced_collision']=dict(public_keys_differ=position_identity_key(a.position,c)!=position_identity_key(b.position,c),private_identity_equal=a.current_identity==b.current_identity,identity_equal_helper=_identity_equal(a.current_identity,b.current_identity),search_keys_equal=a.search_key()==b.search_key(),tt_eligible=[a.tt_eligible,b.tt_eligible],foreign_tt_entry_hit=table.probe(b.search_key()) is not None)
 before=len(a._occurrences[a.runtime_hash]);previous=a._occurrence_add(b.current_identity,a.runtime_hash);r['forced_collision'].update(occurrence_previous=previous,occurrence_bucket_before=before,occurrence_bucket_after=len(a._occurrences[a.runtime_hash]))
 r['complete']=True;return r
if __name__=='__main__':
 r=execute();write_record(B/(sys.argv[1] if len(sys.argv)>1 else 'import-before.json'),r);print(json.dumps(r,indent=2))
