"""Does automatic checking continuation invalidate ongoing=>below-max assumption?"""
import sys,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution,RuleAutomaticAdjudication
from generic_chess.core.pieces import Piece
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.audit_lichess_complete_children import uci
b=Path('.local_agent/scalar-hash-20261011');rows=[[None]*8 for _ in range(8)];rows[1][0]=Piece(0,'Q','Q');rows[0][6]=Piece(0,'K','K');rows[7][7]=Piece(1,'K','K')
c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),max_ply=1,initial_position=tuple(map(tuple,rows)),automatic_adjudications=(RuleAutomaticAdjudication('checking-continuation',1),)))
s=GameSession(c);s.submit(next(a for a in s.legal_actions() if uci(a)=='a2a8'));p=NativeSemanticLegalityProvider.try_create(c,strict=True);assert p is not None
rt=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=p)
v=dict(ply=s.state.ply_count,status=s.state.terminal_status.status.value,public_actions=[uci(a) for a in s.legal_actions()],runtime_actions=[uci(a) for a in rt.legal_actions()],raw_native_count=len(p(s.state.position,s.state.ply_count,None)))
assert v['status']=='ongoing' and v['public_actions']==v['runtime_actions'];(b/'pending-cutoff-after.json').write_text(json.dumps(v,indent=2),encoding='utf-8');print(v)

from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta import search
from scripts.research_record import record_value
contexts=[];original=search._Context
def context(*a,**kw):
 x=original(*a,**kw);contexts.append(x);return x
search._Context=context
try:
 d=AlphaBetaPlayer(c,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,SearchLimits(max_depth=2,max_nodes=64,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=2))
finally:search._Context=original
assert d.action in s.legal_actions();contexts[0].runtime.assert_balanced()
v['caller_decision']=record_value(d);v['caller_stats']=record_value(contexts[0].stats)
(b/'pending-cutoff-after-caller.json').write_text(json.dumps(v,indent=2),encoding='utf-8');print('caller',uci(d.action),contexts[0].runtime.legal_provider_fallbacks)
