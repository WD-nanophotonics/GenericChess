"""Actual unchanged q4 caller availability stage/count attribution, not speed."""
import sys,time,json,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import search_runtime as m
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
b=Path('.local_agent/scalar-hash-20261011');spec=importlib.util.spec_from_file_location('weighted',Path('.local_agent/weighted-backend-20261011/bridge.py'));w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
orig_terminal=m.terminal_from_search_runtime;orig_has=SemanticEngine.has_legal_action;orig_trial=SemanticEngine._trial_child_if_s3_legal
phase=None;active=None;calls=[];seen=set();retained=[]
def adjudicate(rt,checkpoint=None):
 global phase
 previous=phase;key=(id(rt),id(rt._identity),rt.ply_count)
 retained.append((rt,rt._identity)) # Prevent Python object-id recycling in this private counter.
 phase=dict(stage='pre-adjudication',checked=(rt._frames[-1].child_in_check if rt._frames else None),same_frame_repeat=key in seen)
 seen.add(key)
 try:return orig_terminal(rt,checkpoint)
 finally:phase=previous
def availability(self,position,*args,**kw):
 global active
 previous=active;row=dict(phase or dict(stage='outside-runtime-adjudication',checked=None,same_frame_repeat=False),trials=0)
 active=row;t=time.perf_counter()
 try:
  answer=orig_has(self,position,*args,**kw);row['answer']=answer;return answer
 finally:row['instrumented_seconds']=time.perf_counter()-t;calls.append(row);active=previous
def trial(self,*args,**kw):
 if active is not None:active['trials']+=1
 return orig_trial(self,*args,**kw)
start=time.perf_counter();out=dict(scope='Eight existing actual hybrid weighted q4 512-node calls; annotations do not alter answers/caches; instrumented times include counting overhead, separate old primitive timing provides low-overhead cost. No hypothetical native early-exit timing claim.',rows=[],complete=False)
for case in CASES:
 stopped();assert time.perf_counter()-start<180
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);e=w.weighted(c,VALUES[case['game']])
 pair=[]
 for measured in (False,True):
  s=GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses;calls=[];seen=set();retained=[]
  if measured:m.terminal_from_search_runtime=adjudicate;SemanticEngine.has_legal_action=availability;SemanticEngine._trial_child_if_s3_legal=trial
  try:
   t=time.perf_counter();d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=True).choose_action(s,SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
  finally:m.terminal_from_search_runtime=orig_terminal;SemanticEngine.has_legal_action=orig_has;SemanticEngine._trial_child_if_s3_legal=orig_trial
  assert s.state is board.initial
  pair.append(record_value(d));out['rows'].append(dict(root=case['id'],instrumented=measured,wall=wall,decision=record_value(d),calls=calls))
 def stable(v):return {k:x for k,x in v.items() if 'seconds' not in k and not k.startswith('time_')}
 assert stable(pair[0])==stable(pair[1])
out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(b/'availability-stage.json',out)
summary=[]
for row in out['rows']:
 if row['instrumented']:
  cs=row['calls'];summary.append(dict(root=row['root'],calls=len(cs),trials=sum(x['trials'] for x in cs),pre=sum(x['stage']=='pre-adjudication' for x in cs),other=sum(x['stage']!='pre-adjudication' for x in cs),repeated=sum(x['same_frame_repeat'] for x in cs),checked=sum(x['checked'] is True for x in cs),instrumented_seconds=sum(x['instrumented_seconds'] for x in cs)))
write_record(b/'availability-stage-summary.json',summary);print(summary)
