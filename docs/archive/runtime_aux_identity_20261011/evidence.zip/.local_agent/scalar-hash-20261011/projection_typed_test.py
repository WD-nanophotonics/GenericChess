import sys,importlib.util,time
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
b=Path('.local_agent/scalar-hash-20261011');spec=importlib.util.spec_from_file_location('pilot',b/'projection.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
p.m._semantic_component_diff_hash=p.candidate
import pytest
raise SystemExit(pytest.main(['tests/product/test_runtime_aux_identity.py','-q','-p','no:cacheprovider','--basetemp=.local_agent/pytest-runs/projection-typed-20261011']))
