"""Fixed-work exact-input prerecorded answer replay: optimistic cost ceiling only."""
import sys,time,json,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
b=Path('.local_agent/scalar-hash-20261011');spec=importlib.util.spec_from_file_location('weighted',Path('.local_agent/weighted-backend-20261011/bridge.py'));w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
original=SemanticEngine.has_legal_action;out=dict(scope='Optimistic prerecorded availability answer replay under identical512node work. Full actual input sequence audited after timed search; setup/list recording and checkpoint counts differ. Not an implementable cache, equal-time decision assay or cancellation guarantee.',rows=[],complete=False)
start=time.perf_counter()
for case in CASES:
 stopped();assert time.perf_counter()-start<180
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,c);e=w.weighted(c,VALUES[case['game']]);answers=[];inputs=[]
 def record(self,position,*a,**kw):
  answer=original(self,position,*a,**kw);answers.append(answer);inputs.append(position);return answer
 def run(fn):
  s=GameSession(c);s._state=board.initial;s._search_history_witnesses=board.witnesses;SemanticEngine.has_legal_action=fn
  try:
   t=time.perf_counter();d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=True).choose_action(s,SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8));return record_value(d),time.perf_counter()-t
  finally:SemanticEngine.has_legal_action=original
 declared,_=run(record)
 for order in range(2):
  pair=[]
  for replay in ((False,True) if order==0 else (True,False)):
   actual=[];cursor=[0]
   def oracle(self,position,*a,**kw):
    i=cursor[0];cursor[0]+=1;actual.append(position)
    checkpoint=kw.get('checkpoint')
    if checkpoint is not None:checkpoint()
    return answers[i]
   decision,elapsed=run(oracle if replay else original)
   if replay:assert cursor[0]==len(inputs) and actual==inputs
   def clean(v):return {k:x for k,x in v.items() if 'seconds' not in k and not k.startswith('time_')}
   assert clean(decision)==clean(declared)
   pair.append(elapsed);out['rows'].append(dict(root=case['id'],order=order,prerecorded=replay,seconds=elapsed,actual_availability_calls=len(inputs),decision=decision))
out['complete']=True;out['seconds']=time.perf_counter()-start;write_record(b/'availability-ceiling.json',out)
for case in CASES:
 rs=[r for r in out['rows'] if r['root']==case['id']];a=sum(r['seconds'] for r in rs if not r['prerecorded']);z=sum(r['seconds'] for r in rs if r['prerecorded']);print(case['id'],'ceiling cost ratio',z/a,'calls',rs[0]['actual_availability_calls'])
