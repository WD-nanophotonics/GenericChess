"""Rejected candidate: does pre-adjudication eager cache survive repetition?"""
import sys,json
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from conftest import king_type,make_ruleset,sq,T
from generic_chess import compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.movement import RayAtom
from generic_chess.core import search_runtime as m,terminal
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
b=Path('.local_agent/scalar-hash-20261011')
types=[king_type(),T('R',*(RayAtom(d) for d in ((1,0),(-1,0),(0,1),(0,-1))))]
c=compile_legacy_ruleset_for_semantic_execution(make_ruleset(4,types,lines=['...k','....','R...','K...'],repetition_limit=2))
s=GameSession(c)
cycle=((sq(0,1),sq(3,1)),(sq(3,3),sq(2,3)),(sq(3,1),sq(2,1)),(sq(2,3),sq(3,3)))
for source,target in cycle:
 s.submit(next(a for a in s.legal_actions() if a.from_square==source and a.to_square==target))
action=next(a for a in s.legal_actions() if a.from_square==sq(2,1) and a.to_square==sq(3,1))
p=NativeSemanticLegalityProvider.try_create(c,strict=True);assert p is not None
n=dict(terminal.__dict__);exec(compile((b/'checked_terminal_candidate.py').read_text(encoding='utf-8'),'private-candidate','exec'),n)
rows=[]
for name,fn in [('product',m.terminal_from_search_runtime),('rejected-candidate',n['terminal_from_search_runtime'])]:
 rt=m.SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=p)
 old=m.terminal_from_search_runtime;m.terminal_from_search_runtime=fn
 try:
  with rt.pushed(action):
   rows.append(dict(arm=name,status=rt.terminal_status.status.value,checked=rt._frames[-1].child_in_check,cached_before_query=None if rt._legal_cache is None else len(rt._legal_cache),returned_actions=len(rt.legal_actions()),native_calls=rt.legal_provider_calls))
 finally:m.terminal_from_search_runtime=old;rt.assert_balanced()
assert rows[0]['status']==rows[1]['status']=='repetition'
assert rows[0]['returned_actions']==0 and rows[1]['returned_actions']>0
(b/'checked-cache-history.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print(rows)
