import importlib.util,sys,time,json,hashlib
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path('.local_agent/scalar-hash-20261011')
spec=importlib.util.spec_from_file_location('pilot',B/'projection.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
from generic_chess.core.pieces import Piece
from generic_chess.core.search_runtime import SearchPathRuntime,_full_runtime_hash
from generic_chess.core.transition import legal_successors,apply_action
from generic_chess.core.actions import action_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from rule_semantics_ir_fixtures import weird_rulesets
from scripts.research_record import write_record,record_value
fixtures=weird_rulesets();rows=[[None]*8 for _ in range(8)]
for owner,tid,f,r in ((0,'K',4,0),(1,'K',7,7),(0,'R',0,0),(0,'R',0,1),(0,'R',0,2),(0,'R',1,1),(1,'R',1,3),(1,'R',1,4)):rows[r][f]=Piece(owner,tid,tid)
c=compile_ruleset_for_execution(replace(fixtures[2],initial_position=tuple(map(tuple,rows)),semantic_actions=(fixtures[1].semantic_actions[0],fixtures[2].semantic_actions[0]),drop_allowed={'R':((True,)*64,)*2,'TP':((False,)*64,)*2}))
route=(((1,1),(1,3),False),((7,7),(6,7),False),((1,3),(1,4),False),((6,7),(5,7),False),((0,0),(1,1),True),((5,7),(4,7),False),(None,(0,0),False),((4,7),(3,7),False))
s=GameSession(c);old=p.m._semantic_component_diff_hash;p.m._semantic_component_diff_hash=old
out=dict(rows=[],public_children=0,complete=False,scope='Existing concrete eight-ply recombined capture/promotion/expiry/guard/drop path; all legal children of nine actual parents')
t=time.perf_counter()
try:
 for ply in range(9):
  p.stopped();rt=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses);pairs=legal_successors(s.state,c);assert tuple(a for a,_ in pairs)==rt.legal_actions()
  for a,child in pairs:
   with rt.pushed(a):
    assert rt.position==child.position and rt.terminal_status==child.terminal_status
    assert rt.runtime_hash==_full_runtime_hash(rt.position,c)
   assert rt.position is s.state.position
   out['public_children']+=1
  rt.assert_balanced();drops=[a for a,_ in pairs if hasattr(a,'base_type_id')]
  if ply in (2,4,8):assert s.state.position.hands[0].count('R')>0 and not drops
  if ply==5:
   actor=s.state.position.board[9];assert (actor.base_type_id,actor.current_type_id,actor.promoted)==('R','TP',True);assert dict(s.state.position.aux_state)[(0,-1)]==1
  if ply==6:assert dict(s.state.position.aux_state)[(0,-1)]==0 and len(drops)==58
  out['rows'].append(dict(ply=ply,legal=len(pairs),drops=len(drops),hand=record_value(s.state.position.hands),aux=record_value(s.state.position.aux_state)))
  if ply==8:break
  source,target,semantic=route[ply]
  def selected(a):
   if (a.to_square.file,a.to_square.rank)!=target:return False
   if source is None:return hasattr(a,'base_type_id')
   return hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source and a.pattern_id.startswith('sem_')==semantic
  action,=[a for a,_ in pairs if selected(a)];out['rows'][-1]['selected']=action_to_dict(action);s.submit(action)
 out['complete']=True
finally:
 p.m._semantic_component_diff_hash=old;out['seconds']=time.perf_counter()-t;write_record(B/'installed-lifecycle.json',out)
print(json.dumps(out,indent=2))
