import sys,importlib.util,json
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path('.local_agent/scalar-hash-20261011')
spec=importlib.util.spec_from_file_location('pilot',B/'projection.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
from scripts.research_record import write_record
from generic_chess.core.search_runtime import SearchPathRuntime
class Cancel(RuntimeError):pass
out=dict(complete=False,rows=[],unreached=[]);old=p.m._semantic_component_diff_hash;p.m._semantic_component_diff_hash=p.candidate
try:
 for name,c,state,w in list(p.roots())[:8]:
  rt=SearchPathRuntime.from_state(state,c,history_witnesses=w);a=rt.legal_actions()[0];calls=[0]
  def count():calls[0]+=1
  with rt.pushed(a,checkpoint=count):pass
  probes=calls[0]
  for stop in range(1,probes+1):
   p.stopped();rt=SearchPathRuntime.from_state(state,c,history_witnesses=w);a=rt.legal_actions()[0];before=(rt.position,rt.runtime_hash,rt.search_key(),tuple(rt.history),rt.repetition_counts);seen=[0]
   def check():
    seen[0]+=1
    if seen[0]==stop:raise Cancel('declared checkpoint')
   try:
    rt.push(a,checkpoint=check);out['unreached'].append(dict(root=name,nominal_stop=stop,actual_callbacks=seen[0]));rt.pop()
   except Cancel:pass
   after=(rt.position,rt.runtime_hash,rt.search_key(),tuple(rt.history),rt.repetition_counts);assert before==after and rt.position is before[0];rt.assert_balanced()
  out['rows'].append(dict(root=name,checkpoint_probes=probes))
 out['complete']=True
finally:p.m._semantic_component_diff_hash=old;write_record(B/'projection-cancellation.json',out)
print(json.dumps(out))
