from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(P)]
import assessment as a
p=a.p
from scripts.research_record import record_value,write_record
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
plan=json.loads((P/"counterexample-plan.json").read_bytes());paid=json.loads((P/"counterexample-results.json").read_bytes());core=next(r["core"]for r in paid["rows"]if r["depth"]==10);assert core["completed_depth"]==8
write_record(P/"counterexample-binding-plan.json",dict(question="Bind normalNative to actual already-paid Core retainedD8, notunfinishedD10.",source_core_request=10,source_core_retained_depth=8,source_core_score=core["score"],tt=[0,16],depth=8,nodes=1000000,seconds=20,expected_seconds=3,scope="TwoNativequeries only, no newCore/noWDL/noD10completionclaim."))
d,c,s,nr=a.load(R/plan["case"]["root"]);profile=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in profile.board_value_by_type.items()};hv={k:int(round(v))for k,v in profile.hand_value_by_base_type.items()};rows=[];start=time.perf_counter()
for tt in[0,16]:
 p.stopped();t=time.perf_counter();n=p.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=tt,ordering_cache_enabled=False).search(s,p.SearchLimits(max_depth=8,max_nodes=1000000,max_time_seconds=20,quiescence_max_depth=0),root_window_pruning=True)
 norm=n.score if abs(n.score)<50000000 else(1 if n.score>0 else -1)*(1000000000-(100000000-abs(n.score)));row=dict(**plan["case"],tt=tt,depth=8,result=record_value(n),seconds=time.perf_counter()-t,joint_complete=n.completed_depth==8,score_equal=norm==core["score"]if n.completed_depth==8 else None,pv_edges=p.audit(s,nr,n));rows.append(row)
write_record(P/"counterexample-binding.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));assert all(not r["joint_complete"]or r["score_equal"]for r in rows);print("PAID_D8_BIND",[(r["tt"],r["result"]["completed_depth"],r["result"]["score"],r["score_equal"])for r in rows],time.perf_counter()-start,flush=True)
