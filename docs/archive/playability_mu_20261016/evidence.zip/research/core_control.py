from pathlib import Path
import sys,json,time,os
R=Path.cwd();P=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(P)]
import assessment as a
p=a.p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
class Material:
 def __init__(self,bv,hv):self.bv=bv;self.hv=hv
 def evaluate(self,s):
  side=s.position.side_to_move
  return sum((1 if x.owner==side else -1)*self.bv[x.current_type_id]for x in s.position.board if x is not None)+sum((1 if owner==side else -1)*self.hv[t]*n for owner,hand in enumerate(s.position.hands)for t,n in hand.items())
 def type_value(self,t):return self.bv[t]
 def capture_order_value(self,m,c):return 10*self.bv[c.current_type_id]-self.bv[m.current_type_id]
def main():
 plan=json.loads((P/"core-plan.json").read_bytes());start=time.perf_counter();rows=[]
 for case in plan["cases"]:
  p.stopped();d,c,s,nr=a.load(R/case["root"]);profile=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in profile.board_value_by_type.items()};hv={k:int(round(v))for k,v in profile.hand_value_by_base_type.items()};before=p.digest(s)
  for depth,seconds in[(2,2),(3,8)]:
   p.stopped()
   if time.perf_counter()-start>=plan["whole_seconds"]:rows.append(dict(**case,depth=depth,kind="WHOLE_CAP_NOT_STARTED_UNKNOWN"));continue
   t=time.perf_counter();r=AlphaBetaPlayer(c,evaluator_override=Material(bv,hv),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,p.SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0));ct=time.perf_counter()-t
   assert p.digest(s)==before
   t=time.perf_counter();n=p.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False).search(s,p.SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=seconds,quiescence_max_depth=0),root_window_pruning=True);nt=time.perf_counter()-t
   joint=r.completed_depth==n.completed_depth==depth;norm=n.score if abs(n.score)<50000000 else(1 if n.score>0 else -1)*(1000000000-(100000000-abs(n.score)))
   row=dict(**case,depth=depth,kind="ACTUAL_QUERY",core=record_value(r),native=record_value(n),core_seconds=ct,native_seconds=nt,joint_complete=joint,normalized_score_equal=r.score==norm if joint else None,root_restored=p.digest(s)==before,pv_edges=p.audit(s,nr,n));rows.append(row)
   with(P/"core-rows.jsonl").open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush();os.fsync(f.fileno())
   assert not joint or row["normalized_score_equal"],(case["seed"],depth,r.score,n.score)
   print("CORE_FINITE",case["seed"],depth,joint,r.completed_depth,n.completed_depth,round(ct,2),flush=True)
 write_record(P/"core-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("CORE_CLOSED",len(rows),sum(r.get("joint_complete",False)for r in rows),time.perf_counter()-start,flush=True)
if __name__=="__main__":main()
