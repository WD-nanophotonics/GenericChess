from pathlib import Path
import sys,json,time,random,os
R=Path.cwd();P=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(P)]
import assessment as a
import core_control as cc
p=a.p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
def main():
 plan=json.loads((P/"domain-plan.json").read_bytes());base=P/"domain";base.mkdir(exist_ok=False);(base/"inputs").mkdir();rows=[];start=time.perf_counter()
 for case in plan["cases"]:
  p.stopped()
  if time.perf_counter()-start>=600:rows.append(dict(**case,kind="WHOLE_CAP_NOT_STARTED_UNKNOWN"));continue
  t=time.perf_counter();cfg=GeneratorConfig(seed=case["seed"],board_size=case["board"],setup_preset=case["preset"],movement_symmetry=case["symmetry"],allow_hybrid=True,max_generation_attempts=32)
  try:g=generate_game(cfg)
  except Exception as exc:
   row=dict(**case,kind="GENERATION_FAILURE",error=type(exc).__name__+": "+str(exc),generation_seconds=time.perf_counter()-t);rows.append(row);print("DOMAIN_GEN_FAIL",case,str(exc)[:100],flush=True);continue
  generation_seconds=time.perf_counter()-t;ct=time.perf_counter();raw=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);semantic_compile_seconds=time.perf_counter()-ct;s=p.GameSession(c);rng=random.Random(case["seed"]+310000);walk=[];inputs=[]
  for ply in[0,8]:
   if ply==8:
    for step in range(8):
     p.stopped()
     if s.state.terminal_status.is_terminal:break
     actions=s.legal_actions()
     if not actions:break
     ac=rng.choice(sorted(actions,key=repr));walk.append(record_value(ac));s.submit(ac)
   root=dict(ply=ply,actual_ply=s.state.ply_count,game_record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state),walk=walk.copy(),before_sha256=p.digest(s));inputs.append(root)
   write_record(base/"inputs"/f"{case['seed']}.json",dict(**case,config=record_value(cfg),ruleset=json.loads(serialize_ruleset(g.ruleset)),generation_report=record_value(g.generation_report),roots=inputs))
   row=dict(**case,ply=ply,actual_ply=s.state.ply_count,generation_seconds=generation_seconds,semantic_compile_seconds=semantic_compile_seconds,input_file=f"domain/inputs/{case['seed']}.json",kind="ACTUAL_ROOT")
   if s.state.terminal_status.is_terminal or s.state.ply_count<ply:row["kind"]="TERMINAL_TAIL";rows.append(row);continue
   nt=time.perf_counter()
   try:nr=p.nc.compile_native_semantic_rules(c)
   except Exception as exc:
    row.update(kind="NATIVE_COMPILE_UNSUPPORTED_OR_FAILURE",error=type(exc).__name__+": "+str(exc));rows.append(row);continue
   row["native_compile_seconds"]=time.perf_counter()-nt;unit={k:0 if k=="K"else 100 for k in nr.type_ids}
   qt=time.perf_counter();goal=p.SemanticSearchEngine(c,nr,board_values=unit,hand_values=unit,tt_megabytes=0,ordering_cache_enabled=False).search(s,p.SearchLimits(max_depth=1,max_nodes=65536,max_time_seconds=.25,quiescence_max_depth=0),root_window_pruning=True,stop_on_immediate_win=True);row.update(goal=record_value(goal),goal_seconds=time.perf_counter()-qt,goal_pv_edges=p.audit(s,nr,goal))
   profile=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in profile.board_value_by_type.items()};hv={k:int(round(v))for k,v in profile.hand_value_by_base_type.items()};row.update(board_values=bv,hand_values=hv)
   qt=time.perf_counter();core=AlphaBetaPlayer(c,evaluator_override=cc.Material(bv,hv),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,p.SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));row.update(core=record_value(core),core_seconds=time.perf_counter()-qt)
   qt=time.perf_counter();native=p.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False).search(s,p.SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=0),root_window_pruning=True);row.update(native=record_value(native),native_seconds=time.perf_counter()-qt,native_pv_edges=p.audit(s,nr,native))
   joint=core.completed_depth==native.completed_depth==2;norm=native.score if abs(native.score)<50000000 else(1 if native.score>0 else -1)*(1000000000-(100000000-abs(native.score)));row.update(joint_complete=joint,normalized_score_equal=core.score==norm if joint else None,root_restored=p.digest(s)==root["before_sha256"]);rows.append(row)
   with(base/"rows.jsonl").open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush();os.fsync(f.fileno())
   assert row["root_restored"]and(not joint or row["normalized_score_equal"]),(case,ply)
  print("DOMAIN_FAMILY",case["preset"],case["symmetry"],case["board"],case["seed"],[(x["ply"],x["kind"],x.get("joint_complete"))for x in rows if x["seed"]==case["seed"]],flush=True)
 write_record(base/"results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("DOMAIN_CLOSED",len(rows),time.perf_counter()-start,flush=True)
if __name__=="__main__":main()
