from pathlib import Path
import sys,json,time,os
R=Path.cwd();P=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(P)]
import assessment as a
import core_control as cc
p=a.p
from scripts.research_record import record_value,write_record
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
plan=json.loads((P/"counterexample-plan.json").read_bytes());d,c,s,nr=a.load(R/plan["case"]["root"]);profile=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in profile.board_value_by_type.items()};hv={k:int(round(v))for k,v in profile.hand_value_by_base_type.items()};before=p.digest(s);rows=[];start=time.perf_counter()
for depth in plan["depths"]:
 p.stopped()
 if time.perf_counter()-start>=210:rows.append(dict(depth=depth,kind="WHOLE_CAP_NOT_STARTED_UNKNOWN"));continue
 t=time.perf_counter();core=AlphaBetaPlayer(c,evaluator_override=cc.Material(bv,hv),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,p.SearchLimits(max_depth=depth,max_nodes=1000000,max_time_seconds=60,quiescence_max_depth=0,quiescence_hard_max_depth=0));ct=time.perf_counter()-t
 row=dict(**plan["case"],depth=depth,core=record_value(core),core_seconds=ct,native_rows=[],kind="ACTUAL_QUERY")
 for tt in[0,16]:
  t=time.perf_counter();n=p.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=tt,ordering_cache_enabled=False).search(s,p.SearchLimits(max_depth=depth,max_nodes=1000000,max_time_seconds=20,quiescence_max_depth=0),root_window_pruning=True);nt=time.perf_counter()-t
  joint=core.completed_depth==n.completed_depth==depth;norm=n.score if abs(n.score)<50000000 else(1 if n.score>0 else -1)*(1000000000-(100000000-abs(n.score)))
  row["native_rows"].append(dict(tt=tt,result=record_value(n),native_seconds=nt,joint_complete=joint,score_equal=norm==core.score if joint else None,pv_edges=p.audit(s,nr,n)))
 row["root_restored"]=p.digest(s)==before;assert row["root_restored"];rows.append(row)
 write_record(P/"counterexample-results.json",dict(complete=False,rows=rows,seconds=time.perf_counter()-start))
 print("COUNTEREXAMPLE",depth,core.completed_depth,core.score,round(ct,2),[(x["tt"],x["result"]["completed_depth"],x["result"]["score"],x["score_equal"])for x in row["native_rows"]],flush=True)
write_record(P/"counterexample-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start))
assert all(not x["joint_complete"]or x["score_equal"]for row in rows for x in row.get("native_rows",[]))
print("COUNTEREXAMPLE_CLOSED",time.perf_counter()-start,flush=True)
