from pathlib import Path
import sys,json,time,os
R=Path.cwd();sys.path[:0]=[str(R),str(R/".local_agent/playability-mu-20261016")]
import assessment as a
p=a.p;P=a.P
from scripts.research_record import record_value,write_record
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
def main():
 plan=json.loads((P/"curve-plan.json").read_bytes());start=time.perf_counter();rows=[];prep=[];(P/"curve").mkdir(exist_ok=False)
 for ci,case in enumerate(plan["cases"]):
  p.stopped()
  if time.perf_counter()-start>=plan["whole_seconds"]:break
  t=time.perf_counter();d,c,s,nr=a.load(R/case["root"]);profile=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in profile.board_value_by_type.items()};hv={k:int(round(v))for k,v in profile.hand_value_by_base_type.items()};prep.append(dict(**case,setup_seconds=time.perf_counter()-t,board_values=bv,hand_values=hv))
  before=p.digest(s)
  for budget in plan["budgets"]:
   for q in([0,1]if(ci+plan["budgets"].index(budget))%2==0 else[1,0]):
    p.stopped();slot=dict(**case,seconds=budget,q=q)
    if time.perf_counter()-start>=plan["whole_seconds"]:rows.append(dict(**slot,kind="WHOLE_CAP_NOT_STARTED_UNKNOWN"));continue
    t=time.perf_counter();e=p.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=16,ordering_cache_enabled=False)
    allowance=budget-(time.perf_counter()-t)-plan["delivery_reserve"]
    if allowance<=0:row=dict(**slot,kind="CALLER_NO_ALLOWANCE_UNKNOWN",result=None,caller_seconds=time.perf_counter()-t,pv_edges=0)
    else:
     res=e.search(s,p.SearchLimits(max_depth=16,max_nodes=1000000,max_time_seconds=allowance,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True);seconds=time.perf_counter()-t
     row=dict(**slot,kind="ACTUAL_QUERY",result=record_value(res),caller_seconds=seconds,allowance=allowance,execution_allowed=res.action is not None and seconds<budget,overrun_seconds=max(0,seconds-budget),pv_edges=p.audit(s,nr,res),root_restored=p.digest(s)==before);assert row["root_restored"]
    rows.append(row)
    with(P/"curve/rows.jsonl").open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush();os.fsync(f.fileno())
    print("CURVE",case["seed"],budget,q,row["kind"],None if row["result"]is None else(row["result"]["completed_depth"],row["result"]["termination_reason"]),round(row["caller_seconds"],3),flush=True)
 write_record(P/"curve/results.json",dict(complete=True,rows=rows,preparations=prep,seconds=time.perf_counter()-start,planned_slots=plan["slots"],missing_slots=plan["slots"]-len(rows),scope=plan["scope"]));print("CURVE_CLOSED",len(rows),time.perf_counter()-start,flush=True)
if __name__=="__main__":main()
