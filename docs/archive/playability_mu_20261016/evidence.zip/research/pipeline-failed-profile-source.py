from pathlib import Path
import sys,time,json,random,hashlib,subprocess,os
R=Path.cwd();sys.path.insert(0,str(R));P=R/".local_agent/playability-mu-20261016"
from scripts.research_record import record_value,write_record
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.reserve_refresh_diagnostic import stopped
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action,expected_snapshot
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import position_identity_key
from generic_chess.ai.limits import SearchLimits
def digest(s):return hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest()
def audit(s,nr,res):
 state=s.state;np=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses);before=digest(s)
 assert res.action is None or res.action in s.legal_actions()
 for ac in res.principal_variation:
  np=sem.make_checked(nr,np,pack_semantic_action(nr,state.position,ac));state=apply_action(state,ac,s.compiled);w.append(state.position)
  snap=sem.snapshot(nr,np);want=expected_snapshot(state.position,nr,s.compiled)
  for k in["board","hands","aux_state","side"]:assert record_value(snap[k])==record_value(want[k])
  assert ["".join(f"{x:016x}"for x in h)for h in snap["history"]]==[str(position_identity_key(x,s.compiled))for x in w]
  assert snap["history_events"]==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
 assert digest(s)==before
 return len(res.principal_variation)
def child(board,arm):
 plan=json.loads((P/"plan.json").read_bytes());base=P/f"pipeline-{board}-{arm}";base.mkdir(exist_ok=False);(base/"roots").mkdir();start=time.perf_counter();rows=[];accepted=0;cap=plan["raw_candidate_slots"]if arm=="raw"else plan["conditional_candidate_cap"]
 for i in range(1,cap+1):
  stopped()
  if accepted>=plan["accepted_target_per_arm"]:break
  seed=20000+board*100+i;t=time.perf_counter();row=dict(board=board,arm=arm,index=i,seed=seed,accepted=False)
  if t-start>=plan["pipeline_cap_seconds"]:
   rows.append(dict(**row,kind="PIPELINE_CAP_UNKNOWN"));break
  try:
   cfg=GeneratorConfig(seed=seed,board_size=board,setup_preset="bilateral_random",allow_hybrid=True,max_generation_attempts=32);g=generate_game(cfg);row["generation_seconds"]=time.perf_counter()-t;row["generation_report"]=record_value(g.generation_report)
   ct=time.perf_counter();c0=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);row["semantic_compile_seconds"]=time.perf_counter()-ct
   s=GameSession(c);rng=random.Random(seed+210000);wt=time.perf_counter();walk=[]
   for step in range(8):
    stopped()
    if s.state.terminal_status.is_terminal:break
    actions=tuple(s.legal_actions())
    if not actions:break
    ac=rng.choice(sorted(actions,key=repr));walk.append(record_value(ac));s.submit(ac)
   row["walk_seconds"]=time.perf_counter()-wt;row["actual_ply"]=s.state.ply_count;row["root_terminal"]=record_value(s.state.terminal_status)
   d=dict(seed=seed,board=board,ruleset=json.loads(serialize_ruleset(g.ruleset)),game_record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state),walk=walk,before_sha256=digest(s),config=record_value(cfg))
   write_record(base/"roots"/f"{seed}.json",d);row["root_file"]=f"roots/{seed}.json"
   if s.state.terminal_status.is_terminal or len(walk)<8:row["kind"]="TERMINAL_TAIL"
   elif arm=="raw":row.update(kind="RAW_ROOT",accepted=True);accepted+=1
   else:
    nt=time.perf_counter();nr=nc.compile_native_semantic_rules(c);row["native_compile_seconds"]=time.perf_counter()-nt
    et=time.perf_counter();bv={x.type_id:0 if x.is_anchor else 100 for x in c.piece_types};hv={x.type_id:100 for x in c.piece_types if not x.is_anchor};e=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);row["engine_seconds"]=time.perf_counter()-et
    qt=time.perf_counter();res=e.search(s,SearchLimits(max_depth=1,max_nodes=65536,max_time_seconds=.25,quiescence_max_depth=0),root_window_pruning=True,stop_on_immediate_win=True);row["predicate_seconds"]=time.perf_counter()-qt
    kind="ONE_STEP_PHYSICAL_WIN"if res.immediate_win and res.result_source=="verified_root_child"else"NO_ONE_STEP_PHYSICAL_WIN"if res.completed_depth==1 else"UNKNOWN"
    row.update(kind=kind,predicate=record_value(res),pv_edges=audit(s,nr,res),accepted=kind=="NO_ONE_STEP_PHYSICAL_WIN")
    accepted+=int(row["accepted"])
   row["root_restored"]=digest(s)==d["before_sha256"];assert row["root_restored"]
  except Exception as exc:
   row.update(kind="ACTUAL_FAILURE",error=type(exc).__name__+": "+str(exc))
  row["candidate_seconds_before_record"]=time.perf_counter()-t;rows.append(row)
  with(base/"rows.jsonl").open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row,ensure_ascii=False)+"\n");f.flush();os.fsync(f.fileno())
  print("PIPELINE",board,arm,i,row["kind"],accepted,round(row["candidate_seconds_before_record"],3),flush=True)
 write_record(base/"result.json",dict(complete=True,board=board,arm=arm,rows=rows,accepted=accepted,missing_target=max(0,8-accepted),candidate_slots_not_started=list(range(len(rows)+1,cap+1)),seconds=time.perf_counter()-start,scope="Actual coldprocess acquisition; fullstates/rules/history retained. Conditionalmu excludes provenonephysicalstepwin/unknown/tail, not generalplayability/WDL. No productdefault change."))
def main():
 plan=json.loads((P/"plan.json").read_bytes());start=time.perf_counter();runs=[]
 assert not(P/"pipeline-results.json").exists()
 for board in plan["boards"]:
  for arm in(["raw","conditional"]if board in[4,12]else["conditional","raw"]):
   stopped();left=plan["whole_cap_seconds"]-(time.perf_counter()-start)
   if left<=0:runs.append(dict(board=board,arm=arm,kind="WHOLE_CAP_NOT_STARTED_UNKNOWN"));continue
   t=time.perf_counter();log=P/f"pipeline-{board}-{arm}-stdout-private.log"
   with log.open("wb")as f:
    try:r=subprocess.run([sys.executable,"-X","utf8",__file__,"child",str(board),arm],stdout=f,stderr=subprocess.STDOUT,timeout=min(left,plan["pipeline_cap_seconds"]+30));rc=r.returncode
    except subprocess.TimeoutExpired:rc=124
   runs.append(dict(board=board,arm=arm,returncode=rc,process_seconds=time.perf_counter()-t))
   print("PIPELINE_CLOSED",runs[-1],flush=True)
 write_record(P/"pipeline-results.json",dict(complete=True,runs=runs,seconds=time.perf_counter()-start))
if __name__=="__main__":
 if len(sys.argv)>1:child(int(sys.argv[2]),sys.argv[3])
 else:main()
