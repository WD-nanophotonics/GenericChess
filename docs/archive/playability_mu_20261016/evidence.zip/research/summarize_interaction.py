from pathlib import Path
import json,collections,random,statistics,time
P=Path(".local_agent/playability-mu-20261016");plan=json.loads((P/"interaction-plan.json").read_bytes());data=json.loads((P/"interaction/completion.json").read_bytes());assert data["complete"];games=data["games"];cases=plan["cases"];labels={};cost={c:dict(actual_games=0,actual_game_seconds=0,physical_edges=0,query_receipts=0)for c in"ABCD"};causes=collections.Counter()
def outcome(g,role):
 if g.get("kind")!="ACTUAL_GAME"or g["ending_cause"]!="ACTUAL_TERMINAL":return"UNKNOWN"
 t=g["terminal"];return"DRAW"if t["winner"]is None else"WIN"if t["winner"]==role else"LOSS"
for case in cases:
 seed=case["seed"]
 for cell in"ABCD":
  for role in[0,1]:
   mode="C_control"if cell=="C"else f"{cell}_role{role}";g=next(x for x in games if x["seed"]==seed and x["mode"]==mode);labels[seed,cell,role]=outcome(g,role)
for g in games:
 causes[g.get("ending_cause",g["kind"])]+=1
 if g["kind"]!="ACTUAL_GAME":continue
 c=g["mode"][0];v=cost[c];v["actual_games"]+=1;v["actual_game_seconds"]+=g["seconds"];v["physical_edges"]+=g["edges"];v["query_receipts"]+=g["query_receipts"]
counts={cell:dict(collections.Counter(labels[case["seed"],cell,r]for case in cases for r in[0,1]))for cell in"ABCD"}
def val(label):return 1 if label=="WIN"else -1 if label=="LOSS"else 0
family={case["seed"]:{cell:sum(val(labels[case["seed"],cell,r])for r in[0,1])for cell in"ABCD"}for case in cases}
rng=random.Random(36421);boot=[[rng.randrange(len(cases))for _ in cases]for _ in range(10000)]
def contrast(weights):
 vals=[sum(weights.get(c,0)*family[case["seed"]][c]for c in"ABCD")for case in cases];samples=sorted(sum(vals[i]for i in inds)/16 for inds in boot)
 return dict(raw_net_sum=sum(vals),planned_role_denominator=16,normalized=sum(vals)/16,family_bootstrap_interval=[samples[249],samples[9749]],family_nets=vals)
contrasts={name:contrast(w)for name,w in{"B_minus_A":{"B":1,"A":-1},"D_minus_C":{"D":1,"C":-1},"C_minus_A":{"C":1,"A":-1},"D_minus_B":{"D":1,"B":-1},"interaction_DminusC_minus_BminusA":{"D":1,"C":-1,"B":-1,"A":1}}.items()}
transitions={name:dict(collections.Counter(labels[ca["seed"],a,r]+"->"+labels[ca["seed"],b,r]for ca in cases for r in[0,1]))for name,a,b in[("A_to_B","A","B"),("C_to_D","C","D"),("A_to_C","A","C"),("B_to_D","B","D")]}
for c in"ABCD":
 cost[c]["mean_seconds_per_actual_game"]=cost[c]["actual_game_seconds"]/cost[c]["actual_games"]if cost[c]["actual_games"]else None
out=dict(complete=True,planned_families=8,planned_actor_slots=64,planned_games=56,actual_games=sum(v["actual_games"]for v in cost.values()),missing_planned_game_slots=sum(g["kind"]!="ACTUAL_GAME"for g in games),outcomes=counts,contrasts=contrasts,transitions=transitions,cost_by_game_arm=cost,total_seconds=data["seconds"],ending_causes=dict(causes),family_role_labels=[dict(seed=ca["seed"],board=ca["board"],cell=c,role=r,label=labels[ca["seed"],c,r])for ca in cases for c in"ABCD"for r in[0,1]],scope="Exploratorypairedfamilybootstrap10000(seed36421),8dependentfamilies,not64independentgames/populationclaim. UNKNOWNzeroONLYdeclaredfiniteW-L statistic, neverdraw/WDL. Ccontroloneactualgame yieldsbothroles; allgame/cost counts actual, no duplicatingcontrol. Costs include differentopponentpaths, notpurekernel/leafpricecausality. Valuation changesjointleaf/order/captureprices; nofit/training/qorprice/defaultadoption.")
(P/"interaction-summary.json").write_bytes((json.dumps(out,indent=2)+"\n").encode());print(json.dumps(out))
