from pathlib import Path
import sys,json,time,os
R=Path.cwd();P=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(P)]
import assessment as a
import core_control as cc
p=a.p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
plan=json.loads((P/"common-matrix-plan.json").read_bytes());rows=[];start=time.perf_counter()
for i,case in enumerate(plan["cases"]):
 p.stopped()
 if time.perf_counter()-start>=360:rows.append(dict(**case,kind="WHOLE_CAP_NOT_STARTED_UNKNOWN"));continue
 d,c,s,nr=a.load(P/case["root_file"]);before=p.digest(s);unit={t.type_id:0 if t.is_anchor else 100 for t in c.piece_types};assert set(unit)==set(nr.type_ids);values={"unit":(unit,unit),"static":(d["board_values"],d["hand_values"])};row=dict(**case,kind="ACTUAL_COMMON_MATRIX",native_rows=[],core_rows=[])
 cells=[("A","unit",0),("B","unit",1),("C","static",0),("D","static",1)]
 if i%2:cells.reverse()
 for cell,price,q in cells:
  p.stopped();bv,hv=values[price];t=time.perf_counter();n=p.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=16,ordering_cache_enabled=False).search(s,p.SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True)
  row["native_rows"].append(dict(cell=cell,price=price,q=q,result=record_value(n),seconds=time.perf_counter()-t,pv_edges=p.audit(s,nr,n)))
 for price in(["unit","static"]if i%2==0 else["static","unit"]):
  p.stopped();bv,hv=values[price];t=time.perf_counter();r=AlphaBetaPlayer(c,evaluator_override=cc.Material(bv,hv),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,p.SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));n=next(x["result"]for x in row["native_rows"]if x["price"]==price and x["q"]==0);joint=r.completed_depth==n["completed_depth"]==2;norm=n["score"]if abs(n["score"])<50000000 else(1 if n["score"]>0 else -1)*(1000000000-(100000000-abs(n["score"])))
  row["core_rows"].append(dict(price=price,result=record_value(r),seconds=time.perf_counter()-t,joint_complete=joint,normalized_score_equal=norm==r.score if joint else None))
 row["root_restored"]=p.digest(s)==before;rows.append(row);write_record(P/"common-matrix-results.json",dict(complete=False,rows=rows,seconds=time.perf_counter()-start));assert row["root_restored"]and all(not x["joint_complete"]or x["normalized_score_equal"]for x in row["core_rows"])
 print("COMMON_MATRIX",i,case["seed"],[(x["cell"],x["result"]["completed_depth"])for x in row["native_rows"]],[(x["price"],x["joint_complete"])for x in row["core_rows"]],flush=True)
write_record(P/"common-matrix-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("COMMON_MATRIX_CLOSED",len(rows),time.perf_counter()-start,flush=True)
