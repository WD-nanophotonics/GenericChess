from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/".local_agent/playability-mu-20261016";sys.path[:0]=[str(R),str(P)]
import assessment as a
p=a.p
from scripts.research_record import record_value,write_record
from generic_chess.session.serialization import serialize_game_record
plan=json.loads((P/"interaction-plan.json").read_bytes());completion=json.loads((P/"interaction/completion.json").read_bytes());assert completion["complete"]
base=P/"common-parents";base.mkdir(exist_ok=False);rows=[];start=time.perf_counter()
for case in plan["cases"]:
 for role in[0,1]:
  for label,left,right in[("price_q0","A","C"),("q_under_unit","B","A"),("q_under_static","D","C")]:
   def mode(c):return"C_control"if c=="C"else f"{c}_role{role}"
   lf=P/"interaction"/f"game-{case['seed']}-{mode(left)}.json";rf=P/"interaction"/f"game-{case['seed']}-{mode(right)}.json";row=dict(seed=case["seed"],board=case["board"],role=role,comparison=label,left=left,right=right,left_file=lf.relative_to(P).as_posix(),right_file=rf.relative_to(P).as_posix())
   if not lf.exists()or not rf.exists():row["kind"]="MISSING_GAME_UNKNOWN";rows.append(row);continue
   l=json.loads(lf.read_bytes());r=json.loads(rf.read_bytes());d,c,s,nr=a.load(P/"interaction/roots"/f"{case['seed']}.json");kind="SAME_SHARED_PREFIX"
   for i,(lr,rr)in enumerate(zip(l["rows"],r["rows"])):
    assert p.digest(s)==lr["before_sha256"]==rr["before_sha256"]
    if not lr["execution_allowed"]or not rr["execution_allowed"]:kind="EXECUTION_REFUSAL_AT_COMMON_PARENT";row["step"]=i;break
    if lr["action"]!=rr["action"]:
     kind="ACTOR_FIRST_DIFFERENCE"if s.state.position.side_to_move==role else"FIXED_OPPONENT_FIRST_DIFFERENCE";row["step"]=i
     root=dict(seed=case["seed"],ruleset=d["ruleset"],game_record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state),before_sha256=p.digest(s),board_values=d["board_values"],hand_values=d["hand_values"],provenance="Reconstructedfromactualstoredphysicalprefix, nothistoricalprequerysnapshot; exactbothbeforeSHA bindings checked.",left_source=dict(file=row["left_file"],step=i,before_sha256=lr["before_sha256"],result=lr["result"]),right_source=dict(file=row["right_file"],step=i,before_sha256=rr["before_sha256"],result=rr["result"]))
     path=base/f"{case['seed']}-role{role}-{label}.json";write_record(path,root);row.update(root_file=path.relative_to(P).as_posix(),before_sha256=p.digest(s),left_completed_depth=lr["result"]["completed_depth"],right_completed_depth=rr["result"]["completed_depth"]);break
    ac=next(x for x in s.legal_actions()if record_value(x)==lr["action"]);s.submit(ac)
   else:
    if len(l["rows"])!=len(r["rows"]):kind="UNEQUAL_LENGTH_AFTER_SHARED_PREFIX"
   row.update(kind=kind,shared_prefix_length=row.get("step",min(len(l["rows"]),len(r["rows"]))));rows.append(row)
write_record(P/"common-parent-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start,search_queries=0,scope="EXPOSED mechanicalcommonprefix capture after frozenfinitepanel, notfreshoutcomevalidation.48pairs dependon8families/sharedcontrol; rootrecords reconstructedfromexactstoredprefix/beforehash, notinventedhistoricalsnapshots. Actorfirstdifference vsfixedopponenttimedfirstdifference separated. No newsearch/game/model/adoption."))
print("COMMON_PARENTS_CLOSED",len(rows),{k:sum(r["kind"]==k for r in rows)for k in{r["kind"]for r in rows}},time.perf_counter()-start,flush=True)
