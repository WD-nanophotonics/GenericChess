from pathlib import Path
import sys,json,time,collections,hashlib
R=Path.cwd();sys.path.insert(0,str(R));P=R/".local_agent/playability-mu-20261016"
sys.path.insert(0,str(P/"corrected"));import pipeline as p
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.core.movegen import iter_legal_actions
from scripts.research_record import record_value,write_record
def load(root):
 d=json.loads(Path(root).read_bytes());c0=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d["ruleset"])));c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession.replay(c,deserialize_game_record(json.dumps(d["game_record"])));assert record_value(s.state)==d["state"] and p.digest(s)==d["before_sha256"];nr=p.nc.compile_native_semantic_rules(c);return d,c,s,nr
def main():
 plan=json.loads((P/"assessment-plan.json").read_bytes());rows=[];start=time.perf_counter()
 for case in plan["cases"]:
  p.stopped();d,c,s,nr=load(R/case["root"]);before=p.digest(s);bv={x:0 if x=="K"else100 for x in nr.type_ids};hv=dict(bv)
  t=time.perf_counter();e=p.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);res=e.search(s,p.SearchLimits(max_depth=1,max_nodes=65536,max_time_seconds=.25,quiescence_max_depth=0),root_window_pruning=True,stop_on_immediate_win=True);native_seconds=time.perf_counter()-t;pv=p.audit(s,nr,res)
  nk="ONE_STEP_PHYSICAL_WIN"if res.immediate_win and res.result_source=="verified_root_child"else"NO_ONE_STEP_PHYSICAL_WIN"if res.completed_depth==1 else"UNKNOWN"
  ct=time.perf_counter();observed=[];winning=None;complete=False;actor=s.state.position.side_to_move
  def check():
   if time.perf_counter()-ct>=1:raise TimeoutError("Frozen Corefrontier1s")
  try:
   for ac in iter_legal_actions(s.state,c,checkpoint=check):
    check();child=p.apply_action(s.state,ac,c);observed.append(dict(action=record_value(ac),child_terminal=record_value(child.terminal_status)))
    if child.terminal_status.is_terminal and child.terminal_status.winner==actor:winning=record_value(ac);break
   else:complete=True
  except TimeoutError:pass
  ck="ONE_STEP_PHYSICAL_WIN"if winning is not None else"NO_ONE_STEP_PHYSICAL_WIN"if complete else"UNKNOWN"
  assert nk==ck or"UNKNOWN"in(nk,ck)
  row=dict(**case,native_kind=nk,native=record_value(res),native_seconds=native_seconds,pv_edges=pv,core_kind=ck,core_complete=complete,core_winning_action=winning,core_rows=observed,core_seconds=time.perf_counter()-ct,root_restored=p.digest(s)==before);assert row["root_restored"];rows.append(row);print("CLASSIFY",case["seed"],nk,ck,len(observed),flush=True)
  with(P/"assessment-rows.jsonl").open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n")
 write_record(P/"assessment-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start))
if __name__=="__main__":main()
