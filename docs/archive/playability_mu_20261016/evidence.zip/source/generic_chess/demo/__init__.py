"""Headless demo (no UI)."""
