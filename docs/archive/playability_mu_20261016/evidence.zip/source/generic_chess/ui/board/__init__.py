"""QGraphicsView-based board rendering."""
