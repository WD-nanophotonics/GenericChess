"""Deterministic core game kernel."""
