"""Existing generator preference: paired cost/opportunity, never strength labels."""
from pathlib import Path
from collections import Counter
from dataclasses import asdict
import sys,time,json,random,hashlib,traceback,subprocess
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.transition import apply_action
D=R/'.local_agent/playability-filter-20261018';P=json.loads((D/'plan.json').read_bytes());start=time.monotonic();rows=[];points=[];status='COMPLETE';reason=None
assert not (D/'started.json').exists()
write_json(D/'started.json',dict(producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),base_sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()))
slots=[(seed,size,setup,sym) for seed in P['seeds'] for size in P['board_sizes'] for setup in P['setups'] for sym in P['symmetries']];assert len(slots)==P['planned_pairs'];random.Random(2026101802).shuffle(slots)
write_json(D/'slots.json',dict(pairs=slots))
def poll():
 if time.monotonic()-start>=P['limits']['global_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for name in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());assert not f.get('user_paused') and not f.get('stopped'),'EXPLICIT_STOP'
def digest(value):return hashlib.sha256(json.dumps(record_value(value),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def features(st,types):
 return tuple(sum((1 if pc.owner==0 else -1) for pc in st.position.board if pc and pc.current_type_id==t) for t in types)+tuple(st.position.hands[0].count(t)-st.position.hands[1].count(t) for t in types)
try:
 with (D/'generations.jsonl').open('x',encoding='utf-8') as jf,(D/'points.jsonl').open('x',encoding='utf-8') as pf:
  for slot,(seed,size,setup,sym) in enumerate(slots):
   for flag in (P['filter_flags'] if seed%2==0 else list(reversed(P['filter_flags']))):
    poll();key=f'{slot}-{int(flag)}';gstart=time.perf_counter();cfg=GeneratorConfig(seed=seed,board_size=size,setup_preset=setup,movement_symmetry=sym,allow_hybrid=P['allow_hybrid'],max_generation_attempts=P['max_generation_attempts'],require_no_opening_win_in_one=flag)
    row=dict(slot=slot,seed=seed,size=size,setup=setup,symmetry=sym,filter=flag,config=asdict(cfg),key=key,success=False)
    try:game=generate_game(cfg)
    except GenerationError as exc:
     row.update(generation_seconds=time.perf_counter()-gstart,error=str(exc),attempts=P['max_generation_attempts']);rows.append(row);jf.write(json.dumps(row,separators=(',',':'))+'\n');jf.flush();continue
    generation_seconds=time.perf_counter()-gstart;c=compile_legacy_ruleset_for_semantic_execution(game.ruleset);types=tuple(sorted(t.type_id for t in game.ruleset.piece_types if not t.is_anchor));s=GameSession(c);rng=random.Random(seed*1000+size);measured=time.perf_counter();localpoints=[]
    for target in P['prefixes']:
     poll()
     while s.state.ply_count<target and s.result.status.value=='ongoing':
      aa=sorted(s.legal_actions(),key=repr);assert aa;s.submit(aa[rng.randrange(len(aa))])
     before=(s.state,s.history,s._search_witnesses,s.to_record());aa=s.legal_actions() if s.result.status.value=='ongoing' else ();child_vectors=set();child_terminals=Counter();drop=promo=0;tick=time.perf_counter()
     for i,a in enumerate(aa):
      if i%16==0:poll()
      child=apply_action(s.state,a,c);child_vectors.add(features(child,types));child_terminals[str(child.terminal_status.winner) if child.terminal_status.is_terminal else 'ongoing']+=1
      drop+=getattr(a,'from_square',None) is None;promo+=getattr(a,'promotion_target_id',None) is not None
     assert before==(s.state,s.history,s._search_witnesses,s.to_record())
     point=dict(key=key,slot=slot,seed=seed,size=size,setup=setup,symmetry=sym,filter=flag,target_prefix=target,actual_prefix=s.state.ply_count,ongoing=s.result.status.value=='ongoing',result=record_value(s.result),root_state_sha256=digest(s.state),full_witnesses_sha256=digest(s._search_witnesses),record=json.loads(serialize_game_record(s.to_record())),material_nonzero=any(features(s.state,types)),legal_actions=len(aa),legal_drop_actions=drop,legal_promotion_actions=promo,distinct_child_material_vectors=len(child_vectors),material_choice_contrast=len(child_vectors)>=2,child_terminal_outcomes=dict(child_terminals),winning_first_action_count=child_terminals.get(str(s.state.position.side_to_move),0),probe_seconds=time.perf_counter()-tick)
     localpoints.append(point);points.append(point);pf.write(json.dumps(point,separators=(',',':'))+'\n');pf.flush()
    row.update(success=True,generation_seconds=generation_seconds,attempts=game.generation_report.generation_attempts,ruleset_fingerprint=c.ruleset_fingerprint,opening_legal_moves=game.generation_report.opening_legal_move_count,ordinary_types=len(types),promotable_types=sum(t.is_promotable for t in game.ruleset.piece_types),hybrid_types=sum(len({type(a).__name__ for a in t.movement_atoms})>1 for t in game.ruleset.piece_types),drop_mask_squares=sum(sum(m) for masks in game.ruleset.drop_allowed.values() for m in masks),diagnostic_seconds=time.perf_counter()-measured,rules=ruleset_to_dict(game.ruleset))
    rows.append(row);jf.write(json.dumps(row,separators=(',',':'))+'\n');jf.flush()
    if flag:
     opening=localpoints[0];assert opening['ongoing'] and opening['winning_first_action_count']==0,'FILTER_CORE_DISAGREEMENT'
    if len(rows)%16==0:print('GENERATED',len(rows),'points',len(points),'seconds',round(time.monotonic()-start,3),flush=True)
    if len(rows)==32:
     forecast=(time.monotonic()-start)/32*P['planned_generation_calls'];write_json(D/'cost-checkpoint.json',dict(calls=32,seconds=time.monotonic()-start,forecast_seconds=forecast,used_outcome_labels=False))
     if forecast>=7200:status='COST_FORECAST_REQUIRES_DOT';reason='Estimate>=120min; no unapproved long run';raise TimeoutError(reason)
    if jf.tell()+pf.tell()>P['limits']['max_output_bytes']:raise TimeoutError('FROZEN_OUTPUT_CAP')
except BaseException as exc:
 if status=='COMPLETE':status='STOPPED' if isinstance(exc,AssertionError) and str(exc)=='EXPLICIT_STOP' else 'PARTIAL_CAP' if isinstance(exc,TimeoutError) else 'ERROR'
 reason=repr(exc);traceback.print_exc()
result=dict(status=status,reason=reason,planned_calls=P['planned_generation_calls'],actual_calls=len(rows),missing_calls=P['planned_generation_calls']-len(rows),successful_generations=sum(r['success'] for r in rows),failed_generations=sum(not r['success'] for r in rows),points=len(points),seconds=time.monotonic()-start,scope='Paired finite intention-to-generate grid; samplerstream replacements not same-rule causal intervention. Actualfullstate/history/promotion/drop retained. Oneply material-choice contrast is structural availability, not actuallearninggain/strength/balance. Allrefusals/terminalprefixes/missing preserved; noextraattempt/seed/refit/default change.')
write_json(D/'result.json',result);print('CLOSED',json.dumps(result),flush=True)
