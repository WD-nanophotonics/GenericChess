"""Post-survey material opportunity projection, preserving terminal constants."""
from pathlib import Path
from collections import Counter
import json,sys,time,os
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import apply_action
D=R/'.local_agent/playability-filter-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));started=time.perf_counter();gg={g['key']:g for g in map(json.loads,(D/'generations.jsonl').read_bytes().splitlines())};cc={};rows=[];visits=0
assert not (D/'opportunity-result.json').exists()
write_json(D/'opportunity-plan.json',dict(question='Does raw child-material contrast overcount diagnostic availability when all relevant children are terminal or an immediate win dominates?',changed_premise='Survey raw nonzero material includes actualterminalstates; terminalconstants/zeroowngradient alreadyestablished inPRIMARY. Needseparateordinarychild featurecontrasts fromterminal andimmediate-winchoices before future sampling recommendation.',inputs='All4599savedpoints andtheircompletelegalchildren, no newgeneration/game/search/fit. No outcomes used tochangefiltergrid.',decision='Retain morelimitedoptional sampler recommendation if improved raw counts collapse after terminal/oneplywinning exclusions; opportunity remainsstructural not actualTDgradient/usefulness.',limits=dict(seconds=600,visits=1000000)))
def poll():
 assert time.perf_counter()-started<600 and visits<1000000,'FROZEN_OPPORTUNITY_CAP'
 for n in ('rollout','advisor','slack'):
  f=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not f.get('user_paused') and not f.get('stopped'),'EXPLICIT_STOP'
def phi(st,types):
 a=Counter()
 for pc in st.position.board:
  if pc:a['board',pc.current_type_id]+=1 if pc.owner==0 else -1
 for t in types:a['hand',t]=st.position.hands[0].count(t)-st.position.hands[1].count(t)
 return tuple(a[k,t] for k in ('board','hand') for t in types)
for line in (D/'points.jsonl').open(encoding='utf-8'):
 poll();z=json.loads(line);g=gg[z['key']];fp=g['ruleset_fingerprint']
 if fp not in cc:cc[fp]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))
 c=cc[fp];s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));types=tuple(sorted(t.type_id for t in c.piece_types if not t.is_anchor));ordinary=set();terminal=Counter();child_nonzero=0
 if z['ongoing']:
  for a in s.legal_actions():
   visits+=1;child=apply_action(s.state,a,c)
   if child.terminal_status.is_terminal:terminal[str(child.terminal_status.winner)]+=1
   else:v=phi(child,types);ordinary.add(v);child_nonzero+=any(v)
 ownwin=terminal.get(str(s.state.position.side_to_move),0)>0
 rows.append(dict(key=z['key'],slot=z['slot'],filter=z['filter'],target_prefix=z['target_prefix'],ongoing=z['ongoing'],ongoing_root_material_nonzero=z['ongoing']and any(phi(s.state,types)),ordinary_child_vectors=len(ordinary),ordinary_child_contrast=len(ordinary)>=2,ordinary_child_nonzero_count=child_nonzero,immediate_winning_child=ownwin,unforced_ordinary_material_contrast=z['ongoing']and not ownwin and len(ordinary)>=2,scope='Potential oneply materialdistinction only; deepersearch mayend interminalconstant andyieldzeroTDgradient. No actuallearningclaim.'))
write_json(D/'opportunity-result.json',dict(status='COMPLETE_TERMINAL_AWARE_OPPORTUNITY_PROJECTION',rows=rows,points=len(rows),core_children=visits,seconds=time.perf_counter()-started,scope='Posthocnewquestion onALLfrozenrecords; zero newfitness/generation/search. Terminalrules andhistory retained; rawmaterialfeatures neverzeroed, eligibility counters explicitlyconditional. No rootselection/capextension/default change.'))
for prefix in (0,4,16):
 print(prefix,[(flag,{k:sum(z[k]for z in rows if z['filter']==flag and z['target_prefix']==prefix)for k in ('ongoing_root_material_nonzero','ordinary_child_contrast','immediate_winning_child','unforced_ordinary_material_contrast')})for flag in (False,True)],flush=True)
