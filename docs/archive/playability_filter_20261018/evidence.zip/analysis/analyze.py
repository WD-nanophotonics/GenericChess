"""Paired finite sampler measures; successful opportunities per intended generation."""
from pathlib import Path
from collections import Counter,defaultdict
import json,sys,random,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/playability-filter-20261018';began=time.perf_counter();p=json.loads((D/'plan.json').read_bytes());done=json.loads((D/'result.json').read_bytes());gg=[json.loads(l)for l in(D/'generations.jsonl').read_bytes().splitlines()];pp=[json.loads(l)for l in(D/'points.jsonl').read_bytes().splitlines()];gens={(g['slot'],g['filter']):g for g in gg};points={(z['slot'],z['filter'],z['target_prefix']):z for z in pp};slots=json.loads((D/'slots.json').read_bytes())['pairs'];counts=Counter();paired=[]
for slot,(seed,size,setup,sym)in enumerate(slots):
 a=gens.get((slot,False));b=gens.get((slot,True))
 if a is None or b is None:counts['missing_pairs']+=1;continue
 counts['complete_pairs']+=1;counts['both_success']+=a['success']and b['success'];counts['only_default_success']+=a['success']and not b['success'];counts['only_filtered_success']+=b['success']and not a['success'];counts['both_failed']+=not a['success']and not b['success']
 if a['success']and b['success']:
  same=a['ruleset_fingerprint']==b['ruleset_fingerprint'];counts['same_rule_pairs']+=same;counts['replaced_rule_pairs']+=not same;opening=points[slot,False,0]
  assert same==(opening['winning_first_action_count']==0),'Deterministic filter/source mismatch'
  if same:
   for target in p['prefixes']:
    aa=points[slot,False,target];bb=points[slot,True,target]
    for key in ['root_state_sha256','full_witnesses_sha256','record','material_nonzero','material_choice_contrast','legal_actions','legal_drop_actions','legal_promotion_actions','distinct_child_material_vectors','child_terminal_outcomes']:
     assert aa[key]==bb[key],(slot,target,key)
  paired.append(dict(slot=slot,seed=seed,size=size,setup=setup,symmetry=sym,same_rule=same,default_attempts=a['attempts'],filtered_attempts=b['attempts']))
 # Filtered accepted rule is in default acceptance set on the same RNG stream.
 assert not (not a['success'] and b['success'])
summaries=[];differences=[]
for flag in p['filter_flags']:
 rows=[g for g in gg if g['filter']==flag]
 for target in p['prefixes']:
  zz=[z for z in pp if z['filter']==flag and z['target_prefix']==target]
  summaries.append(dict(filter=flag,prefix=target,intended=p['planned_pairs'],actual_generation_calls=len(rows),generation_successes=sum(g['success']for g in rows),generation_failures=sum(not g['success']for g in rows),ongoing=sum(z['ongoing']for z in zz),material_nonzero=sum(z['material_nonzero']for z in zz),material_choice_contrast=sum(z['ongoing']and z['material_choice_contrast']for z in zz),has_drop_action=sum(z['legal_drop_actions']>0 for z in zz),has_promotion_action=sum(z['legal_promotion_actions']>0 for z in zz),generation_seconds=sum(g['generation_seconds']for g in rows),diagnostic_seconds=sum(g.get('diagnostic_seconds',0)for g in rows)))
for target in p['prefixes']:
 for metric in ['ongoing','material_nonzero','material_choice_contrast']:
  values=[];bys={}
  for slot,(seed,size,setup,sym)in enumerate(slots):
   vals=[]
   for flag in (False,True):
    g=gens.get((slot,flag));point=points.get((slot,flag,target));vals.append(None if g is None else False if not g['success']else bool(point[metric]))
   lo=(0 if vals[1]is None else int(vals[1]))-(1 if vals[0]is None else int(vals[0]));hi=(1 if vals[1]is None else int(vals[1]))-(0 if vals[0]is None else int(vals[0]));values.append(dict(seed=seed,size=size,setup=setup,symmetry=sym,lower=lo,upper=hi));bys.setdefault(seed,[]).append((lo,hi))
  rng=random.Random(2026101804);boots=[]
  for _ in range(2000):
   vv=[x for _ in p['seeds']for x in bys[rng.choice(p['seeds'])]];boots.append([sum(x[j]for x in vv)/len(vv)for j in (0,1)])
  differences.append(dict(prefix=target,metric=metric,filtered_minus_default_bounds=[sum(v['lower']for v in values)/len(values),sum(v['upper']for v in values)/len(values)],fixed_grid_seed_block_95_envelope=[sorted(x[0]for x in boots)[49],sorted(x[1]for x in boots)[1949]],by_size={str(n):[sum(v[k]for v in values if v['size']==n)/sum(v['size']==n for v in values)for k in ('lower','upper')]for n in p['board_sizes']},by_setup={s:[sum(v[k]for v in values if v['setup']==s)/sum(v['setup']==s for v in values)for k in ('lower','upper')]for s in p['setups']},by_symmetry={s:[sum(v[k]for v in values if v['symmetry']==s)/sum(v['symmetry']==s for v in values)for k in ('lower','upper')]for s in p['symmetries']}))
r=dict(status='COMPLETE_FINITE_INTENTION_TO_GENERATE_ANALYSIS',generation_pair_counts=dict(counts),summary=summaries,paired_differences=differences,all_same_rule_full_states_equal=True,unchanged_rules_not_independent_new_samples=True,actual_generation_seconds=sum(g['generation_seconds']for g in gg),actual_diagnostic_seconds=sum(g.get('diagnostic_seconds',0)for g in gg),whole_recorded_seconds=done['seconds'],seconds=time.perf_counter()-began,scope='Missinggeneration property[0,1], observedboundedgeneration refusal yields0availablediagnostic opportunities (NOTgame draw). Terminalstates retained. Fixedcondition-grid seedblockresampling retains all12conditions/flags perseed; descriptive NOTpopulationconfidence. Extra filtering replacesrulemeasure; samefingerprints haveidenticalfullrecords/witnesses/materialcontrast. Generationclock includesfilter; semanticcompile/JSON/engineering costs notin percase sum, wholeproducer islarger. ConcurrentCPUload precludes causal timing/speedup or learning/balance claims.')
write_json(D/'analysis.json',r);print(json.dumps(counts));print('generationseconds',[(x['filter'],x['generation_seconds'])for x in summaries if x['prefix']==0])
for x in differences:print(x['prefix'],x['metric'],x['filtered_minus_default_bounds'],x['fixed_grid_seed_block_95_envelope'])
