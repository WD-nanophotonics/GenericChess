"""Independent full-record reconstruction of the finite generator survey."""
from pathlib import Path
from collections import Counter
import json,sys,time,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import apply_action
D=R/'.local_agent/playability-filter-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));started=time.perf_counter();generations={g['key']:g for g in map(json.loads,(D/'generations.jsonl').read_bytes().splitlines())};compiled={};counts=Counter()
def poll():
 assert time.perf_counter()-started<600,'FROZEN_REPLAY_CAP'
 for n in ('rollout','advisor','slack'):
  f=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not f.get('user_paused') and not f.get('stopped'),'EXPLICIT_STOP'
def digest(x):return hashlib.sha256(json.dumps(record_value(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def phi(st,types):
 b=Counter()
 for pc in st.position.board:
  if pc:b['board',pc.current_type_id]+=(-1 if pc.owner else 1)
 for t in types:b['hand',t]=st.position.hands[0].count(t)-st.position.hands[1].count(t)
 return tuple(b[k,t] for k in ('board','hand') for t in types)
for line in (D/'points.jsonl').open(encoding='utf-8'):
 poll();z=json.loads(line);g=generations[z['key']];assert g['success'];fp=g['ruleset_fingerprint']
 if fp not in compiled:compiled[fp]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))
 c=compiled[fp];assert c.ruleset_fingerprint==fp;types=tuple(sorted(t.type_id for t in c.piece_types if not t.is_anchor));s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));assert digest(s.state)==z['root_state_sha256'] and digest(s._search_witnesses)==z['full_witnesses_sha256'];assert s.state.ply_count==z['actual_prefix'];assert record_value(s.result)==z['result'];assert any(phi(s.state,types))==z['material_nonzero'];assert (s.result.status.value=='ongoing')==z['ongoing'];aa=s.legal_actions() if z['ongoing'] else ();assert len(aa)==z['legal_actions'];vectors=set();terms=Counter()
 for a in aa:
  child=apply_action(s.state,a,c);vectors.add(phi(child,types));terms[str(child.terminal_status.winner) if child.terminal_status.is_terminal else 'ongoing']+=1;counts['legal_child_transitions']+=1
 assert len(vectors)==z['distinct_child_material_vectors'] and (len(vectors)>1)==z['material_choice_contrast'];assert dict(terms)==z['child_terminal_outcomes'];assert terms.get(str(s.state.position.side_to_move),0)==z['winning_first_action_count'];assert sum(getattr(a,'from_square',None) is None for a in aa)==z['legal_drop_actions'];assert sum(getattr(a,'promotion_target_id',None) is not None for a in aa)==z['legal_promotion_actions'];counts['full_records']+=1;counts['recorded_plies']+=len(s.to_record().actions)
 if counts['full_records']%128==0:print('REPLAYED',counts['full_records'],round(time.perf_counter()-started,3),flush=True)
done=json.loads((D/'result.json').read_bytes());assert counts['full_records']==done['points'];q=dict(status='PASS_ALL_SAVED_SURVEY_RECORDS_AND_CHILD_FEATURES',counts=dict(counts),unique_rules=len(compiled),seconds=time.perf_counter()-started,scope='Full Core record replay/hash/result/history plus independent Counter material-vector recomputation for ALL legalchildren. Same Core semantics, not an independentrulesimplementation or learning/strength evidence. No generation/fitness repeated, no missing rows fabricated.');write_json(D/'reader-result.json',q);print(q,flush=True)
