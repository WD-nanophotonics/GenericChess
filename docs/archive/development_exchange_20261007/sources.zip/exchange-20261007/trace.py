"""Frequency/scope of the fixed approximation in actual played states; no strength inference."""
import sys,json,hashlib,ast
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
p=Path(__file__).parent;cohort=sys.argv[1];out=p/(cohort+'-trace.json');assert not out.exists()
raw=(p/(cohort+'.json')).read_bytes();v=json.loads(raw);assert v['complete']
# Reuse the exact qualified independent geometry function, without rerunning its producer.
source=(p/'features.py').read_bytes();tree=ast.parse(source);fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='features');from types import SimpleNamespace;tables=d.material_tables();scope={'chess':chess,'d':SimpleNamespace(material_tables=lambda:tables)};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(p/'features.py'),'exec'),scope);features=scope['features']
report=dict(complete=False,source_sha256=hashlib.sha256(raw).hexdigest(),geometry_source_sha256=hashlib.sha256(source).hexdigest(),scope='All actual root and chosen-child pseudo hanging inventory. Frequency and approximation influence only, not counterfactual strength or probability. Top absolute immediate changes illustrate scope, never tune coefficients.',games=[])
for i,g in enumerate(v['games']):
 b=chess.Board(g['initial_fen'])
 for move in g['opening_uci']:b.push_uci(move)
 rows=[]
 for r in g['moves']:
  before=features(b,g['table']);b.push_uci(r['move']);after=features(b,g['table'])
  rows.append(dict(ply=r['ply'],side=r['side'],move=r['move'],root_half=before['correction_white_native'],root_loss_white=before['loss_white'],root_loss_black=before['loss_black'],child_half=after['correction_white_native'],child_loss_white=after['loss_white'],child_loss_black=after['loss_black'],delta_half=after['correction_white_native']-before['correction_white_native']))
 report['games'].append(dict(index=i,id=g['id'],table=g['table'],exchange_color=g['exchange_color'],moves=len(rows),root_any_hanging=sum(bool(x['root_loss_white'] or x['root_loss_black']) for x in rows),root_nonzero_half=sum(bool(x['root_half']) for x in rows),mean_absolute_half=sum(abs(x['root_half']) for x in rows)/len(rows),top_immediate_changes=sorted(rows,key=lambda x:abs(x['delta_half']),reverse=True)[:3],rows=rows))
report['complete']=True;d.write_record(out,report,indent=None)
print(cohort,'root hanging',sum(g['root_any_hanging'] for g in report['games']),'/',sum(g['moves'] for g in report['games']),flush=True)
