"""Native old half-risk approximation: independent geometry and semantic queries."""
import sys,json,hashlib,re,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
from scripts.chess_capture_risk import SemanticHangingRisk
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
p=Path(__file__).parent;out=p/'features.json';assert not out.exists()
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=ROOT/'.local_agent/royal-20261007/features.json';old=json.loads(source.read_bytes());roots=json.loads((ROOT/'.local_agent/classical-control-20261007/direct-roots.json').read_bytes())['rows']
positions=[(chess.STARTING_FEN,policy,None) for policy in d.POLICIES]+[(r['fen'],roots[r['root']]['policy'],r['history_prefix']) for r in old['rows']]
fixtures=['7k/8/8/4r3/3P4/8/8/K7 b - - 0 1','4k3/8/4n3/8/3Q4/8/8/K3R3 w - - 0 1','7k/8/8/3pP3/8/8/8/K7 w - d6 0 1']
positions += [(fen,policy,None) for fen in fixtures for policy in d.POLICIES]
def features(b,policy):
 coverage={color:set().union(*(set(b.attacks(sq)) for sq,pc in b.piece_map().items() if pc.color==color and pc.piece_type!=chess.KING)) for color in chess.COLORS}
 attacked={color:set().union(*(set(b.attacks(sq)) for sq,pc in b.piece_map().items() if pc.color==color)) for color in chess.COLORS};weights=d.material_tables()[policy];loss={color:0 for color in chess.COLORS};exposed=[]
 for sq,pc in b.piece_map().items():
  if pc.piece_type!=chess.KING and sq in attacked[not pc.color] and sq not in attacked[pc.color]:loss[pc.color]+=weights[pc.symbol().upper()];exposed.append((sq,0 if pc.color else 1,pc.symbol().upper()))
 delta=loss[False]-loss[True];correction=(abs(delta)//2)*(1 if delta>=0 else -1)
 material=sum((1 if pc.color else -1)*weights.get(pc.symbol().upper(),0) for pc in b.piece_map().values())
 return dict(coverage_white=len(coverage[True]),coverage_black=len(coverage[False]),loss_white=loss[True],loss_black=loss[False],exposed=sorted(exposed),correction_white_native=correction,evaluation_white_native=material+4*(len(coverage[True])-len(coverage[False]))+correction)
report=dict(complete=False,source_sha256=sha(source),declaration=json.loads((p/'declaration.json').read_bytes()),semantic=[],native=[],scope='Independent PythonChess geometry, current Core full legality and old native semantic pseudo-risk exposed-piece identity. Pins/King safety/EP remain approximation limits, not legal exchange proof.')
for fen,policy,prefix in positions:
 b=chess.Board(fen);state=d.root_from_fen(fen,c) if prefix is None else d.replay_prefix(chess.STARTING_FEN,c,prefix)[0];before=d.record_value(state);assert {d.uci(a) for a in d.iter_legal_actions(state,c)}=={m.uci() for m in b.legal_moves}
 f=features(b,policy);risk=SemanticHangingRisk(d.evaluator(policy),provider);t=risk.terms(state);assert d.record_value(state)==before
 assert f['exposed']==sorted((r['square'],r['owner'],r['type_id']) for r in t['exposed'])
 report['semantic'].append(dict(fen=fen,policy=policy,geometry=f,semantic_queries=risk.queries))
 for mirror in (False,True):
  original=b.mirror() if mirror else b
  for turn in chess.COLORS:
   board=original.copy();board.turn=turn
   if board.is_check():continue
   f=features(board,policy);expected=f['evaluation_white_native']/208
   command=f'uci\nsetoption name UCI_Variant value gc_{policy}\nsetoption name Use NNUE value false\nisready\nposition fen {board.fen(en_passant="fen")}\neval\nquit\n'
   r=subprocess.run([str(p/'fairy-exchange.exe'),'load',str(ROOT/'.local_agent/mature-search/material-variants.ini')],input=command,text=True,capture_output=True,timeout=15);m=re.search(r'Final evaluation\s+([+-]?[0-9.]+)',r.stdout);observed=float(m.group(1)) if m else None
   report['native'].append(dict(fen=board.fen(en_passant='fen'),policy=policy,mirror=mirror,expected_white_pawn=expected,observed_white_pawn=observed,geometry=f,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));d.write_record(out,report,indent=None)
   assert r.returncode==0 and observed is not None and abs(expected-observed)<=.0101
report['complete']=True;d.write_record(out,report);print('semantic',len(report['semantic']),'native',len(report['native']),'zero differences',flush=True)
