"""Single declared nonroyal attack-union pilot, isolated from pure binary."""
import sys,os,json,time,hashlib,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];p=ROOT/'.local_agent/mature-search'
src=p/'Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d/src'
out=ROOT/'.local_agent/exchange-20261007';out.mkdir(exist_ok=True)
assert not (out/'declaration.json').exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
decl=dict(question='Can old fixed half hanging-risk approximation work better at native bitboard cost?',
 scope='StandardChess only: own piece attacked by enemy pseudo union, not own pseudo union; includes King attacks in attack/defense, excludes Kings from discounted inventory. Pins, illegal King captures, EP off-target victim, exchanges and postconditions not modeled. No turn/history rewrite.',
 term='Material+4nonroyal union delta+(hangingBlack-hangingWhite)/2, symmetric integer truncation. Prices from unchanged gc tables; half is old independently declared SemanticHangingRisk hypothesis, not fitted probability or rule-unique context law. Native implementation changes cost premise, not refits exposed labels.',
 decision='Before outcomes declare all36activity/classical/reference cells; retain all loss/unfinished/failure evidence. No coefficient sweep, human prices fitting, default promotion, Elo or generic-strength claim.',
 unchanged='Original search objects/SEE/pruning/NNUEfalse, SinglePV1 Threads1 Hash16. Activity cost shifts reachable nodes; report actual resource usage.',
 cost='One compile object,28reused unchanged; small static and actual-root controls, then bounded sequential36streams under existing1sec conditions. Interruptible on user stop; no extra model/worker.',
 pure_binary_sha256=sha(p/'build/fairy-material.exe'),source_eval_sha256=sha(src/'evaluate.cpp'))
(out/'declaration.json').write_text(json.dumps(decl,indent=2))
s=(src/'evaluate.cpp').read_text();needle='  if (pos.side_to_move() == BLACK) material = -material;'
assert s.count(needle)==1
code='''  // Old untuned half hanging-risk approximation, native bitboard implementation.
  Bitboard covered[COLOR_NB] = {};
  for (Color c : {WHITE, BLACK})
      for (PieceType pt : {PAWN, KNIGHT, BISHOP, ROOK, QUEEN})
      {
          Bitboard b = pos.pieces(c, pt);
          while (b) covered[c] |= pos.attacks_from(c, pt, pop_lsb(b));
      }
  material += 4 * (popcount(covered[WHITE]) - popcount(covered[BLACK]));
  Bitboard attacked[COLOR_NB] = {covered[WHITE], covered[BLACK]};
  for (Color c : {WHITE, BLACK})
  {
      Bitboard b = pos.pieces(c, KING);
      while (b) attacked[c] |= pos.attacks_from(c, KING, pop_lsb(b));
  }
  int hanging[COLOR_NB] = {};
  for (Color c : {WHITE, BLACK})
      for (PieceType pt : {PAWN, KNIGHT, BISHOP, ROOK, QUEEN})
          hanging[c] += EvalPieceValue[MG][pt] * popcount(pos.pieces(c, pt) & attacked[~c] & ~attacked[c]);
  material += (hanging[BLACK] - hanging[WHITE]) / 2;
'''
new=s.replace(needle,code+needle).replace('material leaf without positional terms.','material leaf plus declared nonroyal attack-union and pseudo hanging-risk pilot.')
copy=out/'evaluate-exchange.cpp';copy.write_text(new)
(out/'exchange.patch').write_text(__import__('difflib').unified_diff(s.splitlines(True),new.splitlines(True),fromfile='evaluate-pure.cpp',tofile='evaluate-exchange.cpp').__iter__().__next__() if False else ''.join(__import__('difflib').unified_diff(s.splitlines(True),new.splitlines(True),fromfile='evaluate-pure.cpp',tofile='evaluate-exchange.cpp')))
base=[sys.executable,'-m','ziglang','c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-fno-exceptions','-fno-strict-aliasing','-DNDEBUG','-DIS_64BIT','-DNNUE_EMBEDDING_OFF','-DGENERICCHESS_MATERIAL_DEVELOPMENT']
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(p/'zig-global-cache'),ZIG_LOCAL_CACHE_DIR=str(p/'zig-local-cache'))
report=dict(declaration=decl,commands=[],complete=False);start=time.perf_counter()
obj=out/'evaluate.cpp.o';commands=[base+['-I',str(src),'-c',str(copy),'-o',str(obj)]]
sources=json.loads((p/'build-report.json').read_bytes())['sources']
binary=out/'fairy-exchange.exe'
commands.append(base+[str(obj if f=='evaluate.cpp' else p/'build'/(f.replace('/','_')+'.o')) for f in sources]+['-o',str(binary),'-lpthread','-ladvapi32','-Wl,--stack,8388608'])
report['reused_objects']={f:sha(p/'build'/(f.replace('/','_')+'.o')) for f in sources if f!='evaluate.cpp'}
for cmd in commands:
 r=subprocess.run(cmd,cwd=src,env=env,capture_output=True,text=True,timeout=120)
 report['commands'].append(dict(command=cmd,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
 (out/'build.json').write_text(json.dumps(report,indent=2));print('command',r.returncode,flush=True)
 if r.returncode:break
else:report.update(complete=True,binary_sha256=sha(binary))
report['wall_seconds']=time.perf_counter()-start
assert sha(p/'build/fairy-material.exe')==decl['pure_binary_sha256'];assert sha(src/'evaluate.cpp')==decl['source_eval_sha256']
(out/'build.json').write_text(json.dumps(report,indent=2));print(report['complete'],report['wall_seconds'],flush=True)
