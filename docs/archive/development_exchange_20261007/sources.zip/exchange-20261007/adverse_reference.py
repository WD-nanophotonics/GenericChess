"""Finite independent child reference for changed known failure, not all-defense safety."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;source=p/'adverse.json';raw=source.read_bytes();x=json.loads(raw);assert x['complete'];out=p/'adverse-reference.json';assert not out.exists()
ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe';decl=json.loads((p/'game-declaration.json').read_bytes());assert hashlib.sha256(ref.read_bytes()).hexdigest()==decl['reference_sha256']
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());state,_=d.replay_prefix(chess.STARTING_FEN,c,x['history_prefix']);b=chess.Board(chess.STARTING_FEN)
for m in x['history_prefix']:b.push_uci(m)
assert b.fen(en_passant='fen')==x['fen'];legal={d.uci(a):a for a in d.iter_legal_actions(state,c)};assert set(legal)=={m.uci() for m in b.legal_moves}
report=dict(complete=False,question='Does the new c6c5 choice avoid the finite mate reference retained for old g6g5?',declaration='Two already exposed legal children c6c5/g6g5, same full history, fresh full-strength Stockfish500000nodes/1sec Threads1 Hash16 each. <=2referencefuse seconds plus replay; sequential after games. cp/mate separated, finite diagnostic not all-defense proof or price fitting.',source_sha256=hashlib.sha256(raw).hexdigest(),fen=x['fen'],history_prefix=x['history_prefix'],rows=[])
d.write_record(out,report)
for move in ('c6c5','g6g5'):
 for name in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused')
 child=b.copy(stack=True);assert move in legal;child.push_uci(move);core=d.apply_action(state,legal[move],c);assert {d.uci(a) for a in d.iter_legal_actions(core,c)}=={m.uci() for m in child.legal_moves}
 with chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as e:
  e.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False});t=time.perf_counter();info=e.analyse(child,chess.engine.Limit(nodes=500000,time=1),game=object());score=info['score'].pov(b.turn);pv=[m.uci() for m in info.get('pv',())];check=child.copy(stack=True)
  for m in pv:check.push_uci(m)
  row=dict(move=move,cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),wall_seconds=time.perf_counter()-t,pv=pv);report['rows'].append(row);d.write_record(out,report);print(row,flush=True)
report['complete']=True;d.write_record(out,report)
