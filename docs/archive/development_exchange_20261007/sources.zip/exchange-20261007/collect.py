"""Complete portable native-risk pilot evidence, no default or public promotion."""
import sys,json,hashlib,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/development_exchange_20261007';out=ROOT/'docs/research/data/chess_exchange_20261007.json';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def norm(x):
 if isinstance(x,str):return x.replace(str(ROOT),'{PROJECT_ROOT}').replace(ROOT.as_posix(),'{PROJECT_ROOT}')
 if isinstance(x,list):return [norm(v) for v in x]
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
 return x
files=[]
for name in ('build','features-failed-root-import'):
 raw=(p/(name+'.json')).read_bytes();v=json.loads(raw)
 if name=='build':assert v['complete']
 target=p/(name+'-portable.json');write_record(target,dict(original_local_sha256=sha(raw),normalization='Project absolute paths replaced with {PROJECT_ROOT}; original local report retained.',report=norm(v)));files.append(target)
files.extend(p/n for n in ('declaration.json','game-declaration.json','features.json','root-inspection.json','roots-declaration.json','roots.json','adverse.json','adverse-reference.json','analysis-cost-note.json','coupling-audit.json'))
groups={}
for cohort in ('direct','classical','reference'):
 v=json.loads((p/(cohort+'.json')).read_bytes());r=json.loads((p/(cohort+'-replay.json')).read_bytes());trace=json.loads((p/(cohort+'-trace.json')).read_bytes())
 assert v['complete'] and r['complete'] and trace['complete'] and len(r['games'])==12 and not r['errors']
 methods={}
 for g in r['games']:
  z=methods.setdefault(g['table'],dict(wins=0,losses=0,draws=0,unfinished=0));key='unfinished' if not g['finished'] else 'draws' if g['winner'] is None else 'wins' if g['winner']==g['exchange_color'] else 'losses';z[key]+=1
 groups[cohort]=dict(methods=methods,cells=r['games'],wall_seconds=v['wall_seconds'],recording_cost_before_final_save=v['recording_cost'],replay=dict(streams=12,played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0),approximation_frequency=dict(roots=sum(g['moves'] for g in trace['games']),any_hanging=sum(g['root_any_hanging'] for g in trace['games']),nonzero_half=sum(g['root_nonzero_half'] for g in trace['games'])))
 files.extend(p/n for n in (cohort+'.json',cohort+'-replay.json',cohort+'-trace.json'))
v=json.loads((p/'roots.json').read_bytes());assert v['complete'] and len(v['rows'])==8
contrast=dict(same=0,finite_better=0,finite_worse=0,finite_equal=0,mate=[])
for r in v['rows']:
 m={x['mode']:x['move'] for x in r['choices']};left,right=m['exchange'],m['activity']
 if left==right:contrast['same']+=1;continue
 x,y=r['references'][left],r['references'][right]
 if x['cp'] is None or y['cp'] is None:contrast['mate'].append(dict(game=r['game'],threshold=r['threshold'],side=r['side'],left_move=left,right_move=right,left=x,right=y));continue
 delta=x['cp']-y['cp'];contrast['finite_better' if delta>0 else 'finite_worse' if delta<0 else 'finite_equal']+=1
features=json.loads((p/'features.json').read_bytes());assert features['complete'] and len(features['semantic'])==37 and len(features['native'])==144
adverse=json.loads((p/'adverse.json').read_bytes());assert adverse['complete']
a.mkdir(exist_ok=True);entries={};sources={}
def archive(path,items,target):
 if path.exists():
  with zipfile.ZipFile(path) as z:
   assert z.testzip() is None and set(z.namelist())=={n for _,n in items}
   for f,n in items:
    b=f.read_bytes();assert z.read(n)==b;target[n]=dict(bytes=len(b),sha256=sha(b))
  return
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in items:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b);z.writestr(n,b);target[n]=dict(bytes=len(b),sha256=sha(b))
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and set(z.namelist())==set(target)
  for n,h in target.items():assert sha(z.read(n))==h['sha256']
archive(a/'raw.zip',[(f,f.name) for f in files],entries)
names=('build.py','features.py','games.py','replay.py','roots.py','adverse.py','adverse_reference.py','trace.py','collect.py','features-failed-root-import.py.txt','trace-pre-cache.py.txt','collect-failed.py.txt')
upstream=ROOT/'.local_agent/mature-search/Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d'
archive(a/'sources.zip',[(p/n,'exchange-20261007/'+n) for n in names]+[(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(ROOT/'scripts/chess_capture_risk.py','shared-chess_capture_risk.py'),(ROOT/'scripts/research_record.py','shared-research_record.py'),(p/'evaluate-exchange.cpp','evaluate-exchange.cpp'),(p/'exchange.patch','exchange.patch'),(upstream/'src/evaluate.cpp','pinned-evaluate.cpp'),(upstream/'Copying.txt','upstream-Copying.txt'),(ROOT/'.local_agent/mature-search/material-variants.ini','material-variants.ini'),(ROOT/'.local_agent/mature-openings/suite.json','suite.json')],sources)
summary=dict(scope='StandardChess exposed development; old fixed half pseudo hanging-risk at native bitboard cost. No coefficient/price fitting, default/Elo/holdout/generic-strength claim. Pins, King safety, EP/off-target and exchange-chain limitations remain.',source_pin='9f778da667f6e07dae1e85d3e2ea204fc6dee94d',parent_sha='607c7047ea000fbc5bc45c29dcaadcf300c08a64',build=norm(json.loads((p/'build.json').read_bytes())),declaration=json.loads((p/'game-declaration.json').read_bytes()),feature_checks=dict(core_and_semantic=37,native_mirror_turn=144,mismatches=0,history_import_failure_preserved=True),groups=groups,root_diagnostics=dict(roots=8,contrast=contrast,declaration=v['declaration'],resource_note=json.loads((p/'analysis-cost-note.json').read_bytes()),interpretation='Exposed outcome-conditioned finite references, not error rates or causal feature isolation.'),adverse=adverse,adverse_reference=json.loads((p/'adverse-reference.json').read_bytes()),raw_entries=entries,sources=sources,raw_archive=a.relative_to(ROOT).as_posix()+'/raw.zip',sources_archive=a.relative_to(ROOT).as_posix()+'/sources.zip',raw_zip_sha256=sha((a/'raw.zip').read_bytes()),sources_zip_sha256=sha((a/'sources.zip').read_bytes()),packaging_failure=json.loads((p/'collector-failure.json').read_bytes()),production_changes='None; shared search/table/default APIs unchanged',public_push='held')
write_record(out,summary);write_record(a/'index.json',dict(raw_entries=entries,sources=sources,portable_sha256=sha(out.read_bytes())))
print(json.dumps(dict(groups={k:dict(methods=v['methods'],wall_seconds=v['wall_seconds'],replay=v['replay']) for k,v in groups.items()},contrast=contrast,sha256=sha(out.read_bytes()))),flush=True)
