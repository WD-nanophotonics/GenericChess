from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,hashlib,time,collections
R=Path.cwd();D=Path(__file__).resolve().parent;P=R/'.local_agent/opening-policy-20261017';sys.path[:0]=[str(R)]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot
from generic_chess.native import semantic as sem,SemanticSearchEngine
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value

def forbidden(*a,**k):raise AssertionError('Reader cannot search/train')
AlphaBetaPlayer.choose_action=forbidden;SemanticSearchEngine.search=forbidden

def decode(a):
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def canonical(a):return json.dumps(record_value(a),sort_keys=True,separators=(',',':'))
def digest(a):return hashlib.sha256(canonical(a).encode()).hexdigest()
plan=json.loads((D/'reader-plan.json').read_bytes());start=time.perf_counter();counts=collections.Counter();roots={(z['seed'],z['enabled']):z for z in json.loads((P/'acquisitions.json').read_bytes())['rows']};queries=collections.defaultdict(list)
for q in json.loads((D/'search-results.json').read_bytes())['rows']:queries[q['parent_sha256'],q['arm']].append(q)
def full(s,n,packed=None):
 if time.perf_counter()-start>plan['budget_seconds']:raise TimeoutError('Reader frozen budget')
 if packed is None:packed=pack_semantic_search_position(s.compiled,n,s)
 v=sem.snapshot(n,packed);expected=expected_snapshot(s.state.position,n,s.compiled)
 for k in('board','hands','aux_state','side'):assert record_value(v[k])==record_value(expected[k])
 assert v['ply']==s.state.ply_count and v['history_exact']and v['history_events_exact'];assert [''.join(f'{z:016x}'for z in row)for row in v['history']]==[str(h.position_key)for h in s.state.history];assert v['history_events']==tuple((255 if h.actor<0 else h.actor,bool(h.gave_check))for h in s.state.history);assert sem.terminal_status(n,packed)==record_value(s.state.terminal_status);counts['full_Native_Core_states']+=1;return packed
for row in json.loads((D/'results.json').read_bytes())['rows']:
 z=roots[row['seed'],row['enabled']];c0=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);patterns={p.pattern_id:p for p in c.ir.patterns}
 for arm in row['arms']:
  extra=[replace(patterns[pid],pattern_id=clone,name='diagnostic exact-pattern clone')for clone,pid in arm['clones'].items()]
  if extra:
   ir=replace(c.ir,patterns=c.ir.patterns+tuple(extra));fp=hashlib.sha256((c.ruleset_fingerprint+ir.serialized()).encode()).hexdigest();assert fp==arm['fingerprint'];cc=SearchMetadataAdapter(ir=replace(ir,ruleset_fingerprint=fp),support=replace(c.support,ruleset_fingerprint=fp),_legacy_compiled=replace(c._legacy_compiled,ruleset_fingerprint=fp))
  else:cc=c
  s=GameSession(cc)
  for a in row['parent_record']['actions']:s.submit(decode(a))
  assert record_value(s.state)==arm['full_parent'];n=compile_native_semantic_rules(cc);packed=full(s,n);before=sem.snapshot(n,packed);core=s.legal_actions();native={sem.public_action(n,a):a for a in sem.guarded_actions(n,packed)};assert set(core)==set(native);members={canonical(m['action']):m for g in arm['groups']for m in g['members']}
  for a in core:
   child=copy(s);child.submit(a);m=members[canonical(a)];assert digest(child.state)==m['full_state_sha256'];assert record_value(child.state.history[-1])==m['history_last'];full(child,n,sem.make_checked(n,packed,native[a]));counts['exact_own_child_receipts']+=1
  assert sem.snapshot(n,packed)==before
  for q in queries[row['parent_sha256'],arm['arm']]:
   assert q['status']=='returned';d=q['decision'];assert d['nodes']+d['qnodes']<=q['max_nodes'];pv=copy(s)
   for a,expected in zip(d['principal_variation'],q['PV_states']):pv.submit(decode(a));assert digest(pv.state)==expected['full_state_sha256'];full(pv,n);counts['PV_edges']+=1
   assert len(d['principal_variation'])==len(q['PV_states']);child=copy(s);child.submit(decode(d['action']));assert digest(child.state)==q['selected_full_state_sha256'];counts['query_receipts_not_reruns']+=1
  counts['arm_roots']+=1
 print(row['seed'],counts['full_Native_Core_states'],flush=True)
assert counts['arm_roots']==72 and counts['query_receipts_not_reruns']==288 and counts['PV_edges']==588
out={'complete':True,'counts':dict(counts),'seconds':time.perf_counter()-start,'source_scope':'Current normal source/Python Core and current unchanged Native v4 kernel; no search/training/original clock replay, shared semantic authorities not independent WDL.'}
with(D/'reader-results.json').open('xb')as f:f.write(json.dumps(out,indent=2).encode())
print(out,flush=True)
