from pathlib import Path
import json,time,hashlib,sys,traceback
D=Path(__file__).resolve().parent
source=(D/'run.py').read_text(encoding='utf-8-sig');prefix=source.split("plan=json.loads((D/'plan.json')")[0];exec(compile(prefix,str(D/'run.py')+'#definitions','exec'))
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.limits import SearchLimits
plan=json.loads((D/'search-plan.json').read_bytes());plan['budget_seconds']=plan['whole_seconds'];start=time.perf_counter();assert not(D/'search-results.json').exists();source_rows=json.loads((D/'results.json').read_bytes())['rows'];roots={(z['seed'],z['enabled']):z for z in json.loads((P/'acquisitions.json').read_bytes())['rows']};rows=[];errors=[];events=D/'search-events.jsonl';ending='complete';retained_pv_edges=0

def make(c,arm):
 if not arm['clones']:return c
 patterns={p.pattern_id:p for p in c.ir.patterns};extra=[replace(patterns[pid],pattern_id=clone,name='diagnostic exact-pattern clone')for clone,pid in arm['clones'].items()];ir=replace(c.ir,patterns=c.ir.patterns+tuple(extra));fp=hashlib.sha256((c.ruleset_fingerprint+ir.serialized()).encode()).hexdigest();assert fp==arm['fingerprint'];return SearchMetadataAdapter(ir=replace(ir,ruleset_fingerprint=fp),support=replace(c.support,ruleset_fingerprint=fp),_legacy_compiled=replace(c._legacy_compiled,ruleset_fingerprint=fp))
with events.open('xb')as f:
 try:
  for parent_index,parent in enumerate(source_rows):
   stop();z=roots[parent['seed'],parent['enabled']];c=adapt(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset']))));sessions=[]
   for arm in parent['arms']:
    cc=make(c,arm);s=GameSession(cc)
    for a in parent['parent_record']['actions']:s.submit(decode(a))
    assert record_value(s.state)==arm['full_parent'];p=build_ruleset_profile(cc,EvaluationConfig());assert record_value(p)==arm['profile'];ev=Evaluator(cc,p,EvaluationConfig());sessions.append((arm,s,ev))
   for nodes in (plan['node_budgets']if parent_index%2==0 else list(reversed(plan['node_budgets']))):
    for native in (plan['backends']if parent_index%2==0 else list(reversed(plan['backends']))):
     for arm,s,ev in(sessions if(parent_index+int(native))%2==0 else list(reversed(sessions))):
      stop();spec={'parent_sha256':parent['parent_sha256'],'seed':parent['seed'],'board':parent['board'],'arm':arm['arm'],'native_legality_requested':native,'max_nodes':nodes};before=s.state;witnesses=s._search_witnesses;t=time.perf_counter();player=AlphaBetaPlayer(s.compiled,evaluator_override=ev,tt_max_entries=10000,use_disk_cache=False,use_tt=True,use_ordering=True,use_native_semantic_legality=native,use_native_semantic_availability=False,use_native_semantic_check=False);setup=time.perf_counter()-t;t=time.perf_counter()
      try:
       value=player.choose_action(s,SearchLimits(max_depth=plan['max_depth'],max_nodes=nodes,max_time_seconds=plan['seconds_per_call'],quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t;assert s.state is before and s._search_witnesses is witnesses;assert value.nodes+value.qnodes<=nodes
       child=copy(s);child.submit(value.action);selected=observation(child.state);pv=copy(s);states=[]
       for a in value.principal_variation:pv.submit(a);states.append({'full_state_sha256':digest(pv.state),'history_last':record_value(pv.state.history[-1]),'observation':observation(pv.state)});retained_pv_edges+=1
       row={**spec,'status':'returned','construction_seconds':setup,'actual_choose_seconds':wall,'decision':record_value(value),'selected_child':selected,'selected_full_state_sha256':digest(child.state),'selected_history_last':record_value(child.state.history[-1]),'PV_states':states,'parent_and_witnesses_preserved':True,'leaf_evaluator':type(ev).__name__,'parent_evaluation':ev.evaluate(s.state)}
      except Exception as e:
       row={**spec,'status':'error','error':{'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()},'parent_and_witnesses_preserved':s.state is before and s._search_witnesses is witnesses};errors.append(row);print('ERROR',spec,type(e).__name__,str(e),flush=True)
      rows.append(row);f.write((json.dumps(row)+'\n').encode());f.flush();assert f.tell()<plan['max_evidence_bytes'];print(parent_index,arm['arm'],native,nodes,row['status'],None if row['status']=='error'else(value.completed_depth,value.termination_reason,value.score,round(wall,3)),flush=True)
 except(TimeoutError,InterruptedError)as e:ending=type(e).__name__+':'+str(e)
result={'complete':ending=='complete'and len(rows)==plan['total_slots'],'ending':ending,'rows':rows,'planned_slots':plan['total_slots'],'executed_slots':len(rows),'missing_slots':plan['total_slots']-len(rows),'errors':len(errors),'retained_PV_edges':retained_pv_edges,'seconds':time.perf_counter()-start,'scope':'Actual existing caller with fixed full-history roots, representation/backend/node-budget curve. No physical games/fit/changed evaluator/default/dedup/TT quotient; no independent WDL/strength.'}
with(D/'search-results.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
print('DONE',{k:v for k,v in result.items()if k!='rows'},flush=True)
