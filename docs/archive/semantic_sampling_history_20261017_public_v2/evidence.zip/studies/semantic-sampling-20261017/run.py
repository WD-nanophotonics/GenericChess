from pathlib import Path
from dataclasses import replace
from copy import copy
from fractions import Fraction
import sys,json,time,hashlib,collections,traceback
R=Path.cwd();D=Path(__file__).resolve().parent;P=R/'.local_agent/opening-policy-20261017';sys.path.insert(0,str(R))
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value

def canonical(x):return json.dumps(record_value(x),sort_keys=True,separators=(',',':'))
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def decode(a):
 if 'from_square' in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def stop():
 if time.perf_counter()-start>plan['budget_seconds']:raise TimeoutError('Frozen whole diagnostic cap')
 for name in ('rollout','advisor','slack'):
  flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
  if flags.get('stopped')or flags.get('user_paused'):raise InterruptedError('Explicit project stop')
def observation(state):
 v=record_value(state);p=dict(v['position']);p.pop('ruleset_fingerprint');return {'position':p,'terminal':v['terminal_status']}
def material(position,profile):return sum((1 if p.owner==0 else-1)*profile.board_value_by_type[p.current_type_id]for p in position.board if p)+sum((1 if owner==0 else-1)*count*profile.hand_value_by_base_type[t]for owner,h in enumerate(position.hands)for t,count in h.counts)
def adapt(x):return SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)
def projected(state,original_fp,keymap,clones):
 v=record_value(state);v['position']['ruleset_fingerprint']=original_fp
 v['repetition_counts']=sorted([[keymap[k],n]for k,n in v['repetition_counts']])
 for h in v['history']:
  h['position_key']=keymap[h['position_key']]
  if h['action_signature']:
   a=json.loads(h['action_signature'])
   if a.get('pattern_id')in clones:a['pattern_id']=clones[a['pattern_id']]
   h['action_signature']=json.dumps(a,sort_keys=True,separators=(',',':'))
 return v
plan=json.loads((D/'plan.json').read_bytes());assert not(D/'results.json').exists();start=time.perf_counter();rows=[];aliases=[];errors=[];children=0
roots={(z['seed'],z['enabled']):z for z in json.loads((P/'acquisitions.json').read_bytes())['rows']};seen={}
for row in json.loads((P/'prefix8-results.json').read_bytes())['rows']:
 if row.get('absent_prefix'):aliases.append({'game_id':row['game_id'],'absent_prefix':True});continue
 key=digest(row['parent_state']);aliases.append({'game_id':row['game_id'],'parent_sha256':key})
 if key in seen:continue
 stop();z=roots[row['seed'],row['enabled']];c=adapt(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset']))));s=GameSession(c);original_keys=[]
 original_keys.append(s.state.history[-1].position_key)
 for a in row['parent_record']['actions']:s.submit(decode(a));original_keys.append(s.state.history[-1].position_key)
 assert record_value(s.state)==row['parent_state'];before=s.state;actions=s.legal_actions();selected=min(a.pattern_id for a in actions);base_children={};original_observations={}
 for a in actions:
  stop();ch=copy(s);ch.submit(a);base_children[canonical(a)]=ch.state;original_observations[digest(observation(ch.state))]=observation(ch.state);children+=1
 output={'parent_sha256':key,'seed':row['seed'],'board':row['board'],'enabled':row['enabled'],'parent_record':row['parent_record'],'parent_state':row['parent_state'],'selected_pattern':selected,'arms':[]}
 base_profile=build_ruleset_profile(c,EvaluationConfig());base_profile_fields=record_value(base_profile);base_profile_fields.pop('ruleset_fingerprint')
 for arm in plan['arms']:
  stop();t=time.perf_counter();clones={};extra=[]
  for pattern in c.ir.patterns:
   count=(1 if arm=='all_patterns_1_extra_copy' else 3 if arm=='same_pattern_3_extra_copies' else 1 if arm=='lexicographically_first_active_pattern_1_extra_copy' else 0)if(arm=='all_patterns_1_extra_copy'or pattern.pattern_id==selected)else 0
   for i in range(count):
    pid='sampling_clone_'+str(i)+'_'+pattern.pattern_id;assert all(p.pattern_id!=pid for p in c.ir.patterns);clones[pid]=pattern.pattern_id;extra.append(replace(pattern,pattern_id=pid,name='diagnostic exact-pattern clone'))
  if extra:
   ir=replace(c.ir,patterns=c.ir.patterns+tuple(extra));fp=hashlib.sha256((c.ruleset_fingerprint+ir.serialized()).encode()).hexdigest();cc=SearchMetadataAdapter(ir=replace(ir,ruleset_fingerprint=fp),support=replace(c.support,ruleset_fingerprint=fp),_legacy_compiled=replace(c._legacy_compiled,ruleset_fingerprint=fp))
  else:cc=c
  ss=GameSession(cc);km={ss.state.history[-1].position_key:original_keys[0]}
  for i,a in enumerate(row['parent_record']['actions']):ss.submit(decode(a));k=ss.state.history[-1].position_key;assert km.get(k,original_keys[i+1])==original_keys[i+1];km[k]=original_keys[i+1]
  assert projected(ss.state,c.ruleset_fingerprint,km,clones)==record_value(s.state)
  profile=build_ruleset_profile(cc,EvaluationConfig());pf=record_value(profile);pf.pop('ruleset_fingerprint');assert pf==base_profile_fields
  parent=ss.state;groups=collections.defaultdict(list);vals={};different_signatures=0;verified=0
  for a in ss.legal_actions():
   stop();ch=copy(ss);ch.submit(a);children+=1;ca=record_value(a);ca['pattern_id']=clones.get(ca['pattern_id'],ca['pattern_id']);baseline=base_children[canonical(ca)];k=ch.state.history[-1].position_key;ok=baseline.history[-1].position_key;local=dict(km);assert local.get(k,ok)==ok;local[k]=ok;assert projected(ch.state,c.ruleset_fingerprint,local,clones)==record_value(baseline);verified+=1
   ob=observation(ch.state);oh=digest(ob);assert ob==original_observations[oh];v=material(ch.state.position,profile)-material(parent.position,profile);assert oh not in vals or vals[oh]==v;vals[oh]=v
   different_signatures+=ch.state.history[-1].action_signature!=baseline.history[-1].action_signature
   groups[oh].append({'action':record_value(a),'full_state_sha256':digest(ch.state),'history_last':record_value(ch.state.history[-1]),'baseline_full_state_sha256':digest(baseline),'child_position_key_mapping':[k,ok]})
  assert ss.state is parent and s.state is before;assert set(groups)==set(original_observations)
  n=sum(map(len,groups.values()));m=len(groups);binding=Fraction(sum(len(v)*vals[k]for k,v in groups.items()),n);obs=Fraction(sum(vals.values()),m);tv=sum((abs(Fraction(len(v),n)-Fraction(1,m))for v in groups.values()),Fraction())/2
  output['arms'].append({'arm':arm,'fingerprint':cc.ruleset_fingerprint,'clones':clones,'profile':record_value(profile),'full_parent':record_value(ss.state),'parent_key_correspondence':sorted(km.items()),'bindings':n,'observations':m,'binding_mean':[binding.numerator,binding.denominator],'observation_mean':[obs.numerator,obs.denominator],'TV':[tv.numerator,tv.denominator],'different_action_signatures':different_signatures,'full_children_verified_with_explicit_correspondence':verified,'groups':[{'observation_sha256':k,'material_delta':vals[k],'members':v}for k,v in groups.items()],'seconds':time.perf_counter()-t})
  print(row['game_id'],arm,n,m,binding,obs,'signature_changes',different_signatures,flush=True)
 seen[key]=True;rows.append(output)
 data={'complete':False,'rows':rows,'slot_mapping':aliases,'children_materialized':children,'seconds':time.perf_counter()-start};raw=json.dumps(data).encode();assert len(raw)<plan['max_output_bytes'];(D/'partial.json').write_bytes(raw)
result={'complete':True,'rows':rows,'slot_mapping':aliases,'children_materialized':children,'seconds':time.perf_counter()-start,'new_games_search_fits':0,'scope':'Same declared observed oneply frontiers; actual full histories retained with explicit cross-rule key/pattern correspondence, NOT universal game or history quotient.'}
with(D/'results.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
print('DONE',len(rows),children,result['seconds'],flush=True)
