from pathlib import Path
import sys,json,time,hashlib
D=Path(__file__).resolve().parent
source=(D/'run.py').read_text(encoding='utf-8-sig');exec(compile(source.split("plan=json.loads((D/'plan.json')")[0],str(D/'run.py')+'#definitions','exec'))
sys.path[:0]=[str(R/'tests'),str(R/'tests/product')]
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core.semantic_executor import semantic_engine_for
plan=json.loads((D/'features-plan.json').read_bytes());start=time.perf_counter();rows=[];roots={(z['seed'],z['enabled']):z for z in json.loads((P/'acquisitions.json').read_bytes())['rows']}
for parent in json.loads((D/'results.json').read_bytes())['rows']:
 stop();z=roots[parent['seed'],parent['enabled']];c=adapt(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset']))));patterns={p.pattern_id:p for p in c.ir.patterns}
 for arm in parent['arms']:
  stop();t=time.perf_counter();extra=[replace(patterns[pid],pattern_id=clone,name='diagnostic exact-pattern clone')for clone,pid in arm['clones'].items()]
  if extra:
   ir=replace(c.ir,patterns=c.ir.patterns+tuple(extra));fp=hashlib.sha256((c.ruleset_fingerprint+ir.serialized()).encode()).hexdigest();assert fp==arm['fingerprint'];cc=SearchMetadataAdapter(ir=replace(ir,ruleset_fingerprint=fp),support=replace(c.support,ruleset_fingerprint=fp),_legacy_compiled=replace(c._legacy_compiled,ruleset_fingerprint=fp))
  else:cc=c
  s=GameSession(cc)
  for a in parent['parent_record']['actions']:s.submit(decode(a))
  assert record_value(s.state)==arm['full_parent'];before=s.state;n=compile_native_semantic_rules(cc);packed=pack_semantic_search_position(cc,n,s);snapshot=sem.snapshot(n,packed);expected=(reference_features(cc,s.state.position),localized_control_features(s.state.position,cc));actual=(sem.dynamic_features(n,packed),sem.spatial_features(n,packed)['localized_control']);assert expected==actual and sem.snapshot(n,packed)==snapshot and s.state is before
  profile=build_ruleset_profile(cc,EvaluationConfig());assert record_value(profile)==arm['profile'];ev=Evaluator(cc,profile,EvaluationConfig());e=semantic_engine_for(cc)
  rows.append({'parent_sha256':parent['parent_sha256'],'seed':parent['seed'],'board':parent['board'],'arm':arm['arm'],'fingerprint':cc.ruleset_fingerprint,'Core_3':expected[0],'Core_9':expected[1],'Native_3':actual[0],'Native_9':actual[1],'default_evaluation':ev.evaluate(s.state),'both_owners_in_check':[e.in_check(replace(s.state.position,side_to_move=o),o)for o in(0,1)],'full_history_length':len(s.state.history),'full_state_sha256':digest(s.state),'Native_snapshot_sha256':digest(snapshot),'snapshot_and_parent_preserved':True,'seconds':time.perf_counter()-t});print(parent['seed'],arm['arm'],expected,rows[-1]['default_evaluation'],flush=True)
with(D/'features-results.json').open('xb')as f:f.write(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start,'scope':'Existing required Core/Native inputs and default evaluator onsame72fullsessions, no feature normalization/model fit/default/TT change.'},indent=2).encode())
print('DONE',len(rows),time.perf_counter()-start,flush=True)
