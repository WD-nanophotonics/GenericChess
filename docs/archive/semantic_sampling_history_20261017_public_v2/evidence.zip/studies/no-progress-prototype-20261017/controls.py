from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,hashlib
R=Path.cwd();D=R/'.local_agent/no-progress-prototype-20261017';S=D/'source';sys.path[:0]=[str(S),str(R/'tests'),str(R/'tests/product'),str(R)]
import generic_chess
assert Path(generic_chess.__file__).resolve().is_relative_to(S.resolve())
from generic_chess.core.actions import action_is_board,action_source_square,action_target_square
from generic_chess.core.coordinates import Square
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import LeapAtom
from generic_chess.rules.schema import RuleSet,RuleNoProgressDraw
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.identity import search_state_identity
from generic_chess.core.adjudication import IncompleteAdjudicationHistoryError
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core import terminal
from scripts.research_record import record_value
from scripts.full_q_refresh_comparison import runtime_state

def go(s,src,dst):
 a=next(a for a in s.legal_actions()if action_is_board(a)and action_source_square(a)==Square(*src)and action_target_square(a)==Square(*dst));s.submit(a);return a
leaps=tuple(LeapAtom(x)for x in((1,0),(-1,0),(0,1),(0,-1)));king=PieceType('K','anchor',tuple(LeapAtom((x,y))for x in(-1,0,1)for y in(-1,0,1)if x or y),is_anchor=True);types=(king,PieceType('P','generic reset actor',leaps),PieceType('N','generic quiet actor',leaps));board=[[None]*8 for _ in range(8)]
for o,t,x,y in[(0,'K',0,0),(1,'K',7,7),(0,'P',1,1),(0,'N',3,1)]:board[y][x]=Piece(o,t,t)
rule=RuleSet(board_size=8,piece_types=types,initial_position=tuple(tuple(r)for r in board),drop_allowed={t:((False,)*64,(False,)*64)for t in('P','N')},no_progress_draw=RuleNoProgressDraw(6,True,('P',)),max_ply=64,repetition_limit=4);c=replace(compile_legacy_ruleset_for_semantic_execution(rule),_legacy_compiled=None)
A=[((1,1),(1,2)),((7,7),(7,6)),((1,2),(1,1)),((7,6),(7,7))];B=[((3,1),(3,2)),((7,7),(7,6)),((3,2),(3,1)),((7,6),(7,7))];sessions=[]
for cycles in(A+B,B+A):
 s=GameSession(c)
 for src,dst in cycles:go(s,src,dst)
 assert not s.state.terminal_status.is_terminal;sessions.append(s)
a,b=sessions;assert a.state.position==b.state.position and a.state.ply_count==b.state.ply_count and a.state.repetition_counts==b.state.repetition_counts;assert a.state.history!=b.state.history
ra=SearchPathRuntime(a.state,c,history_witnesses=a._search_witnesses,hash_override=7);rb=SearchPathRuntime(b.state,c,history_witnesses=b._search_witnesses,hash_override=7);assert ra.tt_eligible and rb.tt_eligible;assert ra.search_key()!=rb.search_key();assert search_state_identity(a.state,c)!=search_state_identity(b.state,c)
checks=[]
for label,s,rt in [('A_then_B',a,ra),('B_then_A',b,rb)]:
 snapshot=runtime_state(rt);before=s.state;actions=s.legal_actions()
 for action in actions:
  child=copy(s);child.submit(action);rt.push(action);assert rt.position==child.state.position and rt.terminal_status==child.state.terminal_status and rt.ply_count==child.state.ply_count;rt.pop();assert runtime_state(rt)==snapshot
 child=copy(s);go(child,(0,0),(1,0));checks.append({'label':label,'parent':record_value(s.state),'record':record_value(s.to_record()),'legal_count':len(actions),'tested_all_children':len(actions),'next_action_child':record_value(child.state),'runtime_key_context_kept':True});assert s.state is before
assert checks[0]['next_action_child']['terminal_status']['status']=='no_progress_draw';assert checks[1]['next_action_child']['terminal_status']['status']=='ongoing'
try:SearchPathRuntime(replace(a.state,history=()),c)
except IncompleteAdjudicationHistoryError:opaque_refused=True
else:raise AssertionError('missing history admitted')
class Constant:
 def evaluate(self,state):return 77
 def type_value(self,t):return 0 if t=='K'else 1000
 def capture_order_value(self,moving,captured):return 10*self.type_value(captured.current_type_id)-self.type_value(moving.current_type_id)
# Existing pure-semantic evaluator/runner, no new solver.
results=[];latencies=[];original=terminal.no_progress_draw_status

def timed(*args,**kwargs):
 t=time.perf_counter()
 try:return original(*args,**kwargs)
 finally:latencies.append(time.perf_counter()-t)
terminal.no_progress_draw_status=timed
for label,s in [('A_then_B',a),('B_then_A',b)]:
 for tt in(False,True):
  before=s.state;t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=Constant(),use_disk_cache=False,use_tt=tt,use_ordering=False,use_native_semantic_legality=False);r=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));assert s.state is before;results.append({'label':label,'tt':tt,'decision':record_value(r),'seconds':time.perf_counter()-t})
s=a;before=s.state;token=CancellationToken();fired=[]
def cancel_during_replay(*args,**kwargs):
 fired.append(True);token.cancel();return original(*args,**kwargs)
terminal.no_progress_draw_status=cancel_during_replay
player=AlphaBetaPlayer(c,evaluator_override=Constant(),use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False);cancelled=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0),cancel_token=token);assert fired and cancelled.termination_reason=='cancelled'and s.state is before
terminal.no_progress_draw_status=original
out={'complete':True,'ruleset':json.loads(serialize_ruleset(rule)),'counter_controls':checks,'same_Position_ply_repetition_counts':True,'different_actual_one_action_terminals':True,'full_history_keys_different_under_forced_hash_collision':True,'missing_history_refused':opaque_refused,'calls':results,'actual_mid_replay_cancelled':record_value(cancelled),'primitive_replay_calls':len(latencies),'max_primitive_seconds':max(latencies,default=0),'limitation':'Cancellation polls before/after full primitive replay, NOT inside it. Only these short8/10ply contexts; not a production-ready long-history guarantee. No WDL/unique optimal return or neural-network necessity claim.'}
with(D/'controls.json').open('xb')as f:f.write(json.dumps(out,indent=2).encode())
print({k:v for k,v in out.items()if k not in('ruleset','counter_controls','calls','actual_mid_replay_cancelled')},flush=True)
