from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,hashlib
R=Path.cwd();D=Path(__file__).resolve().parent;S=D/'source';sys.path[:0]=[str(S),str(R)]
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_is_board,action_source_square,action_target_square
from generic_chess.core.coordinates import Square
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core import terminal
from scripts.research_record import record_value
plan=json.loads((D/'long-history-plan.json').read_bytes());start=time.perf_counter();rule=replace(deserialize_ruleset(json.dumps(json.loads((D/'controls.json').read_bytes())['ruleset'])),max_ply=2048,repetition_limit=4096);c=replace(compile_legacy_ruleset_for_semantic_execution(rule),_legacy_compiled=None);s=GameSession(c);cycle=[((1,1),(1,2)),((7,7),(7,6)),((1,2),(1,1)),((7,6),(7,7))];rows=[];steps=0;ending='complete';original=terminal.no_progress_draw_status
class Constant:
 def evaluate(self,state):return 77
 def type_value(self,t):return 0 if t=='K'else 1000
 def capture_order_value(self,moving,captured):return 10*self.type_value(captured.current_type_id)-self.type_value(moving.current_type_id)
with(D/'long-history-progress.jsonl').open('xb')as f:
 for ply in range(1,1025):
  flags=[json.loads((R/'.local_agent'/f'{n}.json').read_bytes())for n in('rollout','advisor','slack')]
  if any(x.get('stopped')or x.get('user_paused')for x in flags):ending='user_stop';break
  if time.perf_counter()-start>plan['whole_seconds']:ending='whole_cap';break
  src,dst=cycle[(ply-1)%4];a=next(a for a in s.legal_actions()if action_is_board(a)and action_source_square(a)==Square(*src)and action_target_square(a)==Square(*dst));s.submit(a);steps+=1;assert not s.state.terminal_status.is_terminal
  if ply%64==0:f.write((json.dumps({'completed_actual_prefix':ply,'seconds':time.perf_counter()-start,'history_length':len(s.state.history)})+'\n').encode());f.flush();print('prefix',ply,time.perf_counter()-start,flush=True)
  if ply not in plan['prefixes']:continue
  with(D/f'long-prefix-{ply}.json').open('xb')as g:g.write(json.dumps({'ruleset':json.loads(serialize_ruleset(rule)),'state':record_value(s.state),'record':record_value(s.to_record())},indent=2).encode())
  before=s.state;w=s._search_witnesses;latencies=[]
  def timed(*a,**k):
   t=time.perf_counter()
   try:return original(*a,**k)
   finally:latencies.append(time.perf_counter()-t)
  terminal.no_progress_draw_status=timed;t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=Constant(),use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tt_max_entries=1000);decision=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t;assert s.state is before and s._search_witnesses is w
  token=CancellationToken();fired=[]
  def cancel(*a,**k):
   fired.append(time.perf_counter());token.cancel();return original(*a,**k)
  terminal.no_progress_draw_status=cancel;t=time.perf_counter();cancelled=AlphaBetaPlayer(c,evaluator_override=Constant(),use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tt_max_entries=1000).choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0),cancel_token=token);elapsed=time.perf_counter()-t;assert fired and cancelled.termination_reason=='cancelled'and s.state is before and s._search_witnesses is w
  rows.append({'prefix':ply,'full_history_length':len(s.state.history),'caller':record_value(decision),'caller_total_seconds':wall,'primitive_replay_calls':len(latencies),'max_indivisible_replay_seconds':max(latencies,default=0),'cancelled':record_value(cancelled),'cancel_to_return_seconds':time.perf_counter()-fired[0],'cancel_total_seconds':elapsed,'parent_preserved':True});terminal.no_progress_draw_status=original
result={'complete':steps==1024,'ending':ending,'actual_transitions':steps,'rows':rows,'missing_prefixes':[p for p in plan['prefixes']if p not in[x['prefix']for x in rows]],'seconds':time.perf_counter()-start,'scope':'Real full histories and bounded private existing-Core calls only; no WDL/longer-context/hardtimer or control inside primitive replay claim.'}
with(D/'long-history-results.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
print('DONE',result['actual_transitions'],result['seconds'],flush=True)
