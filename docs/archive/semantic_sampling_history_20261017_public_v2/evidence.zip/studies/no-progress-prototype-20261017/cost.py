from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,hashlib,ast,traceback,collections
R=Path.cwd();D=Path(__file__).resolve().parent;S=D/'source';sys.path[:0]=[str(S),str(R/'tests'),str(R)]
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core import terminal
from scripts.research_record import record_value
mix=R/'.local_agent/mechanism-mix-20261017';tree=ast.parse((mix/'run.py').read_text(encoding='utf-8-sig'));parts=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in('canonical','digest','decode','Unity')];exec(compile(ast.Module(body=parts,type_ignores=[]),'published-mix-definitions','exec'))
plan=json.loads((D/'cost-plan.json').read_bytes());start=time.perf_counter();rows=[];replays=[];ending='complete';inputs={x['family_index']:x for x in json.loads((mix/'inputs.json').read_bytes())['rows']};frontiers=[x for x in json.loads((mix/'frontiers.json').read_bytes())if x['family_index']%2 and not x.get('absent_search')]
original=terminal.no_progress_draw_status

def timed(*a,**k):
 t=time.perf_counter()
 try:return original(*a,**k)
 finally:replays.append({'ply':a[2],'seconds':time.perf_counter()-t})
terminal.no_progress_draw_status=timed
with(D/'cost-events.jsonl').open('xb')as f:
 for root in frontiers:
  c=replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(inputs[root['family_index']]['ruleset']))),_legacy_compiled=None);s=GameSession(c)
  for a in root['record']['actions']:s.submit(decode(a))
  assert record_value(s.state)==root['full_state']
  for tt in plan['TT']:
   if time.perf_counter()-start>plan['whole_seconds']:ending='whole_cap';break
   flags=[json.loads((R/'.local_agent'/f'{n}.json').read_bytes())for n in('rollout','advisor','slack')]
   if any(x.get('stopped')or x.get('user_paused')for x in flags):ending='user_stop';break
   before=s.state;w=s._search_witnesses;t=time.perf_counter();k=len(replays);player=AlphaBetaPlayer(c,evaluator_override=Unity(c),use_disk_cache=False,use_tt=tt,tt_max_entries=10000,use_native_semantic_legality=True)
   try:
    v=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t;assert s.state is before and s._search_witnesses is w;pv=copy(s);pvstates=[]
    for a in v.principal_variation:pv.submit(a);pvstates.append(record_value(pv.state))
    child=copy(s);child.submit(v.action);out={'family_index':root['family_index'],'ply':root['ply'],'TT':tt,'status':'returned','wall':wall,'decision':record_value(v),'full_PV_states':pvstates,'selected_fullstate':record_value(child.state),'parent_and_witnesses_preserved':True,'native_provider_created':player.native_legality_provider is not None,'primitive_replays':replays[k:]}
   except Exception as e:out={'family_index':root['family_index'],'ply':root['ply'],'TT':tt,'status':'error','error':{'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()},'parent_and_witnesses_preserved':s.state is before and s._search_witnesses is w}
   rows.append(out);f.write((json.dumps(out)+'\n').encode());f.flush();print(root['family_index'],root['ply'],tt,out['status'],None if out['status']=='error'else(v.completed_depth,v.termination_reason,round(wall,3)),flush=True)
  if ending!='complete':break
terminal.no_progress_draw_status=original
result={'complete':ending=='complete'and len(rows)==24,'ending':ending,'rows':rows,'executed_calls':len(rows),'planned_calls':24,'missing':24-len(rows),'errors':sum(x['status']=='error'for x in rows),'seconds':time.perf_counter()-start,'primitive_replays':len(replays),'max_indivisible_primitive_seconds':max((x['seconds']for x in replays),default=0),'scope':'Separate private complete-history existing-Core prototype24calls; baseline96slots/errors untouched. No Native support/production activation or originalsearch rerun claim.'}
with(D/'cost-results.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
print('DONE',{k:v for k,v in result.items()if k!='rows'},flush=True)
