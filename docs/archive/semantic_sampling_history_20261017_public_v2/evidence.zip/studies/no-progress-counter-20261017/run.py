from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,collections,hashlib
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.schema import RuleNoProgressDraw
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_is_board,action_source_square,action_target_square,SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square,square_to_index
from generic_chess.core.adjudication import no_progress_draw_status,IncompleteAdjudicationHistoryError
from scripts.research_record import record_value
plan=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();stats=collections.Counter();timings=[];cases=[]
def stop():
 if time.perf_counter()-start>plan['budget_seconds']:raise TimeoutError('Frozen whole cap')
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('Project stopped')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def step(count,before,after,a,p):
 actor=before.side_to_move;mover=None
 if action_is_board(a):
  src=action_source_square(a);piece=before.board[square_to_index(src,before.board_shape)]
  if piece is None or piece.owner!=actor:raise IncompleteAdjudicationHistoryError('counter mover unavailable')
  mover=piece.current_type_id
 capture=False
 if p.reset_on_capture:
  def totals(pos):return[sum(z is not None and z.owner==o for z in pos.board)+pos.hands[o].total()for o in(0,1)]
  b=totals(before);c=totals(after);delta=[c[o]-b[o]for o in(0,1)]
  if delta[1-actor]<0 and delta[actor]in(0,-delta[1-actor]):capture=True
  elif any(delta):raise IncompleteAdjudicationHistoryError('ambiguous inventory delta; no zero substitution')
 return 0 if capture or mover in p.reset_mover_type_ids else count+1

def checked(s,a,count):
 stop();before=s.state;t=time.perf_counter();child=copy(s);child.submit(a);core_seconds=time.perf_counter()-t;t=time.perf_counter();new=step(count,before.position,child.state.position,a,s.compiled.no_progress_draw);cost=time.perf_counter()-t;expected=no_progress_draw_status(s.compiled.no_progress_draw,child.state.position,child.state.ply_count,child.state.repetition_counts,child.state.history,s.compiled);assert expected==('DRAW'if new>=s.compiled.no_progress_draw.threshold_plies else None);assert s.state is before;timings.append(cost);stats['actual_checked_transitions']+=1;return child,new

def go(s,src,dst,count):
 a=next(a for a in s.legal_actions()if action_is_board(a)and action_source_square(a)==Square(*src)and action_target_square(a)==Square(*dst));return checked(s,a,count)
control=json.loads((R/'.local_agent/no-progress-prototype-20261017/controls.json').read_bytes());c=replace(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(control['ruleset']))),_legacy_compiled=None)
for x in control['counter_controls']:
 s=GameSession(c);count=0
 for a in x['record']['actions']:s,count=checked(s,decode(a),count)
 assert record_value(s.state)==x['parent'];branch=[]
 for a in s.legal_actions():
  ch,n=checked(s,a,count);branch.append({'action':record_value(a),'count':n,'terminal':record_value(ch.state.terminal_status)})
 cases.append({'case':x['label'],'root_counter':count,'root_fullstate':record_value(s.state),'all_children':branch})
assert cases[0]['root_counter']==5 and cases[1]['root_counter']==1
# Systematic composites: even families explicitly add no-progress8 to their
# existing pass/consecutive policy. Original frozen96 inputs/results stay intact.
inputs=json.loads((R/'.local_agent/mechanism-mix-20261017/inputs.json').read_bytes())['rows']
for z in inputs:
 stop();rule=deserialize_ruleset(json.dumps(z['ruleset']));added=rule.no_progress_draw is None
 if added:rule=replace(rule,no_progress_draw=RuleNoProgressDraw(8,True))
 cc=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(cc);actions=tuple(sorted(s.legal_actions(),key=repr));capture=None;promotions=0
 for a in actions:
  ch,n=checked(s,a,0);promotions+=getattr(a,'promotion_target_id',None)is not None
  if capture is None and ch.state.position.hands[s.state.position.side_to_move].total()>s.state.position.hands[s.state.position.side_to_move].total():capture=(ch,n,a)
 witness={'family_index':z['family_index'],'new_declared_no_progress_policy':added,'fingerprint':cc.ruleset_fingerprint,'initial_actions':len(actions),'promotion_children_checked':promotions,'capture_reply_drop':None}
 if capture is not None:
  ch,n,a=capture;edges=[{'action':record_value(a),'counter':n,'fullstate':record_value(ch.state)}]
  if not ch.state.terminal_status.is_terminal:
   reply=next(iter(sorted(ch.legal_actions(),key=repr)),None)
   if reply is not None:
    ch,n=checked(ch,reply,n);edges.append({'action':record_value(reply),'counter':n,'fullstate':record_value(ch.state)})
    drop=next((a for a in sorted(ch.legal_actions(),key=repr)if isinstance(a,SemanticDropMove)),None)
    if drop is not None:ch,n=checked(ch,drop,n);edges.append({'action':record_value(drop),'counter':n,'fullstate':record_value(ch.state)});stats['actual_drop_witnesses']+=1
  witness['capture_reply_drop']={'edges':edges,'record':record_value(ch.to_record())};stats['capture_witnesses']+=1
 cases.append(witness);print('family',z['family_index'],'drop',witness['capture_reply_drop']is not None and len(witness['capture_reply_drop']['edges'])==3,flush=True)
long=json.loads((R/'.local_agent/no-progress-prototype-20261017/long-prefix-1024.json').read_bytes());cc=replace(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(long['ruleset']))),_legacy_compiled=None);s=GameSession(cc);count=0;longrows=[];t=time.perf_counter();counter_time=0
# checked() also evaluates the existing authoritative primitive on every
# complete prefix: this is a differential control, not a fast whole-run claim.
for a in long['record']['actions']:
 s,count=checked(s,decode(a),count);counter_time+=timings[-1]
 if s.state.ply_count%128==0:longrows.append({'ply':s.state.ply_count,'counter':count,'seconds':time.perf_counter()-t});print('long',longrows[-1],flush=True)
assert record_value(s.state)==long['state']and len(s.state.history)==1025
out={'complete':True,'cases':cases,'long_prefixes':longrows,'long_final_counter':count,'long_counter_component_total_seconds':counter_time,'long_actual_Core_and_reference_seconds':time.perf_counter()-t,'stats':dict(stats),'counter_component_seconds_total':sum(timings),'counter_component_max_seconds':max(timings),'seconds':time.perf_counter()-start,'scope':'No runtime integration/search/fit. Full records retained. Ordinary capture/drop/promotion and configured mover resets checked; ambiguity error timing/forged-history validation and generic arbitrary compounds are NOT qualified. Component speed is not measured caller gain or permission to drop history.'}
with(D/'results.json').open('xb')as f:f.write(json.dumps(out,indent=2).encode())
print('DONE',out['stats'],out['seconds'],flush=True)
