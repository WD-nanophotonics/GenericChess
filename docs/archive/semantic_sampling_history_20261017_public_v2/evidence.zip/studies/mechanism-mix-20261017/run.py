from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,random,hashlib,traceback,collections
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.rules.schema import RuleConsecutiveActionAdjudication,RuleNoProgressDraw
from generic_chess.core.coordinates import Square
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot
from generic_chess.native import semantic as sem
from scripts.research_record import record_value
plan=json.loads((D/'plan.json').read_bytes());assert not(D/'results.json').exists();start=time.perf_counter();inputs=[];frontiers=[];rows=[];paths=[];counts=collections.Counter();ending='complete'
def canonical(v):return json.dumps(record_value(v),sort_keys=True,separators=(',',':'))
def digest(v):return hashlib.sha256(canonical(v).encode()).hexdigest()
def stop():
 if time.perf_counter()-start>=plan['whole_seconds']:raise TimeoutError('Frozen whole-run cap')
 for name in('rollout','advisor','slack'):
  x=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
  if x.get('stopped')or x.get('user_paused'):raise InterruptedError('Explicit project stop')
def decode(a):
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
class Unity:
 def __init__(self,c):self.values={t:0 if m.is_anchor else 1000 for t,m in c.support.type_metadata.items()}
 def type_value(self,t):return self.values[t]
 def capture_order_value(self,moving,captured):return 10*self.values[captured.current_type_id]-self.values[moving.current_type_id]
 def evaluate(self,state):
  p=state.position;side=p.side_to_move;return sum((1 if z.owner==side else-1)*self.values[z.current_type_id]for z in p.board if z)+sum((1 if o==side else-1)*k*self.values[t]for o,h in enumerate(p.hands)for t,k in h.counts)
def native_check(s,n):
 packed=pack_semantic_search_position(s.compiled,n,s);snap=sem.snapshot(n,packed);want=expected_snapshot(s.state.position,n,s.compiled)
 for k in('board','hands','aux_state','side'):assert record_value(snap[k])==record_value(want[k])
 assert snap['ply']==s.state.ply_count and snap['history_exact']and snap['history_events_exact'];assert [''.join(f'{z:016x}'for z in h)for h in snap['history']]==[str(h.position_key)for h in s.state.history];assert snap['history_events']==tuple((255 if h.actor<0 else h.actor,bool(h.gave_check))for h in s.state.history);counts['full_native_Core_state_checks']+=1
 return packed,snap
base=weird_rulesets();types=tuple(replace(pt,is_promotable=True,promotion_target_ids=('TP',))if pt.type_id=='R'else pt for pt in base[2].piece_types);board=[[None]*8 for _ in range(8)]
for x,y,o,t in[(0,0,0,'K'),(7,7,1,'K'),(1,1,0,'R'),(1,2,0,'R'),(1,4,1,'R'),(1,6,1,'R')]:board[y][x]=Piece(o,t,t)
mask=frozenset((Square(x,y),Square(tx,ty))for x in range(8)for y in range(8)for tx in range(8)for ty in range(8)if(x,y)!=(tx,ty));sessions=[]
# Serialize every systematic input before any search. No result-selected setup.
for i,combo in enumerate(plan['combinations']):
 stop();rule=replace(base[2],piece_types=types,semantic_actions=tuple(base[k].semantic_actions[0]for k in combo),initial_position=tuple(tuple(r)for r in board),drop_allowed={'R':((True,)*64,(True,)*64),'TP':((False,)*64,(False,)*64)},promotion_allowed={'R':(mask,mask)},promotion_forced={'R':(frozenset(),frozenset())},max_ply=64,pass_enabled=(i%2==0),consecutive_action_adjudications=(RuleConsecutiveActionAdjudication('pass',6,'DRAW'),)if i%2==0 else(),no_progress_draw=RuleNoProgressDraw(8,True)if i%2 else None,metadata={'purpose':'Prospective mechanism pair/triple operational diagnostic','family_index':i})
 c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);assert c._legacy_compiled is None;s=GameSession(c);n=None;refusal=None
 try:n=compile_native_semantic_rules(c)
 except NativeUnsupportedRuleError as e:refusal=str(e)
 inputs.append({'family_index':i,'mechanism_indices':combo,'ruleset':json.loads(serialize_ruleset(rule)),'fingerprint':c.ruleset_fingerprint,'initial_state':record_value(s.state),'native_compile_refusal':refusal});sessions.append((i,c,s,n))
with(D/'inputs.json').open('xb')as f:f.write(json.dumps({'complete':True,'rows':inputs},indent=2).encode())
with(D/'events.jsonl').open('xb')as f:
 try:
  for i,c,s,n in sessions:
   stop();rng=random.Random(193701+i);roots=[];walk=[]
   for ply in range(5):
    if ply in plan['prefixes']:
     root={'family_index':i,'ply':ply,'full_state':record_value(s.state),'record':record_value(s.to_record()),'terminal':record_value(s.state.terminal_status)}
     if s.state.terminal_status.is_terminal:root['absent_search']=True;frontiers.append(root)
     else:
      before=s.state;actions=s.legal_actions();groups=collections.defaultdict(set);children=[]
      if n:
       packed,snap=native_check(s,n);native_actions={sem.public_action(n,a)for a in sem.guarded_actions(n,packed)};assert set(actions)==native_actions
      for a in actions:
       stop();ch=copy(s);ch.submit(a);ob={'position':record_value(ch.state.position),'terminal':record_value(ch.state.terminal_status)};key=record_value(a);key.pop('pattern_id',None);key.pop('geometry_id',None);groups[canonical(key)].add(digest(ob));children.append({'action':record_value(a),'full_state_sha256':digest(ch.state),'observation_sha256':digest(ob),'history_last':record_value(ch.state.history[-1])});counts['frontier_children']+=1
       if n:native_check(ch,n)
      assert s.state is before;root.update(legal=len(actions),children=children,coordinate_keys=len(groups),coordinate_keys_multiple_observations=sum(len(v)>1 for v in groups.values()));frontiers.append(root);roots.append((ply,copy(s)))
    if ply==4:break
    if s.state.terminal_status.is_terminal:break
    a=rng.choice(sorted(s.legal_actions(),key=repr));s.submit(a);walk.append(record_value(a));counts['diagnostic_prefix_edges']+=1
   paths.append({'family_index':i,'walk':walk,'final_state':record_value(s.state),'record':record_value(s.to_record())})
   for ply,root in roots:
    for nodes in(plan['node_budgets']if i%2==0 else list(reversed(plan['node_budgets']))):
     for native in(plan['backends']if i%2==0 else list(reversed(plan['backends']))):
      stop();spec={'family_index':i,'ply':ply,'max_nodes':nodes,'native_legality_requested':native};before=root.state;witnesses=root._search_witnesses;t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=Unity(c),use_disk_cache=False,tt_max_entries=10000,use_tt=True,use_ordering=True,use_native_semantic_legality=native,use_native_semantic_availability=False,use_native_semantic_check=False);construction=time.perf_counter()-t;t=time.perf_counter()
      try:
       value=player.choose_action(root,SearchLimits(max_depth=6,max_nodes=nodes,max_time_seconds=20,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t;assert root.state is before and root._search_witnesses is witnesses;assert value.nodes+value.qnodes<=nodes;pv=copy(root);pvrows=[]
       for a in value.principal_variation:pv.submit(a);pvrows.append({'full_state_sha256':digest(pv.state),'terminal':record_value(pv.state.terminal_status),'history_last':record_value(pv.state.history[-1])});counts['PV_edges']+=1
       ch=copy(root);ch.submit(value.action);out={**spec,'status':'returned','construction_seconds':construction,'actual_choose_seconds':wall,'decision':record_value(value),'PV_states':pvrows,'selected_full_state':record_value(ch.state),'parent_and_witnesses_preserved':True,'native_provider_created':player.native_legality_provider is not None}
      except Exception as e:out={**spec,'status':'error','error':{'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()},'parent_and_witnesses_preserved':root.state is before and root._search_witnesses is witnesses};counts['errors']+=1;print('ERROR',spec,type(e).__name__,str(e),flush=True)
      rows.append(out);f.write((json.dumps(out)+'\n').encode());f.flush();assert f.tell()<plan['max_events_bytes'];print(i,ply,nodes,native,out['status'],None if out['status']=='error'else(value.completed_depth,value.termination_reason,value.score,round(wall,3)),flush=True)
 except(TimeoutError,InterruptedError)as e:ending=type(e).__name__+':'+str(e)
for name,value in [('frontiers',frontiers),('paths',paths)]:
 with(D/(name+'.json')).open('xb')as f:f.write(json.dumps(value,indent=2).encode())
with(D/'results.json').open('xb')as f:f.write(json.dumps({'complete':ending=='complete','ending':ending,'rows':rows,'executed_calls':len(rows),'planned_max_slots':96,'counts':dict(counts),'seconds':time.perf_counter()-start,'scope':'Twelve explicitly recombined8x8semantic rules, actual full prefix/PV/caller/effects, no full generated-domain coverage or learned-price/WDL/strength claim.'},indent=2).encode())
print('DONE',len(rows),dict(counts),time.perf_counter()-start,flush=True)
