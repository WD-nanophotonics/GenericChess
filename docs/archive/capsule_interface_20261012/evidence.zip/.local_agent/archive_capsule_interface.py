"""Archive only explicit synthetic research folders and reviewed source."""
import hashlib,json,zipfile
from pathlib import Path
b=Path('.local_agent');folders=['capsule-interface-20261012','capsule-interface-d2-20261012','capsule-decode-d2-20261012','core-semantic-caller-20261012','capsule-inventory-20261012','capsule-inventory-d2-20261012','capsule-inventory-effects-20261012','capsule-inventory-delivery-20261012','capsule-inventory-profile-20261012','capsule-inventory-profile-fixed-20261012','capsule-terminal-prefix-20261012','capsule-terminal-prefix-d2-20261012','core-semantic-caller-profile-20261012','core-semantic-caller-profile-fixed-20261012']
files=[]
for folder in folders:
 for p in (b/folder).rglob('*'):
  if p.is_file() and p.suffix in ('.json','.py','.c','.log'):files.append(p)
files.extend(p for pattern in ('capsule*20261012.log','core-semantic*20261012.log') for p in b.glob(pattern))
files.extend([b/'verify_capsule_delivery.py',b/'generated_thin_q4.py',b/'archive_capsule_interface.py'])
files.extend(Path('scripts').glob('native_capsule_*.py'));files.extend(Path('scripts').glob('capsule_*.py'));files.extend(Path('scripts').glob('core_semantic_caller*.py'))
source=['generic_chess/_native/native_module.c','generic_chess/_native/native_semantic_runtime.c','generic_chess/_native/native_semantic_state.h','generic_chess/native/semantic.py','generic_chess/native/compiler.py','generic_chess/native/adapter.py','generic_chess/native/mirror.py','generic_chess/ai/alphabeta/native_legality.py','generic_chess/ai/alphabeta/ordering.py','generic_chess/ai/alphabeta/search.py','generic_chess/core/terminal.py','generic_chess/ai/evaluation/semantic_attacks.py','scripts/full_q_refresh_comparison.py','scripts/search_backend_comparison.py','scripts/chess_development.py','scripts/research_record.py','tests/development/test_capsule_path_runtime.py','tests/product/test_qsearch_semantic_effects.py','tests/rule_semantics_ir_fixtures.py']
files.extend(Path(p) for p in source);files=sorted(set(files),key=lambda p:p.as_posix());members=[]
for p in files:
 assert p.exists(),p
 assert not any(s in p.as_posix().lower() for s in ('private','slack','session.json','next_work','credential','handoff'))
 raw=p.read_bytes();members.append(dict(path=p.as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
prior={'docs/archive/q4_tradeoff_20261011/evidence.zip':'ae4216f8070db29f91726e314e7d607c4ccb1a7873f7d29b256b754e248031af','docs/archive/native_terminal_binding_20261011/evidence.zip':'50fb3f4cc5672dbce288f1cd5115bf59782543824aba767914d910ee49efe072'}
for p,h in prior.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
archive=Path('docs/archive/capsule_interface_20261012/evidence.zip');archive.parent.mkdir(parents=True,exist_ok=True);assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.writestr(p.as_posix(),p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(members)
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
index=dict(schema=1,base_sha='1961c01b4911068e495cceb09f315b824acb0e20',science_complete=False,scope='Agent-only synthetic exposed-rule experiments, source/producers, preserved exact declared source versions and failure scope. No rawSlack/private/user inputs, sessions/memo or binaries. Research capsule is not product/PVE/default replacement.',archive=dict(path=archive.as_posix(),bytes=archive.stat().st_size,uncompressed_bytes=sum(m['bytes'] for m in members),members=len(members),sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),prior_archives_unchanged=prior,validation=json.loads((b/'capsule-interface-20261012/final_validation.json').read_bytes()),limits=['Corecaller dependency hashes observed after startup except producer','Inventory-only binary hash observed after fixedD2 startup, before shared-deadline calls','Terminal prefix comparison uses sequential source phases, not counterbalanced binaries','Decoder/profile/verifier setup failures and premature checkpoint correction retained; no frozen evidence rewritten','Actual experiment wall/work/calls/bytes measured; engineering/model tokens not independently metered','Profile inclusive costs overlap; finite controls do not prove full generic domain or strength'],members=members)
Path('docs/research/data/capsule_interface_20261012.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(json.dumps(index['archive']))
