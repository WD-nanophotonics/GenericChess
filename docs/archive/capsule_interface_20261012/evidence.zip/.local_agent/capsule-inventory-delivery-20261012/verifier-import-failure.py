import json,collections
from pathlib import Path
from scripts.research_record import write_record
b=Path('.local_agent/capsule-inventory-delivery-20261012');data=json.loads((b/'result.json').read_text());assert data['complete'] and len(data['rows'])==32
pairs=[];reasons=collections.Counter();depths=collections.Counter();bad=[]
for r in data['rows']:
 assert r['root_restored'] and r['visits']<=100000
 assert r['visits']==sum(e['work'].get('main',0)+e['work'].get('q',0) for e in r['events'])
 complete=[e for e in r['events'] if e['reason']=='complete']
 assert r['completed_depth']==(complete[-1]['depth'] if complete else 0)
 if complete:assert r['action']==complete[-1]['action'] and r['score']==complete[-1]['score']
 else:assert r['score'] is None and r['result_source']=='legal_fallback'
 for e in r['events']:
  assert e['root_restored'] and e['work']['physical_push']==e['work']['physical_pop']
  reasons[e['reason']]+=1
 depths[(r['seed'],r['seconds'],r['mode'],r['completed_depth'])]+=1
for i in range(0,32,2):
 a,z=data['rows'][i:i+2];assert (a['seed'],a['seconds'],a['order'])==(z['seed'],z['seconds'],z['order'])
 base=next(x for x in (a,z) if x['mode']=='projected-inventory');new=next(x for x in (a,z) if x['mode']=='native-summary')
 if base['completed_depth']==new['completed_depth']:assert base['action']==new['action'] and base['score']==new['score']
 common=min(base['completed_depth'],new['completed_depth'])
 for depth in range(1,common+1):
  u=next(e for e in base['events'] if e['depth']==depth);v=next(e for e in new['events'] if e['depth']==depth)
  assert all(u[k]==v[k] for k in ('action','score','work','trace'))
 pairs.append({'seed':base['seed'],'seconds':base['seconds'],'order':base['order'],'projected_depth':base['completed_depth'],'summary_depth':new['completed_depth'],'same_depth_decision_equal':base['completed_depth']==new['completed_depth'],'baseline_seconds':base['caller_seconds'],'summary_seconds':new['caller_seconds'],'partial_reasons':[base['events'][-1]['reason'],new['events'][-1]['reason']]})
write_record(b/'verified.json',{'complete':True,'pairs':pairs,'event_reasons':dict(reasons),'elapsed_seconds':data['elapsed_seconds'],'deadline_max_overshoot':max(r['caller_seconds']-r['seconds'] for r in data['rows']),'scope':'One global caller deadline and total visits across iterations; only last complete root selected. Common completed depth exact action/score/work/trace. Normal concurrent load, two exposed roots; deeper q support does not establish action quality or strength.'})
for p in pairs:print(p)
print('event reasons',dict(reasons),'elapsed',data['elapsed_seconds'])
