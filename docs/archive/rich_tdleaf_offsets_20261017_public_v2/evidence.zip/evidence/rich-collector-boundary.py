from pathlib import Path
import json,sys,runpy,math
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path('tests').resolve()))
from dataclasses import replace
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.learning.selfplay import collect_self_play,SelfPlayConfig
from generic_chess.learning.features import material_features,spatial_occupancy_features,localized_control_features,linear_value
from generic_chess.learning.tdleaf import _normalized_value
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from tools.local_agent.common import write_json
D=Path('.local_agent/td-tree-20261017');rule=replace(make_ruleset(4,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1)))],lines=['...k','....','R...','K...']),max_ply=64);c=compile_legacy_ruleset_for_semantic_execution(rule);native=compile_native_semantic_rules(c)
base=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,board_weights={'R':1.},hand_weights={'R':1.},value_scale=10.,reference_median=1.)
# Fixed unfitted zero-sum rows, all supported types, including anchors. Not a performance candidate.
spatial={f'{owner}:{t}':tuple(([1.+owner]+[0.]*7+[-1.-owner])if t=='K'else[0.]*9)for owner in(0,1)for t in native.type_ids}
cp=replace(base,spatial_occupancy_weights=spatial);cp.validate_ruleset(c)
t,=collect_self_play(c,native,cp,SelfPlayConfig(games=1,nodes_per_move=1000,max_depth=1,max_plies=1,epsilon=0.))
p=t.points[0];s=GameSession(c).state
for a in p.pv:s=apply_action(s,a,c)
f=material_features(s.position,('R',));occupancy=spatial_occupancy_features(s.position,tuple(native.type_ids));control=localized_control_features(s.position,c)
value=linear_value(f,cp.board_weights,cp.hand_weights,spatial_occupancy=occupancy,spatial_occupancy_weights=cp.spatial_occupancy_weights,localized_control=control,localized_control_weights=cp.localized_control_weights)
write_json(D/'rich-collector-boundary.json',dict(status='OBSERVED',scope='One actual Native semantic D1 PV from current collector with valid v3 checkpoint and predeclared unfitted zero-sum anchor location rows. Not a learned model or broader learner correctness claim.',point_leaf_value=p.leaf_value,full_v3_python_prediction=math.tanh(value/cp.value_scale),full_raw=value,terminal_marker=p.leaf_terminal_z,truncated=t.truncated,bootstrap=t.bootstrap_value,pv_actions=len(p.pv),finding='Current collector/trainer only carry material+dynamic features; v3 tables can be preserved without their contribution in recorded/recomputed prediction. Existing v3 TD test checks table preservation only. No patch/unsupported rejection introduced before assessing compatibility/consumer intent.'))
print((D/'rich-collector-boundary.json').read_text(encoding='utf8'))
