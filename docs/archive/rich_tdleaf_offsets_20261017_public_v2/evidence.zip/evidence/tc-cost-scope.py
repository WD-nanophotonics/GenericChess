from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path('.local_agent/td-tree-20261017');r=json.loads((D/'tc-impulse.json').read_bytes());counts=[x['terms']for x in r['records']]
write_json(D/'tc-cost-scope.json',dict(episodes=len(counts),residual_terms=sum(counts),free_coordinates=4,credit_coordinate_products=4*sum(counts),all_same_sequence_prediction_pairs_direct=sum(n*(n+1)//2 for n in counts),max_sequence_predictions=max(counts)+1,decision='TC N/A accumulator is four coordinate additions per existing recommended term; direct prediction-decay quality construction uses all within-sequence pairs and then fits a weighted exponential. This is operation-count scope on existing receipts, not measured implementation runtime or automatic adoption. Coherence cancellations can reflect bias/opponent/policy change or model inadequacy, not proof that updates are noise or weights optimal.'))
print(json.dumps(json.loads((D/'tc-cost-scope.json').read_bytes()),indent=2))
