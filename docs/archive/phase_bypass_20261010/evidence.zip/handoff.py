from pathlib import Path
import sys,time,hashlib,json
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests/development')]
from test_reserve_refresh_diagnostic import fixture
from scripts.reserve_refresh_diagnostic import make_refresh,ORIGINAL,stopped
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.budget import ThinkingConfig,ThinkingStrategy
from generic_chess.clock import TimeControl,TimeControlMode
from generic_chess.ui.controller import UIController
from generic_chess.ui.match import MatchConfig,ParticipantKind
from generic_chess.ui.stores import DictSettingsStore
B=ROOT/'.local_agent/phase-bypass-20261010'
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[]);start=time.perf_counter()
for policy in ('clear','phase_bypass'):
 for cause in ('begin','complete','stale_root','node_limit'):
  stopped();assert time.perf_counter()-start<120
  s,e,b=fixture();ctrl=UIController(settings=DictSettingsStore());assert ctrl.new_game_from_builtin('western_chess')
  ctrl._session=s;ctrl._compiled=s.compiled
  ctrl.start_match(MatchConfig((ParticipantKind.AI,ParticipantKind.HUMAN),TimeControl(mode=TimeControlMode.NONE),ThinkingConfig(strategy=ThinkingStrategy.FIXED_NODES,preset='quick')))
  token=CancellationToken();snapshot=ctrl.capture_ai_search(token);assert snapshot is not None
  initial=s.state;w=s._search_history_witnesses;events=[]
  baseline=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False).choose_action(s,SearchLimits(max_depth=1,max_time_seconds=5))
  assert baseline.completed_depth==1
  cap=baseline.nodes+baseline.qnodes+2 if cause=='node_limit' else 1000000
  pm.run_root_search=make_refresh(events,token=token,cancel_phase=cause if cause in ('begin','complete') else None,expected_state=initial,tt_policy=policy)
  try:d=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False).choose_action(s,SearchLimits(max_depth=2,max_nodes=cap,max_time_seconds=5),cancel_token=token)
  finally:pm.run_root_search=ORIGINAL
  assert s.state==initial and s._search_history_witnesses==w
  if cause=='stale_root':s.submit(next(a for a in s.legal_actions() if a!=d.action));assert not token.is_cancelled()
  before=s.state;history=len(ctrl.history_entries());committed=ctrl.finish_ai_move(d,snapshot)
  assert committed==(cause=='node_limit')
  if not committed:assert s.state==before and len(ctrl.history_entries())==history
  else:assert len(ctrl.history_entries())==history+1
  r['rows'].append(dict(policy=policy,cause=cause,cap=cap,decision=record_value(d),events=events,committed=committed,token_cancelled=token.is_cancelled(),root_restored_before_handoff=True,unchanged_on_rejection=s.state==before if not committed else None))
  write_record(B/'handoff.json',r);print(policy,cause,d.completed_depth,d.termination_reason,committed,flush=True)
r.update(complete=True,wall=time.perf_counter()-start);write_record(B/'handoff.json',r)
