from pathlib import Path
import sys,time,inspect,textwrap,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/phase-bypass-20261010'
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],construction=[])
try:
 for name in tuple(c['id'] for c in CASES):
  case=next(c for c in CASES if c['id']==name)
  compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  tick=time.perf_counter();plan=compiled._actor_capture_patterns
  r['construction'].append(dict(case=name,container_bytes=sys.getsizeof(plan)+sum(sys.getsizeof(v) for v in plan.values())))
  for arm in ('old','plan','plan','old'):
   stopped();object.__setattr__(compiled,'_actor_capture_patterns',None if arm=='old' else plan)
   d=minimal_ab(CoreBoard(case,compiled),2,seconds=30,node_limit=100000,cooperative=True)
   r['rows'].append(dict(case=name,arm=arm,**d));write_record(B/'actor-installed.json',r);print(name,arm,d['wall_seconds'],flush=True)
 r['complete']=True;write_record(B/'actor-installed.json',r)
finally:
 if 'compiled' in globals():object.__setattr__(compiled,'_actor_capture_patterns',plan)
