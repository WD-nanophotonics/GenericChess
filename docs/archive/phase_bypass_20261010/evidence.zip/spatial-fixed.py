from pathlib import Path
import sys,time,inspect,textwrap,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from generic_chess.core import semantic_executor as se
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/phase-bypass-20261010';old=se.SemanticEngine._spatial_ok
old_source=textwrap.dedent(inspect.getsource(old))
(B/'spatial-original-function.py').write_bytes(old_source.encode())
source="""def _spatial_ok(self,sel,idx,position,binding,perspective,checkpoint=None):
    shape=self.support.board_shape
    # Retain legacy validation/exception order for invalid carrier indices.
    if isinstance(idx,int) and 0 <= idx < shape.area:
        if sel.kind=='zone':
            zone=self.ir.zones.get(sel.zone_id)
            return zone is not None and idx in zone.squares
        if sel.kind in ('same_file','same_rank','exact'):
            # Resolve at the same predicate point; never eagerly before owner/type.
            ref=_resolve_square_ref(sel.refs[0],self.support,self.ir.aux_slots,position,perspective,binding)
            if ref is None:return False
            if isinstance(ref,int) and 0 <= ref < shape.area:
                if sel.kind=='same_file':return idx % shape.width==ref % shape.width
                if sel.kind=='same_rank':return idx // shape.width==ref // shape.width
                return idx==ref
            # Original conversion owns unusual reference error semantics.
    return _old_spatial(self,sel,idx,position,binding,perspective,checkpoint)
"""
ns=dict(se.__dict__);ns['_old_spatial']=old;exec(source,ns);new=ns['_spatial_ok']
(B/'spatial-candidate-function.py').write_bytes(source.encode())
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
try:
 for case in CASES:
  c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  for arm in ('old','scalar','scalar','old'):
   stopped();se.SemanticEngine._spatial_ok=old if arm=='old' else new
   d=minimal_ab(CoreBoard(case,c),2,seconds=30,node_limit=100000,cooperative=True)
   r['rows'].append(dict(case=case['id'],arm=arm,**d));write_record(B/'spatial-fixed.json',r);print(case['id'],arm,d['wall_seconds'],flush=True)
 r['complete']=True;write_record(B/'spatial-fixed.json',r)
finally:se.SemanticEngine._spatial_ok=old
