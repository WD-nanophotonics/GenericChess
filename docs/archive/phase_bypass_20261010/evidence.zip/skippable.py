from pathlib import Path
import sys,time,copy,hashlib,json
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.reserve_refresh_diagnostic import ORIGINAL,make_refresh,stopped,PHASE_MODIFIED
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.transposition import BoundType
from scripts.research_record import write_record,record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
B=ROOT/'.local_agent/phase-bypass-20261010';r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),primers=[],rows=[]);start=time.perf_counter()
code=PHASE_MODIFIED.replace('    for depth in range(1, max_depth + 1):',"""    budget.check(stats, force=True)
    skip_refresh = False
    if use_tt and runtime.tt_eligible:
        stats.position_keys_computed += 1
        stats.tt_probes += 1
        warm_entry = tt.probe(runtime.search_key())
        if warm_entry is not None:
            stats.tt_hits += 1
            skip_refresh = warm_entry.bound is BoundType.EXACT and warm_entry.depth >= 2
    _skip_log.append(skip_refresh)
    for depth in range(1, max_depth + 1):""").replace('use_tt if depth > 1 or ctx.qdepth_limit == 0 else False','use_tt if skip_refresh or depth > 1 or ctx.qdepth_limit == 0 else False').replace('if depth == 1 and ctx.qdepth_limit > 0 and best.declaration is None:', 'if not skip_refresh and depth == 1 and ctx.qdepth_limit > 0 and best.declaration is None:')
(B/'skippable-function.py').write_text(code,encoding='utf-8')
def candidate(events,initial,skip_log):
    f=make_refresh(events,expected_state=initial,tt_policy='phase_bypass')
    ns=f.__globals__.copy();ns['_skip_log']=skip_log
    exec(compile(code,'<skippable-diagnostic>','exec'),ns)
    return ns['run_root_search']

try:
 for name in ('chess-middle','chess-ep','shogi-middle'):
  stopped();case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses;initial=s.state;w=s._search_history_witnesses
  primer=AlphaBetaPlayer(c,evaluator_override=b.material,use_native_semantic_legality=False);token=CancellationToken();pm.run_root_search=ORIGINAL
  def progress(depth,*_):
   if depth>=2:token.cancel()
  d=primer.choose_action(s,SearchLimits(max_depth=3,max_time_seconds=10,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token,progress_callback=progress)
  assert s.state==initial and s._search_history_witnesses==w
  r['primers'].append(dict(root=name,decision=record_value(d),cancelled=token.is_cancelled(),entries=len(primer._tt),context='same_uncommitted_root_after_progress_cancel',qdepths=primer._tt_q_depths));write_record(B/'skippable.json',r)
  if d.completed_depth<2 or not token.is_cancelled():print(name,'UNKNOWN prime',flush=True);continue
  snapshot=copy.deepcopy(primer._tt)
  for seconds in (.05,.1,1):
   for arm in ('baseline','skippable','skippable','baseline'):
    stopped();assert time.perf_counter()-start<120;p=copy.copy(primer);p._tt=copy.deepcopy(snapshot);events=[];skip_log=[]
    pm.run_root_search=ORIGINAL if arm=='baseline' else candidate(events,initial,skip_log)
    result=p.choose_action(s,SearchLimits(max_time_seconds=seconds,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    assert s.state==initial and s._search_history_witnesses==w
    r['rows'].append(dict(root=name,seconds=seconds,arm=arm,decision=record_value(result),events=events,skip_log=skip_log,input_entries=len(snapshot),state_restored=True));write_record(B/'skippable.json',r);print(name,seconds,arm,result.completed_depth,result.score,flush=True)
 for name in ('chess-middle','chess-ep','shogi-middle'):
  case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses;initial=s.state
  for arm in ('bypass','skippable'):
   stopped();p=AlphaBetaPlayer(c,evaluator_override=b.material,use_native_semantic_legality=False);events=[];skip_log=[]
   pm.run_root_search=make_refresh(events,expected_state=initial,tt_policy='phase_bypass') if arm=='bypass' else candidate(events,initial,skip_log)
   d=p.choose_action(s,SearchLimits(max_depth=1,max_time_seconds=1,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   assert s.state==initial
   r['rows'].append(dict(root=name,context='cold',arm=arm,decision=record_value(d),events=events,skip_log=skip_log));write_record(B/'skippable.json',r)
 r.update(complete=True,wall=time.perf_counter()-start);write_record(B/'skippable.json',r)
finally:pm.run_root_search=ORIGINAL
