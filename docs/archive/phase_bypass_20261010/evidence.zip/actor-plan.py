from pathlib import Path
import sys,time,inspect,textwrap,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/phase-bypass-20261010'
old=se.SemanticEngine._action_delivers_check;src=textwrap.dedent(inspect.getsource(old));plans={}
anchor='    for pattern in self._patterns:'
assert src.count(anchor)==1
new=src.replace(anchor,'''    _checkpoint(checkpoint)
    indexed = _actor_plans.get(id(self.semantic))
    patterns = self._patterns if indexed is None else indexed.get(piece.current_type_id, ())
    for pattern in patterns:''')
ns=dict(se.__dict__);ns['_actor_plans']=plans;exec(compile(new,'<compiled-actor-capture-plan>','exec'),ns);candidate=ns['_action_delivers_check']
(B/'actor-original-function.py').write_bytes(src.encode());(B/'actor-candidate-function.py').write_bytes(new.encode())
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],construction=[])
try:
 for name in ('shogi-drop','chess-middle','shogi-tactic','shogi-promotion'):
  case=next(c for c in CASES if c['id']==name)
  compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  tick=time.perf_counter();p={}
  for pattern in compiled.ir.patterns:
   if pattern.target.kind=='target_enemy':
    for tid in pattern.type_ids:p.setdefault(tid,[]).append(pattern)
  plans[id(compiled)]={k:tuple(v) for k,v in p.items()}
  r['construction'].append(dict(case=name,seconds=time.perf_counter()-tick,patterns=len(compiled.ir.patterns),indexed_counts={k:len(v) for k,v in p.items()}))
  for arm in ('old','plan','plan','old'):
   stopped();se.SemanticEngine._action_delivers_check=old if arm=='old' else candidate
   d=minimal_ab(CoreBoard(case,compiled),2,seconds=30,node_limit=100000,cooperative=True)
   r['rows'].append(dict(case=name,arm=arm,**d));write_record(B/'actor-plan.json',r);print(name,arm,d['wall_seconds'],flush=True)
 r['complete']=True;write_record(B/'actor-plan.json',r)
finally:se.SemanticEngine._action_delivers_check=old
