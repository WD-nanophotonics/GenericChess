from pathlib import Path
import sys,json,hashlib
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from rule_semantics_ir_fixtures import castling_ruleset
from generic_chess.rules.schema import RuleAuxState,RuleSquareRef,RuleTransitionTrigger
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from scripts.research_record import record_value,write_record
B=ROOT/'.local_agent/phase-bypass-20261010';r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
for scope in ('per_owner','global'):
 for owner in ('self','opponent','any'):
  for token in ((4,0),None,(7,0)):
   rule=castling_ruleset();a=rule.semantic_actions[0]
   mark=RuleAuxState('mark','square_or_none',scope,'persistent',token)
   # Keep the castling-right effects/schema, adding a declared token dependency.
   dynamic=RuleTransitionTrigger('king_right','piece_leaves_square',RuleSquareRef('aux_slot_square',slot_name='mark',owner_relative=False),owner)
   # Old fixed rook leave/removal remain: mixed dispatcher exercises both paths.
   a=replace(a,aux_state=a.aux_state+(mark,),triggers=(dynamic,)+a.triggers[1:])
   rule=replace(rule,semantic_actions=(a,))
   c=compile_ruleset_for_execution(rule);f=replace(c);object.__setattr__(f,'_fixed_transition_triggers',None)
   on=SemanticEngine(c);off=SemanticEngine(f);p=on._initial_position()
   right=next(s for s in c.ir.aux_slots if s.name=='king_right');markslot=next(s for s in c.ir.aux_slots if s.name=='mark')
   frontier=sorted(on.legal_actions(p),key=str);assert frontier==sorted(off.legal_actions(p),key=str)
   children=0
   for action in frontier:
    x=on.apply(p,action);y=off.apply(p,action);assert x==y
    # Restrict independent expected right to simple king legacy moves: no
    # explicit castle clear and no rook auxiliary move can mask dynamic event.
    if action.actor_type_id=='K' and action.from_square is not None and action.pattern_id!='sem_00_king_side_shift':
     aux=dict(x.aux_state);source=(action.from_square.file,action.from_square.rank)
     hit=token==source and owner in ('self','any')
     assert aux.get((right.slot_id,0),right.initial)==(0 if hit else 1)
    # All public child board/hands/aux fields and reply-frontier signatures agree.
    assert sorted(on.legal_actions(x),key=str)==sorted(off.legal_actions(y),key=str)
    children+=1
   r['rows'].append(dict(scope=scope,owner=owner,token=token,frontier=len(frontier),children=children,initial=record_value(p),right_slot=right.slot_id,mark_slot=markslot.slot_id));write_record(B/'public-aux.json',r)
r['complete']=True;write_record(B/'public-aux.json',r);print('rows',len(r['rows']),'children',sum(x['children'] for x in r['rows']))
