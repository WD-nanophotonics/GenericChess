from pathlib import Path
import sys,json,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.reserve_refresh_diagnostic import make_refresh,queen_roots,transfer_roots,ORIGINAL,stopped
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
B=ROOT/'.local_agent/phase-bypass-20261010'
CODE=(ROOT/'.local_agent/reserve-refresh-20261010/warm-retain-function.py').read_text(encoding='utf-8')
def phase(events,token=None,cancel=None,state=None):
    ns=dict(make_refresh(events,token=token,cancel_phase=cancel,expected_state=state).__globals__)
    exec(compile(CODE,'<phase-local-bypass>','exec'),ns)
    return ns['run_root_search']
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),function_sha256=hashlib.sha256(CODE.encode()).hexdigest(),rows=[])
def save():write_record(B/'pilot.json',r)
save();tick=time.perf_counter()
try:
 for name,s,e in list(queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json'))+list(transfer_roots()):
  initial=s.state;history=s._search_history_witnesses;legal=tuple(s.legal_actions())
  cases=[(arm,None,4,1,None) for arm in ('clear','phase','phase','clear')]
  if name.startswith('queen'):
   cases += [('phase',c,4,5,2) for c in ('begin','complete')]+[(arm,None,0,5,2) for arm in ('original','phase')]
  for arm,cancel,q,seconds,depth in cases:
   stopped();assert time.perf_counter()-tick<300
   events=[];token=CancellationToken() if cancel else None
   pm.run_root_search=ORIGINAL if arm=='original' else (phase(events,token,cancel,s.state) if arm=='phase' else make_refresh(events,expected_state=s.state))
   p=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False)
   try:d=p.choose_action(s,SearchLimits(max_depth=depth,max_time_seconds=seconds,max_nodes=1000000,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0),cancel_token=token)
   finally:pm.run_root_search=ORIGINAL
   assert s.state==initial and s._search_history_witnesses==history and d.action in legal
   assert len({x['budget_identity'] for x in events})<=1 and len({x['deadline'] for x in events})<=1
   assert all(x['runtime_restored'] and x['runtime_balanced'] for x in events)
   if cancel:
    keep=next(x for x in events if x['phase']==('reserve' if cancel=='begin' else 'complete'))
    assert d.completed_depth==1 and d.termination_reason=='cancelled' and record_value(d.action)==keep['action'] and d.score==keep['score']
   r['rows'].append(dict(root=name,arm=arm,cancel=cancel,q=q,decision=record_value(d),events=events,restored=True));save()
   print(name,arm,cancel,q,d.completed_depth,d.score,d.termination_reason,flush=True)
 r.update(complete=True,wall=time.perf_counter()-tick);save()
finally:pm.run_root_search=ORIGINAL
