from pathlib import Path
import sys,json,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from scripts.reserve_refresh_diagnostic import transfer_roots,stopped
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.research_record import write_record,record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
base=ROOT/'.local_agent/phase-bypass-20261010';plans={};ns=dict(se.__dict__);ns['_actor_plans']=plans;exec(compile((base/'actor-candidate-function.py').read_text(),'<actor-plan>','exec'),ns);new=ns['_action_delivers_check'];exec(compile((base/'actor-original-function.py').read_text(),'<original-actor>','exec'),ns);old=ns['_action_delivers_check']
roots=[]
for name in ('shogi-drop','chess-middle'):
 case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses;roots.append((name,s,b.material))
roots.extend(transfer_roots());r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((base/'actor-candidate-function.py').read_bytes()).hexdigest(),rows=[])
try:
 for name,s,e in roots:
  start=time.perf_counter();index={}
  for pattern in (() if not hasattr(s.compiled,'ir') else s.compiled.ir.patterns):
   if pattern.target.kind=='target_enemy':
    for tid in pattern.type_ids:index.setdefault(tid,[]).append(pattern)
  plans[id(s.compiled)]={k:tuple(v) for k,v in index.items()};construction=time.perf_counter()-start
  initial=s.state;legal=tuple(s.legal_actions())
  for seconds in (1,4):
   for index,arm in enumerate(('old','new','new','old')):
    stopped();se.SemanticEngine._action_delivers_check=old if arm=='old' else new;p=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False)
    start=time.perf_counter();d=p.choose_action(s,SearchLimits(max_time_seconds=seconds,max_nodes=100000,quiescence_max_depth=4));wall=time.perf_counter()-start
    assert s.state==initial;assert d.action is None or d.action in legal
    r['rows'].append(dict(root=name,seconds=seconds,index=index,arm=arm,wall=wall,construction_seconds=construction,decision=record_value(d)));write_record(base/'actor-time.json',r);print(name,seconds,arm,d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
 r['complete']=True;write_record(base/'actor-time.json',r)
finally:se.SemanticEngine._action_delivers_check=old
