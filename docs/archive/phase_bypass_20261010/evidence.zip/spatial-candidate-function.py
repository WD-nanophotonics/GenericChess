def _spatial_ok(self,sel,idx,position,binding,perspective,checkpoint=None):
    shape=self.support.board_shape
    # Retain legacy validation/exception order for invalid carrier indices.
    if isinstance(idx,int) and 0 <= idx < shape.area:
        if sel.kind=='zone':
            zone=self.ir.zones.get(sel.zone_id)
            return zone is not None and idx in zone.squares
        if sel.kind in ('same_file','same_rank','exact'):
            # Resolve at the same predicate point; never eagerly before owner/type.
            ref=_resolve_square_ref(sel.refs[0],self.support,self.ir.aux_slots,position,perspective,binding)
            if ref is None:return False
            if isinstance(ref,int) and 0 <= ref < shape.area:
                if sel.kind=='same_file':return idx % shape.width==ref % shape.width
                if sel.kind=='same_rank':return idx // shape.width==ref // shape.width
                return idx==ref
            # Original conversion owns unusual reference error semantics.
    return _old_spatial(self,sel,idx,position,binding,perspective,checkpoint)
