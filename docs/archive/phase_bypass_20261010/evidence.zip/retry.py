from pathlib import Path
import sys,time,copy,hashlib,json
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.reserve_refresh_diagnostic import ORIGINAL,make_refresh,stopped
from scripts.research_record import write_record,record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
B=ROOT/'.local_agent/phase-bypass-20261010';r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),primers=[],rows=[]);start=time.perf_counter()
try:
 for name in ('chess-middle','chess-ep','shogi-middle'):
  stopped();case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses;initial=s.state;w=s._search_history_witnesses
  primer=AlphaBetaPlayer(c,evaluator_override=b.material,use_native_semantic_legality=False);token=CancellationToken();pm.run_root_search=ORIGINAL
  def progress(depth,*_):
   if depth>=2:token.cancel()
  d=primer.choose_action(s,SearchLimits(max_depth=3,max_time_seconds=10,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token,progress_callback=progress)
  assert s.state==initial and s._search_history_witnesses==w
  r['primers'].append(dict(root=name,decision=record_value(d),cancelled=token.is_cancelled(),entries=len(primer._tt),context='same_uncommitted_root_after_progress_cancel',qdepths=primer._tt_q_depths));write_record(B/'retry.json',r)
  if d.completed_depth<2 or not token.is_cancelled():print(name,'UNKNOWN prime',flush=True);continue
  snapshot=copy.deepcopy(primer._tt)
  for seconds in (.05,.1,1):
   for arm in ('baseline','bypass','bypass','baseline'):
    stopped();assert time.perf_counter()-start<120;p=copy.copy(primer);p._tt=copy.deepcopy(snapshot);events=[]
    pm.run_root_search=ORIGINAL if arm=='baseline' else make_refresh(events,expected_state=initial,tt_policy='phase_bypass')
    result=p.choose_action(s,SearchLimits(max_time_seconds=seconds,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    assert s.state==initial and s._search_history_witnesses==w
    r['rows'].append(dict(root=name,seconds=seconds,arm=arm,decision=record_value(result),events=events,input_entries=len(snapshot),state_restored=True));write_record(B/'retry.json',r);print(name,seconds,arm,result.completed_depth,result.score,flush=True)
 r.update(complete=True,wall=time.perf_counter()-start);write_record(B/'retry.json',r)
finally:pm.run_root_search=ORIGINAL
