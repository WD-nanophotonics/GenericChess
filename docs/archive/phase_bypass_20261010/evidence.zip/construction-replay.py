from pathlib import Path
import inspect,textwrap,json,time,hashlib,statistics,sys
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tests'))
from generic_chess.rules import ir
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from rule_semantics_ir_fixtures import cannon_ruleset,castling_ruleset,uchifuzume_ruleset,weird_rulesets
from scripts.research_record import write_record
B=ROOT/'.local_agent/phase-bypass-20261010'
source=textwrap.dedent(inspect.getsource(ir.CompiledSemanticRuleset.__post_init__))
remove='        object.__setattr__(self, "_actor_capture_patterns",\n            _actor_capture_patterns(self.ir))\n'
assert source.count(remove)==1
old_source=source.replace(remove,'');ns=dict(ir.__dict__);exec(old_source,ns);old=ns['__post_init__'];new=ir.CompiledSemanticRuleset.__post_init__
r=dict(complete=False,post_init_source_sha256=hashlib.sha256(source.encode()).hexdigest(),rows=[]);start=time.perf_counter()
for name,rule in [('Chess',build_builtin_ruleset('western_chess')),('Shogi',build_builtin_ruleset('standard_shogi')),('cannon',cannon_ruleset()),('castling',castling_ruleset()),('dropmate',uchifuzume_ruleset()),*[(f'weird{i}',x) for i,x in enumerate(weird_rulesets())]]:
 t=[]
 for arm in ['old','new','new','old']*4:
  assert time.perf_counter()-start<300
  ir.CompiledSemanticRuleset.__post_init__=new if arm=='new' else old
  tick=time.perf_counter();c=compile_ruleset_for_execution(rule);duration=time.perf_counter()-tick
  t.append(dict(arm=arm,seconds=duration,metadata_none=c._actor_capture_patterns is None,fingerprint=c.ruleset_fingerprint))
 ir.CompiledSemanticRuleset.__post_init__=new
 c=compile_ruleset_for_execution(rule);tick=time.perf_counter()
 for _ in range(256):p=ir._actor_capture_patterns(c.ir)
 per=(time.perf_counter()-tick)/256
 assert len({x['fingerprint'] for x in t})==1
 means={a:statistics.mean(x['seconds'] for x in t if x['arm']==a) for a in ('old','new')}
 r['rows'].append(dict(rule=name,samples=t,means=means,plan_only_seconds=per,patterns=len(c.ir.patterns),capture_refs=sum(len(x) for x in p.values())))
r.update(complete=True,wall=time.perf_counter()-start,scope='Repeated uncached full product compile after first includes warm shared board-shape interpreter effects;plan-only isolates added constructor helper, not all initialization. Existing semantic compiler constructs twice. No universal cost factor.')
write_record(B/'construction-replay.json',r)
