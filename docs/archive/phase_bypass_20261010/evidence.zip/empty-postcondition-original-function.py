def _violates_postconditions(
    self, pattern, child, checkpoint: Checkpoint | None = None
) -> bool:
    """S4 forbidden-condition conjunction (ADR-016 truth table).

    Postconditions are prohibitions: the candidate is rejected only when
    every present forbidden condition holds.  ``opponent_checked`` is
    evaluated first and short-circuits the conjunction so the C4 reply
    probe does not run when it is false.  Source field order never
    decides semantics or cost."""
    kinds = {pc.kind for pc in pattern.postconditions}
    if not kinds:
        return False
    parent = getattr(self, "_postcondition_parent", None)
    action = getattr(self, "_postcondition_action", None)
    action_checked = (
        "action_delivers_check" in kinds
        and action is not None
        and self._action_delivers_check(
            parent, child, action, checkpoint=checkpoint
        )
    )
    if "action_delivers_check" in kinds and not action_checked:
        return False
    child_checked = "opponent_checked" in kinds and self.in_check(
        child, child.side_to_move, checkpoint=checkpoint
    )
    if "opponent_checked" in kinds and not child_checked:
        return False
    if "no_legal_reply" in kinds and self._exists_s3_reply(
        child, checkpoint=checkpoint
    ):
        return False
    return True
