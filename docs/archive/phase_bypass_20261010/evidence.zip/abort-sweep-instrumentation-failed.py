"""Bounded actual-work abort locations, not wall-time padding or strength."""
from pathlib import Path
import sys,time,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'.local_agent/phase-bypass-20261010'))
# Reconstruct without importing the pilot entrypoint (which executes its batch).
from scripts.reserve_refresh_diagnostic import make_refresh,queen_roots,transfer_roots,stopped
from generic_chess.ai.alphabeta import player as pm,search
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.transposition import TranspositionTable
B=ROOT/'.local_agent/phase-bypass-20261010';CODE=(ROOT/'.local_agent/reserve-refresh-20261010/warm-retain-function.py').read_text(encoding='utf-8');OLD=pm.run_root_search
class ProbeTT(TranspositionTable):
 def __init__(self):super().__init__();self.calls=[]
 def probe(self,key):self.calls.append('probe');return super().probe(key)
 def store(self,*args):self.calls.append('store');return super().store(*args)
 def clear(self):self.calls.append('clear');return super().clear()
def phase(events,state):
 ns=dict(make_refresh(events,expected_state=state).__globals__);exec(compile(CODE,'<phase-local-bypass>','exec'),ns);return ns['run_root_search']
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
start=time.perf_counter()
try:
 roots=list(queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json'))+list(transfer_roots())
 # Unique boundary locations, cold node-only fuses plus a10sec independent safety
 # fuse. Budget values are applied to both policies, not changed from outcomes.
 caps=(4,32,44,45,46,64,96,128,160,192,256,384,512,768)
 for name,s,e in roots:
  for use_tt in (False,True):
   for cap in caps:
    stopped();assert time.perf_counter()-start<600
    rows=[]
    for arm in ('clear','phase'):
     events=[];tt=ProbeTT();p=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False,use_tt=use_tt);p._tt=tt
     pm.run_root_search=make_refresh(events,expected_state=s.state) if arm=='clear' else phase(events,s.state)
     initial=s.state;history=s._search_history_witnesses
     try:d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=cap,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8))
     finally:pm.run_root_search=OLD
     assert s.state==initial and s._search_history_witnesses==history
     assert all(x['runtime_restored'] and x['runtime_balanced'] for x in events)
     if arm=='phase' and (not use_tt or d.completed_depth<=1):assert not tt.calls
     rows.append(dict(arm=arm,decision=record_value(d),events=events,tt_calls=tt.calls))
    r['rows'].append(dict(root=name,use_tt=use_tt,node_cap=cap,arms=rows));write_record(B/'abort-sweep.json',r)
   print(name,use_tt,'done',flush=True)
 r.update(complete=True,wall=time.perf_counter()-start);write_record(B/'abort-sweep.json',r)
finally:pm.run_root_search=OLD
