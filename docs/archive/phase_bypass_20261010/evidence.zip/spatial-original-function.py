def _spatial_ok(
    self, sel, idx, position, binding, perspective,
    checkpoint: Checkpoint | None = None,
) -> bool:
    sq = index_to_square(idx, self.support.board_shape)
    if sel.kind == "same_file":
        ref_sq = self._ref_square(sel.refs[0], position, binding, perspective)
        return ref_sq is not None and ref_sq.file == sq.file
    if sel.kind == "same_rank":
        ref_sq = self._ref_square(sel.refs[0], position, binding, perspective)
        return ref_sq is not None and ref_sq.rank == sq.rank
    if sel.kind == "exact":
        ref_sq = self._ref_square(sel.refs[0], position, binding, perspective)
        return ref_sq is not None and ref_sq == sq
    if sel.kind == "adjacent":
        ref_sq = self._ref_square(sel.refs[0], position, binding, perspective)
        return (
            ref_sq is not None
            and max(abs(ref_sq.file - sq.file), abs(ref_sq.rank - sq.rank)) == 1
        )
    if sel.kind == "path_between":
        a = self._ref_square(sel.refs[0], position, binding, perspective)
        b = self._ref_square(sel.refs[1], position, binding, perspective)
        if a is None or b is None:
            return False
        df = b.file - a.file
        dr = b.rank - a.rank
        g = gcd(abs(df), abs(dr))
        if g <= 1:
            return False
        step_f, step_r = df // g, dr // g
        for k in range(1, g):
            _checkpoint(checkpoint)
            if sq.file == a.file + k * step_f and sq.rank == a.rank + k * step_r:
                return True
        return False
    if sel.kind == "zone":
        zone = self.ir.zones.get(sel.zone_id)
        return zone is not None and idx in zone.squares
    return False
