from pathlib import Path
import sys,time,inspect,textwrap,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from generic_chess.core import semantic_executor as se
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/phase-bypass-20261010';old=se.SemanticEngine._violates_postconditions
old_source=textwrap.dedent(inspect.getsource(old));source=old_source.replace('    kinds = {pc.kind for pc in pattern.postconditions}', '    if not pattern.postconditions:\n        return False\n    kinds = {pc.kind for pc in pattern.postconditions}')
assert source!=old_source
(B/'empty-postcondition-original-function.py').write_bytes(old_source.encode());(B/'empty-postcondition-candidate-function.py').write_bytes(source.encode())
ns=dict(se.__dict__);exec(source,ns);new=ns['_violates_postconditions']
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
try:
 for case in CASES:
  c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  for arm in ('old','empty_skip','empty_skip','old'):
   stopped();se.SemanticEngine._violates_postconditions=old if arm=='old' else new
   d=minimal_ab(CoreBoard(case,c),2,seconds=30,node_limit=100000,cooperative=True)
   r['rows'].append(dict(case=case['id'],arm=arm,**d));write_record(B/'empty-postcondition-fixed.json',r);print(case['id'],arm,d['wall_seconds'],flush=True)
 r['complete']=True;write_record(B/'empty-postcondition-fixed.json',r)
finally:se.SemanticEngine._violates_postconditions=old
