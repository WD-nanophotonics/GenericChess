from pathlib import Path
import sys,time,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from test_rectangular_semantic_action_b4b import _rectangular_single_capture_ruleset
from rule_semantics_ir_fixtures import cannon_ruleset,castling_ruleset,en_passant_ruleset,nifu_ruleset,uchifuzume_ruleset,weird_rulesets
from generic_chess import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.limits import SearchLimits
from scripts.reserve_refresh_diagnostic import make_refresh,ORIGINAL,stopped
from scripts.research_record import record_value,write_record
B=ROOT/'.local_agent/phase-bypass-20261010';r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[]);start=time.perf_counter()
class Unit:
 def __init__(self,c):self.c=c
 def type_value(self,t):return 0 if self.c.types_by_id[t].is_anchor else 100
 def evaluate(self,state):
  p=state.position
  return sum((1 if x.owner==p.side_to_move else -1)*self.type_value(x.current_type_id) for x in p.board if x is not None)+sum((1 if o==p.side_to_move else -1)*self.type_value(t)*n for o,h in enumerate(p.hands) for t,n in h.items())
 def capture_order_value(self,m,c):return 10*self.type_value(c.current_type_id)-self.type_value(m.current_type_id)
try:
 rules=(_rectangular_single_capture_ruleset(),)
 for i,rule in enumerate(rules):
  c=compile_ruleset_for_execution(rule);s=GameSession(c);e=Unit(c);initial=s.state;w=s._search_history_witnesses;legal=tuple(s.legal_actions())
  for q,arm in [(4,x) for x in ('clear','phase_bypass','phase_bypass','clear')]+[(0,'baseline'),(0,'phase_bypass')]:
   stopped();assert time.perf_counter()-start<300;events=[]
   pm.run_root_search=ORIGINAL if arm=='baseline' else make_refresh(events,expected_state=initial,tt_policy=arm)
   d=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=False).choose_action(s,SearchLimits(max_depth=2,max_time_seconds=2,max_nodes=100000,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
   assert s.state==initial and s._search_history_witnesses==w and (d.action is None or d.action in legal)
   assert all(x['runtime_restored'] and x['runtime_balanced'] for x in events)
   r['rows'].append(dict(rule=i,shape=[c.board_shape.width,c.board_shape.height],q=q,arm=arm,decision=record_value(d),events=events,state_restored=True));write_record(B/'mechanism-rectangle.json',r);print(i,q,arm,d.completed_depth,d.termination_reason,flush=True)
 r.update(complete=True,wall=time.perf_counter()-start);write_record(B/'mechanism-rectangle.json',r)
finally:pm.run_root_search=ORIGINAL
