def __post_init__(self):
    # Derived execution data is not part of the IR/fingerprint/payload.
    # init=False also rebuilds it when dataclasses.replace changes IR.
    if self.support is not None and self.ir.capabilities.new_ir_core_executable:
        object.__setattr__(self, "_incoming_attack_paths",
            _incoming_attack_paths(self.ir, self.support.board_shape.area))
        if self.ir.triggers:
            object.__setattr__(self, "_fixed_transition_triggers",
                _fixed_transition_triggers(self.ir, self.support))
