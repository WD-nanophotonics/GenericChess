from pathlib import Path
import sys,time,json,hashlib
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import semantic_executor as se
from rule_semantics_ir_fixtures import cannon_ruleset,castling_ruleset,en_passant_ruleset,nifu_ruleset,uchifuzume_ruleset,weird_rulesets
from scripts.search_backend_comparison import CoreBoard,CASES
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/phase-bypass-20261010';ns=dict(se.__dict__)
exec(compile((B/'actor-original-function.py').read_text(),'<original-actor>','exec'),ns);old=ns['_action_delivers_check']
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[]);roots=[]
for case in CASES:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
 b=CoreBoard(case,c);roots.append((case['id'],c,b.initial.position))
for i,rule in enumerate((cannon_ruleset(),castling_ruleset(),en_passant_ruleset(),nifu_ruleset(),uchifuzume_ruleset(),*weird_rulesets())):
 c=compile_ruleset_for_execution(rule);roots.append((f'mechanism-{i}',c,se.SemanticEngine(c)._initial_position()))
start=time.perf_counter()
for name,c,parent in roots:
 stopped();assert time.perf_counter()-start<300
 e=se.SemanticEngine(c);f=replace(c);object.__setattr__(f,'_actor_capture_patterns',None);fallback=se.SemanticEngine(f)
 actions=e.legal_actions(parent);assert actions==fallback.legal_actions(parent)
 positive=0;probes=0;cancelled=0
 for action in actions:
  child=e.apply(parent,action);assert child==fallback.apply(parent,action)
  actual=e._action_delivers_check(parent,child,action);assert actual==old(e,parent,child,action)==fallback._action_delivers_check(parent,child,action)
  positive+=actual;probes+=1
  # Direct cancellation must still interrupt a traversable actor witness;
  # no-anchor/no-actor short-circuit cases are tracked rather than relabeled.
  def cancel():raise InterruptedError('actor audit stop')
  def outcome(fn):
   try:return ('value',fn(parent,child,action,checkpoint=cancel))
   except InterruptedError:return ('cancelled',)
  a=outcome(e._action_delivers_check);b=outcome(fallback._action_delivers_check)
  assert a==b;cancelled+=a==('cancelled',)
 size=sys.getsizeof(c._actor_capture_patterns)+sum(sys.getsizeof(v) for v in c._actor_capture_patterns.values())
 r['rows'].append(dict(root=name,frontier=len(actions),checked_children=probes,positive_actor_checks=positive,cancelled=cancelled,owned_container_bytes=size,borrowed_pattern_references=sum(len(v) for v in c._actor_capture_patterns.values()),fingerprint_unchanged=c.ir.fingerprint()==f.ir.fingerprint()))
 write_record(B/'actor-audit.json',r);print(name,len(actions),positive,cancelled,size,flush=True)
r.update(complete=True,wall=time.perf_counter()-start);write_record(B/'actor-audit.json',r)
