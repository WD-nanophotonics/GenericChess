from pathlib import Path
import sys,copy,json,time,hashlib
from dataclasses import replace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.reserve_refresh_diagnostic import ORIGINAL,make_refresh,stopped
from scripts.search_backend_comparison import CoreBoard,CASES
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.transposition import BoundType,TranspositionTable
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.rules.schema import RuleRepeatedCycleTargetCondition
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
B=ROOT/'.local_agent/skippable-contract-20261011';CODE=(ROOT/'.local_agent/phase-bypass-20261010/skippable-function.py').read_text()
def candidate(events,skip_log,s):
 f=make_refresh(events,expected_state=s.state,tt_policy='phase_bypass');ns=f.__globals__.copy();ns['_skip_log']=skip_log
 exec(compile(CODE,'<declared-skippable>','exec'),ns);return ns['run_root_search']
class TraceTT(TranspositionTable):
 def probe(self,key):
  self.trace.append(['probe',repr(key)]);return super().probe(key)
 def store(self,*args):
  self.trace.append(['store',args[1],args[3].name]);return super().store(*args)
def table(src):
 t=TraceTT();t._data=copy.deepcopy(src._data);t._generation=src._generation;t.trace=[];return t
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),function_sha256=hashlib.sha256(CODE.encode()).hexdigest(),primers=[],rows=[]);start=time.perf_counter()
def save():write_record(B/'contract.json',r)
try:
 for name in ('chess-middle','shogi-middle'):
  case=next(c for c in CASES if c['id']==name);rules=build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi');c=compile_ruleset_for_execution(rules);b=CoreBoard(case,c);s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses;initial=s.state;w=s._search_history_witnesses
  primer=AlphaBetaPlayer(c,evaluator_override=b.material,use_native_semantic_legality=False);token=CancellationToken();pm.run_root_search=ORIGINAL
  d=primer.choose_action(s,SearchLimits(max_depth=3,max_time_seconds=10,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token,progress_callback=lambda depth,*_:token.cancel() if depth>=2 else None)
  assert d.completed_depth==2 and token.is_cancelled();assert s.state==initial and s._search_history_witnesses==w
  key=SearchPathRuntime.from_state(s.state,c,history_witnesses=w).search_key();root=primer._tt.probe(key);assert root and root.bound is BoundType.EXACT and root.depth>=2
  r['primers'].append(dict(root=name,decision=record_value(d),entry_depth=root.depth,bound=root.bound.name));save()
  for condition in ('deep_exact','shallow_exact','deep_lower','deep_upper','caller_false','q_changed','qzero'):
   for arm in ('bypass','skippable') if condition!='qzero' else ('baseline','skippable'):
    stopped();assert time.perf_counter()-start<120;p=copy.copy(primer);p._tt=table(primer._tt);entry=p._tt._data[key]
    if condition=='shallow_exact':entry.depth=1
    if condition=='deep_lower':entry.bound=BoundType.LOWER
    if condition=='deep_upper':entry.bound=BoundType.UPPER
    if condition=='caller_false':p._use_tt=False
    q=2 if condition=='q_changed' else 0 if condition=='qzero' else 4
    if condition=='qzero':p._tt_q_depths=(0,0)
    events=[];skips=[];pm.run_root_search=ORIGINAL if arm=='baseline' else make_refresh(events,expected_state=initial,tt_policy='phase_bypass') if arm=='bypass' else candidate(events,skips,s)
    d=p.choose_action(s,SearchLimits(max_depth=1,max_time_seconds=.5,max_nodes=1000000,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
    assert s.state==initial and s._search_history_witnesses==w
    r['rows'].append(dict(root=name,condition=condition,arm=arm,decision=record_value(d),events=events,skip_log=skips,trace=p._tt.trace,root_restored=True));save();print(name,condition,arm,skips,len(p._tt.trace),d.completed_depth,flush=True)
 # Actual repeated-cycle terminal policy disables runtime TT eligibility.
 rules=replace(build_builtin_ruleset('western_chess'),repeated_cycle_target_conditions=(RuleRepeatedCycleTargetCondition(actor=0),));c=compile_ruleset_for_execution(rules);s=GameSession(c);rt=SearchPathRuntime.from_state(s.state,c);assert not rt.tt_eligible
 b=CoreBoard(dict(game='chess',setup='start',moves=''),c)
 for arm in ('bypass','skippable'):
  stopped();events=[];skips=[];p=AlphaBetaPlayer(c,evaluator_override=b.material,use_native_semantic_legality=False);p._tt=TraceTT();p._tt.trace=[];p._tt_q_depths=(4,8);p._tt.store(rt.search_key(),2,0,BoundType.EXACT,None);p._tt.trace=[]
  pm.run_root_search=make_refresh(events,expected_state=s.state,tt_policy='phase_bypass') if arm=='bypass' else candidate(events,skips,s);initial=s.state
  d=p.choose_action(s,SearchLimits(max_depth=1,max_time_seconds=.5,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8));assert s.state==initial
  r['rows'].append(dict(root='repeated-cycle-ineligible',condition='ineligible',arm=arm,decision=record_value(d),events=events,skip_log=skips,trace=p._tt.trace,root_restored=True));save();print('ineligible',arm,skips,len(p._tt.trace),flush=True)
 r.update(complete=True,wall=time.perf_counter()-start);save()
finally:pm.run_root_search=ORIGINAL
