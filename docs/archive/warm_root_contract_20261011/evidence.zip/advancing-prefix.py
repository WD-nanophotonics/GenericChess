"""Bounded actual frozen-WebGame path diagnostic; never imports UI into sandbox.

Run with --reference pointing to an isolated git archive of the pinned ui-test,
and --deps to its pinned Web dependencies. Exports and user UI source stay local.
Two start-position games, opposite UI colors, max32plies;1second per call.
Minimal AB is material-only; actual UI keeps dynamic evaluator/q/TT/order.
This is product diagnosis, not matched-algorithm strength or a bug-free proof.
"""
from pathlib import Path
import argparse
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--reference',type=Path,required=True)
p.add_argument('--deps',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--arm',choices=['baseline','phase_bypass'],required=True)
args=p.parse_args()
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(args.deps.resolve()))
sys.path.insert(0,str(args.reference.resolve()))

import asyncio
from dataclasses import asdict
import hashlib
import json
import time
import chess
import generic_chess
assert Path(generic_chess.__file__).resolve().is_relative_to(args.reference.resolve())
from generic_chess.ui.web import service as web
from generic_chess.ui.web.models import GameConfig,Operation
from generic_chess.core.actions import action_to_dict
from scripts.search_backend_comparison import ChessBoard,iterative_minimal
from scripts.research_record import record_value,write_record


import ast,inspect
from generic_chess.ai.alphabeta import search as frozen_search
from generic_chess.ai.alphabeta import player as frozen_player
original_root=frozen_search.run_root_search
root_source=inspect.getsource(original_root)
# Read only Agent diagnostic syntax, then bind to the actual frozen namespace.
tree=ast.parse((ROOT/'scripts/reserve_refresh_diagnostic.py').read_text())
constants={}
for n in tree.body:
    if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant):
        for target in n.targets:
            if isinstance(target,ast.Name):constants[target.id]=n.value.value
anchor=constants['ANCHOR'];refresh=constants['REFRESH']
phase=refresh.replace('            if not _naive_tt:\n                ctx.tt.clear()\n                ctx.use_tt = False','            ctx.use_tt = False').replace('ctx.use_tt = original_tt','ctx.use_tt = use_tt').replace('                if not _naive_tt:\n                    ctx.tt.clear()','')
assert root_source.count(anchor)==1
phase_source=root_source.replace(anchor,anchor+phase)
iteration='    for depth in range(1, max_depth + 1):'
assert phase_source.count(iteration)==1
phase_source=phase_source.replace(iteration,iteration+'\n        ctx.use_tt = use_tt if depth > 1 or ctx.qdepth_limit == 0 else False')
# Mechanical routing patch bound to the frozen namespace, never edit its source.
skip_source=phase_source.replace(iteration,'''    skip_refresh = False
    if use_tt and ctx.qdepth_limit > 0 and runtime.tt_eligible:
        budget.check(stats, force=True)
        stats.position_keys_computed += 1
        stats.tt_probes += 1
        warm_entry = tt.probe(runtime.search_key())
        if warm_entry is not None:
            stats.tt_hits += 1
            skip_refresh = warm_entry.bound is BoundType.EXACT and warm_entry.depth >= 2
        _selection.append(dict(skip=skip_refresh,entry_depth=None if warm_entry is None else warm_entry.depth,bound=None if warm_entry is None else warm_entry.bound.name,at=time.perf_counter()))
    for depth in range(1, max_depth + 1):''').replace('use_tt if depth > 1 or ctx.qdepth_limit == 0 else False','use_tt if skip_refresh or depth > 1 or ctx.qdepth_limit == 0 else False').replace('if depth == 1 and ctx.qdepth_limit > 0 and best.declaration is None:', 'if not skip_refresh and depth == 1 and ctx.qdepth_limit > 0 and best.declaration is None:')
phase_events=[];selection=[]
def phase_log(phase,ctx,result,reason=None):
    ctx.runtime.assert_balanced()
    phase_events.append(dict(at=time.perf_counter(),phase=phase,q=ctx.qdepth_limit,use_tt=ctx.use_tt,budget_identity=id(ctx.budget),deadline=ctx.budget._deadline,score=result.score,nodes=ctx.stats.nodes,qnodes=ctx.stats.qnodes,reason=reason))
namespace=dict(frozen_search.__dict__);namespace['_refresh_log']=phase_log
exec(compile(phase_source,'<frozen-ui-phase-probe>','exec'),namespace)
if args.arm=='phase_bypass':frozen_player.run_root_search=namespace['run_root_search']

skip_namespace=dict(namespace);skip_namespace['_selection']=selection
exec(compile(skip_source,'<frozen-skippable>','exec'),skip_namespace)

UI_SHA='99c97bb87474c44af94c76571f326ef8a41eb898'

import copy
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
B=ROOT/'.local_agent/skippable-contract-20261011'
games=json.loads((ROOT/'.local_agent/ui-product-20261010/games-final.json').read_bytes())
labels=json.loads((ROOT/'.local_agent/ui-product-20261010/population-baseline.json').read_bytes())
lookup={(x['game_index'],x['ply']):x for x in labels['roots']}
selected={(i,next(p['ply'] for p in g['plies'] if p['role']=='UI' and p['decision']['action']['actor_type_id']=='Q' and p['direct_loss_flags'])) for i,g in enumerate(games['games'])}
selected.add((0,17));assert len(selected)==3
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),selected=sorted(selected),ui_sha=UI_SHA,root_source_sha256=hashlib.sha256(root_source.encode()).hexdigest(),phase_source_sha256=hashlib.sha256(phase_source.encode()).hexdigest(),skip_source_sha256=hashlib.sha256(skip_source.encode()).hexdigest(),primers=[],rows=[],snapshots=[])
def save():write_record(args.output,r)
def stopped():
 for name in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes())
  if f.get('stopped') or f.get('user_paused'):raise RuntimeError('project stopped')
def uci(action):
 return chess.square_name(chess.square(action.from_square.file,action.from_square.rank))+chess.square_name(chess.square(action.to_square.file,action.to_square.rank))+(action.promotion_target_id or '').lower()
def tt_signature(table):
 rows=sorted((repr(k),e.depth,e.score,e.bound.name,str(e.best_action),e.generation) for k,e in table._data.items())
 return hashlib.sha256(json.dumps(rows).encode()).hexdigest()
start=time.perf_counter();save()
for gi,g in enumerate(games['games']):
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c);primer=web.create_ui_player(c,use_disk_cache=False)
 for p in g['plies']:
  if p['ply']>max(n for i,n in selected if i==gi):break
  stopped();assert time.perf_counter()-start<800
  initial=s.state;w=s._search_history_witnesses
  if (gi,p['ply']) in selected:
   snapshot=copy.deepcopy(primer._tt);signature=tt_signature(snapshot)
   r['snapshots'].append(dict(root=[gi,p['ply']],entries=len(snapshot),generation=snapshot.generation,q_policy=primer._tt_q_depths,sha256=signature,prefix=[x['uci'] for x in g['plies'] if x['ply']<p['ply']]))
   for seconds in (.1,1.0,4.0):
    for ai,arm in enumerate(('baseline','bypass','skippable','skippable','bypass','baseline')):
     stopped();assert time.perf_counter()-start<800
     player=copy.copy(primer);player._tt=copy.deepcopy(snapshot);assert tt_signature(player._tt)==signature
     phase_events.clear();selection.clear();frozen_player.run_root_search=original_root if arm=='baseline' else skip_namespace['run_root_search'] if arm=='skippable' else namespace['run_root_search']
     tick=time.perf_counter()
     try:d=player.choose_action(s,SearchLimits(max_time_seconds=seconds,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
     finally:frozen_player.run_root_search=original_root
     end=time.perf_counter();assert s.state==initial and s._search_history_witnesses==w
     action=uci(d.action);ref=lookup[(gi,p['ply'])];values={x['move']:x['worst']['score'] for x in ref['material_root_children']}
     source='fallback' if not d.completed_depth else 'configured_main'
     if d.completed_depth==1:source='completed_refresh' if any(x['phase']=='complete' for x in phase_events) else 'completed_initial'
     r['rows'].append(dict(root=[gi,p['ply']],seconds=seconds,arm=arm,order=ai,decision=record_value(d),uci=action,finite_D2_regret=max(values.values())-values[action] if action in values else None,wall=end-tick,events=list(phase_events),selection=list(selection),source=source,same_tt_input_sha256=signature,tt_after_entries=len(player._tt),state_restored=True))
     save();print(gi,p['ply'],seconds,arm,d.completed_depth,action,r['rows'][-1]['finite_D2_regret'],source,flush=True)
  if p['role']=='UI':
   frozen_player.run_root_search=original_root;tick=time.perf_counter();d=primer.choose_action(s,SearchLimits(max_time_seconds=1.0,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   r['primers'].append(dict(root=[gi,p['ply']],returned_uci=uci(d.action),submitted_recorded_uci=p['uci'],decision=record_value(d),wall=time.perf_counter()-tick));save()
  s.submit({uci(a):a for a in s.legal_actions()}[p['uci']])
r.update(complete=True,wall=time.perf_counter()-start,scope='Frozen99c97 recomputed baseline search on recorded actual prefixes; arms clone one identical input TT/player, no cross-arm contamination. Not original captured serviceTT, no browser latency or strength claim. Old finiteD2material labels only, dynamic selectiveq4 values not finiteD2certificates.')
save()
