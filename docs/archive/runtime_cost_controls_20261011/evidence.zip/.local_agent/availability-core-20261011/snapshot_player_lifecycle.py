"""Actual player failure/recovery ownership; not a natural failure-frequency claim."""
import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('caller',B/'installed_control.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
from generic_chess.core.search_runtime import SearchPathRuntime,RuntimeCountsSnapshot
from scripts.research_record import write_record,record_value
original_push=SearchPathRuntime.push
original_update=RuntimeCountsSnapshot.updated
def table(runtime):
    return {key:tuple(sorted(((entry.identity,entry.count) for entry in entries),key=lambda x:repr(x[0]))) for key,entries in runtime._occurrences.items()}
def main():
    start=time.perf_counter();out=dict(complete=False,scope='4 Chess/Shogi actual player cells with Core/Native provider. One deliberate snapshot MemoryError propagates from choose_action, exact mutated table is restored, later same-player call constructs a different Runtime. UI behavior is source-traced, not an executed GUI/game or natural error-frequency observation.',rows=[])
    for name in ('western_chess','standard_shogi'):
        compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset(name))
        for native in (False,True):
            session=c.GameSession(compiled);root=session.state
            evaluator=c.w.weighted(compiled,c.VALUES['chess' if name=='western_chess' else 'shogi'])
            player=c.AlphaBetaPlayer(compiled,evaluator_override=evaluator,use_native_semantic_legality=native,use_disk_cache=False)
            runtimes=[];failures=[];armed=True
            def traced(runtime,action,checkpoint=None):
                nonlocal armed
                if not any(runtime is previous for previous in runtimes):runtimes.append(runtime)
                before=table(runtime)
                try:return original_push(runtime,action,checkpoint)
                except MemoryError:
                    failures.append(dict(restored=table(runtime)==before,accepted_native_frontiers=runtime.legal_provider_calls,history_length=len(runtime._history)))
                    assert table(runtime)==before
                    runtime.assert_balanced()
                    raise
            def fail_once(snapshot,*args,**kwargs):
                nonlocal armed
                if armed:armed=False;raise MemoryError('injected player snapshot')
                return original_update(snapshot,*args,**kwargs)
            SearchPathRuntime.push=traced;RuntimeCountsSnapshot.updated=fail_once
            limits=c.SearchLimits(max_depth=1,max_nodes=256,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0)
            try:
                try:player.choose_action(session,limits)
                except MemoryError as exc:assert str(exc)=='injected player snapshot'
                else:raise AssertionError('MemoryError swallowed')
                assert session.state is root and len(runtimes)==1 and len(failures)==1
                failed_runtime=runtimes[0]
                result=player.choose_action(session,limits)
                assert len(runtimes)==2 and runtimes[1] is not failed_runtime
                assert result.action in session.legal_actions() and session.state is root
                for runtime in runtimes:runtime.assert_balanced()
                out['rows'].append(dict(game=name,native_configured=native,active_provider=player._native_legality_provider is not None,failures=failures,result=record_value(result),fresh_runtime=True))
            finally:SearchPathRuntime.push=original_push;RuntimeCountsSnapshot.updated=original_update
    out.update(complete=True,seconds=time.perf_counter()-start);write_record(B/'snapshot-player-lifecycle.json',out)
if __name__=='__main__':main()
