"""A pre-history snapshot failure must not leak a repetition occurrence."""
import pytest

from generic_chess import build_builtin_ruleset, compile_ruleset_for_execution
from generic_chess.core.identity import RuntimeHash, position_identity_key
from generic_chess.core.search_runtime import RuntimeCountsSnapshot, SearchPathRuntime
from generic_chess.core.transition import legal_successors
from generic_chess.session.session import GameSession


def occurrences(runtime):
    # Inspect the actual mutable table, not the restored persistent snapshot or
    # the root-only compatibility projection, which can conceal a leaked child.
    return {key: tuple((entry.identity, entry.count) for entry in bucket)
            for key, bucket in runtime._occurrences.items()}


@pytest.mark.parametrize("game", ["western_chess", "standard_shogi"])
@pytest.mark.parametrize("collision", [False, True])
def test_snapshot_failure_rolls_back_child_before_history_append(monkeypatch, game, collision):
    compiled = compile_ruleset_for_execution(build_builtin_ruleset(game))
    session = GameSession(compiled)
    # Include a complete public history; both the history and occurrence table
    # must survive repeated failures before any new history record is appended.
    session.submit(session.legal_actions()[0])
    root = session.state
    runtime = SearchPathRuntime.from_state(
        root, compiled, history_witnesses=session._search_witnesses,
        hash_override=RuntimeHash(1, 1) if collision else None,
    )
    action = runtime.legal_actions()[0]
    expected = dict(legal_successors(root, compiled))[action]
    before = occurrences(runtime)
    before_key = runtime.search_key()
    before_history = tuple(runtime._history)
    original = RuntimeCountsSnapshot.updated

    def fail(*args, **kwargs):
        raise RuntimeError("injected snapshot allocation failure")

    monkeypatch.setattr(RuntimeCountsSnapshot, "updated", fail)
    for _ in range(2):
        with pytest.raises(RuntimeError, match="snapshot allocation failure"):
            runtime.push(action)
        assert occurrences(runtime) == before
        assert tuple(runtime._history) == before_history
        assert runtime.position is root.position
        assert runtime.search_key() == before_key
        runtime.assert_balanced()

    monkeypatch.setattr(RuntimeCountsSnapshot, "updated", original)
    with runtime.pushed(action):
        assert runtime.position == expected.position
        assert runtime.terminal_status == expected.terminal_status
        assert runtime.occurrence_count() == expected.repetition_counts[
            position_identity_key(expected.position, compiled)]
    assert occurrences(runtime) == before
    runtime.assert_balanced()
