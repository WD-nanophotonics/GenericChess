"""Generated geometry and caller-neutral finite score comparison; no timings."""
import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
def load(name,file):
    s=importlib.util.spec_from_file_location(name,B/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=load('indexed','indexed_eval_probe.py');c=load('caller','installed_control.py')
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.core.transition import legal_successors
from scripts.research_record import write_record
import pytest
def containers(value,seen):
    if id(value) in seen:return 0
    seen.add(id(value))
    if isinstance(value,dict):return sys.getsizeof(value)+sum(containers(v,seen) for v in value.values())
    if isinstance(value,(tuple,list)):return sys.getsizeof(value)+sum(containers(v,seen) for v in value)
    return 0
def main():
    start=time.perf_counter();out=dict(complete=False,scope='Predeclared existing generated4/6 seeds7/21 roots and first16 legal children. Original legacy attack/score oracle; synthetic fixed100 values (anchor0), no human prices/label fitting. Unchanged legacy semantic limits; owned containers exclude borrowed Squares/IDs/interned integer cells.',rows=[])
    for size in (4,6):
        for seed in (7,21):
            game=generate_game(GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
            compiled=c.compile_ruleset_for_execution(game.ruleset)
            evaluator=c.w.weighted(compiled,{pt.type_id:0 if pt.is_anchor else 100 for pt in compiled.piece_types})
            p.prepare(evaluator);state=c.GameSession(compiled).state
            states=[state]+[child for _,child in legal_successors(state,compiled)[:16]]
            for child in states:
                assert p.baseline(evaluator,child)==p.maps(evaluator,child)
                p.install(False);before=evaluator.evaluate(child)
                try:p.install(True);assert evaluator.evaluate(child)==before
                finally:p.install(False)
            out['rows'].append(dict(size=size,seed=seed,states=len(states),fingerprint=compiled.ruleset_fingerprint,owned_container_bytes=containers(evaluator._indexed_attack_plans,set())))
    p.install(True)
    try:
        out['pytest_exit']=int(pytest.main(['tests/product/test_ai_evaluation.py','tests/product/test_promotion.py','tests/product/test_geometry_target_query.py','tests/product/test_search_evaluation_accounting.py','-q','-p','no:cacheprovider','--basetemp',str(B/'indexed-eval-tests')]))
        assert out['pytest_exit']==0
    finally:p.install(False)
    out.update(complete=True,seconds=time.perf_counter()-start);write_record(B/'indexed-eval-generated.json',out)
if __name__=='__main__':main()
