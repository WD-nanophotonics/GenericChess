"""One finite agreed timing slot; no worker, scheduler or reusable lock system."""
import json,subprocess,sys,time,datetime
from pathlib import Path
B=Path(__file__).parent
out=dict(started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    coordination='DEV_AUX current chat explicitly states five-minute source/report-only slot; no bilateral process lock. Primary runs only this serial batch.',
    hard_slot_seconds=270,rows=[],complete=False)
started=time.monotonic()
try:
    for name in ('shape_reuse_control.py','shape_reuse_time.py'):
        remaining=270-(time.monotonic()-started);assert remaining>0
        result=subprocess.run([sys.executable,'-B',str(B/name)],capture_output=True,text=True,timeout=remaining)
        out['rows'].append(dict(producer=name,exit=result.returncode,stdout=result.stdout,stderr=result.stderr))
        print(name,result.returncode,result.stdout,flush=True)
        assert result.returncode==0
    out['complete']=True
finally:
    out['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    out['elapsed_seconds']=time.monotonic()-started
    (B/'shape-timing-slot.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
if not out['complete']:raise RuntimeError('finite slot incomplete; preserve results')
