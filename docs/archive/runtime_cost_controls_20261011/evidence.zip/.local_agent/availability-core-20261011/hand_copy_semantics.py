"""Baseline public successors versus private hand sharing, plus typed inputs."""
import sys,time,importlib.util,itertools
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('hands',B/'hand_copy_probe.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
from generic_chess import compile_ruleset_for_execution,build_builtin_ruleset
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands
from generic_chess.core.search_runtime import SearchPathRuntime,_full_runtime_hash
from generic_chess.core.transition import legal_successors
from generic_chess.session.session import GameSession
from rule_semantics_ir_fixtures import weird_rulesets
from scripts.research_record import write_record,record_value
from scripts.reserve_refresh_diagnostic import stopped
import pytest

def main():
    started=time.perf_counter();fixtures=weird_rulesets();rows=[[None]*8 for _ in range(8)]
    for owner,tid,f,r in ((0,'K',4,0),(1,'K',7,7),(0,'R',0,0),(0,'R',0,1),(0,'R',0,2),(0,'R',1,1),(1,'R',1,3),(1,'R',1,4)):rows[r][f]=Piece(owner,tid,tid)
    c=compile_ruleset_for_execution(replace(fixtures[2],initial_position=tuple(map(tuple,rows)),semantic_actions=(fixtures[1].semantic_actions[0],fixtures[2].semantic_actions[0]),drop_allowed={'R':((True,)*64,)*2,'TP':((False,)*64,)*2}))
    route=(((1,1),(1,3),False),((7,7),(6,7),False),((1,3),(1,4),False),((6,7),(5,7),False),((0,0),(1,1),True),((5,7),(4,7),False),(None,(0,0),False),((4,7),(3,7),False))
    out=dict(complete=False,scope='Public baseline successors computed with sharing disabled; candidate runtime/full identity/terminal/frontier compared on the old8ply recombined lifecycle. Explicit noncanonical/typed hand normalization; finite development correctness, not speed/general-domain proof.',children=0,typed=[],rows=[])
    game=GameSession(c)
    try:
        for ply in range(9):
            stopped();assert time.perf_counter()-started<180;p.install(False)
            pairs=legal_successors(game.state,c)
            p.install(True);rt=SearchPathRuntime.from_state(game.state,c,history_witnesses=game._search_witnesses);key=rt.search_key()
            assert rt.legal_actions()==tuple(a for a,_ in pairs)
            for action,child in pairs:
                with rt.pushed(action):
                    assert record_value(rt.position)==record_value(child.position)
                    assert rt.runtime_hash==_full_runtime_hash(child.position,c)
                    assert rt.terminal_status==child.terminal_status
                assert rt.search_key()==key and rt.position is game.state.position;out['children']+=1
            rt.assert_balanced();out['rows'].append(dict(ply=ply,children=len(pairs)))
            p.install(False)
            if ply==8:break
            source,target,semantic=route[ply]
            def selected(a):
                if (a.to_square.file,a.to_square.rank)!=target:return False
                if source is None:return hasattr(a,'base_type_id')
                return hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source and a.pattern_id.startswith('sem_')==semantic
            action,=[a for a,_ in pairs if selected(a)];game.submit(action)
        engine=p.m.semantic_engine_for(c);position=engine._initial_position()
        samples=((),(('R',1),),(('R',True),),(('R',1),('R',2)),(('R',1),('K',2)),(('R',0),))
        for left,right in itertools.product(samples,repeat=2):
            base=replace(position,hands=(Hands(left),Hands(right)))
            for mutation in ('none','int-roundtrip','delete'):
                outputs=[]
                for cls in (p.baseline,p.SharedHands):
                    work=cls(base,c.support)
                    if mutation=='int-roundtrip':
                        for hand in work.hands:
                            if 'R' in hand:hand['R']+=1;hand['R']-=1
                    elif mutation=='delete':
                        for hand in work.hands:hand.pop('R',None)
                    child=work.to_position(base.aux_state,c.support.ruleset_fingerprint)
                    outputs.append((record_value(child),_full_runtime_hash(child,c),
                        tuple(tuple((type(t).__name__,t,type(n).__name__,n) for t,n in h.counts) for h in child.hands)))
                assert outputs[0]==outputs[1];out['typed'].append(dict(left=record_value(left),right=record_value(right),mutation=mutation))
        p.install(True)
        out['pytest_exit']=int(pytest.main(['tests/product/test_capture_and_hands.py','tests/product/test_f24c_mixed_mechanic_certification.py','tests/product/test_f24c_mixed_mechanic_certification_r1.py','tests/product/test_compiled_transition_triggers.py','tests/product/test_semantic_trial_checkpoint.py','tests/product/test_runtime_aux_identity.py','tests/product/test_generic_pass_action.py','-q','-p','no:cacheprovider','--basetemp',str(B/'hand-sharing-tests')]))
        assert out['pytest_exit']==0;out['allocations']=dict(p.counts);out['complete']=True
    finally:p.install(False);out['elapsed_seconds']=time.perf_counter()-started;write_record(B/'hand-copy-semantics.json',out)
    print('children',out['children'],'typed',len(out['typed']),flush=True)
if __name__=='__main__':main()
