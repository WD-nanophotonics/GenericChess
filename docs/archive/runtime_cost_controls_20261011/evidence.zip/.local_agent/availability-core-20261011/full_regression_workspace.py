import json,subprocess,time,uuid
from pathlib import Path
b=Path(__file__).parent
base=Path('.local_agent/pytest-runs')/('snapshot-full-'+uuid.uuid4().hex)
assert not base.exists()
args=['.venv/Scripts/python.exe','-m','pytest','-q','-p','no:cacheprovider','--basetemp',str(base.resolve())]
t=time.perf_counter()
try:
 p=subprocess.run(args,capture_output=True,text=True,timeout=600)
 out={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-t,'command':args}
except subprocess.TimeoutExpired as e:out={'exit':'timeout','stdout':str(e.stdout),'stderr':str(e.stderr),'seconds':time.perf_counter()-t,'command':args}
(b/'snapshot-full-workspace.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out)[-5500:]);assert out['exit']==0
