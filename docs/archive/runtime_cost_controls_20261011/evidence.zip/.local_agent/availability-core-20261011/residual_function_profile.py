"""Descriptive per-function profile on unchanged lexical D2; not speed evidence."""
import sys,time,cProfile,pstats,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('caller',B/'installed_control.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
from scripts.search_backend_comparison import minimal_ab
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
def main():
    started=time.perf_counter();out=dict(complete=False,scope='Descriptive cProfile of unchanged8existing hybrid minimal lexical D2 callers. Profiled/plain exact decision/work. No controlled timing comparison or attainable saving while DEV_AUX is active. Inclusive functions overlap.',rows=[])
    for case in c.CASES:
        c.stopped();assert time.perf_counter()-started<120
        compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));provider=NativeSemanticLegalityProvider.try_create(compiled,strict=True);assert provider is not None
        values=[]
        for profiled in (False,True):
            board=c.CoreBoard(case,compiled,provider);board.material=c.w.weighted(compiled,c.VALUES[case['game']]);p=cProfile.Profile()
            if profiled:p.enable()
            try:result=minimal_ab(board,2,seconds=30,node_limit=100000)
            finally:
                if profiled:p.disable()
            assert result['reason']=='completed_depth';values.append(c.clean(result));functions=[]
            if profiled:
                for (file,line,name),(pc,nc,tt,ct,callers) in pstats.Stats(p).stats.items():
                    if 'generic_chess' in file:
                        functions.append(dict(file=Path(file).relative_to(Path.cwd()).as_posix(),line=line,name=name,primitive_calls=pc,total_calls=nc,self_seconds=tt,inclusive_seconds=ct))
            out['rows'].append(dict(root=case['id'],profiled=profiled,decision=result,functions=sorted(functions,key=lambda x:-x['self_seconds'])))
        assert values[0]==values[1];c.write_record(B/'residual-function-profile.json',out);print(case['id'],'exact',flush=True)
    out['complete']=True;out['seconds']=time.perf_counter()-started;c.write_record(B/'residual-function-profile.json',out)
if __name__=='__main__':main()
