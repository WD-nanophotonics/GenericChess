"""Private compile-owned occupancy indices for unchanged legacy attack authority."""
import time
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core.movement import LeapAtom
from generic_chess.core.errors import ensure_ruleset_match
baseline=Evaluator._attack_maps
def prepare(self):
    started=time.perf_counter();compiled=self._compiled;n=compiled.board_size
    plans={}
    for tid,pt in compiled.types_by_id.items():
        owners=[]
        for owner in (0,1):
            rows=[]
            for index in range(n*n):
                leaps=[];rays=[]
                for atom_index,atom in enumerate(pt.movement_atoms):
                    if isinstance(atom,LeapAtom):
                        leaps.extend(compiled.leap_targets[tid][owner][index][atom_index])
                    else:
                        rays.append(tuple((target,target.rank*n+target.file) for target in compiled.ray_paths[tid][owner][index][atom_index]))
                rows.append((tuple(leaps),tuple(rays)))
            owners.append(tuple(rows))
        plans[tid]=tuple(owners)
    self._indexed_attack_plans=plans
    self._indexed_attack_setup_seconds=time.perf_counter()-started
def maps(self,state):
    compiled=self._compiled;position=state.position
    if len(position.board)!=compiled.board_size**2:return baseline(self,state)
    if not hasattr(self,'_indexed_attack_plans'):prepare(self)
    result=[]
    for owner in (0,1):
        ensure_ruleset_match(position,compiled)
        attacked=set()
        for index,piece in enumerate(position.board):
            if piece is None or piece.owner!=owner:continue
            leaps,rays=self._indexed_attack_plans[piece.current_type_id][owner][index]
            attacked.update(leaps)
            for ray in rays:
                for target,target_index in ray:
                    attacked.add(target)
                    if position.board[target_index] is not None:break
        result.append(frozenset(attacked))
    return tuple(result)
def install(active):
    Evaluator._attack_maps=maps if active else baseline
