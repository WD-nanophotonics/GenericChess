"""Independent arithmetic and original exception contracts for extent sharing."""
import sys,time,importlib.util
from pathlib import Path
from enum import IntEnum
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('shapeprobe',B/'shape_direct_probe.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
from scripts.research_record import write_record
import pytest
class N(IntEnum):three=3
def outcome(fn,*a):
    try:return ('value',fn(*a))
    except Exception as e:return ('error',type(e).__name__,str(e))
def main():
    start=time.perf_counter();out=dict(complete=False,scope='Finite independent row-major/offset/rotation arithmetic and exact original validation/error comparison; cache positive exact ints only, immutable values and bounded128entries. No speed or semantic rule shortcut.',arithmetic_checks=0,exception_checks=0)
    try:
        for extent in (1,2,3,8,9,p.m.BoardShape(2,5),p.m.BoardShape(5,2)):
            shape=p.baseline(extent);p.install(True)
            for rank in range(shape.height):
                for file in range(shape.width):
                    sq=p.m.Square(file,rank);idx=rank*shape.width+file
                    assert p.m.square_to_index(sq,extent)==idx
                    assert p.m.index_to_square(idx,extent)==sq
                    assert p.m.rotate_square(sq,extent)==p.m.Square(shape.width-1-file,shape.height-1-rank)
                    for df,dr in ((0,0),(1,0),(-1,0),(0,1),(0,-1),(2,-3)):
                        f,r=file+df,rank+dr;expected=p.m.Square(f,r) if 0<=f<shape.width and 0<=r<shape.height else None
                        assert p.m.add_offset(sq,(df,dr),extent)==expected;out['arithmetic_checks']+=1
        for extent in (0,-1,True,False,1.0,'3',None,[],{},N.three,p.m.BoardShape(2,5),8):
            for idx in (-1,0,17,64,100):
                for fn,args in ((p.m.index_to_square,(idx,extent)),(p.m.square_to_index,(p.m.Square(2,3),extent)),(p.m.in_bounds,(p.m.Square(2,3),extent))):
                    p.install(False);before=outcome(fn,*args);p.install(True);after=outcome(fn,*args)
                    assert before==after,(extent,fn.__name__,before,after);out['exception_checks']+=1
        p.square_extent.cache_clear();p.install(True)
        for n in range(1,257):assert p.reused(n)==p.m.BoardShape(n,n)
        assert p.square_extent.cache_info().currsize==128
        assert p.reused(8) is p.reused(8)
        try:p.reused(8).width=7
        except Exception as e:out['mutation_error']=type(e).__name__
        else:raise AssertionError('mutable shared shape')
        out['pytest_exit']=int(pytest.main(['tests/product/test_coordinates.py','tests/product/test_legacy_attack_target.py','tests/product/test_compiled_attack_index.py','tests/product/test_ai_evaluation.py','tests/product/test_rectangular_board_geometry_a.py','tests/product/test_rectangular_legacy_ir_baseline_b4a.py','tests/product/test_semantic_rectangle_profile.py','-q','-p','no:cacheprovider','--basetemp',str(B/'shape-direct-tests')]))
        assert out['pytest_exit']==0;out['cache_info']=p.square_extent.cache_info()._asdict();out['complete']=True
    finally:p.install(False);out['seconds']=time.perf_counter()-start;write_record(B/'shape-direct-contract.json',out)
if __name__=='__main__':main()
