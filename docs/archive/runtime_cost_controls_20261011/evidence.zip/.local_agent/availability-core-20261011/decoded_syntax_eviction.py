"""Exercise the new syntax cache's real eviction, not only public-cache eviction."""
import sys,importlib.util,time
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('syntax',B/'decoded_syntax_probe.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution,initial_state
from generic_chess.native.semantic import pack_position,transient_legal_actions
from scripts.research_record import write_record
from dataclasses import FrozenInstanceError
def owned_size(value,seen):
    if id(value) in seen:return 0
    seen.add(id(value));size=sys.getsizeof(value)
    if isinstance(value,dict):size+=sum(owned_size(k,seen)+owned_size(v,seen) for k,v in value.items())
    elif isinstance(value,(tuple,list)):size+=sum(owned_size(v,seen) for v in value)
    # Action fields contain borrowed IDs; only their carrier is owned here.
    return size
def main():
    start=time.perf_counter();out=dict(complete=False,scope='Original static decoder-valid syntax, not Native legal-move claims. Real bounded2048-entry syntax eviction and borrowed-ID-excluding owned carriers.',rows=[])
    for name in ('western_chess','standard_shogi'):
        compiled=compile_ruleset_for_execution(build_builtin_ruleset(name));provider=p.P.try_create(compiled,strict=True);assert provider
        pos=initial_state(compiled).position;packed=int(tuple(transient_legal_actions(provider.native_rules,pack_position(provider.native_rules,provider._state_only_payload(pos,0))))[0])
        p.counts.clear();checks=0
        for source,piece in enumerate(pos.board):
            if piece is None or piece.owner!=pos.side_to_move:continue
            for target in range(len(pos.board)):
                for promotion in (255,*range(len(provider.type_ids))):
                    value=(packed & ~((255<<8)|255|(255<<16)|(255<<24)|(255<<56)))|target|(source<<8)|(promotion<<16)|(provider.type_map[piece.base_type_id]<<24)|(provider.type_map[piece.current_type_id]<<56)
                    original=p.baseline(provider,value,pos);candidate=p.decoded(provider,value,pos);assert original==candidate;checks+=1
                    assert len(provider._metrics_local.decoded_syntax)<=2048
        assert p.counts['clear']>0
        cache=provider._metrics_local.decoded_syntax
        action=p.decoded(provider,packed,pos)
        try:action.target=0
        except FrozenInstanceError:pass
        else:raise AssertionError('Mutable cached action')
        out['rows'].append(dict(game=name,checks=checks,counts=dict(p.counts),final_entries=len(cache),owned_bytes=owned_size(cache,set())))
    out.update(complete=True,seconds=time.perf_counter()-start);write_record(B/'decoded-syntax-eviction.json',out)
if __name__=='__main__':main()
