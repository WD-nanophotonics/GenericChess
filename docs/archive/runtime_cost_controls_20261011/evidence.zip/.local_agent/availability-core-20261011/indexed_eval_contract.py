"""Original legacy attack maps and score are the fixed independent oracle."""
import sys,time,importlib.util
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
def load(name,file):
    s=importlib.util.spec_from_file_location(name,B/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=load('indexed','indexed_eval_probe.py');c=load('caller','installed_control.py')
from generic_chess.core.transition import legal_successors
from generic_chess.core.pieces import Piece
from scripts.research_record import write_record
def main():
    start=time.perf_counter();out=dict(complete=False,scope='Unchanged legacy pseudo-attack geometry, friendly blocking/pinning conventions and weighted score; no semantic attack-authority substitution. Root/all immediate public successors plus synthetic current-type/owner/edge blocking states. Compile-owned integer occupancy addresses; no position cache.',rows=[],checks=0)
    for case in c.CASES:
        compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=c.CoreBoard(case,compiled);e=c.w.weighted(compiled,c.VALUES[case['game']]);p.prepare(e)
        states=[board.initial]+[child for _,child in legal_successors(board.initial,compiled)]
        for state in states:
            before=p.baseline(e,state);after=p.maps(e,state);assert before==after
            p.install(False);score=e.evaluate(state)
            try:p.install(True);assert e.evaluate(state)==score
            finally:p.install(False)
            out['checks']+=1
        out['rows'].append(dict(root=case['id'],states=len(states),setup_seconds=e._indexed_attack_setup_seconds))
    for name in ('western_chess','standard_shogi'):
        compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset(name));state=c.GameSession(compiled).state;e=c.w.weighted(compiled,c.VALUES['chess' if name=='western_chess' else 'shogi']);p.prepare(e)
        for tid in compiled.types_by_id:
            for owner in (0,1):
                for source in range(len(state.position.board)):
                    cells=[None]*len(state.position.board);cells[source]=Piece(owner,tid,tid)
                    other=(source+1)%len(cells);cells[other]=Piece(owner,'K','K')
                    changed=SimpleNamespace(position=replace(state.position,board=tuple(cells)),ply_count=0)
                    assert p.baseline(e,changed)==p.maps(e,changed);out['checks']+=1
    out.update(complete=True,seconds=time.perf_counter()-start);write_record(B/'indexed-eval-contract.json',out)
if __name__=='__main__':main()
