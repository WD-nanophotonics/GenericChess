"""Original decoder versus syntax memo: hostile/stale raw actions and fresh bindings."""
import sys,importlib.util,time
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('decodeprobe',B/'decoded_syntax_probe.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution,initial_state
from generic_chess.core.pieces import Piece
from generic_chess.native.semantic import pack_position,transient_legal_actions
from scripts.research_record import write_record,record_value
import pytest
def outcome(fn,*args):
    try:return ('value',record_value(fn(*args)))
    except Exception as e:return ('error',type(e).__name__,str(e))
def main():
    start=time.perf_counter();out=dict(complete=False,scope='Baseline decoder full-validation oracle versus candidate static syntax memo. Reused action keys across changed side/source/base/actor state; invalid u64/kind/index/source/drop/promotion layouts. Fresh binding/checkpoint/cancel/eviction tests remain unchanged.',checks=0,rows=[])
    try:
        for name in ('western_chess','standard_shogi'):
            compiled=compile_ruleset_for_execution(build_builtin_ruleset(name));provider=p.P.try_create(compiled,strict=True);assert provider is not None
            pos=initial_state(compiled).position
            raw=tuple(transient_legal_actions(provider.native_rules,pack_position(provider.native_rules,provider._state_only_payload(pos,0))))
            states=[pos,replace(pos,side_to_move=1-pos.side_to_move)]
            packed=int(raw[0]);action=p.baseline(provider,packed,pos);source=action.source;assert source is not None
            for replacement in (None,replace(pos.board[source],owner=1-pos.side_to_move),Piece(pos.side_to_move,'K','K'),Piece(pos.side_to_move,pos.board[source].base_type_id,'K')):
                cells=list(pos.board);cells[source]=replacement;states.append(replace(pos,board=tuple(cells)))
            hostile=(True,False,-1,1<<64,1.0,'1',None)+tuple(packed^(mask<<shift) for mask,shift in ((255,0),(255,8),(255,16),(255,24),(15,32),(255,36),(4095,44),(255,56)))
            for value in tuple(map(int,raw[:12]))+hostile:
                before=outcome(p.baseline,provider,value,pos)
                after=outcome(p.decoded,provider,value,pos)
                assert before==after,(name,value,before,after);out['checks']+=1
                for state in states:
                    before=outcome(p.baseline,provider,value,state)
                    after=outcome(p.decoded,provider,value,state)
                    assert before==after,(name,value,before,after);out['checks']+=1
            # Exercise bounded eviction through valid original decoder syntax.
            # This is not a claim that these arbitrary syntax values are legal.
            for source_index,piece in enumerate(pos.board):
                if piece is None or piece.owner!=pos.side_to_move:continue
                for target in range(len(pos.board)):
                    value=(packed & ~((255<<8)|255|(255<<24)|(255<<56))) | target | (source_index<<8) | (provider.type_map[piece.base_type_id]<<24) | (provider.type_map[piece.current_type_id]<<56)
                    before=outcome(p.baseline,provider,value,pos);after=outcome(p.decoded,provider,value,pos)
                    assert before==after;out['checks']+=1
            assert len(provider._metrics_local.decoded_syntax)<=2048
            out['rows'].append(dict(game=name,raw_actions=len(raw)))
        p.install(True)
        out['pytest_exit']=int(pytest.main(['tests/product/test_native_public_projection.py','tests/product/test_native_legality_terminal_boundary.py','tests/product/test_runtime_aux_identity.py','tests/product/test_semantic_trial_checkpoint.py','-q','-p','no:cacheprovider','--basetemp',str(B/'decoded-syntax-tests')]))
        assert out['pytest_exit']==0;out['counts']=dict(p.counts);out['complete']=True
    finally:p.install(False);out['seconds']=time.perf_counter()-start;write_record(B/'decoded-syntax-contract.json',out)
if __name__=='__main__':main()
