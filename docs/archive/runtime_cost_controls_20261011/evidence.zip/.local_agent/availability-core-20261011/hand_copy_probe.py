"""Private hand materialization control; never installed as a product default."""
from collections import Counter
import generic_chess.core.semantic_executor as m

baseline = m._WorkingPosition
counts = Counter()

class SharedHands(baseline):
    def __init__(self, position, support):
        # Board/effects/events are unchanged. Hand maps remain ordinary mutable
        # dicts for every effect; only immutable result objects can be shared.
        super().__init__(position, support)
        self._original_hands = position.hands

    def to_position(self, aux_state, fingerprint):
        hands = []
        for owner, values in enumerate(self.hands):
            canonical = tuple(sorted(values.items()))
            original = self._original_hands[owner]
            counts['hand_results'] += 1
            # Comparing canonical tuples also preserves normalization of unsorted
            # or duplicate public Hands inputs; dict equality alone is insufficient.
            if canonical == original.counts and all(
                type(a[0]) is type(b[0]) and type(a[1]) is type(b[1])
                for a, b in zip(canonical, original.counts)
            ):
                hands.append(original)
                counts['shared'] += 1
            else:
                hands.append(m.Hands(canonical))
                counts['constructed'] += 1
        return m.Position(board=tuple(self.board), hands=tuple(hands),
            side_to_move=self.side, ruleset_fingerprint=fingerprint,
            aux_state=aux_state,
            board_width=self.shape.width if self.shape.width != self.shape.height else None,
            board_height=self.shape.height if self.shape.width != self.shape.height else None)

def install(active):
    m._WorkingPosition = SharedHands if active else baseline
