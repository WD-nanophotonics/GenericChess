"""Private bounded reuse of immutable square extents; validation stays public."""
from functools import lru_cache
import generic_chess.core.coordinates as m
baseline=m._shape
@lru_cache(maxsize=128)
def square_extent(n):
    return m.BoardShape(n,n)
def reused(extent):
    if isinstance(extent,m.BoardShape):return extent
    # Preserve bool/subclass/unhashable/invalid input behavior at the original
    # constructor. Cache only exact positive ints, not equal-but-distinct types.
    if type(extent) is int and extent>0:return square_extent(extent)
    return m.BoardShape(extent,extent)
def install(active):
    m._shape=reused if active else baseline
