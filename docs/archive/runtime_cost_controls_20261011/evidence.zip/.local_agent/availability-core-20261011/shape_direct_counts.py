"""Count-only residual bridge: immutable-hand allocations, not speed evidence."""
import sys, importlib.util, time
from pathlib import Path
from collections import Counter
sys.path[:0] = [str(Path.cwd()), str(Path.cwd()/'tests')]
B = Path(__file__).parent
def load(name, file):
    s=importlib.util.spec_from_file_location(name,B/file)
    x=importlib.util.module_from_spec(s);s.loader.exec_module(x);return x
p=load('handprobe','shape_direct_probe.py')
c=load('caller','installed_control.py')
from scripts.search_backend_comparison import minimal_ab
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider

def main():
    out=dict(complete=False,scope='8 existing weighted lexical minimal-AB D2 roots; exact traces/work/provider counters and cache hit/miss counts. No controlled speed claim while DEV_AUX is active. Cold bounded shape cache with direct BoardShape fastpath; no state/legal/history/evaluation shortcut.',rows=[])
    start=time.perf_counter()
    for case in c.CASES:
        c.stopped();assert time.perf_counter()-start < 120
        compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        provider=NativeSemanticLegalityProvider.try_create(compiled,strict=True);assert provider is not None
        values=[]
        for active in (False,True):
            board=c.CoreBoard(case,compiled,provider);board.material=c.w.weighted(compiled,c.VALUES[case['game']])
            p.square_extent.cache_clear();p.install(active)
            try:result=minimal_ab(board,2,seconds=30,node_limit=100000,trace=True)
            finally:p.install(False)
            assert result['reason']=='completed_depth'
            values.append(c.clean(result))
            out['rows'].append(dict(root=case['id'],candidate=active,decision=result,
                cache=p.square_extent.cache_info()._asdict()))
        assert values[0]==values[1],case['id']
        c.write_record(B/'shape-direct-counts.json',out);print(case['id'],'exact',out['rows'][-1]['cache'],flush=True)
    out['complete']=True;out['elapsed_descriptive_seconds']=time.perf_counter()-start;c.write_record(B/'shape-direct-counts.json',out)
if __name__=='__main__':main()
