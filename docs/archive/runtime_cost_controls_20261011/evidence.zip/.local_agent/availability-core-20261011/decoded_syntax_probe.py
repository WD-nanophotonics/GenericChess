"""Private provider-owned immutable syntax memo; fresh dynamic validation/binding."""
from collections import Counter
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider as P
baseline=P._decode_action
counts=Counter()
def decoded(self,packed,position):
    if not isinstance(packed,int) or isinstance(packed,bool) or not 0<=packed<=(1<<64)-1:
        return baseline(self,packed,position)
    cache=getattr(self._metrics_local,'decoded_syntax',None)
    if cache is None:
        cache={};self._metrics_local.decoded_syntax=cache
    entry=cache.get(packed)
    if entry is None:
        counts['miss']+=1
        action=baseline(self,packed,position)
        if len(cache)>=2048:cache.clear();counts['clear']+=1
        cache[packed]=(action,(packed>>24)&255,(packed>>56)&255)
        return action
    counts['hit']+=1
    action,base_index,actor_index=entry
    if action.source is not None:
        piece=position.board[action.source]
        if piece is None or piece.owner!=position.side_to_move:
            raise ValueError('Native legality returned a source without the side-to-move piece')
        if self.type_map[piece.base_type_id]!=base_index:
            raise ValueError('Native legality returned a mismatched base type')
        if self.type_map[piece.current_type_id]!=actor_index:
            raise ValueError('Native legality returned a mismatched actor type')
    # Only provider-validated static u64 syntax is reused. __call__ still checks
    # pattern lookup, creates the complete position binding and all checkpoints.
    return action
def install(active):
    P._decode_action=decoded if active else baseline
