"""Private legacy occupancy indices: fresh search state, prepared evaluator."""
import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
def mod(name,file):
 s=importlib.util.spec_from_file_location(name,B/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=mod('caller','installed_control.py');d=mod('delta','indexed_eval_probe.py')
def run():
 start=time.perf_counter();out=dict(complete=False,scope='Private compile-owned legacy occupancy indices; same attack authority. Predeclared8oldroots,1/4second budgets,2opposite pairs each,64calls,240second fuse. Warm per-evaluator geometry; setup cost separately measured. Same q4/hard8/evaluation/history/backend, maxD4, no node cap. Mate-early-return is not budget exhaustion. No strength claim.',rows=[])
 c.write_record(B/'indexed-eval-time.json',out)
 for case in c.CASES:
  compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=c.CoreBoard(case,compiled);e=c.w.weighted(compiled,c.VALUES[case['game']]);d.prepare(e)
  for seconds in (1,4):
   for repeat in range(2):
    for active in ((False,True) if repeat==0 else (True,False)):
     c.stopped();assert time.perf_counter()-start<240;d.install(active);s=c.GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;t=time.perf_counter()
     try:v=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,c.SearchLimits(max_depth=4,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8))
     finally:d.install(False)
     assert s.state is board.initial;out['rows'].append(dict(root=case['id'],budget=seconds,repeat=repeat,candidate=active,wall=time.perf_counter()-t,decision=c.record_value(v)))
   c.write_record(B/'indexed-eval-time.json',out);print(case['id'],seconds,flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;c.write_record(B/'indexed-eval-time.json',out)
if __name__=='__main__':run()
