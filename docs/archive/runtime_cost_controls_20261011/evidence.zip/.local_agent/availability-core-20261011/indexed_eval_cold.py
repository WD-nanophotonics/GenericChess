"""Predeclared fresh-evaluator total cost; no setup exclusion."""
import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
def load(n,f):
 s=importlib.util.spec_from_file_location(n,B/f);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=load('caller','installed_control.py');d=load('index','indexed_eval_probe.py')
def main():
 start=time.perf_counter();out={'complete':False,'scope':'Predeclared8 old roots,2 opposite pairs each,32 fixed512 calls. Fresh evaluator in both arms; candidate lazy prepares inside first evaluate, within measured total including evaluator constructor/player/choose_action. No cold-setup exclusion. Same q4/hard8/maxD4/10sec/Native, work equality checked.','rows':[]}
 for case in c.CASES:
  compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=c.CoreBoard(case,compiled)
  for repeat in range(2):
   pair=[]
   for active in ((False,True) if repeat==0 else (True,False)):
    c.stopped();assert time.perf_counter()-start<120;s=c.GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;d.install(active);t=time.perf_counter()
    try:
     e=c.w.weighted(compiled,c.VALUES[case['game']]);p=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False);v=p.choose_action(s,c.SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    finally:d.install(False)
    assert s.state is board.initial;value=c.record_value(v);pair.append(c.clean(value));out['rows'].append({'root':case['id'],'candidate':active,'repeat':repeat,'wall':wall,'setup_seconds':getattr(e,'_indexed_attack_setup_seconds',None),'decision':value})
   assert pair[0]==pair[1]
  c.write_record(B/'indexed-eval-cold.json',out)
 out.update(complete=True,seconds=time.perf_counter()-start);c.write_record(B/'indexed-eval-cold.json',out)
 print('exact',len(out['rows']))
if __name__=='__main__':main()
