"""Private executed-write witness; no action-footprint assumption."""
import threading
from collections import Counter
import generic_chess.core.semantic_executor as e
import generic_chess.core.search_runtime as r
local=threading.local()
counts=Counter()
original_work=e._WorkingPosition
original_hash=r._semantic_component_diff_hash
class TrackedWork(original_work):
    def __init__(self, position, support):
        super().__init__(position,support)
        self.parent=position
        self.writes=set()
    def set_piece(self,index,piece):
        self.writes.add(index)
        super().set_piece(index,piece)
    def to_position(self,aux_state,fingerprint):
        child=super().to_position(aux_state,fingerprint)
        local.witness=(self.parent,child,tuple(sorted(self.writes)))
        return child
def diff(parent,child,compiled,current):
    witness=getattr(local,'witness',None)
    # Retained references prevent recycled IDs; a nested/absent producer falls
    # back. Nonboard projection remains the unchanged typed original algorithm.
    local.witness=None
    if witness is None or witness[0] is not parent or witness[1] is not child:
        counts['fallback']+=1
        return original_hash(parent,child,compiled,current)
    counts['witness']+=1
    counts['candidate_cells']+=len(witness[2])
    counts['original_scan_cells']+=len(parent.board)
    value=current
    for index in witness[2]:
        if parent.board[index] is child.board[index]:continue
        old=r._component_map_cell(parent,index)
        new=r._component_map_cell(child,index)
        if old!=new:
            value=r._xor(value,r._component_token(('board',index),old))
            value=r._xor(value,r._component_token(('board',index),new))
    before=r._nonboard_component_map(parent,compiled)
    after=r._nonboard_component_map(child,compiled)
    for address in before.keys()|after.keys():
        old=before.get(address);new=after.get(address)
        if ((address in before)!=(address in after) or old!=new or
            (address[0] in ('aux','aux_unknown') and not r._aux_value_equal(old,new))):
            if address in before:value=r._xor(value,r._component_token(address,old))
            if address in after:value=r._xor(value,r._component_token(address,new))
    return value
def install(active):
    local.witness=None
    e._WorkingPosition=TrackedWork if active else original_work
    r._semantic_component_diff_hash=diff if active else original_hash
