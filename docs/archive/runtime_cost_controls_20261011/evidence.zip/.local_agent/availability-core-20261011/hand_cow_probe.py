"""Private generic hand-map copy-on-access control; no effect/terminal shortcut."""
from collections import Counter
import generic_chess.core.semantic_executor as m
baseline=m._WorkingPosition
counts=Counter()

def canonical_hand(hand):
    # Direct public Hands construction does not enforce its documented invariant.
    # Only strictly increasing string keys permit no-normalization sharing.
    pairs=hand.counts
    if all(type(t) is str for t,n in pairs) and all(
        pairs[i-1][0] < pairs[i][0] for i in range(1,len(pairs))
    ):return hand
    counts['normalized_untouched']+=1
    return m.Hands(tuple(sorted(dict(pairs).items())))

class LazyHands(list):
    def __init__(self,hands):
        super().__init__((None,None));self.original=hands
    def __getitem__(self,owner):
        if not isinstance(owner,int):return [self[i] for i in range(2)][owner]
        values=super().__getitem__(owner)
        if values is None:
            values=dict(self.original[owner].counts);super().__setitem__(owner,values)
            counts['maps_copied']+=1
        return values
    def __iter__(self):
        return (self[i] for i in range(2))
    def freeze(self):
        result=[]
        for owner in range(2):
            counts['hand_results']+=1
            values=super().__getitem__(owner)
            if values is None:
                result.append(canonical_hand(self.original[owner]));counts['unaccessed']+=1
            else:
                result.append(m.Hands(tuple(sorted(values.items()))));counts['accessed']+=1
        return tuple(result)

class CopyOnAccess(baseline):
    def __init__(self,position,support):
        self.shape=support.board_shape;self.board=list(position.board)
        self.hands=LazyHands(position.hands);self.side=position.side_to_move;self.events=[]
    def to_position(self,aux_state,fingerprint):
        return m.Position(board=tuple(self.board),hands=self.hands.freeze(),
            side_to_move=self.side,ruleset_fingerprint=fingerprint,aux_state=aux_state,
            board_width=self.shape.width if self.shape.width!=self.shape.height else None,
            board_height=self.shape.height if self.shape.width!=self.shape.height else None)
def install(active):
    m._WorkingPosition=CopyOnAccess if active else baseline
