"""Count-only residual bridge: immutable-hand allocations, not speed evidence."""
import sys, importlib.util, time
from pathlib import Path
from collections import Counter
sys.path[:0] = [str(Path.cwd()), str(Path.cwd()/'tests')]
B = Path(__file__).parent
def load(name, file):
    s=importlib.util.spec_from_file_location(name,B/file)
    x=importlib.util.module_from_spec(s);s.loader.exec_module(x);return x
p=load('handprobe','indexed_eval_probe.py')
c=load('caller','installed_control.py')
from scripts.search_backend_comparison import minimal_ab
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider

def main():
    out=dict(complete=False,scope='8existing weighted lexical minimalAB D2 roots; exact traces/work/provider counters. Evaluator-owned occupancy indices; unchanged legacy attack maps and score. Count-only, no speed claim.',rows=[])
    start=time.perf_counter()
    for case in c.CASES:
        c.stopped();assert time.perf_counter()-start < 120
        compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        provider=NativeSemanticLegalityProvider.try_create(compiled,strict=True);assert provider is not None
        values=[]
        for active in (False,True):
            board=c.CoreBoard(case,compiled,provider);board.material=c.w.weighted(compiled,c.VALUES[case['game']])
            p.prepare(board.material);p.install(active)
            try:result=minimal_ab(board,2,seconds=30,node_limit=100000,trace=True)
            finally:p.install(False)
            assert result['reason']=='completed_depth'
            values.append(c.clean(result))
            out['rows'].append(dict(root=case['id'],candidate=active,decision=result,
                setup_seconds=board.material._indexed_attack_setup_seconds))
        assert values[0]==values[1],case['id']
        c.write_record(B/'indexed-eval-counts.json',out);print(case['id'],'exact',out['rows'][-1]['decode_counts'],flush=True)
    out['complete']=True;out['elapsed_descriptive_seconds']=time.perf_counter()-start;c.write_record(B/'indexed-eval-counts.json',out)
if __name__=='__main__':main()
