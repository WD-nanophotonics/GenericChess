"""Executed dirty cells versus complete board hash, stale ownership and rollback."""
import sys,importlib.util,time
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('witness',B/'write_witness_probe.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution,initial_state
from scripts.research_record import write_record
import pytest
def main():
    out=dict(complete=False,scope='Independent full-hash oracle; arbitrary distant writes, repeated writes, no writes, stale parent/child witnesses and missing producer fallback; unchanged nonboard projection.',checks=0)
    start=time.perf_counter()
    p.install(True)
    try:
        for name in ('western_chess','standard_shogi'):
            compiled=compile_ruleset_for_execution(build_builtin_ruleset(name));parent=initial_state(compiled).position
            engine=p.e.semantic_engine_for(compiled);current=p.r._full_runtime_hash(parent,compiled)
            for index in range(len(parent.board)):
                work=p.TrackedWork(parent,engine.support)
                work.set_piece(index,None)
                other=(index+len(parent.board)//2)%len(parent.board)
                work.set_piece(other,parent.board[index])
                work.set_piece(index,parent.board[other])
                work.side=1-parent.side_to_move
                child=work.to_position(parent.aux_state,parent.ruleset_fingerprint)
                assert p.diff(parent,child,compiled,current)==p.r._full_runtime_hash(child,compiled)
                out['checks']+=1
                # A value-equal copy must not acquire another producer's witness.
                local_child=replace(child)
                p.local.witness=(parent,child,(index,other))
                assert p.diff(parent,local_child,compiled,current)==p.original_hash(parent,local_child,compiled,current)
                out['checks']+=1
            child=replace(parent,side_to_move=1-parent.side_to_move)
            for witness in (None,(replace(parent),child,()),(parent,replace(child),())):
                p.local.witness=witness
                assert p.diff(parent,child,compiled,current)==p.r._full_runtime_hash(child,compiled)
                out['checks']+=1
        out['pytest_exit']=int(pytest.main(['tests/product/test_runtime_aux_identity.py','tests/product/test_semantic_trial_checkpoint.py','tests/product/test_capture_and_hands.py','tests/product/test_native_public_projection.py','tests/product/test_native_legality_terminal_boundary.py','-q','-p','no:cacheprovider','--basetemp',str(B/'write-witness-contract-tests')]))
        assert out['pytest_exit']==0
        out['counts']=dict(p.counts);out['complete']=True
    finally:
        p.install(False);out['seconds']=time.perf_counter()-start;write_record(B/'write-witness-contract.json',out)
if __name__=='__main__':main()
