"""Changed premise: record actual writes only for Runtime formal transition."""
import ast,inspect,textwrap,importlib.util
from pathlib import Path
import generic_chess.core.semantic_executor as e
import generic_chess.core.search_runtime as r
s=importlib.util.spec_from_file_location('allwrites',Path(__file__).with_name('write_witness_probe.py'));w=importlib.util.module_from_spec(s);s.loader.exec_module(w)
original_push=r.SearchPathRuntime._push_impl
original_work=e._WorkingPosition
counts=w.counts
local=w.local
def factory(position,support):
 if getattr(local,'formal_parent',None) is position:
  local.formal_parent=None;counts['tracked_formal_work']+=1
  return w.TrackedWork(position,support)
 counts['untracked_work']+=1
 return original_work(position,support)
def formal_transition(engine,parent,action,binding,checkpoint):
 local.formal_parent=parent;local.witness=None
 try:return engine._transition(parent,action,binding,checkpoint=checkpoint)
 finally:local.formal_parent=None
class Wrap(ast.NodeTransformer):
 def visit_Call(self,node):
  node=self.generic_visit(node)
  if isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=='engine' and node.func.attr=='_transition':
   assert len(node.args)==3
   return ast.copy_location(ast.Call(func=ast.Name(id='formal_transition',ctx=ast.Load()),args=[ast.Name(id='engine',ctx=ast.Load()),*node.args],keywords=node.keywords),node)
  return node
source=inspect.getsource(original_push);tree=ast.fix_missing_locations(Wrap().visit(ast.parse(textwrap.dedent(source))))
namespace=dict(original_push.__globals__);namespace['formal_transition']=formal_transition
exec(compile(tree,'private-formal-write-witness','exec'),namespace)
patched=namespace['_push_impl']
def install(active):
 local.witness=None;local.formal_parent=None
 e._WorkingPosition=factory if active else original_work
 r._semantic_component_diff_hash=w.diff if active else w.original_hash
 namespace['_semantic_component_diff_hash']=w.diff if active else w.original_hash
 r.SearchPathRuntime._push_impl=patched if active else original_push
