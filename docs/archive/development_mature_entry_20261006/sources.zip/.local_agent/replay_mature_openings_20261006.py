"""Replay every declared budget/start game, including its original prefix."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-openings';out=p/'replay.json';assert not out.exists()
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());report={'complete':False,'scope':'Full prefix and played-history replay, author/Core legal sets, board/rights/rawEP and exact final state. No price/Elo inference.','inputs':{},'games':[],'errors':[]}
for n in range(3):
 f=p/f'games-{n}-resume.json';raw=f.read_bytes();data=json.loads(raw);assert data['complete'] and len(data['games'])==12;report['inputs'][f.name]=hashlib.sha256(raw).hexdigest()
 for index,g in enumerate(data['games']):
  author=d.UciOpponent(None,g['initial_fen'],1);s,w=d.replay_prefix(g['initial_fen'],c,g['opening_uci'],(author,))
  for row in g['moves']:
   legal={d.uci(a):a for a in d.iter_legal_actions(s,c)}
   assert set(legal)=={m.uci() for m in author.board.legal_moves},(n,index,s.ply_count,'legal_set')
   assert row['legal'] and row['move'] in legal and row['side']==s.position.side_to_move and row['ply']==s.ply_count
   s=d.apply_action(s,legal[row['move']],c);author.push(row['move'],s)
  assert d.record_value(s)==g['final_state']
  assert len(s.history)==len(g['opening_uci'])+len(g['moves'])+1
  report['games'].append({'budget':data['material']['seconds_per_search'],'index':index,'id':g['id'],'white':g['white'],'black':g['black'],'prefix_plies':len(g['opening_uci']),'played_plies':len(g['moves']),'end':g['end'],'winner':g['winner'],'author_checkmate':author.board.is_checkmate(),'author_stalemate':author.board.is_stalemate()});d.write_record(out,report)
report.update(complete=True,played_plies=sum(g['played_plies'] for g in report['games']),prefix_plies=sum(g['prefix_plies'] for g in report['games']));d.write_record(out,report)
print('Full replay',len(report['games']),report['played_plies'],report['prefix_plies'],'errors0')
