"""Replay every stronger/direct cell, retaining full opening history."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-openings';out=p/'additional-replay.json';assert not out.exists();compiled=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());report={'complete':False,'scope':'All stronger/direct candidate legal-set, board/rights/rawEP, exact final-history replays; no outcome-strength inference.','inputs':{},'games':[],'errors':[]}
for filename in ('pair-games.json','stronger-games.json'):
 raw=(p/filename).read_bytes();data=json.loads(raw);assert data['complete'] and len(data['games'])==12;report['inputs'][filename]=hashlib.sha256(raw).hexdigest()
 for index,g in enumerate(data['games']):
  player=d.UciOpponent(None,g['initial_fen'],1);s,_=d.replay_prefix(g['initial_fen'],compiled,g['opening_uci'],(player,))
  for row in g['moves']:
   legal={d.uci(a):a for a in d.iter_legal_actions(s,compiled)};assert set(legal)=={m.uci() for m in player.board.legal_moves}
   assert row['legal'] and row['move'] in legal and row['side']==s.position.side_to_move and row['ply']==s.ply_count
   s=d.apply_action(s,legal[row['move']],compiled);player.push(row['move'],s)
  assert d.record_value(s)==g['final_state'] and len(s.history)==len(g['opening_uci'])+len(g['moves'])+1
  report['games'].append({'source':filename,'index':index,'id':g['id'],'plies':len(g['moves']),'end':g['end'],'winner':g['winner'],'white':g['white'],'black':g['black']});d.write_record(out,report)
report.update(complete=True,played_plies=sum(g['plies'] for g in report['games']),prefix_plies=4*len(report['games']));d.write_record(out,report);print('Additional replay',len(report['games']),report['played_plies'],'errors0')
