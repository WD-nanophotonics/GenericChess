"""Finite diagnostic of the observed unfinished game; no price fitting."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-openings';out=p/'unfinished-reference.json';assert not out.exists()
raw=(p/'games-1-resume.json').read_bytes();data=json.loads(raw);assert data['complete']
games=[g for g in data['games'] if g['id']=='central-d' and g['white']=='linear_mixture'];assert len(games)==1
g=games[0];assert not g['finished'] and len(g['moves'])==160
points=[0,40,80,120,158]
binary=ROOT/'.local_agent/mature-search/build/fairy-material.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
report={'scope':'Ex-post development diagnostic, no holdout/WDL/strength/price fitting. Finite strong child proxies; no inference of originally examined leaves.','points':points,'input_sha256':hashlib.sha256(raw).hexdigest(),'material_seconds':1,'reference_limit':{'nodes':1000000,'time':2,'threads':1,'hash_mib':16,'limit_strength':False},'rows':[],'complete':False}
d.write_record(out,report)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());board=chess.Board(g['initial_fen']);state,_=d.replay_prefix(g['initial_fen'],c,g['opening_uci'])
for m in g['opening_uci']:board.push_uci(m)
with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as engine,chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as strong:
 engine.configure({'Threads':1,'Hash':16,'Use NNUE':False});strong.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
 for index,played in enumerate(g['moves']):
  if index in points:
   legal={d.uci(a):a for a in d.iter_legal_actions(state,c)};assert set(legal)=={m.uci() for m in board.legal_moves}
   row={'played_index':index,'actual_ply':state.ply_count,'fen':board.fen(en_passant='fen'),'actual':played['move'],'material':[],'references':{}};report['rows'].append(row)
   for policy in d.POLICIES:
    player=d.UciMaterial(engine,g['initial_fen'],policy,1);prefix=g['opening_uci']+[r['move'] for r in g['moves'][:index]];d.replay_prefix(g['initial_fen'],c,prefix,(player,));m,r=player.choose();assert m in legal;row['material'].append(r)
   strong.configure({'Clear Hash':None});info=strong.analyse(board,chess.engine.Limit(nodes=1000000,time=2),game=object());best=info['pv'][0].uci();row['reference_best']=best
   for move in sorted({best,played['move']}|{r['move'] for r in row['material']}):
    child=board.copy(stack=True);child.push_uci(move);strong.configure({'Clear Hash':None});info=strong.analyse(child,chess.engine.Limit(nodes=1000000,time=2),game=object());score=info['score'].pov(board.turn)
    row['references'][move]={'cp':score.score(),'mate':score.mate(),'nodes':info.get('nodes'),'depth':info.get('depth'),'seconds':info.get('time'),'pv':[m.uci() for m in info.get('pv',())]};d.write_record(out,report)
   print(index,played['move'],[(r['policy'],r['move']) for r in row['material']],row['references'],flush=True)
  legal={d.uci(a):a for a in d.iter_legal_actions(state,c)};state=d.apply_action(state,legal[played['move']],c);board.push_uci(played['move'])
assert d.record_value(state)==g['final_state'];report['complete']=True;d.write_record(out,report)
