"""One fixed direct comparison to address observed weak-opponent saturation."""
import sys,json,time,hashlib
from itertools import combinations
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-openings';out=p/'pair-games.json';assert not out.exists();assert json.loads((p/'progress.json').read_bytes())['complete']
suite=json.loads((p/'suite.json').read_bytes());compiled=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());binary=ROOT/'.local_agent/mature-search/build/fairy-material.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini'
report={'scope':'Adaptive development response to weak-opponent saturation, not independent price validation/Elo. All three unordered table pairs, both colors, both existing declared opening histories; twelve cells fixed before outcomes. Search/SEE/pruning common, material leaves differ.','question':'Does direct equal-time candidate play expose distinctions hidden by the weak comparator?','conditions':{'seconds_per_move':.25,'threads_per_engine':1,'hash_mib_per_engine':16,'max_subsequent_plies':160},'cost':'Twelve interruptible single-thread games, maximum480sec requested search plus transport/recording; no outcome-driven extra cells.','producer_sha256':hashlib.sha256((ROOT/'scripts/chess_development.py').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'suite_sha256':hashlib.sha256((p/'suite.json').read_bytes()).hexdigest(),'games':[],'complete':False}
def stopped():
 for n in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise KeyboardInterrupt('User stop retained')
class Pair:
 def __init__(self,engines,fen,white,black):self.players=tuple(d.UciMaterial(e,fen,policy,.25) for e,policy in zip(engines,(white,black)))
 @property
 def board(self):return self.players[0].board
 def choose(self):return self.players[0 if self.board.turn else 1].choose()
 def push(self,move,state):
  for player in self.players:player.push(move,state)
start=time.perf_counter();d.write_record(out,report)
for case in suite['cases']:
 for a,b in combinations(d.POLICIES,2):
  for white,black in ((a,b),(b,a)):
   stopped()
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as one,chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as two:
    for e in (one,two):e.configure({'Threads':1,'Hash':16,'Use NNUE':False})
    pair=Pair((one,two),case['fen'],white,black)
    def progress(game):report['active_game']=dict(id=case['id'],**game);d.write_record(out,report);stopped()
    g=d.play_game(case['fen'],compiled,white,black,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,local_external=pair,prefix=case['opening_uci'])
    report.pop('active_game',None);report['games'].append(dict(id=case['id'],**g));d.write_record(out,report);print(case['id'],white,black,g['end'],g['winner'],g['plies_played'],flush=True)
report.update(complete=True,wall_seconds=time.perf_counter()-start);d.write_record(out,report)
