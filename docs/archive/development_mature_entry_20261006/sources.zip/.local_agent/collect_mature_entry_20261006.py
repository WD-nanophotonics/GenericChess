"""One portable evidence record and inert exact source archive; no Slack data."""
import sys,json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'.local_agent/mature-openings';out=ROOT/'docs/research/data/chess_mature_entry_results_20261006.json';assert not out.exists()
names=['declaration.json','suite.json','games-0.json','games-0-resume.json','games-1-resume.json','games-2-resume.json','progress.json','replay.json','unfinished-reference.json','pair-games.json','stronger-games.json','additional-replay.json','summary.json','adapter-smoke-suite.json','adapter-smoke.json']
records={}
for name in names:
 raw=(p/name).read_bytes();records[name]={'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'body':json.loads(raw)}
raw=(ROOT/'.local_agent/shogi_checked_drop_20261006.json').read_bytes();records['shogi_checked_drop.json']={'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'body':json.loads(raw)}
assert records['progress.json']['body']['complete'] and records['additional-replay.json']['body']['complete']
assert records['replay.json']['body']['played_plies']+records['additional-replay.json']['body']['played_plies']==5527
report={'scope':'Runnable standard-Chess pure-material adapter;60 declared/adaptive development games and complete replay, finite unfinished-game references and checked full-stock approximate-held Shogi control. No holdout/Elo/intrinsic prior or all-rule native qualification.','core_game_replay':{'games':60,'played_plies':5527,'opening_prefix_plies':240,'mismatches':0},'tests':{'passed':21,'scope':'chess_development and chess_material_transport; not full repository'},'normalization':'Raw report bodies preserved without edits. Production CLI use_tt/use_ordering=false in frozen material reports describe ignored local flags, not the external engine. Material usesHash16 and fixed old ordering/SEE/pruning. Current entry corrects those flags to null and marks unknown nativeCPU/cache/leaf counters; only metadata changed. Exact experimental producer archived separately.','previous_mature_qualification':{'path':'chess_runtime_cost_results_20261006.json','sha256':hashlib.sha256((ROOT/'docs/research/data/chess_runtime_cost_results_20261006.json').read_bytes()).hexdigest(),'binary_sha256':records['declaration.json']['body']['binary_sha256']},'records':records}
assert 'C:\\Users\\wdai' not in json.dumps(report)
write_record(out,report)
archive=ROOT/'docs/archive/development_mature_entry_20261006';files=['scripts/chess_development.py','tests/test_chess_material_transport.py']+['.local_agent/'+n for n in ['run_mature_openings_20261006.py','resume_mature_openings_20261006.py','replay_mature_openings_20261006.py','shogi_checked_drop_20261006.py','shogi_checked_drop_prediction_20261006.md','diagnose_mature_unfinished_20261006.py','play_mature_pairs_20261006.py','play_mature_stronger_20261006.py','replay_mature_additional_20261006.py','summarize_mature_openings_20261006.py','collect_mature_entry_20261006.py']]
zpath=archive/'sources.zip';assert not zpath.exists();index={}
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for name in files:
  raw=(ROOT/name).read_bytes();z.writestr(name,raw);index[name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
with zipfile.ZipFile(zpath) as z:
 for name,v in index.items():assert hashlib.sha256(z.read(name)).hexdigest()==v['sha256']
write_record(archive/'sources.json',{'scope':'Exact inert producers/drivers, current metadata-corrected entry/test; frozen_entry.zip preserves actual timed1472 producer. No binaries/credentials/Slack raw outputs.','entries':index,'zip_sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'portable_sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
print('portable',len(records),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),'source entries',len(index))
