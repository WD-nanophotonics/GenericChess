"""Descriptive groups, never convert unfinished games into draws or Elo."""
import sys,json,hashlib
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'.local_agent/mature-openings';out=p/'summary.json';assert not out.exists()
progress=json.loads((p/'progress.json').read_bytes());assert progress['complete']
result={'scope':'Single development run per cell, adaptive exposed design. No Elo/independent price validation/causal time effect; stochastic opponent and differing trajectories. Unfinished is not draw.','budgets':[],'complete':False}
for n in range(3):
 raw=(p/f'games-{n}-resume.json').read_bytes();d=json.loads(raw);assert d['complete'] and len(d['games'])==12
 group={'seconds':d['material']['seconds_per_search'],'batch_wall_seconds':progress['batches'][n]['wall_seconds'],'input_sha256':hashlib.sha256(raw).hexdigest(),'models':{},'cells':[]}
 for policy in ('geometric_half','linear_mixture','unit'):
  counts=Counter();rows=[];plies=0
  for g in d['games']:
   if policy not in (g['white'],g['black']):continue
   color=0 if g['white']==policy else 1
   outcome=('unfinished' if not g['finished'] else 'draw' if g['winner'] is None else 'win' if g['winner']==color else 'loss');counts[outcome]+=1;plies+=g['plies_played'];rows.extend(r for r in g['moves'] if r['policy']==policy)
   group['cells'].append({'id':g['id'],'policy':policy,'color':color,'outcome':outcome,'end':g['end'],'plies':g['plies_played']})
  group['models'][policy]={'outcomes':dict(counts),'played_plies':plies,'local_moves':len(rows),'uci_reported_nodes':sum(r.get('engine_nodes',0) or 0 for r in rows),'local_call_wall_seconds':sum(r['wall_seconds'] for r in rows),'controller_cpu_seconds':sum(r['controller_cpu_seconds'] for r in rows),'native_engine_cpu_seconds':None,'cache_hits':None,'scored_leaves':None,'reported_maxdepth245_calls':sum(r.get('engine_depth')==245 for r in rows)}
 result['budgets'].append(group)
for filename in ('pair-games.json','stronger-games.json'):
 f=p/filename
 if not f.exists():continue
 raw=f.read_bytes();d=json.loads(raw);assert d['complete'] and len(d['games'])==12
 group={'conditions':d['conditions'],'wall_seconds':d['wall_seconds'],'input_sha256':hashlib.sha256(raw).hexdigest(),'cells':[]}
 for g in d['games']:
  group['cells'].append({'id':g['id'],'white':g['white'],'black':g['black'],'end':g['end'],'winner':g['winner'],'finished':g['finished'],'plies':g['plies_played']})
 result[filename]=group
result['complete']=True;write_record(out,result)
print(json.dumps({g['seconds']:{k:v['outcomes'] for k,v in g['models'].items()} for g in result['budgets']}))
