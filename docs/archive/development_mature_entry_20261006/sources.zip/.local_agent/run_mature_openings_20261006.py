"""Prospective equal-resource curves through the existing development entry."""
import sys, json, hashlib, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import scripts.chess_development as d
import chess
p=ROOT/'.local_agent/mature-openings';p.mkdir(exist_ok=True)
manifest=p/'declaration.json';assert not manifest.exists()
fen=chess.STARTING_FEN
suite={'scope':'Two prospectively chosen ordinary legal opening prefixes, development only; no holdout, Elo or tuned prices. Full initial history retained.','source':'Mechanical fixed prefixes; no outcomes used in selection','cases':[
 {'id':'open-file-e','fen':fen,'opening_uci':['e2e4','e7e5','g1f3','b8c6']},
 {'id':'central-d','fen':fen,'opening_uci':['d2d4','d7d5','c2c4','e7e6']}]}
compiled=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
for c in suite['cases']:
 s,_=d.replay_prefix(c['fen'],compiled,c['opening_uci']);assert not s.terminal_status.is_terminal
suite_path=p/'suite.json';d.write_record(suite_path,suite)
binary=ROOT/'.local_agent/mature-search/build/fairy-material.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini';other=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
old=json.loads((ROOT/'.local_agent/mature-search/probe-results.json').read_bytes());assert old['complete'] and old['binary_sha256']==hashlib.sha256(binary.read_bytes()).hexdigest()
declaration={'question':'Does the runnable pure-material player retain useful feedback on two different opening histories, and does0.25/1/4sec change failures or relative tables enough to choose a practical budget?','decision':'Keep all cells/partials; useful failure trajectories guide the next error diagnostic. Do not pick a winner or change stopping success criteria after outcomes. Resource curves, not extra budget only for candidate.','cost':'36 prospective games, three budgets x two starts x three models x both colors;160 subsequent-ply ceiling, one engine thread/Hash16 each, bounded sequential execution and per-move user-stop checks. Requested worst-case local search5040sec plus reference transport; observed actual cost retained. No extra worker or fees.','budgets_seconds':[.25,1,4],'max_plies':160,'suite_sha256':hashlib.sha256(suite_path.read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256((ROOT/'scripts/chess_development.py').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'opponent_sha256':hashlib.sha256(other.read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'opponent_conditions':{'nodes':50000,'elo_setting':1320,'seconds_fuse':1,'threads':1,'hash_mib':16},'source_qualification':'Previous pinned source/Eval patch/build/static-gauge records; exact binary hash retained.'}
d.write_record(manifest,declaration)
def stopcheck():
 for name in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise KeyboardInterrupt('User stop retained')
original=d.play_game
def guarded(*args,**kwargs):
 stopcheck();a=list(args)
 if len(a)>7:save=a[7]
 else:save=kwargs.get('save_move')
 def progress(game):
  if save:save(game)
  stopcheck()
 if len(a)>7:a[7]=progress
 else:kwargs['save_move']=progress
 return original(*a,**kwargs)
d.play_game=guarded
progress={'complete':False,'batches':[]};start=time.perf_counter()
for index,seconds in enumerate(declaration['budgets_seconds']):
 stopcheck();out=p/f'games-{index}.json';t=time.perf_counter()
 d.main(['play-uci','--suite',str(suite_path),'--output',str(out),'--engine',str(other),'--material-engine',str(binary),'--material-config',str(config),'--uci-python',str(ROOT/'.local_agent/certificate_source/python-chess'),'--seconds',str(seconds),'--max-plies','160'])
 progress['batches'].append({'seconds':seconds,'wall_seconds':time.perf_counter()-t,'report_sha256':hashlib.sha256(out.read_bytes()).hexdigest()});d.write_record(p/'progress.json',progress)
progress.update(complete=True,wall_seconds=time.perf_counter()-start);d.write_record(p/'progress.json',progress)
