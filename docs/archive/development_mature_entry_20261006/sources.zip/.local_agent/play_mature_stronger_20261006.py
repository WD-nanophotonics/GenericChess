"""One decision-driven stronger comparator after observed weak saturation."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-openings';out=p/'stronger-games.json';assert not out.exists()
assert json.loads((p/'progress.json').read_bytes())['complete']
suite=json.loads((p/'suite.json').read_bytes());c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
binary=ROOT/'.local_agent/mature-search/build/fairy-material.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
report={'scope':'Single adaptive development batch selected after1320 comparator saturation; not independent validation, calibrated Elo or price fitting. All three fixed tables/both colors/two unchanged opening histories retained.','question':'Does1800-configured reference at the same50000node/1sec fuse expose useful failures without extra local search?','conditions':{'local_seconds':.25,'local_threads':1,'local_hash_mib':16,'reference_elo_setting':1800,'reference_nodes':50000,'reference_time_fuse':1,'reference_threads':1,'reference_hash_mib':16,'subsequent_ply_limit':160},'cost':'Twelve declared games, per-action saved progress/user-stop checks; no escalating strength until a favored result. If saturated, record it and choose a different decision-changing diagnostic later.','producer_sha256':hashlib.sha256((ROOT/'scripts/chess_development.py').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'opponent_sha256':hashlib.sha256(ref.read_bytes()).hexdigest(),'suite_sha256':hashlib.sha256((p/'suite.json').read_bytes()).hexdigest(),'games':[],'complete':False}
recording={'seconds':0.,'writes':0,'bytes':0}
def save():
 start=time.perf_counter();d.write_record(out,report);recording['seconds']+=time.perf_counter()-start;recording['writes']+=1;recording['bytes']+=out.stat().st_size
def stopcheck():
 for n in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise KeyboardInterrupt('User stop retained')
start=time.perf_counter();save()
for case in suite['cases']:
 for policy in d.POLICIES:
  for color in (0,1):
   stopcheck()
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as engine,chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as reference:
    engine.configure({'Threads':1,'Hash':16,'Use NNUE':False});reference.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':True,'UCI_Elo':1800})
    local=d.UciMaterial(engine,case['fen'],policy,.25);other=d.UciOpponent(reference,case['fen'],50000)
    def progress(game):report['active_game']=dict(id=case['id'],**game);save();stopcheck()
    game=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=other,local_external=local,prefix=case['opening_uci'])
    report.pop('active_game',None);report['games'].append(dict(id=case['id'],**game));save();print(case['id'],policy,color,game['end'],game['winner'],game['plies_played'],flush=True)
report.update(complete=True,wall_seconds=time.perf_counter()-start,recording_cost=recording);d.write_record(out,report)
