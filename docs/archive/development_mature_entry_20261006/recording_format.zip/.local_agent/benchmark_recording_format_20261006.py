import hashlib,json,time,sys,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import write_record
root=Path('.local_agent/mature-openings')
source=root/'stronger-games.json'
body=source.read_bytes();value=json.loads(body)
rows=[]
for pair in range(4):
    for indent in ((2,None) if pair%2==0 else (None,2)):
        target=root/('format-pretty.json' if indent==2 else 'format-compact.json')
        start=time.perf_counter();write_record(target,value,indent=indent)
        seconds=time.perf_counter()-start
        encoded=target.read_bytes()
        assert json.loads(encoded)==value
        rows.append(dict(pair=pair,indent=indent,seconds=seconds,bytes=len(encoded),equal=True))
report=dict(scope='Offline final-frontier microbenchmark, four alternating pairs; not measured game-chain speed improvement.',
    source_sha256=hashlib.sha256(body).hexdigest(),rows=rows,
    modes=[dict(indent=indent,total_seconds=sum(r['seconds'] for r in rows if r['indent']==indent),
        total_bytes=sum(r['bytes'] for r in rows if r['indent']==indent)) for indent in (2,None)],
    tests_passed=27,default_format_unchanged=True,atomic_replacement_unchanged=True,
    repaired_failure='First post-formatting collection found an indentation edit error; fixed before benchmark;27 targeted checks then passed.')
write_record(root/'recording-format.json',report)
write_record(Path('docs/research/data/chess_recording_format_20261006.json'),report)
archive=Path('docs/archive/development_mature_entry_20261006')
files=['scripts/research_record.py','scripts/chess_development.py','tests/test_research_record.py',
       '.local_agent/benchmark_recording_format_20261006.py']
with zipfile.ZipFile(archive/'recording_format.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in files:z.write(name,name)
index=[]
with zipfile.ZipFile(archive/'recording_format.zip') as z:
    for name in files:
        data=Path(name).read_bytes();assert z.read(name)==data
        index.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
write_record(archive/'recording_format.json',dict(scope='Final metadata and compact progress writer; separate from original frozen game source.',files=index))
print(json.dumps(report))
