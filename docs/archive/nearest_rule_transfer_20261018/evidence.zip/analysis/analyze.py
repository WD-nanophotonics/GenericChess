"""Prespecified physical outcome contrasts; no fitting or dropped UNKNOWNs."""
from pathlib import Path
from collections import Counter,defaultdict
import sys,json,random,time
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
D=R/'.local_agent/nearest-rule-transfer-20261017';started=time.perf_counter()
p=json.loads((D/'plan.json').read_bytes());done=json.loads((D/'result.json').read_bytes())
physical={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};slots=json.loads((D/'slots.json').read_bytes())['slots'];by={}
for i,key in enumerate(slots):
 by[tuple(key)]=physical.get(i,dict(slot=i,rule=key[0],family=key[1],label=key[2],candidate_owner=key[3],foe=key[4],reward=None,record=None,ending='UNSTARTED_UNKNOWN',nodes=0,queries=0))
assert len(by)==len(slots)==p['planned_physical']
def bound(observations):
 coeff=Counter();seen={}
 for obs in observations:
  for k,g in obs:
   coeff[g['slot']]+=k;seen[g['slot']]=g
 known=radius=0
 for slot,c in coeff.items():
  g=seen[slot]
  if g['reward'] is None:radius+=abs(c)
  else:known+=c*g['reward']
 return [(known-radius)/len(observations),(known+radius)/len(observations)]
rows=[]
for foe in p['foes']:
 for method in ['initial','TD','WDL']:
  comparisons=['mapped-direct','static-mapped','static-direct']
  if method!='initial':comparisons+=['direct-trained-initial','mapped-trained-initial','mapped-gain-minus-direct-gain']
  for comp in comparisons:
   observations=[];groups=defaultdict(list)
   for rid in p['rules']:
    for f in p['families']:
     for seed in p['seeds']:
      for owner in (0,1):
       label=method+str(seed);direct=by[rid,f,label,owner,foe];mapped=by[rid,f,'mapped_'+label,owner,foe];initial=by[rid,f,'initial'+str(seed),owner,foe];mi=by[rid,f,'mapped_initial'+str(seed),owner,foe];static=by[rid,f,'rule_static_v2',owner,foe]
       terms={'mapped-direct':[(1,mapped),(-1,direct)],'static-mapped':[(1,static),(-1,mapped)],'static-direct':[(1,static),(-1,direct)],'direct-trained-initial':[(1,direct),(-1,initial)],'mapped-trained-initial':[(1,mapped),(-1,mi)],'mapped-gain-minus-direct-gain':[(1,mapped),(-1,mi),(-1,direct),(1,initial)]}[comp]
       obs=dict(rule=rid,family=f,seed=seed,owner=owner,terms=terms);observations.append(obs);groups[rid,f].append(terms)
   gb={k:bound(v) for k,v in groups.items()};rng=random.Random(2026101801);boot=[]
   for _ in range(2000):
    selected=[gb[g,rng.choice(p['families'])] for g in p['rules'] for _ in p['families']];boot.append([sum(x[j] for x in selected)/len(selected) for j in (0,1)])
   def sub(field,value):return bound([x['terms'] for x in observations if x[field]==value])
   rows.append(dict(foe=foe,method=method,contrast=comp,observations=len(observations),bounds=bound([x['terms'] for x in observations]),fixed_rules_family_95_envelope=[sorted(x[0] for x in boot)[49],sorted(x[1] for x in boot)[1949]],by_role={str(c):sub('owner',c) for c in (0,1)},by_seed={str(seed):sub('seed',seed) for seed in p['seeds']},by_rule={str(rid):sub('rule',rid) for rid in p['rules']},same_first_two_full_records=sum(x['terms'][0][1]['record'] is not None and x['terms'][0][1]['record']==x['terms'][1][1]['record'] for x in observations),independence='Fixed8rules/foursourceinitials/nearestsourceassignment; resample entire rule-family blocks, not population confidence'))
for foe in p['foes']:
 obs=[[(1,by[g,f,'rule_static_v2',owner,foe]),(-1,by[g,f,'unit',owner,foe])] for g in p['rules'] for f in p['families'] for owner in (0,1)]
 rows.append(dict(foe=foe,method='baseline',contrast='static-unit',observations=len(obs),bounds=bound(obs)))
qcounts=Counter();caller=kernel=0.
for line in (D/'queries.jsonl').open(encoding='utf-8'):
 q=json.loads(line);qcounts['queries']+=1;qcounts['nodes']+=q['nodes'];qcounts['fallbacks']+=q['used_fallback'];qcounts['completedD2']+=q['completed_depth']==2;caller+=q['caller_seconds'];kernel+=q['kernel_seconds']
counts={}
for foe in p['foes']:
 for label in p['profiles']:
  rr=[g for (gs,f,l,o,v),g in by.items() if l==label and v==foe];counts[foe+'/'+label]=dict(Counter('U' if r['reward'] is None else 'W' if r['reward']==1 else 'L' if r['reward']==-1 else 'D' for r in rr))
result=dict(status='COMPLETE_NEW_RULE_NEAREST_SOURCE_MAPPING' if done['status']=='COMPLETE' and len(physical)==3328 else 'PARTIAL_ALL_PLANNED_UNKNOWN_RETAINED',actual=len(physical),planned=3328,missing=3328-len(physical),unknown=sum(g['reward'] is None for g in physical.values()),contrasts=rows,outcomes=counts,query_counts=dict(qcounts),caller_seconds=caller,kernel_seconds=kernel,seconds=time.perf_counter()-started,scope='All3328physical/no virtualUnit copies; missing/U[-1,1]. Coefficients of reused physical static/initial outcomes combined BEFORE bounds, including gain differences. Fixed8generatedclassiclike4x4rules with fullpromotion/drop/aux/history; not population/universalrulevalue or equaltrainingcost. No frozeninput refit/defaultselection/capextension.')
write_json(D/'analysis.json',result)
for x in rows:print(x['foe'],x['method'],x['contrast'],x['bounds'],x.get('fixed_rules_family_95_envelope'))
