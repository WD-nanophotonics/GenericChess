import sys,json,time,hashlib,random,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=root/'.local_agent/target-context-20261008';out=p/'displacement-role-pilot.json';assert not out.exists();decl=p/'displacement-law-declaration.json';law=json.loads(decl.read_bytes())
r={'complete':False,'declaration':law,'declaration_sha256':hashlib.sha256(decl.read_bytes()).hexdigest(),'correction':'v1/v2 retained: v1 used base=current for promoted Shogi; v2 incorrectly treated original Chess N/B/R/Q as pawn-origin. v3 initial-inventory source roles retain own base, only absent promoted Shogi roles use unique original-type provenance. Same frozen layouts, no reselection. One-step geometry may agree but physical capture hands must be correct.', 'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'games':{}}
total_started=time.perf_counter();write_record(out,r)
try:
 for name,base in [('chess',build_western_chess_ruleset()),('shogi',build_standard_shogi_ruleset())]:
  n=base.board_size;types=[x.type_id for x in base.piece_types if not x.is_anchor];anchor=next(x.type_id for x in base.piece_types if x.is_anchor);inventory=[x.current_type_id for row in base.initial_position for x in row if x and x.owner==0 and x.current_type_id in types]
  provenance={tid:(tid if tid in inventory else next(pt.type_id for pt in base.piece_types if tid in pt.promotion_target_ids)) for tid in types}
  g={'source_base_provenance':provenance,'definition_template':ruleset_to_dict(base),'source_types':types,'target_inventory':inventory,'rows':[],'explicit_transitions':0};r['games'][name]=g;started=time.perf_counter()
  strata=[];m=n-2;inner=[y*n+x for y in range(1,n-1) for x in range(1,n-1)]
  for dx in range(1-m,m):
   for dy in range(1-m,m):
    if dx==dy==0:continue
    eligible=[sq for sq in inner if 1<=sq%n+dx<n-1 and 1<=sq//n+dy<n-1]
    strata.append((dx,dy,eligible,len(eligible)/(m*m*(m*m-1))))
  g['declared_strata']=len(strata);g['declared_mass']=sum(x[3] for x in strata)
  for index,(dx,dy,eligible,mass) in enumerate(strata):
   seed=law['seeds'][name]+index;rng=random.Random(seed);source=rng.choice(eligible);target=source+dx+n*dy;cells=[source,target]+rng.sample([sq for sq in inner if sq not in (source,target)],4);target_type=rng.choice(inventory);others=[rng.choice(inventory) for _ in range(4)]
   for actor in types:
    for owner in (0,1):
     assert time.perf_counter()-started<300 and g['explicit_transitions']<500000
     assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
     row={'seed':seed,'mass':mass,'displacement':[dx,dy],'actor':actor,'owner':owner,'target_type':target_type,'background_types':others,'cells':cells};g['rows'].append(row)
     board=[None]*(n*n);board[0]=Piece(0,anchor,anchor);board[-1]=Piece(1,anchor,anchor);board[source]=Piece(owner,provenance[actor],actor);board[target]=Piece(1-owner,target_type,target_type)
     for sq,tid,actor_owner in zip(cells[2:],others,(0,0,1,1)):board[sq]=Piece(actor_owner,tid,tid)
     try:
      compiled=compile_ruleset_for_execution(replace(base,initial_position=tuple(tuple(board[y*n:y*n+n]) for y in range(n))));engine=SemanticEngine(compiled);position=replace(GameSession(compiled).state.position,side_to_move=1-owner)
     except ValueError as exc:row.update(accepted=False,rejection=str(exc));continue
     row['accepted']=True;forecast={};reference={};ts=time.perf_counter()
     for pattern in engine._patterns:
      for action,binding in engine._iter_candidates(pattern,position):
       assert g['explicit_transitions']<500000
       child=engine._transition(position,action,binding);g['explicit_transitions']+=1;next_target=action.target if action.source==target else target
       available=any(engine.iter_legal_action_bindings(child,source=source,target=next_target))
       if child in forecast:assert forecast[child]==available
       forecast[child]=available
     row['forecast_seconds']=time.perf_counter()-ts;row['prediction']=statistics.mean(forecast.values()) if forecast else None;row['forecast_support']=len(forecast);ts=time.perf_counter()
     for action,binding in engine.iter_legal_action_bindings(position):
      assert g['explicit_transitions']<500000
      child=engine._transition(position,action,binding);g['explicit_transitions']+=1;next_target=action.target if action.source==target else target
      available=any(a.source==source and a.target==next_target for a in engine.legal_actions(child))
      if child in reference:assert reference[child]==available
      reference[child]=available
     row['reference_seconds']=time.perf_counter()-ts;row['reference']=statistics.mean(reference.values()) if reference else None;row['reference_support']=len(reference)
     row['initial_capture']=float(any(engine.iter_legal_action_bindings(replace(position,side_to_move=owner),source=source,target=target)))
   write_record(out,r);print(name,index+1,len(strata),flush=True) if index%20==0 else None
  common=[seed for seed in range(law['seeds'][name],law['seeds'][name]+len(strata)) if all(x['accepted'] and x['prediction'] is not None and x['reference'] is not None for x in g['rows'] if x['seed']==seed)]
  g['common_seeds']=common;g['common_mass']=sum(x['mass'] for x in g['rows'] if x['seed'] in common and x['actor']==types[0] and x['owner']==0);g['seconds']=time.perf_counter()-started
  g['scores']={a:{field:sum(x['mass']*x[field] for x in g['rows'] if x['seed'] in common and x['actor']==a)/(2*g['common_mass']) for field in ('prediction','reference','initial_capture')} for a in types} if common else {}
  for a,row in g['scores'].items():
   for field in ('prediction','reference'):row[field+'_pawn_relative']=row[field]/g['scores']['P'][field] if g['scores']['P'][field]>0 else None
  write_record(out,r)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-total_started;write_record(out,r)
