import sys,json,time,hashlib
from collections import OrderedDict
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/target-context-20261008';out=p/'attack-cache-pilot.json';assert not out.exists();source=root/'.local_agent/joint-context-20261008/tt-fresh-cohort.json';cohort=json.loads(source.read_bytes());assert cohort['complete']
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Predeclared6 exposed-root cache pilot, same12-root fixture cohort first6, no result selection. Independently cold Native semantic map memo by full(Position,ply_count), capacities0/256/4096; per-call LRU, no search-score/action/terminal/history cache. Paired order rotates, same map timing wrapper in all modes. Decision: is repeated map evaluation material enough to justify a local bounded evaluator cache? No product change. Original exposed12-root architecture diagnostic: original versus one duplicate equivalent cannon_quiet name compiled normally. Fixed old table/Native semantic attacks/fullTT/ordering/depth4/8192nodes/4sec/q0/root-scanoff, cold players, paired mode order rotated. No changed old results or validation status. Equal completed scores/legality expected; action IDs/fingerprint may differ, tied choices and traversal costs may differ. Whole120sec checkpoint, stops per call. Measures representation cost, not universal search-node invariance or player gain; no Core action coalescing/product patch.','cases':[]}
t=time.perf_counter();write_record(out,r)
try:
 for item in cohort['cases'][:6]:
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  base=ruleset_from_dict(item['definition']);quiet=next(x for x in base.semantic_actions if x.name=='cannon_quiet');variants={'original':base,'duplicate':replace(base,semantic_actions=base.semantic_actions+(replace(quiet,name='cannon_quiet_equivalent_copy'),))}
  row={'seed':item['seed'],'searches':[]};r['cases'].append(row)
  for label,capacity in [(label,capacity) for label in ('original','duplicate') for capacity in ((0,256,4096) if item['seed']%2==0 else (4096,256,0))]:
   assert time.perf_counter()-t<120
   c=compile_ruleset_for_execution(variants[label]);s=GameSession(c);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0);profile=build_ruleset_profile(c,cfg);
   class Measured(SemanticAttackEvaluator):
    def __init__(self,*a,**kw):
     super().__init__(*a,**kw);self.cache=OrderedDict();self.hits=0;self.misses=0;self.query_seconds=0
    def _attack_maps(self,state):
     started=time.perf_counter();key=(state.position,state.ply_count)
     try:
      if capacity and key in self.cache:
       self.hits+=1;self.cache.move_to_end(key);return self.cache[key]
      self.misses+=1;maps=super()._attack_maps(state)
      if capacity:
       self.cache[key]=maps
       if len(self.cache)>capacity:self.cache.popitem(last=False)
      return maps
     finally:self.query_seconds+=time.perf_counter()-started
   ev=Measured(c,profile,cfg,backend='native');player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
   d=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d)
   row['searches'].append({'variant':label,'capacity':capacity,'hits':ev.hits,'misses':ev.misses,'map_seconds':ev.query_seconds,'retained_entries':len(ev.cache),'root_legal_bindings':len(s.legal_actions()),'prices':dict(profile.board_value_by_type),'decision':record_value(d)})
  scores=[x['decision']['score'] for x in row['searches'] if x['decision']['completed_depth']==4];assert len(set(scores))<=1
  write_record(out,r);print(item['seed'],[(x['variant'],x['root_legal_bindings'],x['decision']['completed_depth'],x['decision']['nodes']) for x in row['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
