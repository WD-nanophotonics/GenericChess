import sys,json,time,hashlib,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=root/'.local_agent/target-context-20261008';source=p/'target-matrix-v2.json';data=json.loads(source.read_bytes());out=p/'query-factorial.json';assert not out.exists()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Postdeclared exposed69accepted random-context roots, all3rejections retained in source; no new sampling/fitting. Four forecast modes full/indexed source query xS0-S1/S3-capture; same independently enumerated S0/S1 physical reply distribution. Four-order rotation by root index; fresh engines per forecast; full exact reference only after all four. No S4 fixture postconditions; do not infer general unsupported-source semantics. Record stage timings separately; no overlapping jobs. Cost30000explicit reply transitions/120sec checkpoint; stop/save per root. Decision: distinguish source-query cost from capture-safety error, before any product API.','rows':[],'explicit_transitions':0}
t=time.perf_counter();write_record(out,r);base=ruleset_from_dict(data['definition_template']);modes=((False,False),(True,False),(False,True),(True,True))
try:
 for index,row in enumerate(x for x in data['rows'] if x['accepted']):
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-t<120
  source_sq,target=row['cells'][:2];board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[source_sq]=Piece(0,row['actor'],row['actor']);board[target]=Piece(1,row['target_type'],row['target_type'])
  for (owner,tid),sq in zip(((0,'R'),(0,'R'),(1,'C'),(1,'R')),row['cells'][2:]):board[sq]=Piece(owner,tid,tid)
  c=compile_ruleset_for_execution(replace(base,initial_position=tuple(tuple(board[y*8:(y+1)*8]) for y in range(8))))
  position=replace(GameSession(c).state.position,side_to_move=1);item={k:row[k] for k in ('seed','actor','target_type','cells')};item['modes']=[];r['rows'].append(item)
  for indexed,s3 in modes[index%4:]+modes[:index%4]:
   start=time.perf_counter();engine=SemanticEngine(c);groups={};capture_trials=0
   assert not any(pat.postconditions for pat in engine._patterns)
   for pattern in engine._patterns:
    for action,binding in engine._iter_candidates(pattern,position):
     child=engine._transition(position,action,binding);r['explicit_transitions']+=1;assert r['explicit_transitions']<30000
     if child in groups:continue
     next_target=action.target if action.source==target else target;pc=child.board[source_sq]
     sources={(child.side_to_move,pc.current_type_id):((source_sq,pc),)} if pc is not None and pc.owner==child.side_to_move else {}
     available=False
     for pat in engine._patterns:
      iterator=engine._iter_candidates(pat,child,sources_by_owner_type=sources) if indexed else engine._iter_candidates(pat,child)
      for a,b in iterator:
       if a.source!=source_sq or a.target!=next_target:continue
       if s3:
        capture_trials+=1
        if engine._trial_child_if_s3_legal(pat,child,a,b) is None:continue
       available=True;break
      if available:break
     groups[child]=available
   item['modes'].append({'indexed':indexed,'s3_capture':s3,'prediction':statistics.mean(groups.values()),'seconds':time.perf_counter()-start,'capture_trials':capture_trials,'physical_successors':len(groups)})
  start=time.perf_counter();engine=SemanticEngine(c);reference={}
  for a,b in engine.iter_legal_action_bindings(position):
   child=engine._transition(position,a,b);r['explicit_transitions']+=1;next_target=a.target if a.source==target else target
   reference[child]=any(z.source==source_sq and z.target==next_target for z in engine.legal_actions(child))
  item['reference']=statistics.mean(reference.values());item['reference_seconds']=time.perf_counter()-start;assert abs(item['reference']-row['reference'])<1e-12
  for s3 in (False,True):
   values=[x['prediction'] for x in item['modes'] if x['s3_capture']==s3];assert values[0]==values[1]
  if index%8==0:write_record(out,r)
 r['summary']={str(indexed)+'/'+str(s3):{'roots':len(r['rows']),'prediction_mse':statistics.mean((m['prediction']-x['reference'])**2 for x in r['rows'] for m in x['modes'] if m['indexed']==indexed and m['s3_capture']==s3),'prediction_seconds':sum(m['seconds'] for x in r['rows'] for m in x['modes'] if m['indexed']==indexed and m['s3_capture']==s3)} for indexed,s3 in modes}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
print(json.dumps({'complete':r['complete'],'seconds':r['seconds'],'summary':r.get('summary'),'transitions':r['explicit_transitions']},indent=2))
