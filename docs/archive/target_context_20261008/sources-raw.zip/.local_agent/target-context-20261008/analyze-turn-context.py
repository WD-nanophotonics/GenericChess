import sys,json,hashlib,statistics
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path('.local_agent/target-context-20261008');src=p/'turn-context-pilot-v2.json';prior=p/'displacement-role-pilot-v2.json';d=json.loads(src.read_bytes());old=json.loads(prior.read_bytes());assert d['complete'] and old['complete'];games={}
for name,g in d['games'].items():
 common=set(g['common_seeds']);rows=[x for x in g['rows'] if x['seed'] in common];den=2*g['common_mass'];types=g['source_types'];oldg=old['games'][name]
 assert set(oldg['common_seeds'])<=common
 original={(x['seed'],x['actor'],x['owner']):x for x in oldg['rows'] if x['seed'] in oldg['common_seeds']}
 agreements=[]
 for x in g['rows']:
  key=(x['seed'],x['actor'],x['owner'])
  if key in original:
   y=original[key];assert x['reference']==y['reference'] and x['prediction']==y['prediction'];agreements.append(key)
 checked=[x for x in rows if x['active_in_check']]
 assert all(x['prediction_gated']==x['reference'] for x in checked)
 scores={}
 for actor in types:
  own=[x for x in rows if x['actor']==actor]
  scores[actor]={f:sum(x['mass']*x[f] for x in own)/den for f in ('prediction','prediction_gated','reference','initial_capture')}
  scores[actor]['mse']={f:sum(x['mass']*(x[f]-x['reference'])**2 for x in own)/den for f in ('prediction','prediction_gated','initial_capture')}
  scores[actor]['positive_reference_roots']=sum(x['reference']>0 for x in own)
  scores[actor]['pawn_relative']={f:scores[actor][f]/g['scores']['P'][f] if g['scores']['P'][f]>0 else None for f in ('prediction','prediction_gated','reference')}
 games[name]={'attempted_roots':len(g['rows']),'accepted_roots':sum(x['accepted'] for x in g['rows']),'common_strata':len(common),'common_mass':g['common_mass'],'prior_initial_safe_mass':oldg['common_mass'],'prior_common_rows_exactly_preserved':len(agreements),'checked_accepted_roots':sum(x['accepted'] and x['active_in_check'] for x in g['rows']),'checked_common_roots':len(checked),'checked_gated_reference_exact':True,'reply_s3_trials':sum(x.get('reply_s3_trials',0) for x in g['rows']),'scores':scores,'overall_mse':{f:sum(x['mass']*(x[f]-x['reference'])**2 for x in rows)/(den*len(types)) for f in ('prediction','prediction_gated','initial_capture')},'explicit_outer_transitions':g['explicit_transitions'],'seconds':g['seconds']}
r={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'prior_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'scope':'Postdeclared analysis of same-layout changed context premise. Canonical rule compilation plus SemanticEngine.in_check; no claim of full game reachability/history. Original frozen population unchanged. Check-gated forecast independently trials candidates, never consumes legal reference support. Reply hands empty in this fixture; arbitrary S4 scope unsupported.','games':games}
write_record(p/'turn-context-analysis.json',r);print({name:{k:v for k,v in g.items() if k!='scores'} for name,g in games.items()})
