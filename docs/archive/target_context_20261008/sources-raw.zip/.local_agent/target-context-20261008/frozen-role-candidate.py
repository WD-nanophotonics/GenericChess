import sys,json,time,hashlib,random,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import LeapAtom
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=root/'.local_agent/target-context-20261008';out=p/'frozen-role-candidate.json';assert not out.exists();dependency=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json';base=ruleset_from_dict(json.loads(dependency.read_bytes())['definition'])
base=replace(base,piece_types=base.piece_types+(PieceType('N','N',tuple(LeapAtom(x) for x in ((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)))),),drop_allowed={**base.drop_allowed,'N':((False,)*64,(False,)*64)})
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'dependency_sha256':hashlib.sha256(dependency.read_bytes()).hexdigest(),'declaration':json.loads((p/'frozen-law-declaration.json').read_bytes()),'declaration_sha256':hashlib.sha256((p/'frozen-law-declaration.json').read_bytes()).hexdigest(),'definition_template':ruleset_to_dict(base),'rows':[],'explicit_transitions':0}
t=time.perf_counter();write_record(out,r)
try:
 for seed in range(202610089000,202610089032):
  cells=random.Random(seed).sample([y*8+x for y in range(1,7) for x in range(1,7)],6);source,target=cells[:2]
  for actor in ('C','R','N'):
   for target_type in ('C','R','N'):
    assert time.perf_counter()-t<180
    assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[source]=Piece(0,actor,actor);board[target]=Piece(1,target_type,target_type)
    for (owner,tid),sq in zip(((0,'R'),(0,'R'),(1,'C'),(1,'R')),cells[2:]):board[sq]=Piece(owner,tid,tid)
    definition=replace(base,initial_position=tuple(tuple(board[y*8:(y+1)*8]) for y in range(8)));item={'seed':seed,'actor':actor,'target_type':target_type,'cells':cells};r['rows'].append(item)
    try:c=compile_ruleset_for_execution(definition);engine=SemanticEngine(c);position=replace(GameSession(c).state.position,side_to_move=1)
    except ValueError as exc:item.update(accepted=False,rejection=str(exc));continue
    item['accepted']=True;pred={};count=0;started=time.perf_counter()
    for pattern in engine._patterns:
     for a,b in engine._iter_candidates(pattern,position):
      assert r['explicit_transitions']<30000;child=engine._transition(position,a,b);r['explicit_transitions']+=1;count+=1;next_target=a.target if a.source==target else target
      # Existing public filtered query retains full capture legality.
      assert all(not pat.postconditions for pat in engine._patterns)
      available=any(engine.iter_legal_action_bindings(child,source=source,target=next_target))
      if child in pred:assert pred[child]==available
      pred[child]=bool(available)
    item['prediction_seconds']=time.perf_counter()-started;item['prediction']=statistics.mean(pred.values());item['candidate_bindings']=count;item['physical_candidates']=len(pred)
    reference={};count=0;started=time.perf_counter()
    for a,b in engine.iter_legal_action_bindings(position):
     assert r['explicit_transitions']<30000;child=engine._transition(position,a,b);r['explicit_transitions']+=1;count+=1;next_target=a.target if a.source==target else target
     available=any(z.source==source and z.target==next_target for z in engine.legal_actions(child))
     if child in reference:assert reference[child]==available
     reference[child]=bool(available)
    item['reference_seconds']=time.perf_counter()-started;item['reference']=statistics.mean(reference.values()) if reference else None;item['legal_bindings']=count;item['physical_legal_replies']=len(reference)
    item['initial_capture']=float(any(z.source==source and z.target==target for z in engine.legal_actions(replace(position,side_to_move=0))))
  write_record(out,r)
 r['summary']={a+'->'+target_type:{'roots':sum(x['accepted'] and x['actor']==a and x['target_type']==target_type for x in r['rows']), 'rejected_roots':sum(not x['accepted'] and x['actor']==a and x['target_type']==target_type for x in r['rows']),'mean_prediction':statistics.mean(x['prediction'] for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'mean_reference':statistics.mean(x['reference'] for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'prediction_mse':statistics.mean((x['prediction']-x['reference'])**2 for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'initial_mse':statistics.mean((x['initial_capture']-x['reference'])**2 for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'worse_roots':sum((x['prediction']-x['reference'])**2>(x['initial_capture']-x['reference'])**2 for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'positive_reference_roots':sum(x['reference']>0 for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'mean_prediction_seconds':statistics.mean(x['prediction_seconds'] for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'mean_reference_seconds':statistics.mean(x['reference_seconds'] for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type)} for a in ('C','R','N') for target_type in ('C','R','N')}
 common=[seed for seed in range(202610089000,202610089032) if all(x['accepted'] and x['reference'] is not None for x in r['rows'] if x['seed']==seed)]
 r['common_seeds']=common
 r['role_score']={a:{field:statistics.mean(x[field] for x in r['rows'] if x['seed'] in common and x['actor']==a) for field in ('prediction','reference','initial_capture')} for a in ('C','R','N')}
 r['common_matrix']={a+'->'+j:{field:statistics.mean(x[field] for x in r['rows'] if x['seed'] in common and x['actor']==a and x['target_type']==j) for field in ('prediction','reference','initial_capture')} for a in ('C','R','N') for j in ('C','R','N')}
 r['common_mse']={a:statistics.mean((x['prediction']-x['reference'])**2 for x in r['rows'] if x['seed'] in common and x['actor']==a) for a in ('C','R','N')}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
print(json.dumps({'complete':r['complete'],'seconds':r['seconds'],'summary':r.get('summary'),'transitions':r['explicit_transitions']},indent=2))
