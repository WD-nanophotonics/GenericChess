import sys,json,time,hashlib,random,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import LeapAtom
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=root/'.local_agent/target-context-20261008';out=p/'capture-s3-predictor.json';assert not out.exists();dependency=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json';base=ruleset_from_dict(json.loads(dependency.read_bytes())['definition'])
base=replace(base,piece_types=base.piece_types+(PieceType('N','N',tuple(LeapAtom(x) for x in ((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)))),),drop_allowed={**base.drop_allowed,'N':((False,)*64,(False,)*64)})
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'dependency_sha256':hashlib.sha256(dependency.read_bytes()).hexdigest(),'declaration':'Postdeclared mechanism intervention on same69accepted roots: source-indexed S3 capture trial added after each independently constructed S0/S1 reply; reply support remains approximate. All fixture postconditions must be empty. Compare resulting error against original forward estimates, do not fit. Prediction still never reads actual legal reply support/outcomes. Correction: original target-matrix.json retained incomplete due to summary KeyError on3 compile-rejected roots; v2 retains same72 declared roots and explicit rejection denominators, no replacement sampling. Before outcomes:8fresh seeds202610087000..7007 xsource C/R/N xtarget C/R/N=72paired roots. Target matrix changes target type at same physical cells; no selection/fit. Declaration preserved before run in prior segment next-target-type-declaration.json. Add supported8L-leap typeN, same board/other4 identities and anchors. Six positions uniformly sampled without replacement inner6x6, no alignment filter. Uniform DISTINCT S0/S1 successor approximation versus uniform DISTINCT Core legal successor reference; same law/cell weights. Generic source-specific S0/S1 candidate iterator replaces hand-written ray/count formula, so N needs no special predictor branch. No actual reply outcomes as inputs; full Core legal capture reference after prediction. Compile acceptance failures retained. Max10000explicit frontier transitions/120sec checkpoint; stop per root/save per seed. No WDL/material/human fit or generic history-quotient claim; this tests approximation/interface transfer across one extra supported mechanic.','definition_template':ruleset_to_dict(base),'rows':[],'explicit_transitions':0}
t=time.perf_counter();write_record(out,r)
try:
 for seed in range(202610087000,202610087008):
  cells=random.Random(seed).sample([y*8+x for y in range(1,7) for x in range(1,7)],6);source,target=cells[:2]
  for actor in ('C','R','N'):
   for target_type in ('C','R','N'):
    assert time.perf_counter()-t<120
    assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[source]=Piece(0,actor,actor);board[target]=Piece(1,target_type,target_type)
    for (owner,tid),sq in zip(((0,'R'),(0,'R'),(1,'C'),(1,'R')),cells[2:]):board[sq]=Piece(owner,tid,tid)
    definition=replace(base,initial_position=tuple(tuple(board[y*8:(y+1)*8]) for y in range(8)));item={'seed':seed,'actor':actor,'target_type':target_type,'cells':cells};r['rows'].append(item)
    try:c=compile_ruleset_for_execution(definition);engine=SemanticEngine(c);position=replace(GameSession(c).state.position,side_to_move=1)
    except ValueError as exc:item.update(accepted=False,rejection=str(exc));continue
    item['accepted']=True;pred={};count=0;started=time.perf_counter()
    for pattern in engine._patterns:
     for a,b in engine._iter_candidates(pattern,position):
      assert r['explicit_transitions']<10000;child=engine._transition(position,a,b);r['explicit_transitions']+=1;count+=1;next_target=a.target if a.source==target else target
      pc=child.board[source];sources={(child.side_to_move,pc.current_type_id):((source,pc),)} if pc is not None and pc.owner==child.side_to_move else {}
      assert all(not pat.postconditions for pat in engine._patterns)
      available=any(z.source==source and z.target==next_target and engine._trial_child_if_s3_legal(pat,child,z,binding) is not None for pat in engine._patterns for z,binding in engine._iter_candidates(pat,child,sources_by_owner_type=sources))
      if child in pred:assert pred[child]==available
      pred[child]=bool(available)
    item['prediction_seconds']=time.perf_counter()-started;item['prediction']=statistics.mean(pred.values());item['candidate_bindings']=count;item['physical_candidates']=len(pred)
    reference={};count=0;started=time.perf_counter()
    for a,b in engine.iter_legal_action_bindings(position):
     assert r['explicit_transitions']<10000;child=engine._transition(position,a,b);r['explicit_transitions']+=1;count+=1;next_target=a.target if a.source==target else target
     available=any(z.source==source and z.target==next_target for z in engine.legal_actions(child))
     if child in reference:assert reference[child]==available
     reference[child]=bool(available)
    item['reference_seconds']=time.perf_counter()-started;item['reference']=statistics.mean(reference.values());item['legal_bindings']=count;item['physical_legal_replies']=len(reference)
    item['initial_capture']=float(any(z.source==source and z.target==target for z in engine.legal_actions(replace(position,side_to_move=0))))
  write_record(out,r)
 r['summary']={a+'->'+target_type:{'roots':sum(x['accepted'] and x['actor']==a and x['target_type']==target_type for x in r['rows']), 'rejected_roots':sum(not x['accepted'] and x['actor']==a and x['target_type']==target_type for x in r['rows']),'mean_prediction':statistics.mean(x['prediction'] for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'mean_reference':statistics.mean(x['reference'] for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'prediction_mse':statistics.mean((x['prediction']-x['reference'])**2 for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'initial_mse':statistics.mean((x['initial_capture']-x['reference'])**2 for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'worse_roots':sum((x['prediction']-x['reference'])**2>(x['initial_capture']-x['reference'])**2 for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'positive_reference_roots':sum(x['reference']>0 for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'mean_prediction_seconds':statistics.mean(x['prediction_seconds'] for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type),'mean_reference_seconds':statistics.mean(x['reference_seconds'] for x in r['rows'] if x['accepted'] and x['actor']==a and x['target_type']==target_type)} for a in ('C','R','N') for target_type in ('C','R','N')}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
print(json.dumps({'complete':r['complete'],'seconds':r['seconds'],'summary':r.get('summary'),'transitions':r['explicit_transitions']},indent=2))
