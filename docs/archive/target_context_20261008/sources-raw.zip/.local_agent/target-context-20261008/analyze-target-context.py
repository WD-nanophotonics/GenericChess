import sys,json,hashlib,statistics
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path('.local_agent/target-context-20261008');out=p/'final-analysis.json';assert not out.exists()
names=['target-matrix-v2','error-decomposition','public-filter-predictor','query-factorial','screen-stratified','frozen-role-candidate','cross-game-role-pilot-v4','displacement-role-pilot-v2','evaluation-cache-pilot','leaf-repeat-trace-v2']
data={n:json.loads((p/(n+'.json')).read_bytes()) for n in names}
assert all(d.get('complete',True) for d in data.values())
forecast=data['public-filter-predictor'];common=[seed for seed in sorted({x['seed'] for x in forecast['rows']}) if all(x['accepted'] for x in forecast['rows'] if x['seed']==seed)]
alias={}
for a in ('C','R','N'):
 alias[a]={}
 for field in ('prediction','reference'):
  k={j:statistics.mean(x[field] for x in forecast['rows'] if x['seed'] in common and x['actor']==a and x['target_type']==j) for j in ('C','R','N')}
  score=sum(k.values())/3;split=k['C']/6+k['C']/6+k['R']/3+k['N']/3;wrong=(2*k['C']+k['R']+k['N'])/4
  assert abs(score-split)<1e-14
  alias[a][field]={'matrix':k,'raw':score,'split_mass':split,'uniform_four_ids':wrong,'id_weight_error':wrong-score}
games={}
for name,g in data['displacement-role-pilot-v2']['games'].items():
 common=set(g['common_seeds']);types=g['source_types'];mass=g['common_mass'];denominator=2*mass
 assert abs(g['declared_mass']-1)<1e-12
 rows=[x for x in g['rows'] if x['seed'] in common]
 by_type={}
 for a in types:
  own=[x for x in rows if x['actor']==a]
  fields={f:sum(x['mass']*x[f] for x in own)/denominator for f in ('prediction','reference','initial_capture')} if own else {}
  assert all(abs(fields[f]-g['scores'][a][f])<1e-14 for f in fields)
  by_type[a]=dict(fields,common_root_count=len(own),positive_reference_roots=sum(x['reference']>0 for x in own),prediction_mse=sum(x['mass']*(x['prediction']-x['reference'])**2 for x in own)/denominator if own else None,initial_mse=sum(x['mass']*(x['initial_capture']-x['reference'])**2 for x in own)/denominator if own else None,owners={str(o):{f:sum(x['mass']*x[f] for x in own if x['owner']==o)/mass for f in ('prediction','reference')} for o in (0,1)} if own else {},pawn_relative={f:g['scores'][a][f+'_pawn_relative'] for f in ('prediction','reference')} if own else {})
 reasons={}
 for x in g['rows']:
  if not x['accepted']:
   reason=x['rejection'].split(']')[0]+']';reasons[reason]=reasons.get(reason,0)+1
 games[name]={'attempted_roots':len(g['rows']),'accepted_roots':sum(x['accepted'] for x in g['rows']),'rejections':reasons,'declared_strata':g['declared_strata'],'common_strata':len(common),'common_mass':mass,'scores':by_type,'explicit_outer_transitions':g['explicit_transitions'],'seconds':g['seconds']}
cache=data['evaluation-cache-pilot'];cache_summary={}
for mode in ('none','map','evaluation'):
 rows=[x for c in cache['cases'] for x in c['searches'] if x['mode']==mode]
 cache_summary[mode]={'calls':len(rows),'decision_seconds':sum(x['decision']['elapsed_seconds'] for x in rows),'evaluation_hits':sum(x['evaluation_hits'] for x in rows),'map_hits':sum(x['hits'] for x in rows),'retained_entries_sum':sum(x['evaluation_entries']+x['retained_entries'] for x in rows)}
for c in cache['cases']:
 for variant in ('original','duplicate'):
  rows=[x['decision'] for x in c['searches'] if x['variant']==variant]
  assert all(all(x[f]==rows[0][f] for f in ('score','nodes','action','principal_variation','completed_depth')) for x in rows)
r={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_hashes':{n:hashlib.sha256((p/(n+'.json')).read_bytes()).hexdigest() for n in names},'scope':'Postdeclared descriptive analysis of frozen batches. No new sample/model fit or restored holdout eligibility. Alias split is algebraic, not additional actor or arbitrary behavior-equivalence proof. Cross-game scores condition on common acceptance and are standalone opportunity, not material value.','common_target_role_control':alias,'cross_game_displacement':games,'cache_summary':cache_summary,'cache_decision':'Defer product cache: modest local benefit, preserve action/history/search/defaults; indexed legal query is the only product change.','corrections':'Retain target summary failure, runtime-view trace failure, wrong base/provenance and missing promoted flag batches. Only cross-game-v4 and displacement-v2 have full correct source promotion state. Earlier promoted results/rejections are invalid inputs, not scientific negative evidence.'}
write_record(out,r);print({'games':{n:{k:g[k] for k in ('attempted_roots','accepted_roots','common_strata','common_mass')} for n,g in games.items()},'cache':cache_summary})
