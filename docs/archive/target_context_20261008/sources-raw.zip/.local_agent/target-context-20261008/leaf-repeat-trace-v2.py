import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.identity import search_state_identity
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/target-context-20261008';out=p/'leaf-repeat-trace-v2.json';assert not out.exists()
source=root/'.local_agent/joint-context-20261008/tt-fresh-cohort.json';data=json.loads(source.read_bytes())
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Correction: original leaf-repeat-trace.json retained incomplete after RuntimeSearchState lacks repetition_counts; v2 reads its existing runtime search_key directly, full Core key only for GameState. First3 frozen exposed roots, original/duplicate-quiet, unchanged fullTT/order/depth4/8192nodes/4sec/q0/root-scanoff. Instrument actual leaf evaluator calls, no memoization/product changes. Group by full Core search identity and ply; also Position/ply. Compare repeated scores, not merge actions or histories. Trace overhead included; no speed claim. One bounded batch90seconds, stop per call.','cases':[]}
t=time.perf_counter();write_record(out,r)
try:
 for item in data['cases'][:3]:
  base=ruleset_from_dict(item['definition']);quiet=next(x for x in base.semantic_actions if x.name=='cannon_quiet')
  for label,definition in [('original',base),('duplicate',replace(base,semantic_actions=base.semantic_actions+(replace(quiet,name='cannon_quiet_equivalent_copy'),)))]:
   assert time.perf_counter()-t<90
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   c=compile_ruleset_for_execution(definition);s=GameSession(c);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0);profile=build_ruleset_profile(c,cfg)
   class Traced(SemanticAttackEvaluator):
    def __init__(self,*args,**kwargs):
     super().__init__(*args,**kwargs);self.calls=0;self.full={};self.physical={};self.conflicts=0
    def evaluate(self,state):
     score=super().evaluate(state);self.calls+=1
     for mapping,key in [(self.full,((state._runtime.search_key() if hasattr(state,'_runtime') else search_state_identity(state,c)),state.ply_count)),(self.physical,(state.position,state.ply_count))]:
      if key in mapping and mapping[key][0]!=score:self.conflicts+=1
      prior=mapping.get(key,(score,0));mapping[key]=(score,prior[1]+1)
     return score
   ev=Traced(c,profile,cfg,backend='native');player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
   decision=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,decision)
   row={'seed':item['seed'],'variant':label,'calls':ev.calls,'unique_full_keys':len(ev.full),'unique_positions':len(ev.physical),'repeated_full_calls':ev.calls-len(ev.full),'repeated_position_calls':ev.calls-len(ev.physical),'score_conflicts':ev.conflicts,'decision':record_value(decision)}
   r['cases'].append(row);write_record(out,r);print(item['seed'],label,row['calls'],row['repeated_full_calls'],decision.completed_depth,flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
