import sys,json,hashlib,collections
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import search_state_identity
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.research_record import write_record
p=root/'.local_agent/target-context-20261008';src=root/'.local_agent/joint-context-20261008/tt-fresh-cohort.json';data=json.loads(src.read_bytes());item=data['cases'][0];c=compile_ruleset_for_execution(ruleset_from_dict(item['definition']));session=GameSession(c);runtime=SearchPathRuntime(session.state,c);groups={}
for action in session.legal_actions():
 child=apply_action(session.state,action,c)
 with runtime.pushed(action):
  key=runtime.search_key();runtime_position=runtime.position;runtime_terminal=runtime.terminal_status
 assert child.position==runtime_position and child.terminal_status==runtime_terminal
 groups.setdefault(child.position,[]).append((action,child,search_state_identity(child,c),key))
r={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'scope':'First frozen exposed root by cohort order, actual full Core transitions/runtime push-pop. Group only to inspect identical physical successor positions; never merge public actions. Compare authoritative Core and Runtime search keys, exact history records and terminal; no cost claim or global identity weakening.','seed':item['seed'],'actions':sum(len(v) for v in groups.values()),'physical_successors':len(groups),'duplicate_groups':[]}
for values in groups.values():
 if len(values)<2:continue
 first=values[0]
 r['duplicate_groups'].append({'actions':[str(x[0]) for x in values],'core_keys_equal':all(x[2]==first[2] for x in values),'runtime_keys_equal':all(x[3]==first[3] for x in values),'history_equal':all(x[1].history==first[1].history for x in values),'terminal_equal':all(x[1].terminal_status==first[1].terminal_status for x in values),'runtime_history_context_equal':all(x[3].history_context==first[3].history_context for x in values)})
runtime.assert_balanced();write_record(p/'duplicate-key-audit.json',r);print(json.dumps(r,indent=2))
