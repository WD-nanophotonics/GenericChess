import sys,json,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import SemanticBoardMove
from generic_chess.core.coordinates import Square
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=root/'.local_agent/target-context-20261008';base=build_standard_shogi_ruleset();rows=[]
for original in base.piece_types:
 for promoted in original.promotion_target_ids:
  board=[None]*81;board[0]=Piece(0,'K','K');board[80]=Piece(1,'K','K');board[28]=Piece(0,'R','R');board[31]=Piece(1,original.type_id,promoted,True)
  compiled=compile_ruleset_for_execution(replace(base,initial_position=tuple(tuple(board[y*9:y*9+9]) for y in range(9))));session=GameSession(compiled)
  captures=[a for a in session.legal_actions() if isinstance(a,SemanticBoardMove) and a.from_square==Square(1,3) and a.to_square==Square(4,3)]
  assert captures
  session.submit(captures[0]);hand=dict(session.state.position.hands[0].counts)
  assert hand.get(original.type_id)==1 and hand.get(promoted,0)==0
  rows.append({'base':original.type_id,'current':promoted,'promoted':True,'capture_to_hand':hand})
write_record(p/'promotion-provenance-audit.json',{'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Actual full Core capture of each correctly constructed promoted Shogi target; confirms original base is returned to hand. Not a price/utility proof.','rows':rows})
print(rows)
