import sys,json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=root/'.local_agent/target-context-20261008';dest=root/'docs/archive/target_context_20261008';dest.mkdir(exist_ok=True);package=dest/'sources-raw.zip';assert not package.exists()
# This directory contains only this segment's synthetic science and producers.
# Workflow/Slack/credentials/user-input directories are never included.
files=sorted([f for f in p.iterdir() if f.suffix in ('.py','.json') or f.name=='default-pytest.txt'])
dependencies=['.local_agent/semantic-candidate-20261008/cannon-mixture.py','.local_agent/joint-context-20261008/tt-fresh-cohort.py','.local_agent/semantic-candidate-20261008/cannon-mixture.json','.local_agent/joint-context-20261008/tt-fresh-cohort.json','.local_agent/joint-context-20261008/next-target-type-declaration.json','generic_chess/core/semantic_executor.py','tests/product/test_semantic_binding_filters.py']
files.extend(root/rel for rel in dependencies)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();by_hash={sha(f):f for f in files if f.suffix=='.py'};pins=[]
for f in files:
 if f.suffix!='.json':continue
 data=json.loads(f.read_bytes());pin=data.get('producer_sha256') if isinstance(data,dict) else None
 if pin:
  assert pin in by_hash,(f,pin)
  pins.append({'producer':by_hash[pin].relative_to(root).as_posix(),'output':f.relative_to(root).as_posix(),'verified':True})
members=[]
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  assert f.resolve().is_relative_to(root.resolve());rel=f.relative_to(root).as_posix()
  assert '/slack/' not in rel and f.name not in ('NEXT_WORK.md','session.json','advisor.json','rollout.json','slack.json')
  z.write(f,rel);members.append({'original_path':rel,'bytes':f.stat().st_size,'sha256':sha(f)})
with tempfile.TemporaryDirectory(prefix='target-context-verify-',dir=root/'.local_agent') as td:
 with zipfile.ZipFile(package) as z:
  assert z.testzip() is None
  for item in z.infolist():assert not Path(item.filename).is_absolute() and '..' not in Path(item.filename).parts
  z.extractall(td)
 for m in members:assert sha(Path(td)/m['original_path'])==m['sha256']
corrections={'target-matrix.json':'Original summary KeyError on3 compile-rejected rows; v2 retains same72 declared roots and denominators.','leaf-repeat-trace.json':'Incomplete: full GameState identity requested from RuntimeSearchState; v2 uses its authoritative runtime key. One instrumented duplicate call depth3 cap remains unknown, not a speed comparison.','cross-game-role-pilot through v3':'Wrong base/current or missing promoted flag. Invalid promoted inputs are not scientific negative evidence. v4 fixes base/current/promoted; actual6-type capture-to-hand audit passed.','displacement-role-pilot.json':'Missing promoted=True rejects all promoted Shogi roots and yields no common sample. v2 corrects state on same frozen draws.','turn-context-pilot.json':'Legacy in_check misses semantic pawn attacks, causing rejected anchor capture. v2 uses SemanticEngine.in_check; canonical rules compiled once.','measures':'First common-context and target-role analyses have no embedded producer pin; retained descriptive derivations, reproducible role analysis in analyze-target-context.py. Chess union derivation also retained without original producer pin. No invented pins.','timing':'Original attack-map pilot may briefly overlap first stratified experiment; do not infer robust wall gain. Later rotated evaluation-cache pilot is separate. Counts are explicit outer transitions, excluding compiler/internal legality work.'}
index={'base_sha':'7324c5490db36e5fc0abedcd8d961748423d57f0','package':package.name,'package_sha256':sha(package),'members':members,'extracted_verified_members':len(members),'producer_pins':pins,'producer_pins_verified':len(pins),'scope':'Agent-generated synthetic rules/observations/declarations/producers and3 explicit prior synthetic dependencies, plus exact product/test source snapshot. No raw Slack/accounts/user inputs/workflow state/credentials/binaries. Isolated recovery only; no active archive imports.','corrections':corrections}
write_record(dest/'index.json',index)
read=lambda name:json.loads((p/(name+'.json')).read_bytes())
f=read('final-analysis');t=read('turn-context-analysis');matrix=read('target-matrix-v2');factorial=read('query-factorial');frozen=read('frozen-role-candidate');screens=read('screen-stratified');union=read('chess-union-mechanism')
compact={'archive_index':'../../archive/target_context_20261008/index.json','scope':'Explicit conditional opportunity laws, no material/WDL/Elo or universal equivalence claim. Only source/target legal binding filters added; search/evaluation defaults unchanged.','target_matrix':matrix['summary'],'query_factorial':factorial,'screen_strata':screens['summary'],'frozen_role_candidate':{k:frozen[k] for k in ('declaration','common_seeds','role_score','common_mse','seconds','explicit_transitions')},'initial_safe_analysis':f,'turn_context_analysis':t,'chess_union_mechanism':{k:v for k,v in union.items() if k!='rows'},'corrections':corrections,'validation':'1600 default tests passed before final dedicated S4 rejection regression; final20binding tests passed. Publication relevant tests recorded separately by tested CLI.'}
# The factorial is69rows of compact observations; no private transport content.
write_record(root/'docs/research/data/target_context_20261008.json',compact)
print({'extracted_members':len(members),'producer_pins':len(pins),'package_bytes':package.stat().st_size})
