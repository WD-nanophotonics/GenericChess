from pathlib import Path
import json,importlib.util,sys,time
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path.insert(0,str(R))
spec=importlib.util.spec_from_file_location('qualification._native_core',B/'history_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
import generic_chess.native as n
n._MODULE=m
import pytest
paths=['tests/product/test_native_main_order_pv_witness.py','tests/development/test_native_q0_canonical_replay.py','tests/product/test_native_pv_replay_boundaries.py','tests/product/test_native_search_budgets.py','tests/product/test_native_semantic_qsearch.py','tests/product/test_native_immediate_win_goal.py','tests/product/test_native_pending_continuation.py','tests/product/test_native_cancellation.py']
start=time.perf_counter();code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(B/'pytest-history'),*paths]);(B/'qualification-private.json').write_bytes(json.dumps(dict(exit_code=code,seconds=time.perf_counter()-start,tests=paths,backend=str(m.__file__),scope='Actual existing contract/oracle tests with private rebuilt history image as process-owned Native backend; product source/image unchanged.')).encode());raise SystemExit(code)
