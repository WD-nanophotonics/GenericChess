from pathlib import Path
import json,sys,time,importlib.util,hashlib,traceback
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015'),str(B)]
import allocation as a
_spec=importlib.util.spec_from_file_location('cutoff_summary',B/'summarize.py');_mod=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_mod);summarize=_mod.summarize
plan=json.loads((B/'fresh-plan.json').read_bytes());manifest=json.loads((B/'fresh-input-manifest.json').read_bytes());assert manifest['complete']and manifest['search_queries']==0
old=summarize('transfer','transfer-plan.json','transfer-completion.json');go=old['missing']is not None and old['missing']['complete']and not old['errors']and not old['mismatches']
a.write_record(B/'fresh-go.json',dict(go=go,paid_summary=old,reason=plan['go_condition']))
if not go:print('SKIPPED_GO_NOT_MET');sys.exit(2)
mods={}
for name in ['baseline','history']:
 assert hashlib.sha256((B/(name+'_source/native_module.c')).read_bytes()).hexdigest()==plan['source_hashes'][name]
 spec=importlib.util.spec_from_file_location('fresh'+name+'._native_core',B/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
start=time.perf_counter();count=0;missing=[]
for case in plan['inputs']:
 a.p.rr.stopped();seed=case['seed'];x=json.loads((B/'fresh-inputs'/f'{seed}.json').read_bytes());assert hashlib.sha256((B/'fresh-inputs'/f'{seed}.json').read_bytes()).hexdigest()==next(v['sha256']for v in manifest['inputs']if v['seed']==seed);family=time.perf_counter();rows=[];roots={r['ply']:r for r in x['roots']}
 if x['state']=='GENERATION_OR_INPUT_FAILURE':missing.append(dict(seed=seed,slots=24,reason=x['state']));a.write_record(B/f'fresh-{seed}.json',dict(complete=True,rows=[],reason=x['state']));continue
 raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(x['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};nrs={name:a.nc.compile_native_semantic_rules(c,backend_module=mod)for name,mod in mods.items()}
 for ply in plan['roots']:
  if ply not in roots:missing.append(dict(seed=seed,ply=ply,slots=12,reason='ACTUAL_TERMINAL_TAIL',terminal_tail=x['terminal_tail']));continue
  root=roots[ply];s=a.GameSession(c)
  for stored in root['walk']:s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==stored))
  assert a.record_value(s.state)==root['state']
  for condition in plan['conditions']:
   for order,names in enumerate(plan['orders']):
    for name in names:
     a.p.rr.stopped()
     if time.perf_counter()-start+manifest['seconds']>=plan['whole_cap_seconds']:raise TimeoutError('Original fresh3000s total cooperative cap')
     if time.perf_counter()-family+x['input_seconds']>=plan['per_family_seconds']:raise TimeoutError('Original fresh160s family cap')
     nr=nrs[name];t=time.perf_counter()
     try:
      engine=a.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
      res=engine.search(s,a.SearchLimits(max_depth=condition['depth'],max_nodes=condition['nodes'],max_time_seconds=condition['seconds'],quiescence_max_depth=condition['q'],quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=False)
      caller=time.perf_counter()-t;edges=a.audit(s,nr,res);row=dict(seed=seed,n=case['n'],ply=ply,condition=condition['label'],order=order,arm=name,seconds=caller,result=a.record_value(res),pv_edges=edges)
     except Exception as e:row=dict(seed=seed,n=case['n'],ply=ply,condition=condition['label'],order=order,arm=name,seconds=time.perf_counter()-t,error=repr(e),traceback=traceback.format_exc())
     rows.append(row);count+=1;a.write_record(B/f'fresh-{seed}-partial.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start))
  print(seed,ply,len(rows),'elapsed',round(time.perf_counter()-start,3),flush=True)
 a.write_record(B/f'fresh-{seed}.json',dict(complete=True,rows=rows,family_seconds=time.perf_counter()-family,input_seconds=x['input_seconds'],seconds=time.perf_counter()-start))
a.write_record(B/'fresh-completion.json',dict(complete=True,queries=count,missing=missing,seconds=time.perf_counter()-start,input_seconds=manifest['seconds']));print('DONE',count,len(missing),time.perf_counter()-start,flush=True)
