from pathlib import Path
import json,hashlib,shutil,subprocess,sysconfig,time,sys
R=Path.cwd(); B=R/'.local_agent/cutoff-repetition-20261016'; S=B/'counter_source';S.mkdir(exist_ok=True)
plan=json.loads((R/'docs/research/data/cutoff_repetition_plan_20261015.json').read_bytes())
base=R/'generic_chess/_native/native_module.c';assert hashlib.sha256(base.read_bytes()).hexdigest()==plan['native_module_sha256']
for p in (R/'generic_chess/_native').iterdir():
 if p.suffix in ('.c','.h'):shutil.copyfile(p,S/p.name)
p=S/'native_module.c';s=p.read_text(encoding='utf-8-sig')
a='    uint64_t beta_cutoffs;';assert s.count(a)==1
s=s.replace(a,a+'''
    uint64_t probe_cutoffs, probe_repeats, probe_replacements;
    uint64_t probe_actions[4096];
    unsigned char probe_actors[4096], probe_occupied[4096];''')
a='''        if (alpha >= beta) {
            ctx->beta_cutoffs++;
            break;
        }''';assert s.count(a)==1
s=s.replace(a,'''        if (alpha >= beta) {
            ctx->beta_cutoffs++;
            if (!pv_replay) {
                unsigned actor = position->side_to_move;
                uint64_t key = action ^ ((uint64_t)actor << 63);
                key ^= key >> 33; key *= UINT64_C(0xff51afd7ed558ccd);
                key ^= key >> 33;
                unsigned slot = (unsigned)key & 4095;
                ctx->probe_cutoffs++;
                if (ctx->probe_occupied[slot]) {
                    if (ctx->probe_actions[slot] == action && ctx->probe_actors[slot] == actor)
                        ctx->probe_repeats++;
                    else ctx->probe_replacements++;
                }
                ctx->probe_actions[slot] = action;
                ctx->probe_actors[slot] = (unsigned char)actor;
                ctx->probe_occupied[slot] = 1;
            }
            break;
        }''')
a='    PyObject *training_trace = ctx.trace_enabled';assert s.count(a)==1
s=s.replace(a,'''    if (gc_semantic_set_u64(out, "probe_cutoffs", ctx.probe_cutoffs) != 0 ||
        gc_semantic_set_u64(out, "probe_repeats", ctx.probe_repeats) != 0 ||
        gc_semantic_set_u64(out, "probe_replacements", ctx.probe_replacements) != 0) {
        Py_DECREF(out); Py_DECREF(best_action_obj); Py_DECREF(pv);
        free(ctx.stack); free(ctx.pv_table); free(ctx.pv_length); free(ctx.trace_rows);
        if (ctx.tt != borrowed_tt) gc_semantic_tt_free(ctx.tt);
        gc_semantic_profile_free(&profile); gc_semantic_profile_free(&ordering_profile);
        return NULL;
    }
'''+a)
p.write_bytes(s.encode())
start=time.perf_counter()
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in S.glob('*.c')],'-o',str(B/'counter_native_core.pyd')]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
(B/'build-private.json').write_bytes(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-start,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2).encode())
print('BUILD',r.returncode,time.perf_counter()-start,r.stderr[-1000:]);sys.exit(r.returncode)
