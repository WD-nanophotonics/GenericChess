from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=Path(sys.argv[1])if len(sys.argv)>1 else R/'.local_agent/cutoff-repetition-20261016'
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.ir import CompiledSemanticRuleset
class SearchMetadataAdapter(CompiledSemanticRuleset):
 __slots__=()
 def __getattr__(self,name):return getattr(self._legacy_compiled,name)
 @property
 def semantic(self):return self
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.native import SemanticSearchEngine,compiler as nc,semantic as sem
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action,expected_snapshot
assert Path(nc.__file__).resolve().is_relative_to(R.resolve()) and Path(compile_legacy_ruleset_for_semantic_execution.__code__.co_filename).resolve().is_relative_to(R.resolve())
SemanticSearchEngine.search=lambda*a,**kw:(_ for _ in()).throw(AssertionError('search disabled'))
def action(d):
 if not d:return PassAction()
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def state_hash(s):return hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest()
start=time.perf_counter();plan=json.loads((B/'decision-plan.json').read_bytes());rows=[];edges=0
for ci,case in enumerate(plan['cases']):
 inp=json.loads((B/'fresh-inputs'/f"{case['seed']}.json").read_bytes());root=next(r for r in inp['roots']if r['ply']==case['ply']);raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(inp['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=nc.compile_native_semantic_rules(c)
 for mode in plan['modes']:
  d=json.loads((B/f'decision-{ci}-{mode}.json').read_bytes());assert d['complete'];s=GameSession(c)
  for stored in root['walk']:s.submit(action(stored))
  assert record_value(s.state)==root['state'];pos=pack_semantic_search_position(c,nr,s);count=0
  for r in d['rows']:
   assert state_hash(s)==r['before_sha256'];assert r['result']['nodes']+r['result']['qnodes']<=1000000
   if 'action'not in r:assert not r['execution_allowed'];continue
   act=action(r['action']);assert record_value(act)==r['result']['action'];assert r['execution_allowed'];old=s.state;pos=sem.make_checked(nr,pos,pack_semantic_action(nr,old.position,act));s.submit(act);snap=sem.snapshot(nr,pos);exp=expected_snapshot(s.state.position,nr,c)
   for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(exp[k])
   assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(p,c))for p in s._search_witnesses];assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in s.state.history);assert sem.terminal_status(nr,pos)==dict(status=s.state.terminal_status.status.value,winner=s.state.terminal_status.winner);assert state_hash(s)==r['after_sha256'];assert record_value(s.state.terminal_status)==r['actual_terminal'];edges+=1;count+=1
  assert record_value(s.state)==d['state']and record_value(s.result)==d['result'];rows.append(dict(case_index=ci,mode=mode,edges=count,kind=d['kind'],result=record_value(s.result)));print('REPLAY',ci,mode,count,flush=True)
out=dict(complete=True,games=len(rows),physical_edges=edges,seconds=time.perf_counter()-start,rows=rows,search_disabled=True,scope='Separate normal-Core/Native consumer reconstructs every physical action, fullidentity/eventhistory, finalstate/result and main+q caps; no timing/game/solver rerun or independent rules implementation.');(B/'decision-replay.json').write_bytes(json.dumps(out,indent=2).encode());print('PASS',len(rows),edges,time.perf_counter()-start,flush=True)
