from pathlib import Path
import sys,json,time,hashlib,importlib.util
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')]
import allocation as a
plan=json.loads((B/'history-plan.json').read_bytes())
mods={}
for name in ['baseline','history']:
 spec=importlib.util.spec_from_file_location(name+'._native_core',B/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
raws={}
for name,mod in mods.items():
 orig=mod.semantic_engine_search
 def wrap(*args,_orig=orig,_name=name,**kwargs):
  x=_orig(*args,**kwargs);raws[_name]=x;return x
 mod.semantic_engine_search=wrap
start=time.perf_counter();rows=[];errors=[]
for seed in plan['seeds']:
 x=json.loads((a.O/f'q-policy-{seed}.json').read_bytes());root=next(r for r in x['roots']if r['ply']==0)
 ss={name:a.load(dict(seed=seed,root=root),mod)for name,mod in mods.items()}
 for order,names in enumerate(plan['orders']):
  for name in names:
   a.p.rr.stopped()
   if time.perf_counter()-start>295:raise TimeoutError('Frozen whole batch180s including compile allowance')
   s,nr,bv,hv=ss[name];t=time.perf_counter();engine=a.SemanticSearchEngine(s.compiled,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
   res=engine.search(s,a.SearchLimits(max_depth=3,max_nodes=65536,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=False)
   sec=time.perf_counter()-t;edges=a.audit(s,nr,res);raw=raws[name]
   rows.append(dict(seed=seed,order=order,arm=name,seconds=sec,result=a.record_value(res),raw=a.record_value(raw),pv_edges=edges))
   (B/'history-results.json').write_bytes(json.dumps(dict(complete=False,rows=rows,seconds=time.perf_counter()-start),indent=2).encode())
   print(seed,order,name,res.completed_depth,res.nodes,res.qnodes,raw.get('probe_cutoffs'),raw.get('probe_repeats'),round(sec,5),flush=True)
for seed in plan['seeds']:
 for order in range(2):
  pair=[r for r in rows if r['seed']==seed and r['order']==order];left,right=pair
  # Timing is measured separately; all result fields except elapsed clocks must match.
  fields=['score','action','principal_variation','completed_depth','result_ordinary_qdepth','result_check_hard_qdepth']
  x=[{k:r['result'][k] for k in fields}for r in pair] if all(r['result']['completed_depth']==3 for r in pair) else [{},{}]
  if x[0]!=x[1]:errors.append(dict(seed=seed,order=order,fields=[k for k in x[0]if x[0][k]!=x[1][k]]))
(B/'history-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,non_time_mismatches=errors),indent=2).encode());print('DONE',len(rows),errors,time.perf_counter()-start)
