from pathlib import Path
import json,math,statistics,random,sys
B=Path('.local_agent/cutoff-repetition-20261016');prefix=sys.argv[1];x=json.loads((B/(prefix+'-summary.json')).read_bytes());rng=random.Random(20261016)
def interval(ps,metric):
 seeds=sorted({p['seed']for p in ps});means={s:statistics.mean(math.log(p[metric])for p in ps if p['seed']==s)for s in seeds};n=len(seeds);boots=sorted(math.exp(statistics.mean(means[rng.choice(seeds)]for _ in range(n)))for _ in range(5000))if n else[]
 return dict(families=n,pairs=len(ps),family_weighted_geomean=math.exp(statistics.mean(means.values()))if n else None,paired_family_bootstrap_95=[boots[125],boots[4874]]if n else None,seed=20261016,draws=5000,scope='Descriptive family interval conditional on jointly completed finite cells, not guarantee or all-domain validation.')
for label in ['fixed_q0','fixed_q4']:
 ps=[p for p in x['conditions'][label]['pairs']if p['both_complete']];x['conditions'][label]['completed_family_intervals']={metric:interval(ps,metric)for metric in ['caller_ratio','work_ratio']}
from collections import Counter
rs=[];plan=json.loads((B/(prefix+'-plan.json')).read_bytes());seeds=plan.get('seeds')or[c['seed']for c in plan['inputs']]
for seed in seeds:rs+=json.loads((B/f'{prefix}-{seed}.json').read_bytes())['rows']
x['termination_histograms']={label:{arm:dict(Counter(r['result']['termination_reason']for r in rs if r['condition']==label and r['arm']==arm and 'result'in r))for arm in['baseline','history']}for label in ['fixed_q0','fixed_q4','wall_q4']}
(B/(prefix+'-summary.json')).write_bytes(json.dumps(x,indent=2).encode());print(json.dumps({label:x['conditions'][label]['completed_family_intervals']for label in['fixed_q0','fixed_q4']},indent=2))
