from pathlib import Path
import json,math,statistics,random
B=Path('.local_agent/cutoff-repetition-20261016')
def summarize(prefix,planfile,completion):
 plan=json.loads((B/planfile).read_bytes());rows=[]
 seeds=plan.get('seeds')or[x['seed']for x in plan['inputs']]
 for seed in seeds:
  p=B/f'{prefix}-{seed}.json'
  if p.exists():rows+=json.loads(p.read_bytes())['rows']
 errors=[r for r in rows if 'error'in r];result=dict(queries=len(rows),errors=errors,missing=json.loads((B/completion).read_bytes())if(B/completion).exists()else None,conditions={},mismatches=[],pv_edges=sum(r.get('pv_edges',0)for r in rows))
 for cond in plan['conditions']:
  label=cond['label'];rs=[r for r in rows if r['condition']==label];pairs=[]
  for key in sorted({(r['seed'],r['ply'],r['order'])for r in rs}):
   p={r['arm']:r for r in rs if (r['seed'],r['ply'],r['order'])==key}
   if len(p)!=2 or any('error'in r for r in p.values()):continue
   a,b=p['baseline'],p['history'];ar,br=a['result'],b['result'];fields=['score','action','declaration_id','principal_variation','decision_line','completed_depth','result_ordinary_qdepth','result_check_hard_qdepth'];both=all(r['completed_depth']==cond['depth']for r in[ar,br])
   mismatch=[f for f in fields if ar[f]!=br[f]]if both else[]
   if mismatch:result['mismatches'].append(dict(seed=key[0],ply=key[1],order=key[2],condition=label,fields=mismatch))
   def requested(r):return r['result_source']=='main_iteration'and r['completed_depth']>=2 and(r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==(4,8)
   work=[r['nodes']+r['qnodes']for r in [ar,br]];assert all(w<=cond['nodes']for w in work)
   pairs.append(dict(seed=key[0],ply=key[1],order=key[2],both_complete=both,finite_equal=both and not mismatch,baseline_depth=ar['completed_depth'],history_depth=br['completed_depth'],same_action=ar['action']==br['action']and ar['declaration_id']==br['declaration_id'],requested_gain=not requested(ar)and requested(br),requested_loss=requested(ar)and not requested(br),work_ratio=work[1]/max(1,work[0]),caller_ratio=b['seconds']/a['seconds'],baseline_seconds=a['seconds'],history_seconds=b['seconds'],baseline_work=work[0],history_work=work[1]))
  def stats(ps):
   if not ps:return dict(pairs=0)
   return dict(pairs=len(ps),both_complete=sum(p['both_complete']for p in ps),finite_equal=sum(p['finite_equal']for p in ps),same_action=sum(p['same_action']for p in ps),deeper=sum(p['history_depth']>p['baseline_depth']for p in ps),same_depth=sum(p['history_depth']==p['baseline_depth']for p in ps),shallower=sum(p['history_depth']<p['baseline_depth']for p in ps),requested_gain=sum(p['requested_gain']for p in ps),requested_loss=sum(p['requested_loss']for p in ps),caller_geomean=math.exp(statistics.mean(math.log(p['caller_ratio'])for p in ps)),work_geomean=math.exp(statistics.mean(math.log(p['work_ratio'])for p in ps)),caller_worse=sum(p['caller_ratio']>1 for p in ps),max_caller_ratio=max(p['caller_ratio']for p in ps),max_work_ratio=max(p['work_ratio']for p in ps))
  result['conditions'][label]=dict(all=stats(pairs),completed=stats([p for p in pairs if p['both_complete']]),pairs=pairs,strata={str(n):stats([p for p in pairs if next((c.get('n')for c in plan.get('inputs',[])if c['seed']==p['seed']),{430:4,431:8,432:12,433:16}.get(p['seed']//10))==n])for n in [4,8,12,16]})
 return result
if __name__=='__main__':
 import sys
 prefix=sys.argv[1]if len(sys.argv)>1 else'transfer';x=summarize(prefix,prefix+'-plan.json',prefix+'-completion.json');(B/(prefix+'-summary.json')).write_bytes(json.dumps(x,indent=2).encode());print(json.dumps({k:v for k,v in x.items()if k!='conditions'}));print(json.dumps({k:{j:z for j,z in v.items()if j!='pairs'}for k,v in x['conditions'].items()}))
