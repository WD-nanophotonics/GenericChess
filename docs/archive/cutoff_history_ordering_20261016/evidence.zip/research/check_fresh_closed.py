from pathlib import Path
import json
B=Path('.local_agent/cutoff-repetition-20261016');rows=[]
for case in json.loads((B/'fresh-plan.json').read_bytes())['inputs']:
 p=B/f"fresh-{case['seed']}.json"
 if p.exists():rows+=json.loads(p.read_bytes())['rows']
errors=[r for r in rows if 'error'in r];print('Fresh closed',len(rows),'errors',len(errors))
for condition in ['fixed_q0','fixed_q4','wall_q4']:
 rs=[r for r in rows if r['condition']==condition];d=4 if condition=='fixed_q0'else 3 if condition=='fixed_q4'else 16;bad=[];complete=0
 for key in sorted({(r['seed'],r['ply'],r['order'])for r in rs}):
  p={r['arm']:r for r in rs if(r['seed'],r['ply'],r['order'])==key};a,b=p['baseline']['result'],p['history']['result']
  if a['completed_depth']==b['completed_depth']==d:
   complete+=1;fields=['score','action','declaration_id','principal_variation','decision_line','result_ordinary_qdepth','result_check_hard_qdepth'];m=[f for f in fields if a[f]!=b[f]]
   if m:bad.append((key,m))
 print(condition,'pairs',len(rs)//2,'bothfinite',complete,'bad',bad)
