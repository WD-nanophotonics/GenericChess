from pathlib import Path
import sys,json,time,importlib.util,traceback
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')];import allocation as a
plan=json.loads((B/'readiness-plan.json').read_bytes());baseplan=json.loads((B/'transfer-plan.json').read_bytes());mods={}
for name in ['baseline','history','guarded']:
 spec=importlib.util.spec_from_file_location('ready'+name+'._native_core',B/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
start=time.perf_counter();rows=[];errors=[];mismatches=[]
for scope in ['active','inactive']:
 seeds=baseplan['seeds']if scope=='active'else[4302,4303,4312,4313,4322,4323,4332,4333];arms=['history','guarded']if scope=='active'else['baseline','guarded'];conditions=baseplan['conditions']if scope=='active'else[dict(label='inactive_q0',depth=1,nodes=100000,seconds=2,q=0),dict(label='inactive_q4',depth=1,nodes=100000,seconds=2,q=4)]
 for seed in seeds:
  data=json.loads((B/'paid-inputs'/f'{seed}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(data['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};nrs={name:a.nc.compile_native_semantic_rules(c,backend_module=mods[name])for name in arms}
  for root in data['roots']:
   if scope=='inactive'and root['ply']!=0:continue
   s=a.GameSession(c)
   for d in root['walk']:s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==d))
   assert a.record_value(s.state)==root['state']
   for cond in conditions:
    order=arms if seed%2 else list(reversed(arms));pair=[]
    for arm in order:
     a.p.rr.stopped()
     if time.perf_counter()-start>=600:raise TimeoutError('Original600s readiness cap')
     t=time.perf_counter()
     try:
      e=a.SemanticSearchEngine(c,nrs[arm],board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);res=e.search(s,a.SearchLimits(max_depth=cond['depth'],max_nodes=cond['nodes'],max_time_seconds=cond['seconds'],quiescence_max_depth=cond['q'],quiescence_hard_max_depth=8),root_window_pruning=scope=='active',stop_on_immediate_win=False);seconds=time.perf_counter()-t;edges=a.audit(s,nrs[arm],res);r=dict(scope=scope,seed=seed,ply=root['ply'],condition=cond['label'],arm=arm,seconds=seconds,result=a.record_value(res),pv_edges=edges);assert res.nodes+res.qnodes<=cond['nodes']
     except Exception as ex:r=dict(scope=scope,seed=seed,ply=root['ply'],condition=cond['label'],arm=arm,error=repr(ex),traceback=traceback.format_exc());errors.append(r)
     rows.append(r);pair.append(r)
    if all('result'in r for r in pair)and all(r['result']['termination_reason']!='time_budget'for r in pair):
     clean=[{k:v for k,v in r['result'].items()if 'elapsed'not in k and 'seconds'not in k}for r in pair];diff=[k for k in clean[0]if clean[0][k]!=clean[1][k]]
     if diff:mismatches.append(dict(scope=scope,seed=seed,ply=root['ply'],condition=cond['label'],fields=diff))
   print(scope,seed,root['ply'],len(rows),round(time.perf_counter()-start,3),flush=True)
  a.write_record(B/'readiness-results-partial.json',dict(complete=False,rows=rows,errors=errors,mismatches=mismatches,seconds=time.perf_counter()-start))
a.write_record(B/'readiness-results.json',dict(complete=True,rows=rows,errors=errors,mismatches=mismatches,seconds=time.perf_counter()-start));print('READY_DONE',len(rows),len(errors),mismatches,time.perf_counter()-start,flush=True)
