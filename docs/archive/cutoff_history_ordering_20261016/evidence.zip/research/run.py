from pathlib import Path
import sys,json,time,hashlib,importlib.util
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')]
import allocation as a
plan=json.loads((R/'docs/research/data/cutoff_repetition_plan_20261015.json').read_bytes())
spec=importlib.util.spec_from_file_location('counter._native_core',B/'counter_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mods={'baseline':a.backend(),'counter':m};raws={}
for name,mod in mods.items():
 orig=mod.semantic_engine_search
 def wrap(*args,_orig=orig,_name=name,**kwargs):
  x=_orig(*args,**kwargs);raws[_name]=x;return x
 mod.semantic_engine_search=wrap
start=time.perf_counter();rows=[];errors=[]
for seed in plan['seeds']:
 x=json.loads((a.O/f'q-policy-{seed}.json').read_bytes());root=next(r for r in x['roots']if r['ply']==0)
 ss={name:a.load(dict(seed=seed,root=root),mod)for name,mod in mods.items()}
 for order,names in enumerate(plan['orders']):
  for name in names:
   a.p.rr.stopped()
   if time.perf_counter()-start>175:raise TimeoutError('Frozen whole batch180s including compile allowance')
   s,nr,bv,hv=ss[name];t=time.perf_counter();engine=a.SemanticSearchEngine(s.compiled,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
   res=engine.search(s,a.SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=False)
   sec=time.perf_counter()-t;edges=a.audit(s,nr,res);raw=raws[name]
   rows.append(dict(seed=seed,order=order,arm=name,seconds=sec,result=a.record_value(res),raw=a.record_value(raw),pv_edges=edges))
   (B/'results.json').write_bytes(json.dumps(dict(complete=False,rows=rows,seconds=time.perf_counter()-start),indent=2).encode())
   print(seed,order,name,res.completed_depth,res.nodes,res.qnodes,raw.get('probe_cutoffs'),raw.get('probe_repeats'),round(sec,5),flush=True)
for seed in plan['seeds']:
 for order in range(2):
  pair=[r for r in rows if r['seed']==seed and r['order']==order];left,right=pair
  # Timing is measured separately; all result fields except elapsed clocks must match.
  x=[{k:v for k,v in r['result'].items()if 'elapsed' not in k}for r in pair]
  if x[0]!=x[1]:errors.append(dict(seed=seed,order=order,fields=[k for k in x[0]if x[0][k]!=x[1][k]]))
(B/'results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,non_time_mismatches=errors),indent=2).encode());print('DONE',len(rows),errors,time.perf_counter()-start)
