from pathlib import Path
import json,hashlib,shutil,subprocess,sysconfig,time,sys
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';S=B/'guarded_source';S.mkdir(exist_ok=True)
for p in (B/'history_source').glob('*'):
 if p.suffix in('.c','.h'):shutil.copyfile(p,S/p.name)
p=S/'native_module.c';s=p.read_text(encoding='utf-8-sig');marker='''typedef struct {
    const GCSemanticRules *rules;
    GCSemanticProbeProfile profile;
    GCSemanticPosition *stack;''';assert s.count(marker)==1
s=s.replace(marker,'''/* Per-call ordering evidence, never a score, legality or terminal cache.
 * Full packed actions distinguish semantic patterns, drops and promotions. */
typedef struct {
    uint64_t actions[4096];
    unsigned char actors[4096], occupied[4096];
    uint16_t scores[4096];
} GCSemanticHistoryTable;

'''+marker)
a='''    uint64_t history_actions[4096];
    unsigned char history_actors[4096], history_occupied[4096];
    uint16_t history_scores[4096];''';assert s.count(a)==1;s=s.replace(a,'    GCSemanticHistoryTable *history;')
for field in ['actions','actors','occupied','scores']:s=s.replace('ctx->history_'+field,'ctx->history->'+field)
s=s.replace('gc_private_history_','gc_semantic_history_')
a='''static unsigned gc_semantic_history_score(GCSemanticIterativeContext *ctx,uint64_t action,unsigned actor) {
 unsigned slot=''';assert s.count(a)==1;s=s.replace(a,'''static unsigned gc_semantic_history_score(GCSemanticIterativeContext *ctx,uint64_t action,unsigned actor) {
 if (ctx->history == NULL) return 0;
 unsigned slot=''' )
a='''            ctx->beta_cutoffs++;
            if (!pv_replay) {''';assert s.count(a)==1;s=s.replace(a,'''            ctx->beta_cutoffs++;
            if (ctx->history != NULL && !pv_replay) {''')
a='''    GCSemanticIterativeContext ctx;
    memset(&ctx, 0, sizeof(ctx));''';assert s.count(a)==1;s=s.replace(a,'''    GCSemanticHistoryTable history;
    GCSemanticIterativeContext ctx;
    memset(&ctx, 0, sizeof(ctx));
    if (root_window_pruning_obj == Py_True &&
        !learned_move_ordering && !policy_move_ordering) {
        memset(&history, 0, sizeof(history));
        ctx.history = &history;
    }''')
p.write_bytes(s.encode());start=time.perf_counter();cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in S.glob('*.c')],'-o',str(B/'guarded_native_core.pyd')];r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(B/'readiness-build-private.json').write_bytes(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-start,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),image_sha256=hashlib.sha256((B/'guarded_native_core.pyd').read_bytes()).hexdigest()if r.returncode==0 else None),indent=2).encode());print('GUARDED_BUILD',r.returncode,time.perf_counter()-start,r.stderr[-1000:]);sys.exit(r.returncode)
