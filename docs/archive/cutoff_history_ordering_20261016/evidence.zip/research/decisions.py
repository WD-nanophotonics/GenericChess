from pathlib import Path
import sys,json,time,importlib.util,hashlib
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')];import allocation as a
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
plan=json.loads((B/'decision-plan.json').read_bytes());mods={}
for name in ['baseline','history']:
 spec=importlib.util.spec_from_file_location('decision'+name+'._native_core',B/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
fresh=json.loads((B/'fresh-completion.json').read_bytes());assert fresh['complete']
summary=json.loads((B/'fresh-summary.json').read_bytes());assert not summary['errors']and not summary['mismatches']
start=time.perf_counter();games=[]
def state_hash(s):return hashlib.sha256(json.dumps(a.record_value(s.state),sort_keys=True).encode()).hexdigest()
for case_index,case in enumerate(plan['cases']):
 data=json.loads((B/'fresh-inputs'/f"{case['seed']}.json").read_bytes());root=next((r for r in data['roots']if r['ply']==case['ply']),None)
 if root is None:
  games.append(dict(**case,mode='ALL',kind='MISSING_FROZEN_ROOT'));continue
 raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(data['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};nrs={name:a.nc.compile_native_semantic_rules(c,backend_module=m)for name,m in mods.items()}
 for mode in plan['modes']:
  a.p.rr.stopped();s=a.GameSession(c)
  for stored in root['walk']:s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==stored))
  assert a.record_value(s.state)==root['state'];positions={name:pack_semantic_search_position(c,nr,s)for name,nr in nrs.items()};token=a.CancellationToken();rows=[];game_start=time.perf_counter();kind=None
  for ply in range(plan['max_additional_plies']):
   a.p.rr.stopped()
   if s.result.status.value!='ongoing':kind='ACTUAL_RULE_TERMINAL';break
   if time.perf_counter()-start>=plan['whole_seconds']:kind='ORIGINAL_WHOLE_CAP_UNKNOWN';break
   if time.perf_counter()-game_start>=plan['per_game_seconds']:kind='ORIGINAL_GAME_CAP_UNKNOWN';break
   actor=s.state.position.side_to_move;owner='history'if mode==f'history_role{actor}'else'baseline';t=time.perf_counter();nr=nrs[owner];engine=a.SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);remaining=plan['per_move_caller_seconds']-plan['delivery_margin_seconds']-(time.perf_counter()-t)
   if remaining<=0:kind='CALLER_PREPARATION_EXPIRY_UNKNOWN';break
   before=state_hash(s);r=engine.search(s,a.SearchLimits(max_depth=16,max_nodes=1000000,max_time_seconds=remaining,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True,stop_on_immediate_win=True);result=a.record_value(r);elapsed=time.perf_counter()-t;allowed=r.action is not None and not token.is_cancelled()and elapsed<plan['per_move_caller_seconds'];row=dict(ply=ply,actor=actor,owner=owner,result=result,search_caller_seconds=elapsed,execution_allowed=allowed,before_sha256=before)
   if not allowed:rows.append(row);kind='CALLER_NO_ELIGIBLE_ACTION_UNKNOWN';break
   a.p.rr.stopped();physical=time.perf_counter();old=s.state
   for name,nr in nrs.items():positions[name]=a.sem.make_checked(nr,positions[name],pack_semantic_action(nr,old.position,r.action))
   s.submit(r.action)
   for name,nr in nrs.items():
    snap=a.sem.snapshot(nr,positions[name]);exp=expected_snapshot(s.state.position,nr,c)
    for key in ['board','hands','aux_state','side']:assert a.record_value(snap[key])==a.record_value(exp[key])
    assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(p,c))for p in s._search_witnesses];assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in s.state.history);assert a.sem.terminal_status(nr,positions[name])==dict(status=s.state.terminal_status.status.value,winner=s.state.terminal_status.winner)
   row.update(action=a.record_value(r.action),after_sha256=state_hash(s),actual_terminal=a.record_value(s.state.terminal_status),physical_transition_and_audit_seconds=time.perf_counter()-physical);rows.append(row)
   a.write_record(B/f'decision-{case_index}-{mode}-partial.json',dict(complete=False,case=case,mode=mode,rows=rows,seconds=time.perf_counter()-game_start));print(case_index,mode,ply,owner,r.completed_depth,r.result_ordinary_qdepth,s.result.status.value,flush=True)
  kind=kind or('ACTUAL_RULE_TERMINAL'if s.result.status.value!='ongoing'else'ORIGINAL_PLY_CAP_UNKNOWN');out=dict(complete=True,case=case,case_index=case_index,mode=mode,rows=rows,kind=kind,state=a.record_value(s.state),result=a.record_value(s.result),seconds=time.perf_counter()-game_start,search_budget_scope='Constructor/search/returned-result conversion and precommit eligibility. Physical checked/Core transition/audit and scientific file saves separate; no hard final return guarantee.');a.write_record(B/f'decision-{case_index}-{mode}.json',out);games.append(dict(case_index=case_index,mode=mode,kind=kind,edges=sum('action'in r for r in rows),result=out['result'],seconds=out['seconds']));print('GAME_DONE',games[-1],flush=True)
a.write_record(B/'decision-completion.json',dict(complete=True,games=games,seconds=time.perf_counter()-start));print('ALL_GAMES_CLOSED',len(games),time.perf_counter()-start,flush=True)
