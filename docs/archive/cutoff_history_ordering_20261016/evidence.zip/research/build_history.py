from pathlib import Path
import json,hashlib,shutil,subprocess,sysconfig,time,sys
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';rows=[]
for arm in ['baseline','history']:
 S=B/(arm+'_source');S.mkdir(exist_ok=True)
 for p in (R/'generic_chess/_native').iterdir():
  if p.suffix in ('.c','.h'):shutil.copyfile(p,S/p.name)
 p=S/'native_module.c';s=p.read_text(encoding='utf-8-sig')
 if arm=='history':
  a='    uint64_t beta_cutoffs;';assert s.count(a)==1
  s=s.replace(a,a+'''
    uint64_t history_actions[4096];
    unsigned char history_actors[4096], history_occupied[4096];
    uint16_t history_scores[4096];''')
  marker='/* A discarded quiet view may omit only the identity/history append. Any';assert s.count(marker)==1
  helper='''static unsigned gc_private_history_slot(uint64_t action, unsigned actor) {
 uint64_t key=action ^ ((uint64_t)actor << 63);
 key^=key>>33;key*=UINT64_C(0xff51afd7ed558ccd);key^=key>>33;
 return (unsigned)key & 4095;
}
static unsigned gc_private_history_score(GCSemanticIterativeContext *ctx,uint64_t action,unsigned actor) {
 unsigned slot=gc_private_history_slot(action,actor);
 return ctx->history_occupied[slot] && ctx->history_actions[slot]==action &&
   ctx->history_actors[slot]==actor ? ctx->history_scores[slot] : 0;
}
static int gc_private_history_order(GCSemanticIterativeContext *ctx,
 GCSemanticPosition *pos,GCSemanticActionBuffer *actions) {
 if(actions->count<2)return 1;
 GCSemanticOrderedAction *ordered=calloc(actions->count,sizeof(*ordered));
 if(!ordered){ctx->control=4;return 0;}
 unsigned cells=ctx->rules->board_size*ctx->rules->board_size;
 for(size_t i=0;i<actions->count;i++) {
  if(!gc_semantic_iterative_check_budget(ctx,1)){free(ordered);return 0;}
  uint64_t action=actions->data[i];unsigned target=GC_ACTION_TO(action);
  int capture=GC_ACTION_KIND(action)==GC_ACTION_KIND_SEMANTIC_BOARD && target<cells &&
    pos->board[target].occupied && pos->board[target].owner!=pos->side_to_move;
  ordered[i].action=action;
  ordered[i].mover_score=(capture?65536.0:0.0)+gc_private_history_score(ctx,action,pos->side_to_move);
 }
 qsort(ordered,actions->count,sizeof(*ordered),gc_semantic_q_candidate_compare);
 for(size_t i=0;i<actions->count;i++)actions->data[i]=ordered[i].action;
 free(ordered);return 1;
}
'''
  s=s.replace(marker,helper+marker)
  # Replace main-only binary sorter; q continues using its original function.
  a='''        ctx->main_binary_order_calls++;
        if (!gc_semantic_order_q_candidates(ctx, position, &actions))''';assert s.count(a)==1
  s=s.replace(a,'''        ctx->main_binary_order_calls++;
        if (!gc_private_history_order(ctx, position, &actions))''')
  a='''        if (alpha >= beta) {
            ctx->beta_cutoffs++;
            break;
        }''';assert s.count(a)==1
  s=s.replace(a,'''        if (alpha >= beta) {
            ctx->beta_cutoffs++;
            if (!pv_replay) {
                unsigned actor=position->side_to_move,slot=gc_private_history_slot(action,actor);
                unsigned old=gc_private_history_score(ctx,action,actor);
                unsigned bonus=(unsigned)depth*(unsigned)depth;
                unsigned score=old+bonus;
                ctx->history_actions[slot]=action;ctx->history_actors[slot]=(unsigned char)actor;
                ctx->history_occupied[slot]=1;ctx->history_scores[slot]=(uint16_t)(score>65535?65535:score);
            }
            break;
        }''')
 p.write_bytes(s.encode());start=time.perf_counter()
 cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in S.glob('*.c')],'-o',str(B/(arm+'_native_core.pyd'))]
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);rows.append(dict(arm=arm,command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-start,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()));print(arm,r.returncode,time.perf_counter()-start,r.stderr[-500:]);assert r.returncode==0
(B/'history-build-private.json').write_bytes(json.dumps(rows,indent=2).encode())
