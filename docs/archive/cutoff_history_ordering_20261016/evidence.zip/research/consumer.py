"""Search-disabled consumer of saved ordering studies using normal Core/Native."""
from pathlib import Path
import sys,json,time
R=Path.cwd();sys.path.insert(0,str(R));B=Path(sys.argv[1]) if len(sys.argv)>1 else R/'.local_agent/cutoff-repetition-20261016'
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.ir import CompiledSemanticRuleset
class SearchMetadataAdapter(CompiledSemanticRuleset):
 __slots__=()
 def __getattr__(self,name):return getattr(self._legacy_compiled,name)
 @property
 def semantic(self):return self
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
assert Path(nc.__file__).resolve().is_relative_to(R.resolve()) and Path(compile_legacy_ruleset_for_semantic_execution.__code__.co_filename).resolve().is_relative_to(R.resolve())
SemanticSearchEngine.search=lambda *a,**kw:(_ for _ in()).throw(AssertionError('search disabled in consumer'))
def action(d):
 if d is None:return None
 if not d:return PassAction()
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
start=time.perf_counter();datasets=[]
for name,filename,cap in [('counter','results.json',4096),('pilot','history-results.json',65536),('tt','tt-results.json',262144)]:
 d=json.loads((B/filename).read_bytes());assert d['complete']
 for seed in sorted({r['seed']for r in d['rows']}):datasets.append((name,json.loads((B/'paid-inputs'/f'{seed}.json').read_bytes()),[dict(r,ply=0)for r in d['rows']if r['seed']==seed],cap))
for prefix in ['transfer','fresh']:
 plan=json.loads((B/(prefix+'-plan.json')).read_bytes());done=json.loads((B/(prefix+'-completion.json')).read_bytes());assert done['complete'];seeds=plan.get('seeds')or[x['seed']for x in plan['inputs']]
 for seed in seeds:
  data=json.loads((B/('paid-inputs'if prefix=='transfer'else'fresh-inputs')/f'{seed}.json').read_bytes());d=json.loads((B/f'{prefix}-{seed}.json').read_bytes());assert d['complete'];datasets.append((prefix,data,d['rows'],None))
ready=json.loads((B/'readiness-results.json').read_bytes());assert ready['complete']
transfer_conditions=json.loads((B/'transfer-plan.json').read_bytes())['conditions']
for seed in sorted({r['seed']for r in ready['rows']}):
 rows=[]
 for r in ready['rows']:
  if r['seed']==seed:
   limit=100000 if r['scope']=='inactive'else next(c['nodes']for c in transfer_conditions if c['label']==r['condition']);rows.append(dict(r,_budget_limit=limit))
 datasets.append(('readiness',json.loads((B/'paid-inputs'/f'{seed}.json').read_bytes()),rows,None))
counts={};tails=0
for kind,data,rows,cap in datasets:
 if data.get('state')=='GENERATION_OR_INPUT_FAILURE':assert not rows;continue
 raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(data['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=nc.compile_native_semantic_rules(c);cnt=counts.setdefault(kind,dict(roots=0,queries=0,edges=0))
 for root in data['roots']:
  selected=[r for r in rows if r['ply']==root['ply']]
  if not selected:continue
  s=GameSession(c)
  for a in root['walk']:s.submit(action(a))
  assert record_value(s.state)==root['state'];before=record_value(s.to_record());cnt['roots']+=1
  for row in selected:
   assert 'error'not in row;result=row['result'];limit=cap
   if limit is None and '_budget_limit'in row:limit=row['_budget_limit']
   if limit is None:
    plan=json.loads((B/(kind+'-plan.json')).read_bytes());limit=next(co['nodes']for co in plan['conditions']if co['label']==row['condition'])
   assert 0<=result['nodes']and 0<=result['qnodes']and result['nodes']+result['qnodes']<=limit
   state=s.state;pos=pack_semantic_search_position(c,nr,s);w=list(s._search_witnesses);line=[action(d)for d in result['principal_variation']]
   if line:assert record_value(line[0])==result['action']
   if not line and result['action']is not None:line=[action(result['action'])]
   for act in line:
    assert not state.terminal_status.is_terminal
    pos=sem.make_checked(nr,pos,pack_semantic_action(nr,state.position,act));state=apply_action(state,act,c);w.append(state.position);snap=sem.snapshot(nr,pos);exp=expected_snapshot(state.position,nr,c)
    for key in('board','hands','aux_state','side'):assert record_value(snap[key])==record_value(exp[key])
    assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(v,c))for v in w]
    assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
    assert sem.terminal_status(nr,pos)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner);cnt['edges']+=1
   assert record_value(s.to_record())==before;cnt['queries']+=1
 if data['terminal_tail']is not None:
  s=GameSession(c)
  for d in data['terminal_tail']['walk']:s.submit(action(d))
  assert record_value(s.state)==data['terminal_tail']['state']and s.result.status.value!='ongoing';tails+=1
 print('REPLAYED',kind,data['seed'],cnt,flush=True)
out=dict(complete=True,by_cohort=counts,roots=sum(v['roots']for v in counts.values()),queries=sum(v['queries']for v in counts.values()),edges=sum(v['edges']for v in counts.values()),terminal_tail_receipts=tails,seconds=time.perf_counter()-start,search_disabled=True,scope='Separate actual consumer with normal product Native and shared Core/compiler. Complete board/hands/aux/actor/digest/event histories, literal terminals and API main+q budget totals. Not timing rerun, independent rules implementation, optimal-PV oracle or all-domain proof.');(B/'consumer-replay.json').write_bytes(json.dumps(out,indent=2).encode());print('PASS',out,flush=True)
