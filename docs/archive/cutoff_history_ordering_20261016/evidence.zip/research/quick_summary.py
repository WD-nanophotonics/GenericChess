from pathlib import Path
import json,statistics,math
B=Path('.local_agent/cutoff-repetition-20261016');rows=[]
for p in B.glob('transfer-*.json'):
 if p.stem.split('-')[-1].isdigit():
  x=json.loads(p.read_bytes());rows+=x['rows']
print('closed',len(rows),'errors',sum('error'in r for r in rows))
for label in ['fixed_q0','fixed_q4','wall_q4']:
 rs=[r for r in rows if r['condition']==label];keys=sorted({(r['seed'],r['ply'],r['order'])for r in rs});eq=0;diff=[];pairs=[]
 for k in keys:
  p={r['arm']:r for r in rs if (r['seed'],r['ply'],r['order'])==k};a,b=p['baseline'],p['history'];ar,br=a['result'],b['result'];d=3 if label=='fixed_q0'else 2
  if label!='wall_q4'and ar['completed_depth']==br['completed_depth']==d:
   fields=['score','action','declaration_id','principal_variation','decision_line','completed_depth','result_ordinary_qdepth','result_check_hard_qdepth']
   bad=[f for f in fields if ar[f]!=br[f]]
   if bad:diff.append((k,bad))
   else:eq+=1
  pairs.append((b['seconds']/a['seconds'],(br['nodes']+br['qnodes'])/max(1,ar['nodes']+ar['qnodes'])))
 print(label,'pairs',len(keys),'equalfinite',eq,'mismatch',diff[:10],'ratios',tuple(math.exp(statistics.mean(math.log(x[i])for x in pairs))for i in range(2))if pairs else None)
