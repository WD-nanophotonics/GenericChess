from pathlib import Path
import sys,json,time,importlib.util,traceback
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')]
import allocation as a
plan=json.loads((B/'transfer-plan.json').read_bytes());mods={}
for name in ['baseline','history']:
 spec=importlib.util.spec_from_file_location(name+'._native_core',B/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
start=time.perf_counter();allcount=0;missing=[]
for seed in plan['seeds']:
 a.p.rr.stopped();x=json.loads((a.O/f'q-policy-{seed}.json').read_bytes());roots={r['ply']:r for r in x['roots']};rows=[];ss={}
 for ply in plan['plies']:
  if ply not in roots:missing.append(dict(seed=seed,ply=ply,slots=12,reason='actual_terminal_tail',terminal_tail=x['terminal_tail']));continue
  for name,mod in mods.items():ss[name]=a.load(dict(seed=seed,root=roots[ply]),mod)
  for condition in plan['conditions']:
   for order,names in enumerate(plan['orders']):
    for name in names:
     a.p.rr.stopped()
     if time.perf_counter()-start>=plan['whole_cap_seconds']:raise TimeoutError('Frozen transfer whole2400s cap')
     s,nr,bv,hv=ss[name];t=time.perf_counter()
     try:
      engine=a.SemanticSearchEngine(s.compiled,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
      res=engine.search(s,a.SearchLimits(max_depth=condition['depth'],max_nodes=condition['nodes'],max_time_seconds=condition['seconds'],quiescence_max_depth=condition['q'],quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=False)
      caller=time.perf_counter()-t;edges=a.audit(s,nr,res);row=dict(seed=seed,ply=ply,condition=condition['label'],order=order,arm=name,seconds=caller,result=a.record_value(res),pv_edges=edges)
     except Exception as e:
      row=dict(seed=seed,ply=ply,condition=condition['label'],order=order,arm=name,seconds=time.perf_counter()-t,error=repr(e),traceback=traceback.format_exc())
     rows.append(row);allcount+=1
     # Preserve each actual slot without overwriting frozen pilot receipts.
     a.write_record(B/f'transfer-{seed}-partial.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start))
  print(seed,ply,len(rows),'elapsed',round(time.perf_counter()-start,3),flush=True)
 a.write_record(B/f'transfer-{seed}.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start))
a.write_record(B/'transfer-completion.json',dict(complete=True,queries=allcount,missing=missing,seconds=time.perf_counter()-start));print('DONE',allcount,len(missing),time.perf_counter()-start,flush=True)
