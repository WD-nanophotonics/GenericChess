from pathlib import Path
import json,time,sys,importlib.util
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')];import allocation as a
plan=json.loads((B/'tt-plan.json').read_bytes());mods={}
for name in ['baseline','history']:
 spec=importlib.util.spec_from_file_location('tt'+name+'._native_core',B/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
start=time.perf_counter();rows=[]
for seed in plan['seeds']:
 x=json.loads((a.O/f'q-policy-{seed}.json').read_bytes());root=next(r for r in x['roots']if r['ply']==0);data={name:a.load(dict(seed=seed,root=root),mod)for name,mod in mods.items()}
 for order,names in enumerate(plan['orders']):
  engines={name:a.SemanticSearchEngine(data[name][0].compiled,data[name][1],board_values=data[name][2],hand_values=data[name][3],tt_megabytes=1,ordering_cache_enabled=False)for name in names}
  for ci,(label,q,depth)in enumerate(zip(plan['calls'],plan['q_depths'],plan['q_main_depths'])):
   for name in names:
    a.p.rr.stopped()
    if time.perf_counter()-start>=plan['whole_cap_seconds']:raise TimeoutError('Original TT240s cap')
    s,nr,bv,hv=data[name];hint=s.legal_actions()[0];t=time.perf_counter();r=engines[name].search(s,a.SearchLimits(max_depth=depth,max_nodes=262144,max_time_seconds=8,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True,root_order_hint=hint,stop_on_immediate_win=False);sec=time.perf_counter()-t;edges=a.audit(s,nr,r);rows.append(dict(seed=seed,order=order,arm=name,call=label,q=q,depth=depth,seconds=sec,result=a.record_value(r),pv_edges=edges));print(seed,order,label,name,r.completed_depth,r.tt_hits,round(sec,4),flush=True)
a.write_record(B/'tt-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('DONE',len(rows),time.perf_counter()-start,flush=True)
