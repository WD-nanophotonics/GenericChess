from pathlib import Path
import sys,json,time
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')];import allocation as a
from scripts.search_backend_comparison import CoreBoard,minimal_ab,MATE_SCORE
from generic_chess.core.search_runtime import SearchPathRuntime
plan=json.loads((B/'core-reference-plan.json').read_bytes());start=time.perf_counter();rows=[];missing=[]
class Material:
 def __init__(self,bv,hv):self.bv=bv;self.hv=hv
 def evaluate(self,state):
  p=state.position;score=sum((1 if x.owner==p.side_to_move else-1)*self.bv[x.current_type_id]for x in p.board if x is not None)+sum((1 if owner==p.side_to_move else-1)*self.hv[tid]*n for owner,h in enumerate(p.hands)for tid,n in h.items());return max(-90000000,min(90000000,score))
def normalize(value):
 if abs(value)>90000000:return (1 if value>=0 else-1)*(MATE_SCORE-(100000000-abs(value)))
 return value
for seed in plan['seeds']:
 data=json.loads((B/'fresh-inputs'/f'{seed}.json').read_bytes());native=json.loads((B/f'fresh-{seed}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(data['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};material=Material(bv,hv)
 for ply in plan['roots']:
  a.p.rr.stopped();root=next((r for r in data['roots']if r['ply']==ply),None)
  if root is None:missing.append(dict(seed=seed,ply=ply,reason='ORIGINAL_TERMINAL_TAIL'));continue
  if time.perf_counter()-start>=plan['whole_seconds']:missing.append(dict(seed=seed,ply=ply,reason='ORIGINAL_WHOLE_CAP'));continue
  s=a.GameSession(c)
  for stored in root['walk']:s.submit(next(act for act in s.legal_actions()if a.record_value(act)==stored))
  assert a.record_value(s.state)==root['state'];board=CoreBoard.__new__(CoreBoard);board.compiled=c;board.initial=s.state;board.witnesses=s._search_witnesses;board.runtime=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses,legal_binding_provider=None);board.material=material;board.checkpoint=None;board.label=repr;before=a.p.runtime_state(board.runtime)
  res=minimal_ab(board,4,seconds=min(20,plan['whole_seconds']-(time.perf_counter()-start)),node_limit=20000,cooperative=True);board.runtime.assert_balanced();assert res['native_provider_active'] is False;assert a.p.runtime_state(board.runtime)==before;comparisons=[]
  for arm in ['baseline','history']:
   n=next(r['result']for r in native['rows']if r['ply']==ply and r['condition']=='fixed_q0'and r['order']==0 and r['arm']==arm);both=res['completed_depth']==n['completed_depth']==4;comparisons.append(dict(arm=arm,native_depth=n['completed_depth'],native_score=n['score'],normalized_native_score=normalize(n['score']),both_complete=both,score_equal=both and res['score']==normalize(n['score'])))
  rows.append(dict(seed=seed,ply=ply,core=res,comparisons=comparisons,full_root_restored=True));a.write_record(B/'core-reference-results.json',dict(complete=False,rows=rows,missing=missing,seconds=time.perf_counter()-start));print(seed,ply,res['completed_depth'],res['reason'],round(res['wall_seconds'],3),[(x['arm'],x['both_complete'],x['score_equal'])for x in comparisons],flush=True)
a.write_record(B/'core-reference-results.json',dict(complete=True,rows=rows,missing=missing,seconds=time.perf_counter()-start,scope=plan['comparison']));print('CORE_CONTROL_DONE',len(rows),len(missing),time.perf_counter()-start,flush=True)
