from pathlib import Path
import sys,json,time
R=Path.cwd();B=R/'.local_agent/cutoff-repetition-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')]
import allocation as a
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action,expected_snapshot
from generic_chess.core.identity import position_identity_key

def act(d):
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
plan=json.loads((B/'screen-plan.json').read_bytes());start=time.perf_counter();rows=[]
for case in plan['cases']:
 a.p.rr.stopped();seed,ply=case['seed'],case['ply'];data=json.loads((B/'paid-inputs'/f'{seed}.json').read_bytes());root=next(r for r in data['roots']if r['ply']==ply);raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(data['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession(c)
 for d in root['walk']:s.submit(act(d))
 nr=a.nc.compile_native_semantic_rules(c);original=a.record_value(s.to_record());records=json.loads((B/f'transfer-{seed}.json').read_bytes())['rows']
 for arm in ['baseline','history']:
  a.p.rr.stopped();r=next(r for r in records if r['ply']==ply and r['condition']=='wall_q4'and r['order']==0 and r['arm']==arm);selected=act(r['result']['action']);t=time.perf_counter();rootpos=pack_semantic_search_position(c,nr,s);childpos=a.sem.make_checked(nr,rootpos,pack_semantic_action(nr,s.state.position,selected));codes=a.sem.guarded_actions(nr,childpos);checked=[];winner=None;complete=True
  for code in codes:
   if time.perf_counter()-t>=plan['per_child_native_seconds']:complete=False;break
   pos=a.sem.make_checked(nr,childpos,code);terminal=a.sem.terminal_status(nr,pos);checked.append(dict(code=code,terminal=terminal))
   if terminal['winner']==1-s.state.position.side_to_move:winner=code;complete=False;break
  native_seconds=time.perf_counter()-t;verify=time.perf_counter();child=a.apply_action(s.state,selected,c);core_actions=tuple(a.iter_legal_actions(child,c));decoded=[a.sem.public_action(nr,code)for code in codes];assert set(decoded)==set(core_actions)
  for checked_row in checked:
   reply=a.sem.public_action(nr,checked_row['code']);pos=a.sem.make_checked(nr,childpos,checked_row['code']);state=a.apply_action(child,reply,c);snap=a.sem.snapshot(nr,pos);expected=expected_snapshot(state.position,nr,c)
   for key in ['board','hands','aux_state','side']:assert a.record_value(snap[key])==a.record_value(expected[key])
   witnesses=list(s._search_witnesses)+[child.position,state.position];assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(p,c))for p in witnesses];assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history);assert checked_row['terminal']==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
  row=dict(**case,arm=arm,selected=r['result']['action'],kind='ONE_REPLY_WIN'if winner is not None else'NONE_FOUND_COMPLETE_ONE_PLY'if complete else'UNKNOWN',complete=complete,legal_replies=len(codes),checked=checked,winning_reply=None if winner is None else a.record_value(a.sem.public_action(nr,winner)),native_screen_seconds=native_seconds,core_verification_seconds=time.perf_counter()-verify);rows.append(row);assert a.record_value(s.to_record())==original;print(seed,ply,arm,row['kind'],len(codes),len(checked),native_seconds,flush=True)
  if time.perf_counter()-start>plan['whole_seconds']:raise TimeoutError('Original30second screen cap')
a.write_record(B/'screen-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,scope=plan['decision']));print('DONE',len(rows),time.perf_counter()-start)
