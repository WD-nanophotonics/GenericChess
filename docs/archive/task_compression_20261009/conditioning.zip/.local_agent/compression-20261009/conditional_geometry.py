"""Same fixed50 task cells: geometric supported captures vs legal unit task.
No new samples/law/fit. Inspect actual reply boards, separately include/exclude
enemy anchors. Report mismatches as support/legality scope, never attribute a
cause solely from aggregate accuracy. No product change or parameter selection.
"""
import sys,json,hashlib
from pathlib import Path
from fractions import Fraction
root=Path.cwd();sys.path[:0]=[str(root),str(root/'.local_agent/finite-law-20261009')]
from finite_law import collect
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'fixed-rule-compression.json';d=json.loads(src.read_bytes());out=p/'conditional-geometry.json';assert not out.exists()
c=compile_ruleset_for_execution(ruleset_from_dict(d['rules']));area=c.board_shape.area;source=15;anchors={t.type_id for t in c.piece_types if t.is_anchor};edges={t:collect(c,c.ir,t,EvaluationConfig())[0]['target_enemy'][source] for t in ('P','X')};rows=[]
for i,r in enumerate(d['rows']):
 for t in ('P','X'):
  cell=r['cells'][t];board=cell['state']['position']['board'];occ={j for j,x in enumerate(board) if x is not None};targets=[]
  if cell['survives']:
   assert board[source]['owner']==0 and board[source]['current_type_id']==t
   for target,events in edges[t].items():
    enemy=board[target] is not None and board[target]['owner']==1
    if enemy and any(not occ&cl and (k is None or len(occ&scope)==k) for cl,scope,k in events):targets.append(target)
  ordinary=[j for j in targets if board[j]['current_type_id'] not in anchors]
  rows.append(dict(reply_index=i,type=t,survives=cell['survives'],geometric_targets=targets,ordinary_targets=ordinary,any_ordinary=int(bool(ordinary)),task=cell['value']))
summary={t:dict(geometric_ordinary_any_mean=str(Fraction(sum(r['any_ordinary'] for r in rows if r['type']==t),25)),task_mean=str(Fraction(sum(r['task'] for r in rows if r['type']==t),25)),mismatch_indices=[r['reply_index'] for r in rows if r['type']==t and r['any_ordinary']!=r['task']]) for t in ('P','X')}
write_record(out,dict(complete=True,declaration=__doc__,rows=rows,summary=summary,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(src.read_bytes()).hexdigest()))
print(summary)
