"""Feasibility: expected endpoint count is not probability of any endpoint.
Fixed dual-transform rule, focal source(3,2), P/X supported ordinary geometric
capture endpoints only. Uniform initial fixed on-board stock, hypothetical actor
substitution, shared4096 colored layouts/seed202610090401. No legal anchoring,
opponent response or whole unit-task inference; this is a geometric diagnostic
of the statistic, not another material task/default or a law chosen by labels.
Compare exact finite E[count] and sampled E[count]/P(count>0); retain raw count
histograms and sampling uncertainty. <=60sec, no extra samples after results.
"""
import sys,json,hashlib,time,random,math
from pathlib import Path
from fractions import Fraction
from collections import Counter
root=Path.cwd();sys.path[:0]=[str(root),str(root/'.local_agent/finite-law-20261009')]
from finite_law import collect,canon,union
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'fixed-rule-compression.json';d=json.loads(src.read_bytes());out=p/'count-vs-any.json';assert not out.exists()
c=compile_ruleset_for_execution(ruleset_from_dict(d['rules']));area=c.board_shape.area;source=2*6+3;owner=0
initial=c.initial_position;initial=initial.board if hasattr(initial,'board') else initial
stock=[sum(x is not None and x.owner==o for x in initial) for o in (0,1)]
edges={t:collect(c,c.ir,t,EvaluationConfig())[0]['target_enemy'][owner*area+source] for t in ('P','X')}
exact={t:sum((Fraction(stock[1],area-1)*union(canon(events),area-2,sum(stock)-2) for events in bucket.values()),Fraction(0)) for t,bucket in edges.items()}
rng=random.Random(202610090401);hist={t:Counter() for t in edges};cells=[i for i in range(area) if i!=source];start=time.perf_counter()
for i in range(4096):
 assert time.perf_counter()-start<60
 z=rng.sample(cells,sum(stock)-1);occupied=set(z);enemy=set(z[:stock[1]])
 for t,bucket in edges.items():
  n=sum(target in enemy and any(not occupied&cl and (k is None or len(occupied&scope)==k) for cl,scope,k in events) for target,events in bucket.items())
  hist[t][n]+=1
rows={}
for t,h in hist.items():
 n=sum(h.values());mu=sum(k*v for k,v in h.items())/n;variance=sum((k-mu)**2*v for k,v in h.items())/(n-1);prob=1-h[0]/n
 rows[t]=dict(exact_expected_count=str(exact[t]),sample_mean_count=mu,mean_count_se=math.sqrt(variance/n),probability_any=prob,probability_any_se=math.sqrt(prob*(1-prob)/n),count_histogram=dict(h))
write_record(out,dict(complete=True,declaration=__doc__,stock=stock,owner=owner,source=source,samples=4096,seed=202610090401,rows=rows,seconds=time.perf_counter()-start,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
print(rows)
