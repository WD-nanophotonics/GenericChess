"""Independent Native replay of fixed-rule compression control, same states/actions.
Replay full declared prefix from genuine initial root; each checked move keeps
history. Compare Core/Native exact position identity, terminal and next legal
sets at all50 common-reply children and1440 own-action transitions. Independently
recompute unit rewards from Native board/hand snapshots. <=90sec/2000children;
no new context, policy, search, caps/defaults or weakened history authority.
"""
import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict,action_to_dict,action_is_board
from generic_chess.core.transition import apply_action,legal_successors
from generic_chess.core.identity import position_identity_key
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native import semantic as ns
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=p/'fixed-rule-compression.json';d=json.loads(src.read_bytes());out=p/'fixed-rule-native.json';assert not out.exists() and d['complete'];c=compile_ruleset_for_execution(ruleset_from_dict(d['rules']));nr=compile_native_semantic_rules(c);old=next(r for r in json.loads((root/'.local_agent/qsemantics-20261008/effect-feature.json').read_bytes())['cases'] if r['seed']==202610082003);route=next(r for r in json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes())['cases'] if r['seed']==old['seed'])['route'];s=GameSession(c);np=pack_semantic_search_position(c,nr,s);start=time.perf_counter();result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),prefix_moves=0,checked_transitions=0,legal_sets=0,cells=[]);write_record(out,result)
key=lambda a:json.dumps(action_to_dict(a),sort_keys=True)
def compare(native,state):
 assert ns.position_key(nr,native)==position_identity_key(state.position,c)
 assert ns.terminal_status(nr,native)==record_value(state.terminal_status)
 snap=ns.snapshot(nr,native);assert snap['history_exact'] and snap['history_events_exact'];return snap
def count(native,owner):
 snap=ns.snapshot(nr,native);anchors={i for i,tid in enumerate(nr.type_ids) if c.types_by_id[tid].is_anchor}
 return sum(x is not None and x[2]==owner and x[1] not in anchors for x in snap['board'])+sum(v for i,v in enumerate(snap['hands'][owner]) if i not in anchors)
try:
 for step in route[:old['event_ply']-1]:
  a=action_from_dict(step['action']);np=ns.make_checked(nr,np,pack_semantic_action(nr,s.state.position,a));s.submit(a);compare(np,s.state);result['prefix_moves']+=1
 for target in ('P','X'):
  a=action_from_dict(d['transform_actions'][target]);rt=apply_action(s.state,a,c);nt=ns.make_checked(nr,np,pack_semantic_action(nr,s.state.position,a));compare(nt,rt);result['checked_transitions']+=1
  for row in d['rows']:
   assert time.perf_counter()-start<90;assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];reply=action_from_dict(row['reply']);ch=apply_action(rt,reply,c);nc=ns.make_checked(nr,nt,pack_semantic_action(nr,rt.position,reply));compare(nc,ch);result['checked_transitions']+=1
   native_actions={key(ns.public_action(nr,a)):a for a in ns.transient_legal_actions(nr,nc)};core=legal_successors(ch,c);assert set(native_actions)=={key(a) for a,_ in core};result['legal_sets']+=1;vals=[];focal=action_from_dict(d['transform_actions'][target]).to_square;before=count(nc,1-rt.position.board[focal.rank*6+focal.file].owner)
   for action,last in core:
    nl=ns.make_checked(nr,nc,native_actions[key(action)]);compare(nl,last);result['checked_transitions']+=1
    if action_is_board(action) and action.from_square==focal:vals.append(before-count(nl,1-rt.position.board[focal.rank*6+focal.file].owner))
   value=max([0]+vals);assert value==row['cells'][target]['value'];result['cells'].append(dict(target=target,reply=row['reply'],value=value));write_record(out,result)
 result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
print('complete',result['complete'],'prefix',result['prefix_moves'],'transitions',result['checked_transitions'],'legalsets',result['legal_sets'],'seconds',result['seconds'])
