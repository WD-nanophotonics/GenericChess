"""Verify material-delta and common-coefficient premise before task compression.
Reconstruct exactly the existing two transform roots/eight variants. No new task
or samples. Record all board-current/hand-base features actually read by material
score, plus board-base/promoted provenance controls. Disable dynamic/promotion
terms, separate default and semantic profiles. Equal label/count differences
across different RuleSets do not imply equal coefficients; report fingerprints,
full price vectors, normalized differences and full physical states. <=60sec.
"""
import sys,json,time,hashlib
from pathlib import Path
from collections import Counter
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'material-premise.json';assert not out.exists();src=root/'.local_agent/qsemantics-20261008/effect-feature.json';prior=json.loads(src.read_bytes());coverage=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes());tasks=json.loads((root/'.local_agent/qsemantics-20261008/effect-unit-task.json').read_bytes());cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
def features(pos):
 result=Counter()
 for x in pos.board:
  if x is not None:result['board_current/'+str(x.owner)+'/'+x.current_type_id]+=1
 for o,hand in enumerate(pos.hands):
  for tid,n in hand:result['hand_base/'+str(o)+'/'+tid]+=n
 return result
def provenance(pos):
 return dict(Counter(str(x.owner)+'/'+x.base_type_id+'/'+x.current_type_id+'/'+str(x.promoted) for x in pos.board if x is not None))
def delta(a,b):return {k:b.get(k,0)-a.get(k,0) for k in sorted(a.keys()|b.keys()) if b.get(k,0)!=a.get(k,0)}
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),cases=[]);write_record(out,result);start=time.perf_counter()
for old in prior['cases']:
 route=next(x for x in coverage['cases'] if x['seed']==old['seed'])['route'];row=dict(seed=old['seed'],variants=[]);result['cases'].append(row)
 for v in old['variants']:
  assert time.perf_counter()-start<60;c=compile_ruleset_for_execution(ruleset_from_dict(v['rules']));s=GameSession(c)
  for step in route[:old['event_ply']]:s.submit(action_from_dict(step['action']))
  profiles={'default':build_ruleset_profile(c,cfg),'semantic':build_semantic_opportunity_profile(c,cfg)[0]}
  task=next(r for r in next(r for r in tasks['cases'] if r['seed']==old['seed'])['variants'] if (r['target'],r['duplicate'])==(v['target'],v['duplicate']))
  row['variants'].append(dict(target=v['target'],duplicate=v['duplicate'],fingerprint=c.ruleset_fingerprint,state=record_value(s.state),features=dict(features(s.state.position)),provenance=provenance(s.state.position),profiles={name:dict(board=dict(prof.board_value_by_type),hand=dict(prof.hand_value_by_base_type),owner0_score=Evaluator(c,prof,cfg).evaluate(s.state)*(1 if s.state.position.side_to_move==0 else -1)) for name,prof in profiles.items()},task=task['uniform_physical_value']))
 a,b=[v for v in row['variants'] if not v['duplicate']];assert (a['target'],b['target'])==('P','X');row['feature_delta_X_minus_P']=delta(a['features'],b['features']);row['task_delta_X_minus_P']=str(Fraction(b['task'])-Fraction(a['task']));row['same_profiles_within_seed']={name:a['profiles'][name]['board']==b['profiles'][name]['board'] and a['profiles'][name]['hand']==b['profiles'][name]['hand'] for name in profiles};row['material_delta_X_minus_P']={name:b['profiles'][name]['owner0_score']-a['profiles'][name]['owner0_score'] for name in profiles}
 for target in ('P','X'):
  a,b=[v for v in row['variants'] if v['target']==target];assert a['features']==b['features'] and a['profiles']==b['profiles']
 write_record(out,result)
result['complete']=True;result['seconds']=time.perf_counter()-start;write_record(out,result)
for row in result['cases']:print(row['seed'],row['feature_delta_X_minus_P'],row['task_delta_X_minus_P'],row['material_delta_X_minus_P'],row['same_profiles_within_seed'])
