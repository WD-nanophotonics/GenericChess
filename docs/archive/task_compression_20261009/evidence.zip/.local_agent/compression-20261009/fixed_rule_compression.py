"""One fixed RuleSet tests additive compression of conditional unit-removal tasks.
Reuse only seed2003's existing pre-transform parent. Construct one rule with
both supported X->P and X->X quiet choices, same destination, by appending X
choice to P variant; all other rules/initial layout unchanged. This is a new
explicit rule-construction control, not original cross-rule evidence or a new
random sample. Enumerate ALL common legal opponent public replies; retain lost,
terminal and differing-material-feature rows, no reward-positive selection.
Then same existing from-focal unit-removal task on next actual turn (task-stop0).
Record full states/current-board+base-hand features, actual default/semantic
static score differences and exact task values. Fixed coefficients may fail to
represent conditional tasks; this does not refute useful averaged approximation.
Bound <=10000 eager own successors/90sec, one writer, no search/default/horizon
change, human prices or fit. Keep branch differences/partial output if any.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from collections import Counter
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict,RuleTypeRef
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict,action_to_dict,action_is_board
from generic_chess.core.transition import legal_successors,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'fixed-rule-compression.json';assert not out.exists();src=root/'.local_agent/qsemantics-20261008/effect-feature.json';old=next(r for r in json.loads(src.read_bytes())['cases'] if r['seed']==202610082003);v=next(v for v in old['variants'] if v['target']=='P' and not v['duplicate']);definition=ruleset_from_dict(v['rules']);quiet=definition.semantic_actions[1];extra=replace(quiet,name=quiet.name+'_to_X',effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id='X')) if e.kind=='set_current_type' else e for e in quiet.effects));definition=replace(definition,semantic_actions=(*definition.semantic_actions,extra));c=compile_ruleset_for_execution(definition)
route=next(r for r in json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes())['cases'] if r['seed']==old['seed'])['route'];s=GameSession(c)
for step in route[:old['event_ply']-1]:s.submit(action_from_dict(step['action']))
orig=action_from_dict(route[old['event_ply']-1]['action']);focal=orig.to_square;index=focal.rank*6+focal.file;owner=s.state.position.side_to_move
chosen={target:next(a for a in s.legal_actions() if action_is_board(a) and a.from_square==orig.from_square and a.to_square==orig.to_square and a.pattern_id.startswith(prefix)) for target,prefix in (('P','sem_01_'),('X','sem_02_'))}
roots={target:apply_action(s.state,action,c) for target,action in chosen.items()};assert roots['P'].position.board[index].current_type_id=='P' and roots['X'].position.board[index].current_type_id=='X'
def feature(pos):
 z=Counter()
 for x in pos.board:
  if x is not None:z['board_current/'+str(x.owner)+'/'+x.current_type_id]+=1
 for o,h in enumerate(pos.hands):
  for tid,n in h:z['hand_base/'+str(o)+'/'+tid]+=n
 return dict(z)
def delta(a,b):return {k:b.get(k,0)-a.get(k,0) for k in sorted(a.keys()|b.keys()) if b.get(k,0)!=a.get(k,0)}
def count(pos,o):return sum(x is not None and x.owner==o and not c.types_by_id[x.current_type_id].is_anchor for x in pos.board)+sum(n for tid,n in pos.hands[o] if not c.types_by_id[tid].is_anchor)
key=lambda a:json.dumps(action_to_dict(a),sort_keys=True)
pairs={target:{key(a):(a,child) for a,child in legal_successors(state,c)} for target,state in roots.items()};common=sorted(pairs['P'].keys()&pairs['X'].keys());cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profiles={'default':build_ruleset_profile(c,cfg),'semantic':build_semantic_opportunity_profile(c,cfg)[0]};evaluators={name:Evaluator(c,prof,cfg) for name,prof in profiles.items()}
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rules=ruleset_to_dict(definition),fingerprint=c.ruleset_fingerprint,parent=record_value(s.state),transform_actions=record_value(chosen),roots={t:record_value(x) for t,x in roots.items()},profiles={n:dict(board=dict(prof.board_value_by_type),hand=dict(prof.hand_value_by_base_type)) for n,prof in profiles.items()},reply_population={t:len(x) for t,x in pairs.items()},common_reply_count=len(common),rows=[],actual_eager_own_successors=0);write_record(out,result);start=time.perf_counter()
try:
 for k in common:
  assert time.perf_counter()-start<90 and result['actual_eager_own_successors']<10000;assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];row=dict(reply=action_to_dict(pairs['P'][k][0]),cells={});result['rows'].append(row)
  for target in ('P','X'):
   reply,child=pairs[target][k];piece=child.position.board[index];survives=piece is not None and piece.owner==owner and piece.base_type_id=='X';options=[];before=count(child.position,1-owner)
   if survives and not child.terminal_status.is_terminal:
    succ=legal_successors(child,c);result['actual_eager_own_successors']+=len(succ)
    for action,last in succ:
     if action_is_board(action) and action.from_square==focal:options.append(dict(action=action_to_dict(action),reward=before-count(last.position,1-owner),terminal=record_value(last.terminal_status)))
   row['cells'][target]=dict(state=record_value(child),features=feature(child.position),survives=survives,choices=options,value=max([0]+[z['reward'] for z in options]),material_score={n:ev.evaluate(child)*(1 if child.position.side_to_move==0 else -1) for n,ev in evaluators.items()})
  a,b=row['cells']['P'],row['cells']['X'];row['feature_delta_X_minus_P']=delta(a['features'],b['features']);row['task_delta_X_minus_P']=b['value']-a['value'];row['material_delta_X_minus_P']={n:b['material_score'][n]-a['material_score'][n] for n in evaluators};write_record(out,result)
 result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
groups={}
for row in result['rows']:groups.setdefault(json.dumps(row['feature_delta_X_minus_P'],sort_keys=True),Counter())[row['task_delta_X_minus_P']]+=1
print('common',len(common),'replypop',result['reply_population'],'successors',result['actual_eager_own_successors'],'groups',groups)
