"""Summarize fixed-rule count compression without fitting a material table."""
import json, hashlib, sys
from pathlib import Path
from fractions import Fraction
from collections import Counter
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'fixed-rule-compression.json'
d=json.loads(src.read_bytes());assert d['complete']
key=lambda pos:json.dumps(pos,sort_keys=True,separators=(',',':'))
groups={}
for i,r in enumerate(d['rows']):
 a=r['cells']['P'];b=r['cells']['X']
 assert a['state']['position']['hands']==b['state']['position']['hands']
 assert a['state']['position']['aux_state']==b['state']['position']['aux_state']
 groups.setdefault((key(a['state']['position']),key(b['state']['position'])),[]).append(i)
for ids in groups.values():assert len({d['rows'][i]['task_delta_X_minus_P'] for i in ids})==1
partitions={t:{frozenset(i for i,r in enumerate(d['rows']) if key(r['cells'][t]['state']['position'])==k) for k in {key(r['cells'][t]['state']['position']) for r in d['rows']}} for t in ('P','X')}
assert partitions['P']==partitions['X']=={frozenset(ids) for ids in groups.values()}
means={t:Fraction(sum(d['rows'][ids[0]]['cells'][t]['value'] for ids in groups.values()),len(groups)) for t in ('P','X')}
public={t:Fraction(sum(r['cells'][t]['value'] for r in d['rows']),len(d['rows'])) for t in ('P','X')}
def rich(pos):
 return Counter('/'.join(map(str,(x['owner'],x['base_type_id'],x['current_type_id'],x['promoted']))) for x in pos['board'] if x is not None)
rich_deltas=[]
for r in d['rows']:
 a=rich(r['cells']['P']['state']['position']);b=rich(r['cells']['X']['state']['position'])
 rich_deltas.append({k:b[k]-a[k] for k in sorted(a.keys()|b.keys()) if b[k]!=a[k]})
assert len({key(z) for r,z in zip(d['rows'],rich_deltas) if r['feature_delta_X_minus_P']})==1
out=dict(scope='Descriptive compression qualification on one constructed fixed rule; no fitting table/loss/weights or search-history merging.',fingerprint=d['fingerprint'],public_replies=len(d['rows']),paired_physical_replies=len(groups),identical_marginal_partitions=True,
 physical_means={k:str(v) for k,v in means.items()},physical_mean_contrast=str(means['X']-means['P']),public_means={k:str(v) for k,v in public.items()},public_mean_contrast=str(public['X']-public['P']),
 physical_delta_histogram=dict(Counter(str(d['rows'][ids[0]]['task_delta_X_minus_P']) for ids in groups.values())),public_delta_histogram=dict(Counter(str(r['task_delta_X_minus_P']) for r in d['rows'])),aliases=[dict(indices=ids,delta=d['rows'][ids[0]]['task_delta_X_minus_P']) for ids in groups.values() if len(ids)>1],
 rich_board_count_delta=next(z for r,z in zip(d['rows'],rich_deltas) if r['feature_delta_X_minus_P']),conditional_extreme_witness_indices={str(v):next(i for i,r in enumerate(d['rows']) if r['task_delta_X_minus_P']==v) for v in (-1,0,1)},
 residual_statement='Surviving pairs share full owner/base/current/promoted count difference and equal hand/aux states, but task contrasts -1 and+1 occur. Any fixed additive count prediction has maximum absolute error at least1 on these conditional contrasts, even with background intercepts. Not material calibration/global impossibility/mean-error guarantee.',
 input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(p/'compression-summary.json',out)
print('paired physical',len(groups),'task means',means,'contrast',means['X']-means['P'])
