"""Summarize declared public search controls, retaining equal-stop scope."""
import json, hashlib, sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent
d=json.loads((p/'fixed-rule-search.json').read_bytes());assert d['complete']
rows=[]
fields=('action','score','principal_variation','completed_depth','nodes','qnodes','termination_reason')
for c in d['cases']:
    runs=c['searches'];assert len(runs)==4
    assert len({json.dumps({k:r['decision'][k] for k in fields},sort_keys=True) for r in runs})==1
    for native in (False,True):
        old=next(r for r in runs if r['native']==native and not r['product'])
        new=next(r for r in runs if r['native']==native and r['product'])
        assert all(r['stats']['runtime_pushes']==r['stats']['runtime_pops'] and r['stats']['runtime_depth_balanced'] for r in (old,new))
        rows.append(dict(delta=c['delta'],target=c['target'],native=native,exact_signature=True,
                         depth=new['decision']['completed_depth'],reason=new['decision']['termination_reason'],
                         old_pushes=old['stats']['runtime_pushes'],new_pushes=new['stats']['runtime_pushes'],
                         old_seconds=old['seconds'],new_seconds=new['seconds']))
task=json.loads((p/'fixed-rule-compression.json').read_bytes())
groups={}
for r in task['rows']:
    for t in ('P','X'):
        k=(t,json.dumps(r['cells'][t]['state']['position'],sort_keys=True))
        groups.setdefault(k,set()).add(r['cells'][t]['value'])
assert all(len(v)==1 for v in groups.values())
write_record(p/'search-summary.json',dict(scope='New constructed caller, no frozen-cohort enlargement or material/strength claim. Exact per-root signatures across old/fused and Core/Native; do not compare different-root D2 and D3 as a shared horizon.',rows=rows,calls=16,all_physical_alias_cell_values_equal=True,input_sha256=hashlib.sha256((p/'fixed-rule-search.json').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
print('16 calls exact per-root; physical aliases preserve each task value')
