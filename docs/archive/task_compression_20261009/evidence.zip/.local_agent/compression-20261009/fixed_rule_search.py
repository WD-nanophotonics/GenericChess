"""Public search integration of the newly constructed dual-transform rule.
New caller, not enlargement of frozen22/8x8 cohorts: same-rule task witnesses
have two simultaneous quiet current-type alternatives, including a no-change
option. Select conditional -1/+1 witness rows already fixed in summary, both
P/X states (four roots). Cold original/fused lexical runtime under Core and
Native legality, same fixed Native semantic evaluator/TT/main/no root/PVS,
D3/8192nodes/30sec/q2-hard8,16calls<=480sec search. Compare exact decisions/main/
qnodes at equal node stops/completion; wall-limited cells remain unknown for
semantic comparison. No resource expansion or preferred-default selection.
This verifies new runnable rule/control enters supported public search; not
material utility/strength evidence. One serial writer, bounded TT, stop flags.
"""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
import generic_chess.ai.alphabeta.search as search
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;src=p/'fixed-rule-compression.json';d=json.loads(src.read_bytes());summary=json.loads((p/'compression-summary.json').read_bytes());out=p/'fixed-rule-search.json';assert not out.exists();c=compile_ruleset_for_execution(ruleset_from_dict(d['rules']));cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');original_source=json.loads((root/'.local_agent/query-transfer-20261009/event-lexical-pilot.json').read_bytes())['original_source'];ns=dict(search.__dict__);exec(original_source,ns);original=ns['_quiescence_runtime'];product=search._quiescence_runtime
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),original_source=original_source,product_sha256=hashlib.sha256(Path(search.__file__).read_bytes()).hexdigest(),cases=[]);write_record(out,result);start=time.perf_counter()
def transform(t):
 z=d['transform_actions'][t];return action_from_dict(dict(kind='semantic_board',pattern_id=z['pattern_id'],geometry_id=z['geometry_id'],actor_type_id=z['actor_type_id'],**{'from':[z['from_square']['file'],z['from_square']['rank']],'to':[z['to_square']['file'],z['to_square']['rank']],'promotion_target_id':z['promotion_target_id']}))
try:
 for delta in (-1,1):
  index=summary['conditional_extreme_witness_indices'][str(delta)];row=d['rows'][index]
  for target in ('P','X'):
   s=GameSession(c);s.submit(transform(target));s.submit(action_from_dict(row['reply']));assert record_value(s.state)==row['cells'][target]['state'];before=(s.state,s.history,s._search_witnesses);case=dict(delta=delta,row_index=index,target=target,searches=[]);result['cases'].append(case)
   for native in (False,True):
    for actual in ((False,True) if delta<0 else (True,False)):
     assert time.perf_counter()-start<600
     for f in ('rollout.json','advisor.json','slack.json'):
      z=json.loads((root/'.local_agent'/f).read_bytes());assert not z.get('stopped',False) and not z.get('user_paused',False)
     player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=native,tuning=SearchTuning(use_root_tactical=False));stats=[]
     def stat():
      z=SearchStatistics();stats.append(z);return z
     t=time.perf_counter()
     with patch('generic_chess.ai.alphabeta.player.SearchStatistics',stat),patch.object(search,'_quiescence_runtime',product if actual else original):
      dec=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=30,quiescence_max_depth=2,quiescence_hard_max_depth=8))
     elapsed=time.perf_counter()-t;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before and stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops
     case['searches'].append(dict(native=native,product=actual,seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0])));write_record(out,result)
     print(delta,target,native,actual,dec.completed_depth,dec.termination_reason,dec.score,dec.nodes,dec.qnodes,stats[0].runtime_pushes,round(elapsed,3),flush=True)
 result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
