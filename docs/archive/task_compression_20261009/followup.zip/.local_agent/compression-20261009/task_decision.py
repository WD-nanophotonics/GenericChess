"""Existing task decisions under declared reply laws, no fitted coefficients.
Only two focal transformation choices; not the full game root action set.
Uniform public/physical reply averages and adversarial minimum are separate
declared functionals on the already complete same-rule task matrix. Verify
whether the existing static material proxy agrees with these local decisions.
No new task, samples, game-value interpretation or default modification.
"""
import json,sys,hashlib
from pathlib import Path
from fractions import Fraction
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'fixed-rule-compression.json').read_bytes());s=json.loads((p/'compression-summary.json').read_bytes())
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
c=compile_ruleset_for_execution(ruleset_from_dict(d['rules']));cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
profiles={'default':build_ruleset_profile(c,cfg),'semantic':build_semantic_opportunity_profile(c,cfg)[0]}
scores={}
for name,profile in profiles.items():
 scores[name]={}
 for target in ('P','X'):
  s0=GameSession(c);a=d['transform_actions'][target]
  s0.submit(action_from_dict(dict(kind='semantic_board',pattern_id=a['pattern_id'],geometry_id=a['geometry_id'],actor_type_id=a['actor_type_id'],**{'from':[a['from_square']['file'],a['from_square']['rank']],'to':[a['to_square']['file'],a['to_square']['rank']],'promotion_target_id':a['promotion_target_id']})))
  assert s0.state.position.side_to_move==1
  scores[name][target]=-Evaluator(c,profile,cfg).evaluate(s0.state)
laws={'uniform_public':{t:Fraction(s['public_means'][t]) for t in ('P','X')},'uniform_physical':{t:Fraction(s['physical_means'][t]) for t in ('P','X')},'adversarial_minimum':{t:Fraction(min(r['cells'][t]['value'] for r in d['rows'])) for t in ('P','X')}}
choices={name:[t for t,v in values.items() if v==max(values.values())] for name,values in scores.items()}
rows=[]
for law,values in laws.items():
 optimal=[t for t,v in values.items() if v==max(values.values())]
 rows.append(dict(law=law,values=values,task_optimal=optimal,static_proxy_choices=choices,regret={name:{t:max(values.values())-values[t] for t in ts} for name,ts in choices.items()}))
write_record(p/'task-decision.json',dict(scope=__doc__,material_scores=scores,rows=rows,qualification='Task-stop0 makes worst-case both0; uniform laws prefer X but this is a fixed focal two-choice task, not the full game action set or a new default. No conversion from price points to task units.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256((p/'fixed-rule-compression.json').read_bytes()).hexdigest()))
print(scores,rows)
