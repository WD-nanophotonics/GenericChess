"""Verify source/input chains and rerun restored Native control, not new research."""
import hashlib,json,sys,subprocess,zipfile
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
root=Path.cwd();p=Path(__file__).parent;restored=root/'.local_agent/compression-recovery-20261009/.local_agent/compression-20261009'
pairs=[('material_premise.py','material-premise.json'),('fixed_rule_compression.py','fixed-rule-compression.json'),('fixed_rule_native.py','fixed-rule-native.json'),('fixed_rule_native_v2.py','fixed-rule-native-v2.json'),('compression_summary.py','compression-summary.json'),('fixed_rule_search.py','fixed-rule-search.json'),('search_summary.py','search-summary.json')]
for src,out in pairs:
 d=json.loads((restored/out).read_bytes());assert hashlib.sha256((restored/src).read_bytes()).hexdigest()==d['producer_sha256'],src
inputs={'.local_agent/qsemantics-20261008/effect-feature.json':'qsemantics_20261008','.local_agent/qsemantics-20261008/effect-unit-task.json':'qsemantics_20261008','.local_agent/generated6-20261008/coverage.json':'generated6_20261008'}
dependencies=[]
for member,archive in inputs.items():
 manifest=json.loads((root/'docs/archive'/archive/'index.json').read_bytes());entry=next(e for e in manifest['members'] if e['path']==member)
 candidates=list((root/'docs/archive'/archive).glob('*.zip'));found=[]
 for zp in candidates:
  with zipfile.ZipFile(zp) as z:
   if member in z.namelist():
    data=z.read(member);assert hashlib.sha256(data).hexdigest()==entry['sha256'];assert data==(root/member).read_bytes();found.append(zp.relative_to(root).as_posix())
 assert found,member
 dependencies.append(dict(member=member,sha256=entry['sha256'],archives=found))
run=root/'.local_agent/compression-native-replay-20261009';assert not run.exists();run.mkdir()
for name in ('fixed_rule_native_v2.py','fixed-rule-compression.json'):(run/name).write_bytes((restored/name).read_bytes())
subprocess.run([sys.executable,'-X','utf8',str(run/'fixed_rule_native_v2.py')],check=True)
a=json.loads((restored/'fixed-rule-native-v2.json').read_bytes());b=json.loads((run/'fixed-rule-native-v2.json').read_bytes())
assert {k:v for k,v in a.items() if k!='seconds'}=={k:v for k,v in b.items() if k!='seconds'}
write_record(p/'recovery-verification.json',dict(source_hash_pairs=len(pairs),dependencies=dependencies,restored_native_replay='All fields except measured seconds match;50legalsets1618transitions.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Archive recovery and same product f8 code, not new samples or independent holdout. Earlier archive scanner falsely detected its own literal sentinel and left an ignored partial ZIP; no raw observations lost.'))
print('source chains7; dependency archives3; restored Native replay exact')
