"""One predeclared exposed earlier-loss root, not a strength/causality certificate."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;out=p/'root.json';assert not out.exists()
plan=json.loads((p/'root-plan.json').read_bytes());raw=(ROOT/plan['source']).read_bytes();assert hashlib.sha256(raw).hexdigest()==plan['source_sha256']
g=json.loads(raw)['games'][plan['game_index']];i=plan['root_move_index'];assert g['candidate_color']==1 and g['table']=='unit'
history=g['opening_uci']+[r['move'] for r in g['moves'][:i]];recorded=g['moves'][i];assert recorded['move']=='g3f4' and recorded['side']==1
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());state,_=d.replay_prefix(g['initial_fen'],c,history);b=chess.Board(g['initial_fen'])
for m in history:b.push_uci(m)
legal={d.uci(a) for a in d.iter_legal_actions(state,c)};assert legal=={m.uci() for m in b.legal_moves} and len(state.history)==len(history)+1
decl=json.loads((p/'declaration.json').read_bytes())
report=dict(complete=False,plan=plan,fen=b.fen(en_passant='fen'),history_prefix=history,recorded_choice=recorded,choices=[],references={},source_sha256=plan['source_sha256'],core_history_root=True)
def stop():
 for n in ('rollout','advisor','slack'):
  x=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes());assert not x.get('stopped') and not x.get('user_paused')
def pvcheck(board,pv):
 z=board.copy(stack=True)
 for m in pv:assert chess.Move.from_uci(m) in z.legal_moves;z.push_uci(m)
for mode in ('original','price'):
 stop();binary=ROOT/decl['binaries'][mode]['path'];assert hashlib.sha256(binary.read_bytes()).hexdigest()==decl['binaries'][mode]['sha256']
 with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(ROOT/'.local_agent/mature-search/material-variants.ini')],timeout=15) as e:
  e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=d.UciMaterial(e,g['initial_fen'],'unit',1);d.replay_prefix(g['initial_fen'],c,history,(player,));m,row=player.choose();assert m in legal;pvcheck(b,row['pv']);report['choices'].append(dict(mode=mode,binary_sha256=decl['binaries'][mode]['sha256'],requested_seconds=1,**row));d.write_record(out,report)
ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe';assert hashlib.sha256(ref.read_bytes()).hexdigest()==decl['reference_sha256']
with chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as e:
 e.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
 def analyse(board):
  stop();e.configure({'Clear Hash':None});start=time.perf_counter();r=e.analyse(board,chess.engine.Limit(nodes=500000,time=1),game=object());pv=[m.uci() for m in r.get('pv',())];pvcheck(board,pv);score=r['score'].pov(b.turn)
  return dict(cp=score.score(),mate=score.mate(),nodes=r.get('nodes'),depth=r.get('depth'),wall_seconds=time.perf_counter()-start,pv=pv)
 report['reference_root']=analyse(b);best=report['reference_root']['pv'][0];assert best in legal
 for m in sorted({recorded['move'],best}|{r['move'] for r in report['choices']}):
  child=b.copy(stack=True);child.push_uci(m);report['references'][m]=analyse(child);d.write_record(out,report)
report.update(complete=True,pv_mismatches=0,core_history_plies=len(history),reference_binary_sha256=decl['reference_sha256']);d.write_record(out,report)
print(json.dumps(dict(choices=[{k:r.get(k) for k in ('mode','move','score_cp','score_mate')} for r in report['choices']],reference_root=report['reference_root'],children=report['references'])))
