"""Selector audit only: no additional game/search budget or candidate outcomes."""
from pathlib import Path
import sys,json,time,hashlib
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.search import _runtime_noisy_actions
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
compiled={g:compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if g=='chess' else 'standard_shogi')) for g in ('chess','shogi')}
rows=[]
for case in CASES:
 board=CoreBoard(case,compiled[case['game']]);actions=tuple(a for _,a in board.actions());stats=SearchStatistics()
 ctx=SimpleNamespace(runtime=board.runtime,compiled=board.compiled,stats=stats,tuning=SearchTuning(),checkpoint=None)
 tick=time.perf_counter();noisy=_runtime_noisy_actions(ctx,actions);wall=time.perf_counter()-tick
 assert board.restored()
 rows.append(dict(id=case['id'],legal=len(actions),noisy=len(noisy),root_in_check=board.runtime.in_check(board.runtime.position.side_to_move),classification_seconds=wall,stats=record_value(stats)))
selection=max(rows,key=lambda r:(r['noisy'],r['legal'],r['id']))
report=dict(declaration=__doc__,complete=True,rows=rows,selected=selection['id'],criterion='generic existing noisy classification, then legal burden/id; no candidate search results',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(ROOT/'.local_agent/ui-product-20261010/tactical-selector.json',report)
print([(x['id'],x['legal'],x['noisy']) for x in rows]);print('selected',selection['id'])
