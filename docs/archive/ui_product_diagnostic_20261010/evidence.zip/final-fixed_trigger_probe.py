"""Isolated fixed-square trigger dispatch; not installed production code.
Immutable rule metadata chooses event/square entries, preserving runtime owner
filters, dynamic-reference fallback, and explicit auxiliary-effect ordering.
"""
from collections import defaultdict
import inspect,textwrap
from generic_chess.core import semantic_executor as se

def install(*, amortized=False):
    owners={}
    old_init=se.SemanticEngine.__init__
    old_transition=se.SemanticEngine._transition
    source=textwrap.dedent(inspect.getsource(old_transition))
    start=source.index('    # 5) transition triggers')
    end=source.index('    # 6) explicit aux effects',start)
    original=source[start:end]
    # Dynamic fallback executes unchanged trigger semantics in the same lifecycle.
    fallback=original.replace('    # 5) transition triggers against the pre-bound event trace.\n','').replace('self.ir.triggers','triggers')
    helper='def dynamic(self, triggers, side, position, work, binding, aux, checkpoint):\n'+fallback
    ns=dict(vars(se));exec(helper,ns);dynamic=ns['dynamic']
    source=source[:start]+'    apply_triggers(self, side, position, work, binding, aux, checkpoint)\n'+source[end:]
    def init(self,semantic):
        old_init(self,semantic)
        cached=owners.get(id(semantic)) if amortized else None
        if cached is not None and cached[0] is semantic:
            self._probe_fixed_trigger_plans=cached[1]
            return
        plans=[]
        for side in (0,1):
            entries=defaultdict(list);others=[]
            for trigger in self.ir.triggers:
                slot=se._aux_slot_by_id(self.ir.aux_slots,trigger.slot_id)
                if slot is None:continue
                if trigger.square_ref.kind!='fixed':others.append(trigger);continue
                for owner in ((0,1) if slot.scope=='per_owner' else (side,)):
                    f,r=trigger.square_ref.square
                    if trigger.square_ref.owner_relative and owner==1:
                        f,r=self.support.board_shape.width-1-f,self.support.board_shape.height-1-r
                    if 0<=f<self.support.board_shape.width and 0<=r<self.support.board_shape.height:
                        idx=r*self.support.board_shape.width+f
                        entries[(trigger.event,idx)].append((trigger.slot_id,owner if slot.scope=='per_owner' else se.GLOBAL_OWNER_TAG,owner,trigger.owner))
            plans.append((dict((k,tuple(v)) for k,v in entries.items()),tuple(others)))
        self._probe_fixed_trigger_plans=tuple(plans)
        if amortized:owners[id(semantic)]=(semantic,self._probe_fixed_trigger_plans)
    def apply_triggers(self,side,position,work,binding,aux,checkpoint):
        if not hasattr(self,"_probe_fixed_trigger_plans"):
            dynamic(self,self.ir.triggers,side,position,work,binding,aux,checkpoint)
            return
        entries,dynamic_triggers=self._probe_fixed_trigger_plans[side]
        for event,piece,square in work.events:
            se._checkpoint(checkpoint)
            if piece is None:continue
            for slot,logical,owner,filter in entries.get((event,square),()):
                se._checkpoint(checkpoint)
                if filter=='self' and piece.owner!=owner:continue
                if filter=='opponent' and piece.owner==owner:continue
                aux[(slot,logical)]=0
        dynamic(self,dynamic_triggers,side,position,work,binding,aux,checkpoint)
    ns['apply_triggers']=apply_triggers;exec(source,ns)
    se.SemanticEngine.__init__=init;se.SemanticEngine._transition=ns['_transition']
    return old_init,old_transition

if __name__=='__main__':
    import runpy,sys
    amortized="--amortized" in sys.argv
    if amortized:sys.argv.remove("--amortized")
    install(amortized=amortized);sys.argv=[str(__file__)]+sys.argv[1:]
    runpy.run_path(str(__import__('pathlib').Path(__file__).with_name('ui_failure_replay.py')),run_name='__main__')
