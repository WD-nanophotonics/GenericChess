from pathlib import Path
import sys,json,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from dataclasses import replace
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.research_record import write_record,record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.search_backend_comparison import Material


class Unit:
 def evaluate(self,state):
  p=state.position;v=sum((1 if x.owner==p.side_to_move else -1)*100 for x in p.board if x is not None and x.current_type_id!='K')
  return v+sum((1 if o==p.side_to_move else -1)*100*n for o,h in enumerate(p.hands) for _,n in h.items())
 def type_value(self,tid):return 0 if tid=='K' else 100
 def capture_order_value(self,m,c):return 10*self.type_value(c.current_type_id)-self.type_value(m.current_type_id)
out=ROOT/'.local_agent/ui-product-20261010/trigger-transition-audit.json'
report=dict(declaration='All one-step children and all children of first4 lexicographic successors on8 existing attribution roots plus generated4seed21. Paired full state and legal frontier versus full old dynamic trigger traversal; no candidate-result selection. Product fixedD2 q2/5sec onsame9 roots: caps retained.',complete=False,cases=[],source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
compiled={g:compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if g=='chess' else 'standard_shogi')) for g in ('chess','shogi')}
roots=[]
for case in CASES:
 b=CoreBoard(case,compiled[case['game']]);roots.append((case['id'],b.initial,b.compiled,b.material,b.witnesses))
gc=compile_ruleset_for_execution(generate_game(GeneratorConfig(seed=21,board_size=4,setup_preset='bilateral_random',allow_hybrid=True)).ruleset)
gs=GameSession(gc);roots.append(('generated4seed21',gs.state,gc,Unit(),gs._search_witnesses))
for name,state,c,e,witnesses in roots:
 flags=[json.loads((ROOT/'.local_agent'/f'{n}.json').read_bytes()) for n in ('rollout','advisor','slack')]
 if any(f.get('stopped') or f.get('user_paused') for f in flags):raise RuntimeError('stopped')
 baseline=replace(c);object.__setattr__(baseline,'_fixed_transition_triggers',None)
 states=[state];children=0;legalsets=0
 for level in range(2):
  nextstates=[]
  for parent in states:
   legal=tuple(sorted(legal_actions(parent,c),key=str));other=tuple(sorted(legal_actions(parent,baseline),key=str));assert legal==other;legalsets+=1
   for a in legal:
    x=apply_action(parent,a,c);y=apply_action(parent,a,baseline);assert x==y;children+=1
    if level==0 and len(nextstates)<4:nextstates.append(x)
  states=nextstates
 session=GameSession(c);session._state=state;session._search_history_witnesses=witnesses
 rows=[]
 for cc in (baseline,c):
  session=GameSession(cc);session._state=state;session._search_history_witnesses=witnesses
  player=AlphaBetaPlayer(cc,evaluator_override=e,use_native_semantic_legality=False)
  tick=time.perf_counter();d=player.choose_action(session,SearchLimits(max_depth=2,max_time_seconds=5,max_nodes=1000000,quiescence_max_depth=2,quiescence_hard_max_depth=8));wall=time.perf_counter()-tick
  assert session.state==state;rows.append(dict(wall=wall,decision=record_value(d)))
 if all(r['decision']['completed_depth']==2 for r in rows):
  for key in ('action','score','principal_variation','nodes','qnodes'):assert rows[0]['decision'][key]==rows[1]['decision'][key]
 report['cases'].append(dict(id=name,children=children,legalsets=legalsets,rows=rows));write_record(out,report);print(name,children,[(r['decision']['completed_depth'],r['decision']['termination_reason'],r['wall']) for r in rows],flush=True)
report['complete']=True;write_record(out,report)
