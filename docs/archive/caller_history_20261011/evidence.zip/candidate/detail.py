from pathlib import Path
import sys,time,json,importlib.util,functools
from dataclasses import asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/candidate-iteration-20261011';OLD=ROOT/'.local_agent/eager-binding-20261011'
spec=importlib.util.spec_from_file_location('qi',OLD/'q-identity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess.core import search_runtime as sr
from generic_chess.core import semantic_executor as se
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.evaluation import EvaluationConfig, EvaluationProfileCache, Evaluator
patches=[]
class Meter:
 def __init__(self):self.current='search_other';self.last=time.perf_counter();self.cost={};self.calls={};self.start=self.last
 def switch(self,new):
  now=time.perf_counter();self.cost[self.current]=self.cost.get(self.current,0)+now-self.last;self.last=now;previous=self.current;self.current=new;return previous
 def finish(self):self.switch('done');return dict(exclusive_seconds=self.cost,calls=self.calls,elapsed_seconds=self.last-self.start,sum_seconds=sum(self.cost.values()))
meter=None
def wrap(obj,name,tag):
 fn=getattr(obj,name)
 @functools.wraps(fn)
 def wrapped(*args,**kwargs):
  chosen=tag(meter.current) if callable(tag) else tag;previous=meter.switch(chosen);meter.calls[chosen]=meter.calls.get(chosen,0)+1
  try:return fn(*args,**kwargs)
  finally:meter.switch(previous)
 patches.append((obj,name,fn));setattr(obj,name,wrapped)

def wrap_generator(obj,name,tag):
 fn=getattr(obj,name)
 class TimedIterator:
  def __init__(self,inner):self.inner=inner
  def __iter__(self):return self
  def advance(self,method,*args):
   parent=meter.current;chosen=tag(parent);previous=meter.switch(chosen)
   meter.calls[chosen]=meter.calls.get(chosen,0)+1
   try:return getattr(self.inner,method)(*args)
   finally:meter.switch(previous)
  def __next__(self):return self.advance('__next__')
  def send(self,value):return self.advance('send',value)
  def throw(self,*args):return self.advance('throw',*args)
  def close(self):return self.advance('close')
 @functools.wraps(fn)
 def wrapped(*args,**kwargs):return TimedIterator(fn(*args,**kwargs))
 patches.append((obj,name,fn));setattr(obj,name,wrapped)

def install():
 wrap(se,'_sources_by_owner_type',lambda parent:'terminal_sources' if parent.startswith('terminal_') else parent)
 wrap(SemanticEngine,'_ensure_match',lambda parent:'terminal_match' if parent.startswith('terminal_') else parent)
 for n in ('_target_holds','_path_holds','_promotion_choices','_violates_postconditions'):
  wrap(SemanticEngine,n,lambda parent,n=n:'terminal'+n if parent.startswith('terminal_') else parent)
 wrap(se,'geometry_candidates',lambda parent:'terminal_geometry' if parent.startswith('terminal_') else parent)

 for name in ('_iter_candidates','_iter_board_candidates','_iter_drop_candidates','iter_legal_action_bindings','iter_legal_actions'):
  wrap_generator(SemanticEngine,name,lambda parent,n=name: 'terminal_iteration'+n if parent.startswith('terminal_') else parent)
 wrap(SemanticEngine,'_make_binding',lambda parent:'terminal_binding' if parent.startswith('terminal_') else parent)
 wrap(SemanticEngine,'has_legal_action','terminal_exists')
 wrap(SemanticEngine,'_guards_hold',lambda parent:'terminal_guards' if parent.startswith('terminal_') else parent)
 wrap(SemanticEngine,'_trial_child_if_s3_legal',lambda parent:'terminal_trial' if parent.startswith('terminal_') else parent)
 wrap(Evaluator,'evaluate','product_evaluation')
 wrap(Evaluator,'_attack_maps','evaluation_attack_maps')
 wrap(sr.SearchPathRuntime,'legal_actions','search_legality')
 wrap(sr,'terminal_from_search_runtime','core_terminal')
 wrap(sr.SearchPathRuntime,'_gave_check','check_query');wrap(sr.SearchPathRuntime,'in_check','check_query')
 wrap(sr,'_apply_action_unchecked','legacy_search_transition')
 wrap(SemanticEngine,'_transition',lambda parent:'semantic_trial_transition' if parent in ('search_legality','core_terminal','terminal_trial','terminal_exists') or parent.startswith('terminal_iteration') else 'semantic_search_transition')
 for name in ('_semantic_component_diff_hash','_legacy_incremental_hash','_full_runtime_hash'):wrap(sr,name,'component_hash')
 for name in ('_occurrence_add','_occurrence_remove','_find_occurrence'):wrap(sr.SearchPathRuntime,name,'history_occurrences')
 wrap(sr.RuntimeCountsSnapshot,'updated','history_snapshot')
 wrap(sr.RuntimeHistoryContext,'append','history_context')
 wrap(NativeSemanticLegalityProvider,'__call__','native_provider')
 wrap(NativeSemanticLegalityProvider,'_state_only_payload','native_state_payload')
 wrap(NativeSemanticLegalityProvider,'_decode_action','native_decode_action')
 wrap(SemanticEngine,'_make_binding_from_action',lambda parent:'native_validate_binding' if parent=='native_provider' else parent)
def restore():
 while patches:
  obj,name,fn=patches.pop();setattr(obj,name,fn)
def main():
 global meter
 started=time.perf_counter();r=dict(complete=False,declaration=(B/'detail-plan.md').read_text(),rows=[])
 for seed in (2026101103,):
  g=m.generate_game(m.GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));old=g.compiled_ruleset;new=m.compile_legacy_ruleset_for_semantic_execution(g.ruleset);provider=m.NativeSemanticLegalityProvider.try_create(new,strict=True);a,b=m.initial_state(old),m.initial_state(new);wa,wb=[a.position],[b.position]
  for ply in range(6):
   aa,bb=m.groups(a,old),m.groups(b,new);k=sorted(aa,key=lambda x:repr((getattr(aa[x][0],'from_square',None),aa[x][0].to_square,getattr(aa[x][0],'promotion_target_id',None),getattr(aa[x][0],'base_type_id',None))))[(seed+ply)%len(aa)];a=m.apply_action(a,aa[k][0],old);b=m.apply_action(b,bb[k][0],new);wa.append(a.position);wb.append(b.position)
  arms=[('legacy',old,a,tuple(wa),None),('semantic',new,b,tuple(wb),None)]+([('hybrid',new,b,tuple(wb),provider)] if provider else [])
  for instrumented,arm,c,state,w,prov in [(True,*x) for x in arms]+[(False,*x) for x in arms+list(reversed(arms))]:
   m.stopped();assert time.perf_counter()-started<60
   if prov:prov._metrics_local.public_cache={}
   stats=m.SearchStatistics();cfg=EvaluationConfig();profile=EvaluationProfileCache(use_disk=False).get_or_build(c,cfg)[0];evaluator=Evaluator(c,profile,cfg)
   if instrumented:install();meter=Meter()
   t=time.perf_counter()
   try:action,score,pv,reason=m.search.run_root_search(state,c,evaluator,m.TranspositionTable(max_entries=65536),m.SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=2,quiescence_max_depth=1,quiescence_hard_max_depth=4),None,stats,use_tt=True,use_ordering=True,tuning=m.SearchTuning(use_root_tactical=False),_history_witnesses=w,legal_binding_provider=prov)
   finally:
    wall=time.perf_counter()-t;measure=meter.finish() if instrumented else None;restore()
   r['rows'].append(dict(seed=seed,arm=arm,instrumented=instrumented,action=m.m.label(action),score=score,pv=[m.m.label(x) for x in pv],reason=reason,stats=asdict(stats),wall_seconds=wall,measurement=measure));m.write_record(B/'detail.json',r)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started);m.write_record(B/'detail.json',r)
if __name__=='__main__':
 try:main()
 finally:restore();m.ordering.MoveOrderer.order=m.original_order;m.search._order_qactions=m.original_q;m.search._runtime_legal_actions=m.original_legal;m.search.MoveOrderer=m.original_class
