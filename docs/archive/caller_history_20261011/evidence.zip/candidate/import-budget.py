from pathlib import Path
import sys,time,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.evaluation import EvaluationConfig,EvaluationProfileCache,Evaluator
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ui.controller import UIController
from generic_chess.ui.stores import DictSettingsStore
from generic_chess.ui.match import MatchConfig,ParticipantKind
from generic_chess.ai.budget import ThinkingConfig,ThinkingStrategy
from generic_chess.clock import TimeControl,TimeControlMode
from scripts.audit_lichess_complete_children import uci
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=ROOT/'.local_agent/candidate-iteration-20261011'
t=time.perf_counter();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c);roots={0:s.to_record()};cycle=('g1f3','g8f6','f3g1','f6g8')
for p in range(400):stopped();s.submit({uci(a):a for a in s.legal_actions()}[cycle[p%4]])
roots[400]=s.to_record();cache=EvaluationProfileCache(use_disk=False);profile=cache.get_or_build(c,EvaluationConfig())[0];e=Evaluator(c,profile,EvaluationConfig());setup=time.perf_counter()-t
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),setup_seconds=setup,rows=[])
for ply,record in roots.items():
 ss=GameSession.replay(c,record)
 for mode in ('supplied','reconstruct'):
  stopped();stats=SearchStatistics();token=CancellationToken();before=ss.state;start=time.perf_counter()
  a,v,pv,reason=run_root_search(before,c,e,TranspositionTable(65536),SearchLimits(max_depth=12,max_time_seconds=.05,quiescence_max_depth=0,quiescence_hard_max_depth=0),token,stats,use_tt=True,use_ordering=True,_history_witnesses=ss._search_witnesses if mode=='supplied' else None)
  end=time.perf_counter();assert ss.state==before and a in ss.legal_actions()
  r['rows'].append(dict(ply=ply,mode=mode,seconds=end-start,reason=reason,action=uci(a),stats=record_value(stats),root_restored=True,return_legal=True))
 ctrl=UIController(settings=DictSettingsStore());ctrl._session=ss;ctrl._compiled=c
 ctrl.start_match(MatchConfig((ParticipantKind.AI,ParticipantKind.HUMAN),TimeControl(mode=TimeControlMode.NONE),ThinkingConfig(strategy=ThinkingStrategy.FIXED_TIME,move_time_seconds=.05,quiescence_max_depth=0)))
 player=AlphaBetaPlayer(c,evaluator_override=e,use_native_semantic_legality=False);token=CancellationToken();snap=ctrl.capture_ai_search(token);token.cancel();before=ss.state;start=time.perf_counter();d=player.choose_action(ss,snap.limits,cancel_token=token);end=time.perf_counter();committed=ctrl.finish_ai_move(d,snap)
 assert not committed and ss.state==before and d.termination_reason=='cancelled' and d.action in ss.legal_actions()
 r['rows'].append(dict(ply=ply,mode='precancelled-public',seconds=end-start,decision=record_value(d),committed=committed,root_restored=True,return_legal=True))
 write_record(B/'import-budget.json',r)
r['complete']=True;write_record(B/'import-budget.json',r)
for x in r['rows']:print(x['ply'],x['mode'],round(x['seconds'],4),x.get('reason',x.get('decision',{}).get('termination_reason')))
