from pathlib import Path
import sys,time,json,hashlib,random
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution,apply_action
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.identity import position_identity_key
from scripts.audit_lichess_complete_children import uci
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=ROOT/'.local_agent/candidate-iteration-20261011'
class MemoRuntime(SearchPathRuntime):
 def __init__(self,*a,**k):
  self.memo={};super().__init__(*a,**k)
  self.memo_entries=len(self.memo);self.memo_bytes=sys.getsizeof(self.memo)+sum(sys.getsizeof(k)+sys.getsizeof(v) for k,v in self.memo.items());self.memo=None
 def _runtime_hash_for_identity(self,identity):
  if self.memo is None:return super()._runtime_hash_for_identity(identity)
  value=self.memo.get(identity)
  if value is None:value=super()._runtime_hash_for_identity(identity);self.memo[identity]=value
  return value
class CountRuntime(SearchPathRuntime):
 def __init__(self,*a,**k):self.hash_requests=0;super().__init__(*a,**k)
 def _runtime_hash_for_identity(self,identity):self.hash_requests+=1;return super()._runtime_hash_for_identity(identity)
t=time.perf_counter();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c);roots=[('cycle0',s.to_record())];cycle=('g1f3','g8f6','f3g1','f6g8')
for p in range(400):
 stopped();s.submit({uci(a):a for a in s.legal_actions()}[cycle[p%4]])
 if p+1 in (100,400):roots.append(('cycle'+str(p+1),s.to_record()))
rng=random.Random(20261011);s=GameSession(c);seen={position_identity_key(s.state.position,c)}
for p in range(100):
 stopped()
 if s.state.terminal_status.is_terminal:break
 actions=list(s.legal_actions());rng.shuffle(actions);chosen=actions[0]
 for a in actions:
  child=apply_action(s.state,a,c);key=position_identity_key(child.position,c)
  if key not in seen:chosen=a;break
 s.submit(chosen);seen.add(s.state.history[-1].position_key)
roots.append(('novel'+str(s.state.ply_count),s.to_record()))
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),construction_seconds=time.perf_counter()-t,novel_unique_keys=len(seen),rows=[],counters=[])
for name,record in roots:
 s=GameSession.replay(c,record);state=s.state;authority=None
 for mode in ('supplied','reconstruct'):
  kw=dict(history_witnesses=s._search_witnesses) if mode=='supplied' else {}
  counted=CountRuntime.from_state(state,c,**kw);memo=MemoRuntime.from_state(state,c,**kw)
  r['counters'].append(dict(case=name,mode=mode,hash_requests=counted.hash_requests,unique_hashes=memo.memo_entries,owned_cache_bytes=memo.memo_bytes,retained_cache=memo.memo is not None))
  for order,arms in enumerate([('original','memo'),('memo','original')]):
   for arm in arms:
    stopped();start=time.perf_counter();x=(SearchPathRuntime if arm=='original' else MemoRuntime).from_state(state,c,**kw);wall=time.perf_counter()-start
    contract=(x.search_key(),x._history_context,x.tt_eligible,x.terminal_status,x.repetition_counts)
    if authority is None:authority=contract
    assert contract==authority and x.position==state.position
    actions=x.legal_actions()
    for a in actions[:2]:x.push(a);x.pop()
    assert x.search_key()==authority[0] and x.position==state.position;x.assert_balanced()
    r['rows'].append(dict(case=name,mode=mode,order=order,arm=arm,seconds=wall,history_records=len(state.history),witness_hits=x.history_witness_hits,witness_misses=x.history_witness_misses,contract_equal=True,balanced=True,legal_actions=len(actions),memo_entries=getattr(x,'memo_entries',None),memo_bytes=getattr(x,'memo_bytes',None)))
    write_record(B/'history-hash-reuse.json',r)
r.update(complete=True,producer_seconds=time.perf_counter()-t);write_record(B/'history-hash-reuse.json',r)
for x in r['counters']:print(x)
for x in r['rows']:print(x['case'],x['mode'],x['arm'],round(x['seconds'],5))
