Question: does lazy candidate advancement dominate terminal existence after small guard/binding costs?
Frozen input: generated seed2026101103 six-ply prefix, unchanged default product evaluator; three legacy/semantic/hybrid arms; D2/q1 hard4,20k nodes,2s,cold65536TT,ordinary ordering,root tactical off.
Measure only each next/send advancement, restore parent before yielding; nested iteration buckets exclusive. Generator creation/suspension/consumer work not charged to iteration. Preserve exhaustion,throw/close and cancellation.
Nine calls: each arm instrumented, then two controls in reverse order. Own-arm action/value/PV/non-timework must match. Stop60s; no cap expansion.
Outcome: material iteration bucket warrants one scoped traversal hypothesis; tiny residual defers traversal and moves to alternate-history or warm-PV reserve. No cache/order/default/UI change implied.
Incremental cost: one temporary producer and timing validation; <60s compute, engineering/token overhead recorded separately.
