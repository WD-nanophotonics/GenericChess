from pathlib import Path
import sys,time,json,hashlib,random,ast,textwrap,collections
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution,apply_action
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.identity import position_identity_key
from scripts.audit_lichess_complete_children import uci
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=ROOT/'.local_agent/candidate-iteration-20261011'
import generic_chess.core.search_runtime as rm
from generic_chess.core.identity import RuntimeHash
from dataclasses import replace
sys.path.insert(0,str(ROOT/'tests'))
from rule_semantics_ir_fixtures import castling_ruleset,en_passant_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
hits=collections.Counter()
def shadow_hit(runtime,identity,cached,origin):
 direct=(runtime.runtime_hash if runtime._forced_hash is not None else
         rm._full_runtime_hash(identity.position,runtime.compiled)
         if isinstance(identity,rm.RuntimePositionIdentity) else
         rm._token(('imported',rm._identity_sort_key(identity))))
 assert cached==direct,(origin,identity,cached,direct)
 hits[origin]+=1
rm.__dict__['_gc_shadow_import_hit']=shadow_hit
source=Path('generic_chess/core/search_runtime.py').read_text();tree=ast.parse(source);node=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='SearchPathRuntime');ns={}
for fn in node.body:
 if isinstance(fn,ast.FunctionDef) and fn.name in ('__init__','_seed_occurrences'):
  code=textwrap.dedent('\n'.join(source.splitlines()[fn.lineno-1:fn.end_lineno]))
  if fn.name=='__init__':
   code=code.replace('            if runtime_hash is None:', "            if runtime_hash is not None:\n                _gc_shadow_import_hit(self, identity, runtime_hash, 'root-record' if record.position_key == self._external_root_key else 'record-record')\n            if runtime_hash is None:",1)
  else:
   code=code.replace('    if runtime_hash is None:', "    if runtime_hash is not None:\n        _gc_shadow_import_hit(self, identity, runtime_hash, 'root-seed' if key == self._external_root_key else 'record-seed')\n    if runtime_hash is None:",1)
  exec(code,rm.__dict__,ns)
class ShadowRuntime(SearchPathRuntime):
 __init__=ns['__init__']
 _seed_occurrences=ns['_seed_occurrences']

class MemoRuntime(SearchPathRuntime):
 def __init__(self,*a,**k):
  self.memo={};super().__init__(*a,**k)
  self.memo_entries=len(self.memo);self.memo_bytes=sys.getsizeof(self.memo)+sum(sys.getsizeof(k)+sys.getsizeof(v) for k,v in self.memo.items());self.memo=None
 def _runtime_hash_for_identity(self,identity):
  if self.memo is None:return super()._runtime_hash_for_identity(identity)
  value=self.memo.get(identity)
  if value is None:value=super()._runtime_hash_for_identity(identity);self.memo[identity]=value
  return value
class CountRuntime(SearchPathRuntime):
 def __init__(self,*a,**k):self.hash_requests=0;super().__init__(*a,**k)
 def _runtime_hash_for_identity(self,identity):self.hash_requests+=1;return super()._runtime_hash_for_identity(identity)
t=time.perf_counter();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c);roots=[('cycle0',s.to_record())];cycle=('g1f3','g8f6','f3g1','f6g8')
for p in range(400):
 stopped();s.submit({uci(a):a for a in s.legal_actions()}[cycle[p%4]])
 if p+1 in (100,400):roots.append(('cycle'+str(p+1),s.to_record()))
rng=random.Random(20261011);s=GameSession(c);seen={position_identity_key(s.state.position,c)}
for p in range(100):
 stopped()
 if s.state.terminal_status.is_terminal:break
 actions=list(s.legal_actions());rng.shuffle(actions);chosen=actions[0]
 for a in actions:
  child=apply_action(s.state,a,c);key=position_identity_key(child.position,c)
  if key not in seen:chosen=a;break
 s.submit(chosen);seen.add(s.state.history[-1].position_key)
roots.append(('novel'+str(s.state.ply_count),s.to_record()))
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),installed_sha256=hashlib.sha256(Path('generic_chess/core/search_runtime.py').read_bytes()).hexdigest(),performance_claim=False,rows=[])
for name,record in roots:
 ss=GameSession.replay(c,record)
 for mode in ('supplied','reconstruct'):
  for forced in (None,RuntimeHash(7,11)):
   kw=dict(history_witnesses=ss._search_witnesses if mode=='supplied' else None,hash_override=forced)
   before=dict(hits);left=SearchPathRuntime.from_state(ss.state,c,**kw);right=ShadowRuntime.from_state(ss.state,c,**kw)
   assert left.search_key()==right.search_key() and left._history_context==right._history_context and right.position==ss.state.position
   for a in right.legal_actions()[:2]:right.push(a);right.pop()
   right.assert_balanced();assert left.search_key()==right.search_key()
   r['rows'].append(dict(case=name,mode=mode,forced=forced is not None,hits={k:hits[k]-before.get(k,0) for k in hits},full_contract_equal=True))
for kind in ('castling','castling_zero','en_passant'):
 rules=en_passant_ruleset() if kind=='en_passant' else castling_ruleset()
 if kind=='castling_zero':rules=replace(rules,semantic_actions=tuple(replace(a,aux_state=tuple(replace(x,initial=0) for x in a.aux_state)) for a in rules.semantic_actions))
 cc=compile_semantic_ruleset(rules);ss=GameSession(cc);state=ss.state
 entries=tuple(sorted(((x.slot_id,o),x.initial) for x in cc.ir.aux_slots for o in ((-1,) if x.scope=='global' else (0,1))))
 for explicit in (False,True):
  st=replace(state,position=replace(state.position,aux_state=entries)) if explicit else state
  for supplied in (False,True):
   for forced in (None,RuntimeHash(7,11)):
    x=ShadowRuntime.from_state(st,cc,history_witnesses=(st.position,) if supplied else None,hash_override=forced)
    assert x.tt_eligible and x.history_witness_misses==0;x.assert_balanced()
    r['rows'].append(dict(case=kind,explicit=explicit,supplied=supplied,forced=forced is not None,full_contract_equal=True))
r.update(complete=True,hits=dict(hits),producer_seconds=time.perf_counter()-t);assert all(hits[k]>0 for k in ('root-record','record-record','record-seed','root-seed'));write_record(B/'history-hash-shadow.json',r);print(json.dumps(dict(rows=len(r['rows']),hits=dict(hits),seconds=r['producer_seconds'])))
