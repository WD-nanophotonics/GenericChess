from pathlib import Path
import sys,json,time
from dataclasses import replace,asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));B=ROOT/'.local_agent/candidate-iteration-20261011'
from conftest import king_type,T,make_ruleset
from generic_chess import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution,initial_state,legal_actions,apply_action
from generic_chess.core.movement import RayAtom
from generic_chess.rules.schema import RuleInitialSetupOption
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record
from scripts.reserve_refresh_diagnostic import stopped
import importlib.util
spec=importlib.util.spec_from_file_location('gs',ROOT/'.local_agent/eager-binding-20261011/generated-search.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def visible(a):
 src=getattr(a,'from_square',None);dst=a.to_square
 return ((src.file,src.rank) if src else None,(dst.file,dst.rank),getattr(a,'promotion_target_id',None),getattr(a,'base_type_id',None))
def snap(rt):return (rt.position,rt.ply_count,rt.runtime_hash,tuple(rt.history),rt.repetition_counts,rt.terminal_status,rt.search_key())
def main():
 started=time.perf_counter();types=[king_type(),T('R',*(RayAtom(d) for d in ((1,0),(-1,0),(0,1),(0,-1))))]
 base=make_ruleset(4,types,lines=['...k','....','.R..','K...'],repetition_limit=3)
 alt=make_ruleset(4,types,lines=['...k','..R.','....','K...'],repetition_limit=3)
 rules=replace(base,initial_setup_options=(RuleInitialSetupOption('checking-cycle',alt.initial_position),),repetition_policy='continuous_check_loss')
 moves=(((2,2),(3,2)),((3,3),(2,3)),((3,2),(2,2)),((2,3),(3,3)))*2
 r=dict(complete=False,declaration=(B/'history-cycle-plan.md').read_text(),rows=[],searches=[])
 for arm,c in [('legacy',compile_ruleset_for_execution(rules)),('semantic',compile_legacy_ruleset_for_semantic_execution(rules))]:
  state=initial_state(c,'checking-cycle');w=[state.position]
  for ply in range(9):
   stopped();assert time.perf_counter()-started<60
   rt=SearchPathRuntime.from_state(state,c);supplied=SearchPathRuntime.from_state(state,c,history_witnesses=tuple(w))
   assert rt.position==supplied.position==state.position;assert rt.terminal_status==supplied.terminal_status==state.terminal_status
   assert rt.tt_eligible and supplied.tt_eligible;assert rt.search_key()==supplied.search_key();assert tuple(rt.history)==tuple(supplied.history)
   row=dict(arm=arm,ply=ply,terminal=asdict(state.terminal_status),checks=[h.gave_check for h in state.history],actors=[h.actor for h in state.history],occurrences=rt.occurrence_count(),history_complete=rt._history_complete,tt_eligible=rt.tt_eligible,attempts=rt.history_reconstruction_attempts,key_computations=rt.history_reconstruction_key_computations)
   if ply<8:
    src,dst=moves[ply];action=next(a for a in legal_actions(state,c) if visible(a)[:2]==(src,dst));child=apply_action(state,action,c);before=snap(rt)
    with rt.pushed(action):
     assert rt.position==child.position;assert rt.terminal_status==child.terminal_status;row['next_terminal']=asdict(rt.terminal_status);row['next_check']=rt.history[-1].gave_check
    assert snap(rt)==before;rt.assert_balanced()
   r['rows'].append(row)
   if ply in (3,7):
    for witness in (False,True):
     for tt in (False,True):
      stats=SearchStatistics();t=time.perf_counter();action,score,pv,reason=run_root_search(state,c,m.Material(types),TranspositionTable(max_entries=4096),SearchLimits(max_depth=2,max_nodes=10000,max_time_seconds=2,quiescence_max_depth=0),None,stats,use_tt=tt,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=tuple(w) if witness else None,require_full_pv=True)
      r['searches'].append(dict(arm=arm,ply=ply,witness=witness,tt=tt,action=m.label(action),score=score,pv=[m.label(a) for a in pv],reason=reason,stats=asdict(stats),wall_seconds=time.perf_counter()-t))
   if ply<8:state=child;w.append(state.position)
   write_record(B/'history-cycle.json',r)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started);write_record(B/'history-cycle.json',r)
if __name__=='__main__':main()
