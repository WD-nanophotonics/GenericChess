from pathlib import Path
import sys,time,json,hashlib
from dataclasses import replace,asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import chess
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.config import EvaluationConfig,config_hash
from generic_chess.ai.evaluation.profile import PieceValueProfile,RuleSetEvaluationProfile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.identity import position_identity_key
from generic_chess.ai.budget import ThinkingConfig,ThinkingStrategy
from generic_chess.clock import TimeControl,TimeControlMode
from generic_chess.ui.match import MatchConfig,ParticipantKind
from generic_chess.ui.controller import UIController
from generic_chess.ui.stores import DictSettingsStore
from scripts.search_backend_comparison import CoreBoard,ChessBoard,iterative_minimal,audit_pair,uci
from scripts.research_record import record_value,write_record
B=ROOT/'.local_agent/candidate-iteration-20261011'
from scripts.reserve_refresh_diagnostic import make_refresh,ORIGINAL
from generic_chess.ai.alphabeta import player as pm
source=ROOT/'.local_agent/ui-product-20261010/replay-frozen.json'
old=json.loads(source.read_bytes())['roots'][0]
case=dict(id='old-white-queen-ply5',game='chess',setup='start',moves=' '.join(old['moves']))
values=old['original']['material']
names=dict(P=chess.PAWN,N=chess.KNIGHT,B=chess.BISHOP,R=chess.ROOK,Q=chess.QUEEN,K=chess.KING)
labels={x['move']:x for x in old['material_root_children']}
assert len(labels)==43 and old['ply']==5
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
def evaluator(compiled):
 gains={pt.type_id:max(0,max((values[t] for t in pt.promotion_target_ids),default=0)-values[pt.type_id]) for pt in compiled.piece_types}
 profile=RuleSetEvaluationProfile(compiled.ruleset_fingerprint,1,'ui-human-teaching-v1',config_hash(config),
 {pt.type_id:PieceValueProfile(pt.type_id,'human-teaching-v1',0.,values[pt.type_id],values[pt.type_id],gains[pt.type_id],0.,0.,pt.is_anchor,pt.is_promotable) for pt in compiled.piece_types},3000,values,values,gains)
 return Evaluator(compiled,profile,config)
def core():
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
 b=CoreBoard(case,c);b.material.values=values
 return b

def specialized():
 b=ChessBoard(case);b.values={names[k]:v for k,v in values.items()};return b

def stopped():
 for n in ('rollout','advisor','slack'):
  d=json.loads((ROOT/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('stopped') or d.get('user_paused'):raise RuntimeError('project stopped')
report=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),old_record_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),case=case,material=values,evaluation=asdict(config),reference=old['minimal_D2'],rows=[])
a=core();b=specialized();e=evaluator(a.compiled)
report['audited_states']=audit_pair(a,b,1)
checks=0
for label,action in [(None,None)]+a.actions():
 if action is not None:a.push(action)
 try:
  assert e.evaluate(a.runtime.state)==a.evaluate();checks+=1
 finally:
  if action is not None:a.pop()
report['actual_evaluator_parity_states']=checks
assert a.restored();write_record(B/'queen-schedule-deadline-final.json',report)
for order,arms in enumerate([['q4','q0','phase_bypass'],['phase_bypass','q0','q4']]):
 for arm in arms:
  stopped();start=time.perf_counter()
  if arm in ('q4','q0','phase_bypass'):
   board=core();compiled=board.compiled
   session=GameSession(compiled)
   for label in case['moves'].split():session.submit({uci(x):x for x in session.legal_actions()}[label])
   assert position_identity_key(session.state.position,compiled)==position_identity_key(board.initial.position,compiled)
   assert session.state.history==board.initial.history and session.state.ply_count==board.initial.ply_count
   report["root_contract"]={"physical_position_equal":session.state.position==board.initial.position,"canonical_position_equal":True,"note":"Session sparse initial aux equals Core explicit castling defaults; no semantic/history mismatch","session_history":record_value(session.state.history),"core_history":record_value(board.initial.history)}
   ctrl=UIController(settings=DictSettingsStore());ctrl._session=session;ctrl._compiled=compiled
   ctrl.start_match(MatchConfig((ParticipantKind.AI,ParticipantKind.HUMAN),TimeControl(mode=TimeControlMode.NONE),ThinkingConfig(strategy=ThinkingStrategy.FIXED_TIME,move_time_seconds=1.0,quiescence_max_depth=0 if arm=='q0' else 4)))
   player=AlphaBetaPlayer(compiled,evaluator_override=evaluator(compiled),use_native_semantic_legality=False)
   token=CancellationToken();snapshot=ctrl.capture_ai_search(token);assert snapshot is not None
   prepared=time.perf_counter();remaining=max(0.000001,1-(prepared-start))
   limits=replace(snapshot.limits,max_time_seconds=remaining)
   original=session.state;witnesses=session._search_witnesses
   events=[]
   pm.run_root_search=make_refresh(events,expected_state=original,tt_policy='phase_bypass') if arm=='phase_bypass' else ORIGINAL
   try:decision=player.choose_action(session,limits,cancel_token=token)
   finally:pm.run_root_search=ORIGINAL
   assert len({x['budget_identity'] for x in events})<=1 and len({x['deadline'] for x in events})<=1
   searched=time.perf_counter();assert session.state==original and session._search_witnesses==witnesses
   move=uci(decision.action) if decision.action is not None else None
   committed=ctrl.finish_ai_move(decision,snapshot)
   assert committed and ctrl.history_entries()[-1].action==decision.action
   endpoint=time.perf_counter()
   result=dict(move=move,completed_depth=decision.completed_depth,score=decision.score,reason=decision.termination_reason,decision=record_value(decision),limits=asdict(limits),snapshot_limits=asdict(snapshot.limits),committed=committed,root_restored=True,backend='Core;Native disabled',cold_tt=True,events=events,returned_source=('completed_refresh' if any(x['phase']=='complete' for x in events) and decision.completed_depth==1 else 'completed_main'),work_definition='product main+q recursive visits; unlike minimal nodes')
  else:
   board=core() if arm=='minimal_core' else specialized()
   prepared=time.perf_counter();remaining=max(0.000001,1-(prepared-start))
   result=iterative_minimal(board,seconds=remaining)
   searched=time.perf_counter();assert board.restored()
   moves=dict(board.actions());assert result['move'] in moves
   board.push(moves[result['move']]);board.pop();assert board.restored()
   endpoint=time.perf_counter()
   result.update(backend='Core' if arm=='minimal_core' else 'python-chess',committed=False,return_verified=True,root_restored=True,limits=dict(seconds=remaining,node_limit=1000000,max_depth=12),work_definition='minimal recursive visits including root/leaves across iterative depths')
  label=labels[result['move']]
  result.update(order=order,arm=arm,prepare_seconds=prepared-start,search_seconds=searched-prepared,return_seconds=endpoint-searched,caller_seconds=endpoint-start,caller_overrun_seconds=max(0,endpoint-start-1),finite_D2_action_value=None if label['worst'] is None else label['worst']['score'],finite_D2_worst_reply=None if label['worst'] is None else label['worst']['reply'])
  report['rows'].append(result);write_record(B/'queen-schedule-deadline-final.json',report)
  print(arm,order,result['move'],result['completed_depth'],result['finite_D2_action_value'],round(result['caller_seconds'],4),flush=True)
report['complete']=True;write_record(B/'queen-schedule-deadline-final.json',report)
