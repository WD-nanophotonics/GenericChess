from pathlib import Path
import sys,time,json,importlib.util,functools
from dataclasses import asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/candidate-iteration-20261011';OLD=ROOT/'.local_agent/eager-binding-20261011'
spec=importlib.util.spec_from_file_location('qi',OLD/'q-identity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess.core import search_runtime as sr
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.evaluation import EvaluationConfig, EvaluationProfileCache, Evaluator
patches=[]
class Meter:
 def __init__(self):self.current='search_other';self.last=time.perf_counter();self.cost={};self.calls={};self.start=self.last
 def switch(self,new):
  now=time.perf_counter();self.cost[self.current]=self.cost.get(self.current,0)+now-self.last;self.last=now;previous=self.current;self.current=new;return previous
 def finish(self):self.switch('done');return dict(exclusive_seconds=self.cost,calls=self.calls,elapsed_seconds=self.last-self.start,sum_seconds=sum(self.cost.values()))
meter=None
def wrap(obj,name,tag):
 fn=getattr(obj,name)
 @functools.wraps(fn)
 def wrapped(*args,**kwargs):
  chosen=tag(meter.current) if callable(tag) else tag;previous=meter.switch(chosen);meter.calls[chosen]=meter.calls.get(chosen,0)+1
  try:return fn(*args,**kwargs)
  finally:meter.switch(previous)
 patches.append((obj,name,fn));setattr(obj,name,wrapped)

def wrap_generator(obj,name,tag):
 fn=getattr(obj,name)
 class TimedIterator:
  def __init__(self,inner):self.inner=inner
  def __iter__(self):return self
  def advance(self,method,*args):
   parent=meter.current;chosen=tag(parent);previous=meter.switch(chosen)
   meter.calls[chosen]=meter.calls.get(chosen,0)+1
   try:return getattr(self.inner,method)(*args)
   finally:meter.switch(previous)
  def __next__(self):return self.advance('__next__')
  def send(self,value):return self.advance('send',value)
  def throw(self,*args):return self.advance('throw',*args)
  def close(self):return self.advance('close')
 @functools.wraps(fn)
 def wrapped(*args,**kwargs):return TimedIterator(fn(*args,**kwargs))
 patches.append((obj,name,fn));setattr(obj,name,wrapped)

def install():
 for name in ('_iter_candidates','_iter_board_candidates','_iter_drop_candidates','iter_legal_action_bindings','iter_legal_actions'):
  wrap_generator(SemanticEngine,name,lambda parent,n=name: 'terminal_iteration'+n if parent.startswith('terminal_') else parent)
 wrap(SemanticEngine,'_make_binding',lambda parent:'terminal_binding' if parent.startswith('terminal_') else parent)
 wrap(SemanticEngine,'has_legal_action','terminal_exists')
 wrap(SemanticEngine,'_guards_hold',lambda parent:'terminal_guards' if parent.startswith('terminal_') else parent)
 wrap(SemanticEngine,'_trial_child_if_s3_legal',lambda parent:'terminal_trial' if parent.startswith('terminal_') else parent)
 wrap(Evaluator,'evaluate','product_evaluation')
 wrap(Evaluator,'_attack_maps','evaluation_attack_maps')
 wrap(sr.SearchPathRuntime,'legal_actions','search_legality')
 wrap(sr,'terminal_from_search_runtime','core_terminal')
 wrap(sr.SearchPathRuntime,'_gave_check','check_query');wrap(sr.SearchPathRuntime,'in_check','check_query')
 wrap(sr,'_apply_action_unchecked','legacy_search_transition')
 wrap(SemanticEngine,'_transition',lambda parent:'semantic_trial_transition' if parent in ('search_legality','core_terminal','terminal_trial','terminal_exists') or parent.startswith('terminal_iteration') else 'semantic_search_transition')
 for name in ('_semantic_component_diff_hash','_legacy_incremental_hash','_full_runtime_hash'):wrap(sr,name,'component_hash')
 for name in ('_occurrence_add','_occurrence_remove','_find_occurrence'):wrap(sr.SearchPathRuntime,name,'history_occurrences')
 wrap(sr.RuntimeCountsSnapshot,'updated','history_snapshot')
 wrap(sr.RuntimeHistoryContext,'append','history_context')
 wrap(NativeSemanticLegalityProvider,'__call__','native_provider')
 wrap(NativeSemanticLegalityProvider,'_state_only_payload','native_state_payload')
 wrap(NativeSemanticLegalityProvider,'_decode_action','native_decode_action')
 wrap(SemanticEngine,'_make_binding_from_action',lambda parent:'native_validate_binding' if parent=='native_provider' else parent)
def restore():
 while patches:
  obj,name,fn=patches.pop();setattr(obj,name,fn)
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.session.session import GameSession

def main():
 started=time.perf_counter();r=dict(complete=False,declaration=(B/'caller-plan.md').read_text(),rows=[])
 for seed in (2026101103,2026101104):
  g=m.generate_game(m.GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));old=g.compiled_ruleset;new=m.compile_legacy_ruleset_for_semantic_execution(g.ruleset);a,b=GameSession(old),GameSession(new)
  for ply in range(6):
   aa,bb=m.groups(a.state,old),m.groups(b.state,new);k=sorted(aa,key=lambda x:repr((getattr(aa[x][0],'from_square',None),aa[x][0].to_square,getattr(aa[x][0],'promotion_target_id',None),getattr(aa[x][0],'base_type_id',None))))[(seed+ply)%len(aa)];a.submit(aa[k][0]);b.submit(bb[k][0])
  for arm,c,initial,native in [('legacy',old,a,False),('semantic',new,b,False),('hybrid',new,b,True)]:
   session=GameSession.from_record(initial.to_record(),c);player=AlphaBetaPlayer(c,use_disk_cache=False,tt_max_entries=65536,use_native_semantic_legality=native);clears=[0];original_clear=player._tt.clear
   def tracked_clear():clears[0]+=1;return original_clear()
   player._tt.clear=tracked_clear
   for turn,q in enumerate((0,1,0,0)):
    m.stopped();assert time.perf_counter()-started<60;before=session.state;t=time.perf_counter();decision=player.choose_action(session,m.SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=1,quiescence_max_depth=q,quiescence_hard_max_depth=4));wall=time.perf_counter()-t;assert session.state==before;assert decision.action in session.legal_actions();assert clears[0]==min(turn+1,3)
    row=dict(seed=seed,arm=arm,turn=turn,q=q,decision=asdict(decision),action=m.m.label(decision.action),pv=[m.m.label(x) for x in decision.principal_variation],tt_clear_calls=clears[0],tt_entries=len(player._tt),tt_generation=player._tt.generation,wall_seconds=wall,provider_available=player.native_legality_provider is not None)
    current=before
    for act in decision.principal_variation:assert act in m.legal_actions(current,c);current=m.apply_action(current,act,c)
    if turn>=2:
     expected=m.apply_action(before,decision.action,c);session.submit(decision.action);assert session.state==expected;replayed=GameSession.from_record(session.to_record(),c);assert replayed.state==session.state;assert replayed._search_witnesses==session._search_witnesses;row['committed_record_replayed']=True
    r['rows'].append(row);m.write_record(B/'caller.json',r)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-started);m.write_record(B/'caller.json',r)
if __name__=='__main__':main()
