from pathlib import Path
import sys,time,json,hashlib
from dataclasses import replace,asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import generate_game,GeneratorConfig,compile_legacy_ruleset_for_semantic_execution,legal_actions,apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation import EvaluationConfig,EvaluationProfileCache,Evaluator
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.budget import ThinkingConfig,ThinkingStrategy
from generic_chess.clock import TimeControl,TimeControlMode
from generic_chess.ui.match import MatchConfig,ParticipantKind
from generic_chess.ui.controller import UIController
from generic_chess.ui.stores import DictSettingsStore
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=ROOT/'.local_agent/candidate-iteration-20261011'
def label(a):
 src=getattr(a,'from_square',None);dst=a.to_square
 return json.dumps([None if src is None else [src.file,src.rank],[dst.file,dst.rank],getattr(a,'promotion_target_id',None),getattr(a,'base_type_id',None)],separators=(',',':'))
def groups(state,c):
 out={}
 for a in legal_actions(state,c):out.setdefault(label(a),[]).append(a)
 return out
started=time.perf_counter();seed=2026101103
g=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='free_random',movement_symmetry='none',allow_hybrid=True));generated=time.perf_counter()
old=g.compiled_ruleset;new=compile_legacy_ruleset_for_semantic_execution(g.ruleset);compiled_at=time.perf_counter();a,b=GameSession(old),GameSession(new)
for ply in range(6):
 aa,bb=groups(a.state,old),groups(b.state,new);assert set(aa)==set(bb)
 k=sorted(aa,key=lambda x:repr((getattr(aa[x][0],'from_square',None),aa[x][0].to_square,getattr(aa[x][0],'promotion_target_id',None),getattr(aa[x][0],'base_type_id',None))))[(seed+ply)%len(aa)];a.submit(aa[k][0]);b.submit(bb[k][0])
assert a.state.position==b.state.position
cfg=EvaluationConfig();profiles={};caches={};setup=[]
for name,c in [('legacy',old),('semantic',new)]:
 cache=EvaluationProfileCache(use_disk=False);t=time.perf_counter();profile=cache.get_or_build(c,cfg)[0];wall=time.perf_counter()-t;profiles[name]=profile;caches[name]=cache;setup.append(dict(arm=name,prebuilt_warm_profile_seconds=wall))
ee=[Evaluator(old,profiles['legacy'],cfg),Evaluator(new,profiles['semantic'],cfg)]
parity=0
for key in [None]+sorted(groups(a.state,old)):
 states=[a.state,b.state] if key is None else [apply_action(x.state,groups(x.state,x.compiled)[key][0],x.compiled) for x in (a,b)]
 assert ee[0].evaluate(states[0])==ee[1].evaluate(states[1]);parity+=1
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seed=seed,ply=6,generation_seconds=generated-started,explicit_compile_seconds=compiled_at-generated,warm_profile_setup=setup,evaluator_parity_states=parity,rows=[])
for mode in ('cold','warm'):
 for order,arms in enumerate([['legacy','semantic','hybrid'],['hybrid','semantic','legacy']]):
  for arm in arms:
   stopped();start=time.perf_counter();c=old if arm=='legacy' else new;initial=a if arm=='legacy' else b
   session=GameSession.replay(c,initial.to_record());replayed=time.perf_counter();ctrl=UIController(settings=DictSettingsStore());ctrl._session=session;ctrl._compiled=c
   owner=session.state.position.side_to_move
   ctrl.start_match(MatchConfig(tuple(ParticipantKind.AI if x==owner else ParticipantKind.HUMAN for x in (0,1)),TimeControl(mode=TimeControlMode.NONE),ThinkingConfig(strategy=ThinkingStrategy.FIXED_TIME,move_time_seconds=1,quiescence_max_depth=1)))
   cache=EvaluationProfileCache(use_disk=False) if mode=='cold' else caches['legacy' if arm=='legacy' else 'semantic']
   built=time.perf_counter();player=AlphaBetaPlayer(c,profile_cache=cache,use_disk_cache=False,use_native_semantic_legality=arm=='hybrid',tt_max_entries=65536);player_ready=time.perf_counter()
   if arm=='hybrid':assert player.native_legality_provider is not None
   token=CancellationToken();snapshot=ctrl.capture_ai_search(token);assert snapshot is not None
   prepared=time.perf_counter();limits=replace(snapshot.limits,max_time_seconds=max(.000001,1-(prepared-start)),quiescence_hard_max_depth=4)
   before=session.state;witnesses=session._search_witnesses;d=player.choose_action(session,limits,cancel_token=token);searched=time.perf_counter();assert session.state==before and session._search_witnesses==witnesses
   current=before
   for action in d.principal_variation:assert action in legal_actions(current,c);current=apply_action(current,action,c)
   committed=ctrl.finish_ai_move(d,snapshot);assert committed and ctrl.history_entries()[-1].action==d.action
   endpoint=time.perf_counter();replay=GameSession.replay(c,session.to_record());assert replay.state==session.state and replay._search_witnesses==session._search_witnesses
   r['rows'].append(dict(mode=mode,order=order,arm=arm,replay_seconds=replayed-start,player_setup_seconds=player_ready-built,prepare_seconds=prepared-start,search_seconds=searched-prepared,return_seconds=endpoint-searched,caller_seconds=endpoint-start,caller_overrun_seconds=max(0,endpoint-start-1),limits=asdict(limits),decision=record_value(d),move=label(d.action),pv=[label(x) for x in d.principal_variation],cache_hit=player.evaluation_profile_cache_hit,committed=committed,record_replayed=True))
   write_record(B/'generated-caller-budget-deadline-final.json',r);print(mode,arm,order,d.completed_depth,round(prepared-start,3),round(endpoint-start,3),d.termination_reason,flush=True)
r.update(complete=True,producer_seconds=time.perf_counter()-started);write_record(B/'generated-caller-budget-deadline-final.json',r)
