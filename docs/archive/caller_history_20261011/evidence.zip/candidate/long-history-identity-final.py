from pathlib import Path
import sys,time,json,hashlib
from dataclasses import asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation import EvaluationConfig,EvaluationProfileCache,Evaluator
from scripts.audit_lichess_complete_children import uci
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=ROOT/'.local_agent/candidate-iteration-20261011'
start=time.perf_counter();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c);roots={0:s.to_record()};states={0:s.state};witnesses={0:s._search_witnesses}
cycle=('g1f3','g8f6','f3g1','f6g8')
for ply in range(400):
 stopped();s.submit({uci(a):a for a in s.legal_actions()}[cycle[ply%4]])
 if ply+1 in (100,400):roots[ply+1]=s.to_record();states[ply+1]=s.state;witnesses[ply+1]=s._search_witnesses
construction=time.perf_counter()-start
cache=EvaluationProfileCache(use_disk=False);cache.get_or_build(c,EvaluationConfig())
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),construction_seconds=construction,cycle=cycle,rows=[],searches=[])
for ply,state in states.items():
 authority=None
 for order,modes in enumerate([('supplied','reconstruct'),('reconstruct','supplied')]):
  for mode in modes:
   stopped();t=time.perf_counter();runtime=SearchPathRuntime.from_state(state,c,history_witnesses=witnesses[ply] if mode=='supplied' else None);wall=time.perf_counter()-t
   key=runtime.search_key();data=(key,runtime._history_context,runtime.tt_eligible,runtime.terminal_status,runtime.repetition_counts)
   if authority is None:authority=data
   assert runtime.state.position==state.position and runtime.depth==0
   equal=data==authority
   assert equal, (ply,mode)
   r['rows'].append(dict(ply=ply,order=order,mode=mode,wall_seconds=wall,history_records=len(state.history),witness_hits=runtime.history_witness_hits,witness_misses=runtime.history_witness_misses,reconstruction_attempts=runtime.history_reconstruction_attempts,reconstruction_keys=runtime.history_reconstruction_key_computations,tt_eligible=runtime.tt_eligible,authority_equal=equal,search_key_equal=key==authority[0],terminal=record_value(runtime.terminal_status),full_runtime_hash=None,occurrence_counts=record_value(runtime.repetition_counts)))
   write_record(B/'long-history-identity-final.json',r);print(ply,mode,order,round(wall,4),flush=True)
 t=time.perf_counter();session=GameSession.replay(c,roots[ply]);prepared=time.perf_counter();player=AlphaBetaPlayer(c,profile_cache=cache,use_disk_cache=False,use_native_semantic_legality=False)
 d=player.choose_action(session,SearchLimits(max_depth=2,max_time_seconds=max(.000001,1-(time.perf_counter()-t)),quiescence_max_depth=0,quiescence_hard_max_depth=0));end=time.perf_counter()
 assert session.state==state and d.action in session.legal_actions()
 verified=time.perf_counter()
 r['searches'].append(dict(ply=ply,decision=record_value(d),choose_return_seconds=end-t,caller_seconds=verified-t,verify_seconds=verified-end,replay_seconds=prepared-t,return_legal=True,root_restored=True));write_record(B/'long-history-identity-final.json',r)
r.update(complete=True,producer_seconds=time.perf_counter()-start);write_record(B/'long-history-identity-final.json',r)
