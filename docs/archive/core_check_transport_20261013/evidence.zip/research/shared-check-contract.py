from pathlib import Path
import sys,importlib.util,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from phase19c1_native_semantic_fixtures import semantic_corpus
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.position import Position,Hands
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from generic_chess.native import semantic as ns
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
spec=importlib.util.spec_from_file_location('shared',Path(__file__).with_name('shared-check-consumer.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=Path(__file__).parent/'shared-check-contract-result.json'
if out.exists():raise RuntimeError('frozen output exists')
rows=[];t=time.perf_counter()
for name,c in semantic_corpus():
 board=tuple(piece for row in c.support.initial_position for piece in row);pos=Position(board,(Hands.empty(),Hands.empty()),0,c.support.ruleset_fingerprint);engine=SemanticEngine(c);consumer=m.SharedCheckAvailability(c)
 for ply in range(6):
  expected=engine.in_check(pos,pos.side_to_move);actual=consumer.check(pos);assert actual==expected,(name,ply)
  avail=consumer.for_position(pos);assert avail==engine.has_legal_action(pos);assert consumer.pending_pack is None and consumer.pending_position is None
  fallback=consumer.for_position(pos);assert fallback==avail
  rows.append(dict(fixture=name,ply=ply,check=actual,has_legal=avail,shared_hits=consumer.shared_import_hits))
  actions=sorted(engine.legal_actions(pos),key=repr)
  if not actions:break
  pos=engine.apply(pos,actions[0])
# The failure path is tested through the actual runtime push rollback boundary.
name,c=next((name,c) for name,c in semantic_corpus() if m.SharedCheckAvailability(c).provider is not None);state=GameSession(c).state
failures=[];oldcheck=SearchPathRuntime._gave_check
for stage in ['check','availability','check_checkpoint','availability_checkpoint']:
 consumer=m.SharedCheckAvailability(c);rt=SearchPathRuntime(state,c,availability_provider=consumer.for_position);actions=rt.legal_actions();before=p.runtime_state(rt);original=ns.in_check if stage=='check' else ns.has_legal_action
 def failed(*args,**kw):raise RuntimeError('injected-'+stage)
 def cancel():raise RuntimeError('injected-'+stage)
 def callback(rt,pos,checkpoint=None):return consumer.check(pos,cancel if stage=='check_checkpoint' else checkpoint)
 try:
  SearchPathRuntime._gave_check=callback
  if stage=='check':ns.in_check=failed
  elif stage=='availability':ns.has_legal_action=failed
  elif stage=='availability_checkpoint':
   original_avail=consumer.for_position
   rt.availability_provider=lambda pos,checkpoint=None:original_avail(pos,cancel)
  try:rt.push(actions[0])
  except RuntimeError as e:assert str(e)=='injected-'+stage
  else:raise AssertionError('injection not reached '+stage)
  rt.assert_balanced();assert p.runtime_state(rt)==before
  failures.append(dict(stage=stage,restored=True))
 finally:
  SearchPathRuntime._gave_check=oldcheck
  if stage=='check':ns.in_check=original
  elif stage=='availability':ns.has_legal_action=original
write_record(out,dict(states=len(rows),rows=rows,failures=failures,seconds=time.perf_counter()-t,scope='Same child check/availability fullstate and checkpoint/queryfailure rollback; no arbitrary malformed-input/error-stage or whole genericdomain proof. Production unchanged.'))
print(len(rows),failures)
