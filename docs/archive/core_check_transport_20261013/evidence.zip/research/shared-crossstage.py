from pathlib import Path
import sys,importlib.util,json
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from phase19c1_native_semantic_fixtures import semantic_corpus
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core import search_runtime as rm
from generic_chess.session.session import GameSession
from generic_chess.core.actions import PassAction
from generic_chess.core.terminal import TerminalStatus
from test_generic_consecutive_action_adjudication import _compiled
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
spec=importlib.util.spec_from_file_location('shared',Path(__file__).with_name('shared-check-consumer.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
name,c=next((name,c) for name,c in semantic_corpus() if m.SharedCheckAvailability(c).provider is not None);state=GameSession(c).state
oldcheck=SearchPathRuntime._gave_check;oldidentity=rm._runtime_position_identity;rows=[]
consumer=m.SharedCheckAvailability(c);rt=SearchPathRuntime(state,c,availability_provider=consumer.for_position);action=rt.legal_actions()[0];before=p.runtime_state(rt)
def checked(rt,pos,checkpoint=None):return consumer.check(pos,checkpoint)
def failidentity(*args,**kw):raise RuntimeError('history-stage-after-check')
try:
 SearchPathRuntime._gave_check=checked;rm._runtime_position_identity=failidentity
 try:rt.push(action)
 except RuntimeError as e:assert str(e)=='history-stage-after-check'
 else:raise AssertionError('fault not reached')
 rt.assert_balanced();assert p.runtime_state(rt)==before
 assert consumer.pending_pack is not None and consumer.pending_position is not None
 stale=consumer.pending_position;before_hits=consumer.shared_import_hits
 value=consumer.for_position(stale);assert consumer.shared_import_hits==before_hits+1
 assert consumer.pending_position is None and consumer.pending_pack is None
 consumer.for_position(stale);assert consumer.shared_import_hits==before_hits+1
 rows.append(dict(case='identityfailure_after_successfulcheck',core_restored=True,external_pending_survives=True,same_stale_position_consumed_once=True,second_query_cold=True,value=value))
finally:SearchPathRuntime._gave_check=oldcheck;rm._runtime_position_identity=oldidentity
# Existing actual early DRAW pass fixture: Native capability is rejected, and a pass never calls _gave_check.
_,c=_compiled(True);s=GameSession(c);consumer=m.SharedCheckAvailability(c);assert consumer.provider is None
rt=SearchPathRuntime(s.state,c,availability_provider=consumer.for_position)
try:
 SearchPathRuntime._gave_check=lambda rt,pos,checkpoint=None:consumer.check(pos,checkpoint)
 with rt.pushed(PassAction()):
  calls=consumer.calls
  with rt.pushed(PassAction()):
   assert rt.terminal_status.status is TerminalStatus.ACTION_CLASS_DRAW
   assert consumer.calls==calls
   assert consumer.pending_position is None and consumer.pending_pack is None
 rt.assert_balanced();rows.append(dict(case='existing_consecutive_pass_DRAW',actual_native_projection_supported=False,draw_skips_availability=True,pass_skips_gavecheck=True,pending_empty=True))
finally:SearchPathRuntime._gave_check=oldcheck
write_record(Path(__file__).with_name('shared-crossstage-result.json'),dict(rows=rows,decision='Externalpending failure reproduced; current private route not public-interface-qualified. DRAW control does not manufacture a hot Native route: existing capability and pass gates prevent it. Retain original plane unchanged, add explicit finally cleanup only in separately declared candidate; earlier pack error observability remains open.',scope='Injected actual runtime identity stage, existing reachable pass-policy DRAW fixture; no engine patch/default change.'))
print(rows)
