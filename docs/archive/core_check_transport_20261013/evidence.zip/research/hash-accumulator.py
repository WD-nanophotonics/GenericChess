def _semantic_component_diff_hash(parent: Position, child: Position, compiled, current: RuntimeHash) -> RuntimeHash:
    """Scan the whole board, avoiding maps/tuples for unchanged cells.

    Compound actions and transition triggers can affect arbitrary cells; the
    action's source/target is deliberately not used as a footprint bound.
    """
    lo, hi = current.lo, current.hi
    changed = False
    for index, (left, right) in enumerate(zip(parent.board, child.board)):
        if left is right:
            continue
        old = _component_map_cell(parent, index)
        new = _component_map_cell(child, index)
        if old != new:
            token = _component_token(("board", index), old)
            lo ^= token.lo
            hi ^= token.hi
            changed = True
            token = _component_token(("board", index), new)
            lo ^= token.lo
            hi ^= token.hi
            changed = True
    before = _nonboard_component_map(parent, compiled)
    after = _nonboard_component_map(child, compiled)
    for address in before.keys() | after.keys():
        old = before.get(address)
        new = after.get(address)
        if (
            (address in before) != (address in after)
            or old != new
            or (address[0] in ("aux", "aux_unknown")
                and not _aux_value_equal(old, new))
        ):
            if address in before:
                token = _component_token(address, old)
                lo ^= token.lo
                hi ^= token.hi
                changed = True
            if address in after:
                token = _component_token(address, new)
                lo ^= token.lo
                hi ^= token.hi
                changed = True
    return RuntimeHash(lo & MASK64, hi & MASK64) if changed else current
