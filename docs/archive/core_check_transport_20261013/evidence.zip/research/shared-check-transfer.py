"""Actual Core-owned caller: semantic attack backend and legality attribution."""
import argparse, hashlib, json, random, sys, time,sysconfig,importlib.util
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import generic_chess.native as native
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value, write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from scripts.native_core_availability import NativeCoreAvailability

class CountedSemanticEvaluator(SemanticAttackEvaluator):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.score_calls=self.map_calls=0
    def evaluate(self,state):
        self.score_calls+=1;return super().evaluate(state)
    def _attack_maps(self,state):
        self.map_calls+=1;return super()._attack_maps(state)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
    b=Path(args.output);b.mkdir(parents=True,exist_ok=True)
    if (b/'declaration.json').exists():raise RuntimeError('frozen output exists')
    modes=[('python-check',True),('shared-check',True)]
    modules={name:native._module() for name,_ in modes}
    declaration=dict(question='Can Native gave-check including every extra state import improve actualCore q4 caller cost?'   ,roots=['1052-ply8'],modes=modes,orders=2,depths=[2],q=4,hardq=8,nodes=100000,seconds=120,calls=4,expected_seconds='8existingD2 calls <2minutes; currentgeneratedtransfer mayrunconcurrently, ordinaryload disclosed, pairedorder, fullnon-timefields/counters required' ,decision='Complete equal-depth action/score/non-time work must match for evaluator backend attribution; any mismatch investigated without fitting. Both arms retain the same Native legal provider; only runtimeattack loop order differs and complete non-time work must agree. Partial iterations are execution limits, not decision gains. No cap extension/default changes.',scope='Both arms use actual Native semantic attacks and Native legal provider, same weights, original Core history/precedence/order/TT. SameS0-S4 availability primitive, onlyscalarcaptureattack looporder changes. Actual public AlphaBetaPlayer, Core terminal/history/identity/declarations and fresh TT/ordering defaults. Previously observed1051-1052 roots; changed premise is per-instance callback versus module-global injection with seed+11000 walk; adaptive developmental transfer, no independent holdout claim; frozen identical weights/profile, explicit SEMANTIC attack authority. Not legacy evaluation equality or thin-capsule product integration.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    declaration.update(scope='Private process-only _gave_check replacement; all current C/backend/evaluation/legality/availability unchanged. Core history/terminal/frame cache stays authoritative; no additional cache. State import actual ply, count every call. Old roots exposed development.',decision='Require exact full decision/non-time work and root/frame/history restoration; measure extra import+query. Negative/noisy gain defers integration. Four counterbalanced D2 calls, q4/hard8, no result-driven extension.',expected_seconds='4 calls estimated 25 seconds, each120second limit')
    declaration.update(question='Does sharing a single transient packed child across check and immediately following availability avoid the Nativecheck extra import?',scope='Private onependingcapsule perresearchconsumer, consumed andcleared on availability; exactPosition identity, no history/terminal/cache/PV/default change. Bothqueries ignoreply;packply0; Core actual ply/history/stop precedence unchanged. Purecheckbackend plus transportsharing, not isolatedquerycost.',decision='Fourcounterbalanced1052D2 q4 calls; compareexactdecision/tree/frontier/eval/restore; transportcounts intentionallydiffer. Required-error/typed-state/current-capability qualification beforeanypublicroute or newequalbudgetplane.')
    declaration.update(roots=list(range(2026101361,2026101369)),depths=[12],budgets=[16,64],nodes=None,calls=64,expected_seconds='Bounded64calls <=2560queryseconds plusrootsetup, estimate<1hour singleprojectrun; no artificialsplitting.',decision='Fresh rules, allroots kept/unavailable not replaced. Twoorders/twoequalbudgets, q4/hard8 no nodecap. Same-depth fullscore/action/PV/declaration and iterationcounters must agree; errors/unfinished retained; no outcome-driven extension. Native fallback explicit. Usefulcompletedhorizon affects optionalroute selection, not WDL/strength/default adoption.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),consumer_sha256=hashlib.sha256(Path(__file__).with_name('shared-check-consumer.py').read_bytes()).hexdigest())
    write_record(b/'declaration.json',declaration)
    roots=[];samples=[]
    for seed in range(2026101361,2026101369):
        g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(seed+11000)
        for _ in range(8):
            if s.result.status.value != 'ongoing':break
            actions=sorted(s.legal_actions(),key=repr)
            if not actions:break
            s.submit(rng.choice(actions))
        if s.result.status.value != 'ongoing' or s.state.ply_count!=8:
            write_record(b/('unavailable-'+str(seed)+'.json'),dict(seed=seed,state=record_value(s.state),result=record_value(s.result),policy='No replacement root'));continue
        roots.append((seed,c,ec,profile,s));samples.append(dict(seed=seed,initial=record_value(s.state),witnesses=record_value(s._search_witnesses),profile=record_value(profile),config=record_value(ec)))
    write_record(b/'samples.json',samples)
    runtimes=[];captured=[];old_attach=SearchPathRuntime.attach_stats;old_stats=pm.SearchStatistics
    imports=queries=0;old_pack=ns.pack_current_position;old_attack=ns.attacked_squares
    from collections import Counter
    physical=Counter();old_transient=ns.transient_legal_actions
    def transient(rules,position):
        audited=ns.transient_legal_actions_audit(rules,position)
        physical['frontiers']+=1;physical['legal_actions']+=len(audited['actions'])
        for key,value in audited.items():
            if key!='actions':physical[key]+=value
        return audited['actions']
    def pack(*a,**kw):
        nonlocal imports;imports+=1;return old_pack(*a,**kw)
    def attack(*a,**kw):
        nonlocal queries;queries+=1;return old_attack(*a,**kw)
    def attach(rt,stats):
        v=old_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return v
    def factory():
        v=SearchStatistics();captured.append(v);return v
    original_check=SearchPathRuntime._gave_check
    sp=importlib.util.spec_from_file_location('shared_transfer',Path(__file__).with_name('shared-check-consumer.py'));module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module);SharedCheckAvailability=module.SharedCheckAvailability
    check_counts={}
    def native_check(rt,position,checkpoint=None):return availability.check(position,checkpoint)
    rows=[];start=time.perf_counter()
    try:
        SearchPathRuntime.attach_stats=attach;pm.SearchStatistics=factory;ns.pack_current_position=pack;ns.attacked_squares=attack;ns.transient_legal_actions=transient
        for seed,c,ec,profile,s in roots:
            legal=set(s.legal_actions());saved=s.state
            depth=12
            for seconds in declaration['budgets']:
                for order in range(2):
                    for backend,use_native in (modes if order==0 else list(reversed(modes))):
                        p.rr.stopped();runtimes.clear();captured.clear();imports=queries=0;physical.clear();native._MODULE=modules[backend]
                        check_counts=dict(calls=0,import_seconds=0.0,query_seconds=0.0);SearchPathRuntime._gave_check=native_check if backend=='shared-check' else original_check
                        t=time.perf_counter();ev=CountedSemanticEvaluator(c,profile,ec,backend='native');availability=SharedCheckAvailability(c) if backend=='shared-check' else NativeCoreAvailability(c);player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,use_disk_cache=False,availability_provider=availability.for_position if availability else None)
                        iterations=[]
                        value=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=None,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8),progress_callback=lambda d,n,q: iterations.append(dict(depth=d,nodes=n,qnodes=q)))
                        elapsed=time.perf_counter()-t
                        assert len(runtimes)==len(captured)==1
                        rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot and s.state==saved and value.action in legal
                        row=dict(seconds_limit=seconds,iterations=iterations,check_counts=dict(check_calls=getattr(availability,'check_calls',0),shared_import_hits=getattr(availability,'shared_import_hits',0),check_import_seconds=getattr(availability,'check_import_seconds',0),check_query_seconds=getattr(availability,'check_query_seconds',0)),seed=seed,depth_requested=depth,order=order,attack_backend='native',native_legal_requested=True,availability_mode=backend,physical_frontier=dict(physical),availability_counts=None if availability is None else dict(calls=availability.calls,imports=availability.imports,queries=availability.queries,fallbacks=availability.fallbacks,payload_seconds=availability.payload_seconds,query_seconds=availability.query_seconds),provider_created=player.native_legality_provider is not None,caller_seconds=elapsed,score_calls=ev.score_calls,map_calls=ev.map_calls,actual_attack_imports=imports,actual_attack_queries=queries,decision=record_value(value),stats=record_value(captured[0]),root_restored=True)
                        rows.append(row);write_record(b/'result.json',dict(complete=False,rows=rows));print(seed,seconds,order,backend,use_native,value.completed_depth,value.termination_reason,round(elapsed,3),value.score,flush=True)
    finally:
        SearchPathRuntime._gave_check=original_check
        SearchPathRuntime.attach_stats=old_attach;pm.SearchStatistics=old_stats;ns.pack_current_position=old_pack;ns.attacked_squares=old_attack;ns.transient_legal_actions=old_transient
    write_record(b/'result.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
if __name__=='__main__':main()
