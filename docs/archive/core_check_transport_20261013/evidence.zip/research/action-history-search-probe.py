from pathlib import Path
import sys,runpy,json,types,subprocess
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
# Import only the observed legal pair setup; do not run its output-producing suffix.
src=Path(__file__).with_name('action-history-key-probe.py').read_text();ns={'__file__':str(Path(__file__).with_name('action-history-key-probe.py')),'__name__':'probe_setup'};exec(src[:src.index('ra=SearchPathRuntime')],ns)
a,b,c=ns['a'],ns['b'],ns['c']
class Leaf:
 def evaluate(self,state):return 7
old_entry=pm.run_root_search;rows=[]
for arm in ('pinned-original','current'):
 if arm=='pinned-original':
  runtime=types.ModuleType('generic_chess.core._original_history_runtime');runtime.__package__='generic_chess.core';sys.modules[runtime.__name__]=runtime
  source=subprocess.check_output(['git','show','0ad6647e97087ee8c6f742f9fa1ec0b22b6b6a2c:generic_chess/core/search_runtime.py']);exec(compile(source,'<pinned-runtime>','exec'),runtime.__dict__)
  search=types.ModuleType('generic_chess.ai.alphabeta._original_history_search');search.__package__='generic_chess.ai.alphabeta';sys.modules[search.__name__]=search
  source=subprocess.check_output(['git','show','0ad6647e97087ee8c6f742f9fa1ec0b22b6b6a2c:generic_chess/ai/alphabeta/search.py']);exec(compile(source,'<pinned-search>','exec'),search.__dict__);search.SearchPathRuntime=runtime.SearchPathRuntime;pm.run_root_search=search.run_root_search
 else:pm.run_root_search=old_entry
 try:
  player=AlphaBetaPlayer(c,evaluator_override=Leaf(),use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
  limits=SearchLimits(max_depth=1,quiescence_max_depth=0,quiescence_hard_max_depth=0)
  left=player.choose_action(a,limits);warmright=player.choose_action(b,limits)
  fresh=AlphaBetaPlayer(c,evaluator_override=Leaf(),use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(b,limits)
  rows.append(dict(arm=arm,left=record_value(left),warm_right=record_value(warmright),cold_right=record_value(fresh),warm_cold_same_score=warmright.score==fresh.score))
 finally:pm.run_root_search=old_entry
out=Path(__file__).with_name('action-history-search-result.json');assert not out.exists();write_record(out,dict(rows=rows,scope='Actual publicchoose_action, completelegalhistories, D1/q0, controlledconstant7 leaf, TTretainedacrosstwoqueries; fullpinnedRuntime/search sources andcurrent. Not stronger-player claim.'))
print([(x['arm'],x['left']['score'],x['warm_right']['score'],x['cold_right']['score'],x['warm_right']['tt_hits']) for x in rows])
