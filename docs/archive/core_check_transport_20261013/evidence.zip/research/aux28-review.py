"""Independent exact regrading of fixed AUX28 structured evidence; no game search."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter, defaultdict
import json, hashlib, argparse, subprocess, zipfile, io

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '.local_agent/core-consumer-20261013/aux28'
PIN = '5ef777228c276435e47d5d71b62bc379e020c7f0'
ROUND_FILES = ['results/dev_aux/task447/result_432_433.json',
               'results/dev_aux/task447/result_439_440.json',
               'results/dev_aux/task447/result_449_450.json',
               'results/dev_aux/task462/result_457_458.json']
METRIC_FILES = [('results/dev_aux/task448/result.json', 'rows'),
                ('results/dev_aux/task442/result.json', 'metrics'),
                ('results/dev_aux/task454/result.json', 'metrics'),
                ('results/dev_aux/task465/result.json', 'metrics')]

def fetch():
    def blob(path):
        return subprocess.check_output(['git', 'show', PIN+':'+path], cwd=ROOT)
    manifest = json.loads(blob('results/dev_aux/ACTUAL_MATURE_20261012_28_manifest.json'))
    raw = blob('results/dev_aux/ACTUAL_MATURE_20261012_28.zip')
    assert hashlib.sha256(raw).hexdigest() == manifest['archive_sha256']
    archive = zipfile.ZipFile(io.BytesIO(raw))
    hashes = {f['path']: f['sha256'] for f in manifest['files']}
    BASE.mkdir(parents=True, exist_ok=True)
    for path in ROUND_FILES + [x[0] for x in METRIC_FILES]:
        try: data = archive.read(path)
        except KeyError: data = blob(path)
        assert hashlib.sha256(data).hexdigest() == hashes[path]
        target = BASE / path.replace('/', '__')
        if target.exists(): assert target.read_bytes() == data
        else: target.write_bytes(data)

def load(path):
    data = (BASE / path.replace('/', '__')).read_bytes()
    return json.loads(data), hashlib.sha256(data).hexdigest()

def review():
    reports, metrics = [], []
    cell_count = 0
    for path in ROUND_FILES:
        result, sha = load(path)
        groups = defaultdict(Counter)
        strict_terminal_overrides, tie_changes = 0, 0
        for row in result['rows']:
            candidates = row['candidates']
            assert len(candidates) == 3
            for candidate in candidates:
                cells = candidate['cells']
                assert len(cells) in (8, 32)
                cell_count += len(cells)
                for field, mean in candidate['means'].items():
                    assert F(mean) == sum((F(x[field]) for x in cells), F(0))/len(cells)
                for cell in cells:
                    assert F(cell['goal']) == F(cell['terminal'])+F(cell['quantity'])
                    terminal = F(cell['terminal'])
                    assert terminal in (-32, 0, 32)
                    fast = terminal+(1 if terminal>0 else -1)*F(24-cell['plies'],24) if terminal else F(0)
                    assert F(cell['fast_terminal']) == fast
            decisions = {}
            for field, saved in row['decisions'].items():
                means = [F(c['means'][field]) for c in candidates]
                winner = max(range(3), key=lambda i: means[i])
                assert winner == saved['selected_index']
                assert means[winner]-means[0] == F(saved['gain'])
                decisions[field] = winner
            assert decisions['actual_training'] == row['actual_selected']
            mixed, pure = decisions['goal'], decisions['terminal']
            category = ('both_keepbase' if mixed==pure==0 else
                        'same_nonbase_proposal' if mixed==pure else
                        'mixed_accepts_pure_keepsbase' if mixed!=0 and pure==0 else 'different_proposal')
            assert category == row['category']
            group = groups[(row['task'], row['arm'], row['family'])]
            group[category] += 1
            group['actual_accepted'] += int(row['actual_selected'] != 0)
            group['mixed_pure_local_choices_differ'] += int(mixed != pure)
            group['pure_fast_local_choices_differ'] += int(pure != decisions['fast_terminal'])
            terms = [F(c['means']['terminal']) for c in candidates]
            strict_terminal_overrides += int(terms[mixed] < max(terms))
            tie_changes += int(mixed != pure and terms[mixed] == terms[pure])
        for summary in result['summaries']:
            group = groups[(summary['task'], summary['arm'], summary['family'])]
            assert {k: group[k] for k in summary['categories']} == summary['categories']
            for key in ('actual_accepted', 'mixed_pure_local_choices_differ', 'pure_fast_local_choices_differ'):
                assert group[key] == summary[key]
        reports.append(dict(path=path, sha256=sha, rounds=len(result['rows']),
                            strict_terminal_overrides=strict_terminal_overrides,
                            terminal_tie_direction_changes=tie_changes, summaries=result['summaries']))
    for path, key in METRIC_FILES:
        result, sha = load(path)
        for row in result[key]:
            deltas = row.get('paired_gains', row.get('paired_deltas'))
            families = row.get('root_family_gains', row.get('root_family_deltas'))
            leave = row.get('leave_one_family_gains', row.get('leave_one_family_deltas'))
            assert F(row['endpoint_mean'])-F(row['initial_mean']) == F(row['gain'])
            assert sum(map(F, deltas), F(0))/len(deltas) == F(row['gain'])
            assert [sum(map(F,deltas[i:i+2]),F(0))/2 for i in range(0,len(deltas),2)] == list(map(F,families))
            assert [(sum(map(F,families),F(0))-F(x))/(len(families)-1) for x in families] == list(map(F,leave))
            if 'terminal_component_gain' in row:
                assert F(row['terminal_component_gain'])+F(row['quantity_component_gain']) == F(row['gain'])
        metrics.append(dict(path=path, sha256=sha, rows=len(result[key]), all_exact=True))
    return dict(source_sha=PIN, rounds=sum(r['rounds'] for r in reports),
                scored_cells=cell_count, reports=reports, metrics=metrics, new_go=0,
                bounds={str(n):str(F(34-4*n,n)) for n in (8,16,32)},
                scope='Reproducible independent exact local scores/winners/family arithmetic; no journal/RNG/PV/binary/game reproduction, no unexecuted training path or human fit.')

if __name__ == '__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--fetch',action='store_true');ap.add_argument('--output',required=True)
    args=ap.parse_args();target=Path(args.output)
    if target.exists(): raise RuntimeError('Frozen output exists')
    if args.fetch: fetch()
    value=review();value['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    target.write_bytes(json.dumps(value,indent=2).encode())
    print(value['rounds'],value['scored_cells'],sum(x['rows'] for x in value['metrics']))
