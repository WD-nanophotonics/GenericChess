import time
from scripts.native_core_availability import NativeCoreAvailability
from generic_chess.native import semantic as ns
from generic_chess.core.semantic_executor import semantic_engine_for
class SharedCheckAvailability(NativeCoreAvailability):
    def __init__(self,compiled):
        super().__init__(compiled);self.pending_position=self.pending_pack=None
        self.check_calls=self.shared_import_hits=0;self.check_import_seconds=self.check_query_seconds=0.0
    def check(self,position,checkpoint=None):
        self.pending_position=self.pending_pack=None
        if checkpoint:checkpoint()
        provider=self.provider
        if provider is None:
            return semantic_engine_for(self.compiled).in_check(position,position.side_to_move,checkpoint=checkpoint)
        if position.ruleset_fingerprint!=provider.native_rules.fingerprint:raise ValueError('check compiled source mismatch')
        t=time.perf_counter();packed=ns.pack_position(provider.native_rules,provider._state_only_payload(position,0));self.check_import_seconds+=time.perf_counter()-t
        t=time.perf_counter();value=ns.in_check(provider.native_rules,packed,position.side_to_move);self.check_query_seconds+=time.perf_counter()-t;self.check_calls+=1
        if checkpoint:checkpoint()
        self.pending_position=position;self.pending_pack=packed
        return value
    def for_position(self,position,checkpoint=None):
        packed=self.pending_pack if self.pending_position is position else None
        self.pending_position=self.pending_pack=None
        if packed is None:return super().for_position(position,checkpoint)
        self.calls+=1;self.shared_import_hits+=1
        if checkpoint:checkpoint()
        t=time.perf_counter();value=ns.has_legal_action(self.provider.native_rules,packed);self.queries+=1;self.query_seconds+=time.perf_counter()-t
        if checkpoint:checkpoint()
        return value
