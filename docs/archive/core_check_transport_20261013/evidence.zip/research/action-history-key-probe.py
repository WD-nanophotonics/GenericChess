from pathlib import Path
import sys,json
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from rule_semantics_ir_fixtures import _semantic_ruleset,_king_type
from generic_chess.rules.schema import RuleSemanticAction,RuleGeometrySpec,RuleConsecutiveActionAdjudication
from generic_chess.core.pieces import PieceType,Piece
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.actions import PassAction,SemanticBoardMove
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
if '--original' in sys.argv:
 import subprocess,types
 old=types.ModuleType('generic_chess.core._action_history_original');old.__package__='generic_chess.core';sys.modules[old.__name__]=old
 raw=subprocess.check_output(['git','show','0ad6647e97087ee8c6f742f9fa1ec0b22b6b6a2c:generic_chess/core/search_runtime.py'])
 exec(compile(raw,'<pinned-original-runtime>','exec'),old.__dict__)
 SearchPathRuntime=old.SearchPathRuntime
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
n=5;board=[[None]*n for _ in range(n)];board[0][0]=Piece(0,'K','K');board[4][4]=Piece(1,'K','K');board[1][1]=Piece(0,'A','A');board[3][3]=Piece(1,'A','A')
noop=RuleSemanticAction(name='board_noop',type_ids=('A',),geometry=RuleGeometrySpec(kind='leap',offset=(1,0)),target_relation='empty',effects=(),composition='augment')
rules=replace(_semantic_ruleset((_king_type(),PieceType('A','A',())),(noop,),n=n,rows=tuple(tuple(x) for x in board)),pass_enabled=True,repetition_limit=20,consecutive_action_adjudications=(RuleConsecutiveActionAdjudication('pass',2,'DRAW'),))
c=compile_semantic_ruleset(rules);a=GameSession(c);b=GameSession(c);passa=PassAction();noopa=next(x for x in b.legal_actions() if isinstance(x,SemanticBoardMove) and x.pattern_id.startswith('sem_'))
a.submit(passa);b.submit(noopa);assert a.state.position==b.state.position
ra=SearchPathRuntime(a.state,c,history_witnesses=a._search_witnesses);rb=SearchPathRuntime(b.state,c,history_witnesses=b._search_witnesses)
keys_equal=ra.search_key()==rb.search_key();assert ra.tt_eligible and rb.tt_eligible
with ra.pushed(passa):status_a=ra.terminal_status.status.value
with rb.pushed(passa):status_b=rb.terminal_status.status.value
ra.assert_balanced();rb.assert_balanced();assert status_a!=status_b
out=dict(same_position=True,same_ply=True,same_counts=True,full_witnesses=True,key_equal=keys_equal,eligible=(ra.tt_eligible,rb.tt_eligible),future_same_pass_terminal=(status_a,status_b),a_history=[x.action_signature for x in ra.history],b_history=[x.action_signature for x in rb.history],scope='Two fullylegal paths pass versus semantic no-board-effect action; identical exact current position/ply/counts/check responsibility but future pass adjudication differs.')
target=Path(__file__).with_name('action-history-key-original.json' if '--original' in sys.argv else 'action-history-key-current.json');assert not target.exists();write_record(target,out);print(out)
