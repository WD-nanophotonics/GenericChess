from pathlib import Path
import sys,random,time,json,importlib.util
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from scripts.native_core_availability import NativeCoreAvailability
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta import search as sm
from generic_chess.core.semantic_executor import semantic_engine_for
seed=2026101403;g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(seed+13000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
b=Path(__file__).with_name('qorder-hardlimit-witness');b.mkdir(exist_ok=True);assert not(b/'declaration.json').exists()
write_record(b/'declaration.json',dict(question='Which exactexisting1403 checked-child causes publicqordering hard8 abort?',scope='OneobservedABordered failedD3 tracedat SAME16s/q4hard8/root/leaf/TT, newpremiseattribution notrescue. Currentf88Pythonrepair isirrelevantbecauseConsecutivepolicyabsent; no timingcomparisontoearlier0ad. Captureonlyfirstdeepfailure, independentcheck/frontier afterward.',calls=1,max_depth=3,seconds=16,nodecap=None,q=4,hardq=8,decision='Keep abort/completedD2, inspectexactincheck/evasion andpath. No capchange/secondrepeat/opponentfit/defaultswitch.'))
traces=[];original=sm._quiescence_runtime
def trace(alpha,beta,ply,qdepth,ctx):
 try:return original(alpha,beta,ply,qdepth,ctx)
 except sm.SearchAborted as e:
  if str(e)=='qsearch_check_hard_limit' and not traces:
   rt=ctx.runtime;pos=rt.position;eng=semantic_engine_for(c);actions=rt.legal_actions()
   traces.append(dict(alpha=alpha,beta=beta,search_ply=ply,qdepth=qdepth,runtime_depth=rt.depth,position=record_value(pos),actual_ply=rt.ply_count,history=[dict(actor=h.actor,gave_check=h.gave_check,signature=h.action_signature) for h in rt.history],terminal=record_value(rt.terminal_status),independent_in_check=eng.in_check(pos,pos.side_to_move),evasion_count=len(actions),evasions=record_value(actions)))
  raise
sm._quiescence_runtime=trace
try:
 availability=NativeCoreAvailability(c);player=AlphaBetaPlayer(c,evaluator_override=SemanticAttackEvaluator(c,profile,ec,backend='native'),use_disk_cache=False,use_native_semantic_legality=True,availability_provider=availability.for_position,tuning=SearchTuning(use_ordered_qsearch=True));start=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=None,max_time_seconds=16,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-start
finally:sm._quiescence_runtime=original
assert d.termination_reason=='qsearch_check_hard_limit' and d.completed_depth==2 and len(traces)==1
assert traces[0]['qdepth']==8 and traces[0]['independent_in_check'] and traces[0]['evasion_count']>0
write_record(b/'result.json',dict(decision=record_value(d),traces=traces,seconds=elapsed,assessment='A genuinecheckednonterminal haslegal evasions atdeclaredhard8, so candidateabort ispolicy boundary, notmissinglegalmoves/unhandledNativeerror. Different qorder canexpose thisbranch beforecutoff; no prooforderingharm beyond measuredcompletion. Lexical64 comparison retainsD3 separately.'))
print(d.completed_depth,d.termination_reason,round(elapsed,3),[(x['qdepth'],x['runtime_depth'],x['evasion_count']) for x in traces])
