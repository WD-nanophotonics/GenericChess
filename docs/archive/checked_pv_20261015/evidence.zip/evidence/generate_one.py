from pathlib import Path
import sys,json,time,inspect,importlib.util,hashlib,traceback
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];b=R/'.local_agent/pv-contract-20261015';prior=R/'.local_agent/immediate-goal-20261015';seed=int(sys.argv[1]);n=int(sys.argv[2]);arm=sys.argv[3];opening=1024 if '1024'in arm else 256
import generic_chess.rules.compiler as cc
if arm.startswith('cache'):
 ns=dict(cc.__dict__);exec((b/'cached_geometry.py').read_text(),ns);cc._build_tables=ns['_build_tables']
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
from scripts.research_record import record_value
from scripts import full_q_refresh_comparison as p
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import position_identity_key
from generic_chess.ai.limits import SearchLimits
start=time.perf_counter();cfg=GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32,max_opening_legal_moves=opening);game=generate_game(cfg);generation_seconds=time.perf_counter()-start
raw=cc.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
spec=importlib.util.spec_from_file_location('genwide._native_core',next(prior.glob('final_v2*.pyd')));wide=importlib.util.module_from_spec(spec);spec.loader.exec_module(wide);nr=nc.compile_native_semantic_rules(c,backend_module=wide);pos=pack_semantic_search_position(c,nr,s);snap=sem.snapshot(nr,pos);expected=expected_snapshot(s.state.position,nr,c)
for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(expected[k])
assert sem.position_key(nr,pos)==str(position_identity_key(s.state.position,c))and snap['history_exact']and snap['history_events_exact']
legal=s.legal_actions();assert set(sem.transient_legal_actions(nr,pos))=={pack_semantic_action(nr,s.state.position,a)for a in legal}
v={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()};e=SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_nodes=64,max_time_seconds=2,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);search_seconds=time.perf_counter()-t;assert r.action in legal
state=s.state;np=pos
for a in r.principal_variation:
 code=pack_semantic_action(nr,state.position,a);np=sem.make_checked(nr,np,code);state=apply_action(state,a,c);sn=sem.snapshot(nr,np);ex=expected_snapshot(state.position,nr,c)
 for k in ['board','hands','aux_state','side']:assert record_value(sn[k])==record_value(ex[k])
 assert sem.position_key(nr,np)==str(position_identity_key(state.position,c))
output={'complete':True,'seed':seed,'n':n,'arm':arm,'generation_seconds':generation_seconds,'total_seconds':time.perf_counter()-start,'ruleset':json.loads(serialize_ruleset(game.ruleset)),'generation_report':record_value(game.generation_report),'fingerprint':c.ruleset_fingerprint,'state':record_value(s.state),'legal_count':len(legal),'fullstate_checked':True,'search':record_value(r),'search_seconds':search_seconds};(b/f'generation-{seed}-{arm}.json').write_text(json.dumps(output),encoding='utf-8');print(seed,n,arm,generation_seconds,len(legal),flush=True)
