from pathlib import Path
import json,sys,subprocess,time,traceback
b=Path('.local_agent/pv-contract-20261015');plan=json.loads((b/'generation-plan.json').read_text());rows=[];start=time.perf_counter()
for i,x in enumerate(plan['families']):
 arms=plan['arms'][i%4:]+plan['arms'][:i%4]
 for arm in arms:
  if time.perf_counter()-start>plan['batch_fuse_seconds']:
   (b/'generation-results.json').write_text(json.dumps({'complete':False,'reason':'frozen2400s_fuse','rows':rows,'seconds':time.perf_counter()-start}));sys.exit(0)
  t=time.perf_counter();name=arm['name']
  try:
   r=subprocess.run([sys.executable,str(b/'generate_one.py'),str(x['seed']),str(x['n']),name],capture_output=True,timeout=45);data=r.stdout+r.stderr;status='complete'if r.returncode==0 else'failed'
  except subprocess.TimeoutExpired as e:data=(e.stdout or b'')+(e.stderr or b'');status='45s_censored'
  (b/f'generation-{x["seed"]}-{name}.log').write_bytes(data);rows.append({'seed':x['seed'],'n':x['n'],'arm':name,'status':status,'seconds':time.perf_counter()-t});(b/'generation-results.json').write_text(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8');print(rows[-1],flush=True)
(b/'generation-results.json').write_text(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start}),encoding='utf-8')
