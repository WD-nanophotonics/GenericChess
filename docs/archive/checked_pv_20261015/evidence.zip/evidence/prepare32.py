from pathlib import Path
import subprocess,json,time,sys
b=Path('.local_agent/pv-contract-20261015');rows=[]
for seed in [3741,3742,4051]:
 start=time.perf_counter()
 try:
  r=subprocess.run([sys.executable,str(b/'prepare32_one.py'),str(seed)],capture_output=True,timeout=45);status='complete'if r.returncode==0 else'failed';data=r.stdout+r.stderr
 except subprocess.TimeoutExpired as e:status='45s_censored';data=(e.stdout or b'')+(e.stderr or b'')
 (b/f'prepare32-{seed}.log').write_bytes(data);rows.append({'seed':seed,'status':status,'seconds':time.perf_counter()-start});(b/'prepare32-results.json').write_text(json.dumps(rows));print(rows[-1],flush=True)
