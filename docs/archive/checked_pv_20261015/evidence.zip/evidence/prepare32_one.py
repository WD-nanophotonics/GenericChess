from pathlib import Path
import sys,time,json,faulthandler
R=Path.cwd();sys.path.insert(0,str(R));import generic_chess.generation.generator as g
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
b=R/'.local_agent/pv-contract-20261015';seed=int(sys.argv[1]);start=time.perf_counter();log=b/f'prepare32-{seed}.jsonl'
def event(x):
 x['at_seconds']=time.perf_counter()-start
 with log.open('a',encoding='utf-8')as f:f.write(json.dumps(x)+'\n')
for name in ['derive_promotion_data','derive_drop_mask','_initial_anchors_attacked','compile_ruleset','run_soft_filters','legal_actions_from_position']:
 old=getattr(g,name)
 def wrap(*args,_name=name,_old=old,**kw):
  event({'phase':_name,'event':'start'});t=time.perf_counter()
  try:r=_old(*args,**kw)
  except BaseException as e:event({'phase':_name,'event':'error','seconds':time.perf_counter()-t,'type':type(e).__name__});raise
  event({'phase':_name,'event':'end','seconds':time.perf_counter()-t});return r
 setattr(g,name,wrap)
faulthandler.dump_traceback_later(20,repeat=True)
game=g.generate_game(GeneratorConfig(seed=seed,board_size=32,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32))
(b/f'prepare32-{seed}-rules.json').write_text(serialize_ruleset(game.ruleset),encoding='utf-8');event({'event':'complete','attempts':game.generation_report.generation_attempts,'opening_count':game.generation_report.opening_legal_move_count})
