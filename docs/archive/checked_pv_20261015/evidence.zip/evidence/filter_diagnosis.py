from pathlib import Path
import sys,json,time
R=Path.cwd();sys.path.insert(0,str(R));b=R/'.local_agent/pv-contract-20261015'
import generic_chess.rules.compiler as c
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.generation.filters import run_soft_filters
from generic_chess.generation.config import GeneratorConfig
rows=[]
for seed in [3741,3742,4051]:
 r=deserialize_ruleset((b/f'geometry-input-{seed}.json').read_text(encoding='utf-8'));t=time.perf_counter()
 try:
  compiled=c.compile_ruleset(r);filters=run_soft_filters(GeneratorConfig(seed=seed,board_size=32,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32),compiled,{p.type_id:p for p in r.piece_types});rows.append({'seed':seed,'compile':'complete','seconds':time.perf_counter()-t,'filters':[{'name':f.name,'passed':f.passed,'detail':f.detail}for f in filters]})
 except Exception as e:rows.append({'seed':seed,'error_type':type(e).__name__,'error':str(e),'seconds':time.perf_counter()-t})
(b/'first-proposal-filters.json').write_text(json.dumps(rows,indent=2));print(rows)
