from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
import hashlib
start=time.perf_counter();checks=[]
for seed in range(4109,4117):
 x=json.loads((b/f'generation-{seed}-base1024.json').read_text(encoding='utf-8'));raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=nc.compile_native_semantic_rules(c,backend_module=wide);rows=json.loads((b/f'q32-{seed}.json').read_text(encoding='utf-8'))['rows'];unique={}
 for row in rows:
  line=row['result']['decision_line'];key=json.dumps(line,sort_keys=True)
  if key in unique:continue
  assert time.perf_counter()-start<180
  s=GameSession(c);assert record_value(s.state)==x['state'];pos=pack_semantic_search_position(c,nr,s);n=0
  for value in line:
   assert s.result.status.value=='ongoing'
   if isinstance(value,str):assert any(d.declaration_id==value for d in available_declarations(s.state,c));break
   a,=[a for a in s.legal_actions() if record_value(a)==value];pos=sem.make_checked(nr,pos,pack_semantic_action(nr,s.state.position,a));s.submit(a);snap=sem.snapshot(nr,pos);expected=expected_snapshot(s.state.position,nr,c)
   for field in ('board','hands','aux_state','side'):assert record_value(snap[field])==record_value(expected[field])
   assert snap['ply']==s.state.ply_count and snap['history_exact'] and snap['history_events_exact']
   assert [''.join(f'{v:016x}' for v in h)for h in snap['history']]==[str(position_identity_key(w,c))for w in s._search_witnesses]
   assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in s.state.history)
   nt=sem.terminal_status(nr,pos);assert nt['status']==s.result.status.value and nt['winner']==s.result.winner
   n+=1
  assert record_value(s.state.terminal_status)==row['PV_leaf_terminal'];unique[key]=n
 checks.append(dict(seed=seed,queries_covered=len(rows),unique_decision_lines=len(unique),unique_edges=sum(unique.values()),all_full_history_entries_and_terminal_match=True))
(b/'q32-history-replay.json').write_text(json.dumps(dict(complete=True,checks=checks,seconds=time.perf_counter()-start,scope='Previously frozen search outputs replayed, no searches/games added; actual earlier wide image with current Core. Every unique decision line checked including all SHA/actor/check history entries. Not all-domain equivalence.'),indent=2),encoding='utf-8');print('PASS',checks,time.perf_counter()-start)
