from pathlib import Path
import json,subprocess,sys,sysconfig,shutil,time,uuid
R=Path.cwd();b=R/'.local_agent/pv-contract-20261015';prior=R/'.local_agent/immediate-goal-20261015';out=b/('replay-'+uuid.uuid4().hex[:8]);out.mkdir();assert out.resolve().is_relative_to(b.resolve())
paths=subprocess.check_output(['git','ls-files'],text=True).splitlines()+['tests/product/test_native_immediate_win_goal.py','tests/product/test_native_explicit_semantic_backend.py','tests/product/test_native_pv_replay_boundaries.py']
for name in paths:
 p=R/name
 if not p.is_file():continue
 if (name.endswith('.py')and name.startswith(('generic_chess/','scripts/','tests/','tools/')))or(name.startswith('generic_chess/')and p.suffix in ['.json','.toml']):
  dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
for label,folder in [('v1',R/'generic_chess/_native'),('v2',prior/'src_final_v2')]:
 dest=out/'replay'/('src_'+label);dest.mkdir(parents=True,exist_ok=True)
 for p in folder.iterdir():
  if p.suffix in ['.c','.h']:shutil.copyfile(p,dest/p.name)
for name in ['v2-boundary-inputs.json','explicit-v2-results.json','explicit-v2-goals.json']:
 dest=out/'replay'/name;shutil.copyfile(prior/name,dest)
(out/'pytest.ini').write_text('[pytest]\npythonpath=tests tests/product\n',encoding='utf-8')
(out/'replay/qualify.py').write_text((prior/'replay_qualify.py').read_text(encoding='utf-8-sig'),encoding='utf-8')
rows=[];start=time.perf_counter();suffix=sysconfig.get_config_var('EXT_SUFFIX')
for label,target in [('v1',out/'generic_chess'/('_native_core'+suffix)),('v2',out/'replay'/('wide'+suffix))]:
 src=out/'replay'/('src_'+label);cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in sorted(src.glob('*.c'))],'-o',str(target)];r=subprocess.run(cmd,capture_output=True,timeout=180);(b/('replay-build-'+label+'.log')).write_bytes(r.stdout+r.stderr);rows.append({'build':label,'exit':r.returncode});assert r.returncode==0
for name,cmd in [('api-tests',[sys.executable,'-m','pytest','-c','pytest.ini','-p','no:cacheprovider','--basetemp','replay/pytest-owned','tests/product/test_native_immediate_win_goal.py','tests/product/test_native_explicit_semantic_backend.py','tests/product/test_native_pv_replay_boundaries.py','tests/product/test_h50b2e_semantic_search_engine.py','-q']),('fullstate',[sys.executable,'replay/qualify.py',str(R/'.local_agent')])]:
 r=subprocess.run(cmd,cwd=out,capture_output=True,timeout=180);(b/('replay-'+name+'.log')).write_bytes(r.stdout+r.stderr);rows.append({'test':name,'exit':r.returncode});assert r.returncode==0,(name,r.returncode)
shutil.copyfile(out/'replay/qualification.json',b/'replay-qualification.json');(b/'replay.json').write_text(json.dumps({'complete':True,'export':str(out),'seconds':time.perf_counter()-start,'rows':rows,'scope':'Two real source-built images,52APItests/full35roots/high32goalstate; own frozen inputs, no older private dependencies. Existing Windows/Python/Zigdeps, not clean-machine installer or longcurve rerun.'},indent=2),encoding='utf-8');print('REPLAY PASS',time.perf_counter()-start)
