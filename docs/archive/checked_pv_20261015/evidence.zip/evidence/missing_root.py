from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
import random
inputs=json.loads((b/'inputs.json').read_text());rows=[]
for seed in range(4011,4045):
 xs=[x for x in inputs['samples']if x['seed']==seed]
 if len(xs)!=1:continue
 c,s=case(xs[0]);rng=random.Random(seed+7000);walk=[]
 for ply in range(8):
  acts=s.legal_actions()
  if not acts:break
  a=rng.choice(sorted(acts,key=repr));s.submit(a);walk.append(record_value(a))
 rows.append({'seed':seed,'missing':'ply8','actual_plies':len(walk),'walk':walk,'terminal':record_value(s.state.terminal_status),'final_state':record_value(s.state),'no_replacement':True})
(b/'missing-played-roots.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print([{k:v for k,v in r.items()if k!='final_state'and k!='walk'}for r in rows])
