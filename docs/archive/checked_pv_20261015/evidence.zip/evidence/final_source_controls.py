from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
rows=[];errors=[];start=time.perf_counter();fns={'timed_candidate':classes['CheckedNative'],'final_product':SemanticSearchEngine}
for x in json.loads((prior/'v2-boundary-inputs.json').read_text()):
 c,s=case(x);nr=nc.compile_native_semantic_rules(c,backend_module=wide);v={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()}
 for q in (0,4):
  for order in (0,1):
   pair={}
   for arm in (list(fns)if order==0 else list(fns)[::-1]):
    e=fns[arm](c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_nodes=64,max_time_seconds=2,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;validate(r,s,nr);pair[arm]=signature(r);rows.append({'root':x['name'],'q':q,'order':order,'arm':arm,'caller_seconds':wall,'result':record_value(r)})
   if pair['timed_candidate']!=pair['final_product']:errors.append({'root':x['name'],'q':q,'order':order})
(b/'final-source-results.json').write_text(json.dumps({'complete':True,'rows':rows,'errors':errors,'seconds':time.perf_counter()-start,'scope':'Final public exception wrapper/declaration-tag parentheses versus earlier timed checked candidate; valid outputs only. Earlier errors and runtime curves retain original source identity.'}),encoding='utf-8');assert not errors;print('COMPLETE',len(rows),len(errors),time.perf_counter()-start)
