from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
seed=int(sys.argv[1]);x=json.loads((b/f'generation-{seed}-base1024.json').read_text(encoding='utf-8'));plan=json.loads((b/'q32-plan.json').read_text());start=time.perf_counter();rows=[]
raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c);assert record_value(s.state)==x['state'];nr=nc.compile_native_semantic_rules(c,backend_module=wide);prof=p.build_ruleset_profile(c,p.EvaluationConfig());v={k:int(round(z))for k,z in prof.board_value_by_type.items()};h={k:int(round(z))for k,z in prof.hand_value_by_base_type.items()};preparation_seconds=time.perf_counter()-start
assert preparation_seconds<=45,'45s preparation exceeded'
def save(done=False,error=None):
 (b/f'q32-{seed}.json').write_text(json.dumps({'complete':done,'seed':seed,'rows':rows,'board_values':v,'hand_values':h,'preparation_seconds':preparation_seconds,'seconds':time.perf_counter()-start,'error':error}),encoding='utf-8')
try:
 for budget in (plan['budgets']if seed%2==0 else plan['budgets'][::-1]):
  for order in (0,1):
   for q in (plan['ordinary_q']if order==0 else plan['ordinary_q'][::-1]):
    p.rr.stopped();e=SemanticSearchEngine(c,nr,board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=12,max_time_seconds=budget,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;leaf=validate(r,s,nr);assert r.action in s.legal_actions()
    child=GameSession(c);child.submit(r.action);physical_child=child.state.terminal_status.is_terminal;reply=None;reply_seconds=0;verified_reply=False
    if not physical_child:
     e2=SemanticSearchEngine(c,nr,board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();reply=e2.search(child,SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0),stop_on_immediate_win=True);reply_seconds=time.perf_counter()-t;validate(reply,child,nr)
     if reply.immediate_win:
      final=apply_action(child.state,reply.action,c);assert final.terminal_status.is_terminal and final.terminal_status.winner==child.state.position.side_to_move;verified_reply=True
    rows.append({'seed':seed,'budget':budget,'order':order,'requested_q':q,'caller_seconds':wall,'result':record_value(r),'PV_leaf_terminal':leaf,'selected_child_terminal':record_value(child.state.terminal_status),'verified_opponent_oneply_win':verified_reply,'opponent_diagnostic':None if reply is None else record_value(reply),'reply_seconds':reply_seconds,'negative_reply_is_WDL':False});save();print(seed,budget,order,q,r.completed_depth,r.result_ordinary_qdepth,verified_reply,flush=True)
 save(True)
except BaseException:save(False,traceback.format_exc());raise
