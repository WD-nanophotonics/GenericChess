from pathlib import Path
import json,sys,time,hashlib,gc
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));b=R/'.local_agent/pv-contract-20261015'
import generic_chess.rules.compiler as c
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.core.movement import LeapAtom,RayAtom
ns=dict(c.__dict__);exec((b/'normalized_geometry.py').read_text(encoding='utf-8'),ns)
inputs=[('4011',json.loads((b/'input-4011.json').read_text(encoding='utf-8'))['samples'][0]['ruleset']),('3741-wide',json.loads((b/'geometry-input-3741.json').read_text(encoding='utf-8')))]
rows=[];start=time.perf_counter()
for name,raw in inputs:
 r=deserialize_ruleset(json.dumps(raw));expected=None
 for variant in ('original','leap_list','ray_list','both_lists'):
  pts=[]
  for pt in r.piece_types:
   atoms=[]
   for atom in pt.movement_atoms:
    if isinstance(atom,LeapAtom) and variant in ('leap_list','both_lists'):atom=replace(atom,offset=list(atom.offset))
    if isinstance(atom,RayAtom) and variant in ('ray_list','both_lists'):atom=replace(atom,direction=list(atom.direction))
    atoms.append(atom)
   pts.append(replace(pt,movement_atoms=tuple(atoms)))
  rr=replace(r,piece_types=tuple(pts))
  for order in (0,1):
   outputs={}
   for arm in (('baseline','normalized') if order==0 else ('normalized','baseline')):
    assert time.perf_counter()-start<120
    gc.collect();t=time.perf_counter();out=(c._build_tables if arm=='baseline' else ns['_build_tables'])(rr);seconds=time.perf_counter()-t
    digest=hashlib.sha256(repr(out).encode()).hexdigest();outputs[arm]=digest
    if expected is None:expected=digest
    assert digest==expected
    rows.append(dict(input=name,variant=variant,order=order,arm=arm,seconds=seconds,full_ordered_table_sha256=digest))
   assert outputs['baseline']==outputs['normalized']
(b/'geometry-normalized-results.json').write_text(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,product_changed=False),indent=2),encoding='utf-8');print('COMPLETE',len(rows),time.perf_counter()-start)
