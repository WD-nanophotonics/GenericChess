from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
import random,collections
rows=[];roots=[];start=time.perf_counter()
for seed in [4113,4114,4115,4116]:
 x=json.loads((b/f'generation-{seed}-base1024.json').read_text());raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c);rng=random.Random(seed+8000);walk=[];nr=nc.compile_native_semantic_rules(c,backend_module=wide)
 for ply in range(3):
  if ply in (0,2):
   if s.result.status.value!='ongoing':break
   pos=pack_semantic_search_position(c,nr,s);before=record_value(sem.snapshot(nr,pos));keys=[str(position_identity_key(w,c))for w in s._search_witnesses];maximum=max(collections.Counter(keys).values());roots.append({'seed':seed,'ply':ply,'max_history_count':maximum,'R':c.repetition_limit,'repetition_impossible_on_next_edge':maximum<c.repetition_limit-1,'walk':walk.copy(),'full_state':record_value(s.state)})
   oracle={pack_semantic_action(nr,s.state.position,a)for a in s.legal_actions()}
   fns={'full':sem.guarded_actions_audit,'transient':sem.transient_legal_actions_audit}
   for order in (0,1):
    outputs={}
    for arm in (list(fns)if order==0 else list(fns)[::-1]):
     if time.perf_counter()-start>120:raise TimeoutError('120s frontier fuse')
     t=time.perf_counter();out=fns[arm](nr,pos);wall=time.perf_counter()-t;outputs[arm]=out['actions'];assert set(out['actions'])==oracle;assert record_value(sem.snapshot(nr,pos))==before;rows.append({'seed':seed,'ply':ply,'order':order,'arm':arm,'seconds':wall,'audit':out})
    assert outputs['full']==outputs['transient']
  if ply==2:break
  acts=s.legal_actions()
  if not acts:break
  a=rng.choice(sorted(acts,key=repr));s.submit(a);walk.append(record_value(a))
from test_native_pv_replay_boundaries import repeated_root
c=repeated_root().compiled;s=GameSession(c);nr=nc.compile_native_semantic_rules(c);control=[]
for ply in range(12):
 pos=pack_semantic_search_position(c,nr,s);keys=[str(position_identity_key(w,c))for w in s._search_witnesses];M=max(collections.Counter(keys).values());a=s.legal_actions()[0];child=apply_action(s.state,a,c);np=sem.make_checked(nr,pos,pack_semantic_action(nr,s.state.position,a));native=sem.terminal_status(nr,np);assert native['status']==child.terminal_status.status.value;safe=M<c.repetition_limit-1
 if safe:assert native['status']not in ('repetition','perpetual_check')
 control.append({'ply':ply,'M':M,'R':c.repetition_limit,'eligible':safe,'native_child_status':native,'Core_child_status':record_value(child.terminal_status)})
 if child.terminal_status.is_terminal:break
 s.submit(a)
(b/'history-cost-results.json').write_text(json.dumps({'complete':True,'rows':rows,'roots':roots,'control':control,'seconds':time.perf_counter()-start,'product_changed':False}),encoding='utf-8');print('COMPLETE',len(rows),len(roots),len(control),time.perf_counter()-start)
