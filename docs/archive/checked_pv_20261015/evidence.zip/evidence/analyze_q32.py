import json,collections,statistics,hashlib
from pathlib import Path
b=Path(__file__).resolve().parent
rows=[]
for seed in range(4109,4117):
 d=json.loads((b/f'q32-{seed}.json').read_text(encoding="utf-8")); assert d["complete"] and not d["error"]; rows+=d["rows"]
assert len(rows)==96 and len({(r["seed"],r["budget"],r["order"],r["requested_q"]) for r in rows})==96
cells=[]
for budget in (4,16):
 for q in (1,2,4):
  rs=[r for r in rows if r["budget"]==budget and r["requested_q"]==q]
  cells.append(dict(budget=budget,requested_q=q,calls=len(rs),completed_requested_q=sum(r["result"]["result_ordinary_qdepth"]==q for r in rs),retained_policy_counts=[dict(depth=k[0],ordinary_q=k[1],count=v) for k,v in sorted(collections.Counter((r["result"]["completed_depth"],r["result"]["result_ordinary_qdepth"]) for r in rs).items())],qnodes=sum(r["result"]["qnodes"] for r in rs),nodes=sum(r["result"]["nodes"] for r in rs),caller_seconds=sum(r["caller_seconds"] for r in rs),reply_seconds=sum(r["reply_seconds"] for r in rs),verified_opponent_oneply_wins=sum(r["verified_opponent_oneply_win"] for r in rs),selected_child_status=dict(collections.Counter((r["selected_child_terminal"]["status"],r["selected_child_terminal"]["winner"]) for r in rs))))
  cells[-1]["selected_child_status"]=[dict(status=k[0],winner=k[1],count=v) for k,v in cells[-1]["selected_child_status"].items()]
compact=[]
for r in rows:
 result={k:v for k,v in r["result"].items() if not k.endswith("_by_ply") and k not in ("training_trace",)}
 reply=None if r["opponent_diagnostic"] is None else {k:r["opponent_diagnostic"][k] for k in ("completed_depth","immediate_win","result_source","termination_reason","nodes","qnodes","action")}
 compact.append({**{k:v for k,v in r.items() if k not in ("result","opponent_diagnostic")},"result":result,"opponent_diagnostic":reply})
families=[]
for seed in range(4109,4117):
 rs=[r for r in rows if r["seed"]==seed];families.append(dict(seed=seed,calls=len(rs),distinct_selected_actions=len({json.dumps(r["result"]["action"],sort_keys=True) for r in rs}),selected_child_status=rs[0]["selected_child_terminal"]))
summary=dict(complete=True,planned_queries=96,recorded_queries=len(rows),families=families,cells=cells,verified_opponent_wins=0,nonterminal_child_unknown_queries=sum(r["selected_child_terminal"]["status"]=="ongoing" for r in rows),rows=compact,interpretation="q1/q2 finish only 2 of 8 families at16s, both orders; q4 none. All variants select identical physical actions per family. Negative opponent query is UNKNOWN, not WDL. Development broad-opening1024 distribution, no default/strength claim.",source_hashes={f"q32-{s}.json":hashlib.sha256((b/f"q32-{s}.json").read_bytes()).hexdigest() for s in range(4109,4117)})
(b/"q32-summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps({k:v for k,v in summary.items() if k not in ("rows","source_hashes")},indent=2))
