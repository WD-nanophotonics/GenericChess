from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
from dataclasses import replace
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.terminal import terminal_result
rows=[];errors=[]
for x in json.loads((prior/'explicit-v2-goals.json').read_text())['rows']:
 raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 if x['kind']=='drop':
  position=replace(s.state.position,hands=(Hands((('R',1),)),Hands()));key=position_identity_key(position,c);state=replace(s.state,position=position,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),));s._state=replace(state,terminal_status=terminal_result(state,c));s._search_history_witnesses=(position,)
 assert record_value(s.state)==x['root_state'];hint,=[a for a in s.legal_actions()if record_value(a)==x['result']['action']];v={t:0 if m.is_anchor else 100for t,m in c.support.type_metadata.items()};nr=nc.compile_native_semantic_rules(c,backend_module=wide)
 for order in range(4):
  pair={}
  for arm in (list(classes)if order%2==0 else list(classes)[::-1]):
   e=classes[arm](c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=4,max_nodes=128,max_time_seconds=5,quiescence_max_depth=4),root_window_pruning=True,root_order_hint=hint,stop_on_immediate_win=True);wall=time.perf_counter()-t;assert r.immediate_win and r.action==hint;validate(r,s,nr);pair[arm]=signature(r);rows.append({'kind':x['kind'],'order':order,'arm':arm,'caller_seconds':wall,'result':record_value(r)})
  if pair['CoreBaseline']!=pair['CheckedNative']:errors.append(x['kind'])
(b/'goal-cost-results.json').write_text(json.dumps({'complete':True,'rows':rows,'errors':errors}),encoding='utf-8');assert not errors
print('complete',len(rows),errors)
