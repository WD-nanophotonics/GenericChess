from pathlib import Path
import sys,json,inspect,importlib.util,time,traceback
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];b=R/'.local_agent/pv-contract-20261015';prior=R/'.local_agent/immediate-goal-20261015'
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import _module
import generic_chess.native.compiler as nc
from generic_chess.native import semantic as sem
import generic_chess.native.semantic_engine as em
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.declarations import available_declarations
from generic_chess.ai.limits import SearchLimits
source=Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8-sig');exec(source[source.index('def case('):source.index('\ndef check(')],globals())
classes={}
for name,file in [('CoreBaseline','baseline_search.py'),('CheckedNative','checked_native_search.py')]:
 space=dict(em.__dict__);space['apply_action']=apply_action;exec(compile((b/file).read_text(),file,'exec'),space);classes[name]=type(name,(SemanticSearchEngine,),{'search':space['search']})
spec=importlib.util.spec_from_file_location('callerwide._native_core',next(prior.glob('final_v2*.pyd')));wide=importlib.util.module_from_spec(spec);spec.loader.exec_module(wide)
def signature(r):return {k:v for k,v in record_value(r).items() if 'elapsed'not in k}
def validate(r,s,nr):
 state=s.state;pos=pack_semantic_search_position(s.compiled,nr,s)
 for a in r.decision_line:
  if isinstance(a,str):assert any(d.declaration_id==a for d in available_declarations(state,s.compiled));break
  raw=pack_semantic_action(nr,state.position,a);pos=sem.make_checked(nr,pos,raw);state=apply_action(state,a,s.compiled);snap=sem.snapshot(nr,pos);expected=expected_snapshot(state.position,nr,s.compiled)
  for key in ('board','hands','aux_state','side'):assert record_value(snap[key])==record_value(expected[key]),key
  assert sem.position_key(nr,pos)==str(position_identity_key(state.position,s.compiled)) and snap['history_exact'] and snap['history_events_exact']
 if r.immediate_win:assert state.terminal_status.is_terminal and state.terminal_status.winner==s.state.position.side_to_move
 return record_value(state.terminal_status)
