from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
study=sys.argv[1];plan=json.loads((b/'plan.json').read_text());rows=[];roots=[];errors=[];start=time.perf_counter()
inputs=json.loads((prior/'v2-boundary-inputs.json').read_text()) if study=='fixed' else json.loads((b/'inputs.json').read_text())['samples']
def save(complete=False,error=None):(b/(study+'-results.json')).write_text(json.dumps({'complete':complete,'rows':rows,'roots':roots,'errors':errors,'seconds':time.perf_counter()-start,'error':error}),encoding='utf-8')
try:
 for index,x in enumerate(inputs):
  p.rr.stopped()
  if not x.get('included',True):continue
  c,s=case(x);before=record_value(s.to_record());nr=nc.compile_native_semantic_rules(c,backend_module=wide if study=='fixed' else _module());pos=pack_semantic_search_position(c,nr,s)
  assert set(sem.transient_legal_actions(nr,pos))=={pack_semantic_action(nr,s.state.position,a)for a in s.legal_actions()}
  profile=p.build_ruleset_profile(c,p.EvaluationConfig());v={t:int(round(z)) for t,z in profile.board_value_by_type.items()};h={t:int(round(z))for t,z in profile.hand_value_by_base_type.items()};roots.append({'name':x['name'],'n':c.board_size,'board_values':v,'hand_values':h,'backend':nr.backend_module.native_capabilities(),'legal_and_state_checked':True})
  for name in (list(classes) if index%2==0 else list(classes)[::-1]):
   classes[name](c,nr,board_values=v,hand_values=h,tt_megabytes=0).search(s,SearchLimits(max_depth=1,max_nodes=32,max_time_seconds=1))
  settings=plan['fixed']['q'] if study=='fixed' else plan['resource']['seconds']
  for setting in settings:
   for order in (0,1):
    pair={}
    for arm in (list(classes)if order==0 else list(classes)[::-1]):
     if time.perf_counter()-start>plan['fuse_seconds']:raise TimeoutError('1800s frozen fuse')
     lim=SearchLimits(max_depth=4 if study=='fixed'else 12,max_nodes=1024 if study=='fixed'else None,max_time_seconds=5 if study=='fixed'else setting,quiescence_max_depth=setting if study=='fixed'else 4,quiescence_hard_max_depth=8)
     e=classes[arm](c,nr,board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,lim,root_window_pruning=True);wall=time.perf_counter()-t;terminal=validate(r,s,nr);assert record_value(s.to_record())==before;pair[arm]=signature(r);rows.append({'root':x['name'],'setting':setting,'order':order,'arm':arm,'caller_seconds':wall,'result':record_value(r),'selected_PV_leaf_terminal':terminal})
    if study=='fixed'and pair['CoreBaseline']!=pair['CheckedNative']:errors.append({'root':x['name'],'setting':setting,'order':order,'fields':[k for k in pair['CoreBaseline']if pair['CoreBaseline'][k]!=pair['CheckedNative'].get(k)]})
  save();print(study,x['name'],len(rows),round(time.perf_counter()-start,2),flush=True)
 save(True);assert not errors,errors;print('COMPLETE',study,len(rows),flush=True)
except BaseException:save(False,traceback.format_exc());raise
