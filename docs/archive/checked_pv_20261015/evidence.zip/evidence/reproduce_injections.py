from pathlib import Path
import sys,inspect,json
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
import generic_chess.native.semantic_engine as em
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native import semantic as sem
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from test_native_terminal_declaration_priority import position
from scripts.research_record import record_value
b=R/'.local_agent/pv-contract-20261015'
source=(R/'.local_agent/pv-contract-20261015/baseline_search.py').read_text()
base_space=dict(em.__dict__);base_space['apply_action']=apply_action;exec(source,base_space)
class Baseline(em.SemanticSearchEngine):search=base_space['search']
old='    state = session.state\n    for pv_action in pv:\n        state = apply_action(state, pv_action, self._compiled)\n'
assert old in source
space=dict(em.__dict__);space['apply_action']=apply_action;exec(source.replace(old,''),space)
class Candidate(em.SemanticSearchEngine):search=space['search']
class Proxy:
 def __init__(self,backend,payload):self.backend=backend;self.payload=payload
 def __getattr__(self,k):return getattr(self.backend,k)
 def semantic_engine_search(self,*a):return self.payload
rows=[]
def query(name,s,mutate):
 nr=compile_native_semantic_rules(s.compiled);e=em.SemanticSearchEngine(s.compiled,nr,tt_megabytes=0);lim=SearchLimits(max_depth=1,max_time_seconds=3)
 pos=pack_semantic_search_position(s.compiled,nr,s);raw=dict(e._backend.semantic_engine_search(e._capsule,pos,1,100,None,None,None,False,False));codes=mutate(s,nr,pos,raw);raw['principal_variation']=codes
 if codes and not(codes[0]&(1<<63)):raw['best_action']=codes[0]
 for cls in (Baseline,Candidate):
  en=cls(s.compiled,nr,tt_megabytes=0);en._backend=Proxy(en._backend,raw)
  try:r=en.search(s,lim);out={'accepted':True,'decision_line':record_value(r.decision_line)}
  except Exception as ex:out={'accepted':False,'error_type':type(ex).__name__,'error':str(ex)}
  rows.append({'case':name,'caller':cls.__name__,'raw_codes':list(codes),'outcome':out})
 print(name,rows[-2]['outcome']['accepted'],rows[-1]['outcome']['accepted'],flush=True)
def terminal_then_move(s,nr,pos,raw):
 # Max-ply terminal after one ordinary action, followed by an otherwise legal raw edge.
 a=s.legal_actions()[0];child=apply_action(s.state,a,s.compiled);c1=pack_semantic_action(nr,s.state.position,a);cp=sem.make_checked(nr,pos,c1)
 assert child.terminal_status.is_terminal
 # Native transition must reject maxply itself; keep the raw attempted identity.
 return (c1,c1)
def declaration_then_board(s,nr,pos,raw):
 a=s.legal_actions()[0];return ((1<<63),pack_semantic_action(nr,s.state.position,a))
def invalid_actor(s,nr,pos,raw):
 a=s.legal_actions()[0];code=pack_semantic_action(nr,s.state.position,a);f=sem.unpack_action(code,native_rules=nr);f['actor_current']=(f['actor_current']+1)%len(nr.type_ids);return (sem.pack_action(f,native_rules=nr),)
def plain(s,nr,pos,raw):return tuple(raw['principal_variation'])
query('valid',position(),plain)
query('maxply_then_move',position(max_ply=1),terminal_then_move)
query('root_declaration_then_board',position(declaring_owner=0),declaration_then_board)
query('malformed_current_actor',position(),invalid_actor)

from test_native_history import _cycle_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
import generic_chess.rules.compiler as helpers
original=helpers.compile_ruleset;helpers.compile_ruleset=lambda rules:rules
try:rules=_cycle_ruleset()
finally:helpers.compile_ruleset=original
c=compile_legacy_ruleset_for_semantic_execution(rules)
ss=GameSession(c)
for i in range(11):ss.submit(ss.legal_actions()[0])
def repeat_then_move(s,nr,pos,raw):
 a=s.legal_actions()[0];c1=pack_semantic_action(nr,s.state.position,a);cp=sem.make_checked(nr,pos,c1);child=apply_action(s.state,a,s.compiled)
 assert child.terminal_status.is_terminal
 actions=sem.transient_legal_actions(nr,cp);assert actions
 return (c1,actions[0])
query('repetition_then_legal_edge',ss,repeat_then_move)
(b/'reproduced-injection-results.json').write_text(json.dumps({'complete':True,'rows':rows},indent=2),encoding='utf-8')
