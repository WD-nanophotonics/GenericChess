from pathlib import Path
import sys,json,time,hashlib,gc,traceback
R=Path.cwd();sys.path.insert(0,str(R));b=R/'.local_agent/pv-contract-20261015'
import generic_chess.rules.compiler as c
from generic_chess.rules.serialization import deserialize_ruleset
ns=dict(c.__dict__);exec((b/'cached_geometry.py').read_text(),ns);fns={'baseline':c._build_tables,'cached':ns['_build_tables']};rows=[];errors=[];start=time.perf_counter()
inputs=[{'name':f'{seed}-first32','ruleset':json.loads((b/f'geometry-input-{seed}.json').read_text(encoding='utf-8'))}for seed in [3741,3742,4051]]
inputs +=[x for x in json.loads((b/'inputs.json').read_text())['samples']if x['name'].endswith('ply0')]
try:
 for x in inputs:
  rule=deserialize_ruleset(json.dumps(x['ruleset']));byatom={a for t in rule.piece_types for a in t.movement_atoms};occ=sum(len(t.movement_atoms)for t in rule.piece_types)
  for order in (0,1):
   pair={}
   for arm in (list(fns)if order==0 else list(fns)[::-1]):
    if time.perf_counter()-start>600:raise TimeoutError('600s geometry fuse')
    gc.collect();t=time.perf_counter();tables=fns[arm](rule);wall=time.perf_counter()-t;digest=hashlib.sha256(repr(tables).encode()).hexdigest();pair[arm]=digest;del tables;rows.append({'root':x['name'],'n':rule.board_size,'atom_occurrences':occ,'distinct_atoms':len(byatom),'order':order,'arm':arm,'seconds':wall,'full_ordered_table_repr_sha256':digest})
   if pair['baseline']!=pair['cached']:errors.append({'root':x['name'],'order':order})
  (b/'geometry-results.json').write_text(json.dumps({'complete':False,'rows':rows,'errors':errors,'seconds':time.perf_counter()-start}),encoding='utf-8');print(x['name'],len(rows),time.perf_counter()-start,flush=True)
 (b/'geometry-results.json').write_text(json.dumps({'complete':True,'rows':rows,'errors':errors,'seconds':time.perf_counter()-start}),encoding='utf-8');assert not errors
except BaseException:
 (b/'geometry-results.json').write_text(json.dumps({'complete':False,'rows':rows,'errors':errors,'error':traceback.format_exc(),'seconds':time.perf_counter()-start}),encoding='utf-8');raise
