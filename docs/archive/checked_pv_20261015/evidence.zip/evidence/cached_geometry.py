def _build_tables(ruleset: RuleSet) -> dict[str, Any]:
    """Precompute all geometry tables on an empty board."""
    shape = ruleset.board_shape
    leap_targets: dict[str, Any] = {}
    ray_paths: dict[str, Any] = {}
    empty_mobility: dict[str, Any] = {}
    empty_forward_mobility: dict[str, Any] = {}

    atom_paths = {}
    for pt in ruleset.piece_types:
        per_player_leap: list[Any] = []
        per_player_ray: list[Any] = []
        per_player_mob: list[Any] = []
        per_player_fwd: list[Any] = []
        for player in (0, 1):
            per_square_leap: list[Any] = []
            per_square_ray: list[Any] = []
            per_square_mob: list[Any] = []
            per_square_fwd: list[Any] = []
            for idx in range(shape.area):
                sq = index_to_square(idx, shape)
                atom_leap: list[tuple[Square, ...]] = []
                atom_ray: list[tuple[Square, ...]] = []
                seen: set[Square] = set()
                mob: list[Square] = []
                for atom in pt.movement_atoms:
                    key = (player, atom)
                    if key not in atom_paths:
                        atom_paths[key] = tuple(
                            _atom_targets(shape, player, index_to_square(j, shape), atom)
                            for j in range(shape.area)
                        )
                    targets = atom_paths[key][idx]
                    if isinstance(atom, LeapAtom):
                        atom_leap.append(targets)
                        atom_ray.append(())
                    else:
                        atom_leap.append(())
                        atom_ray.append(targets)
                    for tgt in targets:
                        if tgt not in seen:
                            seen.add(tgt)
                            mob.append(tgt)
                per_square_leap.append(tuple(atom_leap))
                per_square_ray.append(tuple(atom_ray))
                per_square_mob.append(tuple(mob))
                per_square_fwd.append(
                    tuple(t for t in mob if _is_forward_target(sq, t, player))
                )
            per_player_leap.append(tuple(per_square_leap))
            per_player_ray.append(tuple(per_square_ray))
            per_player_mob.append(tuple(per_square_mob))
            per_player_fwd.append(tuple(per_square_fwd))
        leap_targets[pt.type_id] = tuple(per_player_leap)
        ray_paths[pt.type_id] = tuple(per_player_ray)
        empty_mobility[pt.type_id] = tuple(per_player_mob)
        empty_forward_mobility[pt.type_id] = tuple(per_player_fwd)

    return {
        "leap_targets": leap_targets,
        "ray_paths": ray_paths,
        "empty_mobility": empty_mobility,
        "empty_forward_mobility": empty_forward_mobility,
    }
