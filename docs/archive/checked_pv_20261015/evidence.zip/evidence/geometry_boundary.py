from pathlib import Path
import sys,json
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));b=R/'.local_agent/pv-contract-20261015'
import generic_chess.rules.compiler as c
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.core.movement import LeapAtom,RayAtom
ns=dict(c.__dict__);exec((b/'cached_geometry.py').read_text(),ns)
x=json.loads((b/'input-4011.json').read_text())['samples'][0];r=deserialize_ruleset(json.dumps(x['ruleset']));rows=[]
for kind in ('leap','ray'):
 changed=[];found=False
 for pt in r.piece_types:
  atoms=[]
  for atom in pt.movement_atoms:
   if not found and ((kind=='leap'and isinstance(atom,LeapAtom))or(kind=='ray'and isinstance(atom,RayAtom))):
    atom=replace(atom,offset=list(atom.offset))if kind=='leap'else replace(atom,direction=list(atom.direction));found=True
   atoms.append(atom)
  changed.append(replace(pt,movement_atoms=tuple(atoms)))
 if not found:continue
 rr=replace(r,piece_types=tuple(changed));baseline=c._build_tables(rr);assert baseline==c._build_tables(r)
 try:ns['_build_tables'](rr);error=None
 except Exception as e:error={'type':type(e).__name__,'message':str(e)}
 rows.append({'kind':kind,'baseline_accepts_same_finite_behavior':True,'private_cache_error':error})
(b/'geometry-boundary.json').write_text(json.dumps(rows,indent=2));print(rows)
