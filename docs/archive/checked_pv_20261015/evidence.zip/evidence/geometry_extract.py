from pathlib import Path
import sys,time,json,inspect
R=Path.cwd();sys.path.insert(0,str(R));b=R/'.local_agent/pv-contract-20261015'
import generic_chess.generation.generator as g
import generic_chess.rules.compiler as c
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
class Captured(BaseException):pass
for seed in [3741,3742,4051]:
 def capture(rules):
  (b/f'geometry-input-{seed}.json').write_text(serialize_ruleset(rules),encoding='utf-8');raise Captured()
 old=g.compile_ruleset;g.compile_ruleset=capture
 try:g.generate_game(GeneratorConfig(seed=seed,board_size=32,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32))
 except Captured:print(seed,'captured first full geometry input',flush=True)
 finally:g.compile_ruleset=old
source=inspect.getsource(c._build_tables);assert 'targets = _atom_targets(shape, player, sq, atom)'in source
source=source.replace('    for pt in ruleset.piece_types:', '    atom_paths = {}\n    for pt in ruleset.piece_types:',1)
source=source.replace('                    targets = _atom_targets(shape, player, sq, atom)', '''                    key = (player, atom)
                    if key not in atom_paths:
                        atom_paths[key] = tuple(
                            _atom_targets(shape, player, index_to_square(j, shape), atom)
                            for j in range(shape.area)
                        )
                    targets = atom_paths[key][idx]''')
(b/'cached_geometry.py').write_text(source,encoding='utf-8')
