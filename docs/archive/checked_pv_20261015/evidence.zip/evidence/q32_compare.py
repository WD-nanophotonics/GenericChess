from pathlib import Path
import subprocess,json,sys,time
b=Path('.local_agent/pv-contract-20261015');plan=json.loads((b/'q32-plan.json').read_text());start=time.perf_counter();rows=[]
for seed in plan['families']:
 path=b/f'generation-{seed}-base1024.json'
 while not path.exists() and time.perf_counter()-start<plan['fuse_seconds']:
  generation=json.loads((b/'generation-results.json').read_text())
  if generation['complete'] or any(r['seed']==seed and r['arm']=='base1024' for r in generation['rows']):break
  time.sleep(1)
 if not path.exists():rows.append({'seed':seed,'status':'input_missing','planned_queries':12});continue
 remaining=plan['fuse_seconds']-(time.perf_counter()-start)
 if remaining<=0:rows.append({'seed':seed,'status':'unstarted_fuse','planned_queries':12});continue
 t=time.perf_counter()
 try:
  r=subprocess.run([sys.executable,str(b/'q32_one.py'),str(seed)],capture_output=True,timeout=min(250,remaining));data=r.stdout+r.stderr;status='complete'if r.returncode==0 else'failed'
 except subprocess.TimeoutExpired as e:data=(e.stdout or b'')+(e.stderr or b'');status='family_or_batch_censored'
 (b/f'q32-{seed}.log').write_bytes(data);rows.append({'seed':seed,'status':status,'seconds':time.perf_counter()-t,'planned_queries':12});(b/'q32-results.json').write_text(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start}));print(rows[-1],flush=True)
(b/'q32-results.json').write_text(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start}))
