import sys,sysconfig,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
p=ROOT/'.local_agent/core-consumer-20261013/actor-first'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
sp=importlib.util.spec_from_file_location('threshold_full._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m
import pytest
raise SystemExit(pytest.main(['tests/product/test_native_attack_guard_continuation.py','-q','-p','no:cacheprovider']))
