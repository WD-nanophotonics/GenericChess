from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import pytest
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(ROOT/'.local_agent/core-consumer-20261013/combined-actor-tests-temp'),'--junitxml',str(ROOT/'.local_agent/core-consumer-20261013/combined-actor-tests.xml')]))
