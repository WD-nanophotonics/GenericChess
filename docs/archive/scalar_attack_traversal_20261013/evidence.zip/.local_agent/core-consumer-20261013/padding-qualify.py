import sys,importlib.util,subprocess,ctypes,hashlib,random,json
from pathlib import Path
P=Path(__file__).parent;src=P.parents[1]/'generic_chess/_native';zig=Path(importlib.util.find_spec('ziglang').origin).parent/'zig.exe';mods={}
for name,file in [('old',src/'native_sha256.c'),('padding',P/'padding-native_sha256.c')]:
 out=P/(name+'-sha-test.dll');r=subprocess.run([str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+str(src),str(P/'sha-test.c'),str(file),'-o',str(out)],capture_output=True,text=True);assert r.returncode==0,r.stderr
 dll=ctypes.CDLL(str(out.resolve()));dll.test_digest.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_void_p];mods[name]=dll
rng=random.Random(2026101341);count=0
for size in list(range(257))+[511,512,513,1023,1024,1025,4096]:
 data=rng.randbytes(size);expect=hashlib.sha256(data).digest()
 for chunk in [1,3,55,56,63,64,65,127,4096]:
  states=[]
  for name,dll in mods.items():
   digest=(ctypes.c_ubyte*32)();state=(ctypes.c_ulonglong*10)();dll.test_digest(data,len(data),chunk,digest,state);assert bytes(digest)==expect,(name,size,chunk);states.append(list(state))
  assert states[0]==states[1],(size,chunk,states);count+=1
(P/'padding-qualification.json').write_text(json.dumps({'digest_and_final_internal_state_cases':count,'all_match_hashlib_and_old':True,'sizes':'0..256,511/512/513/1023/1024/1025/4096','chunks':[1,3,55,56,63,64,65,127,4096]},indent=2))
print(count,'passed exact digest andctxstate')
