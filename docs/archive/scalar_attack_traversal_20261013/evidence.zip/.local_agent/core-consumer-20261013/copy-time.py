from pathlib import Path
import sys,sysconfig,os,subprocess,importlib.util,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent;src=ROOT/'generic_chess/_native';mod=(OUT/'reuse-native_module.c').read_text(encoding='utf-8')

pool=r"""
static int gc_test_enabled=0;
int gc_test_purpose=0;
GCSemanticRuntimeAudit gc_test_pool[5];
uint64_t gc_test_copies[5],gc_test_fixed_bytes[5],gc_test_history_bytes[5],gc_test_copy_ns[5];
extern uint64_t gc_test_key_counts[5],gc_test_key_serial[5],gc_test_key_sha[5];
static int gc_test_enter(int p){int old=gc_test_purpose;if(gc_test_enabled){gc_test_purpose=p;gc_semantic_runtime_audit_start(&gc_test_pool[p]);}return old;}
static void gc_test_leave(int p){if(gc_test_enabled){gc_test_purpose=p;gc_semantic_runtime_audit_start(&gc_test_pool[p]);}}
static PyObject *gc_test_reset(PyObject*self,PyObject*args){(void)self;(void)args;memset(gc_test_pool,0,sizeof(gc_test_pool));memset(gc_test_copies,0,sizeof(gc_test_copies));memset(gc_test_copy_ns,0,sizeof(gc_test_copy_ns));memset(gc_test_fixed_bytes,0,sizeof(gc_test_fixed_bytes));memset(gc_test_history_bytes,0,sizeof(gc_test_history_bytes));memset(gc_test_key_counts,0,5*sizeof(uint64_t));memset(gc_test_key_serial,0,5*sizeof(uint64_t));memset(gc_test_key_sha,0,5*sizeof(uint64_t));gc_test_enabled=1;gc_test_purpose=0;gc_semantic_runtime_audit_start(&gc_test_pool[0]);Py_RETURN_NONE;}
static PyObject *gc_test_read(PyObject*self,PyObject*args){(void)self;(void)args;gc_test_enabled=0;gc_semantic_runtime_audit_stop();PyObject *out=PyList_New(0);for(int i=0;i<5;i++){GCSemanticRuntimeAudit*a=&gc_test_pool[i];PyObject*r=Py_BuildValue("{s:i,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K}","purpose",i,"s3",a->s3_trial_count,"s4",a->s4_count,"nested",a->nested_reply_count,"child_keys",a->child_canonical_key_computations,"history_appends",a->history_appends,"attack_checks",a->attack_check_calls,"copy_calls",gc_test_copies[i],"fixed_copy_bytes",gc_test_fixed_bytes[i],"history_copy_bytes",gc_test_history_bytes[i],"key_calls",gc_test_key_counts[i],"key_serial_ns",gc_test_key_serial[i],"key_sha_ns",gc_test_key_sha[i],"copy_ns",gc_test_copy_ns[i]);PyList_Append(out,r);Py_DECREF(r);}return out;}
"""
pool+=r"""
static PyObject *gc_test_calibrate(PyObject*self,PyObject*args){(void)self;(void)args;PyObject*out=PyList_New(0);for(int repeat=0;repeat<8;repeat++){uint64_t total=0,begin=gc_monotonic_ns();for(int j=0;j<1000000;j++){uint64_t t=gc_monotonic_ns();total+=gc_monotonic_ns()-t;}uint64_t elapsed=gc_monotonic_ns()-begin;PyObject*r=Py_BuildValue("{s:i,s:K,s:K}","calls",1000000,"empty_span_ns",total,"whole_loop_ns",elapsed);PyList_Append(out,r);Py_DECREF(r);}return out;}
"""
mod=mod.replace('#define GC_RULES_CAPSULE',pool+'#define GC_RULES_CAPSULE',1)
def wrap(name,signature,call,purpose):
 global mod
 begin=mod.index('static '+signature.split(' ',1)[0]+' '+name+'(')
 end=mod.index('\nstatic ',begin+1)
 part=mod[begin:end].replace(name+'(',name+'_instrumented_impl(',1)
 wrapper='\nstatic '+signature+' {int prev=gc_test_enter('+str(purpose)+');int value='+name+'_instrumented_impl('+call+');gc_test_leave(prev);return value;}\n'
 mod=mod[:begin]+part+wrapper+mod[end:]
wrap('gc_semantic_has_guarded_action_impl','int gc_semantic_has_guarded_action_impl(const GCSemanticRules *rules,const GCSemanticPosition *position,int *ok,GCSemanticRuntimeAudit *audit)','rules,position,ok,audit',2)
wrap('gc_semantic_terminal_status_known','int gc_semantic_terminal_status_known(const GCSemanticRules *rules,const GCSemanticPosition *position,int *winner_out,const uint64_t *known)','rules,position,winner_out,known',4)
wrap('gc_semantic_order_actions','int gc_semantic_order_actions(GCSemanticIterativeContext *ctx,GCSemanticPosition *position,uint32_t ply,uint32_t depth,GCSemanticActionBuffer *actions)','ctx,position,ply,depth,actions',3)
needle='    {"semantic_make_checked", gc_semantic_make_checked, METH_VARARGS,'
mod=mod.replace(needle,'    {"test_copy_calibrate",gc_test_calibrate,METH_NOARGS,"Private clock calibration"},\n    {"test_purpose_reset",gc_test_reset,METH_NOARGS,"Private counters"},\n    {"test_purpose_read",gc_test_read,METH_NOARGS,"Private counters"},\n'+needle)
(OUT/'copy-time-native_module.c').write_text(mod,encoding='utf-8')
key=(src/'native_semantic_key.c').read_text(encoding='utf-8')
key='#include "native_clock.h"\nextern int gc_test_purpose;\nuint64_t gc_test_key_counts[5],gc_test_key_serial[5],gc_test_key_sha[5];\n'+key
key=key.replace('char out_hex[65]) {','char out_hex[65]) {\n    uint64_t started=gc_monotonic_ns();int purpose=gc_test_purpose;gc_test_key_counts[purpose]++;',1)
key=key.replace('GCSha256 sha;uint8_t digest[32];','uint64_t sha_start=gc_monotonic_ns();gc_test_key_serial[purpose]+=sha_start-started;GCSha256 sha;uint8_t digest[32];')
key=key.replace('free(b.data);return 1;','gc_test_key_sha[purpose]+=gc_monotonic_ns()-sha_start;free(b.data);return 1;')
(OUT/'copy-time-native_semantic_key.c').write_text(key,encoding='utf-8')
runtime=(src/'native_semantic_runtime.c').read_text(encoding='utf-8')
runtime=runtime.replace('#include <string.h>','#include <string.h>\nextern int gc_test_purpose;extern GCSemanticRuntimeAudit gc_test_pool[5];extern uint64_t gc_test_copies[5],gc_test_fixed_bytes[5],gc_test_history_bytes[5],gc_test_copy_ns[5];')
runtime=runtime.replace('    memcpy(dst, src, fixed_bytes);','    uint64_t copy_started=gc_monotonic_ns();gc_test_copies[gc_test_purpose]++;gc_test_fixed_bytes[gc_test_purpose]+=fixed_bytes+sizeof(GCSemanticPosition)-offsetof(GCSemanticPosition,history_len);gc_test_history_bytes[gc_test_purpose]+=history_bytes*(sizeof(uint64_t)*2+sizeof(src->history_digest[0])+sizeof(uint8_t)*2);\n    memcpy(dst, src, fixed_bytes);',1)
runtime='#include "native_clock.h"\n'+runtime
runtime=runtime.replace('sizeof(GCSemanticPosition) - offsetof(GCSemanticPosition, history_len));','sizeof(GCSemanticPosition) - offsetof(GCSemanticPosition, history_len));\n    gc_test_copy_ns[gc_test_purpose]+=gc_monotonic_ns()-copy_started;',1)
old='    return gc_semantic_runtime_make_mode(child, r, parent, action, 1, !gc_runtime_transient);'
assert runtime.count(old)==1
runtime=runtime.replace(old,'    int prev=gc_test_purpose;if(prev==0){gc_test_purpose=1;gc_semantic_runtime_audit_start(&gc_test_pool[1]);}\n    int status=gc_semantic_runtime_make_mode(child,r,parent,action,1,!gc_runtime_transient);\n    gc_test_purpose=prev;gc_semantic_runtime_audit_start(&gc_test_pool[prev]);return status;')
(OUT/'copy-time-native_semantic_runtime.c').write_text(runtime,encoding='utf-8')
spec=importlib.util.find_spec('ziglang');zig=Path(spec.origin).parent/'zig.exe';binary=OUT/('copy_time_kernel/_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));binary.parent.mkdir(exist_ok=True)
cmd=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(OUT/'copy-time-native_module.c' if x.name=='native_module.c' else OUT/'copy-time-native_semantic_key.c' if x.name=='native_semantic_key.c' else OUT/'copy-time-native_semantic_runtime.c' if x.name=='native_semantic_runtime.c' else x) for x in sorted(src.glob('*.c'))]+['-o',str(binary)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(OUT/'counter-zig-cache')));assert built.returncode==0,built.stderr
spec=importlib.util.spec_from_file_location('counter_test._native_core',binary);kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
import generic_chess.native as native
native._MODULE=kernel

from generic_chess import compile_ruleset_for_execution,build_builtin_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.material import LearnableMaterialCheckpoint
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from scripts.research_record import write_record,record_value
from types import SimpleNamespace
write_record(OUT/'copy-time-declaration.json',dict(question='Is the remaining live-prefix memcpy span significant after installed exactidentity reuse? Adjacent-clock overhead before andafter same existingShogiD5; counts/output checked against frozenreuse purpose; no speedranking or inferred cost frombytes.',case='shogi-middle',depth=5,node_cap=1000000,seconds=64,calls=1,scope='One nonmillisecond existing root/cap, currentthreshold candidate; key/timer/copy instrumentation private, not speedranking. Purpose0=import/other,1=requiredcheckedchild+canonicalPVfullmakes,2=readonlyavailability inclnested,3=ordering views,4=terminal afteravailability. Prefix memcpy bytes modeled explicit actual source copies, nothardwaretraffic/RSS. No full-history removal or alternate engine.' ))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));case=next(x for x in CASES if x['id']=='shogi-middle');b=CoreBoard(case,c);session=SimpleNamespace(compiled=c,state=b.initial,_search_witnesses=b.witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));nr=compile_native_semantic_rules(c)
ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
e=SemanticSearchEngine(c,nr,board_values=VALUES['shogi'],hand_values=VALUES['shogi'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2,ordering_cache_enabled=False)
before_calibration=kernel.test_copy_calibrate();kernel.test_purpose_reset();started=time.perf_counter();result=e.search(session,SearchLimits(max_depth=5,max_nodes=1000000,max_time_seconds=64,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);counts=kernel.test_purpose_read();elapsed=time.perf_counter()-started
after_calibration=kernel.test_copy_calibrate()
assert result.completed_depth==5 and result.termination_reason!='internal_error';assert session.state==b.initial
write_record(OUT/'copy-time-result.json',dict(result=record_value(result),counts=counts,instrumented_seconds=elapsed,root_restored=True,before_calibration=before_calibration,after_calibration=after_calibration));print(result.completed_depth,result.score,round(elapsed,3));print(counts)
