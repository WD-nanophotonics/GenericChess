from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/alias-teacher-20261016')]
from core_teacher import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,SearchLimits,record_value,write_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules

def main():
 old=json.loads((P/'fixed-node-recovered-results.json').read_bytes());refs=[r for r in old['rows']if r['arm']=='candidate'];plan=dict(question='Does rebuilt installedproduct bind the qualified private dynamic implementation under allfrozen finite-node controls?',slots=len(refs),nodes=512,seconds=None,whole_seconds=180,expected_seconds=30,scope='Actualinstalledproductbinding, allnon-timefields comparetoprivateprototype. No timingcomparison becauseotherownedtests mayrun, no newgames/learning ornewscientificpopulation.')
 write_record(P/'product-binding-plan.json',plan);rows=[];cached={};start=time.perf_counter()
 for ref in refs:
  seed=ref['seed']
  if seed not in cached:
   d=json.loads((P/'fresh-roots'/f'{seed}.json').read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=compile_native_semantic_rules(c);cached[seed]=(c,s,nr)
  c,s,nr=cached[seed];bv={t.type_id:0 if t.is_anchor else 100 for t in c.piece_types};before=record_value(s.state);pol=ref['policy'];e=SemanticSearchEngine(c,nr,board_values=bv,hand_values=bv,dynamic_values=(2,3,5),tt_megabytes=0,ordering_cache_enabled=False);r=e.search(s,SearchLimits(max_depth=pol['depth'],max_nodes=512,max_time_seconds=None,quiescence_max_depth=pol['q'],quiescence_hard_max_depth=8 if pol['q']else 0),root_window_pruning=True);result=record_value(r);assert{k:v for k,v in result.items()if k!='elapsed_seconds'}=={k:v for k,v in ref['result'].items()if k!='elapsed_seconds'};assert record_value(s.state)==before;rows.append(dict(seed=seed,board=ref['board'],policy=pol,result=result,root_restored=True));write_record(P/'product-binding-progress.json',dict(complete=False,rows=rows));assert time.perf_counter()-start<180
 write_record(P/'product-binding-results.json',dict(complete=True,rows=rows,queries=len(rows),seconds=time.perf_counter()-start,scope=plan['scope']));print('PRODUCT_BINDING_PASS',len(rows),time.perf_counter()-start)
if __name__=='__main__':main()
