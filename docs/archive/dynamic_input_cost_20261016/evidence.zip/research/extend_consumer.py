from pathlib import Path
P=Path('.local_agent/dynamic-input-20261016');s=(P/'consumer.py').read_text();s=s.replace("('product-binding-results.json',True)]","('product-binding-results.json',True),('reuse-results.json',True),('reuse-product-results.json',True)]");(P/'consumer.py').write_bytes(s.encode())
