from pathlib import Path
from copy import copy
import sys,json,time,statistics,hashlib
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';sys.path[:0]=[str(P),str(R)];from component import *
from generic_chess.learning.nonlinear import semantic_state_features,CompactNonlinearResidual

def main():
 reuse=loadmodule('reuse');counter=loadmodule('feature_counter');fresh=json.loads((P/'fresh-recovered-results.json').read_bytes());cases=[r for r in fresh['rows']if r['kind']=='EXECUTED_ROOT'and r['board']<16];select=[r for b in(4,8,12)for r in[r for r in cases if r['board']==b][:2]];plan=json.loads((P/'reuse-plan.json').read_bytes());plan['selected_search_seeds']=[r['seed']for r in select];plan['actual_direct_states']=2*len(cases);write_record(P/'reuse-execution-plan.json',plan);start=time.perf_counter();direct=[];queries=[];loaded={}
 for case in cases:
  stopped();d=json.loads((P/case['root']).read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=reuse if a=='reuse'else counter)))for a in('normal','reuse','counter')};payload=json.loads((P/'nonzero-payloads'/f"{case['seed']}.json").read_bytes());loaded[case['seed']]=(c,s,nrs,payload)
  children=[(None,s)];aa=s.legal_actions()
  if aa:
   child=copy(s);child.submit(sorted(aa,key=repr)[0]);children.append((sorted(aa,key=repr)[0],child))
  for ac,ss in children:
   packs={a:pack_semantic_search_position(c,nr,ss)for a,nr in nrs.items()};fv=sem.dynamic_features(nrs['normal'],packs['normal']);model=CompactNonlinearResidual.from_dict(payload);res=float(model.predict(semantic_state_features(ss.state.position,c,fv)));side=1 if ss.state.position.side_to_move==0 else-1
   for name,dyn,comp,wantcalls in[('none',None,None,0),('linear_only',(2,3,5),None,1),('compact_only',None,payload,1),('both',(2,3,5),payload,2)]:
    values={};counter.private_dynamic_calls(True)
    for a,nr in nrs.items():values[a]=sem.evaluate(nr,packs[a],board_values=[0]*len(nr.type_ids),hand_values=[0]*len(nr.type_ids),dynamic_values=dyn,compact_values=comp,evaluator_scale=256)
    actualcalls=counter.private_dynamic_calls(False);expected=(sum(w*f for w,f in zip((2,3,5),fv))if dyn else 0)+(round(res*256)if comp else 0);expected*=side;assert set(values.values())=={expected},(case['seed'],name,values,expected);assert actualcalls==wantcalls,(name,actualcalls,wantcalls);direct.append(dict(seed=case['seed'],board=case['board'],action=record_value(ac),profile=name,values=values,expected=expected,old_dynamic_calls=actualcalls,features=fv))
 for case in select:
  c,s,nrs,payload=loaded[case['seed']];bv={t.type_id:0 if t.is_anchor else 100 for t in c.piece_types};before=record_value(s.state)
  for rep in range(2):
   pair=[]
   for arm in(['normal','reuse']if rep==0 else['reuse','normal']):
    stopped();assert time.perf_counter()-start<180;e=SemanticSearchEngine(c,nrs[arm],board_values=bv,hand_values=bv,dynamic_values=(2,3,5),compact_values=payload,evaluator_scale=256,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);z=dict(seed=case['seed'],board=case['board'],arm=arm,rep=rep,payload=f"nonzero-payloads/{case['seed']}.json",result=record_value(r),caller_seconds=time.perf_counter()-t,root_restored=record_value(s.state)==before);assert z['root_restored'];pair.append(z);queries.append(z);write_record(P/'reuse-progress.json',dict(complete=False,direct=direct,rows=queries))
   assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'};print('REUSE_PAIR',case['seed'],rep,pair[0]['caller_seconds'],pair[1]['caller_seconds'],flush=True)
 ratios=[]
 for b in(4,8,12):
  v=[]
  for seed in[r['seed']for r in select if r['board']==b]:
   for rep in(0,1):
    p={r['arm']:r for r in queries if r['seed']==seed and r['rep']==rep};v.append(p['reuse']['caller_seconds']/p['normal']['caller_seconds'])
  ratios.append(dict(board=b,ratios=v,median_ratio=statistics.median(v)))
 write_record(P/'reuse-results.json',dict(complete=True,direct=direct,rows=queries,queries=len(queries),seconds=time.perf_counter()-start,ratios=ratios,scope=plan['scope']));print('REUSE_DONE',len(direct),len(queries),ratios)
if __name__=='__main__':main()
