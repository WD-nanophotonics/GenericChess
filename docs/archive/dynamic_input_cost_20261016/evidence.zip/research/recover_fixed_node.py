from pathlib import Path
import json
P=Path('.local_agent/dynamic-input-20261016');s=(P/'fixed_node.py').read_text();s=s.replace("board_values={t:0 for t in nrs[a].type_ids},hand_values={t:0 for t in nrs[a].type_ids}","board_values=[0]*len(nrs[a].type_ids),hand_values=[0]*len(nrs[a].type_ids)")
s=s.replace("write_record(P/'fixed-node-plan.json',plan);rows=[];evals=[];start=time.perf_counter()","plan['recovery']='First4actualqueries retained in originalJSONL; forwardprofile dict-vs-sequence error corrected; do NOT rerun those slots';write_record(P/'fixed-node-recovered-plan.json',plan);rows=[json.loads(line)for line in(P/'fixed-node-rows.jsonl').read_text().splitlines()];evals=[];start=time.perf_counter()")
s=s.replace("   pair=[]\n   for arm", "   pair=[]\n   if any(r['seed']==case['seed']and r['policy']==pol for r in rows):continue\n   for arm")
s=s.replace("fixed-node-results.json","fixed-node-recovered-results.json");(P/'fixed_node_recovered.py').write_bytes(s.encode());print('RETAINED_ORIGINAL_SLOTS',len((P/'fixed-node-rows.jsonl').read_text().splitlines()))
