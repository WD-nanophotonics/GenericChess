from pathlib import Path
import json,statistics,collections
P=Path('.local_agent/dynamic-input-20261016');d=json.loads((P/'component-results.json').read_bytes());q=json.loads((P/'search-results.json').read_bytes());rows=[]
for b in(4,8,12,16):
 rr=[r for r in d['rows']if r['board']==b];ratios=[]
 for r in rr:
  times={a:statistics.median(x['seconds']for x in r['observations']if x['arm']==a)for a in('normal','candidate')};ratios.append(times['candidate']/times['normal'])
 rows.append(dict(board=b,states=len(rr),median_candidate_ratio=statistics.median(ratios),audit_sums={k:sum(r['audit'][k]for r in rr)for k in('trials','digests','appends','attacks','nested_replies')}))
qr=[]
for b in(4,8,12):
 a=[r for r in q['rows']if r['board']==b];rs=[]
 for seed in sorted({r['seed']for r in a}):
  for rep in(0,1):
   z={r['arm']:r for r in a if r['seed']==seed and r['rep']==rep};rs.append(z['candidate']['caller_seconds']/z['normal']['caller_seconds'])
 qr.append(dict(board=b,pairs=len(rs),median_ratio=statistics.median(rs),ratios=rs))
x=dict(component=rows,search=qr,search_queries=q['queries'],scope='Repeatedexposedparents; cost/control evidence notall-domain/strength. Countertimingsbiased; candidatewithoutcounters.');(P/'analysis.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
memo='''State: ScienceOPEN; PUBLICforDot/Chat; PRIVATE404abandoned NEWuseronly. ProjectGit/Slack sansPII/password/credentials authorized; PRIMARYsandbox/AUXsidemission separate; >1hrun consultDot.
Segment: ACTIVE d927d21b-e8ca-43ff-9ada-e24675ea90a3 UTC2026-10-16T05:30:53.462553+00:00; preserveclock.
Main: Can discarded dynamic child identity be omitted safely andusefully? | qualify private material-view helper prototype on freshcomplete rule states/nonzero models pluscapacity/automatic/nestederrors | 72states exactvectors, countershowsunuseddigests;24D2searchcalls allnon-timeequal withlargecostsaving | broadsemantic/failure qualification before anyproductedit, allfullhistory/PV/fields retained.
Backup1: What changed with AUX71? | retainnewroot1792127450.941029/completeDot1792127562 asownerreport, inspectfixedreportwhenavailable | new teacher/certificate/pricework ownedAUX, conversiontriggernotfullattribution | no competingtraining/solver/crosswrites; actualfixedreadtiers.
Backup2: Is evidence ready? | checkpoint andcompletefreshsource/control qualification then prescribedpublish | rawSlackprivatelysaved first, plans/caps/failures retained | FULLremoteSHA/Publicbytes and executablememo/sessionfinish, noackgate.
Evidence: .local_agent/dynamic-input-20261016/analysis.json andplan.json; normalC39230230 unchanged, candidateprivateonly. PriorPublicaf4a6676 remainsdelivered; no newgames/training/defaultchange.
''';assert len(memo.encode())<=2048;Path('.local_agent/NEXT_WORK.md').write_bytes(memo.encode())
