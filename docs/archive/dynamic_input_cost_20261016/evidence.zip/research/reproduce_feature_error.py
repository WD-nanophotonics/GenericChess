from pathlib import Path
import sys,sysconfig,subprocess,time,shutil,json,importlib.util
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';S=P/'feature-error-before-source';S.mkdir(exist_ok=False)
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
s=(S/'native_module.c').read_text();mark='static int gc_semantic_dynamic_feature_vector(';a=s.index(mark,s.index(mark)+1);b=s.index('static int gc_semantic_compact_residual(',a);part=s[a:b].replace('gc_semantic_dynamic_feature_vector(','gc_test_dynamic_impl(',1);wrapper='''
int gc_test_feature_fault=0,gc_test_feature_scope=0,gc_test_feature_failures=0;
static int gc_semantic_dynamic_feature_vector(const GCSemanticRules *r,const GCSemanticPosition *p,int out[3]) {
 gc_test_feature_scope=1;int ok=gc_test_dynamic_impl(r,p,out);gc_test_feature_scope=0;return ok;
}
static PyObject *gc_test_feature_set(PyObject *self,PyObject *args) {
 (void)self;if(!PyArg_ParseTuple(args,"p",&gc_test_feature_fault))return NULL;gc_test_feature_failures=0;Py_RETURN_NONE;
}
static PyObject *gc_test_feature_get(PyObject *self,PyObject *args) {
 (void)self;(void)args;return PyLong_FromLong(gc_test_feature_failures);
}
''';s=s[:a]+part+wrapper+s[b:];mark='    {"semantic_dynamic_features", gc_semantic_dynamic_features, METH_VARARGS,';s=s.replace(mark,'    {"test_feature_set",gc_test_feature_set,METH_VARARGS,"Privatefault"},\n    {"test_feature_failures",gc_test_feature_get,METH_NOARGS,"Privatefaultcount"},\n'+mark);(S/'native_module.c').write_bytes(s.encode());p=S/'native_semantic_runtime.c';s=p.read_text();mark='static int semantic_has_s3_reply(const GCSemanticRules *r, const GCSemanticPosition *position) {';assert s.count(mark)==1;s=s.replace(mark,mark+'\n    extern int gc_test_feature_fault,gc_test_feature_scope,gc_test_feature_failures;\n    if(gc_test_feature_fault && gc_test_feature_scope){gc_test_feature_failures++;return -1;}');p.write_bytes(s.encode());cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/'feature_error_before_native_core.pyd')];r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr
sys.path[:0]=[str(R/'tests'),str(P),str(R)];from component import sem,compile_native_semantic_rules,record_value,write_record
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.native.mirror import expected_snapshot
from semantic_control import oracle
import phase19b3_s4_fixtures as f
spec=importlib.util.spec_from_file_location('errorbefore._native_core',P/'feature_error_before_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);rows=[]
for name,builder,pos in [('multiple',f.multiple_replies_ruleset,f.multiple_replies_position),('aux',f.full_child_state_ruleset,f.full_child_state_position)]:
 c=compile_semantic_ruleset(builder());p=pos(c.support);nr=compile_native_semantic_rules(c,backend_module=m);pay=dict(expected_snapshot(p,nr,c),ply=0);pay['board']=[None if x is None else list(x)for x in pay['board']];pay['hands']=[list(x)for x in pay['hands']];np=sem.pack_position(nr,pay);before=sem.snapshot(nr,np);baseline=sem.dynamic_features(nr,np);m.test_feature_set(True)
 try:value=sem.dynamic_features(nr,np);error=None
 except Exception as exc:value=None;error=type(exc).__name__+': '+str(exc)
 finally:failures=m.test_feature_failures();m.test_feature_set(False)
 rows.append(dict(fixture=name,baseline=baseline,core=oracle(c,p),fault_value=value,fault_error=error,injected_nested_failures=failures,root_restored=before==sem.snapshot(nr,np)));print(rows[-1])
write_record(P/'feature-error-before.json',dict(complete=True,rows=rows,scope='ActualcontrollednestedS3failure, notobservedOSmemoryincident. Legacybooleanmaskednegative; sameinC2prototype/product. No solver/model/normalresultchange.'))
