from pathlib import Path
from dataclasses import replace
import sys,json,time
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';sys.path[:0]=[str(R/'tests'),str(R/'tests/product'),str(P),str(R)]
from component import *
from semantic_control import oracle
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.native.mirror import expected_snapshot
import phase19b3_s4_fixtures as f
import test_native_pending_continuation as pend
from generic_chess.native.compiler import GC_SEM_MAX_PLY

def main():
 plan=dict(question='Are nested postconditions, actualautomaticPENDING and hardcapacity behaviors preserved by the dynamic discarded-view?',fixtures=['opponent_checked','nested_s4','full_child_state','multiple_replies','restricted_finish','forbidden_drop','automatic_pending','rule_maxply','capacity_transport'],whole_seconds=180,expected_seconds=20,scope='Mechanism/transportqualification, notnewgameorall-domain theorem. Syntheticcapacity/noninitialpositions explicitly diagnostic, no reachablehistoryclaim.')
 write_record(P/'edge-plan.json',plan);rows=[];start=time.perf_counter()
 for name,builder,pos in [('opponent_checked',f.opponent_checked_perspective_ruleset,f.opponent_checked_reply_checked_position),('nested_s4',f.nested_s4_option_b_ruleset,f.nested_s4_option_b_position),('full_child_state',f.full_child_state_ruleset,f.full_child_state_position),('multiple_replies',f.multiple_replies_ruleset,f.multiple_replies_position),('restricted_finish',f.restricted_finish_ruleset,f.restricted_finish_position),('forbidden_drop',f.forbidden_no_reply_drop_ruleset,f.forbidden_no_reply_drop_position)]:
  c=compile_semantic_ruleset(builder());position=pos(c.support);nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=modules[a])))for a in modules}
  for side in(0,1):
   p=replace(position,side_to_move=side);payload=dict(expected_snapshot(p,nrs['normal'],c),ply=0);payload['board']=[None if x is None else list(x)for x in payload['board']];payload['hands']=[list(x)for x in payload['hands']];vv={};snap={}
   for a,nr in nrs.items():
    np=sem.pack_position(nr,payload);before=sem.snapshot(nr,np);vv[a]=sem.dynamic_features(nr,np);assert before==sem.snapshot(nr,np)
    if a=='counter':audit=modules[a].private_dynamic_audit(nr.capsule,np)
    snap[a]=before
   expected=oracle(c,p);assert len(set(vv.values()))==1 and vv['normal']==expected,(name,side,vv,expected);rows.append(dict(fixture=name,side=side,payload=record_value(payload),features=record_value(vv),core=expected,audit=audit,snapshots=record_value(snap),kind='POSITION_FIXTURE'))
 for name,moves,limit,trigger in [('pending',('e2e4','d7d5','f1b5'),3,3),('pending_after',('e2e4','d7d5','f1b5','c7c6'),3,3),('rule_max',('e2e4','d7d5','f1b5'),3,None)]:
  s=pend.session_after(moves,limit=limit,trigger=trigger);c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=modules[a])))for a in modules};vv={}
  for a,nr in nrs.items():
   np=pack_semantic_search_position(c,nr,s);before=sem.snapshot(nr,np);vv[a]=sem.dynamic_features(nr,np);assert before==sem.snapshot(nr,np)
  assert len(set(vv.values()))==1;rows.append(dict(fixture=name,features=vv,kind='FULL_HISTORY_SESSION',game_record=record_value(s.to_record()),core_terminal=record_value(s.state.terminal_status)))
 s=pend.session_after(('e2e4','d7d5','f1b5','c7c6'));c=s.compiled;vv={};transport={}
 for a in('normal','candidate'):
  nr=compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=modules[a])));np=pack_semantic_search_position(c,nr,s);sn=sem.snapshot(nr,np);history=[(i+1,0,0,0,255 if i==0 else(i-1)%2,int(i>0 and i%2==1))for i in range(GC_SEM_MAX_PLY+1)];history[-1]=(*sn['history'][-1],1,0);payload=dict(side=sn['side'],ply=GC_SEM_MAX_PLY,board=[None if p is None else list(p)for p in sn['board']],hands=[list(x)for x in sn['hands']],history=history,aux_state=sn['aux_state']);np=sem.pack_position(nr,payload);before=sem.snapshot(nr,np);vv[a]=sem.dynamic_features(nr,np);assert before==sem.snapshot(nr,np);transport[a]=sem.terminal_status(nr,np)
 assert vv['normal']==vv['candidate'];rows.append(dict(fixture='capacity_transport_NOT_reachable_game',features=vv,terminal=transport,kind='TRANSPORT_FIXTURE'))
 write_record(P/'edge-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,scope=plan['scope']));print('EDGE_PASS',len(rows),sum(r.get('audit',{}).get('nested_replies',0)for r in rows),time.perf_counter()-start)
if __name__=='__main__':main()
