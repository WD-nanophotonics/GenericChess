from pathlib import Path
from dataclasses import replace
import sys,json,time,random
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';sys.path[:0]=[str(R/'tests'),str(P),str(R)]
from component import modules,sem,GameSession,compile_native_semantic_rules,pack_semantic_search_position,record_value,write_record,stopped
from phase19c1_native_semantic_fixtures import semantic_corpus
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.serialization import serialize_game_record

def oracle(c,p):
 e=SemanticEngine(c);vv=[]
 for owner in(0,1):
  view=replace(p,side_to_move=owner);aa=e.legal_actions(view);prom=sum(a.promotion_target_id is not None for a in aa);anchors=sum(a.source is not None and c.support.type_metadata[view.board[a.source].current_type_id].is_anchor for a in aa);vv.append((len(aa),prom,anchors-10*int(e.in_check(view,owner))))
 return tuple(a-b for a,b in zip(*vv))

def main():
 corpus=semantic_corpus();plan=dict(question='Does discarded-view dynamic extraction preserve independent Core legal-binding counts through existing pure-semantic mechanisms?',fixtures=[n for n,c in corpus],seeds=list(range(4)),max_prefix=6,whole_seconds=300,expected_seconds=30,scope='Existingmechanismfixtures, notfreshdistribution/universalequivalence. Corepositionoracleawayfromrulemax only, fullGameSessionhistorypreserved. Nativeviewsarequeriedreadonly; no newsearch/game/fit.')
 write_record(P/'semantic-plan.json',plan);rows=[];start=time.perf_counter()
 for name,c in corpus:
  nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=modules['candidate'])))for a in('normal','candidate')}
  for seed in range(4):
   s=GameSession(c);rng=random.Random(91800+seed)
   for ply in range(7):
    stopped();assert time.perf_counter()-start<300;before=record_value(s.state);v={};snap={}
    for arm,nr in nrs.items():
     packed=pack_semantic_search_position(c,nr,s);snap[arm]=sem.snapshot(nr,packed);v[arm]=sem.dynamic_features(nr,packed);assert sem.snapshot(nr,packed)==snap[arm]
    expected=oracle(c,s.state.position);assert v['normal']==v['candidate']==expected,(name,seed,ply,v,expected);assert record_value(s.state)==before
    rows.append(dict(fixture=name,seed=seed,ply=ply,game_record=json.loads(serialize_game_record(s.to_record())),state=before,features=expected,native_snapshots=record_value(snap),root_restored=True));write_record(P/'semantic-progress.json',dict(complete=False,rows=rows))
    if ply==6 or s.state.terminal_status.is_terminal:break
    aa=s.legal_actions()
    if not aa:break
    s.submit(rng.choice(sorted(aa,key=repr)))
   print('PURE',name,seed,s.state.ply_count,flush=True)
 write_record(P/'semantic-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,queries=0,games=0,scope=plan['scope']))
if __name__=='__main__':main()
