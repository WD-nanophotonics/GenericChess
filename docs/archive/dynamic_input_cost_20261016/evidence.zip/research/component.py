from pathlib import Path
from copy import copy
import sys,json,hashlib,time,importlib.util,statistics
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';O=R/'.local_agent/alias-teacher-20261016';sys.path[:0]=[str(R),str(O)]
from core_teacher import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,deserialize_ruleset,deserialize_game_record,GameSession,SearchLimits,record_value,write_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square

def action(d):
 if d is None:return None
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def loadmodule(arm):
 spec=importlib.util.spec_from_file_location(arm+'._native_core',P/(arm+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
modules=dict(normal=None,counter=loadmodule('counter'),candidate=loadmodule('candidate'));roots={}
def load(seed):
 if seed not in roots:
  d=json.loads((P/'roots'/f'{seed}.json').read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={k:compile_native_semantic_rules(c,**({}if m is None else dict(backend_module=m)))for k,m in modules.items()};roots[seed]=(d,c,s,nrs)
 return roots[seed]
def stopped():
 for name in('rollout','advisor','slack'):
  d=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
  if d.get('user_paused')or d.get('stopped'):raise RuntimeError('Userstop')

def main():
 plan=dict(question='Does discarded child identity explain dynamic input cost, and does exact checked material view preserve all feature counts?',states=72,component_repetitions=2,search_repetitions=2,depth=2,nodes=4096,q=0,tt=0,search_seconds=None,whole_seconds=300,expected_seconds=60,search_max_queries=24,arms=['normal','candidate'],scope='Exposed8fullruleparents/72existingstates;6supportedcompactroots. Sourcecounterprivateonly, no optimization in product orAUX. No game/fit/strength claim.')
 write_record(P/'component-plan.json',plan);start=time.perf_counter();rows=[]
 for item in json.loads((P/'input-states.json').read_bytes())['rows']:
  stopped();d,c,s,nrs=load(item['seed']);ss=copy(s);a=action(item['action'])
  if a is not None:ss.submit(a)
  digest=hashlib.sha256(json.dumps(record_value(ss.state),sort_keys=True).encode()).hexdigest();assert digest==item['state_sha256'];packs={arm:pack_semantic_search_position(c,nr,ss)for arm,nr in nrs.items()};before={arm:sem.snapshot(nrs[arm],p)for arm,p in packs.items()};observations=[]
  for rep in range(2):
   for arm in(['normal','candidate']if rep==0 else['candidate','normal']):
    t=time.perf_counter();v=sem.dynamic_features(nrs[arm],packs[arm]);elapsed=time.perf_counter()-t;assert list(v)==item['dynamic_values'];assert sem.snapshot(nrs[arm],packs[arm])==before[arm];observations.append(dict(arm=arm,rep=rep,features=v,seconds=elapsed))
  audit=modules['counter'].private_dynamic_audit(nrs['counter'].capsule,packs['counter']);assert list(audit['features'])==item['dynamic_values'];rows.append(dict(seed=item['seed'],board=item['board'],action=item['action'],state_sha256=digest,observations=observations,audit=audit,root_restored=True));assert time.perf_counter()-start<300
 write_record(P/'component-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,search_queries=0,scope=plan['scope']));print('COMPONENTS',len(rows),time.perf_counter()-start,flush=True)
 queries=[]
 for case in json.loads((P/'plan.json').read_bytes())['cases']:
  if case['board']==16:continue
  d,c,s,nrs=load(case['seed']);payload=json.loads((P/'compact-payloads'/f"{case['seed']}-16.json").read_bytes());before=record_value(s.state)
  for rep in range(2):
   pair=[]
   for arm in(['normal','candidate']if rep==0 else['candidate','normal']):
    stopped();assert time.perf_counter()-start<300;e=SemanticSearchEngine(c,nrs[arm],board_values=d['board_values'],hand_values=d['hand_values'],compact_values=payload,tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-t;assert record_value(s.state)==before;row=dict(seed=case['seed'],board=case['board'],arm=arm,rep=rep,payload=f"compact-payloads/{case['seed']}-16.json",result=record_value(r),caller_seconds=elapsed,root_restored=True);queries.append(row);pair.append(row);write_record(P/'search-progress.json',dict(complete=False,rows=queries))
   assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'};print('PAIR',case['seed'],rep,pair[0]['caller_seconds'],pair[1]['caller_seconds'],flush=True)
 write_record(P/'search-results.json',dict(complete=True,rows=queries,queries=len(queries),seconds=time.perf_counter()-start,scope=plan['scope']))
if __name__=='__main__':main()
