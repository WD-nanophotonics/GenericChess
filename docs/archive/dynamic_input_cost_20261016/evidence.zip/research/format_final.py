from pathlib import Path
p=Path('generic_chess/_native/native_module.c');s=p.read_text();old='''                int status = gc_semantic_runtime_make_checked_status(&child, rules, &view, raw);
            if (status < 0) {
                gc_semantic_action_buffer_free(&actions);
                return GC_SEMANTIC_EVAL_ERROR;
            }
            if (!status) continue;''';new='''                int status = gc_semantic_runtime_make_checked_status(&child, rules, &view, raw);
                if (status < 0) {
                    gc_semantic_action_buffer_free(&actions);
                    return GC_SEMANTIC_EVAL_ERROR;
                }
                if (!status) continue;''';assert s.count(old)==1;s=s.replace(old,new).replace('#define GC_SEMANTIC_EVAL_ERROR INT_MIN','/* Internal failure lies outside clipped scores and is checked before negation. */\n#define GC_SEMANTIC_EVAL_ERROR INT_MIN');p.write_bytes(s.encode())
