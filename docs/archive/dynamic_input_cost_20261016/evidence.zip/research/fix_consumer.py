from pathlib import Path
p=Path('.local_agent/dynamic-input-20261016/consumer.py');s=p.read_text();s=s.replace('import test_native_pending_continuation as pending\ns=pending.session_after', '''from generic_chess import build_builtin_ruleset,RuleAutomaticAdjudication,compile_ruleset_for_execution

def pending_session(moves, trigger=3):
 definition=replace(build_builtin_ruleset('western_chess'),max_ply=3,automatic_adjudications=()if trigger is None else(RuleAutomaticAdjudication('audit',trigger),));c=compile_ruleset_for_execution(definition);ss=GameSession(c)
 for uci in moves:
  ac=next(a for a in ss.legal_actions()if getattr(a,'from_square',None)is not None and chr(97+a.from_square.file)+str(1+a.from_square.rank)+chr(97+a.to_square.file)+str(1+a.to_square.rank)==uci);ss.submit(ac)
 return ss
s=pending_session''')
a=s.index('# Capacity oldzeros')
insert='''# Original explicit S4 position fixtures and real pending sessions are retained.
import phase19b3_s4_fixtures as s4
from generic_chess.rules.compiler import compile_semantic_ruleset
builders={'opponent_checked':s4.opponent_checked_perspective_ruleset,'nested_s4':s4.nested_s4_option_b_ruleset,'full_child_state':s4.full_child_state_ruleset,'multiple_replies':s4.multiple_replies_ruleset,'restricted_finish':s4.restricted_finish_ruleset,'forbidden_drop':s4.forbidden_no_reply_drop_ruleset}
positions={'opponent_checked':s4.opponent_checked_reply_checked_position,'nested_s4':s4.nested_s4_option_b_position,'full_child_state':s4.full_child_state_position,'multiple_replies':s4.multiple_replies_position,'restricted_finish':s4.restricted_finish_position,'forbidden_drop':s4.forbidden_no_reply_drop_position}
for row in read('edge-results.json')['rows']:
 if row['kind']!='POSITION_FIXTURE':continue
 c=compile_semantic_ruleset(builders[row['fixture']]());nr=compile_native_semantic_rules(c);position=replace(positions[row['fixture']](c.support),side_to_move=row['side']);np=sem.pack_position(nr,row['payload']);before=sem.snapshot(nr,np);assert list(sem.dynamic_features(nr,np))==row['features']['normal']==list(oracle(c,position));assert sem.snapshot(nr,np)==before;counts['s4_position_features']+=1
'''
s=s[:a]+insert+s[a:]
a=s.index('s=pending_session');b=s.index('from generic_chess.native.compiler import GC_SEM_MAX_PLY',a)
s=s[:a]+'''for name,moves,trigger in [('pending',('e2e4','d7d5','f1b5'),3),('pending_after',('e2e4','d7d5','f1b5','c7c6'),3),('rule_max',('e2e4','d7d5','f1b5'),None)]:
 ss=pending_session(moves,trigger);nn=compile_native_semantic_rules(ss.compiled);np=pack_semantic_search_position(ss.compiled,nn,ss);compare(ss,nn,np);row=next(r for r in read('edge-results.json')['rows']if r['fixture']==name);assert list(sem.dynamic_features(nn,np))==row['features']['normal'];counts['pending_max_feature_states']+=1
s=pending_session(('e2e4','d7d5','f1b5','c7c6'));nr=compile_native_semantic_rules(s.compiled);np=pack_semantic_search_position(s.compiled,nr,s);snap=sem.snapshot(nr,np)
'''+s[b:];p.write_bytes(s.encode())
