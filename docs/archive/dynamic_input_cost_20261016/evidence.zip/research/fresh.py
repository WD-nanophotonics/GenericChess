from pathlib import Path
from dataclasses import replace
import sys,json,time,random,hashlib,numpy as np
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';sys.path[:0]=[str(R),str(P)];from component import *
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.semantic_executor import semantic_engine_for,iter_semantic_public_actions
from generic_chess.core.coordinates import square_to_index

def corefeatures(c,s,deadline):
 engine=semantic_engine_for(c);counts=[]
 def check():
  if time.perf_counter()>deadline:raise TimeoutError('Corefeaturecap')
 for owner in(0,1):
  v=replace(s.state.position,side_to_move=owner);actions=tuple(iter_semantic_public_actions(engine,v,checkpoint=check));promotion=sum(getattr(a,'promotion_target_id',None)is not None for a in actions);anchors=0
  for a in actions:
   sq=getattr(a,'from_square',None)
   if sq is not None:
    piece=v.piece_at(sq);anchors+=int(c.support.type_metadata[piece.current_type_id].is_anchor)
  counts.append((len(actions),promotion,anchors-10*int(engine.in_check(v,owner,checkpoint=check))))
 return tuple(a-b for a,b in zip(*counts))

def main():
 cases=[dict(board=b,seed=50000+b*100+i)for b in(4,8,12,16)for i in range(1,9)];plan=dict(question='Does exact dynamic-value preservation and lower finite-search cost transfer to NEW complete generated rule families with nonzero dynamic profiles?',cases=cases,prefix_plies=8,walk='Fixedseed pseudorandomcanonicalactions, no replacement for terminaltails',policies=[dict(q=0,depth=3,nodes=16384,seconds=4),dict(q=1,depth=2,nodes=4096,seconds=4)],arms=['normal','candidate'],dynamic_values=[2,3,5],tt=0,max_query_slots=128,whole_seconds=900,expected_seconds=300,core_feature_seconds_per_root=8,scope='Prospectiveuncensoredslots retained; newrulefamilies before newlabels/timings, notall-domain/strength. No learnedweights orfitting. Corefeaturecomparison atply8awayfromrulelimits only, nativefullparenthistory preserved.')
 write_record(P/'fresh-plan.json',plan);F=P/'fresh-roots';F.mkdir(exist_ok=False);start=time.perf_counter();rows=[];queries=[]
 for idx,case in enumerate(cases):
  stopped();row=dict(**case);t=time.perf_counter()
  try:
   if t-start>=900:rows.append(dict(**row,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
   g=generate_game(GeneratorConfig(seed=case['seed'],board_size=case['board'],setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));x=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c);rng=random.Random(case['seed']+600000)
   for step in range(8):
    stopped()
    if s.state.terminal_status.is_terminal:break
    aa=tuple(s.legal_actions())
    if not aa:break
    s.submit(rng.choice(sorted(aa,key=repr)))
   d=dict(**case,ruleset=json.loads(serialize_ruleset(g.ruleset)),game_record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state),before_sha256=hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest());write_record(F/f"{case['seed']}.json",d);row.update(root=f"fresh-roots/{case['seed']}.json",actual_ply=s.state.ply_count,terminal=record_value(s.state.terminal_status))
   if s.state.terminal_status.is_terminal or s.state.ply_count<8:row['kind']='ACTUAL_TERMINAL_TAIL';rows.append(row);print('FRESH_TAIL',case,flush=True);continue
   nrs={arm:compile_native_semantic_rules(c,**({}if arm=='normal'else dict(backend_module=modules['candidate'])))for arm in('normal','candidate')};packs={arm:pack_semantic_search_position(c,nrs[arm],s)for arm in nrs};fv={arm:sem.dynamic_features(nrs[arm],packs[arm])for arm in nrs};assert fv['normal']==fv['candidate'];row['features']=fv['normal']
   try:row['core_features']=corefeatures(c,s,time.perf_counter()+8);row['core_feature_match']=row['core_features']==fv['normal']
   except TimeoutError:row['core_feature_censored']=True
   # Do not hide a Core/Nativesemantic difference as a candidate regression.
   if row.get('core_feature_match')is False:row['feature_scope_disagreement_preserved']=True
   bv={t.type_id:0 if t.is_anchor else 100 for t in c.piece_types};before=record_value(s.state)
   for pi,policy in enumerate(plan['policies']):
    pair=[]
    for arm in(['normal','candidate']if(idx+pi)%2==0 else['candidate','normal']):
     stopped()
     if time.perf_counter()-start>=900:queries.append(dict(**case,policy=policy,arm=arm,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
     e=SemanticSearchEngine(c,nrs[arm],board_values=bv,hand_values=bv,dynamic_values=(2,3,5),tt_megabytes=0,ordering_cache_enabled=False);tq=time.perf_counter();r=e.search(s,SearchLimits(max_depth=policy['depth'],max_nodes=policy['nodes'],max_time_seconds=policy['seconds'],quiescence_max_depth=policy['q'],quiescence_hard_max_depth=8 if policy['q']else 0),root_window_pruning=True);sec=time.perf_counter()-tq;assert record_value(s.state)==before;z=dict(**case,policy=policy,arm=arm,kind='ACTUAL_QUERY',result=record_value(r),caller_seconds=sec,root_restored=True);queries.append(z);pair.append(z);write_record(P/'fresh-search-progress.json',dict(complete=False,rows=queries))
    if len(pair)==2:
     joint=all(z['result']['completed_depth']==policy['depth']for z in pair);row.setdefault('joint_complete_policies',[]).append(dict(q=policy['q'],joint=joint))
     if joint:assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'},(case,policy,'Completedfiniteoutputs mismatch')
   row['kind']='EXECUTED_ROOT';row['root_restored']=record_value(s.state)==before
  except Exception as exc:row.update(kind='ACTUAL_FAILURE',error=type(exc).__name__+': '+str(exc));write_record(P/'fresh-failure-current.json',row)
  row['seconds']=time.perf_counter()-t;rows.append(row);write_record(P/'fresh-progress.json',dict(complete=False,rows=rows));print('FRESH',case,row['kind'],row.get('core_feature_match'),round(row['seconds'],3),flush=True)
 write_record(P/'fresh-results.json',dict(complete=True,rows=rows,queries=queries,seconds=time.perf_counter()-start,scope=plan['scope']))
if __name__=='__main__':main()
