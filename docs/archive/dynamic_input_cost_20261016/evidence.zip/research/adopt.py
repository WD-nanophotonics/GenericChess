from pathlib import Path
R=Path.cwd();p=R/'generic_chess/_native/native_module.c';b=p.read_bytes();s=b.decode();mark='static int gc_semantic_dynamic_feature_vector(';i=s.index(mark,s.index(mark)+1);j=s.index('static int gc_semantic_compact_residual(',i);part=s[i:j];old='            if (!gc_semantic_runtime_make_checked(&child, rules, &view, raw)) continue;';assert part.count(old)==1
part=part.replace(old,'''            /* Only legality and action fields are consumed. Keep full parent
             * history and S4 checks; the discarded child's digest/event is unused. */
            if (gc_semantic_runtime_make_material_view_status(
                    &child, rules, &view, raw) <= 0) continue;''');s=s[:i]+part+s[j:]
# Public derived features must not interpret storage exhaustion as zero mobility.
i=s.index('static PyObject *gc_semantic_dynamic_features(');j=s.index('static PyObject *gc_semantic_make_unmake_roundtrip(',i);part=s[i:j];old='    int features[3];';assert part.count(old)==1;part=part.replace(old,'''    if (position->history_len >= GC_SEM_MAX_PLY + 1) {
        PyErr_SetString(PyExc_NotImplementedError,
                        "semantic history capacity exceeded; use Core features");
        return NULL;
    }
'''+old);s=s[:i]+part+s[j:]
i=s.index('static PyObject *gc_semantic_spatial_features(');j=s.index('\nstatic ',i+1);part=s[i:j];old='    int *occupancy =';a=part.index(old);part=part[:a]+'''    if (position->history_len >= GC_SEM_MAX_PLY + 1) {
        PyErr_SetString(PyExc_NotImplementedError,
                        "semantic history capacity exceeded; use Core features");
        return NULL;
    }
'''+part[a:];s=s[:i]+part+s[j:]
i=s.index('static PyObject *gc_semantic_evaluate(');j=s.index('static PyObject *gc_semantic_iterative_search(',i);part=s[i:j];old='    int score = gc_semantic_probe_material(rules, position, &profile, NULL);';assert part.count(old)==1;part=part.replace(old,'''    if (position->history_len >= GC_SEM_MAX_PLY + 1 &&
        (profile.compact || profile.localized_control_supplied ||
         (profile.dynamic_supplied &&
          (profile.dynamic[0] || profile.dynamic[1] || profile.dynamic[2])))) {
        gc_semantic_profile_free(&profile);
        PyErr_SetString(PyExc_NotImplementedError,
                        "semantic history capacity exceeded; use Core evaluation");
        return NULL;
    }
'''+old);s=s[:i]+part+s[j:];p.write_bytes(s.encode())
p=R/'generic_chess/_native/native_semantic_runtime.h';s=p.read_text();s=s.replace('/* Discarded pure material scoring only; preserves postconditions and parent history.','/* Discarded scoring/feature legality only; preserves postconditions and parent history.');p.write_bytes(s.encode())
p=R/'tests/product/test_native_pending_continuation.py';s=p.read_text();old='        lambda: sem.guarded_actions(nr, full),';assert s.count(old)==1;s=s.replace(old,old+'''
        lambda: sem.dynamic_features(nr, full),
        lambda: sem.spatial_features(nr, full),
        lambda: sem.evaluate(nr, full, dynamic_values=(1, 0, 0)),
        lambda: sem.evaluate(nr, full, localized_control_values=(1,) * 9),''');p.write_bytes(s.encode());print('NARROW_SOURCE_AND_CAPACITY_FIX_WRITTEN')
