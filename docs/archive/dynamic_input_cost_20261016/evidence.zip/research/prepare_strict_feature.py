from pathlib import Path
import shutil,hashlib,json
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';S=P/'strict-feature-source';S.mkdir(exist_ok=False)
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
p=S/'native_module.c';s=p.read_text();s=s.replace('#define GC_SEMANTIC_STATIC_LIMIT 90000000','#define GC_SEMANTIC_STATIC_LIMIT 90000000\n#define GC_SEMANTIC_EVAL_ERROR INT_MIN')
# Negative legality status is extraction failure, never another illegal candidate.
a=s.index('static int gc_semantic_dynamic_feature_vector(',s.index('static int gc_semantic_probe_material('));b=s.index('static int gc_semantic_compact_residual(',a);part=s[a:b];old='''            if (gc_semantic_runtime_make_material_view_status(
                    &child, rules, &view, raw) <= 0) continue;''';assert part.count(old)==1;part=part.replace(old,'''            int status = gc_semantic_runtime_make_material_view_status(
                &child, rules, &view, raw);
            if (status < 0) {
                gc_semantic_action_buffer_free(&actions);
                return 0;
            }
            if (!status) continue;''');s=s[:a]+part+s[b:]
# Public entry uses Python errors only while owning the GIL.
a=s.index('static PyObject *gc_semantic_dynamic_features(');b=s.index('static PyObject *gc_semantic_make_unmake_roundtrip(',a);part=s[a:b];old='    if (!gc_semantic_dynamic_feature_vector(rules, position, features)) return NULL;';assert part.count(old)==1;part=part.replace(old,'''    if (!gc_semantic_dynamic_feature_vector(rules, position, features)) {
        if (!PyErr_Occurred())
            PyErr_SetString(PyExc_RuntimeError, "semantic dynamic feature extraction failed");
        return NULL;
    }''');s=s[:a]+part+s[b:]
# Scalar evaluator communicates failure without calling Python under released GIL.
a=s.index('static int gc_semantic_probe_material(');b=s.index('static int gc_semantic_dynamic_feature_vector(',a);part=s[a:b];part=part.replace('            return score;','            return GC_SEMANTIC_EVAL_ERROR;').replace('                return (int)score;','                return GC_SEMANTIC_EVAL_ERROR;');old='            if (!gc_semantic_runtime_make_checked(&child, rules, &view, raw)) continue;';assert part.count(old)==1;part=part.replace(old,'''            int status = gc_semantic_runtime_make_checked_status(&child, rules, &view, raw);
            if (status < 0) {
                gc_semantic_action_buffer_free(&actions);
                return GC_SEMANTIC_EVAL_ERROR;
            }
            if (!status) continue;''');old='''            score += profile->compact->perspective == 1
                ? -fixed_residual
                : (position->side_to_move == 0 ? fixed_residual : -fixed_residual);
        }
''';assert part.count(old)==1;part=part.replace(old,old[:-2]+' else {\n            return GC_SEMANTIC_EVAL_ERROR;\n        }\n');s=s[:a]+part+s[b:]
# Spatial public output has the same negative-status boundary.
a=s.index('static int gc_semantic_spatial_feature_vector(');b=s.index('static PyObject *gc_semantic_spatial_features(',a);part=s[a:b];old='            if (!gc_semantic_runtime_make_checked(&child, rules, &view, raw)) continue;';assert part.count(old)==1;part=part.replace(old,'''            int status = gc_semantic_runtime_make_checked_status(&child, rules, &view, raw);
            if (status < 0) {
                gc_semantic_action_buffer_free(&actions);
                return 0;
            }
            if (!status) continue;''');s=s[:a]+part+s[b:]
s=s.replace('    result.score = gc_semantic_probe_material(rules, position, profile, NULL);','    result.score = gc_semantic_probe_material(rules, position, profile, NULL);\n    if (result.score == GC_SEMANTIC_EVAL_ERROR) { *ok = 0; result.score = 0; return result; }')
s=s.replace('''    if (!gc_semantic_dynamic_feature_vector(ctx->rules, position, row->dynamic))
        memset(row->dynamic, 0, sizeof(row->dynamic));''','''    if (!gc_semantic_dynamic_feature_vector(ctx->rules, position, row->dynamic)) {
        ctx->control = 4;
        return;
    }''')
for prefix,call in [('                ','''gc_semantic_probe_material(
                    ctx->rules, &child, &ctx->ordering_profile,
                    dynamic_features);'''),('            ','''gc_semantic_probe_material(
                ctx->rules, &child, &ctx->ordering_profile, dynamic_features);''')]:
 old=prefix+'mover_score = -'+call;assert s.count(old)==1;s=s.replace(old,prefix+'int evaluated = '+call+'\n'+prefix+'if (evaluated == GC_SEMANTIC_EVAL_ERROR) {\n'+prefix+'    free(ordered); ctx->control = 4; return 0;\n'+prefix+'}\n'+prefix+'mover_score = -evaluated;')
s=s.replace('        int stand=gc_semantic_probe_material(ctx->rules,pos,&ctx->profile,NULL);','        int stand=gc_semantic_probe_material(ctx->rules,pos,&ctx->profile,NULL);\n        if(stand==GC_SEMANTIC_EVAL_ERROR){ctx->control=4;return 0;}')
s=s.replace('''            gc_semantic_probe_material(ctx->rules, position, &ctx->profile, NULL);
        /* A legal neutral claim''','''            gc_semantic_probe_material(ctx->rules, position, &ctx->profile, NULL);
        if (score == GC_SEMANTIC_EVAL_ERROR) { ctx->control = 4; return 0; }
        /* A legal neutral claim''')
old='''    gc_semantic_profile_free(&profile);
    return PyLong_FromLong(score);''';assert s.count(old)==1;s=s.replace(old,'''    gc_semantic_profile_free(&profile);
    if (score == GC_SEMANTIC_EVAL_ERROR) {
        if (!PyErr_Occurred())
            PyErr_SetString(PyExc_RuntimeError, "semantic evaluator feature extraction failed");
        return NULL;
    }
    return PyLong_FromLong(score);''');p.write_bytes(s.encode());(P/'strict-feature-source-plan.json').write_text(json.dumps(dict(question='After actualfault changedvectors silently, do all direct/evaluator/search/trace consumers refuse negative nested status?',source_before_sha256=hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),source_after_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Privatepatchqualificationbeforeproduct; Cthreadsuseout-of-rangeINT_MINstatus neverPythonerrorswithoutGIL; existingctxinternal_error anddirectRuntimeError. No API schema/model/normalvaluechange.'),indent=2)+'\n')
s=(P/'reproduce_feature_error.py').read_text();s=s.replace("feature-error-before-source","feature-error-after-source").replace("R/'generic_chess/_native'","P/'strict-feature-source'").replace('feature_error_before_native_core.pyd','feature_error_after_native_core.pyd').replace('errorbefore._native_core','errorafter._native_core').replace('feature-error-before.json','feature-error-after.json').replace('Legacybooleanmaskednegative; sameinC2prototype/product.','NewprivateC3rejectsnegativefeaturestatus; originalfaultreceiptretained.');(P/'reproduce_feature_error_after.py').write_bytes(s.encode())
