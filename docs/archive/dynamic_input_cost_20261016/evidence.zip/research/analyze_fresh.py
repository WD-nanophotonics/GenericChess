from pathlib import Path
import json,collections,statistics
P=Path('.local_agent/dynamic-input-20261016');d=json.loads((P/'fresh-recovered-results.json').read_bytes());print('FRESH',collections.Counter(r['kind']for r in d['rows']),len(d['queries']),d['seconds']);print('CORE',collections.Counter(r.get('core_feature_match','NA')for r in d['rows']));out=[]
for board in(4,8,12,16):
 for q in(0,1):
  rr=[r for r in d['queries']if r['board']==board and r['policy']['q']==q];pairs=[]
  for seed in sorted({r['seed']for r in rr}):
   z={r['arm']:r for r in rr if r['seed']==seed};a,b=z['normal'],z['candidate'];pairs.append(dict(seed=seed,depth_delta=b['result']['completed_depth']-a['result']['completed_depth'],same_action=a['result']['action']==b['result']['action'],normal_reason=a['result']['termination_reason'],candidate_reason=b['result']['termination_reason'],ratio=b['caller_seconds']/a['caller_seconds'],joint_complete=a['result']['completed_depth']==a['policy']['depth']and b['result']['completed_depth']==b['policy']['depth']))
  out.append(dict(board=board,q=q,pairs=pairs,depth_counts=dict(collections.Counter(p['depth_delta']for p in pairs))))
x=dict(complete=True,roots=30,planned_roots=32,terminal_tails=2,query_receipts=len(d['queries']),results=out,scope='Frozennonzero-dynamicprofile; completionconditionedcost, censorsretained, depthnotstrength. Prior11.468sfailedCoreharness/0search before recoveredphase; noinput/capchange.');(P/'fresh-analysis.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps([dict(board=r['board'],q=r['q'],depth_counts=r['depth_counts'],joint=sum(p['joint_complete']for p in r['pairs']))for r in out],indent=2));print('PURE',len(json.loads((P/'semantic-results.json').read_bytes())['rows']));print('EDGECAP',json.loads((P/'edge-results.json').read_bytes())['rows'][-1]['features'])
