from pathlib import Path
import sys,json,time,numpy as np
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';sys.path[:0]=[str(P),str(R)];from component import *
from generic_chess.learning.nonlinear import semantic_state_features,CompactNonlinearResidual

def main():
 prior=json.loads((P/'fresh-recovered-results.json').read_bytes());cases=[r for r in prior['rows']if r['kind']=='EXECUTED_ROOT'];plan=dict(question='With wall censors removed, do actual retained-depth/actions/PV/work/termination all remain identical under nonzero profiles on new full-rule roots?',cases=[dict(seed=r['seed'],board=r['board'],root=r['root'])for r in cases],policies=[dict(q=0,depth=4,nodes=512),dict(q=1,depth=3,nodes=512)],seconds=None,whole_seconds=420,expected_seconds=100,slot_count=4*len(cases),arms=['normal','candidate'],scope='Fixednodefinitecontrol onalreadyacquiredfreshcohort, no all-domain/evaluator-quality/strength claim. Nonzero untrained compact payload forwardchecks are separate directevaluations;16boardcapacity retained.')
 plan['recovery']='First4actualqueries retained in originalJSONL; forwardprofile dict-vs-sequence error corrected; do NOT rerun those slots';write_record(P/'fixed-node-recovered-plan.json',plan);rows=[json.loads(line)for line in(P/'fixed-node-rows.jsonl').read_text().splitlines()];evals=[];start=time.perf_counter()
 for idx,case in enumerate(cases):
  stopped();d=json.loads((P/case['root']).read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=modules['candidate'])))for a in('normal','candidate')};before=record_value(s.state);bv={t.type_id:0 if t.is_anchor else 100 for t in c.piece_types}
  for pi,pol in enumerate(plan['policies']):
   pair=[]
   if any(r['seed']==case['seed']and r['policy']==pol for r in rows):continue
   for arm in(['normal','candidate']if(idx+pi)%2==0 else['candidate','normal']):
    stopped()
    if time.perf_counter()-start>=420:rows.append(dict(seed=case['seed'],board=case['board'],arm=arm,policy=pol,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
    e=SemanticSearchEngine(c,nrs[arm],board_values=bv,hand_values=bv,dynamic_values=(2,3,5),tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=pol['depth'],max_nodes=pol['nodes'],max_time_seconds=None,quiescence_max_depth=pol['q'],quiescence_hard_max_depth=8 if pol['q']else 0),root_window_pruning=True);z=dict(seed=case['seed'],board=case['board'],policy=pol,arm=arm,kind='ACTUAL_QUERY',result=record_value(r),caller_seconds=time.perf_counter()-t,root_restored=record_value(s.state)==before);assert z['root_restored'];rows.append(z);pair.append(z)
    with(P/'fixed-node-rows.jsonl').open('a',encoding='utf-8',newline='\n')as f:f.write(json.dumps(z)+'\n');f.flush()
   if len(pair)==2:assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'},(case['seed'],pol,'non-time mismatch')
  packed={a:pack_semantic_search_position(c,nrs[a],s)for a in nrs};dynamic=sem.dynamic_features(nrs['normal'],packed['normal']);fv=semantic_state_features(s.state.position,c,dynamic);dim=len(fv)
  if dim<=4096:
   rng=np.random.default_rng(2026101600+case['seed']);payload=dict(input_mean=[0.0]*dim,input_scale=[1.0]*dim,target_scale=11.0,hidden_weights=rng.normal(0,.01,(16,dim)).tolist(),hidden_bias=rng.normal(0,.1,16).tolist(),output_weights=rng.normal(0,.1,16).tolist(),output_bias=.37,width=16,hand_type_indices=[nrs['normal'].type_ids.index(t.type_id)for t in sorted(c.piece_types,key=lambda t:t.type_id)],regularization=0,seed=case['seed']);(P/'nonzero-payloads').mkdir(exist_ok=True);write_record(P/'nonzero-payloads'/f"{case['seed']}.json",payload);model=CompactNonlinearResidual.from_dict(payload);v=float(model.predict(fv));expect=round(v*256)*(1 if s.state.position.side_to_move==0 else-1);actual={a:sem.evaluate(nrs[a],packed[a],board_values=[0]*len(nrs[a].type_ids),hand_values=[0]*len(nrs[a].type_ids),compact_values=payload,evaluator_scale=256)for a in nrs};assert all(v==expect for v in actual.values()),(case['seed'],expect,actual);evals.append(dict(seed=case['seed'],board=case['board'],dimension=dim,expected=expect,actual=actual,payload=f"nonzero-payloads/{case['seed']}.json",kind='ACTUAL_NONZERO_FORWARD_CHECK'))
  else:evals.append(dict(seed=case['seed'],board=case['board'],dimension=dim,kind='DOCUMENTED_UNSUPPORTED_DIMENSION_NO_MODEL_CONSTRUCTION'))
  print('FIXED',case['seed'],len(rows),round(time.perf_counter()-start,2),flush=True)
 write_record(P/'fixed-node-recovered-results.json',dict(complete=True,rows=rows,forward_checks=evals,seconds=time.perf_counter()-start,scope=plan['scope']))
if __name__=='__main__':main()
