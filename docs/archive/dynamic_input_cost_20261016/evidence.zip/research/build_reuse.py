from pathlib import Path
import sys,sysconfig,subprocess,time,shutil,json,hashlib
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';base=(R/'generic_chess/_native/native_module.c').read_text();i=base.index('static int gc_semantic_probe_material(');j=base.index('static int gc_semantic_dynamic_feature_vector(',i);part=base[i:j]
old='    int64_t score = 0;';assert part.count(old)==1;part=part.replace(old,old+'\n    int cached_dynamic[3];\n    const int *compact_dynamic = dynamic_features;')
old='''        for (int i = 0; i < 3; i++) {
            score += (position->side_to_move == 0 ? 1 : -1) *
                (int64_t)profile->dynamic[i] * features[i];
        }
''';assert part.count(old)==1;part=part.replace(old,old+'        memcpy(cached_dynamic, features, sizeof(cached_dynamic));\n        compact_dynamic = cached_dynamic;\n');old='rules, position, profile, dynamic_features, &residual';assert part.count(old)==1;part=part.replace(old,'rules, position, profile, compact_dynamic, &residual');reuse=base[:i]+part+base[j:]
plan=dict(question='When nonzero linear dynamic terms and compact residual coexist, is the exact vector recomputed twice andcan one local reuse remove realcost?',source_sha256=hashlib.sha256(base.encode()).hexdigest(),arm='private_reuse_withoutproductchange',profiles=['none','linear_only','compact_only','both'],first_two_roots_per_board=[4,8,12],direct_nonzero_models=22,search_repetitions=2,depth=2,nodes=4096,seconds=None,whole_seconds=180,expected_seconds=40,search_slots=24,scope='Newchangedpremise BOTHterms, notunchangedrerun. Samefunctional/nonzero untrainedmodel, nolearning/AUX/defaultchange. Local3int reuse only withinone readonly evaluation call; no crossstate cache.')
(P/'reuse-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for arm,code in [('reuse',reuse),('feature_counter',base)]:
 if arm=='feature_counter':
  mark='static int gc_semantic_dynamic_feature_vector(';i=code.index(mark);code=code[:i]+'static unsigned long long private_dynamic_calls_count=0;\n'+code[i:];i=code.index(mark,code.index(mark)+1);j=code.index('{',i);code=code[:j+1]+'\n    private_dynamic_calls_count++;'+code[j+1:];i=code.index('static PyObject *gc_semantic_dynamic_features(');helper='''static PyObject *gc_private_dynamic_calls(PyObject *self,PyObject *args) {
 (void)self;int reset=0;if(!PyArg_ParseTuple(args,"p",&reset))return NULL;
 unsigned long long n=private_dynamic_calls_count;if(reset)private_dynamic_calls_count=0;
 return PyLong_FromUnsignedLongLong(n);
}
''';code=code[:i]+helper+code[i:];mark='    {"semantic_dynamic_features", gc_semantic_dynamic_features, METH_VARARGS,';code=code.replace(mark,'    {"private_dynamic_calls", gc_private_dynamic_calls,METH_VARARGS,"privatecounter"},\n'+mark)
 S=P/(arm+'-source');S.mkdir(exist_ok=False)
 for f in(R/'generic_chess/_native').iterdir():
  if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
 (S/'native_module.c').write_bytes(code.encode());cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/(arm+'_native_core.pyd'))];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);out=dict(returncode=r.returncode,seconds=time.perf_counter()-t,command=cmd,stderr=r.stderr.decode(errors='replace'),source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()});(P/(arm+'-build-private.json')).write_text(json.dumps(out,indent=2)+'\n');print('BUILD',arm,r.returncode,out['seconds'],out['stderr'][-900:]);assert r.returncode==0
