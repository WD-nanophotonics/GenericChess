from pathlib import Path
import json,hashlib,subprocess,zipfile,re
R=Path.cwd();P=R/'.local_agent/dynamic-input-20261016';D=R/'docs/archive/dynamic_input_cost_20261016';D.mkdir(parents=True,exist_ok=False);files={};original={}
def add(name,b):
 original[name]=hashlib.sha256(b).hexdigest();s=b.decode('utf-8-sig')
 for value,label in((str(R),'<PROJECT>'),(str(Path.home()),'<USER>')):
  for x in(value,value.replace(chr(92),'/'),json.dumps(value)[1:-1]):s=s.replace(x,label)
 s=s.replace('\r\n','\n');assert not re.search(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',s),(name,'email');assert not re.search(r'\bsk-[A-Za-z0-9]{24,}|\bxox[bp]-[A-Za-z0-9-]{12,}|\bghp_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}',s),(name,'credential');files[name]=s.encode()
for f in sorted(P.glob('*.py')):add('research/'+f.name,f.read_bytes())
for name in ['plan.json','input-states.json','component-plan.json','component-results.json','search-results.json','analysis.json','fresh-plan.json','fresh-results.json','fresh-recovered-plan.json','fresh-recovered-results.json','fresh-analysis.json','fixed-node-plan.json','fixed-node-recovered-plan.json','fixed-node-recovered-results.json','semantic-plan.json','semantic-results.json','edge-plan.json','edge-results.json','product-binding-plan.json','product-binding-results.json','reuse-plan.json','reuse-execution-plan.json','reuse-results.json','reuse-product-plan.json','reuse-product-results.json','strict-product-plan.json','strict-product-results.json','strict-feature-source-plan.json','feature-error-before.json','feature-error-after.json','failures.json']:
 add('research/'+name,(P/name).read_bytes())
for folder in('roots','fresh-roots','nonzero-payloads','qualified-source1','qualified-source2','failed-source'):
 for f in sorted((P/folder).rglob('*')):
  if f.is_file()and f.suffix in('.py','.json','.c','.h'):add('research/'+f.relative_to(P).as_posix(),f.read_bytes())
for seed in(34101,34102,34201,34202,34301,34302):
 name=f'compact-payloads/{seed}-16.json';add('research/'+name,(P/name).read_bytes())
for folder in('counter-source','candidate-source','reuse-source','feature_counter-source','strict-feature-source','feature-error-before-source','feature-error-after2-source'):
 for name in('native_module.c','native_semantic_runtime.c','native_semantic_runtime.h'):
  f=P/folder/name
  if f.exists():add('research/'+folder+'/'+name,f.read_bytes())
for name in('counter-build-private.json','candidate-build-private.json','reuse-build-private.json','feature_counter-build-private.json','focused-tests-private.json','full-tests-private.json','final-full-tests-private.json','strict-focused-private.json'):
 add('research/'+name.replace('-private',''),(P/name).read_bytes())
# Preserve original producer import support without claiming standalone reruns.
for name in('core_teacher.py',):add('producer-support/'+name,(R/'.local_agent/alias-teacher-20261016'/name).read_bytes())
for name in('assessment.py','core_control.py','corrected/pipeline.py'):add('producer-support/'+name,(R/'.local_agent/playability-mu-20261016'/name).read_bytes())
for rel in subprocess.check_output(['git','ls-files','generic_chess','scripts'],text=True).splitlines():
 if Path(rel).suffix in('.py','.c','.h')and not any(x in rel.lower()for x in('holdout','xiangqi','human_oracle')):add('source/'+rel,(R/rel).read_bytes())
for rel in ['pyproject.toml','README.md','tests/conftest.py','tests/phase19c1_native_semantic_fixtures.py','tests/phase19b3_s4_fixtures.py','tests/rule_semantics_ir_fixtures.py','tests/product/test_native_dynamic_feature_views.py','tests/product/test_native_pending_continuation.py','tests/product/test_f58_compact_nonlinear.py','tests/development/test_native_dynamic_feature_error.py']:add('source/'+rel,(R/rel).read_bytes())
for f in R.glob('LICENSE*'):
 if f.is_file():add('source/'+f.name,f.read_bytes())
with zipfile.ZipFile(D/'evidence.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,b in sorted(files.items()):z.writestr(name,b)
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert z.testzip()is None
 for name,b in files.items():assert z.read(name)==b
m=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),final_module_sha256=hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),archive_sha256=hashlib.sha256((D/'evidence.zip').read_bytes()).hexdigest(),member_count=len(files),archive_bytes=(D/'evidence.zip').stat().st_size,members=[dict(path=k,bytes=len(v),sha256=hashlib.sha256(v).hexdigest(),original_sha256=original[k])for k,v in sorted(files.items())],scope='Fullretained360query receipts/inputs/feature/error controls/provenance and finalsource. Outgoingcopies hostpath/newlinenormalized; no binaries/rawSlack/account/PII/password/credentials/humanholdout. Privatebuildfolders contain relevantoverlays; remainingC/headers matchsharedsource, buildreceipts retainhashes. Originalproducerrelativecontextpreserved, notautomaticexperimentrunner.')
(D/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');
for name in('consumer.py','consumer_models.py'):(D/name).write_bytes(files['research/'+name])
(D/'README.md').write_text('''# Dynamic input cost evidence —2026-10-16

Sealed evidence.zip and manifest retain360actual research/binding query receipts,
40root files,32newrulefamilies/2terminaltails, complete records/history,280pure
prefix feature controls,72exposed states,12S4position fixtures and3realpending/
maxply controls. No new scientific game panel, trained model or shipped binary.
Counter/failed/firstqualified sources are provenance; final product is under
source/generic_chess. Private build directories are relevant source overlays,
not ready incomplete C trees. Original producers preserve executed path context;
DO NOT rerun them over frozen outputs. Only the receipt consumers are standalone.

Extract after verifying every manifest member/hash/ZIP CRC. Build final Native
from source with supported Python3.12/Zig, cwd extracted source. Run:
python -S ../research/consumer.py ../research
With NumPy available:
python ../research/consumer_models.py ../research
Source-only focused tests cover the four included product/development files.
They reproduce controlled nested failures privately, never ship fault hooks.
Both consumers assert actual package/extension origins and forbid searches.
Publication restoration receipt is outside the sealed ZIP to avoid circularity.

360queries include separately labeled60first-product,6second-product and6final
binding checks; not360independent positions. Feature/counter/forward checks are
separate primitive controls. Recorded missing/censored/tail outcomes are retained.
Legacy capacity zeros and negative-status masking are corrected, not rewritten.
No priorclock/WDL/modelquality/all-domain or independentcompiler/host claim.
''',encoding='utf-8');print('SEALED',m['member_count'],m['archive_bytes'],m['archive_sha256'],m['final_module_sha256'])
