from pathlib import Path
import runpy,json,time,hashlib,cProfile,pstats,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
b=Path(__file__).resolve().parent
m=runpy.run_path(str(b/'forced1455.py'));p=m['p'];Runtime=m['Runtime'];session=m['session'];c=m['c'];out=b/'ordering1455-profile-v2';out.mkdir(exist_ok=True);assert not (out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Which actual caller stages remain expensive in drop-rich1455 and does ordering save samecompletedD2 work?',source_commit='7b99185f859e830310f1568e7bece1a7c27d97e5',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),root=2026101455,calls=2,parent_depth=2,seconds=120,q=4,hardq=8,nodecap=None,arms=['lex','noncheck-ordered'],tt=True,scope='Two explicit explanatory profiles, profiled time NOT comparable to resourceplane unprofiledseconds or isolatedkernel. Full action/score/PV and requiredhistory/restoration retained. No results-drivenextension; one rootselected for69actualdropchoices andpositive16seccompletion, exposeddiagnostic, notnewtransferqualification.',decision='If requirednonnoisychild work dominates, inspect existing qclassification transport next; ifevaluationdominates pick evaluator entry. No quietdrop omission, newcache/framework/default/UIchange follows. Single2call runmax240sec<1hour.'))
oldq=sm._order_qactions;oldattach=Runtime.attach_stats;oldfactory=pm.SearchStatistics;rows=[];runtimes=[];stats=[]
def attach(rt,st):
 v=oldattach(rt,st);runtimes.append((rt,p.runtime_state(rt)));return v
def factory():
 v=SearchStatistics();stats.append(v);return v
def noncheck(state,actions,ply,ctx):
 if ctx.runtime.in_check(state.position.side_to_move,checkpoint=ctx.checkpoint):return sorted(actions,key=str)
 return oldq(state,actions,ply,ctx)
try:
 Runtime.attach_stats=attach;pm.SearchStatistics=factory
 for mode in ['lex','noncheck-ordered']:
  p.rr.stopped();runtimes.clear();stats.clear();sm._order_qactions=oldq if mode=='lex' else noncheck
  availability=m['NativeCoreAvailability'](c);ev=m['SemanticAttackEvaluator'](c,m['profile'],m['ec'],backend='native');player=m['AlphaBetaPlayer'](c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=True,availability_provider=availability.for_position,tuning=m['SearchTuning'](use_ordered_qsearch=mode!='lex'))
  profiler=cProfile.Profile();t=time.perf_counter();profiler.enable()
  try:value=player.choose_action(session,m['SearchLimits'](max_depth=2,max_nodes=None,max_time_seconds=120,quiescence_max_depth=4,quiescence_hard_max_depth=8))
  finally:profiler.disable()
  elapsed=time.perf_counter()-t
  for rt,before in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==before
  records=[]
  for (filename,line,name),(cc,nc,tt,ct,callers) in pstats.Stats(profiler).stats.items():
   try:label=str(Path(filename).resolve().relative_to(p.ROOT))
   except (ValueError,OSError):label=Path(filename).name
   records.append(dict(file=label,line=line,name=name,primitive_calls=cc,total_calls=nc,self_seconds=tt,cumulative_seconds=ct))
  records.sort(key=lambda x:x['cumulative_seconds'],reverse=True)
  rows.append(dict(mode=mode,elapsed_profiled_seconds=elapsed,decision=record_value(value),stats=record_value(stats[0]),root_restored=True,availability=dict(calls=availability.calls,imports=availability.imports,queries=availability.queries,fallbacks=availability.fallbacks,payload_seconds=availability.payload_seconds,query_seconds=availability.query_seconds),profile=records))
  write_record(out/'result.json',dict(complete=False,rows=rows));print(mode,value.completed_depth,value.termination_reason,round(elapsed,3),value.score,flush=True)
finally:sm._order_qactions=oldq;Runtime.attach_stats=oldattach;pm.SearchStatistics=oldfactory
write_record(out/'result.json',dict(complete=True,rows=rows))
