"""Limited forced-action diagnostic in the actual parent iterative q context."""
import sys,runpy,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import json,random
from types import SimpleNamespace
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value as record,write_record as write
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime as Runtime
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from scripts.native_core_availability import NativeCoreAvailability
seed=2026101403
g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True))
src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);session=p.GameSession(c);rng=random.Random(seed+13000)
for _ in range(8):
 assert session.result.status.value=='ongoing'
 session.submit(rng.choice(sorted(session.legal_actions(),key=repr)))
m={'s':session,'c':c,'profile':profile,'ec':ec}
h={'CountedSemanticEvaluator':SemanticAttackEvaluator,'AlphaBetaPlayer':AlphaBetaPlayer,'SearchTuning':SearchTuning,'SearchLimits':SearchLimits}
out=Path(__file__).resolve().parent/'forced1403'
def run():
 out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
 spec=json.loads((Path(__file__).resolve().parent/'next-forced-decision.json').read_bytes())
 actions={name:next(a for a in session.legal_actions() if record(a)==r) for name,r in spec['actions'].items()}
 write(out/'declaration.json',dict(spec=spec,source_sha256=__import__('hashlib').sha256(Path(__file__).read_bytes()).hexdigest(),source_commit='7b99185f859e830310f1568e7bece1a7c27d97e5',calls=4,seconds=64,nodes=None,tt=False,parent_depth=3,q=4,hardq=8,method='Original earlier iterations; forced final parent branch ply1/depth2/fullwindow, original parent q context; aborted branches unknown'))
 write(out/'sample.json',dict(state=record(session.state),witnesses=record(session._search_witnesses)))
 old=sm.negamax;oldattach=Runtime.attach_stats;rows=[]
 try:
  for depth in [3]:
   for order,names in enumerate([['retained_D2','completed_D3'],['completed_D3','retained_D2']]):
    for name in names:
     p.rr.stopped();action=actions[name];captures=[];rtrows=[]
     def attach(rt,stats):
      value=oldattach(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return value
     Runtime.attach_stats=attach
     def branch(state,d,alpha,beta,ply,ctx,*args,**kwargs):
      if ply!=0 or d!=depth:return old(state,d,alpha,beta,ply,ctx,*args,**kwargs)
      assert sm._ordinary_qdepth_limit(ctx)==4 and action in ctx.runtime.legal_actions(ctx.checkpoint)
      with ctx.runtime.pushed(action,checkpoint=ctx.checkpoint):
       child=old(ctx.runtime.state,d-1,-sm.INF,sm.INF,1,ctx,prev_action=action)
      captures.append(dict(score=-child.score,parent_ordinary_qdepth=sm._ordinary_qdepth_limit(ctx),pv=record((action,)+child.pv),complete=True))
      return sm.SearchResult(-child.score,action,(action,)+child.pv)
     sm.negamax=branch
     try:
      ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native');player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,availability_provider=NativeCoreAvailability(c).for_position,use_disk_cache=False,use_tt=False,tuning=h['SearchTuning'](use_pvs=False))
      t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=depth,max_nodes=None,max_time_seconds=64,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
      for rt,before in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==before
      rows.append(dict(parent_depth=depth,order=order,forced_action=name,seconds=elapsed,forced_branch=captures[-1] if captures else None,caller_metadata=record(r),root_restored=True,scope='limited forced branch; caller completed_depth is not whole-root optimum'))
      write(out/'result.json',dict(complete=False,rows=rows));print(depth,order,name,round(elapsed,3),captures[-1]['score'] if captures else None,r.completed_depth,r.termination_reason,flush=True)
     finally:sm.negamax=old;Runtime.attach_stats=oldattach
 finally:sm.negamax=old;Runtime.attach_stats=oldattach
 write(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run()
