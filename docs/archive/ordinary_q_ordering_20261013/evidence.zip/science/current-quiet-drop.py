from pathlib import Path
import sys,runpy,json,time,hashlib,inspect,textwrap
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.research_record import record_value,write_record
from scripts.quiet_drop_probe import QuietDropProbe
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
b=Path(__file__).resolve().parent;m=runpy.run_path(str(b/'forced1455.py'));p=m['p'];Runtime=m['Runtime'];s=m['session'];c=m['c'];out=b/'current-quiet-drop';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
source=textwrap.dedent(inspect.getsource(sm._quiescence_runtime));target='    for action in ordered:\n';assert source.count(target)==1
modified=source.replace(target,'    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
write_record(out/'declaration.json',dict(question='Does existing quiet-drop bookkeeping seam add support beyond current noncheckordering after Nativecost repairs?',source_commit='7b99185f859e830310f1568e7bece1a7c27d97e5',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),qsource_sha256=hashlib.sha256(modified.encode()).hexdigest(),probe_sha256=hashlib.sha256(Path('scripts/quiet_drop_probe.py').read_bytes()).hexdigest(),root=2026101455,shadow_calls=1,resource_calls=8,resource_budgets=[16,64],q=4,hardq=8,max_query_seconds=336,tt=True,scope='Changedpremise: current7b costrepairs and newmixedqorder positive16sroot with69rootdrops. Existingprivateexclusion guard and actualtransition preserved. Exposedconditionalcost study, NOTextension/replacementoffrozen64callfreshplane. Shadow4096node16s thenboth16/64 budgets reverseorders, noderesourcecapsNone. Maxsingleproducerunder6minutes,no extraengine/workers. Ifshadowfails stopnewroute, keepfailure. Default/UI unchanged.',decision='Onlyifaddedcompletedusefulsupport consider furtherseamqualification; samehorizon keepsresearchonly. No omissionofpromotion/drop/history or staticcheckedleaf; old877/878 resultsstayfrozen.'))
oldq=sm._quiescence_runtime;oldorder=sm._order_qactions;oldattach=Runtime.attach_stats;oldfactory=pm.SearchStatistics;runtimes=[];stats=[];rows=[]
def noncheck(state,actions,ply,ctx):
 if ctx.runtime.in_check(state.position.side_to_move,checkpoint=ctx.checkpoint):return sorted(actions,key=str)
 return oldorder(state,actions,ply,ctx)
def attach(rt,st):
 v=oldattach(rt,st);runtimes.append((rt,p.runtime_state(rt)));return v
def factory():
 v=SearchStatistics();stats.append(v);return v
try:
 sm._order_qactions=noncheck;Runtime.attach_stats=attach;pm.SearchStatistics=factory
 for seconds,order,mode,nodes in [(16,0,'shadow',4096)]+[(sec,order,mode,None) for sec in [16,64] for order,names in [(0,['baseline','exclude']),(1,['exclude','baseline'])] for mode in names]:
  p.rr.stopped();runtimes.clear();stats.clear();probe=QuietDropProbe(shadow=mode=='shadow');ns=dict(sm.__dict__,quiet_drop_probe=probe);exec(compile(modified,'<current-quiet-drop>','exec'),ns);sm._quiescence_runtime=oldq if mode=='baseline' else ns['_quiescence_runtime']
  av=m['NativeCoreAvailability'](c);ev=m['SemanticAttackEvaluator'](c,m['profile'],m['ec'],backend='native');player=m['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=True,use_disk_cache=False,availability_provider=av.for_position,tuning=m['SearchTuning'](use_ordered_qsearch=True));start=time.perf_counter()
  value=player.choose_action(s,m['SearchLimits'](max_depth=12,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-start
  for rt,root in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==root
  if mode=='shadow':assert probe.counts['shadow_verified']==probe.counts['proved_exclusions'] and probe.counts['shadow_verified']>0
  rows.append(dict(seconds_limit=seconds,order=order,mode=mode,nodecap=nodes,decision=record_value(value),stats=record_value(stats[0]),probe_counts=dict(probe.counts),caller_seconds=elapsed,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(mode,seconds,order,value.completed_depth,value.termination_reason,round(elapsed,3),dict(probe.counts),flush=True)
finally:sm._quiescence_runtime=oldq;sm._order_qactions=oldorder;Runtime.attach_stats=oldattach;pm.SearchStatistics=oldfactory
write_record(out/'result.json',dict(complete=True,rows=rows))
