"""Final product qualification against pinned pre-migration/prototype records.
No rerun of capped callers: verify their actual rounded board inputs unchanged.
"""
import sys,json,hashlib,time
from pathlib import Path
from dataclasses import asdict
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.coordinates import BoardShape
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.ai.evaluation.analyzer import build_movement_capability
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.cache import EvaluationProfileCache,_profile_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.mobility import analytic_mobility_at_density
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from scripts.research_record import write_record
p=root/'.local_agent/rect-profile-20261009';old=json.loads((p/'square-baseline.json').read_bytes());families={'forward':(LeapAtom((0,1)),),'horizontal':(RayAtom((1,0)),),'diagonal':(RayAtom((1,1)),),'hybrid':(RayAtom((1,0)),LeapAtom((2,0)),LeapAtom((0,1))),'overlap':(LeapAtom((0,1)),LeapAtom((0,1)))};cfg=EvaluationConfig(mc_samples=32);square=[]
for row in old['cases']:
 a=build_movement_capability(row['n'],families[row['name']],cfg);b=build_movement_capability(BoardShape(row['n'],row['n']),families[row['name']],cfg);assert a==b
 reverse=build_movement_capability(row['n'],tuple(reversed(families[row['name']])),cfg);assert a.expected_mobility==reverse.expected_mobility
 delta=max(abs(x-y) for x,y in zip(a.expected_mobility,row['profile']['expected_mobility']));square.append(dict(n=row['n'],name=row['name'],max_old_curve_delta=delta,int_shape_exact=True,order_curve_exact=True))
coverage=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes());prior=json.loads((p/'cross-rule-exact.json').read_bytes());rules=[('Chess',build_western_chess_ruleset()),('Shogi',build_standard_shogi_ruleset())]+[(str(r['seed']),ruleset_from_dict(r['rules'])) for r in coverage['cases']];profiles=[]
for name,rule in rules:
 c=compile_ruleset_for_execution(rule);start=time.perf_counter();final=build_ruleset_profile(c,EvaluationConfig());seconds=time.perf_counter()-start;expected=next(r for r in prior['cases'] if r['name']==name)['exact_profile'];assert final.board_value_by_type==expected['board_value_by_type'];assert final.hand_value_by_base_type==expected['hand_value_by_base_type'];profiles.append(dict(name=name,board=dict(final.board_value_by_type),hand=dict(final.hand_value_by_base_type),seconds=seconds,prototype_board_hand_exact=True))
# Deliberately populate only project-local old cache, then require v2 miss/hit.
c=compile_ruleset_for_execution(build_standard_shogi_ruleset());cache_dir=p/'cache-qualification';cache_dir.mkdir(exist_ok=True);base=next(r for r in prior['cases'] if r['name']=='Shogi')['old_profile'];cache=EvaluationProfileCache(disk_dir=cache_dir);cache._store_disk(_profile_from_dict(base));v2,hit=cache.get_or_build(c,EvaluationConfig());assert not hit;again,hit=EvaluationProfileCache(disk_dir=cache_dir).get_or_build(c,EvaluationConfig());assert hit and again==v2
write_record(p/'product-final-qualification.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),square=square,profiles=profiles,cache_old_to_v2_miss_then_hit=True));print('15square+6profiles+diskmigration pass',[(r['name'],round(r['seconds'],4)) for r in profiles])
