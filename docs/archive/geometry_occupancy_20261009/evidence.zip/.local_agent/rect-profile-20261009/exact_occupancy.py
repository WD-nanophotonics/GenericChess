"""Exact independent-occupancy mobility for supported leap/primitive-ray atoms.
Each endpoint has at most one geometric ray prefix; a direct leap dominates it.
For target t retain minimum required empty-prefix length k; contribution
(1-rho/2)*(1-rho)**k. Summing endpoints needs no independence between endpoints.
Research-only: no product default/version/cache changes.
"""
import sys,json,itertools,math,time,collections
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.coordinates import BoardShape,Square
from generic_chess.core.movement import LeapAtom,RayAtom,atom_targets
from generic_chess.ai.evaluation.mobility import analytic_mobility_at_density,monte_carlo_mobility_at_density
from generic_chess.ai.evaluation.analyzer import movement_signature
from scripts.research_record import write_record
p=root/'.local_agent/rect-profile-20261009'
def histogram(shape,atoms):
 hist=collections.Counter()
 for r in range(shape.height):
  for f in range(shape.width):
   endpoint={}
   for a in atoms:
    for k,t in enumerate(atom_targets(shape,0,Square(f,r),a)):
     prefix=0 if isinstance(a,LeapAtom) else k
     endpoint[t]=min(prefix,endpoint.get(t,prefix))
   hist.update(endpoint.values())
 return hist

def exact(shape,atoms,density):
 hist=histogram(shape,atoms)
 return (1-density/2)*sum(n*(1-density)**k for k,n in hist.items())/shape.area

def enumeration(shape,atoms,density):
 total=0
 for board in itertools.product((0,1,2),repeat=shape.area):
  mass=math.prod((1-density if v==0 else density/2) for v in board)
  for r in range(shape.height):
   for f in range(shape.width):
    seen=set()
    for a in atoms:
     for t in atom_targets(shape,0,Square(f,r),a):
      owner=board[t.rank*shape.width+t.file]
      if owner!=1:seen.add(t)
      if owner and isinstance(a,RayAtom):break
    total+=mass*len(seen)/shape.area
 return total

def main():
 start=time.perf_counter();shape=BoardShape(3,2);families={'ray':(RayAtom((1,0)),),'ray_redundant_leap':(RayAtom((1,0)),LeapAtom((1,0))),'hybrid':(RayAtom((1,0)),LeapAtom((2,0)),LeapAtom((0,1))),'duplicate':(LeapAtom((1,1)),LeapAtom((1,1))),'diagonal':(RayAtom((1,1)),LeapAtom((1,1)),RayAtom((-1,-1)))};rows=[]
 for name,atoms in families.items():
  for d in (0,.25,.5,1):
   a=exact(shape,atoms,d);b=enumeration(shape,atoms,d);assert abs(a-b)<1e-10;rows.append(dict(family=name,density=d,formula=a,enumeration=b,histogram=dict(histogram(shape,atoms))))
 a=families['ray'];b=families['ray_redundant_leap'];common='occupancy:3x2';old=analytic_mobility_at_density(shape,a,.5);newmc=monte_carlo_mobility_at_density(shape,b,.5,common,'research-common-field-v1',64)
 assert exact(shape,a,.5)==exact(shape,b,.5)
 write_record(p/'exact-occupancy.json',dict(scope=__doc__,rows=rows,branch_boundary=dict(exact_ray=old,common_mc_redundant=newmc,common_seed_sufficient=old==newmc),seconds=time.perf_counter()-start));print('20exact enumeration controls',old,newmc,time.perf_counter()-start)
if __name__=='__main__':main()
