"""Four existing event roots, pinned old sampled board versus exact board only.
8Corecold calls: D2/8192nodes/5sec/q2hard8. Old hands/ordering/dynamic fixed.
No new samples, fits, cap extension or playing-strength interpretation.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.cache import _profile_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/rect-profile-20261009';inputs=[p/'cross-rule-exact.json',root/'.local_agent/generated6-20261008/coverage.json'];exact,coverage=[json.loads(f.read_bytes()) for f in inputs];declared=[(202610082000,1),(202610082001,16),(202610082002,4),(202610082003,1)];cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);res=dict(scope=__doc__,complete=False,declared=declared,input_hashes={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in inputs},producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=[]);out=p/'exact-callers.json';assert not out.exists()
for i,(seed,ply) in enumerate(declared):
 for f in ('rollout.json','advisor.json','slack.json'):
  flags=json.loads((root/'.local_agent'/f).read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
 old=next(x for x in coverage['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
 for step in old['route'][:ply]:s.submit(action_from_dict(step['action']))
 row=next(x for x in exact['cases'] if x['name']==str(seed));base=_profile_from_dict(row['old_profile']);candidate=replace(base,board_value_by_type=row['exact_profile']['board_value_by_type']);reference=SemanticAttackEvaluator(c,base,cfg,backend='core')
 class FrozenOrdering(SemanticAttackEvaluator):
  def capture_order_value(self,*a):return reference.capture_order_value(*a)
  def type_value(self,*a):return reference.type_value(*a)
 ev={'old_sampled':reference,'exact_board':FrozenOrdering(c,candidate,cfg,backend='core')};before=(s.state,s.history,s._search_witnesses);r=dict(seed=seed,ply=ply,calls=[]);res['cases'].append(r)
 for name in (('old_sampled','exact_board') if i%2==0 else ('exact_board','old_sampled')):
  player=AlphaBetaPlayer(c,evaluator_override=ev[name],use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));start=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-start;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before;r['calls'].append(dict(profile=name,seconds=elapsed,decision=record_value(dec)));write_record(out,res);print(seed,ply,name,dec.completed_depth,dec.termination_reason,dec.score,flush=True)
res['complete']=True;write_record(out,res)
