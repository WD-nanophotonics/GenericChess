"""One capped Core caller profile, same declared D2/8192/5sec/q2hard8.
Profiling overhead is intrusive; not a speed comparison or node parity claim.
"""
import sys,json,time,cProfile,pstats,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/rect-profile-20261009';inp=root/'.local_agent/generated6-20261008/coverage.json';d=json.loads(inp.read_bytes());old=next(x for x in d['cases'] if x['seed']==202610082001);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for step in old['route'][:16]:s.submit(action_from_dict(step['action']))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='core');player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=(s.state,s.history,s._search_witnesses);prof=cProfile.Profile();start=time.perf_counter();prof.enable();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));prof.disable();seconds=time.perf_counter()-start;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before
stats=pstats.Stats(prof);rows=[]
for (file,line,name),(primitive,calls,total,cumulative,callers) in stats.stats.items():
 if 'generic_chess' in file:rows.append(dict(file=Path(file).relative_to(root).as_posix(),line=line,name=name,primitive_calls=primitive,calls=calls,self_seconds=total,cumulative_seconds=cumulative))
write_record(p/'core-cost.json',dict(scope=__doc__,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seed=old['seed'],ply=16,seconds=seconds,decision=record_value(dec),root_pv_valid=True,root_restored=True,rows=sorted(rows,key=lambda r:-r['cumulative_seconds'])));print([(r['name'],r['calls'],round(r['self_seconds'],3),round(r['cumulative_seconds'],3)) for r in sorted(rows,key=lambda r:-r['self_seconds'])[:12]])
