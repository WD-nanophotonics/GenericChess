"""Independent finite occupancy expectation on a tiny rectangle.
For each cell assign empty/friendly/enemy, then union targets; exact probabilities.
Saturation compares physically identical ray+leap encodings; no default change.
"""
import sys,json,time,itertools,math
from pathlib import Path
from dataclasses import asdict
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.coordinates import BoardShape
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.ai.evaluation.analyzer import build_movement_capability
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
p=root/'.local_agent/rect-profile-20261009';shape=BoardShape(3,2);start=time.perf_counter()
def targets(board,src,atoms):
 f,r=src%shape.width,src//shape.width;out=set()
 for atom in atoms:
  df,dr=atom.offset if isinstance(atom,LeapAtom) else atom.direction
  steps=1 if isinstance(atom,LeapAtom) else atom.max_steps or max(shape.width,shape.height)
  for k in range(1,steps+1):
   nf,nr=f+df*k,r+dr*k
   if not(0<=nf<shape.width and 0<=nr<shape.height):break
   dst=nr*shape.width+nf
   if board[dst]!=1:out.add(dst)
   if board[dst] or isinstance(atom,LeapAtom):break
 return out
atoms=(RayAtom((1,0)),LeapAtom((2,0)),LeapAtom((0,1)))
exact={}
for density in (0,.25,.5):
 total=0;mass=0
 for board in itertools.product((0,1,2),repeat=shape.area):
  prob=math.prod((1-density if v==0 else density/2) for v in board)
  total+=prob*sum(len(targets(board,s,atoms)) for s in range(shape.area))/shape.area;mass+=prob
 assert abs(mass-1)<1e-12;exact[density]=total
cfg=EvaluationConfig(density_points=(0,.25,.5),density_weights=(.4,.3,.3),mc_samples=1024);profile=build_movement_capability(shape,atoms,cfg)
a=(RayAtom((1,0),2),LeapAtom((0,1)));b=(RayAtom((1,0),999),LeapAtom((0,1)))
checked=0
for board in itertools.product((0,1,2),repeat=shape.area):
 for src in range(shape.area):
  assert targets(board,src,a)==targets(board,src,b);checked+=1
pa=build_movement_capability(shape,a,EvaluationConfig());pb=build_movement_capability(shape,b,EvaluationConfig())
res={'scope':__doc__,'shape':asdict(shape),'exact_expectation':exact,'mc_profile':asdict(profile),'absolute_errors':[abs(x-exact[d]) for d,x in zip(cfg.density_points,profile.expected_mobility)],'equivalent_saturation_controls':checked,'saturated_a':asdict(pa),'saturated_b':asdict(pb),'same_expected_curve':pa.expected_mobility==pb.expected_mobility,'seconds':time.perf_counter()-start}
write_record(p/'finite-occupancy.json',res);print({k:res[k] for k in ('exact_expectation','absolute_errors','equivalent_saturation_controls','same_expected_curve','seconds')})
