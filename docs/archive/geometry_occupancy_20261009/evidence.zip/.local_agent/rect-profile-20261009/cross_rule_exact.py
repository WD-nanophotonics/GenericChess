"""Existing square rules: old default versus research exact independent-occupancy
curves. Geometry metrics, normalization and dynamic weights fixed. No human
reference labels/holdout, fits, default cache writes or search-strength claims.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.ai.evaluation.analyzer import build_movement_capability,movement_signature
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.mobility import analytic_mobility_at_density,atoms_overlap,mobility_density_curve
from scripts.research_record import write_record,record_value
p=root/'.local_agent/rect-profile-20261009';coverage=root/'.local_agent/generated6-20261008/coverage.json';cfg=EvaluationConfig();rows=[];rules=[('Chess',build_western_chess_ruleset()),('Shogi',build_standard_shogi_ruleset())]+[(str(r['seed']),ruleset_from_dict(r['rules'])) for r in json.loads(coverage.read_bytes())['cases']]
for name,ruleset in rules:
 c=compile_ruleset_for_execution(ruleset);cap={};curve_rows=[]
 for pt in c.piece_types:
  a=build_movement_capability(c.board_size,pt.movement_atoms,cfg);start=time.perf_counter();exact=tuple(analytic_mobility_at_density(c.board_size,pt.movement_atoms,d) for d in cfg.density_points);exact_sec=time.perf_counter()-start;start=time.perf_counter();old=mobility_density_curve(c.board_size,pt.movement_atoms,cfg.density_points,signature=a.movement_signature,version=cfg.evaluator_version,mc_samples=cfg.mc_samples);old_sec=time.perf_counter()-start;assert old==a.expected_mobility
  cap[a.movement_signature]=replace(a,expected_mobility=exact,analyzer_version='research-exact-independent-v1');curve_rows.append(dict(type=pt.type_id,overlap=atoms_overlap(pt.movement_atoms),old=a.expected_mobility,exact=exact,exact_curve_seconds=exact_sec,old_curve_seconds=old_sec))
 class ExactCache:
  def get_or_build(self,n,atoms,config):return cap[movement_signature(atoms)],True
 a=build_ruleset_profile(c,cfg);b=build_ruleset_profile(c,replace(cfg,evaluator_version='research-exact-independent-v1'),ExactCache());rows.append(dict(name=name,fingerprint=c.ruleset_fingerprint,curves=curve_rows,old_profile=record_value(a),exact_profile=record_value(b)))
write_record(p/'cross-rule-exact.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(coverage.read_bytes()).hexdigest(),cases=rows));print([(r['name'],[(x['type'],x['overlap'],x['old']==x['exact']) for x in r['curves']]) for r in rows])
