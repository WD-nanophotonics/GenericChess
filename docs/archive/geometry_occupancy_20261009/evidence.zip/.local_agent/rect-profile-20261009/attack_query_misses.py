"""Count static geometry misses before S0/S1 guards at one existing Core root.
No search policy/index changes; complete square queries bothowners, not runtime-cost attribution.
"""
import sys,json,time,collections,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.semantic_executor import semantic_engine_for,_sources_by_owner_type
from generic_chess.rules.ir import geometry_paths_to
from scripts.research_record import write_record
p=root/'.local_agent/rect-profile-20261009';inp=root/'.local_agent/generated6-20261008/coverage.json';old=next(r for r in json.loads(inp.read_bytes())['cases'] if r['seed']==202610082001);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for step in old['route'][:16]:s.submit(action_from_dict(step['action']))
e=semantic_engine_for(c);pos=s.state.position;sources=_sources_by_owner_type(pos);counts=collections.Counter();start=time.perf_counter()
for owner in (0,1):
 for square in range(pos.board_shape.area):
  for pattern in e._patterns:
   counts['pattern_visits']+=1
   if pattern.target.kind!='target_enemy':counts['noncapture_pattern']+=1;continue
   for tid in pattern.type_ids:
    counts['type_visits']+=1
    for source,piece in sources.get((owner,tid),()):
     counts['source_visits']+=1
     for gid in pattern.geometry_ids:
      counts['geometry_visits']+=1;g=e.ir.geometry.get(gid)
      if g is None or g.kind=='drop':counts['missing_drop']+=1;continue
      if g.atom_source is not None and g.atom_source[0]!=tid:counts['incompatible_actor']+=1;continue
      paths=tuple(geometry_paths_to(g,str(owner),source,square))
      if not paths:counts['target_misses']+=1
      else:counts['target_matches']+=1;counts['matched_paths']+=len(paths)
write_record(p/'attack-query-misses.json',dict(scope=__doc__,seed=old['seed'],ply=16,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),counts=dict(counts),seconds=time.perf_counter()-start));print(dict(counts))
