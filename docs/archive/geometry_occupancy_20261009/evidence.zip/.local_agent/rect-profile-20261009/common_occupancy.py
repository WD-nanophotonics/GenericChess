"""Research-only common occupancy field: fix the sample seed by board shape,
density/version rather than textual piece signature. Default analyzer unchanged.
Equivalent supported leap/ray target unions then see the same occupancy draws.
This repairs finite representation noise, not material calibration or MC bias.
"""
import sys,json,time,itertools
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.coordinates import BoardShape
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.ai.evaluation.mobility import monte_carlo_mobility_at_density
from generic_chess.ai.evaluation.analyzer import movement_signature
from scripts.research_record import write_record
p=root/'.local_agent/rect-profile-20261009';start=time.perf_counter();rows=[]
for shape in (BoardShape(3,2),BoardShape(7,5),BoardShape(9,10)):
 cap=shape.width-1
 families=[('saturation',(RayAtom((1,0),cap),LeapAtom((0,1))),(RayAtom((1,0),999),LeapAtom((0,1)))),('duplicate',(RayAtom((1,0)),LeapAtom((0,1))),(RayAtom((1,0)),LeapAtom((0,1)),LeapAtom((0,1)))),('redundant_one_step',(RayAtom((1,0)),LeapAtom((0,1))),(RayAtom((1,0)),LeapAtom((1,0)),LeapAtom((0,1))))]
 for name,a,b in families:
  common=f'occupancy:{shape.width}x{shape.height}';curve=lambda atoms,sig:tuple(monte_carlo_mobility_at_density(shape,atoms,d,sig,'research-common-field-v1',64) for d in (0,.125,.25,.375,.5))
  ca,cb=curve(a,common),curve(b,common);assert ca==cb
  olda,oldb=curve(a,movement_signature(a)),curve(b,movement_signature(b))
  rows.append(dict(shape=[shape.width,shape.height],family=name,common_a=ca,common_b=cb,old_signature_a=olda,old_signature_b=oldb,common_equal=True))
 # Sensitivity: leap over intermediate blocker is genuinely different from ray.
 density=.5;common=f'occupancy:{shape.width}x{shape.height}'
 a=(RayAtom((1,0)),LeapAtom((0,1)));b=(*a,LeapAtom((2,0)))
 ra=monte_carlo_mobility_at_density(shape,a,density,common,'research-common-field-v1',64);rb=monte_carlo_mobility_at_density(shape,b,density,common,'research-common-field-v1',64);assert rb>ra
 rows.append(dict(shape=[shape.width,shape.height],family='genuine_skip',common_ray=ra,common_added_skip=rb,changed=True))
write_record(p/'common-occupancy.json',dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start));print([(x['shape'],x['family'],x.get('common_equal',x.get('changed'))) for x in rows])
