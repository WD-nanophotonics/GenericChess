"""Full v2 migration caller qualification: leaf table x ordering table.
Changed premise from board-only ablation: hand prices and ordering now vary.
Four existing exposed roots,16Core cold calls, D2/8192nodes/5sec/q2hard8.
No cap extension or strength claim; original board-only calls remain frozen.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.cache import _profile_from_dict
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/rect-profile-20261009';files=[p/'cross-rule-exact.json',root/'.local_agent/generated6-20261008/coverage.json']
exact,coverage=[json.loads(f.read_bytes()) for f in files]
declared=[(202610082000,1),(202610082001,16),(202610082002,4),(202610082003,1)]
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
out=p/'full-migration-factorial.json';assert not out.exists()
res=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 input_hashes={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files},declared=declared,complete=False,cases=[])
cells=[('old','old'),('v2','old'),('old','v2'),('v2','v2')]
for i,(seed,ply) in enumerate(declared):
 for f in ('rollout.json','advisor.json','slack.json'):
  flags=json.loads((root/'.local_agent'/f).read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
 old=next(x for x in coverage['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
 for step in old['route'][:ply]:s.submit(action_from_dict(step['action']))
 prior=next(x for x in exact['cases'] if x['name']==str(seed))
 profiles={'old':_profile_from_dict(prior['old_profile']),'v2':build_ruleset_profile(c,cfg)}
 assert profiles['v2'].board_value_by_type==prior['exact_profile']['board_value_by_type']
 assert profiles['v2'].hand_value_by_base_type==prior['exact_profile']['hand_value_by_base_type']
 # All declared anchors are unique centrally symmetric short leaps: old/new
 # escape orientation and dedup correction cannot alter these callers.
 anchor_atoms=[]
 from generic_chess.core.movement import LeapAtom
 for pt in c.piece_types:
  if pt.is_anchor:
   offsets=[a.offset for a in pt.movement_atoms if isinstance(a,LeapAtom)]
   assert len(offsets)==len(pt.movement_atoms)==len(set(offsets))
   assert {(-a,-b) for a,b in offsets}==set(offsets)
   anchor_atoms.append(record_value(pt.movement_atoms))
 ordering={name:SemanticAttackEvaluator(c,profile,cfg,backend='core') for name,profile in profiles.items()}
 class Controlled(SemanticAttackEvaluator):
  def capture_order_value(self,*a):return self.order.capture_order_value(*a)
  def type_value(self,*a):return self.order.type_value(*a)
 before=(s.state,s.history,s._search_witnesses);r=dict(seed=seed,ply=ply,anchor_atoms=anchor_atoms,calls=[]);res['cases'].append(r)
 for leaf,order in cells[i:]+cells[:i]:
  ev=Controlled(c,profiles[leaf],cfg,backend='core');ev.order=ordering[order]
  player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
  start=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-start
  validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before
  r['calls'].append(dict(leaf=leaf,ordering=order,seconds=elapsed,decision=record_value(dec)));write_record(out,res)
  print(seed,leaf,order,dec.completed_depth,dec.termination_reason,dec.score,flush=True)
res['complete']=True;write_record(out,res)
