"""Changed semantic mechanism: zero/one/two required screens.
Tests opportunity compression, not equivalent encodings or material utility.
Large-board rows are formulas only. Actual Core controls use inert screen types.
"""
import sys,hashlib,time,itertools,math
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'));sys.path.insert(0,str(root/'tests/product'))
from test_rectangular_search_override import rectangular_cannon
from generic_chess.core.pieces import PieceType,Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
def closed(w,h,d,screens):
 q=1-d;lengths=[(L,2*h) for L in range(w)]+[(L,2*w) for L in range(h)]
 quiet=math.fsum(mult*math.fsum(q**(k+1) for k in range(L)) for L,mult in lengths)/(w*h)
 capture=math.fsum(mult*math.fsum(math.comb(k,screens)*d**(screens+1)/2*q**(k-screens) for k in range(screens,L)) for L,mult in lengths)/(w*h)
 return dict(density=d,screens=screens,quiet=quiet,capture=capture,total=quiet+capture)
densities=(0.,.125,.5,.875,1.);cfg=EvaluationConfig(density_points=densities,density_weights=(.2,)*5)
cases=[];start=time.perf_counter()
for w,h in ((5,3),(7,5),(9,10)):
 for screens in (0,1,2):
  definition=rectangular_cannon(w,h)
  # Zero screens here means a declared exact-zero prefix count, equivalent
  # to ordinary rook capture; quiet remains clear-prefix in every cell.
  actions=tuple(replace(a,path_constraints=tuple(replace(p,count=screens) if p.kind=='path_count_eq' else p for p in a.path_constraints)) if a.name=='cannon_capture' else a for a in definition.semantic_actions)
  c=compile_ruleset_for_execution(replace(definition,semantic_actions=actions))
  row=semantic_opportunity(c,'C',cfg);values=[closed(w,h,d,screens) for d in densities]
  for actual,expected in zip(row['curves'],values):
   for key in ('quiet','capture','total'):assert abs(actual[key]-expected[key])<1e-12
  cases.append(dict(width=w,height=h,screens=screens,semantic=row,closed_form=values))
  if (w,h)==(5,3):
   # Add an inert type so other friendly screens cannot themselves attack.
   d=replace(definition,piece_types=definition.piece_types+(PieceType('B','B',()),),drop_allowed={**definition.drop_allowed,'B':((False,)*15,)*2},semantic_actions=actions)
   engine=SemanticEngine(compile_ruleset_for_execution(d));template=engine._initial_position();checks=0
   for owner in (0,1):
    source,target=(0,4) if owner==0 else (4,0)
    for layout in itertools.product((None,0,1),repeat=3):
     for endpoint_owner in (None,0,1):
      board=[None]*15;board[source]=Piece(owner,'C','C')
      for idx,value in zip((1,2,3),layout):
       if value is not None:board[idx]=Piece(value,'B','B')
      if endpoint_owner is not None:board[target]=Piece(endpoint_owner,'B','B')
      position=replace(template,board=tuple(board),side_to_move=owner)
      expected=(sum(v is not None for v in layout)==screens)
      # S0/S1 pseudo-attack deliberately omits target-occupant eligibility,
      # including friendly targets. It is not executable-capture legality.
      assert engine.is_square_attacked(position,target,owner)==expected,(screens,owner,layout,endpoint_owner)
      checks+=1
   cases[-1]['actual_attack_controls']=checks
large=[dict(size=n,curves=[closed(n,n,.5,s) for s in (0,1,2)]) for n in (5,10,20,50,100)]
write_record(root/'.local_agent/rect-profile-20261009/cannon-screen-order.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=cases,large_closed_forms_only=large,seconds=time.perf_counter()-start))
print('9mechanism cells/45density controls; actual Core',sum(r.get('actual_attack_controls',0) for r in cases))
