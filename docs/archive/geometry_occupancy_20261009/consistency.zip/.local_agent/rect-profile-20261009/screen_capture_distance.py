"""Retained prerequisite component, not another static price formula.
Capture opportunity's endpoint-distance moment separates screen orders even
when total count tends to the same limit. Distance means ray landings, not
Manhattan length, travel time, WDL or material utility. Independent law only.
"""
import sys,math,hashlib,time
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'));sys.path.insert(0,str(root/'tests/product'))
from test_rectangular_search_override import rectangular_cannon
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.ir import geometry_candidates
from scripts.research_record import write_record
def measure(w,h,d,s):
 terms=[(k+1,mult*math.comb(k,s)*d**(s+1)/2*(1-d)**(k-s))
        for L,mult in [(L,2*h) for L in range(w)]+[(L,2*w) for L in range(h)]
        for k in range(s,L)]
 count=math.fsum(p for _,p in terms)/(w*h)
 moment=math.fsum(length*p for length,p in terms)/(w*h)
 return dict(density=d,screens=s,capture=count,distance_moment=moment,
             conditional_distance=moment/count if count else None,
             infinite_ray_conditional_distance=(s+1)/d if d else None)
rows=[];start=time.perf_counter()
for w,h in ((5,3),(7,5),(9,10)):
 for s in (0,1,2):
  definition=rectangular_cannon(w,h)
  actions=tuple(replace(a,path_constraints=tuple(replace(p,count=s) if p.kind=='path_count_eq' else p for p in a.path_constraints)) if a.name=='cannon_capture' else a for a in definition.semantic_actions)
  c=compile_ruleset_for_execution(replace(definition,semantic_actions=actions))
  pattern=next(p for p in c.ir.patterns if p.name=='cannon_capture')
  for d in (0.,.125,.5,1.):
   count=moment=0.
   for owner in ('0','1'):
    for source in range(w*h):
     for gid in pattern.geometry_ids:
      for _,path in geometry_candidates(c.ir.geometry[gid],owner,source):
       k=len(path)
       if k>=s:
        p=math.comb(k,s)*d**(s+1)/2*(1-d)**(k-s)
        count+=p;moment+=(k+1)*p
   count/=2*w*h;moment/=2*w*h
   row=measure(w,h,d,s)
   assert abs(count-row['capture'])<1e-12
   assert abs(moment-row['distance_moment'])<1e-12
   if d==1 and count:assert abs(row['conditional_distance']-(s+1))<1e-12
   rows.append(dict(width=w,height=h,**row))
large=[dict(size=n,rows=[measure(n,n,.5,s) for s in (0,1,2)]) for n in (5,10,20,50,100)]
write_record(root/'.local_agent/rect-profile-20261009/screen-capture-distance.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),finite_ir_controls=rows,large_closed_forms_only=large,seconds=time.perf_counter()-start))
print('36finite IR component controls;100x100formula only',[(x['screens'],x['conditional_distance']) for x in large[-1]['rows']])
