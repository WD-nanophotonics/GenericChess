"""Supported explicit primitive semantic opportunity on rectangular carriers.
Raw geometry only; does not enable profile/default/dynamics/Native support.
"""
import sys,json,hashlib,time
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
from dataclasses import replace
from rule_semantics_ir_fixtures import _king_type
from generic_chess.core.coordinates import BoardShape,index_to_square
from generic_chess.core.movement import LeapAtom,RayAtom,empty_mobility
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.schema import RuleSet,RuleGeometrySpec,RuleSemanticAction,RuleActionEffect,RuleSquareRef,RulePathConstraint
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.mobility import analytic_mobility_at_density
from scripts.research_record import write_record
families={'ray':(RayAtom((1,0)),),'short_redundant':(RayAtom((1,0)),LeapAtom((1,0))),
          'long_bypass':(RayAtom((1,0)),LeapAtom((2,0))),
          'non_axis':(RayAtom((2,1)),LeapAtom((4,2))),
          'crossing':(RayAtom((1,1)),RayAtom((-1,1)),LeapAtom((2,2)))}
cfg=EvaluationConfig(density_points=(0.,.125,.5,.875,1.),density_weights=(.2,)*5)
results=[];start=time.perf_counter()
for shape in (BoardShape(5,3),BoardShape(3,5),BoardShape(7,5)):
 for name,atoms in families.items():
  actions=[]
  for j,atom in enumerate(atoms):
   geom=(RuleGeometrySpec(kind='leap',offset=atom.offset) if isinstance(atom,LeapAtom)
         else RuleGeometrySpec(kind='ray',direction=atom.direction,max_steps=atom.max_steps))
   for relation in ('empty','enemy'):
    effects=(() if relation=='empty' else (RuleActionEffect('remove',square_ref=RuleSquareRef('target'),piece_owner='opponent'),))
    actions.append(RuleSemanticAction(name=f'{j}_{relation}',type_ids=('C',),geometry=geom,
      composition='augment',target_relation=relation,
      path_constraints=() if isinstance(atom,LeapAtom) else (RulePathConstraint('path_clear'),),
      effects=effects+(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),)))
  board=[None]*shape.area;board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K')
  rules=RuleSet(board_size=None,board_width=shape.width,board_height=shape.height,
    piece_types=(_king_type(),PieceType('C','C',())),
    initial_position=tuple(tuple(board[r*shape.width:(r+1)*shape.width]) for r in range(shape.height)),
    drop_allowed={'C':((False,)*shape.area,)*2},semantic_actions=tuple(actions))
  c=compile_ruleset_for_execution(rules);row=semantic_opportunity(c,'C',cfg)
  assert all('drop' in x['reasons'] for x in row['excluded'])
  exact=[analytic_mobility_at_density(shape,atoms,d) for d in cfg.density_points]
  errors=[abs(v-r['total']) for v,r in zip(exact,row['curves'])];assert max(errors)<1e-12
  engine=SemanticEngine(c);template=engine._initial_position();checks=0
  # Independent actual-effect attack authority, one blocker, no legal-safety claim.
  for owner in (0,1):
   for source in sorted({0,shape.width-1,shape.area//2,shape.area-1}):
    for blocker in [None]+[i for i in range(shape.area) if i!=source]:
     b=[None]*shape.area;b[source]=Piece(owner,'C','C')
     if blocker is not None:b[blocker]=Piece(1-owner,'C','C')
     position=replace(template,board=tuple(b),side_to_move=owner)
     expected=set()
     from generic_chess.core.movement import atom_targets
     for atom in atoms:
      for target in atom_targets(shape,owner,index_to_square(source,shape),atom):
       i=target.rank*shape.width+target.file;expected.add(i)
       if isinstance(atom,RayAtom) and i==blocker:break
     assert engine.attacked_squares(position,owner)==expected,(shape,name,source,blocker)
     checks+=1
  results.append(dict(width=shape.width,height=shape.height,name=name,geometry=exact,
                      semantic=row,max_error=max(errors),actual_attack_positions=checks))
write_record(root/'.local_agent/rect-profile-20261009/rectangular-semantic-bridge.json',
 dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=results,seconds=time.perf_counter()-start))
print('15rectangle families;75density cells;',sum(r['actual_attack_positions'] for r in results),'actual attack positions; max error',max(r['max_error'] for r in results))
