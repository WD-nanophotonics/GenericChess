"""Existing default-anchor score equality and local escape-call cost.
Microbenchmark only, not whole-search speedup. Old code is pinned Git9c4edde.
"""
import sys,json,ast,subprocess,hashlib,time,statistics
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.coordinates import Square,square_to_index
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
src=subprocess.check_output(['git','show','9c4edde:generic_chess/ai/evaluation/evaluator.py']).decode()
node=next(n for c in ast.parse(src).body if isinstance(c,ast.ClassDef) and c.name=='Evaluator' for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='_anchor_escape')
node.name='old_escape';ns={'Square':Square,'square_to_index':square_to_index,'LeapAtom':LeapAtom,'RayAtom':RayAtom,'Position':object};exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'pinned-old-escape','exec'),ns)
old=ns['old_escape'];cfg=EvaluationConfig();inp=root/'.local_agent/generated6-20261008/coverage.json';data=json.loads(inp.read_bytes());calls=[]
for row in data['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));e=Evaluator(c,build_ruleset_profile(c,cfg),cfg);s=GameSession(c)
 for step in [None]+row['route']:
  if step is not None:s.submit(action_from_dict(step['action']))
  maps=e._attack_maps(s.state)
  for owner in (0,1):
   args=(e,s.state.position,owner,maps[1-owner]);assert old(*args)==Evaluator._anchor_escape(*args)
   calls.append(args)
rows=[]
for rep in range(5):
 for name,fn in ((('old',old),('current',Evaluator._anchor_escape)) if rep%2==0 else (('current',Evaluator._anchor_escape),('old',old))):
  start=time.perf_counter();checksum=0
  for _ in range(25):
   for args in calls:checksum+=fn(*args)
  rows.append(dict(repeat=rep,method=name,seconds=time.perf_counter()-start,calls=25*len(calls),checksum=checksum))
res=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),old_source_sha256=hashlib.sha256(src.encode()).hexdigest(),input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),distinct_calls=len(calls),rows=rows)
out=root/'.local_agent/rect-profile-20261009'/('escape-cost-'+sys.argv[1]+'.json');assert not out.exists();write_record(out,res)
print('equal',len(calls),'calls; medians',{n:statistics.median(r['seconds'] for r in rows if r['method']==n) for n in ('old','current')})
