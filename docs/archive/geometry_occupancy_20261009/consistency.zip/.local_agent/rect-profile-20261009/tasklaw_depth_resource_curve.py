"""Fresh development resource point; previous5sec D3 caps remain unchanged.
Decision: distinguish D2-only task-table choice contrast from a completed D3
contrast. Either result narrows interpretation; a cap leaves D3 unknown and
does not trigger another extension. Two matched Core calls at15sec/8192nodes,
D3/q2hard8, pinned old/default table and prior board-only task table. No success
criterion, holdout qualification, old record or production default is changed.
Incremental worst-case time30sec; no worker, fees, training or heavy batch.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.cache import _profile_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/rect-profile-20261009';files=[p/'cross-rule-exact.json',root/'.local_agent/tasklaw-20261009/depth3-q2-control.json',root/'.local_agent/generated6-20261008/coverage.json']
exact,prior,coverage=[json.loads(f.read_bytes()) for f in files];old=next(x for x in coverage['cases'] if x['seed']==202610082002);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for step in old['route'][:4]:s.submit(action_from_dict(step['action']))
base=_profile_from_dict(next(x for x in exact['cases'] if x['name']=='202610082002')['old_profile'])
assert dict(base.board_value_by_type)==prior['boards']['default']
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
reference=SemanticAttackEvaluator(c,base,cfg,backend='core')
class FrozenOrdering(SemanticAttackEvaluator):
 def capture_order_value(self,*a):return reference.capture_order_value(*a)
 def type_value(self,*a):return reference.type_value(*a)
profiles={'default':base,'board_ablation':replace(base,board_value_by_type=prior['boards']['board_ablation'])}
out=p/'tasklaw-depth-resource-curve.json';assert not out.exists()
res=dict(scope=__doc__,complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_hashes={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files},boards=prior['boards'],calls=[])
before=(s.state,s.history,s._search_witnesses)
for name in ('board_ablation','default'):
 for f in ('rollout.json','advisor.json','slack.json'):
  flags=json.loads((root/'.local_agent'/f).read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
 ev=FrozenOrdering(c,profiles[name],cfg,backend='core');player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));start=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=15,quiescence_max_depth=2,quiescence_hard_max_depth=8));seconds=time.perf_counter()-start
 validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before
 res['calls'].append(dict(profile=name,seconds=seconds,decision=record_value(dec)));write_record(out,res)
 print(name,dec.completed_depth,dec.termination_reason,dec.score,flush=True)
res['complete']=True;write_record(out,res)
