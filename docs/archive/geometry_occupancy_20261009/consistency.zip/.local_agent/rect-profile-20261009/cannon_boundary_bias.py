"""Finite-board source-average cannon/rook opportunity gap, not material utility.
Same independent law; cannon quiet needs clear prefix, capture exactly one
screen. Rook and cannon share quiet opportunity. No human labels or fitting.
Large-board rows use closed forms only, not compiled geometry/heavy jobs.
"""
import sys,hashlib,time,math
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'));sys.path.insert(0,str(root/'tests/product'))
from test_rectangular_search_override import rectangular_cannon
from generic_chess.core.pieces import PieceType
from generic_chess.core.movement import RayAtom
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from scripts.research_record import write_record
densities=(0.,.125,.25,.5,.75,.875,1.)
cfg=EvaluationConfig(density_points=densities,density_weights=(1/7,)*7)
def closed(w,h,d):
 q=1-d
 # Count all directed paths across all sources. L is available ray length.
 lengths=[(L,2*h) for L in range(w)]+[(L,2*w) for L in range(h)]
 quiet=math.fsum(mult*math.fsum(q**(k+1) for k in range(L)) for L,mult in lengths)/(w*h)
 rook=math.fsum(mult*math.fsum(d/2*q**k for k in range(L)) for L,mult in lengths)/(w*h)
 cannon=math.fsum(mult*math.fsum(k*d*d/2*q**(k-1) for k in range(1,L)) for L,mult in lengths)/(w*h)
 gap=d*(math.fsum(L*q**(L-1) for L in range(1,w))/w+math.fsum(L*q**(L-1) for L in range(1,h))/h)
 assert abs(rook-cannon-gap)<1e-12
 return dict(density=d,quiet=quiet,rook_capture=rook,cannon_capture=cannon,
             capture_gap=gap,rook_total=quiet+rook,cannon_total=quiet+cannon,
             total_ratio=(quiet+cannon)/(quiet+rook))
cases=[];start=time.perf_counter()
for w,h in ((5,3),(7,5),(9,10)):
 definition=rectangular_cannon(w,h)
 actor=next(p for p in definition.piece_types if p.type_id=='C')
 definition=replace(definition,piece_types=definition.piece_types+(PieceType('R','R',actor.movement_atoms),),drop_allowed={**definition.drop_allowed,'R':((False,)*(w*h),)*2})
 c=compile_ruleset_for_execution(definition)
 rows={t:semantic_opportunity(c,t,cfg) for t in ('C','R')}
 assert all('drop' in x['reasons'] for row in rows.values() for x in row['excluded'])
 analytic=[]
 for d,cr,rr in zip(densities,rows['C']['curves'],rows['R']['curves']):
  a=closed(w,h,d)
  for actual,expected in ((cr['quiet'],a['quiet']),(rr['quiet'],a['quiet']),
      (cr['capture'],a['cannon_capture']),(rr['capture'],a['rook_capture'])):
   assert abs(actual-expected)<1e-12,(w,h,d,actual,expected)
  analytic.append(a)
 cases.append(dict(width=w,height=h,semantic=rows,closed_form=analytic))
large=[dict(width=n,height=n,cells=[closed(n,n,d) for d in (.125,.5,1.)]) for n in (5,10,20,50,100)]
write_record(root/'.local_agent/rect-profile-20261009/cannon-boundary-bias.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=cases,large_board_closed_forms_only=large,seconds=time.perf_counter()-start))
print('21cannon/rook semantic density cells agree; rho.5 ratios',[(r['width'],r['height'],next(x for x in r['closed_form'] if x['density']==.5)['total_ratio']) for r in cases])
print('large formula only',[(r['width'],r['cells'][1]['total_ratio']) for r in large])
