"""Matched primitive geometry and existing semantic projection, not material value.
No search, human labels, cache writes or changed context law. Uses existing
lowering; tests hybrid unions now covered by the exact default as well.
"""
import sys, json, hashlib, time
from pathlib import Path
from dataclasses import replace
root = Path.cwd(); sys.path.insert(0, str(root)); sys.path.insert(0, str(root/'tests'))
from rule_semantics_ir_fixtures import _king_type, _semantic_ruleset
from generic_chess.core.pieces import PieceType
from generic_chess.core.movement import LeapAtom, RayAtom
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.mobility import analytic_mobility_at_density
from generic_chess.ai.evaluation.analyzer import build_movement_capability
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from scripts.research_record import write_record
families = {
 'balanced': (LeapAtom((0,1)), LeapAtom((0,-1))),
 'duplicate': (LeapAtom((0,1)), LeapAtom((0,-1)), LeapAtom((0,1))),
 'ray': (RayAtom((1,0)),),
 'saturated': (RayAtom((1,0),999),),
 'short_redundant': (RayAtom((1,0)), LeapAtom((1,0))),
 'long_bypass': (RayAtom((1,0)), LeapAtom((2,0))),
 'non_axis': (RayAtom((2,1)), LeapAtom((4,2))),
 'crossing': (RayAtom((1,1)), RayAtom((-1,1)), LeapAtom((2,2))),
}
cfg=EvaluationConfig(density_points=(0.,.125,.5,.875,1.),density_weights=(.2,)*5)
rows=[]; start=time.perf_counter()
for n in (3,5,8):
 for name, atoms in families.items():
  definition=_semantic_ruleset((_king_type(), PieceType('C','C',atoms)), (), n=n)
  compiled=compile_ruleset_for_execution(definition)
  row=semantic_opportunity(compiled,'C',cfg)
  # Lowered drop also has non-move/compound reasons. Decline all drops;
  # require no excluded board pattern, rather than an exact reason list.
  assert all('drop' in e['reasons'] for e in row['excluded'])
  geom=[analytic_mobility_at_density(n,atoms,d) for d in cfg.density_points]
  errors=[abs(g-c['total']) for g,c in zip(geom,row['curves'])]
  assert max(errors)<1e-12,(n,name,errors)
  # Quiet/capture are intentionally separate, with the same prefix event.
  for c in row['curves']:
   d=c['density']
   assert abs(c['quiet']*d/2-c['capture']*(1-d))<1e-12
  cap=build_movement_capability(n,atoms,cfg)
  rows.append(dict(n=n,name=name,geometry=geom,semantic=row,
                   max_error=max(errors),asymmetry=cap.directional_asymmetry))
write_record(root/'.local_agent/rect-profile-20261009/primitive-semantic-bridge.json',
 dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      cases=rows,seconds=time.perf_counter()-start))
print('24families/120density comparisons qualified; max error',max(r['max_error'] for r in rows))
