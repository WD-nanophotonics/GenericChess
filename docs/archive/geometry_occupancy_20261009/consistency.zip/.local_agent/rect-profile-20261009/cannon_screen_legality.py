"""Actual quiet/capture and transition controls for changed screen mechanisms.
Separate from S0/S1 attack eligibility and independent opportunity projection.
No WDL, full search, price-quality or Native claim.
"""
import sys,itertools,hashlib,time
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'));sys.path.insert(0,str(root/'tests/product'))
from test_rectangular_search_override import rectangular_cannon
from generic_chess.core.pieces import PieceType,Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from scripts.research_record import write_record
rows=[];start=time.perf_counter()
for screens in (0,1,2):
 d=rectangular_cannon(5,3)
 actions=tuple(replace(a,path_constraints=tuple(replace(p,count=screens) if p.kind=='path_count_eq' else p for p in a.path_constraints)) if a.name=='cannon_capture' else a for a in d.semantic_actions)
 d=replace(d,piece_types=d.piece_types+(PieceType('B','B',()),),drop_allowed={**d.drop_allowed,'B':((False,)*15,)*2},semantic_actions=actions)
 engine=SemanticEngine(compile_ruleset_for_execution(d));template=engine._initial_position();checks=captures=quiet=0
 for owner in (0,1):
  source,target=(0,4) if owner==0 else (4,0)
  for layout in itertools.product((None,0,1),repeat=3):
   for endpoint_owner in (None,0,1):
    b=[None]*15;b[10]=Piece(0,'K','K');b[14]=Piece(1,'K','K');b[source]=Piece(owner,'C','C')
    for idx,v in zip((1,2,3),layout):
     if v is not None:b[idx]=Piece(v,'B','B')
    if endpoint_owner is not None:b[target]=Piece(endpoint_owner,'B','B')
    pos=replace(template,board=tuple(b),side_to_move=owner)
    count=sum(v is not None for v in layout)
    expected=(count==0 if endpoint_owner is None else endpoint_owner!=owner and count==screens)
    matches=[a for a in engine.legal_actions(pos) if a.source==source and a.target==target]
    assert bool(matches)==expected,(screens,owner,layout,endpoint_owner,expected)
    for action in matches:
     child=engine.apply(pos,action)
     assert child.board[source] is None and child.board[target]==Piece(owner,'C','C')
     assert pos.board==tuple(b)
    captures+=bool(matches) and endpoint_owner is not None
    quiet+=bool(matches) and endpoint_owner is None
    checks+=1
 rows.append(dict(screens=screens,positions=checks,captures=captures,quiet=quiet))
write_record(root/'.local_agent/rect-profile-20261009/cannon-screen-legality.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=rows,seconds=time.perf_counter()-start))
print(rows)
