"""Observed dynamic short-escape encoding/frame defects, prior to correction."""
import sys,json,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
from conftest import T,make_ruleset,make_state
from generic_chess.rules.compiler import compile_ruleset
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=1,promotion_potential_weight=0)
rows=[]
for name,atoms in [('single',(LeapAtom((0,1)),)),('duplicate',(LeapAtom((0,1)),)*2),('ray',(RayAtom((0,1),1),))]:
 c=compile_ruleset(make_ruleset(4,[T('K',*atoms,is_anchor=True),T('R',RayAtom((1,0)))]))
 e=Evaluator(c,build_ruleset_profile(c,cfg),cfg)
 for lines in (['...k','....','....','K...'],['...k','...R','....','K...']):
  s=make_state(c,lines)
  rows.append(dict(name=name,lines=lines,escape=[e._anchor_escape(s.position,o,set()) for o in (0,1)],score=e.evaluate(s)))
write_record(root/'.local_agent/rect-profile-20261009/anchor-frame-before.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=rows))
print(rows)
