import ast,json,time
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011');ns=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 ns.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=ns,type_ignores=[]),'<reused>','exec'),E)
from generic_chess.core.movegen import legal_actions
R=E['R'];oa=R.attach_stats;of=E['pm'].SearchStatistics;out={'complete':False,'rows':[]};begin=time.perf_counter()
try:
 R.attach_stats=E['attach'];E['pm'].SearchStatistics=E['factory']
 for root in ('chess-middle','chess-ep','shogi-middle','shogi-drop'):
  case=next(x for x in E['CASES'] if x['id']==root);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));board=E['CoreBoard'](case,c);ev=E['w'].weighted(c,E['VALUES'][case['game']]);legal=legal_actions(board.initial,c)
  for seconds in (16,64):
   for order in range(2):
    for native in ((False,True) if order==0 else (True,False)):
     E['stopped']();assert time.perf_counter()-begin<1800;E['runtimes']=[];E['captured']=[]
     session=E['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses)
     t=time.perf_counter();player=E['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=native,use_disk_cache=False);prep=time.perf_counter()-t;t=time.perf_counter()
     v=player.choose_action(session,E['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
     rt,st=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==st and v.action in legal
     out['rows'].append({'root':root,'seconds':seconds,'order':order,'native_requested':native,'setup_seconds':prep,'wall':wall,'decision':E['record_value'](v),'stats':E['record_value'](E['captured'][0]),'public_action_legal':True,'actual_root_restored':True})
     (B/'capability-result.json').write_text(json.dumps(out,indent=2)+'\n');print(root,seconds,order,native,'D',v.completed_depth,'score',v.score,'reason',v.termination_reason,flush=True)
 out['complete']=True;out['wall_seconds']=time.perf_counter()-begin;(B/'capability-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:R.attach_stats=oa;E['pm'].SearchStatistics=of
