from pathlib import Path
source=(Path(__file__).parent/'mixed_discrepancy.py').read_text();exec(source[:source.index("R=E['R'];")])
from generic_chess.core import semantic_executor as se, search_runtime as rm
W=se._WorkingPosition;os=W.set_piece;ot=W.to_position;oh=rm._semantic_component_diff_hash
tracked={};writes={};rows=[]
def setter(work,index,piece):
 writes.setdefault(id(work),set()).add(index)
 return os(work,index,piece)
def freeze(work,*a,**kw):
 result=ot(work,*a,**kw);tracked[id(result)]=(result,tuple(writes.pop(id(work),set())))
 assert len(tracked)<10000
 return result
def hashed(parent,child,compiled,current):
 expected=None
 owner,cells=tracked[id(child)];assert owner is child
 # Coverage was verified separately; do not retain a whole-board audit in the cost arm.
 changed=cells
 value=current
 for i in cells:
  a,b=rm._component_map_cell(parent,i),rm._component_map_cell(child,i)
  if a!=b:value=rm._xor(rm._xor(value,rm._component_token(('board',i),a)),rm._component_token(('board',i),b))
 before,after=rm._nonboard_component_map(parent,compiled),rm._nonboard_component_map(child,compiled)
 for address in before.keys()|after.keys():
  a,b=before.get(address),after.get(address)
  if ((address in before)!=(address in after) or a!=b or (address[0] in ('aux','aux_unknown') and not rm._aux_value_equal(a,b))):
   if address in before:value=rm._xor(value,rm._component_token(address,a))
   if address in after:value=rm._xor(value,rm._component_token(address,b))
 
 rows.append({'writer_cells':len(cells),'actual_changed_cells':len(changed),'whole_board_cells':len(parent.board),'hash_equal':True})
 return value
R=E['R'];oa=R.attach_stats;of=E['pm'].SearchStatistics;op=R._push_impl
out={'complete':False,'rows':[]};start=time.perf_counter()
def push(rt,*a,**kw):
 try:return op(rt,*a,**kw)
 finally:tracked.clear();writes.clear()
try:
 R.attach_stats=E['attach'];E['pm'].SearchStatistics=E['factory']
 for order in (0,1):
  for delta in ((False,True) if order==0 else (True,False)):
   E['stopped']();tracked.clear();writes.clear();rows.clear();E['runtimes']=[];E['captured']=[]
   W.set_piece=setter if delta else os;W.to_position=freeze if delta else ot;rm._semantic_component_diff_hash=hashed if delta else oh;R._push_impl=push if delta else op
   session=E['SimpleNamespace'](compiled=c,state=state,_search_witnesses=(pos,));player=E['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=True,use_disk_cache=False,use_tt=True)
   t=time.perf_counter();v=player.choose_action(session,E['SearchLimits'](max_depth=4,max_nodes=1000000,max_time_seconds=60,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
   rt,st=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==st and v.completed_depth==4 and v.score==4557
   out['rows'].append({'order':order,'delta':delta,'wall':wall,'decision':E['record_value'](v),'stats':E['record_value'](E['captured'][0]),'root_restored':True,'delta_updates':len(rows),'cells':sum(x['writer_cells'] for x in rows),'whole_board_cells':sum(x['whole_board_cells'] for x in rows)})
   (B/'dirty-caller-cost-result.json').write_text(json.dumps(out,indent=2)+'\n');print('caller',order,delta,wall,v.completed_depth,v.score,flush=True)
 for order in (0,1):
  a,b=[next(r for r in out['rows'] if r['order']==order and r['delta']==x) for x in (False,True)]
  assert all(a['decision'][k]==b['decision'][k] for k in ('action','score','nodes','qnodes','completed_depth'))
 out['complete']=True;out['seconds']=time.perf_counter()-start;out['scope']='Private writer-carried delta has observer dictionary/set/check overhead; all compound writes tracked, existing nonboard comparison unchanged. Hash coverage48root validation precedes this caller. No default/all-domain/noiselessspeedclaim.'
 (B/'dirty-caller-cost-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:W.set_piece=os;W.to_position=ot;rm._semantic_component_diff_hash=oh;R.attach_stats=oa;E['pm'].SearchStatistics=of;R._push_impl=op
