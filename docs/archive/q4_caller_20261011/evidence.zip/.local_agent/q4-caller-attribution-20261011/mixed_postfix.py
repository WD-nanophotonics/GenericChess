import ast,json,time,sys
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011');ns=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 ns.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=ns,type_ignores=[]),'<reused>','exec'),E)
sys.path[:0]=[str(Path.cwd()/'tests/product'),str(Path.cwd()/'.local_agent/availability-core-20261011')]
from semantic_profile_adapter import SearchSemanticCompiled
from test_f24c_mixed_mechanic_certification import _compiled
from test_f24c_mixed_mechanic_certification_r1 import _simultaneous,_state
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core.movegen import legal_actions
src=_compiled();c=SearchSemanticCompiled(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);pos=_simultaneous(c);state=_state(c,pos);cfg=EvaluationConfig();ev=Evaluator(c,build_ruleset_profile(c,cfg),cfg);legal=legal_actions(state,c)
R=E['R'];oa=R.attach_stats;of=E['pm'].SearchStatistics;out={'complete':False,'rows':[]};begin=time.perf_counter()
try:
 R.attach_stats=E['attach'];E['pm'].SearchStatistics=E['factory']
 for tt in (False,True):
  for native in (False,True):
   E['stopped']();assert time.perf_counter()-begin<500;E['runtimes']=[];E['captured']=[];session=E['SimpleNamespace'](compiled=c,state=state,_search_witnesses=(pos,));player=E['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=native,use_disk_cache=False,use_tt=tt);t=time.perf_counter();v=player.choose_action(session,E['SearchLimits'](max_depth=4,max_nodes=1000000,max_time_seconds=90,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
   rt,st=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==st and v.action in legal
   out['rows'].append({'tt':tt,'native_requested':native,'wall':wall,'decision':E['record_value'](v),'stats':E['record_value'](E['captured'][0]),'public_action_legal':True,'actual_root_restored':True});(B/'mixed-postfix-result.json').write_text(json.dumps(out,indent=2)+'\n');print('mixed D4',tt,native,v.completed_depth,v.score,v.termination_reason,flush=True)
 out['complete']=True;out['wall_seconds']=time.perf_counter()-begin;(B/'mixed-postfix-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:R.attach_stats=oa;E['pm'].SearchStatistics=of
