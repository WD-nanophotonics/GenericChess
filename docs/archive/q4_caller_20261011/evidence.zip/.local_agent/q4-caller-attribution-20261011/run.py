import ast,json,time,sys,collections
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011')
nodes=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 nodes.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<reused-control>','exec'),E)
from generic_chess.ai.alphabeta import search as sm
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core import search_runtime as rm
R=E['R'];oldattach=R.attach_stats;oldfactory=E['pm'].SearchStatistics;oldpush=R._push_impl;oldpop=R.pop;oldnoisy=sm.noisy_child;oldq=sm._quiescence_runtime
frames=[];pending={};totals=collections.Counter();qlevel=0;active=False
engine_names=['_transition','_trial_child_if_s3_legal','in_check','has_legal_action']
oldengine={n:getattr(SemanticEngine,n) for n in engine_names};oldgave=R._gave_check;oldterm=rm.terminal_from_search_runtime
oldhash=rm._semantic_component_diff_hash;oldsnap=rm.RuntimeCountsSnapshot.updated;oldhist=rm.RuntimeHistoryContext.append
clock=[];outside=collections.Counter()
def stage(name,fn):
 def call(*a,**kw):
  target=frames[-1] if frames else outside;t=time.perf_counter();f=[0.0];clock.append(f)
  try:return fn(*a,**kw)
  finally:
   wall=time.perf_counter()-t;clock.pop()
   if clock:clock[-1][0]+=wall
   target[name+'.calls']+=1;target[name+'.inclusive_seconds']+=wall;target[name+'.exclusive_seconds']+=wall-f[0]
 return call
def push(rt,*a,**kw):
 target=collections.Counter();frames.append(target);t=time.perf_counter()
 try:return oldpush(rt,*a,**kw)
 finally:
  wall=time.perf_counter()-t;frames.pop()
  target['push.inclusive_seconds']+=wall
  pending[id(rt._frames[-1])]=(bool(qlevel),target)
def consume(frame,outcome):
 data=pending.pop(id(frame),None)
 if data is None:return
 qp,v=data;totals[(qp,outcome,'children')]+=1
 for k,x in v.items():totals[(qp,outcome,k)]+=x
def pop(rt,*a,**kw):
 if rt._frames:consume(rt._frames[-1],'unclassified')
 return oldpop(rt,*a,**kw)
def noisy(action,child,*a,**kw):
 v=oldnoisy(action,child,*a,**kw);consume(child._runtime._frames[-1],'included' if v else 'excluded');return v
def q(*a,**kw):
 global qlevel
 qlevel+=1
 try:return oldq(*a,**kw)
 finally:qlevel-=1
def install(on):
 R._push_impl=push if on else oldpush;R.pop=pop if on else oldpop;sm.noisy_child=noisy if on else oldnoisy;sm._quiescence_runtime=q if on else oldq
 for n,f in oldengine.items():setattr(SemanticEngine,n,stage('Engine'+n,f) if on else f)
 R._gave_check=stage('gave_check',oldgave) if on else oldgave;rm.terminal_from_search_runtime=stage('terminal',oldterm) if on else oldterm
 rm._semantic_component_diff_hash=stage('component_diff',oldhash) if on else oldhash
 rm.RuntimeCountsSnapshot.updated=stage('count_snapshot',oldsnap) if on else oldsnap
 rm.RuntimeHistoryContext.append=staticmethod(stage('history_context',oldhist) if on else oldhist)
def clean(v):
 if isinstance(v,dict):return {k:clean(x) for k,x in v.items() if 'seconds' not in k and not k.startswith('time_')}
 if isinstance(v,list):return list(map(clean,v))
 return v
out={'complete':False,'rows':[]};start=time.perf_counter()
try:
 R.attach_stats=E['attach'];E['pm'].SearchStatistics=E['factory']
 for root in ('chess-middle','shogi-middle'):
  case=next(x for x in E['CASES'] if x['id']==root);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));board=E['CoreBoard'](case,c);ev=E['w'].weighted(c,E['VALUES'][case['game']])
  for native in (False,True):
   pair=[]
   for measured in (False,True):
    E['stopped']();frames=[];pending={};totals=collections.Counter();outside=collections.Counter();clock=[];qlevel=0;E['runtimes']=[];E['captured']=[]
    s=E['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses)
    p=E['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=native,use_disk_cache=False)
    install(measured);t=time.perf_counter()
    try:d=p.choose_action(s,E['SearchLimits'](max_depth=2,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    finally:install(False)
    rt,rs=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==rs and not pending and not frames and not clock
    value=E['record_value'](d);pair.append(clean(value));out['rows'].append({'root':root,'native_requested':native,'measured':measured,'wall':time.perf_counter()-t,'decision':value,'stats':E['record_value'](E['captured'][0]),'root_actual_restored':True,'stages':[{'qphase':q,'outcome':o,'metric':m,'value':v} for (q,o,m),v in sorted(totals.items())],'outside_push_stages':dict(outside)})
    (B/'result.json').write_text(json.dumps(out,indent=2)+'\n');print(root,native,measured,d.completed_depth,d.score,d.termination_reason,flush=True)
   out['rows'][-1]['exact_plain_nonclock_decision']=pair[0]==pair[1]
 out['complete']=True;out['seconds']=time.perf_counter()-start;out['scope']='Formal push child outcomes with nested stage clocks; outside-push legality/trials separate. C internal cost opaque; Python wrapper timing includes instrumentation. Timeouts preserve actual changed work, never claimed transparent if decision differs.';(B/'result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:install(False);R.attach_stats=oldattach;E['pm'].SearchStatistics=oldfactory
