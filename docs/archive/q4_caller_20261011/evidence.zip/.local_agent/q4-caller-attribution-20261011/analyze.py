import json,statistics,hashlib
from pathlib import Path
B=Path(__file__).parent
def load(n):return json.loads((B/n).read_text(encoding='utf-8-sig'))
def summarize(name,expected):
 d=load(name);assert d['complete'] and len(d['rows'])==expected
 rows=d['rows'];keys=[(r['root'],r['seconds'],r['order'],r['native_requested']) for r in rows];assert len(set(keys))==expected
 paired=[];cells=[]
 for root in dict.fromkeys(r['root'] for r in rows):
  for seconds in dict.fromkeys(r['seconds'] for r in rows if r['root']==root):
   for order in (0,1):
    arms=[next(r for r in rows if (r['root'],r['seconds'],r['order'],r['native_requested'])==(root,seconds,order,n)) for n in (False,True)]
    a,b=arms;paired.append({'root':root,'seconds':seconds,'order':order,'core_depth':a['decision']['completed_depth'],'native_depth':b['decision']['completed_depth'],'same_action':a['decision']['action']==b['decision']['action'],'same_score':a['decision']['score']==b['decision']['score'],'same_retained_q':a['stats']['result_ordinary_qdepth']==b['stats']['result_ordinary_qdepth'],'work_ratio':(b['decision']['nodes']+b['decision']['qnodes'])/(a['decision']['nodes']+a['decision']['qnodes']),'push_ratio':b['stats']['runtime_pushes']/a['stats']['runtime_pushes'] if a['stats']['runtime_pushes'] else None})
   for native in (False,True):
    rs=[r for r in rows if r['root']==root and r['seconds']==seconds and r['native_requested']==native]
    cells.append({'root':root,'seconds':seconds,'native_requested':native,'completed_depths':[r['decision']['completed_depth'] for r in rs],'scores':[r['decision']['score'] for r in rs],'retained_q':[r['stats']['result_ordinary_qdepth'] for r in rs],'reasons':[r['decision']['termination_reason'] for r in rs],**{k:statistics.mean(r['stats'][k] for r in rs) for k in ('nodes','qnodes','runtime_pushes','legal_generation_seconds','evaluation_seconds','native_legality_seconds','native_legality_payload_seconds','native_legality_decode_binding_seconds','native_legality_calls','native_legality_actions','native_legality_fallbacks','native_legality_operational_failures','qsearch_check_hard_limit_aborts')},'wall_mean':statistics.mean(r['wall'] for r in rs),'setup_mean':statistics.mean(r['setup_seconds'] for r in rs)})
 for r in rows:
  s=r['stats'];assert r['actual_root_restored'] and r['public_action_legal'];assert s['runtime_pushes']==s['runtime_pops'] and s['runtime_depth_balanced'];assert not s['native_legality_operational_failures']
 return {'complete':True,'calls':expected,'cells':cells,'pairs':paired,'pairs_deeper_native':sum(p['native_depth']>p['core_depth'] for p in paired),'pairs_deeper_core':sum(p['native_depth']<p['core_depth'] for p in paired),'pairs_changed_action':sum(not p['same_action'] for p in paired),'totals':{k:sum(r['stats'][k] for r in rows) for k in ('nodes','qnodes','runtime_pushes','runtime_pops','native_legality_calls','native_legality_actions','native_legality_fallbacks','native_legality_operational_failures','evaluation_calls','legal_generation_calls')},'wall_sum':sum(r['wall'] for r in rows),'setup_sum':sum(r['setup_seconds'] for r in rows),'limits':'Attempted main+q visits and physical transitions include incomplete final iteration. Retained q metadata is authoritative; completed layer alone is not aligned-q or strength. Legal/evaluation/provider clocks nested/partial, not additive total; native internals opaque. Ordinary concurrent load, no exclusivity claim; opposite order controls not noise-free guarantee.'}
if (B/'capability-result.json').exists() and load('capability-result.json')['complete']:
 a=summarize('capability-result.json',32);(B/'capability-analysis.json').write_text(json.dumps(a,indent=2)+'\n');print('builtin',a['pairs_deeper_native'],a['pairs_changed_action'],a['totals'])
if (B/'generic-capability-result.json').exists() and load('generic-capability-result.json')['complete']:
 a=summarize('generic-capability-result.json',24);(B/'generic-capability-analysis.json').write_text(json.dumps(a,indent=2)+'\n');print('generated',a['pairs_deeper_native'],a['pairs_changed_action'],a['totals'])
# Reuse existing matching-work profile, never rerun or splice its times into memo or q4 callers.
p=json.loads(Path('.local_agent/availability-core-20261011/residual-function-profile.json').read_text());out={'scope':'Existing hybrid no-memo lexical q0 D2 cProfile. Different memo condition than DEV_AUX parsed hybrid+memo; no new execution. Nested clocks separate, observer inflation unknown by component. Current load policy does not upgrade old measurements.','rows':[]}
for root in ('shogi-drop','shogi-tactic'):
 plain=next(r for r in p['rows'] if r['root']==root and not r['profiled']);profile=next(r for r in p['rows'] if r['root']==root and r['profiled']);assert plain['decision']['work']==profile['decision']['work'];assert plain['decision']['move']==profile['decision']['move'] and plain['decision']['score']==profile['decision']['score']
 fs=[f for f in profile['functions'] if f['name'] in ('push','terminal_from_search_runtime','has_legal_action','_legal_actions_from_provider','evaluate','pop','_semantic_component_diff_hash')]
 out['rows'].append({'root':root,'work':plain['decision']['work'],'plain_wall':plain['decision']['wall_seconds'],'profile_wall':profile['decision']['wall_seconds'],'same_work_action_score':True,'functions':fs})
(B/'existing-profile-reuse.json').write_text(json.dumps(out,indent=2)+'\n')
