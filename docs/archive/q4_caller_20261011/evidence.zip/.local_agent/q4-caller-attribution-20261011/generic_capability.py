import ast,json,time,sys
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011');ns=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 ns.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=ns,type_ignores=[]),'<reused>','exec'),E)
sys.path[:0]=[str(Path.cwd()/'tests/product'),str(Path.cwd()/'.local_agent/availability-core-20261011')]
from semantic_profile_adapter import SearchSemanticCompiled
from test_f24c_mixed_mechanic_certification import _compiled
from test_f24c_mixed_mechanic_certification_r1 import _simultaneous,_state
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
R=E['R'];oa=R.attach_stats;of=E['pm'].SearchStatistics;out={'complete':False,'rows':[]};begin=time.perf_counter()
try:
 R.attach_stats=E['attach'];E['pm'].SearchStatistics=E['factory']
 for kind,seed,size in (('generated',13,8),('generated',15,8),('mixed',None,None)):
  src=_compiled() if kind=='mixed' else compile_legacy_ruleset_for_semantic_execution(generate_game(GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True)).ruleset)
  c=SearchSemanticCompiled(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
  if kind=='mixed':pos=_simultaneous(c);state=_state(c,pos)
  else:state=GameSession(c).state;pos=state.position
  cfg=EvaluationConfig();ev=Evaluator(c,build_ruleset_profile(c,cfg),cfg);legal=legal_actions(state,c);root=f'{kind}-{seed}-{size}'
  for seconds in (4,16):
   for order in range(2):
    for native in ((False,True) if order==0 else (True,False)):
     E['stopped']();assert time.perf_counter()-begin<600;E['runtimes']=[];E['captured']=[];session=E['SimpleNamespace'](compiled=c,state=state,_search_witnesses=(pos,))
     t=time.perf_counter();player=E['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=native,use_disk_cache=False);setup=time.perf_counter()-t;t=time.perf_counter();v=player.choose_action(session,E['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
     rt,st=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==st and session.state is state
     assert v.action in legal if v.action is not None else bool(v.declaration or state.terminal_status.is_terminal)
     out['rows'].append({'root':root,'seconds':seconds,'order':order,'native_requested':native,'ruleset_fingerprint':c.ruleset_fingerprint,'setup_seconds':setup,'wall':wall,'decision':E['record_value'](v),'stats':E['record_value'](E['captured'][0]),'public_action_legal':True,'actual_root_restored':True,'adapter':'SearchSemanticCompiled existing read-only metadata adapter; same object per paired Core/Native arms'})
     (B/'generic-capability-result.json').write_text(json.dumps(out,indent=2)+'\n');print(root,seconds,order,native,'D',v.completed_depth,'score',v.score,'reason',v.termination_reason,flush=True)
 out['complete']=True;out['wall_seconds']=time.perf_counter()-begin;(B/'generic-capability-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:R.attach_stats=oa;E['pm'].SearchStatistics=of
