from pathlib import Path
source=(Path(__file__).parent/'mixed_discrepancy.py').read_text();exec(source[:source.index("R=E['R'];")])
from generic_chess.core import semantic_executor as se, search_runtime as rm
W=se._WorkingPosition;os=W.set_piece;ot=W.to_position;oh=rm._semantic_component_diff_hash
tracked={};writes={};rows=[]
def setter(work,index,piece):
 writes.setdefault(id(work),set()).add(index)
 return os(work,index,piece)
def freeze(work,*a,**kw):
 result=ot(work,*a,**kw);tracked[id(result)]=(result,tuple(writes.pop(id(work),set())))
 assert len(tracked)<10000
 return result
def hashed(parent,child,compiled,current):
 expected=oh(parent,child,compiled,current)
 owner,cells=tracked[id(child)];assert owner is child
 changed={i for i,(a,b) in enumerate(zip(parent.board,child.board)) if a!=b}
 assert changed<=set(cells)
 value=current
 for i in cells:
  a,b=rm._component_map_cell(parent,i),rm._component_map_cell(child,i)
  if a!=b:value=rm._xor(rm._xor(value,rm._component_token(('board',i),a)),rm._component_token(('board',i),b))
 before,after=rm._nonboard_component_map(parent,compiled),rm._nonboard_component_map(child,compiled)
 for address in before.keys()|after.keys():
  a,b=before.get(address),after.get(address)
  if ((address in before)!=(address in after) or a!=b or (address[0] in ('aux','aux_unknown') and not rm._aux_value_equal(a,b))):
   if address in before:value=rm._xor(value,rm._component_token(address,a))
   if address in after:value=rm._xor(value,rm._component_token(address,b))
 assert value==expected
 rows.append({'writer_cells':len(cells),'actual_changed_cells':len(changed),'whole_board_cells':len(parent.board),'hash_equal':True})
 return expected
try:
 W.set_piece=setter;W.to_position=freeze;rm._semantic_component_diff_hash=hashed
 rt=rm.SearchPathRuntime(state,c,history_witnesses=(pos,));before=E['state'](rt)
 actions=tuple(rt.legal_actions());assert len(actions)==48
 for action in actions:rt.push(action);rt.pop();assert E['state'](rt)==before
 rt.assert_balanced();assert len(rows)==48
 result={'complete':True,'rows':rows,'actual_root_restored':True,'scope':'Actual writer interception, existing nonboard logic retained, old hash returned.48rootchildren only. Pass outside this path. No speed/all-domain proof.'}
 (B/'dirty-writer-result.json').write_text(json.dumps(result,indent=2)+'\n');print('writer48',sum(r['writer_cells'] for r in rows),sum(r['whole_board_cells'] for r in rows),flush=True)
finally:W.set_piece=os;W.to_position=ot;rm._semantic_component_diff_hash=oh
