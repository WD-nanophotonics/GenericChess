from pathlib import Path
source=(Path(__file__).parent/'mixed_discrepancy.py').read_text(encoding='utf-8-sig');exec(source[:source.index("R=E['R'];")])
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.core import search_runtime as rm
R=E['R'];oa=R.attach_stats;of=E['pm'].SearchStatistics;og=R._legal_actions_from_provider;op=R._push_impl;oo=R.pop
paths={};out={'complete':False,'checked_frontiers':0,'binding_pairs':0,'mismatches':[]};start=time.perf_counter()
def push(rt,*a,**kw):
 value=op(rt,*a,**kw);paths.setdefault(id(rt),[]).append(a[0]);return value
def pop(rt,*a,**kw):
 value=oo(rt,*a,**kw)
 if paths.get(id(rt)):paths[id(rt)].pop()
 return value
def observed(rt,checkpoint):
 value=og(rt,checkpoint)
 if value is None or out['checked_frontiers']>=2000 or len(out['mismatches'])>=4:return value
 engine=semantic_engine_for(rt.compiled);pairs=tuple(engine.iter_legal_action_bindings(rt.position,checkpoint=checkpoint));core={_semantic_public_action(engine,a):(a,b) for a,b in pairs};native=value[1];out['checked_frontiers']+=1
 same=set(core)&set(native);different=[a for a in same if core[a]!=native[a]];out['binding_pairs']+=len(same)
 if set(core)!=set(native) or different:
  out['mismatches'].append({'depth':rt.depth,'ply':rt.ply_count,'path':E['record_value'](paths.get(id(rt),[])),'position':E['record_value'](rt.position),'core_only':E['record_value'](list(set(core)-set(native))),'native_only':E['record_value'](list(set(native)-set(core))),'binding_differences':E['record_value']([{ 'action':a,'core':core[a],'native':native[a]} for a in different[:8]]),'core_action_count':len(core),'native_action_count':len(native),'core_duplicate_actions':len(pairs)-len(core)})
 return value
try:
 E['stopped']();R.attach_stats=E['attach'];E['pm'].SearchStatistics=E['factory'];R._legal_actions_from_provider=observed;R._push_impl=push;R.pop=pop;E['runtimes']=[];E['captured']=[];session=E['SimpleNamespace'](compiled=c,state=state,_search_witnesses=(pos,));player=E['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=True,use_disk_cache=False,use_tt=False)
 v=player.choose_action(session,E['SearchLimits'](max_depth=4,max_nodes=1000000,max_time_seconds=90,quiescence_max_depth=4,quiescence_hard_max_depth=8));rt,st=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==st and not paths[id(rt)]
 out.update(complete=True,decision=E['record_value'](v),stats=E['record_value'](E['captured'][0]),actual_root_restored=True,seconds=time.perf_counter()-start,scope='Transparent paired-frontier/binding observer on current Native noTT mixed D4 q4. Core shadow enumeration changes clock overhead, not product returned provider, max2000frontiers/first4mismatches; no performance assertion.')
 (B/'mixed-postfix-frontier-result.json').write_text(json.dumps(out,indent=2)+'\n');print('frontier',out['checked_frontiers'],len(out['mismatches']),v.completed_depth,v.score,flush=True)
finally:R.attach_stats=oa;E['pm'].SearchStatistics=of;R._legal_actions_from_provider=og;R._push_impl=op;R.pop=oo
