"""Finite reward/work curves against fixed foes; partial depth is actual behavior."""
from pathlib import Path
from collections import Counter,defaultdict
import json,random,sys,time,statistics
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/search-budget-transfer-20261018';start=time.perf_counter();p=json.loads((D/'plan.json').read_bytes());done=json.loads((D/'result.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['slots'];actual={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};by={}
for slot,key in enumerate(slots):by[tuple(key)]=actual.get(slot,dict(slot=slot,rule=key[0],family=key[1],label=key[2],candidate_owner=key[3],foe=key[4],reward=None,record=None,ending='UNSTARTED_UNKNOWN'))
def bounds(obs):
 c=Counter();seen={}
 for terms in obs:
  for k,g in terms:c[g['slot']]+=k;seen[g['slot']]=g
 center=radius=0
 for slot,v in c.items():
  g=seen[slot]
  if g['reward']is None:radius+=abs(v)
  else:center+=v*g['reward']
 return[(center-radius)/len(obs),(center+radius)/len(obs)]
contrasts=[];tags=list(p['budgets']);first,last=tags[0],tags[-1]
for foe in p['foes']:
 specs=[(base+' '+last+'-'+first,[base+'@'+last],[base+'@'+first])for base in p['candidate_models']]
 for tag in tags:
  specs.append(('static-unit '+tag,['rule_static_v2@'+tag],['unit@'+tag]))
  learned=[m+'@'+tag for m in p['candidate_models']if m.startswith('mapped_TD')]
  if learned:
   specs.append(('mappedTD-static '+tag,learned,['rule_static_v2@'+tag]*len(learned)))
 for name,lefts,rights in specs:
  pairs=[];groups=defaultdict(list)
  for left,right in zip(lefts,rights):
   for gs in p['rules']:
    for f in p['families']:
     for owner in(0,1):
      obs=[(1,by[gs,f,left,owner,foe]),(-1,by[gs,f,right,owner,foe])];pairs.append(obs);groups[gs,f].append(obs)
  gb={k:bounds(v)for k,v in groups.items()};rng=random.Random(2026101806);boot=[]
  for _ in range(2000):
   vv=[gb[g,rng.choice(p['families'])]for g in p['rules']for _ in p['families']];boot.append([sum(z[j]for z in vv)/len(vv)for j in(0,1)])
  contrasts.append(dict(foe=foe,contrast=name,pairs=len(pairs),bounds=bounds(pairs),fixed_rule_family95_envelope=[sorted(z[0]for z in boot)[49],sorted(z[1]for z in boot)[1949]],by_role={str(o):bounds([z for z in pairs if z[0][1]['candidate_owner']==o])for o in(0,1)},by_rule={str(g):bounds([z for z in pairs if z[0][1]['rule']==g])for g in p['rules']},same_complete_records=sum(z[0][1]['record']is not None and z[0][1]['record']==z[1][1]['record']for z in pairs)))
work=defaultdict(lambda:dict(queries=0,nodes=0,caller_seconds=0.,kernel_seconds=0.,depths=Counter(),causes=Counter(),fallbacks=0,nodes_sample=[]))
for line in(D/'queries.jsonl').open(encoding='utf-8'):
 q=json.loads(line);gs,f,label,o,foe=slots[q['slot']];w=work[label+'/'+foe+('/candidate'if q['candidate_turn']else'/fixedfoe')];w['queries']+=1;w['nodes']+=q['nodes'];w['caller_seconds']+=q['caller_seconds'];w['kernel_seconds']+=q['kernel_seconds'];w['depths'][q['completed_depth']]+=1;w['causes'][q['cause']]+=1;w['fallbacks']+=q['used_fallback'];w['nodes_sample'].append(q['nodes'])
for w in work.values():w['median_query_nodes']=statistics.median(w.pop('nodes_sample'))
outcomes={label+'/'+foe:dict(Counter('U'if g['reward']is None else'W'if g['reward']==1 else'L'if g['reward']==-1 else'D'for k,g in by.items()if k[2]==label and k[4]==foe))for label in p['profiles']for foe in p['foes']}
q=dict(status='COMPLETE_FIXED_FOE_WORK_CURVE_ANALYSIS'if done['status']=='COMPLETE'else'PARTIAL_ALL_MISSING_UNKNOWN',contrasts=contrasts,work=dict(work),outcomes=outcomes,planned=p['planned_physical'],returned=len(actual),unknown=sum(g['reward']is None for g in actual.values()),missing=p['planned_physical']-len(actual),seconds=time.perf_counter()-start,scope='Candidateonlyconfiguredwork changes; fixedfoe unchangedD2/8192/TT0, actualcandidatepartialdepth usable. Rewardbounds[-1,1]forU/missing, repeatedbaselinecoefficients combined. Fixedrule-familydescriptive resampling, notpopulationconfidence/equalwork ordepthalonebenefit. Allactualquerycosts includesbothactors, wholeproducerhasadditionalsetup/recording. No training/default/Elo claim.')
write_json(D/'analysis.json',q)
for x in contrasts:print(x['foe'],x['contrast'],x['bounds'],x['fixed_rule_family95_envelope'])
print('COST_TOTALS',sum(w['nodes']for w in work.values()),sum(w['caller_seconds']for w in work.values()),flush=True)
