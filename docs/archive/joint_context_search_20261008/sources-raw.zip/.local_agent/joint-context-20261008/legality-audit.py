import sys,json,hashlib,time
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=root/'.local_agent/joint-context-20261008';source=p/'context-replies.json';data=json.loads(source.read_bytes())
base=ruleset_from_dict(json.loads((root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json').read_bytes())['definition'])
result={'declaration':'Postdeclared exact audit of ALL pseudo-eligible but illegal captures from the frozen192-root cohort. Reconstruct only affected roots/replies, inspect pre-S3 candidate bindings and their exact trial transitions. Private candidate/transition calls are diagnostic only, never deployment legality or applied game moves. No new sampling/fitting/default changes.','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False}
t=time.perf_counter()
for row in data['cases']:
 gaps=[x for x in row['outcomes'] if x['pseudo_eligible'] and not x['capture_legal']]
 if not gaps:continue
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
 board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[25]=Piece(0,row['actor'],row['actor']);board[28]=Piece(1,'R','R')
 for (owner,tid),sq in zip(((0,'R'),(0,'R'),(1,'C'),(1,'R')),row['other_cells']):board[sq]=Piece(owner,tid,tid)
 definition=replace(base,initial_position=tuple(tuple(board[y*8:(y+1)*8]) for y in range(8)))
 c=compile_ruleset_for_execution(definition);engine=SemanticEngine(c);position=replace(GameSession(c).state.position,side_to_move=1)
 replies=engine.legal_actions(position)
 for gap in gaps:
  action=next(a for a in replies if a.source==gap['reply_source'] and a.target==gap['reply_target'])
  child=engine.apply(position,action);candidates=[]
  for pattern in engine._patterns:
   for a,binding in engine._iter_candidates(pattern,child):
    if a.source!=25 or a.target!=gap['target']:continue
    trial=engine._transition(child,a,binding)
    candidates.append({'action':record_value(a),'invariants':[x.kind for x in pattern.invariants],'trial_checked':engine.in_check(trial,0),'s3_legal':engine._trial_child_if_s3_legal(pattern,child,a,binding) is not None})
  assert candidates and all(x['trial_checked'] and not x['s3_legal'] and x['invariants']==['own_anchor_safe'] for x in candidates)
  result['rows'].append({'seed':row['seed'],'actor':row['actor'],'reply_source':action.source,'reply_target':action.target,'child_checked':engine.in_check(child,0),'candidates':candidates})
result['complete']=True;result['seconds']=time.perf_counter()-t;write_record(p/'legality-audit.json',result)
print(json.dumps({'complete':True,'gaps':len(result['rows']),'already_checked':sum(x['child_checked'] for x in result['rows']),'seconds':result['seconds'],'first':result['rows'][:2]},indent=2))
