import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.transposition import TranspositionTable,TTEntry
from generic_chess.ai.alphabeta.ordering import MoveOrderer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/joint-context-20261008';out=p/'tt-mechanism.json';assert not out.exists()
source=root/'.local_agent/semantic-attacks-20261008/layout-cohort.json';cohort=json.loads(source.read_bytes())
class HintOnly(TranspositionTable):
 def probe(self,key):
  e=super().probe(key)
  return None if e is None else TTEntry(e.key,-1,e.score,e.bound,e.best_action,e.generation)
original_order=MoveOrderer.order
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Postdeclared mechanism study on exposed seeds1004/1007/1008, not new validation. Existing same fixed evaluator/table/Native attacks. Four modes noTT/fullTT/hints-only/bounds-only atdepth3/4 with4096nodes/2sec, repeated twice48fresh-player calls. Hints-only probe copies depth=-1, forbidding score/bound reuse; bounds-only order wrapper discards TT hint but leaves cached bound/best-action semantics. Local process patches restored, no production change. Validate legal PV and equal completed scores per root/depth, retain caps/variation; no optimal default selection or wallcost claim under instrumentation. Budget whole120sec checkpoint, interruptible per call.','rows':[]}
t=time.perf_counter();write_record(out,r)
try:
 for seed in (202610081004,202610081007,202610081008):
  item=next(x for x in cohort['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(item['definition']));s=GameSession(c)
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  for repeat in (0,1):
   for depth in (3,4):
    for mode in ('none','full','hints','bounds'):
     assert time.perf_counter()-t<120
     assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
     def no_hint(self,state,actions,evaluator,depth,tt_move,prev_action,tuning):
      return original_order(self,state,actions,evaluator,depth,None,prev_action,tuning)
     MoveOrderer.order=no_hint if mode=='bounds' else original_order
     player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=mode!='none',use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
     if mode=='hints':player._tt=HintOnly()
     d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d)
     r['rows'].append({'seed':seed,'repeat':repeat,'depth':depth,'mode':mode,'decision':record_value(d)})
    write_record(out,r)
  print(seed,[(x['repeat'],x['depth'],x['mode'],x['decision']['completed_depth'],x['decision']['nodes']) for x in r['rows'] if x['seed']==seed],flush=True)
 for seed in (202610081004,202610081007,202610081008):
  for depth in (3,4):
   scores={x['decision']['score'] for x in r['rows'] if x['seed']==seed and x['depth']==depth and x['decision']['completed_depth']==depth}
   assert len(scores)<=1,(seed,depth,scores)
 r['complete']=True
finally:
 MoveOrderer.order=original_order;r['seconds']=time.perf_counter()-t;write_record(out,r)
