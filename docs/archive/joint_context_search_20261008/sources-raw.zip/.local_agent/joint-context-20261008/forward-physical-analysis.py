import sys,json,statistics,hashlib,math
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=root/'.local_agent/joint-context-20261008';source=p/'forward-kernel-v3.json';r=json.loads(source.read_bytes());assert r['complete']
summary={};rows=[]
for a in ('C','R'):
 xs=[x for x in r['rows'] if x['actor']==a];ds=[]
 for x in xs:
  target=x['physical_uniform_reference'];prediction=x['physical_uniform_forward'];old=x['initial_legal']
  d=(prediction-target)**2-(old-target)**2;ds.append(d)
  rows.append({'seed':x['seed'],'actor':a,'reference':target,'forward':prediction,'initial':old,'mse_difference':d})
 summary[a]={'roots':len(xs),'forward_mean':statistics.mean(x['physical_uniform_forward'] for x in xs),'reference_mean':statistics.mean(x['physical_uniform_reference'] for x in xs),'initial_mean':statistics.mean(x['initial_legal'] for x in xs),'forward_mse':statistics.mean((x['physical_uniform_forward']-x['physical_uniform_reference'])**2 for x in xs),'initial_mse':statistics.mean((x['initial_legal']-x['physical_uniform_reference'])**2 for x in xs),'paired_mse_difference':statistics.mean(ds),'paired_mse_difference_se':statistics.stdev(ds)/math.sqrt(len(ds)),'worse_roots':sum(x>0 for x in ds),'better_roots':sum(x<0 for x in ds),'mean_physical_candidates':statistics.mean(x['physical_candidates'] for x in xs),'mean_physical_legal_replies':statistics.mean(x['physical_legal_replies'] for x in xs)}
record={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Postdeclared reanalysis of ALL192existing forward rows under MATCHED physical-successor law, no new transitions or parameter fitting. Compare S0/S1 uniform distinct successor prediction against S3 legal distinct successor reference; no-response baseline uses initial legal capture. Equal96root weights per actor; across-root SE descriptive, not independent deployment or universal material evidence. Law itself chosen explicitly, not implied by rules.','summary':summary,'rows':rows,'new_transitions':0}
write_record(p/'forward-physical-analysis.json',record);print(json.dumps(summary,indent=2))
