"""Fixed-count placement and one declared reply law; not a material-price fit."""
import sys,json,hashlib,time,random,math
from pathlib import Path
from dataclasses import replace
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'context-replies.json';assert not out.exists()
dependency=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json'
base=ruleset_from_dict(json.loads(dependency.read_bytes())['definition'])
source,target=25,28
universe=tuple(y*8+x for y in range(1,7) for x in range(1,7) if y*8+x not in (source,target))
assert len(universe)==34
def path_to(target):
 sx,sy=source%8,source//8;tx,ty=target%8,target//8
 if sx!=tx and sy!=ty:return None
 dx=(tx>sx)-(tx<sx);dy=(ty>sy)-(ty<sy)
 return tuple((sy+dy*i)*8+sx+dx*i for i in range(1,max(abs(tx-sx),abs(ty-sy))))
def prediction(actor,path):
 if path is None:return 0.,0.
 # Outside the pre-reply placement universe is initially empty; legality of
 # the chosen reply can condition this distribution, an explicit tested limit.
 m=sum(x in universe for x in path);k=1 if actor=='C' else 0
 independent=math.comb(m,k)*(4/34)**k*(30/34)**(m-k) if m>=k else 0.
 joint=math.comb(m,k)*math.comb(34-m,4-k)/math.comb(34,4) if m>=k and 34-m>=4-k else 0.
 return independent,joint
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'dependency_sha256':hashlib.sha256(dependency.read_bytes()).hexdigest(),
 'declaration':'Before outcomes:96fresh seeds202610082000..2095. Fix source25/target28 and corner anchors; four identity slots (0R,0R,1C,1R) uniformly without replacement among34inner cells. Paired sourceC/R variants share slots. Existing compile-safety acceptance only; immediate wins not filtered. Opponent moves first, uniformly over all legal replies WITHIN each accepted root. Track target identity via its reply source, retain actor losses. Every child actual Core source-capture check; compare fixed pre-law and actual geometry/survival conditioned pre-law, not deployment prediction. Record pseudo screen eligibility separately from legal capture/anchor effects. No price fitting/human data/extra search. Limits:256reply transitions/root,20000total,240sec checkpoint; check stops, save every4seeds; partials remain unknown. No comparison extension by outcome.',
 'cases':[],'reply_transitions':0}
start=time.perf_counter();write_record(out,r)
try:
 for seed in range(202610082000,202610082096):
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  cells=random.Random(seed).sample(universe,4)
  for actor in ('C','R'):
   assert time.perf_counter()-start<240,'development cost checkpoint'
   board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K')
   board[source]=Piece(0,actor,actor);board[target]=Piece(1,'R','R')
   for (owner,tid),square in zip(((0,'R'),(0,'R'),(1,'C'),(1,'R')),cells):board[square]=Piece(owner,tid,tid)
   definition=replace(base,initial_position=tuple(tuple(board[y*8:(y+1)*8]) for y in range(8)))
   item={'seed':seed,'actor':actor,'other_cells':cells,'outcomes':[]};r['cases'].append(item)
   try:
    c=compile_ruleset_for_execution(definition);session=GameSession(c)
   except ValueError as exc:
    item.update(accepted=False,rejection=str(exc));continue
   item['accepted']=True;engine=SemanticEngine(c)
   position=replace(session.state.position,side_to_move=1)
   initial=replace(position,side_to_move=0)
   item['initial_capture_legal']=any(a.source==source and a.target==target for a in engine.legal_actions(initial))
   item['initial_screen_count']=sum(board[x] is not None for x in path_to(target))
   replies=engine.legal_actions(position);item['reply_count']=len(replies)
   if not replies:item['no_reply']=True;continue
   for action in replies:
    assert len(item['outcomes'])<256 and r['reply_transitions']<20000,'transition checkpoint'
    assert time.perf_counter()-start<240,'development cost checkpoint'
    child=engine.apply(position,action);r['reply_transitions']+=1
    next_target=action.target if action.source==target else target
    assert child.board[next_target] is not None and child.board[next_target].owner==1 and child.board[next_target].current_type_id=='R'
    alive=child.board[source] is not None and child.board[source].owner==0
    capture=alive and any(a.source==source and a.target==next_target for a in engine.legal_actions(child))
    path=path_to(next_target) if alive else None
    count=None if path is None else sum(child.board[x] is not None for x in path)
    pseudo=count==(1 if actor=='C' else 0) if count is not None else False
    assert not capture or pseudo
    independent,joint=prediction(actor,path)
    category='target' if action.source==target else 'anchor' if position.board[action.source].current_type_id=='K' else 'other'
    item['outcomes'].append({'reply_source':action.source,'reply_target':action.target,
     'reply_category':category,'target':next_target,'source_alive':alive,
     'path':path,'screen_count':count,'capture_legal':bool(capture),'pseudo_eligible':pseudo,
     'conditioned_independent':independent,'conditioned_fixed_count':joint})
  if (seed-202610082000+1)%4==0:
   write_record(out,r);print(seed,'cases',len(r['cases']),'replies',r['reply_transitions'],'seconds',round(time.perf_counter()-start,2),flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
