import sys,json,time,hashlib,random,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=root/'.local_agent/joint-context-20261008';out=p/'forward-fresh-context.json';assert not out.exists();dependency=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json';base=ruleset_from_dict(json.loads(dependency.read_bytes())['definition'])
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'dependency_sha256':hashlib.sha256(dependency.read_bytes()).hexdigest(),'declaration':'Before outcomes:32fresh seeds202610085000..5031, BOTHC/Rhero variants. Source/target plus four identity slots uniformly without replacement over inner6x6, anchors0/63; no fixed alignment. Same compile safety, rejected roots retained without replacement, no downstream outcome selection. Uniform DISTINCT physical S0/S1 successor predictor versus uniform DISTINCT legal physical successor reference (same declared sampling unit). Source-capture pseudo uses exact supported orthogonal count geometry; reference uses actual Core legal source actions. Predictor computed first, no actual reply outcomes input. Initial-capture no-response baseline. Static material/defaults unchanged, no human fit. Max10000explicitcandidate+legal frontier transitions/120sec checkpoint, stops each root; record partial unknown if exhausted. Tests forward approximation beyond fixed source/target layout, not WDL/general-history equivalence or universal prices.','rows':[],'explicit_transitions':0}
t=time.perf_counter();write_record(out,r)
def pseudo(child,source,target,actor):
 if child.board[source] is None or child.board[source].owner!=0:return False
 sx,sy=source%8,source//8;tx,ty=target%8,target//8
 if sx!=tx and sy!=ty:return False
 dx=(tx>sx)-(tx<sx);dy=(ty>sy)-(ty<sy)
 return sum(child.board[(sy+dy*i)*8+sx+dx*i] is not None for i in range(1,max(abs(tx-sx),abs(ty-sy))))==(1 if actor=='C' else 0)
try:
 for seed in range(202610085000,202610085032):
  cells=random.Random(seed).sample([y*8+x for y in range(1,7) for x in range(1,7)],6);source,target=cells[:2]
  for actor in ('C','R'):
   assert time.perf_counter()-t<120
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[source]=Piece(0,actor,actor);board[target]=Piece(1,'R','R')
   for (owner,tid),sq in zip(((0,'R'),(0,'R'),(1,'C'),(1,'R')),cells[2:]):board[sq]=Piece(owner,tid,tid)
   definition=replace(base,initial_position=tuple(tuple(board[y*8:(y+1)*8]) for y in range(8)));item={'seed':seed,'actor':actor,'cells':cells};r['rows'].append(item)
   try:c=compile_ruleset_for_execution(definition);engine=SemanticEngine(c);position=replace(GameSession(c).state.position,side_to_move=1)
   except ValueError as exc:item.update(accepted=False,rejection=str(exc));continue
   item['accepted']=True;pred={};pred_rows=[];started=time.perf_counter()
   for pattern in engine._patterns:
    for a,b in engine._iter_candidates(pattern,position):
     assert r['explicit_transitions']<10000;child=engine._transition(position,a,b);r['explicit_transitions']+=1;next_target=a.target if a.source==target else target;value=pseudo(child,source,next_target,actor)
     if child in pred:assert pred[child]==value
     pred[child]=value;pred_rows.append({'reply_source':a.source,'reply_target':a.target,'pseudo_capture':value})
   item['prediction_seconds']=time.perf_counter()-started;item['prediction']=statistics.mean(pred.values());item['candidate_bindings']=len(pred_rows);item['physical_candidates']=len(pred);item['candidate_rows']=pred_rows
   reference={};legal_rows=[];started=time.perf_counter()
   for a,b in engine.iter_legal_action_bindings(position):
    assert r['explicit_transitions']<10000;child=engine._transition(position,a,b);r['explicit_transitions']+=1;next_target=a.target if a.source==target else target
    value=child.board[source] is not None and child.board[source].owner==0 and any(z.source==source and z.target==next_target for z in engine.legal_actions(child))
    if child in reference:assert reference[child]==value
    reference[child]=bool(value);legal_rows.append({'reply_source':a.source,'reply_target':a.target,'capture_legal':bool(value)})
   item['reference_seconds']=time.perf_counter()-started;item['reference']=statistics.mean(reference.values());item['legal_bindings']=len(legal_rows);item['physical_legal_replies']=len(reference);item['legal_rows']=legal_rows
   item['initial_capture']=float(any(a.source==source and a.target==target for a in engine.legal_actions(replace(position,side_to_move=0))))
  write_record(out,r)
 r['summary']={actor:{'roots':32,'mean_prediction':statistics.mean(x['prediction'] for x in r['rows'] if x['actor']==actor),'mean_reference':statistics.mean(x['reference'] for x in r['rows'] if x['actor']==actor),'initial_mean':statistics.mean(x['initial_capture'] for x in r['rows'] if x['actor']==actor),'prediction_mse':statistics.mean((x['prediction']-x['reference'])**2 for x in r['rows'] if x['actor']==actor),'initial_mse':statistics.mean((x['initial_capture']-x['reference'])**2 for x in r['rows'] if x['actor']==actor),'worse_roots':sum((x['prediction']-x['reference'])**2>(x['initial_capture']-x['reference'])**2 for x in r['rows'] if x['actor']==actor),'positive_reference_roots':sum(x['reference']>0 for x in r['rows'] if x['actor']==actor)} for actor in ('C','R')}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
print(json.dumps({'complete':r['complete'],'seconds':r['seconds'],'summary':r.get('summary'),'transitions':r['explicit_transitions']},indent=2))
