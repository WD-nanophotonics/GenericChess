import sys,json,hashlib,statistics,ast
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=root/'.local_agent/joint-context-20261008';source=p/'context-replies.json';r=json.loads(source.read_bytes());assert r['complete']
def actor_mean(xs,key,source_key):
 groups={}
 for x in xs:groups.setdefault(source_key(x),[]).append(float(x[key]))
 return statistics.mean(statistics.mean(v) for v in groups.values())
rows=[]
for c in r['cases']:
 xs=c['outcomes'];assert c['accepted'] and xs
 row={'seed':c['seed'],'actor':c['actor'],'reply_actors':len({x['reply_source'] for x in xs})}
 for key in ('capture_legal','pseudo_eligible','source_alive'):
  row[key+'_action_uniform']=statistics.mean(float(x[key]) for x in xs)
  row[key+'_actor_uniform']=actor_mean(xs,key,lambda x:x['reply_source'])
 row['target_move_action_uniform']=statistics.mean(x['reply_category']=='target' for x in xs)
 row['target_move_actor_uniform']=1/row['reply_actors'] if any(x['reply_category']=='target' for x in xs) else 0
 rows.append(row)
summary={a:{k:statistics.mean(x[k] for x in rows if x['actor']==a) for k in rows[0] if k not in ('seed','actor')} for a in ('C','R')}
screen_source=root/'.local_agent/semantic-attacks-20261008/screen-reply.json';screen=json.loads(screen_source.read_bytes());screen_rows=[]
# Source attribution comes from parsing the known producer's SemanticAction repr
# as AST literal arguments, never eval or substring-based identity guessing.
def reply_source(x):
 node=ast.parse(x['reply'],mode='eval').body
 assert isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='SemanticAction'
 return ast.literal_eval(next(k.value for k in node.keywords if k.arg=='source'))
for c in screen['rows']:
 xs=c['outcomes'];screen_rows.append({'actor':c['actor'],'screens':c['screens'],'action_uniform':statistics.mean(x['source_capture_available'] for x in xs),'actor_uniform':actor_mean(xs,'source_capture_available',reply_source)})
laws={'correlated':[(0,0),(1,1)],'anti_correlated':[(0,1),(1,0)],'independent':[(0,0),(0,1),(1,0),(1,1)]}
screen_summary={law:{a:{k:statistics.mean(x[k] for x in screen_rows if x['actor']==a and tuple(x['screens']) in masks) for k in ('action_uniform','actor_uniform')} for a in ('C','R')} for law,masks in laws.items()}
record={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'screen_source_sha256':hashlib.sha256(screen_source.read_bytes()).hexdigest(),'declaration':'Postdeclared unfitted alternative behavior law on ALL existing replies: choose uniformly among actors with legal actions, then uniformly among that actor legal actions. No choice based on downstream capture outcomes, no new transitions, no exclusion of bad contexts. Equal initial-root or screen-cell weighting retained. Both laws are constructions, not uniquely rule-implied policies or cheap static inference. AST reads only validated SemanticAction keyword literals from own earlier producer, never eval.','summary':summary,'screen_summary':screen_summary,'rows':rows,'screen_rows':screen_rows,'additional_reply_transitions':0}
write_record(p/'response-law.json',record);print(json.dumps({'summary':summary,'screen_summary':screen_summary},indent=2))
