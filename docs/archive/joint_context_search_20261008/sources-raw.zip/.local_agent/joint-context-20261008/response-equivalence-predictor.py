import sys,json,time,hashlib,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import write_record
p=root/'.local_agent/joint-context-20261008';out=p/'response-equivalence-predictor.json';assert not out.exists()
source=p/'context-replies.json';data=json.loads(source.read_bytes());base=ruleset_from_dict(json.loads((root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json').read_bytes())['definition']);quiet=next(x for x in base.semantic_actions if x.name=='cannon_quiet')
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Advisor-motivated exposed24root control: independently construct S0/S1 physical predictor before legal reference, identical law each side, no actual reply filtering/weighting. No new population or fit. Before outcomes: first12fixed seeds2000..2011 BOTHsourceC/R from already exposed96root batch, no selection on response differences. Compare original versus one extra high-level cannon_quiet action copied with fresh name, same guards/effects/invariants. Compile both normally. Exhaustively compare sets of physical one-reply successors (board,hands,side,aux,shape), and source-capture legality for each matched successor; uniform binding versus uniform distinct physical successors. Aux-empty fixture/repetition draw only, no claim physical identity suffices for arbitrary history/declaration/trigger semantics. Static generator raw profile invariance also checked. Limits120sec/10000explicitreply transitions, stop per root. No price fit/product change or coordinate-based dedup.', 'rows':[],'explicit_reply_transitions':0}
t=time.perf_counter();write_record(out,r)
def key(child):return child.board,child.hands,child.side_to_move,child.aux_state,child.board_width,child.board_height
try:
 for row in data['cases'][:24]:
  assert time.perf_counter()-t<120
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[25]=Piece(0,row['actor'],row['actor']);board[28]=Piece(1,'R','R')
  for (owner,tid),sq in zip(((0,'R'),(0,'R'),(1,'C'),(1,'R')),row['other_cells']):board[sq]=Piece(owner,tid,tid)
  original=replace(base,initial_position=tuple(tuple(board[y*8:(y+1)*8]) for y in range(8)))
  variants=(original,replace(original,semantic_actions=original.semantic_actions+(replace(quiet,name='cannon_quiet_equivalent_copy'),)))
  effects=[];summaries=[];profiles=[];predictions=[]
  for definition in variants:
   c=compile_ruleset_for_execution(definition);engine=SemanticEngine(c);position=replace(GameSession(c).state.position,side_to_move=1);cfg=EvaluationConfig();profile,scope=build_semantic_opportunity_profile(c,cfg)
   profiles.append({k:{x:scope['types'][k][x] for x in ('raw','quiet_endpoints','capture_endpoints','curves')} for k in ('C','R')})
   predicted={}
   for pattern in engine._patterns:
    for action,binding in engine._iter_candidates(pattern,position):
     child=engine._transition(position,action,binding);r['explicit_reply_transitions']+=1
     target=action.target if action.source==28 else 28
     available=any(a.source==25 and a.target==target for pat in engine._patterns for a,b in engine._iter_candidates(pat,child))
     state_key=key(child)
     if state_key in predicted:assert predicted[state_key]==bool(available)
     predicted[state_key]=bool(available)
   predictions.append(predicted)
   groups={};values=[]
   for action,binding in engine.iter_legal_action_bindings(position):
    assert r['explicit_reply_transitions']<10000
    child=engine._transition(position,action,binding);r['explicit_reply_transitions']+=1;target=action.target if action.source==28 else 28
    available=child.board[25] is not None and child.board[25].owner==0 and any(a.source==25 and a.target==target for a in engine.legal_actions(child))
    state_key=key(child);groups.setdefault(state_key,[]).append(bool(available));values.append(bool(available))
   assert all(len(set(v))==1 for v in groups.values())
   effects.append({k:v[0] for k,v in groups.items()});summaries.append({'bindings':len(values),'physical_successors':len(groups),'binding_uniform_capture':statistics.mean(values),'physical_uniform_capture':statistics.mean(v[0] for v in groups.values())})
  assert effects[0]==effects[1];assert profiles[0]==profiles[1];assert predictions[0]==predictions[1]
  r['rows'].append({'seed':row['seed'],'actor':row['actor'],'original':summaries[0],'duplicated':summaries[1],'forward_original':statistics.mean(predictions[0].values()),'forward_duplicated':statistics.mean(predictions[1].values()),'successor_sets_and_captures_equal':True,'static_profiles_equal':True})
  if len(r['rows'])%4==0:write_record(out,r)
 r['summary']={actor:{'roots':12,'physical_forward_mse':statistics.mean((x['forward_original']-x['original']['physical_uniform_capture'])**2 for x in r['rows'] if x['actor']==actor),'binding_mean_original':statistics.mean(x['original']['binding_uniform_capture'] for x in r['rows'] if x['actor']==actor),'binding_mean_duplicated':statistics.mean(x['duplicated']['binding_uniform_capture'] for x in r['rows'] if x['actor']==actor),'physical_mean':statistics.mean(x['original']['physical_uniform_capture'] for x in r['rows'] if x['actor']==actor),'binding_changed_roots':sum(x['original']['binding_uniform_capture']!=x['duplicated']['binding_uniform_capture'] for x in r['rows'] if x['actor']==actor)} for actor in ('C','R')}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
print(json.dumps({'complete':r['complete'],'seconds':r['seconds'],'summary':r.get('summary'),'transitions':r['explicit_reply_transitions']},indent=2))
