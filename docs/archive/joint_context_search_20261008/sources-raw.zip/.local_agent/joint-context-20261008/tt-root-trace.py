import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.transposition import TranspositionTable,TTEntry
from generic_chess.ai.alphabeta.ordering import MoveOrderer
from generic_chess.ai.alphabeta import search
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/joint-context-20261008';out=p/'tt-root-trace.json';assert not out.exists()
source=root/'.local_agent/semantic-attacks-20261008/layout-cohort.json';cohort=json.loads(source.read_bytes())
class HintOnly(TranspositionTable):
 def probe(self,key):
  e=super().probe(key)
  return None if e is None else TTEntry(e.key,-1,e.score,e.bound,e.best_action,e.generation)
original_order=MoveOrderer.order;original_search=search.negamax
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'New exposed-root trace, not extension/replacement of frozen cap outcomes. Before running: same1004/1007/1008, ALLfour modes, depth4,8192nodes/4sec each, no q/root scan, whole120sec checkpoint. Equal incremental budget tests whether TT hints cause previous cap rather than score inconsistency. Trace root ordering and windowed child returns/cost at each iteration; child returns are fail-soft bounds, NOT exact per-move minimax scores. Local monkeypatch restored. No production changes, no superiority/default claim or wallcost comparison under tracing.','rows':[]}
t=time.perf_counter();write_record(out,r)
try:
 for seed in (202610081004,202610081007,202610081008):
  item=next(x for x in cohort['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(item['definition']));s=GameSession(c)
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  for mode in ('none','full','hints','bounds'):
   assert time.perf_counter()-t<120
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   trace=[];stack=[]
   def traced(state,depth,alpha,beta,ply,ctx,*args,**kwargs):
    before=ctx.stats.nodes;stack.append(ply);entry=None
    if ply==0:
     entry={'depth':depth,'start_nodes':before,'children':[]};trace.append(entry)
    try:
     result=original_search(state,depth,alpha,beta,ply,ctx,*args,**kwargs)
     if ply==1:trace[-1]['children'].append({'action':record_value(kwargs.get('prev_action')),'alpha':alpha,'beta':beta,'score':-result.score,'nodes':ctx.stats.nodes-before})
     if ply==0:entry.update(end_nodes=ctx.stats.nodes,score=result.score,best_action=record_value(result.best_action))
     return result
    except Exception as exc:
     if ply==0:entry.update(end_nodes=ctx.stats.nodes,interrupted=type(exc).__name__)
     raise
    finally:stack.pop()
   def ordered(self,state,actions,evaluator,depth,tt_move,prev_action,tuning):
    ordered=original_order(self,state,actions,evaluator,depth,None if mode=='bounds' else tt_move,prev_action,tuning)
    if stack and stack[-1]==0:trace[-1].update(tt_hint=record_value(tt_move),ordered=[record_value(x) for x in ordered])
    return ordered
   search.negamax=traced;MoveOrderer.order=ordered
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=mode!='none',use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
   if mode=='hints':player._tt=HintOnly()
   d=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d)
   r['rows'].append({'seed':seed,'mode':mode,'trace':trace,'decision':record_value(d)});write_record(out,r)
   print(seed,mode,d.completed_depth,d.nodes,[(x['depth'],x.get('end_nodes',0)-x['start_nodes'],x.get('score'),x.get('interrupted')) for x in trace],flush=True)
 for seed in (202610081004,202610081007,202610081008):
  scores={x['decision']['score'] for x in r['rows'] if x['seed']==seed and x['decision']['completed_depth']==4};assert len(scores)<=1,(seed,scores)
 r['complete']=True
finally:
 MoveOrderer.order=original_order;search.negamax=original_search;r['seconds']=time.perf_counter()-t;write_record(out,r)
