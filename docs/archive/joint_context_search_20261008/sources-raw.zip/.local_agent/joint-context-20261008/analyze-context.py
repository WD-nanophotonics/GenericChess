"""Root-weighted paired forecast errors; no fitted parameters."""
import sys,json,hashlib,statistics,math
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=Path(__file__).parent;source=p/'context-replies.json';r=json.loads(source.read_bytes())
assert r['complete']
def summary(rows):
 if not rows:return None
 return {'roots':len(rows),**{k:statistics.mean(row[k] for row in rows) for k in rows[0] if k!='seed'},
 'paired_mse_difference_se':statistics.stdev(x['joint_minus_independent_mse'] for x in rows)/math.sqrt(len(rows)) if len(rows)>1 else None}
tables={};root_rows={};strata={}
for actor in ('C','R'):
 rows=[];by_category={name:[] for name in ('target','anchor','other')}
 for c in r['cases']:
  if not c['accepted'] or c['actor']!=actor or not c['outcomes']:continue
  outcomes=c['outcomes'];n=len(outcomes)
  row={'seed':c['seed'],'initial_legal':float(c['initial_capture_legal']),
   'legal':statistics.mean(x['capture_legal'] for x in outcomes),
   'pseudo':statistics.mean(x['pseudo_eligible'] for x in outcomes),
   'source_lost':statistics.mean(not x['source_alive'] for x in outcomes),
   'target_moved':statistics.mean(x['reply_category']=='target' for x in outcomes)}
  for model,key in (('independent','conditioned_independent'),('joint','conditioned_fixed_count')):
   row[model]=statistics.mean(x[key] for x in outcomes)
   row[model+'_mse']=statistics.mean((x[key]-x['pseudo_eligible'])**2 for x in outcomes)
   row[model+'_legal_mse']=statistics.mean((x[key]-x['capture_legal'])**2 for x in outcomes)
  row['joint_minus_independent_mse']=row['joint_mse']-row['independent_mse']
  row['joint_minus_independent_legal_mse']=row['joint_legal_mse']-row['independent_legal_mse']
  rows.append(row)
  for name in by_category:
   xs=[x for x in outcomes if x['reply_category']==name]
   if xs:by_category[name].append({'seed':c['seed'],'weight':len(xs)/n,
    'legal':sum(x['capture_legal'] for x in xs)/n,
    'pseudo':sum(x['pseudo_eligible'] for x in xs)/n,
    'independent':sum(x['conditioned_independent'] for x in xs)/n,
    'joint':sum(x['conditioned_fixed_count'] for x in xs)/n})
 tables[actor]=summary(rows);root_rows[actor]=rows
 # Contributions retain equal root weights, including roots with no category.
 strata[actor]={name:{key:sum(x[key] for x in xs)/len(rows)
  for key in ('weight','legal','pseudo','independent','joint')} for name,xs in by_category.items()}
record={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'declaration':'All96fresh paired roots, equal initial-root weights; legal replies uniform inside each root. Scores are comparison of two predeclared unfitted formulas, not a fitted evaluator. MSE paired differences and across-root standard error are descriptive development uncertainty, not proof/independent deployment. Geometry/survival conditional predictions already use actual response outcomes and are diagnostic, not cheap forward inference.',
 'tables':tables,'strata':strata,'root_rows':root_rows}
write_record(p/'context-analysis.json',record)
print(json.dumps({'tables':tables,'strata':strata},indent=2))
