import sys,json,time,hashlib,random
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.ordering import MoveOrderer
from generic_chess.ai.alphabeta import search
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/joint-context-20261008';out=p/'tt-fresh-cohort.json';assert not out.exists()
source=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json';base=ruleset_from_dict(json.loads(source.read_bytes())['definition'])
original_order=MoveOrderer.order;original_search=search.negamax
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Before new outcomes:12fresh seeds202610084000..4011; original2C4R identity slots uniformly without replacement inner6x6, anchors0/63. Existing compile safety only, failures retained without replacement; terminal/immediate wins retained/labeled, no output selection. Paired fullTT versus root-only hint with bound reuse retained, depth4/8192nodes/4sec/q0/root-scanoff, same fixed evaluator/table and Native attacks. Cold players, alternate mode order across seeds. Whole120sec checkpoint, stop checks per call, persist each root. Decision: test whether3exposed-root ordering location benefit replicates, NOT choose a global default from three favorable roots. LegalPV/equal completed scores required; capped depths unknown. Local process wrappers restored, no product flag/default change.','cases':[]}
t=time.perf_counter();write_record(out,r)
try:
 for seed in range(202610084000,202610084012):
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  cells=random.Random(seed).sample([(x,y) for x in range(1,7) for y in range(1,7)],6);board=[[None]*8 for _ in range(8)];board[0][0]=Piece(0,'K','K');board[7][7]=Piece(1,'K','K')
  for (owner,tid),(x,y) in zip(((0,'C'),(0,'R'),(0,'R'),(1,'R'),(1,'C'),(1,'R')),cells):board[y][x]=Piece(owner,tid,tid)
  definition=replace(base,initial_position=tuple(tuple(x) for x in board));row={'seed':seed,'definition':ruleset_to_dict(definition),'searches':[]};r['cases'].append(row)
  try:c=compile_ruleset_for_execution(definition);s=GameSession(c)
  except ValueError as exc:row.update(accepted=False,rejection=str(exc));write_record(out,r);continue
  row['accepted']=True;row['initial_terminal']=record_value(s.state.terminal_status)
  row['immediate_wins']=[record_value(a) for a in s.legal_actions() if (lambda z:z.is_terminal and z.winner==0)(apply_action(s.state,a,c).terminal_status)]
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  for mode in (('full','root_only') if seed%2==0 else ('root_only','full')):
   assert time.perf_counter()-t<120
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   stack=[]
   def traced(state,depth,alpha,beta,ply,ctx,*args,**kwargs):
    stack.append(ply)
    try:return original_search(state,depth,alpha,beta,ply,ctx,*args,**kwargs)
    finally:stack.pop()
   def ordered(self,state,actions,evaluator,depth,tt_move,prev_action,tuning):
    assert stack
    return original_order(self,state,actions,evaluator,depth,tt_move if mode=='full' or stack[-1]==0 else None,prev_action,tuning)
   search.negamax=traced;MoveOrderer.order=ordered
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
   d=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d)
   row['searches'].append({'mode':mode,'decision':record_value(d)})
  complete=[x['decision']['score'] for x in row['searches'] if x['decision']['completed_depth']==4];assert len(set(complete))<=1
  write_record(out,r);print(seed,[(x['mode'],x['decision']['completed_depth'],x['decision']['nodes']) for x in row['searches']],flush=True)
 r['complete']=True
finally:
 MoveOrderer.order=original_order;search.negamax=original_search;r['seconds']=time.perf_counter()-t;write_record(out,r)
