import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.ordering import MoveOrderer
from generic_chess.ai.alphabeta import search
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=root/'.local_agent/joint-context-20261008';out=p/'tt-hint-location.json';assert not out.exists()
source=root/'.local_agent/semantic-attacks-20261008/layout-cohort.json';cohort=json.loads(source.read_bytes())
original_order=MoveOrderer.order;original_search=search.negamax
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Postdeclared exposed-root location intervention, same3roots ALLfour modes full/root-only/internal-only/no-hints with score reuse kept for every mode. Depth4/8192nodes/4sec/q0/root-scanoff;120sec total checkpoint. Local stack tracks exact negamax ply, wrapper passes None only at excluded ply to existing orderer, restored in finally. This isolates location within each dynamically changed traversal/history, not additive causal contributions or new default validation. Equal completed scores/legal PV required, retain caps.','rows':[]}
t=time.perf_counter();write_record(out,r)
try:
 for seed in (202610081004,202610081007,202610081008):
  item=next(x for x in cohort['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(item['definition']));s=GameSession(c)
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  for mode in ('full','root_only','internal_only','no_hints'):
   assert time.perf_counter()-t<120
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   stack=[];counts={'root_used':0,'root_dropped':0,'internal_used':0,'internal_dropped':0}
   def traced(state,depth,alpha,beta,ply,ctx,*args,**kwargs):
    stack.append(ply)
    try:return original_search(state,depth,alpha,beta,ply,ctx,*args,**kwargs)
    finally:stack.pop()
   def ordered(self,state,actions,evaluator,depth,tt_move,prev_action,tuning):
    assert stack
    at_root=stack[-1]==0;use=mode=='full' or mode=='root_only' and at_root or mode=='internal_only' and not at_root
    if tt_move is not None:counts[('root_' if at_root else 'internal_')+('used' if use else 'dropped')]+=1
    return original_order(self,state,actions,evaluator,depth,tt_move if use else None,prev_action,tuning)
   search.negamax=traced;MoveOrderer.order=ordered
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
   d=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d)
   r['rows'].append({'seed':seed,'mode':mode,'counts':counts,'decision':record_value(d)});write_record(out,r)
   print(seed,mode,d.completed_depth,d.nodes,counts,flush=True)
 for seed in (202610081004,202610081007,202610081008):
  scores={x['decision']['score'] for x in r['rows'] if x['seed']==seed and x['decision']['completed_depth']==4};assert len(scores)<=1,(seed,scores)
 r['complete']=True
finally:
 MoveOrderer.order=original_order;search.negamax=original_search;r['seconds']=time.perf_counter()-t;write_record(out,r)
