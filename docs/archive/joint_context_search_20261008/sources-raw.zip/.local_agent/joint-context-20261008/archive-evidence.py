import sys,json,hashlib,zipfile,tempfile,statistics
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=root/'.local_agent/joint-context-20261008';dest=root/'docs/archive/joint_context_search_20261008';dest.mkdir(exist_ok=True)
# Explicit synthetic-only closure. No workflow/Slack/user files or binaries.
names=('context-replies','analyze-context','legality-audit','tt-mechanism','tt-root-trace','tt-hint-location','tt-fresh-cohort','response-law','forward-kernel','forward-kernel-v2','forward-kernel-v3','response-equivalence','equivalent-search-cost','forward-physical-analysis','forward-fresh-context','generic-forward-mechanics','response-equivalence-predictor')
files=[];pins=[]
for name in names:
 producer=p/(name+'.py');output=p/(('context-analysis' if name=='analyze-context' else name)+'.json')
 if not output.exists():continue
 data=json.loads(output.read_bytes());assert data['producer_sha256']==hashlib.sha256(producer.read_bytes()).hexdigest()
 files.extend((producer,output));pins.append({'producer':producer.relative_to(root).as_posix(),'output':output.relative_to(root).as_posix(),'verified':True})
for rel in ('.local_agent/semantic-candidate-20261008/cannon-mixture.json','.local_agent/semantic-attacks-20261008/layout-cohort.json','.local_agent/semantic-attacks-20261008/screen-reply.json'):files.append(root/rel)
files.append(Path(__file__).resolve());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
package=dest/'sources-raw.zip';members=[]
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  assert f.resolve().is_relative_to(root.resolve());rel=f.relative_to(root).as_posix();z.write(f,rel);members.append({'original_path':rel,'bytes':f.stat().st_size,'sha256':sha(f)})
with tempfile.TemporaryDirectory(prefix='joint-context-verify-',dir=root/'.local_agent') as td:
 assert Path(td).resolve().is_relative_to((root/'.local_agent').resolve())
 with zipfile.ZipFile(package) as z:
  for info in z.infolist():assert not Path(info.filename).is_absolute() and '..' not in Path(info.filename).parts
  z.extractall(td)
 for m in members:assert sha(Path(td)/m['original_path'])==m['sha256']
index={'base_sha':'310d7ccee91b8bf2bfa5be4ad65acdda43b3b822','package':package.name,'package_sha256':sha(package),'members':members,'extracted_verified_members':len(members),'producer_pins':pins,'producer_pins_verified':len(pins),'scope':'Only Agent-generated synthetic roots/outcomes/producers and three explicit prior synthetic dependencies. Excludes workflow/memo/session/Slack/accounts/user inputs/binaries. Restore original relative paths only in isolated base checkout, rebuild Native from base. Do not overlay live checkout.','corrections':{'forward-kernel.json':'Original failed on unjustified unique-coordinate assertion; complete=false with empty rows retained.','forward-kernel-v2.json':'Anchor loss metric erroneously counted movement away from corner; superseded by v3 owner/type scan. Other metrics retained.','forward-kernel-v3.json':'Corrected anchor loss zero in all192roots. Transition counts are explicit candidate transitions, not total compiler/internal legality trials.','response_uniformity':'Old binding-uniform results unchanged; not physical-successor-invariant. Distinct-position quotient demonstrated only for aux-empty fixture without action-dependent history adjudication.'}}
write_record(dest/'index.json',index)
a=json.loads((p/'context-analysis.json').read_bytes());b=json.loads((p/'tt-mechanism.json').read_bytes());c=json.loads((p/'tt-root-trace.json').read_bytes());d=json.loads((p/'tt-hint-location.json').read_bytes());e=json.loads((p/'tt-fresh-cohort.json').read_bytes());f=json.loads((p/'response-law.json').read_bytes());g=json.loads((p/'forward-kernel-v3.json').read_bytes());h=json.loads((p/'response-equivalence.json').read_bytes())
pairs=[]
for x in e['cases']:
 ds={y['mode']:y['decision'] for y in x['searches']};pairs.append({'seed':x['seed'],'full_nodes':ds['full']['nodes'],'root_only_nodes':ds['root_only']['nodes'],'ratio':ds['root_only']['nodes']/ds['full']['nodes']})
compact={'archive_index':'../../archive/joint_context_search_20261008/index.json','scope':'Development observations under declared context/response/evaluation laws, no material-quality/WDL or universal search-default claim. Original caps and failures intact.','context_tables':a['tables'],'reply_strata':a['strata'],'legality_gap_audit':{'count':len(json.loads((p/'legality-audit.json').read_bytes())['rows']),'all_own_anchor_safe_failure':True},'response_law':{'summary':f['summary'],'screen_summary':f['screen_summary']},'forward_kernel':{'summary':g['summary'],'seconds':g['seconds'],'explicit_candidate_transitions':sum(x['candidates'] for x in g['rows'])},'response_equivalence':{'summary':h['summary'],'physical_successor_and_capture_sets_equal':True,'static_profiles_equal':True,'explicit_reply_transitions':h['explicit_reply_transitions']},'tt_mechanism_rows':[{k:x[k] for k in ('seed','repeat','depth','mode')}|{'nodes':x['decision']['nodes'],'completed_depth':x['decision']['completed_depth'],'score':x['decision']['score']} for x in b['rows']],'tt_trace_summary':[{'seed':x['seed'],'mode':x['mode'],'nodes':x['decision']['nodes'],'completed_depth':x['decision']['completed_depth'],'score':x['decision']['score']} for x in c['rows']],'tt_hint_location':[{'seed':x['seed'],'mode':x['mode'],'counts':x['counts'],'nodes':x['decision']['nodes'],'score':x['decision']['score']} for x in d['rows']],'fresh_hint_pairs':pairs,'fresh_hint_summary':{'all24_complete':all(y['decision']['completed_depth']==4 for x in e['cases'] for y in x['searches']),'root_only_saves':sum(x['ratio']<1 for x in pairs),'root_only_regresses':sum(x['ratio']>1 for x in pairs),'median_ratio':statistics.median(x['ratio'] for x in pairs),'mean_ratio':statistics.mean(x['ratio'] for x in pairs),'immediate_win_roots_retained':sum(bool(x['immediate_wins']) for x in e['cases'])},'corrections':index['corrections']}
extra=p/'equivalent-search-cost.json'
if extra.exists():
 q=json.loads(extra.read_bytes());compact['equivalent_search_cost']={'complete':q['complete'],'cases':[{'seed':x['seed'],'searches':[{'variant':z['variant'],'root_legal_bindings':z['root_legal_bindings'],'nodes':z['decision']['nodes'],'completed_depth':z['decision']['completed_depth'],'score':z['decision']['score']} for z in x['searches']]} for x in q['cases']]}
compact['forward_matched_physical_law']=json.loads((p/'forward-physical-analysis.json').read_bytes())['summary']
compact['forward_fresh_context']={k:json.loads((p/'forward-fresh-context.json').read_bytes())[k] for k in ('complete','declaration','seconds','summary','explicit_transitions')}
compact['generic_forward_mechanics']={k:json.loads((p/'generic-forward-mechanics.json').read_bytes())[k] for k in ('complete','declaration','seconds','summary','explicit_transitions')}
compact['response_equivalence_predictor']={k:json.loads((p/'response-equivalence-predictor.json').read_bytes())[k] for k in ('complete','declaration','seconds','summary','explicit_reply_transitions')}
write_record(root/'docs/research/data/joint_context_search_20261008.json',compact)
print({'members_verified':len(members),'producer_pins_verified':len(pins),'package_bytes':package.stat().st_size})
