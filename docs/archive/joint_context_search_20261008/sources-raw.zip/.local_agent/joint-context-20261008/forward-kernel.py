import sys,json,hashlib,time,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=root/'.local_agent/joint-context-20261008';out=p/'forward-kernel.json';assert not out.exists()
source=p/'context-replies.json';data=json.loads(source.read_bytes());base=ruleset_from_dict(json.loads((root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json').read_bytes())['definition'])
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Before outcomes:ALL192 exposed paired roots. Construct forward response kernel by uniform S0/S1 candidate replies, exact compiled trial effects, source-specific orthogonal count geometry after reply. No actual reply outcome/target geometry supplied to predictor; compare frozen uniform-legal reply means only AFTER prediction. S3 royal safety deliberately omitted both at reply and capture; retain and count lost anchors/illegal reply support, no favorable filtering. Uses private executor candidate/transition API diagnostically, not product legality. Supported simple C/R fixture only, not static material price or inferred opponent policy. No fitting/new seeds or frozen record changes. Whole120sec checkpoint, stops per root; persist8roots. Decision: can explicit one-step response approximation reduce error versus current no-response conditional geometry at moderate computational cost? Costs count candidates/transitions/seconds; prior Core producer timing not a controlled speedup claim.', 'rows':[]}
t=time.perf_counter();write_record(out,r)
try:
 for row in data['cases']:
  assert time.perf_counter()-t<120
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  actor=row['actor'];board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[25]=Piece(0,actor,actor);board[28]=Piece(1,'R','R')
  for (owner,tid),sq in zip(((0,'R'),(0,'R'),(1,'C'),(1,'R')),row['other_cells']):board[sq]=Piece(owner,tid,tid)
  definition=replace(base,initial_position=tuple(tuple(board[y*8:(y+1)*8]) for y in range(8)));c=compile_ruleset_for_execution(definition);engine=SemanticEngine(c);position=replace(GameSession(c).state.position,side_to_move=1)
  legal_pairs={(x['reply_source'],x['reply_target']) for x in row['outcomes']};assert len(legal_pairs)==len(row['outcomes'])
  candidates=[(a,b) for pattern in engine._patterns for a,b in engine._iter_candidates(pattern,position)];assert len({(a.source,a.target) for a,b in candidates})==len(candidates)
  outcomes=[]
  for a,binding in candidates:
   child=engine._transition(position,a,binding);target=a.target if a.source==28 else 28
   alive=child.board[25] is not None and child.board[25].owner==0
   count=None
   if alive:
    tx,ty=target%8,target//8;sx,sy=1,3
    if sx==tx or sy==ty:
     dx=(tx>sx)-(tx<sx);dy=(ty>sy)-(ty<sy);count=sum(child.board[(sy+dy*i)*8+sx+dx*i] is not None for i in range(1,max(abs(tx-sx),abs(ty-sy))))
   capture=count==(1 if actor=='C' else 0) if count is not None else False
   outcomes.append({'source':a.source,'target':a.target,'source_capture':capture,'legal_reply':(a.source,a.target) in legal_pairs,'source_alive':alive,'anchors_alive':all(child.board[k] is not None and child.board[k].current_type_id=='K' for k in (0,63))})
  assert legal_pairs.issubset({(a.source,a.target) for a,b in candidates})
  groups={}
  for x in outcomes:groups.setdefault(x['source'],[]).append(float(x['source_capture']))
  r['rows'].append({'seed':row['seed'],'actor':actor,'candidates':len(candidates),'legal_replies':len(legal_pairs),'action_uniform_forward':statistics.mean(x['source_capture'] for x in outcomes),'actor_uniform_forward':statistics.mean(statistics.mean(v) for v in groups.values()),'reference_legal_mean':statistics.mean(x['capture_legal'] for x in row['outcomes']),'reference_pseudo_mean':statistics.mean(x['pseudo_eligible'] for x in row['outcomes']),'initial_legal':float(row['initial_capture_legal']),'initial_pseudo':float(row['initial_screen_count']==(1 if actor=='C' else 0)),'illegal_reply_fraction':statistics.mean(not x['legal_reply'] for x in outcomes),'anchor_loss_fraction':statistics.mean(not x['anchors_alive'] for x in outcomes),'outcomes':outcomes})
  if len(r['rows'])%8==0:write_record(out,r)
 r['summary']={a:{'roots':96,**{k:statistics.mean(x[k] for x in r['rows'] if x['actor']==a) for k in ('action_uniform_forward','actor_uniform_forward','reference_legal_mean','reference_pseudo_mean','illegal_reply_fraction','anchor_loss_fraction')},**{predictor+'_root_mean_mse':statistics.mean((x[predictor]-x['reference_legal_mean'])**2 for x in r['rows'] if x['actor']==a) for predictor in ('action_uniform_forward','initial_legal','initial_pseudo')}} for a in ('C','R')}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
print(json.dumps({'complete':r['complete'],'seconds':r['seconds'],'summary':r['summary'],'transitions':sum(x['candidates'] for x in r['rows'])},indent=2))
