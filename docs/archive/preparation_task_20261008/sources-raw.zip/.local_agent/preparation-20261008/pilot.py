import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.coordinates import square_to_index
from generic_chess.core.actions import action_to_dict
from generic_chess.core.transition import legal_successors,apply_action
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import record_value,write_record
p=root/'.local_agent/preparation-20261008';out=p/'pilot.json';assert not out.exists();src=root/'.local_agent/target-context-20261008/displacement-role-pilot-v2.json';data=json.loads(src.read_bytes())['games']['chess'];decl=p/'declaration.json';selected=data['common_seeds'][:2];assert selected==[202610092008,202610092009]
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'declaration_sha256':hashlib.sha256(decl.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration':json.loads(decl.read_bytes()),'rows':[],'core_successor_transitions':0};t=time.perf_counter();write_record(out,r)
def check():
 assert time.perf_counter()-t<240 and r['core_successor_transitions']<60000
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
def successors(state,compiled):
 check();pairs=legal_successors(state,compiled);r['core_successor_transitions']+=len(pairs);return pairs
def idx(square):return square_to_index(square,8)
def kind(a,b):
 dx=b%8-a%8;dy=b//8-a//8
 return 'orthogonal' if dx==0 or dy==0 else ('diagonal' if abs(dx)==abs(dy) else 'other')
try:
 for old in [x for x in data['rows'] if x['seed'] in selected and x['owner']==0]:
  check();cells=old['cells'];source,target=cells[:2];actor=old['actor'];target_type=old['target_type'];board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[source]=Piece(0,actor,actor);board[target]=Piece(1,target_type,target_type)
  for sq,tid,owner in zip(cells[2:],old['background_types'],(0,0,1,1)):board[sq]=Piece(owner,tid,tid)
  definition=replace(build_western_chess_ruleset(),initial_position=tuple(tuple(board[y*8:y*8+8]) for y in range(8)));c=compile_ruleset_for_execution(definition);engine=semantic_engine_for(c);state=GameSession(c).state;original=state.position.board[source];victim=state.position.board[target]
  row={'seed':old['seed'],'actor':actor,'cells':cells,'target_type':target_type,'background_types':old['background_types'],'direct_position_reference':old['reference'],'preparations':[],'success':0,'witness':None,'mixed_witness':None};r['rows'].append(row)
  for prepare,prepared in successors(state,c):
   if not hasattr(prepare,'from_square') or idx(prepare.from_square)!=source:continue
   new_source=idx(prepare.to_square)
   if prepared.position.board[new_source]!=original or state.position.board[new_source] is not None:continue
   expected=list(state.position.board);expected[source]=None;expected[new_source]=original
   if tuple(expected)!=prepared.position.board:continue
   assert prepared.position.board[target]==victim
   item={'action':action_to_dict(prepare),'physical_replies':0,'terminal_replies':[],'source_lost_replies':0,'success':0,'preparation_terminal':record_value(prepared.terminal_status)};row['preparations'].append(item)
   if prepared.terminal_status.is_terminal:continue
   outcomes={}
   for reply,child in successors(prepared,c):
    check();tracked=target
    if hasattr(reply,'from_square') and idx(reply.from_square)==target:tracked=idx(reply.to_square)
    else:assert child.position.board[target]==victim
    actual=child.position.board[tracked];assert actual is not None and actual.owner==victim.owner and actual.base_type_id==victim.base_type_id
    source_alive=child.position.board[new_source]==original
    captures=[] if child.terminal_status.is_terminal or not source_alive else list(engine.iter_legal_action_bindings(child.position,source=new_source,target=tracked))
    available=bool(captures);observable=(available,source_alive,child.terminal_status)
    if child.position in outcomes:assert outcomes[child.position]==observable
    else:
     outcomes[child.position]=observable
     if child.terminal_status.is_terminal:item['terminal_replies'].append(record_value(child.terminal_status))
     if not source_alive:item['source_lost_replies']+=1
    if available:
     capture=_semantic_public_action(engine,captures[0][0]);mixed=actor=='Q' and {kind(source,new_source),kind(new_source,tracked)}=={'orthogonal','diagonal'}
     if row['witness'] is None or (mixed and row['mixed_witness'] is None):
      final=apply_action(child,capture,c);assert final.position.board[tracked].owner==0
      witness={'prepare':action_to_dict(prepare),'reply':action_to_dict(reply),'capture':action_to_dict(capture),'tracked_target':tracked,'history_lengths':[len(state.history),len(prepared.history),len(child.history),len(final.history)],'terminal':record_value(final.terminal_status),'movement_kinds':[kind(source,new_source),kind(new_source,tracked)]}
      if row['witness'] is None:row['witness']=witness
      if mixed:row['mixed_witness']=witness
   item['physical_replies']=len(outcomes);item['success']=sum(x[0] for x in outcomes.values())/len(outcomes) if outcomes else 0
   row['success']=max(row['success'],item['success'])
  write_record(out,r);print(old['seed'],actor,len(row['preparations']),row['success'],bool(row['mixed_witness']),flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
