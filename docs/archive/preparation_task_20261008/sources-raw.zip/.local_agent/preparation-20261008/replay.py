import sys,json,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action,legal_successors
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=root/'.local_agent/preparation-20261008';src=p/'pilot.json';data=json.loads(src.read_bytes());assert data['complete'];rows=[]
for row in data['rows']:
 source,target=row['cells'][:2];board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[source]=Piece(0,row['actor'],row['actor']);board[target]=Piece(1,row['target_type'],row['target_type'])
 for sq,tid,owner in zip(row['cells'][2:],row['background_types'],(0,0,1,1)):board[sq]=Piece(owner,tid,tid)
 c=compile_ruleset_for_execution(replace(build_western_chess_ruleset(),initial_position=tuple(tuple(board[y*8:y*8+8]) for y in range(8))));start=GameSession(c).state;engine=semantic_engine_for(c);verified=[]
 for label in ('witness','mixed_witness'):
  witness=row[label]
  if witness is None:continue
  state=start;states=[state]
  for field in ('prepare','reply','capture'):
   state=apply_action(state,action_from_dict(witness[field]),c);states.append(state)
  assert [len(s.history) for s in states]==witness['history_lengths']==[1,2,3,4]
  tracked=witness['tracked_target'];assert states[2].position.board[tracked].owner==1 and state.position.board[tracked].owner==0
  verified.append(label)
 # Independently recover the original opponent-first component with complete
 # Core state/history/terminal transitions rather than Position-only trials.
 pos=replace(start.position,side_to_move=1);key=repetition_identity_key(pos,c);counts=((key,1),);opponent=GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),));outcomes={};terminal_count=0
 for action,child in legal_successors(opponent,c):
  tracked=target
  if hasattr(action,'from_square') and action.from_square.file+8*action.from_square.rank==target:tracked=action.to_square.file+8*action.to_square.rank
  available=not child.terminal_status.is_terminal and bool(list(engine.iter_legal_action_bindings(child.position,source=source,target=tracked)))
  if child.position in outcomes:assert outcomes[child.position]==available
  else:
   outcomes[child.position]=available;terminal_count+=child.terminal_status.is_terminal
 direct=sum(outcomes.values())/len(outcomes) if outcomes else 0
 assert direct==row['direct_position_reference']
 best=[x['action'] for x in row['preparations'] if x['success']==row['success']]
 rows.append({'seed':row['seed'],'actor':row['actor'],'preparation_success':row['success'],'direct_full_core_success':direct,'verified_witnesses':verified,'best_preparations':best,'direct_terminal_replies':terminal_count,'preparation_terminal_branches':sum(x['preparation_terminal']['status']!='ongoing' for x in row['preparations']),'terminal_reply_branches':sum(len(x['terminal_replies']) for x in row['preparations'])})
write_record(p/'replay.json',{'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'scope':'Independent full Core replay of retained actual public-action paths and complete-state direct-response baseline; all10 direct values match old Position-only reference. Finite exposed diagnostic, not material or strength validation.','rows':rows})
print({'roots':len(rows),'witness_paths':sum(len(x['verified_witnesses']) for x in rows),'mixed_paths':sum('mixed_witness' in x['verified_witnesses'] for x in rows),'direct_values_exact':True})
