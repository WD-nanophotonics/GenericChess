import json, hashlib, zipfile, tempfile
from pathlib import Path
root=Path.cwd(); p=root/'.local_agent/preparation-20261008'
dest=root/'docs/archive/preparation_task_20261008'; dest.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
pilot=json.loads((p/'pilot.json').read_bytes()); replay=json.loads((p/'replay.json').read_bytes())
assert pilot['complete'] and len(replay['rows'])==10
assert pilot['producer_sha256']==sha((p/'pilot.py').read_bytes())
assert replay['producer_sha256']==sha((p/'replay.py').read_bytes())
assert replay['source_sha256']==sha((p/'pilot.json').read_bytes())
paths=[p/x for x in ('declaration.json','pilot.py','pilot.json','replay.py','replay.json','package.py')]
paths+=[root/'.local_agent/target-context-20261008/displacement-role-pilot-v2.json']
archive=dest/'sources-raw.zip'; assert not archive.exists()
members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in paths:
  name=f.relative_to(root).as_posix(); b=f.read_bytes(); z.writestr(name,b)
  members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with tempfile.TemporaryDirectory(dir=p) as temp:
 with zipfile.ZipFile(archive) as z:z.extractall(temp)
 for item in members:assert sha((Path(temp)/item['path']).read_bytes())==item['sha256']
index={'base_commit':'f67719f9061ad04fd48135ed4224369eb9634f38','archive_sha256':sha(archive.read_bytes()),'extracted_rehashed':True,'members':members,'excluded':'Private input, Slack/accounts, workflow/memo, credentials; all members Agent synthetic research.'}
(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
summary={'scope':pilot['declaration'],'complete':True,'core_successor_transitions':pilot['core_successor_transitions'],'seconds':pilot['seconds'],'rows':replay['rows'],'mixed_witnesses':[{'seed':r['seed'],'actor':r['actor'],'witness':r['mixed_witness']} for r in pilot['rows'] if r['mixed_witness']],'archive':'../../archive/preparation_task_20261008/index.json','limits':['Two predeclared exposed initial-safe Chess layouts; owner0 only.','Task probability is not material value, win rate or a recommendation to change defaults.','Q mixed paths need not maximize the preparation task.','Uniform physical replies is an explicit policy assumption. No quiet blend, human fitting or horizon sweep.']}
(root/'docs/research/data/preparation_task_20261008.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
(dest/'README.md').write_bytes(b'''# One-preparation target-capture task

On-demand evidence, not an active import or backlog. Seven extracted/rehashed
members include the pre-outcome declaration, producers, full outputs and exact
earlier synthetic input. index.json pins every byte and producer hashes are
checked against outputs. No private transport or workflow state is packaged.

Recover in a separate checkout of f67719f9061ad04fd48135ed4224369eb9634f38.
Verify archive/member hashes, extract relative paths there and recreate Python
dependencies. Remove only pilot.json/replay.json in that isolated copy before
running pilot.py then replay.py with the repository Python; never overwrite live
evidence. The earlier displacement JSON is an input, not an instruction to rerun
its entire provenance. package.py packages existing outputs, not new experiments.

Current interpretation: ../../research/SEMANTIC_CAPABILITY.md.
Compact data: ../../research/data/preparation_task_20261008.json.
Full Core histories, terminal outcomes and physical-duplicate observables are
checked before quotienting replies. Public actions/history keys stay unchanged.
Two exposed layouts and one owner do not establish universal prices or strength.
''')
print({'members_verified':len(members),'roots':len(replay['rows']),'archive_bytes':archive.stat().st_size,'terminal_branches':sum(r['preparation_terminal_branches']+r['terminal_reply_branches'] for r in replay['rows'])})
