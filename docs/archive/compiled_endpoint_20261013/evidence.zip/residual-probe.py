from pathlib import Path
import sys,ast,time,json,random,cProfile,pstats
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.core import semantic_executor as se
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/fallback-integration-20261013');out=D/'residual';out.mkdir(exist_ok=True);assert not(out/'plan.json').exists()
write_record(out/'plan.json',dict(question='Why do complete q4 resource roots remainshallow after scalar fallback cost improves?',seeds=[2026101961,2026101962],sizes=[18,20],prefix=8,rng_offset=16000,arms=['original','candidate'],q=[0,4],depth=3,max_nodes=4096,max_time_seconds=64,planned_calls=8,fuse_seconds=650,scope='cProfile same nodeconditions/work controls, not wallgain/completion test. Preserve actual abort/cap; only actual next primitivecost attribution.',search_calls=8))
tree=ast.parse((D/'before-executor.py').read_text(encoding='utf-8'));cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='SemanticEngine');fn=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='is_square_attacked');ns=dict(se.__dict__);exec(compile(ast.Module(body=[fn],type_ignores=[]),'before-profile','exec'),ns);OLD=ns['is_square_attacked'];NEW=se.SemanticEngine.is_square_attacked;rows=[];start=time.perf_counter()
try:
 for seed,size in zip([2026101961,2026101962],[18,20]):
  p.rr.stopped();se.SemanticEngine.is_square_attacked=NEW;g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(seed+16000)
  for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
  before=s.to_record();ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
  for q in [0,4]:
   for arm in ['original','candidate']:
    p.rr.stopped();assert time.perf_counter()-start<650;se.SemanticEngine.is_square_attacked=OLD if arm=='original' else NEW;player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);prof=cProfile.Profile();t=time.perf_counter()
    prof.enable();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=64,quiescence_max_depth=q,quiescence_hard_max_depth=8));prof.disable();wall=time.perf_counter()-t;assert before==s.to_record();stats=pstats.Stats(prof);functions=[]
    for (file,line,name),(primitive,calls,self_seconds,cumulative,callers) in stats.stats.items():
     if 'generic_chess' in file:functions.append(dict(file=file.replace(str(ROOT),'PROJECT'),line=line,name=name,calls=calls,self_seconds=self_seconds,cumulative_seconds=cumulative))
    functions.sort(key=lambda x:x['cumulative_seconds'],reverse=True)
    prof.dump_stats(str(out/f'{seed}-q{q}-{arm}.pstats'));rows.append(dict(seed=seed,q=q,arm=arm,wall=wall,decision=record_value(d),functions=functions,history_restored=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(seed,q,arm,round(wall,3),d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:se.SemanticEngine.is_square_attacked=NEW

