from pathlib import Path
import sys,time,cProfile,pstats,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core.semantic_executor import SemanticEngine
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'frontier-profile-plan.json',dict(question='Which required primitive dominates actual24Core frontier that exceeded20s although two node256 choices submit?',seed=2026101965,size=24,max_generation_attempts=4,cooperative_seconds=6,search_calls=0,scope='cProfile failed/capped frontier attribution only; no performance ratio, no time-extension rescue, nocapraise or globalcache'))
g=p.generate_game(p.GeneratorConfig(seed=2026101965,board_size=24,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=4));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);engine=SemanticEngine(c);start=time.perf_counter();polls=0;profile=cProfile.Profile();complete=False
def checkpoint():
 global polls
 polls+=1
 if time.perf_counter()-start>6:raise InterruptedError('declared6s attributionstop')
try:
 profile.enable();actions=engine.legal_actions(s.state.position,checkpoint=checkpoint);complete=True
except InterruptedError:actions=None
finally:profile.disable()
profile.dump_stats(str(D/'frontier-profile.pstats'));stats=pstats.Stats(profile);rows=[]
for (file,line,name),(primitive,calls,self_seconds,cumulative,callers) in stats.stats.items():
 if 'generic_chess' in file:rows.append(dict(file=file.replace(str(ROOT),'PROJECT'),line=line,name=name,calls=calls,self_seconds=self_seconds,cumulative_seconds=cumulative))
rows.sort(key=lambda x:x['cumulative_seconds'],reverse=True)
write_record(D/'frontier-profile.json',dict(complete=complete,legal_count=None if actions is None else len(actions),wall=time.perf_counter()-start,polls=polls,functions=rows,search_calls=0,meaning='capped profiler attribution; doesnotprovewholefrontiertime orsamebudgetdecision'))
print(json.dumps(dict(complete=complete,polls=polls,top=rows[:12]),indent=2))

