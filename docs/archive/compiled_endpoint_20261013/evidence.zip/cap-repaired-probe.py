from pathlib import Path
import sys,time,json,threading,_thread
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core.semantic_executor import SemanticEngine
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'cap-repaired-plan.json',dict(question='Does actual repaired large-rule generation reach complete Core and original-reference escape?',cases=[(2026101965,24),(2026101966,28)],generation_attempt_bound=4,wall_guard=120,frontier_guard=20,search_calls=0,changed_premise='reserved-ID bug repaired; original failed generator results retained; no resampling, no opening-filter widening'))
rows=[];start=time.perf_counter();timer=threading.Timer(120,_thread.interrupt_main);timer.daemon=True;timer.start()
try:
 for seed,size in [(2026101965,24),(2026101966,28)]:
  p.rr.stopped();t=time.perf_counter()
  try:g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=4))
  except Exception as e:
   rows.append(dict(seed=seed,size=size,generated=False,error_type=type(e).__name__,error=str(e)));write_record(D/'cap-repaired-rows.json',dict(complete=False,rows=rows));print(rows[-1],flush=True);continue
  generation=time.perf_counter()-t;t=time.perf_counter();c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);compile_seconds=time.perf_counter()-t
  base=dict(seed=seed,size=size,generated=True,generation_seconds=generation,generation_attempts=g.generation_report.generation_attempts,filters_passed=all(x.passed for x in g.generation_report.filter_results),complete_core=c.ir.capabilities.new_ir_core_executable,fingerprint=c.ruleset_fingerprint,original_index=c._incoming_attack_paths is not None,endpoint_schedule=c._incoming_attack_endpoints is not None,compile_seconds=compile_seconds)
  rows.append(base);write_record(D/'cap-repaired-rows.json',dict(complete=False,rows=rows));print(base,flush=True)
  engine=SemanticEngine(c);session=p.GameSession(c);t=time.perf_counter()
  def checkpoint():
   p.rr.stopped()
   if time.perf_counter()-t>20:raise InterruptedError('declaredfrontier20sec')
  try:actions=engine.legal_actions(session.state.position,checkpoint=checkpoint);base.update(frontier_complete=True,legal_count=len(actions),frontier_seconds=time.perf_counter()-t)
  except InterruptedError as e:base.update(frontier_complete=False,frontier_seconds=time.perf_counter()-t,error=str(e))
  def stopped():raise InterruptedError('actual stopped')
  try:engine.is_square_attacked(session.state.position,-1,0,stopped);raise AssertionError('swallowed')
  except InterruptedError:base['entry_cancel']=True
  write_record(D/'cap-repaired-rows.json',dict(complete=False,rows=rows))
 write_record(D/'cap-repaired-rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start,search_calls=0))
except KeyboardInterrupt:
 write_record(D/'cap-repaired-rows.json',dict(complete=False,rows=rows,guard_stop=True,elapsed_seconds=time.perf_counter()-start,search_calls=0))
finally:timer.cancel()

