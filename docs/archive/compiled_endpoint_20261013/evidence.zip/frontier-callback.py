from pathlib import Path
import sys,time,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core.semantic_executor import SemanticEngine
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'frontier-callback-plan.json',dict(question='Is the20s frontier failure an actualCore cost or the diagnosticcallback rereading privateflags perprimitive?',seed=2026101965,size=24,controls=['no_callback','clockonly_callback'],orders=2,private_stop_reads=2000,search_calls=0,scope='No20sbudgetextension/rerun; changedpremise checkpoint callback instrumentation; compare complete exactorderedactions and isolatedcallbackcost'))
g=p.generate_game(p.GeneratorConfig(seed=2026101965,board_size=24,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=4));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);engine=SemanticEngine(c);rows=[];reference=None
for rep in range(2):
 for arm in (['no_callback','clockonly_callback'] if rep==0 else ['clockonly_callback','no_callback']):
  p.rr.stopped();polls=[0];start=time.perf_counter()
  def callback():
   polls[0]+=1
   if time.perf_counter()-start>2:raise InterruptedError('2secclockguard')
  acts=engine.legal_actions(s.state.position,checkpoint=None if arm=='no_callback' else callback);wall=time.perf_counter()-start
  if reference is None:reference=acts
  assert acts==reference
  rows.append(dict(arm=arm,rep=rep,wall=wall,legal_count=len(acts),complete_frontier=True,exactorderedactions=True,polls=polls[0]))
start=time.perf_counter()
for _ in range(2000):p.rr.stopped()
stop_wall=time.perf_counter()-start
write_record(D/'frontier-callback-rows.json',dict(complete=True,rows=rows,isolated_private_stop_reads=2000,isolated_stop_seconds=stop_wall,stop_seconds_percall=stop_wall/2000,earlier_polls=148457,meaning='The capped diagnostic read3privateJSON percheckpoint. Isolated extrapolation only, not measured20swholeCore norCPUcapacity.',search_calls=0))
print(json.dumps(dict(rows=rows,stop_wall=stop_wall),indent=2))

