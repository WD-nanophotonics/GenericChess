from pathlib import Path
import sys,time,json,gc,tracemalloc,ast,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.rules import ir as ri
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'memory-plan.json',dict(question='What retained and peak Python heap does fallback-only compile-owned indexing add to ordinary and fallback constructors?',cases=[(2026101841,8),(2026101843,12),(2026101951,18),(2026101952,18),(2026101953,20),(2026101944,20)],orders=2,arms=['original','candidate'],scope='tracemalloc delta starts after generation and original IR compile; isolates derived CompiledSemanticRuleset constructor allocation excluding IR, Native process/RSS and total game memory',search_calls=0))
build=ri._incoming_attack_endpoints;rows=[]
for seed,size in [(2026101841,8),(2026101843,12),(2026101951,18),(2026101952,18),(2026101953,20),(2026101944,20)]:
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
 c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
 for rep in range(2):
  for arm in (['original','candidate'] if rep==0 else ['candidate','original']):
   gc.collect();ri._incoming_attack_endpoints=(lambda *args:None) if arm=='original' else build
   tracemalloc.start();t=time.perf_counter();c=ri.CompiledSemanticRuleset(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);wall=time.perf_counter()-t
   current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
   count=sum(len(entries) for sources in (c._incoming_attack_endpoints or {}).values() for typed in sources.values() for entries in typed.values())
   rows.append(dict(seed=seed,size=size,rep=rep,arm=arm,traced_current_bytes=current,traced_peak_bytes=peak,traced_constructor_seconds=wall,indexed=c._incoming_attack_paths is not None,endpoints=count))
   print(rows[-1],flush=True);write_record(D/'memory-rows.json',dict(complete=False,rows=rows));del c
ri._incoming_attack_endpoints=build
write_record(D/'memory-rows.json',dict(complete=True,rows=rows,scope='tracemalloc Python allocation delta of constructor only, not RSS; tracer timing not ordinary cost'))

