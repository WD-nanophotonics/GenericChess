def _incoming_attack_endpoints(ir, squares: int, *, max_paths: int=262144):
    """Bounded fallback schedule borrowing complete IR geometry paths.

    Only endpoint indices are retained, avoiding a copy of every ray prefix.
    Ranks preserve original capture traversal, including repeated geometry
    references. Exceeding the bound leaves the complete reference executor.
    """
    groups = {}
    rank = 0
    for owner in (0, 1):
        owner_key = str(owner)
        for pattern in ir.patterns:
            if pattern.target.kind != 'target_enemy':
                continue
            for tid in pattern.type_ids:
                for source in range(squares):
                    for gid in pattern.geometry_ids:
                        geometry = ir.geometry.get(gid)
                        if geometry is None or geometry.kind == 'drop':
                            continue
                        if geometry.atom_source is not None and geometry.atom_source[0] != tid:
                            continue
                        path = geometry.paths.get(owner_key, {}).get(source, ())
                        endpoints = range(min(1, len(path))) if geometry.kind == 'leap' else range(max(0, (geometry.min_steps or 1) - 1), len(path))
                        for endpoint in endpoints:
                            rank += 1
                            if rank > max_paths:
                                return None
                            groups.setdefault((owner_key, path[endpoint]), {}).setdefault(source, {}).setdefault(tid, []).append((rank, pattern, gid, endpoint))
    for sources in groups.values():
        for typed in sources.values():
            for tid, rows in typed.items():
                typed[tid] = tuple(rows)
    return groups
