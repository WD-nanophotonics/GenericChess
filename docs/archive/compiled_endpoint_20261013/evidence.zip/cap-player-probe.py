from pathlib import Path
import sys,time,json,threading,_thread
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'cap-player-plan.json',dict(question='Can public boundedsearch return a legal retained choice when both static schedules decline on actual24rule?',seed=2026101965,size=24,attempts=4,seconds=[1,4],q=0,max_depth=2,max_nodes=256,planned_calls=2,whole_guard=90,validation_scope='completefrontier alreadycapped20s; validate delivered action only by actualsubmit with20s cooperative maininterrupt; do not claimwholefrontier/24PVE ifvalidation is capped',no_cap_raise=True))
g=p.generate_game(p.GeneratorConfig(seed=2026101965,board_size=24,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=4));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rows=[];before=s.to_record()
timer=threading.Timer(90,_thread.interrupt_main);timer.daemon=True;timer.start()
try:
 for seconds in [1,4]:
  p.rr.stopped();player=AlphaBetaPlayer(c,use_disk_cache=False);t=time.perf_counter()
  decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=256,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=8))
  row=dict(seconds=seconds,wall=time.perf_counter()-t,decision=record_value(decision),requested_native=True,actual_provider=player.native_legality_provider is not None,history_restored=before==s.to_record(),fullfrontier_claim=False);rows.append(row);write_record(D/'cap-player-rows.json',dict(complete=False,rows=rows));print(row,flush=True)
  if decision.action is not None:
   guard=threading.Timer(20,_thread.interrupt_main);guard.daemon=True;guard.start();t=time.perf_counter()
   try:s.submit(decision.action);row.update(actual_submit=True,submit_seconds=time.perf_counter()-t);before=s.to_record()
   except KeyboardInterrupt:row.update(actual_submit=False,submit_guard_stop=True,submit_seconds=time.perf_counter()-t);assert before==s.to_record()
   finally:guard.cancel()
  write_record(D/'cap-player-rows.json',dict(complete=False,rows=rows))
 write_record(D/'cap-player-rows.json',dict(complete=True,rows=rows,search_calls=len(rows)))
except KeyboardInterrupt:write_record(D/'cap-player-rows.json',dict(complete=False,rows=rows,whole_guard_stop=True,search_calls=len(rows)))
finally:timer.cancel()

