from pathlib import Path
import sys,json,time,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core import semantic_executor as se
from generic_chess.rules.ir import geometry_paths_to
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'s3-influence-plan.json',dict(question='Does source/target influence of actual enemy geometry offer enough S3 trial redundancy to justify a next local proof?',seeds=[2026101961,2026101962,2026101963,2026101964],sizes=[18,20,18,20],prefix=8,rng_offset=16000,search_calls=0,decision='If a substantial fraction of eligible non-anchor board transitions leave every actual enemy source/prefix to ownanchor untouched AND exactchild checks remain equal, next develop one rule-conditional shortcut. Otherwise defer. No productionbypass, no statecache, no preserved legalfrontier monotonicity claim.',scope='Four selected previously exposed roots, no complete-domainproof. Full child effects and original incheck actually recomputed; movement-only source/target may fail other mechanisms, guards/aux exclusions are recorded. No promise basedon textual action size.'))
rows=[];start=time.perf_counter()
for seed,size in zip([2026101961,2026101962,2026101963,2026101964],[18,20,18,20]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);rng=random.Random(seed+16000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 engine=se.SemanticEngine(c);pos=s.state.position;side=pos.side_to_move;anchor=se._own_anchor(pos,c.support,side);parent_check=engine.in_check(pos,side);influence={anchor};sources=se._sources_by_owner_type(pos);paths=0
 for pattern in c.ir.patterns:
  if pattern.target.kind!='target_enemy':continue
  for tid in pattern.type_ids:
   for source,piece in sources.get((1-side,tid),()):
    for gid in pattern.geometry_ids:
     geom=c.ir.geometry.get(gid)
     if geom is None or geom.kind=='drop' or geom.atom_source is not None and geom.atom_source[0]!=tid:continue
     for path in geometry_paths_to(geom,str(1-side),source,anchor):
      influence.update(path);influence.add(source);paths+=1
 stats=dict(seed=seed,size=size,parent_in_check=parent_check,influence_squares=len(influence),enemy_paths=paths,aux_slots=len(c.ir.aux_slots),triggers=len(c.ir.triggers),capture_state_guards=sum(len(p.guards)+len(p.slot_guards) for p in c.ir.patterns if p.target.kind=='target_enemy'),pseudo_candidates=0,unaffected_candidates=0,unaffected_child_checks=0,check_changed_counterexamples=0,transition_errors=0)
 for pattern in c.ir.patterns:
  for action,binding in engine._iter_candidates(pattern,pos):
   stats['pseudo_candidates']+=1
   if binding.source==anchor or binding.source in influence or binding.target in influence:continue
   stats['unaffected_candidates']+=1
   try:child=engine._transition(pos,action,binding)
   except RuntimeError:stats['transition_errors']+=1;continue
   # Actual whole-board change verification: never assume only2 changed cells.
   changed=[i for i,(old,new) in enumerate(zip(pos.board,child.board)) if old!=new]
   if se._own_anchor(child,c.support,side)!=anchor or any(i in influence for i in changed):continue
   checked=engine.in_check(child,side);stats['unaffected_child_checks']+=1
   stats['check_changed_counterexamples']+=int(checked!=parent_check)
 stats['fraction_unaffected']=stats['unaffected_candidates']/max(1,stats['pseudo_candidates']);rows.append(stats);print(stats,flush=True);write_record(D/'s3-influence-rows.json',dict(complete=False,rows=rows))
write_record(D/'s3-influence-rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start,search_calls=0,source_target_rule='onlyfinite premise, actualtransition+wholeboarddiff+originalcheck recomputed, no production skipping'))

