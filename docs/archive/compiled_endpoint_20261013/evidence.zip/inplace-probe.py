from pathlib import Path
import sys,ast,gc,tracemalloc,time,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.rules import ir as ri
D=Path('.local_agent/fallback-integration-20261013')
tree=ast.parse(Path(ri.__file__).read_text(encoding='utf-8'));fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='_incoming_attack_endpoints')
source=ast.unparse(fn)
old='return {key: {source: {tid: tuple(rows) for tid, rows in typed.items()} for source, typed in sources.items()} for key, sources in groups.items()}'
assert old in source
source=source.replace(old,'''for sources in groups.values():
        for typed in sources.values():
            for tid, rows in typed.items():
                typed[tid] = tuple(rows)
    return groups''')
(D/'inplace-builder.py').write_bytes((source+'\n').encode())
ns=dict(ri.__dict__);exec(source,ns);alternate=ns['_incoming_attack_endpoints']
write_record(D/'inplace-plan.json',dict(question='Does freezing row lists in existing compile-owned mappings avoid the observed duplicate-dictionary peak without changing ordered rows?',seeds=[2026101952,2026101953,2026101944],sizes=[18,20,20],orders=2,arms=['current','inplace'],search_calls=0,scope='builder-only traced allocation, IR preexists; every result mapping compared exact; currentlyrunning resource keeps its frozen original builder'))
rows=[]
for seed,size in zip([2026101952,2026101953,2026101944],[18,20,20]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
 expected=c._incoming_attack_endpoints
 for rep in range(2):
  for arm in (['current','inplace'] if rep==0 else ['inplace','current']):
   gc.collect();tracemalloc.start();t=time.perf_counter();result=(ri._incoming_attack_endpoints if arm=='current' else alternate)(c.ir,size*size);seconds=time.perf_counter()-t;current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
   assert result==expected
   rows.append(dict(seed=seed,size=size,rep=rep,arm=arm,traced_current_bytes=current,traced_peak_bytes=peak,traced_build_seconds=seconds,all_mapping_rows_equal=True));del result
   print(rows[-1],flush=True);write_record(D/'inplace-rows.json',dict(complete=False,rows=rows))
write_record(D/'inplace-rows.json',dict(complete=True,rows=rows))

