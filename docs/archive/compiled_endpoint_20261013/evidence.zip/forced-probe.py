from pathlib import Path
import sys,json,pytest
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules import ir as ri
D=Path('.local_agent/fallback-integration-20261013')
targets=['tests/product/test_semantic_executor.py','tests/product/test_semantic_trial_checkpoint.py','tests/product/test_semantic_empty_guards.py','tests/product/test_semantic_binding_filters.py','tests/product/test_semantic_zone_guards.py','tests/product/test_recombined_semantic_lifecycle.py','tests/product/test_history_immediate_recapture_trace.py','tests/product/test_history_provenance.py','tests/product/test_generic_history_state_carrier.py','tests/product/test_generic_declaration_semantics.py','tests/product/test_rectangular_public_semantic_execution.py','tests/product/test_semantic_attack_map.py','tests/product/test_native_semantic_randomized_closure.py','tests/product/test_native_semantic_stress_differential.py','tests/product/test_search_semantic_checkpoint.py','tests/product/test_qsearch_semantic_effects.py']
(D/'forced-plan.json').write_text(json.dumps(dict(question='Does forcing compile-owned endpoint route retain existing whole-state/history/guard/Native controls?',targets=targets,scope='Same tests/rules/actions, only original incoming builder forced None in this owned Python process; no production default, no weakened assertions',forced_builder='original incoming paths -> None',candidate_source='final inplace field'),indent=2),encoding='utf-8')
old=ri._incoming_attack_paths;ri._incoming_attack_paths=lambda *args,**kwargs:None
try:code=pytest.main(['-q','--tb=short','--basetemp='+str(D/'forced-tmp'),'-o','cache_dir='+str(D/'pytest-cache'),'--junitxml='+str(D/'forced-junit.xml'),*targets])
finally:ri._incoming_attack_paths=old
raise SystemExit(code)

