from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from rule_semantics_ir_fixtures import _king_type,_ray_type,_semantic_ruleset,_ref,_own_anchor
from generic_chess.rules.schema import RuleSemanticAction,RuleGeometrySpec,RuleReplaceSelector,RuleStateGuard,RuleSpatialSelector,RuleTypeRef,RuleActionEffect,RulePathConstraint
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine,_sources_by_owner_type
from generic_chess.rules.ir import geometry_paths_to
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'s3-guard-counter-plan.json',dict(question='Can a boardregion capture guard invalidate geometry-only S3 influence even when actualsource/target and allchangedboardcells miss oldenemy paths?',size=4,scope='valid completeDSL counterexample, no productionshortcut or guardremoval',search_calls=0))
guard=RuleStateGuard(aggregation='count',owner='opponent',type_ref=RuleTypeRef('explicit','B'),compare_field='current',promoted='any',location='board',spatial=RuleSpatialSelector('zone',zone_squares=((3,2),)),comparison='eq',value=0)
capture=RuleSemanticAction(name='remote_board_region_enables_capture',type_ids=('R',),geometry=RuleGeometrySpec(kind='legacy_atoms',atom_kind='ray'),target_relation='enemy',composition='replace_legacy',replace_selector=RuleReplaceSelector(type_ids=('R',),action_family='board',target_relation='enemy',geometry_kind='ray',replace_all_matching=True),state_guards=(guard,),path_constraints=(RulePathConstraint('path_clear'),),effects=(RuleActionEffect('remove',square_ref=_ref('target'),disposition='capture_to_hand',piece_owner='opponent'),RuleActionEffect('move',from_ref=_ref('source'),to_ref=_ref('target'))),invariants=_own_anchor())
rows=[[None]*4 for _ in range(4)];rows[0][0]=Piece(0,'K','K');rows[3][3]=Piece(1,'K','K');rows[2][0]=Piece(1,'R','R');rows[2][3]=Piece(0,'B','B')
rules=_semantic_ruleset((_king_type(),_ray_type('R',(RayAtom((0,-1)),RayAtom((0,1)))),_ray_type('B',(LeapAtom((-1,0)),))), (capture,),n=4,rows=tuple(tuple(x) for x in rows))
c=compile_ruleset_for_execution(rules);s=GameSession(c);engine=SemanticEngine(c);position=s.state.position;anchor=0;influence={0};sources=_sources_by_owner_type(position)
for pattern in c.ir.patterns:
 if pattern.target.kind!='target_enemy':continue
 for tid in pattern.type_ids:
  for source,piece in sources.get((1,tid),()):
   for gid in pattern.geometry_ids:
    geom=c.ir.geometry.get(gid)
    if geom is None or geom.kind=='drop' or geom.atom_source is not None and geom.atom_source[0]!=tid:continue
    for path in geometry_paths_to(geom,'1',source,anchor):influence.add(source);influence.update(path)
parent=engine.in_check(position,0);assert not parent
found=[]
for pattern in c.ir.patterns:
 for action,binding in engine._iter_candidates(pattern,position):
  if binding.source!=11 or binding.target!=10:continue
  child=engine._transition(position,action,binding);changed=[i for i,(a,b) in enumerate(zip(position.board,child.board)) if a!=b];after=engine.in_check(child,0)
  assert 11 not in influence and 10 not in influence and not any(x in influence for x in changed)
  assert after
  assert engine._trial_child_if_s3_legal(pattern,position,action,binding) is None
  found.append(dict(action=record_value(action),changed=changed,parent_in_check=parent,child_in_check=after,source_target_outside_geometry=True,all_changed_cells_outside_geometry=True,fullS3_rejects=True))
assert found
write_record(D/'s3-guard-counter.json',dict(complete=True,ruleset=record_value(rules),initial=record_value(position),influence=sorted(influence),witnesses=found,valid_complete_core=c.ir.capabilities.new_ir_core_executable,search_calls=0,conclusion='Geometry alone is insufficient with remote state guards; a proposedconditional shortcut must explicitly account for guard dependencies or decline to original fullS3. Finite ordinaryfourroots guard-free results are not complete-domainadmission.'))
print('valid counterexample',sorted(influence),found)

