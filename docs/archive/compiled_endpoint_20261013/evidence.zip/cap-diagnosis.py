from pathlib import Path
import sys,time,json,threading,_thread
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
from generic_chess.generation import generator as gg
from generic_chess.generation.config import GeneratorConfig
D=Path('.local_agent/fallback-integration-20261013');events=[];start=time.perf_counter()
write_record(D/'cap-diagnosis-plan.json',dict(question='Which existing generation stage consumed the failed24/28 zero-result probe?',seed=2026101965,size=24,wall_guard_seconds=90,modified_semantics=False,not_search=True,previous='cap-plan.json failed40s estimate; onlyown confirmedprocess stopped; no cap outcome claimed'))
def record(stage,event):
 events.append(dict(stage=stage,event=event,elapsed=time.perf_counter()-start));write_record(D/'cap-diagnosis-events.json',dict(complete=False,events=events));print(events[-1],flush=True)
for name in ['compile_ruleset','run_soft_filters','legal_actions_from_position']:
 original=getattr(gg,name)
 def wrapper(*args,_name=name,_original=original,**kwargs):
  record(_name,'entered')
  result=_original(*args,**kwargs)
  record(_name,'returned')
  return result
 setattr(gg,name,wrapper)
timer=threading.Timer(90,_thread.interrupt_main);timer.daemon=True;timer.start()
try:
 record('generate_game','entered');g=gg.generate_game(GeneratorConfig(seed=2026101965,board_size=24,setup_preset='bilateral_random',allow_hybrid=True));record('generate_game','returned')
 write_record(D/'cap-diagnosis-events.json',dict(complete=True,events=events,generated=True))
except KeyboardInterrupt:
 write_record(D/'cap-diagnosis-events.json',dict(complete=True,events=events,generated=False,guard_stop=True,elapsed=time.perf_counter()-start,active_stage=events[-1]['stage']))
 print('own90second guard stopped; preserve exact stage; no generated/cap result',flush=True)
finally:timer.cancel()

