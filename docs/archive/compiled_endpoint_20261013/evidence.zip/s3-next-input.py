from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
D=Path('.local_agent/fallback-integration-20261013');rows=[]
for seed,size in zip([2026101961,2026101962,2026101963,2026101964],[18,20,18,20]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);captures=[x for x in c.ir.patterns if x.target.kind=='target_enemy']
 rows.append(dict(seed=seed,size=size,capture_patterns=len(captures),state_guards=sum(len(x.guards) for x in captures),slot_guards=sum(len(x.slot_guards) for x in captures),square_zone_guards=sum(len(x.square_zone_guards) for x in captures),aux_slots=len(c.ir.aux_slots),triggers=len(c.ir.triggers),invariants=sorted({y.kind for x in c.ir.patterns for y in x.invariants}),effects=sorted({y.kind for x in c.ir.patterns for y in x.effects}),candidate_scope_only=True))
counter=json.loads((D/'s3-guard-counter.json').read_text());counter_guards=sum(len(x['state_guards']) for x in counter['ruleset']['semantic_actions'] if x['target_relation']=='enemy')
assert counter_guards>0
write_record(D/'s3-next-input.json',dict(question='Can one frontier-local S3 influence proof preserve complete fullrule results and requiredstops while avoiding unchangedattackquery only when mechanically safe?',actual_compile_facts=rows,observed_finite_unchanged_children=631,observed_candidates=681,guard_counter_declined=counter_guards>0,immediate='Inspect existing _trial_child_if_s3_legal/_WorkingPosition boardeffect writes. Privateprototype only for guard/aux-independent captures and enemyinventory stableexceptremovals; all unsupportedmechanisms fall back original fullS3. Keep exact child transition/S4/history and mandatoryerrors/cancellation.',required_checks=['ownanchorunchanged; no created/retyped/opponentactors outsideoldpaths','allcaptureguard dependencies absent or explicitlyfullycovered; currentgeometryalone insufficient','same orderedcomplete actions; direct/check/drop/promotion/aux/history transition','negativecounter mustremainrejected byfullS3; no game-IDspecialization','callbacks/errors/stop budget; matchedfixedwork then useful resource; no default change before realcomparison'],done='bounded privatefalsification and one usefulcost/delivery choice; not universalproof/cacheframework or extraworker',production_shortcut=False,search_calls=0))
print(json.dumps(dict(facts=rows,counter_guard_count=counter_guards),indent=2))

