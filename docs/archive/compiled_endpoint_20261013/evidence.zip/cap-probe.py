from pathlib import Path
import sys,json,time,gc
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.rules import ir as ri
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess import build_builtin_ruleset
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'cap-plan.json',dict(question='Does real above-cap full ruleset escape preserve playable Core rather than truncate rule domain?',cases=[(2026101965,24),(2026101966,28)],search_calls=0,metadata_row_bound=262144,conditions='compile full generated rules; if schedule absent actual Core frontier and entry cancellation; retain both availability outcomes, no resampling',expected_seconds=40))
rows=[]
for seed,size in [(2026101965,24),(2026101966,28)]:
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));t=time.perf_counter();c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);compile_seconds=time.perf_counter()-t
 engine=SemanticEngine(c);s=p.GameSession(c);t=time.perf_counter();actions=engine.legal_actions(s.state.position);frontier_seconds=time.perf_counter()-t
 def stopped():raise InterruptedError('actual larger-rule stopped')
 try:engine.is_square_attacked(s.state.position,-1,0,stopped);raise AssertionError('stop swallowed')
 except InterruptedError:pass
 rows.append(dict(seed=seed,size=size,fingerprint=c.ruleset_fingerprint,complete_core=c.ir.capabilities.new_ir_core_executable,original_index_present=c._incoming_attack_paths is not None,endpoint_schedule_present=c._incoming_attack_endpoints is not None,endpoint_rows=sum(len(x) for sources in (c._incoming_attack_endpoints or {}).values() for typed in sources.values() for x in typed.values()),compile_seconds=compile_seconds,frontier_seconds=frontier_seconds,legal_count=len(actions),cancel_propagated=True))
 print(rows[-1],flush=True);write_record(D/'cap-rows.json',dict(complete=False,rows=rows));del engine,s,c;gc.collect()
write_record(D/'cap-rows.json',dict(complete=True,rows=rows,search_calls=0))

