from pathlib import Path
import ast,sys,time,json,random,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core import semantic_executor as se
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/fallback-integration-20261013');out=D/'fixed';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Do final compiled-owned normal/Core/Native/fallback q0/q4 callers preserve full non-time decision/work under fixed conditions?',seeds=[2026101841,2026101843,2026101952,2026101953],sizes=[8,12,18,20],prefix=8,rng_offset=15000,arms=['original','candidate'],orders=2,normal_backends=['Core','Native requested'],larger_backend='Core actual',q0_depth=6,q0_nodes=4096,q0_seconds=64,q4_depth=3,q4_nodes=256,q4_seconds=16,hardq=8,planned_calls=48,fuse_seconds=1200,scope='Same complete rules/history/defaultgeometric evaluator; actualprovider recorded. Counterbalanced whole non-time outputs/work compare unless timecaps differ. Ordinary concurrent resourceproducer/test load, no quiet-windowclaim.',candidate_ir_sha=hashlib.sha256(Path(p.CompiledSemanticRuleset.__module__.replace('.','/')+'.py').read_bytes()).hexdigest(),candidate_executor_sha=hashlib.sha256(Path(se.__file__).read_bytes()).hexdigest()))
tree=ast.parse((D/'before-executor.py').read_text(encoding='utf-8'));cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='SemanticEngine');fn=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='is_square_attacked');ns=dict(se.__dict__);exec(compile(ast.Module(body=[fn],type_ignores=[]),'before-fixed','exec'),ns);OLD=ns['is_square_attacked'];NEW=se.SemanticEngine.is_square_attacked
rows=[];unavailable=[];samples=[];start=time.perf_counter()
try:
 for seed,size in zip([2026101841,2026101843,2026101952,2026101953],[8,12,18,20]):
  p.rr.stopped();se.SemanticEngine.is_square_attacked=NEW;g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(seed+15000);walk=[]
  for _ in range(8):
   acts=sorted(s.legal_actions(),key=repr)
   if not acts or s.result.status.value!='ongoing':break
   action=rng.choice(acts);walk.append(record_value(action));s.submit(action)
  if len(walk)!=8 or s.result.status.value!='ongoing':
   unavailable.append(dict(seed=seed,unexecuted=16 if size<=16 else 8,no_resample=True));continue
  ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec);before=s.to_record()
  samples.append(dict(seed=seed,size=size,ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk,original_index=c._incoming_attack_paths is not None,endpoint_schedule=c._incoming_attack_endpoints is not None))
  write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable))
  for native in ([False,True] if size<=16 else [False]):
   for q,depth,nodes,seconds in [(0,6,4096,64),(4,3,256,16)]:
    for rep in range(2):
     for arm in (['original','candidate'] if rep==0 else ['candidate','original']):
      p.rr.stopped();assert time.perf_counter()-start<1200;se.SemanticEngine.is_square_attacked=OLD if arm=='original' else NEW;player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=native,evaluator_override=ev);t=time.perf_counter()
      d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=q,quiescence_hard_max_depth=8));wall=time.perf_counter()-t;assert before==s.to_record();child=s.state
      for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
      rows.append(dict(seed=seed,size=size,q=q,rep=rep,arm=arm,requested_native=native,actual_native=player.native_legality_provider is not None,wall=wall,decision=record_value(d),history_restored=True,pv_core_legal=True));write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable));print(seed,native,q,rep,arm,round(wall,4),d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
finally:se.SemanticEngine.is_square_attacked=NEW

