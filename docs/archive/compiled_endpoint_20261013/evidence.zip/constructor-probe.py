from pathlib import Path
import sys,time,json,gc,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.rules import ir as ri
D=Path('.local_agent/fallback-integration-20261013')
write_record(D/'constructor-plan.json',dict(question='What ordinary untraced constructor cost and exactorderedrows accompany the final fallback-only field?',cases=[(2026101841,8),(2026101843,12),(2026101951,18),(2026101952,18),(2026101953,20),(2026101944,20)],orders=2,arms=['original','candidate'],scope='precompiled fullIR input, no tracer, no search, normalindex preserved; observedconcurrent resource/test load',search_calls=0))
build=ri._incoming_attack_endpoints;rows=[];proof=[]
def stream(ir,area):
 for owner in (0,1):
  for pattern in ir.patterns:
   if pattern.target.kind!='target_enemy':continue
   for tid in pattern.type_ids:
    for source in range(area):
     for gid in pattern.geometry_ids:
      geometry=ir.geometry.get(gid)
      if geometry is None or geometry.kind=='drop' or geometry.atom_source is not None and geometry.atom_source[0]!=tid:continue
      for target,path in ri.geometry_candidates(geometry,str(owner),source):yield str(owner),target,pattern,tid,source,gid,path
for seed,size in [(2026101841,8),(2026101843,12),(2026101951,18),(2026101952,18),(2026101953,20),(2026101944,20)]:
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
 for rep in range(2):
  for arm in (['original','candidate'] if rep==0 else ['candidate','original']):
   gc.collect();ri._incoming_attack_endpoints=(lambda *args:None) if arm=='original' else build;t=time.perf_counter();c=ri.CompiledSemanticRuleset(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);dt=time.perf_counter()-t
   rows.append(dict(seed=seed,size=size,rep=rep,arm=arm,constructor_seconds=dt,normal_index=c._incoming_attack_paths is not None,endpoint_schedule=c._incoming_attack_endpoints is not None));del c
 ri._incoming_attack_endpoints=build;groups=build(c0.ir,size*size);expanded=[]
 for (owner,target),sources in groups.items():
  for source,typed in sources.items():
   for tid,entries in typed.items():
    for rank,pattern,gid,endpoint in entries:
     geom=c0.ir.geometry[gid];prefix=() if geom.kind=='leap' else tuple(geom.paths[owner][source][:endpoint]);expanded.append((rank,(owner,target,pattern,tid,source,gid,prefix)))
 expanded.sort(key=lambda row:row[0]);digest=hashlib.sha256();n=0
 for n,ref in enumerate(stream(c0.ir,size*size),1):
  assert expanded[n-1]==(n,ref)
  digest.update((repr(ref)+'\n').encode())
 assert n==len(expanded)
 proof.append(dict(seed=seed,size=size,rows=n,complete_ordered_equivalence=True,digest=digest.hexdigest(),normal_route_unchanged=c0._incoming_attack_paths is not None))
 print(seed,'constructor',rows[-4:],'ordered',n,flush=True)
 write_record(D/'constructor-rows.json',dict(complete=False,rows=rows,proof=proof))
 del groups,expanded,c0
write_record(D/'constructor-rows.json',dict(complete=True,rows=rows,proof=proof,search_calls=0))

