"""Source-derived binding path shortcut; no validation or callback removal."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.rules.ir import geometry_paths_to
from unittest.mock import patch
import json
output=Path(__file__).with_name('binding-path-ablation.json')
report=dict(configuration=dict(nodes=25000,depth=8,seconds_fuse=30,repeats=2),scope='Same strict Native provider; target-directed binding path only; current arbitrary material/lexical AB',rows=[])
def direct(self,gid,source,target,side):
    geometry=self.ir.geometry.get(gid)
    if geometry is None or geometry.kind=='drop':
        return None
    return next(geometry_paths_to(geometry,str(side),source,target),None)
for index in (0,7):
    case=CASES[index]
    compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if index==0 else 'standard_shogi'))
    engine=semantic_engine_for(compiled); cls=type(engine); original=cls._path_for_geometry
    # All actual finite paths, both sides, off-path targets and drops.
    checked=0
    for gid,g in engine.ir.geometry.items():
        for side in (0,1):
            for source in range(len(CoreBoard(case,compiled).initial.position.board)) if False else range(compiled.board_size**2):
                for target in range(compiled.board_size**2):
                    assert original(engine,gid,source,target,side)==direct(engine,gid,source,target,side)
                    checked+=1
    report.setdefault('geometry_queries',{})[case['id']]=checked
    for repeat in range(2):
        for mode in (['original','target_directed'] if repeat==0 else ['target_directed','original']):
            provider=NativeSemanticLegalityProvider.try_create(compiled,strict=True)
            with patch.object(cls,'_path_for_geometry',original if mode=='original' else direct):
                board=CoreBoard(case,compiled,provider)
                board.actions()
                row=minimal_ab(board,8,seconds=30,node_limit=25000)
            row.update(case=case['id'],repeat=repeat,mode=mode)
            report['rows'].append(row)
            output.write_text(json.dumps(report,indent=2)+'\n')
            print(case['id'],repeat,mode,row['work']['nodes'],row['wall_seconds'],flush=True)
