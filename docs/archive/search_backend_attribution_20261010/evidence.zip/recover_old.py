"""Recover the frozen old rules/adapter; never use live Shogi rules for old data.
Run --verify-only for a read-only D2 alignment check; original CLI otherwise.
"""
from pathlib import Path
import importlib.util
import json
import sys
ROOT=next(p for p in Path(__file__).resolve().parents if (p/"pyproject.toml").is_file())
sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict,compute_fingerprint
base=Path(__file__).resolve().parent
rules=json.loads((base/'frozen-rules.json').read_text())
spec=importlib.util.spec_from_file_location('old_attribution',base/'d6-source.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
def builder(name):
    r=ruleset_from_dict(rules['chess' if name=='western_chess' else 'shogi']['ruleset'])
    assert compute_fingerprint(r)==rules['chess' if name=='western_chess' else 'shogi']['fingerprint']
    return r
module.build_builtin_ruleset=builder
if '--verify-only' in sys.argv:
    for case in module.CASES:
        c=module.compile_ruleset_for_execution(builder('western_chess' if case['game']=='chess' else 'standard_shogi'))
        core=module.CoreBoard(case,c)
        other=module.ChessBoard(case) if case['game']=='chess' else module.ShogiBoard(case)
        assert module.audit_pair(core,other,1)>1
    print('eight frozen old-rule frontiers verified')
else:
    module.main()
