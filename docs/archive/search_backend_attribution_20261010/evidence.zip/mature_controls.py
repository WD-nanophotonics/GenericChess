"""Existing local engine probes; overall references, never aligned search truth."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import hashlib
import json
import queue
import subprocess
import threading
from time import perf_counter
from scripts.search_backend_comparison import CASES, ChessBoard, ShogiBoard

class Protocol:
    def __init__(self, path, greeting):
        self.proc = subprocess.Popen([str(path)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace',
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        self.lines = queue.Queue()
        self.raw = []
        # Transport-only reader, no research worker, process launch or file writer.
        def read():
            for line in self.proc.stdout:
                self.lines.put(line.rstrip())
            self.lines.put(None)
        self.reader = threading.Thread(target=read, daemon=True)
        self.reader.start()
        try:
            self.send(greeting)
            self.handshake = self.until(lambda line: line == greeting+'ok')
        except Exception:
            self.close()
            raise

    def send(self, text):
        self.raw.append('> '+text)
        self.proc.stdin.write(text+'\n')
        self.proc.stdin.flush()

    def until(self, predicate):
        start, lines = perf_counter(), []
        while True:
            timeout = 10-(perf_counter()-start)
            if timeout <= 0:
                raise TimeoutError('bounded engine protocol read')
            line = self.lines.get(timeout=timeout)
            if line is None:
                raise RuntimeError('engine exited before expected response')
            lines.append(line)
            self.raw.append(line)
            if predicate(line):
                return lines

    def close(self):
        if self.proc.poll() is None:
            try:
                self.send('quit')
                self.proc.wait(timeout=3)
            except Exception:
                self.proc.kill()
                self.proc.wait(timeout=3)
        self.reader.join(timeout=1)

output = Path(__file__).with_name('mature-overall.json')
report = dict(scope='Overall engine reference; evaluation, draw policies and selective depth unaligned',
              seconds=0.25, threads=1, hash_mib=16, repeat=2, engines=[])
entries = [
    ('chess', ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe', 'uci'),
    ('shogi', ROOT/'.local_agent/see-price-20261007/fairy-original.exe', 'usi'),
]
for game, path, greeting in entries:
    engine_record = dict(game=game, binary_relative=str(path.relative_to(ROOT)).replace('\\', '/'),
                         sha256=hashlib.sha256(path.read_bytes()).hexdigest(), rows=[])
    report['engines'].append(engine_record)
    engine = None
    try:
        start = perf_counter()
        engine = Protocol(path, greeting)
        engine_record['startup_seconds'] = perf_counter()-start
        engine_record['handshake'] = engine.handshake
        names = {line.split('option name ',1)[1].split(' type ',1)[0]
                 for line in engine.handshake if line.startswith('option name ')}
        for candidates, value in [(('Threads', 'USI_Threads'), '1'), (('Hash', 'USI_Hash'), '16')]:
            name = next((name for name in candidates if name in names), None)
            if name is None:
                raise RuntimeError('cannot verify declared resource option '+repr(candidates))
            engine.send(f'setoption name {name} value {value}')
        if game == 'shogi':
            import re
            variant = next((line for line in engine.handshake if 'Variant type combo' in line), '')
            if not re.search(r'(?:default|var) shogi(?: |$)', variant):
                raise RuntimeError('existing Fairy build does not advertise full9x9 shogi')
            name = variant.split('option name ',1)[1].split(' type ',1)[0]
            engine.send(f'setoption name {name} value shogi')
            if 'Use NNUE' in names:
                engine.send('setoption name Use NNUE value false')
        for case in [case for case in CASES if case['game'] == game]:
            board = ChessBoard(case) if game == 'chess' else ShogiBoard(case)
            legal = {label for label, _ in board.actions()}
            for repeat in range(2):
                engine.send(greeting+'newgame')
                engine.send('isready')
                engine.until(lambda line: line == 'readyok')
                position = ('position startpos' if case['setup']=='start' else
                            'position '+('fen' if game=='chess' else 'sfen')+' '+case['setup'])
                if case['moves']:
                    position += ' moves '+case['moves']
                engine.send(position)
                start = perf_counter()
                engine.send('go movetime 250')
                lines = engine.until(lambda line: line.startswith('bestmove '))
                move = lines[-1].split()[1]
                engine_record['rows'].append(dict(case=case['id'], repeat=repeat, move=move,
                    legal=move in legal, wall_seconds=perf_counter()-start,
                    info=lines, comparison_scope='unaligned overall reference'))
                output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
                print(game, case['id'], repeat, move, move in legal, flush=True)
    except Exception as exc:
        engine_record['error'] = type(exc).__name__+': '+str(exc).replace(str(ROOT), '<repo>')
        print(game, engine_record['error'], flush=True)
    finally:
        if engine is not None:
            engine.close()
            engine_record['raw_protocol'] = engine.raw
        output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
