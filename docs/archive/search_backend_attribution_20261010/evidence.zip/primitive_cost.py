"""Bounded primitive controls; cold fronts, cached-parent push/pop, static eval.
Direct cache clearing is assay instrumentation, not a new production API.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import json
from time import perf_counter
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
output=Path(__file__).with_name('primitive-cost.json')
report=dict(configuration=dict(cold_front_calls=20,push_pop_calls=100,evaluation_calls=5000),rows=[])
for case in CASES:
    compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
    provider=NativeSemanticLegalityProvider.try_create(compiled,strict=True)
    for name in ('core','specialized','native_legality'):
        start=perf_counter()
        board=((ChessBoard(case) if case['game']=='chess' else ShogiBoard(case)) if name=='specialized' else CoreBoard(case,compiled,provider if name=='native_legality' else None))
        row=dict(case=case['id'],backend=name,setup_seconds=perf_counter()-start)
        signatures=[]
        start=perf_counter()
        for _ in range(20):
            if isinstance(board,CoreBoard):
                board.runtime._legal_cache=None
                board.runtime._bindings={}
            actions=board.actions()
            signatures.append(tuple(label for label,_ in actions))
        row['cold_front_seconds']=perf_counter()-start
        assert all(s==signatures[0] for s in signatures)
        row['legal_count']=len(actions)
        start=perf_counter()
        for _ in range(100):
            board.push(actions[0][1]); board.pop()
        row['push_pop_seconds']=perf_counter()-start
        assert board.restored()
        start=perf_counter()
        scores=[board.evaluate() for _ in range(5000)]
        row['evaluation_seconds']=perf_counter()-start
        assert len(set(scores))==1
        row['score']=scores[0]
        if isinstance(board,CoreBoard):
            row['provider_calls']=board.runtime.legal_provider_calls
            row['provider_fallbacks']=board.runtime.legal_provider_fallbacks
            row['payload_seconds']=board.runtime.legal_provider_payload_seconds
            row['decode_seconds']=board.runtime.legal_provider_decode_binding_seconds
        report['rows'].append(row)
        output.write_text(json.dumps(report,indent=2)+'\n')
        print(case['id'],name,row,flush=True)
