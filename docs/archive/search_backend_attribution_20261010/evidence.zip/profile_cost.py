"""One-off fixed-work diagnosis; archive alongside results, not a live API."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import cProfile
import hashlib
import json
import pstats
from time import perf_counter
from unittest.mock import patch
from scripts.search_backend_comparison import *
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.core.semantic_executor import semantic_engine_for

output = Path(__file__).with_name('fixed-work-profile.json')
report = dict(nodes=25000, depth=8, seconds_fuse=120,
              source_sha256=hashlib.sha256((ROOT/'scripts/search_backend_comparison.py').read_bytes()).hexdigest(),
              scope='Clean and cProfile/transition-counted calls separately; Python transition counters do not count C/native work', rows=[])
for index in (0, 7):
    case = CASES[index]
    compiled = compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if index == 0 else 'standard_shogi'))
    provider = NativeSemanticLegalityProvider.try_create(compiled, strict=True)
    for backend in ('core', 'core_cooperative_deadline', 'specialized', 'core_native_legality'):
        for profiled in (False, True):
            start = perf_counter()
            board = (ChessBoard(case) if index == 0 else ShogiBoard(case)) if backend == 'specialized' else CoreBoard(
                case, compiled, provider=provider if backend == 'core_native_legality' else None)
            board.actions()  # declare warm root; initialization separate
            setup_seconds = perf_counter()-start
            counts = dict(python_semantic_transitions=0)
            profiler = cProfile.Profile()
            if profiled:
                engine = semantic_engine_for(compiled)
                cls, original = type(engine), type(engine)._transition
                def counted(self, *args, **kwargs):
                    counts['python_semantic_transitions'] += 1
                    return original(self, *args, **kwargs)
                with patch.object(cls, '_transition', counted):
                    profiler.enable()
                    row = minimal_ab(board, 8, seconds=120, node_limit=25000,
                                     cooperative=backend == 'core_cooperative_deadline')
                    profiler.disable()
                stats = pstats.Stats(profiler)
                functions = []
                for (filename, line, name), (primitive, total, own, cumulative, callers) in stats.stats.items():
                    try:
                        file = str(Path(filename).relative_to(ROOT)).replace('\\', '/')
                    except ValueError:
                        file = Path(filename).name
                    functions.append(dict(file=file, line=line, name=name, primitive_calls=primitive,
                                          total_calls=total, own_seconds=own, cumulative_seconds=cumulative))
                functions.sort(key=lambda x: x['own_seconds'], reverse=True)
                row.update(profile_functions=functions[:50], **counts)
            else:
                row = minimal_ab(board, 8, seconds=120, node_limit=25000,
                                 cooperative=backend == 'core_cooperative_deadline')
            row.update(case=case['id'], backend=backend, profiled=profiled, setup_seconds=setup_seconds)
            report['rows'].append(row)
            output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
            print(case['id'], backend, profiled, row['work']['nodes'], row['wall_seconds'], counts, flush=True)
