import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/drop_budget_20261008';dest.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
curve=json.loads((p/'curve.json').read_bytes());mate=json.loads((p/'mate-replay.json').read_bytes());assert curve['complete'] and mate['complete'];assert curve['producer_sha256']==sha((p/'curve.py').read_bytes());assert mate['producer_sha256']==sha((p/'mate_replay.py').read_bytes())
rows=[]
for ply in (4,5,6,7,8):
 for cap in (16384,32768):
  for staged in (False,True):
   cells=[x for x in curve['cases'] if x['ply']==ply and x['cap']==cap and x['staged']==staged];assert len(cells)==2
   x=cells[0];d=x['decision'];rows.append({'ply':ply,'cap':cap,'staged':staged,'completed_depth':d['completed_depth'],'nodes':d['nodes'],'score':d['score'],'action':d['action'],'evaluation_calls':d['evaluation_calls'],'wall_seconds':[x['wall_seconds'] for x in cells]})
summary={'complete':True,'producer_sha256':sha(Path(__file__).read_bytes()),'curve_sha256':sha((p/'curve.json').read_bytes()),'mate_sha256':sha((p/'mate-replay.json').read_bytes()),'search_calls':len(curve['cases']),'seconds':curve['seconds'],'rows':rows,'core_mate':mate,'interpretation':['All40 calls complete depth3 and cold repeats match exactly. Both budgets have the same completed nodes/scores; doubling beyond16384 adds no work at fixed depth3.','Ply6 baseline9544/staged9569nodes reveal mate999999997; old8192 cap retained, earlier completed depth2score9203 not overwritten. Root choice is unchanged; new evidence recognizes its forced win.','Core replay after actual drop R(6,6) covers both legal defenses, each has a winning terminal response,110yielded transitions/~.051sec. This independent local check does not become a prerequisite for future development.','About16.5% more actually used nodes than8192 finishes the iteration; the configured doubled cap is headroom, not consumed work. Local5% per-node interventions cannot overcome a fixed node cap.','No default budget, staged ordering, price or bridge changes; all exposed development, not strength/holdout claims.'],'archive':'../../archive/drop_budget_20261008/index.json'}
files=sorted(x for x in p.iterdir() if x.suffix in ('.py','.json'))+[root/'.local_agent/preparation-transfer-20261008/recombined.json'];archive=dest/'sources-raw.zip';assert not archive.exists();members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();body=f.read_bytes();z.writestr(name,body);members.append({'path':name,'bytes':len(body),'sha256':sha(body)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for x in members:assert sha((Path(tmp)/x['path']).read_bytes())==x['sha256']
index={'base_commit':'6120b63f4fcb2a564fbfd36770a5c01b72eeca85','members':members,'archive_sha256':sha(archive.read_bytes()),'extracted_rehashed':True,'excluded':'User/private data, Slack/accounts, credentials, workflow state.','caller_correction':'Initial mate replay tried to decode dataclass record without kind; selected exact actual legal action by full record identity instead, before producing result. Not a product defect.'}
(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());(root/'docs/research/data/drop_budget_20261008.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());print({'members':len(members),'calls':len(curve['cases']),'seconds':curve['seconds']})
