import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;source=root/'.local_agent/preparation-transfer-20261008/recombined.json';old=json.loads(source.read_bytes());out=p/'curve.json';assert not out.exists()
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));cfg=EvaluationConfig(**old['config']);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');s=GameSession(c);started=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Existing8192-node ply6 cap is observed, not frozen validation success. All five real-history frontiers,depth3, baseline/staged,16384/32768nodes,two cold rotated repeats,10sec each, <=40calls/240sec. Both methods get identical conditions. Question: does a modest finite node increment finish the iteration/change action-score, and does staged ordering cost change at completed depth? No old record or success criterion overwritten, no restored holdout. No local geometry/Native bridge intervention.','cases':[]};write_record(out,r)
try:
 for ply in range(9):
  if ply>=4:
   for cap in (16384,32768):
    for repeat in (0,1):
     for staged in ((False,True) if (ply+repeat)%2 else (True,False)):
      assert time.perf_counter()-started<240
      assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
      player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False,use_staged_move_picker=staged));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=cap,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t;validate_pv(s,d);new=record_value(d)
      for x in r['cases']:
       if x['ply']==ply and x['cap']==cap and x['staged']==staged:
        assert all(x['decision'][k]==new[k] for k in ('score','action','nodes','completed_depth','principal_variation'))
       if x['ply']==ply and x['decision']['completed_depth']==3 and d.completed_depth==3:assert x['decision']['score']==d.score
      r['cases'].append({'ply':ply,'cap':cap,'repeat':repeat,'staged':staged,'wall_seconds':wall,'decision':new});write_record(out,r)
   print(ply,[(x['cap'],x['staged'],x['decision']['completed_depth'],x['decision']['nodes'],x['decision']['score']) for x in r['cases'] if x['ply']==ply and x['repeat']==0],flush=True)
  if ply<8:s.submit(action_from_dict(old['route'][ply]))
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
