import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/drop_budget_20261008';sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((p/'mate-replay-cost.json').read_bytes());assert r['complete'] and r['producer_sha256']==sha((p/'mate_replay_cost.py').read_bytes())
files=[p/'mate_replay_cost.py',p/'mate-replay-cost.json',p/'correct_cost.py',Path(__file__)];archive=dest/'mate-cost-correction.zip';assert not archive.exists();members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();body=f.read_bytes();z.writestr(name,body);members.append({'path':name,'bytes':len(body),'sha256':sha(body)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for x in members:assert sha((Path(tmp)/x['path']).read_bytes())==x['sha256']
index={'archive_sha256':sha(archive.read_bytes()),'members':members,'extracted_rehashed':True,'correction':'legal_successors eagerly constructs tuples. Original110 counts consumed/visited successors, not all constructed. Replayed actual construction215 including root, same both-defense mate result. Original archive untouched.'};(dest/'mate-cost-index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
data=root/'docs/research/data/drop_budget_20261008.json';s=json.loads(data.read_bytes());s['mate_cost_correction']={'original_measure':'110consumed/visited successors, not all eager constructions','actual_constructed':215,'seconds':r['seconds'],'producer_sha256':r['producer_sha256'],'result_sha256':sha((p/'mate-replay-cost.json').read_bytes()),'archive':'../../archive/drop_budget_20261008/mate-cost-index.json'};data.write_bytes((json.dumps(s,indent=2)+'\n').encode())
