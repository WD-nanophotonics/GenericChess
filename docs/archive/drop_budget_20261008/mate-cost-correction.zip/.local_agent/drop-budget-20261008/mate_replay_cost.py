import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action,legal_successors as original_successors
from generic_chess.core.terminal import terminal_result
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
created=0
def legal_successors(state,compiled):
 global created
 result=original_successors(state,compiled);created+=len(result);return result
p=Path(__file__).parent;src=root/'.local_agent/preparation-transfer-20261008/recombined.json';old=json.loads(src.read_bytes());curve=json.loads((p/'curve.json').read_bytes());out=p/'mate-replay-cost.json';assert not out.exists()
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for action in old['route'][:6]:s.submit(action_from_dict(action))
choice=next(x['decision']['action'] for x in curve['cases'] if x['ply']==6 and not x['staged']);a,=[x for x in s.legal_actions() if record_value(x)==choice];owner=s.state.position.side_to_move;t=time.perf_counter();transitions=0
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'curve_sha256':hashlib.sha256((p/'curve.json').read_bytes()).hexdigest(),'scope':'Confirm newly completed depth3 mate by actual full-history Core root action, all legal opponent defenses and one actual mate response each. No WDL prerequisite for development and no claim beyond this synthetic root. Stop at10000Core transitions/60sec; retain partial on failure.','root_action':choice,'owner':owner,'defenses':[]};write_record(out,r)
try:
 child=apply_action(s.state,a,c);transitions+=1
 assert not terminal_result(child,c).is_terminal
 for defense,reply in legal_successors(child,c):
  transitions+=1;assert time.perf_counter()-t<60;assert transitions<10000
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  assert not terminal_result(reply,c).is_terminal
  witness=None
  for response,final in legal_successors(reply,c):
   transitions+=1;assert time.perf_counter()-t<60;assert transitions<10000
   terminal=terminal_result(final,c)
   if terminal.is_terminal and terminal.winner==owner:
    witness={'action':action_to_dict(response),'terminal':record_value(terminal),'history_length':len(final.history)};break
  r['defenses'].append({'defense':action_to_dict(defense),'witness':witness});write_record(out,r);assert witness is not None
 assert r['defenses'];r['complete']=True
finally:r['core_transitions']=transitions;r['core_successors_constructed']=created+1;r['seconds']=time.perf_counter()-t;write_record(out,r)
print(json.dumps({'defenses':len(r['defenses']),'transitions':transitions,'seconds':r['seconds']}))

