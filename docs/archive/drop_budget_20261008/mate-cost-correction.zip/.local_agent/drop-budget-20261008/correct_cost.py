from pathlib import Path
p=Path(__file__).parent
s=(p/'mate_replay.py').read_text(encoding='utf-8-sig')
s=s.replace('apply_action,legal_successors','apply_action,legal_successors as original_successors')
s=s.replace("p=Path(__file__).parent;", "created=0\ndef legal_successors(state,compiled):\n global created\n result=original_successors(state,compiled);created+=len(result);return result\np=Path(__file__).parent;")
s=s.replace("out=p/'mate-replay.json'", "out=p/'mate-replay-cost.json'")
s=s.replace("r['core_transitions']=transitions", "r['core_transitions']=transitions;r['core_successors_constructed']=created+1")
(p/'mate_replay_cost.py').write_text(s,encoding='utf-8')
