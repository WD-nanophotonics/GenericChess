"""Exposed failure diagnostic: common1/4sec, no coefficient adjustment."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-stronger-20261007';out=p/'adverse-curve.json';assert not out.exists()
raw=(p/'paired-roots.json').read_bytes();v=json.loads(raw)
x=next(x for x in v['rows'] if x['game_index']==7 and x['played_index']==33)
binaries={'pure':ROOT/'.local_agent/mature-search/build/fairy-material.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe'}
config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
report=dict(question='Does the observed activity g6g5 regression persist under symmetric extra root time?',declaration='One exposed linearBlack root33, same full history, pure/activity at1/4sec; fresh hash each call, Threads1/Hash16, unchanged scale/term.10sec requested local plus at most8sec child reference; no game extension, tuning or holdout claim. A switch motivates resource/frontier diagnosis; persistent regression motivates specific safety failure work, not coefficient fitting.',source_sha256=hashlib.sha256(raw).hexdigest(),rows=[],references={},complete=False)
d.write_record(out,report);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
fen=chess.STARTING_FEN;prefix=x['history_prefix'];b=chess.Board(fen);[b.push_uci(m) for m in prefix]
assert b.fen(en_passant='fen')==x['fen'];state,_=d.replay_prefix(fen,c,prefix);legal={d.uci(a) for a in d.iter_legal_actions(state,c)}
for seconds in (1,4):
 for mode,binary in binaries.items():
  for name in ('rollout','advisor','slack'):
   flags=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
  with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
   e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=d.UciMaterial(e,fen,'linear_mixture',seconds)
   d.replay_prefix(fen,c,prefix,(player,));move,r=player.choose();assert move in legal
   r.update(leaf_mode=mode,requested_seconds=seconds);report['rows'].append(r);d.write_record(out,report)
with chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as e:
 e.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
 for move in sorted({r['move'] for r in report['rows']}):
  child=b.copy(stack=True);child.push_uci(move);e.configure({'Clear Hash':None});t=time.perf_counter()
  info=e.analyse(child,chess.engine.Limit(nodes=1000000,time=2),game=object());score=info['score'].pov(b.turn)
  report['references'][move]=dict(cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),engine_seconds=info.get('time'),wall_seconds=time.perf_counter()-t,pv=[m.uci() for m in info.get('pv',())]);d.write_record(out,report)
report['complete']=True;d.write_record(out,report)
print([(r['leaf_mode'],r['requested_seconds'],r['move'],r['engine_depth'],r['engine_nodes']) for r in report['rows']],report['references'])
