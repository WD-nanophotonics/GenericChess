"""Fixed early-root sampling, unchanged leaf pair, finite child diagnostics."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-stronger-20261007';out=p/'paired-roots.json';assert not out.exists()
raw=(p/'games.json').read_bytes();games=json.loads(raw);assert games['complete'] and len(games['games'])==12
config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
binaries={'pure':ROOT/'.local_agent/mature-search/build/fairy-material.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe'}
report=dict(scope='Predeclared first local-to-move roots at/after subsequent16/32 in each of12stronger games. Exposed development, finite child references, not WDL/Elo.',input_sha256=hashlib.sha256(raw).hexdigest(),rows=[],skipped=[],complete=False)
d.write_record(out,report);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
with chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as strong:
 strong.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
 for gi,g in enumerate(games['games']):
  policy=g['white'] if g['white']!='uci_reference' else g['black'];side=0 if g['white']==policy else 1
  for threshold in (16,32):
   found=next((i for i,r in enumerate(g['moves']) if i>=threshold and r['side']==side),None)
   if found is None:report['skipped'].append(dict(game_index=gi,threshold=threshold,reason='no recorded local move at/after threshold'));continue
   prefix=g['opening_uci']+[r['move'] for r in g['moves'][:found]]
   b=chess.Board(g['initial_fen']);[b.push_uci(m) for m in prefix]
   state,_=d.replay_prefix(g['initial_fen'],c,prefix);assert not state.terminal_status.is_terminal
   legal={d.uci(a) for a in d.iter_legal_actions(state,c)};assert legal=={m.uci() for m in b.legal_moves}
   row=dict(game_index=gi,source_mode=g['leaf_mode'],policy=policy,local_side=side,threshold=threshold,played_index=found,fen=b.fen(en_passant='fen'),history_prefix=prefix,choices=[],references={});report['rows'].append(row)
   for mode,binary in binaries.items():
    with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
     e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=d.UciMaterial(e,g['initial_fen'],policy,1)
     d.replay_prefix(g['initial_fen'],c,prefix,(player,));move,r=player.choose();assert move in legal
     r.update(leaf_mode=mode,requested_seconds=1);row['choices'].append(r)
   selections={x['move'] for x in row['choices']};row['equal_move']=len(selections)==1
   if not row['equal_move']:
    for move in sorted(selections):
     child=b.copy(stack=True);child.push_uci(move);strong.configure({'Clear Hash':None})
     t=time.perf_counter();info=strong.analyse(child,chess.engine.Limit(nodes=500000,time=1),game=object());score=info['score'].pov(b.turn)
     row['references'][move]=dict(cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),engine_seconds=info.get('time'),wall_seconds=time.perf_counter()-t,pv=[m.uci() for m in info.get('pv',())])
   d.write_record(out,report);print(gi,policy,found,[x['move'] for x in row['choices']],row['references'],flush=True)
report['complete']=True;d.write_record(out,report)
