import sys,json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
a=ROOT/'docs/archive/development_activity_games_20261007';a.mkdir(exist_ok=True)
out=ROOT/'docs/research/data/chess_activity_games_20261007.json';assert not out.exists()
groups={};files=[]
for folder,label in [('activity-games-20261007','reference1800'),('activity-stronger-20261007','unlimited')]:
 p=ROOT/'.local_agent'/folder;v=json.loads((p/'games.json').read_bytes());r=json.loads((p/'replay.json').read_bytes());assert v['complete'] and r['complete'] and not r['errors']
 methods={}
 for mode in ('pure','activity'):
  methods[mode]={}
  for policy in ('geometric_half','linear_mixture','unit'):
   rows=[x for x in r['games'] if x['mode']==mode and policy in (x['white'],x['black'])]
   methods[mode][policy]=dict(wins=sum(x['finished'] and x['winner']==(0 if x['white']==policy else 1) for x in rows),losses=sum(x['finished'] and x['winner'] is not None and x['winner']!=(0 if x['white']==policy else 1) for x in rows),draws=sum(x['finished'] and x['winner'] is None for x in rows),unfinished=sum(not x['finished'] for x in rows),local_calls=sum(x['local_calls'] for x in rows),local_wall_seconds=sum(x['local_wall_seconds'] for x in rows),engine_nodes=None if any(x['reported_engine_nodes'] is None for x in rows) else sum(x['reported_engine_nodes'] for x in rows))
  methods[mode]['scope']='Independent time-limited paths; root/color/table match, not deterministic paired causal strength.'
 groups[label]=dict(declaration=v['declaration'],methods=methods,wall_seconds=v['wall_seconds'],recording_cost=v['recording_cost'],replay=dict(streams=len(r['games']),played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0),cells=r['games'])
 files.extend(p/n for n in ('declaration.json','suite.json','games.json','replay.json'))
p=ROOT/'.local_agent/activity-direct-20261007'
v=json.loads((p/'games.json').read_bytes());r=json.loads((p/'replay.json').read_bytes());assert v['complete'] and r['complete'] and not r['errors']
direct={}
for policy in ('geometric_half','linear_mixture','unit'):
 rows=[x for x in r['games'] if x['table']==policy]
 direct[policy]={}
 for mode in ('pure','activity'):
  direct[policy][mode]=dict(wins=sum(x['finished'] and x['winner'] is not None and x['white_leaf_mode' if x['winner']==0 else 'black_leaf_mode']==mode for x in rows),losses=sum(x['finished'] and x['winner'] is not None and x['white_leaf_mode' if x['winner']==0 else 'black_leaf_mode']!=mode for x in rows),draws=sum(x['finished'] and x['winner'] is None for x in rows),unfinished=sum(not x['finished'] for x in rows))
groups['direct']=dict(declaration=v['declaration'],methods=direct,wall_seconds=v['wall_seconds'],recording_cost=v['recording_cost'],replay=dict(streams=len(r['games']),played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0),cells=r['games'])
files.extend(p/n for n in ('declaration.json','suite.json','games.json','replay.json'))
files.append(p/'replay-failure.json')
p=ROOT/'.local_agent/activity-stronger-20261007';roots=json.loads((p/'paired-roots.json').read_bytes());assert roots['complete'];files.append(p/'paired-roots.json')
curve=json.loads((p/'adverse-curve.json').read_bytes());assert curve['complete'];files.append(p/'adverse-curve.json')
paired=[]
for x in roots['rows']:
 row={k:x[k] for k in ('game_index','source_mode','policy','local_side','threshold','played_index','equal_move')}
 row['moves']={r['leaf_mode']:r['move'] for r in x['choices']}
 if x['equal_move']:row['finite_cp_delta']=0;row['interpretation']='same move, no difference'
 else:
  v={k:x['references'][m] for k,m in row['moves'].items()};row['references']=v
  row['finite_cp_delta']=None if any(r['cp'] is None for r in v.values()) else v['activity']['cp']-v['pure']['cp']
  row['interpretation']='finite child score only; mate and cp separately; no WDL certificate'
 paired.append(row)
shogi=ROOT/'.local_agent/activity-games-20261007/shogi-ordering-continuation.json';s=json.loads(shogi.read_bytes());assert s['complete'];files.append(shogi)
files.extend(ROOT/'.local_agent/activity-games-20261007'/n for n in ('shogi-ordering.json','shogi-ordering-failure.json'))
files.append(ROOT/'.local_agent/activity_analysis_plan_20261007.md')
entries={}
with zipfile.ZipFile(a/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  b=f.read_bytes();assert b'C:\\\\Users\\\\wdai' not in b;name=f.relative_to(ROOT/'.local_agent').as_posix();z.writestr(name,b);entries[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(a/'raw.zip') as z:
 for n,h in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==h['sha256']
sources={}
with zipfile.ZipFile(a/'sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ('activity_games_20261007.py','activity_stronger_20261007.py','activity_direct_20261007.py','replay_activity_games_20261007.py','replay_activity_stronger_20261007.py','replay_activity_direct_failed_20261007.py','replay_activity_direct_20261007.py','activity_paired_roots_20261007.py','activity_adverse_curve_20261007.py','shogi_ordering_20261007.py','shogi_ordering_continuation_20261007.py','collect_activity_games_20261007.py'):
  b=(ROOT/'.local_agent'/n).read_bytes();z.writestr(n,b);sources[n]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(a/'sources.zip') as z:
 for n,h in sources.items():assert hashlib.sha256(z.read(n)).hexdigest()==h['sha256']
shogi_rows=[dict(config=x['config'],policy=x['policy'],qdepth=x['qdepth'],selected=x['selected'],score=x['score'],reason=x['reason'],seconds=x['seconds'],evaluations=x['evaluations'],classification=x['classification'],statistics={k:x['statistics'][k] for k in ('nodes','qnodes','completed_depth','runtime_pushes','runtime_pops','runtime_depth_balanced','tt_hits','ordering_seconds')}) for x in s['models']]
report=dict(scope='Fixed optional4-native-unit attack union through unchanged qualified standard Chess search; exposed development, no fitted coefficient, default, Elo or generic-rule strength claim.',prior_build_qualification='docs/research/data/chess_targeted_budget_20261007.json',adverse_resource_curve=curve,groups=groups,paired_roots=paired,paired_sampling_skipped=roots['skipped'],shogi=dict(question=s['question'],resource=s['resource_continuation'],models=shogi_rows),raw_entries=entries,sources=sources,raw_archive=a.relative_to(ROOT).as_posix()+'/raw.zip',sources_archive=a.relative_to(ROOT).as_posix()+'/sources.zip',raw_zip_sha256=hashlib.sha256((a/'raw.zip').read_bytes()).hexdigest(),sources_zip_sha256=hashlib.sha256((a/'sources.zip').read_bytes()).hexdigest(),production_code_changed=False,public_push='held')
write_record(out,report);write_record(a/'index.json',dict(raw_entries=entries,sources=sources,portable_sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
print(json.dumps(dict(groups={k:dict(methods=v['methods'],wall_seconds=v['wall_seconds'],replay=v['replay']) for k,v in groups.items()},paired_roots=paired,shogi=shogi_rows,sha256=hashlib.sha256(out.read_bytes()).hexdigest())))
