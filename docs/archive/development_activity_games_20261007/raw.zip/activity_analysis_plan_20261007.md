# Prospective analysis supplement

Declared while the fixed 24-cell 1sec/1800-setting comparison is running.
Do not alter that comparison or extend any individual game's160-ply cap.

Next condition: one entire existing central-d opening group, three fixed
tables, both colors, pure/activity,1sec local, unlimited Stockfish reference
with50000node/1sec fuse, Threads1/Hash16.12cells, fresh hash each game.
Question: does the optional activity term survive a stronger comparison, or
merely exploit a weak stochastic opponent? Keep losses and unfinished cells;
not calibrated Elo or an independently unexposed population. Maximum960sec
requested local search plus reference and authoritative recording overhead.

Same-root diagnosis, adopted from dot's10:06:35 reply: for each of the twelve
stronger-reference game streams, take the first local-to-move root at/after
subsequent ply16 and at/after32, if it exists and is nonterminal. This is a
fixed sampling rule, not select-the-worst or select-the-largest-difference.
Replay the complete legal prefix/history. On the union, pure and activity
choose under the original table and1sec each. Different selections get a
fresh unlimited500000node/1sec child reference; equal move is no difference.
Report both signs and mate/cp separately; never turn finite cp into exact WDL.
At most24roots/48local seconds and48child reference seconds, plus replay.
No coefficients are fit, no earlier adverse record is overwritten.

If stronger games saturate at all losses, that is valid failure feedback;
inspect the fixed paired-root diagnostics rather than automatically adding
complete games or extending budgets. A separate specific failure may motivate
a prospectively declared symmetric resource curve, not a retroactive rerun.

Separate direct-comparison question (declared before any direct outcomes):
does the candidate outperform the same pure search with the same price table,
rather than only exploiting a third-party opponent? Twelve reciprocal-color
games, same two existing prefixes/three tables/1sec per side/160plies,
Threads1/Hash16. This measures direct development play, not calibrated Elo
or an unexposed holdout. Requested total search upper bound1920sec; no third
engine. It is a separate comparator condition, not a rerun/extension of the
reference cohort. Retain draws/unfinished and both signs, no coefficient fit.

Backup Shogi control after timed games: same reachable19-ply checked root,
same q0/q2 models/2ply/4096node/20sec as retained failure. Compare existing
lexical/noTT against ordering+TT and ordering+TT+orderedq, equally for both
inventory models and q depths. Instrument classification calls/candidate
pushes in an inert lab wrapper, retain immediate-terminal semantics. No new
filter/default or cap increase. At most240sec search plus setup; choose an
existing setting only if actual evidence resolves useful work/cost.
