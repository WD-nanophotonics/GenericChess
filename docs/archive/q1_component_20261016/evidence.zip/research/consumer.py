"""Search-disabled consumer. Run from product source root; pass evidence directory."""
from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=Path(sys.argv[1])if len(sys.argv)>1 else R/'.local_agent/q1-component-20261016'
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.ir import CompiledSemanticRuleset
class Adapter(CompiledSemanticRuleset):
 __slots__=()
 def __getattr__(self,name):return getattr(self._legacy_compiled,name)
 @property
 def semantic(self):return self
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import iter_legal_actions
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine,_module
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from scripts.research_record import record_value
assert Path(nc.__file__).resolve().is_relative_to(R.resolve())
assert Path(_module().__file__).resolve().is_relative_to(R.resolve())
assert Path(compile_legacy_ruleset_for_semantic_execution.__code__.co_filename).resolve().is_relative_to(R.resolve())
def forbidden(*a,**kw):raise AssertionError('Search forbidden in receipt consumer')
SemanticSearchEngine.search=forbidden;_module().semantic_engine_search=forbidden
def read(p):return json.loads((B/p).read_bytes())
def action(d):
 if d is None:return None
 if not d:return PassAction()
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def digest(state):return hashlib.sha256(json.dumps(record_value(state),sort_keys=True).encode()).hexdigest()
cache={};counts=dict(roots=0,queries=0,pv_edges=0,physical_games=0,physical_edges=0,one_reply_receipts=0,selected_choice_edges=0)
def load(root):
 key=str(root)
 if key not in cache:
  d=read('roots/'+key+'.json');raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=Adapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=nc.compile_native_semantic_rules(c);cache[key]=(d,c,nr);counts['roots']+=1
 d,c,nr=cache[key];s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])))
 assert record_value(s.state)==d['state']and digest(s.state)==d['before_sha256']
 return s,nr
def compare(s,nr,state,np,witnesses):
 snap=sem.snapshot(nr,np);exp=expected_snapshot(state.position,nr,s.compiled)
 for k in('board','hands','aux_state','side'):assert record_value(snap[k])==record_value(exp[k])
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(w,s.compiled))for w in witnesses]
 assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
def query(s,nr,r,limit=1000000):
 assert r['nodes']>=0 and r['qnodes']>=0 and r['nodes']+r['qnodes']<=limit
 st=s.state;np=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses)
 chosen=action(r['action']);assert chosen is None or chosen in s.legal_actions()
 line=[action(a)for a in r['principal_variation']];had_pv=bool(line)
 if line:assert line[0]==chosen
 if not line and chosen is not None:line=[chosen]
 for a in line:
  np=sem.make_checked(nr,np,pack_semantic_action(nr,st.position,a));st=apply_action(st,a,s.compiled);w.append(st.position);compare(s,nr,st,np,w);counts['pv_edges']+=int(had_pv);counts['selected_choice_edges']+=int(not had_pv)
 if r.get('immediate_win')and r.get('result_source')=='verified_root_child':assert len(line)==1 and st.terminal_status.winner==s.state.position.side_to_move
 counts['queries']+=1
 return st,np
def requested(r):return r['result_source']=='main_iteration'and r['completed_depth']>=2 and(r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==(4,8)
def win(r):return r['immediate_win']and r['result_source']=='verified_root_child'
def scheduler(s,nr,row,cap=1000000,budget=1.):
 used=0;chosen=None;source=None;mode=row['mode'];phases=row['phases']
 for i,p in enumerate(phases):
  r=p['result'];query(s,nr,r,cap-used);used+=r['nodes']+r['qnodes'];assert used==p['used_total_nodes']
  if i==0:chosen=r;source='q4_initial'if p['q']==4 else'disabled_only'if mode=='q0_only'else'upfront_disabled_initial'
  if win(r):chosen=r;source='physical_win'
  elif requested(r):chosen=r;source='requested_q4'
  elif i==1 and mode=='lazy_backup'and r['result_source']=='main_iteration'and r['completed_depth']>=2 and(r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==(0,0):chosen=r;source='disabled_backup'
  if i==1 and mode=='lazy_backup':
   first=phases[0]['result'];assert first['termination_reason']=='qsearch_check_hard_limit'and not requested(first)and not win(first)and p['q']==0
  if i+1<len(phases):assert not win(r)and not requested(r)
 assert chosen==row['selected']and source==row['selected_source']and used==row['total_nodes']and used<=cap
 if row['execution_allowed']:assert chosen is not None and chosen['action']is not None and not row['cancelled']and row['caller_seconds']<budget

start=time.perf_counter()
prefix=read('d2/prefix-results.json');assert prefix['complete']and not prefix['mismatches'];prefix_index={(x['seed'],x['role'],x['ply']):x for x in prefix['rows']};prefix_seen=set()

def portfolio_scheduler(s,nr,row):
 used=0;chosen=None;source=None
 for i,ph in enumerate(row['phases']):
  assert i<2 and ph['q']==(0 if i==0 else 1)
  r=ph['result'];query(s,nr,r,1000000-used);used+=r['nodes']+r['qnodes'];assert used==ph['used_total_nodes']
  if i==0:chosen=r;source='upfront_disabled_initial';assert r['completed_depth']<=2 and ph['allowance']<=.25
  if win(r):chosen=r;source='physical_win'
  elif r['result_source']=='main_iteration'and r['completed_depth']>=2 and(r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==(1,8):chosen=r;source='requested_q1'
  if i+1<len(row['phases']):assert source not in('physical_win','requested_q1')
 assert used==row['total_nodes']and chosen==row['selected']and source==row['selected_source']
 if row['execution_allowed']:assert chosen['action']is not None and not row['cancelled']and row['caller_seconds']<1.

def physical_game(path,root,case,mode,depth,opponent_q=4):
 out=read(path);assert out['complete'];s,nr=load(root);np=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses)
 for row in out['rows']:
  assert digest(s.state)==row['before_sha256']
  if 'phases'in row:
   if row.get('mode')=='upfront_q1':portfolio_scheduler(s,nr,row)
   else:
    assert len(row['phases'])==1
    ph=row['phases'][0];r=ph['result'];query(s,nr,r);assert row['selected']==r
    assert row['total_nodes']==ph['used_total_nodes']==r['nodes']+r['qnodes']
    q=0 if mode=='q0_control'else int(mode[1])if mode!='q4'and row['actor']==int(mode[-1])else opponent_q
    assert ph['q']==q
    if r['completed_depth']>0:
     assert r['completed_depth']<=depth
     assert r['result_check_hard_qdepth']==(8 if q else 0)
     assert r['result_ordinary_qdepth']==(q if r['completed_depth']>=2 else 0)
    if row['execution_allowed']:assert r['action']is not None and not row['cancelled']and row['caller_seconds']<1.
    key=(int(root),case.get('role',-1),row['ply']) if str(root).isdigit() else None
    if key in prefix_index:
     witness=prefix_index[key];clean=lambda v:{k:x for k,x in v.items()if 'elapsed'not in k}
     assert witness['before_sha256']==digest(s.state)
     assert clean(witness['d2_first'])==clean(witness['upfront_first'])==clean(r)
     query(s,nr,witness['upfront_selected']);prefix_seen.add(key)
  if 'action'not in row:assert not row['execution_allowed'];continue
  assert row['execution_allowed']and row['action']==row['selected']['action'];act=action(row['action'])
  np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,act));s.submit(act);w.append(s.state.position);compare(s,nr,s.state,np,w)
  assert digest(s.state)==row['after_sha256']and record_value(s.result)==row['actual_terminal'];counts['physical_edges']+=1
 assert record_value(s.state)==out['state']and record_value(s.result)==out['result'];counts['physical_games']+=1
d=read('d2/completion.json');assert d['complete']and len(d['games'])==16
for g in d['games']:
 if 'result'in g:physical_game(f"d2/q0d2-{g['seed']}-role{g['role']}.json",g['seed'],g,g['mode'],16)
assert prefix_seen==set(prefix_index)
# Candidate q0 D2 bounds checked separately; opponent remains D16.
for g in d['games']:
 if 'result'not in g:continue
 out=read(f"d2/q0d2-{g['seed']}-role{g['role']}.json")
 for row in out['rows']:
  if row['actor']==g['role']:
   assert row['selected']is None or row['selected']['completed_depth']<=2
noise=read('noise/results.json');plan=read('noise/plan.json')
assert noise['complete']and not noise['mismatches']and len(noise['rows'])+len(noise['missing'])==52
for row in noise['rows']:
 s,nr=load(row['root_id']);assert digest(s.state)==row['before_sha256'];query(s,nr,row['result'],plan['total_nodes'])
 if row['arm']=='counter':
  raw=row['raw'];assert sum(raw[f'noise_visits_{m}_{c}']for m in range(2)for c in range(7))+raw['noise_roots_0']+raw['noise_roots_1']==row['result']['qnodes']
tactical=read('d2/tactical-results.json');assert tactical['complete']and len(tactical['rows'])==24
for row in tactical['rows']:
 s,nr=load('d2-'+str(row['case_index']));assert digest(s.state)==row['case']['before_sha256'];act=action(row['action']);child=apply_action(s.state,act,s.compiled);diag=row['diagnostic'];observed=[]
 for witness in diag['rows']:
  ac=action(witness['action']);after=apply_action(child,ac,s.compiled);assert record_value(after.terminal_status)==witness['terminal'];observed.append(ac);counts['one_reply_receipts']+=1
 if diag.get('complete'):assert set(observed)==set(iter_legal_actions(child,s.compiled))
 if diag.get('winning_reply')is not None:assert apply_action(child,action(diag['winning_reply']),s.compiled).terminal_status.winner==child.position.side_to_move

pilot=read('check-layer-results.json');assert pilot['complete']and len(pilot['rows'])+len(pilot['missing'])==104
for row in pilot['rows']:
 s,nr=load(row['root_id']);assert digest(s.state)==row['before_sha256'];query(s,nr,row['result'],row['budget']['nodes'])
 if row['arm']=='check_layer':assert 'NOT original q4'in row['objective']
done_diag=set()
for row in pilot['rows']:
 key=row['diagnostic_key']
 if key in done_diag:continue
 done_diag.add(key);s,nr=load(row['root_id']);child=apply_action(s.state,action(row['result']['action']),s.compiled);diag=pilot['diagnostics'][key];observed=[]
 for witness in diag.get('rows',[]):
  ac=action(witness['action']);after=apply_action(child,ac,s.compiled);assert record_value(after.terminal_status)==witness['terminal'];observed.append(ac);counts['one_reply_receipts']+=1
 if diag.get('complete'):assert set(observed)==set(iter_legal_actions(child,s.compiled))
 if diag.get('winning_reply')is not None:assert apply_action(child,action(diag['winning_reply']),s.compiled).terminal_status.winner==child.position.side_to_move
reserve=read('reserve-control-results.json');assert reserve['complete']and len(reserve['rows'])==26 and not reserve['non_time_mismatches']
for row in reserve['rows']:
 s,nr=load(row['root_id']);query(s,nr,row['result'],65536)
for row in pilot['actual_timer_cancellations']:
 s,nr=load(row['root_id']);query(s,nr,row['result']);assert row['token_cancelled']and row['root_restored']and row['result']['termination_reason']=='cancelled'
if (B/'completion.json').exists():
 done=read('completion.json');assert done['complete']and len(done['games'])==45
 for g in done['games']:
  if 'result'in g:physical_game(f"game-{g['seed']}-{g['mode']}.json",g['seed'],g,g['mode'],16)

if (B/'check-games-completion.json').exists():
 check=read('check-games-completion.json');assert check['complete']and len(check['games'])==18
 for g in check['games']:
  if 'result'in g:
   path=f"checkgame-{g['seed']}-role{g['role']}.json";out=read(path)
   for row in out['rows']:
    if row['actor']==g['role']:assert 'NOT original' in row['objective']
   physical_game(path,g['seed'],g,f"q4_role{g['role']}",16)

budget=read('budget-results.json');bp=read('budget-plan.json');assert budget['complete']and len(budget['rows'])==bp['planned_queries']
for row in budget['rows']:
 s,nr=load(row['root_id']);assert digest(s.state)==row['case']['before_sha256'];st,np=query(s,nr,row['result'])
 assert row['constructor_seconds']>=0 and row['pack_seconds']>=0 and row['backend_call_seconds']>=row['raw_elapsed_seconds']
 if row['result']['principal_variation']:assert record_value(sem.dynamic_features(nr,np))==row['result']['dynamic_features']
 else:assert row['result']['dynamic_features']==[]
if(B/'transfer/completion.json').exists():
 transfer=read('transfer/completion.json');assert transfer['complete']and len(transfer['games'])==18
 for g in transfer['games']:
  if'result'in g:physical_game(f"transfer/game-{g['seed']}-{g['mode']}.json",g['seed'],g,g['mode'],16,opponent_q=0)

tt=read('transfer/tactical-results.json');assert tt['complete']and tt['planned_pairs']==12
for row in tt['rows']:
 s,nr=load(row['root_id']);assert digest(s.state)==row['case']['before_sha256'];diag=tt['diagnostics'][row['diagnostic_key']]
 if row['action']is None:assert diag['kind']=='NO_ACTION';continue
 child=apply_action(s.state,action(row['action']),s.compiled);observed=[]
 for witness in diag.get('rows',[]):
  ac=action(witness['action']);after=apply_action(child,ac,s.compiled);assert record_value(after.terminal_status)==witness['terminal'];observed.append(ac);counts['one_reply_receipts']+=1
 if diag.get('complete'):assert set(observed)==set(iter_legal_actions(child,s.compiled))
 if diag.get('winning_reply')is not None:assert apply_action(child,action(diag['winning_reply']),s.compiled).terminal_status.winner==child.position.side_to_move
pp=read('transfer/portfolio-probe-results.json');assert pp['complete']and len(pp['rows'])==16
for row in pp['rows']:
 s,nr=load(row['root_id']);assert digest(s.state)==row['before_sha256'];portfolio_scheduler(s,nr,row)

probe_seen=set()
for row in pp['rows']:
 key=row['diagnostic_key']
 if key in probe_seen:continue
 probe_seen.add(key);s,nr=load(row['root_id']);diag=pp['diagnostics'][key]
 if row['selected']is None or row['selected']['action']is None:assert diag['kind']=='NO_ACTION';continue
 child=apply_action(s.state,action(row['selected']['action']),s.compiled);observed=[]
 for witness in diag.get('rows',[]):
  ac=action(witness['action']);after=apply_action(child,ac,s.compiled);assert record_value(after.terminal_status)==witness['terminal'];observed.append(ac);counts['one_reply_receipts']+=1
 if diag.get('complete'):assert set(observed)==set(iter_legal_actions(child,s.compiled))
 if diag.get('winning_reply')is not None:assert apply_action(child,action(diag['winning_reply']),s.compiled).terminal_status.winner==child.position.side_to_move
pc=read('transfer/portfolio-controls.json');assert pc['complete']and len(pc['logic_checks'])==7 and all(x['passed']for x in pc['logic_checks'])
for row in pc['actual_timer_cancellations']:
 s,nr=load(row['case_index']);portfolio_scheduler(s,nr,row['row']);assert row['row']['cancelled']and not row['row']['execution_allowed']
if(B/'transfer/portfolio-completion.json').exists():
 done=read('transfer/portfolio-completion.json');assert done['complete']and len(done['games'])==12
 for g in done['games']:
  if'result'in g:physical_game(f"transfer/portfolio-{g['seed']}-role{g['role']}.json",g['seed'],g,f"q0_role{g['role']}",16,opponent_q=0)

clean=lambda r:{k:v for k,v in r.items()if 'elapsed'not in k}
for root in {r['root_id']for r in noise['rows']}:
 for order in[0,1]:
  pair=[r['result']for r in noise['rows']if r['root_id']==root and r['order']==order]
  assert len(pair)==2 and clean(pair[0])==clean(pair[1])
for root in {r['root_id']for r in reserve['rows']}:
 pair=[r['result']for r in reserve['rows']if r['root_id']==root];assert len(pair)==2 and clean(pair[0])==clean(pair[1])
ret=read('return-cost-replay.json');assert ret['complete']and ret['search_disabled']and len(ret['rows'])==12
for row in ret['rows']:
 b=next(r for r in budget['rows']if r['root_id']==row['root_id']and r['order']==row['order']and r['mode']==row['mode'])
 assert row['features']==b['result']['dynamic_features']and row['dynamic_features_seconds']>=0 and row['checked_native_edges_seconds']>=0
result=dict(complete=True,unique_root_states=len({d['before_sha256']for d,c,nr in cache.values()}),**counts,seconds=time.perf_counter()-start,search_disabled=True,scope='Actual Core and checked Native full physical/PV/history replay plus literal one-reply enumeration. Shared compiler/host, not independent rules/WDL or new search execution.')
(B/'consumer-replay.json').write_bytes(json.dumps(result,indent=2).encode());print('CONSUMER_PASS',result,flush=True)
