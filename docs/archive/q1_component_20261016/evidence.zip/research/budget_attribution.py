from pathlib import Path
import json,sys,time,hashlib
R=Path.cwd();P=R/'.local_agent/q1-component-20261016';sys.path[:0]=[str(R),str(P),str(R/'.local_agent/residual-q4-20261016')]
import games as g
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native import semantic_engine as se
p=g.p;a=g.a
done=json.loads((P/'check-games-completion.json').read_bytes());assert done['complete'];cases={}
for meta in done['games']:
 if'result'not in meta:continue
 out=json.loads((P/f"checkgame-{meta['seed']}-role{meta['role']}.json").read_bytes())
 for i,row in enumerate(out['rows']):
  if not row['execution_allowed']:cases.setdefault(row['before_sha256'],dict(seed=meta['seed'],n=meta['n'],role=meta['role'],ply=i,before_sha256=row['before_sha256']))
plan=dict(question='What pipeline work exceeds the20ms reserve on ALL completed changed-layer batch refusal states, and does a larger reserve merely hide or address that observed overhead?',selection='ALL4 refusal events from sealed18game batch, dedup2exact fullstates; no payoff filtering. Original UNKNOWN/caps sealed, no game continuation/retry.',cases=list(cases.values()),modes=['margin02','margin05','zero_native'],orders=[['margin02','margin05','zero_native'],['zero_native','margin05','margin02']],planned_queries=len(cases)*6,whole_seconds=120,expected_seconds=12,nodes=1000000,max_depth=16,ordinary_q=4,hard_q=8,scope='Private timing wrappers around real pack/backend call; no product source or PV/history removal. Nativecall wall includes its admission; backend elapsed differs. Timers perturb runtime slightly; no instruction-exact or universal deadline guarantee.',decision='Identify dominant measured pre/post/backend-admission overhead for a concrete next improvement. Larger-margin result only checks these states, not a new default or rerun of games. Source-only evidence replay validates records without new searches.')
a.write_record(P/'budget-plan.json',plan)
orig_pack=se.pack_semantic_search_position;orig_call=p.m.semantic_engine_search;timing={}
def pack(*args,**kw):
 t=time.perf_counter()
 try:return orig_pack(*args,**kw)
 finally:timing['pack_seconds']=timing.get('pack_seconds',0)+time.perf_counter()-t
def call(*args,**kw):
 t=time.perf_counter()
 try:
  raw=orig_call(*args,**kw);timing['raw_elapsed_seconds']=raw['elapsed_nanoseconds']/1e9;return raw
 finally:timing['backend_call_seconds']=timing.get('backend_call_seconds',0)+time.perf_counter()-t
se.pack_semantic_search_position=pack;p.m.semantic_engine_search=call
rows=[];start=time.perf_counter()
try:
 for ci,case in enumerate(plan['cases']):
  s,nr,d=g.load(case['seed']);old=json.loads((P/f"checkgame-{case['seed']}-role{case['role']}.json").read_bytes())
  for row in old['rows'][:case['ply']]:
   assert p.digest(s)==row['before_sha256'];s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==row['action']))
  assert p.digest(s)==case['before_sha256'];a.write_record(P/'roots'/f'budget-{ci}.json',dict(ruleset=d['ruleset'],game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s)))
  for order,modes in enumerate(plan['orders']):
   for mode in modes:
    p.stopped();assert time.perf_counter()-start<120;timing.clear();token=a.CancellationToken();t=time.perf_counter();e=a.SemanticSearchEngine(s.compiled,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False);ctor=time.perf_counter()-t;allowance=0 if mode=='zero_native'else max(0,1.-(time.perf_counter()-t)-(.02 if mode=='margin02'else .05))
    st=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=16,max_nodes=1000000,max_time_seconds=allowance,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True,stop_on_immediate_win=True);sw=time.perf_counter()-st;st=time.perf_counter();rec=a.record_value(r);ser=time.perf_counter()-st;total=time.perf_counter()-t
    row=dict(root_id=f'budget-{ci}',case=case,order=order,mode=mode,allowance=allowance,constructor_seconds=ctor,search_wrapper_seconds=sw,serialization_seconds=ser,actual_caller_seconds=total,execution_allowed=r.action is not None and not token.is_cancelled()and total<1.,result=rec,**timing)
    row['wrapper_other_seconds']=sw-row['pack_seconds']-row['backend_call_seconds'];row['backend_outside_reported_elapsed']=row['backend_call_seconds']-row['raw_elapsed_seconds'];row['pv_edges']=a.audit(s,nr,r);assert p.digest(s)==case['before_sha256'];rows.append(row);print(row['root_id'],mode,round(total,6),round(row['pack_seconds'],6),round(row['wrapper_other_seconds'],6),r.termination_reason,row['execution_allowed'],flush=True)
finally:se.pack_semantic_search_position=orig_pack;p.m.semantic_engine_search=orig_call
a.write_record(P/'budget-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('BUDGET_CLOSED',len(rows),time.perf_counter()-start,flush=True)
