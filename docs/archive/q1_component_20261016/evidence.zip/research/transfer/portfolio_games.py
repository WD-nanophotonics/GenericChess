from pathlib import Path
import json,sys,time,hashlib
R=Path.cwd();T=R/'.local_agent/q1-transfer-20261016';sys.path[:0]=[str(R),str(T),str(R/'.local_agent/residual-q4-20261016')]
import games as g
import portfolio as p
a=g.a
plan=json.loads((T/'portfolio-plan.json').read_bytes());probe=json.loads((T/'portfolio-probe-results.json').read_bytes());assert probe['complete']and all(r['reserve_complete']for r in probe['rows'])
critical=[r for r in probe['rows']if r['case']['seed']==8631 and r['case']['role']==1];assert len(critical)==2 and all(r['selected_matches_stored_q0']for r in critical)
assert json.loads((T/'portfolio-controls.json').read_bytes())['complete']
a.write_record(T/'portfolio-games-binding.json',dict(plan_sha256=hashlib.sha256((T/'portfolio-plan.json').read_bytes()).hexdigest(),scheduler_sha256=hashlib.sha256((T/'portfolio.py').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),probe_sha256=hashlib.sha256((T/'portfolio-probe-results.json').read_bytes()).hexdigest(),games_started=0,criterion='All16 reserve probes completeD2; both critical time-first calls retain storedq0 action. This is mechanism evidence, not a game win claim.'))
start=time.perf_counter();games=[]
for case in plan['inputs']:
 for role in plan['orders'][case['seed']%2]:
  g.p.stopped()
  if time.perf_counter()-start>=plan['whole_seconds']:games.append(dict(**case,role=role,kind='NOT_STARTED_WHOLE_CAP_UNKNOWN'));continue
  s,nr,d=g.load(case['seed']);t=time.perf_counter();rows=[];kind=None;token=a.CancellationToken();path=T/f"portfolio-{case['seed']}-role{role}.json"
  for ply in range(plan['horizon']):
   g.p.stopped()
   if s.result.status.value!='ongoing':kind='ACTUAL_RULE_TERMINAL';break
   if time.perf_counter()-start>=plan['whole_seconds']:kind='WHOLE_CAP_UNKNOWN';break
   if time.perf_counter()-t>=plan['game_seconds']:kind='GAME_CAP_UNKNOWN';break
   actor=s.state.position.side_to_move;before=g.p.digest(s);outer=time.perf_counter()
   if actor==role:row,r,objs=p.schedule(s,nr,d['board_values'],d['hand_values'],token=token);owner='upfront_q1'
   else:row,r=g.schedule(s,nr,d['board_values'],d['hand_values'],0,token);row['mode']='q0_only';owner='fixed_q0'
   row.update(actual_call_seconds=time.perf_counter()-outer,ply=ply,actor=actor,owner=owner,before_sha256=before)
   if not row['execution_allowed']:rows.append(row);kind='CALLER_NO_ACTION_UNKNOWN';break
   ac=r.action;row['action']=a.record_value(ac);at=time.perf_counter();g.physical(s,nr,ac);row.update(after_sha256=g.p.digest(s),actual_terminal=a.record_value(s.result),physical_audit_seconds=time.perf_counter()-at);rows.append(row);a.write_record(path.with_name(path.stem+'-partial.json'),dict(complete=False,case=case,role=role,rows=rows,seconds=time.perf_counter()-t))
  kind=kind or('ACTUAL_RULE_TERMINAL'if s.result.status.value!='ongoing'else'PLY_CAP_UNKNOWN')
  out=dict(complete=True,case=case,role=role,mode=f'upfrontq1_role{role}',rows=rows,kind=kind,result=a.record_value(s.result),state=a.record_value(s.state),seconds=time.perf_counter()-t);a.write_record(path,out);games.append(dict(**case,role=role,kind=kind,result=out['result'],edges=sum('action'in r for r in rows),seconds=out['seconds']));a.write_record(T/'portfolio-completion-partial.json',dict(complete=False,games=games,seconds=time.perf_counter()-start));print('PORTFOLIO_GAME',case,role,kind,len(rows),out['result']['status'],out['result']['winner'],round(out['seconds'],3),flush=True)
a.write_record(T/'portfolio-completion.json',dict(complete=True,games=games,seconds=time.perf_counter()-start));print('PORTFOLIO_CLOSED',len(games),time.perf_counter()-start,flush=True)
