from pathlib import Path
import json,sys,time
R=Path.cwd();T=R/'.local_agent/q1-transfer-20261016';sys.path[:0]=[str(R),str(T),str(R/'.local_agent/residual-q4-20261016')]
import games as g
from generic_chess.session.serialization import serialize_game_record
p=g.p;a=g.a
plan=dict(question='At ALL first q1/fixedq0 transfer action divergences, is there a literal immediate winning reply difference?',selection='ALL12method/role comparisons from frozen6families, no outcome filtering. Deduplicate identical fullparents/actions only; preserve noncandidate actor/time differences.',max_pairs=12,max_diagnostics=24,per_diagnostic_seconds=a.plan['diagnostic_seconds'],whole_seconds=120,scope='Exact one-reply Core enumeration on saved states; no new search/solver/continuation/cap extension. Absence of a reply win is not safety/WDL.',decision='Use actual literal witnesses if any; otherwise leave deeper finite-policy mechanisms unresolved and prepare a bounded next contrast rather than invent an explanation.')
a.write_record(T/'tactical-plan.json',plan)
if __name__=='__main__':
 done=json.loads((T/'completion.json').read_bytes());assert done['complete'];rows=[];cache={};pairs=[];start=time.perf_counter()
 for case in json.loads((T/'plan.json').read_bytes())['inputs']:
  seed=case['seed'];base=T/f'game-{seed}-q0_control.json'
  if not base.exists():continue
  b=json.loads(base.read_bytes())
  for role in[0,1]:
   vf=T/f'game-{seed}-q1_role{role}.json'
   if not vf.exists():continue
   v=json.loads(vf.read_bytes());s,nr,d=g.load(seed)
   for br,vr in zip(b['rows'],v['rows']):
    assert br['before_sha256']==vr['before_sha256']==p.digest(s)
    if br.get('action')!=vr.get('action'):
     index=len(pairs);root='transfer-div-'+str(index);pairs.append(dict(**case,role=role,root_id=root,ply=br['ply'],actor=br['actor'],is_candidate_actor=br['actor']==role,before_sha256=p.digest(s)))
     a.write_record(T/'roots'/f'{root}.json',dict(ruleset=d['ruleset'],game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s)))
     for arm,row in[('q0_control',br),('q1_candidate',vr)]:
      p.stopped();key=p.digest(s)+':'+repr(row.get('action'))
      if key not in cache:
       if time.perf_counter()-start>=120:cache[key]=dict(kind='WHOLE_CAP_UNKNOWN',rows=[],complete=False)
       else:ac=None if row.get('action')is None else next(ac for ac in s.legal_actions()if a.record_value(ac)==row['action']);cache[key]=a.diagnosis(s,ac)
      rows.append(dict(root_id=root,case=pairs[-1],arm=arm,action=row.get('action'),diagnostic_key=key))
     break
    if'action'not in br:break
    s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==br['action']))
 a.write_record(T/'tactical-results.json',dict(complete=True,planned_pairs=12,actual_divergence_pairs=len(pairs),pairs=pairs,rows=rows,diagnostics=cache,seconds=time.perf_counter()-start));print('TRANSFER_TACTICAL',len(pairs),len(cache),[d['kind']for d in cache.values()],flush=True)
