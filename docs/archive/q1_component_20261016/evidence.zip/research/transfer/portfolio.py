from pathlib import Path
import sys,time,json
R=Path.cwd();T=R/'.local_agent/q1-transfer-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
from probe import a,physical
def requested(r):return r is not None and r.result_source=='main_iteration'and r.completed_depth>=2 and(r.result_ordinary_qdepth,r.result_check_hard_qdepth)==(1,8)
def schedule(s,nr,bv,hv,*,token=None,clock=time.perf_counter,factory=a.SemanticSearchEngine,after_phase=None):
 token=token or a.CancellationToken();start=clock();deadline=start+1.;used=0;phases=[];objects=[];selected=None;source=None;selected_index=None
 for i,q in enumerate([0,1]):
  if token.is_cancelled()or deadline-clock()<=.05 or used>=1000000:break
  pt=clock();engine=factory(s.compiled,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);allowance=deadline-clock()-.05
  if i==0:allowance=min(allowance,.25-(clock()-pt))
  if allowance<=0:break
  r=engine.search(s,a.SearchLimits(max_depth=2 if i==0 else 16,max_nodes=1000000-used,max_time_seconds=allowance,quiescence_max_depth=q,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True,stop_on_immediate_win=True)
  used+=r.nodes+r.qnodes;objects.append(r);rec=a.record_value(r);phases.append(dict(q=q,result=rec,allowance=allowance,used_total_nodes=used,phase_seconds=clock()-pt))
  if i==0:selected=r;selected_index=i;source='upfront_disabled_initial'
  if physical(r):selected=r;selected_index=i;source='physical_win'
  elif requested(r):selected=r;selected_index=i;source='requested_q1'
  if after_phase:after_phase(i,r,token)
  if physical(r)or requested(r)or token.is_cancelled()or clock()>=deadline:break
 out=dict(mode='upfront_q1',phases=phases,selected=None if selected_index is None else phases[selected_index]['result'],selected_source=source,total_nodes=used,cancelled=token.is_cancelled())
 out['caller_seconds']=clock()-start;out['execution_allowed']=selected is not None and selected.action is not None and not token.is_cancelled()and clock()<deadline;out['overrun_seconds']=max(0,out['caller_seconds']-1.)
 return out,selected,objects
