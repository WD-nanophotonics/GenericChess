from pathlib import Path
from collections import Counter
import json,random
P=Path('.local_agent/q1-transfer-20261016')
read=lambda f:json.loads((P/f).read_bytes())
done=read('completion.json');plan=read('plan.json');assert done['complete']and len(done['games'])==18
pay={'WIN':1,'LOSS':-1,'DRAW':0,'UNKNOWN':0}
def status(g,role):
 r=g.get('result');return 'UNKNOWN'if not r or r['status']=='ongoing'else 'DRAW'if r['winner']is None else 'WIN'if r['winner']==role else'LOSS'
bc=Counter();cc=Counter();tr=Counter();pairs=[];families=[];cost=0;calls=[];refusals=[]
for case in plan['inputs']:
 seed=case['seed'];bm=next(g for g in done['games']if g['seed']==seed and g['mode']=='q0_control');fd=0
 for role in[0,1]:
  cm=next(g for g in done['games']if g['seed']==seed and g['mode']==f'q1_role{role}');bs=status(bm,role);cs=status(cm,role);bc[bs]+=1;cc[cs]+=1;tr[bs+'->'+cs]+=1;delta=pay[cs]-pay[bs];fd+=delta
  pair=dict(**case,role=role,baseline=bs,candidate=cs,finite_event_delta=delta,baseline_kind=bm['kind'],candidate_kind=cm['kind'],candidate_seconds=cm.get('seconds'),baseline_seconds=bm.get('seconds'))
  if'result'in cm:
   cg=read(f'game-{seed}-q1_role{role}.json');cost+=cg['seconds'];calls.extend(cg['rows'])
   for row in cg['rows']:
    if not row['execution_allowed']:refusals.append(dict(seed=seed,role=role,actor=row['actor'],is_candidate_actor=row['actor']==role,owner=row['owner'],ply=row['ply'],actual_call_seconds=row['actual_call_seconds']))
   if'result'in bm:
    bg=read(f'game-{seed}-q0_control.json')
    for b,c in zip(bg['rows'],cg['rows']):
     if b['before_sha256']!=c['before_sha256']:break
     if b.get('action')!=c.get('action'):pair['first_difference']=dict(ply=c['ply'],actor=c['actor'],is_candidate_actor=c['actor']==role,before_sha256=c['before_sha256'],baseline_action=b.get('action'),candidate_action=c.get('action'));break
  pairs.append(pair)
 families.append(fd/2)
rng=random.Random(20261016);v=sorted(sum(rng.choice(families)for _ in families)/len(families)for __ in range(5000))
out=dict(complete=True,question=plan['question'],planned_games=18,actual_games=sum('result'in g for g in done['games']),missing=[g for g in done['games']if'result'not in g],physical_edges=sum(g.get('edges',0)for g in done['games']),batch_seconds=done['seconds'],baseline_counts={k:bc[k]for k in pay},candidate_counts={k:cc[k]for k in pay},transitions=dict(tr),finite_event_net_delta=sum(p['finite_event_delta']for p in pairs),mean_delta_per_role=sum(families)/len(families),family_bootstrap95=[v[int(.025*4999)],v[int(.975*4999)]],candidate_game_seconds=cost,refusals=refusals,queries=sum(len(r['phases'])for r in calls),phase_reasons=dict(Counter(ph['result']['termination_reason']for row in calls for ph in row['phases'])),pairs=pairs,scope='Fresh6 balanced-size families; q1 vs fixedq0D16, identical global50msreserve allarms. Not old20ms study rerun/pooled interval or optimalWDL/population/default/price claim. UNKNOWN separate; bothroles resampledtogether, controls physicallyonce/family.',by_board=[dict(n=n,baseline_counts=dict(Counter(p['baseline']for p in pairs if p['n']==n)),candidate_counts=dict(Counter(p['candidate']for p in pairs if p['n']==n)),finite_event_net_delta=sum(p['finite_event_delta']for p in pairs if p['n']==n))for n in[8,12,16]])
(P/'summary.json').write_bytes(json.dumps(out,indent=2).encode());print('TRANSFER_SUMMARY',json.dumps({k:v for k,v in out.items()if k not in('pairs',)},indent=2))
