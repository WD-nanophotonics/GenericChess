from pathlib import Path
import sys,json,threading
from dataclasses import dataclass
from types import SimpleNamespace
R=Path.cwd();T=R/'.local_agent/q1-transfer-20261016';sys.path[:0]=[str(R),str(T),str(R/'.local_agent/residual-q4-20261016')]
import portfolio as p
import probe as old
@dataclass
class Result:
 action:str|None='A'
 completed_depth:int=2
 result_source:str='main_iteration'
 result_ordinary_qdepth:int=0
 result_check_hard_qdepth:int=0
 immediate_win:bool=False
 termination_reason:str='completed'
 nodes:int=10
 qnodes:int=0
 score:int=999999
class Clock:
 def __init__(self):self.t=0.
 def __call__(self):return self.t
checks=[]
def run(label,results,after=None,dt=.1):
 clock=Clock();limits=[]
 class Engine:
  def __init__(self,*args,**kw):pass
  def search(self,s,lim,**kw):limits.append(lim);clock.t+=dt;return results[len(limits)-1]
 row,r,obs=p.schedule(SimpleNamespace(compiled=None),None,{}, {},clock=clock,factory=Engine,after_phase=after);checks.append(dict(label=label,row=row,passed=True));return row,r,limits
row,r,ls=run('retain_D2_when_q1_timefirst_unrequested',[Result(),Result(action='B',completed_depth=1,result_check_hard_qdepth=8,termination_reason='time_budget')]);assert r.action=='A'and len(ls)==2
row,r,ls=run('requested_q1_overrides_without_scorecomparison',[Result(),Result(action='B',result_ordinary_qdepth=1,result_check_hard_qdepth=8,score=-999999)]);assert r.action=='B'and row['selected_source']=='requested_q1'
row,r,ls=run('D0_physical_win_priority',[Result(completed_depth=0,result_source='verified_root_child',immediate_win=True)]);assert len(ls)==1 and row['selected_source']=='physical_win'
row,r,ls=run('cancel_between_phases_forbids_action',[Result()],after=lambda i,r,t:t.cancel());assert len(ls)==1 and row['cancelled']and not row['execution_allowed']
row,r,ls=run('actual_outer_expiry_forbids_action',[Result()],dt=1.2);assert len(ls)==1 and not row['execution_allowed']
row,r,ls=run('main_plus_q_exhaustion_stops',[Result(nodes=400000,qnodes=600000)]);assert len(ls)==1 and row['total_nodes']==1000000
row,r,ls=run('main_plus_q_remaining_deducted',[Result(nodes=400000,qnodes=599990),Result(action='B',result_ordinary_qdepth=1,result_check_hard_qdepth=8,nodes=5,score=-999999)]);assert ls[1].max_nodes==10 and row['total_nodes']==999995
native=[]
for ci in[0,1]:
 s,nr,bv,hv=old.load(ci);before=old.digest(s);token=p.a.CancellationToken();timer=threading.Timer(.02,token.cancel);timer.start()
 try:row,r,objs=p.schedule(s,nr,bv,hv,token=token)
 finally:timer.cancel();timer.join()
 assert row['cancelled']and not row['execution_allowed']and old.digest(s)==before
 native.append(dict(case_index=ci,row=row,pv_edges=[p.a.audit(s,nr,r)for r in objs]))
p.a.write_record(T/'portfolio-controls.json',dict(complete=True,logic_checks=checks,actual_timer_cancellations=native,scope='Seven deterministic orchestration controls, including synthetic fault node counts, plus two real20msNative cancellations. No instruction-exact injection or full product rerun.'))
print('PORTFOLIO_CONTROLS',len(checks),len(native),flush=True)
