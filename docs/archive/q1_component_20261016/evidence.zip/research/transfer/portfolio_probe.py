from pathlib import Path
import json,sys,time
R=Path.cwd();T=R/'.local_agent/q1-transfer-20261016';sys.path[:0]=[str(R),str(T),str(R/'.local_agent/residual-q4-20261016')]
import games as g
import portfolio as p
from generic_chess.session.serialization import deserialize_game_record
a=g.a
cases=json.loads((T/'tactical-results.json').read_bytes())['pairs'];plan=dict(question='Can the preexisting.25sD2 reserve protect ALL observed q1/q0 first divergences before time exhaustion?',cases=cases,orders=[0,1],planned_callers=len(cases)*2,whole_seconds=120,expected_seconds=30,scope='All8 exposed first divergences, no outcome filter; common1s/50msreserve/sharedmain+q1M. Different finiteq objectives never score-compared. Not independent utility evidence or oldcap extension.')
a.write_record(T/'portfolio-probe-plan.json',plan);start=time.perf_counter();rows=[];diags={}
for case in cases:
 s,nr,d=g.load(case['seed']);root=json.loads((T/'roots'/f"{case['root_id']}.json").read_bytes());s=a.GameSession.replay(s.compiled,deserialize_game_record(json.dumps(root['game_record'])));assert g.p.digest(s)==case['before_sha256']
 old=json.loads((T/f"game-{case['seed']}-q0_control.json").read_bytes())['rows'][case['ply']]
 for order in[0,1]:
  g.p.stopped();assert time.perf_counter()-start<120
  outer=time.perf_counter();row,r,objs=p.schedule(s,nr,d['board_values'],d['hand_values']);row.update(actual_call_seconds=time.perf_counter()-outer,root_id=case['root_id'],case=case,order=order,before_sha256=g.p.digest(s),phase_pv_edges=[a.audit(s,nr,x)for x in objs],reserve_complete=bool(objs and objs[0].completed_depth>=2),selected_matches_stored_q0=None if r is None else a.record_value(r.action)==old.get('action'))
  key=case['root_id']+':'+repr(None if r is None else r.action)
  if key not in diags:diags[key]=a.diagnosis(s,None if r is None else r.action)
  row['diagnostic_key']=key;rows.append(row);assert row['total_nodes']<=1000000 and g.p.digest(s)==case['before_sha256'];print(case['seed'],case['role'],case['ply'],order,row['selected_source'],row['reserve_complete'],row['selected_matches_stored_q0'],diags[key]['kind'],flush=True)
a.write_record(T/'portfolio-probe-results.json',dict(complete=True,rows=rows,diagnostics=diags,seconds=time.perf_counter()-start));print('PROBE_CLOSED',len(rows),time.perf_counter()-start,flush=True)
