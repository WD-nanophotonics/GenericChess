from pathlib import Path
from collections import Counter
import json,random
T=Path('.local_agent/q1-transfer-20261016');read=lambda f:json.loads((T/f).read_bytes())
d=read('portfolio-completion.json');base=read('completion.json');plan=read('portfolio-plan.json');assert d['complete']and len(d['games'])==12
pay={'WIN':1,'LOSS':-1,'DRAW':0,'UNKNOWN':0}
def status(g,role):
 r=g.get('result');return'UNKNOWN'if not r or r['status']=='ongoing'else'DRAW'if r['winner']is None else'WIN'if r['winner']==role else'LOSS'
bc=Counter();cc=Counter();tr=Counter();qtr=Counter();pairs=[];families=[];cost=0;calls=[];refusals=[]
for case in plan['inputs']:
 fd=0
 for role in[0,1]:
  b=next(x for x in base['games']if x['seed']==case['seed']and x['mode']=='q0_control');q=next(x for x in base['games']if x['seed']==case['seed']and x['mode']==f'q1_role{role}');v=next(x for x in d['games']if x['seed']==case['seed']and x['role']==role);bs=status(b,role);qs=status(q,role);vs=status(v,role);bc[bs]+=1;cc[vs]+=1;tr[bs+'->'+vs]+=1;qtr[qs+'->'+vs]+=1;delta=pay[vs]-pay[bs];fd+=delta;pair=dict(**case,role=role,baseline=bs,q1=qs,portfolio=vs,finite_delta=delta,portfolio_minus_q1=pay[vs]-pay[qs],candidate_seconds=v.get('seconds'),candidate_kind=v['kind']);pairs.append(pair)
  if'result'in v:
   g=read(f"portfolio-{case['seed']}-role{role}.json");cost+=g['seconds'];calls.extend(g['rows'])
   for r in g['rows']:
    if not r['execution_allowed']:refusals.append(dict(seed=case['seed'],role=role,actor=r['actor'],is_candidate_actor=r['actor']==role,ply=r['ply'],seconds=r['actual_call_seconds']))
 families.append(fd/2)
rng=random.Random(20261016);v=sorted(sum(rng.choice(families)for _ in families)/len(families)for __ in range(5000));ph=[p for r in calls for p in r['phases']]
out=dict(complete=True,planned_games=12,actual_games=sum('result'in g for g in d['games']),missing=[g for g in d['games']if'result'not in g],physical_edges=sum(g.get('edges',0)for g in d['games']),batch_seconds=d['seconds'],baseline_counts={k:bc[k]for k in pay},candidate_counts={k:cc[k]for k in pay},transitions=dict(tr),q1_to_portfolio=dict(qtr),finite_net_delta=sum(p['finite_delta']for p in pairs),portfolio_minus_q1_net=sum(p['portfolio_minus_q1']for p in pairs),family_bootstrap95=[v[int(.025*4999)],v[int(.975*4999)]],actual_game_seconds=cost,phase_queries=len(ph),selected_sources=dict(Counter(r['selected_source']for r in calls)),phase_reasons=dict(Counter(p['result']['termination_reason']for p in ph)),refusals=refusals,pairs=pairs,scope='POSTHOC exposed6families/bothroles; fixedq0 controls reused from fresh transfer. Original .25sD2 reserve retained, q1 qualified policy overrides regardlessnumeric score; common50msreserve/shared1s1M. No independent validation/default/WDL or cap extension.')
(T/'portfolio-summary.json').write_bytes(json.dumps(out,indent=2).encode());print('PORTFOLIO_SUMMARY',json.dumps({k:v for k,v in out.items()if k!='pairs'},indent=2))
