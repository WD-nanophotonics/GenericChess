from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/q1-component-20261016';O=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(O)]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;plan=json.loads((P/'check-layer-plan.json').read_bytes());spec=importlib.util.spec_from_file_location('check_layer_reserve._native_core',P/'check_layer_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);rows=[];mismatches=[];start=time.perf_counter()
for parent in plan['parents']:
 d=json.loads((O/'roots'/f"{parent['root_id']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])))
 for name,mod in[('normal',p.m),('check_layer',m)]:
  p.stopped();assert time.perf_counter()-start<120;nr=a.nc.compile_native_semantic_rules(c,backend_module=mod);e=a.SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False);r=e.search(s,a.SearchLimits(max_depth=1,max_nodes=65536,max_time_seconds=6,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True);rows.append(dict(root_id=parent['root_id'],arm=name,result=a.record_value(r),pv_edges=a.audit(s,nr,r)));assert p.digest(s)==parent['before_sha256']
 pair=rows[-2:];v=[{k:x for k,x in z['result'].items()if 'elapsed'not in k}for z in pair]
 if v[0]!=v[1]:mismatches.append(parent['root_id'])
a.write_record(P/'reserve-control-results.json',dict(complete=True,question='Does private quiet-check subset leave the ordinary0 reserve iteration unchanged on all13 parents?',planned_queries=26,rows=rows,non_time_mismatches=mismatches,whole_seconds_cap=120,per_query_seconds=6,node_cap=65536,seconds=time.perf_counter()-start));print('RESERVE',len(rows),mismatches,time.perf_counter()-start,flush=True)
