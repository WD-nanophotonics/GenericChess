from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/'.local_agent/q1-component-20261016';O=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(O)]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
a=p.a
def action(d):
 if not d:return PassAction()
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def forbidden(*args,**kw):raise AssertionError('Search forbidden in static return-cost replay')
p.m.semantic_engine_search=forbidden
records=json.loads((P/'budget-results.json').read_bytes());assert records['complete'];cache={};rows=[];start=time.perf_counter()
for row in records['rows']:
 key=row['root_id']
 if key not in cache:
  d=json.loads((P/'roots'/f'{key}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=a.nc.compile_native_semantic_rules(c);cache[key]=s,nr
 s,nr=cache[key];np=a.pack_semantic_search_position(s.compiled,nr,s);st=s.state;edge=0;features=();r=row['result']
 for i,ac in enumerate(map(action,r['principal_variation'])):
  if i:assert a.sem.terminal_status(nr,np)['status']=='ongoing'
  packed=a.pack_semantic_action(nr,st.position,ac);t=time.perf_counter();np=nr.backend_module.semantic_make_checked(nr.capsule,np,packed);edge+=time.perf_counter()-t;st=a.apply_action(st,ac,s.compiled)
 t=time.perf_counter()
 if r['principal_variation']:features=a.sem.dynamic_features(nr,np)
 dyn=time.perf_counter()-t;assert a.record_value(features)==r['dynamic_features']
 rows.append(dict(root_id=key,order=row['order'],mode=row['mode'],pv_length=len(r['principal_variation']),checked_native_edges_seconds=edge,dynamic_features_seconds=dyn,features=a.record_value(features),original_wrapper_other_seconds=row['wrapper_other_seconds'],original_serialization_seconds=row['serialization_seconds'],root_restored=True))
a.write_record(P/'return-cost-replay.json',dict(complete=True,search_disabled=True,rows=rows,seconds=time.perf_counter()-start,scope='Actual source-shared static return-cost replay of all12saved budget queries. Original wrapper times include Python overhead; this measures Native checked edges/dynamic features separately, not an instruction-exact decomposition or future runtime guarantee. All result fields retained.'));print('RETURN_REPLAY',len(rows),[(r['root_id'],r['mode'],round(r['checked_native_edges_seconds'],6),round(r['dynamic_features_seconds'],6))for r in rows],flush=True)
