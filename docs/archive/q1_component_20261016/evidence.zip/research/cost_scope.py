from pathlib import Path
from collections import Counter
import json
P=Path('.local_agent/q1-component-20261016')
assert json.loads((P/'completion.json').read_bytes())['complete']
assert json.loads((P/'check-games-completion.json').read_bytes())['complete']
refusals=[];roots=[];costs=Counter();queries=Counter()
for pattern,cohort in[('game-84??-*.json','single_phase'),('checkgame-84??-role?.json','check_layer')]:
 for f in P.glob(pattern):
  if '-partial'in f.name:continue
  d=json.loads(f.read_bytes());role=d.get('role') if cohort=='check_layer'else None if d['mode']=='q4'else int(d['mode'][-1])
  if cohort=='single_phase'and d['mode']=='q4':
   first=d['rows'][0]if d['rows']else None
   roots.append(dict(seed=d['case']['seed'],n=d['case']['n'],first_source=None if first is None else first['selected_source'],physical_root_win=first is not None and first['selected_source']=='physical_win',final_kind=d['kind'],final_result=d['result']))
  for r in d['rows']:
   key=cohort+':'+r['owner'];costs[key]+=r['actual_call_seconds'];queries[key]+=len(r['phases'])
   assert r['actual_call_seconds']>=r['caller_seconds']
   if not r['execution_allowed']:
    refusals.append(dict(file=f.name,cohort=cohort,mode=d['mode'],candidate_role=role,actor=r['actor'],is_candidate_actor=None if role is None else r['actor']==role,ply=r['ply'],owner=r['owner'],caller_seconds=r['caller_seconds'],actual_call_seconds=r['actual_call_seconds'],reason=None if r['selected']is None else r['selected']['termination_reason'],action_present=r['selected']is not None and r['selected']['action']is not None,cancelled=r['cancelled']))
out=dict(complete=True,physical_games=63,refusals=refusals,initial_roots=roots,immediate_initial_root_wins=sum(x['physical_root_win']for x in roots),all_outer_query_seconds_by_owner=dict(costs),queries_by_owner=dict(queries),limits=['Atomic budget/refusal is recorded, never relabeled as a physical loss or draw. An opponent refusal is not proof the candidate is weaker.','Caller timing includes the new serialized single result but excludes physical application/audit, file saving and later orchestration. Actual outer includes function return; game/batch costs include these costs except writing their own final receipts.','Allowance is checked at end of decision schedule; this is not a hard realtime guarantee across later dispatch or OS scheduling.','Ordinary concurrent load including owned diagnostics/other game batch is not a stop/retry gate or a controlled speed experiment.'])
(P/'cost-scope.json').write_bytes(json.dumps(out,indent=2).encode());print('COST_SCOPE',len(refusals),'initialwins',out['immediate_initial_root_wins'],flush=True)
