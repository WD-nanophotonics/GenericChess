from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)]
import probe as p
from q0d2_games import load_new
from generic_chess.session.serialization import serialize_game_record
a=p.a
summary=json.loads((P/'q0d2-summary.json').read_bytes());cases=[dict(seed=x['seed'],role=x['role'],**x['first_action_divergence'])for x in summary['pairs']if 'first_action_divergence'in x]
plan=dict(question='At ALL12 first D2/upfront action divergences, does either selected action admit a literal immediate winning reply?',cases=cases,selection='All12 original first action differences, no outcome filtering; shared-prefix first D2 completes identically in selected fields. Original eight exposed families, no new validation.',query_limit=24,per_diagnostic_seconds=a.plan['diagnostic_seconds'],whole_seconds=120,scope='Exact Core one-reply legal enumeration, preserve unknown; no solver/WDL/old search rerun.',decision='A found immediate tactical loss is a concrete mechanism; absent one-reply loss is not safety/WDL or disproof of deeper useful q4.')
a.write_record(P/'d2-tactical-plan.json',plan);roots=P/'d2-tactical-roots';roots.mkdir(exist_ok=True);rows=[];start=time.perf_counter()
for i,case in enumerate(cases):
 s,nr,bv,hv=load_new(case['seed']);up=json.loads((P/f"policy-{case['seed']}-upfront_role{case['role']}.json").read_bytes());dq=json.loads((P/f"q0d2-{case['seed']}-role{case['role']}.json").read_bytes())
 for row in dq['rows'][:case['ply']]:
  assert p.digest(s)==row['before_sha256'];s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==row['action']))
 assert p.digest(s)==case['before_sha256']
 inp=json.loads((P/'policy-inputs'/f"{case['seed']}.json").read_bytes());a.write_record(roots/f'{i}.json',dict(ruleset=inp['ruleset'],game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s)))
 br=up['rows'][case['ply']];dr=dq['rows'][case['ply']]
 full=lambda r:{k:v for k,v in r.items()if 'elapsed'not in k}
 first_equal=full(br['phases'][0]['result'])==full(dr['phases'][0]['result'])
 assert first_equal
 for arm,row in[('upfront',br),('d2',dr)]:
  p.stopped()
  if time.perf_counter()-start>=plan['whole_seconds']:rows.append(dict(case_index=i,arm=arm,missing='WHOLE_CAP'));continue
  ac=next(ac for ac in s.legal_actions()if a.record_value(ac)==row['action']);diag=a.diagnosis(s,ac);rows.append(dict(case_index=i,case=case,arm=arm,action=a.record_value(ac),selected_source=row['selected_source'],first_D2_all_non_time_fields_equal=first_equal,diagnostic=diag))
a.write_record(P/'d2-tactical-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('TACTICAL',len(rows),[(r['case_index'],r['arm'],r['diagnostic']['kind'])for r in rows],flush=True)
