from pathlib import Path
import json,hashlib,shutil,subprocess,sysconfig,time,sys
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';S=P/'noise_counter_source';S.mkdir(exist_ok=True)
base=R/'generic_chess/_native/native_module.c';assert hashlib.sha256(base.read_bytes()).hexdigest()=='1c855ae56e946ec6cb8e57f60a36a18cb75cfec2ee8061047469f3e0bee3fac3'
for p in (R/'generic_chess/_native').iterdir():
 if p.suffix in('.c','.h'):shutil.copyfile(p,S/p.name)
p=S/'native_module.c';s=p.read_text(encoding='utf-8-sig')
mark='    uint64_t beta_cutoffs;';assert s.count(mark)==1
s=s.replace(mark,mark+'\n    uint64_t noise_roots[2],noise_edges[14],noise_visits[14],noise_abort[14];')
mark='    ctx->nodes++;ctx->qnodes++;';assert s.count(mark)==1
s=s.replace(mark,mark+'\n    if(qdepth==0)ctx->noise_roots[ctx->ordinary_qdepth>0]++;')
mark='        int score=-gc_semantic_quiescence(ctx,ply+1,qdepth+1,-beta,-alpha,child_terminal,child_winner);';assert s.count(mark)==1
inject="""        int noise_idx=-1;
        uint64_t noise_before=ctx->qnodes;
        if(qdepth==0){
            int cl=0;
            if(!check){
                int en=0;
                for(unsigned j=0;j<cells;j++)if(child->board[j].occupied && child->board[j].owner!=pos->side_to_move)en++;
                if(en<parent_enemies)cl=1;
                else if(gc_semantic_inventory_changed(ctx->rules,pos,child)){
                    int ck=gc_semantic_runtime_in_check(ctx->rules,child,child->side_to_move);
                    cl=ck<0?6:ck?2:3;
                }else cl=child_terminal>0?5:4;
            }
            noise_idx=(ctx->ordinary_qdepth>0)*7+cl;
            ctx->noise_edges[noise_idx]++;
        }
"""
s=s.replace(mark,inject+mark+"""
        if(noise_idx>=0){
            ctx->noise_visits[noise_idx]+=ctx->qnodes-noise_before;
            if(ctx->control)ctx->noise_abort[noise_idx]++;
        }""")
mark='    PyObject *training_trace = ctx.trace_enabled';assert s.count(mark)==1
inject="""    for(int mode=0;mode<2;mode++){
        char key[80];snprintf(key,sizeof(key),"noise_roots_%d",mode);
        if(gc_semantic_set_u64(out,key,ctx.noise_roots[mode])!=0){Py_DECREF(out);return NULL;}
        for(int cl=0;cl<7;cl++){
            int ix=mode*7+cl;
            snprintf(key,sizeof(key),"noise_edges_%d_%d",mode,cl);
            if(gc_semantic_set_u64(out,key,ctx.noise_edges[ix])!=0){Py_DECREF(out);return NULL;}
            snprintf(key,sizeof(key),"noise_visits_%d_%d",mode,cl);
            if(gc_semantic_set_u64(out,key,ctx.noise_visits[ix])!=0){Py_DECREF(out);return NULL;}
            snprintf(key,sizeof(key),"noise_abort_%d_%d",mode,cl);
            if(gc_semantic_set_u64(out,key,ctx.noise_abort[ix])!=0){Py_DECREF(out);return NULL;}
        }
    }
"""
s=s.replace(mark,inject+mark);p.write_bytes(s.encode())
plan=json.loads((P/'next-noise-plan.json').read_bytes());plan.update(status='FROZEN_BEFORE_BUILD',counter_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),classes=['forced_evasion','capture','inventory_check','inventory_noncheck','ordinary_check','quiet_terminal','classification_unknown'],attribution='qnodes after-minus-before each qdepth0 child recursive call. Nested descendants attributed once, not each deeper edge. All qnodes minus sum attributed descendants must equal qdepth0 roots. Reserve ordinary0 vs requested ordinary4 separate. Literal check only for inventory noncapture qdepth0; extra scan/check cost changes clock, not policy. Allocation-failure-only diagnostic export cleanup is not product code.')
(P/'noise-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in S.glob('*.c')],'-o',str(P/'noise_counter_native_core.pyd')]
start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
(P/'noise-build-private.json').write_bytes(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-start),indent=2).encode())
print('BUILD',r.returncode,time.perf_counter()-start,r.stderr[-1500:]);sys.exit(r.returncode)
