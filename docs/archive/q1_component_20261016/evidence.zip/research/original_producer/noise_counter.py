from pathlib import Path
import json,sys,time,importlib.util,hashlib
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;plan=json.loads((P/'noise-plan.json').read_bytes())
spec=importlib.util.spec_from_file_location('noise_counter._native_core',P/'noise_counter_native_core.pyd');counter=importlib.util.module_from_spec(spec);spec.loader.exec_module(counter)
mods=dict(normal=p.m,counter=counter);raws={}
for name,m in mods.items():
 orig=m.semantic_engine_search
 def wrap(*args,_orig=orig,_name=name,**kw):
  x=_orig(*args,**kw);raws[_name]=x;return x
 m.semantic_engine_search=wrap
rows=[];missing=[];mismatches=[];start=time.perf_counter()
for parent in plan['parents']:
 d=json.loads((P/'roots'/f"{parent['root_id']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));assert p.digest(s)==parent['before_sha256'];nrs={name:a.nc.compile_native_semantic_rules(c,backend_module=m)for name,m in mods.items()}
 for order,names in enumerate(plan['orders']):
  for name in names:
   p.stopped()
   if time.perf_counter()-start>=plan['whole_seconds']:missing.append(dict(root_id=parent['root_id'],order=order,arm=name,kind='WHOLE_CAP_NOT_STARTED'));continue
   t=time.perf_counter();e=a.SemanticSearchEngine(c,nrs[name],board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False)
   r=e.search(s,a.SearchLimits(max_depth=plan['depth'],max_nodes=plan['total_nodes'],max_time_seconds=plan['per_query_seconds'],quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True)
   row=dict(root_id=parent['root_id'],order=order,arm=name,result=a.record_value(r),raw=a.record_value(raws[name]),caller_seconds=time.perf_counter()-t,pv_edges=a.audit(s,nrs[name],r),before_sha256=p.digest(s));rows.append(row)
   if name=='counter':
    v=row['raw'];attributed=sum(v[f'noise_visits_{mode}_{cl}']for mode in range(2)for cl in range(7));assert attributed+v['noise_roots_0']+v['noise_roots_1']==r.qnodes,(attributed,r.qnodes);row['attribution_identity_pass']=True
   print(parent['root_id'],order,name,r.completed_depth,r.termination_reason,round(row['caller_seconds'],3),flush=True)
  pair=[r for r in rows if r['root_id']==parent['root_id']and r['order']==order]
  if len(pair)==2 and all(r['result']['termination_reason']!='time_budget'for r in pair):
   vals=[{k:v for k,v in z['result'].items()if 'elapsed'not in k}for z in pair]
   if vals[0]!=vals[1]:mismatches.append(dict(root_id=parent['root_id'],order=order,keys=[k for k in vals[0]if vals[0][k]!=vals[1][k]]))
  p.save('noise-results-partial.json',dict(complete=False,rows=rows,missing=missing,mismatches=mismatches,seconds=time.perf_counter()-start))
p.save('noise-results.json',dict(complete=True,rows=rows,missing=missing,mismatches=mismatches,seconds=time.perf_counter()-start))
print('NOISE_CLOSED',len(rows),len(missing),mismatches,time.perf_counter()-start,flush=True)
