from pathlib import Path
import json,sys,time,importlib.util,hashlib,threading
R=Path.cwd();P=R/'.local_agent/q1-component-20261016';O=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(O)]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;plan=json.loads((P/'check-layer-plan.json').read_bytes());spec=importlib.util.spec_from_file_location('check_layer._native_core',P/'check_layer_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods=dict(normal=p.m,check_layer=m);rows=[];missing=[];diags={};start=time.perf_counter()
for parent in plan['parents']:
 d=json.loads((O/'roots'/f"{parent['root_id']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));assert p.digest(s)==parent['before_sha256'];nrs={name:a.nc.compile_native_semantic_rules(c,backend_module=mod)for name,mod in mods.items()}
 for budget in plan['budgets']:
  for order,names in enumerate(plan['orders']):
   for name in names:
    p.stopped()
    if time.perf_counter()-start>=plan['whole_seconds']:missing.append(dict(root_id=parent['root_id'],budget=budget,order=order,arm=name));continue
    e=a.SemanticSearchEngine(c,nrs[name],board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False);t=time.perf_counter()
    r=e.search(s,a.SearchLimits(max_depth=2,max_nodes=budget['nodes'],max_time_seconds=budget['seconds'],quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True)
    seconds=time.perf_counter()-t;key=parent['root_id']+':'+repr(r.action)
    if key not in diags:diags[key]=a.diagnosis(s,r.action)
    rows.append(dict(root_id=parent['root_id'],before_sha256=p.digest(s),budget=budget,order=order,arm=name,objective='original_q4'if name=='normal'else plan['objective'],result=a.record_value(r),caller_seconds=seconds,pv_edges=a.audit(s,nrs[name],r),diagnostic_key=key))
    print(parent['root_id'],budget['kind'],order,name,r.completed_depth,r.termination_reason,round(seconds,3),diags[key]['kind'],flush=True)
  a.write_record(P/'check-layer-results-partial.json',dict(complete=False,rows=rows,missing=missing,diagnostics=diags,seconds=time.perf_counter()-start))
# Actual mid-search cancellation on first two frozen roots, no instruction-exact injection.
cancel=[]
for parent in plan['parents'][:2]:
 d=json.loads((O/'roots'/f"{parent['root_id']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=a.nc.compile_native_semantic_rules(c,backend_module=m);before=p.digest(s);token=a.CancellationToken();timer=threading.Timer(.02,token.cancel);timer.start()
 try:
  e=a.SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False);r=e.search(s,a.SearchLimits(max_depth=16,max_nodes=1000000,max_time_seconds=1.,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True,stop_on_immediate_win=True)
 finally:timer.cancel();timer.join()
 assert p.digest(s)==before
 cancel.append(dict(root_id=parent['root_id'],result=a.record_value(r),token_cancelled=token.is_cancelled(),root_restored=True,pv_edges=a.audit(s,nr,r)))
a.write_record(P/'check-layer-results.json',dict(complete=True,rows=rows,missing=missing,diagnostics=diags,actual_timer_cancellations=cancel,seconds=time.perf_counter()-start));print('CHECK_LAYER_CLOSED',len(rows),len(missing),time.perf_counter()-start,flush=True)
