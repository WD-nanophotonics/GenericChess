from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/q1-component-20261016';sys.path[:0]=[str(R),str(P),str(R/'.local_agent/residual-q4-20261016')]
import games as g
p=g.p;a=g.a
from policy_games import physical
spec=importlib.util.spec_from_file_location('check_layer_games._native_core',P/'check_layer_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=json.loads((P/'check-games-plan.json').read_bytes());start=time.perf_counter();games=[]
for case in plan['inputs']:
 for role in plan['orders'][case['seed']%2]:
  p.stopped()
  if time.perf_counter()-start>=plan['whole_seconds']:games.append(dict(**case,role=role,kind='NOT_STARTED_WHOLE_CAP_UNKNOWN'));continue
  s,nr,d=g.load(case['seed']);pilot=a.nc.compile_native_semantic_rules(s.compiled,backend_module=m);t=time.perf_counter();rows=[];kind=None;token=a.CancellationToken();path=P/f"checkgame-{case['seed']}-role{role}.json"
  for ply in range(plan['horizon']):
   p.stopped()
   if s.result.status.value!='ongoing':kind='ACTUAL_RULE_TERMINAL';break
   if time.perf_counter()-start>=plan['whole_seconds']:kind='WHOLE_CAP_UNKNOWN';break
   if time.perf_counter()-t>=plan['game_seconds']:kind='GAME_CAP_UNKNOWN';break
   actor=s.state.position.side_to_move;before=p.digest(s);use=pilot if actor==role else nr;outer=time.perf_counter();row,r=g.schedule(s,use,d['board_values'],d['hand_values'],4,token);row.update(actual_call_seconds=time.perf_counter()-outer,ply=ply,actor=actor,owner='changed_check_layer_q4'if actor==role else'normal_q4',before_sha256=before,objective=plan['objective']if actor==role else'original_q4')
   if not row['execution_allowed']:rows.append(row);kind='CALLER_NO_ACTION_UNKNOWN';break
   action=r.action;row['action']=a.record_value(action);at=time.perf_counter();physical(s,nr,action);row.update(after_sha256=p.digest(s),actual_terminal=a.record_value(s.result),physical_audit_seconds=time.perf_counter()-at);rows.append(row)
   a.write_record(path.with_name(path.stem+'-partial.json'),dict(complete=False,case=case,role=role,rows=rows,seconds=time.perf_counter()-t))
  kind=kind or('ACTUAL_RULE_TERMINAL'if s.result.status.value!='ongoing'else'PLY_CAP_UNKNOWN')
  out=dict(complete=True,case=case,role=role,mode=f'q4_role{role}',rows=rows,kind=kind,result=a.record_value(s.result),state=a.record_value(s.state),seconds=time.perf_counter()-t);a.write_record(path,out);games.append(dict(**case,role=role,kind=kind,result=out['result'],edges=sum('action'in r for r in rows),seconds=out['seconds']));a.write_record(P/'check-games-completion-partial.json',dict(complete=False,games=games,seconds=time.perf_counter()-start));print('CHECKGAME',case,role,kind,len(rows),out['result']['status'],out['result']['winner'],round(out['seconds'],3),flush=True)
a.write_record(P/'check-games-completion.json',dict(complete=True,games=games,seconds=time.perf_counter()-start));print('CHECKGAMES_CLOSED',len(games),time.perf_counter()-start,flush=True)
