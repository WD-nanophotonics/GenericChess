from pathlib import Path
import json
R=Path.cwd();P=R/'.local_agent/q1-component-20261016';c=json.loads((P/'consumer-replay.json').read_bytes());p=json.loads((R/'docs/archive/q1_component_20261016/publication-replay.json').read_bytes())
q=R/'docs/operations/COLLABORATION_LOG.md';s=q.read_text(encoding='utf-8-sig');marker='## PRIMARY Q horizons and different-opponent transfer —2026-10-16'
assert marker not in s,'Do not duplicate segment collaboration record'
text="""

## PRIMARY Q horizons and different-opponent transfer —2026-10-16

PRIMARY_SANDBOX alone wrote this checkout and sandbox delivery. Normal product
source/API/default/price/UI stayed unchanged. Completed109physical games:
16exposed D2 components,45fresh q0/q1/fixedq4,18private quiet-check-subset,
18fresh fixedq0 transfer and12exposed reserve-beforeq1. Baselines played once
are not doubled as physical games. All caps/failures/UNKNOWN and adverse events
remain. D2alone does not explain prior upfront gains; local quiet-check depth
gain does not establish utility. q1's positive fixedq4 result fails freshq0
transfer (-4/12); changed families/reserve prevent isolated-opponent causality.
Reserve fixes one matched policy LOSS-to-WIN but is still-1versusq0 at greater
cost than pureq1. Future policy also changes: no first-action-only causal proof.

Measured required dynamic features (~15ms) and serialization (~4ms), rather
than checked PV microseconds, explain sampled20msreserve refusals. Original
refused games remainUNKNOWN, including opponent failures. Fresh transfer uses
one common50msreserve; no hard realtime/default/API change. Existing Python
check-only continuation is a distinct next control; private Native source is
prepared with0builds/0queries and an explicit aux/history scope requirement.

DEV_AUX remained owner of separate sidemission solver/verifier/cursor/learning.
No new request/result was discovered during complete channel/thread checkpoints.
Prior04993 order-chamber source/report reading and a579 final OWNER MESSAGE
remain the existing tiers: no final AUX source/tests/games/proofs independently
executed or adopted this segment. No cross-checkout writes, merge, duplicate
solver/training, extra Agent/worker/fees or coordination quiet window occurred.

Coordination: full primary12reply and AUX63two-reply reads were preserved before
assessment; no new Dot technical advice or disagreement appeared. Earlier Dot
retained-policy/shared-clock/main+q advice is applied; shared-account labels are
routing, not process authentication. Legacy root association remains receipt-only,
not byte-verified historical code. No routine acknowledgment/retry/approval loop.
The published fixed report/source/data/archive links are sent as one informational
result; no claim Dot read or reran them. Private receipts retain actual delivery.

Efficiency evidence: counter52calls rejects a negligible nonchecking-inventory
filter premise; cheaper components and different opponents prevent overcrediting
complex portfolios. This measures information/cost of experiments, not a causal
Agent cooperation percentage. Ordinary simultaneous controlled jobs limit wall
comparisons. Actual helper/export/encoding-shape mistakes were corrected with
originals retained; no unchanged launch loop, SAC/OS/approval blocker or hidden
user intervention. The input export repair replayed the SAME9rules/walks,
without regenerating or replacing families.

"""
text+=f"Actual normal and extracted-source Python-S rebuilt search-DISABLED consumers\nverify{c['queries']}query/phase receipts,{c['pv_edges']}PV plus{c['selected_choice_edges']}fallback-choice\nedges,109games/{c['physical_edges']}physical edges and{c['one_reply_receipts']}literal-reply receipts.\n{c['roots']}root identifiers/{c['unique_root_states']}unique fullstates are not independent families.\nRequired38focused regressions pass; no new2687full-suite execution claimed.\nSource-only restore is not new search/game/proof or independent rule/WDL authority.\n\nEvidence: [Q_HORIZON_COMPONENTS_20261016](../research/Q_HORIZON_COMPONENTS_20261016.md).\nCurrent causal selection and reconsideration live in LOCAL_MAINLINE.md; no new\npolicy index/framework or publication consent queue. Science remains OPEN.\n"
q.write_bytes((s.rstrip()+text).encode());print('COLLABORATION_UPDATED')
