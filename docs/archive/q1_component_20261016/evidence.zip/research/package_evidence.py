"""Publish a checked scientific evidence copy; raw account/transport logs stay private."""
from pathlib import Path
import sys,json,hashlib,zipfile,subprocess,re
R=Path.cwd();P=R/'.local_agent/q1-component-20261016';O=R/'.local_agent/residual-q4-20261016';D=R/'docs/archive/q1_component_20261016'
assert json.loads((P/'completion.json').read_bytes())['complete']
assert json.loads((P/'check-games-completion.json').read_bytes())['complete']
assert json.loads((P/'transfer/completion.json').read_bytes())['complete']
assert json.loads((P/'consumer-replay.json').read_bytes())['physical_games']==79+sum('result'in g for g in json.loads((P/'transfer/completion.json').read_bytes())['games'])+sum('result'in g for g in json.loads((P/'transfer/portfolio-completion.json').read_bytes())['games'])
assert hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest()=='1c855ae56e946ec6cb8e57f60a36a18cb75cfec2ee8061047469f3e0bee3fac3'
files={}
def add(name,data):
 text=data.decode('utf-8-sig').replace(str(R),'<PROJECT>').replace(str(R).replace('\\','/'),'<PROJECT>')
 text=text.replace('C:\\\\Users\\\\wdai','<USER>').replace('<USER>','<USER>').replace('<USER>','<USER>')
 files[name]=text.replace('\r\n','\n').encode()
names=['plan.json','prepare.py','prepare-original.py','input-manifest.json','input-manifest-original-failure.json','producer-binding.json','games.py','completion.json','check-games-plan.json','check-games-binding.json','check_games.py','check-games-completion.json','build_check_layer.py','check_layer.py','check-layer-plan.json','check-layer-binding.json','check-layer-results.json','reserve_controls.py','reserve-control-results.json','consumer.py','summarize.py','summary.json','literature.json','focused-tests.json','local-failures.json','scope.py','scope.json','cost_scope.py','cost-scope.json','budget_attribution.py','budget-plan.json','budget-results.json','return_cost_replay.py','return-cost-replay.json','transfer/prepare.py','transfer/games.py','transfer/summarize.py','q1-q0-paired.json','next-check-only-plan.json','package_evidence.py','public_copy_replay.py','write_report.py','write_collaboration.py','transfer/tactical.py','transfer/portfolio.py','transfer/portfolio_probe.py','transfer/portfolio_controls.py','transfer/portfolio_games.py','transfer/portfolio_summary.py']
for name in names:add('research/'+name,(P/name).read_bytes())
add('research/normal-consumer-replay.json',(P/'consumer-replay.json').read_bytes())
for src,dest in [('check-layer-build-private.json','check-layer-build.json')]:add('research/'+dest,(P/src).read_bytes())
for folder in['roots','inputs','original-export-failures','d2','noise','transfer']:
 for f in(P/folder).glob('*.json'):add('research/'+folder+'/'+f.name,f.read_bytes())
for pattern in['game-84??-*.json','checkgame-84??-role?.json']:
 for f in P.glob(pattern):
  if '-partial'not in f.name:add('research/'+f.name,f.read_bytes())
for name in['q0d2-plan.json','q0d2_games.py','q0d2_schedule.py','d2_tactical.py','build_noise_counter.py','noise_counter.py','noise-plan.json','noise-results.json','noise-summary.json']:
 add('research/original_producer/'+name,(O/name).read_bytes())
add('research/noise/noise-build.json',(O/'noise-build-private.json').read_bytes())
for name in['probe.py','policy_games.py']:add('research/original_dependency/'+name,(O/name).read_bytes())
for folder,source in [('check_layer_source',P/'check_layer_source'),('noise_counter_source',O/'noise_counter_source'),('check_only_source',P/'check_only_source')]:
 for f in source.iterdir():
  if f.suffix in('.c','.h'):add('variants/'+folder+'/'+f.name,f.read_bytes())
for rel in subprocess.check_output(['git','ls-files','generic_chess','scripts'],text=True).splitlines():
 if Path(rel).suffix in('.py','.c','.h'):add('source/'+rel,(R/rel).read_bytes())
add('source/pyproject.toml',(R/'pyproject.toml').read_bytes())
for name,data in files.items():
 text=data.decode()
 assert not re.search(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',text),(name,'email')
 for bad in['<USER>','C:\\\\Users\\\\wdai']:assert bad not in text,(name,bad)
 assert not re.search(r'\bsk-[A-Za-z0-9]{24,}',text),(name,'possiblekey')
 assert not re.search(r'\bxox[bp]-[A-Za-z0-9-]{12,}|\bghp_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}',text),(name,'possiblefulltoken')
D.mkdir(parents=True,exist_ok=True)
assert not(D/'evidence.zip').exists(),'Do not silently replace sealed capsule'
with zipfile.ZipFile(D/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert z.testzip()is None
 for name,data in files.items():assert z.read(name)==data
manifest=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),product_changed=False,product_module_sha256=hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),archive_sha256=hashlib.sha256((D/'evidence.zip').read_bytes()).hexdigest(),archive_bytes=(D/'evidence.zip').stat().st_size,member_count=len(files),members=[dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in sorted(files.items())],scope='Full normal source and checked scientific receipts. No raw Slack/account records/credentials/private paths/binaries/external source copies. New consumer is self-contained and search-disabled. Original private producer paths are provenance, not automatic rerun instructions. Prior d319 capsule remains immutable.')
(D/'manifest.json').write_bytes(json.dumps(manifest,indent=2).encode());print('PACKAGED',manifest['member_count'],manifest['archive_bytes'],manifest['archive_sha256'],flush=True)
