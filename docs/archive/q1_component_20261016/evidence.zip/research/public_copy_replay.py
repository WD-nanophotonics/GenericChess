from pathlib import Path
import sys,json,zipfile,uuid,subprocess,sysconfig,hashlib,time,os
R=Path.cwd();P=R/'.local_agent/q1-component-20261016';D=R/'docs/archive/q1_component_20261016';manifest=json.loads((D/'manifest.json').read_bytes());assert hashlib.sha256((D/'evidence.zip').read_bytes()).hexdigest()==manifest['archive_sha256'];dest=P/('public-copy-'+uuid.uuid4().hex[:8]);dest.mkdir();start=time.perf_counter()
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert z.testzip()is None
 for item in manifest['members']:
  data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256'];target=dest/item['path'];assert target.resolve().is_relative_to(dest.resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
source=dest/'source';src=source/'generic_chess/_native';out=source/'generic_chess'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(src.glob('*.c'))],'-o',str(out)]
env=dict(os.environ);cache=P/'zig-public-copy-cache';cache.mkdir(exist_ok=True);env['ZIG_GLOBAL_CACHE_DIR']=str(cache);build=subprocess.run(cmd,capture_output=True,timeout=120,env=env);(P/'public-copy-build-private.log').write_bytes(build.stdout+build.stderr);assert build.returncode==0
process=subprocess.run([sys.executable,'-S',str(dest/'research/consumer.py'),str(dest/'research')],cwd=source,capture_output=True,timeout=600)
(P/'public-copy-consumer-private.log').write_bytes(process.stdout+process.stderr);assert process.returncode==0,(process.stdout[-1000:],process.stderr[-1500:])
receipt=json.loads((dest/'research/consumer-replay.json').read_bytes());normal=json.loads((dest/'research/normal-consumer-replay.json').read_bytes())
for key in['roots','unique_root_states','queries','pv_edges','physical_games','physical_edges','one_reply_receipts','selected_choice_edges']:assert receipt[key]==normal[key],(key,receipt[key],normal[key])
x=dict(complete=True,archive_sha256=manifest['archive_sha256'],members=manifest['member_count'],source_module_sha256=hashlib.sha256((src/'native_module.c').read_bytes()).hexdigest(),native_rebuilt=True,python_without_site=True,module_origins_asserted=True,receipt=receipt,normal_counts_match=True,seconds=time.perf_counter()-start,scope='Actual extracted sanitized source-only normal Native rebuild and search-disabled full state/history receipt replay. Existing Windows/Python3.12.14/Zig0.16 runtime, not new machine, independent rules implementation or new search/game/proof execution. Private diagnostic Native images are source provenance, not rebuilt/rerun by this consumer.')
(D/'publication-replay.json').write_bytes(json.dumps(x,indent=2).encode());(P/'public-copy-replay.json').write_bytes(json.dumps(x,indent=2).encode());print('PUBLIC_COPY_PASS',manifest['member_count'],receipt,x['seconds'],flush=True)
