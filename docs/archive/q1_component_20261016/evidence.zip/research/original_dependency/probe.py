from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';P.mkdir(exist_ok=True)
sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')]
import allocation as a
from generic_chess.native import _module
m=_module()
B=R/'.local_agent/cutoff-repetition-20261016'
def save(name,x): (P/name).write_bytes(json.dumps(x,indent=2,ensure_ascii=False).encode())
def stopped(): a.p.rr.stopped()
def digest(s):return hashlib.sha256(json.dumps(a.record_value(s.state),sort_keys=True).encode()).hexdigest()
def load(ci):
 if ci==2:
  case=json.loads((a.B/'plan.json').read_bytes())['cases'][0]
  assert(case['seed'],case['ply'])==(4323,12)
  return a.load(case,m)
 x=json.loads((B/'fresh-inputs/6311.json').read_bytes());root=next(r for r in x['roots']if r['ply']==8)
 raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(x['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
 s=a.GameSession(c)
 for stored in root['walk']:s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==stored))
 game=json.loads((B/'decision-1-baseline_baseline.json').read_bytes());turn=[27,47][ci]
 for row in game['rows'][:turn]:
  assert digest(s)==row['before_sha256'];s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==row['action']))
 prep=json.loads((B/'next-fallback-preparation-private.json').read_bytes());pc=next(ca for ca in prep['cases']if ca['game_ply']==turn)
 assert digest(s)==pc['before_sha256'] and a.record_value(s.state)==pc['state']
 nr=a.nc.compile_native_semantic_rules(c,backend_module=m);profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig())
 return s,nr,{t:int(round(v))for t,v in profile.board_value_by_type.items()},{t:int(round(v))for t,v in profile.hand_value_by_base_type.items()}
def requested(r):return r is not None and r.result_source=='main_iteration' and r.completed_depth>=2 and (r.result_ordinary_qdepth,r.result_check_hard_qdepth)==(4,8)
def physical(r):return r is not None and r.immediate_win and r.result_source=='verified_root_child'
def backup(r):return r is not None and r.result_source=='main_iteration' and r.completed_depth>=2 and (r.result_ordinary_qdepth,r.result_check_hard_qdepth)==(0,0)
def schedule(s,nr,bv,hv,mode,*,token=None,clock=time.perf_counter,factory=a.SemanticSearchEngine,after_phase=None):
 token=token or a.CancellationToken();start=clock();deadline=start+1.;used=0;phases=[];selected=None;source=None;objs=[]
 qs=[0,4]if mode=='upfront_cap2'else[4,0]if mode=='lazy_backup'else[4]
 for i,q in enumerate(qs):
  if token.is_cancelled()or deadline-clock()<=.02 or used>=1000000:break
  if i==1 and mode=='lazy_backup'and not(phases[0]['result']['termination_reason']=='qsearch_check_hard_limit'and not requested(objs[0])and not physical(objs[0])):break
  t=clock();engine=factory(s.compiled,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
  allowance=deadline-clock()-.02
  if mode=='upfront_cap2'and i==0:allowance=min(allowance,.25-(clock()-t))
  if allowance<=0:break
  r=engine.search(s,a.SearchLimits(max_depth=2 if mode=='upfront_cap2'and i==0 else 16,max_nodes=1000000-used,max_time_seconds=allowance,quiescence_max_depth=q,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True,stop_on_immediate_win=True)
  used+=r.nodes+r.qnodes;objs.append(r)
  phases.append(dict(q=q,result=a.record_value(r),phase_seconds=clock()-t,allowance=allowance,remaining_seconds=deadline-clock(),used_total_nodes=used))
  if i==0:selected=r;source='q4_initial'if q==4 else'upfront_disabled_initial'
  if physical(r):selected=r;source='physical_win'
  elif requested(r):selected=r;source='requested_q4'
  elif i==1 and mode=='lazy_backup'and backup(r):selected=r;source='disabled_backup'
  if after_phase:after_phase(i,r,token)
  if physical(r)or requested(r)or token.is_cancelled()or clock()>=deadline:break
  # A cap2 first result may be retained if the second phase does not complete q4.
 seconds=clock()-start
 out=dict(mode=mode,phases=phases,selected=None if selected is None else a.record_value(selected),selected_source=source,caller_seconds=seconds,total_nodes=used,overrun_seconds=max(0,seconds-1.),cancelled=token.is_cancelled(),execution_allowed=selected is not None and selected.action is not None and not token.is_cancelled()and clock()<deadline)
 return out,selected,objs
if __name__=='__main__':
 plan=json.loads((P/'plan.json').read_bytes());start=time.perf_counter();rows=[];diags={}
 for ci in range(3):
  stopped();s,nr,bv,hv=load(ci);before=digest(s)
  for order,modes in enumerate(plan['orders']):
   for mode in modes:
    stopped()
    if time.perf_counter()-start>=120:raise TimeoutError('frozen whole cap120s')
    row,r,objs=schedule(s,nr,bv,hv,mode);row.update(case_index=ci,order=order,before_sha256=before)
    row['phase_pv_edges']=[a.audit(s,nr,ob)for ob in objs];assert digest(s)==before and row['total_nodes']<=1000000
    key=str(ci)+':'+repr(None if r is None else r.action)
    if key not in diags:diags[key]=a.diagnosis(s,None if r is None else r.action)
    row['diagnostic_key']=key;rows.append(row);save('results.json',dict(complete=False,rows=rows,diagnostics=diags,seconds=time.perf_counter()-start))
    print(ci,order,mode,[(p['result']['completed_depth'],p['result']['termination_reason'],p['result']['result_ordinary_qdepth'],round(p['phase_seconds'],4))for p in row['phases']],row['selected_source'],diags[key]['kind'],round(row['caller_seconds'],4),flush=True)
 save('results.json',dict(complete=True,rows=rows,diagnostics=diags,seconds=time.perf_counter()-start));print('DONE',len(rows),time.perf_counter()-start,flush=True)
