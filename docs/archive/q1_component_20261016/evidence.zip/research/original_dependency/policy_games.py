from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)]
import probe as p
a=p.a
def state_hash(s):return p.digest(s)
def physical(s,nr,action):
 old=s.state;np=a.pack_semantic_search_position(s.compiled,nr,s)
 np=a.sem.make_checked(nr,np,a.pack_semantic_action(nr,old.position,action));s.submit(action);snap=a.sem.snapshot(nr,np);exp=a.expected_snapshot(s.state.position,nr,s.compiled)
 for key in('board','hands','aux_state','side'):assert a.record_value(snap[key])==a.record_value(exp[key])
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(a.position_identity_key(w,s.compiled))for w in s._search_witnesses]
 assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in s.state.history)
 assert a.sem.terminal_status(nr,np)==dict(status=s.result.status.value,winner=s.result.winner)
def run_game(case,mode,load,path,plan,start,*,forced=None):
 s,nr,bv,hv=load();initial_actor=s.state.position.side_to_move;token=a.CancellationToken();t=time.perf_counter();rows=[];kind=None
 for ply in range(plan['horizon']):
  p.stopped()
  if s.result.status.value!='ongoing':kind='ACTUAL_RULE_TERMINAL';break
  if time.perf_counter()-start>=plan['whole_seconds']:kind='WHOLE_CAP_UNKNOWN';break
  if time.perf_counter()-t>=plan['game_seconds']:kind='GAME_CAP_UNKNOWN';break
  actor=s.state.position.side_to_move;owner=('lazy_backup'if mode.startswith('lazy')else'upfront_cap2')if mode!='q4'and actor==int(mode[-1])else'q4';before=state_hash(s)
  if ply==0 and forced is not None:
   action=next(ac for ac in s.legal_actions()if a.record_value(ac)==forced);row=dict(ply=ply,actor=actor,owner='FORCED_SELECTED_ACTION',before_sha256=before,action=a.record_value(action),execution_allowed=True)
  else:
   row,r,objs=p.schedule(s,nr,bv,hv,owner,token=token);row.update(ply=ply,actor=actor,owner=owner,before_sha256=before)
   if not row['execution_allowed']:rows.append(row);kind='CALLER_NO_ACTION_UNKNOWN';break
   action=r.action;row['action']=a.record_value(action)
  phys=time.perf_counter();physical(s,nr,action);row.update(after_sha256=state_hash(s),actual_terminal=a.record_value(s.result),physical_audit_seconds=time.perf_counter()-phys);rows.append(row)
  a.write_record(path.with_name(path.stem+'-partial.json'),dict(complete=False,case=case,mode=mode,initial_actor=initial_actor,rows=rows,seconds=time.perf_counter()-t))
  print(case,mode,ply,owner,row.get('selected_source'),s.result.status.value,flush=True)
 kind=kind or('ACTUAL_RULE_TERMINAL'if s.result.status.value!='ongoing'else'PLY_CAP_UNKNOWN')
 out=dict(complete=True,case=case,mode=mode,initial_actor=initial_actor,rows=rows,kind=kind,result=a.record_value(s.result),state=a.record_value(s.state),seconds=time.perf_counter()-t)
 a.write_record(path,out);print('GAME_DONE',case,mode,kind,len(rows),out['result'],out['seconds'],flush=True);return out

def load_new(seed):
 data=json.loads((P/'policy-inputs'/f'{seed}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(data['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession(c)
 for act in data['root']['walk']:s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==act))
 assert a.record_value(s.state)==data['root']['state'];nr=a.nc.compile_native_semantic_rules(c,backend_module=p.m);profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig())
 return s,nr,{t:int(round(v))for t,v in profile.board_value_by_type.items()},{t:int(round(v))for t,v in profile.hand_value_by_base_type.items()}
if __name__=='__main__':
 plan=json.loads((P/'policy-plan.json').read_bytes());manifest=json.loads((P/'policy-input-manifest.json').read_bytes());assert manifest['search_queries']==0;start=time.perf_counter();games=[]
 for seed in plan['seeds']:
  for mode in plan['orders'][seed%2]:
   data=json.loads((P/'policy-inputs'/f'{seed}.json').read_bytes())
   if data['root']is None:games.append(dict(seed=seed,mode=mode,kind='MISSING_INPUT_ROOT_UNKNOWN'));continue
   if time.perf_counter()-start>=plan['whole_seconds']:games.append(dict(seed=seed,mode=mode,kind='NOT_STARTED_WHOLE_CAP_UNKNOWN'));continue
   path=P/f'policy-{seed}-{mode}.json';out=run_game(seed,mode,lambda:load_new(seed),path,plan,start)
   games.append(dict(seed=seed,mode=mode,kind=out['kind'],result=out['result'],initial_actor=out['initial_actor'],edges=sum('action'in r for r in out['rows']),seconds=out['seconds']))
   p.save('policy-completion-partial.json',dict(complete=False,games=games,seconds=time.perf_counter()-start))
 p.save('policy-completion.json',dict(complete=True,games=games,seconds=time.perf_counter()-start));print('POLICY_ALL_CLOSED',len(games),time.perf_counter()-start,flush=True)
