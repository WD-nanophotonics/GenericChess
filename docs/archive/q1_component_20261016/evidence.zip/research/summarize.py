"""Summarize every frozen slot; categorical UNKNOWN is never an actual DRAW."""
from pathlib import Path
from collections import Counter
import json,random,hashlib
P=Path('.local_agent/q1-component-20261016')
read=lambda f:json.loads((P/f).read_bytes())
pay={'WIN':1,'LOSS':-1,'DRAW':0,'UNKNOWN':0}
def status(g,role):
 r=g.get('result')
 return 'UNKNOWN'if not r or r['status']=='ongoing'else 'DRAW'if r['winner']is None else'WIN'if r['winner']==role else'LOSS'
def boot(families):
 rng=random.Random(20261016);n=len(families);v=sorted(sum(rng.choice(families)for _ in range(n))/n for _ in range(5000));return[v[int(.025*4999)],v[int(.975*4999)]]
def panel(done,mode,baseline,check=False):
 pairs=[];trans=Counter();bc=Counter();vc=Counter();cost=0;calls=[];families=[]
 for case in read('plan.json')['inputs']:
  seed=case['seed'];b=next(g for g in baseline['games']if g['seed']==seed and g['mode']=='q4');fd=0
  for role in[0,1]:
   v=next(g for g in done['games']if g['seed']==seed and(g.get('role')==role if check else g['mode']==f'{mode}_role{role}'))
   bs=status(b,role);vs=status(v,role);bc[bs]+=1;vc[vs]+=1;trans[bs+'->'+vs]+=1;delta=pay[vs]-pay[bs];fd+=delta
   pair=dict(seed=seed,n=case['n'],role=role,baseline=bs,candidate=vs,finite_event_delta=delta,baseline_kind=b['kind'],candidate_kind=v['kind'],baseline_seconds=b.get('seconds'),candidate_seconds=v.get('seconds'))
   if'result'in v:
    path=f'checkgame-{seed}-role{role}.json'if check else f'game-{seed}-{mode}_role{role}.json';out=read(path);cost+=out['seconds'];calls.extend(out['rows']);base=read(f'game-{seed}-q4.json')if'result'in b else None
    if base:
     for br,vr in zip(base['rows'],out['rows']):
      if br['before_sha256']!=vr['before_sha256']:break
      if br.get('action')!=vr.get('action'):pair['first_difference']=dict(ply=vr['ply'],actor=vr['actor'],candidate_actor=vr['actor']==role,before_sha256=vr['before_sha256'],baseline_action=br.get('action'),candidate_action=vr.get('action'));break
   pairs.append(pair)
  families.append(fd/2)
 phases=[ph for row in calls for ph in row['phases']]
 return dict(planned_role_comparisons=18,baseline_counts={k:bc[k]for k in pay},candidate_counts={k:vc[k]for k in pay},transitions=dict(trans),finite_event_net_delta=sum(x['finite_event_delta']for x in pairs),mean_delta_per_role=sum(families)/9,family_bootstrap95=boot(families),family_bootstrap_scope='5000family resamples, both roles kept together; nine balanced development families/shared controls, not randomized causal or population inference.',actual_game_seconds=cost,caller_seconds=sum(r['caller_seconds']for r in calls),queries=len(phases),physical_edges=sum('action'in r for r in calls),execution_disallowed=sum(not r['execution_allowed']for r in calls),main_nodes=sum(ph['result']['nodes']for ph in phases),qnodes=sum(ph['result']['qnodes']for ph in phases),selected_depths=dict(Counter(r['selected']['completed_depth']for r in calls if r['selected']is not None)),phase_reasons=dict(Counter(ph['result']['termination_reason']for ph in phases)),physical_root_wins=sum(r.get('selected_source')=='physical_win'for r in calls),by_board=[dict(n=n,comparisons=sum(p['n']==n for p in pairs),baseline_counts=dict(Counter(p['baseline']for p in pairs if p['n']==n)),candidate_counts=dict(Counter(p['candidate']for p in pairs if p['n']==n)),finite_event_net_delta=sum(p['finite_event_delta']for p in pairs if p['n']==n),candidate_seconds=sum(p.get('candidate_seconds',0)or 0 for p in pairs if p['n']==n))for n in[8,12,16]],pairs=pairs)
base=read('completion.json');assert base['complete']and len(base['games'])==45
noise=read('noise/summary.json');d2=read('d2/summary.json');pilot=read('check-layer-results.json');reserve=read('reserve-control-results.json');assert pilot['complete']and len(pilot['rows'])+len(pilot['missing'])==104
out=dict(product_changed=False,normal_source_sha256=read('plan.json')['source_sha256'],frozen_plan=read('plan.json'),d2_component=d2,d2_first_phase_prefix=dict(calls=len(read('d2/prefix-results.json')['rows']),all_non_time_mismatches=read('d2/prefix-results.json')['mismatches']),noise=noise,base_cohort=dict(planned_games=45,actual_games=sum('result'in g for g in base['games']),missing=[g for g in base['games']if'result'not in g],seconds=base['seconds'],physical_edges=sum(g.get('edges',0)for g in base['games']),q4_physical_controls=[g for g in base['games']if g['mode']=='q4']),single_phase={mode:panel(base,mode,base)for mode in['q0','q1']},check_layer=dict(planned_queries=104,actual_queries=len(pilot['rows']),missing=pilot['missing'],seconds=pilot['seconds'],objective=read('check-layer-plan.json')['objective'],cells=[],reserve_control_queries=len(reserve['rows']),reserve_non_time_mismatches=reserve['non_time_mismatches'],actual_timer_cancellations=pilot['actual_timer_cancellations']))
for budget in['fixed_nodes','one_second']:
 for arm in['normal','check_layer']:
  rows=[r for r in pilot['rows']if r['arm']==arm and r['budget']['kind']==budget]
  out['check_layer']['cells'].append(dict(budget=budget,arm=arm,queries=len(rows),depths=dict(Counter(r['result']['completed_depth']for r in rows)),reasons=dict(Counter(r['result']['termination_reason']for r in rows)),caller_seconds=sum(r['caller_seconds']for r in rows),main_plus_q=sum(r['result']['nodes']+r['result']['qnodes']for r in rows),rows=[dict(root_id=r['root_id'],order=r['order'],depth=r['result']['completed_depth'],reason=r['result']['termination_reason'],seconds=r['caller_seconds'],diagnostic=pilot['diagnostics'][r['diagnostic_key']]['kind'])for r in rows]))
if(P/'check-games-completion.json').exists():
 check=read('check-games-completion.json');assert check['complete']and len(check['games'])==18
 out['check_layer']['finite_games']=panel(check,'check_layer',base,check=True);out['check_layer']['finite_batch_seconds']=check['seconds'];out['check_layer']['finite_missing']=[g for g in check['games']if'result'not in g]
out['limits']=['UNKNOWN maps to0 only in the observed finite W-L event statistic, never a draw/truevalue/missing-outcome imputation. All categorical changes retained.','D2 and check-layer comparisons are exposed component diagnosis; fresh q0/q1 protocol frozen before any cohort search, later check-layer uses the same partially exposed cohort. No independent confirmation, optimal WDL, learned prices, Elo/default claim.','Only the candidate actor changes against fixed q4. Baseline physically once/family reused across both roles/methods. Reused baseline is not additional independent games.','Query budgets include search and construction/serialization per recorded schedule; game/batch costs include full scientific state audits and recording except writing their own final receipt. Atomic budget overruns can refuse actions; no hard-timer promise.','Ordinary concurrent load including this Agents diagnostic/game producers is an interpretation limit; no exclusive machine or controlled wall-speed claim.','Quiet-check-layer finite q4 metadata describes a changed objective, NOT original q4 completion. Main action/rule/declaration/history authority preserved; no generic all-domain proof.','Current normal Native/product source unchanged. Full regression2687 at e583 remains historical; this segment will report only actual relevant checks and source-only receipt replay.']
(P/'summary.json').write_bytes(json.dumps(out,indent=2).encode())
print('SUMMARY',json.dumps({m:{k:v for k,v in x.items()if k in('candidate_counts','baseline_counts','finite_event_net_delta','actual_game_seconds','family_bootstrap95','by_board','execution_disallowed')}for m,x in out['single_phase'].items()},indent=2))
if'finite_games'in out['check_layer']:print('CHECK',json.dumps({k:v for k,v in out['check_layer']['finite_games'].items()if k in('candidate_counts','finite_event_net_delta','actual_game_seconds','family_bootstrap95','by_board','execution_disallowed')},indent=2))
