"""Characterize the frozen sampled domain without filtering or searching."""
from pathlib import Path
from collections import Counter
import json
P=Path('.local_agent/q1-component-20261016');plan=json.loads((P/'plan.json').read_bytes());rows=[]
for case in plan['inputs']:
 d=json.loads((P/'inputs'/f"{case['seed']}.json").read_bytes());rs=d['ruleset'];root=d['root'];pos=root['state']['position']if root else{}
 rows.append(dict(**case,input_state=d['state'],has_root=root is not None,piece_types=len(rs['piece_types']),movement_atom_kinds=dict(Counter(a['kind']for t in rs['piece_types']for a in t['movement_atoms'])),hybrid_types=sum(len({a['kind']for a in t['movement_atoms']})>1 for t in rs['piece_types']),promotable_types=sum(t['is_promotable']for t in rs['piece_types']),promotion_targets=sum(len(t['promotion_target_ids'])for t in rs['piece_types']),drop_mask_entries=len(rs['drop_allowed']),drop_true_owner_squares=sum(sum(sum(owner)for owner in v)for v in rs['drop_allowed'].values()),root_ply=None if root is None else root['state']['ply_count'],root_history_events=None if root is None else len(root['state']['history']),aux_state=pos.get('aux_state'),max_ply=rs['max_ply'],repetition_limit=rs['repetition_limit']))
out=dict(complete=True,rows=rows,selection='All9 frozen generator families with no replacement/search filter. Mechanism counts characterize this subset, not complete-domain coverage.',limits=['Legacy serialized generated rules include sampled promotion/drop/hybrid movement and full history. This is not every auxiliary-state/declaration/adjudication/new-rule domain. The long-term generic target still includes those mechanisms.','Input export failures did not remove/replace any rule family.','Immediate root wins and other trivial/easy games must remain; report their frequency after all frozen games close, rather than filter after outcomes.'])
(P/'scope.json').write_bytes(json.dumps(out,indent=2).encode());print(json.dumps(out,indent=2))
