from pathlib import Path
import json,sys,collections,math
from fractions import Fraction
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path('.local_agent/spatial-snapshot-20261017');T=D/'aux89-exact/results/dev_aux/task2525';V=D/'aux89-exact/results/dev_aux/task2526';write_json(D/'generic-information-plan.json',dict(question='Do actual new Generic TD traces leave entire trainable feature directions unobserved, making mere longer repetitions an unsuitable coverage remedy?',premise='Previous rank4Chessresult does not describe new six-channel generated promotion/drop learner. Use actual leaf sensitivities, not queried-root counts or terminal padding.',data='Closed32episodes/657queries/fourrules/twoinitials only, no new targets/training/fitness.',forecast_seconds=10,cap_seconds=60,decision='If a free input direction is structurally absent in these traces report it and reconsider sampling premise, never require rank as a universal development gate. Full rank is not price identification/strength. Per-seed4episode update rank<=4 is not evidence of failure.'))
qq=[json.loads(x)for x in(T/'queries.jsonl').read_text().splitlines()];ee=[json.loads(x)for x in(T/'episodes.jsonl').read_text().splitlines()]
def rank(matrix):
 basis={}
 for row in matrix:
  v=list(map(Fraction,row))
  for pivot,b in sorted(basis.items()):
   k=v[pivot]
   if k:v=[x-k*y for x,y in zip(v,b)]
  pivot=next((i for i,x in enumerate(v)if x),None)
  if pivot is not None:
   k=v[pivot];basis[pivot]=[x/k for x in v]
 return len(basis)
rows=[]
for gs in sorted({q['generator_seed']for q in qq}):
 q=[q for q in qq if q['generator_seed']==gs];nonterminal=[x for x in q if x['complete']and not x['pv_terminal']];free=[x['pv_phi'][1:]for x in nonterminal];roots=[x['features'][1:]for x in q];channels=q[0]['channels'][1:]
 rows.append(dict(rule=gs,queries=len(q),complete=sum(x['complete']for x in q),terminal_pv=sum(x['complete']and x['pv_terminal']for x in q),nonterminal_pv=len(nonterminal),failed=sum(not x['complete']for x in q),trainable_dimensions=len(channels),root_free_rank_exact=rank(roots),leaf_free_rank_exact=rank(free),never_observed_leaf_channels=[c for i,c in enumerate(channels)if all(x[i]==0 for x in free)],nonzero_actual_gradients=sum(any(x['gradient'][1:])for x in nonterminal),all_zero_nonterminal_inputs=sum(not any(x)for x in free),per_seed=[dict(seed=s,rank=rank([x['pv_phi'][1:]for x in nonterminal if x['seed']==s]))for s in(1977,8173)]))
# Independently recompute actual paired reward/missing intervals; do not use owner audit functions.
games=[json.loads(x)for x in(V/'games.jsonl').read_text().splitlines()];pairs=collections.defaultdict(dict)
for g in games:pairs[tuple(g['slot'][:-1])][g['slot'][-1]]=g
bounds=[0.,0.];changed=collections.Counter();perrule=collections.defaultdict(lambda:[0.,0.,0]);n=0
for key,arms in pairs.items():
 assert set(arms)=={'initial','trained'};u=[]
 for k in('initial','trained'):
  r=arms[k]['reward'];u.append((-1.,1.)if r is None else(r,r))
 lo=u[1][0]-u[0][1];hi=u[1][1]-u[0][0];bounds[0]+=lo;bounds[1]+=hi;n+=1;perrule[key[0]][0]+=lo;perrule[key[0]][1]+=hi;perrule[key[0]][2]+=1
 if any(g['reward']is None for g in arms.values()):changed['unresolved']+=1
 else:
  x=arms['trained']['reward']-arms['initial']['reward'];changed['improved'if x>0 else'worse'if x<0 else'same_reward']+=1
 changed['identical_records']+=arms['initial']['record']==arms['trained']['record']
write_json(D/'generic-information.json',dict(status='COMPLETE',rows=rows,episode_count=len(ee),actual_nonzero_updates=sum(x['initial_weights']!=x['weights']for x in ee),paired_games=len(games),pairs=n,pooled_gain_bounds=[x/n for x in bounds],per_rule=[dict(rule=k,bounds=[v[0]/v[2],v[1]/v[2]],pairs=v[2])for k,v in sorted(perrule.items())],behavior=dict(changed),scope='Independent exact rational input-span and paired arithmetic on TRAIN-exposed four-rule closed data. Terminal leaf constants carry zero own derivative, not missing/ordinary zero features. Rank is necessary local sensitivity only, not unique price/utility/generalization.'))
print(json.dumps(json.loads((D/'generic-information.json').read_bytes()),indent=2))
