from pathlib import Path
import json,sys,statistics
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path('.local_agent/spatial-snapshot-20261017');v=json.loads((D/'activation/result.json').read_bytes());summary=dict(status=v['status'],query_roots=v['query_roots'],history_edges=v['logical_history_edges'],binding_multiplicities=v['semantic_binding_multiplicities'],models=len(v['models']),raw_changed=sum(r['raw_changed']for r in v['models']),scales={},scope=v['scope'])
for scale in ('1','256'):
 errors=[r['scales'][scale]['absolute_error']for r in v['rows']];summary['scales'][scale]=dict(models_changed=sum(r['scales'][scale]['quantized_changed']for r in v['models']),max_error=max(errors),median_error=statistics.median(errors),rms_error=(sum(e*e for e in errors)/len(errors))**.5,max_normalized_error=max(r['scales'][scale]['normalized_error']for r in v['rows']))
write_json(D/'activation-summary.json',summary);print(json.dumps(summary,indent=2))
w=json.loads((D/'whole-collector/result.json').read_bytes());s=dict(status=w['status'],rules=len(w['rows']),whole_trajectories_equal=all(r['full_trajectories_equal']for r in w['rows']),total_seconds={},total_spatial_seconds={},points=sum(r['arms']['copy']['points']for r in w['rows']),physical_collectors=w['physical_game_collectors'],scope=w['scope'])
for arm in ('replay','copy'):
 s['total_seconds'][arm]=sum(r['arms'][arm]['seconds']for r in w['rows']);s['total_spatial_seconds'][arm]=sum(r['arms'][arm]['spatial_seconds']for r in w['rows'])
s['pooled_total_ratio']=s['total_seconds']['replay']/s['total_seconds']['copy'];s['points_only_with_both_arms']=s['points'];write_json(D/'whole-summary.json',s);print(json.dumps(s,indent=2))
