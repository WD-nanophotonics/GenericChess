from pathlib import Path
import sys,json,time,math,collections,hashlib,traceback
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import BoardMove,DropMove,SemanticBoardMove,SemanticDropMove
from generic_chess.learning.features import material_features
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import evaluate
D=Path('.local_agent/spatial-snapshot-20261017');T=D/'aux89-exact/results/dev_aux/task2525';O=D/'activation';O.mkdir(exist_ok=False)
plan=dict(question='Can actual published AUX board-CURRENT/hand-BASE learned prices activate current semantic Native evaluation without losing updates to integer rounding?',premise='AUX89 now actually trains four generated rules; old only-Chess feasibility premise superseded. Native checkpoint material-only default scale1 exists; explicit256 is already supported, no default/API change.',query_source='Closed657GenericTRAINqueries, same eight models; no new game/search/training/learner.',scales=[1,256],forecast_seconds=60,cap_seconds=180,history='Rebuild legacy and semantic paths from actual original actions. Keep all semantic matches, choose deterministic first solely as a scoped representative; record multiplicity, compare full visible positions/outcomes at each step, never reuse legacy history keys or claim identical action signatures/all-domain adapter.',decision='If scale1 erases distinct learned models, require explicit activation precision in any future real integration. Use current supported scale256 privately and disclose its coefficient/input error bound. No new converter API or product behavior.')
write_json(O/'plan.json',plan);start=time.monotonic();train=json.loads((T/'result.json').read_bytes());arms={(a['generator_seed'],a['seed']):a for a in train['arms']};compiled={};native={};legacy={};models=[]
for gs in sorted({k[0]for k in arms}):
 rule=ruleset_from_dict(json.loads((T/f'rules-{gs}.json').read_bytes()));legacy[gs]=compile_ruleset(rule);compiled[gs]=compile_legacy_ruleset_for_semantic_execution(rule);native[gs]=compile_native_semantic_rules(compiled[gs])
def cp_for(a,w,scale):
 maps={k:{t:v for(kind,t),v in zip(a['channels'],w)if kind==k}for k in('board','hand')}
 return LearnableMaterialCheckpoint(ruleset_fingerprint=compiled[a['generator_seed']].ruleset_fingerprint,board_weights=maps['board'],hand_weights=maps['hand'],material_scale=scale,value_scale=10.,reference_median=1.)
for key,a in arms.items():
 item=dict(rule=key[0],seed=key[1],raw_changed=a['initial']!=a['weights'],scales={})
 for scale in plan['scales']:
  n=native[key[0]];p=cp_for(a,a['initial'],scale);q=cp_for(a,a['weights'],scale);item['scales'][str(scale)]=dict(initial_board=p.semantic_quantized_board(n.type_ids),initial_hand=p.semantic_quantized_hand(n.type_ids),trained_board=q.semantic_quantized_board(n.type_ids),trained_hand=q.semantic_quantized_hand(n.type_ids),quantized_changed=(p.semantic_quantized_board(n.type_ids),p.semantic_quantized_hand(n.type_ids))!=(q.semantic_quantized_board(n.type_ids),q.semantic_quantized_hand(n.type_ids)))
 models.append(item)
def matches(old,new):
 if isinstance(old,BoardMove):return isinstance(new,SemanticBoardMove)and(old.from_square,old.to_square,old.promotion_target_id)==(new.from_square,new.to_square,new.promotion_target_id)
 return isinstance(new,SemanticDropMove)and(old.base_type_id,old.to_square)==(new.base_type_id,new.to_square)
rows=[];multiplicity=collections.Counter();edges=0;status='COMPLETE';reason=None
try:
 for line in(T/'queries.jsonl').open():
  if time.monotonic()-start>=180:raise TimeoutError('FROZEN_CAP')
  q=json.loads(line);gs=q['generator_seed'];c=compiled[gs];n=native[gs];a=arms[gs,q['seed']];s=GameSession(c);l=GameSession(legacy[gs]);original=deserialize_game_record(json.dumps(q['record_before']))
  for old in original.actions:
   legal=[x for x in s.legal_actions()if matches(old,x)];assert legal; multiplicity[len(legal)]+=1
   chosen=sorted(legal,key=repr)[0];s.submit(chosen);l.submit(old);edges+=1
   assert s.state.position==l.state.position
   assert (s.result.status,s.result.winner)==(l.result.status,l.result.winner)
  phi=tuple(sum((1 if p.owner==0 else-1)for p in s.state.position.board if p is not None and p.current_type_id==t)if kind=='board'else s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t)for kind,t in a['channels']);assert list(phi)==q['features'];packed=pack_semantic_search_position(c,n,s);row=dict(rule=gs,seed=q['seed'],game=q['game'],ply=q['ply'],feature=phi,root_history_length=len(s.state.history),prices=q['weights'],raw=sum(x*w for x,w in zip(phi,q['weights'])),scales={})
  for scale in plan['scales']:
   cp=cp_for(a,q['weights'],scale);cp.validate_ruleset(c);bw=cp.semantic_quantized_board(n.type_ids);hw=cp.semantic_quantized_hand(n.type_ids);raw=evaluate(n,packed,board_values=bw,hand_values=hw,evaluator_scale=scale);owner0=raw*(1 if s.state.position.side_to_move==0 else-1)/scale
   direct=sum(x*round(w*scale)/scale for x,w in zip(phi,q['weights']));assert abs(owner0-direct)<1e-12
   bound=sum(abs(x)for x in phi)/(2*scale);error=abs(owner0-row['raw']);assert error<=bound+1e-12;row['scales'][str(scale)]=dict(native_owner0=owner0,absolute_error=error,feature_count_bound=bound,normalized_error=abs(math.tanh(owner0/10)-math.tanh(row['raw']/10)))
  rows.append(row)
except Exception as e:status='ERROR';reason=repr(e);traceback.print_exc()
write_json(O/'result.json',dict(status=status,reason=reason,models=models,rows=rows,query_roots=len(rows),logical_history_edges=edges,semantic_binding_multiplicities=dict(multiplicity),seconds=time.monotonic()-start,scope='Private explicit semantic representative replays and existing256precision, not originallegacyhistoryidentity/all-domainadapter/search/strength/newtraining or productdefaultadoption.'))
print('CLOSED',status,len(rows),edges,dict(multiplicity),round(time.monotonic()-start,3),reason)
