from pathlib import Path
import json, sys, time, copy, hashlib, statistics, traceback
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import spatial_features
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove, SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.learning.selfplay import _spatial_snapshot
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.learning.features import non_anchor_type_ids
D=Path('.local_agent/spatial-snapshot-20261017'); D.mkdir(exist_ok=True)
source=Path('.local_agent/td-tree-20261017/generic-prefix-v2/result.json')
plan=dict(question='Does full-root replay dominate the actual optional v3 control snapshot and can a shallow session copy preserve complete state and witnesses?',slots=list(range(0,72,8)),prefixes=[0,16,64],pv='First recorded next action if present, otherwise first current legal typed binding; one action only, terminal cases kept.',repetitions=12,forecast_seconds=60,cap_seconds=120,decision='Measure existing full snapshot plus private candidate; no source adoption until complete child/witness/parent isolation plus representative auxiliary-state tests. No new games, search, training, filter or AUX writes.',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
write_json(D/'plan.json',plan); start=time.monotonic(); rows=[]
def poll():
 if time.monotonic()-start>=120:raise TimeoutError('FROZEN_CAP')
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path('.local_agent')/(n+'.json')).read_bytes())
  if f.get('user_paused')or f.get('stopped'):raise InterruptedError('EXPLICIT_STOP')
def action(a):
 return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id']) if 'from_square'in a else SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def image(s):return dict(state=record_value(s.state),record=record_value(s.to_record()),history=record_value(s.history),witnesses=record_value(s._search_witnesses),result=record_value(s.result))
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
v=json.loads(source.read_bytes()); rules={r['slot']:r['ruleset']for r in v['rules']};records={r['slot']:r for r in v['rows']};status='COMPLETE';reason=None
try:
 for slot in plan['slots']:
  poll(); row=records[slot]; c=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(rules[slot]))); n=compile_native_semantic_rules(c); types=non_anchor_type_ids(c)
  cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,board_weights={t:1. for t in types},hand_weights={t:1. for t in types},value_scale=10.,reference_median=1.,localized_control_weights=(1.,0.,0.,0.,0.,0.,0.,0.,-1.))
  s=GameSession(c); aa=[action(a)for a in row['final_record']['actions']]
  for h in plan['prefixes']:
   poll()
   if len(aa)<h:rows.append(dict(slot=slot,prefix=h,status='ABSENT_EARLY_TERMINAL',actual_terminal_ply=len(aa)));continue
   while s.state.ply_count<h:s.submit(aa[s.state.ply_count])
   parent=image(s)
   if s.result.status.value!='ongoing':rows.append(dict(slot=slot,prefix=h,status='ACTUAL_TERMINAL',parent_sha256=digest(parent)));continue
   pv=(aa[h],)if h<len(aa)else(s.legal_actions()[0],)
   replay=GameSession.replay(c,s.to_record()); candidate=copy.copy(s)
   for a in pv:replay.submit(a);candidate.submit(a)
   assert image(replay)==image(candidate)
   assert image(s)==parent
   old=_spatial_snapshot(c,n,s,pv,cp,replay.state)
   def proposed():
    if candidate.state.terminal_status.is_terminal:return (),()
    child=copy.copy(s)
    for a in pv:child.submit(a)
    return (),spatial_features(n,pack_semantic_search_position(c,n,child))['localized_control']
   assert old==proposed(); timing={key:[]for key in ('replay','copy','pack','extract','full_existing','full_candidate')}
   for rep in range(plan['repetitions']):
    poll()
    # Alternate order to limit systematic first/second effects; no isolated-load claims.
    jobs=[('replay',lambda:GameSession.replay(c,s.to_record())),('copy',lambda:copy.copy(s)),('pack',lambda:pack_semantic_search_position(c,n,candidate)),('extract',lambda:spatial_features(n,packed)),('full_existing',lambda:_spatial_snapshot(c,n,s,pv,cp,replay.state)),('full_candidate',proposed)]
    packed=pack_semantic_search_position(c,n,candidate)
    for key,fn in jobs[::(-1 if rep%2 else 1)]:
     t=time.perf_counter_ns();out=fn();timing[key].append(time.perf_counter_ns()-t)
   assert image(s)==parent
   result=dict(slot=slot,board=row['board'],preset=row['preset'],prefix=h,status='RETURNED',pv=record_value(pv),leaf_terminal=replay.state.terminal_status.is_terminal,parent_sha256=digest(parent),child_sha256=digest(image(candidate)),complete_state_record_history_witness_result_equal=True,parent_unchanged=True,features=record_value(old),timing_ns=timing,median_ns={k:statistics.median(x)for k,x in timing.items()})
   rows.append(result); print(slot,h,result['median_ns'],flush=True)
except Exception as e:status='ERROR';reason=repr(e);traceback.print_exc()
write_json(D/'result.json',dict(status=status,reason=reason,rows=rows,seconds=time.monotonic()-start,scope='Exposed nine scoped atom-generated rules only, no full-domain equivalence, whole-learning cost or strength claim. All microtimings include ordinary concurrent machine load.'))
print('CLOSED',status,len(rows),round(time.monotonic()-start,3),reason,flush=True)
