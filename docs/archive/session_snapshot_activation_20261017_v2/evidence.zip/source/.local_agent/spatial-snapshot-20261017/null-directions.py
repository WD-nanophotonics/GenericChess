from pathlib import Path
import json,sys,math,collections,time,traceback
from fractions import Fraction as F
from functools import reduce
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import BoardMove,SemanticBoardMove,SemanticDropMove
from generic_chess.core.transition import apply_action,legal_actions
D=Path('.local_agent/spatial-snapshot-20261017');T=D/'aux89-exact/results/dev_aux/task2525';O=D/'null-directions';O.mkdir(exist_ok=False)
write_json(O/'plan.json',dict(question='Are the observed rank4/5 Generic PV-price directions absent throughout rules, or only absent in this short actual training support?',decision='Produce exact null vectors and a first existing-root/one-edge witness if present. Do not call no-witness structural proof or add rank/fullWDL as prerequisite. No retraining/label fit, no adaptive price intervention.',forecast_seconds=20,cap_seconds=120,max_existing_roots_per_rule=128,max_child_transitions_per_rule=2048,selection='First two lowrank rules in IDorder; first original-record roots, deterministic firstmatching typed binding; existing root first then exhaustive bounded one-edge children, retain absent outcome.'))
q=[json.loads(x)for x in(T/'queries.jsonl').read_text().splitlines()];episodes=[json.loads(x)for x in(T/'episodes.jsonl').read_text().splitlines()];start=time.monotonic();rows=[]
def null(matrix,n):
 a=[list(map(F,r))for r in matrix];piv=[];r=0
 for j in range(n):
  k=next((k for k in range(r,len(a))if a[k][j]),None)
  if k is None:continue
  a[r],a[k]=a[k],a[r];d=a[r][j];a[r]=[x/d for x in a[r]]
  for k in range(len(a)):
   if k!=r and a[k][j]:
    d=a[k][j];a[k]=[x-d*y for x,y in zip(a[k],a[r])]
  piv.append(j);r+=1
  if r==len(a):break
 out=[]
 for j in range(n):
  if j in piv:continue
  v=[F(0)]*n;v[j]=F(1)
  for k,p in enumerate(piv):v[p]=-a[k][j]
  den=math.lcm(*(x.denominator for x in v));ints=[int(x*den)for x in v];g=reduce(math.gcd,ints);out.append([x//abs(g)for x in ints])
 return out

def matches(old,new):
 if isinstance(old,BoardMove):return isinstance(new,SemanticBoardMove)and(old.from_square,old.to_square,old.promotion_target_id)==(new.from_square,new.to_square,new.promotion_target_id)
 return isinstance(new,SemanticDropMove)and(old.base_type_id,old.to_square)==(new.base_type_id,new.to_square)
for gs in(271002,271004):
 qq=[x for x in q if x['generator_seed']==gs];leaf=[x['pv_phi'][1:]for x in qq if x['complete']and not x['pv_terminal']];channels=qq[0]['channels'][1:];vectors=null(leaf,len(channels));assert all(sum(a*b for a,b in zip(phi,v))==0for phi in leaf for v in vectors)
 row=dict(rule=gs,channels=channels,vectors=vectors,ordinary_nonterminal_leaf_count=len(leaf),episode_null_update_errors=[],root_or_child_witnesses=[])
 for v in vectors:
  errs=[abs(sum((after-before)*n for after,before,n in zip(e['weights'][1:],e['initial_weights'][1:],v)))for e in episodes if e['generator_seed']==gs];row['episode_null_update_errors'].append(max(errs,default=0))
 c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(json.loads((T/f'rules-{gs}.json').read_bytes())));transitions=0
 def phi(p):return[sum(1 if x.owner==0 else-1 for x in p.board if x is not None and x.current_type_id==t)if k=='board'else p.hands[0].count(t)-p.hands[1].count(t)for k,t in channels]
 for v in vectors:
  witness=None;closedroots=0
  for qr in qq[:128]:
   if time.monotonic()-start>120:raise TimeoutError('FROZEN_CAP')
   s=GameSession(c)
   for old in deserialize_game_record(json.dumps(qr['record_before'])).actions:
    choices=[a for a in s.legal_actions()if matches(old,a)];assert len(choices)==1;s.submit(choices[0])
   closedroots+=1;f=phi(s.state.position);dot=sum(x*y for x,y in zip(f,v))
   if dot:witness=dict(kind='EXISTING_QUERIED_ROOT',source=dict(seed=qr['seed'],game=qr['game'],ply=qr['ply']),phi=f,dot=dot,semantic_record=record_value(s.to_record()));break
   for a in s.legal_actions():
    if transitions>=2048:break
    transitions+=1;child=apply_action(s.state,a,c);f=phi(child.position);dot=sum(x*y for x,y in zip(f,v))
    if dot and not child.terminal_status.is_terminal:witness=dict(kind='LEGAL_NONTERMINAL_ONE_EDGE',source=dict(seed=qr['seed'],game=qr['game'],ply=qr['ply']),phi=f,dot=dot,semantic_record=record_value(s.to_record()),action=record_value(a),complete_child=record_value(child));break
   if witness or transitions>=2048:break
  row['root_or_child_witnesses'].append(dict(vector=v,checked_roots=closedroots,child_transitions=transitions,witness=witness,meaning='Perturbing free weights along this vector leaves ALL observed ordinary leaf predictions unchanged, yet this lawful untrained-support state changes if a witness exists. No perturbation was deployed or trained.'))
 rows.append(row)
write_json(O/'result.json',dict(status='COMPLETE',rows=rows,seconds=time.monotonic()-start,scope='Exact finite-data null directions and bounded real-session witnesses, not structural full-domain nonidentifiability or useful extra coverage/strength proof.'))
print(json.dumps(dict(status='COMPLETE',rows=[dict(rule=r['rule'],vectors=r['vectors'],null_update_errors=r['episode_null_update_errors'],witnesses=[x['witness']['kind']if x['witness']else None for x in r['root_or_child_witnesses']],checked=[(x['checked_roots'],x['child_transitions'])for x in r['root_or_child_witnesses']])for r in rows],seconds=time.monotonic()-start),indent=2))
