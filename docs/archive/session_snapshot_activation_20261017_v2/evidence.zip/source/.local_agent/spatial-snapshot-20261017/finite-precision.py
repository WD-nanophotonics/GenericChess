from pathlib import Path
import sys,json,time,collections,copy,hashlib,traceback
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import BoardMove,SemanticBoardMove,SemanticDropMove
from generic_chess.core.transition import apply_action,legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.learning.material import LearnableMaterialCheckpoint
D=Path('.local_agent/spatial-snapshot-20261017');T=D/'aux89-exact/results/dev_aux/task2525';O=D/'finite-precision';O.mkdir(exist_ok=False)
plan=dict(question='Does erased learned-price precision change finite D2 choices, and does supported precision256 preserve actual floating-model action preferences?',roots='First and last CLOSED query of each of8arms in original stream (16attempted slots, duplicates retained). TRAIN-exposed roots, not validation/newgames.',models='Each arm initial+final; unquantized scalar Core D2, and existing Native scales1/256. All outcomes, optimal tie sets and incomplete searches retained, no winner/policy selection.',forecast_seconds=60,cap_seconds=180,max_leaf_visits=200000,depth=2,native_nodes=8192,native_seconds=2.,decision='Diagnose activation fidelity only; no strength claim or source/default/learner change. Exact terminal dominates finite material, terminal scores encode Native mate distance separately; compare lawful action membership, never board coalescence.')
write_json(O/'plan.json',plan);start=time.monotonic();v=json.loads((T/'result.json').read_bytes());arms={(a['generator_seed'],a['seed']):a for a in v['arms']};groups=collections.defaultdict(list)
for line in(T/'queries.jsonl').open():
 q=json.loads(line);groups[q['generator_seed'],q['seed']].append(q)
roots=[(key,which,groups[key][i])for key in sorted(groups)for which,i in(('first',0),('last',-1))];rows=[];visits=0;status='COMPLETE';reason=None

def poll():
 if time.monotonic()-start>=180 or visits>=200000:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for name in('rollout','advisor','slack'):
  f=json.loads((Path('.local_agent')/(name+'.json')).read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')
def match(old,new):
 if isinstance(old,BoardMove):return isinstance(new,SemanticBoardMove)and(old.from_square,old.to_square,old.promotion_target_id)==(new.from_square,new.to_square,new.promotion_target_id)
 return isinstance(new,SemanticDropMove)and(old.base_type_id,old.to_square)==(new.base_type_id,new.to_square)
def signature(a):return json.dumps(record_value(a),sort_keys=True,separators=(',',':'))
try:
 for key,which,q in roots:
  poll();a=arms[key];gs=key[0];rule=ruleset_from_dict(json.loads((T/f'rules-{gs}.json').read_bytes()));c=compile_legacy_ruleset_for_semantic_execution(rule);n=compile_native_semantic_rules(c);s=GameSession(c)
  for old in deserialize_game_record(json.dumps(q['record_before'])).actions:
   aa=[x for x in s.legal_actions()if match(old,x)];assert len(aa)==1;s.submit(aa[0])
  profile=[]
  for scale in(None,1,256):
   for label,w in(('initial',a['initial']),('trained',a['weights'])):profile.append((scale,label,list(w)if scale is None else[round(x*scale)/scale for x in w]))
  def phi(st):
   p=st.position;return[sum(1 if x.owner==0 else-1 for x in p.board if x is not None and x.current_type_id==t)if k=='board'else p.hands[0].count(t)-p.hands[1].count(t)for k,t in a['channels']]
  def walk(st,depth):
   global visits
   visits+=1
   if visits%64==0:poll()
   term=st.terminal_status
   if term.is_terminal:return[0. if term.winner is None else 1e6 if term.winner==0 else-1e6]*len(profile)
   if depth==0:
    fs=phi(st);return[sum(x*w for x,w in zip(fs,p[2]))for p in profile]
   children=[walk(apply_action(st,x,c),depth-1)for x in legal_actions(st,c)];assert children;fn=max if st.position.side_to_move==0 else min
   return[fn(child[i]for child in children)for i in range(len(profile))]
  aa=s.legal_actions();scores=[walk(apply_action(s.state,x,c),1)for x in aa];fn=max if s.state.position.side_to_move==0 else min;best=[fn(x[i]for x in scores)for i in range(len(profile))];opt=[[signature(action)for action,values in zip(aa,scores)if abs(values[i]-best[i])<1e-9]for i in range(len(profile))];native_rows=[]
  for i,(scale,label,w)in enumerate(profile):
   if scale is None:continue
   cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,board_weights={t:x for(k,t),x in zip(a['channels'],w)if k=='board'},hand_weights={t:x for(k,t),x in zip(a['channels'],w)if k=='hand'},material_scale=scale,value_scale=10.,reference_median=1.)
   engine=SemanticSearchEngine(c,n,checkpoint=cp,tt_megabytes=0);before=(s.state,s.to_record(),s._search_witnesses);t=time.perf_counter();r=engine.search(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=2.,quiescence_max_depth=0),root_window_pruning=False);elapsed=time.perf_counter()-t;assert before==(s.state,s.to_record(),s._search_witnesses)
   chosen=signature(r.action)if r.action is not None else None;native_rows.append(dict(scale=scale,label=label,completed_depth=r.completed_depth,nodes=r.nodes,seconds=elapsed,reason=r.termination_reason,action=chosen,score=r.score,belongs_to_corresponding_core_optimal_set=chosen in opt[i],core_best=best[i],pv=record_value(r.principal_variation)))
  row=dict(rule=gs,seed=key[1],which=which,source_query=dict(game=q['game'],ply=q['ply']),original_record=q['record_before'],semantic_record=record_value(s.to_record()),profiles=[dict(scale=p[0],label=p[1],best=best[i],optimal=opt[i])for i,p in enumerate(profile)],native=native_rows);rows.append(row);write_json(O/'partial.json',dict(rows=rows,visits=visits));print(gs,key[1],which,'visits',visits,'native_matches',[r['belongs_to_corresponding_core_optimal_set']for r in native_rows],flush=True)
except Exception as e:status='ERROR';reason=repr(e);traceback.print_exc()
write_json(O/'result.json',dict(status=status,reason=reason,planned=len(roots),returned=len(rows),rows=rows,core_visits=visits,seconds=time.monotonic()-start,scope='Finite D2 scalar arithmetic/actualNative activation on TRAIN-exposed roots; no new games/learning/strength/general-domain proof. Same rule authority, separately authored exhaustive arithmetic.'))
print('CLOSED',status,len(rows),visits,round(time.monotonic()-start,3),reason,flush=True)
