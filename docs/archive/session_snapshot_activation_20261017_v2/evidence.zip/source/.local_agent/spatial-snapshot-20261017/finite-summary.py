from pathlib import Path
import json,sys,collections
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path('.local_agent/spatial-snapshot-20261017');v=json.loads((D/'finite-precision/result.json').read_bytes());summary=dict(status=v['status'],roots=v['returned'],core_visits=v['core_visits'],seconds=v['seconds'],native_queries=sum(len(r['native'])for r in v['rows']),native_legal_optimal=sum(n['belongs_to_corresponding_core_optimal_set']for r in v['rows']for n in r['native']),completedD2=sum(n['completed_depth']==2 for r in v['rows']for n in r['native']),comparison=[])
for r in v['rows']:
 p={(str(x['scale']),x['label']):set(x['optimal'])for x in r['profiles']};item={k:r[k]for k in('rule','seed','which')}
 item['float_initial_vs_trained_optimal_changed']=p['None','initial']!=p['None','trained']
 for scale in ('1','256'):
  item[scale]=dict(initial_vs_trained_optimal_changed=p[scale,'initial']!=p[scale,'trained'],initial_equals_float=p[scale,'initial']==p['None','initial'],trained_equals_float=p[scale,'trained']==p['None','trained'],native_identical_action=next(n['action']for n in r['native']if str(n['scale'])==scale and n['label']=='initial')==next(n['action']for n in r['native']if str(n['scale'])==scale and n['label']=='trained'))
 summary['comparison'].append(item)
write_json(D/'finite-summary.json',summary);print(json.dumps(summary,indent=2))
