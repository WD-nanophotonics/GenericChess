from pathlib import Path
import sys,json,time,hashlib,traceback,importlib.util
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.learning.features import non_anchor_type_ids
import generic_chess.learning.selfplay as live
D=Path('.local_agent/spatial-snapshot-20261017');o=D/'whole-collector';o.mkdir(exist_ok=False)
plan=dict(question='Does the measured control-snapshot improvement affect actual frozen self-play collection cost and leave full trajectories unchanged?',changed_premise='Nine-rule component control plus real auxiliary/alternate-start context tests support standard private copy; actual surrounding Native search cost remains unmeasured.',slots=list(range(0,72,8)),games_per_arm=1,horizon=32,depth=1,nodes=10000,epsilon=0.,seed=20261017,forecast_seconds=90,cap_seconds=240,decision='Keep fulltrajectory/ID/outcome equality requirement and disclose limited cost, no training/strength/newlearning algorithm. No after-result cap extension or rule selection.',order='Alternate replay/copy-first by original slot index; normal concurrent load is a limitation.')
write_json(o/'plan.json',plan);spec=importlib.util.spec_from_file_location('generic_chess.learning._snapshot_before',D/'selfplay-before.py');old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old);new=live._spatial_snapshot;start=time.monotonic();rows=[];status='COMPLETE';reason=None
v=json.loads(Path('.local_agent/td-tree-20261017/generic-prefix-v2/result.json').read_bytes());rules={r['slot']:r['ruleset']for r in v['rules']}
def poll():
 if time.monotonic()-start>=240:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for n in('rollout','advisor','slack'):
  f=json.loads((Path('.local_agent')/(n+'.json')).read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')
try:
 for index,slot in enumerate(plan['slots']):
  poll();c=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(rules[slot])));n=compile_native_semantic_rules(c);types=non_anchor_type_ids(c)
  cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,board_weights={t:1. for t in types},hand_weights={t:1. for t in types},value_scale=10.,reference_median=1.,localized_control_weights=(1.,0.,0.,0.,0.,0.,0.,0.,-1.))
  results={}
  for arm in(('replay','copy')if index%2==0 else('copy','replay')):
   fn=old._spatial_snapshot if arm=='replay'else new;spatial_seconds=0.;calls=0
   def wrapper(*args):
    global spatial_seconds,calls
    poll();stamp=time.perf_counter();result=fn(*args);spatial_seconds+=time.perf_counter()-stamp;calls+=1;return result
   live._spatial_snapshot=wrapper;t=time.perf_counter();tr=live.collect_self_play(c,n,cp,live.SelfPlayConfig(games=1,nodes_per_move=10000,max_depth=1,max_plies=32,seed=20261017,epsilon=0.,tt_megabytes=0));seconds=time.perf_counter()-t
   data=[x.to_dict()for x in tr];write_json(o/f'{slot}-{arm}.json',data);results[arm]=dict(seconds=seconds,spatial_seconds=spatial_seconds,snapshot_calls=calls,trajectory_sha256=hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest(),points=len(tr[0].points),outcome=tr[0].terminal,truncated=tr[0].truncated)
   print(slot,arm,results[arm],flush=True)
  assert results['copy']['trajectory_sha256']==results['replay']['trajectory_sha256'];rows.append(dict(slot=slot,arms=results,full_trajectories_equal=True));write_json(o/'partial.json',dict(rows=rows))
except Exception as e:status='ERROR';reason=repr(e);traceback.print_exc()
finally:live._spatial_snapshot=new
write_json(o/'result.json',dict(status=status,reason=reason,rows=rows,seconds=time.monotonic()-start,missing_rules=len(plan['slots'])-len(rows),new_training=0,physical_game_collectors=2*len(rows),scope='Frozen artificial unfitted v3 offsets / same public nine atom-generated rules; cost/trajectory integrity only, no learned strength or all-domain claim. Partial/error slots retained.'))
print('CLOSED',status,len(rows),round(time.monotonic()-start,3),reason,flush=True)
