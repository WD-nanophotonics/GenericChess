from pathlib import Path
import json,sys
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.position import Position,Hands,GameState,HistoryRecord
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from scripts.research_record import write_record,record_value
inputs=json.loads(Path('.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes());records=[];n=0
for root,inp in inputs.items():
 c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(inp['rules'])));d=inp['state'];p=dict(d['position']);p['board']=tuple(Piece(**x) if x else None for x in p['board']);p['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in p['hands']);p['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in p['aux_state']);state=GameState(Position(**p),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));owner=state.position.side_to_move
 for row in json.loads(Path('.local_agent/q0-delivery-after-20261012/result.json').read_bytes())['rows']:
  if row['root']!=root:continue
  ss=state
  for item in row['result']['principal_variation']:
   matches=[a for a in legal_actions(ss,c) if record_value(a)==item];assert len(matches)==1;ss=apply_action(ss,matches[0],c);n+=1
  v=[0,0]
  for pc in ss.position.board:
   if pc:v[pc.owner]+=inp['board'][pc.current_type_id]
  for side,h in enumerate(ss.position.hands):
   for tid,count in h.counts:v[side]+=inp['hand'][tid]*count
  score=v[owner]-v[1-owner];records.append(dict(root=root,arm=row['arm'],order=row['order'],budget=row['budget_seconds'],depth=row['result']['completed_depth'],score=row['result']['score'],literal_material=score,terminal=record_value(ss.terminal_status),literal_matches=score==row['result']['score']))
write_record(Path('.local_agent/q0-delivery-after-20261012/literal-PV-verification.json'),dict(actions=n,records=records,scope='Independent Core legal replay. Oldtrace mismatch retained, differentcompleteddepth not utility. Failed firstinline verifier KeyError kind: record_value dataclassprojection isnot action_to_dict transport; corrected by exact legalactionprojection matching, no search rerun.'))
print(n);print(records)
