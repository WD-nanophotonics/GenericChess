import sys,json,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/q0-root-hint-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does existing root_order_hint from an independent fixedD3 Native/Core query improve1091 delivery after canonical repair?',calls=16,arms=['none','nativeD3','coreD3'],hint_calls=2,fixed_depth=4,fixed_seconds=64,delivery_seconds=16,delivery_depth=12,nodes=1000000,tt_MiB=1,q=0,orders=['forward','reverse'],scope='12consumercalls and4hintpreparations (freshhintpair perorder). Frozen49744559 source/fullhistory/material. Same total16s consumer envelope includes measured hint preparation; no adaptive/exposed choice, use actual original returnedactions, no root filter. Freshisolated Native consumer TT eacharm; hint engineTT0. No q4/API/default/UI/capraise/strength. <8min estimate.'))
d=json.loads((ROOT/'tests/development/data/native_q0_aux_pv_1091.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(d['rules'])));s=GameSession(c)
for h in d['state']['history'][1:]:s.submit(action_from_dict(json.loads(h['action_signature'])))
class Frozen:
 def evaluate(self,s):
  p=s.position;v=[0,0]
  for pc in p.board:
   if pc:v[pc.owner]+=d['board'][pc.current_type_id]
  for side,h in enumerate(p.hands):
   for tid,n in h.counts:v[side]+=d['hand'][tid]*n
  return v[p.side_to_move]-v[1-p.side_to_move]
 def type_value(self,tid):return d['board'][tid]
 def capture_order_value(self,a,b):return 10*self.type_value(b.current_type_id)-self.type_value(a.current_type_id)
provider=NativeSemanticLegalityProvider.try_create(c,strict=True);rows=[];hints=[]
def native_engine(tt):return SemanticSearchEngine(c,provider.native_rules,board_values=d['board'],hand_values=d['hand'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=tt)
for order,arms in enumerate([['none','nativeD3','coreD3'],['coreD3','nativeD3','none']]):
 prepared={'none':(None,0)}
 for arm in ['nativeD3','coreD3']:
  t=time.perf_counter();lim=SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=16,quiescence_max_depth=0)
  r=native_engine(0).search(s,lim,root_window_pruning=True) if arm=='nativeD3' else AlphaBetaPlayer(c,evaluator_override=Frozen(),use_tt=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=True)).choose_action(s,lim)
  elapsed=time.perf_counter()-t;assert r.completed_depth==3 and r.action in legal_actions(s.state,c);prepared[arm]=(r.action,elapsed);hints.append(dict(arm=arm,order=order,seconds=elapsed,result=record_value(r)))
 for kind in ['fixed','delivery']:
  for arm in arms:
   action,cost=prepared[arm];engine=native_engine(1);before=s.state;w=s._search_witnesses;t=time.perf_counter();r=engine.search(s,SearchLimits(max_depth=4 if kind=='fixed' else 12,max_nodes=1000000,max_time_seconds=64 if kind=='fixed' else 16-cost,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True,root_order_hint=action);elapsed=time.perf_counter()-t;ss=before
   for a in r.principal_variation:assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
   assert s.state is before and s._search_witnesses is w
   if action is not None:assert r.root_hint_legal and r.root_hint_apply_count>0
   rows.append(dict(kind=kind,arm=arm,order=order,seconds=elapsed,total_seconds=elapsed+cost,hint_seconds=cost,result=record_value(r),root_restored=True,pv_legal=True));write_record(out/'result.json',dict(complete=False,hints=hints,rows=rows));print(kind,order,arm,round(elapsed+cost,3),r.completed_depth,r.score,r.nodes,flush=True)
write_record(out/'result.json',dict(complete=True,hints=hints,rows=rows))
