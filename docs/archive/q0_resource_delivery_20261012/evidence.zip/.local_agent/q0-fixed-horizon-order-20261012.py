"""Existing frozen material ordering option, no learning or new search code."""
import sys,json,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess import compile_ruleset_for_execution
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/q0-fixed-horizon-order-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Do min2/min3 ordering comparisons preserve exact finiteD4/D5 withTT0 andcoldTT1 after observed support gains?',calls=24,roots=['generated1091'],arms=['lexical','material_min2','material_min3'],orders=['forward','reverse'],fixed_depths=[4,5],TT_MiB=[0,1],nodes=1000000,q=0,tt_MiB=1,exact_root=True,scope='24fixedD4/D5 calls (3arms*2depths*2TT*2orders), independent freshengine percell. Existing material ordering_checkpoint uses same rulederivedprofile, no training/humanfit, frozen leaf unchanged. Material order is child eval cost and ordering changes, no PVS or q4. Counts/cost/value/PV/legal/fullhistory must be logged; no default/UI/whole-domain/strength claim. Max64s percell; expected<8min from measured q0cost; retainsincompletecells unknown, no rescue; no oldcapraise.'))
inputs=json.loads((ROOT/'.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes());rows=[]
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)
for name,inp in inputs.items():
 if name!='generated1091':continue
 c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(inp['rules'])));d=inp['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));witnesses=tuple(position(x) for x in inp['witnesses']);s=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 provider=NativeSemanticLegalityProvider.try_create(c,strict=True);profile=build_ruleset_profile(c,EvaluationConfig());checkpoint=LearnableMaterialCheckpoint.from_profile(c,profile,dynamic_weights={});write_record(out/(name+'-ordering.json'),checkpoint.to_dict());bv=inp['board'];hv=inp['hand']
 for depth in [4,5]:
  for tt in [0,1]:
   for repeat,arms in enumerate([['lexical','material_min2','material_min3'],['material_min3','material_min2','lexical']]):
    for arm in arms:
     engine=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=tt,ordering_checkpoint=checkpoint if arm!='lexical' else None,ordering_min_depth=int(arm[-1]) if arm!='lexical' else 1);before=record_value(state);t=time.perf_counter();r=engine.search(s,SearchLimits(max_depth=depth,max_nodes=1000000,max_time_seconds=64,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-t;assert record_value(state)==before;ss=state
     for a in r.principal_variation:assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
     assert r.action in legal_actions(state,c);rows.append(dict(root=name,depth=depth,tt_MiB=tt,order=repeat,arm=arm,seconds=elapsed,result=record_value(r),native_leaf=engine.native_evaluator_values,pv_legal=True,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(name,depth,tt,repeat,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,r.ordering_nodes,flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
