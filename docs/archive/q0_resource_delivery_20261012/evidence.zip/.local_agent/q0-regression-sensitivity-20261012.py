import sys,sysconfig,importlib.util,subprocess,hashlib,traceback,time
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from scripts.research_record import write_record
out=ROOT/'.local_agent/q0-regression-sensitivity-20261012';out.mkdir(exist_ok=True)
original=subprocess.check_output(['git','show','497445594d2695653f393e90a29ff9166dbb0466:tests/development/test_native_q0_canonical_replay.py'],text=True)
path=ROOT/'tests/development/test_native_q0_canonical_replay.py';corrected=path.read_text();(out/'original-test.py').write_text(original,encoding='utf-8',newline='\n')
current=native._module();binary=ROOT/'.local_agent/narrow-q0-20261012/baseline'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));spec=importlib.util.spec_from_file_location('sensitivity._native_core',binary);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);rows=[]
write_record(out/'declaration.json',dict(question='Did the published leaf-only regression actually distinguish the observed oldinferior thirdmove?',calls=3,source='49744559 originaltest/currentcorrectedtest',arms=['oldmodule_oldtest','oldmodule_correctedtest','current_correctedtest'],scope='Exact old/current actualtestfunction, all searchconditions sameD4/TT1/1M/64s. Corrected assertion chooses independently scored knownthirdbranch; no searchkernel change ornewsemanticclaim. Short regression overlaps saved-turnbatch ordinaryload, recordtiminglimit rather thanrestart.'))
for label,module,source in [('oldmodule_oldtest',old,original),('oldmodule_correctedtest',old,corrected),('current_correctedtest',current,corrected)]:
 native._MODULE=module;space={'__file__':str(path),'__name__':'research_test'};exec(compile(source,str(path),'exec'),space);t=time.perf_counter()
 try:space['test_exact_root_canonical_replay_does_not_keep_inferior_auxiliary_pv']();status='PASS';error=None
 except AssertionError:status='FAIL';error=traceback.format_exc()
 rows.append(dict(arm=label,status=status,seconds=time.perf_counter()-t,error=error,module_sha256=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),test_sha256=hashlib.sha256(source.encode()).hexdigest()));write_record(out/'result.json',dict(complete=False,rows=rows));print(label,status,flush=True)
native._MODULE=current;assert [x['status'] for x in rows]==['PASS','FAIL','PASS'];write_record(out/'result.json',dict(complete=True,rows=rows,confirmed='Oldleaf-only test falsepassed; correctedthirdaction test detects observedolddefect andcurrent passes. Bothold/newliteralPVleaf=-2514, oldforcedthirdbranchminimax=-4912 versusnew=-2514.'))
