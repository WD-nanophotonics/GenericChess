"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning

from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
import hashlib,random
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)


from generic_chess.ai.cancellation import CancellationToken
base=ROOT/'.local_agent/q0-terminal-proof-20261012/boundary';modules={}
for arm in ['unguarded_injected','guarded_injected','guarded']:
 sp=importlib.util.spec_from_file_location('boundary_'+arm+'._native_core',base/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
samples=json.loads((ROOT/'.local_agent/q0-refine-generated-20261012/samples.json').read_bytes());rows=[]
for sample in samples:
 if not sample['included']:continue
 src=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(sample['rules']));c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 d=sample['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));w=tuple(position(x) for x in sample['witnesses']);session=SimpleNamespace(compiled=c,state=state,_search_witnesses=w,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 bv=sample['board'];hv=sample['hand'];ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})

 for arm in ['unguarded_injected','guarded_injected','guarded']:
  native._MODULE=modules[arm];provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
  e=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2)
  if arm!='guarded':
   a=e.search(session,SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=16,quiescence_max_depth=0),cancel_token=CancellationToken(),root_window_pruning=True)
   rows.append(dict(root=sample['root'],arm=arm,phase='cancel',result=record_value(a)))
   assert a.completed_depth==1
   if arm=='guarded_injected':assert a.termination_reason=='cancelled'
  r=e.search(session,SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=16,quiescence_max_depth=0),root_window_pruning=True)
  rows.append(dict(root=sample['root'],arm=arm,phase='retry' if arm!='guarded' else 'cold',result=record_value(r)))
  assert record_value(state)==d
  ps=state
  for action in r.principal_variation:assert action in legal_actions(ps,c);ps=apply_action(ps,action,c)
write_record(base/'result.json',rows)
fields=('score','action','principal_variation','completed_depth')
for root in sorted({x['root'] for x in rows}):
 data=[x for x in rows if x['root']==root];a=next(x['result'] for x in data if x['arm']=='guarded' and x['phase']=='cold');b=next(x['result'] for x in data if x['arm']=='guarded_injected' and x['phase']=='retry');assert all(a[k]==b[k] for k in fields)
 c=[x['result'] for x in data if x['phase']=='cancel'];assert all(c[0][k]==c[1][k] for k in fields)
wrong=[x for x in rows if x['arm']=='unguarded_injected' and x['phase']=='cancel' and x['result']['termination_reason']!='cancelled']
assert len(wrong)==3
write_record(base/'verification.json',dict(calls=len(rows),silent_cancel_roots=[x['root'] for x in wrong],guarded_cancelled_roots=7,reused_TT_retry_cold_tuple_pairs=7,complete_D1_tuple_retained_pairs=7,scope='Real native cancel flag at deterministic proof boundary; private source only, not external user callback latency. No product changes.'))
print('35 boundary calls PASS; firstprototype misses3 real native cancel flags; guarded retainsD1/retriescoldmatch')
