import json,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-root-canonical-20261012/finite';d=json.loads((p/'result.json').read_bytes());assert d['complete'] and not d['censored'];rows=d['rows'];assert len(rows)==56;summary=[]
for root in sorted({x['root'] for x in rows}):
 for depth in [3,4]:
  cells=[x for x in rows if x['root']==root and x['requested_depth']==depth]
  for order in [0,1]:
   a=next(x for x in cells if x['order']==order and x['arm']=='baseline');b=next(x for x in cells if x['order']==order and x['arm']=='canonical_root');assert all(a['result'][k]==b['result'][k] for k in ['score','action','principal_variation','completed_depth']);assert a['result']['completed_depth']==b['result']['completed_depth']==depth
  a=next(x for x in cells if x['order']==0 and x['arm']=='baseline');b=next(x for x in cells if x['order']==0 and x['arm']=='canonical_root');summary.append(dict(root=root,depth=depth,baseline_nodes=a['result']['nodes'],candidate_nodes=b['result']['nodes'],node_delta=b['result']['nodes']-a['result']['nodes']))
counts={k:sum((x['node_delta']<0 if k=='lower' else x['node_delta']>0 if k=='higher' else x['node_delta']==0) for x in summary) for k in ['lower','higher','equal']}
write_record(p/'verification.json',dict(calls=56,fulltuple_pairs=28,allrequesteddepths_complete=True,named_arm_mapping=True,cost_root_horizon_pairs=counts,rows=summary,decision='Keep rootonlyorder private: mixed finitework changes, equal-time caller usefulness untested beyond gen2/Shogi fixedwork; no stateID selector/global adoption.'))
print(counts,summary)
