"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning

from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
import hashlib,random
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)


from generic_chess.ai.cancellation import CancellationToken
base=ROOT/'.local_agent/q0-terminal-proof-20261012/boundary';modules={}
for arm in ['baseline','guarded']:
 sp=importlib.util.spec_from_file_location('boundary_'+arm+'._native_core',(base.parent/arm if arm=='baseline' else base/arm)/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m

from generic_chess.native import semantic as ns
from generic_chess.native.adapter import pack_semantic_search_position
out=base/'matrix';out.mkdir(exist_ok=True)
write_record(out/'declaration.json',dict(roots='all7 saved',calls=112,TT_MiB=[0,1],offsets=[0,1],exactroot=[False,True],depth=3,seconds=16,nodes=1000000,scope='Private correctedguarded directentry. Legacy mustretain existing wholetriplet/depth; exactroot immediate proof truthfulD1, rawscore/action/PV same fixedD3. All fullhistory/aux retained. No public adoption.'))
samples=json.loads((ROOT/'.local_agent/q0-refine-generated-20261012/samples.json').read_bytes());rows=[]
for sample in samples:
 if not sample['included']:continue
 src=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(sample['rules']));c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 d=sample['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));w=tuple(position(x) for x in sample['witnesses']);session=SimpleNamespace(compiled=c,state=state,_search_witnesses=w,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 bv=sample['board'];hv=sample['hand'];ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})


 for tt in [0,1]:
  for offset in [0,1]:
   for exact in [False,True]:
    for arm in ['baseline','guarded']:
     native._MODULE=modules[arm];nr=NativeSemanticLegalityProvider.try_create(c,strict=True).native_rules;pos=pack_semantic_search_position(c,nr,session);before=ns.snapshot(nr,pos)
     t=time.perf_counter();r=ns.semantic_iterative_search(nr,pos,3,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),tt_megabytes=tt,_root_ply_offset=offset,root_window_pruning=exact,max_nodes=1000000,max_time_seconds=16)
     assert ns.snapshot(nr,pos)==before
     rows.append(dict(root=sample['root'],TT=tt,offset=offset,exact=exact,arm=arm,seconds=time.perf_counter()-t,result=r))
write_record(out/'result.json',rows)
for root in {x['root'] for x in rows}:
 for tt in [0,1]:
  for offset in [0,1]:
   for exact in [False,True]:
    a,b=[x['result'] for x in rows if x['root']==root and x['TT']==tt and x['offset']==offset and x['exact']==exact]
    assert all(a[k]==b[k] for k in ['score','best_action','principal_variation'])
    if not exact:assert a['completed_depth']==b['completed_depth'] and a['termination_reason']==b['termination_reason']
write_record(out/'verification.json',dict(calls=len(rows),paired_rawtriplets=56,legacy_full_depth_cause_pairs=28,proof_calls=sum(x['result']['termination_reason']=='proven_immediate_win' for x in rows),scope='0/1 supportedroot-offset +TT0/1+legacy/exact, notwhole-domain proof'))
print('112 matrix calls PASS')
