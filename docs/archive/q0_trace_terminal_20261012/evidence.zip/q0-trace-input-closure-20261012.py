from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-trace-rebuild-20261012';inputs=json.loads((R/'.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes());saved=json.loads((R/'.local_agent/q0-played-consumer-after-20261012/result.json').read_bytes())['paths'];closure=[]
for name,turns in [('generated1091',[0,2]),('shogi-middle',[0])]:
 for turn in turns:
  path=saved[name];closure.append(dict(root=name,turn=turn,rules=inputs[name]['rules'] if name in inputs else 'builtin:standard_shogi',board=inputs[name]['board'] if name in inputs else {'K':0,'P':100,'L':300,'N':300,'S':500,'G':600,'B':800,'R':1000,'+P':600,'+L':600,'+N':600,'+S':600,'+B':1000,'+R':1200},hand=inputs[name]['hand'] if name in inputs else 'same VALUES shogi map; exact values in archived runner import scripts/search_backend_comparison.py',state=path['turns'][turn]['before'],witnesses=path['initial_witnesses']+[x['after']['position'] for x in path['turns'][:turn]]))
# Preserve the actual source map instead of relying on a guessed listed Shogi table.
from scripts.search_backend_comparison import VALUES
for x in closure:
 if x['root']=='shogi-middle':x['board']=VALUES['shogi'];x['hand']=VALUES['shogi']
write_record(p/'input-closure.json',closure)
