import os,sys,sysconfig,subprocess,time,hashlib,json
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record

out=ROOT/'.local_agent/q0-trace-cost-20261012';out.mkdir(exist_ok=True)
source=(ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
base=(ROOT/'.local_agent/q0-trace-rebuild-20261012/reconstructed/native_module.c').read_text(encoding='utf-8')
base=base.replace('    int replay_origin;','    int replay_origin;\n    uint64_t phase_main_visits;\n    uint64_t phase_refine_visits;\n    uint64_t phase_final_visits;\n    uint64_t phase_final_nanoseconds;')
a='    ctx->nodes++;';assert base.count(a)==1
base=base.replace(a,a+'\n    if(ctx->replay_origin==2) ctx->phase_final_visits++; else if(ctx->replay_origin==1) ctx->phase_refine_visits++; else ctx->phase_main_visits++;')
a='        int old_origin=ctx->replay_origin; ctx->replay_origin=2;';assert base.count(a)==1
base=base.replace(a,a+'\n        uint64_t phase_start=gc_monotonic_ns();')
a='\n        ctx->replay_origin=old_origin;';assert base.count(a)==1
base=base.replace(a,'\n        if(old_origin!=2) ctx->phase_final_nanoseconds+=gc_monotonic_ns()-phase_start;\n'+a)
a='        gc_semantic_set_u64(out, "root_tie_refinements", ctx.root_tie_refinements) != 0 ||';assert base.count(a)==1
base=base.replace(a,'        gc_semantic_set_u64(out, "phase_main_visits", ctx.phase_main_visits) != 0 ||\n        gc_semantic_set_u64(out, "phase_refine_visits", ctx.phase_refine_visits) != 0 ||\n        gc_semantic_set_u64(out, "phase_final_visits", ctx.phase_final_visits) != 0 ||\n        gc_semantic_set_u64(out, "phase_final_nanoseconds", ctx.phase_final_nanoseconds) != 0 ||\n'+a)
write_record(out/'declaration.json',dict(question='Does using normalTT scalar children merely reclassify canonical cost, or what actualphase remains after reconstruction?',calls=4,roots=['gen2','Shogi0'],depth=5,orders=[0,1],TT_MiB=1,min_depth=2,seconds=64,max_nodes=None,scope='Counter-only reconstructedsource, all visits grouped by dynamicphase origin independentlyof pv_replay bit. Rootcanonical phase walltime countedonce, recursiveintervals notdoublecounted; transitions/setupoutsidebranchtimer remainlimits. Fulltuple/nodes comparecounterfree reconstructedD5 closedreference, no default/UI/policychange. Max4.3minutes, expectedunder1minute.'))
rows=[]
for name,flag in [('attribution',0)]:
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';variant=base
 if flag:
  needle='child_beta, child_pv,\n            pv_replay);';assert variant.count(needle)==1
  variant=variant.replace(needle,'child_beta,\n            (ctx->root_window_pruning && pv_replay) ? 0 : child_pv,\n            (ctx->root_window_pruning && pv_replay) ? 0 : pv_replay);')
  needle='&& !pv_replay && pv_node && found &&';assert variant.count(needle)==1
  variant=variant.replace(needle,'&& (!pv_replay || ctx->root_window_pruning) && pv_node && found &&')
  needle='(!ctx->root_window_pruning || ply == 0) &&';assert variant.count(needle)==1
  variant=variant.replace(needle,'(!ctx->root_window_pruning || ply == 0 || pv_replay) &&')
  needle='if(ctx->root_window_pruning && ply==0) { ctx->research_pv_checks++; if(best != -branch) ctx->research_pv_mismatches++; }';assert variant.count(needle)==1
  variant=variant.replace(needle,'if(ctx->root_window_pruning) { ctx->research_pv_checks++; if(best != -branch) {ctx->research_pv_mismatches++;ctx->control=4;return 0;} }')
 p.write_text(variant,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));args=[str(ROOT/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(ROOT/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython'+str(sys.version_info.major)+str(sys.version_info.minor)]+[str(p if f.name=='native_module.c' else f) for f in sorted((ROOT/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)];t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:];rows.append(dict(arm=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size));print(name,'built',flush=True)
assert (ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')==source;write_record(out/'build-summary.json',dict(variants=rows,productsource_unchanged=True))
