import sys,os,sysconfig,subprocess,time,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
from scripts.research_record import write_record

out=R/'.local_agent/q0-terminal-proof-20261012/boundary';out.mkdir(exist_ok=True)
s=(R/'.local_agent/q0-terminal-proof-20261012/proof/native_module.c').read_text(encoding='utf-8')
a='            GCSemanticPosition *child = &ctx.stack[1];'
assert s.count(a)==1
v=s.replace(a,'            if (!gc_semantic_iterative_check_budget(&ctx, 1)) break;\n'+a)
a='            if (terminal > 0 && winner == ctx.stack[0].side_to_move) {'
assert v.count(a)==1
v=v.replace(a,'            if (!gc_semantic_iterative_check_budget(&ctx, 1)) break;\n'+a)
inject='            if (ctx.cancel != NULL) gc_cancel_flag_request(ctx.cancel);\n'
variants={'unguarded_injected':s.replace('            if (terminal < 0)',inject+'            if (terminal < 0)'), 'guarded_injected':v.replace('            if (terminal < 0)',inject+'            if (terminal < 0)'), 'guarded':v}
write_record(out/'declaration.json',dict(question='Can a real native cancel flag arriving during the additional terminal proof be silently ignored?',inject='gc_cancel_flag_request on actual nonNULL ctx.cancel after native terminal result before proof acceptance, exactlyD1',scope='Private deterministic cancellation injection; no OS/UI/usercancel timing claim. Guarded checks before/after extra proof. Retain completeD1 and distinguish cancelled from proven reason. Declared current firstprototype immutable.'))
rows=[]
for name,src in variants.items():
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text(src,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(p if f.name=='native_module.c' else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:]
 rows.append(dict(arm=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));print(name,'built',flush=True)
write_record(out/'build.json',rows)
