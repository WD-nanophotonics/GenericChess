"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning

from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
import hashlib,random
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)

base=ROOT/'.local_agent/q0-trace-rebuild-20261012'
mode='finite';out=base/mode;out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Selected-branch canonical trace reconstruction finite fulltuple transfer',mode=mode,finite_depths=[2,3],seeds=list(range(2026101221,2026101237)) if mode=='prospective' else None,roots='all7 prior frozen ongoing roots',orders=[0,1],arms=['baseline','reconstructed'],seconds=16,nodes=1000000,maxdepth=12,q=0,TT_MiB=1,whole_batch_fuse_seconds=3300,scope='Sequential single writer, same fullhistory and rulederived board/hand profile/min2. Complete depth2/3 full score/action/PV compared, terminalunits unchanged. Scoped trace reconstruction separate from terminal shortcut; no earlyreturn policy. All natural terminal/unsupported retained, no resampling. No default/UI/production adoption. Expected under30minutes; no one run overhour, stop check each cell.'))
modules={}
for arm in ['baseline','reconstructed']:
 p=base/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('term_'+arm+'._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
write_record(out/'modules.json',{k:dict(source_sha256=hashlib.sha256((base/k/'native_module.c').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()) for k,m in modules.items()})
samples=[];rows=[];start=time.perf_counter();censored=False
if mode=='finite':samples=json.loads((ROOT/'.local_agent/q0-refine-generated-20261012/samples.json').read_bytes())
else:
 for seed in range(2026101221,2026101237):
  cfg=GeneratorConfig(seed=seed,board_size=4 if seed%2 else 8,setup_preset='bilateral_random',allow_hybrid=True)
  g=generate_game(cfg);src=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ss=GameSession(c);rng=random.Random(seed+9000);profile=build_ruleset_profile(c,EvaluationConfig())
  for ply in range(17):
   acts=sorted(ss.legal_actions(),key=repr)
   if ply in [0,8,16]:samples.append(dict(root=f'seed{seed}-ply{ply}',config=record_value(cfg),rules=json.loads(serialize_ruleset(g.ruleset)),state=record_value(ss.state),witnesses=record_value(ss._search_witnesses),board=dict(profile.board_value_by_type),hand=dict(profile.hand_value_by_base_type),included=bool(acts) and ss.result.status.value=='ongoing'))
   if ply==16 or not acts or ss.result.status.value!='ongoing':break
   ss.submit(rng.choice(acts))
write_record(out/'samples.json',samples)
for sample in samples:
 if not sample['included']:continue
 src=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(sample['rules']));c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 d=sample['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));w=tuple(position(x) for x in sample['witnesses']);session=SimpleNamespace(compiled=c,state=state,_search_witnesses=w,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 bv=sample['board'];hv=sample['hand'];ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
 for depth in ([2,3] if mode=='finite' else [12]):
  for order,arms in enumerate([['baseline','reconstructed'],['reconstructed','baseline']]):
   for arm in arms:
    for flag in ['rollout','advisor','slack']:
     f=json.loads((ROOT/'.local_agent'/(flag+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused')
    if time.perf_counter()-start>3300:censored=True;break
    native._MODULE=modules[arm];provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
    e=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2)
    before=record_value(state);t=time.perf_counter();res=e.search(session,SearchLimits(max_depth=depth,max_nodes=1000000,max_time_seconds=16,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-t;assert record_value(state)==before
    pvstate=state
    for a in res.principal_variation:assert a in legal_actions(pvstate,c);pvstate=apply_action(pvstate,a,c)
    assert res.action in legal_actions(state,c);child=apply_action(state,res.action,c);win=child.terminal_status.is_terminal and child.terminal_status.winner==state.position.side_to_move
    assert res.termination_reason!='internal_error'
    rows.append(dict(root=sample['root'],requested_depth=depth,order=order,arm=arm,seconds=elapsed,result=record_value(res),selected_child_terminal=record_value(child.terminal_status),actual_immediate_win=win,pv_legal=True,root_restored=True));write_record(out/'result.json',dict(complete=False,censored=censored,rows=rows,seconds=time.perf_counter()-start));print(sample['root'],depth,order,arm,round(elapsed,3),res.completed_depth,res.termination_reason,win,flush=True)
   if censored:break
  if censored:break
 if censored:break
write_record(out/'result.json',dict(complete=True,censored=censored,rows=rows,seconds=time.perf_counter()-start))
