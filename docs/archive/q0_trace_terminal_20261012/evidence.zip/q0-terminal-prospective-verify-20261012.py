import sys,json
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-terminal-proof-20261012/prospective';d=json.loads((p/'result.json').read_bytes());assert d['complete'] and not d['censored'];rows=d['rows'];assert len(rows)==160;fields=('score','action','principal_variation','completed_depth');summary=[];reverse=0
for root in sorted({x['root'] for x in rows}):
 cells=[x for x in rows if x['root']==root]
 for arm in ['baseline','proof']:
  a,b=[x for x in cells if x['arm']==arm];assert all(a['result'][k]==b['result'][k] for k in fields);reverse+=1
 a,b=[next(x for x in cells if x['arm']==arm and x['order']==0) for arm in ['baseline','proof']]
 if b['result']['termination_reason']=='proven_immediate_win':assert a['actual_immediate_win'] and b['actual_immediate_win'] and a['result']['score']==b['result']['score'] and a['result']['action']==b['result']['action']
 else:assert all(a['result'][k]==b['result'][k] for k in fields)
 summary.append(dict(root=root,immediate_proof=b['result']['termination_reason']=='proven_immediate_win',depths=[a['result']['completed_depth'],b['result']['completed_depth']],caller_seconds=[a['seconds'],b['seconds']],scores=[a['result']['score'],b['result']['score']]))
write_record(p/'verification.json',dict(calls=len(rows),reverse_fulltuple_pairs=reverse,actual_roots=len(summary),immediate_roots=sum(x['immediate_proof'] for x in summary),non_immediate_fulltuple_roots=sum(not x['immediate_proof'] for x in summary),actual_caller_seconds=sum(x['seconds'] for x in rows),producer_seconds=d['seconds'],scope='Firstprivateprototype no externalcancel supplied, notrelabeled correctedguardvariant. Changedcaller stop goal, notfixeddepth/strength claim; naturalearlyterminal coverage recorded separately.',roots=summary))
print('160pairedcalls verified; actualimmediate roots',sum(x['immediate_proof'] for x in summary),'seconds',d['seconds'])
