import sys,json,random
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record,record_value
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
p=R/'.local_agent/q0-terminal-proof-20261012/prospective';samples=json.loads((p/'samples.json').read_bytes());rows=[]
for seed in range(2026101221,2026101237):
 g=generate_game(GeneratorConfig(seed=seed,board_size=4 if seed%2 else 8,setup_preset='bilateral_random',allow_hybrid=True));src=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ss=GameSession(c);rng=random.Random(seed+9000);observed=[]
 for ply in range(17):
  acts=sorted(ss.legal_actions(),key=repr)
  if ply in [0,8,16]:
   name=f'seed{seed}-ply{ply}';saved=next(x for x in samples if x['root']==name);assert saved['state']==record_value(ss.state);observed.append(ply)
  if ply==16 or not acts or ss.result.status.value!='ongoing':break
  ss.submit(rng.choice(acts))
 rows.append(dict(seed=seed,observed_roots=observed,omitted_roots=[x for x in [0,8,16] if x not in observed],final_ply=ply,final_result=record_value(ss.result),final_state=record_value(ss.state)))
write_record(p/'coverage.json',dict(scope='Deterministic declared uniform legal walk replay only, no searchrerun/resampling. Originalproducer omitted terminalstop betweenrequestedroots; supplementarycoverage records actualoutcome andmissingroots, notnewsearchcells.',records=rows,actual_ongoing_roots=len(samples),omitted_root_count=sum(len(x['omitted_roots']) for x in rows)))
print('16 walkcoverageverified;40 naturalongoing roots,8 laterroot omissions retained')
