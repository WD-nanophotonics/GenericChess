from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-root-canonical-20261012'
write_record(p/'verification-failure.json',dict(error='Verifier selected a,b by rowlist order; reverseorder swaps arms, so b zero-refinement assertion examinedbaseline.',impact='No scientificsearchrerun or productionchange; existing checkpoint states correctmeasurements but evidencefile missing untilcorrected. Fulltuple assertionspassed, namedarm routing repaired.',fix='Select everycomparison by explicitarm, retainrawoutcomes and failedverification record.',resolved=True))
for directory,depths,expected,zero in [('run',[4,5],8,True),('Shogi-D5',[5],4,True)]:
 d=json.loads((p/directory/'result.json').read_bytes());assert d['complete'];rows=d['rows'];assert len(rows)==expected;summary=[]
 for depth in depths:
  for order in [0,1]:
   cells=[x for x in rows if x['depth']==depth and x['order']==order];a=next(x for x in cells if x['arm']=='baseline');b=next(x for x in cells if x['arm']=='canonical_root');assert all(a['result'][k]==b['result'][k] for k in ['score','action','principal_variation','completed_depth']);assert b['raw']['root_tie_refinements']==0 and b['raw']['phase_refine_visits']==0
   summary.append(dict(depth=depth,order=order,baseline_nodes=a['result']['nodes'],candidate_nodes=b['result']['nodes'],baseline_seconds=a['seconds'],candidate_seconds=b['seconds'],root_refinement_visits=[a['raw']['phase_refine_visits'],b['raw']['phase_refine_visits']]))
 write_record(p/directory/'verification.json',dict(calls=len(rows),fulltuple_pairs=len(summary),named_arm_mapping=True,root_tie_refinements_eliminated=True,rows=summary,scope='Privatefixedrootonlyorder, no uniform/defaultadoption; Shogi smallnegativecost preserved'))
 print(directory,summary)
# Repair derived cost labels in earlier same-tuple verifiers; immutable rawresults untouched.
for directory in ['run','noTT']:
 p=R/'.local_agent/q0-trace-rebuild-20261012'/directory;d=json.loads((p/'result.json').read_bytes());rows=d['rows'];pairs=[]
 for root,turn in {(x['root'],x['turn']) for x in rows}:
  for order in [0,1]:
   cells=[x for x in rows if (x['root'],x['turn'],x['order'])==(root,turn,order)];a=next(x for x in cells if x['arm']=='baseline');b=next(x for x in cells if x['arm']=='reconstructed');assert all(a['result'][k]==b['result'][k] for k in ['score','action','principal_variation','completed_depth']);pairs.append(dict(root=root,turn=turn,order=order,equal=True,baseline_nodes=a['result']['nodes'],candidate_nodes=b['result']['nodes']))
 write_record(p/'verification.json',dict(calls=12,pairs=pairs,all_equal=True,complete=True,named_arm_mapping=True,scope='Corrected derivedroles fromrawarm fields; rawresults notchanged, fulltuple equality unchanged.'))
