import json,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-terminal-proof-20261012/saved';d=json.loads((p/'result.json').read_bytes());assert d['complete'] and not d['censored'];rows=d['rows'];assert len(rows)==56
fields=('score','action','principal_variation','completed_depth')
pairs=[]
for root in sorted({x['root'] for x in rows}):
 cells=[x for x in rows if x['root']==root]
 for depth in [1,12]:
  for arm in ['baseline','proof']:
   a,b=[x for x in cells if x['requested_depth']==depth and x['arm']==arm]
   assert all(a['result'][k]==b['result'][k] for k in fields)
 for order in [0,1]:
  a,b=[x for x in cells if x['requested_depth']==1 and x['order']==order];assert all(a['result'][k]==b['result'][k] for k in fields)
  a,b=[next(x for x in cells if x['requested_depth']==12 and x['order']==order and x['arm']==arm) for arm in ['baseline','proof']]
  if b['actual_immediate_win']:assert a['actual_immediate_win'] and a['result']['score']==b['result']['score'] and a['result']['action']==b['result']['action']
  else:assert all(a['result'][k]==b['result'][k] for k in fields)
 pairs.append(dict(root=root,immediate=cells[0]['actual_immediate_win']))
write_record(p/'verification.json',dict(calls=len(rows),reverse_tuple_pairs=28,common_depth1_fulltuple_pairs=14,immediate_roots=sum(x['immediate'] for x in pairs),non_immediate_roots=sum(not x['immediate'] for x in pairs),actual_win_checks=12,rows=pairs,seconds=sum(x['seconds'] for x in rows),production_unchanged=True))
print('56 calls verified; 3 immediate roots,4 non-immediate, 28 reverse tuple pairs')
