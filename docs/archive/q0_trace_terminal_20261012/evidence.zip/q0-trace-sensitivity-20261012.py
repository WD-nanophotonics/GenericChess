import sys,sysconfig,importlib.util,time
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));import generic_chess.native as native;import pytest
from scripts.research_record import write_record
rows=[]
for arm,sub,expected in [('baseline','q0-trace-rebuild-20261012/baseline',1),('naive','q0-replay-tt-20261012/replay_TT',1),('reconstructed','q0-trace-rebuild-20261012/reconstructed',0)]:
 p=R/'.local_agent'/sub/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('sensitivity_'+arm+'._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m;t=time.perf_counter();code=pytest.main(['-q','--tb=short','-p','no:cacheprovider','--basetemp=.local_agent/pytest-q0-trace-sensitivity-'+arm+'-20261012','tests/development/test_native_q0_canonical_replay.py::test_selected_branch_reconstruction_keeps_full_canonical_pv_under_budget']);rows.append(dict(arm=arm,exit_code=code,expected_exit=expected,seconds=time.perf_counter()-t));assert code==expected
write_record(R/'.local_agent/q0-trace-rebuild-20261012/sensitivity.json',dict(calls=3,rows=rows,baseline_fails_depth=True,naive_fails_fullPV=True,reconstructed_passes=True))
