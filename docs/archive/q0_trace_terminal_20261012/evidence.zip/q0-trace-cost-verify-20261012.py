import json,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-trace-cost-20261012';d=json.loads((p/'run/result.json').read_bytes());assert d['complete'];rows=d['rows'];assert len(rows)==4;summary=[]
for name in ['generated1091','shogi-middle']:
 a,b=[x for x in rows if x['root']==name];assert all(a['result'][k]==b['result'][k] for k in ['score','action','principal_variation','completed_depth','nodes'])
 for x in [a,b]:assert sum(x['raw'][k] for k in ['phase_main_visits','phase_refine_visits','phase_final_visits'])==x['result']['nodes'];assert x['raw']['research_pv_mismatches']==0
 if name=='shogi-middle':ref=next(x for x in json.loads((R/'.local_agent/q0-trace-rebuild-20261012/core-D5/result.json').read_bytes())['rows'] if x['arm']=='reconstructed' and x['order']==0)
 else:ref=next(x for x in json.loads((R/'.local_agent/q0-trace-rebuild-20261012/delivery/result.json').read_bytes())['rows'] if x['root']==name and x['turn']==2 and x['arm']=='reconstructed' and x['order']==0)
 assert all(a['result'][k]==ref['result'][k] for k in ['score','action','principal_variation','completed_depth'])
 summary.append(dict(root=name,depth=5,total_visits=a['result']['nodes'],main=a['raw']['phase_main_visits'],root_refinement=a['raw']['phase_refine_visits'],canonical_phase=a['raw']['phase_final_visits'],old_pv_flag_replay_visits=a['raw']['replay_final'],root_canonical_seconds=[x['raw']['phase_final_nanoseconds']/1e9 for x in [a,b]],caller_seconds=[x['seconds'] for x in [a,b]]))
write_record(p/'verification.json',dict(calls=4,reverse_fulltuple_nodes_pairs=2,all_visit_phase_partition_exact=True,counterfree_output_match=True,roots=summary,scope='Independentofpv_replay bit, nonoverlapping rootbranchintervaltime; parenttransition/contextoutside interval. Changedcodepaths are not primitive-speed proof.'))
print(summary)
