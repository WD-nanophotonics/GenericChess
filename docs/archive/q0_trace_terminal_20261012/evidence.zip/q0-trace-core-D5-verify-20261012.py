import json,sys
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-trace-rebuild-20261012/core-D5';d=json.loads((p/'result.json').read_bytes());assert d['complete'];rows=d['rows'];assert len(rows)==6;fields=('score','action','principal_variation','completed_depth')
for arm in ['reconstructed','CorePlain','CoreAB']:
 a,b=[x for x in rows if x['arm']==arm];assert all(a['result'][k]==b['result'][k] for k in fields)
assert all(x['result']['score']==200 and x['result']['completed_depth']==5 for x in rows if x['arm']!='CorePlain')
assert all(x['result']['completed_depth']==4 for x in rows if x['arm']=='CorePlain')
write_record(p/'verification.json',dict(calls=6,reverse_fulltuple_pairs=3,completedD5_Native_CoreAB_score_agree=True,independent_TTfree_Core_D5_value='UNKNOWN: both64s limit atD4',scope='Fixedsameleaf q0/fullhistory, nonmate rawvalue200; CoreAB is still optimizedTT/order reference, no primitive speed or independentD5 proof',summary=[dict(arm=x['arm'],order=x['order'],depth=x['result']['completed_depth'],score=x['result']['score'],nodes=x['result']['nodes'],seconds=x['seconds']) for x in rows]))
print('sixD5 referencecalls verified;TTfreeD5unknown')
