import os,sys,sysconfig,subprocess,time,hashlib,json
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
out=ROOT/'.local_agent/q0-trace-rebuild-20261012';out.mkdir(exist_ok=True);source=(ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
base=(ROOT/'.local_agent/q0-refine-phase-20261012/phase/native_module.c').read_text(encoding='utf-8')
write_record(out/'declaration.json',dict(question='Does selected-branch recursive canonical reconstruction preserve the full trace while score-only normal child searches use TT?',calls=12,fixed_depth=4,roots=['gen0','gen2','Shogi0'],orders=[0,1],TT_MiB=1,min_depth=2,seconds=64,nodes=None,scope='Changed premise after actual naiveTT PV truncation/change: every canonical node searches child scores normally then recursively rebuilds ONLY its chosen child with fullwindow canonical selection, TT entry never substitutes its trace. Reject any root score/action/fullPV mismatch; each selected-pass value equality checked, internal_error on mismatch. Scope private q0 exactroot, samehistory/order/leaf. No product/default/UI adoption. Expected<2min,max768s<13min; no rescue. A changed outputcontract is not a samesupportspeedup.'))
rows=[]
for name,flag in [('baseline',0),('reconstructed',1)]:
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';variant=base
 if flag:
  needle='child_beta, child_pv,\n            pv_replay);';assert variant.count(needle)==1
  variant=variant.replace(needle,'child_beta,\n            (ctx->root_window_pruning && pv_replay) ? 0 : child_pv,\n            (ctx->root_window_pruning && pv_replay) ? 0 : pv_replay);')
  needle='&& !pv_replay && pv_node && found &&';assert variant.count(needle)==1
  variant=variant.replace(needle,'&& (!pv_replay || ctx->root_window_pruning) && pv_node && found &&')
  needle='(!ctx->root_window_pruning || ply == 0) &&';assert variant.count(needle)==1
  variant=variant.replace(needle,'(!ctx->root_window_pruning || ply == 0 || pv_replay) &&')
  needle='if(ctx->root_window_pruning && ply==0) { ctx->research_pv_checks++; if(best != -branch) ctx->research_pv_mismatches++; }';assert variant.count(needle)==1
  variant=variant.replace(needle,'if(ctx->root_window_pruning) { ctx->research_pv_checks++; if(best != -branch) {ctx->research_pv_mismatches++;ctx->control=4;return 0;} }')
 p.write_text(variant,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));args=[str(ROOT/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(ROOT/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython'+str(sys.version_info.major)+str(sys.version_info.minor)]+[str(p if f.name=='native_module.c' else f) for f in sorted((ROOT/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)];t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:];rows.append(dict(arm=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size));print(name,'built',flush=True)
assert (ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')==source;write_record(out/'build-summary.json',dict(variants=rows,productsource_unchanged=True))
