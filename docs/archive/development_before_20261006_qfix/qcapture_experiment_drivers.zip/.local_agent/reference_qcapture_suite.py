"""Reference all legal returned choices, including retained partial iterations."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
paths={k:ROOT/'.local_agent'/v for k,v in [('curve','chess_qorder_curve_20261006.json'),('capture','chess_qcapture_suite_20261006.json'),('cache','chess_shared_dynamic_reference_20261006.json')]}
inputs={k:json.loads(p.read_bytes()) for k,p in paths.items()};assert all(r['complete'] for r in inputs.values())
out=ROOT/'.local_agent/chess_qcapture_finite_suite_20261006.json';assert not out.exists()
suite=json.loads((ROOT/'docs/research/data/chess_development_suite.json').read_bytes())
enginepath=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
assert inputs['cache']['binary_sha256']==hashlib.sha256(enginepath.read_bytes()).hexdigest()
assert inputs['cache']['conditions']==dict(threads=1,hash_mib=16,nodes_per_child=50000,fresh_game_each_child=True)
cached={r['fen']:r['references'] for r in inputs['cache']['cases']}
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
report=dict(scope='Every returned q0ordered/capture-q2 suite choice, including partial iteration; finite standard-Chess root-child proxy, not WDL/regret/Elo or heldout; supplied BK FEN history only',inputs_sha256={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},binary_sha256=hashlib.sha256(enginepath.read_bytes()).hexdigest(),nodes_per_child=50000,cases=[],new_analyses=0,cached_analyses=0,complete=False)
with chess.engine.SimpleEngine.popen_uci(str(enginepath),timeout=10) as engine:
    engine.configure({'Threads':1,'Hash':16})
    for case in suite['cases']:
        board=chess.Board(case['fen']);s=d.root_from_fen(case['fen'],c)
        rows=[r for r in inputs['curve']['rows'] if r['case_id']==case['id'] and r['qdepth']==0 and r['qordering']]+[r for r in inputs['capture']['rows'] if r['case_id']==case['id']]
        refs={}
        for move in sorted({r['move'] for r in rows}):
            child=board.copy(stack=True);child.push_uci(move)
            actual=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==move),c)
            align=d.UciOpponent(None,case['fen'],1);align.push(move,actual)
            if move in cached.get(case['fen'],{}):
                refs[move]=dict(cached[case['fen']][move],cached=True);report['cached_analyses']+=1
            else:
                info=engine.analyse(child,chess.engine.Limit(nodes=50000),game=object());score=info['score'].pov(board.turn)
                refs[move]=dict(cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),pv=[m.uci() for m in info.get('pv',())],cached=False);report['new_analyses']+=1
        paired=[]
        for policy in d.POLICIES:
            a=next(r for r in rows if r['policy']==policy and r.get('qdepth')==0);b=next(r for r in rows if r['policy']==policy and r.get('tuning',{}).get('use_capture_only_qsearch'))
            x,y=refs[a['move']],refs[b['move']]
            paired.append(dict(policy=policy,q0_move=a['move'],q2_move=b['move'],q0_depth=a['statistics']['completed_depth'],q2_depth=b['statistics']['completed_depth'],cp_delta=None if x['cp'] is None or y['cp'] is None else y['cp']-x['cp'],q0_mate=x['mate'],q2_mate=y['mate']))
        report['cases'].append(dict(id=case['id'],fen=case['fen'],references=refs,paired=paired));d.write_record(out,report)
        print(case['id'],'new',report['new_analyses'],'cached',report['cached_analyses'],flush=True)
report['complete']=True;d.write_record(out,report)
