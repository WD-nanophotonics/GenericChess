"""Declared earlier-root finite diagnosis; all points retained, not price tuning."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
out=ROOT/'.local_agent/chess_first_loss_trend_20261006.json';assert not out.exists()
raw=(ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json').read_bytes();game=json.loads(raw)['games'][0]
points=(16,20,24,26,30,32,36,38,40,42)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
enginepath=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
report=dict(scope='Exposed actual loss diagnosis, finite standard-Chess proxy not certified regret; all memo points predeclared',input_sha256=hashlib.sha256(raw).hexdigest(),points=points,nodes=50000,rows=[],complete=False)
s=d.root_from_fen(game['initial_fen'],c);alignment=d.UciOpponent(None,game['initial_fen'],1)
with chess.engine.SimpleEngine.popen_uci(str(enginepath),timeout=10) as engine:
    engine.configure({'Threads':1,'Hash':16})
    for original in game['moves'][:43]:
        ply=original['ply']
        if ply in points:
            board=alignment.board
            info=engine.analyse(board,chess.engine.Limit(nodes=50000),game=object());best=info['pv'][0].uci()
            row=dict(ply=ply,fen=board.fen(),played=original['move'],original_search=original,root_best=best,root_cp=info['score'].pov(board.turn).score(),root_mate=info['score'].pov(board.turn).mate(),children={})
            for move in sorted({best,original['move']}):
                child=board.copy(stack=True);child.push_uci(move)
                actual=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==move),c)
                check=d.UciOpponent(None,game['initial_fen'],1);check.board=board.copy(stack=True);check.push(move,actual)
                result=engine.analyse(child,chess.engine.Limit(nodes=50000),game=object());score=result['score'].pov(board.turn)
                row['children'][move]=dict(cp=score.score(),mate=score.mate(),nodes=result.get('nodes'),pv=[m.uci() for m in result.get('pv',())],fen=child.fen(),stack=len(child.move_stack),core_author_agrees=True)
            report['rows'].append(row);d.write_record(out,report);print(ply,original['move'],best,row['root_cp'],[(k,v['cp']) for k,v in row['children'].items()],flush=True)
        move=original['move'];s=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==move),c);alignment.push(move,s)
report['complete']=True;d.write_record(out,report)
