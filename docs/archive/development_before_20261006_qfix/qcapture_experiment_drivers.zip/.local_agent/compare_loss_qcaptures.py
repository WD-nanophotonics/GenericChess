"""Changed premise at three identified losses: capture-only q horizons."""
import sys,json,hashlib
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/chess_first_loss_qcaptures_20261006.json';assert not out.exists()
raw=(ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json').read_bytes();game=json.loads(raw)['games'][0]
points=(20,26,40)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
report=dict(scope='Changed capture-only premise, q0 vs q1/q2/q3; ordered lazy classification; fixed4ply32768nodes5seconds, all3points preserved; no prices/defaults or certified regret',input_sha256=hashlib.sha256(raw).hexdigest(),points=points,producer_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/tuning.py','generic_chess/ai/alphabeta/quiescence.py','scripts/chess_development.py']},rows=[],complete=False)
s=d.root_from_fen(game['initial_fen'],c);w=[s.position]
for original in game['moves'][:41]:
    if original['ply'] in points:
        for q in (0,1,2,3):
            limits=d.SearchLimits(max_depth=4,max_nodes=32768,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
            tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=q==0,use_ordered_qsearch=True,use_capture_only_qsearch=q>0)
            a,row=d.search_move(s,c,'geometric_half',limits,provider=provider,ordering=True,use_tt=True,dynamic='cached_legacy',tuning=tuning,_history_witnesses=tuple(w))
            row.update(ply=original['ply'],qdepth=q,limits=asdict(limits),tuning=asdict(tuning));report['rows'].append(row);d.write_record(out,report)
            print(original['ply'],q,row['move'],row['score'],row['statistics']['completed_depth'],row['reason'],round(row['wall_seconds'],3),flush=True)
    s=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==original['move']),c);w.append(s.position)
report['complete']=True;d.write_record(out,report)
