"""Declared fixed-search q0/q1 loss points; retain every point and incomplete."""
import sys,json,hashlib
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/chess_first_loss_q_compare_20261006.json';assert not out.exists()
raw=(ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json').read_bytes();game=json.loads(raw)['games'][0]
points=(16,20,24,26,30,32,36,38,40,42)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=True)
report=dict(scope='Exposed development diagnosis; same4ply/32768nodes/5seconds; q0 vs existing q1 only; no coefficients/default changes',input_sha256=hashlib.sha256(raw).hexdigest(),points=points,tuning=asdict(tuning),rows=[],complete=False)
s=d.root_from_fen(game['initial_fen'],c);w=[s.position]
for original in game['moves'][:43]:
    if original['ply'] in points:
        for q in (0,1):
            limits=d.SearchLimits(max_depth=4,max_nodes=32768,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
            a,row=d.search_move(s,c,'geometric_half',limits,provider=provider,ordering=True,use_tt=True,dynamic='cached_legacy',tuning=tuning,_history_witnesses=tuple(w))
            row.update(ply=original['ply'],qdepth=q,limits=asdict(limits));report['rows'].append(row);d.write_record(out,report)
            print(original['ply'],q,row['move'],row['score'],row['statistics']['completed_depth'],row['reason'],round(row['wall_seconds'],3),flush=True)
    s=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==original['move']),c);w.append(s.position)
report['complete']=True;d.write_record(out,report)
