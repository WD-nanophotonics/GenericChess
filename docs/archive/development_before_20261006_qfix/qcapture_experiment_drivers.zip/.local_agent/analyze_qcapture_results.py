"""Concise deterministic summaries; raw search/game outputs remain untouched."""
from pathlib import Path
import json
from collections import Counter
from scripts.research_record import write_record
root=Path.cwd()
curve=json.loads((root/'.local_agent/chess_qorder_curve_20261006.json').read_bytes());assert curve['complete']
summary={}
for q in (0,1):
    for ordered in (False,True):
        rows=[r for r in curve['rows'] if r['qdepth']==q and r['qordering']==ordered]
        summary[f'q{q}-order{int(ordered)}']=dict(searches=len(rows),completed4=sum(r['statistics']['completed_depth']==4 for r in rows),depths=dict(Counter(str(r['statistics']['completed_depth']) for r in rows)),answer_hits=sum(r['answer_hit'] for r in rows),wall_seconds=sum(r['wall_seconds'] for r in rows),main_qnodes=sum(r['statistics']['nodes']+r['statistics']['qnodes'] for r in rows))
parity={}
for q in (0,1):
    rows={}
    for r in curve['rows']:
        if r['qdepth']==q:rows.setdefault((r['case_id'],r['policy']),{})[r['qordering']]=r
    shared=[pair for pair in rows.values() if all(r['statistics']['completed_depth']==4 for r in pair.values())]
    parity[str(q)]=dict(shared_complete=len(shared),score_matches=sum(p[False]['score']==p[True]['score'] for p in shared),action_matches=sum(p[False]['move']==p[True]['move'] for p in shared),nodes_equal=sum((p[False]['statistics']['nodes'],p[False]['statistics']['qnodes'])==(p[True]['statistics']['nodes'],p[True]['statistics']['qnodes']) for p in shared))
out=root/'.local_agent/chess_qorder_curve_analysis_20261006.json'
value=dict(scope='Observed interleaved curve, brief tests/actual-root calls overlapped some cells; not isolated hardware guarantee; no result omitted',summary=summary,shared_complete_parity=parity)
if out.exists():assert json.loads(out.read_bytes())==value
else:write_record(out,value)
print('curve',json.dumps(summary),json.dumps(parity),flush=True)
suitepath=root/'.local_agent/chess_qcapture_suite_20261006.json'
if suitepath.exists():
    suite=json.loads(suitepath.read_bytes())
    if suite['complete']:
        rows=suite['rows'];out=root/'.local_agent/chess_qcapture_suite_analysis_20261006.json'
        r=dict(searches=len(rows),completed4=sum(r['statistics']['completed_depth']==4 for r in rows),depths=dict(Counter(str(r['statistics']['completed_depth']) for r in rows)),answer_hits=sum(r['answer_hit'] for r in rows),wall_seconds=sum(r['wall_seconds'] for r in rows),main_qnodes=sum(r['statistics']['nodes']+r['statistics']['qnodes'] for r in rows),scope='Changed q law/lazy traversal; development resource curve, no coefficient or isolated causal claim')
        if out.exists():assert json.loads(out.read_bytes())==r
        else:write_record(out,r)
        print('capture-suite',json.dumps(r),flush=True)
gamespath=root/'.local_agent/chess_qcapture_games_20261006.json'
if gamespath.exists():
    games=json.loads(gamespath.read_bytes())
    if games['complete']:
        summary={}
        for q in (0,2):
            gg=[g for g in games['games'] if g['qdepth']==q]
            moves=[m for g in gg for m in g['moves'] if m['policy']!='uci_reference']
            summary[str(q)]=dict(games=len(gg),plies=sum(len(g['moves']) for g in gg),wins=sum(g['winner']==(0 if g['white']!='uci_reference' else 1) for g in gg),losses=sum(g['winner']==(1 if g['white']!='uci_reference' else 0) for g in gg),unfinished=sum(not g['finished'] for g in gg),terminal_without_winner=sum(g['finished'] and g['winner'] is None for g in gg),local_moves=len(moves),depths=dict(Counter(str(m['statistics']['completed_depth']) for m in moves)),reasons=dict(Counter(m['reason'] for m in moves)),wall_seconds=sum(m['wall_seconds'] for m in moves),main_qnodes=sum(m['statistics']['nodes']+m['statistics']['qnodes'] for m in moves))
        out=root/'.local_agent/chess_qcapture_games_analysis_20261006.json';assert not out.exists();write_record(out,dict(scope='12stochastic development cells, unfinished not draw, no Elo',summary=summary,total_wall_seconds=games['wall_seconds']));print('games',json.dumps(summary),flush=True)
