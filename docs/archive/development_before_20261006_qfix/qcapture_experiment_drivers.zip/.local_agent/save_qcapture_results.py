"""One portable raw/summarized record; no prior completed evidence overwritten."""
from pathlib import Path
import hashlib,json,zipfile
from scripts.research_record import write_record
root=Path.cwd()
paths=sorted(set(root.glob('.local_agent/chess_first_loss_*_20261006.json'))|set(root.glob('.local_agent/chess_qorder_*_20261006.json'))|set(root.glob('.local_agent/chess_qcapture_*_20261006.json')))
records={}
for p in paths:
    raw=p.read_bytes();records[p.name]=dict(source=p.relative_to(root).as_posix(),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),record=json.loads(raw))
assert records['chess_qcapture_games_20261006.json']['record']['complete']
assert records['chess_qcapture_finite_suite_20261006.json']['record']['complete']
replay=records['chess_qcapture_game_replay_20261006.json']['record'];assert replay['complete'] and not replay['errors']
out=root/'docs/research/data/chess_qcapture_results_20261006.json';assert not out.exists()
write_record(out,dict(scope='Exposed practical Chess development, not untouched validation/Elo/independent WDL/certified regret; unchanged prices/defaults/Core/human holdout. Timings observed; some small probes/tests overlapped earlier curve, one quiet-mate test during playing. qorder-only curve and capture-only/lazy hypothesis have separately archived producers.',base_sha='a4fdfa6e7f19cc31c5359ad16d7f152de1d15185',suite_searches=360,actual_loss_point_searches=32,new_games=12,played_plies=replay['plies'],tests=dict(relevant_current=82,historical_pins=39),records=records))
names=['diagnose_first_loss.py','compare_loss_q.py','run_qorder_curve.py','compare_loss_qcaptures.py','reference_qcapture_choices.py','probe_qcapture_exchange.py','run_qcapture_followups.py','reference_qcapture_suite.py','analyze_qcapture_results.py','replay_qcapture_games.py','save_qcapture_results.py']
folder=root/'docs/archive/development_before_20261006_qfix';archive=folder/'qcapture_experiment_drivers.zip';assert not archive.exists()
idx=dict(scope='Exact inert experiment/collection drivers; no active policy/scheduler/worker',archive=archive.relative_to(root).as_posix(),sources={})
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in names:
        p=root/'.local_agent'/name;raw=p.read_bytes();member=p.relative_to(root).as_posix();z.writestr(member,raw);idx['sources'][member]=dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
write_record(archive.with_suffix('.json'),idx)
for p in folder.glob('q*_*sources.json'):
    data=json.loads(p.read_bytes())
    with zipfile.ZipFile(root/data['archive']) as z:
        for member,entry in data['sources'].items():assert hashlib.sha256(z.read(member)).hexdigest()==entry['sha256']
with zipfile.ZipFile(archive) as z:
    for member,entry in idx['sources'].items():assert hashlib.sha256(z.read(member)).hexdigest()==entry['sha256']
print(json.dumps(dict(records=len(records),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),archives_verified=True)))
