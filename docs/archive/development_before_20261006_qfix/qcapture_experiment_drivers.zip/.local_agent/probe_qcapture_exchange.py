"""Actual saved variation control, not proof of original visited scoring leaf."""
import sys,json,hashlib,time
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from generic_chess.ai.alphabeta.search import _Context,_Budget,INF,quiescence,SearchAborted
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/chess_qcapture_exchange_control_20261006.json';assert not out.exists()
raw=(ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json').read_bytes();game=json.loads(raw)['games'][0]
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());s=d.root_from_fen(game['initial_fen'],c)
for move in [m['move'] for m in game['moves'][:20]]+['g3h4','g7g5','h4g5']:
    s=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==move),c)
e=d.evaluator('geometric_half',compiled=c,dynamic='cached_legacy')
report=dict(scope='Direct author quiescence at actual legal3move variation endpoint; not claim original search evaluated it or calibrated WDL',input_sha256=hashlib.sha256(raw).hexdigest(),state=d.record_value(s),static_score=e.evaluate(s),in_check=d.semantic_engine_for(c).in_check(s.position,s.position.side_to_move) if hasattr(d,'semantic_engine_for') else None,rows=[],complete=False)
for q in (0,1,2):
    limits=d.SearchLimits(max_nodes=32768,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
    ctx=_Context(c,e,TranspositionTable(),SearchStatistics(),_Budget(limits,None),SearchTuning(use_ordered_qsearch=True,use_capture_only_qsearch=q>0),False,True,q,8,32768)
    start=time.perf_counter();row=dict(qdepth=q)
    try:row.update(score=quiescence(s,-INF,INF,0,0,ctx),complete=True)
    except SearchAborted as exc:row.update(reason=str(exc),complete=False)
    row.update(seconds=time.perf_counter()-start,statistics=asdict(ctx.stats));report['rows'].append(row)
    print(q,row.get('score'),row.get('complete'),row['seconds'],flush=True)
report['complete']=True;d.write_record(out,report)
