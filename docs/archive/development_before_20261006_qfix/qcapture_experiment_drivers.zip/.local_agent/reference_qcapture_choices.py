"""Finite references for every changed pilot choice, actual root children."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
out=ROOT/'.local_agent/chess_first_loss_qcapture_references_20261006.json';assert not out.exists()
games=json.loads((ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json').read_bytes());game=games['games'][0]
pilot=json.loads((ROOT/'.local_agent/chess_first_loss_qcaptures_20261006.json').read_bytes());assert pilot['complete']
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
report=dict(scope='All selected pilot children, fixed50knodes finite standard-Chess proxy; not parameter fitting/WDL',input_sha256=hashlib.sha256((ROOT/'.local_agent/chess_first_loss_qcaptures_20261006.json').read_bytes()).hexdigest(),rows=[],complete=False)
enginepath=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
with chess.engine.SimpleEngine.popen_uci(str(enginepath),timeout=10) as engine:
    engine.configure({'Threads':1,'Hash':16})
    for ply in pilot['points']:
        s=d.root_from_fen(game['initial_fen'],c);align=d.UciOpponent(None,game['initial_fen'],1)
        for orig in game['moves'][:ply]:
            s=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==orig['move']),c);align.push(orig['move'],s)
        row=dict(ply=ply,fen=align.board.fen(),children={})
        for move in sorted({r['move'] for r in pilot['rows'] if r['ply']==ply}):
            child=align.board.copy(stack=True);child.push_uci(move)
            actual=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==move),c)
            checked=d.UciOpponent(None,game['initial_fen'],1);checked.board=align.board.copy(stack=True);checked.push(move,actual)
            info=engine.analyse(child,chess.engine.Limit(nodes=50000),game=object());score=info['score'].pov(align.board.turn)
            row['children'][move]=dict(cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),pv=[m.uci() for m in info.get('pv',())],author_core_agrees=True)
        report['rows'].append(row);d.write_record(out,report);print(ply,[(k,v['cp']) for k,v in row['children'].items()],flush=True)
report['complete']=True;d.write_record(out,report)
