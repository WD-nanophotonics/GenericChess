"""Declared four-condition qdepth/order resource curve, same prices and search."""
import sys,json,hashlib,time
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/chess_qorder_curve_20261006.json';assert not out.exists()
raw=(ROOT/'docs/research/data/chess_development_suite.json').read_bytes();suite=json.loads(raw)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
report=dict(scope='New exposed development curve, not extension of frozen q failures; four-condition qdepth/order2x2, all24cases/3prices; same4ply32768nodes5seconds, cached legacy, PVS/common root ordering/TT',suite_sha256=hashlib.sha256(raw).hexdigest(),decision='Can ordering the same q actions buy completed depth without changing complete values? Does q1 then become practically useful?',cost='288calls at most24minutes single core, interruptible; all negative/partial outcomes retained',producer_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/tuning.py','scripts/chess_development.py']},rows=[],complete=False)
start=time.perf_counter()
for case in suite['cases']:
    s=d.root_from_fen(case['fen'],c)
    for policy in d.POLICIES:
        for q,ordered in ((0,False),(0,True),(1,False),(1,True)):
            for name in ('rollout','advisor','slack'):
                flags=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
                if flags.get('user_paused') or flags.get('stopped'):raise SystemExit('Explicit stop preserved')
            limits=d.SearchLimits(max_depth=4,max_nodes=32768,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
            tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=q==0,use_ordered_qsearch=ordered)
            a,row=d.search_move(s,c,policy,limits,provider=provider,ordering=True,use_tt=True,dynamic='cached_legacy',tuning=tuning)
            row.update(case_id=case['id'],qdepth=q,qordering=ordered,limits=asdict(limits),tuning=asdict(tuning),answer_hit=row['move'] in case['accepted_uci'])
            report['rows'].append(row);d.write_record(out,report)
        print(case['id'],policy,'done',len(report['rows']),flush=True)
report['wall_seconds']=time.perf_counter()-start;report['complete']=True;d.write_record(out,report)
