from pathlib import Path
import hashlib, json, zipfile
from scripts.research_record import write_record

root = Path.cwd()
paths = sorted(set(root.glob('.local_agent/chess_shared_dynamic_*_20261006.json')) | set(root.glob('.local_agent/chess_actual_timeout_*_20261006.json')) | {root / '.local_agent/chess_cached_dynamic_probe_20261006.json', root / '.local_agent/chess_saved_pv_scope_20261006.json', root / '.local_agent/chess_semantic_map_probe_20261006.json'})
records = {}
for path in paths:
    raw = path.read_bytes()
    records[path.name] = {'source':path.relative_to(root).as_posix(), 'sha256':hashlib.sha256(raw).hexdigest(), 'bytes':len(raw), 'record':json.loads(raw)}
replay = records['chess_shared_dynamic_game_replay_20261006.json']['record']
assert replay['complete'] and replay['plies'] == 807 and not replay['errors']
out = root / 'docs/research/data/chess_shared_dynamic_results_20261006.json'
assert not out.exists(), 'Never overwrite completed result'
write_record(out, {'scope':'Exposed Chess development, not WDL/Elo/generic strength or untouched validation. Defaults/prices/Core/human holdout unchanged. Timings observed interleaved, not hardware guarantees.', 'base_sha':'1885eb81dda271790b3e6418d0c9ecf99a97025c', 'suite_searches':576, 'actual_prefix_searches':24, 'actual_timeout_root_searches':6, 'new_games':12, 'played_plies':807, 'completed4_played_searches':168, 'partial3_played_searches':235, 'current_tests_passed':43, 'historical_tests_passed':39, 'provenance':'Exact old/intermediate producer sources and local drivers in docs/archive/development_before_20261006_qfix; game batch retained pre-atomic writer. Raw output preserved with input hashes.', 'records':records})
archive = root / 'docs/archive/development_before_20261006_qfix/shared_dynamic_experiment_drivers.zip'
index_path = archive.with_suffix('.json')
index = json.loads(index_path.read_text(encoding='utf-8'))
driver = root / '.local_agent/save_shared_dynamic_results.py'
member = driver.relative_to(root).as_posix()
raw = driver.read_bytes()
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED) as z:
    assert member not in z.namelist()
    z.writestr(member,raw)
index['sources'][member] = {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
write_record(index_path,index)
for ip in root.glob('docs/archive/development_before_20261006_qfix/shared_dynamic_*.json'):
    idx = json.loads(ip.read_text(encoding='utf-8'))
    with zipfile.ZipFile(root / idx['archive']) as z:
        for name, item in idx['sources'].items():
            assert hashlib.sha256(z.read(name)).hexdigest() == item['sha256'], (ip,name)
print(json.dumps({'records':len(records),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'archives_verified':True}))
