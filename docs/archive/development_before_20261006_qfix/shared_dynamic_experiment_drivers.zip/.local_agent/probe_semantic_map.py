"""One-pass author predicate reuse; no Core/native API or policy changes."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from generic_chess.core.semantic_executor import semantic_engine_for,_sources_by_owner_type
from generic_chess.rules.ir import geometry_candidates
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import is_square_attacked,pack_position

def maps(position,engine):
    engine._ensure_match(position)
    sources=_sources_by_owner_type(position);out=[set(),set()]
    for owner in (0,1):
        for pattern in engine._patterns:
            if pattern.target.kind!='target_enemy':continue
            for tid in pattern.type_ids:
                for source,piece in sources.get((owner,tid),()):
                    for gid in pattern.geometry_ids:
                        geo=engine.ir.geometry.get(gid)
                        if geo is None or geo.kind=='drop' or (geo.atom_source is not None and geo.atom_source[0]!=tid):continue
                        for target,path in geometry_candidates(geo,str(owner),source):
                            if target in out[owner]:continue
                            binding=engine._make_binding(pattern,gid,tid,piece,source,target,None,path,position)
                            if engine._path_holds(pattern.path,position,binding,owner) and engine._guards_hold(pattern,position,binding,owner):out[owner].add(target)
    return tuple(frozenset(s) for s in out)

if __name__=='__main__':
    c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());engine=semantic_engine_for(c);provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
    cases=json.loads((ROOT/'docs/research/data/chess_development_suite.json').read_bytes())['cases'];rows=[]
    cases+=json.loads((ROOT/'.local_agent/chess_shared_dynamic_scope_20261006.json').read_bytes())['rows']
    for case in cases:
        state=d.root_from_fen(case['fen'],c);before=d.record_value(state);p=state.position;packed=pack_position(provider.native_rules,provider._state_only_payload(p,state.ply_count))
        a=maps(p,engine);b=tuple(frozenset(i for i in range(64) if is_square_attacked(provider.native_rules,packed,i,o)) for o in (0,1));author=tuple(frozenset(i for i in range(64) if engine.is_square_attacked(p,i,o)) for o in (0,1))
        assert a==b==author and before==d.record_value(state)
        t=time.perf_counter()
        for _ in range(100):maps(p,engine)
        sec=(time.perf_counter()-t)/100
        rows.append(dict(id=case['id'],counts=[len(s) for s in a],author_native_bulk_agree=True,seconds_per_map_pair=sec));print(case['id'],round(sec*1e6,2),'us',flush=True)
    out=ROOT/'.local_agent/chess_semantic_map_probe_20261006.json';assert not out.exists();d.write_record(out,dict(scope='26 selected fresh states; direct S0/S1 predicate traversal matching existing author square query, not legal-move maps',rows=rows,query_agreements=26*128,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),complete=True))
