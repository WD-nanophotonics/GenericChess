"""Declared twelve weak-engine games, same supported fixed4ply player limits."""
import sys,json,hashlib,time
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess.engine
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json';assert not out.exists()
enginepath=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
limits=d.SearchLimits(max_depth=4,max_nodes=32768,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=True)
fen='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
report=dict(scope='One original initial start,3policies x2colors x2backends,80ply each; weak stochastic opponent, no Elo/causal strength/population inference',
    decision='Test whole playable4ply iterative player, retain all partial searches and losses; no requirement that every move complete4ply',
    conditions=dict(limits=asdict(limits),tuning=asdict(tuning),native=True,ordering=True,tt=True,risk=False,max_plies=80,interleaving='cached legacy/semantic bulk within each policy and color'),
    producer_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['scripts/chess_development.py','scripts/chess_shared_dynamic.py','generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/tuning.py']},
    opponent=dict(binary_sha256=hashlib.sha256(enginepath.read_bytes()).hexdigest(),threads=1,hash_mib=16,configured_elo=1320,nodes=50000,seconds_fuse=1,fresh_game_each_game=True),games=[],complete=False)
d.write_record(out,report);start=time.perf_counter()
def check_stop():
    for name in ('rollout','advisor','slack'):
        flags=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
        if flags.get('user_paused') or flags.get('stopped'):
            raise SystemExit('Explicit project stop preserved; incomplete evidence retained')
check_stop()
with chess.engine.SimpleEngine.popen_uci(str(enginepath),timeout=10) as engine:
    engine.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':True,'UCI_Elo':1320});report['opponent']['id']=engine.id
    for policy in d.POLICIES:
        for color in (0,1):
            white,black=(policy,'uci_reference') if color==0 else ('uci_reference',policy)
            for mode in ('cached_legacy','semantic_bulk'):
                external=d.UciOpponent(engine,fen,50000)
                def save(game):
                    report['active_game']=dict(policy=policy,color=color,dynamic_backend=mode,**game);d.write_record(out,report)
                    check_stop()
                    if len(game['moves'])%10==0:print('progress',policy,color,mode,len(game['moves']),flush=True)
                game=d.play_game(fen,c,white,black,limits,80,save,provider=provider,ordering=True,use_tt=True,dynamic=mode,external=external,tuning=tuning)
                report.pop('active_game',None);report['games'].append(dict(dynamic_backend=mode,**game));d.write_record(out,report)
                print('game',policy,color,mode,game['end'],game['plies_played'],'incomplete',game['incomplete_searches'],flush=True)
report['wall_seconds']=time.perf_counter()-start;report['complete']=True;d.write_record(out,report)
