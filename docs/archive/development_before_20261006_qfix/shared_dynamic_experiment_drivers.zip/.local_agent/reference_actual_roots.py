"""Small fixed50k references with real played history, not PV endpoints."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
out=ROOT/'.local_agent/chess_shared_dynamic_actual_references_20261006.json';assert not out.exists()
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
enginepath=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
games=json.loads((ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json').read_bytes());assert games['complete']
oldraw=(ROOT/'.local_agent/chess_check_only_internal_20261006.json').read_bytes();old=json.loads(oldraw)['games'][3]
timeout=json.loads((ROOT/'.local_agent/chess_actual_timeout_compare_20261006.json').read_bytes())
targets=[('old-timeout43',old,43),('old-timeout53',old,53),('new-first-loss42',games['games'][0],42)]
report=dict(scope='Three selected actual played parents, finite standard-Chess root/child references, not all-defense/WDL/blunder or score-leaf claim',
    conditions=dict(threads=1,hash_mib=16,nodes=50000,fresh_game_each_analysis=True),binary_sha256=hashlib.sha256(enginepath.read_bytes()).hexdigest(),rows=[],complete=False)
with chess.engine.SimpleEngine.popen_uci(str(enginepath),timeout=10) as engine:
    engine.configure({'Threads':1,'Hash':16})
    for name,game,ply in targets:
        state=d.root_from_fen(game['initial_fen'],c);alignment=d.UciOpponent(None,game['initial_fen'],1)
        for move in game['moves'][:ply]:
            action=next(a for a in d.iter_legal_actions(state,c) if d.uci(a)==move['move']);state=d.apply_action(state,action,c);alignment.push(move['move'],state)
        board=alignment.board;info=engine.analyse(board,chess.engine.Limit(nodes=50000),game=object());best=info['pv'][0].uci()
        keys={game['moves'][ply]['move'],best}
        if name.startswith('old'):
            keys.update(r['move'] for r in timeout['rows'] if r['ply']==ply)
        row=dict(id=name,ply=ply,root_fen=board.fen(),played_prefix=[m['move'] for m in game['moves'][:ply]],root_reference=dict(best_move=best,cp=info['score'].pov(board.turn).score(),mate=info['score'].pov(board.turn).mate(),nodes=info.get('nodes')),children={})
        for move in sorted(keys):
            child=board.copy(stack=True);child.push_uci(move);actual=d.apply_action(state,next(a for a in d.iter_legal_actions(state,c) if d.uci(a)==move),c)
            expected=d.UciOpponent(None,game['initial_fen'],1);expected.board=board.copy(stack=True);expected.push(move,actual)
            info=engine.analyse(child,chess.engine.Limit(nodes=50000),game=object());score=info['score'].pov(board.turn)
            row['children'][move]=dict(fen=child.fen(),stack_plies=len(child.move_stack),cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),pv=[m.uci() for m in info.get('pv',())],author_core_child_agrees=True)
        report['rows'].append(row);d.write_record(out,report);print(name,'root',best,[(m,r['cp'],r['mate']) for m,r in row['children'].items()],flush=True)
report['complete']=True;d.write_record(out,report)
