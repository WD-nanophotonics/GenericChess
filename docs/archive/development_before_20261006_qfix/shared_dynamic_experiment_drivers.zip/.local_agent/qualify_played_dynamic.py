"""All prior22 game streams; exact map/score controls on actual history."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from scripts.chess_shared_dynamic import semantic_attack_maps
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,is_square_attacked
out=ROOT/'.local_agent/chess_shared_dynamic_played_scope_20261006.json';assert not out.exists()
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
old=d.evaluator('geometric_half',compiled=c,dynamic=True);cache=d.evaluator('geometric_half',compiled=c,dynamic='cached_legacy')
query=d.evaluator('geometric_half',compiled=c,dynamic='semantic',provider=provider);bulk=d.evaluator('geometric_half',compiled=c,dynamic='semantic_bulk',provider=provider)
report=dict(scope='All22 previously recorded actual histories; selected played-population equivalence, not proof on all positions/variants or strength',inputs={},games=[],states=0,square_agreements=0,changed_semantic_leaf_values=0,complete=False)
wall=time.perf_counter()
for name in ('chess_capture_risk_games_off_20261006','chess_capture_risk_games_on_20261006','chess_check_only_games_20261006','chess_check_only_internal_20261006'):
    raw=(ROOT/'.local_agent'/(name+'.json')).read_bytes();data=json.loads(raw);assert data['complete'];report['inputs'][name]=hashlib.sha256(raw).hexdigest()
    for index,game in enumerate(data['games']):
        s=d.root_from_fen(game['initial_fen'],c);local_states=0;changed=0
        for row in game['moves']:
            before=d.record_value(s)
            assert old.evaluate(s)==cache.evaluate(s)
            a=bulk.terms(s);b=query.terms(s);assert a==b
            maps=semantic_attack_maps(s.position,provider.engine)
            # Match every Boolean, not merely feature totals.
            packed=pack_position(provider.native_rules,provider._state_only_payload(s.position,s.ply_count))
            expected=tuple(frozenset(i for i in range(64) if is_square_attacked(provider.native_rules,packed,i,o)) for o in (0,1))
            assert maps==expected
            if old.dynamic.evaluate(s)!=a['residual']:changed+=1
            assert before==d.record_value(s)
            legal={d.uci(a):a for a in d.iter_legal_actions(s,c)};assert row['move'] in legal
            s=d.apply_action(s,legal[row['move']],c);local_states+=1
        assert d.record_value(s)==game['final_state']
        report['games'].append(dict(source=name,index=index,states=local_states,semantic_residual_changed=changed));report['states']+=local_states;report['square_agreements']+=local_states*128;report['changed_semantic_leaf_values']+=changed
        d.write_record(out,report);print(name,index,local_states,changed,flush=True)
report['wall_seconds']=time.perf_counter()-wall;report['complete']=True;d.write_record(out,report)
print('states',report['states'],'square_agreements',report['square_agreements'],'seconds',round(report['wall_seconds'],3))
