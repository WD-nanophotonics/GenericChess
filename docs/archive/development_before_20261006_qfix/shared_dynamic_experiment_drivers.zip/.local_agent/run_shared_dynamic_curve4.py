"""New4ply fixed-budget resource curve."""
import sys,json,hashlib
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/chess_shared_dynamic_curve4_20261006.json';assert not out.exists()
raw=(ROOT/'docs/research/data/chess_development_suite.json').read_bytes();suite=json.loads(raw)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
limits=d.SearchLimits(max_depth=4,max_nodes=32768,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=True)
modes=('legacy','cached_legacy','semantic_bulk')
report=dict(scope='All original24 exposed development cases, fixed prices/search; check-only ON, risk OFF; not WDL/Elo',
    decision='Keep cache only if score/move parity; semantic option assessed on all finite gains/losses/completion/cost, not answer agreement alone',
    conditions=dict(limits=asdict(limits),tuning=asdict(tuning),native=True,ordering=True,tt=True,risk=False,interleaving='three backends within each case'),
    suite_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['scripts/chess_shared_dynamic.py','scripts/chess_development.py','generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/tuning.py']},
    actual_prefix=[],cases=[],complete=False)
d.write_record(out,report)
played=(ROOT/'.local_agent/chess_development_external_games.json').read_bytes();game=json.loads(played)['games'][1]
report['played_input_sha256']=hashlib.sha256(played).hexdigest()
s=d.root_from_fen(game['initial_fen'],c);witnesses=[s.position];prefix=[]
for row in game['moves'][:9]:
    prefix.append(row['move']);s=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==row['move']),c);witnesses.append(s.position)
report['actual_prefix_context']=dict(initial_fen=game['initial_fen'],prefix=prefix)
before=d.record_value(s)
for mode in modes:
    for policy in d.POLICIES:
        action,row=d.search_move(s,c,policy,limits,provider=provider,ordering=True,use_tt=True,dynamic=mode,tuning=tuning,_history_witnesses=tuple(witnesses))
        row.update(dynamic_backend=mode,completed=d.reason_complete(row,limits),state_preserved=d.record_value(s)==before)
        assert row['state_preserved'];report['actual_prefix'].append(row);d.write_record(out,report)
        print('prefix',mode,policy,row['move'],row['reason'],round(row['wall_seconds'],3),flush=True)
for case in suite['cases']:
    rows=[]
    for mode in modes:
        result=d.compare_case(case,c,limits,provider=provider,ordering=True,use_tt=True,dynamic=mode,tuning=tuning)
        for row in result['rows']:row['dynamic_backend']=mode
        rows.extend(result['rows'])
    report['cases'].append(dict(id=case['id'],fen=case['fen'],accepted_uci=case['accepted_uci'],rows=rows));d.write_record(out,report)
    print(case['id'],[(r['dynamic_backend'],r['policy'],r.get('move'),r['completed'],round(r.get('wall_seconds',0),3)) for r in rows],flush=True)
report['summary']={mode:d.comparison_summary([dict(rows=[r for r in case['rows'] if r['dynamic_backend']==mode]) for case in report['cases']]) for mode in modes}
report['complete']=True;d.write_record(out,report)
