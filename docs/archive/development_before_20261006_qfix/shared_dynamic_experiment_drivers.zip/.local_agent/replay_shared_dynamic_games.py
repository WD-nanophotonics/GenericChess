"""Complete new12-game move streams, full public/author legality and state."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import scripts.chess_development as d
out=ROOT/'.local_agent/chess_shared_dynamic_game_replay_20261006.json';assert not out.exists()
raw=(ROOT/'.local_agent/chess_shared_dynamic_games4_20261006.json').read_bytes();data=json.loads(raw);assert data['complete']
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());report=dict(scope='All declared12games public/author legal sets, board/rights/rawEP/full final state; no strength inference',input_sha256=hashlib.sha256(raw).hexdigest(),games=[],errors=[],complete=False)
for index,g in enumerate(data['games']):
    s=d.root_from_fen(g['initial_fen'],c);external=d.UciOpponent(None,g['initial_fen'],1)
    for ply,row in enumerate(g['moves']):
        legal={d.uci(a):a for a in d.iter_legal_actions(s,c)}
        if set(legal)!={m.uci() for m in external.board.legal_moves}:report['errors'].append(dict(game=index,ply=ply,kind='legal_set'))
        assert row['legal'] and row['move'] in legal
        s=d.apply_action(s,legal[row['move']],c);external.push(row['move'],s)
    assert d.record_value(s)==g['final_state']
    report['games'].append(dict(index=index,plies=len(g['moves']),backend=g['dynamic_backend'],white=g['white'],black=g['black'],core_end=g['end'],author_checkmate=external.board.is_checkmate(),author_stalemate=external.board.is_stalemate()));d.write_record(out,report)
assert not report['errors'];report['plies']=sum(r['plies'] for r in report['games']);report['complete']=True;d.write_record(out,report)
print('games',len(report['games']),'plies',report['plies'],'errors',len(report['errors']))
