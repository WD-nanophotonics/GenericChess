"""New three-backend run at original3ply/five seconds, two actual histories."""
import sys,json,hashlib
from pathlib import Path
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripts.chess_development as d
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=ROOT/'.local_agent/chess_actual_timeout_compare_20261006.json';assert not out.exists()
raw=(ROOT/'.local_agent/chess_check_only_internal_20261006.json').read_bytes();game=json.loads(raw)['games'][3]
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
limits=d.SearchLimits(max_depth=3,max_nodes=32768,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=8,quiescence_max_nodes=32768)
tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=True)
report=dict(scope='New declared same-budget followup of two observed timeouts; old failures unchanged, no frozen-test extension',
    limits=asdict(limits),tuning=asdict(tuning),input_sha256=hashlib.sha256(raw).hexdigest(),game_index=3,rows=[],complete=False,
    producer_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['scripts/chess_development.py','scripts/chess_shared_dynamic.py']})
s=d.root_from_fen(game['initial_fen'],c);witnesses=[s.position]
for original in game['moves'][:54]:
    if original['ply'] in (43,53):
        before=d.record_value(s)
        for mode in ('legacy','cached_legacy','semantic_bulk'):
            a,row=d.search_move(s,c,'geometric_half',limits,provider=provider,ordering=True,use_tt=True,dynamic=mode,tuning=tuning,_history_witnesses=tuple(witnesses))
            row.update(ply=original['ply'],dynamic_backend=mode,completed=d.reason_complete(row,limits),state_preserved=d.record_value(s)==before)
            assert row['state_preserved'];report['rows'].append(row);d.write_record(out,report)
            print(row['ply'],mode,row['move'],row['reason'],row['statistics']['completed_depth'],round(row['wall_seconds'],3),flush=True)
    s=d.apply_action(s,next(a for a in d.iter_legal_actions(s,c) if d.uci(a)==original['move']),c);witnesses.append(s.position)
report['complete']=True;d.write_record(out,report)
