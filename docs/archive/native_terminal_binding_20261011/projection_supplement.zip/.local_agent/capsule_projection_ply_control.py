"""Finite primary reproduction/adoption of DEV_AUX projected-ply defect."""
import ast,json,hashlib
from pathlib import Path
src=Path('.local_agent/raw_capsule_view_comparison.py').read_text(encoding='utf-8');exec(src.split('\nB=Path(')[0],globals())
B=Path('.local_agent/capsule-projected-ply-20261011');B.mkdir(exist_ok=True)
assert not (B/'declaration.json').exists()
write_record(B/'declaration.json',dict(question='Does retained Python parent view restore projected ply after child read, and can a local five-field stack repair close this concrete integration defect?',decision='Preserve old same-action/score/work controls but narrow state-restoration claim. Repair projection before new consumer; no full cohort rerun.',expected_seconds='under1min',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
class FixedCapsuleRuntime(CapsuleRuntime):
 def push(self,action,checkpoint=None):
  parent_ply=self.ply_count
  super().push(action,checkpoint)
  self.stack[-1]=(*self.stack[-1],parent_ply)
 def pop(self):
  self.capsule,self.cache,self.term,self.rawmap,self.ply_count=self.stack.pop()
class FixedRawRuntime(RawRuntime):
 def push(self,action,checkpoint=None):
  parent_ply=self.ply_count
  super().push(action,checkpoint)
  self.stack[-1]=(*self.stack[-1],parent_ply)
 def pop(self):
  self.capsule,self.cache,self.term,self.rawmap,self.ply_count=self.stack.pop()
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);rows=[]
for C in (CapsuleRuntime,RawRuntime,FixedCapsuleRuntime,FixedRawRuntime):
 rt=C(s.state,c,s._search_history_witnesses);saved=rt.full_snapshot();before=rt.state.ply_count
 a=sorted(rt.legal_actions(),key=repr)[0];rt.push(a);child=rt.state.ply_count;rt.pop();after=rt.state.ply_count
 native_restored=rt.full_snapshot()==saved;position_restored=rt.position==s.state.position
 fixed=C.__name__.startswith('Fixed');assert native_restored and position_restored and child==before+1
 assert after==before if fixed else after==child
 rows.append(dict(runtime=C.__name__,before=before,child=child,after=after,native_restored=native_restored,position_restored=position_restored,python_ply_restored=after==before))
write_record(B/'result.json',dict(complete=True,rows=rows,scope='No product runtime changed. Old frozen evaluator consumesPosition only; noisy_child readsPosition/terminal; terminal scores use recursiveply. Future consumers must use corrected projected state. Existing rawview/nativeattack timings retain original source, not repair timings.'))
print(json.dumps(rows))
