"""Decompose existing exposed Western scope mismatch; no search or tuning."""
import json,hashlib
from pathlib import Path
from dataclasses import replace
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.position import Position,Hands
from generic_chess.core.pieces import Piece
from generic_chess.core.attacks import pseudo_attacks
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.coordinates import index_to_square
from scripts.research_record import write_record,record_value
B=Path('.local_agent/western-attack-decomposition-20261011');B.mkdir(exist_ok=True);assert not (B/'declaration.json').exists()
write_record(B/'declaration.json',dict(question='Are the four existing Western legacy/semantic map differences exactly omitted pawn attack atoms?',decision='Exact decomposition forbids automatic cross-authority leaf substitution; diagnose existing feature definition, no price fitting/default change.',scope='Exposed four scope states, static8owner controls, expectedseconds<10',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));a=semantic_engine_for(c);old=json.loads(Path('.local_agent/leaf-attack-scope-20261011-repaired/result.json').read_bytes());rows=[]
for row in old['rows']:
 if row['case']!='western':continue
 v=row['position'];pos=Position(tuple(None if x is None else Piece(**x) for x in v['board']),tuple(Hands(tuple(tuple(y) for y in h['counts'])) for h in v['hands']),v['side_to_move'],v['ruleset_fingerprint'],tuple(v['aux_state']))
 pawns=replace(pos,board=tuple(x if x and x.current_type_id=='P' else None for x in pos.board))
 for o in (0,1):
  legacy=pseudo_attacks(pos,o,c);semantic=frozenset(index_to_square(i,c.board_shape) for i in a.attacked_squares(pos,o));pl=pseudo_attacks(pawns,o,c);ps=frozenset(index_to_square(i,c.board_shape) for i in a.attacked_squares(pawns,o));assert not pl and semantic==legacy|ps
  rows.append(dict(ply=row['ply'],owner=o,legacy_pawn_atoms=len(c.types_by_id['P'].movement_atoms),legacy_pawn_attacks=record_value(sorted(pl)),semantic_pawn_attacks=record_value(sorted(ps)),semantic_extra=record_value(sorted(semantic-legacy)),exact_union=True))
write_record(B/'result.json',dict(complete=True,rows=rows,conclusion='All8owner controls: legacy pawn atoms empty; adding semantic pawn attacks exactly explains full-map difference. Existing formulas differ in attack authority, not just backend cost. No universal sameleaf conversion.',source_cost='One static generated-rule decomposition; no search/training/extra workers'))
print('8owner map differences exactly pawn-attack omission')
