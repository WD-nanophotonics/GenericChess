"""True Shogi loss policy through actual persistent search and submitted moves."""
import json,time,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import snapshot,transient_legal_actions,public_action
from generic_chess.session.session import GameSession
from generic_chess.ai.limits import SearchLimits
B=Path('.local_agent/shared-terminal-shogi-entry-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
write_record(B/'declaration.json',dict(question='Does the rebuilt true-loss StandardShogi capsule support actual persistent-search decisions through submitted legal moves and exact history?',plies=6,depth=1,max_nodes=10000,seconds=5,quiescence=0,tt_megabytes=0,decision='Any rejection, illegal result or state/history drift restricts newly claimed entry. Successful6plies demonstrate finite entry only, not all repetition/declaration rules, PVE UI integration or strength.',estimated_cost='seconds; maximum30seconds under1h',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));n=compile_native_semantic_rules(c);e=SemanticSearchEngine(c,n,tt_megabytes=0);s=GameSession(c);rows=[];limits=SearchLimits(max_depth=1,max_nodes=10000,max_time_seconds=5,quiescence_max_depth=0)
for ply in range(6):
 state=s.state;w=s._search_history_witnesses;cap=pack_semantic_search_position(c,n,s);before=snapshot(n,cap);legals=s.legal_actions();assert set(legals)=={public_action(n,a) for a in transient_legal_actions(n,cap)};t=time.perf_counter();result=e.search(s,limits);wall=time.perf_counter()-t;assert result.completed_depth==1 and result.action in legals;assert s.state==state and s._search_history_witnesses==w and snapshot(n,cap)==before;rows.append(dict(ply=ply,caller_seconds=wall,history_count=len(before['history']),legal_count=len(legals),result=record_value(result)));s.submit(result.action)
write_record(B/'result.json',dict(complete=True,rows=rows,stalemate_policy=c.support.stalemate_result,terminal_bound=n._bound_stalemate_result,final_history_count=len(s.state.history),final_result=record_value(s.result)));print('six actual searches',sum(r['result']['nodes'] for r in rows),'nodes',len(s.state.history),'history')
