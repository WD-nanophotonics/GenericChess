"""Whitelist only Agent-produced synthetic/source/regression evidence."""
import json,hashlib,zipfile
from pathlib import Path
base=Path('.local_agent')
folders=['shared-terminal-extension-20261011','capsule-native-terminal-dependency-20261011','primary-binding-witness-20261011','leaf-projection-cost-20261011','leaf-attack-compatibility-20261011','native-attack-leaf-adapter-20261011','native-attack-leaf-audit-20261011','leaf-attack-scope-20261011','leaf-attack-scope-20261011-repaired','raw-capsule-view-comparison-20261011','attack-coordinate-reuse-20261011','raw-view-state-dependency-20261011','shared-terminal-shogi-entry-20261011','combined-leaf-d2-20261011','combined-leaf-d2-audit-20261011','terminal-binding-source-20261011']
files=[]
for folder in folders:
 for p in (base/folder).rglob('*'):
  if p.is_file() and p.suffix in ('.json','.py','.log'):files.append(p)
producers=['capsule_native_terminal_dependency.py','leaf_projection_cost.py','leaf_attack_compatibility.py','native_attack_leaf_adapter.py','native_attack_leaf_audit.py','leaf_attack_scope.py','raw_capsule_view_comparison.py','attack_coordinate_reuse.py','verify_raw_view_controls.py','shared_terminal_shogi_entry.py','combined_leaf_d2.py','combined_leaf_d2_audit.py','native_capsule_q4.py','generated_thin_q4.py','native_leaf_compatibility.py','analyze_native_leaf_compatibility.py','leaf-attack-scope-import-failure.py','leaf-attack-scope-state-failure.py','combined-leaf-d2-import-failure.py','combined-leaf-d2-class-failure.py','archive_terminal_binding.py']
logs=['terminal-full-initial-truncated-20261011.json','terminal-fullsuite-workspace-temp.log','terminal-binding-full-final-20261011.log','terminal-binding-coordinates-full-20261011.log','terminal-child-tests-20261011.log','primary-binding-tests-20261011.log','terminal-bridge-tests-20261011.log','semantic-coordinate-tests-20261011.log','terminal-policy-full-info-cost-20261011.json','terminal-failure-disposition-20261011.json','combined-leaf-d2-failure-disposition-20261011.json','leaf-attack-scope-import-failure.log','leaf-attack-scope-state-failure.log','combined-leaf-d2-import-failure.log','combined-leaf-d2-class-failure.log','combined-leaf-d2-20261011-final.log','combined-leaf-d2-audit-20261011.log','shared-terminal-shogi-entry-20261011.log','raw-view-state-dependency-20261011.log','leaf-projection-cost-20261011.log','leaf-attack-compatibility-20261011.log','native-attack-leaf-adapter-20261011.log','native-attack-leaf-audit-20261011.log','leaf-attack-scope-repaired-20261011.log','raw-capsule-view-comparison-20261011.log','attack-coordinate-reuse-20261011.log']
files.extend(base/p for p in producers+logs)
files.extend([base/'native-leaf-compatibility-20261011/result.json',base/'native-leaf-compatibility-20261011/analysis.json',base/'q4-prospective-20261011-repaired/samples.json'])
source=['generic_chess/_native/native_module.c','generic_chess/_native/native_semantic_rules.c','generic_chess/_native/native_semantic_rules.h','generic_chess/native/compiler.py','generic_chess/native/semantic.py','generic_chess/native/semantic_engine.py','generic_chess/native/adapter.py','generic_chess/ai/evaluation/semantic_attacks.py','generic_chess/ai/evaluation/evaluator.py','generic_chess/ai/alphabeta/quiescence.py','scripts/full_q_refresh_comparison.py','scripts/search_backend_comparison.py','scripts/research_record.py','scripts/build_native_zig.py','scripts/chess_development.py','tests/product/test_native_terminal_policy_support.py','tests/product/test_native_evaluator_binding.py','tests/product/test_f58_compact_nonlinear.py','tests/product/test_semantic_attack_map.py','tests/development/test_native_backend_bridge.py','tests/rule_semantics_ir_fixtures.py']
files.extend(Path(p) for p in source);files=sorted(set(files),key=lambda p:p.as_posix());members=[]
for p in files:
 assert p.exists(),p
 name=p.as_posix();assert not any(t in name.lower() for t in ('private','slack','handoff','session.json','next_work','credential'))
 raw=p.read_bytes();members.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
for folder in ('shared-terminal-extension-20261011','capsule-native-terminal-dependency-20261011','native-attack-leaf-adapter-20261011','combined-leaf-d2-20261011','combined-leaf-d2-audit-20261011'):
 assert json.loads((base/folder/'result.json').read_bytes())['complete'],folder
archive=Path('docs/archive/native_terminal_binding_20261011/evidence.zip');archive.parent.mkdir(parents=True,exist_ok=True)
if archive.exists():raise RuntimeError('Refuse replacing frozen archive')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.writestr(p.as_posix(),p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(members)
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
index=dict(schema=1,base_sha='5d8e55f2f2cd330312364b19d4099f8c79d2fcac',science_complete=False,scope='Agent-only synthetic finite experiments, actual bound binary metadata, changed source/producers, failure limits and regressions. RawSlack/account/private/user inputs, sessions/memo and nativebinary excluded. Full-domain/default/PVE/strength claims not made.',archive=dict(path=archive.as_posix(),bytes=archive.stat().st_size,uncompressed_bytes=sum(m['bytes'] for m in members),members=len(members),sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),prior_frozen_archive=dict(path='docs/archive/q4_tradeoff_20261011/evidence.zip',sha256='ae4216f8070db29f91726e314e7d607c4ccb1a7873f7d29b256b754e248031af',unchanged=True),source_provenance_limits=json.loads((base/'terminal-failure-disposition-20261011.json').read_bytes())['source_limits'],full_regression=dict(tests=2104,seconds=203.66,log='.local_agent/terminal-binding-coordinates-full-20261011.log'),members=members)
p=Path('docs/research/data/native_terminal_binding_20261011.json')
if p.exists():raise RuntimeError('Refuse replacing frozen index')
p.write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(index['archive']))
