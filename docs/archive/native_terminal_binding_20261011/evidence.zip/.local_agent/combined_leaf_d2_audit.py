"""Deeper all-leaf equivalence audit; diagnostic cost is not a speed control."""
import ast,json,time,hashlib
from pathlib import Path
combined_source=Path('.local_agent/combined_leaf_d2.py').read_text(encoding='utf-8');exec(combined_source.split('\nB=Path(')[0],globals())
B=Path('.local_agent/combined-leaf-d2-audit-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
d=dict(question='Could equal deeper search returns hide a changed internal leaf formula in the combined adapter?',root='seed1008-ply8',depth=2,q=4,hardq=8,nodes=100000,seconds=90,calls=1,expected_seconds='~under1min; interruptible single run under1h',decision='Any internal set/score mismatch rejects sameleaf attribution even if root/trace agrees. Complete equality supports only this deeper finite interface; cap retains UNKNOWN and no automatic extension.',scope='Optional decision-changing leaf audit on the already exposed deeper tree; exact old formula is diagnostic reference, no fitting or success criterion changes.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();prof=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(8008)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
reference=p.Evaluator(c,prof,ec)
class AuditedCachedEvaluator(CachedSquareEvaluator):
 def __init__(self,*a):super().__init__(*a);self.leaf_checks=0;self.set_checks=0;self.score_hash=hashlib.sha256()
 def _attack_maps(self,state):
  actual=super()._attack_maps(state);expected=reference._attack_maps(state);assert actual==expected;self.set_checks+=2;return actual
 def evaluate(self,state):
  actual=super().evaluate(state);expected=reference.evaluate(state);assert actual==expected;self.leaf_checks+=1;self.score_hash.update(str(actual).encode()+b';');return actual
RuntimeChoice=RawRuntime;ev=AuditedCachedEvaluator(c,prof,ec);p.rr.stopped();t=time.perf_counter();v=search(c,s.state,s._search_history_witnesses,ev,True);wall=time.perf_counter()-t
write_record(B/'result.json',dict(complete=v['reason']=='complete',search=v,caller_seconds=wall,leaf_checks=ev.leaf_checks,attack_set_checks=ev.set_checks,mismatches=0,ordered_leaf_score_sha256=ev.score_hash.hexdigest(),scope='Audit instrumentation charged; not timing control'))
assert ev.leaf_checks==v['work']['eval'];print('deeper audit',v['reason'],ev.leaf_checks,ev.set_checks,round(wall,3))
