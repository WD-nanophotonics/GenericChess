"""Separate every-leaf semantic audit and instrumented residual profile."""
import ast,json,time,hashlib,cProfile,pstats
from pathlib import Path
src=Path('.local_agent/native_attack_leaf_adapter.py').read_text(encoding='utf-8')
# Reuse exact class/driver definitions without executing the frozen comparison.
nodes=ast.parse(src).body;filtered=[]
for node in nodes:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='B' for t in node.targets):break
 filtered.append(node)
exec(compile(ast.Module(body=filtered,type_ignores=[]),'<adapter-imports>','exec'),globals())
for node in nodes:
 if isinstance(node,ast.ClassDef):exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact-adapter-class>','exec'),globals())
source=Path('.local_agent/generated_thin_q4.py').read_text();fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='search');code=ast.unparse(fn).replace('rt = SearchPathRuntime(initial, c, history_witnesses=witnesses, legal_binding_provider=provider)','rt = LeafRuntime(initial, c, witnesses)').replace('p.runtime_state(rt)','rt.full_snapshot()');exec(compile(code,'<exact-leaf-audit-driver>','exec'),globals())
B=Path('.local_agent/native-attack-leaf-audit-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
d=dict(question='Are all evaluated leaves exact on the larger existingD1/q4 tree, and which residual actual functions dominate after the scalar-attack adapter?',root='seed1008-ply8',depth=1,q=4,hardq=8,nodes=100000,seconds=90,calls=2,scope='One every-leaf shadowaudit and one separate cProfile run; both diagnostic, not timing controls. No cohort extension/result-based budget increase.',decision='Any leaf set/score mismatch rejects sameleaf claim; observed function costs select one concrete interface follow-on, not overlapping additive gains.',estimated_cost='~under1minute including instrumentation; under1h',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();prof=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(8008)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
ref=p.Evaluator(c,prof,ec)
class AuditedEvaluator(NativeAttackEvaluator):
 def __init__(self,*a):super().__init__(*a);self.leaf_checks=0;self.set_checks=0;self.score_hash=hashlib.sha256()
 def _attack_maps(self,state):
  actual=super()._attack_maps(state);expected=ref._attack_maps(state);assert actual==expected;self.set_checks+=2;return actual
 def evaluate(self,state):
  v=super().evaluate(state);expected=ref.evaluate(state);assert v==expected;self.leaf_checks+=1;self.score_hash.update(str(v).encode()+b';');return v
audit=AuditedEvaluator(c,prof,ec);t=time.perf_counter();a=search(c,s.state,s._search_history_witnesses,audit,True);wall=time.perf_counter()-t
baseline=next(r for r in json.loads(Path('.local_agent/native-attack-leaf-adapter-20261011/result.json').read_bytes())['rows'] if r['root']=='seed1008-ply8' and r['leaf_attack_backend']=='python')
assert all(a[k]==baseline[k] for k in ('reason','score','action','work','trace')) and a['reason']=='complete';assert audit.leaf_checks==a['work']['eval']
write_record(B/'audit.json',dict(complete=True,search=a,caller_seconds=wall,leaf_checks=audit.leaf_checks,attack_set_checks=audit.set_checks,mismatches=0,ordered_leaf_score_sha256=audit.score_hash.hexdigest()))
fast=NativeAttackEvaluator(c,prof,ec);pr=cProfile.Profile();t=time.perf_counter();pr.enable();v=search(c,s.state,s._search_history_witnesses,fast,True);pr.disable();wall=time.perf_counter()-t;assert all(v[k]==baseline[k] for k in ('reason','score','action','work','trace'))
st=pstats.Stats(pr);functions=[]
for (file,line,name),(primitive,calls,exclusive,inclusive,callers) in st.stats.items():functions.append(dict(file=file,line=line,function=name,primitive_calls=primitive,calls=calls,exclusive_seconds=exclusive,inclusive_seconds=inclusive))
write_record(B/'profile.json',dict(complete=True,search=v,caller_seconds=wall,native_attack_queries=fast.attack_queries,native_attack_seconds=fast.attack_seconds,functions=sorted(functions,key=lambda z:-z['inclusive_seconds']),limit='Inclusive overlapping spans cannot be summed; cProfile runs are not speed controls.'));print('audit',audit.leaf_checks,audit.set_checks,round(wall,3))
