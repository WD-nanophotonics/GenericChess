import ast,json
from pathlib import Path
src=Path('.local_agent/native_capsule_q4.py').read_text(encoding='utf-8');exec(src.split('B=Path(')[0],globals());cl=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef));exec(compile(ast.Module(body=[cl],type_ignores=[]),'<capsule-runtime>','exec'),globals())
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
B=Path('.local_agent/capsule-native-terminal-dependency-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
selected={'chess-ep':'e5d6','chess-promotion':'a7a8q','shogi-promotion':'5c5b+','shogi-drop':'R*5e'}
write_record(B/'declaration.json',dict(question='With rebuilt shared Native terminal authority, does capsule adapter preserve concrete EP auxiliary, promotion/base identity, drops/hands and checked history across a supported effect and its replies?',cases=selected,replies='first2 repr-sorted legal after selected effect',max_states=16,scope='Changed premise: rebuilt C shared stalemate policy owns terminal; independent Core is oracle only, no shadow inside adapter. Reuses declared16states, true builtin policy/fingerprint; finite equality not full-domain support/performance',decision='Mismatch scopes adapter and blocks integration; equality permits caller contract work with frozen Python leaf. No search cohort rerun',estimated_cost='seconds to under1min'))
rows=[]
for case in CASES:
 if case['id'] not in selected:continue
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));core=CoreBoard(case,c);rt=CapsuleRuntime(core.initial,c,core.witnesses);witnesses=list(core.witnesses);saved=rt.full_snapshot()
 def check(stage):
  assert rt.position==core.runtime.position and rt.terminal_status==core.runtime.terminal_status
  assert set(rt.legal_actions())==set(core.runtime.legal_actions())
  fresh=pack_semantic_search_position(c,rt.native,SimpleNamespace(compiled=c,state=SimpleNamespace(position=core.runtime.position,ply_count=core.runtime.ply_count,history=tuple(core.runtime.history)),_search_witnesses=tuple(witnesses)));assert ns.snapshot(rt.native,fresh)==rt.full_snapshot()
  rows.append(dict(case=case['id'],stage=stage,position=record_value(rt.position),terminal=record_value(rt.terminal_status),snapshot=rt.full_snapshot(),legal_count=len(rt.legal_actions()),core_history=record_value(core.runtime.history)))
 check('root');actions={core.label(a):a for a in core.runtime.legal_actions()};a=actions[selected[case['id']]];rt.push(a);core.runtime.push(a);witnesses.append(core.runtime.position)
 try:
  check('effect');write_record(B/'partial.json',dict(complete=False,rows=rows))
  for i,b in enumerate(sorted(core.runtime.legal_actions(),key=repr)[:2]):
   rt.push(b);core.runtime.push(b);witnesses.append(core.runtime.position)
   try:check(f'reply{i}')
   finally:core.runtime.pop();witnesses.pop();rt.pop()
 finally:core.runtime.pop();witnesses.pop();rt.pop()
 assert rt.full_snapshot()==saved;core.runtime.assert_balanced();rt.assert_balanced()
write_record(B/'result.json',dict(complete=True,rows=rows,cases=len(selected)));print('matched states',len(rows))
