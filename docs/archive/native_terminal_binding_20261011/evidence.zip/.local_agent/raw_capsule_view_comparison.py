"""Existing raw snapshot projection; all Native history remains authoritative."""
import ast,json,time,hashlib
from pathlib import Path
src=Path('.local_agent/native_attack_leaf_adapter.py').read_text(encoding='utf-8');nodes=ast.parse(src).body;imports=[]
for node in nodes:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='B' for t in node.targets):break
 imports.append(node)
exec(compile(ast.Module(body=imports,type_ignores=[]),'<adapter-imports>','exec'),globals())
for node in nodes:
 if isinstance(node,ast.ClassDef):exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact-adapter-class>','exec'),globals())
from generic_chess.native import _module
class RawRuntime(LeafRuntime):
 @property
 def position(self):
  if self.cache is None:
   s=_module().semantic_position_snapshot(self.native.capsule,self.capsule);ids=self.native.type_ids
   board=tuple(None if x is None else Piece(int(x[2]),ids[int(x[0])],ids[int(x[1])],bool(x[3])) for x in s['board']);hands=tuple(Hands(tuple(sorted((ids[i],int(v)) for i,v in enumerate(h) if v))) for h in s['hands']);aux=tuple(((int(z[0]),int(z[1])),tuple(z[2]) if isinstance(z[2],(list,tuple)) else z[2]) for z in s['aux_state']);self.cache=Position(board,hands,int(s['side']),self.compiled.ruleset_fingerprint,aux);self.ply_count=int(s['ply']);self.views+=1
  return self.cache
source=Path('.local_agent/generated_thin_q4.py').read_text();fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='search');code=ast.unparse(fn).replace('rt = SearchPathRuntime(initial, c, history_witnesses=witnesses, legal_binding_provider=provider)','rt = RuntimeChoice(initial, c, witnesses)').replace('p.runtime_state(rt)','rt.full_snapshot()').replace('root_restored=True)', 'root_restored=True, position_views=rt.views, transitions=rt.transitions)');exec(compile(code,'<raw-view-driver>','exec'),globals())
B=Path('.local_agent/raw-capsule-view-comparison-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
d=dict(question='Does raw snapshot projection remove normalized-history conversion cost on the observed78793view tree while preserving all state/history and sameleaf search?',root='seed1008-ply8',depth=1,q=4,hardq=8,nodes=100000,seconds=90,orders=2,calls=4,expected_seconds='~under1min; interruptible under1h',decision='Exact positions/fullhistory at68controls and exact work/action/score/trace required. If paired actual caller cost falls, retain existingAPI raw-view prototype; else defer. No new C API, skipped terminal/quiet pushes, or product changes.',scope='Changed premise from noisy tiny68view timing: larger-tree instrumented profile locates1.88s normalizedsnapshot versus0.23s C snapshot. Profile overhead is not speed control. Full Native histories remain; full_snapshot still canonical authority.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();prof=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(8008)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
old=LeafRuntime(s.state,c,s._search_history_witnesses);raw=RawRuntime(s.state,c,s._search_history_witnesses);saved=raw.full_snapshot();checks=[]
for a in [None]+sorted(old.legal_actions(),key=repr)[:16]:
 if a is not None:old.push(a);raw.push(a)
 try:
  assert old.position==raw.position and old.terminal_status==raw.terminal_status and old.full_snapshot()==raw.full_snapshot();checks.append(dict(action=record_value(a),position=record_value(raw.position),snapshot=raw.full_snapshot()))
 finally:
  if a is not None:old.pop();raw.pop()
assert raw.full_snapshot()==saved
write_record(B/'view_checks.json',dict(complete=True,checks=checks,mismatches=0,scope='17existing1008-ply8 positions; full-history exact'))
rows=[]
for order in range(2):
 for mode in (('normalized','raw') if order==0 else ('raw','normalized')):
  RuntimeChoice=LeafRuntime if mode=='normalized' else RawRuntime;ev=NativeAttackEvaluator(c,prof,ec);p.rr.stopped();t=time.perf_counter();v=search(c,s.state,s._search_history_witnesses,ev,True);wall=time.perf_counter()-t;rows.append(dict(order=order,projection=mode,caller_seconds=wall,native_attack_queries=ev.attack_queries,**v));write_record(B/'result.json',dict(complete=False,rows=rows));print(order,mode,v['reason'],v['score'],v['position_views'],round(wall,4),flush=True)
 a,b=rows[-2:];assert all(a[k]==b[k] for k in ('reason','score','action','work','trace','position_views','transitions')) and a['reason']=='complete'
write_record(B/'result.json',dict(complete=True,rows=rows,pairs=2,matched=2))
