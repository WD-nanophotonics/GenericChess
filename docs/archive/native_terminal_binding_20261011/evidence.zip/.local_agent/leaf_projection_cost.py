"""Finite same-leaf projection comparison; no feature replacement or fitting."""
import ast,json,time,hashlib
from pathlib import Path
src=Path('.local_agent/native_capsule_q4.py').read_text(encoding='utf-8')
exec(src.split('B=Path(')[0],globals())
cl=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef))
exec(compile(ast.Module(body=[cl],type_ignores=[]),'<frozen-capsule-runtime>','exec'),globals())
from generic_chess.native import _module
B=Path('.local_agent/leaf-projection-cost-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
write_record(B/'declaration.json',dict(question='Can existing raw C snapshot avoid normalized history conversion when projecting Position for the exact frozen Python leaf?',samples=68,repeats=3,orders='normalized/raw then raw/normalized alternating by batch; same immutable capsules',decision='Exact Position/leaf equality required. If projection measurably smaller, retain local adapter candidate; if little effect, inspect narrow history-free view instead. No production defaults/search budget changes.',estimated_cost='seconds to under1min; build/setup charged separately',scope='Exposed finite interface microcost, not end-to-end speedup; full C histories retained. No new search cohort or fitting.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
old=json.loads(Path('.local_agent/native-leaf-compatibility-20261011/result.json').read_bytes())['rows'];samples=[];start=time.perf_counter()
for seed in (1006,1008):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec);s=p.GameSession(c);rng=random.Random(seed+7000)
 for ply in range(9):
  if ply in (0,8):
   rt=CapsuleRuntime(s.state,c,s._search_history_witnesses);saved=rt.full_snapshot();actions=[None]+sorted(rt.legal_actions(),key=repr)[:16]
   for a in actions:
    if a is not None:rt.push(a)
    try:
     x=next(x for x in old if x['root']==f'{seed}-ply{ply}' and x['action']==record_value(a));assert record_value(rt.position)==x['position'];assert ev.evaluate(rt.state)==x['python'];samples.append((rt.native,rt.capsule,c,ev,x,rt.full_snapshot()))
    finally:
     if a is not None:rt.pop()
   assert rt.full_snapshot()==saved
  if ply<8:s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
setup=time.perf_counter()-start

def view(n,cap,c,mode):
 s=ns.snapshot(n,cap) if mode=='normalized' else _module().semantic_position_snapshot(n.capsule,cap)
 aux=s['aux_state'] if mode=='normalized' else tuple(((int(z[0]),int(z[1])),tuple(z[2]) if isinstance(z[2],(list,tuple)) else z[2]) for z in s['aux_state'])
 ids=n.type_ids
 board=tuple(None if x is None else Piece(int(x[2]),ids[int(x[0])],ids[int(x[1])],bool(x[3])) for x in s['board'])
 hands=tuple(Hands(tuple(sorted((ids[i],int(v)) for i,v in enumerate(h) if v))) for h in s['hands'])
 return Position(board,hands,int(s['side']),c.ruleset_fingerprint,aux)
rows=[]
for batch in range(3):
 for mode in (('normalized','raw') if batch%2==0 else ('raw','normalized')):
  t=time.perf_counter();positions=[view(n,cap,c,mode) for n,cap,c,ev,x,saved in samples];projection=time.perf_counter()-t
  t=time.perf_counter();scores=[ev.evaluate(SimpleNamespace(position=pos)) for pos,(_,_,_,ev,_,_) in zip(positions,samples)];evaluation=time.perf_counter()-t
  for pos,score,(_,_,_,ev,x,_) in zip(positions,scores,samples):assert record_value(pos)==x['position'] and score==x['python']
  rows.append(dict(batch=batch,mode=mode,views=len(samples),evaluation_calls=len(scores),projection_seconds=projection,evaluation_seconds=evaluation,scores=scores))
for n,cap,c,ev,x,saved in samples:assert ns.snapshot(n,cap)==saved
write_record(B/'result.json',dict(complete=True,samples=len(samples),setup_seconds=setup,rows=rows,full_history_preserved=True,position_leaf_mismatches=0,history_lengths=[len(s[-1]['history']) for s in samples]))
print(json.dumps(dict(samples=len(samples),setup_seconds=setup,rows=[{k:v for k,v in r.items() if k!='scores'} for r in rows])))
