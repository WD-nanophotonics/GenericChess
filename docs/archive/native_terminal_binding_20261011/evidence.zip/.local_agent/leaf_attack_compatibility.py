"""Existing scalar attack API against frozen evaluator geometry, without fitting."""
import json,time,hashlib,sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
from generic_chess.core.position import Position,Hands
from generic_chess.core.pieces import Piece
from generic_chess.core.coordinates import index_to_square
B=Path('.local_agent/leaf-attack-compatibility-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
write_record(B/'declaration.json',dict(question='Do existing Native scalar attack sets equal the exact frozen Python evaluator attack sets on the prior68positions?',samples=68,decision='Any set mismatch rejects substituting Native scalar attack authority for same-leaf cost control; no tuning. Equality only permits scoped timing, not full-domain adoption.',estimated_cost='seconds; two owner queries perposition; no search',scope='Current position attack geometry only; pack_current_position is not terminal/history authority.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
old=json.loads(Path('.local_agent/native-leaf-compatibility-20261011/result.json').read_bytes())['rows'];rows=[]
for seed in (1006,1008):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();prof=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,prof,ec);native=compile_native_semantic_rules(c)
 for x in old:
  if not x['root'].startswith(str(seed)):continue
  z=x['position'];pos=Position(tuple(None if v is None else Piece(**v) for v in z['board']),tuple(Hands(tuple(tuple(v) for v in h['counts'])) for h in z['hands']),z['side_to_move'],z['ruleset_fingerprint'],tuple(z['aux_state']));cap=ns.pack_current_position(native,pos,ply_count=0);py=ev._attack_maps(SimpleNamespace(position=pos));na=tuple(frozenset(index_to_square(i,c.board_size) for i in ns.attacked_squares(native,cap,o)) for o in (0,1))
  rows.append(dict(root=x['root'],action=x['action'],python=[sorted(a) for a in py],native=[sorted(a) for a in na],equal=py==na))
write_record(B/'result.json',dict(complete=True,rows=rows,mismatches=sum(not x['equal'] for x in rows),attack_queries=2*len(rows)));print(len(rows),sum(not x['equal'] for x in rows))
