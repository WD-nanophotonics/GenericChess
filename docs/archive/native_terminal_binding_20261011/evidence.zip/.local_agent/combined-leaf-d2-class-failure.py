"""One predeclared deeper workload, current sameleaf combined view control."""
import ast,json,time,hashlib
from pathlib import Path
src=Path('.local_agent/attack_coordinate_reuse.py').read_text(encoding='utf-8');exec(src.split("\nB=Path(")[0],globals())
node=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef) and n.name=='CachedSquareEvaluator');exec(compile(ast.Module(body=[node],type_ignores=[]),'<cached-square-evaluator>','exec'),globals())
B=Path('.local_agent/combined-leaf-d2-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
d=dict(question='Do the independently motivated view/attack conversions retain exact frozen leaf search at the existing deeperD2 workload, and what is their combined paired caller cost?',root='seed1008-ply8',depth=2,q=4,hardq=8,nodes=100000,seconds=90,orders=2,calls=4,expected_seconds='~2min from earlier32sD2calls; interruptible under1h',decision='Any work/action/score/trace mismatch rejects combined sameleaf integration. Match and substantial actual caller reduction supports a scoped readonly capsule interface next; small benefit keeps effort on residual recursion/action decode. No fullq4/domain/default/strength claim.',scope='Changed premise: sharedterminal policy built; exact leaf sets audited; rawview and coordinate costs isolated. Current baseline original Python leaf/normalized capsule versus combined candidate. Earlier frozen results untouched; oppositeorder pairs under ordinary concurrent load.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();prof=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(8008)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
rows=[]
for order in range(2):
 for mode in (('original','combined') if order==0 else ('combined','original')):
  RuntimeChoice=CapsuleRuntime if mode=='original' else RawRuntime;ev=p.Evaluator(c,prof,ec) if mode=='original' else CachedSquareEvaluator(c,prof,ec);p.rr.stopped();t=time.perf_counter();v=search(c,s.state,s._search_history_witnesses,ev,True);wall=time.perf_counter()-t;rows.append(dict(order=order,mode=mode,caller_seconds=wall,attack_queries=0 if mode=='original' else ev.attack_queries,**v));write_record(B/'result.json',dict(complete=False,rows=rows));print(order,mode,v['reason'],v['score'],v['work'],round(wall,4),flush=True)
 a,b=rows[-2:];assert all(a[k]==b[k] for k in ('reason','score','action','work','trace','position_views','transitions')) and a['reason']=='complete'
write_record(B/'result.json',dict(complete=True,rows=rows,pairs=2,matched=2))
