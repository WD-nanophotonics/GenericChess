"""Exact formula adapter using Native scalar attacks, finite exposed development."""
import ast,json,time,hashlib
from pathlib import Path
src=Path('.local_agent/native_capsule_q4.py').read_text(encoding='utf-8')
exec(src.split('B=Path(')[0],globals())
cl=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef))
exec(compile(ast.Module(body=[cl],type_ignores=[]),'<frozen-capsule-runtime>','exec'),globals())
from generic_chess.core.coordinates import index_to_square
from generic_chess.core.attacks import pseudo_attacks
B=Path('.local_agent/native-attack-leaf-adapter-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
d=dict(question='Do scalar Native attacks reduce exact frozen Python evaluator cost and preserve full lexicalq4 search work/trace on two existing roots?',roots=['seed1006-ply8','seed1008-ply8'],depth=1,q=4,hardq=8,nodes=100000,seconds=90,orders=2,calls=8,maximum_seconds=720,expected_seconds='~under2min; interruptible, singlerun under1hour',decision='Reject adapter if any leaf set/score or search work/score/action/trace mismatch. If equal, retain scoped adapter and attribute actual leaf/caller cost; no product/default/UI/full-domain claim.',scope='Changed premise: prior68 scalar attack sets equal, unlike Native dynamic features. Same Python material/promotion/anchor equations, runtime/history/terminal, lexical ordering and qpolicy; only _attack_maps queries replaced. Ordinary concurrent load; paired/oppositeorder costs, not noisefree speedup.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
class NativeAttackEvaluator(p.Evaluator):
 def __init__(self,*args):super().__init__(*args);self.attack_queries=0;self.attack_seconds=0.;self.audit_mismatches=0
 def _attack_maps(self,state):
  t=time.perf_counter();n=self._compiled.board_size
  attacks=tuple(frozenset(index_to_square(i,n) for i in ns.attacked_squares(state.native_rules,state.native_capsule,o)) for o in (0,1))
  self.attack_queries+=2;self.attack_seconds+=time.perf_counter()-t
  return attacks
class LeafRuntime(CapsuleRuntime):
 @property
 def state(self):return SimpleNamespace(position=self.position,terminal_status=self.terminal_status,ply_count=self.ply_count,native_rules=self.native,native_capsule=self.capsule)
source=Path('.local_agent/generated_thin_q4.py').read_text();fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='search');code=ast.unparse(fn).replace('rt = SearchPathRuntime(initial, c, history_witnesses=witnesses, legal_binding_provider=provider)','rt = LeafRuntime(initial, c, witnesses)').replace('p.runtime_state(rt)','rt.full_snapshot()');assert 'SearchPathRuntime(' not in code
exec(compile(code,'<exact-leaf-adapter-driver>','exec'),globals())
write_record(B/'driver.json',dict(original_function_sha256=hashlib.sha256(ast.unparse(fn).encode()).hexdigest(),changed_function=code,only_changes='State carries exact capsule to _attack_maps; recursion/formula/ordering/qpolicy retained. Diagnostic query counters charged in candidate.'))
original=json.loads(Path('.local_agent/q4-prospective-20261011-repaired/samples.json').read_bytes())['samples'];old=json.loads(Path('.local_agent/native-leaf-compatibility-20261011/result.json').read_bytes())['rows'];roots=[];checks=[]
for seed in (1006,1008):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec);fast=NativeAttackEvaluator(c,profile,ec);s=p.GameSession(c);rng=random.Random(seed+7000)
 for ply in range(9):
  if ply in (0,8):
   name=f'seed{seed}-ply{ply}';prior=next(x for x in original if x.get('root')==name);assert record_value(s.state)==prior['initial'] and record_value(profile)==prior['profile'];rt=LeafRuntime(s.state,c,s._search_history_witnesses);saved=rt.full_snapshot();actions=[None]+sorted(rt.legal_actions(),key=repr)[:16]
   for a in actions:
    if a is not None:rt.push(a)
    try:
     x=next(x for x in old if x['root']==f'{seed}-ply{ply}' and x['action']==record_value(a));assert record_value(rt.position)==x['position'];assert fast._attack_maps(rt.state)==ev._attack_maps(rt.state);base=ev.evaluate(rt.state);score=fast.evaluate(rt.state);assert score==base==x['python'];checks.append(dict(root=name,action=record_value(a),score=score))
    finally:
     if a is not None:rt.pop()
   assert rt.full_snapshot()==saved
   if ply==8:roots.append((name,c,s.state,s._search_history_witnesses,ev,fast))
  if ply<8:s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
write_record(B/'leaf_checks.json',dict(complete=True,checks=checks,mismatches=0))
rows=[]
for name,c,initial,w,ev,fast in roots:
 for order in range(2):
  for mode in (('python','native_attacks') if order==0 else ('native_attacks','python')):
   chosen=ev if mode=='python' else fast
   fast.attack_queries=0;fast.attack_seconds=0.
   p.rr.stopped();start=time.perf_counter();v=search(c,initial,w,chosen,True);caller=time.perf_counter()-start
   row=dict(root=name,depth=1,order=order,leaf_attack_backend=mode,caller_seconds=caller,native_attack_queries=fast.attack_queries,native_attack_seconds=fast.attack_seconds,**v);rows.append(row);write_record(B/'result.json',dict(complete=False,rows=rows));print(name,order,mode,v['reason'],v['score'],v['work'],round(caller,4),flush=True)
  a,b=rows[-2:]
  assert all(a[k]==b[k] for k in ('reason','score','action','work','trace')) and a['reason']=='complete'
write_record(B/'result.json',dict(complete=True,rows=rows,pairs=4,matched=4))
