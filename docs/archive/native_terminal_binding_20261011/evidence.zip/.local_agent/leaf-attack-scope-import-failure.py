"""Finite semantic/legacy attack authority scope, not new performance samples."""
import json,hashlib,sys
from pathlib import Path
sys.path[:0]=[str(Path(__file__).resolve().parents[1]),str(Path('tests/fixtures').resolve())]
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import attacked_squares,pack_current_position
from generic_chess.core.attacks import pseudo_attacks
from generic_chess.core.coordinates import index_to_square
from generic_chess.core.semantic_executor import semantic_engine_for
from rule_semantics_ir_fixtures import cannon_ruleset,en_passant_ruleset
B=Path('.local_agent/leaf-attack-scope-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
write_record(B/'declaration.json',dict(question='Does scalar Native attack equality with frozen legacy evaluator extend to four existing semantic-rule controls?',cases=['cannon','en_passant','western','shogi'],states='initial plus first repr-sorted legal play through ply3; at most16states',decision='Any legacy/semantic attack mismatch restricts new adapter to verified equivalent semantics; Native/semantic mismatch blocks its authority. No tuning/production change.',estimated_cost='seconds;64two-authority owner comparisons maximum; no search',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
rows=[]
for name,rules in [('cannon',cannon_ruleset()),('en_passant',en_passant_ruleset()),('western',build_builtin_ruleset('western_chess')),('shogi',build_builtin_ruleset('standard_shogi'))]:
 c=compile_ruleset_for_execution(rules);s=GameSession(c);n=compile_native_semantic_rules(c);authority=semantic_engine_for(c)
 for ply in range(4):
  pos=s.state.position;cap=pack_current_position(n,pos,ply_count=s.state.ply_count)
  legacy=tuple(pseudo_attacks(pos,o,c) for o in (0,1));semantic=tuple(frozenset(index_to_square(i,c.board_size) for i in authority.attacked_squares(pos,o)) for o in (0,1));native=tuple(frozenset(index_to_square(i,c.board_size) for i in attacked_squares(n,cap,o)) for o in (0,1));assert native==semantic
  rows.append(dict(case=name,ply=ply,legacy_equal=legacy==native,legacy=[sorted(a) for a in legacy],semantic=[sorted(a) for a in semantic],native=[sorted(a) for a in native],position=record_value(pos)))
  if s.result.is_terminal or ply==3:break
  s.submit(sorted(s.legal_actions(),key=repr)[0])
write_record(B/'result.json',dict(complete=True,rows=rows,native_semantic_mismatches=0,legacy_mismatches=sum(not r['legacy_equal'] for r in rows)));print([(r['case'],r['ply'],r['legacy_equal']) for r in rows])
