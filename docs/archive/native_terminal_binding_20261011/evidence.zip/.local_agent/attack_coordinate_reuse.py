"""Finite immutable coordinate reuse; unchanged attack indices and leaf formula."""
import ast,json,time,hashlib
from pathlib import Path
src=Path('.local_agent/raw_capsule_view_comparison.py').read_text(encoding='utf-8');exec(src.split("B=Path(")[0],globals())
B=Path('.local_agent/attack-coordinate-reuse-20261011');B.mkdir(exist_ok=True)
if (B/'declaration.json').exists():raise RuntimeError('frozen output exists')
d=dict(question='Can immutable compiled-board Square reuse remove the observed1Mcoordinate conversions without altering the current sameleaf attack adapter?',root='seed1008-ply8',depth=1,q=4,hardq=8,nodes=100000,seconds=90,orders=2,calls=4,expected_seconds='~under1min; under1h',decision='Exact maps and fullsearch work/action/score/trace required. If observed cost improves, retain this simple coordinate lookup for existing semantic attack evaluator review; do not replace legacy default attack authority.',scope='Only index->Square conversion changed; raw Position view, scalarC attacksets and frozenformula held. Square is immutable. Not allocation-free/full-domain search or strength claim.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(B/'declaration.json',d)
class CachedSquareEvaluator(NativeAttackEvaluator):
 def __init__(self,*a):super().__init__(*a);shape=self._compiled.board_shape;self.squares=tuple(index_to_square(i,shape) for i in range(shape.area))
 def _attack_maps(self,state):
  t=time.perf_counter();maps=tuple(frozenset(self.squares[i] for i in ns.attacked_squares(state.native_rules,state.native_capsule,o)) for o in (0,1));self.attack_queries+=2;self.attack_seconds+=time.perf_counter()-t;return maps
g=p.generate_game(p.GeneratorConfig(seed=1008,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);ec=p.EvaluationConfig();prof=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(8008)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
RuntimeChoice=RawRuntime;rt=RawRuntime(s.state,c,s._search_history_witnesses);saved=rt.full_snapshot();base=NativeAttackEvaluator(c,prof,ec);fast=CachedSquareEvaluator(c,prof,ec);checks=[]
for a in [None]+sorted(rt.legal_actions(),key=repr)[:16]:
 if a is not None:rt.push(a)
 try:
  assert base._attack_maps(rt.state)==fast._attack_maps(rt.state);v=base.evaluate(rt.state);assert v==fast.evaluate(rt.state);checks.append(dict(action=record_value(a),score=v))
 finally:
  if a is not None:rt.pop()
assert rt.full_snapshot()==saved;write_record(B/'checks.json',dict(complete=True,rows=checks,mismatches=0,squares=len(fast.squares)))
rows=[]
for order in range(2):
 for mode in (('converting','reusing') if order==0 else ('reusing','converting')):
  t=time.perf_counter();ev=NativeAttackEvaluator(c,prof,ec) if mode=='converting' else CachedSquareEvaluator(c,prof,ec);setup=time.perf_counter()-t;p.rr.stopped();t=time.perf_counter();v=search(c,s.state,s._search_history_witnesses,ev,True);wall=time.perf_counter()-t;rows.append(dict(order=order,coordinates=mode,caller_seconds=wall,coordinate_setup_seconds=setup,native_attack_queries=ev.attack_queries,native_attack_seconds=ev.attack_seconds,**v));write_record(B/'result.json',dict(complete=False,rows=rows));print(order,mode,v['reason'],v['score'],round(wall,4),flush=True)
 a,b=rows[-2:];assert all(a[k]==b[k] for k in ('reason','score','action','work','trace','position_views','transitions')) and a['reason']=='complete'
write_record(B/'result.json',dict(complete=True,rows=rows,pairs=2,matched=2))
