import ast,json
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011');prefix=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reuse>','exec'),E)
from generic_chess.ai.alphabeta import search as sm
from generic_chess.core.movegen import legal_actions
orig=sm._quiescence_runtime;G=dict(sm.__dict__);exec(compile((B/'failsoft-function.py').read_text(),'<q>','exec'),G);soft=G['_quiescence_runtime'];refs=json.loads((B/'mtd-result.json').read_text());out={'complete':False,'cells':[]}
try:
 for name in ['chess-ep','shogi-middle']:
  ref=next(x for x in refs['cells'] if x['root']==name);case=next(x for x in E['CASES'] if x['id']==name);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));board=E['CoreBoard'](case,c);e=E['w'].weighted(c,E['VALUES'][case['game']]);action=next(a for a in legal_actions(board.initial,c) if E['record_value'](a)==ref['decision']['action'])
  for kind,fn in [('original',orig),('private_failsoft',soft)]:
   E['stopped']();sm._quiescence_runtime=fn;rt=E['R'].from_state(board.initial,c,history_witnesses=board.witnesses);root=E['state'](rt);stats=E['SearchStatistics']();ctx=sm._Context(c,e,sm.TranspositionTable(),stats,sm._Budget(E['SearchLimits'](max_nodes=32768,max_time_seconds=30),None),E['SearchTuning'](),False,True,4,8,None,runtime=rt,first_main_iteration_complete=True)
   try:
    with rt.pushed(action,checkpoint=ctx.checkpoint):v=sm.negamax(rt.state,2,-sm.INF,sm.INF,1,ctx)
    score=-v.score;reason='complete';assert score==ref['decision']['score']
   except sm.SearchAborted as x:score=None;reason=str(x)
   rt.assert_balanced();assert E['state'](rt)==root
   out['cells'].append(dict(root=name,kind=kind,action=E['record_value'](action),child_negated_value=score,expected_root_value=ref['decision']['score'],reason=reason,stats=E['record_value'](stats),actual_root_restored=True));print(name,kind,score,reason,stats.nodes+stats.qnodes,flush=True)
 out['complete']=True;(B/'selected-child-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:sm._quiescence_runtime=orig
