import ast,json,time,sys
from pathlib import Path
B=Path(__file__).parent;O=Path(".local_agent/physical-publication-20261011")
prefix=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reusedprobe>', 'exec'),env)
sys.path[:0]=[str(Path.cwd()/'tests/product'),str(Path.cwd()/'.local_agent/availability-core-20261011')]
from semantic_profile_adapter import SearchSemanticCompiled
from test_f24c_mixed_mechanic_certification import _compiled
from test_f24c_mixed_mechanic_certification_r1 import _simultaneous,_state
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta import search as sm
import collections
original_q=sm._quiescence_runtime;original_nm=sm.negamax
G=dict(sm.__dict__);exec(compile((B/'failsoft-function.py').read_text(),'<private>','exec'),G);soft=G['_quiescence_runtime']
traces=[];qcounts=collections.Counter();sample=[];kind='original'
def nm(state,depth,alpha,beta,ply,ctx,**kwargs):
 before=ctx.stats.nodes+ctx.stats.qnodes
 z=original_nm(state,depth,alpha,beta,ply,ctx,**kwargs)
 if ply==0:traces.append(dict(depth=depth,alpha=alpha,beta=beta,score=z.score,work=ctx.stats.nodes+ctx.stats.qnodes-before,action=env['record_value'](z.best_action)))
 return z
def q(alpha,beta,ply,qdepth,ctx):
 fn=original_q if kind=='original' else soft
 z=fn(alpha,beta,ply,qdepth,ctx);category='upper' if z<=alpha else 'lower' if z>=beta else 'inside';qcounts[(qdepth,category,z==alpha)]+=1
 if z==alpha and len(sample)<16:sample.append(dict(alpha=alpha,beta=beta,score=z,ply=ply,qdepth=qdepth))
 return z
sm.negamax=nm;sm._quiescence_runtime=q;G['_quiescence_runtime']=q
original_aspiration=sm._aspiration_iteration
R=env['R'];pm=env['pm'];oldattach=R.attach_stats;oldfactory=pm.SearchStatistics;d=json.loads((B/'generic-declaration.json').read_text());out={'complete':False,'cells':[]}
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory']
 for spec in [x for x in d['cells'] if x['kind']=='generated']:
  src=_compiled() if spec['kind']=='mixed' else compile_legacy_ruleset_for_semantic_execution(generate_game(GeneratorConfig(seed=spec['seed'],board_size=spec['size'],setup_preset='bilateral_random',allow_hybrid=True)).ruleset)
  c=SearchSemanticCompiled(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
  if spec['kind']=='mixed':pos=_simultaneous(c);state=_state(c,pos)
  else:state=GameSession(c).state;pos=state.position
  cfg=EvaluationConfig();e=Evaluator(c,build_ruleset_profile(c,cfg),cfg);actions=legal_actions(state,c);cell={'spec':spec,'arms':[]};out['cells'].append(cell)
  for kind in ['original','private_failsoft']:
   tt=True;aspiration=True;traces=[];qcounts=collections.Counter();sample=[]
   env['stopped']();eligible=[]
   def observed_aspiration(state,depth,guess,ctx):
    eligible.append(dict(depth=depth,guess=guess,first_main_iteration_complete=ctx.first_main_iteration_complete));return original_aspiration(state,depth,guess,ctx)
   sm._aspiration_iteration=observed_aspiration
   env['runtimes']=[];env['captured']=[];session=env['SimpleNamespace'](compiled=c,state=state,_search_witnesses=(pos,));player=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=tt,tuning=env['SearchTuning'](use_aspiration=aspiration,aspiration_delta=50,aspiration_start_depth=3));v=player.choose_action(session,env['SearchLimits'](max_depth=3,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8));rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and session.state is state
   legal=v.action in actions if v.action is not None else bool(v.declaration or state.terminal_status.is_terminal);assert legal
   child=env['record_value'](apply_action(state,v.action,c)) if v.action is not None else None
   cell['arms'].append({'tt':tt,'aspiration':aspiration,'q_kind':kind,'root_trace':traces,'q_return_counts':[dict(qdepth=k[0],category=k[1],equals_alpha=k[2],count=v) for k,v in sorted(qcounts.items())],'alpha_echo_samples':sample,'decision':env['record_value'](v),'stats':env['record_value'](env['captured'][0]),'eligible_windows':eligible,'public_return_legal':True,'public_child':child,'restored_actual_multiset':True});print(spec,tt,aspiration,v.completed_depth,v.score,v.termination_reason,flush=True)
  cell['full_depth_comparisons']=[dict(tt=tt,bothD3=all(a['decision']['completed_depth']==3 for a in cell['arms'] if a['tt']==tt)) for tt in d['tt']]
  (B/'generic-retry-trace-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 out['complete']=True;(B/'generic-retry-trace-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
finally:sm._quiescence_runtime=original_q;sm.negamax=original_nm;sm._aspiration_iteration=original_aspiration;R.attach_stats=oldattach;pm.SearchStatistics=oldfactory