import ast,json
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011');prefix=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reuse>','exec'),E)
from generic_chess.ai.alphabeta import search as sm
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
orig=sm._quiescence_runtime;G=dict(sm.__dict__);exec(compile((B/'failsoft-function.py').read_text(),'<private q>','exec'),G);soft=G['_quiescence_runtime']
out={'complete':False,'cells':[]}
def save():(B/'qbound-result.json').write_text(json.dumps(out,indent=2)+'\n')
def call(c,st,witnesses,e,q,kind,a,b):
 E['stopped']();rt=E['R'].from_state(st,c,history_witnesses=witnesses);root=E['state'](rt);stats=E['SearchStatistics']();limits=E['SearchLimits'](max_nodes=8192,max_time_seconds=3);ctx=sm._Context(c,e,sm.TranspositionTable(),stats,sm._Budget(limits,None),E['SearchTuning'](),False,True,q,8,None,runtime=rt,first_main_iteration_complete=True)
 fn=orig if kind=='original' else soft;sm._quiescence_runtime=fn
 try:v=fn(a,b,0,0,ctx);r={'score':v,'reason':'complete'}
 except sm.SearchAborted as x:r={'score':None,'reason':str(x)}
 finally:sm._quiescence_runtime=orig
 rt.assert_balanced();assert E['state'](rt)==root
 r.update(stats=E['record_value'](stats),actual_root_restored=True,in_check=rt.in_check(st.position.side_to_move));return r
try:
 for name in ['chess-ep','shogi-middle','shogi-tactic']:
  case=next(x for x in E['CASES'] if x['id']==name);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));board=E['CoreBoard'](case,c);e=E['w'].weighted(c,E['VALUES'][case['game']]);states=[(name,board.initial,board.witnesses)]
  if name=='shogi-tactic':
   for a in legal_actions(board.initial,c):
    child=apply_action(board.initial,a,c);rt=E['R'].from_state(child,c,history_witnesses=tuple(board.witnesses)+(child.position,))
    if rt.in_check(child.position.side_to_move):states.append((name+'-first-check-child',child,tuple(board.witnesses)+(child.position,)));break
   assert len(states)==2
  for label,st,witnesses in states:
   for q in (0,1):
    cell={'root':label,'q':q,'arms':[]};out['cells'].append(cell);v=call(c,st,witnesses,e,q,'original',-sm.INF,sm.INF);cell['reference']=v
    if v['score'] is None:save();continue
    val=v['score'];windows=[(-sm.INF,sm.INF),(val+1,val+2),(val-2,val-1),(val-1,val+1),(val,val+1)]
    for a,b in windows:
     for kind in ['original','private_failsoft']:
      r=call(c,st,witnesses,e,q,kind,a,b);z=r['score'];valid=None if z is None else (val<=z if z<=a else val>=z if z>=b else val==z);cell['arms'].append(dict(kind=kind,alpha=a,beta=b,result=r,bound_valid=valid));assert valid is not False
    save();print(label,q,val,[(x['kind'],x['result']['score']) for x in cell['arms']],flush=True)
 out['complete']=True;save()
finally:sm._quiescence_runtime=orig
