import ast,json,sys
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011');prefix=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reuse>','exec'),E)
sys.path.insert(0,str(Path.cwd()/'tests/product'))
from test_generic_declaration_semantics import _claim_ruleset,_claim_position,_state
from test_qsearch_correctness import _king_rook_6,_check_chain_state,_evaluator
from dataclasses import replace
from generic_chess import Piece
from generic_chess.ai.alphabeta import search as sm
orig=sm._quiescence_runtime;G=dict(sm.__dict__);exec(compile((B/'failsoft-function.py').read_text(),'<private>','exec'),G);soft=G['_quiescence_runtime'];oldcp=sm._Context.checkpoint
c=E['compile_ruleset_for_execution'](_claim_ruleset());st=_state(c,_claim_position(c,score_state='restart'));board=list(st.position.board);board[8]=Piece(1,'R','R');checked=_state(c,replace(st.position,board=tuple(board)))
e0=_evaluator(c)
class Negative:
 def __getattr__(self,n):return getattr(e0,n)
 def evaluate(self,state):return -100
chainc=_king_rook_6();chain=_check_chain_state(chainc);chaine=_evaluator(chainc)
rows=[]
try:
 for mode in ['restart_q0','restart_checked','check_chain_hard1','check_chain_qnode2','cancel_first_actual_child']:
  co,pos,e=(c,st,Negative()) if mode=='restart_q0' else (c,checked,Negative()) if mode=='restart_checked' else (chainc,chain,chaine)
  for kind,fn in [('original',orig),('private_failsoft',soft)]:
   E['stopped']();rt=E['R'].from_state(pos,co,history_witnesses=(pos.position,));root=E['state'](rt);stats=E['SearchStatistics']();ctx=sm._Context(co,e,sm.TranspositionTable(),stats,sm._Budget(E['SearchLimits'](max_nodes=8192,max_time_seconds=3),None),E['SearchTuning'](),False,True,0,1 if mode=='check_chain_hard1' else 8,2 if mode=='check_chain_qnode2' else None,runtime=rt,first_main_iteration_complete=True);hits=[]
   def cp(context):
    oldcp(context)
    if mode=='cancel_first_actual_child' and context.runtime.depth>0:
     hits.append(context.runtime.depth);raise sm.SearchAborted('cancelled')
   sm._Context.checkpoint=cp;sm._quiescence_runtime=fn
   try:score=fn(-sm.INF,sm.INF,0,0,ctx);reason='complete'
   except sm.SearchAborted as x:score=None;reason=str(x)
   finally:sm._Context.checkpoint=oldcp;sm._quiescence_runtime=orig
   rt.assert_balanced();assert E['state'](rt)==root
   rows.append(dict(mode=mode,kind=kind,score=score,reason=reason,cancellation_depths=hits,in_check=rt.in_check(pos.position.side_to_move),stats=E['record_value'](stats),actual_root_restored=True));print(mode,kind,score,reason,hits,flush=True)
 for i in range(0,len(rows),2):assert (rows[i]['score'],rows[i]['reason'])==(rows[i+1]['score'],rows[i+1]['reason'])
 assert rows[0]['score']==0
 assert all(x['reason']=='cancelled' and x['cancellation_depths']==[1] for x in rows if x['mode']=='cancel_first_actual_child')
 (B/'q-lifecycle-result.json').write_text(json.dumps({'complete':True,'cells':rows},indent=2)+'\n')
finally:sm._Context.checkpoint=oldcp;sm._quiescence_runtime=orig
