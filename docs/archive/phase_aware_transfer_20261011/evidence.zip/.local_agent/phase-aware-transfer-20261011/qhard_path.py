import ast,json,time,sys
from pathlib import Path
B=Path(__file__).parent;O=Path(".local_agent/physical-publication-20261011")
prefix=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reusedprobe>', 'exec'),env)
sys.path[:0]=[str(Path.cwd()/'tests/product'),str(Path.cwd()/'.local_agent/availability-core-20261011')]
from semantic_profile_adapter import SearchSemanticCompiled
from test_f24c_mixed_mechanic_certification import _compiled
from test_f24c_mixed_mechanic_certification_r1 import _simultaneous,_state
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta import search as sm

from contextlib import contextmanager
R=env['R'];pm=env['pm'];oldattach=R.attach_stats;oldfactory=pm.SearchStatistics
oldpush=R.pushed;oldq=sm._quiescence_runtime
stack=[];events=[];out={'complete':False,'arms':[]}
@contextmanager
def tracked(rt,action,checkpoint=None):
 with oldpush(rt,action,checkpoint=checkpoint) as view:
  stack.append(action)
  try:yield view
  finally:stack.pop()
def observed(alpha,beta,ply,qdepth,ctx):
 try:return oldq(alpha,beta,ply,qdepth,ctx)
 except sm.SearchAborted as ex:
  if str(ex)=='qsearch_check_hard_limit' and not events:
   rt=ctx.runtime
   events.append({'actions':tuple(stack),'position':rt.position,'ply_count':rt.ply_count,'history':tuple(rt.history),'terminal':rt.terminal_status,'qdepth':qdepth,'search_ply':ply,'alpha':alpha,'beta':beta,'in_check':rt.in_check(rt.position.side_to_move)})
  raise
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory'];R.pushed=tracked;sm._quiescence_runtime=observed
 src=compile_legacy_ruleset_for_semantic_execution(generate_game(GeneratorConfig(seed=15,board_size=8,setup_preset='bilateral_random',allow_hybrid=True)).ruleset)
 c=SearchSemanticCompiled(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);state=GameSession(c).state
 cfg=EvaluationConfig();e=Evaluator(c,build_ruleset_profile(c,cfg),cfg)
 prior=json.loads((B/'qorder-generic-result.json').read_text())['cells'][1]['arms']
 for ordered in (False,True):
  env['stopped']();stack.clear();events.clear();env['runtimes']=[];env['captured']=[]
  player=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=True,tuning=env['SearchTuning'](use_ordered_qsearch=ordered))
  session=env['SimpleNamespace'](compiled=c,state=state,_search_witnesses=(state.position,))
  v=player.choose_action(session,env['SearchLimits'](max_depth=3,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
  rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and not stack
  dv=env['record_value'](v);ref=next(a for a in prior if a['tt'] and a['ordered_q']==ordered)['decision']
  for key in ('nodes','qnodes','score','completed_depth','action','termination_reason'):assert dv[key]==ref[key],key
  replay=[]
  for ev in events:
   cur=state
   for a in ev['actions']:
    assert a in legal_actions(cur,c)
    cur=apply_action(cur,a,c)
   assert cur.position==ev['position'] and cur.ply_count==ev['ply_count'] and cur.terminal_status==ev['terminal']
   replay.append({'path':env['record_value'](ev['actions']),'final_position':env['record_value'](cur.position),'public_history':env['record_value'](cur.history),'runtime_history':env['record_value'](ev['history']),'qdepth':ev['qdepth'],'search_ply':ev['search_ply'],'alpha':ev['alpha'],'beta':ev['beta'],'in_check':ev['in_check'],'public_legal_path':True,'position_ply_terminal_match':True})
  out['arms'].append({'ordered_q':ordered,'decision':dv,'stats':env['record_value'](env['captured'][0]),'exact_prior_nonclock_decision':True,'actual_root_restored':True,'abort_replay':replay})
  print(ordered,v.completed_depth,v.score,v.termination_reason,'path_lengths',[len(e['actions']) for e in events],flush=True)
 out['complete']=True;(B/'qhard-path-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:R.attach_stats=oldattach;pm.SearchStatistics=oldfactory;R.pushed=oldpush;sm._quiescence_runtime=oldq
