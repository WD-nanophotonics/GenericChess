import sys,json,collections
from pathlib import Path
B=Path(__file__).parent;sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product')]
from test_qsearch_semantic_effects import transform_rules,noop_target_rules
from generic_chess import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import legal_successors
from generic_chess.core.actions import action_is_board,action_target_square,action_promotion_target_id
from generic_chess.ai.alphabeta.ordering import MoveOrderer
from generic_chess.ai.alphabeta.quiescence import classify_noisy,enemy_board_count,material_inventory
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from scripts.research_record import record_value
from scripts.reserve_refresh_diagnostic import stopped
out={'complete':False,'cells':[]}
for label,rules in [('transform_effect',transform_rules(encoding='effect')),('transform_explicit',transform_rules(encoding='explicit')),('nochange',transform_rules('nochange')),('balanced',transform_rules('balanced')),('noop_targets',noop_target_rules())]:
 stopped();c=compile_ruleset_for_execution(rules);game=GameSession(c);state=game.state;pairs=legal_successors(state,c);cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);e=Evaluator(c,build_ruleset_profile(c,cfg),cfg);ordered=MoveOrderer().order(state,[a for a,ch in pairs],e,-1,None,None,SearchTuning());lex=sorted([a for a,ch in pairs],key=str);noisy=classify_noisy(state,pairs,c);rows=[]
 for a,ch in pairs:
  target=action_target_square(a) if action_is_board(a) else None;occupant=state.position.board[target.rank*state.position.board_shape.width+target.file] if target is not None else None
  rows.append(dict(action=record_value(a),lexical_rank=lex.index(a),ordered_rank=ordered.index(a),metadata_enemy_target=occupant is not None and occupant.owner!=state.position.side_to_move,promotion_metadata=action_promotion_target_id(a),actual_enemy_removed=enemy_board_count(ch.position,state.position.side_to_move)<enemy_board_count(state.position,state.position.side_to_move),inventory_changed=material_inventory(ch.position)!=material_inventory(state.position),actual_noisy=a in noisy,child_position=record_value(ch.position)))
 assert game.state is state
 out['cells'].append(dict(fixture=label,rows=rows,public_parent_unchanged=True));print(label,len(rows),[(x['ordered_rank'],x['metadata_enemy_target'],x['promotion_metadata'],x['actual_noisy']) for x in rows if getattr(pairs[rows.index(x)][0],'pattern_id','').startswith('sem_')],flush=True)
out['complete']=True;(B/'q-rank-scope-result.json').write_text(json.dumps(out,indent=2)+'\n')
