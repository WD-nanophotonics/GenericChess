def _quiescence_runtime(alpha, beta, ply, qdepth, ctx: _Context) -> int:
    runtime = ctx.runtime
    ctx.stats.qnodes += 1
    ctx.budget.check(ctx.stats)
    state = runtime.state
    terminal = runtime.terminal_status
    if terminal.is_terminal:
        return terminal_score(terminal, state.position.side_to_move, ply)
    declarations = _declaration_options(state, ctx.compiled, ctx.stats)
    winning = next((a for a in declarations if a.outcome == "WIN"), None)
    restart = next((a for a in declarations if a.outcome == "RESTART"), None)
    if winning is not None:
        return MATE_SCORE - ply
    if restart is not None:
        alpha = max(alpha, 0)
    best = 0 if restart is not None else -INF
    side = state.position.side_to_move
    in_check = runtime.in_check(side, checkpoint=ctx.checkpoint)
    if in_check:
        actions = _runtime_legal_actions(ctx, ctx.checkpoint)
        ctx.budget.check(ctx.stats, force=True)
        ctx.stats.in_check_qnodes += 1
        if qdepth >= ctx.qhard_depth_limit:
            ctx.stats.qsearch_check_hard_limit_aborts += 1
            raise SearchAborted("qsearch_check_hard_limit")
        if ctx.qnode_limit is not None and ctx.stats.qnodes >= ctx.qnode_limit:
            ctx.stats.qsearch_budget_aborts += 1
            raise SearchAborted("qsearch_budget")
        if not actions:
            raise SearchAborted("qsearch_check_no_evasions")
        for action in _order_qactions(state, actions, ply, ctx):
            with runtime.pushed(action, checkpoint=ctx.checkpoint):
                score = -_quiescence_runtime(-beta, -alpha, ply + 1, qdepth + 1, ctx)
            best = max(best, score)
            if score >= beta:
                return score
            if score > alpha:
                alpha = score
        return best

    stand_pat = _evaluate(state, ctx.evaluator, ctx)
    best = max(best, stand_pat)
    ctx.budget.check(ctx.stats, force=True)
    if stand_pat >= beta:
        ctx.stats.stand_pat_cutoffs += 1
        return max(stand_pat, 0) if restart is not None else stand_pat
    if stand_pat > alpha:
        alpha = stand_pat
    if qdepth >= _ordinary_qdepth_limit(ctx):
        ctx.stats.qdepth_cutoffs += 1
        return best
    if ctx.qnode_limit is not None and ctx.stats.qnodes >= ctx.qnode_limit:
        ctx.stats.qsearch_budget_aborts += 1
        raise SearchAborted("qsearch_budget")
    # Terminal status is already authoritative. Noncheck stand-pat/depth
    # exits need no legal list; keep full evasion generation above.
    actions = _runtime_legal_actions(ctx, ctx.checkpoint)
    ctx.budget.check(ctx.stats, force=True)
    # Classify on demand in the chosen order; reuse the child for recursion.
    # The default stays lexical. A cutoff need not classify unvisited actions.
    ordered = _order_qactions(state, actions, ply, ctx)
    semantic = semantic_engine_for(ctx.compiled) is not None
    parent_enemies = enemy_board_count(state.position, side)
    parent_inventory = material_inventory(state.position) if semantic else None
    for action in ordered:
        kind = (
            legacy_noisy_kind(state.position, action)
            if not semantic else None
        )
        with runtime.pushed(action, checkpoint=ctx.checkpoint):
            if not noisy_child(
                    action, runtime.state, side, parent_enemies, parent_inventory,
                    lambda: runtime.in_check(1 - side, checkpoint=ctx.checkpoint),
                    ctx.stats, capture_only=ctx.tuning.use_capture_only_qsearch,
                    legacy_kind=kind):
                continue
            score = -_quiescence_runtime(-beta, -alpha, ply + 1, qdepth + 1, ctx)
        best = max(best, score)
        if score >= beta:
            return score
        if score > alpha:
            alpha = score
    return best
