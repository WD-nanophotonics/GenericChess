import ast,json,time,datetime
from pathlib import Path
B=Path(__file__).parent;O=Path(".local_agent/physical-publication-20261011")
prefix=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reused definitions>', 'exec'),env)
d=json.loads((B/'qorder-time-declaration.json').read_text());ack=json.loads((B/'qorder-resource-private.json').read_text());UTC=datetime.timezone.utc;begin=datetime.datetime.fromisoformat(ack['begin']);end=datetime.datetime.fromisoformat(ack['end']);now=lambda:datetime.datetime.now(UTC)
assert ack['confirmed_explicitly'] and begin<=now()<end
R=env['R'];pm=env['pm'];oldattach=R.attach_stats;oldfactory=pm.SearchStatistics;out={'complete':False,'started_at':now().isoformat(),'resource_ack_scope':'DEV_AUX source-only, not whole-machineatomiclock','cells':[]}
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory']
 for name in d['roots']:
  case=next(x for x in env['CASES'] if x['id']==name);c=env['compile_ruleset_for_execution'](env['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));board=env['CoreBoard'](case,c);e=env['w'].weighted(c,env['VALUES'][case['game']])
  for tt in d['tt']:
   for seconds in d['budgets_seconds']:
    for order in d['orders']:
     cell={'root':name,'tt':tt,'seconds':seconds,'order':order,'arms':[]};out['cells'].append(cell)
     for ordered_q in order:
      env['stopped']();assert begin<=now() and now()+datetime.timedelta(seconds=seconds+10)<end
      env['runtimes']=[];env['captured']=[];session=env['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses);t=time.perf_counter();player=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=tt,tuning=env['SearchTuning'](use_ordered_qsearch=ordered_q));prep=time.perf_counter()-t;t=time.perf_counter();v=player.choose_action(session,env['SearchLimits'](max_depth=4,max_nodes=32768,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
      rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and session.state is board.initial;assert now()<end
      cell['arms'].append({'ordered_q':ordered_q,'decision':env['record_value'](v),'stats':env['record_value'](env['captured'][0]),'preparation_seconds':prep,'observed_choose_wall':wall,'restored_actual_multiset':True});print(name,tt,seconds,ordered_q,v.completed_depth,v.score,v.termination_reason,flush=True)
     (B/'qorder-time-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 out['complete']=True;out['ended_at']=now().isoformat();out['duration_seconds']=(datetime.datetime.fromisoformat(out['ended_at'])-datetime.datetime.fromisoformat(out['started_at'])).total_seconds();(B/'qorder-time-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
finally:R.attach_stats=oldattach;pm.SearchStatistics=oldfactory