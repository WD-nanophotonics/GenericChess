import ast,json
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011');nodes=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 nodes.append(n)
E={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<reused caller>','exec'),E)
from generic_chess.ai.alphabeta import search as sm
from generic_chess.core.movegen import legal_actions
old=sm._aspiration_iteration;R=E['R'];pm=E['pm'];oa=R.attach_stats;of=pm.SearchStatistics;d=json.loads((B/'mtd-declaration.json').read_text());out={'complete':False,'cells':[]}
def save():(B/'mtd-result.json').write_text(json.dumps(out,indent=2)+'\n')
try:
 R.attach_stats=E['attach'];pm.SearchStatistics=E['factory']
 for name in d['roots']:
  case=next(x for x in E['CASES'] if x['id']==name);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));board=E['CoreBoard'](case,c);e=E['w'].weighted(c,E['VALUES'][case['game']]);actions=legal_actions(board.initial,c)
  for mode in d['variants']:
   E['stopped']();E['runtimes']=[];E['captured']=[];cell={'root':name,'mode':mode,'passes':[]};out['cells'].append(cell)
   def driver(state,depth,guess,ctx):
    lo,hi=-sm.INF,sm.INF;g=guess
    for i in range(64):
     pivot=g+1 if g==lo else g;before=ctx.stats.nodes+ctx.stats.qnodes;v=sm.negamax(state,depth,pivot-1,pivot,0,ctx);g=v.score
     if g<pivot:hi=min(hi,g)
     else:lo=max(lo,g)
     cell['passes'].append(dict(index=i,beta=pivot,returned_score=g,lower=lo,upper=hi,work=ctx.stats.nodes+ctx.stats.qnodes-before,best_action=E['record_value'](v.best_action),runtime_depth=ctx.runtime.depth));save()
     if lo>hi:raise sm.SearchAborted('mtd_inconsistent_bounds')
     if lo==hi:
      cell['converged']=g
      if mode=='converged_then_fullwindow':
       before=ctx.stats.nodes+ctx.stats.qnodes;z=sm.negamax(state,depth,-sm.INF,sm.INF,0,ctx);cell['recovery']=dict(score=z.score,work=ctx.stats.nodes+ctx.stats.qnodes-before,action=E['record_value'](z.best_action),equals_interval=z.score==g);return z
      return v
    raise sm.SearchAborted('mtd_pass_limit')
   sm._aspiration_iteration=driver;session=E['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses);p=E['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=True,tuning=E['SearchTuning'](use_aspiration=True,aspiration_start_depth=3));v=p.choose_action(session,E['SearchLimits'](max_depth=3,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8));rt,root=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==root and session.state is board.initial;assert v.action in actions
   cell.update(decision=E['record_value'](v),stats=E['record_value'](E['captured'][0]),public_action_legal=True,actual_root_restored=True);save();print(name,mode,v.completed_depth,v.score,v.nodes+v.qnodes,len(cell['passes']),v.termination_reason,flush=True)
 out['complete']=True;save()
finally:sm._aspiration_iteration=old;R.attach_stats=oa;pm.SearchStatistics=of
