import ast,json
from pathlib import Path
B=Path(__file__).parent;nodes=[]
for n in ast.parse((B/'units.py').read_text()).body:
 if isinstance(n,ast.Try):break
 nodes.append(n)
env={'__file__':str(B/'units.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<reused units definitions>','exec'),env)
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.cancellation import CancellationToken
E=env['env'];R=E['R'];pm=E['pm'];old=sm.negamax;oa=R.attach_stats;of=pm.SearchStatistics;out={'complete':False,'cells':[]}
try:
 R.attach_stats=E['attach'];pm.SearchStatistics=E['factory']
 for name in ('chess-ep','shogi-middle'):
  case=next(x for x in E['CASES'] if x['id']==name);c=E['compile_ruleset_for_execution'](E['build_builtin_ruleset']('western_chess' if case['game']=='chess' else 'standard_shogi'));board=E['CoreBoard'](case,c);e=env['Scaled'](E['w'].weighted(c,E['VALUES'][case['game']]));E['stopped']();E['runtimes']=[];E['captured']=[];hits=[];complete2=[];bounds=[];token=CancellationToken()
  def wrapped(state,depth,alpha,beta,ply,ctx,*args,**kw):
   if ctx.stats.completed_depth==2 and ply==1 and ctx.stats.aspiration_researches>=1 and not hits:
    hits.append(dict(depth=depth,ply=ply,runtime_depth=ctx.runtime.depth,researches=ctx.stats.aspiration_researches,alpha=alpha,beta=beta));token.cancel()
   v=old(state,depth,alpha,beta,ply,ctx,*args,**kw)
   if ply==0 and depth==2:complete2.append(E['record_value'](v))
   if ply==0 and depth==3:bounds.append(dict(alpha=alpha,beta=beta,result=E['record_value'](v)))
   return v
  sm.negamax=wrapped;session=E['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses);p=E['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=False,tuning=E['SearchTuning'](use_aspiration=True,aspiration_start_depth=3,aspiration_delta=50));v=p.choose_action(session,E['SearchLimits'](max_depth=3,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token);rt,root=E['runtimes'][0];rt.assert_balanced();assert E['state'](rt)==root and session.state is board.initial
  assert len(hits)==len(complete2)==len(bounds)==1;assert bounds[0]['result']['score']>=bounds[0]['beta'];assert v.completed_depth==2 and v.termination_reason=='cancelled' and v.score==complete2[0]['score'];assert E['record_value'](v.action)==complete2[0]['best_action']
  out['cells'].append(dict(root=name,hits=hits,independentD2=complete2,failedD3bound=bounds,decision=E['record_value'](v),stats=E['record_value'](E['captured'][0]),actual_root_restored=True));print(name,'retry cancellation D2',v.score,hits,flush=True)
 out['complete']=True;(B/'retry-cancel-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:sm.negamax=old;R.attach_stats=oa;pm.SearchStatistics=of
