import ast,json,sys,collections
from pathlib import Path
B=Path(__file__).parent;O=Path('.local_agent/physical-publication-20261011');prefix=[]
for n in ast.parse((O/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(O/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reuseddefs>', 'exec'),env)
from generic_chess.ai.alphabeta.transposition import TranspositionTable,TTEntry
class ProbeTable(TranspositionTable):
 def __init__(self,mask):super().__init__();self.mask=mask;self.rows=collections.Counter()
 def probe(self,key):
  entry=super().probe(key);f=sys._getframe(1);depth=f.f_locals.get('depth');ctx=f.f_locals.get('ctx');phase=ctx.stats.completed_depth+1 if ctx is not None else -1
  if entry is not None:
   sufficient=(f.f_code.co_name=='negamax' and depth is not None and entry.depth>=depth);self.rows[(phase,entry.bound.name,sufficient)]+=1
   if self.mask:return TTEntry(entry.key,-1,entry.score,entry.bound,entry.best_action,entry.generation)
  return entry
R=env['R'];pm=env['pm'];oldattach=R.attach_stats;oldfactory=pm.SearchStatistics;c=env['compile_ruleset_for_execution'](env['build_builtin_ruleset']('standard_shogi'));board=env['CoreBoard'](next(x for x in env['CASES'] if x['id']=='shogi-middle'),c);e=env['w'].weighted(c,env['VALUES']['shogi']);out={'complete':False,'cells':[]}
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory']
 for aspiration in (False,True):
  for mask in (True,):
   env['stopped']();env['runtimes']=[];env['captured']=[];session=env['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses);player=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,tuning=env['SearchTuning'](use_aspiration=aspiration,aspiration_start_depth=3,aspiration_delta=50));table=ProbeTable(mask);player._tt=table;v=player.choose_action(session,env['SearchLimits'](max_depth=3,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8));rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and session.state is board.initial
   out['cells'].append({'aspiration':aspiration,'mask_bound_depth':mask,'decision':env['record_value'](v),'stats':env['record_value'](env['captured'][0]),'probe_rows':[{'iteration':k[0],'bound':k[1],'original_sufficient_depth':k[2],'count':n} for k,n in sorted(table.rows.items())],'actual_root_restored':True});print(aspiration,mask,v.completed_depth,v.score,v.nodes+v.qnodes,'probe',dict(table.rows),flush=True);(B/'tt-order-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 out['complete']=True;(B/'tt-order-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
finally:R.attach_stats=oldattach;pm.SearchStatistics=oldfactory