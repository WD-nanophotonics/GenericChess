import sys,json,time,sysconfig,importlib.util
from pathlib import Path
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));sys.path.insert(0,str(R/'tests/product'))
import generic_chess.native as native
from scripts.research_record import record_value,write_record
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from test_f58_compact_nonlinear import _native_constant_compact_model
out=R/'.local_agent/ordering-status-view-20261012/profile-controls';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(calls=12,profiles=['dynamic_order','spatial_order','localized_order','compact_order','cached_static_order','compact_leaf_static_order'],depth=2,orders=1,arms=['full','view'],seconds=8,max_nodes=1000000,scope='Predeclared6actualprofileguards pluscomplexleaf/staticorderconsumer; existingChesssemantic fullrules/history/session, no profile fitting/training. Nonzeroorderfeatures/model andcacheOnmustfallback withviewcalls0, compactleaf/staticorder mayuseview butleaf/fullhistories retained. Fulltuple/nodework andactualguard counters, parentimmutability. Max192seconds, expectedunder30seconds.'))
c=compile_semantic_ruleset(build_western_chess_ruleset());s=GameSession(c);profile=build_ruleset_profile(compile_ruleset_for_execution(build_western_chess_ruleset()),EvaluationConfig());parent=LearnableMaterialCheckpoint.from_profile(c,profile,dynamic_weights={})
model=_native_constant_compact_model(c,s);compact=replace(parent,compact_nonlinear=model)
types=tuple(sorted(c.support.type_metadata))
spatial={f'{owner}:{t}':(0.,0.,0.,0.,1.,0.,0.,0.,-1.) for owner in (0,1) for t in types}
cases=[('dynamic_order',parent,replace(parent,dynamic_weights={'mobility':1.}),False,False),('spatial_order',parent,replace(parent,spatial_occupancy_weights=spatial),False,False),('localized_order',parent,replace(parent,localized_control_weights=(1.,0.,0.,0.,0.,0.,0.,0.,-1.)),False,False),('compact_order',parent,compact,False,False),('cached_static_order',parent,parent,True,False),('compact_leaf_static_order',compact,parent,False,True)]
modules={}
for arm in ['full','view']:
 p=(R/'.local_agent/ordering-status-20261012/clean' if arm=='full' else R/'.local_agent/ordering-status-view-20261012/view')/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('guard_'+arm+'._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
rows=[];before=record_value(s.state);witness=s._search_witnesses
for name,leaf,orderprof,cached,eligible in cases:
 for order,arms in enumerate([['full','view']]):
  results=[]
  for arm in arms:
   native._MODULE=modules[arm];p=NativeSemanticLegalityProvider.try_create(c,strict=True);e=SemanticSearchEngine(c,p.native_rules,checkpoint=leaf,ordering_checkpoint=orderprof,ordering_cache_enabled=cached,ordering_min_depth=1,tt_megabytes=1);raw=[];old=modules[arm].semantic_engine_search
   def counted(*a):
    x=old(*a);raw.append(dict(x));return x
   modules[arm].semantic_engine_search=counted
   t=time.perf_counter()
   try:r=e.search(s,SearchLimits(max_depth=2,max_nodes=1000000,max_time_seconds=8,quiescence_max_depth=0),root_window_pruning=True)
   finally:modules[arm].semantic_engine_search=old
   assert r.completed_depth==2 and r.termination_reason=='completed' and record_value(s.state)==before and s._search_witnesses is witness
   if arm=='view':assert (raw[0]['ordering_material_view_trials']>0)==eligible,(name,raw[0]['ordering_material_view_trials'])
   rows.append(dict(case=name,arm=arm,order=order,eligible=eligible,cache=cached,result=record_value(r),raw=raw[0],seconds=time.perf_counter()-t))
   results.append(r)
  assert all(getattr(results[0],k)==getattr(results[1],k) for k in ['score','action','principal_variation','completed_depth','nodes'])
write_record(out/'result.json',dict(complete=True,rows=rows));write_record(out/'verification.json',dict(calls=len(rows),fulltuple_work_pairs=6,actual_guard_fallback_cells=5,complex_leaf_static_order_view_cells=1,fullhistory_parent_unchanged=True,training=False))
print('12actualprofile/fallback controls complete')
