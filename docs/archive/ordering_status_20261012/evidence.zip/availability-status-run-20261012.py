
from pathlib import Path
import sys,sysconfig,importlib.util,json
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));sys.path.insert(0,str(R/'tests'))
from scripts.research_record import write_record,record_value
import generic_chess.native as native
from phase19b3_s4_fixtures import multiple_replies_ruleset,multiple_replies_position
from generic_chess import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.movement import LeapAtom
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.limits import SearchLimits
out=R/'.local_agent/availability-status-20261012';arm=sys.argv[1]
p=out/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('availability'+arm+'._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m
rules=multiple_replies_ruleset();tmp=compile_ruleset_for_execution(rules);pos=multiple_replies_position(tmp.support)
board=list(pos.board)
for i,piece in enumerate(board):
 if piece and piece.current_type_id=='B':board[i]=None
board[3*5+3]=Piece(1,'B','B')
types=tuple(replace(pt,movement_atoms=(LeapAtom((9,9)),)) if pt.is_anchor else pt for pt in rules.piece_types)
rules=replace(rules,piece_types=types,initial_position=tuple(tuple(board[r*5:(r+1)*5]) for r in range(5)))
c=compile_ruleset_for_execution(rules);s=GameSession(c);played=[]
for tid in ['A','B']:
 a=next(a for a in s.legal_actions() if a.actor_type_id==tid);played.append(record_value(a));s.submit(a)
assert s.state.ply_count==2 and len(s.state.history)==len(s._search_witnesses)==3 and s.legal_actions()
before=s.state;witnesses=s._search_witnesses
nr=NativeSemanticLegalityProvider.try_create(c,strict=True).native_rules
ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
def engine():return SemanticSearchEngine(c,nr,board_values={'K':0,'A':11,'B':12},hand_values={'K':0,'A':11,'B':12},dynamic_values=(0,0,0),ordering_checkpoint=ordering,ordering_min_depth=2,ordering_cache_enabled=True,tt_megabytes=1)
def search(e,depth):return e.search(s,SearchLimits(max_depth=depth,max_nodes=100000,max_time_seconds=8,quiescence_max_depth=0),root_window_pruning=True)
m.test_availability_fault(2,999999);r1=search(engine(),1);roots_d1,_=m.test_availability_count();assert roots_d1>0
e=engine();m.test_availability_fault(2,roots_d1+1);r=search(e,3);counts=m.test_availability_count();assert counts[1]>0,counts
result=dict(complete=True,calls=2,baseline=record_value(r1),failure=record_value(r),counts=counts,fault_after=roots_d1+1,rules=record_value(rules),state=record_value(s.state),witnesses=record_value(s._search_witnesses),played_actions=played,scope='Actualplayedprefix3; twoactuallegalA/Bmoves; immobileanchorvariant. OnlyD2rootavailability nestedfault, noordering/recursivefault. Initialfixturefieldtypofixedbeforequery.')
if arm=='before':assert r.termination_reason=='completed' and r.action is None
else:
 assert r.termination_reason=='internal_error' and r.completed_depth==1
 assert all(getattr(r,k)==getattr(r1,k) for k in ['action','score','principal_variation'])
 m.test_availability_fault(2,999999);retry=search(e,3);cold=search(engine(),3)
 assert all(getattr(retry,k)==getattr(cold,k) for k in ['action','score','principal_variation','completed_depth'])
 result.update(calls=4,retry=record_value(retry),cold=record_value(cold))
assert s.state is before and s._search_witnesses is witnesses
write_record(out/(arm+'-result.json'),result)
print(arm,'baselineD1rootchecks',roots_d1,'fault',r.completed_depth,r.termination_reason,r.action,'counts',counts)
