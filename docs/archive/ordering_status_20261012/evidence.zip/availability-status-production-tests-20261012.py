
from pathlib import Path
import sys,subprocess,time,json,xml.etree.ElementTree as ET
R=Path.cwd();sys.path.insert(0,str(R))
from scripts.research_record import write_record
out=R/'.local_agent/availability-status-20261012'
args=[sys.executable,'-m','pytest','-q','-p','no:cacheprovider','--basetemp=.local_agent/pytest-availability-status-production-20261012','--junitxml=.local_agent/availability-status-20261012/production-tests-private.xml']
t=time.perf_counter()
try:
 p=subprocess.run(args,capture_output=True,text=True,timeout=1200)
 (out/'production-test-output-private.txt').write_text(p.stdout+p.stderr,encoding='utf-8')
 counts={}
 if (out/'production-tests-private.xml').exists():
  for suite in ET.parse(out/'production-tests-private.xml').getroot().iter('testsuite'):
   for k in ['tests','failures','errors','skipped']:counts[k]=counts.get(k,0)+int(suite.attrib.get(k,0))
 write_record(out/'production-active-tests.json',dict(exit_code=p.returncode,seconds=time.perf_counter()-t,counts=counts,fuse_seconds=1200,scope='Fullfouractive layers withinstalled cleanstatusNative; faultregression privatebuild optionalWindowsZig. No totalmachineexclusivity, nofaultknob inproduct.'))
 print(p.stdout[-1400:],p.stderr[-500:]);sys.exit(p.returncode)
except subprocess.TimeoutExpired as e:
 write_record(out/'production-active-tests.json',dict(timed_out=True,seconds=time.perf_counter()-t,fuse_seconds=1200,scope='Remainingtests unknown, no rerun extension.'))
 raise
