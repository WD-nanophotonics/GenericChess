"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning

from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
import hashlib,random
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)


base=ROOT/'.local_agent/ordering-status-20261012';out=base/'search-fault';out.mkdir(exist_ok=True);assert not(out/'result.json').exists()
roots=['generated1091-turn2','Shogi0']
p=base/'search_fault'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('statussearch._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m
samples=[]
for x in json.loads((ROOT/'.local_agent/q0-trace-rebuild-20261012/input-closure.json').read_bytes()):
 if (x['root'],x['turn']) not in [('generated1091',2),('shogi-middle',0)]:continue
 x=dict(x);x['root']='generated1091-turn2' if x['root']=='generated1091' else 'Shogi0';x['source_mode']='execution';samples.append(x)
for x in json.loads((ROOT/'.local_agent/q0-refine-generated-20261012/samples.json').read_bytes()):
 if x['root'] not in roots:continue
 x=dict(x);x['source_mode']='metadata';samples.append(x)
samples=[x for x in samples if x['root'] in roots]
assert {x['root'] for x in samples}==set(roots);write_record(out/'input-closure.json',samples)
rows=[]
for sample in samples:
 if sample['source_mode']=='execution':
  c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi')) if sample['rules']=='builtin:standard_shogi' else compile_ruleset_for_execution(ruleset_from_dict(json.loads(sample['rules'])))
 else:
  src=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(sample['rules']));c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 d=sample['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));w=tuple(position(x) for x in sample['witnesses']);session=SimpleNamespace(compiled=c,state=state,_search_witnesses=w,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')))
 bv,hv=sample['board'],sample['hand'];ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
 provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
 def engine():return SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2,ordering_cache_enabled=False)
 e=engine();before=record_value(state)
 for fault,kind,selected in [(1,'outer_failure',e),(0,'same_TT_retry',e),(0,'cold',engine())]:
  m.research_set_order_fault(fault);t=time.perf_counter()
  try:r=selected.search(session,SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=8,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True)
  finally:m.research_set_order_fault(0)
  assert record_value(state)==before and r.action in legal_actions(state,c)
  if fault:assert r.termination_reason=='internal_error' and r.completed_depth==1 and m.research_get_fault_count()>0
  else:assert r.completed_depth==3 and r.termination_reason=='completed'
  rows.append(dict(root=sample['root'],kind=kind,result=record_value(r),fault_count=m.research_get_fault_count(),seconds=time.perf_counter()-t));print(sample['root'],kind,r.completed_depth,r.termination_reason)
write_record(out/'result.json',dict(complete=True,rows=rows))
