"""Observed Native identity failures must not become completed empty searches.

The optional Windows/Zig fixture builds the current source with a private,
ordering-scoped serializer fault. No fault hook is shipped in the product.
"""
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import sysconfig

import pytest

import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.limits import SearchLimits
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.session.session import GameSession


@pytest.fixture(scope="module")
def fault_kernel(tmp_path_factory):
    if os.name != "nt" or not native.native_available():
        pytest.skip("optional Windows Native fault-build regression")
    spec = importlib.util.find_spec("ziglang")
    if spec is None:
        pytest.skip("Zig is required for the private fault build")
    zig = Path(spec.origin).parent / "zig.exe"
    if not zig.is_file():
        pytest.skip("Windows Zig executable unavailable")
    root = Path(__file__).resolve().parents[2]
    source = root / "generic_chess" / "_native"
    out = tmp_path_factory.mktemp("native-ordering-error")
    module = (source / "native_module.c").read_text(encoding="utf-8")
    start = module.index("static int gc_semantic_order_actions(")
    end = module.index("\nstatic ", start + 1)
    original = module[start:end].replace(
        "gc_semantic_order_actions(", "gc_test_order_actions_impl(", 1
    )
    wrapper = """
int gc_test_key_failure = 0;
static int gc_test_fault_enabled = 0;
static int gc_semantic_order_actions(GCSemanticIterativeContext *ctx,
    GCSemanticPosition *position, uint32_t ply, uint32_t depth,
    GCSemanticActionBuffer *actions) {
    gc_test_key_failure = gc_test_fault_enabled;
    int result = gc_test_order_actions_impl(ctx, position, ply, depth, actions);
    gc_test_key_failure = 0;
    return result;
}
static PyObject *gc_test_set_fault(PyObject *self, PyObject *args) {
    (void)self; int enabled;
    if (!PyArg_ParseTuple(args, "p", &enabled)) return NULL;
    gc_test_fault_enabled = enabled; Py_RETURN_NONE;
}
"""
    module = module[:start] + original + wrapper + module[end:]
    needle = '    {"semantic_make_checked", gc_semantic_make_checked, METH_VARARGS,'
    assert module.count(needle) == 1
    module = module.replace(
        needle, '    {"test_set_fault", gc_test_set_fault, METH_VARARGS,'
        ' "Private ordering serializer fault"},\n' + needle
    )
    key = (source / "native_semantic_key.c").read_text(encoding="utf-8")
    needle = ("int gc_semantic_position_key_digest(const GCSemanticRules *r, "
              "const GCSemanticPosition *p, char out_hex[65]) {")
    assert key.count(needle) == 1
    key = key.replace(needle, needle +
                      "\n    extern int gc_test_key_failure;"
                      "\n    if (gc_test_key_failure) return 0;")
    (out / "native_module.c").write_text(module, encoding="utf-8")
    (out / "native_semantic_key.c").write_text(key, encoding="utf-8")
    binary = out / ("_native_core" + sysconfig.get_config_var("EXT_SUFFIX"))
    command = [str(zig), "cc", "-target", "x86_64-windows-gnu", "-shared", "-O2",
               "-I" + sysconfig.get_paths()["include"], "-I" + str(source),
               "-L" + str(Path(sys.base_prefix) / "libs"), "-lpython312"]
    command += [str(out / path.name if path.name in {
        "native_module.c", "native_semantic_key.c"} else path)
        for path in sorted(source.glob("*.c"))]
    command += ["-o", str(binary)]
    built = subprocess.run(
        command, capture_output=True, text=True, timeout=180,
        env=dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(out / "zig-cache")),
    )
    assert built.returncode == 0, built.stderr
    spec = importlib.util.spec_from_file_location("error_test._native_core", binary)
    kernel = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(kernel)
    return kernel


@pytest.mark.parametrize("root_windows", [False, True])
@pytest.mark.parametrize("cache_enabled", [False, True])
def test_serializer_error_retains_iteration_and_does_not_poison_tt(
    fault_kernel, monkeypatch, root_windows, cache_enabled,
):
    monkeypatch.setattr(native, "_MODULE", fault_kernel)
    compiled = compile_ruleset_for_execution(build_western_chess_ruleset())
    rules = compile_native_semantic_rules(compiled)
    profile = build_ruleset_profile(compiled, EvaluationConfig())
    checkpoint = LearnableMaterialCheckpoint.from_profile(
        compiled, profile, dynamic_weights={}
    )
    session = GameSession(compiled)
    before, witnesses = session.state, session._search_witnesses
    limits = SearchLimits(max_depth=3, max_nodes=1000000, max_time_seconds=8,
                          quiescence_max_depth=0, quiescence_hard_max_depth=0)

    def engine():
        return SemanticSearchEngine(
            compiled, rules, checkpoint=checkpoint,
            ordering_checkpoint=checkpoint, ordering_min_depth=2,
            ordering_cache_enabled=cache_enabled, tt_megabytes=1,
        )

    tested = engine()
    fault_kernel.test_set_fault(True)
    try:
        failed = tested.search(session, limits, root_window_pruning=root_windows)
    finally:
        fault_kernel.test_set_fault(False)
    assert failed.termination_reason == "internal_error"
    assert failed.completed_depth == 1
    assert failed.action in session.legal_actions()
    retry = tested.search(session, limits, root_window_pruning=root_windows)
    cold = engine().search(session, limits, root_window_pruning=root_windows)
    assert retry.completed_depth == cold.completed_depth == 3
    assert retry.termination_reason == cold.termination_reason == "completed"
    assert (retry.action, retry.score, retry.principal_variation) == (
        cold.action, cold.score, cold.principal_variation)
    assert session.state is before and session._search_witnesses is witnesses
