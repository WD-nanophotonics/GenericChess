"""New tier2 blocked-leaper/capture-to-hand/downgrade native control."""
import sys,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from generic_chess.core.movement import LeapAtom
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.schema import *
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import pack_position,fixed_depth_search,guarded_actions,make_checked
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from test_native_semantic_probe_search import _python_probe
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'recombined.json';assert not out.exists()
report=dict(complete=False,declaration=dict(question='Does the existing semantic search handle one actual recombined blocking/capture/downgrade rule without a new adapter?',design='Two5x5 initial roots, identical inventory and rule, move one friendly blocker to open/close the leaper leg. J has(1,2) jump and becomes weaker W(0,1) on its custom action, captured tokens transfer base to hand, drops allowed for J. Both colors use owner-relative leg guard. Fixed depth2 ordinal leaf, two calls/root; independent Python oracle and native PV legality.',decision='Guard activation and base/current/hand effects must be observed, native score/best/PV must equal independent oracle. Not price fitting, game-strength or universal tier2 coverage.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),cases=[]);write_record(out,report)
n=5;mask=(True,)*(n*n);false=(False,)*(n*n)
king=PieceType('K','anchor',tuple(LeapAtom((x,y)) for x in (-1,0,1) for y in (-1,0,1) if x or y),is_anchor=True)
j=PieceType('J','blocked leaper', (LeapAtom((1,2)),),is_promotable=True,promotion_target_ids=('W',));w=PieceType('W','weaker step',(LeapAtom((0,1)),))
actions=[]
for relation in ('empty','enemy'):
 effects=() if relation=='empty' else (RuleActionEffect('remove',square_ref=RuleSquareRef('target'),piece_owner='opponent',disposition='capture_to_hand'),)
 effects+=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),)
 actions.append(RuleSemanticAction(name='blocked_'+relation,type_ids=('J',),geometry=RuleGeometrySpec('leap',offset=(1,2)),target_relation=relation,composition='replace_legacy',replace_selector=RuleReplaceSelector(type_ids=('J',),action_family='board',target_relation=relation,geometry_kind='leap',replace_all_matching=True),state_guards=(RuleStateGuard(aggregation='count',owner='any',type_ref=RuleTypeRef('any'),location='board',spatial=RuleSpatialSelector('exact',refs=(RuleSquareRef('offset_from_source',offset=(0,1)),)),comparison='eq',value=0),),effects=effects,invariants=(RuleInvariant('own_anchor_safe'),),promotion_mode='explicit',explicit_promotion_type='W'))
for blocked in (True,False):
 board=[[None]*n for _ in range(n)];board[0][0]=Piece(0,'K','K');board[4][4]=Piece(1,'K','K');board[1][1]=Piece(0,'J','J');board[3][2]=Piece(1,'J','J');board[2 if blocked else 1][1 if blocked else 3]=Piece(0,'W','W')
 rules=RuleSet(board_size=n,piece_types=(king,j,w),initial_position=tuple(tuple(row) for row in board),drop_allowed={'J':(mask,mask),'W':(false,false)},promotion_allowed={},promotion_forced={},semantic_actions=tuple(actions),max_ply=64,repetition_limit=4)
 semantic=compile_semantic_ruleset(rules);start=time.perf_counter();native=compile_native_semantic_rules(semantic);setup=time.perf_counter()-start;session=GameSession(semantic);engine=SemanticEngine(semantic);position=session.state.position
 custom=[a for a in engine.legal_actions(position) if a.actor_type=='J' and a.source==6]
 assert bool(custom)!=blocked
 effects_seen=[]
 for action in custom:
  child=engine.apply(position,action);piece=child.board[action.target]
  assert piece.base_type_id=='J' and piece.current_type_id=='W' and piece.promoted
  assert child.hands[0].get('J')==1
  effects_seen.append(record_value(child))
 ids={t:i for i,t in enumerate(native.type_ids)};packed=pack_position(native,dict(side=0,ply=0,board=[None if piece is None else [ids[piece.base_type_id],ids[piece.current_type_id],piece.owner,int(piece.promoted)] for piece in position.board],hands=[[0]*len(ids),[0]*len(ids)],aux_state=()))
 start=time.perf_counter();expected=_python_probe(semantic,position,native,2);python_seconds=time.perf_counter()-start;calls=[]
 for repeat in (0,1):
  start=time.perf_counter();observed=fixed_depth_search(native,packed,2);seconds=time.perf_counter()-start
  assert {k:v for k,v in observed.items() if k!='nodes'}=={k:v for k,v in expected.items() if k!='nodes'}
  cursor=packed
  for action in observed['principal_variation']:assert action in guarded_actions(native,cursor);cursor=make_checked(native,cursor,action)
  calls.append(dict(repeat=repeat,seconds=seconds,result=observed))
 report['cases'].append(dict(blocked=blocked,ruleset=ruleset_to_dict(rules),fingerprint=semantic.ruleset_fingerprint,custom_actions=record_value(custom),effects_seen=effects_seen,compile_seconds=setup,python_seconds=python_seconds,python_result=expected,native_calls=calls,mismatches=0));write_record(out,report)
 print('blocked',blocked,'custom',len(custom),'score',expected['score'],'native',calls[0]['seconds'],flush=True)
report['complete']=True;write_record(out,report)
