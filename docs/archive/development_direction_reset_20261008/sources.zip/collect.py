"""Portable Agent-generated evidence, no user/Slack records."""
import sys,json,hashlib,zipfile,tempfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;q=ROOT/'.local_agent/prior-discrimination-20261007';a=ROOT/'docs/archive/development_direction_reset_20261008';a.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda f:json.loads(f.read_bytes())
cross=load(p/'cross-prices.json');two=load(p/'two-target.json');oracle=load(p/'two-target-oracle.json');native=load(p/'native-generated-completed.json');old=load(p/'generated-search.json');warm=load(p/'generated-warm-search.json');replay=load(q/'replay.json');probe=load(q/'capture-probe.json');games=load(q/'games.json')
assert all(x['complete'] for x in (cross,two,oracle,native,old,warm,replay,probe,games))
assert len(replay['games'])==4 and not replay['errors'] and replay['input_sha256']==sha((q/'games.json').read_bytes())
assert oracle['source_sha256']==sha((p/'two-target.json').read_bytes()) and oracle['geometry_source_sha256']==sha((p/'two-target.py').read_bytes())
assert oracle['mismatches']==0 and all(not x['mismatches'] for x in native['cases'])
assert len(native['cases'])==4 and sum(len(x['native_calls']) for x in native['cases'])==8
indexes={}
def archive(name,files):
 target=a/name;entries={}
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in files:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b)
   assert n not in entries;z.writestr(n,b);entries[n]=dict(bytes=len(b),sha256=sha(b))
 with tempfile.TemporaryDirectory(prefix='gc-direction-') as td,zipfile.ZipFile(target) as z:
  assert z.testzip() is None;z.extractall(td)
  for n,h in entries.items():assert sha((Path(td)/n).read_bytes())==h['sha256']
 indexes[name]=dict(sha256=sha(target.read_bytes()),entries=entries,physically_extracted_rehashed=True)
raw_names=('cross-prices.json','shogi-qualified-census.json','two-target-declaration.json','two-target.json','two-target-oracle.json','generated-search.json','generated-warm-search.json','generated-semantic-search.json','generated-semantic-ingress.json','native-generated-incomplete-first.json','native-generated-diagnosis.json','native-generated-completed.json','failures.json')
aux_names=('declaration.json','games.json','replay.json','capture-selection.json','capture-roots.json','capture-probe-declaration.json','capture-probe.json')
archive('raw.zip',[(p/n,n) for n in raw_names]+[(q/n,'auxiliary/'+n) for n in aux_names])
src_names=('cross-prices.py','two-target.py','two-target-oracle.py','native-generated.py','native-generated-node-diagnosis.py','unfamiliar-search-initial.py','unfamiliar-search-direct-semantic-failed.py','unfamiliar-search-semantic-ingress-failed.py','collect.py')
aux_src=('games.py','select-roots.py','capture-probe.py','replay.py')
archive('sources.zip',[(p/n,n) for n in src_names]+[(q/n,'auxiliary/'+n) for n in aux_src]+[(ROOT/n,n) for n in ('scripts/unfamiliar_search.py','scripts/research_record.py','tests/product/test_native_semantic_probe_search.py','tests/phase19c1_native_semantic_fixtures.py','tests/rule_semantics_ir_fixtures.py','tests/conftest.py')])
report=dict(complete=True,scope='Direction-aligned construction/interface development; no learning/fitting/default promotion/strength certification; old adverse records and applicability/holdout boundaries retained.',base_sha='ac95d06912a21b62487d229fd0cceecf191d27ce',cross_price=cross,two_target=two,two_target_oracle_summary={k:v for k,v in oracle.items() if k!='rows'},generated_search=old,generated_warm_search=warm,native_generated=native,failures=load(p/'failures.json'),auxiliary=dict(declaration=games['declaration'],replay=replay,wall_seconds=games['wall_seconds'],capture_probe=probe),archives=indexes,production_changes='None to Core/evaluator/search defaults. One reusable scoped generated-search research entry; docs/policy priority alignment.',next='Rule-derived utility mechanism with joint exposure; one recombined-rule semantic search/persistent-history control. Do not extend saturated auxiliary games or tune prices.')
out=ROOT/'docs/research/data/direction_reset_20261008.json';write_record(out,report);write_record(a/'index.json',dict(archives=indexes,portable_sha256=sha(out.read_bytes())))
print('ARCHIVE',sum(len(x['entries']) for x in indexes.values()),'extracted/rehashed entries;4games replay',replay['played_plies'],replay['prefix_plies'])
