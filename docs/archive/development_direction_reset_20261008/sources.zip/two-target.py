"""Complete virtual H1/H2 removal opportunity, stationary two-target law."""
import sys,json,time,hashlib,itertools
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;declaration=json.loads((p/'two-target-declaration.json').read_bytes());out=p/'two-target.json';assert not out.exists()
directions={'R':((1,0),(-1,0),(0,1),(0,-1)),'B':((1,1),(-1,1),(1,-1),(-1,-1)),'N':((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1))};directions['Q']=directions['R']+directions['B']
def geometry(mode):
 edges=[[None]*64 for _ in range(64)];paths=[]
 for source in range(64):
  rays=[];x,y=source%8,source//8
  for dx,dy in directions[mode]:
   ray=[];between=0;xx,yy=x+dx,y+dy
   while 0<=xx<8 and 0<=yy<8:
    target=xx+8*yy;ray.append(target);edges[source][target]=between;between|=1<<target
    if mode=='N':break
    xx+=dx;yy+=dy
   rays.append(ray)
  paths.append(rays)
 return edges,paths
report=dict(complete=False,declaration=declaration,rows={},producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out,report)
start=time.perf_counter()
for mode in ('Q','R','B','N'):
 edges,paths=geometry(mode);counts1=[0,0];counts2=[0,0,0];queries=0;roots=0
 for source in range(64):
  flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
  for a,b in itertools.combinations((i for i in range(64) if i!=source),2):
   roots+=1;mask=(1<<a)|(1<<b)
   def hit(s,t,occupancy):
    global queries
    queries+=1;between=edges[s][t]
    return between is not None and not between&occupancy
   firsta=hit(source,a,mask);firstb=hit(source,b,mask);h1=int(firsta or firstb)
   h2=h1
   if (firsta and hit(a,b,1<<b)) or (firstb and hit(b,a,1<<a)):
    h2=2
   elif not h1:
    for ray in paths[source]:
     for child in ray:
      if mask&(1<<child):break
      if hit(child,a,mask) or hit(child,b,mask):h2=1;break
     if h2:break
   counts1[h1]+=1;counts2[h2]+=1
  if source%16==15:print(mode,'sources',source+1,'roots',roots,flush=True)
 assert roots==124992
 report['rows'][mode]=dict(roots=roots,H1_histogram=counts1,H2_histogram=counts2,H1_mean=Fraction(counts1[1],roots),H2_mean=Fraction(counts2[1]+2*counts2[2],roots),geometry_queries=queries)
 write_record(out,report)
report.update(complete=True,seconds=time.perf_counter()-start,core_transitions=0,source_queries=0)
report['Q_R']={h:Fraction(report['rows']['Q'][h+'_mean'])/Fraction(report['rows']['R'][h+'_mean']) for h in ('H1','H2')}
write_record(out,report)
print('COMPLETE',report['Q_R'],'seconds',report['seconds'],flush=True)
