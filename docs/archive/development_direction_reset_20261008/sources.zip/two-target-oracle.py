"""Independent full move enumeration on prespecified512 geometric contexts."""
import sys,json,random,hashlib,ast
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'two-target.json').read_bytes();data=json.loads(raw);assert data['complete']
rng=random.Random(20261008);cases=[tuple(rng.sample(range(64),3)) for _ in range(128)]
directions={'R':((1,0),(-1,0),(0,1),(0,-1)),'B':((1,1),(-1,1),(1,-1),(-1,-1)),'N':((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1))};directions['Q']=directions['R']+directions['B']
def moves(mode,source,targets):
 x,y=source%8,source//8
 for dx,dy in directions[mode]:
  xx,yy=x+dx,y+dy
  while 0<=xx<8 and 0<=yy<8:
   destination=xx+8*yy;yield destination
   if destination in targets or mode=='N':break
   xx+=dx;yy+=dy
def brute(mode,s,targets):
 first=list(moves(mode,s,targets));one=max((int(v in targets) for v in first),default=0)
 two=0
 for child in first:
  victims=targets-{child};captured=int(child in targets)
  two=max(two,captured+max((int(v in victims) for v in moves(mode,child,victims)),default=0))
 return one,two
# Load only the producer's pure geometry builder and its direction constants;
# no producer run, file side effect or recomputation of the frozen census.
geometry_source=(p/'two-target.py').read_bytes();syntax=ast.parse(geometry_source)
nodes=[n for n in syntax.body if isinstance(n,ast.FunctionDef) and n.name=='geometry'
       or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='directions'
          or isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name) and t.value.id=='directions' for t in n.targets)]
namespace={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'producer-geometry','exec'),namespace)
rows=[]
for mode in ('Q','R','B','N'):
 edges,paths=namespace['geometry'](mode)
 def can_hit(mode,s,t,targets):
  between=edges[s][t]
  return between is not None and not between&sum(1<<v for v in targets)
 for source,a,b in cases:
  targets={a,b};firsta=can_hit(mode,source,a,targets);firstb=can_hit(mode,source,b,targets)
  h1=int(firsta or firstb)
  if (firsta and can_hit(mode,a,b,{b})) or (firstb and can_hit(mode,b,a,{a})):h2=2
  elif h1:h2=1
  else:h2=int(any(can_hit(mode,child,a,targets) or can_hit(mode,child,b,targets) for child in moves(mode,source,targets) if child not in targets))
  expected=brute(mode,source,targets);assert (h1,h2)==expected
  rows.append(dict(mode=mode,source=source,targets=[a,b],H1=h1,H2=h2))
report=dict(complete=True,scope='512 deterministic independent direct-move enumeration cases against actual producer geometry; not independent empirical game validation.',source_sha256=hashlib.sha256(raw).hexdigest(),geometry_source_sha256=hashlib.sha256(geometry_source).hexdigest(),rows=rows,mismatches=0,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(p/'two-target-oracle.json',report);print('512contexts zero mismatches; partial-mode virtual law only')
