"""Existing semantic Native kernel against existing independent Python oracle."""
import sys,time,hashlib,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import pack_position,fixed_depth_search,guarded_actions,make_checked
from scripts.research_record import write_record
from test_native_semantic_probe_search import _python_probe
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('ingress',p/'unfamiliar-search-semantic-ingress-failed.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
report=dict(complete=False,declaration=dict(question='Does the existing semantic native search work on qualified ingress of unfamiliar generated rules?',seeds=[7,21],sizes=[4,6],depth=3,repeats=2,reference='Existing independent Python packed-action alpha-beta oracle; same ordinal type-index+1 leaf vector, no human/contact price fitting, no TT. Not speed-comparable to generic-v1.',cost='Four bounded fixed depth3 roots, twice each. Existing filters/corpus fixed before scoring. No selfplay/learning/model or new worker.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),oracle_sha256=hashlib.sha256((ROOT/'tests/product/test_native_semantic_probe_search.py').read_bytes()).hexdigest()),cases=[])
report['declaration']['node_comparison']='First root diagnosis found identical score/best/PV but47vs52 nodes; implementations need not visit/count identical nodes. Preserve counts, compare decision fields, and retain previous diagnosis. No changed price/depth/root/success-score standard.'
out=p/'native-generated-completed.json';assert not out.exists();write_record(out,report)
for size in (4,6):
 for seed in (7,21):
  game=generate_game(GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));semantic=compile_semantic_ruleset(module.semantic_ingress(game.ruleset));parity=module.compare_ingress(game.compiled_ruleset,semantic)
  start=time.perf_counter();native=compile_native_semantic_rules(semantic);compile_seconds=time.perf_counter()-start
  assert native.native_executable
  session=module.GameSession(semantic);ids={type_id:i for i,type_id in enumerate(native.type_ids)};position=session.state.position
  start=time.perf_counter();packed=pack_position(native,dict(side=position.side_to_move,ply=0,board=[None if piece is None else [ids[piece.base_type_id],ids[piece.current_type_id],piece.owner,int(piece.promoted)] for piece in position.board],hands=[[0]*len(ids),[0]*len(ids)],aux_state=position.aux_state));pack_seconds=time.perf_counter()-start
  start=time.perf_counter();expected=_python_probe(semantic,position,native,3);python_seconds=time.perf_counter()-start
  calls=[]
  for repeat in (0,1):
   start=time.perf_counter();result=fixed_depth_search(native,packed,3);seconds=time.perf_counter()-start
   if {k:v for k,v in result.items() if k!='nodes'}!={k:v for k,v in expected.items() if k!='nodes'}:
    report['cases'].append(dict(seed=seed,size=size,ingress_parity=parity,python_result=expected,native_result=result,mismatches={k:dict(python=expected.get(k),native=result.get(k)) for k in set(expected)|set(result) if expected.get(k)!=result.get(k)},diagnostic='Repeat first interrupted cell once with persisted discrepancy before assertion; stop further cases.'))
    write_record(out,report)
    print(report['cases'][-1],flush=True)
    raise SystemExit('STOP: discrepancy retained')
   cursor=packed
   for action in result['principal_variation']:assert action in guarded_actions(native,cursor);cursor=make_checked(native,cursor,action)
   calls.append(dict(repeat=repeat,seconds=seconds,result=result))
  report['cases'].append(dict(seed=seed,size=size,semantic_fingerprint=semantic.ruleset_fingerprint,ingress_parity=parity,compile_seconds=compile_seconds,pack_seconds=pack_seconds,python_seconds=python_seconds,python_result=expected,native_calls=calls,mismatches=0));write_record(out,report)
  print(size,seed,'nodes',expected['nodes'],'python',python_seconds,'native',[x['seconds'] for x in calls],'parity',parity,flush=True)
report['complete']=True;write_record(out,report)
