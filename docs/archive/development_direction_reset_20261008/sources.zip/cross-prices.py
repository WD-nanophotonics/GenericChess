"""Recover qualified frozen census, compute both laws, no engine/human fitting."""
import sys,json,zipfile,hashlib,time
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.chess_exact_contact_family import exact_chess_contact_intervals
from scripts.research_record import write_record
p=Path(__file__).parent
archive=ROOT/'.local_agent/layout-backup-20261007/snapshot.zip'
names=('docs/research/data/shogi_full_contact_distance_20261005.json','docs/research/data/shogi_coordinate_comparison_20261005.json','scripts/shogi_exact_contact_family.py')
with zipfile.ZipFile(archive) as z:
 raw={n:z.read(n) for n in names}
shogi=json.loads(raw[names[0]]);qualification=json.loads(raw[names[1]])
assert all(x['complete'] and x['source_hashes_unchanged'] for x in (shogi,qualification))
assert len(shogi['rows'])==13 and len(qualification['rows'])==13 and all(x['match'] for x in qualification['rows'])
assert all(sum(row['histogram'].values())+row['unreachable']==row['total']==511920 for row in shogi['rows'])
source=p/'shogi-qualified-census.json'
write_record(source,dict(rows=shogi['rows'],qualification=qualification,original_sha256={n:hashlib.sha256(b).hexdigest() for n,b in raw.items()},archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
results={};start=time.perf_counter()
for law in ('geometric_half','linear_mixture'):
 moment=(lambda t:F(1,2)**t) if law=='geometric_half' else (lambda t:F(2,(t+1)*(t+2)))
 chess={m:lo for (_,m),(lo,hi) in exact_chess_contact_intervals(law).items() if lo==hi}
 means={r['profile']['current']:sum(F(n)*moment(int(t)) for t,n in r['histogram'].items())/r['total'] for r in shogi['rows']}
 assert all(means[m]==means['G'] for m in ('TP','TL','TN','TS'))
 results[law]=dict(chess=dict(exact=chess,pawn_normalized={k:float(v/chess['P']) for k,v in chess.items()},queen_rook=chess['Q']/chess['R']),shogi=dict(exact=means,pawn_normalized={k:float(v/means['P']) for k,v in means.items()},rook_bishop=means['R']/means['B'],silver_gold=means['S']/means['G']))
# Same positive moment weights cannot change the coefficient-ratio upper bound.
q=(87696,162048,240);r=(53760,194432,1792)
upper=max(F(a,b) for a,b in zip(q,r))
assert upper==F(1827,1120) and upper<F(9,5)
report=dict(complete=True,construction='Existing first-contact distance mean with shared declared moment law; same formula across game-specific qualified distance censuses. Unreachable has zero contribution; no fitting or new context/source transitions.',results=results,
 chess_queen_rook_bound=dict(upper=upper,coefficients=dict(Q=q,R=r),proof='Q/R is a convex combination of the three per-distance coefficient ratios, weights R_count(t)*moment(t). All nonnegative shared moments imply upper1827/1120; excluded all-zero denominator.',teaching_reference_ratio='9/5',implication='Changing only the common duration moment cannot reach this instructional Q/R ratio under the frozen spatial one-contact law.'),
 shogi_origin_limitation='Gold,TP,TL,TN,TS have exactly equal current-board histograms/means in both laws. Capture returns different base types to the enemy hand; current-board distance alone cannot encode that liability. Held-law intervals are separate and not promoted to a common point price here.',
 reference_scope='Descriptive exposed instructional baselines, not unique empirical optima/validation holdout: Irish Chess Union relative-values sheet; koichi.jp teaching table. No Xiangqi human-value file or numbers read; no fitted transformation/table selection.',
 sources=dict(chess='docs/research/data/chess_zero_target_correction_20261005.json',shogi_recovery='docs/archive/repository_cleanup_20261007/retired-sources.json',recovered_subset_sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
 seconds=time.perf_counter()-start,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
write_record(p/'cross-prices.json',report)
for law,row in results.items():
 print(law,'Chess',row['chess']['pawn_normalized'],'Shogi',row['shogi']['pawn_normalized'],flush=True)
print('Q/R all shared positive moments <=',upper,'no new transitions',flush=True)
