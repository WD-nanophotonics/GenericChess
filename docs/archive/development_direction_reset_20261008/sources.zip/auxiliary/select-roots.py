"""Preselect legal capture contexts without looking at outcome or engine scores."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
p=Path(__file__).parent;source=ROOT/'.local_agent/positional-feedback-20261007/games.json';v=json.loads(source.read_bytes());assert v['complete']
plan=dict(question='Do the two frozen priors change choices where actual legal captures offer different victim types?',selection='First eligible candidate-turn root within first48played plies, one for each2prefix x2rule tables, from the retained exchange White game. At least2legal captures of distinct non-King victim types; not in check. Outcome, scores and old selected move never used. Retain absent contexts rather than widening selection.',cost='Pure legal enumeration of <=192positions, no new native search during timed cohort.',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
out=p/'capture-roots.json';assert not out.exists();d.write_record(p/'capture-selection.json',plan);rows=[]
for g in v['games']:
 if g['leaf']!='exchange' or g['candidate_color']!=0 or g['table']=='unit':continue
 b=chess.Board(g['initial_fen'])
 for m in g['opening_uci']:b.push_uci(m)
 selected=None
 for i,z in enumerate(g['moves'][:48]):
  if b.turn==chess.WHITE and not b.is_check():
   captures=[m for m in b.legal_moves if b.is_capture(m)]
   victims={('P' if b.is_en_passant(m) else b.piece_at(m.to_square).symbol().upper()) for m in captures}
   if len(captures)>=2 and len(victims)>=2:
    selected=dict(index=i,fen=b.fen(en_passant='fen'),history_prefix=g['opening_uci']+[r['move'] for r in g['moves'][:i]],legal_captures=[m.uci() for m in captures],victim_types=sorted(victims));break
  b.push_uci(z['move'])
 rows.append(dict(id=g['id'],source_table=g['table'],context=selected))
assert len(rows)==4
d.write_record(out,dict(complete=True,declaration=plan,rows=rows))
print([(x['id'],x['source_table'],None if x['context'] is None else (x['context']['index'],x['context']['victim_types'])) for x in rows])
