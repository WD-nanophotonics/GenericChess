"""Fixed-node choice and legal immediate exchange diagnostics, not WDL."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;assert json.loads((p/'games.json').read_bytes())['complete']
source=p/'capture-roots.json';rows=json.loads(source.read_bytes())['rows'];contexts=[];seen=set()
for row in rows:
 if row['context'] is None:continue
 key=tuple(row['context']['history_prefix'])
 if key not in seen:contexts.append(row);seen.add(key)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();config=ROOT/'.local_agent/mature-search/material-variants.ini'
bins={'exchange':ROOT/'.local_agent/exchange-20261007/fairy-exchange.exe','classical':ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe'}
plan=dict(question='Do fixed rule priors discriminate in the preselected real capture contexts?',design='Each unique full-history context x geometric/linear x existing exchange/classical leaves;3Mnodes/10sec fuse SinglePV1 Threads1 Hash16 NNUEfalse, fresh process/hash per cell. Duplicate histories collapse before scoring. Separate exact legal capture/direct-recapture inventory vectors, no actor flip or price for King.',decision='Different choices permit scoped follow-up, not table selection/unique loss cause. Same choices are negative discrimination evidence. Two-ply recapture lines are local arithmetic, not minimax/all-defense/WDL.',cost='<=12calls/120sec fuse plus current legal capture enumeration; all retained, no competing timed job.',selection_sha256=sha(source),binary_sha256={k:sha(v) for k,v in bins.items()},config_sha256=sha(config),producer_sha256=sha(Path(__file__)))
out=p/'capture-probe.json';assert not out.exists();d.write_record(p/'capture-probe-declaration.json',plan);report=dict(complete=False,declaration=plan,contexts=[]);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());tables=d.material_tables()
def inventory(b,policy):return sum((1 if x.color else -1)*tables[policy][x.symbol().upper()] for x in b.piece_map().values() if x.piece_type!=chess.KING)
for i,context in enumerate(contexts):
 r=dict(context_index=i,**context,choices=[],exchanges=[]);history=context['context']['history_prefix'];b=chess.Board(chess.STARTING_FEN)
 for m in history:b.push_uci(m)
 s,_=d.replay_prefix(chess.STARTING_FEN,c,history);legal={d.uci(a) for a in d.iter_legal_actions(s,c)};assert legal=={m.uci() for m in b.legal_moves}
 for move in b.legal_moves:
  if not b.is_capture(move):continue
  child=b.copy(stack=True);child.push(move)
  after={policy:inventory(child,policy)-inventory(b,policy) for policy in ('geometric_half','linear_mixture')}
  replies=[]
  for reply in child.legal_moves:
   if not child.is_capture(reply) or reply.to_square!=move.to_square:continue
   end=child.copy(stack=True);end.push(reply);replies.append(dict(move=reply.uci(),delta_white={policy:inventory(end,policy)-inventory(b,policy) for policy in after}))
  r['exchanges'].append(dict(move=move.uci(),after_capture_delta_white=after,legal_direct_recaptures=replies))
 for policy in ('geometric_half','linear_mixture'):
  for leaf,binary in bins.items():
   for name in ('rollout','advisor','slack'):
    x=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes());assert not x.get('stopped') and not x.get('user_paused')
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
    e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=d.UciMaterial(e,chess.STARTING_FEN,policy,10);player.limit=chess.engine.Limit(nodes=3000000,time=10)
    d.replay_prefix(chess.STARTING_FEN,c,history,(player,));m,z=player.choose();assert m in legal;board=b.copy(stack=True)
    for pv in z['pv']:assert chess.Move.from_uci(pv) in board.legal_moves;board.push_uci(pv)
    z.update(table=policy,leaf=leaf,node_budget_reached=z['engine_nodes']>=3000000);r['choices'].append(z)
 r['legal_history_selected_pv_mismatches']=0;report['contexts'].append(r);d.write_record(out,report)
 print(i,context['id'],[(x['table'],x['leaf'],x['move'],x['node_budget_reached']) for x in r['choices']],flush=True)
report['complete']=True;d.write_record(out,report)
