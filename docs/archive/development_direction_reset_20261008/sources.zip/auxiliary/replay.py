"""Replay every auxiliary Chess move/PV/history and saved draw witness."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
p=Path(__file__).parent;raw=(p/'games.json').read_bytes();v=json.loads(raw)
assert v['complete'] and len(v['games'])==4
out=p/'replay.json';assert not out.exists();c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
r=dict(complete=False,input_sha256=hashlib.sha256(raw).hexdigest(),games=[],errors=[]);start=time.perf_counter()
for i,g in enumerate(v['games']):
 other=d.UciOpponent(None,g['initial_fen'],1);judge=d.ChessAdjudicator(g['initial_fen'])
 s,_=d.replay_prefix(g['initial_fen'],c,g['opening_uci'],(other,judge));cost={}
 for row in g['moves']:
  assert judge.decision() is None
  legal={d.uci(a):a for a in d.iter_legal_actions(s,c)}
  assert set(legal)=={m.uci() for m in other.board.legal_moves}
  assert row['legal'] and row['move'] in legal and row['side']==s.position.side_to_move and row['ply']==s.ply_count
  mode='geometric_half' if row['side']==g['candidate_color'] else 'linear_mixture'
  z=cost.setdefault(mode,dict(calls=0,wall_seconds=0.,controller_cpu_seconds=0.,engine_reported_nodes=0,engine_reported_seconds=0.))
  z['calls']+=1;z['wall_seconds']+=row['wall_seconds'];z['controller_cpu_seconds']+=row['controller_cpu_seconds'];z['engine_reported_nodes']+=row['engine_nodes'];z['engine_reported_seconds']+=row['engine_seconds']
  board=other.board.copy(stack=True)
  for move in row['pv']:assert chess.Move.from_uci(move) in board.legal_moves;board.push_uci(move)
  s=d.apply_action(s,legal[row['move']],c);other.push(row['move'],s);judge.push(row['move'],s)
 assert d.record_value(s)==g['final_state'] and len(s.history)==len(g['opening_uci'])+len(g['moves'])+1
 if 'adjudication' in g:
  saved=g['adjudication'];decision=judge.decision(claims=saved['kind']=='claim');assert saved==dict(ply=s.ply_count,**decision)
 elif g['finished']:assert s.terminal_status.is_terminal
 outcome='unfinished' if not g['finished'] else 'draw' if g['winner'] is None else 'geometric_win' if g['winner']==g['candidate_color'] else 'linear_win'
 r['games'].append(dict(index=i,id=g['id'],geometric_color=g['candidate_color'],outcome=outcome,plies=len(g['moves']),prefix_plies=len(g['opening_uci']),end=g['end'],adjudication=g.get('adjudication'),cost=cost))
 d.write_record(out,r,indent=None)
r.update(complete=True,played_plies=sum(x['plies'] for x in r['games']),prefix_plies=sum(x['prefix_plies'] for x in r['games']),wall_seconds=time.perf_counter()-start);d.write_record(out,r)
print('REPLAY',len(r['games']),r['played_plies'],r['prefix_plies'],'zero mismatches',flush=True)
