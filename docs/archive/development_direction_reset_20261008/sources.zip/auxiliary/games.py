"""Four frozen-prior head-to-head cells beyond the saturated unit control."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();binary=ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini';suite=ROOT/'.local_agent/see-opening-20261007/suite.json'
cases=json.loads(suite.read_bytes())['cases'];out=p/'games.json';assert not out.exists()
plan=dict(question='Can the two fixed rule-derived priors be distinguished within the same supported positional/search bundle, after both defeated unit?',design='4streams:two existing6ply prefixes x both geometric colors, versus linear_mixture. Identical classical executable/SinglePV1/Threads1/Hash16/NNUEfalse1.5sec, fresh processes/hash per cell,160subsequentplies; immediate Chess draw policy. One sequential game only.',decision='Useful exposed head-to-head deployment feedback, not table selection/fitting/formula admission/Elo. Native PSQT/material/SEE/pruning price coupling remains. Retain all4cells, no outcome-based extension.',cost='<=960requested seconds plus replay/recording; explicit new comparator, not an unchanged unit rerun. Interruptible each move; no competing timed job.',binary_sha256=sha(binary),config_sha256=sha(config),suite_sha256=sha(suite),producer_sha256=sha(Path(__file__)),adapter_sha256=sha(ROOT/'scripts/chess_development.py'))
assert plan['binary_sha256']=='2f67539e3b58295901e365edb722fba1e43220185e97eaafb18f38df9d7a8232'
d.write_record(p/'declaration.json',plan);report=dict(complete=False,declaration=plan,games=[]);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());start=time.perf_counter()
def stop():
 for name in ('rollout','advisor','slack'):
  x=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes());assert not x.get('stopped') and not x.get('user_paused')
d.write_record(out,report)
try:
 for case in cases:
  for color in (0,1):
   stop()
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as other:
    for engine in (e,other):engine.configure({'Threads':1,'Hash':16,'Use NNUE':False})
    local=d.UciMaterial(e,case['fen'],'geometric_half',1.5);external=d.UciMaterial(other,case['fen'],'linear_mixture',1.5)
    tags=dict(id=case['id'],table='geometric_half',candidate_color=color,leaf='classical',opponent_table='linear_mixture')
    def progress(g):d.write_record(p/'active.json',dict(**tags,**g),indent=None);stop()
    g=d.play_game(case['fen'],c,'geometric_half' if color==0 else 'uci_reference','uci_reference' if color==0 else 'geometric_half',d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1.5),160,progress,external=external,local_external=local,prefix=case['opening_uci'],claim_chess_draws=True)
    report['games'].append(dict(**tags,**g));d.write_record(out,report,indent=None);print(len(report['games']),case['id'],color,g['end'],g['winner'],g['plies_played'],flush=True)
 report['complete']=True
finally:report['wall_seconds']=time.perf_counter()-start;d.write_record(out,report)
d.write_record(p/'active.json',dict(complete=report['complete'],completed_games=len(report['games'])))
print('COMPLETE',report['complete'],report['wall_seconds'],flush=True)
