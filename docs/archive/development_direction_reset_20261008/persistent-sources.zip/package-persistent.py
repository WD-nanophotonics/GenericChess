"""Add the later declared reuse control to the unpublished portable evidence."""
import sys,json,zipfile,tempfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/development_direction_reset_20261008';out=ROOT/'docs/research/data/direction_reset_20261008.json';report=json.loads(out.read_bytes());extra=json.loads((p/'persistent.json').read_bytes());assert extra['complete']
for zipname,names in (('persistent-raw.zip',('persistent.json',)),('persistent-sources.zip',('persistent.py','package-persistent.py'))):
 target=a/zipname;assert not target.exists();entries={}
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for name in names:
   b=(p/name).read_bytes();z.writestr(name,b);entries[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 with tempfile.TemporaryDirectory(prefix='gc-persistent-') as td,zipfile.ZipFile(target) as z:
  assert z.testzip() is None;z.extractall(td)
  for name,row in entries.items():assert hashlib.sha256((Path(td)/name).read_bytes()).hexdigest()==row['sha256']
 report['archives'][zipname]=dict(entries=entries,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),physically_extracted_rehashed=True)
report['native_persistent']=extra;write_record(out,report);write_record(a/'index.json',dict(archives=report['archives'],portable_sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
print('42total archive entries extracted/rehashed; persistent control complete')
