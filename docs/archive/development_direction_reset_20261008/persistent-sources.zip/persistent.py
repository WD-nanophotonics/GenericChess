"""Single predeclared generated root cold/warm/next-root native reuse."""
import sys,time,hashlib,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('ingress',p/'unfamiliar-search-semantic-ingress-failed.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=p/'persistent.json';assert not out.exists()
declaration=dict(question='Can existing native semantic search reuse one generated-rule engine/TT across repeated and child full-history roots?',config=dict(seed=7,board_size=6,setup_preset='bilateral_random',allow_hybrid=True),search=dict(depth=3,nodes=4096,seconds=5,qdepth=0,tt_megabytes=1),selection='One fixed6x6 seed7 from prior cohort; next position is lexicographically first Core legal action, selected before searches, not by score.',decision='Score disagreement warm/fresh complete cells or illegal PV stops reuse claim. More hits/fewer nodes are cost observations, not game strength. No new rules/price/checkpoint/model.')
report=dict(complete=False,declaration=declaration,calls=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out,report)
game=generate_game(GeneratorConfig(**declaration['config']));compiled=compile_semantic_ruleset(m.semantic_ingress(game.ruleset));native=compile_native_semantic_rules(compiled);session=GameSession(compiled)
action=sorted(session.legal_actions(),key=str)[0];child=GameSession(compiled);child.submit(action)
report.update(fingerprint=compiled.ruleset_fingerprint,next_action=record_value(action),next_full_history_plies=child.state.ply_count)
start=time.perf_counter();engine=SemanticSearchEngine(compiled,native,tt_megabytes=1);report['engine_setup_seconds']=time.perf_counter()-start
limits=SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0)
for label,target in (('root_cold',session),('root_warm',session),('child_reused',child),('child_fresh',child)):
 current=engine if label!='child_fresh' else SemanticSearchEngine(compiled,native,tt_megabytes=1)
 start=time.perf_counter();decision=current.search(target,limits);seconds=time.perf_counter()-start
 m.validate_pv(target,decision);report['calls'].append(dict(label=label,observed_seconds=seconds,decision=record_value(decision),tt=current.tt_info()));write_record(out,report)
 print(label,decision.completed_depth,decision.score,decision.nodes,decision.tt_hits,seconds,flush=True)
for left,right in ((0,1),(2,3)):
 a,b=[report['calls'][i]['decision'] for i in (left,right)]
 assert a['completed_depth']==b['completed_depth']==3 and a['score']==b['score']
report.update(complete=True,score_parity=True,pv_legality_mismatches=0);write_record(out,report)
