"""Prospective planned-cell ordinal-board utility and exact held-hand/rank audit."""
from pathlib import Path
from collections import Counter
from statistics import median
import json,sys,random,hashlib
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/ordinal-board-utility-20261018';p=json.loads((D/'plan.json').read_bytes());result=json.loads((D/'result.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['slots'];games={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};models={(r['rule'],r['label']):r['checkpoint']for r in json.loads((D/'models.json').read_bytes())['rows']};rankaudit=[]
for gs in sorted({r['rule']for r in json.loads((D/'models.json').read_bytes())['rows']}):
 a=models[gs,'rule_static_v2'];b=models[gs,'rank_only'];assert a['hand_weights']==b['hand_weights'];ts=[t for t,v in a['board_weights'].items()if v!=0];active={t:round(a['board_weights'][t]*256)for t in ts};values=sorted(active.values());ranks={t:sum(i+1 for i,v in enumerate(values)if v==value)/values.count(value)for t,value in active.items()};med=median(ranks.values())
 for t in ts:assert b['board_weights'][t]==round(1000*ranks[t]/med)/1000
 for x in ts:
  for y in ts:
   aa=active[x]-active[y];bb=round(b['board_weights'][x]*256)-round(b['board_weights'][y]*256);assert(aa>0)-(aa<0)==(bb>0)-(bb<0)
 rankaudit.append(dict(rule=gs,nonanchors=ts,hand_equal=True,Native_board_weakordering_equal=True,static_active=active,rank_active={t:round(b['board_weights'][t]*256)for t in ts}))
rows=[]
for idx,(gs,fam,label,owner,foe)in enumerate(slots):
 g=games.get(idx);rows.append(dict(rule=gs,seed=gs//100,family=fam,model=label.split('@')[0],owner=owner,foe=foe,reward=None if g is None else g['reward'],game=g))
assert len(rows)==128 and len(games)==result['returned_physical']
def bounds(rr):
 u=sum(r['reward']is None for r in rr);k=sum(r['reward']for r in rr if r['reward']is not None);n=len(rr);return dict(planned=n,W=sum(r['reward']==1 for r in rr),D=sum(r['reward']==0 for r in rr),L=sum(r['reward']==-1 for r in rr),UNKNOWN=u,reward_bounds=[(k-u)/n,(k+u)/n],nodes=sum((r['game']or{}).get('nodes',0)for r in rr),game_seconds=sum((r['game']or{}).get('game_seconds',0)for r in rr))
def contrast(rr):
 a={(r['rule'],r['family'],r['owner']):r for r in rr if r['model']=='rule_static_v2'};b={(r['rule'],r['family'],r['owner']):r for r in rr if r['model']=='rank_only'};assert a.keys()==b.keys();n=len(a);lo=hi=0
 for k in a:
  x=a[k]['reward'];y=b[k]['reward'];lo+=(-1 if x is None else x)-(1 if y is None else y);hi+=(1 if x is None else x)-(-1 if y is None else y)
 return[lo/n,hi/n]
foes={}
for foe in p['foe_models']:
 rr=[r for r in rows if r['foe']==foe];seeds=p['seeds'];per={s:contrast([r for r in rr if r['seed']==s])for s in seeds};rng=random.Random(2026101823);boot=[]
 for _ in range(10000):
  sample=[rng.choice(seeds)for __ in seeds];boot.append([sum(per[s][i]for s in sample)/len(sample)for i in(0,1)])
 foes[foe]=dict(models={m:bounds([r for r in rr if r['model']==m])for m in p['candidate_models']},static_minus_rank=contrast(rr),per_seed=per,descriptive_linked_seed_envelope=[sorted(x[0]for x in boot)[249],sorted(x[1]for x in boot)[9749]])
qq=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));assert sum(q['nodes']for q in qq)==result['counts']['nodes'];work={}
for m in p['candidate_models']:
 ids={i for i,slot in enumerate(slots)if slot[2].startswith(m+'@')};qs=[q for q in qq if q['slot']in ids];work[m]={side:dict(queries=len(v),nodes=sum(q['nodes']for q in v),caller_seconds=sum(q['caller_seconds']for q in v),kernel_seconds=sum(q['kernel_seconds']for q in v),depths=dict(Counter(q['completed_depth']for q in v)),causes=dict(Counter(q['cause']for q in v)))for side,v in[(side,[q for q in qs if q['candidate_turn']==(side=='candidate')])for side in('candidate','foe')]}
write_json(D/'analysis.json',dict(status='PASS_PROSPECTIVE_BOARD_NUMERIC_VS_NATIVE_ORDINAL',foes=foes,rule_rank_hand_audit=rankaudit,work=work,producer_seconds=result['seconds'],planned=128,returned=len(games),missing=128-len(games),queries=len(qq),nodes=result['counts']['nodes'],scope='New8seedblocks/8rules/16prefixes, all128physicalcells andUNKNOWN, no oldrefill. Descriptive10000linked-seedresamples, not independentgames/populationconfidence. HANDS exactlyfixed, Native nonanchorboardweakorderingexact; numericboardspacing changes. Rankderivedfromstaticcomputedtable, NOT cheaper rulefeatureextraction or independentgeometrymethod.6boardregimeselectedafterearlierstudy, prospectivecontrollednewseeds notuniversalholdout. No learner/default/WDL orvalueuniquenessclaim.'))
print(json.dumps(dict(foes=foes,queries=len(qq),nodes=result['counts']['nodes']),indent=2))
