"""Rebuild all rule-only static inputs and verify held-hand/rank control exactly."""
from pathlib import Path
import sys,json,time,os
from itertools import combinations
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.material import LearnableMaterialCheckpoint
D=R/'.local_agent/ordinal-board-utility-20261018';rows=json.loads((D/'models.json').read_bytes())['rows'];mods={(r['rule'],r['label']):r for r in rows};start=time.perf_counter();count=0;comparisons=0;equal=0
for gr in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines()):
 for name in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(gr['rules']));p=build_ruleset_profile(c,EvaluationConfig());anchors={t.type_id for t in c.piece_types if t.is_anchor};gs=gr['rule'];a=mods[gs,'rule_static_v2']['checkpoint'];b=mods[gs,'rank_only']['checkpoint'];u=mods[gs,'unit']['checkpoint']
 for t in c.types_by_id:
  assert a['board_weights'][t]==p.board_value_by_type[t]/1000 and a['hand_weights'][t]==p.hand_value_by_base_type[t]/1000;assert u['board_weights'][t]==u['hand_weights'][t]==(0 if t in anchors else 1);assert b['hand_weights'][t]==a['hand_weights'][t];count+=1
  if t in anchors:assert b['board_weights'][t]==0
 for x,y in combinations(sorted(set(c.types_by_id)-anchors),2):
  aa=round(a['board_weights'][x]*256)-round(a['board_weights'][y]*256);bb=round(b['board_weights'][x]*256)-round(b['board_weights'][y]*256);assert(aa>0)-(aa<0)==(bb>0)-(bb<0);comparisons+=1
 for label in('rule_static_v2','rank_only','unit'):
  r=mods[gs,label];cp=LearnableMaterialCheckpoint.from_dict(r['checkpoint']);cp.validate_ruleset(c);assert cp.checkpoint_id==r['checkpoint_id']
 equal+=all(round(a['board_weights'][t]*256)==round(b['board_weights'][t]*256)for t in c.types_by_id)
write_json(D/'profile-reader-result.json',dict(status='PASS_RULE_ONLY_STATIC_AND_ORDINAL_CONTROL_INPUTS',rules=len(rows)//3,types=count,pairwise_Native_rank_checks=comparisons,unchanged_active_tables=equal,hands_exactly_equal=True,seconds=time.perf_counter()-start,scope='Recomputeexistingstaticprofile fromsavedfullrules, verifyalltypedcoefficients/checkpointids/fingerprints, Unitinputs, heldexacthandsandNativeboardweakordering. No generation/Nativequeries/fitness/training orindependentexternalruleauthority. Rankderivedfromcomputedstatic, notcheapreplacementfeatureconstruction.'))
print('ORDINAL_PROFILE_INPUT_PASS',count,comparisons,equal,time.perf_counter()-start)
