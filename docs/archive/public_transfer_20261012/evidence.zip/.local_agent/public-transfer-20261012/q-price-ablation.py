"""Q-only order-price ablation: leaf/main prices and algorithm are fixed."""
import sys,runpy,inspect,textwrap,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2]
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));p=m['p'];h=m['m'];sm=m['sm'];Runtime=m['Runtime'];record=m['record'];write=m['write'];out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
write(out/'declaration.json',dict(question='Does the weighted victim/actor capture-price q priority cause the transferred1090 work penalty?',root=int(sys.argv[2]),calls=4,orders=['weighted,unweighted','unweighted,weighted'],depth=2,seconds=60,nodes=1000000,q=4,hardq=8,pvs=True,qordering=True,tt='fresh default percall',scope='Both existing orderer on full public tuple with late quiet guard. Q-only capture_order_value returns0 for unweighted: capture category first, lexical within captures. Leaf and main move order retain original rule-derived evaluator. No new algorithm/adaptive selector/human-label tuning. Complete D2 values before comparing actual work. Fourcalls<=4minutes.'))
original=sm._quiescence_runtime;qorder=sm._order_qactions;old=Runtime.attach_stats;rows=[]
class Unweighted:
 def __init__(self,base):self.base=base
 def capture_order_value(self,mover,victim):return 0
 def __getattr__(self,name):return getattr(self.base,name)
for repeat,arms in enumerate([['weighted','unweighted'],['unweighted','weighted']]):
 for arm in arms:
  p.rr.stopped();probe=h['QuietActionProbe'](shadow=False);src=textwrap.dedent(inspect.getsource(original)).replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
  def order(state,actions,ply,ctx):
   if arm=='weighted':return qorder(state,actions,ply,ctx)
   proxy=SimpleNamespace(tuning=ctx.tuning,use_ordering=ctx.use_ordering,evaluator=Unweighted(ctx.evaluator),orderer=ctx.orderer,stats=ctx.stats)
   return qorder(state,actions,ply,proxy)
  namespace=dict(sm.__dict__,quiet_drop_probe=probe,_order_qactions=order);exec(compile(src,'<q-only-price-ablation>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];runtimes=[]
  def attach(rt,stats):
   value=old(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return value
  Runtime.attach_stats=attach
  try:
   ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native');player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=h['SearchTuning'](use_pvs=True,use_ordered_qsearch=True));t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=2,max_nodes=1000000,max_time_seconds=60,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
   for rt,before in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==before
   rows.append(dict(arm=arm,order=repeat,seconds=elapsed,decision=record(r),quiet=dict(probe.counts),root_restored=True));write(out/'result.json',dict(complete=False,rows=rows));print(sys.argv[2],repeat,arm,round(elapsed,3),r.completed_depth,r.score,r.qnodes,flush=True)
  finally:sm._quiescence_runtime=original;Runtime.attach_stats=old
write(out/'result.json',dict(complete=True,rows=rows))