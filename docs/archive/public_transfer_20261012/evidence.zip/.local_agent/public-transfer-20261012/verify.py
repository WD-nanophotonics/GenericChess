"""Independent finite result/legality audit, no new search or altered frozen output."""
import sys,runpy,json,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from generic_chess import compile_ruleset_for_execution,build_builtin_ruleset
from generic_chess.core.position import Position,Hands,GameState,HistoryRecord
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,BoardMove,DropMove
from generic_chess.core.coordinates import Square
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.rules.serialization import deserialize_ruleset
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.research_record import record_value,write_record
base=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_bytes());roots={}
for key in ['1090','1091']:
 sys.argv=['verify','unused',key,'fixed'];m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));roots[key]=(m['c'],m['s'].state)
from rule_semantics_ir_fixtures import uchifuzume_ruleset
from generic_chess.session.session import GameSession
c=compile_ruleset_for_execution(uchifuzume_ruleset());roots['s4']=(c,GameSession(c).state)
w=read(base/'s4-active-fixed/semantic-witness.json');c=compile_ruleset_for_execution(deserialize_ruleset(w['rules']));s=w['state'];pos=s['position'];pos=dict(pos,board=tuple(None if x is None else Piece(**x) for x in pos['board']),hands=tuple(Hands(tuple(tuple(row) for row in x['counts'])) for x in pos['hands']),aux_state=tuple((tuple(k),v) for k,v in pos['aux_state']))
roots['s4-active']=(c,GameState(position=Position(**pos),ply_count=s['ply_count'],repetition_counts=tuple(tuple(x) for x in s['repetition_counts']),terminal_status=TerminalResult(TerminalStatus(s['terminal_status']['status']),s['terminal_status']['winner']),history=tuple(HistoryRecord(**x) for x in s['history'])))
for ident in ['shogi-middle','shogi-drop']:
 c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));roots[ident]=(c,CoreBoard(next(x for x in CASES if x['id']==ident),c).initial)
def action(d):
 d=dict(d)
 for k in ('from_square','to_square'):
  if k in d:d[k]=Square(**d[k])
 cls=(SemanticBoardMove if 'from_square' in d else SemanticDropMove) if 'pattern_id'in d else BoardMove if 'from_square'in d else DropMove
 return cls(**d)
def audit_pv(root,r):
 c,state=roots[root];before=record_value(state);aa=tuple(legal_actions(state,c));assert action(r['action']) in aa
 for d in r['principal_variation']:
  a=action(d);assert a in legal_actions(state,c);state=apply_action(state,a,c)
 assert record_value(roots[root][1])==before
 return len(r['principal_variation'])
paths=[('1090-fixed',4,'1090'),('1090-delivery16',4,'1090'),('s4-fixed',4,'s4'),('s4-active-fixed',4,'s4-active'),('s4-active-shadow',4,'s4-active'),('1090-prefilter',4,'1090'),('1090-qprices',4,'1090'),('1091-qprices',4,'1091')];summary={};calls=0;pvsteps=0
for name,n,root in paths:
 r=read(base/name/'result.json');assert r['complete'] and len(r['rows'])==n
 for row in r['rows']:assert row['root_restored'];pvsteps+=audit_pv(root,row['decision'])
 if name!='1090-delivery16':
  ds=[row['decision'] for row in r['rows']];assert all((d['action'],d['score'],d['principal_variation'],d['nodes'])==(ds[0]['action'],ds[0]['score'],ds[0]['principal_variation'],ds[0]['nodes']) for d in ds)
 calls+=n;summary[name]=dict(rows=n,sha256=hashlib.sha256((base/name/'result.json').read_bytes()).hexdigest())
r=read(base/'hard-witness/result.json');assert r['complete'] and r['root_restored'] and r['trace_captured'];assert r['decision']['termination_reason']=='qsearch_check_hard_limit';pvsteps+=audit_pv('1091',r['decision']);assert read(base/'hard-witness/replay.json')['complete'];calls+=1
bridge=[]
for name,n in [('shogi-bridge',24),('shogi-bridge-q4-diagnosis',1),('shogi-bridge-resumed',35)]:
 r=read(base/name/'result.json');assert len(r['rows'])==n;assert r['complete']==(name!='shogi-bridge');bridge.extend(r['rows']);calls+=n
assert len(bridge)==60 and len({(x['case'],x['budget_seconds'],x['order'],x['arm']) for x in bridge})==60
for row in bridge:
 assert row['root_restored'] and row['actual_native_fallbacks']==0
 if row['arm'].startswith('public'):pvsteps+=audit_pv(row['case'],row['result'])
for name,n in [('shogi-native-q0',12),('shogi-neutral-fixed',8),('shogi-neutral-after',8),('shogi-native-q0-after',12),('shogi-tt-delivery',8),('shogi-root-window-delivery',24),('shogi-root-window-fixed',8)]:
 r=read(base/name/'result.json');assert r['complete'] and len(r['rows'])==n
 for row in r['rows']:assert row['root_restored'];pvsteps+=audit_pv(row['case'],row['result'])
 calls+=n;summary[name]=dict(rows=n,sha256=hashlib.sha256((base/name/'result.json').read_bytes()).hexdigest())
for name in ['shogi-neutral-fixed','shogi-neutral-after']:
 r=read(base/name/'result.json')
 for ident in ['shogi-middle','shogi-drop']:
  ds=[x['result'] for x in r['rows'] if x['case']==ident];expected=(ds[0]['score'],ds[0]['action'],ds[0]['principal_variation'],ds[0]['nodes'],ds[0]['dynamic_features']);assert all((d['score'],d['action'],d['principal_variation'],d['nodes'],d['dynamic_features'])==expected and d['completed_depth']==2 for d in ds)
r=read(base/'shogi-root-window-fixed/result.json');
for ident in ['shogi-middle','shogi-drop']:
 ds=[x['result'] for x in r['rows'] if x['case']==ident];assert all((d['score'],d['action'],d['principal_variation'])==(ds[0]['score'],ds[0]['action'],ds[0]['principal_variation']) and d['completed_depth']==2 for d in ds)
a=read(base/'shogi-neutral-fixed/result.json')['rows'];b=read(base/'shogi-neutral-after/result.json')['rows'];assert all((x['result']['action'],x['result']['score'],x['result']['principal_variation'],x['result']['nodes'],x['result']['dynamic_features'])==(y['result']['action'],y['result']['score'],y['result']['principal_variation'],y['result']['nodes'],y['result']['dynamic_features']) for x,y in zip(a,b))
r=read(base/'shogi-check-support/result.json');assert r['complete'] and len(r['rows'])==6
for row in r['rows']:assert row['root_restored'];pvsteps+=audit_pv('shogi-drop',row['decision'])
calls+=6
r=read(base/'shogi-choice-utility/result.json');assert r['complete'] and len(r['rows'])==12
for row in r['rows']:assert row['result']['completed_depth']==3;assert row['result']['score']==(700 if row['action']=='5i4i' else 900)
for label in ['5i4i','R*1g','R*1a']:
 ds=[x['result'] for x in r['rows'] if x['action']==label];assert all((x['score'],x['work'],x['trace_sha256'])==(ds[0]['score'],ds[0]['work'],ds[0]['trace_sha256']) for x in ds)
calls+=12
d4=[]
for name in ['shogi-choice-d4','shogi-choice-d4-core']:
 r=read(base/name/'result.json');assert r['complete'] and len(r['rows'])==6;d4.extend(r['rows']);calls+=6
for label in ['5i4i','R*1g','R*3b']:
 ds=[x['result'] for x in d4 if x['action']==label];assert all(x['completed_depth']==4 and (x['score'],x['work'],x['trace_sha256'])==(ds[0]['score'],ds[0]['work'],ds[0]['trace_sha256']) for x in ds);assert ds[0]['score']==(900 if label=='R*1g' else 500)
r=read(base/'shogi-probe-qualified/result.json');assert r['complete'] and len(r['rows'])==8 and all(x['legal'] for x in r['rows']);calls+=8
from generic_chess.core.actions import action_from_dict
from generic_chess.core.search_runtime import _runtime_position_identity
from generic_chess.ai.alphabeta.quiescence import noisy_child, enemy_board_count, material_inventory
w = read(base/'checking-scope-witness/witness.json')
c, state = roots['shogi-drop']
for entry in w['parent']['history'][len(state.history):]:
    a = action_from_dict(json.loads(entry['action_signature']))
    assert a in legal_actions(state,c)
    state = apply_action(state,a,c)
    assert record_value(_runtime_position_identity(state.position,c).position) == entry['identity']['position']
assert record_value(state.position) == w['parent']['position']
a = action(w['action']); assert a in legal_actions(state,c)
child = apply_action(state,a,c)
assert record_value(child.position) == w['child_position'] and not child.terminal_status.is_terminal
from generic_chess.core.semantic_executor import semantic_engine_for
check = lambda: semantic_engine_for(c).in_check(child.position,child.position.side_to_move)
args = (a,child,state.position.side_to_move,enemy_board_count(state.position,state.position.side_to_move),material_inventory(state.position),check)
assert noisy_child(*args,capture_only=False) and not noisy_child(*args,capture_only=True)
write_record(base/'checking-scope-witness/replay.json',dict(complete=True,parent_ply=state.ply_count,history_count=len(state.history),full_noisy=True,capture_only_noisy=False,nonterminal=True,actual_drop=record_value(a),scope='Independent full Core parent/action replay; inclusion difference only. Equal-context continuation value pending.'))
r = read(base/'checking-scope-witness/result.json'); assert r['complete']
calls += 1; pvsteps += audit_pv('shogi-drop',r['decision'])
summary.update(complete=True,primary_completed_search_calls=calls,unconfirmed_interrupted_search_attempts=1,pv_actions_independently_replayed=pvsteps,bridge='24 original+1 isolateddiagnosis+35resumed; original exit1 cause unknown, not uninterrupted samebatch',frozen_failures_preserved=True,science_complete=False)
write_record(base/'verification.json',summary);print({k:summary[k] for k in ('primary_completed_search_calls','pv_actions_independently_replayed','unconfirmed_interrupted_search_attempts')})