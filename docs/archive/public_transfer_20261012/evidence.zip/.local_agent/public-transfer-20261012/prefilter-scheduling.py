"""Single scheduling factor: same proved quiet exclusions before or after q ordering."""
import sys,runpy,inspect,textwrap,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));p=m['p'];h=m['m'];sm=m['sm'];Runtime=m['Runtime'];record=m['record'];write=m['write'];out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
write(out/'declaration.json',dict(question='Does early proved quiet exclusion reduce the observed public-ordering tax without changing retained q action order or exact D2 value?',root=int(sys.argv[2]),calls=4,orders=['late,early','early,late'],depth=2,seconds=60,nodes=1000000,q=4,hardq=8,pvs=True,qordering=True,tt='fresh default percall',scope='same Native leaf/legality/availability, full public tuple and Core quiet/history guards; exhaustive prefilter may cost more than late cutoff. Existing ordering on retained subset remains identical. No private API or default/UI change. Fourcalls<=4min; if fixed D2 incomplete retain rawcap and do not claim value equivalence.'))
original=sm._quiescence_runtime;old=Runtime.attach_stats;rows=[]
for repeat,arms in enumerate([['late','early'],['early','late']]):
 for arm in arms:
  p.rr.stopped();probe=h['QuietActionProbe'](shadow=False);src=textwrap.dedent(inspect.getsource(original))
  if arm=='early':
   src=src.replace('    ordered = _order_qactions(state, actions, ply, ctx)\n','')
   src=src.replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    retained = [action for action in actions if not quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory)]\n    ordered = _order_qactions(state,retained,ply,ctx)\n    for action in ordered:\n')
  else:src=src.replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
  namespace=dict(sm.__dict__,quiet_drop_probe=probe);exec(compile(src,'<public-q-exclusion-scheduling>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];runtimes=[]
  def attach(rt,stats):
   result=old(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return result
  Runtime.attach_stats=attach
  try:
   ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native');player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=h['SearchTuning'](use_pvs=True,use_ordered_qsearch=True));t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=2,max_nodes=1000000,max_time_seconds=60,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
   for rt,before in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==before
   rows.append(dict(arm=arm,order=repeat,seconds=elapsed,decision=record(r),quiet=dict(probe.counts),root_restored=True));write(out/'result.json',dict(complete=False,rows=rows));print(sys.argv[2],repeat,arm,round(elapsed,3),r.completed_depth,r.score,r.qnodes,r.ordering_seconds,flush=True)
  finally:sm._quiescence_runtime=original;Runtime.attach_stats=old
write(out/'result.json',dict(complete=True,rows=rows))