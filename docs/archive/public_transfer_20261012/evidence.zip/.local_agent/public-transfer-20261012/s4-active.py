"""Active S4 prohibition fixture: force actual hand drops and nested reply check."""
import sys,runpy
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from generic_chess.core.position import Hands,GameState,HistoryRecord
from generic_chess.core.pieces import Piece
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result,TerminalResult,TerminalStatus
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.actions import action_is_drop,action_target_square
from generic_chess.core.coordinates import Square
from generic_chess.rules.serialization import serialize_ruleset
from scripts.research_record import write_record,record_value
n=runpy.run_path(str(ROOT/'.local_agent/public-transfer-20261012/ordered-transfer.py'));m=n['m'];p=n['p'];ns=m['ns']
from rule_semantics_ir_fixtures import uchifuzume_ruleset
rules=uchifuzume_ruleset();c=m['m']['compile_ruleset_for_execution'](rules)
base=p.GameSession(c).state.position;board=[None]*64;board[5*8+6]=Piece(0,'K','K');board[6*8+6]=Piece(0,'P','P');board[7*8+7]=Piece(1,'K','K')
pos=replace(base,board=tuple(board),hands=(Hands((('P',1),)),Hands.empty()));key=position_identity_key(pos,c)
state=GameState(pos,0,((key,1),),TerminalResult(TerminalStatus.ONGOING),history=(HistoryRecord(key,-1,'',False),));state=replace(state,terminal_status=terminal_result(state,c));assert not state.terminal_status.is_terminal
s=SimpleNamespace(compiled=c,state=state,_search_witnesses=(pos,));m['c']=c;m['s']=s;m['profile']=p.build_ruleset_profile(c,m['ec'])
provider=m['m']['NativeSemanticLegalityProvider'].try_create(c,strict=True) if 'NativeSemanticLegalityProvider' in m['m'] else __import__('generic_chess.ai.alphabeta.native_legality',fromlist=['NativeSemanticLegalityProvider']).NativeSemanticLegalityProvider.try_create(c,strict=True)
rt=m['Runtime'].from_state(state,c,history_witnesses=(pos,),legal_binding_provider=provider);full=tuple(rt.legal_actions());engine=semantic_engine_for(c);oracle=tuple(__import__('generic_chess.core.semantic_executor',fromlist=['_semantic_public_action'])._semantic_public_action(engine,a) for a in engine.legal_actions(pos));assert set(full)==set(oracle)
packed=ns.pack_position(provider.native_rules,provider._state_only_payload(pos,0));raw=tuple(ns.public_action(provider.native_rules,a) for a in ns.candidate_actions(provider.native_rules,packed));target=next(a for a in raw if action_is_drop(a) and action_target_square(a)==Square(7,6));assert target not in full
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);write_record(out/'semantic-witness.json',dict(scope='Active forbidden pawn-drop mate and legal alternative hand drops; full fresh-root history, not original empty-hand S4 fixture',rules=serialize_ruleset(rules),state=record_value(state),witnesses=record_value((pos,)),candidate_count=len(raw),legal_count=len(full),forbidden_candidate=record_value(target),legal_drops=sum(action_is_drop(a) for a in full),core_native_equal=True,root_restored=True))
source=(ROOT/'.local_agent/public-transfer-20261012/ordered-transfer.py').read_text(encoding='utf-8');source=source[source.index('def run():'):source.index("if __name__=='__main__':")];source=source.replace('root=int(sys.argv[2])',"root='s4-active'").replace('predeclared1090 auxiliary-history root','predeclared active S4 pawn-drop-mate root').replace('new1090 paired consumer transfer','active S4 hand/drop nested-reply transfer').replace('One predeclared1090 mixed rule root with actual auxiliary history','One active S4 hand/drop prohibition position with fresh fully known history; original empty-hand fixture does not exercise drop prohibition')
n['m']=m;exec(compile(source,'<active-s4-transfer>','exec'),n);n['run']()