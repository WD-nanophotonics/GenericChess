"""Independent Core replay of the captured finite-check boundary witness."""
import sys,runpy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));p=m['p'];record=m['record'];write=m['write']
from generic_chess.core.actions import action_from_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
trace=json.loads((ROOT/'.local_agent/public-transfer-20261012/hard-witness/trace.json').read_bytes());root=m['s'].state;state=root;steps=[];seen={}
for i,entry in enumerate(trace['history'][len(root.history):],1):
 a=action_from_dict(json.loads(entry['action_signature']));assert a in legal_actions(state,m['c']);assert not state.terminal_status.is_terminal
 state=apply_action(state,a,m['c']);assert all(getattr(state.history[-1],k)==entry[k] for k in ('actor','action_signature','gave_check'));assert record(__import__('generic_chess.core.search_runtime',fromlist=['_runtime_position_identity'])._runtime_position_identity(state.position,m['c']).position)==entry['identity']['position']
 key=state.history[-1].position_key;seen[key]=seen.get(key,0)+1
 steps.append(dict(relative_ply=i,action=record(a),side_to_move=state.position.side_to_move,in_check=semantic_engine_for(m['c']).in_check(state.position,state.position.side_to_move),gave_check=entry['gave_check'],max_repetition=max(v for _,v in state.repetition_counts),terminal=record(state.terminal_status)))
assert record(state.position)==trace['position'];assert state.ply_count==trace['ply_count'];assert record(state.terminal_status)==trace['terminal'];assert len(steps)==trace['ply'] and trace['qdepth']==8 and steps[-1]['in_check'];assert not state.terminal_status.is_terminal
# Core replay carries its actual full history; no runtime reconstruction required.
# Full replay legality authority is independent of Native; no need to use rt's opaque imported history.
assert len(legal_actions(state,m['c']))==len(trace['actions'])
write(ROOT/'.local_agent/public-transfer-20261012/hard-witness/replay.json',dict(complete=True,root_history_count=len(root.history),full_history_count=len(state.history),steps=steps,final_legal_count=len(trace['actions']),value_scope='Unfinished D4 path reaches in-check q8 with legal evasions, no terminal/repetition draw. This is the declared finite-check hard boundary, not a demonstrated legality/restoration defect. Retained completed D3 score/action are not revised.',next='No cap extension from this trace. Need specific downstream consumer decision for a new bounded check policy.'))
print('replayed',len(steps),'evasions',len(trace['actions']),'maxrep',max(x['max_repetition'] for x in steps));print([(x['relative_ply'],x['in_check'],x['max_repetition']) for x in steps])