"""Shogi q checking-support attribution; different scope, not same-q speed gain."""
import sys,time,inspect,textwrap
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,Material
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.full_q_refresh_comparison import runtime_state
from scripts.quiet_action_probe import QuietActionProbe
from scripts.research_record import write_record,record_value
out=ROOT/'.local_agent/public-transfer-20261012/shogi-check-support';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does checking move/drop inclusion versus physical quiet transport explain the16s q4 support failure on the declared Shogi hand root?',root='shogi-drop',calls=6,arms=['raw','quiet','capture_only_quiet'],orders=['forward','reverse'],depth=2,nodes=8192,seconds=64,q=4,hardq=8,leaf='same frozen Material shogi, sameNativelegality/availability/PVS/orderedq/freshTT',scope='raw/quiet same qpolicy. capture_only_quiet is existing flag behavioral ablation: excludes checking move/drop continuation, so values/complete-depth are a different support condition, not equal-q speed or product recommendation. Finite8192-node cap is diagnostic, not old cap rescue; every actual retained policy/cap logged. Sixcalls<=384s plus bounded setup.'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));case=next(x for x in CASES if x['id']=='shogi-drop');rows=[];old=SearchPathRuntime.attach_stats;original=sm._quiescence_runtime
try:
 for repeat,arms in enumerate([['raw','quiet','capture_only_quiet'],['capture_only_quiet','quiet','raw']]):
  for arm in arms:
   probe=QuietActionProbe(shadow=False);src=textwrap.dedent(inspect.getsource(original))
   if arm!='raw':src=src.replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
   namespace=dict(sm.__dict__,quiet_drop_probe=probe);exec(compile(src,'<finite-Shogi-qscope-attribution>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];core=CoreBoard(case,c);runtimes=[]
   def attach(rt,stats):
    value=old(rt,stats);runtimes.append((rt,runtime_state(rt)));return value
   SearchPathRuntime.attach_stats=attach
   player=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=True,use_ordered_qsearch=True,use_capture_only_qsearch=arm=='capture_only_quiet'));t=time.perf_counter();r=player.choose_action(SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses),SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=64,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
   for rt,before in runtimes:rt.assert_balanced();assert runtime_state(rt)==before
   rows.append(dict(arm=arm,order=repeat,seconds=elapsed,decision=record_value(r),move=core.label(r.action),quiet=dict(probe.counts),root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(repeat,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,r.qnodes,r.result_ordinary_qdepth,r.termination_reason,flush=True)
   sm._quiescence_runtime=original;SearchPathRuntime.attach_stats=old
finally:sm._quiescence_runtime=original;SearchPathRuntime.attach_stats=old
write_record(out/'result.json',dict(complete=True,rows=rows))