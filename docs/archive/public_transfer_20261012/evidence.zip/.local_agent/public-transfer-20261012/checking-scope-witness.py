"""Capture an actual checking-drop scope witness, not a timing comparison."""
import sys,time,inspect,textwrap,json
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,Material
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.quiescence import noisy_child
from generic_chess.core.actions import action_is_drop
from generic_chess.ai.limits import SearchLimits
from scripts.quiet_action_probe import QuietActionProbe
from scripts.research_record import write_record,record_value
out=ROOT/'.local_agent/public-transfer-20261012/checking-scope-witness';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Which actually visited nonterminal checking drop is excluded by capture-only while retained by full generic q policy?',root='shogi-drop',calls=1,depth=2,nodes=8192,seconds=64,q=4,hardq=8,scope='One online semantic witness; same public Core material/PVS/orderedq/quietguard. One extra balanced shadowpush records full history/child/noisy predicates. Instrumented cost is not compared with old timings. No action substitution or cap extension. Follow-on independent branch valuation pending.'))
trace=[]
class Capture(QuietActionProbe):
 def exclude(self,ctx,a,engine,enemies,inventory):
  before=self.counts['retain_check'];result=super().exclude(ctx,a,engine,enemies,inventory)
  if not trace and action_is_drop(a) and self.counts['retain_check']>before:
   rt=ctx.runtime;parent=dict(position=record_value(rt.position),history=record_value(tuple(rt.history)),ply_count=rt.ply_count,terminal=record_value(rt.terminal_status));side=rt.position.side_to_move
   with rt.pushed(a,checkpoint=ctx.checkpoint):
    if not rt.terminal_status.is_terminal:
     full=noisy_child(a,rt.state,side,enemies,inventory,lambda:rt.in_check(1-side),capture_only=False)
     capture=noisy_child(a,rt.state,side,enemies,inventory,lambda:rt.in_check(1-side),capture_only=True)
     assert full and not capture
     row=dict(parent=parent,action=record_value(a),child_position=record_value(rt.position),child_terminal=record_value(rt.terminal_status),in_check=rt.in_check(1-side),full_noisy=full,capture_only_noisy=capture,material_before=Material('shogi').evaluate(SimpleNamespace(position=ctx.runtime._frames[-1].position)) if False else 'inventory unchanged by validated quiet predicate',follow_on='Replay actual parent fullhistory; compare this checking continuation under equal bounded parent q context before judging decision utility. This witness alone establishes inclusion difference, not gain.');trace.append(row);write_record(out/'witness.json',row)
  return result
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));core=CoreBoard(next(x for x in CASES if x['id']=='shogi-drop'),c);probe=Capture();original=sm._quiescence_runtime
src=textwrap.dedent(inspect.getsource(original)).replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n');namespace=dict(sm.__dict__,quiet_drop_probe=probe);exec(compile(src,'<actual-checking-scope-witness>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime']
try:
 player=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=True,use_ordered_qsearch=True));t=time.perf_counter();r=player.choose_action(SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses),SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=64,quiescence_max_depth=4,quiescence_hard_max_depth=8));assert trace;write_record(out/'result.json',dict(complete=True,seconds=time.perf_counter()-t,decision=record_value(r),witness_count=len(trace),scope='Instrumented online semantic witness, no timing-gain assertion'));print(r.completed_depth,r.termination_reason,'witness',len(trace))
finally:sm._quiescence_runtime=original