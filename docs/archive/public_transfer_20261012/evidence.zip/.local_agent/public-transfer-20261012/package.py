"""Agent-only evidence package; private transport/binaries/compiler paths excluded."""
import json,hashlib,zipfile,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest();members={}
for p in base.rglob('*.json'):
 if any(part in ('shogi-build','shogi-build-precomputed') for part in p.relative_to(base).parts):continue
 members[p.relative_to(ROOT).as_posix()]=p.read_bytes()
for p in base.glob('*.py'):members[p.relative_to(ROOT).as_posix()]=p.read_bytes()
for p in base.glob('*.log'):
 if p.name=='native-build-zero-fix.log':continue
 b=p.read_bytes()
 if str(ROOT).encode() in b:raise AssertionError('absolute local path in log')
 members[p.relative_to(ROOT).as_posix()]=b
for rel in ['.local_agent/cancel-contract-20261012/pvs-producer.py','.local_agent/cancel-contract-20261012/cancel-producer-v2.py','.local_agent/aux-quiet-20261012/filtered-transfer-producer.py','.local_agent/aux-quiet-20261012/transfer-producer.py','.local_agent/aux-quiet-20261012/active-mixed-premise.json','.local_agent/aux-quiet-20261012/mixed-premise.json','.local_agent/search-attribution-20261010/mature_controls.py']:
 members[rel]=(ROOT/rel).read_bytes()
rel='generic_chess/_native/native_module.c'
members['source-before/'+rel]=subprocess.run(['git','show','4f3aa32bb587a670b5560c881a685340d6136706:'+rel],cwd=ROOT,capture_output=True,check=True).stdout
for rel in ['generic_chess/_native/native_module.c','tests/product/test_native_evaluator_binding.py']:
 members['source-after/'+rel]=(ROOT/rel).read_bytes()
assert all(not any(x in name.lower() for x in ['slack','credential','.pyd','.exe','account']) for name in members)
archive=ROOT/'docs/archive/public_transfer_20261012/evidence.zip';archive.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,b in sorted(members.items()):z.writestr(name,b)
with zipfile.ZipFile(archive) as z:assert z.namelist()==sorted(members) and all(z.read(k)==v for k,v in members.items())
index=dict(schema=1,science_complete=False,source_base='4f3aa32bb587a670b5560c881a685340d6136706',session_id='c497b6a7-8b95-412b-8a33-23d06cecfd3e',archive='docs/archive/public_transfer_20261012/evidence.zip',archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,members={k:dict(bytes=len(v),sha256=sha(v)) for k,v in sorted(members.items())},verification=json.loads((base/'verification.json').read_bytes()),scope='212completed physical searches; one unknown interrupted attempt retained; source/result/declaration/failure and build hashes. No rawSlack/account/privateinput/binary/compiler-source dumps. Ordinaryconcurrentload and exploratory exposed roots. Not fullgenerateddomain/WDL/strength proof.')
(ROOT/'docs/research/data/public_transfer_20261012.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8');print('archive',len(members),archive.stat().st_size,index['archive_sha256'])