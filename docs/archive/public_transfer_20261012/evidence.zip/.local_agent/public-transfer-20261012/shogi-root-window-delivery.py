"""Actual existing C q0 entry under the same fixed material, not a q4 substitute."""
import sys,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
out=ROOT/'.local_agent/public-transfer-20261012/shogi-root-window-delivery';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='How much of restored Shogi cost remains in Python repeated scheduling versus existing supported whole-C q0 search?',roots=['shogi-middle','shogi-drop'],calls=24,budgets=[.25,1,16],root_window_arms=[False,True],orders=['middle,drop','drop,middle'],maxdepth=12,maxnodes=1000000,leaf='same arbitrary frozen Material board/hand VALUES, all dynamic0/evaluatorscale1',tt_MiB=0,root_window_pruning=False,learned_ordering=False,scope='Existing whole C engine supportsq0only; explicitq4request mustreject beforesearch. Whole-Cfullrootwindows/rootlexical/noTT differs current CorePVS/defaultTT. Primitive+algorithm effects bundled, not pure q4 speed ratio. Actual declarations/history/promotion/drop retained; no whole-domain/default/UI claim.Twentyfourcalls max138seconds. Current module declares semantic_exact_root_windows; use already-repaired public opt-in, no guard bypass or new algorithm. Both arms fresh1MiB TT; main leaf explicitzero is now corrected. Different mode search work/depth behavior intentionally measured, no q4 equivalence. Changed premise afterzero repair; fresh cold0/1MiB TT only. Rootwindows remain full, no learnedorder/PVS/q4. Record actual entrybytes/allocated/hits/cutoffs and retained values/depth, not equalnode-algorithm or same-machine-exclusive speed., freshengine percell.'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));nr=NativeSemanticLegalityProvider.try_create(c,strict=True).native_rules;rows=[]
for seconds in [.25,1,16]:
 for repeat,ids in enumerate([['shogi-middle','shogi-drop'],['shogi-drop','shogi-middle']]):
  for item in [(ident,tt) for ident in ids for tt in ([False,True] if repeat==0 else [True,False])]:
   ident,exact=item
   case=next(x for x in CASES if x['id']==ident);core=CoreBoard(case,c);session=SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')))
   engine=SemanticSearchEngine(c,nr,board_values=VALUES['shogi'],hand_values=VALUES['shogi'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1);before=record_value(core.initial)
   if not rows:
    try:engine.search(session,SearchLimits(max_depth=2,max_nodes=10000,max_time_seconds=1,quiescence_max_depth=4));raise AssertionError('q4 incorrectly accepted')
    except ValueError as exc:assert 'does not implement qsearch' in str(exc);write_record(out/'q4-decline.json',dict(exception=type(exc).__name__,message=str(exc),entry='public SemanticSearchEngine.search',scope='same actual compiled engine; no silent q4 downgrade or recursive execution claimed'))
   t=time.perf_counter();r=engine.search(session,SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=exact);elapsed=time.perf_counter()-t;assert record_value(core.initial)==before;assert r.declaration_id is None;assert r.action in {a for _,a in core.actions()}
   state=core.initial
   from generic_chess.core.movegen import legal_actions
   from generic_chess.core.transition import apply_action
   for a in r.principal_variation:assert a in legal_actions(state,c);state=apply_action(state,a,c)
   rows.append(dict(case=ident,root_window=exact,tt_MiB=1,budget_seconds=seconds,order=repeat,seconds=elapsed,result=record_value(r),move=core.label(r.action),root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(ident,exact,seconds,repeat,round(elapsed,3),r.completed_depth,r.score,r.nodes,r.termination_reason,flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))