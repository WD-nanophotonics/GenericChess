"""Missing single-factor cells; reuse completed raw/both controls."""
import sys,runpy,inspect,textwrap,time
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));p=m['p'];sm=m['sm'];Runtime=m['Runtime'];h=m['m'];write=m['write'];record=m['record'];out=Path(sys.argv[1])
kind=sys.argv[3]
def run():
 out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
 write(out/'declaration.json',dict(question='Can the existing q orderer transfer to the predeclared1090 auxiliary-history root without a new private legal interface? Unlike old1006/1008 lazy collection, this caller already owns a full public legal tuple, so ordering adds no extra S3 materialization tax.',root=int(sys.argv[2]),calls=4,arms=['quiet_lexical_pvs','quiet_ordered_pvs'],orders=['forward','reverse'],depth=(2 if kind=='fixed' else 12),nodes=1000000,seconds=(60 if kind=='fixed' else 64),q=4,hardq=8,tt='fresh default per call',reuse='No unchanged1091 rerun; new1090 paired consumer transfer',decision='Same full public tuple/Core quiet guard/Native evaluator+legality+availability/PVS/q4/hard8/freshTT/caps. Only existing use_ordered_qsearch flag changes; no new ordering algorithm. Complete fixed values/legality before cost and64s delivery. Actual work can differ; same-value ties/PV qualified. One predeclared1090 mixed rule root with actual auxiliary history; no default/UI/private API or cap extension. Ordinary concurrent load.',expected_max_seconds=(240 if kind=='fixed' else 256),expected_minutes='under5 for each declared phase; eight total calls fixed+delivery under9'))
 original=sm._quiescence_runtime;old=Runtime.attach_stats;rows=[]
 for repeat,arms in enumerate([['quiet_lexical_pvs','quiet_ordered_pvs'],['quiet_ordered_pvs','quiet_lexical_pvs']]):
  for arm in arms:
   p.rr.stopped();counts=Counter();m['legal'].__globals__['counts']=counts;m['Batch'].__iter__.__globals__['BATCH_SIZE']=8;probe=h['QuietActionProbe'](shadow=False)
   src=textwrap.dedent(inspect.getsource(original))
   if arm.startswith('legal'):src=src.replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)')
   else:src=src.replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
   namespace=dict(sm.__dict__,lazy_legal=m['legal'],lazy_order=m['order'],quiet_drop_probe=probe);exec(compile(src,'<single-factor-existing-q-control>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];rtrows=[]
   def attach(rt,stats):
    value=old(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return value
   Runtime.attach_stats=attach
   try:
    ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native');player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=h['SearchTuning'](use_pvs=True,use_ordered_qsearch=('ordered' in arm)));t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=(2 if kind=='fixed' else 12),max_nodes=1000000,max_time_seconds=(60 if kind=='fixed' else 64),quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
    for rt,before in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==before
    rows.append(dict(order=repeat,arm=arm,seconds=elapsed,decision=record(r),counts=dict(counts),quiet=dict(probe.counts),root_restored=True,actual_legality=dict(fallbacks=rtrows[0][0].legal_provider_fallbacks,failures=rtrows[0][0].legal_provider_operational_failures)))
    write(out/'result.json',dict(complete=False,rows=rows));print(repeat,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,r.qnodes,flush=True)
   finally:sm._quiescence_runtime=original;Runtime.attach_stats=old
 write(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run()
