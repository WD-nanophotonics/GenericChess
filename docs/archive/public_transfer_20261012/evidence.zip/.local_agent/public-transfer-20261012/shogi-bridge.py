"""Restored Shogi attribution bridge: common material, algorithm/q policy distinct."""
import sys,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,ShogiBoard,Material,iterative_minimal,audit_pair
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.full_q_refresh_comparison import runtime_state
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.research_record import write_record,record_value
out=ROOT/'.local_agent/public-transfer-20261012/shogi-bridge';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));methods=['minimal_core','minimal_native_core','minimal_cshogi','public_q0_pvs','public_q4_pvs']
write_record(out/'declaration.json',dict(question='With the actual mature9x9entry restored, which costs/support belong to rule execution versus current public scheduling/qpolicy?',roots=['shogi-middle','shogi-drop'],budgets=[.25,1,16],calls=60,methods=methods,order='forward thenreverse for eachbudget/root',leaf='common frozen arbitrary Material Shogi VALUES, shared with both minimal adapters, not mature classical leaf',native='explicit legality+availability for public; legalityonly minimal_native; actualfallbacks recorded',q='minimal q0 fixedlexical, publicq0/q4 uses existing PVS+orderedq; node definitions/TT/mainordering differ intentionally, not pure algorithm control',limits='1M eachcall, maxdepth12, hardq8; <=345seconds nominal total plus bounded setup/audit. Ordinaryconcurrentload, no exclusive timing claim',decision='report complete q depth/source/legal action/rootrestoration andactualwork; do not equate selective depths/nodes or choose winner by incomparable scores. NoUI/default/price fitting/holdout.'))
rows=[];old=SearchPathRuntime.attach_stats
try:
 for case in [x for x in CASES if x['id'] in ['shogi-middle','shogi-drop']]:
  audited=audit_pair(CoreBoard(case,c),ShogiBoard(case),1)
  for seconds in [.25,1,16]:
   for repeat,arms in enumerate([methods,list(reversed(methods))]):
    for arm in arms:
     flags=[__import__('json').loads((ROOT/'.local_agent'/(x+'.json')).read_bytes()) for x in ('rollout','advisor','slack')];assert not any(x.get('stopped') or x.get('user_paused') for x in flags)
     provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
     core=CoreBoard(case,c,provider=provider if arm=='minimal_native_core' else None);rt=core.runtime;before=runtime_state(rt);runtimes=[]
     if arm.startswith('minimal'):
      board=ShogiBoard(case) if arm=='minimal_cshogi' else core
      r=iterative_minimal(board,seconds=seconds,node_limit=1000000,max_depth=12);assert board.restored();scope='minimal fixed lexical q0; last fully completed whole-root iteration'
     else:
      def attach(runtime,stats):
       value=old(runtime,stats);runtimes.append((runtime,runtime_state(runtime)));return value
      SearchPathRuntime.attach_stats=attach
      player=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=True,use_ordered_qsearch=True));t=time.perf_counter();result=player.choose_action(SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses),SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=4 if arm=='public_q4_pvs' else 0,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t;r=record_value(result);r['measured_seconds']=elapsed;r['label']=None if result.action is None else core.label(result.action)
      for runtime,saved in runtimes:runtime.assert_balanced();assert runtime_state(runtime)==saved
      scope='actual public iterativePVS; q0 orq4 requested, retained result qpolicy recorded separately'
     rt.assert_balanced();assert runtime_state(rt)==before
     move=r.get('label',r.get('move'));assert move in {label for label,a in core.actions()}
     rows.append(dict(case=case['id'],arm=arm,budget_seconds=seconds,order=repeat,audited_states=audited,result=r,scope=scope,root_restored=True,actual_native_fallbacks=(rt.legal_provider_fallbacks if arm.startswith('minimal') else result.native_legality_fallbacks)));write_record(out/'result.json',dict(complete=False,rows=rows));print(case['id'],seconds,repeat,arm,r['completed_depth'],r['score'],r.get('result_ordinary_qdepth'),r.get('termination_reason',r.get('reason')),flush=True);SearchPathRuntime.attach_stats=old
finally:SearchPathRuntime.attach_stats=old
write_record(out/'result.json',dict(complete=True,rows=rows))