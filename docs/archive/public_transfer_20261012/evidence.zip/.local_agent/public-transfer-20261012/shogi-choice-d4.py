"""Defined shallow utility of actual Shogi delivered choices; no WDL claim."""
import sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,ShogiBoard,minimal_ab,Material
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.research_record import write_record
out=ROOT/'.local_agent/public-transfer-20261012/shogi-choice-d4';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does actual q4 budget-retained king choice differ from q0/capture-only rook drop under one defined common material D4 horizon including mature-reference action?',case='shogi-drop',actions=['5i4i','R*1g','R*3b'],calls=6,depth=4,q=0,seconds=60,nodes=1000000,adapters=['cshogi'],orders=['forward','reverse'],scope='Actual legal fullhistory root forced to one selected action, then same minimal alpha-beta fixedlexical fullwindow common Material. completed_depth is restrictedbranch only, not whole-root optimum. Exact matching adapter values before conditional regret; promotion/drop legality preserved. Arbitrary frozen Material coefficients, not human prices/WDL/Elo or proof excluded checks harmless. Maximum12minutes, usually under2.'))
class Forced:
 def __init__(self,board,label):self.board=board;self.label=label;self.depth=0
 def __getattr__(self,k):return getattr(self.board,k)
 def actions(self):
  aa=self.board.actions()
  if self.depth==0:
   aa=[(label,a) for label,a in aa if label==self.label];assert len(aa)==1
  return aa
 def push(self,a):self.board.push(a);self.depth+=1
 def pop(self):self.board.pop();self.depth-=1
 def restored(self):return self.depth==0 and self.board.restored()
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));case=next(x for x in CASES if x['id']=='shogi-drop');cells=[(a,b) for a in ['5i4i','R*1g','R*3b'] for b in ['cshogi']];rows=[]
for repeat,sequence in enumerate([cells,list(reversed(cells))]):
 for label,backend in sequence:
  board=CoreBoard(case,c,provider=NativeSemanticLegalityProvider.try_create(c,strict=True)) if backend=='native_legality_core' else ShogiBoard(case)
  result=minimal_ab(Forced(board,label),4,seconds=60,node_limit=1000000,trace=True,cooperative=True)
  rows.append(dict(action=label,backend=backend,order=repeat,result=result));write_record(out/'result.json',dict(complete=False,rows=rows));print(repeat,label,backend,result['reason'],result['score'],result['work']['nodes'],round(result['wall_seconds'],3),flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))