"""Active S4 full Core shadow verification of each proposed quiet exclusion."""
import sys,runpy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
source=(ROOT/'.local_agent/public-transfer-20261012/s4-active.py').read_text(encoding='utf-8')
source=source.replace("n['m']=m;exec(compile(source,'<active-s4-transfer>','exec'),n);n['run']()", "source=source.replace('shadow=False','shadow=True');n['m']=m;exec(compile(source,'<active-s4-shadow>','exec'),n);n['run']()")
exec(compile(source,'<same-S4-full-Core-shadow>','exec'))