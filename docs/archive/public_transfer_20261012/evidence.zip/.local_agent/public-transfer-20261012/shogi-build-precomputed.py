"""Owned full-board mature Shogi capability repair, isolated pinned clean source."""
import sys,json,zipfile,hashlib,re,subprocess,os,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
def stopped():
 for name in ('rollout','advisor','slack'):
  flags=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if flags.get('user_paused') or flags.get('stopped'):raise SystemExit('User stop retained')
out=ROOT/'.local_agent/public-transfer-20261012/shogi-build-precomputed';out.mkdir(exist_ok=True)
archive=ROOT/'.local_agent/mature-search/fairy-source.zip'
rev='9f778da667f6e07dae1e85d3e2ea204fc6dee94d'
with zipfile.ZipFile(archive) as z:z.extractall(out/'source')
src=out/'source'/('Fairy-Stockfish-'+rev)/'src'
assert 'GENERICCHESS_MATERIAL_DEVELOPMENT' not in (src/'evaluate.cpp').read_text(encoding='utf-8')
make=(src/'Makefile').read_text(encoding='utf-8');sources=re.search(r'SRCS = (.*?)\n\nOBJS',make,re.S).group(1).replace('\\\n',' ').split()
base=[sys.executable,'-m','ziglang','c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-fno-exceptions','-fno-strict-aliasing','-DNDEBUG','-DIS_64BIT','-DNNUE_EMBEDDING_OFF','-DLARGEBOARDS','-DALLVARS','-DPRECOMPUTED_MAGICS','-D__DATE__="Sep 22 2026"','-Wno-builtin-macro-redefined']
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(out/'global-cache'),ZIG_LOCAL_CACHE_DIR=str(out/'local-cache'))
write_record(out/'declaration.json',dict(question='Does the pinned supported LARGEBOARDS build supply the missing full9x9Shogi USI entry?',source_revision=rev,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),source='clean preserved official archive; no material hook',changes='Follow-on observed10s handshake timeout; source Makefile largeboards defaults PRECOMPUTED_MAGICS. Add that missing upstream flag; embeddingOFF and frozen bannerdate',expected='sequential28translationunits~5-15min, one owned compiler at a time, percommand90s hardstop1200s; no onehourrun',decision='actual advertised shogi then legal USI search before entry restored; default classical evaluator/pruning overallreference only'))
report=dict(complete=False,commands=[],base=base[3:],sources=sources);t=time.perf_counter()
try:
 for s in sources:
  stopped();obj=out/(s.replace('/','_')+'.o');r=subprocess.run(base+['-c',str(src/s),'-o',str(obj)],cwd=src,capture_output=True,text=True,timeout=90,env=env)
  report['commands'].append(dict(source=s,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));write_record(out/'result.json',report);print(s,r.returncode,round(time.perf_counter()-t,2),flush=True)
  if r.returncode:break
  if time.perf_counter()-t>1200:report['limit']='declared1200s interrupted';break
 else:
  binary=out/'fairy-largeboard.exe';r=subprocess.run(base+[str(out/(s.replace('/','_')+'.o')) for s in sources]+['-o',str(binary),'-lpthread','-ladvapi32','-Wl,--stack,8388608'],cwd=src,capture_output=True,text=True,timeout=90,env=env)
  report['link']=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
  if not r.returncode:report.update(complete=True,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
except Exception as e:report['failure']=dict(type=type(e).__name__,message=str(e));raise
finally:
 report['wall_seconds']=time.perf_counter()-t;write_record(out/'result.json',report)