"""First actual unchanged hard8 witness; no cap rescue or new search policy."""
import sys,runpy,inspect,textwrap,time,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));p=m['p'];sm=m['sm'];h=m['m'];record=m['record'];write=m['write'];out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
assert not(out/'declaration.json').exists()
write(out/'declaration.json',dict(question='What exact legal full-history path first reaches hard8 after ordered public tuple D3?',root=1091,calls=1,time_limit_seconds=256,maxdepth=12,nodes=1000000,q=4,hardq=8,tt='fresh default',policy='same public tuple quiet existing ordered PVS; firstevent capture only, no cap extension;256s bound lets observe existing abort rather than infer from old timing',decision='classify intended finitecheck boundary versus concrete semantic defect; retained result still only full completed iteration'))
probe=h['QuietActionProbe'](shadow=False);trace=[]
def witness(ctx,ply,qdepth):
 if trace:return
 rt=ctx.runtime
 value=dict(ply=ply,qdepth=qdepth,in_check=rt.in_check(rt.position.side_to_move),position=record(rt.position),history=record(tuple(rt.history)),ply_count=rt.ply_count,terminal=record(rt.terminal_status),actions=record(tuple(rt.legal_actions())),root_history=len(m['s'].state.history))
 trace.append(value);write(out/'trace.json',value)
original=sm._quiescence_runtime
src=textwrap.dedent(inspect.getsource(original)).replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n').replace('            raise SearchAborted("qsearch_check_hard_limit")','            capture_hard(ctx,ply,qdepth)\n            raise SearchAborted("qsearch_check_hard_limit")')
namespace=dict(sm.__dict__,quiet_drop_probe=probe,capture_hard=witness);exec(compile(src,'<hard8-first-witness>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];runtimes=[];old=m['Runtime'].attach_stats
try:
 def attach(rt,stats):
  value=old(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return value
 m['Runtime'].attach_stats=attach
 ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native');player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=h['SearchTuning'](use_pvs=True,use_ordered_qsearch=True));t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=256,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
 for rt,before in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==before
 write(out/'result.json',dict(complete=True,decision=record(r),seconds=elapsed,trace_captured=bool(trace),quiet=dict(probe.counts),root_restored=True));print(round(elapsed,3),r.completed_depth,r.score,r.termination_reason,bool(trace),flush=True)
finally:sm._quiescence_runtime=original;m['Runtime'].attach_stats=old