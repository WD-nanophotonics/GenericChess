"""Predeclared S4 transfer: public tuple, unchanged quiet guard, existing q flag."""
import sys,runpy
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2]
n=runpy.run_path(str(ROOT/'.local_agent/public-transfer-20261012/ordered-transfer.py'))
m=n['m'];p=n['p']
r=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/cancel-producer-v2.py'))
name,c,state,witnesses=next(x for x in r['roots']() if x[0]=='s4')
m['c']=c;m['s']=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses)
m['profile']=p.build_ruleset_profile(c,m['ec'])
source=(ROOT/'.local_agent/public-transfer-20261012/ordered-transfer.py').read_text(encoding='utf-8')
source=source[source.index('def run():'):source.index("if __name__=='__main__':")]
source=source.replace('root=int(sys.argv[2])',"root='s4'").replace('predeclared1090 auxiliary-history root','predeclared S4 pawn-drop-mate rule root').replace('new1090 paired consumer transfer','new S4 paired consumer transfer').replace('One predeclared1090 mixed rule root with actual auxiliary history','One predeclared S4 drop-mate rule with full history; this is semantic guard coverage, not full Shogi deployment')
n['m']=m
exec(compile(source,'<predeclared-s4-transfer>','exec'),n)
n['run']()