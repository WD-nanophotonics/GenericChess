"""Actual full9x9 Shogi USI entry; unaligned overall reference only."""
import ast,sys,json,hashlib,time,queue,subprocess,threading
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,ShogiBoard
from scripts.research_record import write_record
source=ROOT/'.local_agent/search-attribution-20261010/mature_controls.py'
node=next(n for n in ast.parse(source.read_text(encoding='utf-8')).body if isinstance(n,ast.ClassDef) and n.name=='Protocol')
ns=dict(queue=queue,subprocess=subprocess,threading=threading,perf_counter=time.perf_counter);exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns);Protocol=ns['Protocol']
out=ROOT/'.local_agent/public-transfer-20261012/shogi-probe';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
binary=ROOT/'.local_agent/public-transfer-20261012/shogi-build/fairy-largeboard.exe';sha=hashlib.sha256(binary.read_bytes()).hexdigest()
write_record(out/'declaration.json',dict(question='Does fresh pinned LARGEBOARDS build advertise and actually execute full9x9 Shogi?',calls=8,movetime_ms=250,threads=1,hash_MiB=16,source_revision='9f778da667f6e07dae1e85d3e2ea204fc6dee94d',binary_sha256=sha,scope='Four existing exposed Shogi fixtures, full replayed protocol history, PV legality in cshogi; classical default search/leaf/draw/declaration unaligned overallreference. No material-only or generic q4 speed/strength assertion. Engine close in finally.'))
rows=[];engine=None
try:
 engine=Protocol(binary,'usi');variant=next(x for x in engine.handshake if x.startswith('option name UCI_Variant '));assert ' shogi ' in variant+' '
 engine.send('setoption name UCI_Variant value shogi');engine.send('setoption name Threads value 1');engine.send('setoption name Hash value 16');engine.send('setoption name Use NNUE value false')
 for case in [x for x in CASES if x['game']=='shogi']:
  board=ShogiBoard(case);legal={label for label,_ in board.actions()}
  for repeat in range(2):
   engine.send('usinewgame');engine.send('isready');engine.until(lambda x:x=='readyok');command='position startpos' if case['setup']=='start' else 'position sfen '+case['setup']
   if case['moves']:command+=' moves '+case['moves']
   engine.send(command);t=time.perf_counter();engine.send('go movetime 250');lines=engine.until(lambda x:x.startswith('bestmove '));elapsed=time.perf_counter()-t;move=lines[-1].split()[1];assert move in legal
   infos=[]
   for line in lines:
    f=line.split()
    if f[:1]==['info'] and 'depth' in f:
     d={}
     for k in ['depth','seldepth','nodes','nps','time']:
      if k in f:d[k]=int(f[f.index(k)+1])
     if 'score' in f:i=f.index('score');d['score_type']=f[i+1];d['score']=int(f[i+2]);d['bound']='lowerbound' if 'lowerbound'in f else 'upperbound' if 'upperbound'in f else None
     if 'pv' in f:
      d['pv']=f[f.index('pv')+1:];b=board.board.copy()
      for u in d['pv']:
       a=b.move_from_usi(u);assert b.is_legal(a);b.push(a)
     infos.append(d)
   rows.append(dict(case=case['id'],repeat=repeat,move=move,legal=True,seconds=elapsed,info=infos,full_history=case['moves'].split()));write_record(out/'result.json',dict(complete=False,rows=rows));print(case['id'],repeat,move,round(elapsed,3),infos[-1] if infos else None,flush=True)
finally:
 if engine is not None:engine.close()
write_record(out/'result.json',dict(complete=True,rows=rows,handshake=engine.handshake,raw=engine.raw,binary_sha256=sha,cleanup='owned engine closed'))