from pathlib import Path
import sys,sysconfig,os,subprocess,importlib.util,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent;src=ROOT/'generic_chess/_native';mod=(src/'native_module.c').read_text()
start=mod.index('static int gc_semantic_generate_candidate_buffer(');end=mod.index('\nstatic ',start+1);part=mod[start:end].replace('gc_semantic_generate_candidate_buffer(', 'gc_test_generate_impl(',1)
helper=r"""
static GCSemanticRuntimeAudit gc_test_audit;
static int gc_test_audit_enabled=0;
static int gc_semantic_generate_candidate_buffer(const GCSemanticRules*r,const GCSemanticPosition*p,GCSemanticActionBuffer*b){
 int out=gc_test_generate_impl(r,p,b);if(gc_test_audit_enabled)gc_test_audit.candidate_count+=b->count;return out;
}
static PyObject*gc_test_audit_start(PyObject*self,PyObject*args){(void)self;(void)args;memset(&gc_test_audit,0,sizeof(gc_test_audit));gc_test_audit_enabled=1;gc_semantic_runtime_audit_start(&gc_test_audit);Py_RETURN_NONE;}
static PyObject*gc_test_audit_read(PyObject*self,PyObject*args){(void)self;(void)args;gc_semantic_runtime_audit_stop();gc_test_audit_enabled=0;
 return Py_BuildValue("{s:K,s:K,s:K,s:K,s:K,s:K,s:K}","candidate_count",gc_test_audit.candidate_count,"s3_trials",gc_test_audit.s3_trial_count,"s4",gc_test_audit.s4_count,"nested",gc_test_audit.nested_reply_count,"child_keys",gc_test_audit.child_canonical_key_computations,"history_appends",gc_test_audit.history_appends,"attack_checks",gc_test_audit.attack_check_calls);
}
"""
mod=mod[:start]+part+helper+mod[end:];needle='    {"semantic_make_checked", gc_semantic_make_checked, METH_VARARGS,';mod=mod.replace(needle,'    {"test_audit_start",gc_test_audit_start,METH_NOARGS,"Private counters"},\n    {"test_audit_read",gc_test_audit_read,METH_NOARGS,"Private counters"},\n'+needle);(OUT/'shogi-counter-native_module.c').write_text(mod)
spec=importlib.util.find_spec('ziglang');zig=Path(spec.origin).parent/'zig.exe';binary=OUT/('shogi_counter_kernel/_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));binary.parent.mkdir(exist_ok=True)
cmd=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(OUT/'shogi-counter-native_module.c' if x.name=='native_module.c' else x) for x in sorted(src.glob('*.c'))]+['-o',str(binary)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(OUT/'counter-zig-cache')));assert built.returncode==0,built.stderr
spec=importlib.util.spec_from_file_location('counter_test._native_core',binary);kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
import generic_chess.native as native
native._MODULE=kernel
exec((OUT/'shogi-replay.py').read_text().split('rows=[];tables=[]')[0],globals())
from generic_chess.native.semantic import candidate_actions,guarded_actions,make_checked
class Candidate(Packed):
 def __init__(self,core,cache=False):super().__init__(core,VALUES['shogi']);self.cache={} if cache else None;self.attempts=0;self.rejects=0;self.labels=0;self.label_hits=0
 def actions(self):
  for raw in sorted(candidate_actions(self.native,self.position)):
   self.attempts+=1
   try:child=make_checked(self.native,self.position,raw)
   except ValueError:self.rejects+=1;continue
   if self.cache is not None and raw in self.cache:label=self.cache[raw];self.label_hits+=1
   else:
    label=self.label(public_action(self.native,raw));self.labels+=1
    if self.cache is not None:self.cache[raw]=label
   yield label,(raw,child)
 def push(self,pair):self.stack.append(pair[1])
rows=[]
for case in [c for c in CASES if c['game']=='shogi']:
 core=CoreBoard(case,compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi')))
 for arm in ('native_guarded','native_lazy','native_lazy_cached_label','c_fixed'):
  b=Packed(core,VALUES['shogi']) if arm=='native_guarded' or arm=='c_fixed' else Candidate(core,cache=arm.endswith('cached_label'));kernel.test_audit_start()
  if arm=='c_fixed':r=fixed_depth_search(b.native,b.position,3,board_values=b.values,hand_values=b.values)
  else:r=minimal_ab(b,3,seconds=60,node_limit=1000000)
  counts=kernel.test_audit_read();rows.append(dict(case=case['id'],arm=arm,result=r,counters=counts,adapter={k:getattr(b,k,None) for k in ('attempts','rejects','labels','label_hits')}));(OUT/'shogi-execution-counters.json').write_text(json.dumps(rows,indent=2)+'\n');print(case['id'],arm,counts,flush=True)
