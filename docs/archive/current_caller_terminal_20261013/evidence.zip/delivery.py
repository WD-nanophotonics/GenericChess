"""Current supported caller resource plane, not a matched search algorithm."""
import sys,json,time,hashlib
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,VALUES,CoreBoard,ChessBoard,ShogiBoard,Material,iterative_minimal,audit_pair
from scripts.research_record import write_record,record_value
from generic_chess import compile_ruleset_for_execution,build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
import generic_chess.native as native
out=ROOT/'.local_agent/core-consumer-20261013/delivery-corrected';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
chosen=['chess-middle','chess-ep','shogi-middle','shogi-drop'];budgets=[4,16,64]
write_record(out/'declaration.json',dict(question='After distinguishing Core readonly trial costs from the guarded bridge, which actual supported caller delivers a completed material-only continuation under the same time/node conditions?',cases=chosen,budgets=budgets,arms=['CoreNative','NativeCurrent','SpecialMinimal'],orders=[0,1],max_depth=7,node_cap=1000000,q=0,calls=72,cost='Maximum2016 searchseconds plus setup; one bounded batch underonehour; no extension.',scope='Full replay history/aux/promotion/drop/declarations retained by supported callers. Frozenmaterial vector same leaf, Native ordering uses existing ruleprofile/min2/uncached and1MiBTT, Core uses250kTT/material ordering/noPVS/noRootTactical/Native legality+availability; specialized minimal lexical noTT. Algorithm/order/eval mateunits differ explicitly; overall delivery comparison, NOT matched speed ratio or Elo. Root audit reused fixtures but freshly verified. Ordinary concurrent load, constructors outside deadline, caller/kernel overshoot measured. No default/UI changes. All cases kept even failed/incomplete; common completed depths are comparisons not full exactWDL.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),native_sha256=hashlib.sha256(Path(native._module().__file__).read_bytes()).hexdigest()))
compiled={g:compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if g=='chess' else 'standard_shogi')) for g in ['chess','shogi']}
previous=json.loads((ROOT/'.local_agent/core-consumer-20261013/delivery/result.json').read_bytes());rows=[r for r in previous['rows'] if 'error' not in r];inputs=[]
for case in CASES:
 if case['id'] not in chosen:continue
 c=compiled[case['game']];base=CoreBoard(case,c);special=ChessBoard(case) if case['game']=='chess' else ShogiBoard(case);audited=audit_pair(base,special,1)
 s=SimpleNamespace(compiled=c,state=base.initial,_search_witnesses=base.witnesses,result=SimpleNamespace(status=SimpleNamespace(value=base.initial.terminal_status.status.value)))
 before=record_value(s.state);inputs.append(dict(case=case,root=before,witnesses=record_value(base.witnesses),audited_states=audited));write_record(out/'inputs.json',inputs)
 nr=compile_native_semantic_rules(c);ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
 for sec in budgets:
  for order,arms in enumerate([['CoreNative','NativeCurrent','SpecialMinimal'],['SpecialMinimal','NativeCurrent','CoreNative']]):
   for arm in arms:
    if any(r['case']==case['id'] and r['arm']==arm and r['budget_seconds']==sec and r['order']==order for r in rows):continue
    for flag in ['rollout','advisor','slack']:
     f=json.loads((ROOT/'.local_agent'/(flag+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused')
    limits=SearchLimits(max_depth=7,max_nodes=1000000,max_time_seconds=sec,quiescence_max_depth=0,quiescence_hard_max_depth=0)
    if arm=='CoreNative':engine=AlphaBetaPlayer(c,evaluator_override=Material(case['game']),use_disk_cache=False,use_native_semantic_legality=True,use_native_semantic_availability=True,tuning=SearchTuning(use_pvs=False,use_root_tactical=False))
    if arm=='NativeCurrent':engine=SemanticSearchEngine(c,nr,board_values=VALUES[case['game']],hand_values=VALUES[case['game']],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2,ordering_cache_enabled=False)
    started=time.perf_counter()
    try:
     if arm=='SpecialMinimal':
      result=iterative_minimal(special,seconds=sec,node_limit=1000000,max_depth=7);restored=special.restored();pv_ok=None
     else:
      value=engine.choose_action(s,limits) if arm=='CoreNative' else engine.search(s,limits,root_window_pruning=True)
      result=record_value(value);restored=record_value(s.state)==before;state=s.state
      for action in value.principal_variation:
       assert action in legal_actions(state,c);state=apply_action(state,action,c)
      pv_ok=True;assert value.action in legal_actions(s.state,c)
      if arm=='CoreNative':result['provider_created']=engine.native_legality_provider is not None;result['availability_metrics']=engine.native_legality_provider.availability_metrics
      assert value.termination_reason!='internal_error'
     assert restored
     row=dict(case=case['id'],arm=arm,budget_seconds=sec,order=order,caller_seconds=time.perf_counter()-started,result=result,pv_legal=pv_ok,root_restored=restored)
    except Exception as exc:
     row=dict(case=case['id'],arm=arm,budget_seconds=sec,order=order,error=repr(exc),caller_seconds=time.perf_counter()-started)
     rows.append(row);write_record(out/'result.json',dict(complete=False,rows=rows));raise
    rows.append(row);write_record(out/'result.json',dict(complete=False,rows=rows));print(case['id'],sec,order,arm,round(row['caller_seconds'],3),result.get('completed_depth'),result.get('score'),flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
