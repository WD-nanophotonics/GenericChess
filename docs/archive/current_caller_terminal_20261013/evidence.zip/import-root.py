import sys,sysconfig,importlib.util,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent
from dataclasses import replace
from generic_chess import compile_ruleset_for_execution,build_builtin_ruleset
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native.semantic import pack_position,terminal_status,snapshot
from scripts.research_record import write_record
import generic_chess.native as native
write_record(OUT/'import-root-declaration.json',dict(question='Can knowncheckedchild reuse misidentify arbitrary raw imported root histories?',scope='C raw import boundary control, not a claimed legally replayed game. Fourforeign identical SHA256 words differ from currentboard canonicaldigest. Root must remainONGOING ratherthan trustlastimported key. Childfullmakes createowncanonicaldigest. Also incomplete2word rejection kept.',arms=['threshold','reuse'],depth=2))
rows=[]
for arm in ['threshold','reuse']:
 p=OUT/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location(arm+'_root._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m
 c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),repetition_limit=4));provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
 from generic_chess.session.session import GameSession
 ss=GameSession(c);payload=provider._state_only_payload(ss.state.position,3);payload['history']=[(1,2,3,4,255,0),(1,2,3,4,0,0),(1,2,3,4,1,0),(1,2,3,4,0,0)]
 nr=provider.native_rules;position=pack_position(nr,payload);before=snapshot(nr,position);term=terminal_status(nr,position);assert term['status']=='ongoing'
 e=SemanticSearchEngine(c,nr,tt_megabytes=0);r=dict(m.semantic_engine_search(e._capsule,position,2,100000,8,None,None,True,False));assert r['completed_depth']==2 and r['nodes']>1 and r['best_action'] is not None;assert snapshot(nr,position)==before
 cleaned={k:v for k,v in r.items() if 'elapsed' not in k and 'nanoseconds' not in k and 'hit_rate' not in k}
 rows.append(dict(arm=arm,result=cleaned,terminal=term,parent_restored=True))
 payload['history']=[(1,2)]*4;bad=pack_position(nr,payload)
 try:m.semantic_engine_search(e._capsule,bad,2,100000,8,None,None,True,False)
 except ValueError as exc:assert 'exact full history' in str(exc)
 else:raise AssertionError('incomplete importedhistory accepted')
assert rows[0]['result']==rows[1]['result'];write_record(OUT/'import-root-result.json',dict(rows=rows,root_current_key_not_in_history=True,incomplete_imports_rejected=True))
print('raw root controls matched',rows[0]['result']['nodes'])
