from pathlib import Path
import sys,json,time,random,hashlib,importlib.util,traceback
R=Path.cwd();P=R/'.local_agent/api-ready-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,generate_game,GeneratorConfig,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import serialize_ruleset,deserialize_ruleset
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import position_identity_key
plan=json.loads((P/'plan.json').read_bytes());spec=importlib.util.spec_from_file_location('readybase._native_core',P/'base_native_core.pyd');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
modules={'base_af4a':base,'final_1bc6':None};start=time.perf_counter();rootdir=P/'roots';rootdir.mkdir(exist_ok=False);rows=[];roots=[];slots=0;edges=0;states=0

def stopped():
 for n in('rollout','advisor','slack'):
  d=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('user_paused')or d.get('stopped'):raise RuntimeError('USER_STOP')

def setup(d,arm,profile,checkpoint=lambda p:None):
 phases={};t=time.perf_counter();rules=deserialize_ruleset(json.dumps(d['ruleset']));phases['deserialize']=time.perf_counter()-t;checkpoint('deserialize')
 t=time.perf_counter();x=compile_legacy_ruleset_for_semantic_execution(rules);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);phases['python_compile']=time.perf_counter()-t;checkpoint('python_compile')
 t=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));phases['session_replay']=time.perf_counter()-t;checkpoint('session_replay')
 t=time.perf_counter();v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()};phases['rule_price']=time.perf_counter()-t;checkpoint('rule_price')
 t=time.perf_counter();nr=compile_native_semantic_rules(c,**({}if arm=='final_1bc6'else dict(backend_module=base)));phases['native_compile']=time.perf_counter()-t;checkpoint('native_compile')
 t=time.perf_counter();e=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,dynamic_values=(2,3,5)if profile=='dynamic235'else None,tt_megabytes=0,ordering_cache_enabled=False);phases['engine']=time.perf_counter()-t;checkpoint('engine')
 return c,s,nr,e,phases

def validate(c,s,nr,result):
 global edges,states
 state=s.state;pos=pack_semantic_search_position(c,nr,s);w=list(s._search_witnesses);backend=modules[currentarm]
 for a in result.principal_variation:
  pos=sem.make_checked(nr,pos,pack_semantic_action(nr,state.position,a));state=apply_action(state,a,c);w.append(state.position);snap=sem.snapshot(nr,pos);expected=expected_snapshot(state.position,nr,c)
  for k in('board','hands','aux_state','side'):assert record_value(snap[k])==record_value(expected[k])
  assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(v,c))for v in w]
  assert tuple(snap['history_events'])==tuple((255 if h.actor<0 else h.actor,bool(h.gave_check))for h in state.history)
  edges+=1;states+=1
 if not result.principal_variation and result.action is not None:
  child=apply_action(s.state,result.action,c);states+=1
 return True

with(P/'queries.jsonl').open('x',encoding='utf-8')as log:
 for idx,case in enumerate(plan['cases']):
  stopped();t=time.perf_counter();root=dict(**case)
  try:
   if t-start>=plan['whole_seconds']:root['kind']='WHOLE_CAP_NOT_STARTED_UNKNOWN';roots.append(root);continue
   g=generate_game(GeneratorConfig(seed=case['seed'],board_size=case['board'],setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));x=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c);rng=random.Random(case['seed']+700000)
   for j in range(8):
    stopped()
    if s.state.terminal_status.is_terminal:break
    aa=sorted(s.legal_actions(),key=repr)
    if not aa:break
    s.submit(rng.choice(aa))
   d=dict(**case,ruleset=json.loads(serialize_ruleset(g.ruleset)),game_record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state));write_record(rootdir/f"{case['seed']}.json",d);root.update(actual_ply=s.state.ply_count,terminal=record_value(s.state.terminal_status),acquisition_seconds=time.perf_counter()-t,state_sha256=hashlib.sha256(json.dumps(d['state'],sort_keys=True).encode()).hexdigest())
   if s.state.terminal_status.is_terminal or s.state.ply_count<8:root['kind']='ACTUAL_TERMINAL_TAIL';roots.append(root);print('TAIL',case,flush=True);continue
   warm={}
   for profile in plan['profiles']:
    for arm in plan['arms']:
     stopped();t=time.perf_counter();warm[arm,profile]=setup(d,arm,profile);root.setdefault('warm_setup',[]).append(dict(arm=arm,profile=profile,seconds=time.perf_counter()-t,phases=warm[arm,profile][-1]))
   root['kind']='EXECUTED_ROOT';roots.append(root);write_record(P/'roots-progress.json',dict(complete=False,rows=roots))
   for mi,mode in enumerate(plan['modes']):
    for bi,budget in enumerate(plan['budgets']):
     for pi,profile in enumerate(plan['profiles']):
      for rep in range(2):
       arms=plan['arms']if(idx+mi+bi+pi+rep)%2==0 else list(reversed(plan['arms']))
       for arm in arms:
        stopped();slots+=1;currentarm=arm;z=dict(**case,mode=mode,budget=budget,profile=profile,rep=rep,arm=arm,slot=slots)
        if time.perf_counter()-start>=plan['whole_seconds']:z['kind']='WHOLE_CAP_NOT_STARTED_UNKNOWN';rows.append(z);log.write(json.dumps(z)+'\n');log.flush();continue
        tq=time.perf_counter();phase={};res=None;expired=None
        def checkpoint(p):
         if time.perf_counter()-tq>=budget:raise TimeoutError(p)
        try:
         if mode=='cold':cc,ss,nr,e,phase=setup(d,arm,profile,checkpoint)
         else:cc,ss,nr,e,_=warm[arm,profile]
         before=record_value(ss.state);remaining=budget-(time.perf_counter()-tq)
         if remaining<=0:raise TimeoutError('engine')
         ts=time.perf_counter();res=e.search(ss,SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=remaining,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);phase['search_api']=time.perf_counter()-ts
         ts=time.perf_counter();out=record_value(res);serialized=json.dumps(out,separators=(',',':'));phase['serialization']=time.perf_counter()-ts;ready=time.perf_counter()-tq;assert record_value(ss.state)==before
         z.update(kind='ACTUAL_QUERY',allocated_search_seconds=remaining,result=out,serialized_result_bytes=len(serialized.encode()),caller_ready_seconds=ready,overrun_seconds=max(0,ready-budget),eligible=ready<=budget,root_restored=True,phases=phase)
         tv=time.perf_counter();z['full_history_checked']=validate(cc,ss,nr,res);z['diagnostic_seconds']=time.perf_counter()-tv
        except TimeoutError as exc:z.update(kind='ADMISSION_EXPIRED',expired_phase=str(exc),caller_ready_seconds=time.perf_counter()-tq,eligible=False,phases=phase)
        except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc(),eligible=False,phases=phase)
        rows.append(z);log.write(json.dumps(z)+'\n');log.flush()
       print('PAIR',case['seed'],mode,budget,profile,rep,'slots',slots,'seconds',round(time.perf_counter()-start,2),flush=True)
  except Exception as exc:root.update(kind='ACTUAL_ROOT_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc());roots.append(root);print('ROOT_FAILURE',case,root['error'],flush=True)
  write_record(P/'roots-progress.json',dict(complete=False,rows=roots))
write_record(P/'results.json',dict(complete=True,roots=roots,rows=rows,planned_slots=768,actual_slots=len(rows),full_history_edges=edges,full_history_states=states,seconds=time.perf_counter()-start,scope=plan['scope']));print('DONE',len(rows),edges,time.perf_counter()-start,flush=True)
