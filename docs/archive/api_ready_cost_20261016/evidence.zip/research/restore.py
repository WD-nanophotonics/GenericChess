from pathlib import Path
import sys,json,zipfile,hashlib,subprocess,sysconfig,time,uuid,os
R=Path.cwd();P=R/'.local_agent/api-ready-20261016';D=R/'docs/archive/api_ready_cost_20261016';m=json.loads((D/'manifest.json').read_bytes());start=time.perf_counter();out=P/('restored-'+uuid.uuid4().hex[:8]);out.mkdir();assert hashlib.sha256((D/'evidence.zip').read_bytes()).hexdigest()==m['archive_sha256']
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert z.testzip()is None
 for row in m['members']:
  b=z.read(row['path']);assert hashlib.sha256(b).hexdigest()==row['sha256'];f=out/row['path'];assert f.resolve().is_relative_to(out.resolve());f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
dep=m['source_dependency'];base=R/dep['archive'];assert hashlib.sha256(base.read_bytes()).hexdigest()==dep['sha256']
source_count=0
with zipfile.ZipFile(base)as z:
 assert z.testzip()is None
 for name in z.namelist():
  if not name.startswith('source/'):continue
  f=out/name;assert f.resolve().is_relative_to(out.resolve());f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(z.read(name));source_count+=1
assert source_count==dep['source_files'];source=out/'source'
for f in(out/'source-tests').rglob('*'):
 if f.is_file():dest=source/f.relative_to(out/'source-tests');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
src=source/'generic_chess/_native';module=source/'generic_chess'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));assert hashlib.sha256((src/'native_module.c').read_bytes()).hexdigest()==dep['module_sha256'];cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(src.glob('*.c'))],'-o',str(module)];r=subprocess.run(cmd,capture_output=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(P/'source-zig-cache')));(P/'source-build-private.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr[-1500:]
r=subprocess.run([sys.executable,'-S',str(out/'research/consumer.py'),str(out/'research')],cwd=source,capture_output=True,timeout=300);(P/'source-consumer-private.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout[-1500:],r.stderr[-2500:]);reader=json.loads((out/'research/consumer-result.json').read_bytes());assert reader['complete']
r=subprocess.run([sys.executable,'-X','utf8','-m','pytest','tests/development/test_research_record.py','-p','no:cacheprovider','--basetemp',str(P/('source-pytest-'+uuid.uuid4().hex[:8]))],cwd=source,capture_output=True,timeout=120);(P/'source-tests-private.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(r.stdout[-1500:],r.stderr[-1500:]);x=dict(complete=True,source_files=source_count,source_dependency_sha256=dep['sha256'],module_sha256=dep['module_sha256'],new_capsule_members=m['member_count'],new_capsule_sha256=m['archive_sha256'],normal_native_rebuilt=True,module_origin_asserted=True,search_disabled=True,actual_reader=reader,actual_source_tests_stdout=r.stdout.decode(errors='replace'),seconds=time.perf_counter()-start,scope='Actualfresh complete-source rebuild/new data source-bound replay+record tests. SharedCore/compiler/host; no query replay/modeltraining or authentication of oldclocks/independent minimax/WDL. Source readonly, no privatebinary imported.')
for f in(P/'source-restoration.json',D/'publication-restoration.json'):f.write_text(json.dumps(x,indent=2)+'\n');print('SOURCE_RESTORATION_PASS',reader['counts'],x['seconds'],x['actual_source_tests_stdout'][-800:])
