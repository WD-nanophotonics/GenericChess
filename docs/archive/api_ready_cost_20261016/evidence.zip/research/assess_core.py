from pathlib import Path
import sys,json
R=Path.cwd();P=R/'.local_agent/api-ready-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,GameSession
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.evaluation.config import MATE_SCORE
raw=json.loads((P/'core-results.json').read_bytes());fixed=json.loads((P/'fixedD4-results.json').read_bytes());rows=[]
for x in raw['rows']:
 if x.get('joint_score_equal')is not False:continue
 d=json.loads((P/'roots'/f"{x['seed']}.json").read_bytes());a=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=a.ir,_legacy_compiled=a._legacy_compiled,support=a.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));actor=s.state.position.side_to_move;ac=next(a for a in s.legal_actions()if record_value(a)==x['result']['action']);s.submit(ac);ns=[y for y in fixed['rows']if y['seed']==x['seed']and y['profile']==x['profile']and y['result']['completed_depth']==4];assert s.state.terminal_status.is_terminal and s.state.terminal_status.winner==actor;assert len(x['result']['principal_variation'])==1;assert x['result']['score']==MATE_SCORE-1
 for y in ns:assert y['result']['action']==x['result']['action']and len(y['result']['principal_variation'])==1 and y['result']['score']==100000000-1
 rows.append(dict(seed=x['seed'],profile=x['profile'],raw_core_score=x['result']['score'],raw_native_scores=sorted({y['result']['score']for y in ns}),same_actual_chosen_action=True,core_mate_base=MATE_SCORE,native_mate_base=100000000,relative_terminal_distance=1,actual_child_terminal=record_value(s.state.terminal_status),actual_winner=actor,matched_native_receipts=len(ns)))
out=dict(complete=True,core_queries=len(raw['rows']),raw_nonmate_score_matches=sum(x.get('joint_score_equal')is True for x in raw['rows']),raw_score_mismatches_preserved=len(rows),diagnosed_mate_convention_controls=rows,scope='Raw two differences remain in original receipts: Core1B versus Native100M mate base, actual same one-edge terminal WIN/distance1. No raw-score equality claim, score rescaling/default/API change or query rerun. Eight observations/fourfamilies, no generalWDL/equivalence claim.')
(P/'core-score-assessment.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
