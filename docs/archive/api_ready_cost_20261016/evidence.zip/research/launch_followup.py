from pathlib import Path
import subprocess,sys,json,time,datetime
P=Path('.local_agent/api-ready-20261016');name=sys.argv[1];plan=json.loads((P/'followup-plan.json').read_bytes());sub=next(x for x in plan['subpanels']if x['name']==name);receipt=P/(name+'-execution-private.json');assert not receipt.exists();start=time.perf_counter();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 r=subprocess.run([sys.executable,'-X','utf8',str(P/'followup.py'),name],capture_output=True,timeout=sub['whole_seconds']+150);x=dict(returncode=r.returncode,stdout=r.stdout.decode(errors='replace'),stderr=r.stderr.decode(errors='replace'),timed_out=False)
except subprocess.TimeoutExpired as e:x=dict(returncode=124,stdout=(e.stdout or b'').decode(errors='replace'),stderr=(e.stderr or b'').decode(errors='replace'),timed_out=True)
x.update(started_at=utc,outer_seconds=time.perf_counter()-start,scope='Actualoneboundedrun/imports/finalrecord/PVchecks charged, no extension/restart. Query kernel and fullcaller clocks remain distinct. This wrapper is normal local process control, not another Agent/worker.');receipt.write_text(json.dumps(x,indent=2)+'\n');print(x['stdout'][-2000:]);print(x['stderr'][-1200:]);sys.exit(x['returncode'])
