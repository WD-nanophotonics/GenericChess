from pathlib import Path
import sys,json,time,inspect,collections,statistics,dataclasses
from enum import Enum
from fractions import Fraction
R=Path.cwd();P=R/'.local_agent/api-ready-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value,write_record
from generic_chess.native.semantic_engine import SemanticIterativeSearchResult
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
source=inspect.getsource(record_value);candidate=source.replace('return record_value(asdict(value))','return record_value({f.name:getattr(value,f.name)for f in fields(value)})');assert source!=candidate
ns=dict(sys=sys,is_dataclass=dataclasses.is_dataclass,fields=dataclasses.fields,Enum=Enum,Fraction=Fraction);exec(candidate,ns);fast=ns['record_value']
(P/'recording-candidate.py.txt').write_text(candidate)
def action(x):
 if x is None or isinstance(x,str):return x
 if not x:return PassAction()
 if 'from_square'in x:return SemanticBoardMove(x['pattern_id'],x['geometry_id'],x['actor_type_id'],Square(**x['from_square']),Square(**x['to_square']),x['promotion_target_id'])
 return SemanticDropMove(x['pattern_id'],x['geometry_id'],x['base_type_id'],Square(**x['to_square']))
def typed(d):
 x=dict(d)
 for k,v in x.items():
  if k in ('action','root_hint_requested'):x[k]=action(v)
  elif k in ('principal_variation','decision_line','root_iteration_first_actions'):x[k]=tuple(action(a)for a in v)
  elif isinstance(v,list):x[k]=tuple(v)
 return SemanticIterativeSearchResult(**x)
r=json.loads((P/'results.json').read_bytes());selected={}
for x in r['rows']:
 if x['kind']=='ACTUAL_QUERY':selected.setdefault((x['seed'],x['profile'],x['arm']),x)
start=time.perf_counter();rows=[];audit=[]
for i,((seed,profile,arm),x)in enumerate(selected.items()):
 value=typed(x['result']);assert record_value(value)==fast(value)==x['result'];audit.append(dict(seed=seed,board=x['board'],profile=profile,arm=arm,field_count=len(x['result']),array_lengths={k:len(v)for k,v in x['result'].items()if isinstance(v,list)},all_fields_equal=True))
 for rep in range(4):
  pair={}
  for name in (['baseline','candidate']if(i+rep)%2==0 else['candidate','baseline']):
   t=time.perf_counter();v=(record_value if name=='baseline'else fast)(value);encoded=json.dumps(v,separators=(',',':'));sec=time.perf_counter()-t;pair[name]=encoded;rows.append(dict(seed=seed,board=x['board'],profile=profile,backend=arm,rep=rep,encoder=name,seconds=sec,bytes=len(encoded.encode())))
  assert pair['baseline']==pair['candidate']
 assert time.perf_counter()-start<60
summary=[]
for b in(4,8,12,16):
 groups=collections.defaultdict(dict)
 for row in rows:
  if row['board']==b:groups[row['seed'],row['profile'],row['backend'],row['rep']][row['encoder']]=row['seconds']
 ratios=[v['candidate']/v['baseline']for v in groups.values()];summary.append(dict(board=b,pairs=len(ratios),median_ratio=statistics.median(ratios),min_ratio=min(ratios),max_ratio=max(ratios)))
out=dict(complete=True,typed_objects=len(audit),conversion_calls=len(rows),audit=audit,rows=rows,summary=summary,seconds=time.perf_counter()-start,scope='Actualreconstructed realresult dataclasses/actions, fullfield exactJSON equality; privatecomponent only, not original objectidentity or endtoendsearch gain. Original experiment/helper/source unchanged, no tests/games/modeltraining or framework adopted.')
write_record(P/'recording-results.json',out);print('RECORDING',out['typed_objects'],out['conversion_calls'],summary,out['seconds'])
