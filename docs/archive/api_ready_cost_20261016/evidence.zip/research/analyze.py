from pathlib import Path
import json,collections,statistics
P=Path('.local_agent/api-ready-20261016');d=json.loads((P/'results.json').read_bytes());rows=d['rows'];groups=collections.defaultdict(dict)
for x in rows:groups[x['seed'],x['mode'],x['budget'],x['profile'],x['rep']][x['arm']]=x
paired=[]
for k,v in groups.items():
 if len(v)!=2:continue
 a=v['base_af4a'];b=v['final_1bc6'];ra=a.get('result',{});rb=b.get('result',{});paired.append(dict(seed=k[0],board=a['board'],mode=k[1],budget=k[2],profile=k[3],rep=k[4],kinds=[a['kind'],b['kind']],eligible=[a.get('eligible',False),b.get('eligible',False)],depths=[ra.get('completed_depth'),rb.get('completed_depth')],depth_delta=None if not ra or not rb else rb['completed_depth']-ra['completed_depth'],same_action=ra.get('action')==rb.get('action') if ra and rb else None,caller_ratio=b.get('caller_ready_seconds',1)/a.get('caller_ready_seconds',1),both_depth12=ra.get('completed_depth')==12 and rb.get('completed_depth')==12,score_equal=ra.get('score')==rb.get('score')if ra and rb else None,overruns=[a.get('overrun_seconds'),b.get('overrun_seconds')]))
summary=[]
for board in(4,8,12,16):
 for mode in('cold','warm'):
  for profile in('static','dynamic235'):
   for budget in(.25,1,4):
    pp=[x for x in paired if x['board']==board and x['mode']==mode and x['profile']==profile and x['budget']==budget];rr=[r for r in rows if r['board']==board and r['mode']==mode and r['profile']==profile and r['budget']==budget]
    if not rr:continue
    summary.append(dict(board=board,mode=mode,profile=profile,budget=budget,actual_slots=len(rr),kinds=dict(collections.Counter(x['kind']for x in rr)),base_ready=sum(x['eligible'][0]for x in pp),final_ready=sum(x['eligible'][1]for x in pp),final_only_ready=sum(x['eligible']==[False,True]for x in pp),base_only_ready=sum(x['eligible']==[True,False]for x in pp),greater_depth=sum((x['depth_delta']or 0)>0 for x in pp),less_depth=sum((x['depth_delta']or 0)<0 for x in pp),same_depth=sum(x['depth_delta']==0 for x in pp),both_depth12=sum(x['both_depth12']for x in pp),both_depth12_score_disagreements=sum(x['both_depth12']and not x['score_equal']for x in pp),median_readytime_ratio=statistics.median(x['caller_ratio']for x in pp)if pp else None))
out=dict(complete=True,planned_slots=d['planned_slots'],actual_slots=len(rows),roots=len(d['roots']),root_kinds=dict(collections.Counter(x['kind']for x in d['roots'])),query_kinds=dict(collections.Counter(x['kind']for x in rows)),queries=sum(x['kind']=='ACTUAL_QUERY'for x in rows),seconds=d['seconds'],paired=paired,summary=summary,full_history_edges=d['full_history_edges'],scope='Depth/change in action is not quality; compare within profile, maintain separate cold and warm. Exact deadline eligibility includes full output/serialization; late result never promoted to executable. Inputs are development families with no human holdouts or model training.')
out['requested_D12_complete']=sum(r.get('result',{}).get('completed_depth')==12 for r in rows)
out['joint_D12_pairs']=sum(r['both_depth12']for r in paired)
out['actual_late_queries']=sum(r['kind']=='ACTUAL_QUERY'and not r['eligible']for r in rows)
(P/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print({k:out[k]for k in('actual_slots','root_kinds','query_kinds','seconds')});print('READY',collections.Counter((x['arm'],x['eligible'])for x in rows));print('DEPTH12_SCORE_MISMATCH',sum(x['both_depth12']and not x['score_equal']for x in paired))
