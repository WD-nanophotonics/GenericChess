from pathlib import Path
import json,collections,statistics,random
P=Path('.local_agent/api-ready-20261016');outputs=[]
for name,target in [('reserve',12),('fixedD4',4)]:
 p=P/(name+'-results.json')
 if not p.exists():continue
 d=json.loads(p.read_bytes());groups=collections.defaultdict(dict)
 for x in d['rows']:groups[x['seed'],x['budget'],x['profile'],x['rep']][x['arm']]=x
 pairs=[]
 for key,v in groups.items():
  if len(v)!=2:continue
  a=v['base_af4a'];b=v['final_1bc6'];ra=a.get('result');rb=b.get('result');joint=bool(a['kind']=='ACTUAL_QUERY'and b['kind']=='ACTUAL_QUERY'and ra and rb and ra['completed_depth']==target and rb['completed_depth']==target)
  equal=None
  if joint:equal={k:v for k,v in ra.items()if k!='elapsed_seconds'}=={k:v for k,v in rb.items()if k!='elapsed_seconds'}
  pairs.append(dict(seed=key[0],board=a['board'],budget=key[1],profile=key[2],rep=key[3],kinds=[a['kind'],b['kind']],eligible=[a['eligible'],b['eligible']],depths=[None if r is None else r['completed_depth']for r in(ra,rb)],joint_requested_complete=joint,joint_all_non_time_equal=equal,caller_ratio=b['caller_ready_seconds']/a['caller_ready_seconds']if joint else None,overruns=[a.get('overrun_seconds'),b.get('overrun_seconds')]))
 summary=[]
 for board in(4,8,12,16):
  for profile in('static','dynamic235'):
   for budget in sorted({x['budget']for x in pairs}):
    pp=[x for x in pairs if x['board']==board and x['profile']==profile and x['budget']==budget];rr=[x for x in d['rows']if x['board']==board and x['profile']==profile and x['budget']==budget]
    byseed=collections.defaultdict(list)
    for x in pp:
     if x['joint_requested_complete']:byseed[x['seed']].append(x['caller_ratio'])
    med={k:statistics.median(v)for k,v in byseed.items()};values=list(med.values());ci=None
    if values:
     rng=random.Random(20261016);boots=sorted(statistics.median(rng.choices(values,k=len(values)))for _ in range(4000));ci=[boots[99],boots[3899]]
    summary.append(dict(board=board,profile=profile,budget=budget,pairs=len(pp),base_ready=sum(x['eligible'][0]for x in pp),final_ready=sum(x['eligible'][1]for x in pp),requested_complete_by_arm=[sum(x.get('result',{}).get('completed_depth')==target for x in rr if x['arm']==arm)for arm in('base_af4a','final_1bc6')],joint_requested_complete=sum(x['joint_requested_complete']for x in pp),joint_non_time_mismatches=sum(x['joint_all_non_time_equal']is False for x in pp),joint_family_median_ratios=med,joint_family_median=statistics.median(values)if values else None,descriptive_family_resampling_interval=ci))
 x=dict(name=name,complete=True,queries=sum(x['kind']=='ACTUAL_QUERY'for x in d['rows']),query_kinds=dict(collections.Counter(x['kind']for x in d['rows'])),slots=len(d['rows']),planned_slots=d['planned_slots'],seconds_internal=d['seconds'],full_history_edges=d['full_history_edges'],all_target_complete_non_time_mismatches=sum(x['joint_all_non_time_equal']is False for x in pairs),ready_by_arm=dict(collections.Counter(x['arm']for x in d['rows']if x['eligible'])),pairs=pairs,summary=summary,scope='Censored slots preserved; complete-task ratios conditioned on both target completions with <=4families/board. Descriptive4000family resamples seed20261016, not population CI/strength or independent validation. Reserve0 comparison from earlierphase is not contemporaneously randomized reserve effect. No default/API/model change.')
 outputs.append(x)
(P/'followup-analysis.json').write_text(json.dumps(dict(complete=all((P/(n+'-results.json')).exists()for n in('reserve','fixedD4')),panels=outputs),indent=2)+'\n')
for x in outputs:
 print(x['name'],x['query_kinds'],'READY',x['ready_by_arm'],'MISMATCH',x['all_target_complete_non_time_mismatches'],'TIME',x['seconds_internal'])
 print([(r['board'],r['profile'],r['budget'],r['requested_complete_by_arm'],r['joint_family_median'])for r in x['summary']])
