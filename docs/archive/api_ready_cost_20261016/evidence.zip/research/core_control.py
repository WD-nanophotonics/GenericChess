from pathlib import Path
from dataclasses import replace
import sys,json,time,collections
R=Path.cwd();P=R/'.local_agent/api-ready-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.core.semantic_executor import SemanticEngine
plan=json.loads((P/'core-control-plan.json').read_bytes());fixed=json.loads((P/'fixedD4-results.json').read_bytes());start=time.perf_counter();rows=[]
class Material:
 def __init__(self,c,bv,hv,dynamic):self.c=c;self.bv=bv;self.hv=hv;self.dynamic=dynamic;self.engine=SemanticEngine(c)
 def evaluate(self,state):
  p=state.position;owner=p.side_to_move;v=sum((1 if x.owner==owner else -1)*self.bv[x.current_type_id]for x in p.board if x is not None)+sum((1 if o==owner else -1)*self.hv[t]*n for o,h in enumerate(p.hands)for t,n in h.items())
  if not self.dynamic:return v
  counts=[]
  for o in(0,1):
   view=replace(p,side_to_move=o);aa=self.engine.legal_actions(view);counts.append((len(aa),sum(a.promotion_target_id is not None for a in aa),sum(a.source is not None and self.c.support.type_metadata[view.board[a.source].current_type_id].is_anchor for a in aa)-10*int(self.engine.in_check(view,o))))
  return v+(1 if owner==0 else -1)*sum(w*(a-b)for w,a,b in zip((2,3,5),*counts))
 def type_value(self,t):return self.bv[t]
 def capture_order_value(self,m,c):return 10*self.bv[c.current_type_id]-self.bv[m.current_type_id]
for case in plan['cases']:
 for n in('rollout','advisor','slack'):
  stop=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not(stop.get('user_paused')or stop.get('stopped')),'USER_STOP'
 if time.perf_counter()-start>=300:rows.append(dict(**case,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
 d=json.loads((P/'roots'/f"{case['seed']}.json").read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);session=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));profile=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in profile.board_value_by_type.items()};hv={k:int(round(v))for k,v in profile.hand_value_by_base_type.items()};ev=Material(c,bv,hv,case['profile']=='dynamic235');before=record_value(session.state)
 player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,use_native_semantic_availability=False,use_native_semantic_check=False,tuning=SearchTuning(use_root_tactical=False));assert player.native_legality_provider is None
 t=time.perf_counter();r=player.choose_action(session,SearchLimits(max_depth=4,max_nodes=262144,max_time_seconds=32,quiescence_max_depth=0,quiescence_hard_max_depth=0));seconds=time.perf_counter()-t;assert record_value(session.state)==before
 native=[a for a in fixed['rows']if a['seed']==case['seed']and a['profile']==case['profile']and a['kind']=='ACTUAL_QUERY'and a['result']['completed_depth']==4];joint=r.completed_depth==4 and bool(native);equal=all(a['result']['score']==r.score for a in native)if joint else None
 row=dict(**case,kind='ACTUAL_QUERY',result=record_value(r),caller_seconds=seconds,root_restored=True,actual_legality='PURE_CORE_NO_NATIVE_PROVIDER',native_joint_complete_receipts=len(native),core_complete=r.completed_depth==4,joint_score_equal=equal);rows.append(row);write_record(P/'core-progress.json',dict(complete=False,rows=rows));print('CORE',case,r.completed_depth,r.score,seconds,equal,flush=True)
write_record(P/'core-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,scope=plan['scope']));print('CORE_DONE',len(rows),time.perf_counter()-start)
