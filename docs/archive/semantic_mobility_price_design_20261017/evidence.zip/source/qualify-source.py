from pathlib import Path
import sys,importlib.util
W=Path.cwd().resolve()
sys.meta_path[:]=[f for f in sys.meta_path if not getattr(f,'__module__','').startswith('__editable___generic_chess_')]
sys.path[:]=[str(W)]+[p for p in sys.path if p and Path(p).resolve()!=W and not (Path(p)/'generic_chess').is_dir()]
import generic_chess
from generic_chess.native import native_available
assert Path(generic_chess.__file__).resolve().is_relative_to(W)
assert importlib.util.find_spec('generic_chess._native_core') is None
assert not native_available()
if sys.argv[1:] and sys.argv[1] in ('--reader', '--runtime-reader'):
 import runpy
 runpy.run_path(str(W/'.local_agent/price-measure-20261017'/('runtime-reader.py' if sys.argv[1]=='--runtime-reader' else 'reader.py')),run_name='__main__');code=0
else:
 import pytest
 code=pytest.main(['-o','addopts=','-o','cache_dir=.local_agent/cache','--basetemp=.local_agent/pytest-source-pure-02','-q','tests/product/test_no_progress_search_context.py','tests/product/test_semantic_opportunity.py','tests/product/test_semantic_attack_map.py'])
wrong=[name for name,m in sys.modules.items()if name.startswith('generic_chess')and getattr(m,'__file__',None)and not Path(m.__file__).resolve().is_relative_to(W)]
assert not wrong,wrong
print('QUALIFIED_SOURCE_ONLY_MODULES',len([n for n in sys.modules if n.startswith('generic_chess')]),'native_available',native_available(),flush=True)
raise SystemExit(code)
