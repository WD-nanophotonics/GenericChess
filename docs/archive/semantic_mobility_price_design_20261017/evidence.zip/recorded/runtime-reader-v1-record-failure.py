from pathlib import Path
from dataclasses import replace
import sys
import json
import time
import collections
R = Path.cwd()
sys.path.insert(0, str(R))
D = R / '.local_agent/price-measure-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset, compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.transition import initial_state
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.position import GameState, HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.core.actions import SemanticBoardMove, SemanticDropMove, PassAction
from generic_chess.core.coordinates import Square
from generic_chess.session.result import SessionStatus, session_result_from_terminal
from generic_chess.session.record import ActionRecord

start = time.monotonic()
counts = collections.Counter()
cases = []
failure = None

def check():
    if time.monotonic() - start >= 180:
        raise TimeoutError('Runtime reader180s cap')
    for name in ('rollout', 'advisor', 'slack'):
        f = json.loads((R / '.local_agent' / f'{name}.json').read_bytes())
        if f.get('stopped') or f.get('user_paused'):
            raise InterruptedError('Explicit project stop')

def decode(a):
    if not a:
        return PassAction()
    if 'from_square' in a:
        return SemanticBoardMove(a['pattern_id'], a['geometry_id'], a['actor_type_id'], Square(**a['from_square']), Square(**a['to_square']), a['promotion_target_id'])
    return SemanticDropMove(a['pattern_id'], a['geometry_id'], a['base_type_id'], Square(**a['to_square']))

try:
    for base in (D, D / 'fresh-transfer', D / 'fresh-transfer/missing-atom-repair'):
        inputs = json.loads((base / 'consumer-inputs.json').read_bytes())
        compiled = {}
        for inp in inputs:
            rule = deserialize_ruleset(json.dumps(inp['rule']))
            c = compile_semantic_ruleset(rule) if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule)
            compiled[inp['family']] = replace(c, _legacy_compiled=None)
        for path in sorted(base.glob('consumer-game-*.json')):
            check()
            row = json.loads(path.read_bytes())
            c = compiled[row['family']]
            initial = initial_state(c)
            assert record_value(initial) == row['initial_state']
            rt = SearchPathRuntime.from_state(initial, c, history_witnesses=(initial.position,))
            public_history = list(initial.history)
            public_counts = dict(initial.repetition_counts)
            action_records = []
            counts['initial_states'] += 1
            for move in row['moves']:
                check()
                v = move['decision']
                assert move['actor'] == rt.position.side_to_move
                assert move['candidate'] == (move['actor'] == row['candidate_owner'])
                assert v['native_legality_calls'] == 0
                assert v['runtime_depth_balanced'] is not False
                before = (rt.position, rt.ply_count, rt.terminal_status, tuple(rt.history), rt.runtime_hash)
                pushed = 0
                try:
                    for encoded in v['principal_variation']:
                        rt.push(decode(encoded), checkpoint=check)
                        pushed += 1
                        counts['PV_edges'] += 1
                finally:
                    for _ in range(pushed):
                        rt.pop()
                assert before == (rt.position, rt.ply_count, rt.terminal_status, tuple(rt.history), rt.runtime_hash)
                action = decode(v['action'])
                before_key = position_identity_key(rt.position, c)
                actor = rt.position.side_to_move
                rt.push(action, checkpoint=check)
                key = position_identity_key(rt.position, c)
                event = rt.history[-1]
                public_history.append(HistoryRecord(key, event.actor, event.action_signature, event.gave_check))
                public_counts[key] = public_counts.get(key, 0) + 1
                state = GameState(rt.position, rt.ply_count, tuple(sorted(public_counts.items())), rt.terminal_status, tuple(public_history))
                assert record_value(state) == move['child']
                assert len(public_history) == rt.ply_count + 1
                action_records.append(ActionRecord(rt.ply_count, actor, action, before_key, key))
                counts['full_game_edges'] += 1
            assert record_value(tuple(action_records)) == row['record']['actions']
            assert row['record']['ruleset_fingerprint'] == c.ruleset_fingerprint
            result = session_result_from_terminal(rt.terminal_status)
            assert record_value(result) == row['session_result']
            if row['status'] == 'actual_terminal':
                assert result.status is not SessionStatus.ONGOING
                reward = 0 if result.winner is None else 1 if result.winner == row['candidate_owner'] else -1
                assert reward == row['reward']
                counts['actual_terminals'] += 1
            elif row['status'].endswith('_UNKNOWN'):
                assert result.status is SessionStatus.ONGOING and row['reward'] is None
                expected = 64 if '64ply' in row['status'] else 32
                assert rt.ply_count == expected
                counts['administrative_UNKNOWN'] += 1
            else:
                raise AssertionError('Unexpected game status')
            counts['records'] += 1
            cases.append({'source': base.relative_to(D).as_posix(), 'game': row['game'], 'family': row['family'], 'arm': row['arm'], 'status': row['status']})
            write_json(D / 'runtime-reader-progress.json', {'counts': dict(counts), 'cases': cases, 'seconds': time.monotonic() - start})
            print('RUNTIME_READ', base.relative_to(D), row['game'], rt.ply_count, flush=True)
except Exception as exc:
    failure = {'type': type(exc).__name__, 'message': str(exc)}
    raise
finally:
    write_json(D / 'runtime-reader-result.json', {'complete': failure is None and len(cases) == 96, 'counts': dict(counts), 'cases': cases, 'failure': failure, 'seconds': time.monotonic() - start, 'new_search_calls': 0, 'new_games': 0, 'scope': 'ExistingCore incremental runtime compared against all recorded public GameState fields/actions/terminal/PV legality, not independent rules or WDL; separate method from original240s public reader.'})
    print('RUNTIME_DONE', len(cases), dict(counts), failure, time.monotonic() - start, flush=True)
