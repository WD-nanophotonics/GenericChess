from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,inspect,textwrap,hashlib,traceback,statistics
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/price-measure-20261017';N=D/'bulk-attack';START=time.monotonic()
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.core import semantic_executor as mod
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
original = SemanticEngine.attacked_squares
source = textwrap.dedent(inspect.getsource(original))
needle = '                for target, path in geometry_candidates(geometry, str(by_owner), source):'
# Match source indentation mechanically after dedent, not an invented body.
needle = next(line for line in source.splitlines() if 'for target, path in geometry_candidates' in line)
indent = needle[:len(needle)-len(needle.lstrip())]
candidate = source.replace(needle, indent + 'simple_clear_ray = (geometry.kind == "ray" and len(pattern.path) == 1 and pattern.path[0].kind == "path_clear")\n' + needle)
old = '''if self._path_holds(
                            pattern.path, position, binding, by_owner, checkpoint=checkpoint,
                        ) and self._guards_hold(
                            pattern, position, binding, by_owner, checkpoint=checkpoint,
                        ):
                            attacked.add(target)'''
# The method-level dedent removes four spaces from its body.
old = textwrap.dedent(old)
start = candidate.index('if self._path_holds(')
end = candidate.index('attacked.add(target)', start) + len('attacked.add(target)')
old_actual = candidate[start:end]
replacement = '''path_ok = self._path_holds(
{b}    pattern.path, position, binding, by_owner, checkpoint=checkpoint,
{b})
{b}if not path_ok:
{b}    if simple_clear_ray:
{b}        _checkpoint(checkpoint)
{b}        break
{b}    continue
{b}if self._guards_hold(
{b}    pattern, position, binding, by_owner, checkpoint=checkpoint,
{b}):
{b}    attacked.add(target)'''
body_indent = candidate[candidate.rfind('\n', 0, start)+1:start]
candidate = candidate[:start] + replacement.format(b=body_indent) + candidate[end:]
candidate = candidate.replace('    return frozenset(attacked)', '    _checkpoint(checkpoint)\n    return frozenset(attacked)')
assert candidate.count('simple_clear_ray') == 2
(N/'source-original.py').write_text(source, encoding='utf8')
(N/'source-candidate.py').write_text(candidate, encoding='utf8')
namespace = dict(mod.__dict__)
exec(compile(candidate, str(N/'source-candidate.py'), 'exec'), namespace)
new = namespace['attacked_squares']

def check():
    if time.monotonic() - START >= 240:
        raise TimeoutError('Frozen240s whole cap')
    for name in ('rollout','advisor','slack'):
        v = json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
        if v.get('stopped') or v.get('user_paused'):
            raise InterruptedError('Explicit project stop')

def decode(a):
    if not a:
        return PassAction()
    if 'from_square' in a:
        return SemanticBoardMove(a['pattern_id'], a['geometry_id'], a['actor_type_id'], Square(**a['from_square']), Square(**a['to_square']), a['promotion_target_id'])
    return SemanticDropMove(a['pattern_id'], a['geometry_id'], a['base_type_id'], Square(**a['to_square']))

def stable(decision):
    return {k:v for k,v in record_value(decision).items() if 'seconds' not in k and not k.startswith('time_to_')}

inputs = json.loads((D/'fresh-transfer/consumer-inputs.json').read_bytes())
roots = []
cfg = replace(EvaluationConfig(), anchor_escape_weight=0, promotion_potential_weight=0)
for family, game in ((5,12),(10,28)):
    inp = next(x for x in inputs if x['family'] == family)
    c = replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(inp['rule']))), _legacy_compiled=None)
    p, scope = build_semantic_opportunity_profile(c,cfg)
    e = SemanticAttackEvaluator(c,p,cfg,backend='core')
    row = json.loads((D/f'fresh-transfer/consumer-game-{game:02}.json').read_bytes())
    assert row['status'] != 'active'
    s = GameSession(c)
    roots.append((family,0,copy(s),e))
    s.submit(decode(row['moves'][0]['decision']['action']))
    assert record_value(s.state) == row['moves'][0]['child']
    roots.append((family,1,copy(s),e))

rows=[]
try:
    for family,prefix,s,e in roots:
        for nodes in (512,2048):
            pair=[]
            order=('baseline','candidate') if len(rows)%2 == 0 else ('candidate','baseline')
            for arm in order:
                check()
                SemanticEngine.attacked_squares = original if arm == 'baseline' else new
                before = s.state
                player = AlphaBetaPlayer(s.compiled,evaluator_override=e,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(require_full_pv=True))
                t=time.perf_counter()
                v=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=nodes,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0))
                wall=time.perf_counter()-t
                assert s.state is before and v.runtime_depth_balanced is not False
                pv=copy(s)
                for a in v.principal_variation:
                    pv.submit(a)
                pair.append({'arm':arm,'decision':record_value(v),'actual_seconds':wall,'PV_final':record_value(pv.state)})
            a=next(z for z in pair if z['arm']=='baseline')
            b=next(z for z in pair if z['arm']=='candidate')
            exact=stable(type('Record',(),{})()) if False else ({k:v for k,v in a['decision'].items() if 'seconds' not in k and not k.startswith('time_to_')} == {k:v for k,v in b['decision'].items() if 'seconds' not in k and not k.startswith('time_to_')})
            ratio=b['actual_seconds']/a['actual_seconds']
            row={'family':family,'prefix':prefix,'nodes':nodes,'arms':pair,'all_non_time_fields_equal':exact,'full_PV_final_equal':a['PV_final']==b['PV_final'],'ratio':ratio,'both_uncensored_clock':all(z['decision']['termination_reason']!='time_limit' for z in pair)}
            rows.append(row)
            write_json(N/'progress.json',{'rows':rows,'seconds':time.monotonic()-START})
            print('PAIR',family,prefix,nodes,exact,row['full_PV_final_equal'],round(ratio,4),flush=True)
finally:
    SemanticEngine.attacked_squares=original
valid=[r for r in rows if r['both_uncensored_clock'] and r['all_non_time_fields_equal'] and r['full_PV_final_equal']]
median=statistics.median(r['ratio']for r in valid) if valid else None
write_json(N/'result.json',{'rows':rows,'planned_pairs':8,'observed_pairs':len(rows),'qualified_pairs':len(valid),'median_ratio':median,'seconds':time.monotonic()-START,'promising':len(valid)>=6 and median<=.90,'normal_source_unchanged':True,'scope':'PrivateactualdynamicCorecaller matchedwork/PV, exposed4roots/concurrentclocks. Getter/sourceintuition alone notadoption; currentnormalproducer unaffected.'})
print('DONE',len(valid),median,time.monotonic()-START,flush=True)
