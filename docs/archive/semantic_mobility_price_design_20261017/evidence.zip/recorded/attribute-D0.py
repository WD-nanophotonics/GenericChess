from pathlib import Path
import sys
import json
import collections
R = Path.cwd()
sys.path.insert(0, str(R))
D = R / '.local_agent/price-measure-20261017'
from tools.local_agent.common import write_json
counts = collections.Counter()
selected = []
seen = set()
for base in (D / 'fresh-transfer', D / 'fresh-transfer/missing-atom-repair'):
    for path in sorted(base.glob('consumer-game-*.json')):
        game = json.loads(path.read_bytes())
        if game['arm'] != 'attack':
            continue
        for ply, move in enumerate(game['moves']):
            q = move['decision']
            if not move['candidate'] or q['completed_depth'] != 0:
                continue
            counts[(q['termination_reason'], q['result_source'])] += 1
            if q['root_scan_nodes'] > 0 and game['family'] not in seen and len(selected) < 4:
                seen.add(game['family'])
                selected.append({
                    'family': game['family'], 'source': base.relative_to(D).as_posix(),
                    'game': game['game'], 'ply': ply,
                    'prefix': [m['decision']['action'] for m in game['moves'][:ply]],
                    'original_decision': q,
                    'original_parent': game['initial_state'] if ply == 0 else game['moves'][ply - 1]['child'],
                })
write_json(D / 'D0-attribution.json', {
    'counts': [{'termination': a, 'source': b, 'count': n} for (a, b), n in counts.items()],
    'selected': selected,
    'selection': 'First four distinct families with an actual attack candidate D0 and paid root-scan work in closed schedule. Targeted exposed cases, not holdout; original warm TT/clocks are not cold query reproductions.',
})
print('D0_COUNTS', dict(counts))
print('SELECTED', [(r['family'], r['game'], r['ply'], r['original_decision']['root_scan_nodes']) for r in selected])
