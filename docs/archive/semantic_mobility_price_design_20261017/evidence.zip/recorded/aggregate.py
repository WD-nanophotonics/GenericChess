from pathlib import Path
import sys
import json
import collections

R = Path.cwd()
sys.path.insert(0, str(R))
D = R / '.local_agent/price-measure-20261017'
F = D / 'fresh-transfer'
from tools.local_agent.common import write_json

cases = []
for base in (F, F / 'missing-atom-repair'):
    for path in sorted(base.glob('consumer-game-*.json')):
        row = json.loads(path.read_bytes())
        assert row['status'] != 'active'
        cases.append({'source': base.relative_to(D).as_posix(), 'file': path.name, **row})

assert len(cases) == 48
keys = [(r['family'], r['candidate_owner'], r['arm']) for r in cases]
expected = {(f, o, a) for f in range(12) for o in (0, 1) for a in ('material', 'attack')}
assert len(set(keys)) == 48 and set(keys) == expected
summary = {}
for arm in ('material', 'attack'):
    games = [g for g in cases if g['arm'] == arm]
    queries = [m['decision'] for g in games for m in g['moves'] if m['candidate']]
    summary[arm] = {
        'games': len(games),
        'W': sum(g['reward'] == 1 for g in games),
        'L': sum(g['reward'] == -1 for g in games),
        'D': sum(g['reward'] == 0 for g in games),
        'UNKNOWN': sum(g['reward'] is None for g in games),
        'terminal_classes': dict(collections.Counter(g['session_result']['status'] for g in games)),
        'physical_plies': sum(len(g['moves']) for g in games),
        'candidate_calls': len(queries),
        'candidate_search_seconds': sum(q['elapsed_seconds'] for q in queries),
        'candidate_eval_seconds': sum(q['evaluation_seconds'] for q in queries),
        'candidate_nodes': sum(q['nodes'] + q['qnodes'] for q in queries),
        'candidate_completed_depths': dict(collections.Counter(q['completed_depth'] for q in queries)),
        'candidate_max_seconds': max(q['elapsed_seconds'] for q in queries),
        'candidate_native_calls': sum(q['native_legality_calls'] for q in queries),
    }

pairs = []
for family in range(12):
    for owner in (0, 1):
        a = next(g for g in cases if (g['family'], g['candidate_owner'], g['arm']) == (family, owner, 'material'))
        b = next(g for g in cases if (g['family'], g['candidate_owner'], g['arm']) == (family, owner, 'attack'))
        x, y = a['reward'], b['reward']
        low = (y if y is not None else -1) - (x if x is not None else 1)
        high = (y if y is not None else 1) - (x if x is not None else -1)
        gain = y - x if x is not None and y is not None else None
        pairs.append({
            'family': family, 'owner': owner, 'material': x, 'attack': y,
            'gain_bounds': [low, high], 'complete_gain': gain,
            'material_game': a['file'], 'attack_game': b['file'],
            'sources': [a['source'], b['source']],
        })

low = sum(p['gain_bounds'][0] for p in pairs) / 24
high = sum(p['gain_bounds'][1] for p in pairs) / 24
complete = [p['complete_gain'] for p in pairs if p['complete_gain'] is not None]
original = json.loads((F / 'consumer-result.json').read_bytes())
repair = json.loads((F / 'missing-atom-repair/consumer-result.json').read_bytes())
assert not original['source_changed'] and not repair['source_changed']
assert repair['seconds'] < 1800
out = {
    'planned_cells': 48, 'actual_cells': len(cases), 'missing_cells': 0,
    'physical_plies': sum(len(g['moves']) for g in cases),
    'search_calls': original['calls'] + repair['calls'],
    'summary': summary, 'pairs': pairs,
    'paired_mean_gain_bounds': [low, high],
    'complete_pairs': len(complete), 'complete_pair_sum_gain': sum(complete),
    'complete_pair_gain_counts': dict(collections.Counter(complete)),
    'joint_seconds_from_original_start': repair['seconds'],
    'original_whole_cap_seconds': 1800, 'original36_seconds': original['seconds'],
    'original_harness_failure': '3 atom-only generated rules wrongly sent to nonempty DSL compiler; originals retained. Existing compile_legacy route preflight repaired ONLY12 unstarted cells with same original clock, no replacement seed, repeated36 cells or cap reset.',
    'source_unchanged': True,
    'scope': 'Prospective12 specific generated rules and fixed finite opponent; no model/price fit or Elo/general WDL. Within-family trajectories are dependent; late atom-only protocol stratum and concurrent loading remain limits.',
    'decision': 'UNKNOWN bounds include0: no robust attack-mobility gain. Retain cheap material and existing opt-in feature, no default/model/training activation. Inspect one actual loss/common-parent completion contrast instead of another unchanged arena.',
}
write_json(D / 'fresh-transfer-analysis.json', out)
print(json.dumps({k: v for k, v in out.items() if k != 'pairs'}, indent=2))
