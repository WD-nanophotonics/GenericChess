from pathlib import Path
from dataclasses import replace
from copy import copy
from fractions import Fraction
import sys,json,time,traceback
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/price-measure-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig,MATE_THRESHOLD
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
START=time.monotonic();calls=0
class Zero:
 def evaluate(self,state):return 0

def check():
 if time.monotonic()-START>=900:raise TimeoutError('Frozen900s total cap')
 for name in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('Explicit project stop')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def shifted(score):return score-1 if score>=MATE_THRESHOLD else score+1 if score<=-MATE_THRESHOLD else score
cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0)
cs={z['family']:replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(z['rule']))),_legacy_compiled=None)for z in json.loads((D/'inputs.json').read_bytes())};evaluators={}
for family,c in cs.items():
 profile,_=build_semantic_opportunity_profile(c,cfg);evaluators[family]=SemanticAttackEvaluator(c,profile,cfg,backend='core')
rows=[]
for index in range(16):
 check();old=json.loads((D/f'slot-{index:02}.json').read_bytes());f=old['target_family'];s=GameSession(cs[f]);row={'slot':index,'target_family':f,'origin_family':old['origin_family'],'prefix':old['prefix'],'children':[]};t=time.monotonic()
 try:
  for a in old['actions']:s.submit(decode(a))
  assert record_value(s.state)==old['parent']
  for z in old['children']:
   check();ch=copy(s);ch.submit(decode(z['action']));assert record_value(ch.state)==z['child'];ct=time.perf_counter();dynamic=-evaluators[f].evaluate(ch.state);dt=time.perf_counter()-ct
   w={'action':z['action'],'one_ply_material':z['one_ply'],'one_ply_dynamic':dynamic if not ch.state.terminal_status.is_terminal else z['one_ply'],'dynamic_evaluation_seconds':dt,'observation':z['observation'],'binding_weight':z['binding_weight'],'observation_weight':z['observation_weight']}
   if ch.state.terminal_status.is_terminal:w.update(reference=z['one_ply'],reference_kind='actual_terminal',query=None)
   else:
    if calls>=400:raise TimeoutError('Frozen400call cap')
    player=AlphaBetaPlayer(cs[f],evaluator_override=Zero(),use_disk_cache=False,use_native_semantic_legality=False,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));before=ch.state;decision=player.choose_action(ch,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));calls+=1
    assert ch.state is before and decision.runtime_depth_balanced is not False
    w['query']=record_value(decision)
    if decision.completed_depth==2:w.update(reference=-shifted(decision.score),reference_kind='finite_D3_terminal_zero_leaf')
    else:w.update(reference=None,reference_kind='censored_child_call')
   row['children'].append(w)
  row['status']='complete' if all(z['reference']is not None for z in row['children'])else'partial_censored'
  if row['status']=='complete':
   best=max(z['reference']for z in row['children']);summary={'reference_best':best,'positive_terminal_band':sum(z['reference']>=MATE_THRESHOLD for z in row['children']),'negative_terminal_band':sum(z['reference']<=-MATE_THRESHOLD for z in row['children']),'zero_horizon_surrogate_NOT_draw':sum(z['reference']==0 for z in row['children'])}
   for name in ('material','dynamic'):
    bm=max(z['one_ply_'+name]for z in row['children']);tie=[z for z in row['children']if z['one_ply_'+name]==bm];q={'ties':len(tie),'nonoptimal':sum(z['reference']<best for z in tie),'negative_terminal_band':sum(z['reference']<=-MATE_THRESHOLD for z in tie),'gap_range':[min(best-z['reference']for z in tie),max(best-z['reference']for z in tie)]}
    for measure in ('binding_weight','observation_weight'):
     den=sum(Fraction(z[measure])for z in tie);q[measure+'_mean_gap']=str(sum(Fraction(z[measure])*(best-z['reference'])for z in tie)/den)
    summary[name]=q
   row['summary']=summary
 except Exception as e:row.update(status='error',failure={'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()})
 row['seconds']=time.monotonic()-t;write_json(D/f'terminal-slot-{index:02}.json',row);rows.append({k:v for k,v in row.items()if k!='children'});write_json(D/'terminal-progress.json',{'rows':rows,'calls':calls,'seconds':time.monotonic()-START});print('SLOT',index,row['status'],row.get('summary'),round(row['seconds'],3),flush=True)
 if row['status']=='error'and row['failure']['type']in('TimeoutError','InterruptedError'):break
write_json(D/'terminal-result.json',{'rows':rows,'calls':calls,'seconds':time.monotonic()-START,'planned':16,'observed':len(rows),'complete':len(rows)==16 and all(z['status']=='complete'for z in rows)});print('DONE',calls,time.monotonic()-START,flush=True)
