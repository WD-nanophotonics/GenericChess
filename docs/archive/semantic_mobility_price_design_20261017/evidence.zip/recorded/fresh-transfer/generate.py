from pathlib import Path
import sys,json,time,hashlib,traceback
from dataclasses import replace
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];D=R/'.local_agent/price-measure-20261017/fresh-transfer';plan=json.loads((D/'plan.json').read_bytes());start=time.monotonic()
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset,deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import RuleNoProgressDraw,RuleConsecutiveActionAdjudication
from generic_chess.session.session import GameSession
from generic_chess.core.movement import RayAtom
from rule_semantics_ir_fixtures import weird_rulesets
write_json(D/'generation-start.json',{'monotonic_start':start,'utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()})
fixtures=[json.loads(serialize_ruleset(r))['semantic_actions'][0]for r in weird_rulesets()];rows=[];inputs=[]
def check():
 if time.monotonic()-start>=1800:raise TimeoutError('Frozen whole1800 cap including generation')
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
def remap(value,mapping,key=None):
 if isinstance(value,dict):return {k:remap(v,mapping,k)for k,v in value.items()}
 if isinstance(value,list):return[remap(v,mapping,key)for v in value]
 return mapping.get(value,value)if key in('type_id','type_ids')and isinstance(value,str)else value
for i,(seed,board)in enumerate(zip(plan['generation']['seeds'],plan['generation']['boards'])):
 check();t=time.monotonic();row={'family':i,'seed':seed,'board':board,'mode':i%4}
 try:
  cfg=GeneratorConfig(seed=seed,board_size=board,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32,require_no_opening_win_in_one=True);g=generate_game(cfg);base=json.loads(serialize_ruleset(g.ruleset));target=next(p.type_id for p in g.ruleset.piece_types if not p.is_anchor and not p.is_promotable);actor=next((p.type_id for p in g.ruleset.piece_types if not p.is_anchor and any(isinstance(a,RayAtom)for a in p.movement_atoms)),'P');base['semantic_dsl_version']=2
  actions=[]
  if i%4==1:actions=[remap(fixtures[2],{'R':'P','TP':target})]
  if i%4==2:actions=[remap(fixtures[3],{'R':'P'})]
  if i%4==3:actions=[remap(fixtures[0],{'R':actor}),remap(fixtures[1],{'R':actor}),remap(fixtures[2],{'R':'P','TP':target})]
  base['semantic_actions']=actions;rule=deserialize_ruleset(json.dumps(base))
  if i%4==3:rule=replace(rule,pass_enabled=True,no_progress_draw=RuleNoProgressDraw(threshold_plies=16,reset_on_capture=True,reset_mover_type_ids=('P',)),consecutive_action_adjudications=(RuleConsecutiveActionAdjudication(action_class='pass',threshold=2,outcome='DRAW'),))
  c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c);legal=s.legal_actions();wins=[]
  from copy import copy
  for a in legal:
   check();ch=copy(s);ch.submit(a)
   if ch.state.terminal_status.winner==s.state.position.side_to_move:wins.append(record_value(a))
  row.update(status='generated',generation_report=record_value(g.generation_report),full_opening_degree=len(legal),node_floor_within4096=len(legal)+1<=4096,actual_augmented_opening_wins=wins,augmented_fingerprint=c.ruleset_fingerprint,base_type_mapping={'actor':actor,'temporary_P_target':target})
  inputs.append({'family':i,'axis':'prospective_generated_transfer','rule':json.loads(serialize_ruleset(rule))})
 except Exception as e:row.update(status='generation_or_compile_error',failure={'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()})
 row['seconds']=time.monotonic()-t;rows.append(row);write_json(D/'generation-progress.json',{'rows':rows,'seconds':time.monotonic()-start});print('GENERATED',i,board,row['status'],row.get('full_opening_degree'),round(row['seconds'],3),flush=True)
write_json(D/'generation-result.json',{'planned_families':12,'generated':len(inputs),'rows':rows,'seconds':time.monotonic()-start});write_json(D/'consumer-inputs.json',inputs);write_json(D/'consumer-source-binding.json',{'files':{str(p.relative_to(R)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in(R/'generic_chess').rglob('*.py')},'input_sha256':hashlib.sha256((D/'consumer-inputs.json').read_bytes()).hexdigest()})
# Reuse the already corrected runner; retain distinct source and all frozen changes.
s=(D.parent/'consumer.py').read_text(encoding='utf8');s=s.replace("D=R/'.local_agent/price-measure-20261017'","D=R/'.local_agent/price-measure-20261017/fresh-transfer'").replace('START=time.monotonic();rows=[]','START=json.loads((D/\'generation-start.json\').read_bytes())[\'monotonic_start\'];rows=[]').replace('1200','1800').replace('range(32)','range(64)').replace('administrative32ply_UNKNOWN','administrative64ply_UNKNOWN').replace('max_time_seconds=1,','max_time_seconds=0.5,');assert 'SessionStatus.ONGOING' in s;compile(s,str(D/'consumer.py'),'exec');(D/'consumer.py').write_text(s,encoding='utf8');print('GENERATION_DONE',len(inputs),time.monotonic()-start,flush=True)
