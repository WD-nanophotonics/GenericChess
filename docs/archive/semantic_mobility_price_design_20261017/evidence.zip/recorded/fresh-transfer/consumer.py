from pathlib import Path

from dataclasses import replace

import sys,json,time,traceback,os,hashlib

R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/price-measure-20261017/fresh-transfer'

from tools.local_agent.common import write_json

from scripts.research_record import record_value

from generic_chess.rules.serialization import deserialize_ruleset

from generic_chess.rules.compiler import compile_semantic_ruleset

from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile

from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator

from generic_chess.ai.evaluation.config import EvaluationConfig

from generic_chess.ai.alphabeta.player import AlphaBetaPlayer

from generic_chess.ai.alphabeta.tuning import SearchTuning

from generic_chess.ai.limits import SearchLimits

from generic_chess.session.session import GameSession
from generic_chess.session.result import SessionStatus

START=json.loads((D/'generation-start.json').read_bytes())['monotonic_start'];rows=[];calls=0;moves=0

write_json(D/'consumer-producer.json',{'pid':os.getpid(),'started_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'source':'consumer.py','whole_cap_seconds':1800})

def check():

 if time.monotonic()-START>=1800:raise TimeoutError('Frozen1800s whole cap')

 for name in('rollout','advisor','slack'):

  flag=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())

  if flag.get('stopped')or flag.get('user_paused'):raise InterruptedError('Explicit project stop')

def player(c,ev):return AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(require_full_pv=True))

inputs=json.loads((D/'consumer-inputs.json').read_bytes());source=json.loads((D/'consumer-source-binding.json').read_bytes())

def source_check():return [p for p,h in source['files'].items()if hashlib.sha256((R/p).read_bytes()).hexdigest()!=h]

assert not source_check()

try:

 for inp in inputs:

  f=inp['family'];check();t=time.monotonic();c=replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(inp['rule']))),_legacy_compiled=None);evs={};profiles={}

  for arm,mob in(('material',0),('attack',2)):

   cfg=replace(EvaluationConfig(),dynamic_mobility_weight=mob,anchor_escape_weight=0,promotion_potential_weight=0);p,scope=build_semantic_opportunity_profile(c,cfg);profiles[arm]={'profile':record_value(p),'scope':scope};evs[arm]=SemanticAttackEvaluator(c,p,cfg,backend='core')

  assert profiles['material']['profile']['board_value_by_type']==profiles['attack']['profile']['board_value_by_type']

  assert profiles['material']['profile']['hand_value_by_base_type']==profiles['attack']['profile']['hand_value_by_base_type']

  setup=time.monotonic()-t;write_json(D/f'consumer-family-{f:02}-profiles.json',{'setup_seconds':setup,'profiles':profiles})

  for owner in(0,1):

   order=('material','attack')if(f+owner)%2==0 else('attack','material')

   for arm in order:

    check();game=len(rows);s=GameSession(c);players={owner:player(c,evs[arm]),1-owner:player(c,evs['material'])};row={'game':game,'family':f,'candidate_owner':owner,'arm':arm,'initial_state':record_value(s.state),'moves':[],'status':'active'};gstart=time.monotonic()

    try:

     for ply in range(64):

      check()

      if s.state.terminal_status.is_terminal:break

      side=s.state.position.side_to_move;depth=3 if side==owner else 2;before=s.state;call=time.monotonic();v=players[side].choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=0.5,quiescence_max_depth=0,quiescence_hard_max_depth=0));calls+=1

      check();assert s.state is before;assert v.runtime_depth_balanced is not False;assert v.native_legality_calls==0

      if v.choice_kind=='DECLARATION':s.declare(v.declaration.declaration_id)

      elif v.action in s.legal_actions():s.submit(v.action)

      else:raise AssertionError('Missing or illegal action on ongoing session')

      moves+=1;assert len(s.state.history)==s.state.ply_count+1;assert len(s.history)==s.state.ply_count

      row['moves'].append({'actor':side,'candidate':side==owner,'decision':record_value(v),'call_seconds':time.monotonic()-call,'child':record_value(s.state)})

      write_json(D/f'consumer-game-{game:02}.json',row)

      if s.result.status is not SessionStatus.ONGOING:break

     result=s.result;row['session_result']=record_value(result);row['record']=record_value(s.to_record())

     if result.status is SessionStatus.ONGOING:row.update(status='administrative64ply_UNKNOWN',reward=None)

     else:row.update(status='actual_terminal',reward=0 if result.winner is None else 1 if result.winner==owner else -1)

    except Exception as e:

     row.update(status='error',reward=None,failure={'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()},record=record_value(s.to_record()))

    row['seconds']=time.monotonic()-gstart;write_json(D/f'consumer-game-{game:02}.json',row);rows.append({k:v for k,v in row.items()if k not in('initial_state','moves','record')});write_json(D/'consumer-progress.json',{'planned_games':48,'rows':rows,'calls':calls,'physical_moves':moves,'seconds':time.monotonic()-START});print('GAME',game,f,owner,arm,row['status'],row['reward'],len(row['moves']),round(row['seconds'],3),flush=True)

    if row['status']=='error':raise RuntimeError('Producer stopped on retained game error')

except Exception as e:

 failure={'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()};write_json(D/'consumer-failure.json',failure);print('FAILURE',failure,flush=True)

finally:

 changed=source_check();write_json(D/'consumer-result.json',{'planned_games':48,'observed_games':len(rows),'missing_games':48-len(rows),'calls':calls,'physical_moves':moves,'seconds':time.monotonic()-START,'source_changed':changed,'rows':rows,'complete':len(rows)==48 and not changed and all(r['status']!='error'for r in rows)});print('DONE',len(rows),calls,moves,round(time.monotonic()-START,3),'source_changed',changed,flush=True)


