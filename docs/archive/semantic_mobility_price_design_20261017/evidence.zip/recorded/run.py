from pathlib import Path
from dataclasses import replace
from copy import copy
from fractions import Fraction
import sys,json,time,hashlib,traceback,collections
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/price-measure-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig,MATE_THRESHOLD
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
START=time.monotonic();calls=0

def check():
 if time.monotonic()-START>=900:raise TimeoutError('Frozen900s total cap')
 for name in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('Explicit project stop')
def canonical(v):return json.dumps(record_value(v),sort_keys=True,separators=(',',':'))
def decode(a):
 if not a:return PassAction()
 if 'from_square' in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def root_shift(score):return score-1 if score>=MATE_THRESHOLD else score+1 if score<=-MATE_THRESHOLD else score
cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
compiled={z['family']:replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(z['rule']))),_legacy_compiled=None)for z in json.loads((D/'inputs.json').read_bytes())}
ev={};profiles={}
for f,c in compiled.items():
 p,scope=build_semantic_opportunity_profile(c,cfg);profiles[f]={'profile':record_value(p),'scope':scope};ev[f]=SemanticAttackEvaluator(c,p,cfg,backend='core')
write_json(D/'profiles.json',profiles)
assert profiles[0]['profile']['board_value_by_type']==profiles[2]['profile']['board_value_by_type']
old=json.loads((R/'.local_agent/no-progress-context-20261017/product-policy-axis-results.json').read_bytes())['rows'];slots=[]
for origin in (0,2):
 rr=next(z for z in old if z['family']==origin and z['axis']==2 and z['policy_seed']==1977)
 for prefix in (0,2,4,6):
  for family in (0,2):slots.append((origin,prefix,family,rr['actions'][:prefix]))
rows=[]
for index,(origin,prefix,family,actions)in enumerate(slots):
 check();t=time.monotonic();row={'slot':index,'origin_family':origin,'prefix':prefix,'target_family':family,'actions':actions,'status':'started','children':[]};s=GameSession(compiled[family])
 try:
  for a in actions:s.submit(decode(a))
  row['parent']=record_value(s.state);row['record']=record_value(s.to_record());row['parent_position_digest']=hashlib.sha256(canonical(s.state.position).encode()).hexdigest();parent=s.state
  if s.state.terminal_status.is_terminal:row['status']='terminal_parent'
  else:
   legal=s.legal_actions();row['legal_count']=len(legal)
   for a in legal:
    check();child=copy(s);child.submit(a);st=child.state;z={'action':record_value(a),'child':record_value(st),'record':record_value(child.to_record()),'observation':hashlib.sha256(canonical([st.position,st.terminal_status,st.ply_count]).encode()).hexdigest()}
    z['one_ply']=(-terminal_score(st.terminal_status,st.position.side_to_move,1) if st.terminal_status.is_terminal else -ev[family].evaluate(st))
    if st.terminal_status.is_terminal:z.update(reference=z['one_ply'],reference_kind='actual_terminal',query=None)
    else:
     if calls>=1600:raise TimeoutError('Frozen1600call cap')
     player=AlphaBetaPlayer(compiled[family],evaluator_override=ev[family],use_disk_cache=False,use_native_semantic_legality=False,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
     b=child.state;decision=player.choose_action(child,SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));calls+=1
     assert child.state is b
     assert decision.action in child.legal_actions()or decision.choice_kind!='ACTION'
     assert decision.runtime_depth_balanced is not False
     z['query']=record_value(decision)
     if decision.completed_depth==1:z.update(reference=-root_shift(decision.score),reference_kind='finite_D2_material_terminal')
     else:z.update(reference=None,reference_kind='censored_child_call')
    row['children'].append(z)
   assert s.state is parent
   row['status']='complete' if all(x['reference']is not None for x in row['children']) else 'partial_censored'
   counts=collections.Counter(z['observation']for z in row['children']);n=len(row['children']);ng=len(counts)
   for z in row['children']:z['binding_weight']=str(Fraction(1,n));z['observation_weight']=str(Fraction(1,ng*counts[z['observation']]))
   if row['status']=='complete':
    best1=max(z['one_ply']for z in row['children']);best2=max(z['reference']for z in row['children']);ties=[z for z in row['children']if z['one_ply']==best1]
    row['summary']={'D1_best':best1,'D2_best':best2,'D1_ties':len(ties),'D2_ties':sum(z['reference']==best2 for z in row['children']),'D1_tie_nonoptimal':sum(z['reference']<best2 for z in ties),'D1_tie_gap_range':[min(best2-z['reference']for z in ties),max(best2-z['reference']for z in ties)],'legal_observations':ng}
    for weight in ('binding_weight','observation_weight'):
     den=sum(Fraction(z[weight])for z in ties);row['summary'][weight+'_D1_tie_mean_gap']=str(sum(Fraction(z[weight])*(best2-z['reference'])for z in ties)/den)
 except Exception as e:
  row['status']='error';row['failure']={'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()}
 row['seconds']=time.monotonic()-t;rows.append({k:v for k,v in row.items()if k not in ('children','parent','record','actions')});write_json(D/f'slot-{index:02}.json',row);write_json(D/'progress.json',{'planned':16,'rows':rows,'calls':calls,'elapsed_seconds':time.monotonic()-START});print('SLOT',index,origin,prefix,family,row['status'],row.get('legal_count'),row.get('summary'),round(row['seconds'],3),flush=True)
 if row['status']=='error'and row['failure']['type']in('InterruptedError','TimeoutError'):break
write_json(D/'result.json',{'planned':16,'observed':len(rows),'calls':calls,'seconds':time.monotonic()-START,'rows':rows,'complete':len(rows)==16 and all(r['status']in('complete','terminal_parent')for r in rows)})
print('DONE',calls,round(time.monotonic()-START,3),flush=True)
