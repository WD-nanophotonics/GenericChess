from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,hashlib,collections
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/price-measure-20261017';START=time.monotonic()
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig,MAX_STATIC_EVAL
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square

def check():
 if time.monotonic()-START>=180:raise TimeoutError('Reader180s cap')
 for n in('rollout','advisor','slack'):
  v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not v.get('stopped')and not v.get('user_paused')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def key(v):return json.dumps(record_value(v),sort_keys=True,separators=(',',':'))
cs={z['family']:replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(z['rule']))),_legacy_compiled=None)for z in json.loads((D/'inputs.json').read_bytes())};evs={};cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for f,c in cs.items():
 p,_=build_semantic_opportunity_profile(c,cfg);evs[f]=SemanticAttackEvaluator(c,p,cfg,backend='core')
checks=collections.Counter();rows=[]
for i in range(16):
 check();r=json.loads((D/f'slot-{i:02}.json').read_bytes());f=r['target_family'];s=GameSession(cs[f])
 for a in r['actions']:s.submit(decode(a));checks['prefix_edges']+=1
 assert record_value(s.state)==r['parent'];checks['full_parents']+=1
 assert {key(a)for a in s.legal_actions()}=={key(z['action'])for z in r['children']}
 vals=[]
 for z in r['children']:
  check();ch=copy(s);ch.submit(decode(z['action']));assert record_value(ch.state)==z['child'];assert record_value(ch.to_record())==z['record'];checks['full_root_children']+=1;side=s.state.position.side_to_move
  one=terminal_score(ch.state.terminal_status,side,1)if ch.state.terminal_status.is_terminal else -evs[f].evaluate(ch.state)
  assert one==z['one_ply'];checks['one_ply_values']+=1
  if ch.state.terminal_status.is_terminal:reference=one
  else:
   scores=[]
   for j,a in enumerate(ch.legal_actions()):
    if j%16==0:check()
    g=copy(ch);g.submit(a);st=g.state
    score=terminal_score(st.terminal_status,side,2)if st.terminal_status.is_terminal else evs[f].evaluate(st)*(1 if st.position.side_to_move==side else -1)
    if not st.terminal_status.is_terminal:score=max(-MAX_STATIC_EVAL,min(MAX_STATIC_EVAL,score))
    scores.append(score);checks['full_reply_edges']+=1
   assert scores;reference=min(scores)
  assert reference==z['reference'],(i,z['action'],reference,z['reference']);checks['finite_D2_values']+=1;vals.append(reference)
 assert max(vals)==r['summary']['D2_best'];rows.append({'slot':i,'checks':'all values and full states agree','root_children':len(vals)});print('READER',i,len(vals),flush=True)
bad=[]
for p in sorted((D/'consumer-v1-invalid-status').glob('consumer-game-*.json')):
 r=json.loads(p.read_bytes());assert r['session_result']['status']=='ongoing'and r['status']=='actual_terminal'and len(r['moves'])==1;bad.append(r['game'])
assert len(bad)==48
result={'checks':dict(checks),'rows':rows,'bad_original_labels_confirmed':len(bad),'bad_status':'ALL48 firstattempt ongoing states mislabelled actual_terminal, reward0 INVALID; no draw or fullgame claim.','seconds':time.monotonic()-START,'authority':'ExistingCore public replay/enumeration+separate arithmetic, not independent rules or solver.','search_calls':0,'new_games':0}
write_json(D/'reader-result.json',result);print(json.dumps(result,indent=2),flush=True)
