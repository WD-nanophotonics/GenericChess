from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,collections
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/price-measure-20261017';START=time.monotonic()
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square

def check():
 assert time.monotonic()-START<120
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[];oldchecks=0;newchecks=0
first=json.loads((D/'slot-00.json').read_bytes());capture=next(z['action']for z in first['children']if z['one_ply']==first['summary']['D1_best'])
for inp in json.loads((D/'inputs.json').read_bytes()):
 f=inp['family'];c=replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(inp['rule']))),_legacy_compiled=None);p,scope=build_semantic_opportunity_profile(c,cfg);board=dict(p.board_value_by_type);hand=dict(p.hand_value_by_base_type);board['R']-=100;board['TP']-=100;hand['R']+=100
 assert all(v>0 for k,v in board.items()if k!='K')and hand['R']>0
 pp={t:replace(v,normalized_board_value=board[t],normalized_hand_value=hand[t])for t,v in p.piece_profiles.items()};altered=replace(p,board_value_by_type=board,hand_value_by_base_type=hand,piece_profiles=pp);evs={'original':SemanticAttackEvaluator(c,p,cfg,backend='core'),'positive_null_shift':SemanticAttackEvaluator(c,altered,cfg,backend='core')}
 for i in range(16):
  r=json.loads((D/f'slot-{i:02}.json').read_bytes())
  if r['target_family']!=f:continue
  s=GameSession(c)
  for a in r['actions']:s.submit(decode(a))
  assert evs['original'].evaluate(s.state)==evs['positive_null_shift'].evaluate(s.state)
  for z in r['children']:
   check();ch=copy(s);ch.submit(decode(z['action']));assert evs['original'].evaluate(ch.state)==evs['positive_null_shift'].evaluate(ch.state);oldchecks+=1
 s=GameSession(c);s.submit(decode(capture));assert PassAction()in s.legal_actions();s.submit(PassAction());assert not s.state.terminal_status.is_terminal;row={'family':f,'prefix':[capture,{}],'parent':record_value(s.state),'record':record_value(s.to_record()),'profiles':{'original':record_value(p),'positive_null_shift':record_value(altered)},'children':[],'decisions':[]}
 for a in s.legal_actions():
  check();ch=copy(s);ch.submit(a);row['children'].append({'action':record_value(a),'child':record_value(ch.state),'scalars':{name:e.evaluate(ch.state)for name,e in evs.items()},'is_drop':isinstance(a,SemanticDropMove)});newchecks+=1
 for depth in(1,2):
  for name,e in evs.items():
   check();before=s.state;player=AlphaBetaPlayer(c,evaluator_override=e,use_disk_cache=False,use_native_semantic_legality=False,use_tt=False,use_ordering=False,tuning=SearchTuning(require_full_pv=True));v=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));assert s.state is before;row['decisions'].append({'depth':depth,'table':name,'decision':record_value(v),'chosen_drop':isinstance(v.action,SemanticDropMove)})
 rows.append(row);print('WITNESS',f,len(row['children']),sum(x['is_drop']for x in row['children']),[(x['depth'],x['table'],x['chosen_drop'],x['decision']['score'],x['decision']['completed_depth'])for x in row['decisions']],flush=True)
write_json(D/'drop-direction-result.json',{'complete':True,'old_full_child_scalar_equalities':oldchecks,'new_full_children':newchecks,'queries':8,'rows':rows,'seconds':time.monotonic()-START,'scope':'Allpositive unfitted numeric perturbation identifies observation-design ambiguity, not utility/strength, all-domain invariance or a newprofilecandidate/default.'})
