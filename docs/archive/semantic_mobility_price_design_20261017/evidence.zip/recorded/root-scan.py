from pathlib import Path
from dataclasses import replace
from copy import copy
import sys
import json
import time
R = Path.cwd()
sys.path.insert(0, str(R))
D = R / '.local_agent/price-measure-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove, SemanticDropMove, PassAction
from generic_chess.core.coordinates import Square

start = time.monotonic()
inputs = json.loads((D / 'fresh-transfer/consumer-inputs.json').read_bytes())
selected = json.loads((D / 'D0-attribution.json').read_bytes())['selected']
rows = []

def check():
    if time.monotonic() - start >= 90:
        raise TimeoutError('Frozen90s diagnostic cap')
    for name in ('rollout', 'advisor', 'slack'):
        f = json.loads((R / '.local_agent' / f'{name}.json').read_bytes())
        if f.get('stopped') or f.get('user_paused'):
            raise InterruptedError('Explicit project stop')

def decode(a):
    if not a:
        return PassAction()
    if 'from_square' in a:
        return SemanticBoardMove(a['pattern_id'], a['geometry_id'], a['actor_type_id'], Square(**a['from_square']), Square(**a['to_square']), a['promotion_target_id'])
    return SemanticDropMove(a['pattern_id'], a['geometry_id'], a['base_type_id'], Square(**a['to_square']))

for index, chosen in enumerate(selected):
    check()
    family = chosen['family']
    definition = next(z['rule'] for z in inputs if z['family'] == family)
    c = replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(definition))), _legacy_compiled=None)
    s = GameSession(c)
    for a in chosen['prefix']:
        s.submit(decode(a))
    assert record_value(s.state) == chosen['original_parent']
    cfg = replace(EvaluationConfig(), anchor_escape_weight=0, promotion_potential_weight=0)
    p, scope = build_semantic_opportunity_profile(c, cfg)
    evaluator = SemanticAttackEvaluator(c, p, cfg, backend='core')
    arms = []
    for enabled in ((True, False) if index % 2 == 0 else (False, True)):
        check()
        player = AlphaBetaPlayer(c, evaluator_override=evaluator, use_disk_cache=False, use_native_semantic_legality=False, tuning=SearchTuning(require_full_pv=True, use_root_tactical=enabled))
        before = s.state
        decision = player.choose_action(s, SearchLimits(max_depth=3, max_nodes=4096, max_time_seconds=0.5, quiescence_max_depth=0, quiescence_hard_max_depth=0))
        assert s.state is before
        write_json(D / f'root-scan-call-{index}-{int(enabled)}.json', {'family': family, 'tactical': enabled, 'decision': record_value(decision), 'parent': record_value(s.state), 'reply_scan': 'not_yet_completed'})
        ch = copy(s)
        ch.submit(decision.action)
        replies = []
        actor = s.state.position.side_to_move
        if not ch.state.terminal_status.is_terminal:
            for a in ch.legal_actions():
                check()
                g = copy(ch)
                g.submit(a)
                replies.append({'action': record_value(a), 'terminal': record_value(g.state.terminal_status), 'state_history_length': len(g.state.history)})
        exposure = sum(z['terminal']['winner'] == 1 - actor for z in replies)
        arms.append({'root_tactical': enabled, 'decision': record_value(decision), 'selected_child': record_value(ch.state), 'actual_winning_opponent_replies': exposure, 'all_replies': replies})
    row = {'family': family, 'original_game': chosen['game'], 'ply': chosen['ply'], 'arms': arms}
    rows.append(row)
    print('SCAN_PAIR', family, [(a['root_tactical'], a['decision']['completed_depth'], a['decision']['result_source'], a['actual_winning_opponent_replies']) for a in arms], flush=True)

write_json(D / 'root-scan-result.json', {
    'planned_calls': 8, 'executed_calls': 2 * len(rows), 'missing_calls': 8 - 2 * len(rows),
    'missing_reason': 'Only3 distinct eligible time-limit scan-fallback families; no fourth family substituted from real root wins or other failures.',
    'rows': rows, 'seconds': time.monotonic() - start,
    'scope': 'Cold selected failure diagnosis with existing flag, not default adoption, warm-TT reproduction, all-domain or strength result. One-reply exposure is exact only for listed child states.',
})
print('DONE', 2 * len(rows), time.monotonic() - start, flush=True)
