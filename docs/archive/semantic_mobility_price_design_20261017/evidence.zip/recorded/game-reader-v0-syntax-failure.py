from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,collections,hashlib
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/price-measure-20261017';START=time.monotonic()
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.result import SessionStatus
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square

def check():
 if time.monotonic()-START>240:raise TimeoutError('Game reader240s cap')
 for n in('rollout','advisor','slack'):
  v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not v.get('stopped')and not v.get('user_paused')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
paths=[D,D/'fresh-transfer',D/'fresh-transfer/missing-atom-repair'];counts=collections.Counter();cases=[]
for base in paths:
 inputs=json.loads((base/'consumer-inputs.json').read_bytes());compiled={}
 for inp in inputs:
  r=deserialize_ruleset(json.dumps(inp['rule']));compiled[inp['family']]=replace((compile_semantic_ruleset(r)if r.semantic_actions else compile_legacy_ruleset_for_semantic_execution(r)),_legacy_compiled=None)
 for p in sorted(base.glob('consumer-game-*.json')):
  check();row=json.loads(p.read_bytes());s=GameSession(compiled[row['family']]);assert record_value(s.state)==row['initial_state'];counts['initial_states']+=1
  for move in row['moves']:
   check();v=move['decision'];assert move['actor']==s.state.position.side_to_move;assert move['candidate']==(move['actor']==row['candidate_owner']);assert v['native_legality_calls']==0;assert v['runtime_depth_balanced']is not False
   pv=copy(s)
   for a in v['principal_variation']:
    pv.submit(decode(a));assert len(pv.state.history)==pv.state.ply_count+1;counts['PV_edges']+=1
   assert v['choice_kind']=='ACTION';a=decode(v['action']);assert a in s.legal_actions();s.submit(a);assert record_value(s.state)==move['child'];assert len(s.state.history)==s.state.ply_count+1;counts['full_game_edges']+=1
  assert record_value(s.to_record())==row['record'];assert record_value(s.result)==row['session_result'];counts['records']+=1
  if row['status']=='actual_terminal':
   assert s.result.status is not SessionStatus.ONGOING;reward=0 if s.result.winner is None else 1 if s.result.winner==row['candidate_owner']else-1;assert reward==row['reward'];counts['actual_terminals']+=1
  elif row['status'].endswith('_UNKNOWN'):
   assert s.result.status is SessionStatus.ONGOING and row['reward']is None;expected=64 if'64ply'in row['status']else32;assert len(row['moves'])==expected;counts['administrative_UNKNOWN']+=1
  else:assert row['status']=='error';counts['error_records']+=1
  cases.append({'source':str(base.relative_to(D)).replace('\\','/'),'game':row['game'],'family':row['family'],'arm':row['arm'],'owner':row['candidate_owner'],'status':row['status'],'plies':len(row['moves'])});print('GAME_READ',str(base.relative_to(D)),row['game'],len(row['moves']),flush=True)
write_json(D/'game-reader-result.json',{'counts':dict(counts),'cases':cases,'seconds':time.monotonic()-START,'new_search_calls':0,'new_games':0,'scope':'Recorded full public histories/PVs/terminals/UNKNOWN replay; sameCore source authority, not independent optimal-WDL or a rerunofoldpolicy/clocks.'});print('DONE',dict(counts),time.monotonic()-START,flush=True)
