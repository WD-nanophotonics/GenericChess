from pathlib import Path
from dataclasses import replace
from copy import copy
import sys
import json
import time
R = Path.cwd()
sys.path.insert(0, str(R))
D = R / '.local_agent/price-measure-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove, SemanticDropMove, PassAction
from generic_chess.core.coordinates import Square
start = time.monotonic()
plan = json.loads((D / 'root-startup-contract-plan.json').read_bytes())
inputs = json.loads((D / 'fresh-transfer/consumer-inputs.json').read_bytes())
rows = []

def check():
    if time.monotonic() - start >= 120:
        raise TimeoutError('Startup contract120s cap')
    for name in ('rollout', 'advisor', 'slack'):
        f = json.loads((R / '.local_agent' / f'{name}.json').read_bytes())
        if f.get('stopped') or f.get('user_paused'):
            raise InterruptedError('Explicit project stop')

def decode(a):
    if not a:
        return PassAction()
    if 'from_square' in a:
        return SemanticBoardMove(a['pattern_id'], a['geometry_id'], a['actor_type_id'], Square(**a['from_square']), Square(**a['to_square']), a['promotion_target_id'])
    return SemanticDropMove(a['pattern_id'], a['geometry_id'], a['base_type_id'], Square(**a['to_square']))

for index, selected in enumerate(plan['roots']):
    check()
    definition = next(z['rule'] for z in inputs if z['family'] == selected['family'])
    c = replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(definition))), _legacy_compiled=None)
    s = GameSession(c)
    for encoded in selected['prefix']:
        check()
        s.submit(decode(encoded))
    assert record_value(s.state) == selected['original_parent']
    side = s.state.position.side_to_move
    known = None
    if selected['kind'] == 'actual_immediate_win_control':
        witness = copy(s)
        witness.submit(decode(selected['known_win_action']))
        assert witness.state.terminal_status.winner == side
        known = record_value(witness.state)
    cfg = replace(EvaluationConfig(), anchor_escape_weight=0, promotion_potential_weight=0)
    profile, scope = build_semantic_opportunity_profile(c, cfg)
    evaluator = SemanticAttackEvaluator(c, profile, cfg, backend='core')
    arms = []
    for enabled in ((True, False) if index % 2 == 0 else (False, True)):
        check()
        player = AlphaBetaPlayer(c, evaluator_override=evaluator, use_disk_cache=False, use_native_semantic_legality=False, tuning=SearchTuning(require_full_pv=True, use_root_tactical=enabled))
        before = s.state
        decision = player.choose_action(s, SearchLimits(max_depth=3, max_nodes=4096, max_time_seconds=.5, quiescence_max_depth=0, quiescence_hard_max_depth=0))
        assert s.state is before
        child = copy(s)
        child.submit(decision.action)
        arm = {'enabled': enabled, 'decision': record_value(decision), 'selected_child': record_value(child.state), 'actual_own_terminal_win': child.state.terminal_status.winner == side}
        arms.append(arm)
        write_json(D / f'root-startup-contract-call-{index}-{int(enabled)}.json', {'root': selected, 'arm': arm, 'known_win_child': known})
    rows.append({'family': selected['family'], 'ply': selected['ply'], 'kind': selected['kind'], 'arms': arms})
    write_json(D / 'root-startup-contract-progress.json', {'rows': rows, 'seconds': time.monotonic() - start})
    print('STARTUP_PAIR', selected['family'], selected['kind'], [(x['enabled'], x['decision']['completed_depth'], x['decision']['result_source'], x['actual_own_terminal_win']) for x in arms], flush=True)
write_json(D / 'root-startup-contract-result.json', {'complete': len(rows) == 5, 'calls': 2 * len(rows), 'rows': rows, 'seconds': time.monotonic() - start, 'scope': 'Actual cold full-parent existing-flag contract/completion controls; no exhaustive opponent-reply safety, new games, default or strength claim.'})
print('DONE', 2 * len(rows), time.monotonic() - start, flush=True)
