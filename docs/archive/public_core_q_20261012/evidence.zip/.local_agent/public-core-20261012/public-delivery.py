"""Unmodified public Core q4 PVS/AB delivery; research probe curve is reused."""
import sys,runpy,time,inspect,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'))
p=m['p'];sm=m['sm'];Runtime=m['Runtime'];h=m['m'];record=m['record'];write=m['write'];out=Path(sys.argv[1])
def run():
 out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
 write(out/'declaration.json',dict(question='Does existing PVS change delivered support in the actual unmodified public Core q consumer, and does the earlier research transport gain require a private consumer?',root=1091,calls=16,budgets=[1,16,64,256],depth=12,nodes=1000000,q=4,hardq=8,arms=['raw_ab','raw_pvs'],orders=['ab,pvs','pvs,ab'],tt='fresh default TT/player per call',leaf='same Native semantic attack frozen rules profile',backends='same opt-in Native legality/availability; no monkeypatch of q scheduling or collection',ordering='unmodified public default main/q order',expected_max_search_seconds=1348,expected_minutes='under24 including setup',old_curve='reuse prior completed probe PVS/AB1/16/64/256 as contextual supported-depth evidence, not same-machine paired speedup',decision='Complete value/action legality first; completed q/depth/source, counters/cost then next consumer choice. No strength/default/UI claim or cap extension. Full generated target retained; one exposed active auxiliary root.',q_source_sha256=hashlib.sha256(inspect.getsource(sm._quiescence_runtime).encode()).hexdigest()))
 write(out/'sample.json',m['sample']);old=Runtime.attach_stats;rows=[]
 try:
  for budget in [1,16,64,256]:
   for order,flags in enumerate([[False,True],[True,False]]):
    for flag in flags:
     p.rr.stopped();rtrows=[]
     def attach(rt,stats):
      value=old(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return value
     Runtime.attach_stats=attach
     ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native')
     player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=h['SearchTuning'](use_pvs=flag))
     t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=budget,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
     for rt,before in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==before
     rows.append(dict(order=order,pvs=flag,budget=budget,seconds=elapsed,decision=record(r),root_restored=True,actual_legality=dict(fallbacks=rtrows[0][0].legal_provider_fallbacks,failures=rtrows[0][0].legal_provider_operational_failures),availability=player.native_legality_provider.availability_metrics))
     write(out/'result.json',dict(complete=False,rows=rows));print(order,flag,budget,round(elapsed,3),r.completed_depth,r.result_ordinary_qdepth,r.score,r.nodes,r.qnodes,r.termination_reason,flush=True)
 finally:Runtime.attach_stats=old
 write(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run()
