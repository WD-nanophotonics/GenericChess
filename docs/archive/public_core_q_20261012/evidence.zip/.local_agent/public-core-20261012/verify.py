from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parent;root=b.parents[1]
read=lambda p:json.loads(p.read_bytes())
paths=[(root/'.local_agent/cancel-contract-20261012/public-caller/result.json',8)]
paths.extend((b/name/'result.json',n) for name,n in [('public-delivery',16),('factorial',8),('quiet-python-availability',4),('quiet-delivery',4),('combined-delivery',4),('forced-action',8),('ordered-fixed',4),('ordered-delivery',4),('mature-recovered',8)])
results={}
for path,n in paths:
 x=read(path);assert x['complete'] and len(x['rows'])==n
 assert all(r.get('root_restored',True) and r.get('legal',True) for r in x['rows'])
 results[path.relative_to(root).as_posix()]={'rows':n,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
old=read(root/'.local_agent/cancel-contract-20261012/public-caller/result.json')['rows'][0]['decision']
for name in ['factorial','quiet-python-availability','ordered-fixed']:
 for r in read(b/name/'result.json')['rows']:
  assert r['decision']['completed_depth']==2 and r['decision']['score']==-2416
  assert (r['decision']['action'],r['decision']['principal_variation'])==(old['action'],old['principal_variation'])
  assert r['actual_legality']['fallbacks']==r['actual_legality']['failures']==0
summary={'complete':True,'primary_search_rows':68,'core_search_rows':60,'stockfish_search_rows':8,'independent_saved_aux_games_replayed':484,'replayed_aux_search_records':3666,'row_scope':'top-level primary physical searches; forced branches restricted diagnostic calls, tests/subcalls separate; auxiliary replay adds no new games','results':results,'paired_delivery':{},'tests':{'relevant_earlier_passed':118,'final_session_passed':28,'publisher_total_expected':122},'limits':['one exposed active auxiliary root','fixed q4/hard8; no whole-domain/strength/WDL claim','ordinary concurrent load; paired reverse controls, no exclusive-machine claim','forced completed_depth describes restricted branch, not whole-root optimum','saved AUX replay not independent engine reproduction; per-seed endpoint freeze only']}
for name in ['public-delivery','quiet-delivery','combined-delivery','ordered-delivery']:
 summary['paired_delivery'][name]=[{'order':r['order'],'arm':r.get('arm',r.get('pvs')),'budget':r.get('budget',64),'seconds':r['seconds'],'depth':r['decision']['completed_depth'],'q':r['decision']['result_ordinary_qdepth'],'score':r['decision']['score'],'reason':r['decision']['termination_reason'],'action':r['decision']['action']} for r in read(b/name/'result.json')['rows']]
summary['forced_branch']=[{'parent_depth':r['parent_depth'],'action':r['forced_action'],'score':r['forced_branch']['score'],'seconds':r['seconds']} for r in read(b/'forced-action/result.json')['rows']]
(b/'verification.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print({'verified_primary_search_rows':68,'ordered_curve':summary['paired_delivery']['ordered-delivery'],'artifact_roots':len(paths)})
