"""Limited forced-action diagnostic in the actual parent iterative q context."""
import sys,runpy,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));p=m['p'];sm=m['sm'];h=m['m'];Runtime=m['Runtime'];write=m['write'];record=m['record'];out=Path(__file__).resolve().parent/'forced-action'
def run():
 out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
 actions={name:next(a for a in m['s'].legal_actions() if record(a)==r['decision']['action']) for name,r in [('D1',__import__('json').loads((ROOT/'.local_agent/public-core-20261012/public-delivery/result.json').read_bytes())['rows'][0]),('D2',__import__('json').loads((ROOT/'.local_agent/cancel-contract-20261012/public-caller/result.json').read_bytes())['rows'][0])]}
 write(out/'declaration.json',dict(question='Does the observed D1-to-D2 move change have a decision-relevant value difference under the already completed parentD2/q4 andD3/q4 semantics?',root=1091,parent_depths=[2,3],actions={k:record(a) for k,a in actions.items()},calls=8,orders=['D1,D2','D2,D1'],tt=False,pvs=False,nodes=1000000,seconds=120,q=4,hardq=8,method='Original iterative root caller runs earlier iterations normally; at declared final parent depth, force ONE legal root action, push with full history, original negamax full window at ply1/depth-1 using SAME parent context. No child-root phase reset. Original public q function/tuple consumer. Forced result is NOT whole-root optimization; earlier ordinary search results remain unchanged.',decision='Compare completed forced branches with existing full-root best value. Any cap/hardq remains unknown; do not inflate cap. No WDL/all-defense/stronger-player or API claim. D3 same root choice may only refine value.',expected_max_seconds=960,expected_minutes='under17, typically2-5'))
 old=sm.negamax;oldattach=Runtime.attach_stats;rows=[]
 try:
  for depth in [2,3]:
   for order,names in enumerate([['D1','D2'],['D2','D1']]):
    for name in names:
     p.rr.stopped();action=actions[name];captures=[];rtrows=[]
     def attach(rt,stats):
      value=oldattach(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return value
     Runtime.attach_stats=attach
     def branch(state,d,alpha,beta,ply,ctx,*args,**kwargs):
      if ply!=0 or d!=depth:return old(state,d,alpha,beta,ply,ctx,*args,**kwargs)
      assert sm._ordinary_qdepth_limit(ctx)==4 and action in ctx.runtime.legal_actions(ctx.checkpoint)
      with ctx.runtime.pushed(action,checkpoint=ctx.checkpoint):
       child=old(ctx.runtime.state,d-1,-sm.INF,sm.INF,1,ctx,prev_action=action)
      captures.append(dict(score=-child.score,parent_ordinary_qdepth=sm._ordinary_qdepth_limit(ctx),pv=record((action,)+child.pv),complete=True))
      return sm.SearchResult(-child.score,action,(action,)+child.pv)
     sm.negamax=branch
     try:
      ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native');player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,use_tt=False,tuning=h['SearchTuning'](use_pvs=False))
      t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=depth,max_nodes=1000000,max_time_seconds=120,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
      for rt,before in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==before
      rows.append(dict(parent_depth=depth,order=order,forced_action=name,seconds=elapsed,forced_branch=captures[-1] if captures else None,caller_metadata=record(r),root_restored=True,scope='limited forced branch; caller completed_depth is not whole-root optimum'))
      write(out/'result.json',dict(complete=False,rows=rows));print(depth,order,name,round(elapsed,3),captures[-1]['score'] if captures else None,r.completed_depth,r.termination_reason,flush=True)
     finally:sm.negamax=old;Runtime.attach_stats=oldattach
 finally:sm.negamax=old;Runtime.attach_stats=oldattach
 write(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run()
