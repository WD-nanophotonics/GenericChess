"""Missing single-factor cells; reuse completed raw/both controls."""
import sys,runpy,inspect,textwrap,time
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));p=m['p'];sm=m['sm'];Runtime=m['Runtime'];h=m['m'];write=m['write'];record=m['record'];out=Path(sys.argv[1])
def run():
 out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
 write(out/'declaration.json',dict(question='On the same public tuple Core PVS caller, does only quiet mechanical exclusion change delivered64s support?',root=1091,calls=4,arms=['raw_pvs','quiet_only_pvs'],orders=['forward','reverse'],depth=12,nodes=1000000,seconds=64,q=4,hardq=8,tt='fresh default per call',reuse='raw/both complete counterbalanced D2 cells from public-caller; historical values/work, no paired cross-batch speed proof',decision='Same public Core tuple legality, Native leaf/legality/availability, lexical q, freshTT, PVS/q4/hard8; only quiet guards differ. Same-batch reverse controls. Prior combined D3 is context, not pair. No independent holdout/stronger-move/API/default/UI claim; unfinished iteration excluded. Ordinary concurrent load includes owned public curve.',expected_max_seconds=256,expected_minutes='under5 including setup'))
 original=sm._quiescence_runtime;old=Runtime.attach_stats;rows=[]
 for repeat,arms in enumerate([['raw_pvs','quiet_only_pvs'],['quiet_only_pvs','raw_pvs']]):
  for arm in arms:
   p.rr.stopped();counts=Counter();m['legal'].__globals__['counts']=counts;m['Batch'].__iter__.__globals__['BATCH_SIZE']=8;probe=h['QuietActionProbe'](shadow=False)
   src=textwrap.dedent(inspect.getsource(original))
   if arm.startswith('legal'):src=src.replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)')
   elif not arm.startswith('raw'):src=src.replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
   namespace=dict(sm.__dict__,lazy_legal=m['legal'],lazy_order=m['order'],quiet_drop_probe=probe);exec(compile(src,'<single-factor-existing-q-control>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];rtrows=[]
   def attach(rt,stats):
    value=old(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return value
   Runtime.attach_stats=attach
   try:
    ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native');player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=h['SearchTuning'](use_pvs=arm.endswith('pvs')));t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=64,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
    for rt,before in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==before
    rows.append(dict(order=repeat,arm=arm,seconds=elapsed,decision=record(r),counts=dict(counts),quiet=dict(probe.counts),root_restored=True,actual_legality=dict(fallbacks=rtrows[0][0].legal_provider_fallbacks,failures=rtrows[0][0].legal_provider_operational_failures)))
    write(out/'result.json',dict(complete=False,rows=rows));print(repeat,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,r.qnodes,flush=True)
   finally:sm._quiescence_runtime=original;Runtime.attach_stats=old
 write(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run()
