"""Independent saved-record replay; never launches or writes AUX engine/state."""
import json,hashlib,random,statistics
from pathlib import Path
import chess
AUX=Path(__file__).resolve().parents[3]/'GenericChess-DEV_AUX';OUT=Path(__file__).resolve().parent
read=lambda n:json.loads((AUX/n).read_bytes())
def score(board,color,n,cap=16):
 own=sum(len(board.pieces(k,color)) for k in range(1,6));other=sum(len(board.pieces(k,not color)) for k in range(1,6));outcome=board.outcome(claim_draw=False)
 terminal=0 if outcome is None or outcome.winner is None else (100 if outcome.winner==color else -100)
 speed=0 if outcome is None or outcome.winner is None else (1 if outcome.winner==color else -1)*(cap-n)/cap
 cutoff=(own-other)/15 if outcome is None else 0
 return dict(reward=terminal+speed+cutoff,quantity_difference=own-other,agent_quantity=own,opponent_quantity=other,terminal_component=terminal,mate_speed_component=speed,cutoff_quantity_component=cutoff,terminal=outcome is not None,termination='cutoff' if outcome is None else outcome.termination.name,winner=None if outcome is None else outcome.winner,proxy_result=None if outcome is not None else (1 if own>other else -1 if own<other else 0),played_plies=n,cap=cap)
def replay(row):
 w=row['weights'];ctx=row['context'];game=row['result'];board=chess.Board();rng=random.Random(ctx['opening_seed']);opening=[]
 for _ in range(6):
  move=rng.choice(sorted(board.legal_moves,key=lambda m:m.uci()));opening.append(move.uci());board.push(move)
 assert opening==game['opening']
 probes={x['type']:x for x in game['candidate_leaf_probes']};assert set(probes)==set('PNBRQ')
 for k,x in probes.items():assert x['expected_white_pawns']==w[k]/w['P'] and abs(x['measured_white_pawns']-w[k]/w['P'])<=.011
 records=iter(game['search_records']);nr=0;rng=random.Random(ctx['random_seed']);node_counts=[]
 for uci in game['actions']:
  assert not board.is_game_over(claim_draw=False);move=chess.Move.from_uci(uci);assert move in board.legal_moves
  if board.turn==ctx['agent_color']:
   sr=next(records);nr+=1;assert sr['full_history']==[m.uci() for m in board.move_stack]
   assert sr['backend'] in {prefix+':477628ae141c6e5fb7dcb562e31e3bc40eab95b20c8b966ece131a1dbf090999' for prefix in ['QUALIFIED_FAIRY_BINARY','QUALIFIED_FAIRY_MATERIAL']};assert sr['nodes_limit']==1024
   node_counts.append(sr['reported_nodes'])
  else:assert move==rng.choice(sorted(board.legal_moves,key=lambda m:m.uci()))
  board.push(move)
 assert next(records,None) is None and board.fen()==game['final_fen'] and len(game['actions'])<=16
 expected=score(board,ctx['agent_color'],len(game['actions']));assert expected==game['score'] and expected['reward']==game['reward']
 return dict(name=ctx['name'],plies=len(game['actions']),searches=nr,reported_nodes_min=min(node_counts),reported_nodes_max=max(node_counts),score=expected)
def run():
 pilot=read('results/dev_aux/task120/pilot16/pilot.json');assert pilot['complete'];pilotrows=[replay(r) for r in pilot['rows']]
 declaration=read('results/dev_aux/task121/declaration.json');controller=read('results/dev_aux/task121/controller.json');assert controller['completed'];assert len(controller['calls'])==480
 hashes={k:hashlib.sha256((AUX/k).read_bytes()).hexdigest()==v for k,v in declaration['source_hashes'].items()};assert all(hashes.values())
 replayed=[replay(r) for r in controller['calls']];byname={r['context']['name']:r for r in controller['calls']};summary=[]
 for run in controller['runs']:
  seed=run['seed'];initial=run['initial_weights'];final=run['final_weights'];assert len(run['iterations'])==6
  for iteration in run['iterations']:
   means=[]
   for arm in range(3):
    rewards=[byname[f's{seed}-g{iteration["generation"]}-a{arm}-o{o}-c{int(color)}']['result']['reward'] for o in range(4) for color in (True,False)]
    assert rewards==iteration['rewards'][arm];means.append(sum(rewards)/8)
   assert means==iteration['means'];best=max(range(3),key=lambda i:means[i]);selected=best if means[best]>means[0] else 0;assert selected==iteration['selected']
  held={arm:[byname[f's{seed}-heldout-a{arm}-o{o}-c{int(color)}'] for o in range(4) for color in (True,False)] for arm in ['initial','final']}
  for arm,rows in held.items():assert all(r['weights']==(initial if arm=='initial' else final) for r in rows)
  diff=[f['result']['reward']-i['result']['reward'] for i,f in zip(held['initial'],held['final'])]
  qdiff=[f['result']['score']['cutoff_quantity_component']-i['result']['score']['cutoff_quantity_component'] for i,f in zip(held['initial'],held['final'])]
  tidx=[i for i,r in enumerate(controller['calls']) if r['context']['phase']=='train' and r['context']['name'].startswith(f's{seed}-')];hidx=[i for i,r in enumerate(controller['calls']) if r['context']['phase']=='heldout' and r['context']['name'].startswith(f's{seed}-')];assert max(tidx)<min(hidx)
  summary.append(dict(seed=seed,initial_ratios={k:initial[k]/208 for k in 'NBRQ'},final_ratios={k:final[k]/208 for k in 'NBRQ'},selected_updates=sum(x['selected']!=0 for x in run['iterations']),paired_heldout_rewards=diff,mean_reward_change=statistics.mean(diff),median_reward_change=statistics.median(diff),mean_cutoff_quantity_component_change=statistics.mean(qdiff),initial_terminal=sum(x['result']['score']['terminal'] for x in held['initial']),final_terminal=sum(x['result']['score']['terminal'] for x in held['final']),initial_mates=sum(x['result']['score']['termination']=='CHECKMATE' for x in held['initial']),final_mates=sum(x['result']['score']['termination']=='CHECKMATE' for x in held['final']),individual_endpoint_frozen_before_its_heldout=True))
 idx={phase:[i for i,r in enumerate(controller['calls']) if r['context']['phase']==phase] for phase in ['train','heldout']};all_frozen=max(idx['train'])<min(idx['heldout'])
 result=dict(complete=True,pilot_games=4,replayed_games=480,actual_search_records=sum(r['searches'] for r in replayed),declared_source_hashes_match=hashes,summaries=summary,all_three_endpoints_frozen_before_any_heldout=all_frozen,holdout_order_limit='Actually per-seed freeze/holdout; no global freeze of all endpoints before any heldout. Source has no cross-seed heldout selection feedback; do not claim stronger ordering.',source_files={n:hashlib.sha256((AUX/n).read_bytes()).hexdigest() for n in ['results/dev_aux/task120/pilot16/pilot.json','results/dev_aux/task121/controller.json','results/dev_aux/task121/status.json','results/dev_aux/task121/declaration.json']},scope='Independent record legality/history/random-opponent/reward/config/selection arithmetic replay, not independent live engine search or human-price recovery. No auxiliary writes/launches or product changes.')
 (OUT/'aux-independent-replay.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:result[k] for k in ['complete','replayed_games','actual_search_records','summaries','all_three_endpoints_frozen_before_any_heldout']},indent=2))
if __name__=='__main__':run()
