"""Recovered original Stockfish overall reference; no aligned-leaf claim."""
import ast,sys,json,hashlib,time,queue,subprocess,threading
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,ChessBoard
from scripts.research_record import write_record
original=ROOT/'.local_agent/search-attribution-20261010/mature_controls.py'
node=next(n for n in ast.parse(original.read_text(encoding='utf-8')).body if isinstance(n,ast.ClassDef) and n.name=='Protocol')
ns=dict(queue=queue,subprocess=subprocess,threading=threading,perf_counter=time.perf_counter);exec(compile(ast.Module(body=[node],type_ignores=[]),str(original),'exec'),ns);Protocol=ns['Protocol'];out=Path(__file__).resolve().parent/'mature-recovered';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists();binary=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe';sha=hashlib.sha256(binary.read_bytes()).hexdigest();assert sha=='55aa40c857de30b79dbe4f8e4c335ee2b23815cf2f100a6630d54761fcad3b85'
write_record(out/'declaration.json',dict(question='Does the restored original mature entry actually search supported existing Chess roots, rather than merely completing a handshake?',changed_premise='confirmed SACOff and prior UCI/isready actualpass',cases=[c['id'] for c in CASES if c['game']=='chess'],calls=8,movetime_ms=250,threads=1,hash_MiB=16,binary_sha256=sha,scope='Original unmodified Stockfish default evaluation; overall reference only. Leaf/pruning/qdepth/draw policies unaligned with generic semantic attack. No strength/Elo/material-only claim. Known unsupported Shogi build is not retried.',expected_seconds='search2 plus protocol/setup, under1minute'))
rows=[];engine=None
try:
 engine=Protocol(binary,'uci');names={x.split('option name ',1)[1].split(' type ',1)[0] for x in engine.handshake if x.startswith('option name ')};assert {'Threads','Hash'}<=names
 engine.send('setoption name Threads value 1');engine.send('setoption name Hash value 16')
 for case in [c for c in CASES if c['game']=='chess']:
  board=ChessBoard(case);legal={label for label,_ in board.actions()}
  for repeat in range(2):
   engine.send('ucinewgame');engine.send('isready');engine.until(lambda x:x=='readyok')
   command='position startpos' if case['setup']=='start' else 'position fen '+case['setup']
   if case['moves']:command+=' moves '+case['moves']
   engine.send(command);t=time.perf_counter();engine.send('go movetime 250');lines=engine.until(lambda x:x.startswith('bestmove '));elapsed=time.perf_counter()-t;move=lines[-1].split()[1];assert move in legal
   info=[]
   for line in lines:
    f=line.split()
    if f[:1]==['info'] and 'depth' in f:
     d={}
     for k in ['depth','seldepth','nodes','nps','time']:
      if k in f:d[k]=int(f[f.index(k)+1])
     if 'score' in f:i=f.index('score');d['score_type']=f[i+1];d['score']=int(f[i+2]);d['bound']='lowerbound' if 'lowerbound'in f else 'upperbound' if 'upperbound'in f else None
     if 'pv'in f:
      d['pv']=f[f.index('pv')+1:];b=board.board.copy(stack=True)
      for u in d['pv']:b.push_uci(u)
     info.append(d)
   rows.append(dict(case=case['id'],repeat=repeat,move=move,legal=True,seconds=elapsed,info=info,source='same preserved unmodified binary default NNUE/engine options',full_history=case['moves'].split()));write_record(out/'result.json',dict(complete=False,rows=rows));print(case['id'],repeat,move,round(elapsed,3),info[-1] if info else None,flush=True)
finally:
 if engine is not None:engine.close()
write_record(out/'result.json',dict(complete=True,rows=rows,handshake=engine.handshake,observed_eval_messages=sorted(set(x for x in engine.raw if x.startswith('info string'))),binary_sha256=sha,cleanup='owned engine close completed',comparison_scope='unaligned overall reference; reported engine depth/nodes not generic q4 work'))
