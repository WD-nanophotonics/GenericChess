"""Existing PVS/full-window Core q4 scheduling; no new search implementation."""
import sys,runpy,json,inspect,textwrap,time
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/aux-quiet-20261012/filtered-transfer-producer.py'));p=m['p'];ns=m['ns'];sm=m['search_module'];Runtime=m['SearchPathRuntime'];legal=m['legal'];order=m['order'];Batch=m['BatchLegal'];write=m['write_record'];record=m['record_value']
from generic_chess.rules.schema import ruleset_from_dict
key=sys.argv[2];kind=sys.argv[3]
source='active-mixed-premise.json' if key=='1091' else 'mixed-premise.json';sample=next(x for x in json.loads((ROOT/'.local_agent/aux-quiet-20261012'/source).read_text()) if str(x['seed'])==key);c=m['compile_ruleset_for_execution'](ruleset_from_dict(sample['rules']));s=p.GameSession(c)
for _ in range(4):
 aa=s.legal_actions();aux=[a for a in aa if 'promotion_grants_one_turn_right' in a.pattern_id];s.submit(aux[0] if aux else sorted(aa,key=repr)[0])
assert record(s.state)==sample['state'] and record(s._search_witnesses)==sample['witnesses'];ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
def run(out):
 out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists();fixed=kind=='fixed';budgets=[60] if fixed else [1,16,64,256]
 write(out/'declaration.json',dict(question='Does existing Core q4 PVS reduce actual work/cost and increase completed support versus ordinary alpha-beta with the same supported caller?',root=int(key),kind=kind,calls=4*len(budgets),depth=2 if fixed else 12,max_nodes=1000000,budgets=budgets,q=4,hardq=8,ordering='same lexical q / default main ordering',tt='same fresh player default250000 per call; no score reuse between arms',chunk=8,quiet='same full mechanical board+drop guards',arms=['ordinary_ab','pvs'],orders=['ab,pvs','pvs,ab'],decision='Fixed complete value/legality before cost; main/q counts intentionally may differ. Equal-time compare retained completed depth/q/source, never unfinished scores; tie/PV differences qualified, not strength. Preserve all cap/hard-q failure records.',expected_max_search_seconds=240 if fixed else 1348,expected_total_minutes=5 if fixed else 24,scope='Existing exposed1090/1091roots under changed low-cost transport/aux premise; prior old scope PVS results retained and reused as context, not rerun unchanged; actual flag is SearchTuning(use_pvs=...). No new algorithm/kernel/default/UI/product interface. Ordinary concurrent load; fixed call order/caps declared before results.'))
 write(out/'sample.json',sample);original=sm._quiescence_runtime;oldattach=Runtime.attach_stats;rows=[]
 src=textwrap.dedent(inspect.getsource(original)).replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)').replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
 try:
  for seconds in budgets:
   for repeat,flags in enumerate([[False,True],[True,False]]):
    for flag in flags:
     p.rr.stopped();counts=Counter();legal.__globals__['counts']=counts;Batch.__iter__.__globals__['BATCH_SIZE']=8;probe=m['QuietActionProbe'](shadow=False);namespace=dict(sm.__dict__,lazy_legal=legal,lazy_order=order,quiet_drop_probe=probe);exec(compile(src,'<existing-pvs-q4-control>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];rtrows=[]
     def attach(rt,stats):
      v=oldattach(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return v
     Runtime.attach_stats=attach
     try:
      ev=m['CountedSemanticEvaluator'](c,profile,ec,backend='native');player=m['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=m['SearchTuning'](use_pvs=flag));t=time.perf_counter();value=player.choose_action(s,m['SearchLimits'](max_depth=2 if fixed else 12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
      for rt,saved in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==saved
      rows.append(dict(root=int(key),seconds_budget=seconds,order=repeat,pvs=flag,seconds=elapsed,decision=record(value),counts=dict(counts),probe=dict(probe.counts),root_restored=True,actual_legality=dict(fallbacks=rtrows[0][0].legal_provider_fallbacks,failures=rtrows[0][0].legal_provider_operational_failures),availability=player.native_legality_provider.availability_metrics));write(out/'result.json',dict(complete=False,rows=rows));print(key,seconds,repeat,flag,round(elapsed,3),value.completed_depth,value.score,value.nodes,value.qnodes,value.pvs_null_window_searches,value.pvs_researches,value.termination_reason,flush=True)
     finally:Runtime.attach_stats=oldattach
 finally:sm._quiescence_runtime=original;Runtime.attach_stats=oldattach
 write(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run(Path(sys.argv[1]))
