"""Existing public Core API versus research transport, same optional endpoints."""
import sys,runpy,inspect,textwrap,time
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
# This existing producer defines the same1091 root/profile without executing run.
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/pvs-producer.py'));p=m['p'];sm=m['sm'];Runtime=m['Runtime'];legal=m['legal'];Batch=m['Batch'];write=m['write'];record=m['record'];out=Path(sys.argv[1])
def run():
 out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
 write(out/'declaration.json',dict(question='Does PVS value/work gain require private q transport, and is the existing public Core caller a concrete consumer?',root=1091,calls=8,depth=2,nodes=1000000,seconds=120,q=4,hardq=8,arms=['raw_ab','probe_ab','raw_pvs','probe_pvs'],orders=['forward','reverse'],leaf='same strict Native semantic attack evaluator/frozen profile',backends='same opt-in Native legality and availability; public AlphaBetaPlayer API, not frozen UI profile',tt='fresh default TT per call',decision='Compare complete value/action/PV and q/main work; raw public tuple consumer versus bundled research full logical chunk8+quiet guards. Not isolated primitive/cancel-latency speed, no default/UI/API adoption.',expected_max_seconds=960,expected_minutes='under17, typically3-5',scope='One existing exposed active aux root; original unmodified _quiescence_runtime versus previous research function; no new algorithm or iterator API. Normal concurrent load, no cap extension if incomplete.'))
 original=sm._quiescence_runtime;oldattach=Runtime.attach_stats;rows=[]
 src=textwrap.dedent(inspect.getsource(original)).replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)').replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
 try:
  for repeat,arms in enumerate([['raw_ab','probe_ab','raw_pvs','probe_pvs'],['probe_pvs','raw_pvs','probe_ab','raw_ab']]):
   for arm in arms:
    p.rr.stopped();counts=Counter();legal.__globals__['counts']=counts;Batch.__iter__.__globals__['BATCH_SIZE']=8;probe=m['m']['QuietActionProbe'](shadow=False);runtimes=[]
    if arm.startswith('raw'):sm._quiescence_runtime=original
    else:
     namespace=dict(sm.__dict__,lazy_legal=legal,lazy_order=m['order'],quiet_drop_probe=probe);exec(compile(src,'<public-core-probe-control>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime']
    def attach(rt,stats):
     v=oldattach(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return v
    Runtime.attach_stats=attach
    try:
     h=m['m'];ev=h['CountedSemanticEvaluator'](m['c'],m['profile'],m['ec'],backend='native');player=h['AlphaBetaPlayer'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=h['SearchTuning'](use_pvs=arm.endswith('pvs')));t=time.perf_counter();r=player.choose_action(m['s'],h['SearchLimits'](max_depth=2,max_nodes=1000000,max_time_seconds=120,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
     for rt,before in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==before
     rows.append(dict(order=repeat,arm=arm,seconds=elapsed,decision=record(r),counts=dict(counts),probe=dict(probe.counts),root_restored=True,legality=dict(fallbacks=runtimes[0][0].legal_provider_fallbacks,failures=runtimes[0][0].legal_provider_operational_failures),availability=player.native_legality_provider.availability_metrics));write(out/'result.json',dict(complete=False,rows=rows));print(repeat,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,r.qnodes,flush=True)
    finally:Runtime.attach_stats=oldattach
 finally:sm._quiescence_runtime=original;Runtime.attach_stats=oldattach
 write(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run()
