"""Fixed24 allocation feedback streams; existing entry, explicit draw policy."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
bins={'exchange':ROOT/'.local_agent/exchange-20261007/fairy-exchange.exe','classical':ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe'}
config=ROOT/'.local_agent/mature-search/material-variants.ini'
suite=ROOT/'.local_agent/see-opening-20261007/suite.json';cases=json.loads(suite.read_bytes())['cases']
plan=dict(question='Does equal-time root allocation help the fixed half-risk candidate against classical leaf on actual play?',trigger='Root28 changes e5c6 to e5d3 under MultiPV3 with favorable finite child reference; not an isolated evaluation repair.',design='24streams: two existing6ply prefixes x three unchanged tables x both candidate colors x SinglePV1/MultiPV3. Classical SinglePV1 throughout. Fresh engines/hash/cell, local1sec Threads1 Hash16 NNUEfalse,160subsequentplies. Sequential alternating allocation; no extra budget for candidate.',match_policy='Explicit claim_chess_draws=True; automatic outcomes first and prospective legal claim witness unplayed. Library material detection not exhaustive dead position. Core defaults unchanged.',decision='All tables retained; not price selection/Elo/holdout/strength or default promotion. If allocation does not improve practical feedback, do not blindly add breadth; inspect actionable game failure.',cost='<=3840 requested local seconds plus Core/logging; interruptible after every action. One game at a time, no other timed experiments.',binary_sha256={k:sha(v) for k,v in bins.items()},config_sha256=sha(config),suite_sha256=sha(suite),adapter_sha256=sha(ROOT/'scripts/chess_development.py'),producer_sha256=sha(Path(__file__)))
out=p/'games.json';assert not out.exists();d.write_record(p/'games-declaration.json',plan)
report=dict(complete=False,declaration=plan,games=[]);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());start=time.perf_counter();cost=dict(writes=0,bytes=0,seconds=0.)
def stop():
 for name in ('rollout','advisor','slack'):
  x=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes());assert not x.get('stopped') and not x.get('user_paused')
def save(path,value):
 t=time.perf_counter();d.write_record(path,value,indent=None);cost['writes']+=1;cost['bytes']+=path.stat().st_size;cost['seconds']+=time.perf_counter()-t
save(out,report)
try:
 for case in cases:
  for policy in d.POLICIES:
   for color in (0,1):
    for mpv in (1,3):
     stop()
     with chess.engine.SimpleEngine.popen_uci([str(bins['exchange']),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci([str(bins['classical']),'load',str(config)],timeout=15) as other:
      for engine in (e,other):engine.configure({'Threads':1,'Hash':16,'Use NNUE':False})
      local=d.UciMaterial(e,case['fen'],policy,1,multipv=mpv);external=d.UciMaterial(other,case['fen'],policy,1)
      tags=dict(id=case['id'],table=policy,candidate_color=color,candidate_multipv=mpv)
      def progress(g):save(p/'active.json',dict(**tags,**g));stop()
      g=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=external,local_external=local,prefix=case['opening_uci'],claim_chess_draws=True)
      report['games'].append(dict(**tags,**g));save(out,report)
      print(len(report['games']),case['id'],policy,color,mpv,g['end'],g['winner'],g['plies_played'],flush=True)
 report['complete']=True
finally:
 report.update(wall_seconds=time.perf_counter()-start,recording_cost=cost);save(out,report)
save(p/'active.json',dict(complete=report['complete'],completed_games=len(report['games'])))
print('COMPLETE',report['complete'],report['wall_seconds'],flush=True)
