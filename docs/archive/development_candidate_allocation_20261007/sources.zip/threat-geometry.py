"""Falsify a concrete defended-cheaper-threat hypothesis without fitting weights."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
p=Path(__file__).parent;assert json.loads((p/'continuations.json').read_bytes())['complete']
root=next(x for x in json.loads((p/'roots.json').read_bytes())['rows'] if x['index']==28)
b=chess.Board(chess.STARTING_FEN)
for m in root['history_prefix']:b.push_uci(m)
prices=d.material_tables()['geometric_half'];out=p/'threat-geometry.json';assert not out.exists()
r=dict(complete=False,question='Does cheaper-attacker danger hidden by pseudo defense actually occur on root28 or its three declared children?',falsifier='No such target means this root does not justify adding that leaf penalty; do not fit classical threats or widen the hypothesis after a negative result.',scope='Current pseudo attackers/defenders only; King has no material price. Children retain full real history and actor; legal Black captures are enumerated without changing actor/history. Not SEE, forced loss, calibrated probability or a new evaluator.',rows=[])
for chosen in (None,'h2h4','e5c6','e5d3'):
 board=b.copy(stack=True)
 if chosen:board.push_uci(chosen)
 targets=[]
 for square,piece in board.piece_map().items():
  if piece.color!=chess.WHITE or piece.piece_type==chess.KING:continue
  defenders=board.attackers(chess.WHITE,square)
  cheaper=[s for s in board.attackers(chess.BLACK,square) if board.piece_type_at(s)!=chess.KING and prices[chess.piece_symbol(board.piece_type_at(s)).upper()]<prices[piece.symbol().upper()]]
  if defenders and cheaper:
   targets.append(dict(square=chess.square_name(square),piece=piece.symbol(),defenders=[chess.square_name(x) for x in defenders],cheaper_attackers=[chess.square_name(x) for x in cheaper]))
 legal_captures=[]
 if chosen:
  assert board.turn==chess.BLACK
  for move in board.legal_moves:
   if not board.is_capture(move):continue
   victim=board.piece_at(move.to_square)
   legal_captures.append(dict(move=move.uci(),attacker=board.piece_at(move.from_square).symbol(),victim=None if victim is None else victim.symbol(),off_target_ep=board.is_en_passant(move),defenders=[chess.square_name(x) for x in board.attackers(chess.WHITE,move.to_square)]))
 r['rows'].append(dict(chosen=chosen,fen=board.fen(en_passant='fen'),history_plies=len(board.move_stack),targets=targets,legal_black_captures=legal_captures))
r.update(complete=True,root_input_sha256=hashlib.sha256((p/'roots.json').read_bytes()).hexdigest(),prices=prices)
d.write_record(out,r);print([(x['chosen'],x['targets'],x['legal_black_captures']) for x in r['rows']])
