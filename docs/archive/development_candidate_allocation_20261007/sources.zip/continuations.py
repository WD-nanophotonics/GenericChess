"""Same full-history root, forced contrasting first choices; no price fitting."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert json.loads((p/'games.json').read_bytes())['complete']
root=next(x for x in json.loads((p/'roots.json').read_bytes())['rows'] if x['index']==28)
assert [(x['multipv'],x['move']) for x in root['choices'][:2]]==[(1,'e5c6'),(3,'e5d3')]
bins={'exchange':ROOT/'.local_agent/exchange-20261007/fairy-exchange.exe','classical':ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe','reference':ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'}
config=ROOT/'.local_agent/mature-search/material-variants.ini';out=p/'continuations.json';assert not out.exists()
plan=dict(question='Does the favorable root28 choice translate into useful continuation when early divergence is removed?',design='Four streams:forced e5c6/e5d3 from same full root history, candidate White geometric_half SinglePV1 throughout, versus classical SinglePV1 or fullstrength reference. Fresh engines/hash/branch, fixed160subsequentplies and immediate Chess claim policy. All branches retained; no outcome-driven extension.',resources='Both native players2sec Threads1 Hash16 NNUEfalse; reference500000nodes/2sec fuse Threads1 Hash16 fullstrength. Compare first-choice branches within opponent only; different opponents not equal-resource contrast.',decision='Exposed causal intervention on first move only within this small continuation; stochastic/timed downstream can diverge. Finite cp and whole-game feedback not proof/price fitting/Elo. Negative branches argue against blind breadth/default promotion.',cost='<=1280native requested seconds across2classical streams;<=640local+640reference fuse seconds across2reference streams plus replay. Increment justified by concrete choice/outcome question, interruptible each step; no other timed jobs.',root_input_sha256=sha(p/'roots.json'),history_prefix=root['history_prefix'],forced_choices=['e5c6','e5d3'],binary_sha256={k:sha(v) for k,v in bins.items()},config_sha256=sha(config),adapter_sha256=sha(ROOT/'scripts/chess_development.py'),producer_sha256=sha(Path(__file__)))
d.write_record(p/'continuations-declaration.json',plan)
r=dict(complete=False,declaration=plan,games=[]);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());start=time.perf_counter()
def stop():
 for name in ('rollout','advisor','slack'):
  x=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes());assert not x.get('stopped') and not x.get('user_paused')
d.write_record(out,r)
try:
 for opponent in ('classical','reference'):
  for forced in plan['forced_choices']:
   stop()
   with chess.engine.SimpleEngine.popen_uci([str(bins['exchange']),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci(str(bins['reference']) if opponent=='reference' else [str(bins['classical']),'load',str(config)],timeout=15) as other:
    e.configure({'Threads':1,'Hash':16,'Use NNUE':False});other.configure({'Threads':1,'Hash':16,**({'UCI_LimitStrength':False} if opponent=='reference' else {'Use NNUE':False})})
    local=d.UciMaterial(e,chess.STARTING_FEN,'geometric_half',2)
    external=d.UciOpponent(other,chess.STARTING_FEN,500000) if opponent=='reference' else d.UciMaterial(other,chess.STARTING_FEN,'geometric_half',2)
    if opponent=='reference':external.limit=chess.engine.Limit(nodes=500000,time=2)
    def save(g):d.write_record(p/'continuation-active.json',dict(opponent=opponent,forced=forced,**g),indent=None);stop()
    g=d.play_game(chess.STARTING_FEN,c,'geometric_half','uci_reference',d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=2),160,save,external=external,local_external=local,prefix=root['history_prefix']+[forced],claim_chess_draws=True)
    r['games'].append(dict(opponent=opponent,forced=forced,**g));d.write_record(out,r,indent=None)
    print(opponent,forced,g['end'],g['winner'],g['plies_played'],flush=True)
 r['complete']=True
finally:r['wall_seconds']=time.perf_counter()-start;d.write_record(out,r)
print('CONTINUATIONS COMPLETE',r['complete'],r['wall_seconds'],flush=True)
