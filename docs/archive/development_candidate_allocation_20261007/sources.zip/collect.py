"""Publish generated evidence only; reuse repository archive/index convention."""
import sys,json,hashlib,zipfile,re,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/development_candidate_allocation_20261007';out=ROOT/'docs/research/data/chess_candidate_allocation_20261007.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
v=json.loads((p/'games.json').read_bytes());r=json.loads((p/'replay.json').read_bytes());roots=json.loads((p/'roots.json').read_bytes())
continuations=json.loads((p/'continuations.json').read_bytes());cr=json.loads((p/'continuations-replay.json').read_bytes());geometry=json.loads((p/'threat-geometry.json').read_bytes())
assert continuations['complete'] and cr['complete'] and len(cr['games'])==4 and not cr['errors'] and geometry['complete']
assert sha((p/'continuations.py').read_bytes())==continuations['declaration']['producer_sha256']
assert v['complete'] and r['complete'] and roots['complete'] and len(r['games'])==24 and not r['errors']
assert sha((p/'games.py').read_bytes())==v['declaration']['producer_sha256']
groups={}
for g in r['games']:
 z=groups.setdefault(str(g['candidate_multipv']),{}).setdefault(g['table'],dict(win=0,loss=0,draw=0,unfinished=0));z[g['outcome']]+=1
paired=[]
for left,right in zip(r['games'][::2],r['games'][1::2]):
 assert (left['id'],left['table'],left['candidate_color'])==(right['id'],right['table'],right['candidate_color'])
 paired.append(dict(id=left['id'],table=left['table'],candidate_color=left['candidate_color'],single=left['outcome'],multi=right['outcome'],single_plies=left['plies'],multi_plies=right['plies']))
a.mkdir(exist_ok=True);indexes={}
def archive(name,files):
 target=a/name;assert not target.exists();entries={}
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in files:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b)
   z.writestr(n,b);entries[n]=dict(bytes=len(b),sha256=sha(b))
 with tempfile.TemporaryDirectory(prefix='gc-candidate-') as td,zipfile.ZipFile(target) as z:
  assert z.testzip() is None;z.extractall(td)
  for n,h in entries.items():assert sha((Path(td)/n).read_bytes())==h['sha256']
 indexes[name]=dict(entries=entries,sha256=sha(target.read_bytes()),physically_extracted_rehashed=True)
archive('raw.zip',[(p/n,n) for n in ('declaration.json','roots.json','roots-collector-failed.json','games-declaration.json','games.json','replay.json','leaf-trace.json','continuations-declaration.json','continuations.json','continuations-replay.json','threat-geometry.json','cost.json')])
archive('sources.zip',[(p/n,n) for n in ('roots.py','games.py','replay.py','collect.py','leaf-trace.py','continuations.py','threat-geometry.py','cost.py')]+[(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(ROOT/'scripts/research_record.py','shared-research_record.py'),(ROOT/'.local_agent/see-opening-20261007/suite.json','suite.json'),(ROOT/'.local_agent/mature-search/material-variants.ini','material-variants.ini'),(ROOT/'.local_agent/exchange-20261007/evaluate-exchange.cpp','evaluate-exchange.cpp')])
summary=dict(scope='Exposed development, half-risk candidate vs human classical diagnostic; paired allocation conditions, no price fitting/Elo/holdout/default claim.',declaration=v['declaration'],groups=groups,paired_cells=paired,roots=roots,leaf_trace=json.loads((p/'leaf-trace.json').read_bytes()),threat_geometry=geometry,continuations=dict(declaration=continuations['declaration'],replay=cr,wall_seconds=continuations['wall_seconds']),cost=json.loads((p/'cost.json').read_bytes()),root_collector_failure='TypeError duplicate multipv keyword after2searches; no diagnostic was completed. Empty failed report preserved; repaired original declared diagnostic rerun, not outcome-driven retry.',replay=r,wall_seconds=v['wall_seconds'],recording_cost_before_final_cohort_save=v['recording_cost'],archives=indexes,build_recovery='Pinned native source/build packages in chess_exchange_20261007.json and chess_classical_20261007.json; this report verifies28identical actual shared link objects excluding evaluation.',production_changes='None; opt-in existing MultiPV and Chess draw policy only',public_push='Standing user authorization; exact published SHA verified separately')
write_record(out,summary);write_record(a/'index.json',dict(archives=indexes,portable_sha256=sha(out.read_bytes())));print(json.dumps(dict(groups=groups,played=r['played_plies'],prefix=r['prefix_plies'],entries=sum(len(x['entries']) for x in indexes.values()))))
