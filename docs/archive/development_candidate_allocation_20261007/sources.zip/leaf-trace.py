"""Static decomposition on the three declared full-history roots, after timed games."""
import sys,json,hashlib,subprocess,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;v=json.loads((p/'roots.json').read_bytes());assert v['complete']
games=json.loads((p/'games.json').read_bytes());assert games['complete']
out=p/'leaf-trace.json';assert not out.exists()
bins={'exchange':ROOT/'.local_agent/exchange-20261007/fairy-exchange.exe','classical':ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe'}
r=dict(complete=False,question='Which static components distinguish the actual early/mid/late loss roots? Classical terms diagnostic only, not a coefficient-fitting target.',scope='Trace classical decomposition printed by both builds; patched exchange final evaluation differs from the printed human classical term table. Values in pawn units, not probabilities/WDL; full history retained.',rows=[])
for row in v['rows']:
 for mode,binary in bins.items():
  assert hashlib.sha256(binary.read_bytes()).hexdigest()==v['declaration']['binary_sha256'][mode]
  command='uci\nsetoption name UCI_Variant value gc_geometric_half\nsetoption name Use NNUE value false\nisready\nposition startpos moves '+' '.join(row['history_prefix'])+'\neval\nquit\n'
  z=subprocess.run([str(binary),'load',str(ROOT/'.local_agent/mature-search/material-variants.ini')],input=command,text=True,capture_output=True,timeout=15)
  assert z.returncode==0
  final=re.search(r'Final evaluation\s+([+-]?[0-9.]+)',z.stdout);assert final
  r['rows'].append(dict(index=row['index'],mode=mode,final_white_pawn_units=float(final.group(1)),stdout=z.stdout,stderr=z.stderr))
r['complete']=True;write_record(out,r)
print([(x['index'],x['mode'],x['final_white_pawn_units']) for x in r['rows']])
