"""Predeclared exposed geometric loss roots; no fitting or strength certificate."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=ROOT/'.local_agent/exchange-20261007/classical.json'
old=json.loads(source.read_bytes());g=old['games'][0]
assert g['table']=='geometric_half' and g['exchange_color']==0 and g['winner']==1
bins={'exchange':ROOT/'.local_agent/exchange-20261007/fairy-exchange.exe','classical':ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe'}
config=ROOT/'.local_agent/mature-search/material-variants.ini'
ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
plan=dict(question='Does the first geometric candidate loss expose early evaluation/allocation weakness?',indices=[4,28,60],selection='First geometric loss, early b2b4/king exposure, midgame h2h4, later h4h5 before own first material collapse. Chosen from recorded trajectory, exposed diagnostic; all retained.',conditions='exchange SinglePV1/MultiPV3 and classical SinglePV1, each fresh1sec Threads1 Hash16 NNUEfalse; same full history/prices. Full reference root/unique children500000nodes/1sec fresh hash. Finite cp/mate not WDL.',decision='If allocation rescues a materially worse choice, compare allocation in actual games. If not, inspect concrete leaf failure rather than broad SEE framework.',cost='9local calls plus <=15finite-reference calls/replay; no concurrency with timed games.',source_sha256=sha(source),binary_sha256={k:sha(v) for k,v in bins.items()},config_sha256=sha(config),reference_sha256=sha(ref),adapter_sha256=sha(ROOT/'scripts/chess_development.py'))
assert not (p/'roots.json').exists()
d.write_record(p/'declaration.json',plan)
# Compare actual link inputs, excluding only the evaluation object.
builds=[json.loads((ROOT/f'.local_agent/{x}/build.json').read_bytes()) for x in ('exchange-20261007','classical-control-20261007')]
objects=[]
for b in builds:
 command=b['commands'][-1]['command'];o={Path(s).name:sha(Path(s)) for s in command if s.endswith('.o') and Path(s).name!='evaluate.cpp.o'};objects.append(o)
assert objects[0]==objects[1]
report=dict(complete=False,declaration=plan,shared_link_object_sha256=objects[0],rows=[])
d.write_record(p/'roots.json',report)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
def stop():
 for name in ('rollout','advisor','slack'):
  x=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes());assert not x.get('stopped') and not x.get('user_paused')
def pvcheck(board,pv):
 b=board.copy(stack=True)
 for m in pv:assert chess.Move.from_uci(m) in b.legal_moves;b.push_uci(m)
for i in plan['indices']:
 stop();history=g['opening_uci']+[r['move'] for r in g['moves'][:i]]
 state,_=d.replay_prefix(g['initial_fen'],c,history);board=chess.Board(g['initial_fen'])
 for m in history:board.push_uci(m)
 legal={d.uci(a) for a in d.iter_legal_actions(state,c)}
 assert legal=={m.uci() for m in board.legal_moves} and len(state.history)==len(history)+1
 row=dict(index=i,history_prefix=history,fen=board.fen(en_passant='fen'),recorded_choice=g['moves'][i]['move'],choices=[],children={})
 for mode,mpv in (('exchange',1),('exchange',3),('classical',1)):
  stop()
  with chess.engine.SimpleEngine.popen_uci([str(bins[mode]),'load',str(config)],timeout=15) as e:
   e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=d.UciMaterial(e,g['initial_fen'],g['table'],1,multipv=mpv)
   d.replay_prefix(g['initial_fen'],c,history,(player,));m,r=player.choose();assert m in legal;pvcheck(board,r['pv'])
   r.update(mode=mode,multipv=mpv);row['choices'].append(r)
 with chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as e:
  e.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
  def analyse(b):
   stop();e.configure({'Clear Hash':None});t=time.perf_counter();r=e.analyse(b,chess.engine.Limit(nodes=500000,time=1),game=object());pv=[m.uci() for m in r.get('pv',())];pvcheck(b,pv);s=r['score'].pov(board.turn)
   return dict(cp=s.score(),mate=s.mate(),nodes=r.get('nodes'),depth=r.get('depth'),wall_seconds=time.perf_counter()-t,pv=pv)
  row['reference_root']=analyse(board)
  for m in sorted({x['move'] for x in row['choices']}|{row['recorded_choice'],row['reference_root']['pv'][0]}):
   child=board.copy(stack=True);child.push_uci(m);row['children'][m]=analyse(child)
 report['rows'].append(row);d.write_record(p/'roots.json',report)
 print(i,[(r['mode'],r['multipv'],r['move']) for r in row['choices']],{m:(r['cp'],r['mate']) for m,r in row['children'].items()},flush=True)
report.update(complete=True,legal_history_pv_mismatches=0);d.write_record(p/'roots.json',report)
