"""Actual cost of completed streams, not throughput/strength causality."""
import sys,json,hashlib,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'games.json').read_bytes();v=json.loads(raw);assert v['complete']
groups={}
for g in v['games']:
 key=str(g['candidate_multipv']);z=groups.setdefault(key,dict(candidate=[],classical=[]))
 for r in g['moves']:z['candidate' if r['side']==g['candidate_color'] else 'classical'].append(r)
out={}
for key,z in groups.items():
 out[key]={}
 for mode,rows in z.items():
  out[key][mode]=dict(calls=len(rows),wall_seconds=sum(x['wall_seconds'] for x in rows),controller_cpu_seconds=sum(x['controller_cpu_seconds'] for x in rows),engine_reported_nodes=sum(x['engine_nodes'] for x in rows),engine_reported_seconds=sum(x['engine_seconds'] for x in rows),median_reported_depth=statistics.median(x['engine_depth'] for x in rows),median_reported_seldepth=statistics.median(x['engine_seldepth'] for x in rows),native_cpu_seconds=None,cache_hits=None,scored_leaves=None)
result=dict(complete=True,input_sha256=hashlib.sha256(raw).hexdigest(),scope='Time-limited native calls at equal1sec;reported depth/nodes are not production counters or complete fixed-depth search. Total calls/cost differ because actual trajectories/terminal policy differ; not a leaf-speed/strength causal comparison.',groups=out,stream_wall_seconds=v['wall_seconds'],source_bytes=len(raw),recording_cost_before_final_cohort_save=v['recording_cost'])
write_record(p/'cost.json',result);print(json.dumps(result))
