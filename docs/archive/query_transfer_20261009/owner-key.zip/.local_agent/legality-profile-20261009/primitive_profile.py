"""Fixed-work q2 primitive profile.128nodes, no deadline, fixed original root.
Freeze before execution; compare cold signatures/work, not profiler throughput.
Primitive self times disjoint; cumulative times overlap. No production changes.
"""
from pathlib import Path
import json,cProfile,pstats,hashlib,time
import sys
sys.path.insert(0,str(Path.cwd()))
source=Path('docs/archive/search_compression_20261009/source-prior-generation-audit.py')
namespace={'__file__':str(source),'__name__':'setup_only'}
exec(source.read_text().split('control,control_seconds=run()')[0].replace('assert not out.exists()','pass'),namespace)
p=Path('.local_agent/legality-profile-20261009');out=p/'profile.json';assert not out.exists()
control,seconds=namespace['run']();prof=cProfile.Profile();prof.enable()
instrumented,instrumented_seconds=namespace['run']();prof.disable()
fields=['action','score','principal_variation','completed_depth','nodes','qnodes','termination_reason']
assert all(control[k]==instrumented[k] for k in fields)
root=Path.cwd().resolve();rows=[]
for (filename,line,name),(primitive,calls,self_seconds,cumulative,callers) in pstats.Stats(prof).stats.items():
 f=Path(filename)
 if f.is_absolute() and f.is_relative_to(root) and not f.is_relative_to(root/'.venv'):
  rows.append(dict(file=f.relative_to(root).as_posix(),line=line,name=name,calls=calls,self_seconds=self_seconds,cumulative_seconds=cumulative))
rows.sort(key=lambda r:r['self_seconds'],reverse=True)
d=dict(scope=__doc__,seed=namespace['selected'][0],ply=namespace['selected'][1],control=control,instrumented=instrumented,control_seconds=seconds,instrumented_seconds=instrumented_seconds,signatures_equal=True,project_rows=rows,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out.write_bytes((json.dumps(d,indent=2)+'\n').encode());print(json.dumps(rows[:25],indent=2))
