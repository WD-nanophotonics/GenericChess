"""Baseline/product scalar attacks preserve checkpoints and cancellation."""
import ast,json,sys,zipfile,textwrap,inspect
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path('tests'))]
import generic_chess.core.semantic_executor as se
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from rule_semantics_ir_fixtures import weird_rulesets
p=Path(__file__).parent
tree=ast.parse((p/'baseline-semantic_executor.py').read_text())
node=next(n for cls in tree.body if isinstance(cls,ast.ClassDef) and cls.name=='SemanticEngine' for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='is_square_attacked')
ns=dict(vars(se));exec(compile(ast.Module(body=[node],type_ignores=[]),'baseline_scalar','exec'),ns);baseline=ns['is_square_attacked'];product=se.SemanticEngine.is_square_attacked
class Cancel(Exception):pass
class Counter:
 def __init__(self,limit=None):self.n=0;self.limit=limit
 def __call__(self):
  self.n+=1
  if self.limit is not None and self.n==self.limit:raise Cancel()
with zipfile.ZipFile('docs/archive/search_compression_20261009/source-prior-diagnosis-relative.zip') as z:d=json.loads(z.read('.local_agent/source-prior-transfer-20261009/declaration.json'))
cases=[(str(r['seed']),ruleset_from_dict(r['rules']),r['route']) for r in d['rules']]+[(f'fixture{i}',r,[]) for i,r in enumerate(weird_rulesets())]
rows=[]
for name,rules,route in cases:
 c=compile_ruleset_for_execution(rules);s=GameSession(c);checks=cancel_checks=callbacks=0
 for ply in range(len(route)+1):
  for owner in (0,1):
   for square in range(c.board_shape.area):
    outcomes=[]
    for fn in (baseline,product):
     counter=Counter();engine=se.SemanticEngine(c)
     result=fn(engine,s.state.position,square,owner,checkpoint=counter);outcomes.append((result,counter.n))
    assert outcomes[0]==outcomes[1];checks+=1;callbacks+=outcomes[0][1]
    if square==0:
     for limit in (1,max(1,outcomes[0][1]//2),outcomes[0][1]):
      if limit<1:continue
      seen=[]
      for fn in (baseline,product):
       counter=Counter(limit);engine=se.SemanticEngine(c)
       try:fn(engine,s.state.position,square,owner,checkpoint=counter);seen.append(('returned',counter.n))
       except Cancel:seen.append(('cancelled',counter.n))
      assert seen[0]==seen[1];cancel_checks+=1
  if ply<len(route):s.submit(action_from_dict(route[ply]))
 rows.append(dict(case=name,queries=checks,callbacks=callbacks,cancellation_pairs=cancel_checks))
(p/'checkpoint-control.json').write_bytes((json.dumps(dict(scope=__doc__,rows=rows,queries=sum(x['queries'] for x in rows),cancellation_pairs=sum(x['cancellation_pairs'] for x in rows)),indent=2)+'\n').encode())
print(rows)
