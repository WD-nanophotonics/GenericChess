"""Actual rectangle transfer; baseline/product scalar callbacks and cold callers.
Two supported cannon shapes, first eight lexical actual positions per shape.
No new default/profile, fixed unit leaf/order, q0/q2,D3/256nodes/no deadline.
Two balanced rounds. Timings descriptive only; all histories/PVs preserved.
"""
from pathlib import Path
import sys,json,time,ast,statistics
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from test_rectangular_search_override import rectangular_cannon,UnitEvaluator
import generic_chess.core.semantic_executor as se
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'rectangle-transfer.json';assert not out.exists();tree=ast.parse((p/'baseline-semantic_executor.py').read_text());node=next(n for cls in tree.body if isinstance(cls,ast.ClassDef) and cls.name=='SemanticEngine' for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='is_square_attacked');ns=dict(vars(se));exec(compile(ast.Module(body=[node],type_ignores=[]),'baseline_scalar','exec'),ns);baseline=ns['is_square_attacked'];product=se.SemanticEngine.is_square_attacked;rows=[]
class Counter:
 def __init__(self):self.n=0
 def __call__(self):self.n+=1
fields=['action','score','principal_variation','completed_depth','nodes','qnodes','termination_reason']
for shape in ((7,5),(9,10)):
 c=compile_ruleset_for_execution(rectangular_cannon(*shape));s=GameSession(c)
 for ply in range(8):
  if s.state.terminal_status.is_terminal:break
  before=s.state;checks=0;callbacks=0
  for owner in (0,1):
   for square in range(c.board_shape.area):
    vals=[]
    for fn in (baseline,product):
     count=Counter();vals.append((fn(se.SemanticEngine(c),before.position,square,owner,checkpoint=count),count.n))
    assert vals[0]==vals[1];checks+=1;callbacks+=vals[0][1]
  for q in (0,2):
   pairs=[]
   for rep in range(2):
    pair={}
    for name,fn in ([('baseline',baseline),('product',product)] if (ply+rep)%2==0 else [('product',product),('baseline',baseline)]):
     se.SemanticEngine.is_square_attacked=fn;player=AlphaBetaPlayer(c,evaluator_override=UnitEvaluator(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=256,max_time_seconds=None,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0));seconds=time.perf_counter()-t;validate_pv(s,decision);assert s.state==before;pair[name]=dict(seconds=seconds,decision=record_value(decision))
    assert all(pair['baseline']['decision'][k]==pair['product']['decision'][k] for k in fields);pairs.append(pair)
   rows.append(dict(shape=shape,ply=ply,q=q,queries=checks if q==0 else 0,callbacks=callbacks if q==0 else 0,pairs=pairs));write_record(out,dict(scope=__doc__,complete=False,rows=rows))
  se.SemanticEngine.is_square_attacked=product
  acts=s.legal_actions()
  if not acts:break
  s.submit(sorted(acts,key=repr)[0])
se.SemanticEngine.is_square_attacked=product
r=dict(scope=__doc__,complete=True,rows=rows,queries=sum(x['queries'] for x in rows),calls=sum(len(x['pairs'])*2 for x in rows),ratios={q:statistics.median(pair['product']['seconds']/pair['baseline']['seconds'] for x in rows if x['q']==q for pair in x['pairs']) for q in (0,2)})
write_record(out,r);print({k:r[k] for k in ('queries','calls','ratios')})
