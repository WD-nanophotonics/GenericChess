"""Hoist owner-key conversion per attack query; no source/cache/pattern index.
Freeze all68 old route roots, all square/owner attack queries, fixed256nodes
q0/q2 cold leaf/order comparisons before execution; two balanced timing rounds.
No deadline performance inference. Expected below5min, no training/refit.
"""
from pathlib import Path
import sys,json,time,zipfile,collections,inspect,textwrap
sys.path.insert(0,str(Path.cwd()))
import generic_chess.core.semantic_executor as se
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
from scripts.unfamiliar_search import validate_pv

p=Path(__file__).parent;out=p/'owner-key-probe.json';assert not out.exists()
with zipfile.ZipFile('docs/archive/search_compression_20261009/source-prior-diagnosis-relative.zip') as z:d=json.loads(z.read('.local_agent/source-prior-transfer-20261009/declaration.json'))
def owner_sources(position,owner):
 indexed={}
 for source,piece in enumerate(position.board):
  if piece is not None and piece.owner==owner:indexed.setdefault((piece.owner,piece.current_type_id),[]).append((source,piece))
 return {k:tuple(v) for k,v in indexed.items()}
original=se.SemanticEngine.is_square_attacked
src=textwrap.dedent(inspect.getsource(original)).replace('str(by_owner)','owner_key').replace('self._ensure_match(position)','self._ensure_match(position)\n    owner_key = str(by_owner)')
namespace=dict(vars(se));namespace['owner_sources']=owner_sources;exec(src,namespace);candidate=namespace['is_square_attacked']
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
fields=['action','score','principal_variation','completed_depth','nodes','qnodes','termination_reason'];report=dict(scope=__doc__,rules=[],complete=False);start=time.perf_counter()
for case in d['rules']:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);profile,_=build_semantic_opportunity_profile(c,cfg);unit={t.type_id:0 if t.is_anchor else 1000 for t in c.piece_types}
 class FixedOrder:
  def __init__(self):self.leaf=Evaluator(c,profile,cfg)
  def evaluate(self,state):return self.leaf.evaluate(state)
  def capture_order_value(self,moving,captured):return unit[captured.current_type_id]*10-unit[moving.current_type_id]//10
  def type_value(self,t):return unit[t]
 row=dict(seed=case['seed'],attacks=0,searches=[],complete=False);report['rules'].append(row)
 for ply in range(len(case['route'])+1):
  state=s.state;engine=se.SemanticEngine(c)
  expected=[original(engine,state.position,square,owner) for owner in (0,1) for square in range(len(state.position.board))]
  actual=[candidate(engine,state.position,square,owner) for owner in (0,1) for square in range(len(state.position.board))]
  assert actual==expected;row['attacks']+=len(expected)
  for q in (0,2):
   trials=[]
   for rep in range(2):
    pair={}
    for name,fn in ([('original',original),('owner',candidate)] if (ply+rep)%2==0 else [('owner',candidate),('original',original)]):
     se.SemanticEngine.is_square_attacked=fn
     player=AlphaBetaPlayer(c,evaluator_override=FixedOrder(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
     t=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=256,max_time_seconds=None,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0));seconds=time.perf_counter()-t
     validate_pv(s,decision);assert s.state==state;pair[name]=dict(seconds=seconds,decision=record_value(decision))
    assert all(pair['original']['decision'][k]==pair['owner']['decision'][k] for k in fields);trials.append(pair)
   row['searches'].append(dict(ply=ply,q=q,trials=trials))
  se.SemanticEngine.is_square_attacked=original
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 row['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(case['seed'],'done',round(time.perf_counter()-start,2),flush=True)
se.SemanticEngine.is_square_attacked=original;report.update(complete=True,seconds=time.perf_counter()-start);out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
