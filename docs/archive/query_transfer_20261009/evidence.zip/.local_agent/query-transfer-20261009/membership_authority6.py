"""Independent full-map and all-endpoint controls before product deployment."""
import sys,json,hashlib,time
from pathlib import Path
from collections import defaultdict
root=Path.cwd();sys.path.insert(0,str(root));p=Path(__file__).parent
import generic_chess.core.semantic_executor as sem
import ast,textwrap
from generic_chess.rules.ir import geometry_paths_to as helper
prototype=sem.SemanticEngine.is_square_attacked
raw=(root/'.local_agent/pawn-bias-20261008/semantic-executor-before.py').read_text();tree=ast.parse(raw);klass=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='SemanticEngine');method=next(x for x in klass.body if isinstance(x,ast.FunctionDef) and x.name=='is_square_attacked');ns=dict(sem.__dict__);exec(textwrap.dedent(''.join(raw.splitlines(keepends=True)[method.lineno-1:method.end_lineno])),ns);original=ns['is_square_attacked']
from generic_chess.rules.ir import geometry_candidates
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.core.actions import action_from_dict
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.session.session import GameSession
src=root/'.local_agent/generated6-20261008/coverage.json';d=json.loads(src.read_bytes());out=p/'membership-authority6.json';assert not out.exists();start=time.perf_counter();r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration':'Declared followup: actual product versus original committed source and unchanged full-map authority, all four existing generated6x6 semantic-first routes; allboard targets/owners/sources. At every recorded route frontier and canonical initial state, compare original single-square predicate and prototype against independent unchanged full attacked_squares enumeration; retain guards/paths/aux. No human/holdout. First checkpoint cancellation must propagate. Serial <=120sec.','geometry_queries':0,'attack_queries':0,'positions':0,'cases':[]}
cases=[(str(x['seed']),ruleset_from_dict(x['rules']),x['route']) for x in d['cases']]
for label,base,route in cases:
 c=compile_ruleset_for_execution(base);engine=semantic_engine_for(c);game=GameSession(c);area=len(game.state.position.board)
 for geometry in engine.ir.geometry.values():
  if geometry.kind=='drop':continue
  for owner in ('0','1'):
   for source_square in range(area):
    expected=defaultdict(list)
    for target,path in geometry_candidates(geometry,owner,source_square):expected[target].append(path)
    for target in range(-1,area+1):
     assert tuple(helper(geometry,owner,source_square,target))==tuple(expected[target]);r['geometry_queries']+=1
 positions=[game.state.position]
 for step in route:game.submit(action_from_dict(step['action']));positions.append(game.state.position)
 for position in positions:
  assert time.perf_counter()-start<120 and not json.loads((root/'.local_agent/rollout.json').read_bytes()).get('user_paused')
  for owner in (0,1):
   full=engine.attacked_squares(position,owner)
   for target in range(area):
    assert original(engine,position,target,owner)==prototype(engine,position,target,owner)==(target in full);r['attack_queries']+=1
  r['positions']+=1
 class Cancelled(Exception):pass
 def stop():raise Cancelled()
 try:prototype(engine,game.state.position,0,0,checkpoint=stop)
 except Cancelled:pass
 else:raise AssertionError('Checkpoint cancellation failed')
 r['cases'].append({'label':label,'positions':len(positions),'area':area})
r['complete']=True;r['seconds']=time.perf_counter()-start;out.write_bytes((json.dumps(r,indent=2)+'\n').encode());print(r,flush=True)
