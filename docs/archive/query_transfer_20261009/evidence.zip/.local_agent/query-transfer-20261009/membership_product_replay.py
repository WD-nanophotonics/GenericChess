"""Predeclared original/product semantic qsupport callers; serial rotated pairs."""
import sys,json,time,hashlib,types,inspect,textwrap,ast
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'tests/product')]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'membership-product-replay.json';assert not out.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def clone(name,source):
 m=types.ModuleType('generic_chess.ai.alphabeta.'+name)
 m.__package__='generic_chess.ai.alphabeta';sys.modules[m.__name__]=m
 exec(source,m.__dict__);return m
import generic_chess.core.semantic_executor as sem
from generic_chess.rules.ir import geometry_candidates
original_attack=sem.SemanticEngine.is_square_attacked
from generic_chess.rules.ir import geometry_paths_to
helper=inspect.getsource(geometry_paths_to)
prototype_attack=original_attack;modified=inspect.getsource(original_attack)
source=root/'.local_agent/qsemantics-20261008/fresh-reuse.json'
decl=p/'membership-declaration.json';input_data=json.loads(source.read_bytes())
r={'prototype_source':modified,'helper_source':helper,'complete':False,'producer_sha256':sha(Path(__file__)),'inputs':{source.relative_to(root).as_posix():sha(source),decl.relative_to(root).as_posix():sha(decl)},'product_hashes':{f:sha(root/f) for f in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/quiescence.py','generic_chess/core/semantic_executor.py','generic_chess/rules/ir.py')},'declaration':json.loads(decl.read_bytes()),'cases':[]}
started=time.perf_counter();write_record(out,r)
def check():
 assert time.perf_counter()-started<540
 for f in ('rollout.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes())
  assert not d.get('user_paused',False) and not d.get('stopped',False)
try:
 for old in input_data['cases']:
  check();c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));game=GameSession(c)
  for step in old['route']:game.submit(action_from_dict(step['action']))
  assert game.state.ply_count==old['frontier_ply'] and not game.state.terminal_status.is_terminal
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
  ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  row={'seed':old['seed'],'searches':[]};r['cases'].append(row)
  for repeat in (0,):
   for actual in (True,):
    check();observed=[]
    def stats():
     z=SearchStatistics();observed.append(z);return z
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True))
    before=game.state;t=time.perf_counter()
    with patch.object(sem.SemanticEngine,'is_square_attacked',prototype_attack if actual else original_attack),patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):
     decision=player.choose_action(game,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=30,quiescence_max_depth=2,quiescence_hard_max_depth=8))
    elapsed=time.perf_counter()-t;validate_pv(game,decision);assert game.state==before
    assert decision.native_legality_fallbacks==0
    work={k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','native_legality_calls','capture_qactions','material_change_qactions','promotion_qactions','checking_move_qactions','checking_drop_qactions','nonchecking_drop_excluded')}
    assert work['runtime_depth_balanced'] and work['runtime_pushes']==work['runtime_pops']
    row['searches'].append({'target_query_prototype':actual,'repeat':repeat,'seconds':elapsed,'decision':record_value(decision),'runtime_work':work});write_record(out,r)
    print(old['seed'],actual,repeat,decision.completed_depth,decision.score,decision.termination_reason,round(elapsed,3),work['material_change_qactions'],flush=True)
  signature=lambda x:tuple(json.dumps(x['decision'][k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
  row['all_exact']=len({signature(x) for x in row['searches']})==1
  row['same_qclasses']=all({k:v for k,v in x['runtime_work'].items() if k.endswith('qactions') or k=='nonchecking_drop_excluded'}=={k:v for k,v in row['searches'][0]['runtime_work'].items() if k.endswith('qactions') or k=='nonchecking_drop_excluded'} for x in row['searches'])
  if not any(x['decision']['termination_reason']=='time_limit' for x in row['searches']):assert row['all_exact'] and row['same_qclasses']
 r['complete']=True;r['prototype']='native tuple membership miss fast-path, no index/cache'
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
