import ast,sys
from pathlib import Path
from dataclasses import replace
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')]
from tools.local_agent.common import write_json
D=R/'.local_agent/guard-equivalence-20261017'
write_json(D/'dot-subclass-preparation-failure.json',dict(error='IllegalActionError b2-b3 in initial unchanged resolver',cause='Own test fixture ASCII is top-first; P was placed at rank2, not1. No product failure or security restriction.',correction='Place pawn at rank1 without changing test coordinates.'))
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import LeapAtom
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.core import semantic_executor as m
from generic_chess.core.actions import BoardMove
from generic_chess.core.coordinates import Square,square_to_index
from generic_chess.session.session import GameSession
class OffsetRank(int):
 def __mul__(self,width):return int(self)*width+1
rule=make_ruleset(4,[king_type(),T('P',LeapAtom((0,1)))],lines=['...k','....','.P..','K...'])
c=replace(compile_legacy_ruleset_for_semantic_execution(rule),_legacy_compiled=None);s=GameSession(c);engine=m.SemanticEngine(c)
a=BoardMove(Square(1,OffsetRank(1)),Square(1,2));ns=vars(m).copy()
tree=ast.parse((D/'checked-binding-filter/semantic_executor-candidate-final.py').read_text(encoding='utf-8-sig'));fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='semantic_action_for');exec(compile(ast.Module(body=[fn],type_ignores=[]),'rejected-filter-resolver','exec'),ns)
old=m.semantic_action_for(engine,s.state.position,a)
try:new=ns['semantic_action_for'](engine,s.state.position,a);outcome=dict(accepted=True,result=repr(new))
except Exception as e:outcome=dict(accepted=False,error_type=type(e).__name__,error=str(e))
assert old.source==5 and outcome.get('error_type')=='IllegalActionError'
write_json(D/'dot-subclass-counterexample-result.json',dict(reply_ts='1792205569.209119',local_execution=True,scope='Private rejected resolver only; production Core unchanged.',old_accepted=repr(old),filtered_outcome=outcome,visible_source_equals_builtin=a.from_square==Square(1,1),converted_index=square_to_index(a.from_square,c.board_shape),correct_index=5,decision='Adopt exact builtin original coordinate components as a future eligibility condition; do not repair/revive the rejected cost candidate.'))
print('Dot input-subclass counterexample reproduced: old accepts index5, rejected filter computes6 and rejects.')
