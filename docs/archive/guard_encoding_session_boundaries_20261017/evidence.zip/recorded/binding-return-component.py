from pathlib import Path
import sys,json,time
from dataclasses import replace
from copy import copy
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.semantic_executor import SemanticEngine,_semantic_public_action
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.transition import _semantic_transition
from generic_chess.session.session import GameSession
A=D/'node-admission-transfer';g=json.loads((A/'consumer-game-13.json').read_bytes());inputs=json.loads((A/'consumer-inputs.json').read_bytes());rule=deserialize_ruleset(json.dumps(next(i['rule']for i in inputs if i['family']==3)));c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c);start=time.monotonic();out=[]
write_json(D/'binding-return-component-plan.json',dict(question='Can the existing already-verified semantic action/binding transition reproduce the whole public checked child at real history roots?',prefixes=[16,32,48,64],max_bindings_per_root=3,choice='First canonical board binding, first drop binding, first nonlegacy semantic binding; deduplicate identical action, retain missing categories.',whole_cap_seconds=180,forecast_seconds=90,claim='Component interface feasibility only, no new resolver/cache/optimization, no repeat of rejected timing panel. Each binding is obtained by the existing full canonicalS0-S4 iterator before helper use.'))
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def check():
 if time.monotonic()-start>=180:raise TimeoutError('Frozen180s component cap')
 for n in('rollout','advisor','slack'):
  v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not v.get('stopped')and not v.get('user_paused')
for length in(16,32,48,64):
 while s.state.ply_count<length:check();s.submit(decode(g['moves'][s.state.ply_count]['decision']['action']))
 assert record_value(s.state)==g['moves'][length-1]['child'];engine=SemanticEngine(c);all_bindings=list(engine.iter_legal_action_bindings(s.state.position,full_frontier=True));selected=[];missing=[]
 for label,predicate in(('board',lambda a:a.source is not None),('drop',lambda a:a.source is None),('semantic',lambda a:a.pattern_id.startswith('sem_'))):
  match=next(((a,b)for a,b in all_bindings if predicate(a)),None)
  if match is None:missing.append(label)
  elif not any(match[0]==a for _,a,_ in selected):selected.append((label,*match))
 for label,a,binding in selected:
  check();public=_semantic_public_action(engine,a);before=s.state,s.to_record(),s._search_witnesses;normal=copy(s);normal.submit(public);direct=_semantic_transition(s.state,a,binding,public,c);assert direct==normal.state and before==(s.state,s.to_record(),s._search_witnesses)
  out.append(dict(prefix=length,kind=label,public_action=record_value(public),full_child_equal=True,history_length=len(direct.history),hand_total=sum(sum(v for _,v in h.counts)for h in direct.position.hands),child=record_value(direct)));print('BINDING_COMPONENT',length,label,len(direct.history),flush=True)
 write_json(D/'binding-return-component-progress.json',dict(rows=out,last_prefix=length,missing_categories=missing,seconds=time.monotonic()-start))
write_json(D/'binding-return-component-result.json',dict(rows=out,prefixes=[16,32,48,64],seconds=time.monotonic()-start,all_full_child_equal=True,component_only=True,next='A future internal checked resolver could return an exact transient binding while public semantic_action_for keeps its action-only result. Still needs fresh full-caller cost/error qualification, not an adopted optimization.'))