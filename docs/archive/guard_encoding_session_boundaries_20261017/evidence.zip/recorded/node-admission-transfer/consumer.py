from pathlib import Path

from dataclasses import replace

import sys,json,time,traceback,os,hashlib

R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017/node-admission-transfer'

from tools.local_agent.common import write_json
from scripts.research_record import record_value

from generic_chess.rules.serialization import deserialize_ruleset

from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution

from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile

from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator

from generic_chess.ai.evaluation.config import EvaluationConfig

from generic_chess.ai.alphabeta.player import AlphaBetaPlayer

from generic_chess.ai.alphabeta.tuning import SearchTuning

from generic_chess.ai.limits import SearchLimits

from generic_chess.session.session import GameSession
from generic_chess.session.result import SessionStatus

START=json.loads((D/'generation-start.json').read_bytes())['monotonic_start'];rows=[];calls=0;moves=0

write_json(D/'consumer-producer.json',{'pid':os.getpid(),'started_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'source':'consumer.py','whole_cap_seconds':1800})

def check():

 if time.monotonic()-START>=1800:raise TimeoutError('Frozen1800s whole cap')

 for name in('rollout','advisor','slack'):

  flag=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())

  if flag.get('stopped')or flag.get('user_paused'):raise InterruptedError('Explicit project stop')

class Token:
 def __init__(self):self.next=0.;self.cause=None
 def is_cancelled(self):
  now=time.monotonic()
  if now-START>=1800:self.cause='frozen_whole1800seconds';return True
  if now>=self.next:
   self.next=now+.25
   for n in ('rollout','advisor','slack'):
    f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
    if f.get('stopped')or f.get('user_paused'):self.cause='explicit_user_stop';return True
  return self.cause is not None
TOKEN=Token()
class Caller:
 def __init__(self,c,ev,admission):
  self.inner=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_tt=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(require_full_pv=True));self.admission=admission;self.last_admission=None
 def choose_action(self,session,limits):
  t=time.perf_counter();n=len(session.legal_actions())if self.admission else None;prep=time.perf_counter()-t
  gate=self.admission and limits.quiescence_max_depth==0 and n+2<=limits.max_nodes<2*n+2
  self.inner._tuning=replace(self.inner._tuning,use_root_tactical=not gate)
  self.last_admission=dict(enabled=self.admission,root_degree=n,gate_active=bool(gate),preparation_seconds=prep)
  try:
   d=self.inner.choose_action(session,limits,cancel_token=TOKEN)
   write_json(D/'latest-query.json',dict(root=record_value(session.state),decision=record_value(d),admission=self.last_admission))
   return d
  except Exception as e:
   write_json(D/'latest-query-failure.json',dict(root=record_value(session.state),failure=dict(type=type(e).__name__,message=str(e)),admission=self.last_admission));raise

def player(c,ev,admission=False):return Caller(c,ev,admission)


inputs=json.loads((D/'consumer-inputs.json').read_bytes());source=json.loads((D/'consumer-source-binding.json').read_bytes())

def source_check():return [p for p,h in source['files'].items()if hashlib.sha256((R/p).read_bytes()).hexdigest()!=h]

assert not source_check()

try:

 for inp in inputs:

  f=inp['family'];check();t=time.monotonic();rule=deserialize_ruleset(json.dumps(inp['rule']));c=replace((compile_semantic_ruleset(rule) if rule.semantic_actions else compile_legacy_ruleset_for_semantic_execution(rule)),_legacy_compiled=None);evs={};profiles={}

  for arm,mob in(('material',0),('attack',2)):

   cfg=replace(EvaluationConfig(),dynamic_mobility_weight=mob,anchor_escape_weight=0,promotion_potential_weight=0);p,scope=build_semantic_opportunity_profile(c,cfg);profiles[arm]={'profile':record_value(p),'scope':scope};evs[arm]=SemanticAttackEvaluator(c,p,cfg,backend='core')

  assert profiles['material']['profile']['board_value_by_type']==profiles['attack']['profile']['board_value_by_type']

  assert profiles['material']['profile']['hand_value_by_base_type']==profiles['attack']['profile']['hand_value_by_base_type']

  evs['always_on']=evs['attack'];evs['budget_admission']=evs['attack'];setup=time.monotonic()-t;write_json(D/f'consumer-family-{f:02}-profiles.json',{'setup_seconds':setup,'profiles':profiles})

  for owner in(0,1):

   order=('always_on','budget_admission') if (f+owner)%2==0 else ('budget_admission','always_on')

   for arm in order:

    check();game=len(rows);s=GameSession(c);players={owner:player(c,evs[arm],arm=='budget_admission'),1-owner:player(c,evs['material'])};row={'game':game,'family':f,'candidate_owner':owner,'arm':arm,'initial_state':record_value(s.state),'moves':[],'status':'active'};gstart=time.monotonic()

    try:

     for ply in range(64):

      check()

      if s.state.terminal_status.is_terminal:break

      side=s.state.position.side_to_move;depth=2;before=s.state;call=time.monotonic();features_before=getattr(evs[arm],'_projection_calls',0);v=players[side].choose_action(s,SearchLimits(max_depth=depth,max_nodes=1024,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0));calls+=1

      check();assert s.state is before;assert v.runtime_depth_balanced is not False;assert v.native_legality_calls==0

      if v.choice_kind=='DECLARATION':s.declare(v.declaration.declaration_id)

      elif v.action in s.legal_actions():s.submit(v.action)

      else:raise AssertionError('Missing or illegal action on ongoing session')

      moves+=1;assert len(s.state.history)==s.state.ply_count+1;assert len(s.history)==s.state.ply_count

      row['moves'].append({'actor':side,'candidate':side==owner,'decision':record_value(v),'call_seconds':time.monotonic()-call,'admission':players[side].last_admission,'child':record_value(s.state)})

      write_json(D/f'consumer-game-{game:02}.json',row)

      if s.result.status is not SessionStatus.ONGOING:break

     result=s.result;row['session_result']=record_value(result);row['record']=record_value(s.to_record())

     if result.status is SessionStatus.ONGOING:row.update(status='administrative64ply_UNKNOWN',reward=None)

     else:row.update(status='actual_terminal',reward=0 if result.winner is None else 1 if result.winner==owner else -1)

    except Exception as e:

     row.update(status='error',reward=None,failure={'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()},record=record_value(s.to_record()))

    row['seconds']=time.monotonic()-gstart;write_json(D/f'consumer-game-{game:02}.json',row);rows.append({k:v for k,v in row.items()if k not in('initial_state','moves','record')});write_json(D/'consumer-progress.json',{'planned_games':16,'rows':rows,'calls':calls,'physical_moves':moves,'seconds':time.monotonic()-START});print('GAME',game,f,owner,arm,row['status'],row['reward'],len(row['moves']),round(row['seconds'],3),flush=True)

    if row['status']=='error':raise RuntimeError('Producer stopped on retained game error')

except Exception as e:

 failure={'type':type(e).__name__,'message':str(e),'trace':traceback.format_exc()};write_json(D/'consumer-failure.json',failure);print('FAILURE',failure,flush=True)

finally:

 changed=source_check();write_json(D/'consumer-result.json',{'planned_games':16,'observed_games':len(rows),'missing_games':16-len(rows),'calls':calls,'physical_moves':moves,'seconds':time.monotonic()-START,'source_changed':changed,'rows':rows,'complete':len(rows)==16 and not changed and all(r['status']!='error'for r in rows)});print('DONE',len(rows),calls,moves,round(time.monotonic()-START,3),'source_changed',changed,flush=True)


