from pathlib import Path
import sys,json,time,collections
from dataclasses import replace
from copy import copy
from unittest.mock import patch
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.semantic_executor import SemanticEngine,semantic_action_for
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
write_json(D/'next-binding-reuse-plan.json',dict(question='Does a checked public Core transition repeat the same canonical membership work after unique action resolution, and can exact transient binding reuse avoid the second pass without an API/cache?',immediate_action='Count actual S3 trials separately during semantic_action_for and engine.apply on a complete lawful32ply generated root; compare exact appliedPosition with public checked child. No production edit.',expected_evidence='Duplicate full-frontier trial counts and immutable parent/child equality, or evidence the second validation performs a necessary independent check.',done_condition='Only choose a future bounded exact-binding reuse prototype if duplication is actual; preserve ambiguity/S4/error/fingerprint checks and public return type. The failed coordinate-only filter remains rejected.',forecast_seconds=30,whole_cap_seconds=180,decision='Source/counter audit only this segment; no new candidate/default/API, no repeated timing rescue panel or AUX runtime code.'))
A=D/'node-admission-transfer';g=json.loads((A/'consumer-game-13.json').read_bytes());inputs=json.loads((A/'consumer-inputs.json').read_bytes());r=deserialize_ruleset(json.dumps(next(i['rule']for i in inputs if i['family']==3)));c=replace(compile_semantic_ruleset(r),_legacy_compiled=None);s=GameSession(c);start=time.monotonic()
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
for m in g['moves'][:32]:
 if time.monotonic()-start>=180:raise TimeoutError('Frozen180s source audit')
 for n in('rollout','advisor','slack'):
  flag=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not flag.get('stopped')and not flag.get('user_paused')
 s.submit(decode(m['decision']['action']))
assert record_value(s.state)==g['moves'][31]['child'];actions=s.legal_actions();a=next(x for x in actions if isinstance(x,(SemanticBoardMove,SemanticDropMove)));expected=copy(s);expected.submit(a);before=s.state,s.to_record(),s._search_witnesses;phase=['resolve'];counts=collections.Counter();orig=SemanticEngine._trial_child_if_s3_legal

def observed(self,*args,**kwargs):
 counts[phase[0]]+=1
 return orig(self,*args,**kwargs)
engine=SemanticEngine(c)
with patch.object(SemanticEngine,'_trial_child_if_s3_legal',observed):
 resolved=semantic_action_for(engine,s.state.position,a);phase[0]='apply';child=engine.apply(s.state.position,resolved)
assert child==expected.state.position and before==(s.state,s.to_record(),s._search_witnesses)
result=dict(prefix=32,root_degree=len(actions),S3_trials=dict(counts),exact_child=True,parent_unchanged=True,action=record_value(a),root=record_value(s.state),child=record_value(child),seconds=time.monotonic()-start,claim='Actual duplicate canonical membership work in checked public transition; not a tested reuse optimization or license to bypass S3/S4.',next='Inspect internal exact(action,binding) return reuse with unchanged public action-only wrapper, then freeze a new combined caller/error protocol before code adoption. Do not rerun the rejected coordinate-only cost gate.')
write_json(D/'next-binding-reuse-source-counter.json',result);print('NEXT_SOURCE_COUNTER',len(actions),dict(counts),round(result['seconds'],3),flush=True)