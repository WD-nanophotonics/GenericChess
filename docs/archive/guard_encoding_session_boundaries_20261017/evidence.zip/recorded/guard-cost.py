from pathlib import Path
import sys,json,time,collections
from dataclasses import replace
from unittest.mock import patch
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
D=R/'.local_agent/guard-equivalence-20261017';B=R/'.local_agent/root-reuse-20261017/existing-flag-transfer';started=time.monotonic()
write_json(D/'guard-cost-plan.json',dict(question='Is Core global exact-guard full-board candidate enumeration a concrete whole-caller cost?',queries=8,per_query_seconds=2,whole_cap_seconds=120,forecast_seconds=25,exposed_families=[3,7],prefix_lengths=[0,4,8,12],instrumentation='Method timer/counters, attribution only; not an optimization speedup.',decision='Prototype one-binding exact-reference narrowing only if>=10percent guard timer share on at least one real call; otherwise defer and choose another premise.'))
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
inputs=json.loads((B/'consumer-inputs.json').read_bytes());orig=SemanticEngine._guard_holds;rows=[];observations=[]
for f in (3,7):
 r=deserialize_ruleset(json.dumps(next(i['rule']for i in inputs if i['family']==f)));c=replace(compile_semantic_ruleset(r),_legacy_compiled=None);game=json.loads((B/f'consumer-game-{f*4:02}.json').read_bytes());cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0);p,_=build_semantic_opportunity_profile(c,cfg)
 for length in (0,4,8,12):
  if time.monotonic()-started>=120:raise TimeoutError('Frozen120seconds whole batch')
  flags=[json.loads((R/'.local_agent'/f'{n}.json').read_bytes())for n in ('rollout','advisor','slack')];assert not any(x.get('stopped')or x.get('user_paused')for x in flags)
  s=GameSession(c)
  for move in game['moves'][:length]:s.submit(decode(move['decision']['action']))
  assert len(s.state.history)==length+1 and not s.state.terminal_status.is_terminal
  counts=collections.Counter();guardtime=[0.]
  def measured(self,guard,position,binding,perspective,checkpoint=None):
   t=time.perf_counter()
   try:return orig(self,guard,position,binding,perspective,checkpoint)
   finally:
    guardtime[0]+=time.perf_counter()-t;counts[(guard.spatial.kind,guard.subject_ref is None)]+=1
  ev=SemanticAttackEvaluator(c,p,cfg,backend='core');player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False)
  parent=s.state,s.to_record(),s._search_witnesses;t=time.monotonic()
  with patch.object(SemanticEngine,'_guard_holds',measured):d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0))
  sec=time.monotonic()-t;assert parent==(s.state,s.to_record(),s._search_witnesses)
  row=dict(family=f,prefix_length=length,call_seconds=sec,guard_seconds=guardtime[0],guard_share=guardtime[0]/sec,counts={str(k):v for k,v in counts.items()},decision=record_value(d),parent=record_value(s.state),prefix=[m['decision']['action']for m in game['moves'][:length]],rule=next(i['rule']for i in inputs if i['family']==f));rows.append(row);write_json(D/f'guard-cost-{f}-{length}.json',row);print('GUARD_COST',f,length,round(sec,3),round(row['guard_share'],3),dict(row['counts']),flush=True)
write_json(D/'guard-cost-result.json',dict(rows=rows,seconds=time.monotonic()-started))