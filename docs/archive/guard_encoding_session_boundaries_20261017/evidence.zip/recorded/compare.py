from pathlib import Path
import sys,time,json
from dataclasses import replace,asdict
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product')]
from test_semantic_empty_guards import guarded_leap
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.pieces import Piece
from tools.local_agent.common import write_json
D=Path('.local_agent/guard-equivalence-20261017');started=time.monotonic();rows=[];states=children=maps=0
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
def observed(p):
    v=asdict(p);v.pop('ruleset_fingerprint');return v
def key(a):
    return (a.source,a.target,a.pattern_id,a.promotion_type_id if hasattr(a,'promotion_type_id') else None)
for offset in ((1,0),(0,0),(2,1),(20,0)):
 for relative in (False,True):
  for subject in (False,True):
   if time.monotonic()-started>60:raise TimeoutError('frozen60s batch cap')
   a=guarded_leap((offset,),relative=relative,subject=subject)
   b=replace(a,semantic_actions=tuple(replace(p,state_guards=tuple(replace(g,aggregation='exists') for g in p.state_guards)) for p in a.semantic_actions))
   compiled=[compile_ruleset_for_execution(r) for r in (a,b)];engines=[SemanticEngine(c) for c in compiled]
   profiles=[build_semantic_opportunity_profile(c,cfg) for c in compiled]
   pair_states=pair_children=0
   for owner,source,target in ((0,0,7),(1,14,7)):
    df,dr=offset
    if relative and owner:df,dr=-df,-dr
    f,r=source%5+df,source//5+dr
    guard=r*5+f if 0<=f<5 and 0<=r<3 else None
    for blocker in (None,0,1):
     for endpoint in (None,0,1):
      board=[None]*15;board[source]=Piece(owner,'H','H')
      if guard not in (None,source,target) and blocker is not None:board[guard]=Piece(blocker,'B','B')
      if endpoint is not None:board[target]=Piece(endpoint,'B','B')
      ps=[replace(e._initial_position(),board=tuple(board),side_to_move=owner) for e in engines]
      aa=[e.legal_actions(p) for e,p in zip(engines,ps)]
      assert [key(x) for x in aa[0]]==[key(x) for x in aa[1]]
      for own in (0,1):
       assert engines[0].attacked_squares(ps[0],own)==engines[1].attacked_squares(ps[1],own);maps+=1
      for x,y in zip(*aa):
       assert observed(engines[0].apply(ps[0],x))==observed(engines[1].apply(ps[1],y));children+=1;pair_children+=1
      states+=1;pair_states+=1
   row=dict(offset=offset,relative=relative,subject=subject,states=pair_states,children=pair_children,rules=[ruleset_to_dict(x) for x in (a,b)])
   row['profiles']=[dict(board=p.board_value_by_type,hand=p.hand_value_by_base_type,version=p.evaluator_version,hand_policy=s['hand_policy'],H=s['types']['H']) for p,s in profiles]
   rows.append(row)
result=dict(elapsed_seconds=time.monotonic()-started,rule_pairs=len(rows),states=states,children=children,owner_map_pairs=maps,rows=rows,scope='Component positions, not lawful game histories; no WDL/fit/quality claim.')
write_json(D/'baseline-result.json',result)
print(json.dumps({k:v for k,v in result.items() if k!='rows'}));print(json.dumps(rows[0]['profiles']))