from pathlib import Path
import sys,time,json,hashlib,traceback,os
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017/representation-continuation';B=D.parent/'wide-repaired-transfer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.identity import position_identity_key
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.tuning import SearchTuning
START=time.monotonic();rows=[];calls=edges=0;stop_cause=None
write_json(D/'producer.json',dict(pid=os.getpid(),source='run.py',utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),whole_cap_seconds=1800))
write_json(D/'source-binding.json',dict(files={str(p.relative_to(R)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in(R/'generic_chess').rglob('*.py')}))
class Token:
 def __init__(self):self.next=0.;self.cause=None
 def is_cancelled(self):
  now=time.monotonic()
  if now-START>=1800:self.cause='frozen_whole_1800seconds';return True
  if now>=self.next:
   self.next=now+.25
   for n in('rollout','advisor','slack'):
    v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
    if v.get('stopped')or v.get('user_paused'):self.cause='explicit_user_stop';return True
  return self.cause is not None
TOKEN=Token()
def check():
 if TOKEN.is_cancelled():raise InterruptedError(TOKEN.cause)
def physical(pos):
 v=record_value(pos);v.pop('ruleset_fingerprint');return v
def normalized(session):
 state=session.state;witnesses=session._search_witnesses;assert len(witnesses)==len(state.history)==state.ply_count+1
 mapping={}
 for p,h in zip(witnesses,state.history):
  key=position_identity_key(p,session.compiled);assert key==h.position_key
  obs=json.dumps(physical(p),sort_keys=True,separators=(',',':'));old=mapping.setdefault(str(key),obs);assert old==obs
 v=record_value(state);v['position']=physical(state.position)
 for h in v['history']:h['position_key']=mapping[h['position_key']]
 v['repetition_counts']=sorted((mapping[str(k)],n)for k,n in state.repetition_counts)
 return v

def no_time(decision):return {k:v for k,v in record_value(decision).items()if not(k.endswith('_seconds')or k.startswith('time_to_'))}
inputs=json.loads((B/'consumer-inputs.json').read_bytes());limits=SearchLimits(max_depth=2,max_nodes=1024,quiescence_max_depth=0,quiescence_hard_max_depth=0);cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0)
try:
 for inp in inputs:
  check();f=inp['family'];source=deserialize_ruleset(json.dumps(inp['rule']));rules=[]
  for aggregation in('count','exists'):
   actions=tuple(replace(a,state_guards=tuple(replace(g,aggregation=aggregation)for g in a.state_guards))if a.name.startswith('conditional_guarded_leap_')else a for a in source.semantic_actions)
   rules.append(replace(source,semantic_actions=actions))
  compiled=[replace(compile_semantic_ruleset(r),_legacy_compiled=None)for r in rules];sessions=[GameSession(c)for c in compiled];profiles=[build_semantic_opportunity_profile(c,cfg)for c in compiled]
  assert profiles[0][0].board_value_by_type==profiles[1][0].board_value_by_type and profiles[0][0].hand_value_by_base_type==profiles[1][0].hand_value_by_base_type and profiles[0][1]['types']==profiles[1][1]['types']
  assert compiled[0].ruleset_fingerprint!=compiled[1].ruleset_fingerprint
  players=[AlphaBetaPlayer(c,evaluator_override=SemanticAttackEvaluator(c,p[0],cfg,backend='core'),use_disk_cache=False,use_tt=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(require_full_pv=True))for c,p in zip(compiled,profiles)]
  row=dict(family=f,status='active',rules=[json.loads(serialize_ruleset(r))for r in rules],initial_states=[record_value(s.state)for s in sessions],profiles=[record_value(p[0])for p in profiles],moves=[]);write_json(D/f'pair-{f:02}.json',row)
  try:
   for ply in range(64):
    check();assert normalized(sessions[0])==normalized(sessions[1]);assert sessions[0].result==sessions[1].result
    if sessions[0].state.terminal_status.is_terminal:break
    decisions=[None,None];node_forecasts=[len(s.legal_actions())for s in sessions];assert node_forecasts[0]==node_forecasts[1]
    for arm in ((0,1)if(f+ply)%2==0 else(1,0)):
     check();s=sessions[arm];before=s.state,s.to_record(),s._search_witnesses;t=time.monotonic();d=players[arm].choose_action(s,limits,cancel_token=TOKEN);calls+=1
     assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced and d.native_legality_calls==0
     decisions[arm]=d;write_json(D/'latest-query.json',dict(family=f,ply=ply,arm=arm,decision=record_value(d),root=record_value(s.state),seconds=time.monotonic()-t));check()
    assert no_time(decisions[0])==no_time(decisions[1]),'Paired finite-node decision mismatch'
    before_states=[record_value(s.state)for s in sessions]
    for s,d in zip(sessions,decisions):
     if d.choice_kind=='DECLARATION':s.declare(d.declaration.declaration_id)
     else:s.submit(d.action)
    edges+=2;assert normalized(sessions[0])==normalized(sessions[1])
    row['moves'].append(dict(ply=ply,root_degree=node_forecasts[0],decisions=[record_value(d)for d in decisions],children=[record_value(s.state)for s in sessions]));write_json(D/f'pair-{f:02}.json',row)
    print('PAIR_PLY',f,ply,node_forecasts[0],decisions[0].completed_depth,decisions[0].nodes,flush=True)
   row.update(status='actual_terminal'if sessions[0].state.terminal_status.is_terminal else'administrative64ply_UNKNOWN',results=[record_value(s.result)for s in sessions],records=[record_value(s.to_record())for s in sessions])
  except Exception as e:
   row.update(status='interrupted_UNKNOWN'if isinstance(e,InterruptedError)else'actual_failure',failure=dict(type=type(e).__name__,message=str(e),trace=traceback.format_exc()),records=[record_value(s.to_record())for s in sessions]);raise
  finally:
   write_json(D/f'pair-{f:02}.json',row);rows.append({k:v for k,v in row.items()if k not in('rules','initial_states','profiles','moves','records')});write_json(D/'progress.json',dict(rows=rows,queries=calls,physical_edges=edges,seconds=time.monotonic()-START))
except Exception as e:
 stop_cause=dict(type=type(e).__name__,message=str(e),trace=traceback.format_exc());print('STOP',stop_cause,flush=True)
finally:
 source=json.loads((D/'source-binding.json').read_bytes())['files'];changed=[p for p,h in source.items()if hashlib.sha256((R/p).read_bytes()).hexdigest()!=h]
 write_json(D/'result.json',dict(planned_pairs=4,observed_pairs=len(rows),unstarted_pairs=4-len(rows),queries=calls,physical_edges=edges,seconds=time.monotonic()-START,rows=rows,source_changed=changed,stop_cause=stop_cause,complete=len(rows)==4 and not stop_cause and not changed));print('DONE',len(rows),calls,edges,round(time.monotonic()-START,3),changed,flush=True)