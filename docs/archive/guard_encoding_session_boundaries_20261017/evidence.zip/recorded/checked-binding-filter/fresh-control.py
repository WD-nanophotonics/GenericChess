from pathlib import Path
import ast,sys,time,json
from dataclasses import replace
from copy import copy
from unittest.mock import patch
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017';P=D/'checked-binding-filter';A=D/'node-admission-transfer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.core import semantic_executor as mod
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.limits import SearchLimits
source=(P/'semantic_executor-before-filter.py').read_text(encoding='utf-8-sig');tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='semantic_action_for');ns=mod.__dict__.copy();exec(compile(ast.Module(body=[fn],type_ignores=[]),str(P/'semantic_executor-before-filter.py'),'exec'),ns);baseline=ns['semantic_action_for'];candidate=mod.semantic_action_for
cases=[(0,0,1),(1,5,2),(2,8,4),(2,8,7),(3,13,16),(3,13,32),(3,13,48),(3,13,64)]
write_json(P/'fresh-caller-plan.json',dict(question='Does the minimal production binding filter preserve full outputs/work on new actual trajectory roots beyond the single prototype family?',cases=cases,exposure='Newly closed node-admission study, never used for this code optimization or price fitting; not an independent rules oracle/holdout.',calls=16,limits=dict(depth=2,nodes=2048,q0=True,seconds=None),whole_cap_seconds=240,forecast_seconds=60,criterion='All8full non-time/work/selectedchild/PV pairs equal; at least3of4longprefix caller ratios<=.90. Keep all shorter-root adversity; no timing-based sample replacement. Only a local cost result, not play strength.'))
START=time.monotonic();rows=[];inputs=json.loads((A/'consumer-inputs.json').read_bytes())
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def compare(v):return {k:x for k,x in v.items()if not(k.endswith('_seconds')or k.startswith('time_to_'))}
for index,(f,g,length)in enumerate(cases):
 if time.monotonic()-START>=240:raise TimeoutError('Frozen240s paired consumer cap')
 for n in('rollout','advisor','slack'):
  v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not v.get('stopped')and not v.get('user_paused')
 game=json.loads((A/f'consumer-game-{g:02}.json').read_bytes());rule=deserialize_ruleset(json.dumps(next(i['rule']for i in inputs if i['family']==f)));c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c)
 for m in game['moves'][:length]:s.submit(decode(m['decision']['action']))
 assert record_value(s.state)==game['moves'][length-1]['child'] and not s.state.terminal_status.is_terminal
 cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0);profile,_=build_semantic_opportunity_profile(c,cfg);parent=s.state,s.to_record(),s._search_witnesses;arms=[]
 for fast in ((False,True)if index%2==0 else(True,False)):
  player=AlphaBetaPlayer(c,evaluator_override=SemanticAttackEvaluator(c,profile,cfg,backend='core'),use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(require_full_pv=True));t=time.perf_counter()
  with patch.object(mod,'semantic_action_for',candidate if fast else baseline):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=2048,quiescence_max_depth=0,quiescence_hard_max_depth=0))
  sec=time.perf_counter()-t;assert parent==(s.state,s.to_record(),s._search_witnesses)and d.runtime_depth_balanced
  ch=copy(s)
  if d.action is not None:ch.submit(d.action)
  pv=copy(s)
  for a in d.principal_variation:pv.submit(a)
  arms.append(dict(fast=fast,seconds=sec,decision=record_value(d),child=record_value(ch.state),pv_final=record_value(pv.state)))
 arms.sort(key=lambda a:a['fast']);equal=compare(arms[0]['decision'])==compare(arms[1]['decision'])and arms[0]['child']==arms[1]['child']and arms[0]['pv_final']==arms[1]['pv_final'];assert equal
 ratio=arms[1]['seconds']/arms[0]['seconds'];row=dict(family=f,game=g,prefix=length,ratio=ratio,equal=True,arms=arms,parent=record_value(s.state));rows.append(row);write_json(P/f'fresh-caller-{index:02}.json',row);print('FRESH_FILTER',f,g,length,round(ratio,3),[(a['fast'],a['decision']['completed_depth'],a['decision']['nodes'])for a in arms],flush=True)
long=rows[4:];passed=sum(r['ratio']<=.90for r in long)>=3;write_json(P/'fresh-caller-result.json',dict(rows=rows,seconds=time.monotonic()-START,criterion_passed=passed,long_prefix_passing=sum(r['ratio']<=.90for r in long),complete=True));print('PASS_GATE',passed,flush=True)