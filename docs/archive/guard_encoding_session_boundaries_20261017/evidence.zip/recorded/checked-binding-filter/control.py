from pathlib import Path
import sys,json,time,importlib.util
from dataclasses import replace
from unittest.mock import patch
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017';P=D/'checked-binding-filter'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core import semantic_executor as mod
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.limits import SearchLimits
spec=importlib.util.spec_from_file_location('private_filtered_binding',P/'filtered_binding.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
row=json.loads((D/'representation-continuation/pair-01.json').read_bytes());assert row['status']!='active';r=deserialize_ruleset(json.dumps(row['rules'][0]));c=replace(compile_semantic_ruleset(r),_legacy_compiled=None);s=GameSession(c);cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0);profile,_=build_semantic_opportunity_profile(c,cfg);START=time.monotonic();out=[]
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def comparable(d):return {k:v for k,v in record_value(d).items()if not(k.endswith('_seconds')or k.startswith('time_to_'))}
for length in (0,64):
 while s.state.ply_count<length:s.submit(decode(row['moves'][s.state.ply_count]['decisions'][0]['action']))
 assert record_value(s.state)==(row['initial_states'][0]if length==0 else row['moves'][length-1]['children'][0]);N=len(s.legal_actions())
 for mode in('precancel','q0D1'):
  arms=[]
  for fast in ((False,True)if length==0 else(True,False)):
   if time.monotonic()-START>=180:raise TimeoutError('Frozen180second prototype cap')
   for n in ('rollout','advisor','slack'):
    v=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not v.get('stopped')and not v.get('user_paused')
   token=CancellationToken()
   if mode=='precancel':token.cancel()
   player=AlphaBetaPlayer(c,evaluator_override=SemanticAttackEvaluator(c,profile,cfg,backend='core'),use_disk_cache=False,use_native_semantic_legality=False);before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter()
   with patch.object(mod,'semantic_action_for',m.filtered_action_for if fast else m.ORIGINAL):d=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=2*N+2,quiescence_max_depth=0,quiescence_hard_max_depth=0),cancel_token=token)
   sec=time.perf_counter()-t;assert before==(s.state,s.to_record(),s._search_witnesses);arms.append(dict(fast=fast,seconds=sec,decision=record_value(d)))
  arms.sort(key=lambda v:v['fast']);assert comparable(arms[0]['decision'])==comparable(arms[1]['decision']);ratio=arms[1]['seconds']/arms[0]['seconds'];out.append(dict(prefix=length,mode=mode,N=N,arms=arms,ratio=ratio,parent=record_value(s.state)));print('FILTER',length,mode,round(ratio,3),[(a['fast'],round(a['seconds'],3))for a in arms],flush=True)
write_json(P/'caller-result.json',dict(rows=out,seconds=time.monotonic()-START,complete=True,scope='Private exact-coordinate canonical iterator; no production code/default altered.'))