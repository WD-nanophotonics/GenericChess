"""Checked public action resolution need not trial unrelated legal successors."""
from copy import copy
from dataclasses import replace

import pytest

from conftest import make_ruleset, king_type, T
from generic_chess.core.actions import SemanticBoardMove, SemanticDropMove
from generic_chess.core.coordinates import Square, square_to_index
from generic_chess.core.errors import IllegalActionError, RuleSetMismatchError
from generic_chess.core.movement import RayAtom
from generic_chess.core.semantic_executor import SemanticEngine, semantic_action_for
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession


def session_with_stock():
    rule = make_ruleset(8, [king_type(), T('H', RayAtom((1, 0)), RayAtom((-1, 0)),
                                         RayAtom((0, 1)), RayAtom((0, -1)))],
                        lines=['KH......', '.h......', '........', '........',
                               '........', '........', '........', '......hk'])
    c = compile_legacy_ruleset_for_semantic_execution(rule)
    s = GameSession(c)
    capture = next(a for a in s.legal_actions()
                   if a.from_square == Square(1, 7) and a.to_square == Square(1, 6))
    s.submit(capture)
    reply = next(a for a in s.legal_actions()
                 if a.from_square == Square(7, 0) and a.to_square == Square(6, 1))
    s.submit(reply)
    assert s.state.position.hands[0].count('H') == 1
    assert len(s.state.history) == 3
    return s


@pytest.mark.parametrize('drop', [False, True])
def test_checked_membership_only_trials_requested_endpoint_and_preserves_child(monkeypatch, drop):
    session = session_with_stock()
    actions = session.legal_actions()
    assert len(actions) > 20
    action = next(a for a in actions if isinstance(a, SemanticDropMove)
                  and a.to_square == Square(2, 7)) if drop else next(
                      a for a in actions if isinstance(a, SemanticBoardMove)
                      and a.from_square == Square(1, 6) and a.to_square == Square(2, 6))
    expected = copy(session)
    expected.submit(action)
    before = session.state, session.to_record(), session._search_witnesses
    original = SemanticEngine._trial_child_if_s3_legal
    trials = []
    def observed(self, pattern, position, candidate, *args, **kwargs):
        trials.append((candidate.source, candidate.target))
        return original(self, pattern, position, candidate, *args, **kwargs)
    monkeypatch.setattr(SemanticEngine, '_trial_child_if_s3_legal', observed)
    engine = SemanticEngine(session.compiled)
    resolved = semantic_action_for(engine, session.state.position, action)
    membership_trials = tuple(trials)
    child = engine.apply(session.state.position, resolved)
    assert child == expected.state.position
    assert before == (session.state, session.to_record(), session._search_witnesses)
    target = square_to_index(action.to_square, session.compiled.board_shape)
    source = None if drop else square_to_index(action.from_square, session.compiled.board_shape)
    assert membership_trials and all(t == target for _, t in membership_trials)
    assert drop or all(s == source for s, _ in membership_trials)
    assert len(membership_trials) < len(actions)


@pytest.mark.parametrize('outside_source', [False, True])
def test_bad_coordinates_preserve_checked_error_and_fingerprint_priority(outside_source):
    session = session_with_stock()
    action = next(a for a in session.legal_actions() if isinstance(a, SemanticBoardMove))
    bad = replace(action, **({'from_square': Square(-1, 0)} if outside_source
                             else {'to_square': Square(8, 0)}))
    engine = SemanticEngine(session.compiled)
    with pytest.raises(IllegalActionError):
        semantic_action_for(engine, session.state.position, bad)
    mismatched = replace(session.state.position, ruleset_fingerprint='different-rules')
    with pytest.raises(RuleSetMismatchError):
        semantic_action_for(engine, mismatched, bad)