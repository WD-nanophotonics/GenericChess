from generic_chess.core.actions import BoardMove,DropMove,SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import square_to_index
from generic_chess.core import semantic_executor as module
ORIGINAL=module.semantic_action_for

def filtered_action_for(engine, position, action):
    source=target=None
    try:
        if isinstance(action,(BoardMove,SemanticBoardMove)):
            source=square_to_index(action.from_square,engine.support.board_shape)
            target=square_to_index(action.to_square,engine.support.board_shape)
        elif isinstance(action,(DropMove,SemanticDropMove)):
            target=square_to_index(action.to_square,engine.support.board_shape)
    except (ValueError,TypeError,AttributeError):
        return ORIGINAL(engine,position,action)
    if source is None and target is None:
        return ORIGINAL(engine,position,action)
    class NarrowView:
        support=engine.support
        def iter_legal_actions(self, position):
            for candidate,_binding in engine.iter_legal_action_bindings(position,source=source,target=target):
                yield candidate
    return ORIGINAL(NarrowView(),position,action)