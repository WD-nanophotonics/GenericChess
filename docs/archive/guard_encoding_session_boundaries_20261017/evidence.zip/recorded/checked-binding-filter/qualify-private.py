from pathlib import Path
import sys,importlib.util,json,time
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017/checked-binding-filter'
spec=importlib.util.spec_from_file_location('private_filtered_binding',D/'filtered_binding.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from generic_chess.core import semantic_executor as mod
from tools.local_agent.common import write_json
write_json(D/'private-qualification-plan.json',dict(mode='Private monkeypatch of resolver; canonical iterator/S3/S4 unchanged; normal production source untouched.',targets=['semantic_executor','semantic_binding_filters','rectangular_public_semantic_execution','rectangular_semantic_action_b4b','no_progress_search_context','generic_no_progress_draw','generic_no_progress_halfmove_fact','compiled_transition_triggers','f24c_mixed_mechanic_certification_r1'],expectation='Existing valid/invalid/ambiguity/S4/fullhistory regressions all pass; no rewriting tests.'))
mod.semantic_action_for=m.filtered_action_for
import pytest
names=['semantic_executor','semantic_binding_filters','rectangular_public_semantic_execution','rectangular_semantic_action_b4b','no_progress_search_context','generic_no_progress_draw','generic_no_progress_halfmove_fact','compiled_transition_triggers','f24c_mixed_mechanic_certification_r1']
code=pytest.main(['-q','-o','addopts=','-p','no:cacheprovider','--basetemp='+str(D/'private-pytest'),'--junitxml='+str(D/'private-source.xml'),*['tests/product/test_'+n+'.py'for n in names]])
raise SystemExit(code)