from pathlib import Path
import sys,time
from dataclasses import replace
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')]
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import LeapAtom
from generic_chess.rules.schema import RuleDeclaration,RuleDeclarationOutcomeBand,RuleWeightedMaterialMetric
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from scripts.research_record import record_value
from tools.local_agent.common import write_json
D=R/'.local_agent/guard-equivalence-20261017';rows=[]
class Zero:
 def evaluate(self,state):return 0
for kind in ('RESIGNATION','WIN','LOSS','RESTART','NO_CONTEST'):
 rule=make_ruleset(4,[king_type(),T('P',LeapAtom((0,1)))],lines=['K...','.P..','..p.','...k'])
 if kind!='RESIGNATION':rule=replace(rule,declarations=(RuleDeclaration(declaration_id='done',owner=0,require_not_in_check=False,weighted_metric=RuleWeightedMaterialMetric(weights={'K':1}),outcome_bands=(RuleDeclarationOutcomeBand(1,kind),)),))
 c=compile_legacy_ruleset_for_semantic_execution(rule);s=GameSession(c)
 if kind=='RESIGNATION':s.resign()
 else:s.declare('done')
 before=s.state,s.to_record(),s._search_witnesses;token=CancellationToken();token.cancel();player=AlphaBetaPlayer(c,evaluator_override=Zero(),use_disk_cache=False,use_native_semantic_legality=False);d=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=256,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0),cancel_token=token)
 assert before==(s.state,s.to_record(),s._search_witnesses) and not s.legal_actions() and not s.state.terminal_status.is_terminal
 rejected=None
 try:
  if d.declaration:s.declare(d.declaration.declaration_id)
  elif d.action is not None:s.submit(d.action)
 except Exception as e:rejected=type(e).__name__
 row=dict(kind=kind,session_result=record_value(s.result),root=record_value(s.state),record=record_value(s.to_record()),decision=record_value(d),submission_rejection=rejected);rows.append(row);print(kind,d.choice_kind,d.termination_reason,rejected,flush=True)
write_json(D/'session-marker-baseline.json',dict(rows=rows,scope='Actual already-finished session with authoritative Core state intentionally ongoing; no fabricated state or new game.'))