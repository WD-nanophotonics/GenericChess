from pathlib import Path
import sys,time,json
from dataclasses import replace
from unittest.mock import patch
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core import no_progress_context as np
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.limits import SearchLimits
row=json.loads((D/'representation-continuation/pair-01.json').read_bytes());assert row['status']!='active'
write_json(D/'root-import-cost-plan.json',dict(question='Does exact no-progress root replay materially consume a real long-history search/cancelled call?',source='Closed actual paired trajectory family1 count arm; not fabricate witnesses or import only final Position.',prefixes=[0,16,32,64],queries=8,modes=['precancel','q0D1'],forecast_seconds=60,whole_seconds=240,measurement='Nested from_state and no_progress.prepare timers; attribution only, no speedup or default change.',decision='If import>=20percent of actual caller on a longer prefix, investigate smallest existing-interface reuse/admission alternative; otherwise defer without new cache/framework.'))
r=deserialize_ruleset(json.dumps(row['rules'][0]));c=replace(compile_semantic_ruleset(r),_legacy_compiled=None);s=GameSession(c);cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0);p,_=build_semantic_opportunity_profile(c,cfg);started=time.monotonic();rows=[];original=SearchPathRuntime.from_state;prep=np.prepare

def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
for length in(0,16,32,64):
 while s.state.ply_count<length:s.submit(decode(row['moves'][s.state.ply_count]['decisions'][0]['action']))
 assert record_value(s.state)==(row['initial_states'][0]if length==0 else row['moves'][length-1]['children'][0])
 N=len(s.legal_actions())
 for mode in('precancel','q0D1'):
  if time.monotonic()-started>=240:raise TimeoutError('Frozen240second attribution cap')
  for n in ('rollout','advisor','slack'):
   f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not f.get('stopped')and not f.get('user_paused')
  timing={'import':0.,'prepare':0.};counts={'import':0,'prepare':0}
  def imported(*args,**kwargs):
   t=time.perf_counter()
   try:return original(*args,**kwargs)
   finally:timing['import']+=time.perf_counter()-t;counts['import']+=1
  def prepared(*args,**kwargs):
   t=time.perf_counter()
   try:return prep(*args,**kwargs)
   finally:timing['prepare']+=time.perf_counter()-t;counts['prepare']+=1
  token=CancellationToken()
  if mode=='precancel':token.cancel()
  player=AlphaBetaPlayer(c,evaluator_override=SemanticAttackEvaluator(c,p,cfg,backend='core'),use_disk_cache=False,use_native_semantic_legality=False);before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter()
  with patch.object(SearchPathRuntime,'from_state',imported),patch.object(np,'prepare',prepared):d=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=2*N+2,quiescence_max_depth=0,quiescence_hard_max_depth=0),cancel_token=token)
  elapsed=time.perf_counter()-t;assert before==(s.state,s.to_record(),s._search_witnesses)
  if mode=='precancel':assert d.termination_reason=='cancelled' and d.nodes==0
  else:assert d.completed_depth==1 or d.result_source in('root_immediate_win','root_declaration','completed_root_win')
  v=dict(prefix=length,mode=mode,root_degree=N,seconds=elapsed,timing=timing,counts=counts,import_share=timing['import']/elapsed,decision=record_value(d));rows.append(v);write_json(D/f'root-import-{length}-{mode}.json',v);print('IMPORT',length,mode,round(elapsed,3),round(v['import_share'],3),round(timing['prepare'],3),flush=True)
write_json(D/'root-import-cost-result.json',dict(rows=rows,seconds=time.monotonic()-started,source='Actual public prefix/state/witnesses reconstructed and matched closed original full states; timers nested, no modification.'))