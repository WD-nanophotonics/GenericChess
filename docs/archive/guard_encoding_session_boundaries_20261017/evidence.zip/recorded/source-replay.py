from pathlib import Path
import sys,json,time,traceback,collections,os
from copy import copy
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.session.session import GameSession
START=time.monotonic();counts=collections.Counter();done=[];failure=None
write_json(D/'source-reader-producer.json',dict(pid=os.getpid(),utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),source='source-replay.py',whole_cap_seconds=600))
def check():
 if time.monotonic()-START>=600:raise TimeoutError('Frozen600s public replay cap; retain partial')
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('Explicit project stop')
def decode(a):
 if not a:return PassAction()
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))

def verify(label,rule,initial,moves,record):
 check();c=replace(compile_semantic_ruleset(deserialize_ruleset(json.dumps(rule))),_legacy_compiled=None);s=GameSession(c);assert record_value(s.state)==initial;counts['initial_states']+=1
 for m in moves:
  check();d=m['decision'];before=s.state,s.to_record(),s._search_witnesses
  pv=copy(s)
  for a in d['principal_variation']:
   check();pv.submit(decode(a));counts['PV_edges']+=1
  assert before==(s.state,s.to_record(),s._search_witnesses)
  if d['choice_kind']=='DECLARATION':s.declare(d['declaration']['declaration_id']);counts['declarations']+=1
  else:s.submit(decode(d['action']));counts['committed_edges']+=1
  assert record_value(s.state)==m['child'];assert len(s.state.history)==s.state.ply_count+1 and len(s.history)==s.state.ply_count;counts['complete_child_states']+=1
 assert record_value(s.to_record())==record
 counts['records']+=1;counts['actual_terminal'if s.state.terminal_status.is_terminal else'administrative_UNKNOWN']+=1;done.append(dict(label=label,plies=s.state.ply_count,result=record_value(s.result)));write_json(D/'source-reader-progress.json',dict(counts=dict(counts),done=done,seconds=time.monotonic()-START));print('PUBLIC_REPLAY',label,s.state.ply_count,s.result.status.value,round(time.monotonic()-START,3),flush=True)
try:
 B=D/'representation-continuation'
 for path in sorted(B.glob('pair-*.json')):
  r=json.loads(path.read_bytes());assert r['status']!='active'
  for arm in(0,1):verify(f'encoding-f{r["family"]}-a{arm}',r['rules'][arm],r['initial_states'][arm],[dict(decision=m['decisions'][arm],child=m['children'][arm])for m in r['moves']],r['records'][arm])
 B=D/'node-admission-transfer';inputs=json.loads((B/'consumer-inputs.json').read_bytes())
 for path in sorted(B.glob('consumer-game-*.json')):
  r=json.loads(path.read_bytes());assert r['status']!='active';verify(f'node-game-{r["game"]}',next(i['rule']for i in inputs if i['family']==r['family']),r['initial_state'],r['moves'],r['record'])
except Exception as e:failure=dict(type=type(e).__name__,message=str(e),trace=traceback.format_exc());print('REPLAY_FAILURE',failure,flush=True)
finally:
 write_json(D/'source-reader-result.json',dict(counts=dict(counts),done=done,seconds=time.monotonic()-START,failure=failure,complete=counts['records']==24 and failure is None,scope='Current final public Core checked submit replay, exact raw full child/history/record equality plus legal PV execution; not independent rules oracle, no new search/games.'))