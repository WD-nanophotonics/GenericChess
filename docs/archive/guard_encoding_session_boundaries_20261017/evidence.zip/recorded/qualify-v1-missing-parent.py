from pathlib import Path
import sys
W=Path.cwd().resolve()
sys.meta_path[:]=[f for f in sys.meta_path if not getattr(f,'__module__','').startswith('__editable___generic_chess_')]
sys.path[:]=[str(W)]+[p for p in sys.path if p and Path(p).resolve()!=W and not (Path(p)/'generic_chess').is_dir()]
import generic_chess
from generic_chess import native
assert Path(generic_chess.__file__).resolve().is_relative_to(W)
assert native.native_available() and Path(native._module().__file__).resolve().is_relative_to(W)
import pytest
code=pytest.main(['-o','addopts=','-p','no:cacheprovider','--basetemp=.local_agent/pytest-temp','--junitxml=.local_agent/source.xml','-q','tests/product/test_finished_session_search.py','tests/product/test_semantic_empty_guards.py','tests/product/test_inert_hand_profile.py','tests/product/test_semantic_opportunity.py','tests/product/test_semantic_rectangle_profile.py','tests/product/test_semantic_ray_equivalence.py','tests/product/test_semantic_zone_guards.py','tests/product/test_ai_search.py','tests/product/test_search_semantic_checkpoint.py','tests/development/test_unfamiliar_search.py'])
wrong=[n for n,m in sys.modules.items()if n.startswith('generic_chess')and getattr(m,'__file__',None)and not Path(m.__file__).resolve().is_relative_to(W)]
assert not wrong,wrong
print('ISOLATED_EXACT_PYTHON_SOURCE_MODULES',len([n for n in sys.modules if n.startswith('generic_chess')]),'PASS'if code==0 else'FAIL',flush=True)
raise SystemExit(code)
