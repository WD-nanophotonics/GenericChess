from pathlib import Path
import sys,json
from dataclasses import replace
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')]
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import LeapAtom
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.tuning import SearchTuning
from scripts.research_record import record_value
from tools.local_agent.common import write_json
D=R/'.local_agent/guard-equivalence-20261017'
class Material:
 def evaluate(self,state):
  own=state.position.side_to_move
  return sum((1 if p.owner==own else -1)*100 for p in state.position.board if p and p.current_type_id=='P')
r=make_ruleset(4,[king_type(),T('P',LeapAtom((0,1)))],lines=['K...','.P..','..p.','...k']);c=compile_legacy_ruleset_for_semantic_execution(r);p=AlphaBetaPlayer(c,evaluator_override=Material(),use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
s=GameSession(c);limits=SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0);first=p.choose_action(s,limits);assert first.completed_depth==2 and len(p._tt)>0
# Capture actual mutable TT payload values, not aliases to live entries.
def ttsnapshot():return (p._tt.generation,p._tt_q_depths,tuple((k,e.depth,e.score,e.bound,e.best_action,e.generation)for k,e in p._tt._data.items()))
s.resign();before=ttsnapshot();record=s.to_record();ended=p.choose_action(s,replace(limits,quiescence_max_depth=2,quiescence_hard_max_depth=2));assert ttsnapshot()==before and s.to_record()==record
fresh=GameSession(c);after=p.choose_action(fresh,limits);assert after.completed_depth==2 and after.action in fresh.legal_actions();assert (first.score,first.action,first.principal_variation)==(after.score,after.action,after.principal_variation)
write_json(D/'warm-player-session-result.json',dict(first=record_value(first),ended=record_value(ended),fresh=record_value(after),tt_entries=len(p._tt),tt_terminal_unchanged=True,source='Actual player warmed by completeD2; external resignation then different q request does not mutate table, fresh session agrees.'))
print('WARM_PLAYER',len(p._tt),first.completed_depth,ended.choice_kind,after.completed_depth,after.tt_hits)