from pathlib import Path
import sys,time,json
from dataclasses import replace,asdict
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from test_semantic_empty_guards import guarded_leap
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import RayAtom
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
from tools.local_agent.common import write_json
D=R/'.local_agent/guard-equivalence-20261017';start=time.monotonic();rows=[]
write_json(D/'caller-normalized-plan.json',dict(calls=2,forecast_seconds=10,whole_cap_seconds=60,question='Does the existing static candidate discrepancy reach a lawful full-session search consumer?',limits=dict(depth=1,nodes=256,seconds=5,q=0),no_game_or_training=True))
a=guarded_leap();board=[None]*15
board[0]=Piece(0,'K','K');board[14]=Piece(1,'K','K');board[5]=Piece(0,'H','H');board[12]=Piece(1,'B','B')
a=replace(a,initial_position=tuple(tuple(board[r*5:(r+1)*5]) for r in range(3)),piece_types=tuple(PieceType('B','B',(RayAtom((1,0)),)) if p.type_id=='B' else p for p in a.piece_types))
b=replace(a,semantic_actions=tuple(replace(p,state_guards=tuple(replace(g,aggregation='exists') for g in p.state_guards)) for p in a.semantic_actions))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for aggregation,r in zip(('count','exists'),(a,b)):
 if time.monotonic()-start>=60:raise TimeoutError('frozen60s cap')
 c=compile_ruleset_for_execution(r);s=GameSession(c);p,scope=build_semantic_opportunity_profile(c,cfg);e=Evaluator(c,p,cfg);before=s.to_record()
 player=AlphaBetaPlayer(c,evaluator_override=e,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False)
 d=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=256,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
 assert s.to_record()==before and d.completed_depth==1
 root=record_value(s.state);s.submit(d.action)
 rows.append(dict(aggregation=aggregation,rule=ruleset_to_dict(r),profile=record_value(p),scope=scope,root=root,root_degree=len(GameSession(c).legal_actions()),decision=record_value(d),record=record_value(s.to_record()),child=record_value(s.state)))
 print(aggregation,p.board_value_by_type,p.hand_value_by_base_type,d.completed_depth,d.score,d.action,flush=True)
write_json(D/'caller-normalized-result.json',dict(rows=rows,elapsed_seconds=time.monotonic()-start,scope='Two lawful full-state one-query consumers, no quality or WDL claim.'))