from pathlib import Path
import sys,time,json,importlib.util
from dataclasses import replace
from copy import copy
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/guard-equivalence-20261017/wide-repaired-transfer'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
spec=importlib.util.spec_from_file_location('private_projection',R/'.local_agent/root-reuse-20261017/attack-projection/readonly_attack_projection.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
start=json.loads((D/'generation-start.json').read_bytes())['monotonic_start'];rows=[]
def check():
 if time.monotonic()-start>=3000:raise TimeoutError('Frozen whole3000seconds')
 for n in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('Explicit user stop')
def no_time(v):return {k:x for k,x in v.items()if not(k.endswith('_seconds')or k.startswith('time_to_'))}
inputs=json.loads((D/'consumer-inputs.json').read_bytes())
assert len(inputs)==4,'Keep missing generation slots; do not replace'
for inp in inputs:
 check();f=inp['family'];rule=deserialize_ruleset(json.dumps(inp['rule']));c=replace(compile_semantic_ruleset(rule),_legacy_compiled=None);s=GameSession(c);cfg=replace(EvaluationConfig(),anchor_escape_weight=0,promotion_potential_weight=0);profile,scope=build_semantic_opportunity_profile(c,cfg);parent=s.state,s.to_record(),s._search_witnesses;N=len(s.legal_actions());arms=[]
 for accelerated in ((False,True)if f%2==0 else(True,False)):
  check();t=time.perf_counter();ev=m.ReadOnlyAttackProjection(rule,c,profile,cfg)if accelerated else SemanticAttackEvaluator(c,profile,cfg,backend='core');setup=time.perf_counter()-t
  if accelerated:
   expected=SemanticAttackEvaluator(c,profile,cfg,backend='core')._attack_maps(s.state);actual=ev._attack_maps(s.state);assert actual==expected
  player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(require_full_pv=True));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=2*N+2,max_time_seconds=30,quiescence_max_depth=0,quiescence_hard_max_depth=0));seconds=time.perf_counter()-t
  assert parent==(s.state,s.to_record(),s._search_witnesses) and d.completed_depth==1 and d.runtime_depth_balanced
  ch=copy(s)
  if d.action is not None:ch.submit(d.action)
  pv=copy(s)
  for a in d.principal_variation:pv.submit(a)
  arms.append(dict(accelerated=accelerated,setup_seconds=setup,call_seconds=seconds,total_seconds=setup+seconds,decision=record_value(d),child=record_value(ch.state),pv_final=record_value(pv.state),native_feature_queries=getattr(ev,'_projection_calls',0)))
  write_json(D/f'gate-{f}-{int(accelerated)}.json',dict(family=f,N=N,parent=record_value(s.state),arm=arms[-1]))
 arms.sort(key=lambda a:a['accelerated']);equal=no_time(arms[0]['decision'])==no_time(arms[1]['decision'])and arms[0]['child']==arms[1]['child']and arms[0]['pv_final']==arms[1]['pv_final'];assert equal
 ratio=arms[1]['total_seconds']/arms[0]['total_seconds'];row=dict(family=f,root_degree=N,ratio=ratio,equal_non_time_and_full_states=equal,arms=arms);rows.append(row);print('GATE',f,N,round(ratio,3),[(a['accelerated'],round(a['total_seconds'],3),a['decision']['nodes'])for a in arms],flush=True)
passed=sum(r['ratio']<=.90 for r in rows)>=3
write_json(D/'gate-result.json',dict(rows=rows,passed=passed,required_count=3,passing_count=sum(r['ratio']<=.90 for r in rows),seconds=time.monotonic()-start,decision='Execute original16 planned games'if passed else'DEFER: zero games, preserve original16 unstarted slots.'))
print('GATE_PASSED',passed,flush=True)