"""Declared fixed-rule common-slot board-leaf development ablation.
Rule already constructed;17 semantic-effect/physical-child-selected contexts,
instant legal unit task under common standalone actor slots. No human fit;
Core only because Native finalbuild blocked. Raw exactmeans, median1000 scaling
and bankersrounding, no floor if median0. Hand/order prices fixed at reference;
this is NOT a complete calibrated material model or independent validation.
Four existing witness roots,2profiles, D2/8192/5sec/q2hard8<=40sec search, sampling
<=120sec. Preserve all roots/caps; changed choices alone are not improvements.
"""
import sys,json,time,hashlib,statistics
from pathlib import Path
from dataclasses import replace
from collections import defaultdict
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_to_dict,action_from_dict,action_is_board,action_is_drop
from generic_chess.core.transition import legal_successors
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;src=root/'.local_agent/compression-20261009/fixed-rule-compression.json';d=json.loads(src.read_bytes());out=p/'stable-task-caller.json';assert not out.exists();start=time.perf_counter();c=compile_ruleset_for_execution(ruleset_from_dict(d['rules']));eng=semantic_engine_for(c);s=GameSession(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);res=dict(scope=__doc__,complete=False,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fingerprint=c.ruleset_fingerprint,route=[],cells=[],calls=[],sampling_transitions=0)
def physical(state):
 z=record_value(state.position);z.pop('ruleset_fingerprint');return json.dumps(dict(position=z,terminal=record_value(state.terminal_status)),sort_keys=True)
def ordinary_count(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(v for t,v in pos.hands[owner].counts if t not in anchors)
def priority(pair):
 a,ch=pair;pos=s.state.position;side=pos.side_to_move;quiet=False
 if action_is_board(a):
  x=pos.board[a.from_square.rank*6+a.from_square.file];y=ch.position.board[a.to_square.rank*6+a.to_square.file];quiet=pos.board[a.to_square.rank*6+a.to_square.file] is None and x is not None and y is not None and x.owner==y.owner and x.base_type_id==y.base_type_id and x.current_type_id!=y.current_type_id
 return (0 if quiet else 1 if action_is_drop(a) else 2 if ordinary_count(ch.position,1-side)<ordinary_count(pos,1-side) else 3,physical(ch))
try:
 for ply in range(17):
  assert time.perf_counter()-start<120
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  pos=s.state.position;side=pos.side_to_move;sources=[i for i,x in enumerate(pos.board) if x is not None and x.owner==side and x.current_type_id not in anchors];before=ordinary_count(pos,1-side)
  for source in sources:
   for t in types:
    board=list(pos.board);board[source]=Piece(side,t,t);cp=replace(pos,board=tuple(board));rewards=[]
    for a,b in eng.iter_legal_action_bindings(cp):
     if a.source==source:
      child=eng._transition(cp,a,b);rewards.append(before-ordinary_count(child,1-side));res['sampling_transitions']+=1
    res['cells'].append(dict(ply=ply,source=source,type=t,task=max([0]+rewards)))
  write_record(out,res)
  if ply<16:
   if s.state.terminal_status.is_terminal:break
   pairs=legal_successors(s.state,c)
   if not pairs:break
   a,ch=min(pairs,key=priority);s.submit(a);res['route'].append(dict(action=action_to_dict(a),state=record_value(s.state)))
 means={}
 for t in types:
  contexts=defaultdict(list)
  for r in res['cells']:
   if r['type']==t:contexts[r['ply']].append(r['task'])
  means[t]=sum((Fraction(sum(v),len(v)) for v in contexts.values()),Fraction())/len(contexts)
 median=statistics.median(means.values());res['raw_means']=means;res['median']=median;assert median>0,'No positive normalization, retain raw failure'
 cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);base=build_ruleset_profile(c,cfg);board=dict(base.board_value_by_type);board.update({t:round(1000*mu/median) for t,mu in means.items()});candidate=replace(base,board_value_by_type=board);res['profiles']=dict(default=record_value(base),board_ablation=record_value(candidate));res['rounding_residual']={t:Fraction(board[t])-1000*means[t]/median for t in types};write_record(out,res)
 reference=SemanticAttackEvaluator(c,base,cfg,backend='core')
 class FrozenOrdering(SemanticAttackEvaluator):
  def capture_order_value(self,*args):return reference.capture_order_value(*args)
  def type_value(self,*args):return reference.type_value(*args)
 evaluators={'default':reference,'board_ablation':FrozenOrdering(c,candidate,cfg,backend='core')}
 def transform(t):
  z=d['transform_actions'][t];return action_from_dict(dict(kind='semantic_board',pattern_id=z['pattern_id'],geometry_id=z['geometry_id'],actor_type_id=z['actor_type_id'],**{'from':[z['from_square']['file'],z['from_square']['rank']],'to':[z['to_square']['file'],z['to_square']['rank']],'promotion_target_id':z['promotion_target_id']}))
 summary=json.loads((root/'.local_agent/compression-20261009/compression-summary.json').read_bytes());sample_seconds=time.perf_counter()-start;res['sampling_seconds']=sample_seconds
 for delta in (-1,1):
  row=d['rows'][summary['conditional_extreme_witness_indices'][str(delta)]]
  for target in ('P','X'):
   session=GameSession(c);session.submit(transform(target));session.submit(action_from_dict(row['reply']));assert record_value(session.state)==row['cells'][target]['state'];before=(session.state,session.history,session._search_witnesses)
   for name in ('default','board_ablation'):
    assert time.perf_counter()-start<200
    player=AlphaBetaPlayer(c,evaluator_override=evaluators[name],use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();decision=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));seconds=time.perf_counter()-t;validate_pv(session,decision);assert (session.state,session.history,session._search_witnesses)==before;res['calls'].append(dict(delta=delta,target=target,profile=name,seconds=seconds,decision=record_value(decision)));write_record(out,res);print(delta,target,name,decision.completed_depth,decision.termination_reason,decision.score,round(seconds,3),flush=True)
 res['complete']=True
finally:res['seconds']=time.perf_counter()-start;write_record(out,res)
print('raw',res.get('raw_means'),'board',res.get('profiles',{}).get('board_ablation',{}).get('board_value_by_type'))
