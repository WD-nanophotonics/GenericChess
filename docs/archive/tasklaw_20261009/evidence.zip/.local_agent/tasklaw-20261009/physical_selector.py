"""Minimal semantic-role/physical-outcome coverage selector feasibility.
Seed2003 original/semantic-order/movement-order aliases. Same16ply route length;
priority quiet current-type change, drop, ordinarycapture,other; canonical full
physical child tie-break, fingerprintexcluded. Same singleauxslot mapping and
no action-class/target-cycle adjudication in these rules. Never merge search or
repetition history. Actual chosen public action/history stays per-session.
Finite alias control, not canonicalization for arbitrary history-sensitive games.
<=120sec/10000eager child transitions; no new default/law/strength claim.
"""
import sys,json,time,hashlib
from pathlib import Path
from collections import defaultdict
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_to_dict,action_is_board,action_is_drop
from generic_chess.core.transition import legal_successors
from generic_chess.session.session import GameSession
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;original=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes())['cases'][3];out=p/'physical-selector.json';assert not out.exists();start=time.perf_counter();result=dict(scope=__doc__,complete=False,rows=[],transitions=0)
def physical(state):
 d=record_value(state.position);d.pop('ruleset_fingerprint');return json.dumps(dict(position=d,terminal=record_value(state.terminal_status)),sort_keys=True)
for label,rules in [('original',original['rules']),('semantic_order',json.loads((p/'encoding-alias.json').read_bytes())['alias_rules']),('movement_order',json.loads((p/'movement-order-alias.json').read_bytes())['alias_rules'])]:
 c=compile_ruleset_for_execution(ruleset_from_dict(rules));assert not c.repeated_cycle_target_conditions and not c.consecutive_action_adjudications
 s=GameSession(c);row=dict(label=label,route=[]);result['rows'].append(row)
 for ply in range(16):
  assert time.perf_counter()-start<120 and result['transitions']<10000
  if s.state.terminal_status.is_terminal:break
  pairs=legal_successors(s.state,c);result['transitions']+=len(pairs);before=s.state.position;side=before.side_to_move
  def priority(pair):
   a,child=pair;after=child.position;quiet_change=False
   if action_is_board(a):
    src=a.from_square.rank*6+a.from_square.file;target=a.to_square.rank*6+a.to_square.file;x=before.board[src];y=after.board[target]
    quiet_change=before.board[target] is None and x is not None and y is not None and x.owner==y.owner and x.base_type_id==y.base_type_id and x.current_type_id!=y.current_type_id
   capture=sum(x is not None and x.owner!=side for x in after.board)<sum(x is not None and x.owner!=side for x in before.board)
   return (0 if quiet_change else 1 if action_is_drop(a) else 2 if capture else 3,physical(child))
  a,expected=min(pairs,key=priority);s.submit(a);assert physical(s.state)==physical(expected);row['route'].append(dict(ply=ply+1,action=action_to_dict(a),physical=physical(s.state)))
reference=[r['physical'] for r in result['rows'][0]['route']]
for row in result['rows'][1:]:assert [r['physical'] for r in row['route']]==reference
result['complete']=True;result['seconds']=time.perf_counter()-start;write_record(out,result);print('routes',[len(r['route']) for r in result['rows']],'transitions',result['transitions'],'seconds',result['seconds'])
