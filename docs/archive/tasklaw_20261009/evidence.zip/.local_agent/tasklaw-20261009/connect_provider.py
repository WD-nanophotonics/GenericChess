from pathlib import Path
p=Path('generic_chess/ai/alphabeta/native_legality.py');s=p.read_text();needle='    def __call__(self, position, ply_count, checkpoint=None):';s=s.replace(needle,'''    def has_legal_action(self, position, ply_count, checkpoint=None):
        """Existence probe only; do not populate/decode a full child action set."""
        from ...native.semantic import pack_position, has_legal_action

        if checkpoint is not None:
            checkpoint()
        native_position = pack_position(
            self.native_rules, self._state_only_payload(position, ply_count))
        if checkpoint is not None:
            checkpoint()
        return has_legal_action(
            self.native_rules, native_position, checkpoint=checkpoint)

'''+needle);p.write_text(s)
p=Path('generic_chess/core/search_runtime.py');s=p.read_text();s=s.replace('        self.legal_provider_calls = 0','        self.legal_provider_probe_calls = 0\n        self.legal_provider_probe_seconds = 0.0\n        self.legal_provider_calls = 0',1);s=s.replace('            self.stats.native_legality_calls = self.legal_provider_calls','            self.stats.native_legality_probe_calls = self.legal_provider_probe_calls\n            self.stats.native_legality_probe_seconds = self.legal_provider_probe_seconds\n            self.stats.native_legality_calls = self.legal_provider_calls',1)
needle='    def _legal_actions_from_provider(self, checkpoint):';s=s.replace(needle,'''    def has_legal_action(self, engine, checkpoint=None):
        """Opaque provider existence hook; never cache it as a complete set.

        Terminal/history adjudication stays in Core. Providers without the
        optional hook retain the streaming Core predicate. Cancellation uses
        the same non-swallowing wrapper as full legal generation.
        """
        import time

        provider = self._legal_binding_provider
        probe = getattr(provider, "has_legal_action", None)
        if self._legal_provider_active and probe is not None:
            checked, was_aborted = self._provider_checkpoint(checkpoint)
            started = time.perf_counter()
            try:
                checked()
                result = probe(self.position, self.ply_count, checked)
                checked()
                if type(result) is not bool:
                    raise ValueError("legal availability provider returned a non-bool")
            except BaseException as exc:
                if was_aborted() or not isinstance(exc, Exception):
                    raise
                if bool(getattr(provider, "strict", False)):
                    raise
                self.legal_provider_fallbacks += 1
                self.legal_provider_operational_failures += 1
                self._legal_provider_active = False
                self._sync_stats()
            else:
                self.legal_provider_probe_calls += 1
                self.legal_provider_probe_seconds += time.perf_counter() - started
                self._sync_stats()
                return result
        return engine.has_legal_action(self.position, checkpoint=checkpoint)

'''+needle);p.write_text(s)
p=Path('generic_chess/core/terminal.py');s=p.read_text();s=s.replace('has_legal = engine.has_legal_action(position, checkpoint=checkpoint)','has_legal = runtime.has_legal_action(engine, checkpoint=checkpoint)',1);p.write_text(s)
p=Path('generic_chess/ai/alphabeta/statistics.py');s=p.read_text().replace('    native_legality_calls: int = 0','    native_legality_probe_calls: int = 0\n    native_legality_probe_seconds: float = 0.0\n    native_legality_calls: int = 0',1);p.write_text(s)
