"""Movement-order alias endpoint task-average sensitivity, Core only.
Only finalply16 differs in the observed16step coverage route; reuse unchanged
first16context means and recompute both final backgrounds. No new sample law,
fit/default; strict original endpoint task replay before alias comparison.
"""
import sys,json,hashlib,time
from pathlib import Path
from dataclasses import replace
from collections import defaultdict
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import write_record
p=Path(__file__).parent;control=json.loads((p/'movement-order-alias.json').read_bytes());original=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes())['cases'][3];old=json.loads((p/'common-slot-law.json').read_bytes());out=p/'alias-task-average.json';assert not out.exists();start=time.perf_counter();result=dict(scope=__doc__,complete=False,rows=[],profiles={},input_sha256={name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ['movement-order-alias.json','common-slot-law.json']})
for label,rule,route in [('original',original['rules'],original['route']),('alias',control['alias_rules'],control['alias_route'])]:
 c=compile_ruleset_for_execution(ruleset_from_dict(rule));s=GameSession(c);eng=semantic_engine_for(c)
 for step in route:s.submit(action_from_dict(step['action']))
 pos=s.state.position;side=pos.side_to_move;anchors={t.type_id for t in c.piece_types if t.is_anchor};types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);sources=[i for i,x in enumerate(pos.board) if x is not None and x.owner==side and x.current_type_id not in anchors];before=sum(x is not None and x.owner!=side and x.current_type_id not in anchors for x in pos.board)+sum(v for t,v in pos.hands[1-side].counts if t not in anchors);means={}
 for t in types:
  values=[]
  for source in sources:
   assert time.perf_counter()-start<60
   board=list(pos.board);board[source]=Piece(side,t,t);cp=replace(pos,board=tuple(board));rewards=[]
   for a,b in eng.iter_legal_action_bindings(cp):
    if a.source!=source:continue
    child=eng._transition(cp,a,b);after=sum(x is not None and x.owner!=side and x.current_type_id not in anchors for x in child.board)+sum(v for tt,v in child.hands[1-side].counts if tt not in anchors);rewards.append(before-after)
   value=max([0]+rewards);values.append(value)
   if label=='original':assert value==next(r['task'] for r in old['cells'] if r['seed']==original['seed'] and r['ply']==16 and r['source']==source and r['type']==t)
  means[t]=Fraction(sum(values),len(values))
 cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);result['profiles'][label]={name:dict(prof.board_value_by_type) for name,prof in [('default',build_ruleset_profile(c,cfg)),('semantic',build_semantic_opportunity_profile(c,cfg)[0])]};result['rows'].append(dict(label=label,final_context_means=means,sources=sources))
assert result['profiles']['original']==result['profiles']['alias']
old_final,new_final=[r['final_context_means'] for r in result['rows']];base={r['type']:Fraction(r['means']['task']) for r in old['summary'] if r['seed']==original['seed']};result['original_average']=base;result['alias_average']={t:base[t]+(new_final[t]-old_final[t])/17 for t in base};result['delta']={t:(new_final[t]-old_final[t])/17 for t in base};result['seconds']=time.perf_counter()-start;result['complete']=True;write_record(out,result);print(result)
