"""Exact summaries of already observed task-law/caller records only.
No new fit/sample, common-slot empirical averages are declared approximations.
A task-table chooser is tautologically optimal among constant choices on its
own average law, not a heldout improvement. Compare conditional oracle gap and
existing static selectors without equating material points with task units.
"""
import json,hashlib,statistics
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path('.local_agent/tasklaw-20261009');d=json.loads((p/'common-slot-law.json').read_bytes());census=json.loads((p/'legal-census.json').read_bytes());events=json.loads((p/'first-legal-events.json').read_bytes());result=dict(scope=__doc__,rules=[],identity_checks=[],event_pairs=[])
lookup={(r['seed'],r['ply'],r['source']):r for r in census['actors']}
for r in d['cells']:
 old=lookup[r['seed'],r['ply'],r['source']]
 if old['type']==r['type'] and old['base']==r['type'] and not old['promoted']:
  assert r['task']==old['task'] and r['geometric_count']==old['geometric_count'];result['identity_checks'].append([r['seed'],r['ply'],r['source']])
for seed in sorted({r['seed'] for r in d['cells']}):
 rows=[r for r in d['cells'] if r['seed']==seed];cells=defaultdict(dict);types=sorted({r['type'] for r in rows});means={r['type']:Fraction(r['means']['task']) for r in d['summary'] if r['seed']==seed};profiles=next(r['profiles'] for r in census['rules'] if r['seed']==seed);selectors={name:[t for t in types if prof['board'][t]==max(prof['board'][tt] for tt in types)] for name,prof in profiles.items()};selectors['common_task_mean']=[t for t in types if means[t]==max(means.values())]
 for r in rows:cells[r['ply'],r['source']][r['type']]=r['task']
 contextual=defaultdict(list)
 for (ply,source),values in cells.items():
  assert set(values)==set(types)
  oracle=max(values.values());rewards={name:Fraction(sum(values[t] for t in choices),len(choices)) for name,choices in selectors.items()};contextual[ply].append(dict(oracle=Fraction(oracle),**rewards))
 rewards={k:sum((sum((r[k] for r in rs),Fraction())/len(rs) for rs in contextual.values()),Fraction())/len(contextual) for k in ['oracle',*selectors]}
 result['rules'].append(dict(seed=seed,common_means=means,selectors=selectors,expected_rewards=rewards,conditional_oracle_regrets={k:rewards['oracle']-v for k,v in rewards.items() if k!='oracle'},max_task=max(r['task'] for r in rows),presence_means={r['type']:r['context_means']['task'] for r in census['summary'] if r['seed']==seed and r['group']=='all'}))
sigkeys=['action','score','principal_variation','completed_depth','nodes','qnodes','termination_reason']
for row in events['cases']:
 old=next(r for r in row['searches'] if not r['prototype']);new=next(r for r in row['searches'] if r['prototype']);exact=all(old['decision'][k]==new['decision'][k] for k in sigkeys);assert exact
 result['event_pairs'].append(dict(seed=row['seed'],ply=row['ply'],exact_signature=exact,baseline_seconds=old['seconds'],first_seconds=new['seconds'],wall_change=1-new['seconds']/old['seconds'],first_probe_calls=new['stats']['native_legality_probe_calls'],full_action_count_equal=old['stats']['native_legality_actions']==new['stats']['native_legality_actions'],pushes_equal=old['stats']['runtime_pushes']==new['stats']['runtime_pushes']))
result['events_summary']=dict(pairs=len(result['event_pairs']),median_wall_reduction=statistics.median(r['wall_change'] for r in result['event_pairs']),baseline_wall=sum(r['baseline_seconds'] for r in result['event_pairs']),first_wall=sum(r['first_seconds'] for r in result['event_pairs']),scope='Prior successfully imported pre-reentrancy-correction binary; final blocked candidate not deployed.')
result['inputs_sha256']={name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ['common-slot-law.json','legal-census.json','first-legal-events.json']};write_record(p/'tasklaw-summary.json',result)
print('identity',len(result['identity_checks']));print(result['events_summary'])
for r in result['rules']:print(r)
