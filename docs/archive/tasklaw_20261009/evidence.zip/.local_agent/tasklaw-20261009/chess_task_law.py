"""Chess development common-slot unit task:17 physical-selected contexts,Core,120sec/100000transition cap,no material/default/holdout claim."""
import sys,json,time,hashlib,statistics
from pathlib import Path
from dataclasses import replace
from collections import defaultdict
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_to_dict,action_from_dict,action_is_board,action_is_drop
from generic_chess.core.transition import legal_successors
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;src=root/'.local_agent/compression-20261009/fixed-rule-compression.json';d=json.loads(src.read_bytes());out=p/'chess-task-law.json';assert not out.exists();start=time.perf_counter();c=compile_ruleset_for_execution(build_western_chess_ruleset());eng=semantic_engine_for(c);s=GameSession(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);res=dict(scope=__doc__,complete=False,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fingerprint=c.ruleset_fingerprint,route=[],cells=[],calls=[],sampling_transitions=0)
def physical(state):
 z=record_value(state.position);z.pop('ruleset_fingerprint');return json.dumps(dict(position=z,terminal=record_value(state.terminal_status)),sort_keys=True)
def ordinary_count(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(v for t,v in pos.hands[owner].counts if t not in anchors)
def priority(pair):
 a,ch=pair;pos=s.state.position;side=pos.side_to_move;quiet=False
 if action_is_board(a):
  x=pos.board[a.from_square.rank*c.board_shape.width+a.from_square.file];y=ch.position.board[a.to_square.rank*c.board_shape.width+a.to_square.file];quiet=pos.board[a.to_square.rank*c.board_shape.width+a.to_square.file] is None and x is not None and y is not None and x.owner==y.owner and x.base_type_id==y.base_type_id and x.current_type_id!=y.current_type_id
 return (0 if quiet else 1 if action_is_drop(a) else 2 if ordinary_count(ch.position,1-side)<ordinary_count(pos,1-side) else 3,physical(ch))
try:
 for ply in range(17):
  assert time.perf_counter()-start<120
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  pos=s.state.position;side=pos.side_to_move;sources=[i for i,x in enumerate(pos.board) if x is not None and x.owner==side and x.current_type_id not in anchors];before=ordinary_count(pos,1-side)
  for source in sources:
   for t in types:
    board=list(pos.board);board[source]=Piece(side,t,t);cp=replace(pos,board=tuple(board));rewards=[]
    for a,b in eng.iter_legal_action_bindings(cp):
     if a.source==source:
      child=eng._transition(cp,a,b);rewards.append(before-ordinary_count(child,1-side));res['sampling_transitions']+=1;assert res['sampling_transitions']<=100000;assert time.perf_counter()-start<120
    res['cells'].append(dict(ply=ply,source=source,type=t,task=max([0]+rewards)))
  write_record(out,res)
  if ply<16:
   if s.state.terminal_status.is_terminal:break
   pairs=legal_successors(s.state,c)
   if not pairs:break
   a,ch=min(pairs,key=priority);s.submit(a);res['route'].append(dict(action=action_to_dict(a),state=record_value(s.state)))
 means={}
 for t in types:
  contexts=defaultdict(list)
  for r in res['cells']:
   if r['type']==t:contexts[r['ply']].append(r['task'])
  means[t]=sum((Fraction(sum(v),len(v)) for v in contexts.values()),Fraction())/len(contexts)
 median=statistics.median(means.values());res['complete']=True;res['raw_means']=means;res['median']=median;write_record(out,res);print('raw',means,'median',median,flush=True);raise SystemExit(0);res['raw_means']=means;res['median']=median;assert median>0,'No positive normalization, retain raw failure'
 cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);base=build_ruleset_profile(c,cfg);board=dict(base.board_value_by_type);board.update({t:round(1000*mu/median) for t,mu in means.items()});candidate=replace(base,board_value_by_type=board);res['profiles']=dict(default=record_value(base),board_ablation=record_value(candidate));res['rounding_residual']={t:Fraction(board[t])-1000*means[t]/median for t in types};write_record(out,res)

finally:res['seconds']=time.perf_counter()-start;write_record(out,res)
