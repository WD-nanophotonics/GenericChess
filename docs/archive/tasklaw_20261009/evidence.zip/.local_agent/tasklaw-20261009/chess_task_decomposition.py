"""Decompose the already declared Chess task law; no new contexts or fit.
Replay17backgrounds; raw geometry count/any versus stored legal task at common
slots, source current role and check. Core only,<=120sec/20000edge checks.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from collections import defaultdict
from fractions import Fraction
root=Path.cwd();sys.path[:0]=[str(root),str(root/'.local_agent/finite-law-20261009')]
from finite_law import collect
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
p=Path(__file__).parent;inp=p/'chess-task-law.json';d=json.loads(inp.read_bytes());out=p/'chess-task-decomposition.json';assert not out.exists();start=time.perf_counter()
c=compile_ruleset_for_execution(build_western_chess_ruleset());assert c.ruleset_fingerprint==d['fingerprint'];s=GameSession(c);eng=semantic_engine_for(c);area=c.board_shape.area;anchors={t.type_id for t in c.piece_types if t.is_anchor}
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);edges={t:collect(c,c.ir,t,cfg)[0]['target_enemy'] for t in d['raw_means']}
result=dict(scope=__doc__,complete=False,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),rows=[],edge_checks=0)
try:
 for ply in range(17):
  pos=s.state.position;side=pos.side_to_move;occ={i for i,x in enumerate(pos.board) if x is not None}
  for row in [r for r in d['cells'] if r['ply']==ply]:
   assert time.perf_counter()-start<120
   source=row['source'];t=row['type'];targets=[]
   for target,events in edges[t][side*area+source].items():
    enemy=pos.board[target]
    result['edge_checks']+=1;assert result['edge_checks']<=20000
    if enemy is not None and enemy.owner!=side and enemy.current_type_id not in anchors and any(not occ&clear and (k is None or len(occ&scope)==k) for clear,scope,k in events):targets.append(target)
   result['rows'].append(dict(**row,source_role=pos.board[source].current_type_id,checked=eng.in_check(pos,side),geometry_any=int(bool(targets)),geometry_count=len(targets),geometry_targets=targets))
  if ply<16:s.submit(action_from_dict(d['route'][ply]['action']))
 result['summary']={}
 for t in d['raw_means']:
  rows=[r for r in result['rows'] if r['type']==t];groups=defaultdict(list)
  for r in rows:groups[r['ply']].append(r)
  result['summary'][t]=dict(means={k:sum((Fraction(sum(r[k] for r in rs),len(rs)) for rs in groups.values()),Fraction())/len(groups) for k in ('task','geometry_any','geometry_count')},initial={k:Fraction(sum(r[k] for r in groups[0]),len(groups[0])) for k in ('task','geometry_any','geometry_count')},mismatches=[r for r in rows if r['task']!=r['geometry_any']],by_source_role={role:dict(n=len(rs),task=Fraction(sum(r['task'] for r in rs),len(rs))) for role in sorted({r['source_role'] for r in rows}) if (rs:=[r for r in rows if r['source_role']==role])})
 result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
for t,v in result['summary'].items():print(t,v['means'],'mismatch',len(v['mismatches']))
