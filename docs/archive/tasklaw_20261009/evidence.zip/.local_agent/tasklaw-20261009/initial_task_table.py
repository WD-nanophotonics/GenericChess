"""Initial-only legal common-slot task table on already exposed backgrounds.
Changed premise from old geometric raw-count template: bounded S0-S4 unit task,
all types share actor slots. No fit/hyperparameters/new positions. Equal slots
atply0 for table; evaluate existing successor contexts equally then slots;
static ties uniformly mixed. Descriptive extrapolation, not hidden validation.
"""
import sys,json,hashlib
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path('.local_agent/tasklaw-20261009');src=p/'common-slot-law.json';d=json.loads(src.read_bytes());out=p/'initial-task-table.json';assert not out.exists();result=dict(scope=__doc__,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rules=[])
for seed in sorted({r['seed'] for r in d['cells']}):
 rows=[r for r in d['cells'] if r['seed']==seed];types=sorted({r['type'] for r in rows});initial={t:Fraction(sum(r['task'] for r in rows if r['type']==t and r['ply']==0),sum(r['type']==t and r['ply']==0 for r in rows)) for t in types};best=[t for t in types if initial[t]==max(initial.values())];cells=defaultdict(dict)
 for r in rows:
  if r['ply']>0:cells[r['ply'],r['source']][r['type']]=r['task']
 contexts=defaultdict(list)
 for (ply,source),values in cells.items():contexts[ply].append(dict(oracle=Fraction(max(values.values())),initial_selector=Fraction(sum(values[t] for t in best),len(best)),**{t:Fraction(v) for t,v in values.items()}))
 means={k:sum((sum((r[k] for r in rs),Fraction())/len(rs) for rs in contexts.values()),Fraction())/len(contexts) for k in ['oracle','initial_selector',*types]};summary=dict(seed=seed,initial_means=initial,initial_choice=best,successor_means=means,oracle_gap=means['oracle']-means['initial_selector'],best_constant_successor_gap=max(means[t] for t in types)-means['initial_selector'],conditional_mae={t:sum((sum((abs(initial[t]-r[t]) for r in rs),Fraction())/len(rs) for rs in contexts.values()),Fraction())/len(contexts) for t in types});result['rules'].append(summary);print(summary)
write_record(out,result)
