from pathlib import Path
import subprocess
paths=['generic_chess/_native/native_module.c','generic_chess/ai/alphabeta/native_legality.py','generic_chess/ai/alphabeta/statistics.py','generic_chess/core/search_runtime.py','generic_chess/core/terminal.py','generic_chess/native/semantic.py']
for name in paths:
 old=subprocess.check_output(['git','show','HEAD:'+name]);p=Path(name);new=p.read_text();ending='\r\n' if b'\r\n' in old else '\n';p.write_bytes(new.replace('\r\n','\n').replace('\n',ending).encode());print(name,'original CRLF',old.count(b'\r\n'))
p=Path('tests/product/test_native_first_legal.py');s=p.read_text().replace("'CHECKMATE' if checked else 'STALEMATE'","'checkmate' if checked else 'stalemate'").replace("'MAX_PLY'","'max_ply'").replace('state,c,stats=stats,legal_binding_provider=Provider())','state,c,legal_binding_provider=Provider());runtime.attach_stats(stats)').replace('state,c,stats=stats,legal_binding_provider=provider)','state,c,legal_binding_provider=provider);runtime.attach_stats(stats)');p.write_bytes(s.encode())
