"""Declared seed2003 semantic-action declaration-order alias control.
Same rule support; Core-only complete physical successor multisets on original
16ply replay. Ignore only fingerprint; single auxslot0 unchanged. Replay both
matched histories and terminal outcomes. Unchanged textual coverage selector
then produces a route independently. <=120sec/10000 child comparisons. This
is a representation control, not more frozen validation or a deployment law.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from collections import Counter
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import legal_successors
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=root/'.local_agent/generated6-20261008/coverage.json';old=json.loads(src.read_bytes())['cases'][3];definition=ruleset_from_dict(old['rules']);alias=replace(definition,semantic_actions=tuple(reversed(definition.semantic_actions)));out=p/'encoding-alias.json';assert not out.exists();start=time.perf_counter();c=compile_ruleset_for_execution(definition);ca=compile_ruleset_for_execution(alias);s=GameSession(c);a=GameSession(ca);assert c.ir.aux_slots==ca.ir.aux_slots
result=dict(scope=__doc__,complete=False,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),alias_rules=ruleset_to_dict(alias),matched=[],alias_route=[],comparisons=0)
def physical(state):
 d=record_value(state.position);d.pop('ruleset_fingerprint');return json.dumps(dict(position=d,terminal=record_value(state.terminal_status)),sort_keys=True)
def priority(a,s):
 d=action_to_dict(a);capture=False
 if hasattr(a,'to_square'):
  x=s.state.position.board[a.to_square.rank*6+a.to_square.file];capture=x is not None and x.owner!=s.state.position.side_to_move
 return (0 if d.get('pattern_id','').startswith('sem_01_') else 1 if d.get('pattern_id','').startswith('sem_00_') else 2 if capture else 3,json.dumps(d,sort_keys=True))
try:
 for ply in range(17):
  assert time.perf_counter()-start<120 and result['comparisons']<10000
  left=legal_successors(s.state,c);right=legal_successors(a.state,ca);result['comparisons']+=len(left)+len(right)
  assert Counter(physical(x) for _,x in left)==Counter(physical(x) for _,x in right);assert physical(s.state)==physical(a.state)
  result['matched'].append(dict(ply=ply,legal_actions=[len(left),len(right)],physical_outcomes=len({physical(x) for _,x in left})))
  if ply<16:
   step=action_from_dict(old['route'][ply]['action']);s.submit(step);match=[act for act,child in right if physical(child)==physical(s.state)];assert match;a.submit(min(match,key=str))
 a=GameSession(ca);s=GameSession(c)
 for ply in range(16):
  if a.state.terminal_status.is_terminal:break
  actions=a.legal_actions();assert actions;act=min(actions,key=lambda z:priority(z,a));a.submit(act);s.submit(action_from_dict(old['route'][ply]['action']));result['alias_route'].append(dict(ply=ply+1,action=action_to_dict(act),physical=physical(a.state),matches_original=physical(a.state)==physical(s.state)))
 result['first_route_difference']=next((r['ply'] for r in result['alias_route'] if not r['matches_original']),None);result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
print('matched',len(result['matched']),'comparisons',result['comparisons'],'first route difference',result['first_route_difference'],'seconds',result['seconds'])
