"""Blocked-Native safe fallback through actual public Core search caller.
Four existing6x6 finalfrontiers, explicitCore versus requestedoptionalNative;
Core semanticattack evaluator fixed, D2/8192/5sec/q2hard8. Native import already
blocked; no alternate loader or policychanges. Eight coldcalls<=40sec; compare
completed signatures/work, preserve caps/root/PV, no price/strength inference.
"""
import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;src=root/'.local_agent/generated6-20261008/coverage.json';d=json.loads(src.read_bytes());out=p/'core-fallback.json';assert not out.exists();start=time.perf_counter();result=dict(scope=__doc__,complete=False,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),cases=[])
try:
 for index,old in enumerate(d['cases']):
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='core');before=(s.state,s.history,s._search_witnesses);row=dict(seed=old['seed'],calls=[]);result['cases'].append(row)
  for requested in ((False,True) if index%2==0 else (True,False)):
   assert time.perf_counter()-start<120
   player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=requested,tuning=SearchTuning(use_root_tactical=False));assert player._native_legality_provider is None
   t=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before;row['calls'].append(dict(requested_native=requested,seconds=elapsed,decision=record_value(dec)));write_record(out,result);print(old['seed'],requested,dec.completed_depth,dec.termination_reason,dec.nodes,dec.qnodes,round(elapsed,3),flush=True)
 result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
