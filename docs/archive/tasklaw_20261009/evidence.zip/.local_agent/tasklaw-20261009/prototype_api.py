from pathlib import Path
import hashlib
p=Path('generic_chess/_native/native_module.c');s=p.read_text();Path('.local_agent/tasklaw-20261009/native_module-before.c').write_text(s)
s=s.replace('PyObject *self, PyObject *args, GCSemanticRuntimeAudit *audit_out) {','PyObject *self, PyObject *args, GCSemanticRuntimeAudit *audit_out, int first_only) {',1)
start=s.index('static PyObject *gc_semantic_transient_legal_actions_impl(');end=s.index('static int gc_semantic_has_guarded_action(',start);part=s[start:end]
part=part.replace('if (!PyArg_ParseTuple(args, "OO", &rules_capsule, &position_capsule)) return NULL;','PyObject *checkpoint = Py_None;\n    if (first_only) {\n        if (!PyArg_ParseTuple(args, "OO|O", &rules_capsule, &position_capsule, &checkpoint)) return NULL;\n        if (checkpoint != Py_None && !PyCallable_Check(checkpoint)) {\n            PyErr_SetString(PyExc_TypeError, "checkpoint must be callable or None");\n            return NULL;\n        }\n    } else if (!PyArg_ParseTuple(args, "OO", &rules_capsule, &position_capsule)) return NULL;',1)
# Callback after candidate generation, before history/audit mode; repeat on trials.
part=part.replace('GCSemanticRuntimeAudit local_audit = {0};','if (checkpoint != Py_None) {\n        PyObject *checked = PyObject_CallNoArgs(checkpoint);\n        if (!checked) { gc_semantic_action_buffer_free(&candidates); return NULL; }\n        Py_DECREF(checked);\n    }\n    GCSemanticRuntimeAudit local_audit = {0};',1)
part=part.replace('GCSemanticPosition child;\n            if (!gc_semantic_runtime_make_checked','if (i && i % 64 == 0 && checkpoint != Py_None) {\n                PyObject *checked = PyObject_CallNoArgs(checkpoint);\n                if (!checked) { Py_DECREF(out); out = NULL; break; }\n                Py_DECREF(checked);\n            }\n            GCSemanticPosition child;\n            if (!gc_semantic_runtime_make_checked',1)
part=part.replace('Py_DECREF(value);\n        }','Py_DECREF(value);\n            if (first_only) break;\n        }',1)
part=part.replace('gc_semantic_transient_legal_actions_impl(self, args, NULL);','gc_semantic_transient_legal_actions_impl(self, args, NULL, 0);')
part=part.replace('static PyObject *gc_semantic_transient_legal_actions_audit(PyObject *self, PyObject *args) {','static PyObject *gc_semantic_legal_actions_audit_impl(PyObject *self, PyObject *args, int first_only) {')
part=part.replace('gc_semantic_transient_legal_actions_impl(self, args, &audit);','gc_semantic_transient_legal_actions_impl(self, args, &audit, first_only);')
part=part.replace('if (PyDict_SetItemString(out, "actions", actions) != 0) {','PyObject *result = first_only ? PyBool_FromLong(PyTuple_Size(actions) != 0) : Py_NewRef(actions);\n    if (!result || PyDict_SetItemString(out, first_only ? "has_action" : "actions", result) != 0) {\n        Py_XDECREF(result);')
part=part.replace('    Py_DECREF(actions);\n    return out;','    Py_DECREF(result);\n    Py_DECREF(actions);\n    return out;')
part+='''static PyObject *gc_semantic_transient_legal_actions_audit(PyObject *self, PyObject *args) {
    return gc_semantic_legal_actions_audit_impl(self, args, 0);
}

static PyObject *gc_semantic_has_legal_action(PyObject *self, PyObject *args) {
    PyObject *actions = gc_semantic_transient_legal_actions_impl(self, args, NULL, 1);
    if (!actions) return NULL;
    int has_action = PyTuple_Size(actions) != 0;
    Py_DECREF(actions);
    return PyBool_FromLong(has_action);
}

static PyObject *gc_semantic_has_legal_action_audit(PyObject *self, PyObject *args) {
    return gc_semantic_legal_actions_audit_impl(self, args, 1);
}

'''
s=s[:start]+part+s[end:]
needle='    {"semantic_transient_legal_actions", gc_semantic_transient_legal_actions, METH_VARARGS,'
s=s.replace(needle,'    {"semantic_has_legal_action", gc_semantic_has_legal_action, METH_VARARGS,\n     "Transient legal availability; optional checkpoint; no terminal adjudication"},\n    {"semantic_has_legal_action_audit", gc_semantic_has_legal_action_audit, METH_VARARGS,\n     "Audited transient legal availability; stops after first successful trial"},\n'+needle)
p.write_text(s)
p=Path('generic_chess/native/semantic.py');s=p.read_text();needle='def transient_legal_actions(native_rules, position) -> tuple[int, ...]:'
s=s.replace(needle,'''def has_legal_action(native_rules, position, *, checkpoint=None) -> bool:
    """Transient availability only; Core retains history/terminal authority.

    Generates candidates then stops at the first S3/S4-legal action. No full
    legal-set decoding or child history construction. Checkpoints bracket
    packing at the caller and run after candidate generation/every64 trials.
    Native compilation excludes coordinate-free pass rules.
    """
    _require_executable(native_rules)
    if checkpoint is not None:
        checkpoint()
    result = bool(_module().semantic_has_legal_action(
        native_rules.capsule, position, checkpoint))
    if checkpoint is not None:
        checkpoint()
    return result


def has_legal_action_audit(native_rules, position, *, checkpoint=None) -> dict:
    """Same predicate with exact generation/trial work counters."""
    _require_executable(native_rules)
    if checkpoint is not None:
        checkpoint()
    result = dict(_module().semantic_has_legal_action_audit(
        native_rules.capsule, position, checkpoint))
    if checkpoint is not None:
        checkpoint()
    return result


'''+needle)
p.write_text(s)
