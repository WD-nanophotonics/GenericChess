"""Finite candidate-price alias qualification, Core only.
Use the already matched A/B-relabelled16step route. All common-slot unit tasks,
raw context means and median1000rounded values must map exactly; no newlaw,
samples, profile choice or rerun to improve a result. <=120sec/100000transitions.
"""
import sys,json,time,statistics
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
from collections import defaultdict
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record
p=Path(__file__).parent;old=json.loads((p/'stable-task-caller.json').read_bytes());alias=json.loads((p/'type-label-alias-v2.json').read_bytes());out=p/'candidate-alias-tasks.json';assert not out.exists();start=time.perf_counter();c=compile_ruleset_for_execution(ruleset_from_dict(alias['alias_rules']));s=GameSession(c);eng=semantic_engine_for(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);lookup={(r['ply'],r['source'],r['type']):r['task'] for r in old['cells']};res=dict(scope=__doc__,complete=False,cells=[],transitions=0)
def rename(t):return {'A':'B','B':'A'}.get(t,t)
def count(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(v for t,v in pos.hands[owner].counts if t not in anchors)
try:
 for ply in range(len(alias['route'])+1):
  assert time.perf_counter()-start<120 and res['transitions']<100000
  pos=s.state.position;side=pos.side_to_move;sources=[i for i,x in enumerate(pos.board) if x is not None and x.owner==side and x.current_type_id not in anchors];before=count(pos,1-side)
  for source in sources:
   for t in types:
    board=list(pos.board);board[source]=Piece(side,t,t);cp=replace(pos,board=tuple(board));rewards=[]
    for a,b in eng.iter_legal_action_bindings(cp):
     if a.source==source:rewards.append(before-count(eng._transition(cp,a,b),1-side));res['transitions']+=1
    value=max([0]+rewards);assert value==lookup[ply,source,rename(t)];res['cells'].append(dict(ply=ply,source=source,type=t,task=value))
  if ply<len(alias['route']):s.submit(action_from_dict(alias['route'][ply]['action']))
 means={}
 for t in types:
  groups=defaultdict(list)
  for r in res['cells']:
   if r['type']==t:groups[r['ply']].append(r['task'])
  means[t]=sum((Fraction(sum(v),len(v)) for v in groups.values()),Fraction())/len(groups)
 median=statistics.median(means.values());board={t:round(1000*mu/median) for t,mu in means.items()}
 for t in types:assert means[t]==Fraction(old['raw_means'][rename(t)]) and board[t]==old['profiles']['board_ablation']['board_value_by_type'][rename(t)]
 res['raw_means']=means;res['rounded_board']=board;res['complete']=True
finally:res['seconds']=time.perf_counter()-start;write_record(out,res)
print('cells',len(res['cells']),'transitions',res['transitions'],'seconds',res['seconds'],'board',board)
