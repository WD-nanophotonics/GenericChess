"""Qualifiedv2 A/B pure type-label alias control for physical-route candidate.
Original stops atply7 because inverse-renamed Hands tuple needs sorting;
originalsource/partial preserved. This version canonicalizes that map only.
All type references mapped, no movement/rule/stock changes. Core complete
physical successor multisets on matched17route contexts, then unchanged
semantic-effect/raw-physicalJSON selector; compare after inverse relabeling.
<=120sec/10000eager children; no general history-equivalence claim.
"""
import sys,json,time
from pathlib import Path
from collections import Counter
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict,action_to_dict,action_is_board,action_is_drop
from generic_chess.core.transition import legal_successors
from generic_chess.session.session import GameSession
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=json.loads((root/'.local_agent/compression-20261009/fixed-rule-compression.json').read_bytes());sampler=json.loads((p/'stable-task-caller.json').read_bytes());out=p/'type-label-alias-v2.json';assert not out.exists();start=time.perf_counter()
def rename(x):
 if isinstance(x,str):return {'A':'B','B':'A'}.get(x,x)
 if isinstance(x,list):return [rename(v) for v in x]
 if isinstance(x,dict):return {rename(k):rename(v) for k,v in x.items()}
 return x
alias=rename(old['rules']);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));ca=compile_ruleset_for_execution(ruleset_from_dict(alias));assert c.ir.aux_slots==ca.ir.aux_slots
res=dict(scope=__doc__,complete=False,alias_rules=alias,matched=[],route=[],comparisons=0)
def physical(st,normalized=False):
 z=record_value(st.position);z.pop('ruleset_fingerprint')
 if normalized and st.position.ruleset_fingerprint==ca.ruleset_fingerprint:
  z=rename(z)
  for hand in z['hands']:hand['counts']=sorted(hand['counts'])
 return json.dumps(dict(position=z,terminal=record_value(st.terminal_status)),sort_keys=True)
s=GameSession(c);a=GameSession(ca)
try:
 for ply in range(len(sampler['route'])+1):
  assert time.perf_counter()-start<120 and res['comparisons']<10000
  left=legal_successors(s.state,c);right=legal_successors(a.state,ca);res['comparisons']+=len(left)+len(right);assert Counter(physical(x,True) for _,x in left)==Counter(physical(x,True) for _,x in right);assert physical(s.state,True)==physical(a.state,True);res['matched'].append(dict(ply=ply,legal_count=len(left)))
  if ply<len(sampler['route']):
   s.submit(action_from_dict(sampler['route'][ply]['action']));matches=[act for act,ch in right if physical(ch,True)==physical(s.state,True)];assert matches;a.submit(matches[0])
 a=GameSession(ca)
 for ply in range(len(sampler['route'])):
  if a.state.terminal_status.is_terminal:break
  before=a.state.position;side=before.side_to_move
  def priority(pair):
   act,ch=pair;quiet=False
   if action_is_board(act):
    x=before.board[act.from_square.rank*6+act.from_square.file];y=ch.position.board[act.to_square.rank*6+act.to_square.file];quiet=before.board[act.to_square.rank*6+act.to_square.file] is None and x is not None and y is not None and x.owner==y.owner and x.base_type_id==y.base_type_id and x.current_type_id!=y.current_type_id
   capture=sum(x is not None and x.owner!=side for x in ch.position.board)<sum(x is not None and x.owner!=side for x in before.board)
   return (0 if quiet else 1 if action_is_drop(act) else 2 if capture else 3,physical(ch))
  pairs=legal_successors(a.state,ca);res['comparisons']+=len(pairs);act,ch=min(pairs,key=priority);a.submit(act)
  saved=sampler['route'][ply]['state'];z=saved['position'];z=dict(z);z.pop('ruleset_fingerprint');expected=json.dumps(dict(position=z,terminal=saved['terminal_status']),sort_keys=True);res['route'].append(dict(ply=ply+1,action=action_to_dict(act),matches_original=physical(a.state,True)==expected))
 res['first_route_difference']=next((r['ply'] for r in res['route'] if not r['matches_original']),None);res['complete']=True
finally:res['seconds']=time.perf_counter()-start;write_record(out,res)
print('matched',len(res['matched']),'comparisons',res['comparisons'],'firstdifference',res['first_route_difference'],'seconds',res['seconds'])
