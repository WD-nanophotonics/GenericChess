"""First-legal prototype68existingcontexts, no new rule/sample budget.
Core availability authority, Native first/full audit on identical transient
positions; capped-ply predicate still availability not terminal. Cancellation
exception after candidate generation must preserve subsequent audit/state.
"""
import sys,json,time,hashlib,statistics
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
p=Path(__file__).parent;src=Path('.local_agent/generated6-20261008/coverage.json');d=json.loads(src.read_bytes());out=p/'first-legal-census.json';assert not out.exists();start=time.perf_counter();res=dict(scope=__doc__,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),complete=False,rows=[])
class StopProbe(Exception):pass
try:
 for case in d['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);eng=semantic_engine_for(c);nr=compile_native_semantic_rules(c)
  for ply in range(17):
   assert time.perf_counter()-start<120
   pos=s.state.position;np=ns.pack_current_position(nr,pos,ply_count=ply);before=ns.snapshot(nr,np);core=eng.has_legal_action(pos);first=ns.has_legal_action_audit(nr,np);full=ns.transient_legal_actions_audit(nr,np)
   assert core==first['has_action']==bool(full['actions']);assert first['s3_trial_count']<=full['s3_trial_count'];assert first['candidate_count']==full['candidate_count'];assert first['history_appends']==first['child_canonical_key_computations']==0
   capped=ns.pack_current_position(nr,pos,ply_count=c.max_ply);assert ns.has_legal_action(nr,capped)==core
   calls=[0]
   def stop():
    calls[0]+=1
    if calls[0]==2:raise StopProbe()
   try:ns.has_legal_action_audit(nr,np,checkpoint=stop)
   except StopProbe:pass
   else:raise AssertionError('callback did not propagate')
   assert ns.has_legal_action_audit(nr,np)==first and ns.snapshot(nr,np)==before
   timings={}
   for label,fn in [('core',lambda:eng.has_legal_action(pos)),('native_first',lambda:ns.has_legal_action(nr,np)),('native_full',lambda:ns.transient_legal_actions(nr,np))]:
    samples=[]
    for _ in range(5):
     t=time.perf_counter();fn();samples.append(time.perf_counter()-t)
    timings[label]=statistics.median(samples)
   res['rows'].append(dict(seed=case['seed'],ply=ply,first=first,full={k:v for k,v in full.items() if k!='actions'},legal_count=len(full['actions']),timings=timings))
   if ply<16:s.submit(action_from_dict(case['route'][ply]['action']))
 res['complete']=True
finally:res['seconds']=time.perf_counter()-start;write_record(out,res)
print('rows',len(res['rows']),'seconds',res['seconds'])
print('trial_first/full',sum(r['first']['s3_trial_count'] for r in res['rows']),sum(r['full']['s3_trial_count'] for r in res['rows']))
print('timing_sum',{k:sum(r['timings'][k] for r in res['rows']) for k in res['rows'][0]['timings']})
