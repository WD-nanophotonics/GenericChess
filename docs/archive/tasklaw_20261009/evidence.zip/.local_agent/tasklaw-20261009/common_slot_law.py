"""Predeclared common-slot developmental unit-removal law, no fit/default.
Every actualside ordinary slot of68frozen backgrounds is counterfactually
replaced with each supported ordinary standalone type(base=current,unpromoted).
Other board/hand/aux fields unchanged. No legal-transform/reachability claim;
instant S0-S4 legal task ignores history adjudication. Equal contexts then equal
actual slots; common population for every type. Unit reward removes ordinary
enemy board+hand, max with virtualstop0. AllCore/Native focal actions/transitions
and parentcheck agree. <=120sec/100000 focaltransitions; no cohort extension.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from collections import defaultdict
from fractions import Fraction
root=Path.cwd();sys.path[:0]=[str(root),str(root/'.local_agent/finite-law-20261009')]
from finite_law import collect
from scripts.research_record import record_value,write_record
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.core.identity import position_identity_key
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
from generic_chess.ai.evaluation.config import EvaluationConfig
p=Path(__file__).parent;src=root/'.local_agent/generated6-20261008/coverage.json';d=json.loads(src.read_bytes());out=p/'common-slot-law.json';assert not out.exists();start=time.perf_counter();result=dict(complete=False,scope=__doc__,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cells=[],transitions=0,slots=0)
def key(a):return json.dumps(action_to_dict(a),sort_keys=True)
def count(pos,owner,anchors):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(v for t,v in pos.hands[owner].counts if t not in anchors)
try:
 for old in d['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));eng=semantic_engine_for(c);nr=compile_native_semantic_rules(c);s=GameSession(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);edges={t:collect(c,c.ir,t,EvaluationConfig())[0]['target_enemy'] for t in types}
  for ply in range(17):
   pos=s.state.position;side=pos.side_to_move;sources=[i for i,x in enumerate(pos.board) if x is not None and x.owner==side and x.current_type_id not in anchors]
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   for source in sources:
    result['slots']+=1
    for t in types:
     assert time.perf_counter()-start<120 and result['transitions']<100000
     board=list(pos.board);board[source]=Piece(side,t,t,False);cp=replace(pos,board=tuple(board));np=ns.pack_current_position(nr,cp,ply_count=0);checked=eng.in_check(cp,side);assert ns.in_check(nr,np,side)==checked
     pairs=[(a,b) for a,b in eng.iter_legal_action_bindings(cp) if a.source==source];core={key(_semantic_public_action(eng,a)):(a,b) for a,b in pairs};native={}
     for raw in ns.transient_legal_actions(nr,np):
      a=ns.public_action(nr,raw)
      if getattr(a,'from_square',None) is not None and a.from_square.rank*6+a.from_square.file==source:native[key(a)]=raw
     assert set(core)==set(native);choices=[];before=count(cp,1-side,anchors)
     for k,(a,b) in core.items():
      child=eng._transition(cp,a,b);nc=ns.make_checked(nr,np,native[k]);assert ns.position_key(nr,nc)==position_identity_key(child,c);reward=before-count(child,1-side,anchors);choices.append(dict(action=action_to_dict(_semantic_public_action(eng,a)),reward=reward));result['transitions']+=1
     occ={i for i,x in enumerate(cp.board) if x is not None};targets=[]
     for target,events in edges[t][side*36+source].items():
      enemy=cp.board[target]
      if enemy is not None and enemy.owner!=side and enemy.current_type_id not in anchors and any(not occ&cl and (k is None or len(occ&scope)==k) for cl,scope,k in events):targets.append(target)
     result['cells'].append(dict(seed=old['seed'],ply=ply,source=source,original=record_value(pos.board[source]),type=t,checked=checked,task=max([0]+[a['reward'] for a in choices]),choices=choices,geometric_count=len(targets),geometric_any=int(bool(targets))))
   write_record(out,result)
   if ply<16:s.submit(action_from_dict(old['route'][ply]['action']))
 result['summary']=[]
 for seed,t in sorted({(r['seed'],r['type']) for r in result['cells']}):
  rows=[r for r in result['cells'] if (r['seed'],r['type'])==(seed,t)];contexts=defaultdict(list)
  for r in rows:contexts[r['ply']].append(r)
  result['summary'].append(dict(seed=seed,type=t,contexts=len(contexts),slots=len(rows),means={k:sum((Fraction(sum(r[k] for r in rs),len(rs)) for rs in contexts.values()),Fraction())/len(contexts) for k in ['task','geometric_count','geometric_any']}))
 result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
print('complete',result['complete'],'slots',result['slots'],'cells',len(result['cells']),'transitions',result['transitions'],'seconds',result['seconds'])
for row in result['summary']:print(row)
