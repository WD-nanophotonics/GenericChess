"""Qualify two Chess geometric-task mismatches on existing contexts.
Replay fixed route; identify actual off-destination removal and base/current
effect. No new sample, profile or hypothesis tuning; Core<=120sec.
"""
import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from dataclasses import replace
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.core.pieces import Piece
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;d=json.loads((p/'chess-task-law.json').read_bytes());m=json.loads((p/'chess-task-decomposition.json').read_bytes())['summary']['P']['mismatches'];c=compile_ruleset_for_execution(build_western_chess_ruleset());eng=semantic_engine_for(c);s=GameSession(c);rows=[]
for ply in range(17):
 pos=s.state.position;side=pos.side_to_move
 for row in [r for r in m if r['ply']==ply]:
  board=list(pos.board);board[row['source']]=Piece(side,'P','P');cp=replace(pos,board=tuple(board));choices=[]
  for a,b in eng.iter_legal_action_bindings(cp):
   if a.source!=row['source']:continue
   ch=eng._transition(cp,a,b);removed=[i for i,x in enumerate(cp.board) if x is not None and x.owner!=side and (ch.board[i] is None or ch.board[i].owner==side)]
   if removed:choices.append(dict(action=record_value(a),removed=removed,destination=a.target,off_destination=[i for i in removed if i!=a.target]))
  rows.append(dict(context=row,choices=choices))
 if ply<16:s.submit(action_from_dict(d['route'][ply]['action']))
assert len(rows)==2 and all(any(a['off_destination'] for a in r['choices']) for r in rows)
write_record(p/'chess-off-destination.json',dict(scope=__doc__,complete=True,rows=rows))
print(rows)
