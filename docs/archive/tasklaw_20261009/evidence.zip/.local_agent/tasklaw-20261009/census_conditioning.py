"""Analyze existing census only: pair types on shared contexts before ordering.
No new positions, fitting, defaults or hidden validation. Both conditional means
and pair counts retained; shared-context comparisons remain different pair laws.
"""
import json,hashlib,itertools
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
from scripts.research_record import write_record
p=Path('.local_agent/tasklaw-20261009');source=p/'legal-census.json';d=json.loads(source.read_bytes());assert d['complete'];out=p/'census-conditioning.json';assert not out.exists()
cells=defaultdict(list)
for r in d['actors']:cells[r['seed'],r['ply'],r['type']].append(r)
means={k:Fraction(sum(r['task'] for r in rs),len(rs)) for k,rs in cells.items()}
result=dict(scope=__doc__,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),pairs=[],lineages=[],contexts=[])
for seed in sorted({r['seed'] for r in d['actors']}):
 types=sorted({r['type'] for r in d['actors'] if r['seed']==seed})
 for a,b in itertools.combinations(types,2):
  pa={ply for s,ply,t in means if s==seed and t==a};pb={ply for s,ply,t in means if s==seed and t==b};common=sorted(pa&pb)
  unconditional={t:sum((v for (s,ply,tt),v in means.items() if s==seed and tt==t),Fraction())/len(ps) for t,ps in [(a,pa),(b,pb)]}
  shared={t:sum((means[seed,ply,t] for ply in common),Fraction())/len(common) if common else None for t in [a,b]}
  result['pairs'].append(dict(seed=seed,types=[a,b],present_contexts=[sorted(pa),sorted(pb)],shared_contexts=common,presence_means=unconditional,shared_means=shared,sign_reversal=bool(common and (unconditional[a]-unconditional[b])*(shared[a]-shared[b])<0)))
 groups=defaultdict(list)
 for r in d['actors']:
  if r['seed']==seed:groups[r['type'],r['base'],r['promoted']].append(r)
 for (t,base,promoted),rs in groups.items():
  contexts=defaultdict(list)
  for r in rs:contexts[r['ply']].append(r)
  result['lineages'].append(dict(seed=seed,type=t,base=base,promoted=promoted,actors=len(rs),contexts=len(contexts),task_context_mean=sum((Fraction(sum(r['task'] for r in rows),len(rows)) for rows in contexts.values()),Fraction())/len(contexts)))
 for ply in range(17):
  present=[t for t in types if (seed,ply,t) in means]
  result['contexts'].append(dict(seed=seed,ply=ply,present=present,means={t:means[seed,ply,t] for t in present}))
write_record(out,result)
for r in result['pairs']:
 print(r['seed'],r['types'],len(r['shared_contexts']),{k:str(v) for k,v in r['presence_means'].items()},{k:str(v) for k,v in r['shared_means'].items()},'reversal',r['sign_reversal'])
print('lineages',result['lineages'])
