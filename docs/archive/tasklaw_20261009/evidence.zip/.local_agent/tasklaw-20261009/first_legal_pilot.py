"""First-legal Native predicate pilot, four rotated calls on exact prior
seed2001ply16 D2/8192/5sec/q2hard8 conditions. Changed premise from rejected
eager full set: materialize candidates but stop at first legal trial, no action
decode/full set/cache. Core adjudication/history remains exact. Same20sec search
budget; wall-limited signatures unqualified. No deployed caller/default yet.
"""
import sys,json,time,hashlib,inspect
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root)]
import generic_chess.core.search_runtime as sr
import generic_chess.core.terminal as terminal
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'first-legal-pilot.json';assert not out.exists()
from generic_chess.native import semantic as native_semantic
original=sr.terminal_from_search_runtime;src=inspect.getsource(original)
needle='has_legal = engine.has_legal_action(position, checkpoint=checkpoint)'
assert src.count(needle)==1
src=src.replace(needle,'has_legal = first_legal(runtime, engine, checkpoint)')
metrics={}
def first_legal(runtime, engine, checkpoint):
 provider=runtime._legal_binding_provider
 if not runtime._legal_provider_active or provider is None:return engine.has_legal_action(runtime.position,checkpoint=checkpoint)
 if checkpoint:checkpoint()
 t=time.perf_counter()
 np=native_semantic.pack_position(provider.native_rules,provider._state_only_payload(runtime.position,0))
 if checkpoint:checkpoint()
 value=native_semantic.has_legal_action(provider.native_rules,np,checkpoint=checkpoint)
 elapsed=time.perf_counter()-t;metrics['calls']=metrics.get('calls',0)+1;metrics['seconds']=metrics.get('seconds',0)+elapsed;metrics['max_seconds']=max(metrics.get('max_seconds',0),elapsed)
 return value
ns=dict(terminal.__dict__);ns['first_legal']=first_legal;exec(src,ns);prototype=ns['terminal_from_search_runtime']
case=next(x for x in json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes())['cases'] if x['seed']==202610082001)
c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for step in case['route'][:16]:s.submit(action_from_dict(step['action']))
before=(s.state,s.history,s._search_witnesses);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),prototype_source=src,calls=[]);write_record(out,result)
for actual in (False,True,True,False):
 for f in ('rollout.json','advisor.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('user_paused',False) and not d.get('stopped',False)
 player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False));stats=[]
 def make_stats():
  z=SearchStatistics();stats.append(z);return z
 metrics.clear();t=time.perf_counter()
 with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats),patch.object(sr,'terminal_from_search_runtime',prototype if actual else original):
  dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8))
 elapsed=time.perf_counter()-t;validate_pv(s,dec)
 assert (s.state,s.history,s._search_witnesses)==before and stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops and not stats[0].native_legality_fallbacks
 result['calls'].append(dict(prototype=actual,predicate_metrics=dict(metrics),seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0])));write_record(out,result)
 print(actual,dec.completed_depth,dec.termination_reason,dec.score,dec.nodes,dec.qnodes,stats[0].runtime_pushes,round(elapsed,3),flush=True)
result['complete']=True;write_record(out,result)
