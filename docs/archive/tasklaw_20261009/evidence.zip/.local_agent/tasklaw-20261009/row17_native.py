"""Independent Native check/legal-focal witness for saved row17, no new sample."""
import sys,json,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as ns
from scripts.research_record import write_record
p=Path(__file__).parent;src=root/'.local_agent/compression-20261009/fixed-rule-compression.json';d=json.loads(src.read_bytes());v2=json.loads((p/'row17-v2.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(d['rules']));nr=compile_native_semantic_rules(c);rows=[]
key=lambda a:json.dumps(action_to_dict(a),sort_keys=True)
for t in ('P','X'):
 s=GameSession(c);z=d['transform_actions'][t];s.submit(action_from_dict(dict(kind='semantic_board',pattern_id=z['pattern_id'],geometry_id=z['geometry_id'],actor_type_id=z['actor_type_id'],**{'from':[z['from_square']['file'],z['from_square']['rank']],'to':[z['to_square']['file'],z['to_square']['rank']],'promotion_target_id':z['promotion_target_id']})));s.submit(action_from_dict(d['rows'][17]['reply']));np=pack_semantic_search_position(c,nr,s);assert ns.in_check(nr,np,0);snap=ns.snapshot(nr,np);assert snap['history_exact'] and snap['history_events_exact'];actions=[ns.public_action(nr,a) for a in ns.transient_legal_actions(nr,np)];focal=[a for a in actions if getattr(a,'from_square',None) is not None and (a.from_square.file,a.from_square.rank)==(3,2)];expected=next(r for r in v2['rows'] if r['type']==t)['legal_from_focal'];assert {key(a) for a in focal}=={json.dumps(a,sort_keys=True) for a in expected};rows.append(dict(type=t,parent_checked=True,legal_from_focal=[action_to_dict(a) for a in focal],complete_history=True))
assert [len(r['legal_from_focal']) for r in rows]==[1,0];out=p/'row17-native.json';assert not out.exists();write_record(out,dict(complete=True,rows=rows,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),qualification='Native validates current check and legal sets, not Core private rejection-stage internals. Core S3 trials separately identify safety cause.'))
print(rows)
