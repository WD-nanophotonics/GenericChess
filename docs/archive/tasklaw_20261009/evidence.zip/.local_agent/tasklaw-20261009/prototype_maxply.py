from pathlib import Path
p=Path('generic_chess/_native/native_module.c');s=p.read_text();needle='    GCSemanticRuntimeAudit local_audit = {0};';start=s.index('static PyObject *gc_semantic_transient_legal_actions_impl(');at=s.index(needle,start)
s=s[:at]+'''    GCSemanticPosition probe;
    const GCSemanticPosition *trial_position = position;
    if (first_only) {
        /* Availability is independent of history/max-ply adjudication, just
         * like the existing terminal helper and Core has_legal_action. */
        probe = *position;
        probe.ply = 0;
        probe.history_len = 0;
        probe.history_exact = 1;
        trial_position = &probe;
    }
'''+s[at:]
start=s.index('static PyObject *gc_semantic_transient_legal_actions_impl(');end=s.index('static PyObject *gc_semantic_transient_legal_actions(',start)
part=s[start:end].replace('gc_semantic_runtime_make_checked(&child, rules, position, candidates.data[i])','gc_semantic_runtime_make_checked(&child, rules, trial_position, candidates.data[i])');s=s[:start]+part+s[end:];p.write_text(s)
