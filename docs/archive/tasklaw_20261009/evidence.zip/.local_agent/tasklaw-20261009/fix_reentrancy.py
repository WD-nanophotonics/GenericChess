from pathlib import Path
p=Path('generic_chess/_native/native_module.c');s=p.read_text();old='''            if (i && i % 64 == 0 && checkpoint != Py_None) {
                PyObject *checked = PyObject_CallNoArgs(checkpoint);
                if (!checked) { Py_DECREF(out); out = NULL; break; }
                Py_DECREF(checked);
            }''';new='''            if (i && i % 64 == 0 && checkpoint != Py_None) {
                /* A Python callback can reenter Native or release the GIL.
                 * Never expose this call's transient/audit mode to it. */
                gc_semantic_runtime_history_mode_stop();
                if (audit_out) gc_semantic_runtime_audit_stop();
                PyObject *checked = PyObject_CallNoArgs(checkpoint);
                if (!checked) { Py_DECREF(out); out = NULL; break; }
                Py_DECREF(checked);
                if (audit_out) gc_semantic_runtime_audit_start(&local_audit);
                gc_semantic_runtime_history_mode_start();
            }''';assert s.count(old)==1;p.write_bytes(s.replace(old,new).encode())
p=Path('tests/product/test_native_first_legal.py');s=p.read_text();s+='''

def test_trial_checkpoint_can_reenter_native_without_leaking_modes():
    c=compile_ruleset_for_execution(replace(build_standard_shogi_ruleset(),declarations=()))
    state=make_state(c,['r........']+['.........']*5+
        ['.nk......','..g......','K........'])
    from generic_chess.core.position import Hands
    pos=replace(state.position,hands=(Hands((('P',1),('L',1),('N',1),('S',1),('G',1))),Hands()))
    nr=compile_native_semantic_rules(c);np=ns.pack_current_position(nr,pos,ply_count=0)
    initial=ns.pack_current_position(nr,GameSession(c).state.position,ply_count=0)
    action=ns.transient_legal_actions(nr,initial)[0]
    expected=ns.has_legal_action_audit(nr,np);calls=0
    def checkpoint():
        nonlocal calls
        calls+=1
        if calls>=3:
            assert ns.has_legal_action_audit(nr,initial)['has_action']
            child=ns.make_checked(nr,initial,action)
            assert len(ns.snapshot(nr,child)['history'])==len(ns.snapshot(nr,initial)['history'])+1
    assert ns.has_legal_action_audit(nr,np,checkpoint=checkpoint)==expected
    assert calls>=3
''';p.write_bytes(s.encode())
