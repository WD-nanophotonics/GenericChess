"""Declared exposed legal unit-removal census on existing68 route contexts.
Same four generated6 rules/root-through-frozen16ply route, no new samples or
fit. At actual side's turn, each ordinary board actor may use a legal focal
action or virtual task-stop0; reward is ordinary enemy board+hand count loss.
Terminal contexts have task0. Equal contexts then equal present actors of type;
absent types have no observation, not a fabricated zero. Retain initial vs
successor/check/current/base/promoted counts, supported geometric ordinary
capture counts and defaults separately. The semantic-first coverage route is
a declared exposed context law, not deployment calibration or unbiased sampling.
Independent Native all legal sets/children/rewards, full history, <=120sec and
20000transitions. No product/profile/horizon change, hidden labels or worker.
"""
import json,sys,hashlib,time
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
root=Path.cwd();sys.path[:0]=[str(root),str(root/'.local_agent/finite-law-20261009')]
from finite_law import collect
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict,action_is_board
from generic_chess.core.transition import legal_successors
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.identity import position_identity_key
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as ns
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=root/'.local_agent/generated6-20261008/coverage.json';inp=json.loads(src.read_bytes());out=p/'legal-census.json';assert not out.exists();start=time.perf_counter()
result=dict(complete=False,declaration=__doc__,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules=[],contexts=[],actors=[],checked_transitions=0,checked_legal_sets=0);write_record(out,result)
key=lambda a:json.dumps(action_to_dict(a),sort_keys=True)
def count(pos,owner,anchors):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(v for tid,v in pos.hands[owner].counts if tid not in anchors)
try:
 for old in inp['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c);eng=semantic_engine_for(c);nr=compile_native_semantic_rules(c);area=c.board_shape.area;anchors={t.type_id for t in c.piece_types if t.is_anchor};an={i for i,t in enumerate(nr.type_ids) if t in anchors};cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profiles={'default':build_ruleset_profile(c,cfg),'semantic':build_semantic_opportunity_profile(c,cfg)[0]};edges={t.type_id:collect(c,c.ir,t.type_id,cfg)[0]['target_enemy'] for t in c.piece_types if not t.is_anchor}
  result['rules'].append(dict(seed=old['seed'],fingerprint=c.ruleset_fingerprint,profiles={k:dict(board=dict(v.board_value_by_type),hand=dict(v.hand_value_by_base_type)) for k,v in profiles.items()}))
  for ply in range(len(old['route'])+1):
   assert time.perf_counter()-start<120 and result['checked_transitions']<20000
   flags=json.loads((root/'.local_agent/rollout.json').read_bytes());assert not flags['user_paused']
   pos=s.state.position;side=pos.side_to_move;terminal=s.state.terminal_status.is_terminal;checked=eng.in_check(pos,side);np=pack_semantic_search_position(c,nr,s);assert ns.position_key(nr,np)==position_identity_key(pos,c) and ns.terminal_status(nr,np)==record_value(s.state.terminal_status);assert ns.in_check(nr,np,side)==checked
   successors=[] if terminal else legal_successors(s.state,c);native={} if terminal else {key(ns.public_action(nr,a)):a for a in ns.transient_legal_actions(nr,np)};assert set(native)=={key(a) for a,_ in successors};result['checked_legal_sets']+=1
   by_source=defaultdict(list);before=count(pos,1-side,anchors)
   for a,child in successors:
    nc=ns.make_checked(nr,np,native[key(a)]);snap=ns.snapshot(nr,nc);assert snap['history_exact'] and snap['history_events_exact'];assert ns.position_key(nr,nc)==position_identity_key(child.position,c);assert ns.terminal_status(nr,nc)==record_value(child.terminal_status);native_after=sum(x is not None and x[2]==1-side and x[1] not in an for x in snap['board'])+sum(v for i,v in enumerate(snap['hands'][1-side]) if i not in an);reward=before-count(child.position,1-side,anchors);assert reward==before-native_after;result['checked_transitions']+=1
    if action_is_board(a):by_source[a.from_square.rank*6+a.from_square.file].append(dict(action=action_to_dict(a),reward=reward,terminal=record_value(child.terminal_status)))
   context=dict(seed=old['seed'],ply=ply,side=side,terminal=terminal,checked=checked,full_state=record_value(s.state),legal_actions=len(successors));result['contexts'].append(context);occ={i for i,x in enumerate(pos.board) if x is not None}
   for source,actor in enumerate(pos.board):
    if actor is None or actor.owner!=side or actor.current_type_id in anchors:continue
    bucket=edges[actor.current_type_id][side*area+source];targets=[]
    for target,events in bucket.items():
     enemy=pos.board[target]
     if enemy is not None and enemy.owner!=side and enemy.current_type_id not in anchors and any(not occ&cl and (k is None or len(occ&scope)==k) for cl,scope,k in events):targets.append(target)
    choices=by_source[source];value=max([0]+[x['reward'] for x in choices]) if not terminal else 0
    result['actors'].append(dict(seed=old['seed'],ply=ply,side=side,source=source,type=actor.current_type_id,base=actor.base_type_id,promoted=actor.promoted,terminal=terminal,checked=checked,choices=choices,task=value,geometric_ordinary_endpoints=targets,geometric_count=len(targets),geometric_any=int(bool(targets))))
   write_record(out,result)
   if ply<len(old['route']):s.submit(action_from_dict(old['route'][ply]['action']))
 result['summary']=[]
 for seed in sorted({r['seed'] for r in result['actors']}):
  for t in sorted({r['type'] for r in result['actors'] if r['seed']==seed}):
   for group,accept in [('all',lambda r:True),('initial',lambda r:r['ply']==0),('successor',lambda r:r['ply']>0),('checked',lambda r:r['checked']),('not_checked',lambda r:not r['checked'])]:
    rows=[r for r in result['actors'] if r['seed']==seed and r['type']==t and accept(r)];groups=defaultdict(list)
    for r in rows:groups[r['ply']].append(r)
    result['summary'].append(dict(seed=seed,type=t,group=group,actor_count=len(rows),contexts=len(groups),context_means={k:str(sum((Fraction(sum(r[k] for r in rs),len(rs)) for rs in groups.values()),Fraction(0))/len(groups)) if groups else None for k in ('task','geometric_count','geometric_any')},actor_means={k:str(Fraction(sum(r[k] for r in rows),len(rows))) if rows else None for k in ('task','geometric_count','geometric_any')}))
 result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
print('complete',result['complete'],'contexts',len(result['contexts']),'actors',len(result['actors']),'transitions',result['checked_transitions'],'seconds',result['seconds'])
for r in result['summary']:
 if r['group']=='all':print(r['seed'],r['type'],r['actor_count'],r['context_means'])
