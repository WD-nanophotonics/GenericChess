"""Identify saved row17 illegality through actual Core stages, not assumptions.
Same constructed rule/two focal transformations/reply, no new contexts or fit.
Replay actual full history. Enumerate S0-2 candidate bindings for focal source,
retain transitions, S3 safety, S4 rejection and complete public legal result.
Unchecked trials are diagnostics only; never submit them as legal game moves.
"""
import sys,json,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=root/'.local_agent/compression-20261009/fixed-rule-compression.json';d=json.loads(src.read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(d['rules']));engine=semantic_engine_for(c);rows=[]
for t in ('P','X'):
 s=GameSession(c);z=d['transform_actions'][t];s.submit(action_from_dict(dict(kind='semantic_board',pattern_id=z['pattern_id'],geometry_id=z['geometry_id'],actor_type_id=z['actor_type_id'],**{'from':[z['from_square']['file'],z['from_square']['rank']],'to':[z['to_square']['file'],z['to_square']['rank']],'promotion_target_id':z['promotion_target_id']})));s.submit(action_from_dict(d['rows'][17]['reply']));assert record_value(s.state)==d['rows'][17]['cells'][t]['state'];pos=s.state.position;focal=15;actor=pos.board[focal];records=[]
 for pat in engine._patterns:
  for a,binding in engine._iter_candidates(pat,pos,sources_by_owner_type={(actor.owner,actor.current_type_id):((focal,actor),)}):
   if a.source!=focal:continue
   trial=engine._transition(pos,a,binding);s3=engine._trial_child_if_s3_legal(pat,pos,a,binding)
   engine._postcondition_parent=pos;engine._postcondition_action=a
   try:s4=engine._violates_postconditions(pat,trial)
   finally:engine._postcondition_parent=None;engine._postcondition_action=None
   records.append(dict(action=action_to_dict(_semantic_public_action(engine,a)),invariants=record_value(pat.invariants),parent_checked=engine.in_check(pos,actor.owner),trial_checked=engine.in_check(trial,actor.owner),s3_legal=s3 is not None,s4_violates=s4,trial=record_value(trial)))
 rows.append(dict(type=t,parent=record_value(s.state),parent_checked=engine.in_check(pos,0),candidates=records,legal_from_focal=[action_to_dict(a) for a in s.legal_actions() if getattr(a,'from_square',None)==z['to_square']]))
out=p/'row17.json';assert not out.exists();write_record(out,dict(complete=True,declaration=__doc__,rows=rows,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
for r in rows:print(r['type'],r['parent_checked'],[(x['action']['to'],x['trial_checked'],x['s3_legal'],x['s4_violates']) for x in r['candidates']])
