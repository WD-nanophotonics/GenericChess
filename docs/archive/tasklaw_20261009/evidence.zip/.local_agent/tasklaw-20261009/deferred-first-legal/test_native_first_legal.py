"""First-legal Native probes preserve transient availability and Core authority."""
from dataclasses import replace
import pytest
from generic_chess.native import native_available
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from conftest import make_state

pytestmark = pytest.mark.skipif(not native_available(), reason='native unavailable')

@pytest.mark.parametrize('factory',[build_western_chess_ruleset,build_standard_shogi_ruleset])
def test_first_trial_stops_without_history_or_complete_set(factory):
    c=compile_ruleset_for_execution(factory());nr=compile_native_semantic_rules(c)
    pos=GameSession(c).state.position;np=ns.pack_current_position(nr,pos,ply_count=0)
    before=ns.snapshot(nr,np);first=ns.has_legal_action_audit(nr,np)
    full=ns.transient_legal_actions_audit(nr,np)
    assert first['has_action'] is True
    assert first['candidate_count']==full['candidate_count']
    assert 0<first['s3_trial_count']<full['s3_trial_count']
    assert first['history_appends']==first['child_canonical_key_computations']==0
    assert ns.snapshot(nr,np)==before
    capped=ns.pack_current_position(nr,pos,ply_count=c.max_ply)
    assert ns.has_legal_action(nr,capped) is True
    assert ns.transient_legal_actions(nr,capped)==()

@pytest.mark.parametrize('lines,checked',[
    (['........']*5+['..k.....','.q......','K.......'],True),
    (['........']*5+['.q......','..k.....','K.......'],False)])
def test_absence_probe_preserves_mate_stalemate_distinction(lines,checked):
    c=compile_ruleset_for_execution(build_western_chess_ruleset());state=make_state(c,lines)
    eng=semantic_engine_for(c);nr=compile_native_semantic_rules(c)
    np=ns.pack_current_position(nr,state.position,ply_count=0)
    assert eng.in_check(state.position,0)==checked
    assert eng.has_legal_action(state.position) is False
    assert ns.has_legal_action(nr,np) is False
    provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
    runtime=SearchPathRuntime(state,c,legal_binding_provider=provider)
    from generic_chess.core.terminal import terminal_from_search_runtime
    result=terminal_from_search_runtime(runtime)
    assert result.status.value==('checkmate' if checked else 'stalemate')
    assert runtime._legal_cache is None


def test_native_callback_exception_cleans_up_audit_and_transient_modes():
    c=compile_ruleset_for_execution(build_western_chess_ruleset());nr=compile_native_semantic_rules(c)
    np=ns.pack_current_position(nr,GameSession(c).state.position,ply_count=0)
    expected=ns.has_legal_action_audit(nr,np);calls=0
    def checkpoint():
        nonlocal calls
        calls+=1
        if calls==2:raise RuntimeError('cancel after candidate generation')
    with pytest.raises(RuntimeError,match='cancel after'):
        ns.has_legal_action_audit(nr,np,checkpoint=checkpoint)
    assert ns.has_legal_action_audit(nr,np)==expected
    # A subsequent normal transition still appends history, rather than
    # inheriting a leaked transient flag.
    child=ns.make_checked(nr,np,ns.transient_legal_actions(nr,np)[0])
    assert len(ns.snapshot(nr,child)['history'])==len(ns.snapshot(nr,np)['history'])+1


def test_runtime_optional_probe_keeps_core_fallback_and_propagates_cancel():
    c=compile_ruleset_for_execution(build_western_chess_ruleset());state=GameSession(c).state
    eng=semantic_engine_for(c)
    class Provider:
        strict=False
        def __call__(self,*args):raise AssertionError('full set not needed')
        def has_legal_action(self,position,ply,checkpoint):
            checkpoint()
            raise ValueError('operational failure')
    stats=SearchStatistics();runtime=SearchPathRuntime(state,c,legal_binding_provider=Provider());runtime.attach_stats(stats)
    assert runtime.has_legal_action(eng) is True
    assert stats.native_legality_fallbacks==1
    assert not runtime._legal_provider_active
    provider=Provider();provider.strict=True
    runtime=SearchPathRuntime(state,c,legal_binding_provider=provider)
    with pytest.raises(ValueError,match='operational'):runtime.has_legal_action(eng)
    provider.strict=False
    runtime=SearchPathRuntime(state,c,legal_binding_provider=provider)
    def cancelled():raise RuntimeError('actual checkpoint cancellation')
    with pytest.raises(RuntimeError,match='actual checkpoint'):runtime.has_legal_action(eng,cancelled)
    assert runtime.legal_provider_fallbacks==0
    assert runtime._legal_provider_active


def test_native_provider_probe_does_not_fill_legal_cache_or_replace_maxply():
    c=compile_ruleset_for_execution(build_western_chess_ruleset());state=GameSession(c).state
    provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
    stats=SearchStatistics();runtime=SearchPathRuntime(state,c,legal_binding_provider=provider);runtime.attach_stats(stats)
    runtime.ply_count=c.max_ply
    from generic_chess.core.terminal import terminal_from_search_runtime
    result=terminal_from_search_runtime(runtime)
    assert result.status.value=='max_ply'
    assert stats.native_legality_probe_calls==1
    assert stats.native_legality_calls==0
    assert runtime._legal_cache is None


def test_cancel_after64_failed_trials_restores_next_call():
    # Knight check cannot be blocked by any of the many available drops;
    # the other pieces cover all king exits. This reaches the C trial-loop
    # checkpoint, rather than only its pre-generation wrapper.
    c=compile_ruleset_for_execution(replace(build_standard_shogi_ruleset(),declarations=()))
    state=make_state(c,['r........']+['.........']*5+
        ['.nk......','..g......','K........'])
    from generic_chess.core.position import Hands
    pos=replace(state.position,hands=(Hands((('P',1),('L',1),('N',1),('S',1),('G',1))),Hands()))
    eng=semantic_engine_for(c);nr=compile_native_semantic_rules(c)
    np=ns.pack_current_position(nr,pos,ply_count=0)
    assert eng.has_legal_action(pos) is False
    expected=ns.has_legal_action_audit(nr,np)
    assert expected['has_action'] is False
    assert expected['s3_trial_count']>64
    calls=0
    def stop():
        nonlocal calls
        calls+=1
        if calls==3:raise RuntimeError('cancel at64 trials')
    with pytest.raises(RuntimeError,match='at64'):
        ns.has_legal_action_audit(nr,np,checkpoint=stop)
    assert ns.has_legal_action_audit(nr,np)==expected


def test_trial_checkpoint_can_reenter_native_without_leaking_modes():
    c=compile_ruleset_for_execution(replace(build_standard_shogi_ruleset(),declarations=()))
    state=make_state(c,['r........']+['.........']*5+
        ['.nk......','..g......','K........'])
    from generic_chess.core.position import Hands
    pos=replace(state.position,hands=(Hands((('P',1),('L',1),('N',1),('S',1),('G',1))),Hands()))
    nr=compile_native_semantic_rules(c);np=ns.pack_current_position(nr,pos,ply_count=0)
    initial=ns.pack_current_position(nr,GameSession(c).state.position,ply_count=0)
    action=ns.transient_legal_actions(nr,initial)[0]
    expected=ns.has_legal_action_audit(nr,np);calls=0
    def checkpoint():
        nonlocal calls
        calls+=1
        if calls>=3:
            assert ns.has_legal_action_audit(nr,initial)['has_action']
            child=ns.make_checked(nr,initial,action)
            assert len(ns.snapshot(nr,child)['history'])==len(ns.snapshot(nr,initial)['history'])+1
    assert ns.has_legal_action_audit(nr,np,checkpoint=checkpoint)==expected
    assert calls>=3
