"""Localize the sole completed event-root price-choice change.
Use existing predeclared unit-removal/one-reply diagnostic on both actual chosen
actions. Cross-score PV prefixes is descriptive, not actual q-frontier scores.
No new sample, fit, success criterion or independent strength claim.
"""
import json,sys,time
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import legal_successors
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;d=json.loads((p/'board-event-callers.json').read_bytes());rows=[r for r in d['cases'] if r['calls'][0]['decision']['action']!=r['calls'][1]['decision']['action']];assert len(rows)==1;row=rows[0];coverage=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes());old=next(x for x in coverage['cases'] if x['seed']==row['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for step in old['route'][:row['ply']]:s.submit(action_from_dict(step['action']))
before=s.state;side=before.position.side_to_move;anchors={t.type_id for t in c.piece_types if t.is_anchor}
def action(z):return action_from_dict(dict(kind='semantic_board',pattern_id=z['pattern_id'],geometry_id=z['geometry_id'],actor_type_id=z['actor_type_id'],**{'from':[z['from_square']['file'],z['from_square']['rank']],'to':[z['to_square']['file'],z['to_square']['rank']]},promotion_target_id=z['promotion_target_id']))
def count(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(n for t,n in pos.hands[owner].counts if t not in anchors)
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);base=build_ruleset_profile(c,cfg);candidate=replace(base,board_value_by_type=d['profiles'][str(row['seed'])]['candidate']['board_value_by_type']);ev={'default':SemanticAttackEvaluator(c,base,cfg,backend='core'),'board_ablation':SemanticAttackEvaluator(c,candidate,cfg,backend='core')};res=dict(scope=__doc__,seed=row['seed'],ply=row['ply'],choices=[])
for call in row['calls']:
 a=action(call['decision']['action']);child=next(ch for ac,ch in legal_successors(before,c) if ac==a);gain=count(before.position,1-side)-count(child.position,1-side);replies=legal_successors(child,c);losses=[count(child.position,side)-count(ch.position,side) for ac,ch in replies];worst=max([0]+losses);prefix=s
 ps=GameSession(c)
 for step in old['route'][:row['ply']]:ps.submit(action_from_dict(step['action']))
 stages=[]
 for z in call['decision']['principal_variation']:
  ps.submit(action(z));stages.append(dict(state=record_value(ps.state),scores={name:e.evaluate(ps.state) for name,e in ev.items()}))
 res['choices'].append(dict(profile=call['profile'],action=action_to_dict(a),immediate_gain=gain,worst_reply_loss=worst,unit_net=gain-worst,reply_count=len(replies),child_terminal=record_value(child.terminal_status),prefix_stages=stages))
write_record(p/'changed-choice-localization.json',res)
print([(r['profile'],r['immediate_gain'],r['worst_reply_loss'],r['unit_net']) for r in res['choices']])
