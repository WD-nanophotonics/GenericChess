"""Dormant B2 duplicate declaration and task-table normalization scope.
Existing fixed dual rule17physical-selector contexts; B2 copies B capabilities,
no stock/hand/explicit transformation target. Complete legal child comparisons
on17finite backgrounds; compare B2/Bcounterfactual focal task. Not arbitrary
semantic equivalence proof. Core<=120sec/20000children; no product deployment.
"""
import sys,json,copy,time,statistics,hashlib
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import legal_successors
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;inp=p/'stable-task-caller.json';d=json.loads(inp.read_bytes());rules=json.loads((root/'.local_agent/compression-20261009/fixed-rule-compression.json').read_bytes())['rules'];alias=copy.deepcopy(rules);clone=copy.deepcopy(next(t for t in rules['piece_types'] if t['type_id']=='B'));clone['type_id']='B2';clone['name']='Dormant B clone';alias['piece_types'].append(clone);c=compile_ruleset_for_execution(ruleset_from_dict(rules));ca=compile_ruleset_for_execution(ruleset_from_dict(alias));s=GameSession(c);sa=GameSession(ca);eng=semantic_engine_for(ca);anchors={t.type_id for t in ca.piece_types if t.is_anchor};res=dict(scope=__doc__,complete=False,alias_rules=alias,contexts=[],clone_tasks=[],checked_children=0);start=time.perf_counter()
def physical(state):
 x=record_value(state.position);x.pop('ruleset_fingerprint');return json.dumps(dict(position=x,terminal=record_value(state.terminal_status)),sort_keys=True)
def count(pos,side):return sum(x is not None and x.owner==side and x.current_type_id not in anchors for x in pos.board)+sum(n for t,n in pos.hands[side].counts if t not in anchors)
try:
 for ply in range(17):
  assert time.perf_counter()-start<120 and res['checked_children']<20000
  old=legal_successors(s.state,c);new=legal_successors(sa.state,ca);assert sorted(physical(ch) for a,ch in old)==sorted(physical(ch) for a,ch in new);res['checked_children']+=len(old);res['contexts'].append(dict(ply=ply,legal_children=len(old)))
  pos=sa.state.position;side=pos.side_to_move
  for row in [r for r in d['cells'] if r['ply']==ply and r['type']=='B']:
   source=row['source'];board=list(pos.board);board[source]=Piece(side,'B2','B2');cp=replace(pos,board=tuple(board));values=[]
   for a,b in eng.iter_legal_action_bindings(cp):
    if a.source==source:values.append(count(cp,1-side)-count(eng._transition(cp,a,b),1-side))
   task=max([0]+values);assert task==row['task'];res['clone_tasks'].append(dict(ply=ply,source=source,task=task))
  if ply<16:
   action=action_from_dict(d['route'][ply]['action']);expected=next(ch for a,ch in old if a==action);s.submit(action);child_key=physical(expected);aa=next(a for a,ch in new if physical(ch)==child_key);sa.submit(aa)
 means={t:Fraction(v) for t,v in d['raw_means'].items()};oldmedian=statistics.median(means.values());extended=dict(means,B2=means['B']);newmedian=statistics.median(extended.values());res['raw_old']=means;res['raw_extended']=extended;res['old_median']=oldmedian;res['new_median']=newmedian;res['rounded_old']={t:round(1000*v/oldmedian) for t,v in means.items()};res['rounded_extended']={t:round(1000*v/newmedian) for t,v in extended.items()};res['complete']=True
finally:res['seconds']=time.perf_counter()-start;write_record(p/'dormant-clone.json',res)
print(res['checked_children'],len(res['clone_tasks']),res['old_median'],res['new_median'],res['rounded_old'],res['rounded_extended'])
