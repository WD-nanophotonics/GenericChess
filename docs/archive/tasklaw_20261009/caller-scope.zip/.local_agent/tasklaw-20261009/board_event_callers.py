"""All22 frozen event roots: exposed board-price sensitivity, no strength claim.
44coldCore calls, D2/8192/5sec/q2hard8, hand/ordering fixedreference; rule-specific
common-slot context-first means/median1000 bankersround. No new sample, fit,
budget extension or default. <=260sec producer; preserve caps and raw outcomes.
"""
import sys,json,time,hashlib,statistics
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
from collections import defaultdict
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;inputs=[p/'common-slot-law.json',root/'.local_agent/generated6-20261008/coverage.json',root/'.local_agent/generated6-20261008/event-frontiers.json'];law,coverage,frontiers=[json.loads(f.read_bytes()) for f in inputs];events=sorted(frontiers['cases'],key=lambda r:(r['seed'],r['ply']));assert len(events)==22
out=p/'board-event-callers.json';assert not out.exists();start=time.perf_counter();res=dict(scope=__doc__,complete=False,inputs={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in inputs},producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=[],profiles={})
def check():
 assert time.perf_counter()-start<260
 for f in ('rollout.json','advisor.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('user_paused',False) and not d.get('stopped',False)
try:
 for i,event in enumerate(events):
  check();old=next(r for r in coverage['cases'] if r['seed']==event['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route'][:event['ply']]:s.submit(action_from_dict(step['action']))
  rows=[r for r in law['cells'] if r['seed']==event['seed']];types=sorted({r['type'] for r in rows});means={}
  for t in types:
   groups=defaultdict(list)
   for r in rows:
    if r['type']==t:groups[r['ply']].append(r['task'])
   means[t]=sum((Fraction(sum(v),len(v)) for v in groups.values()),Fraction())/len(groups)
  median=statistics.median(means.values());assert median>0;cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);base=build_ruleset_profile(c,cfg);board=dict(base.board_value_by_type);board.update({t:round(1000*v/median) for t,v in means.items()});candidate=replace(base,board_value_by_type=board);reference=SemanticAttackEvaluator(c,base,cfg,backend='core')
  class FrozenOrdering(SemanticAttackEvaluator):
   def capture_order_value(self,*args):return reference.capture_order_value(*args)
   def type_value(self,*args):return reference.type_value(*args)
  ev={'default':reference,'board_ablation':FrozenOrdering(c,candidate,cfg,backend='core')};res['profiles'][str(event['seed'])]=dict(raw=means,median=median,reference=record_value(base),candidate=record_value(candidate));before=(s.state,s.history,s._search_witnesses);row=dict(seed=event['seed'],ply=event['ply'],event=event['event'],calls=[]);res['cases'].append(row)
  for name in (('default','board_ablation') if i%2==0 else ('board_ablation','default')):
   check();player=AlphaBetaPlayer(c,evaluator_override=ev[name],use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));seconds=time.perf_counter()-t;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before;row['calls'].append(dict(profile=name,seconds=seconds,decision=record_value(dec)));write_record(out,res);print(event['seed'],event['ply'],name,dec.completed_depth,dec.termination_reason,dec.score,round(seconds,3),flush=True)
 res['complete']=True
finally:res['seconds']=time.perf_counter()-start;write_record(out,res)
