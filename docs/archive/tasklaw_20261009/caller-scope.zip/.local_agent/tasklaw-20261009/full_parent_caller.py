"""Actual fixed-dual pre-transform root caller, existing board-only profiles.
4 rotatedcoldCoreD2/8192/5sec/q2hard8; hand/order unchanged, no new task-law
sample or strength/default claim. Old post-choice witness calls did not
measure actual transformation selection. Keep all limits/failures.
"""
import json,sys,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.actions import action_to_dict
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;inp=p/'stable-task-caller.json';d=json.loads(inp.read_bytes());rule=json.loads((root/'.local_agent/compression-20261009/fixed-rule-compression.json').read_bytes())['rules'];c=compile_ruleset_for_execution(ruleset_from_dict(rule));assert c.ruleset_fingerprint==d['fingerprint']
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);base=build_ruleset_profile(c,cfg);assert record_value(base)==d['profiles']['default'];candidate=replace(base,board_value_by_type=d['profiles']['board_ablation']['board_value_by_type']);reference=SemanticAttackEvaluator(c,base,cfg,backend='core')
class FrozenOrdering(SemanticAttackEvaluator):
 def capture_order_value(self,*a):return reference.capture_order_value(*a)
 def type_value(self,*a):return reference.type_value(*a)
ev={'default':reference,'board_ablation':FrozenOrdering(c,candidate,cfg,backend='core')};out=p/'full-parent-caller.json';assert not out.exists();res=dict(scope=__doc__,complete=False,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),calls=[])
for name in ('default','board_ablation','board_ablation','default'):
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
 s=GameSession(c);before=(s.state,s.history,s._search_witnesses);player=AlphaBetaPlayer(c,evaluator_override=ev[name],use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));start=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));seconds=time.perf_counter()-start;validate_pv(s,decision);assert (s.state,s.history,s._search_witnesses)==before
 s.submit(decision.action);res['calls'].append(dict(profile=name,seconds=seconds,decision=record_value(decision),chosen_child=record_value(s.state)));write_record(out,res);print(name,decision.completed_depth,decision.termination_reason,decision.score,action_to_dict(decision.action),seconds,flush=True)
res['complete']=True;write_record(out,res)
