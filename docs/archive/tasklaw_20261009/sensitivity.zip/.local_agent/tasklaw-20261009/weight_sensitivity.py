"""Existing-cell context/slot weighting sensitivity; frozen context-first primary.
No new positions, samples or selection by output. All declared17contexts in
each case have at least one ordinary actualside slot; zero task cells retained.
Empty-slot future contexts are unsupported for slot intervention, not task0.
"""
import sys,json,hashlib
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=Path(__file__).parent;result=dict(scope=__doc__,complete=True,cases=[])
for name in ('common-slot-law.json','stable-task-caller.json','chess-task-law.json'):
 d=json.loads((p/name).read_bytes());seeds=sorted({r.get('seed','single') for r in d['cells']})
 for seed in seeds:
  rows=[r for r in d['cells'] if r.get('seed','single')==seed];types=sorted({r['type'] for r in rows});contexts=sorted({r['ply'] for r in rows});counts={ply:len({r['source'] for r in rows if r['ply']==ply}) for ply in contexts};assert contexts==list(range(17)) and min(counts.values())>0
  metrics={}
  for t in types:
   rs=[r for r in rows if r['type']==t];by={ply:[r['task'] for r in rs if r['ply']==ply] for ply in contexts};assert all(len(by[ply])==counts[ply] for ply in contexts)
   context=sum((Fraction(sum(v),len(v)) for v in by.values()),Fraction())/len(contexts);slot=Fraction(sum(r['task'] for r in rs),len(rs));metrics[t]=dict(context=context,slot=slot,difference=slot-context,zero_cells=sum(r['task']==0 for r in rs),cells=len(rs))
  result['cases'].append(dict(input=name,input_sha256=hashlib.sha256((p/name).read_bytes()).hexdigest(),seed=seed,context_slot_counts=counts,metrics=metrics,context_order=sorted(types,key=lambda t:(metrics[t]['context'],t)),slot_order=sorted(types,key=lambda t:(metrics[t]['slot'],t))))
write_record(p/'weight-sensitivity.json',result)
for r in result['cases']:print(r['input'],r['seed'],'counts',r['context_slot_counts'],'orders',r['context_order'],r['slot_order'])
