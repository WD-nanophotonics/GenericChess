"""Initial Chess common-slot one-opponent-reply unit exchange diagnostic.
75cells,5standalone ordinarytypes on15initialside slots. Max legal focal action
of immediate enemy ordinary board+hand removal minus worst legal opponent
ordinary removal, with virtualstop0. Ignores history adjudication, no WDL/material
claim or human fit; preserve raw action gains/losses and zero values.
Core only<=120sec/100000transitions; partial capped output remains evidence.
"""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'chess-one-reply.json';assert not out.exists();c=compile_ruleset_for_execution(build_western_chess_ruleset());eng=semantic_engine_for(c);pos=GameSession(c).state.position;side=pos.side_to_move;anchors={t.type_id for t in c.piece_types if t.is_anchor};types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);start=time.perf_counter();res=dict(scope=__doc__,complete=False,cells=[],transitions=0,fingerprint=c.ruleset_fingerprint,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
def count(p,s):return sum(x is not None and x.owner==s and x.current_type_id not in anchors for x in p.board)+sum(n for t,n in p.hands[s].counts if t not in anchors)
def tick():
 res['transitions']+=1;assert res['transitions']<=100000 and time.perf_counter()-start<120
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
try:
 for source,x in enumerate(pos.board):
  if x is None or x.owner!=side or x.current_type_id in anchors:continue
  for t in types:
   board=list(pos.board);board[source]=Piece(side,t,t);cp=replace(pos,board=tuple(board));actions=[];row=dict(source=source,source_role=x.current_type_id,type=t,actions=actions);res['cells'].append(row)
   for a,b in eng.iter_legal_action_bindings(cp):
    if a.source!=source:continue
    ch=eng._transition(cp,a,b);tick();gain=count(cp,1-side)-count(ch,1-side);losses=[]
    for reply,rb in eng.iter_legal_action_bindings(ch):
     after=eng._transition(ch,reply,rb);tick();losses.append(count(ch,side)-count(after,side))
    worst=max([0]+losses);actions.append(dict(action=record_value(a),gain=gain,worst_loss=worst,net=gain-worst,opponent_replies=len(losses)))
   row['immediate']=max([0]+[r['gain'] for r in actions]);row['one_reply']=max([0]+[r['net'] for r in actions]);write_record(out,res)
 res['summary']={t:{k:Fraction(sum(r[k] for r in res['cells'] if r['type']==t),15) for k in ('immediate','one_reply')} for t in types};res['complete']=True
finally:res['seconds']=time.perf_counter()-start;write_record(out,res)
print('complete',res['complete'],'transitions',res['transitions'],'seconds',res['seconds'],res.get('summary'))
