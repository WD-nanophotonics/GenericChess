"""Localize one-reply unit loss on existing positive-gain actions only.
Track focal destination capture versus total ordinary loss, exact witnesses.
No new context/horizon/fit.<=120sec/100000Core transitions.
"""
import json,sys,time
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;d=json.loads((p/'chess-one-reply.json').read_bytes());c=compile_ruleset_for_execution(build_western_chess_ruleset());pos=GameSession(c).state.position;eng=semantic_engine_for(c);side=pos.side_to_move;start=time.perf_counter();res=dict(scope=__doc__,complete=False,rows=[],transitions=0)
for cell in d['cells']:
 if not any(a['gain']>0 for a in cell['actions']):continue
 board=list(pos.board);board[cell['source']]=Piece(side,cell['type'],cell['type']);cp=replace(pos,board=tuple(board))
 for a,b in eng.iter_legal_action_bindings(cp):
  old=next((r for r in cell['actions'] if r['action']==record_value(a)),None)
  if old is None or old['gain']<=0:continue
  ch=eng._transition(cp,a,b);witnesses=[]
  for reply,rb in eng.iter_legal_action_bindings(ch):
   after=eng._transition(ch,reply,rb);res['transitions']+=1;assert res['transitions']<=100000 and time.perf_counter()-start<120
   removed=[i for i,x in enumerate(ch.board) if x is not None and x.owner==side and (after.board[i] is None or after.board[i].owner!=side)]
   if removed:witnesses.append(dict(reply=record_value(reply),removed=removed,focal=a.target in removed))
  worst_focal=int(any(w['focal'] for w in witnesses));assert len(witnesses)>0
  res['rows'].append(dict(source=cell['source'],type=cell['type'],action=record_value(a),gain=old['gain'],original_worst_loss=old['worst_loss'],focal_worst_loss=worst_focal,focal_net=old['gain']-worst_focal,witnesses=witnesses))
res['summary']={t:dict(positive_gain_actions=len(rs),focal_unsafe=sum(r['focal_worst_loss'] for r in rs),positive_focal_net=sum(r['focal_net']>0 for r in rs)) for t in sorted({r['type'] for r in res['rows']}) if (rs:=[r for r in res['rows'] if r['type']==t])}
res['complete']=True;res['seconds']=time.perf_counter()-start;write_record(p/'chess-reply-localization.json',res);print(res['summary'],res['transitions'],res['seconds'])
