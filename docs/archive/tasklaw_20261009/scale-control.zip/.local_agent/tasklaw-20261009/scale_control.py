"""Existing changed root scale-only diagnostic, not a new normalization default.
Same rule means:original ordinary median versus median with B duplicated.
4rotatedcoldCoreD2/8192/5sec/q2hard8, referencehand/order/dynamic fixed.
No semantic clone equivalence claim for this rule; no new law samples or fit.
"""
import json,sys,time,statistics
from pathlib import Path
from fractions import Fraction
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;d=json.loads((p/'board-event-callers.json').read_bytes());coverage=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes());old=next(x for x in coverage['cases'] if x['seed']==202610082002);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for step in old['route'][:4]:s.submit(action_from_dict(step['action']))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);base=build_ruleset_profile(c,cfg);raw={t:Fraction(v) for t,v in d['profiles']['202610082002']['raw'].items()};medians={'primary':statistics.median(raw.values()),'duplicate_B_scale':statistics.median([*raw.values(),raw['B']])};reference=SemanticAttackEvaluator(c,base,cfg,backend='core')
class FrozenOrdering(SemanticAttackEvaluator):
 def capture_order_value(self,*a):return reference.capture_order_value(*a)
 def type_value(self,*a):return reference.type_value(*a)
profiles={name:replace(base,board_value_by_type={**base.board_value_by_type,**{t:round(1000*v/median) for t,v in raw.items()}}) for name,median in medians.items()};res=dict(scope=__doc__,complete=False,raw=raw,medians=medians,boards={name:dict(v.board_value_by_type) for name,v in profiles.items()},calls=[]);out=p/'scale-control.json';assert not out.exists();before=(s.state,s.history,s._search_witnesses)
for name in ('primary','duplicate_B_scale','duplicate_B_scale','primary'):
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
 ev=FrozenOrdering(c,profiles[name],cfg,backend='core');player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));start=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));seconds=time.perf_counter()-start;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before;res['calls'].append(dict(profile=name,seconds=seconds,decision=record_value(dec)));write_record(out,res);print(name,dec.completed_depth,dec.termination_reason,dec.score,record_value(dec.action),flush=True)
res['complete']=True;write_record(out,res)
