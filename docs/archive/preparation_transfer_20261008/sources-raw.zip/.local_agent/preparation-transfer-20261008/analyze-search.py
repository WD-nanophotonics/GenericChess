import json,hashlib,statistics
from pathlib import Path
p=Path(__file__).parent;src=p/'search.json';d=json.loads(src.read_bytes());assert d['complete']
r={'complete':True,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declared_roots':len(d['cases']),'accepted_roots':sum(x['accepted'] for x in d['cases']),'seconds':d['seconds'],'comparisons':{},'choice_changes':[],'caps':[]}
for depth in (3,4):
 for a,b in (('generic','direct'),('generic','preparation'),('direct','preparation')):
  pairs=[]
  for root in d['cases']:
   if not root['accepted']:continue
   matches={x['table']:x for x in root['searches'] if x['depth']==depth and not x['repeat']}
   if any(matches[k]['decision']['completed_depth']!=depth for k in (a,b)):continue
   x,y=(matches[k]['decision'] for k in (a,b));same=x['action']==y['action'];pairs.append((x,y,matches[a],matches[b]))
   if not same:r['choice_changes'].append({'seed':root['seed'],'depth':depth,'tables':[a,b],'actions':[x['action'],y['action']],'scores':[x['score'],y['score']],'nodes':[x['nodes'],y['nodes']]})
  r['comparisons'][f'{depth}:{a}/{b}']={'paired_complete':len(pairs),'changed_actions':sum(x['action']!=y['action'] for x,y,_,_ in pairs),'changed_scores':sum(x['score']!=y['score'] for x,y,_,_ in pairs),'median_node_ratio_b_over_a':statistics.median(y['nodes']/x['nodes'] for x,y,_,_ in pairs),'total_search_seconds_a':sum(mx['search_wall_seconds'] for _,_,mx,_ in pairs),'total_search_seconds_b':sum(my['search_wall_seconds'] for _,_,_,my in pairs)}
for root in d['cases']:
 for x in root.get('searches',[]):
  if x['decision']['completed_depth']<x['depth']:r['caps'].append({'seed':root['seed'],'table':x['table'],'requested_depth':x['depth'],'decision':x['decision']})
r['repeat_calls']=sum(x['repeat'] for root in d['cases'] for x in root.get('searches',[]));r['search_calls']=sum(len(root.get('searches',[])) for root in d['cases']);r['fallbacks']=sum(x['decision']['native_legality_fallbacks'] for root in d['cases'] for x in root.get('searches',[]))
r['limits']=['Fixed material sum is an additional deployment assumption, not the original preparation policy.','Changes in actions/scores/node use are sensitivity, not strength gains.','Ordering weights and attack authority fixed; leaf prices vary and may affect internal TT/killers naturally.','Node-capped depth4 cells remain unknown at depth4; no result-driven extension.','Cold repeated depth3 decisions must match action, score, nodes, completed depth and PV exactly.','Wall times are local observations, no hardware-independent performance claims.']
(p/'search-summary.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in r.items() if k not in ('choice_changes','caps')},indent=2));print('caps',len(r['caps']),'changed records',len(r['choice_changes']))
