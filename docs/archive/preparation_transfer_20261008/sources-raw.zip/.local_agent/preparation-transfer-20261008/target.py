import sys,json,time,hashlib,collections
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(Path(__file__).parent)]
from task import preparation_task,direct_task
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=Path(__file__).parent;src=root/'.local_agent/preparation-20261008/pilot.json';original=json.loads(src.read_bytes());out=p/'target.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();t=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'helper_sha256':sha(p/'task.py'),'input_sha256':sha(src),'declaration_sha256':sha(p/'target-declaration.json'),'rows':[],'core_transitions':0};write_record(out,r)
def check(n):
 r['core_transitions']+=n
 assert r['core_transitions']<120000 and time.perf_counter()-t<240
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
def initial_turn(state,c,side):
 pos=replace(state.position,side_to_move=side);key=repetition_identity_key(pos,c);counts=((key,1),)
 return GameState(pos,0,counts,semantic_engine_for(c).terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),))
try:
 for old in original['rows']:
  for target_type in ('P','N','B','R','Q'):
   check(0);cells=old['cells'];source,target=cells[:2];board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[source]=Piece(0,old['actor'],old['actor']);board[target]=Piece(1,target_type,target_type)
   for sq,tid,owner in zip(cells[2:],old['background_types'],(0,0,1,1)):board[sq]=Piece(owner,tid,tid)
   row={'seed':old['seed'],'actor':old['actor'],'target_type':target_type,'cells':cells,'background_types':old['background_types']};r['rows'].append(row)
   try:c=compile_ruleset_for_execution(replace(build_western_chess_ruleset(),initial_position=tuple(tuple(board[y*8:y*8+8]) for y in range(8))))
   except ValueError as exc:row.update(accepted=False,rejection=str(exc));continue
   row['accepted']=True;state=GameSession(c).state;row['preparation']=preparation_task(state,c,source,target,check);row['direct']=direct_task(initial_turn(state,c,1),c,source,target,check)
   if target_type==old['target_type']:
    assert row['preparation']['success']==old['success']
    assert row['direct']['success']==old['direct_position_reference']
   write_record(out,r)
  print(old['seed'],old['actor'],flush=True)
 mass={'P':8/15,'N':2/15,'B':2/15,'R':2/15,'Q':1/15};seeds=sorted({x['seed'] for x in r['rows']});common=[(seed,tid) for seed in seeds for tid in mass if all(x['accepted'] for x in r['rows'] if x['seed']==seed and x['target_type']==tid)]
 r['common_cells']=common;r['common_mass']=sum(mass[tid]/len(seeds) for seed,tid in common)
 r['scores']={actor:{field:sum(mass[x['target_type']]/len(seeds)*x[field]['success'] for x in r['rows'] if x['actor']==actor and (x['seed'],x['target_type']) in common)/r['common_mass'] for field in ('preparation','direct')} for actor in mass} if r['common_mass'] else {}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
print({'accepted':sum(x['accepted'] for x in r['rows']),'common_mass':r['common_mass'],'scores':r['scores'],'transitions':r['core_transitions'],'seconds':r['seconds']})
