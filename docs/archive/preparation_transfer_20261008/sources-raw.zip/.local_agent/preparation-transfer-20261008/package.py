import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/preparation_transfer_20261008';dest.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
pins={
 'transfer.json':'transfer.py','target.json':'target.py','cross-game.json':'cross_game.py',
 'cannon.json':'cannon.py','cannon-complete.json':'cannon_complete.py','search.json':'search.py',
 'search-summary.json':'analyze-search.py','additive-control.json':'additive-control.py',
 'choice-boundary.json':'choice-boundary.py','recombined.json':'recombined.py','drop-order.json':'drop-order.py',
 'terminal-boundary.json':'terminal-boundary.py','terminal-boundary-v2.json':'terminal-boundary-v2.py','summary.json':'summarize.py'}
verified=[]
for result,producer in pins.items():
 d=json.loads((p/result).read_bytes());assert d['producer_sha256']==sha((p/producer).read_bytes()),result
 if 'helper_sha256' in d:assert d['helper_sha256']==sha((p/'task.py').read_bytes()),result
 verified.append({'result':result,'producer':producer,'complete':d.get('complete')})
assert json.loads((p/'cannon-complete.json').read_bytes())['prior_partial_sha256']==sha((p/'cannon.json').read_bytes())
assert json.loads((p/'terminal-boundary-v2.json').read_bytes())['prior_failed_sha256']==sha((p/'terminal-boundary.json').read_bytes())
files=sorted(f for f in p.iterdir() if f.suffix in ('.py','.json') and f.name!='cross-game-summary.json')
files += [root/'.local_agent/preparation-20261008/pilot.json',root/'.local_agent/target-context-20261008/displacement-role-pilot-v2.json',root/'.local_agent/target-context-20261008/frozen-role-candidate.json',root/'tests/rule_semantics_ir_fixtures.py',root/'tests/product/test_recombined_semantic_lifecycle.py']
archive=dest/'sources-raw.zip';assert not archive.exists();members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();assert not name.startswith('/') and '..' not in Path(name).parts
  b=f.read_bytes();z.writestr(name,b);members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for member in members:assert sha((Path(tmp)/member['path']).read_bytes())==member['sha256']
index={'base_commit':'6120b63f4fcb2a564fbfd36770a5c01b72eeca85','archive_sha256':sha(archive.read_bytes()),'members':members,'producer_pins':verified,'extracted_rehashed':True,'retained_failures':['cannon.json: initial120000-transition development checkpoint reached before completion; preserve original prefix; separately declared increment computes only missing cells.','terminal-boundary.json: experimental View lacks required search-history witnesses; V2 uses real compiled GameSession.','Original capped depth4 C/R/N seed4016 and recombined ply6 depth3 remain unknown at requested depths.','Incomplete4096-leaf Core references retained as unknown, not score certificates.'],'excluded':'User/private inputs, raw Slack/account records, workflow state/memo, credentials. All included data Agent synthetic research; fixture source belongs to current repository. Redundant unpinned cross-game-summary excluded; pinned summarize.py independently reconstructs compact vectors.'}
(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
summary=json.loads((p/'summary.json').read_bytes());(root/'docs/research/data/preparation_transfer_20261008.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print({'members':len(members),'producer_pins':len(verified),'archive_bytes':archive.stat().st_size,'uncompressed_bytes':sum(x['bytes'] for x in members)})
