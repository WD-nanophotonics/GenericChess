import sys,json,time,hashlib,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;src=p/'cross-game.json';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();g=json.loads(src.read_bytes())['games']['shogi'];chosen=next(x for x in g['rows'] if x['actor']=='G' and x['preparation']['success']==0 and any(a['preparation_terminal']['status']=='checkmate' for a in x['preparation']['preparations']));selected=[chosen,next(x for x in g['rows'] if x['seed']==chosen['seed'] and x['owner']==chosen['owner'] and x['actor']=='TP')]
out=p/'terminal-boundary.json';assert not out.exists();r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'declaration':'Observed-data boundary check only: first frozen Shogi G root with task0 yet a winning quiet preparation, plus same-layout/owner TP. Replay actual full-state mate and compare one-ply public search through existing session interface. No new population or horizon sweep; raw task remains0 and is not rewritten to include WDL. Two cold calls per root, depth1/4096nodes/2sec, q0/root-tacticaloff; whole pilot30sec.','rows':[]};started=time.perf_counter();c=compile_ruleset_for_execution(build_standard_shogi_ruleset());engine=semantic_engine_for(c);template=GameSession(c).state.position
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0,hand_weight=0);profile=build_ruleset_profile(c,cfg);scores={a:v['preparation'] for a,v in g['scores'].items()};median=statistics.median(scores.values());values={a:0 if x.is_anchor else max(1,round(1000*scores[a]/median)) for a,x in profile.piece_profiles.items()};ev=SemanticAttackEvaluator(c,replace(profile,board_value_by_type=values),cfg,backend='native')
class View:
 def __init__(self,state):self.state=state;self.compiled=c
 def legal_actions(self):
  from generic_chess.core.movegen import legal_actions
  return legal_actions(self.state,c)
try:
 for row in selected:
  assert time.perf_counter()-started<30
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  n=9;board=[None]*81;board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K');source,target=row['cells'][:2];base=row['source_base'];board[source]=Piece(row['owner'],base,row['actor'],promoted=base!=row['actor']);board[target]=Piece(1-row['owner'],row['target_type'],row['target_type'])
  for sq,tid,owner in zip(row['cells'][2:],row['background_types'],(0,0,1,1)):board[sq]=Piece(owner,tid,tid)
  pos=replace(template,board=tuple(board),side_to_move=row['owner']);key=repetition_identity_key(pos,c);counts=((key,1),);state=GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),));view=View(state)
  winning=next(a for a in row['preparation']['preparations'] if a['preparation_terminal']['status']=='checkmate');child=apply_action(state,action_from_dict(winning['action']),c);assert child.terminal_status.winner==row['owner']
  item={'actor':row['actor'],'seed':row['seed'],'owner':row['owner'],'task_success':row['preparation']['success'],'winning_quiet_action':winning['action'],'actual_terminal':record_value(child.terminal_status),'table_value':values[row['actor']],'searches':[]};r['rows'].append(item)
  for repeat in (0,1):
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False));d=player.choose_action(view,SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(view,d);final=apply_action(state,d.action,c);assert final.terminal_status.winner==row['owner'] and d.score==999999999;item['searches'].append(record_value(d))
  assert item['searches'][0]['action']==item['searches'][1]['action']
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
print([(x['actor'],x['task_success'],x['table_value'],x['searches'][0]['score']) for x in r['rows']])
