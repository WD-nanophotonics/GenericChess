import sys,json,time,hashlib,random,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=p/'cannon-complete.json';score=json.loads(src.read_bytes());assert score['complete'];template=root/'.local_agent/target-context-20261008/frozen-role-candidate.json';base=ruleset_from_dict(json.loads(template.read_bytes())['definition_template']);out=p/'search.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'score_sha256':sha(src),'template_sha256':sha(template),'declaration_sha256':sha(p/'search-declaration.json'),'cases':[]};write_record(out,r)
class FixedOrdering(SemanticAttackEvaluator):
 def __init__(self,c,profile,cfg,ordering):super().__init__(c,profile,cfg,backend='native');self.ordering=ordering
 def capture_order_value(self,moving,captured):return self.ordering.capture_order_value(moving,captured)
 def type_value(self,tid):return self.ordering.type_value(tid)
def check():
 assert time.perf_counter()-started<720
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
def task_profile(profile,field):
 raw={tid:score['scores'][tid][field] for tid in ('C','R','N')};median=statistics.median(raw.values());board={tid:(0 if piece.is_anchor else max(1,round(1000*raw[tid]/median))) for tid,piece in profile.piece_profiles.items()}
 pieces={tid:replace(piece,raw_capability_score=raw.get(tid,0),normalized_board_value=board[tid]) for tid,piece in profile.piece_profiles.items()}
 return replace(profile,evaluator_version=field+'-task-diagnostic',piece_profiles=pieces,board_value_by_type=board,median_non_anchor_value=1000)
try:
 for seed in range(202610104000,202610104024):
  check();cells=random.Random(seed).sample([y*8+x for y in range(1,7) for x in range(1,7)],6);board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K')
  for sq,(owner,tid) in zip(cells,((0,'C'),(0,'R'),(0,'N'),(1,'C'),(1,'R'),(1,'N'))):board[sq]=Piece(owner,tid,tid)
  definition=replace(base,initial_position=tuple(tuple(board[y*8:y*8+8]) for y in range(8)));row={'seed':seed,'cells':cells,'definition':ruleset_to_dict(definition),'searches':[]};r['cases'].append(row)
  try:c=compile_ruleset_for_execution(definition);s=GameSession(c)
  except ValueError as exc:row.update(accepted=False,rejection=str(exc));write_record(out,r);continue
  row['accepted']=True;row['root_terminal']=record_value(s.state.terminal_status);row['root_legal_actions']=len(s.legal_actions());cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0)
  original=build_ruleset_profile(c,cfg);profiles={'generic':original,'direct':task_profile(original,'direct'),'preparation':task_profile(original,'preparation')};ordering=Evaluator(c,original,cfg);row['tables']={label:dict(prof.board_value_by_type) for label,prof in profiles.items()};row['raw_task_scores']=score['scores'];labels=list(profiles);labels=labels[seed%3:]+labels[:seed%3]
  def run(label,depth,repeat):
   check();t=time.perf_counter();ev=FixedOrdering(c,profiles[label],cfg,ordering);player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False));setup=time.perf_counter()-t;t=time.perf_counter()
   decision=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t;t=time.perf_counter();validate_pv(s,decision);verification=time.perf_counter()-t
   item={'table':label,'depth':depth,'repeat':repeat,'setup_seconds':setup,'search_wall_seconds':wall,'verification_seconds':verification,'decision':record_value(decision)};row['searches'].append(item);write_record(out,r);return item
  for depth in (3,4):
   for label in labels:run(label,depth,False)
  for label in reversed(labels):
   previous=next(x for x in row['searches'] if x['table']==label and x['depth']==3 and not x['repeat'])
   if previous['decision']['completed_depth']!=3:continue
   again=run(label,3,True)
   for key in ('score','action','nodes','completed_depth','principal_variation'):assert again['decision'][key]==previous['decision'][key],('repeat discrepancy',seed,label,key)
  print(seed,[(x['table'],x['depth'],x['decision']['completed_depth'],x['decision']['nodes']) for x in row['searches'] if not x['repeat']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
