import sys,json,hashlib,time,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import legal_successors
from generic_chess.core.actions import action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();t=time.perf_counter()
raw=json.loads((p/'cannon-complete.json').read_bytes());old=json.loads((root/'.local_agent/target-context-20261008/frozen-role-candidate.json').read_bytes())
# First completed root in the existing declared iteration order, no new population.
row=raw['rows'][0];assert row['actor']=='C' and row['target_type']=='C'
board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');source,target=row['cells'][:2]
board[source]=Piece(0,'C','C');board[target]=Piece(1,'C','C')
for sq,(owner,tid) in zip(row['cells'][2:],((0,'R'),(0,'R'),(1,'C'),(1,'R'))):board[sq]=Piece(owner,tid,tid)
c=compile_ruleset_for_execution(replace(ruleset_from_dict(old['definition_template']),initial_position=tuple(tuple(board[y*8:y*8+8]) for y in range(8))));s=GameSession(c)
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0,hand_weight=0)
profile=build_ruleset_profile(c,cfg);scores={k:raw['scores'][k]['preparation'] for k in ('C','R','N')};median=statistics.median(scores.values());table={k:0 if v.is_anchor else max(1,round(1000*scores[k]/median)) for k,v in profile.piece_profiles.items()};profile=replace(profile,board_value_by_type=table);e=Evaluator(c,profile,cfg)
actual={json.dumps(action_to_dict(a),sort_keys=True):child for a,child in legal_successors(s.state,c)};results=[]
for prep in row['preparation']['preparations']:
 child=actual[json.dumps(prep['action'],sort_keys=True)];assert not child.terminal_status.is_terminal
 assert child.position.hands==s.state.position.hands
 counts=lambda pos:sorted((piece.owner,piece.current_type_id,piece.base_type_id,piece.promoted) for piece in pos.board if piece is not None)
 assert counts(child.position)==counts(s.state.position)
 # Evaluator uses side-to-move; report both raw and fixed owner0 perspective.
 value=e.evaluate(child);owner0=value if child.position.side_to_move==0 else -value
 results.append({'action':prep['action'],'material_side_to_move':value,'material_owner0':owner0,'preparation_success':prep['success'],'physical_replies':prep['physical_replies'],'history_length':len(child.history),'terminal':record_value(child.terminal_status)})
assert len({x['material_owner0'] for x in results})==1
assert len({x['preparation_success'] for x in results})>1
out={'complete':True,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(p/'cannon-complete.json'),'template_sha256':sha(root/'.local_agent/target-context-20261008/frozen-role-candidate.json'),'declaration':'Existing first C/C root, all qualifying nontransforming quiet preparations; no new search batch. Pure static Evaluator with all dynamic/promotion/hand terms disabled; verify same counted identities and nonterminal states. Test the additive deployment boundary, not preparation quality.','seed':row['seed'],'table':table,'rows':results,'seconds':time.perf_counter()-t,'interpretation':'Fixed additive material weights cannot retain position-dependent preparation preferences. Search choice changes under these weights are deployment sensitivity, not evidence of learning preparation.'}
write_record(p/'additive-control.json',out);print(len(results),table,sorted({x['material_owner0'] for x in results}),min(x['preparation_success'] for x in results),max(x['preparation_success'] for x in results))
