import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import action_to_dict,action_from_dict
from generic_chess.core.transition import legal_successors,apply_action
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=root/'.local_agent/preparation-transfer-20261008';src=root/'.local_agent/preparation-20261008/pilot.json';data=json.loads(src.read_bytes());out=p/'transfer.json';assert not out.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'declaration_sha256':sha(p/'declaration.json'),'rows':[],'core_transitions':0};t=time.perf_counter();write_record(out,r)
def check():
 assert time.perf_counter()-t<240 and r['core_transitions']<60000
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
def successors(state,c):
 check();pairs=legal_successors(state,c);r['core_transitions']+=len(pairs);return pairs
def idx(s):return s.file+8*s.rank
def visible(action,rotate=False):
 d=action_to_dict(action) if not isinstance(action,dict) else dict(action)
 d.pop('geometry_id',None)
 if rotate:
  for k in ('from','to'):
   if k in d:d[k]=[7-d[k][0],7-d[k][1]]
 return json.dumps(d,sort_keys=True)
def find(actual,old):
 found=[(a,s) for a,s in actual if visible(a)==visible(old,True)]
 assert len(found)==1,('nonunique transformed action',old,len(found))
 return found[0]
try:
 for old in data['rows']:
  check();board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');cells=old['cells'];board[cells[0]]=Piece(0,old['actor'],old['actor']);board[cells[1]]=Piece(1,old['target_type'],old['target_type'])
  for sq,tid,owner in zip(cells[2:],old['background_types'],(0,0,1,1)):board[sq]=Piece(owner,tid,tid)
  mirrored=tuple(None if piece is None else replace(piece,owner=1-piece.owner) for piece in reversed(board))
  c=compile_ruleset_for_execution(replace(build_western_chess_ruleset(),initial_position=tuple(tuple(mirrored[y*8:y*8+8]) for y in range(8))));engine=semantic_engine_for(c);initial=GameSession(c).state
  pos=replace(initial.position,side_to_move=1);key=repetition_identity_key(pos,c);counts=((key,1),);state=GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),))
  # These fixture roots have identical empty auxiliary state; never infer a
  # general right/square-slot rotation from this restricted observation.
  assert pos.aux_state==(),pos.aux_state
  source,target=63-cells[0],63-cells[1];original=pos.board[source];victim=pos.board[target];pairs=successors(state,c);items=[]
  for prepare,prepared in pairs:
   if not hasattr(prepare,'from_square') or idx(prepare.from_square)!=source:continue
   new_source=idx(prepare.to_square)
   if pos.board[new_source] is not None or prepared.position.board[new_source]!=original:continue
   expected=list(pos.board);expected[source]=None;expected[new_source]=original
   if tuple(expected)!=prepared.position.board:continue
   assert prepared.position.board[target]==victim
   item={'action':action_to_dict(prepare),'physical_replies':0,'terminal_replies':[],'source_lost_replies':0,'success':0,'preparation_terminal':record_value(prepared.terminal_status)};items.append(item)
   if prepared.terminal_status.is_terminal:continue
   outcomes={}
   for reply,child in successors(prepared,c):
    tracked=idx(reply.to_square) if hasattr(reply,'from_square') and idx(reply.from_square)==target else target
    actual=child.position.board[tracked];assert actual is not None and actual.owner==victim.owner and actual.base_type_id==victim.base_type_id
    alive=child.position.board[new_source]==original
    available=not child.terminal_status.is_terminal and alive and bool(list(engine.iter_legal_action_bindings(child.position,source=new_source,target=tracked)))
    observable=(available,alive,child.terminal_status)
    if child.position in outcomes:assert outcomes[child.position]==observable
    else:
     outcomes[child.position]=observable
     if not alive:item['source_lost_replies']+=1
     if child.terminal_status.is_terminal:item['terminal_replies'].append(record_value(child.terminal_status))
   item['physical_replies']=len(outcomes);item['success']=sum(x[0] for x in outcomes.values())/len(outcomes) if outcomes else 0
  assert len(items)==len(old['preparations'])
  comparison=[]
  for previous in old['preparations']:
   matching=[x for x in items if visible(x['action'])==visible(previous['action'],True)];assert len(matching)==1
   transformed=matching[0]
   for k in ('physical_replies','source_lost_replies','success','terminal_replies','preparation_terminal'):assert transformed[k]==previous[k],(old['seed'],old['actor'],k,previous[k],transformed[k])
   comparison.append({'original_action':previous['action'],'transformed_action':transformed['action'],'success':transformed['success'],'physical_replies':transformed['physical_replies'],'source_lost_replies':transformed['source_lost_replies']})
  witnesses=[]
  for label in ('witness','mixed_witness'):
   witness=old[label]
   if witness is None:continue
   path=[];current=state
   for step in ('prepare','reply','capture'):
    action,current=find(successors(current,c),witness[step]);path.append(action_to_dict(action))
   tracked=63-witness['tracked_target'];assert current.position.board[tracked].owner==1 and len(current.history)==4
   witnesses.append({'label':label,'actions':path,'final_history_length':len(current.history),'terminal':record_value(current.terminal_status)})
  result={'seed':old['seed'],'actor':old['actor'],'original_max':old['success'],'transformed_max':max([x['success'] for x in items],default=0),'preparations':comparison,'witnesses':witnesses,'initial_aux':record_value(pos.aux_state)};r['rows'].append(result);write_record(out,r);print(old['seed'],old['actor'],len(items),result['transformed_max'],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
