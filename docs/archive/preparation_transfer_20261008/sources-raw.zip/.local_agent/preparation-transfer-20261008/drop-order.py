import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=p/'recombined.json';prior=json.loads(src.read_bytes());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();out=p/'drop-order.json';assert not out.exists();t=time.perf_counter();r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'declaration_sha256':sha(p/'drop-order-declaration.json'),'cases':[]};write_record(out,r)
c=compile_ruleset_for_execution(ruleset_from_dict(prior['rules']));cfg=EvaluationConfig(**prior['config']);profile=build_ruleset_profile(c,cfg);assert dict(profile.board_value_by_type)==prior['table'];ev=SemanticAttackEvaluator(c,profile,cfg,backend='native');s=GameSession(c)
def check():
 assert time.perf_counter()-t<300
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
try:
 for ply in range(9):
  if ply>=4:
   old=next(x for x in prior['cases'] if x['ply']==ply);assert len(s.state.history)==old['history_length'];row={'ply':ply,'searches':[]};r['cases'].append(row)
   for depth in (2,3):
    modes=(False,True) if (ply+depth)%2 else (True,False)
    for repeat in (0,1):
     for staged in (modes if repeat==0 else tuple(reversed(modes))):
      check();player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False,use_staged_move_picker=staged));start=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-start;validate_pv(s,d);item={'depth':depth,'staged':staged,'repeat':repeat,'wall_seconds':wall,'decision':record_value(d)};row['searches'].append(item);write_record(out,r)
      reference=old['references'][str(depth)]
      if d.completed_depth==depth and reference['complete']:assert d.score==reference['score']
      for previous in row['searches'][:-1]:
       q=previous['decision']
       if previous['depth']==depth and previous['staged']==staged:
        for key in ('score','action','completed_depth','principal_variation','nodes'):assert item['decision'][key]==q[key],('repeat',ply,depth,staged,key)
       if previous['depth']==depth and q['completed_depth']==depth and d.completed_depth==depth:assert q['score']==d.score,('paired score',ply,depth,staged)
   print(ply,[(x['depth'],x['staged'],x['decision']['completed_depth'],x['decision']['nodes']) for x in row['searches'] if x['repeat']==0],flush=True)
  if ply<8:s.submit(action_from_dict(prior['route'][ply]))
 r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
