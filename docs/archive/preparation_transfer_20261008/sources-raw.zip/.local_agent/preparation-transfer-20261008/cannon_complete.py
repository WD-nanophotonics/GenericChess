import sys,json,time,hashlib,statistics
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(Path(__file__).parent)]
from task import preparation_task,direct_task
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=Path(__file__).parent;src=root/'.local_agent/target-context-20261008/frozen-role-candidate.json';old=json.loads(src.read_bytes());base=ruleset_from_dict(old['definition_template']);out=p/'cannon-complete.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();t=time.perf_counter();partial=json.loads((p/'cannon.json').read_bytes());completed=[x for x in partial['rows'] if 'direct' in x];done={(x['seed'],x['actor'],x['target_type']) for x in completed}
r={'complete':False,'producer_sha256':sha(Path(__file__)),'helper_sha256':sha(p/'task.py'),'input_sha256':sha(src),'declaration_sha256':sha(p/'cannon-declaration.json'),'common_seeds':old['common_seeds'],'rows':completed,'core_transitions':0,'prior_partial_sha256':sha(p/'cannon.json'),'prior_attempt_transitions':partial['core_transitions'],'completion_declaration_sha256':sha(p/'cannon-completion-declaration.json')};write_record(out,r)
def check(delta):
 r['core_transitions']+=delta
 assert r['core_transitions']<60000 and time.perf_counter()-t<120
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
try:
 for seed in old['common_seeds']:
  for prior in [x for x in old['rows'] if x['seed']==seed]:
   if (prior['seed'],prior['actor'],prior['target_type']) in done:continue
   source,target=prior['cells'][:2];board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[source]=Piece(0,prior['actor'],prior['actor']);board[target]=Piece(1,prior['target_type'],prior['target_type'])
   for sq,(owner,tid) in zip(prior['cells'][2:],((0,'R'),(0,'R'),(1,'C'),(1,'R'))):board[sq]=Piece(owner,tid,tid)
   c=compile_ruleset_for_execution(replace(base,initial_position=tuple(tuple(board[y*8:y*8+8]) for y in range(8))));engine=semantic_engine_for(c);state=GameSession(c).state
   row={k:prior[k] for k in ('seed','actor','target_type','cells')};r['rows'].append(row);row['preparation']=preparation_task(state,c,source,target,check)
   pos=replace(state.position,side_to_move=1);key=repetition_identity_key(pos,c);counts=((key,1),);opponent=GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),));row['direct']=direct_task(opponent,c,source,target,check)
   assert row['direct']['success']==prior['reference']
  write_record(out,r);print(seed,len(r['rows']),r['core_transitions'],flush=True)
 r['scores']={actor:{field:statistics.mean(x[field]['success'] for x in r['rows'] if x['actor']==actor) for field in ('preparation','direct')} for actor in ('C','R','N')};r['complete']=True
finally:r['seconds']=time.perf_counter()-t;write_record(out,r)
print(r['scores'],r['seconds'])
