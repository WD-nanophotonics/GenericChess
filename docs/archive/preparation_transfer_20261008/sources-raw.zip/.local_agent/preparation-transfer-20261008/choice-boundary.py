import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import SemanticBoardMove,action_to_dict
from generic_chess.core.coordinates import Square
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=p/'search.json';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();raw=json.loads(src.read_bytes());case=next(x for x in raw['cases'] if x['seed']==202610104008);c=compile_ruleset_for_execution(ruleset_from_dict(case['definition']));s=GameSession(c);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0);base=build_ruleset_profile(c,cfg)
profiles={name:replace(base,board_value_by_type=table) for name,table in case['tables'].items()};evaluators={name:SemanticAttackEvaluator(c,profile,cfg,backend='native') for name,profile in profiles.items()}
action=lambda d:SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
chosen={name:next(x['decision'] for x in case['searches'] if x['table']==name and x['depth']==4 and not x['repeat']) for name in ('direct','preparation')}
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'declaration_sha256':sha(p/'choice-boundary-declaration.json'),'seed':case['seed'],'pv_rows':[],'reference_cells':[]};started=time.perf_counter();out=p/'choice-boundary.json';assert not out.exists();write_record(out,r)
class Limit(RuntimeError):pass
class Count:
 def __init__(self,e):self.e=e;self.calls=0;self.started=time.perf_counter()
 def evaluate(self,state):
  self.calls+=1
  if self.calls>40000 or time.perf_counter()-self.started>45 or time.perf_counter()-started>240:raise Limit('reference cost checkpoint')
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  return self.e.evaluate(state)
try:
 for label,d in chosen.items():
  state=s.state;steps=[]
  for a in d['principal_variation']:
   previous=state;state=apply_action(state,action(a),c);steps.append({'action':a,'captured':record_value(previous.position.board[a['to_square']['file']+8*a['to_square']['rank']]),'terminal':record_value(state.terminal_status)})
  assert not state.terminal_status.is_terminal
  values={name:e.evaluate(state)*(1 if state.position.side_to_move==0 else -1) for name,e in evaluators.items()}
  material={name:sum((1 if piece.owner==0 else -1)*profile.board_value_by_type[piece.current_type_id] for piece in state.position.board if piece is not None) for name,profile in profiles.items()}
  assert values[label]==d['score'],('PV score mismatch',label,values[label],d['score'])
  r['pv_rows'].append({'table':label,'root_score':d['score'],'steps':steps,'fixed_owner0_leaf_scores':values,'material':material,'dynamic':{name:values[name]-material[name] for name in values},'history_length':len(state.history)})
 for label in ('direct','preparation'):
  for choice in ('direct','preparation'):
   state=apply_action(s.state,action(chosen[choice]['action']),c);count=Count(evaluators[label]);cell={'evaluator':label,'root_choice':choice,'complete':False};r['reference_cells'].append(cell);t=time.perf_counter()
   try:value,a=reference_minimax(state,3,count,c,ply=1);cell.update(complete=True,root_perspective_value=-value,reply=record_value(a))
   except Limit as exc:cell['failure']=str(exc)
   cell.update(leaf_evaluations=count.calls,seconds=time.perf_counter()-t);write_record(out,r);print(cell,flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
