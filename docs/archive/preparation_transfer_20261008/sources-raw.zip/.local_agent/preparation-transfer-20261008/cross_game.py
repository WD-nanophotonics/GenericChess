import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(Path(__file__).parent)]
from task import preparation_task,direct_task
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=Path(__file__).parent;src=root/'.local_agent/target-context-20261008/displacement-role-pilot-v2.json';old=json.loads(src.read_bytes());out=p/'cross-game.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();total=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'helper_sha256':sha(p/'task.py'),'input_sha256':sha(src),'declaration_sha256':sha(p/'cross-game-declaration.json'),'games':{}};write_record(out,r)
try:
 for name,base in [('chess',build_western_chess_ruleset()),('shogi',build_standard_shogi_ruleset())]:
  started=time.perf_counter();prior=old['games'][name];c=compile_ruleset_for_execution(base);engine=semantic_engine_for(c);template=GameSession(c).state.position;n=base.board_size;types=prior['source_types'];anchor=next(x.type_id for x in base.piece_types if x.is_anchor)
  g={'complete':False,'rows':[],'core_transitions':0,'common_mass':prior['common_mass'],'common_seeds':prior['common_seeds'],'source_types':types};r['games'][name]=g
  def check(delta):
   g['core_transitions']+=delta
   assert g['core_transitions']<500000 and time.perf_counter()-started<300
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  def state_for(board,side):
   pos=replace(template,board=tuple(board),side_to_move=side);key=repetition_identity_key(pos,c);counts=((key,1),)
   assert not engine.in_check(pos,0) and not engine.in_check(pos,1)
   return GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),))
  for seed in prior['common_seeds']:
   for original in [x for x in prior['rows'] if x['seed']==seed]:
    check(0);source,target=original['cells'][:2];actor=original['actor'];owner=original['owner'];provenance=prior['source_base_provenance'][actor];board=[None]*(n*n);board[0]=Piece(0,anchor,anchor);board[-1]=Piece(1,anchor,anchor);board[source]=Piece(owner,provenance,actor,promoted=provenance!=actor);board[target]=Piece(1-owner,original['target_type'],original['target_type'])
    for sq,tid,actor_owner in zip(original['cells'][2:],original['background_types'],(0,0,1,1)):board[sq]=Piece(actor_owner,tid,tid)
    row={k:original[k] for k in ('seed','mass','actor','owner','target_type','background_types','cells')};row['source_base']=provenance;g['rows'].append(row)
    row['preparation']=preparation_task(state_for(board,owner),c,source,target,check);row['direct']=direct_task(state_for(board,1-owner),c,source,target,check);row['old_direct_reference']=original['reference']
    assert row['direct']['success']==original['reference'],('full-state direct mismatch',name,seed,actor,owner,row['direct']['success'],original['reference'])
   write_record(out,r);print(name,seed,len(g['rows']),g['core_transitions'],round(time.perf_counter()-started,2),flush=True)
  g['scores']={a:{field:sum(x['mass']*x[field]['success'] for x in g['rows'] if x['actor']==a)/(2*g['common_mass']) for field in ('preparation','direct')} for a in types}
  g['per_owner']={owner:{a:{field:sum(x['mass']*x[field]['success'] for x in g['rows'] if x['actor']==a and x['owner']==owner)/g['common_mass'] for field in ('preparation','direct')} for a in types} for owner in (0,1)}
  g['complete']=True;g['seconds']=time.perf_counter()-started;write_record(out,r)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-total;write_record(out,r)
