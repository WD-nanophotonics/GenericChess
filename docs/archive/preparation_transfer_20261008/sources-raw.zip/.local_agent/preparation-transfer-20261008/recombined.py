import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import action_to_dict
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'recombined.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
fixtures=weird_rulesets();board=[[None]*8 for _ in range(8)]
for owner,tid,file,rank in ((0,'K',4,0),(1,'K',7,7),(0,'R',0,0),(0,'R',0,1),(0,'R',0,2),(0,'R',1,1),(1,'R',1,3),(1,'R',1,4)):board[rank][file]=Piece(owner,tid,tid)
definition=replace(fixtures[2],initial_position=tuple(map(tuple,board)),semantic_actions=(fixtures[1].semantic_actions[0],fixtures[2].semantic_actions[0]),drop_allowed={'R':((True,)*64,(True,)*64),'TP':((False,)*64,(False,)*64)})
c=compile_ruleset_for_execution(definition);s=GameSession(c);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);profile=build_ruleset_profile(c,cfg);ev=SemanticAttackEvaluator(c,profile,cfg,backend='native')
r={'complete':False,'producer_sha256':sha(Path(__file__)),'fixture_sha256':sha(root/'tests/rule_semantics_ir_fixtures.py'),'lifecycle_test_sha256':sha(root/'tests/product/test_recombined_semantic_lifecycle.py'),'declaration_sha256':sha(p/'recombined-declaration.json'),'rules':ruleset_to_dict(definition),'config':record_value(cfg),'table':dict(profile.board_value_by_type),'route':[],'cases':[]};write_record(out,r)
route=(((1,1),(1,3),False),((7,7),(6,7),False),((1,3),(1,4),False),((6,7),(5,7),False),((0,0),(1,1),True),((5,7),(4,7),False),(None,(0,0),False),((4,7),(3,7),False))
def check():
 assert time.perf_counter()-started<300
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
try:
 for ply in range(9):
  check()
  if ply in (4,5,6,7,8):
   case={'ply':ply,'history_length':len(s.state.history),'aux':record_value(s.state.position.aux_state),'hands':record_value(s.state.position.hands),'legal_actions':len(s.legal_actions()),'legal_drops':sum(hasattr(a,'base_type_id') for a in s.legal_actions()),'references':{},'searches':[]};r['cases'].append(case)
   for depth in (2,3):
    check();count=CountedEvaluator(ev,seconds=5,evaluations=4096);t=time.perf_counter();reference={'complete':False}
    try:score,a=reference_minimax(s.state,depth,count,c);reference.update(complete=True,score=score,action=record_value(a))
    except ReferenceLimit as exc:reference['failure']=str(exc)
    reference.update(seconds=time.perf_counter()-t,leaf_evaluations=count.calls);case['references'][depth]=reference;write_record(out,r)
    previous=None
    for repeat in (0,1):
     check();player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t;validate_pv(s,d);item={'depth':depth,'repeat':repeat,'wall_seconds':wall,'decision':record_value(d)};case['searches'].append(item);write_record(out,r)
     if d.completed_depth==depth and reference['complete']:assert d.score==reference['score'],('completed reference discrepancy',ply,depth,d.score,reference['score'])
     signature=(d.action,d.score,d.completed_depth,d.principal_variation,d.nodes)
     if previous is not None:assert signature==previous,('repeat discrepancy',ply,depth)
     previous=signature
   print(ply,case['legal_actions'],case['legal_drops'],[(x['depth'],x['decision']['completed_depth'],x['decision']['score']) for x in case['searches']],flush=True)
  if ply==8:break
  source,target,semantic=route[ply];matches=[]
  for a in s.legal_actions():
   if (a.to_square.file,a.to_square.rank)!=target:continue
   if source is None:
    if hasattr(a,'base_type_id'):matches.append(a)
   elif hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source and a.pattern_id.startswith('sem_')==semantic:matches.append(a)
  a,=matches;r['route'].append(action_to_dict(a));s.submit(a)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
