from pathlib import Path
p=Path(__file__).parent
s=(p/'terminal-boundary.py').read_text()
s=s.replace("out=p/'terminal-boundary.json'","out=p/'terminal-boundary-v2.json'")
a=s.index('class View:');b=s.index('try:',a);s=s[:a]+s[b:]
old="pos=replace(template,board=tuple(board),side_to_move=row['owner']);key=repetition_identity_key(pos,c);counts=((key,1),);state=GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),));view=View(state)"
new="definition=replace(build_standard_shogi_ruleset(),initial_position=tuple(tuple(board[y*9:y*9+9]) for y in range(9)));c=compile_ruleset_for_execution(definition);view=GameSession(c);assert row['owner']==0;state=view.state;profile=build_ruleset_profile(c,cfg);ev=SemanticAttackEvaluator(c,replace(profile,board_value_by_type=values),cfg,backend='native')"
assert old in s;s=s.replace(old,new)
s=s.replace("'rows':[]};started","'prior_failed_sha256':sha(p/'terminal-boundary.json'),'correction':'The first synthetic View omitted required search history witnesses; preserve failure. V2 uses an actual public GameSession with a compiled initially-safe owner0 root, not private state mutation.', 'rows':[]};started")
(p/'terminal-boundary-v2.py').write_bytes(s.encode())
