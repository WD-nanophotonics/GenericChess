from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
D=Path('.local_agent/cold-rule-20261013');out=D/'capacity';out.mkdir(exist_ok=True);assert not (out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Do larger allowed unfamiliar-rule inputs change the earlier small-cold-setup conclusion or existing incoming/Native capability boundary?',seeds=[2026101941,2026101942,2026101943,2026101944],sizes=[8,12,16,20],setup='bilateral_random',hybrid=True,root='initial full generated state, no prefix filter',backend_requested=[False,True],evaluator='actual default geometric',q=0,depth=12,seconds=1,max_nodes=None,calls=8,whole_fuse_seconds=600,expected_seconds=120,scope='Prospective scope change, not extension of old frozen6case declaration. Size and generated mechanics/type counts jointly change, so no isolated board-size causal ratio. Keep exceptions/cap/fallback/terminal, no resample. No newmetadata/cache, no hugejobs; fullgeneratedrules retained, usercache off. Constructor+generation+compile outside existing searchclock measured separately.'))
start=time.perf_counter();rows=[];samples=[]
for seed,size in zip([2026101941,2026101942,2026101943,2026101944],[8,12,16,20]):
 p.rr.stopped();assert time.perf_counter()-start<600;t=time.perf_counter();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));generation=time.perf_counter()-t;t=time.perf_counter();c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);compile_seconds=time.perf_counter()-t;c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c)
 sample=dict(seed=seed,size=size,ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),generation_seconds=generation,compile_seconds=compile_seconds,types=len(c.support.type_metadata),patterns=len(c.ir.patterns),incoming_present=c._incoming_attack_paths is not None,incoming_rows=None if c._incoming_attack_paths is None else sum(map(len,c._incoming_attack_paths.values())))
 samples.append(sample);write_record(out/'samples.json',samples)
 for native in [False,True]:
  p.rr.stopped();assert time.perf_counter()-start<600;before=s.to_record();t=time.perf_counter()
  try:player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=native)
  except (ValueError,RuntimeError,NotImplementedError,AttributeError) as e:
   rows.append(dict(seed=seed,size=size,native_requested=native,error_type=type(e).__name__,error=str(e),constructor_seconds=time.perf_counter()-t,unexecuted_queries=1,resampled=False));continue
  setup=time.perf_counter()-t;t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=12,max_time_seconds=1,max_nodes=None,quiescence_max_depth=0,quiescence_hard_max_depth=8));wall=time.perf_counter()-t;assert before==s.to_record();child=s.state
  for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
  rows.append(dict(seed=seed,size=size,native_requested=native,actual_provider=player.native_legality_provider is not None,constructor_seconds=setup,search_wall=wall,decision=record_value(d),history_restored=True,pv_core_legal=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(size,native,'compile',round(compile_seconds,4),'ctor',round(setup,4),'incoming',sample['incoming_present'],'provider',player.native_legality_provider is not None,'depth',d.completed_depth,d.termination_reason,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
