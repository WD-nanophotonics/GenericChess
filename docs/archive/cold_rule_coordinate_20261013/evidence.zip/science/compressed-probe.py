def build(ir,area):
 groups={};rank=0
 for owner in (0,1):
  for pattern in ir.patterns:
   if pattern.target.kind!='target_enemy':continue
   for tid in pattern.type_ids:
    for source in range(area):
     for gid in pattern.geometry_ids:
      geom=ir.geometry.get(gid)
      if geom is None or geom.kind=='drop' or geom.atom_source is not None and geom.atom_source[0]!=tid:continue
      path=geom.paths.get(str(owner),{}).get(source,())
      endpoints=range(min(1,len(path))) if geom.kind=='leap' else range(max(0,(geom.min_steps or 1)-1),len(path))
      for endpoint in endpoints:
       rank+=1
       if rank>262144:return None,rank
       groups.setdefault((str(owner),path[endpoint]),{}).setdefault(source,{}).setdefault(tid,[]).append((rank,pattern,gid,endpoint))
 return {key:{source:{tid:tuple(rows) for tid,rows in typed.items()} for source,typed in sources.items()} for key,sources in groups.items()},rank

def candidate(self,position,square,by_owner,checkpoint=None):
 self._ensure_match(position)
 if self.semantic is not c:return OLD(self,position,square,by_owner,checkpoint)
 se._checkpoint(checkpoint);selected=[];owner_key=str(by_owner)
 for source,typed in groups.get((owner_key,square),{}).items():
  se._checkpoint(checkpoint);piece=position.board[source]
  if piece is not None and piece.owner==by_owner:
   selected.extend((rank,pattern,source,piece.current_type_id,gid,endpoint) for rank,pattern,gid,endpoint in typed.get(piece.current_type_id,()))
 selected.sort(key=lambda row:row[0])
 for rank,pattern,source,tid,gid,endpoint in selected:
  se._checkpoint(checkpoint);piece=position.board[source];geom=self.ir.geometry[gid]
  path=() if geom.kind=='leap' else tuple(geom.paths[owner_key][source][:endpoint])
  binding=self._make_binding(pattern,gid,tid,piece,source,square,None,path,position)
  if self._path_holds(pattern.path,position,binding,by_owner,checkpoint=checkpoint) and self._guards_hold(pattern,position,binding,by_owner,checkpoint=checkpoint):return True
 return False
