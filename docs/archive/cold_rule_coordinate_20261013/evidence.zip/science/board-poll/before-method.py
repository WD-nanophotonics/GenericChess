def _iter_board_candidates(
    self, pattern, position: Position, checkpoint: Checkpoint | None = None,
    sources_by_owner_type=None,
):
    side = position.side_to_move
    if sources_by_owner_type is None:
        sources_by_owner_type = _sources_by_owner_type(position)
    for tid in pattern.type_ids:
        _checkpoint(checkpoint)
        for source, piece in sources_by_owner_type.get((side, tid), ()):
            _checkpoint(checkpoint)
            for gid in pattern.geometry_ids:
                _checkpoint(checkpoint)
                geometry = self.ir.geometry.get(gid)
                if geometry is None or geometry.kind == "drop":
                    continue
                if (
                    geometry.atom_source is not None
                    and geometry.atom_source[0] != tid
                ):
                    continue
                for target, path in geometry_candidates(geometry, str(side), source):
                    _checkpoint(checkpoint)
                    if not self._target_holds(pattern.target.kind, position, target, side):
                        continue
                    promotions = self._promotion_choices(pattern, piece, source, target)
                    for promotion_target in promotions:
                        _checkpoint(checkpoint)
                        binding = self._make_binding(
                            pattern, gid, tid, piece, source, target,
                            promotion_target, path, position,
                        )
                        if not self._path_holds(
                            pattern.path, position, binding, side,
                            checkpoint=checkpoint,
                        ):
                            continue
                        if not self._guards_hold(
                            pattern, position, binding, side,
                            checkpoint=checkpoint,
                        ):
                            continue
                        action = SemanticAction(
                            pattern_id=pattern.pattern_id,
                            source=source,
                            target=target,
                            promotion_target_id=promotion_target,
                            actor_type=tid,
                            geometry_id=gid,
                        )
                        yield action, binding
