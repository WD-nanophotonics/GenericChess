from pathlib import Path
import sys,json,time,random
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import semantic_executor as se
from generic_chess.rules.ir import CompiledGeometry,geometry_candidates
from rule_semantics_ir_fixtures import cannon_ruleset,castling_ruleset,en_passant_ruleset,nifu_ruleset,uchifuzume_ruleset,weird_rulesets
D=Path('.local_agent/cold-rule-20261013');out=D/'compressed-incoming';assert not(out/'qualification-plan.json').exists()
write_record(out/'qualification-plan.json',dict(question='Does prefix-free row scheduling preserve everypath, duplicateendpoint, guard and completefrontend in finite DSL roots?',cases=['Chess','Shogi','cannon','castling','EP','nifu','uchifuzume','5weird'],plies=4,actualplay='reprsorted first legal, preserveterminal',static='originalordered geometry_candidates stream vs complete compressed rows, including synthetic duplicate type/gid and repeatedendpoint/minstep/leap/drop',scope='No new search or training; same immutablecompiled IR. Finite grammar coverage, not full-domainproof. Compare scalar booleans/alltarget/completelegalactions/entrycancellation onactualstates.'))
OLD=se.SemanticEngine.is_square_attacked;ns=dict(se.__dict__);ns.update(OLD=OLD);exec((D/'compressed-probe.py').read_text(),ns);build=ns['build'];candidate=ns['candidate'];rows=[];checks=0

def decode(groups,ir):
 decoded=[]
 for (owner,target),sources in groups.items():
  for source,typed in sources.items():
   for tid,entries in typed.items():
    for rank,pattern,gid,endpoint in entries:
     geom=ir.geometry[gid];path=() if geom.kind=='leap' else tuple(geom.paths[owner][source][:endpoint]);decoded.append((rank,owner,target,pattern,tid,source,gid,path))
 return [row[1:] for row in sorted(decoded,key=lambda x:x[0])]

def reference(ir,area):
 return [(str(owner),target,pattern,tid,source,gid,path) for owner in (0,1) for pattern in ir.patterns if pattern.target.kind=='target_enemy' for tid in pattern.type_ids for source in range(area) for gid in pattern.geometry_ids if (geom:=ir.geometry.get(gid)) is not None and geom.kind!='drop' and (geom.atom_source is None or geom.atom_source[0]==tid) for target,path in geometry_candidates(geom,str(owner),source)]
try:
 definitions=[build_builtin_ruleset('western_chess'),build_builtin_ruleset('standard_shogi'),cannon_ruleset(),castling_ruleset(),en_passant_ruleset(),nifu_ruleset(),uchifuzume_ruleset(),*weird_rulesets()]
 for i,rules in enumerate(definitions):
  c=compile_ruleset_for_execution(rules);area=c.board_shape.area;groups,n=build(c.ir,area);assert groups is not None;assert decode(groups,c.ir)==reference(c.ir,area);s=p.GameSession(c);engine=se.SemanticEngine(c);ns.update(c=c,groups=groups);visited=0;targets=0
  for ply in range(4):
   position=s.state.position;se.SemanticEngine.is_square_attacked=OLD;expected=[engine.is_square_attacked(position,target,owner) for owner in (0,1) for target in range(-1,area+1)];actions=engine.legal_actions(position)
   se.SemanticEngine.is_square_attacked=candidate;assert expected==[engine.is_square_attacked(position,target,owner) for owner in (0,1) for target in range(-1,area+1)];assert actions==engine.legal_actions(position);visited+=1;targets+=2*(area+2)
   se.SemanticEngine.is_square_attacked=OLD
   if s.result.status.value!='ongoing' or not s.legal_actions() or ply==3:break
   s.submit(sorted(s.legal_actions(),key=repr)[0])
  rows.append(dict(case=i,static_rows=n,actual_states=visited,paired_target_queries=targets,complete_frontier_and_guards_equal=True));checks+=targets;write_record(out/'qualification.json',dict(complete=False,rows=rows));print(i,n,visited,targets,'exact',flush=True)
 synthetic=0
 for kind in ['leap','ray','drop']:
  for minimum in [1,2,4]:
   geom=CompiledGeometry('g',kind,min_steps=minimum,paths={'0':{0:(1,2,1,3)},'1':{0:(3,1,2,1)}});pattern=SimpleNamespace(target=SimpleNamespace(kind='target_enemy'),type_ids=('t','t'),geometry_ids=('g','g'));ir=SimpleNamespace(patterns=(pattern,),geometry={'g':geom});groups,n=build(ir,4);assert decode(groups,ir)==reference(ir,4);synthetic+=n
 write_record(out/'qualification.json',dict(complete=True,rows=rows,paired_target_queries=checks,actual_target_queries=2*checks,synthetic_cases=9,synthetic_rows=synthetic,all_ordered_rows_and_full_frontiers_exact=True,search_calls=0))
finally:se.SemanticEngine.is_square_attacked=OLD
