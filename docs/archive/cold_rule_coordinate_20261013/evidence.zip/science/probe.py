from pathlib import Path
import sys,json,time,random,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai import evaluation as ep
from generic_chess.ai.evaluation import cache as cm
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/cold-rule-20261013');D.mkdir(exist_ok=True)
assert not (D/'declaration.json').exists()
cases=['western_chess','standard_shogi',2026101841,2026101842,2026101843,2026101844]
decl=dict(question='Does the actual public default constructor dominate cold unfamiliar-rule first-decision latency, and which existing stage?',cases=cases,generated_sizes=[8,8,12,12],prefix=8,rng_offset=14000,orders=2,arms=['cold_private_disk','disk_warm_new_cache','memory_warm_shared_cache'],search=dict(seconds=1,max_depth=12,max_nodes=100000,quiescence_max_depth=0,quiescence_hard_max_depth=8),max_search_calls=36,fuse_seconds=600,scope='Default evaluator and legality policy, complete generated states/history. Profile and disk cache are existing APIs; each repetition owns a separate empty private disk directory. No user cache changed. Search timer excludes constructor and compile/prefix; report separately, no strength/machine-exclusive claim. Keep unsupported default-evaluator roots and all partial cases, no resampling. Imports outside measured clock, so not process-start total latency.')
write_record(D/'declaration.json',decl);start=time.perf_counter();rows=[];samples=[];unavailable=[];metrics=[]
orig=cm.build_ruleset_profile

def profile(*a,**kw):
 t=time.perf_counter()
 try:return orig(*a,**kw)
 finally:metrics.append(dict(stage='build_ruleset_profile',seconds=time.perf_counter()-t))
cm.build_ruleset_profile=profile
try:
 for case in cases:
  p.rr.stopped();t=time.perf_counter()
  if isinstance(case,str):rules=build_builtin_ruleset(case);c=compile_ruleset_for_execution(rules);seed=2026101841
  else:
   g=p.generate_game(p.GeneratorConfig(seed=case,board_size=8 if case<=2026101842 else 12,setup_preset='bilateral_random',allow_hybrid=True));rules=g.ruleset;c0=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);seed=case
  compile_seconds=time.perf_counter()-t;t=time.perf_counter();s=p.GameSession(c);rng=random.Random(seed+14000);walk=[]
  for _ in range(8):
   acts=sorted(s.legal_actions(),key=repr)
   if not acts or s.result.status.value!='ongoing':break
   a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
  prefix_seconds=time.perf_counter()-t
  samples.append(dict(case=case,compile_seconds=compile_seconds,prefix_seconds=prefix_seconds,fingerprint=c.ruleset_fingerprint,ruleset=json.loads(p.serialize_ruleset(rules)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk))
  write_record(D/'samples.json',samples)
  for rep in range(2):
   cache=EvaluationProfileCache(use_disk=True,disk_dir=D/f'cache-{case}-{rep}');before=s.to_record();priorprofile=None
   for arm in decl['arms']:
    p.rr.stopped();assert time.perf_counter()-start<600
    if arm=='disk_warm_new_cache':cache=EvaluationProfileCache(use_disk=True,disk_dir=D/f'cache-{case}-{rep}')
    metrics.clear();t=time.perf_counter()
    try:player=AlphaBetaPlayer(c,profile_cache=cache)
    except (ValueError,AttributeError,RuntimeError,NotImplementedError) as e:
     unavailable.append(dict(case=case,rep=rep,arm=arm,error_type=type(e).__name__,error=str(e),setup_seconds=time.perf_counter()-t,unexecuted_searches=3,resampled=False));break
    ctor=time.perf_counter()-t;pr=record_value(player.evaluation_profile)
    if priorprofile is not None:assert priorprofile==pr
    priorprofile=pr;t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=100000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=8));search=time.perf_counter()-t
    assert before==s.to_record();child=s.state
    for a in d.principal_variation:
     assert a in legal_actions(child,c);child=apply_action(child,a,c)
    row=dict(case=case,rep=rep,arm=arm,constructor_seconds=ctor,search_wall=search,first_decision_after_compiled_seconds=ctor+search,actual_provider=player.native_legality_provider is not None,provider_compile_seconds=player.native_legality_provider.compile_seconds if player.native_legality_provider else None,profile_cache_hit=player.evaluation_profile_cache_hit,setup_metrics=metrics.copy(),profile=pr,decision=record_value(d),history_restored=True,pv_core_legal=True)
    rows.append(row);write_record(D/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable));print(case,rep,arm,round(ctor,5),round(search,5),d.completed_depth,d.score,flush=True)
finally:cm.build_ruleset_profile=orig
write_record(D/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start));print('DONE',len(rows),'unavailable',len(unavailable),flush=True)
