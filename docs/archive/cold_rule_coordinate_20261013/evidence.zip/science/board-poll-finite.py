from pathlib import Path
import sys,json,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import semantic_executor as se
D=Path('.local_agent/cold-rule-20261013');out=D/'board-poll';OLD=se.SemanticEngine._iter_board_candidates;ns=dict(se.__dict__);exec((out/'candidate-method.py').read_text(),ns);NEW=ns['_iter_board_candidates'];rows=[]
try:
 for case in ['western_chess','standard_shogi',2026101851,2026101852,2026101853,2026101854]:
  if isinstance(case,str):c=compile_ruleset_for_execution(build_builtin_ruleset(case));seed=2026101851
  else:
   g=p.generate_game(p.GeneratorConfig(seed=case,board_size=8 if case<=2026101852 else 12,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);seed=case
  s=p.GameSession(c);rng=random.Random(seed+14000)
  for _ in range(8):
   acts=sorted(s.legal_actions(),key=repr)
   if not acts or s.result.status.value!='ongoing':break
   s.submit(rng.choice(acts))
  engine=se.SemanticEngine(c);position=s.state.position
  def run(fn,stop):
   se.SemanticEngine._iter_board_candidates=fn;count=0;acts=[];error=None
   def poll():
    nonlocal count
    count+=1
    if count==stop:raise InterruptedError('injected cooperative boundary')
   try:acts=engine.legal_actions(position,checkpoint=None if stop is None else poll)
   except InterruptedError as e:error=(type(e).__name__,str(e))
   return dict(count=count,actions=record_value(acts),error=error)
  a,b=run(OLD,None),run(NEW,None);assert a==b
  a,b=run(OLD,-1),run(NEW,-1);assert a==b;n=a['count'];points=sorted(set(list(range(1,21))+[n//2,n]))
  for point in points:assert run(OLD,point)==run(NEW,point)
  rows.append(dict(case=case,uninterrupted_polls=n,legal_count=len(a['actions']),failure_points=points,all_exact=True));write_record(out/'finite.json',dict(complete=False,rows=rows));print(case,n,len(a['actions']),len(points),'exact',flush=True)
finally:se.SemanticEngine._iter_board_candidates=OLD
write_record(out/'finite.json',dict(complete=True,rows=rows,search_calls=0,all_callbacks_and_errors_exact=True))
