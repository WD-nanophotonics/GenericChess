from pathlib import Path
import sys,json,ast,itertools,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core import semantic_executor as se
from generic_chess.rules.ir import geometry_candidates
D=Path('.local_agent/cold-rule-20261013');out=D/'compressed-incoming';assert not(out/'complete-row-plan.json').exists();write_record(out/'complete-row-plan.json',dict(question='Do all178104 original ordered endpoint occurrences on actual20-board expand exactly without any old enlargedprefixindex?',search_calls=0,reference='Original pattern/type/source/gid loops and geometry_candidates, original target_enemy/non-drop/atom_source compatibility; streaming reference andrank-sorted compressed descriptors. Full tuple equality, not sets/bool only.',advice='New Dot recommends exact fullordered row equivalence; min_steps uses originalzero-basedendpoint. Internalrepeatedpathsynthetic is helper robustness outside productioncomplete-path validation, not legalcounterexample.'))
ns=dict(se.__dict__);ns.update(OLD=se.SemanticEngine.is_square_attacked,se=se);exec((D/'compressed-probe.py').read_text(),ns)
g=p.generate_game(p.GeneratorConfig(seed=2026101944,board_size=20,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);groups,n=ns['build'](c.ir,400);assert n==178104
observed=[]
for (owner,target),sources in groups.items():
 for source,typed in sources.items():
  for tid,entries in typed.items():
   for rank,pattern,gid,endpoint in entries:observed.append((rank,owner,target,pattern,tid,source,gid,endpoint))
observed.sort(key=lambda row:row[0])
def expected():
 for owner in (0,1):
  for pattern in c.ir.patterns:
   if pattern.target.kind!='target_enemy':continue
   for tid in pattern.type_ids:
    for source in range(400):
     for gid in pattern.geometry_ids:
      geom=c.ir.geometry.get(gid)
      if geom is None or geom.kind=='drop' or geom.atom_source is not None and geom.atom_source[0]!=tid:continue
      for target,path in geometry_candidates(geom,str(owner),source):yield str(owner),target,pattern,tid,source,gid,path
h=hashlib.sha256();count=0
for row,ref in itertools.zip_longest(observed,expected()):
 assert row is not None and ref is not None
 rank,owner,target,pattern,tid,source,gid,endpoint=row;geom=c.ir.geometry[gid];path=() if geom.kind=='leap' else tuple(geom.paths[owner][source][:endpoint]);assert (owner,target,pattern,tid,source,gid,path)==ref;count+=1;assert rank==count
 h.update(json.dumps([owner,target,pattern.pattern_id,tid,source,gid,path],separators=(',',':')).encode()+b'\n')
write_record(out/'complete-row-verification.json',dict(rows=count,full_tuple_equality=True,ordered_duplicates_preserved=True,stream_sha256=h.hexdigest(),old65536_and131072_failures_unchanged=True,search_calls=0,no_materialized_old_largeprefixindex=True));print(count,h.hexdigest(),'allordered exact')
