from pathlib import Path
import sys,json,types
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.core import coordinates as co
D=Path('.local_agent/cold-rule-20261013')
OLD=co.square_to_index
code='''def square_to_index(sq, n):
    if type(n) is int and n > 0:
        return sq.rank * n + sq.file
    return sq.rank * _shape(n).width + sq.file
'''
ns=dict(co.__dict__);exec(code,ns);NEW=ns['square_to_index'];(D/'candidate-coordinate.py').write_text(code,encoding='utf-8')
(D/'before-coordinates.py').write_bytes(Path('generic_chess/core/coordinates.py').read_bytes())
class IntSubclass(int):pass
extents=[1,4,8,12,32,co.BoardShape(9,10),co.BoardShape(4,7),0,-1,True,False,None,2.5,'8',IntSubclass(8)]
def outcome(fn,sq,n):
 try:return ('ok',fn(sq,n))
 except Exception as e:return(type(e).__name__,str(e))
rows=[];count=0
for n in extents:
 for f in range(-2,35):
  for r in range(-2,35):
   sq=co.Square(f,r);a,b=outcome(OLD,sq,n),outcome(NEW,sq,n);assert a==b;(count:=count+1)
 rows.append({'extent':repr(n),'comparisons':37**2})
for sq in [None,{},object()]:
 for n in extents:assert outcome(OLD,sq,n)==outcome(NEW,sq,n);count+=1
(D/'coordinate-finite.json').write_text(json.dumps({'comparisons':count,'rows':rows,'all_exact':True,'errors_compared':True},indent=2),encoding='utf-8');print(count,'exact including errors')
