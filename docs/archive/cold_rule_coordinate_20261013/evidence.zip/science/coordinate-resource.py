from pathlib import Path
import sys,json,time,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import coordinates as co
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/cold-rule-20261013');out=D/'coordinate-resource';out.mkdir(exist_ok=True);assert not (out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does the observed coordinate cost improvement buy complete retained decisions under equal actual search time?',cases=['standard_shogi',2026101844],generated_size=12,prefix=8,rng_offset=14000,seconds=[4,16,64],q=0,max_depth=12,max_nodes=None,orders=2,arms=['before','candidate'],calls=24,requested_seconds=672,fuse_seconds=1000,scope='Same public default geometric evaluator/Native legality, original fullhistory and semantic states. Paired reverse order under ordinary concurrent load; unchanged depth alone no strength gain. Imports/constructor remain outside search timer and separately measured in cold declaration. Preserve every partial and all output choices; no result-driven budget extension.'))
ORIG=co.square_to_index;ns=dict(co.__dict__);exec((D/'candidate-coordinate.py').read_text(),ns);NEW=ns['square_to_index'];references=[(m,k) for name,m in list(sys.modules.items()) if name.startswith('generic_chess') and m for k,v in list(vars(m).items()) if v is ORIG]
def install(fn):
 for m,k in references:setattr(m,k,fn)
roots=[];samples=[];start=time.perf_counter();rows=[]
for case in ['standard_shogi',2026101844]:
 if isinstance(case,str):rules=build_builtin_ruleset(case);c=compile_ruleset_for_execution(rules);seed=2026101841
 else:
  g=p.generate_game(p.GeneratorConfig(seed=case,board_size=12,setup_preset='bilateral_random',allow_hybrid=True));rules=g.ruleset;c0=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);seed=case
 s=p.GameSession(c);rng=random.Random(seed+14000)
 for _ in range(8):
  acts=sorted(s.legal_actions(),key=repr)
  if not acts or s.result.status.value!='ongoing':break
  s.submit(rng.choice(acts))
 samples.append(dict(case=case,ruleset=json.loads(p.serialize_ruleset(rules)),state=record_value(s.state),witnesses=record_value(s._search_witnesses)));roots.append((case,c,s))
write_record(out/'samples.json',samples)
try:
 for case,c,s in roots:
  before=s.to_record()
  for seconds in [4,16,64]:
   for rep in range(2):
    for arm in (['before','candidate'] if rep==0 else ['candidate','before']):
     p.rr.stopped();assert time.perf_counter()-start<1000;install(ORIG if arm=='before' else NEW);player=AlphaBetaPlayer(c,use_disk_cache=False);t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
     assert before==s.to_record();child=s.state
     for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
     rows.append(dict(case=case,seconds=seconds,rep=rep,arm=arm,wall=wall,actual_provider=player.native_legality_provider is not None,decision=record_value(d),history_restored=True,pv_core_legal=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(case,seconds,rep,arm,round(wall,4),d.completed_depth,d.nodes,d.score,flush=True)
finally:install(ORIG)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
