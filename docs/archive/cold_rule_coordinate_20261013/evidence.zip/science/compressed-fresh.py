from pathlib import Path
import sys,json,time,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core import semantic_executor as se
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/cold-rule-20261013');out=D/'compressed-fresh';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does the prefix-free static schedule preserve new full-rule Core callers across q0/q4 and metadata boundaries?',seeds=[2026101951,2026101952,2026101953,2026101954],sizes=[18,18,20,20],prefix=8,rng_offset=15000,backend='Core explicit, Nativeboard>16 unavailable retained',q_depth=[0,4],depths=[2,1],node_limit=256,seconds=8,orders=2,arms=['before','candidate'],planned_calls=32,requested_seconds=256,fuse_seconds=600,index_row_cap=262144,structural_memory_limit_bytes=64*1024*1024,no_resample=True,scope='Newdevelopment scope, not universal/unexposedvalidation; nativecap unchanged. Compare fullnon-time/work when same termination; retain exact partials/caps/unsupported instead ofextend. Full promotion/drop/aux/history domain preserved; no evaluatorpolicy/default/memorycap changes.'))
OLD=se.SemanticEngine.is_square_attacked;ns=dict(se.__dict__);ns.update(OLD=OLD,se=se);exec((D/'compressed-probe.py').read_text(),ns);build=ns['build'];candidate=ns['candidate'];start=time.perf_counter();rows=[];samples=[];unavailable=[]
def structural(x,seen):
 if id(x) in seen:return 0
 seen.add(id(x));n=sys.getsizeof(x)
 if isinstance(x,dict):n+=sum(structural(k,seen)+structural(v,seen) for k,v in x.items())
 elif isinstance(x,(tuple,list,set,frozenset)):n+=sum(structural(v,seen) for v in x)
 return n
try:
 for seed,size in zip([2026101951,2026101952,2026101953,2026101954],[18,18,20,20]):
  se.SemanticEngine.is_square_attacked=OLD;p.rr.stopped();assert time.perf_counter()-start<600
  g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(seed+15000);walk=[]
  try:
   for _ in range(8):
    acts=sorted(s.legal_actions(),key=repr)
    if not acts or s.result.status.value!='ongoing':raise ValueError('prefix unavailable')
    a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
   if s.result.status.value!='ongoing':raise ValueError('rootterminal')
   t=time.perf_counter();groups,count=build(c.ir,size*size);build_seconds=time.perf_counter()-t;bytes_used=structural(groups,set())
   if groups is None or bytes_used>64*1024*1024:raise ValueError('compressed static cap unavailable')
  except (ValueError,RuntimeError,NotImplementedError) as e:unavailable.append(dict(seed=seed,error_type=type(e).__name__,error=str(e),unexecuted_cells=8,resampled=False));write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable));continue
  samples.append(dict(seed=seed,size=size,ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk,compressed_rows=count,structural_bytes=bytes_used,build_seconds=build_seconds,original_index_present=c._incoming_attack_paths is not None));write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable));ns.update(c=c,groups=groups);before=s.to_record()
  for q,depth in [(0,2),(4,1)]:
   for rep in range(2):
    for arm in (['before','candidate'] if rep==0 else ['candidate','before']):
     p.rr.stopped();assert time.perf_counter()-start<600;se.SemanticEngine.is_square_attacked=OLD if arm=='before' else candidate;player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False);t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=256,max_time_seconds=8,quiescence_max_depth=q,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
     assert before==s.to_record();child=s.state
     for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
     rows.append(dict(seed=seed,size=size,q=q,rep=rep,arm=arm,wall=wall,decision=record_value(d),actual_provider=player.native_legality_provider is not None,history_restored=True,pv_core_legal=True));write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable));print(seed,q,rep,arm,round(wall,4),d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
finally:se.SemanticEngine.is_square_attacked=OLD
