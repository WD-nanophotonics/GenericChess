from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core import semantic_executor as se
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/cold-rule-20261013');out=D/'compressed-incoming';start=time.perf_counter();g=p.generate_game(p.GeneratorConfig(seed=2026101944,board_size=20,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);before=s.to_record();OLD=se.SemanticEngine.is_square_attacked

def build(ir,area):
 groups={};rank=0
 for owner in (0,1):
  for pattern in ir.patterns:
   if pattern.target.kind!='target_enemy':continue
   for tid in pattern.type_ids:
    for source in range(area):
     for gid in pattern.geometry_ids:
      geom=ir.geometry.get(gid)
      if geom is None or geom.kind=='drop' or geom.atom_source is not None and geom.atom_source[0]!=tid:continue
      path=geom.paths.get(str(owner),{}).get(source,())
      endpoints=range(min(1,len(path))) if geom.kind=='leap' else range(max(0,(geom.min_steps or 1)-1),len(path))
      for endpoint in endpoints:
       rank+=1
       if rank>262144:return None,rank
       groups.setdefault((str(owner),path[endpoint]),{}).setdefault(source,{}).setdefault(tid,[]).append((rank,pattern,gid,endpoint))
 return {key:{source:{tid:tuple(rows) for tid,rows in typed.items()} for source,typed in sources.items()} for key,sources in groups.items()},rank

t=time.perf_counter();groups,count=build(c.ir,400);build_seconds=time.perf_counter()-t;seen=set()
def size(x):
 if id(x) in seen:return 0
 seen.add(id(x));n=sys.getsizeof(x)
 if isinstance(x,dict):n+=sum(size(k)+size(v) for k,v in x.items())
 elif isinstance(x,(tuple,list,set,frozenset)):n+=sum(map(size,x))
 return n
structural=size(groups);setup=dict(rows=count,present=groups is not None,build_seconds=build_seconds,structural_bytes=structural,size_scope='dict/sequence/scalar structural retained sizes, sharedids once; borrowed dataclass payloads not descended; not RSS/wholeheap',production_cap_unchanged=True);write_record(out/'resource-setup.json',setup);print(setup,flush=True)
if groups is None or structural>64*1024*1024:write_record(out/'resource-rows.json',dict(complete=True,rows=[],unavailable='row or structural memory cap',resampled=False));raise SystemExit(0)

def candidate(self,position,square,by_owner,checkpoint=None):
 self._ensure_match(position)
 if self.semantic is not c:return OLD(self,position,square,by_owner,checkpoint)
 se._checkpoint(checkpoint);selected=[];owner_key=str(by_owner)
 for source,typed in groups.get((owner_key,square),{}).items():
  se._checkpoint(checkpoint);piece=position.board[source]
  if piece is not None and piece.owner==by_owner:
   selected.extend((rank,pattern,source,piece.current_type_id,gid,endpoint) for rank,pattern,gid,endpoint in typed.get(piece.current_type_id,()))
 selected.sort(key=lambda row:row[0])
 for rank,pattern,source,tid,gid,endpoint in selected:
  se._checkpoint(checkpoint);piece=position.board[source];geom=self.ir.geometry[gid]
  path=() if geom.kind=='leap' else tuple(geom.paths[owner_key][source][:endpoint])
  binding=self._make_binding(pattern,gid,tid,piece,source,square,None,path,position)
  if self._path_holds(pattern.path,position,binding,by_owner,checkpoint=checkpoint) and self._guards_hold(pattern,position,binding,by_owner,checkpoint=checkpoint):return True
 return False

write_record(out/'resource-sample.json',dict(ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),witnesses=record_value(s._search_witnesses)))
engine=se.SemanticEngine(c)
try:
 se.SemanticEngine.is_square_attacked=OLD;expected=[engine.is_square_attacked(s.state.position,target,owner) for owner in (0,1) for target in range(400)];actions=engine.legal_actions(s.state.position)
 se.SemanticEngine.is_square_attacked=candidate;observed=[engine.is_square_attacked(s.state.position,target,owner) for owner in (0,1) for target in range(400)];assert expected==observed;assert actions==engine.legal_actions(s.state.position)
 for method in [OLD,candidate]:
  se.SemanticEngine.is_square_attacked=method
  def stop():raise InterruptedError('entry cancel')
  try:engine.is_square_attacked(s.state.position,0,0,stop)
  except InterruptedError:pass
  else:raise AssertionError('missed cancel')
 write_record(out/'resource-finite.json',dict(paired_targets=800,actual_target_queries=1600,complete_frontier_equal=True,legal_count=len(actions),entry_cancel_both=True))
 rows=[]
 for seconds in [16,64]:
  for rep in range(2):
   for arm in (['before','candidate'] if rep==0 else ['candidate','before']):
    p.rr.stopped();assert time.perf_counter()-start<500;se.SemanticEngine.is_square_attacked=OLD if arm=='before' else candidate;player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False);t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    assert before==s.to_record();child=s.state
    for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
    rows.append(dict(seconds=seconds,rep=rep,arm=arm,wall=wall,decision=record_value(d),actual_provider=player.native_legality_provider is not None,history_restored=True,pv_core_legal=True));write_record(out/'resource-rows.json',dict(complete=False,rows=rows));print(seconds,rep,arm,round(wall,3),d.completed_depth,d.nodes,d.score,d.termination_reason,flush=True)
 write_record(out/'resource-rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:se.SemanticEngine.is_square_attacked=OLD
