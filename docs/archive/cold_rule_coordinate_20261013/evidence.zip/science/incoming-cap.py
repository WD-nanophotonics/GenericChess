from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.ir import _incoming_attack_paths,_incoming_attack_sources
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/cold-rule-20261013');out=D/'incoming-cap';assert not(out/'rows.json').exists();start=time.perf_counter();g=p.generate_game(p.GeneratorConfig(seed=2026101944,board_size=20,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);old=(c._incoming_attack_paths,c._incoming_attack_sources);assert old==(None,None)
t=time.perf_counter();index=_incoming_attack_paths(c.ir,400,max_paths=131072);source=_incoming_attack_sources(index);build=time.perf_counter()-t
seen=set()
def size(x):
 if id(x) in seen:return 0
 seen.add(id(x));total=sys.getsizeof(x)
 if isinstance(x,dict):total+=sum(size(k)+size(v) for k,v in x.items())
 elif isinstance(x,(tuple,list,set,frozenset)):total+=sum(map(size,x))
 return total
bytes_used=size((index,source));summary=dict(expanded_present=index is not None,build_seconds=build,structural_bytes=bytes_used,unique_objects=len(seen),size_scope='Recursive dict/sequence/scalar structural sizes; shared ids once; borrowed dataclass payloads not descended, not RSS or incremental complete heap.',rows=None if index is None else sum(map(len,index.values())))
write_record(out/'setup.json',summary);print(summary,flush=True)
if index is None or bytes_used>64*1024*1024:
 write_record(out/'rows.json',dict(complete=True,rows=[],unavailable='cap or structural memory limit',resampled=False));raise SystemExit(0)
def install(arm):
 a,b=old if arm=='before' else (index,source);object.__setattr__(c,'_incoming_attack_paths',a);object.__setattr__(c,'_incoming_attack_sources',b)
s=p.GameSession(c);before=s.to_record();engine=SemanticEngine(c)
try:
 install('before');reference=[engine.is_square_attacked(s.state.position,target,owner) for owner in (0,1) for target in range(400)];legal_reference=engine.legal_actions(s.state.position)
 install('candidate');assert reference==[engine.is_square_attacked(s.state.position,target,owner) for owner in (0,1) for target in range(400)];assert legal_reference==engine.legal_actions(s.state.position)
 for arm in ['before','candidate']:
  install(arm)
  def stop():raise InterruptedError('entry cancel')
  try:engine.is_square_attacked(s.state.position,0,0,stop)
  except InterruptedError:pass
  else:raise AssertionError('missed entry cancellation')
 write_record(out/'finite.json',dict(target_queries=1600,paired_targets=800,complete_frontier_equal=True,legal_count=len(legal_reference),entry_cancel_both=True,all_exact=True))
 rows=[]
 for rep in range(2):
  for arm in (['before','candidate'] if rep==0 else ['candidate','before']):
   p.rr.stopped();assert time.perf_counter()-start<500;install(arm);player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False);t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=4096,max_time_seconds=64,quiescence_max_depth=0,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
   assert before==s.to_record();child=s.state
   for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
   rows.append(dict(arm=arm,rep=rep,wall=wall,decision=record_value(d),actual_provider=player.native_legality_provider is not None,history_restored=True,pv_core_legal=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(rep,arm,round(wall,4),d.completed_depth,d.nodes,d.score,d.termination_reason,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:object.__setattr__(c,'_incoming_attack_paths',old[0]);object.__setattr__(c,'_incoming_attack_sources',old[1])
