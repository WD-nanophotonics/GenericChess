from pathlib import Path
import sys,json,time,random,types
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core import coordinates as co
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/cold-rule-20261013');out=D/'coordinate-cost';out.mkdir(exist_ok=True);assert not (out/'rows.json').exists()
ORIG=co.square_to_index;ns=dict(co.__dict__);exec((D/'candidate-coordinate.py').read_text(),ns);NEW=ns['square_to_index']
references=[(m,k) for name,m in list(sys.modules.items()) if name.startswith('generic_chess') and m for k,v in list(vars(m).items()) if v is ORIG]
def install(fn):
 for m,k in references:setattr(m,k,fn)
start=time.perf_counter();rows=[];roots=[]
for seed,depth,size in [(2026101841,3,8),(2026101842,3,8),(2026101843,4,12),(2026101844,4,12)]:
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(seed+14000)
 for _ in range(8):
  acts=sorted(s.legal_actions(),key=repr)
  if not acts or s.result.status.value!='ongoing':break
  s.submit(rng.choice(acts))
 roots.append((seed,depth,c,s))
try:
 for seed,depth,c,s in roots:
  before=s.to_record()
  for rep in range(2):
   for arm in (['before','candidate'] if rep==0 else ['candidate','before']):
    p.rr.stopped();assert time.perf_counter()-start<1200;install(ORIG if arm=='before' else NEW);player=AlphaBetaPlayer(c,use_disk_cache=False);t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=None,max_time_seconds=64,quiescence_max_depth=0,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    assert before==s.to_record();child=s.state
    for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
    rows.append(dict(seed=seed,depth=depth,rep=rep,arm=arm,wall=wall,actual_provider=player.native_legality_provider is not None,decision=record_value(d),history_restored=True,pv_core_legal=True));write_record(out/'rows.json',dict(complete=False,rows=rows));print(seed,rep,arm,round(wall,6),d.completed_depth,d.nodes,d.score,flush=True)
finally:install(ORIG)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start,patched_reference_count=len(references)))
