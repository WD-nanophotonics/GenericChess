from pathlib import Path
import sys,json,time,random,cProfile,pstats
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/cold-rule-20261013');out=D/'consumer-profile';out.mkdir(exist_ok=True)
assert not (out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Which current-default primitive dominates12-board fresh search after setup is separated?',seeds=[2026101843,2026101844],board_size=12,prefix=8,rng_offset=14000,backend=[False,True],q=0,max_depth=4,seconds=64,max_nodes=None,calls=4,fuse_seconds=320,scope='cProfile changes timing and may change budget completion. This is cost attribution, not speed or matched-work equivalence; keep full state/PV/history and actual backend. Default geometric evaluator authority retained, no semantic-evaluator substitution.'))
start=time.perf_counter();rows=[]
for seed in [2026101843,2026101844]:
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=12,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(seed+14000)
 for _ in range(8):
  acts=sorted(s.legal_actions(),key=repr)
  if not acts or s.result.status.value!='ongoing':break
  s.submit(rng.choice(acts))
 for backend in [False,True]:
  p.rr.stopped();assert time.perf_counter()-start<320;before=s.to_record();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=backend);prof=cProfile.Profile();t=time.perf_counter()
  prof.enable()
  try:d=player.choose_action(s,SearchLimits(max_depth=4,max_time_seconds=64,max_nodes=None,quiescence_max_depth=0,quiescence_hard_max_depth=8))
  finally:prof.disable()
  wall=time.perf_counter()-t;assert before==s.to_record();child=s.state
  for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
  stats=pstats.Stats(prof);entries=[]
  for (file,line,name),(cc,nc,tt,ct,callers) in stats.stats.items():
   if 'generic_chess' in file:
    entries.append(dict(file=file[file.index('generic_chess'):].replace('\\','/'),line=line,name=name,primitive_calls=cc,total_calls=nc,tottime=tt,cumtime=ct))
  entries.sort(key=lambda x:x['tottime'],reverse=True)
  rows.append(dict(seed=seed,requested_native=backend,actual_provider=player.native_legality_provider is not None,wall=wall,decision=record_value(d),profile_entries=entries,history_restored=True,pv_core_legal=True))
  write_record(out/'rows.json',dict(complete=False,rows=rows));print(seed,backend,wall,d.completed_depth,d.nodes,d.score,entries[:5],flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
