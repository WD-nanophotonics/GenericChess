def square_to_index(sq, n):
    if type(n) is int and n > 0:
        return sq.rank * n + sq.file
    return sq.rank * _shape(n).width + sq.file
