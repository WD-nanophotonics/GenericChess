from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from generic_chess.core import semantic_executor as se
from scripts.research_record import write_record
D=Path('.local_agent/cold-rule-20261013');assert not(D/'static-memory-plan.json').exists();write_record(D/'static-memory-plan.json',dict(question='Is fallback-only static integration a better memory/compile choice than replacing small already-indexed rules?',cases=[(2026101841,8),(2026101843,12),(2026101951,18),(2026101953,20)],search_calls=0,size_scope='Recursive structural dict/sequence/scalar ownership proxy, sharedids counted once, borrowed dataclass payloads not descended; notRSS or wholeheap/peak. Do not claim originalNone=zero totalrulesmemory.',decision='Use observed old and prefix-free structure/build cost to choose fallback-only test plan, no new productionfield/cap.'))
ns=dict(se.__dict__);ns.update(se=se,OLD=se.SemanticEngine.is_square_attacked);exec((D/'compressed-probe.py').read_text(),ns);rows=[]
def size(x,seen):
 if id(x) in seen:return 0
 seen.add(id(x));total=sys.getsizeof(x)
 if isinstance(x,dict):total+=sum(size(k,seen)+size(v,seen) for k,v in x.items())
 elif isinstance(x,(tuple,list,set,frozenset)):total+=sum(size(v,seen) for v in x)
 return total
for seed,n in [(2026101841,8),(2026101843,12),(2026101951,18),(2026101953,20)]:
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);t=time.perf_counter();groups,count=ns['build'](c.ir,n*n);dt=time.perf_counter()-t;rows.append(dict(seed=seed,size=n,original_index_present=c._incoming_attack_paths is not None,old_structure_bytes=size((c._incoming_attack_paths,c._incoming_attack_sources),set()),compressed_structure_bytes=size(groups,set()),compressed_rows=count,compressed_build_seconds=dt));print(rows[-1])
write_record(D/'static-memory-results.json',dict(search_calls=0,rows=rows,prototype_only=True,size_scope='Same recursive structure proxy as declaration, not RSS/wholeheap/peak.'))
