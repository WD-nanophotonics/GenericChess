from pathlib import Path
import sys,json,time,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core import coordinates as co
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
D=Path('.local_agent/cold-rule-20261013');out=D/'coordinate-fresh';out.mkdir(exist_ok=True);assert not (out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does exact integer coordinate conversion preserve fresh whole-rule callers through Core/Native and q0/q4?',seeds=list(range(2026101851,2026101855)),sizes=[8,8,12,12],prefix=8,rng_offset=14000,backend=[False,True],q_depth=[0,4],main_depth=[2,1],seconds=8,max_nodes=2000,hardq=8,orders=2,arms=['before','candidate'],planned_calls=64,requested_seconds_upper_bound=512,fuse_seconds=850,scope='New-development generator cohort, no universal/unexposed validation claim; full semantics/history/evaluator preserved. Retain unavailable/terminal/timecap; exact-work claim only for matched non-time decisions, capped completion tuples reported separately. No resampling or budget extension.'))
ORIG=co.square_to_index;ns=dict(co.__dict__);exec((D/'candidate-coordinate.py').read_text(),ns);NEW=ns['square_to_index'];refs=[(m,k) for name,m in list(sys.modules.items()) if name.startswith('generic_chess') and m for k,v in list(vars(m).items()) if v is ORIG]
def install(fn):
 for m,k in refs:setattr(m,k,fn)
start=time.perf_counter();rows=[];samples=[];unavailable=[];roots=[]
for seed in range(2026101851,2026101855):
 try:
  g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8 if seed<=2026101852 else 12,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(seed+14000);walk=[]
  for _ in range(8):
   acts=sorted(s.legal_actions(),key=repr)
   if not acts or s.result.status.value!='ongoing':raise ValueError('prefix unavailable')
   a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
  if s.result.status.value!='ongoing':raise ValueError('terminalroot')
  samples.append(dict(seed=seed,ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk));roots.append((seed,c,s))
 except (ValueError,RuntimeError,NotImplementedError) as e:unavailable.append(dict(seed=seed,error_type=type(e).__name__,error=str(e),unexecuted_cells=16,resampled=False))
write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable))
try:
 for seed,c,s in roots:
  before=s.to_record()
  for native in [False,True]:
   for q,depth in [(0,2),(4,1)]:
    for rep in range(2):
     for arm in (['before','candidate'] if rep==0 else ['candidate','before']):
      p.rr.stopped();assert time.perf_counter()-start<850;install(ORIG if arm=='before' else NEW);player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=native);t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=2000,max_time_seconds=8,quiescence_max_depth=q,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
      assert before==s.to_record();child=s.state
      for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
      rows.append(dict(seed=seed,native_requested=native,actual_provider=player.native_legality_provider is not None,q=q,depth_requested=depth,rep=rep,arm=arm,wall=wall,decision=record_value(d),history_restored=True,pv_core_legal=True));write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable));print(seed,native,q,rep,arm,round(wall,4),d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
finally:install(ORIG)
write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
