"""Exact declared behavior change on the frozen finite Shogi census."""
import json, hashlib, time
from pathlib import Path
from fractions import Fraction as F
p=Path(__file__).parent; src=p.parent/'transfer-time-20261008/shogi-goal-service-qualified.json'
out=p/'policy.json'; assert not out.exists(); start=time.perf_counter()
raw=json.loads(src.read_bytes()); assert raw['complete']
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),declaration='Declared before execution: same three frozen actual-history Shogi cells, same legal drop/reply census, no new population or simulation. Compare uniform legal tag drops to rule-terminal-first (uniform among immediate owner0 wins if any, otherwise uniform drops); opponent chooses uniformly among replies minimizing terminal-normalized C=win-loss+U/81, versus old uniform replies. Retain separate win/loss/draw/ongoing and activity components, all tied replies, exact rational weights. Scalar is an explicit uncalibrated convention, not material utility or full-game WDL. Unknown: does the previous G/P order survive an elementary behavior change, or does terminal saturation remove price discrimination? This changes one joint behavior law, not default player settings; no human-label fit. One10sec checkpoint, cheap reuse of verified finite outcomes.',cases=[])
def vector(terminal,U):
    ongoing=terminal['status']=='ongoing'; winner=terminal['winner']
    return dict(U=F(U) if ongoing else F(0),win=F(not ongoing and winner==0),loss=F(not ongoing and winner==1),draw=F(not ongoing and winner is None),ongoing=F(ongoing))
def scalar(v):return v['win']-v['loss']+v['U']/81
def average(vectors):return {k:sum((v[k] for v in vectors),F(0))/len(vectors) for k in vectors[0]}
for c in raw['cases']:
    rows=[]
    for d in c['drops']:
        ts=d['immediate_terminal']
        leaves=[vector(ts,0)] if ts['status']!='ongoing' else [vector(x['terminal'],x['U']) for x in d['replies']]
        minimum=min(map(scalar,leaves)); worst=[v for v in leaves if scalar(v)==minimum]
        rows.append(dict(action=d['drop'],immediate_win=ts['status']!='ongoing' and ts['winner']==0,uniform=average(leaves),min_reply=average(worst),reply_count=len(leaves),min_ties=len(worst)))
    wins=[d for d in rows if d['immediate_win']]; policies=[]
    for own in ('uniform','terminal_first'):
        selected=(wins or rows) if own=='terminal_first' else rows
        for opp in ('uniform','min_reply'):
            v=average([d[opp] for d in selected]); assert sum(v[k] for k in ('win','loss','draw','ongoing'))==1
            policies.append(dict(drop_policy=own,reply_policy=opp,selected_drops=len(selected),vector={k:str(x) for k,x in v.items()},C=str(scalar(v))))
    r['cases'].append(dict(target=c['target'],pawn_drop_mate_filter=c['pawn_drop_mate_filter'],legal_drops=len(rows),immediate_wins=len(wins),policies=policies,reply_tie_counts=[dict(action=d['action'],replies=d['reply_count'],min_ties=d['min_ties']) for d in rows]))
    assert time.perf_counter()-start<10
r.update(complete=True,seconds=time.perf_counter()-start)
out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
for c in r['cases']:
    print(c['target'],c['pawn_drop_mate_filter'],c['policies'])
