"""Matched finite enemy-promotion context intervention, not a player patch."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction as F
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'rook-context.json';assert not out.exists()
source=ROOT/'.local_agent/paired-context-20261008/rook-pressure.json'
original=next(x for x in json.loads(source.read_bytes())['cases'] if x['target']=='TP')
start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       dependency_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
       declaration='Changed premise, not an extension of the cost-limited8root census: two matched declared initial rules, ownK1,1/N3,2/enemyTP(baseP)4,4/R8,2/K8,8. Only enemyR currentR/false versusTR/true differs; same actual Ncapture then exact3transition service, uniform ordinary actions/priority uniqueP legaldrop. Layout taken from FIRST observed T3P prefix; exposed synthetic intervention, not representative sampling or historical causality. Unknown: does opponent promotion state change a fixed-time service kernel enough to require conditioning? Exact H3 plus first-reply promotion multiplicity/drop counts; no fitting or new default. Every node legal/state/terminal Core/Native parity. One240sec interruptible checkpoint; retain partial and no automatic extension.',cases=[],nodes=0,transitions=0)
write_record(out,r)
def checked(s,np,c,nr):
    assert time.perf_counter()-start<240,'matched context cost checkpoint'
    actions=legal_actions(s,c);nas=guarded_actions(nr,np)
    assert set(actions)=={public_action(nr,a) for a in nas}
    nt=terminal_status(nr,np)
    assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner)
    assert snapshot_matches(snapshot(nr,np),s.position,nr,c)
    r['nodes']+=1
    return actions,{public_action(nr,a):a for a in nas}
def advance(s,np,a,packed,c,nr):
    child=apply_action(s,a,c);native=make_checked(nr,np,packed)
    assert snapshot_matches(snapshot(nr,native),child.position,nr,c)
    r['transitions']+=1
    return child,native
def value(s,np,depth,c,nr):
    actions,packed=checked(s,np,c,nr)
    if s.terminal_status.is_terminal:return F(0)
    tag=[i for i,x in enumerate(s.position.board) if x is not None and x.base_type_id=='P']
    assert len(tag)+sum(h.count('P') for h in s.position.hands)==1
    if depth==0:
        return F(len({(a.to_square.file,a.to_square.rank) for a in actions
            if tag and s.position.board[tag[0]].owner==0 and hasattr(a,'from_square')
            and a.from_square.file+9*a.from_square.rank==tag[0]}))
    pool=[a for a in actions if getattr(a,'base_type_id',None)=='P'] or list(actions)
    return sum((value(*advance(s,np,a,packed[a],c,nr),depth-1,c,nr) for a in pool),F(0))/len(pool)
try:
    for promoted in (False,True):
        definition=ruleset_from_dict(original['definition'])
        board=[[None]*9 for _ in range(9)]
        for f,rank,piece in ((1,1,Piece(0,'K','K')),(3,2,Piece(0,'N','N')),
            (4,4,Piece(1,'P','TP',True)),(8,2,Piece(1,'R','TR' if promoted else 'R',promoted)),(8,8,Piece(1,'K','K'))):board[rank][f]=piece
        definition=replace(definition,initial_position=tuple(map(tuple,board)))
        c=compile_ruleset_for_execution(definition);nr=compile_native_semantic_rules(c);s=initial_state(c)
        np=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True).position
        actions,packed=checked(s,np,c,nr)
        capture,=[a for a in actions if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==(3,2) and (a.to_square.file,a.to_square.rank)==(4,4)]
        s,np=advance(s,np,capture,packed[capture],c,nr)
        replies,repacked=checked(s,np,c,nr)
        case=dict(enemy_promoted=promoted,definition=ruleset_to_dict(definition),capture=record_value(capture),
                  first_replies=len(replies),promoting_replies=sum(a.promotion_target_id is not None for a in replies),
                  first_reply_destinations=len({(a.from_square.file,a.from_square.rank,a.to_square.file,a.to_square.rank) for a in replies}),complete=False)
        r['cases'].append(case);write_record(out,r)
        t=time.perf_counter();v=value(s,np,3,c,nr)
        case.update(complete=True,H3=str(v),seconds=time.perf_counter()-t)
        write_record(out,r);print(promoted,case['first_replies'],case['promoting_replies'],v,flush=True)
    r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
