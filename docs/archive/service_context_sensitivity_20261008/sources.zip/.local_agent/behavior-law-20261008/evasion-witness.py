"""Explain a zero H3 service reply with an actual short recovery route."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'evasion-witness.json';assert not out.exists()
source=p/'rook-context.json';frozen=json.loads(source.read_bytes())
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       dependency_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
       declaration='Decision-changing mechanism check, not a new horizon sample: both fixed R/TR layouts, actual forced Ncapture, enemy rook8,2-to1,2 (nonpromoting variant where available), own King captures it, lexical enemy King reply, own Pdrop3,3, lexical enemy King reply. Check whether zero H3 is delayed deployment after forced evasion rather than permanent P unavailability. Full legal/state/terminal Core/Native parity. Report a witness only, not expectedH5, optimal play, material value or mean correction. No search/fit/new population.',cases=[])
for cell in frozen['cases']:
    c=compile_ruleset_for_execution(ruleset_from_dict(cell['definition']));nr=compile_native_semantic_rules(c);s=initial_state(c)
    np=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True).position
    row=dict(enemy_promoted=cell['enemy_promoted'],route=[],nodes=[]);r['cases'].append(row)
    for step in range(7):
        actions=legal_actions(s,c);nas=guarded_actions(nr,np);packed={public_action(nr,a):a for a in nas}
        assert set(actions)==set(packed)
        nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner)
        assert snapshot_matches(snapshot(nr,np),s.position,nr,c)
        tag=[i for i,x in enumerate(s.position.board) if x is not None and x.base_type_id=='P']
        U=len({(a.to_square.file,a.to_square.rank) for a in actions if tag and s.position.board[tag[0]].owner==0
            and hasattr(a,'from_square') and a.from_square.file+9*a.from_square.rank==tag[0]}) if s.position.side_to_move==0 else None
        row['nodes'].append(dict(step_from_initial=step,steps_after_capture=step-1,
            side=s.position.side_to_move,U=U,tag_location='board' if tag else 'hand',
            legal_P_drops=sum(getattr(a,'base_type_id',None)=='P' for a in actions),terminal=record_value(s.terminal_status)))
        if step==6:break
        if step==0:a,=[a for a in actions if record_value(a)==cell['capture']]
        elif step==1:a,=[a for a in actions if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==(8,2)
            and (a.to_square.file,a.to_square.rank)==(1,2) and a.promotion_target_id is None]
        elif step==2:a,=[a for a in actions if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==(1,1)
            and (a.to_square.file,a.to_square.rank)==(1,2)]
        elif step==4:a,=[a for a in actions if getattr(a,'base_type_id',None)=='P' and (a.to_square.file,a.to_square.rank)==(3,3)]
        else:a=sorted(actions,key=lambda a:json.dumps(record_value(a),sort_keys=True))[0]
        np=make_checked(nr,np,packed[a]);s=apply_action(s,a,c);row['route'].append(record_value(a))
    assert row['nodes'][4]['U']==0 and row['nodes'][4]['tag_location']=='hand'
    assert row['nodes'][6]['U']==1 and row['nodes'][6]['tag_location']=='board'
r['complete']=True;write_record(out,r)
print([(x['enemy_promoted'],[(n['steps_after_capture'],n['U'],n['tag_location']) for n in x['nodes'] if n['steps_after_capture'] in (3,5)]) for x in r['cases']])
