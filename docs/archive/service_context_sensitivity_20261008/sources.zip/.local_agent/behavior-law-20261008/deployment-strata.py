"""Postdeclared timing diagnostic of frozen outer paths, not a fitted kernel."""
import json,hashlib
from pathlib import Path
from collections import Counter
p=Path(__file__).parent;source=p.parent/'transfer-time-20261008/horizon10.json';out=p/'deployment-strata.json';assert not out.exists()
raw=json.loads(source.read_bytes());assert raw['complete']
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       dependency_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
       declaration='Declared before parsing this decomposition: first owner0 tagged-base dropD is the first recorded baseG/P drop on an even-index actor0 turn, after first transferT. Unique tag and action histories were verified by original producer. Count W=D-T, no deployment and final U contributions; do not regress/fit a same-sample kernel or call an identity predictive validation. Exposed postdeclared localization only, no causal or holdout claim. Tests whether delayed deployment is frequent enough to motivate a cheap context state instead of unlimited geometry kernels.',cases=[])
for cell in raw['cases']:
    tid='G' if cell['target']=='G' else 'P';rows=[]
    for e in cell['episodes']:
        D=next((i+1 for i,a in enumerate(e['route']) if i%2==0 and a.get('base_type_id')==tid),None)
        if D is not None:assert e['T'] is not None and D>=e['T']+2
        assert D is not None or e['U']==0
        rows.append(dict(T=e['T'],D=D,W=None if D is None else D-e['T'],U=e['U']))
    values=sorted({x['W'] for x in rows if x['W'] is not None})
    summary=[]
    for W in [None,*values]:
        selected=[x for x in rows if x['W']==W]
        if not selected:continue
        summary.append(dict(W=W,n=len(selected),positive_U=sum(x['U']>0 for x in selected),
                            total_U=sum(x['U'] for x in selected),mean_U=sum(x['U'] for x in selected)/len(selected)))
    r['cases'].append(dict(context=cell['context'],target=cell['target'],N=len(rows),
        transfer_no_deploy=sum(x['T'] is not None and x['D'] is None for x in rows),
        no_transfer=sum(x['T'] is None for x in rows),
        later_than_two=sum(x['W'] is not None and x['W']>2 for x in rows),
        deployment_times=dict(Counter(str(x['D']) for x in rows)),strata=summary))
out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps(r['cases'],indent=2))
