"""Exact three-transition continuation in preselected actual delayed contexts."""
import sys, json, time, hashlib
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record

p=Path(__file__).parent;out=p/'delayed-context.json';assert not out.exists()
old=ROOT/'.local_agent/paired-context-20261008'
paths=[ROOT/'.local_agent/transfer-time-20261008/horizon10.json',old/'rook-pressure.json',old/'joint-context.json']
outer,source0,source1=[json.loads(x.read_bytes()) for x in paths]
start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       dependencies={str(x.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(x.read_bytes()).hexdigest() for x in paths},
       declaration='Prospective finite context counterexample: for each frozen context0/1 and G/TP outer cell choose FIRST stored episode with T3 and FIRST with T5, before reading any continuation payoff. Reconstruct only its authentic prefix through capture. Enumerate exactly3 further actual transitions using the existing uniform ordinary / priority unique-tag legal-drop policy. Compare to initial-capture exactH3 with SAME remaining horizon, not to delayed fixed-node10 U or a fitted kernel. Full Core/Native action/state/terminal parity at every visited node; exact rational branch weights, terminal U0.8preselected delayed roots; one300sec interruptible development checkpoint, no automatic extension. Outcomes decide whether postcapture context can be collapsed solely by remaining time; selected exposed witnesses are not population means, causal attribution or material utility. Save partials and all outcomes.',
       selected=[],cases=[],transitions=0,nodes=0,legal_queries=0,terminal_queries=0,complete_roots=0)
for oc in outer['cases']:
    for T in (3,5):
        e=next(e for e in oc['episodes'] if e['T']==T)
        r['selected'].append(dict(context=oc['context'],target=oc['target'],T=T,seed=e['seed'],prefix=e['route'][:T],baseline_H3=oc['frozen_H']))
write_record(out,r)

def checked(s,np,c,nr):
    assert time.perf_counter()-start<300,'context census cost checkpoint'
    nas=guarded_actions(nr,np);actions=legal_actions(s,c);r['legal_queries']+=1
    assert set(actions)=={public_action(nr,x) for x in nas}
    nt=terminal_status(nr,np);r['terminal_queries']+=1
    assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner)
    assert snapshot_matches(snapshot(nr,np),s.position,nr,c)
    return actions,{public_action(nr,x):x for x in nas}

def advance(s,np,a,packed,c,nr):
    child=apply_action(s,a,c);native=make_checked(nr,np,packed)
    assert snapshot_matches(snapshot(nr,native),child.position,nr,c)
    r['transitions']+=1
    return child,native

def census(s,np,depth,tid,c,nr):
    actions,packed=checked(s,np,c,nr);r['nodes']+=1
    if s.terminal_status.is_terminal:return F(0)
    tag=[i for i,piece in enumerate(s.position.board) if piece is not None and piece.base_type_id==tid]
    assert len(tag)+sum(h.count(tid) for h in s.position.hands)==1
    if depth==0:
        if not tag or s.position.board[tag[0]].owner!=0 or s.position.side_to_move!=0:return F(0)
        return F(len({(a.to_square.file,a.to_square.rank) for a in actions
                      if hasattr(a,'from_square') and a.from_square.file+9*a.from_square.rank==tag[0]}))
    drops=[a for a in actions if getattr(a,'base_type_id',None)==tid]
    pool=drops or list(actions)
    assert pool
    value=F(0)
    for a in pool:
        child,native=advance(s,np,a,packed[a],c,nr)
        value+=census(child,native,depth-1,tid,c,nr)
    return value/len(pool)

try:
    for selected in r['selected']:
        source=(source0,source1)[selected['context']]
        original=next(x for x in source['cases'] if x['target']==selected['target'])
        c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']))
        nr=compile_native_semantic_rules(c);s=initial_state(c)
        np=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True).position
        for wanted in selected['prefix']:
            actions,packed=checked(s,np,c,nr)
            a,=[a for a in actions if record_value(a)==wanted]
            s,np=advance(s,np,a,packed[a],c,nr)
        tid='G' if selected['target']=='G' else 'P'
        assert s.position.hands[0].count(tid)==1
        t=time.perf_counter();before=r['transitions']
        result=census(s,np,3,tid,c,nr)
        row=dict(**selected,H3=str(result),baseline_difference=str(result-F(selected['baseline_H3'])),
                 postcapture_board=record_value(s.position.board),postcapture_hands=record_value(s.position.hands),
                 transitions=r['transitions']-before,seconds=time.perf_counter()-t)
        r['cases'].append(row);r['complete_roots']+=1
        write_record(out,r)
        print(selected['context'],selected['target'],selected['T'],result,'baseline',selected['baseline_H3'],flush=True)
    r['complete']=True
finally:
    r['seconds']=time.perf_counter()-start;write_record(out,r)
