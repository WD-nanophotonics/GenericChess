"""Freeze a separate response-policy probe without rewriting earlier evidence."""
from pathlib import Path
p=Path(__file__).parent
source=(p/'rook-context.py').read_text(encoding='utf-8')
source=source.replace("out=p/'rook-context.json'", "out=p/'rook-reply-policy.json'")
old="Unknown: does opponent promotion state change a fixed-time service kernel enough to require conditioning? Exact H3 plus first-reply promotion multiplicity/drop counts; no fitting or new default."
new="New decision question: does uniform public-action counting versus uniform first-reply source/target destinations (uniform promotion variant within each destination), or first reply minimizing exact subsequentH2, change this service kernel? Re-enumerate the two fixed trees to retain conditional first-reply values missing from the prior aggregate; assert original action-uniformH3 reproduces exactly. These are declared response laws for endpoint service, not WDL/rational optimal play. All first-reply conditional values retained, no outcome-selected law or fitted price."
assert old in source
source=source.replace(old,new)
old="""        t=time.perf_counter();v=value(s,np,3,c,nr)
        case.update(complete=True,H3=str(v),seconds=time.perf_counter()-t)"""
new="""        t=time.perf_counter();conditional=[];groups={}
        for reply in replies:
            child,native=advance(s,np,reply,repacked[reply],c,nr)
            v=value(child,native,2,c,nr)
            key=(reply.from_square.file,reply.from_square.rank,reply.to_square.file,reply.to_square.rank)
            groups.setdefault(key,[]).append(v)
            conditional.append(dict(reply=record_value(reply),H2=str(v)))
        uniform=sum((F(x['H2']) for x in conditional),F(0))/len(conditional)
        destination=sum((sum(v,F(0))/len(v) for v in groups.values()),F(0))/len(groups)
        minimum=min(F(x['H2']) for x in conditional)
        previous=json.loads((p/'rook-context.json').read_bytes())
        expected=next(x['H3'] for x in previous['cases'] if x['enemy_promoted']==promoted)
        assert uniform==F(expected)
        case.update(complete=True,H3=str(uniform),destination_uniform=str(destination),
                    minimum_reply_H2=str(minimum),minimum_ties=sum(F(x['H2'])==minimum for x in conditional),
                    conditional=conditional,old_exact_H3_equal=True,seconds=time.perf_counter()-t)"""
assert old in source
source=source.replace(old,new)
assert not (p/'rook-reply-policy.py').exists()
(p/'rook-reply-policy.py').write_text(source,encoding='utf-8',newline='\n')
