"""Actual legal capture/drop prefix from initial full-stock Standard Shogi."""
import sys,json,time
from pathlib import Path
from fractions import Fraction as F
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.core.transition import initial_state,legal_successors,apply_action
from generic_chess.core.actions import action_is_drop
from generic_chess.core.coordinates import Square
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.shogi_full_affine_inventory import FullAffineInventory,BASES
from scripts.shogi_static_inventory import quantize
from scripts.shogi_exact_contact_family import exact_board_means
from scripts.resource_mode_context import resource_ledger
from scripts.research_record import record_value,write_record
p=ROOT/'.local_agent/activity-games-20261007';out=p/'shogi-neighbors.json';assert not out.exists()
report=dict(question='Does the existing orderedTTq setting give usable q0/q2 decisions on neighboring reachable pre-drop/Gold/Rook-reply roots?',scope='Constructed legal cooperative prefix with Pawn-protected checking Bishop drop; not representative game/holdout/WDL. One common approximate held-half law, no strength promotion.',prefix_plan=[[19,28],[54,45],[28,37],[45,36],[37,46],[36,27],[46,55],[27,18],[55,64],[18,9],[21,30],[9,0,'TP'],[30,39],[62,53],[39,48],[53,44],[48,57],[44,35],['B',66]],prefix=[],models=[],complete=False,resource_continuation='Original failures remain. Twelve equal2ply4096node20sec controls: q0/q2, geometric/unit, lexical/noTT versus ordering+TT versus ordering+TT+orderedq. At most240sec plus setup. Inert classification wrapper counts candidates/actual pushes; no semantics or coefficient change.')
write_record(out,report)
c=compile_ruleset_for_execution(build_standard_shogi_ruleset());s=initial_state(c);witness=[s.position];trail=[s]
sq=lambda index:Square(index%9,index//9)
for item in report['prefix_plan']:
 a,b=item[:2];promotion=item[2] if len(item)==3 else None
 children=list(legal_successors(s,c))
 if isinstance(a,str):matches=[(x,y) for x,y in children if action_is_drop(x) and x.base_type_id==a and x.to_square==sq(b)]
 else:matches=[(x,y) for x,y in children if not action_is_drop(x) and getattr(x,'from_square',None)==sq(a) and getattr(x,'to_square',None)==sq(b) and getattr(x,'promotion_target_id',None)==promotion]
 assert len(matches)==1,(a,b,[str(x) for x,_ in children]);x,child=matches[0];assert child==apply_action(s,x,c)
 resource_ledger(c,child.position,'shogi');s=child;witness.append(s.position);trail.append(s);report['prefix'].append(str(x));write_record(out,report)
assert semantic_engine_for(c).in_check(s.position,s.position.side_to_move)
choices=list(legal_successors(s,c))
assert not any(getattr(x,'from_square',None)==sq(76) and getattr(x,'to_square',None)==sq(66) for x,_ in choices)
assert any(getattr(x,'from_square',None)==sq(75) and getattr(x,'to_square',None)==sq(66) for x,_ in choices)
report.update(root=record_value(s),history_plies=len(witness)-1,legal_actions=len(list(legal_successors(s,c))))
class Point:
 def __init__(self,w):self.affine=FullAffineInventory(c,w);self.held={base:quantize(F(1,2)*w[base]) for base in BASES};self.calls=0
 def capture_order_value(self,moving_piece,captured_piece):return 990000
 def evaluate(self,state):
  row=self.affine.row(state);v=row[0]+sum(row[i+1]*self.held[k] for i,k in enumerate(BASES));self.calls+=1;return v if state.position.side_to_move==0 else -v
m=exact_board_means('geometric_half');weights={k:v/m['TR'] for k,v in m.items()}
import generic_chess.ai.alphabeta.search as search_module
original_classify=search_module._runtime_noisy_actions
classify={}
def measured_classify(ctx,actions):
 actions=list(actions);push=ctx.runtime.pushes;t=time.perf_counter();classify['calls']+=1;classify['candidates']+=len(actions)
 try:
  result=original_classify(ctx,actions);classify['selected']+=len(result);return result
 finally:
  classify['pushes']+=ctx.runtime.pushes-push;classify['seconds']+=time.perf_counter()-t
search_module._runtime_noisy_actions=measured_classify
neighbors=[('pre_drop18',trail[-2],tuple(witness[:-1]))]
for label,source in [('gold_reply20',75),('rook_reply20',70)]:
 matches=[(a,y) for a,y in choices if getattr(a,'from_square',None)==sq(source) and getattr(a,'to_square',None)==sq(66) and getattr(a,'promotion_target_id',None) is None]
 assert len(matches)==1,(label,[str(a) for a,y in matches]);a,child=matches[0];resource_ledger(c,child.position,'shogi')
 neighbors.append((label,child,tuple(witness+[child.position])))
report['neighbor_plan']='Exactly pre-drop18 and Gold d9xd8/Rook h8xd8 replies20; existing orderedTTq/q0/q2, geometric/unit, same2ply4096node20sec per cell.12cells at most240sec plus setup. Preserve partial/adverse, no extension/default/strength claim.'
report['neighbors']=[dict(label=k,state=record_value(r),history_plies=len(w)-1) for k,r,w in neighbors];write_record(out,report)
for label,root,root_witness in neighbors:
 config='ordered_tt_q';order=tt=orderedq=True
 for q in (0,2):
  for policy,w in [('geometric_half',weights),('unit',{k:F(1) for k in weights})]:
   e=Point(w);limits=SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=20,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=4096)
   stats=SearchStatistics();classify=dict(calls=0,candidates=0,selected=0,pushes=0,seconds=0.);t=time.perf_counter()
   tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=q==0,use_capture_only_qsearch=q==2,use_ordered_qsearch=orderedq)
   action,score,pv,reason=run_root_search(root,c,e,TranspositionTable(),limits,None,stats,use_tt=tt,use_ordering=order,tuning=tuning,_history_witnesses=tuple(root_witness))
   child=apply_action(root,action,c);resource_ledger(c,child.position,'shogi');rt=SearchPathRuntime.from_state(root,c,history_witnesses=tuple(root_witness))
   with rt.pushed(action):assert rt.position==child.position
   rt.assert_balanced();report['models'].append(dict(root_label=label,root_legal_count=len(list(legal_successors(root,c))),config=config,classification=dict(classify),qdepth=q,policy=policy,selected=str(action),score=score,pv=[str(a) for a in pv],reason=reason,statistics=asdict(stats),seconds=time.perf_counter()-t,evaluations=e.calls));write_record(out,report)
   print(label,config,q,policy,str(action),score,reason,stats.completed_depth,flush=True)
report['complete']=True;write_record(out,report);print('legal prefix',len(report['prefix']),'choices',report['legal_actions'],flush=True)
