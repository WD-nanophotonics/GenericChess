from pathlib import Path
import json,collections,time
P=Path('.local_agent/s4-storage-20261016');d=json.loads((P/'cancel-results.json').read_bytes());rows=d['rows'];summary={}
for board in(4,8,12,16):
 z=[r for r in rows if r['board']==board]
 summary[board]={'queries':len(z),'cancel_phase':dict(collections.Counter(r.get('cancel_phase')for r in z)),'termination':dict(collections.Counter(r['result']['termination_reason']for r in z)),'depths':[r['result']['completed_depth']for r in z],'max_ready_after_cancel':max(r['ready_after_cancel']or 0 for r in z),'max_caller_seconds':max(r['caller_seconds']for r in z),'pv_edges':sum(len(r['pv_edges'])for r in z)}
summary['scope']='12 fresh legacy-lowered mixture rules,96actualacquisitionplies; no claimed allgeneratedaux/S4 coverage, no hard cancel guarantee. Kernel/packing/JSON and scheduling phases separate.'
summary['fallback_first_two_candidates']={'candidates':34,'both_legal':True,'first_two':[144186046496572951,144186046496576035],'meaning':'fail_after2 occurs after one verifiedlegalfallback candidate; NativeoldBoolean path skipped failed candidate and stillreturnedanotheraction'}
(P/'analysis.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
