import importlib.util,json,hashlib
from pathlib import Path

def pytest_configure(config):
 import generic_chess.native as native
 path=Path(__file__).resolve().parent/'_native_core.cp312-win_amd64.pyd'
 spec=importlib.util.spec_from_file_location('isolated_qualification._native_core',path)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 native._MODULE=module
 (path.parent/'full-override-receipt.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'scope':'Only defaultNative module overridden in this pytestprocess. Tests that explicitly build or select anotherbackend retainthatbehavior. Existing source-built faultfixtures readnormalproductC, NOT thisprototype; this doesnotqualify isolatedleafrequired-errorbehavior.'},indent=2),encoding='utf8')
