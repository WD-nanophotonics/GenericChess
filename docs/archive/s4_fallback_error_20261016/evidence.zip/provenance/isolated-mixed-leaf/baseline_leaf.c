static int gc_semantic_probe_material(
    const GCSemanticRules *rules,
    const GCSemanticPosition *position,
    const GCSemanticProbeProfile *profile,
    const int *dynamic_features) {
    int64_t score = 0;
    int cached_dynamic[3];
    const int *compact_dynamic = dynamic_features;
    for (uint16_t sq = 0; sq < rules->board_size * rules->board_size; sq++) {
        const GCPiece *piece = &position->board[sq];
        if (!piece->occupied) continue;
        int64_t value = profile && profile->supplied ? profile->board[piece->current_type] : (int)piece->current_type + 1;
        score += piece->owner == position->side_to_move ? value : -value;
        if (profile && profile->spatial_supplied) {
            uint16_t rank = sq / rules->board_size;
            uint16_t file = sq % rules->board_size;
            uint16_t cell_rank = (uint16_t)((rank * 3) / rules->board_size);
            uint16_t cell_file = (uint16_t)((file * 3) / rules->board_size);
            if (cell_rank > 2) cell_rank = 2;
            if (cell_file > 2) cell_file = 2;
            int64_t spatial = profile->spatial[piece->owner][piece->current_type][cell_rank * 3 + cell_file];
            score += (position->side_to_move == 0 ? 1 : -1) *
                (piece->owner == 0 ? spatial : -spatial);
        }
    }
    for (uint8_t owner = 0; owner < 2; owner++) {
        for (uint16_t type = 0; type < rules->type_count; type++) {
            int64_t value = profile && profile->supplied ? profile->hand[type] : (int)type + 1;
            int64_t hand_score = (int)position->hand_counts[owner][type] * value;
            score += owner == position->side_to_move ? hand_score : -hand_score;
        }
    }
    /* A supplied zero vector is a neutral term, not a request to enumerate
     * dynamic features at every leaf. Returned leaf metadata is separate. */
    if (profile && profile->dynamic_supplied &&
        (profile->dynamic[0] || profile->dynamic[1] || profile->dynamic[2])) {
        int features[3] = {0, 0, 0};
        /* The vector is owner-0 minus owner-1; leaf scores are always from
         * the side-to-move perspective, matching the material terms above. */
        if (dynamic_features != NULL) {
            memcpy(features, dynamic_features, sizeof(features));
        } else if (!gc_semantic_dynamic_feature_vector(rules, position, features)) {
            return GC_SEMANTIC_EVAL_ERROR;
        }
        for (int i = 0; i < 3; i++) {
            score += (position->side_to_move == 0 ? 1 : -1) *
                (int64_t)profile->dynamic[i] * features[i];
        }
        memcpy(cached_dynamic, features, sizeof(cached_dynamic));
        compact_dynamic = cached_dynamic;
    }
    if (profile && profile->localized_control_supplied) {
        int features[GC_SEMANTIC_SPATIAL_CELLS] = {0};
        /* Local control is residualized against each owner's total action
         * count, so its nine cells do not duplicate global mobility. */
        int counts[2][GC_SEMANTIC_SPATIAL_CELLS] = {{0}};
        int totals[2] = {0, 0};
        for (uint8_t owner = 0; owner < 2; owner++) {
            GCSemanticPosition view = *position;
            view.side_to_move = owner;
            GCSemanticActionBuffer actions;
            gc_semantic_action_buffer_init(&actions);
            if (!gc_semantic_generate_candidate_buffer(rules, &view, &actions)) {
                gc_semantic_action_buffer_free(&actions);
                return GC_SEMANTIC_EVAL_ERROR;
            }
            for (size_t i = 0; i < actions.count; i++) {
                uint64_t raw = actions.data[i];
                if (raw == 0 || (raw >> 63) != 0) continue;
                GCSemanticPosition child;
                /* Only status and the raw target are consumed. Retain the full parent
                 * history and S4 checks; this trial child is never searched. */
                int status = gc_semantic_runtime_make_material_view_status(
                    &child, rules, &view, raw);
                if (status < 0) {
                    gc_semantic_action_buffer_free(&actions);
                    return GC_SEMANTIC_EVAL_ERROR;
                }
                if (!status) continue;
                uint16_t target = (uint16_t)(raw & 0xFFu);
                uint16_t rank = target / rules->board_size;
                uint16_t file = target % rules->board_size;
                uint16_t cell_rank = (uint16_t)((rank * 3) / rules->board_size);
                uint16_t cell_file = (uint16_t)((file * 3) / rules->board_size);
                if (cell_rank > 2) cell_rank = 2;
                if (cell_file > 2) cell_file = 2;
                counts[owner][cell_rank * 3 + cell_file]++;
                totals[owner]++;
            }
            gc_semantic_action_buffer_free(&actions);
        }
        for (int cell = 0; cell < GC_SEMANTIC_SPATIAL_CELLS; cell++) {
            features[cell] = 9 * (counts[0][cell] - counts[1][cell]) -
                (totals[0] - totals[1]);
            score += (position->side_to_move == 0 ? 1 : -1) *
                (int64_t)profile->localized_control[cell] * features[cell];
        }
    }
    if (profile && profile->compact) {
        double residual = 0.0;
        if (gc_semantic_compact_residual(
                rules, position, profile, compact_dynamic, &residual)) {
            /* Compact targets use the checkpoint's human-value units, just
             * like the Python training residual.  Convert back to Native's
             * fixed-point score units with the semantic evaluator scale. */
            int64_t fixed_residual = (int64_t)llround(
                residual * (double)profile->evaluator_scale);
            score += profile->compact->perspective == 1
                ? -fixed_residual
                : (position->side_to_move == 0 ? fixed_residual : -fixed_residual);
        } else {
            return GC_SEMANTIC_EVAL_ERROR;
        }
    }
    if (score > GC_SEMANTIC_STATIC_LIMIT) return GC_SEMANTIC_STATIC_LIMIT;
    if (score < -GC_SEMANTIC_STATIC_LIMIT) return -GC_SEMANTIC_STATIC_LIMIT;
    return (int)score;
}

