from pathlib import Path
from dataclasses import replace
import sys,json,time,random,traceback,importlib.util
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];P=R/'.local_agent/s4-storage-20261016';D=P/'isolated-mixed-leaf'
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,generate_game,GeneratorConfig,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.core.transition import apply_action
plan=json.loads((D/'transfer-plan.json').read_bytes());spec=importlib.util.spec_from_file_location('isolated_transfer._native_core',D/'_native_core.cp312-win_amd64.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);start=time.perf_counter();roots=[];out=[]
def stop():
 for name in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 assert time.perf_counter()-start<600
with(D/'transfer-queries.jsonl').open('x',encoding='utf8')as log:
 for index,case in enumerate(plan['cases']):
  stop();root=dict(case);roots.append(root);t=time.perf_counter()
  try:
   g=generate_game(GeneratorConfig(seed=case['seed'],board_size=case['board'],setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));rule=replace(g.ruleset,max_ply=2048);x=compile_legacy_ruleset_for_semantic_execution(rule);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c);rng=random.Random(case['seed']+700000)
   for _ in range(8):
    if s.state.terminal_status.is_terminal:break
    aa=sorted(s.legal_actions(),key=repr)
    if not aa:break
    s.submit(rng.choice(aa))
   root.update(record=json.loads(serialize_game_record(s.to_record())),ruleset=json.loads(serialize_ruleset(rule)),state=record_value(s.state),actual_ply=s.state.ply_count,acquisition_seconds=time.perf_counter()-t)
   if s.state.terminal_status.is_terminal or s.state.ply_count<8:root['kind']='ACTUAL_TERMINAL_TAIL';continue
   root['kind']='ACTUAL_ONGOING';v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()};root['board_values']=bv;root['hand_values']=hv;t=time.perf_counter();ns={arm:compile_native_semantic_rules(c,**({'backend_module':m}if arm=='isolated'else{}))for arm in plan['arms']};root['native_compile_seconds']=time.perf_counter()-t
   for profile in plan['profiles']:
    for rep in range(2):
     pair=[]
     for arm in plan['arms']if(index+rep)%2==0 else list(reversed(plan['arms'])):
      stop();z=dict(**case,profile=profile,rep=rep,arm=arm);t=time.perf_counter()
      try:
       e=SemanticSearchEngine(c,ns[arm],board_values=bv,hand_values=hv,dynamic_values=(2,3,5)if profile in('dynamic235','mixed235control9')else None,localized_control_values=(1,0,0,0,0,0,0,0,-1)if profile in('control9','mixed235control9')else None,tt_megabytes=0,ordering_cache_enabled=False);constructed=time.perf_counter();r=e.search(s,SearchLimits(max_depth=4,max_nodes=16384,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);returned=time.perf_counter();value=record_value(r);json.dumps(value);ready=time.perf_counter();state=s.state;edges=[]
       for a in r.principal_variation:state=apply_action(state,a,c);edges.append({'action':record_value(a),'state':record_value(state)})
       assert record_value(s.state)==root['state'];z.update(kind='ACTUAL_QUERY',result=value,constructor_seconds=constructed-t,search_caller_seconds=returned-constructed,conversion_seconds=ready-returned,ready_seconds=ready-t,pv_edges=edges)
      except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
      out.append(z);pair.append(z);log.write(json.dumps(z)+'\n');log.flush();print(case['seed'],profile,rep,arm,z['kind'],z.get('result',{}).get('completed_depth'),round(time.perf_counter()-start,1),flush=True)
     if all(z['kind']=='ACTUAL_QUERY'and z['result']['termination_reason']!='time_budget'for z in pair):assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
  except Exception as exc:root.update(kind='ACTUAL_ROOT_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
  (D/'transfer-progress.json').write_text(json.dumps({'roots_completed':len(roots),'queries':len(out),'seconds':time.perf_counter()-start}),encoding='utf8')
(D/'transfer-results.json').write_text(json.dumps({'plan':plan,'roots':roots,'rows':out,'planned_slots':256,'actual_queries':sum(z['kind']=='ACTUAL_QUERY'for z in out),'seconds':time.perf_counter()-start},indent=2),encoding='utf8');print('DONE',len(out),time.perf_counter()-start,flush=True)
