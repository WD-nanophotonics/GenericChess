from pathlib import Path
import json,math,statistics,collections,hashlib
P=Path('.local_agent/s4-storage-20261016');D=P/'isolated-mixed-leaf';d=json.loads((D/'transfer-results.json').read_bytes());rows=d['rows'];assert d['actual_queries']==len(rows)==224 and all(z['kind']=='ACTUAL_QUERY'for z in rows)
summary={'planned_slots':256,'actual_queries':224,'missing_slots':32,'actual_tails':[{'seed':z['seed'],'actual_ply':z['actual_ply'],'terminal':z['state']['terminal_status']}for z in d['roots']if z['kind']=='ACTUAL_TERMINAL_TAIL'],'acquisition_edges':sum(z.get('actual_ply',0)for z in d['roots']),'seconds':d['seconds'],'profiles':{},'fixed_work_pairs':0,'joint_requested_d4_pairs':0,'candidate_only_requested_d4_pairs':0,'baseline_only_requested_d4_pairs':0,'scope':'Fresh16family prospectivecostpanel; tails notresampled. Callerreadinessincludesconstructor+publicfields+JSON. Ratios conditionon matchedfixedwork, notstrength, WDL or harddeadline. All individualratios andcensors retained.'}
for profile in d['plan']['profiles']:
 out={'by_board':{},'pairs':[]}
 for board in(4,8,12,16):
  fixed=[];joint=only=old=neither=0;ratios_by_seed=collections.defaultdict(list)
  for seed in[z['seed']for z in d['roots']if z['board']==board and z['kind']=='ACTUAL_ONGOING']:
   for rep in(0,1):
    pair={z['arm']:z for z in rows if z['seed']==seed and z['profile']==profile and z['rep']==rep};assert len(pair)==2
    a,b=pair['baseline'],pair['isolated'];same={k:v for k,v in a['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in b['result'].items()if k!='elapsed_seconds'};matched=all(z['result']['termination_reason']!='time_budget'for z in pair.values())
    if matched:
     assert same;summary['fixed_work_pairs']+=1;ratio=b['ready_seconds']/a['ready_seconds'];fixed.append(ratio);ratios_by_seed[seed].append(ratio)
    ad=a['result']['completed_depth']==4;bd=b['result']['completed_depth']==4
    joint+=ad and bd;only+=(bd and not ad);old+=(ad and not bd);neither+=(not ad and not bd)
    out['pairs'].append({'seed':seed,'board':board,'rep':rep,'matched_fixed_work':matched,'all_non_time_equal':same,'baseline_depth':a['result']['completed_depth'],'isolated_depth':b['result']['completed_depth'],'ready_ratio':b['ready_seconds']/a['ready_seconds'],'kernel_ratio':b['result']['elapsed_seconds']/a['result']['elapsed_seconds']if a['result']['elapsed_seconds'] else None,'baseline_reason':a['result']['termination_reason'],'isolated_reason':b['result']['termination_reason']})
  values=[statistics.median(v)for v in ratios_by_seed.values()]
  out['by_board'][board]={'family_count':len(ratios_by_seed),'matched_fixed_pairs':len(fixed),'family_median_ready_ratio':statistics.median(values)if values else None,'max_individual_fixed_ratio':max(fixed)if fixed else None,'joint_d4':joint,'isolated_only_d4':only,'baseline_only_d4':old,'neither_d4':neither}
  summary['joint_requested_d4_pairs']+=joint;summary['candidate_only_requested_d4_pairs']+=only;summary['baseline_only_requested_d4_pairs']+=old
 summary['profiles'][profile]=out
(D/'transfer-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in summary.items()if k!='profiles'},indent=2));print(json.dumps({k:v['by_board']for k,v in summary['profiles'].items()},indent=2))
# Preserve actual attribution and feasibility sources, not only favorable summaries.
a=json.loads((P/'key-attribution/results.json').read_bytes());pairs=[]
for seed in a['plan']['roots']:
 for profile in a['plan']['profiles']:
  pair={z['arm']:z for z in a['rows']if z['seed']==seed and z['profile']==profile};x=pair['timer_only'];t=x['result']['elapsed_seconds'];fixed=all(z['result']['termination_reason']!='time_budget'for z in pair.values());same={k:v for k,v in pair['normal']['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in x['result'].items()if k!='elapsed_seconds'}
  if fixed:assert same
  pairs.append({'seed':seed,'profile':profile,'matched_fixed_work':fixed,'all_non_time_equal':same,'key_calls':x['metrics']['kernel_key_profile'][0],'key_ns':x['metrics']['kernel_key_profile'][1],'key_share':x['metrics']['kernel_key_profile'][1]/1e9/t,'profiled_kernel_seconds':t})
(P/'key-attribution/summary.json').write_text(json.dumps({'pairs':pairs,'matched_fixed_pairs':sum(z['matched_fixed_work']for z in pairs),'new_product_key_changes':False},indent=2),encoding='utf8')
