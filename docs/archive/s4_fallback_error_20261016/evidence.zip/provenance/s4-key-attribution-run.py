from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];P=R/'.local_agent/s4-storage-20261016';D=P/'key-attribution'
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
plan=json.loads((D/'plan.json').read_bytes());root_data=json.loads((P/'cancel-results.json').read_bytes());roots={r['seed']:r for r in root_data['roots']};spec=importlib.util.spec_from_file_location('key_profile._native_core',D/'_native_core.cp312-win_amd64.pyd');profile=importlib.util.module_from_spec(spec);spec.loader.exec_module(profile);rows=[];start=time.perf_counter()
for seed in plan['roots']:
 z=roots[seed];x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));assert record_value(s.state)==z['initial']
 for kind in plan['profiles']:
  for arm in plan['arms']if (seed+int(kind=='static'))%2==0 else list(reversed(plan['arms'])):
   for name in('rollout','advisor','slack'):
    flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
   assert time.perf_counter()-start<120
   n=compile_native_semantic_rules(c,**({'backend_module':profile}if arm=='timer_only'else{}));e=SemanticSearchEngine(c,n,board_values=z['board_values'],hand_values=z['hand_values'],dynamic_values=(2,3,5)if kind!='static'else None,localized_control_values=(1,0,0,0,0,0,0,0,-1)if kind!='static'else None,tt_megabytes=0,ordering_cache_enabled=False)
   original=n.backend_module.semantic_engine_search;metrics={}
   def observed(*args):
    if arm=='timer_only':profile.key_profile(True)
    t=time.perf_counter()
    try:return original(*args)
    finally:
     metrics['kernel_boundary_seconds']=time.perf_counter()-t
     if arm=='timer_only':metrics['kernel_key_profile']=profile.key_profile(True)
   n.backend_module.semantic_engine_search=observed
   try:t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-t
   finally:n.backend_module.semantic_engine_search=original
   metrics['outside_kernel_key_profile']=profile.key_profile(True)if arm=='timer_only'else None
   state=s.state;edges=[]
   for a in r.principal_variation:state=apply_action(state,a,c);edges.append({'action':record_value(a),'state':record_value(state)})
   rows.append({'seed':seed,'profile':kind,'arm':arm,'result':record_value(r),'caller_seconds':elapsed,'metrics':metrics,'pv_edges':edges});assert record_value(s.state)==z['initial'];print(seed,kind,arm,r.completed_depth,metrics,flush=True)
(D/'results.json').write_text(json.dumps({'plan':plan,'rows':rows,'seconds':time.perf_counter()-start},indent=2),encoding='utf8')
