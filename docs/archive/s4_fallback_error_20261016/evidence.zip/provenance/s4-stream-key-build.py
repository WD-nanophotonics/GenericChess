from pathlib import Path
import json,subprocess,sys,sysconfig,os,time
R=Path.cwd();P=R/'.local_agent/s4-storage-20261016';D=P/'stream-key';D.mkdir(exist_ok=False);S=R/'generic_chess/_native'
plan={'question':'Can bounded SHA staging remove canonicalJSON heap buffering while preserving exact required identities at useful total cost?','changed_premise':'Private attribution shows key fraction about46/54/41/36percent in static4/8/12/16; mixed about12/2.8/1.7/1.1percent. Thus not a solution to wide dynamic starvation. Earlier empty-cell coalescing remains rejected; this distinct staging prototype leaves every literal JSON emission unchanged and never drops history or digest execution.','buffer_bytes':512,'pilot_roots':[124401,124801,125201,125601],'profiles':['static','mixed235control9'],'repetitions':2,'arms':['baseline','staged'],'depth':3,'nodes':8192,'seconds':3,'whole_seconds':180,'expected_seconds':40,'decision':'Only if fixed-work non-timefields match and static geometricmean <=.97 with no compelling mixed regression proceed to a separately frozen fresh transfer and exactbyte checks; otherwise keep prototype private. Censored pairs excluded from speed ratios, retained as data.','scope':'Exposed-root feasibility, not fresh validation, no model/price/q/TT/result-schema/arrays/API change. Internal allocation strategy changes; external required digest failures must still propagate.'}
(D/'plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
k=(S/'native_semantic_key.c').read_text();start=k.index('typedef struct { char *data;');end=k.index('static void sb_lit(',start)
k=k[:start]+'''/* Private prototype: bounded staging, same canonical byte stream. */
typedef struct { uint8_t data[512]; size_t len; int ok; GCSha256 sha; } GCSemBuf;
static void sb_init(GCSemBuf *b) { b->len=0; b->ok=1; gc_sha256_init(&b->sha); }
static void sb_raw(GCSemBuf *b,const char *s,size_t n) {
    if (!b->ok) return;
    while (n) {
        size_t space=sizeof(b->data)-b->len;
        size_t take=n<space?n:space;
        memcpy(b->data+b->len,s,take);b->len+=take;s+=take;n-=take;
        if (b->len==sizeof(b->data)) {
            gc_sha256_update(&b->sha,b->data,b->len);b->len=0;
        }
    }
}
'''+k[end:]
a='if(!b.ok){free(b.data);return 0;} GCSha256 sha;uint8_t digest[32];gc_sha256_init(&sha);gc_sha256_update(&sha,(const uint8_t*)b.data,b.len);gc_sha256_final(&sha,digest);gc_sha256_hex(digest,out_hex);free(b.data);return 1;'
b='if(!b.ok)return 0; uint8_t digest[32];gc_sha256_update(&b.sha,b.data,b.len);gc_sha256_final(&b.sha,digest);gc_sha256_hex(digest,out_hex);return 1;'
assert k.count(a)==1;k=k.replace(a,b);(D/'native_semantic_key.c').write_bytes(k.encode())
zig=R/'.venv/Lib/site-packages/ziglang/zig.exe';binary=D/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));command=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(D/p.name if p.name=='native_semantic_key.c'else p)for p in sorted(S.glob('*.c'))]+['-o',str(binary)]
t=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(D/'zig-cache')));(D/'build.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'stderr':r.stderr},indent=2),encoding='utf8');assert r.returncode==0,r.stderr;print('BUILT',time.perf_counter()-t)
