from pathlib import Path
import sys,json,time
from dataclasses import replace,asdict
R=Path.cwd(); P=R/'.local_agent/s4-storage-20261016'; P.mkdir(exist_ok=True)
sys.path.insert(0,str(R))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands
from generic_chess.core.transition import initial_state
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,transient_legal_actions_audit,snapshot,make_checked
from scripts.research_record import record_value
plan={'question':'Does S4 transient reply require storage minus one, separately from rule horizon?','scope':'Imported Position-only, not reachable GameSession/history/WDL','rule_max_ply':2048,'plies':[1022,1023,1024],'whole_cap_seconds':60,'expected_seconds':5,'decision':'Keep conservative provider guard unless actual consumer benefit warrants a changed guard; no public API/array changes'}
(P/'plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
t=time.perf_counter(); rows=[[None]*9 for _ in range(9)];rows[0][4]=Piece(0,'K','K');rows[8][4]=Piece(1,'K','K')
c=compile_ruleset_for_execution(replace(build_builtin_ruleset('standard_shogi'),max_ply=2048,initial_position=tuple(map(tuple,rows))))
p=replace(initial_state(c).position,hands=(Hands((('P',1),)),Hands()))
e=semantic_engine_for(c); provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
b=time.perf_counter();expected=set(e.legal_actions(p));core_seconds=time.perf_counter()-b
out=[]
for ply in plan['plies']:
 assert time.perf_counter()-t<60
 z={'ply':ply,'supported':provider.supports_position(p,ply)}
 try:
  b=time.perf_counter(); pairs=provider(p,ply);z['native_seconds']=time.perf_counter()-b
  actions={x[1][0] for x in pairs};z['actions']=len(actions);z['equal_core']=actions==expected;z['missing']=[record_value(a) for a in expected-actions];z['extra']=[record_value(a) for a in actions-expected]
  packed=pack_position(provider.native_rules,provider._state_only_payload(p,ply));audit=transient_legal_actions_audit(provider.native_rules,packed);z['audit']=record_value(audit)
  z['checking_drop_present']=any(a.source is None and a.target==7*9+4 for a in actions)
 except Exception as exc:z['error']={'type':type(exc).__name__,'message':str(exc)}
 out.append(z)
r={'plan':plan,'core_actions':len(expected),'core_seconds':core_seconds,'rows':out,'seconds':time.perf_counter()-t,'source':{'reply_record_history':'!gc_runtime_transient','history_guard':'record_history && history_len>=1025','trial_rule_gate':'parent.ply >= rules.max_ply'}}
(P/'results.json').write_text(json.dumps(r,indent=2),encoding='utf8');print(json.dumps(r,indent=2))
