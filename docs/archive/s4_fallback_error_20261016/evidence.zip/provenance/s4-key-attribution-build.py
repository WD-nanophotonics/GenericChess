from pathlib import Path
import sys,json,time,os,subprocess,sysconfig,importlib.util
R=Path.cwd();P=R/'.local_agent/s4-storage-20261016';D=P/'key-attribution';D.mkdir(exist_ok=False);S=R/'generic_chess/_native'
plan={'question':'After delivered mechanical-feature savings, is REQUIRED canonical identity construction a material part of the remaining full search cost?','changed_premise':'Current3+9 leaf is cheaper and a new fallback defect confirms required identity failure must propagate. Earlier empty-cell serializer was rejected at near-one kernel cost; do not revive it. Attribute total key cost before any distinct allocator/serialization proposal.','roots':[124401,124801,125201,125601],'profiles':['static','mixed235control9'],'arms':['normal','timer_only'],'depth':3,'nodes':8192,'seconds':3,'max_queries':16,'whole_run_seconds':120,'expected_seconds':25,'decision':'If identity share is consistently below5percent, stop this route. A larger share only licenses one bounded exact-representation feasibility test, not adoption/cache/history omission.','scope':'Exposed roots from current cancellation cohort, not fresh transfer/playing-strength evidence. Private timer overhead and concurrentload limit attribution; do not sum nested components or interpretcensors as fixed-work parity.'}
(D/'plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
k=(S/'native_semantic_key.c').read_text();needle='int gc_semantic_position_key_digest(';assert k.count(needle)==1;k=k.replace(needle,'int gc_semantic_position_key_digest_impl(',1)
k='#include "native_clock.h"\n'+k+'''
uint64_t gc_key_calls=0, gc_key_ns=0;
int gc_semantic_position_key_digest(const GCSemanticRules *r,
    const GCSemanticPosition *p,char out[65]) {
 uint64_t start=gc_monotonic_ns();
 int status=gc_semantic_position_key_digest_impl(r,p,out);
 gc_key_calls++;gc_key_ns+=gc_monotonic_ns()-start;return status;
}
'''
m=(S/'native_module.c').read_text();i=m.index('static PyMethodDef');m=m[:i]+'''
static PyObject *gc_key_profile(PyObject *self,PyObject *args){
 (void)self;int reset=0;if(!PyArg_ParseTuple(args,"|p",&reset))return NULL;
 extern uint64_t gc_key_calls,gc_key_ns;
 PyObject *out=Py_BuildValue("(KK)",(unsigned long long)gc_key_calls,(unsigned long long)gc_key_ns);
 if(reset){gc_key_calls=0;gc_key_ns=0;}return out;
}
'''+m[i:]
needle='    {"semantic_make_checked", gc_semantic_make_checked, METH_VARARGS,';assert m.count(needle)==1;m=m.replace(needle,'    {"key_profile",gc_key_profile,METH_VARARGS,"Private attribution only"},\n'+needle)
(D/'native_module.c').write_bytes(m.encode());(D/'native_semantic_key.c').write_bytes(k.encode())
zig=R/'.venv/Lib/site-packages/ziglang/zig.exe';binary=D/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));command=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(D/p.name if p.name in('native_module.c','native_semantic_key.c')else p)for p in sorted(S.glob('*.c'))]+['-o',str(binary)]
t=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(D/'zig-cache')));(D/'build.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'stderr':r.stderr},indent=2),encoding='utf8');assert r.returncode==0,r.stderr;print('BUILT',time.perf_counter()-t)
