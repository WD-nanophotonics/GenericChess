from pathlib import Path
import sys,json,sysconfig,subprocess,os,time
R=Path.cwd();P=R/'.local_agent/s4-storage-20261016';D=P/'isolated-mixed-leaf';D.mkdir(exist_ok=False);S=R/'generic_chess/_native'
plan={'question':'Can isolating the entire fused3+9 leaf behind an active-feature dispatch preserve cheap baseline cost while retaining mixed savings?','changed_premise':'Current required-key attribution is large only forstatic;512byteSHA staging failed its preregistered staticcriterion1.0198, so that route isclosed. Prior3+9V2savedmixed work butregressedstaticwide and modifiedthe commonleaf body/frame. Prioroutline tested9only, not isolation ofthe entirefusedbody. This prototype keeps currentbaseleaf verbatim inaseparate function; only profiles withnonzero3 AND supplied9 AND noalreadyprovided3 use the privatefusedbody. No boardfamily choice.','roots':[124401,124801,125201,125601],'profiles':['static','dynamic235','control9','mixed235control9'],'repetitions':2,'arms':['baseline','isolated'],'depth':3,'nodes':512,'seconds':3,'whole_seconds':180,'expected_seconds':25,'decision':'Prototypeonly. Require every fixedwork non-timefield equal and inspect ALLprofile costs/adversity. If mixedsaving<10percent or nonmixed meaningfuladversity persists, reject; even favorable pilot cannot justify productadoption without freshtransfer and Core/S4/history/fault qualification. Added duplicatebodymaintenancecost counts againstit.','scope':'Read PRIMARY own unpublishedV2source as exact knownmechanism, not AUX. No newAPI/model/searchpolicy/default/capacity/history change. Keep product file untouched and all earlier prototypefailures immutable.'}
(D/'plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
current=(S/'native_module.c').read_text();old=(R/'.local_agent/local-control-20261016/coalesced-v2-source/native_module.c').read_text();a=current.index('static int gc_semantic_probe_material(');b=current.index('static int gc_semantic_dynamic_feature_vector(',a);base=current[a:b];oa=old.index('static int gc_semantic_probe_material(');ob=old.index('static int gc_semantic_dynamic_control_feature_vectors(',oa);oc=old.index('static int gc_semantic_dynamic_feature_vector(',ob);fused=old[oa:ob];helper=old[ob:oc]
# Keep the current baseline's body byte-identical, apart from its local symbol.
base=base.replace('static int gc_semantic_probe_material(','Py_NO_INLINE static int gc_semantic_probe_material_base(',1)
fused=fused.replace('static int gc_semantic_probe_material(','Py_NO_INLINE static int gc_semantic_probe_material_fused(',1)
helper=helper.replace('static int gc_semantic_dynamic_control_feature_vectors(','Py_NO_INLINE static int gc_semantic_dynamic_control_feature_vectors(',1)
wrapper='''static int gc_semantic_probe_material(
    const GCSemanticRules *rules,const GCSemanticPosition *position,
    const GCSemanticProbeProfile *profile,const int *dynamic_features) {
    if (profile && profile->dynamic_supplied && profile->localized_control_supplied &&
        (profile->dynamic[0] || profile->dynamic[1] || profile->dynamic[2]) &&
        dynamic_features == NULL)
        return gc_semantic_probe_material_fused(rules,position,profile,dynamic_features);
    return gc_semantic_probe_material_base(rules,position,profile,dynamic_features);
}

'''
m=current[:a]+base+helper+fused+wrapper+current[b:];(D/'native_module.c').write_bytes(m.encode());(D/'baseline_leaf.c').write_bytes(current[a:b].encode())
command=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(D/f.name if f.name=='native_module.c'else f)for f in sorted(S.glob('*.c'))]+['-o',str(D/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')))];t=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(D/'zig-cache')));(D/'build.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'stderr':r.stderr},indent=2),encoding='utf8');assert r.returncode==0,r.stderr;print('BUILT',time.perf_counter()-t)
