from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];P=R/'.local_agent/s4-storage-20261016'
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from scripts.research_record import record_value
binary=Path(sys.argv[1]);out=Path(sys.argv[2]);assert not out.exists()
spec=importlib.util.spec_from_file_location('fallback_repro._native_core',binary);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c)
for _ in range(2):s.submit(s.legal_actions()[0])
n=compile_native_semantic_rules(c,backend_module=m);initial=record_value(s.state);rows=[]
for kind in('cancel','nodes','time','depth_zero'):
 for after in(1,2):
  for window in(False,True):
   token=CancellationToken()
   if kind=='cancel':token.cancel()
   limits=SearchLimits(max_depth=0 if kind=='depth_zero' else 2,max_nodes=0 if kind=='nodes' else 10000,max_time_seconds=0 if kind=='time' else None,quiescence_max_depth=0,quiescence_hard_max_depth=0)
   m.test_set_fallback_fault(after)
   try:
    t=time.perf_counter();r=SemanticSearchEngine(c,n,tt_megabytes=1).search(s,limits,token,root_window_pruning=window);elapsed=time.perf_counter()-t;counts=m.test_fallback_count()
   finally:m.test_set_fallback_fault(0)
   rows.append({'stop':kind,'fault_after':after,'root_windows':window,'counts':counts,'result':record_value(r),'caller_seconds':elapsed});assert record_value(s.state)==initial
out.write_text(json.dumps({'binary_scope':'Private current-source build; only fallback-scoped real identity-digest failure injection','record':json.loads(serialize_game_record(s.to_record())),'initial':initial,'rows':rows},indent=2),encoding='utf8')
print([(z['stop'],z['fault_after'],z['root_windows'],z['result']['termination_reason'],z['result']['action'] is None,z['counts'])for z in rows])
