from pathlib import Path
import sys,json,time
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));P=R/'.local_agent/s4-storage-20261016'
from scripts.research_record import record_value
plan={'question':'Is UINT16 rule horizon admission a material new cost for an actual compile-once Native caller?','cases':[['western_chess',1024],['western_chess',2048],['standard_shogi',2048],['standard_shogi',1024]],'limits':{'max_depth':1,'max_nodes':1,'max_time_seconds':1},'whole_seconds':60,'scope':'Four fresh compiled rule objects, one persistent-engine call each; within-process cold rules, not cold OS imports; no speed statistics or existing deadline contract change'}
(P/'cold-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.session.session import GameSession
from generic_chess.ai.limits import SearchLimits
out=[];start=time.perf_counter()
for name,horizon in plan['cases']:
 assert time.perf_counter()-start<60
 t=time.perf_counter();c=compile_ruleset_for_execution(replace(build_builtin_ruleset(name),max_ply=horizon));semantic_compile=time.perf_counter()-t
 t=time.perf_counter();s=GameSession(c);session_seconds=time.perf_counter()-t
 t=time.perf_counter();n=compile_native_semantic_rules(c);native_compile=time.perf_counter()-t
 t=time.perf_counter();e=SemanticSearchEngine(c,n,tt_megabytes=0,ordering_cache_enabled=False);engine_seconds=time.perf_counter()-t
 # Instrument the actual imported packing symbol; this changes timing only.
 import generic_chess.native.semantic_engine as module
 original=module.pack_semantic_search_position;pack_times=[]
 def pack(*args,**kwargs):
  t=time.perf_counter();value=original(*args,**kwargs);pack_times.append(time.perf_counter()-t);return value
 module.pack_semantic_search_position=pack
 try:
  t=time.perf_counter();r=e.search(s,SearchLimits(**plan['limits']));caller_seconds=time.perf_counter()-t
 finally:module.pack_semantic_search_position=original
 t=time.perf_counter();encoded=json.dumps(record_value(r));record_seconds=time.perf_counter()-t
 out.append({'game':name,'rule_horizon':horizon,'semantic_compile_seconds':semantic_compile,'session_seconds':session_seconds,'native_compile_seconds':native_compile,'engine_seconds':engine_seconds,'search_caller_seconds':caller_seconds,'pack_seconds':pack_times,'kernel_seconds':r.elapsed_seconds,'record_seconds':record_seconds,'result':json.loads(encoded),'total_seconds':semantic_compile+session_seconds+native_compile+engine_seconds+caller_seconds+record_seconds})
(P/'cold-results.json').write_text(json.dumps({'plan':plan,'rows':out,'seconds':time.perf_counter()-start},indent=2),encoding='utf8')
print(json.dumps([{k:v for k,v in z.items() if k!='result'} for z in out],indent=2))
