from pathlib import Path
import sys,json,time
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));P=R/'.local_agent/s4-storage-20261016'
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands
from generic_chess.core.transition import initial_state
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,transient_legal_actions,make_checked,snapshot
from scripts.research_record import record_value
rows=[[None]*9 for _ in range(9)];rows[0][4]=Piece(0,'K','K');rows[8][4]=Piece(1,'K','K')
c=compile_ruleset_for_execution(replace(build_builtin_ruleset('standard_shogi'),max_ply=2048,initial_position=tuple(map(tuple,rows))))
p=replace(initial_state(c).position,hands=(Hands((('P',1),)),Hands()));provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider;e=semantic_engine_for(c)
plan={'question':'Do all76 S4 Position-only child board/base/current/promotion/hand/aux/side fields match at both sides of the conservative margin?','plies':[1022,1023],'whole_seconds':60,'scope':'State-only imported parent; Native locally appends one synthetic identity, never asserted reachable/fullhistory'}
(P/'child-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8');t=time.perf_counter();out=[]
for ply in plan['plies']:
 packed=pack_position(provider.native_rules,provider._state_only_payload(p,ply))
 for a in transient_legal_actions(provider.native_rules,packed):
  assert time.perf_counter()-t<60
  semantic=provider._decode_action(a,p);core=e.apply(p,semantic);child=make_checked(provider.native_rules,packed,a);raw=snapshot(provider.native_rules,child)
  expected=provider._state_only_payload(core,ply+1)
  assert raw['side']==expected['side'] and raw['ply']==expected['ply']
  assert record_value(raw['board'])==record_value(expected['board'])
  assert record_value(raw['hands'])==record_value(expected['hands'])
  assert record_value(raw['aux_state'])==record_value(core.aux_state)
  out.append({'ply':ply,'action':record_value(semantic),'core':record_value(core),'native':record_value(raw)})
(P/'child-results.json').write_text(json.dumps({'plan':plan,'rows':out,'seconds':time.perf_counter()-t},indent=2),encoding='utf8');print('ALL_CHILD_FIELDS',len(out),'SECONDS',time.perf_counter()-t)
