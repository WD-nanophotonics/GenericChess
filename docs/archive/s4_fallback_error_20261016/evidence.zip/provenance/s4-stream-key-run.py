from pathlib import Path
import sys,json,time,importlib.util,math,collections
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];P=R/'.local_agent/s4-storage-20261016';D=P/'stream-key'
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
plan=json.loads((D/'plan.json').read_bytes());roots={r['seed']:r for r in json.loads((P/'cancel-results.json').read_bytes())['roots']};spec=importlib.util.spec_from_file_location('stream_key._native_core',D/'_native_core.cp312-win_amd64.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);out=[];start=time.perf_counter()
for seed in plan['pilot_roots']:
 z=roots[seed];x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));ns={arm:compile_native_semantic_rules(c,**({'backend_module':m}if arm=='staged'else{}))for arm in plan['arms']}
 for kind in plan['profiles']:
  for rep in range(2):
   pair=[]
   for arm in plan['arms']if(seed+rep)%2==0 else list(reversed(plan['arms'])):
    for name in('rollout','advisor','slack'):
     f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
    assert time.perf_counter()-start<180
    e=SemanticSearchEngine(c,ns[arm],board_values=z['board_values'],hand_values=z['hand_values'],dynamic_values=(2,3,5)if kind!='static'else None,localized_control_values=(1,0,0,0,0,0,0,0,-1)if kind!='static'else None,tt_megabytes=0,ordering_cache_enabled=False)
    t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-t;state=s.state;edges=[]
    for a in r.principal_variation:state=apply_action(state,a,c);edges.append({'action':record_value(a),'state':record_value(state)})
    row={'seed':seed,'board':z['board'],'profile':kind,'rep':rep,'arm':arm,'result':record_value(r),'caller_seconds':elapsed,'pv_edges':edges};out.append(row);pair.append(row);assert record_value(s.state)==z['initial'];print(seed,kind,rep,arm,r.completed_depth,elapsed,flush=True)
   if all(q['result']['termination_reason']!='time_budget'for q in pair):assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
(D/'pilot-results.json').write_text(json.dumps({'plan':plan,'rows':out,'seconds':time.perf_counter()-start},indent=2),encoding='utf8')
summary={}
for kind in plan['profiles']:
 ratios=[];byboard={}
 for seed in plan['pilot_roots']:
  pairs=[]
  for rep in(0,1):
   pair={z['arm']:z for z in out if z['seed']==seed and z['profile']==kind and z['rep']==rep}
   if all(z['result']['termination_reason']!='time_budget'for z in pair.values()):pairs.append(pair['staged']['caller_seconds']/pair['baseline']['caller_seconds'])
  byboard[roots[seed]['board']]=pairs;ratios+=pairs
 summary[kind]={'fixed_work_ratios_by_board':byboard,'geometric_mean':math.exp(sum(map(math.log,ratios))/len(ratios))if ratios else None}
(D/'pilot-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
