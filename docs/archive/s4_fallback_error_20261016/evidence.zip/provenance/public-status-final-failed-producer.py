from pathlib import Path
import sys,json
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];P=R/'.local_agent/s4-storage-20261016'
from test_native_pending_continuation import session_after
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native import semantic as sem
from scripts.research_record import record_value
s=session_after(('e2e4','d7d5','f1b5'));n=compile_native_semantic_rules(s.compiled);full=pack_semantic_search_position(s.compiled,n,s);short=sem.pack_current_position(n,s.state.position,ply_count=s.state.ply_count);candidates=sem.candidate_actions(n,short);a=s.legal_actions()[0];packed_a=pack_semantic_action(n,s.state.position,a);out=[]
for name,operation in [('guarded',lambda:sem.guarded_actions(n,short)),('guarded_audit',lambda:sem.guarded_actions_audit(n,short)),('transient',lambda:sem.transient_legal_actions(n,short)),('transient_audit',lambda:sem.transient_legal_actions_audit(n,short)),('subset',lambda:sem.transient_legal_subset(n,short,candidates)),('checked',lambda:sem.snapshot(n,sem.make_checked(n,short,packed_a)))]:
 try:out.append({'path':name,'value':record_value(operation())})
 except Exception as exc:out.append({'path':name,'error_type':type(exc).__name__,'error':str(exc)})
out=P/(sys.argv[1]if len(sys.argv)>1 else 'public-status-baseline.json');assert not out.exists();out.write_text(json.dumps({'scope':'Actual3plyCorePENDINGrecord, plus explicitlystate-onlyNativeimport without enoughhistory; nofalse claim ofauthenticatedshortinput. Full authoritative import succeeds.','root':record_value(s.state),'full_legal_actions':len(sem.guarded_actions(n,full)),'rows':out},indent=2),encoding='utf8');print(json.dumps(out,indent=2))
