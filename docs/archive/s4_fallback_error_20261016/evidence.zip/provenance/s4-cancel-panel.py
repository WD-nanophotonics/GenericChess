from pathlib import Path
from dataclasses import replace
import sys,json,time,threading,random,traceback
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests')];P=R/'.local_agent/s4-storage-20261016'
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,generate_game,GeneratorConfig,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.transition import apply_action
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
plan={'question':'Does complete returned-output cancellation latency on fresh unfamiliar roots expose a concrete need to alter the existing fallback interface?','changed_premise':'An actual fallback requiredidentity failure was just reproduced and repaired. Ordinary cancellation still must retain legal fallback/fullfields, without silently trading correctness for responsiveness. New sample is latency qualification, not optimization or WDL.','cases':[{'board':b,'seed':124000+b*100+i}for b in(4,8,12,16)for i in(1,2,3)],'cancel_delays_seconds':[0,.001,.01],'limits':{'max_depth':8,'max_nodes':131072,'max_time_seconds':1,'quiescence_max_depth':0,'quiescence_hard_max_depth':0},'walk_plies':8,'expected_seconds':15,'whole_cap_seconds':120,'decision':'Only observed >250ms after actual cancel warrants further bottleneck attribution; otherwise retain existing cooperative API, no new diagnostics schema or blanket hard-deadline guarantee. Preserve terminaltails/failures/missing slots.','scope':'Current normal kernel, frozen rule-derived board/hand +3/9 mechanical candidate, no learned/model/AUX execution, actual source/state/PV checks, ordinary concurrent machine load unmodified.'}
assert not(P/'cancel-plan.json').exists();(P/'cancel-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8');start=time.perf_counter();roots=[];out=[]
for case in plan['cases']:
 for name in('rollout','advisor','slack'):
  flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(flags.get('user_paused')or flags.get('stopped'))
 assert time.perf_counter()-start<120
 root=dict(case)
 try:
  g=generate_game(GeneratorConfig(seed=case['seed'],board_size=case['board'],setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));source=compile_legacy_ruleset_for_semantic_execution(replace(g.ruleset,max_ply=2048));c=SearchMetadataAdapter(ir=source.ir,_legacy_compiled=source._legacy_compiled,support=source.support);s=GameSession(c);rng=random.Random(case['seed']+700000)
  for _ in range(8):
   if s.state.terminal_status.is_terminal:break
   actions=sorted(s.legal_actions(),key=repr)
   if not actions:break
   s.submit(rng.choice(actions))
  root.update(record=json.loads(serialize_game_record(s.to_record())),ruleset=json.loads(serialize_ruleset(replace(g.ruleset,max_ply=2048))),initial=record_value(s.state))
  roots.append(root)
  if s.state.terminal_status.is_terminal or s.state.ply_count<8:
   root['kind']='ACTUAL_TERMINAL_TAIL';continue
  root['kind']='ACTUAL_ONGOING';n=compile_native_semantic_rules(c);v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()};root['board_values']=bv;root['hand_values']=hv
  for delay in plan['cancel_delays_seconds']:
   token=CancellationToken();phase=['before_kernel'];event={};timer=None
   def observe():event.update(at=time.perf_counter(),phase=phase[0])
   observer=token.register_callback(observe)
   e=SemanticSearchEngine(c,n,board_values=bv,hand_values=hv,dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False)
   m=e._backend;original=m.semantic_engine_search;times={}
   def instrument(*args):
    phase[0]='kernel';times['entry']=time.perf_counter()
    try:return original(*args)
    finally:times['exit']=time.perf_counter();phase[0]='after_kernel'
   m.semantic_engine_search=instrument;z=dict(**case,cancel_delay=delay)
   try:
    if delay==0:token.cancel()
    else:timer=threading.Timer(delay,token.cancel);timer.start()
    t=time.perf_counter();r=e.search(s,SearchLimits(**plan['limits']),token,root_window_pruning=True);returned=time.perf_counter();value=record_value(r);encoded=json.dumps(value);ready=time.perf_counter()
    z.update(kind='ACTUAL_QUERY',result=value,caller_seconds=returned-t,ready_seconds=ready-t,kernel_boundary_seconds=times['exit']-times['entry'],cancel_phase=event.get('phase'),cancel_after_start=None if 'at'not in event else event['at']-t,return_after_cancel=None if 'at'not in event else returned-event['at'],ready_after_cancel=None if 'at'not in event else ready-event['at'])
    assert record_value(s.state)==root['initial'];assert r.action is None or r.action in s.legal_actions();state=s.state;edges=[]
    for a in r.principal_variation:state=apply_action(state,a,c);edges.append({'action':record_value(a),'state':record_value(state)})
    z['pv_edges']=edges
   except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
   finally:
    m.semantic_engine_search=original;observer()
    if timer is not None:timer.cancel();timer.join(timeout=2);assert not timer.is_alive()
   out.append(z);assert time.perf_counter()-start<120
 except Exception as exc:root.update(kind='ACTUAL_ROOT_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc());roots.append(root)if root not in roots else None
result={'plan':plan,'roots':roots,'rows':out,'planned_slots':36,'actual_queries':sum(z['kind']=='ACTUAL_QUERY'for z in out),'seconds':time.perf_counter()-start}
(P/'cancel-results.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps({'roots':[(x['seed'],x['kind'])for x in roots],'queries':len(out),'seconds':result['seconds'],'max_ready_after_cancel':max((x.get('ready_after_cancel')or 0)for x in out),'failures':[x for x in out if x['kind']!='ACTUAL_QUERY']},indent=2))
