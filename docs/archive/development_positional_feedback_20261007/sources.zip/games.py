"""Matched fixed-prior feedback under two already-qualified leaf bundles."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
bins={'exchange':ROOT/'.local_agent/exchange-20261007/fairy-exchange.exe','classical':ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe','reference':ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'}
config=ROOT/'.local_agent/mature-search/material-variants.ini'
suite=ROOT/'.local_agent/see-opening-20261007/suite.json';cases=json.loads(suite.read_bytes())['cases']
plan=dict(question='Does a supported positional leaf yield useful fixed-prior feedback against a nonsaturated reference, where the rule-derived leaf still fails?',design='24streams:two existing6ply prefixes x three unchanged tables x both native colors x exchange/classical leaf, interleaved. Same native search/allocation SinglePV1 Threads1 Hash16 NNUEfalse1.5sec; reference fixed UCI_LimitStrengthtrue/UCI_Elo2400,500000nodes/1.5sec fuse Threads1 Hash16. Fresh processes/hash per cell;160subsequentplies; explicit immediate Chess draw claims. Reference strength setting is stochastic and not measured Elo.',decision='Classical gains with the same prior implicate positional leaf/search bundle rather than price-only failure. If both fail, prioritize runnable search/feedback failure over adding a static term from root28. Table differences are exploratory development feedback only: retain every cell, no table selection, coefficient fitting, holdout/Elo or default promotion. Not isolated positional-feature causality.',cost='<=5760requested native+reference seconds plus replay/recording; interruptible after every action, sequential single game, no other timed tests. New paired leaf/reference contrast with explicit policy/resources, not a rerun to obtain a better result.',binary_sha256={k:sha(v) for k,v in bins.items()},config_sha256=sha(config),suite_sha256=sha(suite),adapter_sha256=sha(ROOT/'scripts/chess_development.py'),producer_sha256=sha(Path(__file__)))
assert plan['binary_sha256']['exchange']=='40d5689fe0da14762b1f30dd1fe7cb0df722dfa7bb6598dd8a30010b45d47f5b'
assert plan['binary_sha256']['classical']=='2f67539e3b58295901e365edb722fba1e43220185e97eaafb18f38df9d7a8232'
out=p/'games.json';assert not out.exists();d.write_record(p/'declaration.json',plan)
report=dict(complete=False,declaration=plan,games=[]);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());start=time.perf_counter();cost=dict(writes=0,bytes=0,seconds=0.)
def stop():
 for name in ('rollout','advisor','slack'):
  x=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes());assert not x.get('stopped') and not x.get('user_paused')
def save(path,value):
 t=time.perf_counter();d.write_record(path,value,indent=None);cost['writes']+=1;cost['bytes']+=path.stat().st_size;cost['seconds']+=time.perf_counter()-t
save(out,report)
try:
 for case in cases:
  for policy in d.POLICIES:
   for color in (0,1):
    for leaf in ('exchange','classical'):
     stop()
     with chess.engine.SimpleEngine.popen_uci([str(bins[leaf]),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci(str(bins['reference']),timeout=15) as other:
      e.configure({'Threads':1,'Hash':16,'Use NNUE':False});other.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':True,'UCI_Elo':2400})
      local=d.UciMaterial(e,case['fen'],policy,1.5);external=d.UciOpponent(other,case['fen'],500000);external.limit=chess.engine.Limit(nodes=500000,time=1.5)
      tags=dict(id=case['id'],table=policy,candidate_color=color,leaf=leaf)
      def progress(g):save(p/'active.json',dict(**tags,**g));stop()
      g=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1.5),160,progress,external=external,local_external=local,prefix=case['opening_uci'],claim_chess_draws=True)
      report['games'].append(dict(**tags,**g));save(out,report)
      print(len(report['games']),case['id'],policy,color,leaf,g['end'],g['winner'],g['plies_played'],flush=True)
 report['complete']=True
finally:
 report.update(wall_seconds=time.perf_counter()-start,recording_cost=cost);save(out,report)
save(p/'active.json',dict(complete=report['complete'],completed_games=len(report['games'])))
print('COMPLETE',report['complete'],report['wall_seconds'],flush=True)
