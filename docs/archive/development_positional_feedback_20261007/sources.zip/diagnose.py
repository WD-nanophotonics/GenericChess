import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
p=Path(__file__).parent
src=ROOT/'.local_agent/candidate-failure-20261007/continuations.json'
v=json.loads(src.read_bytes());assert v['complete']
rows=[]
for g in v['games']:
 b=chess.Board(g['initial_fen'])
 for m in g['opening_uci']:b.push_uci(m)
 trace=[]
 for i,z in enumerate(g['moves']):
  m=chess.Move.from_uci(z['move']);assert m in b.legal_moves
  before=dict(fen=b.fen(),white_check=b.is_check() and b.turn==chess.WHITE)
  captured=b.piece_at(m.to_square);san=b.san(m);b.push(m)
  if i<20 or captured or b.is_check():
   trace.append(dict(index=i,move=m.uci(),san=san,captured=None if captured is None else captured.symbol(),check=b.is_check(),**before))
 rows.append(dict(opponent=g['opponent'],forced=g['forced'],end=g['end'],winner=g['winner'],trace=trace))
r=dict(question='What concrete mechanism distinguishes the retained root28 forced continuations?',scope='Exposed trajectories, not causal certification or fitted coefficients; exact moves and captures only.',source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rows=rows)
d.write_record(p/'diagnosis.json',r)
for r in rows:print(r['opponent'],r['forced'],r['end'],[(x['index'],x['san'],x['captured']) for x in r['trace'][:24]])
