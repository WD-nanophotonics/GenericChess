"""Exposed root28 allocation curve, unchanged leaves/prices and fresh hashes."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;assert json.loads((p/'games.json').read_bytes())['complete']
src=ROOT/'.local_agent/candidate-failure-20261007/roots.json';root=next(x for x in json.loads(src.read_bytes())['rows'] if x['index']==28)
config=ROOT/'.local_agent/mature-search/material-variants.ini';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
bins={'exchange':ROOT/'.local_agent/exchange-20261007/fairy-exchange.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe','classical':ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe'}
plan=dict(question='Does exposed root28 retain the same selected move when fresh-hash search is compared at fixed nodes instead of elapsed time?',design='Three existing leaf bundles x1M/3M/10Mnodes, SinglePV1/Threads1/Hash16/NNUEfalse, full32ply history and frozen geometric table;10sec safety fuse each. Fresh process/hash/cell. All9cells retained; fuse-limited cells explicitly marked, not equal-node evidence.',decision='Stable divergence supports targeted leaf/search diagnosis; within-leaf changes prohibit attributing the old1sec result to a single static correction. No fitting or new outcome-selected budget.',cost='<=90sec fuse, usual substantially less; no other native job, current exposed root only.',binary_sha256={k:sha(v) for k,v in bins.items()},config_sha256=sha(config),root_input_sha256=sha(src),producer_sha256=sha(Path(__file__)))
out=p/'fixed-nodes.json';assert not out.exists();d.write_record(p/'fixed-nodes-declaration.json',plan)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());state,_=d.replay_prefix(chess.STARTING_FEN,c,root['history_prefix']);legal={d.uci(a) for a in d.iter_legal_actions(state,c)}
report=dict(complete=False,declaration=plan,rows=[],legal_history_selected_pv_mismatches=0)
for nodes in (1000000,3000000,10000000):
 for leaf,binary in bins.items():
  for name in ('rollout','advisor','slack'):
   x=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes());assert not x.get('stopped') and not x.get('user_paused')
  with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
   e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=d.UciMaterial(e,chess.STARTING_FEN,'geometric_half',10)
   player.limit=chess.engine.Limit(nodes=nodes,time=10)
   d.replay_prefix(chess.STARTING_FEN,c,root['history_prefix'],(player,));m,row=player.choose();assert m in legal
   board=player.board.copy(stack=True)
   for pv in row['pv']:assert chess.Move.from_uci(pv) in board.legal_moves;board.push_uci(pv)
   row.update(leaf=leaf,requested_nodes=nodes,node_budget_reached=row['engine_nodes']>=nodes,known_finite_child_reference=root['children'].get(m))
   report['rows'].append(row);d.write_record(out,report)
   print(leaf,nodes,m,row['engine_nodes'],row['engine_depth'],row['node_budget_reached'],flush=True)
report['complete']=True;d.write_record(out,report)
