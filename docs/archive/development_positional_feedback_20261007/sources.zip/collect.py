"""Generated portable evidence with exact raw/source recovery."""
import sys,json,hashlib,zipfile,tempfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/development_positional_feedback_20261007';out=ROOT/'docs/research/data/chess_positional_feedback_20261007.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
v=json.loads((p/'games.json').read_bytes());r=json.loads((p/'replay.json').read_bytes())
prior=json.loads((p/'priors.json').read_bytes());pr=json.loads((p/'priors-replay.json').read_bytes());curve=json.loads((p/'fixed-nodes.json').read_bytes())
assert prior['complete'] and pr['complete'] and len(pr['games'])==8 and not pr['errors'] and curve['complete'] and len(curve['rows'])==9
assert curve['declaration']['producer_sha256']==sha((p/'fixed-nodes.py').read_bytes())
assert pr['input_sha256']==sha((p/'priors.json').read_bytes()) and prior['declaration']['producer_sha256']==sha((p/'priors.py').read_bytes())
assert v['complete'] and r['complete'] and len(r['games'])==24 and not r['errors']
assert r['input_sha256']==sha((p/'games.json').read_bytes())
assert v['declaration']['producer_sha256']==sha((p/'games.py').read_bytes())
groups={};cost={};pairs=[]
for g in r['games']:
 z=groups.setdefault(g['leaf'],{}).setdefault(g['table'],dict(win=0,loss=0,draw=0,unfinished=0));z[g['outcome']]+=1
 for mode,c in g['cost'].items():
  x=cost.setdefault(g['leaf'],{}).setdefault(mode,{k:None if value is None else 0 for k,value in c.items()})
  for k,value in c.items():
   if value is not None:x[k]+=value
for left,right in zip(r['games'][::2],r['games'][1::2]):
 assert (left['id'],left['table'],left['candidate_color'])==(right['id'],right['table'],right['candidate_color'])
 assert (left['leaf'],right['leaf'])==('exchange','classical')
 pairs.append(dict(id=left['id'],table=left['table'],native_color=left['candidate_color'],exchange=left['outcome'],classical=right['outcome'],exchange_plies=left['plies'],classical_plies=right['plies']))
a.mkdir(exist_ok=True);indexes={}
def archive(name,files):
 target=a/name;assert not target.exists();entries={}
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in files:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b)
   z.writestr(n,b);entries[n]=dict(bytes=len(b),sha256=sha(b))
 with tempfile.TemporaryDirectory(prefix='gc-positional-') as td,zipfile.ZipFile(target) as z:
  assert z.testzip() is None;z.extractall(td)
  for n,h in entries.items():assert sha((Path(td)/n).read_bytes())==h['sha256']
 indexes[name]=dict(entries=entries,sha256=sha(target.read_bytes()),physically_extracted_rehashed=True)
archive('raw.zip',[(p/n,n) for n in ('diagnosis.json','declaration.json','games.json','replay.json','priors-declaration.json','priors.json','priors-replay.json','fixed-nodes-declaration.json','fixed-nodes.json')])
archive('sources.zip',[(p/n,n) for n in ('diagnose.py','games.py','replay.py','collect.py','priors.py','fixed-nodes.py')]+[(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(ROOT/'scripts/research_record.py','shared-research_record.py'),(ROOT/'.local_agent/see-opening-20261007/suite.json','suite.json'),(ROOT/'.local_agent/mature-search/material-variants.ini','material-variants.ini')])
prior_groups={}
for g in pr['games']:
 z=prior_groups.setdefault(g['table'],dict(win=0,loss=0,draw=0,unfinished=0));z[g['outcome']]+=1
summary=dict(scope='Exposed development, fixed-prior matched leaf/reference feedback. Classical human positional bundle is a diagnostic benchmark, not rule-derived candidate or coefficient target. Stochastic reference2400 label is not measured rating.',declaration=v['declaration'],groups=groups,paired_cells=pairs,cost=cost,wall_seconds=v['wall_seconds'],recording_cost_before_final_save=v['recording_cost'],replay=r,diagnosis=json.loads((p/'diagnosis.json').read_bytes()),archives=indexes,build_recovery='Pinned source/build packages in chess_exchange_20261007.json and chess_classical_20261007.json. Binaries/config/adapter pinned here; previous root28 reports verify28identical shared native objects excluding evaluation.',limitations='Two reused prefixes, small cells, exposed exploratory prices, stochastic timed/reference play; not independent holdout, calibrated Elo, price ordering proof, unique positional cause or admitted default. Native CPU/cache/scored leaves not instrumented; controller CPU is distinct. Human SEE/pruning/PSQT coupling remains.',production_changes='None; existing game entry/search/leaves/prices, explicit opt-in draw policy only')
summary.update(same_leaf_prior_contrast=dict(declaration=prior['declaration'],groups=prior_groups,replay=pr,wall_seconds=prior['wall_seconds']),fixed_node_diagnostic=curve)
summary['interpretation']='The initial expectation that the half-risk candidate still fails is contradicted in this cohort:6W3D3U. Classical7W3L1D1U is not universal improvement; its unit cells0W3L1U contrast with geometric3W1D and linear4W. Both fixed rule tables then win4/4 versus unit under the same classical bundle. This is useful deployment feedback without fitting or choosing between the rule tables. Preserve old stronger-reference failures and different resources/prefix/policy as distinct records, not a causal before/after strength gain.'
summary['next_decision']='Unit is now a weak/saturated direct control in these scoped cells. Seek a declared comparison that can distinguish the two unchanged rule priors under the same supported bundle, retaining all outcomes; do not change prices or add a new positional penalty from the exposed root.'
write_record(out,summary);write_record(a/'index.json',dict(archives=indexes,portable_sha256=sha(out.read_bytes())))
print(json.dumps(dict(groups=groups,prior_groups=prior_groups,played=r['played_plies']+pr['played_plies'],prefix=r['prefix_plies']+pr['prefix_plies'],entries=sum(len(x['entries']) for x in indexes.values()),wall_seconds=v['wall_seconds']+prior['wall_seconds'])))
