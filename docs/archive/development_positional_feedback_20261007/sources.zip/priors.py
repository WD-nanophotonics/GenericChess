"""Same positional leaf/search, fixed rule tables against unit prior."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;assert json.loads((p/'games.json').read_bytes())['complete']
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();binary=ROOT/'.local_agent/classical-control-20261007/fairy-classical.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini';suite=ROOT/'.local_agent/see-opening-20261007/suite.json'
cases=json.loads(suite.read_bytes())['cases'];out=p/'priors.json';assert not out.exists()
plan=dict(question='Do fixed rule-derived prices yield useful actual play versus unit prices under the same supported positional leaf and search?',design='8streams:two unchanged6ply prefixes x geometric_half/linear_mixture x both rule-table colors, versus unit. Both use identical classical executable/SinglePV1/Threads1/Hash16/NNUEfalse1.5sec, fresh processes/hash per cell,160subsequentplies, explicit immediate Chess draw claims. One sequential game only.',decision='This tests rule-table utility within one human positional bundle, not a generic rule-derived evaluator. Native PSQT/material/SEE/pruning can couple to prices; no pure independent prior effect, table selection, fitting, Elo, holdout or default admission. Retain all8cells, no result-driven extensions.',cost='<=1920requested seconds plus replay/recording; incremental question isolates fixed-table contrast, declared before current feedback completes. Interruptible after each move, no other timed jobs.',binary_sha256=sha(binary),config_sha256=sha(config),suite_sha256=sha(suite),producer_sha256=sha(Path(__file__)),adapter_sha256=sha(ROOT/'scripts/chess_development.py'))
d.write_record(p/'priors-declaration.json',plan);report=dict(complete=False,declaration=plan,games=[]);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());start=time.perf_counter()
def stop():
 for name in ('rollout','advisor','slack'):
  x=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes());assert not x.get('stopped') and not x.get('user_paused')
d.write_record(out,report)
try:
 for case in cases:
  for policy in ('geometric_half','linear_mixture'):
   for color in (0,1):
    stop()
    with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as other:
     for engine in (e,other):engine.configure({'Threads':1,'Hash':16,'Use NNUE':False})
     local=d.UciMaterial(e,case['fen'],policy,1.5);external=d.UciMaterial(other,case['fen'],'unit',1.5)
     tags=dict(id=case['id'],table=policy,candidate_color=color,leaf='classical',opponent_table='unit')
     def progress(g):d.write_record(p/'prior-active.json',dict(**tags,**g),indent=None);stop()
     g=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1.5),160,progress,external=external,local_external=local,prefix=case['opening_uci'],claim_chess_draws=True)
     report['games'].append(dict(**tags,**g));d.write_record(out,report,indent=None);print(len(report['games']),case['id'],policy,color,g['end'],g['winner'],g['plies_played'],flush=True)
 report['complete']=True
finally:report['wall_seconds']=time.perf_counter()-start;d.write_record(out,report)
d.write_record(p/'prior-active.json',dict(complete=report['complete'],completed_games=len(report['games'])))
print('PRIORS COMPLETE',report['complete'],report['wall_seconds'],flush=True)
