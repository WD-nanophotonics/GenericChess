import subprocess,time,json
from pathlib import Path
from datetime import datetime,timezone
b=Path(__file__).parent
start=datetime.now(timezone.utc)
assert datetime.fromisoformat('2026-10-11T04:25:00+00:00') <= start < datetime.fromisoformat('2026-10-11T04:28:45+00:00'), 'outside explicit ACK slot'
t=time.perf_counter()
p=subprocess.run(['.venv/Scripts/python.exe',str(b/'hand_cow_control_run2.py')],capture_output=True,text=True,timeout=240)
end=datetime.now(timezone.utc)
out={'ack_ts':'1791692684.137719','start_utc':start.isoformat(),'end_utc':end.isoformat(),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-t,'primary_cpu_overlap':False,'aux_ack_is_atomic_lock':False,'within_slot':end<datetime.fromisoformat('2026-10-11T04:30:00+00:00')}
(b/'hand-cow-slot-fixed-run2.json').write_text(json.dumps(out,indent=2)+'\n')
print(p.stdout,p.stderr);assert out['within_slot'] and p.returncode==0
