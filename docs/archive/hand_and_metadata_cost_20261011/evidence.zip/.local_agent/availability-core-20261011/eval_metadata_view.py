"""Private evaluator metadata view; original legacy attack helpers remain."""
from types import SimpleNamespace
from generic_chess.ai.evaluation.evaluator import Evaluator
baseline=Evaluator.__init__
FIELDS=('ruleset_fingerprint','board_size','types_by_id','leap_targets','ray_paths','empty_forward_mobility')
def prepare(e):
    original=e._compiled
    # Read the actual execution facade, never substitute the legacy fingerprint.
    e._execution_compiled=original
    e._compiled=SimpleNamespace(**{name:getattr(original,name) for name in FIELDS})
def constructor(self,*args,**kwargs):
    baseline(self,*args,**kwargs)
    prepare(self)
def install(active):
    Evaluator.__init__=constructor if active else baseline
