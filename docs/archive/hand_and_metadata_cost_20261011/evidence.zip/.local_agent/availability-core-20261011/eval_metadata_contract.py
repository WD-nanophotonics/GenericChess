"""Finite original-helper evaluation equivalence, ownership and fingerprint checks."""
import sys,time,importlib.util,json
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
def load(name,file):
 s=importlib.util.spec_from_file_location(name,B/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=load('view','eval_metadata_view.py');c=load('caller','installed_control.py')
from generic_chess.core.transition import legal_successors
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.core.errors import RuleSetMismatchError
from generic_chess.core.pieces import Piece
from generic_chess.core.attacks import pseudo_attacks

def main():
 start=time.perf_counter();out=dict(complete=False,checks=0,foreign_checks=0,rows=[],scope='Unchanged legacy evaluator helpers, shallow view owns container and borrows original rows. Exposed development inputs, not new holdout or semantic-only valuation support.')
 groups=[]
 for case in c.CASES:
  compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=c.CoreBoard(case,compiled)
  groups.append((case['id'],compiled,board.initial,c.VALUES[case['game']],None))
 for size in (4,6):
  for seed in (7,21):
   game=generate_game(GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));compiled=c.compile_ruleset_for_execution(game.ruleset)
   groups.append((f'generated{size}-{seed}',compiled,c.GameSession(compiled).state,{pt.type_id:0 if pt.is_anchor else 100 for pt in compiled.piece_types},16))
 for name,compiled,state,values,cap in groups:
  c.stopped();a=c.w.weighted(compiled,values);b=c.w.weighted(compiled,values);p.prepare(b)
  assert b._execution_compiled is compiled
  for field in p.FIELDS:assert getattr(b._compiled,field) is getattr(compiled,field) or getattr(b._compiled,field)==getattr(compiled,field)
  successors=legal_successors(state,compiled);children=[child for _,child in successors[:cap] if cap is not None] if cap is not None else [child for _,child in successors]
  states=[state]+children
  for child in states:
   assert a._attack_maps(child)==b._attack_maps(child)
   assert a.evaluate(child)==b.evaluate(child);out['checks']+=1
  foreign=replace(state.position,ruleset_fingerprint='FOREIGN')
  for evaluator in (a,b):
   try:pseudo_attacks(foreign,0,evaluator._compiled)
   except RuleSetMismatchError:out['foreign_checks']+=1
   else:raise AssertionError('fingerprint check bypassed')
  out['rows'].append(dict(root=name,states=len(states),fingerprint=compiled.ruleset_fingerprint,owned_shallow_bytes=sys.getsizeof(b._compiled)+sys.getsizeof(vars(b._compiled)),borrowed_fields=list(p.FIELDS)))
 # Synthetic current/base, friendly blocker and both owner domains.
 for game in ('western_chess','standard_shogi'):
  compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset(game));state=c.GameSession(compiled).state;values=c.VALUES['chess' if game=='western_chess' else 'shogi'];a=c.w.weighted(compiled,values);b=c.w.weighted(compiled,values);p.prepare(b)
  for tid in compiled.types_by_id:
   for owner in (0,1):
    for source in range(len(state.position.board)):
     cells=[None]*len(state.position.board);cells[source]=Piece(owner,tid,tid);cells[(source+1)%len(cells)]=Piece(owner,'K','K')
     child=SimpleNamespace(position=replace(state.position,board=tuple(cells)),ply_count=0)
     assert a._attack_maps(child)==b._attack_maps(child);assert a.evaluate(child)==b.evaluate(child);out['checks']+=1
 out.update(complete=True,seconds=time.perf_counter()-start);c.write_record(B/'eval-metadata-contract.json',out);print(out['checks'],out['foreign_checks'],'exact',flush=True)
if __name__=='__main__':main()
