"""Defined-work profiler controls; instrumentation overhead is separate.
Two representative existing roots (Chess middle, generated2000);4096entry/D8,
30second safety fuse. Baseline/profile/reversed profile/baseline on full Native
state only. Requires equal choices/work/trace. C entry time is inclusive of its
internal semantic checks/copies; Python cannot decompose C internals here.
"""
from pathlib import Path
import sys, json, cProfile, pstats, hashlib, importlib.util
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES,minimal_ab
from scripts.native_backend_bridge import NativeBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from generic_chess.native.semantic import search_runtime_sizes
coverage=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
class Generated:
 def __init__(self):
  case=next(c for c in coverage['cases'] if c['seed']==202610082000)
  self.compiled=compile_ruleset_for_execution(ruleset_from_dict(case['rules']))
  s=GameSession(self.compiled)
  for step in case['route'][:3]:s.submit(action_from_dict(step['action']))
  self.initial=s.state;self.witnesses=tuple(s._search_witnesses)
  self.label=lambda a:json.dumps(action_to_dict(a),sort_keys=True,separators=(',',':'))
  self.values={p.type_id:0 if p.is_anchor else 100 for p in self.compiled.piece_types}
def chess_factory():
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
 return CoreBoard(CASES[0],c),VALUES['chess']
def generated_factory():
 b=Generated();return b,b.values
rows=[]
for name,factory in [('chess-middle',chess_factory),('generated2000',generated_factory)]:
 for profiled in (False,True,True,False):
  core,values=factory();board=NativeBoard(core,values);profile=cProfile.Profile()
  if profiled:profile.enable()
  result=minimal_ab(board,8,seconds=30,node_limit=4096,trace=True)
  if profiled:profile.disable()
  stats=[]
  if profiled:
   for (file,line,function),(primitive,total,self_s,cumulative_s,callers) in pstats.Stats(profile).stats.items():
    if 'generic_chess' in file or 'scripts' in file or 'semantic_' in function:
     stats.append(dict(file=file.replace(str(ROOT),'<repo>'),line=line,function=function,primitive_calls=primitive,total_calls=total,self_seconds=self_s,cumulative_seconds=cumulative_s))
   stats.sort(key=lambda row:row['self_seconds'],reverse=True)
  rows.append(dict(case=name,profiled=profiled,result=result,stats=stats))
  print(name,profiled,result['wall_seconds'],flush=True)
 group=[r for r in rows if r['case']==name]
 signature=lambda r:(r['result']['work'],r['result']['move'],r['result']['score'],r['result']['trace_sha256'])
 assert all(signature(r)==signature(group[0]) for r in group)
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),runtime_sizes=search_runtime_sizes(),rows=rows)
Path(__file__).with_name('profile-bridge.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for row in rows:
 if row['profiled']:print(row['case'],[(s['function'],round(s['self_seconds'],3)) for s in row['stats'][:8]])
