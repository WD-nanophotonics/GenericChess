"""Current protected full-root product versus bare same-Native-state AB.
Six existing roots, two reversed fresh pairs, each1sec/D12/100000 safety nodes.
C product cold64MiB TT, q0, absent dynamic features, full-root default; bare
lexical AB retains its different node/order/fallback contract. Setup outside
search wall, all PVs/choices/history/restoration verified. New decision: after
unsafeON withdrawal, what completion/choice remains on safe current defaults?
No fit, new labels/cohort or frozen cap changes. Expected24sec plus setup.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('syntax_ablation.py'))}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from scripts.search_backend_comparison import iterative_minimal
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.research_record import record_value
from scripts.unfamiliar_search import validate_pv
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=Path(__file__).with_name('protected-default.json')
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
start=perf_counter()
try:
 for name,factory,values in ns['factories']:
  for repeat,modes in enumerate((('bare','protected_product'),('protected_product','bare'))):
   for mode in modes:
    for flag in ('rollout','advisor','slack'):
     f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes())
     assert not(f.get('user_paused') or f.get('stopped'))
    t=perf_counter();core=factory();board=NativeBoard(core,values)
    if mode=='bare':
     setup=perf_counter()-t;row=iterative_minimal(board,seconds=1,node_limit=100000,max_depth=12)
    else:
     session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
     engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=64)
     setup=perf_counter()-t;t=perf_counter()
     result=engine.search(session,SearchLimits(max_depth=12,max_nodes=100000,max_time_seconds=1,quiescence_max_depth=0))
     wall=perf_counter()-t;row=record_value(asdict(result));row['move']=None if result.action is None else core.label(result.action);row['wall_seconds']=wall
     assert result.root_window_pruning is False
     validate_pv(session,result);assert session.state==core.initial and tuple(session._search_witnesses)==core.witnesses
    assert board.restored() and row['move'] in {label for label,_ in core.actions()}
    row.update(case=name,repeat=repeat,backend=mode,budget_seconds=1,setup_seconds=setup,legal=True,root_restored=True)
    report['rows'].append(row);save();print(name,mode,row['completed_depth'],flush=True)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
