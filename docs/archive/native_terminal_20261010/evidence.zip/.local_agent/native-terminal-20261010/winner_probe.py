"""Installed-v4 terminal winners versus probe/fixed/iterative search.
Synthetic exact digest/event histories are C contract witnesses, not replayed
legal games. Four checker/turn combinations retain raw roots and all outputs.
"""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests/product'),str(ROOT/'tests')]
from test_h50b2a_semantic_native_search import _declaration_free_shogi,_pack_initial,_continuous_history
from generic_chess.native import _module
from generic_chess.native.semantic import terminal_status,probe_search,fixed_depth_search,semantic_iterative_search,snapshot
rows=[]
for checker in (0,1):
 for side in (0,1):
  semantic,native=_declaration_free_shogi()
  fresh=_pack_initial(semantic,native,side=side)
  packed=_pack_initial(semantic,native,side=side,history=_continuous_history(native,fresh,checker))
  before=snapshot(native,packed)
  terminal=terminal_status(native,packed)
  expected=1 if terminal['winner']==side else -1
  outputs={name:fn(native,packed,1) for name,fn in [('probe',probe_search),('fixed',fixed_depth_search),('iterative',semantic_iterative_search)]}
  assert terminal==dict(status='perpetual_check',winner=1-checker)
  assert outputs['probe']['score']==outputs['fixed']['score']==0
  assert outputs['iterative']['score']*expected>0
  assert snapshot(native,packed)==before
  rows.append(dict(checker=checker,side=side,terminal=terminal,expected_sign=expected,results=outputs,root_restored=True,rule_fingerprint=semantic.ruleset_fingerprint))
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 binary_sha256=hashlib.sha256(Path(_module().__file__).read_bytes()).hexdigest(),rows=rows,
 decision='Fixed/probe winner scoring is independently defective on perpetual-check terminals, while iterative search retains winner semantics. Raw synthetic histories do not establish legal-trajectory coverage.')
Path(__file__).with_name('winner-probe.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps([dict(checker=r['checker'],side=r['side'],scores={k:v['score'] for k,v in r['results'].items()}) for r in rows]))
