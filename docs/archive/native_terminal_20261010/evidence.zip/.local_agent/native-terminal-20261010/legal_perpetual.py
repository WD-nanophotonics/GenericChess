"""Twelve fully legal actions per owner, not synthetic digest/event authority.
Explicit historical draw stalemate variant isolates the independent perpetual
winner defect of the installed v4 fixed/probe raw entries. Public fixed/probe
must now reject before execution; iterative and full-state bridge must agree.
"""
from pathlib import Path
import sys,json,hashlib
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native import _module
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import terminal_status,probe_search,fixed_depth_search,semantic_iterative_search,snapshot
from scripts.search_backend_comparison import CoreBoard
from scripts.native_backend_bridge import NativeBoard
rows=[]
for checker,setup,cycle in (
 (0,'4k4/3R5/9/9/9/9/9/9/8K b - 1','6b5b 5a6a 5b6b 6a5a'),
 (1,'k8/9/9/9/9/9/9/5r3/4K4 w - 1','4h5h 5i4i 5h4h 4i5i'),
):
 compiled=compile_ruleset_for_execution(replace(build_builtin_ruleset('standard_shogi'),stalemate_result='draw'))
 case=dict(game='shogi',setup=setup,moves=' '.join([cycle]*3))
 board=CoreBoard(case,compiled)
 session=GameSession(compiled);session._state=board.initial;session._search_history_witnesses=board.witnesses
 assert board.initial.terminal_status.status.value=='perpetual_check'
 assert board.initial.terminal_status.winner==1-checker
 assert board.initial.ply_count==12 and len(board.witnesses)==13
 native=compile_native_semantic_rules(compiled);packed=pack_semantic_search_position(compiled,native,session)
 before=snapshot(native,packed)
 result=terminal_status(native,packed)
 assert result==dict(status='perpetual_check',winner=1-checker)
 raw={name:dict(getattr(_module(),name)(native.capsule,packed,1)) for name in ('semantic_probe_search','semantic_fixed_depth_search')}
 assert all(r['score']==0 for r in raw.values())
 rejected=[]
 for fn in (probe_search,fixed_depth_search):
  try:fn(native,packed,1)
  except NativeUnsupportedRuleError:rejected.append(fn.__name__)
 assert len(rejected)==2
 iterative=semantic_iterative_search(native,packed,1)
 assert iterative['score']==-100000000
 bridge=NativeBoard(board,{p.type_id:0 if p.is_anchor else 100 for p in compiled.piece_types})
 assert bridge.terminal(0)==board.terminal(0)==-1000000000
 assert snapshot(native,packed)==before
 rows.append(dict(checker=checker,setup=setup,moves=case['moves'],ply=12,witnesses=13,
  core_status=board.initial.terminal_status.status.value,core_winner=board.initial.terminal_status.winner,
  raw=raw,public_rejected=rejected,iterative=iterative,root_restoration=True,rule_fingerprint=compiled.ruleset_fingerprint,
  history=[dict(actor=r.actor,gave_check=r.gave_check) for r in board.initial.history]))
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 binary_sha256=hashlib.sha256(Path(_module().__file__).read_bytes()).hexdigest(),rows=rows)
Path(__file__).with_name('legal-perpetual.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print([(r['checker'],r['core_winner'],r['iterative']['score']) for r in rows])
