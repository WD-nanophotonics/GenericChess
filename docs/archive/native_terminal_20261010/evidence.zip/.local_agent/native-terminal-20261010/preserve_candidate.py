"""Preserve unexecuted source candidate; restore only this segment's tracked edits."""
from pathlib import Path
import subprocess, json, hashlib, shutil
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
base='2d04736dfcfdd64c07ba0bd977ae21651bf8d811'
paths=[
 'generic_chess/native/compiler.py',
 'generic_chess/_native/native_semantic_rules.h',
 'generic_chess/_native/native_semantic_rules.c',
 'generic_chess/_native/native_module.c',
 'tests/product/test_native_terminal_policy_support.py',
 'tests/product/test_h50b1_r2_payload_version.py',
 'tests/product/test_phase19c1_native_semantic_payload.py',
 'tests/specification/test_phase19c1_native_semantic_payload_contract.py',
]
rows=[]
for path in paths+['tests/product/test_native_terminal_v5.py']:
 data=(ROOT/path).read_bytes()
 target=OUT/'candidate'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 rows.append(dict(path=path,sha256=hashlib.sha256(data).hexdigest()))
for path in paths:
 data=subprocess.check_output(['git','show',f'{base}:{path}'],cwd=ROOT)
 (ROOT/path).write_bytes(data)
shutil.move(str(ROOT/'tests/product/test_native_terminal_v5.py'),str(OUT/'unexecuted_test_native_terminal_v5.py'))
binary=OUT/'_native_core_v5.cp312-win_amd64.pyd'
control=OUT/'_native_core.cp312-win_amd64.pyd'
record=dict(schema=1,base_sha=base,candidate_source=rows,
 candidate_binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),candidate_bytes=binary.stat().st_size,
 control_binary_sha256=hashlib.sha256(control.read_bytes()).hexdigest(),
 outcome='Build exit0; fresh import rejected by Windows Application Control; no candidate tests executed; no binary installation or security change.',
 restored_tracked_paths=paths,new_test_retained_only_in_ignored_diagnostics=True)
(OUT/'build-failure.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
