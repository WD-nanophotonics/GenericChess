"""Does the already supported cold64MiB TT change default-window completion?
Same three exposed roots/material/full history, default root pruningON, absent
features/q0. Fresh TT0/64MiB engines in reversed pairs: fixedD2 then1/2second
D12/100000node controls.64MiB is existing engine default, not new worker/training
or memory expansion. No warm carryover across calls. Setup memory/cost excluded
from warm timing but recorded. All PV legality/root restoration checked; fixed
completed scores must match. Estimated<2min, no strength/frozen teacher extension.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('algorithm_curve.py'))}
exec(Path(ns['__file__']).read_text().split('report=dict')[0],ns)
factories=ns['factories'];SemanticSearchEngine=ns['SemanticSearchEngine'];NativeBoard=ns['NativeBoard'];GameSession=ns['GameSession'];SearchLimits=ns['SearchLimits'];validate_pv=ns['validate_pv'];record_value=ns['record_value']
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixed=[],timed=[],complete=False)
out=Path(__file__).with_name('tt-window-ablation.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def stopped():
 for name in ('rollout.json','advisor.json','slack.json'):
  flags=json.loads((ROOT/'.local_agent'/name).read_bytes())
  if flags.get('user_paused') or flags.get('stopped'):raise RuntimeError('project stopped')
start=perf_counter()
try:
 for name,factory,values in factories:
  for kind,budgets in (('fixed',(30,)),('timed',(1,2))):
   for seconds in budgets:
    for repeat,order in enumerate(((False,True),(True,False))):
     for tt_enabled in order:
      stopped();t=perf_counter();core=factory();board=NativeBoard(core,values);s=GameSession(core.compiled);s._state=core.initial;s._search_history_witnesses=core.witnesses
      engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=64 if tt_enabled else 0);setup=perf_counter()-t;t=perf_counter()
      result=engine.search(s,SearchLimits(max_depth=2 if kind=='fixed' else 12,max_nodes=1000000 if kind=='fixed' else 100000,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True)
      wall=perf_counter()-t;validate_pv(s,result)
      assert s.state==core.initial and tuple(s._search_witnesses)==core.witnesses and board.restored()
      row=record_value(asdict(result));row.update(case=name,repeat=repeat,budget_seconds=seconds,tt_megabytes=64 if tt_enabled else 0,move=core.label(result.action),wall_seconds=wall,setup_seconds=setup,legal=True,root_restored=True)
      report[kind].append(row);save()
      print(name,kind,seconds,repeat,tt_enabled,result.completed_depth,result.nodes,round(wall,4),flush=True)
  fixed=[x for x in report['fixed'] if x['case']==name]
  assert all(x['completed_depth']==2 and x['score']==fixed[0]['score'] for x in fixed)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
