"""Winner semantics must reach raw and public search, beyond legality support."""
from copy import deepcopy
from dataclasses import replace

import pytest

from generic_chess import build_builtin_ruleset, compile_ruleset_for_execution
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from generic_chess.native import _module
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.compiler import build_semantic_compile_payload, compile_native_semantic_rules
from generic_chess.native.semantic import (
    terminal_status, snapshot, fixed_depth_search, probe_search,
    semantic_iterative_search, public_action,
)
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
from native_test_helpers import requires_native
from scripts.search_backend_comparison import CASES, CoreBoard

pytestmark = requires_native


def _root(policy='loss', reverse=False):
    rules = replace(build_builtin_ruleset('standard_shogi'), stalemate_result=policy)
    compiled = compile_ruleset_for_execution(rules)
    case = dict(CASES[5])
    if reverse:
        case['setup'] = '8k/9/9/9/9/9/2r6/9/K8 w g 1'
    board = CoreBoard(case, compiled)
    native = compile_native_semantic_rules(compiled)
    session = GameSession(compiled)
    session._state = board.initial
    session._search_history_witnesses = board.witnesses
    return compiled, native, board, session


def _packed(compiled, native, state, witnesses):
    session = GameSession(compiled)
    session._state = state
    session._search_history_witnesses = witnesses
    return pack_semantic_search_position(compiled, native, session)


@pytest.mark.parametrize('policy', ['draw', 'loss'])
@pytest.mark.parametrize('reverse', [False, True])
def test_no_move_policy_reaches_raw_public_and_all_search_scores(policy, reverse):
    compiled, native, board, session = _root(policy, reverse)
    labels = ('3c2c+', '3c3b+') if not reverse else ('7g8g+', '7g7h+')
    children = [(label, apply_action(board.initial, action, compiled))
                for label, action in board.actions() if label in labels]
    assert len(children) == 2
    for label, child in children:
        assert child.terminal_status.status.value == 'stalemate'
        expected_winner = None if policy == 'draw' else 1-child.position.side_to_move
        assert child.terminal_status.winner == expected_winner
        packed = _packed(compiled, native, child, board.witnesses+(child.position,))
        before = snapshot(native, packed)
        for result in (_module().semantic_terminal(native.capsule, packed), terminal_status(native, packed)):
            assert result['status'] == 'stalemate'
            assert result['winner'] == expected_winner
        for entry in (fixed_depth_search, probe_search):
            result = entry(native, packed, 2)
            assert result['score'] == (0 if policy == 'draw' else -1000000)
            assert result['best_action'] is None
        result = semantic_iterative_search(native, packed, 2)
        assert result['score'] == (0 if policy == 'draw' else -100000000)
        engine = SemanticSearchEngine(compiled, native, tt_megabytes=0)
        raw = _module().semantic_engine_search(engine._capsule, packed, 2)
        assert raw['score'] == result['score']
        assert snapshot(native, packed) == before


@pytest.mark.parametrize('reverse', [False, True])
def test_parent_backpropagates_loss_as_win_with_legal_pv_and_restoration(reverse):
    compiled, native, board, session = _root(reverse=reverse)
    packed = pack_semantic_search_position(compiled, native, session)
    before = snapshot(native, packed)
    for entry in (fixed_depth_search, probe_search, semantic_iterative_search):
        result = entry(native, packed, 2)
        assert result['score'] > 900000
        state = board.initial
        for raw in result['principal_variation']:
            state = apply_action(state, public_action(native, raw), compiled)
        assert state.terminal_status.winner == board.initial.position.side_to_move
        assert snapshot(native, packed) == before
    engine = SemanticSearchEngine(compiled, native, tt_megabytes=1)
    result = engine.search(session, SearchLimits(max_depth=2, quiescence_max_depth=0), root_window_pruning=False)
    assert result.score > 90000000
    child = apply_action(board.initial, result.action, compiled)
    assert child.terminal_status.winner == board.initial.position.side_to_move
    other_compiled, _, _, other_session = _root('draw', reverse)
    assert other_compiled.ruleset_fingerprint != compiled.ruleset_fingerprint
    with pytest.raises(ValueError, match='fingerprint'):
        engine.search(other_session, SearchLimits(max_depth=2, quiescence_max_depth=0))


@pytest.mark.parametrize('value', [None, -1, 2, 'loss'])
def test_v5_requires_known_explicit_terminal_policy(value):
    compiled, _, _, _ = _root()
    payload, _ = build_semantic_compile_payload(compiled)
    if value is None:
        payload.pop('stalemate_result')
    else:
        payload['stalemate_result'] = value
    with pytest.raises((ValueError, TypeError, OverflowError)):
        _module().compile_semantic_rules(payload)


def test_historical_v4_roundtrip_stays_draw_and_cannot_hide_v5_policy():
    compiled, _, _, _ = _root()
    payload, _ = build_semantic_compile_payload(compiled)
    legacy = deepcopy(payload)
    legacy['semantic_payload_version'] = 4
    with pytest.raises(ValueError, match='requires payload v5'):
        _module().compile_semantic_rules(legacy)
    legacy.pop('stalemate_result')
    capsule = _module().compile_semantic_rules(legacy)
    assert _module().semantic_rules_info(capsule) == legacy
    legacy.pop('automatic_adjudications')
    with pytest.raises(ValueError, match='missing semantic automatic'):
        _module().compile_semantic_rules(legacy)
