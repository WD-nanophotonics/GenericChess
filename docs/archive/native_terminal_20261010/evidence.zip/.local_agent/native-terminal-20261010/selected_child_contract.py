"""Does narrowed-root tie selection retain the reported exact finiteD3 value?
New concrete premise: source canonicalPV replay retains the already chosen bound
and discards the replayed value. Check selected child only on two existing roots
and four completeD3 TT/window combinations. Core exactD2 child reference, same
material/terminal/history,30sec/1000000 safety fuse, preserve UNKNOWN if capped.
This is a diagnostic of selected-score consistency, not a teacher extension,
fit, new test population or strength claim. Estimated<15sec. All row outcomes
retained; different choices alone are not defects. No C binary edits.
"""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('algorithm_curve.py'))}
exec(Path(ns['__file__']).read_text().split('report=dict')[0],ns)
from generic_chess.native.semantic import semantic_iterative_search,public_action,make_checked
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.search_backend_comparison import minimal_ab
rows=[]
for name,factory,values in ns['factories'][:2]:
 for tt in (0,64):
  for window in (False,True):
   core=factory();board=ns['NativeBoard'](core,values)
   result=semantic_iterative_search(board.native,board.position,3,max_nodes=1000000,max_time_seconds=30,board_values=values,hand_values=values,tt_megabytes=tt,root_window_pruning=window)
   assert result['completed_depth']==3 and result['termination_reason']=='completed'
   replay=result['nodes']-result['transition_count']-result['root_iterations_attempted']
   if tt==0 and not window:assert replay==0
   else:assert replay>0
   state=core.initial
   for raw in result['principal_variation']:
    action=public_action(board.native,raw);assert action in legal_actions(state,core.compiled);state=apply_action(state,action,core.compiled)
   assert board.restored()
   row={k:result[k] for k in ('nodes','transition_count','legal_generation_count','root_iterations_attempted','score','completed_depth','tt_probes','tt_hits','tt_cutoffs','elapsed_nanoseconds')}
   selected=public_action(board.native,result['best_action'])
   core.push(selected)
   try:
    import copy
    view=copy.copy(core)
    child_root=(core.runtime.position,tuple(core.runtime.history),core.runtime.depth,core.runtime.ply_count,core.runtime.terminal_status)
    view.restored=lambda: child_root==(core.runtime.position,tuple(core.runtime.history),core.runtime.depth,core.runtime.ply_count,core.runtime.terminal_status)
    child=minimal_ab(view,2,seconds=30,node_limit=1000000,trace=True)
    assert child['reason']=='completed_depth'
   finally:core.pop()
   row['selected_child_exact_D2']=child
   row['selected_root_value_D3']=-child['score']
   row['reported_root_score']=result['score']
   if abs(child['score'])>100000000:
    distance=1000000000-abs(child['score'])+1
    row['normalized_selected_root_value_D3']=(1 if row['selected_root_value_D3']>0 else -1)*(100000000-distance)
   else:row['normalized_selected_root_value_D3']=row['selected_root_value_D3']
   row['selected_value_matches']=row['normalized_selected_root_value_D3']==result['score']
   if name=='chess-ep':
    native_child=semantic_iterative_search(board.native,make_checked(board.native,board.position,result['best_action']),2,max_nodes=1000000,max_time_seconds=30,board_values=values,hand_values=values,root_window_pruning=False,_root_ply_offset=1)
    assert native_child['completed_depth']==2
    row['native_selected_root_value_D3']=-native_child['score']
    assert row['native_selected_root_value_D3']==row['selected_root_value_D3']
   row.update(case=name,tt_megabytes=tt,root_window=window,replay_entry_counter_difference=replay,move=core.label(public_action(board.native,result['best_action'])),pv_legal=True,root_restored=True)
   rows.append(row);print(name,tt,window,replay,result['nodes'],result['transition_count'],flush=True)
 for row in rows:
  if row['case']==name:assert row['score']==next(x['score'] for x in rows if x['case']==name)
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,complete=True)
Path(__file__).with_name('selected-child-contract.json').write_text(json.dumps(report,indent=2)+'\n')
