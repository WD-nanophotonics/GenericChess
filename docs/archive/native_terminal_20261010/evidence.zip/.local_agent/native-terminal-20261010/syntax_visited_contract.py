"""Untimed per-visit contract audit of the existing4096entry bounded trees.
Paired state, full history/events, aux, ordered actions, terminal reason/winner,
leaf score and parent restoration. Uses the existing lexical AB unchanged.
No new samples or deeper budget: same six roots and4096 cutoff. This audit's
wall is instrumentation cost, excluded from published warm timing comparisons.
"""
from pathlib import Path
import sys, json, hashlib
from types import SimpleNamespace
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES,minimal_ab
from scripts.native_backend_bridge import NativeBoard
cache_namespace={'__file__':str(Path(__file__).with_name('syntax_ablation.py'))}
exec(Path(cache_namespace['__file__']).read_text(encoding='utf-8-sig').split('coverage=json.loads')[0],cache_namespace)
CachedSyntax=cache_namespace['CachedSyntax']
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import snapshot,terminal_status,public_action
coverage=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
class Generated:
 def __init__(self,case):
  self.compiled=compile_ruleset_for_execution(ruleset_from_dict(case['rules']))
  s=GameSession(self.compiled)
  for step in case['route'][:3]:s.submit(action_from_dict(step['action']))
  self.initial=s.state;self.witnesses=tuple(s._search_witnesses)
  self.runtime=SearchPathRuntime.from_state(self.initial,self.compiled,history_witnesses=self.witnesses)
  self.label=lambda a:json.dumps(action_to_dict(a),sort_keys=True,separators=(',',':'));self.checkpoint=None
  self.values={p.type_id:0 if p.is_anchor else 100 for p in self.compiled.piece_types}
 actions=CoreBoard.actions;push=CoreBoard.push;pop=CoreBoard.pop;terminal=CoreBoard.terminal;restored=CoreBoard.restored
 def evaluate(self):
  p=self.runtime.position
  return sum((1 if x.owner==p.side_to_move else -1)*self.values[x.current_type_id] for x in p.board if x is not None)+sum((1 if o==p.side_to_move else -1)*self.values[t]*n for o,h in enumerate(p.hands) for t,n in h.items())
class Paired:
 def __init__(self,core,values):
  self.core=core;self.native=CachedSyntax(core,values);self.witnesses=list(core.witnesses)
  self.parents=[];self.digest=hashlib.sha256();self.visits=0;self.restores=0;self.frontiers=0
  self.max_relative_ply=0;self.terminal_types={}
 def check(self):
  s=GameSession(self.core.compiled)
  s._state=SimpleNamespace(position=self.core.runtime.position,ply_count=self.core.runtime.ply_count,history=tuple(self.core.runtime.history))
  s._search_history_witnesses=tuple(self.witnesses)
  expected=pack_semantic_search_position(self.core.compiled,self.native.native,s)
  actual=snapshot(self.native.native,self.native.position)
  assert snapshot(self.native.native,expected)==actual
  self.digest.update(json.dumps(actual,sort_keys=True,separators=(',',':')).encode())
  return actual
 def terminal(self,ply):
  self.check();self.visits+=1;self.max_relative_ply=max(ply,self.max_relative_ply)
  status=terminal_status(self.native.native,self.native.position)
  core_status=self.core.runtime.terminal_status
  assert status['status']==core_status.status.value
  assert status['winner']==core_status.winner
  self.terminal_types[status['status']]=self.terminal_types.get(status['status'],0)+1
  left,right=self.core.terminal(ply),self.native.terminal(ply)
  assert left==right
  return right
 def actions(self):
  a,b=self.core.actions(),self.native.actions()
  assert [x[0] for x in a]==[x[0] for x in b]
  self.frontiers+=1
  return b
 def push(self,raw):
  parent=self.check();self.parents.append((parent,self.core.runtime.position,tuple(self.core.runtime.history)))
  self.core.push(public_action(self.native.native,raw));self.native.push(raw)
  self.witnesses.append(self.core.runtime.position)
 def pop(self):
  self.native.pop();self.core.pop();self.witnesses.pop()
  parent,core_position,core_history=self.parents.pop()
  assert snapshot(self.native.native,self.native.position)==parent
  assert self.core.runtime.position==core_position
  assert tuple(self.core.runtime.history)==core_history
  self.restores+=1
 def evaluate(self):
  a,b=self.core.evaluate(),self.native.evaluate();assert a==b;return b
 def restored(self):return self.core.restored() and self.native.restored() and not self.parents

old=json.loads(Path(__file__).with_name('bridge-assay.json').read_bytes())
out=Path(__file__).with_name('syntax-visited-contract.json')
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
factories=[]
for case in CASES[:4]:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
 factories.append((case['id'],lambda case=case,c=c:CoreBoard(case,c),VALUES['chess']))
for seed in (202610082000,202610082001):
 case=next(c for c in coverage['cases'] if c['seed']==seed)
 factories.append((f'generated-{seed}-ply3',lambda case=case:Generated(case),Generated(case).values))
start=perf_counter()
try:
 for name,factory,values in factories:
  for file in ('rollout.json','advisor.json','slack.json'):
   flags=json.loads((ROOT/'.local_agent'/file).read_bytes());assert not flags.get('stopped') and not flags.get('user_paused')
  paired=Paired(factory(),values)
  # Audit overhead may exceed the old timing fuse: no timing evidence is taken.
  # The4096entry tree/cutoff stays fixed; bounded ten-minute audit fuse only.
  result=minimal_ab(paired,8,seconds=600,node_limit=4096,trace=True)
  ref=next(r for r in old['fixed'] if r['case']==name)
  for key in ('work','move','score','reason','trace_sha256'):assert result[key]==ref[key],(name,key)
  assert paired.visits==4096 and paired.restores==4096
  report['rows'].append(dict(case=name,result=result,visited=paired.visits,parent_restorations=paired.restores,
   ordered_frontiers=paired.frontiers,max_relative_ply=paired.max_relative_ply,terminal_types=paired.terminal_types,
   normalized_state_history_trace_sha256=paired.digest.hexdigest(),root_restored=paired.restored()))
  out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
  print(name,paired.visits,paired.restores,paired.max_relative_ply,result['wall_seconds'],flush=True)
 report['complete']=True
finally:
 report['seconds']=perf_counter()-start;out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
