"""Reaggregate protected_default output against already exposed utility rows.
No teacher calls or source-run changes; absent labels remain UNKNOWN.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2]
p=Path(__file__).with_name('protected-default.json')
d=json.loads(p.read_bytes());u=json.loads((ROOT/'.local_agent/search-attribution-20261010/utility.json').read_bytes())
known={(x['case'],x['move']):x['finite_D4_regret'] for x in u['rows'] if x.get('finite_D4_regret') is not None}
for x in d['rows']:
 x['finite_D4_regret']=known.get((x['case'],x['move']))
 x['finite_D4_basis']='Existing exposed utility rows only; unmatched/generated choices UNKNOWN; no teacher run'
p.write_bytes((json.dumps(d,indent=2)+'\n').encode())
