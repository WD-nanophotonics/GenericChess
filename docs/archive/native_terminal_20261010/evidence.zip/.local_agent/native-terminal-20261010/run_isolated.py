"""Run tests against the isolated v5 kernel, without replacing the installed DLL."""
from pathlib import Path
import importlib.util
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
path=Path(__file__).with_name('_native_core_v5.cp312-win_amd64.pyd')
spec=importlib.util.spec_from_file_location('generic_chess._native_core',path)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
import generic_chess.native as native
native._MODULE=module
sys.modules['generic_chess._native_core']=module
if __name__=='__main__':
 import pytest
 raise SystemExit(pytest.main(sys.argv[1:]))
