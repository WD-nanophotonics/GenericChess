"""Exposed-development algorithm/backend comparison, not equal-work speedup.
Three preselected roots: existing Chess EP plus generated2000/2001 ply3. Two
reversed repeats at0.25/1/2seconds, D12/100000node fuse. Bare lexical Python AB,
cached-syntax bare AB and installed packed-order C iterative; C TT0, q0, absent
dynamic features, root pruning off. Same material and complete root history;
different order, iteration/work definitions explicitly retained. Setup excluded;
PV/choice legality/restoration audited after timing. Decision: does representation
improvement account for algorithm completion/choice differences? Approximate
incremental runtime below2min; no frozen teacher/test extensions or fit.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('syntax_ablation.py'))}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('coverage=json.loads')[0],ns)
CachedSyntax=ns['CachedSyntax'];GeneratedBoard=ns['GeneratedBoard']
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES,iterative_minimal
from scripts.native_backend_bridge import NativeBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
from scripts.unfamiliar_search import validate_pv
coverage=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
factories=[('chess-ep',lambda:CoreBoard(CASES[3],c),VALUES['chess'])]
for seed in (202610082000,202610082001):
 case=next(x for x in coverage['cases'] if x['seed']==seed)
 factories.append((f'generated-{seed}-ply3',lambda case=case:GeneratedBoard(case),GeneratedBoard(case).values))
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=Path(__file__).with_name('algorithm-curve.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def stopped():
 for name in ('rollout.json','advisor.json','slack.json'):
  flags=json.loads((ROOT/'.local_agent'/name).read_bytes())
  if flags.get('user_paused') or flags.get('stopped'):raise RuntimeError('project stopped')
start=perf_counter()
try:
 for name,factory,values in factories:
  for seconds in (.25,1,2):
   for repeat,modes in enumerate((('bare','syntax','c_iterative'),('c_iterative','syntax','bare'))):
    for mode in modes:
     stopped();t=perf_counter();core=factory();board=NativeBoard(core,values)
     if mode=='c_iterative':
      session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
      engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=0)
      setup=perf_counter()-t;t=perf_counter()
      result=engine.search(session,SearchLimits(max_depth=12,max_nodes=100000,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=False)
      wall=perf_counter()-t
      row=record_value(asdict(result));row['move']=None if result.action is None else core.label(result.action);row['wall_seconds']=wall
      validate_pv(session,result)
      assert session.state==core.initial and tuple(session._search_witnesses)==core.witnesses
     else:
      if mode=='syntax':board=CachedSyntax(core,values)
      setup=perf_counter()-t
      row=iterative_minimal(board,seconds=seconds,node_limit=100000,max_depth=12)
     assert board.restored()
     assert row['move'] in {label for label,_ in core.actions()}
     row.update(case=name,backend=mode,budget_seconds=seconds,repeat=repeat,setup_seconds=setup,legal=True,root_restored=True)
     report['rows'].append(row);save()
     print(name,seconds,repeat,mode,row['move'],row['completed_depth'],round(row['wall_seconds'],4),flush=True)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
