# Proposed exact root-tie repair; not an implemented C fix

Observed EP counterexample: complete D3 ON selects f1e2 with reported100 but independently complete child D2 value0; OFF selects f1d3/100. TT0 and cold64 both reproduce. Generated2000 mate scale/distance difference normalizes correctly. Installed binary hash establishes observation, not source-to-build identity.

Source hypothesis: native_module.c5368-5388 narrows later root child windows, then canonical equal-score replacement ignores evidence type;5406-5434 replays selected branch but discards value. This does not prove that all failures have this cause.

Keep one exact incumbent. A root-perspective UPPER below best cannot win; equal UPPER can replace only after full-window exact verification, and only when the canonical order would prefer it. An exact higher value updates score/action/PV together. A non-exact higher estimate also needs verification before authoritative replacement. TT bound type/depth/history/evaluator/q/extension semantics must survive replay; a second bound is not EXACT. Declaration precedence remains the existing canonical rule.

Verification cutoff cannot install an unverified replacement or label that iteration completed. Preserve the last completed iteration/fallback under the existing cancellation contract. Do not exceed the original shared node/time budget to manufacture exactness. Post-selection PV replay must validate its value or explicitly reject the iteration; legal PV alone is insufficient.

Minimal future validation: existing EP TT0/cold/warm TT; true exact tie with preferred canonical action; upper-bound equality with lower exact value; reversed traversal; exhausted re-search budget; selected child exact score, maximum, canonical tie, PV and root restoration separately. Preserve mate scale and root-relative distance. No production C implementation/build is asserted. Terminal-v5 candidate is separate and does NOT contain this repair.
