"""New transfer premise: unused dynamic scheduling on two full-history generated roots.
Same installed kernel, material tables, q0, TT0, no root pruning. Two reversed
512node/D8/2second pairs. One100call primitive pass in each order. Equal results
and work are required; capped controls stay visible, no resource increase.
"""
from pathlib import Path
import sys, json, hashlib
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.native import _module
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import evaluate,terminal_status,guarded_actions,snapshot
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
from scripts.unfamiliar_search import validate_pv
source=ROOT/'.local_agent/generated6-20261008/coverage.json'
coverage=json.loads(source.read_bytes())
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(Path(_module().__file__).read_bytes()).hexdigest(),
 payload_version=_module().native_capabilities()['semantic_payload_version'],rows=[],primitives=[],complete=False)
out=Path(__file__).with_name('generated-zero-features.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def stopped():
 for file in ('rollout.json','advisor.json','slack.json'):
  f=json.loads((ROOT/'.local_agent'/file).read_bytes())
  if f.get('stopped') or f.get('user_paused'):raise RuntimeError('project stopped')
start=perf_counter()
try:
 for seed in (202610082000,202610082001):
  stopped()
  case=next(c for c in coverage['cases'] if c['seed']==seed)
  compiled=compile_ruleset_for_execution(ruleset_from_dict(case['rules']))
  session=GameSession(compiled)
  for step in case['route'][:3]:session.submit(action_from_dict(step['action']))
  before=(session.state,session.history,tuple(session._search_witnesses))
  native=compile_native_semantic_rules(compiled)
  packed=pack_semantic_search_position(compiled,native,session);snap=snapshot(native,packed)
  values={p.type_id:0 if p.is_anchor else 100 for p in compiled.piece_types}
  table=tuple(values[t] for t in native.type_ids)
  ops={'terminal':lambda:terminal_status(native,packed),'guarded':lambda:guarded_actions(native,packed),
       'material_absent':lambda:evaluate(native,packed,board_values=table,hand_values=table),
       'material_zero':lambda:evaluate(native,packed,board_values=table,hand_values=table,dynamic_values=(0,0,0))}
  outputs={k:fn() for k,fn in ops.items()}
  assert outputs['material_absent']==outputs['material_zero']
  for names in (list(ops),list(reversed(ops))):
   for name in names:
    stopped();t=perf_counter()
    for _ in range(100):assert ops[name]()==outputs[name]
    report['primitives'].append(dict(seed=seed,operation=name,calls=100,seconds=perf_counter()-t,order=names))
    save()
  for repeat,order in enumerate(((None,(0,0,0)),((0,0,0),None))):
   for dynamic in order:
    stopped()
    engine=SemanticSearchEngine(compiled,native,board_values=values,hand_values=values,dynamic_values=dynamic,tt_megabytes=0)
    t=perf_counter();result=engine.search(session,SearchLimits(max_depth=8,max_nodes=512,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=False)
    validate_pv(session,result)
    row=dict(seed=seed,rule_fingerprint=compiled.ruleset_fingerprint,dynamic=dynamic,repeat=repeat,seconds=perf_counter()-t,result=record_value(asdict(result)))
    report['rows'].append(row);save()
    assert before==(session.state,session.history,tuple(session._search_witnesses))
    assert snapshot(native,packed)==snap
    print(seed,repeat,dynamic,result.completed_depth,result.nodes,row['seconds'],flush=True)
  rows=[r for r in report['rows'] if r['seed']==seed]
  fields=('action','decision_line','score','principal_variation','completed_depth','nodes','termination_reason')
  signatures=[{k:r['result'].get(k) for k in fields} for r in rows]
  assert all(s==signatures[0] for s in signatures)
 report['complete']=True
finally:
 report['seconds']=perf_counter()-start;save()
