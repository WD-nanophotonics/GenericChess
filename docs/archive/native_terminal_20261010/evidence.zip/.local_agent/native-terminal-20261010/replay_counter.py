"""Can existing raw counters observe canonical PV replay without expensive trace?
Installed kernel, completeD3 calls on existingEP/generated2000; TT0/64MiB,
root-windowOFF/ON factorial, exactmaterial/history, traceOFF. Source recurrence
predicts nodes-transition_count-root_iterations_attempted counts replay-entry
calls when no budget abort occurs: ordinary recursive calls increment transition
before entry, explicit canonical-PV replay entry does not. This counts entry
events, NOT all replay subtree nodes or replay time. OFF+TT0 must yieldzero.
Same-rule completed scores/PV legality/restoration required. No kernel changes,
source/build attestation claim, training or default adoption. Estimated<10sec.
"""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('algorithm_curve.py'))}
exec(Path(ns['__file__']).read_text().split('report=dict')[0],ns)
from generic_chess.native.semantic import semantic_iterative_search,public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
rows=[]
for name,factory,values in ns['factories'][:2]:
 for tt in (0,64):
  for window in (False,True):
   core=factory();board=ns['NativeBoard'](core,values)
   result=semantic_iterative_search(board.native,board.position,3,max_nodes=1000000,max_time_seconds=30,board_values=values,hand_values=values,tt_megabytes=tt,root_window_pruning=window)
   assert result['completed_depth']==3 and result['termination_reason']=='completed'
   replay=result['nodes']-result['transition_count']-result['root_iterations_attempted']
   if tt==0 and not window:assert replay==0
   else:assert replay>0
   state=core.initial
   for raw in result['principal_variation']:
    action=public_action(board.native,raw);assert action in legal_actions(state,core.compiled);state=apply_action(state,action,core.compiled)
   assert board.restored()
   row={k:result[k] for k in ('nodes','transition_count','legal_generation_count','root_iterations_attempted','score','completed_depth','tt_probes','tt_hits','tt_cutoffs','elapsed_nanoseconds')}
   row.update(case=name,tt_megabytes=tt,root_window=window,replay_entry_counter_difference=replay,move=core.label(public_action(board.native,result['best_action'])),pv_legal=True,root_restored=True)
   rows.append(row);print(name,tt,window,replay,result['nodes'],result['transition_count'],flush=True)
 for row in rows:
  if row['case']==name:assert row['score']==next(x['score'] for x in rows if x['case']==name)
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,complete=True)
Path(__file__).with_name('replay-counter.json').write_text(json.dumps(report,indent=2)+'\n')
