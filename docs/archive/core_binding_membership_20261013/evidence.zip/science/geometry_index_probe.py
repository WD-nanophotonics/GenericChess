from generic_chess.core import semantic_executor as se
old=se.SemanticEngine._path_for_geometry
mode='off';metrics={}
def reset(value):
    global mode,metrics
    mode=value;metrics=dict(calls=0,shadow=0,missing=0,matched=0)
def direct(self,gid,source,target,side):
    geometry=self.ir.geometry.get(gid)
    if geometry is None or geometry.kind=='drop':return None
    path=geometry.paths.get(str(side),{}).get(source,())
    if geometry.kind=='leap':return () if path and path[0]==target else None
    start=max(0,(geometry.min_steps or 1)-1)
    try:index=path.index(target,start)
    except ValueError:return None
    return path[:index]
def traced(self,gid,source,target,side):
    metrics['calls']+=1;value=direct(self,gid,source,target,side)
    metrics['missing' if value is None else 'matched']+=1
    if mode=='shadow':assert value==old(self,gid,source,target,side);metrics['shadow']+=1
    return value
def install(value):
    reset(value)
    if value!='off':se.SemanticEngine._path_for_geometry=traced if value=='shadow' else direct
def restore():se.SemanticEngine._path_for_geometry=old
