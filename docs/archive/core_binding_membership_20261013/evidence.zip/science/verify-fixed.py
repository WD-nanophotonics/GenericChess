from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from tools.local_agent import session
D=Path('.local_agent/write-footprint-20261013')
r=json.loads((D/'cost-fixed/rows.json').read_text(encoding='utf-8'));sh=json.loads((D/'shadow/rows.json').read_text(encoding='utf-8'))
assert r['complete'] and len(r['rows'])==8 and sh['complete'] and len(sh['rows'])==1
sig=lambda x:{k:v for k,v in x['decision'].items() if not(k.endswith('_seconds') or k.startswith('time_to_'))}
checks=[];cost=[]
for seed in [2026101455,2026101514]:
    group=[x for x in r['rows'] if x['seed']==seed];assert all(sig(x)==sig(group[0]) for x in group)
    for rep in range(2):
        a=next(x for x in group if x['repeat']==rep and x['enabled']=='off');b=next(x for x in group if x['repeat']==rep and x['enabled']=='candidate')
        assert b['footprint']['hits']==b['check']['queries'] and b['footprint']['misses']==0
        cost.append(dict(seed=seed,repeat=rep,baseline=a['wall'],candidate=b['wall'],saved_percent=100*(1-b['wall']/a['wall']),hash_calls=b['footprint']['hits'],visited_cells=b['footprint']['visited']))
    checks.append(dict(seed=seed,all4_nontime_exact=True,root_history_restore=True,all_pv_actions_core_replayed=True))
assert sig(sh['rows'][0])==sig(next(x for x in r['rows'] if x['seed']==2026101514))
assert sh['rows'][0]['footprint']['shadow']==68930 and sh['rows'][0]['footprint']['misses']==0
v=dict(actual_search_calls=9,checks=checks,costs=cost,hash_shadow=sh['rows'][0]['footprint'],zeroquery_first_exec_namespace_failure_retained=True,default_production_changed=False,decision='Private exactwrites viable but current wholecall gain only0.35-1.75percent, collection/interface lifecycle overhead substantial; defer productionintegration. Next existingtargetdirectgeometry alreadyavailable, no newcache/framework.',scope='These2existingroots and fullhash shadow on1514 only. Shadow actual budget60s; cloned declaration seconds30 stale metadata retained/corrected here, not time comparison.')
(D/'verification.json').write_bytes((json.dumps(v,indent=2)+'\n').encode())
s=json.loads(Path('.local_agent/session.json').read_text(encoding='utf-8'));m=Path('.local_agent/NEXT_WORK.md').read_text(encoding='utf-8');m=m.replace(m.splitlines()[1],f"Segment: ACTIVE {s['id']} UTC{s['started_at']}; original clock;9searches exact-write private feasibility closed.")
Path('.local_agent/NEXT_WORK.md').write_bytes(m.encode())
session.checkpoint('Does an exact set_piece write observer make full component hashing cheap enough to integrate?', 'Eightfixed cost calls allnontime/fullhistory/PV/workexact;1fullhashshadow68930children, no footprintmiss; actuallocal gain0.35-1.75percent. Reject existingevents and defernewfootprint plumbing on information/interfacecost; completehand/aux nonboardscan remains. Startup exec namespace missing observer was zeroquery, fixedandretained. AUXfixed33 report read-only, no learningadoption.',str(D/'verification.json'),'Beginexistinggeometry_paths_to finitefirst-match equivalence and actualnativebinding shadow/cost; preservefullfrontier validation/error and no lazybinding framework.')
print(v)
