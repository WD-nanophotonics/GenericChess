from pathlib import Path
import sys,json,dataclasses,random,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from scripts import full_q_refresh_comparison as p
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import semantic_executor as se
from generic_chess.rules.ir import CompiledGeometry,geometry_candidates
import geometry_probe as probe
from scripts.research_record import write_record
D=Path('.local_agent/write-footprint-20261013')
assert not (D/'geometry-finite-plan.json').exists()
write_record(D/'geometry-finite-plan.json',dict(question='Does existing targetdirect helper preserve firstmatched exact compiled path across alltargets and geometries?',builtin=['western_chess','standard_shogi'],generated_seeds=[2026101601,2026101602,2026101603,2026101604],owners=[0,1],sources='allboard',targets='-1 through boardcells inclusive',search_calls=0,synthetic='repeatedtarget/minsteps/leap/drop/missinggeometry',no_resample=True))
rows=[];total=0
for name in ['western_chess','standard_shogi',2026101601,2026101602,2026101603,2026101604]:
    if isinstance(name,str):c=compile_ruleset_for_execution(build_builtin_ruleset(name))
    else:
        g=p.generate_game(p.GeneratorConfig(seed=name,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
    engine=se.semantic_engine_for(c);checks=0;shape=c.support.board_shape
    n=shape.width*shape.height
    for gid in engine.ir.geometry:
        for side in (0,1):
            for source in range(n):
                for target in range(-1,n+1):
                    assert probe.old(engine,gid,source,target,side)==probe.direct(engine,gid,source,target,side),(name,gid,side,source,target)
                    checks+=1
    rows.append(dict(case=name,geometries=len(engine.ir.geometry),comparisons=checks));total+=checks
    print(name,checks,flush=True)
from types import SimpleNamespace
synthetic=[]
for kind in ['ray','leap','drop']:
    for minimum in [1,2,4]:
        g=CompiledGeometry('synthetic',kind,min_steps=minimum,paths={'0':{0:(1,2,1,3)}})
        engine=SimpleNamespace(ir=SimpleNamespace(geometry={'synthetic':g}))
        for target in [-1,0,1,2,3,4]:
            a=probe.old(engine,'synthetic',0,target,0);b=probe.direct(engine,'synthetic',0,target,0);assert a==b
            synthetic.append(dict(kind=kind,min_steps=minimum,target=target,path=b))
assert probe.direct(engine,'missing',0,1,0) is None
write_record(D/'geometry-finite-results.json',dict(search_calls=0,comparisons=total,rows=rows,synthetic=synthetic,first_path_equivalent=True,complete_generated_domain_proof=False))
print('all',total,'equal')
