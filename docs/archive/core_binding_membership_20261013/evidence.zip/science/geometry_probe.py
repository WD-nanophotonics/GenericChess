from generic_chess.core import semantic_executor as se
old=se.SemanticEngine._path_for_geometry
mode='off';metrics={}
def reset(value):
    global mode,metrics
    mode=value;metrics=dict(calls=0,shadow=0,missing=0,matched=0)
def direct(self,gid,source,target,side):
    geometry=self.ir.geometry.get(gid)
    if geometry is None or geometry.kind=='drop':return None
    return next(se.geometry_paths_to(geometry,str(side),source,target),None)
def traced(self,gid,source,target,side):
    metrics['calls']+=1;value=direct(self,gid,source,target,side)
    metrics['missing' if value is None else 'matched']+=1
    if mode=='shadow':assert value==old(self,gid,source,target,side);metrics['shadow']+=1
    return value
def install(value):
    reset(value)
    if value!='off':se.SemanticEngine._path_for_geometry=traced if value=='shadow' else direct
def restore():se.SemanticEngine._path_for_geometry=old
