from pathlib import Path
import sys,json,time,random,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
import membership_source as source
D=Path('.local_agent/write-footprint-20261013');out=D/'membership-fresh';out.mkdir(exist_ok=True)
assert not (out/'declaration.json').exists()
decl=dict(question='Does actualsource membership transfer through bothCore andNative completefrontier routes on new unfamiliar rules?',seeds=list(range(2026101731,2026101735)),board_size=8,hybrid=True,setup='bilateral_random',prefix=8,rng_offset=13000,backend_requested=[False,True],qdepths=[0,4],depths=[2,1],seconds=8,hardq=8,orders=2,arms=['actual_before','actual_after'],cells=64,max_requested_seconds=512,whole_fuse_seconds=850,no_resample=True,scope='Newgeneratedcohort notfull-domainproof; fullpromotions/drops/aux/history preserved, no humanprices/holdout/fit. Comparewholework onlywithin same actualbackend/q; keep all capped/unavailable cases. Nativeevaluator fixedbotharms; compilecostseparate setup; ordinaryconcurrentload.')
write_record(out/'declaration.json',decl)
start=time.perf_counter();rows=[];samples=[];unavailable=[];roots=[]
for seed in decl['seeds']:
    p.rr.stopped()
    try:
        g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
        c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=SemanticAttackEvaluator(c,profile,ec,backend='native')
        s=p.GameSession(c);rng=random.Random(seed+13000);walk=[]
        for _ in range(8):
            acts=sorted(s.legal_actions(),key=repr)
            if s.result.status.value!='ongoing' or not acts:raise ValueError('prefixunavailable')
            a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
        if s.result.status.value!='ongoing':raise ValueError('rootterminal')
        roots.append((seed,c,s,ev));samples.append(dict(seed=seed,state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk))
    except (ValueError,RuntimeError,NotImplementedError) as e:
        unavailable.append(dict(seed=seed,error_type=type(e).__name__,error=str(e),unexecuted_cells=16,resampled=False))
write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable))
runtimes=[];old_attach=SearchPathRuntime.attach_stats
def attach(rt,stats):old_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)))
SearchPathRuntime.attach_stats=attach
try:
    for seed,c,s,ev in roots:
        before=s.to_record()
        for backend in [False,True]:
            for q,depth in [(0,2),(4,1)]:
                for rep in range(2):
                    for arm in (['off','candidate'] if rep==0 else ['candidate','off']):
                        p.rr.stopped()
                        if time.perf_counter()-start>=850:raise RuntimeError('fuse, preservepartial')
                        source.install(arm);runtimes.clear()
                        player=AlphaBetaPlayer(c,evaluator_override=ev,tt_max_entries=250000,use_disk_cache=False,use_native_semantic_legality=backend,use_native_semantic_availability=backend,use_native_semantic_check=backend,tuning=SearchTuning(use_ordered_qsearch=True,use_ordered_qsearch_in_check=False))
                        t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_time_seconds=8,max_nodes=None,quiescence_max_depth=q,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
                        assert before==s.to_record()
                        for rt,snap in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==snap
                        child=s.state
                        for a in d.principal_variation:
                            assert a in legal_actions(child,c);child=apply_action(child,a,c)
                        rows.append(dict(seed=seed,requested_backend=backend,q=q,depth_requested=depth,repeat=rep,arm=arm,wall=wall,actual_provider=player.native_legality_provider is not None,decision=record_value(d),full_history_restored=True,pv_core_legal=True))
                        write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable))
                        print(seed,backend,q,rep,arm,d.completed_depth,d.score,d.termination_reason,d.nodes,d.qnodes,round(wall,4),flush=True)
finally:source.restore();SearchPathRuntime.attach_stats=old_attach
write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
