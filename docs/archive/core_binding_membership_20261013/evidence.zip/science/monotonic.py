from pathlib import Path
import sys,json,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.actions import action_to_dict
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
D=Path('.local_agent/write-footprint-20261013')
assert not (D/'monotonic-plan.json').exists()
write_record(D/'monotonic-plan.json',dict(question='Can full legalaction lists be assumed monotonic under same-actor two-ply continuation?',cases=['western_chess','standard_shogi',2026101732,2026101734],prefix=8,continuation=2,rng_offset=13000,search_calls=0,assumed_classifier='side_to_move only',decision='A newly legalcomplete action rejects blanketmonotonic frontier reuse; doesnotrefute speciallycompiled monotonicclasses or alter sampling. No newcache/framework.'))
rows=[]
for case in ['western_chess','standard_shogi',2026101732,2026101734]:
    if isinstance(case,str):c=compile_ruleset_for_execution(build_builtin_ruleset(case));seed=2026101732
    else:
        g=p.generate_game(p.GeneratorConfig(seed=case,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);seed=case
    s=p.GameSession(c);rng=random.Random(seed+13000);walk=[]
    for _ in range(8):
        if s.result.status.value!='ongoing':break
        acts=sorted(s.legal_actions(),key=repr)
        if not acts:break
        a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
    before=s.state;old=s.legal_actions();steps=[]
    for _ in range(2):
        acts=sorted(s.legal_actions(),key=repr)
        if s.result.status.value!='ongoing' or not acts:break
        a=rng.choice(acts);steps.append(record_value(a));s.submit(a)
    after=s.state;new=s.legal_actions();added=[a for a in new if a not in old];removed=[a for a in old if a not in new]
    rows.append(dict(case=case,prefix=walk,continuation=steps,parent=record_value(before),child=record_value(after),old_actions=record_value(old),new_actions=record_value(new),old_count=len(old),new_count=len(new),added=record_value(added),removed=record_value(removed),same_actor=before.position.side_to_move==after.position.side_to_move,complete_two_ply=len(steps)==2,subset=not added))
assert any(x['same_actor'] and x['complete_two_ply'] and x['added'] for x in rows)
write_record(D/'monotonic-results.json',dict(search_calls=0,actual_continuations=len(rows),rows=rows,side_only_monotonic_reuse_rejected=True,unchanged_sampling=True,source='RBG2006.08295 sectionIII monotonicclassifier is conditional; no borrowedspeedfactor'))
print([(x['case'],x['old_count'],x['new_count'],len(x['added']),x['same_actor']) for x in rows])
