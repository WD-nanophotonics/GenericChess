from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
import membership_probe as observer
src=Path('.local_agent/tt-transfer-20261013/heavy_public.py').read_text(encoding='utf-8')
src=src.replace("D=Path('.local_agent/tt-transfer-20261013');out=D/'heavy_public'","D=Path('.local_agent/write-footprint-20261013');out=D/'membership-cost'")
src=src.replace("flags=[False,True]","flags=['off','candidate']").replace("use_native_semantic_check=enabled","use_native_semantic_check=True")
src=src.replace("([False,True] if rep==0 else [True,False])","(['off','candidate'] if rep==0 else ['candidate','off'])")
src=src.replace("t=time.perf_counter();value=player.choose_action", "observer.install(enabled)\n                    t=time.perf_counter();value=player.choose_action")
src=src.replace("assert s.to_record()==before","observer.restore()\n                    assert s.to_record()==before")
src=src.replace("check={} if provider is None else provider.check_metrics,decision=", "check={} if provider is None else provider.check_metrics,footprint=dict(observer.metrics),decision=")
src=src.replace("Does the actual flag provide net wholecall gain on two existing heavy mixed-q4 publicconsumers?", "Can current alreadycomplete semantic binding dict eliminate repeated legal tuple scanning without adding a cache?")
try:exec(compile(src,__file__,'exec'),dict(__name__='__main__',__file__=__file__,observer=observer))
finally:observer.restore()
