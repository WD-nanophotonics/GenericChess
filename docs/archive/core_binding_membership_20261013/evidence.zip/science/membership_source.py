from pathlib import Path
import sys,json,ast,textwrap,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from generic_chess.core import search_runtime as sr
before=Path('.local_agent/write-footprint-20261013/before-membership-search-runtime.py').read_text(encoding='utf-8')
node=next(n for cl in ast.parse(before).body if isinstance(cl,ast.ClassDef) and cl.name=='SearchPathRuntime' for n in cl.body if isinstance(n,ast.FunctionDef) and n.name=='_push_impl')
method=textwrap.dedent('\n'.join(before.splitlines()[node.lineno-1:node.end_lineno]))
ns=dict(sr.__dict__);exec(method,ns);old=ns['_push_impl'];current=sr.SearchPathRuntime._push_impl
def install(value):
    if value=='off':sr.SearchPathRuntime._push_impl=old
    else:sr.SearchPathRuntime._push_impl=current
def restore():sr.SearchPathRuntime._push_impl=current
metrics={}
