from pathlib import Path
import sys,json,time,random,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
import membership_source as source
D=Path('.local_agent/write-footprint-20261013');out=D/'membership-resource';out.mkdir(exist_ok=True)
assert not (out/'declaration.json').exists()
decl=dict(question='Does the measured membership work reduction buy a completed retained decision or only more unfinished work?',seeds=[2026101455,2026101514],budgets=[4,16,64],max_depth=12,max_nodes=None,q=4,hardq=8,orders=2,arms=['actual_before','actual_after'],cells=24,whole_fuse_seconds=1100,expected_max_requested_seconds=672,incremental_cost='About12minutes singlebounded producer; outcomes can support/defer completed-decision benefit withoutbudgethunting. No extension afterresults.',unchanged_old_30s_fixed_results=True,scope='Two exposed existing generated prefix8 consumers, fullIR/promotion/drop/aux/history retained; resourcecurve notnewholdout or strengthclaim. Ordinary concurrentload; no extra worker/fees, Nativecheck/availability/evaluation same botharms.',source_before_sha256=hashlib.sha256(Path('.local_agent/write-footprint-20261013/before-membership-search-runtime.py').read_bytes()).hexdigest(),source_after_sha256=hashlib.sha256(Path('generic_chess/core/search_runtime.py').read_bytes()).hexdigest())
write_record(out/'declaration.json',decl)
start=time.perf_counter();roots=[];samples=[];rows=[];unavailable=[]
for seed in decl['seeds']:
    p.rr.stopped()
    try:
        g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
        c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support)
        ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=SemanticAttackEvaluator(c,profile,ec,backend='native')
        s=p.GameSession(c);rng=random.Random(seed+(13000 if seed==2026101455 else 15000));walk=[]
        for _ in range(8):
            acts=sorted(s.legal_actions(),key=repr)
            if s.result.status.value!='ongoing' or not acts:raise ValueError('unavailable prefix')
            a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
        if s.result.status.value!='ongoing':raise ValueError('terminal declaredroot')
        roots.append((seed,c,s,ev));samples.append(dict(seed=seed,state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk))
    except (ValueError,RuntimeError,NotImplementedError) as e:
        unavailable.append(dict(seed=seed,error_type=type(e).__name__,error=str(e),resampled=False,unexecuted_cells=12))
write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable))
runtimes=[];old_attach=SearchPathRuntime.attach_stats
def attach(rt,stats):
    old_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)))
SearchPathRuntime.attach_stats=attach
try:
    for seed,c,s,ev in roots:
        before=s.to_record()
        for seconds in decl['budgets']:
            for rep in range(2):
                for arm in (['off','candidate'] if rep==0 else ['candidate','off']):
                    p.rr.stopped()
                    if time.perf_counter()-start>=decl['whole_fuse_seconds']:raise RuntimeError('producer fuse; retain partial')
                    source.install(arm);runtimes.clear()
                    player=AlphaBetaPlayer(c,evaluator_override=ev,tt_max_entries=250000,use_disk_cache=False,use_native_semantic_availability=True,use_native_semantic_check=True,tuning=SearchTuning(use_ordered_qsearch=True,use_ordered_qsearch_in_check=False))
                    t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=12,max_time_seconds=seconds,max_nodes=None,quiescence_max_depth=4,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
                    assert s.to_record()==before
                    for rt,snap in runtimes:rt.assert_balanced();assert p.runtime_state(rt)==snap
                    child=s.state
                    for a in d.principal_variation:
                        assert a in legal_actions(child,c);child=apply_action(child,a,c)
                    rows.append(dict(seed=seed,seconds=seconds,repeat=rep,arm=arm,wall=wall,decision=record_value(d),root_history_restored=True,pv_core_legal=True,actual_provider=player.native_legality_provider is not None))
                    write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable))
                    print(seed,seconds,rep,arm,d.completed_depth,d.score,d.termination_reason,d.nodes,d.qnodes,round(wall,4),flush=True)
finally:
    source.restore();SearchPathRuntime.attach_stats=old_attach
write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
