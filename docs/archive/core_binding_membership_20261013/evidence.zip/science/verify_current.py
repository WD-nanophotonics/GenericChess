from pathlib import Path
import json,sys,xml.etree.ElementTree as E
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from tools.local_agent import session
D=Path('.local_agent/write-footprint-20261013')
sig=lambda x:{k:v for k,v in x['decision'].items() if not(k.endswith('_seconds') or k.startswith('time_to_'))}
out={};total=0
for name,count in [('geometry-index-cost',8),('membership-cost',8),('membership-source-cost',8)]:
    r=json.loads((D/name/'rows.json').read_text(encoding='utf-8'));assert r['complete'] and len(r['rows'])==count
    costs=[]
    for seed in [2026101455,2026101514]:
        g=[x for x in r['rows'] if x['seed']==seed];assert all(sig(x)==sig(g[0]) for x in g)
        for rep in range(2):
            a=next(x for x in g if x['repeat']==rep and x['enabled']=='off');b=next(x for x in g if x['repeat']==rep and x['enabled']=='candidate')
            costs.append(dict(seed=seed,repeat=rep,before_seconds=a['wall'],after_seconds=b['wall'],saved_percent=100*(1-b['wall']/a['wall'])))
    out[name]=dict(search_calls=count,costs=costs,all_nontime_work_output_exact=True,all_pvs_core_legal=True,full_history_restored=True);total+=count
r=json.loads((D/'membership-shadow/rows.json').read_text(encoding='utf-8'));assert r['complete'] and len(r['rows'])==1 and r['rows'][0]['footprint']['shadow']==68930
out['membership_shadow']=r['rows'][0]['footprint'];total+=1
r=json.loads((D/'membership-resource/rows.json').read_text(encoding='utf-8'));assert r['complete'] and len(r['rows'])==24
pairs=[]
for seed in [2026101455,2026101514]:
    for seconds in [4,16,64]:
        for rep in range(2):
            g=[x for x in r['rows'] if (x['seed'],x['seconds'],x['repeat'])==(seed,seconds,rep)]
            a=next(x for x in g if x['arm']=='off');b=next(x for x in g if x['arm']=='candidate')
            signature=lambda x:tuple(x['decision'][k] for k in ('action','score','principal_variation','completed_depth','result_source'))
            equal=signature(a)==signature(b)
            pairs.append(dict(seed=seed,seconds=seconds,repeat=rep,retained_tuple_equal=equal,before_depth=a['decision']['completed_depth'],after_depth=b['decision']['completed_depth'],attempted_work_ratio=(b['decision']['nodes']+b['decision']['qnodes'])/(a['decision']['nodes']+a['decision']['qnodes'])))
assert all(x['retained_tuple_equal'] for x in pairs)
out['resource']=dict(search_calls=24,pairs=pairs,all_retained_tuple_equal=True,producer_seconds=r['elapsed_seconds'],raw_curves_not_extended=True);total+=24
# 9footprint +9helper are separately verified, included once.
out['actual_search_calls']=total+9+9
assert out['actual_search_calls']==67
out['path_shadow_correction']='Earlier checkpoint said138399 bindings: actual helper path shadow83595;138399 was priorprofile total binding factory calls including drops. Original checkpoint kept; actual JSON always83595.'
out['finite_path_comparisons_per_candidate']=2400822
for filename in ['pytest-full-private.xml','pytest-membership-fixed-private.xml']:
    suites=E.parse(D/filename).getroot()
    out[filename]=[dict(x.attrib) for x in suites]
out['decision']='Adopt minimalexistingbindingdict membership only after completeoutput/history/error/equalcopy checks; footprint/newgeometryhelpers private/deferred. No horizon benefit demonstrated by24-cell actualresourcecurve, no strength or globalCPUclaim.'
(D/'current-validation.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
session.checkpoint('Does existing complete binding membership preserve semantics and buy completed delivery?',
'Private8cost+68930pushshadow/actualsource8cost arefullnontimeexact.8 focusednew/error/equalcopy+existing146checks pass; earlierfull2343pass predates6equalcopychecks. Actual24 resourcecells at4/16/64seconds preserveall12 retainedtuples/depth; moreattemptedwork notdecisiongain. Geometrytuple-index8call tinycost deferred; pathshadow83595 corrects earlier138399factory-call shorthand.67actualsearches closed. Minimaldict route usesexisting complete frontier, no addedcache/lazyvalidation.',
str(D/'current-validation.json'),'Beginfresh4rule actualsource Core/Native q0/q4 parity qualification; publish reviewedsource, evidence and userrequestedauthorization/manual/nativeprompt clarification at checkpoint, thenselectnext substantive consumer.')
print('67 actualsearches closed; resource12tuples/depth exact',out['membership-source-cost']['costs'])
