import inspect
from generic_chess.core import semantic_executor as se,search_runtime as sr
old_cls=se._WorkingPosition;old_diff=sr._semantic_component_diff_hash
slot=None;mode='off';metrics={}
def reset(value):
    global mode,slot,metrics
    mode=value;slot=None;metrics=dict(transitions=0,hash_calls=0,hits=0,misses=0,shadow=0,changed=0,visited=0)
class Observed(old_cls):
    def __init__(self,parent,support):
        super().__init__(parent,support);self.parent=parent;self.writes=set()
    def set_piece(self,index,piece):
        self.writes.add(index);super().set_piece(index,piece)
    def to_position(self,aux,fingerprint):
        global slot
        child=super().to_position(aux,fingerprint)
        slot=(self.parent,child,self.writes);metrics['transitions']+=1
        return child
src=inspect.getsource(old_diff).replace('def _semantic_component_diff_hash(parent: Position, child: Position, compiled, current: RuntimeHash)', 'def footprint_diff(parent: Position, child: Position, compiled, current: RuntimeHash, indices)')
src=src.replace('for index, (left, right) in enumerate(zip(parent.board, child.board)):', 'for index in indices:\n        left, right = parent.board[index], child.board[index]')
ns=dict(sr.__dict__);exec(src,ns);candidate=ns['footprint_diff']
def diff(parent,child,compiled,current):
    global slot
    pending=slot;slot=None;metrics['hash_calls']+=1
    if pending is None or pending[0] is not parent or pending[1] is not child:
        metrics['misses']+=1;return old_diff(parent,child,compiled,current)
    indices=pending[2];metrics['hits']+=1;metrics['visited']+=len(indices)
    value=candidate(parent,child,compiled,current,indices)
    if mode=='shadow':
        changed={i for i,(a,b) in enumerate(zip(parent.board,child.board)) if a!=b}
        assert changed<=indices,(changed,indices)
        assert value==old_diff(parent,child,compiled,current)==sr._full_runtime_hash(child,compiled)
        metrics['changed']+=len(changed);metrics['shadow']+=1
    return value
def install(value):
    reset(value)
    if value!='off':se._WorkingPosition=Observed;sr._semantic_component_diff_hash=diff
def restore():
    global slot
    se._WorkingPosition=old_cls;sr._semantic_component_diff_hash=old_diff;slot=None
