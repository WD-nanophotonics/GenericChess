import inspect
from generic_chess.core import search_runtime as sr
old=sr.SearchPathRuntime._push_impl
mode='off';metrics={}
def install(value):
    global mode,metrics
    mode=value;metrics=dict(calls=0,shadow=0,dict_membership=0,tuple_fallback=0)
    if value!='off':sr.SearchPathRuntime._push_impl=candidate
def restore():sr.SearchPathRuntime._push_impl=old
def accepted(rt,action,checkpoint):
    legal=rt.legal_actions(checkpoint);metrics['calls']+=1
    if rt._bindings and not isinstance(action,sr.PassAction):
        try:value=action in rt._bindings;metrics['dict_membership']+=1
        except TypeError:value=action in legal;metrics['tuple_fallback']+=1
    else:value=action in legal;metrics['tuple_fallback']+=1
    if mode=='shadow':assert value==(action in legal);metrics['shadow']+=1
    return value
src=inspect.getsource(old).replace('    def _push_impl','def _push_impl',1)
# Dedent actual classmethod body mechanically.
import textwrap
src=textwrap.dedent(inspect.getsource(old))
src=src.replace('if action not in self.legal_actions(checkpoint):','if not accepted(self,action,checkpoint):')
ns=dict(sr.__dict__,accepted=accepted);exec(src,ns);candidate=ns['_push_impl']
