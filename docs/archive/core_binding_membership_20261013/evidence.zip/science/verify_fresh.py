from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from tools.local_agent import session
D=Path('.local_agent/write-footprint-20261013');r=json.loads((D/'membership-fresh/rows.json').read_text(encoding='utf-8'))
assert r['complete'] and len(r['rows'])==48 and len(r['unavailable'])==1
assert r['unavailable'][0]['seed']==2026101731 and r['unavailable'][0]['unexecuted_cells']==16
sig=lambda x:{k:v for k,v in x['decision'].items() if not(k.endswith('_seconds') or k.startswith('time_to_'))}
checks=[]
for seed in [2026101732,2026101733,2026101734]:
    for backend in [False,True]:
        for q in [0,4]:
            g=[x for x in r['rows'] if (x['seed'],x['requested_backend'],x['q'])==(seed,backend,q)]
            assert len(g)==4 and all(sig(x)==sig(g[0]) for x in g)
            assert all(x['actual_provider']==backend for x in g)
            checks.append(dict(seed=seed,backend_requested=backend,q=q,all4_nontime_exact=True,actual_provider=backend,full_root_history_restored=True,all_pvs_core_legal=True))
v=dict(actual_searches=48,declared_cells=64,unexecuted=16,unavailable=r['unavailable'],checks=checks,no_resample=True,total_segment_searches=115,scope='1733 immediatewinning caller retained, no forceddeep iteration. Smallfixedcosts mixed; no generalgain/strengthclaim. Core/Nativepair comparison onlywithin backend.',producer_seconds=r['elapsed_seconds'])
(D/'fresh-validation.json').write_bytes((json.dumps(v,indent=2)+'\n').encode())
s=json.loads(Path('.local_agent/session.json').read_text(encoding='utf-8'))
memo=f'''State: OPEN; user resumed; heartbeat ACTIVE90min; PRIMARY sole sandbox writer; raw project storage authorized, saves resolved.
Segment: ACTIVE {s['id']} UTC{s['started_at']}; original clock;115 research calls closed; user requested authorization clarification is configuration, not research-duration evidence.
Main: does existing bindingdict optimization qualify complete caller semantics? | complete final fullsuite and reviewed115-call archive, then actualremaining consumer cost selection | same fulloutputs/history/error/equalcopy, fresh48+16unavailable, unchanged12resource tuples | publish only minimaldict change; no newcache/lazybinding/footprint framework.
Backup1: can monotonic legal-frontier reuse apply to this generated domain? | construct one real same-actor two-ply counterexample using existingroot actionsets | complete actions, new legal moves, promotion/drop/history authority and paper assumptions | reject blanketreuse or identify one genuine compiled capability; no newinterface/framework.
Backup2: does frozen learned endpoint generalize to fresh opponent RNG? | read AUX fixed33 and all new relevant roots/fullthreads | endpoint-minus-initial weighted/family/unfinished and RNGs separate | interpretation only, no duplicate AUX go/fit/humanholdout or merge.
Evidence: current-validation.json+fresh-validation.json:115calls; footprint9 deferred, helper9/tupleindex8 private, membership9/source8/resource24/fresh48. Footprint68930hash and83595pathshadow exact; prior138399 shorthand corrected.2343 full earlier/154 focused including8new pass; final full pending. Minimalcore source4-5%/2% localcost, no horizon gains. Newrequest194302 receipt-bound/renderedoutline unverified, raw141864bytes saved, equalcopy qualification adopted. AGENTS/manuels/private-vs-Git clear; nativeheartbeat prompt synchronized, cadence/status/target unchanged.
'''
assert len(memo.encode())<=2048 and len(memo.splitlines())<=20;Path('.local_agent/NEXT_WORK.md').write_bytes(memo.encode())
session.checkpoint('Does actualsource membership transfer through new Core andNative rule frontiers?',
'Declared64cells:48actual on3freshrules and16unavailable1731 retained; all12fourcell withinbackend/q groups fullnontime/work/history/PVexact.1733 immediatewin remains notforcedD2. CoreactualproviderFalse/NativeTrue verified. All115segment searchcalls closed. Finalfullsuitewillinclude6equalcopy regressions afterearlier2343 pass and154focused. Userconfiguration clarifiesprojectauthority/private storage versusGitpublication; actualrawsave resolved, no approvalcontrol disabled.',
str(D/'fresh-validation.json'),'Runfinal full2349suite andarchive reviewedscience/configuredauthorization; nextactuallytest literaturemonotonicity onexistingcomplete legalstates, no blanketfrontier reuse/newframework.')
print(v['unavailable']);print('fresh48 actual/16 retainedunavailable;allnontime exact;memo bytes',len(memo.encode()))
