from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from tools.local_agent import session
D=Path('.local_agent/write-footprint-20261013');r=json.loads((D/'geometry-cost/rows.json').read_text(encoding='utf-8'));sh=json.loads((D/'geometry-shadow/rows.json').read_text(encoding='utf-8'));f=json.loads((D/'geometry-finite-results.json').read_text(encoding='utf-8'))
assert r['complete'] and len(r['rows'])==8 and sh['complete'] and len(sh['rows'])==1
sig=lambda x:{k:v for k,v in x['decision'].items() if not(k.endswith('_seconds') or k.startswith('time_to_'))}
cost=[]
for seed in [2026101455,2026101514]:
    g=[x for x in r['rows'] if x['seed']==seed];assert all(sig(x)==sig(g[0]) for x in g)
    for rep in range(2):
        a=next(x for x in g if x['repeat']==rep and x['enabled']=='off');b=next(x for x in g if x['repeat']==rep and x['enabled']=='candidate')
        cost.append(dict(seed=seed,repeat=rep,baseline=a['wall'],candidate=b['wall'],saved_percent=100*(1-b['wall']/a['wall'])))
assert sig(sh['rows'][0])==sig(next(x for x in r['rows'] if x['seed']==2026101514))
assert sh['rows'][0]['footprint']['shadow']==sh['rows'][0]['footprint']['calls']
v=dict(actual_searches=9,all8_cost_nontime_exact=True,whole_history_restored=True,all_pvs_core_replayed=True,shadow=sh['rows'][0]['footprint'],finite=f['comparisons'],costs=cost,decision='Targetdirect generator helper saves1514 butworsens1455; do notintegrate. Changedpremise usesexistingcompiledtuple firsttarget index, no unrelatedendpoint tuples ornewcache.',metadata_correction='Shadow flag=shadow,1call/60s actual; cloneddeclaration flags/seconds copied fromoriginalheavy, retainthenclarify.',production_changed=False)
(D/'geometry-verification.json').write_bytes((json.dumps(v,indent=2)+'\n').encode())
session.checkpoint('Does targetdirect geometry helper reduce actual Native binding cost?', '2400822 compiledfirstpath comparisons and54 repeated/min/leap/drop cases agree; actual138399binding shadow and8fixedfullnontime/PV/history controls pass.1455 firstpair worsens1.9percent/secondnearflat;1514 saves2.5/1.6percent. Rejectuniformhelper adoption; no lazyvalidation orcache. Changedpremise directexistingtuple.index avoidsPython endpoint/generator work.',str(D/'geometry-verification.json'),'Actualtuple-index8cost cells alreadybegun afterindependentfiniteequivalence; nextcompletebinding shadow andrequired-errorcontrols if netbenefit, else alternative structurallegality reuse counterexample.')
print(v)
