from pathlib import Path
import sys,json,inspect,textwrap
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
import membership_source as source
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core import search_runtime as sr
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));s=GameSession(c)
text=source.method;text=text.replace('if action not in self.legal_actions(checkpoint):','self.legal_actions(checkpoint)\n    if action not in self._bindings:')
ns=dict(sr.__dict__);exec(text,ns);naive=ns['_push_impl']
rows=[]
try:
    for name,impl in [('actual_before',source.old),('naive_dict_without_fallback',naive),('actual_after',source.current)]:
        for bad in [[],{'bad':'action'}]:
            sr.SearchPathRuntime._push_impl=impl
            r=sr.SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses);r.legal_actions()
            before=(r.position,tuple(r.history),r.repetition_counts,r.current_identity,r.runtime_hash,r.search_key(),r.depth,r.pushes,r.pops)
            try:r.push(bad)
            except Exception as e:typ=type(e).__name__;msg=str(e)
            else:raise AssertionError('bad accepted')
            assert before==(r.position,tuple(r.history),r.repetition_counts,r.current_identity,r.runtime_hash,r.search_key(),r.depth,r.pushes,r.pops)
            r.assert_balanced();rows.append(dict(mode=name,input_kind=type(bad).__name__,exception=typ,message=msg,full_state_history_restore=True))
finally:source.restore()
assert [x['exception'] for x in rows if x['mode']=='actual_before']==[x['exception'] for x in rows if x['mode']=='actual_after']==['IllegalActionError']*2
assert all(x['exception']=='TypeError' for x in rows if x['mode']=='naive_dict_without_fallback')
write_record(Path('.local_agent/write-footprint-20261013/membership-error-witness.json'),dict(search_calls=0,actual_rejected_pushes=6,rows=rows,naive_proposal_not_product_defect=True))
print(rows)
