import sys,time,json,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.actions import action_from_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'replay-v2.json';assert not out.exists()
source=root/'.local_agent/preparation-transfer-20261008/recombined.json'
old=json.loads(source.read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
profile=build_ruleset_profile(c,cfg)
class Measured(SemanticAttackEvaluator):
 def __init__(self):
  super().__init__(c,profile,cfg,backend='native');self.calls=0;self.seconds=0.;self.maps=0;self.map_seconds=0.
 def evaluate(self,state):
  t=time.perf_counter();self.calls+=1
  try:return super().evaluate(state)
  finally:self.seconds+=time.perf_counter()-t
 def _attack_maps(self,state):
  t=time.perf_counter();self.maps+=1
  try:return super()._attack_maps(state)
  finally:self.map_seconds+=time.perf_counter()-t
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(source),'product_sha256':{str(f):sha(root/f) for f in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/statistics.py')},'decision':'Localize actual evaluation/map cost on existing ten baseline cells; preserve frozen settings and old missing counters. No speedup claim or new cohort.','cases':[]}
write_record(out,r);started=time.perf_counter()
try:
 for ply in range(9):
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  assert time.perf_counter()-started<120
  if ply>=4:
   prior=next(x for x in old['cases'] if x['ply']==ply)
   for depth in (2,3):
    ev=Measured();player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
    t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t
    validate_pv(s,d);new=record_value(d);prev=next(x['decision'] for x in prior['searches'] if x['depth']==depth and x['repeat']==0)
    equal={key:new[key]==prev[key] for key in ('action','score','completed_depth','principal_variation','nodes')}
    item={'ply':ply,'depth':depth,'decision':new,'prior_decision_equal':equal,'independent_evaluation_calls':ev.calls,'independent_evaluation_seconds':ev.seconds,'map_calls':ev.maps,'map_seconds':ev.map_seconds,'wall_seconds':wall}
    r['cases'].append(item);write_record(out,r)
    assert all(equal.values()),equal
    assert d.evaluation_calls==ev.calls
    assert d.evaluation_seconds>=ev.seconds
    print(ply,depth,d.nodes,ev.calls,round(ev.seconds/wall,3),round(ev.map_seconds/wall,3),flush=True)
  if ply<8:s.submit(action_from_dict(old['route'][ply]))
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)

