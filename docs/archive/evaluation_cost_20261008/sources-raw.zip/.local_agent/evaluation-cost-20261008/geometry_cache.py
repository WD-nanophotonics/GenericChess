import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core import semantic_executor as executor
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'geometry-cache.json';assert not out.exists();source=root/'.local_agent/preparation-transfer-20261008/recombined.json';old=json.loads(source.read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c);cfg=EvaluationConfig(**old['config']);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
original=executor.geometry_candidates;started=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Profile found482053 repeated geometry derivations (~.658 nested profiled sec). Compare local fixed-compiled-geometry memoization against original on ALL five existing frontiers,depth3,two cold rotated repeats, same8192nodes/5sec. No persistent/product cache, no state/action/history merge. Cache fresh per search, strongly retains geometry objects, <=16384entries; report exact decisions and whole wall cost, no strength claim. Increment20search calls, <=120sec.','cases':[]};write_record(out,r)
try:
 for ply in range(9):
  if ply>=4:
   for repeat in (0,1):
    for cached in ((False,True) if (ply+repeat)%2 else (True,False)):
     assert time.perf_counter()-started<120
     assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
     cache={};objects={};count=[0,0]
     def memo(geometry,owner,source):
      key=(id(geometry),owner,source);count[0]+=1
      if key in cache:count[1]+=1;return cache[key]
      value=original(geometry,owner,source)
      if len(cache)<16384:objects[id(geometry)]=geometry;cache[key]=value
      return value
     executor.geometry_candidates=memo if cached else original
     player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
     t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t
     executor.geometry_candidates=original;validate_pv(s,d);new=record_value(d)
     previous=next(x for x in old['cases'] if x['ply']==ply)['searches'][2]['decision']
     equal={key:new[key]==previous[key] for key in ('score','action','nodes','completed_depth','principal_variation')}
     r['cases'].append({'ply':ply,'repeat':repeat,'cached':cached,'wall_seconds':wall,'geometry_calls':count[0],'cache_hits':count[1],'entries':len(cache),'decision_equal':equal,'decision':new});write_record(out,r);assert all(equal.values())
   print(ply,[(x['cached'],round(x['wall_seconds'],4),x['cache_hits']) for x in r['cases'] if x['ply']==ply],flush=True)
  if ply<8:s.submit(action_from_dict(old['route'][ply]))
 r['complete']=True
finally:executor.geometry_candidates=original;r['seconds']=time.perf_counter()-started;write_record(out,r)
