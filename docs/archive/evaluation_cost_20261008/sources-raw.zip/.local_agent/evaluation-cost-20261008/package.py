import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/evaluation_cost_20261008';dest.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
records={name:json.loads((p/name).read_bytes()) for name in ('replay.json','replay-v2.json','profile.json','geometry-cache.json','native-check.json')}
pins={'replay.json':'replay.py','replay-v2.json':'replay-v2.py','profile.json':'cost_profile.py','geometry-cache.json':'geometry_cache.py','native-check.json':'native_check.py'}
for record,producer in pins.items():assert records[record]['producer_sha256']==sha((p/producer).read_bytes())
assert not records['replay.json']['complete']
assert all(records[x]['complete'] for x in pins if x!='replay.json')
replay=records['replay-v2.json'];g=records['geometry-cache.json'];n=records['native-check.json']
def paired(rows,field,base,candidate):
 result=[]
 for ply in (4,5,6,7,8):
  a=[x['wall_seconds'] for x in rows if x['ply']==ply and x[field]==base];b=[x['wall_seconds'] for x in rows if x['ply']==ply and x[field]==candidate]
  result.append({'ply':ply,'baseline_seconds':sum(a),'candidate_seconds':sum(b),'candidate_over_baseline':sum(b)/sum(a)})
 return result
summary={'complete':True,'producer_sha256':sha(Path(__file__).read_bytes()),'input_sha256':{name:sha((p/name).read_bytes()) for name in records},'accounting':{'cells':len(replay['cases']),'all_actual_calls_match':all(x['decision']['evaluation_calls']==x['independent_evaluation_calls'] for x in replay['cases']),'all_decisions_unchanged':all(all(x['prior_decision_equal'].values()) for x in replay['cases']),'cells_summary':[{k:x[k] for k in ('ply','depth','wall_seconds','independent_evaluation_calls','independent_evaluation_seconds','map_calls','map_seconds')} for x in replay['cases']]},'profile':{'scope':records['profile.json']['scope'],'wall_seconds':records['profile.json']['wall_seconds'],'top_exclusive':records['profile.json']['functions_by_exclusive_time'][:15]},'geometry_memo':{'calls':len(g['cases']),'paired':paired(g['cases'],'cached',False,True),'all_decisions_unchanged':all(all(x['decision_equal'].values()) for x in g['cases'])},'native_gave_check':{'calls':len(n['cases']),'paired':paired(n['cases'],'mode','core','native'),'verified_core_checks':sum(x['core_verified'] for x in n['cases']),'all_decisions_unchanged':all(all(x['decision_equal'].values()) for x in n['cases'])},'interpretation':['Old quiescence-off search records missing leaf counters are not zero-work evidence; raw records unchanged.','Counter repair centralizes evaluator attempts and uses high-resolution perf_counter; no score/order/default or budget changes.','Initial independent replay exposed coarse monotonic elapsed measurements on Windows; failed record preserved.','Geometry memo and Native gave_check are isolated caller interventions on one exposed recombined fixture, not product adoption or universal speed claims.','Both interventions retain the8192-node depth3 cap; lowering per-node cost cannot alone resolve a node-budget failure.','Whole-wall repeats, nested profiling times and completed node/score evidence are distinct; do not sum nested cumulative costs.'],'archive':'../../archive/evaluation_cost_20261008/index.json'}
files=sorted(x for x in p.iterdir() if x.suffix in ('.py','.json'))+[root/'.local_agent/preparation-transfer-20261008/recombined.json',root/'generic_chess/ai/alphabeta/search.py',root/'generic_chess/ai/alphabeta/statistics.py',root/'tests/product/test_search_evaluation_accounting.py']
archive=dest/'sources-raw.zip';assert not archive.exists();members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();body=f.read_bytes();z.writestr(name,body);members.append({'path':name,'bytes':len(body),'sha256':sha(body)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for x in members:assert sha((Path(tmp)/x['path']).read_bytes())==x['sha256']
index={'base_commit':'6120b63f4fcb2a564fbfd36770a5c01b72eeca85','members':members,'archive_sha256':sha(archive.read_bytes()),'extracted_rehashed':True,'producer_pins':pins,'excluded':'User/private data, Slack/account records, credentials and workflow state.','retained_failures':['replay.json: coarse Windows monotonic precision cannot bound independent perf_counter durations; fix uses perf_counter.','Initial cProfile script name profile.py shadowed stdlib profile; renamed cost_profile.py before successful run.','Original8192-node and4096-reference caps not rewritten.']}
(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());(root/'docs/research/data/evaluation_cost_20261008.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps({'members':len(members),'geometry':summary['geometry_memo']['paired'],'native':summary['native_gave_check']},indent=2))
