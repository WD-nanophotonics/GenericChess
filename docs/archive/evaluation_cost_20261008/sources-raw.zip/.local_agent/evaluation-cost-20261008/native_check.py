import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import in_check,pack_current_position
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'native-check.json';assert not out.exists();source=root/'.local_agent/preparation-transfer-20261008/recombined.json';old=json.loads(source.read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c);nr=compile_native_semantic_rules(c);cfg=EvaluationConfig(**old['config']);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
original=SearchPathRuntime._gave_check;started=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Profile: Core in_check via runtime gave_check is repeated each pushed child despite Native legal provider. Compare local Native current-position gave_check against original on ALL five existing frontiers depth3, two cold rotated repeats,8192nodes/5sec. First dual pass on each frontier checks every bridge answer against Core. Preserve runtime/history/terminal and checkpoint before/after. No Native terminal or history import, no product interface change. <=25calls/180sec; first dual node-only to prevent verification load changing requested node work.','cases':[]};write_record(out,r)
try:
 for ply in range(9):
  if ply>=4:
   for mode,repeat in [('verify',0)]+[(m,i) for i in (0,1) for m in (('core','native') if (ply+i)%2 else ('native','core'))]:
    assert time.perf_counter()-started<180
    assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    counts=[0,0]
    def bridge(runtime,position,checkpoint=None):
     assert runtime.compiled is c
     if checkpoint:checkpoint()
     result=in_check(nr,pack_current_position(nr,position,ply_count=runtime.ply_count+1),position.side_to_move);counts[0]+=1
     if mode=='verify':
      reference=original(runtime,position,checkpoint);counts[1]+=1;assert result==reference
     if checkpoint:checkpoint()
     return result
    SearchPathRuntime._gave_check=original if mode=='core' else bridge
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
    t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=None if mode=='verify' else 5,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-t
    SearchPathRuntime._gave_check=original;validate_pv(s,d);new=record_value(d);previous=next(x for x in old['cases'] if x['ply']==ply)['searches'][2]['decision']
    equal={key:new[key]==previous[key] for key in ('score','action','nodes','completed_depth','principal_variation')}
    r['cases'].append({'ply':ply,'repeat':repeat,'mode':mode,'wall_seconds':wall,'native_calls':counts[0],'core_verified':counts[1],'decision_equal':equal,'decision':new});write_record(out,r);assert all(equal.values())
   print(ply,[(x['mode'],round(x['wall_seconds'],4),x['native_calls']) for x in r['cases'] if x['ply']==ply],flush=True)
  if ply<8:s.submit(action_from_dict(old['route'][ply]))
 r['complete']=True
finally:SearchPathRuntime._gave_check=original;r['seconds']=time.perf_counter()-started;write_record(out,r)
