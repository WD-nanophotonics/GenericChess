import cProfile,pstats,json,time,sys,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.actions import action_from_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'profile.json';assert not out.exists()
source=root/'.local_agent/preparation-transfer-20261008/recombined.json';old=json.loads(source.read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for a in old['route'][:6]:s.submit(action_from_dict(a))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
pr=cProfile.Profile();t=time.perf_counter()
# Instrumentation can change wall-limited completion; node-only cap preserves
# the same bounded8192-node work for localization, not a speed comparison.
d=pr.runcall(player.choose_action,s,SearchLimits(max_depth=3,max_nodes=8192,quiescence_max_depth=0,quiescence_hard_max_depth=0))
wall=time.perf_counter()-t;stats=pstats.Stats(pr)
rows=[]
for (file,line,name),(primitive,total,exclusive,cumulative,callers) in stats.stats.items():
 if 'generic_chess' in file:
  rows.append({'file':file.replace(str(root),'REPO').replace('\\','/'),'line':line,'name':name,'primitive_calls':primitive,'calls':total,'exclusive_seconds':exclusive,'cumulative_seconds':cumulative})
rows.sort(key=lambda x:x['exclusive_seconds'],reverse=True)
prior=next(x for x in old['cases'] if x['ply']==6)['searches'][2]['decision'];new=record_value(d)
equal={key:new[key]==prior[key] for key in ('action','score','completed_depth','principal_variation','nodes')};assert all(equal.values())
write_record(out,{'complete':True,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Existing ply6,8192nodes, profiling omits5sec wall cap solely to avoid instrumentation changing node work. No fair wall speed or strength claim. Cumulative nested times must not be added.','wall_seconds':wall,'prior_decision_equal':equal,'decision':new,'functions_by_exclusive_time':rows})
print(json.dumps({'wall':wall,'top':rows[:12]},indent=2))
