import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import scripts.chess_development as d
p=ROOT/'.local_agent/targeted-budget-20261007';out=p/'replay.json';assert not out.exists()
raw=(p/'games-continuation.json').read_bytes();v=json.loads(raw);assert v['complete'] and len(v['games'])==23 and len(v['interrupted_games'])==1
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());report=dict(complete=False,input_sha256=hashlib.sha256(raw).hexdigest(),games=[],errors=[])
for i,g in enumerate(v['games']+v['interrupted_games']):
 other=d.UciOpponent(None,g['initial_fen'],1);s,_=d.replay_prefix(g['initial_fen'],c,g['opening_uci'],(other,));counts={1:0,4:0};nodes=0;seconds=0.
 for r in g['moves']:
  legal={d.uci(a):a for a in d.iter_legal_actions(s,c)}
  assert set(legal)=={m.uci() for m in other.board.legal_moves}
  assert r['legal'] and r['move'] in legal and r['side']==s.position.side_to_move and r['ply']==s.ply_count
  if 'budget_mode' in r:
   checked=other.board.is_check();captures=sum(other.board.is_capture(m) for m in other.board.legal_moves)
   expected=4 if g['budget_mode']=='fixed4' or checked or captures else 1
   assert r['state_in_check']==checked and r['legal_capture_count']==captures and r['requested_seconds']==expected and r['budget_mode']==g['budget_mode']
   counts[expected]+=1;nodes=None if nodes is None or r.get('engine_nodes') is None else nodes+r['engine_nodes'];seconds+=r['wall_seconds']
  s=d.apply_action(s,legal[r['move']],c);other.push(r['move'],s)
 interrupted='final_state' not in g
 if not interrupted:assert d.record_value(s)==g['final_state']
 assert len(s.history)==len(g['opening_uci'])+len(g['moves'])+1
 report['games'].append(dict(index=i,id=g['id'],mode=g['budget_mode'],white=g['white'],black=g['black'],plies=len(g['moves']),prefix_plies=len(g['opening_uci']),end='recording_interruption' if interrupted else g['end'],winner=None if interrupted else g['winner'],finished=False if interrupted else g['finished'],interrupted=interrupted,local_calls=counts,requested_seconds=sum(k*n for k,n in counts.items()),local_wall_seconds=seconds,reported_engine_nodes=nodes))
 d.write_record(out,report,indent=None)
report.update(complete=True,played_plies=sum(g['plies'] for g in report['games']),prefix_plies=sum(g['prefix_plies'] for g in report['games']));d.write_record(out,report)
print('replay',len(report['games']),report['played_plies'],'zero mismatches; budget conditions verified',flush=True)
