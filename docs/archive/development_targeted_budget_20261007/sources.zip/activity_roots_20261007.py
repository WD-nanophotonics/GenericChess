"""Two previously exposed decision roots, one declared common residual weight."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-20261007';out=p/'roots.json';assert not out.exists()
assert json.loads((p/'static.json').read_bytes())['complete']
raw=(ROOT/'.local_agent/mature-openings/games-1-resume.json').read_bytes();g=next(x for x in json.loads(raw)['games'] if x['id']=='central-d' and x['white']=='linear_mixture')
config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
binaries={'pure':ROOT/'.local_agent/mature-search/build/fairy-material.exe','activity':p/'fairy-activity.exe'}
report=dict(scope='Ex-post actual roots16/32, not holdout or price fitting. Single already declared4native-unit nonroyal attack-union residual; same tables/search/1sec/Threads1/Hash16. Finite child reference cp not WDL or original visited-leaf claims.',input_sha256=hashlib.sha256(raw).hexdigest(),binary_hashes={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},rows=[],complete=False)
d.write_record(out,report);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
with chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as strong:
 strong.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
 for index in (16,32):
  prefix=g['opening_uci']+[r['move'] for r in g['moves'][:index]]
  b=chess.Board(g['initial_fen']);[b.push_uci(m) for m in prefix]
  state,_=d.replay_prefix(g['initial_fen'],c,prefix);legal={d.uci(a) for a in d.iter_legal_actions(state,c)};assert legal=={m.uci() for m in b.legal_moves}
  row=dict(played_index=index,fen=b.fen(en_passant='fen'),choices=[],references={});report['rows'].append(row)
  for mode,binary in binaries.items():
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
    e.configure({'Threads':1,'Hash':16,'Use NNUE':False})
    for policy in d.POLICIES:
     player=d.UciMaterial(e,g['initial_fen'],policy,1);d.replay_prefix(g['initial_fen'],c,prefix,(player,));move,r=player.choose();assert move in legal;r['leaf_mode']=mode;r['requested_seconds']=1;row['choices'].append(r);d.write_record(out,report)
  strong.configure({'Clear Hash':None});info=strong.analyse(b,chess.engine.Limit(nodes=1000000,time=2),game=object());best=info['pv'][0].uci();row['reference_best']=best
  for move in sorted({best,g['moves'][index]['move']}|{x['move'] for x in row['choices']}):
   child=b.copy(stack=True);child.push_uci(move);strong.configure({'Clear Hash':None});info=strong.analyse(child,chess.engine.Limit(nodes=1000000,time=2),game=object());score=info['score'].pov(b.turn)
   row['references'][move]=dict(cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),seconds=info.get('time'),pv=[m.uci() for m in info.get('pv',())]);d.write_record(out,report)
  print(index,[(x['leaf_mode'],x['policy'],x['move']) for x in row['choices']],{m:x['cp'] for m,x in row['references'].items()},flush=True)
report['complete']=True;d.write_record(out,report)
