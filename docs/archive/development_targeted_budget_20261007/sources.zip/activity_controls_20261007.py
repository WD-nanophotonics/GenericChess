import sys,json,re,subprocess,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-20261007';out=p/'static.json';assert not out.exists()
binary=p/'fairy-activity.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini'
fens=[chess.STARTING_FEN,'rnbqkbnr/1ppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1','4k3/8/8/8/3N4/8/8/4K3 w - - 0 1','4k3/8/8/8/8/8/3N4/4K3 w - - 0 1','4k3/8/8/8/3R4/8/8/4K3 w - - 0 1']
report=dict(scope='Independent python-chess standard pseudo-attack union, excludes King; static white-relative UCI score rounded to0.01Pawn. No legality/mobility equivalence.',rows=[],complete=False)
for fen in fens:
 for mirror in (False,True):
  b=chess.Board(fen);b=b.mirror() if mirror else b
  for turn in (True,False):
   b.turn=turn;fen=b.fen(en_passant='fen')
   for policy,weights in d.material_tables().items():
    covered={}
    for c in chess.COLORS:
     bb=0
     for s,pc in b.piece_map().items():
      if pc.color==c and pc.piece_type!=chess.KING:bb|=int(b.attacks(s))
     covered[c]=bb.bit_count()
    material=sum((1 if pc.color else -1)*weights[pc.symbol().upper()] for pc in b.piece_map().values() if pc.piece_type!=chess.KING)
    expected=(material+4*(covered[True]-covered[False]))/208
    cmds=f'uci\nsetoption name UCI_Variant value gc_{policy}\nsetoption name Use NNUE value false\nisready\nposition fen {fen}\neval\nquit\n'
    r=subprocess.run([str(binary),'load',str(config)],input=cmds,text=True,capture_output=True,timeout=15)
    found=re.search(r'Final evaluation\s+([+-]?[0-9.]+)',r.stdout)
    observed=float(found.group(1)) if found else None
    row=dict(fen=fen,mirror=mirror,policy=policy,covered=covered,expected_white_pawn=expected,observed_white_pawn=observed,stdout=r.stdout,stderr=r.stderr,exit_code=r.returncode)
    report['rows'].append(row);d.write_record(out,report)
    assert r.returncode==0 and observed is not None and abs(observed-expected)<=.0101,row
report['complete']=True;d.write_record(out,report);print('static controls',len(report['rows']),flush=True)
