import sys,json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'.local_agent/targeted-budget-20261007';a=ROOT/'docs/archive/development_targeted_budget_20261007';a.mkdir(exist_ok=True)
out=ROOT/'docs/research/data/chess_targeted_budget_20261007.json';assert not out.exists()
v=json.loads((p/'games-continuation.json').read_bytes());r=json.loads((p/'replay.json').read_bytes());assert v['complete'] and r['complete'] and not r['errors']
groups={}
def known_sum(values):
 values=list(values);return None if any(x is None for x in values) else sum(values)
for mode in ('targeted','fixed4'):
 methods={};rows=[x for x in r['games'] if x['mode']==mode]
 for policy in ('geometric_half','linear_mixture','unit'):
  cells=[x for x in rows if policy in (x['white'],x['black'])]
  methods[policy]=dict(wins=sum(x['finished'] and x['winner']==(0 if x['white']==policy else 1) for x in cells),losses=sum(x['finished'] and x['winner'] is not None and x['winner']!=(0 if x['white']==policy else 1) for x in cells),draws=sum(x['finished'] and x['winner'] is None for x in cells),unfinished=sum(not x['finished'] and not x['interrupted'] for x in cells),recording_interrupted=sum(x['interrupted'] for x in cells))
 groups[mode]=dict(methods=methods,requested_seconds=sum(x['requested_seconds'] for x in rows),local_wall_seconds=sum(x['local_wall_seconds'] for x in rows),reported_engine_nodes=known_sum(x['reported_engine_nodes'] for x in rows),local_calls={k:sum(x['local_calls'].get(k,0) for x in rows) for k in ('1','4')},played_plies=sum(x['plies'] for x in rows))
files=[p/n for n in ('declaration.json','suite.json','analysis-plan.md','games.json','games-continuation.json','recording-failure.json','exposed-trigger-diagnostic.json','replay.json','shogi-prefix.json','shogi-prefix-resource.json') if (p/n).exists()]
files += [ROOT/'.local_agent/activity-20261007'/n for n in ('declaration.json','activity.patch','execution-failure.json')]
files += [ROOT/'.local_agent/activity-20261007'/n for n in ('static.json','roots.json') if (ROOT/'.local_agent/activity-20261007'/n).exists()]
entries={}
with zipfile.ZipFile(a/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  b=f.read_bytes();assert b'C:\\Users\\wdai' not in b;name=f.relative_to(ROOT/'.local_agent').as_posix();z.writestr(name,b);entries[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(a/'raw.zip') as z:
 for n,h in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==h['sha256']
names=['build_activity_20261007.py','activity_controls_20261007.py','activity_roots_20261007.py','targeted_budget_20261007.py','continue_targeted_budget_20261007.py','shogi_legal_prefix_20261007.py','shogi_legal_prefix_resource_20261007.py','replay_targeted_budget_20261007.py','collect_targeted_budget_20261007.py'];sources={}
with zipfile.ZipFile(a/'sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in names:
  b=(ROOT/'.local_agent'/n).read_bytes();z.writestr(n,b);sources[n]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(a/'sources.zip') as z:
 for n,h in sources.items():assert hashlib.sha256(z.read(n)).hexdigest()==h['sha256']
b=json.loads((ROOT/'.local_agent/activity-20261007/build.json').read_bytes())
keys=lambda x:(x['id'],x['white'],x['black'])
by_mode={mode:{keys(x):x for x in r['games'] if x['mode']==mode and not x['interrupted']} for mode in ('targeted','fixed4')}
common=sorted(set(by_mode['targeted'])&set(by_mode['fixed4']))
paired={mode:dict(cells=len(common),requested_seconds=sum(by_mode[mode][k]['requested_seconds'] for k in common),local_wall_seconds=sum(by_mode[mode][k]['local_wall_seconds'] for k in common),reported_engine_nodes=known_sum(by_mode[mode][k]['reported_engine_nodes'] for k in common),played_plies=sum(by_mode[mode][k]['plies'] for k in common)) for mode in ('targeted','fixed4')}
paired['scope']='Same declared root/color/table cells, independent stochastic game paths; omitted pair has one recording interruption. No deterministic paired-outcome inference.'
report=dict(scope='Common state-based resource policy development comparison;23 completed streams plus one75ply recording interruption, not24 outcomes. Recorded resources omit lost failed-save action/old write overhead. Unverified positional build; reachable Shogi control. No tuning/default/Elo/holdout claim.',groups=groups,continuation_wall_seconds=v['wall_seconds'],continuation_recording_cost=v['recording_cost'],replay=dict(streams=len(r['games']),completed_streams=23,interrupted_streams=1,played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0,budget_conditions_verified=True),
 activity_build=dict(complete=b['complete'],binary_sha256=b['binary_sha256'],wall_seconds=b['wall_seconds'],reused_objects=b['reused_objects'],execution='WinError4551 Application Control blocked; zero native static controls; no bypass'),
 raw_entries=entries,sources=sources,archive_base='repository root',raw_archive='docs/archive/development_targeted_budget_20261007/raw.zip',raw_zip_sha256=hashlib.sha256((a/'raw.zip').read_bytes()).hexdigest(),sources_zip_sha256=hashlib.sha256((a/'sources.zip').read_bytes()).hexdigest(),production_code_changed=False,public_push='held')
if (p/'shogi-prefix.json').exists():
 s=json.loads((p/'shogi-prefix.json').read_bytes());report['shogi']=dict(complete=s['complete'],prefix=s['prefix'],history_plies=s.get('history_plies'),legal_actions=s.get('legal_actions'),models=s['models'])
report['complete_pair_costs']=paired
static=ROOT/'.local_agent/activity-20261007/static.json';roots=ROOT/'.local_agent/activity-20261007/roots.json'
if static.exists():
 s=json.loads(static.read_bytes());report['activity_build'].update(static_controls=len(s['rows']),static_complete=s['complete'],execution='Initial managed execution WinError4551 retained. Normal approval-reviewed execution used without changing machine policy; static evidence gives actual qualification.')
if roots.exists():
 s=json.loads(roots.read_bytes());report['activity_build']['roots_complete']=s['complete']
 report['activity_roots']=[dict(played_index=row['played_index'],choices=[dict(leaf_mode=x['leaf_mode'],policy=x['policy'],move=x['move'],finite_child_cp=row['references'][x['move']]['cp'],engine_nodes=x['engine_nodes'],wall_seconds=x['wall_seconds']) for x in row['choices']]) for row in s['rows']]
if (p/'shogi-prefix-resource.json').exists():
 s=json.loads((p/'shogi-prefix-resource.json').read_bytes());report['shogi_resource_continuation']=dict(complete=s['complete'],history_plies=s.get('history_plies'),resource_continuation=s['resource_continuation'],models=s['models'])
write_record(out,report);write_record(a/'index.json',dict(raw_entries=entries,sources=sources,portable_sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
print(json.dumps(dict(groups=groups,wall=v['wall_seconds'],replay=report['replay'],shogi=report.get('shogi'),sha256=hashlib.sha256(out.read_bytes()).hexdigest())))
