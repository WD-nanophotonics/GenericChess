"""Prospective common state-based resource policy vs fixed4 seconds."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/targeted-budget-20261007';p.mkdir(exist_ok=True);assert not (p/'declaration.json').exists()
binary=ROOT/'.local_agent/mature-search/build/fairy-material.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
suite=json.loads((ROOT/'.local_agent/mature-openings/suite.json').read_bytes())
decl=dict(question='Can one common state-based time allocation retain useful fixed4sec practical feedback at lower search cost?',
 policy='4sec if current full-history standard board is in check OR has any legal capture; otherwise1sec. Same condition for all three price tables, independent of scores/outcomes. No tuning.',
 scope='24 fresh development games, two prefixes/colors/three tables times targeted/fixed4. Reference1800 UCI setting is not calibrated strength. Fixed maxima unchanged160plies. Earlier1/4 curves are descriptive only.',
 decision='Keep all cells, unfinished and adverse results. Compare resource/result curves; any apparent saved cost without extra losses motivates another independent pilot, never Elo or default promotion. No post-outcome extensions.',
 conditions=dict(reference_elo_setting=1800,reference_nodes=50000,reference_time_fuse=1,threads=1,hash_mib=16,max_subsequent_plies=160),
 cost='24sequential games, local requested upper bound7680sec if all reach160plies with4sec on every local move; stop flags checked per action. Actual time/nodes/search calls/recording measured. No concurrent engine/build/tests.',
 binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256((ROOT/'scripts/chess_development.py').read_bytes()).hexdigest())
d.write_record(p/'declaration.json',decl);d.write_record(p/'suite.json',suite)
class Player(d.UciMaterial):
 def __init__(self,*args,mode,**kw):super().__init__(*args,**kw);self.mode=mode
 def choose(self):
  checked=self.board.is_check();captures=sum(self.board.is_capture(m) for m in self.board.legal_moves)
  seconds=4 if self.mode=='fixed4' or checked or captures else 1
  self.limit=chess.engine.Limit(time=seconds);m,r=super().choose()
  r.update(budget_mode=self.mode,requested_seconds=seconds,state_in_check=checked,legal_capture_count=captures)
  return m,r
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
out=p/'games.json';assert not out.exists();report=dict(declaration=decl,games=[],complete=False);cost=dict(writes=0,bytes=0,seconds=0.)
def stopcheck():
 for n in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise KeyboardInterrupt('User stop retained')
def save(indent=None):
 t=time.perf_counter();d.write_record(out,report,indent=indent);cost['seconds']+=time.perf_counter()-t;cost['writes']+=1;cost['bytes']+=out.stat().st_size
start=time.perf_counter();save()
try:
 cell=0
 for case in suite['cases']:
  for policy in d.POLICIES:
   for color in (0,1):
    modes=('targeted','fixed4') if cell%2==0 else ('fixed4','targeted');cell+=1
    for mode in modes:
     stopcheck()
     with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as other:
      e.configure({'Threads':1,'Hash':16,'Use NNUE':False});other.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':True,'UCI_Elo':1800})
      local=Player(e,case['fen'],policy,4,mode=mode);external=d.UciOpponent(other,case['fen'],50000)
      def progress(game):report['active_game']=dict(id=case['id'],budget_mode=mode,**game);save();stopcheck()
      game=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=external,local_external=local,prefix=case['opening_uci'])
      report.pop('active_game',None);report['games'].append(dict(id=case['id'],budget_mode=mode,**game));save()
      localrows=[r for r in game['moves'] if 'budget_mode' in r]
      print(case['id'],policy,color,mode,game['end'],game['winner'],game['plies_played'],'requested',sum(r['requested_seconds'] for r in localrows),'calls',len(localrows),flush=True)
 report['complete']=True
finally:
 report.update(wall_seconds=time.perf_counter()-start,recording_cost=dict(cost));save(2)
print('COMPLETE',report['complete'],report['wall_seconds'],cost,flush=True)
