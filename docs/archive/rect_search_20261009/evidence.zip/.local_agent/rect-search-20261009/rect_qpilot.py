"""Fixed followup: two rectangular roots, Core authority, supplied unit evaluator.

Four predeclared existing caller cells, two cold repeats: plain; TT/order;
TT/staged; TT/order/root scan. D2/4096nodes/5sec/q2/hard8. Capture creates real
hand/drop branches. Compare repeated completed signatures, completed-depth
scores across cells, PV legality, root immutability and balanced runtime work.
Caps remain unknown at unfinished depths, not implicit gains. No price/strength
claim, no Native rectangle support, no default or resource extension.
"""
from rect_probe import *
from unittest.mock import patch
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.cancellation import CancellationToken
def main():
 p=Path(__file__).parent;out=p/'rect-qpilot.json';assert not out.exists();r=dict(complete=False,declaration=__doc__,cases=[]);start=time.perf_counter()
 for shape in ((7,5),(9,10)):
  c=compile_ruleset_for_execution(definition(*shape));s=GameSession(c);before=s.state;row=dict(shape=shape,searches=[]);r['cases'].append(row)
  for label,tt,ordering,staged,scan in [('plain',False,False,False,False),('tt_order',True,True,False,False),('tt_staged',True,True,True,False),('tt_root',True,True,False,True)]:
   for repeat in (0,1):
    flags=json.loads((root/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped');assert time.perf_counter()-start<150
    player=AlphaBetaPlayer(c,evaluator_override=UnitEvaluator(),use_tt=tt,use_ordering=ordering,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=scan,use_staged_move_picker=staged));stats=[]
    def make_stats():
     z=SearchStatistics();stats.append(z);return z
    t=time.perf_counter()
    with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats):dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8))
    validate_pv(s,dec);assert s.state==before;assert stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops
    row['searches'].append(dict(label=label,repeat=repeat,decision=record_value(dec),seconds=time.perf_counter()-t,runtime_pushes=stats[0].runtime_pushes,runtime_pops=stats[0].runtime_pops));write_record(out,r)
    print(shape,label,repeat,dec.completed_depth,dec.score,dec.termination_reason,flush=True)
  token=CancellationToken();token.cancel();player=AlphaBetaPlayer(c,evaluator_override=UnitEvaluator(),use_native_semantic_legality=False)
  dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5),cancel_token=token);assert s.state==before
  row['pre_cancelled_reason']=dec.termination_reason
 r['complete']=True;r['seconds']=time.perf_counter()-start;r['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(out,r)
if __name__=='__main__':main()
