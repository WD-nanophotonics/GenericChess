"""Isolate rectangular generic search from square-only legacy price generation."""
import sys,json,time,traceback,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import cannon_ruleset
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv,CountedEvaluator
class UnitEvaluator:
 def evaluate(self,state):
  n=sum((100 if p.owner==0 else -100) for p in state.position.board if p is not None and p.current_type_id!='K')
  n+=sum((100 if o==0 else -100)*sum(v for _,v in h.counts) for o,h in enumerate(state.position.hands))
  return n if state.position.side_to_move==0 else -n
 def capture_order_value(self,moving,captured):return 1000 if captured.current_type_id!='K' else 0
class NoUnusedProfile:
 def get_or_build(self,*args):return None,False
def definition(width,height):
 base=cannon_ruleset();board=[[None]*width for _ in range(height)]
 board[0][0]=Piece(0,'K','K');board[-1][-1]=Piece(1,'K','K')
 board[1][0]=Piece(0,'C','C');board[1][-1]=Piece(1,'C','C');board[1][width//2]=Piece(0,'C','C')
 return replace(base,board_size=None,board_width=width,board_height=height,initial_position=tuple(map(tuple,board)),drop_allowed={'C':((False,)*(width*height),)*2})
def main():
 p=Path(__file__).parent;out=p/'rect-after.json';assert not out.exists();result=dict(complete=False,scope='Two fresh rectangular recombinations, fixed unit material only to isolate execution; not price/strength/full-evaluator support',cases=[])
 for width,height in ((7,5),(9,10)):
  d=definition(width,height);c=compile_ruleset_for_execution(d);s=GameSession(c);ev=UnitEvaluator();row=dict(shape=[width,height],rules=ruleset_to_dict(d),searches=[]);result['cases'].append(row)
  try:AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev)
  except Exception as exc:row['public_constructor_failure']=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
  counted=CountedEvaluator(ev,seconds=5,evaluations=4096);t=time.perf_counter();score,action=reference_minimax(s.state,2,counted,c);row['reference']=dict(score=score,action=record_value(action),leaves=counted.calls,seconds=time.perf_counter()-t)
  for native in (False,True):
   for ordering,staged in ((False,False),(True,False),(True,True)):
    x=dict(native_requested=native,ordering=ordering,staged=staged);row['searches'].append(x)
    try:
     player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_native_semantic_legality=native,use_ordering=ordering,tuning=SearchTuning(use_root_tactical=False,use_staged_move_picker=staged))
     x['native_provider_present']=player.native_legality_provider is not None;t=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,dec);x['decision']=record_value(dec);x['seconds']=time.perf_counter()-t
     x['reference_equal']=dec.score==score and dec.completed_depth==2
    except Exception as exc:x['failure']=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
    write_record(out,result)
 result['complete']=True;result['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(out,result)
 print([(r['shape'],r.get('public_constructor_failure',{}).get('message'),[(x['native_requested'],x['ordering'],x.get('failure',{}).get('message'),x.get('reference_equal')) for x in r['searches']]) for r in result['cases']])
if __name__=='__main__':main()
