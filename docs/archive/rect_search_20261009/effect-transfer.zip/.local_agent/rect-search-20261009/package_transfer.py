"""Package the additional, separate nonmaterial rectangle transfer evidence."""
from pathlib import Path
import hashlib,json,zipfile,tempfile,re
from scripts.research_record import write_record

root=Path.cwd();dest=root/'docs/archive/rect_search_20261009';archive=dest/'effect-transfer.zip'
assert not archive.exists()
files=['.local_agent/rect-search-20261009/'+name for name in
 ('rect_effect_transfer.py','rect-effect-transfer.json','rect_effect_witness.py','rect-effect-witness.json','rect_probe.py','package_transfer.py')]
files+=['tests/rule_semantics_ir_fixtures.py']
members=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for rel in files:
  data=(root/rel).read_bytes()
  assert not re.search(rb'(?:xox[baprs]-|[CU][0-9A-Z]{10})',data)
  z.writestr(rel,data);members.append(dict(member=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tempfile.TemporaryDirectory(prefix='genericchess-effect-recovery-') as target:
 with zipfile.ZipFile(archive) as z:z.extractall(target)
 for m in members:assert hashlib.sha256((Path(target)/m['member']).read_bytes()).hexdigest()==m['sha256']
write_record(dest/'effect-transfer-index.json',dict(base_product_sha='af8ed2c62f4c87a17e7fe33d2e2df3a65fd3af2e',members=members,member_count=len(members),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),extracted_hashes_verified=True,scope='Agent-generated nonmaterial rectangle execution controls, not price or Native support. Restore producer dependencies from evidence.zip in this directory; isolate recovery, never overlay live checkout.',producer_correction='First attempt used nonexistent GameSession.apply before writing a result. Corrected to submit and replay actual history for each context. Final output is the first completed frozen run. No search sample extension.'))
path=root/'docs/research/data/rect_search_20261009.json';d=json.loads(path.read_bytes());d['effect_transfer']=dict(index='../archive/rect_search_20261009/effect-transfer-index.json',cases=2,contexts=4,fullwidth_references=4,public_calls=20,q0_reference_equal=12,q2_completed=8,temporal_ordinary_expiry_witnesses=12,temporal_replies=13,compound_replies=11,scope='Fixed unit evaluator, Core; complete public-state/history restoration; no Native/price/strength claim')
write_record(path,d)
print('seven members extracted and hashed; transfer index added')
