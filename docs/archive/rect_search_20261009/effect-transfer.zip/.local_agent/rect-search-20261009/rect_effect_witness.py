"""Independent actual-effect witness from the frozen transfer input/output.

Enumerate the temporal successor's legal replies once. Distinguish expiry from
an opponent resetting the same global slot. No new search/price sample.
"""
from rect_probe import *
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.transition import apply_action

def main():
 p=Path(__file__).parent;out=p/'rect-effect-witness.json';assert not out.exists()
 source=json.loads((p/'rect-effect-transfer.json').read_bytes());r=dict(complete=False,declaration=__doc__,cases=[])
 for row in source['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));s=GameSession(c)
  action=next(a for a in s.legal_actions() if record_value(a)==row['effect']);s.submit(action)
  assert record_value(s.state)==row['after'];state=s.state
  result=dict(label=row['label'],replies=[]);r['cases'].append(result)
  for reply in s.legal_actions():
   nxt=apply_action(state,reply,c)
   result['replies'].append(dict(action=record_value(reply),aux_before=record_value(state.position.aux_state),aux_after=record_value(nxt.position.aux_state),terminal=record_value(nxt.terminal_status)))
  if row['label']=='temporal_transform':
   ordinary=[z for z in result['replies'] if 'promotion_grants_one_turn_right' not in z['action'].get('pattern_id','')]
   assert ordinary
   assert all(all(v==0 for _,v in z['aux_after']) for z in ordinary)
   result['ordinary_expiry_witnesses']=len(ordinary)
  assert s.state==state
 r['complete']=True;r['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(out,r)
 print([(z['label'],len(z['replies']),z.get('ordinary_expiry_witnesses')) for z in r['cases']])
if __name__=='__main__':main()
