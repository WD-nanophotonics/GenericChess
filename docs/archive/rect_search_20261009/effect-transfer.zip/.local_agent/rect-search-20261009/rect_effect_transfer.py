"""One transfer question: does rectangle search preserve nonmaterial events?

Predeclared 7x5 temporal-transform and compound-friendly-shift recombinations.
Initial and one actual effect successor per rule; full-width Core D2 reference,
plain/sorted/staged public D2 q0, then sorted/staged q2. Supplied unit evaluator
isolates execution, not useful prices. 4096 nodes/5sec per search; reference
4096 evaluations/5sec; no sample extension. Validate each PV and unchanged
complete root incl auxiliary state/history, positive compound/temporal witness.
"""
from rect_probe import *
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from unittest.mock import patch

def main():
 p=Path(__file__).parent;out=p/'rect-effect-transfer.json';assert not out.exists()
 r=dict(complete=False,declaration=__doc__,cases=[]);start=time.perf_counter()
 for index,label in ((2,'temporal_transform'),(3,'compound_shift')):
  base=weird_rulesets()[index];w,h=7,5;rows=[[None]*w for _ in range(h)]
  rows[0][0]=Piece(0,'K','K');rows[-1][-1]=Piece(1,'K','K')
  rows[1][1]=Piece(0,'R','R');rows[3][5]=Piece(1,'R','R')
  if index==3:rows[2][1]=Piece(0,'R','R')
  d=replace(base,board_size=None,board_width=w,board_height=h,initial_position=tuple(map(tuple,rows)),drop_allowed={pt.type_id:((False,)*(w*h),)*2 for pt in base.piece_types if not pt.is_anchor})
  c=compile_ruleset_for_execution(d);s=GameSession(c)
  actions=s.legal_actions();effect=[a for a in actions if ('promotion_grants_one_turn_right' if index==2 else 'move_and_shift_adjacent_friendly') in str(a)]
  assert effect, (label,[str(a) for a in actions])
  initial=s.state;s.submit(effect[0]);after=s.state
  if index==2:
   assert any(x is not None and x.current_type_id=='TP' for x in after.position.board)
   assert after.position.aux_state!=initial.position.aux_state
  else:
   assert sum(a!=b for a,b in zip(initial.position.board,after.position.board))==4
  row=dict(label=label,rules=ruleset_to_dict(d),effect=record_value(effect[0]),before=record_value(initial),after=record_value(after),contexts=[]);r['cases'].append(row)
  for context,state in (('initial',initial),('effect_successor',after)):
   flags=json.loads((root/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped');assert time.perf_counter()-start<120
   session=GameSession(c)
   if context=='effect_successor':session.submit(effect[0])
   assert session.state==state
   ev=UnitEvaluator();counted=CountedEvaluator(ev,seconds=5,evaluations=4096)
   score,action=reference_minimax(state,2,counted,c)
   ctx=dict(context=context,reference=dict(score=score,action=record_value(action),leaves=counted.calls),searches=[]);row['contexts'].append(ctx)
   for ordering,staged,q in ((False,False,0),(True,False,0),(True,True,0),(True,False,2),(True,True,2)):
    player=AlphaBetaPlayer(c,evaluator_override=ev,use_ordering=ordering,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False,use_staged_move_picker=staged));stats=[]
    def make_stats():
     z=SearchStatistics();stats.append(z);return z
    t=time.perf_counter()
    with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats):dec=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
    validate_pv(session,dec);assert session.state==state
    assert stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops
    if q==0:assert dec.completed_depth==2 and dec.score==score
    ctx['searches'].append(dict(ordering=ordering,staged=staged,q=q,decision=record_value(dec),seconds=time.perf_counter()-t,pushes=stats[0].runtime_pushes,pops=stats[0].runtime_pops));write_record(out,r)
   print(label,context,score,[(x['q'],x['decision']['completed_depth'],x['decision']['score']) for x in ctx['searches']],flush=True)
 r['complete']=True;r['seconds']=time.perf_counter()-start;r['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(out,r)
if __name__=='__main__':main()
