from pathlib import Path
import sys,json,dataclasses
sys.path.insert(0,str(Path(__file__).resolve().parents[2]));sys.path.insert(0,str(Path(__file__).parent))
from ladder import make_ladder
from tests.product.test_search_result_provenance import position,player
from generic_chess.ai.alphabeta import player as pm,search
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;r=dict(complete=False,rows=[])
for phase,stage in [(None,None),('begin','intermediate'),('complete','intermediate'),('begin','configured'),('complete','configured')]:
 s,e=position();initial=s.state;w=s._search_witnesses;token=CancellationToken();events=[];fn=make_ladder(events,token=token,cancel_stage=None if phase is None else (phase,stage),expected_state=initial);old=pm.run_root_search;pm.run_root_search=fn
 try:d=player(s,e).choose_action(s,SearchLimits(max_depth=2,max_nodes=20000),cancel_token=token)
 finally:pm.run_root_search=old
 assert s.state==initial and s._search_witnesses==w;assert d.action in s.legal_actions();assert len({x['budget'] for x in events})==1
 if phase=='begin' and stage=='intermediate':assert d.completed_depth==1 and d.result_ordinary_qdepth==0
 if (phase,stage) in [('complete','intermediate'),('begin','configured')]:assert d.completed_depth==2 and d.result_source=='intermediate_iteration' and d.result_ordinary_qdepth==1
 if (phase,stage) in [(None,None),('complete','configured')]:assert d.completed_depth==2 and d.result_ordinary_qdepth==4
 r['rows'].append(dict(cancel=[phase,stage],decision=record_value(d),events=events,restored=True));write_record(p/'contracts.json',r);print(phase,stage,d.result_source,d.result_ordinary_qdepth,d.completed_depth,flush=True)
for q,depth in [(0,2),(4,1)]:
 s,e=position();a=player(s,e).choose_action(s,SearchLimits(max_depth=depth,quiescence_max_depth=q));events=[];old=pm.run_root_search;pm.run_root_search=make_ladder(events)
 try:b=player(s,e).choose_action(s,SearchLimits(max_depth=depth,quiescence_max_depth=q))
 finally:pm.run_root_search=old
 for name in ['action','score','principal_variation','nodes','qnodes','completed_depth','result_source','result_ordinary_qdepth']:assert getattr(a,name)==getattr(b,name),name
 assert not events;r['rows'].append(dict(q=q,max_depth=depth,baseline=record_value(a),candidate=record_value(b),bypassed=True));write_record(p/'contracts.json',r)
r['complete']=True;write_record(p/'contracts.json',r)
