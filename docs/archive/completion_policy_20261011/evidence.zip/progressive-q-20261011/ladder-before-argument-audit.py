"""Private changed-premise D2q1 scheduling probe; not a product policy."""
from pathlib import Path
import inspect,sys,time
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from generic_chess.ai.alphabeta import search
from scripts.research_record import record_value
SOURCE=inspect.getsource(search.run_root_search)
LOOP='    for depth in range(1, max_depth + 1):'
STAGES="""    configured_q = ctx.qdepth_limit
    stages = [(1, configured_q, False, 'reserve')]
    stages += [(2, min(1, configured_q), False, 'intermediate'), (2, configured_q, use_tt, 'configured')]
    stages += [(d, configured_q, use_tt, 'configured') for d in range(3, max_depth + 1)]
    for depth, stage_q, stage_tt, stage in stages:
        ctx.qdepth_limit, ctx.use_tt = stage_q, stage_tt
        _stage_event('begin', stage, depth, ctx, best)"""
CODE=SOURCE.replace(LOOP,STAGES)
CAPTURE="        _set_result_provenance(stats, 'main_iteration', ctx)"
assert CODE.count(CAPTURE)==1
CODE=CODE.replace(CAPTURE, "        _set_result_provenance(stats, 'intermediate_iteration' if stage == 'intermediate' else 'main_iteration', ctx)\n        _stage_event('complete', stage, depth, ctx, best)\n        ctx.qdepth_limit, ctx.use_tt = configured_q, use_tt")
# Restore local policy even when the interrupted search returns retained best.
ANCHOR="""        except SearchAborted as exc:
            abort_reason = str(exc)
            break"""
CODE=CODE.replace(ANCHOR,"""        except SearchAborted as exc:
            _stage_event('aborted', stage, depth, ctx, best, str(exc))
            ctx.qdepth_limit, ctx.use_tt = configured_q, use_tt
            abort_reason = str(exc)
            break""")
assert CODE.count("_stage_event('aborted'")==2
def make_ladder(events,token=None,cancel_stage=None,expected_state=None):
 def event(phase,stage,depth,ctx,best,reason=None):
  ctx.runtime.assert_balanced()
  if expected_state is not None:
   assert ctx.runtime.position==expected_state.position and ctx.runtime.ply_count==expected_state.ply_count
  events.append(dict(phase=phase,stage=stage,depth=depth,q=search._ordinary_qdepth_limit(ctx),hardq=ctx.qhard_depth_limit,use_tt=ctx.use_tt,budget=id(ctx.budget),deadline=ctx.budget._deadline,nodes=ctx.stats.nodes,qnodes=ctx.stats.qnodes,tt_hits=ctx.stats.tt_hits,at=time.perf_counter(),action=record_value(None if best is None else best.best_action),score=None if best is None else best.score,reason=reason))
  if (phase,stage)==cancel_stage: token.cancel()
 ns=dict(search.__dict__);ns['_stage_event']=event;exec(compile(CODE,'<private-q-ladder>','exec'),ns);fn=ns['run_root_search']
 def route(*args,**kwargs):
  limits=kwargs.get('limits')
  if limits is None: limits=args[3]
  if limits.quiescence_max_depth==0 or limits.max_depth==1:return search.run_root_search(*args,**kwargs)
  return fn(*args,**kwargs)
 route.generated_source=CODE
 return route
