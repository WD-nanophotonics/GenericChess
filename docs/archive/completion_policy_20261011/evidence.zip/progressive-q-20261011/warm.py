from pathlib import Path
import copy,sys,time,json,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[2]));sys.path.insert(0,str(Path(__file__).parent))
from ladder import make_ladder
from scripts.reserve_refresh_diagnostic import make_refresh,ORIGINAL,stopped
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),primes=[],rows=[])
write_record(p/'warm.json',r)
for name,game in [('chess-middle','western_chess'),('shogi-tactic','standard_shogi')]:
 stopped();compiled=compile_ruleset_for_execution(build_builtin_ruleset(game));board=CoreBoard(next(x for x in CASES if x['id']==name),compiled);s=GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;initial=s.state;w=s._search_witnesses
 prime=AlphaBetaPlayer(compiled,evaluator_override=board.material,use_native_semantic_legality=False);token=CancellationToken();d=prime.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=10),cancel_token=token,progress_callback=lambda depth,*_:token.cancel() if depth==2 else None)
 r['primes'].append(dict(root=name,decision=record_value(d),entries=len(prime._tt),generation=prime._tt.generation,q_policy=prime._tt_q_depths));write_record(p/'warm.json',r)
 if d.completed_depth!=2:continue
 for allowance in (.05,.1,1):
  for arm in ('q4','phase_bypass','ladder','skip_warm_root'):
   stopped();start=time.perf_counter();engine=AlphaBetaPlayer(compiled,evaluator_override=board.material,use_native_semantic_legality=False);engine._tt=copy.deepcopy(prime._tt);engine._tt_q_depths=prime._tt_q_depths;copied=time.perf_counter();events=[];selection=[]
   fn=ORIGINAL if arm=='q4' else make_ladder(events,expected_state=initial) if arm=='ladder' else make_refresh(events,expected_state=initial,tt_policy=arm,selection_log=selection)
   pm.run_root_search=fn;limits=SearchLimits(max_time_seconds=max(.000001,allowance-(time.perf_counter()-start)),max_depth=3,max_nodes=20000)
   try:out=engine.choose_action(s,limits)
   finally:pm.run_root_search=ORIGINAL
   elapsed=time.perf_counter()-start;assert s.state==initial and s._search_witnesses==w;assert out.action in s.legal_actions()
   r['rows'].append(dict(root=name,allowance=allowance,arm=arm,decision=record_value(out),setup_seconds=copied-start,caller_seconds=elapsed,events=events,selection=selection,restored=True));write_record(p/'warm.json',r);print(name,allowance,arm,out.completed_depth,out.result_ordinary_qdepth,out.result_source,flush=True)
r['complete']=True;write_record(p/'warm.json',r)
