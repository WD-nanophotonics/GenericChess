from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[2]));sys.path.insert(0,str(Path(__file__).parent))
from ladder import make_ladder
from scripts.reserve_refresh_diagnostic import queen_roots,make_refresh,ORIGINAL,stopped,uci
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
ROOT=Path.cwd();p=Path(__file__).parent
source=ROOT/'.local_agent/ui-product-20261010/population-baseline.json'
frozen=json.loads(source.read_bytes());labels={f'ui-{r["game_index"]}-{r["ply"]}':{v['move']:v for v in r['material_root_children']} for r in frozen['roots']}
report=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),label_file_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),rows=[])
write_record(p/'cohort.json',report);start_batch=time.perf_counter()
for i,(name,session,evaluator) in enumerate(queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json',all_ui=True)):
 initial=session.state;w=session._search_witnesses;legal=tuple(session.legal_actions());assert name in labels
 arms=['q4','phase_bypass','ladder'];arms=arms[i%3:]+arms[:i%3]
 for arm in arms:
  stopped();assert time.perf_counter()-start_batch<180;events=[]
  fn=ORIGINAL if arm=='q4' else make_refresh(events,expected_state=initial,tt_policy='phase_bypass') if arm=='phase_bypass' else make_ladder(events,expected_state=initial)
  engine=AlphaBetaPlayer(session.compiled,evaluator_override=evaluator,use_native_semantic_legality=False)
  pm.run_root_search=fn;started=time.perf_counter()
  try:d=engine.choose_action(session,SearchLimits(max_nodes=1000000,max_time_seconds=1,quiescence_max_depth=4,quiescence_hard_max_depth=8))
  finally:pm.run_root_search=ORIGINAL
  elapsed=time.perf_counter()-started;assert session.state==initial and session._search_witnesses==w;assert d.action in legal
  move=uci(d.action);label=labels[name][move];value=None if label['worst'] is None else label['worst']['score']
  report['rows'].append(dict(root=name,arm=arm,decision=record_value(d),move=move,finite_D2_value=value,wall_seconds=elapsed,events=events,restored=True));write_record(p/'cohort.json',report);print(name,arm,move,d.completed_depth,d.result_ordinary_qdepth,value,flush=True)
assert len(report['rows'])==90
report.update(complete=True,wall_seconds=time.perf_counter()-start_batch);write_record(p/'cohort.json',report)
