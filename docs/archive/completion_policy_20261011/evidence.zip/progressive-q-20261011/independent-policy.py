from pathlib import Path
import sys,json,dataclasses
sys.path.insert(0,str(Path(__file__).resolve().parents[2]));sys.path.insert(0,str(Path(__file__).parent))
from ladder import make_ladder
from tests.product.test_search_result_provenance import position,player
from scripts.reserve_refresh_diagnostic import queen_roots
from generic_chess.ai.alphabeta import player as pm,search
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;r=dict(complete=False,rows=[])
roots=[('synthetic',*position())]+[(name,s,e) for name,s,e in queen_roots(Path.cwd()/'.local_agent/ui-product-20261010/games-final.json')]
for name,s,e in roots:
 initial=s.state;w=s._search_witnesses;engine=lambda:AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False,use_tt=False,tuning=SearchTuning(use_root_tactical=False));direct=engine().choose_action(s,SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=1,quiescence_hard_max_depth=8));events=[];token=CancellationToken();old=pm.run_root_search;pm.run_root_search=make_ladder(events,token=token,cancel_stage=('complete','intermediate'),expected_state=initial)
 try:intermediate=engine().choose_action(s,SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token)
 finally:pm.run_root_search=old
 assert s.state==initial and s._search_witnesses==w
 a,b=record_value(direct),record_value(intermediate);verified=False
 if a['completed_depth']==b['completed_depth']==2:
  for field in a:
   if field.endswith('_seconds') or field.startswith('time_to_') or field in ('termination_reason','result_source'):continue
   assert a[field]==b[field],(name,field)
  verified=True
 r['rows'].append(dict(root=name,direct=a,intermediate=b,events=events,exact_return_and_work=verified,restored=True));write_record(p/'independent-policy.json',r);print(name,verified,a['completed_depth'],b['completed_depth'],a['score'],b['score'],flush=True)
r['complete']=True;write_record(p/'independent-policy.json',r)
