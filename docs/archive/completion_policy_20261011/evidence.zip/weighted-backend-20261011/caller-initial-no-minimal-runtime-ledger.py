from pathlib import Path
import sys,time,json,hashlib
from dataclasses import replace,asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import chess
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.config import EvaluationConfig,config_hash
from generic_chess.ai.evaluation.profile import PieceValueProfile,RuleSetEvaluationProfile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.identity import position_identity_key
from generic_chess.ai.budget import ThinkingConfig,ThinkingStrategy
from generic_chess.clock import TimeControl,TimeControlMode
from generic_chess.ui.match import MatchConfig,ParticipantKind
from generic_chess.ui.controller import UIController
from generic_chess.ui.stores import DictSettingsStore
from scripts.search_backend_comparison import CoreBoard,ChessBoard,iterative_minimal,audit_pair,uci
from scripts.research_record import record_value,write_record
B=ROOT/'.local_agent/weighted-backend-20261011'
from scripts.reserve_refresh_diagnostic import make_refresh,ORIGINAL
from generic_chess.ai.alphabeta import player as pm
source=ROOT/'.local_agent/ui-product-20261010/replay-frozen.json'
old=json.loads(source.read_bytes())['roots'][0]
case=dict(id='old-white-queen-ply5',game='chess',setup='start',moves=' '.join(old['moves']))
values=old['original']['material']
names=dict(P=chess.PAWN,N=chess.KNIGHT,B=chess.BISHOP,R=chess.ROOK,Q=chess.QUEEN,K=chess.KING)
labels={x['move']:x for x in old['material_root_children']}
assert len(labels)==43 and old['ply']==5
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
def evaluator(compiled):
 gains={pt.type_id:max(0,max((values[t] for t in pt.promotion_target_ids),default=0)-values[pt.type_id]) for pt in compiled.piece_types}
 profile=RuleSetEvaluationProfile(compiled.ruleset_fingerprint,1,'ui-human-teaching-v1',config_hash(config),
 {pt.type_id:PieceValueProfile(pt.type_id,'human-teaching-v1',0.,values[pt.type_id],values[pt.type_id],gains[pt.type_id],0.,0.,pt.is_anchor,pt.is_promotable) for pt in compiled.piece_types},3000,values,values,gains)
 return Evaluator(compiled,profile,config)
def core():
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
 b=CoreBoard(case,c);b.material.values=values
 return b

def specialized():
 b=ChessBoard(case);b.values={names[k]:v for k,v in values.items()};return b

def stopped():
 for n in ('rollout','advisor','slack'):
  d=json.loads((ROOT/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('stopped') or d.get('user_paused'):raise RuntimeError('project stopped')

sys.path.insert(0,str(B))
from bridge import weighted,WeightedChess
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider

preload=time.perf_counter();compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));eval_weighted=weighted(compiled,values);provider=NativeSemanticLegalityProvider.try_create(compiled,strict=True);preload_seconds=time.perf_counter()-preload
report=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),case=case,material=values,configuration=record_value(eval_weighted._config),preload_seconds=preload_seconds,provider_available=provider is not None,rows=[])
write_record(B/'caller.json',report)
for order,arms in enumerate([['minimal_core','minimal_hybrid','minimal_specialized','public_core','public_hybrid'],['public_hybrid','public_core','minimal_specialized','minimal_hybrid','minimal_core']]):
 for arm in arms:
  stopped();start=time.perf_counter()
  if arm.startswith('public'):
   session=GameSession(compiled)
   for label in case['moves'].split():session.submit({uci(x):x for x in session.legal_actions()}[label])
   ctrl=UIController(settings=DictSettingsStore());ctrl._session=session;ctrl._compiled=compiled;ctrl.start_match(MatchConfig((ParticipantKind.AI,ParticipantKind.HUMAN),TimeControl(mode=TimeControlMode.NONE),ThinkingConfig(strategy=ThinkingStrategy.FIXED_TIME,move_time_seconds=1.,quiescence_max_depth=4)))
   engine=AlphaBetaPlayer(compiled,evaluator_override=eval_weighted,use_native_semantic_legality=arm=='public_hybrid');token=CancellationToken();snapshot=ctrl.capture_ai_search(token);initial=session.state;w=session._search_witnesses;prepared=time.perf_counter();limits=replace(snapshot.limits,max_time_seconds=max(.000001,1-(prepared-start)))
   d=engine.choose_action(session,limits,cancel_token=token);searched=time.perf_counter();assert session.state==initial and session._search_witnesses==w;move=uci(d.action);committed=ctrl.finish_ai_move(d,snapshot);assert committed;endpoint=time.perf_counter();result=dict(move=move,decision=record_value(d),completed_depth=d.completed_depth,score=d.score,reason=d.termination_reason,returned_committed=True,restored=True,work_definition='main+q recursive visits across iterations',limits=asdict(limits))
  else:
   board=WeightedChess(case,eval_weighted) if arm=='minimal_specialized' else CoreBoard(case,compiled,provider if arm=='minimal_hybrid' else None)
   if arm!='minimal_specialized':board.material=eval_weighted
   prepared=time.perf_counter();result=iterative_minimal(board,seconds=max(.000001,1-(prepared-start)),node_limit=1000000,max_depth=12);searched=time.perf_counter();assert board.restored();move=result['move'];actions=dict(board.actions());assert move in actions;board.push(actions[move]);board.pop();endpoint=time.perf_counter();result.update(restored=True,returned_committed=False,return_replay_verified=True,work_definition='minimalrecursive visits inclroot/leaves acrossiterations')
  result.update(arm=arm,order=order,prepare_seconds=prepared-start,search_seconds=searched-prepared,return_seconds=endpoint-searched,caller_seconds=endpoint-start,overrun_seconds=max(0,endpoint-start-1),old_material_finite_D2_value=labels[move]['worst']['score']);report['rows'].append(result);write_record(B/'caller.json',report);print(order,arm,move,result['completed_depth'],result['score'],result['old_material_finite_D2_value'],round(result['caller_seconds'],4),flush=True)
report['complete']=True;write_record(B/'caller.json',report)
