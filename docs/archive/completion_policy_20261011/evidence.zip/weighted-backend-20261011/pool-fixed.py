from pathlib import Path
import sys,time,json,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[2]));sys.path.insert(0,str(Path(__file__).parent))
from bridge import weighted,WeightedChess,WeightedShogi,PooledChess,PooledShogi
from scripts.search_backend_comparison import CASES,VALUES,CoreBoard,minimal_ab,audit_pair
from scripts.reserve_refresh_diagnostic import stopped
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.research_record import write_record
p=Path(__file__).parent;r=dict(complete=False,rows=[],audits=[]);write_record(p/'pool-fixed.json',r)
for case in CASES:
 stopped();game=case['game'];c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if game=='chess' else 'standard_shogi'));e=weighted(c,VALUES[game]);a,b=(WeightedChess,PooledChess) if game=='chess' else (WeightedShogi,PooledShogi)
 for order,arms in enumerate([['off','on'],['on','off']]):
  outputs=[]
  for arm in arms:
   board=(a if arm=='off' else b)(case,e);result=minimal_ab(board,2,seconds=10,node_limit=100000);result.update(root=case['id'],arm=arm,order=order,pool_entries=0 if arm=='off' else len(board.piece_pool));r['rows'].append(result);outputs.append(result);write_record(p/'pool-fixed.json',r);print(case['id'],order,arm,round(result['wall_seconds'],6),flush=True)
  for field in ('move','score','completed_depth','work'):assert outputs[0][field]==outputs[1][field],field
 if case['id'] in ('chess-promotion','chess-ep','shogi-promotion','shogi-drop'):
  core=CoreBoard(case,c);core.material=e;special=b(case,e);states=audit_pair(core,special,2);r['audits'].append(dict(root=case['id'],states=states,pool_entries=len(special.piece_pool)));write_record(p/'pool-fixed.json',r);print('audit',case['id'],states,flush=True)
 trace0=minimal_ab(a(case,e),2,seconds=10,node_limit=100000,trace=True);trace1=minimal_ab(b(case,e),2,seconds=10,node_limit=100000,trace=True);assert trace0['trace_sha256']==trace1['trace_sha256'];r['audits'].append(dict(root=case['id'],leaf_trace=trace0['trace_sha256']));write_record(p/'pool-fixed.json',r)
r['complete']=True;write_record(p/'pool-fixed.json',r)
