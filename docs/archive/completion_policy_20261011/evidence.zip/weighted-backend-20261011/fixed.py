from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[2]));sys.path.insert(0,str(Path(__file__).parent))
from bridge import weighted,WeightedChess,WeightedShogi
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES,minimal_ab,audit_pair
from scripts.reserve_refresh_diagnostic import stopped
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),bridge_sha256=hashlib.sha256((p/'bridge.py').read_bytes()).hexdigest(),values=VALUES,rows=[],audits=[])
write_record(p/'fixed.json',r)
for case in CASES:
 stopped();game=case['game'];compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if game=='chess' else 'standard_shogi'));e=weighted(compiled,VALUES[game]);factory=WeightedChess if game=='chess' else WeightedShogi
 left=CoreBoard(case,compiled);left.material=e;right=factory(case,e);audited=audit_pair(left,right,1);r['audits'].append(dict(root=case['id'],states=audited,config=record_value(e._config),ruleset_fingerprint=compiled.ruleset_fingerprint));write_record(p/'fixed.json',r)
 provider=NativeSemanticLegalityProvider.try_create(compiled,strict=True)
 for order,arms in enumerate([['core','hybrid','specialized'],['specialized','hybrid','core']]):
  outputs=[]
  for arm in arms:
   stopped();setup=time.perf_counter()
   if arm=='specialized':board=factory(case,e)
   else:board=CoreBoard(case,compiled,provider if arm=='hybrid' else None);board.material=e
   prepared=time.perf_counter();result=minimal_ab(board,2,seconds=10,node_limit=100000,trace=False);assert result['reason']=='completed_depth'
   result.update(root=case['id'],arm=arm,order=order,setup_seconds=prepared-setup,provider_available=provider is not None);r['rows'].append(result);outputs.append(result);write_record(p/'fixed.json',r);print(case['id'],order,arm,result['move'],result['score'],result['work']['nodes'],round(result['wall_seconds'],5),result['native_provider_active'],flush=True)
  reference=outputs[0]
  for result in outputs[1:]:
   for field in ('move','score','completed_depth','work'):assert result[field]==reference[field],(case['id'],field)
 # Small separate exact-trace control; hash overhead is not formal timing.
 core=CoreBoard(case,compiled);core.material=e;special=factory(case,e,measure=True);a=minimal_ab(core,2,seconds=10,node_limit=100000,trace=True);b=minimal_ab(special,2,seconds=10,node_limit=100000,trace=True);assert a['trace_sha256']==b['trace_sha256'];assert a['work']==b['work']
 r['audits'][-1].update(trace=a['trace_sha256'],specialized_trace_wall=b['wall_seconds'],adapter_seconds=special.adapter_seconds,evaluation_seconds=special.eval_seconds,actual_evaluation_calls=special.eval_calls,trace_core_wall=a['wall_seconds']);write_record(p/'fixed.json',r)
r['complete']=True;write_record(p/'fixed.json',r)
