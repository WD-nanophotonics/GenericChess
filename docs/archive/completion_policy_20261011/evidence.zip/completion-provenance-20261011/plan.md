Question: can caller result-source and ordinary-q policy provenance distinguish reserves/refreshes/fallbacks without changing behavior?
Immediate action: private source instrumentation plus additive decision subclass, existing Chess finite controls and reserve cancellation events.
Predeclared evidence: paired exact action/score/PV/reason, integer work, restoration and serialization; raw wall/timing differs and is not decision parity.
Scope: descriptive configured policy at last completed assignment, not uniform horizon/value certification; checked extensions and TT selective semantics retained. No UI/default promotion.
Cost: single writer, small sequential local batch, no training/new games/labels; each process bounded well below one hour.
