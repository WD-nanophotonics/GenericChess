import dataclasses,json,statistics,sys,types
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from generic_chess.ai.decision import PlayerDecision
from generic_chess.ai.alphabeta.statistics import SearchStatistics
p=Path(__file__).parent
r={}
for name,current,pkg in [('statistics',SearchStatistics,'generic_chess.ai.alphabeta'),('decision',PlayerDecision,'generic_chess.ai')]:
 m=types.ModuleType('old_'+name);m.__package__=pkg;sys.modules[m.__name__]=m;exec(compile((p/(name+'-before.py')).read_text(),str(p/(name+'-before.py')),'exec'),m.__dict__)
 old=getattr(m,current.__name__);kwargs={}
 if name=='decision':
  row=json.loads((p/'installed.json').read_bytes())['rows'][0]['decision'];kwargs={f.name:row[f.name] for f in dataclasses.fields(old)}
 r[name]=dict(old_slot_bytes=sys.getsizeof(old(**kwargs)),new_slot_bytes=sys.getsizeof(current(**kwargs)),scope='slot container only; referenced data excluded')
 rows=json.loads((p/'fixed-cost-clean.json').read_bytes())['rows'];pairs=list(zip(rows[::2],rows[1::2]));r['clean_fixed_work']=dict(pairs=len(pairs),baseline_seconds=sum(a['wall'] for a,b in pairs),metadata_seconds=sum(b['wall'] for a,b in pairs),paired_ratios=[b['wall']/a['wall'] for a,b in pairs],all_nontiming_work_equal=all(a['counters']==b['counters'] for a,b in pairs))
r['earlier_timing_limit']='fixed-cost.json overlapped full pytest; integer parity retained, timing not accepted'
(p/'size-summary.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
