from __future__ import annotations
import ast, copy, dataclasses, hashlib, inspect, json, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta import search,player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.decision import PlayerDecision
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.search_backend_comparison import CoreBoard,CASES
from scripts.reserve_refresh_diagnostic import make_refresh
from scripts.research_record import record_value,write_record

@dataclasses.dataclass(slots=True)
class MetadataStats(SearchStatistics):
    result_source:str='unknown'
    result_ordinary_qdepth:int|None=None
    result_check_hard_qdepth:int|None=None

@dataclasses.dataclass(frozen=True,slots=True)
class MetadataDecision(PlayerDecision):
    result_source:str='unknown'
    result_ordinary_qdepth:int|None=None
    result_check_hard_qdepth:int|None=None

def metadata(stats,source,ctx=None):
    stats.result_source=source
    stats.result_ordinary_qdepth=None if ctx is None else search._ordinary_qdepth_limit(ctx)
    stats.result_check_hard_qdepth=None if ctx is None else ctx.qhard_depth_limit

def instrument(fn,events=None):
    # Private source-only prototype; returns/counters/TT and policy are untouched.
    source=inspect.getsource(fn) if fn is search.run_root_search else fn.__globals__['_prototype_source']
    tree=ast.parse(source)
    class Instrument(ast.NodeTransformer):
        def visit_Assign(self,node):
            text=ast.unparse(node)
            if text=='stats.completed_depth = depth':
                return [ast.parse("_metadata(stats, 'main_iteration', ctx)").body[0],node]
            if text=='best = refreshed':
                return [node,ast.parse("_metadata(stats, 'refresh_iteration', ctx)").body[0]]
            return node
        def visit_Return(self,node):
            text=ast.unparse(node.value)
            # Retained best has source set at complete assignment, not final limits.
            if 'best.score' in text:return node
            if 'terminal_score' in text:label='terminal';ctx='None'
            elif 'MATE_SCORE, ()' in text:label='root_declaration';ctx='None'
            elif 'immediate_win' in text:label='root_immediate_win';ctx='None'
            elif 'scan_best' in text:label='root_scan_fallback';ctx='None'
            elif text.startswith('(fallback,'):
                # A partial tactical scan can retain its own selected fallback.
                label="root_scan_fallback' if ctx.root_scan_best_action is not None else 'legal_fallback";ctx='None'
            elif text.startswith('(None,'):
                label="terminal' if stats.termination_reason == 'terminal_position' else 'no_legal_fallback";ctx='None'
            else:label='legal_fallback';ctx='None'
            return [ast.parse(f"_metadata(stats, '{label}', {ctx})").body[0],node]
    tree=Instrument().visit(tree);ast.fix_missing_locations(tree)
    namespace=dict(fn.__globals__);namespace['_metadata']=metadata
    exec(compile(tree,'<private-completion-metadata>','exec'),namespace)
    return namespace['run_root_search']

def fixture(name):
    c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
    cases=dict(queen=dict(game='chess',setup='k4b2/6p1/8/8/8/6Q1/8/6K1 w - - 0 1',moves=''),
        mate=dict(game='chess',setup='k7/1Q6/2K5/8/8/8/8/8 w - - 0 1',moves=''),
        terminal=dict(game='chess',setup='7k/6Q1/5K2/8/8/8/8/8 b - - 0 1',moves=''),
        middle=next(x for x in CASES if x['id']=='chess-middle'))
    b=CoreBoard(cases[name],c);s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses
    return s,b.material

def run_one(case,observed):
    for name in ('rollout','advisor','slack'):
        flags=json.loads((ROOT/'.local_agent'/f'{name}.json').read_bytes())
        assert not flags.get('user_paused') and not flags.get('stopped')
    s,e=fixture(case['root']);initial=s.state;w=s._search_witnesses
    events=[];token=CancellationToken() if case.get('cancel') else None
    if case.get('cancel')=='pre':token.cancel()
    fn=search.run_root_search
    if case['arm']=='refresh':
        fn=make_refresh(events,token=token,cancel_phase=case.get('cancel'),expected_state=s.state,tt_policy='phase_bypass')
        from scripts.reserve_refresh_diagnostic import PHASE_MODIFIED
        fn.__globals__['_prototype_source']=PHASE_MODIFIED
    if not observed:
        if case['arm']=='main':
            old_source=(Path(__file__).with_name('search-before.py')).read_text(encoding='utf-8')
            old_source=old_source[old_source.index('def run_root_search('):]
        else:
            old_source=fn.__globals__['_prototype_source']
            old_source='\n'.join(line for line in old_source.splitlines() if '_set_result_provenance(' not in line)+'\n'
        namespace=dict(search.__dict__)
        if case['arm']=='refresh':namespace.update(fn.__globals__)
        exec(compile(old_source,'<preserved-baseline-root>','exec'),namespace)
        fn=namespace['run_root_search']
    oldfn,oldstats=pm.run_root_search,pm.SearchStatistics
    stats=MetadataStats() if observed else SearchStatistics()
    pm.run_root_search=fn;pm.SearchStatistics=lambda:stats
    try:
        p=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False,
            use_tt=case.get('tt',False),tuning=SearchTuning(use_root_tactical=case.get('scan',False)))
        start=time.perf_counter();d=p.choose_action(s,SearchLimits(max_depth=case.get('depth',1),
            max_nodes=case.get('nodes',20000),max_time_seconds=5,
            quiescence_max_depth=case.get('q',4),quiescence_hard_max_depth=8),cancel_token=token)
        wall=time.perf_counter()-start
    finally:pm.run_root_search=oldfn;pm.SearchStatistics=oldstats
    if observed:
        d=MetadataDecision(**{f.name:getattr(d,f.name) for f in dataclasses.fields(PlayerDecision) if not f.name.startswith('result_')},
            **{n:getattr(stats,n) for n in ('result_source','result_ordinary_qdepth','result_check_hard_qdepth')})
    assert s.state==initial and s._search_witnesses==w
    assert d.action is None or d.action in s.legal_actions()
    encoded=record_value(d);assert json.loads(json.dumps(encoded))==encoded
    counters={f.name:record_value(getattr(stats,f.name)) for f in dataclasses.fields(SearchStatistics)
        if not f.name.endswith('_seconds') and not f.name.startswith('time_to_') and not f.name.startswith('result_')}
    return dict(case=case,observed=observed,decision=encoded,counters=counters,wall=wall,
        events=events,restored=True)

def main():
    cases=[dict(id='terminal',root='terminal',arm='main'),dict(id='precancelled',root='queen',arm='main',cancel='pre'),
        dict(id='zero-budget',root='queen',arm='main',nodes=0),
        dict(id='scan-abort',root='queen',arm='main',nodes=1,scan=True),
        dict(id='immediate-mate',root='mate',arm='main',scan=True),
        dict(id='ordinary-reserve',root='queen',arm='main',depth=1),
        dict(id='qzero-main',root='queen',arm='main',depth=2,q=0),
        dict(id='configured-main',root='queen',arm='main',depth=2),
        dict(id='refresh-complete',root='queen',arm='refresh',depth=1),
        dict(id='refresh-abort',root='queen',arm='refresh',depth=2,cancel='begin'),
        dict(id='refresh-cancel-after',root='queen',arm='refresh',depth=2,cancel='complete')]
    out=Path(__file__).with_name('installed.json');report=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
    write_record(out,report)
    for case in cases:
        pair=[run_one(case,observed) for observed in (False,True)]
        a,b=pair
        for field in ('action','score','principal_variation','completed_depth','termination_reason'):
            assert a['decision'][field]==b['decision'][field],(case,field)
        assert a['counters']==b['counters'],case
        report['rows'].extend(pair);write_record(out,report)
        print(case['id'],b['decision']['result_source'],b['decision']['result_ordinary_qdepth'],b['decision']['completed_depth'],flush=True)
    report['complete']=True;write_record(out,report)
if __name__=='__main__':main()
