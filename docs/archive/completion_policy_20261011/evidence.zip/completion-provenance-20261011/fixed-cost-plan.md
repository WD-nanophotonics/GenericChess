Predeclare sixteen paired (32call) fixed-work controls: old queen synthetic and Chess-middle; q0/q4hard4; TT on/off; forward/reverse order; identical256main+q budget/depth3 with no live deadline.
Compare exact returned action/score/PV/source-independent integer work/restoration; retain raw time/adverse cost, do not infer equal-time decision improvement from metadata.
New premise is additive source observability; unlike last segment this measures metadata overhead, not search policy. No new labels/games or old budget extension.
