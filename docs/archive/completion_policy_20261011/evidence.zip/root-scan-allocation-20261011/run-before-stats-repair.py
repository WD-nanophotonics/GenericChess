from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.reserve_refresh_diagnostic import queen_roots,stopped,uci,ORIGINAL
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from tests.product.test_search_result_provenance import position
B=Path(__file__).parent
label_file=Path('.local_agent/ui-product-20261010/population-baseline.json')
frozen=json.loads(label_file.read_bytes());labels={f'ui-{r["game_index"]}-{r["ply"]}':{v['move']:v for v in r['material_root_children']} for r in frozen['roots']}
report=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),label_sha256=hashlib.sha256(label_file.read_bytes()).hexdigest(),rows=[],controls=[])
start=time.perf_counter()
def call(session,evaluator,scan,limits):
 stopped();before=session.state;w=session._search_witnesses;stats=[]
 def observed(*args,**kw):
  result=ORIGINAL(*args,**kw);stats.append(record_value(result[-1]));return result
 pm.run_root_search=observed;engine=AlphaBetaPlayer(session.compiled,evaluator_override=evaluator,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=scan));t=time.perf_counter()
 try:d=engine.choose_action(session,limits)
 finally:pm.run_root_search=ORIGINAL
 elapsed=time.perf_counter()-t;assert session.state==before and session._search_witnesses==w;assert d.action in session.legal_actions()
 return dict(scan=scan,decision=record_value(d),move=uci(d.action),stats=stats[0],wall_seconds=elapsed,restored=True)
for i,(name,s,e) in enumerate(queen_roots(Path('.local_agent/ui-product-20261010/games-final.json'),all_ui=True)):
 for scan in ([True,False] if i%2==0 else [False,True]):
  assert time.perf_counter()-start<100
  row=call(s,e,scan,SearchLimits(max_nodes=1000000,max_time_seconds=1,quiescence_max_depth=4,quiescence_hard_max_depth=8));row['root']=name;lab=labels[name][row['move']];row['finite_D2_value']=None if lab['worst'] is None else lab['worst']['score'];report['rows'].append(row);write_record(B/'run.json',report);print(name,scan,row['decision']['completed_depth'],row['finite_D2_value'],round(row['stats']['root_scan_seconds'],4),flush=True)
for name,s,e in queen_roots(Path('.local_agent/ui-product-20261010/games-final.json')):
 for scan in (True,False):
  row=call(s,e,scan,SearchLimits(max_depth=1));row.update(root=name,control='fixed_D1');report['controls'].append(row)
for name,fen in [('mate','k7/1Q6/2K5/8/8/8/8/8 w - - 0 1'),('queen','k4b2/6p1/8/8/8/6Q1/8/6K1 w - - 0 1')]:
 s,e=position(fen)
 for nodes in (1,10,50):
  for scan in (True,False):
   row=call(s,e,scan,SearchLimits(max_nodes=nodes,max_depth=2));row.update(root=name,control='node_fallback',node_cap=nodes);report['controls'].append(row)
report.update(complete=True,wall_seconds=time.perf_counter()-start);write_record(B/'run.json',report)
a={r['root']:r for r in report['rows'] if r['scan']};b={r['root']:r for r in report['rows'] if not r['scan']}
summary=dict(better=sum(b[k]['finite_D2_value']>a[k]['finite_D2_value'] for k in a),worse=sum(b[k]['finite_D2_value']<a[k]['finite_D2_value'] for k in a),tie=sum(b[k]['finite_D2_value']==a[k]['finite_D2_value'] for k in a),extra_completed_depth=sum(b[k]['decision']['completed_depth']>a[k]['decision']['completed_depth'] for k in a),scan_seconds_total=sum(r['stats']['root_scan_seconds'] for r in a.values()),scan_nodes_total=sum(r['stats']['root_scan_nodes'] for r in a.values()))
write_record(B/'summary.json',summary);print(summary,flush=True)
