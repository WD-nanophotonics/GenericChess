from pathlib import Path
import sys,time,json,hashlib
from dataclasses import replace,asdict
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import chess
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.evaluation.config import EvaluationConfig,config_hash
from generic_chess.ai.evaluation.profile import PieceValueProfile,RuleSetEvaluationProfile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.identity import position_identity_key
from generic_chess.ai.budget import ThinkingConfig,ThinkingStrategy
from generic_chess.clock import TimeControl,TimeControlMode
from generic_chess.ui.match import MatchConfig,ParticipantKind
from generic_chess.ui.controller import UIController
from generic_chess.ui.stores import DictSettingsStore
from scripts.search_backend_comparison import CoreBoard,ChessBoard,iterative_minimal,audit_pair,uci
from scripts.research_record import record_value,write_record
B=ROOT/'.local_agent/evaluation-bitmaps-20261011'
from scripts.reserve_refresh_diagnostic import make_refresh,ORIGINAL
from generic_chess.ai.alphabeta import player as pm
source=ROOT/'.local_agent/ui-product-20261010/replay-frozen.json'
old=json.loads(source.read_bytes())['roots'][0]
case=dict(id='old-white-queen-ply5',game='chess',setup='start',moves=' '.join(old['moves']))
values=old['original']['material']
names=dict(P=chess.PAWN,N=chess.KNIGHT,B=chess.BISHOP,R=chess.ROOK,Q=chess.QUEEN,K=chess.KING)
labels={x['move']:x for x in old['material_root_children']}
assert len(labels)==43 and old['ply']==5
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
def evaluator(compiled):
 gains={pt.type_id:max(0,max((values[t] for t in pt.promotion_target_ids),default=0)-values[pt.type_id]) for pt in compiled.piece_types}
 profile=RuleSetEvaluationProfile(compiled.ruleset_fingerprint,1,'ui-human-teaching-v1',config_hash(config),
 {pt.type_id:PieceValueProfile(pt.type_id,'human-teaching-v1',0.,values[pt.type_id],values[pt.type_id],gains[pt.type_id],0.,0.,pt.is_anchor,pt.is_promotable) for pt in compiled.piece_types},3000,values,values,gains)
 return Evaluator(compiled,profile,config)
def core():
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
 b=CoreBoard(case,c);b.material.values=values
 return b

def specialized():
 b=ChessBoard(case);b.values={names[k]:v for k,v in values.items()};return b

def stopped():
 for n in ('rollout','advisor','slack'):
  d=json.loads((ROOT/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('stopped') or d.get('user_paused'):raise RuntimeError('project stopped')

sys.path.insert(0,str(ROOT/'.local_agent/progressive-q-20261011'))
from ladder import make_ladder
from generic_chess.ai.limits import SearchLimits

from scripts.reserve_refresh_diagnostic import queen_roots
_,_,weighted=next(queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json'))
report=dict(complete=False,rows=[])
for order,arms in enumerate([['material','shadow','weighted'],['weighted','shadow','material']]):
 for arm in arms:
  stopped();start=time.perf_counter();board=core();compiled=board.compiled;session=GameSession(compiled)
  for label in case['moves'].split():session.submit({uci(x):x for x in session.legal_actions()}[label])
  mat=evaluator(compiled);calls=[]
  class CostControl:
   def evaluate(self,state):
    begin=time.perf_counter();wvalue=weighted.evaluate(state) if arm!='material' else None;weighted_seconds=time.perf_counter()-begin;mvalue=mat.evaluate(state) if arm!='weighted' else None;calls.append(dict(weighted_seconds=weighted_seconds,material=mvalue,weighted=wvalue));return wvalue if arm=='weighted' else mvalue
   def capture_order_value(self,*args):return mat.capture_order_value(*args)
   def type_value(self,*args):return mat.type_value(*args)
  engine=AlphaBetaPlayer(compiled,evaluator_override=CostControl(),use_native_semantic_legality=False);prepared=time.perf_counter();events=[];pm.run_root_search=make_ladder(events,expected_state=session.state)
  try:d=engine.choose_action(session,SearchLimits(max_time_seconds=max(.000001,1-(prepared-start)),max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
  finally:pm.run_root_search=ORIGINAL
  move=uci(d.action);elapsed=time.perf_counter()-start;assert d.action in session.legal_actions()
  report['rows'].append(dict(arm=arm,order=order,decision=record_value(d),move=move,finite_D2_value=labels[move]['worst']['score'],caller_seconds=elapsed,weighted_eval_seconds=sum(x['weighted_seconds'] for x in calls),evaluation_trace=calls,events=events));write_record(B/'score-cost.json',report);print(order,arm,move,d.completed_depth,d.result_ordinary_qdepth,len(calls),sum(x['weighted_seconds'] for x in calls),flush=True)
report['complete']=True;write_record(B/'score-cost.json',report)
