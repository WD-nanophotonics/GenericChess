from pathlib import Path
import sys,time,json,pickle,hashlib,dataclasses,collections
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.reserve_refresh_diagnostic import queen_roots,stopped
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core.attacks import anchor_square
from scripts.research_record import record_value,write_record
ROOT=Path.cwd();p=Path(__file__).parent
roots=list(queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json'));compiled=roots[0][1].compiled;b=CoreBoard(next(c for c in CASES if c['id']=='chess-middle'),compiled);s=GameSession(compiled);s._state=b.initial;s._search_history_witnesses=b.witnesses;roots.append(('chess-middle',s,roots[0][2]))
report=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),roots=[]);write_record(p/'trace-capture.json',report)
for name,s,e in roots:
 stopped();inputs=[];before=s.state;w=s._search_witnesses;limits=SearchLimits(max_depth=3,max_nodes=512,quiescence_max_depth=4,quiescence_hard_max_depth=8)
 baseline=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False).choose_action(s,limits)
 class Capture:
  def evaluate(self,state):
   runtime=state._runtime;inputs.append(dict(position=state.position,ply_count=state.ply_count,terminal_status=state.terminal_status,history=tuple(runtime.history),repetition_counts=tuple(runtime.repetition_counts.items())));return e.evaluate(state)
  def capture_order_value(self,*args):return e.capture_order_value(*args)
  def type_value(self,*args):return e.type_value(*args)
 start=time.perf_counter();traced=AlphaBetaPlayer(s.compiled,evaluator_override=Capture(),use_native_semantic_legality=False).choose_action(s,limits);elapsed=time.perf_counter()-start
 a=record_value(baseline);z=record_value(traced)
 for k in a:
  if k.endswith('_seconds') or k.startswith('time_to_') or k=='elapsed_seconds':continue
  assert a[k]==z[k],(name,k,a[k],z[k])
 assert s.state==before and s._search_witnesses==w;assert len(inputs)==traced.evaluation_calls
 blob=pickle.dumps(dict(inputs=inputs),protocol=5);path=p/(name+'-inputs.pkl');path.write_bytes(blob)
 row=dict(root=name,baseline=a,traced=z,trace_wall_seconds=elapsed,input_calls=len(inputs),input_bytes=len(blob),input_sha256=hashlib.sha256(blob).hexdigest(),file=path.name,configuration=record_value(e._config),ruleset_fingerprint=s.compiled.ruleset_fingerprint,position_dependencies='evaluate reads position; fullpath snapshot retained, not a TT key',restored=True)
 report['roots'].append(row);write_record(p/'trace-capture.json',report);print(name,len(inputs),len(blob),baseline.elapsed_seconds,elapsed,flush=True)
report['complete']=True;write_record(p/'trace-capture.json',report)
