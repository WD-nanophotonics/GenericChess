from pathlib import Path
import sys,pickle,hashlib,json,time,dataclasses,collections
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.reserve_refresh_diagnostic import queen_roots
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core.attacks import anchor_square
from scripts.research_record import record_value,write_record
ROOT=Path.cwd();p=Path(__file__).parent;capture=json.loads((p/'trace-capture.json').read_bytes());_,_,weighted=next(queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json'));compiled=weighted._compiled;material=Evaluator(compiled,weighted._profile,dataclasses.replace(weighted._config,dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0))
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),roots=[])
def components(e,s):
 start=time.perf_counter();pos=s.position;board=sum((1 if piece.owner==0 else -1)*e._profile.board_value_by_type[piece.current_type_id] for piece in pos.board if piece is not None);hand=sum((1 if owner==0 else -1)*count*e._profile.hand_value_by_base_type[tid] for owner in (0,1) for tid,count in pos.hands[owner].counts);promotion=sum(e._promotion_bonus(piece,idx) for idx,piece in enumerate(pos.board) if piece is not None);scalar_end=time.perf_counter();maps=e._attack_maps(s);kernel_end=time.perf_counter();mob=len(maps[0])-len(maps[1]);esc=e._anchor_escape(pos,0,maps[1])-e._anchor_escape(pos,1,maps[0]);checks=10*(int(anchor_square(pos,1,compiled) in maps[0])-int(anchor_square(pos,0,compiled) in maps[1]));total=board+hand+promotion+e._config.dynamic_mobility_weight*mob+e._config.anchor_escape_weight*(esc+checks);total=total if pos.side_to_move==0 else -total;end=time.perf_counter();return dict(features=dict(board=board,hand=hand,promotion=promotion,mobility_diff=mob,escape_diff=esc,check_diff=checks,side_to_move=pos.side_to_move),score=total,nonoverlap_seconds=dict(scalar=scalar_end-start,geometric_kernel=kernel_end-scalar_end,remainder=end-kernel_end),map_sizes=[len(x) for x in maps])
for entry in capture['roots']:
 blob=(p/entry['file']).read_bytes();assert hashlib.sha256(blob).hexdigest()==entry['input_sha256'];assert entry['ruleset_fingerprint']==compiled.ruleset_fingerprint
 # Only own hash-bound trusted fixture pickles, never user files.
 inputs=pickle.loads(blob)['inputs'];states=[SimpleNamespace(**x) for x in inputs];rows=[]
 for order,arms in enumerate([['weighted','material'],['material','weighted']]):
  for arm in arms:
   e=weighted if arm=='weighted' else material;start=time.perf_counter();values=[e.evaluate(s) for s in states];elapsed=time.perf_counter()-start;rows.append(dict(arm=arm,order=order,calls=len(values),wall_seconds=elapsed,scores=values))
 values=[components(weighted,s) for s in states];assert [x['score'] for x in values]==rows[0]['scores'];assert rows[0]['scores']==rows[-1]['scores'];assert rows[1]['scores']==rows[2]['scores']
 full=[hashlib.sha256(pickle.dumps(x,protocol=5)).hexdigest() for x in inputs];positions=[hashlib.sha256(pickle.dumps(x['position'],protocol=5)).hexdigest() for x in inputs];counts=collections.Counter(positions)
 r['roots'].append(dict(root=entry['root'],calls=len(inputs),full_input_unique=len(set(full)),position_query_unique=len(counts),position_repeats=sum(v-1 for v in counts.values()),max_position_multiplicity=max(counts.values()),replay=rows,components=values,component_sums={k:sum(x['nonoverlap_seconds'][k] for x in values) for k in ('scalar','geometric_kernel','remainder')},input_bytes=len(blob),input_sha256=entry['input_sha256'],all_scores_exact=True));write_record(p/'replay.json',r);print(entry['root'],len(inputs),len(set(full)),len(counts),[(x['arm'],round(x['wall_seconds'],6)) for x in rows],r['roots'][-1]['component_sums'],flush=True)
r['complete']=True;r['query_scope']='Legacy geometric pseudo_attacks, not semantic checking/capture query. Two maps per evaluation shared for all features. Cross-node repeated position alone is not a TT identity.';write_record(p/'replay.json',r)
