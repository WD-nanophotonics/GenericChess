from pathlib import Path
import sys,time,json,dataclasses,cProfile,pstats
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.reserve_refresh_diagnostic import queen_roots
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
ROOT=Path.cwd();p=Path(__file__).parent
name,s,e=next(queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json'));states=[s.state]+[apply_action(s.state,a,s.compiled) for a in s.legal_actions()]
material=Evaluator(s.compiled,e._profile,dataclasses.replace(e._config,dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0));r=dict(root=name,states=len(states),rows=[])
for order,arms in enumerate([['weighted','material'],['material','weighted']]):
 for arm in arms:
  evaluator=e if arm=='weighted' else material;start=time.perf_counter();values=[evaluator.evaluate(state) for _ in range(8) for state in states];elapsed=time.perf_counter()-start;r['rows'].append(dict(order=order,arm=arm,calls=len(values),wall_seconds=elapsed,values=values))
prof=cProfile.Profile();prof.enable();values=[e.evaluate(state) for _ in range(8) for state in states];prof.disable();prof.dump_stats(str(p/'weighted.prof'));stats=pstats.Stats(prof);r['profile']=[dict(file=k[0],line=k[1],function=k[2],primitive_calls=v[0],calls=v[1],self_seconds=v[2],cumulative_seconds=v[3]) for k,v in stats.stats.items()];r['scope']='profilecumulative overlaps, fixed88?states*8calls; no live budget';write_record(p/'profile.json',r);print(r['root'],len(states));print([(x['arm'],x['wall_seconds']) for x in r['rows']]);print(sorted(r['profile'],key=lambda x:-x['cumulative_seconds'])[:9])
