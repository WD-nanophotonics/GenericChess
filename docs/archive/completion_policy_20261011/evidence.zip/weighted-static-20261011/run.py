from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path('.local_agent/weighted-backend-20261011').resolve()))
from bridge import weighted
from scripts.search_backend_comparison import CASES,VALUES,CoreBoard,minimal_ab,uci
from scripts.reserve_refresh_diagnostic import queen_roots,stopped
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixed=[],caller=[]);write_record(p/'run.json',r)
for case in CASES:
 stopped();c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));e=weighted(c,VALUES[case['game']]);b=CoreBoard(case,c);b.material=e
 base=minimal_ab(b,2,seconds=10,node_limit=100000);assert base['completed_depth']==2;r['fixed'].append(dict(root=case['id'],arm='minimal',**base))
 for tt in (False,True):
  b=CoreBoard(case,c);stats=SearchStatistics();t=time.perf_counter();a,score,pv,reason=run_root_search(b.initial,c,e,TranspositionTable(max_entries=65536),SearchLimits(max_depth=2,max_nodes=100000,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=tt,use_ordering=tt,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=b.witnesses);wall=time.perf_counter()-t;assert stats.completed_depth==2 and b.restored();row=dict(root=case['id'],arm='public_TT_order' if tt else 'public_plain',move=b.label(a),score=score,reason=reason,wall_seconds=wall,statistics=record_value(stats),same_value=score==base['score'],same_move=b.label(a)==base['move']);r['fixed'].append(row);print(case['id'],row['arm'],score,base['score'],row['same_move'],flush=True);write_record(p/'run.json',r)
old=json.loads(Path('.local_agent/ui-product-20261010/replay-frozen.json').read_bytes());labels={f'queen-{i}':{v['move']:v for v in root['material_root_children']} for i,root in enumerate(old['roots'])}
for name,s,e in queen_roots(Path('.local_agent/ui-product-20261010/games-final.json')):
 before=s.state;w=s._search_witnesses
 for order,qs in enumerate(((0,4),(4,0))):
  for q in qs:
   stopped();engine=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False);t=time.perf_counter();d=engine.choose_action(s,SearchLimits(max_nodes=1000000,max_time_seconds=1,quiescence_max_depth=q,quiescence_hard_max_depth=8));wall=time.perf_counter()-t;assert s.state==before and s._search_witnesses==w;move=uci(d.action);lab=labels[name][move];row=dict(root=name,q=q,order=order,decision=record_value(d),move=move,wall_seconds=wall,finite_D2_value=lab['worst']['score'],restored=True);r['caller'].append(row);write_record(p/'run.json',r);print(name,q,d.completed_depth,move,row['finite_D2_value'],flush=True)
r['complete']=True;write_record(p/'run.json',r)
