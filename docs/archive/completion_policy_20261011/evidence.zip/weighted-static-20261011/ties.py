from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path('.local_agent/weighted-backend-20261011').resolve()))
from bridge import weighted
from scripts.search_backend_comparison import CASES,VALUES,CoreBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.research_record import write_record
r=json.loads(Path('.local_agent/weighted-static-20261011/run.json').read_bytes());out=[]
for name in ('shogi-middle','shogi-tactic'):
 case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));e=weighted(c,VALUES['shogi']);b=CoreBoard(case,c);b.material=e
 moves=sorted(set(x['move'] for x in r['fixed'] if x['root']==name))
 for move in moves:
  action=dict(b.actions())[move];b.push(action)
  try:
   t=b.terminal(1)
   if t is not None:v=-t;count=0
   else:
    values=[]
    for label,a in b.actions():
     b.push(a)
     try:t=b.terminal(2);values.append(t if t is not None else b.evaluate())
     finally:b.pop()
    v=min(values);count=len(values)
  finally:b.pop()
  assert b.restored();assert v==next(x['score'] for x in r['fixed'] if x['root']==name)
  out.append(dict(root=name,move=move,full_child_finite_D2_value=v,reply_count=count))
write_record(Path('.local_agent/weighted-static-20261011/ties.json'),out);print(out)
