from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.reserve_refresh_diagnostic import queen_roots,stopped,uci
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import search
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
B=Path(__file__).parent;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[]);CTX=search._Context
old=json.loads(Path('.local_agent/ui-product-20261010/replay-frozen.json').read_bytes());labels={f'queen-{i}':{v['move']:v for v in root['material_root_children']} for i,root in enumerate(old['roots'])}
for name,s,e in queen_roots(Path('.local_agent/ui-product-20261010/games-final.json')):
 before=s.state;w=s._search_witnesses
 for timed in (False,True):
  for order,arms in enumerate(((False,True),(True,False))):
   for ordered in arms:
    stopped();contexts=[]
    def context(*a,**kw):c=CTX(*a,**kw);contexts.append(c);return c
    search._Context=context;engine=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False,tuning=SearchTuning(use_ordered_qsearch=ordered));t=time.perf_counter()
    try:d=engine.choose_action(s,SearchLimits(max_depth=None if timed else 3,max_nodes=1000000 if timed else 512,max_time_seconds=1 if timed else 10,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    finally:search._Context=CTX
    wall=time.perf_counter()-t;rt=contexts[0].runtime;assert s.state==before and s._search_witnesses==w and rt.pushes==rt.pops;move=uci(d.action);r['rows'].append(dict(root=name,timed=timed,ordered=ordered,order=order,decision=record_value(d),move=move,wall_seconds=wall,runtime_pushes=rt.pushes,runtime_pops=rt.pops,finite_D2_value=labels[name][move]['worst']['score']));write_record(B/'ordering.json',r);print(name,timed,ordered,d.completed_depth,d.termination_reason,rt.pushes,round(wall,4),r['rows'][-1]['finite_D2_value'],flush=True)
r['complete']=True;write_record(B/'ordering.json',r)
