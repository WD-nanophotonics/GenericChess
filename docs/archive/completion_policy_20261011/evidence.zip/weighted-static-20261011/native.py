from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.reserve_refresh_diagnostic import queen_roots,stopped,uci
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import search,player as pm
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
B=Path(__file__).parent;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixed=[],timed=[]);CTX=search._Context
for i,(name,s,e) in enumerate(queen_roots(Path('.local_agent/ui-product-20261010/games-final.json'))):
 before=s.state;w=s._search_witnesses
 for timed in (False,True):
  for q in (1,4):
   orders=((False,True),(True,False)) if not timed else ((False,True) if i==0 else (True,False),)
   for order,arms in enumerate(orders):
    for native in arms:
     stopped();contexts=[]
     def context(*a,**kw):c=CTX(*a,**kw);contexts.append(c);return c
     search._Context=context;engine=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=native);t=time.perf_counter()
     try:d=engine.choose_action(s,SearchLimits(max_depth=None if timed else 3,max_nodes=1000000 if timed else 512,max_time_seconds=1 if timed else 10,quiescence_max_depth=q,quiescence_hard_max_depth=8))
     finally:search._Context=CTX
     wall=time.perf_counter()-t;rt=contexts[0].runtime;assert s.state==before and s._search_witnesses==w and rt.pushes==rt.pops
     if native:assert rt._legal_provider_active and rt.legal_provider_calls>0 and rt.legal_provider_fallbacks==0 and rt.legal_provider_operational_failures==0
     row=dict(root=name,q=q,native=native,order=order,decision=record_value(d),move=uci(d.action),wall_seconds=wall,actual_provider_active=rt._legal_provider_active,runtime={k:getattr(rt,k) for k in ('pushes','pops','legal_provider_calls','legal_provider_actions','legal_provider_fallbacks','legal_provider_operational_failures')});r['timed' if timed else 'fixed'].append(row);write_record(B/'native.json',r);print(name,timed,q,native,d.completed_depth,round(wall,4),rt.legal_provider_calls,flush=True)
for name in {x['root'] for x in r['fixed']}:
 for q in (1,4):
  rows=[x for x in r['fixed'] if x['root']==name and x['q']==q]
  def clean(x):return {k:v for k,v in x.items() if 'seconds' not in k and not k.startswith('time_') and not k.startswith('native_')}
  assert all(clean(x['decision'])==clean(rows[0]['decision']) for x in rows);assert len(set(x['runtime']['pushes'] for x in rows))==1
r['complete']=True;write_record(B/'native.json',r)
