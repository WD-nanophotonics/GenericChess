from pathlib import Path
import sys,json,time,hashlib,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.reserve_refresh_diagnostic import queen_roots,stopped
from generic_chess.ai.alphabeta import search,player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
B=Path(__file__).parent;NOISY=search.noisy_child;CTX=search._Context;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),pairs=[])
for name,s,e in queen_roots(Path('.local_agent/ui-product-20261010/games-final.json')):
 for q in (1,4):
  rows=[];stopped();before=s.state;w=s._search_witnesses
  for trace in (False,True):
   counts=collections.Counter();duration=[0.];contexts=[];stats=[]
   def noisy(*args,**kwargs):
    t=time.perf_counter()
    try:v=NOISY(*args,**kwargs)
    finally:duration[0]+=time.perf_counter()-t
    counts['included' if v else 'excluded']+=1;counts[('included_' if v else 'excluded_')+args[0].actor_type_id]+=1;return v
   def context(*args,**kwargs):c=CTX(*args,**kwargs);contexts.append(c);return c
   def root(*args,**kwargs):v=search.run_root_search(*args,**kwargs);stats.append(record_value(args[6]));return v
   search._Context=context
   if trace:search.noisy_child=noisy
   pm.run_root_search=root;engine=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False);t=time.perf_counter()
   try:d=engine.choose_action(s,SearchLimits(max_depth=3,max_nodes=512,max_time_seconds=10,quiescence_max_depth=q,quiescence_hard_max_depth=8))
   finally:search._Context=CTX;search.noisy_child=NOISY;pm.run_root_search=search.run_root_search
   wall=time.perf_counter()-t;runtime=contexts[0].runtime;assert runtime.pushes==runtime.pops and s.state==before and s._search_witnesses==w;rows.append(dict(trace=trace,decision=record_value(d),stats=stats[0],counts=dict(counts),predicate_seconds=duration[0],wall_seconds=wall,runtime_pushes=runtime.pushes,runtime_pops=runtime.pops))
  def clean(x):return {k:v for k,v in x.items() if 'seconds' not in k and not k.startswith('time_')}
  assert clean(rows[0]['decision'])==clean(rows[1]['decision']);assert clean(rows[0]['stats'])==clean(rows[1]['stats']);assert rows[0]['runtime_pushes']==rows[1]['runtime_pushes'];r['pairs'].append(dict(root=name,q=q,rows=rows,parity=True));write_record(B/'classification.json',r);print(name,q,rows[1]['counts'],rows[1]['runtime_pushes'],round(rows[1]['predicate_seconds'],4),flush=True)
r['complete']=True;write_record(B/'classification.json',r)
