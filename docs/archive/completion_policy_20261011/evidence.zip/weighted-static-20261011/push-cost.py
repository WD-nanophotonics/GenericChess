from pathlib import Path
import sys,time,json,hashlib,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.reserve_refresh_diagnostic import queen_roots,stopped
from generic_chess.core import search_runtime as rtmod
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.alphabeta import search
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
B=Path(__file__).parent;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),pairs=[]);CTX=search._Context
for name,s,e in queen_roots(Path('.local_agent/ui-product-20261010/games-final.json')):
 stopped();before=s.state;w=s._search_witnesses;rows=[]
 for trace in (False,True):
  contexts=[];patches=[];stack=['outside'];times=collections.Counter();counts=collections.Counter();last=[time.perf_counter()]
  def edge():
   now=time.perf_counter();times[stack[-1]]+=now-last[0];last[0]=now
  def patch(owner,attr,label):
   original=getattr(owner,attr)
   def wrapped(*args,**kw):
    edge();stack.append(label);counts[label]+=1
    try:return original(*args,**kw)
    finally:edge();stack.pop()
   setattr(owner,attr,wrapped);patches.append((owner,attr,original))
  if trace:
   patch(rtmod.SearchPathRuntime,'_push_impl','push_remainder');patch(rtmod.SearchPathRuntime,'pop','pop');patch(type(semantic_engine_for(s.compiled)),'_transition','transition');patch(rtmod.SearchPathRuntime,'_gave_check','check');patch(rtmod,'terminal_from_search_runtime','terminal');patch(rtmod,'_runtime_position_identity','identity');patch(rtmod,'_semantic_component_diff_hash','hash');patch(rtmod.SearchPathRuntime,'_occurrence_add','occurrence')
  def context(*args,**kw):c=CTX(*args,**kw);contexts.append(c);return c
  search._Context=context;engine=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False);t=time.perf_counter();last[0]=t
  try:d=engine.choose_action(s,SearchLimits(max_depth=3,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8));edge();end=last[0]
  finally:
   for owner,attr,old in reversed(patches):setattr(owner,attr,old)
   search._Context=CTX
  assert stack==['outside'];assert abs(sum(times.values())-(end-t))<1e-7;rt=contexts[0].runtime;assert s.state==before and s._search_witnesses==w and rt.pushes==rt.pops
  rows.append(dict(trace=trace,decision=record_value(d),statistics=record_value(contexts[0].stats),runtime_pushes=rt.pushes,wall_seconds=end-t,exclusive_seconds=dict(times),calls=dict(counts)))
 def clean(x):return {k:v for k,v in x.items() if 'seconds' not in k and not k.startswith('time_')}
 assert clean(rows[0]['decision'])==clean(rows[1]['decision']);assert clean(rows[0]['statistics'])==clean(rows[1]['statistics']);assert rows[0]['runtime_pushes']==rows[1]['runtime_pushes'];r['pairs'].append(dict(root=name,rows=rows,exact_work_parity=True));write_record(B/'push-cost.json',r);print(name,rows[0]['wall_seconds'],rows[1]['wall_seconds'],rows[1]['exclusive_seconds'],rows[1]['calls'],flush=True)
r['complete']=True;write_record(B/'push-cost.json',r)
