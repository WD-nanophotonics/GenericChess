from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.reserve_refresh_diagnostic import queen_roots,stopped
from generic_chess.core import search_runtime as m
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.alphabeta import search
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
B=Path(__file__).parent;OLD=m._semantic_component_diff_hash;CTX=search._Context;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
def tail(position,compiled):
 values={('ruleset',):compiled.ruleset_fingerprint,('side',):position.side_to_move}
 for owner,hand in enumerate(position.hands):values[('hand',owner)]=tuple(hand.counts)
 engine=semantic_engine_for(compiled)
 if engine is not None:
  physical=dict(position.aux_state);covered=set()
  for slot in engine.ir.aux_slots:
   for owner in ((-1,) if slot.scope=='global' else (0,1)):
    address=(slot.slot_id,owner);covered.add(address);values[('aux',address)]=physical.get(address,slot.initial)
  for address,value in position.aux_state:
   if address not in covered:values[('aux_unknown',address)]=value
 return values
def candidate(parent,child,compiled,current):
 value=current
 for i,(a,b) in enumerate(zip(parent.board,child.board)):
  if a is b:continue
  old=None if a is None else (a.owner,a.base_type_id,a.current_type_id,a.promoted);new=None if b is None else (b.owner,b.base_type_id,b.current_type_id,b.promoted)
  if old!=new:value=m._xor(m._xor(value,m._component_token(('board',i),old)),m._component_token(('board',i),new))
 before,after=tail(parent,compiled),tail(child,compiled)
 for address in before.keys()|after.keys():
  old,new=before.get(address),after.get(address)
  if old!=new:
   if address in before:value=m._xor(value,m._component_token(address,old))
   if address in after:value=m._xor(value,m._component_token(address,new))
 return value
for name,s,e in queen_roots(Path('.local_agent/ui-product-20261010/games-final.json')):
 stopped();before=s.state;w=s._search_witnesses
 for order,arms in enumerate(((False,True),(True,False))):
  pair=[]
  for experimental in arms:
   contexts=[]
   def context(*a,**kw):c=CTX(*a,**kw);contexts.append(c);return c
   m._semantic_component_diff_hash=candidate if experimental else OLD;search._Context=context;engine=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False);t=time.perf_counter()
   try:d=engine.choose_action(s,SearchLimits(max_depth=3,max_nodes=512,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   finally:m._semantic_component_diff_hash=OLD;search._Context=CTX
   wall=time.perf_counter()-t;rt=contexts[0].runtime;assert s.state==before and s._search_witnesses==w and rt.pushes==rt.pops;assert rt.runtime_hash==m._full_runtime_hash(rt.position,s.compiled);row=dict(root=name,order=order,experimental=experimental,wall_seconds=wall,decision=record_value(d),statistics=record_value(contexts[0].stats));r['rows'].append(row);pair.append(row);write_record(B/'hash.json',r);print(name,order,experimental,round(wall,4),flush=True)
  def clean(x):return {k:v for k,v in x.items() if 'seconds' not in k and not k.startswith('time_')}
  assert clean(pair[0]['decision'])==clean(pair[1]['decision']);assert clean(pair[0]['statistics'])==clean(pair[1]['statistics'])
r['complete']=True;write_record(B/'hash.json',r)
