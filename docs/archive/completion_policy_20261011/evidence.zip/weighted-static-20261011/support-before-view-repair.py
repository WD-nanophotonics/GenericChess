from pathlib import Path
import sys,json,dataclasses,hashlib
sys.path.insert(0,str(Path.cwd()))
from tests.product.test_search_result_provenance import position
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.quiescence import noisy_child,enemy_board_count,material_inventory
from scripts.search_backend_comparison import uci
from scripts.research_record import record_value,write_record
r=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
def probe(name,s,move):
 rt=SearchPathRuntime.from_state(s.state,s.compiled,history_witnesses=s._search_witnesses);initial=rt.position;side=initial.side_to_move;enemies=enemy_board_count(initial,side);inventory=material_inventory(initial);actions={uci(a):a for a in rt.legal_actions()};a=actions[move]
 with rt.pushed(a):
  check=rt.in_check(1-side);included=noisy_child(a,rt.state,side,enemies,inventory,lambda:check);child=record_value(rt.state);row=dict(case=name,move=move,parent_position=record_value(initial),parent_ply=s.state.ply_count,child=child,child_in_check=check,enemy_removed=enemy_board_count(rt.position,side)<enemies,inventory_changed=material_inventory(rt.position)!=inventory,promotion=a.promotion_target_id,included=included)
 assert rt.position==initial and rt.pushes==rt.pops;r['rows'].append(row);print(name,move,check,child['terminal_status'],included,flush=True)
s,e=position('k7/2Q5/2K5/8/8/8/8/8 w - - 0 1')
probe('quiet-stalemate',s,'c7b6');probe('quiet-ongoing',s,'c7d7')
s,e=position();probe('fresh-quiet',s,'g1h1');s._state=dataclasses.replace(s.state,ply_count=s.compiled.max_ply-1);probe('synthetic-import-ply-limit',s,'g1h1')
assert r['rows'][0]['included'] and not r['rows'][1]['included'];assert not r['rows'][2]['included'] and r['rows'][3]['included']
assert all(not x['child_in_check'] and not x['enemy_removed'] and not x['inventory_changed'] and x['promotion'] is None for x in r['rows']);r['complete']=True;write_record(Path(__file__).with_name('support.json'),r)
