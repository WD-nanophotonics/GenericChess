from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.reserve_refresh_diagnostic import queen_roots,stopped
from generic_chess.ai.alphabeta import search,player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
B=Path(__file__).parent;NEG=search.negamax;Q=search.quiescence;r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),pairs=[])
fields=('nodes','qnodes','evaluation_calls','legal_generation_calls','tt_hits','successors_searched','root_scan_nodes','qdepth_cutoffs','in_check_qnodes','capture_qactions','checking_move_qactions','qsearch_budget_aborts','qsearch_check_hard_limit_aborts')
for name,s,e in queen_roots(Path('.local_agent/ui-product-20261010/games-final.json')):
 for q in (0,1,4):
  stopped();before=s.state;w=s._search_witnesses;rows=[]
  for traced in (False,True):
   phases=[];active=[];qsec=[0.];statsout=[]
   def nq(*args,**kw):
    depth,ply,ctx=args[1],args[4],args[5]
    if ply==1 and active:active[-1]['root_child_started']+=1
    if ply!=0:return NEG(*args,**kw)
    initial={k:getattr(ctx.stats,k) for k in fields};event=dict(depth=depth,ordinary_q=search._ordinary_qdepth_limit(ctx),root_child_started=0,completed=False);active.append(event);start=time.perf_counter();qbefore=qsec[0]
    try:
     result=NEG(*args,**kw);event['completed']=True;return result
    except Exception as exc:event['reason']=str(exc);raise
    finally:
     event.update(wall_seconds=time.perf_counter()-start,outer_q_seconds=qsec[0]-qbefore,delta={k:getattr(ctx.stats,k)-v for k,v in initial.items()});active.pop();phases.append(event)
   def qq(*args,**kw):
    start=time.perf_counter()
    try:return Q(*args,**kw)
    finally:qsec[0]+=time.perf_counter()-start
   def root(*args,**kw):
    result=search.run_root_search(*args,**kw);statsout.append(record_value(args[6]));return result
   if traced:search.negamax=nq;search.quiescence=qq
   pm.run_root_search=root;engine=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False);t=time.perf_counter()
   try:d=engine.choose_action(s,SearchLimits(max_depth=3,max_nodes=512,max_time_seconds=10,quiescence_max_depth=q,quiescence_hard_max_depth=8))
   finally:search.negamax=NEG;search.quiescence=Q;pm.run_root_search=search.run_root_search
   wall=time.perf_counter()-t;assert s.state==before and s._search_witnesses==w;rows.append(dict(traced=traced,wall_seconds=wall,decision=record_value(d),stats=statsout[0],phases=phases))
  for kind in ('decision','stats'):
   def clean(x):return {k:v for k,v in x.items() if 'seconds' not in k and not k.startswith('time_')}
   assert clean(rows[0][kind])==clean(rows[1][kind]),(name,q,kind)
  r['pairs'].append(dict(root=name,q=q,rows=rows,return_work_parity=True));write_record(B/'phases.json',r);print(name,q,[(x['depth'],x['completed'],x['root_child_started'],x['delta']['nodes'],x['delta']['qnodes'],round(x['outer_q_seconds'],4)) for x in rows[1]['phases']],flush=True)
r['complete']=True;write_record(B/'phases.json',r)
