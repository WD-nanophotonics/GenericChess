"""Research-only Position inputs; Core retains history/search/terminal authority.

Compilation alone is not Core-equivalent provider admission. This explicitly
retains the existing actor-relative effect exclusion plus conservative max1
refusal. No automatic fallback or product API/default is introduced.
"""
from generic_chess.native import semantic as sem
from generic_chess.core.semantic_executor import semantic_engine_for


def native_position_inputs(position, compiled, native_rules):
    if (compiled.ruleset_fingerprint != native_rules.fingerprint
            or position.ruleset_fingerprint != compiled.ruleset_fingerprint):
        raise ValueError("Native Position input compiled source mismatch")
    engine = semantic_engine_for(compiled)
    if engine is None:
        raise TypeError("Native Position inputs require semantic compiled rules")
    if any(
        effect.kind in ("move", "shift", "remove")
        and effect.piece_type_ref is not None
        and effect.piece_type_ref.kind in ("action_base", "action_current")
        for pattern in engine._patterns for effect in pattern.effects
    ):
        raise NotImplementedError(
            "Native Position inputs decline action-relative move/shift/remove "
            "type filters; use the explicit Core Position input path")
    if compiled.support.max_ply < 2:
        raise NotImplementedError(
            "Native Position inputs require rule max_ply >= 2; "
            "use the explicit Core Position input path")
    packed = sem.pack_current_position(native_rules, position, ply_count=0)
    return (sem.dynamic_features(native_rules, packed),
            sem.spatial_features(native_rules, packed)["localized_control"])
