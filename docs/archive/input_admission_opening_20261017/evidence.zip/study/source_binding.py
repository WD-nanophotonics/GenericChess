from pathlib import Path
from dataclasses import replace
import json,sys,hashlib
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(D)]
from inputs import native_position_inputs
from generic_chess.core.transition import initial_state
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from test_f24c_mixed_mechanic_certification import _mixed_ruleset
c=compile_semantic_ruleset(replace(_mixed_ruleset(),max_ply=2));other=compile_semantic_ruleset(replace(_mixed_ruleset(),max_ply=3));n=compile_native_semantic_rules(c);m=compile_native_semantic_rules(other);rows=[]
for label,p,compiled,native in(('wrong_compiled',initial_state(c).position,other,n),('wrong_native',initial_state(c).position,c,m),('wrong_position',initial_state(other).position,c,n)):
 try:native_position_inputs(p,compiled,native)
 except ValueError as e:assert 'source mismatch'in str(e);rows.append({'label':label,'error':str(e)})
 else:raise AssertionError(label)
# Native getter failure must still propagate; this is a direct dependency control,
# not a replay of old mid-search cancellation/fault experiments.
original=sem.dynamic_features
try:
 def failed(*args):raise RuntimeError('injected research dependency error')
 sem.dynamic_features=failed
 try:native_position_inputs(initial_state(c).position,c,n)
 except RuntimeError as e:assert 'dependency error'in str(e);rows.append({'label':'dynamic_dependency','error':str(e)})
 else:raise AssertionError('dependency hidden')
finally:sem.dynamic_features=original
result={'complete':True,'rows':rows,'source_sha256':hashlib.sha256((D/'inputs.py').read_bytes()).hexdigest(),'scope':'Three explicit mismatched-source refusals and one direct dependency fault. No search/cancellation/clock replay claim.'}
with(D/'source-binding-results.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
print(result)
