from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace
import sys,json,time,hashlib
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(D)]
from inputs import native_position_inputs
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import RuleTypeRef
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.learning.features import localized_control_features
from test_native_dynamic_feature_views import reference_features
from test_f24c_mixed_mechanic_certification import _mixed_ruleset,A0,B0,H0,Piece,N
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,runtime_state
from scripts.research_record import record_value
plan={'question':'Does the corrected bridge explicitly fail in an actual Core caller while explicit full Core inputs remain usable?','calls':4,'cases':['action_current','action_base'],'arms':['bridge_explicitly_unsupported','Core_inputs'],'limits':{'depth':1,'nodes':128,'seconds':2,'q':0,'TT':False,'ordering':False,'Native_legality':False},'decision':'Bridge must not hide unsupported input as zero/terminal/empty actions; explicit Core must complete legal D1. Both root/history/runtime restore. No automaticfallback,trainedmodel,cost orWDLclaim.'}
with(D/'caller-plan.json').open('xb')as f:f.write(json.dumps(plan,indent=2).encode())
class Eval:
 def __init__(self,c,n,bridge):self.c=c;self.n=n;self.bridge=bridge;self.calls=0
 def evaluate(self,state):
  self.calls+=1
  d,x=native_position_inputs(state.position,self.c,self.n)if self.bridge else(reference_features(self.c,state.position),localized_control_features(state.position,self.c))
  return (1 if state.position.side_to_move==0 else -1)*(d[0]+x[0]-x[-1])
 def type_value(self,t):return 0
 def capture_order_value(self,m,captured):return 0
rows=[]
for ref in plan['cases']:
 rule=_mixed_ruleset();actions=tuple(replace(a,effects=(replace(a.effects[0],piece_type_ref=RuleTypeRef(ref)),)+a.effects[1:])if a.name=='capture_A0_B0_leap'else a for a in rule.semantic_actions);board=[[None]*N for _ in range(N)];board[0][0]=Piece(0,H0,H0);board[6][6]=Piece(1,H0,H0);board[1][1]=Piece(0,A0,A0);board[1][2]=Piece(1,B0,B0);raw=compile_semantic_ruleset(replace(rule,semantic_actions=actions,max_ply=2,initial_position=tuple(map(tuple,board))));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);n=compile_native_semantic_rules(c)
 for arm in plan['arms']:
  s=GameSession(c);before=s.state;witness=s._search_witnesses;ev=Eval(c,n,arm.startswith('bridge'));player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));runtimes=[];original=SearchPathRuntime.__init__
  def capture(self,*a,**k):original(self,*a,**k);runtimes.append((self,runtime_state(self)))
  SearchPathRuntime.__init__=capture;t=time.perf_counter()
  try:
   decision=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=128,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));outcome={'result':record_value(decision)};assert arm=='Core_inputs'and decision.completed_depth==1 and decision.action in s.legal_actions()
  except NotImplementedError as e:assert arm.startswith('bridge')and'action-relative'in str(e);outcome={'error_type':type(e).__name__,'error':str(e)}
  finally:SearchPathRuntime.__init__=original
  assert s.state is before and s._search_witnesses is witness
  for rt,snapshot in runtimes:assert runtime_state(rt)==snapshot;rt.assert_balanced()
  rows.append({'ref':ref,'arm':arm,'outcome':outcome,'evaluate_calls':ev.calls,'root_history_runtime_restored':True,'seconds':time.perf_counter()-t});print(ref,arm,list(outcome),flush=True)
with(D/'caller-results.json').open('xb')as f:f.write(json.dumps({'complete':True,'rows':rows,'player_calls':4,'fits':0,'scope':'Four D1 input-interface controls on two deliberately affected rules; no strength,modelbenefit orcostcomparison. Fullactualinitialstate/history, noAUXsolver.'},indent=2).encode())
