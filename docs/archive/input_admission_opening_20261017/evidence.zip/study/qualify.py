from pathlib import Path
from dataclasses import replace
import json,sys,time,hashlib
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(D)]
from inputs import native_position_inputs
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import RuleTypeRef,RuleSquareRef
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.learning.features import localized_control_features
from test_native_dynamic_feature_views import reference_features,S4_CASES
from test_f24c_mixed_mechanic_certification import _mixed_ruleset,_position,A0,A1,B0,B1,H0,Piece
from scripts.research_record import record_value
rows=[];start=time.perf_counter()
def compare(c,p,label,decline=None):
 n=compile_native_semantic_rules(c);packed=sem.pack_current_position(n,p,ply_count=0);before=sem.snapshot(n,packed);wanted=(reference_features(c,p),localized_control_features(p,c));got=None;error=None
 try:got=native_position_inputs(p,c,n)
 except NotImplementedError as e:error=str(e)
 if decline:assert error and decline in error
 else:assert got==wanted and error is None,(label,got,wanted,error)
 assert sem.snapshot(n,packed)==before
 rows.append({'label':label,'position':record_value(p),'core':wanted,'new_inputs':got,'error':error,'preserved':True})
for kind in ('move','shift','remove'):
 for ref in ('action_base','action_current'):
  rule=_mixed_ruleset();actions=[]
  for a in rule.semantic_actions:
   if a.name=='capture_A0_B0_leap':
    if kind=='remove':e=replace(a.effects[0],piece_type_ref=RuleTypeRef(ref))
    else:e=replace(a.effects[1],kind=kind,piece_type_ref=RuleTypeRef(ref))
    a=replace(a,effects=(e,)+a.effects[1:])
   actions.append(a)
  c=compile_semantic_ruleset(replace(rule,semantic_actions=tuple(actions),max_ply=2))
  assert NativeSemanticLegalityProvider.try_create(c,strict=True)is None
  for owner in(0,1):
   for actor_current,victim_current in((A0,B0),(A1,B0),(A0,B1)):
    p=_position(c,[(1,1,Piece(owner,A0,actor_current,promoted=actor_current!=A0)),(2,1,Piece(1-owner,B0,victim_current,promoted=victim_current!=B0)),(0,0,Piece(0,H0,H0)),(6,6,Piece(1,H0,H0))],side=owner)
    compare(c,p,f'{kind}:{ref}:owner{owner}:{actor_current}:{victim_current}','action-relative')
# Positive control still includes permitted action_base hand removal/place, wildcard
# victim filters, all current/base/promoted fields and both side views.
for horizon in(2,128):
 c=compile_semantic_ruleset(replace(_mixed_ruleset(),max_ply=horizon))
 assert NativeSemanticLegalityProvider.try_create(c,strict=True)is not None
 for owner in(0,1):
  p=_position(c,[(1,1,Piece(owner,A0,A0)),(2,1,Piece(1-owner,B0,B1,promoted=True)),(0,0,Piece(0,H0,H0)),(6,6,Piece(1,H0,H0))],side=owner,hands=(((A0,1),),((A0,1),)))
  compare(c,p,f'valid-mixed:{horizon}:owner{owner}')
for builder,position_for in S4_CASES:
 for horizon in(1,2):
  c=compile_semantic_ruleset(replace(builder(),max_ply=horizon))
  for owner in(0,1):compare(c,replace(position_for(c.support),side_to_move=owner),f'{builder.__name__}:max{horizon}:owner{owner}','max_ply'if horizon==1 else None)
result={'complete':True,'rows':rows,'controls':len(rows),'explicit_refusals':sum(x['error']is not None for x in rows),'matched_vectors':sum(x['error']is None for x in rows),'source_sha256':hashlib.sha256((D/'inputs.py').read_bytes()).hexdigest(),'seconds':time.perf_counter()-start,'search_calls':0,'generations':0,'fits':0,'scope':'36actor-ref guards,4 mixed positives,12max1 declines,12S4max2 positives. Specification positions not reachable history claims or all-domain proof; no clock-performance claim.'}
with(D/'qualification-results.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
print({k:v for k,v in result.items()if k!='rows'})
