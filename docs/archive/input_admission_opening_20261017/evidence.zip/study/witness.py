from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib,importlib.util
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from generic_chess.rules.schema import RuleTypeRef
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.learning.features import localized_control_features
from test_native_dynamic_feature_views import reference_features
from test_f24c_mixed_mechanic_certification import _mixed_ruleset,_position,A0,B0,H0,Piece
from scripts.research_record import record_value
old=D/'old_inputs.py'
spec=importlib.util.spec_from_file_location('original_bridge',old);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
start=time.perf_counter();rows=[]
for ref in ('action_current','action_base'):
 rule=_mixed_ruleset();actions=tuple(replace(a,effects=(replace(a.effects[0],piece_type_ref=RuleTypeRef(ref)),)+a.effects[1:]) if a.name=='capture_A0_B0_leap' else a for a in rule.semantic_actions);c=compile_semantic_ruleset(replace(rule,semantic_actions=actions,max_ply=2));p=_position(c,[(1,1,Piece(0,A0,A0)),(2,1,Piece(1,B0,B0)),(0,0,Piece(0,H0,H0)),(6,6,Piece(1,H0,H0))]);e=semantic_engine_for(c);n=compile_native_semantic_rules(c);packed=sem.pack_current_position(n,p,ply_count=0);before=sem.snapshot(n,packed);raw=sem.guarded_actions(n,packed);core=tuple(_semantic_public_action(e,a)for a in e.legal_actions(p));decoder=NativeSemanticLegalityProvider(c,e,n);native=tuple(decoder._decode_action(a,p)for a in raw);wanted=(reference_features(c,p),localized_control_features(p,c));got=mod.native_position_inputs(p,c,n)
 assert not any('capture_A0_B0' in a.pattern_id for a in core)
 assert any('capture_A0_B0' in a.pattern_id for a in native)
 assert NativeSemanticLegalityProvider.try_create(c,strict=True)is None
 assert got!=wanted and sem.snapshot(n,packed)==before
 rows.append({'reference':ref,'max_ply':2,'native_executable':n.native_executable,'position':record_value(p),'core_legal':record_value(core),'native_legal':record_value(native),'core_inputs':wanted,'old_bridge_inputs':got,'old_bridge_accepted':True,'provider_declined':True,'parent_preserved':True})
 print(ref,'legal',len(core),len(native),'vectors',wanted,got,flush=True)
result={'complete':True,'rows':rows,'seconds':time.perf_counter()-start,'old_source_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'player_calls':0,'fits':0,'new_generations':0,'scope':'Two specification positions, not claimed reachable history, no all-domain proof. Direct Native compiles and differs; existing Core-equivalent provider already declines.'}
with(D/'witness-results.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
