from pathlib import Path
from dataclasses import replace
import sys,json
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(D)]
from guard_only_inputs import native_position_inputs
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import RuleTypeRef
from generic_chess.native.compiler import compile_native_semantic_rules
from test_f24c_mixed_mechanic_certification import _mixed_ruleset,_position,A0,B0,H0,Piece
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
rule=_mixed_ruleset();good=compile_semantic_ruleset(replace(rule,max_ply=2));actions=tuple(replace(a,effects=(replace(a.effects[0],piece_type_ref=RuleTypeRef('action_current')),)+a.effects[1:])if a.name=='capture_A0_B0_leap'else a for a in rule.semantic_actions);bad=compile_semantic_ruleset(replace(rule,semantic_actions=actions,max_ply=2));p=_position(bad,[(1,1,Piece(0,A0,A0)),(2,1,Piece(1,B0,B0)),(0,0,Piece(0,H0,H0)),(6,6,Piece(1,H0,H0))]);n=compile_native_semantic_rules(bad)
# Actual mixed-source caller, not a claim any prior experiment used it.
got=native_position_inputs(p,good,n);wanted=(reference_features(bad,p),localized_control_features(p,bad));assert got!=wanted
result={'actual_mixed_source_call_accepted':True,'compiled_fingerprint':good.ruleset_fingerprint,'native_fingerprint':n.fingerprint,'position_fingerprint':p.ruleset_fingerprint,'got':got,'core_for_actual_rule':wanted,'historical_cohorts_affected':False,'scope':'New deliberately inconsistent research-helper call. Existing consumers compiled their Native rules from the same Core source; no claim prior receipts used mixed sources.'}
with(D/'mixed-source-counterexample.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
print(result)
