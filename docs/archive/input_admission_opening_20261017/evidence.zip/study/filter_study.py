from pathlib import Path
from dataclasses import asdict,replace
import sys,json,time,hashlib
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(D)]
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_ruleset
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.generation.generator import generate_game
from generic_chess.generation import filters
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import record_value
roots=json.loads((D/'rules-and-records.json').read_bytes());prior={x['name']:x for x in json.loads((D/'opening-results.json').read_bytes())['rows']};rows=[];start=time.perf_counter();original=filters.apply_action
for z in roots:
 c=compile_ruleset(deserialize_ruleset(json.dumps(z['ruleset'])));cfg=GeneratorConfig(seed=0,board_size=c.board_size);typ={p.type_id:p for p in c.piece_types};counter=[0]
 def counted(*a):counter[0]+=1;return original(*a)
 filters.apply_action=counted
 t=time.perf_counter();baseline=filters.run_soft_filters(cfg,c,typ);baseline_seconds=time.perf_counter()-t;assert counter[0]==0
 t=time.perf_counter();actual=filters.run_soft_filters(replace(cfg,require_no_opening_win_in_one=True),c,typ);enabled_seconds=time.perf_counter()-t
 chosen=next(f for f in actual if f.name=='opening_has_no_win_in_one');expected=prior[z['name']]['first_player_wins']==0;assert chosen.passed==expected
 assert tuple(f for f in actual if f.name!='opening_has_no_win_in_one')==baseline
 rows.append({'name':z['name'],'expected_pass':expected,'actual_pass':chosen.passed,'baseline_extra_transitions':0,'enabled_transitions':counter[0],'opening_degree':prior[z['name']]['legal_count'],'baseline_seconds':baseline_seconds,'enabled_seconds':enabled_seconds,'all_other_filter_results_unchanged':True})
filters.apply_action=original
exposed={'complete':True,'rows':rows,'seconds':time.perf_counter()-start,'scope':'Existing18exposed families, legacyproductiongenerator vssemanticopeningstudy agrees allcases. Cold/warm/source/concurrent clocks descriptive, no speedup or prevalence claim.'}
with(D/'filter-existing-results.json').open('xb')as f:f.write(json.dumps(exposed,indent=2).encode())
plan=json.loads((D/'filter-plan.json').read_bytes());rows=[];start=time.perf_counter();complete=True
for seed,board in zip(plan['prospective_seeds'],plan['boards']):
 for enabled in(False,True):
  if time.perf_counter()-start>plan['whole_seconds']:complete=False;break
  for flag in('rollout','advisor','slack'):
   v=json.loads((R/'.local_agent'/f'{flag}.json').read_bytes());assert not(v.get('stopped')or v.get('user_paused'))
  cfg=GeneratorConfig(seed=seed,board_size=board,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32,require_no_opening_win_in_one=enabled);t=time.perf_counter()
  try:
   g=generate_game(cfg);c=g.compiled_ruleset;state=initial_state(c);winning=[]
   for a in legal_actions(state,c):
    ch=apply_action(state,a,c)
    if ch.terminal_status.winner==state.position.side_to_move:winning.append(record_value(a))
   assert not enabled or not winning
   value={'ruleset':json.loads(serialize_ruleset(g.ruleset)),'ruleset_sha256':hashlib.sha256(serialize_ruleset(g.ruleset).encode()).hexdigest(),'report':record_value(g.generation_report),'verified_winning_first_actions':winning,'error':None}
  except GenerationError as e:value={'error':str(e)}
  row={'seed':seed,'board':board,'enabled':enabled,'config':asdict(cfg),'seconds_including_independent_classification':time.perf_counter()-t,**value};rows.append(row);print(seed,enabled,'error'if value.get('error')else('attempts',value['report']['generation_attempts'],'win1',len(value['verified_winning_first_actions'])),flush=True)
 if not complete:break
result={'complete':complete,'rows':rows,'generation_invocations':len(rows),'seconds':time.perf_counter()-start,'scope':'Four prospective fixed independent rule seeds, each default/optional generator max32 attempts, no refill/resample/capextension. Regeneration is exactly optionalpreference behavior, not replacement of any historicalcohort. No balanced/unseenquality/strength claim, no games/search/training.'}
with(D/'filter-prospective-results.json').open('xb')as f:f.write(json.dumps(result,indent=2).encode())
