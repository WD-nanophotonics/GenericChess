"""Source reader: replay complete tails/prospective openings; never search/train."""
from pathlib import Path
from dataclasses import replace
from copy import copy
import json,sys,time,collections
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(D)]
from opening import compile,record,full,decode_action
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.rules.serialization import deserialize_ruleset
from scripts.research_record import record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.native import SemanticSearchEngine
from generic_chess import native

def forbidden(*a,**k):raise AssertionError('reader cannot search or train')
AlphaBetaPlayer.choose_action=forbidden;SemanticSearchEngine.search=forbidden
for name in('semantic_engine_search','semantic_fixed_depth_search','semantic_probe_search','semantic_iterative_search','semantic_root_parallel_search'):
 if hasattr(native._module(),name):setattr(native._module(),name,forbidden)
start=time.perf_counter();counts=collections.Counter();roots={x['name']:x for x in json.loads((D/'rules-and-records.json').read_bytes())}
first=json.loads((D/'tail-first-case.json').read_bytes());others=json.loads((D/'tail-remaining-results.json').read_bytes())['rows'];tails=[{'name':str(first['name']),'parent':first['parent'],'children':first['rows'],'ongoing':first['ongoing_alternatives'],'all_legal_actions':first['alternative_count']},*others]
for tail in tails:
 z=roots[str(tail['name'])];c=compile(z['ruleset']);rec=record(z['record']);s=GameSession.replay(c,replace(rec,actions=rec.actions[:-1]));before=s.state;n=compile_native_semantic_rules(c);assert record_value(before)==tail['parent'];full(s,n);actions=s.legal_actions();assert len(actions)==len(tail['children'])==tail['all_legal_actions'];seen=set();ongoing=0;selected=0
 for row in tail['children']:
  a=decode_action(row['action']);assert a in actions and a not in seen;seen.add(a);child=copy(s);child.submit(a);assert record_value(child.state)==row['state'];full(child,n);counts['tail_child_full_states']+=1;ongoing+=not child.state.terminal_status.is_terminal
  if row['actual_selected']:
   assert a==rec.actions[-1] and record_value(child.state)==z['tail_state'];selected+=1
 assert ongoing==tail['ongoing'] and selected==1 and s.state is before
 counts['tail_parents']+=1;print('tail',tail['name'],len(seen),ongoing,flush=True)
# Replay all frozen initial alternatives and their fullstate digest receipts.
for row in json.loads((D/'opening-results.json').read_bytes())['rows']:
 c=compile(roots[row['name']]['ruleset']);s=GameSession(c);n=compile_native_semantic_rules(c)
 assert record_value(s.state)==row['initial_state'];assert len(s.legal_actions())==len(row['children'])==row['legal_count']
 for edge in row['children']:
  child=copy(s);child.submit(decode_action(edge['action']));assert full(child,n)==edge['full_state_sha256'];assert record_value(child.state.terminal_status)==edge['terminal'];counts['existing_opening_child_full_states']+=1
 counts['existing_opening_roots']+=1
 print('existing',row['name'],len(row['children']),flush=True)
# Distinct prospective generator outputs are independently interpreted by the
# semantic Core path and Native complete-history transport, not regenerated.
for row in json.loads((D/'filter-prospective-results.json').read_bytes())['rows']:
 if row.get('error'):counts['generation_failures_retained']+=1;continue
 c=compile(row['ruleset']);s=GameSession(c);n=compile_native_semantic_rules(c);full(s,n);wins=[]
 for a in s.legal_actions():
  child=copy(s);child.submit(a);full(child,n);counts['prospective_child_full_states']+=1
  if child.state.terminal_status.winner==s.state.position.side_to_move:wins.append(record_value(a))
 # These inputs are strictly legacy-generated rules; conversion adds explicit
 # pattern/geometry/actor identities. Compare only visible legacy winning moves
 # for this classification, while full Native/Core state checks above retain
 # every semantic identity and history. No all-domain action bijection claim.
 def legacy_move(a):
  return json.dumps({k:a[k] for k in ('from_square','to_square','promotion_target_id','base_type_id')if k in a},sort_keys=True)
 assert {legacy_move(a)for a in wins}=={legacy_move(a)for a in row['verified_winning_first_actions']}
 counts['prospective_roots']+=1
 print('prospective',row['seed'],row['enabled'],len(wins),flush=True)
print(json.dumps({'complete':True,'counts':dict(counts),'seconds':time.perf_counter()-start,'scope':'Search and Native search entrypoints disabled. Actual fullstate/history/terminal and legal oneply actions replayed; no oldclock, balancedquality, optimalWDL, longplayability or sourceindependenceclaim.'},indent=2))
