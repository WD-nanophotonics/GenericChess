from pathlib import Path
from dataclasses import replace
from copy import copy
import sys,json,time,hashlib,collections
R=Path.cwd();D=Path(__file__).resolve().parent;sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(D)]
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.record import GameRecord
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot
from generic_chess.native import semantic as sem
from generic_chess.learning.features import localized_control_features
from test_native_dynamic_feature_views import reference_features
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
from inputs import native_position_inputs

def decode_action(a):
 if 'from_square'in a:return SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
 return SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
def record(a):
 if not a['actions']or'kind'in a['actions'][0]:return deserialize_game_record(json.dumps(a))
 assert a['declaration']is None and a['resigned_by']is None
 return GameRecord(a['schema_version'],a['ruleset_fingerprint'],tuple(map(decode_action,a['actions'])),None,initial_setup_key=a['initial_setup_key'])
def compile(a):
 c=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(a)))
 return SearchMetadataAdapter(ir=c.ir,_legacy_compiled=c._legacy_compiled,support=c.support)
def full(s,n):
 p=pack_semantic_search_position(s.compiled,n,s);v=sem.snapshot(n,p);w=expected_snapshot(s.state.position,n,s.compiled)
 for k in ('board','hands','aux_state','side'):assert record_value(v[k])==record_value(w[k])
 assert v['ply']==s.state.ply_count and v['history_exact']and v['history_events_exact']
 assert [''.join(f'{i:016x}'for i in row)for row in v['history']]==[str(position_identity_key(x,s.compiled))for x in s._search_witnesses]
 assert v['history_events']==tuple((255 if h.actor<0 else h.actor,bool(h.gave_check))for h in s.state.history)
 assert sem.terminal_status(n,p)==record_value(s.state.terminal_status)
 return hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest()
if __name__=='__main__':
 out=D/'opening-results.json';assert not out.exists()
 roots=json.loads((D/'rules-and-records.json').read_bytes());rows=[];start=time.perf_counter();complete=True;count=0
 for z in roots:
  for flag in('rollout','advisor','slack'):
   x=json.loads((R/'.local_agent'/f'{flag}.json').read_bytes());assert not(x.get('stopped')or x.get('user_paused'))
  c=compile(z['ruleset']);rec=record(z['record']);tail=GameSession.replay(c,rec);assert record_value(tail.state)==z['tail_state'];s=GameSession.replay(c,replace(rec,actions=()));n=compile_native_semantic_rules(c);root_hash=full(s,n);wanted=(reference_features(c,s.state.position),localized_control_features(s.state.position,c));assert native_position_inputs(s.state.position,c,n)==wanted
  actions=s.legal_actions();children=[];t=time.perf_counter()
  for a in actions:
   if time.perf_counter()-start>=120:complete=False;break
   child=copy(s);child.submit(a);digest=full(child,n);children.append({'action':record_value(a),'full_state_sha256':digest,'terminal':record_value(child.state.terminal_status),'ply':child.state.ply_count,'history_length':len(child.state.history)});count+=1
  assert full(s,n)==root_hash
  ownwins=sum(x['terminal']['winner']==s.state.position.side_to_move for x in children);terminal=sum(x['terminal']['status']!='ongoing'for x in children)
  row={'name':z['name'],'board':c.board_size,'initial_state':record_value(s.state),'initial_record':record_value(s.to_record()),'root_inputs':wanted,'legal_count':len(actions),'executed':len(children),'first_player_wins':ownwins,'terminal_children':terminal,'children':children,'child_checks_seconds':time.perf_counter()-t,'selected_tail_terminal':tail.state.terminal_status.is_terminal,'selected_tail_ply':tail.state.ply_count};rows.append(row)
  print(z['name'],'legal',len(actions),'win1',ownwins,'tail',tail.state.ply_count,tail.state.terminal_status,flush=True)
  if not complete:break
 result={'complete':complete,'rows':rows,'seconds':time.perf_counter()-start,'new_child_transitions':count,'full_native_state_checks':count+2*len(rows),'new_generations':0,'player_queries':0,'fits':0,'scope':'18 distinct EXPOSED cost-selected rule families, not prevalence sample. All actual initial oneply legal alternatives, exact fullstate/history/status Native/Core agreement. Winning terminal child certifies only immediate win, absence not balance/longplayability.'}
 with out.open('xb')as f:f.write(json.dumps(result,indent=2).encode())
