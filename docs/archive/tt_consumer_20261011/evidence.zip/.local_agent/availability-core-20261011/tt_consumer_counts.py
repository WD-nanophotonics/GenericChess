"""Count current search-key consumers by actual formal-child outcome."""
import sys,time,importlib.util
from pathlib import Path
from collections import Counter
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('repr',B/'representation_outcome.py');p=importlib.util.module_from_spec(s);s.loader.exec_module(p);c=p.c;R=p.T
push=R._push_impl;pop=R.pop;key=R.search_key;classify=c.sm.noisy_child;records={};totals=Counter()
def pushed(self,*a,**k):
 v=push(self,*a,**k);frame=self._frames[-1];records[id(frame)]=[c.iteration,bool(c.qlevel),'unclassified',0];return v

def classified(action,child,*a,**k):
 v=classify(action,child,*a,**k);row=records[id(child._runtime._frames[-1])];row[2]='included' if v else 'excluded';return v

def search_key(self,*a,**k):
 if self._frames and id(self._frames[-1]) in records:records[id(self._frames[-1])][3]+=1
 return key(self,*a,**k)

def popped(self,*a,**k):
 row=records.pop(id(self._frames[-1]),None)
 if row is not None:
  i,q,o,reads=row;totals[(i,q,o,'children')]+=1;totals[(i,q,o,'search_key_calls')]+=reads
 return pop(self,*a,**k)
compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess'));b=c.CoreBoard(c.CASES[0],compiled);e=c.cm.w.weighted(compiled,c.VALUES['chess']);out=dict(complete=False,scope='Consumer counts on existing completedD2 root. No changed execution/default or timing claim. Per-frame outcomes and actual search_key calls, no double-counted descendant access.',rows=[])
try:
 c.stopped();R._push_impl=pushed;R.pop=popped;R.search_key=search_key;c.sm.noisy_child=classified;c.sm.negamax=c.negamax;c.sm._quiescence_runtime=c.quiescence;c.iteration=c.qlevel=0;c.counts=Counter()
 session=c.GameSession(compiled);session._state=b.initial;session._search_history_witnesses=b.witnesses
 d=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(session,c.SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
 assert not records and session.state is b.initial and d.completed_depth==2
 out['decision']=c.record_value(d);out['rows']=[dict(iteration=i,qphase=q,outcome=o,metric=m,value=v) for (i,q,o,m),v in sorted(totals.items())];out['complete']=True
finally:
 R._push_impl=push;R.pop=pop;R.search_key=key;c.sm.noisy_child=classify;c.sm.negamax=c.ng;c.sm._quiescence_runtime=c.q;c.write_record(B/'tt-consumer-counts.json',out)
print(out['rows'],flush=True)
