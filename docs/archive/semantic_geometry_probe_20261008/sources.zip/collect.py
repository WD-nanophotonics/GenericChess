"""Collect scoped observations and archive exact Agent-produced evidence."""
import sys,json,hashlib,zipfile,tempfile,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent
def load(name):return json.loads((p/name).read_bytes())
def pin(name):
 b=(p/name).read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
oracle=load('tag-native-oracle.json');mass=load('tag-mass.json');distribution=load('tag-distribution-core.json')
tag=dict(scope='Observed original-horizon signed tag-service, not stock material prices',native_replay={k:oracle[k] for k in ('native_transitions','mean_difference','seconds')},exact_mass={k:mass[k] for k in ('mean_difference','original_population_repeat_differences','seconds')},independent_core_distribution={k:distribution[k] for k in ('core_transitions','peak_latent_states','nonzero_variance_paths','sum_conditional_variance','seconds')},raw_pins={x:pin(x) for x in ('tag-native-oracle.json','tag-mass.json','tag-distribution-core.json')})
write_record(ROOT/'docs/research/data/original_tag_replay_20261008.json',tag)
baseline=load('promotion-law-completed.json');ablations=load('promotion-search-ablation.json');public=load('promotion-public-search.json')
promotion=dict(scope='Finite supported three-entity derivative, no prices/strength/universal TT claim',baseline=dict(complete_cells=sum(c['complete'] for x in baseline['rows'] for c in x['cells']),total_cells=96,calls=sum(c['calls'] for x in baseline['rows'] for c in x['cells']),seconds=baseline['seconds']),ablations={a:dict(complete_cells=sum(c['complete'] for x in ablations['rows'] if x['ablation']==a for c in x['cells']),total_cells=48,calls=sum(c['calls'] for x in ablations['rows'] if x['ablation']==a for c in x['cells']),seconds=sum(c['seconds'] for x in ablations['rows'] if x['ablation']==a for c in x['cells'])) for a in ('ordering_only','proof_only','both')},subpolicy={k:v for k,v in load('promotion-subpolicy.json').items() if k!='rows'},subpolicy_cells=[{k:x[k] for k in ('context','complete','subpolicy_win','calls','transitions','seconds')} for x in load('promotion-subpolicy.json')['rows']],core_strategy_verification=load('promotion-core-verify.json'),underpromotion=load('underpromotion-core.json'),public_search=dict(total_calls=64,nodes=sum(c['decision']['nodes'] for x in public['rows'] for c in x['cells']),seconds=public['seconds'],cells=[dict(context=x['context'],ceiling=c['ceiling'],staged=c['staged'],repeat=c['repeat'],depth=c['decision']['completed_depth'],score=c['decision']['score'],nodes=c['decision']['nodes'],termination=c['decision']['termination_reason'],seconds=c['seconds']) for x in public['rows'] for c in x['cells']]))
write_record(ROOT/'docs/research/data/promotion_rule_probe_20261008.json',promotion)
geometry=load('semantic-geometry.json');core=load('semantic-core-check.json');guards=load('semantic-guard-bias.json')
canonical=geometry['rows'][0]['types'];pawn=canonical['P']['projected_weighted_mobility']
ratio_diagnostic=dict(scope='Ratios of the declared weighted opportunity proxy, NOT selected material prices. Guard term below is specific to these all-N-background virtual contexts, not a general semantic guard solver.',pawn_normalized={tid:x['projected_weighted_mobility']/pawn for tid,x in canonical.items() if tid!='K'},queen_rook_ratio=canonical['Q']['projected_weighted_mobility']/canonical['R']['projected_weighted_mobility'],missing_double_step_expected=[dict(density=d,expected_missing=(1-d)**2/8) for d in (0.,.125,.25,.375,.5)])
semantic=dict(scope=geometry['declaration'],variants=[dict(variant=x['variant'],fingerprint=x['fingerprint'],types=x['types']) for x in geometry['rows']],core_checks=core,guard_bias=guards,raw_pins={x:pin(x) for x in ('semantic-geometry.json','semantic-core-check.json','semantic-guard-bias.json')},source_audit={name:dict(sha256=hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),observation=observation) for name,observation in [('generic_chess/ui/controller.py','finish_ai_move validates root and commits action; no fixed-depth score/PV consumer.'),('generic_chess/ai/benchmark/runner.py','Move trace uses action/depth/nodes/time, not fixed-depth decision score or full PV.'),('generic_chess/ai/cli/benchmark_alphabeta.py','Analysis prints score/PV; existing fresh-tt resets repeats. Supplied semantic rules now use existing execution compiler, preserving legacy route for ordinary definitions.'),('generic_chess/ai/evaluation/profile.py','Static capability reads movement_atoms, not semantic IR patterns.'),('generic_chess/rules/execution.py','Adapter exposes retained metadata, does not synthesize semantic movement atoms.'),('scripts/unfamiliar_search.py','Existing report now labels static-profile source and semantic-only omissions.') ]})
semantic['ratio_diagnostic']=ratio_diagnostic
witness=load('semantic-search-witness-localized.json')
semantic['search_input_witness']={k:v for k,v in witness.items() if k!='definition'}
write_record(ROOT/'docs/research/data/semantic_capability_20261008.json',semantic)
groups={
 'original_tag_replay_20261008':('original_tag_replay_20261008.json',['tag-native-oracle','tag-mass','tag-distribution-core']),
 'promotion_rule_probe_20261008':('promotion_rule_probe_20261008.json',['promotion-law','promotion-law-initial','promotion-search-ablation','promotion-subpolicy','promotion-core-verify','promotion-core-verify-initial','promotion-public-search','underpromotion-core']),
 'semantic_geometry_probe_20261008':('semantic_capability_20261008.json',['semantic-geometry','semantic-geometry-initial','semantic-core-check','semantic-guard-bias','semantic-search-witness','semantic-search-witness-initial','semantic-search-witness-localized']),
}
for group,(summary,stems) in groups.items():
 dest=ROOT/'docs/archive'/group;dest.mkdir(exist_ok=True);summary_path=ROOT/'docs/research/data'/summary;index=dict(original_directory=p.relative_to(ROOT).as_posix(),repository_base_sha='58f8aa936d899eb6f61df22819eed05f81d59ddd',current_result=dict(path=summary_path.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(summary_path.read_bytes()).hexdigest()),archives={},dependencies=[])
 for archive,suffix in [('sources.zip','.py'),('raw.zip','.json')]:
  names=[stem+suffix for stem in stems if (p/(stem+suffix)).exists()]
  if suffix=='.py':names.append('collect.py')
  else:names.append('failures.json')
  if group=='promotion_rule_probe_20261008' and suffix=='.json':names.append('promotion-law-completed.json')
  members={}
  with zipfile.ZipFile(dest/archive,'w',zipfile.ZIP_DEFLATED) as z:
   for name in names:z.write(p/name,name);members[name]=pin(name)
  with zipfile.ZipFile(dest/archive) as z,tempfile.TemporaryDirectory(dir=p) as temporary:
   assert z.testzip() is None;z.extractall(temporary)
   for name,expected in members.items():b=(Path(temporary)/name).read_bytes();assert len(b)==expected['bytes'] and hashlib.sha256(b).hexdigest()==expected['sha256']
  index['archives'][archive]=dict(sha256=hashlib.sha256((dest/archive).read_bytes()).hexdigest(),members=members,extracted_rehashed=True)
 if group=='original_tag_replay_20261008':
  for name,recovery in [('docs/archive/original_horizon_preflight_20261008/remaining-custody.json','existing original_horizon_preflight_20261008 archive'),('.local_agent/custody-kernel-20261008/kernel-completed.json','custody_continuation_20261008/raw.zip'),('.local_agent/custody-kernel-20261008/pretransfer-coupling.json','custody_continuation_20261008/raw.zip')]:index['dependencies'].append(dict(path=name,sha256=hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),recovery=recovery))
 write_record(dest/'index.json',index)
 (dest/'README.md').write_text('# Scoped development evidence\n\nCurrent result: ../../research/data/'+summary+' .\nExact Agent-produced synthetic sources and complete/incomplete results are\nseparated into sources.zip and raw.zip. Failed initial sources and failure\nexplanations remain evidence; they are not active imports or tasks. No raw\nSlack/account records, user inputs, credentials or local workflow state.\n\nindex.json pins every physically extracted/rehashed member and external\ndependency. Recover dependencies from the named archives into their recorded\nrelative paths; recover these members into .local_agent/original-contribution-20261008\nonly on demand. Use the recorded repository base for unchanged runtime code;\nthe supplied-rule benchmark loader/report metadata changes belong to the new\ncommit, not the original numerical producers. Producers reject output overwrite;\nuse an isolated recovery checkout or retain originals and rename new outputs.\nThe collector packages all three scoped archives and is not an experiment.\n',encoding='utf-8')
 readme=dest/'README.md';readme.write_bytes(readme.read_bytes().replace(b'\r\n',b'\n'))
 print(group,sum(len(x['members']) for x in index['archives'].values()),sum((dest/x).stat().st_size for x in index['archives']))
