"""Independent Core witnesses for the projected simple semantic mobility."""
import sys,json,time,hashlib,random,math
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.ir import geometry_candidates
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'semantic-geometry.json').read_bytes();src=json.loads(raw);out=p/'semantic-core-check.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='All4 declared semantic variants; both owner orientations, all64 actor sources, empty-board quiet targets and every63 single-enemy target independently checked through Core executor. Pseudo contexts intentionally have no anchors; own-anchor safety therefore adds no filter. Filter only the explicitly projected patterns, deduplicate promotion choices by endpoint. Also predeclared512 independent occupancy samples per5densities/variant, seed2026100817 and identical random boards across variants. No terminal-game/whole-legal-mobility or calibrated-price claim.',rows=[])
for row in src['rows']:
 assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
 c=compile_ruleset_for_execution(ruleset_from_dict(row['definition']));engine=semantic_engine_for(c);tid='Z' if row['variant']=='renamed' else 'P';spec=row['types'][tid];included=set(spec['included']);patterns=[x for x in c.ir.patterns if x.pattern_id in included];template=engine._initial_position();t=time.perf_counter();item=dict(variant=row['variant'],quiet_contexts=0,capture_contexts=0,endpoint_checks=0,curves=[])
 for owner in (0,1):
  for origin in range(64):
   board=[None]*64;board[origin]=Piece(owner,tid,tid);position=replace(template,board=tuple(board),side_to_move=owner)
   expect={kind:set() for kind in ('target_empty','target_enemy')}
   for pat in patterns:
    for gid in pat.geometry_ids:
     expect[pat.target.kind].update(target for target,_ in geometry_candidates(c.ir.geometry[gid],str(owner),origin))
   actual={a.target for a in engine.legal_actions(position) if a.pattern_id in included}
   assert actual==expect['target_empty'];item['quiet_contexts']+=1;item['endpoint_checks']+=len(actual)
   for target in range(64):
    if target==origin:continue
    bb=list(board);bb[target]=Piece(1-owner,'N','N');pos=replace(position,board=tuple(bb))
    actual={a.target for a in engine.legal_actions(pos) if a.pattern_id in included and a.source==origin and a.target==target}
    assert bool(actual)==(target in expect['target_enemy']);item['capture_contexts']+=1;item['endpoint_checks']+=len(actual)
 # Density check conditions on actor, all other squares independently occupied.
 for density in (0.,.125,.25,.375,.5):
  rng=random.Random(2026100817);observed=[]
  for sample in range(512):
   origin=rng.randrange(64);board=[]
   for square in range(64):
    u=rng.random();board.append(None if u>=density else Piece(0 if u<density/2 else 1,'N','N'))
   board[origin]=Piece(0,tid,tid);pos=replace(template,board=tuple(board),side_to_move=0)
   observed.append(len({a.target for a in engine.legal_actions(pos) if a.pattern_id in included and a.source==origin}))
  mean=sum(observed)/len(observed);se=math.sqrt(sum((x-mean)**2 for x in observed)/(len(observed)-1)/len(observed));expected=next(x['total'] for x in spec['curves'] if x['density']==density)
  item['curves'].append(dict(density=density,mean=mean,standard_error=se,predicted=expected,delta=mean-expected,samples=len(observed)))
 item.update(complete=True,seconds=time.perf_counter()-t);r['rows'].append(item);write_record(out,r);print(item,flush=True)
assert r['rows'][0]['curves']==r['rows'][3]['curves']
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
