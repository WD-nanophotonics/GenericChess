"""Matched full-pattern versus simple-projection mobility, no new samples."""
import sys,json,time,hashlib,random,math
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'semantic-geometry.json').read_bytes();src=json.loads(raw);out=p/'semantic-guard-bias.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Reuse the exact512boards per density and seed from the independent Core projection check. Count every executable action from the actor, then compare the same-position projected subset after endpoint deduplication. Ordinary enemy/friendly N background, no hands, aux initialized normally, no anchors in these virtual contexts. Full here means all actor patterns in these contexts, not a real-game distribution or full legal material price. No resampling or profile choice based on human labels.',rows=[])
for row in src['rows']:
 c=compile_ruleset_for_execution(ruleset_from_dict(row['definition']));engine=semantic_engine_for(c);tid='Z' if row['variant']=='renamed' else 'P';included=set(row['types'][tid]['included']);template=engine._initial_position();item=dict(variant=row['variant'],curves=[])
 for density in (0.,.125,.25,.375,.5):
  rng=random.Random(2026100817);deltas=[];full=[];partial=[];by_pattern={}
  for sample in range(512):
   origin=rng.randrange(64);board=[]
   for square in range(64):
    u=rng.random();board.append(None if u>=density else Piece(0 if u<density/2 else 1,'N','N'))
   board[origin]=Piece(0,tid,tid);pos=replace(template,board=tuple(board),side_to_move=0)
   aa=[a for a in engine.legal_actions(pos) if a.source==origin];ff={a.target for a in aa};ss={a.target for a in aa if a.pattern_id in included};assert ss<=ff
   for a in aa:
    if a.pattern_id not in included:by_pattern.setdefault(a.pattern_id,[]).append(dict(origin=origin,target=a.target))
   full.append(len(ff));partial.append(len(ss));deltas.append(len(ff)-len(ss))
  mean=sum(deltas)/512;se=math.sqrt(sum((v-mean)**2 for v in deltas)/511/512)
  item['curves'].append(dict(density=density,full_mean=sum(full)/512,partial_mean=sum(partial)/512,paired_missing_mean=mean,paired_standard_error=se,contexts_with_missing=sum(x!=0 for x in deltas),excluded_pattern_occurrences={k:len(v) for k,v in by_pattern.items()},source_ranks_for_omitted_patterns={k:sorted({x['origin']//8 for x in v}) for k,v in by_pattern.items()}))
 r['rows'].append(item);write_record(out,r);print(item,flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
