"""One unfamiliar semantic-only movement input intervention, no price fitting."""
import sys,json,time,hashlib,statistics
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.ir import geometry_candidates
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'semantic-search-witness-localized.json';assert not out.exists();started=time.perf_counter();base=build_western_chess_ruleset();geometry_raw=(p/'semantic-geometry.json').read_bytes();old=json.loads(geometry_raw)
# Recombine familiar rook mechanics into the otherwise atomless type. No type
# name is consulted by legality or evaluation; this fixture selects bindings.
rook_actions=[a for a in base.semantic_actions if a.type_ids==('R',)]
actions=tuple(a for a in base.semantic_actions if a.type_ids!=('P',))+tuple(replace(a,name='recombined_'+a.name,type_ids=('P',),geometry=replace(a.geometry,kind='ray',direction=direction,min_steps=1,max_steps=None,atom_kind=None),composition='augment',replace_selector=None,promotion_mode='inherit_compiled_masks') for a in rook_actions for direction in ((1,0),(-1,0),(0,1),(0,-1)))
board=[[None]*8 for _ in range(8)]
for owner,tid,file,rank in ((0,'K',0,0),(1,'K',7,7),(0,'P',3,3),(0,'N',5,2),(1,'N',3,5),(1,'P',5,5)):board[rank][file]=Piece(owner,tid,tid)
definition=replace(base,initial_position=tuple(tuple(x) for x in board),semantic_actions=actions);c=compile_ruleset_for_execution(definition);session=GameSession(c);config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profile=build_ruleset_profile(c,config)
def edges(compiled,tid):
 return {(owner,source,pat.target.kind,target,tuple(path)) for pat in compiled.ir.patterns if tid in pat.type_ids and any(e.kind=='move' for e in pat.effects) for gid in pat.geometry_ids for owner in ('0','1') for source in range(64) for target,path in geometry_candidates(compiled.ir.geometry[gid],owner,source)}
canonical=compile_ruleset_for_execution(base);assert edges(c,'P')==edges(canonical,'R');assert profile.piece_profiles['P'].raw_capability_score==0
# Isolate one input replacement, keep all other table entries and scale fixed.
scale=1000/statistics.median(x.raw_capability_score for x in profile.piece_profiles.values() if not x.is_anchor);candidate=int(round(old['rows'][0]['types']['R']['projected_weighted_mobility']*scale));table=dict(profile.board_value_by_type);table['P']=candidate;corrected=replace(profile,board_value_by_type=table)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),projection_sha256=hashlib.sha256(geometry_raw).hexdigest(),declaration='One predeclared 8x8 unfamiliar recombination: atomless P has semantic rook movement; six-piece root gives a P-for-N capture followed by enemy P recapture. No human coefficients or label fitting. Compare old fixed material table with ONLY P replaced by the declared projected opportunity scaled by the unchanged legacy median. Every other value, search, legality and resource condition stays fixed. This is an input-sensitivity witness, not validation or selection of a material formula. All depth1/2 cells x2cold repeats,4096nodes/5sec/q0; Core plain material minimax references.',definition=ruleset_to_dict(definition),baseline_values=dict(profile.board_value_by_type),candidate_values=table,scale=scale,semantic_geometry_matches_rook=True,rows=[])
for label,prof in [('baseline',profile),('input_repaired_candidate',corrected)]:
 evaluator=Evaluator(c,prof,config)
 capture=next(a for a in session.legal_actions() if record_value(a).get('from_square')=={'file':3,'rank':3} and record_value(a).get('to_square')=={'file':3,'rank':5})
 captured=apply_action(session.state,capture,c);score,_=reference_minimax(captured,1,evaluator,c);r.setdefault('isolated_capture_values',[]).append(dict(control=label,own_capture=record_value(capture),core_two_ply_value=-score))
 for depth in (1,2):
  score,action=reference_minimax(session.state,depth,evaluator,c);row=dict(control=label,depth=depth,core_reference=dict(score=score,action=record_value(action)),calls=[]);r['rows'].append(row)
  for repeat in (0,1):
   assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=evaluator,tuning=SearchTuning(use_root_tactical=False));decision=player.choose_action(session,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(session,decision);assert decision.completed_depth==depth and decision.score==score;row['calls'].append(record_value(decision));write_record(out,r)
  assert row['calls'][0]['action']==row['calls'][1]['action'];print(label,depth,score,row['calls'][0]['action'],flush=True)
r.update(complete=True,seconds=time.perf_counter()-started);write_record(out,r)
