"""Rule-only geometry projection pilot, explicitly not full legal mobility."""
import sys,json,time,hashlib,itertools
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.schema import ruleset_to_dict,ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.ir import geometry_candidates
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'semantic-geometry.json';assert not out.exists();started=time.perf_counter();cfg=EvaluationConfig()

def shape(compiled,tid):
 edges={kind:[{} for _ in range(64)] for kind in ('target_empty','target_enemy')};excluded=[];included=[]
 for pat in compiled.ir.patterns:
  if tid not in pat.type_ids:continue
  reasons=[]
  if pat.target.kind not in edges:reasons.append('target predicate')
  if pat.guards or pat.slot_guards or pat.square_zone_guards or pat.postconditions:reasons.append('state/zone/postcondition')
  if any(x.kind!='path_clear' for x in pat.path):reasons.append('non-clear path')
  if any(compiled.ir.geometry[g].kind=='drop' for g in pat.geometry_ids):reasons.append('drop')
  ee=pat.effects
  move=next((e for e in ee if e.kind=='move'),None)
  if move is None or len([e for e in ee if e.kind=='move'])!=1 or move.from_ref.kind!='source' or move.to_ref.kind!='target' or move.piece_owner!='self':reasons.append('not simple actor move')
  for e in ee:
   if e.kind=='move':continue
   if not(e.kind=='remove' and e.square_ref.kind=='target' and e.piece_owner=='opponent'):reasons.append('compound/state effect')
  if any(x.kind!='own_anchor_safe' for x in pat.invariants):reasons.append('non-anchor invariant')
  if reasons:excluded.append(dict(pattern=pat.pattern_id,reasons=sorted(set(reasons))));continue
  included.append(pat.pattern_id)
  for gid in pat.geometry_ids:
   geo=compiled.ir.geometry[gid]
   for origin in range(64):
    for target,path in geometry_candidates(geo,'0',origin):
     assert target not in path and origin not in path
     required=frozenset(path) if pat.path else frozenset()
     edges[pat.target.kind][origin].setdefault(target,set()).add(required)
 def union_probability(paths,density):
  # Exact union of path-clear events via inclusion-exclusion. Deduplicate and
  # discard stricter paths subsumed by another candidate to the same endpoint.
  pp=[q for q in paths if not any(x<q for x in paths)];assert len(pp)<=12
  return sum((-1)**(count+1)*(1-density)**len(set().union(*combo)) for count in range(1,len(pp)+1) for combo in itertools.combinations(pp,count))
 curves=[]
 for d in cfg.density_points:
  quiet=sum(union_probability(paths,d)*(1-d) for source in edges['target_empty'] for paths in source.values())/64
  capture=sum(union_probability(paths,d)*(d/2) for source in edges['target_enemy'] for paths in source.values())/64
  curves.append(dict(density=d,quiet=quiet,capture=capture,total=quiet+capture))
 return dict(included=included,excluded=excluded,quiet_endpoint_count=sum(map(len,edges['target_empty'])),capture_endpoint_count=sum(map(len,edges['target_enemy'])),curves=curves,projected_weighted_mobility=sum(w*x['total'] for w,x in zip(cfg.density_weights,curves)))

base=build_western_chess_ruleset();variants=[('canonical',base)]
variants.append(('semantic_long_capture',replace(base,semantic_actions=tuple(replace(a,geometry=replace(a.geometry,offset=(2 if a.geometry.offset[0]>0 else -2,1))) if a.name.startswith('pawn_capture_') else a for a in base.semantic_actions))))
variants.append(('semantic_capture_only',replace(base,semantic_actions=tuple(a for a in base.semantic_actions if a.name!='pawn_one_step' and a.name!='pawn_double_step'))))
def rename(v):
 if isinstance(v,dict):return {('Z' if k=='P' else k):rename(x) for k,x in v.items()}
 if isinstance(v,list):return [rename(x) for x in v]
 return 'Z' if v=='P' else v
variants.append(('renamed',ruleset_from_dict(rename(ruleset_to_dict(base)))))
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Four predeclared rule variants: canonical, longer semantic capture, capture-only, and type-ID rename. Same legacy atoms, no human coefficients. Project only simple actor moves, target removal, empty/enemy target and optional clear path. Exclude guards/aux/compound/drop/zone/postconditions with explicit reasons. Own-anchor safety is deliberately ignored, so this is a pseudo-geometric density approximation, NOT full legal mobility or a deployed price. Independent square occupancy: empty1-d, friendly/enemy d/2. Quiet and capture endpoints have different availability; promotion choices deduplicated by endpoint. Exact path-clear union under this law, future promotion/custody ignored. Product evaluator stays unchanged.',rows=[])
for label,definition in variants:
 c=compile_ruleset_for_execution(definition);profile=build_ruleset_profile(c,cfg);row=dict(variant=label,definition=ruleset_to_dict(definition),fingerprint=c.ruleset_fingerprint,types={})
 for tid in c.types_by_id:
  x=shape(c,tid);old=profile.piece_profiles[tid];x.update(old_signature=old.movement_signature,old_raw=old.raw_capability_score,old_value=old.normalized_board_value);row['types'][tid]=x
 r['rows'].append(row)
 print(label,row['types'].get('P',row['types'].get('Z')),flush=True)
original=r['rows'][0]['types']['P'];long=r['rows'][1]['types']['P'];capture=r['rows'][2]['types']['P'];renamed=r['rows'][3]['types']['Z']
assert original['old_raw']==long['old_raw']==capture['old_raw']==0 and original['old_value']==long['old_value']==capture['old_value']==1
assert original==renamed
assert original['capture_endpoint_count']!=long['capture_endpoint_count']
assert capture['curves'][0]['total']==0 and capture['curves'][1]['capture']>0
r.update(complete=True,seconds=time.perf_counter()-started);write_record(out,r)
