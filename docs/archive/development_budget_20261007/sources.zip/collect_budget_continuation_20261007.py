"""Compact index plus ordinary ZIP of exact raw evidence, not duplicate JSON bodies."""
import sys,json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'.local_agent/mature-budget-20261007'
archive=ROOT/'docs/archive/development_budget_20261007';archive.mkdir(exist_ok=True)
out=ROOT/'docs/research/data/chess_budget_continuation_20261007.json';assert not out.exists()
files=[p/n for n in ('declaration.json','suite.json','DECLARATION_NOTES.md','FAILURE_HYPOTHESIS.md','leaf-inspection.json','games-1.json','games-4.json','replay.json','recording-live.json')]
files += [ROOT/'.local_agent/mature-openings'/n for n in ('early-reference-20261007.json','early-budget-reference-20261007.json')]
files += [ROOT/'.local_agent/shogi_checked_drop_ties_20261007.json']
if (p/'pair-games-1sec.json').exists():files.append(p/'pair-games-1sec.json')
entries={}
with zipfile.ZipFile(archive/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  b=f.read_bytes();name=f.relative_to(ROOT/'.local_agent').as_posix()
  assert b'C:\\Users\\wdai' not in b
  z.writestr(name,b);entries[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(archive/'raw.zip') as z:
 for n,r in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==r['sha256']
sources=['mature_budget_continuation_20261007.py','diagnose_mature_early_20261007.py','diagnose_mature_early_budget_20261007.py','live_recording_compare_20261007.py','shogi_checked_drop_ties_20261007.py','replay_budget_continuation_20261007.py','collect_budget_continuation_20261007.py']
source_index={}
with zipfile.ZipFile(archive/'sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in sources:
  b=(ROOT/'.local_agent'/n).read_bytes();z.writestr(n,b);source_index[n]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(archive/'sources.zip') as z:
 for n,r in source_index.items():assert hashlib.sha256(z.read(n)).hexdigest()==r['sha256']
replay=json.loads((p/'replay.json').read_bytes());assert replay['complete'] and not replay['errors']
groups=[]
for name in ('games-1.json','games-4.json'):
 v=json.loads((p/name).read_bytes());assert v['complete']
 methods={}
 for policy in ('geometric_half','linear_mixture','unit'):
  games=[g for g in v['games'] if policy in (g['white'],g['black'])]
  methods[policy]=dict(wins=sum(g['finished'] and g['winner']==(0 if g['white']==policy else 1) for g in games),
   losses=sum(g['finished'] and g['winner'] is not None and g['winner']!=(0 if g['white']==policy else 1) for g in games),
   draws=sum(g['finished'] and g['winner'] is None for g in games),unfinished=sum(not g['finished'] for g in games))
 groups.append(dict(seconds=v['local_seconds'],methods=methods,wall_seconds=v['wall_seconds'],recording_cost=v['recording_cost']))
live=json.loads((p/'recording-live.json').read_bytes());assert live['complete']
report=dict(scope='Declared stronger-comparator resource curve, actual-root finite diagnostics, operational identical-payload recording and checked Shogi tie inspection. Exposed adaptive development, not Elo/holdout/prior validation.',
 game_groups=groups,replay=replay,live_recording=dict(wall_seconds=live['wall_seconds'],cost=live['recording_cost'],verification=live['verification'],scope=live['format_scope']),
 raw_archive='../archive/development_budget_20261007/raw.zip',raw_zip_sha256=hashlib.sha256((archive/'raw.zip').read_bytes()).hexdigest(),raw_entries=entries,
 sources=source_index,source_zip_sha256=hashlib.sha256((archive/'sources.zip').read_bytes()).hexdigest(),production_code_changed=False,
 previous_qualification='chess_runtime_cost_results_20261006.json',previous_resource_batch='chess_mature_entry_results_20261006.json',public_push='held')
write_record(out,report);write_record(archive/'index.json',dict(raw_entries=entries,sources=source_index,portable_sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
print(json.dumps(dict(groups=groups,replay_games=len(replay['games']),played_plies=replay['played_plies'],live=report['live_recording'],portable_sha256=hashlib.sha256(out.read_bytes()).hexdigest())))
