import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-budget-20261007';out=p/'replay.json';assert not out.exists()
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
report=dict(complete=False,scope='All new full-history game streams, independent author legal sets and exact Core final histories; no Elo.',inputs={},games=[],errors=[])
files=['games-1.json','games-4.json','recording-live.json']
if (p/'pair-games-1sec.json').exists():files.append('pair-games-1sec.json')
for name in files:
 raw=(p/name).read_bytes();v=json.loads(raw);assert v['complete'] and len(v['games'])==12
 report['inputs'][name]=hashlib.sha256(raw).hexdigest()
 for i,g in enumerate(v['games']):
  other=d.UciOpponent(None,g['initial_fen'],1);s,_=d.replay_prefix(g['initial_fen'],c,g['opening_uci'],(other,))
  for row in g['moves']:
   legal={d.uci(a):a for a in d.iter_legal_actions(s,c)}
   assert set(legal)=={m.uci() for m in other.board.legal_moves}
   assert row['legal'] and row['move'] in legal and row['side']==s.position.side_to_move and row['ply']==s.ply_count
   s=d.apply_action(s,legal[row['move']],c);other.push(row['move'],s)
  assert d.record_value(s)==g['final_state']
  assert len(s.history)==len(g['opening_uci'])+len(g['moves'])+1
  report['games'].append(dict(instrumentation=(name=='recording-live.json'),source=name,index=i,id=g['id'],plies=len(g['moves']),prefix_plies=len(g['opening_uci']),end=g['end'],winner=g['winner'],white=g['white'],black=g['black']))
  d.write_record(out,report,indent=None)
report.update(complete=True,research_games=sum(not g['instrumentation'] for g in report['games']),instrumentation_games=sum(g['instrumentation'] for g in report['games']),played_plies=sum(g['plies'] for g in report['games']),prefix_plies=sum(g['prefix_plies'] for g in report['games']))
d.write_record(out,report);print('Replayed',len(report['games']),report['played_plies'],report['prefix_plies'],'zero errors')
