"""Changed premise: full-stock checked root limits drop-placement branches."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction as F
from dataclasses import replace,asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.core.transition import initial_state,legal_successors,apply_action
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.position import Hands
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.actions import action_is_drop
from generic_chess.ai.alphabeta.search import run_root_search,terminal_score
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.audit_exchange_custody import synthetic_state
from scripts.shogi_full_affine_inventory import FullAffineInventory,BASES
from scripts.shogi_static_inventory import quantize
from scripts.shogi_exact_contact_family import exact_board_means
from scripts.resource_mode_context import resource_ledger
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/shogi_checked_drop_ties_20261007.json';assert not out.exists()
c=compile_ruleset_for_execution(build_standard_shogi_ruleset());initial=initial_state(c);b=list(initial.position.board)
for src,dst in ((10,40),(64,43),(58,49),(70,31)):
 assert b[src] and b[dst] is None;b[dst]=b[src];b[src]=None
assert b[40].current_type_id=='R' and b[16].current_type_id=='B' and b[31].current_type_id=='R' and b[43].current_type_id=='B'
b[40]=None;b[16]=None
assert b[22].current_type_id=='P' and b[40] is None;b[40]=b[22];b[22]=None
root=synthetic_state(c,replace(initial.position,board=tuple(b),hands=(Hands((('B',1),('R',1))),initial.position.hands[1]),side_to_move=0))
resource_ledger(c,root.position,'shogi');assert semantic_engine_for(c).in_check(root.position,0) and not root.terminal_status.is_terminal
children=list(legal_successors(root,c));assert any(action_is_drop(a) for a,_ in children)
class Point:
 def __init__(self,w):self.affine=FullAffineInventory(c,w);self.held={base:quantize(F(1,2)*w[base]) for base in BASES};self.calls=0
 def evaluate(self,s):
  row=self.affine.row(s);v=row[0]+sum(row[i+1]*self.held[k] for i,k in enumerate(BASES));self.calls+=1;return v if s.position.side_to_move==0 else -v
m=exact_board_means('geometric_half');weights={k:v/m['TR'] for k,v in m.items()}
limits=SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8,quiescence_max_nodes=2048)
report={'question':'Does a checked full-stock root reduce uninformative static drop-placement ties and expose useful shared-budget choices?','child_scope':'Fresh one-ply child references restart root mate distance; completed finite scores are not WDL certificates. Root2ply retains original conditions.','scope':'New synthetic root; no claim of historical reachability, holdout, WDL or strength. h(base)=half normalized board price is an explicit approximation. Same prior2ply2048node10sec budget.','root':record_value(root),'legal_actions':len(children),'legal_drops':[str(a) for a,_ in children if action_is_drop(a)],'limits':asdict(limits),'models':[],'complete':False,'prior_sha256':hashlib.sha256((ROOT/'.local_agent/shogi_runtime_capture_drop_20261006.json').read_bytes()).hexdigest()}
write_record(out,report)
for policy,w in [('geometric_half',weights),('unit',{k:F(1) for k in weights})]:
 e=Point(w);rows={str(a):(-terminal_score(s.terminal_status,s.position.side_to_move,1) if s.terminal_status.is_terminal else -e.evaluate(s)) for a,s in children};best=max(rows.values());ties=sorted(k for k,v in rows.items() if v==best)
 stats=SearchStatistics();start=time.perf_counter();a,score,pv,reason=run_root_search(root,c,e,TranspositionTable(),limits,None,stats,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=True))
 assert a in {a for a,_ in children};s=apply_action(root,a,c);resource_ledger(c,s.position,'shogi');runtime=SearchPathRuntime.from_state(root,c)
 with runtime.pushed(a):assert runtime.position==s.position and runtime.terminal_status==s.terminal_status
 runtime.assert_balanced()
 root_seconds=time.perf_counter()-start;root_calls=e.calls
 child_rows=[]
 for candidate,child in children:
  cs=SearchStatistics();t=time.perf_counter()
  ca,cv,cpv,cr=run_root_search(child,c,e,TranspositionTable(),replace(limits,max_depth=1),None,cs,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=True))
  child_rows.append(dict(action=str(candidate),root_pov=-cv,reply=str(ca),pv=[str(x) for x in cpv],reason=cr,statistics=asdict(cs),seconds=time.perf_counter()-t))
  resource_ledger(c,child.position,'shogi')
 report['models'].append({'child_reply_rows':child_rows,'policy':policy,'held_weights':e.held,'board_weights':e.affine.weights,'oneply_rows':rows,'oneply_ties':ties,'selected':str(a),'score':score,'pv':[str(x) for x in pv],'reason':reason,'statistics':asdict(stats),'wall_seconds':root_seconds,'evaluations':root_calls,'total_evaluations_including_children':e.calls});write_record(out,report)
 print(policy,len(children),len(ties),str(a),reason,stats.completed_depth,flush=True)
report['complete']=True;write_record(out,report)
