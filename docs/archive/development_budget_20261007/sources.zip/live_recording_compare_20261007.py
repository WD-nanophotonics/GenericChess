"""One decision-driven stronger comparator after observed weak saturation."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-openings';out=ROOT/'.local_agent/mature-budget-20261007/recording-live.json';assert not out.exists()
assert json.loads((p/'progress.json').read_bytes())['complete']
suite=json.loads((p/'suite.json').read_bytes());c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
binary=ROOT/'.local_agent/mature-search/build/fairy-material.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
report={'format_scope':'Actual12short game streams, same payload written in both formats with alternating order; this measures recording cost in operational context, not playing strength or total game speedup. Additional verification and dual-write overhead retained separately.','scope':'Operational recording-format control selected after measured saving overhead; outcomes are not strength validation. All tables/colors/two histories retained.','question':'Does compact atomic saving reduce measured recording cost for identical payloads in actual short game streams?','conditions':{'local_seconds':.25,'local_threads':1,'local_hash_mib':16,'reference_elo_setting':1800,'reference_nodes':50000,'reference_time_fuse':1,'reference_threads':1,'reference_hash_mib':16,'subsequent_ply_limit':40},'cost':'Twelve fixed40ply instrumentation streams, paired writes with alternating order; extra verification/support costs recorded. No extra cells to obtain a favored timing.','producer_sha256':hashlib.sha256((ROOT/'scripts/chess_development.py').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'opponent_sha256':hashlib.sha256(ref.read_bytes()).hexdigest(),'suite_sha256':hashlib.sha256((p/'suite.json').read_bytes()).hexdigest(),'games':[],'complete':False}
recording={str(indent):{'seconds':0.,'writes':0,'bytes':0} for indent in (2,None)}
verification={'seconds':0.,'same_payloads':0,'support_frontier_seconds':0.}
iteration=0

def save():
 global iteration
 for indent in ((2,None) if iteration%2==0 else (None,2)):
  target=out.with_name('recording-pretty-frontier.json' if indent==2 else 'recording-compact-frontier.json')
  t=time.perf_counter();d.write_record(target,report,indent=indent);r=recording[str(indent)];r['seconds']+=time.perf_counter()-t;r['writes']+=1;r['bytes']+=target.stat().st_size
 t=time.perf_counter();assert json.loads(out.with_name('recording-pretty-frontier.json').read_bytes())==json.loads(out.with_name('recording-compact-frontier.json').read_bytes());verification['seconds']+=time.perf_counter()-t;verification['same_payloads']+=1
 iteration+=1
 t=time.perf_counter();d.write_record(out,report,indent=None);verification['support_frontier_seconds']+=time.perf_counter()-t

def stopcheck():
 for n in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise KeyboardInterrupt('User stop retained')
start=time.perf_counter();save()
for case in suite['cases']:
 for policy in d.POLICIES:
  for color in (0,1):
   stopcheck()
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as engine,chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as reference:
    engine.configure({'Threads':1,'Hash':16,'Use NNUE':False});reference.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':True,'UCI_Elo':1800})
    local=d.UciMaterial(engine,case['fen'],policy,.25);other=d.UciOpponent(reference,case['fen'],50000)
    def progress(game):report['active_game']=dict(id=case['id'],**game);save();stopcheck()
    game=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),40,progress,external=other,local_external=local,prefix=case['opening_uci'])
    report.pop('active_game',None);report['games'].append(dict(id=case['id'],**game));save();print(case['id'],policy,color,game['end'],game['winner'],game['plies_played'],flush=True)
report.update(complete=True,wall_seconds=time.perf_counter()-start,recording_cost=recording,verification=verification);d.write_record(out,report)
