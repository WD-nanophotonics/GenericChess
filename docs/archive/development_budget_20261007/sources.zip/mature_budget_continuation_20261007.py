"""Prospectively fixed stronger-comparator time curve; sequential, interruptible."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/mature-budget-20261007';p.mkdir(exist_ok=True)
assert not (p/'declaration.json').exists()
suite=json.loads((ROOT/'.local_agent/mature-openings/suite.json').read_bytes())
binary=ROOT/'.local_agent/mature-search/build/fairy-material.exe';config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
declaration=dict(question='Does increased equal local search time change practical failures against the already fixed1800 comparator, where weak1320 was saturated?',
 scope='Two fresh development batches, all tables/colors/prefixes retained; not independent validation, Elo or price fitting. Prior0.25sec1800 batch is descriptive baseline, not paired deterministic games.',
 budgets=[1,4],conditions=dict(reference_elo_setting=1800,reference_nodes=50000,reference_time_fuse=1,threads=1,hash_mib=16,max_subsequent_plies=160),
 decision='Retain all results. More time improving unit or regressions changes practical resource choice, not prices. No outcome-driven extra cells or threshold tuning.',
 cost='24 games, single-thread engines sequential; interruptible per action; completed cells retained if stopped. Requested local upper bound3840sec, actual recorded. No source/test/compilation load while timed.',
 binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256((ROOT/'scripts/chess_development.py').read_bytes()).hexdigest())
d.write_record(p/'declaration.json',declaration);d.write_record(p/'suite.json',suite)
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
def stopcheck():
 for n in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise KeyboardInterrupt('User stop retained')
for seconds in declaration['budgets']:
 out=p/f'games-{seconds}.json';assert not out.exists()
 report=dict(declaration=declaration,local_seconds=seconds,games=[],complete=False)
 cost=dict(writes=0,bytes=0,seconds=0.)
 def save(indent=None):
  t=time.perf_counter();d.write_record(out,report,indent=indent);cost['seconds']+=time.perf_counter()-t;cost['writes']+=1;cost['bytes']+=out.stat().st_size
 start=time.perf_counter();save()
 try:
  for case in suite['cases']:
   for policy in d.POLICIES:
    for color in (0,1):
     stopcheck()
     with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as other:
      e.configure({'Threads':1,'Hash':16,'Use NNUE':False});other.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':True,'UCI_Elo':1800})
      local=d.UciMaterial(e,case['fen'],policy,seconds);external=d.UciOpponent(other,case['fen'],50000)
      def progress(game):report['active_game']=dict(id=case['id'],**game);save();stopcheck()
      game=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=external,local_external=local,prefix=case['opening_uci'])
      report.pop('active_game',None);report['games'].append(dict(id=case['id'],**game));save()
      print(seconds,case['id'],policy,color,game['end'],game['winner'],game['plies_played'],flush=True)
  report['complete']=True
 finally:
  report.update(wall_seconds=time.perf_counter()-start,recording_cost=cost);save(2)
 print('BATCH COMPLETE',seconds,report['wall_seconds'],cost,flush=True)
