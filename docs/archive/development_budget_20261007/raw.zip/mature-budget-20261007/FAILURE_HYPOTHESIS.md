# Narrow failure hypothesis, pending development comparison
The qualified leaf sums only non-royal piece counts times fixed material values.
Equal counts have equal static values despite changed piece locations; search can
still distinguish later captures, terminals and rules. This is not proof that
missing activity is the sole cause of wandering or that deeper search cannot help.
Actual f3/g3/h3 and King displacement precede finite negative reference scores.
After the fixed resource curve, a single common positional residual is a possible
next intervention; do not change search/SEE/table/defaults concurrently.
IMPORTANT: the old Python shared2/5 terms use Queen1000 units, whereas this native
comparison freezes Pawn208/report100cp. Copying2/5 without an explicit common
reference scale does not preserve that old ablation. Any pilot must name its scale
and approximation; no price fitting, human-holdout access or claim of certified law.
Prefer a small executable control before broad theory. No new candidate or build
is active here. Keep unfavorable finite cells and unfinished games.
