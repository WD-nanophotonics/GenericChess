Budget declaration cost typo retained: local requested maximum is4800sec for24games, not3840sec. This corrects arithmetic only, not conditions/results.
Prepared optional direct1sec all12cells,1920sec maximum requested local search; launch only if an effective concrete resource decision remains and segment timing permits.
