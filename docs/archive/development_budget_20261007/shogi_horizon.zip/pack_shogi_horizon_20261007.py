import sys,json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=ROOT/'docs/archive/development_budget_20261007'
names=['shogi_checked_drop_'+suffix+'_20261007' for suffix in ('unmasked','ties_q2','unmasked_q2','ties_direct_q2','unmasked_direct_q2')]
files=[ROOT/'.local_agent'/(n+ext) for n in names for ext in ('.json','.py')]
files.append(Path(__file__))
index={}
with zipfile.ZipFile(p/'shogi_horizon.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  b=f.read_bytes();assert b'C:\\Users\\wdai' not in b
  z.writestr(f.name,b);index[f.name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(p/'shogi_horizon.zip') as z:
 for n,r in index.items():assert hashlib.sha256(z.read(n)).hexdigest()==r['sha256']
rows=[]
for variant in ('ties','unmasked'):
 v=json.loads((ROOT/'.local_agent'/f'shogi_checked_drop_{variant}_direct_q2_20261007.json').read_bytes());assert v['complete'] and v['legal_actions']==8
 for m in v['models']:
  children=m['child_reply_rows'];best=max(r['root_pov'] for r in children);ties=[r['action'] for r in children if r['root_pov']==best]
  assert best==m['score'] and m['selected'] in ties
  rows.append(dict(root=variant,policy=m['policy'],selected=m['selected'],score=m['score'],full_window_best=best,ties=ties,root_statistics=m['statistics'],root_seconds=m['wall_seconds'],child_nodes=sum(r['statistics']['nodes']+r['statistics']['qnodes'] for r in children)))
report=dict(scope='Observed fixed-horizon Shogi capture-extension diagnostic; synthetic full-stock roots, approximate held-half law; no WDL or default promotion.',
 changed_premise='Own Pawns e5->e7 and f3->f5 remove two exposed targets but also uncover Bishop routes. Predeclared simple masking prediction failed underq0; retained.',
 diagnostic_correction='Fresh maxdepth1 iterative child probes reserve ordinaryqsearch in their first phase. Their q2 label is configured, not active ordinary capture extension. Direct full-window depth1/ply1 contexts explicitly activate the second-phase q2 semantics and preserve original per-child caps. Raw earlier probes retained; they are not q2 root rankings.',
 rows=rows,archive='../archive/development_budget_20261007/shogi_horizon.zip',archive_sha256=hashlib.sha256((p/'shogi_horizon.zip').read_bytes()).hexdigest(),entries=index,production_code_changed=False)
write_record(ROOT/'docs/research/data/shogi_capture_horizon_20261007.json',report)
print('Shogi supplement archived and four full-window/root score matches verified')
