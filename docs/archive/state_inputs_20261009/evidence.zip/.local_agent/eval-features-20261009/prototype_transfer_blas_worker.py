"""Matched caller-cost transfer for the separate sparse Position prototype.
Reuse four frozen8x8 frontiers, two mixed-custody roots and existing rectangular
cannon construction. All methods return identical unit material: random-fixed
width16 network output is discarded. No training, useful-score or speed guarantee.
Fresh players, Core legality, no disk/shared TT, fixed ordering, D2q2/hard8,
4096nodes/5s per caller. Independent q0 record/producer retained. Completed-depth
or cap differences are reported, never hidden by extending only one method.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib,runpy,io,contextlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import action_from_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from rule_semantics_ir_fixtures import cannon_ruleset
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=Path('.local_agent/generated8-20261008/transfer.json')
cases=[]
for old in json.loads(src.read_bytes())['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
 for event in old['route']:s.submit(action_from_dict(event['action']))
 cases.append((str(old['seed']),c,s))
for width,height in ((7,5),(9,10)):
 rows=[[None]*width for _ in range(height)];rows[0][0]=Piece(0,'K','K');rows[-1][-1]=Piece(1,'K','K')
 rows[1][0]=Piece(0,'C','C');rows[1][-1]=Piece(1,'C','C');rows[1][width//2]=Piece(0,'C','C')
 rule=replace(cannon_ruleset(),board_size=None,board_width=width,board_height=height,initial_position=tuple(map(tuple,rows)),drop_allowed={'C':((False,)*(width*height),)*2})
 c=compile_ruleset_for_execution(rule);cases.append((f'cannon-{width}x{height}',c,GameSession(c)))
with contextlib.redirect_stdout(io.StringIO()):mixed=runpy.run_path(str(p/'semantic_base_probe.py'))
for i,state in enumerate(mixed['states']):
 s=GameSession(mixed['c']);s._state=state;s._search_history_witnesses=(state.position,);cases.append((f'mixed-{i}',mixed['c'],s))
import os
output=p/('prototype-transfer-blas-'+os.environ.get('GC_BLAS_CONTROL_LABEL','unknown')+'.json')
assert not output.exists()
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),helper_sha256=hashlib.sha256(Path('scripts/position_features.py').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),cases=[],complete=False,blas_env={key:os.environ.get(key) for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')})
cases=[row for row in cases if row[0]=='202610082102']
for name,c,s in cases:
 before=s.state;encoder=SparsePositionEncoder(c);rng=np.random.default_rng(20261009);weights=rng.normal(0,.01,(16,encoder.dimension));bias=rng.normal(0,.01,16)
 positions=[]
 class Eval:
  def __init__(self,kind):self.kind=kind;self.calls=0;self.feature_seconds=0.
  def evaluate(self,state):
   self.calls+=1
   if self.kind=='baseline':positions.append(state.position)
   else:
    tick=time.perf_counter()
    if self.kind=='dense':hidden=np.tanh(weights@encoder.dense(state.position)+bias)
    else:
     ix,v=encoder.encode(state.position);hidden=np.tanh(weights[:,ix]@v+bias)
    self.feature_seconds+=time.perf_counter()-tick
   value=sum((1 if q.owner==0 else -1)*1000 for q in state.position.board if q and not c.support.type_metadata[q.current_type_id].is_anchor)
   value+=sum((1 if owner==0 else -1)*1000*n for owner,hand in enumerate(state.position.hands) for tid,n in hand.counts if not c.support.type_metadata[tid].is_anchor)
   return value if state.position.side_to_move==0 else -value
  def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
 row=dict(name=name,fingerprint=c.ruleset_fingerprint,shape=[c.board_shape.width,c.board_shape.height],dimension=encoder.dimension,calls=[]);report['cases'].append(row)
 for rep in range(2):
  sig=None
  for kind in (('baseline','dense','sparse') if rep==0 else ('sparse','dense','baseline')):
   ev=Eval(kind);player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
   tick=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-tick
   current=(str(dec.action),dec.score,dec.nodes,dec.completed_depth,dec.termination_reason)
   if sig is None:sig=current
   assert s.state==before
   row['calls'].append(dict(rep=rep,kind=kind,seconds=elapsed,feature_seconds=ev.feature_seconds,leaf_calls=ev.calls,signature=current,matched_signature=current==sig,decision=record_value(dec)))
   write_record(output,report)
 unique=tuple(dict.fromkeys(positions));errors=[];active=[]
 for pos in unique:
  ix,v=encoder.encode(pos);dense=encoder.dense(pos);assert len(set(ix))==len(ix)
  errors.append(float(np.max(np.abs(np.tanh(weights@dense+bias)-np.tanh(weights[:,ix]@v+bias)))));active.append(len(ix))
 row.update(unique_positions=len(unique),max_forward_error=max(errors,default=0),active_range=[min(active,default=0),max(active,default=0)],complete=True)
 assert row['max_forward_error']<1e-12
 write_record(output,report)
 print(name,row['dimension'],row['active_range'],[(x['kind'],round(x['seconds'],4),x['signature'][2:]) for x in row['calls']],flush=True)
report['complete']=True;write_record(output,report)
