"""Replay all four frozen generated8 routes: aux-only q omissions versus encoding.
No new rule/trajectory, no searched reward, no all-quiet expansion. Aux-cleared
positions are counterfactual eligibility probes, not declared reachable states.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict,action_is_drop
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.ai.alphabeta.quiescence import material_inventory,classify_noisy
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=Path('.local_agent/generated8-20261008/transfer.json');data=json.loads(src.read_bytes())
report=dict(scope=__doc__,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),routes=[],complete=False)
start=time.perf_counter()
for old in data['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c);eng=semantic_engine_for(c)
 row=dict(seed=old['seed'],states=[],chosen_actions=[]);report['routes'].append(row)
 for ply in range(len(old['route'])+1):
  state=s.state;pos=state.position;acts=s.legal_actions() if not state.terminal_status.is_terminal else []
  sr=dict(ply=ply,aux=record_value(pos.aux_state),hands=record_value(pos.hands),legal_count=len(acts))
  if any(bool(v) for k,v in pos.aux_state):
   cp=replace(pos,aux_state=tuple((k,0 if isinstance(v,(bool,int)) else None) for k,v in pos.aux_state))
   actual=set(eng.legal_actions(pos));cleared=set(eng.legal_actions(cp))
   a=semantic_state_features(pos,c,(0,0,0));b=semantic_state_features(cp,c,(0,0,0))
   sr['clear_right_control']=dict(features_separate=not np.array_equal(a,b),different_axes=np.flatnonzero(a!=b).tolist(),actual_legal_count=len(actual),cleared_legal_count=len(cleared),only_actual=record_value(sorted(actual-cleared,key=str)),only_cleared=record_value(sorted(cleared-actual,key=str)))
  row['states'].append(sr)
  if ply==len(old['route']):break
  action=action_from_dict(old['route'][ply]['action']);assert action in acts
  child=apply_action(state,action,c);q=classify_noisy(state,[(action,child)],c)
  row['chosen_actions'].append(dict(ply=ply,action=action_to_dict(action),aux_changed=pos.aux_state!=child.position.aux_state,inventory_changed=material_inventory(pos)!=material_inventory(child.position),board_changed=pos.board!=child.position.board,q_included=bool(q),child_terminal=child.terminal_status.is_terminal,child_in_check=eng.in_check(child.position,child.position.side_to_move)))
  s.submit(action);assert s.state==child
 write_record(p/'temporal-probe.json',report)
report.update(complete=True,seconds=time.perf_counter()-start)
write_record(p/'temporal-probe.json',report)
print(json.dumps(dict(states=sum(len(r['states']) for r in report['routes']),right_controls=[dict(seed=r['seed'],**s) for r in report['routes'] for s in r['states'] if 'clear_right_control' in s],aux_only_events=[dict(seed=r['seed'],**a) for r in report['routes'] for a in r['chosen_actions'] if a['aux_changed'] and not a['inventory_changed']],seconds=report['seconds'])))
