"""Existing mixed-custody rule, same compiled rule and current board.
Swap only two promoted victim base identities; fixed dynamic zeros deliberately
isolate the compact encoder (not the full dynamic evaluator). No search/train.
"""
from pathlib import Path
from dataclasses import replace
import sys, json, hashlib, time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import RuleSemanticAction, RuleGeometrySpec, RuleActionEffect, RuleSquareRef
from generic_chess.session.session import GameSession
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import BoardMove, DropMove, action_is_drop
from generic_chess.core.coordinates import Square
from scripts.research_record import write_record, record_value
p=Path(__file__).parent
source=Path('.local_agent/qfrontier-20261009/mixed-choice.json')
data=json.loads(source.read_bytes())
rule=ruleset_from_dict(data['cases'][0]['rules'])
# Inert off-board augmentation changes no finite-board behavior.
noop=RuleSemanticAction(name='outside_board',type_ids=('R',),geometry=RuleGeometrySpec(kind='leap',offset=(99,0)),target_relation='empty',effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),))
c=compile_semantic_ruleset(replace(rule,semantic_actions=(noop,)))
original=GameSession(c).state
board=list(original.position.board)
victims=[i for i,piece in enumerate(board) if piece and piece.owner==1 and piece.current_type_id=='R']
assert len(victims)==2
left,right=victims
board[left]=replace(board[left],base_type_id=original.position.board[right].base_type_id)
board[right]=replace(board[right],base_type_id=original.position.board[left].base_type_id)
swapped=replace(original,position=replace(original.position,board=tuple(board)))
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.position import HistoryRecord
from generic_chess.core.semantic_executor import semantic_engine_for
key=repetition_identity_key(swapped.position,c)
swapped=replace(swapped,repetition_counts=((key,1),),history=(HistoryRecord(key,-1,'',False),),terminal_status=semantic_engine_for(c).terminal_result(swapped.position,0,((key,1),)))
states=[original,swapped]
vectors=[semantic_state_features(s.position,c,(0,0,0)) for s in states]
assert np.array_equal(*vectors)
root_actions=[set(legal_actions(s,c)) for s in states]
assert root_actions[0]==root_actions[1]
capture=next(a for a in root_actions[0] if getattr(a,'from_square',None)==Square(3,3) and a.to_square==Square(1,3))
reply=None
rows=[]
for state in states:
 assert capture in legal_actions(state,c)
 child=apply_action(state,capture,c)
 reply=next(a for a in legal_actions(child,c) if getattr(a,'from_square',None)==Square(7,7) and a.to_square==Square(6,7))
 assert reply in legal_actions(child,c)
 following=apply_action(child,reply,c)
 drops=[a for a in legal_actions(following,c) if action_is_drop(a)]
 rows.append(dict(base_left=state.position.board[left].base_type_id,hand=record_value(child.position.hands[0].counts),drops=record_value(drops)))
assert [len(r['drops']) for r in rows] in ([0,1],[1,0])
report=dict(scope=__doc__,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),same_compiled_fingerprint=c.ruleset_fingerprint if hasattr(c,'ruleset_fingerprint') else original.position.ruleset_fingerprint,feature_dimension=len(vectors[0]),compiled_kind=type(c).__name__,scope_correction='Original5dim legacy probe was outside semantic encoder contract. This repeat uses inert off-board semantic augmentation and retains12same legal root actions.',same_features=True,same_root_legal_actions=len(root_actions[0]),capture=record_value(capture),reply=record_value(reply),rows=rows,conclusion='Compact Position encoder aliases base identities that change actual captured hand stock and subsequent legal drops. Dynamic zeros isolate this representation; no full evaluator collision/strength claim.')
write_record(p/'semantic-base-probe.json',report)
print(json.dumps(report,ensure_ascii=True))
