"""Cost of inputs which distinguished the declared same-material batch.
Four already frozen roots; same unit evaluation returned for ALL methods.
No learned scores: sparse Position width16 fixed network, coarse/relations
fixed linear dot. q0 and q2/hard8, D2/2048nodes/3sec, two order-balanced repeats.
No budget extension for capped cases. Feature count is not assumed to equal cost.
"""
from pathlib import Path
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids,spatial_occupancy_features,tactical_interaction_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;decl=json.loads((p/'same-material-declaration.json').read_bytes());old=next(r for r in json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases'] if r['seed']==202610082102)
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));types=non_anchor_type_ids(c);encoder=SparsePositionEncoder(c)
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration_sha256=hashlib.sha256((p/'same-material-declaration.json').read_bytes()).hexdigest(),calls=[],complete=False)
assert not (p/'representation-caller.json').exists()
names=('baseline','sparse','coarse','relations','coarse_relations');rng=np.random.default_rng(20261009)
w=rng.normal(0,.01,(16,encoder.dimension));bias=np.zeros(16)
linear={name:rng.normal(0,.01,dim) for name,dim in (('coarse',90),('relations',36),('coarse_relations',126))}
class Eval:
 def __init__(self,name):self.name=name;self.calls=0;self.seconds=0.
 def evaluate(self,state):
  self.calls+=1;pos=state.position
  if self.name!='baseline':
   tick=time.perf_counter()
   if self.name=='sparse':
    ix,v=encoder.encode(pos);np.tanh(w[:,ix]@v+bias).sum()
   else:
    features=[]
    if self.name in ('coarse','coarse_relations'):features.extend(v for cells in spatial_occupancy_features(pos,types).values() for v in cells)
    if self.name in ('relations','coarse_relations'):features.extend(tactical_interaction_features(pos,c).values())
    np.asarray(features)@linear[self.name]
   self.seconds+=time.perf_counter()-tick
  return 1000*sum(material_features(pos,types,perspective=pos.side_to_move).array())
 def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
s=GameSession(c)
for ply in range(13):
 if ply in (0,4,8,12):
  before=s.state
  for qdepth in (0,2):
   for rep in range(2):
    reference=None
    for name in (names if rep==0 else tuple(reversed(names))):
     assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
     ev=Eval(name);player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_ordering=False,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
     tick=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=3,quiescence_max_depth=qdepth,quiescence_hard_max_depth=8 if qdepth else 0));elapsed=time.perf_counter()-tick
     signature=(str(dec.action),dec.score,dec.completed_depth,dec.nodes,dec.qnodes,dec.termination_reason)
     if reference is None:reference=signature
     assert s.state==before
     report['calls'].append(dict(ply=ply,qdepth=qdepth,rep=rep,kind=name,seconds=elapsed,feature_seconds=ev.seconds,leaves=ev.calls,signature=signature,matched_signature=signature==reference,decision=record_value(dec)))
     write_record(p/'representation-caller.json',report)
    print('root',ply,'q',qdepth,'rep',rep,[(x['kind'],round(x['seconds'],3),x['signature'][2:]) for x in report['calls'][-5:]],flush=True)
 if ply<len(decl['route']):s.submit(action_from_dict(decl['route'][ply]))
report['complete']=True;write_record(p/'representation-caller.json',report)
