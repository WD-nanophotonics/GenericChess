from pathlib import Path
p=Path(__file__).parent
s=(p/'base_probe.py').read_text(encoding='utf-8')
s=s.replace('from generic_chess.rules.compiler import compile_ruleset_for_execution','from generic_chess.rules.compiler import compile_semantic_ruleset\nfrom generic_chess.rules.schema import RuleSemanticAction, RuleGeometrySpec, RuleActionEffect, RuleSquareRef')
s=s.replace("c=compile_ruleset_for_execution(ruleset_from_dict(data['cases'][0]['rules']))", "rule=ruleset_from_dict(data['cases'][0]['rules'])\n# Inert off-board augmentation changes no finite-board behavior.\nnoop=RuleSemanticAction(name='outside_board',type_ids=('R',),geometry=RuleGeometrySpec(kind='leap',offset=(99,0)),target_relation='empty',effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),))\nc=compile_semantic_ruleset(replace(rule,semantic_actions=(noop,)))")
s=s.replace('from generic_chess.core.actions import BoardMove, DropMove','from generic_chess.core.actions import BoardMove, DropMove, action_is_drop')
s=s.replace("if isinstance(a,DropMove)","if action_is_drop(a)")
s=s.replace("p/'base-probe.json'","p/'semantic-base-probe.json'")
s=s.replace("feature_dimension=len(vectors[0])", "feature_dimension=len(vectors[0]),compiled_kind=type(c).__name__,scope_correction='Original5dim legacy probe was outside semantic encoder contract. This repeat uses inert off-board semantic augmentation and retains12same legal root actions.'")
(p/'semantic_base_probe.py').write_text(s,encoding='utf-8')
