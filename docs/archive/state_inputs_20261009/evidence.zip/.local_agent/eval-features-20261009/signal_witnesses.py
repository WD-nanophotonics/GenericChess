"""Mechanistic replay and independent full-width reference on declared batch.
Pick first different teacher pair per informative root, before new reference
calls, plus every coarse3x3 input collision. No labels/rules/sample extension.
Reference remainingD2,30sec/10000leaf checkpoint per child; failures retained.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.learning.features import material_features,non_anchor_type_ids,tactical_interaction_features
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;decl=json.loads((p/'same-material-declaration.json').read_bytes());labels=json.loads((p/'same-material-signal.json').read_bytes());ab=json.loads((p/'signal-ablation.json').read_bytes())
old=next(r for r in json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases'] if r['seed']==202610082102);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));types=non_anchor_type_ids(c)
rootmap={r['ply']:r for r in decl['roots']};labelmap={r['ply']:r for r in labels['roots']};abmap={r['ply']:r for r in ab['roots']};selected={};reference_ids={}
for row in labels['roots']:
 differing=[pair for g in row['groups'] for pair in g['pairs'] if pair['known'] and pair['different_teacher_score']]
 if differing:reference_ids[row['ply']]=tuple(differing[0]['indices'])
 selected[row['ply']]=set(reference_ids.get(row['ply'],()))
 for pair in differing:
  a,b=pair['indices'];features=abmap[row['ply']]['children']
  if features[a]['hashes']['coarse3x3']==features[b]['hashes']['coarse3x3']:selected[row['ply']].update((a,b))
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),selected={str(k):sorted(v) for k,v in selected.items()},reference_ids=reference_ids,rows=[],complete=False)
write_record(p/'signal-witness-declaration.json',report)
class Unit:
 def __init__(self):self.calls=0;self.started=time.perf_counter()
 def evaluate(self,state):
  self.calls+=1
  if self.calls>10000 or time.perf_counter()-self.started>30:raise RuntimeError('reference per-child cost checkpoint')
  return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
s=GameSession(c)
for ply in range(13):
 if ply in rootmap:
  for index in sorted(selected[ply]):
   item=rootmap[ply]['children'][index];label=labelmap[ply]['children'][index];child=apply_action(s.state,action_from_dict(item['action']),c);pv=[dict(material=record_value(material_features(child.position,types)),terminal=record_value(child.terminal_status))];cursor=child
   for actiondata in label['decision']['principal_variation']:
    # SearchDecision records dataclass actions; match the actual legal object,
    # rather than pretending record_value is the action_to_dict wire schema.
    action=next(a for a in legal_actions(cursor,c) if record_value(a)==actiondata)
    cursor=apply_action(cursor,action,c)
    pv.append(dict(action=action_to_dict(action),material=record_value(material_features(cursor.position,types)),terminal=record_value(cursor.terminal_status)))
   row=dict(ply=ply,index=index,action=item['action'],root_score=label['root_score'],pv=pv,relations=tactical_interaction_features(child.position,c));report['rows'].append(row)
   if index in reference_ids.get(ply,()):
    ev=Unit();start=time.perf_counter()
    try:
     score,action=reference_minimax(child,2,ev,c);assert -score==label['root_score'];row['reference']=dict(complete=True,root_score=-score,action=record_value(action))
    except Exception as exc:row['reference']=dict(complete=False,failure=dict(kind=type(exc).__name__,message=str(exc)))
    row['reference'].update(leaves=ev.calls,seconds=time.perf_counter()-start)
   write_record(p/'signal-witnesses.json',report)
   print(ply,index,row['root_score'],row.get('reference'),flush=True)
 if ply<len(decl['route']):s.submit(action_from_dict(decl['route'][ply]))
report['complete']=True;write_record(p/'signal-witnesses.json',report)
