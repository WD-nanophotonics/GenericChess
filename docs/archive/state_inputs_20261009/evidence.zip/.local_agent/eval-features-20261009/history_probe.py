"""Legal repeated knight cycle with explicit repetition-limit4 rule variant.
The existing western certification fixture has limit100000; only that limit is
changed here to expose history semantics. Not a standard-chess rules claim, new
training target or evaluator correction. Search still owns complete history.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.coordinates import Square
from generic_chess.core.actions import action_to_dict
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.learning.nonlinear import semantic_state_features
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;original=build_western_chess_ruleset();rule=replace(original,repetition_limit=4)
c=compile_semantic_ruleset(rule);s=GameSession(c);encoder=SparsePositionEncoder(c)
cycle=((Square(1,0),Square(2,2)),(Square(6,7),Square(5,5)),(Square(2,2),Square(1,0)),(Square(5,5),Square(6,7)))
snapshots=[];keys=[];route=[]
for ply in range(12):
 source,target=cycle[ply%4]
 action=next(a for a in s.legal_actions() if getattr(a,'from_square',None)==source and getattr(a,'to_square',None)==target)
 route.append(action_to_dict(action));s.submit(action)
 if (ply+1)%4==0:
  state=s.state;snapshots.append(state)
  runtime=SearchPathRuntime(state,c,history_witnesses=s._search_history_witnesses)
  keys.append(runtime.search_key())
assert snapshots[0].position==snapshots[1].position==snapshots[2].position
assert not snapshots[0].terminal_status.is_terminal and not snapshots[1].terminal_status.is_terminal
assert snapshots[2].terminal_status.is_terminal
assert keys[0]!=keys[1]!=keys[2]
assert np.array_equal(encoder.dense(snapshots[0].position),encoder.dense(snapshots[1].position))
assert np.array_equal(semantic_state_features(snapshots[0].position,c,(0,0,0)),semantic_state_features(snapshots[1].position,c,(0,0,0)))
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),original_repetition_limit=original.repetition_limit,control_repetition_limit=rule.repetition_limit,same_position=True,same_old_and_new_position_features=True,search_keys_separate=True,route=route,states=[dict(ply=state.ply_count,current_repetitions=dict(state.repetition_counts)[repetition_identity_key(state.position,c)],history_length=len(state.history),terminal=record_value(state.terminal_status)) for state in snapshots],conclusion='Same nonterminal Position at plies4/8 can have different return after same four legal actions: ongoing versus repetition draw. Position-only prediction cannot encode this target difference; full search keeps the distinction. No mandatory history feature/default change follows.')
write_record(p/'history-probe.json',report);print(json.dumps(report))
