"""Whole-batch descriptive input collisions; no fitted weights or new labels.
Compare existing 3x3 occupancy and semantic relations against old full current
occupancy and new base/promotion-aware sparse Position input. This is post-label
representation analysis of the declared batch, not held-out model performance.
"""
from pathlib import Path
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import spatial_occupancy_features,tactical_interaction_features
from generic_chess.learning.nonlinear import semantic_state_features
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent;declaration=json.loads((p/'same-material-declaration.json').read_bytes());labels=json.loads((p/'same-material-signal.json').read_bytes())
old=next(r for r in json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases'] if r['seed']==202610082102)
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));encoder=SparsePositionEncoder(c);s=GameSession(c)
assert c.ruleset_fingerprint==declaration['fingerprint']
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration_sha256=hashlib.sha256((p/'same-material-declaration.json').read_bytes()).hexdigest(),labels_sha256=hashlib.sha256((p/'same-material-signal.json').read_bytes()).hexdigest(),roots=[],complete=False)
rootmap={r['ply']:r for r in declaration['roots']};labelmap={r['ply']:r for r in labels['roots']}
for ply in range(13):
 if ply in rootmap:
  declared=rootmap[ply];row=dict(ply=ply,children=[],pair_counts=dict(total=0,known=0,unknown=0,ties=0,teacher_difference=0,material_only_difference=0),collisions={},groups=[]);report['roots'].append(row);representations={}
  for item in declared['children']:
   state=apply_action(s.state,action_from_dict(item['action']),c);pos=state.position;material=tuple(item['material']['board_counts']+item['material']['hand_counts'])
   timing={};features={}
   for name,fn in (
    ('coarse3x3',lambda:tuple(v for cells in spatial_occupancy_features(pos,tuple(declaration['types'])).values() for v in cells)),
    ('relations',lambda:tuple(tactical_interaction_features(pos,c).values())),
    ('old_position',lambda:semantic_state_features(pos,c,(0,0,0))),
    ('new_position',lambda:encoder.dense(pos))):
    tick=time.perf_counter();features[name]=np.asarray(fn(),dtype=np.float64);timing[name]=time.perf_counter()-tick
   features['coarse_relations']=np.concatenate((features['coarse3x3'],features['relations']))
   hashes={name:hashlib.sha256(v.tobytes()).hexdigest() for name,v in features.items()};representations[len(row['children'])]=hashes
   assert hashes['new_position']==item['feature_sha256']
   row['children'].append(dict(hashes=hashes,dimensions={name:len(v) for name,v in features.items()},seconds=timing))
  for group in labelmap[ply]['groups']:
   stats=dict(size=len(group['indices']),pairs=len(group['pairs']),known=0,unknown=0,ties=0,differences=0,material_differences=0,score_range=None)
   scores=[x['root_score'] for x in labelmap[ply]['children'] if x['index'] in group['indices'] and x['known']]
   if scores:stats['score_range']=[min(scores),max(scores)]
   for pair in group['pairs']:
    counts=row['pair_counts'];counts['total']+=1
    if not pair['known']:counts['unknown']+=1;stats['unknown']+=1;continue
    counts['known']+=1;stats['known']+=1
    if not pair['different_teacher_score']:counts['ties']+=1;stats['ties']+=1;continue
    counts['teacher_difference']+=1;stats['differences']+=1
    if pair['both_material_target']:counts['material_only_difference']+=1;stats['material_differences']+=1
    a,b=(representations[i] for i in pair['indices'])
    for name in a:
     entry=row['collisions'].setdefault(name,dict(all_differences=0,material_differences=0))
     if a[name]==b[name]:
      entry['all_differences']+=1;entry['material_differences']+=int(pair['both_material_target'])
   row['groups'].append(stats)
  write_record(p/'signal-ablation.json',report)
 if ply<len(declaration['route']):s.submit(action_from_dict(declaration['route'][ply]))
report['complete']=True;write_record(p/'signal-ablation.json',report)
print(json.dumps([{k:r[k] for k in ('ply','pair_counts','collisions','groups')} for r in report['roots']],indent=2))
