"""Prospective fixed-batch teacher-information check, no fitting/training.
One existing complete generated8 RuleSet seed2102 (already exposed, not holdout).
Sample roots at plies0/4/8/12 of ONE lexical-action seeded random legal route,
seed2026100901, independent of evaluation. Freeze all root children and material
groups BEFORE teacher calls. Preserve every child, tie, terminal and missing.
Teacher: unit non-anchor board-current/hand-base material, Core AlphaBeta,
remaining depth2 q0, no TT/order/native/disk/root tactics,2048nodes/1sec per child.
Per-root120sec safety checkpoint leaves unfinished children UNKNOWN, not ties;
no resampling/extension. Full legal GameState history carried. Root perspective
is negative of child side-to-move score. Terminal-derived scores reported apart.
This checks compressible finite-search information, not independent true value,
material prices, need for nonlinearity, learning gains or cross-rule transfer.
"""
from pathlib import Path
import sys,json,random,time,hashlib,itertools
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.evaluation.config import MATE_THRESHOLD
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=Path('.local_agent/generated8-20261008/transfer.json')
assert not (p/'same-material-signal.json').exists()
old=next(r for r in json.loads(src.read_bytes())['cases'] if r['seed']==202610082102)
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));types=non_anchor_type_ids(c);encoder=SparsePositionEncoder(c)
s=GameSession(c);rng=random.Random(2026100901);roots=[];route=[]
for ply in range(13):
 if s.state.terminal_status.is_terminal:break
 actions=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True))
 if ply in (0,4,8,12):
  children=[]
  for action in actions:
   child=apply_action(s.state,action,c);f=material_features(child.position,types,perspective=s.state.position.side_to_move)
   ix,v=encoder.encode(child.position)
   children.append(dict(action=action_to_dict(action),material=record_value(f),feature_sha256=hashlib.sha256(encoder.dense(child.position).tobytes()).hexdigest(),active_features=len(ix),state=record_value(child)))
  roots.append(dict(ply=ply,state=s.state,witnesses=s._search_history_witnesses,children=children,actions=actions))
 if ply==12 or not actions:break
 action=rng.choice(actions);route.append(action_to_dict(action));s.submit(action)
declaration=dict(scope=__doc__,at_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),helper_sha256=hashlib.sha256(Path('scripts/position_features.py').read_bytes()).hexdigest(),fingerprint=c.ruleset_fingerprint,types=types,route=route,roots=[dict(ply=r['ply'],state=record_value(r['state']),children=r['children']) for r in roots])
write_record(p/'same-material-declaration.json',declaration)
report=dict(scope=__doc__,declaration_sha256=hashlib.sha256((p/'same-material-declaration.json').read_bytes()).hexdigest(),roots=[],complete=False)
class Unit:
 def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
 def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
for root in roots:
 start=time.perf_counter();row=dict(ply=root['ply'],children=[],complete=False);report['roots'].append(row)
 for index,(action,declared) in enumerate(zip(root['actions'],root['children'])):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  child=apply_action(root['state'],action,c);item=dict(index=index,action=declared['action'],material=declared['material'],feature_sha256=declared['feature_sha256'],terminal=record_value(child.terminal_status));row['children'].append(item)
  if child.terminal_status.is_terminal:
   item.update(known=True,root_score=-terminal_score(child.terminal_status,child.position.side_to_move,1),target_kind='terminal-child',seconds=0.)
  elif time.perf_counter()-start>=120:
   item.update(known=False,reason='per-root cost checkpoint before call')
  else:
   cs=GameSession(c);cs._state=child;cs._search_history_witnesses=root['witnesses']+(child.position,)
   player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
   tick=time.perf_counter();decision=player.choose_action(cs,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick
   assert cs.state==child
   item.update(known=decision.completed_depth==2,decision=record_value(decision),seconds=elapsed)
   if item['known']:item.update(root_score=-decision.score,target_kind='terminal-derived' if abs(decision.score)>=MATE_THRESHOLD else 'finite-material-search')
   else:item['reason']='teacher incomplete; returned shallower score intentionally unused'
  if index%8==0:write_record(p/'same-material-signal.json',report);print('ply',root['ply'],'children',index+1,'/',len(root['children']),'seconds',round(time.perf_counter()-start,2),flush=True)
 groups={}
 for item in row['children']:
  m=item['material'];key=tuple(m['board_counts']+m['hand_counts']);groups.setdefault(key,[]).append(item)
 summary=[]
 for material,items in groups.items():
  pairs=[]
  for a,b in itertools.combinations(items,2):
   known=a['known'] and b['known'];different=known and a['root_score']!=b['root_score']
   pairs.append(dict(indices=[a['index'],b['index']],known=known,different_teacher_score=different,same_new_features=a['feature_sha256']==b['feature_sha256'],both_material_target=known and a['target_kind']==b['target_kind']=='finite-material-search'))
  summary.append(dict(material=material,indices=[x['index'] for x in items],pairs=pairs))
 row.update(groups=summary,seconds=time.perf_counter()-start,complete=True)
 write_record(p/'same-material-signal.json',report)
 print('ROOT',root['ply'],'children',len(row['children']),'groups',len(groups),'known',sum(x['known'] for x in row['children']),'seconds',row['seconds'],flush=True)
report['complete']=True;write_record(p/'same-material-signal.json',report)
