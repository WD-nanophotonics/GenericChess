"""Changed-premise engineering check: child-process BLAS thread cap, no training.
Existing q2-completing seed2102 chosen because total dense overhead exceeded
recorded forward time. Same states/network/search resource conditions; two
fresh processes default environment versus explicit1thread. No product/env edit.
"""
from pathlib import Path
import subprocess,sys,os,json,hashlib
p=Path(__file__).parent
raw=(p/'prototype_transfer.py').read_text()
raw=raw.replace("for name,c,s in cases:","cases=[row for row in cases if row[0]=='202610082102']\nfor name,c,s in cases:")
raw=raw.replace("output=p/'prototype-transfer-q2.json'","import os\noutput=p/('prototype-transfer-blas-'+os.environ.get('GC_BLAS_CONTROL_LABEL','unknown')+'.json')")
raw=raw.replace("cases=[],complete=False)","cases=[],complete=False,blas_env={key:os.environ.get(key) for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')})")
helper=p/'prototype_transfer_blas_worker.py';helper.write_text(raw,encoding='utf-8')
record=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),worker_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),runs=[])
for label in ('default','one'):
 env=os.environ.copy();env['GC_BLAS_CONTROL_LABEL']=label
 if label=='one':env['OPENBLAS_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1';env['MKL_NUM_THREADS']='1'
 result=subprocess.run([sys.executable,str(helper)],env=env,text=True,capture_output=True,timeout=90)
 record['runs'].append(dict(label=label,exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr))
 (p/'blas-control.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
 print(label,result.returncode,result.stdout,flush=True)
 if result.returncode:break
