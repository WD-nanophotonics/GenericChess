"""Sparse full recomputation feasibility, not incremental NNUE or training.
Same square-only layout as old encoder plus base/promoted identity append.
Random-fixed standardized network is discarded in search; unit scores retained.
"""
from pathlib import Path
import sys,time,json,hashlib,runpy,io,contextlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
p=Path(__file__).parent
with contextlib.redirect_stdout(io.StringIO()):
 ns=runpy.run_path(str(p/'semantic_base_probe.py'))
c=ns['c'];states=ns['states'];types=tuple(sorted(c.support.type_metadata));ids={t:i for i,t in enumerate(types)}
base=tuple(sorted(t.type_id for t in c._legacy_compiled.piece_types));baseids={t:i for i,t in enumerate(base)}
area=len(states[0].position.board);nt=len(types);nb=len(base)
old_dim=len(semantic_state_features(states[0].position,c,(0,0,0)));dim=old_dim+2*nt*area+2*area
def dense(pos):
 old=semantic_state_features(pos,c,(0,0,0));x=np.zeros(dim);x[:old_dim]=old
 for square,piece in enumerate(pos.board):
  if piece is not None:
   x[old_dim+(piece.owner*nt+ids[piece.base_type_id])*area+square]=1.
   x[old_dim+2*nt*area+piece.owner*area+square]=int(piece.promoted)
 return x
def sparse(pos):
 ix=[];v=[]
 def put(i,value):
  if value:ix.append(i);v.append(float(value))
 for square,piece in enumerate(pos.board):
  if piece is not None:
   put((piece.owner*nt+ids[piece.current_type_id])*area+square,1)
   put(old_dim+(piece.owner*nt+ids[piece.base_type_id])*area+square,1)
   put(old_dim+2*nt*area+piece.owner*area+square,int(piece.promoted))
 offset=2*nt*area
 for owner in (0,1):
  for tid,count in pos.hands[owner].counts:put(offset+owner*nb+baseids[tid],count)
 offset+=2*nb;put(offset+pos.side_to_move,1);offset+=5 # two side bits and three fixed zero dynamic fields
 aux=dict(pos.aux_state);size=pos.board_size()
 for slot in c.ir.aux_slots:
  for owner in ((-1,) if slot.scope=='global' else (0,1)):
   value=aux.get((slot.slot_id,owner),slot.initial)
   if slot.value_kind=='bool':put(offset,float(value or 0));offset+=1
   else:
    if isinstance(value,tuple) and len(value)==2:
     put(offset,1);put(offset+1,value[0]/max(size,1));put(offset+2,value[1]/max(size,1))
    offset+=3
 assert offset==old_dim
 return np.asarray(ix,dtype=np.intp),np.asarray(v,dtype=float)
rng=np.random.default_rng(20261009)
w=rng.normal(0,.01,(16,dim));b=rng.normal(0,.01,16)
mean=rng.normal(0,.1,dim);scale=rng.uniform(.25,2,dim)
ws=w/scale;bs=b-ws@mean
def forward(pos,kind):
 if kind=='dense':return np.tanh(w@((dense(pos)-mean)/scale)+b)
 ix,v=sparse(pos);return np.tanh(ws[:,ix]@v+bs)
positions=[]
class Eval:
 def __init__(self,kind):self.kind=kind;self.calls=0;self.seconds=0.
 def evaluate(self,state):
  self.calls+=1;positions.append(state.position)
  if self.kind!='baseline':
   start=time.perf_counter();forward(state.position,self.kind);self.seconds+=time.perf_counter()-start
  value=sum((1 if q.owner==0 else -1)*1000 for q in state.position.board if q and not c.support.type_metadata[q.current_type_id].is_anchor)
  return value if state.position.side_to_move==0 else -value
 def type_value(self,tid):return 0 if c.support.type_metadata[tid].is_anchor else 1000
 def capture_order_value(self,moving,captured):return self.type_value(captured.current_type_id)*10-self.type_value(moving.current_type_id)//10
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dimension=dim,calls=[])
for rep in range(3):
 for stateid,state in enumerate(states):
  sig=None
  # Reverse measured order on middle replicate to expose order-dependent noise.
  for kind in (('baseline','sparse','dense') if rep==1 else ('baseline','dense','sparse')):
   s=GameSession(c);s._state=state;s._search_history_witnesses=(state.position,);ev=Eval(kind)
   player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
   start=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-start
   current=(str(dec.action),dec.score,dec.nodes)
   if sig is None:sig=current
   assert current==sig and dec.completed_depth==2 and s.state==state
   report['calls'].append(dict(rep=rep,state=stateid,kind=kind,wall_seconds=elapsed,feature_seconds=ev.seconds,leaves=ev.calls,signature=current))
  write_record(p/'sparse-forward.json',report)
unique=tuple(dict.fromkeys(positions));maximum=0.;nonzeros=[]
for pos in unique:
 ix,v=sparse(pos);reconstructed=np.zeros(dim);reconstructed[ix]=v
 assert len(set(ix))==len(ix) and np.array_equal(reconstructed,dense(pos))
 error=float(np.max(np.abs(forward(pos,'dense')-forward(pos,'sparse'))));maximum=max(maximum,error);nonzeros.append(len(ix))
 assert error<1e-12
report.update(complete=True,unique_leaf_positions=len(unique),queried_leaves=len(positions),max_absolute_error=maximum,active_feature_range=[min(nonzeros),max(nonzeros)],dense_multiplies=16*dim,sparse_multiplies_range=[16*min(nonzeros),16*max(nonzeros)],standardization='weights/scale and bias-weights_scaled@mean; no fitted parameters')
write_record(p/'sparse-forward.json',report)
print(json.dumps(report))
