"""Existing mixed-custody rule, same compiled rule and current board.
Swap only two promoted victim base identities; fixed dynamic zeros deliberately
isolate the compact encoder (not the full dynamic evaluator). No search/train.
"""
from pathlib import Path
from dataclasses import replace
import sys, json, hashlib, time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import BoardMove, DropMove
from generic_chess.core.coordinates import Square
from scripts.research_record import write_record, record_value
p=Path(__file__).parent
source=Path('.local_agent/qfrontier-20261009/mixed-choice.json')
data=json.loads(source.read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(data['cases'][0]['rules']))
original=GameSession(c).state
board=list(original.position.board)
victims=[i for i,piece in enumerate(board) if piece and piece.owner==1 and piece.current_type_id=='R']
assert len(victims)==2
left,right=victims
board[left]=replace(board[left],base_type_id=original.position.board[right].base_type_id)
board[right]=replace(board[right],base_type_id=original.position.board[left].base_type_id)
swapped=replace(original,position=replace(original.position,board=tuple(board)))
states=[original,swapped]
vectors=[semantic_state_features(s.position,c,(0,0,0)) for s in states]
assert np.array_equal(*vectors)
root_actions=[set(legal_actions(s,c)) for s in states]
assert root_actions[0]==root_actions[1]
capture=BoardMove(Square(3,3),Square(1,3))
reply=BoardMove(Square(7,7),Square(6,7))
rows=[]
for state in states:
 assert capture in legal_actions(state,c)
 child=apply_action(state,capture,c)
 assert reply in legal_actions(child,c)
 following=apply_action(child,reply,c)
 drops=[a for a in legal_actions(following,c) if isinstance(a,DropMove)]
 rows.append(dict(base_left=state.position.board[left].base_type_id,hand=record_value(child.position.hands[0].counts),drops=record_value(drops)))
assert [len(r['drops']) for r in rows] in ([0,1],[1,0])
report=dict(scope=__doc__,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),same_compiled_fingerprint=c.ruleset_fingerprint if hasattr(c,'ruleset_fingerprint') else original.position.ruleset_fingerprint,feature_dimension=len(vectors[0]),same_features=True,same_root_legal_actions=len(root_actions[0]),capture=record_value(capture),reply=record_value(reply),rows=rows,conclusion='Compact Position encoder aliases base identities that change actual captured hand stock and subsequent legal drops. Dynamic zeros isolate this representation; no full evaluator collision/strength claim.')
write_record(p/'base-probe.json',report)
print(json.dumps(report,ensure_ascii=True))
