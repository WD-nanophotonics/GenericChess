"""Recompute descriptive summaries from retained records; no new search or fit.

Sibling-pair counts are dependent observations. Cost ratios use only matched
completed-depth/work controls; capped wall time is not an efficiency gain.
"""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import statistics

p = Path(__file__).parent
def read(name):
    return json.loads((p / (name + '.json')).read_bytes())

labels = read('same-material-signal')
decl = read('same-material-declaration')
ablation = read('signal-ablation')
assert labels['complete'] and ablation['complete']
assert hashlib.sha256((p/'same-material-declaration.json').read_bytes()).hexdigest() == labels['declaration_sha256']
assert hashlib.sha256((p/'same-material-signal.json').read_bytes()).hexdigest() == ablation['labels_sha256']
counts = defaultdict(int)
collisions = defaultdict(int)
for root in ablation['roots']:
    for key, value in root['pair_counts'].items():
        counts[key] += value
    for key, value in root['collisions'].items():
        collisions[key] += value['all_differences']
assert counts['total'] == counts['known'] + counts['unknown']
assert counts['known'] == counts['ties'] + counts['teacher_difference']
assert counts['teacher_difference'] == counts['material_only_difference'] == 229
assert counts['total'] == 1710 and counts['ties'] == 1481 and counts['unknown'] == 0
assert sum(len(r['children']) for r in labels['roots']) == 135
assert all(x['known'] and x['decision']['completed_depth'] == 2 for r in labels['roots'] for x in r['children'])
references = [row for row in read('signal-witnesses')['rows'] if row.get('reference')]
assert len(references) == 6
assert all(row['reference']['complete'] and row['reference']['root_score'] == row['root_score'] for row in references)

caller = read('representation-caller')
assert caller['complete'] and len(caller['calls']) == 80
groups = defaultdict(dict)
for row in caller['calls']:
    groups[row['ply'], row['qdepth'], row['rep']][row['kind']] = row
cost = []
for name in ('sparse', 'coarse', 'relations', 'coarse_relations'):
    for q in (0, 2):
        ratios = []
        complete = capped = depth_loss = mismatched_complete = 0
        leaf_work = []
        for (ply, qdepth, rep), group in groups.items():
            if qdepth != q:
                continue
            a, b = group['baseline'], group[name]
            if b['signature'][2] == 2:
                complete += 1
            else:
                capped += 1
            depth_loss += b['signature'][2] < a['signature'][2]
            if a['signature'][2] == b['signature'][2] == 2:
                same_work = a['signature'] == b['signature']
                mismatched_complete += not same_work
                if same_work:
                    ratios.append(b['seconds']/a['seconds'])
            leaf_work.append(dict(ply=ply, rep=rep, baseline_leaves=a['leaves'], method_leaves=b['leaves'],
                baseline_depth=a['signature'][2], method_depth=b['signature'][2],
                feature_seconds=b['feature_seconds']))
        assert mismatched_complete == 0
        cost.append(dict(kind=name, qdepth=q, calls=8, complete=complete, capped=capped,
            depth_loss_vs_baseline=depth_loss, matched_complete_pairs=len(ratios),
            median_matched_wall_ratio=statistics.median(ratios) if ratios else None,
            per_call=leaf_work))

report = dict(scope=__doc__, producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    signal=dict(roots=[dict(ply=r['ply'],children=len(r['children']),seconds=r['seconds']) for r in labels['roots']],
        pair_counts=dict(counts), input_collisions=dict(collisions),
        independent_full_width_references=len(references)),
    caller_cost=cost,
    boundaries=['No training, fitting, learned-score use or default change.',
        'Same-material D2 teacher compression is not true value or generalization.',
        'Post-label collisions are representational diagnostics, not validation scores.',
        'Position-only encoding omits consequential repetition history.',
        'Baseline material scores and resource conditions are unchanged across cost methods.'])
(p/'evidence-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(signal=report['signal'],caller_cost=[{k:v for k,v in x.items() if k!='per_call'} for x in cost]),indent=2))
