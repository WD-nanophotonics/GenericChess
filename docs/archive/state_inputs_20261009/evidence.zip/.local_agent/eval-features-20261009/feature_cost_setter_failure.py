"""Matched existing-caller representation cost, no learned score or training.
Reuse corrected mixed-custody semantic root. Baseline leaf uses unit current
material; measured feature work is discarded so signatures must remain equal.
Dense width16 random-fixed forward is timing only, never a candidate score.
"""
from pathlib import Path
import sys,time,json,hashlib,runpy
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.learning.features import tactical_interaction_features
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
p=Path(__file__).parent
ns=runpy.run_path(str(p/'semantic_base_probe.py'))
c=ns['c'];states=ns['states'];types=tuple(sorted(c.support.type_metadata));area=len(states[0].position.board)
def identity(position):
 values=np.zeros(2*len(types)*area+2*area)
 ids={t:i for i,t in enumerate(types)}
 for i,piece in enumerate(position.board):
  if piece is not None:
   values[(piece.owner*len(types)+ids[piece.base_type_id])*area+i]=1
   values[2*len(types)*area+piece.owner*area+i]=int(piece.promoted)
 return values
def encode(position,kind):
 if kind=='semantic':return semantic_state_features(position,c,(0,0,0))
 if kind=='identity':return np.concatenate((semantic_state_features(position,c,(0,0,0)),identity(position)))
 if kind=='relations':return np.asarray(tuple(tactical_interaction_features(position,c).values()),dtype=float)
 raise ValueError(kind)
assert not np.array_equal(identity(states[0].position),identity(states[1].position))
assert tactical_interaction_features(states[0].position,c)==tactical_interaction_features(states[1].position,c)
report=dict(scope=__doc__,identity_separates=True,attack_relations_separate=False,feature_dimensions={},extraction=[],calls=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
for kind in ('semantic','identity','relations'):
 x=encode(states[0].position,kind);report['feature_dimensions'][kind]=len(x)
 samples=[]
 for rep in range(3):
  start=time.perf_counter()
  for i in range(200):encode(states[i%2].position,kind)
  samples.append((time.perf_counter()-start)/200)
 report['extraction'].append(dict(kind=kind,seconds_per_call=samples,vector_bytes=x.nbytes,width16_multiplies=len(x)*16))
class Eval:
 def __init__(self,kind):
  self.kind=kind;self.calls=0;self.feature_seconds=0.
  if kind!='baseline':
   d=report['feature_dimensions'][kind];self.w=np.random.default_rng(20261009).normal(0,.01,(16,d));self.b=np.zeros(16)
 def evaluate(self,state):
  self.calls+=1
  if self.kind!='baseline':
   start=time.perf_counter();x=encode(state.position,self.kind);np.tanh(self.w@x+self.b).sum();self.feature_seconds+=time.perf_counter()-start
  value=sum((1 if piece.owner==0 else -1)*1000 for piece in state.position.board if piece and not c.support.type_metadata[piece.current_type_id].is_anchor)
  return value if state.position.side_to_move==0 else -value
 def type_value(self,tid):return 0 if c.support.type_metadata[tid].is_anchor else 1000
 def capture_order_value(self,moving,captured):return self.type_value(captured.current_type_id)*10-self.type_value(moving.current_type_id)//10
from generic_chess.session.session import GameSession
for rep in range(2):
 for owner_state,state in enumerate(states):
  signature=None
  for kind in ('baseline','semantic','identity','relations'):
   s=GameSession(c);s.state=state;ev=Eval(kind)
   player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
   start=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));seconds=time.perf_counter()-start
   assert dec.completed_depth==2 and s.state==state
   sig=(str(dec.action),dec.score,dec.nodes)
   if signature is None:signature=sig
   else:assert sig==signature
   report['calls'].append(dict(rep=rep,state=owner_state,kind=kind,seconds=seconds,feature_seconds=ev.feature_seconds,leaf_calls=ev.calls,signature=sig,decision=record_value(dec)))
  write_record(p/'feature-cost.json',report)
report['complete']=True;write_record(p/'feature-cost.json',report)
print(json.dumps(dict(dimensions=report['feature_dimensions'],extraction=report['extraction'],calls=[{k:r[k] for k in ('kind','seconds','feature_seconds','leaf_calls','signature')} for r in report['calls']]),ensure_ascii=True))
