"""Summarize the frozen relative-pair caller diagnostic, without new execution."""
from pathlib import Path
from collections import defaultdict
import json,statistics,hashlib
p=Path(__file__).parent;data=json.loads((p/'relative-pair-cost.json').read_bytes())
assert data['complete'] and len(data['calls'])==48
groups=defaultdict(dict)
for row in data['calls']:groups[row['ply'],row['qdepth'],row['rep']][row['kind']]=row
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    source_sha256=hashlib.sha256((p/'relative-pair-cost.json').read_bytes()).hexdigest(),
    dimension=data['dimension'],witness_changed_channels=data['witness_changed_channels'],rows=[])
for kind in ('pairs','sparse'):
    for q in (0,2):
        ratios=[];complete=capped=loss=0;active=[];cost=[]
        for (ply,qdepth,rep),group in groups.items():
            if qdepth!=q:continue
            a,b=group['baseline'],group[kind];da,db=a['decision'],b['decision']
            complete+=db['completed_depth']==2;capped+=db['completed_depth']!=2
            loss+=db['completed_depth']<da['completed_depth'];active.extend(b['active_range'])
            cost.append(b['feature_seconds'])
            if da['completed_depth']==db['completed_depth']==2:
                keys=('action','score','nodes','qnodes','completed_depth','termination_reason')
                assert all(da[key]==db[key] for key in keys)
                ratios.append(b['seconds']/a['seconds'])
        report['rows'].append(dict(kind=kind,qdepth=q,complete=complete,capped=capped,
            depth_loss_vs_baseline=loss,matched_complete_pairs=len(ratios),
            median_matched_wall_ratio=statistics.median(ratios),active_range=[min(active),max(active)],
            total_feature_seconds=sum(cost)))
print(json.dumps(report,indent=2))
(p/'relative-pair-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
