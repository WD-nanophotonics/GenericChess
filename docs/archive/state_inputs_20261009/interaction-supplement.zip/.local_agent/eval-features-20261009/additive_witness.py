"""Independent audit of the first full-Position additive contradiction only.

Four existing children, no new samples/teacher target. RemainingD2 full-width
reference capped at10000leaves/30sec each; preserve failures rather than extend.
Exact four-input sum equality is checked independently from saved pair hashes.
"""
from pathlib import Path
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;capacity=json.loads((p/'additive-capacity.json').read_bytes())
decl=json.loads((p/'same-material-declaration.json').read_bytes());labels=json.loads((p/'same-material-signal.json').read_bytes())
witness=capacity['methods']['new_position']['first_witnesses'][0]
selected=witness['left']+witness['right'];rule=next(r['rules'] for r in json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases'] if r['seed']==202610082102)
c=compile_ruleset_for_execution(ruleset_from_dict(rule));s=GameSession(c);enc=SparsePositionEncoder(c);types=non_anchor_type_ids(c)
rootmap={r['ply']:r for r in decl['roots']};labelmap={r['ply']:r for r in labels['roots']};states={}
for ply in range(13):
    if ply in rootmap:
        for index,item in enumerate(rootmap[ply]['children']):
            if [ply,index] in selected:states[ply,index]=apply_action(s.state,action_from_dict(item['action']),c)
    if ply<len(decl['route']):s.submit(action_from_dict(decl['route'][ply]))
vectors=[enc.dense(states[tuple(i)].position) for i in selected]
assert np.array_equal(vectors[0]+vectors[1],vectors[2]+vectors[3])
rows=[]
for ply,index in selected:
    class Unit:
        def __init__(self):self.calls=0;self.started=time.perf_counter()
        def evaluate(self,state):
            self.calls+=1
            if self.calls>10000 or time.perf_counter()-self.started>30:raise RuntimeError('reference checkpoint')
            return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
    ev=Unit();tick=time.perf_counter();row=dict(ply=ply,index=index,teacher=labelmap[ply]['children'][index]['root_score'])
    try:
        score,action=reference_minimax(states[ply,index],2,ev,c)
        row.update(complete=True,reference=-score,action=record_value(action))
        assert row['teacher']==row['reference']
    except Exception as exc:row.update(complete=False,failure=dict(kind=type(exc).__name__,message=str(exc)))
    row.update(leaves=ev.calls,seconds=time.perf_counter()-tick);rows.append(row)
delta=abs(sum(r['teacher'] for r in rows[:2])-sum(r['teacher'] for r in rows[2:]))
assert delta==2000
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    witness=witness,exact_equal_input_sums=True,reference_rows=rows,
    maximum_absolute_error_lower_bound_for_exact_additive_family=delta/4,
    scope_limit='A finite exposed four-state additive constraint, not ranking failure, generalization, necessity of a neural net or a requirement to fit teacher values exactly.')
write_record(p/'additive-witness.json',report)
print(json.dumps(report,indent=2))
