"""Post-label additive-capacity diagnostic on the same frozen135children.

No fitted parameters, new labels or samples. For an additive linear prediction
with bias, equal input sums x[a]+x[b]=x[c]+x[d] require equal target sums. Find
violations if present; absence is inconclusive (other dependencies may exist).
All targets use root owner0, identical remainingD2 teacher; history omission
remains explicit. This is not held-out accuracy or a requirement of exact fit.
Use integer-valued channels exactly after checking integrality; no hash tolerance.
"""
from pathlib import Path
import sys,json,itertools,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import spatial_occupancy_features,tactical_interaction_features
from generic_chess.learning.nonlinear import semantic_state_features
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent
decl=json.loads((p/'same-material-declaration.json').read_bytes())
labels=json.loads((p/'same-material-signal.json').read_bytes())
rule=next(r['rules'] for r in json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases'] if r['seed']==202610082102)
c=compile_ruleset_for_execution(ruleset_from_dict(rule));s=GameSession(c);enc=SparsePositionEncoder(c)
labelmap={r['ply']:r for r in labels['roots']};rootmap={r['ply']:r for r in decl['roots']}
inputs={name:[] for name in ('old_position','new_position','coarse3x3','relations')};targets=[];ids=[]
tick=time.perf_counter()
for ply in range(13):
    if ply in rootmap:
        assert s.state.position.side_to_move==0
        for i,item in enumerate(rootmap[ply]['children']):
            child=apply_action(s.state,action_from_dict(item['action']),c)
            target=labelmap[ply]['children'][i]
            assert target['known'] and target['target_kind']=='finite-material-search'
            values=dict(old_position=semantic_state_features(child.position,c,(0,0,0)),
                new_position=enc.dense(child.position),
                coarse3x3=[v for cells in spatial_occupancy_features(child.position,tuple(decl['types'])).values() for v in cells],
                relations=list(tactical_interaction_features(child.position,c).values()))
            for name,x in values.items():
                a=np.asarray(x)
                assert np.all(a==np.rint(a)) and np.max(np.abs(a),initial=0)<100
                inputs[name].append(a.astype(np.int16))
            targets.append(target['root_score']);ids.append([ply,i])
    if ply<len(decl['route']):s.submit(action_from_dict(decl['route'][ply]))
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    declaration_sha256=hashlib.sha256((p/'same-material-declaration.json').read_bytes()).hexdigest(),methods={})
for name,rows in inputs.items():
    seen={};pairs=collisions=violations=0;witnesses=[]
    # Include repeated-index pairs, so an input collision also supplies a witness.
    for a,b in itertools.combinations_with_replacement(range(len(rows)),2):
        key=(rows[a]+rows[b]).tobytes();score=targets[a]+targets[b];pairs+=1
        if key in seen:
            collisions+=1;u,v,old_score=seen[key]
            if score!=old_score:
                violations+=1
                if len(witnesses)<3:witnesses.append(dict(left=[ids[u],ids[v]],right=[ids[a],ids[b]],
                    target_sums=[old_score,score]))
        else:seen[key]=(a,b,score)
    report['methods'][name]=dict(dimension=len(rows[0]),pairs=pairs,equal_input_sum_revisits=collisions,
        unequal_target_sum_revisits=violations,first_witnesses=witnesses)
report['seconds']=time.perf_counter()-tick
write_record(p/'additive-capacity.json',report)
print(json.dumps(report,indent=2))
