"""Scoped mechanical relative-piece-pair input and actual caller cost.

No chess-specific table, fitted coefficients or new teacher labels. All ordered
distinct actor pairs, owner/current-type and full signed square displacement;
integer histogram, translation pooled. It omits base/promotion/hand/aux/history
and rule descriptors: a cheap interaction comparator, not a replacement complete
input. Test the retained four-state additive witness; then four frozen roots,
D2/2048nodes/3sec q0/q2(hard8), two balanced repetitions baseline/pairs/sparse.
Same unit evaluation returned; feature outputs discarded. No capped extension.
Expected incremental ceiling144sec of caller budget, plus small extraction work.
"""
from pathlib import Path
import sys,json,time,hashlib,itertools
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent
assert not (p/'relative-pair-cost.json').exists()
decl=json.loads((p/'same-material-declaration.json').read_bytes())
rule=next(r['rules'] for r in json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases'] if r['seed']==202610082102)
c=compile_ruleset_for_execution(ruleset_from_dict(rule));enc=SparsePositionEncoder(c)
types=tuple(sorted(c.support.type_metadata));ids={tid:i for i,tid in enumerate(types)}
nt=2*len(types);width=c.board_shape.width;height=c.board_shape.height
dxn=2*width-1;dyn=2*height-1;dimension=nt*nt*dxn*dyn
def encode(pos):
    actors=[(square%width,square//width,piece.owner*len(types)+ids[piece.current_type_id])
            for square,piece in enumerate(pos.board) if piece]
    a=np.asarray(actors,dtype=np.intp)
    dx=a[None,:,0]-a[:,None,0]+width-1
    dy=a[None,:,1]-a[:,None,1]+height-1
    index=(((a[:,None,2]*nt+a[None,:,2])*dxn+dx)*dyn+dy)
    mask=~np.eye(len(actors),dtype=bool)
    return np.unique(index[mask],return_counts=True)
def oracle(pos):
    counts={};actors=[(square,piece) for square,piece in enumerate(pos.board) if piece]
    for (sa,a),(sb,b) in itertools.permutations(actors,2):
        dx=sb%width-sa%width+width-1;dy=sb//width-sa//width+height-1
        key=(((a.owner*len(types)+ids[a.current_type_id])*nt+b.owner*len(types)+ids[b.current_type_id])*dxn+dx)*dyn+dy
        counts[key]=counts.get(key,0)+1
    return counts
s=GameSession(c);rootmap={r['ply']:r for r in decl['roots']};roots=[];children={}
selected=json.loads((p/'additive-witness.json').read_bytes())['witness']
for ply in range(13):
    if ply in rootmap:
        roots.append((ply,s.state,s._search_history_witnesses))
        for index,item in enumerate(rootmap[ply]['children']):
            if [ply,index] in selected['left']+selected['right']:
                child=apply_action(s.state,action_from_dict(item['action']),c)
                ix,v=encode(child.position);assert dict(zip(ix.tolist(),v.tolist()))==oracle(child.position)
                x=np.zeros(dimension,dtype=np.int16);x[ix]=v;children[ply,index]=x
    if ply<len(decl['route']):s.submit(action_from_dict(decl['route'][ply]))
left=sum((children[tuple(i)] for i in selected['left']))
right=sum((children[tuple(i)] for i in selected['right']))
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    dimension=dimension,additive_witness_pair_sums_equal=bool(np.array_equal(left,right)),
    witness_changed_channels=int(np.count_nonzero(left!=right)),oracle_checked_states=len(children),calls=[],complete=False)
rng=np.random.default_rng(20261009);weights=rng.normal(0,.01,dimension);sw=rng.normal(0,.01,(16,enc.dimension))
class Eval:
    def __init__(self,kind):self.kind=kind;self.calls=0;self.seconds=0.;self.active=[]
    def evaluate(self,state):
        self.calls+=1
        if self.kind!='baseline':
            tick=time.perf_counter()
            if self.kind=='pairs':
                ix,v=encode(state.position);weights[ix]@v
            else:
                ix,v=enc.encode(state.position);np.tanh(sw[:,ix]@v).sum()
            self.active.append(len(ix));self.seconds+=time.perf_counter()-tick
        return 1000*sum(material_features(state.position,non_anchor_type_ids(c),perspective=state.position.side_to_move).array())
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
for ply,state,witnesses in roots:
    session=GameSession(c);session._state=state;session._search_history_witnesses=witnesses
    for q in (0,2):
        for rep in range(2):
            for kind in (('baseline','pairs','sparse') if rep==0 else ('sparse','pairs','baseline')):
                assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
                ev=Eval(kind);player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_ordering=False,
                    use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
                tick=time.perf_counter();decision=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=3,
                    quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
                assert session.state==state
                report['calls'].append(dict(ply=ply,qdepth=q,rep=rep,kind=kind,seconds=time.perf_counter()-tick,
                    feature_seconds=ev.seconds,leaves=ev.calls,active_range=[min(ev.active,default=0),max(ev.active,default=0)],
                    decision=record_value(decision)))
                write_record(p/'relative-pair-cost.json',report)
            print(ply,q,rep,[(r['kind'],round(r['seconds'],3),r['decision']['completed_depth']) for r in report['calls'][-3:]],flush=True)
report['complete']=True;write_record(p/'relative-pair-cost.json',report)
