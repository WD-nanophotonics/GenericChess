"""Common-board intervention: does a Position-only vector encode rule behavior?

Four retained complete generated8 rules, initial board copied from seed2102;
all other rule mechanisms retained. Compile each intervention independently,
use its own correctly fingerprint-bound encoder and actual initial GameState.
Freeze all four legal root sets/input hashes before any teacher call. RootD2q0
unit material,2048nodes/2sec, no TT/order/native/disk/root tactical shortcut.
No training, forced shared weights, label fitting or cross-rule success claim.
"""
from pathlib import Path
from dataclasses import replace
import sys, json, hashlib, time
import numpy as np
sys.path.insert(0, str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict, ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from generic_chess.learning.features import material_features, non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record, record_value

p=Path(__file__).parent
assert not (p/'cross-rule-input.json').exists()
src=Path('.local_agent/generated8-20261008/transfer.json')
old=json.loads(src.read_bytes())['cases']
board=ruleset_from_dict(next(row for row in old if row['seed']==202610082102)['rules']).initial_position
roots=[]; declaration=[]
for row in old:
    rule=replace(ruleset_from_dict(row['rules']), initial_position=board)
    c=compile_ruleset_for_execution(rule); s=GameSession(c); encoder=SparsePositionEncoder(c)
    x=encoder.dense(s.state.position)
    actions=[action_to_dict(a) for a in s.legal_actions()]
    declaration.append(dict(seed=row['seed'], rules=ruleset_to_dict(rule),
        fingerprint=c.ruleset_fingerprint, state=record_value(s.state), dimension=len(x),
        features_sha256=hashlib.sha256(x.tobytes()).hexdigest(), types=encoder.types,
        root_legal=actions, legal_sha256=hashlib.sha256(json.dumps(actions,sort_keys=True).encode()).hexdigest()))
    roots.append((c,s,x))
write_record(p/'cross-rule-declaration.json',dict(scope=__doc__,
    producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(), roots=declaration))
report=dict(scope=__doc__,declaration_sha256=hashlib.sha256((p/'cross-rule-declaration.json').read_bytes()).hexdigest(),
    equal_inputs=all(np.array_equal(roots[0][2],r[2]) for r in roots), roots=[], complete=False)
for declared,(c,s,x) in zip(declaration,roots):
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
    types=non_anchor_type_ids(c)
    class Unit:
        def evaluate(self,state):
            return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
        def capture_order_value(self,moving,captured):
            return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
    player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,
        use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
    before=s.state; tick=time.perf_counter()
    decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=2,
        quiescence_max_depth=0,quiescence_hard_max_depth=0))
    assert s.state==before
    report['roots'].append(dict(seed=declared['seed'],legal_count=len(declared['root_legal']),
        decision=record_value(decision), seconds=time.perf_counter()-tick))
    write_record(p/'cross-rule-input.json',report)
report['complete']=True
write_record(p/'cross-rule-input.json',report)
print(json.dumps(dict(equal_inputs=report['equal_inputs'],
    distinct_input_hashes=len({r['features_sha256'] for r in declaration}),
    distinct_legal_sets=len({r['legal_sha256'] for r in declaration}),
    results=[dict(seed=r['seed'],legal_count=r['legal_count'],depth=r['decision']['completed_depth'],
        score=r['decision']['score'],reason=r['decision']['termination_reason'],seconds=r['seconds']) for r in report['roots']]),indent=2))
