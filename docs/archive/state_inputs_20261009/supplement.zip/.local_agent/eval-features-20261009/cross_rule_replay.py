"""Audit common-board intervention PVs without creating new teacher labels.

Only replay the already returned actual legal objects. Terminal-derived root
differences remain separate from the nonterminal same-material signal batch.
"""
from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from scripts.research_record import record_value,write_record
p=Path(__file__).parent
declaration=json.loads((p/'cross-rule-declaration.json').read_bytes())
labels=json.loads((p/'cross-rule-input.json').read_bytes())
rows=[]
for root,answer in zip(declaration['roots'],labels['roots']):
    assert root['seed']==answer['seed']
    c=compile_ruleset_for_execution(ruleset_from_dict(root['rules']));s=GameSession(c)
    row=dict(seed=root['seed'],initial_terminal=record_value(s.state.terminal_status),pv=[])
    rows.append(row)
    for stored in answer['decision']['principal_variation']:
        action=next(a for a in s.legal_actions() if record_value(a)==stored)
        before=s.state; s.submit(action)
        removed=[]
        for i,piece in enumerate(before.position.board):
            after=s.state.position.board[i]
            if piece and piece.owner!=before.position.side_to_move and after!=piece:
                removed.append(dict(square=i,piece=record_value(piece),anchor=c.support.type_metadata[piece.current_type_id].is_anchor))
        row['pv'].append(dict(action=action_to_dict(action),removed=removed,
            material=record_value(material_features(s.state.position,non_anchor_type_ids(c),perspective=0)),
            terminal=record_value(s.state.terminal_status)))
    row['reported_score']=answer['decision']['score']
    row['terminal_derived']=s.state.terminal_status.is_terminal
assert labels['equal_inputs'] and len({r['features_sha256'] for r in declaration['roots']})==1
assert sum(row['terminal_derived'] for row in rows)==2
write_record(p/'cross-rule-replay.json',dict(scope=__doc__,
    producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,
    conclusion='Equal Position vectors do not encode rules. Two changed-rule roots are trivial terminal diagnostics; this is not a playable-rule success or proof a search leaf network must encode every rule. Compiled per-rule weights or explicit rule-conditioned inputs are distinct possible designs; fingerprint guards alone supply neither.'))
print(json.dumps(rows,indent=2))
