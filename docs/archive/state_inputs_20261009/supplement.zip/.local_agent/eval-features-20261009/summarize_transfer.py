"""Recompute transfer cost summaries; complete roots only in ratio medians.

Within each root average two order-balanced repetitions, then median the
root-level ratio. Never treat equal capped elapsed time as equal searched work.
"""
from pathlib import Path
import json,statistics,hashlib
p=Path(__file__).parent
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),runs={})
for filename in ('prototype-transfer.json','prototype-transfer-q2.json'):
    data=json.loads((p/filename).read_bytes()); assert data['complete']
    rows=[]; calls=[]
    for root in data['cases']:
        group={kind:[r for r in root['calls'] if r['kind']==kind] for kind in ('baseline','dense','sparse')}
        complete=all(r['decision']['completed_depth']==2 for r in root['calls'])
        base=statistics.mean(r['seconds'] for r in group['baseline'])
        ratios={kind:statistics.mean(r['seconds'] for r in group[kind])/base for kind in ('dense','sparse')}
        if complete:
            signature=root['calls'][0]['signature']
            assert all(r['signature']==signature for r in root['calls'])
            assert len({r['decision']['qnodes'] for r in root['calls']})==1
        rows.append(dict(name=root['name'],dimension=root['dimension'],active=root['active_range'],
            complete=complete,baseline_seconds=base,ratios=ratios))
        calls.extend(root['calls'])
    report['runs'][filename]=dict(rows=rows,calls=len(calls),
        complete_calls=sum(r['decision']['completed_depth']==2 for r in calls),
        capped_calls=sum(r['decision']['completed_depth']!=2 for r in calls),
        complete_root_medians={kind:statistics.median(r['ratios'][kind] for r in rows if r['complete']) for kind in ('dense','sparse')})
print(json.dumps(report,indent=2))
(p/'transfer-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
