import sys,json,hashlib,zipfile,tempfile,platform
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();summary=json.loads((p/'summary.json').read_bytes());assert summary['complete'];assert summary['producer_sha256']==sha(p/'summarize.py')
for name,h in summary['inputs'].items():assert sha(p/(name+'.json'))==h
dest=root/'docs/archive/qsemantics_20261008';dest.mkdir(parents=True,exist_ok=True);archive=dest/'sources-raw.zip';assert not archive.exists()
files=sorted(x for x in p.iterdir() if x.suffix in ('.py','.json'))
files += [root/f for f in ('tests/ai_fixtures.py','tests/conftest.py','tests/rule_semantics_ir_fixtures.py','tests/product/test_generic_pass_action.py','tests/product/test_qsearch_correctness.py','tests/product/test_runtime_check_reuse.py','generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/search.py','scripts/research_record.py','scripts/unfamiliar_search.py','.local_agent/generated6-20261008/coverage.json','.local_agent/generated8-20261008/transfer.json','.local_agent/pvs-transfer-20261008/transfer.json')]
members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();z.writestr(name,f.read_bytes());members.append({'path':name,'bytes':f.stat().st_size,'sha256':sha(f)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for m in members:assert sha(Path(tmp)/m['path'])==m['sha256']
index={'base_commit':'ad0a34208d46ca8d097aa03d791aeff26cd9768f','archive_sha256':sha(archive),'extracted_rehashed':True,'members':members,'native_binary_pins':[{'path':f.relative_to(root).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in (root/'generic_chess').glob('_native_core*.pyd')],'python':platform.python_version(),'exclude':'User/private inputs, raw Slack/account records, credentials and active workflow/memo/session state. Native binary pins are metadata, prior Native recovery archive supplies source/build evidence.'}
write_record(dest/'index.json',index)
write_record(root/'docs/research/data/qsemantics_20261008.json',{'complete':True,'scope':summary['scope'],'archive':'../../archive/qsemantics_20261008/index.json','archive_sha256':index['archive_sha256'],'analysis':summary})
print(json.dumps({'members':len(members),'archive_bytes':archive.stat().st_size,'sha256':index['archive_sha256']},indent=2))
