"""Finite behavior-equivalent promotion/effect noise-classification witness."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import _semantic_ruleset,_king_type
from generic_chess.rules.schema import RuleSemanticAction,RuleGeometrySpec,RuleActionEffect,RuleSquareRef,RuleTypeRef,RuleInvariant,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.transition import legal_successors
from generic_chess.core.actions import action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.quiescence import classify_noisy
from generic_chess.ai.alphabeta.search import INF,_Budget,_Context,quiescence,_runtime_noisy_actions
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'promotion-balanced.json';assert not out.exists();started=time.perf_counter();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'product_hashes':{f:sha(root/f) for f in ('generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/quiescence.py')},'declaration':'Predeclared balanced-type control: add ownB(2,0) and second effect transforms that B to A while moving A becomes B. Owner/current-type inventory conserved despite changed actual capabilities at squares; checks whether inventory can be complete transformation detector. Not a proposal to include all such tactics. Rest of original witness declaration follows. New observed-interface question: qclassifications trust public promotion metadata but semantic set_current_type can produce the same transformed actor without that field. Predeclared4x4 K(0,0),k(3,3),owner0A(1,0),A forwardleap,Borthogonalrays; same empty-target forward semantic move with set_current_type B. Compare promotion_mode none versus explicit B (redundant same final transform); all other rules/piece metadata unchanged. Also combined definition checks exact same physical child within one fingerprint, not arbitrary history quotient. Frozen generic profile/evaluator dynamic terms0; q1/hard8 with mutable/immutable callers, no WDL/strength claim or price fitting. <=1000successors/30sec, preserve compile/runtime failures.','variants':[]};write_record(out,r)
try:
 A=PieceType('A','A',(LeapAtom((0,1)),));B=PieceType('B','B',tuple(RayAtom(x) for x in ((1,0),(-1,0),(0,1),(0,-1))));board=[None]*16;board[0]=Piece(0,'K','K');board[15]=Piece(1,'K','K');board[1]=Piece(0,'A','A');board[2]=Piece(0,'B','B');rows=tuple(tuple(board[i:i+4]) for i in range(0,16,4))
 action=RuleSemanticAction(name='same_transform',type_ids=('A',),geometry=RuleGeometrySpec(kind='leap',offset=(0,1)),target_relation='empty',composition='augment',effects=(RuleActionEffect('move',from_ref=RuleSquareRef(kind='source'),to_ref=RuleSquareRef(kind='target')),RuleActionEffect('set_current_type',square_ref=RuleSquareRef(kind='target'),type_ref=RuleTypeRef(kind='explicit',type_id='B')),RuleActionEffect('set_current_type',square_ref=RuleSquareRef(kind='fixed',square=(2,0)),type_ref=RuleTypeRef(kind='explicit',type_id='A'))),invariants=(RuleInvariant('own_anchor_safe'),))
 explicit=replace(action,name='same_transform_explicit',promotion_mode='explicit',explicit_promotion_type='B')
 for label,actions in (('effect',(action,)),('explicit',(explicit,)),('combined',(action,explicit))):
  assert time.perf_counter()-started<30
  definition=_semantic_ruleset((_king_type(),A,B),actions,n=4,rows=rows);c=compile_ruleset_for_execution(definition);s=GameSession(c);cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profile=build_ruleset_profile(c,cfg);ev=Evaluator(c,profile,cfg);pairs=legal_successors(s.state,c);transforms=[(a,x) for a,x in pairs if getattr(a,'pattern_id','').startswith('sem_')];row={'label':label,'rules':ruleset_to_dict(definition),'prices':dict(profile.board_value_by_type),'stand_pat':ev.evaluate(s.state),'transformations':[],'q':[]};r['variants'].append(row)
  for a,child in transforms:
   stats=SearchStatistics();noisy=classify_noisy(s.state,[(a,child)],c,stats)
   row['transformations'].append({'action':action_to_dict(a),'child':record_value(child.position),'terminal':record_value(child.terminal_status),'noisy':bool(noisy),'child_owner0_material':-ev.evaluate(child),'stats':record_value(stats)})
  if label=='combined':assert len(transforms)==2 and transforms[0][1].position==transforms[1][1].position
  for mutable in (False,True):
   limits=SearchLimits(max_nodes=4096,max_time_seconds=5,quiescence_max_depth=1,quiescence_hard_max_depth=8);stats=SearchStatistics();ctx=_Context(c,ev,TranspositionTable(),stats,_Budget(limits,None),SearchTuning(),True,True,1,8,None,runtime=SearchPathRuntime(s.state,c) if mutable else None);value=quiescence(s.state,-INF,INF,0,0,ctx);row['q'].append({'mutable':mutable,'value':value,'qnodes':stats.qnodes})
   if mutable:ctx.runtime.assert_balanced()
  write_record(out,r)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
print([(v['label'],v['prices'],v['stand_pat'],[x['noisy'] for x in v['transformations']],v['q']) for v in r['variants']])
