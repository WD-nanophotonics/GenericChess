import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'capture-only.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
sources=[root/'.local_agent/pvs-transfer-20261008/transfer.json',root/'.local_agent/generated8-20261008/transfer.json'];cases=[json.loads(f.read_bytes())['cases'][0] for f in sources];started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_hashes':{f.relative_to(root).as_posix():sha(f) for f in sources},'search_source_sha256':sha(root/'generic_chess/ai/alphabeta/search.py'),'declaration':'Two already exposed roots2200/2100, first q4same-depth success and first hard-check failure. Existing ordered-qsearch on, PVSoff/Native attack+legality/TT/order/root-scanoff fixed. Change existing capture-only flag alone: omit quiet checking actions outside check, all captures/promotions/terminal actions and mandatory evasions remain. D2/8192totalnodes/20sec/q4hard8,2rotated cold repeats8calls<=180sec. Question whether quiet-check omission removes cost/hard-check bottleneck and changes completed scores; this changes q semantics, not a correctness-preserving optimization or strength/default claim. Original failures retained. No extra horizon/fees/workers or price tuning.','cases':[]};write_record(out,r)
try:
 for old in cases:
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':old['seed'],'searches':[]};r['cases'].append(case)
  for repeat in (0,1):
   for capture_only in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-started<180 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    observed=[]
    def stats():
     value=SearchStatistics();observed.append(value);return value
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True,use_capture_only_qsearch=capture_only));t=time.perf_counter()
    with patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=20,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    wall=time.perf_counter()-t;validate_pv(s,d);case['searches'].append({'capture_only':capture_only,'repeat':repeat,'seconds':wall,'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','native_legality_calls')}});write_record(out,r)
    assert d.native_legality_fallbacks==0 and observed[0].runtime_depth_balanced
  print(old['seed'],[(x['capture_only'],x['decision']['completed_depth'],x['decision']['score'],x['decision']['termination_reason'],x['runtime_work']['runtime_pushes'],round(x['seconds'],3)) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
