"""Predeclared fresh generated callers for the cost-only product change."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.attacks import is_in_check
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'fresh-reuse.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'fixture_sha256':sha(root/'tests/rule_semantics_ir_fixtures.py'),'product_hashes':{str(f):sha(root/f) for f in ('generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/search.py')},'declaration':'Four fresh fixed seeds202610082300..2303,8x8bilateral_random/hybrid, existing filter and prior declared mechanical recombination(Pdrop/temp_right eq0 guard,quietX->P).16ply coverage policy semanticboard>guardedPdrop>capture>other lexical ties, retain all compile/terminal/zero outcomes. New cost-only product current-child check reuse versus same product fresh Core query, not capture-only/single-push/PVS. D2/4096totalnodes/20sec/q2hard8/default lexical q, Native attack+legality,TT/order/root-scanoff.2rotatedcoldrepeats16calls<=360sec. Same completed-depth score must agree; exact signatures/work when both terminate by fixed nodes/depth/hard bound, partial wall work may differ. Full Core PV replay all calls; node/wall/hard failures retained. No new default, price or strength selection. Stop checks, one process.','cases':[]};write_record(out,r)
original=SearchPathRuntime.in_check
def fresh(runtime,owner,checkpoint=None):
 engine=semantic_engine_for(runtime.compiled)
 return engine.in_check(runtime.position,owner,checkpoint=checkpoint) if engine else is_in_check(runtime.position,owner,runtime.compiled)
fixtures=weird_rulesets();base_drop=fixtures[1].semantic_actions[0];base_quiet=fixtures[2].semantic_actions[0]
signature=lambda d:tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
try:
 for seed in range(202610082300,202610082304):
  assert time.perf_counter()-started<360 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  generated=generate_game(GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True))
  drop=replace(base_drop,type_ids=('P',),replace_selector=replace(base_drop.replace_selector,type_ids=('P',)),slot_guards=(RuleSlotGuard(slot_name='temp_right',value=0),));effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id='P')) if e.kind=='set_current_type' else e for e in base_quiet.effects);quiet=replace(base_quiet,type_ids=('X',),target_relation='empty',effects=effects);definition=replace(generated.ruleset,semantic_actions=(drop,quiet));case={'seed':seed,'rules':ruleset_to_dict(definition),'route':[],'searches':[]};r['cases'].append(case);write_record(out,r)
  try:c=compile_ruleset_for_execution(definition)
  except Exception as exc:case['compile_failure']=repr(exc);write_record(out,r);continue
  s=GameSession(c)
  for ply in range(16):
   if s.state.terminal_status.is_terminal:break
   actions=s.legal_actions()
   if not actions:break
   def priority(a):
    d=action_to_dict(a);occupant=s.state.position.board[a.to_square.rank*8+a.to_square.file] if hasattr(a,'to_square') else None;capture=occupant is not None and occupant.owner!=s.state.position.side_to_move
    return (0 if d.get('pattern_id','').startswith('sem_01_') else 1 if d.get('pattern_id','').startswith('sem_00_') else 2 if capture else 3,json.dumps(d,sort_keys=True))
   action=min(actions,key=priority);s.submit(action);case['route'].append({'action':action_to_dict(action),'terminal':record_value(s.state.terminal_status),'hands':record_value(s.state.position.hands),'aux':record_value(s.state.position.aux_state)})
  case['terminal']=record_value(s.state.terminal_status);case['frontier_ply']=s.state.ply_count
  if s.state.terminal_status.is_terminal:write_record(out,r);continue
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  for repeat in (0,1):
   for reuse in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-started<360 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];observed=[]
    def stats():
     z=SearchStatistics();observed.append(z);return z
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter()
    with patch.object(SearchPathRuntime,'in_check',original if reuse else fresh),patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=20,quiescence_max_depth=2,quiescence_hard_max_depth=8))
    elapsed=time.perf_counter()-t;validate_pv(s,d);assert d.native_legality_fallbacks==0;case['searches'].append({'reuse':reuse,'repeat':repeat,'seconds':elapsed,'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','native_legality_calls')}});write_record(out,r)
  case['exact_signatures_equal']=len({signature(x['decision']) for x in case['searches']})==1
  if not any(x['decision']['termination_reason']=='time_limit' for x in case['searches']):assert case['exact_signatures_equal']
  by_depth={}
  for x in case['searches']:
   z=x['decision'];by_depth.setdefault(z['completed_depth'],set()).add(z['score'])
  assert all(len(v)==1 for k,v in by_depth.items() if k>0)
  print(seed,[(x['reuse'],x['decision']['completed_depth'],x['decision']['termination_reason'],round(x['seconds'],3)) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
