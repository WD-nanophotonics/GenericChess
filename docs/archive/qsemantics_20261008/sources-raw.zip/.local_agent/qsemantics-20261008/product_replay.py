import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.attacks import is_in_check
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'product-replay.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();start=time.perf_counter()
a=json.loads((root/'.local_agent/pvs-transfer-20261008/transfer.json').read_bytes());b=json.loads((root/'.local_agent/generated8-20261008/transfer.json').read_bytes());olds=[a['cases'][0],b['cases'][0],a['cases'][2]]
r={'complete':False,'producer_sha256':sha(Path(__file__)),'product_hashes':{str(f):sha(root/f) for f in ('generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/search.py')},'declaration':'Actual new product method, not dynamic source clone. Three preselected mechanism roots2200/2100/2202 (completed/hard-check/prior-wallcap). Compare cached-current-child answer versus same product method patched to original Core query; all support/order unchanged. D2/8192totalnodes/40sec/q4hard8,2rotatedcoldrepeats12calls<=240sec. Separate fair continuation for2202 original20sec cap, not restoring holdout or changing old record. Compare exact fixed-node signatures/runtime work and all stop causes; local cost only.','cases':[]};write_record(out,r)
original=SearchPathRuntime.in_check
def fresh(runtime,owner,checkpoint=None):
 engine=semantic_engine_for(runtime.compiled)
 return engine.in_check(runtime.position,owner,checkpoint=checkpoint) if engine is not None else is_in_check(runtime.position,owner,runtime.compiled)
signature=lambda d:tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
try:
 for old in olds:
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':old['seed'],'searches':[]};r['cases'].append(case)
  for repeat in (0,1):
   for reuse in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-start<240 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];observed=[]
    def stats():
     z=SearchStatistics();observed.append(z);return z
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True));t=time.perf_counter()
    with patch.object(SearchPathRuntime,'in_check',original if reuse else fresh),patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=40,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    seconds=time.perf_counter()-t;validate_pv(s,d);case['searches'].append({'reuse':reuse,'repeat':repeat,'seconds':seconds,'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','native_legality_calls')}});write_record(out,r)
  case['all_signatures_equal']=len({signature(x['decision']) for x in case['searches']})==1;assert case['all_signatures_equal'];assert all(x['runtime_work']==case['searches'][0]['runtime_work'] for x in case['searches'])
  print(old['seed'],[(x['reuse'],x['decision']['completed_depth'],x['decision']['score'],x['decision']['termination_reason'],round(x['seconds'],3)) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
