"""Development source clone: classify and search a quiet q action in one push."""
import sys,json,time,hashlib,inspect
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict,action_is_board,action_promotion_target_id,action_target_square,action_is_drop
from generic_chess.core.coordinates import square_to_index
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'single-push.json';assert not out.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
old='''    for action in ordered:
        if ctx.tuning.use_ordered_qsearch and not _runtime_noisy_actions(ctx, (action,)):
            continue
        with runtime.pushed(action, checkpoint=ctx.checkpoint):
            score = -_quiescence_runtime(-beta, -alpha, ply + 1, qdepth + 1, ctx)
'''
new='''    parent_enemies = enemy_board_count(state.position, side)
    for action in ordered:
        direct_kind = None
        if ctx.tuning.use_ordered_qsearch and action_is_board(action):
            occupant = state.position.board[square_to_index(action_target_square(action), state.position.board_size())]
            if action_promotion_target_id(action) is not None:
                direct_kind = "promotion"
            elif occupant is not None and occupant.owner != side:
                direct_kind = "capture"
        with runtime.pushed(action, checkpoint=ctx.checkpoint):
            if ctx.tuning.use_ordered_qsearch:
                if direct_kind == "promotion":
                    ctx.stats.promotion_qactions += 1
                elif direct_kind == "capture" or enemy_board_count(runtime.position, side) < parent_enemies:
                    ctx.stats.capture_qactions += 1
                elif runtime.terminal_status.is_terminal:
                    pass
                elif ctx.tuning.use_capture_only_qsearch:
                    continue
                elif runtime.in_check(1 - side, checkpoint=ctx.checkpoint):
                    if action_is_drop(action):
                        ctx.stats.checking_drop_qactions += 1
                    else:
                        ctx.stats.checking_move_qactions += 1
                else:
                    if action_is_drop(action):
                        ctx.stats.nonchecking_drop_excluded += 1
                    continue
            score = -_quiescence_runtime(-beta, -alpha, ply + 1, qdepth + 1, ctx)
'''
source=inspect.getsource(search._quiescence_runtime);assert source.count(old)==1
namespace=dict(search.__dict__);namespace['square_to_index']=square_to_index
exec(source.replace(old,new),namespace);prototype=namespace['_quiescence_runtime']
# Recursive calls must use the clone, too; this namespace is deliberately local.
namespace['_quiescence_runtime']=prototype
inputs=[root/'.local_agent/pvs-transfer-20261008/transfer.json',root/'.local_agent/generated8-20261008/transfer.json']
cases=[json.loads(inputs[0].read_bytes())['cases'][0],json.loads(inputs[1].read_bytes())['cases'][0]]
started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'search_source_sha256':sha(root/'generic_chess/ai/alphabeta/search.py'),'runtime_source_sha256':sha(root/'generic_chess/core/search_runtime.py'),'inputs':{str(x.relative_to(root)):sha(x) for x in inputs},'declaration':'Observed selected quiet q actions are pushed once to classify and again to recurse. Local source clone only, product current-child check reuse fixed in both. Two exposed roots2200/2100 D2/8192nodes/40sec/q4hard8/orderedq,2rotatedcoldrepeats8calls<=180sec. Classify within the recursive push, preserving captures/promotions/terminals/quiet checks/all evasions and counters. Compare exact completed signatures plus all qclassification counters and actual pushes. Local cost development, no default or price change; small gains may not justify a second product edit.','cases':[]};write_record(out,r)
signature=lambda d:tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
try:
 for prior in cases:
  c=compile_ruleset_for_execution(ruleset_from_dict(prior['rules']));s=GameSession(c)
  for step in prior['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');row={'seed':prior['seed'],'searches':[]};r['cases'].append(row)
  for repeat in (0,1):
   for single in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-started<180 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    observed=[]
    def stats():
     z=SearchStatistics();observed.append(z);return z
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True));t=time.perf_counter()
    with patch.object(search,'_quiescence_runtime',prototype if single else search._quiescence_runtime),patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):
     d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=40,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    elapsed=time.perf_counter()-t;validate_pv(s,d)
    row['searches'].append({'single':single,'repeat':repeat,'seconds':elapsed,'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced')},'qclasses':{k:getattr(observed[0],k) for k in ('promotion_qactions','capture_qactions','checking_drop_qactions','checking_move_qactions','nonchecking_drop_excluded','in_check_qnodes')}});write_record(out,r)
  row['signatures_equal']=len({signature(x['decision']) for x in row['searches']})==1;assert row['signatures_equal'];assert all(x['qclasses']==row['searches'][0]['qclasses'] for x in row['searches'])
  print(prior['seed'],[(x['single'],x['runtime_work']['runtime_pushes'],round(x['seconds'],3)) for x in row['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
