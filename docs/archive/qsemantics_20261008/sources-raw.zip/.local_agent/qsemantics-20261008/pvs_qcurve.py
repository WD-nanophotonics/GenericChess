"""Existing PVS, changed q2 caller premise and fair paired node curve."""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;src=p/'fresh-reuse.json';prior=json.loads(src.read_bytes());assert prior['complete'];out=p/'pvs-qcurve.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'product_hashes':{str(f):sha(root/f) for f in ('generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/search.py')},'declaration':'Changed premise from old q0PVS: current q2 default lexical search retains node caps on fresh caller cohort even after cost-only check reuse. All four now-exposed2300..2303 roots fixed, no favorable selection. Existing PVS alone versus baseline, actual current product reuse in both;D2/q2hard8,Native attack+legality,TT/order,root-scanoff. Fair4096/8192totalnode20sec curve per method,2rotatedcoldrepeats32calls<=600sec. Question: can main-tree null windows change qtree width enough to completeD2 under the same resource condition, or only move work/failures? Not same-tree cost-only optimization, default/price/strength or unexposed validation. Retain all caps/common completed scores/cold signatures/work and PVS researches. No outcome-driven extension; stop checks, serial interruptible calls.','cases':[]};write_record(out,r)
try:
 for old in prior['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  row={'seed':old['seed'],'searches':[]};r['cases'].append(row);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  for nodes in (4096,8192):
   for repeat in (0,1):
    for pvs in ((False,True) if repeat==0 else (True,False)):
     assert time.perf_counter()-started<600 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];observed=[]
     def stats():
      z=SearchStatistics();observed.append(z);return z
     player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_pvs=pvs));t=time.perf_counter()
     with patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=nodes,max_time_seconds=20,quiescence_max_depth=2,quiescence_hard_max_depth=8))
     elapsed=time.perf_counter()-t;validate_pv(s,d);assert observed[0].runtime_depth_balanced;row['searches'].append({'limit':nodes,'pvs':pvs,'repeat':repeat,'seconds':elapsed,'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced')}});write_record(out,r)
  complete=[x for x in row['searches'] if x['decision']['completed_depth']==2];assert len({x['decision']['score'] for x in complete})<=1
  print(old['seed'],[(x['limit'],x['pvs'],x['decision']['completed_depth'],x['decision']['nodes']+x['decision']['qnodes'],x['decision']['termination_reason'],round(x['seconds'],3)) for x in row['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
