import json,hashlib,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;root=Path.cwd();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
load=lambda name:json.loads((p/(name+'.json')).read_bytes())
names={'capture-only':'capture_only','check-witness':'check_witness','check-witness-v2':'check_witness_v2','check-reuse':'check_reuse','check-reuse-transfer':'check_reuse_transfer','effect-feature':'effect_feature','product-replay':'product_replay','single-push':'single_push','product-default-replay':'product_default_replay','effect-unit-task':'effect_unit_task','hard-depth-curve':'hard_depth_curve','fresh-reuse':'fresh_reuse','existence-bridge':'existence_bridge','existence-bridge-v2':'existence_bridge_v2'}
names.update({'pvs-qcurve':'pvs_qcurve','promotion-encoding':'promotion_encoding','promotion-nochange':'promotion_nochange','promotion-nochange-v2':'promotion_nochange_v2','promotion-nochange-v3':'promotion_nochange_v3','promotion-nochange-v4':'promotion_nochange_v4','promotion-balanced':'promotion_balanced'})
r={'complete':True,'producer_sha256':sha(Path(__file__)),'scope':'Exposed development. Qsupport ablation/witness, exact current-child check reuse, local single-push prototype, finite harddepth curve and context-conditional effect features/unit task. No price/default/strength/holdout promotion.','inputs':{},'source_validation':{},'observations':{}}
for name,producer in names.items():
 d=load(name);assert d['producer_sha256']==sha(p/(producer+'.py'));assert d['complete'] or name in ('check-witness','existence-bridge','promotion-nochange','promotion-nochange-v2','promotion-nochange-v3');r['inputs'][name]=sha(p/(name+'.json'));r['source_validation'][name]={'producer_hash_verified':True,'complete':d['complete'],'seconds':d.get('seconds')}
 if name.startswith('promotion-nochange') and not d['complete']:r['source_validation'][name]['failure']='Initial promoted fixture first lacked promotion targets, then required promotion masks, then used incorrect boolean mask shape. Compiler failures retained; v4 uses valid initial promoted actor and empty promotion pair sets.'
 if name=='check-witness':r['source_validation'][name]['failure']='Reversed SearchPathRuntime constructor arguments after finding witness; original incomplete record and source retained. Corrected v2 is a separate producer/output.'
 if name=='existence-bridge':r['source_validation'][name]['failure']='Local bridge matched a single SemanticEngine instance although engines are recreated per query. Zero calls made this a no-op, deliberately interrupted; not speed/parity evidence. Corrected v2 asserts nonzero calls.'
 for field in ('input_hashes','inputs'):
  for f,h in d.get(field,{}).items():assert sha(root/f)==h

def cases(name,flag):
 out=[]
 for c in load(name)['cases']:
  row={'seed':c['seed'],'methods':[]}
  for mode in (False,True):
   xs=[x for x in c['searches'] if x[flag]==mode]
   row['methods'].append({flag:mode,'seconds':[x['seconds'] for x in xs],'depths':[x['decision']['completed_depth'] for x in xs],'scores':[x['decision']['score'] for x in xs],'nodes':[x['decision']['nodes'] for x in xs],'qnodes':[x['decision']['qnodes'] for x in xs],'pushes':[x['runtime_work']['runtime_pushes'] for x in xs],'termination':[x['decision']['termination_reason'] for x in xs]})
  if 'all_signatures_equal' in c:row['exact_signatures_equal']=c['all_signatures_equal']
  if 'signatures_equal' in c:row['exact_signatures_equal']=c['signatures_equal']
  if 'exact_signatures_equal' in c:row['exact_signatures_equal']=c['exact_signatures_equal']
  out.append(row)
 return out
for name,flag in (('capture-only','capture_only'),('check-reuse','reuse'),('check-reuse-transfer','reuse'),('product-replay','reuse'),('product-default-replay','reuse'),('single-push','single'),('fresh-reuse','reuse')):r['observations'][name]=cases(name,flag)
r['observations']['existence-bridge-v2']=cases('existence-bridge-v2','native')
r['observations']['existence_oracle']=[{'seed':c['seed'],'calls':[x['existence_calls'] for x in c['searches']]} for c in load('existence-bridge-v2')['oracle']]
r['observations']['pvs_qcurve']=[]
for c in load('pvs-qcurve')['cases']:
 row={'seed':c['seed'],'cells':[]}
 for limit in (4096,8192):
  for mode in (False,True):
   xs=[x for x in c['searches'] if x['limit']==limit and x['pvs']==mode]
   signature=lambda x:tuple(json.dumps(x['decision'][k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
   row['cells'].append({'limit':limit,'pvs':mode,'cold_exact_signature_equal':len({signature(x) for x in xs})==1,'depths':[x['decision']['completed_depth'] for x in xs],'scores':[x['decision']['score'] for x in xs],'total_nodes':[x['decision']['nodes']+x['decision']['qnodes'] for x in xs],'pushes':[x['runtime_work']['runtime_pushes'] for x in xs],'seconds':[x['seconds'] for x in xs],'termination':[x['decision']['termination_reason'] for x in xs],'pvs_researches':[x['decision']['pvs_researches'] for x in xs]})
 r['observations']['pvs_qcurve'].append(row)
d=load('promotion-encoding');r['observations']['promotion_encoding']=[{'label':v['label'],'prices':v['prices'],'stand_pat':v['stand_pat'],'q':v['q'],'transforms':[{k:x[k] for k in ('action','terminal','noisy','child_owner0_material')} for x in v['transformations']]} for v in d['variants']]
d=load('promotion-balanced');r['observations']['promotion_balanced']=[{'label':v['label'],'prices':v['prices'],'stand_pat':v['stand_pat'],'q':v['q'],'noisy':[x['noisy'] for x in v['transformations']]} for v in d['variants']]
d=load('promotion-nochange-v4');r['observations']['promotion_nochange']=[{'label':v['label'],'prices':v['prices'],'stand_pat':v['stand_pat'],'q':v['q'],'noisy':[x['noisy'] for x in v['transformations']]} for v in d['variants']]
w=load('check-witness-v2')['witness'];r['observations']['quiet_check_witness']={k:w[k] for k in ('lines','hands','action','all_defenses','defense_count')};r['observations']['quiet_check_witness']['scores']=[{k:x[k] for k in ('runtime','capture_only','score','reason')}|{'qnodes':x['stats']['qnodes']} for x in w['scores']]
for name in ('effect-feature','effect-unit-task'):
 r['observations'][name]=[]
 for c in load(name)['cases']:
  r['observations'][name].append({'seed':c['seed'],'variants':[{k:v for k,v in x.items() if k not in ('rules','groups','profile_X_scope')} for x in c['variants']]})
d=load('hard-depth-curve');r['observations']['hard_depth_curve']=[{k:x[k] for k in ('hard','repeat','seconds','runtime_work')}|{'depth':x['decision']['completed_depth'],'score':x['decision']['score'],'stop':x['decision']['termination_reason'],'nodes':x['decision']['nodes'],'qnodes':x['decision']['qnodes']} for x in d['searches']]
for f in ('generic_chess/ai/alphabeta/search.py','generic_chess/core/search_runtime.py'):
 body=subprocess.run(['git','show','ad0a34208d46ca8d097aa03d791aeff26cd9768f:'+f],check=True,stdout=subprocess.PIPE).stdout
 (p/(Path(f).stem+'-before.py')).write_bytes(body)
r['limits']=['All populations are exposed synthetic contexts, no human prices/holdouts.','Only paired local timing within the same declaration supports execution-cost comparisons; profiling/old-run ratios are not speed evidence.','Wall-capped partial trees need not have equal signatures; compare only completed depths and preserve all caps.','Pass checking responsibility is not actual check; roots/other owners query authoritative Core.','Physical reply law preserves tested equivalent bindings, not arbitrary public/history equivalence.','Conditional unit reward and endpoint vectors are not stock prices; worst replies, loss zeros and terminal branches retained.','Local single-push source clone is not deployed product code.']
write_record(p/'summary.json',r)
print(json.dumps({'sources':r['source_validation'],'curve':r['observations']['hard_depth_curve']},indent=2))
