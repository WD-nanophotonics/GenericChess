"""Exact fixed-context unit reward, separate from endpoint counts or prices."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict,action_to_dict,action_is_board
from generic_chess.core.transition import legal_successors
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=p/'effect-feature.json';coverage=root/'.local_agent/generated6-20261008/coverage.json';out=p/'effect-unit-task.json';assert not out.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();prior=json.loads(src.read_bytes());histories={c['seed']:c for c in json.loads(coverage.read_bytes())['cases']};started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'inputs':{x.relative_to(root).as_posix():sha(x) for x in (src,coverage)},'declaration':'Changed question from endpoint features: at each of the same preselected first6x6transform frontiers2000/2003, can the focal baseX actor remove an ordinary opponent-controlled unit on its next turn? Opponent chooses one actual legal reply; then actor chooses one legal from-focal action or virtual task-stop0. Reward is decrease of opponent ordinary board+hand count over that action, excluding anchors; no material weights, terminal bonus, or reward for mere endpoints. Lost actor and actual early terminal replies stay0 and separately counted. Report uniform distinct physical-reply mean and worst-reply value; not whole-game policy, stock prices or rule-unique context. Compare P/X targets and equivalent duplicate quiet binding, full actual history representatives retained. All predeclared existing replies, no capture-positive filtering, horizons or fits. <=10000eager own successors/90sec; stop checks, partials retained.','cases':[],'actual_eager_own_successors':0}
def count(position,owner,c):
 return sum(x is not None and x.owner==owner and not c.types_by_id[x.current_type_id].is_anchor for x in position.board)+sum(n for tid,n in position.hands[owner] if not c.types_by_id[tid].is_anchor)
def check():
 assert time.perf_counter()-started<90 and r['actual_eager_own_successors']<10000
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
write_record(out,r)
try:
 for old in prior['cases']:
  row={'seed':old['seed'],'variants':[]};r['cases'].append(row);route=histories[old['seed']]['route'];ply=old['event_ply']
  for v in old['variants']:
   check();c=compile_ruleset_for_execution(ruleset_from_dict(v['rules']));s=GameSession(c)
   for step in route[:ply]:s.submit(action_from_dict(step['action']))
   focal=action_from_dict(route[ply-1]['action']).to_square;index=focal.rank*6+focal.file;owner=s.state.position.board[index].owner
   groups={}
   for action,child in legal_successors(s.state,c):groups.setdefault(child.position,[]).append((action,child))
   variant={'target':v['target'],'duplicate':v['duplicate'],'groups':[]};row['variants'].append(variant)
   for pos,aliases in groups.items():
    check();reply,child=aliases[0];piece=pos.board[index];survives=piece is not None and piece.owner==owner and piece.base_type_id=='X';before=count(pos,1-owner,c);options=[]
    if survives and not child.terminal_status.is_terminal:
     successors=legal_successors(child,c);r['actual_eager_own_successors']+=len(successors)
     for action,last in successors:
      if not action_is_board(action) or action.from_square!=focal:continue
      reward=before-count(last.position,1-owner,c)
      options.append({'action':action_to_dict(action),'reward':reward,'terminal':record_value(last.terminal_status)})
    best=max([0]+[o['reward'] for o in options]);variant['groups'].append({'reply':action_to_dict(reply),'aliases':len(aliases),'focal_survives':survives,'reply_terminal':record_value(child.terminal_status),'opponent_control_before':before,'choices':options,'value':best})
   values=[g['value'] for g in variant['groups']];variant['uniform_physical_value']=str(Fraction(sum(values),len(values)));variant['worst_reply_value']=min(values);variant['positive_replies']=sum(x>0 for x in values);variant['lost_replies']=sum(not g['focal_survives'] for g in variant['groups']);variant['terminal_replies']=sum(g['reply_terminal']['status']!='ongoing' for g in variant['groups']);write_record(out,r)
  for target in ('P','X'):
   a,b=[v for v in row['variants'] if v['target']==target]
   assert [g['value'] for g in a['groups']]==[g['value'] for g in b['groups']]
   assert a['uniform_physical_value']==b['uniform_physical_value'] and a['worst_reply_value']==b['worst_reply_value']
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
print([(c['seed'],[(v['target'],v['duplicate'],v['uniform_physical_value'],v['worst_reply_value'],v['lost_replies'],v['terminal_replies']) for v in c['variants']]) for c in r['cases']])
