import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict,RuleTypeRef,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict,action_is_board
from generic_chess.core.transition import legal_successors
from generic_chess.core.movegen import legal_actions
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=root/'.local_agent/generated6-20261008/coverage.json';out=p/'effect-feature.json';assert not out.exists();prior=json.loads(src.read_bytes());started=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration':'Changed question: actual P/X transformation omission is known, not a new bonus. For all first actual6x6X transformations (2000/2003), define conditional next-actor distinct movement/capture endpoint feature under uniform physical opponent successor positions. Compare P/X targets and a behaviorally equivalent duplicate of the quiet semantic action. Action-weighted means are controls; group full physical positions before averaging, retaining terminal/lost actor zeros. This is a context/action-conditional feature, NOT a rule-only material value or blend into frozen preparation coordinates. <=2000eager reply constructions/60sec; no horizon or human fitting.','cases':[]}
def mean(values):return Fraction(sum(values),len(values)) if values else Fraction(0)
try:
 for old in prior['cases']:
  found=next(((i,e) for i,e in enumerate(old['route']) if e['action'].get('pattern_id','').startswith('sem_01_')),None)
  if found is None:continue
  i,event=found;definition=ruleset_from_dict(old['rules']);row={'seed':old['seed'],'event_ply':i+1,'variants':[]};r['cases'].append(row)
  for target in ('P','X'):
   quiet=definition.semantic_actions[1];effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id=target)) if e.kind=='set_current_type' else e for e in quiet.effects);quiet=replace(quiet,effects=effects)
   for duplicate in (False,True):
    actions=(definition.semantic_actions[0],quiet)
    if duplicate:actions=(*actions,replace(quiet,name=quiet.name+'_equivalent_duplicate'))
    changed=replace(definition,semantic_actions=actions);c=compile_ruleset_for_execution(changed);s=GameSession(c)
    for e in old['route'][:i]:s.submit(action_from_dict(e['action']))
    action=action_from_dict(event['action']);s.submit(action);square=action.to_square;index=square.rank*6+square.file;owner=s.state.position.board[index].owner
    profiles,scope=build_semantic_opportunity_profile(c,EvaluationConfig());pairs=legal_successors(s.state,c);groups={}
    assert len(pairs)<=2000
    for reply,child in pairs:
     assert time.perf_counter()-started<60 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
     groups.setdefault(child.position,[]).append((reply,child))
    feature=[]
    for position,aliases in groups.items():
     reply,child=aliases[0];piece=position.board[index];survives=piece is not None and piece.owner==owner and piece.base_type_id=='X'
     moves=[a for a in legal_actions(child,c) if action_is_board(a) and a.from_square==square] if survives and not child.terminal_status.is_terminal else []
     targets={(a.to_square.file,a.to_square.rank) for a in moves};captures={q for q in targets if position.board[q[1]*6+q[0]] is not None and position.board[q[1]*6+q[0]].owner!=owner}
     feature.append({'reply':action_to_dict(reply),'aliases':len(aliases),'actor_survives':survives,'current_type':piece.current_type_id if survives else None,'terminal':record_value(child.terminal_status),'movement_endpoints':sorted(targets),'capture_endpoints':sorted(captures)})
    value={'target':target,'duplicate':duplicate,'rules':ruleset_to_dict(changed),'reply_actions':len(pairs),'physical_successors':len(groups),'profile_X_raw':profiles.piece_profiles['X'].raw_capability_score,'profile_X_value':profiles.board_value_by_type['X'],'profile_X_scope':scope['types']['X'],'physical_movement_mean':str(mean([len(f['movement_endpoints']) for f in feature])),'physical_capture_mean':str(mean([len(f['capture_endpoints']) for f in feature])),'action_movement_mean':str(Fraction(sum(f['aliases']*len(f['movement_endpoints']) for f in feature),len(pairs))) if pairs else '0','action_capture_mean':str(Fraction(sum(f['aliases']*len(f['capture_endpoints']) for f in feature),len(pairs))) if pairs else '0','groups':feature};row['variants'].append(value)
    write_record(out,r)
  for target in ('P','X'):
   a,b=[v for v in row['variants'] if v['target']==target];assert a['physical_movement_mean']==b['physical_movement_mean'] and a['physical_capture_mean']==b['physical_capture_mean']
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
for row in r['cases']:print(row['seed'],[(v['target'],v['duplicate'],v['reply_actions'],v['physical_successors'],v['physical_movement_mean'],v['physical_capture_mean'],v['action_movement_mean']) for v in row['variants']])
