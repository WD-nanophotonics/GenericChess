from pathlib import Path
p=Path(__file__).parent
s=(p/'existence_bridge.py').read_text()
s=s.replace("out=p/'existence-bridge.json'","out=p/'existence-bridge-v2.json'")
s=s.replace('if self is not engine:','if self.semantic is not c:')
s=s.replace("elapsed=time.perf_counter()-t;validate_pv(s,d);row['searches'].append", "elapsed=time.perf_counter()-t;validate_pv(s,d);assert not native or counts['calls']>0;row['searches'].append")
s=s.replace('Observed runtime terminal probes still ask Core', 'Corrected producer: SemanticEngine instances are created per query; match immutable compiled rules, not engine identity. Initial zero-call/interrupted v1 retained, not speed evidence. Runtime terminal probes still ask Core')
(p/'existence_bridge_v2.py').write_bytes(s.encode())
