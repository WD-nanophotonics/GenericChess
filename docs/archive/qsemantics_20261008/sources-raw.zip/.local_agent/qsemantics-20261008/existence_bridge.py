"""Local native existence-query bridge; no product authority or API change."""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.native.semantic import pack_position,transient_legal_actions
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'existence-bridge.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();a=root/'.local_agent/pvs-transfer-20261008/transfer.json';b=root/'.local_agent/generated8-20261008/transfer.json';first=json.loads(a.read_bytes());second=json.loads(b.read_bytes());started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'inputs':{f.relative_to(root).as_posix():sha(f) for f in (a,b)},'product_hashes':{str(f):sha(root/f) for f in ('generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/search.py')},'declaration':'Observed runtime terminal probes still ask Core has_legal_action on each child. New local-only question: is packing current state and checking whether existing Native transient legal list is nonempty faster than Core early-exit, without replacing terminal/history authority? No product hook/flag/API. Generated semantic rules with pass disabled only. Independent oracle stage on2200/2201 D2/1024nodes/20sec/q4hard8 checks EVERY bridged bool against original Core, retaining true/false counts. Then fixed exposed2200/2100 D2/4096nodes/30sec/q4hard8/orderedq,2rotatedcoldrepeats8calls compare Core existence versus Native full-list bool; current-child check reuse fixed,TT/order,Native legal+attack,PVS/root-scanoff. <=240sec singleprocess, stop checks, all caps and exact signatures/work retained. Do not transfer current-state Native terminal status/repetition to Core, and do not conflate full-list with an early-exit native API. Engineering cost matters; regressions can reject this approach.','oracle':[],'cases':[]};write_record(out,r)
def setup(old):
 c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));assert not c.pass_enabled;s=GameSession(c)
 for step in old['route']:s.submit(action_from_dict(step['action']))
 cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider is not None
 return c,s,ev,provider
try:
 for oracle,old in [(True,first['cases'][0]),(True,first['cases'][1]),(False,first['cases'][0]),(False,second['cases'][0])]:
  c,s,ev,provider=setup(old);engine=semantic_engine_for(c);kind=type(engine);original=kind.has_legal_action;counts={'calls':0,'true':0,'false':0};row={'seed':old['seed'],'searches':[]};r['oracle' if oracle else 'cases'].append(row)
  def bridge(self,position,checkpoint=None):
   if self is not engine:return original(self,position,checkpoint=checkpoint)
   if checkpoint is not None:checkpoint()
   answer=bool(transient_legal_actions(provider.native_rules,pack_position(provider.native_rules,provider._state_only_payload(position,0))))
   if checkpoint is not None:checkpoint()
   counts['calls']+=1;counts['true' if answer else 'false']+=1
   if oracle:assert answer==original(self,position,checkpoint=checkpoint)
   return answer
  for repeat in ((0,) if oracle else (0,1)):
   for native in ((True,) if oracle else ((False,True) if repeat==0 else (True,False))):
    assert time.perf_counter()-started<240 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];observed=[];counts={'calls':0,'true':0,'false':0}
    def stats():
     z=SearchStatistics();observed.append(z);return z
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True));t=time.perf_counter()
    with patch.object(kind,'has_legal_action',bridge if native else original),patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=1024 if oracle else 4096,max_time_seconds=20 if oracle else 30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    elapsed=time.perf_counter()-t;validate_pv(s,d);row['searches'].append({'native':native,'repeat':repeat,'seconds':elapsed,'existence_calls':dict(counts),'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced')}});write_record(out,r)
  if not oracle:
   signature=lambda x:tuple(json.dumps(x['decision'][k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation','termination_reason'))
   row['signatures_equal']=len({signature(x) for x in row['searches']})==1;assert row['signatures_equal'];assert all(x['runtime_work']==row['searches'][0]['runtime_work'] for x in row['searches'])
  print(oracle,old['seed'],[(x['native'],x['existence_calls'],round(x['seconds'],3)) for x in row['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
