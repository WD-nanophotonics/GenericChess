import sys,json,time,hashlib,inspect
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta import search
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'check-reuse-transfer.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
sources=[root/'.local_agent/pvs-transfer-20261008/transfer.json'];olds=json.loads(sources[0].read_bytes())['cases'][1:];started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'search_source_sha256':sha(root/'generic_chess/ai/alphabeta/search.py'),'declaration':'Cost-only local prototype: a nonpass runtime push already computes child.side check and stores it in exact generated history. Reuse that answer for qnode/checking-action classification; root/imported history/pass/other-side use original query. No action support/order/price/depth change. Changed premise: seven remaining fixed exposed generated roots2201..2207, D2/8192totalnodes/20sec/q4hard8/orderedq,2rotatedcoldrepeats28calls<=600sec. Independent of PVS/q0 conclusions; test cost-only query reuse and common completed score/parity while retaining all caps. Preserve exact decisions/runtime work and hard abort; measure check reuse only, not capture-only heuristic or default promotion.','input_hashes':{f.relative_to(root).as_posix():sha(f) for f in sources},'cases':[]};write_record(out,r)
hits=[0]
def path_check(ctx,side):
 runtime=ctx.runtime
 if runtime._frames and runtime.history:
  last=runtime.history[-1]
  if (getattr(last.identity,'position',None) is runtime.position and side==runtime.position.side_to_move and json.loads(last.action_signature).get('kind')!='pass'):
   ctx.checkpoint();hits[0]+=1;return last.gave_check
 engine=semantic_engine_for(ctx.compiled)
 return engine.in_check(runtime.position,side,checkpoint=ctx.checkpoint) if engine is not None else search.is_in_check(runtime.position,side,ctx.compiled)
ns=dict(search.__dict__);ns['_path_check']=path_check
qsource=inspect.getsource(search._quiescence_runtime);old='''in_check = (
        engine.in_check(state.position, side, checkpoint=ctx.checkpoint)
        if engine is not None else is_in_check(state.position, side, ctx.compiled)
    )''';assert old in qsource;qsource=qsource.replace(old,'in_check = _path_check(ctx, side)')
nsource=inspect.getsource(search._runtime_noisy_actions);old='''child_in_check = (
                engine.in_check(child.position, 1 - side, checkpoint=ctx.checkpoint)
                if engine is not None else is_in_check(child.position, 1 - side, ctx.compiled)
            )''';assert old in nsource;nsource=nsource.replace(old,'child_in_check = _path_check(ctx, 1 - side)')
exec(nsource,ns);exec(qsource,ns)
try:
 for old in olds:
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':old['seed'],'searches':[]};r['cases'].append(case)
  for repeat in (0,1):
   for reuse in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-started<600 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];observed=[];hits[0]=0
    def stats():
     value=SearchStatistics();observed.append(value);return value
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True));t=time.perf_counter()
    with patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats),patch.object(search,'_runtime_noisy_actions',ns['_runtime_noisy_actions'] if reuse else search._runtime_noisy_actions),patch.object(search,'_quiescence_runtime',ns['_quiescence_runtime'] if reuse else search._quiescence_runtime):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=20,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    wall=time.perf_counter()-t;validate_pv(s,d);case['searches'].append({'reuse':reuse,'repeat':repeat,'seconds':wall,'check_reuses':hits[0],'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','native_legality_calls')}});write_record(out,r)
  print(old['seed'],[(x['reuse'],x['decision']['completed_depth'],x['decision']['score'],x['check_reuses'],round(x['seconds'],3)) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
