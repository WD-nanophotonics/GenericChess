from pathlib import Path
p=Path(__file__).parent
s=(p/'product_replay.py').read_text()
s=s.replace("out=p/'product-replay.json'","out=p/'product-default-replay.json'")
s=s.replace("olds=[a['cases'][0],b['cases'][0],a['cases'][2]]","olds=[a['cases'][0],b['cases'][0]]")
s=s.replace('use_ordered_qsearch=True','use_ordered_qsearch=False').replace('max_nodes=8192','max_nodes=4096')
s=s.replace('Three preselected mechanism roots2200/2100/2202 (completed/hard-check/prior-wallcap).','Two preselected exposed roots2200/2100; default lexical qsearch transfer, not fresh roots.')
s=s.replace('D2/8192totalnodes/40sec/q4hard8,2rotatedcoldrepeats12calls<=240sec. Separate fair continuation for2202 original20sec cap, not restoring holdout or changing old record.','D2/4096totalnodes/40sec/q4hard8,2rotatedcoldrepeats8calls<=240sec; fixed lexical q support/order. Old caps retained.')
(p/'product_default_replay.py').write_bytes(s.encode())
