"""Declared caller depth curve, retaining the original hard8 failure."""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'hard-depth-curve.json';assert not out.exists();src=root/'.local_agent/generated8-20261008/transfer.json';old=json.loads(src.read_bytes())['cases'][0];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'product_hashes':{str(f):sha(root/f) for f in ('generic_chess/core/search_runtime.py','generic_chess/ai/alphabeta/search.py')},'declaration':'Existing2100 hard8 qcheck failure has a nonrepeating nine-position prefix, not an observed loop. Changed decision question: does a finite caller-selected check horizon12/16 complete the intendedD2 or merely expose node/wall growth? Preserve all old failures; no new default or claims of equivalence across harddepths. Existing product query reuse fixed. Single exposed root2100, D2/8192totalnodes/30sec/q4, Native attack+legality,TT/order/orderedq/root-scanoff/PVSoff. Hard8/12/16,2rotatedcoldrepeats6calls<=210sec. Same total-node/wall ceiling for each, no result-driven extension, stop checks; completed common-depth scores and all failure causes/work retained.','seed':old['seed'],'searches':[]};write_record(out,r)
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for step in old['route']:s.submit(action_from_dict(step['action']))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
try:
 for repeat in (0,1):
  for hard in ((8,12,16) if repeat==0 else (16,12,8)):
   assert time.perf_counter()-started<210 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused'];observed=[]
   def stats():
    z=SearchStatistics();observed.append(z);return z
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True));t=time.perf_counter()
   with patch('generic_chess.ai.alphabeta.player.SearchStatistics',stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=hard))
   elapsed=time.perf_counter()-t;validate_pv(s,d);r['searches'].append({'hard':hard,'repeat':repeat,'seconds':elapsed,'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','in_check_qnodes','qdepth_cutoffs','qsearch_check_hard_limit_aborts')}});write_record(out,r)
   print(hard,repeat,d.completed_depth,d.score,d.termination_reason,round(elapsed,3),flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
