import sys,json,time,hashlib
from pathlib import Path
from itertools import permutations
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from ai_fixtures import build_4x4_rooks
from conftest import make_state
from generic_chess.core.transition import legal_successors
from generic_chess.core.attacks import is_in_check
from generic_chess.core.actions import action_to_dict
from generic_chess.ai.alphabeta.search import INF,SearchAborted,_Budget,_Context,quiescence
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'check-witness.json';assert not out.exists();c=build_4x4_rooks();start=time.perf_counter();generated=0
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'declaration':'Diagnostic, not population: lexicographic first400 distinct K0/K1/R0 placements on4x4 with one owner0R in hand, owner0turn, both anchors initially safe. No immediate terminal win; seek first quiet checking move/drop with all defenses and a terminal winning answer. <=150000eager successors/90sec. This asks whether omitting nonterminal quiet checks can discard an actual forced tactical consequence; not playing strength or independent holdout. Synthetic fixture provenance is explicit. Retain visited/capped counts and all defenses of any witness.','attempted':0,'safe_roots':0,'immediate_win_roots':0,'witness':None}
def pairs(state):
 global generated
 if generated>150000 or time.perf_counter()-start>90:raise RuntimeError('declared diagnostic cost checkpoint')
 if json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']:raise RuntimeError('user stop')
 xs=legal_successors(state,c);generated+=len(xs);return xs
try:
 for k0,k1,rook in permutations(range(16),3):
  if r['attempted']>=400:break
  r['attempted']+=1;board=['.']*16;board[k0]='K';board[k1]='k';board[rook]='R';lines=[''.join(board[i:i+4]) for i in (12,8,4,0)];s=make_state(c,lines,hands=([('R',1)],()))
  if any(is_in_check(s.position,side,c) for side in (0,1)):continue
  r['safe_roots']+=1;actions=pairs(s)
  if any(x.terminal_status.is_terminal and x.terminal_status.winner==0 for _,x in actions):r['immediate_win_roots']+=1;continue
  for a,child in actions:
   if child.terminal_status.is_terminal or not is_in_check(child.position,1,c):continue
   if hasattr(a,'from_square') and s.position.board[a.to_square.rank*4+a.to_square.file] is not None:continue
   defenses=pairs(child);coverage=[]
   if not defenses:continue
   for b,next_state in defenses:
    if next_state.terminal_status.is_terminal:break
    wins=[(d,last) for d,last in pairs(next_state) if last.terminal_status.is_terminal and last.terminal_status.winner==0]
    if not wins:break
    d,last=wins[0];coverage.append({'defense':action_to_dict(b),'answer':action_to_dict(d),'terminal':record_value(last.terminal_status)})
   else:
    r['witness']={'lines':lines,'hands':[[['R',1]],[]],'action':action_to_dict(a),'child_check':True,'all_defenses':coverage,'defense_count':len(defenses),'scores':[]}
    cfg=EvaluationConfig();ev=Evaluator(c,build_ruleset_profile(c,cfg),cfg)
    for runtime in (False,True):
     for capture in (False,True):
      stats=SearchStatistics();limits=SearchLimits(max_nodes=8192,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8);ctx=_Context(c,ev,TranspositionTable(),stats,_Budget(limits,None),SearchTuning(use_ordered_qsearch=True,use_capture_only_qsearch=capture),True,True,4,8,None,runtime=SearchPathRuntime(c,s) if runtime else None)
      try:value=quiescence(s,-INF,INF,0,0,ctx);reason='completed'
      except SearchAborted as exc:value=None;reason=str(exc)
      r['witness']['scores'].append({'runtime':runtime,'capture_only':capture,'score':value,'reason':reason,'stats':record_value(stats)})
    break
  if r['witness']:break
 r['complete']=True
except RuntimeError as exc:r['failure']=str(exc)
finally:r['seconds']=time.perf_counter()-start;r['eager_successors_constructed']=generated;write_record(out,r)
print(json.dumps({k:v for k,v in r.items() if k!='witness'}));print(json.dumps(r['witness'],indent=2)[:2000])
