from helpers import *
import contextvars
from generic_chess.core.position import Hands
base_installed=installed
packet=contextvars.ContextVar('private_frontier_hands',default=None)
UNBUILT=object()

def normalize(position):
 for h in position.hands:
  counts=h.counts
  if type(counts) is not tuple or any(type(p) is not tuple or len(p)!=2 or type(p[0]) is not str or type(p[1]) is not int for p in counts):
   return False
 return tuple(Hands(tuple(sorted(dict(h.counts).items()))) for h in position.hands)

@contextlib.contextmanager
def installed(arm):
 if arm!='frontier':
  with base_installed(arm):yield
  return
 original_iter=m.SemanticEngine.iter_legal_action_bindings
 original_init=CAND['_WorkingPosition'].__init__
 original_mutate=CAND['_WorkingPosition'].mutable_hand
 def init(self,position,support):
  current=packet.get()
  if current is None or current[0] is not position:
   return original_init(self,position,support)
  holder=current[1]
  if holder[0] is UNBUILT:holder[0]=normalize(position)
  if holder[0] is False:return original_init(self,position,support)
  self.shape=support.board_shape;self.board=list(position.board)
  self._original_hands=holder[0];self.hands=[None,None]
  self.side=position.side_to_move;self.events=[]
 def mutate(self,owner):
  hand=self.hands[owner]
  if hand is None:hand=self.hands[owner]=dict(self._original_hands[owner].counts)
  return hand
 def frontier(self,position,*args,**kwargs):
  if not kwargs.get('full_frontier',False) or kwargs.get('source') is not None or kwargs.get('target') is not None:
   yield from original_iter(self,position,*args,**kwargs)
   return
  inner=original_iter(self,position,*args,**kwargs);holder=[UNBUILT]
  while True:
   token=packet.set((position,holder))
   try:
    try:item=next(inner)
    except StopIteration:return
   finally:packet.reset(token)
   yield item
 with base_installed('candidate'):
  CAND['_WorkingPosition'].__init__=init
  CAND['_WorkingPosition'].mutable_hand=mutate
  m.SemanticEngine.iter_legal_action_bindings=frontier
  try:yield
  finally:
   CAND['_WorkingPosition'].__init__=original_init
   CAND['_WorkingPosition'].mutable_hand=original_mutate
   m.SemanticEngine.iter_legal_action_bindings=original_iter
