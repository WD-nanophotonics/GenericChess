from helpers import *
import sys,tracemalloc,gc,json
from types import SimpleNamespace
from generic_chess.core.coordinates import BoardShape
from generic_chess.core.position import Position,Hands
from scripts.research_record import write_record
out=D/'memory';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='How much actually traced per-trial Python storage is saved, without assuming a materialized __dict__?',python=sys.version,board=18,objects=2000,hands=['empty','nonempty'],scope='owned initialized working objects only; Python traced memory not whole engine RSS/total native/static/playing evidence. Never inspect __dict__ because doing so can materialize it.'))
rows=[]
for hand in ('empty','nonempty'):
 parent=Position((None,)*324,hands=(Hands(),Hands()) if hand=='empty' else (Hands((("A",2),)),Hands((("B",1),))))
 support=SimpleNamespace(board_shape=BoardShape(18,18))
 for arm in ARMS:
  gc.collect();tracemalloc.start();before=tracemalloc.get_traced_memory()[0]
  with installed(arm):objects=[m._WorkingPosition(parent,support) for _ in range(2000)]
  current,peak=tracemalloc.get_traced_memory();rows.append(dict(arm=arm,hand=hand,count=2000,traced_increment=current-before,traced_peak=peak,object_shallow_bytes=sys.getsizeof(objects[0]),no_dict_materialization=True))
  del objects;tracemalloc.stop()
write_record(out/'rows.json',dict(complete=True,rows=rows));print(rows)
