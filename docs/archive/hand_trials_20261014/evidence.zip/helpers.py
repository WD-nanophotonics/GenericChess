from pathlib import Path
import sys,ast,contextlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import generic_chess.core.semantic_executor as m
D=Path(__file__).resolve().parent
names=('_WorkingPosition','_TrackedWorkingPosition','_apply_effect')
ns=dict(m.__dict__)
tree=ast.parse((D/'semantic_executor_original.py.source').read_text(encoding='utf-8'))
exec(compile(ast.Module(body=[n for n in tree.body if getattr(n,'name',None) in names],type_ignores=[]),'frozen_working_baseline','exec'),ns)
BASE={k:ns[k] for k in names}
cn=dict(m.__dict__)
ct=ast.parse((D/'semantic_executor_candidate_v2.py.source').read_text(encoding='utf-8'))
exec(compile(ast.Module(body=[n for n in ct.body if getattr(n,'name',None) in names],type_ignores=[]),'frozen_hand_candidate_v2','exec'),cn)
CAND={k:cn[k] for k in names}
@contextlib.contextmanager
def installed(arm):
 old={k:getattr(m,k) for k in names}
 try:
  for k,v in ARMS[arm].items():setattr(m,k,v)
  yield
 finally:
  for k,v in old.items():setattr(m,k,v)

def slotted(source):
 tree=ast.parse(source)
 definitions=[n for n in tree.body if getattr(n,'name',None) in names]
 for n in definitions:
  if isinstance(n,ast.ClassDef):
   fields=('written',) if n.name=='_TrackedWorkingPosition' else ('shape','board','hands','side','events') + (('_original_hands',) if '_original_hands' in source else ())
   n.body.insert(1,ast.Assign(targets=[ast.Name(id='__slots__',ctx=ast.Store())],value=ast.Constant(value=fields)))
 module=ast.fix_missing_locations(ast.Module(body=definitions,type_ignores=[]));namespace=dict(m.__dict__)
 exec(compile(module,'private_slots_working','exec'),namespace)
 return {k:namespace[k] for k in names}
SLOTS_BASE=slotted((D/'semantic_executor_original.py.source').read_text(encoding='utf-8'))
SLOTS_CAND=slotted((D/'semantic_executor_candidate_v2.py.source').read_text(encoding='utf-8'))
ARMS={'baseline':BASE,'candidate':CAND,'slots':SLOTS_BASE,'combined':SLOTS_CAND}
