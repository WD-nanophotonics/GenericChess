from frontier import *
from dataclasses import replace
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from generic_chess.core.transition import initial_state
from generic_chess.core.keys import semantic_position_key
from scripts.research_record import write_record
out=D/'frontier-inner';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Compare actual inner S3 trial child rather than external replay; preload Shogi hands to expose first-materialization loss.',games=['western_chess','standard_shogi','xiangqi_diagnostic'],hand_cases=[(),(('R',2),),(('R',2),('P',1)),(('R',2),('P',0),('R',1)),[]],scope='Finite actual complete frontier/trial outputs and full child/hash equality. Private V1 invalid; V2 owner firstdict copies normalized counts. Nonimmutable hand fallback preserved. No universal proof.'))
rows=[];original=m.SemanticEngine._transition
for game in ['western_chess','standard_shogi','xiangqi_diagnostic']:
 c=compile_ruleset_for_execution(build_xiangqi_diagnostic_ruleset() if game=='xiangqi_diagnostic' else build_builtin_ruleset(game));root=initial_state(c).position
 for counts in [(),(('R',2),),(('R',2),('P',1)),(('R',2),('P',0),('R',1)),[]]:
  # Diagnostic Xiangqi has no drops; valid hand inventory still exercises normalization.
  position=replace(root,hands=(Hands(counts),Hands((('P',1),('R',2)))))
  expected=None
  for arm in ['baseline','frontier']:
   observed={}
   def transition(self,parent,action,binding,*args,**kwargs):
    child=original(self,parent,action,binding,*args,**kwargs)
    if parent is position:observed[action]=child
    return child
   m.SemanticEngine._transition=transition
   try:
    with installed(arm):
     engine=m.semantic_engine_for(c);pairs=tuple(engine.iter_legal_action_bindings(position,full_frontier=True))
     actual=tuple((a,observed[a],semantic_position_key(observed[a],engine.support,engine.ir.aux_slots)) for a,b in pairs)
     for a,b in pairs:assert observed[a]==original(engine,position,a,b),(game,counts,arm,a)
   finally:m.SemanticEngine._transition=original
   if expected is None:expected=actual
   else:assert actual==expected,(game,counts,arm)
   rows.append(dict(game=game,hand_counts=counts,arm=arm,actual_inner_children=len(actual),equal_external_replay=True))
  write_record(out/'rows.json',dict(complete=False,rows=rows))
write_record(out/'rows.json',dict(complete=True,rows=rows,paired_child_comparisons=sum(r['actual_inner_children'] for r in rows if r['arm']=='baseline')));print('inner checks',len(rows),sum(r['actual_inner_children'] for r in rows if r['arm']=='baseline'))
