from helpers import *
import json,time,random
from collections import Counter
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
out=D/'counts';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='How many required trials actually avoid empty-hand dictionaries/exports, and do hand-bearing semantics force fallback?',roots=[2016,2017,2018,'western_chess','standard_shogi'],nodes=4096,q=4,hardq=8,depth=12,seconds=32,scope='instrumented counts only; no throughput or strength claim; exact full parent/session restoration; root/prep outside measured trial counts'))
rows=[]
for key in [2026102016,2026102017,2026102018,'western_chess','standard_shogi']:
 p.rr.stopped()
 if isinstance(key,int):
  size={2026102016:12,2026102017:18,2026102018:24}[key]
  g=p.generate_game(p.GeneratorConfig(seed=key,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
  cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support)
 else:c=compile_ruleset_for_execution(build_builtin_ruleset(key))
 s=p.GameSession(c);rng=random.Random((key if isinstance(key,int) else 20261014)+31000)
 for i in range(8):
  acts=sorted(s.legal_actions(),key=repr)
  if not acts or s.result.status.value!='ongoing':raise RuntimeError('declared prefix unavailable')
  s.submit(rng.choice(acts))
 before=(s.state,s.to_record(),s._search_witnesses)
 ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
 player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
 counts=Counter();init=CAND['_WorkingPosition'].__init__;export=CAND['_WorkingPosition'].to_position;mutate=CAND['_WorkingPosition'].mutable_hand
 def observed_init(self,position,support):
  init(self,position,support);self._probe_initial=sum((1<<i) for i,h in enumerate(position.hands) if h.counts);counts['init']+=1;counts['initial_nonempty_mask_'+str(self._probe_initial)]+=1
 def observed_mutate(self,owner):
  counts['mutable_access_'+str(owner)]+=1
  if self.hands[owner] is None:counts['first_empty_materialization']+=1
  return mutate(self,owner)
 def observed_export(self,*args):
  mask=sum((1<<i) for i,h in enumerate(self.hands) if h is not None)
  counts['export']+=1;counts['export_materialized_mask_'+str(mask)]+=1
  counts['avoided_export_hands']+=2-mask.bit_count()
  return export(self,*args)
 CAND['_WorkingPosition'].__init__=observed_init;CAND['_WorkingPosition'].to_position=observed_export;CAND['_WorkingPosition'].mutable_hand=observed_mutate
 try:
  with installed('candidate'):d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=4096,max_time_seconds=32,quiescence_max_depth=4,quiescence_hard_max_depth=8))
 finally:
  CAND['_WorkingPosition'].__init__=init;CAND['_WorkingPosition'].to_position=export;CAND['_WorkingPosition'].mutable_hand=mutate
 assert before==(s.state,s.to_record(),s._search_witnesses)
 rows.append(dict(root=key,counts=dict(counts),decision=record_value(d),full_history_restored=True))
 write_record(out/'rows.json',dict(complete=False,rows=rows));print(key,dict(counts),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))
