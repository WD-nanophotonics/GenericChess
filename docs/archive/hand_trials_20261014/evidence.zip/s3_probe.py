from helpers import *
import random,time,json
from collections import Counter
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
out=D/'next-s3-probe';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Which actual S3 full-frontier safety cases still pay required child attack checks?',seed=2026102017,board_size=18,prefix=8,rng_offset=31000,seconds=16,nodes=None,depth=12,q=4,hardq=8,scope='One actual instrumented Core search, next step begun. Counts not ordinary throughput/profilertime, no positioncache or default change. Source-read hypothesis hand/aux equality is not in unchanged(): actual board proof inspected, no invented blocker.'))
g=p.generate_game(p.GeneratorConfig(seed=2026102017,board_size=18,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support)
s=p.GameSession(c);rng=random.Random(2026102017+31000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
before=(s.state,s.to_record(),s._search_witnesses);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
counts=Counter();old=m._OwnAnchorSafety.unchanged;eligible=m.SemanticEngine._capture_reads_local_board;prepare=m.SemanticEngine._own_anchor_safety;trial=m.SemanticEngine._trial_child_if_s3_legal

def unchanged(self,child,written,support):
 result=old(self,child,written,support);counts['unchanged_calls']+=1;counts['unchanged_yes' if result else 'unchanged_no']+=1
 if not result:
  for square in written:
   prior=self.parent.board[square];new=child.board[square]
   if prior==new:continue
   if square in self.influence:counts['first_reason_influence']+=1;break
   if new is not None and (new.owner!=self.side or getattr(support.type_metadata.get(new.current_type_id),'is_anchor',False)):
    counts['first_reason_new_enemy_or_anchor']+=1;break
   if prior is not None and prior.owner==self.side and getattr(support.type_metadata.get(prior.current_type_id),'is_anchor',False):counts['first_reason_old_anchor']+=1;break
 return result

def eligibility(self):
 result=eligible(self);counts['eligibility_yes' if result else 'eligibility_no']+=1;return result

def preparation(self,*a,**kw):
 result=prepare(self,*a,**kw);counts['prepared' if result is not None else 'declined_prepare']+=1;return result

def trials(self,*a,**kw):
 counts['trial_with_safety' if kw.get('safety') is not None else 'trial_without_safety']+=1
 return trial(self,*a,**kw)
m._OwnAnchorSafety.unchanged=unchanged;m.SemanticEngine._capture_reads_local_board=eligibility;m.SemanticEngine._own_anchor_safety=preparation;m.SemanticEngine._trial_child_if_s3_legal=trials
try:
 with installed('baseline'):
  d=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev).choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=16,quiescence_max_depth=4,quiescence_hard_max_depth=8))
finally:
 m._OwnAnchorSafety.unchanged=old;m.SemanticEngine._capture_reads_local_board=eligible;m.SemanticEngine._own_anchor_safety=prepare;m.SemanticEngine._trial_child_if_s3_legal=trial
assert before==(s.state,s.to_record(),s._search_witnesses)
write_record(out/'rows.json',dict(complete=True,rows=[dict(counts=dict(counts),decision=record_value(d),full_history_restored=True)]));print(dict(counts))
