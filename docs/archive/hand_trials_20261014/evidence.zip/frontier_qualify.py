from frontier import *
import json,random,time
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.keys import semantic_position_key
from dataclasses import replace
from generic_chess.core.position import Hands
out=D/'frontier-qualification';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(games=['western_chess','standard_shogi'],reachable_roots_per_game=24,arms=list(ARMS),quiet_hand_inputs=['empty','canonical','descending','duplicate_zero'],scope='complete frontier/child/positionkey checks across real history with capture-prefer deterministic curriculum. Exposed development, no human labels, not broad proof. Exact freeze before observing.'))
rows=[];start=time.perf_counter()
for game in ['western_chess','standard_shogi']:
 c=compile_ruleset_for_execution(build_builtin_ruleset(game));state=initial_state(c);rng=random.Random(2026101401)
 for depth in range(24):
  expected=None;arms=[]
  for arm in ("baseline","frontier"):
   with installed(arm):
    e=m.semantic_engine_for(c)
    pairs=tuple(e.iter_legal_action_bindings(state.position,full_frontier=True))
    children=tuple((a,e._transition(state.position,a,b)) for a,b in pairs)
    digest=tuple((a,ch,semantic_position_key(ch,e.support,e.ir.aux_slots)) for a,ch in children)
   if expected is None:expected=digest
   else:assert digest==expected,(game,depth,arm)
   arms.append(dict(arm=arm,legal_children=len(children)))
  rows.append(dict(game=game,depth=depth,arms=arms,hands=record_value(state.position.hands)))
  write_record(out/'rows.json',dict(complete=False,rows=rows))
  with installed('baseline'):
   actions=legal_actions(state,c)
   if not actions or state.terminal_status.is_terminal:break
   # Prefer genuine enemy capture when available, otherwise deterministic walk.
   captures=[a for a in actions if getattr(a,'to_square',None) is not None and state.position.board[a.to_square.rank*state.position.board_shape.width+a.to_square.file] is not None and state.position.board[a.to_square.rank*state.position.board_shape.width+a.to_square.file].owner!=state.position.side_to_move]
   action=rng.choice(sorted(captures or actions,key=repr));state=apply_action(state,action,c)
 print(game,len([r for r in rows if r['game']==game]),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start,child_comparisons=sum(r['arms'][0]['legal_children'] for r in rows)))
