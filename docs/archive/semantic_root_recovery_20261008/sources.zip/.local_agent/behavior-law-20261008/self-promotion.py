"""Actual legal self-promotion, not a guessed flag invariant."""
import sys, json
from pathlib import Path
from dataclasses import replace
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror, snapshot_matches
from scripts.research_record import write_record

d = weird_rulesets()[2]
action = d.semantic_actions[0]
# Replace the type-changing effect with explicit promotion back to the same R.
action = replace(action, promotion_mode='explicit', explicit_promotion_type='R',
                 effects=tuple(e for e in action.effects if e.kind != 'set_current_type'))
board = [list(row) for row in d.initial_position]
board[1][0] = Piece(0, 'R', 'R')
c = compile_ruleset_for_execution(replace(d, semantic_actions=(action,),
    initial_position=tuple(map(tuple, board))))
s = GameSession(c)
nr = compile_native_semantic_rules(c)
m = NativeSemanticPositionMirror.from_state(c, nr, s.state, history_certified=True)
a, = [a for a in s.legal_actions() if a.pattern_id.startswith('sem_')
       and (a.to_square.file, a.to_square.rank) == (1,2)]
m.push(a, s.state.position)
s.submit(a)
piece = s.state.position.board[17]
r = dict(action=repr(a), piece=repr(piece), carried_equal=snapshot_matches(
    m.snapshot(), s.state.position, nr, c))
try:
    fresh = NativeSemanticPositionMirror.from_state(c, nr, s.state, history_certified=True)
    r['fresh_equal'] = fresh.snapshot() == m.snapshot()
except ValueError as exc:
    r['fresh_rejection'] = str(exc)
write_record(Path(__file__).with_suffix('.json'), r)
print(json.dumps(r))
