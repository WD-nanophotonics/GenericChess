from pathlib import Path
p=Path(__file__).parent
s=(p/'check-feature-qualified.py').read_text(encoding='utf-8')
s=s.replace('check-feature-qualified.json','check-feature-executed.json')
s=s.replace('replace(definition,piece_types=',
    "replace(definition,drop_allowed={**definition.drop_allowed,'Z':((False,)*64,)*2},piece_types=")
assert not (p/'check-feature-executed.py').exists()
(p/'check-feature-executed.py').write_text(s,encoding='utf-8',newline='\n')
