"""Matched old/new Native module route audit on one frozen actual history."""
import sys, json, time, hashlib, importlib.util
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
mode = sys.argv[1]
out = Path(__file__).with_name('repack-routing-' + mode + '.json')
assert not out.exists()
if mode == 'before':
    binary = Path(__file__).with_name('_native_core.cp312-win_amd64.pyd')
    spec = importlib.util.spec_from_file_location('generic_chess._native_core', binary)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
else:
    binary = ROOT / 'generic_chess/_native_core.cp312-win_amd64.pyd'
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror, snapshot_matches
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record, record_value
from scripts.unfamiliar_search import validate_pv

class Counted:
    def __init__(self, provider):
        self.provider = provider
        self.attempts = self.failures = self.returned = 0
    def __call__(self, *args):
        self.attempts += 1
        try:
            result = self.provider(*args)
        except Exception:
            self.failures += 1
            raise
        self.returned += 1
        return result

parent = ROOT / '.local_agent/paired-context-20261008/combined-qualified.json'
frozen = json.loads(parent.read_bytes())
started = time.perf_counter()
r = dict(complete=False, mode=mode, producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
         parent_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
         declaration='Before/new extension in separate processes; identical current Python sources, one frozen 8-ply actual combined rule history. Direct legal sets/fresh full-state imports at all9 roots; public native-on versus Core-only at plies0/5/8, depths2/3, same static generic-v1 profile/TT/order off, root tactical off,qdepth0,4096nodes/5sec per call. Complete score/action/depth/node comparisons; wrappers count actual provider attempts/returned calls/failures.120sec total cost checkpoint. Development diagnostic, no prices/default tuning or universal speed claim. Mirror event transport corrected in both processes; old C guard remains before module.', roots=[], searches=[])
write_record(out,r)
c = compile_ruleset_for_execution(ruleset_from_dict(frozen['definition']))
nr = compile_native_semantic_rules(c)
s = GameSession(c)
provider = NativeSemanticLegalityProvider.try_create(c)
cache = EvaluationProfileCache(use_disk=False)
config = EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
try:
    for ply in range(9):
        assert time.perf_counter()-started < 120, 'total cost checkpoint'
        row = dict(ply=ply)
        t = time.perf_counter()
        try:
            pairs = provider(s.state.position,s.state.ply_count)
            row.update(provider_accepted=True, legal_count=len(pairs),
                       legal_core_equal=set(a for a,b in pairs)==set(s.legal_actions()))
            assert row['legal_core_equal']
        except ValueError as exc:
            row.update(provider_accepted=False,error=str(exc))
        row['provider_seconds'] = time.perf_counter()-t
        try:
            mirror = NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True)
            snap = mirror.snapshot()
            row.update(fresh_accepted=True, snapshot_matches=snapshot_matches(snap,s.state.position,nr,c),
                       events_exact=snap['history_events_exact'],
                       events_equal=snap['history_events']==tuple((255 if h.actor<0 else h.actor,h.gave_check) for h in s.state.history))
            assert row['snapshot_matches'] and row['events_exact'] and row['events_equal']
        except ValueError as exc:
            row.update(fresh_accepted=False,fresh_error=str(exc))
        r['roots'].append(row)
        if ply in (0,5,8):
            for depth in (2,3):
                for native in (False,True):
                    player = AlphaBetaPlayer(c,evaluation_config=config,profile_cache=cache,
                        use_disk_cache=False,use_tt=False,use_ordering=False,
                        use_native_semantic_legality=native,tuning=SearchTuning(use_root_tactical=False))
                    counted = None
                    if native:
                        counted = Counted(player.native_legality_provider)
                        player._native_legality_provider = counted
                    decision = player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,
                        max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
                    validate_pv(s,decision)
                    r['searches'].append(dict(ply=ply,depth=depth,native=native,decision=record_value(decision),
                        actual_provider=None if counted is None else dict(attempts=counted.attempts,
                        returned=counted.returned,failures=counted.failures)))
                    write_record(out,r)
        write_record(out,r)
        if ply<8:
            a, = [a for a in s.legal_actions() if record_value(a)==frozen['route'][ply]]
            s.submit(a)
    r['complete']=True
finally:
    r['seconds']=time.perf_counter()-started
    write_record(out,r)
print(mode,'accepted',sum(x['provider_accepted'] for x in r['roots']),'/9',
      'searches',len(r['searches']),'seconds',r['seconds'])
