import json, hashlib, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.research_record import write_record
p=Path(__file__).parent
a,b=[json.loads((p/('repack-routing-'+n+'.json')).read_bytes()) for n in ('before','after')]
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       rows=[],old_direct_rejections=[x['ply'] for x in a['roots'] if not x['provider_accepted']],
       new_direct_rejections=[x['ply'] for x in b['roots'] if not x['provider_accepted']])
for old,new in zip(a['searches'],b['searches']):
    assert (old['ply'],old['depth'],old['native'])==(new['ply'],new['depth'],new['native'])
    d,e=old['decision'],new['decision']
    control=next(x for x in b['searches'] if x['ply']==new['ply'] and x['depth']==new['depth'] and not x['native'])['decision']
    fields=('action','score','completed_depth','nodes','qnodes','principal_variation')
    r['rows'].append(dict(ply=new['ply'],depth=new['depth'],native=new['native'],
        before_after_equal={k:d[k]==e[k] for k in fields},
        core_new_equal={k:control[k]==e[k] for k in fields},
        old_route=old['actual_provider'],new_route=new['actual_provider'],
        old_seconds=d['elapsed_seconds'],new_seconds=e['elapsed_seconds']))
write_record(p/'routing-analysis.json',r)
print(json.dumps(r,indent=2))
