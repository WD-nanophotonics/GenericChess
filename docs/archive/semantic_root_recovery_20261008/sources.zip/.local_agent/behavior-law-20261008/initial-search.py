"""Exact public Core/Native search parity at newly admitted cannon starts."""
import sys,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path[:0]=[str(root),str(root/'tests'),str(root/'tests/product')]
from test_semantic_initial_authority import definition
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'initial-search.json';assert not out.exists()
r={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'declaration':'Publicly compiled newly admitted no-screen cannon start, both default and alternate setup. Fixed depth2/2048nodes/5sec/q0, root tactical off, no persistent cache. Compare Core versus Native actual decision signatures; dynamic evaluation unchanged, no price/strength evidence.', 'cases':[]}
for alternate in (False,True):
 c=compile_ruleset_for_execution(definition(alternate=alternate))
 s=GameSession(c,'cannon-start' if alternate else None)
 decisions=[]
 for native in (False,True):
  player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=native,tuning=SearchTuning(use_root_tactical=False))
  d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
  assert d.action in s.legal_actions()
  decisions.append(record_value(d))
 keys=('action','score','completed_depth','nodes','qnodes','principal_variation')
 signature=[{k:x.get(k) for k in keys} for x in decisions]
 assert signature[0]==signature[1],signature
 assert decisions[1]['native_legality_calls']>0
 assert decisions[1]['native_legality_fallbacks']==0
 r['cases'].append({'alternate':alternate,'decisions':decisions,'equal_signature':True})
r['complete']=True;write_record(out,r)
print([(x['alternate'],x['decisions'][1]['native_legality_calls']) for x in r['cases']])
