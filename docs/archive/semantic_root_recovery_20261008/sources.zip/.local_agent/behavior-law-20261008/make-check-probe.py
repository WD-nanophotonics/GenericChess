from pathlib import Path
p=Path(__file__).parent
s=(p/'check-feature.py').read_text(encoding='utf-8')
s=s.replace('import Piece\n','import Piece, PieceType\n')
s=s.replace('import initial_state\n','import initial_state,apply_action\nfrom generic_chess.core.movegen import legal_actions\n')
s=s.replace("out=p/'check-feature.json'","out=p/'check-feature-qualified.json'")
s=s.replace('ownK0,0/C3,3/enemyK3,7, optionally ownCscreen3,5.',
    'ownK0,0/C2,3/enemyK3,7, optionally own immobileZscreen3,5; actual legal Cquiet2,3-to3,3 reaches each comparison root. First direct-root prototype was rejected by legacy initial-anchor check; retained unchanged.')
s=s.replace("board[3][3]=Piece(0,'C','C')","board[3][2]=Piece(0,'C','C')")
s=s.replace("board[5][3]=Piece(0,'C','C')","board[5][3]=Piece(0,'Z','Z')")
s=s.replace("c=compile_ruleset_for_execution(replace(cannon_ruleset(),initial_position=tuple(map(tuple,board))))",
    "definition=cannon_ruleset()\n        c=compile_ruleset_for_execution(replace(definition,piece_types=(*definition.piece_types,PieceType('Z','Z',())),initial_position=tuple(map(tuple,board))))")
s=s.replace('s=initial_state(c);e=semantic_engine_for(c);nr=compile_native_semantic_rules(c)',
    "s=initial_state(c)\n        a,=[a for a in legal_actions(s,c) if a.pattern_id.startswith('sem_') and (a.from_square.file,a.from_square.rank)==(2,3) and (a.to_square.file,a.to_square.rank)==(3,3)]\n        s=apply_action(s,a,c);e=semantic_engine_for(c);nr=compile_native_semantic_rules(c)")
assert not (p/'check-feature-qualified.py').exists()
(p/'check-feature-qualified.py').write_text(s,encoding='utf-8',newline='\n')
