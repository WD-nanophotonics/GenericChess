"""Validate an alternate built module while another process holds the live DLL."""
import sys,importlib.util,runpy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('generic_chess._native_core',p/'_native_core-event-candidate.cp312-win_amd64.pyd')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
sys.argv=[str(p/'check-history.py'),'candidate']
runpy.run_path(str(p/'check-history.py'),run_name='__main__')
import pytest
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider',
    'tests/product/test_native_semantic_repack.py',
    'tests/product/test_native_semantic_position.py',
    'tests/product/test_recombined_semantic_lifecycle.py']))
