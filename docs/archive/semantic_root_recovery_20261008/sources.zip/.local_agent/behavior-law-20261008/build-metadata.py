import sys,json,hashlib,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];p=Path(__file__).parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
r=dict(producer_sha256=sha(Path(__file__)),python=sys.version,
       zig_version=subprocess.run([str(ROOT/'.venv/Lib/site-packages/ziglang/zig.exe'),'version'],capture_output=True,text=True,check=True).stdout.strip(),
       final_binary_sha256=sha(ROOT/'generic_chess/_native_core.cp312-win_amd64.pyd'),
       identity_stage_binary_sha256=sha(p/'_native_core-after-identity.cp312-win_amd64.pyd'),
       baseline_binary_sha256=sha(p/'_native_core.cp312-win_amd64.pyd'),
       sources={x.relative_to(ROOT).as_posix():sha(x) for x in sorted((ROOT/'generic_chess/_native').glob('*')) if x.suffix in ('.c','.h')},
       builder_sha256=sha(ROOT/'scripts/build_native_zig.py'),
       build_scope='O2 installed Zig build, currentCPython312 ABI, Windowsx86_64; binary excluded from Git. Source/ABI/compiler pin does not promise byte-identical builds across environments.',
       qualifications=['First event-guard live build was blocked because the bounded context process held the DLL; one attempted after record and its failing test still used the old identity-stage binary. Preserved as check-history-after-unbuilt.json, not evidence of event fix.',
                       'Alternate output built and tested in an isolated process, then copied to live path only after census exited. final record and1550default regressions use the new module.',
                       'Routing before/after timings use baseline and identity-stage binaries; final history guard is separately tested and does not imply those timing samples used the final binary.'])
(p/'build-metadata.json').write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
