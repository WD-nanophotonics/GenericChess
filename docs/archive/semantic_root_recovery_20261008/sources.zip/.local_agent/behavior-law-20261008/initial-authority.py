"""Public-entry initial validation versus an actually reached semantic root."""
import sys,json,hashlib
from pathlib import Path
from dataclasses import replace
root=Path(__file__).resolve().parents[2];sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import cannon_ruleset
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import RuleInitialSetupOption
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror
from generic_chess.native.semantic import is_square_attacked
from generic_chess.session.session import GameSession
from generic_chess.rules.validation import RuleValidationError
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'initial-authority.json';assert not out.exists()
r={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'declaration':'Two predeclared cannon layouts, optional immobile screen. Reach C3,3 from a validated C2,3 root; compare Core/Native check against public compilation of exactly the reached board, as default or alternate setup. No compiler bypass, validation relaxation or product change. Distinguish safe-layout false rejection from legitimate attacked-layout rejection.', 'cases':[]}
for screen in (False,True):
 board=[[None]*8 for _ in range(8)]
 board[0][0]=Piece(0,'K','K');board[7][3]=Piece(1,'K','K');board[3][2]=Piece(0,'C','C')
 if screen:board[5][3]=Piece(0,'Z','Z')
 d=cannon_ruleset();d=replace(d,piece_types=(*d.piece_types,PieceType('Z','Z',())),drop_allowed={**d.drop_allowed,'Z':((False,)*64,)*2},initial_position=tuple(map(tuple,board)))
 c=compile_ruleset_for_execution(d);s=GameSession(c)
 a,=[a for a in s.legal_actions() if a.pattern_id.startswith('sem_') and (a.from_square.file,a.from_square.rank)==(2,3) and (a.to_square.file,a.to_square.rank)==(3,3)]
 s.submit(a);e=semantic_engine_for(c);nr=compile_native_semantic_rules(c)
 m=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True)
 checks=[e.in_check(s.state.position,owner) for owner in (0,1)]
 assert checks[1]==is_square_attacked(nr,m.position,59,0)==screen
 reached=tuple(tuple(s.state.position.board[rank*8:(rank+1)*8]) for rank in range(8))
 row={'screen':screen,'actual_core_checks':checks,'native_enemy_check':screen,'public_compile':[]}
 for mode in ('default','alternate'):
  target=replace(d,initial_position=reached) if mode=='default' else replace(d,initial_setup_options=(RuleInitialSetupOption('reached',reached),))
  try:
   compile_ruleset_for_execution(target)
   row['public_compile'].append({'mode':mode,'accepted':True})
  except RuleValidationError as exc:
   row['public_compile'].append({'mode':mode,'accepted':False,'error':str(exc)})
 r['cases'].append(row)
r['complete']=True;write_record(out,r)
print(json.dumps(r,indent=2))
