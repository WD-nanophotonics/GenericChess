"""Actual checking cycle: complete events versus digest-only history."""
import sys,json,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,_position_payload
from generic_chess.native.semantic import pack_position,terminal_status,snapshot
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/('check-history-'+sys.argv[1]+'.json');assert not out.exists()
d=weird_rulesets()[2];board=[list(row) for row in d.initial_position];board[6][6]=Piece(0,'R','R')
c=compile_ruleset_for_execution(replace(d,initial_position=tuple(map(tuple,board)),repetition_limit=3,repetition_policy='continuous_check_loss'))
s=GameSession(c);nr=compile_native_semantic_rules(c)
m=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True)
for target in ((7,6),(6,7),(6,6),(7,7))*2:
    a,=[a for a in s.legal_actions() if (a.to_square.file,a.to_square.rank)==target]
    m.push(a,s.state.position);s.submit(a)
fresh=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True)
payload=_position_payload(c,nr,s.state)
payload['history']=tuple(h[:4] for h in payload['history'])
key_only=pack_position(nr,payload)
r=dict(producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       core=dict(status=s.state.terminal_status.status.value,winner=s.state.terminal_status.winner),
       fresh=terminal_status(nr,fresh.position),carried=terminal_status(nr,m.position),
       snapshots_equal=fresh.snapshot()==m.snapshot(),key_only_events_exact=snapshot(nr,key_only)['history_events_exact'])
try:r['key_only_terminal']=terminal_status(nr,key_only)
except ValueError as exc:r['key_only_rejected']=str(exc)
write_record(out,r);print(json.dumps(r))
