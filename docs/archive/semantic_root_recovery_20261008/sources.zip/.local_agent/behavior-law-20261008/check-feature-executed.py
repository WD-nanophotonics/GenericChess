"""Exact cannon check-term counterexample; no evaluator/default change."""
import sys,json,time,hashlib,importlib.util
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from rule_semantics_ir_fixtures import cannon_ruleset
from generic_chess.core.pieces import Piece, PieceType
from generic_chess.core.coordinates import Square
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.attacks import pseudo_attacks
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror
from generic_chess.native.semantic import is_square_attacked
from generic_chess.ai.evaluation.config import EvaluationConfig
import generic_chess.ai.evaluation.evaluator as module
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'check-feature-executed.json';assert not out.exists()
spec=importlib.util.spec_from_file_location('attack_feasibility',p/'attack-probe-carried.py')
probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       declaration='Prospective two declared initial cannon layouts: ownK0,0/C2,3/enemyK3,7, optionally own immobileZscreen3,5; actual legal Cquiet2,3-to3,3 reaches each comparison root. First direct-root prototype was rejected by legacy initial-anchor check; retained unchanged. Compare legacy versus exact compiled-semantic attack maps with Core/Native check authority. Isolate existing anchor term with all material/hand/promotion/mobility weights0 and anchor weight5; only map provider changes in a local monkeypatch restored in finally. Anchor-escape movement remains the legacy approximation, not legal escape validation. No product change/new feature or strength claim. Decision: can full dynamic semantic-price comparisons be interpreted without a static/no-dynamic control?',cases=[])
original=module.pseudo_attacks
try:
    for screen in (False,True):
        board=[[None]*8 for _ in range(8)]
        board[0][0]=Piece(0,'K','K');board[7][3]=Piece(1,'K','K');board[3][2]=Piece(0,'C','C')
        if screen:board[5][3]=Piece(0,'Z','Z')
        definition=cannon_ruleset()
        c=compile_ruleset_for_execution(replace(definition,drop_allowed={**definition.drop_allowed,'Z':((False,)*64,)*2},piece_types=(*definition.piece_types,PieceType('Z','Z',())),initial_position=tuple(map(tuple,board))))
        s=initial_state(c)
        a,=[a for a in legal_actions(s,c) if a.pattern_id.startswith('sem_') and (a.from_square.file,a.from_square.rank)==(2,3) and (a.to_square.file,a.to_square.rank)==(3,3)]
        s=apply_action(s,a,c);e=semantic_engine_for(c);nr=compile_native_semantic_rules(c)
        m=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True)
        maps={owner:probe.bulk(e,s.position,owner) for owner in (0,1)}
        native=is_square_attacked(nr,m.position,59,0);core=e.in_check(s.position,1)
        legacy=Square(3,7) in original(s.position,0,c)
        assert native==core==(59 in maps[0]);assert core!=legacy
        profile=SimpleNamespace(board_value_by_type={t:0 for t in c.types_by_id},
            hand_value_by_base_type={t:0 for t in c.types_by_id},promotion_gain_by_type={})
        evaluator=module.Evaluator(c,profile,EvaluationConfig(dynamic_mobility_weight=0,
            promotion_potential_weight=0,anchor_escape_weight=5))
        module.pseudo_attacks=original;before=evaluator.evaluate(s)
        module.pseudo_attacks=lambda position,owner,compiled: frozenset(Square(i%8,i//8) for i in maps[owner])
        after=evaluator.evaluate(s)
        r['cases'].append(dict(screen=screen,core_check=core,native_check=native,legacy_check=legacy,
            old_anchor_term=before,semantic_map_anchor_term=after,difference=after-before))
    r['complete']=True
finally:
    module.pseudo_attacks=original;write_record(out,r)
print(json.dumps(r['cases']))
