"""Bulk semantic attack feasibility, compared with scalar Core and Native."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from generic_chess.core.semantic_executor import semantic_engine_for,_sources_by_owner_type
from generic_chess.rules.ir import geometry_candidates
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.coordinates import square_to_index
from generic_chess.core.attacks import pseudo_attacks
from generic_chess.core.pieces import Piece
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import is_square_attacked,guarded_actions,public_action,make_checked,snapshot
from scripts.research_record import record_value,write_record
from rule_semantics_ir_fixtures import cannon_ruleset,castling_ruleset,en_passant_ruleset,nifu_ruleset

def bulk(engine,position,owner):
    engine._ensure_match(position); sources=_sources_by_owner_type(position);attacked=set()
    for pattern in engine._patterns:
        if pattern.target.kind!='target_enemy':continue
        for tid in pattern.type_ids:
            for source,piece in sources.get((owner,tid),()):
                for gid in pattern.geometry_ids:
                    geometry=engine.ir.geometry.get(gid)
                    if geometry is None or geometry.kind=='drop':continue
                    if geometry.atom_source is not None and geometry.atom_source[0]!=tid:continue
                    for target,path in geometry_candidates(geometry,str(owner),source):
                        if target in attacked:continue
                        binding=engine._make_binding(pattern,gid,tid,piece,source,target,None,path,position)
                        if engine._path_holds(pattern.path,position,binding,owner) and engine._guards_hold(pattern,position,binding,owner):attacked.add(target)
    return frozenset(attacked)

if __name__=='__main__':
    p=Path(__file__).parent;out=p/'attack-probe-carried.json';assert not out.exists();start=time.perf_counter()
    parent=ROOT/'.local_agent/paired-context-20261008/combined-qualified.json';combined=json.loads(parent.read_bytes())
    shogi_path=ROOT/'.local_agent/transfer-time-20261008/shogi-goal.json';shogi=json.loads(shogi_path.read_bytes())
    r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies={str(x.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(x.read_bytes()).hexdigest() for x in (parent,shogi_path,ROOT/'tests/rule_semantics_ir_fixtures.py',ROOT/'generic_chess/core/semantic_executor.py')},declaration='Initial probe changed board after initial_state and Native correctly rejected its stale history; source/partial preserved. Qualified probe puts synthetic cannon boards into initial rules before compilation, but authentic semantic type changes fail fresh Native pack. This run carries Native state via actual make_checked from initial position, explicitly records every fresh-pack rejection, and does not claim a fix. Prospective feasibility, not evaluator promotion: bulk candidate S0/S1 capture eligibility once, exact compare every square/both owners with authoritative Core scalar attack and independent Native. Roots: two declared cannon screen states, four existing special-rule starts,9actual combined-history roots,3Shogi actual routes andWestern initial+8lexical plies. Legacy pseudo-attacks comparison exposes interface mismatch; semantic eligibility is not full legal mobility, target removal, own-anchor safety or S4 legality. Preserve all differences, timings include Python call overhead. One90sec checkpoint; no persistent position cache, no default/scoring change.',rows=[],seconds_by_method={k:0. for k in ('bulk','core_scalar','native_scalar','legacy')});write_record(out,r)
    cannon=[]
    for screen in (False,True):
        board=[None]*64
        for owner,tid,idx in ((0,'K',0),(1,'K',63),(0,'C',27),(1,'C',30)):
            board[idx]=Piece(owner,tid,tid)
        if screen:board[28]=Piece(0,'C','C')
        cannon.append(('cannon-'+str(screen),replace(cannon_ruleset(),initial_position=tuple(tuple(board[i:i+8]) for i in range(0,64,8))),[]))
    definitions=cannon+[('castling',castling_ruleset(),[]),('en-passant',en_passant_ruleset(),[]),('nifu',nifu_ruleset(),[]),('combined',ruleset_from_dict(combined['definition']),combined['route'])]+[('shogi-'+str(i),ruleset_from_dict(c['definition']),c['route']) for i,c in enumerate(shogi['cases'])]+[('western',build_western_chess_ruleset(),None)]
    try:
        for name,definition,route in definitions:
            c=compile_ruleset_for_execution(definition);e=semantic_engine_for(c);nr=compile_native_semantic_rules(c);s=initial_state(c)
            np=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True).position
            roots=(len(route)+1) if route is not None else 9
            for ply in range(roots):
                assert time.perf_counter()-start<90,'attack feasibility checkpoint'
                position=s.position;assert snapshot_matches(snapshot(nr,np),position,nr,c)
                try:
                    repacked=NativeSemanticPositionMirror.from_state(c,nr,s,history_certified=True).position
                    repack=dict(accepted=True,full_state_equal=snapshot_matches(snapshot(nr,repacked),position,nr,c))
                except ValueError as exc:
                    repack=dict(accepted=False,error=str(exc))
                for owner in (0,1):
                    values={}
                    for method in ('bulk','core_scalar','native_scalar','legacy'):
                        t=time.perf_counter()
                        if method=='bulk':v=bulk(e,position,owner)
                        elif method=='core_scalar':v=frozenset(i for i in range(len(position.board)) if e.is_square_attacked(position,i,owner))
                        elif method=='native_scalar':v=frozenset(i for i in range(len(position.board)) if is_square_attacked(nr,np,i,owner))
                        else:v=frozenset(square_to_index(q,position.board_shape) for q in pseudo_attacks(position,owner,c))
                        r['seconds_by_method'][method]+=time.perf_counter()-t;values[method]=v
                    assert values['bulk']==values['core_scalar']==values['native_scalar'],(name,ply,owner,values)
                    r['rows'].append(dict(name=name,ply=ply,owner=owner,bulk=sorted(values['bulk']),legacy=sorted(values['legacy']),legacy_missing=sorted(values['bulk']-values['legacy']),legacy_extra=sorted(values['legacy']-values['bulk']),equal_core_native=True,repack=repack))
                if ply+1<roots:
                    actions=legal_actions(s,c)
                    a=sorted(actions,key=lambda x:json.dumps(record_value(x),sort_keys=True))[0] if route is None else next(a for a in actions if record_value(a)==route[ply]);na=next(x for x in guarded_actions(nr,np) if public_action(nr,x)==a);np=make_checked(nr,np,na);s=apply_action(s,a,c)
            write_record(out,r)
        r['complete']=True
    finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
    print('owner/root rows',len(r['rows']),'differences',sum(bool(x['legacy_missing'] or x['legacy_extra']) for x in r['rows']),'seconds',r['seconds_by_method'])
