"""Continue only the unqualified selected-event warm-TT cell, preserve failure."""
from pathlib import Path
p=Path(__file__).parent;s=(p/'event_product.py').read_text()
old=s[:s.index('"""',3)+3]
s=s.replace(old,'"""Selected event cancellation/resume continuation after preserved cold-work\nassertion failure. Same limits/inputs, q20/q200 cancellation then warm same-player\nresume. Compare semantic action/score/PV/depth/reason with frozen cold result;\nwarm partial TT legitimately changes node/qnode/push work, retained separately.\nOriginal event-product.json remains incomplete with six persisted calls, no\nclaimed original success. This is development diagnosis, not another timing test.\n"""',1)
s=s.replace("out=p/'event-product.json'","out=p/'event-product-resume.json'")
s=s.replace("selected.append(next(r for r in prior['cases'] if r['seed']==202610082001 and r['ply']==16))","selected=[next(r for r in prior['cases'] if r['seed']==202610082001 and r['ply']==16)]")
s=s.replace("'principal_variation','nodes','qnodes','completed_depth'","'principal_variation','completed_depth'")
s=s.replace("   assert stats[0].runtime_pushes==expected['stats']['runtime_pushes']","   # Warm TT cost differs from frozen cold work; report rather than assert it.")
out=p/'event_product_resume.py';assert not out.exists();out.write_text(s,encoding='utf-8')
