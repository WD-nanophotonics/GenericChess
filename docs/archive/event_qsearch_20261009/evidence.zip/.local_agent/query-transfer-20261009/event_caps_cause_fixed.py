"""Selected node128 cause replay after abort reporting correction.

Only the128node condition executes; original caps output stays intact.
Remaining original declaration below documents the inherited setup, not new cells.

Same D2/Native leaf+legality/TT/order/no root/PVS, six cold calls. Conditions
(128nodes,hard8),(512nodes,hard8),(8192nodes,hard2), ordinaryq2,5sec each.
Declare limits before observation; no cap extension. Compare last-completed
decision/depth/reason/main/qnodes, preserve full state/history/witnesses and
balanced runtime. Different classification pushes expected; no timing claim.
"""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root)]
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'event-caps-cause-fixed.json';assert not out.exists()
old_source=json.loads((p/'event-lexical-pilot.json').read_bytes())['original_source'];ns=dict(search.__dict__);exec(old_source,ns);original=ns['_quiescence_runtime'];product=search._quiescence_runtime
case=next(x for x in json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes())['cases'] if x['seed']==202610082001);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for step in case['route'][:16]:s.submit(action_from_dict(step['action']))
before=(s.state,s.history,s._search_witnesses);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),calls=[]);write_record(out,result)
for nodes,hard in ((128,8),):
 for actual in (False,True):
  player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False));stats=[]
  def make_stats():
   z=SearchStatistics();stats.append(z);return z
  t=time.perf_counter()
  with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats),patch.object(search,'_quiescence_runtime',product if actual else original):
   dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=nodes,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=hard))
  elapsed=time.perf_counter()-t;validate_pv(s,dec)
  assert (s.state,s.history,s._search_witnesses)==before and stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops
  result['calls'].append(dict(nodes=nodes,hard=hard,product=actual,seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0])));write_record(out,result)
  print(nodes,hard,actual,dec.completed_depth,dec.termination_reason,dec.score,dec.nodes,dec.qnodes,stats[0].runtime_pushes,flush=True)
result['complete']=True;write_record(out,result)
