"""Replay only the observed node128 cause correction; leave old caps intact."""
from pathlib import Path
p=Path(__file__).parent;s=(p/'event_caps.py').read_text()
s=s.replace("out=p/'event-caps.json'","out=p/'event-caps-cause-fixed.json'")
s=s.replace('for nodes,hard in ((128,8),(512,8),(8192,2)):','for nodes,hard in ((128,8),):')
s=s.replace('Original/fused lexical q resource-boundary replay on selected guarded root.','Selected node128 cause replay after abort reporting correction.\n\nOnly the128node condition executes; original caps output stays intact.\nRemaining original declaration below documents the inherited setup, not new cells.')
out=p/'event_caps_cause_fixed.py';assert not out.exists();out.write_text(s,encoding='utf-8')
