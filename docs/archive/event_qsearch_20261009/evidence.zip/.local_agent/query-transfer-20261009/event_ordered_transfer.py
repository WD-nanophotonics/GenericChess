"""Complete existing22-event q2 transfer, fixed before this batch.

All active/expired/guarded-drop roots of the frozen four6x6 routes, not new games
or outcome-selected contexts. One cold unordered/ordered pair each; alternate
pair order by sorted frontier index. Native attack/legality, same leaf model,
TT/main ordering, D2/8192nodes/5sec/q2-hard8, no root tactical/PVS. <=44calls,
220sec search plus bounded setup/checks, one writer. Count completeness and
decision agreement; cost on joint completed cells, all caps separately. May
justify a scoped opt-in recommendation, never universal gain/default or Elo.
Stop flags between calls, preserve partial frontier on exception. Existing
q0/factorial and single-event records immutable; no result-driven extension.
"""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root)]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'event-ordered-transfer.json';assert not out.exists()
inp=root/'.local_agent/generated6-20261008/coverage.json';evinp=root/'.local_agent/generated6-20261008/event-frontiers.json'
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputs={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in (inp,evinp)},cases=[]);write_record(out,result)
coverage=json.loads(inp.read_bytes());events=sorted(json.loads(evinp.read_bytes())['cases'],key=lambda x:(x['seed'],x['ply']));assert len(events)==22
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);start=time.perf_counter()
def check():
 assert time.perf_counter()-start<300
 for f in ('rollout.json','advisor.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('user_paused',False) and not d.get('stopped',False)
try:
 for i,event in enumerate(events):
  check();case=next(x for x in coverage['cases'] if x['seed']==event['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
  for step in case['route'][:event['ply']]:s.submit(action_from_dict(step['action']))
  before=(s.state,s.history,s._search_witnesses);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  row=dict(seed=event['seed'],ply=event['ply'],event=event['event'],searches=[]);result['cases'].append(row)
  for ordered in ((False,True) if i%2==0 else (True,False)):
   check();player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=ordered));stats=[]
   def make_stats():
    z=SearchStatistics();stats.append(z);return z
   t=time.perf_counter()
   with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats):
    dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8))
   elapsed=time.perf_counter()-t;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before
   assert stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops and not stats[0].native_legality_fallbacks
   row['searches'].append(dict(ordered=ordered,seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0])));write_record(out,result)
   print(event['seed'],event['ply'],event['event'],ordered,dec.completed_depth,dec.termination_reason,dec.score,stats[0].qnodes,stats[0].runtime_pushes,round(elapsed,3),flush=True)
 result['complete']=True
finally:
 result['seconds']=time.perf_counter()-start;write_record(out,result)
