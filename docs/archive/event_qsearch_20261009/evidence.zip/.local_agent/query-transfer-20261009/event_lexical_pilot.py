"""Lexical on-demand classification pilot, declared before this batch.

All same22 frozen events,44 rotated cold original/prototype calls, both lexical
q order. Same Native leaf/legality,TT/main,D2/8192/5sec/q2-hard8. Prototype only
shares classification/recursion push and stops classification after cutoff;
no new ordering/default yet. Require exact completed score/action/PV/qnodes,
measure work separately. Preserve all caps, <=220sec search plus setup, one
writer. Record exact original/prototype function sources and product hash.
"""
import sys,json,time,hashlib,inspect,textwrap
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root)]
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
original=search._quiescence_runtime
original_source=inspect.getsource(original)
old_block="""    if ctx.tuning.use_ordered_qsearch:
        # Classify on demand so a cutoff avoids probing remaining quiet moves.
        ordered = _order_qactions(state, actions, ply, ctx)
        semantic = semantic_engine_for(ctx.compiled) is not None
        parent_enemies = enemy_board_count(state.position, side)
        parent_inventory = material_inventory(state.position) if semantic else None
    else:
        ordered = sorted(_runtime_noisy_actions(ctx, actions), key=str)"""
new_block="""    # Classify on demand in the chosen order; reuse the child for recursion.
    ordered = _order_qactions(state, actions, ply, ctx)
    semantic = semantic_engine_for(ctx.compiled) is not None
    parent_enemies = enemy_board_count(state.position, side)
    parent_inventory = material_inventory(state.position) if semantic else None"""
assert original_source.count(old_block)==1
prototype_source=original_source.replace(old_block,new_block).replace('if ctx.tuning.use_ordered_qsearch and not semantic else None','if not semantic else None').replace('if ctx.tuning.use_ordered_qsearch and not noisy_child(','if not noisy_child(')
namespace=dict(search.__dict__);exec(prototype_source,namespace);prototype=namespace['_quiescence_runtime']
p=Path(__file__).parent;out=p/'event-lexical-pilot.json';assert not out.exists()
inp=root/'.local_agent/generated6-20261008/coverage.json';evinp=root/'.local_agent/generated6-20261008/event-frontiers.json'
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputs={f.relative_to(root).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in (inp,evinp)},cases=[],original_source=original_source,prototype_source=prototype_source,product_sha256=hashlib.sha256(Path(search.__file__).read_bytes()).hexdigest());write_record(out,result)
coverage=json.loads(inp.read_bytes());events=sorted(json.loads(evinp.read_bytes())['cases'],key=lambda x:(x['seed'],x['ply']));assert len(events)==22
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);start=time.perf_counter()
def check():
 assert time.perf_counter()-start<300
 for f in ('rollout.json','advisor.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('user_paused',False) and not d.get('stopped',False)
try:
 for i,event in enumerate(events):
  check();case=next(x for x in coverage['cases'] if x['seed']==event['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
  for step in case['route'][:event['ply']]:s.submit(action_from_dict(step['action']))
  before=(s.state,s.history,s._search_witnesses);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
  row=dict(seed=event['seed'],ply=event['ply'],event=event['event'],searches=[]);result['cases'].append(row)
  for ordered in ((False,True) if i%2==0 else (True,False)):
   check();player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=False));stats=[]
   def make_stats():
    z=SearchStatistics();stats.append(z);return z
   t=time.perf_counter()
   with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats),patch.object(search,'_quiescence_runtime',prototype if ordered else original):
    dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8))
   elapsed=time.perf_counter()-t;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before
   assert stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops and not stats[0].native_legality_fallbacks
   row['searches'].append(dict(prototype=ordered,seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0])));write_record(out,result)
   print(event['seed'],event['ply'],event['event'],ordered,dec.completed_depth,dec.termination_reason,dec.score,stats[0].qnodes,stats[0].runtime_pushes,round(elapsed,3),flush=True)
 result['complete']=True
finally:
 result['seconds']=time.perf_counter()-start;write_record(out,result)
