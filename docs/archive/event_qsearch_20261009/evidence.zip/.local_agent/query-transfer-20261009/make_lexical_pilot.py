"""Construct a source-explicit lexical fusion pilot; does not edit product."""
from pathlib import Path
p=Path(__file__).parent
s=(p/'event_ordered_transfer.py').read_text()
old=s[s.index('"""'):s.index('"""',3)+3]
s=s.replace(old,'"""Lexical on-demand classification pilot, declared before this batch.\n\nAll same22 frozen events,44 rotated cold original/prototype calls, both lexical\nq order. Same Native leaf/legality,TT/main,D2/8192/5sec/q2-hard8. Prototype only\nshares classification/recursion push and stops classification after cutoff;\nno new ordering/default yet. Require exact completed score/action/PV/qnodes,\nmeasure work separately. Preserve all caps, <=220sec search plus setup, one\nwriter. Record exact original/prototype function sources and product hash.\n"""',1)
s=s.replace("out=p/'event-ordered-transfer.json'","out=p/'event-lexical-pilot.json'")
s=s.replace('import sys,json,time,hashlib','import sys,json,time,hashlib,inspect,textwrap\nimport generic_chess.ai.alphabeta.search as search',1)
# sys.path must be set before package import when executed from the local folder.
s=s.replace('\nimport generic_chess.ai.alphabeta.search as search','')
s=s.replace('root=Path.cwd();sys.path[:0]=[str(root)]','root=Path.cwd();sys.path[:0]=[str(root)]\nimport generic_chess.ai.alphabeta.search as search')
marker="p=Path(__file__).parent;out="
setup='''original=search._quiescence_runtime
original_source=inspect.getsource(original)
old_block="""    if ctx.tuning.use_ordered_qsearch:
        # Classify on demand so a cutoff avoids probing remaining quiet moves.
        ordered = _order_qactions(state, actions, ply, ctx)
        semantic = semantic_engine_for(ctx.compiled) is not None
        parent_enemies = enemy_board_count(state.position, side)
        parent_inventory = material_inventory(state.position) if semantic else None
    else:
        ordered = sorted(_runtime_noisy_actions(ctx, actions), key=str)"""
new_block="""    # Classify on demand in the chosen order; reuse the child for recursion.
    ordered = _order_qactions(state, actions, ply, ctx)
    semantic = semantic_engine_for(ctx.compiled) is not None
    parent_enemies = enemy_board_count(state.position, side)
    parent_inventory = material_inventory(state.position) if semantic else None"""
assert original_source.count(old_block)==1
prototype_source=original_source.replace(old_block,new_block).replace('if ctx.tuning.use_ordered_qsearch and not semantic else None','if not semantic else None').replace('if ctx.tuning.use_ordered_qsearch and not noisy_child(','if not noisy_child(')
namespace=dict(search.__dict__);exec(prototype_source,namespace);prototype=namespace['_quiescence_runtime']
'''
s=s.replace(marker,setup+marker,1)
s=s.replace("cases=[]);write_record(out,result)","cases=[],original_source=original_source,prototype_source=prototype_source,product_sha256=hashlib.sha256(Path(search.__file__).read_bytes()).hexdigest());write_record(out,result)")
s=s.replace('use_ordered_qsearch=ordered','use_ordered_qsearch=False')
s=s.replace("with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats):","with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats),patch.object(search,'_quiescence_runtime',prototype if ordered else original):")
s=s.replace('dict(ordered=ordered,seconds=elapsed','dict(prototype=ordered,seconds=elapsed')
out=p/'event_lexical_pilot.py';assert not out.exists();out.write_text(s,encoding='utf-8')
print(out)
