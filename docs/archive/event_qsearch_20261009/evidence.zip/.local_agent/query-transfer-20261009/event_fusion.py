"""Mechanism control on the already observed event, not a new validation set.

Ordered-q flag selects on-demand classification/push reuse; patch only action
ordering to original lexical order. Two cold calls same priorD2/8192/5sec/q2-hard8
Native/leaf/TT/main settings. Compare decision/qnodes with frozen unordered
calls; identical traversal plus fewer pushes isolates reuse/avoided unused
classification, while ordered versus fused-lexical shows ordering contribution.
No product flag/default; incremental <=10sec search. Timing is descriptive.
"""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root)]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'event-fusion.json';assert not out.exists()
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),calls=[]);write_record(out,result)
inp=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes());case=next(x for x in inp['cases'] if x['seed']==202610082001)
c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for step in case['route'][:16]:s.submit(action_from_dict(step['action']))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');before=s.state
for repeat in range(2):
 player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True));stats=[]
 def make_stats():
  z=SearchStatistics();stats.append(z);return z
 t=time.perf_counter()
 with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats),patch('generic_chess.ai.alphabeta.search._order_qactions',lambda state,actions,ply,ctx:sorted(actions,key=str)):
  dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8))
 elapsed=time.perf_counter()-t;validate_pv(s,dec);assert s.state==before and stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops
 row=dict(repeat=repeat,seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0]));result['calls'].append(row);write_record(out,result)
 print(dec.completed_depth,dec.termination_reason,dec.score,stats[0].qnodes,stats[0].runtime_pushes,flush=True)
result['complete']=True;write_record(out,result)
