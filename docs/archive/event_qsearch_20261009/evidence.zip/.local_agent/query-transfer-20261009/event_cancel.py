"""Cooperative mid-q cancellation on actual guarded-event history.

Four cold public calls: ordered false/true x qnodes20/200, checkpoint at positive
runtime depth cancels the ordinary token then runs the ORIGINAL checkpoint.
No callbacks removed/weakened or second writer. Original5sec/D2/8192/q2-hard8
limits retained. Check full session/history/witnesses and captured runtime
balance after unwind. One uncancelled continuation per order reuses the final
cancelled player's partial TT; retain cap if any, no fabricated complete result.
Incremental <=30sec total bounds, generally cancellation much earlier.
"""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root)]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import _Context
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'event-cancel.json';assert not out.exists()
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),calls=[]);write_record(out,result)
inp=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes());case=next(x for x in inp['cases'] if x['seed']==202610082001)
c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for step in case['route'][:16]:s.submit(action_from_dict(step['action']))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
before=(s.state,s.history,s._search_witnesses);original=_Context.checkpoint
limits=SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8)
for ordered in (False,True):
 for threshold in (20,200):
  player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=ordered));stats=[];token=CancellationToken();hit=[];runtimes=[]
  def make_stats():
   z=SearchStatistics();stats.append(z);return z
  def checkpoint(ctx):
   if ctx.stats.qnodes>=threshold and ctx.runtime.depth>0 and not hit:
    hit.append(dict(qnodes=ctx.stats.qnodes,depth=ctx.runtime.depth,pushes=ctx.stats.runtime_pushes));runtimes.append(ctx.runtime);token.cancel()
   original(ctx)
  t=time.perf_counter()
  with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats),patch.object(_Context,'checkpoint',checkpoint):
   dec=player.choose_action(s,limits,cancel_token=token)
  elapsed=time.perf_counter()-t
  assert hit and dec.termination_reason=='cancelled'
  assert (s.state,s.history,s._search_witnesses)==before
  runtimes[0].assert_balanced();assert runtimes[0].position==s.state.position
  assert stats[0].runtime_pushes==stats[0].runtime_pops and stats[0].runtime_depth_balanced
  assert dec.action in s.legal_actions()
  result['calls'].append(dict(ordered=ordered,cancel_at=hit[0],seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0]),root_session_history_witnesses_restored=True));write_record(out,result)
  print(ordered,threshold,'cancelled',hit[0],stats[0].runtime_pushes,flush=True)
 t=time.perf_counter();dec=player.choose_action(s,limits);elapsed=time.perf_counter()-t;validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before
 result['calls'].append(dict(ordered=ordered,kind='same_player_resume_without_cancel',seconds=elapsed,decision=record_value(dec),root_session_history_witnesses_restored=True));write_record(out,result)
 print(ordered,'resume',dec.completed_depth,dec.termination_reason,dec.score,flush=True)
result['complete']=True;write_record(out,result)
