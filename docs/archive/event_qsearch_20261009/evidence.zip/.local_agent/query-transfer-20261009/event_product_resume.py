"""Selected event cancellation/resume continuation after preserved cold-work
assertion failure. Same limits/inputs, q20/q200 cancellation then warm same-player
resume. Compare semantic action/score/PV/depth/reason with frozen cold result;
warm partial TT legitimately changes node/qnode/push work, retained separately.
Original event-product.json remains incomplete with six persisted calls, no
claimed original success. This is development diagnosis, not another timing test.
"""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root)]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import _Context
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'event-product-resume.json';assert not out.exists()
prior=json.loads((p/'event-lexical-pilot.json').read_bytes());assert prior['complete'];coverage=json.loads((root/'.local_agent/generated6-20261008/coverage.json').read_bytes())
selected=[min((r for r in prior['cases'] if r['seed']==seed),key=lambda r:r['ply']) for seed in sorted({r['seed'] for r in prior['cases']})]
selected=[next(r for r in prior['cases'] if r['seed']==202610082001 and r['ply']==16)]
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),product_sha256=hashlib.sha256((root/'generic_chess/ai/alphabeta/search.py').read_bytes()).hexdigest(),cases=[]);write_record(out,result)
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);limits=SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8);original=_Context.checkpoint
for ref in selected:
 case=next(x for x in coverage['cases'] if x['seed']==ref['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for step in case['route'][:ref['ply']]:s.submit(action_from_dict(step['action']))
 ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');before=(s.state,s.history,s._search_witnesses)
 player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False))
 thresholds=(20,200,None) if ref is selected[-1] else (None,)
 for threshold in thresholds:
  stats=[];hit=[];runtimes=[];token=CancellationToken()
  def make_stats():
   z=SearchStatistics();stats.append(z);return z
  def checkpoint(ctx):
   if threshold is not None and ctx.stats.qnodes>=threshold and ctx.runtime.depth>0 and not hit:
    hit.append(dict(qnodes=ctx.stats.qnodes,depth=ctx.runtime.depth,pushes=ctx.stats.runtime_pushes));runtimes.append(ctx.runtime);token.cancel()
   original(ctx)
  t=time.perf_counter()
  with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats),patch.object(_Context,'checkpoint',checkpoint):
   dec=player.choose_action(s,limits,cancel_token=token if threshold is not None else None)
  elapsed=time.perf_counter()-t;validate_pv(s,dec)
  assert (s.state,s.history,s._search_witnesses)==before
  assert stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops and not stats[0].native_legality_fallbacks
  if threshold is not None:
   assert hit and dec.termination_reason=='cancelled';runtimes[0].assert_balanced();assert runtimes[0].position==s.state.position
  else:
   expected=next(z for z in ref['searches'] if z['prototype'])
   for key in ('action','score','principal_variation','completed_depth','termination_reason'):
    assert record_value(dec)[key]==expected['decision'][key],(key,ref['seed'],ref['ply'])
   # Warm TT cost differs from frozen cold work; report rather than assert it.
  result['cases'].append(dict(seed=ref['seed'],ply=ref['ply'],threshold=threshold,cancel_at=hit,seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0]),root_session_history_witnesses_restored=True));write_record(out,result)
  print(ref['seed'],ref['ply'],threshold,dec.termination_reason,dec.score,stats[0].qnodes,stats[0].runtime_pushes,flush=True)
result['complete']=True;write_record(out,result)
