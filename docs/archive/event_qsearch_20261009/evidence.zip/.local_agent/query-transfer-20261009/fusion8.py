"""Lexical fusion transfer to four existing wide q2 caller roots.

Changed premise: deployed lexical sharing removes work without heuristic change;
6x6 exactness need not transfer to earlier8x8 node/time-limited callers. Reuse
four frozen qsemantics fresh-reuse rules/routes, no new seeds or strength sample.
Two rotated cold original/product pairs each, Native leaf/legality,TT/main order,
PVS/root/ordered-q off, D2/8192nodes/30sec/q2-hard8. All caps/negative results
retained;16calls<=480sec search, bounded250k TT/player, one serial writer.
Exact completed or same-node-stop signatures justify transfer; wall-cap differences
are execution frontiers, not strength. Mismatch without cap requires diagnosis,
not extra budget or changed success criteria. Stop flags between calls. No model
worker, fees, unbounded job, new feature/default order or callback weakening.
"""
import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path[:0]=[str(root)]
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'fusion8.json';assert not out.exists()
src=root/'.local_agent/qsemantics-20261008/fresh-reuse.json';prior=json.loads(src.read_bytes());assert prior['complete'] and len(prior['cases'])==4
old_source=json.loads((p/'event-lexical-pilot.json').read_bytes())['original_source'];ns=dict(search.__dict__);exec(old_source,ns);original=ns['_quiescence_runtime'];product=search._quiescence_runtime
result=dict(complete=False,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),original_source=old_source,product_sha256=hashlib.sha256(Path(search.__file__).read_bytes()).hexdigest(),cases=[]);write_record(out,result)
start=time.perf_counter();cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
def check():
 assert time.perf_counter()-start<600
 for f in ('rollout.json','advisor.json','slack.json'):
  d=json.loads((root/'.local_agent'/f).read_bytes());assert not d.get('user_paused',False) and not d.get('stopped',False)
try:
 for case in prior['cases']:
  check();c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
  for step in case['route']:s.submit(action_from_dict(step['action']))
  before=(s.state,s.history,s._search_witnesses);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');row=dict(seed=case['seed'],searches=[]);result['cases'].append(row)
  for repeat,order in enumerate(((False,True),(True,False))):
   for actual in order:
    check();player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False));stats=[]
    def make_stats():
     z=SearchStatistics();stats.append(z);return z
    t=time.perf_counter()
    with patch('generic_chess.ai.alphabeta.player.SearchStatistics',make_stats),patch.object(search,'_quiescence_runtime',product if actual else original):
     dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=30,quiescence_max_depth=2,quiescence_hard_max_depth=8))
    elapsed=time.perf_counter()-t;validate_pv(s,dec)
    assert (s.state,s.history,s._search_witnesses)==before and stats[0].runtime_depth_balanced and stats[0].runtime_pushes==stats[0].runtime_pops and not stats[0].native_legality_fallbacks
    row['searches'].append(dict(product=actual,repeat=repeat,seconds=elapsed,decision=record_value(dec),stats=record_value(stats[0])));write_record(out,result)
    print(case['seed'],actual,repeat,dec.completed_depth,dec.termination_reason,dec.score,dec.nodes+dec.qnodes,stats[0].runtime_pushes,round(elapsed,3),flush=True)
 result['complete']=True
finally:result['seconds']=time.perf_counter()-start;write_record(out,result)
