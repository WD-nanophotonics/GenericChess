"""Recorded same-full-parent mode comparison: deeper score agreement, no new search."""
from pathlib import Path
from collections import defaultdict,Counter
import json,sys
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/root-window-q4-20261019'
games={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())}
groups=defaultdict(lambda:defaultdict(list));counts=Counter();mismatches=[];action_ties=[];examples=[]
for q in map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()):
 if not q['candidate_turn']or q['used_fallback']or q['completed_depth']<1:continue
 g=games.get(q['slot'])
 if g is None:continue
 key=(g['rule'],q['checkpoint_id'],q['before_sha256'],q['requested_nodes'],q['completed_depth'],q['result_ordinary_qdepth'],q['result_check_hard_qdepth'])
 groups[key][q['root_window_pruning']].append(q)
for key,arms in groups.items():
 if not arms[False]or not arms[True]:continue
 counts['distinct_common_parent_depth_groups']+=1
 pairs=[(a,b)for a in arms[False]for b in arms[True]];counts['linked_observation_pairs']+=len(pairs)
 for a,b in pairs:
  counts['depth_'+str(a['completed_depth'])]+=1
  if a['score']!=b['score']:mismatches.append(dict(key=key,false_slot=a['slot'],true_slot=b['slot'],false_score=a['score'],true_score=b['score'],false_ply=a['relative_ply'],true_ply=b['relative_ply']))
  elif a['returned_action']!=b['returned_action']:action_ties.append(dict(key=key,false_slot=a['slot'],true_slot=b['slot'],equal_score=a['score'],false_action=a['returned_action'],true_action=b['returned_action']))
  if len(examples)<12:examples.append(dict(key=key,false_slot=a['slot'],true_slot=b['slot'],false_nodes=a['nodes'],true_nodes=b['nodes'],same_score=a['score']==b['score'],same_action=a['returned_action']==b['returned_action']))
write_json(D/'common-parent-analysis.json',dict(status='RECORDED_MODE_PARENT_DEPTH_COMPARISON',counts=dict(counts),score_mismatch_count=len(mismatches),score_mismatches=mismatches,equal_score_action_difference_count=len(action_ties),equal_score_action_differences=action_ties,examples=examples,scope='Same fullhistory/statehash/checkpoint/nodecap/completeddepth inrecordedcandidatecalls; repeatedroots/foe/roles arelinked, notindependentobservations. SelectivebackendwithTT0/requestedq4andactualqpolicykey; equalreturnedscore isnot independentoptimality. Equal-scoreactiondifference couldbetie, notdefect; anyscoremismatch needsactualsameparentdiagnosis beforeclaim. No newqueries/games/refill.'))
print('COMMON_PARENT',dict(counts),'scoremismatch',len(mismatches),'actionties',len(action_ties))
