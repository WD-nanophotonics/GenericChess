"""Requested kernel deadlines versus paid kernel/caller observations, no searches."""
from pathlib import Path
from collections import Counter
import json,sys,math
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/root-window-q4-20261019';rows=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()))
def quantile(v,p):
 v=sorted(v);return v[min(len(v)-1,int((len(v)-1)*p))]if v else None
arms={}
for mode in(False,True):
 qq=[q for q in rows if q['candidate_turn']and q['root_window_pruning']==mode];assert qq and all(q['requested_nodes']is None and q['requested_seconds']==.05 for q in qq)
 arms[str(mode)]=dict(queries=len(qq),nodes=sum(q['nodes']for q in qq),causes=dict(Counter(q['cause']for q in qq)),kernel_sum_seconds=sum(q['kernel_seconds']for q in qq),caller_sum_seconds=sum(q['caller_seconds']for q in qq),kernel_quantiles={str(p):quantile([q['kernel_seconds']for q in qq],p)for p in(0,.5,.95,.99,1)},caller_quantiles={str(p):quantile([q['caller_seconds']for q in qq],p)for p in(0,.5,.95,.99,1)},caller_over_50ms=sum(q['caller_seconds']>.05 for q in qq),caller_over_60ms=sum(q['caller_seconds']>.06 for q in qq),kernel_over_60ms=sum(q['kernel_seconds']>.06 for q in qq),returned_qpolicies=dict(Counter(str(q['result_ordinary_qdepth'])for q in qq)),qnodes=sum(q['qnodes']for q in qq),fallbacks=sum(q['used_fallback']for q in qq),uncompleted=sum(q['completed_depth']<1 for q in qq),observed_nodes_per_kernel_second=sum(q['nodes']for q in qq)/sum(q['kernel_seconds']for q in qq))
write_json(D/'deadline-cost.json',dict(status='RECORDED_KERNEL_VS_CALLER_COST',arms=arms,scope='Fullactualcandidatequeries, equalrequested50ms kerneldeadline/no nodecap, notwholeAPIreadyharddeadline orequalactualwork. Includesrealallocation/packing/output/PV cost incaller, concurrentload limitsinterpreted, no exclusion/outliertrimming/failureimputation orNative rerun. max/p95 are descriptive finite observations, no guaranteedbound.'))
print(json.dumps(arms,indent=2))
