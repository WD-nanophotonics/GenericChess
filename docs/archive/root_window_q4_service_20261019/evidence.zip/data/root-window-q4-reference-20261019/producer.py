"""Bounded Core product-search control; no new solver, learner or games."""
from pathlib import Path
from dataclasses import asdict
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;S=D.parent/'root-window-q4-20261019';P=json.loads((D/'plan.json').read_bytes());start=time.monotonic()
gens={x['rule']:x for x in map(json.loads,(S/'generation.jsonl').read_bytes().splitlines())}
roots=[x for x in json.loads((S/'roots.json').read_bytes())['rows']if x['family']==1];assert len(roots)==32
models={x['rule']:x['checkpoint']for x in json.loads((S/'models.json').read_bytes())['rows']if x['label']=='rule_static_v2'}
counts=dict(native_queries=0,native_nodes=0,Core_calls=0,Core_nodes=0,Core_qnodes=0,Core_complete_q4=0);status='COMPLETE';error=None
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.monotonic()-start<P['limits']['global_seconds'],'FROZEN_GLOBAL_CAP'
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path.cwd()/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
class StopToken:
 def __init__(self):self.next=0.
 def is_cancelled(self):
  now=time.monotonic()
  if now>=self.next:self.next=now+.1;poll()
  return False
class Material:
 def __init__(self,cp):self.cp=cp;self.evaluated=0;self.max_abs=0
 def evaluate(self,s):
  v=sum((1 if pc.owner==0 else -1)*round(self.cp.board_weights[pc.current_type_id]*256)for pc in s.position.board if pc)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*round(w*256)for t,w in self.cp.hand_weights.items());assert abs(v)<10000000;self.evaluated+=1;self.max_abs=max(self.max_abs,abs(v));return v*(1 if s.position.side_to_move==0 else -1)
items=[]
for r in roots:
 g=gens[r['rule']];assert g['status']=='SUPPORTED';c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']));s=GameSession.replay(c,deserialize_game_record(json.dumps(r['record'])));assert digest(s.state)==r['state_sha256'];cp=LearnableMaterialCheckpoint.from_dict(models[r['rule']]);assert cp.semantic_native_scale==256;items.append((r,c,s,cp))
write_json(D/'inputs.json',dict(rows=[dict(root=r,rule=gens[r['rule']]['rules'],checkpoint=cp.to_dict())for r,c,s,cp in items],source_service_plan_sha256=hashlib.sha256((S/'plan.json').read_bytes()).hexdigest()))
try:
 with(D/'native-queries.jsonl').open('x',encoding='utf8',newline='\n')as log:
  for r,c,s,cp in items:
   nr=compile_native_semantic_rules(c)
   for mode in P['native']['modes']:
    poll();before=(s.state,s.to_record(),s.history,s._search_witnesses);e=SemanticSearchEngine(c,nr,checkpoint=cp,tt_megabytes=0);tick=time.perf_counter();z=e.search(s,SearchLimits(max_depth=2,max_nodes=131072,max_time_seconds=2,quiescence_max_depth=4),root_window_pruning=mode);row=dict(rule=r['rule'],mode=mode,parent_sha256=digest(s.state),parent_unchanged=before==(s.state,s.to_record(),s.history,s._search_witnesses),result=record_value(z),seconds=time.perf_counter()-tick);log.write(json.dumps(row,separators=(',',':'))+'\n');log.flush();counts['native_queries']+=1;counts['native_nodes']+=z.nodes;assert row['parent_unchanged'];del e
 print('NATIVE_CONTROL_CLOSED',counts,flush=True)
 with(D/'core-queries.jsonl').open('x',encoding='utf8',newline='\n')as log:
  for r,c,s,cp in items:
   poll();remaining=P['limits']['global_seconds']-(time.monotonic()-start)
   if remaining<.5:raise TimeoutError('FROZEN_GLOBAL_CAP')
   before=(s.state,s.to_record(),s.history,s._search_witnesses);stats=SearchStatistics();ev=Material(cp);tick=time.perf_counter()
   action,score,pv,cause=run_root_search(s.state,c,ev,TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(60,remaining-.1),quiescence_max_depth=4),StopToken(),stats,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
   row=dict(rule=r['rule'],parent_sha256=digest(s.state),parent_unchanged=before==(s.state,s.to_record(),s.history,s._search_witnesses),action=record_value(action),score=score,pv=record_value(pv),cause=cause,statistics=record_value(stats),evaluations=ev.evaluated,max_static_abs=ev.max_abs,seconds=time.perf_counter()-tick)
   log.write(json.dumps(row,separators=(',',':'))+'\n');log.flush();counts['Core_calls']+=1;counts['Core_nodes']+=stats.nodes;counts['Core_qnodes']+=stats.qnodes;counts['Core_complete_q4']+=stats.completed_depth==2 and stats.result_ordinary_qdepth==4;assert row['parent_unchanged'];print('CORE_Q4_CONTROL',r['rule'],stats.completed_depth,stats.result_ordinary_qdepth,cause,round(time.monotonic()-start,3),flush=True)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,counts=counts,seconds=time.monotonic()-start,planned_Core=32,unstarted_Core=32-counts['Core_calls'],scope='Core product q4 search/scalar target control, no newsolver/training/games. All incomplete/retainedq0 results remain unqualified for q4; terminal bands mapped only inreader.'))
print('Q4_REFERENCE_CLOSED',status,error,counts,time.monotonic()-start,flush=True)
