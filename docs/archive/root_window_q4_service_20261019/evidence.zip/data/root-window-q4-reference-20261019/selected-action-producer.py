"""Reuse Core negamax only for observed selected-action tie diagnosis."""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import negamax,_Context,_Budget,SearchAborted,INF
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.core.search_runtime import SearchPathRuntime
D=Path(__file__).resolve().parent;start=time.monotonic();P=json.loads((D/'selected-action-plan.json').read_bytes());inputs={i['root']['rule']:i for i in json.loads((D/'inputs.json').read_bytes())['rows']};cores={q['rule']:q for q in map(json.loads,(D/'core-queries.jsonl').read_bytes().splitlines())};natives=list(map(json.loads,(D/'native-queries.jsonl').read_bytes().splitlines()));chosen={}
for n in natives:
 c=cores[n['rule']];z=n['result'];st=c['statistics']
 if st['completed_depth']!=2 or st['result_ordinary_qdepth']!=4 or z['completed_depth']!=2 or z['result_ordinary_qdepth']!=4:continue
 if z['score']!=c['score']or z['action']==c['action']:continue
 key=(n['rule'],json.dumps(z['action'],sort_keys=True))
 chosen.setdefault(key,dict(rule=n['rule'],action=z['action'],expected=c['score'],modes=[]))['modes'].append(n['mode'])
class Stop:
 def __init__(self):self.next=0;self.stopped=False
 def is_cancelled(self):
  if time.monotonic()>self.next:
   self.next=time.monotonic()+.1
   for name in ('rollout','advisor','slack'):
    f=json.loads((Path.cwd()/'.local_agent'/(name+'.json')).read_bytes());self.stopped|=bool(f.get('stopped')or f.get('user_paused'))
  return self.stopped or time.monotonic()-start>=300
class Material:
 def __init__(self,cp):self.cp=cp
 def evaluate(self,s):
  v=sum((1 if p.owner==0 else -1)*round(self.cp['board_weights'][p.current_type_id]*256)for p in s.position.board if p)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*round(w*256)for t,w in self.cp['hand_weights'].items());assert abs(v)<10000000;return v*(1 if s.position.side_to_move==0 else -1)
rows=[]
for x in chosen.values():
 i=inputs[x['rule']];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(i['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(i['root']['record'])));action=next(a for a in s.legal_actions()if record_value(a)==x['action']);s.submit(action);before=(s.state,s.to_record(),s.history,s._search_witnesses);runtime=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses);stats=SearchStatistics();runtime.attach_stats(stats);limits=SearchLimits(max_depth=1,max_nodes=200000,max_time_seconds=60,quiescence_max_depth=4);ctx=_Context(c,Material(i['checkpoint']),TranspositionTable(max_entries=1),stats,_Budget(limits,Stop()),SearchTuning(),False,False,4,8,None,runtime=runtime,first_main_iteration_complete=True);tick=time.perf_counter()
 try:r=negamax(s.state,1,-INF,INF,1,ctx);out=dict(status='COMPLETE',child_score=r.score,backed_up=-r.score,child_main_pv=record_value(r.pv),equal_root_target=-r.score==x['expected'])
 except SearchAborted as exc:out=dict(status='UNKNOWN',reason=str(exc))
 runtime.assert_balanced();assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
 row=dict(**x,child_record=record_value(s.to_record()),child_state=record_value(s.state),statistics=record_value(stats),seconds=time.perf_counter()-tick,**out);rows.append(row);write_json(D/'selected-action-result.json',dict(status='CLOSED',rows=rows,planned=len(chosen),seconds=time.monotonic()-start,scope='ExistingCore negamax selectedchild q4,fullhistory,searchplyoffset1; notallaction/all-defense/WDL ornewNativequery.'));print('SELECTED_CHILD',x['rule'],out,round(time.monotonic()-start,3),flush=True)
