"""Rebuild only CLOSED Core controls from pinned source; never refill UNKNOWN."""
from pathlib import Path
import sys,os,json,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search,negamax,_Context,_Budget,INF
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.core.search_runtime import SearchPathRuntime
D=Path(__file__).resolve().parent;start=time.monotonic();stoproot=Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))
inputs={r['root']['rule']:r for r in json.loads((D/'inputs.json').read_bytes())['rows']};cores=list(map(json.loads,(D/'core-queries.jsonl').read_bytes().splitlines()));selected=json.loads((D/'selected-action-result.json').read_bytes());out=[];skipped=[];childrows=[]
class Stop:
 def __init__(self):self.next=0;self.stopped=False
 def is_cancelled(self):
  if time.monotonic()>=self.next:
   self.next=time.monotonic()+.1
   for name in ('rollout','advisor','slack'):
    f=json.loads((stoproot/'.local_agent'/(name+'.json')).read_bytes());self.stopped|=bool(f.get('stopped')or f.get('user_paused'))
  return self.stopped or time.monotonic()-start>=900
class Material:
 def __init__(self,cp):self.cp=cp
 def evaluate(self,s):
  v=sum((1 if pc.owner==0 else -1)*round(self.cp['board_weights'][pc.current_type_id]*256)for pc in s.position.board if pc)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*round(w*256)for t,w in self.cp['hand_weights'].items());assert abs(v)<10000000;return v*(1 if s.position.side_to_move==0 else -1)
def restored(rule):
 i=inputs[rule];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(i['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(i['root']['record'])));return i,c,s
for old in cores:
 st=old['statistics'];complete=st['completed_depth']==2 and st['result_ordinary_qdepth']==4
 if not complete and old['cause']not in ('root_immediate_win','terminal_position'):
  skipped.append(dict(rule=old['rule'],reason=old['cause'],original_main_nodes=st['nodes'],original_qnodes=st['qnodes']));continue
 assert not Stop().is_cancelled();i,c,s=restored(old['rule']);before=(s.state,s.to_record(),s.history,s._search_witnesses);stats=SearchStatistics();tick=time.perf_counter()
 action,score,pv,cause=run_root_search(s.state,c,Material(i['checkpoint']),TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=60,quiescence_max_depth=4),Stop(),stats,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
 assert before==(s.state,s.to_record(),s.history,s._search_witnesses);assert score==old['score']and record_value(action)==old['action'];assert stats.completed_depth==st['completed_depth']and stats.result_ordinary_qdepth==st['result_ordinary_qdepth']
 out.append(dict(rule=old['rule'],score=score,action=record_value(action),depth=stats.completed_depth,returned_qdepth=stats.result_ordinary_qdepth,complete_q4=complete))
 print('REBUILT_CLOSED_CORE',old['rule'],round(time.perf_counter()-tick,3),flush=True)
for old in selected['rows']:
 assert old['status']=='COMPLETE';i,c,s=restored(old['rule']);a=next(a for a in s.legal_actions()if record_value(a)==old['action']);s.submit(a);assert record_value(s.state)==old['child_state'];before=(s.state,s.to_record(),s.history,s._search_witnesses);rt=SearchPathRuntime.from_state(s.state,c,history_witnesses=s._search_witnesses);stats=SearchStatistics();rt.attach_stats(stats);limits=SearchLimits(max_depth=1,max_nodes=200000,max_time_seconds=60,quiescence_max_depth=4);ctx=_Context(c,Material(i['checkpoint']),TranspositionTable(max_entries=1),stats,_Budget(limits,Stop()),SearchTuning(),False,False,4,8,None,runtime=rt,first_main_iteration_complete=True);v=negamax(s.state,1,-INF,INF,1,ctx);rt.assert_balanced();assert before==(s.state,s.to_record(),s.history,s._search_witnesses);assert v.score==old['child_score']and -v.score==old['expected'];childrows.append(dict(rule=old['rule'],modes=old['modes'],child_score=v.score,backed_up=-v.score,equal_root_target=True))
write_json(D/'core-rebuild-result.json',dict(status='PASS_CLOSED_CORE_Q4_AND_SELECTED_ACTIONS',closed_root_controls=out,skipped_original_unknown=skipped,selected_children=childrows,seconds=time.monotonic()-start,scope='Only27previouscompleteCoreq4trees+2immediatewins+1terminal and2closedselectedchildren rebuilt. Both originallyincompleteCore roots remainunrerun; no Nativequeries/training/generation/fitness orWDL/allactionproof.'))
print('CLOSED_CORE_SOURCE_REBUILD',len(out),len(childrows),len(skipped),time.monotonic()-start,flush=True)
