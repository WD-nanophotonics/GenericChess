from pathlib import Path
from collections import Counter,defaultdict
from statistics import median
import json,sys
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;O=D.parent/'secondary-capture-ordinal-games-20261019'
inp=json.loads((D/'inputs.json').read_bytes());original=list(map(json.loads,(D/'games.jsonl').read_bytes().splitlines()));ordinal=list(map(json.loads,(O/'games.jsonl').read_bytes().splitlines()))
by={(x['name'],x['owner'],x['foe'],x['profile']):x for x in original if x['budget']=='shallow'}
by.update({(x['name'],x['owner'],x['foe'],'ordinal'):x for x in ordinal})
gcost={}
for directory in(D,O):
 for line in(directory/'queries.jsonl').open(encoding='utf8'):
  q=json.loads(line);z=q['result'];v=gcost.setdefault((directory.name,q['slot']),dict(queries=0,main=0,q=0,candidate_caller_seconds=0,foe_caller_seconds=0,candidate_depths=Counter(),candidate_stops=Counter()))
  v['queries']+=1;v['main']+=z['nodes'];v['q']+=z['qnodes'];v['candidate_caller_seconds'if q['candidate']else'foe_caller_seconds']+=q['caller_seconds']
  if q['candidate']:v['candidate_depths'][str(z['completed_depth'])]+=1;v['candidate_stops'][z['termination_reason']]+=1
def difference(x,y):
 a=None if x is None else x['reward'];b=None if y is None else y['reward']
 return [(-1 if a is None else a)-(1 if b is None else b),(1 if a is None else a)-(-1 if b is None else b)]
rows=[];aggregate={foe:dict(static_minus_unit=[0,0],static_minus_ordinal=[0,0],pairs=0)for foe in('unit','static')}
ord_profiles={x['name']:x['ordinal_board']for x in json.loads((D.parent/'secondary-capture-ordinal-20261019/result.json').read_bytes())['rows']}
for r in inp['rules']:
 name=r['name'];rr=[]
 for foe in('unit','static'):
  for owner in(0,1):
   games={profile:by.get((name,owner,foe,profile))for profile in('static','unit','ordinal')};su=difference(games['static'],games['unit']);so=difference(games['static'],games['ordinal'])
   details={}
   for profile,g in games.items():
    directory=O if profile=='ordinal'else D
    details[profile]=dict(reward=None if g is None else g['reward'],ending='UNEXECUTED_UNKNOWN'if g is None else g['ending'],actual_cost=None if g is None else gcost[(directory.name,g['slot'])],slot=None if g is None else g['slot'])
   rr.append(dict(owner=owner,foe=foe,static_minus_unit=su,static_minus_ordinal=so,games=details))
   ag=aggregate[foe];ag['pairs']+=1
   for key,z in(('static_minus_unit',su),('static_minus_ordinal',so)):
    for i in(0,1):ag[key][i]+=z[i]
 staticmedian=median(v for v in r['board_values'].values()if v>0);ordinalmedian=median(v for v in ord_profiles[name].values()if v>0)
 rows.append(dict(name=name,prefix_plies=r['preparation']['ordinary_prefix_plies'],opening_preference_passed=r['preparation']['final_optional_preference_passed'],static_board=r['board_values'],ordinal_board=ord_profiles[name],STATIC_HAND=r['hand_values'],static_BOARD_median=staticmedian,ordinal_BOARD_median=ordinalmedian,median_level_preserved=staticmedian==ordinalmedian,pairs=rr))
for ag in aggregate.values():
 for key in('static_minus_unit','static_minus_ordinal'):ag[key]=[v/ag['pairs']for v in ag[key]]
out=dict(status='PASS_EIGHT_ROOT_SHALLOW_MATCHED_LEDGER',rows=rows,aggregate=aggregate,planned_static_shallow=32,planned_unit_shallow=32,planned_ordinal_shallow=32,new_searches=0,new_games=0,opening_preference_failure=[r['name']for r in rows if not r['opening_preference_passed']],allBOARDmedian256=all(r['static_BOARD_median']==r['ordinal_BOARD_median']==256 for r in rows),scope='Dot1792366078 adoptedwithcountcorrection: actualONEprefFAIL721002-8, all8retained. GlobalBOARDmedian preserved onall8, buttypewiseBOARD/HANDratios change evenwithSTATIC_HAND fixed; notpurewithinBOARDspacingcausalclaim. All96plannedshallow outcomes knownorbounded, deeperbudget separate. Reused32staticcontrols countedonce, no OFFgames.')
write_json(D/'matched-shallow-ledger.json',out);print(json.dumps(dict(aggregate=aggregate,failures=out['opening_preference_failure'],all_median256=out['allBOARDmedian256']),indent=2))
