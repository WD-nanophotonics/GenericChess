from pathlib import Path
from collections import Counter,defaultdict
import sys,json
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());res=json.loads((D/'result.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['rows'];games={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};rows=[]
for idx,slot in enumerate(slots):
 g=games.get(idx)
 if g is not None:assert all(g[k]==v for k,v in slot.items())
 seed,size=slot['name'].split('-');rows.append(dict(slot=idx,**slot,seed=int(seed),size=int(size),reward=None if g is None else g['reward']))
assert len(rows)==P['planned_physical']==128 and len(games)==res['closed']
def bounds(rr):
 n=len(rr);u=sum(v['reward']is None for v in rr);k=sum(v['reward']for v in rr if v['reward']is not None)
 return dict(planned=n,W=sum(v['reward']==1 for v in rr),D=sum(v['reward']==0 for v in rr),L=sum(v['reward']==-1 for v in rr),UNKNOWN=u,reward_bounds=[(k-u)/n,(k+u)/n])
def contrast(rr):
 a={(v['name'],v['owner']):v['reward']for v in rr if v['profile']=='static'};b={(v['name'],v['owner']):v['reward']for v in rr if v['profile']=='unit'};assert a.keys()==b.keys()
 lo=hi=0
 for k,x in a.items():
  y=b[k];lo+=(-1 if x is None else x)-(1 if y is None else y);hi+=(1 if x is None else x)-(-1 if y is None else y)
 return [lo/len(a),hi/len(a)]
contrasts={}
for budget in P['budgets']:
 for foe in P['foes']:
  rr=[v for v in rows if v['budget']==budget and v['foe']==foe];per={str(seed):contrast([v for v in rr if v['seed']==seed])for seed in sorted({v['seed']for v in rr})}
  contrasts[budget+'_'+foe]=dict(arms={profile:bounds([v for v in rr if v['profile']==profile])for profile in P['profiles']},static_minus_unit=contrast(rr),per_linked_seed=per,descriptive_seed_range=[min(v[0]for v in per.values()),max(v[1]for v in per.values())],by_size={str(size):contrast([v for v in rr if v['size']==size])for size in(8,10)})
# Differences of paired gains use the same logical planned cells, never unknown->draw.
interactions={}
for foe in P['foes']:
 lo=hi=0;seedvalues={}
 for seed in range(721001,721005):
  rr=[v for v in rows if v['foe']==foe and v['seed']==seed]
  a=contrast([v for v in rr if v['budget']=='paid50ms']);b=contrast([v for v in rr if v['budget']=='shallow'])
  seedvalues[str(seed)]=[a[0]-b[1],a[1]-b[0]]
  lo+=seedvalues[str(seed)][0];hi+=seedvalues[str(seed)][1]
 interactions[foe]=dict(paid_gain_minus_shallow_gain=[lo/4,hi/4],per_linked_seed=seedvalues,scope='Finite paired-budget interaction; budgets differ in node/time/depth limits, not pure depth or causal population.')
work={};count=main=qnodes=0
for line in(D/'queries.jsonl').open(encoding='utf8'):
 q=json.loads(line);slot=slots[q['slot']];z=q['result'];count+=1;main+=z['nodes'];qnodes+=z['qnodes'];key=(slot['budget']+'_'+slot['profile']if q['candidate']else'foe_'+slot['foe']);w=work.setdefault(key,dict(queries=0,main=0,q=0,caller_seconds=0,kernel_seconds=0,caller_max_seconds=0,depths=Counter(),qpolicies=Counter(),causes=Counter()))
 w['queries']+=1;w['main']+=z['nodes'];w['q']+=z['qnodes'];w['caller_seconds']+=q['caller_seconds'];w['kernel_seconds']+=z['elapsed_seconds'];w['caller_max_seconds']=max(w['caller_max_seconds'],q['caller_seconds']);w['depths'][z['completed_depth']]+=1;w['qpolicies'][str((z['result_ordinary_qdepth'],z['result_check_hard_qdepth']))]+=1;w['causes'][z['termination_reason']]+=1
assert count==res['counts']['queries']and main==res['counts']['main']and qnodes==res['counts']['q']
inp=json.loads((D/'inputs.json').read_bytes())
out=dict(status='PASS_ALL_PLANNED_ARITHMETIC',contrasts=contrasts,interactions=interactions,work=work,queries=count,main=main,q=qnodes,producer_seconds=res['seconds'],terminal=res['terminal'],recorded_UNKNOWN=res['unknown'],unexecuted_UNKNOWN=res['missing'],final_preference_failed=[v['name']for v in inp['rules']if not v['preparation']['final_optional_preference_passed']],actual_trigger_roots=len(inp['roots']),scope='Event-conditioned full-rule8/10 prototype,4linkedseedblocks, bothroles/fixedfoes; descriptive ranges not confidence. Root opportunity is selected BEFORE profile/budget execution. No unchanged oldpanel refill/learning/default or population result.')
write_json(D/'analysis.json',out)
print(json.dumps({k:v for k,v in out.items()if k!='work'},indent=2))
