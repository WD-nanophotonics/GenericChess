from pathlib import Path
from dataclasses import replace
import json,sys,time,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
D=Path(__file__).resolve().parent;start=time.perf_counter();items=[]
p=json.loads((D/'prepared.json').read_bytes());items.append(dict(name='711001-8',rule=p['rule'],board_values=p['board_values'],hand_values=p['hand_values']))
for directory in('secondary-capture-prices-20261019','secondary-capture-validation-20261019'):
 f=D.parent/directory/'inputs.json'
 if f.exists():items+=json.loads(f.read_bytes())['rules']
rows=[]
for row in items:
 assert time.perf_counter()-start<180
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 rule=ruleset_from_dict(row['rule']);base=replace(rule,semantic_actions=());c=compile_ruleset(base);profile=build_ruleset_profile(c,EvaluationConfig());anchors={t.type_id for t in rule.piece_types if t.is_anchor}
 board={t:0 if t in anchors else round(v*.256)for t,v in profile.board_value_by_type.items()};hand={t:0 if t in anchors else round(v*.256)for t,v in profile.hand_value_by_base_type.items()}
 assert board==row['board_values']and hand==row['hand_values']
 rows.append(dict(name=row['name'],profile_base_fingerprint=c.ruleset_fingerprint,profile=record_value(profile),Native_board_values=board,Native_hand_values=hand,all_declared_types=sorted(t.type_id for t in rule.piece_types),semantic_action_count=len(rule.semantic_actions),baseline_effect_contribution='No separatelypricedaux/captureeffect; fullsemanticRuleSet remainsinexecution/search'))
write_json(D/'profile-provenance.json',dict(status='PASS_ALL_TYPE_STATIC_CONSTRUCTOR',rows=rows,seconds=time.perf_counter()-start,Native_queries=0,new_games=0,optimizer_updates=0,scope='Reproduce unchangedbasegeometry constructor on41completeinputs; thenexplicit anchor0/scale.256/round transform matchesALL BOARD/HANDentries. Thisisconstructorprovenance, notindependentoptimalpriceformula, rawlearnednormalization, orclaimthatsemanticrightsarepriced. No reductionoftheactualexecutedRuleSet.'))
print('PROFILE_PROVENANCE',len(rows),time.perf_counter()-start)
