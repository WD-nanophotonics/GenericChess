from pathlib import Path
import json,sys,time,runpy,uuid
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;B=D.parent/'secondary-capture-prices-20261019';V=D.parent/'secondary-capture-validation-20261019';start=time.perf_counter()
games=list(map(json.loads,(B/'games.jsonl').read_bytes().splitlines()));chosen=[g for g in games if len(g['queries'])>10][:2];assert len(chosen)==2
closed,unclosed=chosen;needed={closed['slot'],unclosed['slot']};allq=[q for q in map(json.loads,(B/'queries.jsonl').read_bytes().splitlines())if q['slot']in needed];cq=[q for q in allq if q['slot']==closed['slot']];uq=[q for q in allq if q['slot']==unclosed['slot']]
X=D/('tail-reader-control-'+uuid.uuid4().hex[:8]);X.mkdir();rows=[]
for label,tail in(('complete_terminal_tail',uq),('partial_tail',uq[:-2]),('empty_tail',[])):
 F=X/label;F.mkdir()
 for name in('plan.json','inputs.json'):(F/name).write_bytes((B/name).read_bytes())
 (F/'reader.py').write_bytes((V/'reader.py').read_bytes())
 queries=cq+tail
 (F/'games.jsonl').write_bytes((json.dumps(closed)+'\n').encode())
 (F/'queries.jsonl').write_bytes(('\n'.join(json.dumps(q)for q in queries)+'\n').encode())
 res=dict(status='INCOMPLETE',error='CONTROL_FIXTURE_NOT_ACTUAL_PRODUCER_FAILURE',planned=2,closed=1,missing=1,terminal=int(closed['reward']is not None),unknown=int(closed['reward']is None),counts=dict(games=1,queries=len(queries),main=sum(q['result']['nodes']for q in queries),q=sum(q['result']['qnodes']for q in queries)),current_unclosed={k:unclosed[k]for k in('slot','name','owner','foe','mode','profile','budget')})
 write_json(F/'result.json',res)
 runpy.run_path(str(F/'reader.py'),run_name='__main__')
 out=json.loads((F/'reader-result.json').read_bytes());z=out['partial_tail'];assert out['status'].startswith('PASS')and out['counts']['games']==1 and z['scored_reward']is None and z['Core_verified']and z['queries']==[q['query']for q in tail]and not out['literal_score_gaps']
 rows.append(dict(case=label,closed_game_count=1,planned_UNKNOWN=1,tail_queries=len(tail),Core_verified=True,scored_reward=None,observed_terminal=z['reconstructed_terminal'],verified_queries=out['counts']['queries'],PV_edges=out['counts']['PV_Core_edges']))
write_json(D/'tail-control-result.json',dict(status='PASS_THREE_CONTROLLED_UNCLOSED_TAILS',rows=rows,seconds=time.perf_counter()-start,new_Native_queries=0,new_games=0,scope='Explicitverificationfixtures derivedfrom2alreadyclosedprototypegames; not3newgames or3actualfailures. Originaldata unchanged; terminal/partial/emptyunclosed tails stayUNKNOWN, allstoredNativefields/PVs/fullhistory verified withrealstopflags.'))
print('TAIL_CONTROLS_PASS',rows,time.perf_counter()-start)
