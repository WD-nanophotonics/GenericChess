"""Independent Core reader of saved four-effect consumer and ordinal receipts."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,os,json,hashlib,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.semantic_engine import _core_pv_leaf_dynamic_features,SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;start=time.perf_counter();counts=Counter()
R=Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))
def forbidden(*a,**k):raise AssertionError('No Native search in independent reader')
SemanticSearchEngine.search=forbidden
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
class Stop:
 def __init__(self):self.next=0;self.stop=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in ('rollout','advisor','slack'):
    f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());self.stop|=bool(f.get('stopped')or f.get('user_paused'))
  return self.stop or now-start>900
stop=Stop()
class Material:
 def __init__(self,b,h):self.b=b;self.h=h
 def evaluate(self,s):
  v=sum((1 if x.owner==0 else-1)*self.b[x.current_type_id]for x in s.position.board if x)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items())
  return v*(1 if s.position.side_to_move==0 else-1)
def reference(s,c,b,h,ref):
 assert not stop.is_cancelled()
 if not ref['complete']:counts['UNKNOWN_not_rerun']+=1;return
 st=SearchStatistics();a,v,pv,cause=run_root_search(s.state,c,Material(b,h),TranspositionTable(max_entries=1),SearchLimits(max_depth=3,max_nodes=300000,max_time_seconds=90,quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
 assert st.completed_depth==3 or cause=='root_immediate_win'
 assert v==ref['score']and record_value(a)==ref['action']
 counts['closed_Core_targets']+=1;counts['fresh_Core_main']+=st.nodes;counts['fresh_Core_q']+=st.qnodes
def pvcheck(s,z):
 before=(s.state,s.to_record(),s.history,s._search_witnesses);leaf=copy(s);aa=[decode(a)for a in z['decision_line']]
 for a in aa:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['PV_edges']+=1
 if z.get('dynamic_features'):assert list(_core_pv_leaf_dynamic_features(s,tuple(aa)))==z['dynamic_features']
 assert before==(s.state,s.to_record(),s.history,s._search_witnesses);counts['Native_receipts']+=1

inp=json.loads((D.parent/'secondary-capture-prices-20261019/inputs.json').read_bytes());old={v['phase']:v for v in json.loads((D.parent/'secondary-capture-depth-20261019/result.json').read_bytes())['rows']};res=json.loads((D/'result.json').read_bytes());assert res['status']=='COMPLETE'
for row in res['rows']:
 r=next(x for x in inp['rules']if x['name']==row['name']);parent=next(x for x in inp['roots']if x['name']==row['name']);c=compile_semantic_ruleset(ruleset_from_dict(r['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(parent['record'])))
 assert row['same_hand']==r['hand_values'] and row['static_board']==r['board_values']
 values=sorted(r['board_values'][t]for t in r['board_values']if t not in {v['type_id']for v in r['rule']['piece_types']if v['is_anchor']});median=(len(values)+1)/2
 for t,v in row['static_board'].items():
  expected=0 if v==0 else round(256*sum(i+1 for i,x in enumerate(values)if x==v)/values.count(v)/median)
  assert row['ordinal_board'][t]==expected
 for a in row['static_board']:
  for b in row['static_board']:
   sign=lambda x,y:(x>y)-(x<y)
   assert sign(row['static_board'][a],row['static_board'][b])==sign(row['ordinal_board'][a],row['ordinal_board'][b])
 reused=row['profiles']['static'];assert reused['REUSED'] and reused['native']==next(x['result']for x in old[row['name']]['native']if x['mode'])and reused['core']==old[row['name']]['core']
 rr=row['profiles']['ordinal'];reference(s,c,row['ordinal_board'],row['same_hand'],rr['core'])
 for label in ('static','ordinal'):pvcheck(s,row['profiles'][label]['native'])
 counts['reused_static_receipts']+=1;counts['different_actions']+=row['profiles']['static']['native']['action']!=rr['native']['action']
assert counts['different_actions']==res['counts']['different_action']
write_json(D/'reader-result.json',dict(status='PASS_ORDINAL_CORE_PV_ORDERING',counts=dict(counts),seconds=time.perf_counter()-start,Native_calls=0,new_games=0,optimizer_updates=0,scope='EightnewordinalclosedCoreD3 targets; eightstaticNative/Core receiptsreused not newqueries. All16PV legal/featurechecked; inputrelevance notutility.'))
print('SECONDARY_ORDINAL_READER',dict(counts),time.perf_counter()-start)
