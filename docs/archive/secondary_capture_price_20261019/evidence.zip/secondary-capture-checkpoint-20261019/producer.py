from pathlib import Path
from copy import copy
from collections import Counter
import json,sys,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;B=D.parent/'secondary-capture-prices-20261019';start=time.perf_counter();deadline=start+180
inp=json.loads((B/'inputs.json').read_bytes());gg=list(map(json.loads,(B/'games.jsonl').read_bytes().splitlines()));chosen={}
for root in inp['roots']:
 owner=root['state']['position']['side_to_move'];g=next(g for g in gg if g['name']==root['name']and g['owner']==owner and g['foe']=='unit'and g['profile']=='static'and g['budget']=='shallow');chosen[g['queries'][0]]=root['name']
baseline={}
for line in(B/'queries.jsonl').open(encoding='utf8'):
 q=json.loads(line)
 if q['query']in chosen:baseline[chosen[q['query']]]=q
off={r['name']:r['off_rule']for r in json.loads((D.parent/'secondary-capture-counterfactual-20261019/result.json').read_bytes())['rows']}
counts=Counter();rows=[];status='COMPLETE';error=None
class Stop:
 def __init__(self):self.next=0;self.flag=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.05
   for n in('rollout','advisor','slack'):
    f=json.loads(Path('.local_agent',n+'.json').read_bytes());self.flag|=bool(f.get('stopped')or f.get('user_paused'))
  return self.flag or now>=deadline
stop=Stop()
class Material:
 def __init__(self,r):self.r=r
 def evaluate(self,s):
  r=self.r;p=s.position
  return (sum((1 if x.owner==0 else-1)*r['board_values'][x.current_type_id]for x in p.board if x)+sum((p.hands[0].count(t)-p.hands[1].count(t))*v for t,v in r['hand_values'].items()))*(1 if p.side_to_move==0 else-1)
try:
 for root in inp['roots']:
  assert not stop.is_cancelled();r=next(x for x in inp['rules']if x['name']==root['name']);c=compile_semantic_ruleset(ruleset_from_dict(r['rule']));nr=compile_native_semantic_rules(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));before=(s.state,s.to_record(),s.history,s._search_witnesses)
  cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='explicit_static256_carrier_control',board_weights={t:float(v)for t,v in r['board_values'].items()},hand_weights={t:float(v)for t,v in r['hand_values'].items()},material_scale=1.,value_scale=1.,reference_median=256.,training_updates=0)
  assert cp.semantic_native_scale==1 and cp.semantic_quantized_board(nr.type_ids)==[r['board_values'][t]for t in nr.type_ids]and cp.semantic_quantized_hand(nr.type_ids)==[r['hand_values'][t]for t in nr.type_ids]
  cp.validate_ruleset(c);off_c=compile_semantic_ruleset(ruleset_from_dict(off[root['name']]))
  try:cp.validate_ruleset(off_c)
  except ValueError:counts['wrong_rule_refused']+=1
  else:raise AssertionError('wrong-rule checkpoint accepted')
  e=SemanticSearchEngine(c,nr,checkpoint=cp,tt_megabytes=0);tick=time.perf_counter();z=e.search(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=min(1,deadline-time.perf_counter()),quiescence_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-tick;del e
  old=baseline[root['name']];zr=record_value(z)
  equality={k:zr[k]==old['result'][k]for k in('score','action','decision_line','completed_depth','nodes','qnodes')}
  assert all(equality.values())and z.completed_depth==2
  leaf=copy(s)
  for a in z.decision_line:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['PV_edges']+=1
  st=SearchStatistics();tick=time.perf_counter();a,v,pv,cause=run_root_search(s.state,c,Material(r),TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(10,deadline-time.perf_counter()),quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
  complete=st.completed_depth==2 or cause=='root_immediate_win';mapped=v-900000000 if v>=900000000 else v+900000000 if v<=-900000000 else v
  assert complete and z.score==mapped
  rows.append(dict(name=root['name'],checkpoint=cp.to_dict(),native=zr,native_seconds=elapsed,reused_baseline_query=old['query'],equal_fields=equality,core=dict(action=record_value(a),score=v,pv=record_value(pv),cause=cause,complete=complete,statistics=record_value(st),seconds=time.perf_counter()-tick),wrong_fingerprint_refused=True))
  counts['Native_queries']+=1;counts['Native_main']+=z.nodes;counts['Core_queries']+=1;counts['Core_main']+=st.nodes
  assert before==(s.state,s.to_record(),s.history,s._search_witnesses)
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,rows=rows,counts=dict(counts),seconds=time.perf_counter()-start,new_games=0,optimizer_updates=0,scope='ExistingcompleteRuleSet-boundcheckpoint carrierparity on8fulltypecapture opportunityroots. Static explicitweights notlearnedAUXmodel, no crossrule transfer by letters. EightoriginalNativegamebaseline receipts reused notrerun.'))
print('FULLTYPE_CHECKPOINT',status,error,dict(counts),time.perf_counter()-start)
