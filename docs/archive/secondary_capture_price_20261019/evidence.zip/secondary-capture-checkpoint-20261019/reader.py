"""Independent Core reader of saved four-effect consumer and ordinal receipts."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,os,json,hashlib,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.semantic_engine import _core_pv_leaf_dynamic_features,SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
D=Path(__file__).resolve().parent;start=time.perf_counter();counts=Counter()
R=Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))
def forbidden(*a,**k):raise AssertionError('No Native search in independent reader')
SemanticSearchEngine.search=forbidden
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
class Stop:
 def __init__(self):self.next=0;self.stop=False
 def is_cancelled(self):
  now=time.perf_counter()
  if now>=self.next:
   self.next=now+.1
   for n in ('rollout','advisor','slack'):
    f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());self.stop|=bool(f.get('stopped')or f.get('user_paused'))
  return self.stop or now-start>120
stop=Stop()
class Material:
 def __init__(self,b,h):self.b=b;self.h=h
 def evaluate(self,s):
  v=sum((1 if x.owner==0 else-1)*self.b[x.current_type_id]for x in s.position.board if x)+sum((s.position.hands[0].count(t)-s.position.hands[1].count(t))*v for t,v in self.h.items())
  return v*(1 if s.position.side_to_move==0 else-1)
def reference(s,c,b,h,ref):
 assert not stop.is_cancelled()
 if not ref['complete']:counts['UNKNOWN_not_rerun']+=1;return
 st=SearchStatistics();a,v,pv,cause=run_root_search(s.state,c,Material(b,h),TranspositionTable(max_entries=1),SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=10,quiescence_max_depth=0),stop,st,use_tt=False,use_ordering=False,tuning=SearchTuning(),_history_witnesses=s._search_witnesses)
 assert st.completed_depth==2 or cause=='root_immediate_win'
 assert v==ref['score']and record_value(a)==ref['action']
 counts['closed_Core_targets']+=1;counts['fresh_Core_main']+=st.nodes;counts['fresh_Core_q']+=st.qnodes
def pvcheck(s,z):
 before=(s.state,s.to_record(),s.history,s._search_witnesses);leaf=copy(s);aa=[decode(a)for a in z['decision_line']]
 for a in aa:leaf.declare(a)if isinstance(a,str)else leaf.submit(a);counts['PV_edges']+=1
 if z.get('dynamic_features'):assert list(_core_pv_leaf_dynamic_features(s,tuple(aa)))==z['dynamic_features']
 assert before==(s.state,s.to_record(),s.history,s._search_witnesses);counts['Native_receipts']+=1

B=D.parent/'secondary-capture-prices-20261019';inp=json.loads((B/'inputs.json').read_bytes());off={x['name']:x['off_rule']for x in json.loads((D.parent/'secondary-capture-counterfactual-20261019/result.json').read_bytes())['rows']}
r=json.loads((D/'result.json').read_bytes());assert r['status']=='COMPLETE'
need={x['reused_baseline_query']for x in r['rows']};baseline={}
for line in(B/'queries.jsonl').open(encoding='utf8'):
 q=json.loads(line)
 if q['query']in need:baseline[q['query']]=q
for row in r['rows']:
 root=next(x for x in inp['roots']if x['name']==row['name']);rr=next(x for x in inp['rules']if x['name']==row['name']);c=compile_semantic_ruleset(ruleset_from_dict(rr['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])))
 cp=LearnableMaterialCheckpoint.from_dict(row['checkpoint']);cp.validate_ruleset(c);types=tuple(sorted(rr['board_values']))
 assert cp.semantic_native_scale==1 and cp.semantic_quantized_board(types)==[rr['board_values'][t]for t in types]and cp.semantic_quantized_hand(types)==[rr['hand_values'][t]for t in types]
 assert cp.training_updates==0 and cp.generation==0 and not cp.dynamic_weights
 try:cp.validate_ruleset(compile_semantic_ruleset(ruleset_from_dict(off[row['name']])))
 except ValueError:counts['wrong_rule_refused']+=1
 else:raise AssertionError('Wrong-fingerprint checkpoint didnotrefuse')
 z=row['native'];b=baseline[row['reused_baseline_query']]['result'];assert all(z[k]==b[k]for k in row['equal_fields'])and all(row['equal_fields'].values())
 reference(s,c,rr['board_values'],rr['hand_values'],row['core']);pvcheck(s,z);counts['reused_original_game_baselines']+=1;counts['explicit_declared_types']+=len(types)
write_json(D/'reader-result.json',dict(status='PASS_FULLTYPE_CHECKPOINT_CORE_PV_FINGERPRINT',counts=dict(counts),seconds=time.perf_counter()-start,Native_calls=0,new_games=0,optimizer_updates=0,scope='EightnewcarrierclosedD2Coretargets/PVs andexactreusedtablebaselinecomparison;wrongfingerprintrefuses. Sourceconsumercompatibility, notAUXmodeltransfer/training ornewAPI.'))
print('FULLTYPE_CHECKPOINT_READER',dict(counts),time.perf_counter()-start)
