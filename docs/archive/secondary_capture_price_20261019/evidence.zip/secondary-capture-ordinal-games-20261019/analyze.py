from pathlib import Path
from collections import Counter,defaultdict
import json,sys
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;B=D.parent/'secondary-capture-prices-20261019'
res=json.loads((D/'result.json').read_bytes());oldres=json.loads((B/'result.json').read_bytes())
slots=json.loads((D/'slots.json').read_bytes())['rows'];og={x['slot']:x for x in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())}
baseline={ (x['name'],x['owner'],x['foe']):x for x in map(json.loads,(B/'games.jsonl').read_bytes().splitlines())if x['profile']=='static'and x['budget']=='shallow'}
current={}
for i,slot in enumerate(slots):current[(slot['name'],slot['owner'],slot['foe'])]=og.get(i)
assert len(current)==32 and len(og)==res['closed']
def diff(a,b):return [(-1 if a is None else a)-(1 if b is None else b),(1 if a is None else a)-(-1 if b is None else b)]
def counts(v):
 u=sum(x is None for x in v);k=sum(x for x in v if x is not None);return dict(W=v.count(1),D=v.count(0),L=v.count(-1),UNKNOWN=u,reward_bounds=[(k-u)/len(v),(k+u)/len(v)])
out={}
for foe in('unit','static'):
 keys=[k for k in current if k[2]==foe];pairs=[];seed=defaultdict(lambda:[0,0,0])
 for k in keys:
  a=current[k];b=baseline.get(k);av=None if a is None else a['reward'];bv=None if b is None else b['reward'];z=diff(av,bv)
  pairs.append(dict(name=k[0],owner=k[1],ordinal_reward=av,reused_static_reward=bv,ordinal_minus_static=z))
  se=k[0].split('-')[0];seed[se][0]+=z[0];seed[se][1]+=z[1];seed[se][2]+=1
 per={k:[v[0]/v[2],v[1]/v[2]]for k,v in seed.items()}
 out[foe]=dict(ordinal=counts([x['ordinal_reward']for x in pairs]),reused_static=counts([x['reused_static_reward']for x in pairs]),ordinal_minus_static=[sum(x['ordinal_minus_static'][i]for x in pairs)/len(pairs)for i in(0,1)],per_linked_seed=per,descriptive_seed_range=[min(v[0]for v in per.values()),max(v[1]for v in per.values())],pairs=pairs)
qq=defaultdict(list);bq=defaultdict(list)
for line in(D/'queries.jsonl').open(encoding='utf8'):
 q=json.loads(line);qq[q['slot']].append(q)
baseline_slots={g['slot']for g in baseline.values()}
for line in(B/'queries.jsonl').open(encoding='utf8'):
 q=json.loads(line)
 if q['slot']in baseline_slots:bq[q['slot']].append(q)
divergences=[];depths={}
for k,a in current.items():
 b=baseline.get(k)
 if a is None or b is None:continue
 aa=qq[a['slot']];bb=bq[b['slot']];first=None
 for x,y in zip(aa,bb):
  if x['committed']!=y['committed']:
   assert x['before_sha256']==y['before_sha256']
   first=dict(relative_ply=x['relative_ply'],candidate=x['candidate'],same_actual_depth=x['result']['completed_depth']==y['result']['completed_depth'],ordinal_depth=x['result']['completed_depth'],static_depth=y['result']['completed_depth']);break
 divergences.append(dict(name=k[0],owner=k[1],foe=k[2],first=first,whole_committed_prefix_equal=first is None and len(aa)==len(bb)))
for label,groups in(('ordinal',qq),('reused_static',bq)):
 zz=[q for group in groups.values()for q in group if q['candidate']]
 depths[label]=dict(queries=len(zz),main=sum(q['result']['nodes']for q in zz),caller_seconds=sum(q['caller_seconds']for q in zz),depths=dict(Counter(str(q['result']['completed_depth'])for q in zz)),termination_reasons=dict(Counter(q['result']['termination_reason']for q in zz)))
result=dict(status='PASS_REUSED_BASELINE_PLANNED_BOUNDS',contrasts=out,first_divergences=divergences,work=depths,new_physical_games=res['closed'],new_queries=res['counts']['queries'],new_main=res['counts']['main'],producer_seconds=res['seconds'],reused_static_planned=32,scope='Same8exposedrules/triggerroots, STATIC_HAND identical, rankBOARDpreservesweakordering.32newordinalshallowphysicalgames vs32alreadyplannedstaticshallowgames, no rerun/refill. Distinctexecutiontimes andpairedactualdepth/cost retained. Not independentholdout, causal HANDstudy, all-budget orpopulationclaim.')
write_json(D/'analysis.json',result);print(json.dumps({k:v for k,v in result.items()if k not in('first_divergences','contrasts')},indent=2));print('BOUNDS',{k:v['ordinal_minus_static']for k,v in out.items()})
