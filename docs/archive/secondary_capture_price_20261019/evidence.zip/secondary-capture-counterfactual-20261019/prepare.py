from pathlib import Path
from dataclasses import replace
import json,sys,time,hashlib,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
D=Path(__file__).resolve().parent;start=time.perf_counter()
inp=json.loads((D.parent/'secondary-capture-prices-20261019/inputs.json').read_bytes());rows=[];edges=0
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
for parent in inp['roots']:
 assert time.perf_counter()-start<120
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 row=next(v for v in inp['rules']if v['name']==parent['name']);rule=ruleset_from_dict(row['rule']);action,=rule.semantic_actions;aux,=action.aux_state
 off=replace(rule,semantic_actions=(replace(action,aux_state=(replace(aux,initial=0),)),))
 on_c=compile_semantic_ruleset(rule);off_c=compile_semantic_ruleset(off)
 on=GameSession.replay(on_c,deserialize_game_record(json.dumps(parent['record'])));alt=GameSession(off_c)
 assert on_c.ruleset_fingerprint!=off_c.ruleset_fingerprint
 for a in on.to_record().actions:alt.submit(a);edges+=1
 x=on.state.position;y=alt.state.position
 assert x.board==y.board and x.hands==y.hands and x.side_to_move==y.side_to_move and on.state.ply_count==alt.state.ply_count and on.result==alt.result
 for c,s,want in((on_c,on,1),(off_c,alt,0)):
  slot,=c.ir.aux_slots
  assert all(dict(s.state.position.aux_state).get((slot.slot_id,o),slot.initial)==want for o in(0,1))
 aa=on.legal_actions();bb=alt.legal_actions();special=set(row['special_pattern_ids'])
 assert {a for a in aa if getattr(a,'pattern_id',None)not in special}==set(bb)
 extra=[a for a in aa if getattr(a,'pattern_id',None)in special];assert extra
 check=GameSession.replay(off_c,alt.to_record());assert (check.state,check.history,check._search_witnesses)==(alt.state,alt.history,alt._search_witnesses)
 rows.append(dict(name=row['name'],off_rule=ruleset_to_dict(off),off_record=json.loads(serialize_game_record(alt.to_record())),off_state=record_value(alt.state),off_state_sha256=digest(alt.state),off_witness_sha256=digest(alt._search_witnesses),on_rule_fingerprint=on_c.ruleset_fingerprint,off_rule_fingerprint=off_c.ruleset_fingerprint,prefix_plies=alt.state.ply_count,on_legal=len(aa),off_legal=len(bb),on_only=record_value(extra),same_board_hands_actor_and_ply=True,full_history_reconstructed=True))
out=dict(status='PASS_FULLRULE_OFF_RIGHT_FEASIBILITY',rows=rows,Core_prefix_edges=edges,seconds=time.perf_counter()-start,Native_queries=0,fitness_games=0,optimizer_updates=0,scope='Onlyruleauxinitial1->0 changed. Fullordinaryprefix reexecuted underdifferentfingerprint; physicalboard/hands/actor/ply equal, fullhistory/witnessretained not copied/faked. Bothowners rightsdisabled changesfuturechoicepolicy/rule; not a pure isolatedpieceprice intervention or measuredutility. No OFFgameslaunched.')
write_json(D/'result.json',out);print('OFF_RIGHT_FEASIBILITY',len(rows),edges,out['seconds'])
