"""Core-only reconstruction of conversion hint receipts and full PVs."""
from pathlib import Path
from copy import copy
from collections import Counter
import json,time,sys,os
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.semantic_engine import SemanticSearchEngine,_core_pv_leaf_dynamic_features
def forbidden(*a,**k):raise AssertionError('No Native calls in reader')
SemanticSearchEngine.search=forbidden
D=Path(__file__).resolve().parent;start=time.perf_counter();count=Counter()
p=json.loads((D.parent/'secondary-capture-consumer-20261019/prepared.json').read_bytes());rows={v['phase']:dict(name=v['phase'],rule=p['rule'],board_values=p['board_values'],hand_values=p['hand_values'],target=p['target'],special_pattern_ids=['sem_00_secondary_capture_type_right'])for v in p['parents']};roots={v['phase']:v for v in p['parents']}
sessions={n:GameSession.replay(compile_semantic_ruleset(ruleset_from_dict(r['rule'])),deserialize_game_record(json.dumps(roots[n]['record'])))for n,r in rows.items()}
def key(a):return json.dumps(record_value(a),sort_keys=True)
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
r=json.loads((D/'result.json').read_bytes());a=json.loads((D/'analysis.json').read_bytes());assert r['status']=='COMPLETE'
for x in r['rows']:
 assert time.perf_counter()-start<120
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',Path.cwd()))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 s=sessions[x['name']];row=rows[x['name']];z=x['result'];p=x['prior']
 if p:
  aa=s.legal_actions();assert p['full_legal_count']==len(aa)
  expected={}
  for v in aa:
   if getattr(v,'pattern_id',None)not in row['special_pattern_ids']:continue
   owner=s.state.position.side_to_move;sign=1 if owner==0 else -1;victim=s.state.position.board[(v.from_square.rank+sign)*row['rule']['board_size']+v.from_square.file]
   gain=row['board_values'][victim.current_type_id]+row['hand_values'][victim.base_type_id]+row['board_values'][row['target']]-row['board_values'][v.actor_type_id]
   if gain>0:expected[key(v)]=gain
  assert expected=={key(v['action']):v['gain']for v in p['positive_conversion_candidates']}
  if p['selected']:
   assert expected[key(p['selected'])]==max(expected.values())and z['root_hint_legal']and z['root_hint_requested']==p['selected']and z['root_hint_apply_count']>=1;count['honored_hints']+=1
  count['full_legality_receipts']+=1
 if z:
  aa=[decode(v)for v in z['decision_line']];leaf=copy(s)
  for v in aa:leaf.declare(v)if isinstance(v,str)else leaf.submit(v);count['PV_edges']+=1
  if z.get('dynamic_features'):assert list(_core_pv_leaf_dynamic_features(s,tuple(aa)))==z['dynamic_features']
  count['Native_receipts']+=1;count['main']+=z['nodes'];count['q']+=z['qnodes']
for depth in(2,8):
 rr=[v for v in r['rows']if v['depth']==depth];result=a[str(depth)]
 for method in('baseline','secondary_capture_hint'):
  xx=[v for v in rr if v['method']==method];m=result['methods'][method]
  assert m['caller_seconds']==sum(v['caller_seconds']for v in xx)and m['main']==sum(v['result']['nodes']for v in xx)and m['depths']==[v['result']['completed_depth']for v in xx]and m['preprocess_seconds']==sum(v['prior']['seconds']for v in xx if v['prior'])
 for pair in result['pairs']:
  b=next(v['result']for v in rr if v['name']==pair['name']and v['method']=='baseline');p=next(v['result']for v in rr if v['name']==pair['name']and v['method']=='secondary_capture_hint')
  same=all(b[k]==p[k]for k in('completed_depth','result_ordinary_qdepth','result_check_hard_qdepth'));assert same==pair['same_actual_depth_and_q']
  if same:assert pair['same_score']==(b['score']==p['score'])and pair['same_action']==(b['action']==p['action'])
assert count['main']==r['counts']['main']and count['Native_receipts']==r['counts']['Native_queries']
write_json(D/'reader-result.json',dict(status='PASS_FULL_LEGAL_HINTS_PVS_ARITHMETIC',counts=dict(count),seconds=time.perf_counter()-start,Native_calls=0,new_games=0,optimizer_updates=0,scope='Core fulllegals/gains/PVs/recordedNativehintapplication andarithmetic; packedtieIDbits notindependentlyreconstructed; no utility claim'))
print('HINT_READER',dict(count),time.perf_counter()-start)
