import os
"""Full-history late-censor minimax and one-ply diagnostics, no game continuation."""
from pathlib import Path
from dataclasses import replace
from collections import Counter
import json,sys,time,hashlib
R=Path.cwd();STOP_ROOT=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R))).resolve();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import apply_action,legal_actions
from scripts.research_record import record_value
D=R/'.local_agent/mature-static-20261017';P=json.loads((D/'censor-plan.json').read_bytes());models={r['checkpoint_id']:r['checkpoint']for r in json.loads((D/'models.json').read_bytes())['rows']};cc={};visits=0;rows=[];start=time.perf_counter()
def digest(x):return hashlib.sha256(json.dumps(record_value(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.perf_counter()-start<P['limits']['cap_seconds']and visits<P['limits']['core_visits'],'FROZEN_DIAGNOSTIC_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((STOP_ROOT/'.local_agent'/(n+'.json')).read_bytes());assert not f.get('user_paused')and not f.get('stopped'),'EXPLICIT_STOP'
for item in json.loads((D/'censor-inputs.json').read_bytes())['rows']:
 poll();g=item['game'];q=item['query'];gs=g['rule']
 if gs not in cc:cc[gs]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(json.loads((D/f'rule-{gs}.json').read_bytes())))
 c=cc[gs];full=deserialize_game_record(json.dumps(g['record']));s=GameSession.replay(c,replace(full,actions=full.actions[:-1],resigned_by=None,declaration=None));assert digest(s.state)==q['before_sha256'];cp=models[q['checkpoint_id']];n0=visits
 def solve(st,depth,relative):
  global visits
  visits+=1
  if visits%128==0:poll()
  term=st.terminal_status
  if term.is_terminal:return 0 if term.winner is None else(100000000-relative)*(1 if term.winner==0 else-1)
  if depth==0:
   return sum((1 if x.owner==0 else-1)*round(cp['board_weights'].get(x.current_type_id,0.)*256)for x in st.position.board if x)+sum((st.position.hands[0].count(t)-st.position.hands[1].count(t))*round(w*256)for t,w in cp['hand_weights'].items())
  a=[solve(apply_action(st,m,c),depth-1,relative+1)for m in legal_actions(st,c)];assert a;return(max if st.position.side_to_move==0 else min)(a)
 aa=s.legal_actions();vv=[solve(apply_action(s.state,m,c),1,1)for m in aa];own=s.state.position.side_to_move;best=(max if own==0 else min)(vv);chosen=full.actions[-1];assert chosen in aa;actual=q['score']*(1 if own==0 else-1);matched=actual==best and vv[aa.index(chosen)]==best
 s.submit(chosen);assert s.to_record()==full and s.result.status.value=='ongoing'and digest(s.state)==g['final_state_sha256'];finalown=s.state.position.side_to_move;oneply=Counter()
 for a in s.legal_actions():
  child=apply_action(s.state,a,c);term=child.terminal_status;visits+=1
  if term.is_terminal:oneply['winning_children'if term.winner==finalown else'draw_children'if term.winner is None else'losing_children']+=1
  else:oneply['ongoing_children']+=1
 rows.append(dict(slot=g['slot'],rule=gs,label=g['label'],foe=g['foe'],candidate_owner=g['candidate_owner'],final_side=finalown,final_ply=s.state.ply_count,last_actual_query_depth=2,last_native_quantized_value=actual,last_core_quantized_best=best,last_chosen_own_optimal=matched,final_oneply=dict(oneply),max_full_rule_repetition_counter=max(v for k,v in s.state.repetition_counts),declared_repetition_limit=c.repetition_limit,core_visits=visits-n0,retained_reward=None))
counts=Counter()
for r in rows:
 counts['tail_games']+=1;counts['last_query_core_mismatches']+=not r['last_chosen_own_optimal'];counts['final_has_winning_child']+=r['final_oneply'].get('winning_children',0)>0;counts['final_has_draw_child']+=r['final_oneply'].get('draw_children',0)>0;counts['final_has_ongoing_child']+=r['final_oneply'].get('ongoing_children',0)>0;counts['repeat_counter_reaches_rule_limit']+=r['max_full_rule_repetition_counter']>=r['declared_repetition_limit']
out=dict(status='COMPLETE_ALL467_CENSOR_TAIL_DIAGNOSTIC',counts=dict(counts),rows=rows,core_visits=visits,seconds=time.perf_counter()-start,scope='ALL467H128unknownphysicaltails, parentlastqueryunprunedCoreD2+actualfinalFULLhistory/oneplychildren; noNativequery/gamecontinuation/labelreplacement. AllfrozenUNKNOWNretained regardlesslegalwinningchild. Per-rulecounter isnotPosition-onlycycle/WDLproof. Posthocselectedtailsnotgeneralqueryerrorrate/full-domainproof.');write_json(D/'censor-result.json',out);print(json.dumps({k:v for k,v in out.items()if k!='rows'}),flush=True)
