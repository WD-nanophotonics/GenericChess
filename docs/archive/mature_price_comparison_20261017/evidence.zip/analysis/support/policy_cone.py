from pathlib import Path
import json,sys,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/free-price-20261017';T=D/'exact/results/dev_aux/task2534';started=time.perf_counter();rows=[];maximum=0.;vectors=0
for gs in(271001,271002,271003,271004):
 rule=json.loads((T/f'rules-{gs}.json').read_bytes());anchors={p['type_id']for p in rule['piece_types']if p['is_anchor']};assert anchors=={'K'};inventory=sum(pc is not None and pc['base_type_id']not in anchors for row in rule['initial_position']for pc in row);assert inventory==14
 seen=set();bound=rawbound=0.;minp=float('inf');maxp=0.
 for line in(T/'episodes.jsonl').open():
  e=json.loads(line)
  if e['generator_seed']!=gs or e['method']!='free6':continue
  for w in(e['initial_weights'],e['weights']):
   assert w[0]>0;minp=min(minp,w[0]);maxp=max(maxp,w[0]);seen.add(tuple(w));b=inventory*max(abs(x/w[0])for x in w);bound=max(bound,b);rawbound=max(rawbound,inventory*max(abs(x)for x in w))
 maximum=max(maximum,bound);vectors+=len(seen);rows.append(dict(rule=gs,nonanchor_initial_inventory=inventory,unique_episode_frozen_free_vectors=len(seen),P_range=[minp,maxp],sufficient_absolute_nonterminal_bound_after_positivePdivision=bound,sufficient_absolute_raw_nonterminal_bound=rawbound,owner_terminal_magnitude=1000000.,below_owner_terminal=True));assert bound<1000000 and rawbound<1000000
proof='ForafixedpositivePvector, dividingALLsixordinarycoefficientsbyP multiplieseveryordinaryleafbypositive1/P. Ifbothordinaryrangesremainstrictlyinsideconstantterminal+-M, theleaf-value transformationisstrictlyincreasingacrossordinaryandterminalclasses, socommuteswithfiniteunprunedmin/maxandpreservesoptimalactionsets. Thisisexactreal-arithmetic/search-policyexpressivity, NOTfixedtanhprediction/gradient/updateequivalence, time/node/tiebehavior orre-roundedNative256equivalence. These4legacycapture/promotion/drop rulespreserve14nonanchorunits (capturemovesunittohand;dropmovesitback), no spawn/auxcustommechanism claim.'
result=dict(status='COMPLETE_CONDITIONAL_POSITIVE_CONE_POLICY_SCOPE',rows=rows,total_unique_episode_frozen_free_vectors=vectors,max_sufficient_nonterminal_bound_after_Pdivision=maximum,proof=proof,scope='Source-derivedbounded-inventoryconditionwithactualALLdeployedepisodevectors. No newsearch/training/fitness/modelrenormalization. Conditionalmathematicalscope, notexecutedall-action/all-depth/Nativeroundedcomparison orfullgenerateddomainproof. Fixed5canrepresentthesepositivePexactmaterialpolicies atsomeotherrawcoefficients; freePstillchangesfixedT10TDfunctionandoptimizationdynamics. NegativeP/full-domainnecessityremainsopen.',seconds=time.perf_counter()-started);write_json(D/'policy-cone-result.json',result);print(json.dumps(result,indent=2))
