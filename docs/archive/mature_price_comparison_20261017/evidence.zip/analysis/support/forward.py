"""PRIMARY forward eligibility arithmetic; no owner trainer/auditor imports."""
from pathlib import Path
from collections import defaultdict,Counter
from math import tanh,sqrt
import json,sys,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/free-price-20261017';T=D/'exact/results/dev_aux/task2534';start=time.monotonic();p=json.loads((T/'registration.json').read_bytes());stream=(json.loads(line)for line in(T/'queries.jsonl').open());nxt=next(stream,None);counts=Counter();maxerr=0.;maxnorm=0.;maxco=0.;byarm=defaultdict(Counter);ranges=defaultdict(lambda:[float('inf'),-float('inf')]);rows=[]
for line in(T/'episodes.jsonl').open():
 assert time.monotonic()-start<90,'FROZEN_ARITHMETIC_CAP'
 e=json.loads(line);key=e['generator_seed'],e['method'],e['seed'];w=e['initial_weights'];obs=[];used=0
 for value in [w[0],e['weights'][0]]:ranges[key][0]=min(ranges[key][0],value);ranges[key][1]=max(ranges[key][1],value)
 while nxt is not None and(nxt['generator_seed'],nxt['method'],nxt['seed'],nxt['game'])==key+(e['game'],):
  q=nxt;nxt=next(stream,None);counts['queries']+=1;used+=q['nodes'];assert q['weights']==w
  if not q['complete']:counts['failed_queries']+=1;continue
  value=tanh(q['value']/10);g=[0.]*6 if q['pv_terminal']else[(0. if j==0 and e['method']=='fixed5'else x*(1-value*value)/10.)for j,x in enumerate(q['pv_phi'])];assert abs(value-q['prediction'])<1e-12;obs.append((value,g));counts['complete_observations']+=1
  if e['method']=='free6'and not q['pv_terminal']:
   assert w[0]>0
   material=sum(x*y for x,y in zip(w,q['pv_phi']));assert abs(material-q['value'])<1e-9
   normalized=material/w[0];fixed=tanh(normalized/10);co=tanh(normalized/(10/w[0]));a=abs(fixed-value);b=abs(co-value);counts['free_ordinary_inputs']+=1;counts['positiveP_pin_fixedT_changes']+=a>1e-12;maxnorm=max(maxnorm,a);maxco=max(maxco,b)
 eligibility=[0.]*6;delta=[0.]*6;creditterminal=[0.]*6;errors=0
 for i,(value,g)in enumerate(obs):
  target=obs[i+1][0]if i+1<len(obs)else e['outcome']
  if target is None:continue
  error=target-value;eligibility=[p['lambda']*a+b for a,b in zip(eligibility,g)];delta=[a+error*b for a,b in zip(delta,eligibility)];errors+=1;counts['TD_errors']+=1;counts['nonzero_errors']+=error!=0
  if i+1==len(obs):creditterminal=[error*x for x in eligibility]
 actual=[a+p['eta']*b for a,b in zip(w,delta)]
 if e['method']=='fixed5':actual[0]=1.
 err=max(abs(a-b)for a,b in zip(actual,e['weights']));maxerr=max(maxerr,err);assert err<1e-10,(key,e['game'],err)
 assert errors==e['stats']['samples']and len(obs)==e['stats']['observed_searches']and used==e['nodes'];counts['episodes']+=1;counts['nonzero_updates']+=w!=e['weights'];counts['actual_terminal']+=e['outcome']is not None;counts['unknown']+=e['outcome']is None;counts['nodes']+=used;byarm[key]['episodes']+=1;byarm[key]['terminal_credit_l1']+=sum(map(abs,creditterminal));byarm[key]['P_terminal_credit_l1']+=abs(creditterminal[0]);byarm[key]['P_net_update_abs_sum']+=abs(e['weights'][0]-w[0])
assert nxt is None
train=json.loads((T/'result.json').read_bytes());assert counts['episodes']==train['episodes']==6512 and counts['queries']==95895 and counts['nodes']==6400000 and counts['nonzero_updates']==4494
for a in train['arms']:
 key=a['generator_seed'],a['method'],a['seed'];rows.append(dict(rule=key[0],method=key[1],seed=key[2],counts=dict(byarm[key]),observed_P_range=ranges[key],endpoint_P=a['weights'][0],endpoint_effective_temperature_if_pin_P=10/a['weights'][0],endpoint_norm=sqrt(sum(x*x for x in a['weights']))))
result=dict(status='PASS_PRIMARY_FORWARD_ALL91_TD_CREDITS',counts=dict(counts),arms=rows,max_endpoint_update_error=maxerr,max_fixedT_prediction_change=maxnorm,max_co_scaled_temperature_prediction_error=maxco,seconds=time.monotonic()-start,scope='PRIMARYforwardeligibility implementation fromrawall6512episodes/95895queries, independentfromownerreverseaudit/trainer. OriginalCore/sessionauthorityseparatelyreproducednotnewindependentengine. PositivePdivisionwithT10changespredictor; co-scaledT10/Ppreservespredictionidentity,NOTeta/update/trajectoryequivalence oruniquepriceproof. No newtraining/game/fit.');write_json(D/'forward-result.json',result);print(json.dumps({k:v for k,v in result.items()if k!='arms'}),flush=True)
