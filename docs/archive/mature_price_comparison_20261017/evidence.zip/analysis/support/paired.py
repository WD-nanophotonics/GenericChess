"""Independent paired utility and exposure-stratum arithmetic, no owner imports."""
from pathlib import Path
from collections import Counter
import json,sys,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/free-price-20261017';T=D/'exact/results/dev_aux';start=time.perf_counter();plan=json.loads((T/'task2535/plan.json').read_bytes());games=[json.loads(x)for x in(T/'task2535/games.jsonl').read_text().splitlines()];index={tuple(r['slot']):r for r in games};assert len(index)==len(plan['slots'])==1536

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
train=set()
for line in(T/'task2534/episodes.jsonl').open():
 e=json.loads(line);train.add((e['generator_seed'],digest(e['initial_record'])))
rootgroups={}
for r in games:
 assert r['reward']==(None if r['outcome']is None else r['outcome']*(1 if r['color']==0 else-1));rootgroups[r['generator_seed'],r['family']]=(r['generator_seed'],digest(r['initial_record']))in train

def pairs(foe,left,right,rules=None,stratum=None):
 out=[]
 for gs in plan['generator_seeds']if rules is None else rules:
  for seed in plan['initial_seeds']:
   for f in plan['families']:
    if stratum is not None and rootgroups[gs,f]!=stratum:continue
    for owner in(0,1):
     a=index[gs,seed,f,owner,left,foe];b=index[gs,seed,f,owner,right,foe];assert a['initial_record']==b['initial_record'];lo=hi=0
     for sign,r in((1,a),(-1,b)):
      if r['reward']is None:lo-=1;hi+=1
      else:lo+=sign*r['reward'];hi+=sign*r['reward']
     actsA=a['record']['actions'];actsB=b['record']['actions'];first=next((j for j,(u,v)in enumerate(zip(actsA,actsB))if u!=v),None)
     if first is not None:assert first%2==owner,'Samefoe/seedparentbutfirstdiffonfoeturn'
     else:assert actsA==actsB,'Unexplainedlength-onlyrecordchange'
     out.append(dict(rule=gs,seed=seed,family=f,owner=owner,bounds=[lo,hi],same_record=a['record']==b['record'],first_divergence_absolute_ply=first,left_reward=a['reward'],right_reward=b['reward']))
 return out

def summarize(rows):
 n=len(rows);return dict(cells=n,bounds=[sum(x['bounds'][j]for x in rows)/n for j in(0,1)]if n else None,same_records=sum(x['same_record']for x in rows),resolved_better=sum(x['bounds'][0]==x['bounds'][1]and x['bounds'][0]>0 for x in rows),resolved_worse=sum(x['bounds'][0]==x['bounds'][1]and x['bounds'][0]<0 for x in rows),unknown_pairs=sum(x['left_reward']is None or x['right_reward']is None for x in rows))
contrasts=[]
for foe in plan['opponents']:
 for left,right in(('fixed5','initial'),('free6','initial'),('free6','fixed5')):
  rows=pairs(foe,left,right);z=dict(foe=foe,left=left,right=right,**summarize(rows),per_rule={str(gs):summarize([r for r in rows if r['rule']==gs])for gs in plan['generator_seeds']},leave_one_rule_out={str(gs):summarize([r for r in rows if r['rule']!=gs])for gs in plan['generator_seeds']},current_TRAIN_overlap=summarize(pairs(foe,left,right,stratum=True)),not_in_saved_current_TRAIN_initial_record_set=summarize(pairs(foe,left,right,stratum=False)));contrasts.append(z)
interactions=[]
for left,right in(('fixed5','initial'),('free6','initial'),('free6','fixed5')):
 a=pairs('random99031',left,right);b=pairs('uniform',left,right);assert len(a)==len(b);lo=sum(x['bounds'][0]-y['bounds'][1]for x,y in zip(a,b))/len(a);hi=sum(x['bounds'][1]-y['bounds'][0]for x,y in zip(a,b))/len(a);interactions.append(dict(left=left,right=right,random_minus_uniform_gain_bounds=[lo,hi],scope='Fourphysicaloutcomes withUNKNOWNindependentunlessexplicitreuse; no samepastrecord policycoupling. Not populationconfidence/foeinvariance.'))
result=dict(status='PASS_PRIMARY_PAIRED_ALL1536_AND_EXPOSURE_STRATA',games=1536,root_families=len(rootgroups),overlap_families=sum(rootgroups.values()),outcomes=dict(Counter('U'if r['reward']is None else'W'if r['reward']==1 else'L'if r['reward']==-1 else'D'for r in games)),contrasts=contrasts,foe_interactions=interactions,seconds=time.perf_counter()-start,scope='IndependentPRIMARYarithmetic, ownerCore/sessionrecordsseparatelyexecuted. Alloriginal1536cells retained, no endpoint/seedselection/refit/newfitness. Strata/leave-one-rule-outarePOSTHOCdescriptivefragilitydiagnostics, NOTnewholdout/policy/exclusion/populationevidence. NoexactrecordoverlapdoesnotexcludePosition/olderexposure.');write_json(D/'paired-result.json',result);print(json.dumps(result,indent=2))
