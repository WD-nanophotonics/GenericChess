"""Explicit terminal score contract control; no production normalization."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.session.session import GameSession
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'mate-contract.json';assert not out.exists()
board=[[None]*8 for _ in range(8)]
for rank,file,owner,t in ((0,0,1,'K'),(0,2,0,'K'),(4,1,0,'R'),(1,5,0,'R')):board[rank][file]=Piece(owner,t,t,False)
definition=replace(build_western_chess_ruleset(),initial_position=tuple(tuple(row) for row in board))
compiled=compile_ruleset_for_execution(definition);native=compile_native_semantic_rules(compiled);s=GameSession(compiled)
class Static:
 def evaluate(self,state):
  return sum((1 if x.owner==state.position.side_to_move else -1) for x in state.position.board if x is not None)
r=dict(complete=False,declaration='Known sparse semantic mate fixture, depths1/2, unit static leaf, Core/native ordinary score and terminal convention reported raw; no historical reachability or numeric-normalization pass.',ruleset=ruleset_to_dict(definition),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cells=[]);write_record(out,r)
for depth in (1,2):
 start=time.perf_counter();score,a=reference_minimax(s.state,depth,Static(),compiled);reference_seconds=time.perf_counter()-start
 e=SemanticSearchEngine(compiled,native,board_values={t:1 for t in native.type_ids},hand_values={t:1 for t in native.type_ids},tt_megabytes=1)
 d=e.search(s,SearchLimits(max_depth=depth,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0));validate_pv(s,d)
 t=GameSession(compiled);t.submit(d.action)
 r['cells'].append(dict(depth=depth,reference_score=score,reference_action=record_value(a),reference_seconds=reference_seconds,native=record_value(d),raw_score_equal=score==d.score,native_selected_outcome=record_value(t.result)))
 write_record(out,r);print(depth,score,d.score,t.result,flush=True)
r['complete']=True;write_record(out,r)
