"""Independent board-transition enumeration, no producer move reuse."""
import sys,hashlib,itertools,json,importlib.util,time
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('producer',p/'census.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def targets(n,mode,s,board,owner):
    x,y=s%n,s//n
    for t in range(n*n):
        if t==s or board.get(t,(-1,''))[0]==owner:continue
        dx,dy=t%n-x,t//n-y
        if mode=='N':
            if sorted((abs(dx),abs(dy)))==[1,2]:yield t
            continue
        diagonal=abs(dx)==abs(dy);straight=dx==0 or dy==0
        if not ((mode=='Q' and (diagonal or straight)) or (mode=='B' and diagonal) or (mode=='R' and straight)):continue
        sx=0 if dx==0 else (1 if dx>0 else -1);sy=0 if dy==0 else (1 if dy>0 else -1)
        xx,yy=x+sx,y+sy;blocked=False
        while (xx,yy)!=(t%n,t//n):
            if xx+n*yy in board:blocked=True;break
            xx+=sx;yy+=sy
        if not blocked:yield t

def apply(board,s,t):
    child=dict(board);piece=child.pop(s);capture=child.pop(t,None);child[t]=piece
    return child,capture

def brute(n,a,o,s,e,v):
    board={s:(0,a),e:(1,o),v:(1,'inert')};first=[];second=[]
    for t in targets(n,a,s,board,0):
        child,capture=apply(board,s,t);gain=int(capture is not None);worst=0
        if e!=t:
            for u in targets(n,o,e,child,1):
                grand,victim=apply(child,e,u);worst=max(worst,int(victim is not None and victim[0]==0))
        first.append((gain-worst,gain,worst))
    for u in targets(n,o,e,board,1):
        child,capture=apply(board,e,u)
        if capture is not None:second.append((-1,0,1));continue
        gain=max((int(child.get(t,(-1,''))[0]==1) for t in targets(n,a,s,child,0)),default=0)
        second.append((gain,gain,0))
    # Same declared zero-cost pass when an action set is empty.
    if not second:
        gain=max((int(board.get(t,(-1,''))[0]==1) for t in targets(n,a,s,board,0)),default=0)
        second=[(gain,gain,0)]
    return max(first,key=lambda x:x[0],default=(0,0,0)),min(second,key=lambda x:x[0])

import random
rng=random.Random(2026100802);contexts=[tuple(rng.sample(range(64),3)) for _ in range(256)]
start=time.perf_counter();mismatches=[];checked=0;n=8
for a in ('Q','R','B','N'):
 for o in ('Q','R','B','N'):
  actor,opponent=m.build(n,a),m.build(n,o)
  for source,e,v in contexts:
   actual=m.two_orders(actor,opponent,source,e,v);expected=brute(n,a,o,source,e,v);checked+=1
   if actual!=expected:mismatches.append(dict(actor=a,opponent=o,source=source,enemy=e,victim=v,actual=actual,expected=expected))
raw=(p/'census-8x8.json').read_bytes();report=dict(complete=True,checked=checked,scope='256 prespecified deterministic contexts per16mode pairs, not full8x8 independent oracle',mismatches=mismatches,source_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seconds=time.perf_counter()-start)
write_record(p/'oracle-8x8.json',report);assert not mismatches;print('8x8',checked,'independent checks zero mismatch')
