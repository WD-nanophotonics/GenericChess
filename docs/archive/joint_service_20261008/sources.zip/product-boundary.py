"""Use the existing product compiler, not the raw semantic IR as evaluator API."""
import sys,time,json,hashlib,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'product-boundary.json';assert not out.exists()
raw=(ROOT/'.local_agent/direction-reset-20261008/recombined-verified.json').read_bytes();d=json.loads(raw)
r=dict(complete=False,declaration=dict(question='Does the existing execution compiler already resolve the raw-semantic-profile interface failure?',source_sha256=hashlib.sha256(raw).hexdigest(),cases='The same two recombined roots, original fixed generic-v1 evaluation, plain Python versus TT/order/native legality bundle, depth2,4096nodes/5sec/q0/root_tacticalfalse.',decision='Successful profile construction and equal complete scores narrow old interface failure to use of raw IR, not missing product architecture. No new adapter or evaluator.'),rows=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out,r)
for row in d['cases']:
    rules=ruleset_from_dict(row['ruleset']);start=time.perf_counter();compiled=compile_ruleset_for_execution(rules);compile_seconds=time.perf_counter()-start;session=GameSession(compiled)
    results=[]
    for optimized in (False,True):
        start=time.perf_counter();player=AlphaBetaPlayer(compiled,use_disk_cache=False,use_native_semantic_legality=optimized,use_tt=optimized,use_ordering=optimized,tuning=SearchTuning(use_root_tactical=False));setup=time.perf_counter()-start
        start=time.perf_counter();decision=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-start;validate_pv(session,decision)
        results.append(dict(optimized=optimized,setup_seconds=setup,search_seconds=elapsed,native_provider=player.native_legality_provider is not None,decision=record_value(decision)))
        print(row['blocked'],optimized,decision.completed_depth,decision.score,decision.nodes,setup,flush=True)
    assert all(x['decision']['completed_depth']==2 for x in results)
    assert results[0]['decision']['score']==results[1]['decision']['score']
    r['rows'].append(dict(blocked=row['blocked'],compiled_class=type(compiled).__name__,compile_seconds=compile_seconds,results=results));write_record(out,r)
r.update(complete=True,pv_legality_mismatches=0);write_record(out,r)
