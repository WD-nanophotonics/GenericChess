"""Preselected actual capture/hand/drop roots through existing reusable engine."""
import sys,time,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.movegen import legal_actions
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'recombined-history-completed.json';assert not out.exists()
source=(ROOT/'.local_agent/direction-reset-20261008/recombined-verified.json').read_bytes();data=json.loads(source)
r=dict(complete=False,declaration=dict(question='Does persistent supported native search agree with fresh TT across actual capture-to-hand, downgrade and drop histories?',source_sha256=hashlib.sha256(source).hexdigest(),root='previously declared open-leg5x5 rule',selection='Before search: sole J capture fromsource6; lexicographically first legal Black response leaving a legal White J drop; first legal White J drop. Four actual history roots. Search depth3/4,20000nodes/2sec/q0,1MiBTT, same ordinal leaf; reused then fresh then repeated reuse.',decision='Every result PV Core-legal. Equal completed-depth fresh/reused scores required; incomplete cells not parity evidence. No random population/strength/price claim.'),calls=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out,r)
row=next(x for x in data['cases'] if not x['blocked']);compiled=compile_semantic_ruleset(ruleset_from_dict(row['ruleset']));native=compile_native_semantic_rules(compiled)
session=GameSession(compiled);capture=next(a for a in session.legal_actions() if isinstance(a,SemanticBoardMove) and (a.from_square.file,a.from_square.rank)==(1,1) and a.actor_type_id=='J');session.submit(capture)
assert session.state.position.hands[0].count('J')==1
response=None;drop=None
for a in sorted(session.legal_actions(),key=str):
    temp=GameSession(compiled);temp.submit(capture);temp.submit(a)
    options=[b for b in temp.legal_actions() if isinstance(b,SemanticDropMove) and b.base_type_id=='J']
    if options:response=a;drop=sorted(options,key=str)[0];break
assert response is not None and drop is not None
actions=[capture,response,drop];r['preselected_actions']=record_value(actions);write_record(out,r)
engine=SemanticSearchEngine(compiled,native,tt_megabytes=1)
for ply in range(4):
    target=GameSession(compiled)
    for a in actions[:ply]:target.submit(a)
    r.setdefault('roots',[]).append(dict(ply=ply,position=record_value(target.state.position),history=record_value(target.state.history)))
    for depth in (3,4):
        limits=SearchLimits(max_depth=depth,max_nodes=20000,max_time_seconds=2,quiescence_max_depth=0)
        decisions=[]
        for label,current in (('reused',engine),('fresh',SemanticSearchEngine(compiled,native,tt_megabytes=1)),('warm',engine)):
            start=time.perf_counter();decision=current.search(target,limits);elapsed=time.perf_counter()-start
            state=target.state
            for action in decision.principal_variation:
                assert action in legal_actions(state,compiled);state=apply_action(state,action,compiled)
            if decision.action is not None:assert decision.action in target.legal_actions()
            decisions.append(decision);r['calls'].append(dict(ply=ply,depth=depth,label=label,wall_seconds=elapsed,decision=record_value(decision),tt=current.tt_info()));write_record(out,r)
            print(ply,depth,label,decision.completed_depth,decision.score,decision.nodes,elapsed,flush=True)
        complete=all(d.completed_depth==depth for d in decisions)
        if complete:assert len({d.score for d in decisions})==1
        r.setdefault('parity',[]).append(dict(ply=ply,depth=depth,complete=complete,score_equal=len({d.score for d in decisions})==1 if complete else None))
r.update(complete=True,pv_legality_mismatches=0);write_record(out,r)
