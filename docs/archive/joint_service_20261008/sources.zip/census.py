"""Exact small virtual two-player capture law, not a legal-game value law."""
import hashlib,itertools,json,sys,time
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
DIRS={'R':((1,0),(-1,0),(0,1),(0,-1)),
      'B':((1,1),(-1,1),(1,-1),(-1,-1)),
      'N':((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1))}
DIRS['Q']=DIRS['R']+DIRS['B']

def build(n,mode):
    rays=[]
    for s in range(n*n):
        row=[]
        for dx,dy in DIRS[mode]:
            path=[];x,y=s%n+dx,s//n+dy
            while 0<=x<n and 0<=y<n:
                path.append(x+n*y)
                if mode=='N':break
                x+=dx;y+=dy
            row.append(tuple(path))
        rays.append(tuple(row))
    return rays

def moves(rays,s,friendly,enemy):
    for ray in rays[s]:
        for t in ray:
            if t in friendly:break
            yield t
            if t in enemy:break

def contact(rays,s,e,v):
    return any(t==e or t==v for t in moves(rays,s,(),(e,v)))

def two_orders(actor,opponent,s,e,v):
    # No available action is a zero-reward pass in this partial virtual law.
    own=[]
    for t in sorted(moves(actor,s,(),(e,v))):
        gain=int(t==e or t==v)
        if t==e:own.append((gain,gain,0));continue
        victims=() if t==v else (v,)
        lost=int(any(u==t for u in moves(opponent,e,victims,(t,))))
        own.append((gain-lost,gain,lost))
    first=max(own,key=lambda x:x[0],default=(0,0,0))
    responses=[]
    for u in sorted(moves(opponent,e,(v,),(s,))):
        if u==s:responses.append((-1,0,1));continue
        gain=int(contact(actor,s,u,v))
        responses.append((gain,gain,0))
    second=min(responses,key=lambda x:x[0],default=(int(contact(actor,s,e,v)),int(contact(actor,s,e,v)),0))
    return first,second

def main():
    p=Path(__file__).parent;out=p/'census-tie-fixed.json';assert not out.exists()
    declaration=json.loads((p/'declaration.json').read_bytes())
    r=dict(complete=False,declaration=declaration,rows=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    write_record(out,r);start=time.perf_counter();n=4
    for a in ('Q','R','B','N'):
        for o in ('Q','R','B','N'):
            actor,opponent=build(n,a),build(n,o);roots=0;h1=0;hist=[{-1:0,0:0,1:0},{-1:0,0:0,1:0}];gross=[0,0];loss=[0,0]
            for s in range(n*n):
                flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
                for e,v in itertools.permutations((t for t in range(n*n) if t!=s),2):
                    roots+=1;h1+=int(contact(actor,s,e,v))
                    for i,(net,g,l) in enumerate(two_orders(actor,opponent,s,e,v)):
                        hist[i][net]+=1;gross[i]+=g;loss[i]+=l
            assert roots==3360 and all(sum(h.values())==roots for h in hist)
            row=dict(actor=a,opponent=o,roots=roots,contact_mean=Fraction(h1,roots),orders=[dict(order=name,histogram=h,net_mean=Fraction(gross[i]-loss[i],roots),gross_mean=Fraction(gross[i],roots),loss_mean=Fraction(loss[i],roots)) for i,(name,h) in enumerate(zip(('actor_first','opponent_first'),hist))])
            r['rows'].append(row);write_record(out,r);print(a,o,[str(x['net_mean']) for x in row['orders']],flush=True)
            if time.perf_counter()-start>300:raise RuntimeError('declared5min cost checkpoint; incomplete record retained')
    r.update(complete=True,seconds=time.perf_counter()-start,roots=sum(x['roots'] for x in r['rows']),core_transitions=0)
    write_record(out,r);print('complete',r['roots'],r['seconds'])
if __name__=='__main__':main()
