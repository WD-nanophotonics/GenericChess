"""Same explicit rule-derived static profile in Core and whole native search."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.session.session import GameSession
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'static-native-control.json';assert not out.exists()
configs=[('mixture0',json.loads((p/'mixture-rule-0.json').read_bytes())),('mixture1',json.loads((p/'mixture-rule-1.json').read_bytes())),('blocked',json.loads((p/'rule-blocked.json').read_bytes())),('open',json.loads((p/'rule-open.json').read_bytes()))]
# These exact Shogi counterfactual initial roots were independently qualified
# for current-pawn file counts, effects and full-history native/Core legal sets.
shogi=json.loads((p/'shogi-custody-nifu-safe.json').read_bytes())
configs += [('custody-'+('P' if row['promoted'] else 'G'),row['ruleset']) for row in shogi['rows']]
r=dict(complete=False,declaration=dict(question='Can the supported whole-native engine use the same explicit rule-derived static table as independent Core minimax?',cases=[name for name,_ in configs],profile='Existing generic-v1 rule-derived BOARD/HAND tables only, no dynamic terms. This is an interface/search control, not the contact prior, a hand-price law or a new default.',depths=[3,5],native='Fresh1MiB engine,20000nodes/5sec/q0, then repeat warm, same table each. Full PV Core-checked.',reference='Core exhaustive minimax, no native/TT;20000leaf/15sec checked at evaluation. References are not equal-resource speed competitors; unknown on fuse.',decision='Compare score only on completed same-depth reference/native cells, preserve all incompleteness. Label/type sorting cannot supply evaluation weights implicitly.'),rows=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out,r)
class Static:
 def __init__(self,board,hand):self.board=board;self.hand=hand
 def evaluate(self,state):
  pos=state.position;side=pos.side_to_move
  return sum(self.board[x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(self.hand[t]*n*(1 if owner==side else -1) for owner,h in enumerate(pos.hands) for t,n in h.counts)
for name,definition in configs:
 flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
 start=time.perf_counter();compiled=compile_ruleset_for_execution(ruleset_from_dict(definition));native=compile_native_semantic_rules(compiled);compile_seconds=time.perf_counter()-start
 start=time.perf_counter();profile=build_ruleset_profile(compiled,EvaluationConfig());profile_seconds=time.perf_counter()-start
 board,hand=dict(profile.board_value_by_type),dict(profile.hand_value_by_base_type);evaluator=Static(board,hand);session=GameSession(compiled)
 row=dict(name=name,definition=definition,compile_seconds=compile_seconds,profile_seconds=profile_seconds,board_values=board,hand_values=hand,cells=[]);r['rows'].append(row);write_record(out,r)
 for depth in (3,5):
  counted=CountedEvaluator(evaluator,seconds=15,evaluations=20000);start=time.perf_counter()
  try:
   score,action=reference_minimax(session.state,depth,counted,compiled);reference=dict(complete=True,score=score,action=record_value(action))
  except ReferenceLimit:reference=dict(complete=False,score=None,action=None)
  reference.update(seconds=time.perf_counter()-start,leaf_evaluations=counted.calls)
  engine=SemanticSearchEngine(compiled,native,board_values=board,hand_values=hand,tt_megabytes=1);calls=[]
  for repeat in (0,1):
   start=time.perf_counter();decision=engine.search(session,SearchLimits(max_depth=depth,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0));elapsed=time.perf_counter()-start;validate_pv(session,decision)
   equal=decision.score==reference['score'] if reference['complete'] and decision.completed_depth==depth else None
   if equal is not None:assert equal
   calls.append(dict(repeat=repeat,seconds=elapsed,decision=record_value(decision),reference_score_equal=equal))
  if all(x['decision']['completed_depth']==depth for x in calls):assert len({x['decision']['score'] for x in calls})==1
  row['cells'].append(dict(depth=depth,reference=reference,native_calls=calls));write_record(out,r)
  print(name,depth,'reference',reference['complete'],reference['leaf_evaluations'],reference['seconds'],'native',[(x['decision']['completed_depth'],x['decision']['score'],x['reference_score_equal']) for x in calls],flush=True)
r['complete']=True;write_record(out,r)
