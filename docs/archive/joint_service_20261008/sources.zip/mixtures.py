"""Tier1 familiar-movement mixtures through the same existing search entry."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.rules.schema import RuleSet,RuleSemanticAction,RuleGeometrySpec,RuleReplaceSelector,RuleActionEffect,RuleSquareRef,RuleInvariant,ruleset_to_dict
from scripts.unfamiliar_search import run_rule
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'mixtures.json';assert not out.exists()
layouts=[('R','B','N','K','G','S'),('B','G','R','K','S','N'),('S','N','G','K','R','B'),('G','R','S','K','B','N')]
r=dict(complete=False,declaration=dict(question='Does one product-boundary comparison entry support a tier1 familiar-movement mixture without a new engine?',layouts=layouts,design='6x6 two mirrored inventories: Chess R/B/eight-way N, Shogi G/S and one-step F forward movers, one K each. Front row6F, back row layout. Movement mixture only, not full Chess/Shogi special/promotion/drop rules. Equivalent quiet-anchor semantic ingress; same generic-v1 evaluation/plain and native-legality bundle.',depths=[2,3],cost='Existing entry4096nodes/5sec per search,4repeated calls/root/depth,reference4096leaf/5sec. Startup/profile separate; incomplete cells unknown.',decision='Core legal PVs and complete reference score parity; compare completed equal-depth resource observations, no strength/price tuning.'),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[]);write_record(out,r)
K=PieceType('K','anchor',tuple(LeapAtom((x,y)) for x in (-1,0,1) for y in (-1,0,1) if x or y),is_anchor=True)
R=PieceType('R','rook',tuple(RayAtom(d) for d in ((1,0),(-1,0),(0,1),(0,-1))))
B=PieceType('B','bishop',tuple(RayAtom(d) for d in ((1,1),(-1,1),(1,-1),(-1,-1))))
N=PieceType('N','Western knight',tuple(LeapAtom(d) for d in ((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1))))
G=PieceType('G','gold',tuple(LeapAtom(d) for d in ((0,1),(-1,1),(1,1),(-1,0),(1,0),(0,-1))))
S=PieceType('S','silver',tuple(LeapAtom(d) for d in ((0,1),(-1,1),(1,1),(-1,-1),(1,-1))))
F=PieceType('F','forward step',(LeapAtom((0,1)),))
action=RuleSemanticAction(name='anchor_quiet_ingress',type_ids=('K',),geometry=RuleGeometrySpec(kind='legacy_atoms',atom_kind='leap'),target_relation='empty',composition='replace_legacy',replace_selector=RuleReplaceSelector(type_ids=('K',),action_family='board',target_relation='empty',geometry_kind='leap',replace_all_matching=True),effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),),invariants=(RuleInvariant('own_anchor_safe'),))
for index,layout in enumerate(layouts):
 board=[[None]*6 for _ in range(6)]
 for x,tid in enumerate(layout):board[0][x]=Piece(0,tid,tid);board[5][5-x]=Piece(1,tid,tid)
 for x in range(6):board[1][x]=Piece(0,'F','F');board[4][x]=Piece(1,'F','F')
 rules=RuleSet(board_size=6,piece_types=(K,R,B,N,G,S,F),initial_position=tuple(tuple(row) for row in board),drop_allowed={t:((False,)*36,(False,)*36) for t in ('R','B','N','G','S','F')},semantic_actions=(action,),max_ply=128,repetition_limit=3)
 definition=ruleset_to_dict(rules);write_record(p/f'mixture-rule-{index}.json',definition)
 for depth in (2,3):
  path=p/f'mixture-{index}-depth{depth}.json';report=run_rule(path,definition,depth=depth)
  r['rows'].append(dict(index=index,depth=depth,path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),reference_complete=report['reference']['complete'],reference_score=report['reference']['score'],complete_searches=sum(x['complete'] for x in report['searches']),parity=[x['reference_score_equal'] for x in report['searches']]));write_record(out,r)
  print(index,depth,r['rows'][-1],flush=True)
r['complete']=True;write_record(out,r)
