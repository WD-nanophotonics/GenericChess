"""Full-history Core minimax for the declared actual recombined roots."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'history-oracle.json';assert not out.exists()
raw=(ROOT/'.local_agent/direction-reset-20261008/recombined-verified.json').read_bytes();source=json.loads(raw);prior=json.loads((p/'recombined-history-completed.json').read_bytes())
compiled=compile_ruleset_for_execution(ruleset_from_dict(next(x for x in source['cases'] if not x['blocked'])['ruleset']));native=compile_native_semantic_rules(compiled)
values={tid:i+1 for i,tid in enumerate(native.type_ids)}
class Ordinal:
    def evaluate(self,state):
        pos=state.position;side=pos.side_to_move
        return sum(values[x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(values[t]*n*(1 if o==side else -1) for o,h in enumerate(pos.hands) for t,n in h.counts)
session=GameSession(compiled);capture=next(a for a in session.legal_actions() if isinstance(a,SemanticBoardMove) and (a.from_square.file,a.from_square.rank)==(1,1) and a.actor_type_id=='J');session.submit(capture)
for response in sorted(session.legal_actions(),key=str):
 temp=GameSession(compiled);temp.submit(capture);temp.submit(response);drops=[a for a in temp.legal_actions() if isinstance(a,SemanticDropMove) and a.base_type_id=='J']
 if drops:drop=sorted(drops,key=str)[0];break
actions=[capture,response,drop]
r=dict(complete=False,declaration=dict(question='Do fresh/reused native scores agree with independent full-history Core minimax?',roots='Same four preselected actual histories, same ordinal debug leaf; no native legality or TT in reference.',budget='20000leaf evaluations/15sec checked at evaluation, per depth3/4 reference cell. These are reference fuses, not resource-matched speed comparisons.',decision='Every completed reference must equal previously retained native complete scores. Incomplete results remain unknown, no numeric parity claim.'),source_sha256=hashlib.sha256(raw).hexdigest(),rows=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out,r)
for ply in range(4):
 target=GameSession(compiled)
 for action in actions[:ply]:target.submit(action)
 for depth in (3,4):
  counted=CountedEvaluator(Ordinal(),seconds=15,evaluations=20000);start=time.perf_counter()
  try:
   score,action=reference_minimax(target.state,depth,counted,compiled);row=dict(complete=True,score=score,action=record_value(action))
  except ReferenceLimit:row=dict(complete=False,score=None,action=None)
  row.update(ply=ply,depth=depth,seconds=time.perf_counter()-start,leaf_evaluations=counted.calls)
  if row['complete']:
   expected=[x['decision']['score'] for x in prior['calls'] if x['ply']==ply and x['depth']==depth];assert len(set(expected))==1 and score==expected[0]
  r['rows'].append(row);write_record(out,r);print(row,flush=True)
r.update(complete=True);write_record(out,r)
