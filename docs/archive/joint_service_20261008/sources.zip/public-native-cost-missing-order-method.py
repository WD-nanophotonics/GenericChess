"""Two supported search entries, identical static tables/resource conditions."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import SemanticSearchEngine
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.session.session import GameSession
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'public-native-cost.json';assert not out.exists()
prior=json.loads((p/'static-native-control.json').read_bytes())
selected=['mixture0','open','custody-G']
r=dict(complete=False,declaration=dict(question='At the same declared node/time ceiling, what completed depth and ordinary score does each supported entry deliver with identical leaf tables?',cases=selected,depths=[3,5],conditions='Both20000nodes/5sec,q0,root tactics off, fresh TT each depth; cold/warm repeats. Static rule-derived tables pinned to previous control, no dynamic terms, fitting or price selection.',decision='Record all completion/cost/PV outcomes. Compare scores only at completed equal depth and ordinary-score units; terminal units remain explicit and different. Node definitions/TT layouts differ, so report rather than call this pure language speedup.'),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256((p/'static-native-control.json').read_bytes()).hexdigest(),rows=[]);write_record(out,r)
class Static:
 def __init__(self,b,h):self.board=b;self.hand=h
 def evaluate(self,state):
  pos=state.position;side=pos.side_to_move
  return sum(self.board[x.current_type_id]*(1 if x.owner==side else -1) for x in pos.board if x is not None)+sum(self.hand[t]*n*(1 if o==side else -1) for o,h in enumerate(pos.hands) for t,n in h.counts)
for name in selected:
 flags=json.loads((ROOT/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
 source=next(x for x in prior['rows'] if x['name']==name)
 start=time.perf_counter();c=compile_ruleset_for_execution(ruleset_from_dict(source['definition']));n=compile_native_semantic_rules(c);compile_seconds=time.perf_counter()-start
 session=GameSession(c);evaluator=Static(source['board_values'],source['hand_values'])
 row=dict(name=name,compile_seconds=compile_seconds,board_values=source['board_values'],hand_values=source['hand_values'],cells=[]);r['rows'].append(row);write_record(out,r)
 for depth in (3,5):
  start=time.perf_counter();public=AlphaBetaPlayer(c,evaluator_override=evaluator,use_disk_cache=False,use_native_semantic_legality=True,use_tt=True,use_ordering=True,tt_max_entries=16384,tuning=SearchTuning(use_root_tactical=False));public_setup=time.perf_counter()-start
  start=time.perf_counter();native=SemanticSearchEngine(c,n,board_values=source['board_values'],hand_values=source['hand_values'],tt_megabytes=1);native_setup=time.perf_counter()-start
  cell=dict(depth=depth,setup_seconds=dict(public=public_setup,native=native_setup),calls=[]);row['cells'].append(cell);write_record(out,r)
  for label,engine in (('public',public),('native',native)):
   for repeat in (0,1):
    start=time.perf_counter();limits=SearchLimits(max_depth=depth,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0)
    d=engine.choose_action(session,limits) if label=='public' else engine.search(session,limits)
    elapsed=time.perf_counter()-start;validate_pv(session,d)
    cell['calls'].append(dict(entry=label,repeat=repeat,seconds=elapsed,decision=record_value(d)));write_record(out,r)
    print(name,depth,label,repeat,d.completed_depth,d.score,d.nodes,elapsed,flush=True)
  scores=[x['decision']['score'] for x in cell['calls']]
  complete=all(x['decision']['completed_depth']==depth for x in cell['calls'])
  ordinary=all(abs(x)<100000000-10000 for x in scores)
  cell.update(all_complete=complete,ordinary_scores=ordinary,complete_ordinary_score_equal=len(set(scores))==1 if complete and ordinary else None);write_record(out,r)
  if cell['complete_ordinary_score_equal'] is not None:assert cell['complete_ordinary_score_equal']
r['complete']=True;write_record(out,r)
