"""Counterfactual base/current identity through real Shogi semantic effects."""
import sys,time,json,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'shogi-custody.json';assert not out.exists()
r=dict(complete=False,declaration=dict(question='Can same current Gold geometry but distinct captured base create different opponent continuation service?',design='Counterfactual40-entity9x9 roots under actual Standard Shogi mechanics. Move White G from3,0 to3,3, Black R from7,7 to3,5 and Black P from2,6 to1,5. Compare target G versus baseP/currentTP at3,3, otherwise same board. This replaces one base token; not asserted standard inventory/reachable history. Preserve all40 entities, no sparse reachable-game claim.',continuation='White0,2->0,3; BlackR3,5x3,3; White0,3->0,4; Black captured-base drop2,4; White1,2->1,3. Preselected before outcomes. Gold/TP initial tag move geometry compared, then exact capture reset/base hand/drop followed by next tag capture opportunity.',decision='Native/Core legal sets must agree at all actual continuation roots. Captured TP becomes P; G remains G. A distinct post-drop legal capture demonstrates custody liability not represented by same current-board contact histogram. No numeric compensation or complete price inference.',cost='2 roots x6full-history legal-set checks; no search/label fitting.'),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[]);write_record(out,r)
def coords(action):
 return ((action.from_square.file,action.from_square.rank),(action.to_square.file,action.to_square.rank),action.promotion_target_id) if isinstance(action,SemanticBoardMove) else None
def submit_board(session,start,end):
 action=next(a for a in session.legal_actions() if coords(a)==(start,end,None));session.submit(action);return action
for promoted in (False,True):
 rules=build_standard_shogi_ruleset();board=[list(row) for row in rules.initial_position]
 assert board[0][3].current_type_id=='G' and board[7][7].current_type_id=='R' and board[6][2].current_type_id=='P'
 board[3][3]=Piece(0,'P','TP',True) if promoted else board[0][3];board[0][3]=None
 board[5][3]=board[7][7];board[7][7]=None;board[5][1]=board[6][2];board[6][2]=None
 definition=replace(rules,initial_position=tuple(tuple(row) for row in board));compiled=compile_ruleset_for_execution(definition);native=compile_native_semantic_rules(compiled);session=GameSession(compiled)
 assert sum(x is not None for x in session.state.position.board)==40
 row=dict(promoted=promoted,ruleset=ruleset_to_dict(definition),root_tag_moves=sorted(coords(a) for a in session.legal_actions() if isinstance(a,SemanticBoardMove) and (a.from_square.file,a.from_square.rank)==(3,3)),states=[],actions=[])
 def check():
  raw=pack_semantic_search_position(compiled,native,session);actual=set(public_action(native,a) for a in guarded_actions(native,raw));expected=set(session.legal_actions());assert actual==expected
  row['states'].append(dict(ply=session.state.ply_count,position=record_value(session.state.position),history=record_value(session.state.history),legal_actions=record_value(sorted(expected,key=str)),native_core_legal_equal=True))
 check()
 for start,end in (((0,2),(0,3)),((3,5),(3,3)),((0,3),(0,4))):row['actions'].append(record_value(submit_board(session,start,end)));check()
 base='P' if promoted else 'G';assert session.state.position.hands[1].count(base)==1
 drop=next(a for a in session.legal_actions() if isinstance(a,SemanticDropMove) and a.base_type_id==base and (a.to_square.file,a.to_square.rank)==(2,4));session.submit(drop);row['actions'].append(record_value(drop));check()
 dropped=session.state.position.board[2+4*9];assert dropped.base_type_id==dropped.current_type_id==base and not dropped.promoted
 row['actions'].append(record_value(submit_board(session,(1,2),(1,3))));check()
 tag_actions=[a for a in session.legal_actions() if isinstance(a,SemanticBoardMove) and (a.from_square.file,a.from_square.rank)==(2,4)]
 row['post_drop_tag_actions']=record_value(tag_actions);row['can_capture_preselected_pawn']=any(coords(a)==((2,4),(1,3),None) for a in tag_actions)
 assert row['can_capture_preselected_pawn'] != promoted
 r['rows'].append(row);write_record(out,r);print(base,'initial moves',len(row['root_tag_moves']),'postdrop',len(tag_actions),'capture',row['can_capture_preselected_pawn'],flush=True)
assert r['rows'][0]['root_tag_moves']==r['rows'][1]['root_tag_moves']
r.update(complete=True,native_core_legal_mismatches=0);write_record(out,r)
