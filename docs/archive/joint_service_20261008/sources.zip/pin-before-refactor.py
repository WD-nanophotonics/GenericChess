"""Reconstruct the immediately preceding source and verify its recorded hash."""
import hashlib,json
from pathlib import Path
p=Path(__file__).parent;root=p.parents[1]
text=(root/'scripts/unfamiliar_search.py').read_text(encoding='utf-8')
start=text.index('def _compare_searches(');end=text.index('def run_rule(',start)
text=text[:start]+text[end:]
old_rule='''    report['repeat_equal'] = {}
    for optimized in (False, True):
        signatures = []
        for repeat in range(2):
            start = time.perf_counter()
            player = AlphaBetaPlayer(compiled, use_disk_cache=False, profile_cache=cache,
                use_native_semantic_legality=optimized, use_tt=optimized, use_ordering=optimized,
                evaluator_override=evaluator, tt_max_entries=4096,
                tuning=SearchTuning(use_root_tactical=False))
            setup = time.perf_counter()-start
            start = time.perf_counter()
            decision = player.choose_action(session, SearchLimits(max_depth=depth, max_nodes=4096,
                max_time_seconds=5, quiescence_max_depth=0, quiescence_hard_max_depth=0))
            observed = time.perf_counter()-start
            validate_pv(session, decision)
            signatures.append((record_value(decision.action), decision.score, decision.completed_depth))
            complete = decision.completed_depth == depth
            report['searches'].append(dict(optimized=optimized, repeat=repeat,
                setup_seconds=setup, observed_search_seconds=observed,
                native_provider_present=player.native_legality_provider is not None,
                complete=complete, reference_score_equal=(decision.score == report['reference']['score'])
                    if complete and report['reference']['complete'] else None,
                decision=record_value(decision)))
            write_record(output, report)
        report['repeat_equal']['public_bundle' if optimized else 'python_plain'] = signatures[0] == signatures[1]
'''
text=text.replace("    _compare_searches(session, evaluator, cache, report['reference'], depth, report,\n                      lambda: write_record(output, report))\n",old_rule)
old_generated='''        for optimized in (False, True):
            signatures = []
            for repeat in range(2):
                start = time.perf_counter()
                player = AlphaBetaPlayer(compiled, use_disk_cache=False,
                    profile_cache=cache,
                    use_native_semantic_legality=optimized, use_tt=optimized, use_ordering=optimized,
                    evaluator_override=evaluator, tt_max_entries=4096,
                    tuning=SearchTuning(use_root_tactical=False))
                setup_seconds = time.perf_counter()-start
                start = time.perf_counter()
                decision = player.choose_action(session, SearchLimits(max_depth=depth, max_nodes=4096,
                    max_time_seconds=5, quiescence_max_depth=0, quiescence_hard_max_depth=0))
                observed_search_seconds = time.perf_counter()-start
                validate_pv(session, decision)
                signatures.append((record_value(decision.action), decision.score, decision.completed_depth))
                complete = decision.completed_depth == depth
                case['searches'].append(dict(control='public_bundle' if optimized else 'python_plain',
                    repeat=repeat, setup_seconds=setup_seconds, observed_search_seconds=observed_search_seconds,
                    native_provider_present=player.native_legality_provider is not None,
                    complete=complete, reference_score_equal=(decision.score == reference['score']) if complete and reference['complete'] else None,
                    decision=record_value(decision)))
            case.setdefault('repeat_equal', {})['public_bundle' if optimized else 'python_plain'] = signatures[0] == signatures[1]
        report['cases'].append(case)
'''
text=text.replace("        report['cases'].append(case)\n        _compare_searches(session, evaluator, cache, reference, depth, case,\n                          lambda: write_record(output, report))\n",old_generated)
b=text.encode();expected=json.loads((p/'mixture-0-depth3.json').read_bytes())['producer_sha256']
assert hashlib.sha256(b).hexdigest()==expected,(hashlib.sha256(b).hexdigest(),expected)
out=p/'unfamiliar-search-before-shared-loop.py';assert not out.exists();out.write_bytes(b)
print('Exact preceding producer recovered',expected)
