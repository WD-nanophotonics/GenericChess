"""Selected Agent-produced portable evidence; private messages stay excluded."""
import sys,json,hashlib,zipfile,tempfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/joint_service_20261008';a.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda name:json.loads((p/name).read_bytes())
required=['census-tie-fixed.json','census-8x8.json','oracle.json','oracle-8x8.json','replacement.json','recombined-history-completed.json','history-oracle.json','product-boundary.json','mixtures.json','shogi-custody-nifu-safe.json','static-native-control.json','mate-contract.json','public-native-cost-standard-order.json']
assert all(load(n)['complete'] for n in required)
indexes={}
def archive(name,files):
 entries={};target=a/name;assert not target.exists()
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in files:
   b=f.read_bytes()
   assert n not in entries and '..' not in Path(n).parts and not Path(n).is_absolute()
   assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b)
   assert not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b)
   assert not re.search(rb'xox[baprs]-[A-Za-z0-9-]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',b)
   z.writestr(n,b);entries[n]=dict(bytes=len(b),sha256=sha(b))
 with tempfile.TemporaryDirectory(prefix='verify-',dir=p) as td,zipfile.ZipFile(target) as z:
  assert z.testzip() is None;z.extractall(td)
  for n,h in entries.items():assert sha((Path(td)/n).read_bytes())==h['sha256']
 indexes[name]=dict(sha256=sha(target.read_bytes()),entries=entries,physically_extracted_rehashed=True)
archive('raw.zip',[(f,f.name) for f in sorted(p.glob('*.json'))]+[(ROOT/'.local_agent/direction-reset-20261008/recombined-verified.json','dependencies/recombined-verified.json')])
archive('sources.zip',[(f,f.name) for f in sorted(p.glob('*.py'))]+[(ROOT/n,n) for n in ('scripts/unfamiliar_search.py','scripts/research_record.py','tests/development/test_unfamiliar_search.py','tests/rule_semantics_ir_fixtures.py','generic_chess/ai/evaluation/config.py')])
static=load('static-native-control.json');cost=load('public-native-cost-standard-order.json')
def decisions(calls):
 return [dict(**{k:v for k,v in call.items() if k!='decision'},decision={k:call['decision'][k] for k in ('completed_depth','score','nodes','tt_hits','termination_reason') if k in call['decision']}) for call in calls]
report=dict(complete=True,base_sha='01212db333f7c35c3da5511e80d86f99bc271bb6',scope='Exposed development. Virtual task/replacement utility, actual semantic custody/history and supported search-entry controls; no price fitting, default change, human holdout, universal optimum or strength claim.',
 census4=load('census-tie-fixed.json'),census8=load('census-8x8.json'),oracle4=load('oracle.json'),oracle8=load('oracle-8x8.json'),replacement=load('replacement.json'),
 history_reference=load('history-oracle.json'),history_reuse=dict(declaration=load('recombined-history-completed.json')['declaration'],parity=load('recombined-history-completed.json')['parity'],calls=decisions(load('recombined-history-completed.json')['calls'])),
 mixtures=load('mixtures.json'),custody=dict(declaration=load('shogi-custody-nifu-safe.json')['declaration'],native_core_legal_mismatches=load('shogi-custody-nifu-safe.json')['native_core_legal_mismatches'],rows=[dict(promoted=x['promoted'],root_tag_moves=x['root_tag_moves'],post_drop_tag_actions=x['post_drop_tag_actions'],can_capture_preselected_pawn=x['can_capture_preselected_pawn'],history_states=len(x['states'])) for x in load('shogi-custody-nifu-safe.json')['rows']]),
 static_search=dict(declaration=static['declaration'],rows=[dict(name=x['name'],compile_seconds=x['compile_seconds'],profile_seconds=x['profile_seconds'],cells=[dict(depth=c['depth'],reference=c['reference'],native_calls=decisions(c['native_calls'])) for c in x['cells']]) for x in static['rows']]),
 cost_search=dict(declaration=cost['declaration'],rows=[dict(name=x['name'],cells=[dict(**{k:v for k,v in c.items() if k!='calls'},calls=decisions(c['calls'])) for c in x['cells']]) for x in cost['rows']]),
 mate_contract=load('mate-contract.json'),
 qualifications=['First census tie, runtime/public action field, duplicate-current-pawn Shogi, and missing/custom capture-order method sources/results retained separately.','Mate raw-score units differ across APIs; old ordinary parity is not terminal-scale parity.','Old custom capture-order cost record is retained; only standard-order record supports the reported product-order comparison.','Product Core/evaluation/search defaults unchanged; existing product compiler used. Shared small development comparison loop and --rules input added.'],archives=indexes)
out=ROOT/'docs/research/data/joint_service_20261008.json';assert not out.exists();write_record(out,report)
write_record(a/'index.json',dict(portable_sha256=sha(out.read_bytes()),archives=indexes,authorship='Agent-generated sources/results only; no raw Slack, user input, credentials or machine state'))
print('Extracted/rehashed',sum(len(x['entries']) for x in indexes.values()),'archive members;',len(out.read_bytes()),'portable bytes')
