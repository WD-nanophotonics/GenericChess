"""Paired replacement contributions, not compensating inventory prices."""
import sys,itertools,json,time,hashlib,importlib.util
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'replacement.json';assert not out.exists()
spec=importlib.util.spec_from_file_location('producer',p/'census.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
declaration=dict(question='How concentrated/context-dependent is matched replacement reward, and does a nested-action consistency claim hold?',design='Reuse exact4x4 context law and two action orders. Compare Q-R (nested action sets) and B-N (not nested), same source/activeenemy/victim/opponent type. No removal, price fitting, phase tuning or label access.',decision='Q-R negative root differences indicate implementation error under this exact equal-payoff nested-action law. B-N signed reversals demonstrate that aggregate ordering is not pointwise contribution. Strata and zeros are retained; these are relative task contributions, not price ratios.',cost='26880 paired roots, one process, no new model/census/population. New per-context projection needed because previous census retained only aggregates.')
r=dict(complete=False,declaration=declaration,rows=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out,r);start=time.perf_counter()
for a,b in (('Q','R'),('B','N')):
 for o in ('Q','R','B','N'):
  ar,br,enemy=m.build(4,a),m.build(4,b),m.build(4,o);hist=[{i:0 for i in range(-2,3)} for _ in range(2)];witnesses=[{},{}]
  for s,e,v in itertools.permutations(range(16),3):
   av,bv=m.two_orders(ar,enemy,s,e,v),m.two_orders(br,enemy,s,e,v)
   for i in (0,1):
    delta=av[i][0]-bv[i][0];hist[i][delta]+=1
    if delta and str(delta) not in witnesses[i]:witnesses[i][str(delta)]=dict(source=s,enemy=e,victim=v,left=av[i],right=bv[i])
    if a=='Q':assert delta>=0
  r['rows'].append(dict(left=a,right=b,opponent=o,roots=3360,orders=[dict(order=label,histogram=h,mean=Fraction(sum(k*v for k,v in h.items()),3360),witnesses=witnesses[i]) for i,(label,h) in enumerate(zip(('actor_first','opponent_first'),hist))]));write_record(out,r)
  print(a,b,o,[str(x['mean']) for x in r['rows'][-1]['orders']],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start,Q_R_negative_roots=0);write_record(out,r)
