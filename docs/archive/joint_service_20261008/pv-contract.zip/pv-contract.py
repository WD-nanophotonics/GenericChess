"""Interpret already observed cache cost without changing search defaults."""
import sys,json,hashlib,zipfile,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;raw=p/'public-native-cost-standard-order.json';d=json.loads(raw.read_bytes())
rows=[]
for row in d['rows']:
 for c in row['cells']:
  rows.append(dict(name=row['name'],target_depth=c['depth'],all_complete=c['all_complete'],calls=[dict(entry=x['entry'],repeat=x['repeat'],seconds=x['seconds'],completed_depth=x['decision']['completed_depth'],nodes=x['decision']['nodes'],pv_length=len(x['decision']['principal_variation']),score=x['decision']['score']) for x in c['calls']]))
out=ROOT/'docs/research/data/search_pv_contract_20261008.json';assert not out.exists()
report=dict(complete=True,question='Does warm exact-root timing deliver equivalent PV output?',source_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,
 explanation='Five fully completed warm public cells return zero-length PV with legal selected action and matching score; native retains full-depth PV. Core negamax returns exact TT score/action with empty PV. Native gates TT cutoffs on non-PV nodes and re-searches selected principal branches with full PV windows. This is an output/caching tradeoff, not evidence of failed native reuse or pure execution-speed difference.',
 source_pins={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ('generic_chess/ai/alphabeta/search.py','generic_chess/_native/native_module.c')},
 next='Before changing warm-root behavior, specify whether callers need full canonical PV or just score/action and preserve complete history/evaluator identity. No production optimization selected.')
write_record(out,report)
a=ROOT/'docs/archive/joint_service_20261008';target=a/'pv-contract.zip';assert not target.exists();entries={}
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for f,n in ((Path(__file__),'pv-contract.py'),(out,'search_pv_contract_20261008.json')):
  b=f.read_bytes();z.writestr(n,b);entries[n]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with tempfile.TemporaryDirectory(prefix='verify-',dir=p) as td,zipfile.ZipFile(target) as z:
 assert z.testzip() is None;z.extractall(td)
 for n,h in entries.items():assert hashlib.sha256((Path(td)/n).read_bytes()).hexdigest()==h['sha256']
index=json.loads((a/'index.json').read_bytes());index['archives']['pv-contract.zip']=dict(sha256=hashlib.sha256(target.read_bytes()).hexdigest(),entries=entries,physically_extracted_rehashed=True);index['pv_contract_sha256']=hashlib.sha256(out.read_bytes()).hexdigest();write_record(a/'index.json',index)
print('Five completed warm public PVs empty; native full-depth;2 supplement members extracted/rehashed')
