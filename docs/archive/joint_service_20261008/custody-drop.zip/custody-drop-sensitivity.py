"""All common drop destinations in the already qualified custody context."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'custody-drop-sensitivity.json';assert not out.exists()
raw=p/'shogi-custody-nifu-safe.json';source=json.loads(raw.read_bytes())
r=dict(complete=False,declaration=dict(question='Is the single chosen custody capture contrast typical of all common legal drop squares in that same context?',design='Replay qualified matched G/P roots through the same three legal pre-drop plies. Enumerate all common legal drop destinations; retain only those where the fixed White1,2->1,3 reply is legal in both branches. Then compare next tagged legal/capture actions, with no reward weights or averaging law selected.',decision='Count positive/zero/negative capture-opportunity contrasts and explicit exclusions before interpreting the one selected witness. A minority contrast narrows scope, not disproves the mechanism. Conditional common-drop population is not a reachable-game distribution or a price/strategy estimator.',cost='One finite paired drop population, exact Core/native legal-set checks, no search/fit.'),source_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],native_checks=0);write_record(out,r)
def coords(a):return ((a.from_square.file,a.from_square.rank),(a.to_square.file,a.to_square.rank),a.promotion_target_id) if isinstance(a,SemanticBoardMove) else None
def step(s,start,end):s.submit(next(a for a in s.legal_actions() if coords(a)==(start,end,None)))
prefix=[((0,2),(0,3)),((3,5),(3,3)),((0,3),(0,4))]
compiled=[compile_ruleset_for_execution(ruleset_from_dict(x['ruleset'])) for x in source['rows']]
native=[compile_native_semantic_rules(c) for c in compiled]
def root(i):
 s=GameSession(compiled[i])
 for start,end in prefix:step(s,start,end)
 return s
drops=[]
for i,base in enumerate(('G','P')):
 s=root(i);drops.append({(a.to_square.file,a.to_square.rank):a for a in s.legal_actions() if isinstance(a,SemanticDropMove) and a.base_type_id==base})
common=sorted(drops[0].keys() & drops[1].keys());r.update(drop_counts=dict(G=len(drops[0]),P=len(drops[1]),common=len(common)));write_record(out,r);start_time=time.perf_counter()
def check(s,i):
 expected=set(s.legal_actions());actual=set(public_action(native[i],a) for a in guarded_actions(native[i],pack_semantic_search_position(compiled[i],native[i],s)))
 assert expected==actual;r['native_checks']+=1
for square in common:
 sessions=[root(i) for i in (0,1)]
 for i,s in enumerate(sessions):s.submit(drops[i][square]);check(s,i)
 replies=[[a for a in s.legal_actions() if coords(a)==((1,2),(1,3),None)] for s in sessions]
 row=dict(square=square,fixed_reply_legal=[bool(x) for x in replies])
 if all(replies):
  observations=[]
  for i,s in enumerate(sessions):
   s.submit(replies[i][0]);check(s,i)
   actions=[a for a in s.legal_actions() if isinstance(a,SemanticBoardMove) and coords(a)[0]==square]
   captures=[a for a in actions if s.state.position.board[a.to_square.file+9*a.to_square.rank] is not None]
   observations.append(dict(base=('G','P')[i],tag_actions=record_value(actions),capture_actions=record_value(captures),tag_action_count=len(actions),capture_count=len(captures)))
  row.update(qualified=True,observations=observations,capture_difference=observations[0]['capture_count']-observations[1]['capture_count'])
 else:row.update(qualified=False,exclusion='The predeclared identical reply is not legal in both contexts; no branch-specific repair.')
 r['rows'].append(row);write_record(out,r)
hist={'positive':0,'zero':0,'negative':0,'excluded':0}
for row in r['rows']:
 if not row['qualified']:hist['excluded']+=1
 else:hist['positive' if row['capture_difference']>0 else 'negative' if row['capture_difference']<0 else 'zero']+=1
r.update(complete=True,histogram=hist,seconds=time.perf_counter()-start_time);write_record(out,r);print(r['drop_counts'],hist,'nativechecks',r['native_checks'],r['seconds'])
