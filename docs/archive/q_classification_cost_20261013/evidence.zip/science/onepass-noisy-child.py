def noisy_child(
    action: Action, child, side: int, parent_enemies: int,
    parent_inventory: dict[tuple[int, str], int] | None,
    child_in_check: Callable[[], bool], stats: SearchStatistics | None = None,
    *, capture_only: bool = False, legacy_kind: str | None = None,
) -> bool:
    """One shared policy for an already applied child, including runtime views.

    Parent counts/kind must be copied before a mutable push. Check is lazy so
    material/terminal inclusion never pays for a second attack query.
    """
    if legacy_kind == "promotion":
        if stats is not None:
            stats.promotion_qactions += 1
        return True
    if legacy_kind == "capture":
        if stats is not None:
            stats.capture_qactions += 1
        return True
    if parent_inventory is None:
        if enemy_board_count(child.position, side) < parent_enemies:
            if stats is not None:
                stats.capture_qactions += 1
            return True
    else:
        enemies = 0
        counts = {}
        for piece in child.position.board:
            if piece is not None:
                enemies += piece.owner != side
                key = (piece.owner, piece.current_type_id)
                counts[key] = counts.get(key, 0) + 1
        if enemies < parent_enemies:
            if stats is not None:
                stats.capture_qactions += 1
            return True
        for owner, hand in enumerate(child.position.hands):
            for type_id, count in hand.items():
                key = (owner, type_id)
                counts[key] = counts.get(key, 0) + count
        if counts != parent_inventory:
            if stats is not None:
                stats.material_change_qactions += 1
                if action_promotion_target_id(action) is not None:
                    stats.promotion_qactions += 1
            return True
    if child.terminal_status.is_terminal:
        return True
    if capture_only:
        return False
    if child_in_check():
        if stats is not None:
            if action_is_drop(action):
                stats.checking_drop_qactions += 1
            else:
                stats.checking_move_qactions += 1
        return True
    if action_is_drop(action) and stats is not None:
        stats.nonchecking_drop_excluded += 1
    return False
