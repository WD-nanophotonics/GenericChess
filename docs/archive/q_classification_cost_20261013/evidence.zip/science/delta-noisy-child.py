def noisy_child(
    action: Action, child, side: int, parent_enemies: int,
    parent_inventory: dict[tuple[int, str], int] | None,
    child_in_check: Callable[[], bool], stats: SearchStatistics | None = None,
    *, capture_only: bool = False, legacy_kind: str | None = None, parent_position=None,
) -> bool:
    """One shared policy for an already applied child, including runtime views.

    Parent counts/kind must be copied before a mutable push. Check is lazy so
    material/terminal inclusion never pays for a second attack query.
    """
    if legacy_kind == "promotion":
        if stats is not None:
            stats.promotion_qactions += 1
        return True
    if parent_position is None or parent_inventory is None or legacy_kind is not None:
        return baseline_noisy(action, child, side, parent_enemies, parent_inventory,
            child_in_check, stats, capture_only=capture_only, legacy_kind=legacy_kind)
    if len(parent_position.board) != len(child.position.board):
        return baseline_noisy(action, child, side, parent_enemies, parent_inventory,
            child_in_check, stats, capture_only=capture_only, legacy_kind=legacy_kind)
    counts = dict(parent_inventory)
    enemy_delta = 0
    for before, after in zip(parent_position.board, child.position.board):
        if before is after:
            continue
        if before is not None:
            enemy_delta -= before.owner != side
            key = (before.owner, before.current_type_id)
            counts[key] -= 1
        if after is not None:
            enemy_delta += after.owner != side
            key = (after.owner, after.current_type_id)
            counts[key] = counts.get(key, 0) + 1
    if enemy_delta < 0:
        if stats is not None:
            stats.capture_qactions += 1
        return True
    for owner, (before, after) in enumerate(zip(parent_position.hands, child.position.hands)):
        if before is after:
            continue
        for type_id, count in before.items():
            key = (owner, type_id)
            counts[key] -= count
        for type_id, count in after.items():
            key = (owner, type_id)
            counts[key] = counts.get(key, 0) + count
    # Old inventory keeps explicit zero hand keys; absence and zero are distinct.
    for key in tuple(counts):
        if counts[key] == 0 and not any(t == key[1] for t,c in child.position.hands[key[0]].items()):
            del counts[key]
    if counts != parent_inventory:
        if stats is not None:
            stats.material_change_qactions += 1
            if action_promotion_target_id(action) is not None:
                stats.promotion_qactions += 1
        return True
    if child.terminal_status.is_terminal:
        return True
    if capture_only:
        return False
    if child_in_check():
        if stats is not None:
            if action_is_drop(action):
                stats.checking_drop_qactions += 1
            else:
                stats.checking_move_qactions += 1
        return True
    if action_is_drop(action) and stats is not None:
        stats.nonchecking_drop_excluded += 1
    return False
