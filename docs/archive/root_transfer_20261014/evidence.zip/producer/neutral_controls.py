from pathlib import Path
import sys,json,ast,hashlib
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result
from generic_chess.rules.schema import RuleDeclaration,RuleWeightedMaterialMetric,RuleDeclarationOutcomeBand
from generic_chess.rules.serialization import serialize_ruleset
from scripts.full_q_refresh_comparison import compile_legacy_ruleset_for_semantic_execution,SearchMetadataAdapter,GameSession
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.declarations import available_declarations
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
b=ROOT/'.local_agent/root-transfer-20261014';out=b/'neutral-controls';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
raw=(b/'search-before-no-contest.py').read_bytes();names=('negamax','_quiescence_runtime','quiescence','reference_minimax')
nodes=[n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name in names];scope={}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'<before-neutral-fix>','exec'),sm.__dict__,scope);new={n:getattr(sm,n) for n in names}
write_record(out/'declaration.json',dict(question='Does the neutral option fix preserve winning opportunities when NO_CONTEST is unqualified while excluding false proofs when it is available?',guards=[False,True],tunings=['default','pvs','aspirationD2delta1','combined'],caps=[99,100000],q=2,hardq=8,max_depth=2,arms=['old_missing_NO_CONTEST','fixed'],warm_repetitions=2,max_calls=64,max_seconds_per_query=5,scope='Finite same-root rule intervention. Independent H3 oracle includes actual defender neutral declarations; no PV labels, synthetic TT, price tuning or default changes.',old_sha256=hashlib.sha256(raw).hexdigest(),new_sha256=hashlib.sha256((ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()).hexdigest()))
rows=[];samples=[];labels={}
def goal(s,a):
 child=apply_action(s.state,a,s.compiled);side=s.state.position.side_to_move
 if child.terminal_status.is_terminal:return child.terminal_status.winner==side
 if any(x.outcome in ('WIN','RESTART','NO_CONTEST') for x in available_declarations(child,s.compiled)):return False
 replies=legal_actions(child,s.compiled);assert replies
 return all(any(apply_action(after,win,s.compiled).terminal_status.winner==side for win in legal_actions(after,s.compiled)) for after in (apply_action(child,reply,s.compiled) for reply in replies))
try:
 for guard in (False,True):
  r=make_ruleset(4,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1)),RayAtom((1,0)),RayAtom((-1,0)))],lines=['....','...R','....','.k.K'])
  r=replace(r,declarations=(RuleDeclaration(declaration_id='defender_neutral',owner=1,require_not_in_check=guard,weighted_metric=RuleWeightedMaterialMetric(weights={'K':1}),outcome_bands=(RuleDeclarationOutcomeBand(1,'NO_CONTEST'),)),))
  x=compile_legacy_ruleset_for_semantic_execution(r);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c);pos=replace(s.state.position,hands=(Hands((('R',1),)),Hands()));k=position_identity_key(pos,c);st=replace(s.state,position=pos,history=(HistoryRecord(k,-1,'',False),),repetition_counts=((k,1),));s._state=replace(st,terminal_status=terminal_result(st,c));s._search_history_witnesses=(pos,)
  samples.append(dict(require_not_in_check=guard,ruleset=json.loads(serialize_ruleset(r)),state=record_value(s.state),witnesses=record_value(s._search_witnesses)))
  before=s.state,s.to_record(),s._search_witnesses
  for name,tuning in [('default',SearchTuning()),('pvs',SearchTuning(use_pvs=True)),('aspiration',SearchTuning(use_aspiration=True,aspiration_start_depth=2,aspiration_delta=1)),('combined',SearchTuning(use_pvs=True,use_aspiration=True,aspiration_start_depth=2,aspiration_delta=1,use_mate_distance_pruning=True))]:
   for cap in (99,100000):
    for arm in ('old_missing_NO_CONTEST','fixed'):
     for n in names:setattr(sm,n,scope[n] if arm.startswith('old') else new[n])
     player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,tuning=tuning)
     for rep in range(2):
      d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=cap,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8))
      assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
      key=(guard,json.dumps(record_value(d.action),sort_keys=True))
      if key not in labels:labels[key]=goal(s,d.action)
      proved=labels[key];false=d.score>=900000000 and not proved
      if arm=='fixed':assert not false and (guard or d.score<900000000)
      rows.append(dict(guard=guard,tuning=name,cap=cap,arm=arm,warm=bool(rep),decision=record_value(d),independent_full_defense_h3=proved,false_win=false,history_unchanged=True))
 write_record(out/'samples.json',samples);write_record(out/'rows.json',dict(complete=True,rows=rows,unique_labeled_actions=len(labels)))
 print('closed',len(rows),'old false wins',sum(x['false_win'] for x in rows if x['arm'].startswith('old')),'fixed false wins',sum(x['false_win'] for x in rows if x['arm']=='fixed'),'fixed true wins',sum(x['decision']['score']>=900000000 for x in rows if x['arm']=='fixed'))
finally:
 for n,v in new.items():setattr(sm,n,v)

