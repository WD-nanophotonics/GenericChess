from pathlib import Path
import sys,json
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from dataclasses import replace
from test_completed_root_win import prepared,proves_root_h3
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom
from generic_chess.core.identity import position_identity_key
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.terminal import terminal_result
from scripts.full_q_refresh_comparison import compile_legacy_ruleset_for_semantic_execution,SearchMetadataAdapter,GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/root-transfer-20261014/fallback';out.mkdir(exist_ok=True)
write_record(out/'declaration.json',dict(question='Do unavailable, operational-failure and max-ply capability-decline paths preserve proof/stop identity without misreporting Native?',modes=['unavailable','failure_after3attempts','maxply2_decline'],caps=[98,99,100000],reference='Core with identical rules/root',planned_calls=18,seconds=5,scope='Fault injection only within this producer; no OS/security or product edits.'))
rows=[]
def short():
 r=make_ruleset(4,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1)),RayAtom((1,0)),RayAtom((-1,0)))],lines=['....','...R','....','.k.K'],max_ply=2)
 x=compile_legacy_ruleset_for_semantic_execution(r);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)
 s=GameSession(c);pos=replace(s.state.position,hands=(Hands((('R',1),)),Hands()))
 k=position_identity_key(pos,c);st=replace(s.state,position=pos,history=(HistoryRecord(k,-1,'',False),),repetition_counts=((k,1),))
 s._state=replace(st,terminal_status=terminal_result(st,c));s._search_history_witnesses=(pos,);return s
for mode in ('unavailable','failure_after3attempts','maxply2_decline'):
 for cap in (98,99,100000):
  pair=[]
  for candidate in (False,True):
   s=short() if mode=='maxply2_decline' else prepared();before=(s.state,s.to_record(),s._search_witnesses)
   p=AlphaBetaPlayer(s.compiled,use_disk_cache=False,use_native_semantic_legality=candidate)
   attempted=[0]
   if candidate and mode=='unavailable':p._native_legality_provider=None
   if candidate and mode=='failure_after3attempts':
    original=p._native_legality_provider;assert original is not None
    def fault(position,ply,checkpoint=None):
     attempted[0]+=1
     if attempted[0]==3:raise ValueError('controlled provider fault after2 actualNative successes')
     return original(position,ply,checkpoint)
    p._native_legality_provider=fault
   d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=cap,max_time_seconds=5,quiescence_max_depth=2))
   assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
   h3=proves_root_h3(s,d.action)
   row=dict(mode=mode,cap=cap,candidate=candidate,decision=record_value(d),h3=h3,attempts=attempted[0],history_unchanged=True)
   if candidate and mode=='failure_after3attempts':assert attempted[0]==3 and d.native_legality_calls==2 and d.native_legality_fallbacks==d.native_legality_operational_failures==1
   if candidate and mode=='unavailable':assert d.native_legality_calls==0
   if mode=='maxply2_decline':assert d.native_legality_operational_failures==0
   rows.append(row);pair.append(d)
  fields=('action','score','principal_variation','completed_depth','termination_reason','result_source','result_ordinary_qdepth','result_check_hard_qdepth','nodes','qnodes')
  assert all(getattr(pair[0],f)==getattr(pair[1],f) for f in fields),(mode,cap)
  print(mode,cap,pair[1].result_source,pair[1].native_legality_calls,pair[1].native_legality_fallbacks)
write_record(out/'rows.json',dict(complete=True,rows=rows))

