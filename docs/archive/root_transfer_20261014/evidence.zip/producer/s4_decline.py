from pathlib import Path
import sys
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from rule_semantics_ir_fixtures import uchifuzume_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
class Zero:
 def evaluate(self,state):return 0
rows=[]
for limit in (1,2,3):
 c=compile_ruleset_for_execution(replace(uchifuzume_ruleset(),max_ply=limit));s=GameSession(c)
 pos=replace(s.state.position,hands=(Hands((('P',1),)),Hands()));key=position_identity_key(pos,c)
 st=replace(s.state,position=pos,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),))
 s._state=replace(st,terminal_status=terminal_result(st,c));s._search_history_witnesses=(pos,)
 pair=[]
 for native in (False,True):
  before=s.state,s.to_record(),s._search_witnesses
  p=AlphaBetaPlayer(c,evaluator_override=Zero(),use_native_semantic_legality=native,use_disk_cache=False,use_ordering=False)
  d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=5,quiescence_max_depth=2))
  assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
  if native:assert p.native_legality_provider is not None and d.native_legality_fallbacks>0 and d.native_legality_operational_failures==0
  pair.append(d);rows.append(dict(max_ply=limit,native=native,decision=record_value(d),history_unchanged=True))
  write_record(ROOT/'.local_agent/root-transfer-20261014/s4-decline-partial.json',dict(rows=rows,complete=False))
 for key in ('action','score','principal_variation','completed_depth','termination_reason','nodes','qnodes','result_source'):
  assert getattr(pair[0],key)==getattr(pair[1],key),(limit,key)
 print(limit,pair[1].native_legality_calls,pair[1].native_legality_fallbacks,pair[1].result_source)
write_record(ROOT/'.local_agent/root-transfer-20261014/s4-decline.json',dict(rows=rows,scope='S4 reply-guard actual Native per-state capability decline; prior no-S4 maxply2 cohort hadzero declines and is only a terminal-horizon negative control. No failure invented.'))

