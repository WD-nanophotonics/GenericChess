from pathlib import Path
import sys,json,time,cProfile,pstats,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'.local_agent/geometry-prefix-20261014')]
from drop_fixture import make,p
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/root-transfer-20261014/profile';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='After useful Native input sharing, which actual caller layer should receive the next optimization effort?',roots=['knownH3-16','2054-ply8','transformed_live_aux','compound_shift'],arms=['normal','cProfile'],nodes=8192,seconds=30,max_depth=12,q=2,hardq=8,planned_calls=8,scope='Diagnostic profiler overhead is reported, not speedup. Actual non-timing results/work must match before interpreting categories. Cumulative times overlap and are never summed as disjoint percentages. Raw profiles private; sanitized function-level summaries may be published. No new backend/interface or default change.'))
roots=[];_,c,s=make(16);cfg=p.EvaluationConfig();roots.append(('knownH3-16',c,s,p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg)))
sample=next(x for x in json.loads((out.parent/'generated/samples.json').read_text(encoding='utf-8'))['samples'] if x.get('name')=='2054-ply8')
r=deserialize_ruleset(json.dumps(sample['ruleset']));x=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c)
for a in sample['walk']:
 match,=[x for x in s.legal_actions() if record_value(x)==a];s.submit(match)
assert record_value(s.state)==sample['state']
roots.append(('2054-ply8',c,s,p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg)))
for sample in json.loads((out.parent/'semantic/samples.json').read_text(encoding='utf-8'))['rows']:
 if sample['name'] not in ('transformed_live_aux','compound_shift'):continue
 c=compile_ruleset_for_execution(deserialize_ruleset(json.dumps(sample['ruleset'])));s=GameSession(c)
 for a in deserialize_game_record(json.dumps(sample['game_record'])).actions:s.submit(a)
 class EqualMaterial:
  def __init__(self,c):self.v={tid:0 if t.is_anchor else 1000 for tid,t in c.support.type_metadata.items()}
  def type_value(self,tid):return self.v[tid]
  def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
  def evaluate(self,state):
   pos=state.position
   return sum((1 if z.owner==pos.side_to_move else -1)*self.v[z.current_type_id] for z in pos.board if z)+sum((1 if owner==pos.side_to_move else -1)*self.v[tid]*count for owner,hand in enumerate(pos.hands) for tid,count in hand.counts)
 roots.append((sample['name'],c,s,EqualMaterial(c)))
rows=[]
for name,c,s,ev in roots:
 before=s.state,s.to_record(),s._search_witnesses;pair=[]
 for instrumented in (False,True):
  p.rr.stopped();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_native_semantic_check=True)
  prof=cProfile.Profile();t=time.perf_counter()
  if instrumented:prof.enable()
  d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=8192,max_time_seconds=30,quiescence_max_depth=2,quiescence_hard_max_depth=8))
  if instrumented:prof.disable()
  wall=time.perf_counter()-t
  assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
  row=dict(root=name,instrumented=instrumented,wall_seconds=wall,decision=record_value(d),history_unchanged=True)
  if instrumented:
   prof.dump_stats(str(out/(name+'-private.prof')));stats=pstats.Stats(prof);summary=[]
   for (filename,line,fn),(cc,nc,tt,ct,callers) in stats.stats.items():
    try:filename='repo/'+str(Path(filename).resolve().relative_to(ROOT)).replace('\\','/')
    except (ValueError,OSError):filename=Path(filename).name
    summary.append(dict(file=filename,line=line,function=fn,primitive_calls=cc,calls=nc,exclusive_seconds=tt,inclusive_seconds=ct))
   row['profile_total_exclusive_seconds']=stats.total_tt;row['functions']=sorted(summary,key=lambda z:z['inclusive_seconds'],reverse=True)
  rows.append(row);pair.append(d);write_record(out/'rows.json',dict(complete=False,rows=rows))
  print(name,instrumented,round(wall,3),d.completed_depth,d.result_source,d.termination_reason,flush=True)
 fields=('action','score','principal_variation','completed_depth','nodes','qnodes','termination_reason','result_source','result_ordinary_qdepth','runtime_pushes','runtime_pops')
 assert all(getattr(pair[0],f)==getattr(pair[1],f) for f in fields),(name,'profile changed work/result')
write_record(out/'rows.json',dict(complete=True,rows=rows))

