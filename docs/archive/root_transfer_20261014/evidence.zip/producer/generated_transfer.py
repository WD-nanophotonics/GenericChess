from pathlib import Path
import sys,json,time,ast,hashlib,random
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import search as sm,player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.rules.serialization import serialize_ruleset
b=ROOT/'.local_agent/root-transfer-20261014';out=b/'generated';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
old=(ROOT/'.local_agent/geometry-prefix-20261014/search-before-root-reserve.py').read_bytes()
current=(ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()
write_record(out/'declaration.json',dict(question='Does completed-root retention transfer without corrupting negative controls on unfamiliar generated movement/promotion/drop rules and played histories under actual Core/Native?',seeds=list(range(2051,2059)),sizes='odd4 even8',roots=[0,8],walk='Random(seed+27000), repr-sorted actual actions; no resampling terminal roots',orders=2,arms=['old_scalar_only','retention'],backends=['Core','Native requested; actual counters'],seconds=16,max_depth=12,q=2,hardq=8,max_nodes=1000000,max_calls=128,max_search_seconds=2048,expected_whole_minutes=38,decision='Completed win/provenance must be independently checked, history and legal PV preserved. Unchanged negative roots establish scope only. Any mismatch blocks generalization; timing repetitions counterbalance ordinary concurrent load, not exclusive-machine evidence. Old/new equal leaf evaluator/budgets; no result-driven extension or extra worker.',old_sha256=hashlib.sha256(old).hexdigest(),current_sha256=hashlib.sha256(current).hexdigest(),scope='Existing generated legacy mixtures mechanically compiled to semantic IR. Full generated domain remains target, aux/history semantic fixtures tested separately. Fresh seeds are exposed development, not universal holdout.'))
nodes=[n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name in ('negamax','run_root_search')]
assert len(nodes)==2;scope={}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'<old-scalar-only>','exec'),sm.__dict__,scope)
new_neg,new_root=sm.negamax,pm.run_root_search
samples=[];roots=[];start=time.perf_counter()
for seed in range(2051,2059):
 p.rr.stopped();cfg=p.GeneratorConfig(seed=seed,board_size=4 if seed%2 else 8,setup_preset='bilateral_random',allow_hybrid=True)
 g=p.generate_game(cfg);src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
 c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
 s=p.GameSession(c);rng=random.Random(seed+27000);walk=[]
 for ply in range(9):
  actions=tuple(s.legal_actions())
  if ply in (0,8):
   name=f'{seed}-ply{ply}'
   samples.append(dict(name=name,seed=seed,ply=ply,config=record_value(cfg),ruleset=json.loads(serialize_ruleset(g.ruleset)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk.copy(),evaluation_config=record_value(ec),profile=record_value(profile),legal_count=len(actions),included=bool(actions)))
   if actions:roots.append((name,c,s.state,s._search_witnesses,ev,actions))
  if ply==8:break
  if not actions:
   samples.append(dict(seed=seed,unavailable_ply8=True,terminal_at=ply,resampled=False));break
  action=rng.choice(sorted(actions,key=repr));walk.append(record_value(action));s.submit(action)
 write_record(out/'samples.json',dict(complete=False,samples=samples,setup_seconds=time.perf_counter()-start))
 print('prepared',seed,flush=True)
write_record(out/'samples.json',dict(complete=True,samples=samples,setup_seconds=time.perf_counter()-start))
rows=[];runtimes=[];original_attach=p.SearchPathRuntime.attach_stats
def attach(rt,stats):
 value=original_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return value
try:
 p.SearchPathRuntime.attach_stats=attach
 for name,c,state,witnesses,ev,actions in roots:
  for order in range(2):
   for native in ((False,True) if order==0 else (True,False)):
    for arm in (('old_scalar_only','retention') if order==0 else ('retention','old_scalar_only')):
     p.rr.stopped();assert time.perf_counter()-start<3300
     runtimes.clear();sm.negamax=scope['negamax'] if arm=='old_scalar_only' else new_neg
     pm.run_root_search=scope['run_root_search'] if arm=='old_scalar_only' else new_root
     t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=native);prep=time.perf_counter()-t
     sess=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses)
     d=player.choose_action(sess,SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=max(.001,16-prep),quiescence_max_depth=2,quiescence_hard_max_depth=8))
     total=time.perf_counter()-t
     assert len(runtimes)==1;rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot and sess.state is state and sess._search_witnesses==witnesses and d.action in actions
     child=state
     for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
     rows.append(dict(root=name,order=order,arm=arm,native_requested=native,provider_created=player.native_legality_provider is not None,prepare_seconds=prep,total_seconds=total,decision=record_value(d),history_unchanged=True,pv_legal=True,pv_terminal=record_value(child.terminal_status)))
     write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
     print(name,order,native,arm,round(total,3),d.result_source,d.completed_depth,d.result_ordinary_qdepth,d.score,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:sm.negamax=new_neg;pm.run_root_search=new_root;p.SearchPathRuntime.attach_stats=original_attach

