from pathlib import Path
import sys,json,hashlib
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets,castling_ruleset,en_passant_ruleset
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.serialization import serialize_ruleset,deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/root-transfer-20261014/semantic';out.mkdir(exist_ok=True)
assert not(out/'samples.json').exists()
rows=[]
def target(s,t,prefix=None,actor=None):
 candidates=[a for a in s.legal_actions() if (a.to_square.file,a.to_square.rank)==t and (prefix is None or getattr(a,'pattern_id','').startswith(prefix)) and (actor is None or getattr(a,'actor_type_id',getattr(a,'base_type_id',None))==actor)]
 assert len(candidates)==1,(t,candidates);s.submit(candidates[0])
def add(name,r,s,facts):
 rec=json.loads(serialize_game_record(s.to_record()))
 rows.append(dict(name=name,ruleset=json.loads(serialize_ruleset(r)),game_record=rec,state=record_value(s.state),witnesses=record_value(s._search_witnesses),facts=facts))
r=weird_rulesets()[2];board=[list(row) for row in r.initial_position];board[1][0]=Piece(0,'R','R');board[2][2]=Piece(1,'R','R')
r=replace(r,initial_position=tuple(map(tuple,board)),drop_allowed={**r.drop_allowed,'R':((True,)*64,)*2})
s=GameSession(compile_ruleset_for_execution(r));target(s,(1,2),'sem_','R')
assert s.state.position.board[17]==Piece(0,'R','TP',True) and dict(s.state.position.aux_state)[(0,-1)]==1
add('transformed_live_aux',r,s,'Actual R->TP promotion and live expire-next-turn bool.')
target(s,(1,2),actor='R')
assert s.state.position.hands[1].count('R')==1 and s.state.position.hands[1].count('TP')==0
add('capture_reset_base_hand',r,s,'Actual capture resets transformed TP into base R hand; auxiliary expiry retained.')
target(s,(0,1));target(s,(3,3),actor='R')
assert s.state.position.board[27]==Piece(1,'R','R') and s.state.position.hands[1].count('R')==0
add('drop_after_actual_capture',r,s,'Actual transformed capture then reply then base R drop, four played actions.')
r=weird_rulesets()[2];board=[list(row) for row in r.initial_position];board[1][0]=Piece(0,'R','R')
r=replace(r,initial_position=tuple(map(tuple,board)));s=GameSession(compile_ruleset_for_execution(r));target(s,(1,2),'sem_','R')
s.submit(sorted(s.legal_actions(),key=repr)[0]);assert dict(s.state.position.aux_state)[(0,-1)]==0
add('aux_expired_after_reply',r,s,'Actual temp right expires after opponent action, transformed actor remains.')
r=castling_ruleset();s=GameSession(compile_ruleset_for_execution(r));a=next(a for a in s.legal_actions() if a.pattern_id.startswith('sem_'));s.submit(a)
assert dict(s.state.position.aux_state)[(0,0)]==0
add('compound_castle_right_clear',r,s,'Actual king+rook move and owned auxiliary right clear.')
r=weird_rulesets()[3];board=[list(row) for row in r.initial_position];board[1][0]=Piece(0,'R','R');board[2][0]=Piece(0,'R','R');r=replace(r,initial_position=tuple(map(tuple,board)));s=GameSession(compile_ruleset_for_execution(r));target(s,(1,2),'sem_','R')
assert s.state.position.board[24]==Piece(0,'R','R') and s.state.position.board[16] is None
add('compound_shift',r,s,'Actual actor move and distinct friendly adjacent shift.')
r=en_passant_ruleset();board=[list(row) for row in r.initial_position];board[1][2]=Piece(0,'P','P');board[3][3]=Piece(1,'P','P');r=replace(r,initial_position=tuple(map(tuple,board)));s=GameSession(compile_ruleset_for_execution(r));target(s,(2,3),'sem_','P')
assert dict(s.state.position.aux_state)[(0,-1)]==18
add('offtarget_token_live',r,s,'Actual double move creates square token; opponent off-target capture is legal.')
target(s,(2,2),'sem_','P');assert s.state.position.board[26] is None and s.state.position.hands[1].count('P')==1
add('offtarget_capture_and_expiry',r,s,'Actual opponent token capture removes piece off target and adds base hand.')
for x in rows:
 c=compile_ruleset_for_execution(deserialize_ruleset(json.dumps(x['ruleset'])));replay=GameSession(c);record=deserialize_game_record(json.dumps(x['game_record']))
 for action in record.actions:replay.submit(action)
 assert record_value(replay.state)==x['state'] and record_value(replay._search_witnesses)==x['witnesses']
write_record(out/'samples.json',dict(complete=True,rows=rows,independent_replay=True,scope='Eight predeclared played roots from existing generic semantic fixtures. Explicit effects/promotion/drop/auxiliary histories are active, not deleted from task definition.'))
print('Frozen and replayed',len(rows),'roots',[(x['name'],len(x['game_record']['actions'])) for x in rows])

