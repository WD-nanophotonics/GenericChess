from pathlib import Path
import sys,json,ast,time,random,hashlib
from types import SimpleNamespace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from test_completed_root_win import prepared,proves_root_h3
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
b=ROOT/'.local_agent/root-transfer-20261014';out=b/'provider-factor';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Do actual optional check/availability and selective flags preserve completed positive root proof and honest incomplete-depth metadata?',provider_modes=['Core','NativeLegal','NativeAll','NativeCheckAvailabilityOnly'],tunings=['default','pvs','aspirationD2delta1','mdp','pvs+aspiration+mdp'],caps=[98,99,100000],q=2,hardq=8,max_depth=2,seconds=5,planned_calls=60,decision='Any mismatch is investigated before broader transfer; exact98/99 boundary can shift under tuning, so independent H3 and provenance/stop are assessed rather than assumed node invariance. No adoption of optional defaults.'))
rows=[]
for mode in ('Core','NativeLegal','NativeAll','NativeCheckAvailabilityOnly'):
 for name,tuning in [('default',SearchTuning()),('pvs',SearchTuning(use_pvs=True)),('aspiration',SearchTuning(use_aspiration=True,aspiration_start_depth=2,aspiration_delta=1)),('mdp',SearchTuning(use_mate_distance_pruning=True)),('combined',SearchTuning(use_pvs=True,use_aspiration=True,aspiration_start_depth=2,aspiration_delta=1,use_mate_distance_pruning=True))]:
  for cap in (98,99,100000):
   s=prepared();before=(s.state,s.to_record(),s._search_witnesses)
   p=AlphaBetaPlayer(s.compiled,use_disk_cache=False,tuning=tuning,use_native_semantic_legality=mode in ('NativeLegal','NativeAll'),use_native_semantic_availability=mode in ('NativeAll','NativeCheckAvailabilityOnly'),use_native_semantic_check=mode in ('NativeAll','NativeCheckAvailabilityOnly'))
   d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=cap,max_time_seconds=5,quiescence_max_depth=2))
   h3=proves_root_h3(s,d.action)
   assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
   if d.score>=900000000: assert h3
   if d.result_source=='completed_root_win':assert d.termination_reason=='node_limit' and d.completed_depth<2 and h3
   provider=p.native_legality_provider
   rows.append(dict(mode=mode,tuning=name,cap=cap,decision=record_value(d),h3=h3,history_unchanged=True,provider_created=provider is not None,check_metrics=provider.check_metrics if provider else {},availability_metrics=provider.availability_metrics if provider else {}))
   write_record(out/'rows.json',dict(complete=False,rows=rows))
write_record(out/'rows.json',dict(complete=True,rows=rows))
print('closed',len(rows),'retained',sum(r['decision']['result_source']=='completed_root_win' for r in rows),'positive',sum(r['h3'] for r in rows))

