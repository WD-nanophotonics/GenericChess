from pathlib import Path
import sys,ast,pytest
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.ai.alphabeta import search as sm
raw=(ROOT/'.local_agent/root-transfer-20261014/search-before-no-contest.py').read_bytes()
names=('negamax','_quiescence_runtime','quiescence','reference_minimax')
nodes=[n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name in names]
assert len(nodes)==len(names);scope={}
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'<preserved-before-no-contest>','exec'),sm.__dict__,scope)
original={n:getattr(sm,n) for n in names}
try:
 for n in names:setattr(sm,n,scope[n])
 result=pytest.main(['-q','-p','no:cacheprovider','-o','addopts=','--basetemp=.local_agent/pytest-runs/no-contest-old-corrected','tests/product/test_no_contest_search.py','--junitxml=.local_agent/root-transfer-20261014/no-contest-before-corrected.xml'])
finally:
 for n,v in original.items():setattr(sm,n,v)
raise SystemExit(result)

