from pathlib import Path
import sys,json,collections
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'.local_agent/geometry-prefix-20261014')]
from drop_fixture import make
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=ROOT/'.local_agent/root-transfer-20261014/one-second';data=json.loads((out/'rows.json').read_text(encoding='utf-8'));assert data['complete'];labels=json.loads((out/'goal-labels.json').read_text(encoding='utf-8'))['labels'];samples=json.loads((out/'samples.json').read_text(encoding='utf-8'))
calls=0
def step(s,a,c):
 global calls;calls+=1;return apply_action(s,a,c)
for label in labels:
 sample=next(x for x in samples if x['size']==label['size']);_,c,s=make(label['size']);assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
 a,=[a for a in s.legal_actions() if record_value(a)==label['action']];child=step(s.state,a,c)
 if label['goal'] is None:continue
 if 'terminal' in label:assert child.terminal_status.is_terminal and record_value(child.terminal_status)==label['terminal'] and (child.terminal_status.winner==0)==label['goal'];continue
 replies={json.dumps(record_value(a),sort_keys=True):a for a in legal_actions(child,c)}
 if label['goal']:
  edges=label['all_defenses'];assert {json.dumps(e['reply'],sort_keys=True) for e in edges}==set(replies) and len(edges)==len(replies)
  for edge in edges:
   after=step(child,replies[json.dumps(edge['reply'],sort_keys=True)],c);win=edge['win']
   if 'already_terminal' in win:assert after.terminal_status.winner==0 and record_value(after.terminal_status)==win['already_terminal']
   else:
    a,=[a for a in legal_actions(after,c) if record_value(a)==win['action']];leaf=step(after,a,c);assert leaf.terminal_status.winner==0 and record_value(leaf.terminal_status)==win['terminal']
 else:
  after=step(child,replies[json.dumps(label['defender'],sort_keys=True)],c);assert record_value(after.terminal_status)==label['after_terminal']
  if after.terminal_status.is_terminal:assert after.terminal_status.winner!=0
  else:
   actions={json.dumps(record_value(a),sort_keys=True):a for a in legal_actions(after,c)};edges=label['all_attacker_trials'];assert {json.dumps(e['action'],sort_keys=True) for e in edges}==set(actions) and len(edges)==len(actions)
   for edge in edges:
    leaf=step(after,actions[json.dumps(edge['action'],sort_keys=True)],c);assert leaf.terminal_status.winner!=0 and record_value(leaf.terminal_status)==edge['terminal']
answers=[]
for row in data['rows']:
 label,=[x for x in labels if x['size']==row['size'] and x['action']==row['decision']['action']]
 answers.append(dict(size=row['size'],order=row['order'],arm=row['arm'],h3=label['goal'],completed_depth=row['decision']['completed_depth'],result_source=row['decision']['result_source'],ordinary_qdepth=row['decision']['result_ordinary_qdepth']))
write_record(out/'independent-replay.json',dict(answers=answers,actual_replay_transitions=calls,labels=len(labels),unknown=sum(x['goal'] is None for x in labels),scope='Positive full-defense and negative finiteH3 counterexample coverage checked against exact Core sets. Negative H3 is not a game loss; two roots/two orders are not independent samples or global strength.'))
print('independent replay',calls,'transitions')
print([(n,arm,[x['h3'] for x in answers if x['size']==n and x['arm']==arm]) for n in (12,16) for arm in ('Core','NativeLegal','NativeLegalAvailability','NativeAll')])

