from pathlib import Path
import sys,time,json,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'.local_agent/geometry-prefix-20261014')]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=ROOT/'.local_agent/root-transfer-20261014/one-second';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does earlier completed-root-bound delivery from optional Native inputs translate to actual H3 action usefulness at a fixed1s caller budget?',sizes=[12,16],arms=['Core','NativeLegal','NativeLegalAvailability','NativeAll'],seconds=1,orders=2,max_depth=12,q=2,hardq=8,max_nodes=1000000,max_calls=16,scope='New exposed development counterfactual after closed48call provider assay; fixed1s ordinary consumer budget, no result-driven extension of old16s cells, no observer and no default/UI change. Independent Core full-defense H3 labels for actual returned actions, unknown retained. No global-strength or clean-machine claim.',source_sha256=hashlib.sha256((ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()).hexdigest()))
rows=[];samples=[]
for n in (12,16):
 rules,c,s=make(n);cfg=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg);before=s.state,s.to_record(),s._search_witnesses
 from generic_chess.rules.serialization import serialize_ruleset
 samples.append(dict(size=n,ruleset=json.loads(serialize_ruleset(rules)),state=record_value(s.state),witnesses=record_value(s._search_witnesses)))
 for order in range(2):
  arms=['Core','NativeLegal','NativeLegalAvailability','NativeAll'];arms=arms if order==0 else list(reversed(arms))
  for arm in arms:
   p.rr.stopped();t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=arm!='Core',use_native_semantic_availability=arm in ('NativeLegalAvailability','NativeAll'),use_native_semantic_check=arm=='NativeAll');prep=time.perf_counter()-t
   d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=max(.001,1-prep),quiescence_max_depth=2,quiescence_hard_max_depth=8))
   wall=time.perf_counter()-t;provider=player.native_legality_provider
   assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
   rows.append(dict(size=n,order=order,arm=arm,prepare_seconds=prep,wall=wall,decision=record_value(d),check_metrics=provider.check_metrics if provider else {},availability_metrics=provider.availability_metrics if provider else {},history_unchanged=True))
   write_record(out/'rows.json',dict(complete=False,rows=rows));print(n,order,arm,d.completed_depth,d.result_source,d.score,round(wall,3),flush=True)
write_record(out/'samples.json',samples);write_record(out/'rows.json',dict(complete=True,rows=rows))
# Separate terminal-goal label production, not search/PV/score-derived labels.
labels={};calls=0;start=time.perf_counter()
def step(state,a,c):
 global calls
 if calls>=20000 or time.perf_counter()-start>=120:raise TimeoutError('finite H3 label cap')
 calls+=1;return apply_action(state,a,c)
for n in (12,16):
 _,c,s=make(n)
 for row in [z for z in rows if z['size']==n]:
  key=(n,json.dumps(row['decision']['action'],sort_keys=True))
  if key in labels:continue
  action,=[a for a in s.legal_actions() if record_value(a)==row['decision']['action']]
  try:
   child=step(s.state,action,c)
   if child.terminal_status.is_terminal:answer=dict(goal=child.terminal_status.winner==0,terminal=record_value(child.terminal_status))
   else:
    evidence=[];answer=None
    for reply in legal_actions(child,c):
     after=step(child,reply,c);win=None;tested=[]
     if after.terminal_status.is_terminal:
      if after.terminal_status.winner==0:win=dict(already_terminal=record_value(after.terminal_status))
     else:
      for a in legal_actions(after,c):
       leaf=step(after,a,c);tested.append(dict(action=record_value(a),terminal=record_value(leaf.terminal_status)))
       if leaf.terminal_status.winner==0:win=dict(action=record_value(a),terminal=record_value(leaf.terminal_status));break
     if win is None:answer=dict(goal=False,defender=record_value(reply),all_attacker_trials=tested,after_terminal=record_value(after.terminal_status));break
     evidence.append(dict(reply=record_value(reply),win=win))
    if answer is None:answer=dict(goal=True,all_defenses=evidence)
  except TimeoutError:answer=dict(goal=None,unknown=True)
  labels[key]=dict(size=n,action=record_value(action),**answer)
write_record(out/'goal-labels.json',dict(labels=list(labels.values()),producing_transitions=calls,seconds=time.perf_counter()-start))
print('H3 labels',[(x['size'],x['goal']) for x in labels.values()],calls,flush=True)

