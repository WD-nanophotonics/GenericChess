from pathlib import Path
import sys,sysconfig,subprocess,os,json,time,hashlib
ROOT=Path.cwd();b=ROOT/'.local_agent/root-transfer-20261014/payload-v2';b.mkdir(exist_ok=True)
src=b/'payload_probe.c';output=b/('_payload_probe_v2'+sysconfig.get_config_var('EXT_SUFFIX'))
assert not output.exists()
zig=ROOT/'.venv/Lib/site-packages/ziglang/zig.exe';assert zig.exists()
command=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython'+str(sys.version_info.major)+str(sys.version_info.minor),str(src),'-o',str(output)]
env=dict(os.environ);env['ZIG_GLOBAL_CACHE_DIR']=str(b/'zig-cache')
start=time.perf_counter();r=subprocess.run(command,env=env,timeout=90,capture_output=True,text=True)
(b/'build-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8')
meta=dict(returncode=r.returncode,seconds=time.perf_counter()-start,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None,scope='Private Python C-API mapping only, no Native ABI/rule/state/capsule change and no installed binary overwrite.')
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8');print(meta)
if r.returncode:print(r.stdout,r.stderr);raise SystemExit(r.returncode)

