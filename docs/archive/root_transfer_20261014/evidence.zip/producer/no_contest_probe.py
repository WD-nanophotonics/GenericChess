from pathlib import Path
import sys
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result
from generic_chess.rules.schema import RuleDeclaration,RuleWeightedMaterialMetric,RuleDeclarationOutcomeBand
from scripts.full_q_refresh_comparison import compile_legacy_ruleset_for_semantic_execution,SearchMetadataAdapter,GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.declarations import available_declarations
from scripts.research_record import record_value,write_record
r=make_ruleset(4,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1)),RayAtom((1,0)),RayAtom((-1,0)))],lines=['....','...R','....','.k.K'])
r=replace(r,declarations=(RuleDeclaration(declaration_id='defender_neutral',owner=1,require_not_in_check=False,weighted_metric=RuleWeightedMaterialMetric(weights={'K':1}),outcome_bands=(RuleDeclarationOutcomeBand(1,'NO_CONTEST'),)),))
x=compile_legacy_ruleset_for_semantic_execution(r);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)
s=GameSession(c);pos=replace(s.state.position,hands=(Hands((('R',1),)),Hands()));key=position_identity_key(pos,c)
st=replace(s.state,position=pos,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),))
s._state=replace(st,terminal_status=terminal_result(st,c));s._search_history_witnesses=(pos,)
before=s.state,s.to_record(),s._search_witnesses
d=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False).choose_action(s,SearchLimits(max_depth=2,max_nodes=99,max_time_seconds=5,quiescence_max_depth=2))
assert before==(s.state,s.to_record(),s._search_witnesses)
s.submit(d.action);options=available_declarations(s.state,c);actual=s.declare('defender_neutral')
row=dict(decision=record_value(d),defender_options=record_value(options),actual_session_result=record_value(actual),false_win=d.score>=900000000 and actual.winner is None,scope='NO_CONTEST is a supported neutral option; actual session accepts it immediately after chosen root action, before any alleged H3 proof. Same original root rebuilt with new rule fingerprint.')
write_record(ROOT/'.local_agent/root-transfer-20261014/no-contest-before.json',row)
print(d.result_source,d.score,d.termination_reason,'defender',options,'actual',actual)
assert row['false_win']

