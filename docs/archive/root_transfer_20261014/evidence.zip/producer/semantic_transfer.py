from pathlib import Path
import sys,json,ast,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta import search as sm,player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.full_q_refresh_comparison import runtime_state,SearchPathRuntime
from scripts import reserve_refresh_diagnostic as rr
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/root-transfer-20261014/semantic';assert not(out/'declaration.json').exists()
old=(ROOT/'.local_agent/geometry-prefix-20261014/search-before-root-reserve.py').read_bytes()
new=(ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()
selected=['capture_reset_base_hand','drop_after_actual_capture','compound_shift','offtarget_token_live']
write_record(out/'declaration.json',dict(question='Does positive-root retention preserve generic semantic effect/history execution under deterministic work and resource boundaries?',fixed_roots='all8 frozen replayed roots',fixed_nodes=512,fixed_max_seconds=10,resource_roots=selected,seconds=16,orders=2,backends=['Core','Native actual'],arms=['old_scalar_only','retention'],q=2,hardq=8,max_depth=12,max_calls=64,expected_minutes=12,scope='Frozen unit material control: anchor0/every other current/base type1000, board+hands; not price learning, not default evaluator or full generated-domain proof. All clauses retained; actual backend/fallback recorded. Both bounded local producers may overlap ordinary machine load; no exclusive timing/speed claim. Any changed result gets independent finite Core goal check, unknown is retained.',old_sha256=hashlib.sha256(old).hexdigest(),new_sha256=hashlib.sha256(new).hexdigest()))
nodes=[n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name in ('negamax','run_root_search')];scope={};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'<old-scalar-only>','exec'),sm.__dict__,scope)
new_neg,new_root=sm.negamax,pm.run_root_search;original_attach=SearchPathRuntime.attach_stats
class EqualMaterial:
 def __init__(self,c):self.values={tid:0 if t.is_anchor else 1000 for tid,t in c.support.type_metadata.items()}
 def type_value(self,tid):return self.values[tid]
 def capture_order_value(self,moving,captured):return 10*self.type_value(captured.current_type_id)-self.type_value(moving.current_type_id)
 def evaluate(self,state):
  p=state.position;score=sum((1 if x.owner==p.side_to_move else -1)*self.values[x.current_type_id] for x in p.board if x)
  return score+sum((1 if owner==p.side_to_move else -1)*self.values[tid]*count for owner,hand in enumerate(p.hands) for tid,count in hand.counts)
runtimes=[]
def attach(rt,stats):
 result=original_attach(rt,stats);runtimes.append((rt,runtime_state(rt)));return result
rows=[];start=time.perf_counter()
try:
 SearchPathRuntime.attach_stats=attach
 for sample in json.loads((out/'samples.json').read_text(encoding='utf-8'))['rows']:
  c=compile_ruleset_for_execution(deserialize_ruleset(json.dumps(sample['ruleset'])));s=GameSession(c)
  for action in deserialize_game_record(json.dumps(sample['game_record'])).actions:s.submit(action)
  assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
  ev=EqualMaterial(c);before=s.state,s.to_record(),s._search_witnesses;legal=tuple(s.legal_actions())
  conditions=[('fixed',0)]+([('resource',0),('resource',1)] if sample['name'] in selected else [])
  for condition,order in conditions:
   for native in ((False,True) if order==0 else (True,False)):
    for arm in (('old_scalar_only','retention') if order==0 else ('retention','old_scalar_only')):
     rr.stopped();assert time.perf_counter()-start<1800;runtimes.clear()
     sm.negamax=scope['negamax'] if arm=='old_scalar_only' else new_neg
     pm.run_root_search=scope['run_root_search'] if arm=='old_scalar_only' else new_root
     t=time.perf_counter();p=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=native);prep=time.perf_counter()-t
     d=p.choose_action(s,SearchLimits(max_depth=12,max_nodes=512 if condition=='fixed' else 1000000,max_time_seconds=max(.001,(10 if condition=='fixed' else 16)-prep),quiescence_max_depth=2))
     wall=time.perf_counter()-t
     assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced and d.action in legal
     assert len(runtimes)==1;rt,snapshot=runtimes[0];rt.assert_balanced();assert runtime_state(rt)==snapshot
     child=s.state
     for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
     rows.append(dict(root=sample['name'],condition=condition,order=order,native_requested=native,provider_created=p.native_legality_provider is not None,arm=arm,prepare_seconds=prep,wall=wall,decision=record_value(d),history_unchanged=True,pv_legal=True,pv_terminal=record_value(child.terminal_status)))
     write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
     print(sample['name'],condition,order,native,arm,round(wall,3),d.result_source,d.score,d.native_legality_calls,d.native_legality_fallbacks,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:sm.negamax=new_neg;pm.run_root_search=new_root;SearchPathRuntime.attach_stats=original_attach

