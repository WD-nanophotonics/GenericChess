from pathlib import Path
import sys,json,time,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'.local_agent/geometry-prefix-20261014')]
from drop_fixture import make,p
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import _action_from_dict
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from types import SimpleNamespace
out=ROOT/'.local_agent/root-transfer-20261014/native-handoff';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does existing optional Native availability/check input sharing reduce work cost or time to a retained positive root bound after the root-win fix?',roots=['knownH3-12','knownH3-16','2053-ply0','2054-ply8'],arms=['Core','NativeLegal','NativeLegalAvailability','NativeAll'],fixed_nodes=512,fixed_seconds=10,resource_seconds=16,orders=2,q=2,hardq=8,max_depth=12,max_calls=48,expected_minutes=11,decision='Actual query counters and exact work controls precede equal-time provenance/goal. Time-to-first completed winning root bound is measured, not inferred from depth. Optional defaults stay unchanged; mixed/no gains defer interface prioritization. No exclusive-load/speed/strength claim. Generated roots are already exposed development, not fresh holdout.',source_sha256=hashlib.sha256((ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()).hexdigest(),observer='Temporary Context.__setattr__ pass-through records root_completed_win time only; no early exit, budget reset or source edit.'))
roots=[]
for n in (12,16):
 _,c,s=make(n);cfg=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg);roots.append((f'knownH3-{n}',c,s,ev))
samples=json.loads((ROOT/'.local_agent/root-transfer-20261014/generated/samples.json').read_text(encoding='utf-8'))['samples']
for name in ('2053-ply0','2054-ply8'):
 sample=next(x for x in samples if x.get('name')==name);r=deserialize_ruleset(json.dumps(sample['ruleset']));x=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=p.GameSession(c)
 for raw in sample['walk']:
  matches=[a for a in s.legal_actions() if record_value(a)==raw];assert len(matches)==1;s.submit(matches[0])
 assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
 cfg=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg);assert record_value(ev._profile)==sample['profile'];roots.append((name,c,s,ev))
write_record(out/'samples.json',[dict(name=name,state=record_value(s.state),witnesses=record_value(s._search_witnesses),profile=record_value(ev._profile)) for name,c,s,ev in roots])
original=sm._Context.__setattr__;events=[];origin=[0]
def observe(ctx,name,value):
 original(ctx,name,value)
 if name=='root_completed_win' and value is not None:events.append(dict(seconds=time.perf_counter()-origin[0],nodes=ctx.stats.nodes,qnodes=ctx.stats.qnodes,score=value[0].score,action=record_value(value[0].best_action),q=value[1]))
rows=[];start=time.perf_counter()
try:
 sm._Context.__setattr__=observe
 for name,c,s,ev in roots:
  before=s.state,s.to_record(),s._search_witnesses
  for condition,rep in [('fixed',0),('resource',0),('resource',1)]:
   arms=['Core','NativeLegal','NativeLegalAvailability','NativeAll'];arms=arms if rep==0 else list(reversed(arms))
   for arm in arms:
    p.rr.stopped();assert time.perf_counter()-start<1500;events.clear();origin[0]=time.perf_counter()
    player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=arm!='Core',use_native_semantic_availability=arm in ('NativeLegalAvailability','NativeAll'),use_native_semantic_check=arm=='NativeAll')
    prep=time.perf_counter()-origin[0]
    d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=512 if condition=='fixed' else 1000000,max_time_seconds=max(.001,(10 if condition=='fixed' else 16)-prep),quiescence_max_depth=2,quiescence_hard_max_depth=8))
    wall=time.perf_counter()-origin[0];provider=player.native_legality_provider
    assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
    child=s.state
    for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
    rows.append(dict(root=name,condition=condition,order=rep,arm=arm,prepare_seconds=prep,wall_seconds=wall,decision=record_value(d),events=events.copy(),first_root_bound_seconds=events[0]['seconds'] if events else None,provider_created=provider is not None,check_metrics=provider.check_metrics if provider else {},availability_metrics=provider.availability_metrics if provider else {},history_unchanged=True,pv_legal=True))
    write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
    print(name,condition,rep,arm,round(wall,3),d.completed_depth,d.result_source,d.score,round(events[0]['seconds'],3) if events else None,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:sm._Context.__setattr__=original

