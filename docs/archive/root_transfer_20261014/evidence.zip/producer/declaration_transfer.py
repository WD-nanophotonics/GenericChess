from pathlib import Path
import sys,json
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from conftest import make_ruleset,king_type
from generic_chess.rules.schema import RuleDeclaration,RuleStateGuard,RuleSpatialSelector,RuleTypeRef,RuleDeclarationOutcomeBand,RuleWeightedMaterialMetric
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.declarations import available_declarations
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
b=ROOT/'.local_agent/root-transfer-20261014'
rule=make_ruleset(4,[king_type()],lines=['...k','....','....','K...'])
claim=RuleDeclaration(declaration_id='zone_claim',owner=0,state_guards=(RuleStateGuard(aggregation='exists',owner='self',type_ref=RuleTypeRef('explicit','K'),compare_field='current',promoted='any',location='board',spatial=RuleSpatialSelector('zone',zone_squares=((1,0),)),value=1),),weighted_metric=RuleWeightedMaterialMetric(weights={'K':1}),outcome_bands=(RuleDeclarationOutcomeBand(1,'WIN'),))
c=compile_ruleset_for_execution(replace(rule,declarations=(claim,)));s=GameSession(c)
class Zero:
 def evaluate(self,state):return 0
events=[];orig=sm._Context.__setattr__
def observed(ctx,name,value):
 orig(ctx,name,value)
 if name=='root_completed_win' and value is not None:events.append(dict(nodes=ctx.stats.nodes,qnodes=ctx.stats.qnodes,score=value[0].score,action=record_value(value[0].best_action)))
sm._Context.__setattr__=observed
try:
 p=AlphaBetaPlayer(c,evaluator_override=Zero(),use_native_semantic_legality=True,use_ordering=False,tuning=SearchTuning(use_root_tactical=False))
 d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=10000,max_time_seconds=10,quiescence_max_depth=0))
finally:sm._Context.__setattr__=orig
first=events[0]['nodes']+events[0]['qnodes']
rows=[]
for cap in (first,first+1,10000):
 p=AlphaBetaPlayer(c,evaluator_override=Zero(),use_native_semantic_legality=True,use_ordering=False,tuning=SearchTuning(use_root_tactical=False))
 before=s.state,s.to_record(),s._search_witnesses
 d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=cap,max_time_seconds=10,quiescence_max_depth=0))
 child=apply_action(s.state,d.action,c);answers=[]
 for a in legal_actions(child,c):
  after=apply_action(child,a,c)
  answers.append(dict(reply=record_value(a),declarations=record_value(available_declarations(after,c))))
 proved=bool(answers) and all(any(z['outcome']=='WIN' for z in a['declarations']) for a in answers)
 assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
 rows.append(dict(cap=cap,decision=record_value(d),provider_created=p.native_legality_provider is not None,proof_replies=answers,forces_claim_H2=proved))
 print(cap,d.result_source,d.score,d.completed_depth,d.termination_reason,proved)
write_record(b/'declaration-transfer.json',dict(events=events,first_completed_child_nodes=first,rows=rows,scope='Analysis-root zone declaration; all opponent legal replies replayed via Core and actual zero-action claim assessed. Provider unsupported is reported, not called Native.'))

