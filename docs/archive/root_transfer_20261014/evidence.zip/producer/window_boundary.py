from pathlib import Path
import sys,json
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from test_completed_root_win import prepared,proves_root_h3
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.full_q_refresh_comparison import runtime_state
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/root-transfer-20261014/window';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does strict score>root-alpha reject equality mate-band upper bounds while retaining improving lower bounds?',tunings=['plain','pvs','mdp','pvs+mdp'],native=[False,True],tt=['cold','real child entries only; root removed'],windows=['v,v+1','v-1,v'],expected_v='determined by full cold exact directD2/q2 first',scope='Dot boundary control; actual root-child pushes logged, root TT shortcut excluded, no forged entries. Cold full queries+32 boundary queries.'))
rows=[];origpush=SearchPathRuntime.push;rootpush=[]
def observed(rt,a,*args,**kwargs):
 if rt.depth==0:rootpush.append(record_value(a))
 return origpush(rt,a,*args,**kwargs)
def query(s,p,tuning,tt,alpha,beta):
 stats=SearchStatistics();rt=SearchPathRuntime.from_state(s.state,s.compiled,history_witnesses=s._search_witnesses,legal_binding_provider=p.native_legality_provider)
 rt.attach_stats(stats);before=runtime_state(rt);rootkey=rt.search_key();assert tt.probe(rootkey) is None
 ctx=sm._Context(s.compiled,p._evaluator,tt,stats,sm._Budget(SearchLimits(max_depth=2,max_nodes=100000,max_time_seconds=10,quiescence_max_depth=2),None),tuning,True,True,2,8,None,runtime=rt,first_main_iteration_complete=True)
 rootpush.clear();result=sm.negamax(s.state,2,alpha,beta,0,ctx);rt.assert_balanced();assert runtime_state(rt)==before and rootpush
 return result,ctx,rootkey,rootpush.copy()
try:
 SearchPathRuntime.push=observed
 for native in (False,True):
  for name,tuning in [('plain',SearchTuning()),('pvs',SearchTuning(use_pvs=True)),('mdp',SearchTuning(use_mate_distance_pruning=True)),('pvs+mdp',SearchTuning(use_pvs=True,use_mate_distance_pruning=True))]:
   s=prepared();p=AlphaBetaPlayer(s.compiled,use_disk_cache=False,use_native_semantic_legality=native)
   coldtt=TranspositionTable();exact,ctx,key,pushes=query(s,p,tuning,coldtt,-sm.INF,sm.INF);v=exact.score
   assert v==999999997 and proves_root_h3(s,exact.best_action)
   rows.append(dict(native=native,tuning=name,window='fullcold',result=record_value(exact),stats=record_value(ctx.stats),root_pushes=pushes,v=v))
   for warm in (False,True):
    for improve in (False,True):
     tt=TranspositionTable()
     if warm:tt._data=dict(coldtt._data);tt._data.pop(key,None)
     source_entries=len(tt);alpha=v-1 if improve else v
     result,ctx,key,pushes=query(s,p,tuning,tt,alpha,alpha+1)
     assert (ctx.root_completed_win is not None)==improve,(native,name,warm,improve,result.score,ctx.root_completed_win)
     if improve:assert proves_root_h3(s,ctx.root_completed_win[0].best_action)
     rows.append(dict(native=native,tuning=name,warm_child_tt=warm,source_entries=source_entries,window='improve' if improve else 'equal',alpha=alpha,beta=alpha+1,result=record_value(result),saved=record_value(ctx.root_completed_win),stats=record_value(ctx.stats),root_pushes=pushes,history_unchanged=True))
 write_record(out/'rows.json',dict(complete=True,rows=rows))
 print('Closed',len(rows),'calls; equal negatives',sum(r['window']=='equal' for r in rows),'improving proofs',sum(r['window']=='improve' for r in rows))
finally:SearchPathRuntime.push=origpush

