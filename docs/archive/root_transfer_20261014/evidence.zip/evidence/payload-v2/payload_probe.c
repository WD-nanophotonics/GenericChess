#define PY_SSIZE_T_CLEAN
#include <Python.h>
static PyObject *k_owner;
static PyObject *k_base_type_id;
static PyObject *k_current_type_id;
static PyObject *k_promoted;
static PyObject *k_board;
static PyObject *k_hands;
static PyObject *k_counts;
static PyObject *k_aux_state;
static PyObject *k_side_to_move;

static PyObject *number_attr(PyObject *o,const char *name){
 PyObject *v=PyObject_GetAttr(o,k_side_to_move);if(!v)return NULL;
 PyObject *r=PyNumber_Long(v);Py_DECREF(v);return r;
}
static PyObject *typed_lookup(PyObject *map,PyObject *key,const char *message){
 PyObject *v=PyObject_GetItem(map,key);
 if(!v&&PyErr_ExceptionMatches(PyExc_KeyError)){PyErr_Clear();PyErr_SetString(PyExc_ValueError,message);}
 return v;
}
static PyObject *piece_row(PyObject *p,PyObject *map){
 PyObject *owner=NULL,*baseid=NULL,*curid=NULL,*prom=NULL,*base=NULL,*cur=NULL,*ownint=NULL,*flag=NULL,*row=NULL;
 owner=PyObject_GetAttr(p,k_owner);if(!owner)goto done;
 int eq0=PyObject_RichCompareBool(owner,Py_False,Py_EQ),eq1=PyObject_RichCompareBool(owner,Py_True,Py_EQ);
 if(eq0<0||eq1<0)goto done;
 if(!eq0&&!eq1){PyErr_SetString(PyExc_ValueError,"Native legality payload has an invalid owner");goto done;}
 baseid=PyObject_GetAttr(p,k_base_type_id);if(!baseid)goto done;
 curid=PyObject_GetAttr(p,k_current_type_id);if(!curid)goto done;
 base=typed_lookup(map,baseid,"Native legality payload has an unknown piece type");if(!base)goto done;
 cur=typed_lookup(map,curid,"Native legality payload has an unknown piece type");if(!cur)goto done;
 ownint=PyNumber_Long(owner);if(!ownint)goto done;
 prom=PyObject_GetAttr(p,k_promoted);if(!prom)goto done;
 int truth=PyObject_IsTrue(prom);if(truth<0)goto done;flag=PyLong_FromLong(truth?1:0);if(!flag)goto done;
 row=PyList_New(4);if(!row)goto done;
 PyList_SET_ITEM(row,0,base);base=NULL;PyList_SET_ITEM(row,1,cur);cur=NULL;
 PyList_SET_ITEM(row,2,ownint);ownint=NULL;PyList_SET_ITEM(row,3,flag);flag=NULL;
done:
 Py_XDECREF(owner);Py_XDECREF(baseid);Py_XDECREF(curid);Py_XDECREF(prom);Py_XDECREF(base);Py_XDECREF(cur);Py_XDECREF(ownint);Py_XDECREF(flag);return row;
}
static PyObject *payload(PyObject *self,PyObject *args){
 PyObject *pos,*map,*plyarg;Py_ssize_t ntypes;
 if(!PyArg_ParseTuple(args,"OOnO",&pos,&map,&ntypes,&plyarg))return NULL;
 if(ntypes<0){PyErr_SetString(PyExc_ValueError,"negative type count");return NULL;}
 PyObject *rawboard=NULL,*boardfast=NULL,*rawhands=NULL,*handsfast=NULL,*board=NULL,*hands=NULL,*auxraw=NULL,*aux=NULL,*side=NULL,*ply=NULL,*result=NULL;
 rawboard=PyObject_GetAttr(pos,k_board);if(!rawboard)goto done;
 boardfast=PySequence_Fast(rawboard,"board must be a sequence");if(!boardfast)goto done;
 Py_ssize_t len=PySequence_Fast_GET_SIZE(boardfast);board=PyList_New(len);if(!board)goto done;
 for(Py_ssize_t i=0;i<len;i++){
  PyObject *p=PySequence_Fast_GET_ITEM(boardfast,i),*r;
  if(p==Py_None){r=Py_NewRef(Py_None);}else{r=piece_row(p,map);if(!r)goto done;}
  PyList_SET_ITEM(board,i,r);
 }
 rawhands=PyObject_GetAttr(pos,k_hands);if(!rawhands)goto done;
 handsfast=PySequence_Fast(rawhands,"hands must be a sequence");if(!handsfast)goto done;
 len=PySequence_Fast_GET_SIZE(handsfast);hands=PyList_New(len);if(!hands)goto done;
 for(Py_ssize_t i=0;i<len;i++){
  PyObject *counts=PyList_New(ntypes);if(!counts)goto done;
  for(Py_ssize_t j=0;j<ntypes;j++){PyObject *z=PyLong_FromLong(0);if(!z){Py_DECREF(counts);goto done;}PyList_SET_ITEM(counts,j,z);}
  PyList_SET_ITEM(hands,i,counts);
  PyObject *raw=PyObject_GetAttr(PySequence_Fast_GET_ITEM(handsfast,i),k_counts);
  if(!raw)goto done;
  PyObject *entries=PySequence_Fast(raw,"counts must be a sequence");Py_DECREF(raw);if(!entries)goto done;
  for(Py_ssize_t j=0;j<PySequence_Fast_GET_SIZE(entries);j++){
   PyObject *pair=PySequence_Fast(PySequence_Fast_GET_ITEM(entries,j),"hand count must be a pair");
   if(!pair){Py_DECREF(entries);goto done;}
   if(PySequence_Fast_GET_SIZE(pair)!=2){Py_DECREF(pair);Py_DECREF(entries);PyErr_SetString(PyExc_ValueError,"hand count must be a pair");goto done;}
   PyObject *idx=typed_lookup(map,PySequence_Fast_GET_ITEM(pair,0),"Native legality payload has an unknown hand type");
   if(!idx){Py_DECREF(pair);Py_DECREF(entries);goto done;}
   Py_ssize_t index=PyLong_AsSsize_t(idx);Py_DECREF(idx);
   if(index==-1&&PyErr_Occurred()){Py_DECREF(pair);Py_DECREF(entries);goto done;}
   PyObject *count=PyNumber_Long(PySequence_Fast_GET_ITEM(pair,1));Py_DECREF(pair);
   if(!count){Py_DECREF(entries);goto done;}
   PyObject *zero=PyLong_FromLong(0);if(!zero){Py_DECREF(count);Py_DECREF(entries);goto done;}
   int negative=PyObject_RichCompareBool(count,zero,Py_LT);Py_DECREF(zero);
   if(negative<0){Py_DECREF(count);Py_DECREF(entries);goto done;}
   if(negative){Py_DECREF(count);Py_DECREF(entries);PyErr_SetString(PyExc_ValueError,"Native legality payload has a negative hand count");goto done;}
   if(PyList_SetItem(counts,index,count)<0){Py_DECREF(entries);goto done;}
  }
  Py_DECREF(entries);
 }
 auxraw=PyObject_GetAttr(pos,k_aux_state);if(!auxraw)goto done;
 aux=PySequence_Tuple(auxraw);if(!aux)goto done;
 side=number_attr(pos,"side_to_move");if(!side)goto done;
 ply=PyNumber_Long(plyarg);if(!ply)goto done;
 result=PyDict_New();if(!result)goto done;
 if(PyDict_SetItemString(result,"side",side)<0||PyDict_SetItemString(result,"ply",ply)<0||PyDict_SetItemString(result,"board",board)<0||PyDict_SetItemString(result,"hands",hands)<0||PyDict_SetItemString(result,"aux_state",aux)<0){Py_CLEAR(result);}
done:
 Py_XDECREF(rawboard);Py_XDECREF(boardfast);Py_XDECREF(rawhands);Py_XDECREF(handsfast);Py_XDECREF(board);Py_XDECREF(hands);Py_XDECREF(auxraw);Py_XDECREF(aux);Py_XDECREF(side);Py_XDECREF(ply);return result;
}
static PyMethodDef methods[]={{"payload",payload,METH_VARARGS,"Private complete state-only payload builder."},{NULL,NULL,0,NULL}};
static void free_names(void *unused){Py_CLEAR(k_owner);Py_CLEAR(k_base_type_id);Py_CLEAR(k_current_type_id);Py_CLEAR(k_promoted);Py_CLEAR(k_board);Py_CLEAR(k_hands);Py_CLEAR(k_counts);Py_CLEAR(k_aux_state);Py_CLEAR(k_side_to_move);}
static struct PyModuleDef module={PyModuleDef_HEAD_INIT,"_payload_probe_v2",NULL,-1,methods,NULL,NULL,NULL,free_names};
PyMODINIT_FUNC PyInit__payload_probe_v2(void){k_owner=PyUnicode_InternFromString("owner");if(!k_owner){free_names(NULL);return NULL;}k_base_type_id=PyUnicode_InternFromString("base_type_id");if(!k_base_type_id){free_names(NULL);return NULL;}k_current_type_id=PyUnicode_InternFromString("current_type_id");if(!k_current_type_id){free_names(NULL);return NULL;}k_promoted=PyUnicode_InternFromString("promoted");if(!k_promoted){free_names(NULL);return NULL;}k_board=PyUnicode_InternFromString("board");if(!k_board){free_names(NULL);return NULL;}k_hands=PyUnicode_InternFromString("hands");if(!k_hands){free_names(NULL);return NULL;}k_counts=PyUnicode_InternFromString("counts");if(!k_counts){free_names(NULL);return NULL;}k_aux_state=PyUnicode_InternFromString("aux_state");if(!k_aux_state){free_names(NULL);return NULL;}k_side_to_move=PyUnicode_InternFromString("side_to_move");if(!k_side_to_move){free_names(NULL);return NULL;}PyObject *m=PyModule_Create(&module);if(!m)free_names(NULL);return m;}

