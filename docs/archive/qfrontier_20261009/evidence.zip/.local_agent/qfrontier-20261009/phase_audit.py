"""Concentration audit on the existing entire populations, no new data or fit.
Partitions fixed before this audit: owner0/owner1 (even/odd ply), early0..7,
late8..16. Leave-one-background ranges are finite influence, not sampling CIs.
Primary context-first law remains unchanged; don't promote favorable strata.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import combinations
import json,hashlib,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path('.local_agent/qfrontier-20261009');res=dict(scope=__doc__,inputs={},rules=[])
for source,declfile in [('reply-task.json','reply-declaration.json'),('reply8-task.json','reply8-declaration.json')]:
 d=json.loads((p/source).read_bytes());decl=json.loads((p/declfile).read_bytes());res['inputs'][source]=hashlib.sha256((p/source).read_bytes()).hexdigest()
 for old in d['rules']:
  assert old['complete'];prices=decl['prices'][str(old['seed'])];types=old['types'];bg=defaultdict(dict)
  for c in old['cells']:bg[c['ply']].setdefault(c['source'],{})[c['type']]=c
  row=dict(seed=old['seed'],tasks={})
  for field in ('immediate','task'):
   backgrounds=[]
   for ply,slots in sorted(bg.items()):
    assert all(sorted(v)==types for v in slots.values())
    utility={t:sum((F(v[t][field]) for v in slots.values()),F())/len(slots) for t in types}
    blind=sum(utility.values(),F())/len(types);delta={}
    for n,table in prices.items():
     top=[t for t in types if table[t]==max(table[t] for t in types)]
     delta[n]=blind-sum((utility[t] for t in top),F())/len(top)
    backgrounds.append(dict(ply=ply,slots=len(slots),utility=utility,loss_minus_blind=delta))
   def aggregate(bs):return {n:sum((b['loss_minus_blind'][n] for b in bs),F())/len(bs) for n in prices}
   strata={name:aggregate([b for b in backgrounds if pred(b['ply'])]) for name,pred in [('owner0',lambda v:v%2==0),('owner1',lambda v:v%2==1),('early0_7',lambda v:v<8),('late8_16',lambda v:v>=8)]}
   loo=[aggregate([b for b in backgrounds if b['ply']!=omitted]) for omitted in range(17)]
   row['tasks'][field]=dict(primary=aggregate(backgrounds),strata=strata,leave_one_ranges={n:[min(v[n] for v in loo),max(v[n] for v in loo)] for n in prices},backgrounds=backgrounds,positive_delta_backgrounds=[b['ply'] for b in backgrounds if b['loss_minus_blind']['semantic_v3']>0],negative_delta_backgrounds=[b['ply'] for b in backgrounds if b['loss_minus_blind']['semantic_v3']<0],zero_delta_backgrounds=[b['ply'] for b in backgrounds if b['loss_minus_blind']['semantic_v3']==0])
  res['rules'].append(row)
  print(old['seed'],{f:dict(primary=v['primary']['semantic_v3'],strata={n:x['semantic_v3'] for n,x in v['strata'].items()},loo=v['leave_one_ranges']['semantic_v3']) for f,v in row['tasks'].items()},flush=True)
res['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(p/'phase-audit.json',res)
