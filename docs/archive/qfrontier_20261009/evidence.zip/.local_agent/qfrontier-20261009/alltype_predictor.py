"""Changed decision: complete supported ordinary-type choice, not selected B/X.

Reuse all2456frozen common-slot cells/68backgrounds and original equal-context,
equal-slot weighting. Freeze generic-v2/v3 default tables, no parameter fit.
Exact task regret against per-slot oracle and type-blind uniform control.
Oracle is a descriptive information ceiling, not a learned deployed policy.
Exposed retrospective developmental reanalysis; no new observations or strength.
"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'alltype-predictor.json';assert not out.exists()
src=Path('.local_agent/tasklaw-20261009/common-slot-law.json');cov=Path('.local_agent/generated6-20261008/coverage.json')
d=json.loads(src.read_bytes());rules=json.loads(cov.read_bytes());assert d['complete'] and d['input_sha256']==hashlib.sha256(cov.read_bytes()).hexdigest()
report=dict(scope=__doc__,input_sha256={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in (src,cov)},producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules=[],complete=False)
cells=defaultdict(dict)
for row in d['cells']:cells[(row['seed'],row['ply'],row['source'])][row['type']]=row['task']
for case in rules['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));types=sorted(t.type_id for t in c.piece_types if not t.is_anchor)
 cfg=EvaluationConfig();v2=build_ruleset_profile(c,cfg);v3,scope=build_semantic_opportunity_profile(c,cfg)
 tables={'generic_v2':v2.board_value_by_type,'semantic_v3':v3.board_value_by_type}
 chosen={name:[t for t in types if prices[t]==max(prices[t] for t in types)] for name,prices in tables.items()}
 row=dict(seed=case['seed'],fingerprint=c.ruleset_fingerprint,types=types,prices={n:{t:v[t] for t in types} for n,v in tables.items()},chosen=chosen,cells=[],missing=[],backgrounds=[])
 for (seed,ply,slot),values in sorted(cells.items()):
  if seed!=case['seed']:continue
  if sorted(values)!=types:row['missing'].append(dict(ply=ply,source=slot,values=values));continue
  oracle=max(values.values());losses={n:oracle-sum((F(values[t]) for t in ts),F())/len(ts) for n,ts in chosen.items()}
  losses['blind_uniform']=oracle-sum(values.values(),F())/len(types)
  row['cells'].append(dict(ply=ply,source=slot,task=values,losses=losses))
 contexts=defaultdict(list)
 for cell in row['cells']:contexts[cell['ply']].append(cell)
 for ply,rs in sorted(contexts.items()):
  mean={t:sum((F(r['task'][t]) for r in rs),F())/len(rs) for t in types}
  row['backgrounds'].append(dict(ply=ply,slots=len(rs),means=mean,oracle_task=sum(max(r['task'].values()) for r in rs)/F(len(rs)),losses={n:sum((r['losses'][n] for r in rs),F())/len(rs) for n in (*chosen,'blind_uniform')}))
 bg=row['backgrounds'];assert len(bg)==17
 means={t:sum((r['means'][t] for r in bg),F())/len(bg) for t in types}
 losses={n:sum((r['losses'][n] for r in bg),F())/len(bg) for n in (*chosen,'blind_uniform')}
 maximum=max(means.values());oracle_mean=sum((r['oracle_task'] for r in bg),F())/len(bg)
 row['summary']=dict(paired_slots=len(row['cells']),all_zero_slots=sum(not any(x['task'].values()) for x in row['cells']),missing=len(row['missing']),means=means,losses=losses,
  loss_minus_blind={n:losses[n]-losses['blind_uniform'] for n in chosen},
  descriptive_best_constant_types=[t for t,v in means.items() if v==maximum],descriptive_best_constant_loss=oracle_mean-maximum,
  descriptive_best_background_loss=oracle_mean-sum((max(b['means'].values()) for b in bg),F())/len(bg))
 report['rules'].append(row);print(case['seed'],chosen,row['summary'],flush=True)
report['complete']=True;write_record(out,report)
