"""Predeclared transfer of frozen task/predictor, not new trajectories.

Four existing8x8 rules/routes from generated8 transfer. All actual backgrounds
initial through original route, all ordinary side-to-move slots, all ordinary
standalone replacements. Same instant legal focal unit-removal task, virtual
stop0, equal-slot then equal-background weighting. No history/task-stop legality
or reachable replacement claim. No new seeds/routes/density weights.
Fixed generic-v2/v3 tables stored before new task cells; compare B/X and complete
type choice to blind uniform controls. Each rule120seconds/100000focal Core
transitions checkpoint; preserve failed/zero/missing cells and no favorable
filter. Core/Native compare actual action sets and every focal transition.
Existing inputs exposed; prospective task computation is not untouched holdout.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib,datetime
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.core.identity import position_identity_key
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'transfer-task.json';assert not out.exists()
src=Path('.local_agent/generated8-20261008/transfer.json');d=json.loads(src.read_bytes());assert d['complete']
compiled=[];declaration=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),at=datetime.datetime.now(datetime.timezone.utc).isoformat(),rules=[])
for old in d['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));cfg=EvaluationConfig();v2=build_ruleset_profile(c,cfg);v3,scope=build_semantic_opportunity_profile(c,cfg)
 compiled.append((old,c));types=sorted(t.type_id for t in c.piece_types if not t.is_anchor)
 declaration['rules'].append(dict(seed=old['seed'],fingerprint=c.ruleset_fingerprint,route_plies=len(old['route']),types=types,
   prices={'generic_v2':{t:v2.board_value_by_type[t] for t in types},'semantic_v3':{t:v3.board_value_by_type[t] for t in types}},v3_exclusions={t:scope['types'][t]['excluded'] for t in types}))
write_record(p/'transfer-declaration.json',declaration)
report=dict(scope=__doc__,declaration_sha256=hashlib.sha256((p/'transfer-declaration.json').read_bytes()).hexdigest(),rules=[],complete=False)
def key(a):return json.dumps(action_to_dict(a),sort_keys=True)
def count(pos,owner,anchors):
 return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(v for t,v in pos.hands[owner].counts if t not in anchors)
for old,c in compiled:
 started=time.monotonic();eng=semantic_engine_for(c);nr=compile_native_semantic_rules(c);s=GameSession(c)
 anchors={t.type_id for t in c.piece_types if t.is_anchor};types=sorted(t.type_id for t in c.piece_types if not t.is_anchor)
 row=dict(seed=old['seed'],cells=[],backgrounds=[],transitions=0,legal_sets=0,complete=False);report['rules'].append(row)
 try:
  for ply in range(len(old['route'])+1):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
   pos=s.state.position;side=pos.side_to_move;sources=[i for i,x in enumerate(pos.board) if x is not None and x.owner==side and x.current_type_id not in anchors]
   row['backgrounds'].append(dict(ply=ply,side=side,slots=len(sources),terminal=record_value(s.state.terminal_status)))
   for source in sources:
    for t in types:
     if time.monotonic()-started>=120 or row['transitions']>=100000:raise RuntimeError('declared per-rule cost checkpoint')
     board=list(pos.board);board[source]=Piece(side,t,t,False);cp=replace(pos,board=tuple(board));np=ns.pack_current_position(nr,cp,ply_count=0)
     checked=eng.in_check(cp,side);assert checked==ns.in_check(nr,np,side)
     core={key(_semantic_public_action(eng,a)):(a,b) for a,b in eng.iter_legal_action_bindings(cp) if a.source==source}
     native={}
     for raw in ns.transient_legal_actions(nr,np):
      a=ns.public_action(nr,raw);sq=getattr(a,'from_square',None)
      if sq is not None and sq.rank*c.board_size+sq.file==source:native[key(a)]=raw
     assert core.keys()==native.keys();row['legal_sets']+=1
     before=count(cp,1-side,anchors);rewards=[]
     for k,(a,b) in core.items():
      child=eng._transition(cp,a,b);nc=ns.make_checked(nr,np,native[k])
      assert ns.position_key(nr,nc)==position_identity_key(child,c)
      rewards.append(before-count(child,1-side,anchors));row['transitions']+=1
     row['cells'].append(dict(ply=ply,source=source,type=t,checked=checked,task=max([0]+rewards),focal_actions=len(core),positive_actions=sum(v>0 for v in rewards)))
   write_record(out,report)
   if ply<len(old['route']):s.submit(action_from_dict(old['route'][ply]['action']))
  row['complete']=True
 except Exception as exc:
  row['failure']=dict(kind=type(exc).__name__,message=str(exc))
 row['seconds']=time.monotonic()-started;write_record(out,report)
 print(old['seed'],'complete',row['complete'],'cells',len(row['cells']),'transitions',row['transitions'],'seconds',row['seconds'],row.get('failure'),flush=True)
report['complete']=all(r['complete'] for r in report['rules']);write_record(out,report)
