"""Trace observed pair inversions without fitting a replacement model.
Compare default semantic raw total (quiet+capture), its capture component,
actual frozen-slot projected capture count, actual projected any capture, and
original legal unit-removal task. Stage differences change multiple conditions;
they localize representation/task/context distinctions, not causal attribution.
All types, slots, zero values and backgrounds retained. No new game/search cells.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import combinations
from dataclasses import replace
import json,sys,hashlib,time
root=Path.cwd();sys.path[:0]=[str(root),str(root/'.local_agent/finite-law-20261009')]
from finite_law import collect
from scripts.research_record import write_record
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.pieces import Piece
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
p=Path(__file__).parent;start=time.perf_counter();out=p/'component-audit.json';assert not out.exists()
report=dict(scope=__doc__,inputs={},rules=[],complete=False)
for source,taskfile,transfer in [('.local_agent/generated6-20261008/coverage.json','.local_agent/tasklaw-20261009/common-slot-law.json',False),('.local_agent/generated8-20261008/transfer.json',str(p/'transfer-task.json'),True)]:
 src=Path(source);tf=Path(taskfile);cases=json.loads(src.read_bytes())['cases'];task=json.loads(tf.read_bytes())
 report['inputs'][source]=hashlib.sha256(src.read_bytes()).hexdigest();report['inputs'][taskfile]=hashlib.sha256(tf.read_bytes()).hexdigest()
 for old in cases:
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));cfg=EvaluationConfig();_,scope=build_semantic_opportunity_profile(c,cfg)
  types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);anchors={t.type_id for t in c.piece_types if t.is_anchor};area=c.board_size**2
  edges={t:collect(c,c.ir,t,cfg)[0]['target_enemy'] for t in types};s=GameSession(c)
  taskcells=next(r['cells'] for r in task['rules'] if r['seed']==old['seed']) if transfer else [r for r in task['cells'] if r['seed']==old['seed']]
  lookup={(r['ply'],r['source'],r['type']):r for r in taskcells};row=dict(seed=old['seed'],types=types,profile_scope=scope,cells=[],means={},pairs=[])
  for ply in range(len(old['route'])+1):
   pos=s.state.position;side=pos.side_to_move
   for source,piece in enumerate(pos.board):
    if piece is None or piece.owner!=side or piece.current_type_id in anchors:continue
    for t in types:
     board=list(pos.board);board[source]=Piece(side,t,t,False);cp=replace(pos,board=tuple(board));occ={i for i,x in enumerate(cp.board) if x is not None}
     targets=[]
     for target,events in edges[t][side*area+source].items():
      enemy=cp.board[target]
      if enemy is not None and enemy.owner!=side and enemy.current_type_id not in anchors and any(not occ&cl and (k is None or len(occ&cells)==k) for cl,cells,k in events):targets.append(target)
     original=lookup[(ply,source,t)]
     if not transfer:assert original['geometric_count']==len(targets) and original['geometric_any']==int(bool(targets))
     row['cells'].append(dict(ply=ply,source=source,type=t,geometric_count=len(targets),geometric_any=int(bool(targets)),task=original['task'],checked=original['checked']))
   if ply<len(old['route']):s.submit(action_from_dict(old['route'][ply]['action']))
  for t in types:
   contexts=defaultdict(list)
   for r in row['cells']:
    if r['type']==t:contexts[r['ply']].append(r)
   means={k:sum((F(sum(r[k] for r in rs),len(rs)) for rs in contexts.values()),F())/len(contexts) for k in ('geometric_count','geometric_any','task')}
   pr=scope['types'][t]
   means.update(raw_total=pr['raw'],raw_capture=sum(w*v['capture'] for w,v in zip(cfg.density_weights,pr['curves'])),raw_quiet=sum(w*v['quiet'] for w,v in zip(cfg.density_weights,pr['curves'])))
   row['means'][t]=means
  for a,b in combinations(types,2):
   differences={k:row['means'][a][k]-row['means'][b][k] for k in row['means'][a]}
   row['pairs'].append(dict(pair=[a,b],differences=differences,signs={k:(v>0)-(v<0) for k,v in differences.items()}))
  report['rules'].append(row);write_record(out,report)
  print(old['seed'],[(r['pair'],r['signs']) for r in row['pairs']],flush=True)
report.update(complete=True,seconds=time.perf_counter()-start,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(out,report)
