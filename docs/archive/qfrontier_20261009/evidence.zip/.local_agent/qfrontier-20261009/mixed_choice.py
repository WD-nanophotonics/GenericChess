"""Changed premise from previous constant-stock mixed frontier.

Both actually capturable victims have currentR but different promoted P/Qbases;
onlyQhas a live drop mask. Thus root choices create different hand stock.
Two mirrored base assignments, fixed unit ordering, old/P-zero supplied leaf,
D1/D2q0 equal4096nodes/5sec. Actual replies and followup drop availability are
mechanical task evidence, never independent WDL or price-usefulness proof.
No product classifier change and no state/key merging.
"""
from pathlib import Path
from dataclasses import replace
import sys,time,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import BoardMove,DropMove
from generic_chess.core.coordinates import Square
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'mixed-choice.json';assert not out.exists()
types=[king_type(),T('R',*[RayAtom(v) for v in ((1,0),(-1,0),(0,1),(0,-1))]),
 T('P',LeapAtom((0,1)),is_promotable=True,targets=('R',)),
 T('Q',LeapAtom((1,1)),is_promotable=True,targets=('R',))]
zero=(False,)*64;mask=tuple(i==9 for i in range(64))
base=make_ruleset(8,types,drop_all={'R':zero,'P':zero,'Q':mask})
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=[],complete=False)
for left,right in (('P','Q'),('Q','P')):
 board=[[None]*8 for _ in range(8)];board[0][0]=Piece(0,'K','K');board[7][7]=Piece(1,'K','K');board[3][3]=Piece(0,'R','R');board[3][1]=Piece(1,left,'R',True);board[3][5]=Piece(1,right,'R',True)
 rule=replace(base,initial_position=tuple(map(tuple,board)));c=compile_ruleset_for_execution(rule);s=GameSession(c);before=s.state
 profile,scope=build_semantic_opportunity_profile(c,config);hand=dict(profile.hand_value_by_base_type);hand['P']=0
 models={'old':profile,'P_zero':replace(profile,hand_value_by_base_type=hand)}
 row=dict(left=left,right=right,rules=ruleset_to_dict(rule),board_values=profile.board_value_by_type,hand_values=profile.hand_value_by_base_type,policy=scope['hand_policy'],captures=[],calls=[]);report['cases'].append(row)
 for a in s.legal_actions():
  child=apply_action(before,a,c)
  if child.position.hands[0].total()!=1:continue
  replies=legal_actions(child,c)
  quiet_reply=BoardMove(Square(7,7),Square(6,7));assert quiet_reply in replies
  continuation=apply_action(child,quiet_reply,c)
  drops=[x for x in legal_actions(continuation,c) if isinstance(x,DropMove)]
  row['captures'].append(dict(action=record_value(a),captured_base=next(iter(child.position.hands[0].counts))[0],root_scores={name:-Evaluator(c,prof,config).evaluate(child) for name,prof in models.items()},reply_count=len(replies),quiet_reply=record_value(quiet_reply),followup_drops=record_value(drops)))
 assert len(row['captures'])==2
 unit={t:0 if pt.is_anchor else 1000 for t,pt in c.types_by_id.items()}
 class FixedOrder:
  def __init__(self,leaf):self.leaf=leaf
  def evaluate(self,state):return self.leaf.evaluate(state)
  def capture_order_value(self,moving,captured):return unit[captured.current_type_id]*10-unit[moving.current_type_id]//10
  def type_value(self,tid):return unit[tid]
 for name,prof in models.items():
  ev=Evaluator(c,prof,config)
  for depth in (1,2):
   counter=CountedEvaluator(ev);value,action=reference_minimax(before,depth,counter,c)
   player=AlphaBetaPlayer(c,evaluator_override=FixedOrder(ev),use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
   dec=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
   assert dec.completed_depth==depth and dec.score==value and s.state==before;validate_pv(s,dec)
   row['calls'].append(dict(model=name,depth=depth,reference_score=value,reference_evaluations=counter.calls,decision=record_value(dec)))
 write_record(out,report);print(left,right,row['captures'],[(x['model'],x['depth'],x['decision']['action'],x['decision']['score']) for x in row['calls']],flush=True)
report['complete']=True;write_record(out,report)
