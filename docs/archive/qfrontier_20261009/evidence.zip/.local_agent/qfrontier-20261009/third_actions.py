"""Every third action at retained seed102 common two-ply prefix.

Decision: explain branch-ranking change, not extend frozen root search.
Each matched unit/v3 q cell4096nodes/10s, batch120s checkpoint; ordinary2/hard8.
No independent whole-root WDL/reference or price-usefulness claim.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import BoardMove,action_to_dict
from generic_chess.core.coordinates import Square
from generic_chess.core.transition import initial_state,apply_action,legal_successors
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.search import _Context,_Budget,quiescence,INF,SearchAborted
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'third-actions.json';assert not out.exists()
old=Path('.local_agent/leaf-order-20261009')
cases=json.loads((old/'opening-preflight.json').read_bytes())['cases']
calls=json.loads((old/'exchange-depth3.json').read_bytes())['cases'][0]['calls']
pv=next(x['decision']['principal_variation'] for x in calls if x['model']=='v3' and x['q']==0)
c=compile_ruleset_for_execution(ruleset_from_dict(next(x['rules'] for x in cases if x['seed']==102)))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
profile,scope=build_semantic_opportunity_profile(c,cfg)
unit={t:0 if pt.is_anchor else 1000 for t,pt in c.types_by_id.items()}
profiles={'unit':replace(profile,board_value_by_type=unit,hand_value_by_base_type=unit),'v3':profile}
s=initial_state(c)
for a in pv[:2]:s=apply_action(s,BoardMove(Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id']),c)
assert s.position.side_to_move==0
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),prefix=pv[:2],rows=[],complete=False)
successors=legal_successors(s,c);deadline=time.monotonic()+120
for a,ch in successors:
    if time.monotonic()>deadline:break
    row=dict(action=action_to_dict(a),cells=[]);report['rows'].append(row)
    for name,profile in profiles.items():
        ev=Evaluator(c,profile,cfg);stats=SearchStatistics()
        ctx=_Context(c,ev,TranspositionTable(),stats,_Budget(SearchLimits(max_nodes=4096,max_time_seconds=10),None),SearchTuning(use_root_tactical=False),False,False,2,8,None)
        cell=dict(model=name,static_root_score=-ev.evaluate(ch),complete=False)
        started=time.perf_counter()
        try:cell.update(q_root_score=-quiescence(ch,-INF,INF,3,0,ctx),complete=True)
        except SearchAborted as exc:cell['abort']=str(exc)
        cell.update(seconds=time.perf_counter()-started,stats=record_value(stats));row['cells'].append(cell)
    write_record(out,report)
report.update(complete=len(report['rows'])==len(successors),legal_actions=len(successors))
for name in profiles:
    completed=[(row['action'],next(x for x in row['cells'] if x['model']==name)) for row in report['rows']]
    for kind in ('static_root_score','q_root_score'):
        values=[(a,x[kind]) for a,x in completed if kind in x];maximum=max(x[1] for x in values)
        report[f'{name}_{kind}_max']=dict(score=maximum,actions=[a for a,v in values if v==maximum],all_cells_complete=all(x['complete'] for a,x in completed))
write_record(out,report)
print('actions',len(successors),'complete',report['complete'])
for k,v in report.items():
    if k.endswith('_max'):print(k,v)
