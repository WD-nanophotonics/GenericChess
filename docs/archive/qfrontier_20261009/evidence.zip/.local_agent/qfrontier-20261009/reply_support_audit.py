"""Explain positive one-reply support, without changing the original task.
All original cells remain primary. Audit every positive action: opponent check
before replacement move, child check, empty legal reply set, promotion. These
are descriptive overlapping strata, never a repaired task or validation filter.
Budget: at most10000 replay transitions/60seconds per rule; no search/new route.
"""
from pathlib import Path
from dataclasses import replace
from collections import Counter
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from scripts.research_record import write_record
p=Path(__file__).parent;report=dict(scope=__doc__,inputs={},rules=[],complete=False)
for taskfile,cohort in [('reply-task.json','.local_agent/generated6-20261008/coverage.json'),('reply8-task.json','.local_agent/generated8-20261008/transfer.json')]:
 data=json.loads((p/taskfile).read_bytes());cases=json.loads(Path(cohort).read_bytes())['cases']
 report['inputs'][taskfile]=hashlib.sha256((p/taskfile).read_bytes()).hexdigest()
 for old in data['rules']:
  start=time.monotonic();assert old['complete']
  case=next(c for c in cases if c['seed']==old['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));eng=semantic_engine_for(c);s=GameSession(c)
  row=dict(seed=old['seed'],actions=[],transitions=0,complete=False);report['rules'].append(row)
  byply={}
  for cell in old['cells']:
   if cell['task']>0:byply.setdefault(cell['ply'],[]).append(cell)
  try:
   for ply in range(len(case['route'])+1):
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
    pos=s.state.position;side=pos.side_to_move
    for cell in byply.get(ply,[]):
     board=list(pos.board);board[cell['source']]=Piece(side,cell['type'],cell['type'],False);cp=replace(pos,board=tuple(board))
     precheck=eng.in_check(cp,1-side)
     wanted={json.dumps(a['action'],sort_keys=True):a for a in cell['actions'] if a.get('net',0)>0}
     seen=set()
     for a,b in eng.iter_legal_action_bindings(cp):
      public=action_to_dict(_semantic_public_action(eng,a));key=json.dumps(public,sort_keys=True)
      if key not in wanted:continue
      child=eng._transition(cp,a,b);row['transitions']+=1;seen.add(key)
      replies=list(eng.iter_legal_action_bindings(child));assert len(replies)==wanted[key]['opponent_replies']
      row['actions'].append(dict(ply=ply,source=cell['source'],type=cell['type'],action=public,net=wanted[key]['net'],opponent_checked_before=precheck,child_checked=eng.in_check(child,1-side),replies=len(replies),promotion=public.get('promotion_target_id')))
      if row['transitions']>10000 or time.monotonic()-start>60:raise RuntimeError('audit cost checkpoint')
     assert seen==set(wanted)
    if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]['action']))
   row['complete']=True
  except Exception as exc:row['failure']=dict(kind=type(exc).__name__,message=str(exc))
  row['summary']=dict(positive_cells=len([x for x in old['cells'] if x['task']>0]),positive_actions=len(row['actions']),empty_reply_actions=sum(x['replies']==0 for x in row['actions']),prechecked_actions=sum(x['opponent_checked_before'] for x in row['actions']),child_checked_actions=sum(x['child_checked'] for x in row['actions']),promoted_actions=sum(x['promotion'] is not None for x in row['actions']))
  row['seconds']=time.monotonic()-start;print(old['seed'],row['summary'],flush=True)
report['complete']=all(r['complete'] for r in report['rules']);report['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(p/'reply-support-audit.json',report)
