"""Fixed static B/X predictors on existing frozen same-rule common-slot tasks.

Retrospective exposed development reanalysis; no PV filter, new transition,
trajectory, human fit, holdout or material/strength claim. Each RuleSet gets its
own compiled table. Keep all paired slots/zeros; mark missing separately. Original
task: focal ordinary-enemy board-plus-hand unit removal, virtual stop0, instant
legality ignoring history. Equal slots per background, then17backgrounds/rule.
Report unit50/50 blind control and frozen generic-v2/semantic-v3 predictors.
No choice of coefficient, density law or pair after reading losses.
"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'frozen-predictor.json';assert not out.exists()
source=Path('.local_agent/tasklaw-20261009/common-slot-law.json')
coverage=Path('.local_agent/generated6-20261008/coverage.json')
task=json.loads(source.read_bytes());cohort=json.loads(coverage.read_bytes());assert task['complete']
assert task['input_sha256']==hashlib.sha256(coverage.read_bytes()).hexdigest()
cells=defaultdict(dict)
for r in task['cells']:
 if r['type'] in ('B','X'):
  key=(r['seed'],r['ply'],r['source']);assert r['type'] not in cells[key];cells[key][r['type']]=r['task']
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 input_sha256={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in (source,coverage)},rules=[],complete=False)
for case in cohort['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));cfg=EvaluationConfig()
 generic=build_ruleset_profile(c,cfg);semantic,scope=build_semantic_opportunity_profile(c,cfg)
 predictors={'generic_v2':generic.board_value_by_type,'semantic_v3':semantic.board_value_by_type}
 row=dict(seed=case['seed'],fingerprint=c.ruleset_fingerprint,prices={n:{t:v[t] for t in ('B','X')} for n,v in predictors.items()},predictions={},rows=[],missing=[],backgrounds=[],summary={})
 for name,values in predictors.items():row['predictions'][name]=Fraction(1 if values['X']>values['B'] else 0 if values['X']<values['B'] else Fraction(1,2))
 row['predictions']['blind_half']=Fraction(1,2)
 for (seed,ply,slot),values in sorted(cells.items()):
  if seed!=case['seed']:continue
  if set(values)!= {'B','X'}:row['missing'].append(dict(ply=ply,source=slot,available=values));continue
  b,x=values['B'],values['X'];best=max(b,x)
  row['rows'].append(dict(ply=ply,source=slot,B=b,X=x,contrast=x-b,
     losses={n:best-(mass*x+(1-mass)*b) for n,mass in row['predictions'].items()}))
 contexts=defaultdict(list)
 for r in row['rows']:contexts[r['ply']].append(r)
 for ply,rs in sorted(contexts.items()):
  row['backgrounds'].append(dict(ply=ply,slots=len(rs),B=Fraction(sum(r['B'] for r in rs),len(rs)),X=Fraction(sum(r['X'] for r in rs),len(rs)),losses={n:sum((r['losses'][n] for r in rs),Fraction())/len(rs) for n in row['predictions']}))
 backgrounds=row['backgrounds'];assert len(backgrounds)==17
 row['summary']=dict(paired_slots=len(row['rows']),backgrounds=len(backgrounds),missing_slots=len(row['missing']),both_zero=sum(r['B']==r['X']==0 for r in row['rows']),
   mean_task={t:sum((r[t] for r in backgrounds),Fraction())/len(backgrounds) for t in ('B','X')},
   mean_losses={n:sum((r['losses'][n] for r in backgrounds),Fraction())/len(backgrounds) for n in row['predictions']},
   contrast_counts={str(k):sum(r['contrast']==k for r in row['rows']) for k in sorted({r['contrast'] for r in row['rows']})})
 row['summary']['loss_minus_blind']={n:v-row['summary']['mean_losses']['blind_half'] for n,v in row['summary']['mean_losses'].items() if n!='blind_half'}
 report['rules'].append(row);write_record(out,report)
 print(case['seed'],row['prices'],row['summary'],flush=True)
report['complete']=True;write_record(out,report)
