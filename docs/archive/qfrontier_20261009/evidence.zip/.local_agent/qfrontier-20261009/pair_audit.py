"""Descriptive decomposition of every pair, no post-result predictor or fit.
Retain common complete populations, context-first weights and all zero pairs.
Best rule/context constants are label-based ceilings, not deployable formulas.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from collections import defaultdict
import json,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;report=dict(scope=__doc__,inputs={},rules=[])
for filename in ('alltype-predictor.json','transfer-analysis.json'):
 src=p/filename;d=json.loads(src.read_bytes());report['inputs'][filename]=hashlib.sha256(src.read_bytes()).hexdigest()
 for old in d['rules']:
  types=old['types'];bg=defaultdict(list)
  for cell in old['cells']:bg[cell['ply']].append(cell['task'])
  row=dict(seed=old['seed'],pairs=[],all_zero_slots=old['summary']['all_zero_slots'])
  for a,b in combinations(types,2):
   backgrounds=[];prices=old['prices']
   for ply,cells in sorted(bg.items()):
    ma=sum((F(c[a]) for c in cells),F())/len(cells);mb=sum((F(c[b]) for c in cells),F())/len(cells)
    oracle=sum((F(max(c[a],c[b])) for c in cells),F())/len(cells)
    losses={n:oracle-(ma if table[a]>table[b] else mb if table[b]>table[a] else (ma+mb)/2) for n,table in prices.items()}
    backgrounds.append(dict(ply=ply,slots=len(cells),mean_a=ma,mean_b=mb,oracle=oracle,losses=losses,blind=oracle-(ma+mb)/2,context_oracle_loss=oracle-max(ma,mb),both_zero=sum(c[a]==c[b]==0 for c in cells)))
   def avg(k):return sum((r[k] for r in backgrounds),F())/len(backgrounds)
   ma,mb,oracle=avg('mean_a'),avg('mean_b'),avg('oracle');loss={n:sum((r['losses'][n] for r in backgrounds),F())/len(backgrounds) for n in prices}
   const=oracle-max(ma,mb);context=avg('context_oracle_loss')
   row['pairs'].append(dict(pair=[a,b],price_difference={n:t[a]-t[b] for n,t in prices.items()},mean_difference=ma-mb,losses=loss,blind=avg('blind'),loss_minus_blind={n:v-avg('blind') for n,v in loss.items()},wrong_rule_rank_cost={n:v-const for n,v in loss.items()},context_adaptation=const-context,residual=context,backgrounds=backgrounds))
  report['rules'].append(row)
  print(old['seed'],[(r['pair'],r['price_difference'],str(r['mean_difference']),str(r['loss_minus_blind']['semantic_v3'])) for r in row['pairs']],flush=True)
report['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
write_record(p/'pair-audit.json',report)
