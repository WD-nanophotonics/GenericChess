"""Check the source-domain adapter before reusing a geometric literature formula.
Local enumerations of actual Leap/Ray targets, not material/utility evidence.
Source: Feys arXiv2605.20229v1 section2 explicitly halves full diagonal totals
for its single-color Bishop convention. Our ordinary Bishop type is averaged
over every possible source. Retain all-source and conditional color totals.
No new coefficient, human-price fit, gameplay test or general theorem.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.core.movement import LeapAtom,RayAtom
from scripts.research_record import write_record
p=Path('.local_agent/qfrontier-20261009');rows=[]
for n in range(4,13):
 atoms={'B':[RayAtom(v) for v in ((1,1),(-1,1),(1,-1),(-1,-1))],
 'R':[RayAtom(v) for v in ((1,0),(-1,0),(0,1),(0,-1))],
 'N':[LeapAtom((a,b)) for a,b in ((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1))],
 'K':[LeapAtom((a,b)) for a in (-1,0,1) for b in (-1,0,1) if a or b]}
 endpoints={}
 for tid,moves in atoms.items():
  counts=[]
  for r in range(n):
   for f in range(n):
    targets=set()
    for atom in moves:
     if isinstance(atom,LeapAtom):
      df,dr=atom.offset;tf,tr=f+df,r+dr
      if 0<=tf<n and 0<=tr<n:targets.add((tf,tr))
     else:
      df,dr=atom.direction;k=1
      while 0<=f+k*df<n and 0<=r+k*dr<n:
       targets.add((f+k*df,r+k*dr));k+=1
    counts.append(len(targets))
  endpoints[tid]=counts
 totals={t:sum(v) for t,v in endpoints.items()}
 assert totals==dict(B=2*n*(n-1)*(2*n-1)//3,R=2*n*n*(n-1),N=8*(n-1)*(n-2),K=4*(n-1)*(2*n-1))
 colors=[]
 for color in (0,1):
  ids=[r*n+f for r in range(n) for f in range(n) if (r+f)%2==color]
  subtotal=sum(endpoints['B'][i] for i in ids)
  colors.append(dict(color=color,eligible_sources=len(ids),total=subtotal,conditional_mean=F(subtotal,len(ids)),all_source_mean=F(subtotal,n*n)))
 rows.append(dict(n=n,totals=totals,ordinary_all_source_means={t:F(v,n*n) for t,v in totals.items()},colors=colors,bishop_king_total_ratio=F(totals['B'],totals['K']),paper_half_bishop_total=F(totals['B'],2),ordinary_archbishop_total=totals['B']+totals['N']))
write_record(p/'literature-geometry.json',dict(scope=__doc__,rows=rows,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source='https://arxiv.org/html/2605.20229v1'))
for r in rows:print(r,flush=True)
