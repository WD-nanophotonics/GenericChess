"""Frozen seed102 PV frontier: inventory, independent finite q recurrence.

No new root search, D4, reference-cap extension or strength claim. Each of the
two retained v3 D3 PV leaves gets4096nodes/10seconds, ordinaryq2/hard8.
Full-window product q at exactly that leaf is an execution control, not an
independent evaluator. A local frontier value does not certify the root tree.
"""
from pathlib import Path
import sys, json, time, hashlib
sys.path.insert(0, str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import BoardMove, action_to_dict
from generic_chess.core.coordinates import Square
from generic_chess.core.transition import initial_state, apply_action, legal_successors
from generic_chess.core.attacks import is_in_check
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.search import (terminal_score, quiescence,
    _Context, _Budget, INF)
from generic_chess.ai.alphabeta.quiescence import classify_noisy
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record, record_value

p = Path(__file__).parent
out = p/'pv-frontier.json'
assert not out.exists()
old = Path('.local_agent/leaf-order-20261009')
cases = json.loads((old/'opening-preflight.json').read_bytes())['cases']
calls = json.loads((old/'exchange-depth3.json').read_bytes())['cases'][0]['calls']
c = compile_ruleset_for_execution(ruleset_from_dict(next(x['rules'] for x in cases if x['seed']==102)))
config = EvaluationConfig(dynamic_mobility_weight=0, anchor_escape_weight=0, promotion_potential_weight=0)
profile, scope = build_semantic_opportunity_profile(c, config)
ev = Evaluator(c, profile, config)
assert not c.declarations

def parse(a):
    return BoardMove(Square(**a['from_square']), Square(**a['to_square']), a['promotion_target_id'])

def inventory(s):
    board={}; hands={}
    for pc in s.position.board:
        if pc: board[(pc.owner,pc.current_type_id)] = board.get((pc.owner,pc.current_type_id),0)+1
    for owner,h in enumerate(s.position.hands):
        for tid,n in h.counts: hands[(owner,tid)]=n
    return dict(board=record_value(board), hands=record_value(hands),
                root_score=ev.evaluate(s)*(1 if s.position.side_to_move==0 else -1),
                side=s.position.side_to_move, check=is_in_check(s.position,s.position.side_to_move,c),
                terminal=record_value(s.terminal_status))

report=dict(scope=__doc__, producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_hashes={n:hashlib.sha256((old/n).read_bytes()).hexdigest() for n in ('opening-preflight.json','exchange-depth3.json')},
    cases=[],complete=False)
for call in calls:
    if call['model']!='v3': continue
    state=initial_state(c); prefix=[inventory(state)]
    for row in call['decision']['principal_variation']:
        state=apply_action(state,parse(row),c); prefix.append(inventory(state))
    stats=dict(nodes=0,transitions=0,evaluations=0); deadline=time.monotonic()+10
    def independent(s,depth):
        stats['nodes']+=1
        if stats['nodes']>4096 or time.monotonic()>deadline: raise RuntimeError('independent frontier cost fuse')
        if s.terminal_status.is_terminal: return terminal_score(s.terminal_status,s.position.side_to_move,3+depth),[]
        checked=is_in_check(s.position,s.position.side_to_move,c)
        if checked and depth>=8: raise RuntimeError('independent check hard limit')
        stats['evaluations']+=1
        best=-INF if checked else ev.evaluate(s); line=[]
        if not checked and depth>=2: return best,line
        successors=legal_successors(s,c); stats['transitions']+=len(successors)
        allowed=list(a for a,ch in successors) if checked else classify_noisy(s,successors,c)
        if checked and not allowed: raise AssertionError('nonterminal check without evasions')
        for a,ch in successors:
            if a not in allowed:continue
            value,path=independent(ch,depth+1); value=-value
            if value>best:best,line=value,[a]+path
        return best,line
    row=dict(original_q=call['q'], original_root_score=call['decision']['score'],
             prefix=prefix, complete=False)
    report['cases'].append(row)
    try:
        score,line=independent(state,0)
        row.update(independent_score=score,independent_root_score=-score,
                   line=[action_to_dict(a) for a in line],cost=stats.copy())
        runtime_state=state
        runtime_stats=SearchStatistics()
        ctx=_Context(c,ev,TranspositionTable(),runtime_stats,
            _Budget(SearchLimits(max_nodes=4096,max_time_seconds=10),None),
            SearchTuning(use_root_tactical=False),False,False,2,8,None)
        product=quiescence(state,-INF,INF,3,0,ctx)
        assert product==score,(product,score)
        row.update(product_score=product,product_stats=record_value(runtime_stats))
        path=[inventory(state)]
        for a in line:state=apply_action(state,a,c);path.append(inventory(state))
        row.update(q_prefix=path,complete=True)
    except RuntimeError as exc:row.update(failure=str(exc),cost=stats.copy())
    write_record(out,report)
    print(call['q'],row.get('independent_root_score'),row.get('line'),row.get('failure'),flush=True)
report['complete']=all(x['complete'] for x in report['cases']);write_record(out,report)
