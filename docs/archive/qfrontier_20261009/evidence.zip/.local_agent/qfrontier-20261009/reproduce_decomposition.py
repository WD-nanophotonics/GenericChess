"""Reproduce already-observed interactive decomposition; no new empirical run.
The original artifact is never overwritten. Verify every exact stored row.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;d=json.loads((p/'frozen-predictor.json').read_bytes());old=json.loads((p/'regret-decomposition.json').read_bytes())
rows=[]
for rule in d['rules']:
 bg=rule['backgrounds'];means=rule['summary']['mean_task'];means={t:F(v) for t,v in means.items()}
 def avg(values):return sum(values,F())/len(bg)
 oracle=avg([sum((F(max(x['B'],x['X'])) for x in rule['rows'] if x['ply']==b['ply']),F())/b['slots'] for b in bg])
 fixed=F(rule['summary']['mean_losses']['semantic_v3']);const=oracle-max(means.values());context=oracle-avg([max(F(b['B']),F(b['X'])) for b in bg])
 rows.append(dict(seed=rule['seed'],prices=rule['prices'],means=means,fixed_loss=fixed,rule_mean_oracle_loss=const,context_mean_oracle_loss=context,wrong_rule_rank_cost=fixed-const,context_adaptation_reduction=const-context,residual_slot_context_loss=context,context_signs={str(s):[b['ply'] for b in bg if (F(b['X'])>F(b['B']))-(F(b['X'])<F(b['B']))==s] for s in (-1,0,1)}))
assert record_value(rows)==old['rows']
write_record(p/'decomposition-verification.json',dict(scope=__doc__,rows_exactly_reproduced=len(rows),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputs={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ('frozen-predictor.json','regret-decomposition.json')}))
print('All4original decomposition rows exactly reproduced')
