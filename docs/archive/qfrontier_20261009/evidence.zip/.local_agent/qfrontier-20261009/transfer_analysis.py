"""Analyze predeclared transfer without refitting; exact equal-background/slot loss.
Top choice and every unordered pair are separate uses. Pairwise regret averages
all pairs uniformly within slots, including zero/tied outcomes. Descriptive
oracles are information ceilings, never fitted policies or holdout evidence.
"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
import json,hashlib,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent
decl=json.loads((p/'transfer-declaration.json').read_bytes())
d=json.loads((p/'transfer-task.json').read_bytes());assert d['complete']
assert d['declaration_sha256']==hashlib.sha256((p/'transfer-declaration.json').read_bytes()).hexdigest()
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules=[])
for raw,frozen in zip(d['rules'],decl['rules']):
 assert raw['seed']==frozen['seed'] and raw['complete']
 types=frozen['types'];tables=frozen['prices'];groups=defaultdict(dict)
 for c in raw['cells']:groups[(c['ply'],c['source'])][c['type']]=c['task']
 row=dict(seed=raw['seed'],types=types,prices=tables,missing=[],backgrounds=[],cells=[],transitions=raw['transitions'],legal_sets=raw['legal_sets'],seconds=raw['seconds'])
 for (ply,slot),u in sorted(groups.items()):
  if sorted(u)!=types:row['missing'].append(dict(ply=ply,source=slot,values=u));continue
  loss={};pairs={}
  for name,table in tables.items():
   top=[t for t in types if table[t]==max(table[t] for t in types)]
   loss[name]=max(u.values())-sum((F(u[t]) for t in top),F())/len(top)
   pl=[]
   for a,b in combinations(types,2):
    picked=[a] if table[a]>table[b] else [b] if table[b]>table[a] else [a,b]
    pl.append(max(u[a],u[b])-sum((F(u[t]) for t in picked),F())/len(picked))
   pairs[name]=sum(pl,F())/len(pl)
  loss['blind']=max(u.values())-sum(u.values(),F())/len(types)
  pairs['blind']=sum((F(abs(u[a]-u[b]),2) for a,b in combinations(types,2)),F())/F(len(types)*(len(types)-1),2)
  row['cells'].append(dict(ply=ply,source=slot,task=u,losses=loss,pair_losses=pairs))
 for bg in raw['backgrounds']:
  rs=[c for c in row['cells'] if c['ply']==bg['ply']]
  assert len(rs)==bg['slots'] and rs
  row['backgrounds'].append(dict(ply=bg['ply'],slots=len(rs),means={t:sum((F(c['task'][t]) for c in rs),F())/len(rs) for t in types},losses={n:sum((c['losses'][n] for c in rs),F())/len(rs) for n in (*tables,'blind')},pair_losses={n:sum((c['pair_losses'][n] for c in rs),F())/len(rs) for n in (*tables,'blind')}))
 bgs=row['backgrounds'];assert len(bgs)==frozen['route_plies']+1
 row['summary']=dict(slots=len(row['cells']),all_zero_slots=sum(not any(c['task'].values()) for c in row['cells']),missing=len(row['missing']),chosen={n:[t for t in types if v[t]==max(v[t] for t in types)] for n,v in tables.items()},means={t:sum((b['means'][t] for b in bgs),F())/len(bgs) for t in types})
 for field in ('losses','pair_losses'):
  avg={n:sum((b[field][n] for b in bgs),F())/len(bgs) for n in (*tables,'blind')}
  row['summary'][field]=avg;row['summary'][field+'_minus_blind']={n:avg[n]-avg['blind'] for n in tables}
 report['rules'].append(row)
 print(raw['seed'],row['summary'],flush=True)
write_record(p/'transfer-analysis.json',report)
