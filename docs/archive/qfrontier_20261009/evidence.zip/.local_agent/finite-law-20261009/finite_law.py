"""Conditional finite-inventory prototype; no product default/profile changes."""
import sys,inspect,textwrap,json,time,hashlib
from pathlib import Path
from itertools import combinations
from math import comb
from fractions import Fraction as F
from functools import lru_cache
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
import generic_chess.ai.evaluation.semantic as sem
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.rules.compiler import compile_ruleset_for_execution,compile_semantic_ir
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_from_dict
source=textwrap.dedent(inspect.getsource(sem._semantic_opportunity))
source=source[:source.index('    curves = []')]+'    return edges, included, excluded\n'
namespace=dict(sem.__dict__);exec(source,namespace);collect=namespace['_semantic_opportunity']
def choose(n,k):return comb(n,k) if 0<=k<=n else 0
def canon(events):return tuple(sorted(events,key=lambda e:(sorted(e[0]),sorted(e[1]),-1 if e[2] is None else e[2])))
@lru_cache(None)
def intersection(events,N,M):
    if not 0<=M<=N:return F(0)
    clear=frozenset().union(*(e[0] for e in events))
    constraints=sorted({(cells-clear,count) for _,cells,count in events if count is not None},key=lambda x:(sorted(x[0]),x[1]))
    if any(k<0 or k>len(cells) for cells,k in constraints):return F(0)
    cells=sorted(frozenset().union(*(c for c,_ in constraints)))
    assert len(clear)+len(cells)<=N
    states={((0,)*len(constraints),0):1}
    for cell in cells:
        mask=tuple(int(cell in c) for c,_ in constraints);nxt={}
        for (s,r),ways in states.items():
            nxt[(s,r)]=nxt.get((s,r),0)+ways
            z=tuple(a+b for a,b in zip(s,mask))
            if r<M and all(v<=k for v,(_,k) in zip(z,constraints)):
                nxt[(z,r+1)]=nxt.get((z,r+1),0)+ways
        states=nxt
    goal=tuple(k for _,k in constraints);free=N-len(clear)-len(cells)
    return F(sum(ways*choose(free,M-r) for (s,r),ways in states.items() if s==goal),choose(N,M))
@lru_cache(None)
def union(events,N,M):
    if all(k is None for _,_,k in events):
        paths={e[0] for e in events};paths={p for p in paths if not any(q<p for q in paths)}
        events=canon((p,frozenset(),None) for p in paths)
    if len(events)>12:raise ValueError('same12-event complexity boundary as product')
    return sum(((-1)**(k+1)*intersection(canon(xs),N,M) for k in range(1,len(events)+1) for xs in combinations(events,k)),F(0))
def measure(c,stock=None):
    ir=c.ir if hasattr(c,'ir') else compile_semantic_ir(c)
    A=c.board_shape.area if hasattr(c,'ir') else c.board_size**2
    if stock is None:
        board=c.initial_position
        if hasattr(board,'board'):board=board.board
        stock=tuple(sum(p is not None and p.owner==owner for p in board) for owner in (0,1))
    assert min(stock)>=1 and sum(stock)<=A
    cfg=EvaluationConfig();rows={}
    for pt in c.piece_types:
        edges,included,excluded=collect(c,ir,pt.type_id,cfg);totals={kind:F(0) for kind in edges}
        for kind,buckets in edges.items():
            for index,bucket in enumerate(buckets):
                owner,src=divmod(index,A);n=stock[owner]-1+stock[1-owner]
                count=A-sum(stock) if kind=='target_empty' else stock[1-owner]
                occupied=n if kind=='target_empty' else n-1
                for target,events in bucket.items():
                    assert target!=src and all(src not in a|b and target not in a|b for a,b,_ in events)
                    if count:totals[kind]+=F(count,A-1)*union(canon(events),A-2,occupied)
        quiet=totals['target_empty']/(2*A);capture=totals['target_enemy']/(2*A)
        old=sem._semantic_opportunity(c,ir,pt.type_id,cfg)
        rows[pt.type_id]=dict(quiet=float(quiet),capture=float(capture),raw=float(quiet+capture),exact_raw=str(quiet+capture),independent_raw=old['raw'],included=included,excluded=excluded,anchor=pt.is_anchor)
    from statistics import median
    scale=median(r['raw'] for r in rows.values() if not r['anchor'])
    for r in rows.values():r['median_scaled']=r['raw']/scale if scale else None
    return dict(area=A,stock=stock,types=rows)
def exhaustive_controls():
    checked=0
    for N in range(2,9):
        a=frozenset(range(min(3,N)));b=frozenset(range(1,min(4,N)))
        families=[((a,frozenset(),None),),((a,frozenset(),None),(b,frozenset(),None)),((frozenset(),a,1),),((frozenset(),a,1),(frozenset(),b,1)),((frozenset({0}),a,1),),((a,a,1),),((frozenset(),a,0),(a,frozenset(),None)),((frozenset(),a,2),(frozenset({1}),b,1)),((frozenset(),frozenset(),None),)]
        for M in range(N+1):
            layouts=[frozenset(x) for x in combinations(range(N),M)]
            for events in families:
                truth=F(sum(any(not occ&cl and (k is None or len(occ&cells)==k) for cl,cells,k in events) for occ in layouts),len(layouts))
                actual=union(canon(events),N,M);assert actual==truth,(N,M,events,actual,truth);checked+=1
    return checked
if __name__=='__main__':
    p=Path(__file__).parent;t=time.perf_counter();checks=exhaustive_controls()
    rows={'chess':measure(compile_ruleset_for_execution(build_western_chess_ruleset())),'shogi':measure(compile_ruleset_for_execution(build_standard_shogi_ruleset()))}
    coverage=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
    for x in coverage['cases']:rows['generated6-'+str(x['seed'])]=measure(compile_ruleset_for_execution(ruleset_from_dict(x['rules'])))
    out=dict(complete=True,law='uniform fixed initial on-board stock; hypothetical source substitutes own unit; target conditioned exactly; equal owner/source',scope='anonymous occupancy; same supported subset/exclusions as semantic-opportunity-v1; no price/default/unique-law claim',exhaustive_controls=checks,rows=rows,seconds=time.perf_counter()-t,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cache=dict(union=union.cache_info()._asdict(),intersection=intersection.cache_info()._asdict()))
    (p/'finite-law.json').write_bytes(json.dumps(out,indent=2,sort_keys=True).encode());print(json.dumps(out,indent=2))
