from pathlib import Path
import sys,json,time,cProfile,pstats
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/reply-witness-20261015';mode=sys.argv[1];order=int(sys.argv[2])
from scripts import full_q_refresh_comparison as p
from generic_chess.rules.serialization import deserialize_ruleset
x=json.loads((B/'cold_inputs/4331.json').read_text(encoding='utf-8'));rules=deserialize_ruleset(json.dumps(x['ruleset']));prof=cProfile.Profile();t=time.perf_counter()
if mode=='profile':prof.enable()
c=p.compile_legacy_ruleset_for_semantic_execution(rules)
if mode=='profile':prof.disable()
elapsed=time.perf_counter()-t;rows=[]
if mode=='profile':
 prof.dump_stats(str(B/f'admission-{order}-private.prof'));stats=pstats.Stats(prof)
 for (file,line,fn),(cc,nc,tt,ct,callers)in sorted(stats.stats.items(),key=lambda kv:kv[1][3],reverse=True):
  fp=Path(file)
  try:label=fp.resolve().relative_to(R).as_posix()
  except (ValueError,OSError):label=fp.name
  rows.append(dict(file=label,line=line,function=fn,primitive_calls=cc,total_calls=nc,self_seconds=tt,cumulative_seconds=ct))
(B/f'admission-{order}-{mode}.json').write_bytes(json.dumps(dict(complete=True,mode=mode,order=order,seconds=elapsed,functions=rows,scope='One4331compile; profiler cumulative fields overlap. Existing pure compiler/initial validation, no output rule changes.')).encode());print(mode,order,round(elapsed,4))
