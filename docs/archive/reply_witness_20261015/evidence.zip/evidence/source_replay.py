from pathlib import Path
import sys,subprocess,shutil,sysconfig,json,time,uuid,hashlib
R=Path.cwd();B=R/'.local_agent/reply-witness-20261015';dest=B/('source-export-'+uuid.uuid4().hex[:8]);dest.mkdir();assert dest.resolve().is_relative_to(B.resolve())
for folder in ('generic_chess','scripts'):
 for p in (R/folder).rglob('*'):
  if not p.is_file()or '__pycache__'in p.parts or p.suffix not in('.py','.c','.h','.json','.toml'):continue
  out=dest/p.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
for p in [R/'tests/conftest.py']+list((R/'tests/product').glob('*.py'))+[R/'tests/development/test_reference_history_scope.py',R/'tests/development/test_reference_declaration_scope.py']:
 out=dest/p.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
replay=dest/'replay';replay.mkdir();shutil.copyfile(R/'.local_agent/immediate-goal-20261015/v2-boundary-inputs.json',replay/'inputs.json')
for p in (B/'src_wide_witness').glob('*'):
 if p.suffix in('.c','.h'):
  out=replay/'src_v2'/p.name;out.parent.mkdir(exist_ok=True);shutil.copyfile(p,out)
(dest/'pytest.ini').write_bytes(b'[pytest]\npythonpath=tests tests/product\n')
src=R/'.local_agent/immediate-goal-20261015/replay_qualify.py';s=src.read_text(encoding='utf-8-sig');s=s[:s.index('# Rebuild both32goal roots')];s=s.replace("R/'replay/v2-boundary-inputs.json'","R/'replay/inputs.json'");s=s.replace("nr=nc.compile_native_semantic_rules(c,backend_module=v2)","nr=nc.compile_native_semantic_rules(c,backend_module=v1 if c.board_size<=16 else v2)");s=s.replace("SearchLimits(max_depth=1,max_nodes=64,max_time_seconds=2)","SearchLimits(max_depth=3,max_nodes=1024,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8)")
# Earlier driver validated full roots; add complete returned-PV history checks.
needle="results.append({'root':x['name'],'depth':r.completed_depth,'score':r.score})"
replace="""results.append({'root':x['name'],'depth':r.completed_depth,'score':r.score})
 state=s.state;np=pos;witnesses=list(s._search_witnesses)
 for a in r.principal_variation:
  np=sem.make_checked(nr,np,pack_semantic_action(nr,state.position,a));state=apply_action(state,a,c);witnesses.append(state.position);sn=sem.snapshot(nr,np);ex=expected_snapshot(state.position,nr,c)
  for field in ['board','hands','aux_state','side']:assert record_value(sn[field])==record_value(ex[field])
  assert [''.join(f'{v:016x}'for v in hh)for hh in sn['history']]==[str(position_identity_key(w,c))for w in witnesses]
  assert sn['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
  assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
""";assert needle in s;s=s.replace(needle,replace);s+="\n(R/'replay/qualification.json').write_bytes(json.dumps(dict(complete=True,roots=len(results),legal_actions=actions,results=results,seconds=time.perf_counter()-start,no_older_private_reads=True)).encode());print('FULLSTATE',len(results),actions)\n";(replay/'qualify.py').write_bytes(s.encode())
# Qualify the explicitly prepared candidate sources, not the still-unchanged product.
for source in (B/'final_both_src').glob('*'):
 if source.suffix in('.c','.h'):shutil.copyfile(source,dest/'generic_chess/_native'/source.name)
shutil.copyfile(B/'test_native_geometry_first_source.py',dest/'tests/product/test_native_geometry_first_source.py')
start=time.perf_counter();rows=[];suffix=sysconfig.get_config_var('EXT_SUFFIX')
for label,src,target in [('v1',dest/'generic_chess/_native',dest/'generic_chess'/('_native_core'+suffix)),('v2',replay/'src_v2',replay/('wide'+suffix))]:
 r=subprocess.run([str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in sorted(src.glob('*.c'))],'-o',str(target)],capture_output=True,timeout=180);(B/f'source-build-{label}.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace');rows.append(dict(build=label,exit=r.returncode))
for label,cmd in [('focused',[sys.executable,'-m','pytest','-q','-c','pytest.ini','-p','no:cacheprovider','--basetemp','replay/pytest-source','tests/product/test_native_geometry_first_source.py','tests/product/test_native_q_history_deferral.py','tests/product/test_native_pending_continuation.py','tests/product/test_native_pv_replay_boundaries.py','tests/development/test_reference_history_scope.py','tests/development/test_reference_declaration_scope.py']),('fullstate',[sys.executable,'replay/qualify.py',str(R/'.local_agent')])]:
 r=subprocess.run(cmd,cwd=dest,capture_output=True,timeout=300);(B/f'source-{label}.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,(label,r.stdout.decode(errors='replace'),r.stderr.decode(errors='replace'));rows.append(dict(check=label,exit=r.returncode))
shutil.copyfile(replay/'qualification.json',B/'source-qualification.json');(B/'source-replay.json').write_bytes(json.dumps(dict(complete=True,export=str(dest),seconds=time.perf_counter()-start,rows=rows,focused_tests=38,scope='Prepared combined candidateV1 plus optional reply historicalV2 rebuilt from source; full35roots4497actions/PVhistory; no copied binary or older private input reads. Existing Windows/Python/Zig libraries, not clean-machine installer.'),indent=2).encode());print('CANDIDATE SOURCE PASS',dest,time.perf_counter()-start)
