from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
B=R/'.local_agent/reply-witness-20261015';mods={}
for arm,prefix in [('final','baseline'),('post_profile','dense')]:
 spec=importlib.util.spec_from_file_location(arm+'._native_core',next(B.glob(prefix+'*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
rows=[];mismatches=[];start=time.perf_counter()
for seed in (4011,4013,4021,4023,4031,4033,4041,4043):
 x=json.loads((b/f'input-{seed}.json').read_text(encoding='utf-8'))['samples'][0];c,s=case(x);nr={a:nc.compile_native_semantic_rules(c,backend_module=m)for a,m in mods.items()};prof=p.build_ruleset_profile(c,p.EvaluationConfig());bv={t:int(round(v))for t,v in prof.board_value_by_type.items()};hv={t:int(round(v))for t,v in prof.hand_value_by_base_type.items()}
 for order in (0,1):
  pair={}
  for arm in (list(mods)if order==0 else list(mods)[::-1]):
   assert time.perf_counter()-start<180
   if arm=='post_profile':pass
   t=time.perf_counter();res=SemanticSearchEngine(c,nr[arm],board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=3,max_nodes=1024,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;metrics=None;validate(res,s,nr[arm]);pair[arm]=signature(res);rows.append(dict(seed=seed,n=c.board_size,order=order,arm=arm,seconds=wall,result=record_value(res),metrics=metrics))
  if pair['final']!=pair['post_profile']:mismatches.append(dict(seed=seed,order=order,fields=[k for k in pair['final']if pair['final'][k]!=pair['post_profile'].get(k)]))
(B/'dense-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,mismatches=mismatches,seconds=time.perf_counter()-start)).encode());assert not mismatches;print('POST COMPLETE',len(rows),time.perf_counter()-start)
