from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
import math,statistics,hashlib,collections
B=R/'.local_agent/reply-witness-20261015';plan=json.loads((B/'wide-plan.json').read_text(encoding='utf-8'));driver=json.loads((B/'wide-results.json').read_text(encoding='utf-8'));assert driver['complete'];rows=[];pairs=[];audits=[];mods={}
for arm in('baseline','witness'):
 spec=importlib.util.spec_from_file_location('auditwide'+arm+'._native_core',next(B.glob('wide_'+arm+'*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
start=time.perf_counter()
for seed in plan['families']:
 d=json.loads((B/f'wide-{seed}.json').read_text(encoding='utf-8'));assert d['complete'];rows+=d['rows'];x=json.loads((b/f'generation-{seed}-base1024.json').read_text(encoding='utf-8'));raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c);assert record_value(s.state)==x['state'];nrs={a:nc.compile_native_semantic_rules(c,backend_module=m)for a,m in mods.items()}
 for row in d['rows']:
  nr=nrs[row['arm']];state=s.state;pos=pack_semantic_search_position(c,nr,s);w=list(s._search_witnesses);edges=0
  for encoded in row['result']['principal_variation']:
   a,=[a for a in s.legal_actions()if record_value(a)==encoded]if edges==0 else[a for a in __import__('generic_chess.core.movegen',fromlist=['legal_actions']).legal_actions(state,c)if record_value(a)==encoded]
   pos=sem.make_checked(nr,pos,pack_semantic_action(nr,state.position,a));state=apply_action(state,a,c);w.append(state.position);sn=sem.snapshot(nr,pos);ex=expected_snapshot(state.position,nr,c)
   for field in('board','hands','aux_state','side'):assert record_value(sn[field])==record_value(ex[field])
   assert [''.join(f'{v:016x}'for v in hh)for hh in sn['history']]==[str(position_identity_key(p,c))for p in w]
   assert sn['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
   assert sem.terminal_status(nr,pos)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner);edges+=1
  audits.append(dict(seed=seed,q=row['q'],order=row['order'],arm=row['arm'],edges=edges,full_history=True))
 for q in plan['q']:
  for order in range(plan['orders']):
   pp={r['arm']:r for r in d['rows']if r['q']==q and r['order']==order};a,z=pp['baseline'],pp['witness'];diff=[k for k,v in a['result'].items()if 'elapsed'not in k and v!=z['result'].get(k)];pairs.append(dict(seed=seed,q=q,order=order,ratio=z['caller_seconds']/a['caller_seconds'],non_time_mismatches=diff,clock_censored=any(r['result']['termination_reason']=='time_budget'for r in pp.values()),depth_delta=z['result']['completed_depth']-a['result']['completed_depth'],same_action=a['result']['action']==z['result']['action'],baseline_qnodes=a['result']['qnodes'],candidate_qnodes=z['result']['qnodes'],baseline_policy=[a['result'][k]for k in('completed_depth','result_ordinary_qdepth','result_check_hard_qdepth')],candidate_policy=[z['result'][k]for k in('completed_depth','result_ordinary_qdepth','result_check_hard_qdepth')],hint_counts=z['hint_counts']))
summary=[]
for q in plan['q']:
 pp=[x for x in pairs if x['q']==q];fixed=[x for x in pp if not x['clock_censored']];summary.append(dict(q=q,pairs=len(pp),fixed_pairs=len(fixed),samework_ratio=math.exp(statistics.mean(math.log(x['ratio'])for x in fixed))if fixed else None,clock_censored=sum(x['clock_censored']for x in pp),deeper=sum(x['depth_delta']>0 for x in pp),same_depth=sum(x['depth_delta']==0 for x in pp),shallower=sum(x['depth_delta']<0 for x in pp),same_action=sum(x['same_action']for x in pp),hint_hits=sum(x['hint_counts'][0]for x in pp),hint_misses=sum(x['hint_counts'][1]for x in pp)))
out=dict(complete=True,planned_queries=64,recorded_queries=len(rows),summary=summary,pairs=pairs,nonclock_mismatches=[x for x in pairs if x['non_time_mismatches']and not x['clock_censored']],original_batch_seconds=driver['seconds'],full_history_audit=dict(queries=len(audits),edges=sum(x['edges']for x in audits),seconds=time.perf_counter()-start,rows=audits,scope='Retrospective full history replay after original driver checked live SHA/fields only; same recorded decisions, no timing rerun or replacement.'),scope='Exposed prior32rules, changed fixed16knodes, optional historicalV2/no-auto only. In-progress q work differs from retained completed q policy. No strength claim or default V2 activation.');(B/'wide-summary.json').write_bytes(json.dumps(out,indent=2).encode());print({k:v for k,v in out.items()if k not in('pairs','full_history_audit')});print('AUDITED',len(audits),out['full_history_audit']['edges'])
