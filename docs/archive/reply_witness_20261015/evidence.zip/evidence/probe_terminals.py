from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
from conftest import make_ruleset
from generic_chess.core.pieces import PieceType
from generic_chess.core.movement import LeapAtom,RayAtom
B=R/'.local_agent/reply-witness-20261015';spec=importlib.util.spec_from_file_location('terminalhint._native_core',next(B.glob('probe*.pyd')));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
k=PieceType('K','Anchor',(),is_anchor=True);f=PieceType('F','F',(LeapAtom((0,1)),));ray=PieceType('R','Ray',(RayAtom((0,1)),RayAtom((1,0))));mask=(False,)*16;rows=[]
for name,lines in [('stalemate',['...k','....','....','KF..']),('checkmate',['...k','....','....','K.R.'])]:
 rs=make_ruleset(4,[k,f,ray],lines,drop_all={'F':mask,'R':mask},repetition_limit=4,max_ply=64);c=p.compile_legacy_ruleset_for_semantic_execution(rs);s=GameSession(c);legal=s.legal_actions();a=next(a for a in legal if (a.to_square.file,a.to_square.rank)==((1,1)if name=='stalemate'else(3,0)));s.submit(a);nr=nc.compile_native_semantic_rules(c,backend_module=mod);pos=pack_semantic_search_position(c,nr,s);assert not s.legal_actions();assert s.result.status.value==name,(name,s.result);before=record_value(sem.snapshot(nr,pos))
 for hint in (0,2**64-1,1,256,16<<8):
  got,ok,original,original_ok,out,hits,misses=mod.reply_probe(nr.capsule,pos,hint,True);assert ok and original_ok and got==original==0 and hits==0 and misses==1
  assert record_value(sem.snapshot(nr,pos))==before
  rows.append(dict(root=name,hint=hint,available=got,hits=hits,misses=misses,core_terminal=record_value(s.result),root_restored=True))
(B/'probe-terminal-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,scope='Actual one-edge legal continuations ending checkmate/stalemate; no fabricated history, hints must fail checked validation and fall back to no legal action.')).encode());print('TERMINALS',len(rows))
