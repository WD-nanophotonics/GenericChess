from pathlib import Path
import sys,json,time,math
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/reply-witness-20261015';plan=json.loads((B/'price-equivariance-plan.json').read_text(encoding='utf-8'))
from scripts import full_q_refresh_comparison as p
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from scripts.research_record import record_value
from generic_chess.session.session import GameSession
rows=[];mismatches=[];start=time.perf_counter()
def renamed(x,m):
 if isinstance(x,str):return m.get(x,x)
 if isinstance(x,list):return [renamed(v,m)for v in x]
 if isinstance(x,dict):return {m.get(k,k):renamed(v,m)for k,v in x.items()}
 return x
for seed in plan['inputs']:
 assert time.perf_counter()-start<180
 original=json.loads((B/f'fresh-{seed}.json').read_text(encoding='utf-8'));assert original['complete'];rs=original['samples'][0]['ruleset'];base=None
 ids=[x['type_id']for x in rs['piece_types']]
 for arm,m in [('original_roundtrip',{}),('reverse_bijection_same_ID_set',dict(zip(ids,ids[::-1]))),('fresh_P00_IDs',{tid:f'P{i:02}'for i,tid in enumerate(ids)})]:
  changed=renamed(rs,m);rules=deserialize_ruleset(json.dumps(changed));roundtrip=json.loads(serialize_ruleset(rules));assert roundtrip==changed
  raw=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);session=GameSession(c);profile=p.build_ruleset_profile(c,p.EvaluationConfig());inv={v:k for k,v in m.items()};board={inv.get(t,t):v for t,v in profile.board_value_by_type.items()};hand={inv.get(t,t):v for t,v in profile.hand_value_by_base_type.items()};mapped=dict(board=board,hand=hand)
  assert all(math.isfinite(v)for x in mapped.values()for v in x.values())
  if base is None:base=mapped
  delta={kind:{tid:value-base[kind][tid]for tid,value in values.items()if abs(value-base[kind][tid])>1e-9}for kind,values in mapped.items()}
  if any(delta.values()):mismatches.append(dict(seed=seed,arm=arm,delta=delta))
  rows.append(dict(seed=seed,arm=arm,mapping=m,mapped_prices=mapped,delta=delta,ruleset=changed,initial_state=record_value(session.state),compile_ok=True))
(B/'price-equivariance-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,mismatches=mismatches,seconds=time.perf_counter()-start,scope='Generated input label-bijection/roundtrip check only; no full transition-graph equivalence proof or price-quality claim.')).encode());print('PRICE_EQUIVARIANCE',len(rows),mismatches,time.perf_counter()-start)
