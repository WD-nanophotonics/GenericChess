from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
B=R/'.local_agent/reply-witness-20261015';mods={}
for name in('baseline','fault'):
 spec=importlib.util.spec_from_file_location('failure'+name+'._native_core',next(B.glob(name+'*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
rows=[];start=time.perf_counter()
for seed in(4021,4043):
 x=json.loads((b/f'input-{seed}.json').read_text(encoding='utf-8'))['samples'][0];c,s=case(x);nr={a:nc.compile_native_semantic_rules(c,backend_module=m)for a,m in mods.items()};bv={t:0 if m.is_anchor else 100 for t,m in c.support.type_metadata.items()};before=record_value(s.to_record());lim=SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8)
 reference=SemanticSearchEngine(c,nr['baseline'],board_values=bv,hand_values=bv,tt_megabytes=0,ordering_cache_enabled=False).search(s,lim,root_window_pruning=True)
 for site in(1,2):
  for offset in(0,1,7):
   for tt in(0,1):
    assert time.perf_counter()-start<180
    e=SemanticSearchEngine(c,nr['fault'],board_values=bv,hand_values=bv,tt_megabytes=tt,ordering_cache_enabled=False);mods['fault'].fault_set(site,offset);r=e.search(s,lim,root_window_pruning=True);fired=mods['fault'].fault_fired();assert fired==1 and r.termination_reason=='internal_error',(seed,site,offset,tt,fired,r.termination_reason)
    assert before==record_value(s.to_record());validate(r,s,nr['fault']);mods['fault'].fault_set(0,0);recovery=e.search(s,lim,root_window_pruning=True);validate(recovery,s,nr['fault']);assert before==record_value(s.to_record());assert (recovery.completed_depth,recovery.score,recovery.action,recovery.principal_variation)==(reference.completed_depth,reference.score,reference.action,reference.principal_variation)
    rows.append(dict(seed=seed,site=site,offset=offset,tt=tt,injected_result=record_value(r),fired=fired,recovered_result=record_value(recovery),reference=record_value(reference),root_restored=True))
(B/'fault-results.json').write_bytes(json.dumps(dict(complete=True,fault_calls=len(rows),recovery_calls=len(rows),rows=rows,seconds=time.perf_counter()-start,scope='Private negative probe-result injection; retained search state and follow-up policy match, not independent Core enumeration or actual memory failure.')).encode());print('FAULT',len(rows),time.perf_counter()-start)
