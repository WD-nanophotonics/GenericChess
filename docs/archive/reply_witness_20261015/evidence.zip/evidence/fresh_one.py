from pathlib import Path
import sys,json,time,random,importlib.util
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];B=R/'.local_agent/reply-witness-20261015';seed=int(sys.argv[1]);n=int(sys.argv[2]);plan=json.loads((B/'fresh-plan.json').read_text(encoding='utf-8'));start=time.perf_counter();rows=[];samples=[];terminal_tail=None
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.ai.limits import SearchLimits
mods={}
for arm,prefix in [('baseline','baseline'),('final_candidate','witness')]:
 spec=importlib.util.spec_from_file_location(arm+'._native_core',next(B.glob(prefix+'*.pyd')));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mods[arm]=mod
import hashlib
bindings={arm:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()for arm,m in mods.items()}
def save(complete=False):
 (B/f'fresh-{seed}.json').write_bytes(json.dumps(dict(complete=complete,seed=seed,n=n,rows=rows,samples=samples,source_bindings=bindings,seconds=time.perf_counter()-start,expected_roots=2,expected_queries=32,terminal_tail=terminal_tail)).encode())
game=generate_game(GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));raw=p.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c);rng=random.Random(seed+7000);walk=[];assert time.perf_counter()-start<45,'45s preparation limit'
nrs={arm:nc.compile_native_semantic_rules(c,backend_module=m)for arm,m in mods.items()};profile=p.build_ruleset_profile(c,p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()}
for ply in range(9):
 if s.result.status.value!='ongoing':
  terminal_tail=dict(ply=ply,state=record_value(s.state),walk=walk.copy());break
 if ply in (0,8):
  legal=s.legal_actions();before=record_value(s.to_record());samples.append(dict(seed=seed,n=n,ply=ply,ruleset=json.loads(serialize_ruleset(game.ruleset)),walk=walk.copy(),state=record_value(s.state),board_values=bv,hand_values=hv,legal_count=len(legal),generation_report=record_value(game.generation_report)))
  for setting in plan['settings']:
   for order in range(setting['orders']):
    for arm in (list(mods) if order%2==0 else list(mods)[::-1]):
     p.rr.stopped();nr=nrs[arm];pos=pack_semantic_search_position(c,nr,s);t=time.perf_counter();r=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=setting['depth'],max_nodes=setting['nodes'],max_time_seconds=setting['seconds'],quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;assert r.action in legal
     state=s.state;np=pos;witnesses=list(s._search_witnesses)
     for a in r.principal_variation:
      np=sem.make_checked(nr,np,pack_semantic_action(nr,state.position,a));state=apply_action(state,a,c);witnesses.append(state.position);sn=sem.snapshot(nr,np);ex=expected_snapshot(state.position,nr,c)
      for key in ('board','hands','aux_state','side'):assert record_value(sn[key])==record_value(ex[key])
      assert sn['history_exact'] and sn['history_events_exact'] and sn['ply']==state.ply_count
      assert [''.join(f'{v:016x}'for v in h)for h in sn['history']]==[str(position_identity_key(w,c))for w in witnesses]
      assert sn['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
     assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner);child=apply_action(s.state,r.action,c);assert record_value(s.to_record())==before;rows.append(dict(ply=ply,setting=setting['name'],order=order,arm=arm,caller_seconds=wall,result=record_value(r),selected_child_terminal=record_value(child.terminal_status),full_history_checked=True));save();print(seed,ply,setting['name'],order,arm,r.completed_depth,r.result_ordinary_qdepth,round(wall,3),flush=True)
 if ply==8:break
 acts=s.legal_actions()
 if not acts:break
 a=rng.choice(sorted(acts,key=repr));s.submit(a);walk.append(record_value(a))
save(True)
