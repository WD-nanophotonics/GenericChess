from pathlib import Path
import sys,subprocess,time,json
R=Path.cwd();B=R/'.local_agent/reply-witness-20261015';start=time.perf_counter();rows=[]
for order in(0,1):
 for arm in(['control','profile']if order==0 else['profile','control']):
  assert time.perf_counter()-start<45
  r=subprocess.run([sys.executable,str(B/'admission_one.py'),arm,str(order)],capture_output=True,timeout=min(15,45-(time.perf_counter()-start)));(B/f'admission-{order}-{arm}.log').write_bytes(r.stdout+r.stderr);rows.append(dict(order=order,arm=arm,exit=r.returncode));assert r.returncode==0,r.stderr.decode(errors='replace');print(r.stdout.decode(),end='')
(B/'admission-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start)).encode())
