from pathlib import Path
import subprocess,sys,json,time
R=Path.cwd();B=R/'.local_agent/reply-witness-20261015';plan=json.loads((B/'wide-plan.json').read_text(encoding='utf-8'));start=time.perf_counter();rows=[]
for seed in plan['families']:
 f=dict(seed=seed)
 if time.perf_counter()-start>plan['whole_batch_fuse_seconds']:break
 with (B/f"wide-{f['seed']}.log").open('wb')as out:
  try:r=subprocess.run([sys.executable,str(B/'wide_one.py'),str(f['seed'])],stdout=out,stderr=subprocess.STDOUT,timeout=min(plan['per_family_fuse_seconds'],plan['whole_batch_fuse_seconds']-(time.perf_counter()-start)));code=r.returncode
  except subprocess.TimeoutExpired:code='original_fuse_timeout'
 rows.append(dict(**f,exit=code));(B/'wide-results.json').write_bytes(json.dumps(dict(complete=False,families=rows,seconds=time.perf_counter()-start)).encode());print(f,code,round(time.perf_counter()-start,2),flush=True)
(B/'wide-results.json').write_bytes(json.dumps(dict(complete=True,families=rows,seconds=time.perf_counter()-start,planned_families=len(plan['families']))).encode())
