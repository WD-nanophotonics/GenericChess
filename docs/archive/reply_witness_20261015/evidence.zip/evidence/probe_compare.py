from pathlib import Path
exec(compile(Path('.local_agent/pv-contract-20261015/common.py').read_text(encoding='utf-8-sig'),'common.py','exec'))
B=R/'.local_agent/reply-witness-20261015';spec=importlib.util.spec_from_file_location('forcedhint._native_core',next(B.glob('probe*.pyd')));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
samples=json.loads((prior/'v2-boundary-inputs.json').read_text(encoding='utf-8'));rows=[];unsupported=[];previous=0;start=time.perf_counter()
from test_native_q_history_deferral import cycle
from test_native_pending_continuation import session_after
cases=[]
for x in samples:
 c,s=case(x)
 if c.board_size>16:unsupported.append(x['name']);continue
 cases.append((x['name'],c,s))
for name,s in [('quiet_forced_max',cycle(max_ply=2)),('repeated_prefix',cycle(prefix=10)),('long_history',cycle(max_ply=1024,repetition=10000,prefix=512)),('pending',session_after(('e2e4','d7d5','f1b5','c7c6')))]:cases.append((name,s.compiled,s))
for name,c,s in cases:
 assert time.perf_counter()-start<180
 nr=nc.compile_native_semantic_rules(c,backend_module=mod);pos=pack_semantic_search_position(c,nr,s);before=record_value(sem.snapshot(nr,pos));legal=sem.transient_legal_actions(nr,pos)
 tests=[('no_hint',0,False),('zero',0,True),('invalid64',2**64-1,True),('preceding_root',previous,True)]+[('legal_'+str(i),a,True)for i,a in enumerate(legal[:5])]
 for label,hint,have in tests:
  got,ok,original,original_ok,out,hits,misses=mod.reply_probe(nr.capsule,pos,hint,have)
  assert ok and original_ok and got==original,(name,label,got,original)
  assert record_value(sem.snapshot(nr,pos))==before
  if label.startswith('legal_'):assert got and hits==1 and misses==0
  rows.append(dict(root=name,n=c.board_size,label=label,hint=hint,available=got,original=original,returned_hint=out,hits=hits,misses=misses,root_restored=True))
 if legal:previous=legal[0]
(B/'probe-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,unsupported=unsupported,roots=len(cases),seconds=time.perf_counter()-start,scope='Direct original availability comparison shares checked predicate/enumeration, does not independently establish all-domain legality. Full-state fixture search replay is separate.')).encode());print('PROBE',len(cases),len(rows),unsupported,time.perf_counter()-start)
