from pathlib import Path
import sys,importlib.util,time,json
R=Path.cwd();sys.path.insert(0,str(R));b=R/'.local_agent/reply-witness-20261015';spec=importlib.util.spec_from_file_location('privatehintclean._native_core',next(b.glob('factor_hint_clean*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
import generic_chess.native as n
n._MODULE=m
import pytest
start=time.perf_counter();code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(b/'pytest-hint-full')]);(b/'hint-full.json').write_bytes(json.dumps(dict(exit=code,seconds=time.perf_counter()-start,private_backend=str(m.__file__),scope='Full default active suite with private currentV1 counter-free reply hint candidate, no product image replaced')).encode());raise SystemExit(code)
