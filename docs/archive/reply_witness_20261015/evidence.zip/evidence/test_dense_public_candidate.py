from pathlib import Path
import sys,importlib.util,pytest
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];B=R/'.local_agent/reply-witness-20261015'
import generic_chess.native as n
spec=importlib.util.spec_from_file_location('densetest._native_core',next(B.glob('dense*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);n._MODULE=m
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(B/'pytest-dense-boundary'),str(B/'test_native_geometry_first_source.py')]))
