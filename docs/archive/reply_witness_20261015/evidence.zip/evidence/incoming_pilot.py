from pathlib import Path
import sys,json,time,statistics,math
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/reply-witness-20261015'
from scripts import full_q_refresh_comparison as p
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.ir import _incoming_attack_sources

def candidate(incoming):
 if incoming is None:return None
 result={}
 for key,rows in incoming.items():
  groups={}
  for rank,row in enumerate(rows):
   source=row[2];tid=row[1];typed=groups.get(source)
   if typed is None:typed={};groups[source]=typed
   bucket=typed.get(tid)
   if bucket is None:bucket=[];typed[tid]=bucket
   bucket.append((rank,row))
  result[key]={source:{tid:tuple(entries)for tid,entries in typed.items()}for source,typed in groups.items()}
 return result

assert candidate(None)is None;rows=[];checks=[];start=time.perf_counter()
for seed in(4301,4311,4321,4331):
 assert time.perf_counter()-start<180
 x=json.loads((B/'cold_inputs'/f'{seed}.json').read_text(encoding='utf-8'));c=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));incoming=c._incoming_attack_paths
 a=_incoming_attack_sources(incoming);z=candidate(incoming);assert a==z and list(a)==list(z)
 count=0
 for key in a:
  assert list(a[key])==list(z[key])
  for source in a[key]:
   assert list(a[key][source])==list(z[key][source])
   for tid,entries in a[key][source].items():
    for (rank,row),(other_rank,other_row)in zip(entries,z[key][source][tid]):assert rank==other_rank and row is other_row;count+=1
 checks.append(dict(seed=seed,rows=count,ordered_and_identity_equal=True))
 for order in(0,1):
  for repeat in range(3):
   for label,fn in([('original',_incoming_attack_sources),('candidate',candidate)]if order==0 else[('candidate',candidate),('original',_incoming_attack_sources)]):
    t=time.perf_counter();out=fn(incoming);wall=time.perf_counter()-t;assert out==a;rows.append(dict(seed=seed,n=x['n'],order=order,repeat=repeat,arm=label,seconds=wall))
out=dict(complete=True,calls=len(rows),checks=checks,rows=rows,seconds=time.perf_counter()-start,scope='Private grouping feasibility, same exact actual incoming rows/order/ranks/object identities. Input compilation excluded; no product adoption or end-to-end speed claim.');(B/'incoming-pilot-results.json').write_bytes(json.dumps(out,indent=2).encode());print('INCOMING',len(rows),checks)
for n in(4,8,12,16):
 rs=[r for r in rows if r['n']==n];ratios=[]
 for order in(0,1):
  for repeat in range(3):
   pp={r['arm']:r for r in rs if r['order']==order and r['repeat']==repeat};ratios.append(pp['candidate']['seconds']/pp['original']['seconds'])
 print(n,math.exp(statistics.mean(map(math.log,ratios))))
