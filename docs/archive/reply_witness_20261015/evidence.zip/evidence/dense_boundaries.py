from pathlib import Path
import sys,importlib.util,json,copy,random,time
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];B=R/'.local_agent/reply-witness-20261015'
from test_native_q_history_deferral import cycle
from generic_chess.native.compiler import build_semantic_compile_payload
mods={}
for name in('lookup_base','lookup_dense'):
 spec=importlib.util.spec_from_file_location(name+'._native_core',next(B.glob(name+'*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
payload,_=build_semantic_compile_payload(cycle().compiled);rng=random.Random(20261015);sequences=[[],list(range(16)),[0,2,2,4],[0,0,1,2],[2,0,2,1],[5,5,5],[0,3,7,15],list(range(15,-1,-1))]
for i in range(100):
 a=[rng.randrange(16)for _ in range(rng.randrange(33))]
 if i%2==0:a.sort()
 sequences.append(a)
rows=[];start=time.perf_counter();counterexample=None
for ci,seq in enumerate(sequences):
 assert time.perf_counter()-start<180
 p=copy.deepcopy(payload);entries=[[source,[(index+3)%16]]for index,source in enumerate(seq)];p['geometries'][0]['paths'][0]=entries;rs={a:m.compile_semantic_rules(p)for a,m in mods.items()}
 for source in range(16):
  expected=next((tuple(v)for src,v in entries if src==source),None);got={a:m.path_lookup(rs[a],0,0,source)for a,m in mods.items()};assert got['lookup_base']==got['lookup_dense']==expected,(ci,source,got,expected)
  rows.append(dict(case=ci,source=source,entries=entries,expected=expected,actual=got))
  if ci==2 and source==2:counterexample=dict(entries=entries,source=source,first=expected,naive_index=entries[source][1],actual_guarded=got['lookup_dense'])
(B/'dense-boundary-results.json').write_bytes(json.dumps(dict(complete=True,sequences=len(sequences),queries=len(rows)*2,rows=rows,naive_duplicate_counterexample=counterexample,seconds=time.perf_counter()-start,scope='Shared parser and direct path accessor versus explicit Python first matching entry for accepted numeric payloads; no whole-domain execution claim.')).encode());print('LOOKUP',len(sequences),len(rows)*2,counterexample,time.perf_counter()-start)
