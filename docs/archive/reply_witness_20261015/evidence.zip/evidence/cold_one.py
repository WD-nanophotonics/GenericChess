from pathlib import Path
import time,sys,json,importlib.util,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/reply-witness-20261015';seed=int(sys.argv[1]);arm=sys.argv[2];order=int(sys.argv[3]);start=time.perf_counter();phases={}
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.ai.limits import SearchLimits
phases['imports']=time.perf_counter()-start
prefix='factor_baseline'if arm=='baseline'else'final_both';spec=importlib.util.spec_from_file_location('cold'+arm+'._native_core',next(B.glob(prefix+'*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
t=time.perf_counter();x=json.loads((B/'cold_inputs'/f'{seed}.json').read_text(encoding='utf-8'));rules=deserialize_ruleset(json.dumps(x['ruleset']));phases['deserialize']=time.perf_counter()-t
t=time.perf_counter();raw=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);phases['python_compile']=time.perf_counter()-t
t=time.perf_counter();s=GameSession(c);assert record_value(s.state)==x['state'];phases['initial_session']=time.perf_counter()-t
t=time.perf_counter();profile=p.build_ruleset_profile(c,p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};phases['rule_price']=time.perf_counter()-t
t=time.perf_counter();nr=nc.compile_native_semantic_rules(c,backend_module=m);phases['native_compile']=time.perf_counter()-t
t=time.perf_counter();engine=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);phases['engine']=time.perf_counter()-t
before=record_value(s.to_record());rows=[];diagnostic=0
for repeat in range(4):
 p.rr.stopped();t=time.perf_counter();res=engine.search(s,SearchLimits(max_depth=3,max_nodes=1024,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;t=time.perf_counter();state=s.state;pos=pack_semantic_search_position(c,nr,s);w=list(s._search_witnesses)
 for a in res.principal_variation:
  pos=sem.make_checked(nr,pos,pack_semantic_action(nr,state.position,a));state=apply_action(state,a,c);w.append(state.position);snap=sem.snapshot(nr,pos);expected=expected_snapshot(state.position,nr,c)
  for key in('board','hands','aux_state','side'):assert record_value(snap[key])==record_value(expected[key])
  assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(p,c))for p in w]
  assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert before==record_value(s.to_record());diagnostic+=time.perf_counter()-t;rows.append(dict(repeat=repeat,caller_seconds=wall,result=record_value(res),full_history=True))
(B/f'cold-{seed}-{order}-{arm}.json').write_bytes(json.dumps(dict(complete=True,seed=seed,n=x['n'],order=order,arm=arm,phases=phases,rows=rows,diagnostic_seconds=diagnostic,body_seconds=time.perf_counter()-start,provider_image_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256((B/'cold_inputs'/f'{seed}.json').read_bytes()).hexdigest())).encode())
