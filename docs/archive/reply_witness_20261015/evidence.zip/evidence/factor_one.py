from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];B=R/'.local_agent/reply-witness-20261015';P=R/'.local_agent/q-history-20261015';seed=int(sys.argv[1]);plan=json.loads((B/'factor-plan.json').read_text(encoding='utf-8'));start=time.perf_counter();rows=[]
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.ai.limits import SearchLimits
import hashlib
mods={}
for arm in plan['arms']:
 spec=importlib.util.spec_from_file_location('factor'+arm+'._native_core',next(B.glob('factor_'+arm+'*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
bindings={a:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()for a,m in mods.items()};original=json.loads((P/f'fresh-{seed}.json').read_text(encoding='utf-8'));assert original['complete'];inputs=original['samples'];n=inputs[0]['n']
def save(complete=False):
 (B/f'factor-{seed}.json').write_bytes(json.dumps(dict(complete=complete,seed=seed,n=n,rows=rows,source_bindings=bindings,seconds=time.perf_counter()-start,expected_roots=2,expected_queries=32,input_recipe='Prior q-history fresh-'+str(seed)+'.json samples with exact rules/walk/values; no generation')).encode())
for x in inputs:
 raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 for encoded in x['walk']:
  a,=[a for a in s.legal_actions()if record_value(a)==encoded];s.submit(a)
 assert record_value(s.state)==x['state'];before=record_value(s.to_record());bv=x['board_values'];hv=x['hand_values'];legal=s.legal_actions();nrs={a:nc.compile_native_semantic_rules(c,backend_module=m)for a,m in mods.items()}
 for setting in plan['settings']:
  for order in range(plan['orders']):
   for arm in(list(mods)if order==0 else list(mods)[::-1]):
    p.rr.stopped();nr=nrs[arm];pos=pack_semantic_search_position(c,nr,s);t=time.perf_counter();r=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=setting['depth'],max_nodes=setting['nodes'],max_time_seconds=setting['seconds'],quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t;assert r.action in legal
    state=s.state;np=pos;witnesses=list(s._search_witnesses)
    for a in r.principal_variation:
     np=sem.make_checked(nr,np,pack_semantic_action(nr,state.position,a));state=apply_action(state,a,c);witnesses.append(state.position);sn=sem.snapshot(nr,np);ex=expected_snapshot(state.position,nr,c)
     for key in('board','hands','aux_state','side'):assert record_value(sn[key])==record_value(ex[key])
     assert sn['history_exact']and sn['history_events_exact']and sn['ply']==state.ply_count
     assert [''.join(f'{v:016x}'for v in h)for h in sn['history']]==[str(position_identity_key(w,c))for w in witnesses]
     assert sn['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
    assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner);assert before==record_value(s.to_record());child=apply_action(s.state,r.action,c);rows.append(dict(seed=seed,n=n,ply=x['ply'],setting=setting['name'],order=order,arm=arm,caller_seconds=wall,result=record_value(r),full_history_checked=True,selected_child_terminal=record_value(child.terminal_status),root_restored=True));save();print(seed,x['ply'],setting['name'],order,arm,r.completed_depth,r.result_ordinary_qdepth,round(wall,3),flush=True)
save(True)
