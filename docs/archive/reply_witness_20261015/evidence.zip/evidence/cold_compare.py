from pathlib import Path
import sys,subprocess,json,time
R=Path.cwd();B=R/'.local_agent/reply-witness-20261015';plan=json.loads((B/'cold-plan.json').read_text(encoding='utf-8'));start=time.perf_counter();rows=[]
for seed in plan['seeds']:
 for order in range(2):
  for arm in(plan['arms']if order==0 else plan['arms'][::-1]):
   if time.perf_counter()-start>=180:break
   t=time.perf_counter()
   with(B/f'cold-{seed}-{order}-{arm}.log').open('wb')as out:
    try:r=subprocess.run([sys.executable,str(B/'cold_one.py'),str(seed),arm,str(order)],stdout=out,stderr=subprocess.STDOUT,timeout=min(60,180-(time.perf_counter()-start)));code=r.returncode
    except subprocess.TimeoutExpired:code='original_fuse_timeout'
   rows.append(dict(seed=seed,order=order,arm=arm,exit=code,process_seconds=time.perf_counter()-t));print(seed,order,arm,code,round(time.perf_counter()-t,3),flush=True)
(B/'cold-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,planned_processes=16)).encode())
