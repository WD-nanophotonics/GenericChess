from pathlib import Path
import sys,json,time,random,hashlib
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.declarations import available_declarations
from generic_chess.rules.serialization import serialize_ruleset
out=ROOT/'.local_agent/native-payload-20261014/default-caller';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does enabling existing optional Native Boolean inputs improve a prepared-rules public caller on fresh unfamiliar rules at1s using the actual defaultq4 policy, before another transport optimization?',seeds=list(range(2301,2306)),sizes=[4,8,12,16,18],roots=[0,8],arms=['defaultLegal','availability','all'],orders=['defaultLegal,availability,all','all,availability,defaultLegal'],max_calls=60,caller_seconds=1,limits='SearchLimits defaults except remaining wall time: ordinaryq4/hard8, no node cap, existing first-iteration refresh policy',goal_diagnostic='after chosen action: actual immediate root terminal win and existence of an immediate opponent terminal WIN reply/claim; false only after complete reply set; unknown if5000 transition/120s diagnostic cap. Not fullWDL/strength. Cost outside query separately.',decision='Actual eligibility/stop/provenance/retainedq/history and finite terminal witnesses can change advice on existing flags. No default/stop/UI changes, no result-driven extension or duplicate auxiliary games.',scope='Shared complete rule/profile construction outside per-query prepared caller; fresh player construction charged. All generated mechanics/history retained, including explicit18board Core fallback. Exposed development, no noise-free speed or universal quality claim.'))
roots=[];samples=[];setup=time.perf_counter()
for seed,size in zip(range(2301,2306),(4,8,12,16,18)):
 p.rr.stopped();cfg=p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True);g=p.generate_game(cfg);raw=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec);s=p.GameSession(c);rng=random.Random(seed+44000);walk=[]
 for ply in range(9):
  acts=tuple(s.legal_actions())
  if ply in (0,8):
   name=f'{seed}-ply{ply}';samples.append(dict(name=name,size=size,ruleset=json.loads(serialize_ruleset(g.ruleset)),walk=walk.copy(),state=record_value(s.state),witnesses=record_value(s._search_witnesses),included=bool(acts),legal_count=len(acts)))
   if acts:roots.append((name,c,SimpleNamespace(state=s.state,_search_witnesses=s._search_witnesses),ev,acts))
  if ply==8:break
  if not acts:samples.append(dict(seed=seed,missing_ply8=True,terminal_at=ply,resampled=False));break
  a=rng.choice(sorted(acts,key=repr));walk.append(record_value(a));s.submit(a)
write_record(out/'samples.json',dict(samples=samples,setup_seconds=time.perf_counter()-setup))
rows=[];goal_calls=0;goal_seconds=0
class GoalCap(Exception):pass
def goal(state,a,c):
 global goal_calls,goal_seconds
 t=time.perf_counter();owner=state.position.side_to_move;answer=dict(immediate_win=None,immediate_loss_reply=None)
 def poll():
  p.rr.stopped()
  if goal_calls>=5000 or goal_seconds+time.perf_counter()-t>=120:raise GoalCap()
 def step(st,act):
  global goal_calls
  poll();goal_calls+=1;return apply_action(st,act,c)
 try:
  child=step(state,a);answer['immediate_win']=child.terminal_status.is_terminal and child.terminal_status.winner==owner
  if child.terminal_status.is_terminal:answer['immediate_loss_reply']=child.terminal_status.winner not in (None,owner)
  else:
   claim=next((x for x in available_declarations(child,c) if x.outcome=='WIN'),None)
   if claim:answer.update(immediate_loss_reply=True,opponent_claim=record_value(claim))
   else:
    for reply in legal_actions(child,c,checkpoint=poll):
     terminal=step(child,reply).terminal_status
     if terminal.is_terminal and terminal.winner==1-owner:answer.update(immediate_loss_reply=True,opponent_reply=record_value(reply));break
    else:answer['immediate_loss_reply']=False
 except GoalCap:answer['censored']=True
 finally:goal_seconds+=time.perf_counter()-t
 return answer
for name,c,s,ev,acts in roots:
 before=s.state,s._search_witnesses
 for order in range(2):
  for arm in (('defaultLegal','availability','all') if order==0 else ('all','availability','defaultLegal')):
   p.rr.stopped();t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_availability=arm!='defaultLegal',use_native_semantic_check=arm=='all');prep=time.perf_counter()-t
   d=player.choose_action(s,SearchLimits(max_time_seconds=max(.001,1-prep)));wall=time.perf_counter()-t
   assert before==(s.state,s._search_witnesses) and d.runtime_depth_balanced and d.action in acts
   diagnostic=goal(s.state,d.action,c)
   rows.append(dict(root=name,order=order,arm=arm,provider_created=player.native_legality_provider is not None,prepare_seconds=prep,caller_seconds=wall,decision=record_value(d),finite_goal=diagnostic,history_unchanged=True))
   write_record(out/'rows.json',dict(complete=False,rows=rows,goal_transitions=goal_calls,goal_seconds=goal_seconds));print(name,order,arm,round(wall,3),d.completed_depth,d.result_source,d.result_ordinary_qdepth,diagnostic,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,goal_transitions=goal_calls,goal_seconds=goal_seconds))
