from pathlib import Path
import sys,json,hashlib,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts import reserve_refresh_diagnostic as rr
import importlib.util
binary=ROOT/'.local_agent/native-payload-20261014/candidate_native_core_v3.pyd'
spec=importlib.util.spec_from_file_location('generic_chess._native_core',binary);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
import generic_chess.native as native
native._MODULE=mod;sys.modules['generic_chess._native_core']=mod
out=ROOT/'.local_agent/native-payload-20261014/fresh-shadow';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Can a cheaper actual Core Boolean comparison falsify the Native check/availability interface on two fresh16board roots after the optional H5 proof was censored? This is not a repeated or extended H5 proof.',source='closed64 fixed transfer roots: positive2203-ply0 H5 is censored by optional240s Core proof; fresh2207-ply8 control',arms=['NativeLegal','NativeAllShadow'],nodes=2048,max_depth=12,q=2,hardq=8,seconds=60,planned_calls=4,decision='Every delivered Native boolean must match full Core position semantics and final non-timing result/work/history must match; any mismatch rejects transfer. Unsupported provider stays Core and is not claimed Native. Shadow cost is qualification, never benchmark gain.',scope='All reference calls use full Core in_check/has_legal_action with actual immutable position and cooperative checkpoint; no state/cache/ABI/default change.'))
samples=[x for x in json.loads((out.parent/'transfer/samples.json').read_text(encoding='utf-8'))['samples'] if x.get('name') in ('2203-ply0','2207-ply8')];rows=[]
for sample in samples:
 from scripts.full_q_refresh_comparison import compile_legacy_ruleset_for_semantic_execution,SearchMetadataAdapter
 raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(sample['ruleset'])));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 for recorded in sample['walk']:
  a,=[x for x in s.legal_actions() if record_value(x)==recorded];s.submit(a)
 assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
 before=s.state,s.to_record(),s._search_witnesses;engine=semantic_engine_for(c)
 class EqualMaterial:
  def __init__(self):self.v={tid:0 if t.is_anchor else 1000 for tid,t in c.support.type_metadata.items()}
  def type_value(self,tid):return self.v[tid]
  def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
  def evaluate(self,state):
   p=state.position
   return sum((1 if z.owner==p.side_to_move else -1)*self.v[z.current_type_id] for z in p.board if z)+sum((1 if owner==p.side_to_move else -1)*self.v[tid]*count for owner,hand in enumerate(p.hands) for tid,count in hand.counts)
 pair=[]
 for arm in ('NativeLegal','NativeAllShadow'):
  rr.stopped();p=AlphaBetaPlayer(c,evaluator_override=EqualMaterial(),use_disk_cache=False,use_native_semantic_legality=True,use_native_semantic_availability=arm=='NativeAllShadow',use_native_semantic_check=arm=='NativeAllShadow')
  counts=dict(check=0,availability=0,declines=0);digest=hashlib.sha256();provider=p.native_legality_provider
  if arm=='NativeAllShadow' and provider is not None:
   origcheck=p._check_provider;origavail=p._availability_provider
   def check(pos,side,checkpoint=None):
    actual=origcheck(pos,side,checkpoint=checkpoint);expected=engine.in_check(pos,side,checkpoint=checkpoint)
    assert actual==expected,(sample['name'],'check',record_value(pos),side,actual,expected)
    counts['check']+=1;digest.update(json.dumps([record_value(pos),side,actual,expected],sort_keys=True).encode());return actual
   def avail(pos,checkpoint=None):
    actual=origavail(pos,checkpoint=checkpoint);expected=engine.has_legal_action(pos,checkpoint=checkpoint)
    if actual is None:counts['declines']+=1
    else:assert actual==expected,(sample['name'],'availability',record_value(pos),actual,expected)
    counts['availability']+=1;digest.update(json.dumps([record_value(pos),actual,expected],sort_keys=True).encode());return actual
   p._check_provider=check;p._availability_provider=avail
  d=p.choose_action(s,SearchLimits(max_depth=12,max_nodes=2048,max_time_seconds=60,quiescence_max_depth=2,quiescence_hard_max_depth=8))
  assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
  if arm=='NativeAllShadow' and provider is not None:assert counts['check']>0 and counts['availability']>0
  pair.append(d);rows.append(dict(root=sample['name'],arm=arm,provider_created=provider is not None,decision=record_value(d),shadow_counts=counts,shadow_sha256=digest.hexdigest(),check_metrics=provider.check_metrics if provider else {},availability_metrics=provider.availability_metrics if provider else {},history_unchanged=True))
  write_record(out/'rows.json',dict(complete=False,rows=rows));print(sample['name'],arm,d.result_source,d.score,counts,flush=True)
 for field in ('action','score','principal_variation','completed_depth','nodes','qnodes','result_source','result_ordinary_qdepth','result_check_hard_qdepth','termination_reason','runtime_pushes','runtime_pops'):
  assert getattr(pair[0],field)==getattr(pair[1],field),(sample['name'],field)
write_record(out/'rows.json',dict(complete=True,rows=rows))

