from pathlib import Path
import sys,json,time,importlib.util,sysconfig,hashlib
from types import SimpleNamespace
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'.local_agent/geometry-prefix-20261014')]
from drop_fixture import make,p
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider as Provider
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/native-payload-20261014/module-prepared';assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Correct actual timing perimeter: former four-root costs timed choose_action only; now include prepared-rules player construction and choose_action. Full common rules/profile preparation is shared and outside this per-query caller; can a complete C-built Python payload remove the measured sparse-board Python loop while retaining exact old validation and caller semantics?',qualification='all eight frozen typed semantic roots, malformed owner/type/hand inputs and every actual payload in four512node NativeAll callers',cost_roots=['knownH3-16','2054-ply8','transformed_live_aux','compound_shift'],cost_nodes=8192,orders=2,arms=['Python','privateC'],seconds=30,max_depth=12,q=2,hardq=8,planned_calls=16,decision='Any field/error/history/work mismatch rejects candidate. Whole-call gain, not isolated builder speed, decides whether to consider product integration later. Private V2 only; running module-owned V1 transfer stays frozen. No deployment/default/UI or unsupported-domain claim.',scope='Mapping receiver used for unsupported EP roots; no Native query claimed there. C emits complete existing Python payload, then unchanged production pack_position/kernel validates and executes it. No state/result cache.'))
binary=ROOT/'.local_agent/native-payload-20261014/candidate_native_core_v2.pyd'
spec=importlib.util.spec_from_file_location('generic_chess._native_core',binary);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
import generic_chess.native as native
native._MODULE=mod;sys.modules['generic_chess._native_core']=mod
original=Provider._python_state_only_payload;count=[0]
KEYS=tuple(sys.intern(x) for x in ("owner","base_type_id","current_type_id","promoted","board","hands","counts","aux_state","side_to_move"))
candidate=Provider._state_only_payload
def shadow(self,pos,ply):
 expected=original(self,pos,ply);actual=candidate(self,pos,ply);assert actual==expected;count[0]+=1;return expected
samples=json.loads((ROOT/'.local_agent/root-transfer-20261014/semantic/samples.json').read_text(encoding='utf-8'))['rows'];roots=[];primitive=[]
for sample in samples:
 c=compile_ruleset_for_execution(deserialize_ruleset(json.dumps(sample['ruleset'])));s=GameSession(c)
 for a in deserialize_game_record(json.dumps(sample['game_record'])).actions:s.submit(a)
 receiver=SimpleNamespace(_payload_builder=mod.semantic_core_payload,type_ids=tuple(sorted(c.support.type_metadata)),type_map={tid:i for i,tid in enumerate(sorted(c.support.type_metadata))})
 for side in (0,1):
  for ply in (0,7,255):
   pos=replace(s.state.position,side_to_move=side);assert original(receiver,pos,ply)==candidate(receiver,pos,ply)
   primitive.append(dict(root=sample['name'],side=side,ply=ply,equal=True))
 if sample['name'] in ('transformed_live_aux','compound_shift'):
  class EqualMaterial:
   def __init__(self,c):self.v={tid:0 if t.is_anchor else 1000 for tid,t in c.support.type_metadata.items()}
   def type_value(self,tid):return self.v[tid]
   def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
   def evaluate(self,state):
    pos=state.position
    return sum((1 if z.owner==pos.side_to_move else -1)*self.v[z.current_type_id] for z in pos.board if z)+sum((1 if owner==pos.side_to_move else -1)*self.v[tid]*count for owner,hand in enumerate(pos.hands) for tid,count in hand.counts)
  roots.append((sample['name'],c,s,EqualMaterial(c)))
_,c,s=make(16);cfg=p.EvaluationConfig();roots.insert(0,('knownH3-16',c,s,p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg)))
sample=next(x for x in json.loads((ROOT/'.local_agent/root-transfer-20261014/generated/samples.json').read_text(encoding='utf-8'))['samples'] if x.get('name')=='2054-ply8')
r=deserialize_ruleset(json.dumps(sample['ruleset']));x=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=p.GameSession(c)
for a in sample['walk']:
 action,=[z for z in s.legal_actions() if record_value(z)==a];s.submit(action)
roots.insert(1,('2054-ply8',c,s,p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg)))
# Deliberate invalid data are mapping-only controls, never Native states.
name,c,s,ev=roots[0];receiver=SimpleNamespace(_payload_builder=mod.semantic_core_payload,type_ids=('K','R'),type_map={'K':0,'R':1});base=s.state.position
occupied=next(x for x in base.board if x is not None)
errors=[]
for defect in ('owner','base','current','hand_type','hand_negative'):
 piece=SimpleNamespace(owner=occupied.owner,base_type_id=occupied.base_type_id,current_type_id=occupied.current_type_id,promoted=occupied.promoted)
 board=list(base.board);hands=base.hands
 if defect=='owner':piece.owner=7
 elif defect=='base':piece.base_type_id='missing'
 elif defect=='current':piece.current_type_id='missing'
 elif defect=='hand_type':hands=(SimpleNamespace(counts=(('missing',1),)),base.hands[1])
 else:hands=(SimpleNamespace(counts=(('R',-1),)),base.hands[1])
 if defect in ('owner','base','current'):board[next(i for i,x in enumerate(board) if x is not None)]=piece
 pos=SimpleNamespace(board=tuple(board),hands=hands,side_to_move=base.side_to_move,aux_state=base.aux_state)
 observed=[]
 for fn in (original,candidate):
  try:fn(receiver,pos,0);raise AssertionError('expected invalid payload rejection')
  except ValueError as error:observed.append((type(error).__name__,str(error)))
 assert observed[0]==observed[1];errors.append(dict(defect=defect,error=observed[0]))
write_record(out/'primitive.json',dict(equal_inputs=primitive,errors=errors))
rows=[]
try:
 for name,c,s,ev in roots:
  before=s.state,s.to_record(),s._search_witnesses
  for order in range(2):
   pair=[]
   for arm in (('Python','privateC') if order==0 else ('privateC','Python')):
    p.rr.stopped();Provider._state_only_payload=original if arm=='Python' else candidate
    t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_native_semantic_check=True)
    prep=time.perf_counter()-t;d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=8192,max_time_seconds=30,quiescence_max_depth=2));wall=time.perf_counter()-t
    assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
    rows.append(dict(root=name,condition='cost',order=order,arm=arm,prepare_seconds=prep,wall_seconds=wall,decision=record_value(d),history_unchanged=True));pair.append(d)
    write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,order,arm,round(wall,3),d.completed_depth,d.termination_reason,flush=True)
   fields=('action','score','principal_variation','completed_depth','nodes','qnodes','termination_reason','result_source','result_ordinary_qdepth','runtime_pushes','runtime_pops')
   assert all(getattr(pair[0],f)==getattr(pair[1],f) for f in fields),(name,order)
 write_record(out/'rows.json',dict(complete=True,rows=rows))
finally:Provider._state_only_payload=original

