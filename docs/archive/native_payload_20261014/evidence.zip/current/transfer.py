from pathlib import Path
import sys,json,time,random,hashlib
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider as Provider
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.rules.serialization import serialize_ruleset
out=ROOT/'.local_agent/native-payload-20261014/transfer';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does module-owned complete C payload transfer to fresh movement mixtures with real played history, and does it retain useful results under equal caller time?',seeds=list(range(2201,2209)),sizes=[8,12,16,18,8,12,16,18],roots=[0,8],walk='Random(seed+33000), repr-sorted legal actions; no resampling',arms=['Python','moduleC'],orders=2,fixed=dict(nodes=8192,seconds=30),resource=dict(nodes=1000000,seconds=32),max_depth=12,q=2,hardq=8,max_calls=128,expected_single_run_seconds=3500,decision='Any complete payload/error/work/history discrepancy rejects integration; fixed-work cost and equal-time decision value are separate. Report unsupported18 Core explicitly. No result-driven extension or exclusive-machine speed claim; compilation/player preparation charged.',scope='Fresh exposed development generated legacy rules mechanically compiled to semantic IR; no generic-domain restriction or human-price tuning. Separate typed active-state qualification handles promotion/drop/aux/error/stop; ordinary concurrent load accepted.',sources={x:hashlib.sha256((ROOT/x).read_bytes()).hexdigest() for x in ['generic_chess/_native/native_payload.c','generic_chess/ai/alphabeta/native_legality.py','generic_chess/ai/alphabeta/search.py']}))
roots=[];samples=[];start=time.perf_counter()
for seed,size in zip(range(2201,2209),(8,12,16,18,8,12,16,18)):
 p.rr.stopped();cfg=p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True)
 g=p.generate_game(cfg);src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
 c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
 s=p.GameSession(c);rng=random.Random(seed+33000);walk=[]
 for ply in range(9):
  actions=tuple(s.legal_actions())
  if ply in (0,8):
   name=f'{seed}-ply{ply}'
   samples.append(dict(name=name,seed=seed,size=size,ply=ply,ruleset=json.loads(serialize_ruleset(g.ruleset)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk.copy(),legal_count=len(actions),included=bool(actions)))
   if actions:roots.append((name,c,s.state,s._search_witnesses,ev,actions))
  if ply==8:break
  if not actions:
   samples.append(dict(seed=seed,unavailable_ply8=True,terminal_at=ply,resampled=False));break
  action=rng.choice(sorted(actions,key=repr));walk.append(record_value(action));s.submit(action)
 print('prepared',seed,size,flush=True)
write_record(out/'samples.json',dict(samples=samples,setup_seconds=time.perf_counter()-start))
rows=[];original=Provider._state_only_payload;rt_entries=[];old_attach=p.SearchPathRuntime.attach_stats

def python(self,pos,ply):return self._python_state_only_payload(pos,ply)
def attach(rt,stats):
 r=old_attach(rt,stats);rt_entries.append((rt,p.runtime_state(rt)));return r
try:
 p.SearchPathRuntime.attach_stats=attach
 for condition in ('fixed','resource'):
  for name,c,state,witnesses,ev,actions in roots:
   for order in range(2):
    pair=[]
    for arm in (('Python','moduleC') if order==0 else ('moduleC','Python')):
     p.rr.stopped();assert time.perf_counter()-start<3550
     rt_entries.clear();Provider._state_only_payload=python if arm=='Python' else original
     t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_native_semantic_check=True);prep=time.perf_counter()-t
     seconds=30 if condition=='fixed' else max(.001,32-prep)
     session=SimpleNamespace(state=state,_search_witnesses=witnesses)
     d=player.choose_action(session,SearchLimits(max_depth=12,max_nodes=8192 if condition=='fixed' else 1000000,max_time_seconds=seconds,quiescence_max_depth=2,quiescence_hard_max_depth=8))
     wall=time.perf_counter()-t
     assert session.state is state and session._search_witnesses==witnesses and d.action in actions
     assert len(rt_entries)==1;rt,snapshot=rt_entries[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot
     child=state
     for action in d.principal_variation:
      assert action in legal_actions(child,c);child=apply_action(child,action,c)
     row=dict(root=name,condition=condition,order=order,arm=arm,provider_created=player.native_legality_provider is not None,prepare_seconds=prep,caller_seconds=wall,decision=record_value(d),history_unchanged=True,pv_legal=True)
     rows.append(row);pair.append(row);write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
     print(condition,name,order,arm,round(wall,3),d.completed_depth,d.result_source,d.score,flush=True)
    if condition=='fixed' and all(x['decision']['termination_reason']!='time_limit' for x in pair):
     fields=('action','score','principal_variation','completed_depth','nodes','qnodes','termination_reason','result_source','result_ordinary_qdepth','runtime_pushes','runtime_pops')
     assert all(pair[0]['decision'][f]==pair[1]['decision'][f] for f in fields),(name,order)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:Provider._state_only_payload=original;p.SearchPathRuntime.attach_stats=old_attach
