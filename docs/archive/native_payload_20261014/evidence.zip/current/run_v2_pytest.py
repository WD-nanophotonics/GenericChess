from pathlib import Path
import sys,importlib.util
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import generic_chess.native as native
binary=ROOT/'.local_agent/native-payload-20261014/candidate_native_core_v2.pyd'
spec=importlib.util.spec_from_file_location('generic_chess._native_core',binary)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
native._MODULE=mod;sys.modules['generic_chess._native_core']=mod
import pytest
raise SystemExit(pytest.main(sys.argv[1:]))
