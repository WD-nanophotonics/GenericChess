from pathlib import Path
import sys,json
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.declarations import available_declarations
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value,write_record
b=ROOT/'.local_agent/native-payload-20261014';source=json.loads((b/'positive-proof/rows.json').read_text(encoding='utf-8'));assert source['complete']
generated=json.loads((b/'transfer/samples.json').read_text(encoding='utf-8'))['samples'];semantic=[]
calls=0;nodes=0
def step(state,a,c):
 global calls;calls+=1;return apply_action(state,a,c)
def consume(state,h,proof,c,attacker):
 global nodes;nodes+=1
 if 'terminal' in proof:
  assert state.terminal_status.is_terminal and record_value(state.terminal_status)==proof['terminal'];return state.terminal_status.winner==attacker
 assert not state.terminal_status.is_terminal
 opts=available_declarations(state,c);side=state.position.side_to_move
 if 'declaration' in proof:
  assert proof['declaration'] in [record_value(x) for x in opts] and proof['declaration']['outcome']=='WIN';return side==attacker
 if 'defender_neutral' in proof:
  assert side!=attacker and proof['defender_neutral'] in [record_value(x) for x in opts] and proof['defender_neutral']['outcome'] in ('RESTART','NO_CONTEST');return False
 if 'frontier' in proof:assert h==0;return False
 assert h>0;actions=tuple(legal_actions(state,c));by={json.dumps(record_value(a),sort_keys=True):a for a in actions};assert len(by)==len(actions)
 if 'attacker_choice' in proof:assert side==attacker;edges=[proof['attacker_choice']];expected=True
 elif 'defender_counterexample' in proof:assert side!=attacker;edges=[proof['defender_counterexample']];expected=False
 elif 'all_defender_win' in proof:assert side!=attacker;edges=proof['all_defender_win'];expected=True;assert {json.dumps(x['action'],sort_keys=True) for x in edges}==set(by) and len(edges)==len(actions)
 else:assert side==attacker;edges=proof['all_attacker_fail'];expected=False;assert {json.dumps(x['action'],sort_keys=True) for x in edges}==set(by) and len(edges)==len(actions)
 values=[consume(step(state,by[json.dumps(x['action'],sort_keys=True)],c),h-1,x['proof'],c,attacker) for x in edges]
 assert all(v is expected for v in values);return expected
rows=[]
for row in source['rows']:
 if row['unknown']:rows.append(dict(root=row['root'],verified=False,unknown=True));continue
 sample=next(x for x in (generated if row['family']=='generated' else semantic) if x.get('name')==row['root'])
 rule=deserialize_ruleset(json.dumps(sample['ruleset']))
 if row['family']=='generated':
  raw=compile_legacy_ruleset_for_semantic_execution(rule);c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
  for recorded in sample['walk']:
   action,=[a for a in s.legal_actions() if record_value(a)==recorded];s.submit(action)
 else:
  c=compile_ruleset_for_execution(rule);s=GameSession(c)
  for action in deserialize_game_record(json.dumps(sample['game_record'])).actions:s.submit(action)
 assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
 action,=[a for a in s.legal_actions() if record_value(a)==row['action']]
 actual=consume(step(s.state,action,c),row['h']-1,row['proof'],c,s.state.position.side_to_move)
 assert actual is row['proved_within_h']
 rows.append(dict(family=row['family'],root=row['root'],h=row['h'],verified=True,proved_within_h=actual))
write_record(b/'positive-proof/independent-replay.json',dict(rows=rows,verified_nodes=nodes,actual_replay_transitions=calls,scope='Separate proof consumer rebuilds full roots/history, exact all-defense action coverage, terminal and zero-action declaration semantics. Does not use search scores, PV continuation or producing search routine as labels.'))
print('Independent Core certificate replay',len(rows),'cases',nodes,'nodes',calls,'transitions')

