from pathlib import Path
import sys,json,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution,compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.declarations import available_declarations
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value,write_record
from scripts import reserve_refresh_diagnostic as rr
b=ROOT/'.local_agent/native-payload-20261014';out=b/'positive-proof';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
generated=json.loads((b/'transfer/samples.json').read_text(encoding='utf-8'))['samples'];sem=[]
fixed=[r for r in json.loads((b/'transfer/rows.json').read_text(encoding='utf-8'))['rows'] if r['condition']=='fixed'];assert len(fixed)==64
selected={}
for row in fixed:
 d=row['decision']
 if d['score']>=900000000:
  key=(row['root'],json.dumps(d['action'],sort_keys=True),1000000000-d['score'])
  selected[key]=dict(family='generated',root=row['root'],action=d['action'],h=1000000000-d['score'])
write_record(out/'declaration.json',dict(question='Do distinct positive bounds from the closed64 fresh fixed calls have actual full-defense Core goal certificates?',cases=list(selected.values()),max_apply_per_case=50000,global_seconds=240,decision='Optional direct diagnosis of claimed positive utility: unknown remains unknown, no extension. No full-WDL admission gate or universal strength claim. Fixed stage only; no selection from unfinished resource outcomes.'))
class Cap(Exception):pass
start=time.perf_counter();calls=0;case_calls=0
def perform(state,a,c):
 global calls,case_calls
 rr.stopped()
 if case_calls>=50000 or time.perf_counter()-start>=240:raise Cap()
 calls+=1;case_calls+=1;return apply_action(state,a,c)
def prove(state,h,c,attacker):
 t=state.terminal_status
 if t.is_terminal:return t.winner==attacker,dict(terminal=record_value(t))
 opts=available_declarations(state,c);side=state.position.side_to_move
 win=next((x for x in opts if x.outcome=='WIN'),None)
 if win is not None:return side==attacker,dict(declaration=record_value(win))
 neutral=next((x for x in opts if x.outcome in ('RESTART','NO_CONTEST')),None)
 if side!=attacker and neutral is not None:return False,dict(defender_neutral=record_value(neutral))
 if h==0:return False,dict(frontier=True)
 acts=sorted(legal_actions(state,c),key=repr);assert acts;edges=[]
 for a in acts:
  val,sub=prove(perform(state,a,c),h-1,c,attacker);edge=dict(action=record_value(a),proof=sub)
  if side==attacker and val:return True,dict(attacker_choice=edge)
  if side!=attacker and not val:return False,dict(defender_counterexample=edge)
  edges.append(edge)
 return (False,dict(all_attacker_fail=edges)) if side==attacker else (True,dict(all_defender_win=edges))
rows=[]
for item in selected.values():
 case_calls=0
 if item['family']=='generated':
  sample=next(x for x in generated if x.get('name')==item['root']);r=deserialize_ruleset(json.dumps(sample['ruleset']));raw=compile_legacy_ruleset_for_semantic_execution(r);c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
  for a in sample['walk']:
   matches=[x for x in s.legal_actions() if record_value(x)==a];assert len(matches)==1;s.submit(matches[0])
 else:
  sample=next(x for x in sem if x['name']==item['root']);c=compile_ruleset_for_execution(deserialize_ruleset(json.dumps(sample['ruleset'])));s=GameSession(c)
  for a in deserialize_game_record(json.dumps(sample['game_record'])).actions:s.submit(a)
 assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
 action,=[a for a in s.legal_actions() if record_value(a)==item['action']]
 try:
  val,proof=prove(perform(s.state,action,c),item['h']-1,c,s.state.position.side_to_move)
  answer=dict(**item,proved_within_h=val,proof=proof,unknown=False,apply_calls=case_calls)
 except Cap:answer=dict(**item,proved_within_h=None,unknown=True,apply_calls=case_calls)
 rows.append(answer);write_record(out/'rows.json',dict(complete=False,rows=rows,apply_calls=calls,seconds=time.perf_counter()-start));print(item['family'],item['root'],item['h'],answer['proved_within_h'],case_calls,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,apply_calls=calls,seconds=time.perf_counter()-start))

