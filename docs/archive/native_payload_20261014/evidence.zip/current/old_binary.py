from pathlib import Path
import sys,importlib.util,sysconfig,json,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
import generic_chess.native as native
old=ROOT/'.local_agent/native-payload-20261014'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
spec=importlib.util.spec_from_file_location('generic_chess._native_core',old);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
assert not hasattr(mod,'semantic_core_payload');native._MODULE=mod
from test_completed_root_win import prepared,proves_root_h3
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
s=prepared();before=s.state,s.to_record(),s._search_witnesses
p=AlphaBetaPlayer(s.compiled,use_disk_cache=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_native_semantic_check=True)
assert p.native_legality_provider._payload_builder is None
d=p.choose_action(s,SearchLimits(max_depth=2,max_nodes=99,max_time_seconds=5,quiescence_max_depth=2))
assert d.result_source=='completed_root_win' and d.native_legality_calls>0 and proves_root_h3(s,d.action)
assert before==(s.state,s.to_record(),s._search_witnesses) and d.runtime_depth_balanced
write_record(ROOT/'.local_agent/native-payload-20261014/old-binary.json',dict(binary_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),payload_builder=None,actual_native=True,decision=record_value(d),history_unchanged=True,h3=True))
print('actual old binary uses Python transport; Native99 proof/history intact')
