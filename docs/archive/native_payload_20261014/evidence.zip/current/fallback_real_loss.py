from pathlib import Path
import sys,json,ast
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from test_completed_root_win import prepared,proves_root_h3
from test_no_contest_search import defender_root
from generic_chess.ai.alphabeta import search as sm,player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import record_value,write_record
b=ROOT/'.local_agent/native-payload-20261014';assert not(b/'fallback-real-loss.json').exists()
s=prepared();attack=AlphaBetaPlayer(s.compiled,use_disk_cache=False,use_native_semantic_legality=False).choose_action(s,SearchLimits(max_depth=2,max_nodes=99,quiescence_max_depth=2))
assert proves_root_h3(s,attack.action)
source=(b/'search-before-fallback.py').read_bytes();node=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef) and x.name=='run_root_search');scope={}
exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'<published-root-before-fallback>','exec'),sm.__dict__,scope)
new=pm.run_root_search;rows=[]
try:
 for arm in ('published_before','neutral_fallback'):
  session=defender_root();session.submit(attack.action)
  assert session.state.position.side_to_move==1 and not session.state.terminal_status.is_terminal
  before=session.state,session.to_record(),session._search_witnesses
  pm.run_root_search=scope['run_root_search'] if arm=='published_before' else new
  d=AlphaBetaPlayer(session.compiled,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(session,SearchLimits(max_depth=1,max_nodes=1,quiescence_max_depth=0))
  assert before==(session.state,session.to_record(),session._search_witnesses) and d.termination_reason=='node_limit' and d.completed_depth==0 and d.runtime_depth_balanced
  if arm=='published_before':
   assert d.choice_kind=='ACTION';session.submit(d.action)
   winning=next(a for a in session.legal_actions() if apply_action(session.state,a,session.compiled).terminal_status.winner==0)
   terminal=session.submit(winning).state.terminal_status if False else None
   # Submit is authoritative; inspect the resulting session rather than assuming its return shape.
   session.submit(winning);result=session.state.terminal_status
   assert result.is_terminal and result.winner==0
   witness=dict(defender_move=record_value(d.action),attacker_winning_reply=record_value(winning),terminal=record_value(result))
  else:
   assert d.choice_kind=='DECLARATION' and d.declaration.outcome=='NO_CONTEST'
   result=session.declare(d.declaration.declaration_id);assert result.winner is None and result.declaration_outcome=='NO_CONTEST'
   witness=dict(actual_declaration=record_value(result))
  rows.append(dict(arm=arm,decision=record_value(d),root_history_unchanged=True,actual_outcome=witness))
finally:pm.run_root_search=new
write_record(b/'fallback-real-loss.json',dict(search_calls=3,attack_decision=record_value(attack),rows=rows,scope='Known H3 attacker action creates a real checked defensive root with executable NO_CONTEST. Old node1 fallback has an actual opponent mate-in-one reply; fixed choice is actually declared neutral. This is a concrete avoidable loss path, not a guarantee that every old continuation loses or a global strength result.'))
print('3 searches: old node1 action permits an actual losing terminal; fixed node1 declaration executes NO_CONTEST')
