from pathlib import Path
import sys,json,time
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta.search import reference_minimax,terminal_score
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.declarations import available_declarations
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic import snapshot
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.ai.limits import SearchLimits
from test_no_contest_search import defender_root
out=ROOT/'.local_agent/native-payload-20261014/full-backend';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='After small input gains produced no32s choice change, can the existing full Native q0 engine consume unfamiliar rules/played full history/live transformation+aux and an actual neutral declaration without a new carrier?',cases=['2301-ply0','2302-ply8','transformed_live_aux','checked_NO_CONTEST'],reference='complete Core two-ply minimax, identical100 nonanchor/0anchor current-board and base-hand integer material; full declarations',native='existing SemanticSearchEngine,0MB TT,ordering_cache_enabledFalse,maxdepth2,q0/hard0,root_window_pruningTrue;5s kernelcap; callercost reported separately',decision='No pruning of task definition: explicit unsupported remains unsupported. FullD2 scores and chosen-action maxset/declaration must match; mismatch is an interface defect to diagnose. Reference is semantic oracle only: no AB vs unpruned timing speed claim or q0-vs-q4 quality claim.',max_reference_seconds=120,planned_native_queries=4,scope='Finite feasibility not new backend/default/UI; source90dd. Whole generated domain including unsupported/history remains target.'))
cases=[];samples=json.loads((out.parent/'default-caller/samples.json').read_text())['samples']
for name in ('2301-ply0','2302-ply8'):
 sample=next(x for x in samples if x.get('name')==name);r=deserialize_ruleset(json.dumps(sample['ruleset']));raw=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=p.GameSession(c)
 for recorded in sample['walk']:
  a,=[x for x in s.legal_actions() if record_value(x)==recorded];s.submit(a)
 assert record_value(s.state)==sample['state'];cases.append((name,c,s))
sample=next(x for x in json.loads((ROOT/'.local_agent/root-transfer-20261014/semantic/samples.json').read_text())['rows'] if x['name']=='transformed_live_aux');c=compile_ruleset_for_execution(deserialize_ruleset(json.dumps(sample['ruleset'])));s=p.GameSession(c)
for a in deserialize_game_record(json.dumps(sample['game_record'])).actions:s.submit(a)
assert record_value(s.state)==sample['state'];cases.append(('transformed_live_aux',c,s))
old=json.loads((out.parent/'fallback-real-loss.json').read_text());s=defender_root();a,=[x for x in s.legal_actions() if record_value(x)==old['attack_decision']['action']];s.submit(a);cases.append(('checked_NO_CONTEST',s.compiled,s))
rows=[]
class Cap(Exception):pass
for name,c,s in cases:
 before=s.state,s.to_record(),s._search_witnesses;start=time.perf_counter();counts=[0]
 class Material:
  def __init__(self):self.v={tid:0 if t.is_anchor else 100 for tid,t in c.support.type_metadata.items()}
  def evaluate(self,st):
   p.rr.stopped();counts[0]+=1
   if time.perf_counter()-start>120:raise Cap()
   pos=st.position
   return sum((1 if z.owner==pos.side_to_move else -1)*self.v[z.current_type_id] for z in pos.board if z)+sum((1 if owner==pos.side_to_move else -1)*self.v[tid]*count for owner,h in enumerate(pos.hands) for tid,count in h.counts)
 ev=Material();actions={}
 try:
  if s.state.terminal_status.is_terminal:ref=terminal_score(s.state.terminal_status,s.state.position.side_to_move,0)
  else:
   for a in legal_actions(s.state,c):actions[a]=-reference_minimax(apply_action(s.state,a,c),1,ev,c,1)[0]
   vals=list(actions.values());opts=available_declarations(s.state,c)
   if any(o.outcome=='WIN' for o in opts):vals.append(1000000000)
   if any(o.outcome in ('NO_CONTEST','RESTART') for o in opts):vals.append(0)
   ref=max(vals)
  reference=dict(score=ref,complete=True,leaf_evaluations=counts[0],seconds=time.perf_counter()-start,root_action_values=[dict(action=record_value(a),score=v) for a,v in actions.items()])
 except Cap:reference=dict(complete=False,leaf_evaluations=counts[0],seconds=time.perf_counter()-start)
 t=time.perf_counter()
 try:
  nr=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,nr,board_values=ev.v,hand_values=ev.v,tt_megabytes=0,ordering_cache_enabled=False)
  packed=snapshot(nr,pack_semantic_search_position(c,nr,s));assert packed['history_exact'] and packed['history_events_exact'] and len(packed['history'])==len(s.state.history)
  prep=time.perf_counter()-t;d=engine.search(s,SearchLimits(max_depth=2,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);wall=time.perf_counter()-t
  match=None
  if d.completed_depth==2 and reference['complete']:
   if d.declaration_id is not None:
    opt=next(x for x in available_declarations(s.state,c) if x.declaration_id==d.declaration_id);selected=1000000000 if opt.outcome=='WIN' else 0 if opt.outcome in ('RESTART','NO_CONTEST') else -1000000000
   else:selected=actions[d.action]
   match=d.score==reference['score']==selected
  row=dict(root=name,reference=reference,native=record_value(d),history_records=len(packed['history']),history_exact=True,events_exact=True,prepare_seconds=prep,caller_seconds=wall,matched_reference=match)
 except (NativeUnsupportedRuleError,ValueError) as error:row=dict(root=name,reference=reference,unsupported=str(error))
 assert before==(s.state,s.to_record(),s._search_witnesses);row['root_unchanged']=True;rows.append(row);write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,'match',row.get('matched_reference'),'unsupported',row.get('unsupported'),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))
