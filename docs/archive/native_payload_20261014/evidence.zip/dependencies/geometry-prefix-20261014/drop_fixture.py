from pathlib import Path
import sys
from dataclasses import replace
ROOT=Path.cwd()
for entry in (str(ROOT),str(ROOT/'tests')):
 if entry not in sys.path:sys.path.insert(0,entry)
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result
from scripts import full_q_refresh_comparison as p
def make(n,mirror=True):
 rows=[['.']*n for _ in range(n)]
 for x,y,char in (((3,0,'K'),(1,0,'k'),(3,2,'R')) if mirror else ((0,0,'K'),(2,0,'k'),(0,2,'R'))):rows[n-1-y][x]=char
 lines=[''.join(row) for row in rows]
 rules=make_ruleset(n,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1)),RayAtom((1,0)),RayAtom((-1,0)))],lines=lines)
 cc=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support)
 s=p.GameSession(c);pos=replace(s.state.position,hands=(Hands((('R',1),)),Hands()))
 key=position_identity_key(pos,c)
 st=replace(s.state,position=pos,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),))
 st=replace(st,terminal_status=terminal_result(st,c));s._state=st;s._search_history_witnesses=(pos,)
 assert not st.terminal_status.is_terminal and not getattr(c,'declarations',())
 return rules,c,s
