from pathlib import Path
import json,sys,sysconfig,shutil,subprocess,time,hashlib
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';S=P/'membership-source';S.mkdir(exist_ok=False)
plan=dict(question='Can immutable exact capture geometry membership repay cold construction and memory without semantic changes?',premise='Full512node measured wide dynamic attackshare.594 vsstatic.170;16.79Mtarget comparisons0matches. Directfeatureshare alone did notjustifywork.',index='Union of all capture-pattern geometry targets per currenttype/owner/source, using existing first-source lookup; negative membership only. Every matching target occurrence and path/state/slot guard still evaluated by original body if membership positive.',limits=dict(memory_bytes=2097152,construction_visits=2000000,allocation_failure='free partial index, original uncached runtime fallback'),expected_seconds=120,whole_seconds=300,decision='Private feasibility only; cold compile/free plus full fixednode equality/complete-rule controls. High cold cost or no fullcost gain rejects; promising exposedpilot only justifies frozen transfer.',no_games=True,no_training=True,no_aux_execution=True)
(P/'membership-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
p=S/'native_semantic_rules.h';s=p.read_text();s=s.replace('    uint8_t declaration_count;\n} GCSemanticRules;','    uint8_t declaration_count;\n    unsigned char *private_membership;\n    size_t private_membership_bytes;\n} GCSemanticRules;');assert'private_membership_bytes'in s;s=s.replace('/* Parse a Python payload','void gc_private_prepare_membership(GCSemanticRules *rules);\nextern unsigned long long gc_private_index_stats[6];\nextern int gc_private_index_failure;\n/* Parse a Python payload');p.write_bytes(s.encode())
p=S/'native_semantic_runtime.c';s=p.read_text();i=s.index('static int target_ok(');helper=r'''
unsigned long long gc_private_index_stats[6]={0}; /* built,free,bytes,visits, fallback,negative */
int gc_private_index_failure=0;
void gc_private_prepare_membership(GCSemanticRules *r){
 size_t cells=(size_t)r->board_size*r->board_size,stride=(cells+7)/8;
 size_t bytes=(size_t)r->type_count*2*cells*stride;
 gc_private_index_stats[2]=bytes;gc_private_index_stats[3]=0;
 if(!bytes||bytes>2097152||gc_private_index_failure){gc_private_index_stats[4]++;return;}
 unsigned char *bits=(unsigned char *)calloc(bytes,1);
 if(!bits){gc_private_index_stats[4]++;return;}
 size_t work=0;
 for(uint16_t type=0;type<r->type_count;type++)
 for(uint8_t owner=0;owner<2;owner++)
 for(uint16_t source=0;source<cells;source++)
 for(uint16_t ci=0;ci<r->capture_pattern_count[type];ci++){
  const GCSemPattern *p=&r->patterns[r->capture_pattern_indices[type][ci]];
  for(uint8_t gi=0;gi<p->geometry_count;gi++){
   if(++work>2000000)goto fallback;
   uint16_t gid=p->geometry_indices[gi];if(gid>=r->geometry_count)continue;
   const GCSemGeometry *g=&r->geometries[gid];
   if(g->kind==2||(g->has_atom_source&&g->atom_source_type!=type))continue;
   const GCSemPathEntry *entry=NULL;if(!path_entry(g,owner,source,&entry))continue;
   for(uint16_t ti=0;ti<entry->count;ti++){
    if(++work>2000000)goto fallback;
    uint16_t target=entry->squares[ti];if(target>=cells)continue;
    size_t key=(((size_t)type*2+owner)*cells+source)*stride+target/8;
    bits[key]|=(unsigned char)(1u<<(target%8));
   }
  }
 }
 r->private_membership=bits;r->private_membership_bytes=bytes;
 gc_private_index_stats[0]++;gc_private_index_stats[3]=work;return;
fallback:
 free(bits);gc_private_index_stats[3]=work;gc_private_index_stats[4]++;
}
'''
s=s[:i]+helper+s[i:];a=s.index('static int semantic_attacked_by(');b=s.index('static int semantic_action_delivers_check(',a);part=s[a:b];mark='        if (actor->current_type >= r->type_count) continue;';assert part.count(mark)==1
part=part.replace(mark,mark+r'''
        if(r->private_membership){
            size_t cells=(size_t)r->board_size*r->board_size,stride=(cells+7)/8;
            size_t key=(((size_t)actor->current_type*2+attacker)*cells+si)*stride+target_square/8;
            if(!(r->private_membership[key]&(1u<<(target_square%8)))){
                gc_private_index_stats[5]++;continue;
            }
        }''');s=s[:a]+part+s[b:];p.write_bytes(s.encode())
p=S/'native_semantic_rules.c';s=p.read_text();mark='    return rules;';assert s.count(mark)==1;s=s.replace(mark,'    gc_private_prepare_membership(rules);\n'+mark);mark='void gc_semantic_rules_free(GCSemanticRules *rules) {';i=s.index(mark)+len(mark);s=s[:i]+'''
    if(rules && rules->private_membership){free(rules->private_membership);rules->private_membership=NULL;gc_private_index_stats[1]++;}
'''+s[i:];p.write_bytes(s.encode())
p=S/'native_module.c';s=p.read_text();i=s.index('static PyMethodDef ');helper=r'''
static PyObject *gc_private_membership_info(PyObject *self,PyObject *args){
 (void)self;int failure;if(!PyArg_ParseTuple(args,"i",&failure))return NULL;
 if(failure>=0)gc_private_index_failure=failure;
 return Py_BuildValue("(KKKKKK)",gc_private_index_stats[0],gc_private_index_stats[1],gc_private_index_stats[2],gc_private_index_stats[3],gc_private_index_stats[4],gc_private_index_stats[5]);
}
''';s=s[:i]+helper+s[i:];mark='    {"semantic_dynamic_features", gc_semantic_dynamic_features, METH_VARARGS,';assert s.count(mark)==1;s=s.replace(mark,'    {"private_membership_info",gc_private_membership_info,METH_VARARGS,"private membership lifecycle"},\n'+mark);p.write_bytes(s.encode())
outp=P/'membership_native_core.pyd';cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(outp)]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);row=dict(returncode=r.returncode,seconds=time.perf_counter()-t,stderr=r.stderr.decode(errors='replace'),hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()});(P/'membership-build-private.json').write_bytes(json.dumps(row,indent=2).encode());print('BUILD',r.returncode,row['seconds'],row['stderr'],flush=True);assert r.returncode==0
