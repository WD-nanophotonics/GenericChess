from pathlib import Path
import json,sys,time,importlib.util,random,statistics
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
spec=importlib.util.spec_from_file_location('cold_cpu._native_core',P/'final_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=dict(question='Are very large wide cold-query adverse ratios measured algorithmCPU or unresolved wall variability?',changed_premise='Prior512coldquery panel retains12staticnode1median1.589/16dynamicnode1median1.573 andmaximumfamily4.699; warmfixedwork gains do not erase these.',cases=[62201,62202,62203,62204,62601,62602,62603,62604],profiles=['static','dynamic235'],nodes=1,repetitions=32,arms=['normal','final'],whole_seconds=120,expected_seconds=30,scope='Exposed diagnostic only. CPUtime of THIS process plus phasewall forcompile/query/free, balanced perpair. No quietwindow, otherprocessmonitor, baseline rerun replacement or CPU-as-caller claim. Keeporiginaladversepanel regardlessresult.')
(P/'cold-cpu-plan.json').write_bytes(json.dumps(plan,indent=2).encode());start=time.perf_counter();rows=[]
for seed in plan['cases']:
 d=json.loads((R/'.local_agent/api-ready-20261016/roots'/f'{seed}.json').read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()};before=record_value(s.state)
 for pi,profile in enumerate(plan['profiles']):
  for rep in range(plan['repetitions']):
   assert time.perf_counter()-start<plan['whole_seconds'];pair=[];arms=list(plan['arms']);random.Random(seed+pi*100+rep).shuffle(arms)
   for name in('rollout','advisor','slack'):
    z=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(z.get('user_paused')or z.get('stopped'))
   for arm in arms:
    t=time.perf_counter();cp=time.process_time_ns();nr=compile_native_semantic_rules(c,**({}if arm=='normal'else dict(backend_module=m)));compilewall=time.perf_counter()-t;compilecpu=time.process_time_ns()-cp;e=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,dynamic_values=(2,3,5)if profile=='dynamic235'else None,tt_megabytes=0,ordering_cache_enabled=False);q=time.perf_counter();cq=time.process_time_ns();r=e.search(s,SearchLimits(max_depth=8,max_nodes=1,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);querywall=time.perf_counter()-q;querycpu=time.process_time_ns()-cq;value=record_value(r);encoded=json.dumps(value);q=time.perf_counter();del e,nr;freewall=time.perf_counter()-q;wall=time.perf_counter()-t;cpu=time.process_time_ns()-cp;assert record_value(s.state)==before
    row=dict(seed=seed,board=d['board'],profile=profile,rep=rep,arm=arm,wall_seconds=wall,process_cpu_ns=cpu,compile_wall_seconds=compilewall,compile_cpu_ns=compilecpu,query_wall_seconds=querywall,query_cpu_ns=querycpu,free_wall_seconds=freewall,result=value);rows.append(row);pair.append(row)
   assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
 print('CPU_COLD',seed,len(rows),time.perf_counter()-start,flush=True)
summary=[]
for seed in plan['cases']:
 for profile in plan['profiles']:
  g={a:[r for r in rows if r['seed']==seed and r['profile']==profile and r['arm']==a]for a in plan['arms']}
  summary.append(dict(seed=seed,profile=profile,total_cpu_ns={a:sum(r['process_cpu_ns']for r in v)for a,v in g.items()},median_wall_seconds={a:statistics.median(r['wall_seconds']for r in v)for a,v in g.items()},median_compile_wall_seconds={a:statistics.median(r['compile_wall_seconds']for r in v)for a,v in g.items()},median_query_wall_seconds={a:statistics.median(r['query_wall_seconds']for r in v)for a,v in g.items()},family_wall_ratio=statistics.median(r['wall_seconds']for r in g['final'])/statistics.median(r['wall_seconds']for r in g['normal'])))
write_record(P/'cold-cpu-results.json',dict(complete=True,rows=rows,summary=summary,seconds=time.perf_counter()-start,process_clock_info=str(time.get_clock_info('process_time')),scope=plan['scope']));print('CPU_COLD_DONE',len(rows),json.dumps(summary),flush=True)
