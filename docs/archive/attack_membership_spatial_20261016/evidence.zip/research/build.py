from pathlib import Path
import json,sys,sysconfig,shutil,subprocess,time,hashlib
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016'
plan=dict(question='Are semantic attack scans a material fraction of complete static and dynamic search cost?',cases=[dict(seed=61401,board=4),dict(seed=62601,board=16)],arms=['normal','count','timed'],profiles=['static','dynamic235'],repetitions=4,depth=8,nodes=512,seconds=None,whole_seconds=240,expected_seconds=60,decision='Measure full API caller and native query time plus attack-only nested time; require all non-time result fields/root/history equal. Only specific leverage motivates membership prototype; no semantic skips or search strength inference.',scope='Already exposed roots; no new games/training/AUX execution. Full compiled rules/history remain. Count-only inner-loop overhead and two clock reads per attack are measured separately. Cold compile admission separately timed.')
(P/'plan.json').write_bytes(json.dumps(plan,indent=2).encode())
base={f.name:f.read_bytes()for f in(R/'generic_chess/_native').iterdir()if f.suffix in('.c','.h')}
build=[]
for arm in('count','timed'):
 S=P/(arm+'-source');S.mkdir(exist_ok=False)
 for name,data in base.items():(S/name).write_bytes(data)
 p=S/'native_semantic_runtime.c';s=p.read_text();a=s.index('static int semantic_attacked_by(');b=s.index('static int semantic_action_delivers_check(',a)
 part=s[a:b].replace('static int semantic_attacked_by(','static int private_semantic_attacked_by(',1)
 if arm=='count':
  changes=[('    for (uint16_t si=0; si<r->board_size*r->board_size; si++) {','    for (uint16_t si=0; si<r->board_size*r->board_size; si++) {private_scan[0]++;'),('        if (actor->current_type >= r->type_count) continue;','        if (actor->current_type >= r->type_count) continue;private_scan[1]++;'),('            uint16_t pi=r->capture_pattern_indices','            private_scan[2]++;uint16_t pi=r->capture_pattern_indices'),('                uint16_t gid=pattern->geometry_indices','                private_scan[3]++;uint16_t gid=pattern->geometry_indices'),('                for(uint16_t ti=0;ti<entry->count;ti++)if(entry->squares[ti]==target_square){','                private_scan[4]++;for(uint16_t ti=0;ti<entry->count;ti++){private_scan[5]++;if(entry->squares[ti]==target_square){private_scan[6]++;')]
  for old,new in changes:assert part.count(old)==1,old;part=part.replace(old,new)
  assert part.count('continue;return 1;}')==1;part=part.replace('continue;return 1;}','continue;return 1;}}')
 wrapper='''\nunsigned long long private_attack_calls=0,private_attack_ns=0,private_scan[7]={0};\n'''
 s='#include "native_clock.h"\n'+s[:a]+wrapper+part+'''
static int semantic_attacked_by(const GCSemanticRules *r,const GCSemanticPosition *p,uint16_t target,uint8_t attacker){
 private_attack_calls++;
 '''+('uint64_t t=gc_monotonic_ns();'if arm=='timed'else'')+'''
 int ok=private_semantic_attacked_by(r,p,target,attacker);
 '''+('private_attack_ns+=gc_monotonic_ns()-t;'if arm=='timed'else'')+'''
 return ok;
}
'''+s[b:];p.write_bytes(s.encode())
 p=S/'native_module.c';s=p.read_text();i=s.index('static PyMethodDef ')
 helper='''extern unsigned long long private_attack_calls,private_attack_ns,private_scan[7];
static PyObject *gc_private_attack_info(PyObject *self,PyObject *args){
 (void)self;int reset;if(!PyArg_ParseTuple(args,"p",&reset))return NULL;
 if(reset){private_attack_calls=private_attack_ns=0;memset(private_scan,0,sizeof(unsigned long long)*7);}
 return Py_BuildValue("{sK,sK,s(KKKKKKK)}","attack_calls",private_attack_calls,"attack_ns",private_attack_ns,"scan",private_scan[0],private_scan[1],private_scan[2],private_scan[3],private_scan[4],private_scan[5],private_scan[6]);
}
'''
 s=s[:i]+helper+s[i:];mark='    {"semantic_dynamic_features", gc_semantic_dynamic_features, METH_VARARGS,';assert s.count(mark)==1;s=s.replace(mark,'    {"private_attack_info",gc_private_attack_info,METH_VARARGS,"private fullquery census"},\n'+mark);p.write_bytes(s.encode())
 outp=P/(arm+'_native_core.pyd');cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(outp)]
 t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);row=dict(arm=arm,returncode=r.returncode,seconds=time.perf_counter()-t,stderr=r.stderr.decode(errors='replace'),hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()});build.append(row)
 (P/'build-private.json').write_bytes(json.dumps(build,indent=2).encode());print('BUILD',arm,r.returncode,row['seconds'],flush=True);assert r.returncode==0,row['stderr']
