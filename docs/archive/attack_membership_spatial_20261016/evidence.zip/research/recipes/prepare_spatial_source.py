from pathlib import Path
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';F=P/'spatial-followup'
test=(R/'tests/product/test_native_dynamic_feature_views.py').read_text()+r'''

@pytest.mark.parametrize("builder,position_for", S4_CASES)
@pytest.mark.parametrize("owner", (0, 1))
def test_spatial_counts_keep_aux_and_nested_reply_semantics(builder, position_for, owner):
    from generic_chess.learning.features import (
        localized_control_features, spatial_occupancy_features,
    )
    compiled = compile_semantic_ruleset(builder())
    position = replace(position_for(compiled.support), side_to_move=owner)
    rules = compile_native_semantic_rules(compiled)
    payload = dict(expected_snapshot(position, rules, compiled), ply=0)
    payload["board"] = [None if p is None else list(p) for p in payload["board"]]
    payload["hands"] = [list(h) for h in payload["hands"]]
    packed = native.pack_position(rules, payload)
    before = native.snapshot(rules, packed)
    occupancy = spatial_occupancy_features(position, rules.type_ids)
    expected = {
        "occupancy": tuple(value for side in (0, 1) for typ in rules.type_ids
                           for value in occupancy[f"{side}:{typ}"]),
        "localized_control": localized_control_features(position, compiled),
    }
    assert native.spatial_features(rules, packed) == expected
    assert native.snapshot(rules, packed) == before
'''
(F/'test_native_dynamic_feature_views.py').write_bytes(test.encode())
s=(P/'qualify_source_v2.py').read_text().replace("O=P/'source-qualification-v2'","O=P/'spatial-source-qualification'").replace("P/'delivery-source'","P/'spatial-followup/C_discardedidentity-source'").replace('source-build-v2-private.log','spatial-source-build-private.log').replace('source-full-tests-v2-private.log','spatial-source-tests-private.log').replace('source-qualification-v2-private.json','spatial-source-qualification-private.json')
s=s.replace("shutil.copyfile(P/'test_native_attack_membership.py',S/'tests/product/test_native_attack_membership.py')","shutil.copyfile(P/'test_native_attack_membership.py',S/'tests/product/test_native_attack_membership.py')\nshutil.copyfile(P/'spatial-followup/test_native_dynamic_feature_views.py',S/'tests/product/test_native_dynamic_feature_views.py')")
s=s.replace("'-m','pytest','-p','no:cacheprovider'","'-m','pytest','tests/development/test_native_dynamic_feature_error.py','tests/product/test_f56_generic_spatial_evaluator_v3.py','tests/product/test_native_dynamic_feature_views.py','tests/product/test_native_pending_continuation.py','tests/product/test_native_q_history_deferral.py','tests/product/test_native_attack_membership.py','tests/product/test_native_path_source_lookup.py','tests/product/test_native_capture_pattern_index.py','-p','no:cacheprovider'")
s=s.replace("307immutablebase plus complete currenttrackedPython/C/H/tools/activefixturedata and3newtests; first13collection errors retained as missingcopy dependencies, no test assertion relaxed.","Fresh307base plus currenttrackedPython/C/H/tools/activefixturedata; explicit8affectedtargets include existingnegativeS3 spatialfaults and12newpositiveaux/S4cases. Spatial Cprivate image, not fullsuite/productadoption.")
(P/'qualify_spatial_source.py').write_bytes(s.encode())
