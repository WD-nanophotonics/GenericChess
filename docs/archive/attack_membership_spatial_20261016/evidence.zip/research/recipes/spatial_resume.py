from pathlib import Path
import sys,json,time,importlib.util,statistics,random
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';F=P/'spatial-followup'
plan=json.loads((F/'plan.json').read_bytes());start=time.perf_counter();batch_start_utc=(F/'plan.json').stat().st_mtime
mods={'A_product':None}
for arm in plan['arms'][1:]:
 spec=importlib.util.spec_from_file_location(arm+'resume._native_core',F/(arm+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,GameSession
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.learning.features import spatial_occupancy_features,localized_control_features
rows=[]
for f in sorted((R/'.local_agent/api-ready-20261016/roots').glob('*.json')):
 d=json.loads(f.read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={a:compile_native_semantic_rules(c,**({}if m is None else dict(backend_module=m)))for a,m in mods.items()};packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};before={a:sem.snapshot(nr,packs[a])for a,nr in nrs.items()};timing={a:[]for a in mods};vectors={}
 for rep in range(1 if d['seed']==61401 else plan['repetitions']):
  assert time.time()-batch_start_utc<plan['whole_seconds']
  for name in('rollout','advisor','slack'):
   z=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(z.get('user_paused')or z.get('stopped'))
  arms=list(mods);random.Random(d['seed']+rep).shuffle(arms)
  for arm in arms:
   t=time.perf_counter();vectors[arm]=sem.spatial_features(nrs[arm],packs[arm]);timing[arm].append(time.perf_counter()-t)
 assert all(v==vectors['A_product']for v in vectors.values());assert before=={a:sem.snapshot(nr,packs[a])for a,nr in nrs.items()}
 occ=spatial_occupancy_features(s.state.position,nrs['A_product'].type_ids);want=dict(occupancy=tuple(value for owner in(0,1)for typ in nrs['A_product'].type_ids for value in occ[f'{owner}:{typ}']),localized_control=localized_control_features(s.state.position,c));assert record_value(want)==record_value(vectors['A_product'])
 row=dict(seed=d['seed'],board=d['board'],features=record_value(vectors['A_product']),timings=timing,ratios=None if d['seed']==61401 else {a:statistics.median(tt)/statistics.median(timing['A_product'])for a,tt in timing.items()},timing_status='FIRST256CALLTIMINGMISSING_4VECTORRECAPTUREONLY'if d['seed']==61401 else'RETAINED_FROZEN64REPS',full_root_restored=True,core_mechanical_features_equal=True);rows.append(row);write_record(F/'progress-resumed.json',dict(complete=False,rows=rows));print('SPATIAL',d['seed'],row['ratios'],flush=True)
write_record(F/'results.json',dict(complete=True,rows=rows,planned_feature_calls=4096,actual_feature_calls=4100,missing_first_harness_feature_call_timings=256,retained_feature_calls=3844,batch_wall_seconds=time.time()-batch_start_utc,seconds=time.perf_counter()-start,source_hashes={arm:{f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in(F/(arm+'-source')).iterdir()}for arm in plan['arms'][1:]},scope=plan['scope']));print('SPATIAL_DONE',len(rows),time.perf_counter()-start,flush=True)
