from pathlib import Path
import json,sys,time,importlib.util
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';F=P/'spatial-followup';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from scripts.research_record import record_value,write_record
from generic_chess.native import semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.features import spatial_occupancy_features,localized_control_features
from test_native_q_history_deferral import cycle
from test_native_pending_continuation import session_after
from phase19c1_native_semantic_fixtures import semantic_corpus
spec=importlib.util.spec_from_file_location('spatial_qual._native_core',F/'C_discardedidentity_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
start=time.perf_counter();corpus=dict(semantic_corpus());native={};rows=[];histories=[];transport=[]
def stopped():
 for name in('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(z.get('user_paused')or z.get('stopped'))
 assert time.perf_counter()-start<180
def values(c,s):
 nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','candidate')};np={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};before={a:sem.snapshot(nr,np[a])for a,nr in nrs.items()};vv={a:record_value(sem.spatial_features(nr,np[a]))for a,nr in nrs.items()};assert vv['normal']==vv['candidate'];assert before=={a:sem.snapshot(nr,np[a])for a,nr in nrs.items()};return vv,nrs
orig=json.loads((R/'.local_agent/eval-revisit-20261016/control-results.json').read_bytes())
for row in orig['mechanisms']:
 stopped();c=corpus[row['fixture']];s=GameSession.replay(c,deserialize_game_record(json.dumps(row['game_record'])));vv,nrs=values(c,s);types=nrs['normal'].type_ids;occ=spatial_occupancy_features(s.state.position,types);want=dict(occupancy=tuple(x for owner in(0,1)for typ in types for x in occ[f'{owner}:{typ}']),localized_control=localized_control_features(s.state.position,c));assert record_value(want)==vv['candidate'];rows.append(dict(fixture=row['fixture'],seed=row['seed'],ply=row['ply'],features=vv['candidate'],core_equal=True))
for prefix in(0,32,128,512,1023,1024):
 stopped();s=cycle(max_ply=1024,repetition=10000,prefix=prefix)
 if prefix<1024:vv,_=values(s.compiled,s);histories.append(dict(prefix=prefix,features=vv,complete_root_unchanged=True))
 else:
  errors={}
  for a in('normal','candidate'):
   nr=compile_native_semantic_rules(s.compiled,**({}if a=='normal'else dict(backend_module=m)));np=pack_semantic_search_position(s.compiled,nr,s)
   try:sem.spatial_features(nr,np)
   except NotImplementedError as exc:errors[a]=str(exc)
   else:raise AssertionError('fullcapacitymustrefuse')
  assert errors['normal']==errors['candidate'];histories.append(dict(prefix=prefix,errors=errors))
s=session_after(('e2e4','d7d5','f1b5','c7c6'));nrs={a:compile_native_semantic_rules(s.compiled,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','candidate')}
for row in orig['transport']:
 stopped();vv={a:record_value(sem.spatial_features(nr,sem.pack_position(nr,row['payload'])))for a,nr in nrs.items()};assert vv['normal']==vv['candidate'];transport.append(dict(label=row['label'],features=vv))
write_record(F/'controls.json',dict(complete=True,states=rows,histories=histories,transport=transport,seconds=time.perf_counter()-start,scope='280existingmechanismstates Coremechanicalspatial oracle andnormal/candidatefullparentcomparison;6actualhistoryprefix/capacity,3PENDINGactual/editedtransport controls. Editedeventtransport notsecondauthenticatedtrajectory; samecompressedbins notfullgenericrepresentation orWDL.'))
print('SPATIAL_CONTROLS',len(rows),time.perf_counter()-start,flush=True)
