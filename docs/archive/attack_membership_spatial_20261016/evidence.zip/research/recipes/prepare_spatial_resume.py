from pathlib import Path
import json
P=Path('.local_agent/attack-membership-20261016');s=(P/'spatial_followup.py').read_text();a=s.index('sys.path.insert(0,str(R))');s=s[a:];pre=r'''from pathlib import Path
import sys,json,time,importlib.util,statistics,random
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';F=P/'spatial-followup'
plan=json.loads((F/'plan.json').read_bytes());start=time.perf_counter();batch_start_utc=(F/'plan.json').stat().st_mtime
mods={'A_product':None}
for arm in plan['arms'][1:]:
 spec=importlib.util.spec_from_file_location(arm+'resume._native_core',F/(arm+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
'''
s=pre+s;s=s.replace("for rep in range(plan['repetitions']):","for rep in range(1 if d['seed']==61401 else plan['repetitions']):").replace("assert time.perf_counter()-start<plan['whole_seconds']","assert time.time()-batch_start_utc<plan['whole_seconds']")
old="want=dict(occupancy=spatial_occupancy_features(s.state.position,c),localized_control=localized_control_features(s.state.position,c));assert record_value(want)==record_value(vectors['A_product'])"
new="occ=spatial_occupancy_features(s.state.position,nrs['A_product'].type_ids);want=dict(occupancy=tuple(value for owner in(0,1)for typ in nrs['A_product'].type_ids for value in occ[f'{owner}:{typ}']),localized_control=localized_control_features(s.state.position,c));assert record_value(want)==record_value(vectors['A_product'])"
assert old in s;s=s.replace(old,new)
s=s.replace("ratios={a:statistics.median(tt)/statistics.median(timing['A_product'])for a,tt in timing.items()}","ratios=None if d['seed']==61401 else {a:statistics.median(tt)/statistics.median(timing['A_product'])for a,tt in timing.items()},timing_status='FIRST256CALLTIMINGMISSING_4VECTORRECAPTUREONLY'if d['seed']==61401 else'RETAINED_FROZEN64REPS'")
s=s.replace("print('SPATIAL',d['seed'],row['ratios'],flush=True)","write_record(F/'progress-resumed.json',dict(complete=False,rows=rows));print('SPATIAL',d['seed'],row['ratios'],flush=True)")
s=s.replace('feature_calls=16*64*4','planned_feature_calls=4096,actual_feature_calls=4100,missing_first_harness_feature_call_timings=256,retained_feature_calls=3844,batch_wall_seconds=time.time()-batch_start_utc')
(P/'spatial_resume.py').write_bytes(s.encode())
(F/'first-harness-failure.json').write_bytes(json.dumps(dict(error="TypeError: SearchMetadataAdapter object is not iterable",cause='Core spatial_occupancy_features expects type_ids and returns owner/type mapping, not compiledrules/flatvector. ExistingF56test confirms actualcontract.',actual_before_failure='First61401 executed64repetitions x4arms=256featurecalls and Nativeallvectors/root equality assertions. Fulltimingarrays notsaved before Corehelper error; they are missing, excluded. No searchqueries or productchanges.',resume='No timing rerun for firstroot; four directvalue recaptures only, remaining15roots original64reps, samebatch180s walllimit based originalplan mtime. Source/Pyd/plannedarms/caps unchanged.'),indent=2).encode())
