from pathlib import Path
import json,zipfile,shutil,subprocess,sys,sysconfig,time,hashlib,os
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';O=P/'spatial-source-qualification';O.mkdir(exist_ok=False);S=O/'source';start=time.perf_counter()
dep=R/'docs/archive/dynamic_input_cost_20261016/evidence.zip';assert hashlib.sha256(dep.read_bytes()).hexdigest()=='1180b5eea69f9ed8aaffc7461e79eb24f70d8704810132439cc77d6bc4824978'
with zipfile.ZipFile(dep)as z:
 for name in z.namelist():
  if name.startswith('source/'):
   f=O/name;assert f.resolve().is_relative_to(O.resolve());f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(z.read(name))
for f in(P/'spatial-followup/C_discardedidentity-source').iterdir():shutil.copyfile(f,S/'generic_chess/_native'/f.name)
# Current four active layers and shared fixtures are source qualification inputs.
files=subprocess.run(['git','ls-files','generic_chess','scripts','tools','tests','AGENTS.md','generic-chess-local.cmd'],capture_output=True,text=True,check=True).stdout.splitlines()
for name in files:
 f=Path(name)
 if f.parts[0]=='tests' and len(f.parts)>2 and f.parts[1]not in('product','development','workflow','specification'):continue
 if f.parts[0]in('generic_chess','scripts','tools')and f.suffix not in('.py','.c','.h','.cmd','.toml'):continue
 dest=S/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/f,dest)
for f in(P/'spatial-followup/C_discardedidentity-source').iterdir():shutil.copyfile(f,S/'generic_chess/_native'/f.name)
shutil.copyfile(P/'test_native_attack_membership.py',S/'tests/product/test_native_attack_membership.py')
shutil.copyfile(P/'spatial-followup/test_native_dynamic_feature_views.py',S/'tests/product/test_native_dynamic_feature_views.py')
shutil.copyfile(R/'pyproject.toml',S/'pyproject.toml')
src=S/'generic_chess/_native';module=S/'generic_chess'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(src.glob('*.c'))],'-o',str(module)]
r=subprocess.run(cmd,capture_output=True,timeout=180);(P/'spatial-source-build-private.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr[-2000:]
env=dict(os.environ,PYTEST_ADDOPTS='',PYTHONPATH=str(S))
r=subprocess.run([sys.executable,'-X','utf8','-m','pytest','tests/development/test_native_dynamic_feature_error.py','tests/product/test_f56_generic_spatial_evaluator_v3.py','tests/product/test_native_dynamic_feature_views.py','tests/product/test_native_pending_continuation.py','tests/product/test_native_q_history_deferral.py','tests/product/test_native_attack_membership.py','tests/product/test_native_path_source_lookup.py','tests/product/test_native_capture_pattern_index.py','-p','no:cacheprovider','--basetemp',str(O/'pytest-tmp')],cwd=S,capture_output=True,timeout=600,env=env);(P/'spatial-source-tests-private.log').write_bytes(r.stdout+r.stderr)
out=dict(complete=True,returncode=r.returncode,stdout=r.stdout.decode(errors='replace'),stderr=r.stderr.decode(errors='replace'),seconds=time.perf_counter()-start,dependency_sha256=hashlib.sha256(dep.read_bytes()).hexdigest(),all_source_hashes={str(f.relative_to(S)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in S.rglob('*')if f.is_file()and f.suffix in('.py','.c','.h','.toml')},scope='Fresh independent source directory,307immutablebase plus complete currenttrackedPython/C/H/tools/activefixturedata and3newtests; first13collection errors retained as missingcopy dependencies, no test assertions relaxed. Final delivery source includes only comment/unusedprivatefieldcleanup beyond clean measured candidate; no globalproduct adoption yet.')
(P/'spatial-source-qualification-private.json').write_bytes(json.dumps(out,indent=2).encode());print('SOURCE_FULL',r.returncode,round(out['seconds'],3),r.stdout.decode(errors='replace')[-2200:],flush=True);assert r.returncode==0
