from pathlib import Path
import sys,sysconfig,subprocess,time,shutil,json,hashlib,importlib.util,statistics,random
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';F=P/'spatial-followup';F.mkdir(exist_ok=False)
plan=dict(question='After geometric filtering, does existing spatial input still pay unused child identity or unused array capacity?',changed_premise='Currentindex reduces attack scanning; existingspatial9bin control still copies fullparentcapacity and builds fullchecked trialchild digest although only raw actiontarget is consumed. Actual cost not assumed from dynamicfeature findings.',inputs='16alreadyexposed fullrules/history roots, existingCore mechanicalfeatures only; no learner/prover/weights import.',arms=['A_product','B_livecopy','C_discardedidentity','D_both'],repetitions=64,whole_seconds=180,expected_seconds=45,decision='Directcomponentonly. Preserveall returnedoccupancy/control values and complete inputhistory/root. Positivegain can justify later realactiveprofilecost qualification; do not adopt, fit, claimNNquality orredefinefullgenericdomain from this compressed input.',scope='Existing APIs only, complete Nativeparent. Spatial9bin currenttype counts are not a sufficient fullgeneric state encoding; auxiliary/history alias concerns remain.')
(F/'plan.json').write_bytes(json.dumps(plan,indent=2).encode());mods={'A_product':None};start=time.perf_counter()
for arm in plan['arms'][1:]:
 S=F/(arm+'-source');S.mkdir()
 for f in(P/'final-source').iterdir():shutil.copyfile(f,S/f.name)
 p=S/'native_module.c';s=p.read_text();a=s.index('static int gc_semantic_spatial_feature_vector(');b=s.index('static PyObject *gc_semantic_spatial_features(',a);part=s[a:b]
 if arm in('B_livecopy','D_both'):
  assert part.count('        GCSemanticPosition view = *position;')==1;part=part.replace('        GCSemanticPosition view = *position;','        GCSemanticPosition view;\n        gc_semantic_runtime_copy_live_position(&view,position);')
 if arm in('C_discardedidentity','D_both'):
  assert part.count('gc_semantic_runtime_make_checked_status(&child, rules, &view, raw)')==1;part=part.replace('gc_semantic_runtime_make_checked_status(&child, rules, &view, raw)','gc_semantic_runtime_make_material_view_status(&child, rules, &view, raw)')
 s=s[:a]+part+s[b:];p.write_bytes(s.encode());outp=F/(arm+'_native_core.pyd');cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(outp)];r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr;spec=importlib.util.spec_from_file_location(arm+'spatial._native_core',outp);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,GameSession
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.learning.features import spatial_occupancy_features,localized_control_features
rows=[]
for f in sorted((R/'.local_agent/api-ready-20261016/roots').glob('*.json')):
 d=json.loads(f.read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={a:compile_native_semantic_rules(c,**({}if m is None else dict(backend_module=m)))for a,m in mods.items()};packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};before={a:sem.snapshot(nr,packs[a])for a,nr in nrs.items()};timing={a:[]for a in mods};vectors={}
 for rep in range(plan['repetitions']):
  assert time.perf_counter()-start<plan['whole_seconds']
  for name in('rollout','advisor','slack'):
   z=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(z.get('user_paused')or z.get('stopped'))
  arms=list(mods);random.Random(d['seed']+rep).shuffle(arms)
  for arm in arms:
   t=time.perf_counter();vectors[arm]=sem.spatial_features(nrs[arm],packs[arm]);timing[arm].append(time.perf_counter()-t)
 assert all(v==vectors['A_product']for v in vectors.values());assert before=={a:sem.snapshot(nr,packs[a])for a,nr in nrs.items()}
 want=dict(occupancy=spatial_occupancy_features(s.state.position,c),localized_control=localized_control_features(s.state.position,c));assert record_value(want)==record_value(vectors['A_product'])
 row=dict(seed=d['seed'],board=d['board'],features=record_value(vectors['A_product']),timings=timing,ratios={a:statistics.median(tt)/statistics.median(timing['A_product'])for a,tt in timing.items()},full_root_restored=True,core_mechanical_features_equal=True);rows.append(row);print('SPATIAL',d['seed'],row['ratios'],flush=True)
write_record(F/'results.json',dict(complete=True,rows=rows,feature_calls=16*64*4,seconds=time.perf_counter()-start,source_hashes={arm:{f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in(F/(arm+'-source')).iterdir()}for arm in plan['arms'][1:]},scope=plan['scope']));print('SPATIAL_DONE',len(rows),time.perf_counter()-start,flush=True)
