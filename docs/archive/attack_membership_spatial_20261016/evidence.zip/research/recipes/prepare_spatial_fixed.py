from pathlib import Path
import json
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';F=P/'spatial-followup'
plan=json.loads((P/'pilot-plan.json').read_bytes());plan.update(question='Do complete active-control-profile query results agree under exactly matched work when wall-censored wide D4 comparisons cannot?',arms=['normal','spatialC'],profiles=['control9'],repetitions=2,whole_seconds=180,expected_seconds=45,scope='16exposed oldroots full512node actualqueriesequality, activeuntrainedcontrol9 staticruleprices, qTT0. Notanotherprospectivepanel or strengthclaim; no time-limit-inducedwork mismatch.')
(F/'fixed-node-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
s=(P/'final_pilot.py').read_text().replace("P=R/'.local_agent/attack-membership-20261016'","P=R/'.local_agent/attack-membership-20261016/spatial-followup'").replace("'membership'","'spatialC'").replace("P/'final_native_core.pyd'","P/'C_discardedidentity_native_core.pyd'").replace('pilot-plan.json','fixed-node-plan.json').replace('final-pilot-queries.jsonl','fixed-node-queries.jsonl').replace('final-pilot-results.json','fixed-node-results.json')
s=s.replace("dynamic_values=(2,3,5)if profile=='dynamic235'else None,tt_megabytes=0","dynamic_values=None,localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0")
(F/'fixed_nodes.py').write_bytes(s.encode())
