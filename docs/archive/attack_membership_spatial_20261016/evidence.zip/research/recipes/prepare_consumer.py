from pathlib import Path
import shutil,json
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';B=P/'reader-inputs';B.mkdir(exist_ok=False)
for name in('old','transfer'):(B/(name+'-roots')).mkdir()
for f in(R/'.local_agent/api-ready-20261016/roots').glob('*.json'):shutil.copyfile(f,B/'old-roots'/f.name)
for f in(P/'transfer-roots').glob('*.json'):shutil.copyfile(f,B/'transfer-roots'/f.name)
files=['results.json','pilot-results.json','membership-control-results.json','transfer-results.json','final-pilot-results.json','final-control-results.json','cold-query-results.json','cold-cpu-results.json','core-results.json']
for name in files:shutil.copyfile(P/name,B/name)
shutil.copyfile(R/'.local_agent/eval-revisit-20261016/control-results.json',B/'control-results.json')
s=(R/'.local_agent/eval-revisit-20261016/consumer.py').read_text();s=s[:s.index("if scope in('historical','all'):")]
tail=r'''
for fn in ('results.json','pilot-results.json','transfer-results.json','final-pilot-results.json','cold-query-results.json','cold-cpu-results.json'):
 for row in read(fn)['rows']:
  if row.get('kind','ACTUAL_QUERY')!='ACTUAL_QUERY':counts[row['kind']]+=1;continue
  query('transfer'if fn=='transfer-results.json'else'old',row['seed'],row['result']);counts[fn]+=1
for fn in('membership-control-results.json','final-control-results.json'):
 for row in read(fn)['queries']:query('pending',0,row['result']);counts[fn]+=1
for row in read('core-results.json')['rows']:
 if row['kind']!='ACTUAL_PAIR':counts['core_'+row['kind']]+=1;continue
 for arm in('core','native'):query('transfer',row['seed'],row[arm]);counts['core_'+arm+'_query_receipts']+=1
corpus=dict(semantic_corpus());rules={};controls=read('control-results.json');origins={}
for row in controls['mechanisms']:
 name=row['fixture'];c=corpus[name]
 if name not in rules:rules[name]=compile_native_semantic_rules(c)
 nr=rules[name];s=GameSession.replay(c,deserialize_game_record(json.dumps(row['game_record'])));assert record_value(s.state)==row['state'];np=pack_semantic_search_position(c,nr,s);compare(s,nr,np);assert list(sem.dynamic_features(nr,np))==row['features'];counts['mechanism_feature_positions']+=1;origins[(name,row['seed'],row['ply'])]=s
for row in read('final-control-results.json')['checked_edges']:
 s=copy(origins[(row['fixture'],row['seed'],row['ply'])]);nr=rules[row['fixture']];np=pack_semantic_search_position(s.compiled,nr,s);ac=action(row['action']);assert ac in s.legal_actions();np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));s.submit(ac);assert record_value(s.state)==row['child'];compare(s,nr,np);counts['separately_recorded_legal_children']+=1
for row in read('final-control-results.json')['histories']:
 s=cycle(max_ply=1024,repetition=10000,prefix=row['prefix']);nr=compile_native_semantic_rules(s.compiled);np=pack_semantic_search_position(s.compiled,nr,s);compare(s,nr,np)
 if row['errors']:
  try:sem.dynamic_features(nr,np)
  except NotImplementedError as exc:assert 'history capacity'in str(exc)and'Core'in str(exc);counts['full_capacity_refusals']+=1
  else:raise AssertionError('capacity must refuse')
 else:assert list(sem.dynamic_features(nr,np))==row['features']['membership']
 counts['actual_history_prefixes']+=1
for row in read('transfer-results.json')['roots']:
 s,nr=root('transfer',row['seed']);compare(s,nr,pack_semantic_search_position(s.compiled,nr,s));counts['transfer_root_receipts']+=1
out=dict(complete=True,counts=dict(counts),seconds=time.perf_counter()-start,scope='SearchDISABLED normal source-bound Native/Core fullstate/history receipt reader. No raw query/clock/proof/fitness producers invoked. Originalconstructor transfer vs finalconstructor execution tiers retained. Corefinite receipts not recomputed objectives/WDL; no all-domain independenceclaim.')
(B/'consumer-result.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(out))
'''
s=s+tail;(P/'consumer.py').write_bytes(s.encode());shutil.copyfile(P/'consumer.py',B/'consumer.py')
