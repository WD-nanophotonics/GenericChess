from pathlib import Path
import shutil,sys,sysconfig,subprocess,time,json,hashlib
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';S=P/'bounded-source';S.mkdir(exist_ok=False)
for f in(P/'delivery-source').iterdir():shutil.copyfile(f,S/f.name)
p=S/'native_semantic_runtime.c';s=p.read_text();a=s.index('void gc_semantic_runtime_prepare_attack_membership(');b=s.index('static int target_ok(',a)
fn=r'''void gc_semantic_runtime_prepare_attack_membership(GCSemanticRules *r) {
    size_t cells = (size_t)r->board_size * r->board_size;
    size_t stride = (cells + 7) / 8;
    size_t bytes = (size_t)r->type_count * 2 * cells * stride;
    if (bytes == 0 || bytes > 2097152) return;
    unsigned char *bits = (unsigned char *)calloc(bytes, 1);
    if (bits == NULL) return;
    size_t work = 0;
    for (uint16_t type = 0; type < r->type_count; type++) {
        for (uint8_t owner = 0; owner < 2; owner++) {
            for (uint16_t ci = 0; ci < r->capture_pattern_count[type]; ci++) {
                const GCSemPattern *pattern =
                    &r->patterns[r->capture_pattern_indices[type][ci]];
                for (uint8_t gi = 0; gi < pattern->geometry_count; gi++) {
                    if (++work > 2000000) goto fallback;
                    uint16_t gid = pattern->geometry_indices[gi];
                    if (gid >= r->geometry_count) continue;
                    const GCSemGeometry *geo = &r->geometries[gid];
                    if (geo->kind == 2 ||
                        (geo->has_atom_source && geo->atom_source_type != type))
                        continue;
                    /* First array occurrence equals path_entry's direct,
                     * lower-bound AND unsorted-fallback contracts. Count the
                     * entry traversal itself, including ignored duplicates. */
                    unsigned char seen[GC_MAX_SQUARES] = {0};
                    const GCSemPathOwner *paths = &geo->paths[owner];
                    for (uint32_t ei = 0; ei < paths->count; ei++) {
                        if (++work > 2000000) goto fallback;
                        const GCSemPathEntry *entry = &paths->entries[ei];
                        uint16_t source = entry->source;
                        if (source >= cells || seen[source]) continue;
                        seen[source] = 1;
                        for (uint16_t ti = 0; ti < entry->count; ti++) {
                            if (++work > 2000000) goto fallback;
                            uint16_t target = entry->squares[ti];
                            if (target >= cells) continue;
                            size_t key = (((size_t)type * 2 + owner) * cells +
                                          source) * stride + target / 8;
                            bits[key] |= (unsigned char)(1u << (target % 8));
                        }
                    }
                }
            }
        }
    }
    r->attack_membership = bits;
    return;
fallback:
    free(bits);
}
'''
s=s[:a]+fn+s[b:];p.write_bytes(s.encode())
# Build private byte inspectors for BOTH construction versions; no public API.
for arm,src in(('old',P/'clean-source-v3'),('bounded',S)):
 D=P/(arm+'-inspect-source');D.mkdir(exist_ok=False)
 for f in src.iterdir():shutil.copyfile(f,D/f.name)
 p=D/'native_module.c';s=p.read_text();i=s.index('static PyMethodDef ');helper=r'''
static PyObject *gc_private_index_bytes(PyObject *self,PyObject *args){
 (void)self;PyObject *cap;if(!PyArg_ParseTuple(args,"O",&cap))return NULL;
 GCSemanticRules *r=(GCSemanticRules *)PyCapsule_GetPointer(cap,GC_SEM_RULES_CAPSULE);
 if(!r)return NULL;if(!r->attack_membership)Py_RETURN_NONE;
 size_t cells=(size_t)r->board_size*r->board_size;
 return PyBytes_FromStringAndSize((const char *)r->attack_membership,(Py_ssize_t)((size_t)r->type_count*2*cells*((cells+7)/8)));
}
'''
 s=s[:i]+helper+s[i:];mark='    {"semantic_dynamic_features", gc_semantic_dynamic_features, METH_VARARGS,';assert s.count(mark)==1;s=s.replace(mark,'    {"private_index_bytes",gc_private_index_bytes,METH_VARARGS,"private exactindex inspect"},\n'+mark);p.write_bytes(s.encode())
 outp=P/(arm+'_inspect_native_core.pyd');cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(D),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(D.glob('*.c'))],'-o',str(outp)];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);print('INSPECT_BUILD',arm,r.returncode,time.perf_counter()-t,r.stderr.decode(errors='replace'),flush=True);assert r.returncode==0
(P/'construction-bound-plan.json').write_bytes(json.dumps(dict(question='Does the original visit cap really bound unsorted first-source lookup work?',observed_source='Original constructor repeats path_entry across ALL sources; accepted unsorted payload does linear search, whose path-entry visits were not counted. Fulltests/vector equality cannot establish bounded admission cost.',action='Replace construction source loop with a single entry traversal/first-seen pergeometry. Count ignored duplicate entries and targets against same2Mcap; same negative lookup and dynamic guards.',experiment='1/2/4capturepatterns with65535unsorted source entries, bothowners, bounded directtimings only; no gigantic oldconstruction. Exactbyte containment independentPythonoracle over frozenactualrules and numericcases.',decision='Do not ship earlier constructor even if full transfer passes. Need newcoldcost, byteequality/containment and finalsource/fulltests. Originaltransfer version and cost remain frozen evidence, not retroactive revisedconstructor execution.'),indent=2).encode())
