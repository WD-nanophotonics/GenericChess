from pathlib import Path
import json,statistics
P=Path('.local_agent/attack-membership-20261016');d=json.loads((P/'cold-controls-results.json').read_bytes());p=json.loads((P/'pilot-results.json').read_bytes());rows=[]
for board in(4,8,12,16):
 cc=[z for z in d['cold']if z['board']==board]
 z=dict(board=board,index_bytes=sorted({a['index'][2]for a in cc}),construct_work=sorted(a['index'][3]for a in cc),capsule_construct_extra_seconds=statistics.median(statistics.median(a['capsule_construct_seconds']['membership'])-statistics.median(a['capsule_construct_seconds']['normal'])for a in cc),complete_compile_dispose_extra_seconds=statistics.median(statistics.median(a['complete_python_compile_dispose_seconds']['membership'])-statistics.median(a['complete_python_compile_dispose_seconds']['normal'])for a in cc))
 for profile in('static','dynamic235'):
  rr=[]
  for a in cc:
   q=next(x for x in p['summary']if x['seed']==a['seed']and x['profile']==profile)
   rr.append((q['caller_medians']['membership']+statistics.median(a['complete_python_compile_dispose_seconds']['membership']))/(q['caller_medians']['normal']+statistics.median(a['complete_python_compile_dispose_seconds']['normal'])))
  z[profile+'_cold_compile_plus512query_median_ratio']=statistics.median(rr)
 rows.append(z)
(P/'cold-analysis.json').write_bytes(json.dumps(dict(complete=True,rows=rows,scope='Sum separately balanced measured medians, NOT fresh whole pipeline timing; cold-admission model includes completePythoncompile/free plus pilotquery, no generation/replay.'),indent=2).encode());print(json.dumps(rows,indent=2))
