from pathlib import Path
import json,statistics,random,collections
P=Path('.local_agent/attack-membership-20261016');d=json.loads((P/'transfer-results.json').read_bytes());plan=json.loads((P/'transfer-plan.json').read_bytes());seen={(r['seed'],r['profile'],r['rep'],r['arm'])for r in d['rows']};reason={r['seed']:r['kind']for r in d['roots']}
missing=[dict(**c,profile=p,rep=k,arm=a,kind='NO_QUERY_RECEIPT',reason=reason.get(c['seed'],'MISSING_ROOT_UNKNOWN'))for c in plan['cases']for p in plan['profiles']for k in range(plan['repetitions'])for a in plan['arms']if(c['seed'],p,k,a)not in seen]
out=[]
def interval(v):
 if len(v)<2:return None
 rng=random.Random(20261016);q=sorted(statistics.median(rng.choices(v,k=len(v)))for _ in range(4000));return[q[99],q[3899]]
for board in(4,8,12,16):
 for profile in plan['profiles']:
  groups={}
  for row in d['rows']:
   if row['board']==board and row['profile']==profile:groups.setdefault((row['seed'],row['rep']),{})[row['arm']]=row
  patterns=collections.Counter();family={};costs=[];bad=[];depthdelta=collections.Counter()
  for key,g in groups.items():
   assert len(g)==2 and all(r['kind']=='ACTUAL_QUERY'for r in g.values()),g
   a=g['A_normal'];b=g['B_membership'];da=a['result']['completed_depth'];db=b['result']['completed_depth'];patterns[str((da==4,db==4))]+=1;depthdelta['higher'if db>da else'lower'if db<da else'same']+=1
   if da==db==4:
    aa={k:v for k,v in a['result'].items()if k!='elapsed_seconds'};bb={k:v for k,v in b['result'].items()if k!='elapsed_seconds'}
    if aa!=bb:bad.append(key)
    ratio=b['caller_seconds']/a['caller_seconds'];family.setdefault(key[0],[]).append(ratio);costs.append(ratio)
  vv=[statistics.median(v)for v in family.values()]
  out.append(dict(board=board,profile=profile,groups=len(groups),patterns=dict(patterns),joint_family_count=len(vv),family_ratios=vv,family_median_ratio=statistics.median(vv)if vv else None,descriptive_family_interval=interval(vv),maximum_joint_ratio=max(costs,default=None),all_non_time_mismatches=bad,completed_depth_delta=dict(depthdelta)))
acq=collections.Counter()
for f in(P/'transfer-roots').glob('*.json'):
 z=json.loads(f.read_bytes());acq['walks']+=1;acq['plies']+=len(z['game_record']['actions'])
 for a in z['game_record']['actions']:acq['drops']+=int(a['kind']=='semantic_drop');acq['promotions']+=int(a.get('promotion_target_id')is not None)
r=dict(complete=True,panels=out,planned_slots=256,actual_queries=len(d['rows']),explicit_missing_slots=missing,root_kinds=dict(collections.Counter(r['kind']for r in d['roots'])),actual_acquisition=dict(acq),whole_seconds=d['seconds'],scope='Original source-loop-constructor clean candidate; all timing evidence remains tied to that image. Revised bounded-constructor index bytes and runtime are separately qualified; do not label original batch revised source execution. Nonempty jointD4 comparisons conditional, descriptive families notstrength; cold construction outside innerAPI timing.')
(P/'transfer-analysis.json').write_bytes(json.dumps(r,indent=2).encode());print(json.dumps({k:v for k,v in r.items()if k!='explicit_missing_slots'},indent=2))
