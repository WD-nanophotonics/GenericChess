from pathlib import Path
from copy import deepcopy
import json,sys,sysconfig,importlib.util,time,statistics,gc
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';sys.path.insert(0,str(R))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native import _module
from generic_chess.native.compiler import build_semantic_compile_payload,compile_native_semantic_rules
from generic_chess.rules.serialization import deserialize_ruleset
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
from scripts.research_record import write_record
spec=importlib.util.spec_from_file_location('cold_membership._native_core',P/'membership_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mods={'normal':_module(),'membership':m}
start=time.perf_counter();rows=[];cold=[]
for f in sorted((R/'.local_agent/api-ready-20261016/roots').glob('*.json')):
 d=json.loads(f.read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);payload,_=build_semantic_compile_payload(c);tt={a:[]for a in mods};ff={a:[]for a in mods};whole={a:[]for a in mods};before=m.private_membership_info(-1)
 for rep in range(16):
  for arm in(('normal','membership')if rep%2==0 else('membership','normal')):
   t=time.perf_counter();capsule=mods[arm].compile_semantic_rules(payload);tt[arm].append(time.perf_counter()-t);t0=time.perf_counter();del capsule;ff[arm].append(time.perf_counter()-t0);whole[arm].append(time.perf_counter()-t)
 after=m.private_membership_info(-1);assert after[0]-before[0]==after[1]-before[1]==16
 full={a:[]for a in mods}
 for rep in range(8):
  for arm in(('normal','membership')if rep%2==0 else('membership','normal')):
   t=time.perf_counter();nr=compile_native_semantic_rules(c,backend_module=mods[arm]);del nr;full[arm].append(time.perf_counter()-t)
 cold.append(dict(seed=d['seed'],board=d['board'],capsule_construct_seconds=tt,dispose_seconds=ff,whole_capsule_lifecycle_seconds=whole,complete_python_compile_dispose_seconds=full,index=after,index_build_free_counts_delta=[after[0]-before[0],after[1]-before[1]]))
 print('COLD',d['seed'],after[2:5],round(statistics.median(whole['membership'])/statistics.median(whole['normal']),3),flush=True)
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));base,_=build_semantic_compile_payload(c)
pat=deepcopy(next(p for p in base['patterns']if p['target']==1 and p['type_indices']==[0]and not p['guards']and not p['slot_guards']))
for owner in(0,1):
 for case,entries,expected,minimum in[
 ('sorted',[[0,[9]],[27,[36]],[50,[59]]],{36},1),
 ('sorted_duplicate',[[0,[9]],[27,[36]],[27,[45]],[50,[59]]],{36},1),
 ('unsorted_duplicate',[[50,[59]],[27,[36]],[0,[9]],[27,[45]]],{36},1),
 ('missing',[[50,[59]],[0,[9]]],set(),1),
 ('empty',[],set(),1),
 ('second_target_occurrence',[[27,[36,36]]],{36},2)]:
  payload=deepcopy(base);p=deepcopy(pat);p['geometry_indices']=[0];payload['patterns']=[p];payload['geometries'][0]['paths']=[entries,entries];payload['geometries'][0]['min_steps']=minimum
  board=[None]*64;board[27]=[0,0,owner,0];state=dict(board=board,hands=[[0]*6,[0]*6],side=owner,ply=0);out=[]
  for failure in(0,1):
   m.private_membership_info(failure)
   for arm in mods:
    cap=mods[arm].compile_semantic_rules(payload);assert mods[arm].semantic_rules_info(cap)==payload;pos=mods[arm].semantic_pack_position(cap,state);before=mods[arm].semantic_position_snapshot(cap,pos);actual=set(mods[arm].semantic_attacked_squares(cap,pos,owner));assert actual==expected,(case,arm,actual,expected)
    assert all(mods[arm].semantic_is_square_attacked(cap,pos,t,owner)==(t in expected)for t in range(64));assert before==mods[arm].semantic_position_snapshot(cap,pos);out.append(dict(arm=arm,failure_mode=failure,attacked=sorted(actual)));del pos,cap
  rows.append(dict(owner=owner,case=case,expected=sorted(expected),results=out))
m.private_membership_info(0)
# Actual work-cap fallback: many duplicate geometry references are accepted but
# must not force a large derived index construction. Existing scanner remains authority.
payload=deepcopy(base);p=deepcopy(pat);p['geometry_indices']=[0]*255;payload['patterns']=[deepcopy(p)for _ in range(256)]
before=m.private_membership_info(-1);t=time.perf_counter();cap=m.compile_semantic_rules(payload);after=m.private_membership_info(-1);assert after[4]==before[4]+1 and after[0]==before[0];assert after[3]==2000001;assert m.semantic_rules_info(cap)==payload
board=[None]*64;board[27]=[0,0,0,0];pos=m.semantic_pack_position(cap,dict(board=board,hands=[[0]*6,[0]*6],side=0,ply=0));normal=_module().compile_semantic_rules(payload);np=_module().semantic_pack_position(normal,dict(board=board,hands=[[0]*6,[0]*6],side=0,ply=0));assert m.semantic_attacked_squares(cap,pos,0)==_module().semantic_attacked_squares(normal,np,0)
fallback=dict(before=before,after=after,seconds=time.perf_counter()-t,rule_info_preserved=True,attacked_agree=True)
write_record(P/'cold-controls-results.json',dict(complete=True,cold=cold,numeric_controls=rows,construction_cap=fallback,seconds=time.perf_counter()-start,scope='16exposed actualrules 16capsule+8completecompilerdisposal samples eacharm;12numeric cases x forced-index-allocation-unavailable/control. 2Mworkfallback actual. Numeric contract not alternate Core/legal trajectories. Full cost includes free and Pythonserialization separately. No production/API changes.'))
print('COLD_CONTROLS_DONE',len(cold),len(rows),fallback,flush=True)
