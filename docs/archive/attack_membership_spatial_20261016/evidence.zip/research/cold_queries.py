from pathlib import Path
import json,sys,time,importlib.util,statistics,random
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
spec=importlib.util.spec_from_file_location('coldfinal._native_core',P/'final_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=dict(question='Does index cost remain useful when each short query pays a fresh Native compile/engine/free?',inputs='16exposed oldroots, not freshvalidation',profiles=['static','dynamic235'],nodes=[1,512],depth=8,repetitions=4,arms=['normal','final'],whole_seconds=240,expected_seconds=60,scope='Native-admission-through-query-record-and-dispose clocks; Corecompile/rootreplay/ruleprice derivation and inputdisk are outside, explicitly NOT entire unfamiliar-rule acquisition. Node1 fallback/UNKNOWN preserved. Final bounded first-seen constructor; no originalbatch execution upgrade.')
(P/'cold-query-plan.json').write_bytes(json.dumps(plan,indent=2).encode());start=time.perf_counter();rows=[]
def stopped():
 for name in('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(z.get('user_paused')or z.get('stopped'))
 assert time.perf_counter()-start<plan['whole_seconds']
with(P/'cold-query-rows.jsonl').open('x',encoding='utf-8')as log:
 for f in sorted((R/'.local_agent/api-ready-20261016/roots').glob('*.json')):
  d=json.loads(f.read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()};before=record_value(s.state)
  for ni,nodes in enumerate(plan['nodes']):
   for pi,profile in enumerate(plan['profiles']):
    for rep in range(plan['repetitions']):
     pair=[];arms=list(plan['arms']);random.Random(d['seed']+ni*100+pi*10+rep).shuffle(arms)
     for arm in arms:
      stopped();t=time.perf_counter();nr=compile_native_semantic_rules(c,**({}if arm=='normal'else dict(backend_module=m)));compile_seconds=time.perf_counter()-t;e=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,dynamic_values=(2,3,5)if profile=='dynamic235'else None,tt_megabytes=0,ordering_cache_enabled=False);tq=time.perf_counter();r=e.search(s,SearchLimits(max_depth=8,max_nodes=nodes,max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);query_seconds=time.perf_counter()-tq;value=record_value(r);encoded=json.dumps(value);del e,nr;ready=time.perf_counter()-t;assert record_value(s.state)==before
      row=dict(seed=d['seed'],board=d['board'],profile=profile,nodes=nodes,rep=rep,arm=arm,kind='ACTUAL_QUERY',compile_seconds=compile_seconds,query_seconds=query_seconds,native_admission_query_record_dispose_seconds=ready,result=value,root_restored=True);rows.append(row);pair.append(row);log.write(json.dumps(row)+'\n');log.flush()
     assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
  print('COLD_QUERY',d['seed'],len(rows),round(time.perf_counter()-start,3),flush=True)
summary=[]
for board in(4,8,12,16):
 for nodes in plan['nodes']:
  for profile in plan['profiles']:
   families={}
   for row in rows:
    if(row['board'],row['nodes'],row['profile'])==(board,nodes,profile):families.setdefault(row['seed'],{}).setdefault(row['rep'],{})[row['arm']]=row
   vv=[]
   for seed,reps in families.items():vv.append(statistics.median(g['final']['native_admission_query_record_dispose_seconds']/g['normal']['native_admission_query_record_dispose_seconds']for g in reps.values()))
   summary.append(dict(board=board,nodes=nodes,profile=profile,family_ratios=vv,median=statistics.median(vv),maximum_family_ratio=max(vv)))
write_record(P/'cold-query-results.json',dict(complete=True,queries=len(rows),rows=rows,summary=summary,seconds=time.perf_counter()-start,scope=plan['scope']));print('COLD_QUERY_DONE',len(rows),json.dumps(summary),flush=True)
