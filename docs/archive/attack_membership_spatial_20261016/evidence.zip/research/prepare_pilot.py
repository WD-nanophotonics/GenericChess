from pathlib import Path
import json
P=Path('.local_agent/attack-membership-20261016')
s=(P/'run.py').read_text();s=s.replace("for arm in('count','timed'):","for arm in('membership',):").replace("plan=json.loads((P/'plan.json').read_bytes());","plan=json.loads((P/'pilot-plan.json').read_bytes());").replace("P/'queries.jsonl'","P/'pilot-queries.jsonl'").replace("mods[arm].private_attack_info(True)","mods[arm].private_membership_info(-1)").replace("mods[arm].private_attack_info(False)","mods[arm].private_membership_info(-1)").replace("len(group)==3","len(group)==2").replace("rep%3","rep%2")
a=s.index('summary=[]');s=s[:a]+"""summary=[]
for case in plan['cases']:
 for profile in plan['profiles']:
  g=[z for z in rows if z['seed']==case['seed']and z['profile']==profile];a={arm:[z for z in g if z['arm']==arm]for arm in plan['arms']};med={arm:statistics.median(z['caller_seconds']for z in zs)for arm,zs in a.items()};summary.append(dict(**case,profile=profile,caller_medians=med,membership_normal_ratio=med['membership']/med['normal']))
write_record(P/'pilot-results.json',dict(complete=True,rows=rows,summary=summary,setup=setup,seconds=time.perf_counter()-start,queries=len(rows),scope=plan['scope']));print('SUMMARY',json.dumps(summary),flush=True)
"""
(P/'pilot.py').write_bytes(s.encode());plan=dict(question='Does bounded immutable membership improve actual whole queries on exposed inputs?',cases=[dict(seed=b,board=d['board'])for b,d in((int(f.stem),json.loads(f.read_bytes()))for f in sorted(Path('.local_agent/api-ready-20261016/roots').glob('*.json')))],arms=['normal','membership'],profiles=['static','dynamic235'],repetitions=2,depth=8,nodes=512,seconds=None,whole_seconds=240,expected_seconds=45,scope='Exposed16root pilot not independent transfer. Full512node allfield equality. Cold compile separately measured; negative counter remains in private implementation. No games/fits/AUX/source adoption.')
(P/'pilot-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
