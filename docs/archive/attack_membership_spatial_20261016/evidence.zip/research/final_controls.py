from pathlib import Path
from copy import copy

import sys,json,time,importlib.util,statistics
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from scripts.research_record import record_value,write_record
from generic_chess.core.semantic_executor import SemanticEngine
from test_native_pending_continuation import assert_equal
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.native import SemanticSearchEngine,semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from test_native_q_history_deferral import cycle,checked_replay
from test_native_pending_continuation import session_after
from phase19c1_native_semantic_fixtures import semantic_corpus
spec=importlib.util.spec_from_file_location('qualview._native_core',P/'final_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
d=json.loads((R/'.local_agent/eval-revisit-20261016/control-results.json').read_bytes());corpus=dict(semantic_corpus());native={};start=time.perf_counter();states=[];histories=[];queries=[];edges=[];attackchecks=0
def stopped():
 for n in('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if z.get('user_paused')or z.get('stopped'):raise RuntimeError('USER_STOP')
 assert time.perf_counter()-start<180
for row in d['mechanisms']:
 stopped();name=row['fixture'];c=corpus[name]
 if name not in native:native[name]=compile_native_semantic_rules(c,backend_module=m)
 nr=native[name];s=GameSession.replay(c,deserialize_game_record(json.dumps(row['game_record'])));assert record_value(s.state)==row['state'];np=pack_semantic_search_position(c,nr,s);before=sem.snapshot(nr,np);v=sem.dynamic_features(nr,np);assert list(v)==row['features'];assert sem.snapshot(nr,np)==before
 core=SemanticEngine(c)
 for owner in(0,1):
  actual=sem.attacked_squares(nr,np,owner);want=core.attacked_squares(s.state.position,owner);assert actual==want,(name,owner,actual,want);attackchecks+=c.board_size*c.board_size
 assert_equal(s,nr,np)
 aa=sem.guarded_actions(nr,np);assert{sem.public_action(nr,a)for a in aa}==set(s.legal_actions()),name
 for raw in aa:
  child=copy(s);ac=sem.public_action(nr,raw);cn=sem.make_checked(nr,np,raw);child.submit(ac);assert_equal(child,nr,cn)
  edges.append(dict(fixture=name,seed=row['seed'],ply=row['ply'],action=record_value(ac),child=record_value(child.state)))
 assert record_value(s.state)==row['state'];states.append(dict(fixture=name,seed=row['seed'],ply=row['ply'],features=v,full_root_restored=True))
for prefix in(0,32,128,512,1023,1024):
 stopped();s=cycle(max_ply=1024,repetition=10000,prefix=prefix);c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','membership')};packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()};values={};errors={};timings={a:[]for a in nrs};before=record_value(s.state)
 for rep in range(32):
  for a in(('normal','membership')if rep%2==0 else('membership','normal')):
   tt=time.perf_counter()
   try:values[a]=sem.dynamic_features(nrs[a],packs[a])
   except Exception as exc:errors[a]=type(exc).__name__+': '+str(exc)
   timings[a].append(time.perf_counter()-tt)
 assert values.get('normal')==values.get('membership');assert errors.get('normal')==errors.get('membership');assert record_value(s.state)==before
 histories.append(dict(prefix=prefix,history_entries=len(s.state.history),features=values,errors=errors,timings=timings,median_ratio=statistics.median(timings['membership'])/statistics.median(timings['normal'])));print('MEMBERSHIP_HISTORY',prefix,histories[-1]['median_ratio'],flush=True)
s=session_after(('e2e4','d7d5','f1b5','c7c6'));c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','membership')};before=record_value(s.state)
for q in(0,1,4):
 for tt in(0,1):
  engines={a:SemanticSearchEngine(c,nr,dynamic_values=(2,3,5),tt_megabytes=tt,ordering_cache_enabled=False)for a,nr in nrs.items()}
  for rep in range(2):
   pair=[]
   for a in(('normal','membership')if rep==0 else('membership','normal')):
    stopped();t=time.perf_counter();r=engines[a].search(s,SearchLimits(max_depth=2,max_nodes=256,max_time_seconds=None,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0),root_window_pruning=True);z=dict(kind='ACTUAL_QUERY',fixture='actual_pending',q=q,tt=tt,rep=rep,arm=a,result=record_value(r),caller_seconds=time.perf_counter()-t);checked_replay(s,nrs[a],r);assert record_value(s.state)==before;queries.append(z);pair.append(z)
   assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
write_record(P/'final-control-results.json',dict(complete=True,states=states,histories=histories,queries=queries,checked_edges=edges,core_scalar_attack_comparisons=attackchecks,seconds=time.perf_counter()-start,scope='280existing fixturehistory positions, independentCoreallattacksets and complete legal frontiers/allchildren history checked;6actualhistory prefixes pluscapacityerror;24PENDINGqTTqueries. Qualification of private index, not newgames orall-domainclaim; no AUXexecution.'));print('MEMBERSHIP_CONTROL_DONE',len(states),len(queries),time.perf_counter()-start,flush=True)
