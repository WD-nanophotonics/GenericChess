from pathlib import Path
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';old=R/'.local_agent/eval-revisit-20261016'
s=(old/'view_controls.py').read_text().replace("P=R/'.local_agent/eval-revisit-20261016'","P=R/'.local_agent/attack-membership-20261016'").replace("P/'view_native_core.pyd'","P/'clean_native_core.pyd'").replace("d=json.loads((P/'control-results.json').read_bytes())","d=json.loads((R/'.local_agent/eval-revisit-20261016/control-results.json').read_bytes())").replace("'view'","'membership'").replace('view-control-results.json','membership-control-results.json').replace("'VIEW_HISTORY'","'MEMBERSHIP_HISTORY'").replace("'VIEW_CONTROL_DONE'","'MEMBERSHIP_CONTROL_DONE'")
s=s.replace("from pathlib import Path","from pathlib import Path\nfrom copy import copy\nfrom generic_chess.core.semantic_executor import SemanticEngine") # imports packagebefore sys.path but cwdPython sys.path contains? injected aftersys later instead
s=s.replace("from generic_chess.core.semantic_executor import SemanticEngine","")
s=s.replace("from scripts.research_record import record_value,write_record","from scripts.research_record import record_value,write_record\nfrom generic_chess.core.semantic_executor import SemanticEngine\nfrom test_native_pending_continuation import assert_equal\nfrom generic_chess.native.mirror import pack_semantic_action")
s=s.replace("states=[];histories=[];queries=[]","states=[];histories=[];queries=[];edges=[];attackchecks=0")
oldline="assert sem.snapshot(nr,np)==before;states.append("
newline="""assert sem.snapshot(nr,np)==before
 core=SemanticEngine(c)
 for owner in(0,1):
  actual=sem.attacked_squares(nr,np,owner);want=core.attacked_squares(s.state.position,owner);assert actual==want,(name,owner,actual,want);attackchecks+=c.board_size*c.board_size
 assert_equal(s,nr,np)
 aa=sem.guarded_actions(nr,np);assert{sem.public_action(nr,a)for a in aa}==set(s.legal_actions()),name
 for raw in aa:
  child=copy(s);ac=sem.public_action(nr,raw);cn=sem.make_checked(nr,np,raw);child.submit(ac);assert_equal(child,nr,cn)
  edges.append(dict(fixture=name,seed=row['seed'],ply=row['ply'],action=record_value(ac),child=record_value(child.state)))
 assert record_value(s.state)==row['state'];states.append("""
assert oldline in s;s=s.replace(oldline,newline)
s=s.replace("states=states,histories=histories,queries=queries","states=states,histories=histories,queries=queries,checked_edges=edges,core_scalar_attack_comparisons=attackchecks")
s=s.replace("280receiptbound Corefeature positions replayed into private view image;6actualhistory lengths inclfullcapacity error;24actual PENDING q0/1/4 TT0/1 cold/warm fixednode queries and full checked PV history. No new games/fit/AUX execution.","280existing fixturehistory positions, independentCoreallattacksets and complete legal frontiers/allchildren history checked;6actualhistory prefixes pluscapacityerror;24PENDINGqTTqueries. Qualification of private index, not newgames orall-domainclaim; no AUXexecution.")
(P/'membership_controls.py').write_bytes(s.encode())
