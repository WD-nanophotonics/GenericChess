from pathlib import Path
import sys,json,time,random,importlib.util,traceback
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,generate_game,GeneratorConfig,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
modules={'A_normal':None}
for a,n in [('B_membership','clean')]:
 spec=importlib.util.spec_from_file_location('transfer_'+n+'._native_core',P/(n+'_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules[a]=m
plan=json.loads((P/'transfer-plan.json').read_bytes());start=time.perf_counter();rows=[];roots=[];rootdir=P/'transfer-roots';rootdir.mkdir(exist_ok=False)
def stopped():
 for n in('rollout','advisor','slack'):
  d=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('user_paused')or d.get('stopped'):raise RuntimeError('USER_STOP')
def logrow(log,z):
 rows.append(z);log.write(json.dumps(z)+'\n');log.flush()
with(P/'transfer-queries.jsonl').open('x',encoding='utf-8')as log:
 for idx,case in enumerate(plan['cases']):
  stopped();t=time.perf_counter();root=dict(**case)
  try:
   if t-start>=plan['whole_seconds']:root['kind']='WHOLE_CAP_NOT_STARTED_UNKNOWN';roots.append(root);continue
   g=generate_game(GeneratorConfig(seed=case['seed'],board_size=case['board'],setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));x=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c);rng=random.Random(case['seed']+700000)
   for j in range(8):
    stopped()
    if s.state.terminal_status.is_terminal:break
    aa=sorted(s.legal_actions(),key=repr)
    if not aa:break
    s.submit(rng.choice(aa))
   d=dict(**case,ruleset=json.loads(serialize_ruleset(g.ruleset)),game_record=json.loads(serialize_game_record(s.to_record())),state=record_value(s.state));write_record(rootdir/f"{case['seed']}.json",d);root.update(actual_ply=s.state.ply_count,terminal=record_value(s.state.terminal_status),acquisition_seconds=time.perf_counter()-t)
   if s.state.terminal_status.is_terminal or s.state.ply_count<8:root['kind']='ACTUAL_TERMINAL_TAIL';roots.append(root);print('TAIL',case,flush=True);continue
   v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()};nrs={a:compile_native_semantic_rules(c,**({}if m is None else dict(backend_module=m)))for a,m in modules.items()};before=record_value(s.state);root['kind']='EXECUTED_ROOT';root['setup_seconds']=time.perf_counter()-t;roots.append(root);write_record(P/'transfer-roots-progress.json',dict(complete=False,rows=roots))
   for pi,profile in enumerate(plan['profiles']):
    for rep in range(plan['repetitions']):
     arms=list(plan['arms']);random.Random(20261016+idx*100+pi*10+rep).shuffle(arms);quartet=[]
     for arm in arms:
      stopped();z=dict(**case,profile=profile,rep=rep,arm=arm)
      if time.perf_counter()-start>=plan['whole_seconds']:z['kind']='WHOLE_CAP_NOT_STARTED_UNKNOWN';logrow(log,z);continue
      te=time.perf_counter();e=SemanticSearchEngine(c,nrs[arm],board_values=bv,hand_values=hv,dynamic_values=(2,3,5)if profile=='dynamic235'else None,tt_megabytes=0,ordering_cache_enabled=False)
      if arm in('C_cache','D_both'):modules[arm].private_cache(True)
      tq=time.perf_counter()
      try:
       r=e.search(s,SearchLimits(max_depth=plan['depth'],max_nodes=plan['nodes'],max_time_seconds=plan['search_seconds'],quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);api=time.perf_counter()-tq;output=record_value(r);encoded=json.dumps(output,separators=(',',':'));ready=time.perf_counter()-tq;z.update(kind='ACTUAL_QUERY',result=output,caller_seconds=api,record_ready_seconds=ready,serialized_bytes=len(encoded.encode()),root_restored=record_value(s.state)==before,engine_and_query_seconds=time.perf_counter()-te);assert z['root_restored']
       if arm in('C_cache','D_both'):z['cache']=modules[arm].private_cache(False)
      except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
      quartet.append(z);logrow(log,z)
     joint=len(quartet)==2 and all(z['kind']=='ACTUAL_QUERY'and z['result']['completed_depth']==4 for z in quartet)
     if joint:assert all({k:v for k,v in z['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in quartet[0]['result'].items()if k!='elapsed_seconds'}for z in quartet)
     print('TRANSFER',case['seed'],profile,rep,'jointD4',joint,'seconds',round(time.perf_counter()-start,2),'rows',len(rows),flush=True)
  except Exception as exc:root.update(kind='ACTUAL_ROOT_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc());roots.append(root);print('ROOT_FAILURE',case,root['error'],flush=True)
  write_record(P/'transfer-roots-progress.json',dict(complete=False,rows=roots))
write_record(P/'transfer-results.json',dict(complete=True,roots=roots,rows=rows,planned_slots=plan['planned_slots'],actual_slots=len(rows),seconds=time.perf_counter()-start,scope=plan['scope']));print('TRANSFER_DONE',len(rows),time.perf_counter()-start,flush=True)
