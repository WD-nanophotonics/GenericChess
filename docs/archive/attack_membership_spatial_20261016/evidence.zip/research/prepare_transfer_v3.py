from pathlib import Path
import json,sys,sysconfig,shutil,subprocess,time,hashlib
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';S=P/'clean-source-v3';S.mkdir(exist_ok=False)
for f in(P/'membership-source').iterdir():shutil.copyfile(f,S/f.name)
for f in S.iterdir():
 s=f.read_text()
 s=s.replace('private_membership_bytes','attack_membership_bytes').replace('private_membership','attack_membership').replace('gc_private_prepare_membership','gc_semantic_runtime_prepare_attack_membership')
 if f.name=='native_semantic_rules.h':s=s.replace('extern unsigned long long gc_private_index_stats[6];\nextern int gc_private_index_failure;\n','')
 if f.name=='native_semantic_rules.c':s=s.replace(';gc_private_index_stats[1]++;',';')
 if f.name=='native_semantic_runtime.c':
  s=s.replace('unsigned long long gc_private_index_stats[6]={0}; /* built,free,bytes,visits, fallback,negative */\nint gc_private_index_failure=0;\n','')
  s=s.replace(' gc_private_index_stats[2]=bytes;gc_private_index_stats[3]=0;\n','')
  s=s.replace('||gc_private_index_failure','').replace('{gc_private_index_stats[4]++;return;}','{return;}')
  s=s.replace(' gc_private_index_stats[0]++;gc_private_index_stats[3]=work;return;',' return;')
  s=s.replace('free(bits);gc_private_index_stats[3]=work;gc_private_index_stats[4]++;','free(bits);')
  s=s.replace('gc_private_index_stats[5]++;continue;','continue;')
 if f.name=='native_module.c':
  a=s.index('static PyObject *gc_attack_membership_info(');b=s.index('static PyMethodDef ',a);s=s[:a]+s[b:];s=s.replace('    {"attack_membership_info",gc_attack_membership_info,METH_VARARGS,"private membership lifecycle"},\n','')
 f.write_bytes(s.encode())
assert not any('gc_private_'in f.read_text()for f in S.iterdir())
outp=P/'clean_native_core.pyd';cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(outp)]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);row=dict(returncode=r.returncode,seconds=time.perf_counter()-t,stderr=r.stderr.decode(errors='replace'),hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()});(P/'clean-build-private.json').write_bytes(json.dumps(row,indent=2).encode());print('BUILD',r.returncode,row['seconds'],row['stderr'],flush=True);assert r.returncode==0
old=R/'.local_agent/eval-revisit-20261016/transfer.py';s=old.read_text().replace("P=R/'.local_agent/eval-revisit-20261016'","P=R/'.local_agent/attack-membership-20261016'").replace("for a,n in [('B_livecopy','view'),('C_cache','cache'),('D_both','both')]:","for a,n in [('B_membership','clean')]:").replace("len(quartet)==4","len(quartet)==2")
# Scope engine initialization as part of caller, while keeping the original API timing field.
s=s.replace("      e=SemanticSearchEngine(","      te=time.perf_counter();e=SemanticSearchEngine(").replace("root_restored=record_value(s.state)==before)","root_restored=record_value(s.state)==before,engine_and_query_seconds=time.perf_counter()-te)")
(P/'transfer.py').write_bytes(s.encode())
plan=json.loads((R/'.local_agent/eval-revisit-20261016/transfer-plan.json').read_bytes())
plan.update(question='Does exact rule-constant membership reduce finite fullsearch cost on fresh generated complete-rule inputs after cold admission is charged?',changed_premise='Actual48counterqueries show wide dynamic attackshare.594/static.170;128 exposedpilotqueries allfields equal and lowercost. Clean candidate removes hot stats, not any semantic guard.',cases=[dict(seed=75000+board*100+i,board=board)for board in(4,8,12,16)for i in range(1,9)],arms=['A_normal','B_membership'],planned_slots=256,search_seconds=8,whole_seconds=2400,expected_seconds=1000,comparison='2arms x2profiles x2reps x32families=256slots; jointD4all non-time equality, complete-censor one-arm completions and adversities retained. Perfamily median paired caller ratio, descriptive family bootstrap only. Each root cold admission recorded separately.',decision='Only simpler exact negative prefilter potentially adopted after complete-rule/numeric/error/fallback controls, freshcost and normal/source regressions; no q/price/model/TT/API/default change or strength claim.',budget_choice='8newfamilies perboard,2balancedreplicates,8s cappedD4/131072nodes. Maxquerytime2048s+boundedsetup/whole2400s <1hour. Cheaper16root variant too few families; no extra games/training or unchangedqcampaign.',scope='Complete generated promotion/drop/base/aux/history; candidate index only ruleconstant conservative target membership, no state/history cache. Backend only, no AUXruntime/learning/prover imports.')
(P/'transfer-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
