from pathlib import Path
from copy import deepcopy
import sys,json,importlib.util,time,hashlib,statistics
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';sys.path[:0]=[str(R/'tests'),str(R)]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.compiler import build_semantic_compile_payload
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from phase19c1_native_semantic_fixtures import semantic_corpus
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import write_record
mods={}
for arm in('old','bounded'):
 spec=importlib.util.spec_from_file_location('index_'+arm+'._native_core',P/(arm+'_inspect_native_core.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
def oracle(p):
 cells=p['board_size']**2;stride=(cells+7)//8;n=len(p['types']);out=bytearray(n*2*cells*stride)
 for pat in p['patterns']:
  if pat['target']!=1:continue
  for typ in set(pat['type_indices']):
   for gid in pat['geometry_indices']:
    g=p['geometries'][gid]
    if g['kind']==2 or(g['atom_source']is not None and g['atom_source'][0]!=typ):continue
    for owner,entries in enumerate(g['paths']):
     first={}
     for src,targets in entries:first.setdefault(src,targets)
     for src,targets in first.items():
      if not 0<=src<cells:continue
      for target in targets:
       if 0<=target<cells:out[(((typ*2+owner)*cells+src)*stride)+target//8]|=1<<(target%8)
 return bytes(out)
start=time.perf_counter();rows=[];cases=[]
for ddir in(R/'.local_agent/api-ready-20261016/roots',P/'transfer-roots'):
 for f in sorted(ddir.glob('*.json')):
  d=json.loads(f.read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);cases.append((ddir.name+':'+f.stem,c))
cases += [('fixture:'+name,c)for name,c in semantic_corpus()]
for name,c in cases:
 p,_=build_semantic_compile_payload(c);want=oracle(p);values={}
 for arm,m in mods.items():
  cap=m.compile_semantic_rules(p);v=m.private_index_bytes(cap);assert v is not None and v==want,(name,arm);values[arm]=hashlib.sha256(v).hexdigest();del cap
 rows.append(dict(case=name,bytes=len(want),set_bits=sum(x.bit_count()for x in want),sha256=hashlib.sha256(want).hexdigest(),arm_sha256=values))
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));base,_=build_semantic_compile_payload(c);pat=deepcopy(next(p for p in base['patterns']if p['target']==1 and p['type_indices']==[0]and not p['guards']and not p['slot_guards']));pat['geometry_indices']=[0];path=[[1,[9]]]+[[0,[8]]]*65534;timings=[];numeric=[]
for npat in(1,2,4):
 p=deepcopy(base);p['patterns']=[deepcopy(pat)for _ in range(npat)];p['geometries'][0]['paths']=[path,path];want=oracle(p);tt={a:[]for a in mods}
 for rep in range(4):
  for arm in(('old','bounded')if rep%2==0 else('bounded','old')):
   m=mods[arm];t=time.perf_counter();cap=m.compile_semantic_rules(p);elapsed=time.perf_counter()-t;tt[arm].append(elapsed);assert m.private_index_bytes(cap)==want;del cap
 timings.append(dict(patterns=npat,path_entries_per_owner=65535,expected_old_missing_source_path_visits=2*(64-2)*65535*npat,new_counted_entry_visits=2*65535*npat,compile_seconds=tt,median_ratio=statistics.median(tt['bounded'])/statistics.median(tt['old'])))
p=deepcopy(base);p['patterns']=[deepcopy(pat)for _ in range(32)];p['geometries'][0]['paths']=[path,path];t=time.perf_counter();cap=mods['bounded'].compile_semantic_rules(p);assert mods['bounded'].private_index_bytes(cap)is None;fallback=dict(patterns=32,elapsed_seconds=time.perf_counter()-t,index_unavailable=True,scope='Only boundedconstructor executed; no unsafeoldlargecase.')
write_record(P/'index-oracle-results.json',dict(complete=True,rows=rows,timings=timings,entry_cap_fallback=fallback,seconds=time.perf_counter()-start,scope='Complete union bytes compared to independentPythonpayload set-union oracle. Numeric65535unsortedentries are acceptedtransport contract, notphysicalrules distribution orCoretrajectory. Oldlookup pathvisit lowerbound is derived from exact fixture layout, notinstrumentedcount. Timings include unchangedpayloadparse.'))
print('INDEX_ORACLE',len(rows),sum(r['bytes']*8 for r in rows),'bits',json.dumps(timings),fallback,flush=True)
