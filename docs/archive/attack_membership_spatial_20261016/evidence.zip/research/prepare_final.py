from pathlib import Path
import shutil,sys,sysconfig,subprocess,time,json,hashlib
R=Path.cwd();P=R/'.local_agent/attack-membership-20261016';S=P/'final-source';S.mkdir(exist_ok=False)
for f in(P/'bounded-source').iterdir():shutil.copyfile(f,S/f.name)
p=S/'native_semantic_runtime.c';s=p.read_text();a=s.index('/* Compile a conservative union');b=s.index('static int target_ok(',a);helper=s[a:b].replace('void gc_semantic_runtime_prepare_attack_membership(','static void sem_build_attack_membership(');s=s[:a]+s[b:];p.write_bytes(s.encode())
p=S/'native_semantic_rules.c';s=p.read_text();i=s.index('GCSemanticRules *gc_semantic_rules_compile(');s=s[:i]+helper+s[i:];s=s.replace('gc_semantic_runtime_prepare_attack_membership(rules);','sem_build_attack_membership(rules);');p.write_bytes(s.encode())
p=S/'native_semantic_rules.h';s=p.read_text().replace('void gc_semantic_runtime_prepare_attack_membership(GCSemanticRules *rules);\n','');p.write_bytes(s.encode())
outp=P/'final_native_core.pyd';cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(outp)];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);out=dict(returncode=r.returncode,seconds=time.perf_counter()-t,stderr=r.stderr.decode(errors='replace'),source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()});(P/'final-build-private.json').write_bytes(json.dumps(out,indent=2).encode());print('FINAL_BUILD',r.returncode,out['seconds'],out['stderr']);assert r.returncode==0
s=(P/'pilot.py').read_text().replace("P/(arm+'_native_core.pyd')","P/'final_native_core.pyd'").replace("P/'pilot-queries.jsonl'","P/'final-pilot-queries.jsonl'").replace("P/'pilot-results.json'","P/'final-pilot-results.json'")
s=s.replace("     if arm!='normal':mods[arm].private_membership_info(-1)\n","").replace("      if arm!='normal':z['counter']=mods[arm].private_membership_info(-1)\n","")
(P/'final_pilot.py').write_bytes(s.encode())
s=(P/'membership_controls.py').read_text().replace("P/'clean_native_core.pyd'","P/'final_native_core.pyd'").replace("membership-control-results.json","final-control-results.json")
(P/'final_controls.py').write_bytes(s.encode())
