
static PyObject *private_isolation(PyObject *self,PyObject *args){
 (void)self;PyObject *rc,*rootc,*ac,*bc;int depth,bound,reverse;
 if(!PyArg_ParseTuple(args,"OOOOiii",&rc,&rootc,&ac,&bc,&depth,&bound,&reverse))return NULL;
 GCSemanticRules *r=PyCapsule_GetPointer(rc,GC_SEM_RULES_CAPSULE);
 GCSemanticPosition *root=PyCapsule_GetPointer(rootc,GC_SEM_POSITION_CAPSULE);
 GCSemanticPosition *aa=PyCapsule_GetPointer(ac,GC_SEM_POSITION_CAPSULE);
 GCSemanticPosition *bb=PyCapsule_GetPointer(bc,GC_SEM_POSITION_CAPSULE);
 if(!r||!root||!aa||!bb)return NULL;
 if(!gc_semantic_require_matching_rules(r,aa)||!gc_semantic_require_matching_rules(r,bb))return NULL;
 if(depth<0||depth>16||bound<1||bound>3||aa->ply!=bb->ply||aa->ply>=GC_SEM_MAX_PLY){PyErr_SetString(PyExc_ValueError,"bad diagnostic input");return NULL;}
 GCSemanticIterativeContext *ctx=calloc(1,sizeof(*ctx));if(!ctx)return PyErr_NoMemory();
 ctx->rules=r;ctx->root_window_pruning=1;ctx->pv_stride=1;
 ctx->tt=gc_semantic_tt_create(1048576,NULL);
 ctx->pv_table=calloc(GC_SEM_MAX_PLY+2,sizeof(uint64_t));ctx->pv_length=calloc(GC_SEM_MAX_PLY+2,sizeof(uint16_t));
 if(!ctx->tt||!ctx->pv_table||!ctx->pv_length){gc_semantic_tt_free(ctx->tt);free(ctx->pv_table);free(ctx->pv_length);free(ctx);return PyErr_NoMemory();}
 uint64_t rootkey[4],keys[2][4];unsigned maxima[2];int terminals[2],winners[2];
 gc_semantic_context_seed(root,rootkey);rootkey[0]^=UINT64_C(0x726f6f742d657861);rootkey[1]^=UINT64_C(0x63742d6465707468);
 memcpy(ctx->finite_root_context,rootkey,32);GCSemanticPosition *positions[2]={aa,bb};
 unsigned ply=aa->ply-root->ply;
 for(unsigned k=0;k<2;k++){
  GCSemanticPosition *p=positions[k];memcpy(ctx->history_context[ply],rootkey,32);
  for(unsigned i=root->history_len;i<p->history_len;i++){
   uint64_t next[4];gc_semantic_context_step(ctx->history_context[ply],p->history_digest[i],p->history_actor[i],p->history_gave_check[i],i,next);
   memcpy(ctx->history_context[ply],next,32);
  }
  gc_semantic_finite_history_max(ctx,p,0);maxima[k]=ctx->finite_history_max[0];ctx->finite_history_max[ply]=(uint16_t)maxima[k];
  uint64_t temp[4];const uint64_t *key=gc_semantic_finite_tt_context(ctx,p,ply,(unsigned)depth,temp);memcpy(keys[k],key,32);
  terminals[k]=gc_semantic_terminal_status_known(r,p,&winners[k],p->history_digest[p->history_len-1]);
 }
 unsigned writer=reverse?1:0,reader=1-writer;
 GCSemanticPosition *wp=positions[writer];
 // Restore the writer's actual rolling full-history context and multiplicity.
 memcpy(ctx->history_context[ply],rootkey,32);
 for(unsigned i=root->history_len;i<wp->history_len;i++){
  uint64_t next[4];gc_semantic_context_step(ctx->history_context[ply],wp->history_digest[i],wp->history_actor[i],wp->history_gave_check[i],i,next);memcpy(ctx->history_context[ply],next,32);
 }
 ctx->finite_history_max[ply]=(uint16_t)maxima[writer];
 int score=terminals[writer]?gc_semantic_iterative_terminal_score(winners[writer],wp->side_to_move,ply):(writer?222:111);
 int alpha=bound==GC_TT_BOUND_UPPER?score:score-1000;
 int beta=bound==GC_TT_BOUND_LOWER?score:score+1000;
 gc_semantic_tt_store_node(ctx,wp,ply,depth,score,alpha,beta,0,0);
 int32_t got=0;int sd=0,ha=0;uint64_t action=0,col=0;uint8_t sb=0;uint32_t gen=0;
 int hit=gc_semantic_tt_probe(ctx->tt,positions[reader],keys[reader],depth,&got,&action,&ha,&sd,&sb,&gen,&col,NULL,NULL);
 int32_t ownscore=0;int owndepth=0;uint8_t ownbound=0;
 int own=gc_semantic_tt_probe(ctx->tt,wp,keys[writer],depth,&ownscore,NULL,NULL,&owndepth,&ownbound,NULL,NULL,NULL,NULL);
 PyObject *out=Py_BuildValue("{s:i,s:i,s:i,s:i,s:i,s:i,s:i,s:I,s:I,s:i,s:i,s:i,s:i}",
 "cross_hit",hit,"own_hit",own,"stored_score",score,"own_score",gc_semantic_score_from_tt(ownscore,ply),"cross_score",gc_semantic_score_from_tt(got,ply),
 "stored_bound",ownbound,"same_key",!memcmp(keys[0],keys[1],32),"ma",maxima[0],"mb",maxima[1],"terminal_a",terminals[0],"terminal_b",terminals[1],"stored_depth",owndepth,"cross_depth",sd);
 gc_semantic_tt_free(ctx->tt);free(ctx->pv_table);free(ctx->pv_length);free(ctx);return out;
}
