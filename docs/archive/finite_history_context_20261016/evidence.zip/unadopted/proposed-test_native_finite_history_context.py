"""Guarded finite TT routing on real same-root histories, built from actual C."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import sysconfig

import pytest

from generic_chess.native import native_available
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession


@pytest.fixture(scope="module")
def finite_context_kernel(tmp_path_factory):
    if os.name != "nt" or not native_available():
        pytest.skip("optional Windows Native source-build control")
    spec = importlib.util.find_spec("ziglang")
    if spec is None:
        pytest.skip("Zig required for the private source-build control")
    zig = Path(spec.origin).parent / "zig.exe"
    if not zig.is_file():
        pytest.skip("Windows Zig unavailable")
    root = Path(__file__).resolve().parents[2]
    source = root / "generic_chess" / "_native"
    out = tmp_path_factory.mktemp("finite-tt-context")
    module = (source / "native_module.c").read_text(encoding="utf-8-sig")
    hook = (root / "tests/fixtures/native_finite_context_probe.c").read_text(encoding="utf-8")
    needle = "static PyMethodDef gc_methods[] = {"
    assert module.count(needle) == 1
    module = module.replace(needle, hook + "\n" + needle +
        '\n    {"private_isolation",private_isolation,METH_VARARGS,"Test-only finite TT routing"},')
    (out / "native_module.c").write_bytes(module.encode("utf-8"))
    binary = out / ("_native_core" + sysconfig.get_config_var("EXT_SUFFIX"))
    command = [str(zig), "cc", "-target", "x86_64-windows-gnu", "-shared", "-O2",
               "-I" + sysconfig.get_path("include"), "-I" + str(source),
               "-L" + str(Path(sys.base_prefix) / "libs"), "-lpython312"]
    command += [str(out / p.name if p.name == "native_module.c" else p)
                for p in sorted(source.glob("*.c"))]
    command += ["-o", str(binary)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=180,
                            env=dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(out / "zig-cache")))
    assert result.returncode == 0, result.stderr
    spec = importlib.util.spec_from_file_location("finite_test._native_core", binary)
    kernel = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(kernel)
    return kernel


@pytest.fixture(scope="module")
def paired_histories(finite_context_kernel):
    root = Path(__file__).resolve().parents[2]
    inputs = json.loads((root / "tests/fixtures/finite_context_histories.json").read_text())
    values = {}
    for item in inputs:
        compiled = compile_legacy_ruleset_for_semantic_execution(
            deserialize_ruleset(json.dumps(item["ruleset"])))
        rules = compile_native_semantic_rules(compiled, backend_module=finite_context_kernel)
        initial = GameSession(compiled)
        root_capsule = pack_semantic_search_position(compiled, rules, initial)
        sessions = [GameSession.replay(compiled, deserialize_game_record(json.dumps(r["game_record"])))
                    for r in item["records"]]
        assert sessions[0].state.position == sessions[1].state.position
        assert len(sessions[0].state.history) == len(sessions[1].state.history)
        # All records are legally replayed from the same initial root.
        capsules = [pack_semantic_search_position(compiled, rules, s) for s in sessions]
        values[item["repetition"], item["H"]] = (rules, root_capsule, capsules)
    return values


@pytest.mark.parametrize("repeat,length,depth,cross", [
    (4, 8, 1, False),   # M3+ceil(1/2)==R versus eligible M2.
    (4, 8, 0, True),    # Both nonterminal D0 entries may share.
    (4, 12, 0, False),  # Actual repetition terminal store versus ongoing history.
    (5, 14, 2, False),  # M4+ceil(2/2)==R versus eligible M2.
    (5, 14, 3, False),
])
@pytest.mark.parametrize("bound", [1, 2, 3])  # EXACT / LOWER / UPPER
@pytest.mark.parametrize("reverse", [0, 1])
def test_finite_tt_eligibility_namespaces(
    finite_context_kernel, paired_histories, repeat, length, depth, cross, bound, reverse,
):
    rules, root, positions = paired_histories[repeat, length]
    result = finite_context_kernel.private_isolation(
        rules.capsule, root, *positions, depth, bound, reverse)
    assert result["own_hit"] == 1
    assert result["own_score"] == result["stored_score"]
    assert result["stored_bound"] == bound
    assert result["stored_depth"] == depth
    assert bool(result["cross_hit"]) == cross
    assert bool(result["same_key"]) == cross
    if cross:
        assert result["cross_depth"] == depth
    if (repeat, length) == (4, 12):
        assert result["terminal_a"] != 0 and result["terminal_b"] == 0
