from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';OLD=R/'.local_agent/tt-demotion-20261016';sys.path[:0]=[str(R),str(OLD)]
import shadow_loader as g
a=g.a
sp=importlib.util.spec_from_file_location('rootattribution._native_core',P/'root_native_core.pyd');root=importlib.util.module_from_spec(sp);sp.loader.exec_module(root)
mods={'normal':g.p.m,'root':root};raws={}
for name,m in mods.items():
 fn=m.semantic_engine_search
 def capture(*args,_fn=fn,_name=name,**kwargs):
  out=_fn(*args,**kwargs);raws[_name]=a.record_value(out);return out
 m.semantic_engine_search=capture
(P/'root-attribution-plan.json').write_bytes(json.dumps(dict(question='Do required canonical root tie refinements explain why naive TT-root ordering has strong capped regressions?',changed_premise='Fresh32families show root loses a16boardD4 completion despite conditional speed. Existing raw Native fields expose tie refinements/aborts but high-level result does not; no newAPI or skippedcorrectness.',inputs='ALL16original exposed wide roots, one paired order balanced byseed, not selected only favorable/adverse cases',queries=32,depth=4,nodes=131072,seconds=8,whole_seconds=300,expected_seconds=70,scope='Counter attribution using existing rawfields; copied raw serialization cost included, not freshcounterfreeperf/causal proof. Retain all caps/fullPV/history; do not disable tieauthority.'),indent=2).encode())
rows=[];start=time.perf_counter();cases=json.loads((OLD/'curve-plan.json').read_bytes())['inputs']
for case in cases:
 s,nr,d=g.load(case['seed'])
 for name in(['normal','root']if case['seed']%2 else['root','normal']):
  g.p.stopped();assert time.perf_counter()-start<300
  nr=a.nc.compile_native_semantic_rules(s.compiled,backend_module=mods[name]);e=a.SemanticSearchEngine(s.compiled,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=16,ordering_cache_enabled=False)
  t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=4,max_nodes=131072,max_time_seconds=8,quiescence_max_depth=0),root_window_pruning=True)
  row=dict(**case,arm=name,result=a.record_value(r),raw=raws[name],seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r));rows.append(row)
 print('ROOTATTR',case,[(r['arm'],r['raw']['root_tie_refinements'],r['raw']['root_tie_aborts'],r['result']['nodes'])for r in rows[-2:]],flush=True)
a.write_record(P/'root-attribution-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('ROOTATTR_CLOSED',len(rows),time.perf_counter()-start,flush=True)
