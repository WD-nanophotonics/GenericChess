from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';F=P/(sys.argv[1]if len(sys.argv)>1 else'finite');sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
a=p.a;plan=json.loads((F/'plan.json').read_bytes());done=json.loads((F/'completion.json').read_bytes());assert done['complete'];by={(g['seed'],g['mode']):g for g in done['games']};comparisons=[("A_control","B_role"+str(role),role)for role in(0,1)]
cases=[dict(**ca,left=x,right=y,role=role)for ca in plan['inputs']for x,y,role in comparisons];rp=dict(question='Which first physical choices differ across the fixed-policy finite methods, and do literal one-reply outcomes explain an observed contrast?',cases=cases,selection='ALLpaired roles/comparisons, including unchanged paths and UNKNOWN cases. No outcome/root filtering.',diagnostic_seconds=2,whole_seconds=240,expected_seconds=60,scope='Exposed descriptive diagnosis, not all-defense WDL or identical-continuation causality. Opponent timed choices can diverge despite identical nominal policy; record actor/owners explicitly.')
a.write_record(F/'divergence-plan.json',rp);(F/'divergence-roots').mkdir(exist_ok=True);start=time.perf_counter();rows=[];diagnostics={};rootcount=0
for case in cases:
 p.stopped();xg,yg=by[(case['seed'],case['left'])],by[(case['seed'],case['right'])]
 if 'result'not in xg or'result'not in yg:rows.append(dict(case=case,kind='MISSING_GAME_UNKNOWN'));continue
 xp=F/f"game-{case['seed']}-{case['left']}.json";yp=F/f"game-{case['seed']}-{case['right']}.json";x=json.loads(xp.read_bytes());y=json.loads(yp.read_bytes());d=json.loads((F/'roots'/f"{case['seed']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));xr,yr=x['rows'],y['rows'];found=False
 for ply,(u,v)in enumerate(zip(xr,yr)):
  assert p.digest(s)==u['before_sha256']==v['before_sha256']
  if 'action'not in u or'action'not in v:break
  if u['action']!=v['action']:
   rid=f'div-{rootcount}';rootcount+=1;root=dict(ruleset=d['ruleset'],game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s),board_values=d['board_values'],hand_values=d['hand_values'])
   a.write_record(F/'divergence-roots'/f'{rid}.json',root);acts=[u['action'],v['action']];keys=[]
   for act in acts:
    key=p.digest(s)+':'+json.dumps(act,sort_keys=True);keys.append(key)
    if key not in diagnostics:
     ac=next(ac for ac in s.legal_actions()if a.record_value(ac)==act)
     diagnostics[key]=a.diagnosis(s,ac)if time.perf_counter()-start<240 else dict(kind='WHOLE_CAP_NOT_STARTED_UNKNOWN')
   rows.append(dict(case=case,kind='FIRST_ACTION_DIFFERENCE',root_id=rid,ply=ply,actor=u['actor'],left_owner=u['owner'],right_owner=v['owner'],actions=acts,diagnostic_keys=keys,same_physical_child=u['after_sha256']==v['after_sha256'],source_files=[xp.name,yp.name],source_sha256=[hashlib.sha256(q.read_bytes()).hexdigest()for q in(xp,yp)]));found=True;break
  s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==u['action']));assert p.digest(s)==u['after_sha256']==v['after_sha256']
 if not found:rows.append(dict(case=case,kind='IDENTICAL_FULL_PATH'if len(xr)==len(yr)and x['state']==y['state']else'COMMON_PREFIX_DIFFERENT_TAIL',left_edges=len(xr),right_edges=len(yr)))
a.write_record(F/'divergence-results.json',dict(complete=True,rows=rows,diagnostics=diagnostics,seconds=time.perf_counter()-start));print('DIVERGENCE_CLOSED',F.name,len(rows),rootcount,len(diagnostics),time.perf_counter()-start,flush=True)
