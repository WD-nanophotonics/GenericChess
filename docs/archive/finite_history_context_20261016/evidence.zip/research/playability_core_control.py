from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;old=json.loads((P/'playability-results.json').read_bytes())
(P/'playability-core-control-plan.json').write_bytes(json.dumps(dict(question='Did the first Core validation censor because its callback reread disk stop flags in the hot loop, contrary to existing operating guidance?',changed_premise='Source firstcheckpoint calls p.stopped inside legalgen;25Core UNKNOWN versus all54Native completed. Keep original pilot/data/caps; NEW same1s Core-only control uses deadline-only hotcallback and outer-root stop check. No Native search rerun.',cases='All56originalslots/54actualroots, no outcome selection',native_queries=0,core_frontiers=54,per_core_seconds=1,whole_seconds=120,expected_seconds=15,scope='Not an extension/repair/relabeling of old frozen results; independent corrected callback cost comparison. Existing manual already warned about filesystem polling; initial callback was an implementation mistake, not model/OS fault.'),indent=2).encode())
rows=[];start=time.perf_counter()
for oldrow in old['rows']:
 p.stopped();ca={k:oldrow[k]for k in('folder','seed','n')}
 if oldrow['kind']!='ACTUAL_QUERY':rows.append(dict(**ca,kind=oldrow['kind']));continue
 assert time.perf_counter()-start<120
 d=json.loads((P/ca['folder']/'roots'/f"{ca['seed']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);session=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));actor=session.state.position.side_to_move
 ct=time.perf_counter();observed=[];win=None;complete=False
 def checkpoint():
  if time.perf_counter()-ct>=1:raise TimeoutError('Frozen corrected Core1s cap')
 try:
  for ac in a.iter_legal_actions(session.state,c,checkpoint=checkpoint):
   checkpoint();child=a.apply_action(session.state,ac,c);observed.append(dict(action=a.record_value(ac),terminal=a.record_value(child.terminal_status)))
   if child.terminal_status.is_terminal and child.terminal_status.winner==actor:win=a.record_value(ac);break
  else:complete=True
 except TimeoutError:pass
 ck='ONE_STEP_PHYSICAL_WIN'if win is not None else'NO_ONE_STEP_PHYSICAL_WIN'if complete else'UNKNOWN'
 row=dict(**ca,kind='ACTUAL_CORE_FRONTIER',core_kind=ck,core_complete=complete,core_winning_action=win,core_rows=observed,core_seconds=time.perf_counter()-ct,original_native_kind=oldrow['native_kind'],original_core_kind=oldrow['core_kind'],native_receipt_sha256=hashlib.sha256(json.dumps(oldrow['native'],sort_keys=True).encode()).hexdigest());rows.append(row)
 if ck!='UNKNOWN'and oldrow['native_kind']!='UNKNOWN':assert ck==oldrow['native_kind'],ca
a.write_record(P/'playability-core-control.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('CORRECTED_CORE_CLOSED',len(rows),time.perf_counter()-start,flush=True)
