from pathlib import Path
import json,math,random,statistics,collections
P=Path('.local_agent/context-pairs-20261016');F=P/'transfer';d=json.loads((F/'results.json').read_bytes());rr=d['rows'];assert d['complete']and len(rr)==384
assert rr==[json.loads(x)for x in(F/'rows.jsonl').read_text(encoding='utf-8').splitlines()]
out={};rng=random.Random(2026101609)
for n in(4,8,12,16):
 out[n]={}
 for arm in('context','root'):
  pairs=[];wall=collections.Counter();adverse=[];gains=[]
  for seed in sorted(set(r['seed']for r in rr if r['n']==n)):
   ratios=[]
   for order in(0,1):
    a=next(x for x in rr if x['seed']==seed and x['order']==order and x['budget']=='fixed'and x['arm']=='normal')
    b=next(x for x in rr if x['seed']==seed and x['order']==order and x['budget']=='fixed'and x['arm']==arm)
    if a.get('result',{}).get('completed_depth')==b.get('result',{}).get('completed_depth')==4:
     pairs.append(dict(seed=seed,order=order,a=a['seconds'],b=b['seconds'],nodes_a=a['result']['nodes'],nodes_b=b['result']['nodes']));ratios.append(math.log(b['seconds']/a['seconds']))
    wa=next(x for x in rr if x['seed']==seed and x['order']==order and x['budget']=='wall'and x['arm']=='normal')
    wb=next(x for x in rr if x['seed']==seed and x['order']==order and x['budget']=='wall'and x['arm']==arm)
    if 'result'in wa and'result'in wb:
     da=wa['result']['completed_depth'];db=wb['result']['completed_depth'];wall['deeper'if db>da else'shallower'if db<da else'same']+=1;wall['action_changed']+=wa['result']['action']!=wb['result']['action']
   if ratios:
    value=statistics.mean(ratios);gains.append(value)
    if value>0:adverse.append(seed)
  samples=sorted(math.exp(statistics.mean(rng.choices(gains,k=len(gains))))for _ in range(10000))if gains else[]
  out[n][arm]=dict(jointD4_pairs=len(pairs),joint_families=len(gains),geomean_family_caller_ratio=math.exp(statistics.mean(gains))if gains else None,exploratory_family_bootstrap95=[samples[249],samples[9749]]if samples else None,total_caller_ratio=sum(x['b']for x in pairs)/sum(x['a']for x in pairs)if pairs else None,nodes_ratio=sum(x['nodes_b']for x in pairs)/sum(x['nodes_a']for x in pairs)if pairs else None,adverse_families=adverse,wall=dict(wall))
summary=dict(complete=True,planned_slots=384,actual_queries=sum('result'in r for r in rr),missing=[r for r in rr if 'result'not in r],by_board=out,seconds=d['seconds'],max_fixed_caller_overrun=max(r['seconds']-3 for r in rr if r['budget']=='fixed'and'result'in r),max_wall_caller_overrun=max(r['seconds']-1 for r in rr if r['budget']=='wall'and'result'in r),scope='All32newfamilies/2orders; no missing. Completion-conditionedD4 cost, allfixed censors and regressions preserved; ordinary exploratory10000draw cluster bootstrap, no sequentialguarantee. Wall changes not strength; shared host/concurrent finitepanel, timers cooperative.')
(F/'summary.json').write_bytes(json.dumps(summary,indent=2).encode());print(json.dumps(summary))
# All actual key/store/probe helper bytes match the tested candidate source.
s=(P/'context_source/native_module.c').read_text(encoding='utf-8-sig');t=(P/'isolation_source/native_module.c').read_text(encoding='utf-8-sig')
for name,end in[('static void private_context_max','static const uint64_t *private_context_key'),('static const uint64_t *private_context_key','static int gc_semantic_iterative_check_budget'),('static void gc_semantic_tt_store_node','typedef struct {')]:
 a=s[s.index(name):s.index(end,s.index(name)+len(name))];b=t[t.index(name):t.index(end,t.index(name)+len(name))];assert a==b,name
(P/'isolation-helper-binding.json').write_bytes(json.dumps(dict(exact_candidate_helper_bytes=True,functions=['private_context_max','private_context_key','gc_semantic_tt_store_node'],scope='Extra private Pythonmethod wraps actual unchanged candidate helpers and original TT implementation. Controlled synthetic nonterminal payloads validate namespace routing, not independent WDL or full search-loop proof.')).encode())
