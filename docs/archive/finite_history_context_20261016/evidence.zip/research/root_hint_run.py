from pathlib import Path
import sys,json,time,importlib.util,os
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';OLD=R/'.local_agent/tt-demotion-20261016';sys.path[:0]=[str(OLD),str(R)]
import shadow_loader as g
a=g.a;mods={}
for name in ('root',):
 sp=importlib.util.spec_from_file_location(name+'._native_core',P/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);mods[name]=m
rows=[];start=time.perf_counter();j=P/'root-hint-rows.jsonl';j.open('x').close()
for case in [x for x in json.loads((OLD/'prospective/plan.json').read_bytes())['inputs']if x['n']>=12]:
 for order,names in enumerate([['normal','root'],['root','normal']]):
  s,nr,d=g.load(case['seed'])
  for name in names:
   g.p.stopped();assert time.perf_counter()-start<300
   n=nr if name=='normal'else a.nc.compile_native_semantic_rules(s.compiled,backend_module=mods[name])
   e=a.SemanticSearchEngine(s.compiled,n,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=16,ordering_cache_enabled=False)
   t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=4,max_nodes=131072,max_time_seconds=8,quiescence_max_depth=0),root_window_pruning=True)
   row=dict(seed=case['seed'],n=case['n'],order=order,arm=name,result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,n,r),before_sha256=g.p.digest(s));rows.append(row)
   with j.open('a',encoding='utf-8',newline='\n')as f:f.write(json.dumps(row)+'\n');f.flush();os.fsync(f.fileno())
  completed=[x for x in rows[-2:]if x['result']['completed_depth']==4]
  if len(completed)>1:
   for field in ('score','action','principal_variation'):
    assert all(x['result'][field]==completed[0]['result'][field]for x in completed), (case,field)
  print('ROOT_HINT',case,order,[(x['arm'],x['result']['completed_depth'],x['result']['nodes'],round(x['seconds'],3))for x in rows[-2:]],flush=True)
a.write_record(P/'root-hint-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('ROOT_HINT_CLOSED',len(rows),time.perf_counter()-start,flush=True)
