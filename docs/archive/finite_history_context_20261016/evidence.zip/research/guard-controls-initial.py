from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/tt-demotion-20261016')]
import shadow_loader as g
from test_native_q_history_deferral import cycle
a=g.a
sp=importlib.util.spec_from_file_location('guardcheck._native_core',P/'context_native_core.pyd');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
fn=m.semantic_engine_search;raw={}
def cap(*args,**kwargs):
 out=fn(*args,**kwargs);raw.clear();raw.update(out);return out
m.semantic_engine_search=cap
cases=[dict(repetition=rep,prefix=prefix,depth=depth,q=q,tt=tt,exact=exact)for rep,prefix,depth,q,tt,exact in[(4,0,4,0,16,True),(4,8,2,0,16,True),(100,8,4,0,16,True),(4,0,2,1,16,True),(4,0,2,0,0,True),(4,0,2,0,16,False),(10000,512,3,0,16,True)]]
(P/'guard-control-plan.json').write_bytes(json.dumps(dict(question='Do actual guard-active and inactive boundary cases retain native finite authority and complete histories?',cases=cases,queries=14,whole_seconds=120,expected_seconds=20,scope='Existing real cycle fixture; explicit currentthreshold/futuredepth/long512prefix/q/TT/legacy gates; actualcounter distinguishes activation, not generalproof.'),indent=2).encode())
rows=[];start=time.perf_counter()
for case in cases:
 g.p.stopped();assert time.perf_counter()-start<120
 s=cycle(max_ply=1024,repetition=case['repetition'],prefix=case['prefix']);before=g.p.digest(s);rr=[]
 for name in ('normal','context'):
  nr=a.nc.compile_native_semantic_rules(s.compiled,backend_module=g.p.m if name=='normal'else m)
  e=a.SemanticSearchEngine(s.compiled,nr,board_values={'K':0,'F':20,'G':100,'Z':0},hand_values={'K':0,'F':20,'G':100,'Z':0},tt_megabytes=case['tt'],ordering_cache_enabled=False)
  t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=case['depth'],max_nodes=8192,max_time_seconds=5,quiescence_max_depth=case['q']),root_window_pruning=case['exact'])
  rr.append(dict(arm=name,result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r),safe_accesses=int(raw.get('private_safe_accesses',0))if name=='context'else None))
 assert before==g.p.digest(s)
 for field in('score','action','principal_variation','completed_depth','termination_reason'):assert rr[0]['result'][field]==rr[1]['result'][field],(case,field)
 if not case['exact']or case['q']or not case['tt']or(case['repetition']==4 and case['prefix']==8):assert rr[1]['safe_accesses']==0,(case,rr[1]['safe_accesses'])
 else:assert rr[1]['safe_accesses']>0
 rows.append(dict(case=case,rows=rr));print('GUARD',case,rr[1]['safe_accesses'],flush=True)
a.write_record(P/'guard-controls.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start))
