from pathlib import Path
import json,sys,sysconfig,shutil,subprocess,time,hashlib
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016'
base=(R/'generic_chess/_native/native_module.c').read_text(encoding='utf-8-sig')
helper=r"""
static void private_context_max(GCSemanticIterativeContext *ctx,const GCSemanticPosition *p,unsigned ply) {
 if(!ctx->root_window_pruning || ctx->qdepth_limit || !ctx->tt)return;
 if(!p->history_exact || !p->history_events_exact || p->history_len!=p->ply+1 || !p->history_len){ctx->private_max[ply]=UINT16_MAX;return;}
 unsigned m=ply?ctx->private_max[ply-1]:0;
 if(!ply){for(unsigned i=0;i<p->history_len;i++){unsigned n=0;for(unsigned j=0;j<p->history_len;j++)if(!memcmp(p->history_digest[i],p->history_digest[j],32))n++;if(n>m)m=n;}}
 else{unsigned n=0;for(unsigned j=0;j<p->history_len;j++)if(!memcmp(p->history_digest[p->history_len-1],p->history_digest[j],32))n++;if(n>m)m=n;}
 ctx->private_max[ply]=(uint16_t)m;
}
static const uint64_t *private_context_key(GCSemanticIterativeContext *ctx,const GCSemanticPosition *p,unsigned ply,unsigned depth,uint64_t key[4]){
 int safe=ctx->root_window_pruning && !ctx->qdepth_limit && ctx->tt &&
 !ctx->profile.dynamic_supplied && !ctx->profile.spatial_supplied && !ctx->profile.localized_control_supplied &&
 !ctx->learned_move_ordering && !ctx->policy_move_ordering &&
 !ctx->rules->automatic_adjudication_count && p->history_exact && p->history_events_exact &&
 p->history_len==p->ply+1 && ctx->private_max[ply]!=UINT16_MAX &&
 (unsigned)ctx->private_max[ply]+(depth+1)/2<ctx->rules->repetition_limit;
 if(!safe)return ctx->history_context[ply];
 ctx->private_safe_accesses++;
 for(unsigned i=0;i<4;i++)key[i]=PRIVATE_CANONICAL?ctx->private_root_tag[i]:ctx->history_context[ply][i];
 key[0]^=UINT64_C(0x636f6e746578742d);key[1]^=UINT64_C(0x66696e6974652d30);
 key[2]^=depth;key[3]^=((uint64_t)(ctx->root_ply_offset+ply)<<32)^p->history_len;
 return key;
}
"""
for name,canonical in [('gate',0),('context',1)]:
 S=P/(name+'_source');S.mkdir(exist_ok=True)
 for f in (R/'generic_chess/_native').iterdir():
  if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
 s=base.replace('    uint32_t tt_iteration_generation;','    uint16_t private_max[GC_SEM_MAX_PLY+1];\n    uint64_t private_root_tag[4],private_safe_accesses;\n    uint32_t tt_iteration_generation;')
 end=s.index('} GCSemanticIterativeContext;')+len('} GCSemanticIterativeContext;')
 s=s[:end]+'\n#define PRIVATE_CANONICAL '+str(canonical)+'\n'+helper+s[end:]
 mark='    GCSemanticPosition *position = &ctx->stack[ply];'
 idx=s.index(mark,s.index('static int gc_semantic_iterative_negamax('))+len(mark)
 s=s[:idx]+'\n    private_context_max(ctx,position,ply);'+s[idx:]
 # Store and probe only. Never alter full rolling history context used for physical children.
 mark='    uint64_t replaced = 0;\n    if (gc_semantic_tt_store('
 assert s.count(mark)==1
 s=s.replace(mark,'    uint64_t private_key[4];\n    const uint64_t *key=private_context_key(ctx,position,ply,(unsigned)depth,private_key);\n'+mark)
 s=s.replace('ctx->tt, position, ctx->history_context[ply], depth,\n            gc_semantic_score_to_tt','ctx->tt, position, key, depth,\n            gc_semantic_score_to_tt')
 mark='        if (gc_semantic_tt_probe(\n                ctx->tt, position, ctx->history_context[ply], depth,'
 assert s.count(mark)==1
 s=s.replace(mark,'        uint64_t private_key[4];\n        const uint64_t *key=private_context_key(ctx,position,ply,depth,private_key);\n        if (gc_semantic_tt_probe(\n                ctx->tt, position, key, depth,')
 mark='    memcpy(root_context_seed, ctx.history_context[0], sizeof(root_context_seed));'
 assert s.count(mark)==1
 s=s.replace(mark,mark+'\n    memcpy(ctx.private_root_tag,root_context_seed,sizeof(root_context_seed));')
 mark='        gc_semantic_set_u64(out, "ordering_cache_hits", cache_hits) != 0 ||'
 s=s.replace(mark,'        gc_semantic_set_u64(out, "private_safe_accesses", ctx.private_safe_accesses) != 0 ||\n'+mark)
 (S/'native_module.c').write_bytes(s.encode())
 cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in S.glob('*.c')],'-o',str(P/(name+'_native_core.pyd'))]
 t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
 (P/(name+'-build.json')).write_bytes(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,command=cmd,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()}),indent=2).encode())
 print(name,r.returncode,r.stderr[-2000:]);assert r.returncode==0
