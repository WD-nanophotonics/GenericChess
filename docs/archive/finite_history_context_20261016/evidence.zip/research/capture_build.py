from pathlib import Path
import sys,sysconfig,shutil,subprocess,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';S=P/'capture_source';S.mkdir(exist_ok=True)
for f in (R/'.local_agent/tt-demotion-20261016/shadow_source').iterdir():shutil.copyfile(f,S/f.name)
c=S/'native_module.c';s=c.read_text(encoding='utf-8-sig')
s=s.replace('uint8_t occupied, safe;','uint8_t occupied, safe; uint16_t pathlen, maxcount; uint64_t path[8];')
mark='    PrivateShadowEntry *private_shadow;'
s=s.replace(mark,'''    uint64_t capture_path[GC_SEM_MAX_PLY+1];
    struct {uint64_t a[8],b[8];unsigned len,depth,ma,mb;} captures[8];
    unsigned capture_count;
'''+mark)
mark='   if(safe&&e->safe) {if(depth)ctx->shadow_safe_nonleaf++;else ctx->shadow_safe_leaf++;}'
assert s.count(mark)==1
s=s.replace(mark,mark+'''
   if(safe && e->safe && depth && ply<=8 && e->pathlen==ply && ctx->capture_count<8) {
    int duplicate=0;
    for(unsigned k=0;k<ctx->capture_count;k++)
     if(ctx->captures[k].len==ply && !memcmp(ctx->captures[k].a,e->path,ply*8) && !memcmp(ctx->captures[k].b,ctx->capture_path,ply*8))duplicate=1;
    if(!duplicate) {unsigned k=ctx->capture_count++;
     ctx->captures[k].len=ply;ctx->captures[k].depth=depth;
     ctx->captures[k].ma=e->maxcount;ctx->captures[k].mb=ctx->private_max[ply];
     memcpy(ctx->captures[k].a,e->path,ply*8);memcpy(ctx->captures[k].b,ctx->capture_path,ply*8);
    }
   }
''')
mark='  e->history_len=p->history_len;e->depth=(uint16_t)depth;e->occupied=1;e->safe=(uint8_t)safe;'
s=s.replace(mark,mark+'''
  e->pathlen=(uint16_t)ply;e->maxcount=ctx->private_max[ply];
  if(ply<=8)memcpy(e->path,ctx->capture_path,ply*8);
''')
# Only main full checked transition owns these path edges.
mark='        if (deferred_policy) legal_child_index++;'
assert s.count(mark)==1
s=s.replace(mark,'        ctx->capture_path[ply] = action;\n'+mark)
# PyObject construction occurs with GIL after computation; no allocation within traversal.
mark='    PyObject *root_hint_requested = ctx.root_order_hint_present'
idx=s.index(mark)
s=s[:idx]+'''    PyObject *pairs=PyList_New(0);
    if(!pairs) {Py_DECREF(out);out=NULL;goto private_capture_failure;}
    for(unsigned k=0;k<ctx.capture_count;k++){
     PyObject *a=gc_semantic_u64_tuple(ctx.captures[k].a,ctx.captures[k].len);
     PyObject *b=gc_semantic_u64_tuple(ctx.captures[k].b,ctx.captures[k].len);
     PyObject *row=(a&&b)?Py_BuildValue("{s:O,s:O,s:I,s:I,s:I}","a",a,"b",b,"depth",ctx.captures[k].depth,"ma",ctx.captures[k].ma,"mb",ctx.captures[k].mb):NULL;
     Py_XDECREF(a);Py_XDECREF(b);
     if(!row || PyList_Append(pairs,row)<0){Py_XDECREF(row);Py_DECREF(pairs);Py_DECREF(out);out=NULL;goto private_capture_failure;}
     Py_DECREF(row);
    }
    if(PyDict_SetItemString(out,"private_pairs",pairs)<0){Py_DECREF(pairs);Py_DECREF(out);out=NULL;goto private_capture_failure;}
    Py_DECREF(pairs);
'''+s[idx:]
# Reuse normal final cleanup via early helper label? goto at final free before return.
start=s.index('static PyObject *gc_semantic_iterative_search(');end=s.index('static PyObject *gc_semantic_search_runtime_sizes(',start)
part=s[start:end];idx=part.rfind('    free(ctx.private_shadow); free(ctx.stack);')
assert idx>=0
part=part[:idx]+'private_capture_failure:\n'+part[idx:]
s=s[:start]+part+s[end:];c.write_bytes(s.encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in S.glob('*.c')],'-o',str(P/'capture_native_core.pyd')]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
(P/'capture-build.json').write_bytes(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()}),indent=2).encode())
print('BUILD',r.returncode,r.stderr[-3000:]);sys.exit(r.returncode)
