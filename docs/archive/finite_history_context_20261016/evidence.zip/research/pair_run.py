from pathlib import Path
import sys,json,time,collections,os
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';OLD=R/'.local_agent/tt-demotion-20261016';sys.path[:0]=[str(OLD),str(R)]
import shadow_loader as g
from generic_chess.session.serialization import serialize_game_record
from policy_games import physical
a=g.a;start=time.perf_counter();rows=[];journal=P/'pair-rows.jsonl';journal.open('x').close()
data=json.loads((P/'capture-results.json').read_bytes())
selected=[]
for seed in sorted(set(r['seed']for r in data['rows'])):
 seen=set();pairs=[]
 for r in data['rows']:
  if r['seed']!=seed or r['arm']!='capture':continue
  for pair in r['pairs']:
   key=json.dumps([pair['a'],pair['b']])
   if key not in seen:seen.add(key);pairs.append(pair)
 selected.extend((seed,i,pair)for i,pair in enumerate(pairs[:2]))
for seed,i,pair in selected:
 g.p.stopped();assert time.perf_counter()-start<300
 sessions=[];records=[];queries=[]
 for side in ('a','b'):
  s,nr,d=g.load(seed)
  for packed in pair[side]:
   ac=a.sem.public_action(nr,packed);physical(s,nr,ac)
  assert s.result.status.value=='ongoing'
  identities=[str(a.position_identity_key(w,s.compiled))for w in s._search_witnesses]
  ma=max(collections.Counter(identities).values())
  assert ma==pair['m'+side]
  rec=dict(game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),witness_identities=identities,max_multiplicity=ma,physical=a.record_value(s.state.position),terminal=a.record_value(s.result),legal_actions=[a.record_value(x)for x in s.legal_actions()])
  # Two separate fresh native engines: TT0 and TT16. Full histories always packed.
  qr=[]
  for tt in (0,16):
   depth=min(2,pair['depth'])
   e=a.SemanticSearchEngine(s.compiled,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=tt,ordering_cache_enabled=False)
   t=time.perf_counter();result=e.search(s,a.SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=2,quiescence_max_depth=0),root_window_pruning=True)
   qr.append(dict(tt=tt,depth=depth,result=a.record_value(result),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,result)))
  records.append(rec);queries.append(qr);sessions.append(s)
 assert records[0]['physical']==records[1]['physical']
 assert len(records[0]['witness_identities'])==len(records[1]['witness_identities'])
 assert records[0]['witness_identities']!=records[1]['witness_identities']
 assert records[0]['terminal']==records[1]['terminal']
 assert records[0]['legal_actions']==records[1]['legal_actions']
 for qa,qb in zip(*queries):
  for field in ('score','action','principal_variation','completed_depth','termination_reason'):
   assert qa['result'][field]==qb['result'][field],(seed,i,field)
 row=dict(seed=seed,pair_index=i,pair=pair,records=records,queries=queries)
 rows.append(row)
 with journal.open('a',encoding='utf-8',newline='\n')as f:f.write(json.dumps(row)+'\n');f.flush();os.fsync(f.fileno())
 print('PAIRED',seed,i,pair['depth'],len(pair['a']),flush=True)
a.write_record(P/'pair-results.json',dict(complete=True,rows=rows,selected=len(selected),seconds=time.perf_counter()-start))
print('PAIRS_CLOSED',len(rows),time.perf_counter()-start,flush=True)
