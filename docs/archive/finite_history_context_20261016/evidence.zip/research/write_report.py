from pathlib import Path
import json,hashlib
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';D=R/'docs/archive/finite_history_context_20261016';D.mkdir(parents=True,exist_ok=True)
def read(f):return json.loads((P/f).read_bytes())
assert read('finite/summary.json')['net_delta']==-2
assert hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest()=='39230230e1f51e44c158b4bbfebe23e3721211c56e897916a5cfe65d1144fd17'
data=dict(decision='NO_PRODUCT_ADOPTION',source_base='33af504fd03863af0fbbecc54767905b2776c21a',normal_module_sha256='39230230e1f51e44c158b4bbfebe23e3721211c56e897916a5cfe65d1144fd17',paired_histories=dict(selected=22,capture_query_controls=64,captured_pair_receipts=154,selected_continuation_queries=88),context=read('context-summary.json'),prospective=read('transfer/summary.json'),leaf_ablation=read('leaf-summary.json'),finite=read('finite/summary.json'),core=read('core-pair-summary.json'),core_candidate_binding=dict(queries=88,joint_complete=79,censored=9,score_mismatches=0),isolation=dict(cases=30,helper_binding=read('isolation-helper-binding.json')),root_attribution=read('root-attribution-summary.json'),playability=read('playability-summary.json'),scope_corrections=read('receipt-scope-corrections.json'))
(R/'docs/research/data/finite_history_context_20261016.json').write_bytes((json.dumps(data,indent=2)+'\n').encode())
report="""# Finite history contexts, root ordering and sample information

Science is OPEN. Production remains the tested33af504f backend, module SHA256
39230230e1f51e44c158b4bbfebe23e3721211c56e897916a5cfe65d1144fd17.
**No TT/key/q/default/API/evaluation/price/UI change is adopted.** Prepared
counter-free C/test proposals are unadopted provenance, not pending consent
or a recovery task.

## Decision and changed premise

Earlier shadow counts suggested reuse but saved no real paired histories or
work. Actual pairs now qualify a private guarded-context experiment. It improves
local completed-objective costs, yet the fresh finite panel gives no adoption
case. More hits or depth is insufficient. Root-order-only and leaf-only routes
also remain private. Current next research is sample information per TOTAL cost,
before any NEW conditional-root protocol. No old root/result is removed.
The complete generated-rule target, including promotion/drop/aux/history, remains.

## Actual histories, guard and independent scope

ALL16exposed wide inputs receive64 normal/capture controls with equal non-time
results. Capture derives from the previous shadow source; normal equivalence
is executed.154paired-path receipts span repeated orders. First two distinct
pairs per available family give22pairs from11of16roots;5roots retain zero
selected pairs. Both full root+action records reconstruct identical physical
states/absolute history lengths and different ordered histories.88fresh TT0/16
D1 continuations agree, not a general equivalence theorem.

The private key requires exact-root q0/static evaluation, no automatic path
rule, coherent full history and M+ceil(D/2)<R. Digest includes side-to-move,
which flips each physical edge, so a fixed digest can appear at most
ceil(D/2) additional times within D edges. The strict bound excludes repetition
through that finite horizon. Declarations/max-ply still use full state/absolute
ply. Terminal authority precedes probing; stores AND probes use the same gate;
exact remaining depth is required. Receiving PVs replay on receiving histories.

Full root salt, physical digest, absolute ply, history length and depth remain
key inputs. Different imported root histories cannot borrow. Memory remains
16MiB requested/11MiB actual, no extra score bank. Generated cohorts initially
have empty aux; tested scope is not all rule/model/state combinations.

88all-Core AlphaBeta D1/D2 objectives are executed with full legal transitions,
no TT/order/Native legality.79jointly complete with matching normalized Native
scores;9Core censors stay. Separate88private-candidate calls match those79
complete Core scores. Shared Core/compiler/host limit independence; action ties
are not value errors.

## Actual advisor contribution and routing control

Dot1792108316.561119 read public33af source, not the private patch, and did not
execute the studies. Its useful objection was write/read eligibility isolation:
an ineligible writer must not leak a repetition-sensitive value to an eligible
reader. PRIMARY adopted this concrete check, not a proof/approval framework.

30actual controls invoke byte-identical candidate key/store helpers and original
TT code, both directions and EXACT/LOWER/UPPER. Real common-root histories have
multiplicities3/2 atR4,4/3 at a repetition-terminal D0 boundary, and4/2 atR5.
Threshold-equality cases isolate; eligible D0 sharing is positively checked.
Synthetic nonterminal payloads test routing, not WDL truth. Real terminal
classification/score remains. All30pass; no test-only API is shipped.

14repaired guard controls include q/TT/legacy fallbacks and real512-ply history.
An initial assertion confused nonleaf ineligibility with legal D0 sharing.
Its4actual query dictionaries were not saved before failure: explicitly missing,
not replayed or counted. Source/failure observations remain, no guard/cap change.

## Controlled and fresh transfer costs

96three-arm calls compare product, gate/full-path depth-tag control and context.
All32same-retained-horizon groups preserve score/action/full PV. JointD4
context/product caller ratios are.850/.796 on12/16boards; context/gate
.862/.788. Completion-conditioned costs are not all-root speedups.

NEW before-input32families give ALL384slots, no missing roots. Static profiles,
full histories and TT resources match. Two orders repeat8families per size.

| Board | Context total caller ratio, jointD4 | Family geometric ratio / exploratory95% interval | Wall greater/same/smaller depth |
|---|---:|---|---|
|4|.916|.915 / [.878,.953]|8/6/2|
|8|.932|.939 / [.864,1.007]|5/11/0|
|12|.900|.864 / [.759,.965]|3/13/0|
|16|.911|.892 / [.814,.983]|2/14/0|

The16board cost interval has only3joint-D4 families. All censors/adverse cases
remain. Four wall-action changes are two repeated families, not strength.
Max fixed/wall caller-over-cap .016442/.013880s means cooperative timers,
not hard deadlines. Ordinary exploratory cluster bootstrap gives no sequential/
population guarantee. Concurrent finite-panel load is an interpretation limit,
not a reason to demand an exclusive machine.

## Fresh finite decisions: no adoption

Before inputs/labels,24families/72game slots were frozen. Two families terminate
before target walk, leaving6missing slots without replacement. ALL66actual
games/2517edges close within original3300s cap, reported batch2456.962s, no
caller refusal. Opponent is fixed normal; static rule prices unchanged.
Separate persistent TT pergame/actor,64ply horizon,1s caller/.05s reserve/
1Mnodes and all original caps remain.

| Paired actor observations | WIN | LOSS | DRAW | UNKNOWN |
|---|---:|---:|---:|---:|
|Normal|14|14|0|20|
|Context|14|16|1|17|

48planned role observations cluster by24families, including4missing role
observations. UNKNOWN is zero only in the declared finite W-L statistic, never
draw or invented outcome. **Net-2/48; family interval[-.145833,.0625].**
This fails to establish benefit, not proof of universal harm. Transitions:
3UNKNOWN-to-LOSS,2UNKNOWN-to-WIN,1LOSS-to-WIN,1WIN-to-DRAW,2WIN-to-UNKNOWN.
Cost alone does not justify activation.

22control games cost836.772s;44candidate-role games1574.001s: unequal game
counts/paths. Candidate-actor775.569s versus825.169s control-actor call time is
trajectory cost, not a matched kernel ratio. Batch includes earlier recording/
initialization but excludes finalsummary write/input preparation/publication.
The Agent segment includes additional work. No Elo/learning/all-defense claim.

All48first-divergence contrasts:28identical full paths,16first action differences,
4missing. Fourteen differences start candidate-side,2at the nominally fixed
opponent's timed path.32literal diagnostics yield30complete no-one-ply-win
frontiers/2UNKNOWN, not deeper safety or identical-continuation causality.

## Alternatives and primitive cost

Root-only ordering reuses a probed same-full-root TT action, preserving canonical
tie/PV authority.64exposed controls plus fresh384panel find mixed effects:
one12board family gains D4, one16board family loses it. Conditional16board
cost has only2families and cannot hide that loss. No adoption.

32additional existing-raw-counter calls cover ALL16wide roots. Seed9518 spends
131072visits in both arms, but root ordering makes31698versus2729legal generations,
3versus0required tie refinements, caller ratio2.028. Seed9512 has29120versus3775
generations and ratio1.830. Association is not isolated timing causality, but
equal visits clearly do not mean equal primitive work. Correctness stays.

192exposed leaf-only ablation calls remove M scanning/nonleaf sharing. Caller
ratios1.003/.998/.991/.995, small-board nodes exactly unchanged. It is not a
useful replacement here; combined design ablation does not prove every saving
is exclusively caused by nonleaf reuse.

18real cycle controls at history0/128/512 preserve D16 objectives/408visits.
At512 context~12.17ms versus normal~10.51ms; root similar to normal. Retain the
~15%synthetic long-history regression.

## Next-step pilot and correction

ALL56existing planned roots:54actual/2tails. Existing Native explicit physical
one-step goal completes54D1queries:4wins/50without. This is not WDL or a deployed
filter. Native caller total.242096s excludes engine construction, compile and
root replay. Integrated filter cost is still unmeasured; full pilot pays Core too.

The initial Core hot callback wrongly reread disk stop flags despite existing
manual guidance, giving25UNKNOWN. Original data/1s caps remain. A NEW same-cap
deadline-only Core control checks stops between roots, with zero repeated
Native queries:48decidable matches/6UNKNOWN. Core totals17.247s versus34.817s.
Runs are noninterleaved with changed load; do not attribute the entire timing
difference to the callback. This corrected implementation mistake is not an
OS/approval issue or a hidden blocker.

Before NEW raw/conditional-mu sampling freeze seeds/attempts/cost, charge
generation/compile/predicate/recording and retain failures. Do not assume
filtering improves information per total cost: trivial roots mainly consume
sample quota, not compute. Current generator/default/data remain unchanged.

## Literature, reproduction and collaboration limits

[Kishimoto and Mueller, AAAI2004](https://cdn.aaai.org/AAAI/2004/AAAI04-102.pdf)
distinguish path-specific solved results/verification from unresolved heuristic
values. Their guarantee does not certify our finite cache; ordering precedent
also does not establish local utility. No general twin/proof framework is added.

Each private candidate passes98relevant tests, including legacy/semantic scopes,
not98all-domain guard activations or a new product fullsuite. Context retains
a small diagnostic counter despite inherited runner text saying counter-free;
raw data/errata preserve this. The unadopted proposal removes it/adds explicit
model fallback. Prior2691-test production acceptance is not claimed rerun here.
Prescribed publisher fresh relevant checks are separate.

Main search-disabled replay verifies3733query receipts/13203PVedges,
66games/2517edges,154paired receipts/888path edges,16658full-state/history
comparisons and30routing receipts. Its76loaded-base-state digests are not all
distinct query histories. Ten fixture roots were reconstructed from pinned
unchanged source/parameters, not historical snapshots. Late literal and actual
extracted-source replay receipts are separate. SameCore/compiler/host, not
independent WDL or new search/game/proof.

PRIMARY owns experiments/analysis. Dot's source-read/reasoning and PRIMARY's
execution are distinct; original legacy root payload binding remains unverified.
AUX66fixed6c9533a stays report-read-only: no final solver/learning source/tests/
games/proofs executed/adopted here. No cross-checkout writes, duplicate solver,
extra Agent/worker/fee, visibility/default/UI change or routine acknowledgement.

[Summary data](data/finite_history_context_20261016.json) and
[full archive](../archive/finite_history_context_20261016/README.md) retain
plans/inputs/results/failures and actual prototype sources.
"""
(R/'docs/research/FINITE_HISTORY_CONTEXT_AND_ROOT_ORDER_20261016.md').write_bytes(report.encode())
main=R/'docs/research/LOCAL_MAINLINE.md';s=main.read_text(encoding='utf-8-sig')
start=s.index('Current next question is whether the unchanged fullpath TT misses useful finite')
end=s.index('16normal/reconstruction-counter calls all non-time fields match:',start)
replacement="""Current finite-context result:22actual paired histories/64capture controls
qualify testing the former shadow opportunity. Guarded q0/static/noautomatic
reuse preserves completed objectives in96three-arm calls,384fresh slots,
79joint Core objectives and30actual write/probe namespace controls. Local
completed-D4 cost improves, but72frozen game slots (66actual/2517edges,2tail
families) give14W16L1D17UNKNOWN versus14W14L20UNKNOWN: net-2/48, family interval
crosses0. NO production TT/key/q/default/price/API/UI change. Prepared C/tests
are historical unadopted provenance, not missing consent or recovery tasks.
No unchanged retry solely for more hits/depth.

Root ordering has adverse16board completion/cost;32raw-counter calls show up
to~11.6x legal generation at equal131072visits. Canonical tie/PV authority stays.
192leaf-only calls give essentially no useful savings, also not adopted.
Full findings: FINITE_HISTORY_CONTEXT_AND_ROOT_ORDER_20261016.md. Old demotion
task is closed; frozen evidence and search-first selection remain. AUX66fixed
6c9533a is REPORT_READ_ONLY, no final solver/learning execution/adoption.

Current next question: can simple root playability improve information per
TOTAL cost under an explicitly changed sampling distribution? ALL56existing
planned roots retain54actual/2tails; Native physical-one-step goal finds4wins/
50without, .242s query caller excluding compile/engine/rootreplay. Corrected
same1s Core control has48decidable matches/6UNKNOWN; original hot-loop disk
polling mistake/censors remain. No filter deployed or oldroot relabeled.
Before NEW conditional-mu sampling freeze raw/conditional protocols, attempts/
seeds/cost, keep complete promotion/drop/aux/history and failures. Trivial-root
quota is not automatically a compute bottleneck or a ban on unrestrictedmu.
Begin a small charged raw-versus-conditional generator feasibility comparison;
only a changed premise justifies another cache/price route. Science is OPEN.

"""
main.write_bytes((s[:start]+replacement+s[end:]).encode())
log=R/'docs/operations/COLLABORATION_LOG.md';s=log.read_text(encoding='utf-8-sig')
s+="""\n## PRIMARY finite contexts, root order and sample information —2026-10-16\n\nPRIMARY captured real ordered-history pairs and ran96three-arm/384prospective/\n192leaf-ablation calls plus72frozen game slots (66actualgames). Finite values\nagree/local costs improve, but W-L net-2/48/interval crossing0 does not justify\nactivation. Product33af/39230230 remains; proposed C/test files are unadopted\narchive evidence, not pending consent. Root-order regressions expose unequal\nprimitive generation work at equal visits, with canonical tie/PV checks retained.\n\nActual coordination: unique followupPRIMARY-CONTEXT-GUARD-20261016 sent\n1792108196.701309 in existing thread. Dot1792108316.561119 read public33af,\nnot private patch or studies. Its writer/reader eligibility objection was adopted\nand tested by30actual same-helper TT controls, bothdirections/allbounds/terminalD0.\nThis is Dot source reasoning plus PRIMARY execution, not independent execution\nor publication approval. No routine acknowledgement/self-reply. Legacy original\npayload binding stays unverified; delivery does not prove reading/execution.\n\nAUX66fixed6c9533a remains report-read-only from the preceding checkpoint; no\nfinal solver/learning source/tests/games/proofs executed/adopted here. No branch\nwrites, duplicate solver/training, extra Agent/worker/fees, imported2hour authority\nor visibility/default/UI change. Ordinary parallel work is normal.\n\nCorrections/limits: initial aggregate guard-counter assertion missed safeD0;\n4full query dicts missing/disclosed,14repairs retained. Initial playability Core\ncallback polled disk in hotloop despite manual. Originals/caps remain; new samecap\ndeadline-only Core control improves coverage without Native rerun; noninterleaved\nload limits timing causality. Next raw/conditional sampling must charge actual\nattempts/compile/predicate before filter selection. No proof/diagnostics framework.\n\nDetailed results/source/failures: FINITE_HISTORY_CONTEXT_AND_ROOT_ORDER_20261016.md.\nPrescribed publisher/fullSHA/public anonymous/source-copy receipts are separate\ndelivery evidence, never collaborator-execution claims.\n"""
log.write_bytes(s.encode())
(P/'preparation-failure.json').write_bytes(json.dumps(dict(error='Initial report-writer orchestration JavaScript parse error due to literal Markdown backticks in template string',effects='No script executed, no files/data/protocol changed',resolution='Prepared report text without template delimiters and reran successfully')).encode())
print('Report/data/mainline/collaboration saved; product unchanged')
