from pathlib import Path
import json,sys,sysconfig,shutil,subprocess,time,hashlib
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';S=P/'leaf_source';S.mkdir(exist_ok=True)
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
s=(S/'native_module.c').read_text(encoding='utf-8-sig')
s=s.replace('    uint32_t tt_iteration_generation;','    uint8_t private_leaf_eligible[GC_SEM_MAX_PLY+1];\n    uint64_t private_root_tag[4];\n    uint32_t tt_iteration_generation;')
helper=r"""
static const uint64_t *private_leaf_key(GCSemanticIterativeContext *ctx,const GCSemanticPosition *p,unsigned ply,unsigned depth,uint64_t key[4]){
 if(depth || !ctx->private_leaf_eligible[ply])return ctx->history_context[ply];
 memcpy(key,ctx->private_root_tag,32);
 key[0]^=UINT64_C(0x7374617469632d30);key[1]^=UINT64_C(0x6c6561662d6f6e6c);
 key[2]^=p->history_len;key[3]^=ctx->root_ply_offset+ply;
 return key;
}
"""
end=s.index('} GCSemanticIterativeContext;')+len('} GCSemanticIterativeContext;')
s=s[:end]+'\n'+helper+s[end:]
mark='    GCSemanticPosition *position = &ctx->stack[ply];'
idx=s.index(mark,s.index('static int gc_semantic_iterative_negamax('))+len(mark)
s=s[:idx]+'\n    ctx->private_leaf_eligible[ply]=0;'+s[idx:]
mark='    if (ctx->tt != NULL && !pv_replay) {'
idx=s.index(mark,s.index('static int gc_semantic_iterative_negamax('))
s=s[:idx]+'''    /* Only after full terminal and winning-declaration authority. Nonterminal
       static q0 leaf value depends on current complete state, not old path.
       Terminal/declaration stores retain the original full-history namespace. */
    ctx->private_leaf_eligible[ply]=depth==0 && ctx->root_window_pruning &&
        !ctx->qdepth_limit && !ctx->rules->automatic_adjudication_count &&
        !ctx->profile.dynamic_supplied && !ctx->profile.spatial_supplied &&
        !ctx->profile.localized_control_supplied && !ctx->profile.compact_supplied &&
        !ctx->profile.policy_supplied && !ctx->learned_move_ordering &&
        !ctx->policy_move_ordering;
'''+s[idx:]
mark='    uint64_t replaced = 0;\n    if (gc_semantic_tt_store('
s=s.replace(mark,'    uint64_t private_key[4];\n    const uint64_t *key=private_leaf_key(ctx,position,ply,(unsigned)depth,private_key);\n'+mark)
s=s.replace('ctx->tt, position, ctx->history_context[ply], depth,\n            gc_semantic_score_to_tt','ctx->tt, position, key, depth,\n            gc_semantic_score_to_tt')
mark='        if (gc_semantic_tt_probe(\n                ctx->tt, position, ctx->history_context[ply], depth,'
s=s.replace(mark,'        uint64_t private_key[4];\n        const uint64_t *key=private_leaf_key(ctx,position,ply,depth,private_key);\n        if (gc_semantic_tt_probe(\n                ctx->tt, position, key, depth,')
mark='    memcpy(root_context_seed, ctx.history_context[0], sizeof(root_context_seed));'
s=s.replace(mark,mark+'\n    memcpy(ctx.private_root_tag,root_context_seed,sizeof(root_context_seed));')
(S/'native_module.c').write_bytes(s.encode())
plan=dict(question='Does nonleaf cross-history reuse add useful work savings beyond static-leaf-only sharing after authoritative terminal/declaration checks?',changed_premise='Context improves localcost but real512history adds15percent guardcost; captured safe leaf opportunities greatly outnumber nonleaf. Simpler root ordering has regressions. A leaf-only ablation can avoid multiplicity scanning and any future-history equivalence premise.',inputs='All32 transfer roots NOW EXPOSED by closed384query study; not new validation',arms=['normal','context','leaf'],orders=[['normal','context','leaf'],['leaf','context','normal']],queries=192,depth=4,nodes=131072,seconds=3,whole_seconds=600,expected_seconds=200,scope='PRIVATE samebudget q0static-only, full terminal and winningdeclaration checked BEFORE eligibleflag/probe. Terminal/declaration stores originalnamespace; only nonterminalD0static plus state-onlyneutralfloor canonicalized, root/fullH/absoluteply fixed. No nonleafscore sharing/M scan, no AUXsolver/defaultchange.',decision='Any shared finitehorizon score/action/fullPV mismatch stops. If leaf retains benefit atlowercost, prefer simpler route; no more games merely for extra hits.')
(P/'leaf-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in S.glob('*.c')],'-o',str(P/'leaf_native_core.pyd')]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
(P/'leaf-build.json').write_bytes(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()}),indent=2).encode());print('LEAF_BUILD',r.returncode,r.stderr[-2000:]);assert not r.returncode
