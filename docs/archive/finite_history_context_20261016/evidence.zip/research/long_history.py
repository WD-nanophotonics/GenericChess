from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/tt-demotion-20261016')]
import shadow_loader as g
from test_native_q_history_deferral import cycle
a=g.a;mods={}
for name in('context','root'):
 sp=importlib.util.spec_from_file_location('long_'+name+'._native_core',P/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);mods[name]=m
(P/'long-history-plan.json').write_bytes(json.dumps(dict(question='Does the context bound introduce a serious whole-history guard cost on a real coherent512-ply static cycle, compared with root ordering?',prefixes=[0,128,512],orders=[['normal','context','root'],['root','context','normal']],queries=18,depth=16,nodes=65536,seconds=2,whole_seconds=120,expected_seconds=20,repetition_limit=10000,scope='One exposed synthetic single-action semantic cycle at3histories, not generatedfamily/population. Actualfull history and paid native import retained; fullroot replay/init excluded from percall but whole includes. No WDL/strength.'),indent=2).encode())
rows=[];start=time.perf_counter()
for prefix in(0,128,512):
 s=cycle(max_ply=1024,repetition=10000,prefix=prefix);before=g.p.digest(s)
 for order,names in enumerate([['normal','context','root'],['root','context','normal']]):
  cur=[]
  for name in names:
   g.p.stopped();assert time.perf_counter()-start<120
   nr=a.nc.compile_native_semantic_rules(s.compiled,backend_module=g.p.m if name=='normal'else mods[name])
   e=a.SemanticSearchEngine(s.compiled,nr,board_values={'K':0,'F':20,'G':100,'Z':0},hand_values={'K':0,'F':20,'G':100,'Z':0},tt_megabytes=16,ordering_cache_enabled=False)
   t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=16,max_nodes=65536,max_time_seconds=2,quiescence_max_depth=0),root_window_pruning=True)
   row=dict(prefix=prefix,order=order,arm=name,result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r),root_restored=before==g.p.digest(s));rows.append(row);cur.append(row)
  for f in('score','action','principal_variation','completed_depth'):assert all(r['result'][f]==cur[0]['result'][f]for r in cur),f
  print('LONG',prefix,order,[(r['arm'],r['result']['nodes'],r['seconds'])for r in cur],flush=True)
a.write_record(P/'long-history-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start))
