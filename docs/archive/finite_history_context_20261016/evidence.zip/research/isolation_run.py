from pathlib import Path
import sys,json,time,importlib.util,collections
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/tt-demotion-20261016')]
import shadow_loader as g
from conftest import make_ruleset
from generic_chess.core.pieces import PieceType
from generic_chess.core.movement import LeapAtom
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
from policy_games import physical
a=g.a;sp=importlib.util.spec_from_file_location('isolation._native_core',P/'isolation_native_core.pyd');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
cases=[dict(R=4,H=8,D=1,cross=False),dict(R=4,H=8,D=0,cross=True),dict(R=4,H=12,D=0,cross=False),dict(R=5,H=14,D=2,cross=False),dict(R=5,H=14,D=3,cross=False)]
(P/'isolation-plan.json').write_bytes(json.dumps(dict(question='Does actual guarded-key write/read namespace isolation hold in both directions, including equal-threshold boundary, D0/terminal stores and all TT bound classes?',cases=cases,bounds=['EXACT','LOWER','UPPER'],directions=[0,1],operations=30,whole_seconds=120,expected_seconds=10,scope='Real legal common-root histories reconstructed Core/Native. Exact candidate key/store/probe helper bytes; synthetic nonterminal bound payloads to isolate routing, actual terminal classification/score. No new games/solver/proof or candidate source change.'),indent=2).encode())
short=[((0,1),(0,2)),((3,2),(3,1)),((0,2),(0,1)),((3,1),(3,2))]
long=[((0,1),(1,1)),((3,2),(3,1)),((1,1),(1,2)),((3,1),(3,2)),((1,2),(0,2)),((3,2),(3,1)),((0,2),(0,1)),((3,1),(3,2))]
cache={};inputs=[];rows=[];start=time.perf_counter()
for ca in cases:
 g.p.stopped();assert time.perf_counter()-start<120
 key=(ca['R'],ca['H'])
 if key not in cache:
  k=PieceType('K','K',(),is_anchor=True);f=PieceType('F','F',tuple(LeapAtom(v)for v in[(0,1),(0,-1),(1,0),(-1,0)]));gg=PieceType('G','G',(LeapAtom((0,1)),LeapAtom((0,-1))));z=PieceType('Z','Z',())
  zero=(False,)*16;rule=make_ruleset(4,[k,f,gg,z],['Z..k','...g','F...','K..z'],drop_all={'F':zero,'G':zero,'Z':zero},max_ply=512,repetition_limit=ca['R'])
  raw=a.p.compile_legacy_ruleset_for_semantic_execution(rule);c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=a.nc.compile_native_semantic_rules(c,backend_module=m);root=a.GameSession(c);rootcaps=a.pack_semantic_search_position(c,nr,root)
  pa=(short*4)[:ca['H']];pb=long+short if ca['H']==12 else(long*2)[:ca['H']]
  recs=[];caps=[]
  for path in(pa,pb):
   session=a.GameSession(c);actions=[]
   for src,dst in path:
    ac=next(ac for ac in session.legal_actions()if getattr(ac,'from_square',None)and(ac.from_square.file,ac.from_square.rank)==src and(ac.to_square.file,ac.to_square.rank)==dst)
    actions.append(a.record_value(ac));physical(session,nr,ac)
   ids=[str(a.position_identity_key(w,c))for w in session._search_witnesses]
   recs.append(dict(game_record=json.loads(serialize_game_record(session.to_record())),state=a.record_value(session.state),path=actions,max_multiplicity=max(collections.Counter(ids).values()),physical=a.record_value(session.state.position),terminal=a.record_value(session.result)))
   caps.append(a.pack_semantic_search_position(c,nr,session))
  assert recs[0]['physical']==recs[1]['physical']
  assert recs[0]['state']['history']!=recs[1]['state']['history'] or recs[0]['game_record']!=recs[1]['game_record']
  inputs.append(dict(repetition=ca['R'],H=ca['H'],ruleset=json.loads(serialize_ruleset(rule)),records=recs))
  cache[key]=(nr,rootcaps,caps,recs)
 nr,rootcaps,caps,recs=cache[key]
 eligibility=[r['max_multiplicity']+(ca['D']+1)//2<ca['R']for r in recs]
 for bound in(1,2,3):
  for reverse in(0,1):
   out=m.private_isolation(nr.capsule,rootcaps,*caps,ca['D'],bound,reverse)
   row=dict(case=ca,bound=bound,reverse=reverse,eligibility=eligibility,result=out);rows.append(row)
   assert out['own_hit']==1 and out['own_score']==out['stored_score']and out['stored_bound']==bound and out['stored_depth']==ca['D'],row
   assert bool(out['cross_hit'])==ca['cross']==bool(out['same_key']),row
   if ca['cross']:assert out['cross_depth']==ca['D']
   assert out['ma']==recs[0]['max_multiplicity']and out['mb']==recs[1]['max_multiplicity']
 print('ISOLATION',ca,eligibility,[r['max_multiplicity']for r in recs],flush=True)
a.write_record(P/'isolation-results.json',dict(complete=True,inputs=inputs,rows=rows,seconds=time.perf_counter()-start));print('ISOLATION_CLOSED',len(rows),time.perf_counter()-start,flush=True)
