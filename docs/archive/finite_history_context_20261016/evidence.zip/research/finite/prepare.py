from pathlib import Path
import sys,json,random,time,hashlib
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016/finite';OLD=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(OLD)]
import probe as p
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
a=p.a;plan=json.loads((P/'plan.json').read_bytes());D=P/'inputs';D.mkdir(exist_ok=True);roots=P/'roots';roots.mkdir(exist_ok=True);start=time.perf_counter();manifest=[]
for case in plan['inputs']:
 p.stopped();t=time.perf_counter();seed=case['seed'];row=dict(**case,root=None,walk=[],terminal_tail=None)
 try:
  g=generate_game(GeneratorConfig(seed=seed,board_size=case['n'],**plan['generator']));row['ruleset']=json.loads(serialize_ruleset(g.ruleset));raw=a.p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession(c);rng=random.Random(seed+plan['walk_rng_offset'])
  for ply in range(plan['walk']+1):
   p.stopped()
   if s.result.status.value!='ongoing':row['terminal_tail']=dict(ply=ply,state=a.record_value(s.state));break
   if ply==plan['walk']:row['root']=dict(ply=ply,state=a.record_value(s.state),walk=row['walk'].copy());break
   ac=rng.choice(sorted(s.legal_actions(),key=repr));s.submit(ac);row['walk'].append(a.record_value(ac))
  row['state']='INPUT_FROZEN_NO_SEARCH'
  if row['root']:
   profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig())
   a.write_record(roots/f'{seed}.json',dict(ruleset=row['ruleset'],game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s),board_values={t:int(round(v))for t,v in profile.board_value_by_type.items()},hand_values={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()}))
 except Exception as e:row.update(state='INPUT_FAILURE',error=repr(e))
 row['seconds']=time.perf_counter()-t;a.write_record(D/f'{seed}.json',row);manifest.append(dict(seed=seed,n=case['n'],has_root=row['root']is not None,state=row['state'],sha256=hashlib.sha256((D/f'{seed}.json').read_bytes()).hexdigest()));print(case,row['state'],row['root']is not None,flush=True)
a.write_record(P/'input-manifest.json',dict(complete=True,inputs=manifest,search_queries=0,seconds=time.perf_counter()-start,plan_sha256=hashlib.sha256((P/'plan.json').read_bytes()).hexdigest()))
