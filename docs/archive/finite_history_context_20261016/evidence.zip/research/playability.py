from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a
cases=[dict(folder=folder,**ca)for folder in('finite','transfer')for ca in json.loads((P/folder/'plan.json').read_bytes())['inputs']]
(P/'playability-plan.json').write_bytes(json.dumps(dict(question='Would an existing cheap physical-one-step-win predicate improve sample quota per total cost before a future conditional-root protocol?',changed_premise='Context cost savings did not improve fresh finite outcomes; several unrestricted roots remain immediate wins, so diagnose information yield before another micro-optimization. Prior rootquota diagnosis was not a compute bottleneck or existingfilterapproval.',cases=cases,native_queries=54,planned_roots=56,depth=1,nodes=65536,native_seconds=.25,core_seconds=1,whole_seconds=240,expected_seconds=45,scope='ALLexisting now-exposed24finite+32transfer families incl2actualterminaltails; unchanged generator/prices/fullhistory. Native uses existing explicit physical-root-win goal, Core literal frontier checked independently. Keep censors UNKNOWN, not draw/no-win. No old root removal or new generatorfilter/default yet. Conditionalmu would be a NEW future protocol, not a shrunk generic task.'),indent=2).encode())
rows=[];start=time.perf_counter();checks=0
for ca in cases:
 p.stopped();root=P/ca['folder']/'roots'/f"{ca['seed']}.json"
 if not root.exists():rows.append(dict(**ca,kind='ORIGINAL_TERMINAL_TAIL_MISSING'));continue
 if time.perf_counter()-start>=240:rows.append(dict(**ca,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
 d=json.loads(root.read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);session=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=a.nc.compile_native_semantic_rules(c);e=a.SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False)
 before=p.digest(session);t=time.perf_counter();r=e.search(session,a.SearchLimits(max_depth=1,max_nodes=65536,max_time_seconds=.25,quiescence_max_depth=0),root_window_pruning=True,stop_on_immediate_win=True);native_seconds=time.perf_counter()-t
 nk='ONE_STEP_PHYSICAL_WIN'if r.immediate_win and r.result_source=='verified_root_child'else'NO_ONE_STEP_PHYSICAL_WIN'if r.completed_depth==1 else'UNKNOWN'
 actor=session.state.position.side_to_move;observed=[];win=None;complete=False;ct=time.perf_counter()
 def checkpoint():
  p.stopped()
  if time.perf_counter()-ct>=1:raise TimeoutError('Frozen Core literal frontier cap1s')
 try:
  for ac in a.iter_legal_actions(session.state,c,checkpoint=checkpoint):
   checkpoint();child=a.apply_action(session.state,ac,c);observed.append(dict(action=a.record_value(ac),terminal=a.record_value(child.terminal_status)))
   if child.terminal_status.is_terminal and child.terminal_status.winner==actor:win=a.record_value(ac);break
  else:complete=True
 except TimeoutError:pass
 ck='ONE_STEP_PHYSICAL_WIN'if win is not None else'NO_ONE_STEP_PHYSICAL_WIN'if complete else'UNKNOWN'
 row=dict(**ca,kind='ACTUAL_QUERY',native=a.record_value(r),native_kind=nk,native_seconds=native_seconds,core_kind=ck,core_complete=complete,core_winning_action=win,core_rows=observed,core_seconds=time.perf_counter()-ct,pv_edges=a.audit(session,nr,r),root_restored=before==p.digest(session))
 rows.append(row);assert row['root_restored']
 if nk!='UNKNOWN'and ck!='UNKNOWN':assert nk==ck,ca;checks+=1
 print('PLAYABILITY',ca,nk,ck,len(observed),flush=True)
a.write_record(P/'playability-results.json',dict(complete=True,rows=rows,matched_decisions=checks,seconds=time.perf_counter()-start));print('PLAYABILITY_CLOSED',len(rows),checks,time.perf_counter()-start,flush=True)
