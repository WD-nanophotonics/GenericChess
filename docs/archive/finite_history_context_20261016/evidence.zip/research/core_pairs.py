from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/tt-demotion-20261016')]
import shadow_loader as g
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
a=g.a
class Material:
 def __init__(self,bv,hv):self.bv=bv;self.hv=hv
 def evaluate(self,s):
  side=s.position.side_to_move
  return sum((1 if x.owner==side else -1)*self.bv[x.current_type_id]for x in s.position.board if x is not None)+sum((1 if owner==side else -1)*self.hv[t]*n for owner,hand in enumerate(s.position.hands)for t,n in hand.items())
 def type_value(self,t):return self.bv[t]
 def capture_order_value(self,m,c):return 10*self.bv[c.current_type_id]-self.bv[m.current_type_id]
pairs=json.loads((P/'pair-results.json').read_bytes())['rows'];rows=[];start=time.perf_counter()
(P/'core-pair-plan.json').write_bytes(json.dumps(dict(question='Do actual paired full-history nodes independently preserve small finite q0 scores under existing all-Core AlphaBeta?',pairs=22,depths=[1,2],histories=['a','b'],max_queries=176,core_seconds=2,native_seconds=2,nodes=8192,whole_seconds=300,expected_seconds=160,scope='Existing Core AlphaBeta/noTT/noordering/noNativelegality; fixed actual material values, no newsolver. Keep censors and action ties; shared rulecompiler/host, not all-domain/WDL.'),indent=2).encode())
journal=P/'core-pair-rows.jsonl';journal.open('x').close()
for pair in pairs:
 seed=pair['seed'];base,nr,d=g.load(seed)
 for side,rec in zip(('a','b'),pair['records']):
  for depth in(1,2):
   g.p.stopped()
   if time.perf_counter()-start>=300:
    rows.append(dict(seed=seed,pair_index=pair['pair_index'],side=side,depth=depth,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN'));continue
   state=a.GameSession.replay(base.compiled,deserialize_game_record(json.dumps(rec['game_record'])));before=g.p.digest(state)
   t=time.perf_counter()
   r=AlphaBetaPlayer(state.compiled,evaluator_override=Material(d['board_values'],d['hand_values']),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(state,a.SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0))
   coretime=time.perf_counter()-t;assert before==g.p.digest(state)
   t=time.perf_counter()
   n=a.SemanticSearchEngine(state.compiled,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=0,ordering_cache_enabled=False).search(state,a.SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=2,quiescence_max_depth=0),root_window_pruning=True)
   joint=r.completed_depth==n.completed_depth==depth
   norm=n.score if abs(n.score)<50000000 else(1 if n.score>0 else-1)*(1000000000-(100000000-abs(n.score)))
   row=dict(seed=seed,pair_index=pair['pair_index'],side=side,depth=depth,core=a.record_value(r),native=a.record_value(n),core_seconds=coretime,native_seconds=time.perf_counter()-t,joint_complete=joint,normalized_score_equal=r.score==norm if joint else None,root_restored=before==g.p.digest(state),pv_edges=a.audit(state,nr,n),kind='ACTUAL_QUERY')
   rows.append(row)
   with journal.open('a',encoding='utf-8',newline='\n')as f:f.write(json.dumps(row)+'\n')
   assert not joint or r.score==norm,(seed,side,depth,r.score,n.score)
 print('CORE_PAIR',seed,pair['pair_index'],sum(x.get('joint_complete',False)for x in rows),flush=True)
a.write_record(P/'core-pair-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('CORE_CLOSED',len(rows),sum(r.get('joint_complete',False)for r in rows),time.perf_counter()-start,flush=True)
