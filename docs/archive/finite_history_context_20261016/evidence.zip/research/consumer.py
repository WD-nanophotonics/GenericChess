"""Search-disabled full-state/history consumer for this frozen research segment."""
from pathlib import Path
import sys,json,time,hashlib,collections
R=Path.cwd();sys.path.insert(0,str(R));B=Path(sys.argv[1])if len(sys.argv)>1 else R/'.local_agent/context-pairs-20261016'
phase=sys.argv[2]if len(sys.argv)>2 else'all'
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.ir import CompiledSemanticRuleset
class Adapter(CompiledSemanticRuleset):
 __slots__=()
 def __getattr__(self,name):return getattr(self._legacy_compiled,name)
 @property
 def semantic(self):return self
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import iter_legal_actions
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine,_module
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from scripts.research_record import record_value
assert Path(nc.__file__).resolve().is_relative_to(R.resolve())
assert Path(_module().__file__).resolve().is_relative_to(R.resolve())
def forbidden(*args,**kwargs):raise AssertionError('No new search/game/proof in receipt replay')
SemanticSearchEngine.search=forbidden;_module().semantic_engine_search=forbidden;AlphaBetaPlayer.choose_action=forbidden
def read(p):return json.loads((B/p).read_bytes())
def action(d):
 if d is None:return None
 if not d:return PassAction()
 if'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def digest(st):return hashlib.sha256(json.dumps(record_value(st),sort_keys=True).encode()).hexdigest()
counts=collections.Counter();cache={};roots=set()
def compiled(d):
 raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])))
 c=Adapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);return c,nc.compile_native_semantic_rules(c)
def load(folder,seed):
 k=(folder,seed)
 if k not in cache:
  d=read(folder+'/'+str(seed)+'.json');c,nr=compiled(d);cache[k]=(d,c,nr)
 d,c,nr=cache[k];s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])))
 assert digest(s.state)==d['before_sha256'];roots.add(digest(s.state));return s,nr,d
def compare(s,nr,state,np,w):
 snap=sem.snapshot(nr,np);exp=expected_snapshot(state.position,nr,s.compiled)
 for k in('board','hands','aux_state','side'):assert record_value(snap[k])==record_value(exp[k])
 assert snap['ply']==state.ply_count
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(v,s.compiled))for v in w]
 assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
 assert snap['history_exact']and snap['history_events_exact']
 counts['state_history_comparisons']+=1
def query(s,nr,r,limit):
 assert r['nodes']+r['qnodes']<=limit
 chosen=action(r['action']);assert chosen is None or chosen in s.legal_actions()
 state=s.state;np=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses)
 line=[action(x)for x in r['principal_variation']]
 if line:assert line[0]==chosen
 if not line and chosen is not None:line=[chosen]
 for ac in line:
  np=sem.make_checked(nr,np,pack_semantic_action(nr,state.position,ac));state=apply_action(state,ac,s.compiled);w.append(state.position);compare(s,nr,state,np,w);counts['pv_edges']+=1
 counts['query_receipts']+=1
def actual_path(s,nr,packed_path):
 path=[]
 for packed in packed_path:
  ac=sem.public_action(nr,packed);np=pack_semantic_search_position(s.compiled,nr,s);np=sem.make_checked(nr,np,packed);s.submit(ac);compare(s,nr,s.state,np,list(s._search_witnesses));path.append(record_value(ac));counts['captured_path_edges']+=1
 return path
start=time.perf_counter()
cap=read('capture-results.json');assert cap['complete']and len(cap['rows'])==64
assert cap['rows']==[json.loads(x)for x in(B/'capture-rows.jsonl').read_text(encoding='utf-8').splitlines()]
for row in cap['rows']:
 s,nr,d=load('capture_roots',row['seed']);query(s,nr,row['result'],32768)
 for pair in row.get('pairs',[]):
  sessions=[]
  for side in('a','b'):
   ss=GameSession.replay(s.compiled,deserialize_game_record(json.dumps(d['game_record'])));actual_path(ss,nr,pair[side]);sessions.append(ss)
  assert record_value(sessions[0].state.position)==record_value(sessions[1].state.position)
  assert len(sessions[0]._search_witnesses)==len(sessions[1]._search_witnesses)
  assert [position_identity_key(w,s.compiled)for w in sessions[0]._search_witnesses]!=[position_identity_key(w,s.compiled)for w in sessions[1]._search_witnesses]
  counts['captured_pair_receipts']+=1
pairdata=read('pair-results.json');assert pairdata['complete']and len(pairdata['rows'])==22
for row in pairdata['rows']:
 for rec,queries in zip(row['records'],row['queries']):
  base,nr,d=load('capture_roots',row['seed']);s=GameSession.replay(base.compiled,deserialize_game_record(json.dumps(rec['game_record'])))
  assert record_value(s.state)==rec['state']and record_value(s.state.position)==rec['physical']
  compare(s,nr,s.state,pack_semantic_search_position(s.compiled,nr,s),list(s._search_witnesses))
  assert[record_value(x)for x in s.legal_actions()]==rec['legal_actions']
  for q in queries:query(s,nr,q['result'],8192)
for filename,limit in[('context-results.json',131072),('root-hint-results.json',131072),('leaf-results.json',131072)]:
 data=read(filename);assert data['complete']
 journal={'context-results.json':'context-rows.jsonl','root-hint-results.json':'root-hint-rows.jsonl','leaf-results.json':'leaf-rows.jsonl'}[filename]
 assert data['rows']==[json.loads(x)for x in(B/journal).read_text(encoding='utf-8').splitlines()]
 for row in data['rows']:
  if'result'not in row:continue
  folder='transfer/roots'if filename=='leaf-results.json'else'capture_roots';s,nr,d=load(folder,row['seed']);query(s,nr,row['result'],limit)
for filename in('core-pair-results.json','core-context-results.json'):
 data=read(filename);assert data['complete']
 for row in data['rows']:
  pair=next(x for x in pairdata['rows']if x['seed']==row['seed']and x['pair_index']==row['pair_index'])
  rec=pair['records'][0 if row['side']=='a'else 1];base,nr,d=load('capture_roots',row['seed']);s=GameSession.replay(base.compiled,deserialize_game_record(json.dumps(rec['game_record'])))
  for field in('core','native')if filename=='core-pair-results.json'else('candidate',):
   query(s,nr,row[field],8192);counts['core_receipts']+=field=='core'
data=read('transfer/results.json');assert data['complete']and len(data['rows'])==384
assert data['rows']==[json.loads(x)for x in(B/'transfer/rows.jsonl').read_text(encoding='utf-8').splitlines()]
for row in data['rows']:
 if'result'not in row:continue
 s,nr,d=load('transfer/roots',row['seed']);query(s,nr,row['result'],131072 if row['budget']=='fixed'else 1000000)
data=read('root-attribution-results.json');assert data['complete']and len(data['rows'])==32
for row in data['rows']:
 s,nr,d=load('capture_roots',row['seed']);query(s,nr,row['result'],131072)
for i,row in enumerate(read('guard-controls.json')['rows']):
 s,nr,d=load('fixture_roots','guard-'+str(i))
 for q in row['rows']:query(s,nr,q['result'],8192)
for row in read('long-history-results.json')['rows']:
 s,nr,d=load('fixture_roots','long-'+str(row['prefix']));query(s,nr,row['result'],65536)
data=read('isolation-results.json');assert data['complete']and len(data['rows'])==30
for d in data['inputs']:
 c,nr=compiled(d)
 for rec in d['records']:
  s=GameSession.replay(c,deserialize_game_record(json.dumps(rec['game_record'])));assert record_value(s.state)==rec['state']
  compare(s,nr,s.state,pack_semantic_search_position(c,nr,s),list(s._search_witnesses));counts['isolation_histories']+=1
for row in data['rows']:
 r=row['result'];assert r['own_hit']==1 and r['own_score']==r['stored_score']and r['stored_bound']==row['bound']
 assert bool(r['cross_hit'])==bool(r['same_key'])==row['case']['cross'];counts['isolation_receipts']+=1
if phase=='all':
 done=read('finite/completion.json');assert done['complete']and len(done['games'])==72
 for game in done['games']:
  if'result'not in game:counts['missing_game_slots']+=1;continue
  s,nr,d=load('finite/roots',game['seed']);base='finite/game-'+str(game['seed'])+'-'+game['mode'];g=read(base+'.json');assert g['complete']
  assert g['rows']==[json.loads(x)for x in(B/(base+'.jsonl')).read_text(encoding='utf-8').splitlines()]
  for row in g['rows']:
   assert digest(s.state)==row['before_sha256']and row['actor']==s.state.position.side_to_move
   owner='B'if game['mode']!='A_control'and row['actor']==int(game['mode'][-1])else'A'
   assert row['owner']==owner and row['tt_megabytes']==16
   for ph in row['phases']:
    query(s,nr,ph['result'],1000000);assert ph['q']==0 and row['selected']==ph['result']
    assert row['total_nodes']==ph['used_total_nodes']==ph['result']['nodes']+ph['result']['qnodes']
    assert ph['result']['tt_allocated_bytes']==11534336
   if'action'not in row:assert not row['execution_allowed'];counts['refusals']+=1;continue
   assert row['execution_allowed']and not row['cancelled']and row['caller_seconds']<1 and row['action']==row['selected']['action']
   ac=action(row['action']);np=pack_semantic_search_position(s.compiled,nr,s);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));s.submit(ac);compare(s,nr,s.state,np,list(s._search_witnesses));counts['physical_edges']+=1
   assert digest(s.state)==row['after_sha256']and record_value(s.result)==row['actual_terminal']
  assert record_value(s.state)==g['state']and record_value(s.result)==g['result'];counts['physical_games']+=1
out=dict(complete=True,phase=phase,fixture_inputs_reconstructed_from_pinned_parameters=True,counts=dict(counts),unique_loaded_base_states=len(roots),seconds=time.perf_counter()-start,scope='Search-disabled exact full Core/normalNative state/history receipt replay, all actual PV/action fields retained; no new study search/game/proof or private-image execution. SameCore/compiler/host, not independent WDL.')
(B/('consumer-'+phase+'.json')).write_bytes(json.dumps(out,indent=2).encode());print('CONSUMER_PASS',out,flush=True)
