"""Late finite-divergence and playability receipt consumer; no search."""
from pathlib import Path
import sys,json,time,hashlib
B=Path(sys.argv[1])if len(sys.argv)>1 else Path('.local_agent/context-pairs-20261016')
source=(B/'consumer.py').read_text(encoding='utf-8-sig')
exec(compile(source[:source.index('start=time.perf_counter()')],str(B/'consumer.py'),'exec'),globals())
start=time.perf_counter()
d=read('finite/divergence-results.json');assert d['complete']and len(d['rows'])==48;seen=set()
for row in d['rows']:
 if row['kind']!='FIRST_ACTION_DIFFERENCE':continue
 s,nr,root=load('finite/divergence-roots',row['root_id'])
 for act,key in zip(row['actions'],row['diagnostic_keys']):
  if key in seen:continue
  seen.add(key);ac=action(act);child=apply_action(s.state,ac,s.compiled);np=pack_semantic_search_position(s.compiled,nr,s);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));w=list(s._search_witnesses)+[child.position];compare(s,nr,child,np,w);counts['diagnostic_choices']+=1
  diag=d['diagnostics'][key];observed=[]
  for r in diag.get('rows',[]):
   reply=action(r['action']);after=apply_action(child,reply,s.compiled);assert record_value(after.terminal_status)==r['terminal'];observed.append(reply);counts['diagnostic_literal_replies']+=1
  if diag.get('complete'):assert set(observed)==set(iter_legal_actions(child,s.compiled))
old=read('playability-results.json');corrected=read('playability-core-control.json');assert old['complete']and corrected['complete']
for row in old['rows']:
 if row['kind']!='ACTUAL_QUERY':continue
 s,nr,d=load(row['folder']+'/roots',row['seed']);query(s,nr,row['native'],65536);actor=s.state.position.side_to_move
 if row['native_kind']=='ONE_STEP_PHYSICAL_WIN':
  child=apply_action(s.state,action(row['native']['action']),s.compiled)
  assert child.terminal_status.is_terminal and child.terminal_status.winner==actor
 elif row['native_kind']=='NO_ONE_STEP_PHYSICAL_WIN':assert row['native']['completed_depth']==1
 for frontier in(row,next(x for x in corrected['rows']if x['folder']==row['folder']and x['seed']==row['seed'])):
  observed=[]
  for r in frontier['core_rows']:
   ac=action(r['action']);child=apply_action(s.state,ac,s.compiled);np=pack_semantic_search_position(s.compiled,nr,s);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));compare(s,nr,child,np,list(s._search_witnesses)+[child.position])
   assert record_value(child.terminal_status)==r['terminal'];observed.append(ac);counts['playability_literal_replies']+=1
  if frontier['core_complete']:assert set(observed)==set(iter_legal_actions(s.state,s.compiled))
  if frontier['core_winning_action']is not None:
   child=apply_action(s.state,action(frontier['core_winning_action']),s.compiled);assert child.terminal_status.winner==actor and child.terminal_status.is_terminal
  counts['literal_frontier_receipts']+=1
out=dict(complete=True,counts=dict(counts),seconds=time.perf_counter()-start,scope='Search-disabled replay of all48finite contrasts/32diagnosticchoices plus54Native one-step receipts and both54Corefrontiers; incomplete frontiers retain UNKNOWN. No new studysearch/game/proof. SameCore/compiler/host, no historical clock or independentWDL recreation.')
(B/'consumer-addon.json').write_bytes(json.dumps(out,indent=2).encode());print('ADDON_PASS',out,flush=True)
