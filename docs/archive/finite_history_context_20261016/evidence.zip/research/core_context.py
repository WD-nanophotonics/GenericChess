from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/tt-demotion-20261016')]
import shadow_loader as g
from generic_chess.session.serialization import deserialize_game_record
a=g.a
sp=importlib.util.spec_from_file_location('corebinding._native_core',P/'context_native_core.pyd');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
(P/'core-context-plan.json').write_bytes(json.dumps(dict(question='Does the actual context prototype bind to the already-paid Core finite objectives, rather than only normal Native?',queries=88,seconds=2,nodes=8192,whole_seconds=180,expected_seconds=40,scope='All existing44pairhistory states atD1/D2, same fullrecords/values. No new Core queries/solver/labels; retained-depth censors explicit.'),indent=2).encode())
pairs=json.loads((P/'pair-results.json').read_bytes())['rows'];cores=json.loads((P/'core-pair-results.json').read_bytes())['rows'];rows=[];start=time.perf_counter()
for cr in cores:
 g.p.stopped();assert time.perf_counter()-start<180
 seed=cr['seed'];pair=next(x for x in pairs if x['seed']==seed and x['pair_index']==cr['pair_index']);rec=pair['records'][0 if cr['side']=='a'else 1];base,nr,d=g.load(seed)
 s=a.GameSession.replay(base.compiled,deserialize_game_record(json.dumps(rec['game_record'])));nr=a.nc.compile_native_semantic_rules(s.compiled,backend_module=m);t=time.perf_counter()
 r=a.SemanticSearchEngine(s.compiled,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=16,ordering_cache_enabled=False).search(s,a.SearchLimits(max_depth=cr['depth'],max_nodes=8192,max_time_seconds=2,quiescence_max_depth=0),root_window_pruning=True)
 joint=r.completed_depth==cr['core']['completed_depth']==cr['depth'];norm=r.score if abs(r.score)<50000000 else(1 if r.score>0 else-1)*(1000000000-(100000000-abs(r.score)))
 row=dict(seed=seed,pair_index=cr['pair_index'],side=cr['side'],depth=cr['depth'],candidate=a.record_value(r),core_reference_index=cores.index(cr),joint_complete=joint,score_equal=norm==cr['core']['score']if joint else None,seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r));rows.append(row)
 assert not joint or row['score_equal'],row
a.write_record(P/'core-context-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('CORE_CONTEXT',len(rows),sum(x['joint_complete']for x in rows),time.perf_counter()-start,flush=True)
