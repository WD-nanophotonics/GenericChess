from pathlib import Path
import sys,json,hashlib,zipfile,subprocess,re
R=Path.cwd();P=R/'.local_agent/context-pairs-20261016';D=R/'docs/archive/finite_history_context_20261016';D.mkdir(parents=True,exist_ok=True)
assert json.loads((P/'consumer-all.json').read_bytes())['counts']['query_receipts']==3733
assert json.loads((P/'consumer-addon.json').read_bytes())['counts']['query_receipts']==54
assert json.loads((P/'proposal-scope.json').read_bytes())['state']=='NOT_ADOPTED'
for name in('context','root','leaf'):assert json.loads((P/(name+'-tests.json')).read_bytes())['returncode']==0
files={};originals={}
def add(name,data):
 originals[name]=hashlib.sha256(data).hexdigest();text=data.decode('utf-8-sig')
 for value,label in[(str(R),'<PROJECT>'),(str(Path.home()),'<USER>')]:
  for old in(value,value.replace('\\','/'),json.dumps(value)[1:-1]):text=text.replace(old,label)
 text=text.replace('pytest-of-'+Path.home().name,'pytest-of-USER')
 files[name]=text.replace('\r\n','\n').encode()
def scientific(f):
 return f.suffix in('.json','.jsonl','.py','.c','.patch')and not any(x in f.name for x in('-private','-partial','recovery','guard-thread','question-','segment-quality','outgoing','publication-verified'))
for f in sorted(P.iterdir()):
 if f.is_file()and(scientific(f)or f.name=='primary-literature.txt'):
  folder='unadopted/'if f.name.startswith('proposed-')or f.name=='proposal-scope.json'else'research/'
  add(folder+f.name,f.read_bytes())
for folder in('finite','transfer','capture_roots','fixture_roots'):
 for f in sorted((P/folder).rglob('*')):
  if f.is_file()and'__pycache__'not in f.parts and scientific(f):add('research/'+f.relative_to(P).as_posix(),f.read_bytes())
for folder in('baseline_source','capture_source','gate_source','context_source','root_hint_source','leaf_source','isolation_source'):
 for f in sorted((P/folder).iterdir()):
  if f.suffix in('.c','.h'):add('variants/'+folder+'/'+f.name,f.read_bytes())
for rel in subprocess.check_output(['git','ls-files','generic_chess','scripts'],text=True).splitlines():
 if Path(rel).suffix in('.py','.c','.h'):add('source/'+rel,(R/rel).read_bytes())
for rel in('pyproject.toml','tests/product/test_native_q_history_deferral.py','tests/product/test_native_pending_continuation.py','tests/conftest.py'):
 add('source/'+rel,(R/rel).read_bytes())
for f in R.glob('LICENSE*'):
 if f.is_file():add('source/'+f.name,f.read_bytes())
add('research/producer-dependencies.json',json.dumps(dict(prior_fixed_sha='33af504fd03863af0fbbecc54767905b2776c21a',prior_capsule='docs/archive/tt_demotion_20261016/evidence.zip',prior_capsule_sha256='d41c60f59e241da7342e4629acb68d7211f3f62ab0679cd6ae869a874d506a95',scope='Original producer helpers refer to prior frozen private recipes; provenance, not automatic campaign replay. Current source/research consumers are self-contained and actually restored. Private Native images/proposed code are not rebuilt or activated by receipt consumers.'),indent=2).encode())
for name,data in files.items():
 text=data.decode()
 assert not re.search(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',text),(name,'email')
 assert not re.search(r'\bsk-[A-Za-z0-9]{24,}|\bxox[bp]-[A-Za-z0-9-]{12,}|\bghp_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}',text),(name,'credential')
 for sep in('/',chr(92),chr(92)*2):assert 'Users'+sep+Path.home().name not in text,(name,'privatepath')
assert not(D/'evidence.zip').exists(),'Never overwrite sealed evidence'
with zipfile.ZipFile(D/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert z.testzip()is None
 for name,data in files.items():assert z.read(name)==data
manifest=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),normal_module_sha256=hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),archive_sha256=hashlib.sha256((D/'evidence.zip').read_bytes()).hexdigest(),archive_bytes=(D/'evidence.zip').stat().st_size,member_count=len(files),members=[dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),original_sha256=originals[name])for name,data in sorted(files.items())],scope='All retained scientific plans/inputs/outputs/failures and seven actual Native source variants; full normal source. Public copies sanitize host paths/newlines only; original/public SHA separate. No binary/rawSlack/account/credential/pytest-temp/transport records. Unadopted proposals are historical, not recovery tasks. Final report/source-copy/session/delivery receipts outside immutable ZIP.')
(D/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
readme="""# Finite history context evidence —2026-10-16

Science OPEN; NO production adoption. Normal Native source remains39230230
from PUBLIC33af504f. Context local cost improved but fresh66games/72slots
gave finite net-2/48, family interval crossing0. Root/leaf alternatives also
not adopted. Unadopted C/test proposals are historical provenance, not pending
permission, a publication gate or instructions to apply after compaction.

The immutable ZIP contains full normal source, seven executed Native variant
source trees, all retained plans/inputs/results/failures and standalone receipt
consumers. Four initial guard-call dictionaries are explicitly missing, not
invented. Exact private originals remain local; public copies sanitize only
host paths/newlines. Manifest distinguishes original and publication hashes.
Raw Slack/account/credential records, binaries and temporary test trees excluded.

Original campaign producers use helpers from fixed previous33af504f capsule;
producer-dependencies.json pins it. They are provenance, not an automatic
rerun of games/search/proof/training. Current consumers are self-contained.

For receipt replay extract to an owned directory, build source/generic_chess
Native with the supported scripts/build_native_zig.py and current Python/Zig.
From extracted source run Python without site packages:
python -S ../research/consumer.py ../research all
python -S ../research/addon_consumer.py ../research

Both scripts explicitly forbid new search. They verify full physical states,
aux/hands/ply, ordered SHA digest+actor/check histories, PVs/decisions and
literal frontiers. This does not rerun timed search/private images/games,
authenticate historical clocks or establish independent WDL. Same host/Core/
compiler remains an independence limit. Ten fixed fixture roots were reconstructed
from unchanged source/parameters, not captured historic snapshots.
The base-root count is not the number of all distinct query histories.

Actual extracted-source build/replay receipt is publication-replay.json outside
the sealed ZIP. Detailed conclusions/costs/limitations are in
../../research/FINITE_HISTORY_CONTEXT_AND_ROOT_ORDER_20261016.md.
"""
(D/'README.md').write_bytes(readme.encode());print('SEALED',manifest['member_count'],manifest['archive_bytes'],manifest['archive_sha256'],flush=True)
