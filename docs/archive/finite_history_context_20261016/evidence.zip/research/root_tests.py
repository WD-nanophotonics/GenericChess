from pathlib import Path
import sys,importlib.util,json,time,subprocess
R=Path.cwd();P=R/".local_agent/context-pairs-20261016"
targets=["tests/product/test_native_repetition_context.py","tests/product/test_native_history.py","tests/product/test_native_q_history_deferral.py","tests/product/test_h50b2e_semantic_search_engine.py","tests/product/test_native_semantic_qsearch.py","tests/product/test_native_terminal_declaration_priority.py","tests/product/test_native_explicit_semantic_backend.py","tests/product/test_runtime_aux_identity.py","tests/product/test_native_pending_continuation.py","tests/product/test_native_pv_replay_boundaries.py","tests/product/test_native_main_order_pv_witness.py","tests/product/test_native_cancellation.py"]
sys.path.insert(0,str(R))
if len(sys.argv)>1 and sys.argv[1]=="child":
 import generic_chess.native as native
 spec=importlib.util.spec_from_file_location("qualified._native_core",P/"root_native_core.pyd");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
 import pytest
 sys.exit(pytest.main(["-q","-p","no:cacheprovider","--basetemp="+str(P/"pytest-root"),*targets]))
t=time.perf_counter();r=subprocess.run([sys.executable,str(Path(__file__).resolve()),"child"],capture_output=True,text=True,timeout=240)
(P/"root-tests.json").write_text(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,targets=targets,scope="Private counter-free module injected only in this isolated test process; normal installed binary unchanged; not full suite/private product adoption."),indent=2),encoding="utf-8");print(r.stdout);print(r.stderr);sys.exit(r.returncode)
