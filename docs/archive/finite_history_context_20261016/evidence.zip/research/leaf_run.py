from pathlib import Path
import sys,json,time,importlib.util,os
R=Path.cwd();F=R/'.local_agent/context-pairs-20261016/transfer';P=F.parent;sys.path[:0]=[str(R),str(R/'.local_agent/residual-q4-20261016')]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;mods={}
for name in('context','leaf'):
 sp=importlib.util.spec_from_file_location('transfer_'+name+'._native_core',P/(name+'_native_core.pyd'));m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);mods[name]=m
plan=json.loads((F/'plan.json').read_bytes());plan.update(orders=[['normal','context','leaf'],['leaf','context','normal']],budgets=['fixed'],whole_seconds=600);rows=[];start=time.perf_counter();journal=P/'leaf-rows.jsonl';journal.open('x').close()
for case in plan['inputs']:
 root=F/'roots'/f"{case['seed']}.json"
 if root.exists():
  d=json.loads(root.read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nrs={'normal':a.nc.compile_native_semantic_rules(c,backend_module=p.m),**{name:a.nc.compile_native_semantic_rules(c,backend_module=m)for name,m in mods.items()}}
 for order,names in enumerate(plan['orders']):
  for budget in plan['budgets']:
   current=[]
   for name in names:
    p.stopped()
    if not root.exists():row=dict(**case,order=order,budget=budget,arm=name,kind='MISSING_ROOT_UNKNOWN')
    elif time.perf_counter()-start>=plan['whole_seconds']:row=dict(**case,order=order,budget=budget,arm=name,kind='WHOLE_CAP_NOT_STARTED_UNKNOWN')
    else:
     nr=nrs[name];before=p.digest(s);t=time.perf_counter()
     e=a.SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=16,ordering_cache_enabled=False)
     r=e.search(s,a.SearchLimits(max_depth=plan['fixed_depth']if budget=='fixed'else plan['wall_depth'],max_nodes=plan['fixed_nodes']if budget=='fixed'else plan['wall_nodes'],max_time_seconds=plan['fixed_seconds']if budget=='fixed'else plan['wall_seconds'],quiescence_max_depth=0),root_window_pruning=True)
     seconds=time.perf_counter()-t
     row=dict(**case,order=order,budget=budget,arm=name,kind='ACTUAL_QUERY',result=a.record_value(r),seconds=seconds,pv_edges=a.audit(s,nr,r),root_restored=before==p.digest(s))
     assert row['root_restored']
    rows.append(row);current.append(row)
    with journal.open('a',encoding='utf-8',newline='\n')as f:f.write(json.dumps(row)+'\n');f.flush();os.fsync(f.fileno())
   rr=[r for r in current if'result'in r]
   for depth in set(r['result']['completed_depth']for r in rr):
    same=[r for r in rr if r['result']['completed_depth']==depth]
    for field in('score','action','principal_variation'):
     assert all(r['result'][field]==same[0]['result'][field]for r in same),(case,budget,depth,field)
  print('LEAF_ABLATION',case,order,[(x['budget'],x['arm'],x.get('result',{}).get('completed_depth'))for x in rows[-6:]],flush=True)
a.write_record(P/'leaf-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print('LEAF_CLOSED',len(rows),time.perf_counter()-start,flush=True)
