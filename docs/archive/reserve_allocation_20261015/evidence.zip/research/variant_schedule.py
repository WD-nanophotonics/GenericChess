from allocation import *
def schedule_variant(s,nr,bv,hv,mode,budget,*,token=None,clock=time.perf_counter,after_phase=None,engine_factory=SemanticSearchEngine,phase_results=None,variant="reserve"):
 token=token if token is not None else CancellationToken();start=clock();deadline=start+budget;phases=[];selected=None;source=None;used=0
 for i,q in enumerate([0,4]if mode=='reserve'else[4]if mode=='q4'else[0]):
  if token.is_cancelled() or clock()>=deadline:break
  phase_start=clock();engine=engine_factory(s.compiled,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
  remaining=deadline-clock()-plan['delivery_margin_seconds'];allowance=min(remaining,plan['reserve_seconds']-(clock()-phase_start))if mode=='reserve'and i==0 else remaining
  if allowance<=0:break
  res=engine.search(s,SearchLimits(max_depth=(2 if variant=='cap2' and mode=='reserve' and i==0 else plan['depth']),max_nodes=max(0,plan['nodes']-used),max_time_seconds=allowance,quiescence_max_depth=q,quiescence_hard_max_depth=plan['hard_q']),cancel_token=token,root_order_hint=(selected.action if variant=='hint'and i==1 and eligible(selected,0)else None),root_window_pruning=True,stop_on_immediate_win=True)
  used+=res.nodes
  if phase_results is not None:phase_results.append(res)
  row=dict(q=q,result=record_value(res),phase_seconds=clock()-phase_start,requested_kernel_seconds=allowance,remaining_after=deadline-clock(),eligible=eligible(res,q));phases.append(row)
  if after_phase is not None:after_phase(i,res,token)
  # Preserve evidence even after cancellation, but never authorize execution.
  if res.immediate_win and res.result_source=='verified_root_child':selected=res;source='physical_win';break
  if mode!='reserve':selected=res;source=mode
  elif i==0:selected=res;source='disabled_reserve' if eligible(res,0) else 'disabled_fallback'
  elif eligible(res,4):selected=res;source='requested_q4'
  if token.is_cancelled() or clock()>=deadline:break
 wall=clock()-start
 return dict(mode=mode,budget=budget,phases=phases,selected=None if selected is None else record_value(selected),selected_source=source,caller_seconds=wall,overrun_seconds=max(0,wall-budget),cancelled=token.is_cancelled(),execution_allowed=selected is not None and selected.action is not None and not token.is_cancelled() and clock()<deadline,total_nodes=used),selected
