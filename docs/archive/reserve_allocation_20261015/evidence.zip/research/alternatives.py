from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()/'.local_agent/reserve-allocation-20261015'))
import allocation as a
from variant_schedule import schedule_variant
from scripts.research_record import write_record,record_value
progress=json.loads((a.B/'transfer-progress.json').read_bytes());assert progress['complete']
summary=json.loads((a.B/'transfer-summary.json').read_bytes());assert summary['complete']
plan=json.loads((a.B/'alternative-plan.json').read_bytes());tp=json.loads((a.B/'transfer-plan.json').read_bytes());pairs=[p for p in summary['pairs']if p['order']==0];cases=[dict(seed=4323,ply=12,budget=1,selection='predeclared literal-loss case')]
for label,predicate in [('requested_displacement',lambda p:p['q4_requested']and not p['reserve_requested']and not p['reserve_physical']),('completed_policy_action_difference',lambda p:not p['same_action']and p['q4_requested']and p['reserve_requested'])]:
 for p in pairs:
  if predicate(p)and(p['seed'],p['ply'])not in[(x['seed'],x['ply'])for x in cases]:cases.append(dict(seed=p['seed'],ply=p['ply'],budget=p['budget'],selection=label));break
assert len(cases)<=3
write_record(a.B/'alternative-selection.json',dict(cases=cases,rule=plan['selection']));m=a.backend();start=time.perf_counter();rows=[];diags={}
for ci,case in enumerate(cases):
 family=next(f for f in tp['cases']if f['seed']==case['seed']);root=next(r for r in family['roots']if r['ply']==case['ply']);s,nr,bv,hv=a.load(dict(seed=case['seed'],root=root),m)
 for order,variants in enumerate(plan['orders']):
  for variant in variants:
   a.p.rr.stopped();assert time.perf_counter()-start<plan['batch_seconds'];phases=[];t=time.perf_counter();row,res=schedule_variant(s,nr,bv,hv,'q4'if variant=='q4'else'reserve',case['budget'],phase_results=phases,variant=variant);row['outer_caller_seconds']=time.perf_counter()-t;row['outer_delivery_allowed']=row['execution_allowed']and row['outer_caller_seconds']<case['budget'];row.update(case=ci,seed=case['seed'],ply=case['ply'],order=order,variant=variant);row['pv_edges_checked']=sum(a.audit(s,nr,r)for r in phases);key=str(ci)+':'+repr(res.action)
   if key not in diags:diags[key]=a.diagnosis(s,res.action)
   row['diagnostic_key']=key;rows.append(row);write_record(a.B/'alternatives.json',dict(complete=False,cases=cases,rows=rows,diagnostics=diags,seconds=time.perf_counter()-start));print(ci,variant,res.completed_depth,res.result_ordinary_qdepth,row['selected_source'],round(row['outer_caller_seconds'],4),diags[key]['kind'],flush=True)
write_record(a.B/'alternatives.json',dict(complete=True,cases=cases,rows=rows,diagnostics=diags,seconds=time.perf_counter()-start));print('ALTERNATIVES_DONE',len(rows),time.perf_counter()-start,flush=True)
