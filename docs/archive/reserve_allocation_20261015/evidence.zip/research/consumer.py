"""Search-disabled consumer of saved allocations, not a timing or strength rerun."""
from pathlib import Path
import sys,json,time,hashlib,importlib.util
R=Path.cwd();sys.path.insert(0,str(R));B=Path(sys.argv[1])if len(sys.argv)>1 else R/'.local_agent/reserve-allocation-20261015';O=R/'.local_agent/admission-reuse-20261015'
INPUTS=Path(sys.argv[3]) if len(sys.argv)>3 else O/'transfer-inputs'
from scripts import full_q_refresh_comparison as p
if len(sys.argv)>2:p.rr.ROOT=Path(sys.argv[2])
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action

def action(d):
 if d is None:return None
 if not d:return PassAction()
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def no_search(*args,**kwargs):raise AssertionError('search disabled in consumer')
SemanticSearchEngine.search=no_search
# Use normal independently rebuilt product, never producer-owned binary.
start=time.perf_counter();plan=json.loads((B/'transfer-plan.json').read_bytes());edges=0;phases=0;roots=0;tails=0;choices=0;diagnosed=0
datasets=[]
for f in plan['cases']:
 x=json.loads((INPUTS/f"{f['seed']}.json").read_bytes());rec=json.loads((B/f"transfer-{f['seed']}.json").read_bytes());datasets.append((f,rec,x['ruleset'],'paid'))
if (B/'fresh-go.json').exists()and json.loads((B/'fresh-go.json').read_bytes())['go']:
 for f in json.loads((B/'fresh-plan.json').read_bytes())['inputs']:
  rec=json.loads((B/f"fresh-{f['seed']}.json").read_bytes());datasets.append((dict(seed=f['seed'],roots=rec['roots'],terminal_tail=rec['terminal_tail']),rec,rec['ruleset'],'fresh'))
counts={'paid':dict(roots=0,phases=0,edges=0),'fresh':dict(roots=0,phases=0,edges=0)}
for f,rec,ruleset,kind in datasets:
 assert rec['complete'];prior=(roots,phases,edges);raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(ruleset)));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=nc.compile_native_semantic_rules(c)
 for root in f['roots']:
  p.rr.stopped();s=GameSession(c)
  for d in root['walk']:s.submit(action(d))
  assert record_value(s.state)==root['state'];roots+=1
  for row in [r for r in rec['rows']if r['ply']==root['ply']]:
   for phase in row['phases']:
    phases+=1;result=phase['result'];state=s.state;pos=pack_semantic_search_position(c,nr,s);w=list(s._search_witnesses)
    line=[action(d)for d in result['principal_variation']]
    if not line and result['action']is not None:line=[action(result['action'])]
    for act in line:
     assert not state.terminal_status.is_terminal
     pos=sem.make_checked(nr,pos,pack_semantic_action(nr,state.position,act));state=apply_action(state,act,c);w.append(state.position);snap=sem.snapshot(nr,pos);exp=expected_snapshot(state.position,nr,c)
     for key in('board','hands','aux_state','side'):assert record_value(snap[key])==record_value(exp[key])
     assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(v,c))for v in w]
     assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
     assert sem.terminal_status(nr,pos)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner);edges+=1
    if result['immediate_win']:
     ch=apply_action(s.state,action(result['action']),c);assert ch.terminal_status.is_terminal and ch.terminal_status.winner==s.state.position.side_to_move;choices+=1
   d=rec['diagnostics'][row['diagnostic_key']]
   if d.get('winning_reply')is not None:
    ch=apply_action(s.state,action(row['selected']['action']),c);reply=apply_action(ch,action(d['winning_reply']),c);assert reply.terminal_status.is_terminal and reply.terminal_status.winner==ch.position.side_to_move;diagnosed+=1
 if f['terminal_tail']is not None:
  s=GameSession(c)
  for d in f['terminal_tail']['walk']:s.submit(action(d))
  assert record_value(s.state)==f['terminal_tail']['state']and s.result.status.value!='ongoing';tails+=1
 for k,v,old in zip(('roots','phases','edges'),(roots,phases,edges),prior):counts[kind][k]+=v-old
 print('REPLAYED',kind,f['seed'],roots,phases,edges,flush=True)
write_record(B/'consumer-replay.json',dict(complete=True,seconds=time.perf_counter()-start,roots=roots,phases=phases,edges=edges,by_cohort=counts,terminal_tails=tails,physical_win_receipts=choices,winning_reply_receipts=diagnosed,scope='Search disabled, existing Core/compiler and normal product Native; every recorded phase PV/fallback state/history replayed and actual terminals. No timing rerun, proof of optimality or independent rules implementation.'));print('REPLAY_PASS',roots,phases,edges,flush=True)
