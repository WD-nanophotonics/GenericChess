from pathlib import Path
import sys,dataclasses,json
sys.path.insert(0,str(Path.cwd()/'.local_agent/reserve-allocation-20261015'))
import allocation as a
from scripts.research_record import record_value,write_record
m=a.backend();s,nr,bv,hv=a.load(a.plan['cases'][1],m);before=record_value(s.to_record());controls=[]
token=a.CancellationToken();token.cancel();row,r=a.schedule(s,nr,bv,hv,'reserve',1,token=token);assert r is None and not row['execution_allowed']and not row['phases'];controls.append(dict(name='real_precancel_no_call',result=row))
row,r=a.schedule(s,nr,bv,hv,'reserve',1,after_phase=lambda i,r,t:t.cancel());assert len(row['phases'])==1 and row['cancelled']and not row['execution_allowed'];a.audit(s,nr,r);controls.append(dict(name='real_cancel_between_phases',result=row))
base=r
# Clock jump models atomic caller cost exceeding the whole deadline, not a kernel timer.
offset=[0.0]
def clock():return a.time.perf_counter()+offset[0]
def jump(i,r,t):offset[0]+=2
row,r=a.schedule(s,nr,bv,hv,'reserve',1,clock=clock,after_phase=jump);assert len(row['phases'])==1 and not row['execution_allowed']and row['overrun_seconds']>1;a.audit(s,nr,r);controls.append(dict(name='real_result_then_fake_outer_expiry',result=row))
class Factory:
 def __init__(self,seq):self.seq=list(seq);self.tokens=[];self.limits=[]
 def __call__(self,*args,**kwargs):return self
 def search(self,s,lim,cancel_token,**kwargs):self.tokens.append(cancel_token);self.limits.append(lim);return self.seq.pop(0)
def result(depth,ordinary,hard,reason='time_budget',score=-100,**kw):return dataclasses.replace(base,completed_depth=depth,result_source='main_iteration',result_ordinary_qdepth=ordinary,result_check_hard_qdepth=hard,termination_reason=reason,immediate_win=False,score=score,**kw)
reserve=result(3,0,0,score=500000)
for name,second,expected in [('retained_requested_despite_later_abort',result(2,4,8),True),('completed_reserve_is_not_requested',result(1,0,8,'completed_depth',score=999999),False),('fallback_fake_q_fields_not_completed',dataclasses.replace(result(2,4,8),result_source='fallback'),False),('missing_policy_fields',result(3,None,None),False)]:
 f=Factory([reserve,second]);row,r=a.schedule(s,nr,bv,hv,'reserve',1,engine_factory=f);assert(r is second)==expected;assert f.tokens[0]is f.tokens[1];assert f.limits[1].max_nodes==a.plan['nodes']-reserve.nodes;controls.append(dict(name=name,expected_requested_adoption=expected,result=row))
# Actual physical win fixture, same Native backend, no mate-score substitution.
sys.path.insert(0,str(Path.cwd()/'tests/product'));sys.path.insert(0,str(Path.cwd()/'tests'))
from test_native_terminal_declaration_priority import position
ws=position();wn=a.nc.compile_native_semantic_rules(ws.compiled,backend_module=m);v={t:0 if x.is_anchor else 100 for t,x in ws.compiled.support.type_metadata.items()}
for mode in ['q0','q4','reserve']:
 row,r=a.schedule(ws,wn,v,v,mode,1);assert r.immediate_win and r.completed_depth==0 and row['selected_source']=='physical_win';child=a.apply_action(ws.state,r.action,ws.compiled);assert child.terminal_status.winner==ws.state.position.side_to_move;a.audit(ws,wn,r);controls.append(dict(name='real_physical_win_'+mode,result=row,child_terminal=record_value(child.terminal_status)))
row,r=a.schedule(ws,wn,v,v,'reserve',1,after_phase=lambda i,r,t:t.cancel());assert r.immediate_win and row['selected_source']=='physical_win'and row['cancelled']and not row['execution_allowed'];controls.append(dict(name='physical_win_evidence_survives_cancellation_execution_forbidden',result=row))
assert record_value(s.to_record())==before
write_record(a.B/'controls.json',dict(passed=len(controls),controls=controls,scope='Actual Native pre/afterphase cancellation and physical win; synthetic retained-result/clock controls explicitly labelled, no claim real coincident kernel cancellation reproduced.'));print('CONTROL_PASS',len(controls))

