from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()/'.local_agent/reserve-allocation-20261015'))
import allocation as a
from scripts.research_record import record_value,write_record
plan=json.loads((a.B/'transfer-plan.json').read_bytes());assert hashlib.sha256((a.B/'allocation.py').read_bytes()).hexdigest()==plan['allocation_sha256'];start=time.perf_counter();m=a.backend();family_results=[]
for family in plan['cases']:
 family_start=time.perf_counter();rows=[];diagnostics={};reason=None;prep=time.perf_counter()
 seed=family['seed'];assert hashlib.sha256((a.O/'transfer-inputs'/f'{seed}.json').read_bytes()).hexdigest()==family['input_sha256']
 if family['roots']:s,nr,bv,hv=a.load(dict(seed=seed,root=family['roots'][0]),m);c=s.compiled
 preparation=time.perf_counter()-prep
 def save(complete=False):write_record(a.B/f'transfer-{seed}.json',dict(complete=complete,seed=seed,n=family['n'],rows=rows,diagnostics=diagnostics,missing_root_slots=[p for p in [0,4,8,12]if not any(r['ply']==p for r in family['roots'])],terminal_tail=family['terminal_tail'],end_reason=reason,seconds=time.perf_counter()-family_start,preparation_seconds=preparation,planned_queries=48))
 for root in family['roots']:
  s=a.GameSession(c)
  for stored in root['walk']:s.submit(next(x for x in s.legal_actions()if record_value(x)==stored))
  assert record_value(s.state)==root['state'];before=record_value(s.to_record())
  for budget in plan['budgets']:
   for order,modes in enumerate(plan['orders']):
    for mode in modes:
     a.p.rr.stopped()
     if time.perf_counter()-start>=plan['batch_seconds']:reason='ORIGINAL_WHOLE_CAP';break
     if time.perf_counter()-family_start>=plan['per_family_seconds']:reason='ORIGINAL_FAMILY_CAP';break
     phase_results=[];row,res=a.schedule(s,nr,bv,hv,mode,budget,phase_results=phase_results);row.update(seed=seed,n=family['n'],ply=root['ply'],order=order)
     at=time.perf_counter();row['all_phase_pv_edges_checked']=sum(a.audit(s,nr,r)for r in phase_results);row['audit_seconds']=time.perf_counter()-at;assert before==record_value(s.to_record())
     key=str(root['ply'])+':'+repr(None if res is None else res.action)
     if key not in diagnostics:diagnostics[key]=a.diagnosis(s,None if res is None else res.action)
     row['diagnostic_key']=key;rows.append(row);save();rr=row['selected'];print(seed,root['ply'],budget,order,mode,None if rr is None else(rr['completed_depth'],rr['result_ordinary_qdepth']),row['selected_source'],diagnostics[key]['kind'],flush=True)
    if reason:break
   if reason:break
  if reason:break
 if reason is None:reason='PLANNED_AVAILABLE_ROOTS_COMPLETE'
 save(True);family_results.append(dict(seed=seed,queries=len(rows),reason=reason,seconds=time.perf_counter()-family_start));write_record(a.B/'transfer-progress.json',dict(complete=False,families=family_results,seconds=time.perf_counter()-start));print('FAMILY_DONE',seed,len(rows),round(time.perf_counter()-family_start,3),flush=True)
 if reason=='ORIGINAL_WHOLE_CAP':break
write_record(a.B/'transfer-progress.json',dict(complete=len(family_results)==20,families=family_results,seconds=time.perf_counter()-start,source_hash_unchanged=hashlib.sha256((a.B/'allocation.py').read_bytes()).hexdigest()==plan['allocation_sha256']));print('BATCH_DONE',len(family_results),time.perf_counter()-start,flush=True)
