from pathlib import Path
import sys,json,time,subprocess
R=Path.cwd();B=R/'.local_agent/reserve-allocation-20261015';sys.path.insert(0,str(B));import allocation as a
from scripts.research_record import write_record
plan=json.loads((B/'fresh-plan.json').read_bytes());alt=json.loads((B/'alternatives.json').read_bytes());assert alt['complete'];chosen=[r for r in alt['rows']if r['seed']==4323 and r['ply']==12];valid=True;go_evidence=[]
for order in [0,1]:
 cap=next(r for r in chosen if r['order']==order and r['variant']=='cap2');old=next(r for r in chosen if r['order']==order and r['variant']=='reserve');good=cap['phases'][0]['result']['completed_depth']>=2 and alt['diagnostics'][cap['diagnostic_key']]['kind']=='NONE_FOUND_ONE_PLY'and cap['outer_delivery_allowed']and cap['phases'][-1]['requested_kernel_seconds']>old['phases'][-1]['requested_kernel_seconds'];valid=valid and good;go_evidence.append(dict(order=order,go=good,cap2_second_budget=cap['phases'][-1]['requested_kernel_seconds'],old_second_budget=old['phases'][-1]['requested_kernel_seconds']))
write_record(B/'fresh-go.json',dict(go=valid,evidence=go_evidence,scope=plan['go_condition']))
if not valid:print('FRESH_SKIPPED_NO_PREMISE');sys.exit(0)
start=time.perf_counter();rows=[]
for case in plan['inputs']:
 a.p.rr.stopped();remaining=plan['batch_seconds']-(time.perf_counter()-start)
 if remaining<=0:rows.append(dict(seed=case['seed'],state='ORIGINAL_WHOLE_CAP'));break
 try:
  r=subprocess.run([sys.executable,str(B/'fresh_one.py'),str(case['seed'])],capture_output=True,timeout=min(plan['per_family_seconds']+1,remaining));(B/f"fresh-{case['seed']}.log").write_bytes(r.stdout+r.stderr);rows.append(dict(seed=case['seed'],exit=r.returncode,state='EXITED',seconds=time.perf_counter()-start))
 except subprocess.TimeoutExpired as e:
  (B/f"fresh-{case['seed']}.log").write_bytes((e.stdout or b'')+(e.stderr or b''));rows.append(dict(seed=case['seed'],state='ORIGINAL_PROCESS_CAP',seconds=time.perf_counter()-start))
 write_record(B/'fresh-progress.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start));print(rows[-1],flush=True)
write_record(B/'fresh-progress.json',dict(complete=len(rows)==6,rows=rows,seconds=time.perf_counter()-start));print('FRESH_BATCH_DONE',len(rows),time.perf_counter()-start,flush=True)
