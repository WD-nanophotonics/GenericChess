from pathlib import Path
import sys,json,time,random,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/reserve-allocation-20261015';sys.path.insert(0,str(B))
import allocation as a
from variant_schedule import schedule_variant
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
from scripts.research_record import record_value,write_record
seed=int(sys.argv[1]);plan=json.loads((B/'fresh-plan.json').read_bytes());case=next(x for x in plan['inputs']if x['seed']==seed);start=time.perf_counter();rows=[];roots=[];walk=[];diags={};tail=None;reason=None;generated=None
assert hashlib.sha256((B/'variant_schedule.py').read_bytes()).hexdigest()==plan['variant_sha256'];assert hashlib.sha256((B/'allocation.py').read_bytes()).hexdigest()==plan['allocation_sha256']
def save(complete=False):write_record(B/f'fresh-{seed}.json',dict(complete=complete,seed=seed,n=case['n'],ruleset=generated,roots=roots,rows=rows,walk=walk,terminal_tail=tail,diagnostics=diags,reason=reason,seconds=time.perf_counter()-start,planned_queries=24))
save();a.p.rr.stopped();cfg=GeneratorConfig(seed=seed,board_size=case['n'],**plan['generator']);game=generate_game(cfg);generated=json.loads(serialize_ruleset(game.ruleset));raw=a.p.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession(c);m=a.backend();nr=a.nc.compile_native_semantic_rules(c,backend_module=m);profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};rng=random.Random(seed+19000);save()
for ply in range(9):
 a.p.rr.stopped()
 if time.perf_counter()-start>=plan['per_family_seconds']:reason='ORIGINAL_FAMILY_CAP';break
 if s.result.status.value!='ongoing':tail=dict(ply=ply,state=record_value(s.state),walk=walk.copy());reason='ACTUAL_TERMINAL_TAIL';break
 if ply in plan['roots']:
  roots.append(dict(ply=ply,state=record_value(s.state),walk=walk.copy(),legal_count=len(s.legal_actions())));before=record_value(s.to_record());save()
  for budget in plan['budgets']:
   for order,variants in enumerate(plan['orders']):
    for variant in variants:
     a.p.rr.stopped()
     if time.perf_counter()-start>=plan['per_family_seconds']:reason='ORIGINAL_FAMILY_CAP';break
     phases=[];t=time.perf_counter();row,res=schedule_variant(s,nr,bv,hv,'q4'if variant=='q4'else'reserve',budget,phase_results=phases,variant=variant);row['outer_caller_seconds']=time.perf_counter()-t;row['outer_delivery_allowed']=row['execution_allowed']and row['outer_caller_seconds']<budget;row.update(seed=seed,n=case['n'],ply=ply,order=order,variant=variant);at=time.perf_counter();row['pv_edges_checked']=sum(a.audit(s,nr,r)for r in phases);row['audit_seconds']=time.perf_counter()-at;assert before==record_value(s.to_record());key=str(ply)+':'+repr(None if res is None else res.action)
     if key not in diags:diags[key]=a.diagnosis(s,None if res is None else res.action)
     row['diagnostic_key']=key;rows.append(row);save();print(seed,ply,budget,order,variant,None if res is None else(res.completed_depth,res.result_ordinary_qdepth),row['selected_source'],flush=True)
    if reason:break
   if reason:break
  if reason:break
 if ply==8:break
 acts=tuple(s.legal_actions())
 if not acts:reason='NO_LEGAL_ACTION';break
 act=rng.choice(sorted(acts,key=repr));s.submit(act);walk.append(record_value(act))
reason=reason or'PLANNED_ROOTS_COMPLETE';save(True);print('FRESH_DONE',seed,len(rows),reason,time.perf_counter()-start,flush=True)
