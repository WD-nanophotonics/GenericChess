"""Private frozen caller experiment. No product/default change or solver."""
from pathlib import Path
import sys,json,time,hashlib,importlib.util
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/reserve-allocation-20261015';O=R/'.local_agent/admission-reuse-20261015'
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.movegen import iter_legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
plan=json.loads((B/'plan.json').read_bytes())

def eligible(res,q):
 if res is None:return False
 if res.immediate_win and res.result_source=='verified_root_child':return True
 return res.result_source=='main_iteration' and res.completed_depth>=(1 if q==0 else 2) and (res.result_ordinary_qdepth,res.result_check_hard_qdepth)==((0,0)if q==0 else(q,8))

def schedule(s,nr,bv,hv,mode,budget,*,token=None,clock=time.perf_counter,after_phase=None,engine_factory=SemanticSearchEngine,phase_results=None):
 token=token if token is not None else CancellationToken();start=clock();deadline=start+budget;phases=[];selected=None;source=None;used=0
 for i,q in enumerate([0,4]if mode=='reserve'else[4]if mode=='q4'else[0]):
  if token.is_cancelled() or clock()>=deadline:break
  phase_start=clock();engine=engine_factory(s.compiled,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
  remaining=deadline-clock()-plan['delivery_margin_seconds'];allowance=min(remaining,plan['reserve_seconds']-(clock()-phase_start))if mode=='reserve'and i==0 else remaining
  if allowance<=0:break
  res=engine.search(s,SearchLimits(max_depth=plan['depth'],max_nodes=max(0,plan['nodes']-used),max_time_seconds=allowance,quiescence_max_depth=q,quiescence_hard_max_depth=plan['hard_q']),cancel_token=token,root_window_pruning=True,stop_on_immediate_win=True)
  used+=res.nodes
  if phase_results is not None:phase_results.append(res)
  row=dict(q=q,result=record_value(res),phase_seconds=clock()-phase_start,requested_kernel_seconds=allowance,remaining_after=deadline-clock(),eligible=eligible(res,q));phases.append(row)
  if after_phase is not None:after_phase(i,res,token)
  # Preserve evidence even after cancellation, but never authorize execution.
  if res.immediate_win and res.result_source=='verified_root_child':selected=res;source='physical_win';break
  if mode!='reserve':selected=res;source=mode
  elif i==0:selected=res;source='disabled_reserve' if eligible(res,0) else 'disabled_fallback'
  elif eligible(res,4):selected=res;source='requested_q4'
  if token.is_cancelled() or clock()>=deadline:break
 wall=clock()-start
 return dict(mode=mode,budget=budget,phases=phases,selected=None if selected is None else record_value(selected),selected_source=source,caller_seconds=wall,overrun_seconds=max(0,wall-budget),cancelled=token.is_cancelled(),execution_allowed=selected is not None and selected.action is not None and not token.is_cancelled() and clock()<deadline,total_nodes=used),selected

def backend():
 spec=importlib.util.spec_from_file_location('allocation._native_core',next((R/'.local_agent/reply-witness-20261015').glob('final_both*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);assert hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()==plan['native_image_sha256'];return m

def load(case,m):
 x=json.loads((O/'transfer-inputs'/f"{case['seed']}.json").read_bytes());raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 for stored in case['root']['walk']:s.submit(next(a for a in s.legal_actions()if record_value(a)==stored))
 assert record_value(s.state)==case['root']['state'];nr=nc.compile_native_semantic_rules(c,backend_module=m);profile=p.build_ruleset_profile(c,p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};return s,nr,bv,hv

def audit(s,nr,res):
 if res is None:return 0
 c=s.compiled;state=s.state;np=pack_semantic_search_position(c,nr,s);w=list(s._search_witnesses);before=record_value(s.to_record())
 assert res.action is None or res.action in s.legal_actions()
 for action in res.principal_variation:
  np=sem.make_checked(nr,np,pack_semantic_action(nr,state.position,action));state=apply_action(state,action,c);w.append(state.position);snap=sem.snapshot(nr,np);expected=expected_snapshot(state.position,nr,c)
  for key in('board','hands','aux_state','side'):assert record_value(snap[key])==record_value(expected[key])
  assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(v,c))for v in w]
  assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
 assert before==record_value(s.to_record());return len(res.principal_variation)

def diagnosis(s,action):
 if action is None:return dict(kind='NO_ACTION')
 p.rr.stopped();child=apply_action(s.state,action,s.compiled);start=time.perf_counter();actor=child.position.side_to_move;rows=[];complete=False;win=None
 if child.terminal_status.is_terminal:return dict(kind='SELECTED_CHILD_TERMINAL',terminal=record_value(child.terminal_status))
 def checkpoint():
  if time.perf_counter()-start>=plan['diagnostic_seconds']:raise TimeoutError('frozen new two-second diagnostic cap')
 try:
  for a in iter_legal_actions(child,s.compiled,checkpoint=checkpoint):
   checkpoint();r=apply_action(child,a,s.compiled);rows.append(dict(action=record_value(a),terminal=record_value(r.terminal_status)))
   if r.terminal_status.is_terminal and r.terminal_status.winner==actor:win=record_value(a);break
  else:complete=True
 except TimeoutError:pass
 p.rr.stopped();return dict(kind='ONE_REPLY_WIN'if win is not None else'NONE_FOUND_ONE_PLY'if complete else'UNKNOWN',complete=complete,winning_reply=win,rows=rows,seconds=time.perf_counter()-start)

if __name__=='__main__':
 m=backend();batch=time.perf_counter();rows=[];diagnostics={};complete=True
 for ci,case in enumerate(plan['cases']):
  s,nr,bv,hv=load(case,m)
  for budget in plan['budgets']:
   for order,modes in enumerate(plan['orders']):
    for mode in modes:
     p.rr.stopped()
     if time.perf_counter()-batch>=plan['total_seconds']:complete=False;break
     row,res=schedule(s,nr,bv,hv,mode,budget);row.update(case_index=ci,seed=case['seed'],ply=case['ply'],order=order)
     row['pv_edges_checked']=audit(s,nr,res);key=str(ci)+':'+repr(None if res is None else res.action)
     if key not in diagnostics:diagnostics[key]=diagnosis(s,None if res is None else res.action)
     row['diagnostic_key']=key;rows.append(row);write_record(B/'results.json',dict(complete=False,rows=rows,diagnostics=diagnostics,seconds=time.perf_counter()-batch));print(ci,budget,order,mode,row['selected_source'],None if res is None else(res.completed_depth,res.result_ordinary_qdepth,res.result_check_hard_qdepth),round(row['caller_seconds'],4),diagnostics[key]['kind'],flush=True)
 write_record(B/'results.json',dict(complete=complete,rows=rows,diagnostics=diagnostics,seconds=time.perf_counter()-batch,scope=plan['scope']));print('COMPLETE',complete,len(rows),time.perf_counter()-batch,flush=True)
