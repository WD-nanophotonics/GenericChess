from pathlib import Path
import sys,json,time,subprocess
R=Path.cwd();B=R/'.local_agent/reserve-allocation-20261015';sys.path.insert(0,str(B));import allocation as a
from scripts.research_record import write_record
plan=json.loads((B/'continuation-plan.json').read_bytes());start=time.perf_counter();rows=[]
for ci,case in enumerate(plan['cases']):
 for arm in (['q4','reserve']if ci%2==0 else['reserve','q4']):
  a.p.rr.stopped();remaining=plan['batch_seconds']-(time.perf_counter()-start)
  if remaining<=0:rows.append(dict(case=ci,arm=arm,state='ORIGINAL_WHOLE_CAP'));break
  try:
   r=subprocess.run([sys.executable,str(B/'continuation_one.py'),str(ci),arm],capture_output=True,timeout=min(plan['per_game_seconds']+5,remaining));(B/f'continuation-{ci}-{arm}.log').write_bytes(r.stdout+r.stderr);rows.append(dict(case=ci,arm=arm,state='EXITED',exit=r.returncode));print(r.stdout.decode(errors='replace').strip(),flush=True)
  except subprocess.TimeoutExpired as e:
   (B/f'continuation-{ci}-{arm}.log').write_bytes((e.stdout or b'')+(e.stderr or b''));rows.append(dict(case=ci,arm=arm,state='ORIGINAL_PROCESS_CAP'));print(rows[-1],flush=True)
  write_record(B/'continuation-progress.json',dict(complete=False,rows=rows,seconds=time.perf_counter()-start))
write_record(B/'continuation-progress.json',dict(complete=len(rows)==2*len(plan['cases']),rows=rows,seconds=time.perf_counter()-start));print('CONTINUATIONS_DONE',len(rows),time.perf_counter()-start,flush=True)
