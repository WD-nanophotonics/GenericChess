from pathlib import Path
import json,hashlib,zipfile,re
R=Path.cwd();B=R/'.local_agent/reserve-allocation-20261015';A=R/'docs/archive/reserve_allocation_20261015';A.mkdir(parents=True,exist_ok=True)
files={}
for p in B.iterdir():
 if p.is_file()and p.suffix in['.py','.json','.log']and 'private'not in p.name and p.name not in['publication-replay.json']:
  files['research/'+p.name]=p.read_bytes()
for p in (R/'.local_agent/admission-reuse-20261015/transfer-inputs').glob('*.json'):files['inputs/'+p.name]=p.read_bytes()
# Preserve raw originals; sanitize only publication copies containing project paths.
rows=[]
for name,blob in sorted(files.items()):
 text=blob.decode('utf-8-sig');original=text
 for source in [str(R).replace('\\','\\\\'),str(R),str(R).replace('\\','/')]:text=text.replace(source,'<PROJECT>')
 assert not re.search(r'[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}',text,re.I),(name,'email')
 assert not re.search(r'(xox[baprs]-[A-Za-z0-9-]+|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]+)',text),(name,'credential')
 assert not re.search(r'C:[\\/](?:Users)[\\/]',text,re.I),(name,'personal path')
 blob=text.encode();files[name]=blob;rows.append(dict(member=name,bytes=len(blob),public_sha256=hashlib.sha256(blob).hexdigest(),sanitized_copy=text!=original))
with zipfile.ZipFile(A/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for name,blob in sorted(files.items()):z.writestr(name,blob)
with zipfile.ZipFile(A/'evidence.zip')as z:
 assert z.testzip()is None
 for item in rows:assert hashlib.sha256(z.read(item['member'])).hexdigest()==item['public_sha256']
manifest=dict(source_base='a3c495916f81a2f1fdb50f2b0344a9f5463583f4',archive_sha256=hashlib.sha256((A/'evidence.zip').read_bytes()).hexdigest(),archive_bytes=(A/'evidence.zip').stat().st_size,members=rows,scope='Exact technical project record copies; private/account originals excluded for actual personal information. Only publication path copies normalized. Producer image hash is provenance; replay uses unchanged public product Native, no timing rerun.')
(A/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print('ARCHIVE',len(rows),manifest['archive_bytes'],'unpacked',sum(r['bytes']for r in rows),'sanitized',[r['member']for r in rows if r['sanitized_copy']])
# Publish report and a compact summary; complete records remain compressed.
report=(B/'report-draft.md').read_text(encoding='utf-8-sig').replace('The full19reply auxiliary thread','The recovery full19reply auxiliary thread')
report+='\nClosing complete20reply auxiliary read adds final owner revision65243286224f37f022824fb4cfdad2bff9fc10c6: reported298tests and888newpolicy games/12717moves, plus unit/horizon sensitivity. PRIMARY read the Slack supplement only; no final source/test/game execution or adoption is claimed. It reports reading our prior context without a rerun; costs remain separate. No new channel roots or primary supplements after the adopted reply.\n\nFocused existing Native goal/cancel/budget/q contracts:56passed. Pytest optional cache write reports Errno13; actual tests and research succeed. The publication invocation disables that optional cache provider. Raw warning stays private and its public copy replaces the personal project path. No security setting change or claim that SAC caused this cache warning.\n\nArchive: `../archive/reserve_allocation_20261015/evidence.zip`, per-member hashes and `replay.py`; complete phase records, rules/roots, protocols, all missing slots, controls and next-source examination. Public-copy replay receipt is recorded after actual execution.\n'
(R/'docs/research/COMPLETION_AWARE_RESERVE_ALLOCATION.md').write_bytes(report.encode())
summary={k:json.loads((B/f).read_bytes())for k,f in [('transfer','transfer-summary.json'),('alternatives','alternative-summary.json'),('fresh','fresh-summary.json'),('cohort_replay','consumer-replay.json'),('continuations','continuation-replay.json'),('next_question','next-ordering-source.json')]}
(R/'docs/research/data/reserve_allocation_20261015.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
