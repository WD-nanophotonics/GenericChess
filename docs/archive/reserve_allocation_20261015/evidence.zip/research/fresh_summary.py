from pathlib import Path
import json,collections
B=Path('.local_agent/reserve-allocation-20261015');plan=json.loads((B/'fresh-plan.json').read_bytes());progress=json.loads((B/'fresh-progress.json').read_bytes());files=[];failures=[]
closed={r['seed']for r in progress['rows']}
for f in plan['inputs']:
 if f['seed']not in closed:continue
 p=B/f"fresh-{f['seed']}.json"
 if not p.exists():failures.append(dict(seed=f['seed'],reason='NO_RESULT'));continue
 x=json.loads(p.read_bytes())
 if not x['complete']:failures.append(dict(seed=f['seed'],reason=x['reason']or'PROCESS_INTERRUPTED_PARTIAL'))
 files.append(x)
rows=[r for f in files for r in f['rows']];group={};pairs=[];byseed={f['seed']:f for f in files}
for r in rows:group.setdefault((r['seed'],r['ply'],r['budget'],r['order']),{})[r['variant']]=r
def requested(r):
 s=r['selected'];return s is not None and s['result_source']=='main_iteration'and s['completed_depth']>=2 and(s['result_ordinary_qdepth'],s['result_check_hard_qdepth'])==(4,8)
def physical(r):return r['selected']is not None and r['selected']['immediate_win']and r['selected']['result_source']=='verified_root_child'
for k,g in sorted(group.items()):
 if set(g)!={'q4','reserve','cap2'}:continue
 q,c,o=g['q4'],g['cap2'],g['reserve'];d=byseed[k[0]]['diagnostics'];pairs.append(dict(seed=k[0],ply=k[1],budget=k[2],order=k[3],n=q['n'],same_action=q['selected']['action']==c['selected']['action'],q4_requested=requested(q),cap2_requested=requested(c),old_requested=requested(o),cap2_physical=physical(c),q4_depth=q['selected']['completed_depth'],cap2_depth=c['selected']['completed_depth'],old_depth=o['selected']['completed_depth'],q4_diagnostic=d[q['diagnostic_key']]['kind'],cap2_diagnostic=d[c['diagnostic_key']]['kind'],both_deliverable=q['outer_delivery_allowed']and c['outer_delivery_allowed'],old_same_action=o['selected']['action']==c['selected']['action']))
s=dict(complete=progress['complete']and len(files)==6 and not failures and all(f['reason']in['PLANNED_ROOTS_COMPLETE','ACTUAL_TERMINAL_TAIL']for f in files),planned_roots=12,roots=sum(len(f['roots'])for f in files),planned_queries=144,queries=len(rows),terminal_tails=[dict(seed=f['seed'],ply=f['terminal_tail']['ply'])for f in files if f['terminal_tail']is not None],failures=failures,triples=len(pairs),same_action=sum(p['same_action']for p in pairs),both_deliverable=sum(p['both_deliverable']for p in pairs),requested_lost=sum(p['q4_requested']and not p['cap2_requested']and not p['cap2_physical']for p in pairs),requested_gained=sum(not p['q4_requested']and p['cap2_requested']for p in pairs),old_requested_lost=sum(p['q4_requested']and not p['old_requested']for p in pairs),same_action_old_vs_cap2=sum(p['old_same_action']for p in pairs),immediate_loss_avoided=sum(p['both_deliverable']and p['q4_diagnostic']=='ONE_REPLY_WIN'and p['cap2_diagnostic']=='NONE_FOUND_ONE_PLY'for p in pairs),immediate_loss_introduced=sum(p['both_deliverable']and p['cap2_diagnostic']=='ONE_REPLY_WIN'and p['q4_diagnostic']=='NONE_FOUND_ONE_PLY'for p in pairs),diagnostics=dict(collections.Counter(d['kind']for f in files for d in f['diagnostics'].values())),pv_edges=sum(r['pv_edges_checked']for r in rows),execution_forbidden=sum(not r['outer_delivery_allowed']for r in rows),max_outer_overrun=max([r['outer_caller_seconds']-r['budget']for r in rows]+[0]),seconds=progress['seconds'],pairs=pairs,scope=plan['decision'])
(B/'fresh-summary.json').write_text(json.dumps(s,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in s.items()if k not in['pairs','scope']},indent=2))
