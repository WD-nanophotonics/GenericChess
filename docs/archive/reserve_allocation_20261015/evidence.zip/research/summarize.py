from pathlib import Path
import json,collections,math
B=Path('.local_agent/reserve-allocation-20261015');plan=json.loads((B/'transfer-plan.json').read_bytes());files=[]
closed={int(line.split()[1]) for line in (B/'transfer.log').read_text(encoding='utf-8-sig').splitlines()if line.startswith('FAMILY_DONE ')}
for f in plan['cases']:
 if f['seed']not in closed:continue
 p=B/f"transfer-{f['seed']}.json"
 if p.exists():
  x=json.loads(p.read_bytes())
  if x['complete']:files.append(x)
rows=[r for f in files for r in f['rows']];pairs=[];by={}
for r in rows:by.setdefault((r['seed'],r['ply'],r['budget'],r['order']),{})[r['mode']]=r
families={f['seed']:f for f in files}
def requested(r):
 s=r['selected'];return s is not None and s['result_source']=='main_iteration'and s['completed_depth']>=2 and s['result_ordinary_qdepth']==4 and s['result_check_hard_qdepth']==8
def physical(r):return r['selected']is not None and r['selected']['immediate_win']and r['selected']['result_source']=='verified_root_child'
for k,arms in sorted(by.items()):
 if set(arms)!={'q0','q4','reserve'}:continue
 a,b=arms['q4'],arms['reserve'];di=families[k[0]]['diagnostics'];ad,bd=di[a['diagnostic_key']],di[b['diagnostic_key']]
 pairs.append(dict(seed=k[0],ply=k[1],budget=k[2],order=k[3],n=a['n'],same_action=a['selected']['action']==b['selected']['action'],q4_requested=requested(a),reserve_requested=requested(b),q4_physical=physical(a),reserve_physical=physical(b),q4_depth=a['selected']['completed_depth'],reserve_depth=b['selected']['completed_depth'],q4_diagnostic=ad['kind'],reserve_diagnostic=bd['kind'],q4_execution_allowed=a['execution_allowed'],reserve_execution_allowed=b['execution_allowed'],q4_source=a['selected']['result_source'],reserve_source=b['selected_source']))
summary=dict(complete=len(files)==20 and all(f['end_reason']=='PLANNED_AVAILABLE_ROOTS_COMPLETE'for f in files),families=len(files),planned_roots=80,available_roots=sum(len(f['roots'])for f in plan['cases']),planned_queries=960,queries=len(rows),missing_terminal_root_slots=sum(len(f['missing_root_slots'])for f in files),family_seconds=sum(f['seconds']for f in files),triples=len(pairs),same_action=sum(p['same_action']for p in pairs),both_deliverable=sum(p['q4_execution_allowed']and p['reserve_execution_allowed']for p in pairs),requested_lost=sum(p['q4_requested']and not p['reserve_requested']and not p['reserve_physical']for p in pairs),requested_gained=sum(not p['q4_requested']and p['reserve_requested']for p in pairs),actual_immediate_loss_avoided=sum(p['q4_execution_allowed']and p['reserve_execution_allowed']and p['q4_diagnostic']=='ONE_REPLY_WIN'and p['reserve_diagnostic']=='NONE_FOUND_ONE_PLY'for p in pairs),actual_immediate_loss_introduced=sum(p['q4_execution_allowed']and p['reserve_execution_allowed']and p['reserve_diagnostic']=='ONE_REPLY_WIN'and p['q4_diagnostic']=='NONE_FOUND_ONE_PLY'for p in pairs),source_counts=dict(collections.Counter(r['selected_source']for r in rows if r['mode']=='reserve')),diagnostics=dict(collections.Counter(d['kind']for f in files for d in f['diagnostics'].values())),pv_edges=sum(r['all_phase_pv_edges_checked']for r in rows),execution_forbidden=sum(not r['execution_allowed']for r in rows),max_caller_overrun=max([r['overrun_seconds']for r in rows],default=0),pairs=pairs,scope=plan['scope'])
for n in [4,8,12,16]:
 for budget in [1,4]:
  z=[p for p in pairs if p['n']==n and p['budget']==budget];summary.setdefault('strata',[]).append(dict(n=n,budget=budget,triples=len(z),same_action=sum(p['same_action']for p in z),requested_lost=sum(p['q4_requested']and not p['reserve_requested']and not p['reserve_physical']for p in z),requested_gained=sum(not p['q4_requested']and p['reserve_requested']for p in z)))
(B/'transfer-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in summary.items()if k not in ['pairs','strata','scope']},indent=2))
