"""Cross-panel planned bounds; missing interrupted original games never refilled."""
from pathlib import Path
from collections import defaultdict,Counter
import sys,json,random,hashlib
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/empty-mobility-utility-20261018';F=R/'.local_agent/broad-static-utility-20261018';S=R/'.local_agent/broad-static-opponent-20261018';rows=[]
for directory,defaultfoe in [(F,'unit'),(S,'rule_static_v2'),(D,None)]:
 slots=json.loads((directory/'slots.json').read_bytes())['slots'];games={g['slot']:g for g in map(json.loads,(directory/'games.jsonl').read_bytes().splitlines())}
 for idx,slot in enumerate(slots):
  gs,fam,label,owner=slot[:4];foe=slot[4]if len(slot)==5 else defaultfoe;g=games.get(idx);model,budget=label.split('@');rows.append(dict(rule=gs,seed=gs//100,size=gs%100,family=fam,model=model,budget=budget,owner=owner,foe=foe,reward=None if g is None else g['reward'],ending='MISSING_UNKNOWN'if g is None else g['ending'],game=g))
assert len(rows)==768

def interval(r):return[-1,1]if r['reward']is None else[r['reward']]*2

def outcome(rr):
 n=len(rr);u=sum(r['reward']is None for r in rr);k=sum(r['reward']for r in rr if r['reward']is not None)
 return dict(planned=n,returned=sum(r['game']is not None for r in rr),W=sum(r['reward']==1 for r in rr),D=sum(r['reward']==0 for r in rr),L=sum(r['reward']==-1 for r in rr),UNKNOWN=u,reward_bounds=[(k-u)/n,(k+u)/n],actual_nodes=sum((r['game']or{}).get('nodes',0)for r in rr),game_seconds=sum((r['game']or{}).get('game_seconds',0)for r in rr),endings=dict(Counter(r['ending']for r in rr)))

def contrast(rr,baseline):
 a={(r['rule'],r['family'],r['owner']):r for r in rr if r['model']=='geo_empty'};b={(r['rule'],r['family'],r['owner']):r for r in rr if r['model']==baseline};assert a.keys()==b.keys();n=len(a);v=[[interval(a[k])[0]-interval(b[k])[1],interval(a[k])[1]-interval(b[k])[0]]for k in a]
 return [sum(x[i]for x in v)/n for i in (0,1)]
result={};seed=2026101819
for foe in ('unit','rule_static_v2'):
 for budget in ('n8192','n32768'):
  rr=[r for r in rows if r['foe']==foe and r['budget']==budget];key=foe+'__'+budget;entry=dict(outcomes={m:outcome([r for r in rr if r['model']==m])for m in ('unit','rule_static_v2','geo_empty')},geo_minus={m:contrast(rr,m)for m in ('unit','rule_static_v2')},by_board={str(n):{m:contrast([r for r in rr if r['size']==n],m)for m in ('unit','rule_static_v2')}for n in (6,8)},descriptive_seed_envelopes={})
  seeds=sorted({r['seed']for r in rr});rng=random.Random(seed)
  sampled=[[rng.choice(seeds)for _ in seeds]for __ in range(10000)]
  for m in ('unit','rule_static_v2'):
   per={s:contrast([r for r in rr if r['seed']==s],m)for s in seeds};boot=[[sum(per[s][i]for s in seq)/len(seq)for i in (0,1)]for seq in sampled];entry['descriptive_seed_envelopes'][m]=[sorted(v[0]for v in boot)[249],sorted(v[1]for v in boot)[9749]]
  result[key]=entry
q=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));new=json.loads((D/'result.json').read_bytes());assert sum(g['nodes']for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines()))==sum(x['nodes']for x in q)==new['counts']['nodes']
write_json(D/'analysis.json',dict(status='PASS_ALL_PLANNED_CROSS_PANEL_BOUNDS',arms=result,new_actual_seconds=new['seconds'],new_nodes=sum(x['nodes']for x in q),new_queries=len(q),original_staticfoe_missing=144,scope='Exposed development comparison on SAME16rules/32roots/8linkedseedblocks, no newindependentholdout; eachfoe/budget64physicalcells/model. Original144missing/unclosed stayUNKNOWN. Posthoc descriptive10000blockresamples retainboards/families/roles together, no populationconfidenceguarantee. Crossprocesswalltimes descriptive not causal; resourcecaps/actualwork preserved. No fitting/default/AUXlearner.'))
print(json.dumps({k:dict(geo_minus=v['geo_minus'],envelopes=v['descriptive_seed_envelopes'],geo=v['outcomes']['geo_empty'])for k,v in result.items()},indent=2))
