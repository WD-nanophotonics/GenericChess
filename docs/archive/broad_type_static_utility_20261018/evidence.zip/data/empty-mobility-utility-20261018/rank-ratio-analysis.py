"""Posthoc rank-matched strata and legal two-PV leaf witnesses; no optimality proof."""
from pathlib import Path
from copy import copy
from collections import defaultdict,Counter
import sys,json,hashlib,os,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=R/'.local_agent/empty-mobility-utility-20261018';I=R/'.local_agent/broad-static-utility-20261018';mods={(r['rule'],r['label']):r['checkpoint']for r in json.loads((D/'models.json').read_bytes())['rows']};same={r['rule']for r in json.loads((D/'profile-comparison.json').read_bytes())['rows']if not r['board_rank_differences']};roots={(r['rule'],r['family']):r for r in json.loads((D/'roots.json').read_bytes())['rows']};compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines())};qmap={};game_rows={}
for directory,model in [(I,'rule_static_v2'),(D,'geo_empty')]:
 games={g['slot']:g for g in map(json.loads,(directory/'games.jsonl').read_bytes().splitlines())if g['label'].startswith(model+'@')and(directory==I or g['foe']=='unit')};game_rows[model]=games
 for q in map(json.loads,(directory/'queries.jsonl').read_bytes().splitlines()):
  g=games.get(q['slot'])
  if g and g['candidate_owner']==0 and q['relative_ply']==0 and q['candidate_turn']:
   qmap[model,g['rule'],g['family'],g['label'].split('@')[1]]=q

def bound(gs):
 u=sum(g['reward']is None for g in gs);k=sum(g['reward']for g in gs if g['reward']is not None);return[(k-u)/len(gs),(k+u)/len(gs)]
strata={}
for mode in ('same_rank','different_rank'):
 for budget in ('n8192','n32768'):
  tables={m:[g for g in games.values()if g['label']==m+'@'+budget and(g['rule']in same)==(mode=='same_rank')]for m,games in game_rows.items()};a=bound(tables['geo_empty']);b=bound(tables['rule_static_v2']);strata[mode+'__'+budget]=dict(rules=len({g['rule']for g in tables['geo_empty']}),physical_per_model=len(tables['geo_empty']),geo_minus_static_bounds=[a[0]-b[1],a[1]-b[0]])

def decode(v):
 if isinstance(v,str):return v
 v=dict(v);v['to_square']=Square(**v['to_square'])
 if 'from_square'in v:v['from_square']=Square(**v['from_square']);return SemanticBoardMove(**v)
 return SemanticDropMove(**v)
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def val(s,cp,integer):
 w=lambda kind,t:round(cp[kind+'_weights'][t]*256)if integer else cp[kind+'_weights'][t]
 return sum((1 if p.owner==0 else-1)*w('board',p.current_type_id)for p in s.state.position.board if p is not None)+sum((s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t))*w('hand',t)for t in cp['hand_weights'])
counts=Counter();witness=None
for gs,fam,budget in sorted(k[1:]for k in qmap if k[0]=='geo_empty'and k[1]in same):
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 qa=qmap.get(('rule_static_v2',gs,fam,budget));qb=qmap['geo_empty',gs,fam,budget]
 if qa is None:continue
 assert qa['before_sha256']==qb['before_sha256'];counts['same_rank_matched_root_queries']+=1;counts['returned_action_differences']+=qa['returned_action']!=qb['returned_action'];s=GameSession.replay(compiled[gs],deserialize_game_record(json.dumps(roots[gs,fam]['record'])));assert digest(s.state)==qa['before_sha256'];leaves=[]
 for q in (qa,qb):
  leaf=copy(s)
  for v in q['decision_line']:
   a=decode(v)
   if isinstance(a,str):leaf.declare(a)
   else:leaf.submit(a)
  leaves.append(leaf)
 if any(l.result.status.value!='ongoing'for l in leaves):continue
 diffs={m:{'float':val(leaves[0],mods[gs,m],False)-val(leaves[1],mods[gs,m],False),'integer256':val(leaves[0],mods[gs,m],True)-val(leaves[1],mods[gs,m],True)}for m in ('rule_static_v2','geo_empty')};counts['two_ordinary_leaf_pairs']+=1
 flip=diffs['rule_static_v2']['float']*diffs['geo_empty']['float']<0 and diffs['rule_static_v2']['integer256']*diffs['geo_empty']['integer256']<0
 counts['strict_float_and_integer_leaf_preference_flips']+=flip
 if flip and witness is None:witness=dict(rule=gs,family=fam,budget=budget,root_sha256=digest(s.state),original_root=roots[gs,fam]['record'],queries={'static':qa,'geo':qb},leaf_records=[record_value(l.to_record())for l in leaves],static_leaf_minus_geo_leaf=diffs)
write_json(D/'rank-ratio-analysis.json',dict(status='PASS_DESCRIPTIVE_RANK_RATIO_RECEIPTS',counts=dict(counts),posthoc_unitfoe_strata=strata,first_sorted_legal_leaf_witness=witness,scope='POSTHOC rule-only same weakordering (includingties) groups,13same/3different rules; not randomized ratio-only intervention/populationquality. Existing actual rootqueries/PVs, noNative/games. Opposite float/int preferences amongTWOlegalordinary leaves show rankingsalone do notspecifythese additiveleafpreferences; NOT fulltree/minimax optimum, explanation of gameoutcomes or proofwhichactionisbetter. DifferentPVdepths/selection matter; current complete fitness/UNKNOWN remains authority forfiniteutility.'))
print('RANK_RATIO_RECEIPTS',dict(counts),strata)
