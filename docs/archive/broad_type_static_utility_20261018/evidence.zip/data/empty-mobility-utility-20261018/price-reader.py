"""Rule-only exact geometry price reconstruction; no query or outcome use."""
from pathlib import Path
import sys,json,time,os
from statistics import median
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.core.movement import empty_mobility
from generic_chess.core.coordinates import Square
D=R/'.local_agent/empty-mobility-utility-20261018';mods={(r['rule'],r['label']):r['checkpoint']for r in json.loads((D/'models.json').read_bytes())['rows']};saved={r['rule']:r for r in json.loads((D/'geometry-prices.json').read_bytes())['rows']};origins=0;types=0;start=time.perf_counter()
for row in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines()):
 for name in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 gs=row['rule'];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(row['rules']));n=c.board_size;raw={}
 for pt in c.piece_types:
  counts=[]
  for idx in range(n*n):
   s=Square(idx%n,idx//n);reference=empty_mobility(n,0,s,pt.movement_atoms);actual=c.empty_mobility[pt.type_id][0][idx];assert len(reference)==len(actual);counts.append(len(reference));origins+=1
  raw[pt.type_id]=sum(counts)/len(counts);types+=1
 assert raw==saved[gs]['raw'];m=median(raw[pt.type_id]for pt in c.piece_types if not pt.is_anchor);assert m==saved[gs]['median_raw'];cp=mods[gs,'geo_empty']
 for pt in c.piece_types:
  t=pt.type_id;b=0 if pt.is_anchor else max(1,min(round(1000*raw[t]/m),90000000))if m>0 else 1;h=0 if pt.is_anchor else round(b*.9)
  assert b==saved[gs]['board_values'][t]and h==saved[gs]['hand_values'][t];assert cp['board_weights'][t]==b/1000 and cp['hand_weights'][t]==h/1000
 assert set(cp['board_weights'])==set(cp['hand_weights'])==set(c.types_by_id)
write_json(D/'price-reader-result.json',dict(status='PASS_RULE_ONLY_GEOMETRY_PRICE_CONSTRUCTION',rules=len(saved),types=types,type_origins=origins,seconds=time.perf_counter()-start,scope='Exact unique empty-mobility mean/median/round/hand.9/checkpoint onall16savedrules/alltypes. No outcome fitting, generation, Native, training or changeddefault; occupied/fullgame semantics remain insearch, not represented by priceformula.'))
print('PRICE_CONSTRUCTION_PASS',len(saved),types,origins)
