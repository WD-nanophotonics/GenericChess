"""Descriptive candidate equality/ranking metadata, never fitting/outcome evidence."""
import json,pathlib,itertools,sys
R=pathlib.Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/empty-mobility-utility-20261018';rows=json.loads((D/'models.json').read_bytes())['rows'];mods={(r['rule'],r['label']):r['checkpoint']for r in rows};rr=[]
for gs in sorted({r['rule']for r in rows}):
 a=mods[gs,'geo_empty'];b=mods[gs,'rule_static_v2'];t=[t for t,v in a['board_weights'].items()if v!=0];pairs=[]
 for x,y in itertools.combinations(t,2):
  da=a['board_weights'][x]-a['board_weights'][y];db=b['board_weights'][x]-b['board_weights'][y]
  if (da>0)-(da<0)!=(db>0)-(db<0):pairs.append(dict(types=[x,y],geo_difference=da,static_difference=db))
 rr.append(dict(rule=gs,size=gs%100,nonanchors=len(t),active_board_equal=all(round(a['board_weights'][k]*256)==round(b['board_weights'][k]*256)for k in a['board_weights']),active_hand_equal=all(round(a['hand_weights'][k]*256)==round(b['hand_weights'][k]*256)for k in a['hand_weights']),board_rank_differences=pairs))
write_json(D/'profile-comparison.json',dict(status='RECORDED_CANDIDATE_PROFILE_DIFFERENCES',rows=rr,scope='Ruleonly candidate equality/ranking metadata; not fitness, exactpiecevalue or evidence changedtie/action isuseful. All originalgames retained even iftables coincide.'))
print('PROFILE_METADATA_PASS',len(rr))
