"""Saved paired trajectory first-divergence audit, no search/outcome selection."""
from pathlib import Path
from collections import defaultdict,Counter
from copy import copy
import json,sys,hashlib,os,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=R/'.local_agent/empty-mobility-utility-20261018';I=R/'.local_agent/broad-static-utility-20261018';same={r['rule']for r in json.loads((D/'profile-comparison.json').read_bytes())['rows']if not r['board_rank_differences']};roots={(r['rule'],r['family']):r for r in json.loads((D/'roots.json').read_bytes())['rows']};mods={(r['rule'],r['label']):r['checkpoint']for r in json.loads((D/'models.json').read_bytes())['rows']};compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines())};maps={};counts=Counter();rows=[];start=time.perf_counter()
for directory,model in[(I,'rule_static_v2'),(D,'geo_empty')]:
 games={g['slot']:g for g in map(json.loads,(directory/'games.jsonl').read_bytes().splitlines())if g['label'].startswith(model+'@')and(directory==I or g['foe']=='unit')};qs=defaultdict(list)
 for q in map(json.loads,(directory/'queries.jsonl').read_bytes().splitlines()):
  if q['slot']in games:qs[q['slot']].append(q)
 maps[model]={(g['rule'],g['family'],g['candidate_owner'],g['label'].split('@')[1]):(g,qs[slot])for slot,g in games.items()}
assert maps['rule_static_v2'].keys()==maps['geo_empty'].keys()
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(v):
 if isinstance(v,str):return v
 v=dict(v);v['to_square']=Square(**v['to_square'])
 if 'from_square'in v:v['from_square']=Square(**v['from_square']);return SemanticBoardMove(**v)
 return SemanticDropMove(**v)
def submit(s,v):
 a=decode(v)
 if isinstance(a,str):s.declare(a)
 else:s.submit(a)
def value(s,cp,integer):
 w=lambda kind,t:round(cp[kind+'_weights'][t]*256)if integer else cp[kind+'_weights'][t]
 return sum((1 if p.owner==0 else-1)*w('board',p.current_type_id)for p in s.state.position.board if p is not None)+sum((s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t))*w('hand',t)for t in cp['hand_weights'])
for key in sorted(maps['geo_empty']):
 assert time.perf_counter()-start<300
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 gs,fam,owner,budget=key;ga,qa=maps['rule_static_v2'][key];gb,qb=maps['geo_empty'][key];s=GameSession.replay(compiled[gs],deserialize_game_record(json.dumps(roots[gs,fam]['record'])));entry=dict(rule=gs,family=fam,owner=owner,budget=budget,same_board_weakordering=gs in same,first_divergence=None,common_commits=0);counts['paired_physical_games']+=1
 for a,b in zip(qa,qb):
  assert a['relative_ply']==b['relative_ply'];assert a['before_sha256']==b['before_sha256']==digest(s.state);counts['identical_parent_query_pairs']+=1
  if a['committed']!=b['committed']:
   actor=s.state.position.side_to_move;rec=dict(relative_ply=a['relative_ply'],actor=actor,candidate_turn=actor==owner,before_sha256=digest(s.state),parent_record=record_value(s.to_record()),static_query=a,geo_query=b);leaves=[]
   for q in(a,b):
    leaf=copy(s)
    for move in q['decision_line']:submit(leaf,move)
    leaves.append(leaf)
   if all(l.result.status.value=='ongoing'for l in leaves):
    diffs={m:{'float':value(leaves[0],mods[gs,m],False)-value(leaves[1],mods[gs,m],False),'integer256':value(leaves[0],mods[gs,m],True)-value(leaves[1],mods[gs,m],True)}for m in('rule_static_v2','geo_empty')};rec['two_ordinary_leaf_preference_differences']=diffs;flip=diffs['rule_static_v2']['float']*diffs['geo_empty']['float']<0 and diffs['rule_static_v2']['integer256']*diffs['geo_empty']['integer256']<0;rec['strict_float_and_int_two_leaf_flip']=flip;counts['ordinary_leaf_pairs']+=1;counts['strict_two_leaf_flips']+=flip
    if gs in same:counts['same_rank_strict_two_leaf_flips']+=flip
   for q in(a,b):
    child=copy(s)
    if q['committed']is not None:submit(child,q['committed']);assert digest(child.state)==q['after_sha256'];counts['divergence_child_checks']+=1
   entry['first_divergence']=rec;counts['candidate_first_divergences'if actor==owner else'foe_first_divergences']+=1
   if gs in same:counts['same_rank_first_divergences']+=1
   break
  if a['committed']is not None:submit(s,a['committed']);entry['common_commits']+=1;counts['common_core_commits']+=1
  assert digest(s.state)==a['after_sha256']==b['after_sha256']
 else:
  assert len(qa)==len(qb),'Unequal traces without a recordedfirstdivergence';assert ga['record']==gb['record']and ga['reward']==gb['reward'];counts['identical_complete_traces']+=1
 rows.append(entry)
write_json(D/'trajectory-divergence.json',dict(status='PASS_ALL_PAIRED_FIRST_DIVERGENCE_FULL_CONTEXTS',counts=dict(counts),rows=rows,seconds=time.perf_counter()-start,scope='ALL128static/geo physical pairs againstsamefixedUnitfoe, no resultfilter/newsearch. Exactsharedparent/history andbothdivergentchildren/PVsreplayed; actualcaps/causes/depths retained. Sameweakordering isdescriptive, notisolatedratiointervention. Twolegal leafpreference flips doNOTprove fulltree/minimaxoptimality, qualityofaction orcauseofgameoutcome. No claimfromchangedactionsalone; allplannedoutcomeboundsremain.'))
print('PAIRED_TRAJECTORY_PASS',dict(counts),time.perf_counter()-start)
