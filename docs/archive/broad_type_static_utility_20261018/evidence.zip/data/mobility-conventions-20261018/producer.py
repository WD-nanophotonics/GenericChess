"""Finite direct-coordinate versus Core geometry counts, with explicit conventions."""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import sys,json,time,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from generic_chess.core.movement import LeapAtom,RayAtom,empty_mobility
from generic_chess.core.coordinates import Square
D=R/'.local_agent/mobility-conventions-20261018';P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));counts=Counter();rows=[]
king=tuple(LeapAtom((x,y))for x in[-1,0,1]for y in[-1,0,1]if x or y);bishop=tuple(RayAtom((x,y))for x in[-1,1]for y in[-1,1]);rook=tuple(RayAtom((x,y))for x,y in[(-1,0),(1,0),(0,-1),(0,1)]);atoms={'kinglike8':king,'diagonalrider':bishop,'orthogonalrider':rook,'queen_union':bishop+rook,'diagonalrider_plus_kinglike':bishop+king,'orthogonalrider_plus_kinglike':rook+king}
def poll():
 assert time.perf_counter()-start<P['limits']['seconds'],'FROZEN_CAP'
 for name in ['rollout','advisor','slack']:
  q=json.loads((STOP/'.local_agent'/(name+'.json')).read_bytes());assert not(q.get('stopped')or q.get('user_paused')),'EXPLICIT_STOP'
for n in P['board_sizes']:
 poll();total=Counter();colors={0:Counter(),1:Counter()};origins=Counter()
 for x in range(n):
  for y in range(n):
   poll();origin=(x+y)%2;origins[origin]+=1;targets={name:set()for name in atoms}
   # Direct coordinate predicates deliberately independent of Core ray traversal.
   for u in range(n):
    for v in range(n):
     dx=abs(u-x);dy=abs(v-y)
     if dx==dy==0:continue
     k=max(dx,dy)==1;b=dx==dy;r=dx==0 or dy==0
     for name,allowed in [('kinglike8',k),('diagonalrider',b),('orthogonalrider',r),('queen_union',b or r),('diagonalrider_plus_kinglike',b or k),('orthogonalrider_plus_kinglike',r or k)]:
      if allowed:targets[name].add((u,v))
   for name,aa in atoms.items():
    actual={(s.file,s.rank)for s in empty_mobility(n,0,Square(x,y),aa)};assert actual==targets[name],(n,x,y,name);total[name]+=len(actual);colors[origin][name]+=len(actual);counts['per_origin_piece_sets']+=1
   counts['origins']+=1
 K=4*(n-1)*(2*n-1);B=2*n*(n-1)*(2*n-1)//3;RR=2*n*n*(n-1);assert total['kinglike8']==K and total['diagonalrider']==B and total['orthogonalrider']==RR;assert total['queen_union']==B+RR;assert total['diagonalrider_plus_kinglike']==B+K-4*(n-1)**2;assert total['orthogonalrider_plus_kinglike']==RR+K-4*n*(n-1)
 assert Fraction(B,K)==Fraction(n,6);assert Fraction(B,2*K)==Fraction(n,12)
 rows.append(dict(n=n,ordered_distinct_pairs=n*n*(n*n-1),all_origin_totals=dict(total),fixed_color_origin_totals={str(c):dict(t)for c,t in colors.items()},color_origin_counts=dict(origins),ordinary_diagonal_over_king=str(Fraction(B,K)),half_diagonal_total_over_king=str(Fraction(B,2*K)),diagonal_half_sum=str(Fraction(B,2)),fixed_colors_equal_half_sum={str(c):Fraction(colors[c]['diagonalrider'])==Fraction(B,2)for c in [0,1]},overlap_excess_if_additive=dict(diagonal_plus_king=B+K-total['diagonalrider_plus_kinglike'],orthogonal_plus_king=RR+K-total['orthogonalrider_plus_kinglike'])))
q=dict(status='PASS_FINITE_GEOMETRY_CONVENTIONS',source_plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),counts=dict(counts),rows=rows,seconds=time.perf_counter()-start,scope='Finiteemptyboarddirectpredicate/Coredestination-setchecks. All-origin versusfixedcolorversushalf-sum definitions explicitlydifferent; distinctdestinationsnotadditivewhencomponents overlap. No occupied-boardlegality, royalKing/chess/shogi semantics equivalence, materialprice, WDL or learningclaim. Paper half-total is its stated convention, not automatically an implementationerror.');write_json(D/'result.json',q);print('GEOMETRY_PASS',dict(counts),q['seconds'],flush=True)
