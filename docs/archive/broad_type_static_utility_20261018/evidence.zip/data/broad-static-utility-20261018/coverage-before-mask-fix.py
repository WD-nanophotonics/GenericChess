"""Describe actual admitted generated mechanisms; not a domain-completeness claim."""
from pathlib import Path
import json,sys
from collections import Counter
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/broad-static-utility-20261018';rs=list(map(json.loads,(D/'generation.jsonl').read_bytes().splitlines()));counts=Counter();rows=[]
for r in rs:
 if 'rules'not in r:counts[r['status']]+=1;continue
 rule=r['rules'];types=rule['piece_types'];hy=[t['type_id']for t in types if len({a['kind']for a in t['movement_atoms']})>1];nonunitray=sum(a['kind']=='ray'and max(map(abs,a['direction']))>1 for t in types for a in t['movement_atoms']);prom=[dict(type=t['type_id'],targets=t['promotion_target_ids'])for t in types if t['is_promotable']];counts['rules']+=1;counts['drop_allowed_rules']+=rule['drop_allowed'];counts['promotion_allowed_rules']+=rule['promotion_allowed'];counts['hybrid_rules']+=bool(hy);counts['hybrid_types']+=len(hy);counts['nonunit_direction_ray_atoms']+=nonunitray
 rows.append(dict(rule=r['rule'],size=r['size'],types=[t['type_id']for t in types],hybrid_types=hy,promotion_targets=prom,drop_allowed=rule['drop_allowed'],promotion_allowed=rule['promotion_allowed'],repetition_limit=rule['repetition_limit'],max_ply=rule['max_ply'],native_admission=r['status']))
write_json(D/'coverage.json',dict(status='ACTUAL_GENERATED_MECHANISM_COVERAGE',counts=dict(counts),rows=rows,scope='Actualfullsample descriptors only; preserving generatedpromotion/drop/repetition andalltype inputs does not cover every possible RuleIR/state/history or independently certify engine semantics.'))
print(dict(counts))
