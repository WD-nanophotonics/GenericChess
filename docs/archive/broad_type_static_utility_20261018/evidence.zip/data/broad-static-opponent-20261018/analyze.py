"""Finite planned-slot outcome bounds and actual paid resource curves; no fitting."""
from pathlib import Path
from collections import Counter,defaultdict
import json,sys,random,statistics
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));from tools.local_agent.common import write_json
D=ROOT/'.local_agent/broad-static-opponent-20261018';p=json.loads((D/'plan.json').read_bytes());result=json.loads((D/'result.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['slots'];games={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};rows=[]
for slot,(rule,family,label,owner)in enumerate(slots):
 g=games.get(slot);rows.append(dict(slot=slot,rule=rule,seed=rule//100,size=rule%100,family=family,label=label,owner=owner,reward=None if g is None else g['reward'],ending='UNSTARTED_UNKNOWN'if g is None else g['ending'],game=g))
assert len(rows)==256 and len(games)==result['returned_physical'];qq=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));assert len(qq)==result['counts']['queries']
def bounds(rr):
 values=[r['reward']for r in rr];n=len(values);known=sum(x for x in values if x is not None);u=sum(x is None for x in values);return dict(planned=n,unknown=u,W=sum(x==1 for x in values),D=sum(x==0 for x in values),L=sum(x==-1 for x in values),reward_bounds=[(known-u)/n,(known+u)/n],endings=dict(Counter(r['ending']for r in rr)),actual_queries=sum((r['game']or{}).get('queries',0)for r in rr),actual_nodes=sum((r['game']or{}).get('nodes',0)for r in rr),game_seconds=sum((r['game']or{}).get('game_seconds',0.)for r in rr),caller_seconds=sum((r['game']or{}).get('caller_seconds',0.)for r in rr),kernel_seconds=sum((r['game']or{}).get('kernel_seconds',0.)for r in rr))
def contrast(rr,budget):
 a=[r for r in rr if r['label']=='rule_static_v2@'+budget];b=[r for r in rr if r['label']=='unit@'+budget];ka={(r['rule'],r['family'],r['owner']):r for r in a};kb={(r['rule'],r['family'],r['owner']):r for r in b};assert ka.keys()==kb.keys();lo=hi=0.;pairs=Counter()
 for k,x in ka.items():
  y=kb[k];xx=[-1.,1.]if x['reward']is None else[x['reward']]*2;yy=[-1.,1.]if y['reward']is None else[y['reward']]*2;lo+=xx[0]-yy[1];hi+=xx[1]-yy[0];pairs['both_known']+=x['reward']is not None and y['reward']is not None;pairs['both_unknown']+=x['reward']is None and y['reward']is None;pairs['one_unknown']+=(x['reward']is None)!=(y['reward']is None)
 return dict(paired_cells=len(a),reward_difference_bounds=[lo/len(a),hi/len(a)],pairs=dict(pairs))
labels=sorted({r['label']for r in rows});overall={label:bounds([r for r in rows if r['label']==label])for label in labels};byboard={str(n):{label:bounds([r for r in rows if r['size']==n and r['label']==label])for label in labels}for n in p['board_sizes']};contrasts={budget:contrast(rows,budget)for budget in p['budgets']};perseed={str(seed):{b:contrast([r for r in rows if r['seed']==seed],b)for b in p['budgets']}for seed in p['seeds']}
# Explicit posthoc descriptive block envelope; repeated families/roles/depths linked.
rng=random.Random(2026101812);boot=defaultdict(list)
for _ in range(10000):
 selected=[rng.choice(p['seeds'])for __ in p['seeds']]
 for b in p['budgets']:
  pairs=[perseed[str(s)][b]['reward_difference_bounds']for s in selected];boot[b].append([sum(x[i]for x in pairs)/len(pairs)for i in [0,1]])
envelopes={b:[sorted(x[0]for x in rr)[249],sorted(x[1]for x in rr)[9749]]for b,rr in boot.items()}
work={}
for label in labels:
 ids={r['slot']for r in rows if r['label']==label};sq=[q for q in qq if q['slot']in ids];work[label]={}
 for side in ['candidate','foe']:
  qs=[q for q in sq if q['candidate_turn']==(side=='candidate')];work[label][side]=dict(queries=len(qs),nodes=sum(q['nodes']for q in qs),caller_seconds=sum(q['caller_seconds']for q in qs),kernel_seconds=sum(q['kernel_seconds']for q in qs),completed_depth_histogram=dict(Counter(q['completed_depth']for q in qs)),causes=dict(Counter(q['cause']for q in qs)),fallbacks=sum(q['used_fallback']for q in qs))
terminal_zero=[r for r in rows if r['game']and r['game']['queries']==0 and r['ending']=='ACTUAL_TERMINAL'];ongoing_keys={(r['rule'],r['family'])for r in rows if r['game']and r['game']['queries']>0};ongoing_rows=[r for r in rows if(r['rule'],r['family'])in ongoing_keys];sub={b:contrast(ongoing_rows,b)for b in p['budgets']}if ongoing_rows else{}
low=contrasts['n8192']['reward_difference_bounds'];high=contrasts['n32768']['reward_difference_bounds'];interaction=[high[0]-low[1],high[1]-low[0]]
within_models={}
for model in p['candidate_models']:
 a=overall[model+'@n8192']['reward_bounds'];b=overall[model+'@n32768']['reward_bounds'];within_models[model]=dict(high_minus_low_reward_bounds=[b[0]-a[1],b[1]-a[0]],actual_node_ratio=overall[model+'@n32768']['actual_nodes']/max(1,overall[model+'@n8192']['actual_nodes']),game_wall_ratio=overall[model+'@n32768']['game_seconds']/max(1e-12,overall[model+'@n8192']['game_seconds']))
q=dict(within_model_budget_contrasts=within_models,budget_difference_of_contrasts=dict(high_minus_low_reward_bounds=interaction,scope='Static-minus-Unit contrast at32768 minus8192; allfour physical arms retained, UNKNOWN interval endpoints notimputed. Budget plus finite selective search changes, notpuredepthcausalclaim.'),status='PASS_PLANNED_SLOT_BOUNDS_AND_COST',source_plan_sha256=__import__('hashlib').sha256((D/'plan.json').read_bytes()).hexdigest(),overall=overall,static_minus_unit=contrasts,by_board=byboard,by_board_contrasts={str(n):{b:contrast([r for r in rows if r['size']==n],b)for b in p['budgets']}for n in p['board_sizes']},by_seed=perseed,descriptive_linked_seed_envelopes=dict(seed=2026101812,resamples=10000,independent_seed_blocks=8,intervals=envelopes,scope='POSTHOC descriptive8linkedseedblocks, bothboards/families/roles/budgets retained together. Not binomial independentgames, confidence guarantee, outcome fitting or population winner.'),actual_work=work,actual_producer_seconds=result['seconds'],zero_query_terminal_slots=len(terminal_zero),ongoing_root_paired_contrasts=sub,counts=dict(planned=256,returned=len(games),unstarted=256-len(games),physical_queries=len(qq)),scope='Finiteconditionalreward[-1,1] bounds, static-minus-Unit rawreward in[-2,2], fixedSTATICD2foe; UNKNOWN incl missing remains[-1,1], neverdraw. Nodecap curves, not equalwall/depth.8seeds16rules32prefixes not256independentrules; optionalongoing-rootstratum is descriptive. No training/default/populationclaim.');write_json(D/'analysis.json',q);print(json.dumps(dict(overall=overall,contrasts=contrasts,envelopes=envelopes,byboard=q['by_board_contrasts'],zero_query_terminal_slots=len(terminal_zero)),indent=2),flush=True)
