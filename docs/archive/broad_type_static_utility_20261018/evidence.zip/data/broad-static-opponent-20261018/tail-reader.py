"""Reconstruct persisted interrupted tail only; no original outcome/footer recovery."""
from pathlib import Path
import json,hashlib,sys,os
from copy import copy
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=ROOT/'.local_agent/broad-static-opponent-20261018'
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
closed=list(map(json.loads,(D/'games.jsonl').read_bytes().splitlines()));tail=list(map(json.loads,(D/'unclosed-queries.jsonl').read_bytes().splitlines()));slot=tail[0]['slot'];assert not any(g['slot']==slot for g in closed)
gs,fam,label,owner=json.loads((D/'slots.json').read_bytes())['slots'][slot];gr=next(r for r in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines())if r['rule']==gs);c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(gr['rules']));root=next(r for r in json.loads((D/'roots.json').read_bytes())['rows']if(r['rule'],r['family'])==(gs,fam));s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));pv=commits=0
for idx,q in enumerate(tail):
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',ROOT))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 assert q['slot']==slot and q['relative_ply']==idx and digest(s.state)==q['before_sha256'];leaf=copy(s)
 for a in q['decision_line']:
  a=decode(a)
  if isinstance(a,str):leaf.declare(a)
  else:leaf.submit(a);pv+=1
 if q['committed']is not None:
  a=decode(q['committed'])
  if isinstance(a,str):s.declare(a)
  else:s.submit(a);commits+=1
 assert digest(s.state)==q['after_sha256']
assert s.result.status.value=='ongoing'
write_json(D/'tail-audit.json',dict(status='PASS_DERIVED_INTERRUPTED_QUERY_TAIL_CORE',slot=slot,queries=len(tail),PV_core_edges=pv,committed_core_edges=commits,paid_nodes=sum(q['nodes']for q in tail),observed_result_from_reconstruction=record_value(s.result),reconstructed_record=json.loads(serialize_game_record(s.to_record())),reconstructed_state_sha256=digest(s.state),original_final_game_record_present=False,outcome_in_planned_analysis='UNKNOWN',scope='Derived exact root+persisted query replay, not recovery of an original producerfooter/finalrecord or new search/outcome. Original partialjournals unchanged; all144missing/unclosed outcomes stayUNKNOWN.'))
print('TAIL_CORE_PASS',len(tail),pv,commits)
