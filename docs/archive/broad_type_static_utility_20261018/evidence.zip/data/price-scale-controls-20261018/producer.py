"""Active-integer positive scaling control on complete saved root/midgame inputs."""
from pathlib import Path
import sys,json,time,hashlib,random,os,subprocess
from copy import copy
from dataclasses import replace
from collections import defaultdict,Counter
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=R/'.local_agent/price-scale-controls-20261018';I=R/'.local_agent/broad-static-utility-20261018';P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();counts=Counter();rows=[];status='COMPLETE';reason=None
assert not(D/'started.json').exists()
write_json(D/'started.json',dict(pid=os.getpid(),started_at_utc=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),base_sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()))
for name,sha in P['source_inputs'].items():assert hashlib.sha256((I/name).read_bytes()).hexdigest()==sha
compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(I/'generation.jsonl').read_bytes().splitlines())if 'rules'in r};native={gs:compile_native_semantic_rules(c)for gs,c in compiled.items()};roots=json.loads((I/'roots.json').read_bytes())['rows'];mods={(r['rule'],r['label']):LearnableMaterialCheckpoint.from_dict(r['checkpoint'])for r in json.loads((I/'models.json').read_bytes())['rows']};games=[r for r in map(json.loads,(I/'games.jsonl').read_bytes().splitlines())if r['label']=='unit@n8192'and r['candidate_owner']==0];qby=defaultdict(list)
for q in map(json.loads,(I/'queries.jsonl').read_bytes().splitlines()):qby[q['slot']].append(q)
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(v):
 if isinstance(v,str):return v
 a=dict(v);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
def poll():
 assert time.perf_counter()-start<P['limits']['global_seconds'],'FROZEN_CAP'
 for name in ['rollout','advisor','slack']:
  q=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());assert not(q.get('stopped')or q.get('user_paused')),'EXPLICIT_STOP'
contexts=[dict(rule=r['rule'],family=r['family'],phase='prefix',record=r['record'],state_sha256=r['state_sha256'])for r in roots]
for g in games:
 qs=qby[g['slot']]
 if not qs:continue
 chosen=next((q for q in qs if q['relative_ply']>=16),qs[-1]);root=next(r for r in roots if(r['rule'],r['family'])==(g['rule'],g['family']));s=GameSession.replay(compiled[g['rule']],deserialize_game_record(json.dumps(root['record'])))
 for q in qs:
  assert digest(s.state)==q['before_sha256']
  if q is chosen:break
  if q['committed']is not None:
   a=decode(q['committed'])
   if isinstance(a,str):s.declare(a)
   else:s.submit(a)
 contexts.append(dict(rule=g['rule'],family=g['family'],phase='midgame',source_slot=g['slot'],source_relative_ply=chosen['relative_ply'],record=json.loads(serialize_game_record(s.to_record())),state_sha256=digest(s.state)))
write_json(D/'contexts.json',dict(rows=contexts,unique_full_states=len({r['state_sha256']for r in contexts}),scope='Outcome-blind structuralselection fromfrozen Unitlow owner0 streams; actualterminalroots kept, duplicatefullstatesnotindependentsamples.'))
try:
 with(D/'queries.jsonl').open('x',encoding='utf8')as out:
  for ix,ctx in enumerate(contexts):
   poll();gs=ctx['rule'];c=compiled[gs];s=GameSession.replay(c,deserialize_game_record(json.dumps(ctx['record'])));assert digest(s.state)==ctx['state_sha256'];counts['contexts']+=1
   for model in P['profiles']:
    base=mods[gs,model];ww={kind:{t:round(w*256)for t,w in getattr(base,kind+'_weights').items()}for kind in ['board','hand']};assert set(ww['board'])==set(ww['hand'])==set(c.types_by_id)
    for budget in P['budgets']:
     cases=[]
     for mult in ([1,4]if(ix+budget)%2==0 else[4,1]):
      poll();cp=replace(base,board_weights={t:w*mult/256 for t,w in ww['board'].items()},hand_weights={t:w*mult/256 for t,w in ww['hand'].items()},evaluation_profile_version='exact-active-int-scale-'+str(mult));assert all(round(getattr(cp,k+'_weights')[t]*256)==v*mult for k,ws in ww.items()for t,v in ws.items());before=(s.state,s.to_record(),s.history,s._search_witnesses);eng=SemanticSearchEngine(c,native[gs],checkpoint=cp,tt_megabytes=0);tick=time.perf_counter();r=eng.search(s,SearchLimits(max_depth=8,max_nodes=budget,max_time_seconds=5.,quiescence_max_depth=0),root_window_pruning=False);elapsed=time.perf_counter()-tick;assert before==(s.state,s.to_record(),s.history,s._search_witnesses);row=dict(context=ix,rule=gs,family=ctx['family'],phase=ctx['phase'],model=model,budget=budget,multiplier=mult,checkpoint=cp.to_dict(),state_sha256=ctx['state_sha256'],root_result=record_value(s.result),action=record_value(r.action),declaration_id=r.declaration_id,decision_line=record_value(r.decision_line),score=r.score,completed_depth=r.completed_depth,nodes=r.nodes,qnodes=r.qnodes,fallback=r.used_fallback,cause=r.termination_reason,caller_seconds=elapsed,kernel_seconds=r.elapsed_seconds);cases.append(row);rows.append(row);counts['queries']+=1;counts['nodes']+=r.nodes;out.write(json.dumps(row,separators=(',',':'))+'\n');out.flush()
     a=next(r for r in cases if r['multiplier']==1);b=next(r for r in cases if r['multiplier']==4)
     for key in ['action','declaration_id','decision_line','completed_depth','nodes','qnodes','fallback','cause']:counts[key+'_different_pairs']+=a[key]!=b[key]
   if(ix+1)%8==0:print('SCALE_CONTEXTS',ix+1,'queries',counts['queries'],'seconds',round(time.perf_counter()-start,3),flush=True)
   if out.tell()>P['limits']['max_output_bytes']:raise TimeoutError('OUTPUT_CAP')
except BaseException as exc:status='PARTIAL_CAP'if isinstance(exc,(TimeoutError,AssertionError))else'ERROR';reason=repr(exc);__import__('traceback').print_exc()
write_json(D/'result.json',dict(status=status,reason=reason,planned_contexts=len(contexts),planned_queries=len(contexts)*8,counts=dict(counts),missing_queries=len(contexts)*8-counts['queries'],seconds=time.perf_counter()-start,scope='Finite exactactiveintcoefficients x4 underq0TT0/root_windowFalse,nodebounds5s allowance. Changes/missing retained; noalltrajectory/globalnormalization, learninginvariance, fitness/WDL ordefaultclaim.'));print('SCALE_CLOSED',status,dict(counts),time.perf_counter()-start,flush=True)
