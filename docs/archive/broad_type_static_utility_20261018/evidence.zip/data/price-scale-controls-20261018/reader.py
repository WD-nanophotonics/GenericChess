"""Search-free complete-state/PV and active-int scaling receipt audit."""
from pathlib import Path
from collections import defaultdict,Counter
from copy import copy
import sys,json,time,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=R/'.local_agent/price-scale-controls-20261018';I=R/'.local_agent/broad-static-utility-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));start=time.perf_counter();compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(I/'generation.jsonl').read_bytes().splitlines())if 'rules'in r};contexts=json.loads((D/'contexts.json').read_bytes())['rows'];mods={(r['rule'],r['label']):r['checkpoint']for r in json.loads((I/'models.json').read_bytes())['rows']};counts=Counter();paired=defaultdict(dict)
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(v):
 if isinstance(v,str):return v
 a=dict(v);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
for q in map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()):
 assert time.perf_counter()-start<300
 for name in ['rollout','advisor','slack']:
  v=json.loads((STOP/'.local_agent'/(name+'.json')).read_bytes());assert not(v.get('stopped')or v.get('user_paused'))
 ctx=contexts[q['context']];c=compiled[ctx['rule']];s=GameSession.replay(c,deserialize_game_record(json.dumps(ctx['record'])));assert digest(s.state)==ctx['state_sha256']==q['state_sha256'];assert record_value(s.result)==q['root_result'];cp=q['checkpoint'];base=mods[ctx['rule'],q['model']]
 for kind in ['board','hand']:
  assert set(cp[kind+'_weights'])==set(c.types_by_id)
  for t,v in cp[kind+'_weights'].items():assert round(v*256)==q['multiplier']*round(base[kind+'_weights'][t]*256)
 if s.result.status.value!='ongoing':
  assert q['cause']=='terminal_position'and q['action']is None and not q['decision_line']and q['completed_depth']==0 and q['score']==0;counts['terminal_root_nonsearch_receipts']+=1
 else:
  before=(s.state,s.history,s.to_record(),s._search_witnesses);leaf=copy(s)
  for v in q['decision_line']:
   a=decode(v)
   if isinstance(a,str):leaf.declare(a)
   else:leaf.submit(a);counts['PV_edges']+=1
  assert before==(s.state,s.history,s.to_record(),s._search_witnesses)
  if q['completed_depth']>=1 and not q['fallback']:
   assert q['decision_line']and q['decision_line'][0]==(q['declaration_id']or q['action'])
   if leaf.result.status.value=='ongoing':
    val=sum((1 if pc.owner==0 else-1)*round(cp['board_weights'][pc.current_type_id]*256)for pc in leaf.state.position.board if pc is not None)+sum((leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t))*round(w*256)for t,w in cp['hand_weights'].items());counts['ordinary_leaf']+=1
   else:
    assert leaf.result.declaration_outcome not in ['RESTART','NO_CONTEST'];val=0 if leaf.result.winner is None else(100000000-len(q['decision_line']))*(1 if leaf.result.winner==0 else-1);counts['terminal_leaf']+=1
   assert val==q['score']*(1 if s.state.position.side_to_move==0 else-1)
  else:counts['unusable_queries']+=1
 paired[q['context'],q['model'],q['budget']][q['multiplier']]=q;counts['queries']+=1;counts['nodes']+=q['nodes']
for k,v in paired.items():
 assert set(v)=={1,4};a,b=v[1],v[4]
 for field in ['action','declaration_id','decision_line','completed_depth','nodes','qnodes','fallback','cause']:assert a[field]==b[field],(k,field)
 counts['paired_controls']+=1
result=json.loads((D/'result.json').read_bytes());assert counts['queries']==result['counts']['queries']and counts['nodes']==result['counts']['nodes']
write_json(D/'reader-result.json',dict(status='PASS_ALL_SCALE_CONTROL_CORE_RECEIPTS',counts=dict(counts),seconds=time.perf_counter()-start,scope='Every fullroot/modelbinding/PV andordinary quantizedleafscore; terminalroot API zero is a nonsearchreceipt, notthe Core outcome/WDL. Positiveexactintx4 policy/work equivalence onfinitepairedinputs, notwholetrajectories orlearninginvariance. NoNativequery/generation/training rerun.'));print('SCALE_READER_PASS',dict(counts),time.perf_counter()-start,flush=True)
