"""Exact finite occupancy counterexample for identical empty-target geometry."""
from pathlib import Path
from fractions import Fraction
from itertools import product
import sys,json,time,os,math
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from generic_chess.core.coordinates import Square
from generic_chess.core.movement import LeapAtom,RayAtom,empty_mobility
from generic_chess.ai.evaluation.mobility import analytic_mobility_at_density
D=R/'.local_agent/empty-equivalent-blockers-20261018';p=json.loads((D/'plan.json').read_bytes());n=p['board_size'];start=time.perf_counter();ray=tuple(RayAtom(v)for v in[(1,0),(-1,0),(0,1),(0,-1)]);leap=tuple(LeapAtom((a*k,b*k))for a,b in[(1,0),(-1,0),(0,1),(0,-1)]for k in range(1,n));ds=list(map(Fraction,p['density_fractions']));sums={d:[Fraction(0),Fraction(0),Fraction(0)]for d in ds};patterns=0;different=0;witness=None
for x in range(n):
 for y in range(n):
  assert time.perf_counter()-start<p['max_seconds']
  for name in ('rollout','advisor','slack'):
   f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
  a=empty_mobility(n,0,Square(x,y),ray);b=empty_mobility(n,0,Square(x,y),leap);assert a==b;cells=sorted((s.file,s.rank)for s in a);assert len(cells)==6
  for states in product((0,1,2),repeat=len(cells)):
   occ=dict(zip(cells,states));jump=sum(v!=1 for v in states);walk=0
   for dx,dy in[(1,0),(-1,0),(0,1),(0,-1)]:
    for k in range(1,n):
     t=x+dx*k,y+dy*k
     if not(0<=t[0]<n and 0<=t[1]<n):break
     v=occ[t]
     if v!=1:walk+=1
     if v:break
   patterns+=1;different+=walk!=jump
   if walk!=jump and witness is None:witness=dict(origin=[x,y],line_states=[dict(square=list(t),state=v)for t,v in occ.items()],rider_targets=walk,finite_leaper_targets=jump)
   empty=states.count(0);occupied=6-empty
   for d in ds:
    prob=(1-d)**empty*(d/2)**occupied;sums[d][0]+=prob*walk;sums[d][1]+=prob*jump;sums[d][2]+=prob
rows=[]
for d,(r,l,mass)in sums.items():
 assert mass==n*n;r/=n*n;l/=n*n
 assert math.isclose(float(r),analytic_mobility_at_density(n,ray,float(d)),abs_tol=1e-12);assert math.isclose(float(l),analytic_mobility_at_density(n,leap,float(d)),abs_tol=1e-12)
 assert l==6*(1-d/2);assert (r==l)if d==0 else(r<l)
 rows.append(dict(density=str(d),exact_rider=str(r),exact_finite_leaper=str(l),leaper_minus_rider=str(l-r)))
write_json(D/'result.json',dict(status='PASS_EMPTY_EQUIVALENT_BLOCKER_COUNTEREXAMPLE',origins=16,complete_relevant_occupancy_patterns=patterns,patterns_with_different_mobility=different,rows=rows,first_sorted_witness=witness,seconds=time.perf_counter()-start,scope='Identicalemptytargetsets atALLorigins on4x4, different exact independentoccupancy pseudo-target means atpositive densities. Currentstaticmobility formula matches allenumerated means. Off-linecells marginalized exactly; no claimabout royallegality, gamevalue, observedutilitycause, searchoptimality orall-domainperformance. Notgroundsfora newAPI/learner/prover orretrospectivegameexclusion.'))
print('BLOCKER_COLLISION_PASS',patterns,different,rows,time.perf_counter()-start)
