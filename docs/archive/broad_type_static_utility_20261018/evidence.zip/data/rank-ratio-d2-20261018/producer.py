"""Existing full CoreD2 enumeration pattern on new posthoc ratio diagnostic states."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib,os,gzip
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=R/'.local_agent/rank-ratio-d2-20261018';I=R/'.local_agent/empty-mobility-utility-20261018';P=json.loads((D/'plan.json').read_bytes());assert not(D/'started.json').exists();write_json(D/'started.json',dict(plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()));start=time.perf_counter();counts=Counter();rows=[];active=None;status='COMPLETE';reason=None
for name,sha in P['source_inputs'].items():assert hashlib.sha256((I/name).read_bytes()).hexdigest()==sha
compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(I/'generation.jsonl').read_bytes().splitlines())};models={(r['rule'],r['label']):r['checkpoint']for r in json.loads((I/'models.json').read_bytes())['rows']};contexts=json.loads((D/'contexts.json').read_bytes())['rows']
class RootCap(Exception):pass
def poll():
 assert time.perf_counter()-start<P['limits']['global_seconds'],'GLOBAL_CAP';assert counts['edges']<P['limits']['max_total_edges'],'TOTAL_EDGE_CAP'
 for n in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
def submit(s,a):
 global local
 if local>=P['limits']['max_per_root_edges']:raise RootCap('PER_ROOT_CAP')
 if counts['edges']%128==0:poll()
 child=copy(s);child.submit(a);local+=1;counts['edges']+=1;return child
def leaf(s,dist):
 feats=[]
 for kind,t in channels:
  feats.append(sum((1 if p.owner==0 else-1)for p in s.state.position.board if p is not None and p.current_type_id==t)if kind=='board'else s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t))
 if s.result.status.value!='ongoing':
  assert s.result.declaration_outcome not in('NO_CONTEST','RESTART');v=0 if s.result.winner is None else(100000000-dist)*(1 if s.result.winner==0 else-1);values=[v*1000,v,v*1000,v];rec=dict(terminal_value=v,features=feats)
 else:values=[sum(x*w for x,w in zip(feats,weights))for weights in vectors];rec=dict(terminal_value=None,features=feats)
 counts['leaves']+=1;return values,rec
try:
 with(D/'roots.jsonl').open('x',encoding='utf8')as out,gzip.open(D/'frontiers.jsonl.gz','xt',encoding='utf8')as front:
  for idx,ctx in enumerate(contexts):
   poll();tick=time.perf_counter();active=idx;c=compiled[ctx['rule']];s=GameSession.replay(c,deserialize_game_record(json.dumps(ctx['record'])));assert hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True,separators=(',',':')).encode()).hexdigest()==ctx['state_sha256'];channels=[(kind,t)for kind in('board','hand')for t in sorted(c.types_by_id)];vectors=[]
   for model in('rule_static_v2','geo_empty'):
    cp=models[ctx['rule'],model];raw=[round(cp[kind+'_weights'][t]*1000)for kind,t in channels];assert all(abs(cp[kind+'_weights'][t]*1000-v)<1e-8 for(kind,t),v in zip(channels,raw));vectors.extend([[v*256 for v in raw],[round(cp[kind+'_weights'][t]*256)for kind,t in channels]])
   local=0;forest=[];aa=sorted(s.legal_actions(),key=repr);assert aa;action_values=[];row=dict(context=idx,rule=ctx['rule'],state_sha256=ctx['state_sha256'],status='UNKNOWN',root_actions=record_value(aa))
   try:
    for a in aa:
     ch=submit(s,a)
     if ch.result.status.value!='ongoing':v,rec=leaf(ch,1);forest.append(dict(terminal=True,leaves=[rec]));action_values.append(v)
     else:
      replies=[];records=[];bb=sorted(ch.legal_actions(),key=repr);assert bb
      for b in bb:v,rec=leaf(submit(ch,b),2);replies.append(v);records.append(rec)
      backup=max if ch.state.position.side_to_move==0 else min;action_values.append([backup(v[j]for v in replies)for j in range(4)]);forest.append(dict(terminal=False,reply_actor=ch.state.position.side_to_move,leaves=records))
    backup=max if s.state.position.side_to_move==0 else min;best=[backup(v[j]for v in action_values)for j in range(4)];opts=[[i for i,v in enumerate(action_values)if v[j]==best[j]]for j in range(4)];row.update(status='COMPLETE',actor=s.state.position.side_to_move,action_values=action_values,best_values=best,optimal_indices=opts,float_sets_disjoint=not bool(set(opts[0])&set(opts[2])),integer_sets_disjoint=not bool(set(opts[1])&set(opts[3])))
   except RootCap as exc:row.update(status='UNKNOWN_ROOT_CAP',reason=str(exc));forest=[]
   row.update(edges=local,seconds=time.perf_counter()-tick);front.write(json.dumps(dict(context=idx,status=row['status'],channels=channels,vectors=vectors,forest=forest),separators=(',',':'))+'\n');out.write(json.dumps(row,separators=(',',':'))+'\n');front.flush();out.flush();rows.append(row);active=None;print('D2_ROOT',idx,row['status'],local,flush=True)
   assert(D/'frontiers.jsonl.gz').stat().st_size<P['limits']['max_output_bytes'],'OUTPUT_CAP'
except BaseException as exc:status='PARTIAL_LIMIT';reason=repr(exc)
write_json(D/'result.json',dict(status=status,reason=reason,planned_contexts=len(contexts),returned_contexts=len(rows),complete=sum(r['status']=='COMPLETE'for r in rows),unknown=len(contexts)-sum(r['status']=='COMPLETE'for r in rows),active_unclosed_context=active,counts=dict(counts),both_float_int_disjoint=sum(r.get('float_sets_disjoint',False)and r.get('integer_sets_disjoint',False)for r in rows),seconds=time.perf_counter()-start,scope=P['scope']));print('D2_CLOSED',dict(counts),len(rows),time.perf_counter()-start,flush=True)
