"""Search-free Core verification of complete saved D2 trees only; UNKNOWN never refilled."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,gzip,os,hashlib
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=R/'.local_agent/rank-ratio-d2-20261018';I=R/'.local_agent/empty-mobility-utility-20261018';contexts=json.loads((D/'contexts.json').read_bytes())['rows'];done=json.loads((D/'result.json').read_bytes());rows=list(map(json.loads,(D/'roots.jsonl').read_bytes().splitlines()));frontiers={f['context']:f for f in map(json.loads,gzip.open(D/'frontiers.jsonl.gz','rt',encoding='utf8'))};compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(I/'generation.jsonl').read_bytes().splitlines())};models={(r['rule'],r['label']):r['checkpoint']for r in json.loads((I/'models.json').read_bytes())['rows']};start=time.perf_counter();counts=Counter()
def poll():
 assert time.perf_counter()-start<300,'READER_CAP'
 for name in ('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def child(s,a):
 if counts['edges']%128==0:poll()
 out=copy(s);out.submit(a);counts['edges']+=1;return out
def observed_leaf(s,dist,f,ctx,channels):
 features=[sum((1 if pc.owner==0 else-1)for pc in s.state.position.board if pc is not None and pc.current_type_id==t)if kind=='board'else s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t)for kind,t in channels];assert features==f['features'];vals=[]
 terminal=s.result.status.value!='ongoing';tval=None if not terminal else 0 if s.result.winner is None else(100000000-dist)*(1 if s.result.winner==0 else-1);assert tval==f['terminal_value']
 for model in ('rule_static_v2','geo_empty'):
  cp=models[ctx['rule'],model];raw=sum(x*round(cp[kind+'_weights'][t]*1000)*256 for x,(kind,t)in zip(features,channels));integer=sum(x*round(cp[kind+'_weights'][t]*256)for x,(kind,t)in zip(features,channels));vals.extend([raw,integer]if not terminal else[tval*1000,tval])
 counts['leaves']+=1;return vals
for row in rows:
 if row['status']!='COMPLETE':counts['saved_unknown_not_replayed']+=1;continue
 ctx=contexts[row['context']];front=frontiers[row['context']];assert front['status']=='COMPLETE';s=GameSession.replay(compiled[ctx['rule']],deserialize_game_record(json.dumps(ctx['record'])));assert hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True,separators=(',',':')).encode()).hexdigest()==ctx['state_sha256'];aa=sorted(s.legal_actions(),key=repr);assert record_value(aa)==row['root_actions'];assert len(aa)==len(front['forest']);values=[];before=counts['edges']
 for a,fr in zip(aa,front['forest']):
  ch=child(s,a)
  if ch.result.status.value!='ongoing':assert fr['terminal']and len(fr['leaves'])==1;v=observed_leaf(ch,1,fr['leaves'][0],ctx,front['channels'])
  else:
   assert not fr['terminal']and ch.state.position.side_to_move==fr['reply_actor'];bb=sorted(ch.legal_actions(),key=repr);assert len(bb)==len(fr['leaves']);vv=[observed_leaf(child(ch,b),2,leaf,ctx,front['channels'])for b,leaf in zip(bb,fr['leaves'])];backup=max if ch.state.position.side_to_move==0 else min;v=[backup(v[j]for v in vv)for j in range(4)]
  values.append(v)
 assert values==row['action_values'];assert counts['edges']-before==row['edges'];backup=max if s.state.position.side_to_move==0 else min;best=[backup(v[j]for v in values)for j in range(4)];opts=[[i for i,v in enumerate(values)if v[j]==best[j]]for j in range(4)];assert best==row['best_values']and opts==row['optimal_indices'];counts['complete_roots']+=1;counts['both_disjoint']+=(not bool(set(opts[0])&set(opts[2])))and(not bool(set(opts[1])&set(opts[3])))
assert counts['complete_roots']==done['complete']and counts['both_disjoint']==done['both_float_int_disjoint'];write_json(D/'reader-result.json',dict(status='PASS_ALL_COMPLETE_SAVED_D2_CORE_FRONTIERS',counts=dict(counts),planned_unknown=done['unknown'],seconds=time.perf_counter()-start,scope='Fresh Coreenumeration ofONLYoriginalcompletedD2roots, allrootactions/replies/leafstates/features/terminalvalues/fourbackups andoptimumsets agree. Capped/unstarted statesnotrefilled; originalpartialpaidwork retained. SameCore/rules authority, not externalimplementation, WDL, deepsearchoptimality, utilitycausation orpopulationquality.'))
print('D2_CORE_READER_PASS',dict(counts),time.perf_counter()-start)
