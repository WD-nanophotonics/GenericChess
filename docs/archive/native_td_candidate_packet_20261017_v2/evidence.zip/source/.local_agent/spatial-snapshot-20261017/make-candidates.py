from pathlib import Path
import sys,json,hashlib,collections,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.core.actions import BoardMove,SemanticBoardMove,SemanticDropMove
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.learning.serialization import stable_sha256
D=Path('.local_agent/spatial-snapshot-20261017');T=D/'aux89-exact/results/dev_aux/task2525';O=Path('docs/research/data/aux89_native_candidates_20261017');O.mkdir(exist_ok=False)
plan=dict(question='Can the actual eight published rule-conditioned learned models be consumed through the established backend without AUX code imports or silent integer rounding?',forecast_seconds=30,cap_seconds=120,source_sha='63b4ce1d8f0e94755bf2102dfbd4f524a91c0264',destination='Standard16checkpoint JSONs+4rules+16semantic records and one existing-API runnable example; research-only candidates, not champion/default/UI or resumable AUXoptimizer.',precision=256,value_scale=10.,normalization='NONE: preserve sourcecoefficients and boardP1 scale; do not median-rescale or add fake dynamic coefficients.',validation='Roundtrip IDs/fullfloat tables/channel mapping then32actual NativeD2 calls on included16TRAIN-exposed roots; compare prior fixed executable choices/scores. No new learning/fitness or general converter API.')
write_json(D/'candidate-packet-plan.json',plan);v=json.loads((T/'result.json').read_bytes());episodes=[json.loads(x)for x in(T/'episodes.jsonl').read_text().splitlines()];nativecontrols=json.loads((D/'finite-precision/result.json').read_bytes());index=dict(schema=1,source=dict(sha=plan['source_sha'],archive_sha256='2fa240c52fbfd1cd989c66110b74701dcd11412bcbad204ae003d348492cbf29',path='results/dev_aux/task2525/result.json',raw_sha256=hashlib.sha256((T/'result.json').read_bytes()).hexdigest()),activation=plan,models=[],rules=[],roots=[],qualification='PENDING')
for gs in sorted({a['generator_seed']for a in v['arms']}):
 raw=(T/f'rules-{gs}.json').read_bytes();rule=json.loads(raw);p=O/f'rule-{gs}.json';p.write_bytes((json.dumps(rule,sort_keys=True,indent=2)+'\n').encode());index['rules'].append(dict(generator_seed=gs,path=p.name,source_raw_sha256=hashlib.sha256(raw).hexdigest(),public_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
for arm in v['arms']:
 gs,seed=arm['generator_seed'],arm['seed'];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(json.loads((T/f'rules-{gs}.json').read_bytes())));ee=[e for e in episodes if(e['generator_seed'],e['seed'])==(gs,seed)];common=dict(source=index['source'],rule=gs,initial_seed=seed,channels=arm['channels'],recorded_games=arm['games'],recorded_nodes=arm['nodes'],actual_nonzero_updates=sum(e['initial_weights']!=e['weights']for e in ee),terminal=sum(e['outcome']is not None for e in ee),unknown=sum(e['outcome']is None for e in ee),precision=256,normalization='No sourceweight changes')
 parent=None
 for label,key in(('initial','initial'),('trained','weights')):
  w=arm[key];cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='aux89-source-endpoint-explicit-native256',generation=0 if label=='initial' else 1,parent_checkpoint_id=parent,training_config_hash=stable_sha256(dict(**common,endpoint=label)),board_weights={t:x for(kind,t),x in zip(arm['channels'],w)if kind=='board'},hand_weights={t:x for(kind,t),x in zip(arm['channels'],w)if kind=='hand'},material_scale=256,value_scale=10.,reference_median=1.,games_seen=0 if label=='initial'else arm['games'],positions_seen=0 if label=='initial'else sum(e['stats']['samples']for e in ee),training_updates=0 if label=='initial'else common['actual_nonzero_updates'],training_seed=seed,promoted_to_champion=False)
  cp.validate_ruleset(c);cp.ensure_within_limits();data=cp.to_dict();restored=LearnableMaterialCheckpoint.from_dict(data);assert restored.checkpoint_id==cp.checkpoint_id and restored.to_dict()==data
  name=f'{gs}-{seed}-{label}.json';(O/name).write_bytes((json.dumps(data,sort_keys=True,indent=2)+'\n').encode());index['models'].append(dict(generator_seed=gs,seed=seed,label=label,path=name,checkpoint_id=cp.checkpoint_id,provenance=common,endpoint_generation_meaning='0source-initial/1source-endpointconversion, NOT original4episode optimizer lineage'))
  if label=='initial':parent=cp.checkpoint_id
for row in nativecontrols['rows']:
 gs,seed,which=row['rule'],row['seed'],row['which'];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(json.loads((T/f'rules-{gs}.json').read_bytes())));s=GameSession(c)
 for old in deserialize_game_record(json.dumps(row['original_record'])).actions:
  if isinstance(old,BoardMove):aa=[x for x in s.legal_actions()if isinstance(x,SemanticBoardMove)and(x.from_square,x.to_square,x.promotion_target_id)==(old.from_square,old.to_square,old.promotion_target_id)]
  else:aa=[x for x in s.legal_actions()if isinstance(x,SemanticDropMove)and(x.base_type_id,x.to_square)==(old.base_type_id,old.to_square)]
  assert len(aa)==1;s.submit(aa[0])
 assert record_value(s.to_record())==row['semantic_record'];data=json.loads(serialize_game_record(s.to_record()));assert GameSession.replay(c,deserialize_game_record(json.dumps(data))).state==s.state
 name=f'root-{gs}-{seed}-{which}.json';(O/name).write_bytes((json.dumps(data,sort_keys=True,indent=2)+'\n').encode());index['roots'].append(dict(generator_seed=gs,seed=seed,which=which,path=name,exposure='ExistingTRAIN query, never heldout',source_query=row['source_query'],state_sha256=stable_sha256(record_value(s.state)),witnesses_sha256=stable_sha256(record_value(s._search_witnesses)),expected_native=[{k:n[k]for k in('label','action','score','completed_depth')}for n in row['native']if n['scale']==256]))
(O/'index.json').write_bytes((json.dumps(index,sort_keys=True,indent=2)+'\n').encode());print('PACKED',len(index['models']),len(index['rules']),len(index['roots']))
