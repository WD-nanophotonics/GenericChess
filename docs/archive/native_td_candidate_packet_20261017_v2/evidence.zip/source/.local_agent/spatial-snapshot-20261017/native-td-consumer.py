from pathlib import Path
import sys,json,time,hashlib,traceback,collections
ROOT=Path.cwd();D=ROOT/'.local_agent/spatial-snapshot-20261017';AUX=D/'aux89-exact';sys.path.insert(0,str(ROOT));sys.path.insert(1,str(AUX))
from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
from results.dev_aux.task2492.learning import Model
from results.dev_aux.task2511.generic import ScoringSessionEnv
from results.dev_aux.task2504.search import TrainingSearch
import results.dev_aux.task2504.search as owner_search
O=D/'native-td-consumer';O.mkdir(exist_ok=False);P=ROOT/'docs/research/data/aux89_native_candidates_20261017';index=json.loads((P/'index.json').read_bytes())
plan=dict(question='Does the existing Native semantic backend offer a worthwhile actually executed bounded TD-material search consumer for the newly portable Generic prices?',premise='AUX89 learner now has actual Generic data, and canonical endpoint packet is executable through existingbackend. Need value/legal fidelity AND total caller cost, not a newlearning algorithm or read-only interface promise.',roots='All16includedTRAIN-exposed first/last roots xinitial/final =32pairs, no selection after results.',fixed=dict(depth=2,nodes=8192,seconds=2.,q0=True,tt0=True,prices='identical exact integer/256 coefficients in both consumers; Native mate encoding converted separately'),order='alternate first backend by slot',forecast_seconds=60,cap_seconds=180,scope='Published AUX89 Model+ScoringSessionEnv+TrainingSearch executed on CURRENT PRIMARY Core+semantic records; not owneroriginallegacyCore reproduction. Allselectedplies/history retained. No AUXcheckout/sourcechange, newtrain/game/default/backendAPI or automatic acceleratoradoption. A future learning comparison would need new registration because tie ordering/work/quantization differ.')
write_json(O/'plan.json',plan);write_json(O/'source-paths-private.json',dict(owner_search=str(owner_search.__file__),current_session=__import__('generic_chess.session.session',fromlist=['x']).__file__));assert Path(owner_search.__file__).resolve().is_relative_to(AUX)
compiled={};natives={};models={};rows=[];began=time.monotonic();status='COMPLETE';reason=None
for e in index['rules']:
 c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(json.loads((P/e['path']).read_bytes())));compiled[e['generator_seed']]=c;natives[e['generator_seed']]=compile_native_semantic_rules(c)
for e in index['models']:models[e['generator_seed'],e['seed'],e['label']]=LearnableMaterialCheckpoint.from_dict(json.loads((P/e['path']).read_bytes()))
finite=json.loads((D/'finite-precision/result.json').read_bytes());refs={(r['rule'],r['seed'],r['which']):r for r in finite['rows']}
def signature(a):return json.dumps(record_value(a),sort_keys=True,separators=(',',':'))
def poll():
 if time.monotonic()-began>=180:raise TimeoutError('FROZEN_CAP')
 for name in('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')
try:
 for root in index['roots']:
  for label in('initial','trained'):
   poll();gs,seed=root['generator_seed'],root['seed'];c=compiled[gs];native=natives[gs];cp=models[gs,seed,label];s=GameSession.replay(c,deserialize_game_record((P/root['path']).read_text(encoding='utf8')));before=(s.state,s.to_record(),s.history,s._search_witnesses);channels=tuple(tuple(x)for x in next(e for e in index['models']if(e['generator_seed'],e['seed'],e['label'])==(gs,seed,label))['provenance']['channels']);w=[round((cp.board_weights if kind=='board'else cp.hand_weights)[tid]*256)/256 for kind,tid in channels];data={};reference=next(p for p in refs[gs,seed,root['which']]['profiles']if p['scale']==256 and p['label']==label)
   for backend in(('native','published_aux_search')if len(rows)%2==0 else('published_aux_search','native')):
    poll();stamp=time.perf_counter()
    if backend=='native':
     engine=SemanticSearchEngine(c,native,checkpoint=cp,tt_megabytes=0);r=engine.search(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=2.,quiescence_max_depth=0),root_window_pruning=False);complete=r.completed_depth==2;action=r.action;owner0=r.score*(1 if s.state.position.side_to_move==0 else-1);value=(1e6 if owner0>0 else-1e6)if abs(owner0)>50000000 else owner0/256;nodes=r.nodes;cause=r.termination_reason
    else:
     env=ScoringSessionEnv(s,channels);model=Model(w);seedquery=gs*100000+seed+root['source_query']['game']*1000+root['source_query']['ply'];r=TrainingSearch(2,quiet=False).search(env,model,nodes=8192,seconds=2.,seed=seedquery,cancel=poll);complete=r.complete;action=r.action.action if complete else None;value=r.value;nodes=r.nodes;cause=r.reason;assert env.session.state==s.state and env.session.to_record()==s.to_record()
    elapsed=time.perf_counter()-stamp;assert before==(s.state,s.to_record(),s.history,s._search_witnesses);sig=signature(action)if action is not None else None;valid=complete and sig in reference['optimal'];equalvalue=complete and abs(value-reference['best'])<1e-9;data[backend]=dict(complete=complete,seconds=elapsed,nodes=nodes,cause=cause,action=sig,owner0_value=value,belongs_to_exhaustive_quantized_optimum=valid,value_matches=equalvalue)
   rows.append(dict(rule=gs,seed=seed,root=root['which'],label=label,arms=data,tied_actions_allowed=data['native']['action']!=data['published_aux_search']['action']));write_json(O/'partial.json',dict(rows=rows));print(gs,seed,root['which'],label,[(k,round(x['seconds'],4),x['complete'],x['value_matches'])for k,x in data.items()],flush=True)
except Exception as e:status='ERROR';reason=repr(e);traceback.print_exc()
write_json(O/'result.json',dict(status=status,reason=reason,planned=32,returned=len(rows),rows=rows,seconds=time.monotonic()-began,compilation_and_setup_in_total=True,per_call_includes='Native Engine construction/rootpack/checkedPV/feature result versus AUXEnv+Modelfromsameprices/search; common source rule compilation and fullSessionreplay are outside per-call but within total. Different node accounting/order, equal nominal limits not equalwork.'))
print('CLOSED',status,len(rows),round(time.monotonic()-began,3),reason,flush=True)
