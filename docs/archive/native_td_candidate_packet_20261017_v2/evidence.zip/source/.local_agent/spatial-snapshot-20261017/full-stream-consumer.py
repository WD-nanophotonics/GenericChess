from pathlib import Path
import sys,json,time,copy,collections,traceback,hashlib,math
ROOT=Path.cwd();D=ROOT/'.local_agent/spatial-snapshot-20261017';AUX=D/'aux89-exact';sys.path[:0]=[str(ROOT),str(AUX)]
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import BoardMove,SemanticBoardMove,SemanticDropMove
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from results.dev_aux.task2492.learning import Model
from results.dev_aux.task2511.generic import ScoringSessionEnv
from results.dev_aux.task2504.search import TrainingSearch
T=AUX/'results/dev_aux/task2525';O=D/'full-stream-consumer';O.mkdir(exist_ok=False)
plan=dict(question='Does Native retain useful TD-ready caller savings on ALL actual newGeneric training roots once nonterminal support and real leaf extraction are included?',changed_premise='32endpoint controls were20/32terminalPV; actual657sourcequeries contain43terminalPVs. PriorNative search-only stopwatch excluded extra materialleaf extraction; do not generalize24x.',slots='All657closedsourcequery roots in ORIGINAL stream order/actualperqueryweights, include original1failedthinpoolroot explicitly.',limits=dict(depth=2,nodes=8192,seconds=2.,q0=True,tt0=True,precision=256),forecast_seconds=120,cap_seconds=600,order='AlternateNative/AUXfirst byoriginalindex',decision='A disappearance/reversal of TD-ready benefit argues against accelerator engineering; retained useful benefit supports an opt-in future AUX trial, never autochanges currentfrozencurve. No newtraining/game, oldfailedquery outcome replacement, code merge or samealgorithm/strengthclaim.',cost='TDreadyNative Engine+fullrootpack+checkedPV+existing3features+privateSessioncopy/PVsubmit/materialCURRENT+handBASE vector+terminalconstant/gradient. AUXEnv+Model+publishedSearch+gradient. Commonstreamsemantictranslation/stop/log outside per-call, insideaggregate; counts/order differ; normal concurrent load.')
write_json(O/'plan.json',plan);querybytes=(T/'queries.jsonl').read_bytes();source=[json.loads(x)for x in querybytes.splitlines()];assert len(source)==657;cc={};nn={};lc={};began=time.monotonic();rows=[];status='COMPLETE';reason=None;translation_seconds=0.;logical_edges=0
for gs in sorted({x['generator_seed']for x in source}):
 rule=ruleset_from_dict(json.loads((T/f'rules-{gs}.json').read_bytes()));lc[gs]=compile_ruleset(rule);cc[gs]=compile_legacy_ruleset_for_semantic_execution(rule);nn[gs]=compile_native_semantic_rules(cc[gs])
def poll():
 if time.monotonic()-began>=600:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for name in('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')
def match(old,new):
 if isinstance(old,BoardMove):return isinstance(new,SemanticBoardMove)and(old.from_square,old.to_square,old.promotion_target_id)==(new.from_square,new.to_square,new.promotion_target_id)
 return isinstance(new,SemanticDropMove)and(old.base_type_id,old.to_square)==(new.base_type_id,new.to_square)
def step(old):
 global logical_edges
 aa=[x for x in s.legal_actions()if match(old,x)];assert len(aa)==1;s.submit(aa[0]);legacy.submit(old);logical_edges+=1;assert s.state.position==legacy.state.position;assert(s.result.status,s.result.winner)==(legacy.result.status,legacy.result.winner)
def features(position,channels):return tuple(sum(1 if p.owner==0 else-1 for p in position.board if p is not None and p.current_type_id==tid)if kind=='board'else position.hands[0].count(tid)-position.hands[1].count(tid)for kind,tid in channels)
last=None
try:
 with(O/'queries.jsonl').open('x',encoding='utf8')as log:
  for i,q in enumerate(source):
   poll();stamp=time.perf_counter();gs,seed,game=q['generator_seed'],q['seed'],q['game'];c=cc[gs];native=nn[gs];key=(gs,seed,game);channels=tuple(tuple(x)for x in q['channels'])
   if key!=last:
    s=GameSession(c);legacy=GameSession(lc[gs])
    for old in deserialize_game_record(json.dumps(q['record_before'])).actions:step(old)
    last=key
   assert record_value(legacy.to_record())['actions'] or len(q['record_before']['actions'])==0
   assert len(s.to_record().actions)==len(q['record_before']['actions']);assert list(features(s.state.position,channels))==q['features'];translation_seconds+=time.perf_counter()-stamp
   w=[round(x*256)/256 for x in q['weights']];cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,board_weights={tid:x for(kind,tid),x in zip(channels,w)if kind=='board'},hand_weights={tid:x for(kind,tid),x in zip(channels,w)if kind=='hand'},material_scale=256,value_scale=10.,reference_median=1.);before=(s.state,s.to_record(),s.history,s._search_witnesses);data={}
   for backend in(('native','published_aux')if i%2==0 else('published_aux','native')):
    poll();stamp=time.perf_counter()
    if backend=='native':
     engine=SemanticSearchEngine(c,native,checkpoint=cp,tt_megabytes=0);r=engine.search(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=2.,quiescence_max_depth=0),root_window_pruning=False);complete=r.completed_depth==2;action=record_value(r.action);nodes=r.nodes;cause=r.termination_reason;kernel_seconds=r.elapsed_seconds
     if complete:
      leaf=copy.copy(s)
      for move in r.principal_variation:leaf.submit(move)
      term=leaf.state.terminal_status.is_terminal;phi=None if term else features(leaf.state.position,channels);gradient=[0.]*len(w)if term else list(Model(w).gradient(phi));value=(0. if leaf.result.winner is None else 1e6 if leaf.result.winner==0 else -1e6)if term else sum(x*y for x,y in zip(phi,w));sc=r.score*(1 if s.state.position.side_to_move==0 else -1);rootvalue=(1e6 if sc>0 else -1e6)if abs(sc)>50000000 else sc/256;leaf_matches=abs(value-rootvalue)<1e-9;leaf_hash=hashlib.sha256(json.dumps(record_value(leaf.state),sort_keys=True).encode()).hexdigest();pv=record_value(r.principal_variation)
     else:term=False;phi=None;gradient=None;value=None;rootvalue=None;leaf_matches=False;leaf_hash=None;pv=[]
    else:
     env=ScoringSessionEnv(s,channels);model=Model(w);r=TrainingSearch(2,quiet=False).search(env,model,nodes=8192,seconds=2.,seed=gs*100000+seed+game*1000+q['ply'],cancel=poll);complete=r.complete;action=record_value(r.action.action)if complete else None;nodes=r.nodes;cause=r.reason;kernel_seconds=None;term=r.pv_terminal;phi=r.pv_phi;gradient=([0.]*len(w)if term else list(model.gradient(phi)))if complete else None;value=r.value;rootvalue=r.value;leaf_matches=True;leaf_hash=None;pv=None;assert env.session.state==s.state and env.session.to_record()==s.to_record()
    elapsed=time.perf_counter()-stamp;assert before==(s.state,s.to_record(),s.history,s._search_witnesses);data[backend]=dict(complete=complete,seconds=elapsed,kernel_seconds=kernel_seconds,nodes=nodes,cause=cause,action=action,value=value,root_value=rootvalue,terminal=term,phi=phi,gradient=gradient,leaf_matches_root=leaf_matches,leaf_hash=leaf_hash,pv=pv)
   row=dict(index=i,rule=gs,seed=seed,game=game,ply=q['ply'],source_complete=q['complete'],source_terminal_pv=q['pv_terminal'],history_length=len(s.state.history),arms=data,values_equal=all(x['complete']for x in data.values())and abs(data['native']['root_value']-data['published_aux']['root_value'])<1e-9,leaves_equal=data['native']['terminal']==data['published_aux']['terminal']and data['native']['phi']==data['published_aux']['phi']);rows.append(row);log.write(json.dumps(row,separators=(',',':'))+'\n');log.flush()
   stamp=time.perf_counter();oldrecord=deserialize_game_record(json.dumps(q['record_after']));oldbefore=deserialize_game_record(json.dumps(q['record_before']));assert oldrecord.actions[:len(oldbefore.actions)]==oldbefore.actions
   for old in oldrecord.actions[len(oldbefore.actions):]:step(old)
   translation_seconds+=time.perf_counter()-stamp
   if(i+1)%64==0:print('CLOSED_ROOTS',i+1,round(time.monotonic()-began,3),flush=True)
except Exception as e:status='ERROR';reason=repr(e);traceback.print_exc()
summary=dict(status=status,reason=reason,planned=len(source),returned=len(rows),source_sha256=hashlib.sha256(querybytes).hexdigest(),seconds=time.monotonic()-began,translation_seconds=translation_seconds,logical_translated_edges=logical_edges,values_equal=sum(r['values_equal']for r in rows),leaf_contract_equal=sum(r['leaves_equal']for r in rows),old_failed_roots_included=sum(not r['source_complete']for r in rows),arms={})
for k in('native','published_aux'):
 a=[r['arms'][k]for r in rows];summary['arms'][k]=dict(complete=sum(x['complete']for x in a),seconds=sum(x['seconds']for x in a),nodes=sum(x['nodes']for x in a),terminal_pv=sum(x['complete']and x['terminal']for x in a),nonterminal_pv=sum(x['complete']and not x['terminal']for x in a),leaf_root_matches=sum(x['leaf_matches_root']for x in a),nonterminal_seconds=sum(x['seconds']for x in a if x['complete']and not x['terminal']))
write_json(O/'result.json',summary);print('CLOSED',json.dumps(summary),flush=True)
