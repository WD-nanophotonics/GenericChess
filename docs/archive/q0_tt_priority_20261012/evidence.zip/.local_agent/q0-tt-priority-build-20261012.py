import os,sys,sysconfig,subprocess,time,hashlib,json
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
out=ROOT/'.local_agent/q0-tt-priority-20261012';out.mkdir(exist_ok=True);source=(ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
base=source.replace('    uint32_t pv_stride;\n    uint64_t nodes;','    uint32_t pv_stride;\n    uint64_t replay_nodes;\n    uint64_t tt_rank_conflicts;\n    uint64_t tt_rank_restores;\n    uint64_t tt_conflict_first_cutoffs;\n    uint64_t nodes;');assert base!=source
base=base.replace('    ctx->nodes++;','    ctx->nodes++;\n    if (pv_replay) ctx->replay_nodes++;')
needle='    if (ply == 0 && ctx->root_order_hint_present) {';assert base.count(needle)==1
change="""    int tt_rank_conflict_here = 0;
    if (ctx->learned_move_ordering && !ctx->policy_move_ordering &&
        !pv_node && !pv_replay && tt_has_action) {
        for (size_t j = 1; j < actions.count; j++) {
            if (actions.data[j] == tt_action) {
                tt_rank_conflict_here = 1;
                ctx->tt_rank_conflicts++;
                if (GC_RESEARCH_RESTORE_TT) {
                    memmove(&actions.data[1], &actions.data[0],
                            j * sizeof(uint64_t));
                    actions.data[0] = tt_action;
                    ctx->tt_rank_restores++;
                }
                break;
            }
        }
    }
"""
base=base.replace(needle,change+needle)
needle='        if (alpha >= beta) {\n            ctx->beta_cutoffs++;';assert base.count(needle)==1;base=base.replace(needle,'        if (alpha >= beta) {\n            if (tt_rank_conflict_here && first_legal_child) ctx->tt_conflict_first_cutoffs++;\n            ctx->beta_cutoffs++;')
marker='"s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K}",';assert base.count(marker)==1;base=base.replace(marker,'"s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K}",');base=base.replace('        "tt_allocated_bytes", ctx.tt == NULL ?', '        "replay_nodes", ctx.replay_nodes,\n        "tt_rank_conflicts", ctx.tt_rank_conflicts,\n        "tt_rank_restores", ctx.tt_rank_restores,\n        "tt_conflict_first_cutoffs", ctx.tt_conflict_first_cutoffs,\n        "tt_allocated_bytes", ctx.tt == NULL ?')
write_record(out/'declaration.json',dict(question='Does materialscore ordering overwrite actualusefulTT priority onfailureturn2?',source_base='497445594d2695653f393e90a29ff9166dbb0466',calls=8,root='generated1091 savedturn2 fullhistory',depths=[3,4],arms=['baseline','TT_first'],orders=['forward','reverse'],tt_MiB=1,seconds=64,nodes=None,min_depth=2,scope='Dot1791787532.299919 adopted. Sameper-node complete scorer; aggregateorderingcost maychange. InstrumentbothsameABI privatevariants identically, stablemoveonlystilllegalTTaction onnormalnonPV/nonreplay permittednodes. Root hints/canonical order/leaf/terminal/history/completeiteration unchanged. D3 mayhavezeroconflicts;D4 fromknown64timeplane completion; no caprescue/withinbatchextension/default/UI/API orbinarypublication. Max512seconds plusbuild<9min, expected<5min.'))
rows=[]
for name,flag in [('baseline',0),('TT_first',1)]:
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text('#define GC_RESEARCH_RESTORE_TT '+str(flag)+'\n'+base,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));args=[str(ROOT/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(ROOT/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython'+str(sys.version_info.major)+str(sys.version_info.minor)]+[str(p if f.name=='native_module.c' else f) for f in sorted((ROOT/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)];t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:];rows.append(dict(arm=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size));print(name,'built',flush=True)
assert (ROOT/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')==source;write_record(out/'build-summary.json',dict(variants=rows,productsource_unchanged=True))
