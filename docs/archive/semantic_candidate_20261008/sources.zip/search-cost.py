"""Matched end-to-end search, isolating disabled-feature execution cost."""
import sys,json,time,hashlib,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'search-cost.json';assert not out.exists();start=time.perf_counter();spec=importlib.util.spec_from_file_location('generic_chess.ai.evaluation._before_search_cost',p/'evaluator-before.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
src=json.loads((p/'ordering-ablation.json').read_bytes());cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256((p/'ordering-ablation.json').read_bytes()).hexdigest(),before_sha256=hashlib.sha256((p/'evaluator-before.py').read_bytes()).hexdigest(),after_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/evaluator.py').read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/semantic.py').read_bytes()).hexdigest(),declaration='Same two declared exposed roots, both static profiles,4096/16384nodes/5sec,targetdepth6,q0/root-tacticaloff;2cold repeats alternate before/after ordering. Only change is execution of disabled dynamic terms. Scoring and ordering tables identical within each pair; no budget changes or option pruning. Exact repeat conditions apply only completed/node-limited cells; actual time-limited node counts may vary. Compare equal completed depth score/actions/nodes and actual time, or report depth/resource curves. No generic strength/price claim.',rows=[])
write_record(out,r)
for root in src['rows']:
 c=compile_ruleset_for_execution(ruleset_from_dict(root['definition']));session=GameSession(c)
 for candidate in (False,True):
  profile=build_semantic_opportunity_profile(c,cfg)[0] if candidate else build_ruleset_profile(c,cfg)
  for ceiling in (4096,16384):
   item=dict(root=root['root'],candidate=candidate,ceiling=ceiling,calls=[]);r['rows'].append(item)
   for repeat in (0,1):
    for label in (('before','after') if repeat==0 else ('after','before')):
     assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
     ev=(old.Evaluator if label=='before' else Evaluator)(c,profile,cfg);player=AlphaBetaPlayer(c,evaluation_config=cfg,use_disk_cache=False,evaluator_override=ev,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();d=player.choose_action(session,SearchLimits(max_depth=6,max_nodes=ceiling,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(session,d);item['calls'].append(dict(label=label,repeat=repeat,seconds=time.perf_counter()-t,decision=record_value(d),legal=True));write_record(out,r);print(root['root'],candidate,ceiling,label,repeat,d.completed_depth,d.score,d.nodes,d.termination_reason,flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
