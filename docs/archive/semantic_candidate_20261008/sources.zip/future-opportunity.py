"""Finite promotion-opportunity diagnostic, not material utility or games."""
import sys,json,time,hashlib,collections
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.pieces import Piece
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'future-opportunity.json';assert not out.exists();start=time.perf_counter()
base=build_western_chess_ruleset();actions=tuple(a for a in base.semantic_actions if not(a.name.startswith('castle_') or a.name.startswith('en_passant_') or a.name=='pawn_double_step'))
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Observed future-promotion omission only. Actual supported Western derivative removes castling/double-step/en-passant, preserving simple movement and all promotion choices. One ordinary actor alone on8x8, no anchors/opponent/captures/terminal utility; actual Core legal actions and transitions, then explicit virtual opponent pass to return own turn. Rule pass_enabled is not changed: this is a virtual task, not a legal game. Choose uniformly among distinct target endpoints, then uniformly among legal promotion alternatives to that endpoint. Reward is number of current quiet endpoints, not WDL or prices. Predeclared horizons1/4/8/16, every both-owner source; source populations equal all squares or owner-relative rank1 for every type. Compare full promotion rules against explicit no-promotion rule; no outcome-driven law choice/human data. Float mass propagation, bounded4096graph states/100000actual Core transitions per rule; partial on cost limit, not zero.',modes=[],failures=[])
write_record(out,r)
class Fuse(RuntimeError):pass
for mode in ('no_promotion','all_choices'):
 assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
 definition=replace(base,semantic_actions=actions,promotion_allowed=base.promotion_allowed if mode=='all_choices' else {'P':(frozenset(),frozenset())},promotion_forced=base.promotion_forced if mode=='all_choices' else {'P':(frozenset(),frozenset())})
 c=compile_ruleset_for_execution(definition);engine=semantic_engine_for(c);template=engine._initial_position();assert not template.aux_state
 ordinary=[pt.type_id for pt in c.piece_types if not pt.is_anchor];item=dict(mode=mode,definition=ruleset_to_dict(definition),graph_states=0,core_transitions=0,graph_hits=0,rows=[],complete=False);r['modes'].append(item);graph={};positions={}
 def key(pos):return (pos.side_to_move,tuple((i,piece.owner,piece.base_type_id,piece.current_type_id,piece.promoted) for i,piece in enumerate(pos.board) if piece is not None),pos.aux_state)
 def edges(pos):
  k=key(pos)
  if k in graph:item['graph_hits']+=1;return graph[k]
  if len(graph)>=4096:raise Fuse('state checkpoint')
  aa=engine.legal_actions(pos);groups={}
  for a in aa:groups.setdefault(a.target,{})[(a.promotion_target_id,a.source)]=a
  transitions={}
  for options in groups.values():
   for action in options.values():
    if item['core_transitions']>=100000:raise Fuse('transition checkpoint')
    child=engine.transition_pass(engine.apply(pos,action));item['core_transitions']+=1
    assert child.side_to_move==pos.side_to_move and not child.aux_state
    kk=key(child);positions[kk]=child;transitions[kk]=transitions.get(kk,0.)+1/len(groups)/len(options)
  if not transitions:transitions={k:1.};positions[k]=pos
  assert abs(sum(transitions.values())-1)<1e-12
  graph[k]=(len(groups),transitions);item['graph_states']=len(graph);return graph[k]
 try:
  for tid in ordinary:
   for population in ('all_sources','relative_rank1'):
    curves={}
    for owner in (0,1):
     sources=list(range(64)) if population=='all_sources' else list(range(8,16) if owner==0 else range(48,56))
     mass={}
     for source in sources:
      board=[None]*64;board[source]=Piece(owner,tid,tid);pos=replace(template,board=tuple(board),side_to_move=owner);kk=key(pos);positions[kk]=pos;mass[kk]=1/len(sources)
     cumulative=0.;curve=[]
     for horizon in range(1,17):
      next_mass=collections.defaultdict(float);reward=0.
      for kk,prob in mass.items():
       opportunities,children=edges(positions[kk]);reward+=prob*opportunities
       for child,weight in children.items():next_mass[child]+=prob*weight
      cumulative+=reward;assert abs(sum(next_mass.values())-1)<1e-10;mass=dict(next_mass)
      if horizon in (1,4,8,16):curve.append(dict(horizon=horizon,current_step_opportunity=reward,cumulative_opportunity=cumulative,mean_per_step=cumulative/horizon,mass=sum(mass.values()),states=len(mass)))
     curves[str(owner)]=curve
    assert all(abs(a['cumulative_opportunity']-b['cumulative_opportunity'])<1e-10 for a,b in zip(curves['0'],curves['1']))
    item['rows'].append(dict(type=tid,population=population,curves=curves));write_record(out,r);print(mode,tid,population,[(x['horizon'],round(x['mean_per_step'],5)) for x in curves['0']],item['graph_states'],item['core_transitions'],flush=True)
  item['complete']=True
 except Fuse as e:item['failure']=str(e);r['failures'].append(dict(mode=mode,reason=str(e)))
 write_record(out,r)
r.update(complete=all(x['complete'] for x in r['modes']),seconds=time.perf_counter()-start);write_record(out,r)
