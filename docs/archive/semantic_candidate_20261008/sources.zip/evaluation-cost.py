"""Matched score and actual evaluation cost after skipping disabled features."""
import sys,json,time,hashlib,importlib.util,statistics
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import write_record
from rule_semantics_ir_fixtures import cannon_ruleset
p=Path(__file__).parent;out=p/'evaluation-cost.json';assert not out.exists();start=time.perf_counter()
spec=importlib.util.spec_from_file_location('generic_chess.ai.evaluation._before_cost',p/'evaluator-before.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
recomb=json.loads((ROOT/'.local_agent/original-contribution-20261008/semantic-search-witness-localized.json').read_bytes())['definition']
cases=[('recombined',ruleset_from_dict(recomb)),('canonical',build_western_chess_ruleset()),('cannon',cannon_ruleset()),('shogi',build_standard_shogi_ruleset())]
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),before_sha256=hashlib.sha256((p/'evaluator-before.py').read_bytes()).hexdigest(),after_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/evaluator.py').read_bytes()).hexdigest(),declaration='Four existing synthetic/supported rules, deterministically advance first sorted legal action for up to16ply; every saved state checked old/new score parity under both baseline/candidate profiles and default/material-only config. Compare3paired timing batches of100cycles through same states, alternate old/new order, no search/price/strength claim. Zero-weight dynamic skip is algebraically score-preserving; timing is local measurement.',rows=[])
for name,definition in cases:
 c=compile_ruleset_for_execution(definition);states=[GameSession(c).state]
 for step in range(16):
  aa=legal_actions(states[-1],c)
  if not aa:break
  states.append(apply_action(states[-1],sorted(aa,key=str)[0],c))
 for static in (False,True):
  cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0) if static else EvaluationConfig()
  for candidate in (False,True):
   profile=build_semantic_opportunity_profile(c,cfg)[0] if candidate else build_ruleset_profile(c,cfg);evaluators={'before':m.Evaluator(c,profile,cfg),'after':Evaluator(c,profile,cfg)}
   expected=[evaluators['before'].evaluate(s) for s in states];assert expected==[evaluators['after'].evaluate(s) for s in states];item=dict(case=name,static_only=static,candidate=candidate,states=len(states),parity=True,scores=expected,timing=[])
   for repeat in range(3):
    row={}
    for label in (('before','after') if repeat%2==0 else ('after','before')):
     t=time.perf_counter();checksum=0
     for cycle in range(100):
      for state in states:checksum+=evaluators[label].evaluate(state)
     row[label]=dict(seconds=time.perf_counter()-t,evaluations=100*len(states),checksum=checksum)
    assert row['before']['checksum']==row['after']['checksum'];item['timing'].append(row)
   r['rows'].append(item);write_record(out,r);print(name,static,candidate,statistics.median(x['before']['seconds'] for x in item['timing']),statistics.median(x['after']['seconds'] for x in item['timing']),flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
