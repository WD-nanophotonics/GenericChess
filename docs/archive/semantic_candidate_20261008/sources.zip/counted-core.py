"""Independent Core occupancy checks for the observed counted-path gap."""
import json,sys,time,hashlib,random,math
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from rule_semantics_ir_fixtures import cannon_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.pieces import Piece
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'counted-core.json';assert not out.exists();start=time.perf_counter();c=compile_ruleset_for_execution(cannon_ruleset());engine=semantic_engine_for(c);row=semantic_opportunity(c,'C',EvaluationConfig());included=set(row['included']);template=engine._initial_position();n=c.board_shape.area
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/semantic.py').read_bytes()).hexdigest(),declaration='One synthetic cannon fixture, no human/Xiangqi data. Both owners and every actor source. Each density uses declared1024 samples/owner, seed2026100831; same boards compare full Core actor endpoints and projection-included Core endpoints. No anchors, hand/aux unchanged empty; equal-independent occupancy with actor conditioned present. No full-game/price claim. Additional exact one-screen witness per both-owner source/target for one representative horizontal ray; two screens must invalidate capture.',scope={k:v for k,v in row.items() if k!='signature'},exact_checks=0,curves=[])
capture=next(x for x in c.ir.patterns if x.name=='cannon_capture');capture_id=capture.pattern_id
for owner in (0,1):
 for source in range(n):
  for target in range(n):
   if target//8!=source//8 or abs(target%8-source%8)<2:continue
   step=1 if target>source else -1;path=list(range(source+step,target,step))
   board=[None]*n;board[source]=Piece(owner,'C','C');board[target]=Piece(1-owner,'C','C')
   position=replace(template,board=tuple(board),side_to_move=owner)
   assert not any(a.pattern_id==capture_id and a.source==source and a.target==target for a in engine.legal_actions(position));r['exact_checks']+=1
   board[path[0]]=Piece(owner,'C','C');position=replace(position,board=tuple(board))
   assert any(a.pattern_id==capture_id and a.source==source and a.target==target for a in engine.legal_actions(position));r['exact_checks']+=1
   if len(path)>1:
    board[path[-1]]=Piece(1-owner,'C','C');position=replace(position,board=tuple(board))
    assert not any(a.pattern_id==capture_id and a.source==source and a.target==target for a in engine.legal_actions(position));r['exact_checks']+=1
for density in EvaluationConfig().density_points:
 observed=[];full=[]
 for owner in (0,1):
  rng=random.Random(2026100831)
  for sample in range(1024):
   source=rng.randrange(n);board=[]
   for cell in range(n):
    u=rng.random();board.append(None if u>=density else Piece(owner if u<density/2 else 1-owner,'C','C'))
   board[source]=Piece(owner,'C','C');pos=replace(template,board=tuple(board),side_to_move=owner)
   aa=[a for a in engine.legal_actions(pos) if a.source==source]
   projected={a.target for a in aa if a.pattern_id in included};all_targets={a.target for a in aa}
   assert projected==all_targets
   observed.append(len(projected));full.append(len(all_targets))
 mean=sum(observed)/len(observed);se=math.sqrt(sum((x-mean)**2 for x in observed)/(len(observed)-1)/len(observed));predicted=next(v['total'] for v in row['curves'] if v['density']==density)
 r['curves'].append(dict(density=density,samples=len(observed),mean=mean,standard_error=se,predicted=predicted,delta=mean-predicted,full_projected_same=True));write_record(out,r);print(r['curves'][-1],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
