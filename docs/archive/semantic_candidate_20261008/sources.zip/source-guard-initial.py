"""Quantify an observed source-rank omission, not a complete guard evaluator."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.pieces import Piece
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'source-guard.json';assert not out.exists();start=time.perf_counter();c=compile_ruleset_for_execution(build_western_chess_ruleset());engine=semantic_engine_for(c);template=engine._initial_position();n=c.board_shape.area
pat=next(x for x in c.ir.patterns if x.name=='pawn_double_step');included=semantic_opportunity(c,'P',EvaluationConfig())['included'];config=EvaluationConfig()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Observed excluded pawn double-step only. Source conditioned as ordinary unpromoted actor with base=current; no anchors or hand. Current source guard is checked through Core, not interpreted from debug label. For all both-owner source squares: empty board, each interior/target blocker, and next-state token effects. Derive independent-occupancy opportunity correction for this particular supported guard. No complete guard/aux implementation or selected price; actual future token remains outside static opportunity.',eligible_sources={},block_checks=0,token_checks=0,curves=[])
for owner in (0,1):
 sources=[]
 for source in range(n):
  board=[None]*n;board[source]=Piece(owner,'P','P');pos=replace(template,board=tuple(board),side_to_move=owner)
  aa=[a for a in engine.legal_actions(pos) if a.pattern_id==pat.pattern_id and a.source==source]
  if not aa:continue
  assert len(aa)==1;sources.append(source);action=aa[0];step=8 if owner==0 else -8
  for blocker in (source+step,action.target):
   for blocker_owner in (owner,1-owner):
    bb=list(board);bb[blocker]=Piece(blocker_owner,'N','N');blocked=replace(pos,board=tuple(bb))
    assert not any(a.pattern_id==pat.pattern_id and a.source==source for a in engine.legal_actions(blocked));r['block_checks']+=1
  # Preserve the distinction between current movement eligibility and the
  # auxiliary state this action creates for subsequent en-passant capture.
  from generic_chess.core.actions import SemanticAction
  from generic_chess.core.transition import apply_action
  from generic_chess.core.position import GameState
  # The executor's transition path receives actual Core action, no rewrite.
  next_pos=engine.apply_action(pos,action)
  assert next_pos.aux_state!=pos.aux_state;r['token_checks']+=1
 r['eligible_sources'][str(owner)]=sources
assert len(r['eligible_sources']['0'])==len(r['eligible_sources']['1'])==8
base=semantic_opportunity(c,'P',config);correction=[]
for density in config.density_points:
 extra=(1-density)**2/8
 r['curves'].append(dict(density=density,projected=next(x['total'] for x in base['curves'] if x['density']==density),double_step_extra=extra,qualified_augmented=next(x['total'] for x in base['curves'] if x['density']==density)+extra));correction.append(extra)
extra=sum(w*x for w,x in zip(config.density_weights,correction));raw=base['raw'];knight=semantic_opportunity(c,'N',config)['raw'];r.update(extra_weighted=extra,base_pawn_raw=raw,augmented_pawn_raw=raw+extra,knight_to_pawn_before=knight/raw,knight_to_pawn_after=knight/(raw+extra),complete=True,seconds=time.perf_counter()-start);write_record(out,r);print(r,flush=True)
