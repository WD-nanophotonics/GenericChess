"""Independent Native transition oracle for the declared virtual promotion law."""
import sys,json,time,hashlib,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import pack_position,guarded_actions,public_action,make_checked,snapshot
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'future-native.json';assert not out.exists();raw=(p/'future-opportunity.json').read_bytes();src=json.loads(raw);start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Independent Native action enumeration, packed transitions and actual promoted/base/current flags for every row of the fixed Core virtual-task law. No terminal-WDL queries or actual legal-game pass claim. After each checked native action, assert empty auxiliary state, then repack with original own side to represent the explicitly declared virtual opponent pass. History is absent because this task reward never uses game adjudication; not a generic search projection. Same uniform endpoint/promotion law, horizons and both-owner populations. Separate analytic no-promotion pawn distance sum checks the finite Core/Native result.',modes=[])
for mode in src['modes']:
 c=compile_ruleset_for_execution(ruleset_from_dict(mode['definition']));native=compile_native_semantic_rules(c);ids={t:i for i,t in enumerate(native.type_ids)};cache={};item=dict(mode=mode['mode'],native_transitions=0,graph_states=0,rows=[],complete=False);r['modes'].append(item)
 def packed(key):
  side,base,current,promoted,square=key;board=[None]*64;board[square]=[base,current,side,promoted]
  return pack_position(native,dict(board=board,hands=[[0]*len(ids),[0]*len(ids)],side=side,ply=0,history=[],aux_state=()))
 def edges(key):
  if key in cache:return cache[key]
  if len(cache)>=4096 or item['native_transitions']>=100000:raise RuntimeError('declared state/transition checkpoint')
  pos=packed(key);groups={}
  for a in guarded_actions(native,pos):
   action=public_action(native,a);target=action.to_square.file+8*action.to_square.rank
   groups.setdefault(target,{})[action.promotion_target_id]=a
  transitions={}
  for options in groups.values():
   for a in options.values():
    child=snapshot(native,make_checked(native,pos,a));item['native_transitions']+=1
    assert child['side']==1-key[0] and not child['aux_state']
    occupied=[(i,x) for i,x in enumerate(child['board']) if x is not None];assert len(occupied)==1
    square,piece=occupied[0];base,current,owner,promoted=piece;assert owner==key[0]
    kk=(owner,base,current,promoted,square);transitions[kk]=transitions.get(kk,0.)+1/len(groups)/len(options)
  if not transitions:transitions={key:1.}
  assert abs(sum(transitions.values())-1)<1e-12
  cache[key]=(len(groups),transitions);item['graph_states']=len(cache);return cache[key]
 for row in mode['rows']:
  curves={}
  for owner in (0,1):
   tid=ids[row['type']];sources=list(range(64)) if row['population']=='all_sources' else list(range(8,16) if owner==0 else range(48,56));mass={(owner,tid,tid,0,s):1/len(sources) for s in sources};cumulative=0.;curve=[]
   for h in range(1,17):
    next_mass=collections.defaultdict(float);reward=0.
    for kk,probability in mass.items():
     options,children=edges(kk);reward+=probability*options
     for child,weight in children.items():next_mass[child]+=probability*weight
    cumulative+=reward;mass=dict(next_mass)
    if h in (1,4,8,16):curve.append(dict(horizon=h,current_step_opportunity=reward,cumulative_opportunity=cumulative,mean_per_step=cumulative/h,mass=sum(mass.values()),states=len(mass)))
   expected=row['curves'][str(owner)];assert all(abs(a['cumulative_opportunity']-b['cumulative_opportunity'])<1e-10 for a,b in zip(curve,expected))
   if row['type']=='P' and mode['mode']=='no_promotion':
    for v in curve:
     k=range(8) if row['population']=='all_sources' else (6,)
     analytic=sum(min(distance,v['horizon']) for distance in k)/len(k)
     assert abs(v['cumulative_opportunity']-analytic)<1e-10
   curves[str(owner)]=curve
  item['rows'].append(dict(type=row['type'],population=row['population'],core_equal=True,curves=curves));write_record(out,r);print(mode['mode'],row['type'],row['population'],'Core equal',flush=True)
 item['complete']=True;write_record(out,r)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
