"""Separate candidate scoring from candidate capture/promotion ordering."""
import json,sys,time,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'ordering-ablation.json';assert not out.exists();start=time.perf_counter()
recomb_raw=(ROOT/'.local_agent/original-contribution-20261008/semantic-search-witness-localized.json').read_bytes()
promotion_raw=(ROOT/'.local_agent/original-contribution-20261008/promotion-law-completed.json').read_bytes()
definitions=[('recombined',json.loads(recomb_raw)['definition']),('promotion-context3',next(x['definition'] for x in json.loads(promotion_raw)['rows'] if x['mode']=='all_choices' and x['context']==3))]
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
class SplitEvaluator:
 def __init__(self,scoring,ordering):self.scoring=scoring;self.ordering=ordering
 def evaluate(self,state):return self.scoring.evaluate(state)
 def type_value(self,tid):return self.ordering.type_value(tid)
 def capture_order_value(self,mover,victim):return self.ordering.capture_order_value(mover,victim)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/semantic.py').read_bytes()).hexdigest(),recombined_source_sha256=hashlib.sha256(recomb_raw).hexdigest(),promotion_source_sha256=hashlib.sha256(promotion_raw).hexdigest(),declaration='Two fixed exposed roots: recombination and original promotion context3. Cross old/candidate static scoring x old/candidate capture/promotion ordering, targetdepth6,4096/16384nodes/5sec,2cold repeats each, q0/root-tacticaloff. Same legal actions and public algorithm; no option pruning. Explicit evaluator wrapper holds selected ordering table separate from selected scoring table. Compare complete equal-depth scores within one scoring control; capped depth/result tradeoffs never speed certificates. No fitted coefficients or strength goal.',rows=[])
write_record(out,r)
for name,definition in definitions:
 c=compile_ruleset_for_execution(ruleset_from_dict(definition));session=GameSession(c);base=build_ruleset_profile(c,cfg);candidate,scope=build_semantic_opportunity_profile(c,cfg);evaluators=[Evaluator(c,base,cfg),Evaluator(c,candidate,cfg)]
 item=dict(root=name,definition=definition,baseline_values=dict(base.board_value_by_type),candidate_values=dict(candidate.board_value_by_type),cells=[]);r['rows'].append(item)
 for ceiling in (4096,16384):
  for score_kind in (0,1):
   for order_kind in (0,1):
    for repeat in (0,1):
     assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
     evaluator=SplitEvaluator(evaluators[score_kind],evaluators[order_kind]);player=AlphaBetaPlayer(c,use_disk_cache=False,evaluation_config=cfg,evaluator_override=evaluator,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();decision=player.choose_action(session,SearchLimits(max_depth=6,max_nodes=ceiling,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(session,decision)
     cell=dict(ceiling=ceiling,scoring=score_kind,ordering=order_kind,repeat=repeat,seconds=time.perf_counter()-t,decision=record_value(decision),legal=True);item['cells'].append(cell);write_record(out,r);print(name,ceiling,score_kind,order_kind,repeat,decision.completed_depth,decision.score,decision.nodes,decision.termination_reason,flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
