"""Predeclared same-entry comparisons; no price/strength selection."""
import json, sys, time, hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_to_dict,ruleset_from_dict
from scripts.unfamiliar_search import run_rule
from scripts.research_record import write_record
from rule_semantics_ir_fixtures import cannon_ruleset
p=Path(__file__).parent;out=p/'comparisons.json';assert not out.exists();start=time.perf_counter()
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
raw=(ROOT/'.local_agent/original-contribution-20261008/semantic-search-witness-localized.json').read_bytes()
recomb=json.loads(raw)['definition']
cases=[('recombined',recomb,2),('canonical',ruleset_to_dict(build_western_chess_ruleset()),2),('cannon',ruleset_to_dict(cannon_ruleset()),2),('shogi',ruleset_to_dict(build_standard_shogi_ruleset()),2)]
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),base_sha='69fdf6146570938b5f859c9063f5674c524d0c48',source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Four predeclared supported rules: prior exposed recombined six-piece root, canonical Western start, cannon fixture, standard Shogi start; depth2, both old generic-v1 and optional semantic-opportunity-v0 through existing run_rule;4096nodes/5sec,2cold repeats per plain/public bundle. Static material-only dynamic weights0 in both controls; all ordering remains old generic-v1. Count every failed/incomplete cell; no WDL/price validation, no human data or selection by outcome. Changes across fully renormalized tables differ from earlier one-input intervention.',rows=[])
write_record(out,r)
for name,definition,depth in cases:
 for candidate in (False,True):
  assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
  filename=name+('-candidate' if candidate else '-baseline')+'.json'
  t=time.perf_counter();report=run_rule(p/filename,definition,depth=depth,semantic_candidate=candidate,evaluation_config=cfg)
  row=dict(case=name,candidate=candidate,path=filename,sha256=hashlib.sha256((p/filename).read_bytes()).hexdigest(),seconds=time.perf_counter()-t,profile_seconds=report['profile_seconds'],board_values=report['board_values'],reference=report['reference'],repeat_equal=report['repeat_equal'],calls=[dict(control=x['control'],complete=x['complete'],score=x['decision']['score'],depth=x['decision']['completed_depth'],nodes=x['decision']['nodes'],observed_seconds=x['observed_search_seconds'],reference_equal=x['reference_score_equal'],action=x['decision']['action']) for x in report['searches']])
  r['rows'].append(row);write_record(out,r);print(name,candidate,row,flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
