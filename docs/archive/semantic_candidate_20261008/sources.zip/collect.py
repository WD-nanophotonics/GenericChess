"""Publish compact scoped observations and exact isolated Agent evidence."""
import sys,json,hashlib,zipfile,tempfile,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent
def load(name):return json.loads((p/name).read_bytes())
def pin(path):
 b=path.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
comparisons=load('comparisons.json');counted=load('counted-core.json');guards=load('source-guard.json');cost=load('evaluation-cost.json');search=load('search-cost.json');ablation=load('ordering-ablation.json');future=load('future-opportunity.json');native=load('future-native.json');mixture=load('cannon-mixture.json')
summary=dict(scope='Opt-in semantic opportunity input and execution cost; no selected universal material table/WDL/strength claim',initial_integration=dict(calls=sum(len(x['calls']) for x in comparisons['rows']),core_parity=all(c['reference_equal'] for x in comparisons['rows'] for c in x['calls']),seconds=comparisons['seconds'],ordering_correction=load('ordering-qualification.json')),counted_path=dict(exact_checks=counted['exact_checks'],samples=sum(x['samples'] for x in counted['curves']),curves=counted['curves'],seconds=counted['seconds']),source_guard={k:v for k,v in guards.items() if k not in ('producer_sha256','declaration')},evaluation_cost=dict(score_states=sum(x['states'] for x in cost['rows']),paired_evaluations=sum(v['evaluations'] for x in cost['rows'] for t in x['timing'] for v in t.values()),rows=[dict(case=x['case'],static_only=x['static_only'],candidate=x['candidate'],states=x['states'],parity=x['parity'],before_median_seconds=statistics.median(t['before']['seconds'] for t in x['timing']),after_median_seconds=statistics.median(t['after']['seconds'] for t in x['timing'])) for x in cost['rows']],seconds=cost['seconds']),search_cost=dict(calls=sum(len(x['calls']) for x in search['rows']),rows=[dict(root=x['root'],candidate=x['candidate'],ceiling=x['ceiling'],calls=[dict(label=c['label'],repeat=c['repeat'],seconds=c['seconds'],depth=c['decision']['completed_depth'],score=c['decision']['score'],nodes=c['decision']['nodes'],termination=c['decision']['termination_reason']) for c in x['calls']]) for x in search['rows']],seconds=search['seconds']),ordering_ablation=dict(calls=sum(len(x['cells']) for x in ablation['rows']),seconds=ablation['seconds'],scope='Scoring and ordering table crossed; complete context3 cells all8893 nodes atdepth6, no ordering gain. Recombination cells capped; no universal acceleration claim.'),mixture=dict(controls=[dict(label=x['label'],values=x['values'],reference=x['reference'],repeat_equal=x['repeat_equal']) for x in mixture['controls']],isolated_captures=mixture['isolated_captures'],alias=mixture['alias'],calls=sum(len(x['calls']) for x in mixture['controls']),seconds=mixture['seconds']),future_task=dict(core_states=sum(x['graph_states'] for x in future['modes']),core_transitions=sum(x['core_transitions'] for x in future['modes']),native_states=sum(x['graph_states'] for x in native['modes']),native_transitions=sum(x['native_transitions'] for x in native['modes']),native_all_rows_core_equal=all(x['core_equal'] for m in native['modes'] for x in m['rows']),rows=[dict(mode=m['mode'],type=x['type'],population=x['population'],owner0=x['curves']['0']) for m in future['modes'] for x in m['rows']],scope=future['declaration'],core_seconds=future['seconds'],native_seconds=native['seconds']))
raw_names=['comparisons.json','counted-core.json','source-guard.json','evaluation-cost.json','search-cost.json','ordering-ablation.json','future-opportunity.json','future-native.json','cannon-mixture.json','cannon-mixture-baseline.json','cannon-mixture-candidate.json','ordering-qualification.json','failures.json']+[x['path'] for x in comparisons['rows']]
source_names=['compare.py','counted-core.py','source-guard.py','source-guard-initial.py','evaluation-cost.py','search-cost.py','ordering-ablation.py','future-opportunity.py','future-native.py','cannon-mixture.py','semantic-v0.py','semantic-v1-core-snapshot.py','semantic-v1-ablation-snapshot.py','semantic-v1-measured.py','semantic-v1-library.py','unfamiliar-search-v0.py','unfamiliar-search-v1.py','evaluator-before.py','evaluator-after-measured.py','collect.py']
# Check every recorded producer/library hash against physically packaged exact
# snapshots, including line endings and pre-optimization candidate versions.
source_hashes={pin(p/name)['sha256']:name for name in source_names}
for name in raw_names:
 data=load(name)
 for key in ('producer_sha256','candidate_sha256','before_sha256','after_sha256'):
  if key in data:assert data[key] in source_hashes,(name,key,data[key])
summary['raw_pins']={name:pin(p/name) for name in raw_names};result=ROOT/'docs/research/data/semantic_candidate_20261008.json';write_record(result,summary)
dest=ROOT/'docs/archive/semantic_candidate_20261008';dest.mkdir(exist_ok=True)
index=dict(original_directory=p.relative_to(ROOT).as_posix(),repository_base_sha='69fdf6146570938b5f859c9063f5674c524d0c48',current_result=dict(path=result.relative_to(ROOT).as_posix(),**pin(result)),archives={},dependencies=[])
for archive,names in [('sources.zip',source_names),('raw.zip',raw_names)]:
 members={name:pin(p/name) for name in names}
 with zipfile.ZipFile(dest/archive,'w',zipfile.ZIP_DEFLATED) as z:
  for name in names:z.write(p/name,name)
 with zipfile.ZipFile(dest/archive) as z,tempfile.TemporaryDirectory(dir=p) as temporary:
  assert z.testzip() is None;z.extractall(temporary)
  for name,expected in members.items():assert pin(Path(temporary)/name)==expected
 index['archives'][archive]=dict(**pin(dest/archive),members=members,extracted_rehashed=True)
for path,recovery in [('.local_agent/original-contribution-20261008/semantic-search-witness-localized.json','docs/archive/semantic_geometry_probe_20261008/raw.zip'),('.local_agent/original-contribution-20261008/promotion-law-completed.json','docs/archive/promotion_rule_probe_20261008/raw.zip')]:
 index['dependencies'].append(dict(path=path,recovery=recovery,**pin(ROOT/path)))
write_record(dest/'index.json',index)
readme='''# Semantic candidate development evidence

Current result: ../../research/data/semantic_candidate_20261008.json.
sources.zip and raw.zip separate exact Agent-generated synthetic producers,
library-version snapshots, immutable complete/capped results and corrections.
No user input, raw Slack/account records, credentials or workflow state.

index.json pins physically extracted/rehashed members and on-demand dependencies.
Restore only in an isolated recovery checkout under the recorded original path;
archives are not active imports, scientific gates or a task backlog.
The base SHA predates the optional library/zero-feature optimization. For the
first comparisons install semantic-v0.py as ai/evaluation/semantic.py and
unfamiliar-search-v0.py as scripts/unfamiliar_search.py in that checkout. Its
ordering claim is corrected by ordering-qualification.json; numbers unchanged.
Counted Core data pins semantic-v1-core-snapshot.py; ordering ablation pins
semantic-v1-ablation-snapshot.py; search cost pins semantic-v1-measured.py.
Other current comparisons use semantic-v1-library.py and unfamiliar-search-v1.py.
Before/after measured evaluator snapshots preserve exact bytes/line endings.
Version snapshots reconstructed by reversing later edits were SHA checked
against the immutable raw source pins, not inferred to be identical.
Producers refuse output overwrite: preserve originals and use a fresh isolated
recovery output directory for reruns. Collector is packaging, not an experiment.
Future-opportunity/native are explicit virtual tasks with no terminal utility
or claim that opponent pass is legal in Chess. They are not material tables.
'''
(dest/'README.md').write_bytes(readme.encode('utf-8'))
print('archive',sum(len(x['members']) for x in index['archives'].values()),'members',sum((dest/n).stat().st_size for n in index['archives']),'bytes; hashes verified')
