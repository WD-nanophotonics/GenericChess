"""Append isolated generated/history interface evidence without rewriting old raw archives."""
import sys,json,hashlib,zipfile,tempfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;dest=ROOT/'docs/archive/semantic_candidate_20261008'
def load(name):return json.loads((p/name).read_bytes())
def pin(path):
 b=path.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
generated=load('generated-interface.json');core=load('generated-core.json');history=load('history-interface.json');events=load('event-history-qualified.json')
corrections=dict(history_initial='GameSession.apply does not exist. Partial record and original producer retained; corrected submit route completed.',event_four='Four-ply capture fixture covers promotion/hand but no drop. The session checkpoint claiming drop was premature.',event_six='Source loop extended to6 after four steps did not cover a drop; copied declaration still says4. Raw preserved as preliminary, not a frozen comparison. Original C/R rule forbids drops, so six steps still did not cover a drop.',qualified='New explicitly declared C-drop-enabled fixture and6-ply event-priority route cover two actual drops.12 roots/36 public calls complete,11 Core references complete; one reference hits its declared fuse and stays unknown. No change to old comparison roots/results.')
write_record(p/'generated-corrections.json',corrections)
shutil.copyfile(ROOT/'generic_chess/ai/evaluation/semantic.py',p/'semantic-v1-generated.py')
shutil.copyfile(ROOT/'scripts/unfamiliar_search.py',p/'unfamiliar-search-generated.py')
source_names=['generated-interface.py','generated-core.py','history-interface-initial.py','history-interface.py','event-history-four.py','event-history.py','event-history-qualified.py','promotion-event-definition.py','prepare-event-history.py','prepare-qualified-events.py','semantic-v1-generated.py','unfamiliar-search-generated.py','collect-generated.py']
raw_names=['generated-interface.json','generated-core.json','history-interface-initial.json','history-interface.json','event-history.json','event-history-six.json','event-history-qualified.json','promotion-event-definition.json','drop-event-definition.json','generated-corrections.json']+[x['path'] for c in generated['cases'] for x in c['controls']]
hashes={pin(p/name)['sha256'] for name in source_names}
for name in raw_names:
 data=load(name)
 for field in ('producer_sha256','library_sha256'):
  if field in data:assert data[field] in hashes,(name,field)
summary_path=ROOT/'docs/research/data/semantic_candidate_20261008.json';summary=json.loads(summary_path.read_bytes())
assert 'generated_interface' not in summary
summary['generated_interface']=dict(declaration=generated['declaration'],cases=[dict(board_size=c['board_size'],seed=c['seed'],compiled_class=c['compiled_class'],analytical_checks=c['analytical_checks'],controls=[{k:v for k,v in x.items() if k not in ('calls',)} for x in c['controls']],opening_terminal_children=sum(x['terminal']['status']!='ongoing' for x in o['opening_children']),occupancy_samples=o['rows']) for c,o in zip(generated['cases'],core['cases'])],cold_calls=sum(len(x['calls']) for c in generated['cases'] for x in c['controls']),core_seconds=core['seconds'],comparison_seconds=generated['seconds'])
def brief(raw):return dict(declaration=raw['declaration'],seconds=raw['seconds'],cases=[dict(source=c['source'],roots=len(c['rows']),calls=sum(len(x['calls']) for x in c['rows']),complete_calls=sum(x['complete'] for a in c['rows'] for x in a['calls']),complete_references=sum(a['reference']['complete'] for a in c['rows']),all_known_reference_scores_equal=all(x['reference_score_equal'] is not False for a in c['rows'] for x in a['calls']),max_history=max(a['history_length'] for a in c['rows']),max_promoted=max(a['promoted'] for a in c['rows']),max_hand=max(sum(v for h in a['hands'] for k,v in h['counts']) for a in c['rows']),drops=sum('from_square' not in a for a in c['transitions'])) for c in raw['cases']])
summary['history_interface']=dict(lexical=brief(history),qualified_events=brief(events),corrections=corrections)
summary['raw_pins'].update({name:pin(p/name) for name in raw_names});write_record(summary_path,summary)
index_path=dest/'index.json';index=json.loads(index_path.read_bytes());index['previous_current_result']=index['current_result'];index['current_result']=dict(path=summary_path.relative_to(ROOT).as_posix(),**pin(summary_path));index['generated_supplement_base_sha']='3a6135be19f64c09b283bb4251b445d9a4177929'
for archive,names in [('generated-sources.zip',source_names),('generated-raw.zip',raw_names)]:
 assert not (dest/archive).exists()
 members={name:pin(p/name) for name in names}
 with zipfile.ZipFile(dest/archive,'w',zipfile.ZIP_DEFLATED) as z:
  for name in names:z.write(p/name,name)
 with zipfile.ZipFile(dest/archive) as z,tempfile.TemporaryDirectory(dir=p) as temporary:
  assert z.testzip() is None;z.extractall(temporary)
  for name,expected in members.items():assert pin(Path(temporary)/name)==expected
 index['archives'][archive]=dict(**pin(dest/archive),members=members,extracted_rehashed=True)
write_record(index_path,index)
with (dest/'README.md').open('a',encoding='utf-8',newline='\n') as f:f.write('\nGenerated/history supplement: generated-sources.zip and generated-raw.zip.\nOriginal sources.zip/raw.zip bytes remain unchanged. Supplement base is3a6135.\nRestore semantic-v1-generated.py for these analyses; the legacy search executor\nremains original. Initial/short event routes and corrections stay separate.\nOne drop-history Core reference is unknown at the declared fuse, not zero.\nThe new C-drop-enabled fixture changes drop permissions explicitly; it is not\na retroactive alteration of the frozen cannon/rook price comparison.\n')
print('supplement',len(source_names)+len(raw_names),'extracted/rehashed members; original archives unchanged')
