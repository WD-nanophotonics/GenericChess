"""Declare a real drop-enabled fixture; earlier capture fixture forbids drops."""
import sys,json,hashlib
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from scripts.research_record import write_record
p=Path(__file__).parent;raw=(p/'cannon-mixture-candidate.json').read_bytes()
definition=ruleset_from_dict(json.loads(raw)['source_definition'])
definition=replace(definition,drop_allowed={**definition.drop_allowed,'C':((True,)*64,(True,)*64)})
out=p/'drop-event-definition.json';assert not out.exists()
write_record(out,dict(producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Declared new interface fixture: frozen cannon/rook mixture with C drop mask true at every square, both owners. Original fixture forbids all drops, so capture-to-hand history did not cover a drop. This intervention changes only the declared drop permission, no artificial runtime edits. Event-priority6-ply legal route, reference/search parity, no price utility or prior frozen-comparison alteration.',source_definition=ruleset_to_dict(definition)))
s=(p/'event-history.py').read_text().replace("out=p/'event-history-six.json'","out=p/'event-history-qualified.json'")
s=s.replace("sources=['promotion-event-definition.json','cannon-mixture-candidate.json']","sources=['promotion-event-definition.json','drop-event-definition.json']")
s=s.replace('frozen cannon/rook mixture','explicit C-drop-enabled cannon/rook mixture').replace('at most4 actual plies','at most6 actual plies')
(p/'event-history-qualified.py').write_text(s,encoding='utf-8')
