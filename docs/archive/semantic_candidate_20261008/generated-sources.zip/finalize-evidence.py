import sys,json,hashlib,zipfile,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;dest=ROOT/'docs/archive/semantic_candidate_20261008'
def pin(path):
 b=path.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
index=json.loads((dest/'index.json').read_bytes());result=ROOT/'docs/research/data/semantic_candidate_20261008.json';data=json.loads(result.read_bytes())
for key,name in [('drop_reference_followup','drop-reference-followup.json'),('capture_reset','capture-reset.json')]:data[key]=json.loads((p/name).read_bytes());data['raw_pins'][name]=pin(p/name)
write_record(result,data);index['current_result']=dict(path=result.relative_to(ROOT).as_posix(),**pin(result))
for archive,names in [('generated-sources.zip',['drop-reference-followup.py','capture-reset.py','finalize-evidence.py']),('generated-raw.zip',['drop-reference-followup.json','capture-reset.json'])]:
 with zipfile.ZipFile(dest/archive,'a',zipfile.ZIP_DEFLATED) as z:
  for name in names:assert name not in z.namelist();z.write(p/name,name);index['archives'][archive]['members'][name]=pin(p/name)
 with zipfile.ZipFile(dest/archive) as z,tempfile.TemporaryDirectory(dir=p) as tmp:
  assert z.testzip() is None;z.extractall(tmp)
  for name,expected in index['archives'][archive]['members'].items():assert pin(Path(tmp)/name)==expected
 index['archives'][archive].update(pin(dest/archive))
write_record(dest/'index.json',index)
# Verify every archived byte and declared member; public evidence is synthetic
# and contains neither private state nor raw Slack/account records.
checked=0
for archive,item in index['archives'].items():
 assert pin(dest/archive)=={k:item[k] for k in ('bytes','sha256')}
 with zipfile.ZipFile(dest/archive) as z:
  assert set(z.namelist())==set(item['members'])
  for name,expected in item['members'].items():
   b=z.read(name);assert hashlib.sha256(b).hexdigest()==expected['sha256'] and len(b)==expected['bytes'];checked+=1
print(checked,'archive members verified')
