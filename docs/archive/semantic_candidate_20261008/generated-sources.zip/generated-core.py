"""Independent legacy Core pseudo-mobility and observed opening terminal check."""
import sys,json,time,random,math,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.coordinates import index_to_square
from generic_chess.core.movegen import _piece_actions,legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.terminal import terminal_result
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'generated-core.json';assert not out.exists();start=time.perf_counter();source=(p/'generated-interface.json').read_bytes();observed=json.loads(source)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(source).hexdigest(),declaration='Same four frozen generated inputs, no filtering/replacement. Independent legacy Core pseudo board moves, no anchor safety, promotion/drop expansion or WDL pricing. For each ordinary type/density .25/.5 draw2048 both-owner/all-source virtual occupancies from a fixed seed; identical actor/filler type, empty1-d friend/enemy d/2, remove source occupant. Deduplicate original-source targets. Report mean/SE against exact projected curve, no success cutoff or refitting. Separately enumerate each real opening child terminal to assess existing filters; preserve degenerate roots as tactical controls rather than price evidence.',cases=[])
write_record(out,r)
for case in observed['cases']:
 n,seed=case['board_size'],case['seed'];g=generate_game(GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True));c=compile_ruleset_for_execution(g.ruleset);session=GameSession(c);state=session.state;item=dict(board_size=n,seed=seed,rows=[],opening_children=[]);r['cases'].append(item)
 for action in legal_actions(state,c):
  child=apply_action(state,action,c);terminal=terminal_result(child,c)
  item['opening_children'].append(dict(action=record_value(action),terminal=record_value(terminal)))
 for pt in c.piece_types:
  if pt.is_anchor:continue
  for density in (.25,.5):
   rng=random.Random(2026100841+seed*1000+n*100);samples=2048;values=[]
   for sample in range(samples):
    owner=rng.randrange(2);source=rng.randrange(n*n);board=[]
    for square in range(n*n):
     z=rng.random();board.append(None if z>=density else Piece(owner if z<density/2 else 1-owner,pt.type_id,pt.type_id))
    board[source]=Piece(owner,pt.type_id,pt.type_id)
    position=replace(state.position,board=tuple(board),side_to_move=owner)
    origin=index_to_square(source,n);targets={a.to_square for a in _piece_actions(position,c) if a.from_square==origin};values.append(len(targets))
   mean=sum(values)/samples;se=math.sqrt(sum((x-mean)**2 for x in values)/(samples-1)/samples);expected=next(x['total'] for x in case['candidate_scope']['types'][pt.type_id]['curves'] if x['density']==density)
   item['rows'].append(dict(type_id=pt.type_id,density=density,samples=samples,mean=mean,standard_error=se,projected=expected,difference=mean-expected,standardized_difference=(mean-expected)/se if se else None))
  write_record(out,r)
 # Reference/search parity is checked on all retained cells, never by the sample statistic.
 for control in case['controls']:
  assert control['reference']['complete'] and all(control['repeat_equal'].values())
  assert all(x['complete'] and x['reference_score_equal'] for x in control['calls'])
 print(n,seed,'opening',len(item['opening_children']),'terminal',sum(x['terminal']['status']!='ongoing' for x in item['opening_children']),'largest-z',max(abs(x['standardized_difference'] or 0) for x in item['rows']),flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
