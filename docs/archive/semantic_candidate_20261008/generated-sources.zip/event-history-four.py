"""Candidate profile with actual history/hand/promotion and reused search."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.terminal import terminal_result
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'event-history.json';assert not out.exists();start=time.perf_counter()
sources=['promotion-event-definition.json','cannon-mixture-candidate.json']
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),library_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/semantic.py').read_bytes()).hexdigest(),declaration='Two event-targeted definitions: predeclared3entity supported Western promotion root and frozen cannon/rook mixture. Original lexical route had no promoted entities or hands, so did not cover those events. Prefer legal drop, then promotion, then enemy-target capture, then canonical first action, independent of evaluator; at most4 actual plies, stop at genuine terminal. Not a holdout/price test. At each root same opt-in profile and static-only dynamic config with normal hand_weight. Compare cold and reused player depth2/4096nodes/5sec q0/root-tactical-off, fresh Core minimax leaf4096/5sec. Also repeat reused root to expose TT hit contract. Validate all public PV/actions; allow established warm empty-PV contract, no full-PV claim. Record actual histories, hands, promoted entities and transitions; no winrate/true-price claim from artificial route. Incomplete references unknown, never zero.',source_pins={name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in sources},cases=[])
write_record(out,r);cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);limits=SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0)
for name in sources:
 definition=json.loads((p/name).read_bytes())['source_definition'];c=compile_ruleset_for_execution(ruleset_from_dict(definition));session=GameSession(c);profile,scope=build_semantic_opportunity_profile(c,cfg);ev=Evaluator(c,profile,cfg)
 def make():return AlphaBetaPlayer(c,evaluation_config=cfg,use_disk_cache=False,evaluator_override=ev,tuning=SearchTuning(use_root_tactical=False),tt_max_entries=4096)
 reused=make();item=dict(source=name,compiled_class=type(c).__name__,rows=[],transitions=[],terminal=None);r['cases'].append(item)
 for ply in range(4):
  terminal=terminal_result(session.state,c)
  if terminal.is_terminal:item['terminal']=record_value(terminal);break
  reference=CountedEvaluator(ev)
  try:score,action=reference_minimax(session.state,2,reference,c);ref=dict(complete=True,score=score,action=record_value(action))
  except ReferenceLimit:ref=dict(complete=False,score=None,action=None)
  ref['evaluations']=reference.calls;row=dict(ply=ply,reference=ref,hands=record_value(session.state.position.hands),promoted=sum(bool(x.promoted) for x in session.state.position.board if x is not None),history_length=len(session.state.history),calls=[]);item['rows'].append(row);write_record(out,r)
  for label,player in (('fresh',make()),('reused',reused),('reused_repeat',reused)):
   decision=player.choose_action(session,limits);validate_pv(session,decision);value=record_value(decision)
   row['calls'].append(dict(label=label,complete=decision.completed_depth==2,reference_score_equal=(decision.score==ref['score']) if ref['complete'] and decision.completed_depth==2 else None,decision=value));write_record(out,r)
  signatures={(x['decision']['score'],x['decision']['completed_depth']) for x in row['calls'] if x['complete']};assert len(signatures)<=1
  assert all(x['reference_score_equal'] is not False for x in row['calls'])
  
  def priority(a):
   v=record_value(a);target=v.get('to_square');occupant=session.state.position.board[target['rank']*c.board_size+target['file']] if target else None
   event=0 if 'from_square' not in v else 1 if v.get('promotion_target_id') else 2 if occupant is not None and occupant.owner!=session.state.position.side_to_move else 3
   return event,json.dumps(v,sort_keys=True)
  route=sorted(session.legal_actions(),key=priority)[0];item['transitions'].append(record_value(route));session.submit(route)
 print(name,'roots',len(item['rows']),'calls',sum(len(x['calls']) for x in item['rows']),'terminal',item['terminal'],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
