"""Predeclared legacy-generator boundary; no artificial DSL or executor change."""
import sys,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.compiler import compile_ruleset_for_execution,compile_semantic_ruleset
from generic_chess.rules.validation import RuleValidationError
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.mobility import atoms_overlap,analytic_mobility_at_density
from scripts.unfamiliar_search import run_rule
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'generated-interface.json';assert not out.exists()
start=time.perf_counter();r=dict(complete=False,declaration='Four predeclared existing-generator inputs: board4/6, seeds7/21, bilateral_random, hybrid allowed. Existing generator filters only, no result selection. Legacy product execution retained; existing compile_semantic_ir used for analysis, not a synthetic DSL action. Both profiles static-only, same depth2/4096nodes/5sec q0 and2cold plain/public repeats. Independent analytic nonoverlap curves checked; hybrid union is exact in candidate and sampled in old table, not equal-formula claim. Small exposed development, not strength/material validation.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),library_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/semantic.py').read_bytes()).hexdigest(),cases=[])
write_record(out,r);cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for n,seed in ((4,7),(4,21),(6,7),(6,21)):
 generated=generate_game(GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True));c=compile_ruleset_for_execution(generated.ruleset)
 assert not generated.ruleset.semantic_actions and not hasattr(c,'ir')
 try:compile_semantic_ruleset(generated.ruleset)
 except RuleValidationError as error:rejected=str(error)
 else:raise AssertionError('semantic DSL unexpectedly accepted empty actions')
 prof,scope=build_semantic_opportunity_profile(c,cfg);analytic=[]
 for pt in c.piece_types:
  if not atoms_overlap(pt.movement_atoms):
   differences=[x['total']-analytic_mobility_at_density(n,pt.movement_atoms,x['density']) for x in scope['types'][pt.type_id]['curves']]
   assert max(map(abs,differences))<1e-10;analytic.append(dict(type_id=pt.type_id,max_difference=max(map(abs,differences))))
 case=dict(board_size=n,seed=seed,compiled_class=type(c).__name__,semantic_DSL_rejection=rejected,ir_source=scope['ir_source'],analytical_checks=analytic,candidate_scope=scope,controls=[]);r['cases'].append(case);write_record(out,r)
 for label,optional in (('baseline',False),('candidate',True)):
  filename=f'generated-{n}-{seed}-{label}.json';v=run_rule(p/filename,ruleset_to_dict(generated.ruleset),depth=2,semantic_candidate=optional,evaluation_config=cfg)
  case['controls'].append(dict(label=label,path=filename,sha256=hashlib.sha256((p/filename).read_bytes()).hexdigest(),compiled_class=v['compiled_class'],board_values=v['board_values'],opening_legal_actions=v['opening_legal_actions'],reference=v['reference'],repeat_equal=v['repeat_equal'],calls=[dict(control=x['control'],complete=x['complete'],reference_score_equal=x['reference_score_equal'],decision=x['decision'],seconds=x['observed_search_seconds']) for x in v['searches']]))
  write_record(out,r)
 print(n,seed,[(x['label'],x['board_values'],x['reference']['score'],x['repeat_equal']) for x in case['controls']],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
