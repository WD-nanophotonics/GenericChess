from pathlib import Path
p=Path(__file__).parent
s=(p/'history-interface.py').read_text()
s=s.replace("out=p/'history-interface.json'","out=p/'event-history.json'")
s=s.replace("sources=['generated-4-7-candidate.json','generated-4-21-candidate.json','generated-6-7-candidate.json','generated-6-21-candidate.json','cannon-mixture-candidate.json']","sources=['promotion-event-definition.json','cannon-mixture-candidate.json']")
s=s.replace('Five frozen input definitions: four generated candidates and cannon/rook mixture, no outcome selection. Follow lexicographically first legal action by canonical serialized content, independent of evaluator, at most8 actual plies, stop at genuine terminal.','Two event-targeted definitions: predeclared3entity supported Western promotion root and frozen cannon/rook mixture. Original lexical route had no promoted entities or hands, so did not cover those events. Prefer legal drop, then promotion, then enemy-target capture, then canonical first action, independent of evaluator; at most4 actual plies, stop at genuine terminal. Not a holdout/price test.')
s=s.replace('range(8)','range(4)')
s=s.replace("route=sorted(session.legal_actions(),key=lambda a:json.dumps(record_value(a),sort_keys=True))[0]", """
  def priority(a):
   v=record_value(a);target=v.get('to_square');occupant=session.state.position.board[target['rank']*c.board_size+target['file']] if target else None
   event=0 if 'from_square' not in v else 1 if v.get('promotion_target_id') else 2 if occupant is not None and occupant.owner!=session.state.position.side_to_move else 3
   return event,json.dumps(v,sort_keys=True)
  route=sorted(session.legal_actions(),key=priority)[0]""")
(p/'event-history.py').write_text(s,encoding='utf-8')
