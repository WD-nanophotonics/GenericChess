"""Declared actual promotion root, separate from exposed lexical histories."""
import sys,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.pieces import Piece
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'promotion-event-definition.json';assert not out.exists()
rows=[[None]*8 for _ in range(8)]
for owner,tid,file,rank in ((0,'K',0,0),(1,'K',7,7),(0,'P',0,6)):rows[rank][file]=Piece(owner,tid,tid)
definition=replace(build_western_chess_ruleset(),initial_position=tuple(tuple(row) for row in rows))
write_record(out,dict(producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Predeclared3entity supported Western promotion fixture: ownKa1/Pa7 enemyKh8, side0. Real legality, all promotion choices, auxiliary rights and terminal rules retained. Event-priority route is for interface validation, no best-play/price/game-strength inference.',source_definition=ruleset_to_dict(definition)))
