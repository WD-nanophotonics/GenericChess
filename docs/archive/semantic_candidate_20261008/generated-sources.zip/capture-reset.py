"""Actual Shogi capture-reset boundary, not new board prices."""
import sys,hashlib,time
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'capture-reset.json';assert not out.exists();start=time.perf_counter();base=build_standard_shogi_ruleset();cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),library_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/semantic.py').read_bytes()).hexdigest(),declaration='Two predeclared4entity real Shogi roots: ownK(0,0),enemyK(8,8),ownR(4,1), enemyG or promotedP(4,4). Same current gold-like geometry, different captured base. Enumerate actual legal R capture and real transition; static-only dynamic terms, existing hand_weight0.9 retained. Does lookup already see different capture-reset outcomes despite equal board opportunity? No utility oracle, fitted prices or game-strength claim.',rows=[]);write_record(out,r)
for target in ('G','TP'):
 board=[[None]*9 for _ in range(9)]
 for owner,tid,f,rank in ((0,'K',0,0),(1,'K',8,8),(0,'R',4,1)):board[rank][f]=Piece(owner,tid,tid)
 board[4][4]=Piece(1,'P' if target=='TP' else 'G',target,target=='TP');definition=replace(base,initial_position=tuple(tuple(x) for x in board));c=compile_ruleset_for_execution(definition);session=GameSession(c);prof,scope=build_semantic_opportunity_profile(c,cfg);ev=Evaluator(c,prof,cfg)
 actions=[a for a in session.legal_actions() if a.from_square.file==4 and a.from_square.rank==1 and a.to_square.file==4 and a.to_square.rank==4 and a.promotion_target_id is None];assert len(actions)==1
 child=apply_action(session.state,actions[0],c);base_id='P' if target=='TP' else 'G';assert child.position.hands[0].count(base_id)==1
 before=ev.evaluate(session.state);after=-ev.evaluate(child);expected=prof.board_value_by_type[target]+prof.hand_value_by_base_type[base_id];assert after-before==expected
 r['rows'].append(dict(target=target,definition=ruleset_to_dict(definition),board_value=prof.board_value_by_type[target],base_hand_value=prof.hand_value_by_base_type[base_id],raw_opportunity=scope['types'][target]['raw'],actual_capture=record_value(actions[0]),hands=record_value(child.position.hands),score_gain=after-before));write_record(out,r)
assert r['rows'][0]['board_value']==r['rows'][1]['board_value'] and r['rows'][0]['raw_opportunity']==r['rows'][1]['raw_opportunity']
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print([(x['target'],x['board_value'],x['base_hand_value'],x['score_gain']) for x in r['rows']])
