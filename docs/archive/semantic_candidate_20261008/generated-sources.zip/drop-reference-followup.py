"""New bounded batch for one unknown reference; original fuse result stays unknown."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'drop-reference-followup.json';assert not out.exists();raw=(p/'event-history-qualified.json').read_bytes();source=json.loads(raw)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),library_sha256=hashlib.sha256((ROOT/'generic_chess/ai/evaluation/semantic.py').read_bytes()).hexdigest(),declaration='One unknown actual drop-enabled history reference. New development batch only: replay exact saved legal transitions, then Core depth2 leaf8192/time10sec. No new public-player budget, no old frozen result/status mutation. A discrepancy would block this interface claim; equality extends coverage, not prices/strength. Remaining fuse stays unknown. Incremental maximum10sec, no worker/fees.',rows=[])
write_record(out,r);start=time.perf_counter()
for case in source['cases']:
 unknown=[x for x in case['rows'] if not x['reference']['complete']]
 if not unknown:continue
 c=compile_ruleset_for_execution(ruleset_from_dict(json.loads((p/case['source']).read_bytes())['source_definition']));session=GameSession(c);cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profile,scope=build_semantic_opportunity_profile(c,cfg);ev=Evaluator(c,profile,cfg)
 for row in case['rows']:
  if not row['reference']['complete']:
   counted=CountedEvaluator(ev,seconds=10,evaluations=8192)
   try:score,action=reference_minimax(session.state,2,counted,c);v=dict(complete=True,score=score,action=record_value(action),public_scores_equal=all(x['decision']['score']==score for x in row['calls']))
   except ReferenceLimit:v=dict(complete=False,score=None,public_scores_equal=None)
   v.update(ply=row['ply'],leaf_evaluations=counted.calls);r['rows'].append(v);write_record(out,r)
  transition=case['transitions'][row['ply']];matched=[a for a in session.legal_actions() if record_value(a)==transition];assert len(matched)==1;session.submit(matched[0])
r.update(complete=all(x['complete'] for x in r['rows']),seconds=time.perf_counter()-start);write_record(out,r);print(r['rows'],r['seconds'])
