"""Alternating paired full-record consumer timing; no Native queries or product writes."""
from pathlib import Path
import sys,json,time,hashlib,importlib.util,random,os
from collections import defaultdict
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
import generic_chess.session.session as ss
D=R/'.local_agent/core-submit-cost-20261018';I=R/'.local_agent/acquisition-cost-20261018';start=time.perf_counter()
spec=importlib.util.spec_from_file_location('generic_chess.core._pinned_baseline_transition',D/'baseline-transition.py');baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
spec=importlib.util.spec_from_file_location('candidate',D/'candidate.py');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
assert not(D/'benchmark-started.json').exists();write_json(D/'benchmark-started.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((D/'candidate.py').read_bytes()).hexdigest(),rounds=3,limits_seconds=600,scope='Actual GameSession.replay consumer; retained fullrecords, original vs candidate actionapply only, no fresh generation/Native. Compilation andJSONparseoutside timer, allsession/historyvalidationinside. Warm process, alternatingold/new byround/slot; concurrentexternalmachine load not controlled.'))
original=ss.apply_action;rows=[];gens={};points=[]
for line in(I/'records.jsonl').open(encoding='utf-8'):
 q=json.loads(line)
 if q['kind']=='GENERATION':gens[q['key']]=q
 else:points.append(q)
# Last64target perrule measures the longest actually available fullrecord; terminal early records retained.
points=[q for q in points if q['target_prefix']==64];assert len(points)==384
rng=random.Random(2026101805);rng.shuffle(points);compiled={k:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))for k,g in gens.items()if g['status']=='SUCCESS'};records={q['key']:deserialize_game_record(json.dumps(q['record']))for q in points}
def poll():
 assert time.perf_counter()-start<600,'BENCHMARK_CAP'
 for n in ['rollout','advisor','slack']:
  d=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(d.get('stopped')or d.get('user_paused')),'EXPLICIT_STOP'
try:
 for round_id in range(3):
  for i,q in enumerate(points):
   poll();children={}
   for label in (['old','candidate']if(i+round_id)%2==0 else['candidate','old']):
    ss.apply_action=baseline.apply_action if label=='old'else lambda s,a,c:candidate.candidate_apply(s,a,c,baseline)
    tick=time.perf_counter();session=ss.GameSession.replay(compiled[q['key']],records[q['key']]);elapsed=time.perf_counter()-tick;children[label]=(session.state,session.history,session.to_record(),session._search_witnesses);rows.append(dict(round=round_id,key=q['key'],seed=q['seed'],size=q['size'],filter=q['filter'],actual_prefix=q['actual_prefix'],label=label,seconds=elapsed))
   assert children['old']==children['candidate']
  print('CORE_BENCH_ROUND',round_id,len(rows),time.perf_counter()-start,flush=True)
finally:ss.apply_action=original
summary={}
for size in ['all',4,6,8]:
 r=[r for r in rows if size=='all'or r['size']==size]
 sums={label:sum(x['seconds']for x in r if x['label']==label)for label in ['old','candidate']};summary[str(size)]=dict(seconds=sums,candidate_over_old=sums['candidate']/sums['old'])
write_json(D/'benchmark-result.json',dict(status='PASS_FULL_RECORD_PAIRED_CONSUMER',rows=rows,summary=summary,seconds=time.perf_counter()-start,all_full_states_histories_equal=True,scope='Threealternating paired consumerrounds on384fullrecords, not independenthardware/speedpopulation trials or wholeacquisition/Nativeacceleration. No product/default code orotherprocess changed.'));print(summary,flush=True)
