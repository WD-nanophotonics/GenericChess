"""Dot's concrete boundary: true terminal GameState with still-playable Position."""
from pathlib import Path
import sys,json,time,importlib.util
from dataclasses import replace
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
D=R/'.local_agent/core-submit-cost-20261018';start=time.perf_counter()
spec=importlib.util.spec_from_file_location('generic_chess.core._pinned_baseline_transition',D/'baseline-transition.py');baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
spec=importlib.util.spec_from_file_location('candidate',D/'candidate.py');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
c=compile_semantic_ruleset(replace(build_western_chess_ruleset(),max_ply=1,automatic_adjudications=(),declarations=()));s=GameSession(c);s.submit(s.legal_actions()[0]);assert s.result.status.value=='max_ply';record=s.to_record();replayed=GameSession.replay(c,record);assert replayed.state==s.state;engine=semantic_engine_for(c);bindings=tuple(engine.iter_legal_actions(s.state.position));assert bindings;action=_semantic_public_action(engine,bindings[0]);before=(s.state,s.history,s._search_witnesses,s.to_record());errors=[]
for fn in [baseline.apply_action,lambda state,a,c:candidate.candidate_apply(state,a,c,baseline)]:
 try:fn(s.state,action,c)
 except Exception as exc:errors.append(dict(type=type(exc).__name__,message=str(exc)))
 else:raise AssertionError('TERMINAL_PARENT_ACCEPTED')
assert errors[0]==errors[1]and errors[0]['type']=='IllegalActionError';assert before==(s.state,s.history,s._search_witnesses,s.to_record())
write_json(D/'terminal-guard-result.json',dict(status='PASS_REAL_REPLAY_MAX_PLY_GUARD',record=record_value(record),root_terminal=record_value(s.result),still_legal_position_actions=len(bindings),tested_action=record_value(action),errors=errors,seconds=time.perf_counter()-start,scope='Real legalinitialmove andrecordreplay, nohandwritten terminalflag. ParentGameState terminalguard retained despite Position-level legalaction availability. Dot1792313591.852889 source-review advice nowactuallyexecuted locally, not Dotindependentexecution.'));print('PASS terminalguard')
