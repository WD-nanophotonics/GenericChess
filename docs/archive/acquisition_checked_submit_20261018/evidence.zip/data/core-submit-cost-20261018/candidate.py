"""Private candidate: keep legal membership and unique binding, skip duplicate enumeration."""
def candidate_apply(state,action,compiled,baseline):
 from generic_chess.core.actions import PassAction
 from generic_chess.core.errors import IllegalActionError,ensure_ruleset_match
 from generic_chess.core.terminal import TerminalStatus
 from generic_chess.core.semantic_executor import semantic_engine_for,semantic_action_for
 engine=semantic_engine_for(compiled)
 if engine is None or isinstance(action,PassAction):return baseline.apply_action(state,action,compiled)
 ensure_ruleset_match(state.position,compiled)
 if state.terminal_status.status is not TerminalStatus.ONGOING:raise IllegalActionError(f'cannot apply an action to a terminal state ({state.terminal_status})')
 semantic_action=semantic_action_for(engine,state.position,action)
 pattern=next(p for p in engine.ir.patterns if p.pattern_id==semantic_action.pattern_id)
 binding=engine._make_binding_from_action(state.position,semantic_action,pattern)
 return baseline._semantic_transition(state,semantic_action,binding,action,compiled)
