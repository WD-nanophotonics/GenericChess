"""Finite higher-branching generated Core submit comparison; no search/training."""
from pathlib import Path
from dataclasses import asdict
from collections import Counter
import sys,json,time,random,hashlib,importlib.util,traceback
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.transition import apply_action as actual_apply
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
D=R/'.local_agent/largeboard-submit-20261018';A=R/'.local_agent/core-submit-cost-20261018';P=json.loads((D/'plan.json').read_bytes());assert hashlib.sha256(Path('generic_chess/core/transition.py').read_bytes()).hexdigest()==P['source_transition_sha256'];assert not(D/'started.json').exists();start=time.perf_counter();counts=Counter();rows=[];status='COMPLETE';reason=None
spec=importlib.util.spec_from_file_location('generic_chess.core._largeboard_baseline',A/'baseline-transition.py');baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
write_json(D/'started.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest()))

def poll():
 if time.perf_counter()-start>P['limits']['global_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 if counts['child_pairs']>=P['limits']['max_child_pairs']:raise TimeoutError('FROZEN_CHILDPAIR_CAP')
 for n in ['rollout','advisor','slack']:
  d=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(d.get('stopped')or d.get('user_paused')),'EXPLICIT_STOP'
try:
 with(D/'records.jsonl').open('x',encoding='utf-8')as jf:
  slots=[(s,n,p)for s in P['seeds']for n in P['board_sizes']for p in P['setups']];random.Random(2026101807).shuffle(slots)
  for idx,(seed,size,setup)in enumerate(slots):
   poll();tick=time.perf_counter();cfg=GeneratorConfig(seed=seed,board_size=size,setup_preset=setup,movement_symmetry=P['symmetry'],allow_hybrid=True,max_generation_attempts=16,require_no_opening_win_in_one=False);g=dict(kind='RULE',slot=idx,seed=seed,size=size,setup=setup,config=asdict(cfg))
   try:game=generate_game(cfg)
   except GenerationError as exc:g.update(status='GENERATION_REFUSAL',error=str(exc),generation_seconds=time.perf_counter()-tick);jf.write(json.dumps(g)+'\n');jf.flush();counts['generation_refusals']+=1;counts['generation_calls']+=1;continue
   g['generation_seconds']=time.perf_counter()-tick;c=compile_legacy_ruleset_for_semantic_execution(game.ruleset);g.update(status='GENERATED',rules=ruleset_to_dict(game.ruleset),fingerprint=c.ruleset_fingerprint,types=sorted(c.types_by_id));tick=time.perf_counter()
   try:native=compile_native_semantic_rules(c);g['native_admission']='SUPPORTED';native=None;counts['native_admitted']+=1
   except NativeUnsupportedRuleError as exc:g.update(native_admission='EXPLICIT_REFUSAL',native_refusal=str(exc));counts['native_refused']+=1
   g['native_admission_seconds']=time.perf_counter()-tick;jf.write(json.dumps(g,separators=(',',':'))+'\n');jf.flush();counts['generation_calls']+=1;counts['rules']+=1;s=GameSession(c);rng=random.Random(seed*1000+size)
   for target in P['prefixes']:
    poll()
    while s.state.ply_count<target and s.result.status.value=='ongoing':
     aa=sorted(s.legal_actions(),key=repr);a=aa[rng.randrange(len(aa))];old=baseline.apply_action(s.state,a,c);new=s.submit(a);assert old==new;counts['progression_pairs']+=1
    aa=s.legal_actions();before=(s.state,s.history,s.to_record(),s._search_witnesses);old_seconds=0.;new_seconds=0.;child_hashes=[]
    for i,a in enumerate(aa):
     poll();children={}
     for label in (['old','new']if(i+idx)%2==0 else['new','old']):
      tick=time.perf_counter();child=baseline.apply_action(s.state,a,c)if label=='old'else actual_apply(s.state,a,c);elapsed=time.perf_counter()-tick
      if label=='old':old_seconds+=elapsed
      else:new_seconds+=elapsed
      children[label]=child
     assert children['old']==children['new'];counts['child_pairs']+=1;counts['drops']+=getattr(a,'from_square',None)is None;counts['promotions']+=getattr(a,'promotion_target_id',None)is not None;child_hashes.append(hashlib.sha256(json.dumps(record_value(children['new']),sort_keys=True,separators=(',',':')).encode()).hexdigest())
    assert before==(s.state,s.history,s.to_record(),s._search_witnesses);r=dict(kind='POINT',slot=idx,seed=seed,size=size,setup=setup,target_prefix=target,actual_prefix=s.state.ply_count,root_result=record_value(s.result),record=json.loads(serialize_game_record(s.to_record())),legal_actions=[record_value(a)for a in aa],child_state_sha256=child_hashes,old_seconds=old_seconds,new_seconds=new_seconds);rows.append(r);jf.write(json.dumps(r,separators=(',',':'))+'\n');jf.flush();counts['roots']+=1;print('LARGE_ROOT',size,idx,target,'children',len(aa),'seconds',round(time.perf_counter()-start,3),flush=True)
    if jf.tell()>P['limits']['max_output_bytes']:raise TimeoutError('FROZEN_OUTPUT_CAP')
except BaseException as exc:status='PARTIAL_CAP'if isinstance(exc,TimeoutError)else'ERROR';reason=repr(exc);traceback.print_exc()
summary={}
for size in P['board_sizes']:
 rr=[r for r in rows if r['size']==size];a=sum(r['old_seconds']for r in rr);b=sum(r['new_seconds']for r in rr);summary[str(size)]=dict(roots=len(rr),child_pairs=sum(len(r['legal_actions'])for r in rr),old_seconds=a,new_seconds=b,new_over_old=b/a if a else None)
result=dict(status=status,reason=reason,counts=dict(counts),planned_rules=12,missing_generation_calls=12-counts['generation_calls'],planned_roots=36,missing_or_unavailable_roots=36-counts['roots'],by_board=summary,seconds=time.perf_counter()-start,scope='Fullchildstate equality andpairedapplicationtime onfiniteactual10/12/16generatedrules, declaredold/newalternation. Retainsgeneratorrefusals/earlyterminals/UNKNOWNtail, actualNativeadmission not search/fallbackexecution. No learning/fitness/all-domainproof.');write_json(D/'result.json',result);print('LARGE_CLOSED',json.dumps(result),flush=True)
