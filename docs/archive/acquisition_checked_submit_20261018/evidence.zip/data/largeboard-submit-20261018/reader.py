"""Pure Core check of saved larger-board complete records and child state hashes."""
from pathlib import Path
import sys,json,time,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import apply_action
D=R/'.local_agent/largeboard-submit-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));start=time.perf_counter();rules=roots=children=0
for line in (D/'records.jsonl').open(encoding='utf8'):
 for n in ['rollout','advisor','slack']:
  q=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not(q.get('stopped')or q.get('user_paused'))
 assert time.perf_counter()-start<300
 q=json.loads(line)
 if q['kind']=='RULE':
  assert q['status']=='GENERATED';c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(q['rules']));assert c.ruleset_fingerprint==q['fingerprint'];rules+=1;continue
 s=GameSession.replay(c,deserialize_game_record(json.dumps(q['record'])));assert s.state.ply_count==q['actual_prefix'];assert record_value(s.result)==q['root_result'];aa=s.legal_actions();assert [record_value(a)for a in aa]==q['legal_actions'];hh=[hashlib.sha256(json.dumps(record_value(apply_action(s.state,a,c)),sort_keys=True,separators=(',',':')).encode()).hexdigest()for a in aa];assert hh==q['child_state_sha256'];roots+=1;children+=len(aa)
assert (rules,roots,children)==(12,36,2209)
write_json(D/'reader-result.json',dict(status='PASS_SAVED_LARGEBOARD_CORE_CHILDREN',rules=rules,roots=roots,children=children,seconds=time.perf_counter()-start,scope='Pure Core replay/fullchildhashes only; no regeneration, Native compilation, query, timing replication, training or independent external rules authority.'))
print('LARGE_READER_PASS',roots,children,flush=True)
