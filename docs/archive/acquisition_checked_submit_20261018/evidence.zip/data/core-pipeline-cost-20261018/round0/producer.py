"""Prospective complete acquisition cost, existing generator/Native interfaces."""
from pathlib import Path
BOOT=__import__('time').perf_counter()
import sys,time,json,random,hashlib,traceback,math,subprocess
from collections import Counter
from copy import copy
from dataclasses import asdict
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.learning.features import material_features
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.ai.limits import SearchLimits

import importlib.util
_core_control_dir=R/'.local_agent/core-submit-cost-20261018'
_spec=importlib.util.spec_from_file_location('generic_chess.core._timing_baseline_transition',_core_control_dir/'baseline-transition.py');_baseline=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_baseline)
_spec=importlib.util.spec_from_file_location('_timing_candidate',_core_control_dir/'candidate.py');_candidate=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_candidate)
import generic_chess.core.transition as _ct
import generic_chess.session.session as _ss
import generic_chess.native.adapter as _adapter
_original_apply=_ct.apply_action
_alias_targets=[]
for _module in list(sys.modules.values()):
 if _module is not None and getattr(_module,'__name__','').startswith(('generic_chess.','scripts.research_record')):
  for _name,_value in list(vars(_module).items()):
   if _value is _original_apply:_alias_targets.append((_module,_name))
def set_backend(label):
 fn=_baseline.apply_action if label=='old' else lambda s,a,c:_candidate.candidate_apply(s,a,c,_baseline)
 for module,name in _alias_targets:setattr(module,name,fn)

D=R/'.local_agent/core-pipeline-cost-20261018'/'round0';P=json.loads((D/'plan.json').read_bytes());began=time.perf_counter();rows=Counter();status='COMPLETE';reason=None
assert not (D/'started.json').exists()
write_json(D/'started.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),base_sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),startup_seconds=began-BOOT))
slots=[(s,n,p,y) for s in P['seeds'] for n in P['board_sizes'] for p in P['setups'] for y in P['symmetries']];random.Random(2026101803).shuffle(slots)
write_json(D/'slots.json',dict(pairs=slots))
def poll():
 if time.perf_counter()-began>P['limits']['global_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for name in ['rollout','advisor','slack']:
  d=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());assert not(d.get('user_paused') or d.get('stopped')),'EXPLICIT_STOP'
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
try:
 with (D/'records.jsonl').open('x',encoding='utf-8') as out,(D/'timings.jsonl').open('x',encoding='utf-8') as timings:
  for slot,(seed,size,setup,sym) in enumerate(slots):
   for flag,label in [(f,l)for f in ([False,True]if seed%2==0 else[True,False])for l in (['old','candidate']if(slot+0)%2==0 else['candidate','old'])]:
    poll();set_backend(label);rule_start=time.perf_counter();key=f'{slot}-{int(flag)}-{label}';base=dict(key=key,slot=slot,seed=seed,size=size,setup=setup,symmetry=sym,filter=flag,backend=label);phase={};cfg=GeneratorConfig(seed=seed,board_size=size,setup_preset=setup,movement_symmetry=sym,allow_hybrid=True,max_generation_attempts=P['max_generation_attempts'],require_no_opening_win_in_one=flag)
    tick=time.perf_counter()
    try:game=generate_game(cfg)
    except GenerationError as exc:
     phase['generation_seconds']=time.perf_counter()-tick;row=dict(base,kind='GENERATION',status='REFUSAL',error=str(exc),config=asdict(cfg));t=time.perf_counter();out.write(json.dumps(row,separators=(',',':'))+'\n');out.flush();phase['write_seconds']=time.perf_counter()-t;timings.write(json.dumps(dict(base,kind='GENERATION',status='REFUSAL',phases=phase,online_seconds=time.perf_counter()-rule_start))+'\n');timings.flush();rows['refusals']+=1;rows['generation_calls']+=1;continue
    phase['generation_seconds']=time.perf_counter()-tick;tick=time.perf_counter();c=compile_legacy_ruleset_for_semantic_execution(game.ruleset);phase['compile_seconds']=time.perf_counter()-tick;tick=time.perf_counter();profile=build_ruleset_profile(c,EvaluationConfig());types=tuple(sorted(t.type_id for t in c.piece_types if not t.is_anchor));anchors={t.type_id for t in c.piece_types if t.is_anchor};alltypes=set(c.types_by_id);assert set(profile.board_value_by_type)==set(profile.hand_value_by_base_type)==alltypes
    cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='complete-acquisition-existing-static',board_weights={t:0. if t in anchors else profile.board_value_by_type[t]/1000 for t in alltypes},hand_weights={t:0. if t in anchors else profile.hand_value_by_base_type[t]/1000 for t in alltypes},material_scale=256,value_scale=10.,reference_median=1.);phase['profile_seconds']=time.perf_counter()-tick;tick=time.perf_counter();refusal=None
    try:native=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,native,checkpoint=cp,tt_megabytes=0)
    except NativeUnsupportedRuleError as exc:engine=None;refusal=str(exc)
    phase['native_init_seconds']=time.perf_counter()-tick;tick=time.perf_counter();s=GameSession(c);phase['session_init_seconds']=time.perf_counter()-tick
    row=dict(base,kind='GENERATION',status='SUCCESS',config=asdict(cfg),rules=ruleset_to_dict(game.ruleset),checkpoint=cp.to_dict(),generation_report=record_value(game.generation_report),fingerprint=c.ruleset_fingerprint,types=types);tick=time.perf_counter();out.write(json.dumps(row,separators=(',',':'))+'\n');out.flush();phase['write_seconds']=time.perf_counter()-tick;timings.write(json.dumps(dict(base,kind='GENERATION',status='SUCCESS',phases=phase,online_seconds=time.perf_counter()-rule_start))+'\n');timings.flush();rows['generation_calls']+=1;rows['successful_generations']+=1;rng=random.Random(seed*1000+size)
    for target in P['prefixes']:
     poll();point_start=time.perf_counter();phase={};tick=time.perf_counter()
     while s.state.ply_count<target and s.result.status.value=='ongoing':
      aa=sorted(s.legal_actions(),key=repr);assert aa;s.submit(aa[rng.randrange(len(aa))])
     phase['prefix_seconds']=time.perf_counter()-tick;before=(s.state,s.to_record(),s.history,s._search_witnesses);row=dict(base,kind='POINT',target_prefix=target,actual_prefix=s.state.ply_count,status='TERMINAL_ROOT',gradient_nonzero=False,nodes=0,root_state_sha256=digest(s.state),root_witness_sha256=digest(s._search_witnesses),root_result=record_value(s.result));tick=time.perf_counter();record=serialize_game_record(s.to_record());row['record']=json.loads(record);phase['root_encode_seconds']=time.perf_counter()-tick
     if s.result.status.value=='ongoing':
      if engine is None:row.update(status='NATIVE_REFUSAL',gradient_nonzero=None,refusal=refusal)
      else:
       tick=time.perf_counter();r=engine.search(s,SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=.5,quiescence_max_depth=0),root_window_pruning=False);phase['query_seconds']=time.perf_counter()-tick;row.update(status='USABLE' if r.completed_depth>=1 and not r.used_fallback else 'INCOMPLETE_UNKNOWN',depth=r.completed_depth,fallback=r.used_fallback,nodes=r.nodes,score=r.score,cause=r.termination_reason,decision_line=record_value(r.decision_line),action=record_value(r.action),gradient_nonzero=None);rows['queries']+=1;rows['nodes']+=r.nodes
       if row['status']=='USABLE':
        tick=time.perf_counter();leaf=copy(s)
        for a in r.decision_line:
         if isinstance(a,str):leaf.declare(a)
         else:leaf.submit(a)
        phase['pv_replay_seconds']=time.perf_counter()-tick;tick=time.perf_counter();f=material_features(leaf.state.position,types,perspective=0);vector=f.array();coeff=[cp.board_weights[t] for t in types]+[cp.hand_weights[t] for t in types];terminal=leaf.result.status.value!='ongoing'
        if terminal:
         assert leaf.result.declaration_outcome not in ['NO_CONTEST','RESTART'];z=0 if leaf.result.winner is None else (1 if leaf.result.winner==0 else -1);pred=float(z);gradient=[0.]*len(vector);expected=(100000000-len(r.decision_line))*z
        else:pred=math.tanh(sum(v*w for v,w in zip(vector,coeff))/10.);gradient=[v*(1-pred*pred)/10 for v in vector];expected=sum(v*round(w*256) for v,w in zip(vector,coeff))
        assert expected==r.score*(1 if s.state.position.side_to_move==0 else -1),'LEAF_INTEGER_SCORE_MISMATCH';row.update(leaf_phi=vector,prediction=pred,gradient=gradient,gradient_nonzero=any(gradient),leaf_result=record_value(leaf.result),leaf_actual_terminal=terminal);phase['features_seconds']=time.perf_counter()-tick;rows['usable']+=1;rows['nonzero']+=bool(row['gradient_nonzero'])
     assert before==(s.state,s.to_record(),s.history,s._search_witnesses),'ROOT_MUTATED';tick=time.perf_counter();out.write(json.dumps(row,separators=(',',':'))+'\n');out.flush();phase['write_seconds']=time.perf_counter()-tick;online=time.perf_counter()-point_start;timings.write(json.dumps(dict(base,kind='POINT',target_prefix=target,status=row['status'],phases=phase,online_seconds=online))+'\n');timings.flush();rows['points']+=1
    if rows['generation_calls']%16==0:print('ACQUIRED',rows['generation_calls'],rows['points'],'seconds',round(time.perf_counter()-began,3),flush=True)
    if rows['generation_calls']==32:
     forecast=(time.perf_counter()-began)/32*P['planned_generation_calls'];write_json(D/'cost-checkpoint.json',dict(calls=32,forecast_seconds=forecast,used_learning_outcomes=False));assert forecast<7200,'FORECAST_REQUIRES_DOT'
    if out.tell()+timings.tell()>P['limits']['max_output_bytes']:raise TimeoutError('FROZEN_OUTPUT_CAP')
except BaseException as exc:status='PARTIAL_CAP' if isinstance(exc,TimeoutError) else 'ERROR';reason=repr(exc);traceback.print_exc()
result=dict(status=status,reason=reason,counts=dict(rows),planned_generation_calls=P['planned_generation_calls'],planned_point_slots=P['planned_point_slots'],missing_generation_calls=P['planned_generation_calls']-rows['generation_calls'],unavailable_or_missing_point_slots=P['planned_point_slots']-rows['points'],seconds=time.perf_counter()-began,startup_seconds=began-BOOT,scope=P['scope']);write_json(D/'result.json',result);print('CLOSED',json.dumps(result),flush=True)
