"""Three complete acquisition timing repetitions, old/candidate paired within each flag."""
from pathlib import Path
import sys,json,time,hashlib,subprocess,os
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/core-pipeline-cost-20261018';I=R/'.local_agent/acquisition-cost-20261018';P=json.loads((D/'plan.json').read_bytes());source=(I/'producer.py').read_text(encoding='utf-8-sig');assert hashlib.sha256((I/'producer.py').read_bytes()).hexdigest()==P['base_producer_sha256'];assert not(D/'started.json').exists()
# Imports complete BEFORE injection so references already bound in modules can be routed consistently.
inject='''
import importlib.util
_core_control_dir=R/'.local_agent/core-submit-cost-20261018'
_spec=importlib.util.spec_from_file_location('generic_chess.core._timing_baseline_transition',_core_control_dir/'baseline-transition.py');_baseline=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_baseline)
_spec=importlib.util.spec_from_file_location('_timing_candidate',_core_control_dir/'candidate.py');_candidate=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_candidate)
import generic_chess.core.transition as _ct
import generic_chess.session.session as _ss
import generic_chess.native.adapter as _adapter
_original_apply=_ct.apply_action
_alias_targets=[]
for _module in list(sys.modules.values()):
 if _module is not None and getattr(_module,'__name__','').startswith(('generic_chess.','scripts.research_record')):
  for _name,_value in list(vars(_module).items()):
   if _value is _original_apply:_alias_targets.append((_module,_name))
def set_backend(label):
 fn=_baseline.apply_action if label=='old' else lambda s,a,c:_candidate.candidate_apply(s,a,c,_baseline)
 for module,name in _alias_targets:setattr(module,name,fn)
'''
for round_id in range(3):
 target=D/('round'+str(round_id));target.mkdir();q=json.loads((I/'plan.json').read_bytes());q.update(planned_generation_calls=768,planned_point_slots=3072);q['limits']['global_seconds']=900;q['limits']['max_output_bytes']=P['limits']['per_round_output_bytes'];q['cost']+=' Pairedold/candidate process-localCorefunction only; labels alternate slot+round parity, conditions identical scientificinputs. Timing repeatedsamecases not independentsamples.';write_json(target/'plan.json',q)
 code=source.replace("D=R/'.local_agent/acquisition-cost-20261018';P=",inject+"\nD=R/'.local_agent/core-pipeline-cost-20261018'/"+repr('round'+str(round_id))+";P=",1)
 needle="for flag in ([False,True] if seed%2==0 else [True,False]):";assert code.count(needle)==1
 code=code.replace(needle,"for flag,label in [(f,l)for f in ([False,True]if seed%2==0 else[True,False])for l in (['old','candidate']if(slot+"+str(round_id)+")%2==0 else['candidate','old'])]:",1)
 code=code.replace("poll();rule_start=time.perf_counter();key=f'{slot}-{int(flag)}';base=dict(key=key,slot=slot,seed=seed,size=size,setup=setup,symmetry=sym,filter=flag)","poll();set_backend(label);rule_start=time.perf_counter();key=f'{slot}-{int(flag)}-{label}';base=dict(key=key,slot=slot,seed=seed,size=size,setup=setup,symmetry=sym,filter=flag,backend=label)",1)
 assert 'set_backend(label)'in code and'backend=label'in code;(target/'producer.py').write_bytes(code.encode())
# Declared-global cap covers allround subprocess startup/timing/recording.
began=time.perf_counter();write_json(D/'started.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),rounds=3,monotonic_start=began));steps=[];status='COMPLETE'
for round_id in range(3):
 for n in ['rollout','advisor','slack']:
  z=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(z.get('stopped')or z.get('user_paused'))
 target=D/('round'+str(round_id));tick=time.perf_counter()
 with(target/'producer.log').open('x',encoding='utf-8')as log:
  child=subprocess.Popen([sys.executable,'-X','utf8',str(target/'producer.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  while child.poll()is None:
   try:
    assert time.perf_counter()-began<P['limits']['total_seconds'],'FROZEN_GLOBAL_CAP'
    for n in ['rollout','advisor','slack']:
     z=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(z.get('stopped')or z.get('user_paused')),'EXPLICIT_STOP'
   except BaseException:child.terminate();child.wait();raise
   time.sleep(.25)
  assert child.returncode==0,('ROUND_PROCESS_ERROR',round_id)
 result=json.loads((target/'result.json').read_bytes());assert result['status']=='COMPLETE',(round_id,result);steps.append(dict(round=round_id,seconds=time.perf_counter()-tick,result=result));print('PIPELINE_ROUND',round_id,result['counts'],'seconds',steps[-1]['seconds'],flush=True)
write_json(D/'result.json',dict(status=status,steps=steps,seconds=time.perf_counter()-began,scope=P['scope']));print('PIPELINE_COMPLETE',time.perf_counter()-began,flush=True)
