"""Bind every timing repetition to the independently Core-qualified original science."""
from pathlib import Path
from collections import defaultdict,Counter
import json,hashlib
R=Path.cwd();import sys;sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/core-pipeline-cost-20261018';I=R/'.local_agent/acquisition-cost-20261018';base={}
def canonical(q):return{k:v for k,v in q.items()if k not in ['key','backend']}
for line in(I/'records.jsonl').open(encoding='utf-8'):
 q=json.loads(line);base[q['key'],q['kind'],q.get('target_prefix')]=canonical(q)
rows=[];count=Counter();whole=[]
for round_id in range(3):
 S=D/('round'+str(round_id));rt=json.loads((S/'result.json').read_bytes());whole.append(dict(round=round_id,seconds=rt['seconds'],startup_seconds=rt['startup_seconds']));times={}
 for line in(S/'timings.jsonl').open(encoding='utf-8'):
  t=json.loads(line);times[t['key'],t['kind'],t.get('target_prefix')]=t
 for line in(S/'records.jsonl').open(encoding='utf-8'):
  q=json.loads(line);key=q['key'].rsplit('-',1)[0];assert q['backend']in ['old','candidate'];assert canonical(q)==base[key,q['kind'],q.get('target_prefix')],('SCIENTIFIC_DIFFERENCE',round_id,q['key'],q.get('target_prefix'));t=times[q['key'],q['kind'],q.get('target_prefix')];assert t['status']==q['status'];rows.append(dict(round=round_id,seed=q['seed'],size=q['size'],filter=q['filter'],backend=q['backend'],kind=q['kind'],prefix=q.get('target_prefix'),online_seconds=t['online_seconds'],phases=t['phases'],nonzero=q.get('gradient_nonzero')is True));count['exact_scientific_rows']+=1;count['point_rows']+=q['kind']=='POINT';count['query_rows']+=q.get('status')=='USABLE'
def summary(rr):
 costs={label:sum(r['online_seconds']for r in rr if r['backend']==label)for label in ['old','candidate']};nonzero={label:sum(r['nonzero']for r in rr if r['backend']==label)for label in ['old','candidate']};assert nonzero['old']==nonzero['candidate'];byflag={}
 for flag in [False,True]:
  byflag[str(flag)]={label:dict(nonzero=sum(r['nonzero']for r in rr if r['backend']==label and r['filter']==flag),online_seconds=sum(r['online_seconds']for r in rr if r['backend']==label and r['filter']==flag),phase_seconds=dict(sum((Counter(r['phases'])for r in rr if r['backend']==label and r['filter']==flag),Counter())))for label in ['old','candidate']}
 return dict(costs=costs,nonzero=nonzero,candidate_over_old=costs['candidate']/costs['old'],by_filter=byflag)
q=dict(status='PASS_ALL_REPETITIONS_SCIENTIFICALLY_BOUND_AND_PAIRED_COST',counts=dict(count),overall=summary(rows),by_round={str(i):summary([r for r in rows if r['round']==i])for i in range(3)},by_board={str(n):summary([r for r in rows if r['size']==n])for n in [4,6,8]},actual_whole_run_costs=whole,scope='Threewithinconditionalternating completeacquisitionrepeats onSAME192pairs. Everygeneration/rule/profile/root/history/PV/score/node/depth/prediction/gradientfield exactlymatches independentlyCorequalifiedoriginal; timing-onlyfields separate. This is recordbinding/arithmetic, not9216independentCore replays, newfitness/training or universal speedup.')
write_json(D/'analysis.json',q);print(json.dumps(dict(counts=q['counts'],overall=q['overall'],by_round={k:v['candidate_over_old']for k,v in q['by_round'].items()},by_board={k:v['candidate_over_old']for k,v in q['by_board'].items()}),indent=2),flush=True)
