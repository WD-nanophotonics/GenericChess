"""Independent Core full-root/PV/Counter reconstruction of deeper served observations."""
from pathlib import Path
from collections import Counter
from copy import copy
from math import tanh
import json,time,sys,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=R/'.local_agent/acquisition-depth-cost-20261018';I=R/'.local_agent/acquisition-cost-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));start=time.perf_counter();counts=Counter();gens={};roots={}
for line in(I/'records.jsonl').open(encoding='utf-8'):
 r=json.loads(line)
 if r['kind']=='GENERATION':gens[r['key']]=r
 else:roots[r['key'],r['target_prefix']]=r
active=None

def poll():
 assert time.perf_counter()-start<900,'READER_CAP'
 for n in ['rollout','advisor','slack']:
  d=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not(d.get('stopped')or d.get('user_paused')),'EXPLICIT_STOP'
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(v):
 if isinstance(v,str):return v
 from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
 from generic_chess.core.coordinates import Square
 d=dict(v);d['to_square']=Square(**d['to_square'])
 if 'from_square'in d:d['from_square']=Square(**d['from_square']);return SemanticBoardMove(**d)
 return SemanticDropMove(**d)
for line in(D/'queries.jsonl').open(encoding='utf-8'):
 poll();q=json.loads(line);old=roots[q['key'],q['target_prefix']]
 if active!=q['key']:active=q['key'];g=gens[active];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']));types=tuple(g['types']);cp=g['checkpoint']
 s=GameSession.replay(c,deserialize_game_record(json.dumps(old['record'])));assert digest(s.state)==q['root_state_sha256']==old['root_state_sha256'];assert digest(s._search_witnesses)==q['root_witness_sha256']==old['root_witness_sha256'];counts['full_roots']+=1;counts['history_plies']+=s.state.ply_count
 if q['status']=='TERMINAL_ROOT':assert s.result.status.value!='ongoing'and q['gradient_nonzero']is False;counts['terminal_roots']+=1;continue
 assert s.result.status.value=='ongoing'
 if q['status']!='USABLE':counts[q['status']]+=1;continue
 assert q['decision_line']and q['decision_line'][0]==q['action']and decode(q['action'])in s.legal_actions();leaf=copy(s)
 for raw in q['decision_line']:
  a=decode(raw)
  if isinstance(a,str):leaf.declare(a)
  else:leaf.submit(a)
  counts['PV_edges']+=1
 b=Counter()
 for pc in leaf.state.position.board:
  if pc:b['board',pc.current_type_id]+=1 if pc.owner==0 else -1
 for t in types:b['hand',t]=leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t)
 v=[b[k,t]for k in ['board','hand']for t in types];assert v==q['leaf_phi'];terminal=leaf.result.status.value!='ongoing';assert terminal==q['leaf_actual_terminal']and record_value(leaf.result)==q['leaf_result']
 if terminal:
  z=0 if leaf.result.winner is None else (1 if leaf.result.winner==0 else -1);pred=float(z);grad=[0.]*len(v);score=(100000000-len(q['decision_line']))*z
 else:
  coeff=[cp['board_weights'][t]for t in types]+[cp['hand_weights'][t]for t in types];pred=tanh(sum(x*w for x,w in zip(v,coeff))/10.);grad=[x*(1-pred*pred)/10 for x in v];score=sum(x*round(w*256)for x,w in zip(v,coeff))
 assert pred==q['prediction']and grad==q['gradient']and bool(any(grad))==q['gradient_nonzero'];assert score==q['pv_literal_integer_score'];assert(score==q['score']*(1 if s.state.position.side_to_move==0 else -1))==q['search_score_matches_literal_pv'];assert 1<=q['depth']<=8 and not q['fallback'];counts['usable']+=1;counts['nonzero']+=q['gradient_nonzero'];counts['score_PV_differences']+=not q['search_score_matches_literal_pv'];counts['depth_'+str(q['depth'])]+=1
result=json.loads((D/'result.json').read_bytes());assert counts['full_roots']==result['counts']['points'];out=dict(status='PASS_ALL_RETURNED_DEEP_INPUT_CORE_RECORDS',counts=dict(counts),seconds=time.perf_counter()-start,scope='Every returnedfullroot/history andselectedPV legaltransition/terminal/Counter/conditionalrawpredictorgradient/literalintscore. General boundedsearch score/PVdifferences retained, notcertifieddefects orWDL. NoNativequeries/newgeneration/train; censoredtailUNKNOWN.');write_json(D/'reader-result.json',out);print(out,flush=True)
