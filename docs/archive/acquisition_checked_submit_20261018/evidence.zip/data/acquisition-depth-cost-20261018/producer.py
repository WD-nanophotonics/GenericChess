"""Actual bounded deeper search on fixed complete acquisition roots; no training."""
from pathlib import Path
from copy import copy
from collections import Counter
from math import tanh
import sys,json,time,hashlib,traceback
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.learning.features import material_features
from generic_chess.ai.limits import SearchLimits
D=R/'.local_agent/acquisition-depth-cost-20261018';I=R/'.local_agent/acquisition-cost-20261018';P=json.loads((D/'plan.json').read_bytes());assert hashlib.sha256((I/'records.jsonl').read_bytes()).hexdigest()==P['input_records_sha256'];assert not(D/'started.json').exists();write_json(D/'started.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),input_sha256=P['input_records_sha256']));began=time.perf_counter();counts=Counter();status='COMPLETE';reason=None;active=None;c=engine=cp=None;last=None

def poll():
 if time.perf_counter()-began>P['limits']['global_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for n in ['rollout','advisor','slack']:
  z=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(z.get('stopped')or z.get('user_paused')),'EXPLICIT_STOP'
try:
 with(D/'queries.jsonl').open('x',encoding='utf-8')as out,(D/'timings.jsonl').open('x',encoding='utf-8')as tj:
  for line in(I/'records.jsonl').open(encoding='utf-8'):
   poll();q=json.loads(line)
   if q['kind']=='GENERATION':
    if q['status']!='SUCCESS':counts['generation_refusals']+=1;continue
    tick=time.perf_counter();c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(q['rules']));cp=LearnableMaterialCheckpoint.from_dict(q['checkpoint']);types=tuple(q['types']);native=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,native,checkpoint=cp,tt_megabytes=0);init=time.perf_counter()-tick;tj.write(json.dumps(dict(kind='RULE_INIT',key=q['key'],seconds=init))+'\n');tj.flush();active=q['key'];counts['rules']+=1;continue
   assert active==q['key'];tick=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(q['record'])));import_seconds=time.perf_counter()-tick;before=(s.state,s.to_record(),s.history,s._search_witnesses);row={k:q[k]for k in ['key','slot','seed','size','setup','symmetry','filter','target_prefix','actual_prefix','root_state_sha256','root_witness_sha256']};row.update(status='TERMINAL_ROOT',gradient_nonzero=False,nodes=0);ph={};ob=time.perf_counter()
   if s.result.status.value=='ongoing':
    tick=time.perf_counter();r=engine.search(s,SearchLimits(max_depth=8,max_nodes=131072,max_time_seconds=2.,quiescence_max_depth=0),root_window_pruning=False);ph['query_seconds']=time.perf_counter()-tick;row.update(status='USABLE' if r.completed_depth>=1 and not r.used_fallback else 'INCOMPLETE_UNKNOWN',depth=r.completed_depth,fallback=r.used_fallback,nodes=r.nodes,score=r.score,cause=r.termination_reason,action=record_value(r.action),decision_line=record_value(r.decision_line),gradient_nonzero=None);counts['queries']+=1;counts['nodes']+=r.nodes;counts['depth_'+str(r.completed_depth)]+=1;counts['cause_'+str(r.termination_reason)]+=1
    if row['status']=='USABLE':
     tick=time.perf_counter();leaf=copy(s)
     for a in r.decision_line:
      if isinstance(a,str):leaf.declare(a)
      else:leaf.submit(a)
     ph['pv_replay_seconds']=time.perf_counter()-tick;tick=time.perf_counter();v=material_features(leaf.state.position,types,perspective=0).array();coeff=[cp.board_weights[t]for t in types]+[cp.hand_weights[t]for t in types];terminal=leaf.result.status.value!='ongoing'
     if terminal:
      assert leaf.result.declaration_outcome not in ['NO_CONTEST','RESTART'];z=0 if leaf.result.winner is None else(1 if leaf.result.winner==0 else -1);pred=float(z);gradient=[0.]*len(v);expected=(100000000-len(r.decision_line))*z
     else:pred=tanh(sum(x*w for x,w in zip(v,coeff))/10.);gradient=[x*(1-pred*pred)/10 for x in v];expected=sum(x*round(w*256)for x,w in zip(v,coeff))
     row.update(leaf_phi=v,prediction=pred,gradient=gradient,gradient_nonzero=any(gradient),leaf_result=record_value(leaf.result),leaf_actual_terminal=terminal,pv_literal_integer_score=expected,search_score_matches_literal_pv=expected==r.score*(1 if s.state.position.side_to_move==0 else -1));ph['features_seconds']=time.perf_counter()-tick;counts['usable']+=1;counts['nonzero']+=bool(any(gradient));counts['score_pv_differences']+=not row['search_score_matches_literal_pv']
   assert before==(s.state,s.to_record(),s.history,s._search_witnesses),'ROOT_MUTATED';tick=time.perf_counter();out.write(json.dumps(row,separators=(',',':'))+'\n');out.flush();ph['write_seconds']=time.perf_counter()-tick;tj.write(json.dumps(dict(kind='POINT',key=q['key'],target_prefix=q['target_prefix'],filter=q['filter'],phases=ph,served_observation_seconds=time.perf_counter()-ob,root_import_seconds=import_seconds))+'\n');tj.flush();counts['points']+=1;last=[q['key'],q['target_prefix']]
   if counts['points']%64==0:print('DEEP_INPUT',counts['points'],'queries',counts['queries'],'nodes',counts['nodes'],'seconds',round(time.perf_counter()-began,3),flush=True)
   if out.tell()+tj.tell()>P['limits']['max_output_bytes']:raise TimeoutError('FROZEN_OUTPUT_CAP')
except BaseException as exc:status='PARTIAL_CAP'if isinstance(exc,TimeoutError)else'ERROR';reason=repr(exc);traceback.print_exc()
q=dict(status=status,reason=reason,counts=dict(counts),planned_points=P['planned_points'],missing_points=P['planned_points']-counts['points'],last_returned=last,seconds=time.perf_counter()-began,scope=P['scope']);write_json(D/'result.json',q);print('CLOSED',json.dumps(q),flush=True)
