"""Posthoc linked-seed descriptive envelope for deeper projected cost rate."""
from pathlib import Path
import json,random,sys
from collections import defaultdict
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/acquisition-depth-cost-20261018';I=R/'.local_agent/acquisition-cost-20261018';r0=list(map(json.loads,(I/'records.jsonl').read_bytes().splitlines()));t0=list(map(json.loads,(I/'timings.jsonl').read_bytes().splitlines()));base={(q['key'],q.get('target_prefix')):(q,t)for q,t in zip(r0,t0)};qs=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));tt={(t['key'],t['target_prefix']):t for t in map(json.loads,(D/'timings.jsonl').read_bytes().splitlines())if t['kind']=='POINT'};tot=defaultdict(lambda:[[0.,0.],[0.,0.]])
for(q,t)in base.values():
 if q['kind']=='GENERATION':tot[q['seed']][int(q['filter'])][1]+=t['online_seconds']
for q in qs:
 old,t=base[q['key'],q['target_prefix']];nt=tt[q['key'],q['target_prefix']];v=tot[q['seed']][int(q['filter'])];v[0]+=q.get('gradient_nonzero')is True;v[1]+=t['online_seconds']-sum(t['phases'].get(k,0)for k in ['query_seconds','pv_replay_seconds','features_seconds','write_seconds'])+nt['served_observation_seconds']
rng=random.Random(2026101806);blocks=list(tot.values());ratios=[]
for _ in range(10000):
 selected=[rng.choice(blocks)for __ in blocks];n=[sum(x[f][0]for x in selected)for f in [0,1]];t=[sum(x[f][1]for x in selected)for f in [0,1]];ratios.append((n[1]/t[1])/(n[0]/t[0]))
ratios.sort();out=dict(status='PASS_POSTHOC_DESCRIPTATIVE_DEEP_RATE_ENVELOPE',seed=2026101806,resamples=10000,seedblocks=16,ratio_percentiles_025_975=[ratios[int(.025*9999)],ratios[int(.975*9999)]],seeds=dict(tot),scope='POSTHOC finite16seed linkedblockresampling ofcounts+projectedsharedcost, not independenttimingreplication or populationconfidence; not utility/TDcredit. No newqueries.');out['status']='PASS_POSTHOC_DESCRIPTIVE_DEEP_RATE_ENVELOPE';write_json(D/'rate-envelope.json',out);print(out['ratio_percentiles_025_975'])
