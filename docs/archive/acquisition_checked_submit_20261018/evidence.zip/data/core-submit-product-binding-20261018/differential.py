"""All prospective acquisition roots/children compare old checked transition to candidate."""
from pathlib import Path
import sys,json,time,hashlib,importlib.util,os
from collections import Counter
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
D=R/'.local_agent/core-submit-product-binding-20261018';I=R/'.local_agent/acquisition-cost-20261018';P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();count=Counter();status='COMPLETE';reason=None
spec=importlib.util.spec_from_file_location('generic_chess.core._pinned_baseline_transition',D/'baseline-transition.py');baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
spec=importlib.util.spec_from_file_location('candidate',D/'candidate.py');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
from generic_chess.core.transition import apply_action as actual_product_apply
candidate.candidate_apply=lambda state,action,compiled,baseline:actual_product_apply(state,action,compiled)
assert not(D/'differential-started.json').exists();write_json(D/'differential-started.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((D/'candidate.py').read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest()))

def poll():
 if time.perf_counter()-start>P['limits']['global_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 if count['child_pairs']>=P['limits']['maximum_child_pairs']:raise TimeoutError('FROZEN_CHILD_CAP')
 for n in ['rollout','advisor','slack']:
  d=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(d.get('stopped')or d.get('user_paused')),'EXPLICIT_STOP'
def capture(fn,state,a,c):
 try:return('STATE',fn(state,a,c))
 except Exception as exc:return('ERROR',type(exc).__name__,str(exc))
try:
 for line in(I/'records.jsonl').open(encoding='utf-8'):
  poll();q=json.loads(line)
  if q['kind']=='GENERATION':
   if q['status']=='SUCCESS':c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(q['rules']));key=q['key'];count['rules']+=1
   continue
  assert q['key']==key;s=GameSession.replay(c,deserialize_game_record(json.dumps(q['record'])));before=(s.state,s.history,s.to_record(),s._search_witnesses);aa=s.legal_actions();count['roots']+=1;count['full_history_plies']+=s.state.ply_count
  for a in aa:
   poll();old=baseline.apply_action(s.state,a,c);new=candidate.candidate_apply(s.state,a,c,baseline);assert old==new,('CHILD_DIFFERENCE',q['key'],q['target_prefix'],a);count['child_pairs']+=1;count['drops']+=isinstance(a,SemanticDropMove);count['promotions']+=getattr(a,'promotion_target_id',None)is not None;count['terminal_children']+=old.terminal_status.is_terminal
  # Actual forged semantic identity and forged drop IDs must fail identically.
  for a in [SemanticBoardMove(pattern_id='__invalid_pattern__',geometry_id='__invalid_geometry__',actor_type_id='K',from_square=Square(0,0),to_square=Square(0,1)),SemanticDropMove(pattern_id='__invalid_pattern__',geometry_id='__invalid_geometry__',base_type_id='__missing_type__',to_square=Square(0,0))]:
   old=capture(baseline.apply_action,s.state,a,c);new=capture(lambda s,a,c:candidate.candidate_apply(s,a,c,baseline),s.state,a,c);assert old==new and old[0]=='ERROR',('ERROR_DIFFERENCE',q['key'],old,new);count['invalid_controls']+=1
  assert before==(s.state,s.history,s.to_record(),s._search_witnesses)
  if count['roots']%128==0:print('CORE_DIFF',dict(count),'seconds',round(time.perf_counter()-start,3),flush=True)
except BaseException as exc:
 status='PARTIAL_CAP' if isinstance(exc,TimeoutError) else 'ERROR';reason=repr(exc);raise
finally:
 q=dict(status=status,reason=reason,counts=dict(count),seconds=time.perf_counter()-start,scope='Allplanned1536root legalchildren full GameState comparison under pinnedbaseline andactualeditedpublicfunction, retained allhistory/repetition/terminal fields and exacterrorclass/message forforgedIDs. BothsameCore ruleimplementation; finitegeneratedsample not all-domainproof.');write_json(D/'differential-result.json',q);print(q,flush=True)
