"""Paired intention-to-acquire cost accounting; descriptive seed envelopes."""
from pathlib import Path
from collections import defaultdict,Counter
import json,random,math,hashlib
R=Path.cwd();import sys;sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/acquisition-cost-20261018';P=json.loads((D/'plan.json').read_bytes());result=json.loads((D/'result.json').read_bytes());records=list(map(json.loads,(D/'records.jsonl').read_bytes().splitlines()));times=list(map(json.loads,(D/'timings.jsonl').read_bytes().splitlines()));assert len(records)==len(times)
rows=[]
for q,t in zip(records,times):
 assert (q['key'],q['kind'],q.get('target_prefix'))==(t['key'],t['kind'],t.get('target_prefix'));assert q['status']==t['status'];assert all(v>=0 and math.isfinite(v) for v in t['phases'].values());assert t['online_seconds']+1e-8>=sum(t['phases'].values());rows.append(dict(record=q,timing=t))
def summarize(sub,through=64):
 o=[]
 for flag in [False,True]:
  rr=[x for x in sub if x['record']['filter']==flag and (x['record']['kind']=='GENERATION' or x['record']['target_prefix']<=through)];ss=Counter();ph=Counter();online=0.;nonzero=0
  for x in rr:
   q,t=x['record'],x['timing'];ss[q['kind']+'_'+q['status']]+=1;online+=t['online_seconds'];ph.update(t['phases']);nonzero+=q.get('gradient_nonzero')is True
  o.append(dict(filter=flag,statuses=dict(ss),nonzero=nonzero,online_seconds=online,phase_seconds=dict(ph),nonzero_per_online_second=nonzero/online if online else None,phase_residual_seconds=online-sum(ph.values())))
 a,b=o;return dict(conditions=o,filtered_minus_unfiltered_count=b['nonzero']-a['nonzero'],filtered_count_ratio=b['nonzero']/a['nonzero'] if a['nonzero'] else None,filtered_time_ratio=b['online_seconds']/a['online_seconds'],filtered_rate_ratio=b['nonzero_per_online_second']/a['nonzero_per_online_second'] if a['nonzero'] else None)
allresult=summarize(rows);byboard={str(n):summarize([r for r in rows if r['record']['size']==n])for n in P['board_sizes']};byregime={f'{n}-{p}-{y}':summarize([r for r in rows if(r['record']['size'],r['record']['setup'],r['record']['symmetry'])==(n,p,y)]) for n in P['board_sizes'] for p in P['setups'] for y in P['symmetries']};byseed={str(s):summarize([r for r in rows if r['record']['seed']==s])for s in P['seeds']};cumulative={str(p):summarize(rows,p)for p in P['prefixes']};counts={str(p):{str(f):sum(x['record'].get('gradient_nonzero')is True for x in rows if x['record']['kind']=='POINT' and x['record']['target_prefix']==p and x['record']['filter']==f)for f in [False,True]}for p in P['prefixes']}
# Linked seed bootstrap repeats complete seed blocks, allsettings/flags/prefixes together.
seedtotals=[byseed[str(s)]['conditions']for s in P['seeds']];rng=random.Random(2026101804);ratios=[]
for _ in range(10000):
 chosen=[seedtotals[rng.randrange(len(seedtotals))] for __ in seedtotals];n=[sum(x[f]['nonzero']for x in chosen)for f in [0,1]];t=[sum(x[f]['online_seconds']for x in chosen)for f in [0,1]]
 if n[0] and t[0]and t[1]:ratios.append((n[1]/t[1])/(n[0]/t[0]))
ratios.sort();envelope=[ratios[int(.025*(len(ratios)-1))],ratios[int(.975*(len(ratios)-1))]]
a,b=allresult['conditions'];paid=sum(x['timing']['online_seconds']for x in rows);unassigned=result['seconds']-paid;assert unassigned>=0;overhead=unassigned+result['startup_seconds'];worst=[(b['nonzero']/(b['online_seconds']+overhead))/(a['nonzero']/a['online_seconds']),(b['nonzero']/b['online_seconds'])/(a['nonzero']/(a['online_seconds']+overhead))]
# POSTHOC accounting forecast ONLY: hold input counts fixed, vary measured query cost.
qa=a['phase_seconds']['query_seconds'];qb=b['phase_seconds']['query_seconds'];aa=a['online_seconds']-qa;bb=b['online_seconds']-qb;den=b['nonzero']*qa-a['nonzero']*qb;threshold=(a['nonzero']*bb-b['nonzero']*aa)/den if den else None
out=dict(status='PASS_COMPLETE_PAIRED_COST_ACCOUNTING',plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),overall=allresult,by_board=byboard,by_regime=byregime,by_seed=byseed,cumulative_prefix_sequence=cumulative,prefix_nonzero=counts,descriptive_linked_seed_bootstrap=dict(resamples=10000,seed=2026101804,ratio_percentiles_025_975=envelope,scope='Finite16seed-block timing/count resampling, all settings/flags/prefixes linked; not independent timing replication or population confidence guarantee.'),cost_closure=dict(producer_seconds=result['seconds'],startup_seconds=result['startup_seconds'],allocated_online_seconds=paid,unassigned_producer_seconds=unassigned,all_unassigned_plus_startup_allocation_rate_ratio_bounds=worst),posthoc_unchanged_input_query_cost_crossover=dict(query_time_multiplier=threshold,scope='Accounting forecast only: hold counts/all non-query costs fixed while scaling queryseconds equally. Actual deeper search may change counts, termination and cost; requires separate prospective control.'),scope='Availability of raw selectedleaf own-gradients peractual paid research acquisition protocol, not TDcredit/training/utility. Intentionalfinitegrid; no failed or terminal slots removed, no constant rule distribution causal claim.')
write_json(D/'analysis.json',out);print(json.dumps(dict(overall=allresult,bootstrap=envelope,cost_bounds=worst,query_scale_crossover=threshold,byboard=byboard),indent=2),flush=True)
