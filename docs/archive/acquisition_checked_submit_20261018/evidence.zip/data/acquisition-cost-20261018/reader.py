"""Independent full-record/state/Counter/PV check plus separate saved-root import cost."""
from pathlib import Path
from collections import Counter
from copy import copy
from math import tanh
import sys,json,time,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
D=R/'.local_agent/acquisition-cost-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));start=time.perf_counter();counts=Counter();gens={};imports=[];c=None;cp=None;active=None

def poll():
 assert time.perf_counter()-start<600,'FROZEN_READER_CAP'
 for n in ['rollout','advisor','slack']:
  d=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not(d.get('stopped')or d.get('user_paused')),'EXPLICIT_STOP'
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(v):
 from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
 from generic_chess.core.coordinates import Square
 if isinstance(v,str):return v
 d=dict(v);d['to_square']=Square(**d['to_square'])
 if 'from_square'in d:d['from_square']=Square(**d['from_square']);return SemanticBoardMove(**d)
 return SemanticDropMove(**d)
for line in (D/'records.jsonl').open(encoding='utf-8'):
 poll();q=json.loads(line)
 if q['kind']=='GENERATION':
  gens[q['key']]=q;counts['generation_calls']+=1
  if q['status']=='SUCCESS':
   c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(q['rules']));assert c.ruleset_fingerprint==q['fingerprint'];cp=LearnableMaterialCheckpoint.from_dict(q['checkpoint']);cp.validate_ruleset(c);types=tuple(sorted(t.type_id for t in c.piece_types if not t.is_anchor));assert list(types)==q['types'];active=q['key'];counts['rules']+=1;counts['nonPAX_rules']+=not(set(c.types_by_id)<={'K','P','A','X'})
  else:counts['generation_refusals']+=1
  continue
 assert q['key']==active;tick=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(q['record'])));elapsed=time.perf_counter()-tick;imports.append(dict(key=q['key'],target_prefix=q['target_prefix'],size=q['size'],filter=q['filter'],actual_prefix=q['actual_prefix'],seconds=elapsed));assert digest(s.state)==q['root_state_sha256'];assert digest(s._search_witnesses)==q['root_witness_sha256'];assert record_value(s.result)==q['root_result'];assert s.state.ply_count==q['actual_prefix'];counts['full_records']+=1;counts['recorded_plies']+=s.state.ply_count
 if q['status']=='TERMINAL_ROOT':assert s.result.status.value!='ongoing' and q['gradient_nonzero']is False;counts['terminal_roots']+=1;continue
 assert s.result.status.value=='ongoing'
 if q['status']!='USABLE':counts[q['status']]+=1;continue
 assert q['decision_line'] and q['decision_line'][0]==q['action'];assert decode(q['action'])in s.legal_actions();leaf=copy(s)
 for raw in q['decision_line']:
  a=decode(raw)
  if isinstance(a,str):leaf.declare(a)
  else:leaf.submit(a)
  counts['PV_edges']+=1
 b=Counter()
 for pc in leaf.state.position.board:
  if pc:b['board',pc.current_type_id]+=1 if pc.owner==0 else -1
 for t in types:b['hand',t]=leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t)
 v=[b[k,t] for k in ['board','hand'] for t in types];assert v==q['leaf_phi'];terminal=leaf.result.status.value!='ongoing';assert terminal==q['leaf_actual_terminal'];assert record_value(leaf.result)==q['leaf_result']
 if terminal:
  z=0 if leaf.result.winner is None else (1 if leaf.result.winner==0 else -1);pred=float(z);grad=[0.]*len(v);expected=(100000000-len(q['decision_line']))*z
 else:
  coeff=[cp.board_weights[t] for t in types]+[cp.hand_weights[t] for t in types];pred=tanh(sum(x*w for x,w in zip(v,coeff))/10.);grad=[x*(1-pred*pred)/10 for x in v];expected=sum(x*round(w*256)for x,w in zip(v,coeff))
 assert pred==q['prediction'] and grad==q['gradient'] and any(grad)==q['gradient_nonzero'];assert expected==q['score']*(1 if s.state.position.side_to_move==0 else -1);assert not q['fallback'];counts['usable']+=1;counts['nonzero']+=bool(any(grad));counts['D2']+=q['depth']==2
result=json.loads((D/'result.json').read_bytes());assert counts['generation_calls']==result['counts']['generation_calls'] and counts['full_records']==result['counts']['points'] and counts['nonzero']==result['counts']['nonzero']
write_json(D/'saved-root-import-cost.json',dict(rows=imports,total_seconds=sum(r['seconds'] for r in imports),scope='Separate reader process after prospective queries; measured fullrecord parse+Core replay, compile outside timer. Warm process/caches, not counterfactual same-time online latency.'))
q=dict(status='PASS_ALL_FULL_RECORDS_AND_SELECTED_PV_GRADIENTS',counts=dict(counts),seconds=time.perf_counter()-start,scope='Allroots/historywitnesses, actualchosenactionlegal, every returnedPVedge/leafCounter/materialpredictor/gradient/integerleafscore. NoNativequery/generation/training, not fullminimax/WDL/externalrulesauthority. Importcost is separate observational pass.');write_json(D/'reader-result.json',q);print(q,flush=True)
