"""Archive complete fixed-setting feedback, not strength certification."""
import sys,json,hashlib,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/development_feedback_20261007';out=ROOT/'docs/research/data/chess_feedback_20261007.json';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest();decl=json.loads((p/'declaration.json').read_bytes());assert sha((p/'games.py').read_bytes())==decl['producer_sha256']
files=[p/n for n in ('declaration.json','proposal.json','uci-options.json','exchange-first-pair.json','activity-first-pair.json','see-scope-audit.json','loss-inspection.json')];groups={}
for mode in ('exchange','activity'):
 v=json.loads((p/(mode+'.json')).read_bytes());r=json.loads((p/(mode+'-replay.json')).read_bytes());assert v['complete'] and r['complete'] and len(r['games'])==12 and not r['errors']
 methods={}
 for g in r['games']:
  z=methods.setdefault(g['table'],dict(wins=0,losses=0,draws=0,unfinished=0));z['unfinished' if not g['finished'] else 'draws' if g['winner'] is None else 'wins' if g['winner']==g['candidate_color'] else 'losses']+=1
 groups[mode]=dict(methods=methods,cells=r['games'],wall_seconds=v['wall_seconds'],recording_cost_before_final_save=v['recording_cost_before_final_save'],replay=dict(streams=12,played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0))
 files.extend(p/n for n in (mode+'.json',mode+'-replay.json'))
totals={k:{metric:sum(x[metric] for x in g['methods'].values()) for metric in ('wins','losses','draws','unfinished')} for k,g in groups.items()}
saturated=any(all(z[metric]>=10 for z in totals.values()) for metric in ('wins','losses','unfinished'))
a.mkdir(exist_ok=True);entries={};sources={}
def archive(path,items,target):
 assert not path.exists()
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in items:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b);z.writestr(n,b);target[n]=dict(bytes=len(b),sha256=sha(b))
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and set(z.namelist())==set(target)
  for n,h in target.items():assert sha(z.read(n))==h['sha256']
archive(a/'raw.zip',[(f,f.name) for f in files],entries)
upstream=ROOT/'.local_agent/mature-search/Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d'
archive(a/'sources.zip',[(p/n,'feedback-20261007/'+n) for n in ('games.py','replay.py','collect.py')]+[(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(ROOT/'scripts/research_record.py','shared-research_record.py'),(upstream/'src/position.cpp','pinned-position.cpp'),(upstream/'Copying.txt','upstream-Copying.txt'),(ROOT/'.local_agent/mature-search/material-variants.ini','material-variants.ini'),(ROOT/'.local_agent/mature-openings/suite.json','suite.json')],sources)
summary=dict(scope='Fixed2400option exposed development feedback; native exchange/activity at same conditions. Option label not measured Elo, limited play can be stochastic. No human/exposed-label fitting, tier fishing, coefficient/default/Elo/holdout claim.',parent_sha='3d9426bb605e244ee6b6679b4a161e8f45e34308',declaration=decl,groups=groups,totals=totals,saturated_by_predeclared_rule=saturated,raw_entries=entries,sources=sources,raw_archive=a.relative_to(ROOT).as_posix()+'/raw.zip',sources_archive=a.relative_to(ROOT).as_posix()+'/sources.zip',raw_zip_sha256=sha((a/'raw.zip').read_bytes()),sources_zip_sha256=sha((a/'sources.zip').read_bytes()),production_changes='None; fixed leaves/search/defaults unchanged',public_push='held')
write_record(out,summary);write_record(a/'index.json',dict(raw_entries=entries,sources=sources,portable_sha256=sha(out.read_bytes())));print(json.dumps(dict(totals=totals,saturated=saturated,replay={k:g['replay'] for k,g in groups.items()},sha256=sha(out.read_bytes()))))
