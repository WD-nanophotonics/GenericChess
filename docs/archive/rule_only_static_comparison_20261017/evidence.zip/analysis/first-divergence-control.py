from pathlib import Path
from dataclasses import replace
from collections import Counter
import sys,json,time,os
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));D=ROOT/'.local_agent/static-price-20261017';STOP_ROOT=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(ROOT))).resolve()
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import apply_action,legal_actions
P=json.loads((D/'first-divergence-control-plan.json').read_bytes());start=time.monotonic();visits=0;rows=[];status='COMPLETE';reason=None;div=json.loads((D/'first-divergences.json').read_bytes())['rows'];models={x['checkpoint_id']:x['checkpoint']for x in json.loads((D/'models.json').read_bytes())['rows']};games={x['slot']:x for x in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};compiled={};selected=[]
def signature(a):return json.dumps(record_value(a),sort_keys=True,separators=(',',':'))
def poll():
 if visits>=P['caps']['core_visits']or time.monotonic()-start>=P['caps']['seconds']:raise TimeoutError('FROZEN_CONTROL_CAP')
 for n in('rollout','advisor','slack'):
  f=json.loads((STOP_ROOT/'.local_agent'/(n+'.json')).read_bytes());assert not f.get('stopped')and not f.get('user_paused'),'EXPLICIT_STOP'
for gs in range(271001,271005):
 eligible=sorted([r for r in div if r['rule']==gs],key=lambda r:(r['comparison'],r['family'],r['owner'],r['left'],r['right']));seen=set()
 for r in eligible:
  key=(r['parent_state_sha256'],r['left_query']['checkpoint_id'],r['right_query']['checkpoint_id'])
  if key in seen:continue
  seen.add(key);selected.append(r)
  if len(seen)>=4:break
try:
 for r in selected:
  poll();gs=r['rule']
  if gs not in compiled:compiled[gs]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(json.loads((ROOT/'docs/research/data/aux89_native_candidates_20261017'/f'rule-{gs}.json').read_bytes())))
  c=compiled[gs];record=deserialize_game_record(json.dumps(games[r['left_slot']]['record']));s=GameSession.replay(c,replace(record,actions=record.actions[:r['absolute_ply']],declaration=None,resigned_by=None));actualhash=__import__('hashlib').sha256(json.dumps(record_value(s.state),sort_keys=True,separators=(',',':')).encode()).hexdigest();assert actualhash==r['parent_state_sha256'];profiles=[models[r[k+'_query']['checkpoint_id']]for k in('left','right')]
  def walk(st,depth,relative):
   global visits
   visits+=1
   if visits%128==0:poll()
   terminal=st.terminal_status
   if terminal.is_terminal:return[0 if terminal.winner is None else(100000000-relative)*(1 if terminal.winner==0 else-1)]*2
   if depth==0:
    out=[]
    for cp in profiles:
     board=sum((1 if x.owner==0 else-1)*round(cp['board_weights'].get(x.current_type_id,0.)*256)for x in st.position.board if x is not None);hand=sum((st.position.hands[0].count(t)-st.position.hands[1].count(t))*round(w*256)for t,w in cp['hand_weights'].items());out.append(board+hand)
    return out
   children=[walk(apply_action(st,a,c),depth-1,relative+1)for a in legal_actions(st,c)];assert children;fn=max if st.position.side_to_move==0 else min;return[fn(child[i]for child in children)for i in range(2)]
  aa=s.legal_actions();scores=[walk(apply_action(s.state,a,c),1,1)for a in aa];fn=max if s.state.position.side_to_move==0 else min;best=[fn(v[i]for v in scores)for i in range(2)];opts=[{signature(a)for a,v in zip(aa,scores)if v[i]==best[i]}for i in range(2)];chosen=[json.dumps(r[k+'_query']['returned_action'],sort_keys=True,separators=(',',':'))for k in('left','right')];membership=[[a in opt for opt in opts]for a in chosen];own=[membership[i][i]for i in range(2)];scorematch=[r[k+'_query']['score']*(1 if s.state.position.side_to_move==0 else-1)==best[i]for i,k in enumerate(('left','right'))];classification='JOINT_OPTIMAL_TIE'if all(all(x)for x in membership)else'STRICT_CONFLICT'if not membership[0][1]and not membership[1][0]else'ONE_SIDED_STRICT'
  rows.append(dict(rule=gs,family=r['family'],owner=r['owner'],comparison=r['comparison'],left=r['left'],right=r['right'],parent_record=record_value(s.to_record()),parent_sha256=actualhash,root_degree=len(aa),own_action_optimal=own,native_score_matches_core=scorematch,cross_membership=membership,classification=classification,best_values_owner0=best,legal_action_quantized_values=[dict(action=record_value(a),values=v)for a,v in zip(aa,scores)],left_slot=r['left_slot'],right_slot=r['right_slot'],relative_ply=r['relative_ply']));print('CONTROL',gs,r['family'],classification,own,scorematch,flush=True)
except Exception as exc:status='PARTIAL';reason=repr(exc)
write_json(D/'first-divergence-control.json',dict(status=status,reason=reason,selected=len(selected),returned=len(rows),rows=rows,core_visits=visits,seconds=time.monotonic()-start,classifications=dict(Counter(r['classification']for r in rows)),all_own_actions_optimal=all(all(r['own_action_optimal'])for r in rows),all_native_scores_match=all(all(r['native_score_matches_core'])for r in rows),scope=P['scope']+'Complete typedstate/history retained; current-root-relative mate utility; no Nativequery/game/training rerun.'))
print('CLOSED_CONTROLS',status,len(rows),'visits',visits,'seconds',round(time.monotonic()-start,3))
