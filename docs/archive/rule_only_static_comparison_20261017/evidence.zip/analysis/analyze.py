from pathlib import Path
from collections import Counter,defaultdict
import json,statistics,random,sys
sys.path.insert(0,str(Path.cwd()));from tools.local_agent.common import write_json
D=Path('.local_agent/static-price-20261017');p=json.loads((D/'plan.json').read_bytes());done=json.loads((D/'result.json').read_bytes());assert done['status']=='COMPLETE';physical=[json.loads(x)for x in(D/'games.jsonl').read_bytes().splitlines()];rows={};queries=defaultdict(list)
for line in(D/'queries.jsonl').read_bytes().splitlines():q=json.loads(line);queries[q['slot']].append(q)
for g in physical:
 k=(g['rule'],g['family'],g['label'],g['candidate_owner']);assert k not in rows;rows[k]=g
 if g['label']=='unit':
  z=dict(g);z['candidate_owner']=1;z['reward']=None if g['reward']is None else-g['reward'];z['logical_role_copy_only']=True;rows[g['rule'],g['family'],'unit',1]=z
assert len(rows)==384
summary=[]
for label in p['profiles']:
 a=[r for k,r in rows.items()if k[2]==label];assert len(a)==64;counter=Counter('U'if x['reward']is None else'W'if x['reward']==1 else'L'if x['reward']==-1 else'D'for x in a);known=sum(x['reward']or 0 for x in a);u=counter['U'];summary.append(dict(label=label,cells=len(a),outcomes=dict(counter),W_minus_L_bounds=[(known-u)/len(a),(known+u)/len(a)],known_reward_sum=known,physical_slots=len({x['slot']for x in a}),queries=sum(x['queries']for x in a),nodes=sum(x['nodes']for x in a)))
comparisons=[('static-unit',['rule_static_v2'],['unit']),('trained-initial',['trained1977','trained8173'],['initial1977','initial8173']),('static-trained',['rule_static_v2','rule_static_v2'],['trained1977','trained8173'])];contrasts=[];divergences=[]
def bound(x):return(-1,1)if x is None else(x,x)
for name,aa,bb in comparisons:
 pairs=[];byrule=defaultdict(list);byfamily=defaultdict(list)
 for a,b in zip(aa,bb):
  for gs in p['rules']:
   for family in p['families']:
    for owner in(0,1):
     x=rows[gs,family,a,owner];y=rows[gs,family,b,owner];xl,xh=bound(x['reward']);yl,yh=bound(y['reward']);lo,hi=xl-yh,xh-yl;same=x['record']==y['record'];pair=dict(rule=gs,family=family,owner=owner,left=a,right=b,left_slot=x['slot'],right_slot=y['slot'],left_reward=x['reward'],right_reward=y['reward'],delta_bounds=[lo,hi],same_full_record=same);pairs.append(pair);byrule[gs].append((lo,hi));byfamily[gs,family].append((lo,hi))
     if not same:
      ax=x['record']['actions'];ay=y['record']['actions'];rootlen=next(r['prefix_completed']for r in json.loads((D/'roots.json').read_bytes())['rows']if r['rule']==gs and r['family']==family);j=next((j for j,(u,v)in enumerate(zip(ax,ay))if u!=v),None);assert j is not None,'lengthonlydivergence';relative=j-rootlen;qx=queries[x['slot']][relative];qy=queries[y['slot']][relative];assert qx['before_sha256']==qy['before_sha256']and qx['actor']==qy['actor']==owner
      divergences.append(dict(comparison=name,rule=gs,family=family,owner=owner,left=a,right=b,left_slot=x['slot'],right_slot=y['slot'],absolute_ply=j,relative_ply=relative,parent_state_sha256=qx['before_sha256'],left_query=qx,right_query=qy,delta_bounds=[lo,hi],known_improvement=lo==hi and lo>0,known_worsening=lo==hi and lo<0))
 n=len(pairs);lower=sum(x['delta_bounds'][0]for x in pairs)/n;upper=sum(x['delta_bounds'][1]for x in pairs)/n;rng=random.Random(2026101711);boot=[]
 for _ in range(2000):
  sampled=[]
  for gs in p['rules']:
   for _ in p['families']:sampled.extend(byfamily[gs,rng.choice(p['families'])])
  boot.append((sum(x[0]for x in sampled)/len(sampled),sum(x[1]for x in sampled)/len(sampled)))
 lowerboot=sorted(x[0]for x in boot);upperboot=sorted(x[1]for x in boot);contrast=dict(name=name,pairs=n,delta_W_minus_L_bounds=[lower,upper],resolved_pairs=sum(x['left_reward']is not None and x['right_reward']is not None for x in pairs),same_full_records=sum(x['same_full_record']for x in pairs),resolved_better=sum(x['delta_bounds'][0]==x['delta_bounds'][1]and x['delta_bounds'][0]>0 for x in pairs),resolved_worse=sum(x['delta_bounds'][0]==x['delta_bounds'][1]and x['delta_bounds'][1]<0 for x in pairs),conditional_fixed_rule_family_resampling_95_envelope=[lowerboot[49],upperboot[1949]],per_rule={str(gs):dict(pairs=len(z),bounds=[sum(x[0]for x in z)/len(z),sum(x[1]for x in z)/len(z)])for gs,z in byrule.items()},scope='Bounds retain UNKNOWN[-1,+1]; descriptive2000within-rulefamilyresamples on4fixedexposedrules/32families, no unseenrule/full-domainconfidence. Modelseeds/roles are correlated, not128independentfamilies.');contrasts.append(contrast)
q=[q for a in queries.values()for q in a];write_json(D/'analysis.json',dict(status='COMPLETE_REGISTERED_FINITE_DIAGNOSTIC',logical_cells=len(rows),physical_games=len(physical),profiles=summary,contrasts=contrasts,first_divergences=len(divergences),first_divergence_always_candidate_owner=True,depths=dict(Counter(x['completed_depth']for x in q)),fallbacks=sum(x['used_fallback']for x in q),query_causes=dict(Counter(x['cause']for x in q)),kernel_seconds=sum(x['kernel_seconds']for x in q),caller_seconds=sum(x['caller_seconds']for x in q),max_caller_seconds=max(x['caller_seconds']for x in q),total_nodes=done['nodes'],scope='No pricefit/newlearner/AUXchange/selection. Samefixedfoe/allinitials retained, actualfinitebehavior notElo oruniqueprices. Unitrolecopies countedonlylogically.'));write_json(D/'first-divergences.json',dict(rows=divergences));print(json.dumps(dict(profiles=summary,contrasts=contrasts,first_divergences=len(divergences)),indent=2))
