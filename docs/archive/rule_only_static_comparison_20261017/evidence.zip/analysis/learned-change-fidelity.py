from pathlib import Path
from dataclasses import replace
from collections import Counter
import sys,json,time,hashlib,os
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));D=ROOT/'.local_agent/static-price-20261017';STOP_ROOT=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(ROOT))).resolve()
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.transition import apply_action,legal_actions
P=json.loads((D/'learned-change-fidelity-plan.json').read_bytes());selected=[r for r in json.loads((D/'first-divergences.json').read_bytes())['rows']if r['comparison']=='trained-initial'];models={r['checkpoint_id']:r['checkpoint']for r in json.loads((D/'models.json').read_bytes())['rows']};games={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};compiled={};start=time.monotonic();visits=0;rows=[];status='COMPLETE';reason=None

def sig(a):return json.dumps(record_value(a),sort_keys=True,separators=(',',':'))
def poll():
 if time.monotonic()-start>=P['limits']['seconds']or visits>=P['limits']['visits']:raise TimeoutError('FROZEN_FIDELITY_CAP')
 for n in('rollout','advisor','slack'):
  f=json.loads((STOP_ROOT/'.local_agent'/(n+'.json')).read_bytes());assert not f.get('stopped')and not f.get('user_paused'),'EXPLICIT_STOP'
try:
 for r in selected:
  poll();gs=r['rule']
  if gs not in compiled:compiled[gs]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(json.loads((ROOT/'docs/research/data/aux89_native_candidates_20261017'/f'rule-{gs}.json').read_bytes())))
  c=compiled[gs];record=deserialize_game_record(json.dumps(games[r['left_slot']]['record']));s=GameSession.replay(c,replace(record,actions=record.actions[:r['absolute_ply']],declaration=None,resigned_by=None));assert hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True,separators=(',',':')).encode()).hexdigest()==r['parent_state_sha256'];cp=[models[r[k+'_query']['checkpoint_id']]for k in('left','right')];profiles=[(cp[0],False),(cp[1],False),(cp[0],True),(cp[1],True)]
  def walk(st,depth,relative):
   global visits
   visits+=1
   if visits%128==0:poll()
   terminal=st.terminal_status
   if terminal.is_terminal:return[0 if terminal.winner is None else(100000000-relative)*(1 if terminal.winner==0 else-1)]*4
   if depth==0:
    out=[]
    for model,quantized in profiles:
     def w(x):return round(x*256)if quantized else x*256
     board=sum((1 if x.owner==0 else-1)*w(model['board_weights'].get(x.current_type_id,0.))for x in st.position.board if x is not None);hand=sum((st.position.hands[0].count(t)-st.position.hands[1].count(t))*w(v)for t,v in model['hand_weights'].items());out.append(board+hand)
    return out
   values=[walk(apply_action(st,a,c),depth-1,relative+1)for a in legal_actions(st,c)];assert values;fn=max if st.position.side_to_move==0 else min;return[fn(v[i]for v in values)for i in range(4)]
  aa=s.legal_actions();values=[walk(apply_action(s.state,a,c),1,1)for a in aa];fn=max if s.state.position.side_to_move==0 else min;best=[fn(v[i]for v in values)for i in range(4)];opts=[{sig(a)for a,v in zip(aa,values)if abs(v[i]-best[i])<1e-8}for i in range(4)];chosen=[json.dumps(r[k+'_query']['returned_action'],sort_keys=True,separators=(',',':'))for k in('left','right')];floatmembership=[chosen[i]in opts[i]for i in range(2)];quantmembership=[chosen[i]in opts[i+2]for i in range(2)];scorematch=[r[k+'_query']['score']*(1 if s.state.position.side_to_move==0 else-1)==best[i+2]for i,k in enumerate(('left','right'))];jointtie=all(a in opts[0]and a in opts[1]for a in chosen)
  rows.append(dict(rule=gs,family=r['family'],owner=r['owner'],left=r['left'],right=r['right'],parent_record=record_value(s.to_record()),parent_sha256=r['parent_state_sha256'],left_slot=r['left_slot'],right_slot=r['right_slot'],relative_ply=r['relative_ply'],native_choices_float_optimal=floatmembership,native_choices_quantized_optimal=quantmembership,native_scores_match_quantized=scorematch,training_changes_float_optimal_set=opts[0]!=opts[1],joint_float_tie=jointtie,best_values=best,optimal_sets=[sorted(x)for x in opts],chosen=chosen,scope='ValuesinNative256units; floatusesunroundedcoefficient*256;terminalrootrelative1e8distance. Tolerance1e-8units onlyforbinaryfloatarithmetic.'))
except Exception as exc:status='PARTIAL';reason=repr(exc)
result=dict(status=status,reason=reason,selected=len(selected),returned=len(rows),rows=rows,visits=visits,seconds=time.monotonic()-start,all_own_quantized_actions_optimal=all(all(x['native_choices_quantized_optimal'])for x in rows),native_choices_outside_source_float_optset=sum(not y for x in rows for y in x['native_choices_float_optimal']),joint_float_tie_contexts=sum(x['joint_float_tie']for x in rows),float_preference_changes=sum(x['training_changes_float_optimal_set']for x in rows),scope=P['scope']);write_json(D/'learned-change-fidelity.json',result);print('FIDELITY',json.dumps({k:v for k,v in result.items()if k!='rows'}),flush=True)
