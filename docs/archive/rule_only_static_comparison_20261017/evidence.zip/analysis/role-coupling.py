from pathlib import Path
from collections import defaultdict
import json,random,shutil,sys
sys.path.insert(0,str(Path.cwd()));from tools.local_agent.common import write_json
D=Path('.local_agent/static-price-20261017');a=json.loads((D/'analysis.json').read_bytes());write_json(D/'analysis-before-explicit-role-coupling.json',a);p=json.loads((D/'plan.json').read_bytes());physical={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};logical={}
for g in physical.values():
 logical[g['rule'],g['family'],g['label'],g['candidate_owner']]=g
 if g['label']=='unit':
  z=dict(g);z['candidate_owner']=1;z['reward']=None if g['reward']is None else-g['reward'];logical[g['rule'],g['family'],'unit',1]=z
specs=[('static-unit',['rule_static_v2'],['unit']),('trained-initial',['trained1977','trained8173'],['initial1977','initial8173']),('static-trained',['rule_static_v2','rule_static_v2'],['trained1977','trained8173'])]
def coupled(pairs):
 coeff=defaultdict(int)
 for left,right in pairs:
  coeff[left['slot']]+=1 if left['candidate_owner']==0 else-1;coeff[right['slot']]-=1 if right['candidate_owner']==0 else-1
 known=0;radius=0;canceled_unknown=0
 for slot,c in coeff.items():
  g=physical[slot]
  if g['reward']is None:
   radius+=abs(c);canceled_unknown+=c==0
  else:known+=c*g['reward']*(1 if g['candidate_owner']==0 else-1)
 n=len(pairs);return[(known-radius)/n,(known+radius)/n],canceled_unknown
results=[]
for name,lefts,rights in specs:
 groups=defaultdict(list);pairs=[]
 for left,right in zip(lefts,rights):
  for gs in p['rules']:
   for f in p['families']:
    for owner in(0,1):
     pair=(logical[gs,f,left,owner],logical[gs,f,right,owner]);pairs.append(pair);groups[gs,f].append(pair)
 bounds,canceled=coupled(pairs);rng=random.Random(2026101711);boots=[]
 for _ in range(2000):
  sample=[]
  for gs in p['rules']:
   for _ in p['families']:sample+=groups[gs,rng.choice(p['families'])]
  boots.append(coupled(sample)[0])
 low=sorted(x[0]for x in boots);high=sorted(x[1]for x in boots);result=dict(name=name,bounds=bounds,unknown_physical_slots_canceling_algebraically=canceled,conditional_within_rule_family_95_envelope=[low[49],high[1949]],per_rule={str(gs):coupled([pair for pair in pairs if pair[0]['rule']==gs])[0]for gs in p['rules']});results.append(result)
 row=next(r for r in a['contrasts']if r['name']==name);row['bounds_with_registered_physical_role_reuse']=result
write_json(D/'analysis.json',a);write_json(D/'explicit-role-coupling.json',dict(status='COMPLETE_SAME_TARGET_TIGHTER_VALID_BOUNDS',results=results,formula='Each logicalreward=s_owner*Z_physical. Pairmean=sum(coeff_slot*Z_slot)/N. KnownZexact, eachunknownZ[-1,1] contributes+-abs(coeff). ExplicitUnitrolecopies cancel, notimputedasdraw. No coupling inferredfrommerelyidenticalrecords underdifferentpolicies.',scope='Tight under ONLY declaredphysicalreuse constraints, not complete-game-theoretic bounds. Samefrozen384logical/352physicalcells, no newgame/label/modelselection. Both conservativeoldbounds andcorrectcoupledones retained. Descriptiveresamplingconditionson4fixedTRAINrules.'));print(json.dumps(results,indent=2))
