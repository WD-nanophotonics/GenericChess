"""Declared paired four-ply original-control retention, not material prices."""
import sys,json,time,hashlib,random,collections
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.transition import legal_successors
from generic_chess.core.actions import action_to_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'retention.json';assert not out.exists()
src=root/'.local_agent/target-context-20261008/frozen-role-candidate.json';old=json.loads(src.read_bytes());base=ruleset_from_dict(old['definition_template'])
assert not any(any(row) for rows in base.drop_allowed.values() for row in rows)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
declaration={'question':'Can one scalar ordering describe this price-free local retention observation? Not capture-opportunity calibration or positive material price.','layout':'All original32 inner6x6 displacement layouts, same cells/background0R0R1C1R, corner anchors. All three pairs C-R/R-N/N-C, A in owner0 or owner1 slot, both first players. Condition once on common initial nonterminal legal acceptance across all12 variants; preserve rejections, no capture-conditioned selection.','policy':'Four actual public plies, uniform distinct legal successor Positions at each step. Equivalent bindings receive one physical mass; representative retains real history. Not a general history quotient.16 predeclared trajectories per variant using shared seed/layout/rep quantiles across pair/role/turn, no candidate evaluator.','utility':'Indicator A still controlled by original owner minus indicator B still controlled by original owner. Track moving identities, capture loses original control. In this no-drop/no-transform template a lost mark cannot return; captured hand at opponent is not original control. Keep both-live/both-lost zeros and early terminals separately; no win utility or ratios.','uncertainty':'Unit of context replication is layout, not independent plies. Paired layout means and exact finite16-path outcomes; small Monte Carlo sample may be inconclusive.','cost':'<=324 common root variants (32 attempted*12, acceptance may differ),16 trajectories*4 plies. Initial cost checkpoint300sec/2000000 actual eager successors. Single process, stop checks; partial prefix kept. Further effort only for decision-changing uncertainty, no model/worker.'}
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'declaration':declaration,'attempted_layouts':[],'rows':[],'actual_eager_successors':0,'semantic_aliases':0,'turn_calls':0};write_record(out,r)
def check():
 assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
 assert time.perf_counter()-started<300 and r['actual_eager_successors']<2000000
def turn(state,c,side):
 pos=replace(state.position,side_to_move=side);key=repetition_identity_key(pos,c);counts=((key,1),)
 return GameState(pos,0,counts,semantic_engine_for(c).terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),))
def tracks_after(action,child,tracks,owners):
 source=action.from_square.file+8*action.from_square.rank;target=action.to_square.file+8*action.to_square.rank
 result=[]
 for sq,owner in zip(tracks,owners):
  if sq is None:result.append(None);continue
  next_sq=target if sq==source else sq
  piece=child.position.board[next_sq]
  result.append(next_sq if piece is not None and piece.owner==owner else None)
 return tuple(result)
try:
 layouts={x['seed']:x['cells'] for x in old['rows']}
 for seed,cells in sorted(layouts.items()):
  check();variants=[];attempt={'seed':seed,'cells':cells,'rejections':[]};r['attempted_layouts'].append(attempt)
  for A,B in (('C','R'),('R','N'),('N','C')):
   for owner in (0,1):
    board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[cells[owner]]=Piece(owner,A,A);board[cells[1-owner]]=Piece(1-owner,B,B)
    for sq,(who,tid) in zip(cells[2:],((0,'R'),(0,'R'),(1,'C'),(1,'R'))):board[sq]=Piece(who,tid,tid)
    try:c=compile_ruleset_for_execution(replace(base,initial_position=tuple(tuple(board[y*8:y*8+8]) for y in range(8))));initial=GameSession(c).state
    except ValueError as exc:attempt['rejections'].append({'pair':[A,B],'owner':owner,'error':str(exc)});continue
    for side in (0,1):
     state=turn(initial,c,side)
     if state.terminal_status.is_terminal:attempt['rejections'].append({'pair':[A,B],'owner':owner,'side':side,'terminal':record_value(state.terminal_status)})
     variants.append((A,B,owner,side,c,state))
  attempt['common_accepted']=not attempt['rejections'] and len(variants)==12
  if not attempt['common_accepted']:write_record(out,r);continue
  for A,B,owner,side,c,initial in variants:
   row={'seed':seed,'pair':[A,B],'A_owner':owner,'first_player':side,'outcomes':[]};r['rows'].append(row)
   for rep in range(16):
    state=initial;tracks=(cells[owner],cells[1-owner]);owners=(owner,1-owner);rng=random.Random(seed*100+rep);trajectory=[]
    for ply in range(4):
     check()
     if state.terminal_status.is_terminal:break
     successors=legal_successors(state,c);r['turn_calls']+=1;r['actual_eager_successors']+=len(successors);physical={}
     for action,child in successors:
      following=tracks_after(action,child,tracks,owners);observable=(following,child.terminal_status)
      if child.position in physical:
       assert observable==physical[child.position][3];r['semantic_aliases']+=1
      else:physical[child.position]=(action,child,following,observable)
     assert physical,'nonterminal without legal action'
     options=list(physical.values());action,state,tracks,_=options[min(int(rng.random()*len(options)),len(options)-1)]
     trajectory.append({'action':action_to_dict(action),'physical_support':len(options),'tracks':tracks,'history_length':len(state.history)})
    alive=(tracks[0] is not None,tracks[1] is not None)
    row['outcomes'].append({'rep':rep,'alive':alive,'utility':int(alive[0])-int(alive[1]),'plies':len(trajectory),'terminal':record_value(state.terminal_status),'trajectory':trajectory})
   write_record(out,r)
  print(seed,len(r['rows']),r['actual_eager_successors'],round(time.perf_counter()-started,2),flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
