"""Independent tag-board replay and Rao-Blackwell last-turn reanalysis.

Same saved prefixes, utility, four-ply horizon and physical policy. No new roots,
trajectory extension, fitted rewards or positive-price normalization.
"""
import sys,json,time,hashlib,statistics,random,collections
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.transition import legal_successors,apply_action
from generic_chess.core.actions import action_from_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=p/'retention.json';d=json.loads(src.read_bytes());assert d['complete'];out=p/'replay.json';assert not out.exists()
template=root/'.local_agent/target-context-20261008/frozen-role-candidate.json';base=ruleset_from_dict(json.loads(template.read_bytes())['definition_template']);cells_by_seed={x['seed']:x['cells'] for x in d['attempted_layouts']}
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'template_sha256':sha(template),'declaration':'Independently replay ALL saved public histories with tag-board identity rather than source-square tracker. Same physical-policy four-ply utility; exact last-turn conditional expectation at existing sampled three-ply prefixes, no extra trajectory/horizon. Unknown whether rare utility observations reflect last-turn MC variance versus layout variation. Cost checkpoint300sec/1000000actual eager last successors; original sample retained.','replayed_steps':0,'actual_eager_successors':0,'rows':[]};write_record(out,r)
def labels_after(labels,a,state,owners):
 start=a.from_square.file+8*a.from_square.rank;end=a.to_square.file+8*a.to_square.rank
 labels=list(labels);labels[end]=labels[start];labels[start]=None
 for square,tag in enumerate(labels):
  if tag is not None:assert state.position.board[square] is not None and state.position.board[square].owner==owners[tag]
 return tuple(labels)
def observable(labels,state):
 live=[tag in labels for tag in ('A','B')]
 return (int(live[0])-int(live[1]),tuple(live),state.terminal_status)
try:
 for old in d['rows']:
  assert time.perf_counter()-started<300 and r['actual_eager_successors']<1000000
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  cells=cells_by_seed[old['seed']];owner=old['A_owner'];A,B=old['pair'];owners={'A':owner,'B':1-owner};board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K');board[cells[owner]]=Piece(owner,A,A);board[cells[1-owner]]=Piece(1-owner,B,B)
  for sq,(who,tid) in zip(cells[2:],((0,'R'),(0,'R'),(1,'C'),(1,'R'))):board[sq]=Piece(who,tid,tid)
  c=compile_ruleset_for_execution(replace(base,initial_position=tuple(tuple(board[y*8:y*8+8]) for y in range(8))));initial=GameSession(c).state;pos=replace(initial.position,side_to_move=old['first_player']);key=repetition_identity_key(pos,c);counts=((key,1),);initial=GameState(pos,0,counts,semantic_engine_for(c).terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),))
  row={k:old[k] for k in ('seed','pair','A_owner','first_player')};row['outcomes']=[];r['rows'].append(row)
  for sample in old['outcomes']:
   state=initial;labels=[None]*64;labels[cells[owner]]='A';labels[cells[1-owner]]='B';parent=None;parent_labels=None
   for step in sample['trajectory']:
    parent,parent_labels=state,tuple(labels);a=action_from_dict(step['action']);state=apply_action(state,a,c);r['replayed_steps']+=1;labels=labels_after(labels,a,state,owners)
    assert len(state.history)==step['history_length']
    assert [labels.index(tag) if tag in labels else None for tag in ('A','B')]==step['tracks']
   u,live,terminal=observable(labels,state);assert u==sample['utility'] and list(live)==sample['alive'] and record_value(terminal)==sample['terminal']
   item={'rep':sample['rep'],'sampled_utility':u,'conditional_expected_utility':u,'conditional_variance':0,'physical_support':0,'early_terminal':sample['plies']<4};row['outcomes'].append(item)
   if sample['plies']<4:continue
   pairs=legal_successors(parent,c);r['actual_eager_successors']+=len(pairs);physical={}
   for a,child in pairs:
    next_labels=labels_after(parent_labels,a,child,owners);value=observable(next_labels,child)
    if child.position in physical:assert physical[child.position]==value
    else:physical[child.position]=value
   assert state.position in physical and physical[state.position][0]==u
   values=[x[0] for x in physical.values()];mean=statistics.mean(values);item.update(conditional_expected_utility=mean,conditional_variance=statistics.mean((x-mean)**2 for x in values),physical_support=len(values),conditional_both_live=sum(all(x[1]) for x in physical.values())/len(values),conditional_both_lost=sum(not any(x[1]) for x in physical.values())/len(values),conditional_terminal=sum(x[2].is_terminal for x in physical.values())/len(values))
  write_record(out,r)
  if len(r['rows'])%12==0:print(old['seed'],len(r['rows']),r['replayed_steps'],r['actual_eager_successors'],round(time.perf_counter()-started,2),flush=True)
 r['pairs']={}
 for A,B in (('C','R'),('R','N'),('N','C')):
  rows=[x for x in r['rows'] if x['pair']==[A,B]];seeds=sorted({x['seed'] for x in rows});means=[statistics.mean(x['conditional_expected_utility'] for row in rows if row['seed']==seed for x in row['outcomes']) for seed in seeds];rng=random.Random(202610082300);boot=sorted(statistics.mean(rng.choices(means,k=len(means))) for _ in range(10000));r['pairs'][A+'-'+B]={'mean':statistics.mean(means),'layout_means':dict(zip(map(str,seeds),means)),'layout_bootstrap95_interval':[boot[249],boot[9749]],'mean_conditional_last_turn_variance':statistics.mean(x['conditional_variance'] for row in rows for x in row['outcomes'])}
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
print(json.dumps(r['pairs'],indent=2))
