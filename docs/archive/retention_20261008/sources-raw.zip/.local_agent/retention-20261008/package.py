import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/retention_20261008';dest.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
analysis=json.loads((p/'analysis.json').read_bytes());replay=json.loads((p/'replay.json').read_bytes());assert analysis['complete'] and replay['complete'];assert analysis['input_sha256']==replay['input_sha256']==sha((p/'retention.json').read_bytes())
for name,producer in (('retention','run'),('analysis','analyze'),('replay','replay')):assert json.loads((p/(name+'.json')).read_bytes())['producer_sha256']==sha((p/(producer+'.py')).read_bytes())
dependency=root/'.local_agent/target-context-20261008/frozen-role-candidate.json';assert sha(dependency.read_bytes())==json.loads((p/'retention.json').read_bytes())['input_sha256']==replay['template_sha256']
files=sorted(x for x in p.iterdir() if x.suffix in ('.py','.json'))+[dependency];members=[];archive=dest/'sources-raw.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  body=f.read_bytes();name=f.relative_to(root).as_posix();z.writestr(name,body);members.append({'path':name,'bytes':len(body),'sha256':sha(body)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for x in members:assert sha((Path(tmp)/x['path']).read_bytes())==x['sha256']
index={'base_commit':'ea934db19a9e39218e9a690f150a1d33286d31c7','archive_sha256':sha(archive.read_bytes()),'members':members,'extracted_rehashed':True,'excluded':'User/private inputs, raw Slack/accounts, credentials, active workflow state.'};(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
summary={'complete':True,'scope':'Price-free four-ply original-control retention,27 common layouts/three pairs/role+turn balance/16 trajectories. No-drop no-transform template only. Independent tag-board replay and exact last-turn conditional expectation on same prefixes. Signed observations, not positive prices/ratios/WDL or reliable ordering.','archive':'../../archive/retention_20261008/index.json','archive_sha256':index['archive_sha256'],'analysis':analysis,'independent_replay':{'input_sha256':replay['input_sha256'],'replayed_steps':replay['replayed_steps'],'actual_eager_successors':replay['actual_eager_successors'],'seconds':replay['seconds'],'pairs':replay['pairs']},'baseline_fixed_prices':{'C':1000,'R':1000,'N':530},'decision':'All layout uncertainty intervals cross zero, including exact last-turn reanalysis. No scalar cycle, ranking or ratio conclusion. Do not extend unchanged random trajectories or tune weights/horizon to force ordering; a further experiment needs a changed informative decision question.'};(root/'docs/research/data/retention_20261008.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());print({'members':len(members),'bytes':archive.stat().st_size})
