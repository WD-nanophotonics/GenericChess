"""Compact evidence and hash-verified inert raw/source archives; no Slack data."""
import sys,json,hashlib,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
a=ROOT/'docs/archive/development_allocation_20261007';a.mkdir(exist_ok=True)
out=ROOT/'docs/research/data/chess_allocation_20261007.json';assert not out.exists()
groups={};files=[]
for folder,label,n in [('activity-multipv-direct-20261007','direct',12),('activity-multipv-stronger-20261007','reference',24)]:
 p=ROOT/'.local_agent'/folder;v=json.loads((p/'games.json').read_bytes());r=json.loads((p/'replay.json').read_bytes());assert v['complete'] and r['complete'] and len(r['games'])==n and not r['errors']
 methods={}
 for policy in ('geometric_half','linear_mixture','unit'):
  methods[policy]={}
  for mode in ('pure','activity'):
   rows=[x for x in r['games'] if (x.get('table')==policy if label=='direct' else policy in (x['white'],x['black']) and x['mode']==mode)]
   def won(x):return x['white_leaf_mode' if x['winner']==0 else 'black_leaf_mode']==mode if label=='direct' else x['winner']==(0 if x['white']==policy else 1)
   methods[policy][mode]=dict(wins=sum(x['finished'] and x['winner'] is not None and won(x) for x in rows),losses=sum(x['finished'] and x['winner'] is not None and not won(x) for x in rows),draws=sum(x['finished'] and x['winner'] is None for x in rows),unfinished=sum(not x['finished'] for x in rows))
 groups[label]=dict(declaration=v['declaration'],methods=methods,cells=r['games'],wall_seconds=v['wall_seconds'],recording_cost=v['recording_cost'],replay=dict(streams=n,played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0))
 files.extend(p/n for n in ('declaration.json','suite.json','games.json','replay.json'))
p=ROOT/'.local_agent/activity-safety-20261007'
forced=json.loads((p/'forced.json').read_bytes());mpv=json.loads((p/'multipv-root.json').read_bytes());roots=json.loads((p/'allocation-roots.json').read_bytes());shogi=json.loads((p/'shogi-ordered-drop.json').read_bytes())
assert all(x['complete'] for x in (forced,mpv,roots,shogi))
def root_contrasts(roots):
 contrasts={}
 for name,left,right in [('activity_leaf_single',('activity',1),('pure',1)),('activity_leaf_multipv',('activity',3),('pure',3)),('allocation_pure',('pure',3),('pure',1)),('allocation_activity',('activity',3),('activity',1))]:
  c=dict(same_move=0,finite_positive=0,finite_negative=0,finite_equal=0,mate_comparisons=[])
  for row in roots['rows']:
   choices={(x['mode'],x['multipv']):x['move'] for x in row['choices']};l,r=choices[left],choices[right]
   if l==r:c['same_move']+=1;continue
   lv,rv=row['references'][l],row['references'][r]
   if lv['cp'] is None or rv['cp'] is None:c['mate_comparisons'].append(dict(game=row['game'],threshold=row['threshold'],side=row['side'],left_move=l,right_move=r,left=lv,right=rv));continue
   delta=lv['cp']-rv['cp'];c['finite_positive' if delta>0 else 'finite_negative' if delta<0 else 'finite_equal']+=1
  contrasts[name]=c
 return contrasts
contrasts=root_contrasts(roots)
files.extend(p/n for n in ('forced.json','multipv-root.json','allocation-roots.json','shogi-ordered-drop.json','source-analysis.md','static-adverse.json','white-threat.json','new-failure-roots.json','shared-api.json','execution-notes.json'))
entries={};sources={}
def archive(path,items,target):
 if path.exists():
  with zipfile.ZipFile(path) as z:
   assert z.testzip() is None and set(z.namelist())=={n for f,n in items}
   for f,n in items:
    b=f.read_bytes();assert z.read(n)==b;target[n]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  return
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f,name in items:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:\\+Users\\+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b)
   z.writestr(name,b);target[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for n,h in target.items():assert hashlib.sha256(z.read(n)).hexdigest()==h['sha256']
archive(a/'raw.zip',[(f,f.relative_to(ROOT/'.local_agent').as_posix()) for f in files],entries)
names=('activity_forced_20261007.py','activity_white_threat_20261007.py','activity_new_failures_20261007.py','shared_multipv_check_20261007.py','static_adverse_20261007.py','activity_multipv_root_20261007.py','multipv_player_20261007.py','activity_multipv_direct_20261007.py','activity_multipv_stronger_20261007.py','activity_allocation_roots_20261007.py','shogi_ordered_drop_20261007.py','replay_multipv_direct_20261007.py','replay_multipv_stronger_20261007.py','collect_allocation_20261007.py')
archive(a/'sources.zip',[(ROOT/'.local_agent'/n,n) for n in names]+[(p/'frozen-chess_development.py','frozen-chess_development.py'),(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(p/'archive-failure.json','archive-failure.json')],sources)
summary=dict(archive_failure=json.loads((p/'archive-failure.json').read_bytes()),scope='Exposed StandardChess existing MultiPV allocation and fixed root diagnostics; Shogi separate synthetic finite horizon control. No default, tuning, Elo, holdout or generic-rule playing-strength claim.',prior='docs/research/data/chess_activity_games_20261007.json',game_adapter_commit='5ec9a124588dd55716aa779c78f45046e356f310',shared_api=json.loads((p/'shared-api.json').read_bytes()),white_threat=json.loads((p/'white-threat.json').read_bytes()),new_failures=dict(raw_file='activity-safety-20261007/new-failure-roots.json',contrasts=root_contrasts(json.loads((p/'new-failure-roots.json').read_bytes()))),groups=groups,static_adverse=json.loads((p/'static-adverse.json').read_bytes()),forced=forced,multipv_root=mpv,forced_declaration_correction='actual12calls30requestedsec, not18calls',execution_notes=json.loads((p/'execution-notes.json').read_bytes()),root_sampling=dict(declaration=roots['declaration'],roots=len(roots['rows']),skipped=roots['skipped'],contrasts=contrasts,excluding_first_row=root_contrasts(dict(rows=roots['rows'][1:])),interpretation='Finite score signs, not error-rate; small cp deltas unreliable; mate separate. Complete choices/histories/PVs in raw archive.'),shogi=shogi,raw_entries=entries,sources=sources,raw_archive=a.relative_to(ROOT).as_posix()+'/raw.zip',sources_archive=a.relative_to(ROOT).as_posix()+'/sources.zip',raw_zip_sha256=hashlib.sha256((a/'raw.zip').read_bytes()).hexdigest(),sources_zip_sha256=hashlib.sha256((a/'sources.zip').read_bytes()).hexdigest(),production_changed='Shared development UciMaterial API opt-in multipv; default1/CLI/search/leaf unchanged',public_push='held')
write_record(out,summary);write_record(a/'index.json',dict(raw_entries=entries,sources=sources,portable_sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
print(json.dumps(dict(groups={k:dict(methods=v['methods'],wall_seconds=v['wall_seconds'],replay=v['replay']) for k,v in groups.items()},root_contrasts=contrasts,shogi=[{k:x[k] for k in ('root','policy','q','selected','score','reason','wall_seconds')} for x in shogi['models']],sha256=hashlib.sha256(out.read_bytes()).hexdigest())))
