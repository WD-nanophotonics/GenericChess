"""Lab adapter using existing native MultiPV3, final bestmove, unchanged game entry."""
import time
import scripts.chess_development as d
class MultiPlayer(d.UciMaterial):
 def choose(self):
  wall,cpu=time.perf_counter(),time.process_time()
  with self.engine.analysis(self.board,self.limit,multipv=3,game=self.game) as analysis:
   result=analysis.wait();infos=analysis.multipv
  move=result.move.uci() if result.move else None
  lines=[]
  for info in infos:
   score=info.get('score');score=score.pov(self.board.turn) if score else None
   lines.append(dict(rank=info.get('multipv'),score_cp=None if score is None else score.score(),score_mate=None if score is None else score.mate(),pv=[m.uci() for m in info.get('pv',())],depth=info.get('depth'),nodes=info.get('nodes'),engine_seconds=info.get('time'),lowerbound=info.get('lowerbound'),upperbound=info.get('upperbound')))
  selected=next((i for i in infos if i.get('pv') and i['pv'][0]==result.move),{})
  score=selected.get('score');score=score.pov(self.board.turn) if score else None
  return move,dict(policy=self.policy,move=move,reason='native_MultiPV3_final_bestmove',score=None,score_cp=None if score is None else score.score(),score_mate=None if score is None else score.mate(),wall_seconds=time.perf_counter()-wall,controller_cpu_seconds=time.process_time()-cpu,engine_nodes=max((i.get('nodes',0) for i in infos),default=0),engine_depth=selected.get('depth'),engine_seldepth=selected.get('seldepth'),engine_seconds=max((i.get('time',0) for i in infos),default=0),pv=[m.uci() for m in selected.get('pv',())],statistics={},search_completion_scope='Timed native MultiPV3 bestmove; lines can finish at different depths, not complete fixed depth',multipv_lines=lines)
