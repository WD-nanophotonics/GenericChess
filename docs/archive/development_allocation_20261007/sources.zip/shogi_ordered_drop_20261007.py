"""Changed premise: existing orderedTTq on earlier horizon-discriminating roots."""
import sys,json,time
from pathlib import Path
from fractions import Fraction as F
from dataclasses import replace,asdict
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.core.transition import initial_state,legal_successors,apply_action
from generic_chess.core.position import Hands
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.actions import action_is_drop
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.audit_exchange_custody import synthetic_state
from scripts.shogi_full_affine_inventory import FullAffineInventory,BASES
from scripts.shogi_static_inventory import quantize
from scripts.shogi_exact_contact_family import exact_board_means
from scripts.resource_mode_context import resource_ledger
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/activity-safety-20261007/shogi-ordered-drop.json';assert not out.exists()
c=compile_ruleset_for_execution(build_standard_shogi_ruleset());initial=initial_state(c)
def root(relocated):
 b=list(initial.position.board)
 for src,dst in ((10,40),(64,43),(58,49),(70,31)):
  assert b[src] and b[dst] is None;b[dst]=b[src];b[src]=None
 assert b[40].current_type_id=='R' and b[16].current_type_id=='B';b[40]=None;b[16]=None
 assert b[22].current_type_id=='P';b[40]=b[22];b[22]=None
 if relocated:
  assert b[58] is None and b[41] is None;b[58]=b[40];b[40]=None;b[41]=b[23];b[23]=None
 s=synthetic_state(c,replace(initial.position,board=tuple(b),hands=(Hands((('B',1),('R',1))),initial.position.hands[1]),side_to_move=0))
 resource_ledger(c,s.position,'shogi');assert semantic_engine_for(c).in_check(s.position,0) and not s.terminal_status.is_terminal
 assert len(list(legal_successors(s,c)))==8
 return s
class Point:
 def __init__(self,w):self.affine=FullAffineInventory(c,w);self.held={base:quantize(F(1,2)*w[base]) for base in BASES};self.calls=0
 def evaluate(self,s):
  row=self.affine.row(s);v=row[0]+sum(row[i+1]*self.held[k] for i,k in enumerate(BASES));self.calls+=1;return v if s.position.side_to_move==0 else -v
 def capture_order_value(self,state,action,captured=None):return 990000
m=exact_board_means('geometric_half');weights={k:v/m['TR'] for k,v in m.items()}
report=dict(question='Does useful q2 horizon discrimination survive the supported orderedTTq cost setting?',declaration='Eight cells, two prior exposed synthetic checked full-stock8action roots(original/relocated), geometric/unit, q0/q2;2ply2048nodes10sec each, hardq8, freshTT, common990000 capture order, PVS and orderedq on. Only allocation changes relative old lexical tests; held-half and weights unchanged. Prior q2 relocation selected unitKingd2/geometricB@e2; observe both favorable/adverse outcomes, no unique tie/WDL/default/representative-play claim.<=80sec plus setup, after current timed Chess cohorts, no concurrent heavy jobs.',models=[],complete=False)
write_record(out,report)
for relocated in (False,True):
 s=root(relocated);legal=dict((str(a),(a,b)) for a,b in legal_successors(s,c))
 for q in (0,2):
  for policy,w in [('geometric_half',weights),('unit',{k:F(1) for k in weights})]:
   for name in ('rollout','advisor','slack'):
    f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not f.get('user_paused') and not f.get('stopped')
   e=Point(w);stats=SearchStatistics();limits=SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=10,quiescence_max_depth=q,quiescence_hard_max_depth=8,quiescence_max_nodes=2048)
   tuning=SearchTuning(use_root_tactical=False,use_pvs=True,use_check_only_qsearch=q==0,use_capture_only_qsearch=q==2,use_ordered_qsearch=True)
   t=time.perf_counter();a,score,pv,reason=run_root_search(s,c,e,TranspositionTable(),limits,None,stats,use_tt=True,use_ordering=True,tuning=tuning)
   assert str(a) in legal;child=apply_action(s,a,c);rt=SearchPathRuntime.from_state(s,c)
   with rt.pushed(a):assert rt.position==child.position and rt.terminal_status==child.terminal_status
   rt.assert_balanced();resource_ledger(c,child.position,'shogi')
   row=dict(root='relocated' if relocated else 'original',root_state=record_value(s),policy=policy,q=q,selected=str(a),score=score,pv=[str(x) for x in pv],reason=reason,statistics=asdict(stats),wall_seconds=time.perf_counter()-t,evaluations=e.calls)
   report['models'].append(row);write_record(out,report);print(row['root'],policy,q,str(a),score,reason,stats.completed_depth,flush=True)
report['complete']=True;write_record(out,report)
