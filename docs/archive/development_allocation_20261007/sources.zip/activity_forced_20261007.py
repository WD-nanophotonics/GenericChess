"""Exposed same-root forced-move diagnostic; unchanged native builds."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-safety-20261007';p.mkdir(exist_ok=True)
out=p/'forced.json';assert not out.exists()
source=ROOT/'.local_agent/activity-stronger-20261007/paired-roots.json'
x=next(x for x in json.loads(source.read_bytes())['rows'] if x['game_index']==7 and x['played_index']==33)
config=ROOT/'.local_agent/mature-search/material-variants.ini'
binaries={'pure':ROOT/'.local_agent/mature-search/build/fairy-material.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe'}
b=type('MaterialBoard',(chess.Board,),{'uci_variant':'gc_linear_mixture'})(chess.STARTING_FEN)
for m in x['history_prefix']:b.push_uci(m)
assert b.fen(en_passant='fen')==x['fen']
moves=['g6g5','g6f5','c6c5'];assert all(chess.Move.from_uci(m) in b.legal_moves for m in moves)
report=dict(question='Does forced root search recover the reference rejection of g6g5, or retain an endogenous ranking error?',declaration='Exposed retained linearBlack root33. Pure/activity, all three already observed moves, fresh engines and hashes, Threads1/Hash16/NNUEfalse, symmetric1/4sec each.18 calls30requested seconds. Root restriction changes tree allocation, not proof or deployment improvement. PV and score are within leaf only; do not compare cross-leaf score levels. No coefficient/default changes.',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),fen=x['fen'],history_prefix=x['history_prefix'],binary_sha256={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},rows=[],complete=False)
d.write_record(out,report)
for sec in (1,4):
 for move in moves:
  for mode,binary in binaries.items():
   for name in ('rollout','advisor','slack'):
    flags=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
    e.configure({'Threads':1,'Hash':16,'Use NNUE':False,'Clear Hash':None})
    t=time.perf_counter();info=e.analyse(b,chess.engine.Limit(time=sec),root_moves=[chess.Move.from_uci(move)],game=object())
    score=info['score'].pov(b.turn);pv=[m.uci() for m in info.get('pv',())]
    assert pv and pv[0]==move
    board=b.copy(stack=True)
    for m in pv:board.push_uci(m)
    row=dict(mode=mode,root_move=move,requested_seconds=sec,cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),seldepth=info.get('seldepth'),engine_seconds=info.get('time'),wall_seconds=time.perf_counter()-t,pv=pv,pv_terminal=board.is_game_over(claim_draw=False))
    report['rows'].append(row);d.write_record(out,report);print(row,flush=True)
report['complete']=True;d.write_record(out,report)
