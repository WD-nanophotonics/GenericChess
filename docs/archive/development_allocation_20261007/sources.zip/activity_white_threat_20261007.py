"""Exposed same-root forced-move diagnostic; unchanged native builds."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-safety-20261007';p.mkdir(exist_ok=True)
out=p/'white-threat.json';assert not out.exists()
source=ROOT/'.local_agent/activity-stronger-20261007/paired-roots.json'
x=next(x for x in json.loads(source.read_bytes())['rows'] if x['game_index']==7 and x['played_index']==33)
config=ROOT/'.local_agent/mature-search/material-variants.ini'
binaries={'pure':ROOT/'.local_agent/mature-search/build/fairy-material.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe'}
b=type('MaterialBoard',(chess.Board,),{'uci_variant':'gc_linear_mixture'})(chess.STARTING_FEN)
for m in x['history_prefix']:b.push_uci(m)
assert b.fen(en_passant='fen')==x['fen']
b.push_uci('g6g5')
moves=[None,'h3g5','a3e7'];assert all(chess.Move.from_uci(m) in b.legal_moves for m in moves if m)
report=dict(question='After g6g5, can the native leaf/search see White forcing threats from the child root?',declaration='Exposed retained root33 full history plus g6g5; now White to move. Pure/activity, unrestricted or forcedh3g5/a3e7, both observed existing PV threats, fresh engine/hash, Threads1/Hash16/NNUEfalse, symmetric1/4sec.12calls30requestedseconds. Does a child-root launch reveal a threat missed by prior parent free search? Source-path and resource effect, not a unique SEE bug, mate certificate or new coefficient/default.',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),fen=b.fen(en_passant='fen'),history_prefix=x['history_prefix']+['g6g5'],binary_sha256={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},rows=[],complete=False)
d.write_record(out,report)
for sec in (1,4):
 for move in moves:
  for mode,binary in binaries.items():
   for name in ('rollout','advisor','slack'):
    flags=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
    e.configure({'Threads':1,'Hash':16,'Use NNUE':False,'Clear Hash':None})
    t=time.perf_counter();info=e.analyse(b,chess.engine.Limit(time=sec),root_moves=None if move is None else [chess.Move.from_uci(move)],game=object())
    score=info['score'].pov(b.turn);pv=[m.uci() for m in info.get('pv',())]
    assert pv and (move is None or pv[0]==move)
    board=b.copy(stack=True)
    for m in pv:board.push_uci(m)
    row=dict(mode=mode,root_move=move,requested_seconds=sec,cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),seldepth=info.get('seldepth'),engine_seconds=info.get('time'),wall_seconds=time.perf_counter()-t,pv=pv,pv_terminal=board.is_game_over(claim_draw=False))
    report['rows'].append(row);d.write_record(out,report);print(row,flush=True)
report['complete']=True;d.write_record(out,report)
