"""Fixed old direct-game root union; four native configurations, equal time."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess'),str(ROOT/'.local_agent')]
import chess,chess.engine
import scripts.chess_development as d
from multipv_player_20261007 import MultiPlayer
p=ROOT/'.local_agent/activity-safety-20261007';out=p/'allocation-roots.json';assert not out.exists()
source=ROOT/'.local_agent/activity-direct-20261007/games.json';raw=source.read_bytes();old=json.loads(raw);assert old['complete'] and len(old['games'])==12
config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
binaries={'pure':ROOT/'.local_agent/mature-search/build/fairy-material.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe'}
report=dict(question='Do leaf and existing MultiPV allocation changes give useful or adverse same-root choices on the previous direct corpus?',declaration='Before new results, fixed source original12directgames; first actual root at/after16/32 for each side. Up to48roots, four fresh-hash configurations(pure/activity x SinglePV/MultiPV3),1sec/Threads1/Hash16/NNUEfalse. <=192sec local plus <=192sec reference fuse; for every distinct selected child fresh fullstrength500000node/1sec. Same move counts no action difference; cp/mate separate, finite cp small deltas unreliable. Exposed fixed development sampling, no holdout/Elo/default/tuning. Full histories and Core/legal parity. No concurrency with timed cohorts.',source_sha256=hashlib.sha256(raw).hexdigest(),rows=[],skipped=[],complete=False)
d.write_record(out,report);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
for gi,g in enumerate(old['games']):
 for threshold in (16,32):
  for side in (0,1):
   found=next((i for i,r in enumerate(g['moves']) if i>=threshold and r['side']==side),None)
   if found is None:report['skipped'].append(dict(game=gi,threshold=threshold,side=side));continue
   for name in ('rollout','advisor','slack'):
    f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not f.get('user_paused') and not f.get('stopped')
   prefix=g['opening_uci']+[r['move'] for r in g['moves'][:found]];state,_=d.replay_prefix(g['initial_fen'],c,prefix)
   b=chess.Board(g['initial_fen'])
   for m in prefix:b.push_uci(m)
   legal={d.uci(a) for a in d.iter_legal_actions(state,c)};assert legal=={m.uci() for m in b.legal_moves}
   row=dict(game=gi,id=g['id'],policy=g['table'],threshold=threshold,side=side,index=found,fen=b.fen(en_passant='fen'),history_prefix=prefix,choices=[],references={})
   for mpv,cls in ((1,d.UciMaterial),(3,MultiPlayer)):
    for mode,binary in binaries.items():
     with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
      e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=cls(e,g['initial_fen'],g['table'],1)
      d.replay_prefix(g['initial_fen'],c,prefix,(player,));move,r=player.choose();assert move in legal
      r.update(mode=mode,multipv=mpv);row['choices'].append(r)
   selections={r['move'] for r in row['choices']};row['all_equal']=len(selections)==1
   if not row['all_equal']:
    with chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as e:
     e.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
     for move in sorted(selections):
      child=b.copy(stack=True);child.push_uci(move);e.configure({'Clear Hash':None});t=time.perf_counter()
      info=e.analyse(child,chess.engine.Limit(nodes=500000,time=1),game=object());score=info['score'].pov(b.turn)
      row['references'][move]=dict(cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),wall_seconds=time.perf_counter()-t,pv=[m.uci() for m in info.get('pv',())])
   report['rows'].append(row);d.write_record(out,report);print(gi,threshold,side,[(r['mode'],r['multipv'],r['move']) for r in row['choices']],flush=True)
report['complete']=True;d.write_record(out,report)
