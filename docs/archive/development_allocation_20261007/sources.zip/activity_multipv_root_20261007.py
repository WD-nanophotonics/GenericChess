"""Existing MultiPV allocation diagnostic, frozen leaf/source coefficients."""
exec_source=None
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-safety-20261007';out=p/'multipv-root.json';assert not out.exists()
x=json.loads((p/'forced.json').read_bytes());b=type('MaterialBoard',(chess.Board,),{'uci_variant':'gc_linear_mixture'})(chess.STARTING_FEN)
for m in x['history_prefix']:b.push_uci(m)
binaries={'pure':ROOT/'.local_agent/mature-search/build/fairy-material.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe'}
report=dict(declaration='Exposed root33, unchanged two builds, existing MultiPV3/5, symmetric1/4sec, fresh engine/hash per call Threads1/Hash16/NNUEfalse. Eight calls20requested sec. Hypothesis: broader PV allocation reveals dangerous quiet-root loss and changes choice; failure motivates another specific diagnostic, no coefficient fit. Raw forced declaration mistakenly says18calls: actual12calls30sec; preserve original and correction here.',fen=b.fen(en_passant='fen'),history_prefix=x['history_prefix'],rows=[],complete=False)
d.write_record(out,report)
for mpv in (3,5):
 for sec in (1,4):
  for mode,binary in binaries.items():
   with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(ROOT/'.local_agent/mature-search/material-variants.ini')],timeout=15) as e:
    e.configure({'Threads':1,'Hash':16,'Use NNUE':False,'Clear Hash':None});t=time.perf_counter()
    infos=e.analyse(b,chess.engine.Limit(time=sec),multipv=mpv,game=object());rows=[]
    for info in infos:
     score=info['score'].pov(b.turn);pv=[m.uci() for m in info.get('pv',())];assert pv and chess.Move.from_uci(pv[0]) in b.legal_moves
     rows.append(dict(rank=info.get('multipv'),cp=score.score(),mate=score.mate(),pv=pv,depth=info.get('depth'),nodes=info.get('nodes'),engine_seconds=info.get('time')))
    row=dict(mode=mode,multipv=mpv,seconds=sec,wall_seconds=time.perf_counter()-t,lines=rows);report['rows'].append(row);d.write_record(out,report);print(row,flush=True)
report['complete']=True;d.write_record(out,report)
