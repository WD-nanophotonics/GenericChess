"""Actual shared optional API, full histories/PV legality and option restoration."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-safety-20261007';out=p/'shared-api.json';assert not out.exists()
x=json.loads((p/'forced.json').read_bytes());config=ROOT/'.local_agent/mature-search/material-variants.ini'
binaries={'pure':ROOT/'.local_agent/mature-search/build/fairy-material.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe'}
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
report=dict(scope='Transport integration only; same retained full history,0.25sec each, native3->1->3->1 transitions on the same engine for each leaf. Verify finalbestmove/legalPV and actual protocol option restoration. No playing improvement or benchmark inference.',adapter_sha256=hashlib.sha256((ROOT/'scripts/chess_development.py').read_bytes()).hexdigest(),rows=[],complete=False)
d.write_record(out,report)
for mode,binary in binaries.items():
 with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
  e.configure({'Threads':1,'Hash':16,'Use NNUE':False})
  for mpv in (3,1,3,1):
   player=d.UciMaterial(e,chess.STARTING_FEN,'linear_mixture',.25,multipv=mpv);state,_=d.replay_prefix(chess.STARTING_FEN,c,x['history_prefix'],(player,))
   legal={d.uci(a) for a in d.iter_legal_actions(state,c)};assert legal=={m.uci() for m in player.board.legal_moves}
   m,row=player.choose();assert m in legal and len(player.board.move_stack)==len(x['history_prefix'])
   observed=e.protocol.config.get('MultiPV');assert observed==mpv,(mode,mpv,observed)
   check=player.board.copy(stack=True)
   for move in row['pv']:check.push_uci(move)
   if mpv==3:
    assert row['multipv']==3 and len(row['multipv_lines'])==3
    assert any(line['move']==m for line in row['multipv_lines'])
    assert all('pv' not in line for line in row['multipv_lines'])
   else:assert 'multipv_lines' not in row
   report['rows'].append(dict(mode=mode,requested_multipv=mpv,observed_multipv=observed,**row));d.write_record(out,report)
report['complete']=True;d.write_record(out,report);print('shared API',len(report['rows']),'native transitions/full-history/PV controls pass')
