"""Inert retained producer of the completed immediate-geometry crosscheck."""
import sys,json
from pathlib import Path
sys.path[:0]=['.local_agent/certificate_source/python-chess','.']
import chess
from scripts.chess_development import material_tables
from scripts.research_record import write_record
p=Path('.local_agent/activity-safety-20261007');x=json.loads((p/'forced.json').read_bytes());b=chess.Board(x['fen']);w=material_tables()['linear_mixture']
def measure(b):
 material=sum((1 if pc.color else -1)*w.get(pc.symbol().upper(),0) for pc in b.piece_map().values());coverage={}
 for c in (chess.WHITE,chess.BLACK):
  union=set()
  for sq,pc in b.piece_map().items():
   if pc.color==c and pc.piece_type!=chess.KING:union.update(b.attacks(sq))
  coverage['white' if c else 'black']=len(union)
 activity=4*(coverage['white']-coverage['black']);return dict(white_material_native=material,covered=coverage,white_activity_native=activity,black_pure_native=-material,black_activity_native=-material-activity)
rows={}
for m in (None,'g6g5','g6f5','c6c5'):
 child=b.copy()
 if m:child.push_uci(m)
 rows[m or 'root']=measure(child)
out=p/'static-adverse.json';assert not out.exists();write_record(out,dict(question='Can the immediate union residual alone explain preferring g6g5 over the pawn capture?',scope='Python-chess pseudo-attack geometry crosscheck with pinned native Chess term, not a search value or guaranteed branch attribution; full native static controls already qualified term previously.',coefficient=4,pawn=208,policy='linear_mixture',fen=x['fen'],rows=rows))
print(json.dumps(rows))
