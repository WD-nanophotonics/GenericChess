"""Prospective pure/activity leaf comparison through the existing game adapter."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-multipv-stronger-20261007';p.mkdir(exist_ok=True)
pure=ROOT/'.local_agent/mature-search/build/fairy-material.exe'
activity=ROOT/'.local_agent/activity-20261007/fairy-activity.exe'
config=ROOT/'.local_agent/mature-search/material-variants.ini'
ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
suite=json.loads((ROOT/'.local_agent/mature-openings/suite.json').read_bytes())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
decl=dict(question='Does existing native MultiPV3 avoid practical selective-search failures against the same unlimited reference?',
 scope='Standard Chess; exposed openings; unlimited reference fixed50000node/1sec fuse, no Elo, independent holdout or generic-rule strength claim.',
 term='4 native units per white-minus-black unique nonroyal pseudo-attacked square; Pawn208. Unchanged coefficient, no outcome-based tuning.',
 conditions=dict(multipv=3,local_seconds=1,reference_nodes=50000,reference_time_fuse=1,reference_elo_setting=None,threads=1,hash_mib=16,max_subsequent_plies=160),
 design='24 sequential cells: two existing fixed prefixes, three unchanged tables, both colors, pure/activity interleaved by pair; both now use native MultiPV3 and final bestmove. Changed premise is root allocation, not leaf coefficient. Fresh hash/game per cell. Preserve all losses, unfinished and interrupted cells; no silent rerun.',
 decision='Retain or defer optional positional candidate based on actual outcomes/cost and specific failures; no default promotion. Stochastic/time-limited pairs are descriptive, not exact causal estimates.',
 cost='At most1920sec requested local search plus reference fuse and authoritative-state/recording overhead. Stop check each action. No concurrent engines/tests/builds outside the current game.',
 binary_sha256=dict(pure=sha(pure),activity=sha(activity)),config_sha256=sha(config),reference_sha256=sha(ref),adapter_sha256=sha(ROOT/'scripts/chess_development.py'))
assert decl['binary_sha256']['pure']=='477628ae141c6e5fb7dcb562e31e3bc40eab95b20c8b966ece131a1dbf090999'
assert decl['binary_sha256']['activity']=='8f9dab0fc47ef7a29014d55a349502344509d5a65d6a8a19a7f5a9bfb8dad099'
assert not (p/'declaration.json').exists()
d.write_record(p/'declaration.json',decl);d.write_record(p/'suite.json',suite)
from multipv_player_20261007 import MultiPlayer
class Player(MultiPlayer):
 def __init__(self,*args,mode,**kw):super().__init__(*args,**kw);self.mode=mode
 def choose(self):
  m,r=super().choose();r.update(leaf_mode=self.mode,requested_seconds=1,leaf_binary_sha256=decl['binary_sha256'][self.mode]);return m,r
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
out=p/'games.json';assert not out.exists()
report=dict(declaration=decl,games=[],complete=False);cost=dict(writes=0,bytes=0,seconds=0.)
def stopcheck():
 for n in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if f.get('user_paused') or f.get('stopped'):raise KeyboardInterrupt('User stop retained')
def save(indent=None):
 t=time.perf_counter();d.write_record(out,report,indent=indent);cost['seconds']+=time.perf_counter()-t;cost['writes']+=1;cost['bytes']+=out.stat().st_size
start=time.perf_counter();save()
try:
 pair=0
 for case in suite['cases']:
  for policy in d.POLICIES:
   for color in (0,1):
    modes=('pure','activity') if pair%2==0 else ('activity','pure');pair+=1
    for mode in modes:
     stopcheck();binary=pure if mode=='pure' else activity
     with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as other:
      e.configure({'Threads':1,'Hash':16,'Use NNUE':False});other.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
      local=Player(e,case['fen'],policy,1,mode=mode);external=d.UciOpponent(other,case['fen'],50000)
      def progress(game):report['active_game']=dict(id=case['id'],leaf_mode=mode,**game);save();stopcheck()
      game=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=external,local_external=local,prefix=case['opening_uci'])
      report.pop('active_game',None);report['games'].append(dict(id=case['id'],leaf_mode=mode,**game));save()
      rows=[r for r in game['moves'] if 'leaf_mode' in r]
      print(case['id'],policy,color,mode,game['end'],game['winner'],game['plies_played'],'localwall',sum(r['wall_seconds'] for r in rows),'nodes',sum(r.get('engine_nodes',0) for r in rows),flush=True)
 report['complete']=True
finally:
 report.update(wall_seconds=time.perf_counter()-start,recording_cost=dict(cost));save(2)
print('COMPLETE',report['complete'],report['wall_seconds'],cost,flush=True)
