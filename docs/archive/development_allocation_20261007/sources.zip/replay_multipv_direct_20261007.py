import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'.local_agent/certificate_source/python-chess'))
import scripts.chess_development as d
p=ROOT/'.local_agent/activity-multipv-direct-20261007';out=p/'replay.json';assert not out.exists()
raw=(p/'games.json').read_bytes();v=json.loads(raw);assert v['complete'] and len(v['games'])==12
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());report=dict(complete=False,input_sha256=hashlib.sha256(raw).hexdigest(),games=[],errors=[])
for i,g in enumerate(v['games']):
 other=d.UciOpponent(None,g['initial_fen'],1);s,_=d.replay_prefix(g['initial_fen'],c,g['opening_uci'],(other,));calls=nodes=0;seconds=0.
 for r in g['moves']:
  legal={d.uci(a):a for a in d.iter_legal_actions(s,c)}
  assert set(legal)=={m.uci() for m in other.board.legal_moves}
  assert r['legal'] and r['move'] in legal and r['side']==s.position.side_to_move and r['ply']==s.ply_count
  if 'leaf_mode' in r:
   assert r['leaf_mode']==g['white_leaf_mode' if r['side']==0 else 'black_leaf_mode'] and r['policy']==g['table'] and r['requested_seconds']==1
   assert r['leaf_binary_sha256']==v['declaration']['binary_sha256'][r['leaf_mode']]
   assert r['reason']=='native_MultiPV3_final_bestmove' and 1<=len(r['multipv_lines'])<=3
   assert any(line['pv'] and line['pv'][0]==r['move'] for line in r['multipv_lines'])
   calls+=1;nodes=None if nodes is None or r.get('engine_nodes') is None else nodes+r['engine_nodes'];seconds+=r['wall_seconds']
  s=d.apply_action(s,legal[r['move']],c);other.push(r['move'],s)
 assert d.record_value(s)==g['final_state']
 assert len(s.history)==len(g['opening_uci'])+len(g['moves'])+1
 report['games'].append(dict(index=i,id=g['id'],table=g['table'],white_leaf_mode=g['white_leaf_mode'],black_leaf_mode=g['black_leaf_mode'],white=g['white'],black=g['black'],plies=len(g['moves']),prefix_plies=len(g['opening_uci']),end=g['end'],winner=g['winner'],finished=g['finished'],local_calls=calls,local_wall_seconds=seconds,reported_engine_nodes=nodes))
 d.write_record(out,report,indent=None)
report.update(complete=True,played_plies=sum(g['plies'] for g in report['games']),prefix_plies=sum(g['prefix_plies'] for g in report['games']));d.write_record(out,report)
print('replay',len(report['games']),report['played_plies'],'zero mismatches; leaf identity verified',flush=True)
