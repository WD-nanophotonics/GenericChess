# Exposed root allocation diagnosis
Pinned source9f778da667f6e07dae1e85d3e2ea204fc6dee94d, unchanged builds.
Question: leaf-value ranking versus selective root allocation on retained linearBlack33.
search.cpp873: check nodes skip early evaluation pruning; qsearch1584 disables stand pat in check.
search.cpp910/920: staticEval changes quiet history and improving;931/940/1006 changes futility/null/ProbCut.
search.cpp1280-1406: late moves get reduced zero-window searches; only fail-high results get fuller/PV searches. This is a plausible coupling, not a measured unique defective branch.
position.cpp2502: SEE uses global PieceValue, not the activity union or variant leaf table; changing leaf does not make search heuristics mathematically consistent.
search.cpp391-480: MultiPV iterates separate root PV indices and aspiration windows, changing ordering, TT/history and time allocation. It is not an isolated LMR toggle.
Observed forced one-move g6g5: pure mate-11/-10 at1/4seconds, activity cp-2337/mate-11. Activity unrestricted4sec had selectedg6g5.
Existing MultiPV3/5 choices at1/4sec all avoidg6g5. This supports a practical allocation followup; no exact mate certificate, default, coefficient tuning or unique causal identification.
Declaration correction: forced.json says18calls; actual loop executed12calls30requestedseconds. No records changed.
A full PV reaching checkmate verifies one legal line, not every defensive continuation.
Before new game results: direct12reciprocal cells and stronger24cells(two same prefixes,3tables,2colors,2leaves), all native MultiPV3/1sec, fixed160ply cap, immutable original SinglePV records. No result-dependent sample extension. Existing game entry/finalbestmove used; stale/different-depth info lines not retrospectively sorted by cp.
Decision: retain optional allocation only if useful practical evidence; all-loss games diagnose failures, not strength; same-root finite controls separate changed trajectories.
Cost: direct<=1920seconds both sides, stronger<=1920local plus finite reference1sec fuse, sequential one-core engines/no heavy concurrent jobs; stop check each move. Cost checkpoints, no runaway extension.
