"""Actual Core-owned caller: semantic attack backend and legality attribution."""
import argparse, hashlib, json, random, sys, time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value, write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from scripts.native_core_availability import NativeCoreAvailability
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess.core import search_runtime as runtime_module
import inspect,textwrap
from generic_chess.ai.alphabeta import search as search_module
from scripts.quiet_drop_probe import QuietDropProbe
from generic_chess.ai.alphabeta.tuning import SearchTuning

class CountedSemanticEvaluator(SemanticAttackEvaluator):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.score_calls=self.map_calls=0
    def evaluate(self,state):
        self.score_calls+=1;return super().evaluate(state)
    def _attack_maps(self,state):
        self.map_calls+=1;return super()._attack_maps(state)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
    b=Path(args.output);b.mkdir(parents=True,exist_ok=True)
    if (b/'declaration.json').exists():raise RuntimeError('frozen output exists')
    modes=[('baseline',(False,False)),('probe',(False,True))]
    declaration=dict(question='Does guarded quiet-drop exclusion agree with every full Core shadow child encountered?'  ,roots=['shogi-drop'],modes=modes,orders=2,depths=[8192,16384],q=4,hardq=8,nodes=4096,seconds=[16,64],calls=8,expected_seconds='Maximum64searchseconds plus setup; expected8-11min, entire run below one hour; interruptible',decision='Complete equal-depth action/score/non-time work must match for evaluator backend attribution; any mismatch investigated without fitting. Both arms retain the same Native legal provider and original Core gave-check; only availability differs. Delivered completion and costs are primary; partial work need not match. Partial iterations are execution limits, not decision gains. No cap extension/default changes.',scope='Both arms use actual Native semantic attacks and Native legal provider, same weights, original Core history/precedence/order/TT. Only S0-S4 availability uses the optional existing per-instance interface; Core check/history/TT/terminal remain. Actual public AlphaBetaPlayer, Core terminal/history/identity/declarations and fresh TT/ordering defaults. Existing familiar Chess EP/Shogi rich-drop roots. Changed premise is the live-prefix Native availability transport inside current token-optimized Core, rather than pre-repair negative Native primitives. Development transfer, no independent holdout claim; frozen identical weights/profile, explicit SEMANTIC attack authority. Not legacy evaluation equality or thin-capsule product integration.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    declaration.update(question='Does guarded quiet-drop bookkeeping elimination add useful support beyond existing semantic PVS, and does either interaction degrade at a larger fixed time?',roots=['shogi-drop'],modes=modes,orders=2,node_budgets=[8192,16384],depths=[12],q=4,hardq=8,seconds=60,calls=16,time_budgets=[64,256],expected_seconds='Maximum2560ssearch plus setup; interruptible; no cap extension',decision='Botharms same semantic leaves/nativelegal/availability/Core check/history/TT. Only existing PVS and q exclusion vary, independently in4arms. Q guards prove noisyfalse, default unchanged. Compare action/score/PV/deliveredq plus main/q nodes and cost. No default change, generic unknown scopes decline.',scope='Adaptive exposed existing Shogirichdrop root after zero-mismatch4096node shadow. Actual execution maxdepth12/1Mnodes/64or256s,4algorithm/probe factorial arms. Earlier frozen caps remain unchanged.256s is a newly predeclared common resource curve for the interaction question, not a rescue of failed cells. Original8192/16384 caps remain frozen separate. Not independentholdout/strength/fullgeneric evidence.')
    declaration.update(question='Does quiet-drop exclusion reduce equal-work caller cost in existing PVS as well as baseline?', calls=8,node_budgets=[32768],time_budgets=None,seconds=120, expected_seconds='Maximum960ssearch plus setup; under one hour; stop at original node/time cap',scope='Actual execution8calls,4arms bothorders,maxdepth12,32768combinednodes,120s,q4hard8,Native semantic leaves/legal/availability and originalCorehistory. Same exposed Shogidrop root. Different PVS work/support is not held equal; exclusion pairs compare within PVS flag. Newly predeclared interaction attribution, no extension of previous caps or holdout/strength claim.')
    declaration.update(question='Does guarded drop exclusion preserve generated semantic D2 decisions/work and cost on an actual drop-rich root and initially no-drop root?',roots=[1006,1008],modes=modes,calls=8,depths=[2],node_budgets=[100000],time_budgets=None,seconds=60,expected_seconds='Maximum480searchseconds plus setup; no extension',scope='Exposed existing1006/1008ply8 roots, actual public maxdepth2/node100000/time60/q4hard8. Native semantic evaluator/legal/availability; originalCorehistory. Only scoped research q prefix differs. Same-depth decision and recursive work checked; interrupted work not equated; not generic-domain or stronger-move proof.')
    write_record(b/'declaration.json',declaration)
    roots=[];samples=[]
    for seed in (1006,1008):
        g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));source=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=source.ir,_legacy_compiled=source._legacy_compiled,support=source.support);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);s=p.GameSession(c);rng=random.Random(seed+7000)
        for _ in range(8):
            if s.result.status.value!='ongoing':break
            actions=sorted(s.legal_actions(),key=repr)
            if not actions:break
            s.submit(rng.choice(actions))
        assert s.state.ply_count==8 and s.result.status.value=='ongoing'
        roots.append((seed,c,ec,profile,s));samples.append(dict(seed=seed,initial=record_value(s.state),witnesses=record_value(s._search_witnesses),profile=record_value(profile),config=record_value(ec)))
    write_record(b/'samples.json',samples)
    runtimes=[];captured=[];old_attach=SearchPathRuntime.attach_stats;old_stats=pm.SearchStatistics
    imports=queries=0;old_pack=ns.pack_current_position;old_attack=ns.attacked_squares
    def pack(*a,**kw):
        nonlocal imports;imports+=1;return old_pack(*a,**kw)
    def attack(*a,**kw):
        nonlocal queries;queries+=1;return old_attack(*a,**kw)
    def attach(rt,stats):
        v=old_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return v
    def factory():
        v=SearchStatistics();captured.append(v);return v
    rows=[];start=time.perf_counter()
    try:
        SearchPathRuntime.attach_stats=attach;pm.SearchStatistics=factory;ns.pack_current_position=pack;ns.attacked_squares=attack
        for seed,c,ec,profile,s in roots:
            legal=set(s.legal_actions());saved=s.state
            for depth in declaration['depths']:
                for order in range(2):
                    for backend,flags in (modes if order==0 else list(reversed(modes))):
                        pvs,native=flags
                        p.rr.stopped();runtimes.clear();captured.clear();imports=queries=0
                        probe=QuietDropProbe(shadow=False); original_q=search_module._quiescence_runtime
                        source=textwrap.dedent(inspect.getsource(original_q))
                        target='    for action in ordered:\n'
                        assert source.count(target)==1
                        source=source.replace(target,'    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
                        namespace=dict(search_module.__dict__,quiet_drop_probe=probe)
                        exec(compile(source,'<research-quiet-drop>','exec'),namespace);search_module._quiescence_runtime=namespace['_quiescence_runtime'] if native else original_q
                        t=time.perf_counter();ev=CountedSemanticEvaluator(c,profile,ec,backend='native');availability=None;check=None;player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,use_disk_cache=False,use_native_semantic_availability=True,tuning=SearchTuning(use_pvs=pvs))
                        value=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=100000,max_time_seconds=60,quiescence_max_depth=4,quiescence_hard_max_depth=8))
                        search_module._quiescence_runtime=original_q
                        elapsed=time.perf_counter()-t
                        assert len(runtimes)==len(captured)==1
                        rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot and s.state==saved and value.action in legal
                        row=dict(probe_counts=dict(probe.counts),actual_product_availability=player.native_legality_provider.availability_metrics,seed=seed,budget_seconds=60,depth_requested=depth,node_budget=100000,order=order,attack_backend='native',native_legal_requested=True,algorithm_mode=backend,availability_counts=None if availability is None else dict(calls=availability.calls,imports=availability.imports,queries=availability.queries,fallbacks=availability.fallbacks,payload_seconds=availability.payload_seconds,query_seconds=availability.query_seconds),provider_created=player.native_legality_provider is not None,caller_seconds=elapsed,score_calls=ev.score_calls,map_calls=ev.map_calls,actual_attack_imports=imports,actual_attack_queries=queries,decision=record_value(value),stats=record_value(captured[0]),root_restored=True)
                        rows.append(row);write_record(b/'result.json',dict(complete=False,rows=rows));print(seed,depth,order,backend,native,value.completed_depth,value.termination_reason,round(elapsed,3),value.score,flush=True)
    finally:
        if 'original_q' in locals():search_module._quiescence_runtime=original_q
        SearchPathRuntime.attach_stats=old_attach;pm.SearchStatistics=old_stats;ns.pack_current_position=old_pack;ns.attacked_squares=old_attack
    write_record(b/'result.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
if __name__=='__main__':main()
