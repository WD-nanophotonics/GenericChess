"""One diagnostic of actual Core hash portions, not a new hash algorithm."""
from pathlib import Path
import json,importlib.util,inspect,textwrap,time,hashlib
from generic_chess.core import search_runtime as rt
base=Path('.local_agent/quiet-drop-probe-20261012');decl=base/'hash-portion-declaration.json';assert not decl.exists()
decl.write_text(json.dumps({'question':'Is full-board scanning enough of actual Core hash cost to justify an effect-footprint experiment?','action':'One same minimalNativebothD1 with timers around unchanged hash board/nonboard portions; compare every returned hash against original function and complete decision/work/trace.','cost':'One15s16384node bounded search; oracle and timing overhead included, no speed claim.','done':'Choose footprint prototype only if measured portion is material; otherwise defer it without further token/cache audits.'},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('b',Path('.local_agent/minimal-q-native-bridge-20261012/producer.py'));b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
original=rt._semantic_component_diff_hash;source=textwrap.dedent(inspect.getsource(original));counts={'calls':0,'board_cells':0,'board_seconds':0.0,'nonboard_seconds':0.0}
source=source.replace('    value = current\n','    portion_start = time.perf_counter()\n    value = current\n',1).replace('    before = _nonboard_component_map(parent, compiled)\n','    counts["board_seconds"] += time.perf_counter()-portion_start\n    counts["board_cells"] += len(parent.board)\n    portion_start = time.perf_counter()\n    before = _nonboard_component_map(parent, compiled)\n',1).replace('    return value\n','    counts["nonboard_seconds"] += time.perf_counter()-portion_start\n    counts["calls"] += 1\n    assert value == oracle(parent, child, compiled, current)\n    return value\n',1)
ns=dict(rt.__dict__,time=time,counts=counts,oracle=original);exec(source,ns);rt._semantic_component_diff_hash=ns['_semantic_component_diff_hash']
try:
 c=b.compile_ruleset_for_execution(b.build_builtin_ruleset('standard_shogi'));provider=b.NativeSemanticLegalityProvider.try_create(c);assert provider
 board=b.CoreBoard(next(x for x in b.CASES if x['id']=='shogi-drop'),c,provider=provider);board.runtime.availability_provider=provider.has_legal_action;result=b.run(board,1)
finally:rt._semantic_component_diff_hash=original
control=next(r['result'] for r in json.loads(Path('.local_agent/minimal-q-native-bridge-20261012/caller/result.json').read_text())['rows'] if r['depth']==1 and r['order']==0 and r['backend']=='core_native_both')
diff=[f for f in ['move','score','reason','completed_depth','work','trace_sha256'] if result[f]!=control[f]];assert not diff,diff
assert counts['calls']==result['work']['pushes']
record={'complete':True,'calls':1,'counts':counts,'result':result,'equal_decision_work_trace':True,'full_original_hash_equal_every_child':True,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'limit':'Timers include board tokens/nonboard maps and tokens; oracle overhead outside portions. Not a clean speed comparison or a changed footprint implementation.'}
(base/'hash-portion-verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
