"""Bounded actual public PVS transfer on an existing compound rule fixture."""
import sys,json,time,hashlib
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,'tests')
from rule_semantics_ir_fixtures import castling_ruleset
from generic_chess import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
base=Path('.local_agent/quiet-drop-probe-20261012/compound-caller');base.mkdir(exist_ok=True);assert not (base/'declaration.json').exists()
write_record(base/'declaration.json',{'question':'Does existing PVS preserve completed D2/q4 decisions on persistent auxiliary rights and a four-cell semantic action?','calls':4,'depth':2,'q':4,'hardq':8,'nodes':100000,'seconds':10,'orders':2,'cost':'Maximum40s plus setup; below1h, no replacement or cap extension.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'decision':'If equal-support decisions diverge, inspect semantics before fitting; abort/immediate-win scope retained. No product/UI adoption.'})
c=compile_ruleset_for_execution(castling_ruleset());initial=GameSession(c).state;rt=SearchPathRuntime.from_state(initial,c,history_witnesses=(initial.position,));s=SimpleNamespace(state=initial,_search_witnesses=(initial.position,),legal_actions=rt.legal_actions);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
write_record(base/'samples.json',{'state':record_value(initial),'witnesses':record_value(s._search_witnesses),'profile':record_value(profile),'config':record_value(ec)})
rows=[]
for order in [0,1]:
 for enabled in ([False,True] if order==0 else [True,False]):
  ev=SemanticAttackEvaluator(c,profile,ec,backend='native');player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=enabled));start=time.perf_counter();value=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=100000,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8));assert s.state is initial and rt.restored() if hasattr(rt,'restored') else s.state is initial
  row={'order':order,'pvs':enabled,'decision':record_value(value),'caller_seconds':time.perf_counter()-start,'provider_created':player.native_legality_provider is not None,'availability_metrics':player.native_legality_provider.availability_metrics};rows.append(row);print(order,enabled,value.completed_depth,value.termination_reason,value.score,flush=True)
  write_record(base/'result.json',{'complete':False,'rows':rows})
write_record(base/'result.json',{'complete':True,'rows':rows})
