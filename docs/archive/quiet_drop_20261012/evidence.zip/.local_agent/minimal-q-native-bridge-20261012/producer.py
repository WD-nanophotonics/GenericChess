"""Scoped same-policy minimal AB/q bridge; no product integration."""
import sys,json,time,hashlib
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.search_backend_comparison import CASES,CoreBoard,ChessBoard,ShogiBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from scripts.research_record import write_record

class Abort(Exception):pass

def check(board):
    if isinstance(board,CoreBoard):
        return board.runtime.in_check(board.runtime.position.side_to_move,checkpoint=board.checkpoint)
    return board.board.is_check()

def signals(board):
    cells,hands,side,aux,ply=board.snapshot()
    inventory=Counter((x[0],x[2]) for x in cells if x is not None)
    for owner,hand in enumerate(hands):
        for tid,n in hand:inventory[owner,tid]+=n
    return side,sum(x is not None and x[0]!=side for x in cells),inventory

def run(board,depth):
    start=time.perf_counter();work=Counter();trace=hashlib.sha256();best=None;bestscore=None
    def poll():
        if time.perf_counter()-start>=15:raise Abort('time_limit')
    def enter(kind):
        poll()
        if work['main_nodes']+work['qnodes']>=16384:raise Abort('node_limit')
        work[kind]+=1
    def terminal(ply):
        work['terminal_queries']+=1
        return board.terminal(ply)
    def evaluate():
        work['evaluations']+=1;return board.evaluate()
    def actions():
        work['legal_queries']+=1;return board.actions()
    def push(action):board.push(action);work['pushes']+=1
    def q(alpha,beta,ply,qdepth):
        enter('qnodes');term=terminal(ply)
        if term is not None:trace.update(f'T:{ply}:{term};'.encode());return term
        work['check_queries']+=1;checked=check(board)
        if checked:
            if qdepth>=8:raise Abort('q_hard_limit')
            value=-2000000000
        else:
            value=evaluate();trace.update(f'E:{ply}:{value};'.encode())
            if value>=beta:work['stand_pat_cutoffs']+=1;return value
            alpha=max(alpha,value)
            if qdepth>=4:work['qdepth_cutoffs']+=1;return alpha
        ordered=actions();trace.update(('A:'+','.join(label for label,_ in ordered)+';').encode())
        side,parent_enemies,parent_inventory=signals(board)
        for label,action in ordered:
            push(action)
            try:
                included=checked
                if not included:
                    childside,childenemies,inventory=signals(board)
                    # enemy count relative to parent actor, after side switches
                    cells=board.snapshot()[0]
                    enemies=sum(x is not None and x[0]!=side for x in cells)
                    childterm=terminal(ply+1)
                    included=enemies<parent_enemies or inventory!=parent_inventory or childterm is not None
                    if not included:work['check_queries']+=1;included=check(board)
                trace.update(f'Q:{ply}:{label}:{int(bool(included))};'.encode())
                if not included:work['excluded']+=1;continue
                work['included']+=1;score=-q(-beta,-alpha,ply+1,qdepth+1)
            finally:board.pop();work['pops']+=1
            trace.update(f'V:{ply}:{label}:{score};'.encode());value=max(value,score);alpha=max(alpha,score)
            if alpha>=beta:work['cutoffs']+=1;break
        return alpha if not checked else value
    def visit(left,alpha,beta,ply):
        nonlocal best,bestscore
        if left==0:return q(alpha,beta,ply,0)
        enter('main_nodes');term=terminal(ply)
        if term is not None:return term
        ordered=actions();trace.update(('M:'+','.join(label for label,_ in ordered)+';').encode());value=-2000000000
        for label,action in ordered:
            push(action)
            try:score=-visit(left-1,-beta,-alpha,ply+1)
            finally:board.pop();work['pops']+=1
            trace.update(f'R:{ply}:{label}:{score};'.encode())
            if ply==0:
                work['completed_root_children']+=1
                if best is None or score>bestscore:best,bestscore=label,score
            value=max(value,score);alpha=max(alpha,value)
            if alpha>=beta:work['cutoffs']+=1;break
        return value
    if hasattr(board,'checkpoint'):board.checkpoint=poll
    try:score=visit(depth,-2000000000,2000000000,0);reason='completed_depth'
    except Abort as exc:score=bestscore;reason=str(exc)
    finally:
        if hasattr(board,'checkpoint'):board.checkpoint=None
    assert board.restored()
    return {'move':best,'score':score,'reason':reason,'completed_depth':depth if reason=='completed_depth' else 0,'work':dict(work),'trace_sha256':trace.hexdigest(),'seconds':time.perf_counter()-start,'root_restored':True}

if __name__=='__main__':
    base=Path(sys.argv[1]);base.mkdir(exist_ok=True)
    assert not (base/'declaration.json').exists()
    plan=json.loads(Path(__file__).with_name('plan.json').read_text());plan['source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(base/'declaration.json',plan)
    rows=[]
    for case_id in ['shogi-drop']:
        case=next(x for x in CASES if x['id']==case_id);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        for depth in [1,2]:
            for order in [0,1]:
                for kind in (['core_python','core_native_legal','core_native_both'] if order==0 else ['core_native_both','core_native_legal','core_python']):
                    provider=None if kind=='core_python' else NativeSemanticLegalityProvider.try_create(c)
                    assert kind=='core_python' or provider is not None
                    board=CoreBoard(case,c,provider=provider)
                    if kind=='core_native_both':board.runtime.availability_provider=provider.has_legal_action
                    result=run(board,depth);result['native_legality_active']=board.runtime._legal_provider_active;result['runtime_counts']={k:getattr(board.runtime,k) for k in ['legal_provider_calls','legal_provider_fallbacks','legal_provider_operational_failures','pushes','pops']};result['availability_metrics']=None if provider is None else provider.availability_metrics;rows.append({'case':case_id,'depth':depth,'order':order,'backend':kind,'result':result});write_record(base/'result.json',{'complete':False,'rows':rows});print(case_id,depth,order,kind,result['reason'],round(result['seconds'],3),result['work'],flush=True)
    write_record(base/'result.json',{'complete':True,'rows':rows})
