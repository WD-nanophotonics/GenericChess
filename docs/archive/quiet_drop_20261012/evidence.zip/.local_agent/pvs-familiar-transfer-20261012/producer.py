"""Actual Core-owned caller: semantic attack backend and legality attribution."""
import argparse, hashlib, json, random, sys, time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value, write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from scripts.native_core_availability import NativeCoreAvailability
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess.core import search_runtime as runtime_module
from generic_chess.ai.alphabeta.tuning import SearchTuning

class CountedSemanticEvaluator(SemanticAttackEvaluator):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.score_calls=self.map_calls=0
    def evaluate(self,state):
        self.score_calls+=1;return super().evaluate(state)
    def _attack_maps(self,state):
        self.map_calls+=1;return super()._attack_maps(state)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
    b=Path(args.output);b.mkdir(parents=True,exist_ok=True)
    if (b/'declaration.json').exists():raise RuntimeError('frozen output exists')
    modes=[('baseline',False),('pvs',True)]
    declaration=dict(question='Does existing PVS transfer to familiar ChessEP/Shogi-drop with current semantic leaves under equal public deadlines?' ,roots=['chess-ep','shogi-drop'],modes=modes,orders=2,depths=[16,64],q=4,hardq=8,nodes=1000000,seconds=[16,64],calls=16,expected_seconds='Maximum640searchseconds plus setup; expected8-11min, entire run below one hour; interruptible',decision='Complete equal-depth action/score/non-time work must match for evaluator backend attribution; any mismatch investigated without fitting. Both arms retain the same Native legal provider and original Core gave-check; only the existing PVS switch differs; availability identical. Delivered completion and costs are primary; partial work need not match. Partial iterations are execution limits, not decision gains. No cap extension/default changes.',scope='Both arms use actual Native semantic attacks and Native legal provider, same weights, original Core history/precedence/order/TT. Both arms use identical S0-S4 Native availability; only PVS differs; Core check/history/TT/terminal remain. Actual public AlphaBetaPlayer, Core terminal/history/identity/declarations and fresh TT/ordering defaults. Existing familiar Chess EP/Shogi rich-drop roots. Changed premise is current semantic leaves and familiar-rule PVS transfer after mixed generated-root evidence. Current1053 transfer small/no support gain;1054 immediate-win uninformative, retained without replacement. Development transfer, no independent holdout claim; frozen identical weights/profile, explicit SEMANTIC attack authority. Not legacy evaluation equality or thin-capsule product integration.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    write_record(b/'declaration.json',declaration)
    roots=[];samples=[]
    for case_id in ('chess-ep','shogi-drop'):
        case=next(x for x in CASES if x['id']==case_id)
        c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        core=CoreBoard(case,c);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
        s=SimpleNamespace(state=core.initial,_search_witnesses=core.witnesses,legal_actions=core.runtime.legal_actions)
        roots.append((case_id,c,ec,profile,s));samples.append(dict(case=case,initial=record_value(s.state),witnesses=record_value(core.witnesses),profile=record_value(profile),config=record_value(ec)))
    write_record(b/'samples.json',samples)
    runtimes=[];captured=[];old_attach=SearchPathRuntime.attach_stats;old_stats=pm.SearchStatistics
    imports=queries=0;old_pack=ns.pack_current_position;old_attack=ns.attacked_squares
    def pack(*a,**kw):
        nonlocal imports;imports+=1;return old_pack(*a,**kw)
    def attack(*a,**kw):
        nonlocal queries;queries+=1;return old_attack(*a,**kw)
    def attach(rt,stats):
        v=old_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return v
    def factory():
        v=SearchStatistics();captured.append(v);return v
    rows=[];start=time.perf_counter()
    try:
        SearchPathRuntime.attach_stats=attach;pm.SearchStatistics=factory;ns.pack_current_position=pack;ns.attacked_squares=attack
        for seed,c,ec,profile,s in roots:
            legal=set(s.legal_actions());saved=s.state
            for depth in declaration['depths']:
                for order in range(2):
                    for backend,native in (modes if order==0 else list(reversed(modes))):
                        p.rr.stopped();runtimes.clear();captured.clear();imports=queries=0
                        t=time.perf_counter();ev=CountedSemanticEvaluator(c,profile,ec,backend='native');availability=NativeCoreAvailability(c);check=None;player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,use_disk_cache=False,availability_provider=availability.for_position,tuning=SearchTuning(use_pvs=native))
                        value=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=depth,quiescence_max_depth=4,quiescence_hard_max_depth=8))
                        elapsed=time.perf_counter()-t
                        assert len(runtimes)==len(captured)==1
                        rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot and s.state==saved and value.action in legal
                        row=dict(seed=seed,budget_seconds=depth,depth_requested=12,order=order,attack_backend='native',native_legal_requested=True,algorithm_mode=backend,availability_counts=None if availability is None else dict(calls=availability.calls,imports=availability.imports,queries=availability.queries,fallbacks=availability.fallbacks,payload_seconds=availability.payload_seconds,query_seconds=availability.query_seconds),provider_created=player.native_legality_provider is not None,caller_seconds=elapsed,score_calls=ev.score_calls,map_calls=ev.map_calls,actual_attack_imports=imports,actual_attack_queries=queries,decision=record_value(value),stats=record_value(captured[0]),root_restored=True)
                        rows.append(row);write_record(b/'result.json',dict(complete=False,rows=rows));print(seed,depth,order,backend,native,value.completed_depth,value.termination_reason,round(elapsed,3),value.score,flush=True)
    finally:
        SearchPathRuntime.attach_stats=old_attach;pm.SearchStatistics=old_stats;ns.pack_current_position=old_pack;ns.attacked_squares=old_attack
    write_record(b/'result.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
if __name__=='__main__':main()
