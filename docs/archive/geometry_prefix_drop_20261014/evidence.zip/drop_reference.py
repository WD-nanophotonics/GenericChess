from pathlib import Path
import sys,json,time
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'drop-reference';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Do the fixed four mirrored knownH3 actions retain a full-defense winning terminal when only board extents/drop space grow?',sizes=[4,12,18,24],rootH=3,targets=[['move',3,2,1,2],['move',3,2,0,2],['move',3,2,3,1],['drop',0,2]],max_apply=100000,seconds=180,scope='Reference specified from existing4board proof before any largerboard search. All defenses complete, no q/material/evaluation in oracle; no q-policy selection on incomplete labels. Unknown preserved.'))
rows=[];start=time.perf_counter();count=0
class Limited(Exception):pass
def perform(state,a,c):
 global count
 p.rr.stopped()
 if count>=100000 or time.perf_counter()-start>=180:raise Limited()
 count+=1;return apply_action(state,a,c)
def prove(state,h,c):
 if state.terminal_status.is_terminal:return state.terminal_status.winner==0,dict(terminal=record_value(state.terminal_status))
 if h==0:return False,dict(frontier=True)
 acts=tuple(legal_actions(state,c));assert acts;attacking=state.position.side_to_move==0;edges=[]
 for a in acts:
  value,proof=prove(perform(state,a,c),h-1,c);edge=dict(action=record_value(a),proof=proof)
  if attacking and value:return True,dict(attacker_choice=edge)
  if not attacking and not value:return False,dict(defender_counterexample=edge)
  edges.append(edge)
 return (False,dict(all_attacker_actions_fail=edges)) if attacking else (True,dict(all_defender_actions_win=edges))
def signature(a):
 if hasattr(a,'from_square'):return ['move',a.from_square.file,a.from_square.rank,a.to_square.file,a.to_square.rank]
 return ['drop',a.to_square.file,a.to_square.rank]
for n in (4,12,18,24):
 rules,c,s=make(n);acts=s.legal_actions()
 for target in [['move',3,2,1,2],['move',3,2,0,2],['move',3,2,3,1],['drop',0,2]]:
  a=next(a for a in acts if signature(a)==target)
  try:
   value,proof=prove(perform(s.state,a,c),2,c);row=dict(size=n,action=record_value(a),forces_root_win_H3=value,proof=proof)
  except Limited:row=dict(size=n,action=record_value(a),forces_root_win_H3=None,unknown=True)
  rows.append(row);write_record(out/'rows.json',dict(complete=False,rows=rows,apply_calls=count,seconds=time.perf_counter()-start))
  print(n,target,row['forces_root_win_H3'],count,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,apply_calls=count,seconds=time.perf_counter()-start))
# Independent proof consumer: reconstruct each action against complete Core legalset.
verified=0;apply_verify=0
def consume(state,h,proof,c,attacker):
 global verified,apply_verify
 verified+=1
 if 'terminal' in proof:
  assert state.terminal_status.is_terminal and record_value(state.terminal_status)==proof['terminal']
  return state.terminal_status.winner==attacker
 assert not state.terminal_status.is_terminal
 if 'frontier' in proof:assert h==0;return False
 assert h>0
 acts=tuple(legal_actions(state,c));by={json.dumps(record_value(a),sort_keys=True):a for a in acts};attack=state.position.side_to_move==attacker
 if 'attacker_choice' in proof:assert attack;edges=[proof['attacker_choice']];expected=True
 elif 'defender_counterexample' in proof:assert not attack;edges=[proof['defender_counterexample']];expected=False
 else:
  name='all_attacker_actions_fail' if attack else 'all_defender_actions_win'
  edges=proof[name];assert [json.dumps(e['action'],sort_keys=True) for e in edges]==list(by);expected=not attack
 for edge in edges:
  action=by[json.dumps(edge['action'],sort_keys=True)];apply_verify+=1
  assert consume(apply_action(state,action,c),h-1,edge['proof'],c,attacker)==expected
 return expected
original=json.loads((D/'drop-goal/proof.json').read_text(encoding='utf-8'));_,c,s=make(4,mirror=False)
assert len(original['answers'])==len(s.legal_actions())
for answer,a in zip(original['answers'],s.legal_actions()):
 assert record_value(a)==answer['action'];apply_verify+=1
 assert consume(apply_action(s.state,a,c),2,answer['proof'],c,0)==answer['forces_root_win_H3']
for row in rows:
 _,c,s=make(row['size']);a=next(a for a in s.legal_actions() if record_value(a)==row['action']);apply_verify+=1
 assert consume(apply_action(s.state,a,c),2,row['proof'],c,0)==row['forces_root_win_H3']
write_record(out/'verification.json',dict(complete=True,proof_nodes=verified,apply_calls=apply_verify,original_actions=19,mirrored_reference_actions=len(rows),scope='Independent proof parser/replay; no producer recursion/evaluator/search called; all required defense sets matched in exact Core order.'))
print('verified',verified,apply_verify)
