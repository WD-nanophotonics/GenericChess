from pathlib import Path
import sys,time,json,random,ast,hashlib
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'score-band-cost';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
before_source=(D/'search-before-score-band.py').read_text(encoding='utf-8')
tree=ast.parse(before_source);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_evaluate')
scope={};exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'<preserved-before-evaluate>','exec'),sm.__dict__,scope)
old=scope['_evaluate'];new=sm._evaluate
write_record(out/'declaration.json',dict(question='Does the score-band repair preserve ordinary bounded decisions/work and impose material caller overhead?',seeds=[2026102016,2026102017,2026102018],sizes=[12,18,24],q=2,nodes=1024,depth=6,seconds=60,orders=2,planned_calls=12,expected_minutes=1,scope='Changed premise is real total-score correctness repair, not another unchanged cache/resource curve. Same live module globals, before-only _evaluate function bound processlocally vs repaired function. Other product code identical; no on-disk rollback. Existing exposed roots, same exact node budget/evaluator/TT/history.',before_source_sha256=hashlib.sha256((D/'search-before-score-band.py').read_bytes()).hexdigest(),after_source_sha256=hashlib.sha256((ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()).hexdigest()))
rows=[];start=time.perf_counter()
try:
 for seed,size in zip([2026102016,2026102017,2026102018],[12,18,24]):
  game=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support)
  s=p.GameSession(c);rng=random.Random(seed+31000)
  for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
  cfg=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg);snapshot=(s.state,s.to_record(),s._search_witnesses)
  for rep in range(2):
   for arm in (('before','after') if rep==0 else ('after','before')):
    p.rr.stopped();assert time.perf_counter()-start<240;sm._evaluate=old if arm=='before' else new
    t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False)
    decision=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=1024,max_time_seconds=60,quiescence_max_depth=2,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    assert snapshot==(s.state,s.to_record(),s._search_witnesses)
    child=s.state
    for a in decision.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
    rows.append(dict(seed=seed,size=size,rep=rep,arm=arm,total=wall,decision=record_value(decision),full_history_restored=True,pv_core_legal=True))
    write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
    print(size,rep,arm,round(wall,5),decision.nodes,decision.qnodes,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:sm._evaluate=new
excluded={'elapsed_seconds','time_to_first_legal_action','time_to_first_completed_iteration','ordering_seconds','legal_generation_seconds','evaluation_seconds'}
for size in (12,18,24):
 group=[r for r in rows if r['size']==size];base={k:v for k,v in group[0]['decision'].items() if k not in excluded}
 assert all({k:v for k,v in r['decision'].items() if k not in excluded}==base for r in group)
print('all12 normal decisions/work/history identical')
