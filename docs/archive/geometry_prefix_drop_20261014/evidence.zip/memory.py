from pathlib import Path
import sys,json,tracemalloc,gc,dataclasses
from collections.abc import Mapping
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.rules.ir import geometry_candidates
D=ROOT/'.local_agent/geometry-prefix-20261014';rows=[]
for seed,size in zip([2026102016,2026102017,2026102018],[12,18,24]):
 p.rr.stopped()
 game=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
 c=p.compile_legacy_ruleset_for_semantic_execution(game.ruleset)
 base=set()
 def mark(x):
  if id(x) in base:return
  base.add(id(x))
  if dataclasses.is_dataclass(x):
   for f in dataclasses.fields(x):mark(getattr(x,f.name))
  elif isinstance(x,Mapping):
   for k,v in x.items():mark(k);mark(v)
  elif isinstance(x,(tuple,list,set,frozenset)):
   for v in x:mark(v)
 mark(c.ir.geometry)
 gc.collect();tracemalloc.start();before=tracemalloc.get_traced_memory()[0]
 table={}
 for g in c.ir.geometry.values():
  for owner,mapping in g.paths.items():
   table[(id(g),owner)]={source:geometry_candidates(g,owner,source) for source in mapping}
 retained,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
 seen=set(base)
 def additional(x):
  if id(x) in seen:return 0
  seen.add(id(x));n=sys.getsizeof(x)
  if isinstance(x,dict):n+=sum(additional(k)+additional(v) for k,v in x.items())
  elif isinstance(x,(tuple,list)):n+=sum(additional(v) for v in x)
  return n
 rows.append(dict(seed=seed,size=size,retained_traced_bytes=retained-before,peak_traced_bytes=peak-before,new_reachable_bytes_excluding_input_geometry=additional(table),input_geometry_objects=len(base),scope='Pure eager preparation after compiledgeometry exists. tracemalloc tracks Python allocations, not processRSS; excludes preexistinginput graph in reachable correction. No searches rerun.'))
 del table
write_record(D/'geometry-memory.json',dict(rows=rows,scope='Refines earlier wholegraph size; wholegraph is not strict incrementalRSS.'))
print(json.dumps(rows,indent=2))
