from pathlib import Path
import sys,time,json,random,collections
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core import semantic_executor as se
from generic_chess.rules.ir import geometry_candidates
out=ROOT/'.local_agent/geometry-prefix-20261014';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Can static geometry prefix preparation avoid measurable repeated allocation without state caching?',seed=2026102017,size=18,nodes=1024,q=2,seconds=60,planned_calls=2,scope='Original Core q2 counter vs baseline; counters return original outputs. Exposed development not strength; no state or position cache; memory estimate via unique Python object sizes.'))
g=p.generate_game(p.GeneratorConfig(seed=2026102017,board_size=18,setup_preset='bilateral_random',allow_hybrid=True))
c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support)
s=p.GameSession(c);rng=random.Random(2026102017+31000);walk=[]
for _ in range(8):
 acts=sorted(s.legal_actions(),key=repr);a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
write_record(out/'sample.json',dict(ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk))
before=(s.state,s.to_record(),s._search_witnesses)
counter=collections.Counter();values={};calls=0;candidate_total=0;prefix_total=0
def counted(geometry,owner,source):
 global calls,candidate_total,prefix_total
 value=geometry_candidates(geometry,owner,source)
 key=(geometry.geometry_id,owner,source);counter[key]+=1;values[key]=value
 calls+=1;candidate_total+=len(value);prefix_total+=sum(len(x[1]) for x in value)
 return value
rows=[]
for arm in ('baseline','counted'):
 p.rr.stopped();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
 original=se.geometry_candidates
 try:
  if arm=='counted':se.geometry_candidates=counted
  t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=1024,max_time_seconds=60,quiescence_max_depth=2,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
 finally:se.geometry_candidates=original
 assert before==(s.state,s.to_record(),s._search_witnesses)
 rows.append(dict(arm=arm,wall=wall,decision=record_value(d),history_restored=True))
 write_record(out/'rows.json',dict(complete=False,rows=rows))
def size_unique(values):
 seen=set()
 def visit(v):
  if id(v) in seen:return 0
  seen.add(id(v));total=sys.getsizeof(v)
  if isinstance(v,(tuple,list)):total+=sum(visit(x) for x in v)
  return total
 return sum(visit(v) for v in values)
summary=dict(calls=calls,unique_keys=len(counter),candidate_total=candidate_total,prefix_total=prefix_total,unique_candidates=sum(len(v) for v in values.values()),unique_prefix_entries=sum(len(x[1]) for v in values.values() for x in v),value_bytes=size_unique(values.values()),top_keys=counter.most_common(10))
write_record(out/'rows.json',dict(complete=True,rows=rows,counters=summary))
assert rows[0]['decision']==rows[1]['decision'] or all(rows[0]['decision'][key]==rows[1]['decision'][key] for key in ('action','score','principal_variation','nodes','qnodes','completed_depth'))
print(json.dumps(summary));print('walls',[r['wall'] for r in rows])
