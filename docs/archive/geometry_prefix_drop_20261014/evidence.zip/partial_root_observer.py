from pathlib import Path
import sys,time,json,ast,hashlib
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import MATE_THRESHOLD
out=D/'partial-root-observer';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='When old useful H3 goals are lost at budget abort, did a completed winning root child already exist in the interrupted same-policy iteration?',cases=[dict(size=18,q=4),dict(size=24,q=2)],calibration=dict(size=18,q=4,nodes=1024,max_depth=4,seconds=60,planned_calls=2),resource=dict(seconds=16,orders=1,arms=['baseline','observer'],planned_calls=4),expected_minutes=2,scope='Changed mechanism question, not unchanged q curve. Processlocal AST observer before root best/alpha update; full live globals retain recursive instrumentation. Record only completed child results, score>previousalpha and terminal-band proof candidates. No policy/node/stop/default changes; source scalar guard stays repaired. Fixed-node calibration must match every nontiming field. Resource stats can vary with observer overhead. Same knownCore roots; no comparedscore labels for independent H3 goal.'))
original=sm.negamax;events=[];started=0
def observe(action,score,pv,depth,alpha,beta,ordinary):
 events.append(dict(action=record_value(action),score=score,pv=record_value(pv),depth=depth,alpha_before=alpha,beta=beta,ordinary_q=ordinary,elapsed=time.perf_counter()-started,improves_root_alpha=score>alpha))
tree=ast.parse((ROOT/'generic_chess/ai/alphabeta/search.py').read_text(encoding='utf-8'))
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='negamax')
class Insert(ast.NodeTransformer):
 count=0
 def visit_If(self,node):
  self.generic_visit(node)
  if isinstance(node.test,ast.Compare) and ast.unparse(node.test)=='score > best':
   self.count+=1
   injected=ast.parse('if ply == 0:\n _completed_root_observe(action, score, child_result.pv, depth, alpha, beta, _ordinary_qdepth_limit(ctx))').body[0]
   return [ast.copy_location(injected,node),node]
  return node
inserter=Insert();function=inserter.visit(function);assert inserter.count==1
scope={};exec(compile(ast.fix_missing_locations(ast.Module(body=[function],type_ignores=[])),'<root-child-observer>','exec'),sm.__dict__,scope)
instrumented=scope['negamax'];sm._completed_root_observe=observe
rows=[]
try:
 for size,q,calibrate in ((18,4,True),(18,4,False),(24,2,False)):
  _,c,s=make(size);cfg=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg)
  before=(s.state,s.to_record(),s._search_witnesses)
  for arm in ('baseline','observer'):
   p.rr.stopped();events.clear();sm.negamax=original if arm=='baseline' else instrumented
   player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
   started=time.perf_counter()
   d=player.choose_action(s,SearchLimits(max_depth=4 if calibrate else 12,max_nodes=1024 if calibrate else None,max_time_seconds=60 if calibrate else 16,quiescence_max_depth=q,quiescence_hard_max_depth=8))
   assert before==(s.state,s.to_record(),s._search_witnesses)
   wins=[e for e in events if e['score']>=MATE_THRESHOLD and e['improves_root_alpha']]
   rows.append(dict(size=size,q=q,calibration=calibrate,arm=arm,total=time.perf_counter()-started,decision=record_value(d),completed_root_events=list(events),completed_root_winning_improvements=wins,full_history_restored=True))
   write_record(out/'rows.json',dict(complete=False,rows=rows))
   print(size,q,calibrate,arm,round(rows[-1]['total'],4),d.completed_depth,d.result_ordinary_qdepth,'events',len(events),'winning',len(wins),flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows))
finally:sm.negamax=original;del sm._completed_root_observe
excluded={'elapsed_seconds','time_to_first_legal_action','time_to_first_completed_iteration','ordering_seconds','legal_generation_seconds','evaluation_seconds'}
cal=rows[:2];assert {k:v for k,v in cal[0]['decision'].items() if k not in excluded}=={k:v for k,v in cal[1]['decision'].items() if k not in excluded};assert cal[1]['completed_root_events']
write_record(out/'qualification.json',dict(fixed_node_all_nontiming_fields_equal=True,actual_calibration_events=len(cal[1]['completed_root_events']),recursive_live_globals=True,scope='Positive winning candidates, if any, require Core independent goal replay; absence means retaining a completedwinning child cannot help the observed capped iteration. This observer changes no product source.'))
