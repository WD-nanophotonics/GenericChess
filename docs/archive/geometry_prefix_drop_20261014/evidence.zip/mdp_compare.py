from pathlib import Path
import sys,time,json,random,hashlib
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.core.position import count_entities
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import MATE_THRESHOLD,MAX_STATIC_EVAL
out=D/'mdp-curve';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does the already implemented MDP change useful delivered decisions/work on knownH3 and prospective generated roots once total score range is explicit?',drop_sizes=[4,12,18,24],generated_seeds=[2026102040,2026102041,2026102042,2026102043],generated_sizes=[8,12,18,24],prefix=8,rng_offset=31000,q=2,hardq=8,depth=12,seconds=16,orders=2,planned_calls=32,expected_minutes=9,fuse_seconds=1000,scope='Exact same bounded productsource and evaluator per arm, fresh player/TT, preparation charged. Only existingMDP flag differs; no default change. Mechanism roots exposed; generated seeds fixed before any query, no unavailable replacement. Bounds use actor conservation in actual legacy lowered effects, all type/promotion prices and area-bounded dynamic terms, not visited maxima. Score-band fix intentionally separates raw evaluator from bounded search utility.',source_sha256=hashlib.sha256((ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()).hexdigest()))
roots=[];samples=[];unavailable=[]
for cohort,seed,size in [('drop',None,n) for n in (4,12,18,24)]+[('generated',seed,n) for seed,n in zip(range(2026102040,2026102044),(8,12,18,24))]:
 p.rr.stopped();walk=[]
 if cohort=='drop':rules,c,s=make(size);name=f'drop-{size}'
 else:
  game=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));rules=game.ruleset
  cc=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support)
  s=p.GameSession(c);rng=random.Random(seed+31000);name=f'generated-{seed}'
  for _ in range(8):
   acts=sorted(s.legal_actions(),key=repr)
   if not acts or s.result.status.value!='ongoing':break
   a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
  if len(walk)!=8 or s.result.status.value!='ongoing':
   unavailable.append(dict(root=name,size=size,reason='declared8ply prefix unavailable',resampled=False));continue
 ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
 flows=set()
 for pattern in c.ir.patterns:
  kinds=tuple(e.kind for e in pattern.effects);flows.add(kinds)
  assert kinds in (('move',),('remove','move'),('remove_from_hand','place')),kinds
  assert pattern.pattern_id.startswith('legacy_') and pattern.promotion_mode in ('none','inherit_compiled_masks')
  if kinds==('remove','move'):assert pattern.effects[0].disposition in ('capture_to_hand','destroy')
  if kinds==('remove_from_hand','place'):
   a,b=pattern.effects;assert a.count==b.count==1 and a.piece_type_ref==b.piece_type_ref and a.piece_owner==b.piece_owner
 entities=count_entities(s.state.position);price=max([0,*profile.board_value_by_type.values(),*profile.hand_value_by_base_type.values()]);gain=max([0,*profile.promotion_gain_by_type.values()])
 promo=abs(ec.promotion_potential_weight)*max(1,gain//1000) if gain>0 else 0
 bound=entities*(price+promo)+size*size*abs(ec.dynamic_mobility_weight)+(size*size+10)*abs(ec.anchor_escape_weight)
 assert bound<MAX_STATIC_EVAL<MATE_THRESHOLD
 samples.append(dict(root=name,cohort=cohort,size=size,seed=seed,ruleset=json.loads(p.serialize_ruleset(rules)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),walk=walk,config=record_value(ec),profile=record_value(profile),utility_bound=dict(root_entities=entities,max_piece_or_hand_price=price,max_per_actor_promotion_bonus=promo,area=size*size,raw_total_absolute_bound=bound,flow_kinds=sorted(flows),assumption='Every actual lowered pattern conserves actors or destroys one; promotion retypes only. Inventory bound starts at actual declared root, not initial metadata. No external override or arbitrary semantic creation claim.')))
 roots.append((name,cohort,size,c,s,ev))
write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable))
rows=[];start=time.perf_counter()
try:
 for name,cohort,size,c,s,ev in roots:
  before=(s.state,s.to_record(),s._search_witnesses)
  for rep in range(2):
   for mdp in ((False,True) if rep==0 else (True,False)):
    p.rr.stopped();assert time.perf_counter()-start<1000;t=time.perf_counter()
    player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev,tuning=SearchTuning(use_mate_distance_pruning=mdp))
    prep=time.perf_counter()-t
    d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=max(.001,16-prep),quiescence_max_depth=2,quiescence_hard_max_depth=8));total=time.perf_counter()-t
    assert before==(s.state,s.to_record(),s._search_witnesses)
    child=s.state
    for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
    rows.append(dict(root=name,cohort=cohort,size=size,rep=rep,mdp=mdp,prepare_seconds=prep,total=total,action=record_value(d.action),decision=record_value(d),full_history_restored=True,pv_core_legal=True))
    write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
    print(name,rep,mdp,round(total,4),d.completed_depth,d.result_ordinary_qdepth,d.mate_pruning_cutoffs,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
except BaseException as exc:
 write_record(out/'failure.json',dict(error_type=type(exc).__name__,error=str(exc),saved_calls=len(rows),elapsed_seconds=time.perf_counter()-start));raise
