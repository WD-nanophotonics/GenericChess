from pathlib import Path
import sys,json,time,ast,hashlib
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import search as sm,player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'root-reserve-curve';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
before=(D/'search-before-root-reserve.py').read_bytes();after=(ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()
write_record(out/'declaration.json',dict(question='Does retaining only a completed winning root child recover the already proved H3 goal at the same capped budget?',cases=[dict(size=18,q=4),dict(size=24,q=2)],seconds=16,orders=2,planned_calls=8,expected_minutes=3,max_depth=12,scope='Old bounded source vs completed-win retention; exact live globals, same Core/evaluator/TT/budgets and preserved actual abort reason. No crosspolicy score comparison or claiming an interrupted main iteration complete. Existing independent H3 certificates are reused only after exact root/rules/witness match; no on-disk rollback.',before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest()))
fns=[n for n in ast.parse(before).body if isinstance(n,ast.FunctionDef) and n.name in ('negamax','run_root_search')];assert len(fns)==2;scope={}
exec(compile(ast.fix_missing_locations(ast.Module(body=fns,type_ignores=[])),'<before-root-reserve>','exec'),sm.__dict__,scope)
new_negamax,new_root=sm.negamax,pm.run_root_search
samples=json.loads((D/'drop-curve/samples.json').read_text());labels=json.loads((D/'selected-goal/rows.json').read_text())['answers']
rows=[];start=time.perf_counter()
try:
 for size,q in ((18,4),(24,2)):
  _,c,s=make(size);sample=next(x for x in samples if x['size']==size)
  assert sample['state']==record_value(s.state) and sample['witnesses']==record_value(s._search_witnesses)
  cfg=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg);snapshot=(s.state,s.to_record(),s._search_witnesses)
  for rep in range(2):
   for arm in (('before','after') if rep==0 else ('after','before')):
    p.rr.stopped();assert time.perf_counter()-start<240
    sm.negamax=scope['negamax'] if arm=='before' else new_negamax
    pm.run_root_search=scope['run_root_search'] if arm=='before' else new_root
    t=time.perf_counter();player=AlphaBetaPlayer(c,evaluator_override=ev,use_disk_cache=False,use_native_semantic_legality=False);prep=time.perf_counter()-t
    decision=player.choose_action(s,SearchLimits(max_depth=12,max_time_seconds=max(.001,16-prep),quiescence_max_depth=q,quiescence_hard_max_depth=8))
    total=time.perf_counter()-t;assert snapshot==(s.state,s.to_record(),s._search_witnesses)
    child=s.state
    for a in decision.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
    action=record_value(decision.action);certificate=next(x for x in labels if x['size']==size and x['action']==action)
    rows.append(dict(size=size,q=q,rep=rep,arm=arm,prepare_seconds=prep,total=total,decision=record_value(decision),rootH3_goal=certificate['forces_root_win_H3'],independent_certificate_file='selected-goal/rows.json',full_history_restored=True,pv_core_legal=True))
    write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
    print(size,q,rep,arm,round(total,3),decision.result_source,decision.completed_depth,decision.termination_reason,rows[-1]['rootH3_goal'],flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
finally:sm.negamax=new_negamax;pm.run_root_search=new_root
assert all(r['rootH3_goal']==(r['arm']=='after') for r in rows)
assert all(r['decision']['termination_reason']=='time_limit' and r['decision']['completed_depth']==1 for r in rows)
