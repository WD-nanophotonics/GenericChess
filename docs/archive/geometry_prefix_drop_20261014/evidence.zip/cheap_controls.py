from pathlib import Path
import sys,json,time
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
out=D/'cheap-controls';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does this finite goal require search, or would an already installed cheap fallback/D1 already select a goal-winning action?',sizes=[4,12,18,24],arms=['first_child_fallback','complete_root_scan','static_D1'],q=0,planned_calls=12,seconds=60,scope='Adaptive mechanism control, no modifications to frozen64call q curve. No special tactical helper; existing public entry under explicit limits. Independent selectedaction rootH3 goal applied later; same metadata/evaluator/Core/history. No quality inference from score or arbitrary PV match.'))
rows=[];start=time.perf_counter()
for size in (4,12,18,24):
 _,c,s=make(size);before=(s.state,s.to_record(),s._search_witnesses);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec);root_count=len(s.legal_actions())
 for arm in ('first_child_fallback','complete_root_scan','static_D1'):
  p.rr.stopped();limits=SearchLimits(max_depth=1 if arm=='static_D1' else 12,max_nodes=1 if arm=='first_child_fallback' else root_count+1 if arm=='complete_root_scan' else 1000000,max_time_seconds=60,quiescence_max_depth=0,quiescence_hard_max_depth=8)
  t=time.perf_counter();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);d=player.choose_action(s,limits)
  assert before==(s.state,s.to_record(),s._search_witnesses)
  if arm!='static_D1':assert d.completed_depth==0 and d.root_scan_used_fallback
  rows.append(dict(size=size,arm=arm,root_legal_count=root_count,limits=record_value(limits),total=time.perf_counter()-t,action=record_value(d.action),decision=record_value(d),full_history_restored=True))
  write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
  print(size,arm,round(rows[-1]['total'],4),d.result_source,d.root_scan_nodes,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
