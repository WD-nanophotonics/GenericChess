from pathlib import Path
import sys,time,json,hashlib
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
out=D/'drop-curve';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='When a preexisting quiet checking drop H3 goal is preserved but board/drop branching grows, which actual delivered q0/q1/q2/q4 actions retain that goal under common endtoend16/64seconds?',sizes=[4,12,18,24],q=[0,1,2,4],seconds=[16,64],orders=2,hardq=8,depth=12,planned_calls=64,expected_minutes=44,fuse_seconds=3300,scope='Mechanism comparison constructed from existing4board fixture by fixed local horizontal reflection anchored to files0..3 then extending board. Not blind strength/generic-domain completion or label fitting. Reference actions independently proved before searches; all selectedactions get same rootH3 test afterward, no referencePV equality. Complete compiledCore/hands/history retained; static profile perrules, fresh players/TT, incrementalplayerprep charged. No cachecandidate/default/product or native changes. Ordinary concurrent load.',source_sha256=hashlib.sha256((ROOT/'generic_chess/ai/alphabeta/search.py').read_bytes()).hexdigest()))
rows=[];samples=[];start=time.perf_counter()
try:
 for size in (4,12,18,24):
  rules,c,s=make(size);before=(s.state,s.to_record(),s._search_witnesses)
  ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
  samples.append(dict(size=size,ruleset=json.loads(p.serialize_ruleset(rules)),state=record_value(s.state),witnesses=record_value(s._search_witnesses),evaluation_config=record_value(ec),profile=record_value(profile),legal_count=len(s.legal_actions())))
  write_record(out/'samples.json',samples)
  reference=json.loads((D/'drop-reference/rows.json').read_text(encoding='utf-8'))
  refs=[r for r in reference['rows'] if r['size']==size]
  assert len(refs)==4 and all(r['forces_root_win_H3'] for r in refs)
  for seconds in (16,64):
   for rep in range(2):
    for q in ((0,1,2,4) if rep==0 else (4,2,1,0)):
     p.rr.stopped();assert time.perf_counter()-start<3300
     t=time.perf_counter();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);prep=time.perf_counter()-t
     d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=max(.001,seconds-prep),quiescence_max_depth=q,quiescence_hard_max_depth=8))
     total=time.perf_counter()-t;assert before==(s.state,s.to_record(),s._search_witnesses)
     child=s.state
     for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
     rows.append(dict(size=size,seconds=seconds,rep=rep,q=q,prep_seconds=prep,total=total,decision=record_value(d),full_history_restored=True,pv_core_legal=True))
     write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
     print(size,seconds,rep,q,round(total,3),d.completed_depth,d.result_ordinary_qdepth,d.termination_reason,flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
except BaseException as exc:
 write_record(out/'failure.json',dict(error_type=type(exc).__name__,error=str(exc),saved_calls=len(rows),elapsed_seconds=time.perf_counter()-start));raise
