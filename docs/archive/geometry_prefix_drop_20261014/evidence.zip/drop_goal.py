from pathlib import Path
import sys,time,json
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from conftest import make_ruleset,parse_lines,king_type,T
from generic_chess.core.movement import RayAtom
from generic_chess.core.position import Hands,HistoryRecord
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/geometry-prefix-20261014/drop-goal';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does the existing quiet checking drop fixture provide an independent rootH3 winning-goal comparison for delivered q policies?',root_source='tests/product/test_qsearch_correctness.py::test_quiet_check_can_force_mate_after_either_defense',rows=['....','R...','....','K.k.'],hands=[[['R',1]],[]],attacker=0,root_halfmoves=3,limits=dict(seconds=120,apply_calls=100000),scope='Existing mechanism fixture, not unseen strength. Full root action union independently labelled before compared searches; all legal defenses incl drops. No material/search scores in label; no required universal WDL. Root has declared one-position exact history, not an invented played prefix.'))
rules=make_ruleset(4,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1)),RayAtom((1,0)),RayAtom((-1,0)))],lines=['....','R...','....','K.k.'])
cc=p.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support)
s=p.GameSession(c);pos=replace(s.state.position,hands=(Hands((('R',1),)),Hands()))
key=position_identity_key(pos,c);st=replace(s.state,position=pos,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),));st=replace(st,terminal_status=terminal_result(st,c));s._state=st;s._search_history_witnesses=(pos,)
assert not st.terminal_status.is_terminal and not getattr(c,'declarations',())
write_record(out/'sample.json',dict(ruleset=json.loads(p.serialize_ruleset(rules)),state=record_value(st),witnesses=record_value(s._search_witnesses)))
start=time.perf_counter();count=0
class Limited(Exception):pass
def apply(state,a):
 global count
 p.rr.stopped()
 if count>=100000 or time.perf_counter()-start>=120:raise Limited()
 count+=1;return apply_action(state,a,c)
def prove(state,h):
 if state.terminal_status.is_terminal:return state.terminal_status.winner==0,dict(terminal=record_value(state.terminal_status))
 if h==0:return False,dict(frontier=True)
 acts=tuple(legal_actions(state,c));assert acts;attack=state.position.side_to_move==0;edges=[]
 for a in acts:
  value,proof=prove(apply(state,a),h-1);edge=dict(action=record_value(a),proof=proof)
  if attack and value:return True,dict(attacker_choice=edge)
  if not attack and not value:return False,dict(defender_counterexample=edge)
  edges.append(edge)
 return (False,dict(all_attacker_actions_fail=edges)) if attack else (True,dict(all_defender_actions_win=edges))
answers=[]
for a in s.legal_actions():
 try:
  value,proof=prove(apply(st,a),2);answers.append(dict(action=record_value(a),forces_root_win_H3=value,proof=proof))
 except Limited:
  answers.append(dict(action=record_value(a),forces_root_win_H3=None,unknown=True))
 write_record(out/'proof.json',dict(complete=False,answers=answers,apply_calls=count,seconds=time.perf_counter()-start))
write_record(out/'proof.json',dict(complete=True,answers=answers,apply_calls=count,seconds=time.perf_counter()-start))
print('root actions',len(answers),'wins',sum(a['forces_root_win_H3'] is True for a in answers),'unknown',sum(a['forces_root_win_H3'] is None for a in answers),'transitions',count,'seconds',time.perf_counter()-start)
