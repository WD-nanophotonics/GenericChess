from pathlib import Path
import sys,json,time
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'selected-goal';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
curve=json.loads((D/'drop-curve/rows.json').read_text());bridge=json.loads((D/'minimal-bridge/rows.json').read_text())
cheap=json.loads((D/'cheap-controls/rows.json').read_text())
mdp=json.loads((D/'mdp-curve/rows.json').read_text());assert mdp['complete']
mdp_drop=[r for r in mdp['rows'] if r['cohort']=='drop'];assert len(mdp_drop)==16
assert curve['complete'] and len(curve['rows'])==64 and bridge['complete'] and len(bridge['rows'])==16 and cheap['complete'] and len(cheap['rows'])==12
write_record(out/'declaration.json',dict(question='Do actual returned actions retain the predeclared rootH3 winning goal?',source_calls=108,rootH=3,remaining_after_selected=2,max_apply=250000,seconds=300,scope='Union of all actions from completed fixed comparisons; independent Core terminal goal, not searched scores/depth or referencePV matching. No budget expansion, unknown stays unknown. Distinct tied winning moves allpass. No broader loss/globalstrength label.'))
samples=json.loads((D/'drop-curve/samples.json').read_text())
targets={}
for row in curve['rows']+bridge['rows']+cheap['rows']+mdp_drop:
 action=row.get('action',row['decision'].get('action'))
 targets[(row['size'],json.dumps(action,sort_keys=True))]=action
start=time.perf_counter();count=0;answers=[]
class Limited(Exception):pass
def perform(state,a,c):
 global count
 p.rr.stopped()
 if count>=250000 or time.perf_counter()-start>=300:raise Limited()
 count+=1;return apply_action(state,a,c)
def prove(state,h,c):
 if state.terminal_status.is_terminal:return state.terminal_status.winner==0,dict(terminal=record_value(state.terminal_status))
 if h==0:return False,dict(frontier=True)
 acts=tuple(legal_actions(state,c));assert acts;attacking=state.position.side_to_move==0;edges=[]
 for a in acts:
  value,proof=prove(perform(state,a,c),h-1,c);edge=dict(action=record_value(a),proof=proof)
  if attacking and value:return True,dict(attacker_choice=edge)
  if not attacking and not value:return False,dict(defender_counterexample=edge)
  edges.append(edge)
 return (False,dict(all_attacker_actions_fail=edges)) if attacking else (True,dict(all_defender_actions_win=edges))
for (size,encoded),record in targets.items():
 if record is None:
  answers.append(dict(size=size,action=None,forces_root_win_H3=None,no_returned_action=True));continue
 _,c,s=make(size);sample=next(x for x in samples if x['size']==size)
 assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses']
 action=next(a for a in s.legal_actions() if record_value(a)==record)
 try:value,proof=prove(perform(s.state,action,c),2,c);answer=dict(size=size,action=record,forces_root_win_H3=value,proof=proof)
 except Limited:answer=dict(size=size,action=record,forces_root_win_H3=None,unknown=True)
 answers.append(answer);write_record(out/'rows.json',dict(complete=False,answers=answers,apply_calls=count,elapsed_seconds=time.perf_counter()-start))
 print(size,record,answer['forces_root_win_H3'],count,flush=True)
write_record(out/'rows.json',dict(complete=True,answers=answers,apply_calls=count,elapsed_seconds=time.perf_counter()-start))
# Separate proof consumer, independent recursion over saved certificate shape.
visited=0;replays=0
def consume(state,h,proof,c):
 global visited,replays
 visited+=1
 if 'terminal' in proof:
  assert state.terminal_status.is_terminal and record_value(state.terminal_status)==proof['terminal']
  return state.terminal_status.winner==0
 assert not state.terminal_status.is_terminal
 if 'frontier' in proof:assert h==0;return False
 assert h>0
 acts=tuple(legal_actions(state,c));by={json.dumps(record_value(a),sort_keys=True):a for a in acts};attack=state.position.side_to_move==0
 if 'attacker_choice' in proof:assert attack;edges=[proof['attacker_choice']];expected=True
 elif 'defender_counterexample' in proof:assert not attack;edges=[proof['defender_counterexample']];expected=False
 else:
  name='all_attacker_actions_fail' if attack else 'all_defender_actions_win';edges=proof[name]
  assert [json.dumps(e['action'],sort_keys=True) for e in edges]==list(by);expected=not attack
 for e in edges:
  a=by[json.dumps(e['action'],sort_keys=True)];replays+=1
  assert consume(apply_action(state,a,c),h-1,e['proof'],c)==expected
 return expected
for answer in answers:
 if answer['forces_root_win_H3'] is None:continue
 _,c,s=make(answer['size']);a=next(a for a in s.legal_actions() if record_value(a)==answer['action']);replays+=1
 assert consume(apply_action(s.state,a,c),2,answer['proof'],c)==answer['forces_root_win_H3']
write_record(out/'verification.json',dict(complete=True,proof_nodes=visited,replay_transitions=replays,unique_actions=len(answers),unknown=sum(a['forces_root_win_H3'] is None for a in answers)))
labels={(a['size'],json.dumps(a['action'],sort_keys=True)):a['forces_root_win_H3'] for a in answers}
summaries=[]
for n in (4,12,18,24):
 for seconds in (16,64):
  for q in (0,1,2,4):
   group=[r for r in curve['rows'] if r['size']==n and r['seconds']==seconds and r['q']==q];assert len(group)==2
   summaries.append(dict(size=n,seconds=seconds,q=q,rootH3_wins=[labels[(n,json.dumps(r['decision']['action'],sort_keys=True))] for r in group],depths=[r['decision']['completed_depth'] for r in group],effective_q=[r['decision']['result_ordinary_qdepth'] for r in group],sources=[r['decision']['result_source'] for r in group],runtime_pushes=[r['decision']['runtime_pushes'] for r in group],runtime_balanced=all(r['decision']['runtime_depth_balanced'] is True for r in group),actions_equal=group[0]['decision']['action']==group[1]['decision']['action']))
write_record(out/'summary.json',dict(curve=summaries,bridge=[dict(size=r['size'],arm=r['arm'],rep=r['rep'],goal=labels[(r['size'],json.dumps(r['action'],sort_keys=True))],total=r['total'],decision=r['decision']) for r in bridge['rows']],mdp_drop=[dict(root=r['root'],size=r['size'],mdp=r['mdp'],rep=r['rep'],goal=labels[(r['size'],json.dumps(r['action'],sort_keys=True))],total=r['total'],decision=r['decision']) for r in mdp_drop],cheap_controls=[dict(size=r['size'],arm=r['arm'],goal=labels[(r['size'],json.dumps(r['action'],sort_keys=True))],total=r['total'],decision=r['decision']) for r in cheap['rows']],scope='RootH3 finite objective only; no score/depth-derived labels; all original decisions retained.'))
