from pathlib import Path
import sys,time,json
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.search_backend_comparison import CoreBoard,minimal_ab
from scripts.research_record import record_value,write_record
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
out=D/'minimal-bridge';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does the existing minimal AB already solve the same H3 goal with matched Core/evaluator, isolating search scheduling/order/TT overhead from rule execution?',sizes=[4,12,18,24],depth=3,q=0,orders=2,arms=['minimal','supported'],seconds=120,max_nodes=1000000,planned_calls=16,expected_minutes=8,fuse_seconds=2700,scope='Existing minimal_ab reused; both full Core runtime and exact same generic-v2 evaluator. Minimal lexical/noTT vs supported ordering/TT/iterative/root scan are algorithm differences, not backend changes. FixedD3 task, actual work not assumed equal; timeout remains incomplete. Compared after own resource curve closes; ordinary otherproject concurrency remains. No new search framework/default/price fit.'))
class Board(CoreBoard):
 def __init__(self,c,s,ev):
  self.compiled=c;self.initial=s.state;self.witnesses=s._search_witnesses
  self.runtime=SearchPathRuntime.from_state(s.state,c,history_witnesses=self.witnesses)
  self.material=ev;self.label=lambda a:json.dumps(record_value(a),sort_keys=True,separators=(',',':'));self.checkpoint=None
rows=[];start=time.perf_counter()
try:
 for size in (4,12,18,24):
  _,c,s=make(size);before=(s.state,s.to_record(),s._search_witnesses)
  ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
  for rep in range(2):
   for arm in (('minimal','supported') if rep==0 else ('supported','minimal')):
    p.rr.stopped();assert time.perf_counter()-start<2700;t=time.perf_counter()
    if arm=='minimal':
     board=Board(c,s,ev);snapshot=p.runtime_state(board.runtime);prep=time.perf_counter()-t
     d=minimal_ab(board,3,seconds=120,node_limit=1000000,cooperative=True)
     assert p.runtime_state(board.runtime)==snapshot;board.runtime.assert_balanced()
     action=None if d['move'] is None else json.loads(d['move'])
    else:
     player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);prep=time.perf_counter()-t
     answer=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=120,quiescence_max_depth=0,quiescence_hard_max_depth=8))
     d=record_value(answer);action=record_value(answer.action)
    assert before==(s.state,s.to_record(),s._search_witnesses)
    rows.append(dict(size=size,rep=rep,arm=arm,prep_seconds=prep,total=time.perf_counter()-t,action=action,decision=d,full_history_restored=True))
    write_record(out/'rows.json',dict(complete=False,rows=rows,elapsed_seconds=time.perf_counter()-start))
    print(size,rep,arm,round(rows[-1]['total'],4),d['score'],d.get('termination_reason',d.get('reason')),flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
except BaseException as exc:
 write_record(out/'failure.json',dict(error_type=type(exc).__name__,error=str(exc),saved_calls=len(rows),elapsed_seconds=time.perf_counter()-start));raise
