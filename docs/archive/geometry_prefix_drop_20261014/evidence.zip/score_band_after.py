from pathlib import Path
import sys,json,time
ROOT=Path.cwd();D=ROOT/'.local_agent/geometry-prefix-20261014';sys.path[:0]=[str(D),str(ROOT)]
from drop_fixture import make,p
from scripts.research_record import record_value,write_record
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import MATE_SCORE,MATE_THRESHOLD
out=D/'score-band-after';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Is per-piece MAX_STATIC_EVAL a sufficient condition for MDP numeric equivalence?',size=4,depth=1,q=0,tt=False,ordering=False,pvs=False,root_tactical=False,planned_calls=8,scope='Concrete numeric contract stress, not evidence that default q2 cohorts fail. Full legal Core frontier retained. Four override two-action-score controls and four actual standard/stress EvaluationConfig calls; other moves are not filtered. No product config/default change.'))
_,c,s=make(4);acts=sorted(s.legal_actions(),key=str);children=[apply_action(s.state,a,c) for a in acts]
assert all(not child.terminal_status.is_terminal for child in children)
before=(s.state,s.to_record(),s._search_witnesses)
class Override:
 def __init__(self,large):self.large=large
 def evaluate(self,state):
  if state.position==children[0].position:return -(MATE_SCORE+10 if self.large else 10)
  if state.position==children[1].position:return -(MATE_SCORE+20 if self.large else 20)
  return 0
configs=[('override_small',Override(False)),('override_large',Override(True))]
for name,cfg in [('default',p.EvaluationConfig()),('large_dynamic',p.EvaluationConfig(dynamic_mobility_weight=1000000000,anchor_escape_weight=0,promotion_potential_weight=0))]:
 configs.append((name,p.Evaluator(c,p.build_ruleset_profile(c,cfg),cfg)))
rows=[]
for name,ev in configs:
 values=[-ev.evaluate(child) for child in children];best=max(values);reference=acts[values.index(best)]
 for enabled in (False,True):
  p.rr.stopped()
  tuning=SearchTuning(use_mate_distance_pruning=enabled,use_root_tactical=False)
  d=AlphaBetaPlayer(c,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=tuning,evaluator_override=ev).choose_action(s,SearchLimits(max_depth=1,max_nodes=100000,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=8))
  assert before==(s.state,s.to_record(),s._search_witnesses)
  assert d.completed_depth==1
  rows.append(dict(evaluator=name,mdp=enabled,full_frontier_size=len(acts),full_frontier_scores=values,reference=record_value(reference),expected_max_static=best,selected_actual_static=values[acts.index(d.action)],decision=record_value(d),full_history_restored=True))
  print(name,enabled,d.score,values[acts.index(d.action)],'max',best,'beta_cutoffs',d.beta_cutoffs,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,mate_threshold=MATE_THRESHOLD,scope='No default-state failure asserted. Actual accepted high dynamic configuration and explicit override show why unrestricted numeric utility is outside MDP distance assumptions.'))
for name in ('override_small','default'):
 group=[r for r in rows if r['evaluator']==name];assert all(r['selected_actual_static']==r['expected_max_static'] for r in group)
from generic_chess.ai.evaluation.config import MAX_STATIC_EVAL
for row in rows:
 assert row['decision']['score']==max(max(-MAX_STATIC_EVAL,min(MAX_STATIC_EVAL,v)) for v in row['full_frontier_scores'])
for name in ('override_small','override_large','default','large_dynamic'):
 group=[r for r in rows if r['evaluator']==name];assert group[0]['decision']['action']==group[1]['decision']['action']
print('all completed root utilities agree after explicit search saturation; raw values preserved')
