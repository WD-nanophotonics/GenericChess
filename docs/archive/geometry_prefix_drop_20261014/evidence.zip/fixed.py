from pathlib import Path
import sys,time,json,random,functools
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core import semantic_executor as se
from generic_chess.rules.ir import geometry_candidates
out=ROOT/'.local_agent/geometry-prefix-20261014/fixed';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does avoiding static prefix allocation survive whole Core q2 caller cost including preparation?',seeds=[2026102016,2026102017,2026102018],sizes=[12,18,24],nodes=4096,q=2,seconds=120,arms=['baseline','content_lru','eager'],orders=2,planned_calls=18,expected_minutes=3,scope='Exposed development; exact immutable compiled path derivation only. No state/result cache. Fresh player/TT; cache cleared or newly prepared for each call, preparation charged. Same nodes/stop/evaluator/history. Ordinary concurrency.'))
@functools.lru_cache(maxsize=4096)
def prefixes(kind,start,path):
 if kind=='leap':return ((path[0],()),) if path else ()
 return tuple((path[i],path[:i]) for i in range(start,len(path)))
def content_lru(g,owner,source):
 path=g.paths.get(owner,{}).get(source,())
 if len(path)>32:return geometry_candidates(g,owner,source)
 return prefixes(g.kind,max(0,(g.min_steps or 1)-1),path)
def bytes_unique(values):
 seen=set()
 def visit(v):
  if id(v) in seen:return 0
  seen.add(id(v));n=sys.getsizeof(v)
  if isinstance(v,dict):n+=sum(visit(k)+visit(x) for k,x in v.items())
  elif isinstance(v,(tuple,list)):n+=sum(visit(x) for x in v)
  return n
 return visit(values)
rows=[];start=time.perf_counter()
for seed,size in zip([2026102016,2026102017,2026102018],[12,18,24]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
 c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support)
 s=p.GameSession(c);rng=random.Random(seed+31000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
 write_record(out/f'sample-{size}.json',dict(ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),witnesses=record_value(s._search_witnesses)))
 before=(s.state,s.to_record(),s._search_witnesses)
 # All compiled endpoints including empty and absent lookup semantics.
 checks=0
 for geo in c.ir.geometry.values():
  for owner,mapping in geo.paths.items():
   for source in mapping:
    assert content_lru(geo,owner,source)==geometry_candidates(geo,owner,source);checks+=1
 for rep in range(2):
  for arm in (('baseline','content_lru','eager') if rep==0 else ('eager','content_lru','baseline')):
   p.rr.stopped();prefixes.cache_clear();t=time.perf_counter();table={}
   if arm=='eager':
    for geo in c.ir.geometry.values():
     for owner,mapping in geo.paths.items():
      table[(id(geo),owner)]={source:geometry_candidates(geo,owner,source) for source in mapping}
   def eager(geo,owner,source):return table.get((id(geo),owner),{}).get(source,())
   player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
   prep=time.perf_counter()-t;original=se.geometry_candidates
   try:
    if arm!='baseline':se.geometry_candidates=content_lru if arm=='content_lru' else eager
    t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=8,max_nodes=4096,max_time_seconds=120,quiescence_max_depth=2,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
   finally:se.geometry_candidates=original
   assert before==(s.state,s.to_record(),s._search_witnesses)
   row=dict(seed=seed,size=size,rep=rep,arm=arm,prepare_seconds=prep,wall=wall,total=prep+wall,decision=record_value(d),all_endpoint_checks=checks,eager_bytes=bytes_unique(table),cache_info=record_value(prefixes.cache_info()),history_restored=True)
   rows.append(row);write_record(out/'rows.json',dict(complete=False,rows=rows))
   print(size,rep,arm,round(prep+wall,6),d.nodes,d.qnodes,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
keys=('action','score','principal_variation','nodes','qnodes','completed_depth','result_ordinary_qdepth','search_runtime_pushes','search_runtime_pops')
for size in (12,18,24):
 group=[r for r in rows if r['size']==size];base=group[0]['decision']
 for r in group:
  for key in keys:
   if key in base:assert base[key]==r['decision'][key],(size,r['arm'],key)
print('EXACT matched fixedwork')
