from pathlib import Path
import json,statistics
D=Path('.local_agent/geometry-prefix-20261014')
probe=json.loads((D/'rows.json').read_text());fixed=json.loads((D/'fixed/rows.json').read_text())
assert probe['complete'] and fixed['complete']
excluded={'elapsed_seconds','time_to_first_legal_action','time_to_first_completed_iteration','ordering_seconds','legal_generation_seconds','evaluation_seconds'}
def norm(d):return {k:v for k,v in d.items() if k not in excluded}
assert norm(probe['rows'][0]['decision'])==norm(probe['rows'][1]['decision'])
answers=[]
for n in (12,18,24):
 group=[r for r in fixed['rows'] if r['size']==n];base=norm(group[0]['decision'])
 assert len(group)==6 and all(norm(r['decision'])==base for r in group)
 summaries=[]
 for arm in ('baseline','content_lru','eager'):
  chosen=[r for r in group if r['arm']==arm]
  summaries.append(dict(arm=arm,total_seconds=[r['total'] for r in chosen],prepare_seconds=[r['prepare_seconds'] for r in chosen],eager_value_bytes=chosen[0]['eager_bytes'],all_endpoint_checks=chosen[0]['all_endpoint_checks'],cache_info=[r['cache_info'] for r in chosen]))
 baseline=statistics.mean(r['total'] for r in group if r['arm']=='baseline')
 for x in summaries:x['mean_total_ratio_to_baseline']=statistics.mean(x['total_seconds'])/baseline
 answers.append(dict(size=n,arms=summaries,all_nontiming_fields_equal=True,runtime_pushes=base['runtime_pushes'],runtime_pops=base['runtime_pops']))
summary=dict(probe=probe['counters'],fixed_work=answers,elapsed_seconds=fixed['elapsed_seconds'],excluded_timing_fields=sorted(excluded),decision='DEFER both private candidates: small/mixed fullcaller costs; eager memory/startup does not justify product state/schema changes; no equal-time curve from this lever.',scope='Finite exposed generated cohort; counterbalanced order, ordinary concurrency, not strength or independent holdout. Eager bytes measured unique reachable Python object graph, not RSS.')
(D/'geometry-summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(answers,indent=2))
