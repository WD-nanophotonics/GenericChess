"""Per-child representation attribution; no cached or changed child result."""
import sys,time,importlib.util
from pathlib import Path
from collections import Counter
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('qc',B/'q_execution_counts.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
r=c.rtmod;T=r.SearchPathRuntime;push=T._push_impl;pop=T.pop;hashfn=r._semantic_component_diff_hash;snap=r.RuntimeCountsSnapshot.updated;hist=r.RuntimeHistoryContext.append;classify=c.noisy
stack=[];pending={};totals=Counter();peak=0
def stage(name,fn):
 def call(*a,**kw):
  t=time.perf_counter()
  try:return fn(*a,**kw)
  finally:
   if stack:stack[-1][name+'_calls']+=1;stack[-1][name+'_inclusive_seconds']+=time.perf_counter()-t
 return call
def pushed(self,*a,**kw):
 global peak
 values=Counter();stack.append(values)
 try:out=push(self,*a,**kw)
 finally:stack.pop()
 pending[id(self._frames[-1])]=(c.iteration,bool(c.qlevel),values);peak=max(peak,len(pending));return out
def consume(frame,outcome):
 data=pending.pop(id(frame),None)
 if data is None:return
 iteration,qphase,values=data;totals[(iteration,qphase,outcome,'children')]+=1
 for k,v in values.items():totals[(iteration,qphase,outcome,k)]+=v
def classified(action,child,*a,**kw):
 result=classify(action,child,*a,**kw);consume(child._runtime._frames[-1],'included' if result else 'excluded');return result
def popped(self,*a,**kw):
 if self._frames:consume(self._frames[-1],'unclassified')
 return pop(self,*a,**kw)
def install(active):
 T._push_impl=pushed if active else push;T.pop=popped if active else pop;r._semantic_component_diff_hash=stage('component_diff',hashfn) if active else hashfn;r.RuntimeCountsSnapshot.updated=stage('count_snapshot',snap) if active else snap;r.RuntimeHistoryContext.append=staticmethod(stage('history_context',hist) if active else hist)
 c.sm.negamax=c.negamax if active else c.ng;c.sm._quiescence_runtime=c.quiescence if active else c.q;c.sm.noisy_child=classified if active else classify
def main():
 global stack,pending,totals,peak
 start=time.perf_counter();out=dict(complete=False,declared=dict(root='chess-middle',max_depth=2,max_nodes=32768,max_seconds=30,q=4,hard=8,orders=2,fuse=180),scope='Per-formal-child representation stages grouped by actual quiet classifier outcome, removed on pop; no child cache/reuse. Inclusive timings for distinct selected stages, not complete push cost or predicted speed. Unclassified includes main/checked traversal. Plain/instrumented fixed-work pairs agree.',rows=[])
 compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess'));board=c.CoreBoard(c.CASES[0],compiled);e=c.cm.w.weighted(compiled,c.VALUES['chess'])
 for order in range(2):
  pair=[]
  for measured in ((False,True) if order==0 else (True,False)):
   stack=[];pending={};totals=Counter();peak=0;c.iteration=c.qlevel=0;c.counts=Counter();install(measured);s=c.GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;t=time.perf_counter()
   try:d=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,c.SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   finally:install(False)
   assert not stack and not pending and s.state is board.initial and d.completed_depth==2;v=c.record_value(d);pair.append(c.cm.clean(v));out['rows'].append(dict(order=order,measured=measured,wall=time.perf_counter()-t,decision=v,peak_pending_children=peak,stages=[dict(iteration=i,qphase=q,outcome=o,metric=k,value=v) for (i,q,o,k),v in sorted(totals.items())]))
  assert pair[0]==pair[1];c.write_record(B/'representation-outcome.json',out);print(order,'exact',flush=True);c.stopped();assert time.perf_counter()-start<180
 out['complete']=True;out['seconds']=time.perf_counter()-start;c.write_record(B/'representation-outcome.json',out)
if __name__=='__main__':main()
