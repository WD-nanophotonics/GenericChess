from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/admission-reuse-20261015';seed=int(sys.argv[1]);arm=sys.argv[2];order=int(sys.argv[3])
from generic_chess.ai.evaluation import movement_graph as mg
source=B/f'movement-graph-{arm}.py';exec(compile(source.read_bytes(),str(source),'exec'),mg.__dict__)
from generic_chess.ai.evaluation import analyzer
analyzer.graph_metrics=mg.graph_metrics
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import deserialize_ruleset
from scripts.research_record import record_value
x=json.loads((B/'transfer-inputs'/f'{seed}.json').read_bytes());r=deserialize_ruleset(json.dumps(x['ruleset']));compiled=compile_legacy_ruleset_for_semantic_execution(r);times=[];profiles=[]
for repeat in range(2):
 t=time.perf_counter();p=build_ruleset_profile(compiled,EvaluationConfig());times.append(time.perf_counter()-t);profiles.append(record_value(p))
assert profiles[0]==profiles[1]
# The profile records raw/normalized prices; record complete capability as well.
capabilities={pt.type_id:record_value(analyzer.build_movement_capability(compiled.board_size,pt.movement_atoms,EvaluationConfig()))for pt in compiled.piece_types}
(B/f'profile-{seed}-{order}-{arm}.json').write_bytes(json.dumps(dict(complete=True,seed=seed,n=x['n'],arm=arm,order=order,seconds=times,profile=profiles[0],capabilities=capabilities,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())).encode());print(seed,arm,order,flush=True)
