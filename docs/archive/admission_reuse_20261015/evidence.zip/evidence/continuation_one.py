from pathlib import Path
import sys,json,time,importlib.util,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/admission-reuse-20261015';old=R/'.local_agent/reply-witness-20261015';plan=json.loads((B/'continuation-plan.json').read_bytes());case_index=int(sys.argv[1]);arm=int(sys.argv[2]);case=plan['cases'][case_index];start=time.perf_counter()
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.ai.limits import SearchLimits
x=json.loads((B/'transfer-inputs'/f"{case['seed']}.json").read_bytes());raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
for stored in case['root']['walk']:s.submit(next(a for a in s.legal_actions()if record_value(a)==stored))
assert record_value(s.state)==case['root']['state'];actor=s.state.position.side_to_move;spec=importlib.util.spec_from_file_location('continuation._native_core',next(old.glob('final_both*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);nr=nc.compile_native_semantic_rules(c,backend_module=m);profile=p.build_ruleset_profile(c,p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};rows=[];reason=None

def save(complete=False):write_record(B/f'continuation-{case_index}-{arm}.json',dict(complete=complete,case=case_index,seed=case['seed'],root_ply=case['ply'],first_action_arm=arm,root_actor=actor,rows=rows,state=record_value(s.state),result=record_value(s.result),end_reason=reason,seconds=time.perf_counter()-start,scope='Forced stored firstmove, then same q0/fixed4096nodes/hard8 policy on BOTHactors; not full q-policy match or optimal WDL.'))
def execute(action,search=None,wall=None):
 pos=pack_semantic_search_position(c,nr,s);np=sem.make_checked(nr,pos,pack_semantic_action(nr,s.state.position,action));before=hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest();s.submit(action);snap=sem.snapshot(nr,np);expected=expected_snapshot(s.state.position,nr,c)
 for key in('board','hands','aux_state','side'):assert record_value(snap[key])==record_value(expected[key])
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(v,c))for v in s._search_witnesses]
 assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in s.state.history)
 assert sem.terminal_status(nr,np)==dict(status=s.state.terminal_status.status.value,winner=s.state.terminal_status.winner)
 rows.append(dict(before_sha256=before,action=record_value(action),after_sha256=hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest(),actual_terminal=record_value(s.state.terminal_status),search=None if search is None else record_value(search),caller_seconds=wall,full_history_checked=True));save()
execute(next(a for a in s.legal_actions()if record_value(a)==case['first_actions'][str(arm)]))
for ply in range(plan['max_additional_plies']):
 p.rr.stopped()
 if s.result.status.value!='ongoing':reason='ACTUAL_TERMINAL';break
 if time.perf_counter()-start>=plan['per_game_seconds']:reason='ORIGINAL_GAME_TIME_CAP';break
 legal=tuple(s.legal_actions());t=time.perf_counter();res=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=16,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t
 if res.action not in legal:reason='NO_LEGAL_SEARCH_ACTION';break
 execute(res.action,res,wall)
else:reason='ORIGINAL_PLY_CAP'
if s.result.status.value!='ongoing':reason='ACTUAL_TERMINAL'
save(True);print(case_index,arm,reason,len(rows),s.result,flush=True)
