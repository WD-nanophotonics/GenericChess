from pathlib import Path
import sys,time,json,cProfile,pstats
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/admission-reuse-20261015';seed=int(sys.argv[1]);mode=sys.argv[2]
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.serialization import deserialize_ruleset
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
x=json.loads((B/'transfer-inputs'/f'{seed}.json').read_bytes());r=deserialize_ruleset(json.dumps(x['ruleset']));prof=cProfile.Profile();start=time.perf_counter()
if mode=='profile':prof.enable()
c=compile_legacy_ruleset_for_semantic_execution(r);adapt=SearchMetadataAdapter(ir=c.ir,_legacy_compiled=c._legacy_compiled,support=c.support);mid=time.perf_counter();p=build_ruleset_profile(adapt,EvaluationConfig());end=time.perf_counter()
if mode=='profile':prof.disable()
rows=[]
if mode=='profile':
 prof.dump_stats(str(B/f'remaining-{seed}-private.prof'))
 for (file,line,fn),(cc,nc,tt,ct,callers)in sorted(pstats.Stats(prof).stats.items(),key=lambda kv:kv[1][3],reverse=True):
  try:label=Path(file).resolve().relative_to(R).as_posix()
  except(ValueError,OSError):label=Path(file).name
  rows.append(dict(file=label,line=line,function=fn,primitive_calls=cc,total_calls=nc,self_seconds=tt,cumulative_seconds=ct))
out=dict(complete=True,seed=seed,mode=mode,compile_adapter_seconds=mid-start,rule_price_seconds=end-mid,total_seconds=end-start,functions=rows,scope='Actual candidate compile plus unchanged caller adapter and rule price. cProfile overlap/overhead retained; no timed search.')
(B/f'remaining-{seed}-{mode}.json').write_bytes(json.dumps(out).encode());print(seed,mode,out['compile_adapter_seconds'],out['rule_price_seconds'])
