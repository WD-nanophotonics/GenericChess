from pathlib import Path
import sys,json,time,random,importlib.util,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/admission-reuse-20261015';old=R/'.local_agent/reply-witness-20261015';seed=int(sys.argv[1]);plan=json.loads((B/'q-policy-plan.json').read_bytes());start=time.perf_counter();rows=[];roots=[];diagnostics={};tail=None
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import iter_legal_actions
from generic_chess.ai.limits import SearchLimits
spec=importlib.util.spec_from_file_location('qpolicy._native_core',next(old.glob('final_both*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);assert hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()==plan['native_image_sha256']
x=json.loads((B/'transfer-inputs'/f'{seed}.json').read_bytes());raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c);assert record_value(s.state)==x['state'];nr=nc.compile_native_semantic_rules(c,backend_module=m);profile=p.build_ruleset_profile(c,p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};rng=random.Random(seed+9000);walk=[]
def save(complete=False):write_record(B/f'q-policy-{seed}.json',dict(complete=complete,seed=seed,n=x['n'],rows=rows,roots=roots,diagnostics=diagnostics,terminal_tail=tail,seconds=time.perf_counter()-start,planned_roots=4,planned_queries=32,native_image_sha256=plan['native_image_sha256']))
def diagnosis(child):
 t=time.perf_counter();status=child.terminal_status
 if status.is_terminal:return dict(kind='SELECTED_CHILD_TERMINAL',terminal=record_value(status),seconds=time.perf_counter()-t)
 actor=child.position.side_to_move;tested=0;complete=False;win=None
 def checkpoint():
  p.rr.stopped()
  if time.perf_counter()-t>=plan['diagnostic_seconds_per_child']:raise TimeoutError('original one-reply diagnostic cap')
 try:
  for action in iter_legal_actions(child,c,checkpoint=checkpoint):
   checkpoint();reply=apply_action(child,action,c);tested+=1
   if reply.terminal_status.is_terminal and reply.terminal_status.winner==actor:win=record_value(action);break
  else:complete=True
 except TimeoutError:pass
 return dict(kind='ONE_REPLY_WIN'if win is not None else'NONE_FOUND_ONE_PLY'if complete else'UNKNOWN',winning_reply=win,tested=tested,complete=complete,seconds=time.perf_counter()-t)
for ply in range(13):
 p.rr.stopped()
 if time.perf_counter()-start>=plan['per_family_seconds']:break
 if s.result.status.value!='ongoing':tail=dict(ply=ply,state=record_value(s.state),walk=walk.copy());save();break
 if ply in plan['roots']:
  legal=tuple(s.legal_actions());before=record_value(s.to_record());roots.append(dict(ply=ply,state=record_value(s.state),walk=walk.copy(),legal_count=len(legal)));save()
  for budget in plan['budgets']:
   for order,arms in enumerate(plan['orders']):
    for q in arms:
     if time.perf_counter()-start>=plan['per_family_seconds']:break
     pos=pack_semantic_search_position(c,nr,s);t=time.perf_counter();res=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=16,max_nodes=1000000,max_time_seconds=budget,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);wall=time.perf_counter()-t
     assert res.action is None or res.action in legal
     state=s.state;np=pos;w=list(s._search_witnesses);t=time.perf_counter()
     for action in res.principal_variation:
      np=sem.make_checked(nr,np,pack_semantic_action(nr,state.position,action));state=apply_action(state,action,c);w.append(state.position);snap=sem.snapshot(nr,np);expected=expected_snapshot(state.position,nr,c)
      for key in('board','hands','aux_state','side'):assert record_value(snap[key])==record_value(expected[key])
      assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(v,c))for v in w]
      assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
     assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
     assert before==record_value(s.to_record());audit=time.perf_counter()-t;key=f'{ply}:'+repr(res.action)
     if key not in diagnostics:diagnostics[key]=diagnosis(apply_action(s.state,res.action,c))if res.action is not None else dict(kind='NO_ACTION')
     rows.append(dict(ply=ply,budget=budget,order=order,ordinary_q=q,caller_seconds=wall,result=record_value(res),diagnostic_key=key,full_history_checked=True,history_audit_seconds=audit));save();print(seed,ply,budget,order,q,res.completed_depth,diagnostics[key]['kind'],round(wall,3),flush=True)
 if ply==12:break
 acts=tuple(s.legal_actions())
 if not acts:break
 action=rng.choice(sorted(acts,key=repr));s.submit(action);walk.append(record_value(action))
save(True)
