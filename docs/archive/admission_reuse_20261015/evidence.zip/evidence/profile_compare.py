from pathlib import Path
import sys,json,time,subprocess
B=Path.cwd()/'.local_agent/admission-reuse-20261015';p=json.loads((B/'profile-plan.json').read_bytes());start=time.perf_counter();rows=[]
for inp in p['inputs']:
 for order,arms in enumerate(p['orders']):
  for arm in arms:
   if time.perf_counter()-start>=300:break
   with(B/f"profile-{inp['seed']}-{order}-{arm}.log").open('wb')as log:
    try:code=subprocess.run([sys.executable,str(B/'profile_one.py'),str(inp['seed']),arm,str(order)],stdout=log,stderr=subprocess.STDOUT,timeout=min(30,300-(time.perf_counter()-start))).returncode
    except subprocess.TimeoutExpired:code='original_fuse_timeout'
   rows.append(dict(seed=inp['seed'],order=order,arm=arm,exit=code));print(rows[-1],flush=True)
(B/'profile-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,planned=80)).encode())
