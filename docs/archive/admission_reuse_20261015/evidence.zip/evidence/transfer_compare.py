from pathlib import Path
import sys,subprocess,json,time
B=Path.cwd()/'.local_agent/admission-reuse-20261015';plan=json.loads((B/'transfer-plan.json').read_bytes());start=time.perf_counter();rows=[]
for inp in plan['inputs']:
 seed=inp['seed']
 for order,arms in enumerate(plan['orders']):
  for arm in arms:
   if time.perf_counter()-start>=plan['batch_seconds']:break
   t=time.perf_counter()
   with(B/f'transfer-{seed}-{order}-{arm}.log').open('wb')as log:
    try:code=subprocess.run([sys.executable,str(B/'transfer_one.py'),str(seed),arm,str(order)],stdout=log,stderr=subprocess.STDOUT,timeout=min(plan['process_seconds'],plan['batch_seconds']-(time.perf_counter()-start))).returncode
    except subprocess.TimeoutExpired:code='original_fuse_timeout'
   rows.append(dict(seed=seed,order=order,arm=arm,exit=code,seconds=time.perf_counter()-t));print(rows[-1],flush=True)
(B/'transfer-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,planned_processes=80,planned_queries=320)).encode())
