from pathlib import Path
import json,sys,time,statistics,dataclasses
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/admission-reuse-20261015'
from generic_chess.ai.evaluation import movement_graph as mg
from generic_chess.core.coordinates import BoardShape
from generic_chess.core.movement import LeapAtom,RayAtom
candidate={};exec((B/'graph-candidates.py').read_text(),candidate);arm=sys.argv[1];n=int(sys.argv[2]);height=int(sys.argv[3]);order=int(sys.argv[4]);shape=BoardShape(n,height);original=mg._bfs
if arm=='early':mg._bfs=candidate['early']
elif arm=='bitset':
 source=Path(mg.__file__).read_text(encoding='utf-8-sig');source=source.replace('    for source in sources:\n', '    masks = [sum(1 << target for target in neighbors) for neighbors in adj]\n    for source in sources:\n',1).replace('= _bfs(adj, source, node_count)','= bitset(masks, source, node_count)',1)
 # Rename only call in graph_metrics, not original helper declaration.
 assert 'def bitset(' not in source
 mg.__dict__['bitset']=candidate['bitset'];exec(compile(source,str(B/'graph-bitset-private.py'),'exec'),mg.__dict__)
motifs={'empty':(), 'forward_leap':(LeapAtom((0,1)),),'bounded_forward_ray':(RayAtom((0,1),3),),'knight':tuple(LeapAtom(d)for d in [(1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)]),'bishop':tuple(RayAtom(d)for d in [(1,1),(1,-1),(-1,1),(-1,-1)]),'rook':tuple(RayAtom(d)for d in [(1,0),(-1,0),(0,1),(0,-1)]),'queen':tuple(RayAtom(d)for d in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]),'mixed_duplicate':(LeapAtom((1,0)),LeapAtom((1,0)),RayAtom((1,0)),RayAtom((-1,0)),LeapAtom((0,2)))}
rows=[]
for name,atoms in motifs.items():
 times=[]
 for rep in range(2):
  t=time.perf_counter();result=mg.graph_metrics(shape,atoms);times.append(time.perf_counter()-t)
 rows.append(dict(motif=name,seconds=times,metrics=dataclasses.asdict(result)))
(B/f'graph-{n}-{height}-{order}-{arm}.json').write_bytes(json.dumps(dict(complete=True,arm=arm,width=n,height=height,order=order,rows=rows,scope='Graph metric including adjacency/mask/SCC; original exact1024/sampled64 source rule; no games.')).encode());print(n,height,order,arm,flush=True)
