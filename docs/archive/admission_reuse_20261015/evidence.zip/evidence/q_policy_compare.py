from pathlib import Path
import sys,json,time,subprocess
B=Path.cwd()/'.local_agent/admission-reuse-20261015';p=json.loads((B/'q-policy-plan.json').read_bytes());start=time.perf_counter();rows=[]
for inp in p['inputs']:
 if time.perf_counter()-start>=p['batch_seconds']:break
 with(B/f"q-policy-{inp['seed']}.log").open('wb')as log:
  try:code=subprocess.run([sys.executable,str(B/'q_policy_one.py'),str(inp['seed'])],stdout=log,stderr=subprocess.STDOUT,timeout=min(p['per_family_seconds']+5,p['batch_seconds']-(time.perf_counter()-start))).returncode
  except subprocess.TimeoutExpired:code='original_fuse_timeout'
 rows.append(dict(seed=inp['seed'],exit=code));print(rows[-1],flush=True)
(B/'q-policy-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,planned_roots=p['planned_roots'],planned_queries=p['planned_queries'])).encode())
