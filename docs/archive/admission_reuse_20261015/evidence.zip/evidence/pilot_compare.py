from pathlib import Path
import sys,subprocess,time,json
B=Path.cwd()/'.local_agent/admission-reuse-20261015';plan=json.loads((B/'plan.json').read_bytes());start=time.perf_counter();rows=[]
for seed in plan['seeds']:
 for order,arms in enumerate(plan['orders']):
  for arm in arms:
   if time.perf_counter()-start>=180:break
   t=time.perf_counter()
   with(B/f'pilot-{seed}-{order}-{arm}.log').open('wb')as log:
    try:code=subprocess.run([sys.executable,str(B/'pilot_one.py'),str(seed),arm,str(order)],stdout=log,stderr=subprocess.STDOUT,timeout=min(20,180-(time.perf_counter()-start))).returncode
    except subprocess.TimeoutExpired:code='original_fuse_timeout'
   rows.append(dict(seed=seed,order=order,arm=arm,exit=code,seconds=time.perf_counter()-t));print(rows[-1],flush=True)
(B/'pilot-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,planned=16)).encode())
