from pathlib import Path
import sys,subprocess,json,time
B=Path.cwd()/'.local_agent/admission-reuse-20261015';plan=dict(question='After exact reuse, are another duplicate catalog or actual rule-price computations the material next bottleneck?',seeds=[4324,4334],orders=[['control','profile'],['profile','control']],process_seconds=20,batch_seconds=90,decision='Use profiling only to localize; compare overhead controls. Reject catalog engineering if negligible. No index removal/price formula/validation change.',estimate='under90seconds, existing full rules; cheaper trace lacks wall attribution');(B/'remaining-plan.json').write_bytes(json.dumps(plan).encode());start=time.perf_counter();rows=[]
for seed in plan['seeds']:
 for order,modes in enumerate(plan['orders']):
  for mode in modes:
   # Keep both order outputs separately; runner final files are copied immediately.
   with(B/f'remaining-{seed}-{order}-{mode}.log').open('wb')as log:r=subprocess.run([sys.executable,str(B/'remaining_one.py'),str(seed),mode],stdout=log,stderr=subprocess.STDOUT,timeout=20)
   src=B/f'remaining-{seed}-{mode}.json'
   if src.exists():(B/f'remaining-{seed}-{order}-{mode}.json').write_bytes(src.read_bytes())
   rows.append(dict(seed=seed,order=order,mode=mode,exit=r.returncode));print(rows[-1],flush=True)
(B/'remaining-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start)).encode())
