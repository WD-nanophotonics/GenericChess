from pathlib import Path
import sys,json,time,pickle,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/admission-reuse-20261015';seed=int(sys.argv[1]);arm=sys.argv[2];order=int(sys.argv[3])
from generic_chess.rules import compiler,execution
if arm=='candidate':
 exec(compile((B/'execution-candidate.py').read_bytes(),str(B/'execution-candidate.py'),'exec'),execution.__dict__)
 exec(compile((B/'compiler-candidate.py').read_bytes(),str(B/'compiler-candidate.py'),'exec'),compiler.__dict__)
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.native.compiler import build_semantic_compile_payload
from generic_chess.session.session import GameSession
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
x=json.loads((R/'.local_agent/reply-witness-20261015/cold_inputs'/f'{seed}.json').read_text(encoding='utf-8'));r=deserialize_ruleset(json.dumps(x['ruleset']));rows=[]
for rep in range(3):
 t=time.perf_counter();c=compiler.compile_legacy_ruleset_for_semantic_execution(r);compile_seconds=time.perf_counter()-t
 t=time.perf_counter();a=SearchMetadataAdapter(ir=c.ir,_legacy_compiled=c._legacy_compiled,support=c.support);adapter_seconds=time.perf_counter()-t
 rows.append(dict(rep=rep,compile_seconds=compile_seconds,adapter_seconds=adapter_seconds))
s=GameSession(c);assert record_value(s.state)==x['state'];fields=['_incoming_attack_paths','_incoming_attack_sources','_incoming_attack_endpoints','_fixed_transition_triggers','_actor_capture_patterns','_pattern_drop_kinds'];hashes={k:hashlib.sha256(pickle.dumps(getattr(c,k),protocol=4)).hexdigest()for k in fields}
payload,report=build_semantic_compile_payload(c);out=dict(complete=True,seed=seed,arm=arm,order=order,rows=rows,derived_hashes=hashes,ir=c.ir.serialized(),payload_hash=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest(),report=record_value(report),state=record_value(s.state),actions=record_value(tuple(s.legal_actions())))
(B/f'pilot-{seed}-{order}-{arm}.json').write_bytes(json.dumps(out).encode());print(seed,arm,order,rows,flush=True)
