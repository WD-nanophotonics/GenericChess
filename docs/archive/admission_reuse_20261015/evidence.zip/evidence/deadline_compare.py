from pathlib import Path
import sys,json,time,subprocess
B=Path.cwd()/'.local_agent/admission-reuse-20261015';p=json.loads((B/'deadline-plan.json').read_bytes());start=time.perf_counter();rows=[]
for inp in p['inputs']:
 for budget in p['budgets']:
  for order,cells in enumerate(p['orders']):
   for cell in cells:
    if time.perf_counter()-start>=p['batch_seconds']:break
    with(B/f"deadline-{inp['seed']}-{budget}-{order}-{cell}.log").open('wb')as log:
     try:code=subprocess.run([sys.executable,str(B/'deadline_one.py'),str(inp['seed']),cell,str(budget),str(order)],stdout=log,stderr=subprocess.STDOUT,timeout=min(p['process_seconds'],p['batch_seconds']-(time.perf_counter()-start))).returncode
     except subprocess.TimeoutExpired:code='original_fuse_timeout'
    rows.append(dict(seed=inp['seed'],budget=budget,order=order,cell=cell,exit=code));print(rows[-1],flush=True)
(B/'deadline-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,planned_processes=p['planned_processes'])).encode())
