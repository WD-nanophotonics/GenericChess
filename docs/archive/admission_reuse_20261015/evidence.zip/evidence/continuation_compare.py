from pathlib import Path
import sys,json,time,subprocess
B=Path.cwd()/'.local_agent/admission-reuse-20261015';assert json.loads((B/'q-policy-results.json').read_bytes())['complete'];p=json.loads((B/'continuation-plan.json').read_bytes());start=time.perf_counter();rows=[]
for i,arms in enumerate(p['orders']):
 for arm in arms:
  if time.perf_counter()-start>=300:break
  with(B/f'continuation-{i}-{arm}.log').open('wb')as log:
   try:code=subprocess.run([sys.executable,str(B/'continuation_one.py'),str(i),str(arm)],stdout=log,stderr=subprocess.STDOUT,timeout=min(35,300-(time.perf_counter()-start))).returncode
   except subprocess.TimeoutExpired:code='original_fuse_timeout'
  rows.append(dict(case=i,arm=arm,exit=code));print(rows[-1],flush=True)
(B/'continuation-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,planned_games=8)).encode())
