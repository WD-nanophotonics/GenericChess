from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/admission-reuse-20261015';start=time.perf_counter();plan=json.loads((B/'continuation-plan.json').read_bytes())
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.core.transition import apply_action
SemanticSearchEngine.search=lambda *a,**k: (_ for _ in ()).throw(AssertionError('replay must not search'))
rows=[];edges=0
for i,case in enumerate(plan['cases']):
 x=json.loads((B/'transfer-inputs'/f"{case['seed']}.json").read_bytes());raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
 for arm in [0,4]:
  d=json.loads((B/f'continuation-{i}-{arm}.json').read_bytes());s=GameSession(c)
  for stored in case['root']['walk']:s.submit(next(a for a in s.legal_actions()if record_value(a)==stored))
  assert record_value(s.state)==case['root']['state']
  for r in d['rows']:
   assert hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest()==r['before_sha256'];a=next(a for a in s.legal_actions()if record_value(a)==r['action']);s.submit(a);assert hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True).encode()).hexdigest()==r['after_sha256'];assert record_value(s.state.terminal_status)==r['actual_terminal'];edges+=1
  assert record_value(s.state)==d['state']and record_value(s.result)==d['result'];rows.append(dict(case=i,arm=arm,edges=len(d['rows']),result=record_value(s.result)))
(B/'continuation-replay.json').write_bytes(json.dumps(dict(complete=True,rows=rows,physical_edges=edges,seconds=time.perf_counter()-start,search_disabled=True,scope='Separate consumer reconstructs all roots/277actualedges/finalhistories from publicactions with search disabled; original producer independently Native-crosschecked each edge. Shared Core/compiler, not all-domain proof or timing rerun.'),indent=2).encode());print('REPLAY',edges,time.perf_counter()-start)
