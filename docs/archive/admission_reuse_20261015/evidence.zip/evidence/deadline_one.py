from pathlib import Path
import sys,json,time,hashlib,importlib.util
R=Path.cwd();sys.path.insert(0,str(R));B=R/'.local_agent/admission-reuse-20261015';old=R/'.local_agent/reply-witness-20261015';seed=int(sys.argv[1]);cell=sys.argv[2];budget=float(sys.argv[3]);order=int(sys.argv[4]);started=time.perf_counter();plan=json.loads((B/'deadline-plan.json').read_bytes());ca,ga=plan['cells'][cell]
from generic_chess.rules import compiler,execution
for name,module in [('execution',execution),('compiler',compiler)]:
 source=B/f'{name}-{ca}.py';exec(compile(source.read_bytes(),str(source),'exec'),module.__dict__)
from generic_chess.ai.evaluation import movement_graph as mg
source=B/f'movement-graph-{ga}.py';exec(compile(source.read_bytes(),str(source),'exec'),mg.__dict__)
from generic_chess.ai.evaluation import analyzer
analyzer.graph_metrics=mg.graph_metrics
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.ai.limits import SearchLimits
phases=dict(imports=time.perf_counter()-started)
spec=importlib.util.spec_from_file_location('deadline._native_core',next(old.glob('final_both*.pyd')));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
t=time.perf_counter();x=json.loads((B/'transfer-inputs'/f'{seed}.json').read_bytes());rules=deserialize_ruleset(json.dumps(x['ruleset']));phases['deserialize']=time.perf_counter()-t
start=time.perf_counter();result=None;expired=None;remaining=None;diagnostic=0
try:
 t=time.perf_counter();raw=compiler.compile_legacy_ruleset_for_semantic_execution(rules);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);phases['python_compile']=time.perf_counter()-t
 if time.perf_counter()-start>=budget:expired='python_compile';raise StopIteration
 t=time.perf_counter();s=GameSession(c);phases['initial_session']=time.perf_counter()-t
 if time.perf_counter()-start>=budget:expired='initial_session';raise StopIteration
 t=time.perf_counter();profile=p.build_ruleset_profile(c,p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()};phases['rule_price']=time.perf_counter()-t
 if time.perf_counter()-start>=budget:expired='rule_price';raise StopIteration
 t=time.perf_counter();nr=nc.compile_native_semantic_rules(c,backend_module=m);phases['native_compile']=time.perf_counter()-t
 if time.perf_counter()-start>=budget:expired='native_compile';raise StopIteration
 t=time.perf_counter();engine=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False);phases['engine']=time.perf_counter()-t
 remaining=budget-(time.perf_counter()-start)
 if remaining<=0:expired='engine';raise StopIteration
 before=record_value(s.to_record());t=time.perf_counter();res=engine.search(s,SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=remaining,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);phases['search']=time.perf_counter()-t;elapsed=time.perf_counter()-start;result=record_value(res)
 t=time.perf_counter();state=s.state;pos=pack_semantic_search_position(c,nr,s);w=list(s._search_witnesses)
 for action in res.principal_variation:
  pos=sem.make_checked(nr,pos,pack_semantic_action(nr,state.position,action));state=apply_action(state,action,c);w.append(state.position);snap=sem.snapshot(nr,pos);expected=expected_snapshot(state.position,nr,c)
  for key in('board','hands','aux_state','side'):assert record_value(snap[key])==record_value(expected[key])
  assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(v,c))for v in w]
  assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert before==record_value(s.to_record());diagnostic=time.perf_counter()-t
except StopIteration:elapsed=time.perf_counter()-start
(B/f'deadline-{seed}-{budget}-{order}-{cell}.json').write_bytes(json.dumps(dict(complete=True,seed=seed,n=x['n'],cell=cell,budget=budget,order=order,phases=phases,status='ADMISSION_EXPIRED'if expired else'SEARCH_EXECUTED',expired_phase=expired,allocated_search_seconds=remaining,caller_seconds=elapsed,overrun_seconds=max(0,elapsed-budget),result=result,full_history_checked=result is not None,diagnostic_seconds=diagnostic,source_hashes={k:hashlib.sha256((B/v).read_bytes()).hexdigest()for k,v in [('compiler',f'compiler-{ca}.py'),('execution',f'execution-{ca}.py'),('graph',f'movement-graph-{ga}.py')]})).encode())
