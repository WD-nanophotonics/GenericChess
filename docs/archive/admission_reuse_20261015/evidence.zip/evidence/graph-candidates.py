from collections import deque

def early(adj, source, node_count):
 dist={source:0};queue=deque([source])
 while queue and len(dist)<node_count:
  node=queue.popleft()
  for nxt in adj[node]:
   if nxt not in dist:
    dist[nxt]=dist[node]+1;queue.append(nxt)
 return len(dist)-1,sum(d for d in dist.values()if d>0),max(dist.values())

def bitset(masks,source,node_count):
 seen=frontier=1<<source;reachable=0;path_sum=0;depth=0
 while frontier:
  targets=0
  while frontier:
   bit=frontier & -frontier;targets |= masks[bit.bit_length()-1];frontier ^= bit
  frontier=targets & ~seen
  if not frontier:break
  depth+=1;count=frontier.bit_count();reachable+=count;path_sum+=depth*count;seen |= frontier
  if reachable==node_count-1:break
 return reachable,path_sum,depth
