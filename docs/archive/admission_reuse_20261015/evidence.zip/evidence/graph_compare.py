from pathlib import Path
import sys,json,time,subprocess
B=Path.cwd()/'.local_agent/admission-reuse-20261015';p=json.loads((B/'graph-plan.json').read_bytes());start=time.perf_counter();rows=[]
for w,h in [[n,n]for n in p['boards']]+p['rectangles']:
 for order,arms in enumerate(p['orders']):
  for arm in arms:
   if time.perf_counter()-start>=480:break
   with(B/f'graph-{w}-{h}-{order}-{arm}.log').open('wb')as log:
    try:code=subprocess.run([sys.executable,str(B/'graph_one.py'),arm,str(w),str(h),str(order)],stdout=log,stderr=subprocess.STDOUT,timeout=min(45,480-(time.perf_counter()-start))).returncode
    except subprocess.TimeoutExpired:code='original_fuse_timeout'
   rows.append(dict(width=w,height=h,order=order,arm=arm,exit=code));print(rows[-1],flush=True)
(B/'graph-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,planned=42)).encode())
