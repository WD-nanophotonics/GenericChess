import sys,json,hashlib,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;out=ROOT/'docs/research/data/chess_see_price_20261007.json';a=ROOT/'docs/archive/development_see_price_20261007';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest();records={n:json.loads((p/n).read_bytes()) for n in ('declaration.json','build.json','qualification.json','roots.json','adverse.json','root-replay.json','first-pair.json','game-declaration.json','direct.json','direct-replay.json')}
for n in ('build.json','qualification.json','roots.json','adverse.json','root-replay.json','direct.json','direct-replay.json'):assert records[n]['complete']
r=records['direct-replay.json'];assert len(r['games'])==12 and not r['errors'];assert sha((p/'games.py').read_bytes())==records['game-declaration.json']['producer_sha256']
totals=dict(wins=0,losses=0,draws=0,unfinished=0);tables={}
for g in r['games']:
 key='unfinished' if not g['finished'] else 'draws' if g['winner'] is None else 'wins' if g['winner']==g['price_color'] else 'losses';totals[key]+=1;z=tables.setdefault(g['table'],dict(wins=0,losses=0,draws=0,unfinished=0));z[key]+=1
a.mkdir(exist_ok=True)
def archive(path,items):
 assert not path.exists();entries={}
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in items:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b);z.writestr(n,b);entries[n]=dict(bytes=len(b),sha256=sha(b))
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  for n,h in entries.items():assert sha(z.read(n))==h['sha256']
 return entries
rawentries=archive(a/'raw.zip',[(p/n,n) for n in records]);upstream=ROOT/'.local_agent/mature-search/Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d'
sourceitems=[(f,'see-price-20261007/'+f.name) for f in p.glob('*.py')]+[(p/n,n) for n in ('position-price.cpp','uci-diagnostic.cpp','price.patch')]+[(upstream/'src'/n,'pinned-'+n) for n in ('position.cpp','uci.cpp')]+[(upstream/'Copying.txt','upstream-Copying.txt'),(ROOT/'.local_agent/exchange-20261007/evaluate-exchange.cpp','evaluate-exchange.cpp'),(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(ROOT/'scripts/research_record.py','shared-research_record.py'),(ROOT/'.local_agent/mature-search/material-variants.ini','material-variants.ini'),(ROOT/'.local_agent/mature-openings/suite.json','suite.json')]
sources=archive(a/'sources.zip',sourceitems)
summary=dict(scope='Arithmetic-only fast SEE price contrast, unchanged half-risk leaf, LVA/capture ordering and thresholds. Exposed development, no default/strength/Elo/holdout or generic SEE claim.',declaration=records['declaration.json'],build=records['build.json'],qualification={k:v for k,v in records['qualification.json'].items() if k!='rows'},roots=records['roots.json'],adverse=records['adverse.json'],root_replay=records['root-replay.json'],game_declaration=records['game-declaration.json'],totals=totals,tables=tables,cells=r['games'],replay=dict(streams=12,played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0),wall_seconds=records['direct.json']['wall_seconds'],recording_cost_before_final_save=records['direct.json']['recording_cost_before_final_save'],raw_entries=rawentries,sources=sources,raw_archive=a.relative_to(ROOT).as_posix()+'/raw.zip',sources_archive=a.relative_to(ROOT).as_posix()+'/sources.zip',raw_zip_sha256=sha((a/'raw.zip').read_bytes()),sources_zip_sha256=sha((a/'sources.zip').read_bytes()),production_changes='None; isolated source/binaries only',public_push='held')
summary['parent_sha']='3d9426bb605e244ee6b6679b4a161e8f45e34308'
summary['public_push']='User2026-10-07 authorized Agent-generated code/evidence; verify actual publication independently after commit/push.'
write_record(out,summary);write_record(a/'index.json',dict(raw_entries=rawentries,sources=sources,portable_sha256=sha(out.read_bytes())));print(json.dumps(dict(totals=totals,replay=summary['replay'],sha256=sha(out.read_bytes()))))
