import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;out=p/'adverse.json';assert not out.exists()
source=ROOT/'.local_agent/activity-safety-20261007/forced.json';raw=source.read_bytes();x=json.loads(raw);build=json.loads((p/'build.json').read_bytes());assert build['complete']
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());state,_=d.replay_prefix(chess.STARTING_FEN,c,x['history_prefix']);b=chess.Board(chess.STARTING_FEN)
for m in x['history_prefix']:b.push_uci(m)
assert b.fen(en_passant='fen')==x['fen'];legal={d.uci(a) for a in d.iter_legal_actions(state,c)};assert legal=={m.uci() for m in b.legal_moves}
report=dict(complete=False,source_sha256=hashlib.sha256(raw).hexdigest(),fen=x['fen'],history_prefix=x['history_prefix'],scope='Retained exposed linearBlack failure, both private debug-identical builds at1/4sec. Same leaf/conditions; cp/mate children are finite reference, not WDL or proof of pricing cause.',choices=[],references={})
for mode in ('original','price'):
 for sec in (1,4):
  for name in ('rollout','advisor','slack'):
   st=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not st.get('stopped') and not st.get('user_paused')
  with chess.engine.SimpleEngine.popen_uci([str(p/('fairy-'+mode+'.exe')),'load',str(ROOT/'.local_agent/mature-search/material-variants.ini')],timeout=15) as e:
   e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=d.UciMaterial(e,chess.STARTING_FEN,'linear_mixture',sec);d.replay_prefix(chess.STARTING_FEN,c,x['history_prefix'],(player,));m,row=player.choose();assert m in legal;pv=b.copy(stack=True)
   for v in row['pv']:assert chess.Move.from_uci(v) in pv.legal_moves;pv.push_uci(v)
   report['choices'].append(dict(mode=mode,requested_seconds=sec,**row));d.write_record(out,report);print(mode,sec,m,row.get('score_cp'),row.get('score_mate'),flush=True)
with chess.engine.SimpleEngine.popen_uci(str(ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'),timeout=15) as e:
 e.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
 for m in sorted({r['move'] for r in report['choices']}):
  child=b.copy(stack=True);child.push_uci(m);e.configure({'Clear Hash':None});start=time.perf_counter();info=e.analyse(child,chess.engine.Limit(nodes=500000,time=1),game=object());score=info['score'].pov(b.turn);pv=child.copy(stack=True)
  for v in info.get('pv',()):assert v in pv.legal_moves;pv.push(v)
  report['references'][m]=dict(cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),wall_seconds=time.perf_counter()-start,pv=[v.uci() for v in info.get('pv',())]);d.write_record(out,report)
report['complete']=True;d.write_record(out,report)
