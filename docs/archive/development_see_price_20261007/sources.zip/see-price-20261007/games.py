"""Single prospective SEE arithmetic contrast through the unchanged game adapter."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess,chess.engine
import scripts.chess_development as d
p=Path(__file__).parent;config=ROOT/'.local_agent/mature-search/material-variants.ini';suitepath=ROOT/'.local_agent/mature-openings/suite.json';out=p/'direct.json';active=p/'direct-active.json';assert not out.exists()
build=json.loads((p/'build.json').read_bytes());qual=json.loads((p/'qualification.json').read_bytes());roots=json.loads((p/'roots.json').read_bytes());assert build['complete'] and qual['complete'] and roots['complete'] and any(not row['all_equal'] for row in roots['rows'])
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();bins={k:p/('fairy-'+k+'.exe') for k in ('price','original')};assert all(sha(f)==build['binaries'][k] for k,f in bins.items())
decl=dict(question='Do observed same-leaf SEE arithmetic changes have useful practical effect?',design='Fixed12price/original color-paired cells, two existing prefixes x three unchanged gc tables.1sec SinglePV1 Threads1 Hash16 NNUEfalse,160subsequentplies. Fresh engines/hash/game, sequential, complete history/PV/results; no replacement or extension.',scope='Exposed development, not human-price fitting, default/Elo/holdout or fully generic SEE. Only arithmetic prices change; LVA/capture order and all thresholds fixed. New condition does not rewrite earlier24feedback results.',binary_sha256=build['binaries'],config_sha256=sha(config),suite_sha256=sha(suitepath),adapter_sha256=sha(ROOT/'scripts/chess_development.py'),producer_sha256=sha(Path(__file__)),recording='Existing per-action active snapshots and per-completed-game cohort, cost measured; no shared entry/schema edits.',cost='At most1920requested search seconds plus legal/Core/logging; interruptible every action, no extra worker. Unknown effect; win/loss/unfinished changes next decision, none automatically promote default.')
assert not (p/'game-declaration.json').exists();d.write_record(p/'game-declaration.json',decl)
class Player(d.UciMaterial):
 def __init__(self,*args,mode,**kw):super().__init__(*args,**kw);self.mode=mode
 def choose(self):
  m,r=super().choose();r.update(leaf_mode=self.mode,leaf_binary_sha256=build['binaries'][self.mode],requested_seconds=1);return m,r
def stopcheck():
 for n in ('rollout','advisor','slack'):
  v=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes())
  if v.get('user_paused') or v.get('stopped'):raise KeyboardInterrupt('User stop retained')
cost={k:dict(writes=0,bytes=0,seconds=0.) for k in ('active','cohort')}
def save(kind,value):
 t=time.perf_counter();target=active if kind=='active' else out;d.write_record(target,value,indent=None);cost[kind]['writes']+=1;cost[kind]['bytes']+=target.stat().st_size;cost[kind]['seconds']+=time.perf_counter()-t
suite=json.loads(suitepath.read_bytes());c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());report=dict(declaration=decl,games=[],complete=False);start=time.perf_counter();save('cohort',report)
try:
 for case in suite['cases']:
  for policy in d.POLICIES:
   for color in (0,1):
    stopcheck()
    with chess.engine.SimpleEngine.popen_uci([str(bins['price']),'load',str(config)],timeout=15) as e,chess.engine.SimpleEngine.popen_uci([str(bins['original']),'load',str(config)],timeout=15) as other:
     for engine in (e,other):engine.configure({'Threads':1,'Hash':16,'Use NNUE':False})
     local=Player(e,case['fen'],policy,1,mode='price');external=Player(other,case['fen'],policy,1,mode='original');tags=dict(id=case['id'],table=policy,price_color=color)
     def progress(g):save('active',dict(**tags,**g));stopcheck()
     g=d.play_game(case['fen'],c,policy if color==0 else 'uci_reference','uci_reference' if color==0 else policy,d.SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1),160,progress,external=external,local_external=local,prefix=case['opening_uci']);report['games'].append(dict(**tags,**g));save('cohort',report);print('direct',len(report['games']),policy,color,g['end'],g['winner'],g['plies_played'],flush=True)
 report['complete']=True
finally:report.update(wall_seconds=time.perf_counter()-start,recording_cost_before_final_save={k:dict(v) for k,v in cost.items()});save('cohort',report)
d.write_record(active,dict(complete=report['complete'],games=len(report['games'])),indent=None)
