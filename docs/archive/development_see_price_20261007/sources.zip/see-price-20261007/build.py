import sys,os,json,time,hashlib,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;common=ROOT/'.local_agent/mature-search';src=common/'Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d/src'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();decl=json.loads((p/'declaration.json').read_bytes());assert not (p/'build.json').exists()
for n,k in [('position.cpp','position_source_sha256'),('uci.cpp','uci_source_sha256')]:assert sha(src/n)==decl[k]
for n,k in [('position-price.cpp','position_price_sha256'),('uci-diagnostic.cpp','uci_diagnostic_sha256')]:assert sha(p/n)==decl[k]
base=[sys.executable,'-m','ziglang','c++','-target','x86_64-windows-gnu','-std=c++17','-O2','-fno-exceptions','-fno-strict-aliasing','-DNDEBUG','-DIS_64BIT','-DNNUE_EMBEDDING_OFF','-DGENERICCHESS_MATERIAL_DEVELOPMENT']
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(common/'zig-global-cache'),ZIG_LOCAL_CACHE_DIR=str(common/'zig-local-cache'))
sources=json.loads((common/'build-report.json').read_bytes())['sources'];report=dict(complete=False,commands=[],binaries={},reused_objects={f:sha(common/'build'/(f.replace('/','_')+'.o')) for f in sources if f not in ('evaluate.cpp','position.cpp','uci.cpp')},shared_evaluate_sha256=sha(ROOT/'.local_agent/exchange-20261007/evaluate.cpp.o'));start=time.perf_counter()
commands=[base+['-I',str(src),'-c',str(p/n),'-o',str(p/(n+'.o'))] for n in ('position-price.cpp','uci-diagnostic.cpp')]
for mode in ('original','price'):
 objects=[]
 for f in sources:
  if f=='evaluate.cpp':obj=ROOT/'.local_agent/exchange-20261007/evaluate.cpp.o'
  elif f=='uci.cpp':obj=p/'uci-diagnostic.cpp.o'
  elif f=='position.cpp' and mode=='price':obj=p/'position-price.cpp.o'
  else:obj=common/'build'/(f.replace('/','_')+'.o')
  objects.append(str(obj))
 commands.append(base+objects+['-o',str(p/('fairy-'+mode+'.exe')),'-lpthread','-ladvapi32','-Wl,--stack,8388608'])
for cmd in commands:
 for name in ('rollout','advisor','slack'):
  state=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not state.get('user_paused') and not state.get('stopped')
 r=subprocess.run(cmd,cwd=src,env=env,capture_output=True,text=True,timeout=120)
 report['commands'].append(dict(command=[x.replace(str(ROOT),'ROOT') for x in cmd],exit_code=r.returncode,stdout=r.stdout.replace(str(ROOT),'ROOT'),stderr=r.stderr.replace(str(ROOT),'ROOT')));write_record(p/'build.json',report);print('command',r.returncode,flush=True)
 if r.returncode:break
else:
 report['complete']=True;report['binaries']={k:sha(p/('fairy-'+k+'.exe')) for k in ('original','price')}
report['wall_seconds']=time.perf_counter()-start
for n,k in [('position.cpp','position_source_sha256'),('uci.cpp','uci_source_sha256')]:assert sha(src/n)==decl[k]
write_record(p/'build.json',report);print(report['complete'],report['wall_seconds'],flush=True)
