import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
p=Path(__file__).parent;out=p/'root-replay.json';assert not out.exists();c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());report=dict(complete=False,roots=0,choice_pvs=0,reference_pvs=0,errors=[],source_sha256={})
for name in ('roots','adverse'):
 raw=(p/(name+'.json')).read_bytes();v=json.loads(raw);assert v['complete'];report['source_sha256'][name]=hashlib.sha256(raw).hexdigest()
 for row in v['rows'] if name=='roots' else [v]:
  b=chess.Board(chess.STARTING_FEN);s,_=d.replay_prefix(chess.STARTING_FEN,c,row['history_prefix'])
  for m in row['history_prefix']:b.push_uci(m)
  assert b.fen(en_passant='fen')==row['fen'];legal={d.uci(a) for a in d.iter_legal_actions(s,c)};assert legal=={m.uci() for m in b.legal_moves};report['roots']+=1
  for r in row['choices']:
   assert r['move'] in legal;copy=b.copy(stack=True)
   for m in r['pv']:assert chess.Move.from_uci(m) in copy.legal_moves;copy.push_uci(m)
   report['choice_pvs']+=1
  for move,r in row['references'].items():
   assert move in legal;copy=b.copy(stack=True);copy.push_uci(move)
   for m in r['pv']:assert chess.Move.from_uci(m) in copy.legal_moves;copy.push_uci(m)
   assert (r['cp'] is None)!=(r['mate'] is None);report['reference_pvs']+=1
report['complete']=True;d.write_record(out,report);print(json.dumps(report))
