from pathlib import Path
import ast
p=Path(__file__).parent
s=(p.parent/'exchange-20261007/roots.py').read_text().replace('exchange-20261007','see-price-20261007')
s=s.replace("binaries={'exchange':p/'fairy-exchange.exe','activity':ROOT/'.local_agent/activity-20261007/fairy-activity.exe'}","binaries={'original':p/'fairy-original.exe','price':p/'fairy-price.exe'}")
s=s.replace("json.loads((p/'roots-declaration.json').read_bytes())","json.loads((p/'declaration.json').read_bytes())").replace("assert report['source_sha256']==report['declaration']['source_sha256']","assert old['complete'] and len(old['rows'])==8")
start=s.index("decl=json.loads((p/'game-declaration.json')");end=s.index('\nd.write_record(out,report)',start)
s=s[:start]+"decl=json.loads((p/'build.json').read_bytes());assert decl['complete'] and all(sha(f)==decl['binaries'][k] for k,f in binaries.items())"+s[end:]
s=s.replace('Does native half hanging-risk change decisions on the already exposed actual royal/classical root union?','Does isolated SEE arithmetic pricing change the already exposed actual root choices with exchange leaf fixed?')
s=s.replace("report['complete']=True;d.write_record(out,report)","report['complete']=True;report['scope']='Eight exposed actual roots, paired equal time. Child cp/mate finite diagnostics only, not exact WDL or independent strength validation.';d.write_record(out,report)")
ast.parse(s);(p/'roots.py').write_bytes(s.encode());print('Prepared eight paired actual roots')
