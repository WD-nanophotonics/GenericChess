import sys,json,hashlib,subprocess,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
import scripts.chess_development as d
p=Path(__file__).parent;assert not (p/'qualification.json').exists();build=json.loads((p/'build.json').read_bytes());assert build['complete']
c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset());report=dict(complete=False,rows=[],errors=[],scope='Single ordinary legal two-capture fixture and color mirror only; arithmetic contract, unchanged LVA, no general SEE/strength correctness.')
base=chess.Board('7k/8/4p3/3p4/2Q5/8/8/K7 w - - 0 1')
for mirrored in (False,True):
 b=base.mirror() if mirrored else base.copy();fen=b.fen(en_passant='fen');moves=['c5d4','e3d4'] if mirrored else ['c4d5','e6d5'];s=d.root_from_fen(fen,c);board=b.copy();states=[s]
 for move in moves:
  legal={d.uci(a):a for a in d.iter_legal_actions(s,c)};assert set(legal)=={m.uci() for m in board.legal_moves} and move in legal
  s=d.apply_action(s,legal[move],c);board.push_uci(move);states.append(s)
 for policy,prices in d.material_tables().items():
  def inventory(board):return sum((1 if pc.color==b.turn else -1)*prices[pc.symbol().upper()] for pc in board.piece_map().values() if pc.piece_type!=chess.KING)
  delta=inventory(board)-inventory(b);assert delta==prices['P']-prices['Q']
  for mode in ('original','price'):
   for n in ('rollout','advisor','slack'):
    st=json.loads((ROOT/'.local_agent'/(n+'.json')).read_bytes());assert not st.get('user_paused') and not st.get('stopped')
   commands=['uci','setoption name Threads value 1','setoption name Hash value 16','setoption name Use NNUE value false','setoption name UCI_Variant value gc_'+policy,'isready','position fen '+fen]+['gcsee '+moves[0]+' '+str(t) for t in (-1,0,1)]+['eval','quit']
   r=subprocess.run([str(p/('fairy-'+mode+'.exe')),'load',str(ROOT/'.local_agent/mature-search/material-variants.ini')],input='\n'.join(commands)+'\n',text=True,capture_output=True,timeout=15);assert r.returncode==0
   got=[bool(int(x)) for x in re.findall(r'^gcsee ([01])$',r.stdout,re.M)];assert len(got)==3
   expected=[delta>=t for t in (-1,0,1)]
   if mode=='price':assert got==expected
   report['rows'].append(dict(mirrored=mirrored,policy=policy,mode=mode,fen=fen,moves=moves,net_exchange=delta,thresholds=[-1,0,1],expected=expected,actual=got,agrees=got==expected,stdout=r.stdout,stderr=r.stderr,binary_sha256=build['binaries'][mode]))
for mirrored in (False,True):
 for policy in d.POLICIES:
  pair=[row for row in report['rows'] if row['mirrored']==mirrored and row['policy']==policy]
  assert len(pair)==2
  # Compare complete eval trace after the last diagnostic predicate, excluding only gcsee output.
  traces=[re.split(r'^gcsee [01]$',row['stdout'],flags=re.M)[-1] for row in pair]
  assert traces[0]==traces[1] and traces[0].strip()
report.update(complete=True,predicates=36,core_replayed_capture_plies=4,changed_contract_cases=sum(not row['agrees'] for row in report['rows']),leaf_equality='Six original/price complete native eval trace pairs identical; shared evaluate object unchanged.')
d.write_record(p/'qualification.json',report);print('36predicates/4Corecaptureplies; price all expected; original mismatches',report['changed_contract_cases'])
