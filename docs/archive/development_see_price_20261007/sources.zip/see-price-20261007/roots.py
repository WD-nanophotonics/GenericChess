"""Fixed eight exposed actual roots; exchange/activity under equal time."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess'),str(ROOT/'.local_agent')]
import chess,chess.engine
import scripts.chess_development as d
p=ROOT/'.local_agent/see-price-20261007';out=p/'roots.json';assert not out.exists()
source=ROOT/'.local_agent/royal-20261007/classical-roots.json';raw=source.read_bytes();old=json.loads(raw);assert old['complete'] and len(old['rows'])==8
config=ROOT/'.local_agent/mature-search/material-variants.ini';ref=ROOT/'.local_agent/stockfish-reference/stockfish/stockfish-windows-x86-64.exe'
binaries={'original':p/'fairy-original.exe','price':p/'fairy-price.exe'}
report=dict(question='Does isolated SEE arithmetic pricing change the already exposed actual root choices with exchange leaf fixed?',declaration=json.loads((p/'declaration.json').read_bytes()),source_sha256=hashlib.sha256(raw).hexdigest(),rows=[],complete=False)
assert old['complete'] and len(old['rows'])==8
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
decl=json.loads((p/'build.json').read_bytes());assert decl['complete'] and all(sha(f)==decl['binaries'][k] for k,f in binaries.items())
d.write_record(out,report);c=d.compile_ruleset_for_execution(d.build_western_chess_ruleset())
for source_row in old['rows']:
   for name in ('rollout','advisor','slack'):
    f=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes());assert not f.get('user_paused') and not f.get('stopped')
   prefix=source_row['history_prefix'];state,_=d.replay_prefix(chess.STARTING_FEN,c,prefix)
   b=chess.Board(chess.STARTING_FEN)
   for m in prefix:b.push_uci(m)
   assert b.fen(en_passant='fen')==source_row['fen']
   legal={d.uci(a) for a in d.iter_legal_actions(state,c)};assert legal=={m.uci() for m in b.legal_moves}
   row={k:source_row[k] for k in ('game','id','policy','threshold','side','index','fen','history_prefix')};row.update(choices=[],references={})
   for mpv,cls in ((1,d.UciMaterial),):
    for mode,binary in binaries.items():
     with chess.engine.SimpleEngine.popen_uci([str(binary),'load',str(config)],timeout=15) as e:
      e.configure({'Threads':1,'Hash':16,'Use NNUE':False});player=cls(e,chess.STARTING_FEN,row['policy'],1)
      d.replay_prefix(chess.STARTING_FEN,c,prefix,(player,));move,r=player.choose();assert move in legal
      r.update(mode=mode,multipv=mpv);row['choices'].append(r)
   selections={r['move'] for r in row['choices']};row['all_equal']=len(selections)==1
   if not row['all_equal']:
    with chess.engine.SimpleEngine.popen_uci(str(ref),timeout=15) as e:
     e.configure({'Threads':1,'Hash':16,'UCI_LimitStrength':False})
     for move in sorted(selections):
      child=b.copy(stack=True);child.push_uci(move);e.configure({'Clear Hash':None});t=time.perf_counter()
      info=e.analyse(child,chess.engine.Limit(nodes=500000,time=1),game=object());score=info['score'].pov(b.turn)
      row['references'][move]=dict(cp=score.score(),mate=score.mate(),nodes=info.get('nodes'),depth=info.get('depth'),wall_seconds=time.perf_counter()-t,pv=[m.uci() for m in info.get('pv',())])
   report['rows'].append(row);d.write_record(out,report);print(row['game'],row['threshold'],row['side'],[(r['mode'],r['multipv'],r['move']) for r in row['choices']],flush=True)
report['complete']=True;report['scope']='Eight exposed actual roots, paired equal time. Child cp/mate finite diagnostics only, not exact WDL or independent strength validation.';d.write_record(out,report)
