"""Later fullhistory largeboard admission/cost gate; no match or training."""
from pathlib import Path
from collections import Counter
import sys,json,time,random,hashlib,shutil,traceback
from copy import copy
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.actions import SemanticDropMove,SemanticBoardMove
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());B=R/'.local_agent'/P['input_directory'];start=time.perf_counter();count=Counter();status='COMPLETE';error=None;current=None
assert not(D/'queries.jsonl').exists()
for n in('generation.jsonl','models.json'):shutil.copyfile(B/n,D/n)
grs=list(map(json.loads,(D/'generation.jsonl').read_bytes().splitlines()));compiled={g['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))for g in grs if 'rules'in g};mods={(r['rule'],r['label']):r for r in json.loads((D/'models.json').read_bytes())['rows']};oldroots=json.loads((B/'roots.json').read_bytes())['rows'];native={gs:compile_native_semantic_rules(c)for gs,c in compiled.items()};roots=[]
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.perf_counter()-start<P['global_seconds'],'FROZEN_GLOBAL_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
try:
 with(D/'roots.jsonl').open('x',encoding='utf8')as log:
  for base in oldroots:
   gs=base['rule'];fam=base['family'];c=compiled[gs];tick=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(base['record'])));assert digest(s.state)==base['state_sha256']and digest(s._search_witnesses)==base['witnesses_sha256'];rng=random.Random(P['random_walk_seed']+gs*100+fam);moves=[]
   for target in P['targets']:
    while s.state.ply_count<target and s.result.status.value=='ongoing':
     poll();aa=sorted(s.legal_actions(),key=repr);assert aa;a=aa[rng.randrange(len(aa))];s.submit(a);moves.append(record_value(a));count['continuation_Core_edges']+=1;count['drop_commits']+=isinstance(a,SemanticDropMove);count['promotion_commits']+=isinstance(a,SemanticBoardMove)and a.promotion_target_id is not None
    tick2=time.perf_counter();aa=s.legal_actions()if s.result.status.value=='ongoing'else();legal_seconds=time.perf_counter()-tick2
    row=dict(rule=gs,family=fam,target=target,base_ply=base['prefix_completed'],base_state_sha256=base['state_sha256'],continuation_actions=list(moves),record=json.loads(serialize_game_record(s.to_record())),state_sha256=digest(s.state),witnesses_sha256=digest(s._search_witnesses),actual_ply=s.state.ply_count,result=record_value(s.result),legal_count=len(aa),drop_legal_count=sum(isinstance(a,SemanticDropMove)for a in aa),promotion_legal_count=sum(isinstance(a,SemanticBoardMove)and a.promotion_target_id is not None for a in aa),hands=record_value(s.state.position.hands),occupied=sum(pc is not None for pc in s.state.position.board),legal_seconds=legal_seconds,cumulative_continuation_seconds=time.perf_counter()-tick)
    log.write(json.dumps(row,separators=(',',':'))+'\n');log.flush();roots.append(row);count['prepared_roots']+=1
 slots=[(r['rule'],r['family'],r['target'],b,m)for r in roots for b in P['budgets']for m in P['modes']];random.Random(P['random_walk_seed']).shuffle(slots);write_json(D/'slots.json',dict(slots=slots));by={(r['rule'],r['family'],r['target']):r for r in roots}
 with(D/'queries.jsonl').open('x',encoding='utf8')as log:
  for slot,(gs,fam,target,budget,mode)in enumerate(slots):
   poll();current=dict(slot=slot,rule=gs,family=fam,target=target,budget=budget,mode=mode);root=by[gs,fam,target];row=dict(current,status='TERMINAL_NO_SEARCH'if root['result']['status']!='ongoing'else'SEARCH_RETURNED',parent_state_sha256=root['state_sha256'])
   if row['status']=='SEARCH_RETURNED':
    tick=time.perf_counter();c=compiled[gs];s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));restore=time.perf_counter()-tick;cp=LearnableMaterialCheckpoint.from_dict(mods[gs,'rule_static_v2']['checkpoint']);before=(s.state,s.to_record(),s.history,s._search_witnesses);tick=time.perf_counter();e=SemanticSearchEngine(c,native[gs],checkpoint=cp,tt_megabytes=0);init=time.perf_counter()-tick;lim=P['budgets'][budget];tick=time.perf_counter();r=e.search(s,SearchLimits(max_depth=lim['depth'],max_nodes=lim['nodes'],max_time_seconds=lim['seconds'],quiescence_max_depth=0),root_window_pruning=mode);caller=time.perf_counter()-tick
    row.update(checkpoint_id=cp.checkpoint_id,action=record_value(r.action),declaration_id=r.declaration_id,decision_line=record_value(r.decision_line),score=r.score,depth=r.completed_depth,nodes=r.nodes,qnodes=r.qnodes,cause=r.termination_reason,fallback=r.used_fallback,kernel_seconds=r.elapsed_seconds,caller_seconds=caller,restore_seconds=restore,engine_init_seconds=init,parent_unchanged=before==(s.state,s.to_record(),s.history,s._search_witnesses),root_window=r.root_window_pruning)
    log.write(json.dumps(row,separators=(',',':'))+'\n');log.flush();count['queries']+=1;count['nodes']+=r.nodes;count['usable']+=r.completed_depth>=1 and not r.used_fallback;del e;assert row['parent_unchanged']and r.root_window_pruning==mode
   else:log.write(json.dumps(row,separators=(',',':'))+'\n');log.flush()
   count['returned_slots']+=1;count[row['status']]+=1;current=None;assert log.tell()<P['max_output_bytes'],'FROZEN_OUTPUT_CAP'
except BaseException as exc:status='ERROR';error=repr(exc);traceback.print_exc()
write_json(D/'result.json',dict(status=status,error=error,counts=dict(count),planned=P['planned_slots'],returned=count['returned_slots'],missing=P['planned_slots']-count['returned_slots'],current_unclosed=current,seconds=time.perf_counter()-start,scope='Saved12rules/24baseparents, deterministicfullcontinuations to16/32/64 withterminalduplicates retained, notcompetition/learning. Fullstate/history import andquery cost; no all-domain/deeperoptimum/utilityclaim.'))
print('LATE_CLOSED',status,error,dict(count),time.perf_counter()-start)
