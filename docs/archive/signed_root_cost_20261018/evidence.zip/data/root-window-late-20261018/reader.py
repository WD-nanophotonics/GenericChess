"""Full Core continuation/PV and saved large late-state budget checks; no Native."""
from pathlib import Path
from collections import Counter
from copy import copy
import json,sys,time,hashlib,os,statistics,random
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();counts=Counter();grs=list(map(json.loads,(D/'generation.jsonl').read_bytes().splitlines()));compiled={g['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))for g in grs if 'rules'in g};mods={(r['rule'],r['label']):r for r in json.loads((D/'models.json').read_bytes())['rows']};roots={(r['rule'],r['family'],r['target']):r for r in map(json.loads,(D/'roots.jsonl').read_bytes().splitlines())};base={(r['rule'],r['family']):r for r in json.loads((D/'base-roots.json').read_bytes())['rows']};slots=json.loads((D/'slots.json').read_bytes())['slots'];qs=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));parents={};arms={}
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
def poll():
 assert time.perf_counter()-start<180,'READER_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
for gs,c in compiled.items():
 poll();v=build_ruleset_profile(c,EvaluationConfig());m=mods[gs,'rule_static_v2'];cp=LearnableMaterialCheckpoint.from_dict(m['checkpoint']);cp.validate_ruleset(c);assert cp.checkpoint_id==m['checkpoint_id']
 for t in c.types_by_id:assert cp.board_weights[t]==v.board_value_by_type[t]/1000 and cp.hand_weights[t]==v.hand_value_by_base_type[t]/1000;counts['typed_coefficients']+=1
 counts['profiles']+=1
for gs,fam in base:
 b=base[gs,fam];c=compiled[gs];s=GameSession.replay(c,deserialize_game_record(json.dumps(b['record'])));assert digest(s.state)==b['state_sha256'];rng=random.Random(P['random_walk_seed']+gs*100+fam);moves=[]
 for target in P['targets']:
  poll();r=roots[gs,fam,target]
  while s.state.ply_count<target and s.result.status.value=='ongoing':
   aa=sorted(s.legal_actions(),key=repr);a=aa[rng.randrange(len(aa))];s.submit(a);moves.append(record_value(a));counts['continuation_Core_edges']+=1
  assert moves==r['continuation_actions'];assert record_value(s.to_record())==record_value(deserialize_game_record(json.dumps(r['record'])));assert digest(s.state)==r['state_sha256']and digest(s._search_witnesses)==r['witnesses_sha256'];assert record_value(s.result)==r['result'];aa=s.legal_actions()if s.result.status.value=='ongoing'else();assert len(aa)==r['legal_count'];assert sum(isinstance(a,SemanticDropMove)for a in aa)==r['drop_legal_count'];assert sum(isinstance(a,SemanticBoardMove)and a.promotion_target_id is not None for a in aa)==r['promotion_legal_count'];assert record_value(s.state.position.hands)==r['hands'];parents[gs,fam,target]=copy(s);counts['fullparents']+=1
seen=set();diff=[]
for q in qs:
 poll();slot=q['slot'];assert slot not in seen;seen.add(slot);gs,fam,target,budget,mode=slots[slot];assert[gs,fam,target,budget,mode]==[q['rule'],q['family'],q['target'],q['budget'],q['mode']];counts['returned_slots']+=1;s=parents[gs,fam,target];r=roots[gs,fam,target];assert digest(s.state)==q['parent_state_sha256']
 if q['status']=='TERMINAL_NO_SEARCH':assert s.result.status.value!='ongoing';counts['terminal_no_search']+=1;continue
 assert q['status']=='SEARCH_RETURNED'and s.result.status.value=='ongoing';assert q['parent_unchanged']and q['root_window']==mode;cp=mods[gs,'rule_static_v2']['checkpoint'];assert q['checkpoint_id']==mods[gs,'rule_static_v2']['checkpoint_id'];assert q['qnodes']==0
 if P['budgets'][budget]['nodes']is not None:assert q['nodes']<=P['budgets'][budget]['nodes']
 leaf=copy(s)
 for raw in q['decision_line']:
  a=decode(raw)
  if isinstance(a,str):leaf.declare(a)
  else:leaf.submit(a);counts['PV_core_edges']+=1
 assert q['depth']>=1 and not q['fallback']and q['decision_line'][0]==(q['declaration_id']or q['action'])
 value=(sum((1 if pc.owner==0 else-1)*round(cp['board_weights'][pc.current_type_id]*256)for pc in leaf.state.position.board if pc is not None)+sum((leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t))*round(w*256)for t,w in cp['hand_weights'].items()))if leaf.result.status.value=='ongoing'else(0 if leaf.result.winner is None else(100000000-len(q['decision_line']))*(1 if leaf.result.winner==0 else-1))
 if value!=q['score']*(1 if s.state.position.side_to_move==0 else-1):diff.append(dict(slot=slot,literal=value,score=q['score']))
 counts['queries']+=1;counts['nodes']+=q['nodes']
 k=str(gs%100)+'_'+str(target)+'_'+budget+'_'+str(mode);a=arms.setdefault(k,dict(observed=0,nodes=0,caller_seconds=0.,kernel_seconds=0.,restore_seconds=0.,engine_init_seconds=0.,caller_max=0.,restore_max=0.,depths=Counter(),causes=Counter()))
 a['observed']+=1;a['nodes']+=q['nodes']
 for n in('caller_seconds','kernel_seconds','restore_seconds','engine_init_seconds'):a[n]+=q[n]
 a['caller_max']=max(a['caller_max'],q['caller_seconds']);a['restore_max']=max(a['restore_max'],q['restore_seconds']);a['depths'][q['depth']]+=1;a['causes'][q['cause']]+=1
done=json.loads((D/'result.json').read_bytes());assert len(qs)==done['returned']==288 and counts['queries']==280 and counts['nodes']==done['counts']['nodes'];assert counts['continuation_Core_edges']==done['counts']['continuation_Core_edges']
write_json(D/'reader-result.json',dict(status='PASS_FULL_LATE_CONTINUATIONS_AND_PV',counts=dict(counts),literal_score_mismatches=diff,seconds=time.perf_counter()-start,scope='Rebuild all24fixed randomwalk continuations/72completeparents plus280queryPVs viaCore, staticcoefficients/history/witnesses. No Native/generation/newtrajectory; not optimality/utility/all-domainproof.'))
write_json(D/'analysis.json',dict(arms=arms,planned=288,returned=288,queries=280,terminal_slots=8,missing=0,root_summary=[dict(target=t,observed=len(rr),terminal=sum(x['result']['status']!='ongoing'for x in rr),max_legal=max(x['legal_count']for x in rr),max_drop_legal=max(x['drop_legal_count']for x in rr))for t in P['targets']for rr in[[r for r in roots.values()if r['target']==t]]],literal_score_mismatches=diff,producer_seconds=done['seconds'],scope='Complete history retained; restore is cold record replay, not necessary cost for retainedSession consumers. Eightterminal nosearch slots and repeatedtrajectory dependence explicit. No Native timing rerun or utilityclaim.'))
print('LATE_READER',dict(counts),len(diff),time.perf_counter()-start)
