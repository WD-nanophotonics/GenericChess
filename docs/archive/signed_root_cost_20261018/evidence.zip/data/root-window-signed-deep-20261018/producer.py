"""Frozen60-request signed deeper-cost diagnostic; raw result precedes checks."""
from pathlib import Path
from copy import copy
from collections import Counter
import json,sys,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());I=json.loads((D/'inputs.json').read_bytes());refs={r['source_index']:r for r in json.loads((D/'references.json').read_bytes())['rows']}
start=time.perf_counter();counts=Counter();status='COMPLETE';error=None
assert not(D/'queries.jsonl').exists()
compiled={int(gs):compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r))for gs,r in I['rules'].items()};native={gs:compile_native_semantic_rules(c)for gs,c in compiled.items()}
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.perf_counter()-start<P['global_seconds'],'FROZEN_GLOBAL_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
try:
 with(D/'queries.jsonl').open('x',encoding='utf8')as log:
  for row in I['rows']:
   idx=row['source_index']
   if idx not in P['source_indices']:continue
   item=row['item'];c=compiled[item['rule']];q=item['query'];s=GameSession.replay(c,deserialize_game_record(json.dumps(q['record_before'])));cp=LearnableMaterialCheckpoint.from_dict(row['published_checkpoint']);cp.validate_ruleset(c);assert cp.board_weights['P']<0
   assert digest(s.state)==refs[idx]['parent_state_sha256']and digest(s._search_witnesses)==refs[idx]['parent_witness_sha256']
   for cap in P['caps']:
    for mode in P['modes']:
     poll();before=(s.state,s.to_record(),s.history,s._search_witnesses);e=SemanticSearchEngine(c,native[item['rule']],checkpoint=cp,tt_megabytes=P['tt']);tick=time.perf_counter();r=e.search(s,SearchLimits(max_depth=P['max_depth'],max_nodes=cap,max_time_seconds=P['query_seconds'],quiescence_max_depth=P['qdepth']),root_window_pruning=mode);elapsed=time.perf_counter()-tick
     out=dict(source_index=idx,cap=cap,mode=mode,checkpoint_id=cp.checkpoint_id,parent_state_sha256=digest(s.state),parent_unchanged=before==(s.state,s.to_record(),s.history,s._search_witnesses),action=record_value(r.action),declaration_id=r.declaration_id,decision_line=record_value(r.decision_line),score=r.score,depth=r.completed_depth,nodes=r.nodes,qnodes=r.qnodes,cause=r.termination_reason,fallback=r.used_fallback,kernel_seconds=r.elapsed_seconds,caller_seconds=elapsed,root_window=r.root_window_pruning)
     log.write(json.dumps(out,separators=(',',':'))+'\n');log.flush();counts['queries']+=1;counts['nodes']+=r.nodes;del e
     assert out['parent_unchanged']and r.root_window_pruning==mode and r.nodes<=cap and r.qnodes==0
     leaf=copy(s)
     for a in r.decision_line:
      if isinstance(a,str):leaf.declare(a)
      else:leaf.submit(a);counts['PV_core_edges']+=1
     if r.completed_depth==2 and not r.used_fallback:
      ref=refs[idx];assert ref['actions'].index(out['action'])in ref['quantized_optimal_indices'];assert r.score*(1 if s.state.position.side_to_move==0 else-1)==ref['quantized_best'];counts['completed_D2_correct']+=1
     else:counts['deeper_optimum_UNKNOWN']+=1
except BaseException as exc:status='ERROR';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,counts=dict(counts),planned=P['planned_queries'],returned=counts['queries'],missing=P['planned_queries']-counts['queries'],seconds=time.perf_counter()-start,scope='15unique full signed-negativeP contexts/60cold D8/q0/TT0 query receipts. CoreD2 optimum checks ONLY actualD2; deeper optimality UNKNOWN. No games/training/learning-gain/default claim.'))
print('SIGNED_DEEP_CLOSED',status,error,dict(counts),time.perf_counter()-start)
