"""No-Native receipt replay and paired cost analysis for frozen signed requests."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib,os,statistics
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());I=json.loads((D/'inputs.json').read_bytes());refs={r['source_index']:r for r in json.loads((D/'references.json').read_bytes())['rows']};qs=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));start=time.perf_counter();count=Counter();compiled={int(g):compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(v))for g,v in I['rules'].items()};parents={};cps={}
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.perf_counter()-start<120
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
for inp in I['rows']:
 if inp['source_index']not in P['source_indices']:continue
 poll();idx=inp['source_index'];item=inp['item'];c=compiled[item['rule']];s=GameSession.replay(c,deserialize_game_record(json.dumps(item['query']['record_before'])));cp=LearnableMaterialCheckpoint.from_dict(inp['published_checkpoint']);cp.validate_ruleset(c);assert cp.board_weights['P']<0;ref=refs[idx];assert cp.checkpoint_id==ref['checkpoint_id'];assert digest(s.state)==ref['parent_state_sha256']and digest(s._search_witnesses)==ref['parent_witness_sha256'];assert record_value(s.legal_actions())==ref['actions'];parents[idx]=s;cps[idx]=cp
seen=set();mismatches=[]
for q in qs:
 poll();idx=q['source_index'];key=(idx,q['cap'],q['mode'],q.get('requested_depth',P['max_depth']));assert key not in seen;seen.add(key);s=parents[idx];ref=refs[idx];cp=cps[idx];assert q['parent_state_sha256']==ref['parent_state_sha256']and q['parent_unchanged']and q['checkpoint_id']==cp.checkpoint_id;assert q['root_window']==q['mode']and q['nodes']<=q['cap']and q['qnodes']==0;assert not q['fallback']and q['depth']>0;leaf=copy(s)
 assert q['decision_line']and q['decision_line'][0]==(q['declaration_id']or q['action'])
 for raw in q['decision_line']:
  a=decode(raw)
  if isinstance(a,str):leaf.declare(a)
  else:leaf.submit(a);count['PV_core_edges']+=1
 value=(sum((1 if p.owner==0 else-1)*round(cp.board_weights[p.current_type_id]*256)for p in leaf.state.position.board if p is not None)+sum((leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t))*round(w*256)for t,w in cp.hand_weights.items()))if leaf.result.status.value=='ongoing'else(0 if leaf.result.winner is None else(100000000-len(q['decision_line']))*(1 if leaf.result.winner==0 else-1))
 if value!=q['score']*(1 if s.state.position.side_to_move==0 else-1):mismatches.append(dict(key=key,literal=value,served=q['score'],side=s.state.position.side_to_move))
 if q['depth']==2:
  assert ref['actions'].index(q['action'])in ref['quantized_optimal_indices'];assert q['score']*(1 if s.state.position.side_to_move==0 else-1)==ref['quantized_best'];count['complete_D2_optima']+=1
 else:count['deeper_optimum_UNKNOWN']+=1
 count['queries']+=1;count['nodes']+=q['nodes']
done=json.loads((D/'result.json').read_bytes());assert count['queries']==done['returned']and count['nodes']==done['counts']['nodes'];assert len(qs)==P['planned_queries']and done['status']=='COMPLETE'
arms=[];pairs=[]
for cap in P['caps']:
 for mode in P['modes']:
  for target in P.get('max_depths',[P['max_depth']]):
   qq=[q for q in qs if q['cap']==cap and q['mode']==mode and q.get('requested_depth',P['max_depth'])==target]
   overhead=[q['caller_seconds']-q['kernel_seconds']for q in qq]
   arms.append(dict(cap=cap,mode=mode,target=target,returned=len(qq),depths=dict(Counter(q['depth']for q in qq)),nodes=sum(q['nodes']for q in qq),kernel_seconds=sum(q['kernel_seconds']for q in qq),caller_seconds=sum(q['caller_seconds']for q in qq),overhead_seconds=sum(overhead),overhead_median=statistics.median(overhead),causes=dict(Counter(q['cause']for q in qq))))
by={(q['source_index'],q['cap'],q.get('requested_depth',P['max_depth']),q['mode']):q for q in qs}
for idx in P['source_indices']:
 for cap in P['caps']:
  for target in P.get('max_depths',[P['max_depth']]):
   a=by[idx,cap,target,False];b=by[idx,cap,target,True]
   pairs.append(dict(source_index=idx,cap=cap,target=target,depth_False=a['depth'],depth_True=b['depth'],action_equal=a['action']==b['action'],score_equal=a['score']==b['score'],node_ratio=b['nodes']/a['nodes'],caller_ratio=b['caller_seconds']/a['caller_seconds'],both_requested_complete=a['depth']==b['depth']==target))
write_json(D/'reader-result.json',dict(status='PASS_SIGNED_DEEP_RECEIPTS',counts=dict(count),literal_PV_score_mismatches=mismatches,seconds=time.perf_counter()-start,scope='Core fullparent/history/checkpoint/PV legality plus separatelyrecorded literalvalues; equaldepth scorecomparison is not externalrules/minimax/WDL/learningproof. D2reference usedonly actualD2.'))
write_json(D/'analysis.json',dict(arms=arms,pairs=pairs,literal_PV_score_mismatches=mismatches,scope='Saved samecontext pairs; differentdepth actions/scores notquality orsameobjective comparisons. Alloriginal paidcosts retained; no Native execution here.'))
print('SIGNED_DEEP_READER',dict(count),len(mismatches),time.perf_counter()-start)
