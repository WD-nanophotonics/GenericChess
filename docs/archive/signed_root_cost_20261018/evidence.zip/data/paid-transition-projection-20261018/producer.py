"""Actual public search+checked-submit A/B, complete later parents and allfields."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,random,hashlib,dataclasses,importlib.util
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();counts=Counter();status='COMPLETE';error=None;classes={};games={}
for mode in P['modes']:
 p=D/(mode+'.py');assert hashlib.sha256(p.read_text().encode()).hexdigest()==P[mode+'_sha256'];name='generic_chess.native._paid_'+mode;spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);classes[mode]=m.SemanticSearchEngine
compiled={g['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))for g in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines())if'rules'in g};native={gs:compile_native_semantic_rules(c)for gs,c in compiled.items()};models={r['rule']:r for r in json.loads((D/'models.json').read_bytes())['rows']};roots=[r for r in map(json.loads,(D/'roots.jsonl').read_bytes().splitlines())if r['family']==P['family']and r['target']in P['targets']];assert len(roots)==36;seen={}
assert not(D/'queries.jsonl').exists()
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.perf_counter()-start<P['global_seconds'],'FROZEN_GLOBAL_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
try:
 with(D/'queries.jsonl').open('x',encoding='utf8')as qlog,(D/'episodes.jsonl').open('x',encoding='utf8')as elog:
  for root in roots:
   gs=root['rule'];c=compiled[gs];cp=LearnableMaterialCheckpoint.from_dict(models[gs]['checkpoint']);engines={mode:cls(c,native[gs],checkpoint=cp,tt_megabytes=0)for mode,cls in classes.items()}
   for rep in range(P['repeats']):
    modes=list(P['modes']);random.Random(P['order_seed']+gs+root['target']*10+rep).shuffle(modes)
    for mode in modes:
     poll();tick=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));restore=time.perf_counter()-tick;assert digest(s.state)==root['state_sha256']and digest(s._search_witnesses)==root['witnesses_sha256'];searchsum=commitsum=0.;nq=0
     for ply in range(P['plies']):
      poll()
      if s.result.status.value!='ongoing':break
      before=(s.state,s.to_record(),s.history,s._search_witnesses);tick=time.perf_counter();r=engines[mode].search(s,SearchLimits(max_depth=P['max_depth'],max_nodes=P['max_nodes'],max_time_seconds=P['max_time_seconds'],quiescence_max_depth=0),root_window_pruning=True);call=time.perf_counter()-tick;assert before==(s.state,s.to_record(),s.history,s._search_witnesses);tick=time.perf_counter()
      if r.declaration_id is not None:s.declare(r.declaration_id)
      elif r.action is not None:s.submit(r.action)
      commit=time.perf_counter()-tick;fields=record_value(dataclasses.asdict(r));out=dict(rule=gs,target=root['target'],rep=rep,mode=mode,relative_ply=ply,source_state_sha256=root['state_sha256'],search_seconds=call,submit_seconds=commit,full_child_state=record_value(s.state),child_state_sha256=digest(s.state),child_record=record_value(s.to_record()),child_history=record_value(s.history),child_witnesses_sha256=digest(s._search_witnesses),result=fields)
      qlog.write(json.dumps(out,separators=(',',':'))+'\n');qlog.flush();counts['queries']+=1;counts['nodes']+=r.nodes;nq+=1;searchsum+=call;commitsum+=commit
      stable={k:v for k,v in out.items()if k not in('rep','mode','search_seconds','submit_seconds')};stable['result']={k:v for k,v in fields.items()if'elapsed'not in k};key=(gs,root['target'],ply)
      if key in seen:assert seen[key]==stable,('PAID_CONSUMER_DIFFERENCE',key)
      else:seen[key]=stable
      assert r.completed_depth==2 and not r.used_fallback,'UNFINISHED_TARGET'
      assert qlog.tell()<P['max_output_bytes']
     e=dict(rule=gs,target=root['target'],rep=rep,mode=mode,queries=nq,search_seconds=searchsum,submit_seconds=commitsum,restore_seconds=restore,final_state_sha256=digest(s.state),final_result=record_value(s.result));elog.write(json.dumps(e,separators=(',',':'))+'\n');elog.flush();counts['episode_slots']+=1
   del engines
except BaseException as exc:status='ERROR';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,counts=dict(counts),planned_episode_slots=216,returned_episode_slots=counts['episode_slots'],missing=216-counts['episode_slots'],seconds=time.perf_counter()-start,scope='Existing12widerules/36parent slots,actualtwo-step fullsearch+Corecommit pairedcopies; allfields/completechildren fixed. No newrules/training/matches/qualityclaim, terminalslots retained.'))
print('PAID_TRANSITION_CLOSED',status,error,dict(counts),time.perf_counter()-start)
