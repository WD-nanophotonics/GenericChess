"""No-Native full-child replay and paid public-consumer pair accounting."""
from pathlib import Path
from copy import copy
from collections import Counter
import json,sys,time,hashlib,os,statistics
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();count=Counter();qs=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));episodes=list(map(json.loads,(D/'episodes.jsonl').read_bytes().splitlines()));compiled={g['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))for g in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines())if'rules'in g};roots={(r['rule'],r['target']):r for r in map(json.loads,(D/'roots.jsonl').read_bytes().splitlines())if r['family']==1};parents={};by={};unique=set()
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
def poll():
 assert time.perf_counter()-start<180
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
for key,r in roots.items():
 poll();s=GameSession.replay(compiled[key[0]],deserialize_game_record(json.dumps(r['record'])));assert digest(s.state)==r['state_sha256']and digest(s._search_witnesses)==r['witnesses_sha256'];parents[key]=s
for q in qs:
 key=(q['rule'],q['target'],q['rep'],q['mode']);by.setdefault(key,[]).append(q)
stable={}
for e in episodes:
 poll();key=(e['rule'],e['target'],e['rep'],e['mode']);s=copy(parents[e['rule'],e['target']]);qq=sorted(by.get(key,[]),key=lambda q:q['relative_ply']);assert len(qq)==e['queries']
 for q in qq:
  unique.add((q['rule'],digest(s.state),digest(s._search_witnesses)));r=q['result'];assert r['completed_depth']==2 and not r['used_fallback']and r['root_window_pruning']
  decision=r['declaration_id']or r['action'];assert decision is not None
  if isinstance(decision,str):s.declare(decision)
  else:s.submit(decode(decision));count['Core_commits']+=1
  assert record_value(s.state)==q['full_child_state']and digest(s.state)==q['child_state_sha256'];assert record_value(s.to_record())==q['child_record'];assert record_value(s.history)==q['child_history']and digest(s._search_witnesses)==q['child_witnesses_sha256']
  scientific={k:v for k,v in q.items()if k not in('rep','mode','search_seconds','submit_seconds')};scientific['result']={k:v for k,v in r.items()if'elapsed'not in k};sk=(q['rule'],q['target'],q['relative_ply'])
  if sk in stable:assert stable[sk]==scientific
  else:stable[sk]=scientific
  count['queries']+=1;count['nodes']+=r['nodes']
 assert digest(s.state)==e['final_state_sha256']and record_value(s.result)==e['final_result'];count['episode_slots']+=1;count['terminal_nosearch']+=not qq
done=json.loads((D/'result.json').read_bytes());assert done['status']=='COMPLETE'and count['queries']==414 and count['episode_slots']==216 and count['nodes']==done['counts']['nodes']
arms={}
for mode in P['modes']:
 q=[r for r in qs if r['mode']==mode];ee=[r for r in episodes if r['mode']==mode];search=sum(r['search_seconds']for r in q);submit=sum(r['submit_seconds']for r in q);restore=sum(r['restore_seconds']for r in ee)
 arms[mode]=dict(queries=len(q),nodes=sum(r['result']['nodes']for r in q),search_seconds=search,submit_seconds=submit,retained_search_submit_seconds=search+submit,cold_restore_seconds=restore,cold_restore_search_submit_seconds=search+submit+restore,kernel_seconds=sum(r['result']['elapsed_seconds']for r in q),episode_slots=len(ee),terminal_nosearch=sum(r['queries']==0 for r in ee))
ratios={k:arms['candidate'][k]/arms['baseline'][k]for k in('search_seconds','retained_search_submit_seconds','cold_restore_search_submit_seconds')}
write_json(D/'reader-result.json',dict(status='PASS_PAID_CONSUMER_ALL_FIELDS_AND_FULL_CHILDREN',counts=dict(count),unique_fullparent_witness_contexts=len(unique),seconds=time.perf_counter()-start,scope='All414actualresults/216episodes retaincompletechildren/history/witnesses/records;3repeats/bothcodecopies notindependentstates. No Nativequery ornewmatch/qualityclaim.'))
write_json(D/'analysis.json',dict(arms=arms,candidate_baseline_ratios=ratios,planned_episode_slots=216,returned=216,paired_query_results=207,unique_fullparent_witness_contexts=len(unique),producer_seconds=done['seconds'],scope='RetainedSession search+actualCorecheckedsubmit differsfromcoldrecordrestore. Wideractualpipeline gain notextrapolatedfrom26percentcheap4boardcall; originalNativecostsnotremeasured.'))
print('PAID_CONSUMER_READER',dict(count),len(unique),ratios,time.perf_counter()-start)
