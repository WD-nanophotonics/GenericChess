"""Full-field pairs, immutable candidate-source delta and saved-cost arithmetic."""
from pathlib import Path
import json,statistics,hashlib,re
import sys;sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());q=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));by={(x['source_index'],x['target'],x['rep'],x['mode']):x for x in q}
old=(D/'baseline.py').read_text();new=(D/'candidate.py').read_text()
assert hashlib.sha256(old.encode()).hexdigest()==P['baseline_sha256']and hashlib.sha256(new.encode()).hexdigest()==P['candidate_sha256']
assert len(old.splitlines())==len(new.splitlines());changes=[(a,b)for a,b in zip(old.splitlines(),new.splitlines())if a!=b];assert len(changes)==P['changed_conversions']==12
for a,b in changes:
 m=re.search(r'tuple\(int\(value\) for value in raw\.get\((".*?", \(\))\)\)',a);assert m
 assert b==a[:m.start()]+'tuple(map(int, raw.get('+m.group(1)+')))'+a[m.end():]
count=0;arrays=set()
for idx in P['source_indices']:
 for dep in P['max_depths']:
  for rep in range(P['repeats']):
   a=by[idx,dep,rep,'baseline'];b=by[idx,dep,rep,'candidate'];assert a['parent_unchanged']and b['parent_unchanged'];stable=lambda r:{k:v for k,v in r.items()if 'elapsed'not in k};assert stable(a['result'])==stable(b['result']);count+=1
   for k,v in a['result'].items():
    if k.endswith('_by_ply')or k=='ordering_skipped_by_remaining_depth':assert len(v)==1025 and all(type(x)is int for x in v);arrays.add(k)
arms=[]
for dep in P['max_depths']:
 z={}
 for m in P['modes']:
  aa=[x for x in q if x['target']==dep and x['mode']==m];z[m]=dict(calls=len(aa),caller_seconds=sum(x['caller_seconds']for x in aa),kernel_seconds=sum(x['result']['elapsed_seconds']for x in aa),nodes=sum(x['result']['nodes']for x in aa),caller_median=statistics.median(x['caller_seconds']for x in aa))
 pairs=[(by[idx,dep,rep,'baseline'],by[idx,dep,rep,'candidate'])for idx in P['source_indices']for rep in range(P['repeats'])]
 z.update(target=dep,caller_ratio=z['candidate']['caller_seconds']/z['baseline']['caller_seconds'],paired_median_ratio=statistics.median(b['caller_seconds']/a['caller_seconds']for a,b in pairs),candidate_faster_pairs=sum(b['caller_seconds']<a['caller_seconds']for a,b in pairs));arms.append(z)
assert len(arrays)==12 and len(q)==180
decision=arms[0]['caller_ratio']<=.9 and arms[1]['caller_ratio']<=1.1
write_json(D/'analysis.json',dict(status='PASS_FULL_FIELDS_AND_COST',paired_calls=count,array_fields=sorted(arrays),retained_length_each=1025,arms=arms,adopt_candidate=decision,new_product_API=False,scope='All180actualcalls/90fullnonruntimefield pairs match;12full1025elementintarrays retained. Randominterleaving/3repeats scoped15contexts, ordinaryconcurrentload; no universalspeed/learningclaim.'))
print('PROJECTION_READER',len(q),decision)
