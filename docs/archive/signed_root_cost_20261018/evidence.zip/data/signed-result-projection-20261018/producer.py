"""Paired full-result public search benchmark, actual code copies and fullfields."""
from pathlib import Path
import sys,json,time,random,hashlib,importlib.util,dataclasses
from collections import Counter
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());I=json.loads((D/'inputs.json').read_bytes());start=time.perf_counter();count=Counter();seen={};status='COMPLETE';error=None;classes={}
for mode in P['modes']:
 p=D/(mode+'.py');assert hashlib.sha256(p.read_text().encode()).hexdigest()==P[mode+'_sha256'];name='generic_chess.native._bench_'+mode;spec=importlib.util.spec_from_file_location(name,p);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);classes[mode]=module.SemanticSearchEngine
compiled={int(g):compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(v))for g,v in I['rules'].items()};native={g:compile_native_semantic_rules(c)for g,c in compiled.items()}
assert not(D/'queries.jsonl').exists()
def poll():
 assert time.perf_counter()-start<P['global_seconds'],'FROZEN_GLOBAL_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
try:
 with(D/'queries.jsonl').open('x',encoding='utf8')as log:
  for inp in I['rows']:
   idx=inp['source_index']
   if idx not in P['source_indices']:continue
   item=inp['item'];c=compiled[item['rule']];s=GameSession.replay(c,deserialize_game_record(json.dumps(item['query']['record_before'])));cp=LearnableMaterialCheckpoint.from_dict(inp['published_checkpoint']);engines={m:cls(c,native[item['rule']],checkpoint=cp,tt_megabytes=0)for m,cls in classes.items()}
   for dep in P['max_depths']:
    for rep in range(P['repeats']):
     modes=list(P['modes']);random.Random(P['order_seed']+idx*100+dep*10+rep).shuffle(modes)
     for mode in modes:
      poll();before=(s.state,s.to_record(),s.history,s._search_witnesses);tick=time.perf_counter();r=engines[mode].search(s,SearchLimits(max_depth=dep,max_nodes=131072,max_time_seconds=.5,quiescence_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-tick;fields=record_value(dataclasses.asdict(r));q=dict(source_index=idx,target=dep,rep=rep,mode=mode,caller_seconds=elapsed,parent_unchanged=before==(s.state,s.to_record(),s.history,s._search_witnesses),result=fields)
      log.write(json.dumps(q,separators=(',',':'))+'\n');log.flush();count['queries']+=1;count['nodes']+=r.nodes;assert q['parent_unchanged']and r.completed_depth==dep and not r.used_fallback
      stable={k:v for k,v in fields.items()if 'elapsed'not in k};key=(idx,dep)
      if key in seen:assert stable==seen[key],('RESULT_FIELDS_DIFFER',idx,dep,rep,mode)
      else:seen[key]=stable
      assert log.tell()<P['max_output_bytes'],'FROZEN_OUTPUT_CAP'
   del engines
except BaseException as exc:status='ERROR';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,counts=dict(count),returned=count['queries'],planned=P['planned_queries'],seconds=time.perf_counter()-start,scope='12existing tuple conversions only,allresultfields/parents/q0TT0 preserved. Timing fields retainedbutnotexactequalitytargets; no kernel/API/default/learning/fitnesschange.'))
print('PROJECTION_CLOSED',status,error,dict(count),time.perf_counter()-start)
