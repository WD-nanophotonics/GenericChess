"""Analyze saved timed-wrapper calls, linking unchanged outputs to qualified controls."""
from pathlib import Path
import json,statistics,time
import sys;sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());qs=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));control=list(map(json.loads,(D/'control-D2.jsonl').read_bytes().splitlines()))+list(map(json.loads,(D/'control-D6.jsonl').read_bytes().splitlines()));counts={}
for q in qs:
 candidates=[x for x in control if x['source_index']==q['source_index']and x['mode']and x.get('requested_depth',x['depth'])==q['target']and x['depth']==q['target']]
 assert candidates and q['parent_unchanged'];ref=candidates[0]
 for key in('depth','nodes','score','action','decision_line','declaration_id'):assert q[key]==ref[key]
 assert q['component_calls']==dict(full_history_pack=1,public_action_decode=1+len(q['decision_line'])+q['depth'],returned_leaf_dynamic_features=1)or q['component_calls']['full_history_pack']==q['component_calls']['returned_leaf_dynamic_features']==1
 assert q['target']==q['depth']and not q['fallback']
arms=[]
for dep in P['max_depths']:
 q=[x for x in qs if x['target']==dep];ks=('full_history_pack','public_action_decode','returned_leaf_dynamic_features')
 arms.append(dict(target=dep,calls=len(q),caller_seconds=sum(x['caller_seconds']for x in q),kernel_seconds=sum(x['kernel_seconds']for x in q),components={k:sum(x['profiled_components'].get(k,0)for x in q)for k in ks},median_component_fraction={k:statistics.median(x['profiled_components'].get(k,0)/x['caller_seconds']for x in q)for k in ks}))
assert len(qs)==P['planned_queries']==90
write_json(D/'analysis.json',dict(status='PASS_PROFILE_OUTPUT_LINKS',queries=len(qs),arms=arms,scope='All90scientificoutputs match previouslyqualifiedsameparent controls; wrappers addcost, no instrumentedspeedclaim. Unassignedresidual notcausallyattributed toonefunction. No field/API removal.'))
print('COMPONENT_READER',len(qs))
