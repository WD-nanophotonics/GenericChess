"""Bounded component profile of existing full-result signed consumer; no product edits."""
from pathlib import Path
from collections import Counter,defaultdict
from copy import copy
import sys,json,time,functools,random
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
import generic_chess.native.semantic_engine as em
import generic_chess.native.semantic as sm
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());I=json.loads((D/'inputs.json').read_bytes());start=time.perf_counter();status='COMPLETE';error=None;count=Counter();seen={};totals=defaultdict(float);calls=Counter();originals=[]
assert not(D/'queries.jsonl').exists()
compiled={int(g):compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r))for g,r in I['rules'].items()};native={g:compile_native_semantic_rules(c)for g,c in compiled.items()}
def poll():
 assert time.perf_counter()-start<P['global_seconds'],'FROZEN_GLOBAL_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
def wrapped(obj,name,label):
 fn=getattr(obj,name);originals.append((obj,name,fn))
 @functools.wraps(fn)
 def timed(*a,**kw):
  t=time.perf_counter()
  try:return fn(*a,**kw)
  finally:totals[label]+=time.perf_counter()-t;calls[label]+=1
 setattr(obj,name,timed)
 return fn
try:
 wrapped(em,'pack_semantic_search_position','full_history_pack')
 wrapped(em,'public_action','public_action_decode')
 wrapped(sm,'dynamic_features','returned_leaf_dynamic_features')
 with(D/'queries.jsonl').open('x',encoding='utf8')as log:
  for row in I['rows']:
   idx=row['source_index']
   if idx not in P['source_indices']:continue
   poll();item=row['item'];c=compiled[item['rule']];tick=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(item['query']['record_before'])));restore=time.perf_counter()-tick;cp=LearnableMaterialCheckpoint.from_dict(row['published_checkpoint']);tick=time.perf_counter();e=SemanticSearchEngine(c,native[item['rule']],checkpoint=cp,tt_megabytes=0);init=time.perf_counter()-tick
   slots=[(rep,dep)for rep in range(P['repeats'])for dep in P['max_depths']];random.Random(P['order_seed']+idx).shuffle(slots)
   for rep,depth in slots:
    poll();totals.clear();calls.clear();before=(s.state,s.to_record(),s.history,s._search_witnesses);tick=time.perf_counter();r=e.search(s,SearchLimits(max_depth=depth,max_nodes=131072,max_time_seconds=.5,quiescence_max_depth=0),root_window_pruning=True);caller=time.perf_counter()-tick
    q=dict(source_index=idx,rep=rep,target=depth,depth=r.completed_depth,nodes=r.nodes,score=r.score,action=record_value(r.action),decision_line=record_value(r.decision_line),declaration_id=r.declaration_id,kernel_seconds=r.elapsed_seconds,caller_seconds=caller,profiled_components=dict(totals),component_calls=dict(calls),cause=r.termination_reason,fallback=r.used_fallback,restore_once_seconds=restore,engine_once_seconds=init,parent_unchanged=before==(s.state,s.to_record(),s.history,s._search_witnesses))
    log.write(json.dumps(q,separators=(',',':'))+'\n');log.flush();count['queries']+=1;count['nodes']+=r.nodes;assert q['parent_unchanged']and not r.used_fallback and r.completed_depth==depth;key=(idx,depth);scientific={k:q[k]for k in('depth','nodes','score','action','decision_line','declaration_id')}
    if key in seen:assert seen[key]==scientific
    else:seen[key]=scientific
   del e
except BaseException as exc:status='ERROR';error=repr(exc)
finally:
 for obj,name,fn in reversed(originals):setattr(obj,name,fn)
write_json(D/'result.json',dict(status=status,error=error,counts=dict(count),returned=count['queries'],planned=P['planned_queries'],seconds=time.perf_counter()-start,scope='Existingpublicfullresult consumer onretainedSessions/engineTT0,90timedwrappercalls, no field removal/API/default/productfile changes. Instrumentedwallincludeswrapperoverhead; not oldunprofiledspeed rerun orlearninggain.'))
print('COMPONENT_CLOSED',status,error,dict(count),time.perf_counter()-start)
