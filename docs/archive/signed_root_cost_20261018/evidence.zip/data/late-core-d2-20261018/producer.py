"""Optional frozen full Core D2 reference on12late largeboard parents."""
from pathlib import Path
from collections import Counter
import sys,json,time,hashlib,traceback
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.core.transition import apply_action,legal_actions
D=Path(__file__).resolve().parent;P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();counts=Counter();status='COMPLETE';error=None;current=None
grs=list(map(json.loads,(D/'saved-generation.jsonl').read_bytes().splitlines()));compiled={g['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))for g in grs if 'rules'in g};mods={r['rule']:r for r in json.loads((D/'saved-models.json').read_bytes())['rows']};roots={(r['rule'],r['family'],r['target']):r for r in map(json.loads,(D/'saved-roots.jsonl').read_bytes().splitlines())};qs=list(map(json.loads,(D/'saved-queries.jsonl').read_bytes().splitlines()))
assert not(D/'references.jsonl').exists()
def poll():
 assert time.perf_counter()-start<P['global_seconds'],'FROZEN_GLOBAL_CAP'
 assert counts['edges']<P['edge_cap'],'FROZEN_EDGE_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
def leaf(st,cp,dist):
 if st.terminal_status.is_terminal:
  w=st.terminal_status.winner;return 0 if w is None else(100000000-dist)*(1 if w==0 else-1)
 return sum((1 if pc.owner==0 else-1)*round(cp.board_weights[pc.current_type_id]*256)for pc in st.position.board if pc is not None)+sum((st.position.hands[0].count(t)-st.position.hands[1].count(t))*round(w*256)for t,w in cp.hand_weights.items())
try:
 with(D/'references.jsonl').open('x',encoding='utf8')as log:
  for select in P['selected_roots']:
   poll();gs=select['rule'];fam=select['family'];target=select['target'];current=dict(select);r=roots[gs,fam,target];c=compiled[gs];tick=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(r['record'])));cp=LearnableMaterialCheckpoint.from_dict(mods[gs]['checkpoint']);cp.validate_ruleset(c);assert not s.available_declarations();aa=s.legal_actions();vv=[];rows=[];before=counts['edges']
   for a in aa:
    poll();ch=apply_action(s.state,a,c);counts['edges']+=1
    if ch.terminal_status.is_terminal:v=leaf(ch,cp,1);values=[]
    else:
     bb=legal_actions(ch,c);values=[]
     for b in bb:
      poll();st=apply_action(ch,b,c);counts['edges']+=1;values.append(leaf(st,cp,2))
     assert values;v=(max if ch.position.side_to_move==0 else min)(values)
    vv.append(v);rows.append(dict(action=record_value(a),value=v,reply_values=values))
   fn=max if s.state.position.side_to_move==0 else min;best=fn(vv);opts=[i for i,v in enumerate(vv)if v==best];matched=[];other=[]
   for q in qs:
    if(q['rule'],q['family'],q['target'])!=(gs,fam,target):continue
    if q.get('depth')==2 and not q.get('fallback'):
     assert record_value(aa).index(q['action'])in opts and q['score']*(1 if s.state.position.side_to_move==0 else-1)==best,('D2_MISMATCH',select,q['slot']);matched.append(q['slot']);counts['matched_D2_receipts']+=1
    else:other.append(q['slot']);counts['otherdepth_uncompared']+=1
   out=dict(select,status='COMPLETE',checkpoint_id=cp.checkpoint_id,parent_state_sha256=r['state_sha256'],parent_witness_sha256=r['witnesses_sha256'],root_actions=record_value(aa),action_values=vv,best=best,optimal_indices=opts,complete_children=rows,edges=counts['edges']-before,matched_D2_slots=matched,other_depth_slots=other,seconds=time.perf_counter()-tick)
   log.write(json.dumps(out,separators=(',',':'))+'\n');log.flush();counts['complete_roots']+=1;current=None;assert log.tell()<P['max_output_bytes'],'FROZEN_OUTPUT_CAP';print('CORE_ROOT',select,counts['edges'],round(time.perf_counter()-start,3),flush=True)
except BaseException as exc:status='CAPPED'if isinstance(exc,AssertionError)and'FROZEN'in str(exc)else'ERROR';error=repr(exc);traceback.print_exc()
write_json(D/'result.json',dict(status=status,error=error,counts=dict(counts),planned_roots=12,complete_roots=counts['complete_roots'],unfinished_UNKNOWN=12-counts['complete_roots'],current_partial=current,seconds=time.perf_counter()-start,scope='CompleteCoreD2integerenumeration only on12fixedlateparents; allpaidpartialedgeskept, no Nativequery/training orall-domain/WDLclaim. DeeperorD1 receipts notcompared toD2.'))
print('LATE_CORE_CLOSED',status,error,dict(counts),time.perf_counter()-start)
