"""Re-enumerate only CLOSED Core reference frontiers; never refill a capped tail."""
from pathlib import Path
from collections import Counter
import sys,json,time,os
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.core.transition import apply_action,legal_actions
D=Path(__file__).resolve().parent;start=time.perf_counter();count=Counter();P=json.loads((D/'plan.json').read_bytes());done=json.loads((D/'result.json').read_bytes());refs=list(map(json.loads,(D/'references.jsonl').read_bytes().splitlines()));grs=list(map(json.loads,(D/'saved-generation.jsonl').read_bytes().splitlines()));compiled={g['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))for g in grs if 'rules'in g};mods={r['rule']:r for r in json.loads((D/'saved-models.json').read_bytes())['rows']};roots={(r['rule'],r['family'],r['target']):r for r in map(json.loads,(D/'saved-roots.jsonl').read_bytes().splitlines())};qs={q['slot']:q for q in map(json.loads,(D/'saved-queries.jsonl').read_bytes().splitlines())}
def poll():
 assert time.perf_counter()-start<1200,'CLOSED_REFERENCE_READER_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def leaf(st,cp,dist):
 if st.terminal_status.is_terminal:
  w=st.terminal_status.winner;return 0 if w is None else(100000000-dist)*(1 if w==0 else-1)
 return sum((1 if pc.owner==0 else-1)*round(cp.board_weights[pc.current_type_id]*256)for pc in st.position.board if pc is not None)+sum((st.position.hands[0].count(t)-st.position.hands[1].count(t))*round(w*256)for t,w in cp.hand_weights.items())
seen=set()
for ref in refs:
 poll();key=(ref['rule'],ref['family'],ref['target']);assert key not in seen;seen.add(key);assert ref['status']=='COMPLETE';c=compiled[key[0]];r=roots[key];s=GameSession.replay(c,deserialize_game_record(json.dumps(r['record'])));cp=LearnableMaterialCheckpoint.from_dict(mods[key[0]]['checkpoint']);cp.validate_ruleset(c);assert cp.checkpoint_id==ref['checkpoint_id'];aa=s.legal_actions();assert record_value(aa)==ref['root_actions'];vv=[];edge0=count['edges']
 for j,a in enumerate(aa):
  poll();ch=apply_action(s.state,a,c);count['edges']+=1
  if ch.terminal_status.is_terminal:v=leaf(ch,cp,1);values=[]
  else:
   values=[]
   for b in legal_actions(ch,c):
    poll();x=apply_action(ch,b,c);count['edges']+=1;values.append(leaf(x,cp,2))
   v=(max if ch.position.side_to_move==0 else min)(values)
  assert values==ref['complete_children'][j]['reply_values']and v==ref['complete_children'][j]['value'];vv.append(v)
 assert vv==ref['action_values'];best=(max if s.state.position.side_to_move==0 else min)(vv);opts=[i for i,v in enumerate(vv)if v==best];assert best==ref['best']and opts==ref['optimal_indices']and count['edges']-edge0==ref['edges']
 for slot in ref['matched_D2_slots']:
  q=qs[slot];assert q['depth']==2 and q['score']*(1 if s.state.position.side_to_move==0 else-1)==best and ref['root_actions'].index(q['action'])in opts;count['matched_D2_receipts']+=1
 count['complete_roots']+=1;print('CLOSED_REF_CHECK',key,count['edges'],round(time.perf_counter()-start,3),flush=True)
assert len(refs)==done['complete_roots']and done['unfinished_UNKNOWN']==12-len(refs)and count['edges']==sum(r['edges']for r in refs)
write_json(D/'reader-result.json',dict(status='PASS_CLOSED_CORE_D2_FRONTIERS',counts=dict(count),original_unfinished_UNKNOWN=done['unfinished_UNKNOWN'],original_paid_edges=done['counts']['edges'],replayed_closed_edges=count['edges'],seconds=time.perf_counter()-start,scope='Freshsource Core enumeratesonlyclosedfrontiers/fulllegalreplysets, notcapped/unstartedroots. Originalpaidpartialcost/UNKNOWNretained; no Nativecalls orWDL/all-domainproof.'))
print('CLOSED_CORE_READER',dict(count),time.perf_counter()-start)
