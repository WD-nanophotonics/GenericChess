from pathlib import Path
import json
P=Path('.local_agent/local-control-20261016');s=(P/'finite_alias.py').read_text()
s=s.replace('finite-alias-plan.json','finite-alias-v2-plan.json').replace('finite-alias-results.json','finite-alias-v2-results.json')
s=s.replace("while not t.result.is_terminal:","while not t.state.terminal_status.is_terminal:")
s=s.replace("start=time.perf_counter();rows=[];runs=[];bvs=","start=time.perf_counter();rows=[];runs=[];querylog=(P/'finite-alias-v2-queries.jsonl').open('x',encoding='utf-8');bvs=")
s=s.replace("t=copy(s);trace=[]","querylog.write(json.dumps(rows[-1])+'\\n');querylog.flush()\n t=copy(s);trace=[]")
s=s.replace("write_record(P/'finite-alias-v2-results.json',out);","querylog.close();write_record(P/'finite-alias-v2-results.json',out);")
s=s.replace("changed_premise='Actual9featurecostimproved,","changed_premise='Correctedqualification afteroriginalharness AttributeError onSessionResult.is_terminal following2querycalls withMISSINGreceipts. Originalfailed30s jobnotrewritten orclaimedcomplete; thisnew<=30s qualification usesSAMEfinite4ply/4096/3s caps andimmediaterow append, noextra labelselection. Actual9featurecostimproved,")
(P/'finite_alias_v2.py').write_bytes(s.encode())
(P/'finite-alias-failure.json').write_bytes(json.dumps(dict(original='finite_alias.py',log='finite-alias.log',actual_native_and_core_query_calls_before_failure=2,missing_query_receipts=2,retained_query_receipts=0,cause='SessionResult has no is_terminal; use GameState.terminal_status.is_terminal',old_job_complete=False,corrected_job='finite_alias_v2.py',scope='Distinctboundedmechanicalqualification withsameperquerycaps; do not include oldmissingcalls inretained/replaycount, do not claim originalscientificcap extended or allresultsretained.'),indent=2).encode())
