from pathlib import Path
import json
R=Path.cwd();P=R/'.local_agent/local-control-20261016';A=R/'.local_agent/attack-membership-20261016'
s=(A/'core_validation.py').read_text().replace("P=R/'.local_agent/attack-membership-20261016'","P=R/'.local_agent/local-control-20261016'")
s=s.replace("P/'final_native_core.pyd'","R/'.local_agent/attack-membership-20261016/leaf_native_core.pyd'")
a=s.index('plan=dict(');b=s.index("(P/'core-plan.json')",a)
s=s[:a]+"""plan=dict(question='Does independent pureCore finite search corroborate the changed actuallocalized-control leaf, not merely baselineNative?',inputs='Exposed qualification: fixed first2ID families perboard in current32family panel, retain tails/no replacement. Notunexposedvalidation or sameobjectiveasstaticpastCore.',cases=[114401,114402,114801,114802,115201,115202,115601,115602],depth=3,nodes=131072,seconds=30,whole_seconds=480,expected_seconds=240,profile='static exactsameboard/handplusfixedcontrol9=(1,0,0,0,0,0,0,0,-1),qTT0',decision='Anyjointcomplete-score mismatch stopsadoption; Corecensors UNKNOWN. IndependentPythonenumeration/search sharesCorecompiler/featuredefinition butnotCkernel. No solver/WDL/strength/all-domainclaim.',scope='8preselectedpureCoreAlphaBeta/NativeD3 pairs; newactiveprofileconditionalcorrectness test, notextendingoriginal8sD4cap. Singlejob<1hour, noAUXexecution.')
"""+s[b:]
s=s.replace("def __init__(self,bv,hv):self.bv=bv;self.hv=hv","def __init__(self,bv,hv,c):self.bv=bv;self.hv=hv;self.c=c")
s=s.replace("return sum((1 if x.owner==side else-1)*self.bv[x.current_type_id]for x in s.position.board if x is not None)+sum((1 if owner==side else-1)*self.hv[t]*n for owner,hand in enumerate(s.position.hands)for t,n in hand.items())","material=sum((1 if x.owner==side else-1)*self.bv[x.current_type_id]for x in s.position.board if x is not None)+sum((1 if owner==side else-1)*self.hv[t]*n for owner,hand in enumerate(s.position.hands)for t,n in hand.items())\n  controls=localized_control_features(s.position,self.c)\n  return max(-90000000,min(90000000,material+(1 if side==0 else -1)*(controls[0]-controls[-1])))")
s=s.replace("from generic_chess.ai.alphabeta.tuning import SearchTuning","from generic_chess.ai.alphabeta.tuning import SearchTuning\nfrom generic_chess.learning.features import localized_control_features")
s=s.replace("for f in sorted((P/'transfer-roots').glob('*.json')):","for seed in plan['cases']:\n  f=P/'transfer-roots'/f'{seed}.json'")
s=s.replace("Material(bv,hv)","Material(bv,hv,c)")
s=s.replace("max_time_seconds=16","max_time_seconds=plan['seconds']")
s=s.replace("hand_values=hv,tt_megabytes=0","hand_values=hv,localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0")
s=s.replace("abs(n.score)<50000000","abs(n.score)<99000000")
(P/'core_validation.py').write_bytes(s.encode())
print('FROZEN8COREPAIRS')
