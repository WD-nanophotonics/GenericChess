from pathlib import Path
import json,zipfile,hashlib,re,subprocess
R=Path.cwd();P=R/'.local_agent/local-control-20261016';B=P/'reader-inputs';D=R/'docs/archive/local_control_leaf_20261016';assert D.resolve().is_relative_to(R.resolve());D.mkdir(parents=True,exist_ok=True)
assert json.loads((P/'reader-complete-private.json').read_bytes())['returncode']==0
entries={}
def put(rel,path):
 p=Path(path);assert p.is_file(),p
 if rel in entries:assert entries[rel].read_bytes()==p.read_bytes(),rel
 entries[rel]=p
for p in B.rglob('*.json'):put('research/'+p.relative_to(B).as_posix(),p)
for p in P.glob('*.json'):
 if p.name=='qualification-summary.json':continue
 if (B/p.name).is_file() and p.read_bytes()==(B/p.name).read_bytes():continue
 if p.name.endswith('-private.json')or p.name.startswith(('recovery-','checkpoint-'))or p.name in('peer-recovery-assessment-private.json',):continue
 put('research/plans-analysis/'+p.name,p)
for p in P.glob('*.py'):
 if p.name.startswith(('reconcile','fix_page','pagination_tests','update_recovery','write_reports')):continue
 put('research/recipes/'+p.name,p)
for p in P.glob('*.jsonl'):put('research/journals/'+p.name,p)
for p in P.glob('*.log'):
 if p.name.startswith(('pagination','reconcile','collection')):continue
 put('research/logs/'+p.name,p)
for sub in('coalescence-transfer','api-curve'):
 for name in('plan.json','transfer-plan.json','transfer.py','run.py','transfer-queries.jsonl','queries.jsonl','transfer.log','run.log'):
  p=P/sub/name
  if p.exists():put('research/'+sub+'/'+name,p)
for name in('C_livecopy-source','D_both-source','coalesced-source','coalesced-v2-source','outlined-source'):
 put('research/prototype-overrides/'+name+'/native_module.c',P/name/'native_module.c')
baseline=P/'baseline-native-module.c';baseline.write_bytes(subprocess.check_output(['git','show','2bef9d908ad75ac109d32710fd634d939847ace6:generic_chess/_native/native_module.c']))
put('research/prototype-overrides/baseline2bef/native_module.c',baseline)
source=json.loads((P/'publication-source-tests-private.json').read_bytes())
for rel in source['support_files']:put(('product-overrides/'if rel.startswith('generic_chess/_native/')else'source-tests/')+rel,R/rel)
put('research/consumer.py',P/'consumer.py')
receipts={}
for name in('full-tests-private.json','publication-source-tests-private.json','coalescence-full-source-tests-private.json','reader-complete-private.json'):
 d=json.loads((P/name).read_bytes());receipts[name]={k:v for k,v in d.items()if k not in('source_hashes','support_files')};assert d['returncode']==0
receipts['normal_actual_tests']=2757;receipts['source_affected_tests']=160
receipts['coalescence_full_source_skip']='test_f91_release_version_authority.py::test_ui_version_entry_points[command1]: generated console executable unavailable in source export; one skip,2756passed; NOT installedcoalescence.'
receipts['scope']='Normalminimal9 product/source andprivateV1 fullsource tiers remain distinct. Sourcecopy all2509retainedqueries/8628states/5163PVedges/16forcededges;2missingfirstqueryreceipts and12unsavedfailedtraceedges excluded.'
(P/'qualification-summary.json').write_bytes(json.dumps(receipts,indent=2).encode());put('research/qualification-summary.json',P/'qualification-summary.json')
def public(raw):
 text=raw.decode('utf-8-sig').replace('\r\n','\n')
 text=re.sub(re.escape(R.as_posix()).replace('/',r'[\\/]+'),'<project>',text,flags=re.I)
 text=re.sub(re.escape(Path.home().as_posix()).replace('/',r'[\\/]+'),'<user>',text,flags=re.I)
 assert not re.search(re.escape(Path.home().as_posix()).replace('/',r'[\\/]+'),text,re.I),'homepath'
 assert not re.search(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',text),'email'
 assert not re.search(r'\bsk-[A-Za-z0-9]{24,}|\bxox[bp]-[A-Za-z0-9-]{12,}|\bghp_[A-Za-z0-9]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY',text),'credential'
 return text.encode()
rows=[]
with zipfile.ZipFile(D/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for rel,p in entries.items():
  raw=p.read_bytes();b=public(raw);z.writestr(rel,b);rows.append(dict(path=rel,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),original_sha256=hashlib.sha256(raw).hexdigest(),publication_copy='exact'if raw==b else'LF/hostpathsanitization'))
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert z.testzip()is None
 for row in rows:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
manifest=dict(complete=True,archive_sha256=hashlib.sha256((D/'evidence.zip').read_bytes()).hexdigest(),archive_bytes=(D/'evidence.zip').stat().st_size,uncompressed_bytes=sum(r['bytes']for r in rows),members=len(rows),files=rows,source_dependency=dict(archive='docs/archive/dynamic_input_cost_20261016/evidence.zip',sha256='1180b5eea69f9ed8aaffc7461e79eb24f70d8704810132439cc77d6bc4824978',source_files=307,public_sha='1bc6408c81ae9b6fbc6b74db1d564ad554a3b364'),full_source_base='2bef9d908ad75ac109d32710fd634d939847ace6',adopted='Onlyminimalactualinline9identity +exactSlackpagebundle repair; prototypesunadopted',scope='Checkedtechnicaldata includingallfields/censors/failures, no rawaccount/Slack/PII/password/credentials. Originalprivatebytes preserved; exactsourceprototypes areprovenance, noautomaticproducer execution.')
(D/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode());(D/'consumer.py').write_bytes(public((P/'consumer.py').read_bytes()))
(D/'README.md').write_bytes(b'# Actual local-control leaf evidence\n\nVerify manifest hashes and ZIP CRC before use. The fixed source dependency has307 source/ files. Extract those into a NEW ignored source directory, overlay product-overrides/ and source-tests/ from this ZIP, and rebuild normal Native with the declared compatible Python/Zig environment. The host interpreter, pytest/dependencies and compiler are not bundled. The existing source-tests include the actual semantic/error/page-bundle checks; normal dependencies are required, do not add -S.\n\nExtract research/ separately and run consumer.py with that research directory argument from the rebuilt source root. The reader asserts Native origin and disables all search entry points. It verifies2509retainedqueries, complete state/history/PV and scalar contexts, explicit capacity refusals and16unique-frontier forced edges. It does not rerun old clocks, training, games, AUX programs or scientific producers. Two missing first-harness query receipts and12unsaved failed trace edges are excluded. Old failed programs remain historical, not pending retries.\n\nAll prototype sources and producer recipes are AS-EXECUTED provenance. They use exclusive output paths; do not automatically run them or overwrite frozen results/caps. Host paths in publication copies use <project>/<user> placeholders; private originals remain unchanged. Normal source-tests use relative runtime fixtures. CoalescenceV1/V2, live-copy, zero-skip and outlined variants are not deployed. Their positive/adverse results and separate qualification tiers must remain distinguishable from the adopted minimal9kernel.\n\nFor full four-layer regression use the COMPLETE fixed PUBLIC Git base plus these overrides; compact307source intentionally omits unrelated reports/assets. Normal product2757tests and160freshaffectedchecks pass; privateV1source2756pass/1missing-console-exe skip is a different tier. Exact raw Slack/identity/receipts stay private; checked collaboration summaries are in the purpose report. No UI/AUX activation or automatic integration is provided.\n')
(P/'publication-targets.json').write_bytes(json.dumps(source['targets'],indent=2).encode())
print('PACKAGED',manifest['members'],manifest['archive_bytes'],manifest['uncompressed_bytes'],manifest['archive_sha256'],flush=True)
