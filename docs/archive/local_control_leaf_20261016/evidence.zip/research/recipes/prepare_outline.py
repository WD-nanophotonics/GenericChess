from pathlib import Path
import json,shutil,sys,sysconfig,subprocess,time
R=Path.cwd();P=R/'.local_agent/local-control-20261016';S=P/'outlined-source';S.mkdir(exist_ok=False)
plan=dict(question='Does outlining only the optional9 feature enumeration reduce the mandatory hotleaf frame and improve actualcheapconsumers?',changed_premise='Assemblyshowsbaselinegc_probe_material reserves108168bytes andcalls___chkstk_msevenwithno9profile. V1/V2 frames108248/108280 staySAME27pagecount, soextra-page hypothesisrefuted; spills/bodygrowthobservedbutnotcausalproof. Testoneactualoptionalpathisolation, notassembler-as-speedclaim.',scope='PRIVATE9-onlyoutlinefromdeliveredminimal9source, originalfullparentcopy andmaterial-view trial semantics unchanged. PortablePy_NO_INLINE verifiedinstalledPythonpyport.h. No coalescence/API/default/learning/AUXchange.',decision='384fixed512node actualqueriesallnon-timefields equal; measureallstatic/dynamic/control profiles. Ifnoactualgain ornewadversity, keepprivate. Sourceframechange aloneinsufficient.',whole_seconds=180,expected_seconds=30)
(P/'outline-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
p=S/'native_module.c';s=p.read_text();a=s.index('static int gc_semantic_probe_material(');b=s.index('static int gc_semantic_dynamic_feature_vector(',a);part=s[a:b]
start=part.index('        /* Local control is residualized');end=part.index('        for (int cell = 0;',start);enum=part[start:end].replace('return GC_SEMANTIC_EVAL_ERROR;','return 0;')
helper='''Py_NO_INLINE static int gc_semantic_local_control_vector(
    const GCSemanticRules *rules, const GCSemanticPosition *position,
    int features[GC_SEMANTIC_SPATIAL_CELLS]) {
'''+enum+'''        for (int cell = 0; cell < GC_SEMANTIC_SPATIAL_CELLS; cell++)
            features[cell] = 9 * (counts[0][cell] - counts[1][cell]) -
                (totals[0] - totals[1]);
        return 1;
}

'''
part=part[:start]+'''        if (!gc_semantic_local_control_vector(rules, position, features))
            return GC_SEMANTIC_EVAL_ERROR;
'''+part[end:]
needle='''            features[cell] = 9 * (counts[0][cell] - counts[1][cell]) -
                (totals[0] - totals[1]);
'''
assert part.count(needle)==1;part=part.replace(needle,'')
s=s[:a]+helper+part+s[b:];p.write_bytes(s.encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/'outlined_native_core.pyd')]
r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr
q=json.loads((P/'coalescence-controls-plan.json').read_bytes());q.update(profiles=['static','dynamic235','control9'],repetitions=4,scope=plan['scope'],question=plan['question'])
(P/'outline-pilot-plan.json').write_bytes(json.dumps(q,indent=2).encode())
s=(P/'coalescence_controls.py').read_text().replace("P/'coalesced_native_core.pyd'","P/'outlined_native_core.pyd'").replace('coalescence-controls-plan.json','outline-pilot-plan.json').replace('coalescence-controls-queries.jsonl','outline-pilot-queries.jsonl').replace('coalescence-controls-results.json','outline-pilot-results.json')
s=s.replace("localized_control_values=None,tt_megabytes","localized_control_values=(1,0,0,0,0,0,0,0,-1)if profile=='control9'else None,tt_megabytes")
(P/'outline_pilot.py').write_bytes(s.encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-O2','-S','-I'+sysconfig.get_path('include'),'-I'+str(S),str(S/'native_module.c'),'-o',str(P/'outline-module.s')]
r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr
print('PRIVATE_OUTLINE_BUILT')
