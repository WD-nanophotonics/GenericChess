from pathlib import Path
import sys,json,time,importlib.util,traceback,statistics
R=Path.cwd();P=R/'.local_agent/local-control-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
mods={}
for arm,path in [('B_identity',R/'.local_agent/attack-membership-20261016/leaf_native_core.pyd'),('C_livecopy',P/'C_livecopy_native_core.pyd'),('D_both',P/'D_both_native_core.pyd')]:
 spec=importlib.util.spec_from_file_location('fourcell_'+arm+'._native_core',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
plan=json.loads((P/'fourcell-plan.json').read_bytes());start=time.perf_counter();rows=[];setup=[]
def stopped():
 for n in('rollout','advisor','slack'):
  d=json.loads((R/'.local_agent'/f'{n}.json').read_bytes())
  if d.get('user_paused')or d.get('stopped'):raise RuntimeError('USER_STOP')
with(P/'fourcell-queries.jsonl').open('x',encoding='utf-8')as out:
 for case in plan['cases']:
  t=time.perf_counter();d=json.loads((R/'.local_agent/api-ready-20261016/roots'/f"{case['seed']}.json").read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(v))for k,v in v.board_value_by_type.items()};hv={k:int(round(v))for k,v in v.hand_value_by_base_type.items()};nrs={a:compile_native_semantic_rules(c,**({}if a=='A_normal'else dict(backend_module=mods[a])))for a in plan['arms']};before=record_value(s.state);setup.append(dict(seed=d['seed'],seconds=time.perf_counter()-t,full_state=before))
  for profile in ['control9']:
   for rep in range(plan['repetitions']):
    group=[];arms=plan['arms'][rep:]+plan['arms'][:rep]
    if rep%2:arms=list(reversed(arms))
    for arm in arms:
     stopped();z=dict(**case,profile=profile,rep=rep,arm=arm)
     if time.perf_counter()-start>plan['whole_seconds']:z.update(kind='WHOLE_CAP_NOT_STARTED_UNKNOWN');rows.append(z);continue
     t0=time.perf_counter();e=SemanticSearchEngine(c,nrs[arm],board_values=bv,hand_values=hv,dynamic_values=None,localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False)
     t=time.perf_counter()
     try:
      r=e.search(s,SearchLimits(max_depth=plan['depth'],max_nodes=plan['nodes'],max_time_seconds=None,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-t;z.update(kind='ACTUAL_QUERY',caller_seconds=elapsed,ready_seconds=time.perf_counter()-t0,result=record_value(r),root_restored=record_value(s.state)==before);assert z['root_restored']
     except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=str(exc),traceback=traceback.format_exc())
     rows.append(z);group.append(z);out.write(json.dumps(z)+'\n');out.flush()
    assert len(group)==4 and all(z['kind']=='ACTUAL_QUERY'for z in group),group
    assert all({k:v for k,v in z['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in group[0]['result'].items()if k!='elapsed_seconds'}for z in group)
    print('GROUP',case['seed'],profile,rep,[(z['arm'],round(z['caller_seconds'],6),z.get('counter'))for z in group],flush=True)
summary=[]
for case in plan['cases']:
 for profile in ['control9']:
  g=[z for z in rows if z['seed']==case['seed']and z['profile']==profile];a={arm:[z for z in g if z['arm']==arm]for arm in plan['arms']};med={arm:statistics.median(z['caller_seconds']for z in zs)for arm,zs in a.items()};summary.append(dict(**case,profile=profile,caller_medians=med,identity_normal_ratio=med['B_identity']/med['A_normal'],copy_normal_ratio=med['C_livecopy']/med['A_normal'],both_identity_ratio=med['D_both']/med['B_identity']))
write_record(P/'fourcell-results.json',dict(complete=True,rows=rows,summary=summary,setup=setup,seconds=time.perf_counter()-start,queries=len(rows),scope=plan['scope']));print('SUMMARY',json.dumps(summary),flush=True)
