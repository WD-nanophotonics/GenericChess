from pathlib import Path
import shutil,subprocess,sys,sysconfig,time,json,os,hashlib
R=Path.cwd();P=R/'.local_agent/local-control-20261016';S=P/'coalescence-full-source/source';S.mkdir(parents=True,exist_ok=False)
files=subprocess.check_output(['git','ls-files','-z']).decode().split('\0');count=0;size=0
for rel in files:
 if not rel:continue
 f=R/rel
 if not f.is_file():continue
 d=S/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,d);count+=1;size+=f.stat().st_size
shutil.copyfile(P/'coalesced-source/native_module.c',S/'generic_chess/_native/native_module.c')
out=S/'generic_chess'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted((S/'generic_chess/_native').glob('*.c'))],'-o',str(out)]
t=time.perf_counter();built=subprocess.run(cmd,capture_output=True,timeout=180);assert built.returncode==0,built.stderr
env=dict(os.environ);env.pop('PYTHONPATH',None)
r=subprocess.run([str(R/'.venv/Scripts/python.exe'),'-X','utf8','-m','pytest','-o','addopts=','-q','--basetemp='+str(P/'pytest-coalescence-full-temp'),'-o','cache_dir='+str(P/'pytest-coalescence-full-cache')],cwd=S,capture_output=True,text=True,encoding='utf-8',timeout=1500,env=env)
data=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,source_files=count,source_bytes=size,native_module_sha256=hashlib.sha256((S/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),scope='Fullfreshtrackedsourceexport plusPRIVATEcoalescedmodule, all4testlayers; actualsource-builtNative. No generatedconsoleexecutable copied; iftestskips keepitexplicit. Normaldeliveredminimal9full2757 separate, thisdoesnotclaimnormalcoalescenceinstallation.')
(P/'coalescence-full-source-tests-private.json').write_bytes(json.dumps(data,indent=2).encode());print(r.stdout[-1400:]);print(r.stderr[-500:]);print('COALESCED_FULL_SOURCE',r.returncode,data['seconds'],count,size);raise SystemExit(r.returncode)
