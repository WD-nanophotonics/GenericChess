from pathlib import Path
R=Path.cwd();p=R/'tools/local_agent/slack_transport.py';s=p.read_text()
s=s.replace('def parse_plugin_thread(result):','def parse_plugin_thread(result, *, _allow_more=False):')
old="if not data or 'There are no more messages in this thread.' not in data.get('pagination_info', ''):\n        raise LocalFlowError('complete paginated Slack thread evidence is required')"
new="if not data or (not _allow_more and 'There are no more messages in this thread.' not in data.get('pagination_info', '')):\n        raise LocalFlowError('complete paginated Slack thread evidence is required')"
assert s.count(old)==1;s=s.replace(old,new)
idx=s.index('\ndef _rendered_emphasis(')
helper='''
def parse_plugin_pages(pages):
    """Read an exact cursor-linked bundle without rewriting raw page bodies."""
    if not isinstance(pages, list) or not pages:
        raise LocalFlowError('Slack pages must be a nonempty cursor-linked list')
    expected_cursor = None
    seen_cursors = set()
    parent = None
    replies = {}
    for index, page in enumerate(pages):
        if not isinstance(page, dict) or page.get('cursor') != expected_cursor:
            raise LocalFlowError('Slack page cursor gap or wrong first page')
        result = page.get('tool_result', {})
        messages = parse_plugin_thread(result, _allow_more=True)
        data = next(json.loads(b['text']) for b in result['content']
                    if b.get('type') == 'text' and b.get('text', '').startswith('{')
                    and 'messages' in json.loads(b['text']))
        pagination = data.get('pagination_info', '')
        complete = 'There are no more messages in this thread.' in pagination
        # Server metadata outside message bodies, never inferred from reply text.
        cursors = re.findall(r'To view the next page, use cursor: BACKTICK([^BACKTICK]+)BACKTICK', pagination)
        if complete:
            if cursors or index != len(pages) - 1:
                raise LocalFlowError('Slack pages continue after a final page')
        else:
            if len(cursors) != 1 or index == len(pages) - 1:
                raise LocalFlowError('Slack page chain is incomplete')
            if cursors[0] in seen_cursors:
                raise LocalFlowError('Slack pagination cursor repeats')
            expected_cursor = cursors[0]
            seen_cursors.add(expected_cursor)
        if parent is None:
            parent = messages[0]
        elif messages[0] != parent:
            raise LocalFlowError('Slack page parent changed')
        for message in messages[1:]:
            previous = replies.get(message['ts'])
            if previous is not None and previous != message:
                raise LocalFlowError('Slack overlapping reply changed')
            replies[message['ts']] = message
    from decimal import Decimal
    return [parent] + sorted(replies.values(), key=lambda message: Decimal(message['ts']))

'''.replace('BACKTICK',chr(96))
s=s[:idx]+'\n'+helper+s[idx:]
s=s.replace("    messages = parse_plugin_thread(snapshot['tool_result'])","    if 'pages' in snapshot and 'tool_result' in snapshot:\n        raise LocalFlowError('choose single Slack result or exact page bundle')\n    messages = (parse_plugin_pages(snapshot['pages']) if 'pages' in snapshot\n                else parse_plugin_thread(snapshot['tool_result']))")
p.write_bytes(s.encode())
print('PAGINATION_OBSERVED_REPAIR')
