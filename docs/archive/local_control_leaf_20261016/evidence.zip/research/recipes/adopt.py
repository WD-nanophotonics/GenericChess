from pathlib import Path
import json,subprocess,time,hashlib
R=Path.cwd();P=R/'.local_agent/local-control-20261016';a=json.loads((P/'analysis.json').read_bytes());core=json.loads((P/'core-results.json').read_bytes())
assert a['complete']and core['complete']and all(not z.get('joint_complete')or z['normalized_score_equal']for z in core['rows'])
p=R/'generic_chess/_native/native_module.c';s=p.read_text();begin=s.index('static int gc_semantic_probe_material(');end=s.index('static int gc_semantic_dynamic_feature_vector(',begin);part=s[begin:end];needle='int status = gc_semantic_runtime_make_checked_status(&child, rules, &view, raw);';assert part.count(needle)==1
part=part.replace(needle,'/* Only status and the raw target are consumed. Retain the full parent\n                 * history and S4 checks; this trial child is never searched. */\n                int status = gc_semantic_runtime_make_material_view_status(\n                    &child, rules, &view, raw);')
p.write_bytes((s[:begin]+part+s[end:]).encode())
for src,dest in [('proposed-tests.py','tests/product/test_native_dynamic_feature_views.py'),('proposed-fault-tests.py','tests/development/test_native_dynamic_feature_error.py')]:
 (R/dest).write_bytes((P/src).read_bytes().rstrip()+b'\n')
f=R/'tests/workflow/test_slack_transport.py';f.write_bytes(f.read_bytes().rstrip()+b'\n')
q=dict(adopted='minimal INLINEcontrol9 identityonly',rationale='Actualconsumer Core/S4/fullhistory/error qualified;240/256freshqueries66jointD4allfields equal,10leafonlycomplete,0normalonly,44neither; staticcost~1,active4/8conditional.275/.118;12/16nojoint notinvented.128fourcell showscopyincrementnear1/adversewide, rejectsecondline. Independent2completeCoreD3 scores agree,5censorsUNKNOWN,1actualtail. Zeroabsenceordinaryfields equal butobservednestedfaultdifference retained, nozeroskip.',production_changes=['native_module.c exactinline checked->material-view call+comment','12S4actualinlineleaf regressioncases','localizedactualsearch nestedfaultcoverage','observedSlackexactcursorpage ingestionrepair and9regressions'],no_getter_change=True,no_aux_execution=True,no_api_schema_or_defaults_change=True)
(P/'adoption-decision.json').write_bytes(json.dumps(q,indent=2).encode())
print('ADOPTED_MINIMAL_INLINE_ONLY')
