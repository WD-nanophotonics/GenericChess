from pathlib import Path
import shutil,json
R=Path.cwd();P=R/'.local_agent/local-control-20261016';A=R/'.local_agent/attack-membership-20261016';B=P/'reader-inputs';B.mkdir(exist_ok=False)
base=(A/'consumer.py').read_text();base=base[:base.index("for fn in ('results.json'")]
base=base.replace("'control-results.json'","'support-controls.json'")
extra='''
def verify_values(c,nr,np,values):
 before=record_value(sem.snapshot(nr,np));zero=(0,)*len(nr.type_ids)
 for row in values:
  assert row["isolated"]["normal"]==row["isolated"]["leaf"]
  assert row["mixed"]["normal"]==row["mixed"]["leaf"]
  actual=sem.evaluate(nr,np,board_values=zero,hand_values=zero,localized_control_values=row["weights"])
  assert actual==row["isolated"]["leaf"]
  mixed=sem.evaluate(nr,np,dynamic_values=(2,3,5),localized_control_values=row["weights"])
  assert mixed==row["mixed"]["leaf"]
 assert record_value(sem.snapshot(nr,np))==before
 counts["direct_leaf_contexts"]+=1

for fn,kind,field in (
 ("transfer-results.json","transfer","rows"),
 ("q-profile-results.json","old","rows"),
 ("fourcell-results.json","old","rows"),
 ("zero-results.json","old","rows"),
 ("coalescence-pilot-results.json","old","rows"),
 ("coalescence-transfer-results.json","coalescence","rows"),
 ("qualification-results.json","pending","queries"),
 ("coalescence-qualification-results.json","pending","queries"),
):
 d=read(fn);assert d["complete"]
 for row in d[field]:
  if row.get("kind","ACTUAL_QUERY")!="ACTUAL_QUERY":
   counts[fn+":"+row["kind"]]+=1;continue
  query(kind,row.get("seed",0),row["result"]);counts[fn]+=1
for row in read("core-results.json")["rows"]:
 if row["kind"]!="ACTUAL_PAIR":counts["core_"+row["kind"]]+=1;continue
 for arm in ("core","native"):
  query("transfer",row["seed"],row[arm]);counts["core_"+arm+"_query_receipts"]+=1
for kind,fn in (("transfer","transfer-results.json"),("coalescence","coalescence-transfer-results.json")):
 for row in read(fn)["roots"]:
  s,nr=root(kind,row["seed"]);compare(s,nr,pack_semantic_search_position(s.compiled,nr,s));counts[kind+"_roots"]+=1
corpus=dict(semantic_corpus());origins={};rules={}
for row in read("support-controls.json")["mechanisms"]:
 c=corpus[row["fixture"]];s=GameSession.replay(c,deserialize_game_record(json.dumps(row["game_record"])))
 assert record_value(s.state)==row["state"]
 key=(row["fixture"],row["seed"],row["ply"]);origins[key]=s
 if row["fixture"]not in rules:rules[row["fixture"]]=compile_native_semantic_rules(c)
for fn in ("qualification-results.json","coalescence-qualification-results.json"):
 d=read(fn)
 for row in d["states"]:
  s=copy(origins[(row["fixture"],row["seed"],row["ply"])]);nr=rules[row["fixture"]];np=pack_semantic_search_position(s.compiled,nr,s)
  compare(s,nr,np);verify_values(s.compiled,nr,np,row["values"])
 import phase19b3_s4_fixtures as s4
 from dataclasses import replace
 from generic_chess.rules.compiler import compile_semantic_ruleset
 for row in d["s4"]:
  c=compile_semantic_ruleset(getattr(s4,row["fixture"])())
  from test_native_dynamic_feature_views import S4_CASES
  builder,posfn=next((a,b)for a,b in S4_CASES if a.__name__==row["fixture"])
  p=replace(posfn(c.support),side_to_move=row["owner"]);assert record_value(p)==row["position"]
  nr=compile_native_semantic_rules(c);payload=dict(expected_snapshot(p,nr,c),ply=0)
  payload["board"]=[None if p is None else list(p)for p in payload["board"]];payload["hands"]=[list(h)for h in payload["hands"]]
  verify_values(c,nr,sem.pack_position(nr,payload),row["values"]);counts["s4_specification_contexts"]+=1
 for row in d["histories"]:
  s=cycle(max_ply=1024,repetition=10000,prefix=row["prefix"]);nr=compile_native_semantic_rules(s.compiled);np=pack_semantic_search_position(s.compiled,nr,s);compare(s,nr,np)
  if row.get("errors"):
   try:sem.evaluate(nr,np,localized_control_values=(1,0,0,0,0,0,0,0,-1))
   except NotImplementedError as exc:assert str(exc)==row["errors"]["normal"];counts["capacity_refusals"]+=1
   else:raise AssertionError("capacitymustrefuse")
  else:verify_values(s.compiled,nr,np,row["values"])
  counts["actual_history_prefixes"]+=1
 for row in d["transport"]:
  s,nr=root("pending",0);np=sem.pack_position(nr,row["payload"]);verify_values(s.compiled,nr,np,row["values"]);counts["actual_or_edited_transport"]+=1
for row in read("mixed-cost-results.json")["rows"]:
 s,nr=root("old",row["seed"]);np=pack_semantic_search_position(s.compiled,nr,s)
 for profile,v in row["scores"].items():
  actual=sem.evaluate(nr,np,dynamic_values=(2,3,5)if profile in("dynamic","both")else None,localized_control_values=(1,0,0,0,0,0,0,0,-1)if profile in("control","both")else None)
  assert actual==v;counts["component_final_score_receipts"]+=1
 compare(s,nr,np)
out=dict(complete=True,counts=dict(counts),seconds=time.perf_counter()-start,scope="SearchDISABLED freshlyrebuiltproduct/Core replay ofallretainedquery/PV/fallback fullstate-history receipts anddirectleafcontexts. Actualdata, censors/tails andprivatecandidate comparisons retained; nooldclock/finiteobjective/WDL orAUXproducer recomputation. Corecompiler/hostshared, notall-domainproof.")
(B/"consumer-result.json").write_bytes((json.dumps(out,indent=2)+"\\n").encode());print(json.dumps(out))
'''
# Consumer must never write into an unsaved producer directory.
(P/'consumer.py').write_bytes((base+extra).encode())
for name in('transfer-results.json','q-profile-results.json','fourcell-results.json','zero-results.json','coalescence-pilot-results.json','qualification-results.json','coalescence-qualification-results.json','core-results.json','mixed-cost-results.json'):
 shutil.copyfile(P/name,B/name)
shutil.copyfile(R/'.local_agent/eval-revisit-20261016/control-results.json',B/'support-controls.json')
for folder,original in [('old-roots',R/'.local_agent/api-ready-20261016/roots'),('transfer-roots',P/'transfer-roots')]:
 dst=B/folder;dst.mkdir()
 for f in original.glob('*.json'):shutil.copyfile(f,dst/f.name)
print('READER_PREPARED_CORE',len(list((B/'old-roots').glob('*.json'))),len(list((B/'transfer-roots').glob('*.json'))))
