from pathlib import Path
import json,statistics,re
P=Path('.local_agent/local-control-20261016')
# Read completed producers only.
c=json.loads((P/'coalescence-transfer/transfer-results.json').read_bytes());api=json.loads((P/'api-curve/results.json').read_bytes());assert c['complete']and api['complete']
cs=[]
for board in(4,8,12,16):
 groups={}
 for z in c['rows']:
  if z['board']==board:groups.setdefault((z['seed'],z['rep']),[]).append(z)
 counts=dict(joint=0,only_normal=0,only_coalesced=0,neither=0);fam={}
 for (seed,rep),g in groups.items():
  a={z['arm']:z for z in g};assert all(z['kind']=='ACTUAL_QUERY'for z in g)
  x=a['A_normal'];y=a['B_coalesced'];xc=x['result']['completed_depth']==4;yc=y['result']['completed_depth']==4
  label='joint'if xc and yc else'only_normal'if xc else'only_coalesced'if yc else'neither';counts[label]+=1
  if xc and yc:
   assert{k:v for k,v in x['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in y['result'].items()if k!='elapsed_seconds'}
   fam.setdefault(seed,[]).append(y['caller_seconds']/x['caller_seconds'])
 fr={k:statistics.median(v)for k,v in fam.items()};cs.append(dict(board=board,counts=counts,family_ratios=fr,conditional_family_median=statistics.median(fr.values())if fr else None))
summ=[]
for mode in('cold','warm'):
 for budget in(.25,1,4):
  for arm in('old9','minimal9','coalesced'):
   g=[r for r in api['rows']if r['mode']==mode and r['budget']==budget and r['arm']==arm]
   summ.append(dict(mode=mode,budget=budget,arm=arm,slots=len(g),queries=sum(z['kind']=='ACTUAL_QUERY'for z in g),admission_expired=sum(z['kind']=='ADMISSION_EXPIRED'for z in g),failures=sum(z['kind']=='ACTUAL_FAILURE'for z in g),eligible=sum(z.get('eligible',False)for z in g),complete_D4=sum(z.get('result',{}).get('completed_depth')==4 for z in g),eligible_D4=sum(z.get('eligible',False)and z.get('result',{}).get('completed_depth')==4 for z in g),max_outer_overrun=max((z.get('overrun_seconds',0)for z in g),default=0),expired_phases={phase:sum(z.get('expired_phase')==phase for z in g)for phase in sorted({z['expired_phase']for z in g if' expired_phase'.strip()in z})}))
negative=[]
for v in('coalescence','coalescence-v2'):
 d=json.loads((P/(v+'-controls-results.json')).read_bytes())
 for board in(4,8,12,16):
  for profile in('static','dynamic235'):
   g=[r['membership_normal_ratio']for r in d['summary']if r['board']==board and r['profile']==profile]
   negative.append(dict(version=v,board=board,profile=profile,family_median_ratio=statistics.median(g),maximum_family_ratio=max(g),scope='4exposedfamilies8reps; processconcurrencyallowed, notgeneralcausality'))
outline=json.loads((P/'outline-pilot-results.json').read_bytes());outsummary=[]
for board in(4,8,12,16):
 for profile in('static','dynamic235','control9'):
  g=[r['membership_normal_ratio']for r in outline['summary']if r['board']==board and r['profile']==profile]
  outsummary.append(dict(board=board,profile=profile,family_median_ratio=statistics.median(g),max_family=max(g)))
asm=(P/'outline-module.s').read_text();i=asm.index('gc_semantic_probe_material:');j=asm.index('.seh_endproc',i);frame=re.search(r'\.seh_stackalloc (\d+)',asm[i:j]);outline_frame=int(frame[1])
data=dict(complete=True,coalescence_transfer=dict(planned=128,actual=len(c['rows']),missing_slots=128-len(c['rows']),roots=len(c['roots']),tails=sum(r['kind']=='ACTUAL_TERMINAL_TAIL'for r in c['roots']),internal_pre_final_write_seconds=c['seconds'],summary=cs),api_curve=dict(planned=288,actual=len(api['rows']),internal_pre_final_write_seconds=api['seconds'],summary=summ),negative_controls=negative,outline=dict(frame_bytes=outline_frame,baseline_frame_bytes=108168,summary=outsummary,adopt=False,reason='9-onlyoutline doesnotestablishusefulwholequerygain; mostratios~1, keepprivate. Stack/frame changesarenotCPU/utilityevidence.'),coalescence_adopt=False,coalescence_v2_adopt=False,decision='Deliver onlyminimalINLINE9identity andactualrawpage recovery. V1hasconsistentdynamic-onlyregression;V2notprospectivecostvalidated and16static adversefamilies; no broadcoalescenceadoption. Preservepositivefusedcost/negativecontrols/APIcurve withoutchoosingfavorableversionafterresults.',scope='Allcost/source tiers distinct. No newtraining/evaluationgames/pricefit/AUXexecution. Rawfrozenrecords retained.')
(P/'followup-analysis.json').write_bytes(json.dumps(data,indent=2).encode())
print('COALESCENCE',json.dumps(data['coalescence_transfer'],indent=2));print('API',json.dumps(summ,indent=2));print('OUTLINE_FRAME',outline_frame);print('NEGATIVE',negative)
