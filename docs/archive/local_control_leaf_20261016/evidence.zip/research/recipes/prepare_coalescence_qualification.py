from pathlib import Path
R=Path.cwd();P=R/'.local_agent/local-control-20261016'
s=(P/'qualify-v3.py').read_text().replace("A/'leaf_native_core.pyd'","P/'coalesced_native_core.pyd'").replace("P/'qualification-queries.jsonl'","P/'coalescence-qualification-queries.jsonl'").replace("P/'qualification-results.json'","P/'coalescence-qualification-results.json'")
s=s.replace("from test_native_dynamic_feature_views import S4_CASES","from test_native_dynamic_feature_views import S4_CASES,reference_features")
needle="assert mixed['normal']==mixed['leaf']"
new="""assert mixed['normal']==mixed['leaf']
  if position is not None:
   ids=nrs['normal'].type_ids;values={t:i+1 for i,t in enumerate(ids)}
   mat=sum((1 if piece.owner==position.side_to_move else -1)*values[piece.current_type_id]for piece in position.board if piece is not None)+sum((1 if owner==position.side_to_move else -1)*values[t]*n for owner,hand in enumerate(position.hands)for t,n in hand.items())
   dynamic=reference_features(c,position)
   want_mixed=max(-90000000,min(90000000,mat+(1 if position.side_to_move==0 else -1)*(sum(w*x for w,x in zip(weights,control))+sum(w*x for w,x in zip((2,3,5),dynamic)))))
   assert mixed['leaf']==want_mixed,(mixed,want_mixed)"""
assert s.count(needle)==1;s=s.replace(needle,new)
# Exercise actual shared consumer in pending qTT searches as well.
s=s.replace("localized_control_values=profiles[0],tt_megabytes=tt","dynamic_values=(2,3,5),localized_control_values=profiles[0],tt_megabytes=tt")
(P/'qualify_coalescence.py').write_bytes(s.encode())
s=(P/'test_inline_fault.py').read_text().replace(str(R/'.local_agent/attack-membership-20261016/leaf-pilot-source').replace('\\','\\\\'),str(P/'coalesced-source').replace('\\','\\\\'))
s=s.replace('("dynamic", "spatial", "linear", "localized", "compact")','("dynamic", "spatial", "linear", "localized", "compact", "mixed_control")')
s=s.replace('        "compact": lambda:', '        "mixed_control": lambda: sem.evaluate(rules, packed, dynamic_values=(2, 3, 5), localized_control_values=(1, -1, 0, 0, 0, 0, 0, 0, 0)),\n        "compact": lambda:')
s=s.replace('("linear", "compact", "both", "localized")','("linear", "compact", "both", "localized", "mixed_control")')
s=s.replace('if profile == "localized":','if profile in ("localized", "mixed_control"):').replace('if profile in ("linear", "both"):','if profile in ("linear", "both", "mixed_control"):')
assert 'coalesced-source'in s
(P/'test_coalescence_fault.py').write_bytes(s.encode())
print('COALESCENCE_CORE_AND_ERROR_QUALIFICATION_PREPARED')
