from pathlib import Path
import subprocess,sysconfig,time,json,re,sys
R=Path.cwd();P=R/'.local_agent/local-control-20261016';plan=dict(question='Is added stack-frame/probe work a concrete cause of the observed cheap-profile regression?',changed_premise='V1dynamic-onlyall16positivecostratios;V2restoresoriginal3body andremovesconsistentdynamicpenalty butsome16static ratios1.05-1.10 remain. Do notattributeconcurrentload/assemblywithout evidence.',cost='3bounded assembly-only compilations, <120swhole, no Native searches/newfit/OSchanges.',decision='Frame/probeincreasewouldjustify movingmixed-onlystate outofcheapleaf; equalframes refute thatparticularcause, retainuncertainty insteadofroutine rerun.')
(P/'assembly-plan.json').write_bytes(json.dumps(plan,indent=2).encode());rows=[];start=time.perf_counter()
for arm,source in [('minimal',R/'generic_chess/_native'),('v1',P/'coalesced-source'),('v2',P/'coalesced-v2-source')]:
 out=P/(arm+'-module.s');cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-O2','-S','-I'+sysconfig.get_path('include'),'-I'+str(source),str(source/'native_module.c'),'-o',str(out)]
 r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr
 text=out.read_text();lines=text.splitlines();indexes=[i for i,line in enumerate(lines)if re.match(r'^gc_semantic_probe_material:',line)]
 assert len(indexes)==1,(arm,indexes)
 i=indexes[0];end=next(j for j in range(i+1,len(lines))if '.seh_endproc'in lines[j]);body=lines[i:end+1]
 rows.append(dict(arm=arm,assembly_bytes=out.stat().st_size,material_entry=body[:45],stack_probe_lines=[z for z in body if '__chkstk'in z or re.search(r'\b(subq|addq).*(%rsp)',z)or '.seh_stackalloc'in z],instruction_lines=len(body),scope='Compiler-emitted assembly, not CPU profiling orcausalexecution.'))
(P/'assembly-results.json').write_bytes(json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start),indent=2).encode());print(json.dumps(rows,indent=2))
