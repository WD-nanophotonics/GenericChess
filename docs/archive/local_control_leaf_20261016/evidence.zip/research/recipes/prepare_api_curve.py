from pathlib import Path
import json
R=Path.cwd();P=R/'.local_agent/local-control-20261016';F=P/'api-curve';F.mkdir(exist_ok=False)
s=(R/'.local_agent/api-ready-20261016/run.py').read_text().replace("P=R/'.local_agent/api-ready-20261016'","P=R/'.local_agent/local-control-20261016/api-curve'")
a=s.index("plan=json.loads(");b=s.index("\n\ndef stopped():",a)
s=s[:a]+"""plan=json.loads((P/'plan.json').read_bytes());modules={}
for arm,path in [('old9',R/'.local_agent/attack-membership-20261016/final_native_core.pyd'),('coalesced',R/'.local_agent/local-control-20261016/coalesced_native_core.pyd')]:
 spec=importlib.util.spec_from_file_location('ready_'+arm+'._native_core',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules[arm]=m
modules['minimal9']=None;start=time.perf_counter();rootdir=P/'roots';rootdir.mkdir(exist_ok=False);rows=[];roots=[];slots=0;edges=0;states=0
"""+s[b:]
s=s.replace("compile_native_semantic_rules(c,**({}if arm=='final_1bc6'else dict(backend_module=base)))","compile_native_semantic_rules(c,**({}if modules[arm]is None else dict(backend_module=modules[arm])))")
s=s.replace("dynamic_values=(2,3,5)if profile=='dynamic235'else None","dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1)")
a=s.index("   g=generate_game(");b=s.index("   warm={}",a)
s=s[:a]+"""   d=json.loads((R/'.local_agent/api-ready-20261016/roots'/f"{case['seed']}.json").read_bytes());write_record(rootdir/f"{case['seed']}.json",d)
   root.update(actual_ply=d['state']['ply_count'],acquisition_seconds=time.perf_counter()-t,state_sha256=hashlib.sha256(json.dumps(d['state'],sort_keys=True).encode()).hexdigest())
"""+s[b:]
s=s.replace("arms=plan['arms']if(idx+mi+bi+pi+rep)%2==0 else list(reversed(plan['arms']))","arms=plan['arms'][(idx+mi+bi)%3:]+plan['arms'][:(idx+mi+bi)%3]\n       if rep:arms=list(reversed(arms))")
s=s.replace("remaining=budget-(time.perf_counter()-tq)","remaining=budget-(time.perf_counter()-tq)-plan['reserve_seconds']")
s=s.replace('max_depth=12,max_nodes=1000000','max_depth=4,max_nodes=131072').replace('planned_slots=768','planned_slots=plan["planned_slots"]')
(F/'run.py').write_bytes(s.encode())
plan=dict(question='Do current actualleaf savings convert into usable complete D4 outputs within an end-to-end deadline, or are they lost in admission/serialization?',changed_premise='Oldderivedinput API-ready outcome notrerununchanged: now actualcontrol9 identity and PRIVATEshared3+9 targettrueleaf, materiallydifferentconsumercost. Fullq/price/model/defaultsunchanged, pendingfreshmixedtransfer separate.',cases=[dict(seed=61001+b*100+i,board=b)for b in(4,8,12,16)for i in range(2)],modes=['cold','warm'],budgets=[.25,1,4],reserve_seconds=.05,profiles=['mixed3plus9'],arms=['old9','minimal9','coalesced'],planned_slots=288,whole_seconds=1500,expected_seconds=600,scope='EXPOSED8fullroot diagnostic resourcecurve,288slots. Coldper-rule deserialize/Corecompile/sessionreplay/staticruleprices/Nativecompile/engine/fullquery/outputconversion+JSON; inputJSONparse/disk/Pythonstartup outsidepercallclock. Warmsetupoutsidecallerclock butbatchcharged. Actualqueryresults retainedevenifnoteligible. Privateposthocfullstate/PVvalidation andlogappend outsideeligibility butinsidebatch. Common50msreserve reusedfromexistingprotocol; positivefiniteD4/131072node objectives, noD12vacuousclaims. NoGames/learning/AUXexecution.',decision='Trackadmissionexpired/eligible/completedD4separately, preserveallfailures/overruns/missing. Readiness/depthnotstrength. NotpublishnewAPI/defaultorcoalescenceautomatically; ifimprovementdoesnotreachAPIready stateit. Oldfrozenstudies/capsunchanged.',cost='288maxrequestsouter.25/1/4 acrosscold/warm/reps/arms implies504 nominalquerybudgetseconds plusboundedsetup/serialization inside1500whole<1h. Expected~600s. ExistingAPIreadyrunneradaptation, no framework or singlelongrun splitting.')
(F/'plan.json').write_bytes(json.dumps(plan,indent=2).encode());print('FROZEN_API288')
