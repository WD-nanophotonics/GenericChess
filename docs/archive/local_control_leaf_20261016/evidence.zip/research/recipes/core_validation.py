from pathlib import Path
import json,sys,time,importlib.util
R=Path.cwd();P=R/'.local_agent/local-control-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.learning.features import localized_control_features
spec=importlib.util.spec_from_file_location('independentfinal._native_core',R/'.local_agent/attack-membership-20261016/leaf_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=dict(question='Does independent pureCore finite search corroborate the changed actuallocalized-control leaf, not merely baselineNative?',inputs='Exposed qualification: fixed first2ID families perboard in current32family panel, retain tails/no replacement. Notunexposedvalidation or sameobjectiveasstaticpastCore.',cases=[114401,114402,114801,114802,115201,115202,115601,115602],depth=3,nodes=131072,seconds=30,whole_seconds=480,expected_seconds=240,profile='static exactsameboard/handplusfixedcontrol9=(1,0,0,0,0,0,0,0,-1),qTT0',decision='Anyjointcomplete-score mismatch stopsadoption; Corecensors UNKNOWN. IndependentPythonenumeration/search sharesCorecompiler/featuredefinition butnotCkernel. No solver/WDL/strength/all-domainclaim.',scope='8preselectedpureCoreAlphaBeta/NativeD3 pairs; newactiveprofileconditionalcorrectness test, notextendingoriginal8sD4cap. Singlejob<1hour, noAUXexecution.')
(P/'core-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
class Material:
 def __init__(self,bv,hv,c):self.bv=bv;self.hv=hv;self.c=c
 def evaluate(self,s):
  side=s.position.side_to_move
  material=sum((1 if x.owner==side else-1)*self.bv[x.current_type_id]for x in s.position.board if x is not None)+sum((1 if owner==side else-1)*self.hv[t]*n for owner,hand in enumerate(s.position.hands)for t,n in hand.items())
  controls=localized_control_features(s.position,self.c)
  return max(-90000000,min(90000000,material+(1 if side==0 else -1)*(controls[0]-controls[-1])))
 def type_value(self,t):return self.bv[t]
 def capture_order_value(self,m,c):return 10*self.bv[c.current_type_id]-self.bv[m.current_type_id]
start=time.perf_counter();rows=[]
def stopped():
 for name in('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(z.get('user_paused')or z.get('stopped'))
with(P/'core-rows.jsonl').open('x',encoding='utf-8')as log:
 for seed in plan['cases']:
  f=P/'transfer-roots'/f'{seed}.json'
  stopped();d=json.loads(f.read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));row=dict(seed=d['seed'],board=d['board'])
  if s.state.terminal_status.is_terminal:row.update(kind='ACTUAL_TERMINAL_TAIL',state=record_value(s.state));rows.append(row);log.write(json.dumps(row)+'\n');log.flush();continue
  if time.perf_counter()-start>plan['whole_seconds']:row['kind']='WHOLE_CAP_NOT_STARTED_UNKNOWN';rows.append(row);log.write(json.dumps(row)+'\n');log.flush();continue
  v=build_ruleset_profile(c,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()};before=record_value(s.state)
  nr=compile_native_semantic_rules(c,backend_module=m);t=time.perf_counter();r=AlphaBetaPlayer(c,evaluator_override=Material(bv,hv,c),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,SearchLimits(max_depth=3,max_nodes=131072,max_time_seconds=plan['seconds'],quiescence_max_depth=0,quiescence_hard_max_depth=0));ct=time.perf_counter()-t;assert record_value(s.state)==before
  t=time.perf_counter();n=SemanticSearchEngine(c,nr,board_values=bv,hand_values=hv,localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False).search(s,SearchLimits(max_depth=3,max_nodes=131072,max_time_seconds=plan['seconds'],quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);nt=time.perf_counter()-t
  joint=r.completed_depth==n.completed_depth==3;norm=n.score if abs(n.score)<99000000 else(1 if n.score>0 else-1)*(1000000000-(100000000-abs(n.score)));row.update(kind='ACTUAL_PAIR',core=record_value(r),native=record_value(n),core_seconds=ct,native_seconds=nt,joint_complete=joint,normalized_score_equal=r.score==norm if joint else None,root_restored=record_value(s.state)==before)
  assert row['root_restored'];assert r.action in s.legal_actions()and n.action in s.legal_actions();rows.append(row);log.write(json.dumps(row)+'\n');log.flush();assert not joint or row['normalized_score_equal'],row
  print('CORE_FINAL',d['seed'],joint,r.completed_depth,n.completed_depth,round(ct,3),flush=True)
write_record(P/'core-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,scope=plan['scope']));print('CORE_DONE',len(rows),sum(r.get('joint_complete',False)for r in rows),time.perf_counter()-start,flush=True)
