from pathlib import Path
import json,shutil,subprocess,sys,os,time
R=Path.cwd();P=R/'.local_agent/local-control-20261016';B=P/'reader-inputs';S=P/'publication-source/source'
p=P/'consumer.py';s=p.read_text().replace("if kind=='pending':s=session_after","if kind=='aliascycle':s=cycle(max_ply=512,repetition=4,prefix=seed)\n  elif kind=='pending':s=session_after")
i=s.index('out=dict(complete=True,counts=')
add='''
alias=read("finite-alias-complete-results.json")
for row in alias["rows"]:
 s,nr=root("aliascycle",row["prefix"]);assert record_value(s.state)==row["state"]
 np=pack_semantic_search_position(s.compiled,nr,s)
 features=record_value(dict(dynamic=sem.dynamic_features(nr,np),spatial=sem.spatial_features(nr,np)))
 assert features==row["features"]
 for arm in ("core","native"):
  query("aliascycle",row["prefix"],row[arm]);counts["finite_alias_"+arm+"_queries"]+=1
assert alias["rows"][0]["features"]==alias["rows"][1]["features"]
for row in alias["continuations"]:
 s,nr=root("aliascycle",row["prefix"]);np=pack_semantic_search_position(s.compiled,nr,s);compare(s,nr,np)
 for edge in row["edges"]:
  aa=s.legal_actions();na=sem.guarded_actions(nr,np)
  assert len(aa)==len(na)==edge["legal_frontier_size"]==1
  ac=action(edge["action"]);assert ac==aa[0]==sem.public_action(nr,na[0])
  np=sem.make_checked(nr,np,na[0]);s.submit(ac)
  assert record_value(s.state)==edge["state"];compare(s,nr,np)
  counts["forced_unique_frontier_edges"]+=1
 assert s.state.terminal_status.winner is None and s.state.terminal_status.status.value=="repetition"
 counts["forced_diagnostic_continuations"]+=1
'''
s=s[:i]+add+s[i:];p.write_bytes(s.encode());shutil.copyfile(P/'finite-alias-complete-results.json',B/'finite-alias-complete-results.json')
env=dict(os.environ);env.pop('PYTHONPATH',None);t=time.perf_counter()
r=subprocess.run([str(R/'.venv/Scripts/python.exe'),'-X','utf8',str(p),str(B)],cwd=S,env=env,capture_output=True,text=True,encoding='utf-8',timeout=900)
(P/'reader-complete-private.json').write_bytes(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,scope='All2509retainednewqueries and16forceduniqueCore/Nativefrontiers;2missingfirstharnessqueryreceipts/12unserializedfailedtraceedges explicitlyexcluded. Sourcebuiltproduct, searchesdisabled.'),indent=2).encode())
print(r.stdout[-2000:]);print(r.stderr[-1500:]);raise SystemExit(r.returncode)
