from pathlib import Path
import json
R=Path.cwd();P=R/'.local_agent/local-control-20261016';A=R/'.local_agent/attack-membership-20261016'
q=json.loads((P/'qualification-results.json').read_bytes());assert q['complete']and len(q['states'])==280 and len(q['s4'])==12 and len(q['queries'])==24
s=(A/'transfer.py').read_text().replace("P=R/'.local_agent/attack-membership-20261016'","P=R/'.local_agent/local-control-20261016'")
s=s.replace("for a,n in [('B_membership','clean')]:","for a,n in [('B_leaf','leaf')]:")
s=s.replace("P/(n+'_native_core.pyd')","R/'.local_agent/attack-membership-20261016/leaf_native_core.pyd'")
s=s.replace("arms=list(plan['arms']);random.Random(20261016+idx*100+pi*10+rep).shuffle(arms);quartet=[]","arms=list(plan['arms']);arms=arms if (idx+pi+rep)%2==0 else arms[::-1];quartet=[]")
s=s.replace("dynamic_values=(2,3,5)if profile=='dynamic235'else None,tt_megabytes=0","dynamic_values=None,localized_control_values=(1,0,0,0,0,0,0,0,-1)if profile=='control9'else None,tt_megabytes=0")
(P/'transfer.py').write_bytes(s.encode())
plan=json.loads((A/'transfer-plan.json').read_bytes())
plan.update(question='At the verified actual inline leaf, does legal-trial identity deferral reduce complete D4 query cost on new generated families while cheap static controls stay unchanged?',changed_premise='Actual inline pilot positive,280Coremechanicalstates/12S4specification/6realhistoryprefixcapacity/3transport/24PENDINGqTT queries now qualify;18privatefaulttests includingactuallocalizedsearch and recovery pass. Getternegativepanel stayssealed.',cases=[dict(seed=114000+b*100+i,board=b)for b in(4,8,12,16)for i in range(1,9)],profiles=['static','control9'],arms=['A_normal','B_leaf'],search_seconds=8,whole_seconds=2700,expected_seconds=1500,planned_slots=256,decision='All jointlycompletedD4 non-time fields mustequal; maintain actualtails/missing/censors/onearm completion counts and phasecost. Staticcontrol may be adverse. No strength/model/weights/default/API claim. Singlejob<1h, no splitting.',scope='New32family development transfer,2profilesx2repsx2arms=256slots, D4/131072nodes/8s, qTT0, staticruleprices identical; fixedexistingUNTRAINEDninebinweights activeonlycontrol9. Fullpromotion/drop/current/base/aux/history kept. Qualification passedbeforeinputs; noAUXimport/game/training.',budget_choice='256x8s theoretical2048s plusboundedsetup within2700whole<1h. Expected~1500s; staticcontrolsareimportant toavoid activefeature-onlyselection. Existingrunner, no newframework.',schedule='Reversearmsby(rootindex+profileindex+rep)%2 guarantees pairedrep orderbalance. Originalrecords remain append-only.')
(P/'transfer-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
print('FROZEN256',q['seconds'])
