from pathlib import Path
import json,subprocess,time,hashlib
R=Path.cwd();P=R/'.local_agent/local-control-20261016'
cmd=[str(R/'.venv/Scripts/python.exe'),'-X','utf8','-m','pytest','-q','--basetemp='+str(P/'pytest-full-temp'),'-o','cache_dir='+str(P/'pytest-full-cache')]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',timeout=1500)
d=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),scope='Actualnormal rebuilt product all4active testlayers incl12newactualinlineS4leaf/2newlocalizedsearchfault/9exactSlackpagination regressions. Explicitprojectprivatepytesttemp avoids actualTEMPpermissionerror withoutsecuritychange.')
(P/'full-tests-private.json').write_bytes(json.dumps(d,indent=2).encode());print(r.stdout[-1600:]);print(r.stderr[-500:]);print('FULL_DONE',r.returncode,d['seconds'],flush=True);raise SystemExit(r.returncode)
