from pathlib import Path
from dataclasses import replace
import json,sys,time,importlib.util,traceback
R=Path.cwd();P=R/'.local_agent/local-control-20261016';A=R/'.local_agent/attack-membership-20261016';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from generic_chess.native import semantic as sem,SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.learning.features import localized_control_features
from generic_chess.ai.limits import SearchLimits
from phase19c1_native_semantic_fixtures import semantic_corpus
from test_native_dynamic_feature_views import S4_CASES,reference_features
from test_native_pending_continuation import session_after
from test_native_q_history_deferral import cycle,checked_replay
from scripts.research_record import record_value,write_record
spec=importlib.util.spec_from_file_location('inline_qualification._native_core',P/'coalesced_v2_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
start=time.perf_counter();states=[];s4=[];histories=[];transport=[];queries=[];profiles=[(1,0,0,0,0,0,0,0,-1),(0,1,-1,2,-2,0,3,-3,0),(1000000,0,0,0,0,0,0,0,-1000000)]
def stop():
 for n in ('rollout','advisor','slack'):
  d=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not(d.get('stopped')or d.get('user_paused'))
 assert time.perf_counter()-start<600
def check(c,packs,nrs,position=None):
 before={a:record_value(sem.snapshot(nr,packs[a]))for a,nr in nrs.items()};rows=[]
 zero=(0,)*len(nrs['normal'].type_ids)
 control=localized_control_features(position,c)if position is not None else None
 for weights in profiles:
  v={a:sem.evaluate(nr,packs[a],board_values=zero,hand_values=zero,localized_control_values=weights)for a,nr in nrs.items()};assert v['normal']==v['leaf'],v
  want=None
  if control is not None:
   want=max(-90000000,min(90000000,(1 if position.side_to_move==0 else -1)*sum(w*x for w,x in zip(weights,control))));assert v['leaf']==want,(v,want)
  mixed={a:sem.evaluate(nr,packs[a],dynamic_values=(2,3,5),localized_control_values=weights)for a,nr in nrs.items()};assert mixed['normal']==mixed['leaf']
  if position is not None:
   ids=nrs['normal'].type_ids;values={t:i+1 for i,t in enumerate(ids)}
   mat=sum((1 if piece.owner==position.side_to_move else -1)*values[piece.current_type_id]for piece in position.board if piece is not None)+sum((1 if owner==position.side_to_move else -1)*values[t]*n for owner,hand in enumerate(position.hands)for t,n in hand.items())
   dynamic=reference_features(c,position)
   want_mixed=max(-90000000,min(90000000,mat+(1 if position.side_to_move==0 else -1)*(sum(w*x for w,x in zip(weights,control))+sum(w*x for w,x in zip((2,3,5),dynamic)))))
   assert mixed['leaf']==want_mixed,(mixed,want_mixed)
  rows.append(dict(weights=weights,control=control,isolated=v,core_expected=want,mixed=mixed))
 assert before=={a:record_value(sem.snapshot(nr,packs[a]))for a,nr in nrs.items()}
 return rows
corpus=dict(semantic_corpus());orig=json.loads((R/'.local_agent/eval-revisit-20261016/control-results.json').read_bytes())
cache={}
for row in orig['mechanisms']:
 stop();c=corpus[row['fixture']];s=GameSession.replay(c,deserialize_game_record(json.dumps(row['game_record'])))
 if row['fixture']not in cache:cache[row['fixture']]={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','leaf')}
 nrs=cache[row['fixture']];packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()}
 values=check(c,packs,nrs,s.state.position);assert record_value(s.state)==row['state'];states.append(dict(fixture=row['fixture'],seed=row['seed'],ply=row['ply'],values=values,complete_root_restored=True))
for builder,posfn in S4_CASES:
 stop();c=compile_semantic_ruleset(builder());nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','leaf')}
 for owner in (0,1):
  p=replace(posfn(c.support),side_to_move=owner);packs={}
  for a,nr in nrs.items():
   d=dict(expected_snapshot(p,nr,c),ply=0);d['board']=[None if x is None else list(x)for x in d['board']];d['hands']=[list(x)for x in d['hands']];packs[a]=sem.pack_position(nr,d)
  s4.append(dict(fixture=builder.__name__,owner=owner,position=record_value(p),values=check(c,packs,nrs,p),scope='SpecificationPosition, notclaimedreachableSession'))
for prefix in (0,32,128,512,1023,1024):
 stop();s=cycle(max_ply=1024,repetition=10000,prefix=prefix);c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','leaf')};packs={a:pack_semantic_search_position(c,nr,s)for a,nr in nrs.items()}
 if prefix<1024:values=check(c,packs,nrs,s.state.position);histories.append(dict(prefix=prefix,history_entries=len(s.state.history),values=values,root_state=record_value(s.state)))
 else:
  errors={}
  for a,nr in nrs.items():
   try:sem.evaluate(nr,packs[a],localized_control_values=profiles[0])
   except NotImplementedError as exc:errors[a]=str(exc)
   else:raise AssertionError('CapacityMustRefuse')
  assert errors['normal']==errors['leaf'];histories.append(dict(prefix=prefix,errors=errors))
 print('HISTORY',prefix,flush=True)
s=session_after(('e2e4','d7d5','f1b5','c7c6'));c=s.compiled;nrs={a:compile_native_semantic_rules(c,**({}if a=='normal'else dict(backend_module=m)))for a in('normal','leaf')}
for row in orig['transport']:
 stop();packs={a:sem.pack_position(nr,row['payload'])for a,nr in nrs.items()};transport.append(dict(label=row['label'],values=check(c,packs,nrs),payload=row['payload'],scope='ActualPENDINGandEditedeventtransport, editedisnotsecondtrajectory'))
before=record_value(s.state)
with(P/'coalescence-v2-qualification-queries.jsonl').open('x',encoding='utf-8')as out:
 for q in (0,1,4):
  for tt in (0,1):
   eng={a:SemanticSearchEngine(c,nr,dynamic_values=(2,3,5),localized_control_values=profiles[0],tt_megabytes=tt,ordering_cache_enabled=False)for a,nr in nrs.items()}
   for rep in range(2):
    pair=[]
    for a in (('normal','leaf')if rep==0 else('leaf','normal')):
     stop();t=time.perf_counter();r=eng[a].search(s,SearchLimits(max_depth=2,max_nodes=256,max_time_seconds=None,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0),root_window_pruning=True);checked_replay(s,nrs[a],r);assert record_value(s.state)==before;z=dict(kind='ACTUAL_QUERY',fixture='actual_pending',q=q,tt=tt,rep=rep,arm=a,caller_seconds=time.perf_counter()-t,result=record_value(r));pair.append(z);queries.append(z);out.write(json.dumps(z)+'\n');out.flush()
    assert {k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
write_record(P/'coalescence-v2-qualification-results.json',dict(complete=True,states=states,s4=s4,histories=histories,transport=transport,queries=queries,seconds=time.perf_counter()-start,scope='Actual INLINEleaf evaluated against Coremechanical9bins and baseline, fullparentcontext unchanged. 280fixturestates,12S4specificationstates,6actualcyclichistoryprefix/capacity,3transport,24qTT/PVqueries; finitecoverage, notall-domainproof.'))
print('QUALIFIED',len(states),len(s4),len(queries),time.perf_counter()-start,flush=True)
