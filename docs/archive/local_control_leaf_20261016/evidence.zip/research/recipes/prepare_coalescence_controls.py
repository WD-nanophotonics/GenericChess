from pathlib import Path
import json
R=Path.cwd();P=R/'.local_agent/local-control-20261016';A=R/'.local_agent/attack-membership-20261016'
s=(P/'coalescence_pilot.py').read_text().replace('coalescence-pilot-plan.json','coalescence-controls-plan.json').replace('coalescence-pilot-queries.jsonl','coalescence-controls-queries.jsonl').replace('coalescence-pilot-results.json','coalescence-controls-results.json')
s=s.replace("dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1)","dynamic_values=(2,3,5)if profile=='dynamic235'else None,localized_control_values=None")
(P/'coalescence_controls.py').write_bytes(s.encode());q=json.loads((P/'coalescence-pilot-plan.json').read_bytes());q.update(question='Does the sharedhelper regress actual static or dynamic-only consumers even when9isabsent?',profiles=['static','dynamic235'],repetitions=8,whole_seconds=300,expected_seconds=60,scope='512exposedfixed512node actualfullquerycontrol calls16rootsx2profilesx8repsx2arms, allnon-time equality. Cheapnegativecontrols before anycoalescenceadoption; actualcost/adversefamiliesretained, notdynamicprofile sameobjectiveasstatic.')
(P/'coalescence-controls-plan.json').write_bytes(json.dumps(q,indent=2).encode());print('FROZEN512CONTROLS')
