from pathlib import Path
import json
P=Path('.local_agent/local-control-20261016');s=(P/'finite_alias_v2.py').read_text()
s=s.replace('finite-alias-v2-plan.json','finite-alias-completion-plan.json').replace('finite-alias-v2-results.json','finite-alias-complete-results.json').replace('finite-alias-v2-queries.jsonl','finite-alias-completion-queries.jsonl')
s=s.replace("for prefix in plan['cases']:","oldrow=json.loads((P/'finite-alias-v2-queries.jsonl').read_text().splitlines()[0]);assert oldrow['prefix']==0\nfor prefix in plan['cases']:")
a=s.index(" core=AlphaBetaPlayer(");b=s.index(" t=copy(s);trace=[]",a)
old=s[a:b]
new=""" if prefix==0:
  rows.append(oldrow)
 else:
"""+'\n'.join(' '+line for line in old.splitlines())+'\n'
s=s[:a]+new+s[b:]
s=s.replace("assert t.result.status.value=='draw'","assert t.state.terminal_status.status.value=='repetition' and t.state.terminal_status.winner is None")
s=s.replace("new_queries=4,","new_queries=2,retained_queries_including_v2_partial=4,missing_original_query_receipts=2,")
s=s.replace("TWOactuallegalrecords, noforgedcounts.","TWOactuallegalrecords, noforgedcounts. CompletionREUSES2savedv2prefix0queryreceiptsandexecutesONLY2remainingprefix8queries. V1/v2failedjobscapsnotrewritten; statusassertion correctedtoactualrepetition/winnerNone. Reconstructfirstuniquechainfrompublicrecord, notclaimoriginaltracebytes.")
s=s.replace("4newfinitequeries plus2forceddiagnostic continuations <=16newmoves","2newfinitequeries plus2retainedv2partialqueries;2recordedforceddiagnostic chains16moves, firstv2failed12unserializededgechecks keptseparate")
(P/'complete_finite_alias.py').write_bytes(s.encode())
(P/'finite-alias-v2-failure.json').write_bytes(json.dumps(dict(cause="SessionResult.status is repetition, not literal draw; winnerNone is actual draw outcome",queries_executed=2,retained_query_receipts=2,retained_file="finite-alias-v2-queries.jsonl",first_forced_chain_checked_edges_without_saved_trace=12,old_job_complete=False,corrected_completion="complete_finite_alias.py reusesexactpartialqueries; no firstrootqueryrerun",scope="Failedassertionnotwronggameexecution. Originalsource/logsretained; nofrozencomparativecaprewrite."),indent=2).encode())
