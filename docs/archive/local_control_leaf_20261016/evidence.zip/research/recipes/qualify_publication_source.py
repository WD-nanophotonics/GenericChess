from pathlib import Path
import json,zipfile,shutil,subprocess,os,sys,sysconfig,time,hashlib
R=Path.cwd();P=R/'.local_agent/local-control-20261016';S=P/'publication-source/source';S.mkdir(parents=True,exist_ok=False)
base=R/'docs/archive/dynamic_input_cost_20261016/evidence.zip';assert hashlib.sha256(base.read_bytes()).hexdigest()=='1180b5eea69f9ed8aaffc7461e79eb24f70d8704810132439cc77d6bc4824978'
n=0
with zipfile.ZipFile(base)as z:
 for name in z.namelist():
  if name.startswith('source/')and not name.endswith('/'):
   dest=S/Path(name).relative_to('source');assert dest.resolve().is_relative_to(S.resolve());dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(name));n+=1
overrides=['generic_chess/_native/'+name for name in('native_module.c','native_semantic_rules.c','native_semantic_rules.h','native_semantic_runtime.c','native_semantic_runtime.h')]
targets=json.loads((R/'.local_agent/attack-membership-20261016/publication-targets.json').read_bytes())+['tests/workflow/test_slack_transport.py']
copied=overrides+targets+['scripts/research_record.py']
copied += [str(f.relative_to(R)).replace('\\','/')for f in(R/'tools').rglob('*.py')if '__pycache__'not in str(f)and 'local_agent'in str(f)]
copied+=['tools/__init__.py']if(R/'tools/__init__.py').exists()else[]
for rel in copied:
 f=R/rel;dest=S/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
out=S/'generic_chess'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted((S/'generic_chess/_native').glob('*.c'))],'-o',str(out)]
t=time.perf_counter();build=subprocess.run(cmd,capture_output=True,timeout=180);assert build.returncode==0,build.stderr
env=dict(os.environ);env.pop('PYTHONPATH',None)
cmd=[str(R/'.venv/Scripts/python.exe'),'-X','utf8','-m','pytest','-o','addopts=','-q',*targets,'--basetemp='+str(P/'pytest-publication-temp'),'-o','cache_dir='+str(P/'pytest-publication-cache')]
r=subprocess.run(cmd,cwd=S,capture_output=True,text=True,encoding='utf-8',env=env,timeout=900)
d=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,base_source_files=n,source_overrides=overrides,support_files=copied,targets=targets,source_hashes={rel:hashlib.sha256((S/rel).read_bytes()).hexdigest()for rel in copied},scope='Fresh307source compactdependency pluscurrent5C/H/affectedtests/existinglocalagenttools, independentlyrebuilt Native inexportsource. DoesnotexecuteAUXprograms orhistoricalqueryproducers. Originalnormalfullsuite separate.')
(P/'publication-source-tests-private.json').write_bytes(json.dumps(d,indent=2).encode());print(r.stdout[-1800:]);print(r.stderr[-500:]);print('SOURCE_TESTS_DONE',r.returncode,d['seconds']);raise SystemExit(r.returncode)
