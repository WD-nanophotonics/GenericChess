from pathlib import Path
import json,shutil,subprocess,os,time,sys
R=Path.cwd();P=R/'.local_agent/local-control-20261016';B=P/'reader-inputs';S=P/'publication-source/source'
# Extend the existing reader, keeping all query phases rather than only completions.
p=P/'consumer.py';s=p.read_text()
needle=' ("coalescence-pilot-results.json","old","rows"),'
s=s.replace(needle,needle+'''
 ("coalescence-controls-results.json","old","rows"),
 ("coalescence-v2-pilot-results.json","old","rows"),
 ("coalescence-v2-controls-results.json","old","rows"),
 ("outline-pilot-results.json","old","rows"),
 ("cancel-results.json","old","rows"),
 ("api-results.json","old","rows"),''')
s=s.replace(' ("coalescence-qualification-results.json","pending","queries"),',' ("coalescence-qualification-results.json","pending","queries"),\n ("coalescence-v2-qualification-results.json","pending","queries"),')
s=s.replace('for fn in ("qualification-results.json","coalescence-qualification-results.json"):','for fn in ("qualification-results.json","coalescence-qualification-results.json","coalescence-v2-qualification-results.json"):')
p.write_bytes(s.encode())
for name in ('coalescence-controls-results.json','coalescence-v2-controls-results.json','coalescence-v2-pilot-results.json','coalescence-v2-qualification-results.json','outline-pilot-results.json','cancel-results.json'):
 shutil.copyfile(P/name,B/name)
shutil.copyfile(P/'coalescence-transfer/transfer-results.json',B/'coalescence-transfer-results.json')
shutil.copyfile(P/'api-curve/results.json',B/'api-results.json')
dst=B/'coalescence-roots';dst.mkdir(exist_ok=False)
for f in(P/'coalescence-transfer/transfer-roots').glob('*.json'):shutil.copyfile(f,dst/f.name)
# Test actual current source export with normal dependencies, never historical kernels.
env=dict(os.environ);env.pop('PYTHONPATH',None)
t=time.perf_counter();r=subprocess.run([str(R/'.venv/Scripts/python.exe'),'-X','utf8',str(P/'consumer.py'),str(B)],cwd=S,env=env,capture_output=True,text=True,encoding='utf-8',timeout=900)
d=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,scope='First complete actualcurrentproductsource replay ofallnewretained2505queryreceipts plusdirectcontexts/components; nosearch/timingrerun. Fresh307source+actualoverrides/tests/tools, normaldependencies.')
(P/'reader-first-private.json').write_bytes(json.dumps(d,indent=2).encode());print(r.stdout[-1800:]);print(r.stderr[-2500:]);raise SystemExit(r.returncode)
