from pathlib import Path
import shutil
P=Path('.local_agent/local-control-20261016');D=Path('docs/archive/local_control_leaf_20261016')
shutil.copyfile(D/'evidence.zip',P/'publication-copy-v1.zip');shutil.copyfile(D/'manifest.json',P/'publication-copy-v1-private.json')
s=(P/'package.py').read_text().replace("D.mkdir(parents=True,exist_ok=False)","assert D.resolve().is_relative_to(R.resolve());D.mkdir(parents=True,exist_ok=True)")
s=s.replace("for p in P.glob('*.json'):\n if p.name.endswith", "for p in P.glob('*.json'):\n if p.name=='qualification-summary.json':continue\n if (B/p.name).is_file() and p.read_bytes()==(B/p.name).read_bytes():continue\n if p.name.endswith")
(P/'package_v2.py').write_bytes(s.encode())
