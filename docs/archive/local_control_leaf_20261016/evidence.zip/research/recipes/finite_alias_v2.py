from pathlib import Path
from copy import copy
import json,sys,time
R=Path.cwd();P=R/'.local_agent/local-control-20261016';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from test_native_q_history_deferral import cycle,checked_replay
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
from generic_chess.native import semantic as sem,SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.session.serialization import serialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value,write_record
plan=dict(question='Does an actual material+3+9 feature alias distinguish finite-horizon target ambiguity from optimal-return insufficiency?',changed_premise='Correctedqualification afteroriginalharness AttributeError onSessionResult.is_terminal following2querycalls withMISSINGreceipts. Originalfailed30s jobnotrewritten orclaimedcomplete; thisnew<=30s qualification usesSAMEfinite4ply/4096/3s caps andimmediaterow append, noextra labelselection. Actual9featurecostimproved, but faster/ richerinputalone notutility. PriorauxV1aliasdoesnotanswerwhether3+9 targetdifferenceimplies gamevaluefailure. Usepreexistingforcedcycle withTWOactuallegalrecords, noforgedcounts.',cases=[0,8],max_ply=512,repetition=4,depth=4,nodes=4096,seconds=3,whole_seconds=30,expected_seconds=2,decision='Checkfeatureequality+Core/NativefiniteQ+fulluniquelegalcontinuation. OppositefiniteQwithsameeventualforcedDRAW wouldrefute inferring optimalvalueencodingfailure fromfinitealias alone; do notfit exposedlabels orbuildnewmodel.',scope='4newfinitequeries plus2forceddiagnostic continuations <=16newmoves, not evaluationgames/training/solver. Wholegeneratedtarget staysfullhistory; existingcycle specificationcase is scopedcounterexample, nofrequencyclaim.')
(P/'finite-alias-v2-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
start=time.perf_counter();rows=[];runs=[];querylog=(P/'finite-alias-v2-queries.jsonl').open('x',encoding='utf-8');bvs={'K':0,'Z':0,'F':20,'G':100}
class Mixed:
 def __init__(self,c):self.c=c
 def evaluate(self,state):
  p=state.position;side=p.side_to_move
  mat=sum((1 if x.owner==side else -1)*bvs[x.current_type_id]for x in p.board if x is not None)+sum((1 if owner==side else -1)*bvs[t]*n for owner,hand in enumerate(p.hands)for t,n in hand.items())
  f=reference_features(self.c,p);v=localized_control_features(p,self.c)
  return max(-90000000,min(90000000,mat+(1 if side==0 else -1)*(sum(w*x for w,x in zip((2,3,5),f))+v[0]-v[-1])))
 def type_value(self,t):return bvs[t]
 def capture_order_value(self,m,c):return 10*bvs[c.current_type_id]-bvs[m.current_type_id]
for prefix in plan['cases']:
 for n in('rollout','advisor','slack'):
  flags=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
 s=cycle(max_ply=512,repetition=4,prefix=prefix);old=s.compiled;c=SearchMetadataAdapter(ir=old.ir,_legacy_compiled=old._legacy_compiled,support=old.support)
 # Actual public replay under the identical facade, no private-state injection.
 from generic_chess.session.session import GameSession
 s=GameSession.replay(c,s.to_record());nr=compile_native_semantic_rules(c);np=pack_semantic_search_position(c,nr,s);before=record_value(s.state)
 feature=dict(dynamic=sem.dynamic_features(nr,np),spatial=sem.spatial_features(nr,np))
 lim=SearchLimits(max_depth=4,max_nodes=4096,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0)
 core=AlphaBetaPlayer(c,evaluator_override=Mixed(c),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,lim)
 native=SemanticSearchEngine(c,nr,board_values=bvs,hand_values=bvs,dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False).search(s,lim,root_window_pruning=True)
 assert core.completed_depth==native.completed_depth==4 and core.score==native.score
 checked_replay(s,nr,native);assert record_value(s.state)==before
 rows.append(dict(prefix=prefix,state=before,game_record=json.loads(serialize_game_record(s.to_record())),features=record_value(feature),core=record_value(core),native=record_value(native)))
 querylog.write(json.dumps(rows[-1])+'\n');querylog.flush()
 t=copy(s);trace=[]
 while not t.state.terminal_status.is_terminal:
  assert len(trace)<16 and time.perf_counter()-start<plan['whole_seconds']
  aa=t.legal_actions();assert len(aa)==1,aa
  action=aa[0];t.submit(action);trace.append(dict(action=record_value(action),state=record_value(t.state),legal_frontier_size=1))
 assert t.result.status.value=='draw'
 runs.append(dict(prefix=prefix,full_unique_legal_chain=True,edges=trace,terminal=record_value(t.result),final_record=json.loads(serialize_game_record(t.to_record()))))
assert rows[0]['state']['position']==rows[1]['state']['position']and rows[0]['features']==rows[1]['features']
assert rows[0]['native']['score']!=rows[1]['native']['score']
out=dict(complete=True,rows=rows,continuations=runs,new_queries=4,forced_diagnostic_continuations=2,new_forced_edges=sum(len(r['edges'])for r in runs),seconds=time.perf_counter()-start,scope=plan['scope'],conclusion='Equalmaterial+3+spatial9inputs withtwoactualrecords give differentD4bootstrapobjectives, yetBOTH completeuniquelegalchains endactualDRAW. Thereforefinitehorizoninputaliasalone doesnotproveoptimalWDLencodingfailure. History stillrequired for correctfinite/searchterminal behavior; no claimscalaraveragesimpossible orNNneeded.')
querylog.close();write_record(P/'finite-alias-v2-results.json',out);print('FINITE_ALIAS',[(r['prefix'],r['native']['score'])for r in rows],[(r['prefix'],len(r['edges']),r['terminal'])for r in runs],flush=True)
