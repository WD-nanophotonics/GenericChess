from pathlib import Path
import sys,json,time,statistics
R=Path.cwd();P=R/'.local_agent/local-control-20261016';sys.path.insert(0,str(R))
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,GameSession
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from scripts.research_record import record_value,write_record
plan=dict(question='Do active3+9 terms actually pay two near-additive legality enumerations in an ordinary leaf?',changed_premise='Actual9identityfixed/qualified; remaining3+9 loops sameparentmechanicallegality in realgc_semantic_probe_material. ExistingV3checkpointbinds both, no newmodel/fit.',cases=[61401,61402,61403,61404,61801,61802,61803,61804,62201,62202,62203,62204,62601,62602,62603,62604],repetitions=16,profiles=['static','dynamic','control','both'],whole_seconds=120,expected_seconds=10,scope='1024direct actualleafcalls on16exposedfullcontexts, nosearch/objectivemediation incomponentcost. Allscorelinearidentities/rootrestore required. ExistingactualNativeone-shotconsumer; noAUXcode/training/newAPI.',decision='Onlyifbothcostnearadditive andsourceconfirms duplicate work, prepare minimalshared-enumeration PRIVATEpilot; no productsecondoptimization yet.')
(P/'mixed-cost-plan.json').write_bytes(json.dumps(plan,indent=2).encode());start=time.perf_counter();rows=[]
for seed in plan['cases']:
 d=json.loads((R/'.local_agent/api-ready-20261016/roots'/f'{seed}.json').read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));nr=compile_native_semantic_rules(c);np=pack_semantic_search_position(c,nr,s);before=record_value(sem.snapshot(nr,np));times={k:[]for k in plan['profiles']};values={}
 for rep in range(plan['repetitions']):
  assert time.perf_counter()-start<plan['whole_seconds']
  for n in('rollout','advisor','slack'):
   flag=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not(flag.get('stopped')or flag.get('user_paused'))
  arms=plan['profiles'][rep%4:]+plan['profiles'][:rep%4]
  for arm in arms:
   t=time.perf_counter();v=sem.evaluate(nr,np,dynamic_values=(2,3,5)if arm in('dynamic','both')else None,localized_control_values=(1,0,0,0,0,0,0,0,-1)if arm in('control','both')else None);times[arm].append(time.perf_counter()-t);values[arm]=v
 assert values['both']-values['static']==values['dynamic']-values['static']+values['control']-values['static']
 assert record_value(sem.snapshot(nr,np))==before
 med={a:statistics.median(z)for a,z in times.items()};rows.append(dict(seed=seed,board=d['board'],scores=values,seconds=times,medians=med,both_over_sum=med['both']/(med['dynamic']+med['control']),complete_root_restored=True))
write_record(P/'mixed-cost-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,actual_calls=1024,scope=plan['scope']));print('MIXED_COST',[(r['seed'],round(r['both_over_sum'],3))for r in rows],flush=True)
