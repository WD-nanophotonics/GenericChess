from pathlib import Path
import json,sys,time,threading,importlib.util
R=Path.cwd();P=R/'.local_agent/local-control-20261016';sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.cancellation import CancellationToken
from test_native_q_history_deferral import checked_replay
spec=importlib.util.spec_from_file_location('cancel_coalescence._native_core',P/'coalesced_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=dict(question='Do actual midsearch cancellations in active3+9 preserve complete root/PVhistory and clean retry for both deliveredminimal9 andprivatecoalescence?',cases=[61401,61801,62201,62601],delays=[.01,.03],arms=['normal','coalesced'],whole_seconds=120,expected_seconds=10,scope='16actualtimercancel attempts plus32fixednode retry/coldqueries, q1/TT0. Cooperative atomic feature latency measured, not strictdeadline/insideinstruction injection. No AUXprograms.')
(P/'cancel-plan.json').write_bytes(json.dumps(plan,indent=2).encode());start=time.perf_counter();rows=[]
def engine(c,nr):return SemanticSearchEngine(c,nr,dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False)
with(P/'cancel-queries.jsonl').open('x',encoding='utf-8')as log:
 for seed in plan['cases']:
  d=json.loads((R/'.local_agent/api-ready-20261016/roots'/f'{seed}.json').read_bytes());x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));before=record_value(s.state)
  for arm in plan['arms']:
   nr=compile_native_semantic_rules(c,**({}if arm=='normal'else dict(backend_module=m)))
   for delay in plan['delays']:
    assert time.perf_counter()-start<plan['whole_seconds']
    for n in('rollout','advisor','slack'):
     flags=json.loads((R/'.local_agent'/f'{n}.json').read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
    e=engine(c,nr);token=CancellationToken();called=[]
    def request():called.append(time.perf_counter());token.cancel()
    timer=threading.Timer(delay,request);t=time.perf_counter();timer.start()
    try:r=e.search(s,SearchLimits(max_depth=16,max_nodes=1000000,max_time_seconds=1,quiescence_max_depth=1,quiescence_hard_max_depth=8),token,root_window_pruning=True)
    finally:timer.cancel();timer.join(timeout=.1)
    elapsed=time.perf_counter()-t;checked_replay(s,nr,r);assert record_value(s.state)==before
    z=dict(kind='ACTUAL_QUERY',seed=seed,arm=arm,delay=delay,phase='timer_attempt',cancel_requested_seconds=[x-t for x in called],caller_seconds=elapsed,result=record_value(r),root_restored=True);rows.append(z);log.write(json.dumps(z)+'\n');log.flush()
    pair=[]
    for phase,ee in [('retry',e),('fresh',engine(c,nr))]:
     t=time.perf_counter();r=ee.search(s,SearchLimits(max_depth=2,max_nodes=128,max_time_seconds=None,quiescence_max_depth=1,quiescence_hard_max_depth=8),root_window_pruning=True);checked_replay(s,nr,r);assert record_value(s.state)==before;z=dict(kind='ACTUAL_QUERY',seed=seed,arm=arm,delay=delay,phase=phase,caller_seconds=time.perf_counter()-t,result=record_value(r),root_restored=True);rows.append(z);pair.append(z);log.write(json.dumps(z)+'\n');log.flush()
    assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
write_record(P/'cancel-results.json',dict(complete=True,rows=rows,seconds=time.perf_counter()-start,scope=plan['scope']));print('CANCEL',len(rows),[(r['seed'],r['arm'],r['delay'],r['result']['termination_reason'],round(r['caller_seconds'],4))for r in rows if r['phase']=='timer_attempt'],flush=True)
