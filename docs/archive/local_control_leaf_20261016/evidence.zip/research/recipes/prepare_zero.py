from pathlib import Path
import json
R=Path.cwd();P=R/'.local_agent/local-control-20261016';A=R/'.local_agent/attack-membership-20261016'
s=(A/'leaf_pilot.py').read_text().replace("P=R/'.local_agent/attack-membership-20261016'","P=R/'.local_agent/local-control-20261016'").replace("P/'leaf_native_core.pyd'","R/'.local_agent/attack-membership-20261016/leaf_native_core.pyd'")
s=s.replace('leaf-pilot-plan.json','zero-plan.json').replace('leaf-pilot-queries.jsonl','zero-queries.jsonl').replace('leaf-pilot-results.json','zero-results.json')
s=s.replace("localized_control_values=(1,0,0,0,0,0,0,0,-1)","localized_control_values=None if profile=='absent'else (0,)*9 if profile=='zero'else (1,0,0,0,0,0,0,0,-1)")
s=s.replace("group=[];arms=plan['arms'][rep%2:]+plan['arms'][:rep%2]\n    if rep%2:arms=list(reversed(arms))","group=[];arms=list(plan['arms']) if rep%2==0 else list(reversed(plan['arms']))")
s=s.replace("summary=[]","for case in plan['cases']:\n for rep in range(plan['repetitions']):\n  for arm in plan['arms']:\n   g=[z for z in rows if z['seed']==case['seed']and z['rep']==rep and z['arm']==arm and z['profile']in('absent','zero')];assert len(g)==2;assert{k:v for k,v in g[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in g[1]['result'].items()if k!='elapsed_seconds'}\nsummary=[]")
plan=json.loads((A/'leaf-pilot-plan.json').read_bytes());plan.update(question='Is a supplied all-zero localcontrol neutral in all ordinary fullquery fields but still charged enumeration cost?',cases=[dict(seed=61401,board=4),dict(seed=62601,board=16)],profiles=['absent','zero','nonzero'],planned_slots=24,whole_seconds=120,expected_seconds=15,decision='Diagnostic only: nozeroskip adoption. Preserve explicitcapacityrefusal and nestederror opportunities; scoresbeingzero alone is not license to change extraction/errorcontract or requiredmetadata.',scope='24exposedfixed512node fullqueries,2rootsx3profilesx2repsx2arms. Baselineandidentity compare, zero-to-absent fullnon-time equality onordinaryvalidstates; errorsseparate. Notnewtraining orv3usagepopulationclaim.')
(P/'zero-plan.json').write_bytes(json.dumps(plan,indent=2).encode());(P/'zero.py').write_bytes(s.encode())
test=(P/'test_inline_fault.py').read_text()
test+='''
@pytest.mark.parametrize("builder,position_for", (
    (s4.multiple_replies_ruleset, s4.multiple_replies_position),
    (s4.full_child_state_ruleset, s4.full_child_state_position),
))
def test_zero_control_retains_observed_extraction_error_contract(feature_fault_kernel, builder, position_for):
    kernel = feature_fault_kernel
    c = compile_semantic_ruleset(builder())
    nr = compile_native_semantic_rules(c, backend_module=kernel)
    p = position_for(c.support)
    payload = dict(expected_snapshot(p, nr, c), ply=0)
    payload["board"] = [None if x is None else list(x) for x in payload["board"]]
    payload["hands"] = [list(x) for x in payload["hands"]]
    np = sem.pack_position(nr, payload)
    before = sem.snapshot(nr, np)
    kernel.test_feature_set(False)
    baseline = sem.evaluate(nr, np)
    assert sem.evaluate(nr, np, localized_control_values=(0,) * 9) == baseline
    kernel.test_feature_set(True)
    assert sem.evaluate(nr, np) == baseline
    assert kernel.test_feature_failures() == 0
    with pytest.raises(RuntimeError, match="feature extraction failed"):
        sem.evaluate(nr, np, localized_control_values=(0,) * 9)
    assert kernel.test_feature_failures() == 1
    kernel.test_feature_set(False)
    assert sem.snapshot(nr, np) == before
'''
(P/'test_zero_contract.py').write_bytes(test.encode())
print('FROZEN24ZERO')
