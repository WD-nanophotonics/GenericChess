from pathlib import Path
import json,sys,sysconfig,subprocess,shutil
R=Path.cwd();P=R/'.local_agent/local-control-20261016';A=R/'.local_agent/attack-membership-20261016'
plan=dict(question='After removing actual INLINE leaf identity cost, does copying only live parent storage add enough useful saving to justify a second line change?',changed_premise='Getter-only4cell was notactiveconsumer; actualinlineleaf nowqualified andchangedbottleneck. Existinggc_semantic_runtime_copy_live_position alreadyusedbydynamicandretainsfullACTUALhistory, ignoresonlyunusedcapacity.',cases=[dict(seed=b*100+61001+i,board=b)for b in (4,8,12,16)for i in range(4)],arms=['A_normal','B_identity','C_livecopy','D_both'],repetitions=2,nodes=512,depth=8,whole_seconds=300,expected_seconds=60,scope='128exposed fixedworkquery fourcell diagnostic, actualINLINEconsumer. No newgames/fit/AUXexecution; allnon-timefields equal required; per-root pairedratios andinteractionretained.',decision='IfincrementalDbeyondBsmall/adverse keepidentityonly. No work-cap extension/newpopulationclaim; beforeproductadoptionqualify anyselectedcombinedsource onCore/S4/history/errors.',cost='Fourprivatebuilds? onlytwoadditional C/Dbuilds and128fixed512nodecalls; <300s single run, existingfixtures/runner.')
# Match real existing root seeds 61401..61404 etc.
plan['cases']=[dict(seed=61001+b*100+i,board=b)for b in(4,8,12,16)for i in range(4)]
(P/'fourcell-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
for name,base in [('C_livecopy','final-source'),('D_both','leaf-pilot-source')]:
 S=P/(name+'-source');S.mkdir(exist_ok=False)
 for f in(A/base).iterdir():shutil.copyfile(f,S/f.name)
 p=S/'native_module.c';s=p.read_text();a=s.index('static int gc_semantic_probe_material(');b=s.index('static int gc_semantic_dynamic_feature_vector(',a);part=s[a:b];assert part.count('GCSemanticPosition view = *position;')==1
 part=part.replace('GCSemanticPosition view = *position;','GCSemanticPosition view;\n            gc_semantic_runtime_copy_live_position(&view, position);');p.write_bytes((s[:a]+part+s[b:]).encode())
 cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/(name+'_native_core.pyd'))]
 r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr
s=(A/'leaf_pilot.py').read_text();a=s.index('mods={}');b=s.index("plan=json.loads(",a)
s=s[:a]+"""mods={}
for arm,path in [('B_identity',R/'.local_agent/attack-membership-20261016/leaf_native_core.pyd'),('C_livecopy',P/'C_livecopy_native_core.pyd'),('D_both',P/'D_both_native_core.pyd')]:
 spec=importlib.util.spec_from_file_location('fourcell_'+arm+'._native_core',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
"""+s[b:]
s=s.replace("P=R/'.local_agent/attack-membership-20261016'","P=R/'.local_agent/local-control-20261016'")
s=s.replace('leaf-pilot-plan.json','fourcell-plan.json').replace('leaf-pilot-queries.jsonl','fourcell-queries.jsonl').replace('leaf-pilot-results.json','fourcell-results.json')
s=s.replace("a=='normal'","a=='A_normal'").replace("plan['profiles']","['control9']")
s=s.replace("group=[];arms=plan['arms'][rep%2:]+plan['arms'][:rep%2]\n    if rep%2:arms=list(reversed(arms))","group=[];arms=plan['arms'][rep:]+plan['arms'][:rep]\n    if rep%2:arms=list(reversed(arms))")
s=s.replace("assert len(group)==2","assert len(group)==4")
s=s.replace("membership_normal_ratio=med['leaf']/med['normal']","identity_normal_ratio=med['B_identity']/med['A_normal'],copy_normal_ratio=med['C_livecopy']/med['A_normal'],both_identity_ratio=med['D_both']/med['B_identity']")
(P/'fourcell.py').write_bytes(s.encode());print('BUILT_FROZEN128',flush=True)
