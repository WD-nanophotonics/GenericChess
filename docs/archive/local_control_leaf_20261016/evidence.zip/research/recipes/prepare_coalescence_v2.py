from pathlib import Path
import json,shutil,subprocess,sys,sysconfig,time
R=Path.cwd();P=R/'.local_agent/local-control-20261016';S=P/'coalesced-v2-source';S.mkdir(exist_ok=False)
d=json.loads((P/'coalescence-controls-results.json').read_bytes())
plan=dict(question='Does restoring the original3-only function eliminate the observed2-6percent collateral slowdown while keeping fused3+9 savings?',changed_premise='V1all16dynamic-only familyratios>1 across512matchedcalls; notanunchangedrerun. V1ongoingpanel/sourcefull stayimmutable andarenotv2execution. Source-levelreason: wrapperroutesNULLcontrol throughnew72bytezero/control tests; isolateoriginal3-onlybody.',decision='V2staysPRIVATE pending actualbaseline/static/dynamic/mixed andCore/history/errorqualification. Do notreinterpretV1freshclockresultsasV2. Ifregressionpersists do notshipcoalescence.',scope='Restore originaldynamic-feature function body verbatim, retainunchangedpairedhelper invokedonlywhen3+9active. NoAPI/defaults/weights/lifecycle orAUX changes.')
(P/'coalescence-v2-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
for f in(P/'coalesced-source').iterdir():shutil.copyfile(f,S/f.name)
prod=(R/'generic_chess/_native/native_module.c').read_text();i=prod.index('static int gc_semantic_dynamic_feature_vector(',prod.index('static int gc_semantic_probe_material('));j=prod.index('static int gc_semantic_compact_residual(',i);orig=prod[i:j]
p=S/'native_module.c';s=p.read_text();i=s.index('static int gc_semantic_dynamic_feature_vector(',s.index('static int gc_semantic_probe_material('));j=s.index('static int gc_semantic_compact_residual(',i)
assert 'return gc_semantic_dynamic_control_feature_vectors(rules, position, out, NULL);'in s[i:j]
p.write_bytes((s[:i]+orig+s[j:]).encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/'coalesced_v2_native_core.pyd')]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);assert r.returncode==0,r.stderr
for src,dest in [('coalescence_controls.py','coalescence_v2_controls.py'),('coalescence_pilot.py','coalescence_v2_pilot.py'),('qualify_coalescence.py','qualify_coalescence_v2.py')]:
 s=(P/src).read_text().replace("P/'coalesced_native_core.pyd'","P/'coalesced_v2_native_core.pyd'")
 for old in('coalescence-controls','coalescence-pilot','coalescence-qualification'):s=s.replace(old,'coalescence-v2-'+old.split('coalescence-')[1])
 (P/dest).write_bytes(s.encode())
for old in('coalescence-controls-plan.json','coalescence-pilot-plan.json'):
 q=json.loads((P/old).read_bytes());q['changed_premise']=plan['changed_premise'];q['scope']+=' PRIVATEv2, original3-onlybodyrestored; v1clocksnotreused.'
 (P/old.replace('coalescence-','coalescence-v2-',1)).write_bytes(json.dumps(q,indent=2).encode())
s=(P/'test_coalescence_fault.py').read_text().replace('coalesced-source','coalesced-v2-source');(P/'test_coalescence_v2_fault.py').write_bytes(s.encode())
print('PRIVATE_V2_BUILT')
