from pathlib import Path
import json,statistics,random,math
P=Path('.local_agent/local-control-20261016');d=json.loads((P/'transfer-results.json').read_bytes());assert d['complete']
rows=d['rows'];groups={}
for z in rows:groups.setdefault((z['seed'],z['board'],z['profile'],z['rep']),[]).append(z)
summary=[];overall=dict(joint=0,only_normal=0,only_leaf=0,neither=0,actual_queries=len(rows),planned=256,root_tails=sum(r['kind']=='ACTUAL_TERMINAL_TAIL'for r in d['roots']))
for board in(4,8,12,16):
 for profile in('static','control9'):
  families={};counts=dict(joint=0,only_normal=0,only_leaf=0,neither=0);depth=[];reasons={}
  for key,g in groups.items():
   if key[1:3]!=(board,profile):continue
   a={z['arm']:z for z in g};assert set(a)=={'A_normal','B_leaf'}
   assert all(z['kind']=='ACTUAL_QUERY'for z in g),g
   aa=a['A_normal'];bb=a['B_leaf'];x=aa['result']['completed_depth']==4;y=bb['result']['completed_depth']==4
   label='joint'if x and y else'only_normal'if x else'only_leaf'if y else'neither';counts[label]+=1;overall[label]+=1
   depth.append(bb['result']['completed_depth']-aa['result']['completed_depth'])
   for z in g:reasons[z['arm']+':'+z['result']['termination_reason']]=reasons.get(z['arm']+':'+z['result']['termination_reason'],0)+1
   if x and y:
    assert{k:v for k,v in aa['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in bb['result'].items()if k!='elapsed_seconds'}
    families.setdefault(key[0],[]).append(bb['caller_seconds']/aa['caller_seconds'])
  fm=[statistics.median(v)for v in families.values()];ci=None
  if len(fm)>=2:
   rng=random.Random(20261016);bs=sorted(statistics.median(rng.choices(fm,k=len(fm)))for _ in range(2000));ci=[bs[49],bs[1949]]
  summary.append(dict(board=board,profile=profile,counts=counts,families=len(fm),family_median_ratio=statistics.median(fm)if fm else None,family_bootstrap95=ci,family_ratios=families,depth_changes=dict(greater=sum(x>0 for x in depth),equal=depth.count(0),smaller=sum(x<0 for x in depth)),actual_termination_counts=reasons))
four=json.loads((P/'fourcell-results.json').read_bytes());fsummary=[]
for board in(4,8,12,16):
 g=[r for r in four['summary']if r['board']==board]
 fsummary.append(dict(board=board,identity_normal=statistics.median(r['identity_normal_ratio']for r in g),copy_normal=statistics.median(r['copy_normal_ratio']for r in g),both_identity=statistics.median(r['both_identity_ratio']for r in g),interaction_seconds=statistics.median((r['caller_medians']['D_both']-r['caller_medians']['C_livecopy'])-(r['caller_medians']['B_identity']-r['caller_medians']['A_normal'])for r in g),adverse_both_identity=[dict(seed=r['seed'],ratio=r['both_identity_ratio'])for r in g if r['both_identity_ratio']>1]))
out=dict(complete=True,transfer_seconds=d['seconds'],overall=overall,summary=summary,fourcell=fsummary,decision='Adopt minimal actualleafidentityonly ifremainingindependentCore/fullregression pass. Copyalone near1, incrementalcombined smallwideandadverse16; keepsecondlineprivate. Zeroordinaryfieldsneutralbutactualerrorcontractdiffers, nozeroskip.',scope='Developmentfullquerycost; conditionalcompletion ratios notquality/generalstrength. Familyresampling descriptiveonly; allcensors andactualtails retained.')
(P/'analysis.json').write_bytes(json.dumps(out,indent=2).encode());print(json.dumps(out,indent=2))
