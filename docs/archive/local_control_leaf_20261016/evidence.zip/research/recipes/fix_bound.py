from pathlib import Path
P=Path('.local_agent/local-control-20261016');s=(P/'qualify-v2.py').read_text().replace('(100000000,0,0,0,0,0,0,0,-100000000)','(1000000,0,0,0,0,0,0,0,-1000000)');(P/'qualify-v3.py').write_bytes(s.encode())
