from pathlib import Path
import json
P=Path('.local_agent/local-control-20261016');p=P/'qualify.py';s=p.read_text().replace("zero={typ:0 for typ in nrs['normal'].type_ids}","zero=(0,)*len(nrs['normal'].type_ids)");(P/'qualify-v2.py').write_bytes(s.encode())
(P/'initial-failures.json').write_bytes(json.dumps(dict(qualification='Before first stored query: raw sem.evaluate takes type-aligned numeric sequence, dict keys not accepted; corrected zero tuple.',fault='18fixture setuperrors before builds: default TEMP pytest root AccessDenied. Use explicit newprojectprivate --basetemp and cache_dir, do not inspect/change unrelatedtemp/security.',evidence=['qualification.log','fault-tests.log'],queries_before_failure=0),indent=2).encode())
