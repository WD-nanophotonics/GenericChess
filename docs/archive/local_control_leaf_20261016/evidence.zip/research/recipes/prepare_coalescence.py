from pathlib import Path
import json,shutil,sys,sysconfig,subprocess,time
R=Path.cwd();P=R/'.local_agent/local-control-20261016';S=P/'coalesced-source';S.mkdir(exist_ok=False)
plan=dict(question='Does one shared checked legality enumeration supply both existing active3 and9 terms at lower wholequerycost?',changed_premise='1024directactualleafcalls showbothcostnearadditive wide(.95-.998 ofsum); actualV3consumerbindsboth. Priorgetter-onlyfailureexcluded: thischangesverifiedgc_semantic_probe_material only.',scope='PRIVATEpilot only; dynamic-only/publicgetter/control-only behavior unchanged, no model/weights/API/defaults change. Fullparenthistory andS3/S4 mandatory; nochildidentity consumed. Precomputed3-onlyorderinginput fallsbackoriginal9enumeration; compactreusepreserved.',expected_seconds=180,whole_seconds=300,decision='First64exposed512node fullqueries allnon-timefields +Core/S4/history/error oracle mustpass beforeanynewprospectivepanel. Keepprivateifincrementalgainabsent; no productcoalescence adoption in firstminimalchange.')
(P/'coalescence-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
for f in(R/'generic_chess/_native').iterdir():
 if f.suffix in('.c','.h'):shutil.copyfile(f,S/f.name)
p=S/'native_module.c';s=p.read_text()
# Introduce only an internal paired-feature helper, retaining the old entry point.
i=s.index('static int gc_semantic_probe_material(')
decl='static int gc_semantic_dynamic_control_feature_vectors(const GCSemanticRules *rules, const GCSemanticPosition *position, int out[3], int *control);\n\n'
s=s[:i]+decl+s[i:]
a=s.index('static int gc_semantic_probe_material(');b=s.index('static int gc_semantic_dynamic_feature_vector(',a);part=s[a:b]
part=part.replace('    int cached_dynamic[3];','    int cached_dynamic[3];\n    int cached_control[GC_SEMANTIC_SPATIAL_CELLS];\n    int control_ready = 0;')
old='''        } else if (!gc_semantic_dynamic_feature_vector(rules, position, features)) {
            return GC_SEMANTIC_EVAL_ERROR;
        }'''
new='''        } else if (profile->localized_control_supplied) {
            if (!gc_semantic_dynamic_control_feature_vectors(
                    rules, position, features, cached_control)) return GC_SEMANTIC_EVAL_ERROR;
            control_ready = 1;
        } else if (!gc_semantic_dynamic_feature_vector(rules, position, features)) {
            return GC_SEMANTIC_EVAL_ERROR;
        }'''
assert part.count(old)==1;part=part.replace(old,new)
start=part.index('        /* Local control is residualized');end=part.index('        for (int cell = 0;',start)
# Original final loop computes and consumes; preserve it but use cachedvector when ready.
part=part[:start]+'        if (control_ready) memcpy(features, cached_control, sizeof(features));\n        else {\n'+part[start:end]+'''        for (int cell = 0; cell < GC_SEMANTIC_SPATIAL_CELLS; cell++) {
            features[cell] = 9 * (counts[0][cell] - counts[1][cell]) - (totals[0] - totals[1]);
        }
        }
'''+part[end:]
needle='''            features[cell] = 9 * (counts[0][cell] - counts[1][cell]) -
                (totals[0] - totals[1]);
'''
assert part.count(needle)==1;part=part.replace(needle,'')
s=s[:a]+part+s[b:]
a=s.index('static int gc_semantic_dynamic_feature_vector(',s.index('static int gc_semantic_probe_material('));b=s.index('static int gc_semantic_compact_residual(',a);body=s[a:b]
body=body.replace('static int gc_semantic_dynamic_feature_vector(','static int gc_semantic_dynamic_control_feature_vectors(',1).replace('    int out[3]) {','    int out[3], int *control) {',1)
body=body.replace('    int mobility[2] = {0, 0};','    int mobility[2] = {0, 0};\n    int controls[2][GC_SEMANTIC_SPATIAL_CELLS] = {{0}};')
needle='''            mobility[owner]++;'''
replacement='''            mobility[owner]++;
            if (control) {
                uint16_t target = (uint16_t)(raw & 0xFFu);
                unsigned row = (target / rules->board_size) * 3 / rules->board_size;
                unsigned col = (target % rules->board_size) * 3 / rules->board_size;
                if (row > 2) row = 2;
                if (col > 2) col = 2;
                controls[owner][row * 3 + col]++;
            }'''
assert body.count(needle)==1;body=body.replace(needle,replacement)
body=body.replace('    out[0] = mobility[0] - mobility[1];','    if (control) for (int cell = 0; cell < GC_SEMANTIC_SPATIAL_CELLS; cell++)\n        control[cell] = 9 * (controls[0][cell] - controls[1][cell]) - (mobility[0] - mobility[1]);\n    out[0] = mobility[0] - mobility[1];')
body+='''static int gc_semantic_dynamic_feature_vector(
    const GCSemanticRules *rules, const GCSemanticPosition *position, int out[3]) {
    return gc_semantic_dynamic_control_feature_vectors(rules, position, out, NULL);
}

'''
s=s[:a]+body+s[b:];p.write_bytes(s.encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(f)for f in sorted(S.glob('*.c'))],'-o',str(P/'coalesced_native_core.pyd')]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,timeout=120);(P/'coalescence-build-private.json').write_bytes(json.dumps(dict(returncode=r.returncode,seconds=time.perf_counter()-t,stderr=r.stderr.decode(errors='replace')),indent=2).encode());assert r.returncode==0,r.stderr
q=json.loads((R/'.local_agent/attack-membership-20261016/leaf-pilot-plan.json').read_bytes());q.update(cases=[dict(seed=61001+b*100+i,board=b)for b in(4,8,12,16)for i in range(4)],profiles=['mixed3plus9'],whole_seconds=180,expected_seconds=40,scope=plan['scope'])
(P/'coalescence-pilot-plan.json').write_bytes(json.dumps(q,indent=2).encode())
s=(R/'.local_agent/attack-membership-20261016/leaf_pilot.py').read_text().replace("P=R/'.local_agent/attack-membership-20261016'","P=R/'.local_agent/local-control-20261016'").replace("P/'leaf_native_core.pyd'","P/'coalesced_native_core.pyd'")
s=s.replace('leaf-pilot-plan.json','coalescence-pilot-plan.json').replace('leaf-pilot-queries.jsonl','coalescence-pilot-queries.jsonl').replace('leaf-pilot-results.json','coalescence-pilot-results.json')
s=s.replace("dynamic_values=None,localized_control_values=","dynamic_values=(2,3,5),localized_control_values=")
s=s.replace("group=[];arms=plan['arms'][rep%2:]+plan['arms'][:rep%2]\n    if rep%2:arms=list(reversed(arms))","group=[];arms=list(plan['arms']) if rep%2==0 else list(reversed(plan['arms']))")
(P/'coalescence_pilot.py').write_bytes(s.encode())
print('PRIVATE_COALESCENCE_BUILT')
