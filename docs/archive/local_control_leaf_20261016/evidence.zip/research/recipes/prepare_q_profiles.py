from pathlib import Path
import json
R=Path.cwd();P=R/'.local_agent/local-control-20261016'
test=R/'tests/product/test_native_dynamic_feature_views.py'
addition='''
@pytest.mark.parametrize("builder,position_for", S4_CASES)
@pytest.mark.parametrize("owner", (0, 1))
def test_inline_localized_leaf_keeps_real_child_aux_and_nested_reply_semantics(
    builder, position_for, owner,
):
    from generic_chess.learning.features import localized_control_features

    # Exercise the actual leaf consumer, not the separate public vector getter.
    compiled = compile_semantic_ruleset(builder())
    position = replace(position_for(compiled.support), side_to_move=owner)
    rules = compile_native_semantic_rules(compiled)
    payload = dict(expected_snapshot(position, rules, compiled), ply=0)
    payload["board"] = [None if p is None else list(p) for p in payload["board"]]
    payload["hands"] = [list(h) for h in payload["hands"]]
    packed = native.pack_position(rules, payload)
    before = native.snapshot(rules, packed)
    zero_material = (0,) * len(rules.type_ids)
    control = localized_control_features(position, compiled)
    for weights in (
        (1, 0, 0, 0, 0, 0, 0, 0, -1),
        (1000000, 0, 0, 0, 0, 0, 0, 0, -1000000),
    ):
        expected = (1 if owner == 0 else -1) * sum(
            w * value for w, value in zip(weights, control))
        expected = max(-90000000, min(90000000, expected))
        assert native.evaluate(
            rules, packed, board_values=zero_material, hand_values=zero_material,
            localized_control_values=weights,
        ) == expected
    assert native.snapshot(rules, packed) == before
'''
# Prepare only; do not adopt product implementation before transfer decision.
(P/'proposed-tests.py').write_bytes((test.read_text()+addition).encode())
src=R/'tests/development/test_native_dynamic_feature_error.py';s=src.read_text()
s=s.replace('("linear", "compact", "both")','("linear", "compact", "both", "localized")')
s=s.replace('    if profile in ("linear", "both"):', '    if profile == "localized":\n        kwargs["localized_control_values"] = (1, -1, 0, 0, 0, 0, 0, 0, 0)\n    if profile in ("linear", "both"):')
(P/'proposed-fault-tests.py').write_bytes(s.encode())
old=json.loads((R/'.local_agent/attack-membership-20261016/leaf-pilot-plan.json').read_bytes())
old.update(question='Does actual inline deferral preserve main and q/TT fixed-work results and fullPVhistory, beyond directscalar oracle?',profiles=['control9_q0_tt0','control9_q1_tt0','control9_q1_tt1','control9_q4_tt1'],cases=[dict(seed=61401,board=4),dict(seed=61801,board=8),dict(seed=62201,board=12),dict(seed=62601,board=16)],repetitions=2,whole_seconds=600,expected_seconds=120,scope='64exposedfixed512node fullconsumerqualification,4rootsx4qTTprofilesx2rep x2arms, exactallnon-timefields and checkedPVfullhistory. PriorqTTPENDING controls are separate. No newgames/modeltraining/strengthclaim.')
(P/'q-profile-plan.json').write_bytes(json.dumps(old,indent=2).encode())
s=(R/'.local_agent/attack-membership-20261016/leaf_pilot.py').read_text()
s=s.replace("P=R/'.local_agent/attack-membership-20261016'","P=R/'.local_agent/local-control-20261016'")
s=s.replace("P/'leaf_native_core.pyd'","R/'.local_agent/attack-membership-20261016/leaf_native_core.pyd'")
s=s.replace('leaf-pilot-plan.json','q-profile-plan.json').replace('leaf-pilot-queries.jsonl','q-profile-queries.jsonl').replace('leaf-pilot-results.json','q-profile-results.json')
s=s.replace("localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0","localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=int(profile[-1])")
s=s.replace("quiescence_max_depth=0,quiescence_hard_max_depth=0","quiescence_max_depth=int(profile.split('_q')[1][0]),quiescence_hard_max_depth=8 if '_q0_'not in profile else 0")
s=s.replace("r=e.search(", "r=e.search(")
s=s.replace("elapsed=time.perf_counter()-t;z.update","elapsed=time.perf_counter()-t;checked_replay(s,nrs[arm],r);z.update")
s=s.replace("sys.path.insert(0,str(R))","sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]\nfrom test_native_q_history_deferral import checked_replay")
# Correct previous pilot's accidental two rotations yielding same order both reps.
s=s.replace("group=[];arms=plan['arms'][rep%2:]+plan['arms'][:rep%2]\n    if rep%2:arms=list(reversed(arms))","group=[];arms=list(plan['arms']) if rep%2==0 else list(reversed(plan['arms']))")
(P/'q_profiles.py').write_bytes(s.encode())
print('PREPARED_TESTS_AND_FROZEN64')
