"""Nested exclusive formal-child cost attribution; no changed search results."""
import sys,time,importlib.util
from pathlib import Path
from collections import Counter
B=Path(__file__).parent
spec=importlib.util.spec_from_file_location('reprprobe',B/'representation_outcome.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
c=p.c;r=p.r;T=p.T;E=c.SemanticEngine
targets=[(E,'_transition','transition'),(E,'_trial_child_if_s3_legal','trial'),(E,'in_check','attack'),(E,'has_legal_action','availability'),(T,'legal_actions','runtime_frontier'),(r,'terminal_from_search_runtime','terminal'),(r,'_semantic_component_diff_hash','component_diff'),(r.RuntimeCountsSnapshot,'updated','snapshot'),(r.RuntimeHistoryContext,'append','context')]
originals=[getattr(o,a) for o,a,_ in targets]
calls=[];outside=Counter()
def stage(name,fn):
 def run(*a,**kw):
  bucket=p.stack[-1] if p.stack else outside
  frame=[time.perf_counter(),0.0];calls.append(frame)
  try:return fn(*a,**kw)
  finally:
   elapsed=time.perf_counter()-frame[0];calls.pop()
   bucket[name+'_calls']+=1;bucket[name+'_inclusive_seconds']+=elapsed;bucket[name+'_exclusive_seconds']+=elapsed-frame[1]
   if calls:calls[-1][1]+=elapsed
 return run
def install(active):
 T._push_impl=p.pushed if active else p.push;T.pop=p.popped if active else p.pop
 for (obj,attr,name),old in zip(targets,originals):
  fn=stage(name,old) if active else old
  setattr(obj,attr,staticmethod(fn) if attr=='append' else fn)
 c.sm.negamax=c.negamax if active else c.ng;c.sm._quiescence_runtime=c.quiescence if active else c.q;c.sm.noisy_child=p.classified if active else p.classify
def main():
 global calls,outside
 start=time.perf_counter();out=dict(complete=False,declared=dict(root='chess-middle',depth=2,nodes=32768,seconds=30,q=4,hard=8,orders=2,fuse_seconds=180),scope='Same formal children grouped by actual noisy classifier. Timers nested within selected seams; exclusive excludes selected nested seams only, not all Python children. Frontier operations outside formal push are reported separately, not falsely attributed to discarded children. Instrumentation overhead measured against ordinary opposite-order pairs. No child reuse or semantic changes.',rows=[])
 compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess'));board=c.CoreBoard(c.CASES[0],compiled);e=c.cm.w.weighted(compiled,c.VALUES['chess'])
 for order in range(2):
  pair=[]
  for measured in ((False,True) if order==0 else (True,False)):
   p.stack=[];p.pending={};p.totals=Counter();p.peak=0;c.iteration=c.qlevel=0;c.counts=Counter();calls=[];outside=Counter();install(measured)
   s=c.GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;t=time.perf_counter()
   try:d=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,c.SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   finally:install(False)
   assert not calls and not p.stack and not p.pending and s.state is board.initial and d.completed_depth==2
   v=c.record_value(d);pair.append(c.cm.clean(v));out['rows'].append(dict(order=order,measured=measured,wall=time.perf_counter()-t,decision=v,peak_pending=p.peak,outside_formal_push=dict(outside),stages=[dict(iteration=i,qphase=q,outcome=o,metric=k,value=v) for (i,q,o,k),v in sorted(p.totals.items())]))
  assert pair[0]==pair[1];c.write_record(B/'physical-outcome.json',out);print(order,'exact',flush=True);c.stopped();assert time.perf_counter()-start<180
 out['complete']=True;out['seconds']=time.perf_counter()-start;c.write_record(B/'physical-outcome.json',out)
if __name__=='__main__':main()
