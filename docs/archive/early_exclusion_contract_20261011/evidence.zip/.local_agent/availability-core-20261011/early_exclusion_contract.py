"""Finite counterexamples to excluding quiet children before terminal/check facts."""
import sys,time
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import initial_state,legal_actions,apply_action
from generic_chess.core.terminal import TerminalResult,TerminalStatus,terminal_result
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.quiescence import noisy_child,enemy_board_count,material_inventory
from scripts.research_record import record_value,write_record
from scripts.reserve_refresh_diagnostic import stopped
B=Path(__file__).parent
def select(state,c,source,target):
 return next(a for a in legal_actions(state,c) if getattr(a,'from_square',None) is not None and (a.from_square.file,a.from_square.rank)==source and (a.to_square.file,a.to_square.rank)==target)
def inspect(name,c,parent,a,witnesses):
 stopped();e=semantic_engine_for(c);side=parent.position.side_to_move;child=apply_action(parent,a,c);check=e.in_check(child.position,child.position.side_to_move);before=e.in_check(parent.position,side);enemies=enemy_board_count(parent.position,side);inventory=material_inventory(parent.position)
 actual=noisy_child(a,child,side,enemies,inventory,lambda:check)
 # This is an intentionally invalid observation proxy, never a searched state.
 proxy=replace(child,terminal_status=TerminalResult(TerminalStatus.ONGOING))
 omitted=noisy_child(a,proxy,side,enemies,inventory,lambda:check)
 runtime=SearchPathRuntime.from_state(parent,c,history_witnesses=witnesses)
 with runtime.pushed(a):assert runtime.position==child.position and runtime.terminal_status==child.terminal_status
 runtime.assert_balanced();assert runtime.position is parent.position
 return dict(name=name,parent=record_value(parent),action=record_value(a),child=record_value(child),parent_checked=before,child_checked=check,terminal=record_value(child.terminal_status),actual_quiet_classifier=actual,omitted_terminal_classifier=omitted,checked_evasion_must_bypass_quiet_classifier=before and not actual)
def main():
 start=time.perf_counter();rows=[]
 for cap in (1,512):
  c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),max_ply=cap));s=initial_state(c);a=select(s,c,(0,1),(0,2));r=inspect('quiet-pawn-max'+str(cap),c,s,a,(s.position,));assert r['actual_quiet_classifier']==(cap==1) and not r['omitted_terminal_classifier'];rows.append(r)
 board=[[None]*8 for _ in range(8)]
 for owner,tid,f,rank in ((0,'K',0,0),(1,'K',7,7),(0,'P',0,2),(1,'P',7,5)):board[rank][f]=Piece(owner,tid,tid)
 c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),repetition_limit=3,initial_position=tuple(map(tuple,board))));s=initial_state(c);witnesses=[s.position];moves=(((0,0),(1,0)),((7,7),(6,7)),((1,0),(0,0)),((6,7),(7,7)))
 found=False
 for i in range(16):
  a=select(s,c,*moves[i%4]);child=apply_action(s,a,c)
  if child.terminal_status.is_terminal:
   r=inspect('quiet-configured-third-occurrence',c,s,a,tuple(witnesses));assert r['actual_quiet_classifier'] and not r['omitted_terminal_classifier'];rows.append(r);found=True;break
  s=child;witnesses.append(s.position)
 assert found

 board=[[None]*8 for _ in range(8)]
 for owner,tid,f,rank in ((0,'K',4,0),(1,'K',7,7),(1,'R',4,7),(0,'P',0,2)):board[rank][f]=Piece(owner,tid,tid)
 imported_board=tuple(piece for rank in board for piece in rank)
 board[7][5]=board[7][4];board[7][4]=None
 c=compile_ruleset_for_execution(replace(build_builtin_ruleset('western_chess'),initial_position=tuple(map(tuple,board))));initial=initial_state(c);pos=replace(initial.position,board=imported_board);key=repetition_identity_key(pos,c)
 s=GameState(pos,0,((key,1),),initial.terminal_status,(HistoryRecord(key,-1,'',False),));s=replace(s,terminal_status=terminal_result(s,c));a=select(s,c,(4,0),(3,0));r=inspect('quiet-imported-checked-evasion',c,s,a,(pos,));assert r['parent_checked'] and not r['child_checked'] and not r['actual_quiet_classifier'];rows.append(r)
 write_record(B/'early-exclusion-contract.json',dict(complete=True,seconds=time.perf_counter()-start,scope='Four Agent-declared public/imported controls and exact runtime child/undo checks. Terminal omission proxy is intentionally invalid and never searched; falsifies a proposed early quiet-exclusion premise, not an existing product bug. Repetition control explicitly configures limit3 and uses a bounded actually applied prefix and complete witnesses, not imported/user history.',rows=rows));print([(r['name'],r['terminal'],r['actual_quiet_classifier'],r['parent_checked']) for r in rows])
if __name__=='__main__':main()
