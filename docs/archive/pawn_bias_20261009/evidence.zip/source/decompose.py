"""Frozen-row decomposition, no new sampling or price fit."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import json,hashlib,time
p=Path(__file__).parent;root=Path.cwd();src=root/'.local_agent/preparation-transfer-20261008/cross-game.json';out=p/'decomposition.json';assert not out.exists()
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();data=json.loads(src.read_bytes());start=time.perf_counter()
r={'complete':False,'input_sha256':sha(src),'producer_sha256':sha(Path(__file__)),'declaration_sha256':sha(p/'declaration.json'),'games':{}}
def rational(x):
 v=F(x).limit_denominator(100000);assert abs(float(v)-x)<1e-14;return v
def success(item):
 n=item['physical_replies'];x=item['success']
 if not n:assert x==0;return F(0)
 k=round(x*n);assert abs(k/n-x)<1e-14;return F(k,n)
def save():out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
save()
for game,g in data['games'].items():
 stats={};rows=[];common=sum(rational(next(x['mass'] for x in g['rows'] if x['seed']==seed)) for seed in g['common_seeds'])
 assert abs(float(common)-g['common_mass'])<1e-14
 for actor in g['source_types']:
  rr=[x for x in g['rows'] if x['actor']==actor];total=sum(rational(x['mass']) for x in rr);assert total==2*common
  accum=defaultdict(F);counts=defaultdict(int);byowner={0:defaultdict(F),1:defaultdict(F)}
  for x in rr:
   mass=rational(x['mass'])/total;pre=x['preparation']['preparations'];vv=[success(y) for y in pre];best=max(vv,default=F(0));avg=sum(vv)/len(vv) if vv else F(0);direct=success(x['direct']);assert abs(float(best)-x['preparation']['success'])<1e-14
   values={'best':best,'average':avg,'direct':direct,'has_preparation':F(bool(pre)),'positive_best':F(best>0),'positive_direct':F(direct>0),'has_positive_option':F(any(v>0 for v in vv)),'mean_positive_option_fraction':F(sum(v>0 for v in vv),len(vv)) if vv else F(0),'preparation_count':F(len(pre))}
   for k,v in values.items():accum[k]+=mass*v;byowner[x['owner']][k]+=mass*2*v
   counts['rows']+=1;counts['no_preparation']+=not pre;counts['positive_rows']+=best>0;counts['preparations']+=len(pre);counts['terminal_preparations']+=sum(y['preparation_terminal']['status']!='ongoing' for y in pre)
   rows.append({'seed':x['seed'],'actor':actor,'owner':x['owner'],'mass':str(mass),'best':str(best),'average':str(avg),'direct':str(direct),'preparations':len(pre),'positive_options':sum(v>0 for v in vv),'terminal_options':sum(y['preparation_terminal']['status']!='ongoing' for y in pre),'source':x['cells'][0],'target':x['cells'][1]})
  accum['best_selection_premium']=accum['best']-accum['average'];accum['success_conditional_positive']=accum['best']/accum['positive_best'] if accum['positive_best'] else F(0)
  assert accum['positive_best']*accum['success_conditional_positive']==accum['best']
  stats[actor]={'weighted':{k:str(v) for k,v in accum.items()},'counts':dict(counts),'per_owner':{str(o):{k:str(v) for k,v in d.items()} for o,d in byowner.items()}}
 n,pawn=stats['N']['weighted'],stats['P']['weighted'];ratios={k:str(F(n[k])/F(pawn[k])) if F(pawn[k]) else None for k in ('best','average','direct','positive_best','success_conditional_positive','has_preparation','preparation_count')}
 assert F(ratios['positive_best'])*F(ratios['success_conditional_positive'])==F(ratios['best'])
 r['games'][game]={'common_mass':str(common),'actors':stats,'knight_pawn_ratios':ratios,'rows':rows};save();print(game,ratios,flush=True)
r['complete']=True;r['seconds']=time.perf_counter()-start;save()
