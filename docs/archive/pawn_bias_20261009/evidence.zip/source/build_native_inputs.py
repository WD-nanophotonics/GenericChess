"""Reproduce derived Native expectations exactly; no transition or new evidence."""
from pathlib import Path
import json,hashlib
p=Path(__file__).parent
old=json.loads(Path('.local_agent/preparation-transfer-20261008/cross-game.json').read_bytes());src=p/'target-integrated.json';new=json.loads(src.read_bytes());assert new['complete'];r={'complete':True,'declaration':'Adapter only, no new simulation. Frozen witness geometry/background plus exact integrated target; all expected preparation records are Core outputs.','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'games':{}}
for name,g in new['games'].items():
 m={(x['seed'],x['actor'],x['owner']):x for x in old['games'][name]['rows']};rows=[]
 for x in g['rows']:
  row=dict(m[x['seed'],x['actor'],x['owner']]);row['target_type']=x['target_type'];row['preparation']={'success':x['promoting'],'preparations':x['preparations']};rows.append(row)
 r['games'][name]={'rows':rows}
encoded=(json.dumps(r,indent=2)+'\n').encode();assert encoded==(p/'target-native-input.json').read_bytes();print('target adapter reproduced exact',hashlib.sha256(encoded).hexdigest())
src=p/'representatives.json';d=json.loads(src.read_bytes());assert d['complete'];r={'complete':True,'declaration':'Adapter only; no extra simulation. Every fresh Core root, expected ordinary/promoting branches pinned. Native independently reconstructs old field-compatible witness with correct actor base.','input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'games':{}}
for name,g in d['games'].items():
 rows=[]
 for x in g['rows']:
  witness=g['seed_map'][str(x['seed'])];rows.append(dict(x,cells=witness['cells'],background_types=witness['background_types'],source_base=x['actor'],preparation={'success':x['promoting'],'preparations':x['preparations']}))
 r['games'][name]={'rows':rows}
encoded=(json.dumps(r,indent=2)+'\n').encode();assert encoded==(p/'representatives-native-input.json').read_bytes();print('fresh adapter reproduced exact',hashlib.sha256(encoded).hexdigest())
