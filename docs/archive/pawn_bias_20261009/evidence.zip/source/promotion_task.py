"""Finite preparation task shared by this declared research pilot only.

This is not a generic material evaluator or a history-independent state quotient.
Scope: one ordinary on-board tracked actor/target; no auxiliary target relocation.
"""
from generic_chess.core.actions import action_to_dict
from generic_chess.core.transition import legal_successors,apply_action
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from scripts.research_record import record_value

def preparation_task(state,compiled,source,target,checkpoint):
    engine=semantic_engine_for(compiled);width=state.position.board_shape.width
    idx=lambda s:s.file+width*s.rank
    original=state.position.board[source];victim=state.position.board[target]
    assert original is not None and victim is not None and original.owner!=victim.owner
    assert state.position.side_to_move==original.owner
    row={'success':0,'preparations':[],'initial_terminal':record_value(state.terminal_status),'witness':None}
    if state.terminal_status.is_terminal:return row
    checkpoint(0)
    successors=legal_successors(state,compiled);checkpoint(len(successors))
    for prepare,prepared in successors:
        if not hasattr(prepare,'from_square') or idx(prepare.from_square)!=source:continue
        moved=idx(prepare.to_square)
        if state.position.board[moved] is not None:continue
        tracked_actor=prepared.position.board[moved]
        if tracked_actor is None or tracked_actor.owner!=original.owner or tracked_actor.base_type_id!=original.base_type_id:continue
        expected=list(state.position.board);expected[source]=None;expected[moved]=tracked_actor
        if tuple(expected)!=prepared.position.board or prepared.position.hands!=state.position.hands:continue
        assert prepared.position.board[target]==victim
        item={'action':action_to_dict(prepare),'actor_after':record_value(tracked_actor),'transformed':tracked_actor!=original,'physical_replies':0,'terminal_replies':[],'source_lost_replies':0,'success':0,'preparation_terminal':record_value(prepared.terminal_status)}
        row['preparations'].append(item)
        if prepared.terminal_status.is_terminal:continue
        checkpoint(0);replies=legal_successors(prepared,compiled);checkpoint(len(replies));outcomes={}
        for reply,child in replies:
            tracked=idx(reply.to_square) if hasattr(reply,'from_square') and idx(reply.from_square)==target else target
            actual=child.position.board[tracked]
            assert actual is not None and actual.owner==victim.owner and actual.base_type_id==victim.base_type_id,('unsupported target relocation/identity',reply)
            alive=child.position.board[moved]==tracked_actor
            candidate=next(engine.iter_legal_action_bindings(child.position,source=moved,target=tracked),None) if alive and not child.terminal_status.is_terminal else None
            available=candidate is not None;observable=(available,alive,child.terminal_status)
            if child.position in outcomes:assert outcomes[child.position]==observable
            else:
                outcomes[child.position]=observable
                if not alive:item['source_lost_replies']+=1
                if child.terminal_status.is_terminal:item['terminal_replies'].append(record_value(child.terminal_status))
            if available and row['witness'] is None:
                capture=_semantic_public_action(engine,candidate[0]);final=apply_action(child,capture,compiled);checkpoint(1)
                assert final.position.board[tracked].owner==original.owner
                row['witness']={'prepare':action_to_dict(prepare),'reply':action_to_dict(reply),'capture':action_to_dict(capture),'tracked_target':tracked,'history_lengths':[len(s.history) for s in (state,prepared,child,final)],'terminal':record_value(final.terminal_status)}
        item['physical_replies']=len(outcomes);item['success']=sum(x[0] for x in outcomes.values())/len(outcomes) if outcomes else 0
        row['success']=max(row['success'],item['success'])
    return row

def direct_task(state,compiled,source,target,checkpoint):
    engine=semantic_engine_for(compiled);width=state.position.board_shape.width;idx=lambda s:s.file+width*s.rank
    victim=state.position.board[target];original=state.position.board[source];outcomes={};terminal=[]
    if state.terminal_status.is_terminal:return {'success':0,'physical_replies':0,'terminal_replies':[]}
    checkpoint(0);pairs=legal_successors(state,compiled);checkpoint(len(pairs))
    for reply,child in pairs:
        tracked=idx(reply.to_square) if hasattr(reply,'from_square') and idx(reply.from_square)==target else target
        actual=child.position.board[tracked];assert actual is not None and actual.owner==victim.owner and actual.base_type_id==victim.base_type_id
        alive=child.position.board[source]==original
        available=alive and not child.terminal_status.is_terminal and any(engine.iter_legal_action_bindings(child.position,source=source,target=tracked))
        observable=(available,alive,child.terminal_status)
        if child.position in outcomes:assert outcomes[child.position]==observable
        else:
            outcomes[child.position]=observable
            if child.terminal_status.is_terminal:terminal.append(record_value(child.terminal_status))
    return {'success':sum(x[0] for x in outcomes.values())/len(outcomes) if outcomes else 0,'physical_replies':len(outcomes),'terminal_replies':terminal}
