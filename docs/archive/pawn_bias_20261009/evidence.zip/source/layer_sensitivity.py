"""Same-cohort promotion-aware task, exact pawn-layer law sensitivity."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import json,hashlib
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
p=Path(__file__).parent;root=Path.cwd();src=p/'target-integrated.json';d=json.loads(src.read_bytes());assert d['complete'];raw=json.loads(Path('.local_agent/preparation-transfer-20261008/cross-game.json').read_bytes());out=p/'layer-sensitivity.json';assert not out.exists()
def f(x):
 y=F(x).limit_denominator(100000);assert abs(float(y)-x)<1e-14;return y
def best(row):return max((F(round(x['success']*x['physical_replies']),x['physical_replies']) if x['physical_replies'] else F(0) for x in row['preparations']),default=F(0))
r={'complete':True,'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'All-target integrated original common cohort, same owner/context/target weights for P and N, all zero roots retained. Near means a geometrically possible one-step quiet P move has promotion_allowed by actual rules, ignoring blockers/check; N uses that SAME pawn-defined layer, not its own jump reach. Inside-zone Shogi P included. Mixture freezes within-group weights; t range is diagnostic, not natural-game distribution or parameter fitting. No transition or new sample. R is ratio of merged raw means, not average of ratios.','games':{}}
for name,g in d['games'].items():
 base=build_western_chess_ruleset() if name=='chess' else build_standard_shogi_ruleset();n=base.board_size;old={x['seed']:x for x in raw['games'][name]['rows']};mass=sum({x['seed']:f(x['mass']) for x in g['rows']}.values());groups={a:defaultdict(lambda:{'mass':F(0),'numerator':F(0),'positive_mass':F(0),'rows':0}) for a in ('P','N')};ranks={a:defaultdict(lambda:{'mass':F(0),'numerator':F(0),'rows':0}) for a in ('P','N')}
 for row in g['rows']:
  source=old[row['seed']]['cells'][0];y=source//n;owner=row['owner'];dist=n-1-y if owner==0 else y;allowed=base.promotion_allowed['P'][owner];near=any(a.file==b.file and a.rank==y and a.file==source%n and b.rank-a.rank==(1 if owner==0 else -1) for a,b in allowed);group='near' if near else 'far';w=f(row['mass'])*F(row['target_weight'])/(2*mass);v=best(row);z=groups[row['actor']][group];z['mass']+=w;z['numerator']+=w*v;z['positive_mass']+=w*(v>0);z['rows']+=1;z=ranks[row['actor']][dist];z['mass']+=w;z['numerator']+=w*v;z['rows']+=1
 for group in ('near','far'):assert groups['P'][group]['mass']==groups['N'][group]['mass']
 t=groups['P']['near']['mass'];assert 0<t<1;means={a:{k:v['numerator']/v['mass'] for k,v in gg.items()} for a,gg in groups.items()}
 def ratio(t):
  nn=t*means['N']['near']+(1-t)*means['N']['far'];pp=t*means['P']['near']+(1-t)*means['P']['far'];return nn/pp if pp else None
 original=sum(x['numerator'] for x in groups['N'].values())/sum(x['numerator'] for x in groups['P'].values());assert ratio(t)==original
 derivative=means['N']['near']*means['P']['far']-means['N']['far']*means['P']['near']
 pack=lambda gg:{str(k):{**{kk:(str(vv) if isinstance(vv,F) else vv) for kk,vv in v.items()},'mean':str(v['numerator']/v['mass']) if v['mass'] else None} for k,v in gg.items()}
 r['games'][name]={'width':n,'original_t':str(t),'groups':{a:pack(gg) for a,gg in groups.items()},'far_edge_rank_layers':{a:pack(gg) for a,gg in ranks.items()},'R_original':str(original),'derivative_numerator':str(derivative),'R_diagnostic_points':{str(tt):str(ratio(tt)) if ratio(tt) is not None else None for tt in (F(0),F(1,4),F(1,2),F(3,4),F(1))}}
 print(name,'t',float(t),'R_original',float(original),'R_endpoints',float(ratio(F(0))) if ratio(F(0)) is not None else None,float(ratio(F(1))) if ratio(F(1)) is not None else None,'derivative sign',int(derivative>0)-int(derivative<0),flush=True)
out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
