"""Distinguish layer-mass changes from within-layer representative variability."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
p=Path(__file__).parent;src=p/'representatives.json';fresh=json.loads(src.read_bytes());original=json.loads((p/'target-integrated.json').read_bytes());analysis=json.loads((p/'representatives-analysis.json').read_bytes());raw=json.loads(Path('.local_agent/preparation-transfer-20261008/cross-game.json').read_bytes());assert fresh['complete'];out=p/'layer-representatives.json';assert not out.exists()
def f(x):return F(x).limit_denominator(100000)
def best(x):return max((F(round(y['success']*y['physical_replies']),y['physical_replies']) if y['physical_replies'] else F(0) for y in x['preparations']),default=F(0))
r={'complete':True,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'scope':'Same all-four common offset intersection, promotion-aware exact target law. Report actual near mass and raw group means. Standardize only binary near mass to original-on-intersection t; within-group source/background/owner weights stay per-representative. Residual variation is descriptive, not precision/causation/natural law. Empty strata remain unsupported, never imputed.','games':{}}
for name,g in fresh['games'].items():
 base=build_western_chess_ruleset() if name=='chess' else build_standard_shogi_ruleset();n=base.board_size;sm={int(k):v for k,v in g['seed_map'].items()};oi={tuple(v['displacement']):v['stratum'] for v in sm.values()};oldcells={x['seed']:x['cells'] for x in raw['games'][name]['rows']};oldoffset={s:oi[(c[1]%n-c[0]%n,c[1]//n-c[0]//n)] for s,c in oldcells.items()};common=set(analysis['games'][name]['all_four_common_strata']);rows={'original':[x for x in original['games'][name]['rows'] if oldoffset[x['seed']] in common]};cells={'original':oldcells}
 for rep in range(3):
  label='fresh'+str(rep);rows[label]=[x for x in g['rows'] if sm[x['seed']]['rep']==rep and sm[x['seed']]['stratum'] in common];cells[label]={s:v['cells'] for s,v in sm.items()}
 output={}
 for label,rr in rows.items():
  mass=sum({x['seed']:f(x['mass']) for x in rr}.values());gg={a:{k:{'mass':F(0),'numerator':F(0),'positive_mass':F(0)} for k in ('near','far')} for a in ('P','N')}
  for x in rr:
   source=cells[label][x['seed']][0];near=any(a.file==b.file and a.file==source%n and a.rank==source//n and b.rank-a.rank==(1 if x['owner']==0 else -1) for a,b in base.promotion_allowed['P'][x['owner']]);v=gg[x['actor']]['near' if near else 'far'];w=f(x['mass'])*F(x['target_weight'])/(2*mass);v['mass']+=w;v['numerator']+=w*best(x);v['positive_mass']+=w*(best(x)>0)
  assert all(gg['N'][k]['mass']==gg['P'][k]['mass'] for k in ('near','far'));output[label]={'t':gg['P']['near']['mass'],'groups':{a:{k:{**v,'mean':v['numerator']/v['mass'] if v['mass'] else None} for k,v in aa.items()} for a,aa in gg.items()}}
 t0=output['original']['t']
 def ratio(item,t):
  if any(item['groups'][a][k]['mean'] is None for a in ('P','N') for k in ('near','far')):return None
  pp=t*item['groups']['P']['near']['mean']+(1-t)*item['groups']['P']['far']['mean'];nn=t*item['groups']['N']['near']['mean']+(1-t)*item['groups']['N']['far']['mean'];return nn/pp if pp else None
 for label,item in output.items():item['R_actual']=ratio(item,item['t']);item['R_fixed_original_near_mass']=ratio(item,t0)
 def serial(v):
  if isinstance(v,F):return str(v)
  if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
  return v
 r['games'][name]={'offsets':len(common),'original_t':str(t0),'representatives':serial(output)};print(name,[(label,float(x['t']),float(x['R_actual']) if x['R_actual'] else None,float(x['R_fixed_original_near_mass']) if x['R_fixed_original_near_mass'] else None) for label,x in output.items()],flush=True)
out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
