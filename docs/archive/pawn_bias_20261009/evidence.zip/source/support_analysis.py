"""Exact support/selection decomposition with tied-optimum survival intervals."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
p=Path(__file__).parent
src=p/'target-integrated.json';data=json.loads(src.read_bytes());assert data['complete'];out=p/'support-analysis.json';assert not out.exists()
def f(x):
 y=F(x).limit_denominator(100000);assert abs(float(y)-x)<1e-14;return y
def value(x):
 n=x['physical_replies'];k=round(x['success']*n);assert not n or abs(k/n-x['success'])<1e-14
 return F(k,n) if n else F(0)
def stats(rows,scope,mass):
 rr=[]
 for row in rows:
  pp=[x for x in row['preparations'] if scope=='promoting' or not x['transformed']];vv=[value(x) for x in pp];best=max(vv,default=F(0));tied=[x for x,v in zip(pp,vv) if v==best]
  survival=[F(x['physical_replies']-x['source_lost_replies'],x['physical_replies']) if x['physical_replies'] else F(0) for x in tied]
  w=f(row['mass'])*F(row['target_weight'])/(2*mass)
  rr.append({'w':w,'best':best,'avg':sum(vv)/len(vv) if vv else F(0),'positive':F(best>0),'available':F(bool(pp)),'count':F(len(pp)),'survival_low':min(survival,default=F(0)),'survival_high':max(survival,default=F(0)),'terminal_preparation_mass':F(sum(x['preparation_terminal']['status']!='ongoing' for x in pp),len(pp)) if pp else F(0)})
 total=sum(x['w'] for x in rr);assert total>0
 s={k:sum(x['w']*x[k] for x in rr)/total for k in rr[0] if k!='w'};s['conditional_positive']=s['best']/s['positive'] if s['positive'] else None;s['selection_premium']=s['best']-s['avg'];assert not s['positive'] or s['positive']*s['conditional_positive']==s['best']
 return {k:str(v) if v is not None else None for k,v in s.items()}
r={'complete':True,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'scope':'Exact conditional diagnostics, not price or utility. Integrate fixed all-target common cohort. survival_low/high range over tied best preparations, including zero-denominator terminal preparations with survival0; no arbitrary tie policy. Survival is not independent of capture success. Conditional target tables renormalize that target mass; aggregate uses original inventory weights.','games':{}}
for name,g in data['games'].items():
 mass=sum({x['seed']:f(x['mass']) for x in g['rows']}.values());a={}
 for actor in ('P','N'):
  rows=[x for x in g['rows'] if x['actor']==actor];a[actor]={scope:stats(rows,scope,mass) for scope in ('ordinary','promoting')};a[actor]['per_target']={tid:{scope:stats([x for x in rows if x['target_type']==tid],scope,mass) for scope in ('ordinary','promoting')} for tid in g['inventory']}
 ratios={}
 for scope in ('ordinary','promoting'):
  ratios[scope]={k:str(F(a['N'][scope][k])/F(a['P'][scope][k])) if a['P'][scope][k] is not None and F(a['P'][scope][k]) else None for k in ('best','avg','positive','conditional_positive')}
  assert F(ratios[scope]['positive'])*F(ratios[scope]['conditional_positive'])==F(ratios[scope]['best'])
 r['games'][name]={'actors':a,'N_P':ratios};print(name,{s:{k:float(F(v)) if v else None for k,v in x.items()} for s,x in ratios.items()},flush=True)
out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
