"""Independent Native task census of frozen contexts, actual postprepare actor."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,make_checked,snapshot,terminal_status,unpack_action,public_action
from generic_chess.core.actions import action_to_dict
p=Path(__file__).parent;src=p/'promotion-aware.json';data=json.loads(src.read_bytes());assert data['complete'];out=p/'native-promotion.json';assert not out.exists();start=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration':'Independent Native full exact all frozen contexts and ordinary/promotion quiet preparations; Native legal replies/actual tracked actor/target/native capture availability/terminal/history. Match each Core preparation identity, physical reply count, success numerator and terminal/source loss. Same root provenance limits. Native<=800000transitions/360sec pergame; capture legal-list generation counted separately. No default/price/strength claim.','games':{}}
def save():out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
save()
for name,base in [('chess',build_western_chess_ruleset()),('shogi',build_standard_shogi_ruleset())]:
 c=compile_ruleset_for_execution(base);n=compile_native_semantic_rules(c);ids={t:i for i,t in enumerate(n.type_ids)};engine=semantic_engine_for(c);template=GameSession(c).state.position;width=base.board_size;anchor=next(x.type_id for x in base.piece_types if x.is_anchor);t=time.perf_counter();g={'rows':[],'transitions':0,'legal_list_queries':0,'capture_list_queries':0,'preparations':0,'reply_classes':0};r['games'][name]=g;field_cache={}
 def fields(a):
  if a not in field_cache:field_cache[a]=unpack_action(a)
  return field_cache[a]
 def actions(pos):g['legal_list_queries']+=1;return guarded_actions(n,pos)
 def transition(pos,a):g['transitions']+=1;return make_checked(n,pos,a)
 def physical(v):return json.dumps({k:v[k] for k in ('board','hands','side','aux_state') if k in v},sort_keys=True)
 for old in data['games'][name]['rows']:
  assert time.perf_counter()-t<360 and g['transitions']<800000
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes()).get('user_paused')
  source,target=old['cells'][:2];owner=old['owner'];actor=old['actor'];board=[None]*(width*width);board[0]=Piece(0,anchor,anchor);board[-1]=Piece(1,anchor,anchor);board[source]=Piece(owner,old['source_base'],actor,promoted=old['source_base']!=actor);board[target]=Piece(1-owner,old['target_type'],old['target_type'])
  for sq,tid,who in zip(old['cells'][2:],old['background_types'],(0,0,1,1)):board[sq]=Piece(who,tid,tid)
  pos=replace(template,board=tuple(board),side_to_move=owner);key=repetition_identity_key(pos,c);counts=((key,1),);state=GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),));game=GameSession(c);game._state=state;game._search_history_witnesses=(pos,);native=pack_semantic_search_position(c,n,game);rootview=snapshot(n,native);assert rootview['history_exact'] and rootview['history_events_exact']
  expected={json.dumps(x['action'],sort_keys=True):x for x in old['preparation']['preparations']};actual={};physical_preps=set()
  if terminal_status(n,native)['status']=='ongoing':
   for a in actions(native):
    f=fields(a)
    if f['kind']!=2 or f['from']!=source or rootview['board'][f['to']] is not None:continue
    prepared=transition(native,a);v=snapshot(n,prepared);tracked=v['board'][f['to']]
    if tracked is None or tracked[2]!=owner or tracked[0]!=ids[old['source_base']]:continue
    want=list(rootview['board']);want[source]=None;want[f['to']]=tracked
    if v['board']!=want or v['hands']!=rootview['hands']:continue
    ad=json.dumps(action_to_dict(public_action(n,a)),sort_keys=True);assert ad in expected;item=expected[ad];assert terminal_status(n,prepared)==item['preparation_terminal'];outcomes={};physical_preps.add(physical(v))
    if terminal_status(n,prepared)['status']=='ongoing':
     for reply in actions(prepared):
      rf=fields(reply);child=transition(prepared,reply);cv=snapshot(n,child);target_now=rf['to'] if rf['kind']==2 and rf['from']==target else target;victim=cv['board'][target_now];assert victim is not None and victim[2]==1-owner and victim[0]==ids[old['target_type']]
      alive=cv['board'][f['to']]==tracked;terminal=terminal_status(n,child);available=False
      if alive and terminal['status']=='ongoing':
       g['capture_list_queries']+=1
       available=any(fields(k)['kind']==2 and fields(k)['from']==f['to'] and fields(k)['to']==target_now for k in actions(child))
      observable=(available,alive,json.dumps(terminal,sort_keys=True));pk=physical(cv)
      if pk in outcomes:assert outcomes[pk]==observable
      outcomes[pk]=observable
    num=sum(x[0] for x in outcomes.values());den=len(outcomes);lost=sum(not x[1] for x in outcomes.values());terms=sorted(x[2] for x in outcomes.values() if json.loads(x[2])['status']!='ongoing')
    assert den==item['physical_replies'] and (num/den if den else 0)==item['success'] and lost==item['source_lost_replies']
    assert terms==sorted(json.dumps(x,sort_keys=True) for x in item['terminal_replies'])
    actual[ad]={'numerator':num,'denominator':den,'transformed':item['transformed']};g['reply_classes']+=den
  assert set(actual)==set(expected);g['preparations']+=len(actual);best=max((Fraction(x['numerator'],x['denominator']) if x['denominator'] else Fraction(0) for x in actual.values()),default=Fraction(0));assert float(best)==old['preparation']['success']
  g['rows'].append({'seed':old['seed'],'actor':actor,'owner':owner,'best':str(best),'public_preparations':len(actual),'physical_preparations':len(physical_preps),'changed_preparations':sum(x['transformed'] for x in actual.values())})
  if len(g['rows'])%100==0:save();print(name,len(g['rows']),g['transitions'],round(time.perf_counter()-t,2),flush=True)
 g['seconds']=time.perf_counter()-t;g['complete']=True;save()
r['complete']=True;r['seconds']=time.perf_counter()-start;save()
