"""Fixed representative layouts, exact initial-inventory target integration."""
import sys,json,time,hashlib,random
from pathlib import Path
from dataclasses import replace
from collections import Counter
from fractions import Fraction as F
root=Path.cwd();p=Path(__file__).parent;sys.path[:0]=[str(root),str(p)]
from promotion_task import preparation_task
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
src=root/'.local_agent/preparation-transfer-20261008/cross-game.json';old=json.loads(src.read_bytes());out=p/'representatives.json';assert not out.exists();start=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256((p/'promotion_task.py').read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration_sha256':hashlib.sha256((p/'representatives-declaration.json').read_bytes()).hexdigest(),'declaration':'New task-law factor, no new layouts/horizon/fit. For each frozen seed/background/source-target cells, replace target type over exact original initial owner0 non-anchor inventory law. Retain seed only if BOTH P/N actors and BOTH owners have safe anchors for EVERY target type; report excluded common mass. On this exact same accepted cohort compare original sampled target vs inventory-integrated target, and nontransforming vs promotion-aware preparation support. All contexts explicit no reachability claim, terminal0 retains task semantics, no WDL/material table/default. Serial Core <=600000transitions/360sec Chess and1500000/720sec Shogi, pergame interruptible seed checkpoints. Costs chosen for target-factor isolation; never outcome-extend. Do not run concurrently with Native census.','games':{}}
def save():out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
save()
for name,base in [('chess',build_western_chess_ruleset()),('shogi',build_standard_shogi_ruleset())]:
 c=compile_ruleset_for_execution(base);engine=semantic_engine_for(c);template=GameSession(c).state.position;n=base.board_size;anchor=next(x.type_id for x in base.piece_types if x.is_anchor);inventory=Counter(x.current_type_id for row in base.initial_position for x in row if x and x.owner==0 and x.current_type_id!=anchor);g={'inventory':dict(inventory),'accepted':[],'rejected':[],'rows':[],'transitions':0};r['games'][name]=g;t=time.perf_counter();prior=old['games'][name];oldmap={};newseeds=[];strata=[];m=n-2;inner=[y*n+x for y in range(1,n-1) for x in range(1,n-1)]
 for dx in range(1-m,m):
  for dy in range(1-m,m):
   if dx==dy==0:continue
   eligible=[sq for sq in inner if 1<=sq%n+dx<n-1 and 1<=sq//n+dy<n-1];strata.append((dx,dy,eligible,F(len(eligible),m*m*(m*m-1))))
 g['strata']=len(strata);g['declared_mass']=str(sum(x[3] for x in strata));g['seed_map']={}
 population=[tid for tid,count in inventory.items() for _ in range(count)]
 for rep in range(3):
  for index,(dx,dy,eligible,mass) in enumerate(strata):
   seed=2400000+(100000 if name=='shogi' else 0)+rep*10000+index;rng=random.Random(seed);source=rng.choice(eligible);target=source+dx+n*dy;cells=[source,target]+rng.sample([sq for sq in inner if sq not in (source,target)],4);background=[rng.choice(population) for _ in range(4)];g['seed_map'][seed]={'rep':rep,'stratum':index,'displacement':[dx,dy],'mass':str(mass),'cells':cells,'background_types':background};newseeds.append(seed)
   for actor in ('P','N'):
    for owner in (0,1):oldmap[seed,actor,owner]={'seed':seed,'mass':float(mass),'actor':actor,'owner':owner,'cells':cells,'background_types':background}

 def check(delta):
  g['transitions']+=delta;assert g['transitions']<2000000 and time.perf_counter()-t<900
  flags=json.loads((root/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
 def state_for(row,target_type):
  source,target=row['cells'][:2];owner=row['owner'];actor=row['actor'];board=[None]*(n*n);board[0]=Piece(0,anchor,anchor);board[-1]=Piece(1,anchor,anchor);board[source]=Piece(owner,actor,actor);board[target]=Piece(1-owner,target_type,target_type)
  for sq,tid,who in zip(row['cells'][2:],row['background_types'],(0,0,1,1)):board[sq]=Piece(who,tid,tid)
  pos=replace(template,board=tuple(board),side_to_move=owner)
  if engine.in_check(pos,0) or engine.in_check(pos,1):return None
  key=repetition_identity_key(pos,c);counts=((key,1),);return GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),))
 for seed in newseeds:
  check(0);contexts=[];valid=True
  for actor in ('P','N'):
   for owner in (0,1):
    row=oldmap[seed,actor,owner]
    for tid in inventory:
     state=state_for(row,tid)
     if state is None:valid=False
     contexts.append((row,tid,state))
  if not valid:g['rejected'].append(seed);continue
  g['accepted'].append(seed)
  for row,tid,state in contexts:
   result=preparation_task(state,c,*row['cells'][:2],check);ordinary=max((x['success'] for x in result['preparations'] if not x['transformed']),default=0)
   g['rows'].append({'seed':seed,'mass':row['mass'],'actor':row['actor'],'owner':row['owner'],'target_type':tid,'target_weight':str(F(inventory[tid],sum(inventory.values()))),'ordinary':ordinary,'promoting':result['success'],'preparations':result['preparations']})
  save();print(name,seed,'seeds',len(g['accepted']),'rows',len(g['rows']),'transitions',g['transitions'],'sec',round(time.perf_counter()-t,2),flush=True)
 g['complete']=True;g['seconds']=time.perf_counter()-t;save()
r['complete']=True;r['seconds']=time.perf_counter()-start;save()
