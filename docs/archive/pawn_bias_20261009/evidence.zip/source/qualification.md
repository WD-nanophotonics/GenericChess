# Pawn-task scope and context-law qualification

All outputs are Agent-generated development diagnostics. No product code,
prices, defaults, human fit, Elo goal or Xiangqi holdout changed. UTC segment
2026-10-08T14:53:07.384020+00:00; local date2026-10-09. Old results remain immutable.

The original preparation task intentionally excluded transformations. That
restriction is valid for that task but must not be read as all legal quiet
capability. The changed task permits same-base/owner quiet promotion, tracks
the actual post-preparation actor and the actual replied target, and retains
all ordinary branches/direct baselines. Early winning preparations still have
capture-task0; this is not zero game value. Source/target provenance and full
Core/Native root history are retained. No reachability claim follows from
initial anchor safety, especially on synthetic backgrounds/auxiliary state.

Promotion-aware and exact target-integrated censuses independently match every
Core/Native preparation identity, reply denominator, success numerator, actor
loss and terminal. Native list-query counts and actual make_checked counts
have different accounting from Core legal_successors/witness application;
separate counters are retained, not used as an equal-work speed claim.

Exact rational decompositions distinguish max choice, uniform canonical
physical-preparation average, positive support mass and conditional success.
Canonical runs have no duplicate physical preparations. Physical reply classes
retain an actual history representative and assert equal observables on aliases;
this is not permission to merge search/action/history identities.

Target-law comparisons are matched within one all-target/P-N/both-owner safe
cohort. Old all-piece-safe seed qualification further restricts the original
cohort; original versus fresh cohort numbers alone do not isolate target law.
Fresh3replicate representatives predeclare every original displacement stratum,
source/background drawing and exact initial-inventory target law. All accepted
and rejected strata remain. Same offset intersection across fresh replicates
isolates representative/background dependence conditional on that intersection;
all-four intersection also includes the original. Neither is a whole-board
census or independent material validation. Three replicates give descriptive
spread, not a confidence interval. Do not select a preferred ratio/law.

representatives.py inherits prose about sampled-target pairing and old pergame
caps from target_integrated.py; representatives-declaration.json owns the new
actual3replicate scope/caps. Its code implements that declaration and does not
use sampled targets. Inherited prose is not evidence of an unexecuted contrast.

eligibility.py failed to serialize an enum; eligibility.json is incomplete and
not evidence. eligibility_v2 uses record_value and completed. Preliminary
paired/rank JSON came from inline analyses; paired_exact.py independently
reconstructs their exact branch/rank claims with pinned inputs. Adapter JSON
contains only derived Core expectations plus frozen witness geometry; Native
execution independently reconstructs transitions rather than reusing outcomes.

Two initial Native promotion launches and one representative Native launch
were auto-review rejected because the preceding census was considered active.
No rejected launch executed. Read-only completion and matching-process checks
established exit before the serial census was approved; no concurrent heavy
jobs, credential extraction or access bypass occurred. Current state resolved.
Slack raw messages/receipts/identities stay ignored and are excluded from this
archive. Advisor statements are not independent experiment execution.

Full JSON persistence at each accepted seed incurs engineering/I/O cost; final
file sizes and transition/query/time counters are recorded, cumulative write
bytes are not instrumented. Future collection should batch durable checkpoints
if this becomes a bottleneck; no protocol expansion is required.
