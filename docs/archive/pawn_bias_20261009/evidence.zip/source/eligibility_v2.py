"""Audit exact frozen P/N preparation boundary; no new sample or payoff."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from collections import Counter
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.core.pieces import Piece
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.transition import legal_successors
from generic_chess.core.actions import action_to_dict
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import record_value
p=Path(__file__).parent;src=root/'.local_agent/preparation-transfer-20261008/cross-game.json';data=json.loads(src.read_bytes());out=p/'eligibility-v2.json';assert not out.exists();start=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration':'Audit all frozenP/N roots, reconstruct supported fullCore original states/history, exact legal actor actions. Classify normal quiet versus quiet transformation/promotion, blocked/no actions, existing terminal. Original preparation support must recover exactly. Record promotion-only roots and ordinary options separately, no payoff or price inference. <=100000Core successors/120sec per game, no extension.','games':{}}
def save():out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
save()
for name,base in [('chess',build_western_chess_ruleset()),('shogi',build_standard_shogi_ruleset())]:
 c=compile_ruleset_for_execution(base);engine=semantic_engine_for(c);template=GameSession(c).state.position;n=base.board_size;anchor=next(x.type_id for x in base.piece_types if x.is_anchor);g={'rows':[],'transitions':0};r['games'][name]=g;t=time.perf_counter()
 for old in data['games'][name]['rows']:
  if old['actor'] not in ('P','N'):continue
  assert time.perf_counter()-t<120 and g['transitions']<100000
  flags=json.loads((root/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused')
  source,target=old['cells'][:2];actor=old['actor'];owner=old['owner'];board=[None]*(n*n);board[0]=Piece(0,anchor,anchor);board[-1]=Piece(1,anchor,anchor);original=Piece(owner,old['source_base'],actor,promoted=old['source_base']!=actor);board[source]=original;board[target]=Piece(1-owner,old['target_type'],old['target_type'])
  for sq,tid,who in zip(old['cells'][2:],old['background_types'],(0,0,1,1)):board[sq]=Piece(who,tid,tid)
  pos=replace(template,board=tuple(board),side_to_move=owner);key=repetition_identity_key(pos,c);counts=((key,1),);state=GameState(pos,0,counts,engine.terminal_result(pos,0,counts),(HistoryRecord(key,-1,'',False),));assert not engine.in_check(pos,0) and not engine.in_check(pos,1)
  row={k:old[k] for k in ('seed','mass','actor','owner','cells')};row['counts']=Counter();row['ordinary']=[];row['changed']=[]
  for a,ch in legal_successors(state,c):
   g['transitions']+=1
   if not hasattr(a,'from_square') or a.from_square.file+n*a.from_square.rank!=source:continue
   to=a.to_square.file+n*a.to_square.rank
   if board[to] is not None:row['counts']['capture_or_occupied']+=1;continue
   expected=list(board);expected[source]=None;expected[to]=ch.position.board[to]
   if tuple(expected)!=ch.position.board or ch.position.hands!=state.position.hands:row['counts']['other_effect']+=1;continue
   kind='ordinary' if ch.position.board[to]==original else 'changed';row['counts'][kind]+=1;row[kind].append({'action':action_to_dict(a),'piece':{'base':ch.position.board[to].base_type_id,'current':ch.position.board[to].current_type_id,'promoted':ch.position.board[to].promoted},'terminal':record_value(ch.terminal_status)})
  assert row['counts']['ordinary']==len(old['preparation']['preparations']);g['rows'].append(row)
 g['seconds']=time.perf_counter()-t;g['summary']={a:{'roots':sum(x['actor']==a for x in g['rows']),'ordinary':sum(x['counts']['ordinary'] for x in g['rows'] if x['actor']==a),'changed':sum(x['counts']['changed'] for x in g['rows'] if x['actor']==a),'promotion_only_roots':sum(x['counts']['changed']>0 and x['counts']['ordinary']==0 for x in g['rows'] if x['actor']==a)} for a in ('P','N')};save();print(name,g['summary'],flush=True)
r['complete']=True;r['seconds']=time.perf_counter()-start;save()
