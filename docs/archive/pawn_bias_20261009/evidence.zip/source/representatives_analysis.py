"""Fixed three-representative task-law variability, no fitted distribution."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
p=Path(__file__).parent;src=p/'representatives.json';d=json.loads(src.read_bytes());assert d['complete'];out=p/'representatives-analysis.json';assert not out.exists()
def f(x):
 y=F(x).limit_denominator(100000);assert abs(float(y)-x)<1e-14;return y
def best(row,scope):
 pp=[x for x in row['preparations'] if scope=='promoting' or not x['transformed']]
 return max((F(round(x['success']*x['physical_replies']),x['physical_replies']) if x['physical_replies'] else F(0) for x in pp),default=F(0))
def vector(rows,mass):
 a={}
 for actor in ('P','N'):
  a[actor]={}
  for scope in ('ordinary','promoting'):
   vals=[(f(x['mass'])*F(x['target_weight'])/(2*mass),best(x,scope)) for x in rows if x['actor']==actor];assert sum(w for w,v in vals)==1
   mean=sum(w*v for w,v in vals);positive=sum(w for w,v in vals if v>0);a[actor][scope]={'mean':str(mean),'positive_mass':str(positive),'conditional_positive':str(mean/positive) if positive else None}
 return {'actors':a,'N_P':{scope:str(F(a['N'][scope]['mean'])/F(a['P'][scope]['mean'])) if F(a['P'][scope]['mean']) else None for scope in ('ordinary','promoting')}}
r={'complete':True,'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Development diagnostic under fixed3replicates/all-target safety/initial-inventory target law. Reps have different safe populations, so only common stratum intersection isolates layout/background representative change. Still not same physical cohort or material utility, no confidence/holdout claim; predeclared sampled stratum laws not human selected.','games':{}}
for name,g in d['games'].items():
 maps={int(k):v for k,v in g['seed_map'].items()};sets={rep:{maps[s]['stratum'] for s in g['accepted'] if maps[s]['rep']==rep} for rep in range(3)};common=set.intersection(*sets.values());a={'strata':g['strata'],'common_strata':sorted(common),'reps':{}}
 for rep in range(3):
  rows=[x for x in g['rows'] if maps[x['seed']]['rep']==rep];mass=sum({x['seed']:f(x['mass']) for x in rows}.values());cr=[x for x in rows if maps[x['seed']]['stratum'] in common];cm=sum({x['seed']:f(x['mass']) for x in cr}.values());a['reps'][rep]={'accepted_strata':len(sets[rep]),'accepted_mass':str(mass),'own_cohort':vector(rows,mass),'common_mass':str(cm),'common_offsets':vector(cr,cm) if cm else None}
 a['common_offsets_ratios']={scope:[a['reps'][rep]['common_offsets']['N_P'][scope] for rep in range(3)] if common else [] for scope in ('ordinary','promoting')};old=json.loads((p/'target-integrated.json').read_bytes())['games'][name];raw=json.loads(Path('.local_agent/preparation-transfer-20261008/cross-game.json').read_bytes())['games'][name];width=8 if name=='chess' else 9;original_map={x['seed']:x['cells'] for x in raw['rows']};offset_index={tuple(v['displacement']):v['stratum'] for v in maps.values()};old_offsets={seed:offset_index[(cells[1]%width-cells[0]%width,cells[1]//width-cells[0]//width)] for seed,cells in original_map.items()};allfour=common & {old_offsets[s] for s in old['accepted']};a['all_four_common_strata']=sorted(allfour);four={}
 for rep in range(3):
  rr=[x for x in g['rows'] if maps[x['seed']]['rep']==rep and maps[x['seed']]['stratum'] in allfour];mm=sum({x['seed']:f(x['mass']) for x in rr}.values());four['fresh'+str(rep)]={'mass':str(mm),'vector':vector(rr,mm) if mm else None}
 rr=[x for x in old['rows'] if old_offsets[x['seed']] in allfour];mm=sum({x['seed']:f(x['mass']) for x in rr}.values());four['original']={'mass':str(mm),'vector':vector(rr,mm) if mm else None};a['all_four_common_offsets']=four;r['games'][name]=a;print(name,'common',len(common),'per-rep',[(x['accepted_strata'],{s:float(F(v)) if v else None for s,v in x['own_cohort']['N_P'].items()}) for x in a['reps'].values()],'common_ratios',{s:[float(F(v)) if v else None for v in vv] for s,vv in a['common_offsets_ratios'].items()},flush=True)
out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
