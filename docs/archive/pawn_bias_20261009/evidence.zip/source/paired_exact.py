"""Recover original-branch identity and rank contributions from pinned inputs."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import json,hashlib
p=Path(__file__).parent;oldsrc=Path('.local_agent/preparation-transfer-20261008/cross-game.json');newsrc=p/'promotion-aware.json';old=json.loads(oldsrc.read_bytes());new=json.loads(newsrc.read_bytes());assert old['complete'] and new['complete'];out=p/'paired-exact.json';assert not out.exists()
def f(x):
 y=F(x).limit_denominator(100000);assert abs(float(y)-x)<1e-14;return y
def value(item):
 n=item['physical_replies'];k=round(item['success']*n);assert not n or abs(k/n-item['success'])<1e-14;return F(k,n) if n else F(0)
def best(row):return max((value(x) for x in row['preparation']['preparations']),default=F(0))
r={'complete':True,'input_sha256':{str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in (oldsrc,newsrc)},'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'All old direct and ordinary-preparation outputs exact; rank contributions are weighted contributions to unconditional actor mean, not conditional rank means. No WDL/material or reachability claim.','games':{}}
for name,g in new['games'].items():
 before={(x['seed'],x['actor'],x['owner']):x for x in old['games'][name]['rows']};mass=f(g['common_mass']);width=8 if name=='chess' else 9;means={};ranks={};unchanged=changed=improved=0
 for actor in g['source_types']:
  total_old=total_new=F(0);rank=defaultdict(lambda:{'mass':F(0),'old':F(0),'new':F(0),'changed_options':0,'improved_rows':0})
  for row in g['rows']:
   if row['actor']!=actor:continue
   b=before[row['seed'],actor,row['owner']];assert row['direct']==b['direct'];bm={json.dumps(x['action'],sort_keys=True):x for x in b['preparation']['preparations']};nm={json.dumps(x['action'],sort_keys=True):x for x in row['preparation']['preparations'] if not x['transformed']};assert bm.keys()==nm.keys()
   for key,x in bm.items():assert all(nm[key][k]==v for k,v in x.items());unchanged+=1
   added=sum(x['transformed'] for x in row['preparation']['preparations']);changed+=added;v0=best(b);v1=best(row);assert v1>=v0;improved+=v1>v0;w=f(row['mass'])/(2*mass);total_old+=w*v0;total_new+=w*v1
   if actor in ('P','N'):
    y=row['cells'][0]//width;dist=width-1-y if row['owner']==0 else y;rr=rank[dist];rr['mass']+=w;rr['old']+=w*v0;rr['new']+=w*v1;rr['changed_options']+=added;rr['improved_rows']+=v1>v0
  means[actor]={'old':str(total_old),'new':str(total_new)}
  if rank:
   assert sum(x['old'] for x in rank.values())==total_old and sum(x['new'] for x in rank.values())==total_new;ranks[actor]={k:{kk:str(vv) if isinstance(vv,F) else vv for kk,vv in x.items()} for k,x in rank.items()}
 r['games'][name]={'ordinary_branches_exact':unchanged,'changed_options':changed,'improved_rows':improved,'means':means,'N_P':{scope:str(F(means['N'][scope])/F(means['P'][scope])) for scope in ('old','new')},'rank_contributions':ranks};print(name,unchanged,changed,improved,{k:float(F(v)) for k,v in r['games'][name]['N_P'].items()},flush=True)
out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
