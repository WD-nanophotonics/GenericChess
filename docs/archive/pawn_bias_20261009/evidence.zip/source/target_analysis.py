"""Paired cohort/target-law/task-scope contrasts from fixed outputs."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
p=Path(__file__).parent;root=Path.cwd();src=p/'target-integrated.json';data=json.loads(src.read_bytes());assert data['complete'];prior=json.loads((p/'promotion-aware.json').read_bytes());out=p/'target-analysis.json';assert not out.exists()
r={'complete':False,'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'games':{}}
def f(x):
 y=F(x).limit_denominator(100000);assert abs(float(y)-x)<1e-14;return y
def exact(row,field):
 vv=[x for x in row['preparations'] if field=='promoting' or not x['transformed']]
 return max((F(round(x['success']*x['physical_replies']),x['physical_replies']) if x['physical_replies'] else F(0) for x in vv),default=F(0))
for name,g in data['games'].items():
 reps={x['seed']:f(x['mass']) for x in g['rows']};mass=sum(reps.values());common=f(prior['games'][name]['common_mass']);assert len(reps)==len(g['accepted']);vectors={};pop={}
 for mode in ('sampled','integrated'):
  v={}
  for actor in ('P','N'):
   sums={field:F(0) for field in ('ordinary','promoting')};positive={field:F(0) for field in sums}
   for row in g['rows']:
    if row['actor']!=actor:continue
    if mode=='sampled' and row['target_type']!=row['sampled_target']:continue
    w=f(row['mass'])/(2*mass)*(F(row['target_weight']) if mode=='integrated' else 1)
    for field in sums:
     x=exact(row,field);assert abs(float(x)-row[field])<1e-14;sums[field]+=w*x;positive[field]+=w*(x>0)
   v[actor]={'value':{k:str(x) for k,x in sums.items()},'positive_mass':{k:str(x) for k,x in positive.items()}}
  vectors[mode]={'actors':v,'N_P':{field:str(F(v['N']['value'][field])/F(v['P']['value'][field])) if F(v['P']['value'][field]) else None for field in ('ordinary','promoting')}}
 r['games'][name]={'seeds':len(reps),'old_seeds':len(prior['games'][name]['common_seeds']),'accepted_mass':str(mass),'old_mass':str(common),'retained_fraction':str(mass/common),'vectors':vectors,'scope':'Compare modes ONLY on same all-target/all-owner/P-N safe cohort. Prior-cohort versus this-cohort is separately qualified. Target integration conditional on backgrounds/one representative per displacement, not exact board census or stock utility.'}
 print(name,'mass',float(mass),'vectors',[(k,{f:float(F(x)) if x else None for f,x in v['N_P'].items()}) for k,v in vectors.items()],flush=True)
r['complete']=True;out.write_bytes((json.dumps(r,indent=2)+'\n').encode())
