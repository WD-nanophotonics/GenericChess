"""Research composition of existing APIs; not a new product/learner interface."""
from copy import copy
from types import SimpleNamespace
import time
from generic_chess.native.compiler import GC_SEM_MAX_PLY
def physical_key(a):
 return(getattr(a,'from_square',None),getattr(a,'to_square',None),getattr(a,'promotion_target_id',None),getattr(a,'base_type_id',None))
def source_choice(env,native,Choice):
 choices=tuple(env.actions())
 if isinstance(native,str):matches=[a for a in choices if a.kind=='DECLARATION'and a.declaration_id==native]
 elif hasattr(native,'geometry_id')and hasattr(env.session.compiled,'ir'):
  # Full typed identity is essential for compound secondary bindings.
  matches=[a for a in choices if a.kind=='ACTION'and a.action==native]
 else:matches=[a for a in choices if a.kind=='ACTION'and physical_key(a.action)==physical_key(native)]
 if len(matches)!=1:raise ValueError('Query mapping requires one exact source choice; no coordinate alias guessing')
 return matches[0]
def mapped_query(env,model,engine,Receipt,Choice,limits,*,root_window=True,cancel_token=None,requested_TT_megabytes=0,deadline_seconds=None):
 start=time.perf_counter();base=len(env.stack);raw=None
 if limits.quiescence_max_depth!=0 or requested_TT_megabytes!=0:raise NotImplementedError('Prototype qualifies cold explicitq0 only')
 if env.terminal()is not None:raise ValueError('Actual training controller must skip terminal roots before querying')
 depth=limits.max_depth
 if env.session.state.ply_count+depth>=GC_SEM_MAX_PLY:raise NotImplementedError('Legacy direct prototype leaves last-slot feature fallback to existing Core query')
 raw=engine.search(env.session,limits,cancel_token=cancel_token,root_window_pruning=root_window)
 nodes=raw.nodes+raw.qnodes
 complete=(raw.completed_depth==depth and not raw.used_fallback and raw.qnodes==0 and raw.termination_reason!='cancelled')
 if not complete:
  r=Receipt(None,None,None,False,(),nodes,False,0,time.perf_counter()-start,'native_incomplete:'+raw.termination_reason)
  return r,raw,dict(mapping_seconds=time.perf_counter()-start,reason=r.reason,deadline_missed=False)
 value=phi=terminal=action=None;mapping_start=time.perf_counter()
 def interrupted():
  if cancel_token is not None and cancel_token.is_cancelled():return 'query_cancelled_after_native'
  if deadline_seconds is not None and time.perf_counter()-start>deadline_seconds:return 'whole_query_deadline'
  return None
 def incomplete(reason):
  elapsed=time.perf_counter()-start
  return Receipt(None,None,None,False,(),nodes,False,0,elapsed,reason),raw,dict(mapping_seconds=time.perf_counter()-mapping_start,whole_query_seconds=elapsed,reason=reason,deadline_missed=reason=='whole_query_deadline')
 try:
  reason=interrupted()
  if reason:return incomplete(reason)
  for native in raw.decision_line:
   reason=interrupted()
   if reason:return incomplete(reason)
   chosen=source_choice(env,native,Choice)
   if action is None:action=chosen
   env.push(chosen)
   reason=interrupted()
   if reason:return incomplete(reason)
  z=env.terminal();terminal=z is not None
  if terminal:value=1_000_000.*z;phi=None
  else:phi=tuple(env.features());value=model.raw(phi)
 finally:
  while len(env.stack)>base:env.pop()
 reason=interrupted()
 if reason:return incomplete(reason)
 elapsed=time.perf_counter()-start;r=Receipt(action,value,phi,terminal,(),nodes,True,0,elapsed,'complete_native_cold_q0')
 return r,raw,dict(mapping_seconds=time.perf_counter()-mapping_start,whole_query_seconds=elapsed,reason=r.reason,deadline_missed=False)
