"""No Native/query/learner execution: retained receipts, full Core PVs, exact target algebra."""
from pathlib import Path
from collections import Counter,defaultdict
import sys,json,math,time,statistics
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_query import modules
from native_receipt import source_choice
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D.parent/'learned-prospective-20261019/inputs.json').read_bytes());trees=json.loads((D.parent/'learned-prospective-20261019/result.json').read_bytes())['trees'];R=json.loads((D/'cost-result.json').read_bytes());M,T,E,C=modules();ch=I['channels'];models={f"{m['generator_seed']}-{m['seed']}-{m['method']}":m for m in I['models']};parents={};checks=Counter();rootsets={};groups=defaultdict(dict);last=[0.]
def poll():
 now=time.perf_counter()
 if now-start>120:raise TimeoutError('READER_GLOBAL120')
 if now-last[0]>.1:
  last[0]=now
  root=Path(__import__('os').environ.get('GC_REPLAY_STOP_ROOT',str(Path.cwd())))
  for n in('rollout','advisor','slack'):
   f=json.loads((root/'.local_agent'/(n+'.json')).read_bytes())
   if f.get('stopped')or f.get('user_paused'):raise InterruptedError('USER_STOP')
def decode(a):
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
def optimum(n,w,side):
 if n['terminal']is not None:return n['terminal']*1e6,{('terminal',n['terminal'])}
 if n['depth']==2:return sum(a*b for a,b in zip(n['phi'],w)),{('material',*n['phi'])}
 values=[optimum(x['child'],w,1-side)for x in n['children']];best=(max if side==0 else min)(x[0]for x in values);sigs=set()
 for v,p in values:
  if v==best:sigs|=p
 return best,sigs
for root in I['roots']:
 poll();gs=root['generator_seed'];r=next(r for r in I['rules']if r['generator_seed']==gs);parents[gs,root['family']]=GameSession.replay(compile_ruleset(ruleset_from_dict(r['rule'])),deserialize_game_record(json.dumps(root['legacy_record'])))
for i,row in enumerate(R['rows']):
 if row['status']=='SKIP_ACTUAL_TERMINAL':checks['terminal_slots']+=1;continue
 poll();w=models[row['model']]['weights'];s=parents[row['generator_seed'],row['family']];tree=next(t['tree']for t in trees if(t['generator_seed'],t['family'])==(row['generator_seed'],row['family']));target,sigs=optimum(tree,w,s.state.position.side_to_move);signature=('terminal',0 if row['raw_value']==0 else 1 if row['raw_value']>0 else-1)if row['pv_terminal']else('material',*row['pv_phi']);assert signature in sigs and abs(row['raw_value']-target)<=1e-10;assert len(sigs)==1;pred=math.tanh(row['raw_value']/10);grad=[0.]*len(w)if row['pv_terminal']else[x*(1-pred*pred)/10 for x in row['pv_phi']];assert abs(pred-row['prediction'])<1e-12 and all(abs(a-b)<1e-12 for a,b in zip(grad,row['gradient']));groups[row['model'],row['generator_seed'],row['family'],row['repeat']][row['method']]=row;checks['rows']+=1
with(D/'cost-queries.jsonl').open()as f:
 for line in f:
  poll();x=json.loads(line);row=R['rows'][x['index']];assert x['summary']==row;receipt=x['receipt'];assert receipt['complete']and receipt['value']==row['raw_value']and receipt['pv_phi']==row['pv_phi']and receipt['pv_terminal']==row['pv_terminal']and receipt['nodes']==row['nodes'];checks['raw_receipts']+=1
  if x['Native']is None:continue
  raw=x['Native'];assert raw['completed_depth']==2 and not raw['used_fallback']and raw['qnodes']==0;env=E(parents[row['generator_seed'],row['family']],ch);before=env.record();first=None
  for a in raw['decision_line']:
   chosen=source_choice(env,decode(a),C)
   if first is None:first=record_value(chosen)
   env.push(chosen);checks['cost_PV_edges']+=1
  z=env.terminal();phi=None if z is not None else list(env.features());value=z*1e6 if z is not None else sum(a*b for a,b in zip(models[row['model']]['weights'],phi));assert value==receipt['value']and phi==receipt['pv_phi']and(z is not None)==receipt['pv_terminal']and first==receipt['action']
  while env.stack:env.pop()
  assert env.record()==before;checks['cost_Native_PVs']+=1
comparisons=[]
for key,methods in groups.items():
 a=methods['Source_currentCore']
 for name in('Native_False_TT0','Native_True_TT0'):
  b=methods[name];assert a['raw_value']==b['raw_value']and a['prediction']==b['prediction']and a['gradient']==b['gradient'];comparisons.append(dict(model=key[0],generator_seed=key[1],family=key[2],repeat=key[3],method=name,action_diff=a['source_action']!=b['source_action'],paired_caller_ratio=b['caller_seconds']/a['caller_seconds']))
cost={}
for method in('Source_currentCore','Native_False_TT0','Native_True_TT0'):
 rr=[r for r in R['rows']if r['method']==method and r['status']=='COMPLETE'];cost[method]=dict(queries=len(rr),caller_seconds=sum(r['caller_seconds']for r in rr),nodes=sum(r['nodes']for r in rr),median_caller_seconds=statistics.median(r['caller_seconds']for r in rr),max_caller_seconds=max(r['caller_seconds']for r in rr))
divergence={}
for method in('Native_False_TT0','Native_True_TT0'):
 rr=[r for r in comparisons if r['method']==method];unique={(r['model'],r['generator_seed'],r['family'])for r in rr if r['action_diff']};cost[method]['caller_sum_ratio_to_source']=cost[method]['caller_seconds']/cost['Source_currentCore']['caller_seconds'];divergence[method]=dict(repeated_pairs=len(rr),different_actions=sum(r['action_diff']for r in rr),distinct_contexts=len(unique),by_rule=dict(Counter(gs for _,gs,_ in unique)),paired_ratio_min=min(r['paired_caller_ratio']for r in rr),paired_ratio_median=statistics.median(r['paired_caller_ratio']for r in rr),paired_ratio_max=max(r['paired_caller_ratio']for r in rr))
W=json.loads((D/'witness-result.json').read_bytes());assert W['status']=='COMPLETE'and len(W['rows'])==32
for r in W['rows']:
 assert all(r['source_vs_original'].values())and all(r['mapped_vs_current_source'].values());checks['actual_witness_pairs']+=1
S=json.loads((D/'semantic-result.json').read_bytes());assert S['status']=='COMPLETE'and len(S['rows'])==20
for r in S['rows']:assert all(r['equal_fields'].values());checks['semantic_pairs']+=1
for r in S['aliases']:assert r['full_child_equal']and r['exact_unique']and r['physical_candidates']>=2;checks['typed_alias_choices']+=1
G=json.loads((D.parent/'global-capture-consumer-20261019/prepared.json').read_bytes());A=json.loads((D.parent/'compound-policy-alias-20261019/result.json').read_bytes());semantic_inputs={**{'global/'+p['phase']:(G['rule'],p['record'])for p in G['parents']},**{'alias/'+r['name']:(r['rule'],r['record'])for r in A['rows']}};semantic_parents={name:GameSession.replay(compile_semantic_ruleset(ruleset_from_dict(rule)),deserialize_game_record(json.dumps(record)))for name,(rule,record)in semantic_inputs.items()}
def replay(env,raw,w,expected,namespace):
 before=(env.record(),env.session.state,env.session.history,env.session._search_witnesses)
 for a in raw['decision_line']:env.push(source_choice(env,decode(a),C));checks[namespace+'_edges']+=1
 z=env.terminal();phi=None if z is not None else list(env.features());value=z*1e6 if z is not None else sum(a*b for a,b in zip(w,phi));assert value==expected['value']and phi==expected['pv_phi']and(z is not None)==expected['pv_terminal']
 while env.stack:env.pop()
 assert before==(env.record(),env.session.state,env.session.history,env.session._search_witnesses);checks[namespace+'_PVs']+=1
for r in S['rows']:poll();replay(E(semantic_parents[r['name']],r['channels']),r['Native'],r['weights'],r['results']['Native-cold-TT0-q0-rootwindow'],'semantic')
original_W=json.loads((D/'published-actual/witness-queries.json').read_bytes())
actual_action_differences=[];original_source_child_differences=[]
for r,original in zip(W['rows'],original_W):
 poll();q=original['query'];rule=next(t['rule']for t in I['rules']if t['generator_seed']==q['generator_seed']);s=GameSession.replay(compile_ruleset(ruleset_from_dict(rule)),deserialize_game_record(json.dumps(q['record_before'])));replay(E(s,ch),r['Native'],r['weights'],r['results']['Native-cold-q0-TT0-rootwindow'],'actual_witness')
 children={}
 for method,result in r['results'].items():
  env=E(s,ch);matches=[a for a in env.actions()if record_value(a)==result['action']];assert len(matches)==1;env.push(matches[0]);children[method]=(env.record(),env.session.state,env.session.history,env.session._search_witnesses)
 source_child=children['published-query-currentCore'];native_child=children['Native-cold-q0-TT0-rootwindow'];checks['actual_source_record_after_equal']+=source_child[0]==q['record_after'];checks['actual_source_record_after_checked']+=1
 if source_child[0]!=q['record_after']:original_source_child_differences.append(dict(index=r['index'],key=r['key'],which=r['which'],gameid=r['gameid'],ply=r['ply'],original_last=q['record_after']['actions'][-1],current_source_last=source_child[0]['actions'][-1],same_prefix=source_child[0]['actions'][:-1]==q['record_after']['actions'][:-1],same_record_except_actions={k:v for k,v in source_child[0].items()if k!='actions'}=={k:v for k,v in q['record_after'].items()if k!='actions'},source_action=r['results']['published-query-currentCore']['action']))
 if source_child!=native_child:actual_action_differences.append(dict(index=r['index'],key=r['key'],which=r['which'],gameid=r['gameid'],ply=r['ply'],source_action=r['results']['published-query-currentCore']['action'],Native_action=r['results']['Native-cold-q0-TT0-rootwindow']['action'],physical_state_changed=source_child[1]!=native_child[1],record_changed=source_child[0]!=native_child[0],history_changed=source_child[2]!=native_child[2],credit_equal=True))
deadline=json.loads((D/'deadline-result.json').read_bytes());assert deadline['status']=='COMPLETE'and len(deadline['rows'])==40;delivery={}
for r in deadline['rows']:
 poll();assert r['delivered_credit']==(r['returned_complete']and r['caller_seconds']<=deadline['deadline_seconds'])
 if not r['delivered_credit']:assert r['credit_prediction']is None and r['credit_gradient']is None
 if r['returned_complete']:assert all(r['completed_target_equal'].values())
 if r['Native']is not None:
  target=next(z for z in S['rows']if z['name']==r['name']);replay(E(semantic_parents[r['name']],target['channels']),r['Native'],target['weights'],target['results']['published-query-currentCore'],'deadline_raw')
 checks['deadline_accounted_queries']+=1
for method in ('Source_currentCore','Native_True_TT0'):
 rr=[r for r in deadline['rows']if r['method']==method];delivery[method]=dict(queries=len(rr),delivered=sum(r['delivered_credit']for r in rr),no_credit=sum(not r['delivered_credit']for r in rr),max_caller_seconds=max(r['caller_seconds']for r in rr),nodes=sum(r['raw_receipt']['nodes']for r in rr))
out=dict(status='PASS_NO_QUERY_RECEIPT_CORE_PV_AND_TARGET_READER',checks=dict(checks),cost=cost,divergence=divergence,actual_witness_different_children=actual_action_differences,original_source_child_differences=original_source_child_differences,deadline_delivery=delivery,setup_seconds=sum(v.get('seconds',0)+v.get('source_seconds',0)+v.get('Native_two_modes_seconds',0)for v in R['setup']),log_seconds=R['log_seconds'],producer_seconds=R['seconds'],seconds=time.perf_counter()-start,Native_queries=0,source_queries=0,optimizer_updates=0,new_games=0,scope='Retained existing closed D3 trees algebra evaluated atD2;864complete caller rows/576actualNative fullCorePVs plus32actualTRAINwitness/20semantic/20rawdeadlinePVs; no originalNative/source queries/TRAIN/EVAL/UNKNOWN refill. Cost includes commonfreshsourceenv copy+two records+query+rawpredictiongradient; sharedlogging/setup separate, not a liveTRAIN speedup. Different optimalrootactions despite identical unique credit vectors prevent trajectory/update equivalence. Source/Native node currencies differ.');write_json(D/'reader-result.json',out);print('TD_READER_PASS',dict(checks),'actualdifferentchildren',len(actual_action_differences),'originalSourceDiff',len(original_source_child_differences),flush=True)
