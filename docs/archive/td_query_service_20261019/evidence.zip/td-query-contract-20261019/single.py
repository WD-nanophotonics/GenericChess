"""One finite receipt-field mapping, no search or learner execution."""
from pathlib import Path
from copy import copy
import json,sys,hashlib,time,math
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D/'single-input.json').read_bytes());q=I['query'];root=I['root'];rule=ruleset_from_dict(I['rule']['rule']);c=compile_ruleset(rule);sc=compile_legacy_ruleset_for_semantic_execution(rule)
assert q['complete']and q['scale']==256 and q['result']['completed_depth']==2 and q['result']['qnodes']==0 and not q['result']['used_fallback']
s=GameSession.replay(c,deserialize_game_record(json.dumps(root['legacy_record'])));ss=GameSession.replay(sc,deserialize_game_record(json.dumps(root['semantic_record'])));before=(s.state,s.to_record(),s.history,s._search_witnesses,ss.state,ss.to_record(),ss.history,ss._search_witnesses);legacy=copy(s);semantic=copy(ss)
def key(a):
 if hasattr(a,'from_square'):return ['board',a.from_square.file,a.from_square.rank,a.to_square.file,a.to_square.rank,getattr(a,'promotion_target_id',None)]
 return ['drop',a.base_type_id,a.to_square.file,a.to_square.rank]
def decode(a):
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
actions=[]
for raw in q['result']['decision_line']:
 assert not isinstance(raw,str),'Declaration target not in this ordinaryq0 prototype'
 a=decode(raw);aa=[x for x in legacy.legal_actions()if key(x)==key(a)];assert len(aa)==1;legacy.submit(aa[0]);semantic.submit(a);actions.append(record_value(aa[0]));assert legacy.state.position==semantic.state.position and legacy.result==semantic.result
terminal=legacy.result.status.value!='ongoing';p=legacy.state.position;phi=[sum((1 if x.owner==0 else -1)for x in p.board if x is not None and x.current_type_id==t)if k=='board'else p.hands[0].count(t)-p.hands[1].count(t)for k,t in I['channels']];w=I['model']['weights'];raw=sum(x*y for x,y in zip(phi,w));value=(0 if legacy.result.winner is None else 1e6 if legacy.result.winner==0 else -1e6)if terminal else raw
side=1 if s.state.position.side_to_move==0 else -1;assert math.isclose(value*side,q['float_optimum'],abs_tol=1e-12,rel_tol=1e-12)
prediction=math.tanh(value/10);gradient=[0.]*len(w)if terminal else[x*(1-prediction**2)/10 for x in phi]
assert before==(s.state,s.to_record(),s.history,s._search_witnesses,ss.state,ss.to_record(),ss.history,ss._search_witnesses)
naive=side*q['result']['score']/256
out=dict(status='PASS_SINGLE_EXISTING_RECEIPT_MAP',receipt=dict(complete=True,value=value,pv_phi=None if terminal else phi,pv_terminal=terminal,action=actions[0],nodes=q['result']['nodes']+q['result']['qnodes'],samples=[]),prediction=prediction,gradient=gradient,naive_root_score_divided_by_scale=naive,naive_prediction=math.tanh(naive/10),naive_prediction_error=math.tanh(naive/10)-prediction,PV_edges=len(actions),seconds=time.perf_counter()-start,Native_queries=0,Core_searches=0,optimizer_updates=0,new_games=0,scope='One currentCore coldD2q0 fulltyped/history receipt only. Value andphi recomputed fromactualPV; exactsourcefloatoptimum backedby previousclosedtree. Native workcount isdifferent currency from sourceTrainingSearch. No arbitrarycached/selectivePV or optimizer/trajectoryequivalenceclaim.')
write_json(D/'single-result.json',out);print('SINGLE_RECEIPT',out)
