"""One actual existing Native call on a full legacy Session, no history-key copy."""
from pathlib import Path
from copy import copy
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D/'single-input.json').read_bytes());rule=ruleset_from_dict(I['rule']['rule']);c=compile_ruleset(rule);sc=compile_legacy_ruleset_for_semantic_execution(rule);s=GameSession.replay(c,deserialize_game_record(json.dumps(I['root']['legacy_record'])));before=(s.state,s.to_record(),s.history,s._search_witnesses)
from generic_chess.learning.material import LearnableMaterialCheckpoint
e=SemanticSearchEngine(sc,compile_native_semantic_rules(sc),checkpoint=LearnableMaterialCheckpoint.from_dict(I['checkpoint']),tt_megabytes=0);tick=time.perf_counter();z=e.search(s,SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=2,quiescence_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-tick
raw=record_value(z);old=I['query']['result'];fields={k:raw[k]==old[k]for k in('action','score','decision_line','completed_depth','nodes','qnodes')};assert all(fields.values())and before==(s.state,s.to_record(),s.history,s._search_witnesses)
l=copy(s)
for a in z.decision_line:
 assert not isinstance(a,str)
 def key(x):return(getattr(x,'from_square',None),x.to_square,getattr(x,'promotion_target_id',None),getattr(x,'base_type_id',None))
 choices=[x for x in l.legal_actions()if key(x)==key(a)];assert len(choices)==1;l.submit(choices[0])
write_json(D/'legacy-direct-result.json',dict(status='PASS_FULL_LEGACY_SESSION_DIRECT_NATIVE',Native_result=raw,equal_fields=fields,root_legacy_state=record_value(s.state),legacy_PV_leaf=record_value(l.state),Native_calls=1,Core_searches=0,whole_seconds=time.perf_counter()-start,caller_seconds=elapsed,optimizer_updates=0,new_games=0,scope='Actualexistingengine accepts matchingfingerprint/fullphysicalwitnesses oflegacySession andrehashesundersemanticcompiledidentity. TypedLegacyactionprojection onlyatreturnedPV; no historytruncation/keycopy/fullreplaymigration. Singlefinitecase, not1024featurefallback/declaration/all-domain admission.'))
print('LEGACY_DIRECT_PASS',elapsed,fields)
