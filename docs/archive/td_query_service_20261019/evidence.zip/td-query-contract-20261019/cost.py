"""Whole caller cost of actual source query and existing Native API composition."""
from pathlib import Path
import sys,json,time,random,math,hashlib
from collections import Counter
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_query import modules
from native_receipt import mapped_query
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;start=time.perf_counter();P=json.loads((D/'cost-plan.json').read_bytes());I=json.loads((D.parent/'learned-prospective-20261019/inputs.json').read_bytes());old=json.loads((D.parent/'learned-prospective-20261019/result.json').read_bytes());bundle=json.loads((D.parent/'learned-consumer-20261019/bound-checkpoints-scale256.json').read_bytes());cp_by={x['model']:x for x in bundle['entries']};M,T,E,C=modules();from results.dev_aux.task2492.learning import Receipt
status='COMPLETE';error=None;rows=[];counts=Counter();setup=[];rng=random.Random(973001);last=[-1.];log_seconds=0.;source_queries=Native_queries=0
def poll():
 now=time.perf_counter()
 if now-start>=P['global_seconds']:raise TimeoutError('FROZEN_GLOBAL300S')
 if now-last[0]>.05:
  last[0]=now
  for n in('rollout','advisor','slack'):
   f=json.loads(Path('.local_agent',n+'.json').read_bytes())
   if f.get('stopped')or f.get('user_paused'):raise InterruptedError('USER_STOP')
def safe(v):
 if isinstance(v,float)and not math.isfinite(v):return 'Infinity'if v>0 else '-Infinity'if v<0 else 'NaN'
 if isinstance(v,dict):return{k:safe(x)for k,x in v.items()}
 if isinstance(v,(list,tuple)):return[safe(x)for x in v]
 return v
def target(n,w,side,root_side):
 if n['terminal']is not None:return n['terminal']*1e6,{('terminal',n['terminal'])}
 if n['depth']==2:return sum(x*y for x,y in zip(n['phi'],w)),{('material',*n['phi'])}
 vv=[target(x['child'],w,1-side,root_side)for x in n['children']];best=(max if side==0 else min)(x[0]for x in vv);sigs=set()
 for value,phi in vv:
  if value==best:sigs.update(phi)
 return best,sigs
assert not(D/'cost-queries.jsonl').exists()
with(D/'cost-queries.jsonl').open('x',encoding='utf8',newline='\n')as log:
 try:
  for rule in I['rules']:
   poll();tick=time.perf_counter();gs=rule['generator_seed'];schema=ruleset_from_dict(rule['rule']);c=compile_ruleset(schema);sc=compile_legacy_ruleset_for_semantic_execution(schema);nr=compile_native_semantic_rules(sc);setup.append(dict(kind='rule_compile',generator_seed=gs,seconds=time.perf_counter()-tick));parents={}
   for root in I['roots']:
    if root['generator_seed']!=gs:continue
    tick=time.perf_counter();s=GameSession.replay(c,deserialize_game_record(json.dumps(root['legacy_record'])));parents[root['family']]=s;setup.append(dict(kind='full_parent_replay',generator_seed=gs,family=root['family'],seconds=time.perf_counter()-tick))
   for model in sorted((m for m in I['models']if m['generator_seed']==gs),key=lambda m:(m['seed'],m['method'])):
    poll();mid=f"{gs}-{model['seed']}-{model['method']}";tick=time.perf_counter();m=M(model['weights'],scale=10.);source_bind=time.perf_counter()-tick;cp=LearnableMaterialCheckpoint.from_dict(cp_by[mid]['checkpoint']);tick=time.perf_counter();e={mode:SemanticSearchEngine(sc,nr,checkpoint=cp,tt_megabytes=0)for mode in(False,True)};setup.append(dict(kind='model_binding',model=mid,source_seconds=source_bind,Native_two_modes_seconds=time.perf_counter()-tick));source_snapshot=tuple(m.weights)
    for family,s in parents.items():
     tree=next(t['tree']for t in old['trees']if(t['generator_seed'],t['family'])==(gs,family));ref,sigs=target(tree,m.weights,s.state.position.side_to_move,s.state.position.side_to_move);side=1 if s.state.position.side_to_move==0 else -1
     for repeat in range(P['repeats']):
      poll();methods=list(P['methods']);rng.shuffle(methods)
      for method in methods:
       poll();meta={};native=None;receipt=None
       if s.result.status.value!='ongoing':
        rows.append(dict(model=mid,generator_seed=gs,family=family,repeat=repeat,method=method,status='SKIP_ACTUAL_TERMINAL',caller_seconds=0.,nodes=0));counts['terminal_method_slots']+=1;continue
       tick=time.perf_counter();env=E(s,I['channels']);record=env.record();before=(env.session.state,env.session.history,env.session._search_witnesses);order=gs*100000000+family*1000+31415
       if method=='Source_currentCore':
        search=T(2,quiet=False);receipt=search.search(env,m,nodes=200000,seconds=min(2,P['global_seconds']-(time.perf_counter()-start)),seed=order,cancel=poll);source_queries+=1;meta=dict(source_stats=search.last_stats)
       else:
        mode=method=='Native_True_TT0';receipt,native,meta=mapped_query(env,m,e[mode],Receipt,C,SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=min(2,P['global_seconds']-(time.perf_counter()-start)),quiescence_max_depth=0),root_window=mode);Native_queries+=1
       assert env.record()==record and before==(env.session.state,env.session.history,env.session._search_witnesses)and tuple(m.weights)==source_snapshot
       pred=math.tanh(receipt.value/10)if receipt.complete else None;grad=([0.]*len(m.weights)if receipt.pv_terminal else list(m.gradient(receipt.pv_phi)))if receipt.complete else None;caller=time.perf_counter()-tick
       signature=('terminal',0 if receipt.value==0 else 1 if receipt.value>0 else -1)if receipt.pv_terminal else('material',*receipt.pv_phi)if receipt.complete else None
       gap=side*(ref-receipt.value)if receipt.complete else None
       if method=='Source_currentCore'and receipt.complete:assert abs(receipt.value-ref)<=1e-10 and signature in sigs
       row=dict(model=mid,generator_seed=gs,family=family,repeat=repeat,method=method,status='COMPLETE'if receipt.complete else'UNKNOWN_QUERY',caller_seconds=caller,nodes=receipt.nodes,source_order_seed=order,raw_value=receipt.value,prediction=pred,gradient=grad,pv_terminal=receipt.pv_terminal,pv_phi=record_value(receipt.pv_phi),float_target=ref,float_regret=gap,exact_optimal_signature=signature in sigs if receipt.complete else None,signature_count=len(sigs),source_action=record_value(receipt.action))
       rows.append(row);counts[method+'_queries']+=1;counts[method+'_complete']+=receipt.complete;counts[method+'_nodes']+=receipt.nodes;counts['positive_float_regret']+=bool(gap is not None and gap>1e-10)
       tick=time.perf_counter();log.write(json.dumps(safe(dict(index=len(rows)-1,summary=row,receipt=record_value(receipt),Native=None if native is None else record_value(native),meta=meta)),separators=(',',':'),allow_nan=False)+'\n');log.flush();log_seconds+=time.perf_counter()-tick
    del e
 except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'cost-result.json',dict(status=status,error=error,rows=rows,counts=dict(counts),setup=setup,source_query_calls=source_queries,Native_calls=Native_queries,log_seconds=log_seconds,seconds=time.perf_counter()-start,planned_method_slots=128*3*3,planned_source_queries=288,planned_Native_queries=576,unexecuted_method_slots=128*3*3-len(rows),new_games=0,optimizer_updates=0,scope='RetainedfullLegacySession wholecaller, exactpublishedquery/model/environment overCURRENTCore vsNativecoldD2q0sourceReceiptcomposition. Setup/binding/logIO separateandwholewall retained. SourceandNative nodesdifferentcurrencies. Fourterminalroots neverqueried, allslotsretained. No originalAUXCore/optimizer/TRAIN/EVAL/holdout/strength/APIclaim. Infinitysamplebounds losslessly taggedinrawJSONL; scalarpredictionfinite.'))
print('WHOLE_CALLER_COST',status,error,dict(counts),time.perf_counter()-start,flush=True)
