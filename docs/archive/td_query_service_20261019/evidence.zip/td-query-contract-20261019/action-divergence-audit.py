"""Replay existing source/Native action disagreements; do not run search or training."""
from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

from generic_chess.core.actions import BoardMove, DropMove
from generic_chess.core.coordinates import Square
from generic_chess.learning.features import material_features, non_anchor_type_ids
from generic_chess.rules.compiler import compile_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession


ROOT = Path(__file__).resolve().parents[2]
PRIVATE = ROOT / ".local_agent"
TASK = PRIVATE / "td-query-contract-20261019"
INPUT = PRIVATE / "learned-prospective-20261019" / "inputs.json"
QUERIES = TASK / "cost-queries.jsonl"
PLAN = TASK / "cost-plan.json"
OUTPUT = TASK / "action-divergence-result.json"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decode_action(record: dict):
    action = record["action"]
    if "from_square" in action:
        source = action["from_square"]
        target = action["to_square"]
        return BoardMove(
            Square(source["file"], source["rank"]),
            Square(target["file"], target["rank"]),
            action.get("promotion_target_id"),
        )
    target = action["to_square"]
    return DropMove(
        action["base_type_id"], Square(target["file"], target["rank"])
    )


def main() -> None:
    inputs = json.loads(INPUT.read_text(encoding="utf-8"))
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    grouped = defaultdict(dict)
    with QUERIES.open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            summary = row["summary"]
            key = (
                summary["model"],
                summary["generator_seed"],
                summary["family"],
                summary["repeat"],
            )
            grouped[key][summary["method"]] = row

    pattern_counts = Counter()
    mismatches = []
    seen_physical_roots = set()
    for (model, generator_seed, family, repeat), methods in grouped.items():
        required = ("Source_currentCore", "Native_False_TT0", "Native_True_TT0")
        if not all(name in methods for name in required):
            continue
        source = methods["Source_currentCore"]["summary"]["source_action"]
        native_false = methods["Native_False_TT0"]["receipt"]["action"]
        native_true = methods["Native_True_TT0"]["receipt"]["action"]
        source_action = decode_action(source)
        false_action = decode_action(native_false)
        true_action = decode_action(native_true)
        pattern = (
            "source_equals_native_false" if source_action == false_action else "source_differs_native_false",
            "source_equals_native_true" if source_action == true_action else "source_differs_native_true",
            "native_modes_equal" if false_action == true_action else "native_modes_differ",
        )
        pattern_counts["|".join(pattern)] += 1
        if source_action == false_action and source_action == true_action:
            continue

        physical_key = (generator_seed, family)
        if physical_key in seen_physical_roots:
            continue
        seen_physical_roots.add(physical_key)
        rule_row = next(x for x in inputs["rules"] if x["generator_seed"] == generator_seed)
        root_row = next(
            x for x in inputs["roots"]
            if x["generator_seed"] == generator_seed and x["family"] == family
        )
        compiled = compile_ruleset(ruleset_from_dict(rule_row["rule"]))
        record = deserialize_game_record(json.dumps(root_row["legacy_record"]))
        parent = GameSession.replay(compiled, record)
        legal = set(parent.legal_actions())
        source_session = GameSession.replay(compiled, record)
        false_session = GameSession.replay(compiled, record)
        source_session.submit(source_action)
        false_session.submit(false_action)
        type_ids = non_anchor_type_ids(compiled)
        source_features = material_features(source_session.state.position, type_ids)
        false_features = material_features(false_session.state.position, type_ids)
        mismatches.append(
            {
                "model": model,
                "generator_seed": generator_seed,
                "family": family,
                "repeat": repeat,
                "source_action": str(source_action),
                "native_action": str(false_action),
                "native_true_action": str(true_action),
                "source_legal": source_action in legal,
                "native_legal": false_action in legal,
                "successor_positions_equal": source_session.state.position == false_session.state.position,
                "immediate_material_vectors_equal": source_features == false_features,
                "source_promotion_target": getattr(source_action, "promotion_target_id", None),
                "native_promotion_target": getattr(false_action, "promotion_target_id", None),
                "source_board_counts": list(source_features.board_counts),
                "native_board_counts": list(false_features.board_counts),
                "type_ids": list(type_ids),
                "target_signature_count": methods["Source_currentCore"]["summary"]["signature_count"],
                "native_pv_feature_signature_member": methods["Native_False_TT0"]["summary"]["exact_optimal_signature"],
            }
        )

    unique_contexts = {
        (model, generator_seed, family)
        for (model, generator_seed, family, _), methods in grouped.items()
        if all(name in methods for name in ("Source_currentCore", "Native_False_TT0", "Native_True_TT0"))
        and decode_action(methods["Source_currentCore"]["summary"]["source_action"])
        != decode_action(methods["Native_False_TT0"]["receipt"]["action"])
    }
    payload = {
        "status": "COMPLETE",
        "question": "Do target-field matches also preserve actual action/successor identity?",
        "scope": "Reads saved cost queries and replays only four existing source/Native disagreement roots through current Core. No search, game, training, optimizer or refilled slots.",
        "source_core_sha": plan["Core_sha"],
        "source_training_sha": plan["source_sha"],
        "input_sha256": digest(INPUT),
        "query_log_sha256": digest(QUERIES),
        "planned_query_triplets": plan["models"] * plan["roots"] * plan["repeats"],
        "completed_query_triplets": sum(
            all(name in methods for name in ("Source_currentCore", "Native_False_TT0", "Native_True_TT0"))
            for methods in grouped.values()
        ),
        "action_pattern_counts": dict(pattern_counts),
        "mismatched_model_rule_contexts": len(unique_contexts),
        "mismatched_physical_roots": len(seen_physical_roots),
        "replayed_disagreements": mismatches,
        "conclusion": "All recorded Native PV material-feature signatures are target-set members, but this does not establish first-action optimality. Each replayed action pair is legal and yields a distinct successor; one changes promotion target and immediate material vector. Query-target equality therefore does not imply behavior-policy/trajectory equivalence.",
    }
    OUTPUT.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({k: payload[k] for k in (
        "status", "completed_query_triplets", "action_pattern_counts",
        "mismatched_model_rule_contexts", "mismatched_physical_roots", "conclusion"
    )}, ensure_ascii=False))


if __name__ == "__main__":
    main()
