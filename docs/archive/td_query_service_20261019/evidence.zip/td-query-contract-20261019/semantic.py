from pathlib import Path
from copy import copy
import sys,json,time,math
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_query import modules
from native_receipt import mapped_query,source_choice,physical_key
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;P=json.loads((D/'semantic-plan.json').read_bytes());G=json.loads((D.parent/'global-capture-consumer-20261019/prepared.json').read_bytes());A=json.loads((D.parent/'compound-policy-alias-20261019/result.json').read_bytes());start=time.perf_counter();M,T,E,C=modules();from results.dev_aux.task2492.learning import Receipt
rows=[];aliases=[];status='COMPLETE';error=None;last=[-1.];calls=dict(source=0,Native=0)
def poll():
 now=time.perf_counter()
 if now-start>P['global_seconds']:raise TimeoutError('FROZEN_GLOBAL120')
 if now-last[0]>.05:
  last[0]=now
  for n in('rollout','advisor','slack'):
   f=json.loads(Path('.local_agent',n+'.json').read_bytes())
   if f.get('stopped')or f.get('user_paused'):raise InterruptedError('USER_STOP')
def decode(a):
 from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
 from generic_chess.core.coordinates import Square
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
try:
 inputs=[dict(name='global/'+p['phase'],rule=G['rule'],record=p['record'],board=G['board_values'],hand=G['hand_values'],groups=[])for p in G['parents']]+[dict(name='alias/'+r['name'],rule=r['rule'],record=r['record'],board=r['board'],hand=r['hand'],groups=r['groups'])for r in A['rows']]
 for i,x in enumerate(inputs):
  poll();c=compile_semantic_ruleset(ruleset_from_dict(x['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(x['record'])));types=sorted(t for t in x['board']if t!='K');ch=[(k,t)for k in('board','hand')for t in types];w=[x['board'if k=='board'else'hand'][t]/256 for k,t in ch];m=M(w,scale=10.);cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,board_weights={t:x['board'][t]/256 for t in types},hand_weights={t:x['hand'][t]/256 for t in types},material_scale=256,value_scale=10.);engine=SemanticSearchEngine(c,compile_native_semantic_rules(c),checkpoint=cp,tt_megabytes=0)
  env=E(s,ch);before=(env.record(),env.session.state,env.session.history,env.session._search_witnesses)
  for g in x['groups']:
   for a in g['actions']:
    poll();native=decode(a['action']);chosen=source_choice(env,native,C);assert chosen.action==native;physical=[z for z in env.actions()if z.kind=='ACTION'and physical_key(z.action)==physical_key(native)];direct=copy(s);direct.submit(native);env.push(chosen);eq=(env.session.state,env.session.history,env.session._search_witnesses)==(direct.state,direct.history,direct._search_witnesses);env.pop();assert eq and len(physical)>=2;aliases.append(dict(name=x['name'],action=a['action'],physical_candidates=len(physical),exact_unique=True,full_child_equal=eq))
  assert before==(env.record(),env.session.state,env.session.history,env.session._search_witnesses)
  if env.terminal()is not None:rows.append(dict(name=x['name'],status='SKIP_ACTUAL_TERMINAL'));continue
  results={};raw=None
  for method in P['methods']:
   poll();env=E(s,ch);before=(env.record(),env.session.state,env.session.history,env.session._search_witnesses,tuple(m.weights));tick=time.perf_counter()
   if method.startswith('published'):q=T(2,quiet=False);r=q.search(env,m,nodes=P['nodes'],seconds=P['seconds_per_query'],seed=P['source_seed'],cancel=poll);calls['source']+=1
   else:r,raw,meta=mapped_query(env,m,engine,Receipt,C,SearchLimits(max_depth=2,max_nodes=P['nodes'],max_time_seconds=P['seconds_per_query'],quiescence_max_depth=0));calls['Native']+=1
   assert before==(env.record(),env.session.state,env.session.history,env.session._search_witnesses,tuple(m.weights))
   results[method]=dict(complete=r.complete,reason=r.reason,value=r.value,pv_phi=record_value(r.pv_phi),pv_terminal=r.pv_terminal,nodes=r.nodes,prediction=math.tanh(r.value/10)if r.complete else None,gradient=([0.]*len(w)if r.pv_terminal else list(m.gradient(r.pv_phi)))if r.complete else None,action=record_value(r.action),seconds=time.perf_counter()-tick)
  a,b=results.values();eq={k:(abs(a[k]-b[k])<=1e-10 if k in('value','prediction')else a[k]==b[k])for k in('value','pv_phi','pv_terminal','prediction','gradient')}if a['complete']and b['complete']else None
  rows.append(dict(name=x['name'],channels=ch,weights=w,results=results,Native=record_value(raw),equal_fields=eq))
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'semantic-result.json',dict(status=status,error=error,rows=rows,aliases=aliases,calls=calls,missing_inputs=20-len(rows),seconds=time.perf_counter()-start,scope=P['scope'],new_games=0,updates=0));print('SEMANTIC',status,error,calls,'pairs',len(rows),'allequal',sum(all(r['equal_fields'].values())for r in rows if r.get('equal_fields')is not None),'alias',len(aliases),flush=True)
