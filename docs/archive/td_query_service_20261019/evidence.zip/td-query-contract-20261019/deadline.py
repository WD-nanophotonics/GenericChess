from pathlib import Path
import sys,json,time,math,random
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_query import modules
from native_receipt import mapped_query
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;P=json.loads((D/'deadline-plan.json').read_bytes());G=json.loads((D.parent/'global-capture-consumer-20261019/prepared.json').read_bytes());A=json.loads((D.parent/'compound-policy-alias-20261019/result.json').read_bytes());ref=json.loads((D/'semantic-result.json').read_bytes());start=time.perf_counter();M,T,E,C=modules();from results.dev_aux.task2492.learning import Receipt
rows=[];status='COMPLETE';error=None;setup=0.;rng=random.Random(P['method_order_seed']);last=[-1.]
def poll():
 now=time.perf_counter()
 if now-start>P['global_seconds']:raise TimeoutError('FROZEN_GLOBAL60')
 if now-last[0]>.05:
  last[0]=now
  for n in('rollout','advisor','slack'):
   f=json.loads(Path('.local_agent',n+'.json').read_bytes())
   if f.get('stopped')or f.get('user_paused'):raise InterruptedError('USER_STOP')
try:
 inputs=[dict(name='global/'+p['phase'],rule=G['rule'],record=p['record'],board=G['board_values'],hand=G['hand_values'])for p in G['parents']]+[dict(name='alias/'+r['name'],rule=r['rule'],record=r['record'],board=r['board'],hand=r['hand'])for r in A['rows']]
 for x in inputs:
  poll();tick=time.perf_counter();c=compile_semantic_ruleset(ruleset_from_dict(x['rule']));s=GameSession.replay(c,deserialize_game_record(json.dumps(x['record'])));types=sorted(t for t in x['board']if t!='K');ch=[(k,t)for k in('board','hand')for t in types];w=[x['board'if k=='board'else'hand'][t]/256 for k,t in ch];m=M(w,scale=10.);cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,board_weights={t:x['board'][t]/256 for t in types},hand_weights={t:x['hand'][t]/256 for t in types},material_scale=256,value_scale=10.);engine=SemanticSearchEngine(c,compile_native_semantic_rules(c),checkpoint=cp,tt_megabytes=0);setup+=time.perf_counter()-tick;methods=list(P['methods']);rng.shuffle(methods)
  for method in methods:
   poll();tick=time.perf_counter();env=E(s,ch);before=env.record();remaining=max(0.,P['caller_seconds']-(time.perf_counter()-tick));raw=None
   if method=='Source_currentCore':q=T(2,quiet=False);r=q.search(env,m,nodes=P['max_nodes'],seconds=remaining,seed=973021,cancel=poll)
   else:r,raw,meta=mapped_query(env,m,engine,Receipt,C,SearchLimits(max_depth=2,max_nodes=P['max_nodes'],max_time_seconds=remaining,quiescence_max_depth=0),deadline_seconds=remaining)
   pred=math.tanh(r.value/10)if r.complete else None;grad=([0.]*len(w)if r.pv_terminal else list(m.gradient(r.pv_phi)))if r.complete else None;assert env.record()==before and not env.stack;elapsed=time.perf_counter()-tick;delivered=r.complete and elapsed<=P['caller_seconds'];reference=next(z for z in ref['rows']if z['name']==x['name'])['results']['published-query-currentCore'];equal=None
   if r.complete:equal=dict(value=abs(r.value-reference['value'])<=1e-10,prediction=abs(pred-reference['prediction'])<=1e-12,gradient=all(abs(u-v)<1e-12 for u,v in zip(grad,reference['gradient'])))
   rows.append(dict(name=x['name'],method=method,caller_seconds=elapsed,search_remaining_seconds=remaining,returned_complete=r.complete,delivered_credit=delivered,credit_prediction=pred if delivered else None,credit_gradient=grad if delivered else None,raw_receipt=record_value(r),Native=record_value(raw),completed_target_equal=equal))
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
write_json(D/'deadline-result.json',dict(status=status,error=error,rows=rows,planned=40,missing=40-len(rows),seconds=time.perf_counter()-start,setup_seconds=setup,new_games=0,updates=0,scope=P['scope'],deadline_seconds=P['caller_seconds']));print('WHOLE_DEADLINE',status,error,{m:dict(queries=sum(r['method']==m for r in rows),complete=sum(r['method']==m and r['returned_complete']for r in rows),delivered=sum(r['method']==m and r['delivered_credit']for r in rows),max_caller=max(r['caller_seconds']for r in rows if r['method']==m))for m in P['methods']},flush=True)
