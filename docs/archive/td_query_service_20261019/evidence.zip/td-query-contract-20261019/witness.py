from pathlib import Path
import sys,json,time,math
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_query import modules
from native_receipt import mapped_query
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;start=time.perf_counter();P=json.loads((D/'witness-plan.json').read_bytes());W=json.loads((D/'published-actual/witness-queries.json').read_bytes());I=json.loads((D/'single-input.json').read_bytes());B=json.loads((D.parent/'learned-prospective-20261019/inputs.json').read_bytes());M,T,E,C=modules();from results.dev_aux.task2492.learning import Receipt
rows=[];calls=dict(source=0,Native=0);status='COMPLETE';error=None;last=[-1.]
def poll():
 now=time.perf_counter()
 if now-start>P['global_seconds']:raise TimeoutError('FROZEN_GLOBAL120')
 if now-last[0]>.05:
  last[0]=now
  for n in ('rollout','advisor','slack'):
   f=json.loads(Path('.local_agent',n+'.json').read_bytes())
   if f.get('stopped')or f.get('user_paused'):raise InterruptedError('USER_STOP')
try:
 for i,x in enumerate(W):
  poll();q=x['query'];gs=q['generator_seed'];schema=ruleset_from_dict(next(r['rule']for r in B['rules']if r['generator_seed']==gs));sc=compile_legacy_ruleset_for_semantic_execution(schema);s=GameSession.replay(compile_ruleset(schema),deserialize_game_record(json.dumps(q['record_before'])));m=M(q['weights'],scale=10.);cp=LearnableMaterialCheckpoint(ruleset_fingerprint=sc.ruleset_fingerprint,board_weights={t:w for (kind,t),w in zip(I['channels'],q['weights'])if kind=='board'},hand_weights={t:w for (kind,t),w in zip(I['channels'],q['weights'])if kind=='hand'},material_scale=256,value_scale=10.);engine=SemanticSearchEngine(sc,compile_native_semantic_rules(sc),checkpoint=cp,tt_megabytes=0);result={};native=None
  for method in P['methods']:
   poll();env=E(s,I['channels']);before=(env.record(),env.session.state,env.session.history,env.session._search_witnesses,tuple(m.weights));tick=time.perf_counter()
   if method.startswith('published'):
    search=T(2,quiet=False);r=search.search(env,m,nodes=P['nodes'],seconds=P['seconds_per_query'],seed=q['ordering_seed'],cancel=poll);calls['source']+=1
   else:r,native,meta=mapped_query(env,m,engine,Receipt,C,SearchLimits(max_depth=2,max_nodes=P['nodes'],max_time_seconds=P['seconds_per_query'],quiescence_max_depth=0));calls['Native']+=1
   assert before==(env.record(),env.session.state,env.session.history,env.session._search_witnesses,tuple(m.weights))
   result[method]=dict(complete=r.complete,value=r.value,pv_phi=record_value(r.pv_phi),pv_terminal=r.pv_terminal,action=record_value(r.action),nodes=r.nodes,reason=r.reason,seconds=time.perf_counter()-tick,prediction=math.tanh(r.value/10)if r.complete else None,gradient=([0.]*len(m.weights)if r.pv_terminal else list(m.gradient(r.pv_phi)))if r.complete else None)
  a,b=result.values();orig={k:q[k]for k in('complete','value','pv_phi','pv_terminal','nodes','total_nodes','effective_nodes','effective_seconds','ordering_seed')};complete=a['complete']and b['complete'];eq=None
  if complete:eq=dict(value=abs(a['value']-b['value'])<=1e-10,phi=a['pv_phi']==b['pv_phi'],terminal=a['pv_terminal']==b['pv_terminal'],prediction=abs(a['prediction']-b['prediction'])<=1e-12,gradient=all(abs(u-v)<1e-12 for u,v in zip(a['gradient'],b['gradient'])))
  rows.append(dict(index=i,key=x['key'],which=x['which'],gameid=q['gameid'],ply=q['ply'],weights=q['weights'],original_recorded=orig,source_vs_original={k:(abs(a[k]-q[k])<=1e-10 if k=='value'and a[k]is not None else a[k]==q[k])for k in('complete','value','pv_phi','pv_terminal')},mapped_vs_current_source=eq,results=result,Native=record_value(native)))
except BaseException as exc:status='INCOMPLETE';error=repr(exc)
out=dict(status=status,error=error,calls=calls,planned=32,rows=rows,missing=32-len(rows),seconds=time.perf_counter()-start,new_games=0,updates=0,scope=P['scope']);write_json(D/'witness-result.json',out);print('WITNESS',status,error,calls,'complete_pairs',sum(r['mapped_vs_current_source']is not None for r in rows),'allfields',sum(all(r['mapped_vs_current_source'].values())for r in rows if r['mapped_vs_current_source']is not None),flush=True)
