from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_query import modules
from native_receipt import mapped_query
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D/'single-input.json').read_bytes());M,T,E,C=modules();from results.dev_aux.task2492.learning import Receipt
rule=ruleset_from_dict(I['rule']['rule']);c=compile_ruleset(rule);sc=compile_legacy_ruleset_for_semantic_execution(rule);s=GameSession.replay(c,deserialize_game_record(json.dumps(I['root']['legacy_record'])));env=E(s,I['channels']);model=M(I['model']['weights']);cp=LearnableMaterialCheckpoint.from_dict(I['checkpoint']);nr=compile_native_semantic_rules(sc);before=(env.record(),env.session.state,list(model.weights));rows=[]
for budget in(0,1,8):
 source=T(2,quiet=False).search(env,model,nodes=budget,seconds=1,seed=429497)
 e=SemanticSearchEngine(sc,nr,checkpoint=cp,tt_megabytes=0);r,z,meta=mapped_query(env,model,e,Receipt,C,SearchLimits(max_depth=2,max_nodes=budget,max_time_seconds=1,quiescence_max_depth=0));del e
 assert not source.complete and not r.complete and r.value is None and r.action is None and r.pv_phi is None
 assert before==(env.record(),env.session.state,list(model.weights));rows.append(dict(case='nodes'+str(budget),source=record_value(source),mapped=record_value(r),Native=record_value(z),meta=meta))
e=SemanticSearchEngine(sc,nr,checkpoint=cp,tt_megabytes=0);token=CancellationToken();token.cancel();r,z,meta=mapped_query(env,model,e,Receipt,C,SearchLimits(max_depth=2,max_nodes=200000,max_time_seconds=1,quiescence_max_depth=0),cancel_token=token);assert not r.complete and r.value is None and 'cancel'in r.reason;rows.append(dict(case='pre_cancel',mapped=record_value(r),Native=record_value(z),meta=meta));del e
refusals=[]
for name,kwargs,limits in [('nonzeroq',{},SearchLimits(max_depth=2,quiescence_max_depth=1)),('warmTT',{'requested_TT_megabytes':4},SearchLimits(max_depth=2,quiescence_max_depth=0))]:
 try:mapped_query(env,model,None,Receipt,C,limits,**kwargs)
 except NotImplementedError:refusals.append(name)
 else:raise AssertionError('Unqualifiedregime silentlyadmitted')
source_inputs=json.loads((D.parent/'learned-consumer-20261019/inputs.json').read_bytes());terminal=next(r for r in source_inputs['roots']if r['source_terminal']['status']!='ongoing');rul=next(r for r in source_inputs['rules']if r['generator_seed']==terminal['generator_seed']);ts=GameSession.replay(compile_ruleset(ruleset_from_dict(rul['rule'])),deserialize_game_record(json.dumps(terminal['legacy_record'])));te=E(ts,I['channels'])
try:mapped_query(te,model,None,Receipt,C,SearchLimits(max_depth=2,quiescence_max_depth=0))
except ValueError:refusals.append('actualterminal_controller_skip')
else:raise AssertionError('Terminalroot turnedintoNativecredit')
write_json(D/'abort-result.json',dict(status='PASS_STRICT_INCOMPLETE_AND_REGIME_REFUSALS',rows=rows,refusals=refusals,Native_queries=4,source_queries=3,seconds=time.perf_counter()-start,new_games=0,optimizer_updates=0,scope='ActualNative/sourcebudget probes andcancelobject; no userstopflag injection. No incompleteD1/fallback/action scoredascompleteD2. Paidnodes areseparatecurrencies. Prototype deliberatelyrefuses qnonzero,warmTT,terminalroot query; fullprojecttask not redefined.'))
print('ABORT_CONTRACT_PASS',[(r['case'],r['Native']['completed_depth'],r['Native']['used_fallback'])for r in rows],refusals)
