"""Boundary fault injection using one already recorded real Native receipt, zero searches."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import sys,json
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_query import modules
from native_receipt import mapped_query
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path(__file__).resolve().parent;I=json.loads((D/'single-input.json').read_bytes());M,T,E,C=modules();from results.dev_aux.task2492.learning import Receipt
def decode(a):
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
raw=dict(I['query']['result']);raw['decision_line']=tuple(decode(a)for a in raw['decision_line']);raw=SimpleNamespace(**raw);s=GameSession.replay(compile_ruleset(ruleset_from_dict(I['rule']['rule'])),deserialize_game_record(json.dumps(I['root']['legacy_record'])));rows=[]
for case in('control','cancel_after_native','cancel_after_first_push','deadline_after_native','deadline_after_first_push','exception_after_first_push'):
 clock=[0.];token=CancellationToken();env=E(s,I['channels']);before=(env.record(),env.session.state,env.session.history,env.session._search_witnesses);push=env.push;pushes=[0]
 class RecordedEngine:
  def search(self,*args,**kw):
   if case=='cancel_after_native':token.cancel()
   if case=='deadline_after_native':clock[0]=3.
   return raw
 def injected_push(a):
  push(a);pushes[0]+=1
  if pushes[0]==1:
   if case=='cancel_after_first_push':token.cancel()
   if case=='deadline_after_first_push':clock[0]=3.
   if case=='exception_after_first_push':raise RuntimeError('INJECTED_AFTER_REAL_PUSH')
 env.push=injected_push;receipt=None;error=None
 try:
  with patch('native_receipt.time.perf_counter',lambda:clock[0]):receipt,z,meta=mapped_query(env,M(I['model']['weights'],scale=10.),RecordedEngine(),Receipt,C,SearchLimits(max_depth=2,quiescence_max_depth=0),cancel_token=token,deadline_seconds=2.)
 except RuntimeError as exc:error=str(exc)
 restored=before==(env.record(),env.session.state,env.session.history,env.session._search_witnesses)and not env.stack
 passed=restored and((receipt.complete and receipt.value is not None)if case=='control'else(error=='INJECTED_AFTER_REAL_PUSH')if case.startswith('exception')else(not receipt.complete and receipt.value is None and receipt.action is None and receipt.pv_phi is None))
 rows.append(dict(case=case,passed=passed,restored=restored,pushes=pushes[0],receipt=record_value(receipt),error=error))
out=dict(status='PASS'if all(r['passed']for r in rows)else'OBSERVED_RESEARCH_ADAPTER_CONTROL_GAP',rows=rows,Native_queries=0,source_queries=0,updates=0,new_games=0,scope='Controlled post-return cancellation/fake deadline/exception injection with recorded actual complete Native receipt and real source environment push/pop. Not new Native execution, product bug or actual user-stop injection.');name=sys.argv[1]if len(sys.argv)>1 else'post-return-result.json';write_json(D/name,out);print(name,out['status'],[(r['case'],r['passed'])for r in rows])
