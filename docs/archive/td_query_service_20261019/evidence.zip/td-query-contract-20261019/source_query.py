"""Published query/model/environment only; current Core, no learner/prover execution."""
from pathlib import Path
import sys,ast,types,importlib.util,json,time,hashlib,os
from dataclasses import dataclass
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.core.actions import action_to_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset
from generic_chess.session.session import GameSession
from generic_chess.session.result import SessionStatus
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
D=Path(__file__).resolve().parent;S=D/'dependency-source'
def load(name,path,names=None,extra=None):
 path=S/path
 if names is None:
  spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
 tree=ast.parse(path.read_text());body=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))and n.name in names];assert {n.name for n in body}==set(names)
 m=types.ModuleType(name);m.__file__=str(path);m.__dict__.update(extra or{});sys.modules[name]=m;exec(compile(ast.Module(body=body,type_ignores=[]),str(path),'exec'),m.__dict__);return m
def modules():
 learning=load('results.dev_aux.task2492.learning','results/dev_aux/task2492/learning.py')
 free=load('results.dev_aux.task2532.free_model','results/dev_aux/task2532/free_model.py')
 search=load('results.dev_aux.task2504.search','results/dev_aux/task2504/search.py')
 material=load('results.dev_aux.task2397.material','results/dev_aux/task2397/material.py')
 env=load('results.dev_aux.task2492.adapters','results/dev_aux/task2492/adapters.py')
 generic=load('results.dev_aux.task2511.generic','results/dev_aux/task2511/generic.py')
 ordering=load('gc_source_ordering','scripts/generic_win_proof.py',['_ordered'],dict(json=json,action_to_dict=action_to_dict))
 choice=load('scripts.generic_session_win_proof','scripts/generic_session_win_proof.py',['SessionChoice','choices','execute'],dict(dataclass=dataclass,SessionStatus=SessionStatus,_ordered=ordering._ordered))
 recorded=load('gc_source_recorded','results/dev_aux/task2525/run.py',['RecordedSessionEnv'],dict(ScoringSessionEnv=generic.ScoringSessionEnv,json=json,serialize_game_record=serialize_game_record))
 return free.FreeModel,search.TrainingSearch,recorded.RecordedSessionEnv,choice.SessionChoice
def main():
 start=time.perf_counter();I=json.loads((D/'single-input.json').read_bytes());mapped=json.loads((D/'single-result.json').read_bytes());P=json.loads((D/'source-single-plan.json').read_bytes());M,T,E,C=modules();s=GameSession.replay(compile_ruleset(ruleset_from_dict(I['rule']['rule'])),deserialize_game_record(json.dumps(I['root']['legacy_record'])));env=E(s,I['channels']);model=M(I['model']['weights'],scale=10.);before=(env.record(),env.session.state,env.session.history,env.session._search_witnesses,list(model.weights));last=[0.]
 def cancel():
  now=time.perf_counter();assert now-start<P['global_seconds']
  if now-last[0]>.05:
   last[0]=now
   for n in('rollout','advisor','slack'):
    f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(Path.cwd())))/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 tick=time.perf_counter();query=T(P['depth'],quiet=False);r=query.search(env,model,nodes=P['source_nodes'],seconds=P['source_seconds'],seed=P['ordering_seed'],cancel=cancel);elapsed=time.perf_counter()-tick
 assert before==(env.record(),env.session.state,env.session.history,env.session._search_witnesses,list(model.weights))
 equal=None
 if r.complete:
  equal=dict(value=abs(r.value-mapped['receipt']['value'])<=1e-12,pv_phi=record_value(r.pv_phi)==mapped['receipt']['pv_phi'],pv_terminal=r.pv_terminal==mapped['receipt']['pv_terminal']);assert all(equal.values())
  prediction=model.prediction(r.pv_phi)if not r.pv_terminal else 0 if r.value==0 else 1 if r.value>0 else -1;gradient=list(model.gradient(r.pv_phi))if not r.pv_terminal else [0.]*len(model.weights);assert abs(prediction-mapped['prediction'])<1e-12 and all(abs(a-b)<1e-12 for a,b in zip(gradient,mapped['gradient']))
 out=dict(status='PASS_ACTUAL_SOURCE_QUERY'if r.complete else'UNKNOWN_SOURCE_QUERY',receipt=record_value(r),actual_query_seconds=elapsed,stats=query.last_stats,matching_TD_fields=equal,seconds=time.perf_counter()-start,source_query_calls=1,Native_queries=0,new_games=0,optimizer_updates=0,source_version='57696f621cda9957bbef8f10d5ff8515f8482616',Core_version='302aef755b883a321a6babe06eb2c3329d61c4bf',scope='Exactpublishedsearch/model/environment routines overCURRENTCore, not originalAUXCoreaudit/TRAIN/EVAL. Unusedsamples retained butnotrequiredbyTD. Onequery wall only, nothistoricalNative speedcomparison.')
 write_json(D/'source-single-result.json',out);print('ACTUAL_SOURCE_QUERY',out['status'],r.nodes,elapsed,equal)
if __name__=='__main__':main()
