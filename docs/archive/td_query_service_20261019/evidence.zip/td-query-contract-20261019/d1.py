from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_query import modules
from native_receipt import mapped_query
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset,compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
D=Path(__file__).resolve().parent;start=time.perf_counter();I=json.loads((D/'single-input.json').read_bytes());P=json.loads((D/'d1-plan.json').read_bytes());M,T,E,C=modules();from results.dev_aux.task2492.learning import Receipt
rule=ruleset_from_dict(I['rule']['rule']);sc=compile_legacy_ruleset_for_semantic_execution(rule);s=GameSession.replay(compile_ruleset(rule),deserialize_game_record(json.dumps(I['root']['legacy_record'])));e=SemanticSearchEngine(sc,compile_native_semantic_rules(sc),checkpoint=LearnableMaterialCheckpoint.from_dict(I['checkpoint']),tt_megabytes=0);r,z,meta=mapped_query(E(s,I['channels']),M(I['model']['weights']),e,Receipt,C,SearchLimits(max_depth=2,max_nodes=P['node_budget'],max_time_seconds=1,quiescence_max_depth=0));assert not r.complete and r.value is None
write_json(D/'d1-result.json',dict(status='PASS_INCOMPLETE_D2_NO_CREDIT',observed_retained_D1=z.completed_depth==1,Native=record_value(z),mapped=record_value(r),meta=meta,Native_queries=1,source_queries=0,seconds=time.perf_counter()-start));print('D1_BOUNDARY',z.completed_depth,z.used_fallback,z.nodes,r.complete)
