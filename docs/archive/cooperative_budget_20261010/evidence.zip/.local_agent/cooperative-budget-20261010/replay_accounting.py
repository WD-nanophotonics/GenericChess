"""Installed Native replay accounting from existing counters, no trace/Cbuild.
For COMPLETE q0/no-fallback calls: every negamax entry is root-iteration,
ordinary child after transition_count++, or canonical selected-PV replay child
whose transition is not counted. Thus replay entry count=nodes-transitions-roots.
Do not apply to interrupted calls (a checked edge may not enter its child).
Three existing supported roots xTT0/64 x2cold engines x2same-D3 calls=24serial.
1million/30sec fuse percall, fullrootOFF/no learned/policy/trace/material change.
Raw generation/transition/TT counters retained; separately count kernel/caller.
No inference that replay subtree size equals replay-entry count. Scope installed
source ABI; warm cache differences preserved, no finite-PV witness assumption.
Expected<2min; cold64MB and reused same engine, no extra workers or overlap.
"""
from pathlib import Path
import json,hashlib
from time import perf_counter
from dataclasses import asdict
folder=Path(__file__).parent;f=folder/'native_schedule.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'replay-accounting.json'
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for name,factory,values in ns['ns']['ns']['factories'][3:]:
 core=factory();board=ns['ns']['NativeBoard'](core,values);session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
 for repeat,order in enumerate(((0,64),(64,0))):
  for mb in order:
   engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=mb)
   for run in ('cold','same_horizon_warm'):
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    start=perf_counter();r=engine.search(session,SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0));wall=perf_counter()-start
    row={'case':name,'repeat':repeat,'tt_mb':mb,'run':run,'result':asdict(r),'caller_seconds':wall}
    if r.completed_depth==3 and r.termination_reason=='max_depth' and not r.used_fallback:
     row['replay_entry_count']=r.nodes-r.transition_count-r.root_iterations_attempted
     assert row['replay_entry_count']>=0
     if mb==0:assert row['replay_entry_count']==0 and r.tt_status=='NOT_STARTED' and r.tt_allocated_bytes==0
    else:row['replay_entry_count']=None
    assert board.restored() and session.state==core.initial
    report['rows'].append(ns['ns']['record_value'](row));save()
    print(name,mb,run,r.nodes,r.transition_count,r.root_iterations_attempted,row['replay_entry_count'],round(wall,3),flush=True)
report['complete']=True;save()
