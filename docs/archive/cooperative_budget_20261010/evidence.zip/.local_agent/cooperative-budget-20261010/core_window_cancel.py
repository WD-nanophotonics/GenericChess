"""16actualcancel Core-window single-variable controls, matched live polls.
Twoexisting generated roots x2strict-tie windowarms x2delays .05/.15 x2reversed,
1million/30sec/maxD12, no TT/q/price/state change. Timer onlyflagsetter; actual
request-return/pollgap/returned completedroute stored. Postcancel validation is
not counted as search response; caller returns legally generated illustrative
line with completed-iteration provenance, not an independent minimax witness.
Expected<1min, run afterlabel fixedassay to prevent overlapping CPU work.
"""
from pathlib import Path
import json,hashlib,threading
from time import perf_counter
folder=Path(__file__).parent;f=folder/'core_window.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
f=folder/'cancel_assay.py';tokens={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=dict')[0],tokens)
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'core-window-cancel.json'
for name,factory,values in ns['ns']['factories'][2:]:
 for delay in (.05,.15):
  for repeat,order in enumerate((('source','fullroot_ab'),('fullroot_ab','source'))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();material=ns['ns']['Material']('chess');material.values=values;core.material=material;token=tokens['Token']();timer=threading.Timer(delay,token.cancel);timer.daemon=True;start=perf_counter();timer.start()
    try:r=ns['model'](core,mode=='source',30,1000000,12,token);end=perf_counter()
    finally:timer.cancel();timer.join()
    assert core.restored() and r['exit_cause']=='cancelled' and token.requested is not None
    report['rows'].append(ns['ns']['record_value']({'case':name,'mode':mode,'repeat':repeat,'intended_delay':delay,'actual_request_delay':token.requested-start,'request_to_return_seconds':end-token.requested,'max_poll_gap_seconds':token.max_gap,'result':r}));out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
report['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print('16actual window cancels restored')
