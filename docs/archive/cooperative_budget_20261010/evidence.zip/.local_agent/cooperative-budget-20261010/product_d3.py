"""Four cold supported productCore D3 counter-controls, same two generated roots.
Default TT/order, root tactical OFF,q0/material/fullhistory/60sec+100000 fuse,
two reversed root passes. Existing new plain models have identical live semantic
budget checks but unlike TT/order/root-window policy; this is overall configured
search control, not isolated window cause. No teacher/cohort/default change.
Question: would replacing currentCore with the cheaper-than-Native-schedule
plain model actually help? Expected<1min, serial after fixed Core model/audits.
"""
from pathlib import Path
import json,hashlib
from time import perf_counter
folder=Path(__file__).parent;f=folder/'assay.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
from dataclasses import asdict
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
rows=[]
for repeat,order in enumerate((ns['factories'][2:],list(reversed(ns['factories'][2:])))):
 for name,factory,values in order:
  for flag in ('rollout','advisor','slack'):
   flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
  core=factory();material=ns['Material']('chess');material.values=values;stats=SearchStatistics();start=perf_counter()
  action,score,pv,reason=run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=3,max_nodes=100000,max_time_seconds=60,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
  wall=perf_counter()-start;assert core.restored() and stats.completed_depth==3
  rows.append(ns['record_value']({'case':name,'repeat':repeat,'score':score,'move':core.label(action),'pv':[core.label(a) for a in pv],'statistics':asdict(stats),'caller_seconds':wall}));print(name,stats.nodes,round(wall,3),score,flush=True)
out={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True}
(folder/'product-d3.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
