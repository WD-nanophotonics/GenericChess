"""24actualNativecancel controls for entry-accounting applicability/response.
Three existing roots xTT0/64 xdelay.01/.05 x2reversed=24serial calls, maxD12/
1million/30sec, material/q0/rootOFF, cold engine. Timer onlyflags real token.
Record residual but NEVER label it exact replay count on cancelled iterations;
ordinary transition can be accepted before child entry sees cancel. Measure
actual request-return, source state restoration and returned completed/fallback
metadata. No phase timer, claimSLA, extra worker/build or frozenoracle growth.
Expected<1min; CPU serial after stored warmroute audit.
"""
from pathlib import Path
import json,hashlib,threading
from time import perf_counter
from dataclasses import asdict
folder=Path(__file__).parent;f=folder/'replay_accounting.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
from generic_chess.ai.cancellation import CancellationToken
class Token(CancellationToken):
 def __init__(self):super().__init__();self.requested=None
 def cancel(self):self.requested=perf_counter();super().cancel()
rows=[];out=folder/'native-cancel-accounting.json'
for name,factory,values in ns['ns']['ns']['ns']['factories'][3:]:
 core=factory();board=ns['ns']['ns']['NativeBoard'](core,values);session=ns['GameSession'](core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
 for delay in (.01,.05):
  for repeat,order in enumerate(((0,64),(64,0))):
   for mb in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ns['ns']['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    engine=ns['SemanticSearchEngine'](core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=mb)
    token=Token();timer=threading.Timer(delay,token.cancel);timer.daemon=True;start=perf_counter();timer.start()
    try:r=engine.search(session,ns['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0),token);end=perf_counter()
    finally:timer.cancel();timer.join()
    assert token.requested is not None and r.termination_reason=='cancelled' and session.state==core.initial and board.restored()
    rows.append(ns['ns']['ns']['record_value']({'case':name,'tt_mb':mb,'repeat':repeat,'intended_delay':delay,'actual_request_delay':token.requested-start,'request_to_return_seconds':end-token.requested,'raw_entry_residual':r.nodes-r.transition_count-r.root_iterations_attempted,'replay_entry_count':None,'result':asdict(r)}))
    out.write_bytes((json.dumps({'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':False},indent=2)+'\n').encode())
out.write_bytes((json.dumps({'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True},indent=2)+'\n').encode())
print(len(rows),'actualcancel max',max(r['request_to_return_seconds'] for r in rows)*1000,'ms;residuals',sorted(set(r['raw_entry_residual'] for r in rows)))
