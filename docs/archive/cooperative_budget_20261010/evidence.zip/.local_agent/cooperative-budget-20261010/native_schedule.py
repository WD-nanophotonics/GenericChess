"""Source-guided TT0/rootOFF/q0 scheduling assay, no native compilation.
Three existing EP/generated roots, installed candidate/transition/terminal/eval
backend. D1-D3 cumulative, <=1million entries/30sec per model. Source policy
retains candidate index (including illegal first), packed tie and PV full-window
dispatch. Comparator changes only internal PV dispatch to ordinary alpha-beta;
every root child remains full-window. No root pruning, TT, trace, policy, learned
ordering, declaration or unsupported terminal policy. Exact source-model counters
and packed PV are checked against installed raw search before causal comparison.
Scope local supported roots, no strength or deployment claim; expected<2min.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=ROOT/'.local_agent/terminal-frontier-20261010/native_fixed_work.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=dict')[0],ns)
from generic_chess.native.semantic import candidate_actions,make_checked,terminal_status,snapshot,evaluate,semantic_iterative_search
INF=1000000000;MATE=100000000
def model(board,max_depth,source_policy):
 counts=Counter();phases=Counter();start=perf_counter();last=None;iterations=[]
 def visit(pos,depth,alpha,beta,pv_node,ply):
  if counts['nodes']>=1000000 or perf_counter()-start>30:raise RuntimeError('declared fuse')
  counts['nodes']+=1;phases[f'{"pv" if pv_node else "nonpv"}_d{depth}']+=1
  status=terminal_status(board.native,pos)
  if status['status']!='ongoing':
   counts['terminals']+=1
   winner=status['winner'];side=snapshot(board.native,pos)['side']
   return (0 if winner is None else MATE-ply if winner==side else -MATE+ply),()
  if depth==0:
   counts['leaves']+=1
   return evaluate(board.native,pos,board_values=board.values,hand_values=board.values),()
  actions=candidate_actions(board.native,pos);counts['legal_generation_count']+=1
  found=False;best=-INF;best_action=0;best_pv=()
  for i,action in enumerate(actions):
   counts['candidate_attempts']+=1
   try:child=make_checked(board.native,pos,action)
   except ValueError:counts['illegal_skips']+=1;continue
   counts['transition_count']+=1
   child_pv=(True if ply==0 else pv_node and i==0) if source_policy else False
   full=ply==0 or source_policy and pv_node
   if full:counts['full_window_edges']+=1
   else:counts['inherited_window_edges']+=1
   branch,line=visit(child,depth-1,-INF if full else -beta,INF if full else -alpha,child_pv,ply+1)
   score=-branch
   if not found or score>best or score==best and action<best_action:
    found=True;best=score;best_action=action;best_pv=(action,*line)
   alpha=max(alpha,score)
   if alpha>=beta:counts['beta_cutoffs']+=1;break
  return (best if found else 0),best_pv
 for depth in range(1,max_depth+1):
  before=counts.copy();score,pv=visit(board.position,depth,-INF,INF,source_policy,0)
  iterations.append({'depth':depth,'score':score,'pv':pv,'counts':dict(counts-before)})
  last=(score,pv)
 return {'score':last[0],'principal_variation':last[1],'counts':dict(counts),'phases':dict(phases),'iterations':iterations,'wall_seconds':perf_counter()-start}
folder=Path(__file__).parent;out=folder/'native-schedule.json'
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'kernel_source_sha256':hashlib.sha256((ROOT/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),'rows':[],'complete':False}
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for name,factory,values in ns['ns']['factories'][3:]:
 core=factory();board=ns['NativeBoard'](core,values);assert not board.native.declarations
 for mode in ('source','fullroot_ab','kernel'):
  for flag in ('rollout','advisor','slack'):
   flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
  if mode=='kernel':
   start=perf_counter();r=semantic_iterative_search(board.native,board.position,3,max_nodes=1000000,max_time_seconds=30,board_values=board.values,hand_values=board.values,tt_megabytes=0,root_window_pruning=False);r['caller_seconds']=perf_counter()-start
  else:r=model(board,3,mode=='source')
  assert board.restored();report['rows'].append({'case':name,'mode':mode,'result':r});save()
  print(name,mode,r.get('nodes',r.get('counts',{}).get('nodes')),r['score'],flush=True)
 cell=report['rows'][-3:];source=cell[0]['result'];kernel=cell[2]['result']
 for key in ('nodes','beta_cutoffs','legal_generation_count','transition_count'):assert source['counts'].get(key,0)==kernel[key],(name,key,source['counts'].get(key),kernel[key])
 assert tuple(source['principal_variation'])==tuple(kernel['principal_variation']) and source['score']==kernel['score'],name
 assert kernel['tt_status']=='NOT_STARTED' and kernel['tt_allocated_bytes']==0
report['complete']=True;save()
