"""Existing real cancellation attribution, no extra timing workload.
Compare request latency to already recorded preparation/validation/search
intervals; token last poll timestamp exposes after-poll caller cleanup time.
Intervals alone do not establish exact semantic phase at request; no SLA.
"""
from pathlib import Path
import json,statistics,hashlib
folder=Path(__file__).parent;data=json.loads((folder/'cancel-assay.json').read_bytes())
rows=[]
for row in data['rows']:
 if row['backend']=='product':continue
 r=row['result'];validation=r['validation_seconds'];preparation=r['preparation_seconds'];request=row['actual_request_delay'];total=preparation+r['search_seconds']+validation
 rows.append({'case':row['case'],'mode':row['backend'],'delay':row['intended_delay'],'actual_request_seconds':request,'request_to_return_ms':1000*row['request_to_return_seconds'],'preparation_ms':1000*preparation,'validation_ms':1000*validation,'poll_gap_ms':1000*row['max_observed_poll_gap_seconds'],'validation_over_latency':validation/max(row['request_to_return_seconds'],1e-12),'result_completed_depth':r['completed_depth'],'request_during_preparation':request<preparation,'request_after_search':request>preparation+r['search_seconds']})
out={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'max_latency_rows':sorted(rows,key=lambda r:r['request_to_return_ms'],reverse=True)[:6]}
(folder/'cancel-attribution.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
print(json.dumps(out['max_latency_rows'],indent=2))
