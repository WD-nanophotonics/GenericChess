"""Independent finite-D3 selected-response checks on stored cold/warm Native.
Three existing roots xTT0/64 xcold/warm, use repeat0 saved routes only (12lines).
Root value baseline savedTT0; each selected reply audited against TT0 full-root
remaining horizon, max100000/10sec. Calls at ply>=2 use supported offset1 then
explicit mate-distance adjustment; depth0 uses actual terminal/material. No
external utility oracle increase, no hypothetical line stitched after interrupt.
Counts/caller cost retained; contract diagnostic of existing estimates, not
independent strength validation. Expected<1min, serial after cancellation run.
"""
from pathlib import Path
import json,hashlib
from time import perf_counter
folder=Path(__file__).parent;f=folder/'native_schedule.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
from generic_chess.native.semantic import public_action,semantic_iterative_search
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.native.mirror import pack_semantic_action
data=json.loads((folder/'replay-accounting.json').read_bytes());rows=[]
def action(value):
 if 'from_square' in value:
  return SemanticBoardMove(pattern_id=value['pattern_id'],geometry_id=value['geometry_id'],actor_type_id=value['actor_type_id'],from_square=Square(**value['from_square']),to_square=Square(**value['to_square']),promotion_target_id=value['promotion_target_id'])
 return SemanticDropMove(pattern_id=value['pattern_id'],geometry_id=value['geometry_id'],base_type_id=value['base_type_id'],to_square=Square(**value['to_square']))
for row in data['rows']:
 if row['repeat']!=0:continue
 name=row['case'];_,factory,values=next(c for c in ns['ns']['ns']['factories'][3:] if c[0]==name);core=factory();board=ns['ns']['NativeBoard'](core,values);r=row['result'];line=[action(a) for a in r['principal_variation']];queries=[];observations=[];start=perf_counter()
 def finite(left,ply):
  terminal=board.terminal(ply)
  if terminal is not None:
   return 0 if terminal==0 else (ns['MATE']-ply)*(1 if terminal>0 else -1)
  if left==0:return board.evaluate()
  result=semantic_iterative_search(board.native,board.position,left,max_nodes=100000,max_time_seconds=10,board_values=board.values,hand_values=board.values,_root_ply_offset=min(1,ply),tt_megabytes=0)
  assert result['completed_depth']==left and result['termination_reason']=='completed'
  score=result['score']
  if abs(score)>ns['MATE']//2:score+=(ply-min(1,ply))*(-1 if score>0 else 1)
  queries.append({'remaining':left,'ply':ply,'nodes':result['nodes'],'score':score})
  return score
 for ply,a in enumerate(line):
  raw=pack_semantic_action(board.native,core.runtime.position,a)
  optimal=next(z['result']['score'] for z in data['rows'] if z['case']==name and z['repeat']==0 and z['tt_mb']==0 and z['run']=='cold') if ply==0 else finite(3-ply,ply)
  # Public action packing uses full Core position, kept in step with Native.
  core.push(a);board.push(raw)
  selected=-finite(2-ply,ply+1)
  observations.append({'ply':ply,'remaining':3-ply,'optimal':optimal,'selected':selected,'matches':optimal==selected})
 for _ in line:board.pop();core.pop()
 assert board.restored() and core.restored()
 rows.append({'case':name,'tt_mb':row['tt_mb'],'run':row['run'],'reported_score':r['score'],'responses':observations,'queries':queries,'caller_seconds':perf_counter()-start})
out={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True}
(folder/'warm-pv-contract.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print([(r['case'],r['tt_mb'],r['run'],sum(not o['matches'] for o in r['responses'])) for r in rows])
