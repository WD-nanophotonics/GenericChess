"""Captured-frontier label functional controls, no adaptive timing budget.
Four existing roots xnode32/2048 x2reversed xreplay/captured=32serial calls,
maxD2/30sec fuse, live semantic budget. Search decisions/PVlabels/non-time work
must match for completed and fallback routes; retain independent replay default.
No speed/strength claim from skipped verification. Expected<1min.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;f=folder/'assay.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'label-fixed.json'
for name,factory,values in ns['factories']:
 for nodes in (32,2048):
  cell=[]
  for repeat,order in enumerate((('replay','captured'),('captured','replay'))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();core.semantic_checkpoint_supported=True;material=ns['Material']('chess');material.values=values;core.material=material
    r=ns['iterative_root_search'](core,seconds=30,node_limit=nodes,max_depth=2,cooperative=True,validate_pv=mode=='replay')
    assert core.restored();cell.append(r);report['rows'].append(ns['record_value']({'case':name,'repeat':repeat,'mode':mode,'cap_nodes':nodes,'result':r}));out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
  for r in cell:
   for key in ('move','score','pv_labels','completed_depth','used_fallback','work'):assert r[key]==cell[0][key],(name,nodes,key)
report['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print('32functional controls exact')
