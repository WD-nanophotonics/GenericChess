"""Summarize completed Agent outputs without rerunning experiments."""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent
def read(name):return json.loads((folder/name).read_bytes())
names=['assay','cancel-assay','owner-assay','native-schedule','native-time','core-window','core-fixed-d3','product-d3','product-factorial','core-window-cancel','replay-accounting','replay-model-verification','warm-pv-contract','native-cancel-accounting','native-cancel-tail','label-fixed','label-cancellation','runtime-pv-probe','runtime-cancel-probe']
summary={'scope':'Exposed development, serial existing roots. Kernel/model/Core work units distinct; no strength/default/C deployment claim.','datasets':{}}
for name in names:
 r=read(name+'.json');rows=r.get('rows',r.get('results',[]))
 summary['datasets'][name]={'rows':len(rows),'complete':r.get('complete'),'sha256':hashlib.sha256((folder/(name+'.json')).read_bytes()).hexdigest()}
rows=read('runtime-cancel-probe.json')['rows']
summary['runtime_validation_cancel']={mode:{'max_post_kernel_ms':max(r['post_kernel_ms'] for r in rows if r['mode']==mode),'mean_post_kernel_ms':sum(r['post_kernel_ms'] for r in rows if r['mode']==mode)/12,'max_request_to_public_ms':max(r['request_to_public_ms'] for r in rows if r['mode']==mode)} for mode in ('baseline','runtime')}
summary['decisions']={'adopt':'Native optional work counters; explicit Core semantic-budget diagnostic and searched-frontier label provenance. Product validation remains unchanged.','defer':'owner-only source index1.38-3.13% no timed depth gain; Core-runtime validation modest scoped tail reduction, lacks broad generated semantic controls; no product search replacement.','main':'NativeTT0/OFF canonical replay inactive; fullwindow dispatch source-model reproduced. Core product q0 TT/order D3~0.7sec outperforms plain AB6-7sec on generated roots.','phase':'Completed q0 only: replay entry calls=nodes-transition_count-root_iterations_attempted; cold64 subtree shares6.83/3.47/1.00%. Interrupted residuals include -1, unavailable not zero.','route':'4096 synthetic D4 tree internal tie errors59/213; strict interior improvement removes errors on scoped TT0/q0/complete controls, not all TT/interrupt contexts.'}
(folder/'final-summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
# Recover exact pre-audit-change source, verify against its immutable result pin.
source=(folder/'core_window.py').read_text(encoding='utf-8').replace('def audit_pv(board,result,skip_root=False):','def audit_pv(board,result):').replace('   if skip_root and ply==0:\n    board.push(action);pushed+=1;continue\n','')
assert hashlib.sha256(source.encode()).hexdigest()==read('core-window.json')['source_sha256']
(folder/'core_window-first-executed.py').write_bytes(source.encode())
print(json.dumps(summary,indent=2))
