"""Retain raw runs; derive only for the actual completed result spelling.
The first runner tested 'max_depth', but installed Native reports 'completed'.
All raw counters remain; no rerun, hidden zero or artificial phase tag.
Identity counts replay ENTRY calls, not descendant work/time or unique states.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;data=json.loads((folder/'replay-accounting.json').read_bytes());assert data['complete']
rows=[]
for row in data['rows']:
 r=row['result'];applicable=(r['completed_depth']==3 and r['termination_reason']=='completed' and not r['used_fallback'] and r['qnodes']==0 and r['transition_count'] is not None)
 replay=r['nodes']-r['transition_count']-r['root_iterations_attempted'] if applicable else None
 assert replay is None or replay>=0
 if row['tt_mb']==0:assert replay==0
 rows.append({'case':row['case'],'repeat':row['repeat'],'tt_mb':row['tt_mb'],'run':row['run'],'nodes':r['nodes'],'transitions':r['transition_count'],'root_entries':r['root_iterations_attempted'],'replay_entries':replay,'tt_status':r['tt_status'],'tt_bytes':r['tt_allocated_bytes'],'score':r['score'],'caller_seconds':row['caller_seconds'],'generation_count':r['legal_generation_count']})
out={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True}
(folder/'replay-derived.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
print([(r['case'],r['tt_mb'],r['run'],r['replay_entries']) for r in rows[::2]])
