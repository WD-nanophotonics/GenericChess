"""12instrumented actualNativecancel calls, distinguish C boundary/caller tail.
Same3roots/TT0,64/.01,.05; singleton C entry wrapper timestamps start/return,
no per-node instrumentation/callback/throttling. Actual tokenrequest clock and
public return measure post-kernel packing/PV validation. Expected<1min; no extra
threadwork, Cbuild, SLA or changed PV/evaluator contract. Run serial after24
uninstrumented cancellation controls; instrumented observations kept separate.
"""
from pathlib import Path
import json,hashlib,threading
from time import perf_counter
folder=Path(__file__).parent;f=folder/'native_cancel_accounting.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nrows=[]')[0],ns)
from generic_chess.native import _module
module=_module();original=module.semantic_engine_search;boundary={}
def measured(*args,**kwargs):
 boundary['start']=perf_counter()
 try:return original(*args,**kwargs)
 finally:boundary['returned']=perf_counter()
rows=[]
try:
 module.semantic_engine_search=measured
 for name,factory,values in ns['ns']['ns']['ns']['ns']['factories'][3:]:
  core=factory();board=ns['ns']['ns']['ns']['NativeBoard'](core,values);session=ns['ns']['GameSession'](core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
  for mb in (0,64):
   for delay in (.01,.05):
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ns['ns']['ns']['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    engine=ns['ns']['SemanticSearchEngine'](core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=mb);token=ns['Token']();timer=threading.Timer(delay,token.cancel);timer.daemon=True;start=perf_counter();timer.start()
    try:r=engine.search(session,ns['ns']['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0),token);end=perf_counter()
    finally:timer.cancel();timer.join()
    assert r.termination_reason=='cancelled' and board.restored() and session.state==core.initial
    rows.append({'case':name,'tt_mb':mb,'delay':delay,'completed_depth':r.completed_depth,'used_fallback':r.used_fallback,'actual_request_delay':token.requested-start,'pre_kernel_ms':1000*(boundary['start']-start),'request_to_kernel_return_ms':1000*(boundary['returned']-token.requested),'post_kernel_ms':1000*(end-boundary['returned']),'request_to_public_return_ms':1000*(end-token.requested),'kernel_search_seconds':r.elapsed_seconds})
finally:module.semantic_engine_search=original
out={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True}
(folder/'native-cancel-tail.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(sorted(rows,key=lambda r:r['request_to_public_return_ms'],reverse=True)[:3],indent=2))
