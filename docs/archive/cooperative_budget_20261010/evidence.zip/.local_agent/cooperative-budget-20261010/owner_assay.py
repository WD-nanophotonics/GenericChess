"""Single-owner pseudoattack source dispatch feasibility, 48serial calls.
Four existing roots middle/drop/generated2000/2001, before/prototype, two reversed
passes, fixed1024q2+60sec fuse and1/4sec+1million fuse,maxD12,TT/order cold.
No pattern/poll/path/guard change. Audit all root/D1 square/owner attacks plus
3974 full-state Native comparisons on existing EP/generated controls. Non-time
statistics/output/PV must agree under fixed cap; retain every timed difference.
No callback throttling, state cache, cohort/teacher growth or policy change.
Expected<5minutes; decision adopt simple index only if meaningful fixed benefit
and preserved transfer, otherwise archive negative, no additional framework.
Run after cooperative/cancel assays, never concurrent performance.
"""
from pathlib import Path
import json,sys,hashlib
from time import perf_counter
from dataclasses import asdict
from contextlib import nullcontext
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=Path(__file__).with_name('assay.py');ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
from owner_sources import active
from generic_chess.core.semantic_executor import SemanticEngine
from scripts.native_backend_bridge import NativeBoard,audit_native_tree
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
case=ns['CASES'][0];compiled=ns['compile_ruleset_for_execution'](ns['build_builtin_ruleset']('western_chess'))
factories=[('chess-middle',lambda:ns['CoreBoard'](case,compiled),ns['VALUES']['chess']),*ns['factories'][1:]]
folder=Path(__file__).parent;out=folder/'owner-assay.json'
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),prototype_sha256=hashlib.sha256((folder/'owner_sources.py').read_bytes()).hexdigest(),rows=[],audits=[],complete=False)
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for name,factory,values in factories:
 core=factory();positions=[core.runtime.position]
 for _,move in core.actions():core.push(move);positions.append(core.runtime.position);core.pop()
 engine=SemanticEngine(core.compiled)
 expected=[tuple(engine.is_square_attacked(p,s,o) for o in (0,1) for s in range(len(p.board))) for p in positions]
 with active():actual=[tuple(engine.is_square_attacked(p,s,o) for o in (0,1) for s in range(len(p.board))) for p in positions]
 assert actual==expected
 report['audits'].append(dict(case=name,all_square_attack_queries=sum(map(len,actual))));save()
 for seconds,nodes in ((60,1024),(1,1000000),(4,1000000)):
  for repeat,order in enumerate((('before','prototype'),('prototype','before'))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();material=ns['Material']('chess');material.values=values;stats=SearchStatistics();t=perf_counter()
    with active() if mode=='prototype' else nullcontext():
     action,score,pv,reason=run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=12,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=2,quiescence_hard_max_depth=12),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
    wall=perf_counter()-t;assert core.restored()
    report['rows'].append(ns['record_value'](dict(case=name,backend=mode,repeat=repeat,cap_seconds=seconds,cap_nodes=nodes,move=core.label(action),score=score,pv=[core.label(a) for a in pv],reason=reason,statistics=asdict(stats),caller_seconds=wall)));save()
    print(name,seconds,repeat,mode,round(wall,3),stats.completed_depth,flush=True)
 fixed=[r for r in report['rows'] if r['case']==name and r['cap_nodes']==1024]
 sig=lambda r:(r['move'],r['score'],r['pv'],r['reason'],{k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')})
 assert all(sig(r)==sig(fixed[0]) for r in fixed),name
for name,factory,values in ns['factories'][::1]:
 if name=='shogi-drop':continue
 core=factory()
 with active():states=audit_native_tree(core,NativeBoard(factory(),values),2)
 report['audits'].append(dict(case=name,full_state_audit=states));save()
report['complete']=True;save()
