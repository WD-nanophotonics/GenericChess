"""Real token cancellation: 4existing roots x2 delays x2reversed x3arms=48calls.
Thin node/semantic and supported product Coreq0 cold TT/order,1million/30sec
fuse,maxD12. Record actual timer request,request-return/maxpollgap; not an SLA.
Thin root preparation and validation explicit; cancellation is not awaited by
the caller after return. Timer only sets token flag, no search/writer/worker.
No performance overlap, run after72resource assay completes. Expected<1min.
"""
from pathlib import Path
import sys,json,hashlib,threading
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=Path(__file__).with_name('assay.py');ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
class Token(CancellationToken):
 def __init__(self):super().__init__();self.requested=None;self.last=None;self.max_gap=0;self.polls=0
 def cancel(self):self.requested=perf_counter();super().cancel()
 def is_cancelled(self):
  t=perf_counter()
  if self.last is not None:self.max_gap=max(self.max_gap,t-self.last)
  self.last=t;self.polls+=1;return super().is_cancelled()
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=Path(__file__).with_name('cancel-assay.json')
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for name,factory,values in ns['factories']:
 for delay in (.05,.15):
  for repeat,order in enumerate((('thin_node','thin_semantic','product'),('product','thin_semantic','thin_node'))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();core.semantic_checkpoint_supported=True;material=ns['Material']('chess');material.values=values;core.material=material
    token=Token();timer=threading.Timer(delay,token.cancel);timer.daemon=True;t=perf_counter();timer.start()
    try:
     if mode=='product':
      stats=SearchStatistics()
      action,score,pv,reason=run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0,quiescence_hard_max_depth=0),token,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
      r=dict(move=core.label(action),score=score,reason=reason,statistics=asdict(stats))
     else:r=ns['iterative_root_search'](core,seconds=30,node_limit=1000000,max_depth=12,cooperative=mode=='thin_semantic',cancellation=token)
     end=perf_counter()
    finally:timer.cancel();timer.join()
    assert core.restored() and token.requested is not None and r.get('reason',r.get('exit_cause'))=='cancelled'
    report['rows'].append(ns['record_value'](dict(case=name,backend=mode,repeat=repeat,intended_delay=delay,actual_request_delay=token.requested-t,request_to_return_seconds=end-token.requested,max_observed_poll_gap_seconds=token.max_gap,polls=token.polls,result=r)));save()
report['complete']=True;save()
print('actual cancellations',len(report['rows']))
