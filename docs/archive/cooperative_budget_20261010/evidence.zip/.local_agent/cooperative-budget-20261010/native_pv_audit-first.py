"""Audit stored source/fullroot AB selected routes, not another search/teacher.
Replay each D1-D3 PV against Native/fullhistory; compare terminal distance or
material leaf to stored score, root canonical packed action, and route length.
No inferred strategic gain from lower entries or a differing canonical PV.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;f=folder/'native_schedule.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
data=json.loads((folder/'native-schedule.json').read_bytes());rows=[]
for name,factory,values in ns['ns']['ns']['factories'][3:]:
 core=factory();board=ns['ns']['NativeBoard'](core,values)
 cell=[r for r in data['rows'] if r['case']==name]
 for source,alt in zip(cell[0]['result']['iterations'],cell[1]['result']['iterations']):
  observations=[]
  for mode,r in (('source',source),('fullroot_ab',alt)):
   for packed in r['pv']:board.push(packed)
   terminal=ns['terminal_status'](board.native,board.position);leaf=board.terminal(len(r['pv']))
   if leaf is not None and abs(leaf)>1000000:leaf=(ns['MATE']-len(r['pv']))*(1 if leaf>0 else -1)
   if leaf is None:leaf=board.evaluate()
   root_leaf=leaf*((-1)**len(r['pv']))
   observations.append({'mode':mode,'depth':r['depth'],'score':r['score'],'root_oriented_leaf':root_leaf,'matches_leaf':r['score']==root_leaf,'pv_length':len(r['pv']),'terminal':terminal,'labels':[board.label(ns['ns']['public_action'](board.native,a)) for a in r['pv']]})
   for _ in r['pv']:board.pop()
   assert board.restored()
  rows.append({'case':name,'depth':source['depth'],'same_root':source['pv'][:1]==alt['pv'][:1],'same_pv':source['pv']==alt['pv'],'observations':observations})
out={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True}
(folder/'native-pv-audit.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
print([(r['case'],r['depth'],r['same_pv'],[o['matches_leaf'] for o in r['observations']]) for r in rows])
