from pathlib import Path
import json,hashlib
from dataclasses import asdict
folder=Path(__file__).parent;f=folder/'native_schedule.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
from generic_chess.native.semantic import public_action
models=json.loads((folder/'replay-model.json').read_bytes());actual=json.loads((folder/'replay-accounting.json').read_bytes());rows=[]
for row in models['rows']:
 name=row['case'];_,factory,values=next(c for c in ns['ns']['ns']['factories'][3:] if c[0]==name);board=ns['ns']['NativeBoard'](factory(),values)
 r=row['result'];pv=[asdict(public_action(board.native,packed)) for packed in r['principal_variation']]
 for raw in actual['rows']:
  if raw['case']!=name or raw['tt_mb']!=64 or raw['run']!='cold':continue
  a=raw['result']
  for key in ('nodes','beta_cutoffs','legal_generation_count','transition_count'):assert a[key]==r['counts'][key],(name,key)
  assert a['score']==r['score'] and a['principal_variation']==pv and a['tt_cutoffs']==0,name
  rows.append({'case':name,'repeat':raw['repeat'],'exact_counters_score_pv':True,'main_entries':r['counts']['main_entries'],'replay_subtree_entries':r['counts']['replay_subtree_entries'],'replay_entry_calls':r['counts']['replay_entry_calls'],'replay_fraction':r['counts']['replay_subtree_entries']/r['counts']['nodes']})
out={'scope':'Source-model phasepartition validated against six real cold64D3results/counters/PVs withTTcutoffs0;not a universal warmTTphase model. Callgraphentryidentity only countsreplaycalls forcompletedq0.', 'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True}
(folder/'replay-model-verification.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(rows)
