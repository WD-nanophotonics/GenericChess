"""Changed premise: strict interior ties, canonical full-window root ties.
Same4096synthetictrees/seed and three existing NativeD3 roots; no new teacher,
rules, timing or default change. Preserve rootvalue/action; inspect selected
interior exact policy and actual work before proposing an approved C repair.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent
f=folder/'pv_bound_probe.py';ns={'__file__':str(f)}
source=f.read_text(encoding='utf-8').split('\nreport=')[0]
source=source.replace('value==best and action<best_action','value==best and ply==0 and action<best_action')
exec(source,ns)
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'synthetic':{},'native':[]}
for mode in ('source','fullroot_ab'):
 rng=ns['Random'](202610101003);ns['rng']=rng;counts={'wrong_root':0,'wrong_root_action':0,'wrong_leaf':0,'suboptimal_continuation':0}
 for index in range(4096):
  tree=ns['make'](4);value,pv=ns['exact'](tree);score,line=ns['search'](tree,mode=='source',mode=='source')
  counts['wrong_root']+=value!=score;counts['wrong_root_action']+=pv[:1]!=line[:1];counts['wrong_leaf']+=ns['leaf'](tree,line)!=score;counts['suboptimal_continuation']+=bool(ns['policy_errors'](tree,line))
 report['synthetic'][mode]=counts
f=folder/'native_schedule.py';native={'__file__':str(f)}
source=f.read_text(encoding='utf-8').split('\nfolder=')[0].replace('score==best and action<best_action','score==best and ply==0 and action<best_action')
exec(source,native)
(folder/'native_strict_model.py').write_bytes(source.encode())
for name,factory,values in native['ns']['ns']['factories'][3:]:
 core=factory();board=native['ns']['NativeBoard'](core,values)
 for mode in ('source','fullroot_ab'):
  r=native['model'](board,3,mode=='source');assert board.restored()
  report['native'].append({'case':name,'mode':mode,'result':r})
report['complete']=True
(folder/'pv-strict-probe.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(report['synthetic']);print([(r['case'],r['mode'],r['result']['counts']['nodes'],r['result']['score']) for r in report['native']])
