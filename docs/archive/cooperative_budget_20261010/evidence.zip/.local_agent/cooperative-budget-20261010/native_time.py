"""36 serial equal-resource schedule-model calls on three existing roots.
Source/native model versus ordinary internal AB, same Native candidate order,
packed tie/full root/history/terminal/material and identical Python instrument.
1/4second+1million fuse and4096nodes+30sec fuse; two reversed passes,maxD12.
Node-only callback cannot interrupt a Native primitive. Partial iterations never
replace last complete decision; no utility teacher expansion or C-speed claim.
Question: does isolated expansion reduction change completion under this caller?
Expected<2min, follow fixed-counter verification, no timing overlap.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;f=folder/'native_schedule.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
source=f.read_text(encoding='utf-8').split('\nfolder=')[0]
source=source.replace('def model(board,max_depth,source_policy):','def timed_model(board,max_depth,source_policy,seconds,node_limit):').replace("counts['nodes']>=1000000 or perf_counter()-start>30","counts['nodes']>=node_limit or perf_counter()-start>seconds")
source=source.replace('before=counts.copy();score,pv=visit(board.position,depth,-INF,INF,source_policy,0)',"before=counts.copy()\n  try:score,pv=visit(board.position,depth,-INF,INF,source_policy,0)\n  except RuntimeError as exc:\n   if str(exc)!='declared fuse':raise\n   break")
source=source.replace("return {'score':last[0],'principal_variation':last[1]", "return {'score':None if last is None else last[0],'principal_variation':() if last is None else last[1],'completed_depth':iterations[-1]['depth'] if iterations else 0")
exec(source,ns)
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'executed_model_sha256':hashlib.sha256(source.encode()).hexdigest(),'rows':[],'complete':False}
(folder/'native_time_model.py').write_bytes(source.encode())
out=folder/'native-time.json'
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for name,factory,values in ns['ns']['ns']['factories'][3:]:
 for seconds,nodes in ((30,4096),(1,1000000),(4,1000000)):
  for repeat,order in enumerate((('source','fullroot_ab'),('fullroot_ab','source'))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();board=ns['ns']['NativeBoard'](core,values)
    r=ns['timed_model'](board,12,mode=='source',seconds,nodes);assert board.restored()
    report['rows'].append({'case':name,'mode':mode,'repeat':repeat,'cap_seconds':seconds,'cap_nodes':nodes,'result':r});save()
    print(name,seconds,mode,r['completed_depth'],round(r['wall_seconds'],3),flush=True)
report['complete']=True;save()
