"""Four complete-D3 controls with phase costs after timed-depth negative.
Same two roots/arms/material/semantic node-cancel-time/fullhistory/root contract.
60sec+100000entry fuse each, one reversed case order. No claim that fewer entries
must be faster: count terminal/material/expanded work by remaining depth and
internal polling to explain reached-prefix differences. Only completedD3 can
support same-horizon cost comparison. Independent remaining<=D2 PV suffix checks
plus rootvalue agreement, not a new utility teacher/cohort. Expected<3min.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;f=folder/'core_window.py';ns={'__file__':str(f)}
source=f.read_text(encoding='utf-8').split('\nfolder=')[0]
source=source.replace("check();counts['nodes']+=1", "check();counts['nodes']+=1;counts[f'entries_remaining_{depth}']+=1")
source=source.replace("if terminal is not None:return terminal,(),()", "if terminal is not None:counts['terminals']+=1;return terminal,(),()")
source=source.replace("if depth==0:return board.evaluate(),(),()", "if depth==0:counts['material_leaves']+=1;return board.evaluate(),(),()")
exec(source,ns)
(folder/'core_phase_model.py').write_bytes(source.encode())
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'core-fixed-d3.json'
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for i,(name,factory,values) in enumerate(ns['ns']['factories'][2:]):
 for mode in (('source','fullroot_ab') if i==0 else ('fullroot_ab','source')):
  for flag in ('rollout','advisor','slack'):
   flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
  core=factory();material=ns['ns']['Material']('chess');material.values=values;core.material=material
  r=ns['model'](core,mode=='source',60,100000,3)
  report['rows'].append(ns['ns']['record_value']({'case':name,'mode':mode,'result':r,'suffix_audit':None}));save()
  audit=None
  if r['completed_depth']==3:
   audit=ns['audit_pv'](core,r,skip_root=True)
   assert core.restored()
  report['rows'][-1]['suffix_audit']=audit;save()
  print(name,mode,r['completed_depth'],r['counts'],round(r['caller_seconds'],3),flush=True)
report['complete']=True;save()
