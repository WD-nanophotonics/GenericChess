"""32actualcancels paired on caller replay/captured frontier labels.
Four existing roots xdelay.05/.15 x2reversed x2modes; identical thin cooperative
search/maxD12/1million/30sec, no product/API/default change. Captured labels came
from legally searched frontiers; this mode explicitly omits independent post-
search replay and is NOT an independent route witness. Live semantic polling,
actual timer request and complete-iteration contract retained. Timer sets flag
only. Expected<1min, strictly serial after Nativephase runs.
"""
from pathlib import Path
import json,hashlib,threading
from time import perf_counter
folder=Path(__file__).parent;f=folder/'cancel_assay.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=dict')[0],ns)
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'label-cancellation.json'
for name,factory,values in ns['ns']['factories']:
 for delay in (.05,.15):
  for repeat,order in enumerate((('replay','captured'),('captured','replay'))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();core.semantic_checkpoint_supported=True;material=ns['ns']['Material']('chess');material.values=values;core.material=material
    token=ns['Token']();timer=threading.Timer(delay,token.cancel);timer.daemon=True;start=perf_counter();timer.start()
    try:r=ns['ns']['iterative_root_search'](core,seconds=30,node_limit=1000000,max_depth=12,cooperative=True,cancellation=token,validate_pv=mode=='replay');end=perf_counter()
    finally:timer.cancel();timer.join()
    assert core.restored() and token.requested is not None and r['exit_cause']=='cancelled'
    report['rows'].append(ns['ns']['record_value']({'case':name,'mode':mode,'repeat':repeat,'intended_delay':delay,'actual_request_delay':token.requested-start,'request_to_return_seconds':end-token.requested,'max_poll_gap_seconds':token.max_gap,'result':r}));out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
report['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
print([(mode,max(r['request_to_return_seconds'] for r in report['rows'] if r['mode']==mode)*1000) for mode in ('replay','captured')])
