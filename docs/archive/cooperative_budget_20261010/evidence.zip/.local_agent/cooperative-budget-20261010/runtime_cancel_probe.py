"""24 serial actual-cancel controls: existing three roots, TT0/64, .05sec,
two reversed baseline/Core-runtime validation pairs. Preserve both Core and
Native legality checks. Same kernel limits; measure C return and caller tail.
Decision: adopt only if retained state/illegal-route checks and material tail
reduction justify the small caller repair. No C build or budget weakening.
"""
from pathlib import Path
import json,hashlib,threading
from time import perf_counter
from contextlib import nullcontext
folder=Path(__file__).parent
f=folder/'runtime_pv_probe.py'; ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
f=folder/'native_cancel_accounting.py'; cs={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nrows=[]')[0],cs)
from generic_chess.native import _module
module=_module(); original=module.semantic_engine_search; boundary={}
def measured(*args,**kwargs):
 try:return original(*args,**kwargs)
 finally:boundary['returned']=perf_counter()
report={'declaration':__doc__,'rows':[],'complete':False,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
try:
 module.semantic_engine_search=measured
 for name,factory,values in ns['ns']['ns']['ns']['ns']['factories'][3:]:
  for mb in (0,64):
   for repeat,order in enumerate((('baseline','runtime'),('runtime','baseline'))):
    for mode in order:
     core=factory();board=ns['ns']['ns']['ns']['NativeBoard'](core,values);session=ns['ns']['GameSession'](core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
     engine=ns['module'].SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=mb)
     token=cs['Token']();timer=threading.Timer(.05,token.cancel);timer.daemon=True;start=perf_counter();timer.start()
     try:
      with ns['active']() if mode=='runtime' else nullcontext():r=engine.search(session,ns['ns']['SearchLimits'](max_depth=12,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0),token)
      end=perf_counter()
     finally:timer.cancel();timer.join()
     assert r.termination_reason=='cancelled' and session.state==core.initial and board.restored()
     report['rows'].append({'case':name,'tt_mb':mb,'repeat':repeat,'mode':mode,'completed_depth':r.completed_depth,'post_kernel_ms':1000*(end-boundary['returned']),'request_to_public_ms':1000*(end-token.requested)})
finally:module.semantic_engine_search=original
report['complete']=True;(folder/'runtime-cancel-probe.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
for mode in ('baseline','runtime'):
 rows=[r for r in report['rows'] if r['mode']==mode]
 print(mode,'max tail',max(r['post_kernel_ms'] for r in rows),'mean tail',sum(r['post_kernel_ms'] for r in rows)/len(rows),'max cancel',max(r['request_to_public_ms'] for r in rows))
