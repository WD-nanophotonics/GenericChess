# Cooperative budgets and scheduling, 2026-10-10

Question: after preserving live semantic budgets, does simpler scheduling improve
useful completion enough to displace the current product? Existing exposed roots,
material/q0/fullhistory, finite local controls; no extra games or label fitting.

## Resource fairness

72 serial fixed2048/1second/4second comparisons with two reversed passes show
internal checks matter. EP4second thin D4 becomes D3, Shogi-drop1second D2 becomes
D1, generated2001 1second D3 becomes D2. Product node/TT/order units differ;
these are mechanism controls, not strength rates.48 actual cancels unwind roots;
observed max thin-semantic6.414ms/product1.378ms, not a future guarantee.
Preparation and postsearch validation are explicit remaining unpolled boundaries.

## Window mechanism

Installed v4 TT0/rootOFF has no selected-PV canonical replay. Exact Python source
model matches9D1-D3 counters/score/packedPV. Keeping full-window root children,
ordinary interior AB changes cumulative nodes25824->8710,41620->8163,
68505->9552.36 model equal-resource controls show deeper completion on some
1/4second cells; this is Python model throughput, not modified-C deployment.

4096 seeded synthetic D4 trees show59/213 internally suboptimal response lines
with correct root/action/leaf values when equal bound scores replace PVs.
Strict interior improvement removes these scoped errors, preserving root ties.
It is not a general TT/interruption/exact-PV guarantee.32 matched Core controls
plus4D3 calls retain selected-response checks and fixed savings.1/4second depths
remain D2, a negative completion result. On generated2000/2001 source D3 takes
16.393/24.637seconds versus ordinary AB5.976/6.842seconds. Configured product
Core takes0.70/0.69seconds, about1700/1597nodes: retain current product.
Its TT/order/root scheduling differ. A subsequent16-call product-only coldD3
factorial isolates TT/order under unchanged product windows and checks. With
both OFF, generated2000/2001 still take0.88-0.89/0.97-0.98seconds,1353/2040
nodes. OrderingON/TT0 takes0.71/0.90seconds,1700/1912nodes. TT plus ordering
takes0.72-0.75/0.70seconds,1700/1597nodes. TT without ordering changes no node
count on these roots. Scores agree. Thus TT/order alone do not explain the plain
full-root model gap; root shared-window scheduling is the next concrete suspect,
and ordering can be faster despite more node visits. No equal-time gain follows.

## Phase accounting

Raw generation/transition counters now pass through high-level Native results;
availability is optional. Search-loop work is cumulative, not unique positions,
all nested terminal generation or caller validation. Completed q0 callgraph
identity: replay entries=nodes-transition_count-root_iterations_attempted.
24 cold/warm observations agree with applicability; TT0 has no replay. Cold64
source models match6actual results, all four counters/score/PV with zero TT
cutoffs. Replay subtrees1894/27718,1496/43116,689/69194 are6.83/3.47/1.00%.
Warm64 thousands of cutoffs preclude inheriting that subtree model.12stored
cold/warm PV audits agree on sampled responses; older horizon-mixing failures
remain.24actual interruptions produce residuals including-1: do not derive a
replay count there, clamp it or treat unavailable as zero.

## Caller costs and decisions

32 fixed captured-label controls retain output/non-time work.32real cancels have
max default replay6.765ms versus captured0.502ms. Capture is explicit diagnostic
provenance, not an independent replay witness; replay stays default.
12Native boundary calls locate most observed cancellation tail after C returns.
24coldD3 validation prototypes retain results and full Core states; both reject
a counterfeit repeated move.24actual paired cancels reduce mean caller tail
7.869->6.477ms, max14.538->8.929ms. Defer product Runtime validation: narrow
semantics and modest benefit do not yet justify broad integration; no check is
removed.48owner-source controls save1.38-3.13% with unchanged timed depths;
defer. No C rebuild, UI propagation, security bypass or workflow change.

Dot's complete reply supports matched semantic budgets and route contracts,
not independent execution. We applied those checks, then retained product based
on contrary practical evidence. Failed harnesses, exact source models and all
adverse/capped rows remain in the purpose archive. Next inspect root shared-window
and canonical contender verification costs under the same checks.

## Shared-root bridge

Four final live-budget shared-window diagnostic D3 calls include canonical
contender verification and independent legal PV replay. Generated2000/2001
retain scores999999997/999999999,2027/2112entries,caller0.94-0.97/1.16-1.17sec.
The plain full-root AB6-7sec cost largely disappears under shared root bounds.
Remaining product advantage is narrower and still mixes frontier/order/runtime
details, not established causal throughput or strength. Product-only factorial
records zero PVS/aspiration/mate-pruning cutoffs; those features were OFF.
Source inspection confirms product uses shared alpha and strict best replacement;
the bridge adds canonical contender verification. PV legal replay establishes
legality, not independent optimality at every interior response.
