"""Declared cooperative-budget attribution, 72 serial calls.
Existing EP, Shogi-drop and generated2000/2001 roots; thin node-boundary checks,
thin Core internal checks, installed product Core q0/TT/order/root-tacticsOFF.
2048entries+60sec fuse,1/4seconds+1million fuse,maxD12,two reversed passes.
Same material/history/rules; product node/order/TT/PV semantics remain distinct.
Semantic polling includes live node/cancel/time. Initial thin root frontier and
external PV validation still lack internal polling: preparation time is included,
validation separately measured; do not claim complete product response parity.
Fixed outputs may differ at partial-cap boundaries; report them, not a failure
of full-depth semantics. No new oracle, price fit or default search replacement.
Question: does the thin timing advantage disappear after internal Core checks?
Projected<6min; each call bounded and stop flags checked. No parallel timing.
"""
from pathlib import Path
import json,sys,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
from scripts.search_backend_comparison import CoreBoard,CASES,VALUES,Material,supported_search
from scripts.bounded_root_scheduler import iterative_root_search
from scripts.research_record import record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
case=CASES[7];compiled=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'))
factories=[ns['factories'][3],('shogi-drop',lambda:CoreBoard(case,compiled),VALUES['shogi']),*ns['factories'][4:]]
folder=Path(__file__).parent;out=folder/'assay.json'
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
start=perf_counter()
try:
 for name,factory,values in factories:
  for seconds,nodes in ((60,2048),(1,1000000),(4,1000000)):
   modes=['thin_node','thin_semantic','product']
   for repeat,order in enumerate((modes,list(reversed(modes)))):
    for mode in order:
     for flag in ('rollout','advisor','slack'):
      flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
     core=factory();material=Material('chess');material.values=values;core.material=material
     if mode=='product':
      result=supported_search(core,12,seconds,nodes);result['completed_depth']=result['statistics']['completed_depth'];result['caller_seconds']=result['wall_seconds']
     else:result=iterative_root_search(core,seconds=seconds,node_limit=nodes,max_depth=12,cooperative=mode=='thin_semantic')
     assert core.restored()
     report['rows'].append(record_value(dict(case=name,backend=mode,repeat=repeat,cap_seconds=seconds,cap_nodes=nodes,result=result)));save()
     print(name,seconds,repeat,mode,result['completed_depth'],round(result['caller_seconds'],3),flush=True)
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
