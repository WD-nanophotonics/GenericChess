"""Agent-authored evidence only, exact bytes; no transport, secrets or binaries."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[2];folder=Path(__file__).parent
paths=[p for p in folder.iterdir() if p.is_file() and p.suffix in ('.py','.json','.md') and p.name!='finalize_notes.py']
extra=['.local_agent/native-terminal-20261010/syntax_ablation.py','.local_agent/native-terminal-20261010/bridge_assay.py','.local_agent/generated6-20261008/coverage.json','scripts/bounded_root_scheduler.py','scripts/root_bound_diagnostic.py','scripts/native_backend_bridge.py','scripts/search_backend_comparison.py','scripts/research_record.py','generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/statistics.py','generic_chess/ai/alphabeta/native_legality.py','generic_chess/core/semantic_executor.py','generic_chess/core/search_runtime.py','generic_chess/core/transition.py','generic_chess/core/identity.py','generic_chess/native/semantic_engine.py','generic_chess/native/semantic.py','generic_chess/native/compiler.py','generic_chess/_native/native_module.c','tests/product/test_search_semantic_checkpoint.py','tests/development/test_diagnostic_semantic_budget.py','tests/development/test_bounded_root_scheduler.py','tests/development/test_root_bound_diagnostic.py','tests/development/test_native_backend_bridge.py']
paths += [ROOT/p for p in extra]
assert all(p.is_file() and '/slack/' not in p.as_posix() and p.name!='dot-question.txt' for p in paths)
target=ROOT/'docs/archive/cooperative_budget_20261010/evidence.zip';target.parent.mkdir(parents=True,exist_ok=True);members={}
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p in sorted(set(paths)):
  data=p.read_bytes();name=p.relative_to(ROOT).as_posix();members[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};archive.writestr(name,data)
with zipfile.ZipFile(target) as archive:
 assert len(archive.namelist())==len(members)
 for name,meta in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==meta['sha256']
index={'schema':1,'base_commit':'5ddb9d990fae68bfeb5d296da6fe285a87c585e2','scope':'Agent-authored exposed development; exact executed models/failures and final source closure. No raw Slack/account/outgoing/user-private records or binaries. See failures.md for staged diagnostic source limitation.','archive':target.relative_to(ROOT).as_posix(),'archive_bytes':target.stat().st_size,'archive_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'members':members,'summary':json.loads((folder/'final-summary.json').read_bytes()),'validation':'37 focused tests passed, publisher repeats relevant targets; counter fields verified against installed kernel.','dependencies':'Other imports recoverable from base commit; scoped local evidence dependencies bundled. Final C blocked/restored and no build retry.'}
(ROOT/'docs/research/data/cooperative_budget_20261010.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
print(len(members),target.stat().st_size,index['archive_sha256'])
