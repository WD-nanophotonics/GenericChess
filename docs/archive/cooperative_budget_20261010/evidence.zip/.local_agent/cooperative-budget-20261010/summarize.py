from pathlib import Path
import json,statistics
folder=Path(__file__).parent
summary={}
for filename in ('assay','cancel-assay','owner-assay'):
 data=json.loads((folder/f'{filename}.json').read_bytes());assert data['complete']
 rows=data['rows'];result={'count':len(rows)}
 if filename=='cancel-assay':
  result['arms']={arm:{'max_return_ms':1000*max(r['request_to_return_seconds'] for r in rows if r['backend']==arm),'max_poll_gap_ms':1000*max(r['max_observed_poll_gap_seconds'] for r in rows if r['backend']==arm),'median_polls':statistics.median(r['polls'] for r in rows if r['backend']==arm)} for arm in {r['backend'] for r in rows}}
 else:
  groups=[]
  for case in dict.fromkeys(r['case'] for r in rows):
   for cap in dict.fromkeys(r['cap_seconds'] for r in rows):
    cell=[r for r in rows if r['case']==case and r['cap_seconds']==cap]
    arms={}
    for arm in dict.fromkeys(r['backend'] for r in cell):
     selected=[r for r in cell if r['backend']==arm]
     arms[arm]={'seconds':[r.get('caller_seconds',r.get('result',{}).get('caller_seconds')) for r in selected],'depth':[r.get('statistics',{}).get('completed_depth',r.get('result',{}).get('completed_depth')) for r in selected],'move':[r.get('move',r.get('result',{}).get('move')) for r in selected]}
    groups.append({'case':case,'cap_seconds':cap,'arms':arms})
  result['groups']=groups
  if filename=='owner-assay':result['audits']=data['audits']
 summary[filename]=result
(folder/'summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(summary['cancel-assay'],indent=2))
for g in summary['owner-assay']['groups']:
 if g['cap_seconds']==60:
  a=g['arms'];before=statistics.mean(a['before']['seconds']);after=statistics.mean(a['prototype']['seconds']);print(g['case'],round(100*(before-after)/before,3),'%')
