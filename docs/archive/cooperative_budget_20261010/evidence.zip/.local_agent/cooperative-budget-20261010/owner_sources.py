"""Owner-only source index for a single pseudoattack query, no state cache.
Current helper builds both owners' tuple keys even when only one is queried.
Prototype indexes the requested owner by type, preserving board/source order.
Every existing semantic poll/path/guard stays. Candidate generation is untouched.
Bounded feasibility only; source helper's profile share limits possible benefit.
"""
from contextlib import contextmanager
import inspect,textwrap
import generic_chess.core.semantic_executor as executor
original=executor.SemanticEngine.is_square_attacked
source=textwrap.dedent(inspect.getsource(original))
first='sources_by_owner_type = _sources_by_owner_type(position)'
second='sources_by_owner_type.get((by_owner, tid), ())'
assert source.count(first)==1 and source.count(second)==1
template=source.replace(first,'sources_by_owner_type = _owner_sources(position, by_owner)').replace(second,'sources_by_owner_type.get(tid, ())')
def _owner_sources(position,owner):
 indexed={}
 for source,piece in enumerate(position.board):
  if piece is not None and piece.owner==owner:
   indexed.setdefault(piece.current_type_id,[]).append((source,piece))
 return {key:tuple(value) for key,value in indexed.items()}
@contextmanager
def active():
 namespace=dict(executor.__dict__,_owner_sources=_owner_sources)
 exec(template,namespace)
 saved=executor.SemanticEngine.is_square_attacked
 executor.SemanticEngine.is_square_attacked=namespace['is_square_attacked']
 try:yield
 finally:executor.SemanticEngine.is_square_attacked=saved
