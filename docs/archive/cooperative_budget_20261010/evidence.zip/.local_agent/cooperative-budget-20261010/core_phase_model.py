"""Core same-interface window comparison with live semantic budgets.
Existing generated2000/2001, two arms only internal PV/full-window dispatch.
Both root children fullwindow; lexical legal-frontier order/canonical root tie,
strict interior tie, full history/material/q0/noTT. Every semantic poll dispatches
node/cancel/time. Root preparation timed but unpolled, matching diagnostic scope.
D2 with60sec/100000 fuse,512entry+30sec fuse,1/4sec+1million fuse; two reversed
passes =32 calls. Independent fullwidth remaining-horizon PV checks only on D2
completed fixed controls, with cost recorded separately. This is route-contract
diagnosis, not enlarged utility oracle. MaxD12, no newrules/training/Cbuild.
Expected<4min; CPU serial, each call interruptible, no product replacement.
"""
from pathlib import Path
import json,sys,hashlib
from time import perf_counter
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=Path(__file__).with_name('assay.py');ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
INF=10**12
class Exhausted(Exception):pass
def model(board,source_policy,seconds,nodes,max_depth=12,token=None):
 counts=Counter();iterations=[];start=perf_counter();exit_cause='max_depth'
 previous=getattr(board,'checkpoint',None)
 def check():
  if counts['nodes']>=nodes:raise Exhausted('node_budget')
  if token is not None and token.is_cancelled():raise Exhausted('cancelled')
  if perf_counter()-start>=seconds:raise Exhausted('time_limit')
 def checkpoint():counts['semantic_polls']+=1;check()
 def visit(depth,alpha,beta,pv_node,ply):
  check();counts['nodes']+=1;counts[f'entries_remaining_{depth}']+=1
  terminal=board.terminal(ply)
  if terminal is not None:counts['terminals']+=1;return terminal,(),()
  if depth==0:counts['material_leaves']+=1;return board.evaluate(),(),()
  counts['legal_queries']+=1;frontier=board.actions();best=-INF;line=();labels=();best_key=None
  for i,(label,action) in enumerate(frontier):
   board.push(action);counts['pushes']+=1
   full=ply==0 or source_policy and pv_node
   child_pv=(True if ply==0 else pv_node and i==0) if source_policy else False
   try:branch,child_line,child_labels=visit(depth-1,-INF if full else -beta,INF if full else -alpha,child_pv,ply+1)
   finally:board.pop()
   score=-branch
   if score>best or ply==0 and score==best and (best_key is None or label<best_key):best=score;best_key=label;line=(action,*child_line);labels=(label,*child_labels)
   alpha=max(alpha,score)
   if alpha>=beta:counts['cutoffs']+=1;break
  if not frontier:raise AssertionError('nonterminal empty legal frontier')
  return best,line,labels
 try:
  terminal=board.terminal(0);frontier=board.actions();preparation=perf_counter()-start
  if terminal is not None:return {'terminal':terminal,'nodes':0,'caller_seconds':preparation,'completed_depth':0}
  board.checkpoint=checkpoint
  try:
   for depth in range(1,max_depth+1):
    score,pv,labels=visit(depth,-INF,INF,source_policy,0);iterations.append({'depth':depth,'score':score,'pv':pv,'labels':labels})
  except Exhausted as exc:exit_cause=str(exc)
 finally:board.checkpoint=previous
 end=perf_counter();assert board.restored()
 last=iterations[-1] if iterations else {'score':None,'pv':(frontier[0][1],),'labels':(frontier[0][0],),'depth':0}
 return {'score':last['score'],'pv':last['pv'],'pv_labels':last['labels'],'completed_depth':last['depth'],'iterations':iterations,'counts':dict(counts),'preparation_seconds':preparation,'caller_seconds':end-start,'exit_cause':exit_cause,'root_restored':True}
def audit_pv(board,result,skip_root=False):
 """Independent fullwidth oracle of only this returned short route."""
 start=perf_counter();counts=Counter();rows=[];pushed=0
 def full(left,ply):
  counts['nodes']+=1;terminal=board.terminal(ply)
  if terminal is not None:return terminal
  if not left:return board.evaluate()
  values=[]
  for _,action in board.actions():
   board.push(action);counts['pushes']+=1
   try:values.append(-full(left-1,ply+1))
   finally:board.pop()
  assert values;return max(values)
 try:
  for ply,action in enumerate(result['pv']):
   if skip_root and ply==0:
    board.push(action);pushed+=1;continue
   left=result['completed_depth']-ply;optimal=full(left,ply)
   board.push(action);pushed+=1;selected=-full(left-1,ply+1)
   rows.append({'ply':ply,'remaining_depth':left,'optimal':optimal,'selected':selected,'matches':selected==optimal})
 finally:
  for _ in range(pushed):board.pop()
 assert board.restored()
 return {'rows':rows,'counts':dict(counts),'caller_seconds':perf_counter()-start}