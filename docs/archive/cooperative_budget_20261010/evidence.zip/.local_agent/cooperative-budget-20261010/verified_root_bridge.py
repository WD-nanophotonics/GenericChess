"""Four real Core D3 shared-window diagnostic controls, existing two roots.
Use shipped verified-contender diagnostic and live node/cancel/time semantic
polls, independent PV replay included in caller wall. Lexical frontiers, noTT,
q0/material/fullhistory,100000nodes/60second fuse, two reversed root passes.
Question: how much full-root plain cost disappears after shared-root bounds
with canonical contender verification? Not a product replacement or new oracle.
Expected<1min; serial after product factorial and consumer tests.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;f=folder/'assay.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
rows=[]
for repeat,order in enumerate((ns['factories'][2:],list(reversed(ns['factories'][2:])))):
 for name,factory,values in order:
  for flag in ('rollout','advisor','slack'):
   flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
  core=factory();core.semantic_checkpoint_supported=True;material=ns['Material']('chess');material.values=values;core.material=material
  r=ns['iterative_root_search'](core,seconds=60,node_limit=100000,max_depth=3,cooperative=True)
  assert r['completed_depth']==3 and core.restored()
  rows.append(ns['record_value']({'case':name,'repeat':repeat,'result':r}));print(name,r['work']['nodes'],round(r['caller_seconds'],3),r['score'],flush=True)
out={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True};(folder/'verified-root-bridge.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
