"""Isolated canonical-replay mechanism in verified source model, no TT lookup.
Three existingD3roots; enable only selected-PV replay condition, retain order,
fullwindow dispatch/history/material. Record actual replay-subtree entries vs
replay entry calls. TT64's real scheduling/cache effects are not this control.
No deployment, syntheticC build or trace. Saved TT0 baseline stays unchanged.
30sec/1million fuse, expected<1min, strictly serial.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;f=folder/'native_schedule.py';ns={'__file__':str(f)}
source=f.read_text(encoding='utf-8').split('\nfolder=')[0]
source=source.replace('def visit(pos,depth,alpha,beta,pv_node,ply):','def visit(pos,depth,alpha,beta,pv_node,ply,pv_replay=False):')
source=source.replace("counts['nodes']+=1;phases", "counts['nodes']+=1\n  counts['replay_subtree_entries' if pv_replay else 'main_entries']+=1\n  phases")
source=source.replace('child_pv,ply+1)','child_pv,ply+1,pv_replay)')
source=source.replace("return (best if found else 0),best_pv", "if pv_node and found and not pv_replay:\n   counts['replay_entry_calls']+=1\n   child=make_checked(board.native,pos,best_action)\n   branch,replayed=visit(child,depth-1,-INF,INF,True,ply+1,True)\n   best_pv=(best_action,*replayed)\n  return (best if found else 0),best_pv")
exec(source,ns)
(folder/'native_replay_model.py').write_bytes(source.encode())
baseline=json.loads((folder/'native-schedule.json').read_bytes())
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'replay-model.json'
for name,factory,values in ns['ns']['ns']['factories'][3:]:
 for flag in ('rollout','advisor','slack'):
  flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
 core=factory();board=ns['ns']['NativeBoard'](core,values);r=ns['model'](board,3,True);assert board.restored()
 old=next(row['result'] for row in baseline['rows'] if row['case']==name and row['mode']=='source')
 assert r['score']==old['score'] and r['principal_variation'][:1]==tuple(old['principal_variation'][:1])
 counts=r['counts'];assert counts['nodes']==counts['transition_count']+3+counts['replay_entry_calls'];assert counts['nodes']==counts['main_entries']+counts['replay_subtree_entries']
 report['rows'].append({'case':name,'result':r,'baseline_nodes':old['counts']['nodes'],'added_entries':counts['nodes']-old['counts']['nodes']})
 out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(name,counts,flush=True)
report['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
