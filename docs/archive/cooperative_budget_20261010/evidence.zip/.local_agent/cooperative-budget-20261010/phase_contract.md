# Entry accounting and returned-route contract

This is a conditional explanation of the installed semantic Native q0 search,
not a new player, a build, a universal formula for arbitrary engines, or evidence
that a smaller integer node count means a better decision.

## Incoming-edge identity

`gc_semantic_iterative_negamax` has three call sites in the current source:
the iterative root caller, ordinary accepted action recursion, and selected-PV
replay recursion. The function increments nodes only after its budget check.
The ordinary action loop increments transition_count before the recursive call;
the selected replay transition does not increment that counter. At completed
iterations without fallback/interruption, every checked ordinary child enters
negamax. Therefore nodes = root entries + ordinary transitions + replay entry
calls. The root entries are root_iterations_attempted in these complete controls.

The residual counts selected replay calls, NOT every descendant visited during
replay, elapsed replay time, failed/terminal nested transition checks, or unique
positions. On an interruption a checked transition can be counted before child
entry aborts; partial iterations invalidate this identity's simple applicability.
Do not silently clamp a negative residual, infer unsupported qsearch phases, or
equate counter units across engines. Missing public counter fields remain None.

TT0/rootOFF has a null context TT and a false root-window flag, so the canonical
selected-PV replay guard cannot execute. Its excess work is not this replay.
TT64 cold controls have no TT cutoffs. A forced-replay source model reproduces
their complete four work counters, score and packed/public PV on all six repeated
controls. The model partitions replay descendants: EP1894/27718 entries,
generated2000 1496/43116, generated2001 689/69194. This validates a scoped phase
explanation, not direct phase timing. Warm64 calls have thousands of TT cutoffs
and cannot inherit that model's subtree partition. The incoming-edge residual
still counts their replay entries under the stated completion conditions.

## Full-window dispatch versus response correctness

The TT0/rootOFF source model, actual candidate order and full Native backend,
matches all four counters/score/PV. Changing only the internal PV-node window
dispatch, while leaving every root child full-window, reduces D1-D3 entries.
Canonical root choice is independently exact because each root child is searched
with a full window in these noTT/q0/completed controls. Interior equal fail-soft
returns do not establish equally good minimax replies. The4096 fixed synthetic
trees show this explicitly: both schedules return correct root values/actions
and matching PV leaf values, while59/213 continuations use a locally inferior
remaining-horizon action. The demonstration is tree-contract evidence, not chess
strength. Stored realD3 PV leaf replay alone would have missed the distinction.

Strict improvement for interior PV replacement, with canonical full-window root
ties retained, removes those selected-response errors in the same trees. It is
not a blanket guarantee for TT-derived lines, interruption, selective search,
qsearch, declarations or arbitrary rule semantics. For completed noTT/q0 ordinary
AB, the useful induction is narrower: an exact node's newly selected improving
child has a returned value inside its effective window, rather than a tied bound
at the incumbent threshold. That child can continue the exact-line induction.
This does not turn an arbitrary returned search estimate into a finite witness.

The Core controls independently exhaust the remaining horizon for each chosen
response at completeD2, and for each nonroot suffix position at completeD3. Root
D3 values agree between two full-root configurations; mate scores use the same
Core1e9 scale and actual ply offset. All sampled responses match their local
reference values. Tests keep legality, full history, undo, and live semantic
node/cancel/time dispatch. These local checks do not certify the whole generated
rule domain or restore unexposed validation status.

## Caller validation and cancellation

Independent post-search PV replay is the default diagnostic contract. It costs
time after semantic cancellation; in the original48cancel controls, the largest
cooperative latency6.414ms included5.806ms of that replay. A separate opt-in
diagnostic returns labels captured from legal searched frontiers and clearly
reports `pv_validation=searched_frontiers`. It omits independent replay only;
budget/legality checks during search remain intact, and only the last complete
iteration is returned.32actual paired cancellations show observed maximum
replay6.765ms versus captured0.502ms; timer jitter and limited scope preclude an
SLA. Initial root preparation remains unpolled in both diagnostic variants.

This distinction is a measurement choice, not permission to advertise a stronger
PV contract without paying its required verification cost. Product behavior and
UI remain unchanged. Current supported productCore already completes the two
D3 roots in about0.7sec/1597-1700 nodes, versus5.976/6.842sec for plain full-root
AB under real checks. Its TT/order/root scheduling differs; replacing it on the
basis of the Native source-model improvement is unjustified.
