# Execution failures

The initial resource assay retained37 completed cells, then refused a generated
adapter whose cooperative capability marker was absent. Its actions/push methods
were verified as exact CoreBoard aliases before local opt-in. Only35 remaining
declared cells ran; original source/partial output remain intact.

The first stored-PV replay script used the wrong imported namespace for
public_action and raised KeyError before completing. The first source is retained;
the corrected script only replays stored routes, not a search rerun.

The first complete-D3 Core script completed its first search but invoked a root-
restoration assertion while auditing from an already pushed child. No result had
yet been saved; the failed execution is ineligible for timing conclusions. Its
source is retained. The repaired script saves search results before verification
and skips root reference work while walking from the actual root, preserving mate
distance and restoration. It repeats the unchanged declared search solely to
recover missing output after this execution failure, with this added cost recorded.
No budget, success criterion or adverse comparison record is changed.

The initial replay applicability guard expected max_depth instead of the actual
completed termination string. Original raw output remains; derive_replay.py
corrects applicability without rerunning calls. The first model verification
indexed an absent zero Counter key; get(key,0) fixes this stored-data check.

The optional missing-counter regression initially omitted the required compiled
NativeRules argument. Its TypeError occurred before search. It was repaired
using the same NativeBoard constructor as the adjacent real-counter test; the
37 focused tests then passed. The first consolidation named one result file
incorrectly and failed before producing a summary; corrected filename only.

Source provenance: core_window-first-executed.py is reconstructed and verified
against the original output SHA before adding the later skip-root audit option.
Generated native_time_model/core_phase_model/native_replay_model and runtime
validation method files are the actual executed code. Initial budget/label
scripts used the earlier diagnostic without captured labels; final source closure
contains the later labeled diagnostic. Performance samples are not claimed to
have run against that later closure. This is retained as a provenance limitation.
