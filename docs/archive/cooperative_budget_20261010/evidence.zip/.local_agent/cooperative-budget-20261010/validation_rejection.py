"""Reject a counterfeit repeated move through both authoritative validators.
No search rerun; one existing Chess root's first legal move duplicated.
"""
from pathlib import Path
import json
folder=Path(__file__).parent;f=folder/'runtime_pv_probe.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
name,factory,values=ns['ns']['ns']['ns']['ns']['factories'][3]
core=factory();action=core.actions()[0][1];errors={}
for mode in ('immutable','runtime'):
 state=core.initial;runtime=ns['SearchPathRuntime'].from_state(state,core.compiled,history_witnesses=core.witnesses)
 try:
  for move in (action,action):
   if mode=='immutable':state=ns['apply_action'](state,move,core.compiled)
   else:runtime.push(move)
 except Exception as exc:errors[mode]={'class':type(exc).__name__,'message':str(exc)}
 else:raise AssertionError('illegal route accepted')
assert errors['immutable']['class']==errors['runtime']['class']=='IllegalActionError'
(folder/'validation-rejection.json').write_bytes((json.dumps(errors,indent=2)+'\n').encode());print(errors)
