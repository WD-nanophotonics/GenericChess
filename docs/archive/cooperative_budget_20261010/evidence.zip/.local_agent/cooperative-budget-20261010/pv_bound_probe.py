"""Bounded synthetic scheduling-contract check, not game/price evidence.
4096 seeded binary D4 trees, fixed leaf scores{-2,0,2}, shuffled candidate order
and numeric canonical tie. Compare source PVwindow policy/internalAB to full
minimax. Question: can an exact root value coexist with a wrong PV leaf when
equal fail-soft bounds replace interior best lines? Leaf agreement alone does
not establish minimax reply choice. No fitting or oracle games.
"""
from pathlib import Path
from random import Random
import json,hashlib
folder=Path(__file__).parent;rng=Random(202610101003)
def make(depth):
 if not depth:return rng.choice((-2,0,2))
 children=[(0,make(depth-1)),(1,make(depth-1))];rng.shuffle(children);return children
def exact(tree):
 if isinstance(tree,int):return tree,()
 rows=[(-exact(child)[0],action,exact(child)[1]) for action,child in tree]
 best=min(rows,key=lambda row:(-row[0],row[1]));return best[0],(best[1],*best[2])
def search(tree,source,pv,ply=0,alpha=-100,beta=100):
 if isinstance(tree,int):return tree,()
 best=-100;best_action=None;line=()
 for index,(action,child) in enumerate(tree):
  full=ply==0 or source and pv
  child_pv=(True if ply==0 else pv and index==0) if source else False
  value,childline=search(child,source,child_pv,ply+1,-100 if full else -beta,100 if full else -alpha)
  value=-value
  if value>best or value==best and action<best_action:best=value;best_action=action;line=(action,*childline)
  alpha=max(alpha,value)
  if alpha>=beta:break
 return best,line
def leaf(tree,line):
 for action in line:tree=dict(tree)[action]
 return tree*((-1)**len(line))
def policy_errors(tree,line):
 errors=[]
 for ply,action in enumerate(line):
  child=dict(tree)[action];optimal=exact(tree)[0];selected=-exact(child)[0]
  if selected!=optimal:errors.append({'ply':ply,'optimal':optimal,'selected':selected})
  tree=child
 return errors
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':4096,'modes':{mode:{'wrong_root':0,'wrong_root_action':0,'wrong_pv_leaf':0,'suboptimal_pv_continuation':0,'first_failure':None} for mode in ('source','fullroot_ab')}}
for index in range(4096):
 tree=make(4);value,pv=exact(tree)
 for mode in report['modes']:
  score,line=search(tree,mode=='source',mode=='source');r=report['modes'][mode]
  r['wrong_root']+=score!=value;r['wrong_root_action']+=line[:1]!=pv[:1]
  if leaf(tree,line)!=score:
   r['wrong_pv_leaf']+=1
  errors=policy_errors(tree,line)
  if errors:
   r['suboptimal_pv_continuation']+=1
   if r['first_failure'] is None:r['first_failure']={'index':index,'tree':tree,'exact':{'score':value,'pv':pv},'result':{'score':score,'pv':line,'leaf':leaf(tree,line),'errors':errors}}
(folder/'pv-bound-probe.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print([(mode,{k:v for k,v in r.items() if k!='first_failure'}) for mode,r in report['modes'].items()])
