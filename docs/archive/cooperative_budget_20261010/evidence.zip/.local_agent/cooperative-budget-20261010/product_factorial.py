"""Product-only cold TT/order attribution,16 serial D3 controls.
Same two generated roots, four TT/order cells, two reversed passes; no changes
to search/window algorithm, material/q0/history/rootTacticsOFF/semantic polls.
100000nodes/60seconds fuses. Decision: isolate whether current product advantage
comes from TT, ordering or residual schedule before proposing another repair.
No common-time claim, labels/oracle growth, training, default or Cbuild change.
Expected<2min, each call interruptible and stop checked.
"""
from pathlib import Path
import json,hashlib
from time import perf_counter
folder=Path(__file__).parent;f=folder/'product_d3.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nrows=')[0],ns)
rows=[];cells=((False,False),(True,False),(False,True),(True,True))
for name,factory,values in ns['ns']['factories'][2:]:
 for repeat,order in enumerate((cells,tuple(reversed(cells)))):
  for tt,ordering in order:
   for flag in ('rollout','advisor','slack'):
    flags=json.loads((ns['ns']['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
   core=factory();material=ns['ns']['Material']('chess');material.values=values;stats=ns['SearchStatistics']();start=perf_counter()
   action,score,pv,reason=ns['run_root_search'](core.initial,core.compiled,material,ns['TranspositionTable'](max_entries=65536),ns['SearchLimits'](max_depth=3,max_nodes=100000,max_time_seconds=60,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=tt,use_ordering=ordering,tuning=ns['SearchTuning'](use_root_tactical=False),_history_witnesses=core.witnesses)
   wall=perf_counter()-start;assert core.restored() and stats.completed_depth==3
   rows.append(ns['ns']['record_value']({'case':name,'repeat':repeat,'tt':tt,'ordering':ordering,'move':core.label(action),'score':score,'pv':[core.label(a) for a in pv],'statistics':ns['asdict'](stats),'caller_seconds':wall}));print(name,tt,ordering,stats.nodes,round(wall,3),flush=True)
out={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'complete':True};(folder/'product-factorial.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
