"""Scoped caller sensitivity to repaired blocked-leap input at fixed old scale.
Old/new full candidate tables are reported, but the actual comparison changes only
H board lookup. Ordering, other leaf lookups, dynamics and Core authority frozen.
No deployment choice, optimal material, WDL or strength claim.
"""
import sys,time,hashlib,subprocess,types
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'.local_agent/guard-projection-20261009')]
from option_distribution import definition,SHARED
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.rules.schema import RuleInvariant
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import _median,MAX_STATIC_EVAL
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
base='45b87ab8324393147b24cf71c9cb4ac577371129'
source=subprocess.run(['git','show',base+':generic_chess/ai/evaluation/semantic.py'],check=True,capture_output=True).stdout
historical=types.ModuleType('generic_chess.ai.evaluation.historical_semantic_v1');historical.__package__='generic_chess.ai.evaluation';exec(compile(source,'historical_semantic_v1','exec'),historical.__dict__)
def make():
 d=definition(SHARED);n=7;rows=[[None]*n for _ in range(n)]
 for f,r,owner,tid in ((0,0,0,'K'),(6,6,1,'K'),(2,2,0,'H'),(4,4,1,'H'),(1,1,0,'N'),(5,5,1,'N'),(5,4,1,'R')):rows[r][f]=Piece(owner,tid,tid)
 knight=PieceType('N','N',tuple(LeapAtom(o) for o in ((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1))))
 rook=PieceType('R','R',tuple(RayAtom(v) for v in ((1,0),(-1,0),(0,1),(0,-1))))
 return replace(d,piece_types=d.piece_types+(knight,rook),initial_position=tuple(map(tuple,rows)),drop_allowed={**d.drop_allowed,'N':((False,)*49,)*2,'R':((False,)*49,)*2},semantic_actions=tuple(replace(a,invariants=(RuleInvariant('own_anchor_safe'),)) for a in d.semantic_actions),capture_disposition='remove_from_game')

start=time.perf_counter();d=make();c=compile_ruleset_for_execution(d);cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
old,oldscope=historical.build_semantic_opportunity_profile(c,cfg);full,scope=build_semantic_opportunity_profile(c,cfg)
median=_median([oldscope['types'][pt.type_id]['raw'] for pt in c.piece_types if not pt.is_anchor]);assert median>0
h=max(1,min(MAX_STATIC_EVAL,round(cfg.normal_piece_median_value*scope['types']['H']['raw']/median)))
intervention=replace(old,board_value_by_type={**old.board_value_by_type,'H':h})
oldorder=Evaluator(c,old,cfg)
class FixedOrder(Evaluator):
 def capture_order_value(self,*args):return oldorder.capture_order_value(*args)
 def type_value(self,*args):return oldorder.type_value(*args)
res=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),old_source_sha256=hashlib.sha256(source).hexdigest(),base=base,declaration='4actual lexical-history roots x2H lookups x D2/D3; 8192nodes/5sec/q2hard8,root-tactical off; no post-outcome extensions. All configured cells retained.',old_profile=record_value(old),full_v2_profile=record_value(full),intervention_profile=record_value(intervention),old_scope=oldscope,new_scope=scope,cases=[],complete=False)
out=root/'.local_agent/guard-projection-20261009/guarded-caller.json';assert not out.exists();s=GameSession(c)
for ply in range(4):
 before=(s.state,s.history,s._search_witnesses)
 for depth in (2,3):
  for name,profile in (('old',old),('H_only',intervention)):
   ev=FixedOrder(c,profile,cfg);player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
   t=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=2,quiescence_hard_max_depth=8))
   validate_pv(s,dec);assert before==(s.state,s.history,s._search_witnesses)
   res['cases'].append(dict(ply=ply,depth=depth,lookup=name,seconds=time.perf_counter()-t,decision=record_value(dec)));write_record(out,res)
   print(ply,depth,name,dec.completed_depth,dec.termination_reason,dec.score,flush=True)
 if ply<3:s.submit(sorted(legal_actions(s.state,c),key=str)[0])
res['complete']=True;res['seconds']=time.perf_counter()-start;write_record(out,res)
