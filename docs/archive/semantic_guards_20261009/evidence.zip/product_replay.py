import sys,json
from pathlib import Path
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'.local_agent/guard-projection-20261009')]
from prototype_controls import definition,cases
from prototype import project
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
cfg=EvaluationConfig(density_points=(0.,.125,.5,.875,1.),density_weights=(.2,)*5)
rows=[]
for name,offsets,relative,ray,count in cases:
 c=compile_ruleset_for_execution(definition(offsets,relative,ray,count))
 a,_=project(c,'H',cfg.density_points);b=semantic_opportunity(c,'H',cfg)
 assert a['curves']==b['curves'],name
 rows.append(dict(case=name,projection=b))
write_record(root/'.local_agent/guard-projection-20261009/product-replay.json',dict(cases=rows,scope='Exact replay of declared research-only9case prototype with product opt-in projection; no new default.'))
print('9 product/prototype curves match')
