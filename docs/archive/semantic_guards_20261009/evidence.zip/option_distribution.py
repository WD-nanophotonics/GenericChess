"""Equal expected opportunity with different same-actor option distributions.
A declared one-step any-target diagnostic, not WDL/material value or a default.
"""
import sys,itertools,math,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import _king_type
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.schema import RuleSet,RuleSemanticAction,RuleGeometrySpec,RuleActionEffect,RuleSquareRef,RuleStateGuard,RuleSpatialSelector,RuleTypeRef
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
OFFSETS=((2,1),(1,2),(-1,2),(-2,1),(-2,-1),(-1,-2),(1,-2),(2,-1))
INDEPENDENT=((1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1))
SHARED=tuple((df//2,0) if abs(df)==2 else (0,dr//2) for df,dr in OFFSETS)


def definition(legs):
 actions=[]
 for i,(offset,leg) in enumerate(zip(OFFSETS,legs)):
  ref=RuleSquareRef('offset_from_source',offset=leg)
  guard=RuleStateGuard(aggregation='count',owner='any',type_ref=RuleTypeRef('any'),compare_field='base',promoted='any',location='board',spatial=RuleSpatialSelector('exact',refs=(ref,)),comparison='eq',value=0,subject_ref=ref)
  for relation in ('empty','enemy'):
   effects=(() if relation=='empty' else (RuleActionEffect('remove',square_ref=RuleSquareRef('target'),piece_owner='opponent'),))
   actions.append(RuleSemanticAction(name=f'{i}_{relation}',type_ids=('H',),geometry=RuleGeometrySpec('leap',offset=offset),target_relation=relation,composition='augment',state_guards=(guard,),effects=effects+(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),)))
 board=[None]*49;board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K')
 return RuleSet(board_size=7,piece_types=(_king_type(),PieceType('H','H',()),PieceType('B','B',())),initial_position=tuple(tuple(board[r*7:(r+1)*7]) for r in range(7)),drop_allowed={'H':((False,)*49,)*2,'B':((False,)*49,)*2},semantic_actions=tuple(actions))


def census(legs):
 unique=sorted(set(legs));index={g:i for i,g in enumerate(unique)}
 counts={}
 for clear in itertools.product((False,True),repeat=len(unique)):
  for targets in itertools.product((False,True),repeat=8):
   n=sum(clear[index[g]] and targets[i] for i,g in enumerate(legs))
   key=(sum(clear),sum(targets),n);counts[key]=counts.get(key,0)+1
 return counts,len(unique)

if __name__ == "__main__":
    start=time.perf_counter();cfg=EvaluationConfig(density_points=(0.,.125,.5,.875,1.),density_weights=(.2,)*5)
    res=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='7x7,8horse endpoints. Shared4cardinal guards vs8distinct neighbor guards. Every endpoint needs one empty guard. Same owner/source/density law and target relation; no fitting. Compute exact source-center count distribution, then actual Core endpoint-set controls.',cases=[])
    projections=[];position_checks=0
    for name,legs in (('shared',SHARED),('independent',INDEPENDENT)):
     c=compile_ruleset_for_execution(definition(legs));projection=semantic_opportunity(c,'H',cfg);projections.append(projection)
     counts,ng=census(legs);curves=[];engine=SemanticEngine(c);template=engine._initial_position()
     for d in cfg.density_points:
      q=1-d
      for kind,p in (('quiet',q),('capture',d/2)):
       pmf=[sum(m*q**clear*d**(ng-clear)*p**targets*(1-p)**(8-targets) for (clear,targets,count),m in counts.items() if count==n) for n in range(9)]
       mean=sum(i*v for i,v in enumerate(pmf));variance=sum((i-mean)**2*v for i,v in enumerate(pmf));any_action=1-pmf[0]
       assert abs(sum(pmf)-1)<1e-12 and abs(mean-8*q*p)<1e-12
       closed=1-(d+q*(1-p)**2)**4 if name=='shared' else 1-(1-q*p)**8
       var=8*q*p*(1-q*p)+(8*q*(1-q)*p*p if name=='shared' else 0)
       assert abs(any_action-closed)<1e-12 and abs(variance-var)<1e-12
       curves.append(dict(density=d,kind=kind,mean=mean,variance=variance,any_action=any_action,pmf=pmf))
     # Exhaust each guard-only layout with all targets identically empty or enemy.
     # Actual engine controls are separate from the full colored-layout probability census.
     unique=sorted(set(legs))
     for owner in (0,1):
      sign=1 if owner==0 else -1;source=24;targets=[24+sign*(dr*7+df) for df,dr in OFFSETS];guard_cells=[24+sign*(dr*7+df) for df,dr in unique]
      for clear in itertools.product((False,True),repeat=len(unique)):
       for capture in (False,True):
        board=[None]*49;board[source]=Piece(owner,'H','H')
        for square,empty in zip(guard_cells,clear):
         if not empty:board[square]=Piece(1-owner,'B','B')
        if capture:
         for square in targets:board[square]=Piece(1-owner,'B','B')
        position=replace(template,board=tuple(board),side_to_move=owner)
        allowed={targets[i] for i,g in enumerate(legs) if clear[unique.index(g)]}
        actual={a.target for a in engine.legal_actions(position) if a.source==source}
        assert actual==allowed,(name,owner,clear,capture)
        position_checks+=1
     res['cases'].append(dict(name=name,guards=legs,projection=projection,center_curves=curves,assignments=2**(ng+8)))
    assert projections[0]['curves']==projections[1]['curves']
    assert projections[0]['signature']!=projections[1]['signature']
    res['core_positions']=position_checks;res['seconds']=time.perf_counter()-start
    write_record(root/'.local_agent/guard-projection-20261009/option-distribution.json',res)
    print({'core_positions':position_checks,'same_projected_curves':True,'rows':[{k:v for k,v in x.items() if k!='pmf'} for c in res['cases'] for x in c['center_curves'] if x['density']==.5],'seconds':res['seconds']})
