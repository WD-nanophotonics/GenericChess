"""Supplied evaluator q2 transfer at existing rectangular roots.
Explicit control tables; no default rectangle generation, Native or strength claim.
"""
import sys,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'tests/product')]
from test_rectangular_search_override import rectangular_cannon,UnusedProfileCache
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.profile import RuleSetEvaluationProfile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
out=root/'.local_agent/guard-projection-20261009/rectangle-q2-transfer.json';assert not out.exists()
res=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='2shapes x2actual roots x2explicit evaluators x q0/q2; D2/8192nodes/5sec; q2hard8. Cold each cell. Compare restoration and supported completion, not q0/q2 score equivalence or gains.',complete=False,cases=[])
start=time.perf_counter()
for width,height in ((7,5),(9,10)):
 c=compile_ruleset_for_execution(rectangular_cannon(width,height));base=GameSession(c);action=sorted(legal_actions(base.state,c),key=str)[0]
 for ply in (0,1):
  s=GameSession(c)
  if ply:s.submit(action)
  before=(s.state,s.history,s._search_witnesses)
  profile=RuleSetEvaluationProfile(ruleset_fingerprint=c.ruleset_fingerprint,schema_version=1,evaluator_version='supplied-unit-control',config_hash='',piece_profiles={},board_value_by_type={'K':0,'C':100},hand_value_by_base_type={'K':0,'C':100},promotion_gain_by_type={},median_non_anchor_value=100)
  for name in ('material','semantic_mobility'):
   cfg=EvaluationConfig(dynamic_mobility_weight=2 if name=='semantic_mobility' else 0,anchor_escape_weight=0,promotion_potential_weight=0)
   for q in (0,2):
    ev=SemanticAttackEvaluator(c,profile,cfg,backend='core') if name=='semantic_mobility' else Evaluator(c,profile,cfg)
    player=AlphaBetaPlayer(c,evaluator_override=ev,profile_cache=UnusedProfileCache(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
    t=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
    assert player.evaluation_profile is None and player.native_legality_provider is None
    validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before
    res['cases'].append(dict(shape=[width,height],ply=ply,evaluator=name,q=q,seconds=time.perf_counter()-t,decision=record_value(dec)))
    write_record(out,res);print(width,height,ply,name,q,dec.completed_depth,dec.termination_reason,dec.score,flush=True)
res['complete']=True;res['seconds']=time.perf_counter()-start;write_record(out,res)
