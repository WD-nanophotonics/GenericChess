"""Research-only pure exact emptiness projection. Not a material/default change."""
from dataclasses import replace
from generic_chess.ai.evaluation.semantic import _excluded, _path_union
from generic_chess.rules.ir import geometry_candidates


def supported(guard):
    return (guard.aggregation == 'count' and guard.comparison == 'eq' and guard.value == 0
            and guard.owner == 'any' and guard.type_ref.kind == 'any'
            and guard.promoted == 'any' and guard.location == 'board'
            and guard.subject_ref is None and guard.spatial.kind == 'exact'
            and len(guard.spatial.refs) == 1
            and guard.spatial.refs[0].kind == 'offset_from_source')


def clear_cells(pattern, shape, owner, source, target):
    cells = set()
    for guard in pattern.guards:
        if not supported(guard):
            raise ValueError('unsupported guard')
        ref = guard.spatial.refs[0]
        df, dr = ref.offset
        if ref.owner_relative and owner == 1:
            df, dr = -df, -dr
        f, r = source % shape.width + df, source // shape.width + dr
        if not (0 <= f < shape.width and 0 <= r < shape.height):
            continue  # unresolved exact ref counts zero in Core
        cell = r * shape.width + f
        if cell == source:
            return None  # source is conditioned occupied
        if cell == target:
            if pattern.target.kind == 'target_enemy':
                return None
            continue  # already conditioned empty
        cells.add(cell)
    return frozenset(cells)


def project(compiled, type_id, densities):
    shape = compiled.board_shape
    edges = {kind:[{} for _ in range(2*shape.area)] for kind in ('target_empty','target_enemy')}
    included, excluded = [], []
    for pattern in compiled.ir.patterns:
        if type_id not in pattern.type_ids:
            continue
        reasons = _excluded(replace(pattern, guards=()), compiled.ir)
        if any(not supported(guard) for guard in pattern.guards):
            reasons.append('unsupported empty-cell guard')
        if reasons:
            excluded.append({'pattern':pattern.pattern_id,'reasons':sorted(set(reasons))})
            continue
        included.append(pattern.pattern_id)
        for gid in pattern.geometry_ids:
            geometry = compiled.ir.geometry[gid]
            if geometry.atom_source is not None and geometry.atom_source[0] != type_id:
                continue
            for owner in (0,1):
                for source in range(shape.area):
                    bucket = edges[pattern.target.kind][owner*shape.area+source]
                    for target,path in geometry_candidates(geometry,str(owner),source):
                        clear = clear_cells(pattern,shape,owner,source,target)
                        if clear is None:
                            continue
                        if any(p.kind=='path_clear' for p in pattern.path):
                            clear |= frozenset(path)
                        counts = {p.count for p in pattern.path if p.kind=='path_count_eq'}
                        if len(counts)>1:
                            continue
                        count = next(iter(counts)) if counts else None
                        cells = frozenset(path) if count is not None else frozenset()
                        bucket.setdefault(target,set()).add((clear,cells,count))
    curves=[]
    for density in densities:
        quiet=sum(_path_union(e,density)*(1-density) for b in edges['target_empty'] for e in b.values())/(2*shape.area)
        capture=sum(_path_union(e,density)*density/2 for b in edges['target_enemy'] for e in b.values())/(2*shape.area)
        curves.append(dict(density=density,quiet=quiet,capture=capture,total=quiet+capture))
    return dict(curves=curves,included=included,excluded=excluded),edges
