"""Preflighted guarded-H exchange, following an uninformative ordinary cohort.
One fixed mechanism witness; only H board price changes. No label fitting,
independent strength conclusion or modification of old cohort/criteria.
"""
import sys,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'.local_agent/guard-projection-20261009')]
from guarded_caller import make,historical,base
from generic_chess.core.pieces import Piece
from generic_chess.core.coordinates import Square
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig,MAX_STATIC_EVAL
from generic_chess.ai.evaluation.profile import _median
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.actions import action_source_square,action_target_square
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
start=time.perf_counter();d=make();rows=[[None]*7 for _ in range(7)]
for f,r,owner,tid in ((0,0,0,'K'),(6,6,1,'K'),(2,2,0,'H'),(5,3,1,'H'),(1,1,0,'N'),(5,5,1,'N'),(4,5,1,'R'),(4,3,1,'B')):rows[r][f]=Piece(owner,tid,tid)
d=replace(d,initial_position=tuple(map(tuple,rows)));c=compile_ruleset_for_execution(d);s=GameSession(c)
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
old,oldscope=historical.build_semantic_opportunity_profile(c,cfg);new,scope=build_semantic_opportunity_profile(c,cfg);median=_median([oldscope['types'][pt.type_id]['raw'] for pt in c.piece_types if not pt.is_anchor]);h=max(1,min(MAX_STATIC_EVAL,round(1000*scope['types']['H']['raw']/median)))
intervention=replace(old,board_value_by_type={**old.board_value_by_type,'H':h})
order=Evaluator(c,old,cfg)
class FixedOrder(Evaluator):
 def capture_order_value(self,*a):return order.capture_order_value(*a)
 def type_value(self,*a):return order.type_value(*a)
source,target=16,25
sq=lambda f,r: r*7+f
match=lambda a,src,tgt: action_source_square(a)==Square(src%7,src//7) and action_target_square(a)==Square(tgt%7,tgt//7)
capture=next(a for a in legal_actions(s.state,c) if match(a,source,target))
child=apply_action(s.state,capture,c);replies=[a for a in legal_actions(child,c) if match(a,sq(4,5),target) or match(a,sq(5,5),target)]
assert len(replies)==2,'declared R and N recaptures must be executable'
res=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),base=base,declaration='One fixed8piece7x7 root. Preflight exact H capture and R/N recaptures before D2 reference or D2/D3 q0/q2 public callers. Only H board1->derived repaired input, ordering/other leaves/dynamics fixed;8192nodes/5sec/cell, no extensions.',H_lookup=[old.board_value_by_type['H'],h],root=record_value(s.state),capture=record_value(capture),recaptures=record_value(replies),evaluations=[],calls=[])
out=root/'.local_agent/guard-projection-20261009/guarded-exchange.json';assert not out.exists();before=(s.state,s.history,s._search_witnesses)
for name,profile in (('old',old),('H_only',intervention)):
 ev=FixedOrder(c,profile,cfg);root_leaf=ev.evaluate(s.state);forced=[]
 for reply in replies:
  after=apply_action(child,reply,c);delta=ev.evaluate(after)-root_leaf
  assert delta==old.board_value_by_type['B']+old.hand_value_by_base_type['B']-profile.board_value_by_type['H']
  assert dict(after.position.hands[0].counts).get('B',0)==1 and not after.position.hands[1].counts
  forced.append(dict(reply=record_value(reply),leaf_delta=delta))
 action_value=-reference_minimax(child,1,ev,c,ply=1)[0];reference,refaction=reference_minimax(s.state,2,ev,c)
 res['evaluations'].append(dict(lookup=name,forced=forced,capture_D2_value=action_value,root_D2_value=reference,root_D2_action=record_value(refaction)))
 for depth in (2,3):
  for q in (0,2):
   player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
   t=time.perf_counter();dec=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
   validate_pv(s,dec);assert (s.state,s.history,s._search_witnesses)==before
   if depth==2 and q==0 and dec.completed_depth==2:assert dec.score==reference
   res['calls'].append(dict(lookup=name,depth=depth,q=q,seconds=time.perf_counter()-t,decision=record_value(dec)));write_record(out,res)
   print(name,depth,q,dec.completed_depth,dec.termination_reason,dec.score,flush=True)
res['seconds']=time.perf_counter()-start;write_record(out,res);print(res['evaluations'])
