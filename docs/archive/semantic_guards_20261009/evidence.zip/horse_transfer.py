"""Blocked-leap transfer and equivalent subject encoding on internal rule definitions.
No Xiangqi human holdout, material comparison, full legal-mobility or Native claim.
"""
import sys,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(root/'.local_agent/guard-projection-20261009')]
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
start=time.perf_counter();definition=build_xiangqi_diagnostic_ruleset();mask=(False,)*90
# Inert blockers isolate attribution to H from all other types.
definition=replace(definition,piece_types=definition.piece_types+(PieceType('Z','Z',()),),drop_allowed={**definition.drop_allowed,'Z':(mask,mask)})
compiled=compile_ruleset_for_execution(definition);engine=SemanticEngine(compiled);template=engine._initial_position()
cfg=EvaluationConfig(density_points=(0.,.125,.5,.875,1.),density_weights=(.2,)*5)
row=semantic_opportunity(compiled,'H',cfg)
unguarded=compile_ruleset_for_execution(replace(definition,semantic_actions=tuple(replace(a,state_guards=()) if 'H' in a.type_ids else a for a in definition.semantic_actions)))
free=semantic_opportunity(unguarded,'H',cfg)
global_definition=replace(definition,semantic_actions=tuple(replace(a,state_guards=tuple(replace(g,subject_ref=None) for g in a.state_guards)) if 'H' in a.type_ids else a for a in definition.semantic_actions))
global_row=semantic_opportunity(compile_ruleset_for_execution(global_definition),'H',cfg)
assert row['signature']==global_row['signature'] and row['curves']==global_row['curves']
assert len(row['included'])==16 and all('drop' in e['reasons'] for e in row['excluded'])
for actual,base in zip(row['curves'],free['curves']):
 for field in ('quiet','capture','total'):
  assert abs(actual[field]-base[field]*(1-actual['density']))<1e-12
positions=0
for owner in (0,1):
 for source in range(90):
  for blocker in [None]+[i for i in range(90) if i!=source]:
   board=[None]*90;board[source]=Piece(owner,'H','H')
   if blocker is not None:board[blocker]=Piece(1-owner,'Z','Z')
   position=replace(template,board=tuple(board),side_to_move=owner)
   expected=set()
   for df,dr in ((1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)):
    f,r=source%9+df,source//9+dr
    if not(0<=f<9 and 0<=r<10):continue
    leg=(source%9+(df//2 if abs(df)==2 else 0),source//9+(dr//2 if abs(dr)==2 else 0))
    if blocker!=leg[1]*9+leg[0]:expected.add(r*9+f)
   assert engine.attacked_squares(position,owner)==expected,(owner,source,blocker)
   positions+=1
other_scope={tid:semantic_opportunity(compiled,tid,cfg) for tid in ('G','A','E','S')}
write_record(root/'.local_agent/guard-projection-20261009/horse-transfer.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),guarded=row,unguarded=free,global_subject_equivalent=True,core_pseudo_positions=positions,other_scope=other_scope,seconds=time.perf_counter()-start))
print(dict(positions=positions,guarded_raw=row['raw'],unguarded_raw=free['raw'],included=len(row['included']),other_included={tid:len(v['included']) for tid,v in other_scope.items()},seconds=time.perf_counter()-start))
