"""Bounded prototype qualification; independent occupancy and real Core actions.
No full Xiangqi, safety invariant, default-price or strength claim.
"""
import sys,itertools,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(Path(__file__).parent)]
from prototype import project,clear_cells
from rule_semantics_ir_fixtures import _king_type
from generic_chess.core.coordinates import BoardShape
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import RuleSet,RuleSemanticAction,RuleGeometrySpec,RuleActionEffect,RuleSquareRef,RuleStateGuard,RuleSpatialSelector,RuleTypeRef,RulePathConstraint
from generic_chess.ai.evaluation.semantic import _path_union
from scripts.research_record import write_record


def definition(offsets=((1,0),),relative=True,ray=False,path_count=None):
    shape=BoardShape(5,3);board=[None]*15;board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K')
    guards=tuple(RuleStateGuard(aggregation='count',owner='any',type_ref=RuleTypeRef('any'),compare_field='base',promoted='any',location='board',spatial=RuleSpatialSelector('exact',refs=(RuleSquareRef('offset_from_source',offset=off,owner_relative=relative),)),comparison='eq',value=0) for off in offsets)
    actions=[]
    for target in ('empty','enemy'):
        effects=(() if target=='empty' else (RuleActionEffect('remove',square_ref=RuleSquareRef('target'),piece_owner='opponent'),))
        actions.append(RuleSemanticAction(name='guard_'+target,type_ids=('H',),geometry=RuleGeometrySpec('ray',direction=(1,0),max_steps=4) if ray else RuleGeometrySpec('leap',offset=(2,1)),target_relation=target,composition='augment',state_guards=guards,path_constraints=(() if not ray else (RulePathConstraint('path_clear'),)) if path_count is None else (RulePathConstraint('path_count_eq',count=path_count),),effects=effects+(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),)))
    return RuleSet(board_size=None,board_width=5,board_height=3,piece_types=(_king_type(),PieceType('H','H',()),PieceType('B','B',())),initial_position=tuple(tuple(board[r*5:(r+1)*5]) for r in range(3)),drop_allowed={'H':((False,)*15,)*2,'B':((False,)*15,)*2},semantic_actions=tuple(actions))


def exact_event(events,density):
    cells=set().union(*(clear|counted for clear,counted,count in events)); result=0
    for bits in itertools.product((False,True),repeat=len(cells)):
        occupied={c for c,v in zip(sorted(cells),bits) if v}
        if any(not(clear&occupied) and (count is None or len(counted&occupied)==count) for clear,counted,count in events):
            result+=density**len(occupied)*(1-density)**(len(cells)-len(occupied))
    return result

start=time.perf_counter();rows=[];positions=0;event_checks=0
cases=[('distinct',((1,0),),True,False,None),('duplicate',((1,0),(1,0)),True,False,None),('source',((0,0),),True,False,None),('target',((2,1),),True,False,None),('offboard',((20,0),),True,False,None),('absolute',((1,0),),False,False,None),('shared_path',((1,0),),True,True,None),('counted',((1,0),),True,True,1),('two_cells',((1,0),(0,1)),True,False,None)]
for name,offsets,relative,ray,count in cases:
    c=compile_ruleset_for_execution(definition(offsets,relative,ray,count));row,edges=project(c,'H',(0.,.125,.5,.875,1.));engine=SemanticEngine(c);template=engine._initial_position()
    assert all('drop' in e['reasons'] for e in row['excluded']),row['excluded']
    for kind,buckets in edges.items():
        for bucket in buckets:
            for target,events in bucket.items():
                for d in (0.,.125,.5,.875,1.):
                    assert abs(_path_union(events,d)-exact_event(events,d))<1e-12
                    event_checks+=1
    checks=0
    for owner in (0,1):
        source=5 if owner==0 else 9;target=source+(3 if not ray else 4)*(-1 if owner else 1) if not ray else (9 if owner==0 else 5)
        # Leap target uses(+2,+1), mirrored for owner1; choose valid middle-row origins.
        if not ray:source=0 if owner==0 else 14;target=7 if owner==0 else 7
        candidates=[x for x in range(15) if x not in (source,target)]
        # Exhaust all occupancy only where the real guard or ray can depend.
        relevant=set()
        for off in offsets:
            df,dr=off
            if relative and owner:df,dr=-df,-dr
            f,r=source%5+df,source//5+dr
            if 0<=f<5 and 0<=r<3:relevant.add(r*5+f)
        if ray:relevant.update(range(min(source,target)+1,max(source,target)))
        relevant-= {source,target}
        for bits in itertools.product((None,0,1),repeat=len(relevant)):
            for endpoint in (None,0,1):
                b=[None]*15;b[source]=Piece(owner,'H','H')
                for cell,v in zip(sorted(relevant),bits):
                    if v is not None:b[cell]=Piece(v,'B','B')
                if endpoint is not None:b[target]=Piece(endpoint,'B','B')
                pos=replace(template,board=tuple(b),side_to_move=owner)
                event_kind='target_empty' if endpoint is None else 'target_enemy'
                events=edges[event_kind][owner*15+source].get(target,())
                occupied={i for i,p in enumerate(b) if p is not None}
                expected=(endpoint is None or endpoint!=owner) and any(not(clear&occupied) and (ct is None or len(cells&occupied)==ct) for clear,cells,ct in events)
                actual=[a for a in engine.legal_actions(pos) if a.source==source and a.target==target]
                assert bool(actual)==expected,(name,owner,bits,endpoint,expected)
                for action in actual:
                    child=engine.apply(pos,action);assert child.board[target]==Piece(owner,'H','H') and child.board[source] is None
                    assert pos.board==tuple(b)
                checks+=1
    positions+=checks;rows.append(dict(case=name,curves=row['curves'],included=row['included'],excluded=row['excluded'],core_positions=checks))
assert rows[0]['curves']==rows[1]['curves']
assert all(r['total']==0 for r in rows[2]['curves'])
assert all(r['capture']==0 for r in rows[3]['curves'])
write_record(root/'.local_agent/guard-projection-20261009/prototype-controls.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),prototype_sha256=hashlib.sha256((Path(__file__).parent/'prototype.py').read_bytes()).hexdigest(),cases=rows,core_positions=positions,event_density_controls=event_checks,seconds=time.perf_counter()-start))
print({'cases':len(rows),'core_positions':positions,'event_density_controls':event_checks,'seconds':time.perf_counter()-start})
