"""Same blocked-leap option question under a declared anonymous fixed stock.
Exact union fractions, not human calibration, actual game utility or a default.
"""
import sys,math,itertools,time,hashlib
from pathlib import Path
from fractions import Fraction
root=Path.cwd();sys.path[:0]=[str(root),str(root/'.local_agent/guard-projection-20261009')]
from option_distribution import OFFSETS,SHARED,INDEPENDENT
from scripts.research_record import write_record


def falling(n,k):
 if k<0 or k>n:return 0
 return math.prod(range(n-k+1,n+1))


def union(targets,legs,B,E,F,quiet):
 Z=B-E-F;total=Fraction()
 for size in range(1,len(targets)+1):
  for chosen in itertools.combinations(range(len(targets)),size):
   g=len({legs[i] for i in chosen})
   numerator=falling(Z,size+g) if quiet else falling(E,size)*falling(Z,g)
   total+=(-1)**(size+1)*Fraction(numerator,falling(B,size+g))
 return total


def moments(shape,source,legs,E,F):
 w,h=shape;targets=[];guards=[]
 for (df,dr),(gf,gr) in zip(OFFSETS,legs):
  f,r=source%w+df,source//w+dr
  if 0<=f<w and 0<=r<h:
   targets.append(r*w+f);guards.append((source//w+gr)*w+source%w+gf)
 B=w*h-1;Z=B-E-F;m=len(targets)
 return dict(quiet_mean=Fraction(m*Z*(Z-1),B*(B-1)),capture_mean=Fraction(m*E*Z,B*(B-1)),quiet_any=union(targets,guards,B,E,F,True),capture_any=union(targets,guards,B,E,F,False))


def brute_two(guards,E,F,quiet):
 # 5x3 source6, targets3/13, sharedguard7 or distinct7/2.
 B=14;Z=B-E-F;targets=(3,13);cells=sorted(set(targets)|set(guards));value=Fraction()
 for layout in itertools.product(('E','F','Z'),repeat=len(cells)):
  assignment=dict(zip(cells,layout))
  if any(assignment[t]==('Z' if quiet else 'E') and assignment[g]=='Z' for t,g in zip(targets,guards)):
   e,f,z=(layout.count(k) for k in ('E','F','Z'))
   value+=Fraction(falling(E,e)*falling(F,f)*falling(Z,z),falling(B,len(cells)))
 return value

start=time.perf_counter();checks=[]
for E,F in ((0,0),(1,0),(1,1),(3,3),(6,6),(7,6)):
 for guards in ((7,7),(7,2)):
  for quiet in (False,True):
   exact=union((3,13),guards,14,E,F,quiet);observed=brute_two(guards,E,F,quiet)
   assert exact==observed
   checks.append(dict(E=E,F=F,guards=guards,quiet=quiet,probability=exact))
rows=[];stocks=((0,0),(1,1),(3,3),(6,6),(12,12),(18,18),(23,23))
for E,F in stocks:
 cases=[]
 for name,legs in (('shared',SHARED),('independent',INDEPENDENT)):
  per=[moments((7,7),source,legs,E,F) for source in range(49)]
  means={key:sum((r[key] for r in per),Fraction())/49 for key in per[0]}
  cases.append(dict(name=name,source_average=means,center=per[24]))
 assert cases[0]['source_average']['quiet_mean']==cases[1]['source_average']['quiet_mean']
 assert cases[0]['source_average']['capture_mean']==cases[1]['source_average']['capture_mean']
 rows.append(dict(enemy=E,friendly=F,other_empty=48-E-F,rho=(E+F)/48,cases=cases))
res=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Uniform colored placement of fixed E enemy/F friendly on B=area-1 after conditioning focal source occupied. Fixed7x7 source average; no anchors/history/S3 response filtering.7predeclared stocks,2mechanisms. Independent-square law is a separate original result, not overwritten.',two_endpoint_exact_controls=checks,cases=rows,seconds=time.perf_counter()-start)
write_record(root/'.local_agent/guard-projection-20261009/fixed-stock-options.json',res)
print({'two_endpoint_controls':len(checks),'stock_cases':len(rows),'seconds':res['seconds']})
for row in rows:
 print(row['enemy'],row['friendly'],[(c['name'],{k:float(v) for k,v in c['source_average'].items()}) for c in row['cases']])
