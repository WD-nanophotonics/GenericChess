"""Finite evidence summary, retain original source and results separately."""
from pathlib import Path
import json,hashlib
from statistics import mean
folder=Path(__file__).parent
def load(name):return json.loads((folder/f'{name}.json').read_bytes())
names=['assay','action-string-probe','matched-profile','poll-dispatch-probe','replay-scope','target-index-assay','delivered-index-probe','cancel-delivery','lifecycle-index-audit','lifecycle-events','metadata-cost','delivered-profile','thin-index-transfer','native-caller-delivery','generation-prefix-probe']
report={'scope':'Exposed finite local development, same four roots. Rule execution/completion/caller validation distinct; no strength, all-rule proof, Native terminal repair or UI propagation.','datasets':{},'decisions':{'adopt':'Bounded compile-owned incoming paths with exact old fallback; diagnostic one-dispatch live checking; independently validated Core Runtime Native PV caller.','defer':'Further state/hash/generation changes until one decision-changing residual is selected. No C blocked-build retry, polling throttle, engine replacement or new utility labels.','peer':'Key static-sequence/compile-lifecycle objection adopted and tested. Supplied-snippet review only; no independently executed evidence or workflow change.'}}
for name in names:
 a=load(name);assert a.get('complete',name=='matched-profile'),name
 report['datasets'][name]={'sha256':hashlib.sha256((folder/f'{name}.json').read_bytes()).hexdigest(),'complete':a.get('complete',True),'rows':len(a.get('rows',[])),'cancel':len(a.get('cancel',[])),'q2':len(a.get('q2',[])),'fixed':len(a.get('fixed',[]))}
def paired(a,timekey):
 result=[]
 for case in dict.fromkeys(r['case'] for r in a['rows']):
  rows=[r for r in a['rows'] if r['case']==case];fixed=[r for r in rows if r.get('cap_seconds',r.get('seconds'))==60]
  old=mean(r['result'][timekey] for r in fixed if r['mode']=='fallback');new=mean(r['result'][timekey] for r in fixed if r['mode']=='index')
  result.append({'case':case,'fallback_mean_seconds':old,'index_mean_seconds':new,'saved_percent':100*(1-new/old),'timed_completion':[{'cap_seconds':r.get('cap_seconds',r.get('seconds')),'mode':r['mode'],'repeat':r['repeat'],'completed_depth':r['result']['completed_depth']} for r in rows if r.get('cap_seconds',r.get('seconds'))!=60]})
 return result
report['delivered_product']=paired(load('delivered-index-probe'),'caller_seconds');report['thin_bridge']=paired(load('thin-index-transfer'),'caller_seconds')
c=load('cancel-delivery');report['cancel']={mode:{'max_request_to_return_ms':1000*max(r['request_to_return'] for r in c['cancel'] if r['mode']==mode),'max_observed_poll_gap_ms':1000*max(r['poll_gap'] for r in c['cancel'] if r['mode']==mode),'mean_polls':mean(r['polls'] for r in c['cancel'] if r['mode']==mode)} for mode in ('fallback','index')}
l=load('lifecycle-index-audit');report['lifecycle']={'roots':len(l['rows']),'states':sum(r['state_checks'] for r in l['rows']),'attack_queries':sum(r['attack_queries'] for r in l['rows']),'static_rows':sum(r['static_rows'] for r in l['rows']),'default_overflow':l['default_overflow'],'original_pseudoattack_positions':sum(r['positions'] for r in load('target-index-assay')['audits']),'original_pseudoattack_queries':sum(r['queries'] for r in load('target-index-assay')['audits']),'real_events':len(load('lifecycle-events')['events'])}
report['metadata']=load('metadata-cost')['rows']
n=load('native-caller-delivery');report['native_caller']={phase:{mode:{'max_post_kernel_ms':1000*max(r['post_kernel_seconds'] for r in n[phase] if r['mode']==mode),'mean_post_kernel_ms':1000*mean(r['post_kernel_seconds'] for r in n[phase] if r['mode']==mode),'mean_caller_ms':1000*mean(r['caller_seconds'] for r in n[phase] if r['mode']==mode)} for mode in ('immutable','runtime')} for phase in ('fixed','cancel')}
report['profile']=[]
for r in load('delivered-profile')['rows']:
 p=r['profile'];report['profile'].append({'case':r['case'],'mode':r['mode'],'instrumented_wall':r['profile_wall'],'semantic_polls':next(x['calls'] for x in p if x['function']=='checkpoint'),'top_self':p[:5]})
report['decisions']['adopt']='Compile-owned incoming-path index with full old fallback; one-dispatch diagnostic live checks. Product search scheduling retained.'
report['decisions']['defer']='Native Runtime PV validator passes new full-state/illegal-route controls but delivered mean fixed/cancel tail is unchanged or slightly worse after the shared Core index. Candidate archived; final Native caller stays immutable. Further generation/history changes need a concrete decision-changing residual; no polling throttle/C retry.'
g=load('generation-prefix-probe');report['generation_prefix']=[]
for case in dict.fromkeys(r['case'] for r in g['rows']):
 rows=[r for r in g['rows'] if r['case']==case];fixed=[r for r in rows if r['seconds']==60]
 old=mean(r['result']['caller_seconds'] for r in fixed if r['mode']=='baseline');new=mean(r['result']['caller_seconds'] for r in fixed if r['mode']=='cache')
 report['generation_prefix'].append({'case':case,'saved_percent':100*(1-new/old),'baseline_seconds':old,'cache_seconds':new,'timed_completion':[{'seconds':r['seconds'],'mode':r['mode'],'depth':r['result']['statistics']['completed_depth']} for r in rows if r['seconds']!=60]})
report['decisions']['generation_prefix']='Defer bounded per-call immutable geometry-prefix reuse:36 calls keep fixed work/routes; modest/adverse fixed cost and no timed completed-depth gain across all3 roots. No product cache added.'
(folder/'final-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:report[k] for k in ('cancel','native_caller','lifecycle')},indent=2))
