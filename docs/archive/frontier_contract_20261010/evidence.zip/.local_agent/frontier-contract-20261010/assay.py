"""Declared32fixed+64timed frontier/tie contract controls; see plan.md."""
from pathlib import Path
import sys,json,hashlib,inspect,textwrap,types
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));folder=Path(__file__).parent
f=ROOT/'.local_agent/cooperative-budget-20261010/assay.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
import scripts.bounded_root_scheduler as scheduler
source=textwrap.dedent(inspect.getsource(scheduler.iterative_root_search));assert source.count('canonical_key=keys.__getitem__')==1
first_source=source.replace('canonical_key=keys.__getitem__','canonical_key=lambda action: 0')
scope=dict(scheduler.__dict__);exec(first_source,scope);first_search=scope['iterative_root_search'];(folder/'first_tie_caller.py').write_bytes(first_source.encode())
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
report={'declaration':__doc__,'plan_sha256':hashlib.sha256((folder/'plan.md').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'assay.json'
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
def natural(self):return [(self.label(a),a) for a in self.runtime.legal_actions(checkpoint=self.checkpoint)]
for name,factory,values in ns['factories']:
 for seconds,nodes,depth in ((60,100000,3),(1,1000000,12),(4,1000000,12)):
  modes=('product','natural_first','lexical_first','lexical_canonical')
  for repeat,order in enumerate((modes,tuple(reversed(modes)))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();core.semantic_checkpoint_supported=True;material=ns['Material']('chess');material.values=values;core.material=material
    if mode=='product':
     stats=SearchStatistics();start=perf_counter()
     action,score,pv,reason=run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=depth,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
     r={'move':None if action is None else core.label(action),'score':score,'pv_labels':[core.label(a) for a in pv],'completed_depth':stats.completed_depth,'caller_seconds':perf_counter()-start,'exit_cause':reason,'statistics':asdict(stats)}
    else:
     if mode=='natural_first':core.actions=types.MethodType(natural,core)
     search=scheduler.iterative_root_search if mode=='lexical_canonical' else first_search
     r=search(core,seconds=seconds,node_limit=nodes,max_depth=depth,cooperative=True)
    assert core.restored();report['rows'].append(ns['record_value']({'case':name,'mode':mode,'repeat':repeat,'cap_seconds':seconds,'cap_nodes':nodes,'max_depth':depth,'result':r}));save()
    print(name,mode,seconds,r['completed_depth'],round(r['caller_seconds'],3),flush=True)
report['complete']=True;save()
