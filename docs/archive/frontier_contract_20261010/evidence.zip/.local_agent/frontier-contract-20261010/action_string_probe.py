"""Actual product unordered traversal is sorted(key=str), not natural order.
Four same roots x fixed D3/1sec/4sec x two passes =24 diagnostic calls.
First tie; q0; cooperative checks and independent PV replay remain. Existing
product controls are unchanged references, not interleaved timing pairs.
Expected <2min. Fixed counts/routes matching decides whether residual profiling
is meaningful; if unequal, inspect exact recursion before any timing claim.
"""
from pathlib import Path
import json,hashlib,types
folder=Path(__file__).parent; f=folder/'assay.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
def actions(self):
 return [(self.label(a),a) for a in sorted(self.runtime.legal_actions(checkpoint=self.checkpoint),key=str)]
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False}
out=folder/'action-string-probe.json'
for repeat in range(2):
 for name,factory,values in ns['ns']['factories'][::1 if repeat==0 else -1]:
  for seconds,nodes,depth in ((60,100000,3),(1,1000000,12),(4,1000000,12)):
   for flag in ('rollout','advisor','slack'):
    flags=json.loads((ns['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
   core=factory();core.semantic_checkpoint_supported=True;core.actions=types.MethodType(actions,core)
   core.material=ns['ns']['Material']('chess');core.material.values=values
   r=ns['first_search'](core,seconds=seconds,node_limit=nodes,max_depth=depth,cooperative=True)
   assert core.restored()
   report['rows'].append(ns['ns']['record_value']({'case':name,'repeat':repeat,'cap_seconds':seconds,'result':r}))
   out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(name,seconds,r['completed_depth'],r['work']['nodes'],round(r['caller_seconds'],3),flush=True)
report['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
