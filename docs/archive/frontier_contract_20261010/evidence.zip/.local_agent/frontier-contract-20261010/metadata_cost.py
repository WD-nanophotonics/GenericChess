"""Clarify memory after allocator reuse was visible in first tracemalloc assay.
Flush free lists using gc.collect before tracing four existing compiled roots;
also count unique index-owned key/row/path containers, excluding referenced
existing patterns/type/gid/compiled target integers and shared global emptytuple.
Neither allocation delta nor owned-container estimate is whole-process RSS.
No gameplay/search rerun; expected<10sec.
"""
from pathlib import Path
import json,hashlib,gc,sys,tracemalloc
from time import perf_counter
folder=Path(__file__).parent;f=folder/'assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
from generic_chess.rules.ir import _incoming_attack_paths
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
for name,factory,values in ns['ns']['factories']:
 c=factory().compiled;gc.collect();tracemalloc.start();t=perf_counter();index=_incoming_attack_paths(c.ir,c.board_shape.area);wall=perf_counter()-t;resident,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
 assert index==c._incoming_attack_paths
 seen=set();owned=0
 def count(x):
  global owned
  if id(x) not in seen:seen.add(id(x));owned+=sys.getsizeof(x)
 count(index)
 for key,rows in index.items():
  count(key);count(key[0]);count(rows)
  for row in rows:
   count(row)
   if row[4]:count(row[4])
 report['rows'].append(dict(case=name,paths=sum(map(len,index.values())),unique_owned_container_bytes=owned,tracked_new_resident_bytes=resident,tracked_new_peak_bytes=peak,instrumented_construction_seconds=wall))
report['complete']=True;(folder/'metadata-cost.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report['rows'],indent=2))
