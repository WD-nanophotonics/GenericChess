# Decision and initial evidence

Same generated roots have unlike root/interior traversal: product unordered
SemanticEngine order vs diagnostic sorted public labels. Product strictly keeps
the first equal winner, diagnostic chooses lexical canonical winner and verifies
bound contenders. Prior fixed values match but counts/cost are not isolated.
Question: after matching natural frontiers/first-tie, do recursive counts and
chosen routes agree, and what caller cost remains? No product replacement.

Declare four existing roots EP/Shogi-drop/generated2000/generated2001, four
arms productTT/orderOFF, diagnostic natural-first, lexical-first,
lexical-canonical. D3 fixed100000/60sec fuse, two reversed passes32calls;
then1/4seconds and1million/maxD12 under the same arms,64calls. All q0/material/
fullhistory/live semantic polls. Product q=0/node definition recorded separately.
Natural-first diagnostic retains exact root value, first encountered optimal
action. Canonical diagnostic key is original public label. Preparation/PV replay
included caller wall and recorded as unpolled. No new utility labels/cohort/game.
Expected under8min; each call bounded, serial, stop checked. Finite independent
selected-response D2 audit only if a mismatch changes attribution, not blanket
proof requirement. Possible outcome identical counts => inspect runtime/caller
per-node costs; unequal counts => locate traversal/terminal/iteration semantics.
