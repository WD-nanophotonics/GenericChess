"""Six matched-work cProfile calls: three existing roots x fallback/index.
Product q0 coldTT/orderON D3/max100k/60sec, no tactical root. Determine residual
execution bottleneck after delivery, not deployment speed from instrumented time.
Exact fixed output and non-time counts must agree; no new utility sample.
Expected<1min, sequential and no other CPU experiments running.
"""
from pathlib import Path
import json,hashlib,cProfile,pstats
from dataclasses import asdict
from time import perf_counter
folder=Path(__file__).parent;f=folder/'assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False);out=folder/'delivered-profile.json'
for name,factory,values in ns['ns']['factories']:
 if name=='shogi-drop':continue
 results=[]
 for mode in ('fallback','index'):
  core=factory();idx=core.compiled._incoming_attack_paths
  if mode=='fallback':object.__setattr__(core.compiled,'_incoming_attack_paths',None)
  core.material=ns['ns']['Material']('chess');core.material.values=values;stats=ns['SearchStatistics']();profile=cProfile.Profile();t=perf_counter();profile.enable()
  try:a,score,pv,reason=ns['run_root_search'](core.initial,core.compiled,core.material,ns['TranspositionTable'](),ns['SearchLimits'](max_depth=3,max_nodes=100000,max_time_seconds=60,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=True,use_ordering=True,tuning=ns['SearchTuning'](use_root_tactical=False),_history_witnesses=core.witnesses)
  finally:profile.disable();object.__setattr__(core.compiled,'_incoming_attack_paths',idx)
  wall=perf_counter()-t;assert core.restored();result=dict(score=score,move=core.label(a),pv=[core.label(x) for x in pv],reason=reason,statistics=asdict(stats));results.append(result)
  rows=[]
  for (filename,line,function),(primitive,total,selftime,cumulative,callers) in pstats.Stats(profile).stats.items():rows.append(dict(file=filename.replace(str(ns['ROOT']),'WORKSPACE'),line=line,function=function,primitive_calls=primitive,calls=total,self_seconds=selftime,cumulative_seconds=cumulative))
  report['rows'].append(dict(case=name,mode=mode,result=ns['ns']['record_value'](result),profile_wall=wall,profile=sorted(rows,key=lambda x:x['self_seconds'],reverse=True)));out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(name,mode,round(wall,3),flush=True)
 for k in ('score','move','pv','reason'):assert results[0][k]==results[1][k]
 sig=lambda r:{k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
 assert sig(results[0])==sig(results[1])
report['complete']=True;out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
