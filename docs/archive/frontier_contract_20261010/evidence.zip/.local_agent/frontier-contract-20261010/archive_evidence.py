"""Exact Agent research evidence, no Slack/raw account/private inputs/binaries."""
from pathlib import Path
import json,hashlib,zipfile,subprocess,sys,importlib.metadata
ROOT=Path(__file__).resolve().parents[2];folder=Path(__file__).parent
base='78dc9925c277f4a27af45973bfee5fed90c832d7'
before=folder/'source_before';before.mkdir(exist_ok=True)
for rel in ('generic_chess/core/semantic_executor.py','generic_chess/rules/ir.py','generic_chess/native/semantic_engine.py','scripts/root_bound_diagnostic.py'):
 data=subprocess.check_output(['git','show',f'{base}:{rel}'],cwd=ROOT);p=before/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
from generic_chess.native import _module
binary=Path(_module().__file__)
env={'python':sys.version,'packages':{name:importlib.metadata.version(name) for name in ('pytest','python-chess','cshogi')},'installed_kernel_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'kernel_file_name':binary.name,'source_base':base,'binary_not_archived':True}
(folder/'environment.json').write_text(json.dumps(env,indent=2)+'\n',encoding='utf-8')
paths=[p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.md') and '__pycache__' not in p.parts]
extra=['.local_agent/cooperative-budget-20261010/assay.py','.local_agent/cooperative-budget-20261010/runtime_pv_probe.py','.local_agent/cooperative-budget-20261010/runtime_validation_method.py','.local_agent/cooperative-budget-20261010/runtime-pv-probe.json','.local_agent/cooperative-budget-20261010/runtime-cancel-probe.json','.local_agent/native-terminal-20261010/syntax_ablation.py','.local_agent/native-terminal-20261010/bridge_assay.py','.local_agent/generated6-20261008/coverage.json','scripts/bounded_root_scheduler.py','scripts/root_bound_diagnostic.py','scripts/search_backend_comparison.py','scripts/native_backend_bridge.py','scripts/research_record.py','generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/statistics.py','generic_chess/core/semantic_executor.py','generic_chess/rules/ir.py','generic_chess/core/search_runtime.py','generic_chess/native/semantic_engine.py','tests/conftest.py','tests/rule_semantics_ir_fixtures.py','tests/product/test_compiled_attack_index.py','tests/product/test_h50b2e_semantic_search_engine.py','tests/product/test_search_path_runtime.py','tests/product/test_native_history.py','tests/product/test_recombined_semantic_lifecycle.py','tests/product/test_rectangular_public_semantic_execution.py','tests/development/test_diagnostic_semantic_budget.py']
paths += [ROOT/rel for rel in extra]
assert all(p.is_file() and '/slack/' not in p.as_posix() and p.name!='dot-question.txt' for p in paths)
target=ROOT/'docs/archive/frontier_contract_20261010/evidence.zip';target.parent.mkdir(parents=True,exist_ok=True)
(target.parent/'report.md').write_bytes((folder/'report.md').read_bytes());members={}
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(paths)):
  data=p.read_bytes();name=p.relative_to(ROOT).as_posix();members[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};z.writestr(name,data)
with zipfile.ZipFile(target) as z:
 assert len(z.namelist())==len(members)
 for name,m in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==m['sha256']
index={'schema':1,'base_commit':base,'scope':'Agent-authored exposed development; exact earlier/final source and contrary/failed results. Excludes raw Slack/account/outgoing/user-private inputs and binaries. Existing rule/test fixtures only, no human holdouts.','archive':target.relative_to(ROOT).as_posix(),'archive_bytes':target.stat().st_size,'archive_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'members':members,'summary':json.loads((folder/'final-summary.json').read_bytes()),'validation':'120 relevant tests passed; publish repeats relevant targets after final review.','dependencies':'Base commit supplies other module imports; exact scoped pilot source closure bundled. Early prototypes require their source_before context; final delivered controls explicitly select old traversal. Native caller pilot requires saved candidate search method, final immutable caller retained.'}
(ROOT/'docs/research/data/frontier_contract_20261010.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print('members',len(members),'bytes',target.stat().st_size,'sha256',index['archive_sha256'])
