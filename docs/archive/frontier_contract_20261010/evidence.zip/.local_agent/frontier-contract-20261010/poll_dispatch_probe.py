"""Retain every live node/cancel/deadline poll and its semantic count; inline
one diagnostic callback dispatch. Four same roots x two reverse passes x two
arms x D3/1sec/4sec =48calls, expected<3min. No throttle, budget enlargement,
partial-result promotion or product change. Same action-string first ties.
Completed D3 counts/PVs/poll counts must match, timed completion is measured.
"""
from pathlib import Path
import json,hashlib,inspect,textwrap,types
from contextlib import contextmanager,nullcontext
folder=Path(__file__).parent;f=folder/'action_string_probe.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns);s=ns['ns']
import scripts.root_bound_diagnostic as module
original=module._root_search;source=textwrap.dedent(inspect.getsource(original))
old="        work['semantic_polls'] += 1\n        budget_check()"
new="""        work['semantic_polls'] += 1
        if work['nodes'] >= node_limit:
            raise Exhausted('node_budget')
        if cancellation is not None and cancellation.is_cancelled():
            raise Exhausted('cancelled')
        if perf_counter()-start >= seconds:
            raise Exhausted('time_limit')"""
assert source.count(old)==1
scope=dict(module.__dict__);exec(source.replace(old,new),scope);candidate=scope['_root_search']
(folder/'inline_root_candidate.py').write_bytes(source.replace(old,new).encode())
@contextmanager
def active():
 module._root_search=candidate
 try:yield
 finally:module._root_search=original
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False}
out=folder/'poll-dispatch-probe.json'
for name,factory,values in s['ns']['factories']:
 for seconds,nodes,depth in ((60,100000,3),(1,1000000,12),(4,1000000,12)):
  for repeat,order in enumerate((('baseline','inline'),('inline','baseline'))):
   cell=[]
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((s['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();core.semantic_checkpoint_supported=True;core.actions=types.MethodType(ns['actions'],core);core.material=s['ns']['Material']('chess');core.material.values=values
    with active() if mode=='inline' else nullcontext():
     r=s['first_search'](core,seconds=seconds,node_limit=nodes,max_depth=depth,cooperative=True)
    assert core.restored();cell.append(r)
    report['rows'].append(s['ns']['record_value']({'case':name,'mode':mode,'repeat':repeat,'cap_seconds':seconds,'result':r}));out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(name,mode,seconds,r['completed_depth'],round(r['caller_seconds'],3),flush=True)
   if seconds==60:
    for key in ('score','move','pv_labels','work','completed_depth'):assert cell[0][key]==cell[1][key],(name,key)
report['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
