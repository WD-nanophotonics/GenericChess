"""Delivered compile-owned index vs exact old traversal (same compiled object
with private derived index setNone in a scoped local context). Four existing
roots x two reverse passes x two arms x D3/1sec/4sec =48Core product calls,
q0/coldTT/orderON/no root tactics/material unchanged. Include factory compile/
root preparation time and derived bytes separately; finite and timed work kept.
Same setup pays index construction in both arms: this isolates traversal, not
the counterfactual cost of never constructing an index. Earlier prototype
records measured that separate incremental setup. Expected<3min.
"""
from pathlib import Path
import json,hashlib
from dataclasses import asdict
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];folder=Path(__file__).parent
f=folder/'assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'delivered-index-probe.json'
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for name,factory,values in ns['ns']['factories']:
 for seconds,nodes,depth in ((60,100000,3),(1,1000000,12),(4,1000000,12)):
  for repeat,order in enumerate((('fallback','index'),('index','fallback'))):
   cell=[]
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    start=perf_counter();core=factory();setup=perf_counter()-start;index=core.compiled._incoming_attack_paths;assert index is not None
    if mode=='fallback':object.__setattr__(core.compiled,'_incoming_attack_paths',None)
    core.material=ns['ns']['Material']('chess');core.material.values=values;stats=ns['SearchStatistics']();start=perf_counter()
    try:
     a,score,pv,reason=ns['run_root_search'](core.initial,core.compiled,core.material,ns['TranspositionTable'](),ns['SearchLimits'](max_depth=depth,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=True,use_ordering=True,tuning=ns['SearchTuning'](use_root_tactical=False),_history_witnesses=core.witnesses)
     wall=perf_counter()-start
    finally:object.__setattr__(core.compiled,'_incoming_attack_paths',index)
    assert core.restored();r={'move':core.label(a),'score':score,'pv_labels':[core.label(a) for a in pv],'exit_cause':reason,'statistics':asdict(stats),'completed_depth':stats.completed_depth,'caller_seconds':wall,'factory_seconds':setup,'one_shot_seconds':wall+setup,'index_rows':sum(map(len,index.values()))};cell.append(r)
    report['rows'].append(ns['ns']['record_value']({'case':name,'mode':mode,'repeat':repeat,'cap_seconds':seconds,'result':r}));save();print(name,mode,seconds,stats.completed_depth,round(wall,3),round(setup,3),flush=True)
   if seconds==60:
    for k in ('move','score','pv_labels','exit_cause','completed_depth'):assert cell[0][k]==cell[1][k],(name,k)
    sig=lambda r:{k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
    assert sig(cell[0])==sig(cell[1]),(name,'fixed work')
report['complete']=True;save()
