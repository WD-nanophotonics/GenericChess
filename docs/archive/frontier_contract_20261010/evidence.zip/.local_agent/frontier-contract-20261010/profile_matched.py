"""Six cProfile controls on EP/generated2000/generated2001 D3.
Product TT/orderOFF vs diagnostic action-string first-tie. No new positions,
price fit or deadline throughput claim; cProfile changes wall substantially.
Compare exact nodes/PVs to unprofiled controls and attribute cumulative/self
cost, especially semantic polling vs retained rule execution. Each60sec fuse;
expected <2min. Shogi large frontier stays in unprofiled controls.
"""
from pathlib import Path
import json,hashlib,cProfile,pstats,types
from time import perf_counter
from dataclasses import asdict
folder=Path(__file__).parent;f=folder/'action_string_probe.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns);s=ns['ns']
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[]}
for name,factory,values in s['ns']['factories']:
 if name=='shogi-drop':continue
 for mode in ('product','diagnostic'):
  core=factory();core.semantic_checkpoint_supported=True;core.material=s['ns']['Material']('chess');core.material.values=values
  profiler=cProfile.Profile();start=perf_counter();profiler.enable()
  if mode=='product':
   stats=s['SearchStatistics']()
   action,score,pv,reason=s['run_root_search'](core.initial,core.compiled,core.material,s['TranspositionTable'](),s['SearchLimits'](max_depth=3,max_nodes=100000,max_time_seconds=60,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=False,use_ordering=False,tuning=s['SearchTuning'](use_root_tactical=False),_history_witnesses=core.witnesses)
   r={'score':score,'move':core.label(action),'pv_labels':[core.label(a) for a in pv],'completed_depth':stats.completed_depth,'work':asdict(stats)}
  else:
   core.actions=types.MethodType(ns['actions'],core)
   r=s['first_search'](core,seconds=60,node_limit=100000,max_depth=3,cooperative=True)
  profiler.disable();wall=perf_counter()-start;assert core.restored()
  raw=pstats.Stats(profiler).stats;data=[]
  for (filename,line,function),(primitive,total,self_time,cumulative,callers) in raw.items():
   data.append({'file':filename.replace(str(s['ROOT']),'WORKSPACE'),'line':line,'function':function,'primitive_calls':primitive,'calls':total,'self_seconds':self_time,'cumulative_seconds':cumulative})
  report['rows'].append(s['ns']['record_value']({'case':name,'mode':mode,'result':r,'profile_wall_seconds':wall,'profile':sorted(data,key=lambda x:x['cumulative_seconds'],reverse=True)}))
  (folder/'matched-profile.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(name,mode,r['completed_depth'],round(wall,3),flush=True)
