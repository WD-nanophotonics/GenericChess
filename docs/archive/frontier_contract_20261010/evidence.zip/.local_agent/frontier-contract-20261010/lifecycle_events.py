"""Reuse actual8-ply promoted/aux-expiring/capture-to-hand/drop-capacity
fixture, instrument only its public session submit. Audit both-owner/every-square
indexed/fallback attack and Runtime push/pop of each actual action; compare
complete child state with immutable transition. No new gameplay scenario.
Tracemalloc incoming metadata on four existing comparison roots separately;
counts/peak are new allocations from helper, not whole-process RSS. Expected<1min.
"""
from pathlib import Path
import sys,json,hashlib,tracemalloc
from time import perf_counter
from dataclasses import replace
folder=Path(__file__).parent;ROOT=folder.parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));sys.path.insert(0,str(ROOT/'tests/product'))
import test_recombined_semantic_lifecycle as fixture
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.rules.ir import _incoming_attack_paths
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),events=[],metadata=[],complete=False);out=folder/'lifecycle-events.json'
def audit(session):
 c=session.compiled if hasattr(session,'compiled') else session.ruleset
 fallback=replace(c);object.__setattr__(fallback,'_incoming_attack_paths',None)
 for owner in (0,1):
  for target in range(c.board_shape.area):assert SemanticEngine(c).is_square_attacked(session.state.position,target,owner)==SemanticEngine(fallback).is_square_attacked(session.state.position,target,owner)
 return c
base=fixture.GameSession
class CheckedSession(base):
 def submit(self,action):
  c=audit(self);state=self.state;runtime=SearchPathRuntime.from_state(state,c,history_witnesses=self._search_witnesses)
  child=fixture.apply_action(state,action,c);runtime.push(action)
  assert runtime.position==child.position and runtime.ply_count==child.ply_count and runtime.terminal_status==child.terminal_status
  runtime.pop();runtime.assert_balanced();assert runtime.position==state.position
  result=super().submit(action);audit(self)
  report['events'].append(dict(action=str(action),ply=self.state.ply_count,aux=list(self.state.position.aux_state),hands=[list(h.items()) for h in self.state.position.hands],promotion=any(p is not None and p.promoted for p in self.state.position.board)))
  return result
fixture.GameSession=CheckedSession
try:fixture.test_promotion_expiry_and_drop_capacity_through_real_capture_history()
finally:fixture.GameSession=base
f=folder/'assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
for name,factory,values in ns['ns']['factories']:
 c=factory().compiled;tracemalloc.start();t=perf_counter();idx=_incoming_attack_paths(c.ir,c.board_shape.area);seconds=perf_counter()-t;resident,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
 assert idx==c._incoming_attack_paths
 report['metadata'].append(dict(case=name,rows=sum(map(len,idx.values())),resident_new_bytes=resident,peak_new_bytes=peak,instrumented_construction_seconds=seconds))
report['complete']=True;out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print('events',len(report['events']),'metadata',len(report['metadata']))
