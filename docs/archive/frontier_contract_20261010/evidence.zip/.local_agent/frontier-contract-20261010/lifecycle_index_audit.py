"""One bounded compile lifecycle audit, no enlarged decision cohort.
Compare every static tuple/order (not short-circuit booleans) from old
geometry_paths_to against the compile-owned reverse index on existing roots.
Repeat filtered candidate and attack equality through real Runtime push/pop.
Change one existing geometry endpoint with dataclasses.replace, preserving old
object; check rebinding. Helper cap=count-1/count/count+1 and default65536
overflow stress use duplicated capture patterns with unique IDs, not admitted
new gameplay rules. tracemalloc resident/peak and construction wall separately;
compile construction has no cancellation API, bounded work not response SLA.
Expected<2min; at most4 first lexical root actions per existing root.
"""
from pathlib import Path
import sys,json,hashlib,tracemalloc
from dataclasses import replace
from time import perf_counter
folder=Path(__file__).parent;ROOT=folder.parents[1]
f=folder/'replay_scope.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
from generic_chess.rules.ir import _incoming_attack_paths,geometry_paths_to
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.search_runtime import SearchPathRuntime
from test_rectangular_public_semantic_execution import _public_9x10_facing_generals_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state
c=compile_ruleset_for_execution(_public_9x10_facing_generals_ruleset());s=initial_state(c)
roots=[x for x in ns['roots'] if hasattr(x[1],'ir')]+[('rectangle-palace',c,s,(s.position,))]
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=folder/'lifecycle-index-audit.json'
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
def old_sequence(c,owner,target):
 result=[]
 for p in c.ir.patterns:
  if p.target.kind!='target_enemy':continue
  for tid in p.type_ids:
   for source in range(c.board_shape.area):
    for gid in p.geometry_ids:
     g=c.ir.geometry.get(gid)
     if g is None or g.kind=='drop' or (g.atom_source is not None and g.atom_source[0]!=tid):continue
     for path in geometry_paths_to(g,str(owner),source,target):result.append((p,tid,source,gid,path))
 return tuple(result)
def audit(c,state):
 index=c._incoming_attack_paths;assert index is not None
 fallback=replace(c);object.__setattr__(fallback,'_incoming_attack_paths',None)
 engine,reference=SemanticEngine(c),SemanticEngine(fallback);rows=queries=0
 for owner in (0,1):
  for target in range(c.board_shape.area):
   old=old_sequence(c,owner,target);new=index[(str(owner),target)];assert old==new
   occupied=lambda r:(state.position.board[r[2]] is not None and state.position.board[r[2]].owner==owner and state.position.board[r[2]].current_type_id==r[1])
   assert tuple(filter(occupied,old))==tuple(filter(occupied,new))
   assert engine.is_square_attacked(state.position,target,owner)==reference.is_square_attacked(state.position,target,owner)
   rows+=len(new);queries+=1
 return rows,queries
for name,c,state,witnesses in roots:
 for flag in ('rollout','advisor','slack'):
  flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('stopped') or flags.get('user_paused'))
 index=c._incoming_attack_paths;count,queries=audit(c,state)
 runtime=SearchPathRuntime.from_state(state,c,history_witnesses=witnesses);states=1
 for a in sorted(runtime.legal_actions(),key=str)[:4]:
  runtime.push(a);r,q=audit(c,runtime);assert r==count;queries+=q;states+=1
  runtime.pop();runtime.assert_balanced();assert c._incoming_attack_paths is index
 gid=next(gid for gid,g in c.ir.geometry.items() if g.kind=='leap' and any(g.paths.get('0',{}).values()))
 g=c.ir.geometry[gid];source=next(s for s,p in g.paths['0'].items() if p)
 old_target=g.paths['0'][source][0];paths={o:dict(p) for o,p in g.paths.items()};paths['0'][source]=((old_target+1)%c.board_shape.area,)
 geometry=dict(c.ir.geometry);geometry[gid]=replace(g,paths=paths)
 changed=replace(c,ir=replace(c.ir,geometry=geometry))
 assert changed._incoming_attack_paths is not index and c._incoming_attack_paths is index
 audit(changed,state)
 report['rows'].append(dict(case=name,static_rows=count,state_checks=states,attack_queries=queries,replaced_endpoint=True,old_index_retained=True));save();print(name,count,states,flush=True)
# Stress just metadata helper, not a new gameplay/utility corpus.
c=roots[0][1];patterns=tuple(replace(p,pattern_id=f'stress{n}_{p.pattern_id}') for n in range(9) for p in c.ir.patterns)
stress=replace(c.ir,patterns=patterns)
def measured(ir,cap):
 tracemalloc.start();start=perf_counter();idx=_incoming_attack_paths(ir,c.board_shape.area,max_paths=cap);wall=perf_counter()-start;resident,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
 return idx,dict(cap=cap,wall=wall,resident=resident,peak=peak,rows=None if idx is None else sum(map(len,idx.values())))
idx,m=measured(c.ir,65536);count=sum(map(len,idx.values()));caps=[]
for cap in (count-1,count,count+1):
 candidate,data=measured(c.ir,cap);assert (candidate is None)==(cap<count)
 if candidate is not None:assert candidate==idx
 caps.append(data)
candidate,overflow=measured(stress,65536);assert candidate is None
report.update(metadata_measurement=m,exact_cap_boundary=caps,default_overflow=overflow,stress_scope='IR metadata helper only; duplicate uniquely renamed patterns, no admitted gameplay claim',complete=True);save()
print('metadata peak',m['peak'],'overflow peak',overflow['peak'])
