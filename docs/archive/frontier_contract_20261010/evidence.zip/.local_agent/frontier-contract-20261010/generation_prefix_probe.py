"""Next residual: does compile-static legal-generation prefix reuse matter?
Only EP/two existing generated roots;36 paired q0 product calls:D3/1sec/4sec,
two reverse baseline/cache arms. Installed attack index stays in both arms.
Scoped memo of immutable geometry_candidates result keyed geometry-id object,
owner/source; no occupancy/promotions/guards/legality/state cache. Preserve every
generation target/path poll. Cap65536 endpoint rows then stop storing, not rule
exclusion. Count hits/misses/metadata separately. No production integration
without material cost/completion effect; expected<2min, serial no CPU overlap.
"""
from pathlib import Path
import json,hashlib
from dataclasses import asdict
from time import perf_counter
folder=Path(__file__).parent;ROOT=folder.parents[1];f=folder/'assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
import generic_chess.core.semantic_executor as module
original=module.geometry_candidates
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False);out=folder/'generation-prefix-probe.json'
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for name,factory,values in ns['ns']['factories']:
 if name=='shogi-drop':continue
 for seconds,depth in ((60,3),(1,12),(4,12)):
  for repeat,order in enumerate((('baseline','cache'),('cache','baseline'))):
   cell=[]
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();core.material=ns['ns']['Material']('chess');core.material.values=values;stats=ns['SearchStatistics']();cache={};cost=dict(hits=0,misses=0,rows=0)
    def reused(g,owner,source):
     key=(id(g),owner,source)
     if key in cache:cost['hits']+=1;return cache[key]
     cost['misses']+=1;result=original(g,owner,source)
     if cost['rows']+len(result)<=65536:cache[key]=result;cost['rows']+=len(result)
     return result
    module.geometry_candidates=reused if mode=='cache' else original;t=perf_counter()
    try:a,score,pv,reason=ns['run_root_search'](core.initial,core.compiled,core.material,ns['TranspositionTable'](),ns['SearchLimits'](max_depth=depth,max_nodes=100000 if seconds==60 else 1000000,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=True,use_ordering=True,tuning=ns['SearchTuning'](use_root_tactical=False),_history_witnesses=core.witnesses)
    finally:module.geometry_candidates=original
    wall=perf_counter()-t;assert core.restored();r=dict(score=score,move=core.label(a),pv=[core.label(x) for x in pv],reason=reason,statistics=asdict(stats),caller_seconds=wall,cache=cost);cell.append(r)
    report['rows'].append(ns['ns']['record_value'](dict(case=name,mode=mode,repeat=repeat,seconds=seconds,result=r)));save();print(name,mode,seconds,stats.completed_depth,round(wall,3),flush=True)
   if seconds==60:
    for k in ('score','move','pv','reason'):assert cell[0][k]==cell[1][k],(name,k)
    sig=lambda r:{k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
    assert sig(cell[0])==sig(cell[1])
report['complete']=True;save()
