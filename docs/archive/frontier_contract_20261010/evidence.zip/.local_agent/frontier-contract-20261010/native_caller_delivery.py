"""Separate Native caller validation change from Core index gains.
Existing three full-Native-supported roots (EP/two generated),24fixed D3 and24
actual .05sec cancellations: TT0/64 x two reverse immutable/runtime pairs.
Both arms use identical new Core index, installed kernel/limits, full Core
legality and Native leaf feature replay. Immutable reference proxy implements
only old PV apply_action chain at the delivered validator seam. NoCbuild.
One-million/30sec fuse, cold engines, no trace/root tasks/default changes.
Measure actual post-kernel/public tail; no strength/PV-optimality claim.
Expected<2min; serial after thin48 ends, no extra writer/worker.
"""
from pathlib import Path
import json,hashlib,threading
from dataclasses import asdict
from time import perf_counter
folder=Path(__file__).parent;ROOT=folder.parents[1];f=folder/'assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
import generic_chess.native.semantic_engine as engine_module
from generic_chess.native import _module
from generic_chess.ai.cancellation import CancellationToken
runtime_class=engine_module.SearchPathRuntime
class Immutable:
 @classmethod
 def from_state(cls,state,compiled,history_witnesses=None):
  result=cls();result.state=state;result.compiled=compiled;return result
 def push(self,action):self.state=apply_action(self.state,action,self.compiled)
class Token(CancellationToken):
 def cancel(self):self.requested=perf_counter();super().cancel()
kernel=_module();original=kernel.semantic_engine_search;boundary={}
def measured(*args,**kwargs):
 try:return original(*args,**kwargs)
 finally:boundary['returned']=perf_counter()
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixed=[],cancel=[],complete=False);out=folder/'native-caller-delivery.json'
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def signature(x):
 if isinstance(x,dict):return {k:signature(v) for k,v in x.items() if 'seconds' not in k and 'nanoseconds' not in k}
 if isinstance(x,list):return [signature(v) for v in x]
 return x
kernel.semantic_engine_search=measured
try:
 for phase in ('fixed','cancel'):
  for name,factory,values in ns['ns']['factories']:
   if name=='shogi-drop':continue
   for mb in (0,64):
    cell=[]
    for repeat,order in enumerate((('immutable','runtime'),('runtime','immutable'))):
     for mode in order:
      for flag in ('rollout','advisor','slack'):
       flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('stopped') or flags.get('user_paused'))
      core=factory();board=NativeBoard(core,values);session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
      engine=engine_module.SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=mb)
      token=Token() if phase=='cancel' else None;timer=threading.Timer(.05,token.cancel) if token else None
      engine_module.SearchPathRuntime=Immutable if mode=='immutable' else runtime_class
      start=perf_counter()
      if timer:timer.start()
      try:result=engine.search(session,ns['SearchLimits'](max_depth=3 if phase=='fixed' else 12,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0),token);end=perf_counter()
      finally:
       engine_module.SearchPathRuntime=runtime_class
       if timer:timer.cancel();timer.join()
      assert session.state==core.initial and board.restored()
      if token:assert result.termination_reason=='cancelled'
      raw=ns['ns']['record_value'](asdict(result));cell.append(raw)
      r=dict(case=name,tt_mb=mb,repeat=repeat,mode=mode,result=raw,caller_seconds=end-start,post_kernel_seconds=end-boundary['returned'])
      if token:r['request_to_public_seconds']=end-token.requested
      report[phase].append(r);save()
    if phase=='fixed':assert all(signature(r)==signature(cell[0]) for r in cell),name
finally:kernel.semantic_engine_search=original;engine_module.SearchPathRuntime=runtime_class
report['complete']=True;save();print('fixed',len(report['fixed']),'cancel',len(report['cancel']))
