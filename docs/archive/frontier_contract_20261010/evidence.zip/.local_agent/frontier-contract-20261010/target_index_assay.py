"""Target-index changed premise; profile shows864942 geometry_paths_to probes
on generated2000 D3 versus13431 attacks. Prior compatibility-only atlas skipped
type-incompatible geometries, not compatible paths to other squares.
Attack all squares/both owners on four existing roots and first12D1children;
also nonempty semantic castling/EP/five weird roots from replay_scope.py. Then
four roots x baseline/index x2reversed x D3/1sec/4sec =48product q0 coldTT/orderON
calls, no root tactics. Fixed complete route and nontime stats must agree.
Setup cost/bytes separate, caller total includes metadata construction for
one-shot clients; live checkpoints preserved on every actual indexed work unit.
Expected<4min; cap100000nodes/60sec forD3 and1million/maxD12 timed. Same prices,
existing exposed roots; no new utility reference labels or engine/UI defaults.
"""
from pathlib import Path
import sys,json,hashlib
from dataclasses import asdict
from contextlib import nullcontext
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
folder=Path(__file__).parent;f=folder/'assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
from target_attack_index import active
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.transition import initial_state,legal_successors
f=folder/'replay_scope.py';rs={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],rs)
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'prototype_sha256':hashlib.sha256((folder/'target_attack_index.py').read_bytes()).hexdigest(),'audits':[],'rows':[],'complete':False};out=folder/'target-index-assay.json'
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for name,c,state,witnesses in rs['roots']:
 if not hasattr(c,'ir'):continue
 positions=[state.position]+[child.position for _,child in legal_successors(state,c)[:12]];engine=SemanticEngine(c)
 expected=[tuple(engine.is_square_attacked(p,s,o) for o in (0,1) for s in range(len(p.board))) for p in positions]
 with active(c) as metadata:
  actual=[tuple(engine.is_square_attacked(p,s,o) for o in (0,1) for s in range(len(p.board))) for p in positions]
 assert actual==expected,(name,'pseudo-attack')
 report['audits'].append({'case':name,'positions':len(positions),'queries':sum(len(x) for x in actual),'signature_sha256':hashlib.sha256(repr(actual).encode()).hexdigest(),'metadata':metadata});save();print('audit',name,len(positions),metadata['paths'],flush=True)
for name,factory,values in ns['ns']['factories']:
 for seconds,nodes,depth in ((60,100000,3),(1,1000000,12),(4,1000000,12)):
  for repeat,order in enumerate((('baseline','index'),('index','baseline'))):
   cell=[]
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();core.material=ns['ns']['Material']('chess');core.material.values=values;stats=ns['SearchStatistics']();start=perf_counter()
    with active(core.compiled) if mode=='index' else nullcontext({}) as metadata:
     setup=perf_counter()-start;start=perf_counter()
     a,score,pv,reason=ns['run_root_search'](core.initial,core.compiled,core.material,ns['TranspositionTable'](),ns['SearchLimits'](max_depth=depth,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=True,use_ordering=True,tuning=ns['SearchTuning'](use_root_tactical=False),_history_witnesses=core.witnesses)
     wall=perf_counter()-start
    assert core.restored();r={'move':core.label(a),'score':score,'pv_labels':[core.label(a) for a in pv],'exit_cause':reason,'statistics':asdict(stats),'completed_depth':stats.completed_depth,'caller_seconds':wall,'setup_seconds':setup,'one_shot_seconds':wall+setup,'metadata':metadata};cell.append(r)
    report['rows'].append(ns['ns']['record_value']({'case':name,'mode':mode,'repeat':repeat,'cap_seconds':seconds,'result':r}));save();print(name,mode,seconds,stats.completed_depth,round(wall,3),round(setup,3),flush=True)
   if seconds==60:
    for k in ('move','score','pv_labels','exit_cause','completed_depth'):assert cell[0][k]==cell[1][k],(name,k)
    sig=lambda r:{k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
    assert sig(cell[0])==sig(cell[1]),(name,'fixed work')
report['complete']=True;save()
