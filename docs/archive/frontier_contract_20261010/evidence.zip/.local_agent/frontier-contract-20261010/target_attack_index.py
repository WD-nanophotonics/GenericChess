"""New premise: compile incoming geometry paths by target, not merely static
compatible geometry IDs. Eliminate source/geometry probes with no path to the
queried square; retain exact original pattern/type/source/geometry/path order,
occupancy, attacker-relative guards, aux state and every actual path predicate.
All S0/S1 capture patterns including S4-bearing patterns remain. No state cache,
geometry reinterpretation, C build or globally keyed product cache. Scoped
per-compiled context; metadata and setup measured separately. Budget checks at
every incoming candidate/path and inside path/guard work, no time throttle.
"""
from contextlib import contextmanager
import sys
from time import perf_counter
import generic_chess.core.semantic_executor as module
from generic_chess.rules.ir import geometry_candidates

@contextmanager
def active(compiled):
 start=perf_counter();size=compiled.support.board_shape.area;count=0
 index={(owner,target):[] for owner in (0,1) for target in range(size)}
 for owner in (0,1):
  for pattern in compiled.ir.patterns:
   if pattern.target.kind!='target_enemy':continue
   for tid in pattern.type_ids:
    for source in range(size):
     for gid in pattern.geometry_ids:
      geometry=compiled.ir.geometry.get(gid)
      if geometry is None or geometry.kind=='drop' or geometry.atom_source is not None and geometry.atom_source[0]!=tid:continue
      for target,path in geometry_candidates(geometry,str(owner),source):
       index[(owner,target)].append((pattern,tid,source,gid,path))
       count+=1
       if count>1000000:raise ValueError('local prototype path metadata cap')
 index={k:tuple(v) for k,v in index.items()}
 original=module.SemanticEngine.is_square_attacked
 def incoming(self,position,square,by_owner,checkpoint=None):
  if self.semantic is not compiled:return original(self,position,square,by_owner,checkpoint)
  self._ensure_match(position);module._checkpoint(checkpoint)
  for pattern,tid,source,gid,path in index.get((by_owner,square),()):
   module._checkpoint(checkpoint)
   piece=position.board[source]
   if piece is None or piece.owner!=by_owner or piece.current_type_id!=tid:continue
   binding=self._make_binding(pattern,gid,tid,piece,source,square,None,path,position)
   if self._path_holds(pattern.path,position,binding,by_owner,checkpoint=checkpoint) and self._guards_hold(pattern,position,binding,by_owner,checkpoint=checkpoint):return True
  return False
 metadata={'entries':len(index),'paths':sum(map(len,index.values())),'construction_seconds':perf_counter()-start,'shallow_bytes':sys.getsizeof(index)+sum(sys.getsizeof(k)+sys.getsizeof(v)+sum(sys.getsizeof(row)+sys.getsizeof(row[-1]) for row in v) for k,v in index.items())}
 module.SemanticEngine.is_square_attacked=incoming
 try:yield metadata
 finally:module.SemanticEngine.is_square_attacked=original
