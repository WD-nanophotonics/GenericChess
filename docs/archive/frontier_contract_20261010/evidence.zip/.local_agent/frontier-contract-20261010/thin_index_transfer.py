"""Does the new rule-execution repair transfer to the existing thin AB bridge?
Four existing roots x fallback/index x two reverse passes x D3/1sec/4sec=48
serial calls; actual Core internal node/cancel/time polls, public lexical/canonical
tie policy, noTT/order/q. D3max100k/time60fuse, timedmax1M/maxD12. This is new
exposed development after a changed execution premise, not extension of old
frozen validation or utility labels. Existing prices/history unchanged. Thin
initial root preparation/PV replay remain unpolled, included caller cost.
Compare only own fixed full work/PV; no product/Native node-unit equation or
strength claim. Expected<4min, every call interruptible and stop flags checked.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;ROOT=folder.parents[1]
f=ROOT/'.local_agent/cooperative-budget-20261010/assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nfolder=')[0],ns)
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False);out=folder/'thin-index-transfer.json'
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for name,factory,values in ns['factories']:
 for seconds,depth in ((60,3),(1,12),(4,12)):
  for repeat,order in enumerate((('fallback','index'),('index','fallback'))):
   cells=[]
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('stopped') or flags.get('user_paused'))
    core=factory();index=core.compiled._incoming_attack_paths;assert index is not None
    if mode=='fallback':object.__setattr__(core.compiled,'_incoming_attack_paths',None)
    core.semantic_checkpoint_supported=True;core.material=ns['Material']('chess');core.material.values=values
    try:result=ns['iterative_root_search'](core,seconds=seconds,node_limit=100000 if seconds==60 else 1000000,max_depth=depth,cooperative=True)
    finally:object.__setattr__(core.compiled,'_incoming_attack_paths',index)
    assert core.restored();cells.append(result);report['rows'].append(ns['record_value'](dict(case=name,mode=mode,repeat=repeat,seconds=seconds,result=result)));save();print(name,mode,seconds,result['completed_depth'],round(result['caller_seconds'],3),flush=True)
   if seconds==60:
    for k in ('move','score','pv_labels','nodes','completed_depth','exit_cause'):
     if k in cells[0]:assert cells[0][k]==cells[1][k],(name,k)
report['complete']=True;save()
