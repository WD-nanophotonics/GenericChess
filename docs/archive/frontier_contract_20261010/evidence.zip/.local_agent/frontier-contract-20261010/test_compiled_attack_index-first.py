"""Derived incoming geometry ownership, serialization and exact fallback."""
from dataclasses import replace
import pickle

import pytest

from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.ir import _incoming_attack_paths
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.session.session import GameSession


def test_repeated_engines_share_compile_owned_data_and_pickle_preserves_execution():
    compiled = compile_ruleset_for_execution(build_western_chess_ruleset())
    index = compiled._incoming_attack_paths
    assert index is not None
    first, second = SemanticEngine(compiled), SemanticEngine(compiled)
    assert first.semantic._incoming_attack_paths is second.semantic._incoming_attack_paths is index
    restored = pickle.loads(pickle.dumps(compiled))
    assert restored.ir.serialized() == compiled.ir.serialized()
    assert restored.ruleset_fingerprint == compiled.ruleset_fingerprint
    position = GameSession(compiled).state.position
    expected = tuple(first.is_square_attacked(position, square, owner)
        for owner in (0, 1) for square in range(len(position.board)))
    observed = tuple(SemanticEngine(restored).is_square_attacked(position, square, owner)
        for owner in (0, 1) for square in range(len(position.board)))
    assert observed == expected


def test_replacing_ir_rebuilds_derived_paths_instead_of_reusing_stale_index():
    compiled = compile_ruleset_for_execution(build_western_chess_ruleset())
    changed = replace(compiled, ir=replace(compiled.ir, patterns=()))
    assert changed._incoming_attack_paths is not compiled._incoming_attack_paths
    assert not any(changed._incoming_attack_paths.values())
    position = GameSession(compiled).state.position
    assert not SemanticEngine(changed).is_square_attacked(position, 0, 0)


def test_bounded_metadata_fallback_keeps_full_attack_semantics():
    compiled = compile_ruleset_for_execution(build_western_chess_ruleset())
    assert _incoming_attack_paths(compiled.ir, compiled.board_shape.area, max_paths=0) is None
    session = GameSession(compiled)
    for _ in range(3):
        position = session.state.position
        indexed = SemanticEngine(compiled)
        fallback = replace(compiled)
        object.__setattr__(fallback, '_incoming_attack_paths', None)
        reference = SemanticEngine(fallback)
        for owner in (0, 1):
            for square in range(len(position.board)):
                assert indexed.is_square_attacked(position, square, owner) == reference.is_square_attacked(position, square, owner)
        session.submit(sorted(session.legal_actions(), key=str)[0])


def test_indexed_empty_query_still_polls_and_preserves_match_check():
    compiled = compile_ruleset_for_execution(build_western_chess_ruleset())
    engine = SemanticEngine(compiled)
    position = GameSession(compiled).state.position
    assert not engine.is_square_attacked(position, -1, 0)
    assert not engine.is_square_attacked(position, 64, 0)
    assert not engine.is_square_attacked(position, 0, 99)
    def stopped():
        raise InterruptedError('stopped inside geometry')
    with pytest.raises(InterruptedError, match='stopped inside geometry'):
        engine.is_square_attacked(position, -1, 0, stopped)
    with pytest.raises(Exception, match='fingerprint'):
        engine.is_square_attacked(replace(position, ruleset_fingerprint='different'), 0, 0)
