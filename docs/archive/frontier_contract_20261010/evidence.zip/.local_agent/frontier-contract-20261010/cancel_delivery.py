"""32 real cancellation controls: four existing roots x two delays(.05,.15)
x two reversed orders x fallback/index. Timer sets token only; no CPU overlap.
q0 coldTT/orderON, maxD12/1M nodes/30sec fuse. Full parent restoration and
cancelled exit required; poll gap and requested-to-return are observed, not SLA.
Then16 fixed D2/q2 paired controls, nodes4096/time30sec, same roots and orders.
No utility labels or cohort extensions. Expected<2min.
"""
from pathlib import Path
import json,hashlib,threading
from dataclasses import asdict
from time import perf_counter
folder=Path(__file__).parent;ROOT=folder.parents[1]
f=folder/'assay.py';ns={'__file__':str(f)};exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
from generic_chess.ai.cancellation import CancellationToken
class Token(CancellationToken):
 def __init__(self):super().__init__();self.requested=None;self.last=None;self.max_gap=0;self.polls=0
 def cancel(self):self.requested=perf_counter();super().cancel()
 def is_cancelled(self):
  t=perf_counter()
  if self.last is not None:self.max_gap=max(self.max_gap,t-self.last)
  self.last=t;self.polls+=1;return super().is_cancelled()
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cancel=[],q2=[],complete=False)
out=folder/'cancel-delivery.json'
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
for phase in ('cancel','q2'):
 for name,factory,values in ns['ns']['factories']:
  for delay in ((.05,.15) if phase=='cancel' else (None,)):
   for repeat,order in enumerate((('fallback','index'),('index','fallback'))):
    cell=[]
    for mode in order:
     for flag in ('rollout','advisor','slack'):
      flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
     core=factory();idx=core.compiled._incoming_attack_paths
     if mode=='fallback':object.__setattr__(core.compiled,'_incoming_attack_paths',None)
     core.material=ns['ns']['Material']('chess');core.material.values=values;stats=ns['SearchStatistics']()
     token=Token() if phase=='cancel' else None;timer=threading.Timer(delay,token.cancel) if token else None
     start=perf_counter()
     if timer:timer.start()
     try:
      a,score,pv,reason=ns['run_root_search'](core.initial,core.compiled,core.material,ns['TranspositionTable'](),ns['SearchLimits'](max_depth=12 if token else 2,max_nodes=1000000 if token else 4096,max_time_seconds=30,quiescence_max_depth=0 if token else 2,quiescence_hard_max_depth=0 if token else 2),token,stats,use_tt=True,use_ordering=True,tuning=ns['SearchTuning'](use_root_tactical=False),_history_witnesses=core.witnesses)
      end=perf_counter()
     finally:
      object.__setattr__(core.compiled,'_incoming_attack_paths',idx)
      if timer:timer.cancel();timer.join()
     assert core.restored()
     r=dict(case=name,mode=mode,repeat=repeat,delay=delay,move=core.label(a),score=score,pv=[core.label(x) for x in pv],reason=reason,statistics=asdict(stats),wall=end-start)
     if token:
      assert token.requested is not None and reason=='cancelled'
      r.update(actual_delay=token.requested-start,request_to_return=end-token.requested,poll_gap=token.max_gap,polls=token.polls)
     cell.append(r);report[phase].append(ns['ns']['record_value'](r));save()
    if phase=='q2':
     for k in ('move','score','pv','reason'):assert cell[0][k]==cell[1][k],(name,k)
     sig=lambda x:{k:v for k,v in x['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
     assert sig(cell[0])==sig(cell[1]),(name,'q2 work')
report['complete']=True;save();print('cancel',len(report['cancel']),'q2',len(report['q2']))
