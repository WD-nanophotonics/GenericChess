# Failures and source boundaries

The initial plan incorrectly treated unordered product traversal as natural
order. It actually sorts str(action). Preserve the96-call plan/results; natural
and public-label orders cannot isolate work differences. The subsequent24-call
string control aligns eight fixed scores, nodes and full routes.

The first immutable/Runtime audit encountered handcrafted empty history. Runtime
intentionally seeds root history. The first source and four completed real-root
rows remain; recovery explicitly normalizes handcrafted roots and does not rerun
the completed real roots. No history policy was weakened.

The initial delivered-index test tried whole compiled-object pickle, which
fails on an existing inspection/support mappingproxy. Preserve that test. IR
and the new derived mapping pickle successfully; whole-object pickle is not a
new public promise. A first mappingproxy index draft was replaced by the existing
private mapping convention; exact drafts are retained.

Prototype target_index_assay used the then-unindexed installed Core method.
Its current source would no longer isolate the same baseline if rerun blindly.
Recover the base78dc9925c277f4a27af45973bfee5fed90c832d7 source snapshot first.
The delivered probe explicitly disables the private derived index for reference
and is reproducible with final sources. The poll prototype also used the base
diagnostic dispatcher; preserve base source and inline clone, not a claim that
current-code substitution replays the earlier intervention.

First tracemalloc metadata measurements include allocator/free-list reuse and
are not RSS. A changed measurement premise flushes free lists before tracing,
also counts unique owned containers excluding already-shared compiled records.
Retain both measurements. The65536 overflow stress is a bounded IR-helper test,
not an admitted new gameplay ruleset or utility cohort.

The fifth session checkpoint says143 positions; the exact dataset contains134.
A later checkpoint corrects this; old session evidence is not rewritten.

Slack raw messages, account records, request/receipt/payload hashes and outgoing
text stay local and are excluded from publication. The peer assessment is based
on supplied snippets/results, not independent source execution. Rendering changes
the code fence; receipt associates the thread but importer reports byte-unverified
readback. No instruction or workflow update is inferred from this technical review.

Native caller pilot initially set GameSession's read-only _search_witnesses
property and failed before any measurement. Preserve first source; recovery
assigns actual _search_history_witnesses storage.24fixed/24cancel controls are
complete but mean post-kernel cost is essentially unchanged after the shared
index (fixed4.56 vs4.54ms;cancel3.97 vs4.09ms). Peak cancellation tail improves
in this small sample, without average/completion gain. Defer Runtime validation;
final product retains immutable validation. The exact tested candidate is
archived. Replaying the Native pilot requires its saved candidate search method,
not blind execution against the restored final immutable method.
