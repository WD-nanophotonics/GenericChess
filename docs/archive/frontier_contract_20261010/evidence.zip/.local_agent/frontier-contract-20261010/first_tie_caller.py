def iterative_root_search(board, *, seconds, node_limit, max_depth=12,
                          cooperative=False, cancellation=None, validate_pv=True):
    """Keep replay validation by default; expose its caller cost separately.

    ``validate_pv=False`` returns labels captured from searched legal frontiers.
    It omits independent post-search replay, not search legality/budget checks.
    This diagnostic mode does not establish an independent PV witness.
    """
    start = perf_counter()
    terminal = board.terminal(0)
    if terminal is not None:
        return dict(move=None, action=None, score=terminal, pv_labels=[],
                    completed_depth=0, exit_cause='terminal_position',
                    work={}, iterations=[], used_fallback=False,
                    preparation_seconds=perf_counter()-start,
                    search_seconds=0., validation_seconds=0.,
                    caller_seconds=perf_counter()-start, root_restored=board.restored())
    frontier = board.actions()
    if not frontier:
        raise ValueError('nonterminal diagnostic root has no legal action')
    first = frontier[0]
    keys = {move: label for label, move in frontier}
    preparation = perf_counter()-start
    total, iterations, completed = {}, [], None
    for depth in range(1, max_depth+1):
        result = root_search(board, depth, mode='verified',
            canonical_key=lambda action: 0, node_limit=node_limit-total.get('nodes',0),
            seconds=seconds-(perf_counter()-start), cooperative=cooperative,
            cancellation=cancellation)
        for key, value in result['work'].items():
            total[key] = total.get(key,0)+value
        iterations.append(result)
        if not result['completed_depth']:
            break
        completed = result
    search_finished = perf_counter()
    action = completed['action'] if completed else first[1]
    pv = completed['pv'] if completed else (action,)
    labels = []
    pushed = 0
    try:
        for move in pv if validate_pv else ():
            frontier = {m: label for label, m in board.actions()}
            if move not in frontier:
                raise AssertionError('diagnostic PV contains illegal action')
            labels.append(frontier[move])
            board.push(move)
            pushed += 1
    finally:
        for _ in range(pushed):
            board.pop()
    end = perf_counter()
    if not validate_pv:
        labels = list(completed['pv_labels']) if completed else [first[0]]
    if not board.restored() or total.get('nodes',0)>node_limit:
        raise AssertionError('diagnostic root/cap invariant')
    return dict(move=completed['move'] if completed else first[0], action=action,
                score=completed['score'] if completed else None, pv_labels=labels,
                completed_depth=completed['completed_depth'] if completed else 0,
                used_fallback=completed is None,
                pv_validation='independent_replay' if validate_pv else 'searched_frontiers',
                exit_cause=iterations[-1]['exit_cause'] if iterations else 'depth_limit',
                work=total, iterations=iterations, preparation_seconds=preparation,
                search_seconds=search_finished-start-preparation,
                validation_seconds=end-search_finished, caller_seconds=end-start,
                budgeted_seconds=search_finished-start, cap_seconds=seconds,
                cap_nodes=node_limit, root_restored=True)
