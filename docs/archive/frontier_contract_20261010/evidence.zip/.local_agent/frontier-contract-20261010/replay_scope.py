"""Independent immutable/runtime replay audit, not a search or strength test.
Existing four comparison roots, legacy capture/promotion/drop, existing semantic
castling/EP and five nonempty weird fixtures, repetition threshold and two
continuous-check histories. At most24 root actions (semantic effect first) and
first lexical response; depth2. Compare complete positions/aux/hands/base types,
ply, terminal, every history identity/actor/signature/check and all repetition
counts. Also duplicate-action rejection and balanced rollback. Expected<2min.
This finite scope decides whether the cheap replay validation prototype can
be applied at its existing Native caller; unsupported full-Native rules excluded
from caller integration, never deleted from generic Core semantics.
"""
from pathlib import Path
import sys,json,hashlib
from dataclasses import replace
from collections import Counter
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));sys.path.insert(0,str(ROOT/'tests/product'))
folder=Path(__file__).parent;f=folder/'assay.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
from generic_chess.core.search_runtime import SearchPathRuntime,RuntimePositionIdentity
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action,initial_state,legal_successors
from generic_chess.core.errors import IllegalActionError
from generic_chess.core.pieces import Piece
from generic_chess.core.position import HistoryRecord
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from conftest import T,king_type,make_compiled,make_state
from generic_chess.core.movement import LeapAtom,RayAtom
from rule_semantics_ir_fixtures import weird_rulesets,castling_ruleset,en_passant_ruleset
from test_native_history import _cycle_ruleset,_session_at_ply
from test_search_path_runtime import _continuous_history_pair
roots=[]
for name,factory,values in ns['ns']['factories']:
 core=factory();roots.append((name,core.compiled,core.initial,core.witnesses))
pawn=T('P',LeapAtom((0,1)),is_promotable=True,targets=('G',));gold=T('G',LeapAtom((1,0)),LeapAtom((-1,0)),LeapAtom((0,1)),LeapAtom((0,-1)));rook=T('R',RayAtom((1,0)),RayAtom((-1,0)),RayAtom((0,1)),RayAtom((0,-1)))
compiled=make_compiled(8,[king_type(),pawn,gold,rook],auto_drop=True,auto_promotion=True)
for name,lines,hands in (
 ('legacy-capture',['.......k','........','........','........','........','r.......','........','R......K'],None),
 ('legacy-promotion',['.......k','....P...','........','........','........','........','........','K.......'],None),
 ('legacy-drop',['.......k','........','........','........','........','........','........','K.......'],([('P',1)],[])),
):
 state=make_state(compiled,lines,**({'hands':hands} if hands else {}));roots.append((name,compiled,state,None))
for name,rules in [('castle',castling_ruleset()),('ep-fixture',en_passant_ruleset()),*[(f'weird-{i}',r) for i,r in enumerate(weird_rulesets())]]:
 if name.startswith('weird'):
  rows=[list(row) for row in rules.initial_position]
  rows[2][2]=Piece(0,'R','R');rows[3][2]=Piece(0,'R','R');rows[5][5]=Piece(1,'R','R')
  rules=replace(rules,initial_position=tuple(tuple(row) for row in rows))
 c=compile_semantic_ruleset(rules);state=initial_state(c);roots.append((name,c,state,(state.position,)))
c=_cycle_ruleset()
for ply in (3,11):
 session=_session_at_ply(c,ply);roots.append((f'cycle-{ply}',c,session.state,session._search_witnesses))
c,states,paths=_continuous_history_pair()
for index,state in enumerate(states):roots.append((f'continuous-{index}',c,state,None))
def projection(runtime,c):
 return [(position_identity_key(r.identity.position,c) if isinstance(r.identity,RuntimePositionIdentity) else r.external_key,r.actor,r.action_signature,r.gave_check) for r in runtime.history]
def audit(state,runtime,c):
 assert runtime.position==state.position and runtime.ply_count==state.ply_count and runtime.terminal_status==state.terminal_status
 history=projection(runtime,c);assert history==[(r.position_key,r.actor,r.action_signature,r.gave_check) for r in state.history]
 assert Counter(h[0] for h in history)==dict(state.repetition_counts)
 assert runtime.occurrence_count()==dict(state.repetition_counts).get(position_identity_key(state.position,c),0)
 assert set(runtime.legal_actions())==set(a for a,_ in legal_successors(state,c))
 return history
out=folder/'replay-scope.json';report=json.loads(out.read_bytes())
report['recovery_source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report['recovery']='Empty-history handcrafted helper is explicitly seeded with one root occurrence; preserve first four completed real-root rows.'
for name,c,state,witnesses in roots[len(report['rows']):]:
 for flag in ('rollout','advisor','slack'):
  flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
 if not state.history:
  key=position_identity_key(state.position,c);state=replace(state,history=(HistoryRecord(key,-1,'',False),),repetition_counts=((key,1),));witnesses=(state.position,)
 start=perf_counter();runtime=SearchPathRuntime.from_state(state,c,history_witnesses=witnesses);before=audit(state,runtime,c);actions=sorted(runtime.legal_actions(),key=lambda a:(not bool(getattr(a,'pattern_id',None)),str(a)))[:24];count=0;effects=Counter();rejects=0
 for action in actions:
  child=apply_action(state,action,c);runtime.push(action);audit(child,runtime,c);count+=1
  effects['promotion']+=int(any(p is not None and p.current_type_id!=p.base_type_id for p in child.position.board));effects['aux_changed']+=int(child.position.aux_state!=state.position.aux_state);effects['hands_changed']+=int(child.position.hands!=state.position.hands)
  replies=sorted(runtime.legal_actions(),key=str)
  if replies:
   grand=apply_action(child,replies[0],c);runtime.push(replies[0]);audit(grand,runtime,c);count+=1;runtime.pop();audit(child,runtime,c)
  for validator in ('immutable','runtime'):
   try:
    if validator=='immutable':apply_action(child,action,c)
    else:runtime.push(action)
   except IllegalActionError:rejects+=1
   else:raise AssertionError(('duplicate route unexpectedly legal',name,action,validator))
  runtime.pop();runtime.assert_balanced();assert projection(runtime,c)==before
 report['rows'].append({'case':name,'root_actions_total':len(runtime.legal_actions()),'root_actions_tested':len(actions),'state_pairs':count,'effects':dict(effects),'illegal_rejections':rejects,'wall_seconds':perf_counter()-start,'complete_root_restored':True});out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(name,count,dict(effects),flush=True)
report['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
