"""Scoped immutable syntax/label ablation, not a product default.
Six existing roots; fresh per-call caches capped at2048 entries. Raw packed
actions define immutable syntax in one compiled rules instance. Every actions()
still runs live C guarded_actions; no legal frontier, state, history or terminal
cache. Common lexical AB/order/material/terminal score stay unchanged. Fixed
D8/4096entries/30sec fuse, two reversed passes; separate1sec iterative controls.
Unknown: is action conversion enough cost to change completion? If traces differ,
reject. Speed alone is scoped overhead evidence, not playing strength. Estimated
incremental run below1min, interruptible at each call; no frozen budget extension.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
namespace={"__file__":str(Path(__file__).with_name('bridge_assay.py'))}
exec(Path(namespace['__file__']).read_text().split("source=ROOT/")[0],namespace)
GeneratedBoard=namespace['GeneratedBoard']
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES,minimal_ab,iterative_minimal
from scripts.native_backend_bridge import NativeBoard,audit_native_tree
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.semantic import guarded_actions,public_action

class CachedSyntax(NativeBoard):
 def __init__(self,*args):
  super().__init__(*args);self.syntax={};self.hits=0;self.misses=0;self.clears=0
 def actions(self):
  result=[]
  for raw in guarded_actions(self.native,self.position):
   key=raw
   entry=self.syntax.get(key)
   if entry is None:
    self.misses+=1
    entry=(self.label(public_action(self.native,raw)),raw)
    if len(self.syntax)>=2048:self.syntax.clear();self.clears+=1
    self.syntax[key]=entry
   else:self.hits+=1
   result.append(entry)
  return sorted(result,key=lambda x:x[0])

coverage=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes())
factories=[]
for case in CASES[:4]:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
 factories.append((case['id'],lambda case=case,c=c:CoreBoard(case,c),VALUES['chess']))
for seed in (202610082000,202610082001):
 case=next(x for x in coverage['cases'] if x['seed']==seed)
 factories.append((f'generated-{seed}-ply3',lambda case=case:GeneratedBoard(case),GeneratedBoard(case).values))
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixed=[],timed=[],audits=[],complete=False)
output=Path(__file__).with_name('syntax-ablation.json')
def save():output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def stopped():
 for name in ('rollout.json','advisor.json','slack.json'):
  flag=json.loads((ROOT/'.local_agent'/name).read_bytes())
  if flag.get('user_paused') or flag.get('stopped'):raise RuntimeError('project stopped')
start=perf_counter()
try:
 for name,factory,values in factories:
  stopped();core=factory();cached=CachedSyntax(core,values)
  count=audit_native_tree(core,cached,1)
  report['audits'].append(dict(case=name,states=count))
  for kind in ('fixed','timed'):
   for repeat,order in enumerate(((NativeBoard,CachedSyntax),(CachedSyntax,NativeBoard))):
    for cls in order:
     stopped();t=perf_counter();board=cls(factory(),values);setup=perf_counter()-t
     row=(minimal_ab(board,8,seconds=30,node_limit=4096,trace=True) if kind=='fixed' else iterative_minimal(board,seconds=1,node_limit=100000,max_depth=12))
     row.update(case=name,backend=cls.__name__,repeat=repeat,setup_seconds=setup)
     if cls is CachedSyntax:row['cache']=dict(entries=len(board.syntax),hits=board.hits,misses=board.misses,clears=board.clears,shallow_bytes=sys.getsizeof(board.syntax)+sum(sys.getsizeof(k)+sys.getsizeof(v)+sys.getsizeof(v[0]) for k,v in board.syntax.items()))
     assert board.restored()
     report[kind].append(row);save()
     print(name,kind,repeat,cls.__name__,round(row['wall_seconds'],4),row.get('completed_depth'),flush=True)
  rows=[x for x in report['fixed'] if x['case']==name]
  signature=lambda x:(x['work'],x['move'],x['score'],x['reason'],x['trace_sha256'])
  assert all(signature(x)==signature(rows[0]) for x in rows),name
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()

