"""Full-state Native attribution bridge, six existing roots chosen by identifiers.
Fixed D8/4096entries/30sec fuse, two reversed passes, identical lexical AB and
material. Core, Native-legality/Core-state, Native-state/Python-AB; python-chess
as specialized rules control on four Chess roots. Each call starts a fresh
adapter. Equal-time1sec/D12/100000entry controls separately use the common bare
iterative driver, not Native packed-order iterative search. Audit all D1 child
states/history before timings. No new rules, labels, tuning, large games or C
binary changes. Scope excludes Native loss-policy rules and declarations as
search options. All timed caps/adverse outcomes retained.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native import _module
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES,ChessBoard,minimal_ab,iterative_minimal
from scripts.native_backend_bridge import NativeBoard,audit_native_tree

class GeneratedBoard:
 def __init__(self,case):
  self.compiled=compile_ruleset_for_execution(ruleset_from_dict(case['rules']))
  session=GameSession(self.compiled)
  for step in case['route'][:3]:session.submit(action_from_dict(step['action']))
  self.initial=session.state;self.witnesses=tuple(session._search_witnesses)
  self.runtime=SearchPathRuntime.from_state(self.initial,self.compiled,history_witnesses=self.witnesses)
  self.label=lambda a:json.dumps(action_to_dict(a),sort_keys=True,separators=(',',':'))
  self.checkpoint=None
  self.values={p.type_id:0 if p.is_anchor else 100 for p in self.compiled.piece_types}
 actions=CoreBoard.actions;push=CoreBoard.push;pop=CoreBoard.pop
 terminal=CoreBoard.terminal;restored=CoreBoard.restored
 def evaluate(self):
  p=self.runtime.position
  return sum((1 if x.owner==p.side_to_move else -1)*self.values[x.current_type_id] for x in p.board if x is not None)+sum((1 if o==p.side_to_move else -1)*self.values[t]*n for o,h in enumerate(p.hands) for t,n in h.items())

source=ROOT/'.local_agent/generated6-20261008/coverage.json'
coverage=json.loads(source.read_bytes())
factories=[]
for case in CASES[:4]:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
 factories.append((case['id'],lambda case=case,c=c:CoreBoard(case,c),VALUES['chess'],case))
for seed in (202610082000,202610082001):
 case=next(x for x in coverage['cases'] if x['seed']==seed)
 values=GeneratedBoard(case).values
 factories.append((f'generated-{seed}-ply3',lambda case=case:GeneratedBoard(case),values,None))
report=dict(schema=1,declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 bridge_sha256=hashlib.sha256((ROOT/'scripts/native_backend_bridge.py').read_bytes()).hexdigest(),
 input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(Path(_module().__file__).read_bytes()).hexdigest(),
 audits=[],fixed=[],timed=[],complete=False)
out=Path(__file__).with_name('bridge-assay.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def stopped():
 for file in ('rollout.json','advisor.json','slack.json'):
  flag=json.loads((ROOT/'.local_agent'/file).read_bytes())
  if flag.get('user_paused') or flag.get('stopped'):raise RuntimeError('project stopped')
start=perf_counter()
try:
 for name,factory,values,case in factories:
  stopped();core=factory();native=NativeBoard(core,values)
  t=perf_counter();checked=audit_native_tree(core,native,1)
  report['audits'].append(dict(case=name,states=checked,seconds=perf_counter()-t,rule_fingerprint=core.compiled.ruleset_fingerprint))
  save();print(name,'audit',checked,flush=True)
  def make(mode):
   if mode=='specialized':return ChessBoard(case)
   b=factory()
   if mode=='native_state':return NativeBoard(b,values)
   if mode=='native_legality':
    provider=NativeSemanticLegalityProvider.try_create(b.compiled,strict=True)
    assert provider is not None
    b.runtime=SearchPathRuntime.from_state(b.initial,b.compiled,history_witnesses=b.witnesses,legal_binding_provider=provider)
   return b
  modes=['core','native_legality','native_state']+(['specialized'] if case else [])
  for repeat,order in enumerate((modes,list(reversed(modes)))):
   for mode in order:
    stopped();t=perf_counter();b=make(mode);setup=perf_counter()-t
    row=minimal_ab(b,8,seconds=30,node_limit=4096,trace=True)
    row.update(case=name,backend=mode,repeat=repeat,setup_seconds=setup)
    report['fixed'].append(row);save()
    print(name,'fixed',repeat,mode,row['work']['nodes'],round(row['wall_seconds'],3),row['reason'],flush=True)
  rows=[r for r in report['fixed'] if r['case']==name]
  signature=lambda r:(r['work'],r['move'],r['score'],r['reason'],r['trace_sha256'])
  assert all(signature(r)==signature(rows[0]) for r in rows),name
  for repeat,order in enumerate((modes,list(reversed(modes)))):
   for mode in order:
    stopped();b=make(mode)
    row=iterative_minimal(b,seconds=1,node_limit=100000,max_depth=12)
    row.update(case=name,backend=mode,repeat=repeat)
    report['timed'].append(row);save()
    print(name,'timed',repeat,mode,row['completed_depth'],row['work']['nodes'],flush=True)
 report['complete']=True
finally:
 report['seconds']=perf_counter()-start;save()
