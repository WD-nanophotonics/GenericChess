def search(
    self,
    session,
    limits: SearchLimits,
    cancel_token: CancellationToken | None = None,
    *,
    root_order_hint: Action | None = None,
    root_window_pruning: bool = False,
    trace_enabled: bool = False,
) -> SemanticIterativeSearchResult:
    if root_order_hint is not None and (
        self._ordering_checkpoint_id is not None or self._policy_model is not None
    ):
        raise ValueError("root_order_hint cannot be combined with learned move ordering")
    if self._compiled.ruleset_fingerprint != session.compiled.ruleset_fingerprint:
        raise ValueError("session ruleset fingerprint does not match semantic engine")
    if limits.max_depth is None:
        raise ValueError("SemanticSearchEngine requires max_depth")
    if not 0 <= limits.max_depth <= GC_SEM_MAX_PLY:
        raise ValueError(f"max_depth must be in [0, {GC_SEM_MAX_PLY}]")
    if limits.max_nodes is not None and limits.max_nodes < 0:
        raise ValueError("max_nodes must be >= 0")
    if limits.max_time_seconds is not None and not (
        0 <= limits.max_time_seconds
        and limits.max_time_seconds == limits.max_time_seconds
        and abs(limits.max_time_seconds) != float("inf")
    ):
        raise ValueError("max_time_seconds must be a finite non-negative value")
    if limits.quiescence_max_depth != 0 or limits.quiescence_max_nodes not in (None, 0):
        raise ValueError("SemanticSearchEngine does not implement qsearch")
    if not isinstance(root_window_pruning, bool):
        raise TypeError("root_window_pruning must be a bool")
    _require_root_window_support(root_window_pruning)
    if not isinstance(trace_enabled, bool):
        raise TypeError("trace_enabled must be a bool")
    if session.result.status.value != "ongoing":
        return SemanticIterativeSearchResult(
            0, None, None, (), (), 0, 0, 0, 0, 0.0,
            "terminal_position", False, "NOT_STARTED", 0, 0, 0, 0, 0, 0, 0,
        )

    position = pack_semantic_search_position(self._compiled, self._native_rules, session)
    packed_root_hint = None if root_order_hint is None else int(
        pack_semantic_action(self._native_rules, session.state.position, root_order_hint)
    )
    flag = None
    unregister = None
    if cancel_token is not None:
        flag = _module().create_cancel_flag()
        unregister = cancel_token.register_callback(
            lambda: _module().request_cancel(flag)
        )
    try:
        raw = dict(_module().semantic_engine_search(
            self._capsule,
            position,
            int(limits.max_depth),
            None if limits.max_nodes is None else int(limits.max_nodes),
            None if limits.max_time_seconds is None else float(limits.max_time_seconds),
            flag,
            packed_root_hint,
            root_window_pruning,
            trace_enabled,
        ))
    finally:
        if unregister is not None:
            unregister()

    declaration_id = raw.get("declaration_id")
    declaration_id = None if declaration_id is None else str(declaration_id)
    packed_best = raw.get("best_action")
    action = None if packed_best is None else public_action(
        self._native_rules, int(packed_best)
    )
    decision_line = []
    for packed in raw.get("principal_variation", ()):
        packed = int(packed)
        if packed & DECLARATION_ACTION_TAG:
            index = packed & 0xFF
            if index >= len(self._native_rules.declarations):
                raise ValueError("semantic search returned invalid declaration decision")
            decision_line.append(self._native_rules.declarations[index].declaration_id)
        else:
            decision_line.append(public_action(self._native_rules, packed))
    if declaration_id is not None and not decision_line:
        decision_line.append(declaration_id)
    pv = tuple(item for item in decision_line if not isinstance(item, str))
    validation = SearchPathRuntime.from_state(session.state, self._compiled,
        history_witnesses=getattr(session, '_search_history_witnesses', None))
    for pv_action in pv:
        validation.push(pv_action)

    leaf_dynamic: tuple[int, int, int] = ()
    if pv:
        leaf_position = position
        for packed in raw.get("principal_variation", ()):
            packed = int(packed)
            if packed & DECLARATION_ACTION_TAG:
                break
            leaf_position = _module().semantic_make_checked(
                self._native_rules.capsule, leaf_position, packed
            )
        from .semantic import dynamic_features as native_dynamic_features
        leaf_dynamic = native_dynamic_features(self._native_rules, leaf_position)

    root_first_actions = []
    for packed in raw.get("root_iteration_first_actions", ()):
        packed = None if packed is None else int(packed)
        root_first_actions.append(
            None if packed is None else public_action(self._native_rules, packed)
        )

    return SemanticIterativeSearchResult(
        score=int(raw["score"]),
        action=action,
        declaration_id=declaration_id,
        principal_variation=pv,
        decision_line=tuple(decision_line),
        completed_depth=int(raw["completed_depth"]),
        selective_depth=int(raw["selective_depth"]),
        nodes=int(raw["nodes"]),
        qnodes=int(raw.get("qnodes", 0)),
        elapsed_seconds=int(raw["elapsed_nanoseconds"]) / 1e9,
        termination_reason=str(raw["termination_reason"]),
        used_fallback=bool(raw["used_fallback"]),
        tt_status=str(raw.get("tt_status", "NOT_STARTED")),
        tt_probes=int(raw.get("tt_probes", 0)),
        tt_hits=int(raw.get("tt_hits", 0)),
        tt_cutoffs=int(raw.get("tt_cutoffs", 0)),
        tt_stores=int(raw.get("tt_stores", 0)),
        tt_replacements=int(raw.get("tt_replacements", 0)),
        tt_entry_bytes=int(raw.get("tt_entry_bytes", 0)),
        tt_allocated_bytes=int(raw.get("tt_allocated_bytes", 0)),
        dynamic_features=leaf_dynamic,
        root_hint_requested=root_order_hint,
        root_hint_legal=bool(raw.get("root_hint_legal", False)),
        root_hint_apply_count=int(raw.get("root_hint_apply_count", 0)),
        root_iterations_attempted=int(raw.get("root_iterations_attempted", 0)),
        root_iteration_first_actions=tuple(root_first_actions),
        root_window_pruning=bool(raw.get("root_window_pruning", False)),
        beta_cutoffs=int(raw.get("beta_cutoffs", 0)),
        legal_generation_count=(int(raw["legal_generation_count"])
                                if "legal_generation_count" in raw else None),
        transition_count=(int(raw["transition_count"])
                          if "transition_count" in raw else None),
        learned_move_ordering=bool(raw.get("learned_move_ordering", False)),
        ordering_checkpoint_id=self._ordering_checkpoint_id,
        ordering_evaluations=int(raw.get("ordering_evaluations", 0)),
        ordering_nodes=int(raw.get("ordering_nodes", 0)),
        ordering_actions=int(raw.get("ordering_actions", 0)),
        ordering_elapsed_seconds=int(raw.get("ordering_elapsed_nanoseconds", 0)) / 1e9,
        ordering_cache_hits=int(raw.get("ordering_cache_hits", 0)),
        ordering_cache_misses=int(raw.get("ordering_cache_misses", 0)),
        ordering_cache_collisions=int(raw.get("ordering_cache_collisions", 0)),
        ordering_cache_hit_rate=float(raw.get("ordering_cache_hit_rate", 0.0)),
        ordering_cache_capacity=int(raw.get("ordering_cache_capacity", 0)),
        ordering_cache_entry_bytes=int(raw.get("ordering_cache_entry_bytes", 0)),
        ordering_max_ply=int(raw.get("ordering_max_ply", -1)),
        ordering_min_depth=int(raw.get("ordering_min_depth", 1)),
        ordering_evaluations_by_ply=tuple(int(value) for value in raw.get("ordering_evaluations_by_ply", ())),
        ordering_nodes_by_ply=tuple(int(value) for value in raw.get("ordering_nodes_by_ply", ())),
        ordering_actions_by_ply=tuple(int(value) for value in raw.get("ordering_actions_by_ply", ())),
        ordering_elapsed_nanoseconds_by_ply=tuple(int(value) for value in raw.get("ordering_elapsed_nanoseconds_by_ply", ())),
        ordering_cache_hits_by_ply=tuple(int(value) for value in raw.get("ordering_cache_hits_by_ply", ())),
        ordering_cache_misses_by_ply=tuple(int(value) for value in raw.get("ordering_cache_misses_by_ply", ())),
        ordering_cache_collisions_by_ply=tuple(int(value) for value in raw.get("ordering_cache_collisions_by_ply", ())),
        ordering_skipped_by_remaining_depth=tuple(int(value) for value in raw.get("ordering_skipped_by_remaining_depth", ())),
        policy_ordering=bool(raw.get("policy_ordering", False)),
        policy_nodes=int(raw.get("policy_nodes", 0)),
        policy_state_inferences=int(raw.get("policy_state_inferences", 0)),
        policy_actions_scored=int(raw.get("policy_actions_scored", 0)),
        policy_action_embeddings=int(raw.get("policy_action_embeddings", raw.get("policy_actions_scored", 0))),
        policy_elapsed_seconds=int(raw.get("policy_elapsed_nanoseconds", 0)) / 1e9,
        policy_model_sha256=self.policy_model_sha256,
        policy_deferred_legality=bool(raw.get("policy_deferred_legality", False)),
        policy_preorder_checked_transitions=int(raw.get("policy_preorder_checked_transitions", 0)),
        policy_traversal_checked_attempts=int(raw.get("policy_traversal_checked_attempts", 0)),
        policy_traversal_illegal_skips=int(raw.get("policy_traversal_illegal_skips", 0)),
        policy_min_depth=int(raw.get("policy_min_depth", 2)),
        policy_nodes_by_ply=tuple(int(value) for value in raw.get("policy_nodes_by_ply", ())),
        policy_state_inferences_by_ply=tuple(int(value) for value in raw.get("policy_state_inferences_by_ply", ())),
        policy_actions_scored_by_ply=tuple(int(value) for value in raw.get("policy_actions_scored_by_ply", ())),
        policy_elapsed_nanoseconds_by_ply=tuple(int(value) for value in raw.get("policy_elapsed_nanoseconds_by_ply", ())),
        training_trace=tuple(dict(row) for row in raw.get("training_trace", ())),
        training_trace_enabled=bool(raw.get("training_trace_enabled", False)),
        training_trace_count=int(raw.get("training_trace_count", 0)),
        training_trace_raw_count=int(raw.get("training_trace_raw_count", 0)),
    )
