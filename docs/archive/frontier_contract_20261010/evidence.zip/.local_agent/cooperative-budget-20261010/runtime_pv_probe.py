"""Core-authoritative PV validation data-plane prototype, no validation removal.
Current high-level Native validates each PV with immutable Core apply_action,
then replays Native for leaf features; temporary state is otherwise unused.
Compare Core SearchPathRuntime's legal/fullhistory push validation instead.
Three existing roots xTT0/64 x2reversed xbaseline/runtime =24coldD3calls, plus
each returned PV independently replayed immutable-vs-runtime complete states.
Same kernel outputs/work/leaf features required. Counterfeit illegal PV remains
rejected by both; no Cbuild/cancelthrottling/searchbudget or UI changes.
Expected<2min; serial after cancellation phase assay.
"""
from pathlib import Path
import json,hashlib,inspect,textwrap
from time import perf_counter
from dataclasses import asdict
from contextlib import contextmanager
folder=Path(__file__).parent;f=folder/'replay_accounting.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=')[0],ns)
import generic_chess.native.semantic_engine as module
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import position_identity_key
original=module.SemanticSearchEngine.search
source=textwrap.dedent(inspect.getsource(original))
old='state = session.state\n    for pv_action in pv:\n        state = apply_action(state, pv_action, self._compiled)'
new="validation = SearchPathRuntime.from_state(session.state, self._compiled,\n        history_witnesses=getattr(session, '_search_history_witnesses', None))\n    for pv_action in pv:\n        validation.push(pv_action)"
assert source.count(old)==1
scope=dict(module.__dict__,SearchPathRuntime=SearchPathRuntime);exec(source.replace(old,new),scope)
prototype=scope['search'];(folder/'runtime_validation_method.py').write_bytes(source.replace(old,new).encode())
@contextmanager
def active():
 module.SemanticSearchEngine.search=prototype
 try:yield
 finally:module.SemanticSearchEngine.search=original
def state_audit(core,pv):
 immutable=core.initial;runtime=SearchPathRuntime.from_state(core.initial,core.compiled,history_witnesses=core.witnesses);states=0
 for action in pv:
  immutable=apply_action(immutable,action,core.compiled);runtime.push(action)
  assert immutable.position==runtime.position and immutable.ply_count==runtime.ply_count and immutable.terminal_status==runtime.terminal_status
  assert immutable.history[-1].actor==runtime.history[-1].actor and immutable.history[-1].gave_check==runtime.history[-1].gave_check
  assert position_identity_key(immutable.position,core.compiled)==position_identity_key(runtime.position,core.compiled)
  states+=1
 for _ in pv:runtime.pop()
 assert runtime.position==core.initial.position and runtime.depth==0
 return states
report={'declaration':__doc__,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':[],'complete':False};out=folder/'runtime-pv-probe.json'
from contextlib import nullcontext
for name,factory,values in ns['ns']['ns']['ns']['factories'][3:]:
 for mb in (0,64):
  cell=[]
  for repeat,order in enumerate((('baseline','runtime'),('runtime','baseline'))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ns['ns']['ROOT']/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();board=ns['ns']['ns']['NativeBoard'](core,values);session=ns['GameSession'](core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
    engine=module.SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=mb)
    start=perf_counter()
    with active() if mode=='runtime' else nullcontext():r=engine.search(session,ns['SearchLimits'](max_depth=3,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0))
    wall=perf_counter()-start;assert session.state==core.initial and board.restored();audit=state_audit(core,r.principal_variation);record=asdict(r);cell.append(record)
    report['rows'].append(ns['ns']['ns']['record_value']({'case':name,'tt_mb':mb,'mode':mode,'repeat':repeat,'caller_seconds':wall,'kernel_seconds':r.elapsed_seconds,'result':record,'state_pairs':audit}));out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
  sig=lambda r:{k:v for k,v in r.items() if 'seconds' not in k and 'nanoseconds' not in k}
  assert all(sig(r)==sig(cell[0]) for r in cell),name
report['complete']=True;out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print('24fixedNative results/runtime states exact')
