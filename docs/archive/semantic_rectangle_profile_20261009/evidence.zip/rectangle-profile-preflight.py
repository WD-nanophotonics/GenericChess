"""Rectangular opt-in profile feasibility; no default/profile-quality claim.
Use stripped semantic type metadata and shape area for existing drop diagnostics.
Anchor escape/promotion dynamics remain disabled; Core attack authority fixed.
"""
from pathlib import Path
import sys,types,hashlib,time
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from generic_chess.ai.evaluation import semantic
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from tests.product.test_rectangular_search_override import rectangular_cannon,UnusedProfileCache
from tests.product.test_semantic_zone_guards import zone_rule
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
start=time.perf_counter();m=semantic
config=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=0,promotion_potential_weight=0)
square=compile_ruleset_for_execution(build_western_chess_ruleset())
# Recover exact preceding candidate source, not a second copy of the new producer.
import subprocess
old_source=subprocess.check_output(['git','show','187b58f4f34f3befe25e774c76c16c7e8ea43a01:generic_chess/ai/evaluation/semantic.py'])
(root/'.local_agent/guard-projection-20261009/semantic-square-base.py').write_bytes(old_source)
old=types.ModuleType('generic_chess.ai.evaluation.square_base');old.__package__='generic_chess.ai.evaluation'
exec(compile(old_source,'<square_base>','exec'),old.__dict__)
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
square_checks=0
for builder in (build_western_chess_ruleset,build_standard_shogi_ruleset,build_xiangqi_diagnostic_ruleset):
 compiled=compile_ruleset_for_execution(builder())
 for cfg in (EvaluationConfig(),config):
  assert old.build_semantic_opportunity_profile(compiled,cfg)==semantic.build_semantic_opportunity_profile(compiled,cfg)
  square_checks+=1
rows=[]
for name,definition in [('cannon7x5',rectangular_cannon(7,5)),('cannon9x10',rectangular_cannon(9,10)),('zone5x3',zone_rule('target',True,'inside'))]:
 compiled=compile_ruleset_for_execution(definition);profile,scope=m.build_semantic_opportunity_profile(compiled,config)
 for tid in compiled.support.type_metadata:
  assert scope['types'][tid]==semantic.semantic_opportunity(compiled,tid,config)
 evaluator=SemanticAttackEvaluator(compiled,profile,config,backend='core');session=GameSession(compiled);before=session.state
 reference,action=reference_minimax(before,2,evaluator,compiled)
 calls=[]
 for q in (0,2):
  signatures=[]
  for repeat in range(2):
   player=AlphaBetaPlayer(compiled,evaluator_override=evaluator,profile_cache=UnusedProfileCache(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
   decision=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
   assert decision.completed_depth==2;validate_pv(session,decision);assert session.state==before
   if q==0:assert decision.score==reference
   signature=(record_value(decision.action),decision.score,decision.completed_depth,decision.nodes,decision.qnodes)
   signatures.append(signature);calls.append(dict(q=q,repeat=repeat,decision=record_value(decision)))
  assert signatures[0]==signatures[1]
 rows.append(dict(name=name,board_values=dict(profile.board_value_by_type),scope=scope,reference_score=reference,calls=calls))
write_record(root/'.local_agent/guard-projection-20261009/rectangle-profile-product.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),product_sha256=hashlib.sha256(Path(semantic.__file__).read_bytes()).hexdigest(),square_profile_exact_parity=True,square_profile_checks=square_checks,base_product_sha256=hashlib.sha256(old_source).hexdigest(),rows=rows,seconds=time.perf_counter()-start))
print(dict(roots=len(rows),calls=sum(len(r['calls']) for r in rows),seconds=time.perf_counter()-start))
