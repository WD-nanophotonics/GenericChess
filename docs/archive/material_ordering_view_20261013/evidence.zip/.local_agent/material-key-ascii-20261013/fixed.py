"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.search_backend_comparison import VALUES
from generic_chess import build_builtin_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning

from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
import hashlib,random
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)


base=ROOT/'.local_agent/q0-ordering-view-20261012';out=ROOT/'.local_agent/material-key-ascii-20261013/fixed';out.mkdir(exist_ok=True);assert not(out/'result.json').exists()
roots=['generated1091-turn2','Shogi0']
write_record(out/'declaration.json',json.loads((ROOT/'.local_agent/material-key-ascii-20261013/declaration.json').read_bytes()))
modules={}
for arm in ['full','ascii_runs']:
 p=(ROOT/'.local_agent/material-key-ascii-20261013'/arm)/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('order_'+arm+'._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
write_record(out/'modules.json',{k:dict(source_sha256=hashlib.sha256((ROOT/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()) for k,m in modules.items()})
samples=[]
for x in json.loads((ROOT/'.local_agent/q0-trace-rebuild-20261012/input-closure.json').read_bytes()):
 if (x['root'],x['turn']) not in [('generated1091',2),('shogi-middle',0)]:continue
 x=dict(x);x['root']='generated1091-turn2' if x['root']=='generated1091' else 'Shogi0';x['source_mode']='execution';samples.append(x)
for x in json.loads((ROOT/'.local_agent/q0-refine-generated-20261012/samples.json').read_bytes()):
 if x['root'] not in roots:continue
 x=dict(x);x['source_mode']='metadata';samples.append(x)
samples=[x for x in samples if x['root'] in roots]
assert {x['root'] for x in samples}==set(roots);write_record(out/'input-closure.json',samples)
rows=[]
for sample in samples:
 if sample['source_mode']=='execution':
  c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi')) if sample['rules']=='builtin:standard_shogi' else compile_ruleset_for_execution(ruleset_from_dict(json.loads(sample['rules'])))
 else:
  src=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(sample['rules']));c=SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
 d=sample['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));w=tuple(position(x) for x in sample['witnesses']);session=SimpleNamespace(compiled=c,state=state,_search_witnesses=w,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 bv,hv=sample['board'],sample['hand'];ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
 for depth in [6]:
  for order,arms in enumerate([['full','ascii_runs'],['ascii_runs','full']]):
   for arm in arms:
    for flag in ['rollout','advisor','slack']:
     f=json.loads((ROOT/'.local_agent'/(flag+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused')
    native._MODULE=modules[arm];provider=NativeSemanticLegalityProvider.try_create(c,strict=True)
    e=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2,ordering_cache_enabled=False)
    raw=[];old=modules[arm].semantic_engine_search
    def counted(*a):
     x=old(*a);raw.append(dict(x));return x
    modules[arm].semantic_engine_search=counted
    before=record_value(state);t=time.perf_counter()
    try:r=e.search(session,SearchLimits(max_depth=depth,max_nodes=None,max_time_seconds=90,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True)
    finally:modules[arm].semantic_engine_search=old
    sec=time.perf_counter()-t;assert record_value(state)==before;ps=state
    for a in r.principal_variation:assert a in legal_actions(ps,c);ps=apply_action(ps,a,c)
    assert r.action in legal_actions(state,c);assert r.completed_depth==depth
    rows.append(dict(root=sample['root'],depth=depth,arm=arm,order=order,seconds=sec,result=record_value(r),raw=raw[0],pv_legal=True,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(sample['root'],order,arm,round(sec,3),r.completed_depth,r.score,r.nodes,flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
