
import sys,sysconfig,importlib.util,json,random,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R))
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.native.compiler import build_semantic_compile_payload
from scripts.research_record import write_record
out=R/'.local_agent/material-key-decimal-20261013'
modules={}
for arm in ['full','decimal']:
 p=out/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 sp=importlib.util.spec_from_file_location('ascii'+arm+'._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
payload,_=build_semantic_compile_payload(compile_ruleset_for_execution(build_western_chess_ruleset()))
sets=[['ASCII','Q"quote','slash\\end','line\nbreak','制御é','😀'],
      ['\b','\f','\r','\t','\x01','\x1f'],
      ['α','日本語','é','𝄞','𐀀','end\\"']]
write_record(out/'identity-declaration.json',dict(type_id_sets=sets,positions_per_set=32,seed=2026101300,checks=192,scope='Boundary descriptors with valid nonNUL UTF8/public escapes and random typed board/hand fields; representational identity test, not reachable games or training. Compare both actualC digests to independent exactjson sha.'))
rng=random.Random(2026101300);rows=[]
for ids in sets:
 p=dict(payload,type_ids=ids)
 caps={arm:m.compile_semantic_rules(p) for arm,m in modules.items()}
 for case in range(32):
  cells=[None if rng.randrange(3)==0 else [rng.randrange(6),0,rng.randrange(2),1] for _ in range(64)]
  for cell in cells:
   if cell:cell[1]=cell[0]
  hands=[[rng.randrange(4) for _ in ids] for side in range(2)];side=rng.randrange(2)
  position=dict(board=cells,hands=hands,side=side,ply=0,aux=[])
  # The rules have castling/EP auxiliary slots, with default null values.
  digests={};snaps={}
  for arm,m in modules.items():
   packed=m.semantic_pack_position(caps[arm],position)
   digests[arm]=m.semantic_position_key(caps[arm],packed)
   snaps[arm]=dict(m.semantic_position_snapshot(caps[arm],packed))
  snap=snaps['full']
  aux={f'{x[0]}:{x[1]}':x[2] for x in snap['aux_state']} if 'aux_state' in snap else {f'{x[0]}:{x[1]}':x[2] for x in snap.get('aux',[])}
  expected=dict(aux_state=aux,board=[None if x is None else [x[2],ids[x[0]],ids[x[1]],bool(x[3])] for x in snap['board']],hands=[[[[ids[t],n] for t,n in sorted(enumerate(h),key=lambda v:ids[v[0]]) if n] for h in snap['hands']]],ruleset=payload['fingerprint'],side_to_move=side)
  encoded=json.dumps(expected,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
  key=hashlib.sha256(encoded).hexdigest()
  assert len(set(digests.values()))==1
  assert digests['full']==key,(snap,expected,digests,key)
  rows.append(dict(type_ids=ids,case=case,expected_sha256=key,actual=digests))
write_record(out/'identity-result.json',dict(complete=True,rows=rows))
print(len(rows)*2,'C identities match independentJSON')
