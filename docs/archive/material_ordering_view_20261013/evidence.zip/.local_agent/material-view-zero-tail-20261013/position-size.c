#include "native_semantic_state.h"
#include <stdio.h>
#include <stddef.h>
int main(void){printf("%zu %zu %zu\n",sizeof(GCSemanticPosition),offsetof(GCSemanticPosition,history_lo),offsetof(GCSemanticPosition,history_len));return 0;}
