from pathlib import Path
import json,collections,time
P=Path('.local_agent/consumer-isolation-20261017');d=json.loads((P/'results.json').read_bytes());counts=collections.Counter();batches=collections.Counter();scopes=[]
for r in d['rows']:
 trace=r['trace'];batch=[];orders=[]
 for t in trace:
  if t[0]!=2:continue
  if t[3]==0:
   if batch:assert len(batch)==batch[0][4];orders.append(batch)
   batch=[]
  batch.append(t)
 if batch:assert len(batch)==batch[0][4];orders.append(batch)
 for order in orders:
  assert [t[3]for t in order]==list(range(len(order)))
  assert [(t[5],t[6])for t in order]==sorted([(t[5],t[6])for t in order],key=lambda x:(-x[0],x[1]))
  counts['full_sorted_action_entries']+=len(order);counts['full_order_batches']+=1
  batches[str(order[0][7])]+=1
 probes=[t for t in trace if t[0]==1];counts['recorded_probe_calls']+=len(probes)
 if r['kind']=='precomputed_leaf':assert len(probes)==1 and probes[0][2]==1 and probes[0][1]==0
 if r['kind']=='compact_ordering':
  result=r['result'];assert sum(map(len,orders))==result['ordering_actions'];assert len(orders)==result['ordering_nodes'];assert result['termination_reason']=='node_budget'and result['nodes']==256
  # A constant residual makes child-side ordering score=-512 plus linear/control terms.
  # Trace records actualscores, not an assertion that constantmodel reorders meaningfully.
  scopes.append({'arm':r['arm'],'case':r['case'],'reuse':r['reuse'],'actual_depth':result['completed_depth'],'reason':result['termination_reason'],'ordering_actions':result['ordering_actions'],'ordering_evaluations_by_first_two_plies':result['ordering_evaluations_by_ply'][:2],'fused_calls':sum(t[1]for t in probes),'precomputed_calls':sum(t[2]for t in probes),'nonnull_zero_calls':sum(t[2]and not any(t[3:6])for t in probes)})
assert all(z['fused_calls']==0 for z in scopes if z['arm']=='baseline' or z['case']==0)
assert all(z['fused_calls']>0 for z in scopes if z['arm']=='isolated'and z['case']in(1,2))
# Reuse confines ordering probes to baseline while ordinary mixed leaf probes remain fused.
assert all(z['precomputed_calls']==z['ordering_actions']for z in scopes if z['reuse'])
assert all(z['precomputed_calls']==0 for z in scopes if not z['reuse'])
summary={'counts':dict(counts),'batches_by_ply':dict(batches),'cases':scopes,'root_vectors':{r['root']:r['vector']for r in d['rows']if r['kind']=='precomputed_leaf'},'interpretation':'All12searches retainD1 withrequestedD2 andnode_budget; no completedD2claim. Extraorderingtrials~4.2k aredistinctfrom256searchnodes. No performanceinferencefrominstrumentedtimes, no learnerclaim, no overcountofindependentroots.'};(P/'consumer-analysis.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
