from pathlib import Path
import sys,json,time,importlib.util,collections
from dataclasses import replace
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];P=R/'.local_agent/consumer-isolation-20261017'
from test_native_q_history_deferral import cycle,checked_replay
from test_f58_compact_nonlinear import _native_constant_compact_model
from generic_chess.rules.serialization import deserialize_ruleset,serialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
start=time.perf_counter();mods={};roots={};setup=[]
for arm in ('baseline','isolated'):
 spec=importlib.util.spec_from_file_location(arm+'._native_core',P/arm/'_native_core.cp312-win_amd64.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
roots['cycle']=cycle(max_ply=2048,repetition=10000,prefix=8)
z=next(r for r in json.loads((R/'.local_agent/s4-storage-20261016/cancel-results.json').read_bytes())['roots']if r['seed']==124801);x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);roots['hybrid']=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])))
ns={};packed={};features={};before={}
for root,s in roots.items():
 before[root]=record_value(s.state)
 for arm,m in mods.items():
  n=compile_native_semantic_rules(s.compiled,backend_module=m);p=pack_semantic_search_position(s.compiled,n,s);v=sem.dynamic_features(n,p);sp=sem.spatial_features(n,p);ns[root,arm]=n;packed[root,arm]=p;features[root,arm]=v
  setup.append({'root':root,'arm':arm,'vector':v,'spatial':sp,'snapshot':record_value(sem.snapshot(n,p))})
assert features['cycle','baseline']==(0,0,0),features
assert any(features['hybrid','baseline']),features
assert features['cycle','baseline']==features['cycle','isolated'] and features['hybrid','baseline']==features['hybrid','isolated']
(P/'setup.json').write_text(json.dumps({'rows':setup,'roots':{k:record_value(s.state)for k,s in roots.items()},'source_hybrid':z,'setup_calls':{'compile':4,'pack':4,'dynamic_features':4,'spatial_features':4,'snapshot':4},'seconds':time.perf_counter()-start},indent=2),encoding='utf8')
cases=[((0,0,0),(1,0,0,0,0,0,0,0,-1)),((2,3,5),(0,)*9),((2,3,5),(1,0,0,0,0,0,0,0,-1))];rows=[];errors=[];t0=time.perf_counter()
def save(row):
 rows.append(row)
 with(P/'queries.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps(row)+'\n')
 print(row['kind'],row['root'],row['case'],row.get('reuse'),row['arm'],len(row['trace']),flush=True)
def stops():
 for name in ('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(z.get('stopped')or z.get('user_paused'))
 assert len(rows)<24 and time.perf_counter()-t0<120
for root,s in roots.items():
 for k,(d,nine)in enumerate(cases):
  for arm,m in mods.items():
   stops();v=features[root,arm];m.test_consumer_reset(1,*v);t=time.perf_counter();value=sem.evaluate(ns[root,arm],packed[root,arm],dynamic_values=d,localized_control_values=nine);elapsed=time.perf_counter()-t;trace,overflow=m.test_consumer_read();save({'kind':'precomputed_leaf','root':root,'case':k,'arm':arm,'vector':v,'dynamic_values':d,'control_values':nine,'value':value,'trace':trace,'overflow':overflow,'caller_seconds':elapsed});assert not overflow and len(trace)==1 and trace[0][1]==0 and trace[0][2]==1
for k,(d,nine)in enumerate(cases):
 s=roots['hybrid'];model=_native_constant_compact_model(s.compiled,s)
 cp=LearnableMaterialCheckpoint(ruleset_fingerprint=s.compiled.ruleset_fingerprint,evaluation_profile_version='manual-consumer-control',board_weights={},hand_weights={},dynamic_weights=dict(zip(('mobility','promotion_potential','anchor_safety'),d)),localized_control_weights=nine,compact_nonlinear=model,created_at='fixed-control',training_updates=0)
 for reuse in(False,True):
  for arm,m in mods.items():
   stops();e=SemanticSearchEngine(s.compiled,ns['hybrid',arm],dynamic_values=d,localized_control_values=nine,ordering_checkpoint=cp,tt_megabytes=0,ordering_cache_enabled=False,ordering_feature_reuse_enabled=reuse);m.test_consumer_reset(0,0,0,0);t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_nodes=256,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);result=record_value(r);elapsed=time.perf_counter()-t;trace,overflow=m.test_consumer_read();save({'kind':'compact_ordering','root':'hybrid','case':k,'reuse':reuse,'arm':arm,'checkpoint':cp.to_dict(),'result':result,'trace':trace,'overflow':overflow,'caller_seconds':elapsed});assert not overflow and r.ordering_actions>0
   checked_replay(s,ns['hybrid',arm],r);assert record_value(s.state)==before['hybrid']
assert len(rows)==24
pairs=[]
for i in range(0,24,2):
 a,b=rows[i:i+2];assert a['arm']=='baseline'and b['arm']=='isolated'
 ta=[list(x)for x in a['trace']];tb=[list(x)for x in b['trace']]
 for x in ta+tb:x[1]=0
 trace_equal=ta==tb
 if a['kind']=='precomputed_leaf':equal=a['value']==b['value']
 else:
  def non_time(row):return{k:v for k,v in row['result'].items()if'elapsed'not in k}
  equal=non_time(a)==non_time(b)
 pairs.append({'kind':a['kind'],'root':a['root'],'case':a['case'],'reuse':a.get('reuse'),'all_non_time_equal':equal,'all_probe_values_vectors_and_sorted_order_equal':trace_equal,'baseline_seconds':a['caller_seconds'],'isolated_seconds':b['caller_seconds']})
 assert equal and trace_equal,pairs[-1]
summary={'query_calls':len(rows),'pairs':pairs,'seconds':time.perf_counter()-t0,'total_seconds':time.perf_counter()-start,'branch_counts':{arm:dict(collections.Counter(('fused'if t[1]else'base')for r in rows if r['arm']==arm for t in r['trace']if t[0]==1))for arm in mods},'pointer_counts':{arm:dict(collections.Counter(('present_zero'if not any(t[3:6])else'present_nonzero')if t[2]else'absent'for r in rows if r['arm']==arm for t in r['trace']if t[0]==1))for arm in mods},'instrumented_times_not_cost_claim':True,'root_preserved':all(record_value(s.state)==before[k]for k,s in roots.items())};(P/'results.json').write_text(json.dumps({'summary':summary,'rows':rows},indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
