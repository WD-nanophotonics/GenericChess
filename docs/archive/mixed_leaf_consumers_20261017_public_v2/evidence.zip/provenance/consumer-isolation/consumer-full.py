from pathlib import Path
import subprocess,sys,json,time
R=Path.cwd();P=R/'.local_agent/consumer-isolation-20261017';t=time.perf_counter()
with(P/'full-tests.log').open('x',encoding='utf8')as f:r=subprocess.run([sys.executable,'-m','pytest','-q','--basetemp='+str(P/'full-temp'),'-o','cache_dir='+str(P/'full-cache')],stdout=f,stderr=subprocess.STDOUT,timeout=900)
(P/'full-tests.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'scope':'Normal rebuilt adopted product, defaultfullactivefourlayers; actualsourcefaultfixtures readadoptedproductC. Separatefrompriorprivateoverridequalification.'},indent=2),encoding='utf8');print((P/'full-tests.log').read_text(encoding='utf8')[-2200:]);sys.exit(r.returncode)
