from pathlib import Path
import sys,sysconfig,subprocess,time,json,os,hashlib
R=Path.cwd();P=R/'.local_agent/consumer-isolation-20261017';S=R/'generic_chess/_native';D=R/'.local_agent/s4-storage-20261016/isolated-mixed-leaf'
header=r'''
/* PRIVATE consumer observation only; bounded arrays, no Python calls in GIL-free search. */
#define GC_CT_CAP 65536
static int gc_ct_count=0,gc_ct_overflow=0,gc_ct_force=0,gc_ct_vector[3]={0,0,0};
static long long gc_ct_rows[GC_CT_CAP][10];
static void gc_ct_add(int kind,int branch,int pointer,int a,int b,int c,long long value,int ply,int weight,int nine) {
 if(gc_ct_count>=GC_CT_CAP){gc_ct_overflow=1;return;}
 long long *r=gc_ct_rows[gc_ct_count++];r[0]=kind;r[1]=branch;r[2]=pointer;r[3]=a;r[4]=b;r[5]=c;r[6]=value;r[7]=ply;r[8]=weight;r[9]=nine;
}
static PyObject *gc_ct_reset(PyObject *self,PyObject *args){int force,a,b,c;if(!PyArg_ParseTuple(args,"iiii",&force,&a,&b,&c))return NULL;gc_ct_count=gc_ct_overflow=0;gc_ct_force=force;gc_ct_vector[0]=a;gc_ct_vector[1]=b;gc_ct_vector[2]=c;Py_RETURN_NONE;}
static PyObject *gc_ct_read(PyObject*self,PyObject*args){PyObject *rows=PyList_New(gc_ct_count);if(!rows)return NULL;for(int i=0;i<gc_ct_count;i++){long long*r=gc_ct_rows[i];PyObject*t=Py_BuildValue("(LLLLLLLLLL)",r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8],r[9]);if(!t){Py_DECREF(rows);return NULL;}PyList_SET_ITEM(rows,i,t);}return Py_BuildValue("Ni",rows,gc_ct_overflow);}
'''
for arm in ('baseline','isolated'):
 Q=P/arm;Q.mkdir(exist_ok=False);source=(S/'native_module.c' if arm=='baseline'else D/'native_module.c').read_text()
 # Insert observation after profile declaration but before leaf use. Renamed symbol remains local.
 start=source.index('static int gc_semantic_probe_material(');end=source.index('static int gc_semantic_dynamic_feature_vector(',start)
 if arm=='baseline':
  body=source[start:end].replace('static int gc_semantic_probe_material(','Py_NO_INLINE static int gc_semantic_probe_material_base(',1)
 else:body=''
 wrapper=r'''static int gc_semantic_probe_material(const GCSemanticRules *rules,const GCSemanticPosition *position,const GCSemanticProbeProfile *profile,const int *dynamic_features) {
 if(gc_ct_force)dynamic_features=gc_ct_vector;
 int branch=0,result;
 DISPATCH
 gc_ct_add(1,branch,dynamic_features!=NULL,dynamic_features?dynamic_features[0]:0,dynamic_features?dynamic_features[1]:0,dynamic_features?dynamic_features[2]:0,result,position->ply,profile?!!(profile->dynamic[0]||profile->dynamic[1]||profile->dynamic[2]):0,profile?profile->localized_control_supplied:0);
 return result;
}

'''
 dispatch='result=gc_semantic_probe_material_base(rules,position,profile,dynamic_features);'
 if arm=='isolated':dispatch='if(profile && profile->dynamic_supplied && profile->localized_control_supplied && (profile->dynamic[0]||profile->dynamic[1]||profile->dynamic[2]) && dynamic_features==NULL){branch=1;result=gc_semantic_probe_material_fused(rules,position,profile,dynamic_features);}else '+dispatch
 source=source[:start]+header+body+wrapper.replace('DISPATCH',dispatch)+source[end:]
 key='    actions->count = legal_count;\n    free(ordered);';assert source.count(key)==1
 source=source.replace(key,'    for(size_t j=0;j<legal_count;j++) gc_ct_add(2,0,0,(int)j,(int)legal_count,ordered[j].mover_score,(long long)ordered[j].action,(int)ply,0,0);\n'+key)
 key='static PyMethodDef gc_methods[] = {';source=source.replace(key,key+'\n {"test_consumer_reset",gc_ct_reset,METH_VARARGS,"private"},\n {"test_consumer_read",gc_ct_read,METH_VARARGS,"private"},')
 (Q/'native_module.c').write_bytes(source.encode());cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(Q/f.name if f.name=='native_module.c' else f)for f in sorted(S.glob('*.c'))]+['-o',str(Q/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')))];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(Q/'zig-cache')));(Q/'build.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'stderr':r.stderr,'source_sha256':hashlib.sha256(source.encode()).hexdigest()},indent=2),encoding='utf8');assert r.returncode==0,r.stderr;print(arm,'BUILT',time.perf_counter()-t,flush=True)
