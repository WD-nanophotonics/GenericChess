from pathlib import Path
import sys,json,time,importlib.util,collections,math
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];P=R/'.local_agent/consumer-isolation-20261017';D=P/'root-scout'
from test_native_q_history_deferral import cycle,checked_replay
from test_native_pending_continuation import session_after
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
spec=importlib.util.spec_from_file_location('root_scout._native_core',D/'_native_core.cp312-win_amd64.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
roots={'cycle2':cycle(max_ply=2048,repetition=4,prefix=2),'cycle8':cycle(max_ply=2048,repetition=4,prefix=8),'pending':session_after(('e2e4','d7d5','f1b5'))};details={};source=json.loads((R/'.local_agent/s4-storage-20261016/cancel-results.json').read_bytes())
for seed in(124401,124801,125201):
 z=next(r for r in source['roots']if r['seed']==seed);x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);roots[str(seed)]=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));details[str(seed)]=z
(D/'roots.json').write_text(json.dumps({'actual_roots':{k:record_value(s.state)for k,s in roots.items()},'existing_hybrid_source':details,'cycle_spec':{'max_ply':2048,'repetition':4,'prefix':[2,8]},'pending_actions':['e2e4','d7d5','f1b5']},indent=2),encoding='utf8');rows=[];start=time.perf_counter()
for index,(root,s)in enumerate(roots.items()):
 before=record_value(s.state);ns={'adoptedbaseline':compile_native_semantic_rules(s.compiled),'private_root_scout':compile_native_semantic_rules(s.compiled,backend_module=m)}
 for profile in('defaultstatic','mixed235control9'):
  for arm in ('adoptedbaseline','private_root_scout')if index%2==0 else('private_root_scout','adoptedbaseline'):
   for name in('rollout','advisor','slack'):
    f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
   assert time.perf_counter()-start<120 and len(rows)<24
   setup=time.perf_counter();e=SemanticSearchEngine(s.compiled,ns[arm],tt_megabytes=0,ordering_cache_enabled=False,**({'dynamic_values':(2,3,5),'localized_control_values':(1,0,0,0,0,0,0,0,-1)}if profile=='mixed235control9'else{}));t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);row={'root':root,'profile':profile,'arm':arm,'result':record_value(r),'constructor_seconds':t-setup,'caller_seconds':time.perf_counter()-t};json.dumps(row);row['ready_seconds']=time.perf_counter()-setup;rows.append(row)
   with(D/'queries.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps(row)+'\n')
   checked_replay(s,ns[arm],r);assert record_value(s.state)==before
   print(root,profile,arm,r.completed_depth,r.nodes,r.termination_reason,row['ready_seconds'],flush=True)
pairs=[]
for root in roots:
 for profile in('defaultstatic','mixed235control9'):
  x={z['arm']:z for z in rows if z['root']==root and z['profile']==profile};a,b=x['adoptedbaseline'],x['private_root_scout'];same_depth=a['result']['completed_depth']==b['result']['completed_depth'];keys=('score','action','principal_variation','dynamic_features','result_ordinary_qdepth','result_check_hard_qdepth');equal=all(a['result'][k]==b['result'][k]for k in keys)if same_depth else None;joint=a['result']['completed_depth']==b['result']['completed_depth']==3
  pairs.append({'root':root,'profile':profile,'joint_requested_d3':joint,'same_retained_depth':same_depth,'same_score_canonicalPV_and_vectors':equal,'baseline_depth':a['result']['completed_depth'],'candidate_depth':b['result']['completed_depth'],'baseline_reason':a['result']['termination_reason'],'candidate_reason':b['result']['termination_reason'],'node_ratio':b['result']['nodes']/a['result']['nodes']if a['result']['nodes']else None,'ready_ratio':b['ready_seconds']/a['ready_seconds']})
summary={'calls':len(rows),'pairs':pairs,'seconds':time.perf_counter()-start,'joint_d3':sum(z['joint_requested_d3']for z in pairs),'same_depth_mismatch':sum(z['same_retained_depth']and z['same_score_canonicalPV_and_vectors']is False for z in pairs),'not_a_fresh_transfer':True,'not_adopted':True};(D/'results.json').write_text(json.dumps({'summary':summary,'rows':rows},indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
