from pathlib import Path
import sys,json,time,math
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];P=R/'.local_agent/consumer-isolation-20261017'
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.learning.nonlinear import CompactNonlinearResidual,semantic_state_features
from test_native_dynamic_feature_views import reference_features
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
z=next(z for z in json.loads((P/'compact-required3/results.json').read_bytes())['roots']if z['seed']==125601);src=z['source'];x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(src['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(src['record'])));n=compile_native_semantic_rules(c);model=CompactNonlinearResidual.from_dict(z['checkpoint']['compact_nonlinear']);
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.learning.features import localized_control_features
from generic_chess.core.transition import apply_action
class ManualExistingCallback:
 def __init__(self):self.calls=0;self.dimensions=set();self.feature_seconds=0.;self.predict_seconds=0.
 def evaluate(self,state):
  t=time.perf_counter();dynamic=reference_features(c,state.position);features=semantic_state_features(state.position,c,dynamic);control=localized_control_features(state.position,c);self.feature_seconds+=time.perf_counter()-t;t=time.perf_counter();prediction=float(model.predict(features[None,:])[0]);self.predict_seconds+=time.perf_counter()-t;self.calls+=1;self.dimensions.add(len(features));assert len(features)==5145
  return max(-90000000,min(90000000,(1 if state.position.side_to_move==0 else -1)*(round(prediction*256)+256*(control[0]-control[-1]))))
 def type_value(self,t):return 0
 def capture_order_value(self,m,captured):return 0
for name in('rollout','advisor','slack'):
 f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
before=record_value(s.state);evaluator=ManualExistingCallback();player=AlphaBetaPlayer(c,evaluator_override=evaluator,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();r=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=256,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0));returned=time.perf_counter();value=record_value(r);json.dumps(value);ready=time.perf_counter();assert record_value(s.state)==before;assert r.action is None or r.action in s.legal_actions();state=s.state;edges=[]
for action in r.principal_variation:
 state=apply_action(state,action,c);edges.append({'action':record_value(action),'state':record_value(state)})
result={'plan':json.loads((P/'compact-Core-player-plan.json').read_bytes()),'result':value,'caller_seconds':returned-t,'ready_seconds':ready-t,'callback_calls':evaluator.calls,'actual_input_dimensions':sorted(evaluator.dimensions),'feature_and_control_seconds':evaluator.feature_seconds,'prediction_seconds':evaluator.predict_seconds,'pv_edges':edges,'root_unchanged':True,'scope':'OneexplicitpureCoreplayerprototype, notautomaticNativefallback,deployedmodel,learnedbenefit,all-domainrepresentationoroptimalWDL. Directandwholeplayercosts distinct; original3secondcapretained.'};(P/'compact-Core-player-results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in result.items()if k not in('result','pv_edges','plan')},indent=2));print('RESULT',r.completed_depth,r.termination_reason,r.score)
