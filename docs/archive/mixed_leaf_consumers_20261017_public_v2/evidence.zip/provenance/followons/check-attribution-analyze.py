from pathlib import Path
import json
P=Path('.local_agent/consumer-isolation-20261017');D=P/'check-attribution';d=json.loads((D/'results.json').read_bytes());pairs=[]
for seed in d['plan']['roots']:
 for profile in d['plan']['profiles']:
  x={r['arm']:r for r in d['rows']if r['seed']==seed and r['profile']==profile};a,b=x['normal'],x['timer_only'];fixed=all(r['result']['termination_reason']!='time_budget'for r in x.values());same={k:v for k,v in a['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in b['result'].items()if k!='elapsed_seconds'}
  if fixed:assert same
  calls,ns=b['metrics']['kernel_check_profile'];pairs.append({'seed':seed,'profile':profile,'fixed_work':fixed,'all_non_time_equal':same,'entry_calls':calls,'inclusive_entry_nanoseconds':ns,'kernel_seconds':b['result']['elapsed_seconds'],'entry_time_share':ns/1e9/b['result']['elapsed_seconds'],'instrumented_caller_ratio':b['caller_seconds']/a['caller_seconds']})
summary={'pairs':pairs,'decision':'REJECT engineering a cache/reuse for THISpublicruntime-in-checkentry: allentryshares<5percent. This isNOT totalattack/self-checkcost; internalstatichelperchecks excluded. Do not inferallcheckworkcheap orreuseuntrustedhistorybits. Timeronly16calls, productunchanged.','fixed_work_pairs':sum(z['fixed_work']for z in pairs),'max_entry_share':max(z['entry_time_share']for z in pairs)};(D/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
# Keep current decisions and precise pending work, not a completed-task diary.
memo='''State: ScienceOPEN; PUBLICforDot/Chat; PRIVATE404abandoned. StandingprojectGit/Slack sansPII/password/credentials; PRIMARYsandbox/AUXsidemission separate; >1hrun consultDot. No newworkers.
Segment: ACTIVE2e88800f-a2ba-4f66-b094-0374683cf43a UTC2026-10-16T15:35:06.733856+00:00; clockpersists.
Main: Does compact-NEEDS3 withzero3+supplied9 duplicatelegalpasses? | inspectactualcompact/orderconsumer thenfreeze12private2arm/reusecontrols beforeanyprototypequery | precomputedNONNULL staysbase; compactitselfrequires3, nozero-skip/errorchange | decideeligibilitywideningonlyifsemantics/wholecallerbenefit; no learner/AUX/newAPI.
Backup1: Can adoptedfusion be delivered reproducibly? | finishreport/sourcecopy/membership/PIIreview andprescribedpublisher | normal2866full+46laterS4; restored231/sourcehash;24TOTALconsumertraces | fullremoteSHA/PUBLICbyteverification, no routineDotgate.
Backup2: New usefuladvice? | newchannelrootsafter1792163478.240619 andcompletePRIMARY20limitpages; saveraw/reconcile | last40replies/6Dot; AUX78root+oneadvice referenceonly | no rebind/reset/resend/AUXexecution.
Evidence: .local_agent/consumer-isolation-20261017: fusionADOPT 12equalpairs,actual9206fused/17340base; PVSv2fresh128/128,56jointD3/0D3only/mixedadverse REJECT; v1override2878/actualv2C38 distinct. PureCoremixedD2censor156 notD3agreement. Checkentry16timerqueriesall<5percent REJECTcache, notallattackcost. Source reader base/currentindexerror andmissingF58fixture preserved/fixed; restored-v4reader+231pass. Product89f3c92b, noPVS/cache/default/AUXchange.
''';assert len(memo.encode())<=2048;(Path('.local_agent/NEXT_WORK.md')).write_text(memo,encoding='utf8')
