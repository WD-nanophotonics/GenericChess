from pathlib import Path
import sys,json,time,math
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];P=R/'.local_agent/consumer-isolation-20261017'
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.learning.nonlinear import CompactNonlinearResidual,semantic_state_features
from test_native_dynamic_feature_views import reference_features
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
plan={'question':'Does existingexplicitCore compactevaluation preserve everydefined5145input onanactual16boardrootandlegalchild, withoutchangingNativecap or task?','changed_premise':'44existingrules showall11sixteenboardroots above4096. Sourceordinary_type_ids fixesnTypes=n/2+2forevenn; aux0 formula n^3+4n^2+n+9 gives5145at16, whileodd15gives4073. This is structuralforthatgenerator, notbadseeds oradversariallabels.','controls':2,'search_calls':0,'fits':0,'scope':'Existingmanualmodelalreadyfromprivate12slotcontrol, no newnetwork/training/benchmarkdataset/AUXprogram. CompleteGameSessionandlegaltransitionretained; denseencoderfieldsareexistingapproximation, NOT fullsemanticMarkovrepresentation orstrengthproof.','budget':'<30seconds, twoCorepredictions plusCore/Nativefeaturechecks; donotraiseNativecap/truncatetypes/altergenerator.'};(P/'compact-Core-input-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
z=next(z for z in json.loads((P/'compact-required3/results.json').read_bytes())['roots']if z['seed']==125601);src=z['source'];x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(src['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(src['record'])));n=compile_native_semantic_rules(c);model=CompactNonlinearResidual.from_dict(z['checkpoint']['compact_nonlinear']);rows=[];start=time.perf_counter();parent=record_value(s.state)
for label in('parent','first_legal_child'):
 if label=='first_legal_child':
  action=sorted(s.legal_actions(),key=repr)[0];s.submit(action)
 t=time.perf_counter();dynamic=reference_features(c,s.state.position);native_dynamic=sem.dynamic_features(n,pack_semantic_search_position(c,n,s));assert dynamic==native_dynamic;features=semantic_state_features(s.state.position,c,dynamic);encoded=time.perf_counter();assert len(features)==5145;pred=float(model.predict(features[None,:])[0]);expected=2+.125*math.tanh(.01*dynamic[0]);assert abs(pred-expected)<1e-12;assert not model._prediction_arrays[2].flags.writeable
 rows.append({'label':label,'state':record_value(s.state),'vector':dynamic,'dimension':len(features),'encoded_seconds':encoded-t,'predict_seconds':time.perf_counter()-encoded,'prediction':pred,'known_formula':expected,'model_weight_bytes':model._prediction_arrays[2].nbytes,'feature_bytes':features.nbytes,'history_len':len(s._search_witnesses)});print(label,len(features),pred,rows[-1]['encoded_seconds'],rows[-1]['predict_seconds'],flush=True)
assert rows[0]['state']==parent and rows[1]['state']['ply_count']==rows[0]['state']['ply_count']+1
record={'plan':plan,'rows':rows,'seconds':time.perf_counter()-start,'decision':'ExistingCore prediction handles5145inputs withouttruncation, whileNativecompactstilldeclinesexplicitly. ThisisNOTaninstalledfullsearchfallback/player/model, learningbenefit,all-domaininputadequacyorpermissiontoautoselectdifferentobjective. Keepcurrentbackendcap anddeferprivatewideninguntilactualconsumer.','encoder_limit':'BoardCURRENTtypes,handsBASEtypes,side,3andauxencoded; boardbase/promotionbit/historynotseparateinputaxes. CompleteCoresearchstate/transition retains them; thisdenseapproximation doesnotredefinetarget.'};(P/'compact-Core-input-results.json').write_text(json.dumps(record,indent=2),encoding='utf8')
