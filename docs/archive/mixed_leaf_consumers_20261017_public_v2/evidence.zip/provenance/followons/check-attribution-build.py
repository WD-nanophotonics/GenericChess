from pathlib import Path
import sys,json,time,os,subprocess,sysconfig,importlib.util
R=Path.cwd();P=R/'.local_agent/consumer-isolation-20261017';D=P/'check-attribution';S=R/'generic_chess/_native'
k=(S/'native_semantic_runtime.c').read_text();needle='int gc_semantic_runtime_in_check(';assert k.count(needle)==1;k=k.replace(needle,'int gc_semantic_runtime_in_check_impl(',1)
k='#include "native_clock.h"\n'+k+'\nuint64_t gc_check_calls=0,gc_check_ns=0;\nint gc_semantic_runtime_in_check(const GCSemanticRules *r,const GCSemanticPosition *p,uint8_t side){\n uint64_t start=gc_monotonic_ns();int status=gc_semantic_runtime_in_check_impl(r,p,side);\n gc_check_calls++;gc_check_ns+=gc_monotonic_ns()-start;return status;\n}\n'
m=(S/'native_module.c').read_text();i=m.index('static PyMethodDef');m=m[:i]+'''
static PyObject *gc_check_profile(PyObject *self,PyObject *args){
 (void)self;int reset=0;if(!PyArg_ParseTuple(args,"|p",&reset))return NULL;
 extern uint64_t gc_check_calls,gc_check_ns;
 PyObject *out=Py_BuildValue("(KK)",(unsigned long long)gc_check_calls,(unsigned long long)gc_check_ns);
 if(reset){gc_check_calls=0;gc_check_ns=0;}return out;
}
'''+m[i:]
needle='    {"semantic_make_checked", gc_semantic_make_checked, METH_VARARGS,';assert m.count(needle)==1;m=m.replace(needle,'    {"check_profile",gc_check_profile,METH_VARARGS,"Private attribution only"},\n'+needle)
(D/'native_module.c').write_bytes(m.encode());(D/'native_semantic_runtime.c').write_bytes(k.encode())
zig=R/'.venv/Lib/site-packages/ziglang/zig.exe';binary=D/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));command=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(D/p.name if p.name in('native_module.c','native_semantic_runtime.c')else p)for p in sorted(S.glob('*.c'))]+['-o',str(binary)]
t=time.perf_counter();r=subprocess.run(command,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(D/'zig-cache')));(D/'build.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'stderr':r.stderr},indent=2),encoding='utf8');assert r.returncode==0,r.stderr;print('BUILT',time.perf_counter()-t)
