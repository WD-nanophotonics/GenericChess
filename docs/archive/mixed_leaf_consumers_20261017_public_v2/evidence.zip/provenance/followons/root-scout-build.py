from pathlib import Path
import json,sys,sysconfig,subprocess,time,os,hashlib
R=Path.cwd();P=R/'.local_agent/consumer-isolation-20261017';D=P/'root-scout';D.mkdir(exist_ok=False);S=R/'generic_chess/_native';source=(S/'native_module.c').read_text()
plan={'question':'Does a root-only null-window scout reduce completed exact-root q0 caller cost without changing score/canonicalPV or stop semantics?','changed_premise':'Isolatedmixedleaf adopted andqualified; perleaf savings leave entirewide searchD1/D2 and many checkedidentities. SHA/keymicrooptimization failed. Currentroot_window alreadyusesincumbent alpha butlaterrootchildren stillreceivewide[-beta,-alpha]; null-window scheduling is a distinct searchalgorithmquestion, notrootreordering orrepeatmixedcostpanel.','primary_reference':'https://github.com/nescitus/cpw-engine/blob/master/search.cpp (raised_alpha PVS section read; standardalgorithmidea only, noenginecode copied). FixedStockfish raw URL fetch failed, notclaimedread.','scope':'PRIVATE ROOT-ONLY, exactrootwindowtrue q0 TT0, unchangedalllegalactions/order/leaf/default/history/requirederrors/canonicalselectedPV replay. Null-window is searchscorethreshold, NOT nullmove/rulechange/pruning/reduction. NoAUXimplementation orlearner.','roots':['actualcycleprefix2','actualcycleprefix8','actualPENDING3ply','exposed124401','exposed124801','exposed125201'],'profiles':['defaultstatic','mixed235control9'],'arms':['adoptedbaseline','private_root_scout'],'query_calls':24,'limits':{'depth':3,'nodes':8192,'seconds':3,'q':0,'tt':0,'whole_seconds':120},'budget':'No repetitions orresampling; expected<60s, build<180s, inspectcostinclsetup/recording. Censors kept, compareonlysamecompletedobjective, rootfullstate/PV alwaysreplayed. Rejectscopeifscore/canonicalPV differsatjointcompletedD3; favorableexposedpilotonly motivatesfreshprotocol, notadoption. No additional oldcostcampaign.'};(D/'plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
old='''        int branch = gc_semantic_iterative_negamax(
            ctx, ply + 1, depth - 1, child_alpha, child_beta,
            /* Scalar probes may reuse TT bounds; only the selected child
             * is recursively reconstructed as the canonical continuation. */
            (ctx->root_window_pruning && pv_replay) ? 0 : child_pv,
            (ctx->root_window_pruning && pv_replay) ? 0 : pv_replay);
        if (ctx->control != 0) break;
        int score = -branch;'''
assert source.count(old)==1
new='''        /* PRIVATE root-only scout; no null move, reduction or action omission. */
        int scout = ply == 0 && ctx->root_window_pruning && !pv_replay &&
            !root_first_child && ctx->ordinary_qdepth == 0 && ctx->tt == NULL &&
            alpha > -GC_SEMANTIC_PROBE_INF && alpha < GC_SEMANTIC_PROBE_INF-1;
        int branch = gc_semantic_iterative_negamax(
            ctx, ply + 1, depth - 1, scout ? -alpha-1 : child_alpha,
            scout ? -alpha : child_beta,
            (ctx->root_window_pruning && pv_replay) ? 0 : child_pv,
            (ctx->root_window_pruning && pv_replay) ? 0 : pv_replay);
        if (ctx->control != 0) break;
        int score = -branch;
        if (scout && score > alpha && score < beta) {
            branch = gc_semantic_iterative_negamax(ctx, ply+1, depth-1,
                child_alpha,child_beta,child_pv,pv_replay);
            if(ctx->control != 0)break;
            score = -branch;
        }'''
source=source.replace(old,new);(D/'native_module.c').write_bytes(source.encode());(D/'baseline.c').write_bytes((S/'native_module.c').read_bytes());cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(D/f.name if f.name=='native_module.c'else f)for f in sorted(S.glob('*.c'))]+['-o',str(D/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')))];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(D/'zig-cache')));(D/'build.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'stderr':r.stderr,'source_sha256':hashlib.sha256(source.encode()).hexdigest()},indent=2),encoding='utf8');assert r.returncode==0,r.stderr;print('BUILT',time.perf_counter()-t)
