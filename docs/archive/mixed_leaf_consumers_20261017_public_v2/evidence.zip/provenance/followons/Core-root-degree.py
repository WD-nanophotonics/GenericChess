from pathlib import Path
import json,sys,time
R=Path.cwd();P=R/'.local_agent/consumer-isolation-20261017';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
z=next(z for z in json.loads((P/'compact-required3/results.json').read_bytes())['roots']if z['seed']==125601)['source'];x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));t=time.perf_counter();core=s.legal_actions();core_seconds=time.perf_counter()-t;n=compile_native_semantic_rules(c);packed=pack_semantic_search_position(c,n,s);t=time.perf_counter();native=sem.guarded_actions(n,packed);native_seconds=time.perf_counter()-t;assert len(core)==len(native)
r={'question':'Does frozen256-nodecap preventanycompleteD1 onactual16boardconsumer?','core_legal_actions':len(core),'native_legal_actions':len(native),'core_enumeration_seconds':core_seconds,'native_enumeration_seconds':native_seconds,'node_cap':256,'completeD1_requires_at_least_one_visit_per_root_action':True,'node_cap_below_root_degree':256<len(core),'scope':'Actualexistingprefix8/rootnotgeneratoropening; readonlyenumeration NOTnewsearch/proof/WDL. Generatoropeningmax256doesnotboundlaterbranching. Do notextendfrozen3second/256nodeexperiment.'};(P/'Core-shared-input/root-degree.json').write_text(json.dumps(r,indent=2),encoding='utf8');print(json.dumps(r,indent=2))
raw=(P/'Core-shared-input/queries.jsonl').read_text();decoder=json.JSONDecoder();at=0;parsed=[]
while at<len(raw):
 while at<len(raw)and raw[at].isspace():at+=1
 if raw[at:at+2]=='\\n':at+=2;continue
 if at>=len(raw):break
 obj,end=decoder.raw_decode(raw,at);parsed.append(obj);at=end
aggregate=json.loads((P/'Core-shared-input/results.json').read_bytes())['rows'];assert parsed==aggregate
(P/'Core-shared-input/queries-recovered.jsonl').write_bytes((''.join(json.dumps(row)+'\n'for row in parsed)).encode());(P/'Core-shared-input/recording-note.json').write_text(json.dumps({'original_newline_count':raw.count('\n'),'literal_separator_count':raw.count('\\n'),'rows_retained_in_valid_aggregate':len(aggregate),'exact_bodies_match_recovered_copy':True,'no_search_rerun':True,'scope':'Producerwroteescapedseparator ratherthannewline; preserveoriginalandaggregate, recovernewcopy only.'},indent=2),encoding='utf8')
