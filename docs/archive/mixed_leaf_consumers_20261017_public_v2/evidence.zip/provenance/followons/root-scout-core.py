from pathlib import Path
import sys,json,time
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];D=R/'.local_agent/consumer-isolation-20261017/root-scout'
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
plan={'question':'Does independent pureCore finiteD3 agree with the exposed12board root-only scout success, before spending on fresh transfer?','decision_change':'A complete differing objective rejectsprototype; a Corecensor isUNKNOWN andnotassumedagreement. No needoptimalWDL.','calls':2,'profiles':['defaultstatic','mixed235control9'],'limits':{'depth':3,'nodes':131072,'seconds':30,'q':0,'TT':False,'native_legality':False,'ordering':False},'scope':'Separate explicitcorrectnesscheck, not extensionofthe24callpilot/frozencostpanel; whole65sec, nofit/AUX; PureCore sharescompiler/host andCorederivedfeatures, independentsearch/transitionexecution.'};(D/'core-control-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8');z=json.loads((D/'roots.json').read_bytes())['existing_hybrid_source']['125201'];x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));n=compile_native_semantic_rules(c);bv={t:i+1 for i,t in enumerate(n.type_ids)}
class Profile:
 def __init__(self,mixed):self.mixed=mixed
 def evaluate(self,state):
  p=state.position;side=p.side_to_move;v=sum((1 if a.owner==side else -1)*bv[a.current_type_id]for a in p.board if a is not None)+sum((1 if o==side else -1)*bv[t]*count for o,h in enumerate(p.hands)for t,count in h.items())
  if self.mixed:
   dynamic=reference_features(c,p);nine=localized_control_features(p,c);v+=(1 if side==0 else -1)*(sum(w*a for w,a in zip((2,3,5),dynamic))+nine[0]-nine[-1])
  return max(-90000000,min(90000000,v))
 def type_value(self,t):return bv[t]
 def capture_order_value(self,m,captured):return 10*bv[captured.current_type_id]-bv[m.current_type_id]
rows=[];before=record_value(s.state)
for profile in plan['profiles']:
 for name in('rollout','advisor','slack'):
  flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
 e=AlphaBetaPlayer(c,evaluator_override=Profile(profile=='mixed235control9'),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();r=e.choose_action(s,SearchLimits(max_depth=3,max_nodes=131072,max_time_seconds=30,quiescence_max_depth=0,quiescence_hard_max_depth=0));row={'profile':profile,'result':record_value(r),'caller_seconds':time.perf_counter()-t};rows.append(row);assert record_value(s.state)==before
 with(D/'core-control-queries.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps(row)+'\n')
 print(profile,r.completed_depth,r.score,row['caller_seconds'],flush=True)
(D/'core-control-results.json').write_text(json.dumps({'plan':plan,'rows':rows},indent=2),encoding='utf8')
