from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];P=R/'.local_agent/consumer-isolation-20261017';D=P/'compact-required3'
from test_f58_compact_nonlinear import _native_constant_compact_model
from test_native_q_history_deferral import checked_replay
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
plan=json.loads((D/'plan.json').read_bytes());mods={};data=json.loads((R/'.local_agent/s4-storage-20261016/cancel-results.json').read_bytes());rows=[];roots=[];start=time.perf_counter()
for arm in plan['arms']:
 spec=importlib.util.spec_from_file_location(arm+'_compact._native_core',D/arm/'_native_core.cp312-win_amd64.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[arm]=m
for index,seed in enumerate(plan['roots']):
 z=next(r for r in data['roots']if r['seed']==seed);x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));before=record_value(s.state);ns={arm:compile_native_semantic_rules(c,backend_module=m)for arm,m in mods.items()};model=_native_constant_compact_model(c,s);offset=2*len(ns['baseline'].type_ids)*c.board_size**2+2*len(model['hand_type_indices'])+2;assert offset+3<=len(model['input_mean']);model['hidden_weights'][0][offset]=.01;model['output_weights'][0]=.125
 cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='manual-existing-ABI-control',created_at='fixed-fixture',dynamic_weights=dict(zip(('mobility','promotion_potential','anchor_safety'),(0.,0.,0.))),localized_control_weights=(1.,0.,0.,0.,0.,0.,0.,0.,-1.),compact_nonlinear=model)
 roots.append({'seed':seed,'source':z,'checkpoint':cp.to_dict(),'dynamic_feature_offset':offset,'input_dimension':len(model['input_mean'])})
 for reuse in(False,True):
  for arm in plan['arms']if index%2==0 else list(reversed(plan['arms'])):
   assert time.perf_counter()-start<120 and len(rows)<12
   for name in('rollout','advisor','slack'):
    flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
   t=time.perf_counter();row={'seed':seed,'reuse':reuse,'arm':arm}
   try:
    e=SemanticSearchEngine(c,ns[arm],checkpoint=cp,ordering_checkpoint=cp,tt_megabytes=0,ordering_cache_enabled=False,ordering_feature_reuse_enabled=reuse);constructed=time.perf_counter();mods[arm].test_compact_calls(True);r=e.search(s,SearchLimits(max_depth=2,max_nodes=256,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);returned=time.perf_counter();result=record_value(r);json.dumps(result);ready=time.perf_counter();counts=mods[arm].test_compact_calls(True);row.update(kind='ACTUAL_QUERY',result=result,body_calls=counts,constructor_seconds=constructed-t,caller_seconds=returned-constructed,ready_seconds=ready-t);checked_replay(s,ns[arm],r);assert record_value(s.state)==before
   except Exception as exc:row.update(kind='EXPLICIT_FAILURE_OR_REFUSAL',error_type=type(exc).__name__,error=str(exc),elapsed_seconds=time.perf_counter()-t)
   rows.append(row)
   with(D/'queries.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps(row)+'\n')
   print(seed,reuse,arm,row['kind'],row.get('body_calls'),round(time.perf_counter()-start,3),flush=True)
pairs=[]
for seed in plan['roots']:
 for reuse in(False,True):
  pair={z['arm']:z for z in rows if z['seed']==seed and z['reuse']==reuse};a,b=pair['baseline'],pair['compact_required3'];valid=a['kind']==b['kind']=='ACTUAL_QUERY';fixed=valid and all(z['result']['termination_reason']!='time_budget'for z in pair.values())
  non=lambda z:{k:v for k,v in z['result'].items()if 'elapsed'not in k}
  pairs.append({'seed':seed,'reuse':reuse,'both_queries':valid,'fixed_work':fixed,'all_non_time_equal':non(a)==non(b)if valid else None,'same_refusal':a.get('error_type')==b.get('error_type')and a.get('error')==b.get('error')if not valid else None,'ready_ratio':b['ready_seconds']/a['ready_seconds']if fixed else None,'baseline_body_calls':a.get('body_calls'),'candidate_body_calls':b.get('body_calls')})
summary={'attempt_slots':len(rows),'actual_queries':sum(r['kind']=='ACTUAL_QUERY'for r in rows),'pairs':pairs,'seconds':time.perf_counter()-start,'counter_instrumentation_both_arms':True,'not_adopted':True};(D/'results.json').write_text(json.dumps({'summary':summary,'rows':rows,'roots':roots},indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
