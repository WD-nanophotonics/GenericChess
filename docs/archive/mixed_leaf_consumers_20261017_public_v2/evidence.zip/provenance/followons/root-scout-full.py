from pathlib import Path
import json,sys,subprocess,time,os
R=Path.cwd();P=R/'.local_agent/consumer-isolation-20261017';D=P/'root-scout';plugin='''import importlib.util,json,hashlib
from pathlib import Path
def pytest_configure(config):
 import generic_chess.native as native
 p=Path(__file__).resolve().parent/'_native_core.cp312-win_amd64.pyd'
 spec=importlib.util.spec_from_file_location('root_scout_qualification._native_core',p)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
 (p.parent/'full-override-receipt.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'OnlydefaultNative overridden, explicitlyselected/sourcebuiltbackendsretain ownbehavior. Notalltestsusecandidate andsourcefaultfixtures readproductfusion,notPVS.'},indent=2),encoding='utf8')
''';(D/'gc_root_scout_test_plugin.py').write_bytes(plugin.encode());t=time.perf_counter()
with(D/'full-override-tests.log').open('x',encoding='utf8')as f:r=subprocess.run([sys.executable,'-m','pytest','-p','gc_root_scout_test_plugin','-q','--basetemp='+str(D/'full-temp'),'-o','cache_dir='+str(D/'full-cache')],env=dict(os.environ,PYTHONPATH=str(D)+os.pathsep+str(R)),stdout=f,stderr=subprocess.STDOUT,timeout=900)
(D/'full-override-tests.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'scope':'PrivatePVSdefaultmodulefunctionalqualification only;explicit/source-builtotherbackends unchanged. No product/default change.'},indent=2),encoding='utf8');print((D/'full-override-tests.log').read_text(encoding='utf8')[-1600:]);sys.exit(r.returncode)
