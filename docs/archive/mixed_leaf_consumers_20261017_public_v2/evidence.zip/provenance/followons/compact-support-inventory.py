from pathlib import Path
import sys,json,collections
R=Path.cwd();sys.path.insert(0,str(R));P=R/'.local_agent/consumer-isolation-20261017'
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
sources=[('prior_cancel_exposed',R/'.local_agent/s4-storage-20261016/cancel-results.json'),('prior_isolation_transfer',R/'.local_agent/s4-storage-20261016/isolated-mixed-leaf/transfer-results.json'),('current_scout_transfer',P/'root-scout-v2/transfer-results.json')];rows=[]
for cohort,path in sources:
 d=json.loads(path.read_bytes())
 for z in d['roots']:
  if 'ruleset'not in z:continue
  c=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));current=len(c.support.type_metadata);base=len(c._legacy_compiled.piece_types);aux=sum((1 if a.value_kind=='bool' else 3)*(1 if a.scope=='global' else 2)for a in c.ir.aux_slots);dimension=2*current*c.board_size**2+2*base+5+aux
  rows.append({'cohort':cohort,'seed':z['seed'],'board':c.board_size,'root_kind':z.get('kind','ACTUAL_EXPOSED_ROOT'),'current_types':current,'base_hand_types':base,'aux_fields':aux,'compact_dimension':dimension,'within_existing4096':dimension<=4096,'width16_dense_weight_bytes_only':16*dimension*8})
summary={}
for cohort,_ in sources:
 by={}
 for board in(4,8,12,16):
  rr=[z for z in rows if z['cohort']==cohort and z['board']==board];by[board]={'roots':len(rr),'above4096':sum(not z['within_existing4096']for z in rr),'dimension_min':min((z['compact_dimension']for z in rr),default=None),'dimension_max':max((z['compact_dimension']for z in rr),default=None)}
 summary[cohort]=by
record={'question':'Do the observedcompactrefusals indicate a real support-scope limit across existing fullgenerated records, before shortlistingthismodel asgenericbaseline?','changed_premise':'Current12slotmanualcompactcontrol has4explicit16boardrefusals, earlierwidth16/32feasibilityhad8; supportcoverage mustbecharged notsilentlytruncatepromotion/currenttypes.','method':'READONLY existing44rules, formula2*ncurrent*boardsquares+2*nbasehand+5+aux; no newmodel/datafamily/teacher/fit/search. Keepcohortsseparate andtails. Existingdense4096 inputABI cap, not genericdefinition.','rows':rows,'by_cohort_board':summary,'decision':'Keepcompactv4 a SCOPED candidate, explicitrefusals inanyfuture comparison. Do notraise cap/widenprivatefusion orstartarchitecture justfrommanualspeed. Coveragecounts descriptiveexposedcohorts, notgeneratordistribution/proof. A realconsumercheckpoint/changedinputrepresentation andpairedwholecostwouldchangeselection.','source':'generic_chess/native/semantic_engine.py and _native/native_module.c compact input dimension; existingtest_f58 fixture mappingbasehand/currenttypes.','machine_cost':'Onlycompile/inspectexistingrulemetadata; no densemodelallocation,nofit,noAUXprogram.'};(P/'compact-support-inventory.json').write_text(json.dumps(record,indent=2),encoding='utf8');print(json.dumps(summary,indent=2));print('ROWS',len(rows))
