from pathlib import Path
import json,collections,statistics,math
P=Path('.local_agent/consumer-isolation-20261017');D=P/'root-scout-v2';d=json.loads((D/'transfer-results.json').read_bytes());rows=d['rows'];pairs=[]
keys=('score','action','principal_variation','dynamic_features','decision_line','result_ordinary_qdepth','result_check_hard_qdepth')
for root in d['roots']:
 for profile in d['plan']['profiles']:
  for rep in(0,1):
   pair={z['arm']:z for z in rows if z['seed']==root['seed']and z['profile']==profile and z['rep']==rep}
   if len(pair)!=2 or any(z['kind']!='ACTUAL_QUERY'for z in pair.values()):continue
   a=pair['adoptedbaseline'];b=pair['private_root_scout_v2'];ar=a['result'];br=b['result'];same=ar['completed_depth']==br['completed_depth'];joint=ar['completed_depth']==br['completed_depth']==3
   pairs.append({'seed':root['seed'],'board':root['board'],'profile':profile,'rep':rep,'joint_d3':joint,'same_depth':same,'equal_score_action_PV_vector':all(ar[k]==br[k]for k in keys)if same else None,'a_depth':ar['completed_depth'],'b_depth':br['completed_depth'],'a_reason':ar['termination_reason'],'b_reason':br['termination_reason'],'ready_ratio':b['ready_seconds']/a['ready_seconds'],'nodes_ratio':br['nodes']/ar['nodes']if ar['nodes']else None,'a_nodes':ar['nodes'],'b_nodes':br['nodes']})
summary={'calls':d['actual_queries'],'planned_slots':128,'missing_slots':128-d['actual_queries'],'roots':len(d['roots']),'actual_acquisition_edges':sum(r.get('actual_ply',0)for r in d['roots']),'tails':[r['seed']for r in d['roots']if r['kind']=='ACTUAL_TERMINAL_TAIL'],'root_failures':[r['seed']for r in d['roots']if r['kind']=='ACTUAL_ROOT_FAILURE'],'joint_d3':sum(z['joint_d3']for z in pairs),'candidate_only_d3':sum(z['b_depth']==3 and z['a_depth']<3 for z in pairs),'baseline_only_d3':sum(z['a_depth']==3 and z['b_depth']<3 for z in pairs),'same_depth_mismatches':[z for z in pairs if z['same_depth']and not z['equal_score_action_PV_vector']],'by_profile':{},'seconds':d['seconds'],'scope':'16families,2dependentpairedrepetitions/profiles. Samecompletedobjective notsamework. Scopedcost/completion notstrength, noactualevaluationgames/training. All32wideprofilecalls/censors kept.'}
for profile in d['plan']['profiles']:
 by={}
 for board in(4,8,12,16):
  selected=[z for z in pairs if z['profile']==profile and z['board']==board];fixed=[z for z in selected if z['joint_d3']];groups=collections.defaultdict(list)
  for z in fixed:groups[z['seed']].append(z)
  values=[statistics.median(z['ready_ratio']for z in g)for g in groups.values()];nodes=[statistics.median(z['nodes_ratio']for z in g)for g in groups.values()]
  by[board]={'family_count':len(groups),'joint_d3_pairs':len(fixed),'family_median_ready_ratio':statistics.median(values)if values else None,'family_median_nodes_ratio':statistics.median(nodes)if nodes else None,'max_joint_d3_ready_ratio':max((z['ready_ratio']for z in fixed),default=None),'both_incomplete_pairs':sum(z['a_depth']<3 and z['b_depth']<3 for z in selected),'candidate_only_d3':sum(z['b_depth']==3 and z['a_depth']<3 for z in selected),'baseline_only_d3':sum(z['a_depth']==3 and z['b_depth']<3 for z in selected)}
 summary['by_profile'][profile]=by
(D/'transfer-summary.json').write_text(json.dumps({'summary':summary,'pairs':pairs},indent=2),encoding='utf8');print(json.dumps(summary,indent=2))
