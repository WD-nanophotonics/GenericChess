import importlib.util,json,hashlib
from pathlib import Path
def pytest_configure(config):
 import generic_chess.native as native
 p=Path(__file__).resolve().parent/'_native_core.cp312-win_amd64.pyd'
 spec=importlib.util.spec_from_file_location('root_scout_qualification._native_core',p)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
 (p.parent/'full-override-receipt.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'OnlydefaultNative overridden, explicitlyselected/sourcebuiltbackendsretain ownbehavior. Notalltestsusecandidate andsourcefaultfixtures readproductfusion,notPVS.'},indent=2),encoding='utf8')
