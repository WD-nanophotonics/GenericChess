import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/expiry_guard_20261008';dest.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((p/'probe.json').read_bytes());assert r['complete'] and r['producer_sha256']==sha((p/'probe.py').read_bytes())
files=[p/'probe.py',p/'probe.json',Path(__file__),root/'.local_agent/generated-recombination-20261008/transfer.json'];archive=dest/'sources-raw.zip';assert not archive.exists();members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();body=f.read_bytes();z.writestr(name,body);members.append({'path':name,'bytes':len(body),'sha256':sha(body)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for x in members:assert sha((Path(tmp)/x['path']).read_bytes())==x['sha256']
index={'base_commit':'2f40bd85911eb0c70dd91ee3047f385ebc373f46','archive_sha256':sha(archive.read_bytes()),'members':members,'extracted_rehashed':True,'excluded':'User/private data, Slack/accounts, credentials, workflow state.'};(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());r['archive']='../../archive/expiry_guard_20261008/index.json';(root/'docs/research/data/expiry_guard_20261008.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print({'members':len(members),'cells':len(r['cases'])})
