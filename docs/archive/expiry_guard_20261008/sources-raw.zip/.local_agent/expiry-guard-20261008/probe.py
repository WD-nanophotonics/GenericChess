import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=root/'.local_agent/generated-recombination-20261008/transfer.json';old=json.loads(src.read_bytes());out=p/'probe.json';assert not out.exists();started=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration':'Earlier expiry flag is not consumed by a guard, so passing active-state search is representation coverage only. Use existing generated seed1101ply5/6 and1103ply9/10, all four reached states. Recombine same zone-capacity rule on P drops (held by active side at observed active states) with temp_right eq0 versuseq1; all else fixed. Replay actual legal prefixes; count Pdrop difference and compare Core/Native publicdepth2/8192nodes/5sec under fixed evaluator,16calls <=60sec. No outcome/price tuning or default change.','cases':[]};write_record(out,r)
try:
 for seed,plies in ((202610081101,(5,6)),(202610081103,(9,10))):
  case=next(x for x in old['cases'] if x['seed']==seed);definition=ruleset_from_dict(case['rules']);base=definition.semantic_actions[0]
  for expected in (0,1):
   drop=replace(base,type_ids=('P',),replace_selector=replace(base.replace_selector,type_ids=('P',)),slot_guards=(RuleSlotGuard(slot_name='temp_right',value=expected),));c=compile_ruleset_for_execution(replace(definition,semantic_actions=(drop,definition.semantic_actions[1])));s=GameSession(c);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
   for ply,e in enumerate(case['route'][:max(plies)],1):
    s.submit(action_from_dict(e['action']))
    if ply not in plies:continue
    assert time.perf_counter()-started<60
    assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    row={'seed':seed,'ply':ply,'guard_value':expected,'actual_slot':dict(s.state.position.aux_state)[(0,-1)],'p_drops':sum(getattr(a,'base_type_id',None)=='P' for a in s.legal_actions()),'searches':[]};r['cases'].append(row);write_record(out,r)
    for native in (False,True):
     player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=native,tuning=SearchTuning(use_root_tactical=False));d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);row['searches'].append({'native':native,'decision':record_value(d)});write_record(out,r)
    a,b=[x['decision'] for x in row['searches']];row['equal']={k:a[k]==b[k] for k in ('action','score','nodes','completed_depth','principal_variation')};assert all(row['equal'].values());assert b['native_legality_fallbacks']==0
 for row in r['cases']:
  if row['guard_value']!=row['actual_slot']:assert row['p_drops']==0
 assert any(x['p_drops']>0 for x in r['cases']);r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
print([(x['seed'],x['ply'],x['guard_value'],x['actual_slot'],x['p_drops']) for x in r['cases']])
