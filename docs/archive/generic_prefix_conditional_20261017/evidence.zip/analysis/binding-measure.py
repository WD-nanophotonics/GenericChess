from pathlib import Path
import json,sys,time,collections,hashlib
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path('.local_agent/td-tree-20261017');start=time.monotonic()
write_json(D/'binding-measure-plan.json',dict(question='Does uniform typed-binding sampling overweight some physical intents through multiple pattern/geometry bindings in the existing72rule records?',changed_premise='Clune/Flux syntactic-sensitivity caveat and this study explicitly chooses typed bindings; inspect multiplicity before interpreting measure as uniform physical moves.',decision='If multiplicity exists disclose distinction and inspect up to32first duplicate intent groups complete children; never assume physical intent equivalence or merge histories. If absent in this scope retain typed-binding definition, no all-domain proof.',forecast_seconds=20,cap_seconds=120,new_games=0,new_search_training=0))
v=json.loads((D/'generic-prefix-v2/result.json').read_bytes());rules={r['slot']:r['ruleset']for r in v['rules']};rows=[];witnesses=[]
for r in v['rows']:
 s=GameSession(compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(rules[r['slot']]))));checkpoints={0,16,64}
 def inspect():
  if s.result.status.value!='ongoing':return
  groups=collections.defaultdict(list)
  for a in s.legal_actions():
   body=record_value(a);physical={k:x for k,x in body.items()if k not in('pattern_id','geometry_id')};groups[json.dumps(physical,sort_keys=True)].append(a)
  n=sum(map(len,groups.values()));tv=sum(abs(len(g)/n-1/len(groups))for g in groups.values())/2 if n else 0
  rows.append(dict(rule=r['slot'],ply=s.state.ply_count,typed_bindings=n,physical_intents=len(groups),duplicate_groups=sum(len(g)>1for g in groups.values()),intent_distribution_TV=tv))
  for key,aa in sorted(groups.items()):
   if len(aa)<2 or len(witnesses)>=32:continue
   children=[record_value(apply_action(s.state,a,s.compiled))for a in aa]
   witnesses.append(dict(rule=r['slot'],ply=s.state.ply_count,actions=[record_value(a)for a in aa],physical=json.loads(key),complete_children=children,full_children_equal=all(c==children[0]for c in children)))
 inspect()
 for a in r['final_record']['actions']:
  act=SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])if'from_square'in a else SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
  s.submit(act)
  if s.state.ply_count in checkpoints:inspect()
 assert time.monotonic()-start<120
 for name in('rollout','advisor','slack'):
  f=json.loads((Path('.local_agent')/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
write_json(D/'binding-measure.json',dict(status='COMPLETE',states=len(rows),rows=rows,witnesses=witnesses,seconds=time.monotonic()-start,scope='Existing72scoped rules and choseninitial/16/64 ongoingstates; physicalintent grouping is diagnostic, not semantic equivalence or sampling change. Fullchildren retained for boundedfirst32groups; no rule filtering.'))
print('CLOSED',len(rows),sum(x['duplicate_groups']>0for x in rows),len(witnesses),round(time.monotonic()-start,3))
