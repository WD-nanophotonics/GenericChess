from pathlib import Path
import json,sys
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path('.local_agent/td-tree-20261017');rows=[json.loads(x)for x in(D/'conditional-prefix/paths.jsonl').read_text(encoding='utf8').splitlines()];out=[]
for k in range(72):
 rr=[r for r in rows if r['rule']==k];cs={h:[c for r in rr for c in r['checkpoints']if c['ply']==h and c['ongoing']]for h in(16,64)}
 dim=len(next(c for r in rr for c in r['checkpoints'])['phi'])
 aa={h:np.array([c['phi']for c in cs[h]],float).reshape(-1,dim)for h in(16,64)}
 def rank(a):return int(np.linalg.matrix_rank(a))if len(a)else 0
 r16=rank(aa[16]);r64=rank(aa[64]);rm=rank(np.vstack([aa[16],aa[64]]));out.append(dict(rule=k,board=rr[0]['board'],preset=rr[0]['preset'],dimensions=dim,rank16=r16,rank64=r64,rank_union=rm,samples16=len(aa[16]),samples64=len(aa[64]),unexcited_union=[j for j in range(dim)if not np.any(np.vstack([aa[16],aa[64]])[:,j])]))
x=dict(question='Does denser64ply input supply novel typed material directions across fresh continuations, or only drop earlier directions?',rows=out,late_adds_to_early=sum(r['rank_union']>r['rank16']for r in out),early_adds_to_late=sum(r['rank_union']>r['rank64']for r in out),late_rank_greater=sum(r['rank64']>r['rank16']for r in out),late_rank_lower=sum(r['rank64']<r['rank16']for r in out),late_rank_equal=sum(r['rank64']==r['rank16']for r in out),scope='Finite observed typed board-current/hand-base vectors on ongoing starts, per-rule axes only. Linear rank is not useful gradients, payoff identification, unique values, deployment utility or a shared model across rule type spellings. Union is retrospective analysis, no sample/model choice from validation fitness.')
write_json(D/'conditional-span.json',x);print(json.dumps({k:v for k,v in x.items()if k!='rows'},indent=2))
