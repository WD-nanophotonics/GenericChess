"""Fresh conditional continuation sample, not a repeat/extension of original72cohort."""
from pathlib import Path
import json,sys,time,random,hashlib,collections
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.result import SessionStatus
D=Path(".local_agent/td-tree-20261017");O=D/"conditional-prefix";O.mkdir(exist_ok=False)
original=json.loads((D/"generic-prefix-v2/result.json").read_bytes());rules={r["slot"]:r["ruleset"]for r in original["rules"]};meta={r["slot"]:r for r in original["rows"]}
slots=[dict(rule=k,replicate=r,seed=9800000+k*10000+r)for k in sorted(rules)for r in range(16)];random.Random(2026101702).shuffle(slots)
plan=dict(question="Is the observed late-prefix survivor shift robust to continuation randomness WITHIN rules, rather than a single bad path?",changed_premise="Original72singlepaths cannot estimate rule-specific survival or retainedrule measure; NEW16uniformcontinuationseeds perSAMErule, independentofmodels/outcomes, notnewindependentfamilies orunchangedoldcapextension.",decision="Estimate16/64survival andnonzero-input perrule and retainedruleTV. Distinguish zeroobservations from impossible/unplayable. If retainedmeasures differ, universal64sampler notadopted; futuremixture mustpreserveoriginalrulemeasure. No fit/learner/strength inference.",slots=slots,horizons=[16,64],forecast_seconds=240,cap_seconds=600,scope="Existing72exposedatom-generatorrules/fullpromotion/drop/currentbase/history. Newpolicyseeds1152trajectories; no newrule/generatorselection/semanticdomainshrink. Allslots/partial/unstartedretained, uniformtypedbindings. NotAUXChessTRAIN ornewsearch/prover.",source_hashes={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in("generic_chess/core/semantic_executor.py","generic_chess/core/transition.py","generic_chess/session/session.py")})
write_json(O/"plan.json",plan);start=time.monotonic();write_json(O/"started.json",dict(utc=__import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()))
compiled={k:compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(r)))for k,r in rules.items()};rows=[];edges=0;status="COMPLETE";cause=None
def poll():
 if time.monotonic()-start>=plan["cap_seconds"]:raise TimeoutError("FROZEN_GLOBAL_CAP")
 for name in("rollout","advisor","slack"):
  f=json.loads((Path(".local_agent")/(name+".json")).read_bytes())
  if f.get("stopped")or f.get("user_paused"):raise InterruptedError("EXPLICIT_STOP")
def channels(s,ids):
 b=collections.Counter();h=collections.Counter()
 for p in s.state.position.board:
  if p:b[p.current_type_id]+=1 if p.owner==0 else-1
 for owner,hand in enumerate(s.state.position.hands):
  for t,n in hand.counts:h[t]+=(1 if owner==0 else-1)*n
 return [b[t]for t in ids]+[h[t]for t in ids]
try:
 with(O/"paths.jsonl").open("x",encoding="utf8")as f:
  for slot in slots:
   poll();k=slot["rule"];c=compiled[k];s=GameSession(c);rng=random.Random(slot["seed"]);ids=sorted(t.type_id for t in deserialize_ruleset(json.dumps(rules[k])).piece_types if not t.is_anchor);r=dict(**slot,board=meta[k]["board"],preset=meta[k]["preset"],checkpoints=[],drops=0,promotions=0)
   try:
    for ply in range(65):
     poll();res=s.result;assert len(s.state.history)==ply+1
     if ply in(16,64):
      phi=channels(s,ids);body=json.dumps(record_value(s.state),sort_keys=True,separators=(",",":")).encode();r["checkpoints"].append(dict(ply=ply,ongoing=res.status is SessionStatus.ONGOING,nonzero_free=any(phi),phi=phi,type_ids=ids,fullstate_sha256=hashlib.sha256(body).hexdigest(),history_length=len(s.state.history)))
     if res.status is not SessionStatus.ONGOING:r.update(ending="ACTUAL_"+res.status.value,terminal_ply=ply);break
     if ply==64:r["ending"]="PREFIX64_ONGOING";break
     aa=sorted(s.legal_actions(),key=lambda a:json.dumps(record_value(a),sort_keys=True,separators=(",",":")));assert aa
     a=rng.choice(aa);v=record_value(a);r["drops"]+="base_type_id"in v;r["promotions"]+=v.get("promotion_target_id")is not None;s.submit(a);edges+=1
   except(TimeoutError,InterruptedError):
    r["ending"]="PARTIAL_INTERRUPTED";raise
   finally:
    r.update(record=record_value(s.to_record()),result=record_value(s.result));f.write(json.dumps(r,separators=(",",":"))+"\n");f.flush();rows.append(r)
   if len(rows)%72==0:
    write_json(O/"progress.json",dict(closed=len(rows),edges=edges,seconds=time.monotonic()-start));print("PROGRESS",len(rows),edges,round(time.monotonic()-start,3),flush=True)
except(TimeoutError,InterruptedError)as e:status="PARTIAL";cause=str(e)
except Exception as e:status="ERROR";cause=repr(e);__import__("traceback").print_exc()
write_json(O/"result.json",dict(status=status,cause=cause,planned=len(slots),recorded=len(rows),unstarted=len(slots)-len(rows),edges=edges,seconds=time.monotonic()-start,rule_count=len(rules)))
print("CLOSED",status,len(rows),edges,round(time.monotonic()-start,3),cause,flush=True)

