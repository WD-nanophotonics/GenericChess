from pathlib import Path
import json,collections,math,hashlib,sys,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path('.local_agent/td-tree-20261017');O=D/'conditional-prefix'
v=[json.loads(s) for s in (O/'paths.jsonl').read_text(encoding='utf8').splitlines()]
assert len(v)==1152 and len({(r['rule'],r['replicate'])for r in v})==1152
assert all(r['seed']==9800000+r['rule']*10000+r['replicate']for r in v)
rules=[]
for k in range(72):
 rr=[r for r in v if r['rule']==k];assert len(rr)==16
 z=dict(rule=k,board=rr[0]['board'],preset=rr[0]['preset'])
 for h in (16,64):
  cc=[c for r in rr for c in r['checkpoints']if c['ply']==h]
  z[str(h)]=dict(reached=len(cc),ongoing=sum(c['ongoing']for c in cc),nonzero_ongoing=sum(c['ongoing']and c['nonzero_free']for c in cc))
 rules.append(z)
def summary(rr):
 out={}
 for h in ('16','64'):
  a=np.array([r[h]['ongoing']for r in rr]);b=np.array([r[h]['nonzero_ongoing']for r in rr]);p=a/a.sum()
  out[h]=dict(ongoing=int(a.sum()),nonzero_ongoing=int(b.sum()),paths=16*len(rr),rules=len(rr),zero_observed_survival=int(np.sum(a==0)),all16_survive=int(np.sum(a==16)),rule_distribution_TV_from_uniform=float(np.sum(abs(p-1/len(rr)))/2),rule_effective_count=float(1/np.sum(p*p)),survival_histogram={str(i):int(np.sum(a==i))for i in range(17)})
 p=np.array([r['16']['ongoing']for r in rr],float);q=np.array([r['64']['ongoing']for r in rr],float)
 out['between_horizons_TV']=float(np.sum(abs(p/p.sum()-q/q.sum()))/2)
 out['newly_zero_rule_ids']=[r['rule']for r in rr if r['16']['ongoing']and not r['64']['ongoing']]
 return out
out=dict(status='COMPLETE',scope='72 exposed rules, 16 fresh paths each; rule is cluster, not 1152 independent rules. Descriptive empirical survival/conditional measure only, not unplayability or strength.',all=summary(rules),by_board={str(b):summary([r for r in rules if r['board']==b])for b in (4,6,8)},by_preset={p:summary([r for r in rules if r['preset']==p])for p in sorted({r['preset']for r in rules})},rules=rules,terminals=collections.Counter(r['ending']for r in v),drops=sum(r['drops']for r in v),promotions=sum(r['promotions']for r in v))
write_json(D/'conditional-prefix-summary.json',out)
print(json.dumps({k:z for k,z in out.items()if k!='rules'},indent=2))
