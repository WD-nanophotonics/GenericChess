from pathlib import Path
import json,sys,hashlib,time,collections
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=Path('.local_agent/td-tree-20261017');O=D/'conditional-prefix';start=time.monotonic()
plan=json.loads((O/'plan.json').read_bytes())
for p,h in plan['source_hashes'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
rules={r['slot']:r['ruleset']for r in json.loads((D/'generic-prefix-v2/result.json').read_bytes())['rules']}
compiled={k:compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(r)))for k,r in rules.items()}
n=edges=checks=0
for line in (O/'paths.jsonl').open(encoding='utf8'):
 r=json.loads(line);s=GameSession(compiled[r['rule']]);cc={c['ply']:c for c in r['checkpoints']}
 for a in r['record']['actions']:
  act=SemanticBoardMove(a['pattern_id'],a['geometry_id'],a['actor_type_id'],Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])if'from_square'in a else SemanticDropMove(a['pattern_id'],a['geometry_id'],a['base_type_id'],Square(**a['to_square']))
  s.submit(act);edges+=1;ply=s.state.ply_count;assert len(s.state.history)==ply+1
  if ply in cc:
   c=cc[ply];body=json.dumps(record_value(s.state),sort_keys=True,separators=(',',':')).encode();assert hashlib.sha256(body).hexdigest()==c['fullstate_sha256'];checks+=1
 assert record_value(s.to_record())==r['record']and record_value(s.result)==r['result'];n+=1
 if n%72==0:
  assert time.monotonic()-start<180
  for name in ('rollout','advisor','slack'):
   f=json.loads((Path('.local_agent')/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
write_json(D/'conditional-replay.json',dict(status='PASS',paths=n,edges=edges,states=edges+n,checkpoints=checks,seconds=time.monotonic()-start,scope='All saved typed actions actually resubmitted through full Core, full checkpoint state hashes/history and final records/results equal. Same implementation replay, not independent rule oracle.'))
print(n,edges,checks,round(time.monotonic()-start,3))
