from pathlib import Path
import json,collections,sys
sys.path.insert(0,str(Path.cwd()))
from tools.local_agent.common import write_json
D=Path('.local_agent/td-tree-20261017');rows=[json.loads(s)for s in(D/'conditional-prefix/paths.jsonl').read_text(encoding='utf8').splitlines()]
def category(r,h):
 c=next((c for c in r['checkpoints']if c['ply']==h),None)
 return 'absent_terminal'if c is None else'terminal_at_checkpoint'if not c['ongoing']else'ongoing_nonzero'if c['nonzero_free']else'ongoing_zero'
pairs=collections.Counter((category(r,16),category(r,64))for r in rows)
# Any resampling of surviving starts changes rule measure. This calculation is finite empirical support, not a learned sampler.
rule_counts={k:{h:sum(category(r,h).startswith('ongoing')for r in rows if r['rule']==k)for h in(16,64)}for k in range(72)}
weighted={}
for h in(16,64):
 counts=[x[h]for x in rule_counts.values()];supported=sum(x>0 for x in counts)
 weights=[1/c for c in counts if c>0 for _ in range(c)]
 weighted[str(h)]=dict(supported_rules=supported,missing_rule_mass=(72-supported)/72,max_inverse_count_weight=max(weights),min_inverse_count_weight=min(weights),empirical_equal_rule_weight_ESS=sum(weights)**2/sum(w*w for w in weights),interpretation='Equal weight per observed rule can flatten ONLY the supported empirical rule marginal; it cannot reconstruct absent histories, unsupported rules, unbiased unknown probabilities or payoff/learning utility.')
out=dict(paired_categories=[dict(at16=a,at64=b,count=n)for(a,b),n in sorted(pairs.items())],weights=weighted,rejected_route='Uniformly keep only64ply ongoing paths or retry/filter until quotas fill; silently discards chosen short-line evidence and changes measure/cost.',selected_route='For future consumer freeze rule-first attempted slots plus a declared prefix mixture; preserve actual terminal records and prefix/status tags, expose ongoing-only estimand separately. No sampler/API/training implementation until real consumer needed.',current_consumer='collect_self_play creates GameSession(compiled) directly and has no prefix-import argument. Do not fabricate GameState or inject a new sampler merely from this diagnostic. AUX owns its own training lane.')
write_json(D/'conditional-design.json',out);print(json.dumps(out,indent=2))
