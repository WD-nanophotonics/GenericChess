"""Positive deployment mobility under real replies, with terminal outcome kept separate."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'deployment-endpoints.json';assert not out.exists();started=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Four actual-history roots: Ncapture G/TP after sole reply, release-delay line at ownturn2/4. Uniform legal hand drop then uniform actual enemy legal reply. Changed metric premise: prior action-count proxy also counted promotion alternatives. Proxy U now counts distinct deployed-piece own target endpoints on next actual turn; retain exact actions/count separately. Captured/terminal branches U0; terminal winner kept separately, never interpreted as zero game utility. No virtual pass or inserted hand. Complete Core/Native transitions/legal/terminal parity;20sec/8000reply-frontier checkpoint perroot. No default table, WDL calibration, human fit or optimal policy. This asks whether availability and positive continuation mobility alone retain terminal deployment utility.',rows=[])
write_record(out,r);cases=[]
for row in json.loads((p/'capture-swing-knight.json').read_bytes())['rows']:
 cases.append((row['target'],row['definition'],[row['capture'],row['enemy_replies'][0]['reply']]))
delay=json.loads((p/'release-delay-completed.json').read_bytes())
for ply in (2,4):cases.append(('release-ply'+str(ply),delay['definition'],delay['actions'][:ply]))
for name,definition,route in cases:
 c=compile_ruleset_for_execution(ruleset_from_dict(definition));s=GameSession(c)
 for encoded in route:
  matches=[a for a in s.legal_actions() if record_value(a)==encoded];assert len(matches)==1;s.submit(matches[0])
 nr=compile_native_semantic_rules(c);mirror=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True);np=mirror.position
 row=dict(name=name,history_length=len(s.state.history),root_history_sha256=hashlib.sha256(json.dumps(record_value(s.state.history),sort_keys=True).encode()).hexdigest(),complete=False,drops=[],reply_frontiers=0);r['rows'].append(row);write_record(out,r)
 assert set(s.legal_actions())=={public_action(nr,a) for a in guarded_actions(nr,np)}
 dropactions=[a for a in s.legal_actions() if hasattr(a,'base_type_id')];start=time.perf_counter()
 for drop in dropactions:
  if time.perf_counter()-start>20 or row['reply_frontiers']>=8000:break
  child=apply_action(s.state,drop,c);native_child=make_checked(nr,np,mirror.direct_pack(drop,s.state.position));assert snapshot_matches(snapshot(nr,native_child),child.position,nr,c)
  nt=terminal_status(nr,native_child);ct=child.terminal_status;assert (nt['status'],nt['winner'])==(ct.status.value,ct.winner)
  replies=legal_actions(child,c);nreplies=guarded_actions(nr,native_child);assert set(replies)=={public_action(nr,a) for a in nreplies}
  d=dict(action=record_value(drop),terminal=record_value(ct),reply_count=len(replies),continuations=[],mean_next_piece_moves=None);row['drops'].append(d)
  for na in nreplies:
   reply=public_action(nr,na);nextstate=apply_action(child,reply,c);nn=make_checked(nr,native_child,na);assert snapshot_matches(snapshot(nr,nn),nextstate.position,nr,c)
   nt=terminal_status(nr,nn);ct=nextstate.terminal_status;assert (nt['status'],nt['winner'])==(ct.status.value,ct.winner)
   actions=legal_actions(nextstate,c);assert set(actions)=={public_action(nr,a) for a in guarded_actions(nr,nn)}
   ownmoves=[a for a in actions if hasattr(a,'from_square') and a.from_square==drop.to_square]
   # A surviving piece is identified at the actual dropped square; an enemy
   # capture leaves no own source there. Every continuation is a real turn.
   d['continuations'].append(dict(reply=record_value(reply),terminal=record_value(ct),deployed_piece_moves=len({(a.to_square.file,a.to_square.rank) for a in ownmoves}),legal_boardmove_count=len(ownmoves),legal_boardmoves=record_value(ownmoves)));row['reply_frontiers']+=1
  d['mean_next_piece_moves']=str(Fraction(sum(x['deployed_piece_moves'] for x in d['continuations']),len(replies))) if replies else '0'
 else:row['complete']=True
 if row['complete']:
  row['drop_count']=len(dropactions);row['immediate_winning_drops']=sum(d['terminal']['winner']==s.state.position.side_to_move and d['terminal']['status']!='ONGOING' for d in row['drops'])
  row['uniform_drop_mean_U']=str(sum(Fraction(d['mean_next_piece_moves']) for d in row['drops'])/len(dropactions)) if dropactions else '0'
  row['max_nonterminal_drop_U']=str(max((Fraction(d['mean_next_piece_moves']) for d in row['drops'] if d['reply_count']),default=Fraction(0)))
 row['seconds']=time.perf_counter()-start;write_record(out,r);print(name,{k:v for k,v in row.items() if k not in ('drops','root_history_sha256')},flush=True)
r.update(complete=all(x['complete'] for x in r['rows']),seconds=time.perf_counter()-started);write_record(out,r)
