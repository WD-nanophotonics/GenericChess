"""Append deployment evidence without changing original archive bytes."""
import json,hashlib,zipfile,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];p=Path(__file__).parent;dest=ROOT/'docs/archive/lifecycle_20261008'
def h(raw):return hashlib.sha256(raw).hexdigest()
target=dest/'deployment.zip';assert not target.exists();files=[p/n for n in ('deployment-proxy.py','deployment-proxy.json','deployment-endpoints.py','deployment-endpoints.json','collect-deployment-supplement.py')];members=[]
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  body=f.read_bytes();name=f.relative_to(ROOT).as_posix();z.writestr(name,body);members.append(dict(path=name,bytes=len(body),sha256=h(body)))
with tempfile.TemporaryDirectory(dir=p,prefix='deployment-extract-') as temp:
 with zipfile.ZipFile(target) as z:assert z.testzip() is None;z.extractall(temp)
 for m in members:assert h((Path(temp)/m['path']).read_bytes())==m['sha256']
data=json.loads((p/'deployment-endpoints.json').read_bytes());assert data['complete']
summary=dict(base_sha='4c7410521de167b09d7cee9c903e5f00da64353e',file='deployment.zip',sha256=h(target.read_bytes()),members=members,verified_extracted=True,correction='Initial U counts BoardMove alternatives inclpromotion, revised U counts distinct target endpoints; original raw preserved. Terminal branches U0 by definition, never zero outcome utility.',reply_frontiers=sum(x['reply_frontiers'] for x in data['rows']),rows=[{k:v for k,v in row.items() if k!='drops'} for row in data['rows']])
(dest/'deployment-index.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
path=ROOT/'docs/research/data/lifecycle_20261008.json';current=json.loads(path.read_bytes());current['deployment_proxy']=dict(reply_frontiers=summary['reply_frontiers'],rows=summary['rows'],archive='../../archive/lifecycle_20261008/deployment-index.json',scope=summary['correction']);path.write_text(json.dumps(current,indent=2)+'\n',encoding='utf8');print('Verified',len(members),'supplemental members; reply frontiers',summary['reply_frontiers'])
