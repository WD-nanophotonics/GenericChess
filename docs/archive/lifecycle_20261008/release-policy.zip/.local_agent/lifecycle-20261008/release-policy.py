"""One real own/enemy cycle: release availability depends on declared behavior."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'release-policy.json';assert not out.exists();source=p/'release-delay-completed.json';raw=source.read_bytes();data=json.loads(raw);assert data['complete'];start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(raw).hexdigest(),declaration='Same actual captured-handP blocked root at ownturnply2. Enumerate all own actions and every real enemy reply to next ownturn. Uniform legal own action vs uniform promotion-if-available own action; enemy uniform legal in both.20sec/4000frontier checkpoint. Report probability of immediate Pawnhand availability at next ownturn and mean drop count; no eventual/minimum release, geometric waiting assumption or WDL claim. All branches full Core/Native action/position/history/terminal parity. Behavior selection explicit, not fitted to price.',branches=[],policies=[])
write_record(out,r);c=compile_ruleset_for_execution(ruleset_from_dict(data['definition']));s=GameSession(c)
for enc in data['actions'][:2]:
 a,=[a for a in s.legal_actions() if record_value(a)==enc];s.submit(a)
nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True);np=m.position;actions=s.legal_actions();assert not any(hasattr(a,'base_type_id') for a in actions);assert set(actions)=={public_action(nr,a) for a in guarded_actions(nr,np)};frontiers=0
for action in actions:
 if time.perf_counter()-start>20 or frontiers>=4000:break
 child=apply_action(s.state,action,c);nc=make_checked(nr,np,m.direct_pack(action,s.state.position));assert snapshot_matches(snapshot(nr,nc),child.position,nr,c)
 replies=legal_actions(child,c);nas=guarded_actions(nr,nc);assert set(replies)=={public_action(nr,a) for a in nas}
 row=dict(action=record_value(action),promotion=bool(getattr(action,'promotion_target_id',None)),replies=[]);r['branches'].append(row)
 for na in nas:
  reply=public_action(nr,na);own=apply_action(child,reply,c);nn=make_checked(nr,nc,na);assert snapshot_matches(snapshot(nr,nn),own.position,nr,c)
  nt=terminal_status(nr,nn);ct=own.terminal_status;assert (nt['status'],nt['winner'])==(ct.status.value,ct.winner)
  legal=legal_actions(own,c);assert set(legal)=={public_action(nr,a) for a in guarded_actions(nr,nn)};drops=[a for a in legal if getattr(a,'base_type_id',None)=='P'];row['replies'].append(dict(action=record_value(reply),drop_count=len(drops),terminal=record_value(ct)));frontiers+=1
 row['release_probability']=str(Fraction(sum(x['drop_count']>0 for x in row['replies']),len(replies))) if replies else '0';row['mean_drop_count']=str(Fraction(sum(x['drop_count'] for x in row['replies']),len(replies))) if replies else '0';write_record(out,r)
else:r['complete']=True
if r['complete']:
 for name in ('uniform','promotion-if-available'):
  subset=r['branches'] if name=='uniform' else [x for x in r['branches'] if x['promotion']];assert subset
  r['policies'].append(dict(name=name,own_actions=len(subset),next_turn_release_probability=str(sum(Fraction(x['release_probability']) for x in subset)/len(subset)),mean_next_turn_drops=str(sum(Fraction(x['mean_drop_count']) for x in subset)/len(subset))))
r.update(reply_frontiers=frontiers,seconds=time.perf_counter()-start);write_record(out,r);print('complete',r['complete'],'frontiers',frontiers,'policies',r['policies'])
