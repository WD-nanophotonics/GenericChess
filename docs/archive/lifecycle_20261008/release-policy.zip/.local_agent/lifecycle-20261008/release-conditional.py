"""Does a single observed release probability remain stationary after legal play?"""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'release-conditional.json';assert not out.exists();source=json.loads((p/'release-delay-completed.json').read_bytes());first=json.loads((p/'release-policy.json').read_bytes());assert first['complete'];start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256((p/'release-policy.json').read_bytes()).hexdigest(),declaration='Changed decision question: stationary geometric waiting approximation from first-turn uniform q1/14. Two explicitly selected non-release mechanisms: first canonical king action, first canonical Knight promotion; each then first canonical real enemy reply. At resulting ownturn enumerate all own actions/all enemy replies under uniform legal policies,20sec/4000frontiers each. No whole two-turn average or geometric waiting fit. Full real histories, Native transition/legal/terminal checks at every enumerated child and next ownturn.',rows=[])
write_record(out,r)
for mechanism in ('king','knight-promotion'):
 options=[b for b in first['branches'] if b['action'].get('actor_type_id')==('K' if mechanism=='king' else 'N') and (mechanism=='king' or b['promotion'])];assert options
 branch=sorted(options,key=lambda b:json.dumps(b['action'],sort_keys=True))[0];reply=sorted(branch['replies'],key=lambda x:json.dumps(x['action'],sort_keys=True))[0];assert reply['drop_count']==0
 route=source['actions'][:2]+[branch['action'],reply['action']];c=compile_ruleset_for_execution(ruleset_from_dict(source['definition']));s=GameSession(c)
 for enc in route:
  a,=[a for a in s.legal_actions() if record_value(a)==enc];s.submit(a)
 nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True);actions=s.legal_actions();assert not any(hasattr(a,'base_type_id') for a in actions)
 row=dict(mechanism=mechanism,route=route,own_actions=len(actions),branches=[],complete=False);r['rows'].append(row);begin=time.perf_counter();count=0
 for a in actions:
  if time.perf_counter()-begin>20 or count>=4000:break
  ch=apply_action(s.state,a,c);nc=make_checked(nr,m.position,m.direct_pack(a,s.state.position));assert snapshot_matches(snapshot(nr,nc),ch.position,nr,c);nt=terminal_status(nr,nc);ct=ch.terminal_status;assert (nt['status'],nt['winner'])==(ct.status.value,ct.winner)
  replies=guarded_actions(nr,nc);assert {public_action(nr,b) for b in replies}==set(legal_actions(ch,c));outcomes=[]
  for b in replies:
   nn=make_checked(nr,nc,b);own=apply_action(ch,public_action(nr,b),c);assert snapshot_matches(snapshot(nr,nn),own.position,nr,c);nt=terminal_status(nr,nn);ct=own.terminal_status;assert (nt['status'],nt['winner'])==(ct.status.value,ct.winner)
   las=legal_actions(own,c);assert set(las)=={public_action(nr,z) for z in guarded_actions(nr,nn)};outcomes.append(sum(getattr(z,'base_type_id',None)=='P' for z in las));count+=1
  row['branches'].append(dict(action=record_value(a),enemy_reply_drop_counts=outcomes,probability=str(Fraction(sum(x>0 for x in outcomes),len(outcomes))) if outcomes else '0'))
 else:row['complete']=True
 if row['complete']:row['uniform_next_release_probability']=str(sum(Fraction(b['probability']) for b in row['branches'])/len(actions))
 row.update(reply_frontiers=count,seconds=time.perf_counter()-begin);write_record(out,r);print(mechanism,row['own_actions'],row.get('uniform_next_release_probability'),count)
r.update(complete=all(x['complete'] for x in r['rows']),seconds=time.perf_counter()-start);write_record(out,r)
