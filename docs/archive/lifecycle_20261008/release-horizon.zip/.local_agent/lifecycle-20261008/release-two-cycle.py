"""Quantify rather than automatically reject a stationary release approximation."""
import sys,json,time,hashlib
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action,legal_successors
from generic_chess.core.movegen import legal_actions
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'release-two-cycle.json';assert not out.exists();source=json.loads((p/'release-delay-completed.json').read_bytes());first=json.loads((p/'release-policy.json').read_bytes());assert first['complete'];start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),transition_sha256=hashlib.sha256((ROOT/'generic_chess/core/transition.py').read_bytes()).hexdigest(),declaration='One new bounded30sec/20000second-cycle-frontier batch to quantify a stationary approximation, not reject it merely because q varies. Same blocked actual-capture root; uniform legal own/enemy policies, probability of first availability within two own/enemy cycles. Actual full Core histories/terminal adjudication; no claim of independent Native replay for this entire expanded population. First-cycle matching uses prior validated raw branches. A previously available hand is absorbing for first-availability, not assumed still available. Ended games unavailable. Missing probability mass gives0..1 bounds, not success. Geometric prediction1-(13/14)^2 declared before enumeration; no fitted q or outcome-based extension.',first_cycle_probability='1/14',stationary_prediction='27/196',rows=[])
write_record(out,r);c=compile_ruleset_for_execution(ruleset_from_dict(source['definition']));s=GameSession(c)
for enc in source['actions'][:2]:
 a,=[a for a in s.legal_actions() if record_value(a)==enc];s.submit(a)
positive=Fraction(0);observed=Fraction(0);count=0;stop=False
for branch in first['branches']:
 a,=[a for a in s.legal_actions() if record_value(a)==branch['action']];ch=apply_action(s.state,a,c);replies=legal_actions(ch,c);assert len(replies)==len(branch['replies'])
 row=dict(first_action=branch['action'],positive_mass='0',observed_mass='0',second_frontiers=0);r['rows'].append(row);rp=Fraction(0);ro=Fraction(0)
 for replydata in branch['replies']:
  b,=[b for b in replies if record_value(b)==replydata['action']];own=apply_action(ch,b,c);w=Fraction(1,len(first['branches'])*len(replies))
  if replydata['drop_count']>0:positive+=w;observed+=w;rp+=w;ro+=w;continue
  second=legal_successors(own,c)
  if not second:observed+=w;ro+=w;continue
  for a2,ch2 in second:
   enemy=legal_successors(ch2,c)
   if not enemy:mass=w/len(second);observed+=mass;ro+=mass;continue
   for b2,own2 in enemy:
    if time.perf_counter()-start>30 or count>=20000:stop=True;break
    mass=w/(len(second)*len(enemy));las=legal_actions(own2,c);available=any(getattr(x,'base_type_id',None)=='P' for x in las);observed+=mass;ro+=mass
    if available:positive+=mass;rp+=mass
    count+=1;row['second_frontiers']+=1
   if stop:break
  if stop:break
 row.update(positive_mass=str(rp),observed_mass=str(ro));write_record(out,r)
 if stop:break
r.update(complete=not stop,second_frontiers=count,observed_probability_mass=str(observed),release_probability_lower=str(positive),release_probability_upper=str(positive+1-observed),seconds=time.perf_counter()-start)
if not stop:assert observed==1;r['absolute_stationary_error']=str(abs(positive-Fraction(27,196)))
write_record(out,r);print({k:v for k,v in r.items() if k not in ('rows','declaration')})
