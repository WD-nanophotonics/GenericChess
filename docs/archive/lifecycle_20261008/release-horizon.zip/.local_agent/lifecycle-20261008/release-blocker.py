"""Actual Knight promotion can occupy the Pawn's release destination."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'release-blocker.json';assert not out.exists();data=json.loads((p/'release-delay-completed.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(data['definition']));s=GameSession(c);nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True);start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='One changed interaction: actual capturedN goes4,4 to3,6 unpromoted, then4,8 mandatoryTN; it occupies ownP4,7 release destination. Enemy takes canonical legal replies. Compare all own actions/all enemy replies at resulting ownturn,20sec/4000frontiers. Conditional mechanism, not whole third-cycle population or extrapolation of prior two-cycle coincidence. Full Core/Native action/position/terminal parity.',route=[],rows=[])
write_record(out,r)
route=[data['actions'][0],data['actions'][1]]
for ply in range(6):
 actions=s.legal_actions();assert set(actions)=={public_action(nr,a) for a in guarded_actions(nr,m.position)};assert snapshot_matches(m.snapshot(),s.state.position,nr,c)
 nt=terminal_status(nr,m.position);ct=s.state.terminal_status;assert (nt['status'],nt['winner'])==(ct.status.value,ct.winner)
 if ply<2:a,=[a for a in actions if record_value(a)==route[ply]]
 elif ply in (2,4):
  source,target,prom=((4,4),(3,6),None) if ply==2 else ((3,6),(4,8),'TN')
  a,=[a for a in actions if (a.from_square.file,a.from_square.rank)==source and (a.to_square.file,a.to_square.rank)==target and a.promotion_target_id==prom]
 else:a=sorted(actions,key=lambda x:json.dumps(record_value(x),sort_keys=True))[0]
 m.push(a,s.state.position);s.submit(a);r['route'].append(record_value(a));write_record(out,r)
assert not any(hasattr(a,'base_type_id') for a in s.legal_actions());count=0
for a in s.legal_actions():
 if time.perf_counter()-start>20 or count>=4000:break
 child=apply_action(s.state,a,c);nc=make_checked(nr,m.position,m.direct_pack(a,s.state.position));assert snapshot_matches(snapshot(nr,nc),child.position,nr,c);nas=guarded_actions(nr,nc);assert set(legal_actions(child,c))=={public_action(nr,b) for b in nas};row=dict(action=record_value(a),reply_drop_counts=[]);r['rows'].append(row)
 for b in nas:
  own=apply_action(child,public_action(nr,b),c);nn=make_checked(nr,nc,b);assert snapshot_matches(snapshot(nr,nn),own.position,nr,c);nt=terminal_status(nr,nn);ct=own.terminal_status;assert (nt['status'],nt['winner'])==(ct.status.value,ct.winner);las=legal_actions(own,c);assert set(las)=={public_action(nr,x) for x in guarded_actions(nr,nn)};row['reply_drop_counts'].append(sum(getattr(x,'base_type_id',None)=='P' for x in las));count+=1
 write_record(out,r)
else:r['complete']=True
r.update(reply_frontiers=count,own_actions=len(r['rows']),any_next_turn_release=any(x for row in r['rows'] for x in row['reply_drop_counts']),seconds=time.perf_counter()-start);write_record(out,r);print({k:v for k,v in r.items() if k not in ('route','rows','declaration')})
