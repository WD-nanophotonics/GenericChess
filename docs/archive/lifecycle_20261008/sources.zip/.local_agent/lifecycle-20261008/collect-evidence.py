"""Package exact isolated Agent evidence; not an experiment or active framework."""
import json,hashlib,zipfile,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];p=Path(__file__).parent
dest=ROOT/'docs/archive/lifecycle_20261008';dest.mkdir(exist_ok=True)
assert not (dest/'index.json').exists()
def h(raw):return hashlib.sha256(raw).hexdigest()
def read(name):return json.loads((p/name).read_bytes())
cost=read('drop-cost-comparison.json');exchange=read('generated-exchange.json');margins=read('action-margins.json');scope=read('eager-event-scope.json');laws=read('release-law.json')
summary=dict(date='2026-10-08',base_sha='4c7410521de167b09d7cee9c903e5f00da64353e',science='OPEN',defaults_changed=False,scope='Exposed synthetic diagnostics; no human data or strength/universal price claims.',capture_reset=dict(native_frontier_transitions=362,public_calls=24,knight='G winningdrop vs resetP no2plymate',rook_control='both mate'),core_eager=dict(calls=cost['rows'],immediate_full_state_parity=cost['immediate_full_state_parity'],scope='Equal6126-leaf Core reference only; prior unknowns unchanged'),generated=dict(public_calls=32,complete_references=14,total_references=16,paired_actions_equal=8,action_margins=[dict(source=x['source'],ply=x['ply'],profiles=x['profiles'],max_action_value_difference=x['max_action_value_difference'],optimal_set_equal=x['optimal_set_equal']) for x in margins['rows']]),event_scope=dict(roots=sum(len(x['rows']) for x in scope['cases']),calls=sum(len(row['calls']) for x in scope['cases'] for row in x['rows']),full_state_and_native_parity=True,fixtures=[dict(fixture=x['fixture'],route=x['route'],hands=[y['hands'] for y in x['rows']]) for x in scope['cases']]),hand_context=dict(prefix_cells=160,all_masks=512,legal_only=True,release_laws=laws['laws'],actual_release_line='Four real plies; blocked0 to7 after capturedPawn and mandatorypromotion; not minimal delay'),qualification=read('final-qualification.json'),archive='../../archive/lifecycle_20261008/index.json')
(ROOT/'docs/research/data/lifecycle_20261008.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
sources=[x for x in p.iterdir() if x.suffix=='.py'];raws=[x for x in p.iterdir() if x.suffix=='.json']
old=ROOT/'.local_agent/semantic-candidate-20261008'
deps=[old/f'generated-{n}-{seed}-candidate.json' for n in (4,6) for seed in (7,21)]+[old/'event-history-qualified.json',old/'drop-event-definition.json']
snapshots=[ROOT/'generic_chess/core/transition.py',ROOT/'tests/product/test_legal_successors.py']
index=dict(base_sha=summary['base_sha'],scope='Exact Agent evidence only; excluded private/account/Slack/workflow data.',packages=[],dependencies='Restore recorded .local_agent paths in isolated checkout of base SHA; install snapshot transition for after comparisons. Prior sources/results otherwise already committed at base. Preserve existing raw outputs; fresh output directories for reruns.')
for name,files in (('sources.zip',sources+snapshots),('raw.zip',raws),('dependencies.zip',deps)):
 target=dest/name;assert not target.exists();members=[]
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for path in sorted(files):
   rel=path.relative_to(ROOT).as_posix();body=path.read_bytes();z.writestr(rel,body);members.append(dict(path=rel,bytes=len(body),sha256=h(body)))
 with tempfile.TemporaryDirectory(dir=p,prefix='extract-check-') as temp:
  with zipfile.ZipFile(target) as z:
   assert z.testzip() is None;z.extractall(temp)
  for m in members:assert h((Path(temp)/m['path']).read_bytes())==m['sha256']
 index['packages'].append(dict(file=name,sha256=h(target.read_bytes()),members=members,verified_extracted=True))
(dest/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf8');print([(x['file'],len(x['members'])) for x in index['packages']])
