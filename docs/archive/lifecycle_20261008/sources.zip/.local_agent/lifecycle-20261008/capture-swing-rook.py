"""A declared exchange-swing decomposition and one real transfer counterexample."""
import sys,time,hashlib,json
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.terminal import terminal_result
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.config import EvaluationConfig,MATE_SCORE
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'capture-swing.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='New hypothesis, not old signed tag service. Positive current opportunity A_i decomposed as board V_i=A_i-beta*A_base and recipient hand H_base=beta*A_base, beta in0,.25,.5,.75. Thus capture swing V_i+H_base=A_i predicts equal local exchange coefficients for identical current geometry, even different reset base. Test one predeclared actual Shogi4entity context, ownK(7,6), enemyK(8,8), ownR(4,1), enemyG or baseP/currentTP(4,4). Actual legal R capture; preserve both kings/all rules/all replies/promotion/drop legality. Terminal-only zero nonterminal evaluation, exact conditional2plies after capture if Core completes. This is an exposed synthetic conditional-tempo counterexample, not game price, reachability from a standard opening, full P loss/draw or fitted coefficients. Core checkpoint4096leaves/10sec; every unknown retained.',law=[],rows=[])
write_record(out,r);base=build_standard_shogi_ruleset();cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
class TerminalOnly(Evaluator):
 def evaluate(self,state):return 0
for target in ('G','TP'):
 board=[[None]*9 for _ in range(9)]
 for owner,tid,f,rank in ((0,'K',7,6),(1,'K',8,8),(0,'R',4,1)):board[rank][f]=Piece(owner,tid,tid)
 board[4][4]=Piece(1,'P' if target=='TP' else 'G',target,target=='TP');definition=replace(base,initial_position=tuple(tuple(x) for x in board));c=compile_ruleset_for_execution(definition);session=GameSession(c);prof,scope=build_semantic_opportunity_profile(c,cfg);ev=TerminalOnly(c,prof,cfg)
 row=dict(target=target,definition=ruleset_to_dict(definition),current_raw=scope['types'][target]['raw'],base_raw=scope['types']['P' if target=='TP' else 'G']['raw'],capture=None,enemy_replies=[],reference=None);r['rows'].append(row);write_record(out,r)
 captures=[a for a in session.legal_actions() if a.from_square.file==4 and a.from_square.rank==1 and a.to_square.file==4 and a.to_square.rank==4 and a.promotion_target_id is None];assert len(captures)==1;capture=captures[0];child=apply_action(session.state,capture,c);row['capture']=record_value(capture)
 for reply in legal_actions(child,c):
  own=apply_action(child,reply,c);wins=[];moves=legal_actions(own,c)
  for action in moves:
   terminal=terminal_result(apply_action(own,action,c),c)
   if terminal.is_terminal and terminal.winner==0:wins.append(record_value(action))
  row['enemy_replies'].append(dict(reply=record_value(reply),own_legal_actions=len(moves),own_immediate_wins=wins))
 reference=CountedEvaluator(ev,seconds=10,evaluations=4096)
 try:score,action=reference_minimax(child,2,reference,c);row['reference']=dict(complete=True,enemy_view_score=score,action=record_value(action))
 except ReferenceLimit:row['reference']=dict(complete=False,enemy_view_score=None)
 row['reference']['leaf_evaluations']=reference.calls;write_record(out,r)
 print(target,'enemy replies',len(row['enemy_replies']),'wins',[(x['own_legal_actions'],len(x['own_immediate_wins'])) for x in row['enemy_replies']],row['reference'],flush=True)
for beta in (0.,.25,.5,.75):
 r['law'].append(dict(beta=beta,modes=[dict(target=x['target'],board=x['current_raw']-beta*x['base_raw'],hand=beta*x['base_raw'],swing=x['current_raw']) for x in r['rows']]))
r.update(complete=all(x['reference']['complete'] for x in r['rows']),seconds=time.perf_counter()-start);write_record(out,r)
