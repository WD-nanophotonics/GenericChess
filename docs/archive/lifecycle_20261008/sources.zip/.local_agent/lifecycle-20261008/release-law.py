"""Same type marginals, different immediate-release probability; no new executor calls."""
import json,hashlib,math
from pathlib import Path
from fractions import Fraction
p=Path(__file__).parent;source=p/'typed-file-law.json';raw=source.read_bytes();data=json.loads(raw);assert data['complete'];out=p/'release-law.json';assert not out.exists()
rows=data['rows'];result=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(raw).hexdigest(),declaration='Three explicitly chosen distributions over the same512 Core/Native-verified fixed-occupancy contexts. Each file has currentP marginal1/2; currentTP otherwise. Compare expected legal drop count, positive availability and mean conditional on availability. These are immediate position-only opportunities, not eventual release probability, WDL or material prices. No games/human labels or parameter selection.',laws=[])
for law in ('independent','all-correlated','balanced'):
 weighted=[]
 for row in rows:
  k=row['unpromoted_files'];mask=row['mask']
  w=Fraction(1,512) if law=='independent' else Fraction(1,2) if law=='all-correlated' and mask in (0,511) else Fraction(1,2*math.comb(9,k)) if law=='balanced' and k in (4,5) else Fraction(0)
  weighted.append((row,w))
 assert sum(w for row,w in weighted)==1
 marginals=[sum(w for row,w in weighted if row['mask']&(1<<f)) for f in range(9)];assert marginals==[Fraction(1,2)]*9
 mean=sum(w*row['drop_count'] for row,w in weighted);prob=sum(w for row,w in weighted if row['drop_count']>0);assert mean==31
 result['laws'].append(dict(law=law,file_marginals=list(map(str,marginals)),mean_drops=str(mean),probability_immediate_use=str(prob),mean_drops_when_usable=str(mean/prob)))
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result['laws'],indent=2))
