"""First independently qualified root per frozen generated definition."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=p.parent/'semantic-candidate-20261008';out=p/'generated-exchange.json';assert not out.exists();start=time.perf_counter()
class FixedOrdering:
 def __init__(self,scoring,ordering):self.scoring=scoring;self.ordering=ordering
 def evaluate(self,state):return self.scoring.evaluate(state)
 def type_value(self,tid):return self.ordering.type_value(tid)
 def capture_order_value(self,mover,victim):return self.ordering.capture_order_value(mover,victim)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='First qualified exchange root per frozen definition, chosen by legal capture structure before scoring. Actual history replay. Both static profiles, hand0 to isolate board prices; same baseline ordering, q0/root-tactical-off. Depth2/3 with4096nodes/5sec,2cold repeats; Core leaf8192/5sec reference at each depth. No speed/strength/universal price claim, no result-driven filtering. Unknown Core remains unknown; completed scores must match.',rows=[])
write_record(out,r);cfg=EvaluationConfig(hand_weight=0,dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for case in json.loads((p/'generated-discrimination-qualified.json').read_bytes())['cases']:
 qualified=[x for x in case['rows'] if x['qualifies_exchange_diagnostic']];assert qualified;root=qualified[0]
 definition=json.loads((old/case['source']).read_bytes())['source_definition'];c=compile_ruleset_for_execution(ruleset_from_dict(definition));s=GameSession(c)
 for action in case['transitions'][:root['ply']]:
  matching=[a for a in s.legal_actions() if record_value(a)==action];assert len(matching)==1;s.submit(matching[0])
 generic=build_ruleset_profile(c,cfg);candidate,scope=build_semantic_opportunity_profile(c,cfg);ordering=Evaluator(c,generic,cfg)
 item=dict(source=case['source'],ply=root['ply'],history_length=len(s.state.history),baseline_values=dict(generic.board_value_by_type),candidate_values=dict(candidate.board_value_by_type),cells=[]);r['rows'].append(item)
 for depth in (2,3):
  for label,profile in (('baseline',generic),('candidate',candidate)):
   scoring=Evaluator(c,profile,cfg);counted=CountedEvaluator(scoring,seconds=5,evaluations=8192)
   try:score,action=reference_minimax(s.state,depth,counted,c);ref=dict(complete=True,score=score,action=record_value(action))
   except ReferenceLimit:ref=dict(complete=False,score=None,action=None)
   ref['leaves']=counted.calls;cell=dict(depth=depth,scoring=label,reference=ref,calls=[]);item['cells'].append(cell);write_record(out,r)
   for repeat in range(2):
    player=AlphaBetaPlayer(c,evaluation_config=cfg,use_disk_cache=False,evaluator_override=FixedOrdering(scoring,ordering),tuning=SearchTuning(use_root_tactical=False),tt_max_entries=4096)
    before=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d)
    cell['calls'].append(dict(seconds=time.perf_counter()-before,repeat=repeat,decision=record_value(d),reference_score_equal=(d.score==ref['score']) if ref['complete'] and d.completed_depth==depth else None));write_record(out,r)
   cell['repeat_equal']=all(cell['calls'][0]['decision'][k]==cell['calls'][1]['decision'][k] for k in ('score','action','completed_depth'));assert cell['repeat_equal'];assert all(x['reference_score_equal'] is not False for x in cell['calls'])
   print(case['source'],root['ply'],depth,label,ref['complete'],[(x['decision']['completed_depth'],x['decision']['score'],x['decision']['nodes']) for x in cell['calls']],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
