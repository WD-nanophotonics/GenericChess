"""Qualification of existing generated roots, without choosing by score."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import legal_successors
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=p.parent/'semantic-candidate-20261008';out=p/'generated-discrimination.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Four frozen board4/6 seed7/21 definitions, at most8 actual plies each. Before evaluator search, classify legal child terminals and non-anchor captures. Price diagnostic requires at least2 nonterminal captures of2 distinct current types and no immediate terminal winner. Route prefers non-anchor capture, then canonical action, independent of prices/scores; actual terminal ends. A root failing this criterion remains evidence, not silently replaced. Synthetic exposed development only, no holdout/strength/true-price oracle.',cases=[])
write_record(out,r)
for size,seed in ((4,7),(4,21),(6,7),(6,21)):
 name=f'generated-{size}-{seed}-candidate.json';source=json.loads((old/name).read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(source['source_definition']));s=GameSession(c)
 case=dict(source=name,source_sha256=hashlib.sha256((old/name).read_bytes()).hexdigest(),rows=[],transitions=[]);r['cases'].append(case)
 for ply in range(8):
  if s.state.terminal_status.is_terminal:case['terminal']=record_value(s.state.terminal_status);break
  pairs=legal_successors(s.state,c);captures=[];terminals=[]
  for a,child in pairs:
   if child.terminal_status.is_terminal:terminals.append(dict(action=record_value(a),terminal=record_value(child.terminal_status)))
   v=record_value(a);target=v.get('to_square');piece=s.state.position.board[target['rank']*size+target['file']] if target else None
   if piece is not None and piece.owner!=s.state.position.side_to_move and not c.piece_type_by_id[piece.current_type_id].is_anchor:
    captures.append(dict(action=v,target=record_value(piece),terminal=record_value(child.terminal_status)))
  eligible=[x for x in captures if x['terminal']['status']=='ongoing'];winning=[x for x in terminals if x['terminal']['winner']==s.state.position.side_to_move]
  qualified=len(eligible)>=2 and len({x['target']['current_type_id'] for x in eligible})>=2 and not winning
  case['rows'].append(dict(ply=ply,history_length=len(s.state.history),legal_actions=len(pairs),captures=captures,terminal_children=terminals,qualifies_exchange_diagnostic=qualified));write_record(out,r)
  if not pairs:break
  def priority(item):
   a,child=item;v=record_value(a);return (0 if any(x['action']==v for x in captures) else 1,json.dumps(v,sort_keys=True))
  route=sorted(pairs,key=priority)[0][0];case['transitions'].append(record_value(route));s.submit(route)
 print(name,'roots',len(case['rows']),'qualified',[x['ply'] for x in case['rows'] if x['qualifies_exchange_diagnostic']],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
