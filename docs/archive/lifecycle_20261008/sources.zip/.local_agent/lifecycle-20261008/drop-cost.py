"""Profile one observed costly reference, not a frozen-result extension."""
import sys,json,time,hashlib,cProfile,pstats
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;old=p.parent/'semantic-candidate-20261008';out=p/'drop-cost.json';assert not out.exists()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='One new instrumented batch for previously unknown Core drop-history root: replay same exact route, profile Core depth2 with leaf8192/10sec fuse. Profiling overhead makes timings diagnostic, not speed comparison. Outcome decides whether terminal/legality duplication or scoring deserves work; preserve original unknown statuses. No new public-player resources/defaults.',rows=[])
write_record(out,r);source=json.loads((old/'event-history-qualified.json').read_bytes())
for case in source['cases']:
 if all(x['reference']['complete'] for x in case['rows']):continue
 c=compile_ruleset_for_execution(ruleset_from_dict(json.loads((old/case['source']).read_bytes())['source_definition']));s=GameSession(c)
 cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profile,scope=build_semantic_opportunity_profile(c,cfg);ev=Evaluator(c,profile,cfg)
 for row in case['rows']:
  if not row['reference']['complete']:
   pr=cProfile.Profile();counted=CountedEvaluator(ev,seconds=10,evaluations=8192);start=time.perf_counter();pr.enable()
   try:score,action=reference_minimax(s.state,2,counted,c);v=dict(reference_complete=True,score=score,action=record_value(action))
   except ReferenceLimit:v=dict(reference_complete=False,score=None)
   finally:pr.disable()
   stats=pstats.Stats(pr);v.update(ply=row['ply'],seconds=time.perf_counter()-start,leaf_evaluations=counted.calls,total_calls=stats.total_calls,primitive_calls=stats.prim_calls,functions=[])
   for (file,line,name),(primitive,calls,selftime,cumulative,callers) in sorted(stats.stats.items(),key=lambda x:-x[1][3])[:35]:
    v['functions'].append(dict(file=str(Path(file).relative_to(ROOT)) if str(file).startswith(str(ROOT)) else str(file),line=line,name=name,primitive_calls=primitive,calls=calls,self_seconds=selftime,cumulative_seconds=cumulative))
   r['rows'].append(v);write_record(out,r);print(v['reference_complete'],v['leaf_evaluations'],v['seconds']);print([(x['name'],round(x['cumulative_seconds'],3),x['calls']) for x in v['functions'][:15]],flush=True)
  matched=[a for a in s.legal_actions() if record_value(a)==case['transitions'][row['ply']]];assert len(matched)==1;s.submit(matched[0])
r['complete']=True;write_record(out,r)
