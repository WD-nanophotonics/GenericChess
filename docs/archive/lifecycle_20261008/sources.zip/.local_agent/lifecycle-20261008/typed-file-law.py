"""Fixed occupancy, varying base/current composition; conditional availability only."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands
from generic_chess.core.semantic_executor import iter_semantic_public_actions
from generic_chess.core.transition import initial_state
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,guarded_actions,public_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'typed-file-law.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='All512 masks: same9 occupied rank1 files, each ownP or baseP/currentTP; owner0, opposite-corner kings, onehandP. Full position-only legal sets Core/Native. Independent Bernoulli currentP probability a gives mean legal drops62*(1-a); no release policy, game utility or opening reachability. General rank1 empty/P/TP law with probabilities1-a-b/a/b gives E[Pdrop]=71*(1-a)-9*b, E[Gdrop]=79-9*(a+b), by linearity. No independence acrossfiles needed for these means if marginals equal. No price chosen.',rows=[],means=[])
write_record(out,r);c=compile_ruleset_for_execution(build_standard_shogi_ruleset());s=initial_state(c);provider=NativeSemanticLegalityProvider.try_create(c,strict=True);nr=provider.native_rules
for mask in range(512):
 board=[None]*81;board[0]=Piece(0,'K','K');board[80]=Piece(1,'K','K')
 for f in range(9):
  promoted=not bool(mask&(1<<f));board[9+f]=Piece(0,'P','TP' if promoted else 'P',promoted)
 pos=replace(s.position,board=tuple(board),hands=(Hands((('P',1),)),Hands.empty()),side_to_move=0)
 actions=list(iter_semantic_public_actions(provider.engine,pos));native={public_action(nr,a) for a in guarded_actions(nr,pack_position(nr,provider._state_only_payload(pos,0)))};assert set(actions)==native
 drops=[a for a in actions if 'from_square' not in record_value(a)];expected=sum((6 if f==0 else 7) for f in range(9) if not mask&(1<<f));assert len(drops)==expected
 r['rows'].append(dict(mask=mask,unpromoted_files=mask.bit_count(),drop_count=len(drops),expected=expected,native_equal=True))
 if mask%64==0:write_record(out,r);print(mask,flush=True)
for a in (Fraction(0),Fraction(1,4),Fraction(1,2),Fraction(3,4),Fraction(1)):
 mean=sum(a**row['unpromoted_files']*(1-a)**(9-row['unpromoted_files'])*row['drop_count'] for row in r['rows']);expected=62*(1-a);assert mean==expected
 r['means'].append(dict(unpromoted_probability=str(a),mean_drops=str(mean),expected=str(expected)))
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print(r['means'])
