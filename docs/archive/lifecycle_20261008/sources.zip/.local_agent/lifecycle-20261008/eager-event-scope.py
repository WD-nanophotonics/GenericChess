"""Matched eager transition cost and full-state parity on semantic events."""
import sys,time,json,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import rule_semantics_ir_fixtures as fixtures
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import legal_successors
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'eager-event-scope.json';assert not out.exists();start=time.perf_counter();oldraw=(p/'transition-before.py').read_bytes();ns=dict(__name__='generic_chess.core.transition',__package__='generic_chess.core');exec(compile(oldraw,'frozen_transition_before.py','exec'),ns);old=ns['legal_successors']
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),baseline_sha256=hashlib.sha256(oldraw).hexdigest(),candidate_sha256=hashlib.sha256((ROOT/'generic_chess/core/transition.py').read_bytes()).hexdigest(),declaration='Changed route premise: same five declared fixtures, now prioritize actual capture, then actual drop, then semantic action, then canonical. Four actual history roots each. No claim of drop coverage until observed hands/drop route records confirm it. Two alternating old/new eager calls perroot, exact full child GameState parity; independent full-history Native action/position/terminal replay on selected route. Cost is eager enumeration only, not public-search/strength. No new rules selected by result.',cases=[])
write_record(out,r)
for name in ('cannon','castling','en_passant','nifu','uchifuzume'):
 definition=getattr(fixtures,name+'_ruleset')();board=[list(x) for x in definition.initial_position]
 if name=='cannon':
  for owner,rank in ((0,1),(1,2),(1,4)):board[rank][2]=Piece(owner,'C','C')
 elif name=='en_passant':board[1][4]=Piece(0,'P','P');board[3][5]=Piece(1,'P','P')
 elif name in ('nifu','uchifuzume'):board[1][4]=Piece(0,'P','P');board[2][4]=Piece(1,'P','P')
 definition=replace(definition,initial_position=tuple(map(tuple,board)));c=compile_ruleset_for_execution(definition);s=GameSession(c);nr=compile_native_semantic_rules(c);m=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True)
 case=dict(fixture=name,definition=ruleset_to_dict(definition),rows=[],route=[]);r['cases'].append(case)
 for ply in range(4):
  if s.state.terminal_status.is_terminal:break
  assert snapshot_matches(m.snapshot(),s.state.position,nr,c);nt=terminal_status(nr,m.position);assert nt['status']==s.state.terminal_status.status.value and nt['winner']==s.state.terminal_status.winner
  expected=None;row=dict(ply=ply,history_length=len(s.state.history),hands=record_value(s.state.position.hands),calls=[]);case['rows'].append(row)
  for repeat,methods in enumerate((('old','new'),('new','old'))):
   for method in methods:
    before=time.perf_counter();pairs=(old if method=='old' else legal_successors)(s.state,c);elapsed=time.perf_counter()-before
    if expected is None:expected=pairs
    assert expected==pairs
    row['calls'].append(dict(method=method,repeat=repeat,seconds=elapsed,successors=len(pairs)))
  row['full_state_sha256']=hashlib.sha256(json.dumps(record_value(expected),sort_keys=True,separators=(',',':')).encode()).hexdigest()
  assert {a for a,ch in expected}=={public_action(nr,a) for a in guarded_actions(nr,m.position)}
  actions=[a for a,ch in expected]
  if not actions:break
  if name=='en_passant' and ply in (0,1):
   source,target=((4,1),(4,3)) if ply==0 else ((5,3),(4,2))
   candidates=[a for a in actions if (a.from_square.file,a.from_square.rank)==source and (a.to_square.file,a.to_square.rank)==target and a.pattern_id.startswith('sem_')]
  else:
   parent_count=sum(x is not None for x in s.state.position.board)
   candidates=[a for a,ch in expected if sum(x is not None for x in ch.position.board)<parent_count]
   if not candidates:candidates=[a for a in actions if hasattr(a,'base_type_id')]
   if not candidates:candidates=[a for a in actions if a.pattern_id.startswith('sem_')]
  if not candidates:candidates=actions
  a=sorted(candidates,key=lambda a:json.dumps(record_value(a),sort_keys=True))[0];m.push(a,s.state.position);s.submit(a);case['route'].append(record_value(a));write_record(out,r)
 print(name,[(x['ply'],x['calls'][0]['successors'],x['hands']) for x in case['rows']],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
