"""Real capture/promotion history releases a previously blocked hand pawn."""
import sys,time,json,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'release-delay-completed.json';assert not out.exists();start=time.perf_counter()
board=[[None]*9 for _ in range(9)];board[0][0]=Piece(0,'K','K');board[8][8]=Piece(1,'K','K');board[2][3]=Piece(0,'N','N');board[4][4]=Piece(1,'P','P')
for f in range(9):board[7 if f==4 else 1][f]=Piece(0,'P','P')
definition=replace(build_standard_shogi_ruleset(),initial_position=tuple(tuple(x) for x in board));c=compile_ruleset_for_execution(definition);s=GameSession(c);nr=compile_native_semantic_rules(c);mirror=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),definition=ruleset_to_dict(definition),declaration='Declared synthetic initial board, full standard Shogi rules and actual4ply history: N3,2 capturesP4,4; enemyK8,8 to7,7; ownP4,7 promotesTP4,8; enemyK7,7 to7,6. No virtual pass, external hand insertion, standard-opening reachability or universal price. Pawn hand obtained from real capture. Nifu blocks everyfile at ownturn ply2, promotion opensfile4 by ply4. Independent full-history Native transition, all legal action sets and terminal status. Not a minimum/optimal delay claim: selected real line exposes conditional delay only.',rows=[],actions=[])
write_record(out,r)
route=[((3,2),(4,4),None),((8,8),(7,7),None),((4,7),(4,8),'TP'),((7,7),(7,6),None)]
for ply in range(5):
 actions=s.legal_actions();nas=guarded_actions(nr,mirror.position);assert set(actions)=={public_action(nr,a) for a in nas}
 assert snapshot_matches(mirror.snapshot(),s.state.position,nr,c)
 nt=terminal_status(nr,mirror.position);ct=s.state.terminal_status;assert nt['status']==ct.status.value and nt['winner']==ct.winner
 drops=[a for a in actions if 'from_square' not in record_value(a)];r['rows'].append(dict(ply=ply,side=s.state.position.side_to_move,history_length=len(s.state.history),hands=record_value(s.state.position.hands),legal_actions=len(actions),drops=record_value(drops),terminal=record_value(ct),native_equal=True));write_record(out,r)
 if ply==4:break
 source,target,promotion=route[ply];matching=[a for a in actions if (a.from_square.file,a.from_square.rank)==source and (a.to_square.file,a.to_square.rank)==target and a.promotion_target_id==promotion];assert len(matching)==1
 action=matching[0];mirror.push(action,s.state.position);s.submit(action);r['actions'].append(record_value(action))
assert not r['rows'][2]['drops'];assert len(r['rows'][4]['drops'])==7
r['correction']='Initial expected8 forgot ownN occupying(4,4); exact original action list already has7. Full Core/Native execution was equal. Corrected membership count, no changed rule/route.'
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print([(x['ply'],x['side'],x['history_length'],len(x['drops'])) for x in r['rows']])
