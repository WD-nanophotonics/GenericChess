"""Finite root action spectra explaining two completed comparisons."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import legal_successors
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=p.parent/'semantic-candidate-20261008';out=p/'action-margins.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Two4x4 first-qualified roots already have completed depth3Core references. Enumerate each conditional root action with complete Core2ply continuation, no ordering or pruning. Same static hand0 profiles;20sec/16384leaf fuse shared across all actions perprofile perroot. Changed action-specific question, not unchanged root search. Terminal mate sentinel adjusted one root ply. Compare optimum sets, margins and maximum observed value changes; not causal price quality/strength. Any cap leaves spectrum unknown.',rows=[])
write_record(out,r);cfg=EvaluationConfig(hand_weight=0,dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for case in json.loads((p/'generated-discrimination-qualified.json').read_bytes())['cases'][:2]:
 root=next(x for x in case['rows'] if x['qualifies_exchange_diagnostic']);c=compile_ruleset_for_execution(ruleset_from_dict(json.loads((old/case['source']).read_bytes())['source_definition']));s=GameSession(c)
 for saved in case['transitions'][:root['ply']]:s.submit(next(a for a in s.legal_actions() if record_value(a)==saved))
 base=build_ruleset_profile(c,cfg);candidate,_=build_semantic_opportunity_profile(c,cfg);pairs=legal_successors(s.state,c)
 item=dict(source=case['source'],ply=root['ply'],profiles={},actions=[dict(action=record_value(a),values={}) for a,ch in pairs]);r['rows'].append(item)
 for label,profile in (('baseline',base),('candidate',candidate)):
  ev=Evaluator(c,profile,cfg);counted=CountedEvaluator(ev,seconds=20,evaluations=16384);before=time.perf_counter();complete=True
  for i,(a,child) in enumerate(pairs):
   try:score,_=reference_minimax(child,2,counted,c)
   except ReferenceLimit:complete=False;break
   own=-score
   if abs(own)>900000000:own=own-1 if own>0 else own+1
   item['actions'][i]['values'][label]=own
  item['profiles'][label]=dict(complete=complete,leaves=counted.calls,seconds=time.perf_counter()-before)
  if complete:
   values=[x['values'][label] for x in item['actions']];best=max(values);lower=[v for v in values if v<best]
   item['profiles'][label].update(best=best,optimal_actions=[x['action'] for x in item['actions'] if x['values'][label]==best],next_gap=best-max(lower) if lower else None,ties=sum(v==best for v in values))
  write_record(out,r)
 if all(v['complete'] for v in item['profiles'].values()):
  item['max_action_value_difference']=max(abs(x['values']['candidate']-x['values']['baseline']) for x in item['actions'])
  item['optimal_set_equal']=item['profiles']['baseline']['optimal_actions']==item['profiles']['candidate']['optimal_actions']
 print(case['source'],item['profiles'],item.get('optimal_set_equal'),flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
