"""Matched existing-player replay; no default prices or policy changes."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'public-continuation.json';assert not out.exists();start=time.perf_counter()
class TerminalOnly(Evaluator):
 def evaluate(self,state):return 0
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Same declared conditional after-capture roots, all legal replies and real history. Same public optimized bundle, depth2/node8192/time5sec/q0/root-tactical-off, cold repeats2. TerminalOnly, existing generic-v1 static, opt-in v1 static. No player-strength/true-price claim; scoring and ordering tables vary together, resource ceiling fixed. Exact terminal-only Core reference exists, static references not asserted.',rows=[])
write_record(out,r);cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
limits=SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0)
for name in ('capture-swing.json','capture-swing-knight.json'):
 for original in json.loads((p/name).read_bytes())['rows']:
  c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));s=GameSession(c)
  capture=[a for a in s.legal_actions() if record_value(a)==original['capture']];assert len(capture)==1;s.submit(capture[0])
  generic=build_ruleset_profile(c,cfg);candidate,scope=build_semantic_opportunity_profile(c,cfg)
  for label,ev in [('terminal_only',TerminalOnly(c,candidate,cfg)),('generic_static',Evaluator(c,generic,cfg)),('opportunity_static',Evaluator(c,candidate,cfg))]:
   row=dict(source=name,target=original['target'],evaluator=label,calls=[]);r['rows'].append(row)
   for repeat in range(2):
    player=AlphaBetaPlayer(c,evaluation_config=cfg,use_disk_cache=False,evaluator_override=ev,tuning=SearchTuning(use_root_tactical=False),tt_max_entries=4096)
    before=time.perf_counter();d=player.choose_action(s,limits);elapsed=time.perf_counter()-before;validate_pv(s,d)
    row['calls'].append(dict(repeat=repeat,seconds=elapsed,decision=record_value(d),complete=d.completed_depth==2,core_score_equal=(d.score==original['reference']['enemy_view_score']) if label=='terminal_only' and d.completed_depth==2 else None));write_record(out,r)
   row['repeat_equal']=all(row['calls'][0]['decision'][k]==row['calls'][1]['decision'][k] for k in ('score','action','completed_depth'))
   assert row['repeat_equal'];assert all(x['core_score_equal'] is not False for x in row['calls'])
   print(name,original['target'],label,[(x['decision']['score'],x['decision']['completed_depth'],x['decision']['nodes']) for x in row['calls']],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
