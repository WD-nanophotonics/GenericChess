"""Frozen old/new eager Core comparison in an isolated diagnostic process."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.core import transition
from generic_chess.ai.alphabeta import search
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;old=p.parent/'semantic-candidate-20261008';out=p/'drop-cost-comparison.json';assert not out.exists()
oldraw=(p/'transition-before.py').read_bytes();ns=dict(__name__='generic_chess.core.transition',__package__='generic_chess.core');exec(compile(oldraw,'frozen_transition_before.py','exec'),ns)
old_successors=ns['legal_successors'];new_successors=transition.legal_successors;original_search_successors=search.legal_successors
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),baseline_sha256=hashlib.sha256(oldraw).hexdigest(),candidate_sha256=hashlib.sha256((ROOT/'generic_chess/core/transition.py').read_bytes()).hexdigest(),declaration='Same exact previously unknown root/history/evaluator and Core depth2, leaf16384/20sec fuse, two alternating old/new repeats. New bounded development comparison explicitly grants same cap to both versions; preserve prior unknown results. Isolated diagnostic substitutes only search.legal_successors, restores finally. Full immediate successor GameState parity required before cost test; leafcounts/fullscore/action compare when complete. Not a resource-matched public-player speed claim.',rows=[])
write_record(out,r);source=json.loads((old/'event-history-qualified.json').read_bytes())
try:
 for case in source['cases']:
  if all(x['reference']['complete'] for x in case['rows']):continue
  c=compile_ruleset_for_execution(ruleset_from_dict(json.loads((old/case['source']).read_bytes())['source_definition']));s=GameSession(c)
  cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);prof,_=build_semantic_opportunity_profile(c,cfg);ev=Evaluator(c,prof,cfg)
  for row in case['rows']:
   if not row['reference']['complete']:
    before=old_successors(s.state,c);after=new_successors(s.state,c);assert before==after;r['immediate_full_state_parity']=len(after)
    for repeat,methods in enumerate((('old','new'),('new','old'))):
     for method in methods:
      search.legal_successors=old_successors if method=='old' else new_successors
      counted=CountedEvaluator(ev,seconds=20,evaluations=16384);start=time.perf_counter()
      try:score,action=search.reference_minimax(s.state,2,counted,c);v=dict(complete=True,score=score,action=record_value(action),public_equal=all(x['decision']['score']==score for x in row['calls']))
      except ReferenceLimit:v=dict(complete=False,score=None)
      v.update(method=method,repeat=repeat,seconds=time.perf_counter()-start,leaf_evaluations=counted.calls);r['rows'].append(v);write_record(out,r);print(v,flush=True)
   matched=[a for a in s.legal_actions() if record_value(a)==case['transitions'][row['ply']]];assert len(matched)==1;s.submit(matched[0])
finally:search.legal_successors=original_search_successors
complete=[x for x in r['rows'] if x['complete']];r['complete_equal']=len({(x['score'],json.dumps(x['action'],sort_keys=True),x['leaf_evaluations']) for x in complete})<=1
assert r['complete_equal'];r['complete']=True;write_record(out,r)
