"""Independent real-transition replay of the two declared Shogi controls."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.terminal import terminal_result
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,terminal_status,snapshot
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'native-frontier.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Independent Native real transitions, exact full root SHA256 history, no virtual pass. Preserve R negative control and changed N premise. Compare every legal action and terminal at the conditional frontier; record base reset and history. No average utility/true-price/strength claim.',source_pins={},rows=[])
write_record(out,r)
for name in ('capture-swing.json','capture-swing-knight.json'):
 raw=(p/name).read_bytes();r['source_pins'][name]=hashlib.sha256(raw).hexdigest()
 for original in json.loads(raw)['rows']:
  c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));s=GameSession(c);nr=compile_native_semantic_rules(c)
  mirror=NativeSemanticPositionMirror.from_state(c,nr,s.state,history_certified=True)
  capture=[a for a in s.legal_actions() if record_value(a)==original['capture']];assert len(capture)==1
  mirror.push(capture[0],s.state.position);s.submit(capture[0]);assert snapshot_matches(mirror.snapshot(),s.state.position,nr,c)
  row=dict(source=name,target=original['target'],capture=original['capture'],after_capture=record_value(mirror.snapshot()),frontiers=[]);r['rows'].append(row)
  replies=legal_actions(s.state,c);native_replies=guarded_actions(nr,mirror.position)
  assert set(replies)=={public_action(nr,a) for a in native_replies}
  for reply in replies:
   packed=mirror.direct_pack(reply,s.state.position);np=make_checked(nr,mirror.position,packed);child=apply_action(s.state,reply,c)
   assert snapshot_matches(snapshot(nr,np),child.position,nr,c)
   actions=legal_actions(child,c);nas=guarded_actions(nr,np);assert set(actions)=={public_action(nr,a) for a in nas}
   wins=[];checks=0
   for na in nas:
    action=public_action(nr,na);ns=make_checked(nr,np,na);cs=apply_action(child,action,c)
    assert snapshot_matches(snapshot(nr,ns),cs.position,nr,c)
    ct=terminal_result(cs,c);nt=terminal_status(nr,ns)
    assert nt['status']==ct.status.value and nt['winner']==ct.winner,(nt,ct)
    checks+=1
    if ct.is_terminal and ct.winner==0:wins.append(record_value(action))
   assert sorted(wins,key=str)==sorted(next(x['own_immediate_wins'] for x in original['enemy_replies'] if x['reply']==record_value(reply)),key=str)
   row['frontiers'].append(dict(reply=record_value(reply),legal_actions=len(actions),terminal_checks=checks,wins=wins))
  write_record(out,r);print(name,original['target'],[(x['legal_actions'],len(x['wins'])) for x in row['frontiers']],flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
