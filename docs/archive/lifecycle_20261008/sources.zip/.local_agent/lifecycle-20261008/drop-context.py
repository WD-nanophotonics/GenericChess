"""Actual legal-drop context, no game utility or synthetic history claims."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.position import Hands
from generic_chess.core.semantic_executor import iter_semantic_public_actions
from generic_chess.core.transition import initial_state
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import pack_position,guarded_actions,public_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'drop-context-completed.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='Standard full Shogi legality, synthetic position-only contexts. Own/enemy kings opposite corners; k=0..9 files occupied at relative rank1 by ownP or baseP/currentTP. Hand G/P, multiplicity1/2; both owners under180degree reflection. Core/Native all legal action sets, no terminal/history calls from position-only payload. Analytic drop counts: G79-k; P with unpromoted fillers k0:71, k>=1:8*(9-k); P with promoted fillers71-k. No standard-opening reachability, game value, release policy, timing or fitted correction. Existing static hand coefficients stay unchanged.',rows=[])
write_record(out,r);c=compile_ruleset_for_execution(build_standard_shogi_ruleset());state=initial_state(c);provider=NativeSemanticLegalityProvider.try_create(c,strict=True);nr=provider.native_rules;prof,_=build_semantic_opportunity_profile(c,EvaluationConfig());r['static_hand_values']=dict(prof.hand_value_by_base_type)
for owner in (0,1):
 for filler in ('P','TP'):
  for k in range(10):
   board=[None]*81
   def at(f,rank):return rank*9+f if owner==0 else (8-rank)*9+8-f
   board[at(0,0)]=Piece(owner,'K','K');board[at(8,8)]=Piece(1-owner,'K','K')
   for file in range(k):board[at(file,1)]=Piece(owner,'P',filler,filler=='TP')
   for hand in ('G','P'):
    signatures=[]
    for count in (1,2):
     hands=[Hands.empty(),Hands.empty()];hands[owner]=Hands(((hand,count),));pos=replace(state.position,board=tuple(board),hands=tuple(hands),side_to_move=owner)
     core=list(iter_semantic_public_actions(provider.engine,pos));np=pack_position(nr,provider._state_only_payload(pos,0));native={public_action(nr,a) for a in guarded_actions(nr,np)};assert set(core)==native
     drops=[a for a in core if 'from_square' not in record_value(a)];expected=79-k if hand=='G' else 71-k if filler=='TP' else 71 if k==0 else 8*(9-k)
     assert len(drops)==expected,(owner,filler,k,hand,count,len(drops),expected)
     signatures.append(set(drops));r['rows'].append(dict(owner=owner,filler=filler,files=k,hand=hand,count=count,legal_actions=len(core),drop_actions=len(drops),expected_drop_actions=expected,drop_actions_exact=record_value(drops),native_equal=True));write_record(out,r)
    assert signatures[0]==signatures[1]
 print('owner',owner,'complete',flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
