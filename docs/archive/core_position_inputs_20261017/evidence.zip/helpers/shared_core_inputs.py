from dataclasses import replace
from generic_chess.core.actions import action_target_square
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.learning.features import spatial_cell

def shared_core_inputs(position,compiled):
 engine=semantic_engine_for(compiled)
 if engine is None:raise TypeError('semanticPosition helperrequiressemanticengine')
 counts=[];cells=[[0]*9 for _ in range(2)];size=position.board_size()
 for owner in(0,1):
  view=replace(position,side_to_move=owner);actions=engine.legal_actions(view)
  promotions=sum(a.promotion_target_id is not None for a in actions)
  anchors=sum(a.source is not None and compiled.support.type_metadata[view.board[a.source].current_type_id].is_anchor for a in actions)
  counts.append((len(actions),promotions,anchors-10*int(engine.in_check(view,owner))))
  for action in actions:
   target=action.target if hasattr(action,'target')else action_target_square(action)
   index=target if isinstance(target,int)else target.rank*size+target.file
   cells[owner][spatial_cell(index,size)]+=1
 dynamic=tuple(a-b for a,b in zip(*counts));totals=[sum(v)for v in cells]
 control=tuple(9*(cells[0][i]-cells[1][i])-(totals[0]-totals[1])for i in range(9))
 return dynamic,control
