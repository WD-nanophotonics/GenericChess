"""Session-level results (resignation and declarations live here, not in Core)."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from ..core.terminal import TerminalResult, TerminalStatus


class SessionStatus(Enum):
    ONGOING = "ongoing"
    CHECKMATE = "checkmate"
    STALEMATE = "stalemate"
    REPETITION = "repetition"
    PERPETUAL_CHECK = "perpetual_check"
    MAX_PLY = "max_ply"
    NO_CONTEST = "no_contest"
    ACTION_CLASS_DRAW = "action_class_draw"
    NO_PROGRESS_DRAW = "no_progress_draw"
    RULE_LOSS = "rule_loss"
    RESIGNATION = "resignation"
    DECLARATION = "declaration"


@dataclass(frozen=True, slots=True)
class SessionResult:
    status: SessionStatus
    winner: int | None
    resigned_by: int | None = None
    declaration_id: str | None = None
    declared_by: int | None = None
    declaration_outcome: str | None = None
    declaration_score: int | None = None

    def __str__(self) -> str:
        if self.status is SessionStatus.ONGOING:
            return "ongoing"
        if self.status is SessionStatus.RESIGNATION:
            return f"resignation, player {self.winner} wins (player {self.resigned_by} resigned)"
        if self.status is SessionStatus.DECLARATION:
            if self.declaration_outcome == "RESTART":
                return (
                    f"declaration {self.declaration_id}, player {self.declared_by} "
                    "RESTART/no-contest"
                )
            return (
                f"declaration {self.declaration_id}, player {self.declared_by} "
                f"{self.declaration_outcome}, player {self.winner} wins"
            )
        if self.status is SessionStatus.CHECKMATE:
            return f"checkmate, player {self.winner} wins"
        if self.status is SessionStatus.STALEMATE and self.winner is not None:
            return f"stalemate, player {self.winner} wins"
        if self.status is SessionStatus.PERPETUAL_CHECK:
            loser = 1 - self.winner if self.winner is not None else None
            return f"perpetual check, player {self.winner} wins (player {loser} loses)"
        if self.status is SessionStatus.RULE_LOSS:
            loser = 1 - self.winner if self.winner is not None else None
            return f"rule loss, player {loser} loses, player {self.winner} wins"
        if self.status is SessionStatus.NO_CONTEST:
            return "no-contest/restart"
        return f"{self.status.value}, draw"


def _session_status_from_terminal(terminal: TerminalResult) -> SessionStatus:
    mapping = {
        TerminalStatus.ONGOING: SessionStatus.ONGOING,
        TerminalStatus.CHECKMATE: SessionStatus.CHECKMATE,
        TerminalStatus.STALEMATE: SessionStatus.STALEMATE,
        TerminalStatus.REPETITION: SessionStatus.REPETITION,
        TerminalStatus.PERPETUAL_CHECK: SessionStatus.PERPETUAL_CHECK,
        TerminalStatus.MAX_PLY: SessionStatus.MAX_PLY,
        TerminalStatus.NO_CONTEST: SessionStatus.NO_CONTEST,
        TerminalStatus.ACTION_CLASS_DRAW: SessionStatus.ACTION_CLASS_DRAW,
        TerminalStatus.NO_PROGRESS_DRAW: SessionStatus.NO_PROGRESS_DRAW,
        TerminalStatus.RULE_LOSS: SessionStatus.RULE_LOSS,
    }
    return mapping[terminal.status]


def session_result_from_terminal(terminal: TerminalResult) -> SessionResult:
    """Map a Core TerminalResult to a SessionResult (no resignation)."""
    return SessionResult(
        status=_session_status_from_terminal(terminal),
        winner=terminal.winner,
        resigned_by=None,
    )
