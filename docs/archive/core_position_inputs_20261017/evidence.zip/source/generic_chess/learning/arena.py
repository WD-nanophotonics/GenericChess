"""Integrity-preserving paired arena.

Measurement rules:
* every game replays one corpus opening (identical within a pair);
* every game creates **fresh** parent and child engines (TT never crosses
  games);
* engine failures are raised, never counted as draws;
* the primary statistic is the paired score with a pair-level bootstrap CI.
"""

from __future__ import annotations

from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, as_completed, wait
from dataclasses import asdict, dataclass
import json
import math
import os
from pathlib import Path
import re
import time

from ..ai.evaluation.config import EvaluationConfig
from ..ai.limits import SearchLimits
from ..core.actions import Action, action_from_dict, action_to_dict
from ..core.identity import position_identity_key
from ..native.compiler import GC_SEM_MAX_PLY, compile_native_evaluation
from ..native.engine import NativeSearchEngine
from ..native.semantic_engine import SemanticSearchEngine
from ..session.session import GameSession
from .material import LearnableMaterialCheckpoint
from .openings import ArenaOpeningCorpus, generate_arena_openings
from .serialization import stable_sha256
from .statistics import bootstrap_pair_mean_ci


class ArenaExecutionError(RuntimeError):
    """Raised when the arena cannot produce a valid measurement."""


class ArenaCapHit(ArenaExecutionError):
    """A hard execution cap stopped a stage before a valid game completed."""

    def __init__(self, cap: str) -> None:
        self.cap = cap
        super().__init__(f"arena execution cap hit: {cap}")


ARENA_PROGRESS_SCHEMA = "generic-chess-arena-progress-v1"
ARENA_GAME_PROGRESS_SCHEMA = "generic-chess-arena-game-progress-v1"
ARENA_PARTIAL_GAME_PROGRESS_SCHEMA = "generic-chess-arena-partial-game-progress-v1"


def _trusted_search_elapsed(native_elapsed: float, wall_elapsed: float):
    credible = (
        native_elapsed > 0.0
        and native_elapsed <= max(wall_elapsed * 2.0, wall_elapsed + 1.0)
    )
    return (
        (native_elapsed, "native")
        if credible else (wall_elapsed, "wall_fallback")
    )


@dataclass(frozen=True, slots=True)
class ArenaConfig:
    pairs: int = 10
    nodes_per_move: int = 5000
    max_depth: int = 12
    tt_megabytes: int = 8
    opening_seed: int = 314159
    opening_count: int = 0  # 0 -> use pairs
    min_plies: int = 2
    max_plies: int = 6
    workers: int = 1
    parent_nodes_per_move: int | None = None
    child_nodes_per_move: int | None = None
    tt_reset_each_move: bool = False
    move_time_seconds: float | None = None
    ordering_max_ply: int = -1
    ordering_min_depth: int = 1
    root_window_pruning: bool = False

    def __post_init__(self) -> None:
        if self.pairs <= 0 or self.nodes_per_move <= 0 or self.max_depth <= 0:
            raise ValueError("arena budgets must be positive")
        if self.workers <= 0:
            raise ValueError("arena workers must be positive")
        for role, budget in (
            ("parent", self.parent_nodes_per_move),
            ("child", self.child_nodes_per_move),
        ):
            if budget is not None and budget <= 0:
                raise ValueError(f"{role} nodes_per_move must be positive")
        if self.move_time_seconds is not None and not (
            self.move_time_seconds > 0.0 and math.isfinite(self.move_time_seconds)
        ):
            raise ValueError("move_time_seconds must be a finite positive value")
        if (
            isinstance(self.ordering_max_ply, bool)
            or not isinstance(self.ordering_max_ply, int)
            or not -1 <= self.ordering_max_ply <= GC_SEM_MAX_PLY
        ):
            raise ValueError("ordering_max_ply must be -1 or within GC_SEM_MAX_PLY")
        if (
            isinstance(self.ordering_min_depth, bool)
            or not isinstance(self.ordering_min_depth, int)
            or not 1 <= self.ordering_min_depth <= GC_SEM_MAX_PLY
        ):
            raise ValueError("ordering_min_depth must be within GC_SEM_MAX_PLY")
        if not isinstance(self.root_window_pruning, bool):
            raise TypeError("root_window_pruning must be a bool")


@dataclass(frozen=True, slots=True)
class ArenaExecutionCaps:
    """Hard bounds for one game and one resumable arena stage.

    ``workers`` remains the caller's requested concurrency.  The game-level
    runner applies the stricter lane cap exposed by :meth:`game_lanes`; no
    pair-level worker can create a nested executor.
    """

    per_game_wall_seconds: float | None = None
    per_game_nodes: int | None = None
    per_game_plies: int | None = None
    max_stage_games: int | None = None
    max_concurrent_games: int | None = None
    stage_wall_seconds: float | None = None
    logical_cpu_count: int = os.cpu_count() or 1

    def __post_init__(self) -> None:
        if self.logical_cpu_count <= 0:
            raise ValueError("logical_cpu_count must be positive")
        for name in (
            "per_game_wall_seconds", "per_game_nodes", "per_game_plies",
            "max_stage_games", "max_concurrent_games", "stage_wall_seconds",
        ):
            value = getattr(self, name)
            if value is not None and value <= 0:
                raise ValueError(f"{name} must be positive when provided")

    def game_lanes(self, requested_pairs: int, requested_workers: int) -> int:
        if requested_pairs <= 0 or requested_workers <= 0:
            raise ValueError("arena pair and worker counts must be positive")
        lanes = min(self.logical_cpu_count, 2 * requested_pairs, 16)
        lanes = min(lanes, requested_workers)
        if self.max_concurrent_games is not None:
            lanes = min(lanes, self.max_concurrent_games)
        return max(1, lanes)

    @property
    def has_per_game_caps(self) -> bool:
        return any(
            value is not None for value in (
                self.per_game_wall_seconds,
                self.per_game_nodes,
                self.per_game_plies,
            )
        )


# Short aliases keep the protocol convenient for callers without creating a
# second schema or a second implementation.
ArenaCaps = ArenaExecutionCaps


@dataclass(frozen=True, slots=True)
class ArenaGameResult:
    pair: int
    opening_id: str
    opening_position_key: str
    child_owner: int
    winner: int | None
    result: str
    plies: int
    actions: tuple[Action, ...]
    final_position_key: str
    declaration_id: str | None = None
    search_metrics: tuple[dict, ...] = ()

    @property
    def is_scoring_result(self) -> bool:
        """Whether this terminal result is admissible for strength scoring.

        ``no_contest`` is an explicit restart/no-contest outcome, not a draw.
        Keeping it out of the score path prevents a restart from silently
        becoming half a point.
        """
        return self.result != "no_contest"

    @property
    def child_points(self) -> float | None:
        if not self.is_scoring_result:
            return None
        if self.winner is None:
            return 0.5
        return 1.0 if self.winner == self.child_owner else 0.0


@dataclass(frozen=True, slots=True)
class ArenaPairResult:
    pair_index: int
    opening_id: str
    game_child_owner0: ArenaGameResult
    game_child_owner1: ArenaGameResult

    @property
    def child_pair_score(self) -> float | None:
        if not (
            self.game_child_owner0.is_scoring_result
            and self.game_child_owner1.is_scoring_result
        ):
            return None
        return (
            self.game_child_owner0.child_points
            + self.game_child_owner1.child_points
        ) / 2.0

    @property
    def is_scoring_pair(self) -> bool:
        return self.child_pair_score is not None


@dataclass(frozen=True, slots=True)
class ArenaSummary:
    pair_count: int
    pair_scores: tuple[float, ...]
    mean_pair_score: float
    child_better_pairs: int
    tied_pairs: int
    child_worse_pairs: int
    bootstrap_low: float
    bootstrap_high: float
    # Descriptive game-level aggregates.
    game_wins: int
    game_draws: int
    game_losses: int
    game_score_rate: float
    pairs: tuple[ArenaPairResult, ...]


def _engine_for(
    compiled, native_rules, checkpoint, tt_mb, *, ordering_checkpoint=None,
    ordering_max_ply=-1, ordering_min_depth=1, policy=None,
    policy_deferred_legality=False,
):
    from ..rules.ir import CompiledSemanticRuleset

    if isinstance(compiled, CompiledSemanticRuleset):
        return SemanticSearchEngine(
            compiled, native_rules, checkpoint=checkpoint,
            ordering_checkpoint=ordering_checkpoint,
            ordering_max_ply=ordering_max_ply,
            ordering_min_depth=ordering_min_depth,
            policy=policy,
            policy_deferred_legality=policy_deferred_legality,
            tt_megabytes=tt_mb,
        )
    if ordering_checkpoint is not None:
        raise ValueError("learned move ordering requires a semantic ruleset")
    eval_tables = compile_native_evaluation(
        native_rules,
        _dummy_profile(compiled, checkpoint),
        EvaluationConfig(),
        material_override=checkpoint,
    )
    return NativeSearchEngine(compiled, native_rules, eval_tables, tt_mb)


def _dummy_profile(compiled, checkpoint):
    from types import SimpleNamespace

    return SimpleNamespace(
        ruleset_fingerprint=compiled.ruleset_fingerprint,
        promotion_gain_by_type={pt.type_id: 0 for pt in compiled.piece_types},
        evaluator_version=checkpoint.evaluator_version,
    )


def _play_one_game(
    compiled,
    native_rules,
    parent,
    child,
    *,
    opening,
    child_owner: int,
    config: ArenaConfig,
    capture_search_metrics: bool = False,
    execution_caps: ArenaExecutionCaps | None = None,
    stage_deadline: float | None = None,
    partial_path: str | Path | None = None,
    partial_identity_sha256: str | None = None,
    partial_game_identity: dict | None = None,
    resume_partial: dict | None = None,
    root_order_hint_provider=None,
    ordering_checkpoint=None,
    policy=None,
    policy_deferred_legality=False,
) -> ArenaGameResult:
    """Replay ``opening``, then play one game with fresh engines.

    A cap can leave a validated, atomic in-game prefix when ``partial_path``
    is provided.  The next invocation replays that prefix and continues the
    same role-swapped game instead of restarting from the opening.
    """
    session = GameSession(compiled)
    for action in opening.actions:
        session.submit(action)
    opening_key = position_identity_key(session.state.position, compiled)
    parent_engine = None if config.tt_reset_each_move else _engine_for(
        compiled, native_rules, parent, config.tt_megabytes,
        ordering_max_ply=config.ordering_max_ply,
        ordering_min_depth=config.ordering_min_depth,
    )
    child_engine = None if config.tt_reset_each_move else _engine_for(
        compiled, native_rules, child, config.tt_megabytes,
        ordering_checkpoint=ordering_checkpoint,
        ordering_max_ply=config.ordering_max_ply,
        ordering_min_depth=config.ordering_min_depth,
        policy=policy,
        policy_deferred_legality=policy_deferred_legality,
    )
    actions: list[Action] = []
    plies = 0
    searched_nodes = 0
    if resume_partial is not None:
        if resume_partial.get("opening_id") != opening.final_position_key:
            raise ArenaExecutionError("arena partial opening identity does not match")
        for action in resume_partial["actions"]:
            if action not in session.legal_actions():
                raise ArenaExecutionError("arena partial game contains an illegal action")
            session.submit(action)
            actions.append(action)
        plies = len(actions)
        searched_nodes = int(resume_partial["searched_nodes"])
    game_started = time.perf_counter()
    declaration_id = None
    search_metrics = list(resume_partial["search_metrics"]) if resume_partial else []

    def cap_hit(cap: str):
        if partial_path is not None:
            if partial_identity_sha256 is None or partial_game_identity is None:
                raise ArenaExecutionError("partial progress identity is not bound")
            _atomic_write_json(
                Path(partial_path),
                _partial_game_progress_to_dict(
                    identity_sha256=partial_identity_sha256,
                    game_identity=partial_game_identity,
                    pair=opening.index,
                    child_owner=child_owner,
                    opening_id=opening.final_position_key,
                    actions=actions,
                    search_metrics=search_metrics,
                    searched_nodes=searched_nodes,
                ),
            )
        raise ArenaCapHit(cap)
    while session.result.status.value == "ongoing":
        if execution_caps is not None:
            if (
                execution_caps.per_game_wall_seconds is not None
                and time.perf_counter() - game_started
                >= execution_caps.per_game_wall_seconds
            ):
                cap_hit("per_game_wall_seconds")
            if (
                execution_caps.per_game_plies is not None
                and plies >= execution_caps.per_game_plies
            ):
                cap_hit("per_game_plies")
        legal = session.legal_actions()
        if not legal:
            raise ArenaExecutionError(
                "Core reports no legal moves but the session is ongoing"
            )
        side = session.state.position.side_to_move
        if config.tt_reset_each_move:
            parent_engine = _engine_for(
                compiled, native_rules, parent, config.tt_megabytes,
                ordering_max_ply=config.ordering_max_ply,
                ordering_min_depth=config.ordering_min_depth,
            )
            child_engine = _engine_for(
                compiled, native_rules, child, config.tt_megabytes,
                ordering_checkpoint=ordering_checkpoint,
                ordering_max_ply=config.ordering_max_ply,
                ordering_min_depth=config.ordering_min_depth,
                policy=policy,
                policy_deferred_legality=policy_deferred_legality,
            )
        engine = child_engine if side == child_owner else parent_engine
        role = "child" if side == child_owner else "parent"
        nodes_per_move = (
            config.child_nodes_per_move if role == "child"
            else config.parent_nodes_per_move
        ) or config.nodes_per_move
        if execution_caps is not None and execution_caps.per_game_nodes is not None:
            remaining_nodes = execution_caps.per_game_nodes - searched_nodes
            if remaining_nodes <= 0:
                cap_hit("per_game_nodes")
            nodes_per_move = min(nodes_per_move, remaining_nodes)
        remaining_wall = []
        if execution_caps is not None and execution_caps.per_game_wall_seconds is not None:
            remaining_wall.append((
                execution_caps.per_game_wall_seconds
                - (time.perf_counter() - game_started),
                "per_game_wall_seconds",
            ))
        if stage_deadline is not None:
            remaining_wall.append((
                stage_deadline - time.perf_counter(),
                "stage_wall_seconds",
            ))
        wall_limit = None
        wall_limit_name = None
        if remaining_wall:
            wall_limit, wall_limit_name = min(remaining_wall, key=lambda item: item[0])
            if wall_limit <= 0:
                cap_hit(wall_limit_name)
        wall_started = time.perf_counter()
        root_order_hint = None
        root_hint_policy = None
        if root_order_hint_provider is not None and side == child_owner:
            provided = root_order_hint_provider(session, legal)
            if not isinstance(provided, tuple) or len(provided) != 2:
                raise ArenaExecutionError(
                    "root_order_hint_provider must return (action, telemetry)"
                )
            root_order_hint, root_hint_policy = provided
            if root_order_hint not in legal:
                raise ArenaExecutionError("root_order_hint_provider returned an illegal action")
        search_kwargs = {}
        if root_order_hint_provider is not None or config.root_window_pruning:
            search_kwargs = {
                "root_order_hint": root_order_hint,
                "root_window_pruning": config.root_window_pruning,
            }
        timed_search = config.move_time_seconds is not None
        search_time_limit = (
            config.move_time_seconds if timed_search else wall_limit
        )
        result = engine.search(
            session,
            SearchLimits(
                max_depth=config.max_depth,
                max_nodes=nodes_per_move,
                max_time_seconds=search_time_limit,
                quiescence_max_depth=0,
            ),
            **search_kwargs,
        )
        wall_elapsed = time.perf_counter() - wall_started
        if (
            execution_caps is not None
            and execution_caps.per_game_wall_seconds is not None
            and time.perf_counter() - game_started
            >= execution_caps.per_game_wall_seconds
        ):
            cap_hit("per_game_wall_seconds")
        if stage_deadline is not None and time.perf_counter() >= stage_deadline:
            cap_hit("stage_wall_seconds")
        termination_reason = str(getattr(result, "termination_reason", "")).lower()
        if (
            timed_search and termination_reason == "time_budget"
        ):
            pass
        elif termination_reason in {
            "time_budget", "time_limit", "timeout", "deadline", "cancelled", "canceled",
        } or "deadline" in termination_reason:
            cap_hit(wall_limit_name or "per_game_wall_seconds")
        searched_nodes += int(getattr(result, "nodes", 0))
        searched_nodes += int(getattr(result, "qnodes", 0))
        if (
            execution_caps is not None
            and execution_caps.per_game_nodes is not None
            and searched_nodes > execution_caps.per_game_nodes
        ):
            cap_hit("per_game_nodes")
        if capture_search_metrics:
            native_elapsed = float(result.elapsed_seconds)
            elapsed, elapsed_source = _trusted_search_elapsed(
                native_elapsed, wall_elapsed
            )
            search_metrics.append({
                "side_to_move": side,
                "engine_role": role,
                "nodes_budget": nodes_per_move,
                "score": int(result.score),
                "nodes": int(result.nodes),
                "elapsed_seconds": elapsed,
                "elapsed_source": elapsed_source,
                "search_wall_seconds": wall_elapsed,
                "timing_mode": (
                    "per_move_search_time" if timed_search
                    else "unbounded_or_execution_cap"
                ),
                "requested_time_seconds": config.move_time_seconds,
                "time_budget_termination": bool(
                    timed_search and termination_reason == "time_budget"
                ),
                "wall_budget_overshoot_seconds": (
                    max(0.0, wall_elapsed - config.move_time_seconds)
                    if timed_search else 0.0
                ),
                "hard_execution_cap": wall_limit_name,
                "nps": (float(result.nodes) / elapsed if elapsed > 0.0 else None),
                "completed_depth": int(result.completed_depth),
                "selective_depth": int(result.selective_depth),
                "termination_reason": str(result.termination_reason),
                "used_fallback": bool(result.used_fallback),
                "root_window_pruning": bool(
                    getattr(result, "root_window_pruning", False)
                ),
                "decision_kind": (
                    "declaration"
                    if getattr(result, "declaration_id", None) is not None
                    else "action"
                ),
                "root_hint_requested_action_key": (
                    None if getattr(result, "root_hint_requested", None) is None
                    else json.dumps(action_to_dict(getattr(result, "root_hint_requested")), sort_keys=True, separators=(",", ":"))
                ),
                "root_hint_legal": bool(getattr(result, "root_hint_legal", False)),
                "root_hint_apply_count": int(getattr(result, "root_hint_apply_count", 0)),
                "root_iterations_attempted": int(getattr(result, "root_iterations_attempted", 0)),
                "root_iteration_first_action_keys": [
                    None if action is None else json.dumps(
                        action_to_dict(action), sort_keys=True, separators=(",", ":")
                    )
                    for action in getattr(result, "root_iteration_first_actions", ())
                ],
                "learned_move_ordering": bool(
                    getattr(result, "learned_move_ordering", False)
                ),
                "ordering_checkpoint_id": getattr(
                    result, "ordering_checkpoint_id", None
                ),
                "ordering_evaluations": int(
                    getattr(result, "ordering_evaluations", 0)
                ),
                "ordering_nodes": int(getattr(result, "ordering_nodes", 0)),
                "ordering_actions": int(getattr(result, "ordering_actions", 0)),
                "ordering_elapsed_seconds": float(
                    getattr(result, "ordering_elapsed_seconds", 0.0)
                ),
                "ordering_cache_hits": int(
                    getattr(result, "ordering_cache_hits", 0)
                ),
                "ordering_cache_misses": int(
                    getattr(result, "ordering_cache_misses", 0)
                ),
                "ordering_cache_collisions": int(
                    getattr(result, "ordering_cache_collisions", 0)
                ),
                "ordering_cache_hit_rate": float(
                    getattr(result, "ordering_cache_hit_rate", 0.0)
                ),
                "ordering_cache_capacity": int(
                    getattr(result, "ordering_cache_capacity", 0)
                ),
                "ordering_cache_entry_bytes": int(
                    getattr(result, "ordering_cache_entry_bytes", 0)
                ),
                "ordering_max_ply": int(getattr(result, "ordering_max_ply", -1)),
                "ordering_min_depth": int(getattr(result, "ordering_min_depth", 1)),
                "ordering_evaluations_by_ply": [
                    int(value) for value in getattr(
                        result, "ordering_evaluations_by_ply", ()
                    )
                ],
                "ordering_nodes_by_ply": [
                    int(value) for value in getattr(result, "ordering_nodes_by_ply", ())
                ],
                "ordering_actions_by_ply": [
                    int(value) for value in getattr(result, "ordering_actions_by_ply", ())
                ],
                "ordering_elapsed_nanoseconds_by_ply": [
                    int(value) for value in getattr(
                        result, "ordering_elapsed_nanoseconds_by_ply", ()
                    )
                ],
                "ordering_cache_hits_by_ply": [
                    int(value) for value in getattr(
                        result, "ordering_cache_hits_by_ply", ()
                    )
                ],
                "ordering_cache_misses_by_ply": [
                    int(value) for value in getattr(
                        result, "ordering_cache_misses_by_ply", ()
                    )
                ],
                "ordering_cache_collisions_by_ply": [
                    int(value) for value in getattr(
                        result, "ordering_cache_collisions_by_ply", ()
                    )
                ],
                "ordering_skipped_by_remaining_depth": [
                    int(value) for value in getattr(
                        result, "ordering_skipped_by_remaining_depth", ()
                    )
                ],
                "policy_deferred_legality": bool(
                    getattr(result, "policy_deferred_legality", False)
                ),
                "policy_nodes": int(getattr(result, "policy_nodes", 0)),
                "policy_state_inferences": int(
                    getattr(result, "policy_state_inferences", 0)
                ),
                "policy_actions_scored": int(
                    getattr(result, "policy_actions_scored", 0)
                ),
                "policy_action_embeddings": int(
                    getattr(result, "policy_action_embeddings", 0)
                ),
                "policy_elapsed_seconds": float(
                    getattr(result, "policy_elapsed_seconds", 0.0)
                ),
                "policy_preorder_checked_transitions": int(
                    getattr(result, "policy_preorder_checked_transitions", 0)
                ),
                "policy_traversal_checked_attempts": int(
                    getattr(result, "policy_traversal_checked_attempts", 0)
                ),
                "policy_traversal_illegal_skips": int(
                    getattr(result, "policy_traversal_illegal_skips", 0)
                ),
            })
            if root_hint_policy is not None:
                search_metrics[-1]["root_hint_policy"] = dict(root_hint_policy)
        if getattr(result, "declaration_id", None) is not None:
            declaration_id = result.declaration_id
            session.declare(declaration_id)
            break
        if result.action is None:
            raise ArenaExecutionError(
                "engine returned no action on an ongoing position "
                f"(termination_reason={result.termination_reason})"
            )
        session.submit(result.action)
        actions.append(result.action)
        plies += 1
    return ArenaGameResult(
        pair=opening.index,
        opening_id=opening.final_position_key,
        opening_position_key=opening_key,
        child_owner=child_owner,
        winner=session.result.winner,
        result=session.result.status.value,
        plies=plies,
        actions=tuple(actions),
        final_position_key=position_identity_key(session.state.position, compiled),
        declaration_id=declaration_id,
        search_metrics=tuple(search_metrics),
    )


def _prepare_arena(
    compiled,
    parent: LearnableMaterialCheckpoint,
    child: LearnableMaterialCheckpoint,
    config: ArenaConfig,
    openings: ArenaOpeningCorpus | None = None,
) -> ArenaOpeningCorpus:
    parent.validate_ruleset(compiled)
    child.validate_ruleset(compiled)
    if openings is None:
        openings = generate_arena_openings(
            compiled,
            count=config.opening_count or config.pairs,
            seed=config.opening_seed,
            min_plies=config.min_plies,
            max_plies=config.max_plies,
        )
    openings.validate(compiled)
    if len(openings.openings) < config.pairs:
        raise ValueError(
            f"opening corpus has {len(openings.openings)} openings but "
            f"{config.pairs} pairs requested"
        )
    return openings


def _play_pair(
    compiled,
    native_rules,
    parent: LearnableMaterialCheckpoint,
    child: LearnableMaterialCheckpoint,
    config: ArenaConfig,
    openings: ArenaOpeningCorpus,
    pair_index: int,
    *,
    capture_search_metrics: bool = False,
    root_order_hint_provider=None,
    policy=None,
    policy_deferred_legality=False,
    execution_caps: ArenaExecutionCaps | None = None,
) -> ArenaPairResult:
    opening = openings.openings[pair_index]
    game_child_owner0 = _play_one_game(
        compiled, native_rules, parent, child,
        opening=opening, child_owner=0, config=config,
        capture_search_metrics=capture_search_metrics,
        root_order_hint_provider=root_order_hint_provider,
        policy=policy,
        policy_deferred_legality=policy_deferred_legality,
        execution_caps=execution_caps,
    )
    game_child_owner1 = _play_one_game(
        compiled, native_rules, parent, child,
        opening=opening, child_owner=1, config=config,
        capture_search_metrics=capture_search_metrics,
        root_order_hint_provider=root_order_hint_provider,
        policy=policy,
        policy_deferred_legality=policy_deferred_legality,
        execution_caps=execution_caps,
    )
    return ArenaPairResult(
        pair_index=pair_index,
        opening_id=opening.final_position_key,
        game_child_owner0=game_child_owner0,
        game_child_owner1=game_child_owner1,
    )


def _summarize_pairs(pairs: list[ArenaPairResult]) -> ArenaSummary:
    pairs.sort(key=lambda pair: pair.pair_index)
    scoring_pairs = [pair for pair in pairs if pair.is_scoring_pair]
    game_wins = game_draws = game_losses = 0
    for pair in scoring_pairs:
        game_child_owner0 = pair.game_child_owner0
        game_child_owner1 = pair.game_child_owner1
        game_wins += sum(
            1 for g in (game_child_owner0, game_child_owner1) if g.child_points == 1.0
        )
        game_draws += sum(
            1 for g in (game_child_owner0, game_child_owner1) if g.child_points == 0.5
        )
        game_losses += sum(
            1 for g in (game_child_owner0, game_child_owner1) if g.child_points == 0.0
        )

    pair_scores = tuple(p.child_pair_score for p in scoring_pairs)
    mean = sum(pair_scores) / len(pair_scores) if pair_scores else 0.0
    better = sum(1 for s in pair_scores if s > 0.5)
    tied = sum(1 for s in pair_scores if s == 0.5)
    worse = sum(1 for s in pair_scores if s < 0.5)
    low, high = (
        bootstrap_pair_mean_ci(list(pair_scores))
        if pair_scores else (0.0, 0.0)
    )
    total_games = game_wins + game_draws + game_losses
    return ArenaSummary(
        pair_count=len(scoring_pairs),
        pair_scores=pair_scores,
        mean_pair_score=mean,
        child_better_pairs=better,
        tied_pairs=tied,
        child_worse_pairs=worse,
        bootstrap_low=low,
        bootstrap_high=high,
        game_wins=game_wins,
        game_draws=game_draws,
        game_losses=game_losses,
        game_score_rate=(
            (game_wins + 0.5 * game_draws) / total_games if total_games else 0.0
        ),
        pairs=tuple(scoring_pairs),
    )


def _game_to_dict(game: ArenaGameResult) -> dict:
    payload = {
        "pair": game.pair,
        "opening_id": game.opening_id,
        "opening_position_key": game.opening_position_key,
        "child_owner": game.child_owner,
        "winner": game.winner,
        "result": game.result,
        "plies": game.plies,
        "actions": [action_to_dict(action) for action in game.actions],
        "final_position_key": game.final_position_key,
        "declaration_id": game.declaration_id,
    }
    if game.search_metrics:
        payload["search_metrics"] = list(game.search_metrics)
    return payload


def _game_from_dict(data: dict) -> ArenaGameResult:
    required = {
        "pair", "opening_id", "opening_position_key", "child_owner", "winner",
        "result", "plies", "actions", "final_position_key", "declaration_id",
    }
    if set(data) not in (required, required | {"search_metrics"}):
        raise ValueError("arena game fields do not match the progress schema")
    winner = data["winner"]
    if winner not in (None, 0, 1) or data["child_owner"] not in (0, 1):
        raise ValueError("arena game owner/winner is invalid")
    return ArenaGameResult(
        pair=int(data["pair"]),
        opening_id=str(data["opening_id"]),
        opening_position_key=str(data["opening_position_key"]),
        child_owner=int(data["child_owner"]),
        winner=winner,
        result=str(data["result"]),
        plies=int(data["plies"]),
        actions=tuple(action_from_dict(action) for action in data["actions"]),
        final_position_key=str(data["final_position_key"]),
        declaration_id=(
            None if data["declaration_id"] is None else str(data["declaration_id"])
        ),
        search_metrics=tuple(dict(row) for row in data.get("search_metrics", ())),
    )


def _pair_to_dict(pair: ArenaPairResult, identity_sha256: str) -> dict:
    return {
        "schema": ARENA_PROGRESS_SCHEMA,
        "identity_sha256": identity_sha256,
        "pair_index": pair.pair_index,
        "opening_id": pair.opening_id,
        "game_child_owner0": _game_to_dict(pair.game_child_owner0),
        "game_child_owner1": _game_to_dict(pair.game_child_owner1),
    }


def _pair_from_dict(data: dict, *, identity_sha256: str) -> ArenaPairResult:
    required = {
        "schema", "identity_sha256", "pair_index", "opening_id",
        "game_child_owner0", "game_child_owner1",
    }
    if set(data) != required or data.get("schema") != ARENA_PROGRESS_SCHEMA:
        raise ValueError("arena pair fields do not match the progress schema")
    if data.get("identity_sha256") != identity_sha256:
        raise ValueError("arena pair identity does not match the manifest")
    pair = ArenaPairResult(
        pair_index=int(data["pair_index"]),
        opening_id=str(data["opening_id"]),
        game_child_owner0=_game_from_dict(data["game_child_owner0"]),
        game_child_owner1=_game_from_dict(data["game_child_owner1"]),
    )
    if (
        pair.game_child_owner0.child_owner != 0
        or pair.game_child_owner1.child_owner != 1
        or pair.game_child_owner0.opening_id != pair.opening_id
        or pair.game_child_owner1.opening_id != pair.opening_id
        or pair.game_child_owner0.opening_position_key
        != pair.game_child_owner1.opening_position_key
    ):
        raise ValueError("arena pair is incomplete or internally inconsistent")
    return pair


def _atomic_write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    os.replace(temporary, path)


def _validate_replayed_game(compiled, opening, game: ArenaGameResult) -> None:
    session = GameSession(compiled)
    for action in opening.actions:
        session.submit(action)
    if position_identity_key(session.state.position, compiled) != game.opening_position_key:
        raise ValueError("arena game opening position does not replay")
    if len(game.actions) != game.plies:
        raise ValueError("arena game ply count does not match its actions")
    for index, action in enumerate(game.actions):
        if game.search_metrics:
            metric = game.search_metrics[index]
            if (
                metric.get("side_to_move") != session.state.position.side_to_move
                or metric.get("decision_kind") != "action"
            ):
                raise ValueError("arena game search telemetry does not replay")
        if action not in session.legal_actions():
            raise ValueError("arena game contains an illegal action")
        session.submit(action)
    if game.declaration_id is not None:
        if game.search_metrics:
            metric = game.search_metrics[-1]
            if (
                len(game.search_metrics) != game.plies + 1
                or metric.get("side_to_move") != session.state.position.side_to_move
                or metric.get("decision_kind") != "declaration"
            ):
                raise ValueError("arena declaration telemetry does not replay")
        session.declare(game.declaration_id)
    elif game.search_metrics and len(game.search_metrics) != game.plies:
        raise ValueError("arena game search telemetry count does not match plies")
    if (
        session.result.status.value != game.result
        or session.result.winner != game.winner
        or position_identity_key(session.state.position, compiled)
        != game.final_position_key
    ):
        raise ValueError("arena game result does not replay")


def _progress_identity(
    compiled,
    parent: LearnableMaterialCheckpoint,
    child: LearnableMaterialCheckpoint,
    config: ArenaConfig,
    openings: ArenaOpeningCorpus,
    *,
    capture_search_metrics: bool = False,
) -> dict:
    opening_rows = openings.to_dict()["openings"][:config.pairs]
    identity = {
        "ruleset_fingerprint": compiled.ruleset_fingerprint,
        "parent_checkpoint_id": parent.checkpoint_id,
        "child_checkpoint_id": child.checkpoint_id,
        "config": asdict(config),
        "ordered_openings": opening_rows,
    }
    if capture_search_metrics:
        identity["capture_search_metrics"] = True
    return identity


def run_arena(
    compiled,
    native_rules,
    parent: LearnableMaterialCheckpoint,
    child: LearnableMaterialCheckpoint,
    config: ArenaConfig,
    openings: ArenaOpeningCorpus | None = None,
    *,
    capture_search_metrics: bool = False,
    policy=None,
    policy_deferred_legality=False,
    execution_caps: ArenaExecutionCaps | None = None,
) -> ArenaSummary:
    """Paired matches over a fixed evaluator-neutral opening corpus."""
    openings = _prepare_arena(compiled, parent, child, config, openings)
    indexes = range(config.pairs)
    def execute(index: int) -> ArenaPairResult:
        args = (compiled, native_rules, parent, child, config, openings, index)
        if capture_search_metrics:
            return _play_pair(
                *args, capture_search_metrics=True, policy=policy,
                policy_deferred_legality=policy_deferred_legality,
                execution_caps=execution_caps,
            )
        return _play_pair(
            *args, policy=policy,
            policy_deferred_legality=policy_deferred_legality,
            execution_caps=execution_caps,
        )

    if config.workers == 1:
        pairs = [execute(index) for index in indexes]
    else:
        with ThreadPoolExecutor(max_workers=config.workers) as pool:
            pairs = list(pool.map(execute, indexes))
    return _summarize_pairs(pairs)


def run_arena_resumable(
    compiled,
    native_rules,
    parent: LearnableMaterialCheckpoint,
    child: LearnableMaterialCheckpoint,
    config: ArenaConfig,
    *,
    progress_dir: str | Path,
    openings: ArenaOpeningCorpus | None = None,
    capture_search_metrics: bool = False,
) -> ArenaSummary:
    """Run an arena while atomically checkpointing complete swapped-color pairs."""
    openings = _prepare_arena(compiled, parent, child, config, openings)
    directory = Path(progress_dir)
    directory.mkdir(parents=True, exist_ok=True)
    identity = _progress_identity(
        compiled, parent, child, config, openings,
        capture_search_metrics=capture_search_metrics,
    )
    identity_sha256 = stable_sha256(identity)
    expected_manifest = {
        "schema": ARENA_PROGRESS_SCHEMA,
        "identity_sha256": identity_sha256,
        "identity": identity,
    }
    manifest_path = directory / "manifest.json"
    if manifest_path.exists():
        try:
            actual_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ArenaExecutionError("arena progress manifest is corrupt") from exc
        if actual_manifest != expected_manifest:
            raise ArenaExecutionError("arena progress identity does not match this run")
    else:
        _atomic_write_json(manifest_path, expected_manifest)

    completed: dict[int, ArenaPairResult] = {}

    def require_telemetry(pair: ArenaPairResult) -> None:
        if capture_search_metrics and (
            not pair.game_child_owner0.search_metrics
            or not pair.game_child_owner1.search_metrics
        ):
            raise ArenaExecutionError(
                "arena progress pair is missing requested search telemetry"
            )

    for pair_path in directory.glob("pair-*.json"):
        try:
            data = json.loads(pair_path.read_text(encoding="utf-8"))
            pair = _pair_from_dict(data, identity_sha256=identity_sha256)
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise ArenaExecutionError(f"arena progress pair is corrupt: {pair_path.name}") from exc
        expected_name = f"pair-{pair.pair_index:06d}.json"
        if pair_path.name != expected_name or not 0 <= pair.pair_index < config.pairs:
            raise ArenaExecutionError(f"arena progress pair has invalid index: {pair_path.name}")
        expected_opening = openings.openings[pair.pair_index]
        if (
            pair.opening_id != expected_opening.final_position_key
            or pair.game_child_owner0.pair != expected_opening.index
            or pair.game_child_owner1.pair != expected_opening.index
        ):
            raise ArenaExecutionError(f"arena progress opening mismatch: {pair_path.name}")
        try:
            _validate_replayed_game(compiled, expected_opening, pair.game_child_owner0)
            _validate_replayed_game(compiled, expected_opening, pair.game_child_owner1)
        except Exception as exc:
            raise ArenaExecutionError(
                f"arena progress game does not replay: {pair_path.name}"
            ) from exc
        if pair.pair_index in completed:
            raise ArenaExecutionError(f"conflicting arena progress pair: {pair.pair_index}")
        require_telemetry(pair)
        completed[pair.pair_index] = pair

    missing = [index for index in range(config.pairs) if index not in completed]
    def execute(index: int) -> ArenaPairResult:
        args = (compiled, native_rules, parent, child, config, openings, index)
        if capture_search_metrics:
            return _play_pair(*args, capture_search_metrics=True)
        return _play_pair(*args)

    if config.workers == 1:
        produced = (execute(index) for index in missing)
        for pair in produced:
            require_telemetry(pair)
            _atomic_write_json(
                directory / f"pair-{pair.pair_index:06d}.json",
                _pair_to_dict(pair, identity_sha256),
            )
            completed[pair.pair_index] = pair
    else:
        with ThreadPoolExecutor(max_workers=config.workers) as pool:
            futures = {pool.submit(execute, index): index for index in missing}
            for future in as_completed(futures):
                pair = future.result()
                require_telemetry(pair)
                _atomic_write_json(
                    directory / f"pair-{pair.pair_index:06d}.json",
                    _pair_to_dict(pair, identity_sha256),
                )
                completed[pair.pair_index] = pair
    return _summarize_pairs(list(completed.values()))


@dataclass(frozen=True, slots=True)
class ArenaDecisionCriterion:
    """Predeclared pass criterion for decision-aware early stopping."""

    mean_threshold: float = 0.5
    mean_operator: str = ">"
    require_better_than_worse: bool = False

    def __post_init__(self) -> None:
        if not 0.0 <= self.mean_threshold <= 1.0:
            raise ValueError("mean_threshold must be in [0, 1]")
        if self.mean_operator not in {">", ">=", "<", "<="}:
            raise ValueError("unsupported mean criterion operator")


@dataclass(frozen=True, slots=True)
class ArenaDecisionBound:
    """Best/worst possible final decision from complete pair scores only."""

    requested_pairs: int
    completed_pairs: int
    remaining_pairs: int
    completed_total: float
    best_final_total: float
    worst_final_total: float
    best_final_mean: float
    worst_final_mean: float
    best_better_pairs: int
    best_tied_pairs: int
    best_worse_pairs: int
    worst_better_pairs: int
    worst_tied_pairs: int
    worst_worse_pairs: int
    criterion: dict
    decision_state: str
    decision_sufficient: bool
    strength_estimate_complete: bool


def arena_decision_bound(
    completed_pair_scores: list[float] | tuple[float, ...],
    requested_pairs: int,
    *,
    target_mean: float = 0.5,
    criterion: ArenaDecisionCriterion | str | dict | None = None,
    require_better_than_worse: bool | None = None,
) -> ArenaDecisionBound:
    """Return conservative bounds without inventing scores for missing pairs.

    Pair scores are always in ``[0, 1]``.  A greater-than-half decision is
    sufficient only when even the worst remaining pairs stay strictly above
    ``target_mean``.  This deliberately distinguishes a locked decision from
    a complete strength estimate.
    """
    if requested_pairs <= 0:
        raise ValueError("requested_pairs must be positive")
    scores = tuple(float(score) for score in completed_pair_scores)
    if len(scores) > requested_pairs:
        raise ValueError("more completed pairs than requested pairs")
    if any(score < 0.0 or score > 1.0 for score in scores):
        raise ValueError("pair scores must be in [0, 1]")
    if criterion is None:
        resolved = ArenaDecisionCriterion(
            mean_threshold=target_mean,
            require_better_than_worse=bool(require_better_than_worse),
        )
    elif isinstance(criterion, ArenaDecisionCriterion):
        resolved = criterion
        if require_better_than_worse is not None:
            resolved = ArenaDecisionCriterion(
                mean_threshold=resolved.mean_threshold,
                mean_operator=resolved.mean_operator,
                require_better_than_worse=require_better_than_worse,
            )
    elif isinstance(criterion, str):
        if criterion in {"f63_teacher_gate", "mean_gt_half_and_better"}:
            resolved = ArenaDecisionCriterion(
                mean_threshold=target_mean,
                require_better_than_worse=True,
            )
        elif criterion in {"mean_gt", "mean_gt_half", "mean_threshold"}:
            resolved = ArenaDecisionCriterion(mean_threshold=target_mean)
        else:
            raise ValueError(f"unknown arena decision criterion: {criterion}")
    elif isinstance(criterion, dict):
        resolved = ArenaDecisionCriterion(
            mean_threshold=float(criterion.get("mean_threshold", target_mean)),
            mean_operator=str(criterion.get("mean_operator", ">")),
            require_better_than_worse=bool(
                criterion.get("require_better_than_worse", False)
            ),
        )
        if require_better_than_worse is not None:
            resolved = ArenaDecisionCriterion(
                mean_threshold=resolved.mean_threshold,
                mean_operator=resolved.mean_operator,
                require_better_than_worse=require_better_than_worse,
            )
    else:
        raise TypeError("criterion must be a criterion, string, dict, or None")
    remaining = requested_pairs - len(scores)
    completed_total = sum(scores)
    best_total = completed_total + remaining
    worst_total = completed_total
    completed_better = sum(score > 0.5 for score in scores)
    completed_tied = sum(score == 0.5 for score in scores)
    completed_worse = sum(score < 0.5 for score in scores)
    criterion_payload = asdict(resolved)

    def mean_pass(value: float) -> bool:
        if resolved.mean_operator == ">":
            return value > resolved.mean_threshold
        if resolved.mean_operator == ">=":
            return value >= resolved.mean_threshold
        if resolved.mean_operator == "<":
            return value < resolved.mean_threshold
        return value <= resolved.mean_threshold

    def class_pass(better: int, worse: int) -> bool:
        return (
            not resolved.require_better_than_worse
            or better > worse
        )

    best_passes = mean_pass(best_total / requested_pairs) and class_pass(
        completed_better + remaining, completed_worse
    )
    worst_passes = mean_pass(worst_total / requested_pairs) and class_pass(
        completed_better, completed_worse + remaining
    )
    higher_is_better = resolved.mean_operator in {">", ">="}
    pass_locked = worst_passes if higher_is_better else best_passes
    fail_locked = (not best_passes) if higher_is_better else (not worst_passes)
    if pass_locked:
        decision_state = "PASS_LOCKED"
    elif fail_locked:
        decision_state = "FAIL_LOCKED"
    else:
        decision_state = "UNRESOLVED"
    return ArenaDecisionBound(
        requested_pairs=requested_pairs,
        completed_pairs=len(scores),
        remaining_pairs=remaining,
        completed_total=completed_total,
        best_final_total=best_total,
        worst_final_total=worst_total,
        best_final_mean=best_total / requested_pairs,
        worst_final_mean=worst_total / requested_pairs,
        best_better_pairs=completed_better + remaining,
        best_tied_pairs=completed_tied,
        best_worse_pairs=completed_worse,
        worst_better_pairs=completed_better,
        worst_tied_pairs=completed_tied,
        worst_worse_pairs=completed_worse + remaining,
        criterion=criterion_payload,
        decision_state=decision_state,
        decision_sufficient=(decision_state != "UNRESOLVED"),
        strength_estimate_complete=(remaining == 0),
    )


# Descriptive aliases used by audit/report callers.
compute_arena_decision_bound = arena_decision_bound
decision_bound = arena_decision_bound


@dataclass(frozen=True, slots=True)
class ArenaRunResult:
    """A game-level run, including an explicit non-scoring partial state."""

    status: str
    summary: ArenaSummary | None
    completed_games: int
    completed_pairs: int
    total_games: int
    reason: str | None
    effective_game_lanes: int
    decision_bound: ArenaDecisionBound

    @property
    def is_complete(self) -> bool:
        return self.status == "COMPLETE"


def _game_progress_identity(
    compiled,
    parent: LearnableMaterialCheckpoint,
    child: LearnableMaterialCheckpoint,
    config: ArenaConfig,
    openings: ArenaOpeningCorpus,
    caps: ArenaExecutionCaps,
    *,
    stage_id: str,
    capture_search_metrics: bool,
    decision_criterion: dict | str | None = None,
    policy_identity: dict | str | None = None,
    ordering_checkpoint=None,
) -> dict:
    identity = _progress_identity(
        compiled, parent, child, config, openings,
        capture_search_metrics=capture_search_metrics,
    )
    identity.update({
        "schema": ARENA_GAME_PROGRESS_SCHEMA,
        "stage_id": stage_id,
        "arena_id": getattr(
            openings, "corpus_id", stable_sha256(openings.to_dict())
        ),
        "execution_caps": asdict(caps),
        "effective_game_lanes": caps.game_lanes(config.pairs, config.workers),
    })
    if decision_criterion is not None:
        identity["decision_criterion"] = (
            asdict(decision_criterion)
            if isinstance(decision_criterion, ArenaDecisionCriterion)
            else decision_criterion
        )
    if policy_identity is not None:
        identity["policy_identity"] = policy_identity
    identity["ordering_checkpoint_id"] = (
        None if ordering_checkpoint is None else ordering_checkpoint.checkpoint_id
    )
    return identity


def _game_progress_identity_for(
    base_identity: dict,
    config: ArenaConfig,
    caps: ArenaExecutionCaps,
    opening: dict,
    pair_index: int,
    child_owner: int,
    *,
    capture_search_metrics: bool,
) -> dict:
    parent_budget = config.parent_nodes_per_move or config.nodes_per_move
    child_budget = config.child_nodes_per_move or config.nodes_per_move
    return {
        "stage_id": base_identity["stage_id"],
        "arena_id": base_identity["arena_id"],
        "pair_index": pair_index,
        "opening": opening,
        "child_owner": child_owner,
        "parent_checkpoint_id": base_identity["parent_checkpoint_id"],
        "child_checkpoint_id": base_identity["child_checkpoint_id"],
        "ordering_checkpoint_id": base_identity.get("ordering_checkpoint_id"),
        "node_budgets": {"parent": parent_budget, "child": child_budget},
        "max_depth": config.max_depth,
        "tt_megabytes": config.tt_megabytes,
        "timing_mode": (
            "per_move_search_time" if config.move_time_seconds is not None
            else "unbounded_or_execution_cap"
        ),
        "move_time_seconds": config.move_time_seconds,
        "capture_search_metrics": capture_search_metrics,
        "hard_caps": asdict(caps),
    }


def _game_progress_to_dict(
    game: ArenaGameResult,
    *,
    identity_sha256: str,
    game_identity: dict,
) -> dict:
    return {
        "schema": ARENA_GAME_PROGRESS_SCHEMA,
        "identity_sha256": identity_sha256,
        "game_identity": game_identity,
        "status": "completed",
        "game": _game_to_dict(game),
    }


def _game_progress_from_dict(data: dict) -> tuple[dict, ArenaGameResult]:
    required = {"schema", "identity_sha256", "game_identity", "status", "game"}
    if set(data) != required or data.get("schema") != ARENA_GAME_PROGRESS_SCHEMA:
        raise ValueError("arena game fields do not match the game progress schema")
    if data.get("status") != "completed" or not isinstance(data["game_identity"], dict):
        raise ValueError("arena game progress is not a completed game")
    return data["game_identity"], _game_from_dict(data["game"])


def _partial_game_progress_to_dict(
    *, identity_sha256: str, game_identity: dict, pair: int,
    child_owner: int, opening_id: str, actions: list[Action],
    search_metrics: list[dict], searched_nodes: int,
) -> dict:
    return {
        "schema": ARENA_PARTIAL_GAME_PROGRESS_SCHEMA,
        "identity_sha256": identity_sha256,
        "game_identity": game_identity,
        "status": "partial",
        "pair": pair,
        "child_owner": child_owner,
        "opening_id": opening_id,
        "plies": len(actions),
        "actions": [action_to_dict(action) for action in actions],
        "search_metrics": list(search_metrics),
        "searched_nodes": int(searched_nodes),
    }


def _partial_game_progress_from_dict(data: dict) -> dict:
    required = {
        "schema", "identity_sha256", "game_identity", "status", "pair",
        "child_owner", "opening_id", "plies", "actions", "search_metrics",
        "searched_nodes",
    }
    if set(data) != required or data.get("schema") != ARENA_PARTIAL_GAME_PROGRESS_SCHEMA:
        raise ValueError("arena partial game fields do not match the progress schema")
    if data.get("status") != "partial" or not isinstance(data["game_identity"], dict):
        raise ValueError("arena partial game progress is not a partial game")
    if data["child_owner"] not in (0, 1) or data["pair"] < 0:
        raise ValueError("arena partial game owner or pair is invalid")
    actions = tuple(action_from_dict(action) for action in data["actions"])
    if int(data["plies"]) != len(actions) or int(data["searched_nodes"]) < 0:
        raise ValueError("arena partial game progress counts are invalid")
    if data["search_metrics"] and len(data["search_metrics"]) != len(actions):
        raise ValueError("arena partial game telemetry does not match its actions")
    return dict(data, actions=actions)


def _validate_game_telemetry(
    game: ArenaGameResult,
    config: ArenaConfig,
    *,
    capture_search_metrics: bool,
) -> None:
    if not capture_search_metrics:
        if game.search_metrics:
            raise ValueError("arena game has telemetry but telemetry is disabled")
        return
    if not game.search_metrics:
        raise ValueError("arena game is missing requested search telemetry")
    expected_count = game.plies + (1 if game.declaration_id is not None else 0)
    if len(game.search_metrics) != expected_count:
        raise ValueError("arena game telemetry count does not match its decisions")
    parent_budget = config.parent_nodes_per_move or config.nodes_per_move
    child_budget = config.child_nodes_per_move or config.nodes_per_move
    for index, metric in enumerate(game.search_metrics):
        if not isinstance(metric, dict):
            raise ValueError("arena game telemetry row is not an object")
        required = {
            "side_to_move", "engine_role", "nodes_budget", "nodes",
            "elapsed_seconds", "elapsed_source", "decision_kind",
        }
        if not required <= metric.keys():
            raise ValueError("arena game telemetry row is incomplete")
        role = metric["engine_role"]
        budget = child_budget if role == "child" else parent_budget if role == "parent" else None
        if budget is None or metric["nodes_budget"] != budget:
            raise ValueError("arena game telemetry node budget is invalid")
        if int(metric["nodes"]) < 0 or int(metric["nodes"]) > budget:
            raise ValueError("arena game telemetry node count is invalid")
        if config.move_time_seconds is not None:
            timed_fields = {
                "search_wall_seconds", "timing_mode", "requested_time_seconds",
                "time_budget_termination", "wall_budget_overshoot_seconds",
            }
            if not timed_fields <= metric.keys():
                raise ValueError("timed arena telemetry row is incomplete")
            if metric["timing_mode"] != "per_move_search_time":
                raise ValueError("timed arena telemetry mode is invalid")
            if metric["requested_time_seconds"] != config.move_time_seconds:
                raise ValueError("timed arena telemetry budget is invalid")
            if float(metric["search_wall_seconds"]) < 0.0:
                raise ValueError("timed arena telemetry wall time is invalid")
            if float(metric["wall_budget_overshoot_seconds"]) < 0.0:
                raise ValueError("timed arena telemetry overshoot is invalid")
        if metric["decision_kind"] != (
            "declaration" if index == game.plies and game.declaration_id is not None
            else "action"
        ):
            raise ValueError("arena game telemetry decision kind is invalid")


def _validate_game_progress(
    compiled,
    opening,
    payload: dict,
    *,
    expected_identity: dict,
    identity_sha256: str,
    config: ArenaConfig,
    capture_search_metrics: bool,
    pair_index: int,
    child_owner: int,
) -> ArenaGameResult:
    game_identity, game = _game_progress_from_dict(payload)
    if payload.get("identity_sha256") != identity_sha256:
        raise ValueError("arena game identity does not match the manifest")
    if game_identity != expected_identity:
        raise ValueError("arena game identity does not match the expected game")
    if game.pair != pair_index or game.child_owner != child_owner:
        raise ValueError("arena game pair or owner does not match its filename")
    if game.opening_id != opening.final_position_key:
        raise ValueError("arena game opening identity does not match the corpus")
    if game.result == "ongoing":
        raise ValueError("arena game is not terminal")
    _validate_replayed_game(compiled, opening, game)
    _validate_game_telemetry(
        game, config, capture_search_metrics=capture_search_metrics
    )
    return game


def _pair_results_from_games(
    games: dict[tuple[int, int], ArenaGameResult],
    openings: ArenaOpeningCorpus,
) -> list[ArenaPairResult]:
    pairs = []
    for pair_index in range(len(openings.openings)):
        owner0 = games.get((pair_index, 0))
        owner1 = games.get((pair_index, 1))
        if owner0 is None or owner1 is None:
            continue
        pairs.append(ArenaPairResult(
            pair_index=pair_index,
            opening_id=openings.openings[pair_index].final_position_key,
            game_child_owner0=owner0,
            game_child_owner1=owner1,
        ))
    return pairs


def run_arena_game_resumable(
    compiled,
    native_rules,
    parent: LearnableMaterialCheckpoint,
    child: LearnableMaterialCheckpoint,
    config: ArenaConfig,
    *,
    progress_dir: str | Path,
    openings: ArenaOpeningCorpus | None = None,
    capture_search_metrics: bool = False,
    execution_caps: ArenaExecutionCaps | None = None,
    caps: ArenaExecutionCaps | None = None,
    identity_caps: ArenaExecutionCaps | None = None,
    stage_id: str = "arena",
    pause_requested=None,
    pause_file: str | Path | None = None,
    decision_criterion: ArenaDecisionCriterion | str | dict | None = None,
    stop_on_decision: bool = False,
    max_pairs: int | None = None,
    root_order_hint_provider=None,
    policy_identity: dict | str | None = None,
    ordering_checkpoint=None,
) -> ArenaRunResult:
    """Run one game per checkpoint and aggregate only complete pairs.

    Game files are the scheduling unit.  A crash after either swapped-color
    game leaves a valid partial pair; a later call validates and reuses it,
    then schedules only the missing game.  Hard-cap hits are returned as an
    explicit incomplete result and can never become a draw.
    """
    if execution_caps is not None and caps is not None:
        raise ValueError("pass only one of execution_caps or caps")
    caps = execution_caps or caps or ArenaExecutionCaps()
    identity_caps = identity_caps or caps
    if max_pairs is not None and (max_pairs <= 0 or max_pairs > config.pairs):
        raise ValueError("max_pairs must be within the configured pair count")
    if not isinstance(stage_id, str) or not stage_id:
        raise ValueError("stage_id must be a non-empty string")
    openings = _prepare_arena(compiled, parent, child, config, openings)
    directory = Path(progress_dir)
    directory.mkdir(parents=True, exist_ok=True)
    lanes = caps.game_lanes(config.pairs, config.workers)
    identity = _game_progress_identity(
        compiled, parent, child, config, openings, identity_caps,
        stage_id=stage_id, capture_search_metrics=capture_search_metrics,
        decision_criterion=decision_criterion,
        policy_identity=policy_identity,
        ordering_checkpoint=ordering_checkpoint,
    )
    if max_pairs is not None:
        identity["max_pairs"] = max_pairs
    identity_sha256 = stable_sha256(identity)
    expected_manifest = {
        "schema": ARENA_GAME_PROGRESS_SCHEMA,
        "identity_sha256": identity_sha256,
        "identity": identity,
    }
    manifest_path = directory / "manifest.json"
    if manifest_path.exists():
        try:
            actual_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ArenaExecutionError("arena game progress manifest is corrupt") from exc
        if actual_manifest != expected_manifest:
            raise ArenaExecutionError("arena game progress identity does not match this run")
    else:
        if list(directory.glob("pair-*.json")):
            raise ArenaExecutionError(
                "pair-v1 progress cannot be mixed with game-v1 progress"
            )
        _atomic_write_json(manifest_path, expected_manifest)

    opening_rows = openings.to_dict()["openings"]
    if len(opening_rows) < config.pairs:
        raise ArenaExecutionError("arena opening identity is incomplete")
    expected_games = {
        (pair_index, owner): _game_progress_identity_for(
            identity, config, identity_caps, opening_rows[pair_index], pair_index, owner,
            capture_search_metrics=capture_search_metrics,
        )
        for pair_index in range(config.pairs)
        for owner in (0, 1)
    }
    completed_games: dict[tuple[int, int], ArenaGameResult] = {}
    for game_path in sorted(directory.glob("game-*.json")):
        match = re.fullmatch(
            r"game-(\d{6})-owner-([01])\.json", game_path.name
        )
        if match is None:
            raise ArenaExecutionError(
                f"arena game progress has invalid filename: {game_path.name}"
            )
        key = (int(match.group(1)), int(match.group(2)))
        if key not in expected_games:
            raise ArenaExecutionError(
                f"arena game progress has invalid index: {game_path.name}"
            )
        try:
            payload = json.loads(game_path.read_text(encoding="utf-8"))
            game = _validate_game_progress(
                compiled, openings.openings[key[0]], payload,
                expected_identity=expected_games[key],
                identity_sha256=identity_sha256, config=config,
                capture_search_metrics=capture_search_metrics,
                pair_index=key[0], child_owner=key[1],
            )
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise ArenaExecutionError(
                f"arena game progress is corrupt: {game_path.name}"
            ) from exc
        if key in completed_games:
            raise ArenaExecutionError(f"conflicting arena game progress: {key}")
        completed_games[key] = game

    partial_games: dict[tuple[int, int], dict] = {}
    for partial_path in sorted(directory.glob("partial-game-*.json")):
        match = re.fullmatch(
            r"partial-game-(\d{6})-owner-([01])\.json", partial_path.name
        )
        if match is None:
            raise ArenaExecutionError(
                f"arena partial progress has invalid filename: {partial_path.name}"
            )
        key = (int(match.group(1)), int(match.group(2)))
        if (
            key not in expected_games
            or key in completed_games
            or (max_pairs is not None and key[0] >= max_pairs)
        ):
            raise ArenaExecutionError(
                f"arena partial progress has invalid index: {partial_path.name}"
            )
        try:
            partial = _partial_game_progress_from_dict(
                json.loads(partial_path.read_text(encoding="utf-8"))
            )
            if partial["identity_sha256"] != identity_sha256:
                raise ValueError("arena partial identity does not match the manifest")
            if partial["game_identity"] != expected_games[key]:
                raise ValueError("arena partial identity does not match the expected game")
            if partial["pair"] != key[0] or partial["child_owner"] != key[1]:
                raise ValueError("arena partial pair or owner does not match its filename")
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise ArenaExecutionError(
                f"arena partial progress is corrupt: {partial_path.name}"
            ) from exc
        partial_games[key] = partial

    active_pairs = max_pairs if max_pairs is not None else config.pairs
    missing = [
        key for key in expected_games
        if key not in completed_games and key[0] < active_pairs
    ]
    stage_started = time.perf_counter()
    stage_deadline = (
        None if caps.stage_wall_seconds is None
        else stage_started + caps.stage_wall_seconds
    )
    stop_reason = None
    fatal_error = None

    def current_decision_bound() -> ArenaDecisionBound:
        return arena_decision_bound(
            [
                pair.child_pair_score
                for pair in _pair_results_from_games(completed_games, openings)
                if pair.is_scoring_pair
            ],
            active_pairs,
            criterion=decision_criterion,
        )

    if stop_on_decision:
        initial_bound = current_decision_bound()
        if (
            initial_bound.decision_state != "UNRESOLVED"
            and len(completed_games) < 2 * config.pairs
        ):
            stop_reason = f"decision_{initial_bound.decision_state}"

    def is_paused() -> bool:
        if pause_requested is not None:
            value = pause_requested() if callable(pause_requested) else pause_requested
            if bool(value):
                return True
        return pause_file is not None and Path(pause_file).exists()

    def launch_blocker(active_count: int) -> str | None:
        if is_paused():
            return "stage_paused"
        if stage_deadline is not None and time.perf_counter() >= stage_deadline:
            return "stage_wall_seconds"
        if (
            caps.max_stage_games is not None
            and len(completed_games) + active_count >= caps.max_stage_games
        ):
            return "max_stage_games"
        return None

    def execute_game(pair_index: int, owner: int) -> ArenaGameResult:
        kwargs = {
            "opening": openings.openings[pair_index],
            "child_owner": owner,
            "config": config,
            "capture_search_metrics": capture_search_metrics,
        }
        partial_path = directory / f"partial-game-{pair_index:06d}-owner-{owner}.json"
        kwargs.update(
            partial_path=partial_path,
            partial_identity_sha256=identity_sha256,
            partial_game_identity=expected_games[(pair_index, owner)],
            resume_partial=partial_games.get((pair_index, owner)),
            root_order_hint_provider=root_order_hint_provider,
            ordering_checkpoint=ordering_checkpoint,
        )
        if caps.has_per_game_caps:
            kwargs["execution_caps"] = caps
        if stage_deadline is not None:
            kwargs["stage_deadline"] = stage_deadline
        return _play_one_game(
            compiled, native_rules, parent, child, **kwargs
        )

    active = {}
    executor = ThreadPoolExecutor(max_workers=lanes)
    try:
        pending = iter(missing)
        exhausted = False
        while active or not exhausted:
            while not exhausted and stop_reason is None and len(active) < lanes:
                blocker = launch_blocker(len(active))
                if blocker is not None:
                    stop_reason = blocker
                    break
                try:
                    key = next(pending)
                except StopIteration:
                    exhausted = True
                    break
                active[key] = executor.submit(execute_game, *key)
            if not active:
                if exhausted or stop_reason is not None:
                    break
                continue
            done, _ = wait(tuple(active.values()), return_when=FIRST_COMPLETED)
            done_items = sorted(
                ((key, active[key]) for key in active if active[key] in done),
                key=lambda item: item[0],
            )
            for key, future in done_items:
                del active[key]
                try:
                    game = future.result()
                    _validate_game_progress(
                        compiled, openings.openings[key[0]],
                        _game_progress_to_dict(
                            game,
                            identity_sha256=identity_sha256,
                            game_identity=expected_games[key],
                        ),
                        expected_identity=expected_games[key],
                        identity_sha256=identity_sha256, config=config,
                        capture_search_metrics=capture_search_metrics,
                        pair_index=key[0], child_owner=key[1],
                    )
                    target = directory / f"game-{key[0]:06d}-owner-{key[1]}.json"
                    if target.exists():
                        raise ArenaExecutionError(
                            f"conflicting arena game progress: {target.name}"
                        )
                    _atomic_write_json(
                        target,
                        _game_progress_to_dict(
                            game,
                            identity_sha256=identity_sha256,
                            game_identity=expected_games[key],
                        ),
                    )
                    (directory / f"partial-game-{key[0]:06d}-owner-{key[1]}.json").unlink(
                        missing_ok=True
                    )
                    completed_games[key] = game
                    if stop_on_decision and all(
                        (key[0], owner) in completed_games for owner in (0, 1)
                    ):
                        completed_bound = current_decision_bound()
                        if completed_bound.decision_state != "UNRESOLVED":
                            stop_reason = (
                                f"decision_{completed_bound.decision_state}"
                            )
                except ArenaCapHit as exc:
                    stop_reason = exc.cap
                except Exception as exc:  # preserve other engine failures
                    fatal_error = exc
                    stop_reason = stop_reason or "arena_execution_error"
            if stop_reason is not None and not active:
                break
    finally:
        executor.shutdown(wait=True)

    if fatal_error is not None:
        raise fatal_error
    pairs = _pair_results_from_games(completed_games, openings)
    bound = arena_decision_bound(
        [pair.child_pair_score for pair in pairs if pair.is_scoring_pair],
        config.pairs,
        criterion=decision_criterion,
    )
    summary = _summarize_pairs(pairs) if len(pairs) == active_pairs else None
    if len(completed_games) == 2 * active_pairs:
        status = "COMPLETE"
        reason = None
    elif stop_reason == "stage_paused":
        status = "PAUSED"
        reason = stop_reason
    else:
        status = "INCOMPLETE"
        reason = stop_reason or "stage_incomplete"
    return ArenaRunResult(
        status=status,
        summary=summary,
        completed_games=len(completed_games),
        completed_pairs=len(pairs),
        total_games=2 * active_pairs,
        reason=reason,
        effective_game_lanes=lanes,
        decision_bound=bound,
    )


# Names used in early F63 notes; all route to the same game-v1 protocol.
run_arena_resumable_game_level = run_arena_game_resumable
run_arena_game_atomic_resumable = run_arena_game_resumable
