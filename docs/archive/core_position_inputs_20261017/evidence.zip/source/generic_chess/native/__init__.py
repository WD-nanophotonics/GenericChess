"""Native Phase 1 rule kernel (optional CPython C extension).

The extension is built by ``scripts/build_native_zig.py`` (or a standard
MSVC setuptools build on compiler-equipped machines).  When it is not built,
``native_available()`` returns False and native tests are skipped; the Python
Core remains the specification and correctness oracle either way.
"""

from __future__ import annotations

from typing import Any

_MODULE = None


def _load() -> Any:
    global _MODULE
    if _MODULE is None:
        import importlib

        _MODULE = importlib.import_module("generic_chess._native_core")
    return _MODULE


def native_available() -> bool:
    try:
        _load()
        return True
    except ImportError:
        return False


def native_version() -> str:
    if not native_available():
        return "unavailable"
    return str(_load().native_version())


def native_capabilities() -> dict:
    if not native_available():
        return {"available": False}
    caps = dict(_load().native_capabilities())
    caps["available"] = True
    return caps


def _module():
    return _load()


__all__ = [
    "native_available",
    "native_version",
    "native_capabilities",
]


def __getattr__(name: str):
    """Lazy re-exports so the optional extension is only touched on use."""
    if name in (
        "compile_native_rules",
        "NativeCompiledRules",
        "NativeCompilationReport",
        "NativeActionError",
        "compile_native_evaluation",
        "NativeEvaluationTables",
        "NATIVE_SCHEMA_VERSION",
    ):
        from .compiler import (
            NATIVE_SCHEMA_VERSION,
            NativeActionError,
            NativeCompilationReport,
            NativeCompiledRules,
            NativeEvaluationTables,
            compile_native_evaluation,
            compile_native_rules,
        )

        return {
            "compile_native_rules": compile_native_rules,
            "NativeCompiledRules": NativeCompiledRules,
            "NativeCompilationReport": NativeCompilationReport,
            "NativeActionError": NativeActionError,
            "compile_native_evaluation": compile_native_evaluation,
            "NativeEvaluationTables": NativeEvaluationTables,
            "NATIVE_SCHEMA_VERSION": NATIVE_SCHEMA_VERSION,
        }[name]
    if name in ("native_fixed_depth_search", "NativeFixedDepthResult"):
        from .search import NativeFixedDepthResult, native_fixed_depth_search

        return {
            "native_fixed_depth_search": native_fixed_depth_search,
            "NativeFixedDepthResult": NativeFixedDepthResult,
        }[name]
    if name in ("NativeSearchEngine", "NativeIterativeSearchResult"):
        from .engine import (
            NativeIterativeSearchResult,
            NativeSearchEngine,
        )

        return {
            "NativeSearchEngine": NativeSearchEngine,
            "NativeIterativeSearchResult": NativeIterativeSearchResult,
        }[name]
    if name in (
        "SemanticSearchEngine", "NativeSemanticSearchEngine",
        "SemanticIterativeSearchResult", "NativeSemanticSearchResult",
    ):
        from .semantic_engine import (
            NativeSemanticSearchEngine,
            NativeSemanticSearchResult,
            SemanticIterativeSearchResult,
            SemanticSearchEngine,
        )
        return {
            "SemanticSearchEngine": SemanticSearchEngine,
            "NativeSemanticSearchEngine": NativeSemanticSearchEngine,
            "SemanticIterativeSearchResult": SemanticIterativeSearchResult,
            "NativeSemanticSearchResult": NativeSemanticSearchResult,
        }[name]
    if name in ("semantic_iterative_search", "iterative_search"):
        from .semantic import iterative_search, semantic_iterative_search

        return {
            "semantic_iterative_search": semantic_iterative_search,
            "iterative_search": iterative_search,
        }[name]
    if name in (
        "NativeSemanticCompilationReport",
        "NativeSemanticCompiledRules",
        "build_semantic_compile_payload",
        "compile_native_semantic_rules",
        "SEMANTIC_PAYLOAD_VERSION",
    ):
        from .compiler import (
            SEMANTIC_PAYLOAD_VERSION,
            NativeSemanticCompilationReport,
            NativeSemanticCompiledRules,
            build_semantic_compile_payload,
            compile_native_semantic_rules,
        )

        return {
            "NativeSemanticCompilationReport": NativeSemanticCompilationReport,
            "NativeSemanticCompiledRules": NativeSemanticCompiledRules,
            "build_semantic_compile_payload": build_semantic_compile_payload,
            "compile_native_semantic_rules": compile_native_semantic_rules,
            "SEMANTIC_PAYLOAD_VERSION": SEMANTIC_PAYLOAD_VERSION,
        }[name]
    raise AttributeError(name)
