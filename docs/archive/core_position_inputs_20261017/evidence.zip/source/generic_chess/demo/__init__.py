"""Headless demo (no UI)."""
