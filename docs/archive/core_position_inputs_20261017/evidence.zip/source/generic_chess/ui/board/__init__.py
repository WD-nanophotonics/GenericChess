"""QGraphicsView-based board rendering."""
