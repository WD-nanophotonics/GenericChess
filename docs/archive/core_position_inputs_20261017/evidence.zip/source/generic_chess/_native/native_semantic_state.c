#include "native_semantic_state.h"

#include <string.h>

static void gc_semantic_aux_default(GCSemAuxValue *out,
                                    const GCSemAuxSlot *slot,
                                    uint8_t board_size) {
    memset(out, 0, sizeof(*out));
    out->kind = slot->value_kind;
    if (slot->initial_kind == 1) {
        out->has_value = 1;
        out->bool_value = slot->initial_int;
    } else if (slot->initial_kind == 2) {
        out->has_value = 1;
        out->square = (uint16_t)(slot->initial_rank * board_size + slot->initial_file);
    }
}

int gc_semantic_position_pack(GCSemanticPosition *pos,
                              const GCSemanticRules *rules,
                              const GCSemanticBoardPayload *payload) {
    if (pos == NULL || rules == NULL || payload == NULL ||
        payload->side_to_move > 1 || payload->ply > GC_SEM_MAX_PLY) {
        return 0;
    }
    GCSemAuxValue provided[GC_SEM_MAX_AUX_SLOTS][3];
    memcpy(provided, payload->aux, sizeof(provided));
    memset(pos, 0, offsetof(GCSemanticPosition, history_lo));
    memset(&pos->history_len, 0,
           sizeof(*pos) - offsetof(GCSemanticPosition, history_len));
    memcpy(pos->rules_fingerprint, rules->fingerprint, sizeof(pos->rules_fingerprint));
    pos->side_to_move = payload->side_to_move;
    pos->ply = payload->ply;
    memcpy(pos->board, payload->board, sizeof(GCPiece) *
           (size_t)(rules->board_size * rules->board_size));
    memcpy(pos->hand_counts, payload->hand_counts, sizeof(pos->hand_counts));
    if (payload->history_len > GC_SEM_MAX_PLY + 1) return 0;
    pos->history_len = payload->history_len;
    memcpy(pos->history_lo, payload->history_lo,
           sizeof(pos->history_lo[0]) * (size_t)payload->history_len);
    memcpy(pos->history_hi, payload->history_hi,
           sizeof(pos->history_hi[0]) * (size_t)payload->history_len);
    memcpy(pos->history_digest, payload->history_digest,
           sizeof(pos->history_digest[0]) * (size_t)payload->history_len);
    memcpy(pos->history_actor, payload->history_actor,
           sizeof(pos->history_actor[0]) * (size_t)payload->history_len);
    memcpy(pos->history_gave_check, payload->history_gave_check,
           sizeof(pos->history_gave_check[0]) * (size_t)payload->history_len);
    pos->history_exact = payload->history_exact;
    pos->history_events_exact = payload->history_events_exact;
    for (uint16_t sq = 0; sq < (uint16_t)(rules->board_size * rules->board_size); sq++) {
        const GCPiece *piece = &pos->board[sq];
        if (!piece->occupied) continue;
        if (piece->owner > 1 || piece->base_type >= rules->type_count ||
            piece->current_type >= rules->type_count || piece->promoted > 1) {
            return 0;
        }
        /* Semantic effects can change types outside legacy promotion targets.
         * Packing checks representation, not legal reachability. An unpromoted
         * piece retains its base type; explicit promotion to that SAME type can
         * legally set promoted=1, so the converse implication does not hold.
         * Core and Native execution/history checks own transition validity. */
        if (!piece->promoted && piece->current_type != piece->base_type) return 0;
    }
    for (uint8_t slot_i = 0; slot_i < rules->aux_slot_count; slot_i++) {
        const GCSemAuxSlot *slot = &rules->aux_slots[slot_i];
        gc_semantic_aux_default(&pos->aux[slot_i][0], slot, rules->board_size);
        if (slot->scope == 1) {
            gc_semantic_aux_default(&pos->aux[slot_i][1], slot, rules->board_size);
            gc_semantic_aux_default(&pos->aux[slot_i][2], slot, rules->board_size);
        }
        for (uint8_t owner = 0; owner < 3; owner++)
            if (provided[slot_i][owner].supplied)
                pos->aux[slot_i][owner] = provided[slot_i][owner];
    }
    return 1;
}

int gc_semantic_position_matches_rules(const GCSemanticPosition *pos,
                                       const GCSemanticRules *rules) {
    return pos != NULL && rules != NULL &&
           memcmp(pos->rules_fingerprint, rules->fingerprint,
                  sizeof(pos->rules_fingerprint)) == 0;
}
