"""Deterministic core game kernel."""
