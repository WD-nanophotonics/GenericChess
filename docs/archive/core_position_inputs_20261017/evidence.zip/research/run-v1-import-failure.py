from pathlib import Path
import sys,json,time,math
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];P=R/'.local_agent/consumer-isolation-20261017'
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.learning.nonlinear import CompactNonlinearResidual,semantic_state_features
from test_native_dynamic_feature_views import reference_features
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value

from dataclasses import replace
import random,hashlib
from generic_chess.generation import generate_game,GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.learning.features import localized_control_features
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import position_identity_key
P=R/'.local_agent/core-forecast-20261017';old=R/'.local_agent/consumer-isolation-20261017'
sys.path.insert(0,str(old/'Core-shared-input'))
from shared_core_inputs import shared_core_inputs
plan=json.loads((P/'plan.json').read_bytes());start=time.perf_counter()
def save(name,value):
 (P/name).write_bytes(json.dumps(value,indent=2).encode())
def stopped():
 for name in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def adapt(rules):
 x=compile_legacy_ruleset_for_semantic_execution(rules)
 return SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)
source=next(z for z in json.loads((old/'compact-required3/results.json').read_bytes())['roots']if z['seed']==125601)
t=time.perf_counter();model=CompactNonlinearResidual.from_dict(source['checkpoint']['compact_nonlinear']);model._prediction_arrays;model_seconds=time.perf_counter()-t
roots=[];live=[]
for case in plan['predeclared_cases']:
 stopped();t=time.perf_counter();seed=case['seed'];cfg=GeneratorConfig(seed=seed,board_size=16,setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32)
 try:
  game=generate_game(cfg);rules=replace(game.ruleset,max_ply=2048);c=adapt(rules);s=GameSession(c);rng=random.Random(seed+700000)
  for ply in range(8):
   if s.state.terminal_status.is_terminal:break
   legal=sorted(s.legal_actions(),key=repr)
   if not legal:break
   s.submit(rng.choice(legal))
  legal=s.legal_actions();degree=len(legal);nodes=max(1024,2*(degree+1));n=compile_native_semantic_rules(c);packed=pack_semantic_search_position(c,n,s);native_degree=len(sem.legal_actions(n,packed));assert degree==native_degree
  dynamic=reference_features(c,s.state.position);control=localized_control_features(s.state.position,c);assert shared_core_inputs(s.state.position,c)==(dynamic,control)
  features=semantic_state_features(s.state.position,c,dynamic);assert len(features)==5145
  eligible=s.state.ply_count==8 and not s.state.terminal_status.is_terminal and degree>0 and nodes<=8192
  z={'seed':seed,'config':record_value(cfg),'ruleset':json.loads(serialize_ruleset(rules)),'record':record_value(s.to_record()),'state':record_value(s.state),'witnesses':record_value(s._search_witnesses),'root_degree':degree,'native_root_degree':native_degree,'node_forecast':nodes,'dimension':len(features),'dynamic':dynamic,'control':control,'eligible':eligible,'setup_seconds':time.perf_counter()-t}
  roots.append(z)
  if eligible:live.append((z,c,s))
 except Exception as e:
  roots.append({'seed':seed,'failure':type(e).__name__+':'+str(e),'eligible':False,'setup_seconds':time.perf_counter()-t});raise
save('forecast.json',{'roots':roots,'model_seconds':model_seconds,'checkpoint':source['checkpoint'],'preparation_seconds':time.perf_counter()-start,'queries_started':0})
print('FORECAST',[(z['seed'],z.get('root_degree'),z.get('node_forecast'),z['eligible'])for z in roots],flush=True)
class Manual:
 def __init__(self,c,shared):self.c=c;self.shared=shared;self.calls=0;self.dimensions=set();self.feature_seconds=0.;self.predict_seconds=0.;self.trace=hashlib.sha256()
 def evaluate(self,state):
  t=time.perf_counter()
  if self.shared:dynamic,control=shared_core_inputs(state.position,self.c)
  else:dynamic=reference_features(self.c,state.position);control=localized_control_features(state.position,self.c)
  features=semantic_state_features(state.position,self.c,dynamic);self.feature_seconds+=time.perf_counter()-t;t=time.perf_counter();prediction=float(model.predict(features[None,:])[0]);self.predict_seconds+=time.perf_counter()-t;self.calls+=1;self.dimensions.add(len(features));assert len(features)==5145
  value=max(-90000000,min(90000000,(1 if state.position.side_to_move==0 else -1)*(round(prediction*256)+256*(control[0]-control[-1]))))
  self.trace.update(json.dumps([state.ply_count,dynamic,control,value]).encode());return value
 def type_value(self,t):return 0
 def capture_order_value(self,m,captured):return 0
rows=[];queries_start=time.perf_counter()
for z,c,s in live:
 before=record_value(s.state)
 for rep in(0,1):
  for arm in ('separate','shared')if rep==0 else('shared','separate'):
   stopped();assert time.perf_counter()-queries_start<120;assert len(rows)<8
   t=time.perf_counter();ev=Manual(c,arm=='shared');player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
   result=player.choose_action(s,SearchLimits(max_depth=1,max_nodes=z['node_forecast'],max_time_seconds=6,quiescence_max_depth=0,quiescence_hard_max_depth=0));returned=time.perf_counter();value=record_value(result);json.dumps(value);ready=time.perf_counter();assert record_value(s.state)==before;assert result.action is None or result.action in s.legal_actions()
   state=s.state;edges=[]
   for action in result.principal_variation:
    state=apply_action(state,action,c);edges.append({'action':record_value(action),'state':record_value(state)})
   row={'seed':z['seed'],'rep':rep,'arm':arm,'result':value,'caller_seconds':returned-t,'ready_seconds':ready-t,'callback_calls':ev.calls,'dimensions':sorted(ev.dimensions),'feature_seconds':ev.feature_seconds,'prediction_seconds':ev.predict_seconds,'trace_sha256':ev.trace.hexdigest(),'pv_edges':edges,'root_unchanged':True};rows.append(row)
   with(P/'queries.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps(row)+'\n')
   save('results.json',{'complete':False,'roots':roots,'rows':rows,'query_seconds':time.perf_counter()-queries_start,'whole_seconds':time.perf_counter()-start})
   print(z['seed'],arm,rep,result.completed_depth,result.termination_reason,round(row['ready_seconds'],3),ev.calls,flush=True)
save('results.json',{'complete':True,'roots':roots,'rows':rows,'query_seconds':time.perf_counter()-queries_start,'whole_seconds':time.perf_counter()-start})
