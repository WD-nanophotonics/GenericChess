from pathlib import Path
from dataclasses import replace
import sys,json,time,math,hashlib
R=Path.cwd();P=R/'.local_agent/core-forecast-20261017';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/consumer-isolation-20261017/Core-shared-input')]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.session.record import GameRecord
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
def decode_action(z):
 if "from_square"in z:return SemanticBoardMove(z["pattern_id"],z["geometry_id"],z["actor_type_id"],Square(**z["from_square"]),Square(**z["to_square"]),z["promotion_target_id"])
 return SemanticDropMove(z["pattern_id"],z["geometry_id"],z["base_type_id"],Square(**z["to_square"]))
def decode_record(z):
 assert z["declaration"]is None and z["resigned_by"]is None
 return GameRecord(z["schema_version"],z["ruleset_fingerprint"],tuple(decode_action(a)for a in z["actions"]),None,initial_setup_key=z["initial_setup_key"])
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.learning.features import localized_control_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.native import SemanticSearchEngine
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from test_native_dynamic_feature_views import reference_features
from shared_core_inputs import shared_core_inputs
from scripts.research_record import record_value
# Reader may enumerate transitions and evaluate fixed formulas; no search/training.
def forbidden(*a,**k):raise AssertionError('reader cannot search')
AlphaBetaPlayer.choose_action=forbidden;SemanticSearchEngine.search=forbidden

from copy import copy
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.native.mirror import expected_snapshot
from generic_chess.core.identity import position_identity_key
from generic_chess.native import SemanticSearchEngine
start=time.perf_counter();checks=[];refusals=[]
forecast=json.loads((P/'forecast.json').read_bytes());d2=json.loads((P/'D2/forecast.json').read_bytes());children=json.loads((P/'independent-children.json').read_bytes())
model=forecast['checkpoint']['compact_nonlinear']
def compare(current,n,expected_dynamic=None,expected_control=None):
 packed=pack_semantic_search_position(current.compiled,n,current);raw=sem.snapshot(n,packed);wanted=expected_snapshot(current.state.position,n,current.compiled)
 for key in('board','hands','aux_state','side'):assert record_value(raw[key])==record_value(wanted[key]),key
 assert raw['ply']==current.state.ply_count and raw['history_exact']and raw['history_events_exact']
 assert [''.join(f'{v:016x}'for v in row)for row in raw['history']]==[str(position_identity_key(w,current.compiled))for w in current._search_witnesses]
 assert raw['history_events']==tuple((255 if h.actor<0 else h.actor,bool(h.gave_check))for h in current.state.history)
 assert sem.terminal_status(n,packed)=={'status':current.state.terminal_status.status.value,'winner':current.state.terminal_status.winner}
 dyn=sem.dynamic_features(n,packed);control=sem.spatial_features(n,packed)['localized_control']
 if expected_dynamic is not None:assert list(dyn)==expected_dynamic
 if expected_control is not None:assert list(control)==expected_control
 return {'ply':current.state.ply_count,'history_length':len(raw['history']),'dynamic':dyn,'control':control,'native_snapshot_sha256':hashlib.sha256(json.dumps(record_value(raw),sort_keys=True).encode()).hexdigest()}
for z in forecast['roots']+d2['roots']:
 x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);current=GameSession.replay(c,decode_record(z['record']));n=compile_native_semantic_rules(c);assert record_value(current.state)==z['state'];before=record_value(current.state)
 checks.append({'seed':z['seed'],'label':'root',**compare(current,n,z['dynamic'],z['control'])})
 # Constructor refusal is explicit, no Native search requested or fallback claimed.
 try:SemanticSearchEngine(c,n,board_values={t:0 for t in n.type_ids},hand_values={t:0 for t in n.type_ids},dynamic_values=(0,0,0),localized_control_values=(256,0,0,0,0,0,0,0,-256),compact_values=model,tt_megabytes=0)
 except ValueError as e:
  assert 'input' in str(e).lower()or'4096'in str(e);refusals.append({'seed':z['seed'],'exception':type(e).__name__,'message':str(e),'search_executed':False})
 else:raise AssertionError('Expected existing input cap refusal, no silent truncation')
 if z['seed']in(132601,132602):
  detail=next(x for x in children['roots']if x['seed']==z['seed'])
  for item in detail['children']:
   child=copy(current);child.submit(decode_action(item['action']));assert record_value(child.state)==item['state'];checks.append({'seed':z['seed'],'action':item['action'],**compare(child,n,item['dynamic'],item['control'])})
 assert record_value(current.state)==before
 print(z['seed'],'fullNativeCorecontrols',len(checks),'refusals',len(refusals),flush=True)
(P/'native-input-state-checks.json').write_bytes(json.dumps({'checks':checks,'constructor_refusals':refusals,'search_calls':0,'seconds':time.perf_counter()-start,'scope':'Actual completehistories, current/base/promotedboard, basehands,aux,side,terminal and3/9vectorsatprefix8/9 only. Notall-domain/genericboundaryequivalence; noNativecompactquery/truncation/autofallback.'},indent=2).encode())
