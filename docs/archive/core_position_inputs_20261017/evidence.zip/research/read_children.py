from pathlib import Path
from dataclasses import replace
import sys,json,time,math,hashlib
R=Path.cwd();P=R/'.local_agent/core-forecast-20261017';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/consumer-isolation-20261017/Core-shared-input')]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.session.record import GameRecord
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
def decode_action(z):
 if "from_square"in z:return SemanticBoardMove(z["pattern_id"],z["geometry_id"],z["actor_type_id"],Square(**z["from_square"]),Square(**z["to_square"]),z["promotion_target_id"])
 return SemanticDropMove(z["pattern_id"],z["geometry_id"],z["base_type_id"],Square(**z["to_square"]))
def decode_record(z):
 assert z["declaration"]is None and z["resigned_by"]is None
 return GameRecord(z["schema_version"],z["ruleset_fingerprint"],tuple(decode_action(a)for a in z["actions"]),None,initial_setup_key=z["initial_setup_key"])
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.learning.features import localized_control_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.native import SemanticSearchEngine
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from test_native_dynamic_feature_views import reference_features
from shared_core_inputs import shared_core_inputs
from scripts.research_record import record_value
# Reader may enumerate transitions and evaluate fixed formulas; no search/training.
def forbidden(*a,**k):raise AssertionError('reader cannot search')
AlphaBetaPlayer.choose_action=forbidden;SemanticSearchEngine.search=forbidden
forecast=json.loads((P/'forecast.json').read_bytes());results=json.loads((P/'results.json').read_bytes());start=time.perf_counter();roots=[]
for src in forecast['roots']:
 x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(src['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,decode_record(src['record']));(P/('canonical-record-'+str(src['seed'])+'.json')).write_text(serialize_game_record(s.to_record()),encoding='utf8');assert record_value(s.state)==src['state'];assert record_value(s._search_witnesses)==src['witnesses'];engine=semantic_engine_for(c);children=[];before=record_value(s.state)
 for action in sorted(s.legal_actions(),key=str):
  t=time.perf_counter();child=apply_action(s.state,action,c);dynamic=reference_features(c,child.position);control=localized_control_features(child.position,c);assert shared_core_inputs(child.position,c)==(dynamic,control);features=semantic_state_features(child.position,c,dynamic);assert len(features)==5145
  # The unchanged manual model is bias2 + .125*tanh(.01*mobility), owner0.
  prediction=2+.125*math.tanh(.01*dynamic[0]);static=(1 if child.position.side_to_move==0 else -1)*(round(prediction*256)+256*(control[0]-control[-1]));static=max(-10000000,min(10000000,max(-90000000,min(90000000,static))))
  checked=engine.in_check(child.position,child.position.side_to_move)
  if child.terminal_status.winner is not None:
   leaf=(1000000000-1)if child.terminal_status.winner==child.position.side_to_move else(-1000000000+1)
  elif child.terminal_status.is_terminal:leaf=0
  else:leaf=static
  children.append({'action':record_value(action),'state':record_value(child),'dynamic':dynamic,'control':control,'dimension':len(features),'prediction':prediction,'leaf_side_score':leaf,'root_score':-leaf,'in_check':checked,'seconds':time.perf_counter()-t})
 assert record_value(s.state)==before;assert len(children)==src['root_degree']
 best=max(z['root_score']for z in children);best_actions=[z['action']for z in children if z['root_score']==best];records=[z for z in results['rows']if z['seed']==src['seed']]
 for r in records:
  assert r['result']['completed_depth']==1 and r['result']['score']==best
  assert r['result']['action']in best_actions
  assert len(r['pv_edges'])==1
  match=next(z for z in children if z['action']==r['pv_edges'][0]['action']);assert match['state']==r['pv_edges'][0]['state']
  assert r['callback_calls']==len(children)
 roots.append({'seed':src['seed'],'children':children,'score':best,'argmax':best_actions,'query_receipts':len(records),'checked_children':sum(z['in_check']for z in children)})
 print(src['seed'],'verifiedchildren',len(children),'best',best,'ties',len(best_actions),flush=True)
(P/'independent-children.json').write_bytes(json.dumps({'roots':roots,'seconds':time.perf_counter()-start,'scope':'q0 directly evaluates checked leaves unless check-only opted in; reader initial assumption corrected, no product defect. No search/training rerun. Complete Coreapply_action fullhistory+bothinputdefinitions+knownmanualfiniteD1 formula; sharesrule/compilerwithproducer, notindependentrulesimplementation/optimalWDL.'},indent=2).encode())
print('READER seconds',time.perf_counter()-start)
