from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/core-forecast-20261017';D=P/'Native-position-input';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/consumer-isolation-20261017/Core-shared-input')]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from generic_chess.learning.nonlinear import CompactNonlinearResidual,semantic_state_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,runtime_state
from scripts.research_record import record_value
from shared_core_inputs import shared_core_inputs
sys.path.insert(0,str(D))
from native_position_inputs import native_position_inputs
class Manual:
 def __init__(self,c,n,model,native,dim):self.c=c;self.n=n;self.model=model;self.native=native;self.dim=dim;self.calls=0;self.dimensions=set();self.feature_seconds=0.;self.predict_seconds=0.;self.trace=hashlib.sha256()
 def evaluate(self,state):
  t=time.perf_counter()
  if self.native:
   dynamic,control=native_position_inputs(state.position,self.c,self.n)
  else:dynamic,control=shared_core_inputs(state.position,self.c)
  features=semantic_state_features(state.position,self.c,dynamic);self.feature_seconds+=time.perf_counter()-t;t=time.perf_counter();prediction=float(self.model.predict(features[None,:])[0]);self.predict_seconds+=time.perf_counter()-t;self.calls+=1;self.dimensions.add(len(features));assert len(features)==self.dim
  value=max(-90000000,min(90000000,(1 if state.position.side_to_move==0 else -1)*(round(prediction*256)+256*(control[0]-control[-1]))));self.trace.update(json.dumps([state.ply_count,dynamic,control,value]).encode());return value
 def type_value(self,t):return 0
 def capture_order_value(self,m,captured):return 0


from test_native_q_history_deferral import cycle
from test_native_pending_continuation import session_after
from generic_chess.core.transition import apply_action

from test_native_q_history_deferral import cycle
from test_native_pending_continuation import session_after
import statistics
forecast=json.loads((D/'transfer-forecast.json').read_bytes());rows=[];start=time.perf_counter();summary=[]
for z in forecast['roots']:
 if not z['eligible']:continue
 if z['ruleset']is not None:
  x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)
 else:c=(cycle(max_ply=2048,repetition=10000,prefix=0)if z['name'].startswith('actualcycle')else session_after(())).compiled
 s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));n=compile_native_semantic_rules(c);model=CompactNonlinearResidual.from_dict(z['model']);model._prediction_arrays;local=[]
 for rep in range(20):
  t=time.perf_counter();packed=sem.pack_current_position(n,s.state.position,ply_count=0);p=time.perf_counter()-t
  if rep%2==0:
   t=time.perf_counter();dynamic=sem.dynamic_features(n,packed);d=time.perf_counter()-t;t=time.perf_counter();control=sem.spatial_features(n,packed)['localized_control'];lc=time.perf_counter()-t
  else:
   t=time.perf_counter();control=sem.spatial_features(n,packed)['localized_control'];lc=time.perf_counter()-t;t=time.perf_counter();dynamic=sem.dynamic_features(n,packed);d=time.perf_counter()-t
  t=time.perf_counter();features=semantic_state_features(s.state.position,c,dynamic);e=time.perf_counter()-t;t=time.perf_counter();pred=float(model.predict(features[None,:])[0]);pr=time.perf_counter()-t;assert len(features)==z['dimension'];assert abs(pred-(2+.125*__import__('math').tanh(.01*dynamic[0])))<1e-12
  row={'name':z['name'],'rep':rep,'pack':p,'dynamic':d,'localized_control':lc,'dense_encode':e,'predict':pr,'dimension':len(features),'prediction':pred};rows.append(row);local.append(row)
 med={key:statistics.median(r[key]for r in local)for key in('pack','dynamic','localized_control','dense_encode','predict')};total=sum(med.values());summary.append({'name':z['name'],'medians':med,'total_median_components':total,'packing_share':med['pack']/total,'prediction_share':med['predict']/total})
aggregate=sum(z['medians']['pack']for z in summary)/sum(z['total_median_components']for z in summary)
(D/'component-results.json').write_bytes(json.dumps({'rows':rows,'summary':summary,'aggregate_packing_share':aggregate,'seconds':time.perf_counter()-start,'direct_predictions':len(rows),'player_queries':0,'decision':'CONSIDERexistingpayloadreuse'if aggregate>=.1 else'DEFERpackingengineering'},indent=2).encode());print(json.dumps({'summary':summary,'aggregate_packing_share':aggregate,'predictions':len(rows)},indent=2))
