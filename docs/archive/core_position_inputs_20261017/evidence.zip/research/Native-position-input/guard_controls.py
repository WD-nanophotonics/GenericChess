from pathlib import Path
from dataclasses import replace
import sys,json,time,math,hashlib
R=Path.cwd();P=R/'.local_agent/core-forecast-20261017';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/consumer-isolation-20261017/Core-shared-input')]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.session.record import GameRecord
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
def decode_action(z):
 if "from_square"in z:return SemanticBoardMove(z["pattern_id"],z["geometry_id"],z["actor_type_id"],Square(**z["from_square"]),Square(**z["to_square"]),z["promotion_target_id"])
 return SemanticDropMove(z["pattern_id"],z["geometry_id"],z["base_type_id"],Square(**z["to_square"]))
def decode_record(z):
 assert z["declaration"]is None and z["resigned_by"]is None
 return GameRecord(z["schema_version"],z["ruleset_fingerprint"],tuple(decode_action(a)for a in z["actions"]),None,initial_setup_key=z["initial_setup_key"])
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.learning.features import localized_control_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.native import SemanticSearchEngine
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from test_native_dynamic_feature_views import reference_features
from shared_core_inputs import shared_core_inputs
from scripts.research_record import record_value
# Reader may enumerate transitions and evaluate fixed formulas; no search/training.
def forbidden(*a,**k):raise AssertionError('reader cannot search')
AlphaBetaPlayer.choose_action=forbidden;SemanticSearchEngine.search=forbidden

from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from test_native_dynamic_feature_views import S4_CASES
from generic_chess.rules.compiler import compile_semantic_ruleset
from test_native_pending_continuation import session_after

sys.path.insert(0,str(P/'Native-position-input'))
from native_position_inputs import native_position_inputs
D=P/'Native-position-input';rows=[];start=time.perf_counter()
for builder,position_for in S4_CASES:
 for horizon in(1,2,3):
  c=compile_semantic_ruleset(replace(builder(),max_ply=horizon));n=compile_native_semantic_rules(c)
  for owner in(0,1):
   position=replace(position_for(c.support),side_to_move=owner);wanted=(reference_features(c,position),localized_control_features(position,c));packed=sem.pack_current_position(n,position,ply_count=0)
   try:got=native_position_inputs(position,c,n);error=None
   except Exception as e:got=None;error=type(e).__name__+':'+str(e);assert horizon==1 and isinstance(e,NotImplementedError)
   assert (horizon==1 and got is None)or got==wanted
   row={'fixture':builder.__name__,'horizon':horizon,'owner':owner,'position':record_value(position),'core':wanted,'NativePosition_ply0':got,'error':error,'matches':got==wanted};rows.append(row);print(builder.__name__,horizon,owner,got==wanted,error,flush=True)
   (D/'guard-controls.json').write_bytes(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start},indent=2).encode())
(D/'guard-controls.json').write_bytes(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start,'mismatches':sum(not x['matches']for x in rows),'player_calls':0},indent=2).encode())
