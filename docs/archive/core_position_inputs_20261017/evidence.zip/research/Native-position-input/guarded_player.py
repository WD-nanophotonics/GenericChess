from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/core-forecast-20261017';D=P/'Native-position-input';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/consumer-isolation-20261017/Core-shared-input')]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from generic_chess.learning.nonlinear import CompactNonlinearResidual,semantic_state_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,runtime_state
from scripts.research_record import record_value
from shared_core_inputs import shared_core_inputs
sys.path.insert(0,str(D))
from native_position_inputs import native_position_inputs
class Manual:
 def __init__(self,c,n,model,native,dim):self.c=c;self.n=n;self.model=model;self.native=native;self.dim=dim;self.calls=0;self.dimensions=set();self.feature_seconds=0.;self.predict_seconds=0.;self.trace=hashlib.sha256()
 def evaluate(self,state):
  t=time.perf_counter()
  if self.native:
   dynamic,control=native_position_inputs(state.position,self.c,self.n)
  else:dynamic,control=shared_core_inputs(state.position,self.c)
  features=semantic_state_features(state.position,self.c,dynamic);self.feature_seconds+=time.perf_counter()-t;t=time.perf_counter();prediction=float(self.model.predict(features[None,:])[0]);self.predict_seconds+=time.perf_counter()-t;self.calls+=1;self.dimensions.add(len(features));assert len(features)==self.dim
  value=max(-90000000,min(90000000,(1 if state.position.side_to_move==0 else -1)*(round(prediction*256)+256*(control[0]-control[-1]))));self.trace.update(json.dumps([state.ply_count,dynamic,control,value]).encode());return value
 def type_value(self,t):return 0
 def capture_order_value(self,m,captured):return 0


from test_native_q_history_deferral import cycle
from test_native_pending_continuation import session_after
from generic_chess.core.transition import apply_action
forecast=json.loads((D/'transfer-forecast.json').read_bytes());original=json.loads((D/'transfer-results.json').read_bytes());rows=[];start=time.perf_counter()
for name in('138601','actualPENDINGprefix3','actualcycleprefix1025max2048repeat10000'):
 z=next(x for x in forecast['roots']if x['name']==name)
 if z['ruleset']is not None:
  x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)
 else:c=(cycle(max_ply=2048,repetition=10000,prefix=0)if name.startswith('actualcycle')else session_after(())).compiled
 s=GameSession.replay(c,deserialize_game_record(json.dumps(z['record'])));assert record_value(s.state)==z['state'];n=compile_native_semantic_rules(c);model=CompactNonlinearResidual.from_dict(z['model']);model._prediction_arrays;ev=Manual(c,n,model,True,z['dimension']);before=s.state;witnesses=s._search_witnesses;player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();r=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=z['nodes'],max_time_seconds=z['seconds'],quiescence_max_depth=0,quiescence_hard_max_depth=0));value=record_value(r);json.dumps(value);ready=time.perf_counter();prior=next(x for x in original['rows']if x['name']==name and x['arm']=='NativePosition_ply0')
 def nonclock(d):return {k:v for k,v in d.items()if 'seconds'not in k and not k.startswith('time_to_')}
 assert nonclock(value)==nonclock(prior['result'])and ev.trace.hexdigest()==prior['trace_sha256'];assert s.state is before and s._search_witnesses is witnesses
 state=s.state;edges=[]
 for a in r.principal_variation:state=apply_action(state,a,c);edges.append({'action':record_value(a),'state':record_value(state)})
 assert edges==prior['pv_edges'];row={'name':name,'result':value,'ready_seconds':ready-t,'trace_sha256':ev.trace.hexdigest(),'callback_calls':ev.calls,'pv_edges':edges,'same_nonclock_trace_and_fullPV_as_original':True,'guard_source_sha256':hashlib.sha256((D/'native_position_inputs.py').read_bytes()).hexdigest()};rows.append(row);(D/'guarded-player-results.json').write_bytes(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start},indent=2).encode());print(name,r.completed_depth,r.termination_reason,round(ready-t,3),flush=True)
(D/'guarded-player-results.json').write_bytes(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start},indent=2).encode())
