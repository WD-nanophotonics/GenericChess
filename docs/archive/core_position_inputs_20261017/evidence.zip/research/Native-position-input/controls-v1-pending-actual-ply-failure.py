from pathlib import Path
from dataclasses import replace
import sys,json,time,math,hashlib
R=Path.cwd();P=R/'.local_agent/core-forecast-20261017';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/consumer-isolation-20261017/Core-shared-input')]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.session.record import GameRecord
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
def decode_action(z):
 if "from_square"in z:return SemanticBoardMove(z["pattern_id"],z["geometry_id"],z["actor_type_id"],Square(**z["from_square"]),Square(**z["to_square"]),z["promotion_target_id"])
 return SemanticDropMove(z["pattern_id"],z["geometry_id"],z["base_type_id"],Square(**z["to_square"]))
def decode_record(z):
 assert z["declaration"]is None and z["resigned_by"]is None
 return GameRecord(z["schema_version"],z["ruleset_fingerprint"],tuple(decode_action(a)for a in z["actions"]),None,initial_setup_key=z["initial_setup_key"])
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.learning.nonlinear import semantic_state_features
from generic_chess.learning.features import localized_control_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.native import SemanticSearchEngine
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from test_native_dynamic_feature_views import reference_features
from shared_core_inputs import shared_core_inputs
from scripts.research_record import record_value
# Reader may enumerate transitions and evaluate fixed formulas; no search/training.
def forbidden(*a,**k):raise AssertionError('reader cannot search')
AlphaBetaPlayer.choose_action=forbidden;SemanticSearchEngine.search=forbidden

from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from test_native_dynamic_feature_views import S4_CASES
from generic_chess.rules.compiler import compile_semantic_ruleset
from test_native_pending_continuation import session_after
D=P/'Native-position-input';positions=[]
for folder in(P,P/'D2'):
 for z in json.loads((folder/'forecast.json').read_bytes())['roots']:
  x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(z['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,decode_record(z['record']));positions.append(('actual:'+str(z['seed']),c,s.state.position,s.state.ply_count))
for moves in(('e2e4','d7d5','f1b5'),('e2e4','d7d5','f1b5','c7c6')):
 s=session_after(moves);positions.append(('PENDING:'+str(len(moves)),s.compiled,s.state.position,s.state.ply_count))
for builder,position_for in S4_CASES:
 c=compile_semantic_ruleset(builder())
 for owner in(0,1):positions.append((builder.__name__+':'+str(owner),c,replace(position_for(c.support),side_to_move=owner),0))
rows=[];start=time.perf_counter()
for name,c,position,ply in positions:
 t=time.perf_counter();wanted=(reference_features(c,position),localized_control_features(position,c));core_seconds=time.perf_counter()-t;n=compile_native_semantic_rules(c);t=time.perf_counter();packed=sem.pack_current_position(n,position,ply_count=0);got=(sem.dynamic_features(n,packed),sem.spatial_features(n,packed)['localized_control']);native_seconds=time.perf_counter()-t
 actual=sem.pack_current_position(n,position,ply_count=ply);actual_vectors=(sem.dynamic_features(n,actual),sem.spatial_features(n,actual)['localized_control'])
 row={'name':name,'position':record_value(position),'actual_ply':ply,'core':wanted,'native_Position_ply0':got,'native_actual_ply':actual_vectors,'matches_core':wanted==got,'actual_ply_matches_core':actual_vectors==wanted,'core_seconds':core_seconds,'native_Position_seconds':native_seconds};rows.append(row)
 (D/'controls.json').write_bytes(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start},indent=2).encode());print(name,wanted==got,actual_vectors==wanted,flush=True)
(D/'controls.json').write_bytes(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start,'decision':'PASSscopedPositiondefinitiononly'if all(x['matches_core']for x in rows)else'REJECTmismatchingroute','player_queries':0},indent=2).encode())
