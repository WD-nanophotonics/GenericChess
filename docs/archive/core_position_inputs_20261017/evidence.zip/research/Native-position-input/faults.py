from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/core-forecast-20261017';D=P/'Native-position-input';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(R/'.local_agent/consumer-isolation-20261017/Core-shared-input')]
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as sem
from generic_chess.learning.nonlinear import CompactNonlinearResidual,semantic_state_features
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,runtime_state
from scripts.research_record import record_value
from shared_core_inputs import shared_core_inputs
class Manual:
 def __init__(self,c,n,model,native,dim):self.c=c;self.n=n;self.model=model;self.native=native;self.dim=dim;self.calls=0;self.dimensions=set();self.feature_seconds=0.;self.predict_seconds=0.;self.trace=hashlib.sha256()
 def evaluate(self,state):
  t=time.perf_counter()
  if self.native:
   packed=sem.pack_current_position(self.n,state.position,ply_count=0);dynamic=sem.dynamic_features(self.n,packed);control=sem.spatial_features(self.n,packed)['localized_control']
  else:dynamic,control=shared_core_inputs(state.position,self.c)
  features=semantic_state_features(state.position,self.c,dynamic);self.feature_seconds+=time.perf_counter()-t;t=time.perf_counter();prediction=float(self.model.predict(features[None,:])[0]);self.predict_seconds+=time.perf_counter()-t;self.calls+=1;self.dimensions.add(len(features));assert len(features)==self.dim
  value=max(-90000000,min(90000000,(1 if state.position.side_to_move==0 else -1)*(round(prediction*256)+256*(control[0]-control[-1]))));self.trace.update(json.dumps([state.ply_count,dynamic,control,value]).encode());return value
 def type_value(self,t):return 0
 def capture_order_value(self,m,captured):return 0

forecast=json.loads((D/'transfer-forecast.json').read_bytes());src=next(x for x in forecast['roots']if x['name']=='137801');x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(src['ruleset'])));c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,deserialize_game_record(json.dumps(src['record'])));n=compile_native_semantic_rules(c);model=CompactNonlinearResidual.from_dict(src['model']);model._prediction_arrays
wrong=next(x for x in forecast['roots']if x['name']=='138201');x=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(wrong['ruleset'])));bad=compile_native_semantic_rules(SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support))
original_dynamic=sem.dynamic_features;original_spatial=sem.spatial_features;original_attach=SearchPathRuntime.attach_stats;original_clock=time.monotonic
rows=[];start=time.perf_counter();root=s.state;witnesses=s._search_witnesses
for case in json.loads((D/'fault-plan.json').read_bytes())['cases']:
 captured=[];calls={'dynamic':0,'spatial':0};token=CancellationToken();shift=[False]
 def attach(rt,stats):
  value=original_attach(rt,stats);captured.append((rt,runtime_state(rt)));return value
 def dynamic(*args,**kwargs):
  value=original_dynamic(*args,**kwargs);calls['dynamic']+=1
  if case=='dynamic_error_first':raise RuntimeError('injectedobservedNative3failure')
  if case=='cancel_after_dynamic':token.cancel()
  if case=='deadline_after_dynamic':shift[0]=True
  return value
 def spatial(*args,**kwargs):
  value=original_spatial(*args,**kwargs);calls['spatial']+=1
  if case=='spatial_error_third'and calls['spatial']==3:raise RuntimeError('injectedobservedNative9failure')
  return value
 sem.dynamic_features=dynamic;sem.spatial_features=spatial;SearchPathRuntime.attach_stats=attach
 if case=='deadline_after_dynamic':time.monotonic=lambda:original_clock()+(100 if shift[0]else 0)
 try:
  ev=Manual(c,bad if case=='wrong_rules_fingerprint'else n,model,True,src['dimension']);player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));limits=SearchLimits(max_depth=2,max_nodes=3 if case=='node_limit_3'else 1024,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0)
  try:
   result=player.choose_action(s,limits,cancel_token=token);out={'result':record_value(result)}
   expected={'cancel_after_dynamic':'cancelled','deadline_after_dynamic':'time_limit','node_limit_3':'node_limit'}[case];assert result.termination_reason==expected
   assert result.action is None or result.action in s.legal_actions()
  except (RuntimeError,ValueError)as e:
   assert case in('dynamic_error_first','spatial_error_third','wrong_rules_fingerprint'),(case,str(e));out={'exception':type(e).__name__,'message':str(e)}
 finally:
  sem.dynamic_features=original_dynamic;sem.spatial_features=original_spatial;SearchPathRuntime.attach_stats=original_attach;time.monotonic=original_clock
 assert s.state is root and s._search_witnesses is witnesses
 assert len(captured)==1
 for rt,initial in captured:rt.assert_balanced();assert runtime_state(rt)==initial,case
 row={'case':case,'calls':calls,'root_and_witnesses_unchanged':True,'runtime_exact_balanced':True,'outcome':out,'fakeclock':case=='deadline_after_dynamic'};rows.append(row);print(case,out.get('exception',out.get('result',{}).get('termination_reason')),calls,flush=True)
 (D/'fault-results.json').write_bytes(json.dumps({'complete':False,'rows':rows,'seconds':time.perf_counter()-start},indent=2).encode())
(D/'fault-results.json').write_bytes(json.dumps({'complete':True,'rows':rows,'seconds':time.perf_counter()-start,'scope':'SixactualCoreplayerfault/interruptcontrols. Cgettersinvokedbeforeinjectedfailureexceptfingerprintguard. Fakeclockelapsednotperformance. Errorspropagate; abortedfallbacknotDRAW.'},indent=2).encode())
