"""Private research input provider; never a search/terminal authority or default."""
from generic_chess.native import semantic as sem

def native_position_inputs(position, compiled, native_rules):
    # Position-only Core features do not use rule ply. S4 can probe an S3 reply
    # after the first action; Native's reply executor still checks rule max_ply.
    # Preserve the observed max1 counterexamples rather than changing that rule.
    if compiled.support.max_ply < 2:
        raise NotImplementedError(
            'Native Position input provider requires rule max_ply >= 2; '
            'use the explicit full Core Position input path for this rule')
    packed = sem.pack_current_position(native_rules, position, ply_count=0)
    return (sem.dynamic_features(native_rules, packed),
            sem.spatial_features(native_rules, packed)['localized_control'])
