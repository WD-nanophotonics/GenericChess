from pathlib import Path
import sys,json,time,math
R=Path.cwd();sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')];P=R/'.local_agent/consumer-isolation-20261017'
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as sem
from generic_chess.learning.nonlinear import CompactNonlinearResidual,semantic_state_features
from test_native_dynamic_feature_views import reference_features
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value

from dataclasses import replace
import random,hashlib
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.learning.features import localized_control_features
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import position_identity_key
P=R/'.local_agent/core-forecast-20261017';old=R/'.local_agent/consumer-isolation-20261017'
sys.path.insert(0,str(old/'Core-shared-input'))
from shared_core_inputs import shared_core_inputs

import importlib.util,sysconfig
baseline_path=P/'capsule/source/generic_chess'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
spec=importlib.util.spec_from_file_location('getter_baseline._native_core',baseline_path);baseline_kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline_kernel)
sys.path.insert(0,str(P/'Native-position-input'))
from native_position_inputs import native_position_inputs

plan=json.loads((P/'getter-trial/fresh/transfer-plan.json').read_bytes());start=time.perf_counter()
def save(name,value):
 (P/name).write_bytes(json.dumps(value,indent=2).encode())
def stopped():
 for name in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
def adapt(rules):
 x=compile_legacy_ruleset_for_semantic_execution(rules)
 return SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)

from copy import copy,deepcopy
from generic_chess.session.serialization import serialize_game_record
from test_native_q_history_deferral import cycle
from test_native_pending_continuation import session_after
D=P/'getter-trial/fresh';rows=[];roots=[];live=[];model_source=json.loads((P/'forecast.json').read_bytes())['checkpoint']['compact_nonlinear'];allstart=time.perf_counter()
def emit(name,value):(D/name).write_bytes(json.dumps(value,indent=2).encode())
for spec in plan['families']+[{'control':name}for name in plan['session_controls']]:
 stopped();t=time.perf_counter();name=str(spec.get('seed',spec.get('control')))
 try:
  if 'seed'in spec:
   cfg=GeneratorConfig(seed=spec['seed'],board_size=spec['board'],setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32);game=generate_game(cfg);rules=replace(game.ruleset,max_ply=2048);c=adapt(rules);s=GameSession(c);rng=random.Random(spec['seed']+700000)
   for ply in range(8):
    if s.state.terminal_status.is_terminal:break
    actions=sorted(s.legal_actions(),key=repr)
    if not actions:break
    s.submit(rng.choice(actions))
   acquired=s.state.ply_count;seconds=60
  else:
   if spec['control']=='actualcycleprefix1025max2048repeat10000':s=cycle(max_ply=2048,repetition=10000,prefix=1025)
   else:s=session_after(('e2e4','d7d5','f1b5')+(('c7c6',)if spec['control'].endswith('4')else()))
   c=s.compiled;acquired=s.state.ply_count;seconds=6;rules=None
  n=compile_native_semantic_rules(c);legal=s.legal_actions();degree=len(legal);childdegrees=[]
  from generic_chess.core.movegen import legal_actions
  for a in legal:childdegrees.append(len(legal_actions(apply_action(s.state,a,c),c)))
  nodes=max(1024,2*(1+degree+sum(childdegrees)));dynamic,control=shared_core_inputs(s.state.position,c);features=semantic_state_features(s.state.position,c,dynamic);dim=len(features);dynamic_index=len(features)-3
  # Existingapproximation includesaux axes afterdynamic; deriveoffsetmechanically.
  metadata=c.support.type_metadata;base_ids=tuple(sorted(p.type_id for p in getattr(c._legacy_compiled,'piece_types',())))or tuple(sorted(metadata));dynamic_index=2*len(metadata)*len(s.state.position.board)+2*len(base_ids)+2
  m=deepcopy(model_source);m['input_mean']=[0.]*dim;m['input_scale']=[1.]*dim;m['hidden_weights']=[[0.]*dim for _ in range(16)];m['hidden_weights'][0][dynamic_index]=.01;m['hand_type_indices']=list(range(len(base_ids)))
  mt=time.perf_counter();model=CompactNonlinearResidual.from_dict(m);model._prediction_arrays;model_seconds=time.perf_counter()-mt
  pp=sem.pack_current_position(n,s.state.position,ply_count=0);assert (sem.dynamic_features(n,pp),sem.spatial_features(n,pp)['localized_control'])==(dynamic,control)
  record=json.loads(serialize_game_record(s.to_record()));z={'name':name,'spec':spec,'ruleset':json.loads(serialize_ruleset(rules))if rules is not None else None,'record':record,'state':record_value(s.state),'witnesses':record_value(s._search_witnesses),'degree':degree,'child_degrees':childdegrees,'nodes':nodes,'dimension':dim,'dynamic_index':dynamic_index,'model':m,'model_seconds':model_seconds,'seconds':seconds,'acquired_plies':acquired,'setup_seconds':time.perf_counter()-t,'eligible':not s.state.terminal_status.is_terminal and degree>0 and nodes<=200000 and ('seed'not in spec or acquired==8)};roots.append(z)
  if z['eligible']:live.append((z,c,s,n,model))
 except Exception as e:
  roots.append({'name':name,'spec':spec,'eligible':False,'failure':type(e).__name__+':'+str(e),'setup_seconds':time.perf_counter()-t});raise
emit('transfer-forecast.json',{'roots':roots,'preparation_seconds':time.perf_counter()-allstart,'queries_started':0})
print('FORECAST',[(z['name'],z['degree'],z['nodes'],z['dimension'],z['eligible'])for z in roots],flush=True)
class Manual:
 def __init__(self,c,n,model,native,dim):self.c=c;self.n=n;self.model=model;self.native=native;self.dim=dim;self.calls=0;self.dimensions=set();self.feature_seconds=0.;self.predict_seconds=0.;self.trace=hashlib.sha256()
 def evaluate(self,state):
  t=time.perf_counter()
  if self.native:
   dynamic,control=native_position_inputs(state.position,self.c,self.n)
  else:dynamic,control=shared_core_inputs(state.position,self.c)
  features=semantic_state_features(state.position,self.c,dynamic);self.feature_seconds+=time.perf_counter()-t;t=time.perf_counter();prediction=float(self.model.predict(features[None,:])[0]);self.predict_seconds+=time.perf_counter()-t;self.calls+=1;self.dimensions.add(len(features));assert len(features)==self.dim
  value=max(-90000000,min(90000000,(1 if state.position.side_to_move==0 else -1)*(round(prediction*256)+256*(control[0]-control[-1]))));self.trace.update(json.dumps([state.ply_count,dynamic,control,value]).encode());return value
 def type_value(self,t):return 0
 def capture_order_value(self,m,captured):return 0
qs=time.perf_counter()
for index,(z,c,s,n,model)in enumerate(live):
 before=record_value(s.state);witnesses=s._search_witnesses
 for arm in ('baseline_getter','candidate_getter')if index%2==0 else('candidate_getter','baseline_getter'):
  stopped();assert time.perf_counter()-qs<1200 and len(rows)<16;nn=compile_native_semantic_rules(c,backend_module=baseline_kernel)if arm=='baseline_getter'else n
  t=time.perf_counter();ev=Manual(c,nn,model,True,z['dimension']);player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));result=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=z['nodes'],max_time_seconds=z['seconds'],quiescence_max_depth=0,quiescence_hard_max_depth=0));returned=time.perf_counter();value=record_value(result);json.dumps(value);ready=time.perf_counter();assert record_value(s.state)==before and s._search_witnesses==witnesses;assert result.action is None or result.action in s.legal_actions();state=s.state;edges=[]
  for action in result.principal_variation:state=apply_action(state,action,c);edges.append({'action':record_value(action),'state':record_value(state)})
  row={'name':z['name'],'arm':arm,'result':value,'caller_seconds':returned-t,'ready_seconds':ready-t,'callback_calls':ev.calls,'dimensions':sorted(ev.dimensions),'feature_seconds':ev.feature_seconds,'prediction_seconds':ev.predict_seconds,'trace_sha256':ev.trace.hexdigest(),'pv_edges':edges,'root_unchanged':True,'history_length':len(s._search_witnesses)};rows.append(row)
  with(D/'transfer-queries.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps(row)+'\n')
  emit('transfer-results.json',{'complete':False,'rows':rows,'query_seconds':time.perf_counter()-qs,'whole_seconds':time.perf_counter()-allstart});print(z['name'],arm,result.completed_depth,result.termination_reason,round(row['ready_seconds'],3),ev.calls,flush=True)
emit('transfer-results.json',{'complete':True,'rows':rows,'query_seconds':time.perf_counter()-qs,'whole_seconds':time.perf_counter()-allstart})
