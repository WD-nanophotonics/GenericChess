"""Replay source-bound evidence without search, training, or old clock claims."""
from pathlib import Path
from dataclasses import fields,replace
from copy import copy
import sys,json,time,math,hashlib,collections
R=Path.cwd();B=Path(sys.argv[1]).resolve();P=B/'research';D=P/'Native-position-input';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product'),str(D),str(B/'helpers')]
from generic_chess import native
from generic_chess.native import semantic as sem,SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution,compile_semantic_ruleset
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.session.record import GameRecord
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.decision import PlayerDecision
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value
from test_native_dynamic_feature_views import reference_features,S4_CASES
from test_native_pending_continuation import session_after
from test_native_q_history_deferral import cycle
from generic_chess.learning.features import localized_control_features
from generic_chess.learning.nonlinear import semantic_state_features
from shared_core_inputs import shared_core_inputs
from native_position_inputs import native_position_inputs
assert Path(native._module().__file__).resolve().is_relative_to(R.resolve())
def forbidden(*args,**kwargs):raise AssertionError('Reader cannot search or train')
AlphaBetaPlayer.choose_action=forbidden;SemanticSearchEngine.search=forbidden
for name in('semantic_engine_search','semantic_fixed_depth_search','semantic_probe_search','semantic_iterative_search','semantic_root_parallel_search'):
 if hasattr(native._module(),name):setattr(native._module(),name,forbidden)
counts=collections.Counter();start=time.perf_counter()
def read(p):return json.loads(p.read_bytes())
def adapt(rules):
 x=compile_legacy_ruleset_for_semantic_execution(rules);return SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)
def action(z):
 if 'from_square'in z:return SemanticBoardMove(z['pattern_id'],z['geometry_id'],z['actor_type_id'],Square(**z['from_square']),Square(**z['to_square']),z['promotion_target_id'])
 return SemanticDropMove(z['pattern_id'],z['geometry_id'],z['base_type_id'],Square(**z['to_square']))
def original_record(z):
 if not z['actions']or'kind'in z['actions'][0]:return deserialize_game_record(json.dumps(z))
 assert z['declaration']is None and z['resigned_by']is None
 return GameRecord(z['schema_version'],z['ruleset_fingerprint'],tuple(action(a)for a in z['actions']),None,initial_setup_key=z['initial_setup_key'])
def restore(z):
 if z['ruleset']is not None:c=adapt(deserialize_ruleset(json.dumps(z['ruleset'])))
 else:c=(cycle(max_ply=2048,repetition=10000,prefix=0)if z['name'].startswith('actualcycle')else session_after(())).compiled
 s=GameSession.replay(c,original_record(z['record']));assert record_value(s.state)==z['state'];assert record_value(s._search_witnesses)==z['witnesses'];counts['root_records']+=1;return s
# Full-state Native transport checks have a separate role from Position-only inputs.
def full_state(s,n):
 if s.state.ply_count>1024:
  try:pack_semantic_search_position(s.compiled,n,s)
  except (ValueError,NotImplementedError)as e:
   assert 'history'in str(e).lower()or'ply'in str(e).lower();counts['explicit_long_history_import_refusals']+=1;return
  raise AssertionError('No history truncation allowed')
 p=pack_semantic_search_position(s.compiled,n,s);raw=sem.snapshot(n,p);wanted=expected_snapshot(s.state.position,n,s.compiled)
 for key in('board','hands','aux_state','side'):assert record_value(raw[key])==record_value(wanted[key])
 assert raw['ply']==s.state.ply_count and raw['history_exact']and raw['history_events_exact']
 assert [''.join(f'{v:016x}'for v in row)for row in raw['history']]==[str(position_identity_key(w,s.compiled))for w in s._search_witnesses]
 assert raw['history_events']==tuple((255 if h.actor<0 else h.actor,bool(h.gave_check))for h in s.state.history)
 assert sem.terminal_status(n,p)=={'status':s.state.terminal_status.status.value,'winner':s.state.terminal_status.winner};counts['full_Native_Core_states']+=1
instances={}
for group,folder in(('D1',P),('D2',P/'D2'),('transfer',D),('curve',D/'common-deadline'),('fresh',P/'getter-trial/fresh')):
 file='forecast.json'if group in('D1','D2')else'transfer-forecast.json'
 for z in read(folder/file)['roots']:
  if 'state'not in z:continue
  s=restore(z);key=z.get('name',z.get('seed'));n=compile_native_semantic_rules(s.compiled);instances[(group,str(key))]=(s,n,z);full_state(s,n)
  if not z['eligible']:counts['retained_terminal_tails']+=1
# Every saved D1 child, all history fields and the independently known formula.
for z in read(P/'independent-children.json')['roots']:
 s,n,_=instances[('D1',str(z['seed']))];scores=[]
 for row in z['children']:
  child=copy(s);child.submit(action(row['action']));assert record_value(child.state)==row['state'];full_state(child,n);dynamic=reference_features(s.compiled,child.state.position);control=localized_control_features(child.state.position,s.compiled);assert record_value((dynamic,control))==[row['dynamic'],row['control']];assert shared_core_inputs(child.state.position,s.compiled)==(dynamic,control);assert native_position_inputs(child.state.position,s.compiled,n)==(dynamic,control);f=semantic_state_features(child.state.position,s.compiled,dynamic);assert len(f)==5145
  pred=2+.125*math.tanh(.01*dynamic[0]);score=(1 if child.state.position.side_to_move==0 else -1)*(round(pred*256)+256*(control[0]-control[-1]));score=max(-10000000,min(10000000,score));assert not child.state.terminal_status.is_terminal;assert score==row['leaf_side_score'];scores.append(-score);counts['independent_D1_children']+=1
 assert max(scores)==z['score']
# All actual player result fields are preserved, including censored D1 and fallback.
keys={f.name for f in fields(PlayerDecision)}
for group,file in(('D1',P/'results.json'),('D2',P/'D2/results.json'),('transfer',D/'transfer-results.json'),('curve',D/'common-deadline/transfer-results.json'),('guarded',D/'guarded-player-results.json'),('getter',P/'getter-trial/results.json'),('fresh',P/'getter-trial/fresh/transfer-results.json')):
 for row in read(file)['rows']:
  key=str(row.get('name',row.get('seed')));s,n,z=instances[('transfer'if group in('guarded','getter')else group,key)];value=row['result'];assert set(value)==keys;assert value['action']is None or action(value['action'])in s.legal_actions();current=copy(s)
  for index,a in enumerate(value['principal_variation']):
   current.submit(action(a));assert record_value(current.state)==row['pv_edges'][index]['state'];full_state(current,n);counts['Core_PV_edges']+=1
  assert value['runtime_depth_balanced']and value['runtime_pushes']==value['runtime_pops'];counts['actual_query_receipts']+=1
  if value['termination_reason']=='time_limit':counts['retained_time_censors']+=1
# Saved actual guard/no-guard counterexamples, not changes to Native rule semantics.
for row in read(D/'short-horizon-results.json')['rows']:
 builder,pos=next((a,b)for a,b in S4_CASES if a.__name__==row['fixture']);c=compile_semantic_ruleset(replace(builder(),max_ply=row['horizon']));p=replace(pos(c.support),side_to_move=row['owner']);n=compile_native_semantic_rules(c);expected=(reference_features(c,p),localized_control_features(p,c));np=sem.pack_current_position(n,p,ply_count=0);got=(sem.dynamic_features(n,np),sem.spatial_features(n,np)['localized_control']);assert record_value(expected)==row['core']and record_value(got)==row['NativePosition_ply0'];assert (got==expected)==row['matches']
 try:guarded=native_position_inputs(p,c,n)
 except NotImplementedError:assert row['horizon']==1;counts['guarded_short_horizon_refusals']+=1
 else:assert guarded==expected;counts['guarded_S4_vectors']+=1
 if not row['matches']:counts['retained_original_counterexamples']+=1
for file in('fault-results.json','guarded-fault-results.json'):
 d=read(D/file);assert d['complete']and len(d['rows'])==6
 for row in d['rows']:
  assert row['root_and_witnesses_unchanged']and row['runtime_exact_balanced']
  if 'result'in row['outcome']:assert set(row['outcome']['result'])==keys
  counts['original_fault_receipts_not_rerun']+=1
print(json.dumps({'counts':dict(counts),'seconds':time.perf_counter()-start,'scope':'Search/training disabled. Fullstate/PV/Positiondefinitions andmanualD1formula checked from restoredsource; old clocks/minimaxD2/interruptions not rerun, no all-domain proof.'},indent=2))
