from pathlib import Path
import sys,json
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product')]
from tools.local_agent.common import write_json
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import RayAtom
from generic_chess.rules.schema import RuleDeclaration,RuleWeightedMaterialMetric,RuleDeclarationOutcomeBand
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.learning.selfplay import collect_self_play,SelfPlayConfig
from scripts.research_record import record_value
D=Path('.local_agent/spatial-snapshot-20261017');rows=[]
for outcome in('WIN','NO_CONTEST','RESTART'):
 rule=make_ruleset(4,[king_type(),T('R',RayAtom((0,1)),RayAtom((0,-1)),RayAtom((1,0)),RayAtom((-1,0)))],lines=['k...','....','....','..RK']);claim=RuleDeclaration(declaration_id='leaf_claim',owner=1,require_not_in_check=False,weighted_metric=RuleWeightedMaterialMetric(weights={'K':1}),outcome_bands=(RuleDeclarationOutcomeBand(1,outcome),));c=compile_legacy_ruleset_for_semantic_execution(replace(rule,declarations=(claim,)));n=compile_native_semantic_rules(c);s=GameSession(c);cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,board_weights={'R':1.},hand_weights={'R':1.},value_scale=10.,reference_median=1.)
 r=SemanticSearchEngine(c,n,checkpoint=cp,tt_megabytes=0).search(s,SearchLimits(max_depth=1,max_nodes=1000,quiescence_max_depth=0));full=GameSession(c)
 for step in r.decision_line:
  if isinstance(step,str):full.declare(step)
  else:full.submit(step)
 try:
  t,=collect_self_play(c,n,cp,SelfPlayConfig(games=1,nodes_per_move=1000,max_depth=1,max_plies=1,epsilon=0.,tt_megabytes=0));collected=dict(leaf_value=t.points[0].leaf_value,leaf_terminal_z=t.points[0].leaf_terminal_z,bootstrap=t.bootstrap_value,point_pv=record_value(t.points[0].pv))
 except Exception as e:collected=dict(error=repr(e))
 rows.append(dict(outcome=outcome,decision_line=record_value(r.decision_line),score=r.score,depth=r.completed_depth,full_actual_leaf_result=record_value(full.result),collected=collected))
write_json(D/'declaration-pv-probe.json',dict(status='COMPLETE',rows=rows,new_training=0,scope='RealNativeD1/fullGameSessiondecision_line versus currentcollector physicalPV, no stub/newlabels.'));print(json.dumps(rows,indent=2))
