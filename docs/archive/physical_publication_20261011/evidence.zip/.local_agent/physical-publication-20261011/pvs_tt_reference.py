import sys,json,time,importlib.util,collections
from pathlib import Path
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime as R
from scripts.research_record import record_value
from scripts.reserve_refresh_diagnostic import stopped
s=importlib.util.spec_from_file_location('weighted',Path('.local_agent/weighted-backend-20261011/bridge.py'));w=importlib.util.module_from_spec(s);s.loader.exec_module(w)
B=Path(__file__).parent;d=json.loads((B/'pvs-tt-reference-declaration.json').read_text(encoding='utf-8'));out={'complete':False,'cells':[]}
oldattach=R.attach_stats;oldfactory=pm.SearchStatistics

def actual(rt):return frozenset(collections.Counter((h,e.identity,int(e.count)) for h,b in rt._occurrences.items() for e in b).items())
def state(rt):return (rt.position,rt.ply_count,rt.terminal_status,rt.current_identity,rt.runtime_hash,rt._snapshot,tuple(rt.history),rt._history_context,actual(rt),frozenset(rt._opaque_imported_keys),frozenset(rt._history_aliases.items()))
def attach(rt,stats):
 value=oldattach(rt,stats);runtimes.append((rt,state(rt)));return value

def factory():
 v=SearchStatistics();captured.append(v);return v

try:
 R.attach_stats=attach;pm.SearchStatistics=factory
 for spec in d['cells']:
  case=next(x for x in CASES if x['id']==spec['root']);compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=CoreBoard(case,compiled);e=w.weighted(compiled,VALUES[case['game']]);cell={'spec':spec,'arms':[]};out['cells'].append(cell)
  for pvs in (False,True):
   stopped();runtimes=[];captured=[];session=SimpleNamespace(compiled=compiled,state=board.initial,_search_witnesses=board.witnesses)
   player=AlphaBetaPlayer(compiled,evaluator_override=e,use_disk_cache=False,use_tt=spec['tt'],use_ordering=spec['ordering'],tuning=SearchTuning(use_pvs=pvs,use_root_tactical=True));t=time.perf_counter()
   value=player.choose_action(session,SearchLimits(max_depth=spec['depth'],max_nodes=32768,max_time_seconds=60,quiescence_max_depth=spec['q'],quiescence_hard_max_depth=8));wall=time.perf_counter()-t
   assert session.state is board.initial and len(runtimes)==1 and len(captured)==1
   rt,root=runtimes[0];rt.assert_balanced();assert state(rt)==root
   arm={'pvs':pvs,'wall_observation':wall,'decision':record_value(value),'stats':record_value(captured[0]),'restored_actual_multiset':True};cell['arms'].append(arm)
   (B/'pvs-tt-reference-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(spec,'pvs',pvs,'depth',value.completed_depth,'score',value.score,'nodes',value.nodes+value.qnodes,'wall',wall,flush=True)
  a,b=cell['arms'];cell['both_complete']=all(x['decision']['completed_depth']==spec['depth'] for x in cell['arms']);cell['score_equal']=a['decision']['score']==b['decision']['score'];cell['action_equal']=a['decision']['action']==b['decision']['action'];cell['work_ratio']=(b['decision']['nodes']+b['decision']['qnodes'])/(a['decision']['nodes']+a['decision']['qnodes'])
 out['complete']=True;(B/'pvs-tt-reference-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
finally:R.attach_stats=oldattach;pm.SearchStatistics=oldfactory