import ast,json,time
from pathlib import Path
B=Path(__file__).parent
prefix=[]
for n in ast.parse((B/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(B/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reused declarations>', 'exec'),env)
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.cancellation import CancellationToken
old=sm.negamax;R=env['R'];pm=env['pm'];oldattach=R.attach_stats;oldfactory=pm.SearchStatistics
c=env['compile_ruleset_for_execution'](env['build_builtin_ruleset']('western_chess'));case=next(x for x in env['CASES'] if x['id']=='chess-ep');board=env['CoreBoard'](case,c);e=env['w'].weighted(c,env['VALUES']['chess']);out={'complete':False,'cells':[]}
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory']
 for tt in (False,True):
  env['stopped']();env['runtimes']=[];env['captured']=[];hits=[];token=CancellationToken()
  def wrapped(state,depth,alpha,beta,ply,ctx,*args,**kw):
   if ctx.stats.completed_depth==2 and ply==1 and not hits:
    hits.append(dict(depth=depth,ply=ply,runtime_depth=ctx.runtime.depth,alpha=alpha,beta=beta));token.cancel()
   return old(state,depth,alpha,beta,ply,ctx,*args,**kw)
  sm.negamax=wrapped
  session=env['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses);player=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=tt,tuning=env['SearchTuning'](use_aspiration=True,aspiration_start_depth=3,aspiration_delta=50));v=player.choose_action(session,env['SearchLimits'](max_depth=3,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token)
  rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and session.state is board.initial
  reference=next(x for x in json.loads((B/'aspiration-result.json').read_text())['cells'] if x['root']=='chess-ep' and x['tt']==tt)['arms'][0]['decision'];record=env['record_value'](v);assert len(hits)==1 and v.completed_depth==2 and v.score==8 and v.termination_reason=='cancelled' and record['action']==reference['action'];out['cells'].append(dict(tt=tt,actual_hits=hits,decision=record,stats=env['record_value'](env['captured'][0]),restored_actual_root=True));print(tt,'actualtarget',hits,'retainedD2',v.score,flush=True)
 out['complete']=True;(B/'aspiration-cancel-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
finally:sm.negamax=old;R.attach_stats=oldattach;pm.SearchStatistics=oldfactory