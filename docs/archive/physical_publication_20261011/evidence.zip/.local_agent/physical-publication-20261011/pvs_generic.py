import ast,json,time,sys
from pathlib import Path
B=Path(__file__).parent
prefix=[]
for n in ast.parse((B/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(B/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reusedprobe>', 'exec'),env)
sys.path[:0]=[str(Path.cwd()/'tests/product'),str(Path.cwd()/'.local_agent/availability-core-20261011')]
from semantic_profile_adapter import SearchSemanticCompiled
from test_f24c_mixed_mechanic_certification import _compiled
from test_f24c_mixed_mechanic_certification_r1 import _simultaneous,_state
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
R=env['R'];pm=env['pm'];oldattach=R.attach_stats;oldfactory=pm.SearchStatistics;d=json.loads((B/'pvs-generic-declaration.json').read_text());out={'complete':False,'cells':[]}
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory']
 for spec in d['cells']:
  src=_compiled() if spec['kind']=='mixed' else compile_legacy_ruleset_for_semantic_execution(generate_game(GeneratorConfig(seed=spec['seed'],board_size=spec['size'],setup_preset='bilateral_random',allow_hybrid=True)).ruleset)
  c=SearchSemanticCompiled(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support)
  if spec['kind']=='mixed':pos=_simultaneous(c);state=_state(c,pos)
  else:state=GameSession(c).state;pos=state.position
  cfg=EvaluationConfig();e=Evaluator(c,build_ruleset_profile(c,cfg),cfg);actions=legal_actions(state,c);cell={'spec':spec,'arms':[]};out['cells'].append(cell)
  for pvs in (False,True):
   env['stopped']();env['runtimes']=[];env['captured']=[];session=env['SimpleNamespace'](compiled=c,state=state,_search_witnesses=(pos,));player=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,tuning=env['SearchTuning'](use_pvs=pvs));v=player.choose_action(session,env['SearchLimits'](max_depth=4,max_nodes=512,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8));rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and session.state is state
   legal=v.action in actions if v.action is not None else bool(v.declaration or state.terminal_status.is_terminal);assert legal
   child=env['record_value'](apply_action(state,v.action,c)) if v.action is not None else None
   cell['arms'].append({'pvs':pvs,'decision':env['record_value'](v),'stats':env['record_value'](env['captured'][0]),'public_return_legal':True,'public_child':child,'restored_actual_multiset':True});print(spec,pvs,v.completed_depth,v.score,v.termination_reason,flush=True)
  a,b=cell['arms'];cell['same_depth_score_action']=all(a['decision'][key]==b['decision'][key] for key in ('completed_depth','score','action'))
  (B/'pvs-generic-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 out['complete']=True;(B/'pvs-generic-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
finally:R.attach_stats=oldattach;pm.SearchStatistics=oldfactory