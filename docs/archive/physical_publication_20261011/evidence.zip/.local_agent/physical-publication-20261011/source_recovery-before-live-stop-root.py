import subprocess,sys,zipfile,json,shutil,hashlib
from pathlib import Path
root=Path.cwd();B=root/'.local_agent/physical-publication-20261011';dest=B/'source-recovery';dest.mkdir(exist_ok=True)
# Tracked baseline, not current research docs or private state.
subprocess.run(['git','archive','--format=zip','--output',str(B/'source-baseline.zip'),'c87ed1f36497276eb966bb186c81baabaa897114','generic_chess','tests','scripts','docs/research/data/chess_zero_target_correction_20261005.json'],check=True)
with zipfile.ZipFile(B/'source-baseline.zip') as z:
 for n in z.namelist():
  if n.endswith('.py') or n=='docs/research/data/chess_zero_target_correction_20261005.json':
   p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
files=[B/'pvs_probe.py',root/'.local_agent/weighted-backend-20261011/bridge.py']
for p in files:
 target=dest/p.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
d={'cells':[{'root':'chess-promotion','depth':2,'q':1}],'scope':'New source-recovery cell, Core-only expected; original experimental declaration/results not overwritten.'}
(dest/'.local_agent/physical-publication-20261011/pvs-declaration.json').write_text(json.dumps(d),encoding='utf-8')
pre="import pathlib,generic_chess;from generic_chess.native import native_available;assert pathlib.Path(generic_chess.__file__).is_relative_to(pathlib.Path.cwd());assert not native_available();print('isolatedtrackedsource,Nativeabsent')"
p=subprocess.run([sys.executable,'-S','-c',pre],cwd=dest,capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr
site=str(root/'.venv/Lib/site-packages');code="import sys,runpy;sys.path.append("+repr(site)+");from generic_chess.native import native_available;assert not native_available();runpy.run_path('.local_agent/physical-publication-20261011/pvs_probe.py',run_name='__main__')"
p=subprocess.run([sys.executable,'-S','-c',code],cwd=dest,capture_output=True,text=True,timeout=60);assert p.returncode==0,p.stderr
r=json.loads((dest/'.local_agent/physical-publication-20261011/pvs-result.json').read_text());expected=json.loads((B/'pvs-result.json').read_text());old=next(x for x in expected['cells'] if x['spec']['root']=='chess-promotion');assert r['complete']
for a,b in zip(r['cells'][0]['arms'],old['arms']):
 for k in ('score','action','completed_depth'):assert a['decision'][k]==b['decision'][k]
 assert a['stats']['native_legality_calls']==0 and a['restored_actual_multiset']
shutil.copyfile(dest/'.local_agent/physical-publication-20261011/pvs-result.json',B/'source-recovery-result.json')
receipt={'complete':True,'base_sha':'c87ed1f36497276eb966bb186c81baabaa897114','new_scope':'Two actualtracked-source noTTlexicalD2/q1 promotion arms,Nativeabsent explicitlyconfirmed; originalmethod/publicresults retained, noCperformanceproof.', 'score_action_depth_matches_source':True,'returncode':p.returncode,'stdout':p.stdout,'native_absent_confirmed':True,'dependencies':[{'path':str(x.relative_to(root)).replace('\\','/'),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in files]};(B/'source-recovery-summary.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt,indent=2))