import ast,json,time
from pathlib import Path
B=Path(__file__).parent
prefix=[]
for n in ast.parse((B/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(B/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reused declarations>', 'exec'),env)
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.cancellation import CancellationToken
old=sm.negamax;R=env['R'];pm=env['pm'];oldattach=R.attach_stats;oldfactory=pm.SearchStatistics
c=env['compile_ruleset_for_execution'](env['build_builtin_ruleset']('western_chess'));case=next(x for x in env['CASES'] if x['id']=='chess-middle');board=env['CoreBoard'](case,c);e=env['w'].weighted(c,env['VALUES']['chess']);out={'complete':False,'cells':[]}
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory']
 for tt in (False,True):
  baseline=None
  for phase in ('baseline','null_window','full_research'):
   env['stopped']();env['runtimes']=[];env['captured']=[];hits=[];token=CancellationToken();d2_research_start=[None]
   def wrapped(state,depth,alpha,beta,ply,ctx,*args,**kw):
    pv=kw.get('pv_node',True)
    if ctx.stats.completed_depth==1:
     if d2_research_start[0] is None:d2_research_start[0]=ctx.stats.pvs_researches
     hit=(phase=='null_window' and not pv) or (phase=='full_research' and pv and ctx.stats.pvs_researches>d2_research_start[0])
     if hit and not hits:
      hits.append(dict(phase=phase,depth=depth,ply=ply,runtime_depth=ctx.runtime.depth,nulls=ctx.stats.pvs_null_window_searches,researches=ctx.stats.pvs_researches));token.cancel()
    return old(state,depth,alpha,beta,ply,ctx,*args,**kw)
   sm.negamax=old if phase=='baseline' else wrapped
   session=env['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses);player=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=tt,use_ordering=True,tuning=env['SearchTuning'](use_pvs=True,use_root_tactical=True));v=player.choose_action(session,env['SearchLimits'](max_depth=1 if phase=='baseline' else 2,max_nodes=32768,max_time_seconds=60,quiescence_max_depth=4,quiescence_hard_max_depth=8),cancel_token=token)
   rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and session.state is board.initial
   record=env['record_value'](v)
   if phase=='baseline':baseline=record
   else:assert len(hits)==1 and v.completed_depth==1 and record['action']==baseline['action'] and v.score==baseline['score'] and v.termination_reason=='cancelled'
   out['cells'].append(dict(tt=tt,phase=phase,actual_hits=hits,decision=record,stats=env['record_value'](env['captured'][0]),restored_actual_root=True));print(tt,phase,'hits',len(hits),v.termination_reason,flush=True)
 out['complete']=True;(B/'pvs-cancel-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
finally:sm.negamax=old;R.attach_stats=oldattach;pm.SearchStatistics=oldfactory