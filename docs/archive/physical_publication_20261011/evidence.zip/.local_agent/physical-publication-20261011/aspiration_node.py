import ast,json
from pathlib import Path
B=Path(__file__).parent;prefix=[]
for n in ast.parse((B/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(B/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reuse>', 'exec'),env)
d=json.loads((B/'aspiration-node-declaration.json').read_text());R=env['R'];pm=env['pm'];oa=R.attach_stats;of=pm.SearchStatistics;out={'complete':False,'cells':[]}
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory']
 for name in d['roots']:
  c=env['compile_ruleset_for_execution'](env['build_builtin_ruleset']('western_chess'));board=env['CoreBoard'](next(x for x in env['CASES'] if x['id']==name),c);e=env['w'].weighted(c,env['VALUES']['chess'])
  for tt in d['tt']:
   cell={'root':name,'tt':tt,'arms':[]};out['cells'].append(cell)
   for aspiration in d['aspiration']:
    env['stopped']();env['runtimes']=[];env['captured']=[];session=env['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses)
    p=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=tt,tuning=env['SearchTuning'](use_aspiration=aspiration,aspiration_start_depth=3,aspiration_delta=50))
    v=p.choose_action(session,env['SearchLimits'](max_depth=3,max_nodes=8192,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8));rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and session.state is board.initial
    cell['arms'].append({'aspiration':aspiration,'decision':env['record_value'](v),'stats':env['record_value'](env['captured'][0]),'actual_root_restored':True});print(name,tt,aspiration,v.completed_depth,v.score,v.nodes+v.qnodes,flush=True)
    (B/'aspiration-node-result.json').write_text(json.dumps(out,indent=2)+'\n')
 out['complete']=True;(B/'aspiration-node-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:R.attach_stats=oa;pm.SearchStatistics=of
