import ast,json
from pathlib import Path
B=Path(__file__).parent;prefix=[]
for n in ast.parse((B/'pvs_probe.py').read_text()).body:
 if isinstance(n,ast.Try):break
 prefix.append(n)
env={'__file__':str(B/'pvs_probe.py')};exec(compile(ast.Module(body=prefix,type_ignores=[]),'<reuse>', 'exec'),env)
from generic_chess.ai.alphabeta.transposition import TranspositionTable,TTEntry
class OrderOnly(TranspositionTable):
 def probe(self,key):
  e=super().probe(key)
  return None if e is None else TTEntry(e.key,-1,e.score,e.bound,e.best_action,e.generation)
R=env['R'];pm=env['pm'];oa=R.attach_stats;of=pm.SearchStatistics;out={'complete':False,'cells':[]};d=json.loads((B/'warm-horizon-declaration.json').read_text())
try:
 R.attach_stats=env['attach'];pm.SearchStatistics=env['factory']
 for name in d['roots']:
  c=env['compile_ruleset_for_execution'](env['build_builtin_ruleset']('western_chess'));board=env['CoreBoard'](next(x for x in env['CASES'] if x['id']==name),c);e=env['w'].weighted(c,env['VALUES']['chess']);cell={'root':name,'arms':[]};out['cells'].append(cell)
  for mode in d['arms']:
   p=env['AlphaBetaPlayer'](c,evaluator_override=e,use_disk_cache=False,use_tt=(mode!='fresh_noTT_D1'),tuning=env['SearchTuning'](use_pvs=False,use_root_tactical=False))
   if 'depthmasked' in mode:p._tt=OrderOnly()
   arm={'mode':mode,'calls':[]};cell['arms'].append(arm)
   for depth in ([1] if mode=='fresh_noTT_D1' else [2,1]):
    env['stopped']();env['runtimes']=[];env['captured']=[];session=env['SimpleNamespace'](compiled=c,state=board.initial,_search_witnesses=board.witnesses)
    v=p.choose_action(session,env['SearchLimits'](max_depth=depth,max_nodes=32768,max_time_seconds=30,quiescence_max_depth=0,quiescence_hard_max_depth=8));rt,root=env['runtimes'][0];rt.assert_balanced();assert env['state'](rt)==root and session.state is board.initial
    arm['calls'].append({'requested_depth':depth,'decision':env['record_value'](v),'stats':env['record_value'](env['captured'][0]),'actual_root_restored':True});print(name,mode,depth,v.completed_depth,v.score,v.nodes+v.qnodes,flush=True)
    (B/'warm-horizon-result.json').write_text(json.dumps(out,indent=2)+'\n')
 out['complete']=True;(B/'warm-horizon-result.json').write_text(json.dumps(out,indent=2)+'\n')
finally:R.attach_stats=oa;pm.SearchStatistics=of
