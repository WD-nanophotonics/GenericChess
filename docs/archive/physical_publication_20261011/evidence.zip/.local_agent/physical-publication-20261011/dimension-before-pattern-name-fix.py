"""Finite supported representation dimensions; not search utility or game sampling."""
import sys,json,time,collections
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from rule_semantics_ir_fixtures import _semantic_ruleset,_king_type
from generic_chess.core.movement import LeapAtom
from generic_chess.core.pieces import PieceType
from generic_chess.core.position import Hands
from generic_chess.rules.schema import RuleSemanticAction,RuleGeometrySpec,RuleActionEffect,RuleSquareRef,RuleInvariant,RuleAuxState
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.core.semantic_executor import semantic_engine_for
import generic_chess.core.semantic_executor as m
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import record_value
B=Path(__file__).parent;orig_init=m._WorkingPosition.__init__;orig_freeze=m._WorkingPosition.to_position
metrics=collections.Counter()
def init(self,*args,**kw):
 t=time.perf_counter()
 try:return orig_init(self,*args,**kw)
 finally:metrics['copy_seconds']+=time.perf_counter()-t;metrics['copies']+=1

def freeze(self,*args,**kw):
 t=time.perf_counter()
 try:return orig_freeze(self,*args,**kw)
 finally:metrics['freeze_seconds']+=time.perf_counter()-t;metrics['freezes']+=1

out={'complete':False,'cells':[]}
try:
 for n,h,a in [(8,1,0),(8,8,0),(8,32,0),(12,1,0),(8,1,32),(8,32,32)]:
  stopped();types=(_king_type(),)+tuple(PieceType(f'T{i:02}',f'type{i}',(LeapAtom((1,0)),)) for i in range(h));slots=tuple(RuleAuxState(name=f'slot{i:02}',value_kind='bool',scope='per_owner',lifetime='expire_next_turn',initial=1) for i in range(a));action=RuleSemanticAction(name='anchor_trial',type_ids=('K',),geometry=RuleGeometrySpec(kind='leap',offset=(1,0)),target_relation='empty',composition='augment',aux_state=slots,effects=(RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')),),invariants=(RuleInvariant('own_anchor_safe'),));rules=_semantic_ruleset(types,(action,),n=n,drop_all_true=tuple(t.type_id for t in types if not t.is_anchor));t=time.perf_counter();c=compile_semantic_ruleset(rules);engine=semantic_engine_for(c);prep=time.perf_counter()-t;position=replace(engine._initial_position(),hands=(Hands(tuple((t.type_id,2) for t in types if not t.is_anchor)),Hands(tuple((t.type_id,1) for t in types if not t.is_anchor))));parent=record_value(position);moves=list(engine.iter_legal_action_bindings(position,source=0,target=1));assert moves;act,binding=next((x,b) for x,b in moves if b.pattern.debug_name=='anchor_trial');expected=engine._transition(position,act,binding);assert expected.hands==position.hands;escaped=record_value(expected);cell=dict(board_area=n*n,hand_entries_each=h,logical_aux_entries=len(position.aux_state),compile_seconds=prep,rows=[])
  for measured in (False,True):
   stopped();metrics=collections.Counter();m._WorkingPosition.__init__=init if measured else orig_init;m._WorkingPosition.to_position=freeze if measured else orig_freeze;t=time.perf_counter()
   for i in range(2500):
    child=engine._transition(position,act,binding);assert child==expected
   wall=time.perf_counter()-t;assert record_value(position)==parent and record_value(expected)==escaped;cell['rows'].append(dict(measured=measured,wall=wall,calls=2500,metrics=dict(metrics),stable_parent_and_escaped_child=True))
  out['cells'].append(cell);(B/'dimension-result.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(n,h,a,'done',flush=True)
 out['complete']=True;out['limits']='Imported hands use declared types; not a played-prefix or random-generation distribution. Primitive assertions/timers add overhead; no search speed claim. Aux copy/sort and lifecycle remain in transition outside copy/freeze seams.';(B/'dimension-result.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
finally:m._WorkingPosition.__init__=orig_init;m._WorkingPosition.to_position=orig_freeze
