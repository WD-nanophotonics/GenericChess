from pathlib import Path
import sys,inspect,textwrap,json,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from scripts.search_backend_comparison import CASES,CoreBoard,ChessBoard,ShogiBoard,minimal_ab
from scripts.research_record import write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.reserve_refresh_diagnostic import stopped
old=se.SemanticEngine._action_delivers_check;source=textwrap.dedent(inspect.getsource(old))
a="""for target, path in geometry_candidates(
                geometry, str(piece.owner), source
            ):
                _checkpoint(checkpoint)
                if target != anchor:
                    continue"""
b="""for path in geometry_paths_to(
                geometry, str(piece.owner), source, anchor
            ):
                _checkpoint(checkpoint)
                target = anchor"""
assert source.count(a)==1
changed=source.replace(a,b);ns=dict(se.__dict__);exec(compile(changed,'<actor-target-path>','exec'),ns);new=ns['_action_delivers_check']
base=ROOT/'.local_agent/reserve-refresh-20261010';(base/'actor-path-original-function.py').write_bytes(source.encode());(base/'actor-path-candidate-function.py').write_bytes(changed.encode())
p=base/'actor-path.json';r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
try:
 for name in ('shogi-drop','chess-middle'):
  case=next(c for c in CASES if c['id']==name);compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  for index,arm in enumerate(('old','new','new','old')):
   stopped();se.SemanticEngine._action_delivers_check=old if arm=='old' else new;b=CoreBoard(case,compiled)
   d=minimal_ab(b,2,seconds=30,node_limit=100000,cooperative=True)
   r['rows'].append(dict(case=name,index=index,arm=arm,**d));write_record(p,r);print(name,arm,d['move'],d['score'],d['work']['nodes'],d['wall_seconds'],flush=True)
 r['complete']=True;write_record(p,r)
finally:se.SemanticEngine._action_delivers_check=old
