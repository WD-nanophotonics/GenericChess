from pathlib import Path
import sys,json,time,cProfile,pstats,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.research_record import write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.reserve_refresh_diagnostic import stopped
p=ROOT/'.local_agent/reserve-refresh-20261010/residual-profile.json';r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),roots=[])
for name in ('chess-middle','shogi-drop'):
 stopped();case=next(c for c in CASES if c['id']==name);compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,compiled)
 profiler=cProfile.Profile();d=profiler.runcall(minimal_ab,b,2,seconds=30,node_limit=100000,cooperative=True)
 calls=[]
 for (file,line,name),(primitive,total,own,cumulative,callers) in pstats.Stats(profiler).stats.items():
  calls.append(dict(file=file,line=line,name=name,primitive=primitive,total=total,own_seconds=own,cumulative_seconds=cumulative))
 r['roots'].append(dict(case=case['id'],decision=d,calls=sorted(calls,key=lambda v:v['cumulative_seconds'],reverse=True)));write_record(p,r)
 print(case['id'],d['wall_seconds'],flush=True)
r['complete']=True;write_record(p,r)
