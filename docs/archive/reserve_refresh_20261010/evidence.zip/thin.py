from pathlib import Path
import sys,time,json,hashlib
from dataclasses import replace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,ChessBoard,ShogiBoard,minimal_ab,audit_pair
from scripts.research_record import write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.reserve_refresh_diagnostic import stopped
out=ROOT/'.local_agent/reserve-refresh-20261010/thin.json'
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),depth=2,nodes=100000,seconds=30,cooperative=True,rows=[])
def save():write_record(out,r)
save();started=time.perf_counter()
for case in CASES:
 stopped();tick=time.perf_counter();on=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));off=replace(on);object.__setattr__(off,'_fixed_transition_triggers',None);prep=time.perf_counter()-tick
 tick=time.perf_counter();a=CoreBoard(case,on);b=CoreBoard(case,off);c=ChessBoard(case) if case['game']=='chess' else ShogiBoard(case);setup=time.perf_counter()-tick
 audited=audit_pair(a,c,0);assert a.snapshot()==b.snapshot();assert [x[0] for x in a.actions()]==[x[0] for x in b.actions()]
 boards=[('coreOFF',b),('coreON',a),('specialized',c)]
 for rep in range(2):
  for name,board in (boards if rep==0 else list(reversed(boards))):
   stopped();assert time.perf_counter()-started<300
   d=minimal_ab(board,2,seconds=30,node_limit=100000,cooperative=True)
   r['rows'].append(dict(case=case['id'],backend=name,repeat=rep,root_audit=audited,compile_replace_seconds=prep,setup_seconds=setup,**d));save()
   print(case['id'],name,rep,d['reason'],d['work']['nodes'],round(d['wall_seconds'],4),flush=True)
r['complete']=True;r['wall']=time.perf_counter()-started;save()
