from pathlib import Path
import sys,inspect,textwrap,time,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.research_record import write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.reserve_refresh_diagnostic import stopped
old=se.SemanticEngine._guard_holds;source=textwrap.dedent(inspect.getsource(old))
a="""    if guard.subject_ref is None:
        candidates = enumerate(position.board)"""
b="""    if guard.subject_ref is None:
        if sel.kind in ('same_file', 'same_rank'):
            shape = self.support.board_shape
            ref_sq = self._ref_square(sel.refs[0], position, binding, perspective)
            if ref_sq is None:
                candidates = ()
            elif sel.kind == 'same_file':
                candidates = ((r * shape.width + ref_sq.file, position.board[r * shape.width + ref_sq.file])
                              for r in range(shape.height)) if 0 <= ref_sq.file < shape.width else ()
            else:
                candidates = ((ref_sq.rank * shape.width + f, position.board[ref_sq.rank * shape.width + f])
                              for f in range(shape.width)) if 0 <= ref_sq.rank < shape.height else ()
        else:
            candidates = enumerate(position.board)"""
assert source.count(a)==1
changed=source.replace(a,b);ns=dict(se.__dict__);exec(compile(changed,'<guard-line-prefilter>','exec'),ns);new=ns['_guard_holds']
base=ROOT/'.local_agent/reserve-refresh-20261010';(base/'guard-line-original-function.py').write_bytes(source.encode());(base/'guard-line-candidate-function.py').write_bytes(changed.encode())
p=base/'guard-line.json';r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
try:
 for name in ('shogi-drop','chess-middle'):
  case=next(c for c in CASES if c['id']==name);compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  for index,arm in enumerate(('old','new','new','old')):
   stopped();se.SemanticEngine._guard_holds=old if arm=='old' else new;b=CoreBoard(case,compiled)
   d=minimal_ab(b,2,seconds=30,node_limit=100000,cooperative=True)
   r['rows'].append(dict(case=name,index=index,arm=arm,**d));write_record(p,r);print(name,arm,d['move'],d['score'],d['work']['nodes'],d['wall_seconds'],flush=True)
 r['complete']=True;write_record(p,r)
finally:se.SemanticEngine._guard_holds=old
