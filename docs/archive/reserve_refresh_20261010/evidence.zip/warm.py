from pathlib import Path
import sys,time,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.reserve_refresh_diagnostic import queen_roots,make_refresh,ORIGINAL,stopped
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
p=ROOT/'.local_agent/reserve-refresh-20261010/warm.json'
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
def save():write_record(p,r)
save()
for name,s,e in queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json'):
 for arm in ('baseline','refresh'):
  stopped();player=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False)
  pm.run_root_search=ORIGINAL
  prime=player.choose_action(s,SearchLimits(max_depth=2,max_time_seconds=5,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
  row=dict(root=name,arm=arm,prime=record_value(prime),tt_before=len(player._tt));r['rows'].append(row);save()
  events=[];pm.run_root_search=ORIGINAL if arm=='baseline' else make_refresh(events,expected_state=s.state)
  tick=time.perf_counter()
  try:d=player.choose_action(s,SearchLimits(max_time_seconds=1,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
  finally:pm.run_root_search=ORIGINAL
  row.update(decision=record_value(d),wall=time.perf_counter()-tick,events=events,tt_after=len(player._tt));save()
  print(name,arm,prime.completed_depth,d.completed_depth,d.score,d.tt_hits,flush=True)
 events=[];pm.run_root_search=make_refresh(events,expected_state=s.state)
 try:
  player=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False)
  d=player.choose_action(s,SearchLimits(max_depth=1,max_time_seconds=5,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
 finally:pm.run_root_search=ORIGINAL
 r['rows'].append(dict(root=name,arm='cold-q1-identification',decision=record_value(d),events=events));save()
r['complete']=True;save()
