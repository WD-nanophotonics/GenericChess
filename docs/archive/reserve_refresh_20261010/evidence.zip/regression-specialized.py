from pathlib import Path
import sys,json,hashlib,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import chess
from scripts.research_record import write_record
base=ROOT/'.local_agent/reserve-refresh-20261010';old=json.loads((ROOT/'.local_agent/ui-product-20261010/population-baseline.json').read_bytes());root=next(r for r in old['roots'] if r['game_index']==0 and r['ply']==17);board=chess.Board()
for move in root['moves']:board.push_uci(move)
values={getattr(chess,k):v for k,v in [('PAWN',1000),('KNIGHT',3000),('BISHOP',3000),('ROOK',5000),('QUEEN',9000),('KING',0)]}
# Use the stored material table, never retune against these exposed decisions.
names={'P':chess.PAWN,'N':chess.KNIGHT,'B':chess.BISHOP,'R':chess.ROOK,'Q':chess.QUEEN,'K':chess.KING};values={names[k]:v for k,v in root['original']['material'].items()}
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],material=values,scope='independent specialized material q1/hard8; checks/captures/promotions; no generic evaluator/state equivalence claim')
for move in ('e3d4','e2e1'):
 board.push_uci(move);count=0;start=time.perf_counter();deadline=start+5
 def visit(q,ply,alpha,beta):
  global count
  count+=1
  if count>1000000 or time.perf_counter()>deadline:raise RuntimeError('budget')
  outcome=board.outcome(claim_draw=False)
  if outcome is not None:return (0 if outcome.winner is None else (1 if outcome.winner==board.turn else -1)*(1000000000-ply)),[]
  check=board.is_check()
  if check and q>=8:raise RuntimeError('hardq')
  material=sum((1 if color==board.turn else -1)*len(board.pieces(t,color))*v for t,v in values.items() for color in (chess.WHITE,chess.BLACK))
  if not check and q>=1:return material,[]
  best=-10**12 if check else material;line=[]
  if best>=beta:return best,line
  alpha=max(alpha,best)
  moves=sorted(board.legal_moves,key=lambda m:m.uci())
  if not check:moves=[m for m in moves if board.is_capture(m) or m.promotion or board.gives_check(m)]
  for m in moves:
   label=m.uci();board.push(m)
   try:value,tail=visit(q+1,ply+1,-beta,-alpha);value=-value
   finally:board.pop()
   if value>best:best=value;line=[label]+tail
   alpha=max(alpha,best)
   if alpha>=beta:break
  return best,line
 try:v,line=visit(0,1,-10**12,10**12);row=dict(move=move,root_value=-v,line=[move]+line,complete=True)
 except RuntimeError as exc:row=dict(move=move,complete=False,reason=str(exc))
 row.update(nodes=count,wall=time.perf_counter()-start);r['rows'].append(row);board.pop();print(row,flush=True)
r['complete']=True;write_record(base/'regression-specialized.json',r)
