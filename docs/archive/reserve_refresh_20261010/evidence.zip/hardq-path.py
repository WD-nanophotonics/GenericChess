from pathlib import Path
import sys,json,hashlib,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.reserve_refresh_diagnostic import transfer_roots,stopped
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta import search
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
name,s,e=next(x for x in transfer_roots() if x[0]=='generated4-seed21');initial=s.state;base=ROOT/'.local_agent/reserve-refresh-20261010';stack=[];failures=[];full_history=[];old=search._quiescence_runtime
# Position references are immutable; defer JSON and equality work until after abort.
def trace(alpha,beta,ply,qdepth,ctx):
 rt=ctx.runtime;stack.append((rt.position,rt.ply_count,rt.terminal_status,qdepth,rt._history[-1].action_signature,rt._history_context))
 try:return old(alpha,beta,ply,qdepth,ctx)
 except search.SearchAborted as exc:
  if str(exc)=='qsearch_check_hard_limit' and not failures:
   failures.append(tuple(stack));full_history.extend((h.actor,h.action_signature,h.gave_check) for h in rt._history)
  raise
 finally:stack.pop()
stopped();search._quiescence_runtime=trace;start=time.perf_counter()
try:d=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False).choose_action(s,SearchLimits(max_time_seconds=5,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
finally:search._quiescence_runtime=old
assert s.state==initial and not stack
r=dict(complete=True,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),wall=time.perf_counter()-start,decision=record_value(d),repetition_policy=getattr(s.compiled,'repetition_policy',None),repetition_count=getattr(s.compiled,'repetition_count',None),paths=[],full_action_history=full_history)
for path in failures:
 rows=[]
 for i,(pos,ply,terminal,q,signature,history) in enumerate(path):
  rows.append(dict(position=record_value(pos),ply=ply,terminal=record_value(terminal),qdepth=q,action_signature=signature,earlier_equal_positions=[j for j,x in enumerate(path[:i]) if x[0]==pos]))
 r['paths'].append(rows)
write_record(base/'hardq-path.json',r);print(dict(reason=d.termination_reason,depth=d.completed_depth,path_length=[len(p) for p in r['paths']],repetition_policy=r['repetition_policy']));print([(x['qdepth'],x['earlier_equal_positions']) for x in r['paths'][0]])
