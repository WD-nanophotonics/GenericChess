from pathlib import Path
import sys,json,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.reserve_refresh_diagnostic import queen_roots,uci,stopped
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta import search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
base=ROOT/'.local_agent/reserve-refresh-20261010';name,s,e=next(x for x in queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json',all_ui=True) if x[0]=='ui-0-17');initial=s.state
r=dict(complete=False,root=name,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
for label in ('e3d4','e2e1'):
 stopped();action={uci(a):a for a in s.legal_actions()}[label];s.submit(action);child=s.state;stats=SearchStatistics();limits=SearchLimits(max_nodes=1000000,max_time_seconds=5,quiescence_max_depth=1,quiescence_hard_max_depth=8)
 ctx=search._Context(s.compiled,e,TranspositionTable(),stats,search._Budget(limits,None),SearchTuning(),False,True,1,8,None,first_main_iteration_complete=True)
 leaves=[];original=search._evaluate
 def trace(state,evaluator,context):
  score=original(state,evaluator,context);leaves.append(dict(ply=state.ply_count,position=record_value(state.position),score=score));return score
 search._evaluate=trace;start=time.perf_counter()
 try:
  result=search.negamax(child,0,-search.INF,search.INF,1,ctx);row=dict(move=label,root_value=-result.score,complete=True)
 except search.SearchAborted as exc:row=dict(move=label,complete=False,reason=str(exc))
 finally:search._evaluate=original
 row.update(wall=time.perf_counter()-start,nodes=stats.nodes,qnodes=stats.qnodes,in_check_qnodes=stats.in_check_qnodes,leaves=leaves);r['rows'].append(row);write_record(base/'regression-probe.json',r);s.undo();assert s.state==initial;print(label,row.get('root_value'),stats.qnodes,len(leaves),flush=True)
r['complete']=True;write_record(base/'regression-probe.json',r)
