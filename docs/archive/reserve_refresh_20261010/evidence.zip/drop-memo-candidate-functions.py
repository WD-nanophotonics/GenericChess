def _iter_drop_candidates(
    self, pattern, position: Position, side,
    checkpoint: Checkpoint | None = None,
):
    drop_gid = next(
        (
            g
            for g in pattern.geometry_ids
            if self.ir.geometry[g].kind == "drop"
        ),
        "",
    )
    for tid in pattern.type_ids:
        _checkpoint(checkpoint)
        mask = self.support.drop_allowed.get(tid, ((), ()))[side]
        hand = dict(position.hands[side].counts)
        if hand.get(tid, 0) <= 0:
            continue
        guard_cache = {}
        for target in range(self.support.board_area):
            _checkpoint(checkpoint)
            if not mask[target] or position.board[target] is not None:
                continue
            binding = self._make_binding(
                pattern, drop_gid, tid, None, None, target, None, (), position
            )
            if not self._guards_hold(
                pattern, position, binding, side, checkpoint=checkpoint, drop_guard_cache=guard_cache
            ):
                continue
            action = SemanticAction(
                pattern_id=pattern.pattern_id,
                source=None,
                target=target,
                actor_type=tid,
                geometry_id=drop_gid,
            )
            yield action, binding

def _guards_hold(
    self, pattern, position, binding, perspective,
    checkpoint: Checkpoint | None = None, drop_guard_cache=None,
) -> bool:
    for guard in pattern.guards:
        _checkpoint(checkpoint)
        cacheable = (drop_guard_cache is not None and guard.subject_ref is None
                     and guard.spatial.kind in ("same_file", "same_rank")
                     and guard.spatial.refs[0].kind == "target")
        if cacheable:
            shape = self.support.board_shape
            line = binding.target % shape.width if guard.spatial.kind == "same_file" else binding.target // shape.width
            key = (guard, line)
            if key not in drop_guard_cache:
                drop_guard_cache[key] = self._guard_holds(guard, position, binding, perspective, checkpoint=checkpoint)
            holds = drop_guard_cache[key]
        else:
            holds = self._guard_holds(guard, position, binding, perspective, checkpoint=checkpoint)
        if not holds:
            return False
    for guard in pattern.square_zone_guards:
        _checkpoint(checkpoint)
        square_idx = _resolve_square_ref(
            guard.square_ref,
            self.support,
            self.ir.aux_slots,
            position,
            perspective,
            binding,
        )
        zone = self.ir.zones.get(guard.spatial.zone_id)
        if square_idx is None or zone is None:
            return False
        zone_squares = zone.squares
        if guard.owner_relative and binding.actor_owner == 1:
            shape = self.support.board_shape
            # Rotation is an involution; inverse-transform one square
            # instead of allocating a rotated zone for every candidate.
            square_idx = shape.area - 1 - square_idx
        is_inside = square_idx in zone_squares
        if (guard.relation == "inside") != is_inside:
            return False
    for slot_guard in pattern.slot_guards:
        _checkpoint(checkpoint)
        if not self._slot_guard_holds(slot_guard, position, binding, perspective):
            return False
    return True
