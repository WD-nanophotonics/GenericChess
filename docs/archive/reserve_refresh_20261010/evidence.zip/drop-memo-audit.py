from pathlib import Path
import sys, random, hashlib, json, time
from types import SimpleNamespace
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from generic_chess.core import semantic_executor as se
from generic_chess.core.pieces import Piece
from generic_chess.rules.ir import CompiledStatePredicate as Guard,CompiledSpatialSelector as Spatial,CompiledSquareRef as Ref,CompiledTypeRef as Type
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from test_rectangular_semantic_action_b4b import _rectangular_single_capture_ruleset
from scripts.research_record import write_record
base=ROOT/'.local_agent/reserve-refresh-20261010';ns=dict(se.__dict__)
exec(compile((base/'drop-memo-candidate-functions.py').read_text(),'<drop-memo-audit>','exec'),ns)
new=ns['_guards_hold'];old=se.SemanticEngine._guards_hold;rng=random.Random(20261010)
r=dict(complete=False,seed=20261010,checks=0,cancel_checks=0,shapes={},source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
start=time.perf_counter()
for game in ('western_chess','standard_shogi','rectangle'):
 rules=_rectangular_single_capture_ruleset() if game=='rectangle' else build_builtin_ruleset(game)
 eng=se.semantic_engine_for(compile_ruleset_for_execution(rules));initial=eng._initial_position();shape=eng.support.board_shape;ids=list(eng.support.type_metadata);before=r['checks']
 for trial in range(96):
  board=tuple(None if rng.random()<.6 else Piece(rng.randrange(2),rng.choice(ids),rng.choice(ids),rng.choice((True,False))) for _ in range(shape.area));pos=replace(initial,board=board);side=trial%2
  # Different actors get separate maps exactly as the drop generator does.
  for tid in ids[:2]:
   cache={};typ=rng.choice((Type('any'),Type('explicit',ids[-1]),Type('action_base'),Type('action_current')))
   guard=Guard(rng.choice(('count','exists')),rng.choice(('self','opponent','any')),typ,rng.choice(('base','current')),rng.choice(('yes','no','any')),'board',Spatial(rng.choice(('same_file','same_rank')),(Ref('target'),)),rng.choice(('eq','ne','lt','le','gt','ge')),rng.randrange(4))
   pattern=SimpleNamespace(guards=(guard,),square_zone_guards=(),slot_guards=())
   for target in range(shape.area):
    binding=se._ActionBinding(pattern,'drop',side,tid,tid,tid,None,target,None,())
    assert old(eng,pattern,pos,binding,side)==new(eng,pattern,pos,binding,side,drop_guard_cache=cache)
    r['checks']+=1
   assert len(cache)<=max(shape.width,shape.height)
   def cancel():raise RuntimeError('cancel')
   try:new(eng,pattern,pos,binding,side,checkpoint=cancel,drop_guard_cache=cache)
   except RuntimeError as exc:assert str(exc)=='cancel';r['cancel_checks']+=1
   else:raise AssertionError('cached guard skipped cancellation')
 r['shapes'][game]=r['checks']-before
r['complete']=True;r['wall']=time.perf_counter()-start;write_record(base/'drop-memo-audit.json',r);print(json.dumps(r,indent=2))
