def run_root_search(
    state: GameState,
    compiled,
    evaluator: Evaluator,
    tt: TranspositionTable,
    limits: SearchLimits,
    cancel_token: CancellationToken | None,
    stats: SearchStatistics,
    *,
    use_tt: bool,
    use_ordering: bool,
    tuning: SearchTuning = SearchTuning(),
    _history_witnesses=None,
    legal_binding_provider=None,
    recorder: AuditRecorder | None = None,
    progress_callback=None,
) -> tuple[Action | None, int, tuple[Action, ...], str]:
    """Iterative deepening; returns (action, score, pv, termination_reason)."""
    started = time.monotonic()
    runtime = SearchPathRuntime.from_state(
        state,
        compiled,
        history_witnesses=_history_witnesses,
        legal_binding_provider=legal_binding_provider,
    )
    terminal = runtime.terminal_status
    if terminal.is_terminal:
        stats.termination_reason = "terminal_position"
        return (
            None,
            terminal_score(terminal, state.position.side_to_move, 0),
            (),
            stats.termination_reason,
        )
    budget = _Budget(limits, cancel_token)
    tt.new_generation()
    ctx = _Context(
        compiled,
        evaluator,
        tt,
        stats,
        budget,
        tuning,
        use_tt,
        use_ordering,
        limits.quiescence_max_depth,
        limits.quiescence_hard_max_depth,
        limits.quiescence_max_nodes,
        recorder,
        runtime,
        first_main_iteration_complete=False,
    )
    runtime.attach_stats(stats)

    # Root declaration assessment is deliberately before legal-action
    # fallback/tactical scanning so no root path can bypass a valid WIN.
    root_declarations = _declaration_options(runtime.state, compiled, stats)
    root_winning = next((a for a in root_declarations if a.outcome == "WIN"), None)
    if root_winning is not None:
        stats.declaration_root_selected = True
        stats.root_declaration = root_winning
        stats.termination_reason = "root_declaration_win"
        return None, MATE_SCORE, (), stats.termination_reason

    root_first_action: Action | None = None
    root_handles = None
    actions: list[Action] | None = None
    if runtime is not None:
        try:
            actions = _runtime_legal_actions(ctx, ctx.checkpoint)
        except SearchAborted as exc:
            # A cancelled search still owes the caller one legal fallback,
            # matching the historical root contract.  The fallback generation
            # is outside search and does not recurse or mutate the runtime.
            actions = _runtime_legal_actions(ctx, None)
            if not actions:
                stats.termination_reason = str(exc)
                return None, 0, (), stats.termination_reason
            stats.time_to_first_legal_action = time.monotonic() - started
            stats.root_scan_used_fallback = True
            stats.termination_reason = str(exc)
            return sorted(actions, key=str)[0], 0, (), stats.termination_reason
        if not actions:
            stats.termination_reason = "terminal_position"
            return None, 0, (), stats.termination_reason
        root_first_action = sorted(actions, key=str)[0]
        stats.time_to_first_legal_action = time.monotonic() - started
        try:
            budget.check(stats, force=True)
        except SearchAborted as exc:
            stats.root_scan_used_fallback = True
            stats.termination_reason = str(exc)
            return root_first_action, 0, (), stats.termination_reason
    elif semantic_engine_for(compiled) is not None:
        root_stream = iter_legal_successor_handles(
            state, compiled, checkpoint=ctx.checkpoint
        )
        try:
            first_handle = next(root_stream)
        except StopIteration:
            stats.termination_reason = "terminal_position"
            return None, 0, (), stats.termination_reason
        except SearchAborted:
            stats.termination_reason = "NO_LEGAL_FALLBACK_BEFORE_DEADLINE"
            return None, 0, (), stats.termination_reason
        root_first_action = first_handle.action
        stats.time_to_first_legal_action = time.monotonic() - started
        root_handles = chain((first_handle,), root_stream)
        try:
            budget.check(stats, force=True)
        except SearchAborted as exc:
            stats.root_scan_used_fallback = True
            stats.termination_reason = str(exc)
            return root_first_action, 0, (), stats.termination_reason
    else:
        actions = legal_actions(state, compiled)
        if not actions:
            stats.termination_reason = "terminal_position"
            return None, 0, (), stats.termination_reason
        try:
            budget.check(stats, force=True)
        except SearchAborted as exc:
            stats.root_scan_used_fallback = True
            stats.termination_reason = str(exc)
            return sorted(actions, key=str)[0], 0, (), stats.termination_reason

    immediate_win: Action | None = None
    scan_best: Action | None = None
    if tuning.use_root_tactical:
        try:
            immediate_win, scan_best = root_tactical_scan(
                state, compiled, evaluator, ctx, handles=root_handles
            )
        except SearchAborted as exc:
            stats.root_scan_used_fallback = True
            stats.termination_reason = str(exc)
            fallback = ctx.root_scan_best_action or root_first_action
            if fallback is None:
                fallback = sorted(actions, key=str)[0]
            return fallback, 0, (), stats.termination_reason
    if immediate_win is not None:
        stats.termination_reason = "root_immediate_win"
        return immediate_win, MATE_SCORE - 1, (immediate_win,), stats.termination_reason

    max_depth = limits.max_depth if limits.max_depth is not None else 64
    best: SearchResult | None = None
    abort_reason: str | None = None
    for depth in range(1, max_depth + 1):
        ctx.use_tt = use_tt if depth > 1 or ctx.qdepth_limit == 0 else False
        try:
            budget.check_iteration(stats)
        except SearchAborted as exc:
            abort_reason = str(exc)
            break
        prev_score = best.score if best is not None else None
        try:
            if (
                tuning.use_aspiration
                and depth >= tuning.aspiration_start_depth
                and prev_score is not None
                and abs(prev_score) < MATE_THRESHOLD
            ):
                best = _aspiration_iteration(state, depth, prev_score, ctx)
            else:
                best = negamax(state, depth, -INF, INF, 0, ctx)
        except SearchAborted as exc:
            abort_reason = str(exc)
            break
        stats.completed_depth = depth
        stats.selective_depth = depth
        ctx.first_main_iteration_complete = True
        if stats.time_to_first_completed_iteration is None:
            stats.time_to_first_completed_iteration = time.monotonic() - started
        if progress_callback is not None:
            progress_callback(depth, stats.nodes, stats.qnodes)
        if depth == 1 and ctx.qdepth_limit > 0 and best.declaration is None:
            _refresh_log('reserve', ctx, best)
            original_q, original_tt = ctx.qdepth_limit, ctx.use_tt
            ctx.use_tt = False
            ctx.qdepth_limit = min(1, original_q)
            _refresh_log('begin', ctx, best)
            try:
                # RHS assignment is essential: an abort retains complete reserve.
                refreshed = negamax(state, 1, -INF, INF, 0, ctx)
                _refresh_log('complete', ctx, refreshed)
                best = refreshed
            except SearchAborted as exc:
                _refresh_log('aborted', ctx, best, str(exc))
                abort_reason = str(exc)
                break
            finally:
                ctx.qdepth_limit = original_q
                ctx.use_tt = use_tt


    if best is not None:
        stats.termination_reason = "completed_depth" if abort_reason is None else abort_reason
        if best.declaration is not None:
            stats.declaration_root_selected = True
            stats.root_declaration = best.declaration
            return None, best.score, (), stats.termination_reason
        return best.best_action, best.score, best.pv, stats.termination_reason

    # No full iteration completed: prefer the root scan's best action.
    # Fallback describes the selected action, not why search stopped.
    stats.root_scan_used_fallback = True
    stats.termination_reason = abort_reason or "fallback"
    if tuning.use_root_tactical and scan_best is not None:
        return scan_best, 0, (), stats.termination_reason
    fallback = root_first_action
    if fallback is None:
        fallback = sorted(actions, key=str)[0]
    return fallback, 0, (), stats.termination_reason
