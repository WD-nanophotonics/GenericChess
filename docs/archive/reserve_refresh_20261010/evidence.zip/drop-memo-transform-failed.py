from pathlib import Path
import sys, inspect, textwrap, hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from scripts.search_backend_comparison import CASES,CoreBoard,minimal_ab
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
base=ROOT/'.local_agent/reserve-refresh-20261010'
old_iter=se.SemanticEngine._iter_drop_candidates;old_hold=se.SemanticEngine._guards_hold
src1=textwrap.dedent(inspect.getsource(old_iter));src2=textwrap.dedent(inspect.getsource(old_hold))
a='            for target in range(self.support.board_area):'
b='            guard_cache = {}\n            for target in range(self.support.board_area):'
assert src1.count(a)==1
new1=src1.replace(a,b).replace('pattern, position, binding, side, checkpoint=checkpoint','pattern, position, binding, side, checkpoint=checkpoint, drop_guard_cache=guard_cache')
new2=src2.replace('checkpoint: Checkpoint | None = None,','checkpoint: Checkpoint | None = None, drop_guard_cache=None,')
a='''        if not self._guard_holds(
            guard, position, binding, perspective, checkpoint=checkpoint
        ):
            return False'''
b='''        cacheable = (drop_guard_cache is not None and guard.subject_ref is None
                     and guard.spatial.kind in ("same_file", "same_rank")
                     and guard.spatial.refs[0].kind == "target")
        if cacheable:
            shape = self.support.board_shape
            line = binding.target % shape.width if guard.spatial.kind == "same_file" else binding.target // shape.width
            key = (guard, line)
            if key not in drop_guard_cache:
                drop_guard_cache[key] = self._guard_holds(guard, position, binding, perspective, checkpoint=checkpoint)
            holds = drop_guard_cache[key]
        else:
            holds = self._guard_holds(guard, position, binding, perspective, checkpoint=checkpoint)
        if not holds:
            return False'''
assert new2.count(a)==1;new2=new2.replace(a,b)
ns=dict(se.__dict__);exec(compile(new1+'\n'+new2,'<drop-guard-memo>','exec'),ns)
new_iter=ns['_iter_drop_candidates'];new_hold=ns['_guards_hold']
(base/'drop-memo-original-functions.py').write_bytes((src1+'\n'+src2).encode())
(base/'drop-memo-candidate-functions.py').write_bytes((new1+'\n'+new2).encode())
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[])
try:
 for name in ('shogi-drop','chess-middle'):
  case=next(c for c in CASES if c['id']==name)
  compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  for index,arm in enumerate(('old','new','new','old')):
   stopped();se.SemanticEngine._iter_drop_candidates=old_iter if arm=='old' else new_iter;se.SemanticEngine._guards_hold=old_hold if arm=='old' else new_hold
   d=minimal_ab(CoreBoard(case,compiled),2,seconds=30,node_limit=100000,cooperative=True)
   r['rows'].append(dict(case=name,index=index,arm=arm,**d));write_record(base/'drop-memo.json',r)
   print(name,arm,d['wall_seconds'],d['work']['nodes'],flush=True)
 r['complete']=True;write_record(base/'drop-memo.json',r)
finally:se.SemanticEngine._iter_drop_candidates=old_iter;se.SemanticEngine._guards_hold=old_hold
