def _guard_holds(
    self, guard, position: Position, binding, perspective,
    checkpoint: Checkpoint | None = None,
) -> bool:
    sel = guard.spatial
    bound_base = binding.actor_base
    bound_current = binding.actor_current
    count = 0
    if guard.subject_ref is None:
        candidates = enumerate(position.board)
    else:
        subject_idx = _resolve_square_ref(
            guard.subject_ref,
            self.support,
            self.ir.aux_slots,
            position,
            perspective,
            binding,
        )
        candidates = (
            ((subject_idx, position.board[subject_idx]),)
            if subject_idx is not None and 0 <= subject_idx < len(position.board)
            else ()
        )
    for idx, piece in candidates:
        _checkpoint(checkpoint)
        if piece is None:
            continue
        if not self._owner_filter_ok(guard.owner, piece.owner, perspective):
            continue
        if guard.location == "hand":
            continue  # hand predicates are rejected at compile time
        if not self._type_selector_ok(guard, piece, bound_base, bound_current):
            continue
        promoted_ok = (
            guard.promoted == "any"
            or (guard.promoted == "yes") == piece.promoted
        )
        if not promoted_ok:
            continue
        if self._spatial_ok(
            sel, idx, position, binding, perspective, checkpoint=checkpoint
        ):
            count += 1
    if guard.aggregation == "exists":
        value = 1 if count > 0 else 0
    else:
        value = count
    return self._compare(guard.comparison, value, guard.value)
