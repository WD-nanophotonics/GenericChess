from pathlib import Path
import sys,time,json,hashlib,copy
from dataclasses import replace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.reserve_refresh_diagnostic import queen_roots,make_refresh,ORIGINAL,stopped
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta import search,player as pm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.transposition import TranspositionTable,BoundType
from generic_chess.ai.limits import SearchLimits
stack=[];stage='prime';original_negamax=search.negamax

def signature(ctx,depth,alpha,beta,ply):
 return dict(main_remaining_depth=depth,ordinary_q=search._ordinary_qdepth_limit(ctx),configured_q=ctx.qdepth_limit,
             hard_q=ctx.qhard_depth_limit,first_completed=ctx.first_main_iteration_complete,
             evaluation_control='same-per-root-evaluator-object',alpha=alpha,beta=beta,ply=ply,phase=stage)
def traced_negamax(state,depth,alpha,beta,ply,ctx,*a,**kw):
 stack.append(signature(ctx,depth,alpha,beta,ply))
 try:return original_negamax(state,depth,alpha,beta,ply,ctx,*a,**kw)
 finally:stack.pop()
search.negamax=traced_negamax
class TraceTT(TranspositionTable):
 def __init__(self):super().__init__();self.contracts={};self.hits=[];self.clear_cost=[]
 def store(self,key,depth,score,bound,action):
  old=self._data.get(key);oldversion=None if old is None else (old.depth,old.generation)
  super().store(key,depth,score,bound,action)
  current=self._data.get(key)
  # The real replacement rule, rather than assuming every store request wins.
  accepted=oldversion is None or depth>=oldversion[0] or self.generation>oldversion[1]
  if accepted:
   self.contracts[key]=dict(producer=copy.deepcopy(stack[-1]) if stack else 'UNKNOWN',stored_depth=current.depth,stored_bound=current.bound.name,stored_score=current.score)
  self.contracts={k:v for k,v in self.contracts.items() if k in self._data}
 def probe(self,key):
  e=super().probe(key)
  if e is not None:
   request=copy.deepcopy(stack[-1]) if stack else 'UNKNOWN'
   self.hits.append(dict(request=request,entry=self.contracts.get(key,'UNKNOWN'),stored_depth=e.depth,stored_bound=e.bound.name,
       stored_score=e.score,eligible_depth=None if not stack else e.depth>=stack[-1]['main_remaining_depth'],key_hash=hash(key)))
  return e
 def clear(self):
  tick=time.perf_counter();count=len(self._data);super().clear();self.contracts.clear()
  self.clear_cost.append(dict(phase=stage,entries=count,seconds=time.perf_counter()-tick))

p=ROOT/'.local_agent/reserve-refresh-20261010/warm-entry.json'
r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),instrumented=True,roots=[])
def save():write_record(p,r)
save()
try:
 for name,s,e in queen_roots(ROOT/'.local_agent/ui-product-20261010/games-final.json'):
  stopped();stage='prime';base=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False);base._tt=TraceTT();pm.run_root_search=ORIGINAL
  prime=base.choose_action(s,SearchLimits(max_depth=2,max_time_seconds=5,max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8))
  row=dict(root=name,prime=record_value(prime),prime_completed=prime.completed_depth==2,entries=len(base._tt),rows=[]);r['roots'].append(row);save()
  # Snapshot once; neither outcome is ever the other arm's starting table.
  snapshot_data=copy.deepcopy(base._tt._data);snapshot_contracts=copy.deepcopy(base._tt.contracts);generation=base._tt.generation
  for clear_entry in (False,True):
   stopped();events=[];tt=TraceTT();player=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False);player._tt=tt;player._tt_q_depths=(4,8)
   stage='entry-copy';tick=time.perf_counter();tt._data=copy.deepcopy(snapshot_data);tt.contracts=copy.deepcopy(snapshot_contracts);tt._generation=generation
   if clear_entry:tt.clear()
   setup=time.perf_counter()-tick
   stage='revisit';fn=make_refresh(events,expected_state=s.state)
   # Charge actual per-call independent copy+optional clear against original1sec.
   limits=SearchLimits(max_time_seconds=max(0,1-setup),max_nodes=1000000,quiescence_max_depth=4,quiescence_hard_max_depth=8)
   pm.run_root_search=fn
   try:d=player.choose_action(s,limits)
   finally:pm.run_root_search=ORIGINAL
   assert not stack
   row['rows'].append(dict(entry_clear=clear_entry,setup_seconds=setup,wall_including_setup=setup+d.elapsed_seconds,
       requested_seconds=1,effective_search_seconds=limits.max_time_seconds,initial_snapshot_entries=len(snapshot_data),
       events=events,decision=record_value(d),tt_hits=tt.hits,clear_costs=tt.clear_cost))
   save();print(name,clear_entry,prime.completed_depth,d.completed_depth,d.score,len(tt.hits),setup,flush=True)
 r['complete']=True;save()
finally:
 search.negamax=original_negamax;pm.run_root_search=ORIGINAL
