import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
from scripts.reserve_refresh_diagnostic import transfer_roots
from scripts.research_record import record_value,write_record
from generic_chess.core.actions import action_from_dict
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.attacks import is_in_check
base=Path('.local_agent/reserve-refresh-20261010');r=json.loads((base/'hardq-path.json').read_bytes());_,s,_=next(x for x in transfer_roots() if x[0]=='generated4-seed21');checks=[]
for actor,signature,gave_check in r['full_action_history']:
 if not signature:continue
 action=action_from_dict(json.loads(signature));assert s.state.position.side_to_move==actor;assert action in s.legal_actions();s.submit(action)
 for x in r['paths'][0]:
  if x['ply']!=s.state.ply_count:continue
  assert record_value(s.state.position)==x['position'];assert record_value(s.state.terminal_status)==x['terminal'];eng=semantic_engine_for(s.compiled)
  check=eng.in_check(s.state.position,s.state.position.side_to_move) if eng else is_in_check(s.state.position,s.state.position.side_to_move,s.compiled)
  checks.append(dict(ply=x['ply'],qdepth=x['qdepth'],in_check=check,legal=len(s.legal_actions()),repetition_counts=record_value(s.state.repetition_counts)))
assert len(checks)==9
out=dict(complete=True,legal_public_replayed_plies=s.state.ply_count,matched_q_positions=9,rows=checks,decision='Legitimate ongoing unique-state path, not a missing short repetition. Already completed D2 estimate is preserved; no hard-limit/rule change. Full PV is not this failure path.')
write_record(base/'hardq-path-audit-reproduced.json',out);assert (base/'hardq-path-audit-reproduced.json').read_bytes()==(base/'hardq-path-audit.json').read_bytes()
print('exact stored public replay reproduced')
