from pathlib import Path
import sys,json,time,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from scripts.reserve_refresh_diagnostic import transfer_roots,stopped
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.research_record import write_record,record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
base=ROOT/'.local_agent/reserve-refresh-20261010';ns=dict(se.__dict__);exec(compile((base/'guard-line-candidate-function.py').read_text(),'<guard-v3>','exec'),ns);old=se.SemanticEngine._guard_holds;new=ns['_guard_holds']
roots=[]
for name in ('shogi-drop','chess-middle'):
 case=next(c for c in CASES if c['id']==name);c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));b=CoreBoard(case,c);s=GameSession(c);s._state=b.initial;s._search_history_witnesses=b.witnesses;roots.append((name,s,b.material))
roots.extend(transfer_roots());r=dict(complete=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((base/'guard-line-candidate-function.py').read_bytes()).hexdigest(),rows=[])
try:
 for name,s,e in roots:
  initial=s.state;legal=tuple(s.legal_actions())
  for seconds in (1,4):
   for index,arm in enumerate(('old','new','new','old')):
    stopped();se.SemanticEngine._guard_holds=old if arm=='old' else new;p=AlphaBetaPlayer(s.compiled,evaluator_override=e,use_native_semantic_legality=False)
    start=time.perf_counter();d=p.choose_action(s,SearchLimits(max_time_seconds=seconds,max_nodes=100000,quiescence_max_depth=4));wall=time.perf_counter()-start
    assert s.state==initial;assert d.action is None or d.action in legal
    r['rows'].append(dict(root=name,seconds=seconds,index=index,arm=arm,wall=wall,decision=record_value(d)));write_record(base/'guard-time.json',r);print(name,seconds,arm,d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
 r['complete']=True;write_record(base/'guard-time.json',r)
finally:se.SemanticEngine._guard_holds=old
