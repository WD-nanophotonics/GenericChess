def _action_delivers_check(
    self, position: Position, child: Position, action,
    checkpoint: Checkpoint | None = None,
) -> bool:
    """Return whether this action's actor itself checks the reply side.

    This is distinct from the resulting position being checked: a
    position may already contain a check from an earlier history state.
    The distinction is a generic action-witness primitive and is needed
    by bounded postconditions such as a checking drop restriction.
    """
    anchor = _own_anchor(child, self.support, child.side_to_move)
    if anchor is None:
        return False
    source = action.target
    piece = child.board[source]
    if piece is None or piece.owner != position.side_to_move:
        return False
    for pattern in self._patterns:
        _checkpoint(checkpoint)
        if pattern.target.kind != "target_enemy" or piece.current_type_id not in pattern.type_ids:
            continue
        for gid in pattern.geometry_ids:
            _checkpoint(checkpoint)
            geometry = self.ir.geometry.get(gid)
            if geometry is None or geometry.kind == "drop":
                continue
            if geometry.atom_source is not None and geometry.atom_source[0] != piece.current_type_id:
                continue
            for target, path in geometry_candidates(
                geometry, str(piece.owner), source
            ):
                _checkpoint(checkpoint)
                if target != anchor:
                    continue
                binding = self._make_binding(
                    pattern,
                    gid,
                    piece.current_type_id,
                    piece,
                    source,
                    target,
                    None,
                    path,
                    child,
                )
                if self._path_holds(
                    pattern.path, child, binding, piece.owner,
                    checkpoint=checkpoint,
                ) and self._guards_hold(
                    pattern, child, binding, piece.owner,
                    checkpoint=checkpoint,
                ):
                    return True
    return False
