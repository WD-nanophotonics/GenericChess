"""Frozen-trajectory diagnostics, no added samples or fitted model."""
import json,hashlib,math,statistics
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
p=Path(__file__).parent;out=p/'horizon-summary.json';assert not out.exists()
def stats(values):
 n=len(values);mean=statistics.mean(values);se=statistics.stdev(values)/math.sqrt(n) if n>1 else None
 return dict(n=n,mean=mean,standard_error=se,normal_approx_95=[mean-1.96*se,mean+1.96*se] if se is not None else None)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Diagnostic normal intervals are not bounded coverage guarantees; all samples exposed development. Old exact H3 is fixed. Impact screens are practical, not scientific accuracy limits. Final custody/type strata are postdeclared exploratory localization, not new validation or causal attribution.',batches=[])
for name,horizon in (('pilot-qualified.json',6),('validation.json',6),('horizon10.json',10)):
 src=p/name;raw=json.loads(src.read_bytes());assert raw['complete'];rows=[]
 for case in raw['cases']:
  es=case['episodes'];H=float(F(case['frozen_H']));usable=lambda e:e['T'] is not None and e['T']<=horizon-3
  residual=stats([H*usable(e)-e['U'] for e in es]);threshold=.1 if case['target']=='G' else .025;interval=residual['normal_approx_95'];flag=abs(residual['mean'])>threshold and interval[0]*interval[1]>0
  row=dict(context=case['context'],target=case['target'],N=len(es),mean_U=statistics.mean(e['U'] for e in es),stationary_prediction=case['summary']['stationary_prediction'],residual=residual,practical_screen=threshold,screen_triggered=flag,transfer_times=case['summary']['transfer_times'],conditional_U=case['summary']['conditional_U'],terminal_counts=dict(Counter(e['terminal']['status'] for e in es)))
  if horizon==10:
   row['final_custody']=dict(Counter(str((e['final_tag']['owner'],e['final_tag']['location'],e['final_tag']['current_type'])) for e in es))
   row['multiple_transfer_episodes']=sum(len(e['ownership_changes'])>1 for e in es)
   row['opportunity_by_final_type']={str(t):sum(e['U'] for e in es if e['final_tag']['current_type']==t)/len(es) for t in {e['final_tag']['current_type'] for e in es}}
  rows.append(row)
 paired=[]
 for context in (0,1):
  g,pawn=[next(c for c in raw['cases'] if c['context']==context and c['target']==t) for t in ('G','TP')];contrast=[];errors=[]
  for a,b in zip(g['episodes'],pawn['episodes']):
   assert a['seed']==b['seed'];actual=a['U']-b['U'];contrast.append(actual);pred=float(F(g['frozen_H']))*(a['T'] is not None and a['T']<=horizon-3)-float(F(pawn['frozen_H']))*(b['T'] is not None and b['T']<=horizon-3);errors.append(pred-actual)
  paired.append(dict(context=context,G_minus_P=stats(contrast),prediction_minus_contrast=stats(errors)))
 r['batches'].append(dict(file=name,sha256=hashlib.sha256(src.read_bytes()).hexdigest(),horizon=horizon,seconds=raw['seconds'],transitions=sum(c['transitions'] for c in raw['cases']),rows=rows,paired=paired))
r['complete']=True;out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
for b in r['batches']:
 print(b['file'],b['seconds'])
 for row in b['rows']:print(row['context'],row['target'],'residual',row['residual'],'screen',row['screen_triggered'],'typeU',row.get('opportunity_by_final_type'))
