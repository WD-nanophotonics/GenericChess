"""Localize remaining-time approximation on frozen independent sources."""
import json,hashlib,statistics,math
from fractions import Fraction as F
from pathlib import Path
p=Path(__file__).parent;out=p/'time-strata.json';assert not out.exists();outer=json.loads((p/'horizon10.json').read_bytes());kernel=json.loads((p/'kernel.json').read_bytes());assert outer['complete'] and kernel['complete']
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ('horizon10.json','kernel.json')},scope='Postdeclared localization only, no new simulation or kernel fitted against conditional outcomes. AtT1 forced postcapture context is identical to the outer initial capture, while delayed captures may change context. Conditional subgroup and independent kernel mean SE combined diagnostically; small/multiple groups do not give certified coverage or causal attribution. ExactH3 has zero samplingSE, not zero context error. Keep terminal counts, all strata and old residuals.',rows=[])
for oc in outer['cases']:
 kc=next(c for c in kernel['cases'] if c['context']==oc['context'] and c['target']==oc['target'])
 for t in (1,3,5,7,9,None):
  es=[e for e in oc['episodes'] if e['T']==t]
  if not es:continue
  vals=[e['U'] for e in es];m=statistics.mean(vals);se=statistics.stdev(vals)/math.sqrt(len(vals)) if len(vals)>1 else None;remaining=10-t if t is not None else None
  if remaining in (5,7,9):
   ks=[e['U'][str(remaining)] for e in kc['episodes']];k=statistics.mean(ks);kse=statistics.stdev(ks)/math.sqrt(len(ks))
  elif remaining==3:k=float(F(oc['frozen_H']));kse=0
  else:k=0;kse=0
  combined=math.hypot(se,kse) if se is not None else None;error=k-m;r['rows'].append(dict(context=oc['context'],target=oc['target'],T=t,n=len(vals),actual_conditional_U=m,kernel_U=k,residual=error,combined_mean_SE=combined,normal_approx_95=[error-1.96*combined,error+1.96*combined] if combined is not None else None,outer_probability=len(vals)/len(oc['episodes']),contribution_to_total_residual=error*len(vals)/len(oc['episodes'])))
out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
for x in r['rows']:print(x['context'],x['target'],x['T'],'n',x['n'],'d',round(x['residual'],5),'CI',x['normal_approx_95'],'weighted',round(x['contribution_to_total_residual'],5))
