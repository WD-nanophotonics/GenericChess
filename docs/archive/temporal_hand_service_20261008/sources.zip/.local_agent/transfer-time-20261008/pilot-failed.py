"""Fixed six-transition path observable; bounded pilot, no price fit."""
import sys,json,hashlib,time,random,math
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=ROOT/'.local_agent/transfer-time-20261008';p.mkdir(exist_ok=True);out=p/'pilot.json';assert not out.exists();begin=time.perf_counter();old=ROOT/'.local_agent/paired-context-20261008';a=json.loads((old/'rook-pressure.json').read_bytes());b=json.loads((old/'joint-context.json').read_bytes());census=json.loads((old/'recipient-census.json').read_bytes())
N=512
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies={n:hashlib.sha256((old/n).read_bytes()).hexdigest() for n in ('rook-pressure.json','joint-context.json','recipient-census.json')},declaration='Predeclared equal King0,0/0,1 contexts, pairedG/TP.512independent RNG episode seeds per context shared across targets as common quantiles, fixed6actual transitions. Every actual legal action uniform except a held unique tagged baseG/P is dropped uniformly when legal (either owner), otherwise ordinary uniform legal policy. Target base is unique in these five-entity games; validate conservation board+hands==1. First transfer is first ownership0, atply1/3/5; nontransfer paths have reward0. U at final node6 is distinct legal endpoints of tagged piece if currently owner0/onboard and side0, terminal0 separately recorded. This is endpoint opportunity at node6, not executed reward or material utility. Compare joint meanU with usable-first-transfer-by3 frequency times independently frozen conditionalH at3transitions after capture, context-conditioned. A stationary remaining-time approximation, not the tautological p*same-sample conditionalmean. Both pilot uncertainty and policy/context mismatch qualify error; no fitting/defaults. Native/Core all sampled legal sets and full transitions/terminal checked. Initial batch512percell/300sec checkpoint, one process; partial preserved, no automatic extension.',N=N,cases=[])
write_record(out,r)
try:
 for context,source in enumerate((a,b)):
  for original in source['cases']:
   target=original['target'];tid='G' if target=='G' else 'P';compiled=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));nr=compile_native_semantic_rules(compiled);initial=initial_state(compiled)
   oldH=next(x['H'] for x in (census['cases'] if context==0 else b['cases']) if x['target']==target)
   case=dict(context=context,target=target,frozen_H=oldH,episodes=[],complete=False,transitions=0);r['cases'].append(case)
   for episode in range(N):
    assert time.perf_counter()-begin<300,'pilot checkpoint'
    rng=random.Random(2026100800+context*100000+episode);s=initial;m=NativeSemanticPositionMirror.from_state(compiled,nr,s,history_certified=True);np=m.position;T=None;route=[]
    for ply in range(7):
     tag=[(i,piece) for i,piece in enumerate(s.position.board) if piece is not None and piece.base_type_id==tid]
     assert len(tag)+sum(h.count(tid) for h in s.position.hands)==1
     owner=tag[0][1].owner if tag else next(o for o,h in enumerate(s.position.hands) if h.count(tid))
     if T is None and owner==0:T=ply
     nas=guarded_actions(nr,np);actions=legal_actions(s,compiled);assert set(actions)=={public_action(nr,x) for x in nas}
     nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner)
     if ply==6 or not actions:
      U=len({(x.to_square.file,x.to_square.rank) for x in actions if tag and owner==0 and hasattr(x,'from_square') and x.from_square.file+9*x.from_square.rank==tag[0][0]}) if ply==6 and s.position.side_to_move==0 else 0
      case['episodes'].append(dict(seed=episode,T=T,U=U,terminal=record_value(s.terminal_status),route=route));break
     drops=[x for x in actions if getattr(x,'base_type_id',None)==tid];pool=drops or list(actions);action=pool[rng.randrange(len(pool))];na,=[x for x in nas if public_action(nr,x)==action]
     s=apply_action(s,action,compiled);np=make_checked(nr,np,na);assert snapshot_matches(snapshot(nr,np),s.position,nr,compiled);route.append(record_value(action));case['transitions']+=1
   else:raise AssertionError('episode loop')
   values=[x['U'] for x in case['episodes']];mean=sum(values)/N;se=math.sqrt(sum((x-mean)**2 for x in values)/(N-1)/N);counts=Counter(str(x['T']) for x in case['episodes']);usable=sum(x['T'] in (1,3) for x in case['episodes'])/N
   from fractions import Fraction
   prediction=usable*float(Fraction(oldH));case.update(complete=True,summary=dict(mean_U=mean,standard_error=se,transfer_times=dict(counts),usable_transfer_probability=usable,stationary_prediction=prediction,error=prediction-mean,conditional_U={str(t):sum(x['U'] for x in case['episodes'] if x['T']==t)/sum(x['T']==t for x in case['episodes']) for t in (None,1,3,5) if any(x['T']==t for x in case['episodes'])}));write_record(out,r);print(context,target,case['summary'],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-begin;write_record(out,r)
