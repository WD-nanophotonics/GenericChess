"""Two independent sampling sources; time-aware kernel prediction."""
import json,hashlib,math,statistics
from pathlib import Path
from fractions import Fraction as F
p=Path(__file__).parent;out=p/'kernel-analysis-disjoint.json';assert not out.exists();outer=json.loads((p/'horizon10.json').read_bytes());kernel=json.loads((p/'kernel-disjoint.json').read_bytes());assert outer['complete'] and kernel['complete']
def stats(v):
 mean=statistics.mean(v);se=statistics.stdev(v)/math.sqrt(len(v));return dict(n=len(v),mean=mean,standard_error=se,normal_approx_95=[mean-1.96*se,mean+1.96*se])
r=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ('horizon10.json','kernel-disjoint.json')},scope='Independent outer first-transfer/actual-U batch and forced-initial-capture service kernel. Kernel3 uses prior exactH3; kernel5/7/9 independent sample means. First-order delta normal diagnostics combine outer residual and kernel influence variances; not finite-sample bounded coverage or material-price accuracy. Common seed pairing across types is retained for contrast uncertainty. No coefficients chosen against outcomes; delayed-capture contexts are still approximated by initial postcapture contexts.',rows=[],contrasts=[])
work={}
for oc in outer['cases']:
 context,target=oc['context'],oc['target'];kc=next(c for c in kernel['cases'] if c['context']==context and c['target']==target);H=float(F(oc['frozen_H']));K={int(t):v for t,v in kc['means'].items()};K[3]=H;es=oc['episodes'];ks=kc['episodes'];prob={t:sum(e['T']==t for e in es)/len(es) for t in (1,3,5,7)}
 old=[H*(e['T'] in prob)-e['U'] for e in es];new=[K[10-e['T']]-e['U'] if e['T'] in prob else -e['U'] for e in es]
 influence=[sum(prob[t]*(e['U'][str(10-t)]-K[10-t]) for t in (1,3,5)) for e in ks]
 os=stats(new);ki=stats(influence);se=math.hypot(os['standard_error'],ki['standard_error']);mean=os['mean'];row=dict(context=context,target=target,kernel=K,first_transfer_probability=prob,actual_mean_U=oc['summary']['mean_U'],constant_prediction=oc['summary']['stationary_prediction'],time_prediction=mean+oc['summary']['mean_U'],constant_residual=stats(old),time_residual=dict(mean=mean,outer_SE=os['standard_error'],kernel_SE=ki['standard_error'],combined_first_order_SE=se,normal_approx_95=[mean-1.96*se,mean+1.96*se]),sampled_H3_sanity=stats([e['U']['3'] for e in ks]),paired_H9_minus_H3=stats([e['U']['9']-e['U']['3'] for e in ks]));r['rows'].append(row);work[context,target]=(new,influence)
for context in (0,1):
 g,gi=work[context,'G'];pawns,pi=work[context,'TP'];a=stats([x-y for x,y in zip(g,pawns)]);b=stats([x-y for x,y in zip(gi,pi)]);se=math.hypot(a['standard_error'],b['standard_error']);r['contrasts'].append(dict(context=context,time_prediction_minus_actual_G_P=a['mean'],outer_SE=a['standard_error'],kernel_SE=b['standard_error'],combined_first_order_SE=se,normal_approx_95=[a['mean']-1.96*se,a['mean']+1.96*se]))
out.write_bytes((json.dumps(r,indent=2,sort_keys=True)+'\n').encode())
for row in r['rows']:print(row['context'],row['target'],'actual',row['actual_mean_U'],'old',row['constant_prediction'],'time',row['time_prediction'],'residual',row['time_residual'])
print(r['contrasts'])
