"""Independent capture-conditioned remaining-time kernel, not fitted prices."""
import sys,json,hashlib,time,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror,snapshot_matches
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;old=ROOT/'.local_agent/paired-context-20261008';sources=[json.loads((old/n).read_bytes()) for n in ('rook-pressure.json','joint-context.json')];out=p/'kernel-disjoint.json';assert not out.exists();start=time.perf_counter();N=2048
r=dict(complete=False,N=N,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependencies={n:hashlib.sha256((old/n).read_bytes()).hexdigest() for n in ('rook-pressure.json','joint-context.json')},declaration='Correction declared before execution: old202610083000kernel and202610082000outer each2048seeds overlap1048seeds percontext, so old independent-source SE was unqualified. Preserve original producer/results and do not treat that analysis as independent validation. New base202610090000+100000context creates disjoint intervals, no changed estimator/horizon/N/policy/resource ceiling. Declared before execution:2048independent seeds per context/target,base202610090000+100000*context+episode, shared quantiles acrossG/TP. Force the actual initial Ncapture, then same uniform ordinary actions/priority unique-tag legal drop policy as outer six/ten-step batches. Measure U at3/5/7/9actual transitions after capture, including recapture/terminal zeros and possible promotion. Old exactH3 remains primary kernel3; sampled3 is a sanity control. Full sampled Core/Native action/state/terminal parity. Ten-step prediction sum_t empiricalP(T=t)*H(10-t),t1/3/5/7, independent kernel samples; this still approximates delayed-capture context by initial postcapture context and cannot identify material values.8192episodes,73728postcapture transitions, one300sec checkpoint/no automatic extension. No horizon or kernel fit against human/outer outcomes.',cases=[]);write_record(out,r)
try:
 for context,source in enumerate(sources):
  for original in source['cases']:
   tid='G' if original['target']=='G' else 'P';c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));nr=compile_native_semantic_rules(c);s0=initial_state(c)
   capture,=[a for a in legal_actions(s0,c) if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==(3,2) and (a.to_square.file,a.to_square.rank)==(4,4)]
   m0=NativeSemanticPositionMirror.from_state(c,nr,s0,history_certified=True);na,=[a for a in guarded_actions(nr,m0.position) if public_action(nr,a)==capture];post=apply_action(s0,capture,c);np0=make_checked(nr,m0.position,na);assert snapshot_matches(snapshot(nr,np0),post.position,nr,c)
   case=dict(context=context,target=original['target'],capture=record_value(capture),complete=False,episodes=[],transitions=0);r['cases'].append(case)
   for episode in range(N):
    assert time.perf_counter()-start<300,'kernel checkpoint';rng=random.Random(202610090000+100000*context+episode);s=post;np=np0;route=[];values={};last=None
    for step in range(10):
     tag=[(i,piece) for i,piece in enumerate(s.position.board) if piece is not None and piece.base_type_id==tid];assert len(tag)+sum(h.count(tid) for h in s.position.hands)==1
     owner=tag[0][1].owner if tag else next(o for o,h in enumerate(s.position.hands) if h.count(tid));nas=guarded_actions(nr,np);actions=legal_actions(s,c);assert set(actions)=={public_action(nr,a) for a in nas};nt=terminal_status(nr,np);assert (nt['status'],nt['winner'])==(s.terminal_status.status.value,s.terminal_status.winner)
     if step in (3,5,7,9):values[str(step)]=len({(a.to_square.file,a.to_square.rank) for a in actions if tag and owner==0 and hasattr(a,'from_square') and a.from_square.file+9*a.from_square.rank==tag[0][0]}) if not s.terminal_status.is_terminal else 0
     if step==9 or not actions or s.terminal_status.is_terminal:
      for k in (3,5,7,9):values.setdefault(str(k),0)
      case['episodes'].append(dict(seed=episode,U=values,terminal=record_value(s.terminal_status),route=route));break
     drops=[a for a in actions if getattr(a,'base_type_id',None)==tid];pool=drops or list(actions);action=pool[rng.randrange(len(pool))];na,=[a for a in nas if public_action(nr,a)==action];s=apply_action(s,action,c);np=make_checked(nr,np,na);assert snapshot_matches(snapshot(nr,np),s.position,nr,c);route.append(record_value(action));case['transitions']+=1
   assert len(case['episodes'])==N;case.update(complete=True,means={str(k):sum(e['U'][str(k)] for e in case['episodes'])/N for k in (3,5,7,9)});write_record(out,r);print(context,original['target'],case['means'],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
