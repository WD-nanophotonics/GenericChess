import sys,json,hashlib,math,statistics
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'validation.json';raw=json.loads(src.read_bytes());assert raw['complete'];old=ROOT/'.local_agent/paired-context-20261008';defs=[json.loads((old/n).read_bytes()) for n in ('rook-pressure.json','joint-context.json')];rows=[]
def stats(values):
 n=len(values);mean=statistics.mean(values);se=statistics.stdev(values)/math.sqrt(n) if n>1 else None;return dict(n=n,mean=mean,standard_error=se,normal_approx_95=(mean-1.96*se,mean+1.96*se) if se is not None else None)
for case in raw['cases']:
 d=next(x['definition'] for x in defs[case['context']]['cases'] if x['target']==case['target']);c=compile_ruleset_for_execution(ruleset_from_dict(d));tid='G' if case['target']=='G' else 'P';paired=[];H=float(F(case['frozen_H']));residual=[]
 for e in case['episodes']:
  residual.append(H*(e['T'] in (1,3))-e['U'])
  if e['T']!=1:continue
  s=initial_state(c);u4=None
  for ply,enc in enumerate(e['route'],1):
   a,=[x for x in legal_actions(s,c) if record_value(x)==enc];s=apply_action(s,a,c)
   if ply==4:
    tag=[i for i,piece in enumerate(s.position.board) if piece is not None and piece.base_type_id==tid and piece.owner==0]
    assert len(tag)<=1
    u4=len({(x.to_square.file,x.to_square.rank) for x in legal_actions(s,c) if tag and hasattr(x,'from_square') and x.from_square.file+9*x.from_square.rank==tag[0]}) if not s.terminal_status.is_terminal else 0
  if u4 is not None:paired.append(e['U']-u4)
 rows.append(dict(context=case['context'],target=case['target'],residual=stats(residual),paired_extra_cycle_U_change=stats(paired),conditional=case['summary']['conditional_U']))
out=p/'validation-analysis.json';assert not out.exists();write_record(out,dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),scope='Analysis of frozen trajectories, not added samples. Residual indicator*oldH-U uncertainty accounts for their within-episode covariance. Normal approximate intervals are diagnostics, not bounded rigorous confidence claims. Replayed same first-transfer1 paths compare U after4/6transitions; no Native claim added for analysis, all original routes already fully replayed.',rows=rows));print(rows)
