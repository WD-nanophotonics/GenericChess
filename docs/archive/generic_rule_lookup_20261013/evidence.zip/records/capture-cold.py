import copy,json,sys,sysconfig,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));B=Path(__file__).parent
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.compiler import build_semantic_compile_payload
compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));payload,_=build_semantic_compile_payload(compiled)
pattern=copy.deepcopy(next(p for p in payload['patterns'] if p['target']==1 and p['type_indices']==[0] and not p['guards'] and not p['slot_guards']))
drop_gid=next(i for i,g in enumerate(payload['geometries']) if g['kind']==2)
import time
from scripts.research_record import write_record
write_record(B/'capture-cold-declaration.json',dict(question='Does fixed index allocation/build dominate short-lived public capsule consumers?',descriptors=['ordinary-chess','existing256-lastwitness'],orders=[['actor-first','capture-index'],['capture-index','actor-first']],repetitions=1,reused_queries=20000,scope='Onecold sample perorder, separatecompile/export/pack/firstattack andwarmquerybatch. Not noisycoldspeedguarantee; currentfreshtransfer/tests running ordinaryload. No newrootset, no queryresultcache.'))
modules={}
for arm in ['actor-first','capture-index']:
 path=B/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location(arm+'_cold._native_core',path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
board=[None]*64;board[27]=[0,0,0,0];state=dict(board=board,hands=[[0]*6,[0]*6],side=0,ply=0)
bound=copy.deepcopy(payload);bound['patterns']=[]
for i in range(256):
 pat=copy.deepcopy(pattern);pat['type_indices']=[0]*255
 if i!=255:pat['geometry_indices']=[drop_gid]
 bound['patterns'].append(pat)
rows=[]
for name,p in [('ordinary-chess',payload),('existing256-lastwitness',bound)]:
 for order,arms in enumerate([['actor-first','capture-index'],['capture-index','actor-first']]):
  for arm in arms:
   m=modules[arm];start=time.perf_counter_ns();rules=m.compile_semantic_rules(p);after_compile=time.perf_counter_ns();info=m.semantic_rules_info(rules);assert info==p;after_info=time.perf_counter_ns();position=m.semantic_pack_position(rules,state);after_pack=time.perf_counter_ns();value=m.semantic_is_square_attacked(rules,position,36,0);after_first=time.perf_counter_ns();snap=m.semantic_position_snapshot(rules,position)
   start_warm=time.perf_counter_ns()
   for _ in range(20000):assert m.semantic_is_square_attacked(rules,position,36,0)==value
   end_warm=time.perf_counter_ns();assert m.semantic_position_snapshot(rules,position)==snap
   rows.append(dict(descriptor=name,arm=arm,order=order,compile_ns=after_compile-start,export_ns=after_info-after_compile,pack_ns=after_pack-after_info,first_query_ns=after_first-after_pack,cold_total_ns=after_first-start,warm_queries=20000,warm_batch_ns=end_warm-start_warm,query_value=value,payload_exact=True,root_restored=True))
write_record(B/'capture-cold-result.json',dict(rows=rows,one_live_rules_capsule_percell=True,incremental_rules_bytes=32896,scope='Ordinaryconcurrentload andonecoldsample/order; warmPythonFFI/assert loop overheadincluded; not pureCPU/memoryRSS or noiseremoved amortization.'))
print(rows)
