#include "native_semantic_rules.h"
__declspec(dllexport) size_t test_layout(int n){return n==0?sizeof(GCSemPathOwner):n==1?sizeof(GCSemGeometry):sizeof(GCSemanticRules);}
