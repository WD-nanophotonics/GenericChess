import copy,json,sys,sysconfig,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));B=Path(__file__).parent
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.compiler import build_semantic_compile_payload
compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));payload,_=build_semantic_compile_payload(compiled)
pattern=copy.deepcopy(next(p for p in payload['patterns'] if p['target']==1 and p['type_indices']==[0] and not p['guards'] and not p['slot_guards']))
drop_gid=next(i for i,g in enumerate(payload['geometries']) if g['kind']==2)
rows=[]
for arm in ['actor-first','capture-index']:
 path=B/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location(arm+'_bound._native_core',path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
 base=copy.deepcopy(payload);base['patterns']=[copy.deepcopy(pattern)];rc=m.compile_semantic_rules(base)
 for owner in (0,1):
  cells=[None]*64;cells[27]=[0,0,owner,0];state=dict(board=cells,hands=[[0]*6,[0]*6],side=owner,ply=0)
  pp=m.semantic_pack_position(rc,state);expected=m.semantic_attacked_squares(rc,pp,owner);assert expected
  for last_witness in (False,True):
   p=copy.deepcopy(payload);patterns=[]
   for i in range(256):
    pat=copy.deepcopy(pattern);pat['type_indices']=[0]*255
    if i!=255 or not last_witness:pat['geometry_indices']=[drop_gid]
    patterns.append(pat)
   p['patterns']=patterns;rules=m.compile_semantic_rules(p);assert m.semantic_rules_info(rules)==p
   pos=m.semantic_pack_position(rules,state);snapshot=m.semantic_position_snapshot(rules,pos)
   actual=m.semantic_attacked_squares(rules,pos,owner)
   assert tuple(actual)==tuple(expected if last_witness else ()), (arm,owner,last_witness,actual,expected)
   for target in range(64): assert m.semantic_is_square_attacked(rules,pos,target,owner)==(target in actual)
   assert m.semantic_position_snapshot(rules,pos)==snapshot
   rows.append(dict(arm=arm,owner=owner,patterns=256,duplicate_type_entries=255,last_witness=last_witness,attack_count=len(actual),exact_roundtrip=True,root_restored=True))
(B/'capture-index-boundary.json').write_text(json.dumps(dict(rows=rows,scope='Synthetic accepted numeric capsule boundary, not reachablegame orfingerprintclaim; only256th capture-pattern can witness, repeatedselector entries mustnotduplicateindex oroverflow uint16count.'),indent=2),encoding='utf-8');print('boundarycases',len(rows))
