from pathlib import Path
import sys,sysconfig,importlib.util,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution,build_builtin_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.material import LearnableMaterialCheckpoint
from scripts.search_backend_comparison import CASES,CoreBoard,VALUES
from scripts.research_record import write_record,record_value
from types import SimpleNamespace
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));case=next(x for x in CASES if x['id']=='shogi-middle');b=CoreBoard(case,c);session=SimpleNamespace(compiled=c,state=b.initial,_search_witnesses=b.witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));nr=compile_native_semantic_rules(c)
ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={})
e=SemanticSearchEngine(c,nr,board_values=VALUES['shogi'],hand_values=VALUES['shogi'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2,ordering_cache_enabled=False)

modules={}
for arm in ['path-sorted','lookup-o3']:
 path=OUT/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location(arm+'_pad._native_core',path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
write_record(OUT/'compiler-o3-d5-declaration.json',dict(calls=4,orders=[['path-sorted','lookup-o3'],['lookup-o3','path-sorted']],case='shogi-middle',depth=5,node_cap=1000000,seconds=64,q=0,TT_MiB=1,min2_uncached=True,scope='Cleanwholecaller finitework after exactdigest qualification; no instrumentedranking andnoother source difference. Compare allnontime publicfields andrawkernelstats, coldengines, samehistory/promo/drops; fourcall cap, noresult-drivenextension.'))
rows=[];expected=None
for pair,arms in enumerate([['path-sorted','lookup-o3'],['lookup-o3','path-sorted']]):
 for arm in arms:
  native._MODULE=modules[arm];nr=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,nr,board_values=VALUES['shogi'],hand_values=VALUES['shogi'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2,ordering_cache_enabled=False)
  started=time.perf_counter();result=engine.search(session,SearchLimits(max_depth=5,max_nodes=1000000,max_time_seconds=64,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-started
  assert result.completed_depth==5 and result.termination_reason=='completed' and session.state==b.initial
  rr=record_value(result);plain={k:v for k,v in rr.items() if 'elapsed' not in k}
  if expected is None:expected=plain
  assert plain==expected
  rows.append(dict(pair=pair,arm=arm,seconds=elapsed,result=rr,root_restored=True));write_record(OUT/'compiler-o3-d5-result.json',rows);print(pair,arm,elapsed,flush=True)
