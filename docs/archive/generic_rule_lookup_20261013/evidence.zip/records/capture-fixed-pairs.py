import sys,json,time,importlib.util,sysconfig,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent
from scripts.search_backend_comparison import CASES,VALUES,CoreBoard
from scripts.native_backend_bridge import NativeBoard
from generic_chess import compile_ruleset_for_execution,build_builtin_ruleset
from generic_chess.native.semantic import fixed_depth_search,snapshot
from scripts.research_record import write_record
import generic_chess.native as native
modules={}
for name in ['actor-first','capture-index']:
 p=OUT/name/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location(name+'_paired._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[name]=m
write_record(OUT/'capture-fixed-pairs-declaration.json',dict(question='Does source-first scalarattack reorder improve the existing qualifiedsameorder fixedChess/Shogi bridge while old/current complete output matches?',calls=32,cases=[x['id'] for x in CASES],depth={'chess':4,'shogi':3},orders=[['actor-first','capture-index'],['capture-index','actor-first']],scope='Samefrozenleaf/packedorder/fullhistory directC, currentbefore/afterruntime only. ExistingfourChessD4/fourShogiD3 cells unchanged, earlierbridges untouched;32boundedcalls, notnewroot/timeplane. Ratiosagainstpreviousspecialist retainedasreference, no purelanguage/persistent attribution. Tinycase explicitlyno timing inference, ordinaryconcurrentload. Fullresult equality andparentrestoration required. No result-driven extension.',modules={k:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for k,m in modules.items()}))
rows=[]
for case in CASES:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));core=CoreBoard(case,c);expected=None
 for pair,arms in enumerate([['actor-first','capture-index'],['capture-index','actor-first']]):
  for arm in arms:
   native._MODULE=modules[arm];b=NativeBoard(core,VALUES[case['game']]);before=snapshot(b.native,b.position);t=time.perf_counter();r=fixed_depth_search(b.native,b.position,4 if case["game"]=="chess" else 3,board_values=b.values,hand_values=b.values);elapsed=time.perf_counter()-t
   assert snapshot(b.native,b.position)==before and b.restored()
   if expected is None:expected=r
   assert r==expected
   rows.append(dict(case=case['id'],pair=pair,arm=arm,seconds=elapsed,result=r,root_restored=True));write_record(OUT/'capture-fixed-pairs.json',rows);print(case['id'],pair,arm,round(elapsed,6),flush=True)
