import sys,sysconfig,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
p=ROOT/'.local_agent/core-consumer-20261013/path-sorted'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
sp=importlib.util.spec_from_file_location('threshold_full._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m;sys.modules["generic_chess._native_core"]=m
import generic_chess;generic_chess._native_core=m
import pytest
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(ROOT/'.local_agent/core-consumer-20261013/path-sorted-tests-temp'),'--junitxml',str(ROOT/'.local_agent/core-consumer-20261013/path-sorted-tests.xml')]))
