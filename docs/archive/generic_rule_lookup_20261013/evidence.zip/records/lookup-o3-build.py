from pathlib import Path
import sys,sysconfig,os,subprocess,importlib.util,json
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).parent;src=ROOT/"generic_chess/_native"
spec=importlib.util.find_spec('ziglang');zig=Path(spec.origin).parent/'zig.exe';binary=OUT/('lookup-o3/_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));binary.parent.mkdir(exist_ok=True)
cmd=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O3','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(x) for x in sorted(src.glob('*.c'))]+['-o',str(binary)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(OUT/'counter-zig-cache')));assert built.returncode==0,built.stderr

print(binary)
