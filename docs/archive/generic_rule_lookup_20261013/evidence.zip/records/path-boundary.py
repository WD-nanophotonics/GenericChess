import sys,sysconfig,copy,json,importlib.util,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));B=Path(__file__).parent
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native.compiler import build_semantic_compile_payload
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));base,_=build_semantic_compile_payload(c)
pattern=copy.deepcopy(next(p for p in base['patterns'] if p['target']==1 and p['type_indices']==[0] and not p['guards'] and not p['slot_guards']));pattern['geometry_indices']=[0];base['patterns']=[pattern]
cases={'unique_sorted':[[0,[9]],[27,[36]],[50,[59]]],'duplicate_sorted':[[0,[9]],[27,[36]],[27,[45]],[50,[59]]],'duplicate_unsorted':[[50,[59]],[27,[36]],[0,[9]],[27,[45]]],'missing_unsorted':[[50,[59]],[0,[9]]],'empty':[], 'max65535_sorted':[[27,[36]]]+[[27,[45]]]*65534}
modules={}
for arm in ('capture-index','path-sorted'):
 p=B/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location(arm+'_pathtruth._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
rows=[];t=time.perf_counter()
for name,entries in cases.items():
 payload=copy.deepcopy(base);payload['geometries'][0]['paths']=[entries,entries]
 for owner in (0,1):
  board=[None]*64;board[27]=[0,0,owner,0];state=dict(board=board,hands=[[0]*6,[0]*6],side=owner,ply=0)
  expected={36} if name not in ('missing_unsorted','empty') else set()
  for arm,m in modules.items():
   rules=m.compile_semantic_rules(payload);assert m.semantic_rules_info(rules)==payload
   pos=m.semantic_pack_position(rules,state);snap=m.semantic_position_snapshot(rules,pos)
   assert set(m.semantic_attacked_squares(rules,pos,owner))==expected,(name,arm,owner)
   for square in range(64):assert m.semantic_is_square_attacked(rules,pos,square,owner)==(square in expected)
   assert m.semantic_position_snapshot(rules,pos)==snap
   rows.append(dict(case=name,entries=len(entries),owner=owner,arm=arm,exact_roundtrip=True,scalar_and_set_match_first_source_entry=True,restored=True))
(B/'path-boundary.json').write_text(json.dumps(dict(rows=rows,seconds=time.perf_counter()-t,scope='Acceptednumericpayload synthetic ordering/duplicate-first/empty/missing/max65535 boundary, independentexplicitexpectedtarget36not45; no game or semanticfingerprintclaim.'),indent=2),encoding='utf-8');print('pathboundary',len(rows),time.perf_counter()-t)
