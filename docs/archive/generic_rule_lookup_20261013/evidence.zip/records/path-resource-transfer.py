import sys,time,json,random,sysconfig,importlib.util,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent/'path-resource-transfer';OUT.mkdir(exist_ok=True);assert not(OUT/'declaration.json').exists()
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record,record_value
import generic_chess.native as native
seeds=[2026101351,2026101352,2026101353,2026101354,2026101355,2026101356,2026101357,2026101358];budgets=[16]
write_record(OUT/'declaration.json',dict(question='Do matched16s budgets give a completed-depth benefit from sorted-source lower_bound withoriginalunordered fallback aftercaptureindex transfer to fresh generated rules, rather than only the exposedGen2 boundary?',seeds=seeds,budgets=budgets,depth=12,node_cap=None,calls=32,max_search_seconds=512,walk=8,walk_seed_offset=9000,scope='Shared8-rule developmentpanel after indexplane began, not fresh independent roots or statisticalholdout. Preserve fullgeneratedrule target and allstate/history, allowhybrids/drop/promotion. Natural type-index leaf control, K0; samefrozen per-rule orderingprofile/min2/uncached/1MiBTT andq0. Bothcurrentkernels differonly compiler-marked pathlookup; sameeight1351..58 rules predeclaredforrunningindexplane, exposeddevelopmental reuse no tuned roots orlabels, full existing regression plus scalar/bulk independent truth checks required beforelaunch. Unavailable/terminal roots kept/skippedwithoutreplacement, no adaptive extension/Elo/default/UI change. Ordinaryload. Changedexecution separate resourceplane, oldcaps immutable.'))
modules={}
for arm in ['capture-index','path-sorted']:
 p=OUT.parent/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location(arm+'_fresh._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
write_record(OUT/'modules.json',{k:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for k,m in modules.items()})
rows=[];samples=[]
for seed in seeds:
 native._MODULE=modules['capture-index'];g=generate_game(GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));source=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=source.ir,_legacy_compiled=source._legacy_compiled,support=source.support);session=GameSession(c);rng=random.Random(seed+9000)
 for _ in range(8):
  if session.result.status.value!='ongoing':break
  aa=sorted(session.legal_actions(),key=repr)
  if not aa:break
  session.submit(rng.choice(aa))
 samples.append(dict(seed=seed,rules=serialize_ruleset(g.ruleset),state=record_value(session.state),witnesses=record_value(session._search_witnesses)));write_record(OUT/'inputs.json',samples)
 if session.result.status.value!='ongoing' or session.state.ply_count!=8:
  rows.append(dict(seed=seed,unavailable='terminal/prefix unavailable',no_replacement=True));write_record(OUT/'result.json',dict(complete=False,rows=rows));continue
 nr=compile_native_semantic_rules(c);bv={tid:0 if tid=='K' else 100*(i+1) for i,tid in enumerate(nr.type_ids)};ordering=LearnableMaterialCheckpoint.from_profile(c,build_ruleset_profile(c,EvaluationConfig()),dynamic_weights={});before=record_value(session.state)
 for sec in budgets:
  for pair,arms in enumerate([['capture-index','path-sorted'],['path-sorted','capture-index']]):
   for arm in arms:
    for flag in ['rollout','advisor','slack']:
     f=json.loads((ROOT/'.local_agent'/(flag+'.json')).read_bytes());assert not f.get('stopped') and not f.get('user_paused')
    native._MODULE=modules[arm];nr=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,nr,board_values=bv,hand_values=bv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1,ordering_checkpoint=ordering,ordering_min_depth=2,ordering_cache_enabled=False)
    t=time.perf_counter();r=engine.search(session,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=sec,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);elapsed=time.perf_counter()-t
    assert record_value(session.state)==before and r.termination_reason!='internal_error';ss=session.state
    for a in r.principal_variation:assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
    assert r.action in legal_actions(session.state,c)
    rows.append(dict(seed=seed,seconds_requested=sec,pair=pair,arm=arm,caller_seconds=elapsed,result=record_value(r),root_restored=True,pv_legal=True,board_values=bv,hand_values=bv));write_record(OUT/'result.json',dict(complete=False,rows=rows));print(seed,sec,pair,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,flush=True)
write_record(OUT/'result.json',dict(complete=True,rows=rows))
