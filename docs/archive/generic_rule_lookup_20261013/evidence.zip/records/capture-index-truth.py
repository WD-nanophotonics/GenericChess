from pathlib import Path
import sys,sysconfig,importlib.util,time,json
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'tests')];OUT=Path(__file__).parent
from phase19c1_native_semantic_fixtures import semantic_corpus
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.core.position import Position,Hands
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import pack_current_position,is_square_attacked,attacked_squares,snapshot
import generic_chess.native as native
from scripts.research_record import write_record
modules={}
for arm in ['actor-first','capture-index']:
 p=OUT/arm/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location(arm+'_truth._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[arm]=m
write_record(OUT/'capture-index-truth-declaration.json',dict(question='Does directattack existential truth survive loopreorder across every square/owner and existingsemanticstress corpus rather than only royal safety?',scope='Existingcorpus6legalprefixstates, no addedrules/targetfit; comparePythonSemanticEngine andold/current scalars andbatched sets. Stateonlypack isdeclaredattackconsumer, notterminal/historycomparison. Stopterminal/noactions withoutreplacement; retainallfixtures.'))
rows=[];t=time.perf_counter()
for name,c in semantic_corpus():
 board=tuple(piece for row in c.support.initial_position for piece in row);pos=Position(board,(Hands.empty(),Hands.empty()),0,c.support.ruleset_fingerprint);engine=SemanticEngine(c)
 for ply in range(6):
  expected={owner:frozenset(sq for sq in range(len(board)) if engine.is_square_attacked(pos,sq,owner)) for owner in (0,1)}
  for arm in modules:
   native._MODULE=modules[arm];nr=compile_native_semantic_rules(c);pp=pack_current_position(nr,pos,ply_count=ply);before=snapshot(nr,pp)
   for owner in (0,1):
    actual=frozenset(sq for sq in range(len(board)) if is_square_attacked(nr,pp,sq,owner));assert actual==expected[owner],(name,ply,arm,owner,actual,expected[owner]);assert attacked_squares(nr,pp,owner)==expected[owner]
   assert snapshot(nr,pp)==before
  rows.append(dict(fixture=name,ply=ply,squares=len(board),scalar_queries=len(board)*4,sets=4,all_match=True))
  actions=sorted(engine.legal_actions(pos),key=repr)
  if not actions:break
  pos=engine.apply(pos,actions[0])
write_record(OUT/'capture-index-truth-result.json',dict(rows=rows,scalar_queries=sum(x['scalar_queries'] for x in rows),seconds=time.perf_counter()-t,all_match=True));print('states',len(rows),'queries',sum(x['scalar_queries'] for x in rows),'seconds',time.perf_counter()-t)
