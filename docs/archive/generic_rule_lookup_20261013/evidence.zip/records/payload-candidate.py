def _state_only_payload(self, position, ply_count):
    """Build exactly the F20 state-only payload; never read history/SHA."""
    type_map = self.type_map
    board = []
    for piece in position.board:
        if piece is None:
            board.append(None)
            continue
        if piece.owner not in (0, 1):
            raise ValueError("Native legality payload has an invalid owner")
        try:
            base = type_map[piece.base_type_id]
            current = type_map[piece.current_type_id]
        except KeyError as exc:
            raise ValueError("Native legality payload has an unknown piece type") from exc
        board.append([base, current, int(piece.owner), 1 if piece.promoted else 0])

    hands = []
    for hand in position.hands:
        counts = [0] * len(self.type_ids)
        for type_id, count in hand.counts:
            if type_id not in type_map:
                raise ValueError("Native legality payload has an unknown hand type")
            if int(count) < 0:
                raise ValueError("Native legality payload has a negative hand count")
            counts[type_map[type_id]] = int(count)
        hands.append(counts)
    return {
        "side": int(position.side_to_move),
        "ply": int(ply_count),
        "board": board,
        "hands": hands,
        "aux_state": tuple(position.aux_state),
    }
