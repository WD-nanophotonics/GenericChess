import subprocess,sys,shutil,zipfile,json
from pathlib import Path
root=Path.cwd();export=root/'.local_agent/provider-source-export';export.mkdir(exist_ok=True)
files=subprocess.check_output(['git','ls-files','generic_chess','tests','scripts'],text=True).splitlines()
for name in files:
 if not name.endswith('.py'):continue
 target=export/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
for name in ('availability_core_20261011','representation_outcome_20261011','physical_outcome_20261011','provider_route_20261011','tt_consumer_20261011'):
 idx=json.loads((root/'docs/research/data'/f'{name}.json').read_text())
 with zipfile.ZipFile(root/idx['archive']['path']) as z:
  for member in z.namelist():
   if member.startswith('.local_agent/') and member.endswith('.py'):
    p=export/member;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(member))
code="import pathlib,generic_chess;from generic_chess.native import native_available;assert pathlib.Path(generic_chess.__file__).is_relative_to(pathlib.Path.cwd());assert not native_available();print('clean source;Native unavailable confirmed')"
p=subprocess.run([sys.executable,'-S','-c',code],cwd=export,capture_output=True,text=True);print(p.stdout);assert p.returncode==0,p.stderr
p=subprocess.run([sys.executable,'-S','-c',"import sys,runpy;sys.path.append("+repr(str(Path.cwd()/'.venv/Lib/site-packages'))+");runpy.run_path('.local_agent/availability-core-20261011/native_terminal_semantics.py',run_name='__main__')"],cwd=export,capture_output=True,text=True,timeout=60);print(p.stdout[-2500:]);print(p.stderr[-1000:]);assert p.returncode==0
receipt=dict(exit_code=p.returncode,scope='Clean tracked Python source and archived Python producers; native absent confirmed;56selected terminal/history/trial/typed regressions with normal Core fallback and explicit Native skips. No DLL/data/Slack copied.',stdout=p.stdout[-2500:],stderr=p.stderr[-1000:])
(root/'.local_agent/availability-core-20261011/clean-provider-export.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
