from pathlib import Path
from collections import Counter
import sys,time,json,math,hashlib,traceback
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.material import LearnableMaterialCheckpoint
D=R/'.local_agent/static-input-objective-20261018';S=R/'.local_agent/playability-filter-20261018';plan=json.loads((D/'plan.json').read_bytes());began=time.perf_counter();rows=[];models=[];counts=Counter();failed=[]
assert not(D/'coverage-started.json').exists();write_json(D/'coverage-started.json',dict(plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
for line in(S/'generations.jsonl').open(encoding='utf8'):
 if time.perf_counter()-began>plan['limits']['coverage_seconds']:raise TimeoutError('COVERAGE_CAP')
 for name in ('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());assert not(z.get('stopped')or z.get('user_paused'))
 g=json.loads(line)
 if not g['success']:continue
 try:
  c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']));p=build_ruleset_profile(c,EvaluationConfig());anchors={t.type_id for t in c.piece_types if t.is_anchor};types=set(c.types_by_id);assert set(p.board_value_by_type)==set(p.hand_value_by_base_type)==types
  board={t:0. if t in anchors else p.board_value_by_type[t]/1000 for t in types};hand={t:0. if t in anchors else p.hand_value_by_base_type[t]/1000 for t in types};assert all(math.isfinite(x)for x in list(board.values())+list(hand.values()));cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='existing-rule-only-generic-v2-fulltype-input-diagnostic',board_weights=board,hand_weights=hand,material_scale=256,value_scale=10.,reference_median=1.)
  rows.append(dict(key=g['key'],size=g['size'],setup=g['setup'],symmetry=g['symmetry'],filter=g['filter'],ruleset_fingerprint=c.ruleset_fingerprint,all_types=sorted(types),anchors=sorted(anchors),non_anchor_types=sorted(types-anchors),profile_board_values=dict(p.board_value_by_type),profile_hand_values=dict(p.hand_value_by_base_type),checkpoint_id=cp.checkpoint_id));models.append(dict(key=g['key'],checkpoint=cp.to_dict()));counts['rules']+=1;counts['nonstandard_type_rules']+=not(types<={'K','P','A','X'});counts['non_anchor_channels']+=2*len(types-anchors)
 except Exception as exc:failed.append(dict(key=g['key'],error=repr(exc)))
 if len(rows)%128==0:print('COVERED',len(rows),round(time.perf_counter()-began,3),flush=True)
write_json(D/'static-models.json',dict(rows=models));write_json(D/'coverage-result.json',dict(status='PASS_COMPLETE_COVERAGE'if not failed else'EXPLICIT_FAILURES',rows=rows,failures=failed,counts=dict(counts),seconds=time.perf_counter()-began,scope='Existingstatic profile fieldcoverage/finitecheckpoint construction only, noNativequery/learning/generation. Explicitanchors0, everyactualtype boardCURRENT/handBASE retained, no PAXprojection.'))
print('COVERAGE_DONE',dict(counts),len(failed),time.perf_counter()-began,flush=True)
