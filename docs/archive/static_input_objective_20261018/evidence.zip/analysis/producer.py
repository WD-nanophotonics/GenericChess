"""One finite Native leaf observation per saved complete state, no TD updates."""
from pathlib import Path
from copy import copy
from collections import Counter
from math import tanh
import json,sys,time,hashlib,traceback
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.limits import SearchLimits
D=R/'.local_agent/static-input-objective-20261018';S=R/'.local_agent/playability-filter-20261018';p=json.loads((D/'plan.json').read_bytes());gens={g['key']:g for g in map(json.loads,(S/'generations.jsonl').read_bytes().splitlines())};models={m['key']:m['checkpoint']for m in json.loads((D/'static-models.json').read_bytes())['rows']};rows=[];status='COMPLETE';reason=None;began=time.perf_counter();active=None;c=native=engine=None;refused=None;counts=Counter()
assert not (D/'started.json').exists();write_json(D/'started.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),frozen_points_sha256=hashlib.sha256((S/'points.jsonl').read_bytes()).hexdigest()))
def poll():
 if time.perf_counter()-began>=p['limits']['producer_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for name in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());assert not f.get('user_paused') and not f.get('stopped'),'EXPLICIT_STOP'
def phi(st):return[sum((1 if pc.owner==0 else -1)for pc in st.position.board if pc and pc.current_type_id==t)if kind=='board'else st.position.hands[0].count(t)-st.position.hands[1].count(t)for kind,t in channels]
try:
 with(D/'queries.jsonl').open('x',encoding='utf-8')as out:
  for line in(S/'points.jsonl').open(encoding='utf-8'):
   poll();item=json.loads(line);g=gens[item['key']]
   if active!=item['key']:
    engine=native=c=None;active=item['key'];refused=None;compile_start=time.perf_counter();c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']));types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);channels=[(k,t)for k in ('board','hand')for t in types];cp=LearnableMaterialCheckpoint.from_dict(models[active]);weights=cp.board_weights
    try:native=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,native,checkpoint=cp,tt_megabytes=0)
    except NativeUnsupportedRuleError as exc:refused=str(exc)
    compile_seconds=time.perf_counter()-compile_start
   s=GameSession.replay(c,deserialize_game_record(json.dumps(item['record'])));before=(s.state,s.to_record(),s.history,s._search_witnesses);row=dict(key=item['key'],slot=item['slot'],filter=item['filter'],prefix=item['target_prefix'],size=item['size'],setup=item['setup'],symmetry=item['symmetry'],checkpoint_id=cp.checkpoint_id,channels=channels,root_state_sha256=item['root_state_sha256'],compile_seconds=compile_seconds if item['target_prefix']==0 else 0.,status='TERMINAL_ROOT',gradient_nonzero=False,eligible_native_gradient=False,query_nodes=0,query_seconds=0.)
   if not item['ongoing']:row.update(root_actual_result=item['result'],raw_root_phi=phi(s.state),terminal_gradient_constant=True)
   elif refused is not None:row.update(status='NATIVE_EXPLICIT_REFUSAL',refusal=refused,gradient_nonzero=None)
   else:
    tick=time.perf_counter();r=engine.search(s,SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=p['query']['max_time_seconds'],quiescence_max_depth=0),root_window_pruning=False);elapsed=time.perf_counter()-tick;assert before==(s.state,s.to_record(),s.history,s._search_witnesses);counts['queries']+=1;counts['nodes']+=r.nodes;row.update(status='USABLE_NATIVE_RETURN'if r.completed_depth>=1 and not r.used_fallback else'INCOMPLETE_UNKNOWN',completed_depth=r.completed_depth,used_fallback=r.used_fallback,cause=r.termination_reason,query_nodes=r.nodes,query_seconds=elapsed,score=r.score,decision_line=record_value(r.decision_line),chosen_action=record_value(r.action))
    if row['status']=='USABLE_NATIVE_RETURN':
     assert r.action in s.legal_actions();leaf=copy(s)
     for action in r.decision_line:
      if isinstance(action,str):leaf.declare(action)
      else:leaf.submit(action)
     vector=phi(leaf.state);terminal=leaf.result.status.value!='ongoing'
     if terminal:
      assert leaf.result.declaration_outcome not in ('NO_CONTEST','RESTART');z=0 if leaf.result.winner is None else 1 if leaf.result.winner==0 else-1;pred=float(z);gradient=[0.]*len(vector);expected=(100000000-len(r.decision_line))*z
     else:
      coeff=[(cp.board_weights if kind=='board'else cp.hand_weights)[t]for kind,t in channels];pred=tanh(sum(x*w for x,w in zip(vector,coeff))/10.);gradient=[v*(1-pred*pred)/10.0 for v in vector];expected=sum(x*round(w*256)for x,w in zip(vector,coeff))
     assert expected==r.score*(1 if s.state.position.side_to_move==0 else-1),'CORE_PV_SCORE_MISMATCH'
     row.update(leaf_actual_terminal=terminal,leaf_phi=vector,leaf_prediction=pred,gradient=gradient,gradient_nonzero=any(v!=0 for v in gradient),eligible_native_gradient=any(v!=0 for v in gradient),leaf_result=record_value(leaf.result),terminal_gradient_constant=terminal,full_root_unchanged=True)
    else:row['gradient_nonzero']=None
   rows.append(row);out.write(json.dumps(row,separators=(',',':'))+'\n');out.flush()
   if len(rows)%128==0:print('OBSERVED',len(rows),'queries',counts['queries'],'seconds',round(time.perf_counter()-began,3),flush=True)
   if out.tell()>p['limits']['max_output_bytes']:raise TimeoutError('FROZEN_OUTPUT_CAP')
except BaseException as exc:status='PARTIAL_CAP'if isinstance(exc,TimeoutError)else'ERROR';reason=repr(exc);traceback.print_exc()
result=dict(status=status,reason=reason,planned_points=4599,returned_points=len(rows),missing_points=4599-len(rows),counts=dict(counts),statuses=dict(Counter(r['status']for r in rows)),nonzero_gradients=sum(r['eligible_native_gradient']for r in rows),seconds=time.perf_counter()-began,scope='ALLsavedpoint finiteNativeexistingSTATIC consumer, completeactualtypes/currentboard/basehand/fullhistory. ZeroTDupdates/newfitness/generation. Refused/incompletegradients remainUNKNOWN, terminalgradientisactualconstantzero whilephi retained. Oneactivecapsule, no ruletruncation/hiddenfallback/all-domain/learninggainclaim.');write_json(D/'result.json',result);print('CLOSED',json.dumps(result),flush=True)
