"""Independent full-record/PV and terminal-aware gradient reconstruction."""
from pathlib import Path
from collections import Counter
from copy import copy
from math import tanh
import json,hashlib,time,sys,os
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=R/'.local_agent/static-input-objective-20261018';S=R/'.local_agent/playability-filter-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));gens={g['key']:g for g in map(json.loads,(S/'generations.jsonl').read_bytes().splitlines())};points={(z['key'],z['target_prefix']):z for z in map(json.loads,(S/'points.jsonl').read_bytes().splitlines())};models={m['key']:m['checkpoint']for m in json.loads((D/'static-models.json').read_bytes())['rows']};started=time.perf_counter();active=None;c=None;counts=Counter()
def poll():
 assert time.perf_counter()-started<300,'REPLAY_CAP'
 for n in ('rollout','advisor','slack'):
  z=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not z.get('user_paused')and not z.get('stopped'),'EXPLICIT_STOP'
def digest(st):return hashlib.sha256(json.dumps(record_value(st),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(raw):
 from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
 from generic_chess.core.coordinates import Square
 d=dict(raw);d['to_square']=Square(**d['to_square'])
 if 'from_square'in d:d['from_square']=Square(**d['from_square']);return SemanticBoardMove(**d)
 return SemanticDropMove(**d)
for line in(D/'queries.jsonl').open(encoding='utf-8'):
 poll();q=json.loads(line);point=points[q['key'],q['prefix']];g=gens[q['key']]
 if active!=q['key']:active=q['key'];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))
 cp=models[q['key']];assert q['checkpoint_id']==__import__('generic_chess.learning.material',fromlist=['LearnableMaterialCheckpoint']).LearnableMaterialCheckpoint.from_dict(cp).checkpoint_id;s=GameSession.replay(c,deserialize_game_record(json.dumps(point['record'])));assert digest(s.state)==q['root_state_sha256'];types=tuple(sorted(t.type_id for t in c.piece_types if not t.is_anchor));channels=[(kind,t)for kind in('board','hand')for t in types];assert [list(x)for x in channels]==q['channels']
 def vector(st):
  b=Counter()
  for pc in st.position.board:
   if pc:b['board',pc.current_type_id]+=1 if pc.owner==0 else-1
  for t in types:b['hand',t]=st.position.hands[0].count(t)-st.position.hands[1].count(t)
  return[b[k,t]for k,t in channels]
 if q['status']=='TERMINAL_ROOT':assert s.result.status.value!='ongoing' and q['gradient_nonzero']is False;assert vector(s.state)==q['raw_root_phi'];counts['terminal_roots']+=1
 elif q['status']=='USABLE_NATIVE_RETURN':
  assert q['decision_line']and q['chosen_action']==q['decision_line'][0];assert 1<=q['completed_depth']<=2 and not q['used_fallback'];assert decode(q['chosen_action'])in s.legal_actions();leaf=copy(s)
  for raw in q['decision_line']:leaf.submit(decode(raw));counts['PV_edges']+=1
  v=vector(leaf.state);term=leaf.result.status.value!='ongoing';assert term==q['leaf_actual_terminal'];assert v==q['leaf_phi'];assert record_value(leaf.result)==q['leaf_result']
  if term:
   assert leaf.result.declaration_outcome not in('NO_CONTEST','RESTART');z=0 if leaf.result.winner is None else 1 if leaf.result.winner==0 else-1;pred=float(z);gradient=[0.]*len(v);expected=(100000000-len(q['decision_line']))*z
  else:
   coeff=[cp['board_weights'if kind=='board'else'hand_weights'][t]for kind,t in channels];pred=tanh(sum(x*w for x,w in zip(v,coeff))/10.);gradient=[x*(1-pred*pred)/10. for x in v];expected=sum(x*round(w*256)for x,w in zip(v,coeff));counts['ordinary_nonzero_phi_zero_floatgradient']+=any(v)and not any(gradient);counts['ordinary_nonzero_phi']+=any(v)
  assert abs(pred-q['leaf_prediction'])<1e-12;assert gradient==q['gradient'];assert any(x!=0 for x in gradient)==q['gradient_nonzero']==q['eligible_native_gradient'];assert expected==q['score']*(1 if s.state.position.side_to_move==0 else-1);counts['usable_queries']+=1;counts['nonzero_gradients']+=q['gradient_nonzero'];counts['terminal_leaf_zero_gradients']+=term;counts['D2_completed']+=q['completed_depth']==2
 else:counts[q['status']]+=1
 counts['full_points']+=1
assert counts['full_points']==json.loads((D/'result.json').read_bytes())['returned_points'];q=dict(status='PASS_ALL_STATIC_INPUTS_AND_GRADIENTS_CORE_RECONSTRUCTED',counts=dict(counts),seconds=time.perf_counter()-started,scope='IndependentCounterfeatures/fullrecord/PV/leafterminal/STATICtanh-gradient calculation, fulltypes/checkpointidentityandnumericalgradientzeros, actualchosenactionlegal androotstatesretained. No Nativequery/generation/game/TRAINrerun; no minimax/WDL/all-domainauthority claim.');write_json(D/'reader-result.json',q);print(q,flush=True)
