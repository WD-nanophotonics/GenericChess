"""Matched full-state objective crossover; no generation/query/training."""
from pathlib import Path
from collections import Counter,defaultdict
import json,sys
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/static-input-objective-20261018';U=R/'.local_agent/filter-search-inputs-20261018';I=R/'.local_agent/playability-filter-20261018';a={(q['slot'],q['filter'],q['prefix']):q for q in map(json.loads,(U/'queries.jsonl').read_bytes().splitlines())};b=[json.loads(l)for l in(D/'queries.jsonl').read_bytes().splitlines()];groups=defaultdict(Counter)
for q in b:
 u=a[q['slot'],q['filter'],q['prefix']];assert u['root_state_sha256']==q['root_state_sha256']and u['channels']==q['channels'];c=groups[q['prefix'],q['filter']];c['intended_returned']+=1;c['Unit_nonzero']+=bool(u['gradient_nonzero']);c['static_nonzero']+=bool(q['gradient_nonzero']);c['same_status']+=u['status']==q['status'];c['nodes_Unit']+=u['query_nodes'];c['nodes_static']+=q['query_nodes']
 if q['status']=='USABLE_NATIVE_RETURN':
  c['same_chosen_action']+=q['chosen_action']==u['chosen_action'];c['same_PV']+=q['decision_line']==u['decision_line'];c['both_nonzero']+=bool(q['gradient_nonzero']and u['gradient_nonzero']);c['Unit_only_nonzero']+=bool(u['gradient_nonzero']and not q['gradient_nonzero']);c['static_only_nonzero']+=bool(q['gradient_nonzero']and not u['gradient_nonzero']);c['ordinary_nonzero_phi_floatzero']+=not q['leaf_actual_terminal']and any(q['leaf_phi'])and not any(q['gradient']);c['static_terminal_leaf']+=q['leaf_actual_terminal'];c['Unit_terminal_leaf']+=u['leaf_actual_terminal']
rows=[dict(prefix=k[0],filter=k[1],counts=dict(v))for k,v in sorted(groups.items())];result=dict(status='COMPLETE',rows=rows,scope='Matchedsamefullstate/profilecrossover; featureavailabilityisnot TDresidual/eligibility ortraininggain. Alloriginalgenerationrefusalsremainunavailable, not measuredzerogradient. Querynodeclockscostnotoldtrainingcost.');write_json(D/'objective-analysis.json',result)
gens={(g['slot'],g['filter']):g for g in map(json.loads,(I/'generations.jsonl').read_bytes().splitlines())};qs={(q['slot'],q['filter'],q['prefix']):q for q in b};paired=[]
for prefix in (0,4,16):
 counts=Counter();delta=Counter();transition=Counter()
 for slot in range(768):
  ga,gb=gens[slot,False],gens[slot,True];same=ga['success']and gb['success']and ga['rules']==gb['rules'];kind='same_complete_rule'if same else'replacement_rule'if ga['success']and gb['success']else'bounded_generation_refusal';counts[kind]+=1;x=qs.get((slot,False,prefix));y=qs.get((slot,True,prefix));vx=bool(x and x['gradient_nonzero']);vy=bool(y and y['gradient_nonzero']);delta[kind]+=int(vy)-int(vx);transition[kind+'_off']+=vx;transition[kind+'_on']+=vy
  if same:
   fields=['status','channels','root_state_sha256','gradient_nonzero']
   if x['status']=='USABLE_NATIVE_RETURN':fields+=['chosen_action','decision_line','leaf_phi','gradient','leaf_prediction','score','completed_depth','query_nodes']
   assert all(x[f]==y[f]for f in fields),(slot,prefix)
 paired.append(dict(prefix=prefix,pairs=dict(counts),static_nonzero_delta=dict(delta),counts=dict(transition),total_delta=sum(delta.values())))
write_json(D/'paired-static-decomposition.json',dict(status='PASS_SAME_RULE_CONTROLS',rows=paired,scope='Availabilityatintended768pairs perprefix;3failedgenerationsunavailable, not zerogradientsmeasured. Acceptedrulemeasurechanges, not samegame orlearninggain.'))
print('ANALYZED',[(r['prefix'],r['total_delta'])for r in paired],flush=True)
