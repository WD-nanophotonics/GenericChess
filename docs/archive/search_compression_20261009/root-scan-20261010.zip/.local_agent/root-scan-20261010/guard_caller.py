"""Scoring-discard bool-guard caller controls on12prospective2146..2149roots.
Unit/v3 leaves, cold Core, D2/512nodes/10sec/q0, root scan enabled; baseline
versus existing compiled bool guard probe discarded from leaf scores. Two
paired repeats reverse arm order. No concurrent CPU experiment is permitted
for this timing batch. Cost expectation<3min,900sec checkpoint. Probe counts
current and reset predicate satisfaction with declared hand stock; omits
geometry/path/king-safety/history and cannot replace state/action support or
justify cross-rule weights. No fitting, new rule cases or budget expansion.
Question: can a mechanical rule-condition primitive be read cheaply enough
to retain as an input option without changing actual decisions/search work?
"""
from pathlib import Path
import sys,json,time,hashlib,collections
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'guard-callers.json';assert not out.exists()
d=json.loads((p/'prospective-rules.json').read_bytes())
write_record(p/'guard-caller-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules_sha256=hashlib.sha256((p/'prospective-rules.json').read_bytes()).hexdigest(),openings=[0,4,8],policies=['unit','v3'],repeats=2,limits=dict(depth=2,nodes=512,seconds=10,q=0),probe_scores_discarded=True))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg);engine=semantic_engine_for(c)
 slots={s.slot_id:s for s in engine.ir.aux_slots};patterns=[pat for pat in engine.ir.patterns if pat.slot_guards]
 assert all(slots[g.slot_id].value_kind=='bool' and g.square_ref is None for pat in patterns for g in pat.slot_guards)
 class Leaf(UnitEvaluator):
  def __init__(self,kind,probe):self.kind=kind;self.probe=probe;self.ev=Evaluator(c,profile,cfg);self.calls=0;self.terms=collections.Counter();self.probe_seconds=0
  def evaluate(self,state):
   if self.probe:
    tick=time.perf_counter();pos=state.position
    for pat in patterns:
     truth=all(engine._slot_guard_holds(g,pos,None,pos.side_to_move) for g in pat.slot_guards)
     reset=all(engine._compare(g.comparison,slots[g.slot_id].initial,g.value) for g in pat.slot_guards)
     stock=sum(dict(pos.hands[pos.side_to_move].counts).get(tid,0) for tid in pat.type_ids)
     self.terms[(truth,reset,stock)]+=1
    self.calls+=1;self.probe_seconds+=time.perf_counter()-tick
   return super().evaluate(state) if self.kind=='unit' else self.ev.evaluate(state)
 for opening in (0,4,8):
  s=GameSession(c)
  for raw in case['route'][:opening]:s.submit(action_from_dict(raw))
  if s.state.terminal_status.is_terminal:continue
  arms=[]
  for repeat in (0,1):
   for kind in ('unit','v3'):
    for probe in ((False,True) if repeat==0 else (True,False)):
     assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<900
     leaf=Leaf(kind,probe);pl=AlphaBetaPlayer(c,evaluator_override=leaf,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=True));before=s.state;tick=time.perf_counter()
     dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-tick;validate_pv(s,dec);assert s.state==before
     arms.append(dict(policy=kind,repeat=repeat,probe=probe,decision=record_value(dec),seconds=elapsed,probe_calls=leaf.calls,probe_seconds=leaf.probe_seconds,terms=[dict(truth=k[0],reset=k[1],stock=k[2],count=n)for k,n in sorted(leaf.terms.items())]))
  rows.append(dict(seed=case['seed'],opening=opening,arms=arms));write_record(out,dict(scope=__doc__,rows=rows,complete=False,seconds=time.perf_counter()-start));print(case['seed'],opening,flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
