"""Exposed attribution of one introduced2147v3/Unit partial-root hole atply14.
No default selection or games extension. Compare four declared leaf arms:
Unit100/100, uniform1000/900, unchangedv3, v3hand=board (declared intervention,
not generatedprice correction). Same coldCore/D2max64totalnodes/q0/root-scan.
Audit the already scored64root-prefix children plus old canonical if outside:
all immediate replies, not full root defenses or eventual WDL. Question: does
universal board/hand discount alone prefer the mating Cdrop, and can raw guard
input address it? All adverse labels retained. Expected<10min;600sec checkpoint.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action,legal_successors
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'introduced-hole.json';assert not out.exists();audit=json.loads((p/'partial-game-audit.json').read_bytes());r=next(r for r in audit['rows']if r['seed']==202610082147 and r['policies']==['v3','unit']and r['version']=='candidate'and r['ply']==14)
case=next(r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']if r['seed']==202610082147);g=next(r for r in json.loads((p/'partial-games.json').read_bytes())['rows']if r['seed']==202610082147 and r['policies']==['v3','unit']and r['version']=='candidate');c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for raw in case['route'][:4]:s.submit(action_from_dict(raw))
for step in g['steps'][:14]:s.submit(action_from_dict(step['action']))
assert record_value(s.state)==r['parent'];cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profile,_=build_semantic_opportunity_profile(c,cfg)
class Leaf(UnitEvaluator):
 def __init__(self,kind):self.kind=kind;self.ev=Evaluator(c,profile,cfg)
 def evaluate(self,st):
  if self.kind=='unit':return super().evaluate(st)
  if self.kind=='v3':return self.ev.evaluate(st)
  p=st.position;board=profile.board_value_by_type if self.kind=='v3_hand_board'else{t:1000 for t in c.support.type_metadata}
  score=sum((1 if piece.owner==0 else -1)*board[piece.current_type_id]for piece in p.board if piece is not None and piece.current_type_id!='K')
  score+=sum((1 if owner==0 else -1)*count*(board[t]if self.kind=='v3_hand_board'else 900)for owner,hand in enumerate(p.hands)for t,count in hand.counts)
  return score if p.side_to_move==0 else -score
kinds=['unit','uniform1000_900','v3','v3_hand_board'];leaves={k:Leaf(k)for k in kinds}
write_record(p/'introduced-hole-declaration.json',dict(scope=__doc__,root=dict(seed=case['seed'],policies=['v3','unit'],ply=14),arms=kinds,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limits=dict(depth=2,nodes=64,seconds=10,q=0),label_scope='64scored root children and old canonical only'))
arms=[];before=s.state;start=time.perf_counter()
for kind in kinds:
 pl=AlphaBetaPlayer(c,evaluator_override=leaves[kind],use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=True));dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=64,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,dec);assert s.state==before;arms.append(dict(policy=kind,action=action_to_dict(dec.action),decision=record_value(dec)))
children=list(legal_successors(s.state,c));prefix=children[:64];canonical=action_from_dict(r['arms'][0]['action'])
if canonical not in [a for a,_ in prefix]:prefix.append(next((a,ch)for a,ch in children if a==canonical))
rows=[];transitions=len(children);engine=semantic_engine_for(c);pattern=next(pat for pat in engine.ir.patterns if pat.slot_guards)
for a,ch in prefix:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<600
 w=[];replies=0
 if not ch.terminal_status.is_terminal:
  for reply in legal_actions(ch,c):
   nxt=apply_action(ch,reply,c);transitions+=1;replies+=1
   if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-before.position.side_to_move:w.append(dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status)))
 rows.append(dict(action=action_to_dict(a),scores={k:-leaf.evaluate(ch)for k,leaf in leaves.items()},terminal=record_value(ch.terminal_status),guard_truth=all(engine._slot_guard_holds(guard,ch.position,None,ch.position.side_to_move)for guard in pattern.slot_guards),enemy_P_stock=dict(ch.position.hands[ch.position.side_to_move].counts).get('P',0),replies=replies,witnesses=w,complete=True));write_record(out,dict(scope=__doc__,arms=arms,rows=rows,complete=False,root_actions=len(children),transitions=transitions,seconds=time.perf_counter()-start))
write_record(out,dict(scope=__doc__,arms=arms,rows=rows,complete=True,root_actions=len(children),transitions=transitions,seconds=time.perf_counter()-start));print(dict(arms=[(a['policy'],a['action'])for a in arms],prefix=len(prefix),transitions=transitions,seconds=time.perf_counter()-start))
