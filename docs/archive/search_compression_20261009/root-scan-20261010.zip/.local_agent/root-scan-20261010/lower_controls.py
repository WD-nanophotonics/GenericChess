"""Matched root-scan off/on calls at all7exposed prospective mating loser parents.
All2leaf policies under the same64node/10sec/Unit-order/root-tactical-off limit.
Question: can the default existing root scan avoid a locally avoidable immediate loss,
or does extra qwork only lose completed iterations? Label chosen actions by the
already completed all-action immediate-reply fronts; no game/budget extension.
Posthoc exposed diagnosis, not default selection or playing gain.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;source=Path('.local_agent/v3-transfer-20261010');assert not (p/'lower-controls.json').exists();front=json.loads((source/'mate-fronts.json').read_bytes());assert front['complete'] and len(front['rows'])==7
games=json.loads((source/'games.json').read_bytes())['rows'];cases={r['seed']:r for r in json.loads((source/'signal-declaration.json').read_bytes())['rules']}
write_record(p/'lower-declaration.json',dict(scope=__doc__,roots=[dict(seed=r['seed'],policies=r['policies'],ply=r['ply']) for r in front['rows']],limits=dict(nodes=64,seconds=10,depth=2,qhard=8),arms=[['unit',0],['v3',0],['unit',1],['v3',1]]))
rows=[];start=time.perf_counter();cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for r in front['rows']:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 case=cases[r['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);g=next(x for x in games if x['seed']==r['seed'] and x['policies']==r['policies'])
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in g['steps'][:r['ply']]:s.submit(action_from_dict(step['action']))
 assert record_value(s.state)==r['parent'];profile,_=build_semantic_opportunity_profile(c,cfg)
 class Leaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind;self.ev=Evaluator(c,profile,cfg)
  def evaluate(self,state):return super().evaluate(state) if self.kind=='unit' else self.ev.evaluate(state)
 arms=[]
 for kind,scan in (('unit',False),('v3',False),('unit',True),('v3',True)):
  before=s.state;pl=AlphaBetaPlayer(c,evaluator_override=Leaf(kind),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=scan));tick=time.perf_counter();dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=64,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,dec);assert s.state==before
  a=action_to_dict(dec.action);label=next(x for x in r['actions'] if x['action']==a);assert label['complete']
  arms.append(dict(policy=kind,root_scan=scan,action=a,decision=record_value(dec),immediate_loss_witnesses=len(label['witnesses']),child_terminal=label['terminal'],seconds=time.perf_counter()-tick))
 rows.append(dict(seed=r['seed'],source_policies=r['policies'],ply=r['ply'],arms=arms));write_record(p/'lower-controls.json',dict(scope=__doc__,rows=rows,complete=False))
write_record(p/'lower-controls.json',dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
print([(r['seed'],r['ply'],[(a['policy'],a['root_scan'],a['decision']['completed_depth'],a['immediate_loss_witnesses']) for a in r['arms']]) for r in rows])
