"""Local adverse diagnostic of24frozen64node old/candidate trajectories.
For every same-rule/policy pair: first action divergence at the common parent;
for every actual checkmate game: loser action immediately before the mating
reply. Both old/candidate at the same parent/leaf/64budget, plus recorded
action if distinct. Enumerate chosen child's replies only, not all root
defenses or eventual WDL. Dedupe identical roots within each case, retain
all zeros/adverse/forced unknowns. Expect<5min;600sec checkpoint. Decision:
separate an introduced local hole from trajectory/event changes before delivery.
"""
from pathlib import Path
import sys,json,time,hashlib,importlib.util,collections
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
import generic_chess.ai.alphabeta.player as player_module
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'partial-game-audit.json';assert not out.exists();games=json.loads((p/'partial-games.json').read_bytes());assert games['complete'] and len(games['rows'])==24
cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};selected=[]
for seed in cases:
 for kinds in (['unit','unit'],['unit','v3'],['v3','unit']):
  oldgame=next(g for g in games['rows']if g['seed']==seed and g['policies']==kinds and g['version']=='old');newgame=next(g for g in games['rows']if g['seed']==seed and g['policies']==kinds and g['version']=='candidate')
  for i,(a,b) in enumerate(zip(oldgame['steps'],newgame['steps'])):
   if a['action']!=b['action']:
    selected.append(dict(seed=seed,policies=kinds,version='old',ply=i,reason='first_divergence'));break
  for g in (oldgame,newgame):
   if g['terminal']['status']=='checkmate':
    assert len(g['steps'])>=2;selected.append(dict(seed=seed,policies=kinds,version=g['version'],ply=len(g['steps'])-2,reason='actual_mating_loser_action'))
write_record(p/'partial-game-audit-declaration.json',dict(scope=__doc__,roots=selected,games_sha256=hashlib.sha256((p/'partial-games.json').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
name='generic_chess.ai.alphabeta.audit_baseline';spec=importlib.util.spec_from_file_location(name,p/'search-baseline.py');old=importlib.util.module_from_spec(spec);sys.modules[name]=old;spec.loader.exec_module(old);candidate=player_module.run_root_search
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[];transitions=0;start=time.perf_counter()
for root in selected:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<600
 case=cases[root['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg);g=next(g for g in games['rows']if g['seed']==root['seed']and g['policies']==root['policies']and g['version']==root['version']);s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in g['steps'][:root['ply']]:s.submit(action_from_dict(step['action']))
 side=s.state.position.side_to_move;kind=root['policies'][side];arms=[];labels={}
 class Leaf(UnitEvaluator):
  def evaluate(self,state):return super().evaluate(state)if kind=='unit'else Evaluator(c,profile,cfg).evaluate(state)
 for version in ('old','candidate'):
  player_module.run_root_search=old.run_root_search if version=='old' else candidate;pl=AlphaBetaPlayer(c,evaluator_override=Leaf(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=True));before=s.state
  try:dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=64,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8))
  finally:player_module.run_root_search=candidate
  validate_pv(s,dec);assert s.state==before;arms.append(dict(version=version,action=action_to_dict(dec.action),decision=record_value(dec)))
 for raw in [a['action']for a in arms]+[g['steps'][root['ply']]['action']]:
  key=json.dumps(raw,sort_keys=True)
  if key in labels:continue
  child=apply_action(s.state,action_from_dict(raw),c);transitions+=1;w=[];replycount=0
  if not child.terminal_status.is_terminal:
   for reply in legal_actions(child,c):
    nxt=apply_action(child,reply,c);transitions+=1;replycount+=1
    if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-side:w.append(dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status)))
  labels[key]=dict(action=raw,replies=replycount,witnesses=w,terminal=record_value(child.terminal_status),complete=True)
 for arm in arms:arm['immediate_loss_witnesses']=len(labels[json.dumps(arm['action'],sort_keys=True)]['witnesses'])
 rows.append(dict(**root,mover=side,leaf=kind,parent=record_value(s.state),arms=arms,labels=list(labels.values())));write_record(out,dict(scope=__doc__,rows=rows,complete=False,transitions=transitions,seconds=time.perf_counter()-start));print(root['seed'],root['ply'],root['reason'],[(a['version'],a['immediate_loss_witnesses'])for a in arms],flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,transitions=transitions,seconds=time.perf_counter()-start))
