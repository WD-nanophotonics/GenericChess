"""Negative control: run new interruption regressions against pinned old source."""
import importlib.util, sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
import generic_chess.ai.alphabeta.search
name='generic_chess.ai.alphabeta.search'
spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name('search-baseline.py'))
module=importlib.util.module_from_spec(spec)
sys.modules[name]=module
spec.loader.exec_module(module)
import generic_chess.ai.alphabeta
generic_chess.ai.alphabeta.search=module
import pytest
raise SystemExit(pytest.main(['tests/product/test_search_upgrades.py','-q','-k','partial_root_scan']))
