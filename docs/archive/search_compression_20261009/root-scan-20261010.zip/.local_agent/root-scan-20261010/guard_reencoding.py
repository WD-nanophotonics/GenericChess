"""Finite boolean-rule/state recoding check, no model fitting or WDL target.
Reuse all three observed X-transform child positions (exposed), actual stock
and one synthetic P, flags0/1. Compare original versus inverted bool coding:
guard0->1, initial0->1, explicit set1->0, positionflag f->1-f.
Only this no-trigger global expire_next_turn boolean family is supported;
clear-right, square guards and other rules are not claimed equivalent.
One-step Position transitions and public legal actions, no GameState-history
counterfactual. Mechanical guard truth should survive recoding; raw numeric
aux does not. Compare same numericflag under opposite guards as a separate
non-equivalent condition. Decide whether raw aux labels are an adequate shared
input, not whether the new tiny probe predicts useful prices. Under5min.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,copy,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd())]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'guard-reencoding.json';assert not out.exists()
source=Path('.local_agent/v3-transfer-20261010');cases={r['seed']:r for r in json.loads((source/'signal-declaration.json').read_bytes())['rules']}
events=json.loads((source/'executed-scope.json').read_bytes())['rows'];games=json.loads((source/'games.json').read_bytes())['rows']
roots=[(r,e)for r in events for e in r['events']if e['action'].get('pattern_id','').startswith('sem_01_')];assert len(roots)==3
write_record(p/'guard-reencoding-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),roots=[dict(seed=r['seed'],policies=r['policies'],ply=e['ply'])for r,e in roots],stocks=['actual','synthetic_P'],flags=[0,1],old_sources_unchanged=True))
def observation(engine,pos):
 pattern=next(x for x in engine.ir.patterns if x.slot_guards)
 assert len(pattern.slot_guards)==1 and pattern.slot_guards[0].square_ref is None
 guard=pattern.slot_guards[0];slot=next(s for s in engine.ir.aux_slots if s.slot_id==guard.slot_id)
 assert slot.value_kind=='bool' and slot.scope=='global' and slot.lifetime=='expire_next_turn'
 truth=engine._slot_guard_holds(guard,pos,None,pos.side_to_move)
 reset=replace(pos,aux_state=(((slot.slot_id,-1),slot.initial),))
 return dict(guard_truth=truth,after_expiry_truth=engine._slot_guard_holds(guard,reset,None,pos.side_to_move),P_stock=dict(pos.hands[pos.side_to_move].counts).get('P',0))
def signature(pos,flip=False):
 aux=tuple((key,1-value if flip else value) for key,value in pos.aux_state)
 return record_value(dict(board=tuple(pos.board),hands=pos.hands,side=pos.side_to_move,aux=aux))
rows=[];transitions=0;start=time.perf_counter()
for r,e in roots:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 case=cases[r['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));engine=semantic_engine_for(c);assert not engine.ir.triggers
 rule=copy.deepcopy(case['rules']);rule['semantic_actions'][0]['slot_guards'][0]['value']=1
 for action in rule['semantic_actions']:
  for slot in action.get('aux_state',[]):
   assert slot['value_kind']=='bool';slot['initial']=1-slot['initial']
  for effect in action['effects']:
   if effect['kind']=='set_bool':effect['value']=1-effect['value']
   assert effect['kind'] not in ('clear_right','clear_token')
 cc=compile_ruleset_for_execution(ruleset_from_dict(rule));ee=semantic_engine_for(cc);s=GameSession(c);g=next(g for g in games if g['seed']==r['seed']and g['policies']==r['policies'])
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in g['steps'][:e['ply']+1]:s.submit(action_from_dict(step['action']))
 for stock in ('actual','synthetic_P'):
  pos=s.state.position
  if stock=='synthetic_P':
   hh=list(pos.hands);hh[pos.side_to_move]=hh[pos.side_to_move].add('P');pos=replace(pos,hands=tuple(hh))
  for flag in (0,1):
   original=replace(pos,aux_state=((pos.aux_state[0][0],flag),));inverse=replace(original,ruleset_fingerprint=cc.ruleset_fingerprint,aux_state=((pos.aux_state[0][0],1-flag),))
   obs=observation(engine,original);inv=observation(ee,inverse);assert obs==inv
   raw_equal=bool(np.array_equal(SparsePositionEncoder(c).dense(original),SparsePositionEncoder(cc).dense(inverse)))
   oldlist=list(engine.iter_legal_action_bindings(original));newlist=list(ee.iter_legal_action_bindings(inverse));keys=lambda eng,items:[action_to_dict(_semantic_public_action(eng,a))for a,_ in items]
   assert keys(engine,oldlist)==keys(ee,newlist)
   childmatches=[]
   for (a,b),(aa,bb) in zip(oldlist,newlist):
    cp=engine._transition(original,a,b);ip=ee._transition(inverse,aa,bb);transitions+=2
    childmatches.append(signature(cp)==signature(ip,flip=True))
   assert all(childmatches)
   sameflag=replace(inverse,aux_state=original.aux_state)
   rows.append(dict(seed=r['seed'],policies=r['policies'],ply=e['ply'],stock=stock,flag=flag,original=signature(original),inverse=signature(inverse),observations=[obs,inv],raw_sparse_equal=raw_equal,public_actions=keys(engine,oldlist),children_equivalent=childmatches,non_equivalent_same_numeric_flag=observation(ee,sameflag)))
write_record(out,dict(scope=__doc__,rows=rows,complete=True,transitions=transitions,seconds=time.perf_counter()-start))
print(dict(rows=len(rows),transitions=transitions,raw_equal=sum(r['raw_sparse_equal']for r in rows),all_guard_equivalent=all(r['observations'][0]==r['observations'][1]for r in rows),seconds=time.perf_counter()-start))
