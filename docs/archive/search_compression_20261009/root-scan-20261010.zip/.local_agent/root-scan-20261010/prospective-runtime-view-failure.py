"""Prospective partial-root diagnostic, not playing-strength or holdout proof.
Four seeds2146..2149 fixed before search outcomes; openings0/4/8 where
nonterminal, no replacement of missing/terminal roots. Unit/v3 leaves, Unit
ordering, cold TT, D2/q0,64/128totalnodes,10sec safety. Old pinned versus
candidate same limits. Observe every chosen child's legal one-reply terminals,
including zero witnesses. Predicted under15min;900sec cost checkpoint retains
partial status, no automatic batch expansion. Decision: preserving completed
scores should preserve work, handle full semantic state, and expose any adverse
partial-fallback behavior before delivery. Immediate safety is not forced WDL.
"""
from pathlib import Path
import sys,json,time,hashlib,importlib.util
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
import generic_chess.ai.alphabeta.player as player_module
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'prospective-controls.json';assert not out.exists()
oldpath=p/'search-baseline.py';name='generic_chess.ai.alphabeta.scan_baseline'
spec=importlib.util.spec_from_file_location(name,oldpath);old=importlib.util.module_from_spec(spec);sys.modules[name]=old;spec.loader.exec_module(old)
candidate=player_module.run_root_search
rulespath=p/'prospective-rules.json';d=json.loads(rulespath.read_bytes())
write_record(p/'prospective-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules_sha256=hashlib.sha256(rulespath.read_bytes()).hexdigest(),old_source_sha256=hashlib.sha256(oldpath.read_bytes()).hexdigest(),candidate_source_sha256=hashlib.sha256(Path('generic_chess/ai/alphabeta/search.py').read_bytes()).hexdigest(),openings=[0,4,8],policies=['unit','v3'],nodes=[64,128],versions=['old','candidate'],success='no numerical utility pass threshold; preserve actual work and legality, report all adverse labels'))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
rows=[];start=time.perf_counter();transitions=0
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg)
 class Leaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind;self.ev=Evaluator(c,profile,cfg);self.seen=[]
  def evaluate(self,state):
   score=super().evaluate(state) if self.kind=='unit' else self.ev.evaluate(state)
   self.seen.append(dict(state=record_value(state),score=score));return score
 for opening in (0,4,8):
  s=GameSession(c)
  for raw in case['route'][:opening]:s.submit(action_from_dict(raw))
  if s.state.terminal_status.is_terminal:
   rows.append(dict(seed=case['seed'],opening=opening,terminal_skip=record_value(s.state.terminal_status)));continue
  arms=[];labels={};root_actions=legal_actions(s.state,c)
  for nodes in (64,128):
   for kind in ('unit','v3'):
    for version in ('old','candidate'):
     assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
     assert time.perf_counter()-start<900
     ev=Leaf(kind);player_module.run_root_search=old.run_root_search if version=='old' else candidate
     pl=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=True))
     before=s.state;t=time.perf_counter()
     try:dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=nodes,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8))
     finally:player_module.run_root_search=candidate
     elapsed=time.perf_counter()-t;validate_pv(s,dec);assert s.state==before and dec.action in root_actions
     raw=action_to_dict(dec.action);key=json.dumps(raw,sort_keys=True)
     if key not in labels:
      child=apply_action(s.state,dec.action,c);transitions+=1;witnesses=[];replies=0
      if not child.terminal_status.is_terminal:
       for reply in legal_actions(child,c):
        nxt=apply_action(child,reply,c);transitions+=1;replies+=1
        if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-before.position.side_to_move:witnesses.append(dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status)))
      labels[key]=dict(child=record_value(child),terminal=record_value(child.terminal_status),replies=replies,witnesses=witnesses,complete=True)
     partial=dec.completed_depth==0 and dec.root_scan_used_fallback
     label=labels[key]
     if version=='candidate' and partial and ev.seen:
      assert label['child'] in [r['state'] for r in ev.seen if r['score']==min(x['score'] for x in ev.seen)]
     arms.append(dict(nodes=nodes,policy=kind,version=version,action=raw,decision=record_value(dec),seconds=elapsed,evaluated=ev.seen,immediate_loss_witnesses=len(label['witnesses']),terminal=label['terminal']))
  rows.append(dict(seed=case['seed'],opening=opening,parent=record_value(s.state),root_actions=len(root_actions),arms=arms,labels=labels));write_record(out,dict(scope=__doc__,rows=rows,complete=False,transitions=transitions,seconds=time.perf_counter()-start))
  print(case['seed'],opening,len(root_actions),[(a['nodes'],a['policy'],a['version'],a['decision']['completed_depth'],a['immediate_loss_witnesses']) for a in arms],flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,transitions=transitions,seconds=time.perf_counter()-start))
