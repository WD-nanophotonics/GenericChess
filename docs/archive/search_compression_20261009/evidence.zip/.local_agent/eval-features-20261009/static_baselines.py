"""Existing rule-generated tables as future compression controls, not fitting.
Six frozen roots/all228children: v2/v3 material-only greedy uniform ties, then
24balanced actual D3/20000node/3second/q0 Core calls, no order/TT/root tactics.
Unit-D2-child teacher regret is descriptive agreement with a UNIT teacher, not
independent price quality. Neither generated table is tuned on these outputs.
"""
from pathlib import Path
import sys,json,time,hashlib,statistics
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not (p/'static-baselines.json').exists()
decl=json.loads((p/'prospective-target-declaration.json').read_bytes());labels=json.loads((p/'prospective-target-d2-completed.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));evaluators={}
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),profiles=[],greedy=[],calls=[],complete=False)
for version in ('generic-v2','semantic-opportunity-v3'):
    cfg=EvaluationConfig(evaluator_version=version,dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
    tick=time.perf_counter();profile=build_ruleset_profile(c,cfg)
    report['profiles'].append(dict(version=version,config=record_value(cfg),profile=record_value(profile),build_seconds=time.perf_counter()-tick))
    evaluators[version]=Evaluator(c,profile,cfg)
for root,row in zip(decl['roots'],labels['roots']):
    s=GameSession(c)
    for a in root['route']:s.submit(action_from_dict(a))
    teachers={json.dumps(x['action'],sort_keys=True):y['targets']['2']['root_score']for x,y in zip(root['children'],row['children'])};maximum=max(teachers.values());before=s.state
    for version,ev in evaluators.items():
        values=[-ev.evaluate(apply_action(s.state,action_from_dict(item['action']),c))for item in root['children']]
        selected=[i for i,v in enumerate(values)if v==max(values)];target=[teachers[json.dumps(x['action'],sort_keys=True)]for x in root['children']]
        report['greedy'].append(dict(seed=root['seed'],version=version,values=values,selected=selected,
            unit_teacher_expected_regret=statistics.mean(maximum-target[i]for i in selected)))
    for rep in range(2):
        for version in (list(evaluators)if rep==0 else list(reversed(evaluators))):
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            player=AlphaBetaPlayer(c,evaluator_override=evaluators[version],use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
            tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick
            validate_pv(s,d);assert s.state==before
            key=json.dumps(action_to_dict(d.action),sort_keys=True);assert key in teachers
            report['calls'].append(dict(seed=root['seed'],version=version,rep=rep,seconds=elapsed,unit_teacher_regret=maximum-teachers[key],decision=record_value(d)))
            write_record(p/'static-baselines.json',report)
        print(root['seed'],rep,[(r['version'],r['decision']['completed_depth'],r['unit_teacher_regret'])for r in report['calls'][-2:]],flush=True)
report['complete']=True;write_record(p/'static-baselines.json',report)
