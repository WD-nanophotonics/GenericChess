"""Complete only the already declared D2 arm after a cost-futility checkpoint.
Original D4 partials stay immutable; no capped call rerun or success-rule change.
All remaining D4 outcomes are UNKNOWN/not executed, not omitted or zero.
No training; no fresh routes; D2 conditions exactly match original declaration.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;decl=json.loads((p/'prospective-target-declaration.json').read_bytes())
partial=json.loads((p/'prospective-target-cost-stopped.json').read_bytes());old={r['seed']:r for r in partial['roots']}
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));types=non_anchor_type_ids(c)
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    declaration_sha256=hashlib.sha256((p/'prospective-target-declaration.json').read_bytes()).hexdigest(),
    partial_sha256=hashlib.sha256((p/'prospective-target-cost-stopped.json').read_bytes()).hexdigest(),
    roots=[],complete_d2=False,d4_stopped_for_cost=True)
class Unit:
    def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
for root in decl['roots']:
    s=GameSession(c)
    for action in root['route']:s.submit(action_from_dict(action))
    assert record_value(s.state)==root['state']
    previous={x['index']:x for x in old.get(root['seed'],{}).get('children',[])}
    row=dict(seed=root['seed'],group=root['group'],children=[]);report['roots'].append(row)
    if 'missing' in root:row['missing']=root['missing'];continue
    for i,item in enumerate(root['children']):
        child=apply_action(s.state,action_from_dict(item['action']),c);assert record_value(child)==item['state']
        out=previous.get(i,dict(index=i,targets={}))
        out['targets'].setdefault('4',dict(known=False,reason='D4 arm stopped for cost before this call',seconds=0))
        if '2' not in out['targets']:
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            tick=time.perf_counter()
            if child.terminal_status.is_terminal:
                val=dict(known=True,root_score=terminal_score(child.terminal_status,s.state.position.side_to_move,1),target_kind='terminal-child')
            else:
                cs=GameSession(c);cs._state=child;cs._search_history_witnesses=s._search_history_witnesses+(child.position,)
                pl=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
                d=pl.choose_action(cs,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0))
                val=dict(known=d.completed_depth==2,decision=record_value(d))
                if val['known']:val.update(root_score=-d.score,target_kind='terminal-derived' if abs(d.score)>1000000 else 'finite-material-search')
                else:val['reason']='incomplete depth; shallower returned value excluded'
            val['seconds']=time.perf_counter()-tick;out['targets']['2']=val
        row['children'].append(out);write_record(p/'prospective-target-d2-completed.json',report)
    print(root['seed'],len(row['children']),sum(x['targets']['2']['known'] for x in row['children']),flush=True)
report['complete_d2']=True;write_record(p/'prospective-target-d2-completed.json',report)
