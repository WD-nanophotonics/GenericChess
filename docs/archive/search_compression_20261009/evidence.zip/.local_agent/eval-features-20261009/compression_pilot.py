"""Prepared offline single-fit protocol. Default invocation does not train.
Use --execute-once only following user authorization for the declared pilot.
No search deployment, sweeps, model selection, or report-group fitting.
"""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
import argparse,json,hashlib,time,sys
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent
parser=argparse.ArgumentParser();parser.add_argument('--execute-once',action='store_true');args=parser.parse_args()
plan=json.loads((p/'compression-pilot-plan.json').read_bytes())
metadata=json.loads((p/'compression-inputs.json').read_bytes())
assert hashlib.sha256((p/'compression-inputs.npz').read_bytes()).hexdigest()==metadata['npz_sha256']
data=np.load(p/'compression-inputs.npz',allow_pickle=False)
x,y,b,g,roots=[data[k]for k in ('features','targets','baseline','groups','roots')]
train=g=='train';assert (int(train.sum()),x.shape)==(72,(228,1682))
assert set(roots[train])==set(plan['train_trajectory_seeds'])
assert set(roots[g=='dev'])==set(plan['dev_trajectory_seeds'])
assert set(roots[g=='test'])==set(plan['report_trajectory_seeds'])
assert np.isfinite(x).all() and np.isfinite(y).all() and np.isfinite(b).all()
if not args.execute_once:
    print(json.dumps(dict(status='PREPARED_NOT_STARTED',rows=len(x),train_rows=int(train.sum()),purpose=plan['purpose'])))
    raise SystemExit(0)
assert not (p/'compression-model.json').exists() and not (p/'compression-pilot-result.json').exists()
assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
assert not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
from generic_chess.learning.nonlinear import fit_compact_residual,CompactNonlinearResidual
tick=time.perf_counter()
model=fit_compact_residual(x[train],y[train],width=plan['width'],regularization=plan['regularization'],seed=plan['seed'],epochs=plan['epochs'],learning_rate=plan['learning_rate'])
fit_seconds=time.perf_counter()-tick
assert fit_seconds<=plan['fit_safety_checkpoint_seconds'], 'fit exceeded declared safety checkpoint; retain failure, do not retry'
payload=dict(scope='offline sparse Position only, omitted history; no live model binding',plan_sha256=hashlib.sha256((p/'compression-pilot-plan.json').read_bytes()).hexdigest(),input_sha256=metadata['npz_sha256'],model=model.to_dict())
write_record(p/'compression-model.json',payload)
restored=CompactNonlinearResidual.from_dict(payload['model'])
tick=time.perf_counter();prediction=restored.predict(x);inference_seconds=time.perf_counter()-tick
assert np.array_equal(prediction,model.predict(x)) and np.isfinite(prediction).all()
assert np.allclose(np.asarray(model.input_mean),x[train].mean(axis=0),rtol=0,atol=0)
assert model.perspective=='owner0'
full=prediction+b;teacher=y+b;rows=[]
for seed in dict.fromkeys(roots):
    mask=roots==seed;v=full[mask];t=teacher[mask];base=b[mask]
    chosen=np.flatnonzero(v==v.max());greedy=np.flatnonzero(base==base.max())
    rows.append(dict(seed=int(seed),group=str(g[mask][0]),children=int(mask.sum()),
        prediction_top_indices=chosen.tolist(),teacher_top_indices=np.flatnonzero(t==t.max()).tolist(),
        teacher_expected_regret=float(np.mean(t.max()-t[chosen])),
        material_expected_regret=float(np.mean(t.max()-t[greedy])),
        teacher_top_fraction=float(np.mean(t[chosen]==t.max())),
        residual_mse=float(np.mean((prediction[mask]-y[mask])**2))))
report=dict(scope=__doc__,status='ONE_FIT_COMPLETE_NOT_DEPLOYED',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    plan_sha256=payload['plan_sha256'],input_sha256=metadata['npz_sha256'],model_sha256=hashlib.sha256((p/'compression-model.json').read_bytes()).hexdigest(),
    model_bytes=(p/'compression-model.json').stat().st_size,fit_seconds=fit_seconds,inference_batch_seconds=inference_seconds,
    blas_environment_requested='one thread; not a measured thread count',rows=rows,
    groups={name:dict(roots=sum(r['group']==name for r in rows),
        equal_root_mean_teacher_regret=float(np.mean([r['teacher_expected_regret']for r in rows if r['group']==name])),
        equal_root_mean_material_regret=float(np.mean([r['material_expected_regret']for r in rows if r['group']==name])))for name in ('train','dev','test')},
    exposure=plan['exposure'],training_rows=72,report_rows_used_for_training=0,search_deployed=False)
write_record(p/'compression-pilot-result.json',report);print(json.dumps(report,indent=2))
