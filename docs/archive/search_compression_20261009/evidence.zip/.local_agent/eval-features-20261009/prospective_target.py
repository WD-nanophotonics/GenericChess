"""Prospective development teacher comparison, no fitting or new evaluator.
Six lexical-action random legal routes seeds2026100902..07, fixed before labels,
one existing complete exposed generated8 RuleSet2102, root at ply8 only. Whole
trajectories assigned train/dev/test pairs for a possible FUTURE pilot; no train
occurs here and no unexposed-rule claim. Early terminal routes stay missing.
Freeze every legal child BEFORE any labels. D2q0 and D4q0 same unit leaf, exact
GameState/history, no TT/order/native/disk/root tactics. D2:2048nodes/1sec;
D4:20000nodes/5sec. This measures resource/result curves, not equal-cost gains.
All caps UNKNOWN for declared depth; no result-driven extension. The unknown is
whether D2 material-search contrasts are stable enough to choose a compression
target. Both agreement and disagreement affect interpretation; not a gate for
all learning. Ceiling6*max-legal-child-count*6sec; serial interruptible calls.
"""
from pathlib import Path
import sys,json,random,time,hashlib,datetime
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent
assert not (p/'prospective-target-declaration.json').exists()
src=Path('.local_agent/generated8-20261008/transfer.json')
rule=next(r['rules'] for r in json.loads(src.read_bytes())['cases'] if r['seed']==202610082102)
c=compile_ruleset_for_execution(ruleset_from_dict(rule));enc=SparsePositionEncoder(c);types=non_anchor_type_ids(c)
roots=[];declarations=[]
for k,seed in enumerate(range(2026100902,2026100908)):
    s=GameSession(c);rng=random.Random(seed);route=[]
    for ply in range(8):
        if s.state.terminal_status.is_terminal:break
        acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True))
        if not acts:break
        a=rng.choice(acts);route.append(action_to_dict(a));s.submit(a)
    row=dict(seed=seed,group=('train','dev','test')[k//2],route=route,state=record_value(s.state),children=[])
    if len(route)<8 or s.state.terminal_status.is_terminal:row['missing']='early terminal or no actions'
    else:
        for action in sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True)):
            child=apply_action(s.state,action,c)
            row['children'].append(dict(action=action_to_dict(action),state=record_value(child),
                material=record_value(material_features(child.position,types,perspective=s.state.position.side_to_move)),
                position_sha256=hashlib.sha256(enc.dense(child.position).tobytes()).hexdigest()))
    declarations.append(row);roots.append(s)
declaration=dict(scope=__doc__,at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),
    rules=rule,fingerprint=c.ruleset_fingerprint,types=types,roots=declarations)
write_record(p/'prospective-target-declaration.json',declaration)
report=dict(scope=__doc__,declaration_sha256=hashlib.sha256((p/'prospective-target-declaration.json').read_bytes()).hexdigest(),
    roots=[],complete=False)
class Unit:
    def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
for root,s in zip(declarations,roots):
    row=dict(seed=root['seed'],group=root['group'],children=[]);report['roots'].append(row)
    if 'missing' in root:row['missing']=root['missing'];continue
    for i,declared in enumerate(root['children']):
        child=apply_action(s.state,__import__('generic_chess.core.actions',fromlist=['action_from_dict']).action_from_dict(declared['action']),c)
        item=dict(index=i,targets={});row['children'].append(item)
        for depth,nodes,seconds in ((2,2048,1),(4,20000,5)):
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            assert not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
            tick=time.perf_counter()
            if child.terminal_status.is_terminal:
                val=dict(known=True,root_score=terminal_score(child.terminal_status,s.state.position.side_to_move,1),target_kind='terminal-child')
            else:
                cs=GameSession(c);cs._state=child;cs._search_history_witnesses=s._search_history_witnesses+(child.position,)
                pl=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
                d=pl.choose_action(cs,SearchLimits(max_depth=depth,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0))
                val=dict(known=d.completed_depth==depth,decision=record_value(d))
                if val['known']:val.update(root_score=-d.score,target_kind='terminal-derived' if abs(d.score)>1000000 else 'finite-material-search')
                else:val['reason']='incomplete depth; shallower returned value excluded'
            val['seconds']=time.perf_counter()-tick;item['targets'][str(depth)]=val
            write_record(p/'prospective-target.json',report)
        print(root['seed'],i+1,'/',len(root['children']),{k:(v['known'],round(v['seconds'],3)) for k,v in item['targets'].items()},flush=True)
report['complete']=True;write_record(p/'prospective-target.json',report)
