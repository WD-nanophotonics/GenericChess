"""Post-label no-fit relative-pair audit of the retained135children.
No new teacher calls, training or sample extension. Equal hashes are checked
with exact integer arrays. Pair-only excludes absolute location/hand/aux/history;
compare it with sparse Position + pairs, not a replacement complete state.
Decision: retain a cheap interaction comparator or expose a concrete alias.
"""
from pathlib import Path
import sys,json,itertools,hashlib,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent
decl=json.loads((p/'same-material-declaration.json').read_bytes())
labels=json.loads((p/'same-material-signal.json').read_bytes())
rule=next(r['rules'] for r in json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases'] if r['seed']==202610082102)
c=compile_ruleset_for_execution(ruleset_from_dict(rule));enc=SparsePositionEncoder(c)
types=tuple(sorted(c.support.type_metadata));ids={t:i for i,t in enumerate(types)}
nt=2*len(types);w=c.board_shape.width;h=c.board_shape.height
dxn=2*w-1;dyn=2*h-1;dim=nt*nt*dxn*dyn
def pairs(pos):
    actors=np.asarray([(sq%w,sq//w,a.owner*len(types)+ids[a.current_type_id]) for sq,a in enumerate(pos.board) if a],dtype=np.intp)
    x=actors[None,:,0]-actors[:,None,0]+w-1
    y=actors[None,:,1]-actors[:,None,1]+h-1
    ix=(((actors[:,None,2]*nt+actors[None,:,2])*dxn+x)*dyn+y)
    ix,v=np.unique(ix[~np.eye(len(actors),dtype=bool)],return_counts=True)
    out=np.zeros(dim,dtype=np.int16);out[ix]=v
    assert v.sum()==len(actors)*(len(actors)-1)
    return out
rootmap={r['ply']:r for r in decl['roots']};lm={r['ply']:r for r in labels['roots']}
s=GameSession(c);rows=[];targets=[];ids_out=[];position=[];root_sizes=[]
start=time.perf_counter()
for ply in range(13):
    if ply in rootmap:
        assert s.state.position.side_to_move==0
        root_sizes.append(len(rootmap[ply]['children']))
        for i,item in enumerate(rootmap[ply]['children']):
            child=apply_action(s.state,action_from_dict(item['action']),c)
            target=lm[ply]['children'][i]
            assert target['known'] and target['target_kind']=='finite-material-search'
            rows.append(pairs(child.position));position.append(enc.dense(child.position).astype(np.int16))
            targets.append(target['root_score']);ids_out.append([ply,i])
    if ply<len(decl['route']):s.submit(action_from_dict(decl['route'][ply]))
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    source_sha256={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in ('same-material-declaration.json','same-material-signal.json')},
    children=len(rows),root_sizes=root_sizes,methods={})
for name,vectors in (('relative_pairs',rows),('position_plus_pairs',[np.concatenate((a,b)) for a,b in zip(position,rows)])):
    single={};aliases=conflicts=0;alias_witness=[]
    for i,x in enumerate(vectors):
        key=hashlib.sha256(x.tobytes()).digest()
        if key in single:
            j=single[key];assert np.array_equal(x,vectors[j]);aliases+=1
            if targets[i]!=targets[j]:
                conflicts+=1
                if len(alias_witness)<3:alias_witness.append([ids_out[j],ids_out[i]])
        else:single[key]=i
    sums={};revisits=violations=0;witnesses=[]
    for a,b in itertools.combinations_with_replacement(range(len(vectors)),2):
        val=vectors[a]+vectors[b];key=hashlib.sha256(val.tobytes()).digest();y=targets[a]+targets[b]
        if key in sums:
            u,v,previous=sums[key];assert np.array_equal(val,vectors[u]+vectors[v]);revisits+=1
            if y!=previous:
                violations+=1
                if len(witnesses)<3:witnesses.append(dict(left=[ids_out[u],ids_out[v]],right=[ids_out[a],ids_out[b]],target_sums=[previous,y]))
        else:sums[key]=(a,b,y)
    report['methods'][name]=dict(dimension=len(vectors[0]),identical_input_revisits=aliases,
        conflicting_single_revisits=conflicts,alias_witnesses=alias_witness,
        sum_pairs=len(vectors)*(len(vectors)+1)//2,equal_sum_revisits=revisits,
        conflicting_sum_revisits=violations,first_witnesses=witnesses)
report['seconds']=time.perf_counter()-start
write_record(p/'pair-batch-audit.json',report);print(json.dumps(report,indent=2))
