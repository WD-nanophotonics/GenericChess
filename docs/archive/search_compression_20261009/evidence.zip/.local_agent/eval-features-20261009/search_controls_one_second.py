"""Existing search mechanisms versus fixed finite compression target, no training.
Same frozen six roots/four configurations, balanced repeats at1second/q0.
Post-control decision: does cheaper ordering change finite-teacher regret under
the SAME wall budget? No changed labels, target, cohort or model selection.
Question: is an apparent compression opportunity already solved cheaply by
existing search? Report all caps/work and best-set regret, not player strength.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not (p/'search-controls-one-second.json').exists()
decl=json.loads((p/'prospective-target-declaration.json').read_bytes());labels=json.loads((p/'prospective-target-d2-completed.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));types=non_anchor_type_ids(c)
class Unit:
    def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
methods=[('base',False,False),('tt',True,False),('order',False,True),('tt_order',True,True)]
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    source_sha256={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in ('prospective-target-declaration.json','prospective-target-d2-completed.json')},calls=[],complete=False)
for root,row in zip(decl['roots'],labels['roots']):
    s=GameSession(c)
    for a in root['route']:s.submit(action_from_dict(a))
    teachers={json.dumps(x['action'],sort_keys=True):y['targets']['2']['root_score'] for x,y in zip(root['children'],row['children'])}
    maximum=max(teachers.values());before=s.state
    for rep in range(2):
        for name,tt,order in (methods if rep==0 else list(reversed(methods))):
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=tt,use_ordering=order,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
            tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick
            validate_pv(s,d);assert s.state==before
            key=json.dumps(action_to_dict(d.action),sort_keys=True);assert key in teachers
            if d.completed_depth==3:assert d.score==maximum
            report['calls'].append(dict(seed=root['seed'],group=root['group'],rep=rep,method=name,seconds=elapsed,
                teacher_regret=maximum-teachers[key],teacher_top=teachers[key]==maximum,decision=record_value(d)))
            write_record(p/'search-controls-one-second.json',report)
        print(root['seed'],rep,[(x['method'],round(x['seconds'],3),x['decision']['completed_depth'],x['teacher_regret'])for x in report['calls'][-4:]],flush=True)
report['complete']=True;write_record(p/'search-controls-one-second.json',report)
