"""Prepare the fixed prospective pilot inputs; DOES NOT FIT A MODEL.
Reconstruct legal routes/children and compare source hashes, fixed owner0 target
and material baseline. Report train-only channel support, without transforming
or selecting any model from development/report labels.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent
decl=json.loads((p/'prospective-target-declaration.json').read_bytes())
labels=json.loads((p/'prospective-target-d2-completed.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));enc=SparsePositionEncoder(c);types=non_anchor_type_ids(c)
features=[];targets=[];baselines=[];groups=[];root_ids=[];child_ids=[];source_hashes=[]
for root,row in zip(decl['roots'],labels['roots']):
    s=GameSession(c)
    for a in root['route']:s.submit(action_from_dict(a))
    assert record_value(s.state)==root['state'] and s.state.position.side_to_move==0
    for i,(item,lab) in enumerate(zip(root['children'],row['children'])):
        child=apply_action(s.state,action_from_dict(item['action']),c)
        x=enc.dense(child.position);h=hashlib.sha256(x.tobytes()).hexdigest()
        assert h==item['position_sha256'] and record_value(child)==item['state']
        target=lab['targets']['2'];assert target['known'] and target['target_kind']=='finite-material-search'
        material=1000*sum(material_features(child.position,types,perspective=0).array())
        assert material==1000*sum(item['material']['board_counts']+item['material']['hand_counts'])
        features.append(x);targets.append(target['root_score']-material);baselines.append(material)
        groups.append(root['group']);root_ids.append(root['seed']);child_ids.append(i);source_hashes.append(h)
x=np.asarray(features);g=np.asarray(groups);train=x[g=='train'];train_variable=np.ptp(train,axis=0)>0
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    declaration_sha256=hashlib.sha256((p/'prospective-target-declaration.json').read_bytes()).hexdigest(),
    labels_sha256=hashlib.sha256((p/'prospective-target-d2-completed.json').read_bytes()).hexdigest(),
    shape=list(x.shape),group_counts={name:int(np.sum(g==name)) for name in ('train','dev','test')},
    train_variable_channels=int(train_variable.sum()),train_constant_channels=int((~train_variable).sum()),
    novel_channels_per_group={name:int(np.count_nonzero(np.any(x[g==name]!=train[0],axis=0)&~train_variable)) for name in ('train','dev','test')},
    training_started=False,model_selected=False)
np.savez_compressed(p/'compression-inputs.npz',features=x,targets=np.asarray(targets),baseline=np.asarray(baselines),
    groups=g,roots=np.asarray(root_ids),children=np.asarray(child_ids),position_hashes=np.asarray(source_hashes))
report['npz_sha256']=hashlib.sha256((p/'compression-inputs.npz').read_bytes()).hexdigest()
write_record(p/'compression-inputs.json',report);print(json.dumps(report,indent=2))
