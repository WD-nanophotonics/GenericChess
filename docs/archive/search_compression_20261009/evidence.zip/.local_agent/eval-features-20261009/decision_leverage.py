"""Descriptive decision leverage of retained complete-root teachers, no fit.
Every declared legal child, original root weighting, ties averaged uniformly.
Compare material-only one-step selection with finite D2-child teacher optimum.
Same-material contrasts in inferior groups need not change the actual root
choice. Regret uses finite teacher only, not true value or playing strength.
"""
from pathlib import Path
import json,hashlib,itertools,statistics
p=Path(__file__).parent
decl=json.loads((p/'same-material-declaration.json').read_bytes())
data=json.loads((p/'same-material-signal.json').read_bytes())
roots=[]
for d,r in zip(decl['roots'],data['roots']):
    assert d['ply']==r['ply'] and len(d['children'])==len(r['children'])
    assert all(x['known'] and x['target_kind']=='finite-material-search' for x in r['children'])
    m=[1000*sum(x['material']['board_counts']+x['material']['hand_counts']) for x in d['children']]
    y=[x['root_score'] for x in r['children']];maximum=max(y)
    chosen=[i for i,x in enumerate(m) if x==max(m)]
    best=[i for i,x in enumerate(y) if x==maximum]
    regrets=[maximum-y[i] for i in chosen]
    roots.append(dict(ply=r['ply'],children=len(y),material_best_value=max(m),
        material_top_indices=chosen,teacher_top_indices=best,
        overlap=len(set(chosen)&set(best)),
        material_tie_teacher_range=[min(y[i] for i in chosen),max(y[i] for i in chosen)],
        material_uniform_tie_expected_regret=statistics.mean(regrets),
        material_tie_min_regret=min(regrets),material_tie_max_regret=max(regrets),
        blind_expected_regret=maximum-statistics.mean(y),
        material_top_pair_differences=sum(y[a]!=y[b] for a,b in itertools.combinations(chosen,2)),
        material_top_pairs=len(chosen)*(len(chosen)-1)//2))
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    sources_sha256={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in ('same-material-declaration.json','same-material-signal.json')},roots=roots,
    equal_root_mean_material_regret=statistics.mean(r['material_uniform_tie_expected_regret'] for r in roots),
    equal_root_mean_blind_regret=statistics.mean(r['blind_expected_regret'] for r in roots))
(p/'decision-leverage.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
