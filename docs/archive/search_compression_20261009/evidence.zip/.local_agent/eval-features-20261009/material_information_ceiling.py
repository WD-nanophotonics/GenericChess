"""Descriptive best material-equivalence-group ceiling, never a fitted scorer.
Retain all six roots/all children. Any scorer of the FULL material vector gives
equal scores within a group; assume uniform ties. A clairvoyant selector may
choose a different material group at each root, strictly more flexible than
shared static prices. Its minimum regret lower-bounds that scoped scorer family.
No coefficients, hyperparameters, price recommendations or deployed choices.
"""
from pathlib import Path
import json,hashlib,statistics,collections
p=Path(__file__).parent
decl=json.loads((p/'prospective-target-declaration.json').read_bytes())
labels=json.loads((p/'prospective-target-d2-completed.json').read_bytes())
rows=[]
for root,row in zip(decl['roots'],labels['roots']):
    groups=collections.defaultdict(list)
    targets=[x['targets']['2']['root_score']for x in row['children']]
    assert all(x['targets']['2']['known']for x in row['children'])
    best=max(targets)
    for i,item in enumerate(root['children']):
        groups[json.dumps(item['material'],sort_keys=True)].append(i)
    detail=[]
    for key,indices in groups.items():
        values=[targets[i]for i in indices]
        detail.append(dict(material=json.loads(key),indices=indices,teacher_range=[min(values),max(values)],
            expected_regret=statistics.mean(best-v for v in values),
            top_fraction=statistics.mean(v==best for v in values)))
    minimum=min(r['expected_regret']for r in detail)
    bestgroups=[r for r in detail if r['expected_regret']==minimum]
    rows.append(dict(seed=root['seed'],group=root['group'],children=len(targets),groups=len(groups),
        clairvoyant_group_min_expected_regret=minimum,best_groups=bestgroups,all_groups=detail))
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    sources_sha256={f:hashlib.sha256((p/f).read_bytes()).hexdigest()for f in ('prospective-target-declaration.json','prospective-target-d2-completed.json')},
    rows=rows,equal_root_mean_minimum_regret=statistics.mean(r['clairvoyant_group_min_expected_regret']for r in rows),
    zero_regret_group_roots=sum(r['clairvoyant_group_min_expected_regret']==0 for r in rows),scorer_fitted=False)
(p/'material-information-ceiling.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items()if k not in ('all_groups','best_groups')}for r in rows],indent=2))
