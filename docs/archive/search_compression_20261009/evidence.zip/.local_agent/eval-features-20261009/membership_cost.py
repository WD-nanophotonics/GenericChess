"""Measure cached legal-tuple membership inside actual full-root Core search.
No candidate implementation, training or changed legality; injected timer keeps
the original predicate. Six declared roots, D3/20000nodes/10sec/q0, one call each.
If this guard is a negligible fraction of wall cost, defer its optimization.
"""
from pathlib import Path
import sys,json,time,hashlib,inspect,textwrap
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent
assert not (p/'membership-cost.json').exists()
decl=json.loads((p/'prospective-target-declaration.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));types=non_anchor_type_ids(c)
class Unit:
    def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
original=SearchPathRuntime._push_impl
source=textwrap.dedent(inspect.getsource(original))
old='    if action not in self.legal_actions(checkpoint):'
new='''    _membership_tick = _membership_clock()
    _membership_legal = action in self.legal_actions(checkpoint)
    _membership_counter[0] += _membership_clock() - _membership_tick
    _membership_counter[1] += 1
    if not _membership_legal:'''
assert source.count(old)==1
counter=[0.,0];namespace=dict(original.__globals__)
namespace.update(_membership_clock=time.perf_counter,_membership_counter=counter)
exec(compile(source.replace(old,new),'<membership timing only>','exec'),namespace)
report=dict(scope=__doc__,source_sha256=hashlib.sha256(source.encode()).hexdigest(),
    producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),calls=[],complete=False)
try:
    SearchPathRuntime._push_impl=namespace['_push_impl']
    for root in decl['roots']:
        assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
        s=GameSession(c)
        for a in root['route']:s.submit(action_from_dict(a))
        before=s.state;counter[:]=[0.,0]
        player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
        tick=time.perf_counter()
        d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0))
        elapsed=time.perf_counter()-tick
        measured=list(counter)
        validate_pv(s,d);assert s.state==before and d.completed_depth==3
        report['calls'].append(dict(seed=root['seed'],seconds=elapsed,membership_seconds=measured[0],membership_calls=measured[1],wall_fraction=measured[0]/elapsed,decision=record_value(d)))
        write_record(p/'membership-cost.json',report)
        print(root['seed'],measured[1],round(measured[0]/elapsed,5),flush=True)
finally:SearchPathRuntime._push_impl=original
report['complete']=True;write_record(p/'membership-cost.json',report)
