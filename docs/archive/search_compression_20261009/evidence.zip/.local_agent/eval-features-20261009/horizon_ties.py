"""Independent D1-child reference for complete-root D2 ties, not new fitting.
Question: do existing orderer changes improve the finite target, or only select
different horizon ties? Only the two decision-changing dev/report roots0904/07,
83children, ENTIRE batch10seconds/4096leaves. This reduced run follows rejection
of the larger228child per-reference-cap proposal; no large batch is executed.
Preserve unknown failures. Compare D2choices with D3teacher.
"""
from pathlib import Path
import sys,json,time,hashlib,statistics
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not (p/'horizon-ties.json').exists()
decl=json.loads((p/'prospective-target-declaration.json').read_bytes());labels=json.loads((p/'prospective-target-d2-completed.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));types=non_anchor_type_ids(c)
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),roots=[],complete=False)
batch_started=time.perf_counter();batch_leaves=0
for root,row in zip(decl['roots'],labels['roots']):
    if root['seed'] not in (2026100904,2026100907):continue
    s=GameSession(c)
    for a in root['route']:s.submit(action_from_dict(a))
    children=[]
    for index,item in enumerate(root['children']):
        assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
        class Unit:
            def __init__(self):self.calls=0;self.started=time.perf_counter()
            def evaluate(self,state):
                global batch_leaves
                self.calls+=1
                batch_leaves+=1
                if batch_leaves>4096 or time.perf_counter()-batch_started>10:raise RuntimeError('whole-batch checkpoint')
                return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
        ev=Unit();tick=time.perf_counter();entry=dict(index=index,action=item['action'])
        try:
            if time.perf_counter()-batch_started>10 or batch_leaves>=4096:raise RuntimeError('whole-batch checkpoint; not executed')
            child=apply_action(s.state,action_from_dict(item['action']),c)
            score,action=reference_minimax(child,1,ev,c)
            entry.update(known=True,root_d2_action_value=-score,reply=record_value(action))
        except Exception as exc:entry.update(known=False,failure=dict(kind=type(exc).__name__,message=str(exc)))
        entry.update(leaves=ev.calls,seconds=time.perf_counter()-tick);children.append(entry)
    summary=dict(seed=root['seed'],children=children)
    if all(x['known']for x in children):
        values=[x['root_d2_action_value']for x in children];best=max(values);chosen=[i for i,v in enumerate(values)if v==best]
        teacher=[x['targets']['2']['root_score']for x in row['children']];best3=max(teacher)
        summary.update(d2_best_indices=chosen,d2_root_value=best,d2_uniform_tie_d3_regret=statistics.mean(best3-teacher[i]for i in chosen))
    report['roots'].append(summary);write_record(p/'horizon-ties.json',report)
    print(root['seed'],summary.get('d2_best_indices'),summary.get('d2_uniform_tie_d3_regret'),flush=True)
report['complete']=True;write_record(p/'horizon-ties.json',report)
