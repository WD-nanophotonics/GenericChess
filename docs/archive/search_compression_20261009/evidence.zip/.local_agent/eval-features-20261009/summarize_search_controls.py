"""Recompute all search control/cost/tie denominators; no calls or training."""
from pathlib import Path
import json,hashlib,statistics,collections,sys
sys.path.insert(0,str(Path.cwd()))
from generic_chess.core.actions import action_from_dict
from scripts.research_record import record_value
p=Path(__file__).parent
files=['compression-core-curve.json','membership-cost.json','search-controls.json','search-controls-one-second.json','horizon-ties.json','material-information-ceiling.json','opening-filter-audit.json']
data={f:json.loads((p/f).read_bytes())for f in files}
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),sources_sha256={f:hashlib.sha256((p/f).read_bytes()).hexdigest()for f in files})
def summarize(rows):
    return dict(calls=len(rows),completed_d3=sum(r['decision']['completed_depth']==3 for r in rows),
        caps=sum(r['decision']['termination_reason']!='completed_depth'for r in rows),
        depth_counts=dict(collections.Counter(str(r['decision']['completed_depth'])for r in rows)),
        mean_teacher_regret=statistics.mean(r['teacher_regret']for r in rows),
        mean_seconds=statistics.mean(r['seconds']for r in rows),
        mean_nodes=statistics.mean(r['decision']['nodes']for r in rows),
        tt_probes=sum(r['decision']['tt_probes']for r in rows),
        tt_hits=sum(r['decision']['tt_hits']for r in rows),
        tt_cutoffs=sum(r['decision']['tt_cutoffs']for r in rows),
        legal_generation_seconds=sum(r['decision']['legal_generation_seconds']for r in rows),
        evaluation_seconds=sum(r['decision']['evaluation_seconds']for r in rows),
        repeat_action_disagreements=sum(len({json.dumps(r['decision']['action'],sort_keys=True)for r in rows if r['seed']==seed})>1 for seed in {r['seed']for r in rows}))
curve=data['compression-core-curve.json'];assert curve['complete'] and len(curve['calls'])==48
report['core_wall_curve']={str(wall):summarize([r for r in curve['calls']if r['wall']==wall])for wall in (.1,.3,1.,3.)}
for file,key in [('search-controls.json','full_depth_controls'),('search-controls-one-second.json','one_second_controls')]:
    d=data[file];assert d['complete'] and len(d['calls'])==48
    rows={m:[r for r in d['calls']if r['method']==m]for m in ('base','tt','order','tt_order')}
    report[key]={m:summarize(r)for m,r in rows.items()}
    if key=='full_depth_controls':
        assert all(r['decision']['completed_depth']==3 and r['teacher_regret']==0 for r in d['calls'])
        ratios={}
        for m in ('tt','order','tt_order'):
            wall=[];nodes=[]
            for seed in {r['seed']for r in d['calls']}:
                a=[r for r in rows[m]if r['seed']==seed];b=[r for r in rows['base']if r['seed']==seed]
                wall.append(statistics.mean(r['seconds']for r in a)/statistics.mean(r['seconds']for r in b))
                nodes.append(statistics.mean(r['decision']['nodes']for r in a)/statistics.mean(r['decision']['nodes']for r in b))
            ratios[m]=dict(roots=len(wall),median_mean_root_wall_ratio=statistics.median(wall),median_mean_root_node_ratio=statistics.median(nodes))
        report['full_depth_cost_ratios']=ratios
membership=data['membership-cost.json'];assert membership['complete'] and len(membership['calls'])==6
report['membership_measurement']=dict(calls=6,total_membership_calls=sum(r['membership_calls']for r in membership['calls']),wall_fraction_range=[min(r['wall_fraction']for r in membership['calls']),max(r['wall_fraction']for r in membership['calls'])],candidate_implemented=False)
ties=data['horizon-ties.json'];assert ties['complete'] and len(ties['roots'])==2
report['horizon_ties']=[]
for root in ties['roots']:
    assert all(r['known']for r in root['children'])
    actionmap={json.dumps(record_value(action_from_dict(r['action'])),sort_keys=True):r['index']for r in root['children']}
    chosen=[]
    for call in data['search-controls-one-second.json']['calls']:
        if call['seed']!=root['seed']:continue
        assert call['decision']['completed_depth']==2
        i=actionmap[json.dumps(call['decision']['action'],sort_keys=True)]
        assert i in root['d2_best_indices'] and call['decision']['score']==root['d2_root_value']
        chosen.append(dict(method=call['method'],rep=call['rep'],index=i,d3_teacher_regret=call['teacher_regret']))
    report['horizon_ties'].append(dict(seed=root['seed'],full_children=len(root['children']),d2_best_count=len(root['d2_best_indices']),d2_uniform_tie_d3_regret=root['d2_uniform_tie_d3_regret'],selected=chosen))
report['material_information_ceiling']={k:v for k,v in data['material-information-ceiling.json'].items()if k in ('zero_regret_group_roots','equal_root_mean_minimum_regret')}
report['opening_filter_control']=[{k:v for k,v in r.items()if k in ('seed','opening_actions','immediate_wins','immediate_draws','initial_in_check','initial_terminal')}for r in data['opening-filter-audit.json']['cases']]
(p/'search-control-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
