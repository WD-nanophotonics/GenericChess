"""Existing generated-rule opening audit, no filtering of old evidence.
Question: do simple PRE-recombination generator filters certify the later
complete semantic rule's opening? Audit all four recorded rules, initial check
and complete one-ply terminal outcomes. No price/search target or new samples.
Counterfactual transplanted boards are deliberately excluded from this cohort.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.transition import apply_action
from generic_chess.core.actions import action_to_dict
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=Path('.local_agent/generated8-20261008/transfer.json')
out=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),cases=[])
for old in json.loads(src.read_bytes())['cases']:
    tick=time.perf_counter();c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c);engine=semantic_engine_for(c)
    rows=[];actions=s.legal_actions()
    for a in actions:
        child=apply_action(s.state,a,c)
        rows.append(dict(action=action_to_dict(a),terminal=record_value(child.terminal_status),opponent_in_check=engine.in_check(child.position,child.position.side_to_move)))
    out['cases'].append(dict(seed=old['seed'],initial_terminal=record_value(s.state.terminal_status),
        initial_in_check=[engine.in_check(s.state.position,side) for side in (0,1)],
        source_filters=old['generated_report']['filter_results'],opening_actions=len(actions),
        immediate_wins=sum(x['terminal']['winner']==0 and x['terminal']['status']!='ongoing' for x in rows),
        immediate_draws=sum(x['terminal']['winner'] is None and x['terminal']['status']!='ongoing' for x in rows),
        children=rows,seconds=time.perf_counter()-tick))
write_record(p/'opening-filter-audit.json',out)
print(json.dumps([{k:v for k,v in r.items() if k not in ('children','source_filters')}for r in out['cases']],indent=2))
