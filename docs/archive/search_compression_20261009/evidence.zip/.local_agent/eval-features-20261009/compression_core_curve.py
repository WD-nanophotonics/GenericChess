"""Fixed existing-Core baseline curve on the six frozen prospective roots.
No learned evaluator/training. Same unit, Core legality, no TT/order/disk/root
tactics,q0; maxD3/20000nodes and walls0.1/0.3/1/3sec, two balanced repeats.
Decision question: what actual search cost already preserves the D2-child
teacher's root choices? All48calls retained including partial-depth fallbacks;
completeD3 must agree with the complete child teacher. Not strength/true value.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not (p/'compression-core-curve.json').exists()
decl=json.loads((p/'prospective-target-declaration.json').read_bytes());labels=json.loads((p/'prospective-target-d2-completed.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));types=non_anchor_type_ids(c)
class Unit:
    def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    source_sha256={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in ('prospective-target-declaration.json','prospective-target-d2-completed.json')},calls=[],complete=False)
for root,row in zip(decl['roots'],labels['roots']):
    s=GameSession(c)
    for a in root['route']:s.submit(action_from_dict(a))
    teachers={json.dumps(x['action'],sort_keys=True):y['targets']['2']['root_score'] for x,y in zip(root['children'],row['children'])}
    maximum=max(teachers.values());before=s.state
    for rep in range(2):
        for wall in ((.1,.3,1.,3.) if rep==0 else (3.,1.,.3,.1)):
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
            tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=wall,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick
            validate_pv(s,d);assert s.state==before
            key=json.dumps(action_to_dict(d.action),sort_keys=True);assert key in teachers
            if d.completed_depth==3:assert d.score==maximum
            report['calls'].append(dict(seed=root['seed'],group=root['group'],rep=rep,wall=wall,seconds=elapsed,
                teacher_regret=maximum-teachers[key],teacher_top=teachers[key]==maximum,decision=record_value(d)))
            write_record(p/'compression-core-curve.json',report)
        print(root['seed'],rep,[(x['wall'],x['decision']['completed_depth'],x['teacher_regret'])for x in report['calls'][-4:]],flush=True)
report['complete']=True;write_record(p/'compression-core-curve.json',report)
