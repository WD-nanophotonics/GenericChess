"""Recompute frozen development target statistics without fitting or new calls.
D4 remains228UNKNOWN (55capped,173unattempted). CompletedD3 values from the
aborted D4 arm are POST-HOC diagnostics, not relabelled D4 or a full6root target.
Only one root has all D3children; incomplete roots do not get complete-root regret.
"""
from pathlib import Path
import json,hashlib,itertools,statistics
p=Path(__file__).parent;decl=json.loads((p/'prospective-target-declaration.json').read_bytes())
data=json.loads((p/'prospective-target-d2-completed.json').read_bytes())
assert data['complete_d2'] and len(decl['roots'])==len(data['roots'])==6
rows=[];seen={};d4_calls=0;d4_known=0;d2cost=d4cost=0;total_nodes={'2':0,'4':0};evalcost=legalcost=0
for root,measured in zip(decl['roots'],data['roots']):
    assert root['seed']==measured['seed'] and len(root['children'])==len(measured['children'])
    n=len(root['children']);assert n>0
    material=[1000*sum(x['material']['board_counts']+x['material']['hand_counts']) for x in root['children']]
    targets=[x['targets']['2']['root_score'] for x in measured['children']]
    assert all(x['targets']['2']['known'] for x in measured['children'])
    best=max(targets);greedy=[i for i,x in enumerate(material) if x==max(material)]
    paircounts=dict(total=0,ties=0,differences=0)
    for a,b in itertools.combinations(range(n),2):
        if root['children'][a]['material']!=root['children'][b]['material']:continue
        paircounts['total']+=1;paircounts['differences' if targets[a]!=targets[b] else 'ties']+=1
    post=[]
    for item in measured['children']:
        for depth,val in item['targets'].items():
            total_nodes[depth]+=val.get('decision',{}).get('nodes',0)
            if depth=='2':d2cost+=val['seconds']
            else:
                d4cost+=val['seconds'];d4_known+=val['known'];d4_calls+='decision' in val
                if 'decision' in val:
                    decision=val['decision'];assert decision['completed_depth']==3
                    post.append((item['index'],-decision['score']))
                    legalcost+=decision['legal_generation_seconds'];evalcost+=decision['evaluation_seconds']
    row=dict(seed=root['seed'],group=root['group'],children=n,same_material_pairs=paircounts,
        d2_teacher_range=[min(targets),max(targets)],material_greedy_count=len(greedy),
        d2_material_expected_regret=statistics.mean(best-targets[i] for i in greedy),
        d2_blind_expected_regret=best-statistics.mean(targets),
        posthoc_d3_children=len(post),d4_known=sum(x['targets']['4']['known'] for x in measured['children']))
    if len(post)==n:
        y3=[v for _,v in post];assert [i for i,_ in post]==list(range(n))
        chosen2=[i for i,v in enumerate(targets) if v==best];best3=max(y3)
        row['complete_root_posthoc_d3']=dict(range=[min(y3),max(y3)],
            d2_choice_expected_d3_regret=statistics.mean(best3-y3[i] for i in chosen2),
            material_choice_expected_d3_regret=statistics.mean(best3-y3[i] for i in greedy),
            ties=sum(targets[a]==targets[b] for a,b in itertools.combinations(range(n),2)),
            strict_sign_reversals=sum((targets[a]-targets[b])*(y3[a]-y3[b])<0 for a,b in itertools.combinations(range(n),2)))
    rows.append(row)
    seen.setdefault(root['group'],set()).update(x['position_sha256'] for x in root['children'])
assert sum(r['children'] for r in rows)==228 and d4_calls==55 and d4_known==0
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    sources_sha256={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in ('prospective-target-declaration.json','prospective-target-d2-completed.json')},
    roots=rows,children=228,d2_complete=228,d4_known=0,d4_capped=55,d4_not_executed=173,
    total_seconds={'2':d2cost,'4':d4cost},total_nodes=total_nodes,
    d4_generation_seconds=legalcost,d4_leaf_evaluation_seconds=evalcost,
    position_overlap={a+'-'+b:len(seen[a]&seen[b]) for a,b in itertools.combinations(sorted(seen),2)},
    equal_root_mean_material_d2_regret=statistics.mean(x['d2_material_expected_regret'] for x in rows),
    equal_root_mean_blind_d2_regret=statistics.mean(x['d2_blind_expected_regret'] for x in rows))
(p/'prospective-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
