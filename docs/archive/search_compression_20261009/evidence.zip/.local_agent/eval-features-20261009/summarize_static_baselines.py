"""Recompute the existing-table controls without fitting or search."""
from pathlib import Path
import json,statistics,hashlib,collections
p=Path(__file__).parent;d=json.loads((p/'static-baselines.json').read_bytes())
assert d['complete'] and len(d['calls'])==24 and len(d['greedy'])==12
rows=[]
for version in ('generic-v2','semantic-opportunity-v3'):
    calls=[r for r in d['calls']if r['version']==version];greedy=[r for r in d['greedy']if r['version']==version]
    rows.append(dict(version=version,greedy_mean_unit_teacher_regret=statistics.mean(r['unit_teacher_expected_regret']for r in greedy),
        greedy_by_root=[dict(seed=r['seed'],ties=len(r['selected']),unit_teacher_regret=r['unit_teacher_expected_regret'])for r in greedy],
        calls=len(calls),completed_d3=sum(r['decision']['completed_depth']==3 for r in calls),
        depth_counts=dict(collections.Counter(str(r['decision']['completed_depth'])for r in calls)),
        mean_actual_seconds=statistics.mean(r['seconds']for r in calls),
        mean_unit_teacher_regret=statistics.mean(r['unit_teacher_regret']for r in calls),
        root_repeat_disagreements=sum(len({json.dumps(r['decision']['action'],sort_keys=True)for r in calls if r['seed']==seed})>1 for seed in {r['seed']for r in calls}),
        capped_roots=sorted({r['seed']for r in calls if r['decision']['completed_depth']!=3})))
report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256((p/'static-baselines.json').read_bytes()).hexdigest(),rows=rows,
    all_greedy_value_arrays_identical=all(a['values']==b['values']for a,b in zip(d['greedy'][::2],d['greedy'][1::2])),
    source_profile_values=[dict(version=r['version'],board=r['profile']['board_value_by_type'],hand=r['profile']['hand_value_by_base_type'],build_seconds=r['build_seconds'])for r in d['profiles']],
    interpretation='Unit-teacher agreement is not independent price quality; static prices alter alpha-beta tree work and capped fallback. No new price/default selected.')
(p/'static-baseline-summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
