"""All actual caller arms/caps, not leaf-score or strength comparisons."""
from pathlib import Path
from collections import defaultdict,Counter
from statistics import median
import json,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'callers.json';d=json.loads(src.read_bytes());assert d['complete'];report=dict(scope=__doc__,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rules=[],all_arms=[]);globalarms=defaultdict(list)
for old in d['rules']:
 assert len(old['calls'])==102 and old['roots']==17;arms=defaultdict(list);byroot=defaultdict(dict)
 for r in old['calls']:arms[(r['leaf'],r['q'])].append(r);globalarms[(r['leaf'],r['q'])].append(r);byroot[(r['ply'],r['q'])][r['leaf']]=r
 row=dict(seed=old['seed'],arms=[],sensitivity=[]);report['rules'].append(row)
 for (leaf,q),rs in arms.items():row['arms'].append(dict(leaf=leaf,q=q,calls=len(rs),complete=sum(r['complete'] for r in rs),seconds=sum(r['seconds'] for r in rs),nodes=sum(r['decision']['nodes'] for r in rs),qnodes=sum(r['decision']['qnodes'] for r in rs),scorings=sum(r['scorings'] for r in rs),reasons=dict(Counter(r['decision']['termination_reason'] for r in rs))))
 for q in [0,2]:
  for leaf in ['initial_source_capture','initial_source_total']:
   paired=[(rs['v3'],rs[leaf]) for (ply,qq),rs in byroot.items() if qq==q];joint=[(a,b) for a,b in paired if a['complete'] and b['complete']];row['sensitivity'].append(dict(q=q,leaf=leaf,changed_actions=sum(a['decision']['action']!=b['decision']['action'] for a,b in paired),both_complete=len(joint),both_complete_changed_actions=sum(a['decision']['action']!=b['decision']['action'] for a,b in joint)))
for (leaf,q),rs in globalarms.items():report['all_arms'].append(dict(leaf=leaf,q=q,calls=len(rs),complete=sum(r['complete'] for r in rs),seconds=sum(r['seconds'] for r in rs),median_seconds=median(r['seconds'] for r in rs),nodes=sum(r['decision']['nodes'] for r in rs),qnodes=sum(r['decision']['qnodes'] for r in rs),reasons=dict(Counter(r['decision']['termination_reason'] for r in rs))))
report['total_calls']=sum(len(r['calls']) for r in d['rules']);report['producer_seconds']=d['seconds'];report['all_PVs_replayed_and_roots_preserved']=True;write_record(p/'caller-analysis.json',report);print(report['all_arms']);print([r['sensitivity'] for r in report['rules']])
