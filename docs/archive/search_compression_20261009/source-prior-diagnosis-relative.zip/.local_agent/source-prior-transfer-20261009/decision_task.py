"""Independent scoped diagnostic of actual search decisions, not their scores.
Use all68existing frozen actual GameState roots and completed caller outputs.
Enumerate every legal root action, ordinary enemy board+hand removal minus
worst legal opponent ordinary removal, with virtualstop0 for the task oracle.
Unlike the task oracle, a player's actual forced move can have negative net.
No terminal-win/history/future-service reward. Full state/history still carried
in Session/transition. D3/q choices are not optimized for this short proxy.
Cost checkpoint10000transition/10sec per root, not candidate-only extra budget.
Incomplete references UNKNOWN, not zero. No increased horizons/refit/selection.
Possible outcomes choose whether these scoped tables have useful diagnostic
signal in actual decisions, or whether this proxy is too sparse; no strength.
One run max68x10sec plus replay, under1hour; no extra worker.
"""
from pathlib import Path
from collections import defaultdict
import json,sys,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'decision-task.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());calls=json.loads((p/'callers.json').read_bytes());assert calls['complete']
write_record(p/'decision-task-declaration.json',dict(scope=__doc__,inputs={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['declaration.json','callers.json']},producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
report=dict(scope=__doc__,rules=[],complete=False);allstart=time.perf_counter()
def key(a):return json.dumps(record_value(a),sort_keys=True)
for case,callrow in zip(d['rules'],calls['rules']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};byroot=defaultdict(list)
 for r in callrow['calls']:byroot[r['ply']].append(r)
 row=dict(seed=case['seed'],roots=[]);report['rules'].append(row)
 def ordinary(st,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in st.position.board)+sum(n for t,n in st.position.hands[owner].counts if t not in anchors)
 for ply in range(len(case['route'])+1):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];start=time.perf_counter();before=s.state;owner=before.position.side_to_move;acts=s.legal_actions();rr=dict(ply=ply,actions=[],transitions=0,complete=False,terminal=before.terminal_status.is_terminal);row['roots'].append(rr)
  def tick():
   rr['transitions']+=1
   if rr['transitions']>10000 or time.perf_counter()-start>10:raise RuntimeError('declared per-root cost checkpoint')
  try:
   for action in acts:
    child=apply_action(before,action,c);tick();gain=ordinary(before,1-owner)-ordinary(child,1-owner);replies=legal_actions(child,c);losses=[]
    for reply in replies:after=apply_action(child,reply,c);tick();losses.append(ordinary(child,owner)-ordinary(after,owner))
    worst=max([0]+losses);rr['actions'].append(dict(action=record_value(action),gain=gain,worst_loss=worst,net=gain-worst,replies=len(replies)))
   rr['complete']=True
  except RuntimeError as exc:rr['failure']=str(exc)
  rr['seconds']=time.perf_counter()-start;lookup={json.dumps(a['action'],sort_keys=True):a for a in rr['actions']};rr['oracle']=max([0]+[a['net'] for a in rr['actions']]) if rr['complete'] else None;rr['decisions']=[]
  for call in byroot[ply]:
   raw=call['decision']['action'];a=lookup.get(json.dumps(raw,sort_keys=True));rr['decisions'].append(dict(leaf=call['leaf'],q=call['q'],search_completed=call['complete'],action=raw,net=a['net'] if a else None,regret=rr['oracle']-a['net'] if rr['complete'] and a else None,task_known=rr['complete'] and a is not None))
  assert s.state==before;write_record(out,report);print(case['seed'],ply,rr['complete'],rr['transitions'],round(rr['seconds'],3),flush=True)
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
report['complete']=True;report['seconds']=time.perf_counter()-allstart;report['limits']='Producercomplete does not mean every referencecomplete. Caps/terminalempty fronts are explicitly unknown for decisions.';write_record(out,report)
