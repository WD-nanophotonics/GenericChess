"""Prospective fixed-predictor price usefulness, not Unit search compression.
Four preselected new generator seeds2106..2109, same8x8hybrid/recombined rules
and existing16ply route policy as2100..2103; no seed replacement or fitting. Two changed initial-source priors: analytical projected capture-count and total quiet+capture, equal initial ordinary source slots/both owners. Same original IID density. Past source-prior failures remain; these are frozen candidate selectors, not true prices. All candidates frozen on all four rules before any task queries.
Freeze rules/routes and all static/learned tables before task queries. Every
ordinary own slot/type, original immediate legal ordinary-removal reward with
virtual stop0. Equal slots then backgrounds, zeros/caps retained. Counterfactual
replacement is not a reachable game; reward excludes anchor wins/history/future
service. Full generated semantics preserved in route/legal-transition carriers.
Expected<5min, per-rule120sec/100000transition checkpoints; no deep search.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from dataclasses import replace
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
import json,sys,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('.local_agent/interaction-20261009')),str(Path('.local_agent/finite-law-20261009'))]
from prototype import actor_vectors
from finite_law import collect
from generic_chess.ai.evaluation.semantic import _path_union
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import write_record
p=Path('.local_agent/source-prior-transfer-20261009');assert not(p/'declaration.json').exists();frozen=[];compiled=[];fixtures=weird_rulesets();models={n:json.loads(Path(f'.local_agent/preference-20261009/{n}-model.json').read_bytes()) for n in ('full','partial2048','partial8192')}
for seed in (202610082106,202610082107,202610082108,202610082109):
 generated=generate_game(GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));base_drop=fixtures[1].semantic_actions[0];base_quiet=fixtures[2].semantic_actions[0]
 drop=replace(base_drop,type_ids=('P',),replace_selector=replace(base_drop.replace_selector,type_ids=('P',)),slot_guards=(RuleSlotGuard(slot_name='temp_right',value=0),));effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id='P')) if e.kind=='set_current_type' else e for e in base_quiet.effects);quiet=replace(base_quiet,type_ids=('X',),target_relation='empty',effects=effects);rules=replace(generated.ruleset,semantic_actions=(drop,quiet));c=compile_ruleset_for_execution(rules);s=GameSession(c);route=[]
 for ply in range(16):
  if s.state.terminal_status.is_terminal:break
  acts=s.legal_actions()
  if not acts:break
  def key(a):
   raw=action_to_dict(a);capture=False
   if hasattr(a,'to_square'):
    piece=s.state.position.board[a.to_square.rank*8+a.to_square.file];capture=piece is not None and piece.owner!=s.state.position.side_to_move
   return (0 if raw.get('pattern_id','').startswith('sem_01_') else 1 if raw.get('pattern_id','').startswith('sem_00_') else 2 if capture else 3,json.dumps(raw,sort_keys=True))
  a=min(acts,key=key);route.append(action_to_dict(a));s.submit(a)
 types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);v2=build_ruleset_profile(c,EvaluationConfig());v3,scope=build_semantic_opportunity_profile(c,EvaluationConfig());tables={n:{t:v.board_value_by_type[t] for t in types} for n,v in [('generic_v2',v2),('semantic_v3',v3)]};actors=actor_vectors(c)
 for name,m in models.items():
  w=np.zeros(938);w[np.asarray(m['count_columns'])[m['columns']]]=np.asarray(m['weights'])/m['scale'];tables[name]={t:float(actors[t]@w[:66]+actors[t]@w[396:462]) for t in types}
 # Changed-prior candidates frozen before task labels; no task-source fitting.
 initial=GameSession(c).state.position;A=c.board_shape.area;initial_sources=[x.owner*A+i for i,x in enumerate(initial.board) if x and x.current_type_id in types];cfg=EvaluationConfig();tables['initial_source_capture']={};tables['initial_source_total']={}
 for t in types:
  edges=collect(c,c.ir,t,cfg)[0];cap=quiet=0.
  for rho,w in zip(cfg.density_points,cfg.density_weights):
   cap+=w*sum(_path_union(ev,rho)*rho/2 for i in initial_sources for ev in edges['target_enemy'][i].values())/len(initial_sources)
   quiet+=w*sum(_path_union(ev,rho)*(1-rho) for i in initial_sources for ev in edges['target_empty'][i].values())/len(initial_sources)
  tables['initial_source_capture'][t]=cap;tables['initial_source_total'][t]=cap+quiet
 tables['blind']={t:0 for t in types};frozen.append(dict(seed=seed,rules=ruleset_to_dict(rules),route=route,types=types,tables=tables,fingerprint=c.ruleset_fingerprint,v3_exclusions={t:scope['types'][t]['excluded'] for t in types}));compiled.append(c)
write_record(p/'declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),models={n:hashlib.sha256(Path(f'.local_agent/preference-20261009/{n}-model.json').read_bytes()).hexdigest() for n in models},rules=frozen));out=dict(scope=__doc__,complete=False,rules=[])
for case,c in zip(frozen,compiled):
 start=time.perf_counter();s=GameSession(c);engine=semantic_engine_for(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};row=dict(seed=case['seed'],cells=[],backgrounds=[],transitions=0,complete=False);out['rules'].append(row)
 def count(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(n for t,n in pos.hands[owner].counts if t not in anchors)
 try:
  for ply in range(len(case['route'])+1):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];pos=s.state.position;side=pos.side_to_move;slots=[i for i,x in enumerate(pos.board) if x is not None and x.owner==side and x.current_type_id not in anchors];row['backgrounds'].append(dict(ply=ply,side=side,slots=len(slots),terminal=s.state.terminal_status.is_terminal))
   for source in slots:
    for t in case['types']:
     if time.perf_counter()-start>=120 or row['transitions']>=100000:raise RuntimeError('declared cost checkpoint')
     board=list(pos.board);board[source]=Piece(side,t,t,False);cp=replace(pos,board=tuple(board));before=count(cp,1-side);rewards=[]
     for action,binding in engine.iter_legal_action_bindings(cp):
      if action.source!=source:continue
      child=engine._transition(cp,action,binding);rewards.append(before-count(child,1-side));row['transitions']+=1
     row['cells'].append(dict(ply=ply,source=source,type=t,task=max([0]+rewards)))
   if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
  row['complete']=True
 except Exception as exc:row['failure']=dict(kind=type(exc).__name__,message=str(exc))
 row['seconds']=time.perf_counter()-start
 if row['complete']:
  slots=defaultdict(dict)
  for r in row['cells']:slots[(r['ply'],r['source'])][r['type']]=r['task']
  assert all(sorted(u)==case['types'] for u in slots.values());bg=defaultdict(list)
  for (ply,_),u in slots.items():
   losses={}
   for name,table in case['tables'].items():
    top=[t for t in case['types'] if table[t]==max(table.values())];pairs=[]
    for a,b in combinations(case['types'],2):
     selected=[a] if table[a]>table[b] else [b] if table[b]>table[a] else [a,b];pairs.append(F(max(u[a],u[b]))-sum((F(u[t]) for t in selected),F())/len(selected))
    losses[name]=dict(top=F(max(u.values()))-sum((F(u[t]) for t in top),F())/len(top),pair=sum(pairs,F())/len(pairs))
   bg[ply].append(losses)
  row['summary']={n:{k:sum((sum((r[n][k] for r in rs),F())/len(rs) for rs in bg.values()),F())/len(bg) for k in ('top','pair')} for n in case['tables']};row['slots']=len(slots);row['all_zero_slots']=sum(not any(v.values()) for v in slots.values());row['empty_backgrounds']=[b['ply'] for b in row['backgrounds'] if not b['slots']];row['chosen']={n:[t for t in case['types'] if table[t]==max(table.values())] for n,table in case['tables'].items()}
 write_record(p/'result.json',out);print(row['seed'],row['complete'],row['seconds'],row.get('summary'),flush=True)
out['complete']=all(r['complete'] for r in out['rules']);out['limits']='Four prospectively frozen new rules within existing generator/mechanism family, not unknown-rule universe or natural distribution. Complete physical reward excludes anchor/history/response utility; all generated semantics retained in execution. No training, numeric leaf/default or strength claim.';write_record(p/'result.json',out)
