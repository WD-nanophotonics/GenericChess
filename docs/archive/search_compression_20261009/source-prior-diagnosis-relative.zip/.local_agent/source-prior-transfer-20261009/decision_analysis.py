"""All-root task coverage and paired actual-decision contrasts; no score proxy."""
from pathlib import Path
from collections import Counter
import json,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'decision-task.json';d=json.loads(src.read_bytes());assert d['complete']
report=dict(scope=__doc__,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rules=[])
for r in d['rules']:
 roots=r['roots'];known=[x for x in roots if x['complete']];row=dict(seed=r['seed'],roots=len(roots),complete_references=len(known),unknown_references=len(roots)-len(known),transitions=sum(x['transitions'] for x in roots),seconds=sum(x['seconds'] for x in roots),oracle_counts=dict(Counter(x['oracle'] for x in known)),comparisons=[])
 for q in [0,2]:
  for leaf in ['initial_source_capture','initial_source_total']:
   pairs=[]
   for x in roots:
    a=next(v for v in x['decisions'] if v['leaf']=='v3' and v['q']==q);b=next(v for v in x['decisions'] if v['leaf']==leaf and v['q']==q)
    if a['task_known'] and b['task_known']:pairs.append((a,b))
   row['comparisons'].append(dict(q=q,leaf=leaf,task_known_pairs=len(pairs),better=sum(b['regret']<a['regret'] for a,b in pairs),worse=sum(b['regret']>a['regret'] for a,b in pairs),tied=sum(b['regret']==a['regret'] for a,b in pairs),baseline_regret_sum=sum(a['regret'] for a,b in pairs),candidate_regret_sum=sum(b['regret'] for a,b in pairs),joint_search_complete=sum(a['search_completed'] and b['search_completed'] for a,b in pairs)))
 report['rules'].append(row)
report['limitations']='All68roots kept; capped references UNKNOWN; sums scoped per rule, no pooled selector/default/strength claim. Short removal proxy excludes terminal wins and future drop/promotion service.'
write_record(p/'decision-analysis.json',report);print(json.dumps(report,indent=2))
