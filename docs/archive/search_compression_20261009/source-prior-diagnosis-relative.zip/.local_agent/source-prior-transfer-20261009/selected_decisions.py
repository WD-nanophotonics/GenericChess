"""Cheaper changed question: paired net reward of actual selected actions.
Keep original all-action oracle caps UNKNOWN. Reuse already complete action
references even when its root oracle capped; compute only missing unique chosen
actions from all six fixed arms, without choosing more favorable roots/arms.
This cannot yield complete-oracle regret or optimize a policy. Root selection is
the original all68route roots; action selection is explicitly policy dependent.
Same short ordinary-removal proxy and full legal replies. Incremental per-root
10sec/10000transition checkpoint; producer expected<12min, no extra worker.
Possible paired net signal versus no signal changes whether another price-use
target is warranted; no refit/default/strength. No extension of the frozen oracle.
"""
from pathlib import Path
from collections import defaultdict
import json,sys,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'selected-decisions.json';assert not out.exists();decl=json.loads((p/'declaration.json').read_bytes());old=json.loads((p/'decision-task.json').read_bytes());assert old['complete']
write_record(p/'selected-declaration.json',dict(scope=__doc__,input_sha256=hashlib.sha256((p/'decision-task.json').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
report=dict(scope=__doc__,rules=[],complete=False);started=time.perf_counter()
def key(raw):return json.dumps(raw,sort_keys=True)
class CostCheckpoint(Exception):pass
for case,prior in zip(decl['rules'],old['rules']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};row=dict(seed=case['seed'],roots=[]);report['rules'].append(row)
 def ordinary(st,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in st.position.board)+sum(n for t,n in st.position.hands[owner].counts if t not in anchors)
 for root in prior['roots']:
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];start=time.perf_counter();before=s.state;owner=before.position.side_to_move;rr=dict(ply=root['ply'],oracle_known=root['complete'],actions=list(root['actions']),incremental_transitions=0,reused_actions=len(root['actions']));row['roots'].append(rr);lookup={key(a['action']):a for a in rr['actions']};chosen={key(v['action']) for v in root['decisions'] if v['action'] is not None};legal={key(record_value(a)):a for a in s.legal_actions()}
  def tick():
   rr['incremental_transitions']+=1
   if rr['incremental_transitions']>10000 or time.perf_counter()-start>10:raise CostCheckpoint()
  try:
   for k in sorted(chosen):
    if k in lookup:continue
    action=legal[k];child=apply_action(before,action,c);tick();gain=ordinary(before,1-owner)-ordinary(child,1-owner);replies=legal_actions(child,c);losses=[]
    for reply in replies:after=apply_action(child,reply,c);tick();losses.append(ordinary(child,owner)-ordinary(after,owner))
    a=dict(action=record_value(action),gain=gain,worst_loss=max([0]+losses),net=gain-max([0]+losses),replies=len(replies));rr['actions'].append(a);lookup[k]=a
  except CostCheckpoint:rr['failure']='incremental selected-action cost checkpoint'
  rr['decisions']=[dict(leaf=v['leaf'],q=v['q'],search_completed=v['search_completed'],net=lookup[key(v['action'])]['net'] if key(v['action']) in lookup else None) for v in root['decisions']];rr['seconds']=time.perf_counter()-start;assert s.state==before;write_record(out,report);print(case['seed'],root['ply'],rr['incremental_transitions'],round(rr['seconds'],3),flush=True)
  if root['ply']<len(case['route']):s.submit(action_from_dict(case['route'][root['ply']]))
report['complete']=True;report['seconds']=time.perf_counter()-started;write_record(out,report)
