"""Hard-q-depth change alone: preserve abort versus completed-value semantics."""
from pathlib import Path
import sys,json
sys.path[:0]=[str(Path.cwd()),str(Path('tests'))]
from ai_fixtures import build_4x4_rooks
from conftest import make_state
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;c=build_4x4_rooks();s=GameSession(c);s._state=make_state(c,['....','R...','....','K.k.'],hands=([('R',1)],()));s._search_history_witnesses=(s.state.position,)
def pl():return AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
def call(player,hard):return player.choose_action(s,SearchLimits(max_depth=2,max_nodes=65536,quiescence_max_depth=1,quiescence_hard_max_depth=hard))
cold={hard:call(pl(),hard) for hard in [1,8]};rows=[]
for order in [[1,8],[8,1]]:
 player=pl();first=call(player,order[0]);last=call(player,order[1]);target=cold[order[1]];assert (last.score,last.completed_depth,last.termination_reason)==(target.score,target.completed_depth,target.termination_reason);rows.append(dict(order=order,first=record_value(first),last=record_value(last)))
write_record(p/'q-hard-repaired.json',dict(scope=__doc__,cold={str(k):record_value(v) for k,v in cold.items()},rows=rows));print({k:(v.score,v.completed_depth,v.termination_reason) for k,v in cold.items()})
