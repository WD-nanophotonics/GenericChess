"""Independently replay every prospective physical task through Core/Native.
Same frozen rules/routes/cells; no additional observations or outcome selection.
Reward deliberately ignores anchor/history utility, as in the original task.
"""
from pathlib import Path
import json,sys,time
from dataclasses import replace
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import action_to_dict,action_from_dict
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.core.identity import position_identity_key
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
from scripts.research_record import write_record
p=Path('.local_agent/source-prior-transfer-20261009');decl=json.loads((p/'declaration.json').read_bytes());result=json.loads((p/'result.json').read_bytes());assert result['complete'];old=json.loads(Path('.local_agent/preference-20261009/declaration.json').read_bytes());oldfingerprints={compile_ruleset_for_execution(ruleset_from_dict(r)).ruleset_fingerprint for r in old['rules']};rows=[];start=time.perf_counter()
for case,row in zip(decl['rules'],result['rules']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));assert c.ruleset_fingerprint not in oldfingerprints;s=GameSession(c);engine=semantic_engine_for(c);nr=compile_native_semantic_rules(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};checks=transitions=0
 lookup={(r['ply'],r['source'],r['type']):r['task'] for r in row['cells']}
 def count(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(n for t,n in pos.hands[owner].counts if t not in anchors)
 def key(a):return json.dumps(action_to_dict(a),sort_keys=True)
 for ply in range(len(case['route'])+1):
  pos=s.state.position;side=pos.side_to_move
  for source,piece in enumerate(pos.board):
   if piece is None or piece.owner!=side or piece.current_type_id in anchors:continue
   for t in case['types']:
    board=list(pos.board);board[source]=Piece(side,t,t,False);cp=replace(pos,board=tuple(board));packed=ns.pack_current_position(nr,cp,ply_count=0);core={key(_semantic_public_action(engine,a)):(a,b) for a,b in engine.iter_legal_action_bindings(cp) if a.source==source};native={}
    for raw in ns.transient_legal_actions(nr,packed):
     action=ns.public_action(nr,raw);sq=getattr(action,'from_square',None)
     if sq is not None and sq.rank*8+sq.file==source:native[key(action)]=raw
    assert core.keys()==native.keys();assert engine.in_check(cp,side)==ns.in_check(nr,packed,side);rewards=[]
    for name,(a,b) in core.items():
     child=engine._transition(cp,a,b);nc=ns.make_checked(nr,packed,native[name]);assert position_identity_key(child,c)==ns.position_key(nr,nc);rewards.append(count(cp,1-side)-count(child,1-side));transitions+=1
    assert max([0]+rewards)==lookup[ply,source,t];checks+=1
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 assert checks==len(row['cells']);rows.append(dict(seed=case['seed'],cells=checks,transition_parity=transitions,not_training_rule=True));print(rows[-1],flush=True)
write_record(p/'audit.json',dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,all_cells_replayed=True))
