"""Same analytic initial-source mechanism across two established rule compilers.
No human reference/holdout or fitted weights. Raw capture/total ratios are
descriptive opportunity under a hypothetical source/occupancy law, not material
truth. Full state remains in rule/session carriers; projection exclusions shown.
Also measure per-rule compilation/baseline/candidate preparation separately on
the four already frozen generated rules, verify tables before timing claims.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/finite-law-20261009')),str(Path(__file__).parent)]
from candidate import source_scores
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'cost-crossgame.json';assert not out.exists();decl=json.loads((p/'declaration.json').read_bytes());report=dict(scope=__doc__,generated=[],crossgame={})
for case in decl['rules']:
 t=time.perf_counter();c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));compiletime=time.perf_counter()-t;t=time.perf_counter();v3,_=build_semantic_opportunity_profile(c,EvaluationConfig());baselinetime=time.perf_counter()-t;t=time.perf_counter();value=source_scores(c);candidate_time=time.perf_counter()-t
 for typ,r in value['types'].items():
  for field,table in [('capture','initial_source_capture'),('total','initial_source_total')]:assert abs(r['values'][1][field]-case['tables'][table][typ])<1e-10
  assert v3.board_value_by_type[typ]==case['tables']['semantic_v3'][typ]
 report['generated'].append(dict(seed=case['seed'],compile_seconds=compiletime,baseline_profile_seconds=baselinetime,candidate_pair_seconds=candidate_time,all_frozen_tables_match=True))
for name,rules in [('Chess',build_western_chess_ruleset()),('Shogi',build_standard_shogi_ruleset())]:
 t=time.perf_counter();c=compile_ruleset_for_execution(rules);value=source_scores(c);types=value['types'];orders={};ratios={}
 for law,idx in [('uniform',0),('initial',1)]:
  orders[law]={field:sorted(types,key=lambda typ:(-types[typ]['values'][idx][field],typ)) for field in ['capture','total']}
  denom=types['P']['values'][idx];ratios[law]={typ:{field:r['values'][idx][field]/denom[field] if denom[field] else None for field in ['capture','total']} for typ,r in types.items()}
 report['crossgame'][name]=dict(raw=value,orders=orders,pawn_opportunity_ratios=ratios,seconds=time.perf_counter()-t)
 print(name,orders,ratios,flush=True)
report['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();write_record(out,report);print('cost',report['generated'],flush=True)
