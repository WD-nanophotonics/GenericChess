"""Explain adverse2109 pair ordering using all original slots, no refit."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import combinations
import json,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;decl=json.loads((p/'declaration.json').read_bytes());task=json.loads((p/'reply-task.json').read_bytes());aggregate=json.loads((p/'pair-analysis.json').read_bytes());rows=[]
for case,row,old in zip(decl['rules'],task['rules'],aggregate['rows']):
 bg=defaultdict(lambda:defaultdict(dict))
 for r in row['cells']:bg[r['ply']][r['source']][r['type']]=r['task']
 pairs=[]
 for a,b in combinations(case['types'],2):
  losses={}
  for name in ['semantic_v3','initial_source_capture','initial_source_total']:
   table=case['tables'][name];chosen=[a] if table[a]>table[b] else [b] if table[b]>table[a] else [a,b];weighted=[]
   for slots in bg.values():weighted.append(sum((F(max(v[a],v[b]))-sum((F(v[t]) for t in chosen),F())/len(chosen) for v in slots.values()),F())/len(slots))
   losses[name]=sum(weighted,F())/len(weighted)
  pairs.append(dict(pair=[a,b],losses=losses,minus_static={n:v-losses['semantic_v3'] for n,v in losses.items()},raw_tables={n:{t:case['tables'][n][t] for t in [a,b]} for n in losses}))
 for name in ['semantic_v3','initial_source_capture','initial_source_total']:assert sum((r['losses'][name] for r in pairs),F())/len(pairs)==F(old['losses'][name])
 rows.append(dict(seed=case['seed'],pairs=pairs))
write_record(p/'pair-breakdown.json',dict(scope=__doc__,rows=rows));print(json.dumps([{ 'seed':r['seed'],'changed':[{'pair':x['pair'],'minus_static':{n:str(v) for n,v in x['minus_static'].items()}} for x in r['pairs'] if any(x['minus_static'].values())]} for r in rows],indent=2))
