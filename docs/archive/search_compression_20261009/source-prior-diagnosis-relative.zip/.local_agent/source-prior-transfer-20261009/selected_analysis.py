"""Paired actual selected-action net proxy, full68roots; no oracle claim."""
from pathlib import Path
import json,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'selected-decisions.json';d=json.loads(src.read_bytes());assert d['complete'];rows=[]
for r in d['rules']:
 row=dict(seed=r['seed'],roots=len(r['roots']),incremental_transitions=sum(x['incremental_transitions'] for x in r['roots']),comparisons=[])
 for q in [0,2]:
  for leaf in ['initial_source_capture','initial_source_total']:
   pairs=[]
   for x in r['roots']:
    a=next(v for v in x['decisions'] if v['leaf']=='v3' and v['q']==q);b=next(v for v in x['decisions'] if v['leaf']==leaf and v['q']==q)
    if a['net'] is not None and b['net'] is not None:pairs.append((a,b))
   row['comparisons'].append(dict(q=q,leaf=leaf,known_pairs=len(pairs),better=sum(b['net']>a['net'] for a,b in pairs),worse=sum(b['net']<a['net'] for a,b in pairs),tie=sum(b['net']==a['net'] for a,b in pairs),baseline_net_sum=sum(a['net'] for a,b in pairs),candidate_net_sum=sum(b['net'] for a,b in pairs),joint_search_complete=sum(a['search_completed'] and b['search_completed'] for a,b in pairs)))
 rows.append(row)
report=dict(scope=__doc__,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rows=rows,seconds=d['seconds'],limitations='Selected-action net only, policy-dependent support, no full-oracle regret, terminal/history/future-service reward or model selection. Original all-action oracle UNKNOWNs remain.');write_record(p/'selected-analysis.json',report);print(json.dumps(report,indent=2))
