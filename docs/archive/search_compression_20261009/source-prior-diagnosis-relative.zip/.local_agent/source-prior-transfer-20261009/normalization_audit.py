"""Separate raw opportunity order from rounding/clipping and hand-price scope."""
from pathlib import Path
from itertools import combinations
from statistics import median
import json,sys
sys.path.insert(0,str(Path.cwd()))
from generic_chess.ai.evaluation.config import MAX_STATIC_EVAL
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'declaration.json').read_bytes());c=json.loads((p/'caller-declaration.json').read_bytes());rows=[]
def sign(x):return (x>0)-(x<0)
for rule,call in zip(d['rules'],c['profiles']):
 row=dict(seed=rule['seed'],arms=[])
 for name in ['initial_source_capture','initial_source_total']:
  raw=rule['tables'][name];board=call['leaf_board'][name];scale=median(raw.values());pairs=list(combinations(rule['types'],2));changed=[dict(pair=[a,b],raw_difference=raw[a]-raw[b],normalized_difference=board[a]-board[b]) for a,b in pairs if sign(raw[a]-raw[b])!=sign(board[a]-board[b])]
  row['arms'].append(dict(leaf=name,median=scale,pairs=len(pairs),changed_pair_order=changed,clipped=[t for t in raw if round(1000*raw[t]/scale)>MAX_STATIC_EVAL or round(1000*raw[t]/scale)<1],board_hand_ratio={t:board[t]/call['shared_hand'][t] for t in raw if call['shared_hand'][t]},scope='Shared original hand prices intentionally fixed; changed board/hand ratio is a leaf-only ablation, not a consistent joint material proposal.'))
 rows.append(row)
write_record(p/'normalization-audit.json',dict(scope=__doc__,rows=rows));print(json.dumps(rows,indent=2))
