"""Predeclared continuation: does positive immediate selection survive a reply?
Reuse four prospectively frozen new8x8rules2106..2109,68backgrounds/allactualslots/all5ordinarytypes and frozen
v2/v3, three frozen learned tables and two initial-source candidates. Same prior Chess one-reply unit task: max over focal legal actions
of immediate enemy ordinary board+hand removal minus worst legal opponent
ordinary removal, virtualstop0 for both. Anchor wins/history adjudication and
future service are outside this task; no WDL/material/strength claim. No new
route, seed, formula or density. Compare complete-type and all-pair regrets.
Per rule120sec/100000Coretransitions checkpoint, partial failures retained.
Nonpositive gains cannot exceed virtualstop0 because worst loss>=0; skip their
reply expansion exactly, record this optimization rather than hide work.
Every first positive child per background receives complete Core/Native reply
action-set and child-transition parity. Same task on all types, never candidate
only extra resources. Earlier immediate records exposed; one-reply results newly queried. No refit or holdout claim.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time,datetime
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.core.identity import position_identity_key
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
from scripts.research_record import write_record
p=Path('.local_agent/source-prior-transfer-20261009');out=p/'reply-task.json';assert not out.exists()
src=p/'declaration.json';rules=json.loads(src.read_bytes())
frozen=p/'declaration.json';predictors=json.loads(frozen.read_bytes())
declaration=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in (src,frozen)},at=datetime.datetime.now(datetime.timezone.utc).isoformat(),prices={str(r['seed']):r['tables'] for r in predictors['rules']})
write_record(p/'reply-declaration.json',declaration)
result=dict(scope=__doc__,declaration_sha256=hashlib.sha256((p/'reply-declaration.json').read_bytes()).hexdigest(),rules=[],complete=False)
for old in rules['rules']:
 start=time.monotonic();c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));eng=semantic_engine_for(c);nr=compile_native_semantic_rules(c);s=GameSession(c)
 anchors={t.type_id for t in c.piece_types if t.is_anchor};types=sorted(t.type_id for t in c.piece_types if not t.is_anchor)
 row=dict(seed=old['seed'],types=types,cells=[],transitions=0,reply_controls=0,native_control_transitions=0,skipped_nonpositive=0,complete=False);result['rules'].append(row)
 def count(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(n for t,n in pos.hands[owner].counts if t not in anchors)
 def tick():
  row['transitions']+=1
  if time.monotonic()-start>=120 or row['transitions']>100000:raise RuntimeError('declared per-rule cost checkpoint')
 def key(a):return json.dumps(action_to_dict(a),sort_keys=True)
 try:
  for ply in range(len(old['route'])+1):
   flags=json.loads(Path('.local_agent/rollout.json').read_bytes());assert not flags['user_paused']
   pos=s.state.position;side=pos.side_to_move;controlled=False
   for source,x in enumerate(pos.board):
    if x is None or x.owner!=side or x.current_type_id in anchors:continue
    for t in types:
     board=list(pos.board);board[source]=Piece(side,t,t,False);cp=replace(pos,board=tuple(board));actions=[]
     for a,b in eng.iter_legal_action_bindings(cp):
      if a.source!=source:continue
      child=eng._transition(cp,a,b);tick();gain=count(cp,1-side)-count(child,1-side)
      ar=dict(action=action_to_dict(_semantic_public_action(eng,a)),gain=gain)
      if gain<=0:row['skipped_nonpositive']+=1;ar.update(skipped='net<=gain<=0; virtualstop0 dominates',net_upper_bound=gain)
      else:
       losses=[];control={};check_control=not controlled
       for reply,rb in eng.iter_legal_action_bindings(child):
        after=eng._transition(child,reply,rb);tick();loss=count(child,side)-count(after,side);losses.append(loss)
        if check_control:control[key(_semantic_public_action(eng,reply))]=position_identity_key(after,c)
       ar.update(worst_loss=max([0]+losses),net=gain-max([0]+losses),opponent_replies=len(losses))
       if check_control:
        np=ns.pack_current_position(nr,child,ply_count=0);observed={}
        for raw in ns.transient_legal_actions(nr,np):
         observed[key(ns.public_action(nr,raw))]=ns.position_key(nr,ns.make_checked(nr,np,raw));row['native_control_transitions']+=1
        assert observed==control;row['reply_controls']+=1;controlled=True
      actions.append(ar)
     row['cells'].append(dict(ply=ply,source=source,type=t,task=max([0]+[a['net'] for a in actions if 'net' in a]),immediate=max([0]+[a['gain'] for a in actions]),actions=actions))
   write_record(out,result)
   if ply<len(old['route']):s.submit(action_from_dict(old['route'][ply]))
  row['complete']=True
 except Exception as exc:row['failure']=dict(kind=type(exc).__name__,message=str(exc))
 row['seconds']=time.monotonic()-start;write_record(out,result)
 print(old['seed'],'complete',row['complete'],'cells',len(row['cells']),'transitions',row['transitions'],'seconds',row['seconds'],row.get('failure'),flush=True)
result['complete']=all(r['complete'] for r in result['rules']);write_record(out,result)
