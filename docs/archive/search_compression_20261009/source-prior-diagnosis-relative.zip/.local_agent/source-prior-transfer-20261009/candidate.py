"""Offline source-prior selector only; not a product profile or universal price.
Shared source slots for every counterfactual type: all initial ordinary actors
of both owners. Original IID density points/weights and supported projection.
Promotion, drop, history and excluded effects are NOT valued by this selector.
"""
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import _path_union
from generic_chess.rules.compiler import compile_semantic_ir
from generic_chess.session.session import GameSession
from finite_law import collect

def source_scores(c):
 cfg=EvaluationConfig();A=c.board_shape.area if hasattr(c,'ir') else c.board_size**2;ir=c.ir if hasattr(c,'ir') else compile_semantic_ir(c);types=[t.type_id for t in c.piece_types if not t.is_anchor];initial=GameSession(c).state.position;slots=[x.owner*A+i for i,x in enumerate(initial.board) if x and x.current_type_id in types]
 if not slots:raise ValueError('initial ordinary-source prior is undefined')
 result={}
 for t in types:
  edges,inc,exc=collect(c,ir,t,cfg);rows=[]
  for name,indices in [('uniform',range(2*A)),('initial',slots)]:
   values={}
   for kind,factor in [('target_enemy',lambda d:d/2),('target_empty',lambda d:1-d)]:values[kind]=sum(w*sum(_path_union(ev,d)*factor(d) for i in indices for ev in edges[kind][i].values())/len(indices) for d,w in zip(cfg.density_points,cfg.density_weights))
   rows.append(dict(source=name,capture=values['target_enemy'],quiet=values['target_empty'],total=sum(values.values())))
  result[t]=dict(values=rows,included=inc,excluded=exc)
 return dict(types=result,initial_source_indices=slots,scope=__doc__)
