"""Full pair loss of original complete one-reply cells, all zeros retained.
Exact old equal-slot then equal-background weights. No refit/selection.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import combinations
import json,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'reply-task.json';d=json.loads(src.read_bytes());decl=json.loads((p/'declaration.json').read_bytes());rows=[]
for case,row in zip(decl['rules'],d['rules']):
 assert row['complete'];bg=defaultdict(lambda:defaultdict(dict))
 for r in row['cells']:bg[r['ply']][r['source']][r['type']]=r['task']
 assert len(bg)==17;losses={}
 for name,table in case['tables'].items():
  means=[]
  for slots in bg.values():
   acc=[]
   for values in slots.values():
    assert sorted(values)==case['types'];pairs=[]
    for a,b in combinations(case['types'],2):
     selected=[a] if table[a]>table[b] else [b] if table[b]>table[a] else [a,b]
     pairs.append(F(max(values[a],values[b]))-sum((F(values[t]) for t in selected),F())/len(selected))
    acc.append(sum(pairs,F())/len(pairs))
   means.append(sum(acc,F())/len(acc))
  losses[name]=sum(means,F())/len(means)
 rows.append(dict(seed=case['seed'],losses=losses,minus_static={n:v-losses['semantic_v3'] for n,v in losses.items()},slots=sum(len(s) for s in bg.values())))
 print(case['seed'],{n:str(v) for n,v in losses.items()},flush=True)
write_record(p/'pair-analysis.json',dict(scope=__doc__,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rows=rows))
