"""Bounded public-player TT probe when caller changes q limits.
Three existing small search fixtures, cold q0/q2 controls versus same-player
q0->q2 andq2->q0, unchanged evaluator/rules/state. D2/65536nodes/10sec.
Not a learned task or source-prior benchmark; scores compare search semantics.
Only completed results can establish an inconsistent warm-cache value.
"""
from pathlib import Path
import sys,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests'))]
from ai_fixtures import build_4x4_rooks
from conftest import make_state
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'q-cache-probe.json';assert not out.exists();c=build_4x4_rooks();states=[make_state(c,['....','R...','....','K.k.'],hands=([('R',1)],())),make_state(c,['R..K','....','.r..','k...'],side_to_move=1),GameSession(c).state];result=dict(scope=__doc__,rows=[],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());start=time.perf_counter()
for idx,state in enumerate(states):
 s=GameSession(c);s._state=state;s._search_history_witnesses=(state.position,);row=dict(fixture=idx,cold={},warm=[]);result['rows'].append(row)
 def player():return AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
 def query(pl,q):
  decision=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=65536,max_time_seconds=10,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0));validate_pv(s,decision);assert s.state==state;return record_value(decision)
 for q in [0,2]:row['cold'][str(q)]=query(player(),q)
 for order in [[0,2],[2,0]]:
  pl=player();decisions=[query(pl,q) for q in order];cold=row['cold'][str(order[-1])];last=decisions[-1];row['warm'].append(dict(order=order,decisions=decisions,completed_score_mismatch=last['completed_depth']==cold['completed_depth']==2 and last['score']!=cold['score']))
 write_record(out,result);print(idx,{q:(d['score'],d['completed_depth']) for q,d in row['cold'].items()},[(x['order'],x['decisions'][-1]['score'],x['completed_score_mismatch']) for x in row['warm']],flush=True)
result['seconds']=time.perf_counter()-start;write_record(out,result)
