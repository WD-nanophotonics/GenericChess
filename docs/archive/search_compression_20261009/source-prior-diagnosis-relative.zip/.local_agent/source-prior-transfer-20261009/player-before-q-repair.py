"""AlphaBetaPlayer: the public AI player interface."""

from __future__ import annotations

import time

from ...rules.compiled import CompiledRuleSet
from ...session.session import GameSession
from ..cancellation import CancellationToken
from ..decision import PlayerDecision
from ..evaluation.cache import EvaluationProfileCache
from ..evaluation.config import EvaluationConfig
from ..evaluation.evaluator import Evaluator
from ..limits import SearchLimits
from .search import run_root_search
from .native_legality import NativeSemanticLegalityProvider
from .statistics import SearchStatistics
from .transposition import TranspositionTable
from .tuning import SearchTuning


class AlphaBetaPlayer:
    """Deterministic, rule-derived alpha-beta player for any GenericChess RuleSet.

    The evaluation profile is built once per RuleSet (cached); the
    transposition table is kept across moves for the same RuleSet and cleared
    when a different RuleSet is loaded.
    """

    def __init__(
        self,
        compiled: CompiledRuleSet,
        *,
        evaluation_config: EvaluationConfig | None = None,
        tt_max_entries: int = 250_000,
        profile_cache: EvaluationProfileCache | None = None,
        use_disk_cache: bool = True,
        disk_cache_dir: str | None = None,
        use_tt: bool = True,
        use_ordering: bool = True,
        # H21B default-on policy.  ``False`` remains the explicit Python
        # authority control for parity, diagnostics, and emergency rollback.
        use_native_semantic_legality: bool = True,
        tuning: SearchTuning = SearchTuning(),
        evaluator_override=None,
    ) -> None:
        self._compiled = compiled
        self._config = evaluation_config if evaluation_config is not None else EvaluationConfig()
        self._profile = None
        self._profile_cache_hit = False
        self._profile_cache = profile_cache
        if evaluator_override is None:
            self._profile_cache = profile_cache or EvaluationProfileCache(
                use_disk=use_disk_cache, disk_dir=disk_cache_dir
            )
            self._profile, self._profile_cache_hit = self._profile_cache.get_or_build(
                compiled, self._config
            )
            self._evaluator = Evaluator(compiled, self._profile, self._config)
        else:
            # A supplied evaluator owns its inputs. Building an unused default
            # profile can reject rules that the evaluator/search can execute.
            self._evaluator = evaluator_override
        self._tt = TranspositionTable(max_entries=tt_max_entries)
        self._use_tt = use_tt
        self._use_ordering = use_ordering
        self._use_native_semantic_legality = bool(use_native_semantic_legality)
        self._native_legality_provider = (
            NativeSemanticLegalityProvider.try_create(compiled)
            if self._use_native_semantic_legality
            else None
        )
        self._tuning = tuning

    @property
    def compiled(self) -> CompiledRuleSet:
        return self._compiled

    @property
    def evaluation_profile(self):
        """Generated default profile, or None when an evaluator was supplied."""
        return self._profile

    @property
    def evaluation_profile_cache_hit(self) -> bool:
        return self._profile_cache_hit

    @property
    def use_native_semantic_legality(self) -> bool:
        return self._use_native_semantic_legality

    @property
    def native_legality_provider(self):
        return self._native_legality_provider

    def reset(self) -> None:
        """Clear search state (e.g., after loading a different RuleSet)."""
        self._tt.clear()

    def choose_action(
        self,
        session: GameSession,
        limits: SearchLimits,
        *,
        cancel_token: CancellationToken | None = None,
        progress_callback=None,
        recorder=None,
    ) -> PlayerDecision:
        state = session.state
        started = time.monotonic()
        stats = SearchStatistics()
        action, score, pv, reason = run_root_search(
            state,
            self._compiled,
            self._evaluator,
            self._tt,
            limits,
            cancel_token,
            stats,
            use_tt=self._use_tt,
            use_ordering=self._use_ordering,
            tuning=self._tuning,
            _history_witnesses=session._search_witnesses,
            legal_binding_provider=(
                self._native_legality_provider
                if self._use_native_semantic_legality
                else None
            ),
            recorder=recorder,
            progress_callback=progress_callback,
        )
        elapsed = time.monotonic() - started
        return PlayerDecision(
            action=action,
            score=score,
            principal_variation=pv,
            completed_depth=stats.completed_depth,
            selective_depth=stats.selective_depth,
            nodes=stats.nodes,
            qnodes=stats.qnodes,
            elapsed_seconds=elapsed,
            tt_probes=stats.tt_probes,
            tt_hits=stats.tt_hits,
            tt_cutoffs=stats.tt_cutoffs,
            beta_cutoffs=stats.beta_cutoffs,
            evaluation_profile_cache_hit=self._profile_cache_hit,
            termination_reason=reason,
            choice_kind=(
                "TERMINAL"
                if reason == "terminal_position" and not stats.declaration_root_selected
                else "DECLARATION" if stats.declaration_root_selected else "ACTION"
            ),
            declaration=stats.root_declaration,
            time_to_first_legal_action=stats.time_to_first_legal_action,
            time_to_first_completed_iteration=stats.time_to_first_completed_iteration,
            qdepth_cutoffs=stats.qdepth_cutoffs,
            qsearch_budget_aborts=stats.qsearch_budget_aborts,
            qsearch_check_hard_limit_aborts=stats.qsearch_check_hard_limit_aborts,
            in_check_qnodes=stats.in_check_qnodes,
            stand_pat_cutoffs=stats.stand_pat_cutoffs,
            capture_qactions=stats.capture_qactions,
            material_change_qactions=stats.material_change_qactions,
            promotion_qactions=stats.promotion_qactions,
            checking_move_qactions=stats.checking_move_qactions,
            checking_drop_qactions=stats.checking_drop_qactions,
            nonchecking_drop_excluded=stats.nonchecking_drop_excluded,
            pvs_null_window_searches=stats.pvs_null_window_searches,
            pvs_researches=stats.pvs_researches,
            aspiration_fail_low=stats.aspiration_fail_low,
            aspiration_fail_high=stats.aspiration_fail_high,
            aspiration_researches=stats.aspiration_researches,
            root_scan_nodes=stats.root_scan_nodes,
            root_scan_used_fallback=stats.root_scan_used_fallback,
            move_picker_generated=stats.move_picker_generated,
            move_picker_yielded=stats.move_picker_yielded,
            move_picker_yielded_by_stage=dict(stats.move_picker_yielded_by_stage),
            ordering_calls=stats.ordering_calls,
            ordered_moves=stats.ordered_moves,
            ordering_seconds=stats.ordering_seconds,
            legal_generation_calls=stats.legal_generation_calls,
            legal_generation_seconds=stats.legal_generation_seconds,
            evaluation_calls=stats.evaluation_calls,
            evaluation_seconds=stats.evaluation_seconds,
            countermove_hits=stats.countermove_hits,
            mate_pruning_cutoffs=stats.mate_pruning_cutoffs,
            legal_actions_generated=stats.legal_actions_generated,
            successor_handles_created=stats.successor_handles_created,
            successors_materialized=stats.successors_materialized,
            successors_searched=stats.successors_searched,
            terminal_results_computed=stats.terminal_results_computed,
            terminal_cache_hits=stats.terminal_cache_hits,
            position_keys_computed=stats.position_keys_computed,
            position_key_cache_hits=stats.position_key_cache_hits,
            declaration_checks=stats.declaration_checks,
            declaration_win_options=stats.declaration_win_options,
            declaration_restart_options=stats.declaration_restart_options,
            declaration_root_selected=stats.declaration_root_selected,
            native_legality_calls=stats.native_legality_calls,
            native_legality_fallbacks=stats.native_legality_fallbacks,
            native_legality_operational_failures=stats.native_legality_operational_failures,
        )
