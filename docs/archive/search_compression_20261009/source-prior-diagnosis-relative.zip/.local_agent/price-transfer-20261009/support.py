"""Read-only influence/phase audit on all new-rule task slots; no filter/refit."""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
import json,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path('.local_agent/price-transfer-20261009');d=json.loads((p/'result.json').read_bytes());decl=json.loads((p/'declaration.json').read_bytes());rows=[]
for row,case in zip(d['rules'],decl['rules']):
 assert row['complete'];cells=defaultdict(dict)
 for r in row['cells']:cells[(r['ply'],r['source'])][r['type']]=r['task']
 means={};groups=defaultdict(list);sides={b['ply']:b['side'] for b in row['backgrounds']}
 for (ply,source),u in cells.items():groups[ply].append(u)
 for ply,slots in groups.items():means[ply]={t:sum((F(u[t])for u in slots),F())/len(slots) for t in case['types']}
 static=row['chosen']['semantic_v3'];candidate=row['chosen']['partial2048']
 contrasts={ply:sum((m[t] for t in candidate),F())/len(candidate)-sum((m[t]for t in static),F())/len(static) for ply,m in means.items()}
 strata=[]
 for owner in (0,1):
  for phase in ('early','late'):
   selected=[ply for ply in means if sides[ply]==owner and ('early' if ply<8 else 'late')==phase]
   strata.append(dict(owner=owner,phase=phase,backgrounds=len(selected),candidate_minus_static=sum((contrasts[i]for i in selected),F())/len(selected) if selected else None))
 loo=[sum((v for k,v in contrasts.items()if k!=i),F())/(len(contrasts)-1) for i in means]
 rows.append(dict(seed=row['seed'],static=static,partial2048=candidate,means={t:sum((m[t] for m in means.values()),F())/len(means) for t in case['types']},positive_backgrounds=sum(v>0 for v in contrasts.values()),negative_backgrounds=sum(v<0 for v in contrasts.values()),contrasts=contrasts,strata=strata,leave_one_background_range=[min(loo),max(loo)],limits='Dependent same-route influence ranges, not confidence intervals. Original whole-population weights remain primary.'))
write_record(p/'support.json',dict(scope=__doc__,rows=rows));print(rows)
