"""Exposed follow-up: source weights x occupancy law on unchanged two rules.
Use identical supported projection, ordinary enemy endpoints, count and any.
Original uniform owners/squares versus frozen ordinary own-slot source weights;
IID default density versus frozen actual occupancy. Equal17background weights.
Uniform-source actual occupancy forces the hypothetical actor at every source,
including otherwise enemy/empty sources; it is not reachable gameplay. No fit.
Reuse exact128-layout seeds from factorial-ordinary; verify old uniform cells.
Cost checkpoint120sec/rule. Do not infer uniquely rule-given population/price.
"""
from pathlib import Path
import sys,json,time,random,hashlib
from fractions import Fraction as F
from collections import defaultdict
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/finite-law-20261009'))]
from finite_law import collect
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'population-split.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());old=json.loads((p/'factorial-ordinary.json').read_bytes())
write_record(p/'population-split-declaration.json',dict(scope=__doc__,inputs={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['declaration.json','factorial-ordinary.json']},producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seeds=[202610091121,202610091122],samples=128))
def mask(v):return sum(1<<i for i in v)
def count(bucket,occ,en):return sum(bool(en&(1<<target)) and any(not occ&cl and (k is None or (occ&cells).bit_count()==k) for cl,cells,k in ev) for target,ev in bucket)
report=dict(scope=__doc__,rules=[],complete=False)
for case,prior in zip(d['rules'],old['rules']):
 start=time.perf_counter();c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));cfg=EvaluationConfig();A=c.board_shape.area;types=case['types'];anchors={t.type_id for t in c.piece_types if t.is_anchor};edges={t:[[(target,[(mask(cl),mask(cells),k) for cl,cells,k in ev]) for target,ev in b.items()] for b in collect(c,c.ir,t,cfg)[0]['target_enemy']] for t in types};s=GameSession(c);bgs=[]
 for ply in range(len(case['route'])+1):
  pos=s.state.position;o=pos.side_to_move;slots=[i for i,x in enumerate(pos.board) if x and x.owner==o and x.current_type_id not in anchors];assert slots
  bgs.append(dict(owner=o,slots=slots,occupied=mask(i for i,x in enumerate(pos.board) if x),enemy=[mask(i for i,x in enumerate(pos.board) if x and x.owner!=owner and x.current_type_id not in anchors) for owner in range(2)]))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 sourceweights={i:F(0) for i in range(2*A)}
 for bg in bgs:
  for src in bg['slots']:sourceweights[bg['owner']*A+src]+=F(1,len(bgs)*len(bg['slots']))
 assert sum(sourceweights.values(),F())==1
 row=dict(seed=case['seed'],replicates=[],actual_occupancy={},complete=False);report['rules'].append(row)
 for seed,control in zip([202610091121,202610091122],prior['replicates']):
  rng=random.Random(seed);curves=[]
  for rho in cfg.density_points:
   sums={t:{k:F() for k in ['uniform_count','uniform_any','actualsource_count','actualsource_any']} for t in types}
   for sample in range(128):
    occ=0;en=[0,0]
    for i in range(A):
     if rng.random()<rho:occ|=1<<i;en[1-rng.randrange(2)]|=1<<i
    for idx in range(2*A):
     owner,src=divmod(idx,A);occup=occ&~(1<<src);enemy=en[owner]&~(1<<src)
     for t in types:
      n=count(edges[t][idx],occup,enemy)
      for k,v in [('count',n),('any',int(bool(n)))]:sums[t]['uniform_'+k]+=F(v,2*A);sums[t]['actualsource_'+k]+=v*sourceweights[idx]
    if time.perf_counter()-start>120:raise RuntimeError('declared per-rule cost checkpoint')
   curves.append(dict(density=rho,values={t:{k:v/128 for k,v in ss.items()} for t,ss in sums.items()}))
  values={t:{k:sum((F(str(w))*r['values'][t][k] for w,r in zip(cfg.density_weights,curves)),F()) for k in sums[t]} for t in types}
  for t in types:
   for k in ['count','any']:assert values[t]['uniform_'+k]==F(control['values'][t][k])
  row['replicates'].append(dict(seed=seed,values=values,contrast={k:values['B'][k]-values['C'][k] for k in values['B']}))
 sums={t:{k:F() for k in ['uniform_count','uniform_any','actualsource_count','actualsource_any']} for t in types}
 for bg in bgs:
  for idx in range(2*A):
   owner,src=divmod(idx,A);occ=bg['occupied']&~(1<<src);en=bg['enemy'][owner]&~(1<<src)
   for t in types:
    n=count(edges[t][idx],occ,en)
    for k,v in [('count',n),('any',int(bool(n)))]:
     sums[t]['uniform_'+k]+=F(v,len(bgs)*2*A)
     if owner==bg['owner'] and src in bg['slots']:sums[t]['actualsource_'+k]+=F(v,len(bgs)*len(bg['slots']))
 for t in types:
  for k in ['count','any']:assert sums[t]['actualsource_'+k]==F(prior['actual_means'][t][k])
 row['actual_occupancy']=sums;row['actual_occupancy_contrast']={k:sums['B'][k]-sums['C'][k] for k in sums['B']};row['complete']=True;row['seconds']=time.perf_counter()-start;write_record(out,report);print(row['seed'],row['seconds'],[r['contrast'] for r in row['replicates']],row['actual_occupancy_contrast'],flush=True)
report['complete']=True;write_record(out,report)
