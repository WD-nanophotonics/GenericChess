"""Exposed full-population support audit; no changed reward or filtered result.
Replay all frozen slots/types and all focal legal actions. Distinguish projected
ordinary endpoints, S0-S2 candidates, legal positive targets and maximal gain.
Record positive multiremoval if any; do not assume any=max. B/C projection is
simple board move+one-target remove; excluded drops cannot have board source.
Cost120sec/rule/100000transitions, no search or expanded cohort.
"""
from pathlib import Path
import json,sys,time,hashlib
from dataclasses import replace
from collections import Counter
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/finite-law-20261009'))]
from finite_law import collect
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.session.session import GameSession
from generic_chess.core.pieces import Piece
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'legality-audit.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());task=json.loads((p/'result.json').read_bytes());proj=json.loads((p/'factorial-ordinary.json').read_bytes());report=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules=[],complete=False)
for case,truth,projected in zip(d['rules'],task['rules'],proj['rules']):
 start=time.perf_counter();c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);eng=semantic_engine_for(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};rows=[];transitions=0;hist=Counter();lookup={(r['ply'],r['source'],r['type']):r['task'] for r in truth['cells']};plook={(r['ply'],r['source'],t):v for r in projected['actual'] for t,v in r['values'].items()}
 def ordinary(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(n for t,n in pos.hands[owner].counts if t not in anchors)
 for ply in range(len(case['route'])+1):
  pos=s.state.position;side=pos.side_to_move;assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  for src,x in enumerate(pos.board):
   if not x or x.owner!=side or x.current_type_id in anchors:continue
   for t in case['types']:
    board=list(pos.board);board[src]=Piece(side,t,t,False);cp=replace(pos,board=tuple(board));legal=[];targets=set();rewards=[]
    for a,b in eng.iter_legal_action_bindings(cp,source=src):
     child=eng._transition(cp,a,b);gain=ordinary(cp,1-side)-ordinary(child,1-side);transitions+=1;hist[gain]+=1;rewards.append(gain)
     if gain>0:targets.add(a.target);legal.append(dict(action=action_to_dict(_semantic_public_action(eng,a)),gain=gain))
    assert max([0]+rewards)==lookup[ply,src,t]
    rr=dict(ply=ply,source=src,type=t,projected=plook[ply,src,t],legal_positive_endpoints=len(targets),legal_max=max([0]+rewards),positive_actions=legal)
    if t in ('B','C'):
     rawtargets=set();rejected=[]
     for pattern in eng._patterns:
      for a,b in eng._iter_candidates(pattern,cp):
       if a.source!=src:continue
       target=cp.board[a.target] if a.target is not None else None
       if not target or target.owner==side or target.current_type_id in anchors:continue
       rawtargets.add(a.target)
       if eng._trial_child_if_s3_legal(pattern,cp,a,b) is None:rejected.append(dict(action=action_to_dict(_semantic_public_action(eng,a)),pattern=pattern.pattern_id))
     rr.update(raw_capture_endpoints=len(rawtargets),s3_rejected=rejected)
     assert len(rawtargets)==rr['projected']['count'],(case['seed'],ply,src,t,len(rawtargets),rr['projected'])
    rows.append(rr)
    if time.perf_counter()-start>120 or transitions>100000:raise RuntimeError('audit checkpoint')
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 assert len(rows)==len(truth['cells']);row=dict(seed=case['seed'],cells=rows,transitions=transitions,gain_histogram={str(k):v for k,v in hist.items()},any_equals_max_all=all(int(r['legal_positive_endpoints']>0)==r['legal_max'] for r in rows),projection_any_diff_cells=sum(r['projected']['any']!=r['legal_max'] for r in rows),BC_projection_any_diff_cells=sum(r['projected']['any']!=r['legal_max'] for r in rows if r['type'] in ('B','C')),complete=True,seconds=time.perf_counter()-start);report['rules'].append(row);print({k:v for k,v in row.items() if k!='cells'},flush=True)
report['complete']=True;write_record(out,report)
