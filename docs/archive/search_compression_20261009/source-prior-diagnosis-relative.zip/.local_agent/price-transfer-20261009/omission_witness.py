"""One existing full-state successor for each semantic mechanism, no new cohort.
Reward counts enemy ordinary board+hand loss only. Show changing current/base,
hand or auxiliary state can score zero. No claim zero utility or new fitting.
Scan existing frozen route positions; retain absent mechanism as absent support.
"""
from pathlib import Path
from collections import Counter
import json,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for,_semantic_public_action
from generic_chess.core.identity import position_identity_key
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'omission-witness.json';assert not out.exists();case=json.loads((p/'declaration.json').read_bytes())['rules'][0];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);eng=semantic_engine_for(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};found={}
def inventory(pos):return dict(board_current={str(k):v for k,v in Counter((x.owner,x.current_type_id) for x in pos.board if x).items()},board_base={str(k):v for k,v in Counter((x.owner,x.base_type_id) for x in pos.board if x).items()},hand=[dict(h.counts) for h in pos.hands],aux=record_value(pos.aux_state))
def ordinary(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(n for t,n in pos.hands[owner].counts if t not in anchors)
for ply in range(len(case['route'])+1):
 pos=s.state.position;owner=pos.side_to_move
 for a,b in eng.iter_legal_action_bindings(pos):
  kind='drop' if a.pattern_id.startswith('sem_00_') else 'quiet_transform' if a.pattern_id.startswith('sem_01_') else None
  if kind is None or kind in found:continue
  action=_semantic_public_action(eng,a);child=apply_action(s.state,action,c);raw=eng._transition(pos,a,b);assert position_identity_key(raw,c)==position_identity_key(child.position,c);gain=ordinary(pos,1-owner)-ordinary(child.position,1-owner)
  found[kind]=dict(ply=ply,action=action_to_dict(action),ordinary_removal_gain=gain,before=inventory(pos),after=inventory(child.position),full_state_changed=s.state!=child,position_identity_changed=position_identity_key(pos,c)!=position_identity_key(child.position,c),future_opponent_legal_actions=len(eng.legal_actions(child.position)) if hasattr(eng,'legal_actions') else len(list(eng.iter_legal_action_bindings(child.position))))
 if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
write_record(out,dict(scope=__doc__,seed=case['seed'],mechanisms=found,absent_mechanisms=[k for k in ['quiet_transform','drop'] if k not in found],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()));print({k:(v['ply'],v['ordinary_removal_gain'],v['full_state_changed']) for k,v in found.items()})
