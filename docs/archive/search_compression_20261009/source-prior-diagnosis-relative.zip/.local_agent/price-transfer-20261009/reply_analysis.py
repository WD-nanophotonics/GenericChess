"""Analyze all completed one-reply cells with pre-existing frozen price tables.
Exact original context-first weights; partial rules are unsupported, not zeros.
"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
import json,sys,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path('.local_agent/price-transfer-20261009');src=p/'reply-task.json';d=json.loads(src.read_bytes());frozen=json.loads((p/'reply-declaration.json').read_bytes())
assert d['declaration_sha256']==hashlib.sha256((p/'reply-declaration.json').read_bytes()).hexdigest()
report=dict(scope=__doc__,input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules=[])
for old in d['rules']:
 row=dict(seed=old['seed'],complete=old['complete'],cells=old['cells'],backgrounds=[],summary={});report['rules'].append(row)
 if not old['complete']:row['failure']=old['failure'];continue
 tables=frozen['prices'][str(old['seed'])];types=old['types'];bg=defaultdict(dict)
 for r in old['cells']:bg[r['ply']].setdefault(r['source'],{})[r['type']]=r
 for ply,slots in sorted(bg.items()):
  assert all(sorted(x)==types for x in slots.values())
  rr=dict(ply=ply,slots=len(slots),tasks={})
  for field in ('immediate','task'):
   us=[{t:v[t][field] for t in types} for v in slots.values()]
   means={t:sum((F(u[t]) for u in us),F())/len(us) for t in types};oracle=sum((F(max(u.values())) for u in us),F())/len(us)
   losses={n:oracle-sum((means[t] for t in types if table[t]==max(table[t] for t in types)),F())/sum(table[t]==max(table[t] for t in types) for t in types) for n,table in tables.items()}
   losses['blind']=oracle-sum(means.values(),F())/len(types)
   rr['tasks'][field]=dict(means=means,losses=losses,all_zero=sum(not any(u.values()) for u in us),oracle=oracle)
  row['backgrounds'].append(rr)
 assert len(bg)==17
 for field in ('immediate','task'):
  rs=[r['tasks'][field] for r in row['backgrounds']]
  losses={n:sum((r['losses'][n] for r in rs),F())/len(rs) for n in (*tables,'blind')}
  row['summary'][field]=dict(means={t:sum((r['means'][t] for r in rs),F())/len(rs) for t in types},losses=losses,minus_blind={n:v-losses['blind'] for n,v in losses.items() if n!='blind'},all_zero_slots=sum(r['all_zero'] for r in rs),positive_cells=sum(r[field]>0 for r in old['cells']))
 # Verify immediate task agrees with the earlier entire common-slot population.
 prior=json.loads((p/'result.json').read_bytes())
 priorcells=next(r['cells'] for r in prior['rules'] if r['seed']==old['seed'])
 lookup={(r['ply'],r['source'],r['type']):r['task'] for r in priorcells}
 assert all(lookup[(r['ply'],r['source'],r['type'])]==r['immediate'] for r in old['cells'])
 print(old['seed'],row['summary'],flush=True)
write_record(p/'reply-analysis.json',report)
