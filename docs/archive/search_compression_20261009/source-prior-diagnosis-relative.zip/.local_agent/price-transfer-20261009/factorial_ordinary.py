"""Exposed diagnosis: crossed population and statistic, fixed two rules.
Uniform owner/source with original independent-density law versus every frozen
actual own ordinary slot, equal slots then backgrounds. Supported projected
enemy endpoints only: distinct endpoint count versus any reachable enemy.
Any equals max ordinary removal ONLY in this simple one-target projection;
actual compound legal rewards remain separately measured. Actual enemy endpoints exclude anchors; uniform anonymous enemy units are ordinary. The earlier factorial.json included actual anchor endpoints and remains a superseded support diagnostic. No fitting/selection.
Two fixed128-layout replicates, same layouts/types/statistics; max120sec/rule.
Actual cells exact, all zeros retained. Random estimates are not exact means.
"""
from pathlib import Path
import sys,json,time,random,hashlib
from fractions import Fraction as F
from collections import defaultdict
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/finite-law-20261009'))]
from finite_law import collect
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'factorial-ordinary.json';assert not out.exists()
decl=json.loads((p/'declaration.json').read_bytes());task=json.loads((p/'result.json').read_bytes())
write_record(p/'factorial-ordinary-declaration.json',dict(scope=__doc__,seeds=[202610091121,202610091122],samples=128,inputs={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['declaration.json','result.json']},producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
result=dict(scope=__doc__,rules=[],complete=False)
def mask(v):return sum(1<<i for i in v)
def count(bucket,occupied,enemy):return sum(bool(enemy&(1<<target)) and any(not occupied&cl and (k is None or (occupied&cells).bit_count()==k) for cl,cells,k in events) for target,events in bucket)
for case,truth in zip(decl['rules'],task['rules']):
 start=time.perf_counter();c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));cfg=EvaluationConfig();A=c.board_shape.area;types=case['types'];edges={};scope={}
 for t in types:
  e,inc,exc=collect(c,c.ir,t,cfg);edges[t]=[[(target,[(mask(cl),mask(cells),k) for cl,cells,k in events]) for target,events in bucket.items()] for bucket in e['target_enemy']];scope[t]=dict(included=inc,excluded=exc,exact_curve=semantic_opportunity(c,t,cfg)['curves'])
 row=dict(seed=case['seed'],scope=scope,original_prices=case['tables'],replicates=[],actual=[],complete=False);result['rules'].append(row)
 for seed in [202610091121,202610091122]:
  rng=random.Random(seed);curves=[]
  for rho in cfg.density_points:
   sums={t:[0,0] for t in types}
   for sample in range(128):
    occ=0;en=[0,0]
    for i in range(A):
     if rng.random()<rho:occ|=1<<i;en[1-rng.randrange(2)]|=1<<i
    for idx in range(2*A):
     owner,src=divmod(idx,A);occupied=occ&~(1<<src);enemy=en[owner]&~(1<<src)
     for t in types:
      n=count(edges[t][idx],occupied,enemy);sums[t][0]+=n;sums[t][1]+=bool(n)
    if time.perf_counter()-start>120:raise RuntimeError('declared per-rule checkpoint')
   curves.append(dict(density=rho,values={t:dict(count=F(v[0],128*2*A),any=F(v[1],128*2*A)) for t,v in sums.items()}))
  row['replicates'].append(dict(seed=seed,curves=curves,values={t:{k:sum((F(str(w))*r['values'][t][k] for w,r in zip(cfg.density_weights,curves)),F()) for k in ['count','any']} for t in types}))
 s=GameSession(c);lookup={(r['ply'],r['source'],r['type']):r['task'] for r in truth['cells']};anchors={t.type_id for t in c.piece_types if t.is_anchor}
 for ply in range(len(case['route'])+1):
  pos=s.state.position;owner=pos.side_to_move;occ=mask(i for i,x in enumerate(pos.board) if x);enemy=mask(i for i,x in enumerate(pos.board) if x and x.owner!=owner and x.current_type_id not in anchors)
  for src,x in enumerate(pos.board):
   if x is None or x.owner!=owner or x.current_type_id in anchors:continue
   vals={}
   for t in types:
    n=count(edges[t][owner*A+src],occ&~(1<<src),enemy);vals[t]=dict(count=n,any=int(bool(n)),legal_max=lookup[ply,src,t])
   row['actual'].append(dict(ply=ply,source=src,values=vals))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 bg=defaultdict(list)
 for r in row['actual']:bg[r['ply']].append(r)
 row['actual_means']={t:{k:sum((sum((F(r['values'][t][k]) for r in rs),F())/len(rs) for rs in bg.values()),F())/len(bg) for k in ['count','any','legal_max']} for t in types}
 row['contrasts_B_minus_C']=dict(uniform=[{k:r['values']['B'][k]-r['values']['C'][k] for k in ['count','any']} for r in row['replicates']],actual={k:row['actual_means']['B'][k]-row['actual_means']['C'][k] for k in ['count','any','legal_max']})
 row['complete']=True;row['seconds']=time.perf_counter()-start;write_record(out,result);print(row['seed'],row['seconds'],row['contrasts_B_minus_C'],flush=True)
result['complete']=True;write_record(out,result)
