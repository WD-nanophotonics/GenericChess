"""Finite Bernoulli path formulas check sampled count attribution, not any.
Default density unchanged. Uniform, initial ordinary source-template, and
whole frozen-route own-slot weights. Initial source is an explicit candidate
prior, not uniquely rule-determined future occupancy. No prices/refit/default.
Analytical floats are numeric controls, not a new exact certificate.
"""
from pathlib import Path
import json,sys,time,hashlib
from fractions import Fraction as F
from collections import defaultdict
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/finite-law-20261009'))]
from finite_law import collect
from generic_chess.ai.evaluation.semantic import _path_union
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'count-control.json';assert not out.exists();cases=json.loads((p/'declaration.json').read_bytes())['rules'];prior=json.loads((p/'population-split.json').read_bytes());rows=[];start=time.perf_counter()
for case,old in zip(cases,prior['rules']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);cfg=EvaluationConfig();A=c.board_shape.area;types=case['types'];anchors={t.type_id for t in c.piece_types if t.is_anchor};weights=defaultdict(float);initial=[]
 for ply in range(len(case['route'])+1):
  pos=s.state.position;slots=[i for i,x in enumerate(pos.board) if x and x.owner==pos.side_to_move and x.current_type_id not in anchors]
  for i in slots:weights[pos.side_to_move*A+i]+=1/((len(case['route'])+1)*len(slots))
  if ply==0:initial=[x.owner*A+i for i,x in enumerate(pos.board) if x and x.current_type_id not in anchors]
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 assert abs(sum(weights.values())-1)<1e-12;values={}
 for t in types:
  edges=collect(c,c.ir,t,cfg)[0];vals={}
  for name,ww in [('uniform',{i:1/(2*A) for i in range(2*A)}),('initial',{i:1/len(initial) for i in initial}),('actualsource',weights)]:
   curves=[]
   for rho,w in zip(cfg.density_points,cfg.density_weights):
    capture=sum(weight*_path_union(ev,rho)*rho/2 for i,weight in ww.items() for ev in edges['target_enemy'][i].values());quiet=sum(weight*_path_union(ev,rho)*(1-rho) for i,weight in ww.items() for ev in edges['target_empty'][i].values());curves.append(dict(density=rho,quiet=quiet,capture=capture,total=quiet+capture,weight=w))
   vals[name]={k:sum(r['weight']*r[k] for r in curves) for k in ['quiet','capture','total']};vals[name]['curves']=curves
  values[t]=vals
 contrast={name:{k:values['B'][name][k]-values['C'][name][k] for k in ['quiet','capture','total']} for name in ['uniform','initial','actualsource']}
 errors=[{name:{t:float(F(rep['values'][t][name+'_count']))-values[t][name]['capture'] for t in types} for name in ['uniform','actualsource']} for rep in old['replicates']]
 row=dict(seed=case['seed'],values=values,contrast_B_minus_C=contrast,sampled_count_errors=errors,initial_owner_source_indices=initial,actual_source_weights={str(k):v for k,v in weights.items()});rows.append(row);print(case['seed'],contrast,flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
