"""Fresh fixed-model search diagnostic on six new trajectories of the same rule.
Freeze routes before scores; no refit/tuning, no unknown-rule or strength claim.
Root UnitD3/20knodes/3sec target; selected child UnitD2/2048nodes/1sec.
Two balanced unit/sparse-model calls per root, identical D3/20knodes/1sec.
Caps remain unknown. Whole run upper checkpoint90sec; no result-driven extension.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,random,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'compression-fresh.json';declaration=p/'compression-fresh-declaration.json'
assert not out.exists() and not declaration.exists()
rule=json.loads((p/'prospective-target-declaration.json').read_bytes())['rules']
c=compile_ruleset_for_execution(ruleset_from_dict(rule));types=non_anchor_type_ids(c);enc=SparsePositionEncoder(c)
m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
w=np.asarray(m.hidden_weights)/np.asarray(m.input_scale)[None,:];offset=np.asarray(m.hidden_bias)-w@np.asarray(m.input_mean);ow=np.asarray(m.output_weights)
class Eval:
    def __init__(self,learned=False):self.learned=learned
    def evaluate(self,state):
        v=1000*sum(material_features(state.position,types,perspective=0).array())
        if self.learned:
            ix,values=enc.encode(state.position)
            v+=float((np.tanh(w[:,ix]@values+offset)@ow+m.output_bias)*m.target_scale)
        return v if state.position.side_to_move==0 else -v
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
def search(s,learned,depth,nodes,seconds):
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
    assert not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
    assert time.perf_counter()-start<90
    player=AlphaBetaPlayer(c,evaluator_override=Eval(learned),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
    before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick
    validate_pv(s,d);assert s.state==before
    return d,elapsed
sessions=[];routes=[]
for seed in range(2026100910,2026100916):
    s=GameSession(c);rng=random.Random(seed);route=[]
    for ply in range(8):
        if s.state.terminal_status.is_terminal:break
        acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True))
        if not acts:break
        a=rng.choice(acts);route.append(action_to_dict(a));s.submit(a)
    sessions.append(s);routes.append(dict(seed=seed,route=route,state=record_value(s.state),missing=len(route)!=8 or s.state.terminal_status.is_terminal))
write_record(declaration,dict(scope=__doc__,model_sha256=hashlib.sha256((p/'compression-model.json').read_bytes()).hexdigest(),rules=rule,roots=routes))
start=time.perf_counter();report=dict(scope=__doc__,declaration_sha256=hashlib.sha256(declaration.read_bytes()).hexdigest(),roots=[],complete=False)
for root,s in zip(routes,sessions):
    row=dict(seed=root['seed'],calls=[]);report['roots'].append(row)
    if root['missing']:row['missing']=True;continue
    target,seconds=search(s,False,3,20000,3)
    row['target']=dict(known=target.completed_depth==3,seconds=seconds,decision=record_value(target))
    refs={}
    for rep in range(2):
        for name in (('unit','learned')if rep==0 else ('learned','unit')):
            d,seconds=search(s,name=='learned',3,20000,1)
            key=json.dumps(action_to_dict(d.action),sort_keys=True)
            if key not in refs:
                child=apply_action(s.state,d.action,c)
                if child.terminal_status.is_terminal:ref=dict(known=True,score=terminal_score(child.terminal_status,s.state.position.side_to_move,1))
                else:
                    cs=GameSession(c);cs._state=child;cs._search_history_witnesses=s._search_history_witnesses+(child.position,)
                    rd,rseconds=search(cs,False,2,2048,1)
                    ref=dict(known=rd.completed_depth==2,score=-rd.score,seconds=rseconds,decision=record_value(rd))
                refs[key]=ref
            ref=refs[key];known=row['target']['known']and ref['known']
            row['calls'].append(dict(evaluator=name,rep=rep,seconds=seconds,decision=record_value(d),reference=ref,teacher_regret=target.score-ref['score']if known else None))
    write_record(out,report);print(root['seed'],[(r['evaluator'],r['teacher_regret'])for r in row['calls']],flush=True)
report['complete']=True;report['seconds']=time.perf_counter()-start
report['summary']={name:dict(known=sum(r['teacher_regret']is not None for row in report['roots']for r in row['calls']if r['evaluator']==name),regrets=[r['teacher_regret']for row in report['roots']for r in row['calls']if r['evaluator']==name])for name in ('unit','learned')}
write_record(out,report);print(json.dumps(report['summary']))
