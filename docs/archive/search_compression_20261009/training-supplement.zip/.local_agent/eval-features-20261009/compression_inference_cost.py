"""Per-row fixed-model implementations, same228inputs, no search or fitting."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from scripts.research_record import write_record
p=Path(__file__).parent;m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
x=np.load(p/'compression-inputs.npz',allow_pickle=False)['features'];reference=m.predict(x)
w=np.asarray(m.hidden_weights)/np.asarray(m.input_scale)[None,:];offset=np.asarray(m.hidden_bias)-w@np.asarray(m.input_mean);ow=np.asarray(m.output_weights)
def cached(row):return float((np.tanh(w@row+offset)@ow+m.output_bias)*m.target_scale)
def sparse(row):
    ix=np.flatnonzero(row);return float((np.tanh(w[:,ix]@row[ix]+offset)@ow+m.output_bias)*m.target_scale)
methods=dict(original=lambda row:float(m.predict(row[None,:])[0]),cached_dense=cached,cached_sparse=sparse)
rows=[]
for rep in range(3):
    for name in (list(methods)if rep!=1 else list(reversed(methods))):
        tick=time.perf_counter();pred=np.array([methods[name](row)for row in x]);seconds=time.perf_counter()-tick
        assert np.allclose(pred,reference,rtol=0,atol=1e-9)
        rows.append(dict(rep=rep,method=name,seconds=seconds,max_error=float(np.max(np.abs(pred-reference))),calls=len(x)))
write_record(p/'compression-inference-cost.json',dict(scope=__doc__,rows=rows,limits='Stored dense rows; excludes real Position encoding/legal/search cost. Mathematically equivalent within1e-9, not bit-identical.'))
print(json.dumps(rows,indent=2))
