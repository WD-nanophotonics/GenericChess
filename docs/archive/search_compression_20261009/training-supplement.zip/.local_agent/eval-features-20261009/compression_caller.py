"""Scoped fixed learned-leaf caller versus unit under identical one-second limits.
Post-fit deployment diagnostic, not the original finite teacher or playing gain.
No fitting/selection/default changes. Full search state; Position-only learned leaf.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'compression-caller-sparse.json';assert not out.exists()
decl=json.loads((p/'prospective-target-declaration.json').read_bytes());labels=json.loads((p/'prospective-target-d2-completed.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));types=non_anchor_type_ids(c);enc=SparsePositionEncoder(c)
m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
w=np.asarray(m.hidden_weights)/np.asarray(m.input_scale)[None,:]
offset=np.asarray(m.hidden_bias)-w@np.asarray(m.input_mean)
ow=np.asarray(m.output_weights)
def sparse_predict(position):
    indices,values=enc.encode(position)
    return float((np.tanh(w[:,indices]@values+offset)@ow+m.output_bias)*m.target_scale)
inputs=np.load(p/'compression-inputs.npz',allow_pickle=False)['features']
dense_reference=m.predict(inputs)
cached_prediction=(np.tanh(inputs@w.T+offset)@ow+m.output_bias)*m.target_scale
assert np.allclose(cached_prediction,dense_reference,rtol=0,atol=1e-9)
class Eval:
    def __init__(self,learned):self.learned=learned;self.calls=0;self.seconds=0
    def evaluate(self,state):
        tick=time.perf_counter();v=1000*sum(material_features(state.position,types,perspective=0).array())
        if self.learned:v+=sparse_predict(state.position)
        self.calls+=1;self.seconds+=time.perf_counter()-tick
        return v if state.position.side_to_move==0 else -v
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
report=dict(scope=__doc__,implementation='Preconvert the fixed model once; sparse weighted active channels. All228stored input predictions agree with dense within1e-9; no fitted parameter changes.',conditions='D3/20000nodes/1sec/q0/Core; no TT/order/disk/native/root tactics; two balanced repeats; no full-D3 claim.',calls=[],complete=False)
for root,row in zip(decl['roots'],labels['roots']):
    s=GameSession(c)
    for a in root['route']:s.submit(action_from_dict(a))
    teachers={json.dumps(x['action'],sort_keys=True):y['targets']['2']['root_score']for x,y in zip(root['children'],row['children'])};maximum=max(teachers.values())
    for rep in range(2):
        for name in (('unit','learned')if rep==0 else ('learned','unit')):
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            assert not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
            e=Eval(name=='learned');player=AlphaBetaPlayer(c,evaluator_override=e,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
            before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));wall=time.perf_counter()-tick
            validate_pv(s,d);assert s.state==before
            key=json.dumps(action_to_dict(d.action),sort_keys=True);assert key in teachers
            report['calls'].append(dict(seed=root['seed'],group=root['group'],rep=rep,evaluator=name,seconds=wall,leaf_calls=e.calls,leaf_seconds=e.seconds,teacher_regret=maximum-teachers[key],decision=record_value(d)))
    write_record(out,report)
    print(root['seed'],[(r['evaluator'],r['decision']['completed_depth'],r['teacher_regret'])for r in report['calls'][-4:]],flush=True)
report['complete']=True
report['summary']={name:dict(calls=12,mean_teacher_regret=float(np.mean([r['teacher_regret']for r in report['calls']if r['evaluator']==name])),leaf_seconds=sum(r['leaf_seconds']for r in report['calls']if r['evaluator']==name),leaf_calls=sum(r['leaf_calls']for r in report['calls']if r['evaluator']==name),depths=[r['decision']['completed_depth']for r in report['calls']if r['evaluator']==name])for name in ('unit','learned')}
write_record(out,report);print(json.dumps(report['summary'],indent=2))
