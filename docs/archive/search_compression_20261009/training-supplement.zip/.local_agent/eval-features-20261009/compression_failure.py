"""Post-fit diagnostic intervention, not model selection or new validation."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from scripts.research_record import write_record
p=Path(__file__).parent
d=np.load(p/'compression-inputs.npz',allow_pickle=False)
x,y,b,g,roots=[d[k]for k in ('features','targets','baseline','groups','roots')]
m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
mean=x[g=='train'].mean(axis=0);constant=np.ptp(x[g=='train'],axis=0)==0
masked=x.copy();masked[:,constant]=mean[constant]
tick=time.perf_counter();original=m.predict(x);control=m.predict(masked);elapsed=time.perf_counter()-tick
rows=[]
for seed in dict.fromkeys(roots):
    ix=roots==seed;t=y[ix]+b[ix]
    scores=original[ix]+b[ix];masked_scores=control[ix]+b[ix]
    chosen=np.flatnonzero(scores==scores.max());c=np.flatnonzero(masked_scores==masked_scores.max())
    rows.append(dict(seed=int(seed),group=str(g[ix][0]),novel_cells=int(np.count_nonzero(x[ix][:,constant]!=mean[constant])),
        original_regret=float(np.mean(t.max()-t[chosen])),intervention_regret=float(np.mean(t.max()-t[c])),
        original_mse=float(np.mean((original[ix]-y[ix])**2)),intervention_mse=float(np.mean((control[ix]-y[ix])**2)),
        original_choice=chosen.tolist(),intervention_choice=c.tolist(),max_prediction_change=float(np.max(np.abs(original[ix]-control[ix])))))
w=np.asarray(m.hidden_weights)
support=dict(constant_channels=int(constant.sum()),variable_channels=int((~constant).sum()),
    max_abs_constant_hidden_weight=float(np.max(np.abs(w[:,constant]))),
    max_abs_variable_hidden_weight=float(np.max(np.abs(w[:,~constant]))),
    explanation='Training-constant normalized inputs are zero. Their fit gradient is regularization only; this fixed fit suppresses their weights. Novel-channel counts alone do not identify the root failure mechanism.')
for row in rows:
    ix=roots==row['seed'];chosen=row['original_choice']
    row['chosen_teacher_residual']=y[ix][chosen].tolist()
    row['chosen_predicted_residual']=original[ix][chosen].tolist()
    row['predicted_residual_range']=[float(original[ix].min()),float(original[ix].max())]
    row['teacher_residual_range']=[float(y[ix].min()),float(y[ix].max())]
write_record(p/'compression-failure.json',dict(scope=__doc__,intervention='Reset all training-constant input channels to training mean; no refit. Deliberately removes state information; diagnostic only, never adopted as deployment.',seconds=elapsed,support=support,rows=rows))
print(json.dumps(rows,indent=2))
