"""Cost pilot: existing root TT bounds label only certified preferences.
Eight preselected old roots (first trajectory each rule,7/16), no training.
Same UnitD3/8192node/5sec/q0 Core, TT/order. Compare to frozen full childD2
values only after normalization of mate distance. Unknown ties/depths retained.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.transposition import score_from_tt
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.evaluation.config import MATE_THRESHOLD
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'bound-teacher.json';assert not out.exists();old=Path('.local_agent/sharing-20261009');plan=json.loads((old/'rule-declaration.json').read_bytes());screen=json.loads((old/'rule-screen.json').read_bytes());indices=[0,1,6,7,12,13,18,19];write_record(p/'bound-teacher-declaration.json',dict(scope=__doc__,root_indices=indices,node_budget=8192,seconds=5,exact_entry_depth=2,reference='Already exposed frozen childD2, normalization adjusts mate distance by one root ply.',cost='Eight calls plus child identity probes, expected<1minute, no fit or new labels used in training.'));rows=[]
for i in indices:
 root=plan['roots'][i];ref=screen['roots'][i];c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));types=non_anchor_type_ids(c);s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 class Unit:
  def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
  def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=True,use_ordering=True,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);runtime=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses);cells=[];tick=time.perf_counter();ss=1 if root['side']==0 else-1
 for j,raw in enumerate(root['children']):
  a=action_from_dict(raw);cell=dict(index=j,classification='UNKNOWN');child=apply_action(s.state,a,c)
  with runtime.pushed(a):entry=player._tt.probe(runtime.search_key())if runtime.tt_eligible else None
  if child.terminal_status.is_terminal:
   lower=upper=terminal_score(child.terminal_status,root['side'],1);cell.update(source='terminal',lower=lower,upper=upper)
  elif entry is not None:
   value=-score_from_tt(entry.score,1);cell.update(source='TT',entry_depth=entry.depth,entry_bound=entry.bound.name,root_value=value)
   if entry.depth==2:
    if entry.bound.name=='EXACT':cell.update(lower=value,upper=value)
    elif entry.bound.name=='LOWER':cell['upper']=value
    elif entry.bound.name=='UPPER':cell['lower']=value
  if d.completed_depth==3:
   if cell.get('upper',float('inf'))<d.score:cell['classification']='CERTIFIED_INFERIOR'
   elif cell.get('lower',-float('inf'))==d.score:cell['classification']='CERTIFIED_OPTIMAL'
  r=ref['children'][j]
  if r['known']:
   target=ss*r['owner0_target'];target=target-1 if target>=MATE_THRESHOLD else target+1 if target<=-MATE_THRESHOLD else target;cell['reference_root_score']=target
   if 'lower'in cell:assert cell['lower']<=target
   if 'upper'in cell:assert cell['upper']>=target
   if cell['classification']=='CERTIFIED_INFERIOR':assert target<d.score
   if cell['classification']=='CERTIFIED_OPTIMAL':assert target==d.score
  cells.append(cell)
 runtime.assert_balanced();probe_seconds=time.perf_counter()-tick;rows.append(dict(root=f"{root['seed']}/{root['ply']}",rule_index=root['rule_index'],root_search_seconds=elapsed,probe_seconds=probe_seconds,decision=record_value(d),cells=cells));write_record(out,dict(scope=__doc__,complete=False,rows=rows));print(rows[-1]['root'],d.completed_depth,{v:sum(x['classification']==v for x in cells)for v in('CERTIFIED_OPTIMAL','CERTIFIED_INFERIOR','UNKNOWN')},flush=True)
write_record(out,dict(scope=__doc__,complete=True,rows=rows,limits='Eight exposed roots, pilot only. Root incomplete=>all preferences unknown; depth other than2 not qualified. Bound direction and mate-distance independently checked against retained finite references. No all-cooptimal claim, no replayed labels fitted, no WDL/default/interface change. Research uses private TT under full runtime identity; not an exported stable product API.'))
