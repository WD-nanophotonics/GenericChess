"""Count actual internal semantic transition calls behind unlike512work labels.
Two fixed2164/2165opening4parents, Unit, AB D2max512/q0, frontier512 and
the existing-handle512 variant.
Each has uninstrumented then counted cold control, preserving action/work;
class wrapper lives only in this subprocess. No faster-path deployment or
equal-cost claim. Counter overhead qualifies instrumented timing. Expected<3min.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/root-order-transfer-20261010'))]
from frontier import choose
from frontier_handles import choose as choose_handles
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'cost-probe.json';assert not out.exists();d=json.loads((p/'prospective-rules.json').read_bytes());rows=[];start=time.perf_counter()
write_record(p/'cost-probe-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),seeds=[202610082164,202610082165],cells=12))
for case in d['rules'][:2]:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 cls=type(semantic_engine_for(c));original=cls._transition
 for method in('ab','frontier','handles'):
  control=None
  for instrumented in(False,True):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];count=[0]
   def counted(self,*args,**kwargs):count[0]+=1;return original(self,*args,**kwargs)
   if instrumented:cls._transition=counted
   tick=time.perf_counter();before=s.state
   try:
    if method!='ab':action,stats=(choose if method=='frontier'else choose_handles)(before,c,UnitEvaluator(),512);work=stats['transitions'];sig=(action,work,stats['root_outcome'],stats['root_children'])
    else:
     dec=AlphaBetaPlayer(c,evaluator_override=UnitEvaluator(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));action=dec.action;stats=record_value(dec);work=dec.nodes;sig=(action,dec.nodes,dec.qnodes,dec.completed_depth);assert dec.termination_reason!='time_limit'
   finally:cls._transition=original
   elapsed=time.perf_counter()-tick;assert s.state==before
   if control is None:control=sig
   else:assert sig==control
   rows.append(dict(seed=case['seed'],method=method,instrumented=instrumented,public_action=action_to_dict(action),budget_label=512,reported_work=work,internal_semantic_transition_calls=count[0]if instrumented else None,seconds=elapsed,stats=stats))
   print(case['seed'],method,instrumented,work,count[0],round(elapsed,3),flush=True)
write_record(out,dict(scope=__doc__,source=Path(__file__).read_text(),rows=rows,complete=True,seconds=time.perf_counter()-start))
