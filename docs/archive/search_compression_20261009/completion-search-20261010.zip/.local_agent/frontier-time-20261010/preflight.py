"""Finite certificate preflight for research frontier backup: partial frontier
cannot prove a loss; genuine win child suffices; all resolved draw/loss children
resolve the correct outcome for either mover. Not a generated-game theorem.
"""
from pathlib import Path
import sys,json
from types import SimpleNamespace as S
sys.path[:0]=[str(Path.cwd()),str(Path(__file__).parent)]
import frontier_time as f
from scripts.research_record import write_record
def state(side,out=None,value=0):return S(position=S(side_to_move=side),terminal_status=S(is_terminal=out is not None,winner=None if out==0 or out is None else 0 if out==1 else 1),value=value)
rows=[]
class Eval:
 def evaluate(self,s):return s.value if s.position.side_to_move==0 else -s.value
for name,side,outs,limit,expected in [('partial_loss',0,[-1,None],1,None),('existential_win',0,[1,None],1,1),('existential_black_win',1,[-1,None],1,-1),('all_loss',0,[-1,-1],2,-1),('draw_over_loss',0,[-1,0],2,0),('black_draw_over_loss',1,[1,0],2,0)]:
 root=state(side);children=[state(1-side,x)for x in outs];f.legal_actions=lambda s,c:list(range(len(children)))if s is root else [0];f.apply_action=lambda s,a,c:children[a];f.action_to_dict=lambda a:dict(edge=a)
 action,stats=f.choose(root,S(declarations=()),Eval(),limit,10);assert stats['root_outcome']==expected,(name,stats);rows.append(dict(case=name,action=action,stats=stats,expected=expected))
write_record(Path(__file__).parent/'preflight.json',dict(scope=__doc__,source=Path(__file__).read_text(),rows=rows,passed=True))
print('six finite backup controls pass')
