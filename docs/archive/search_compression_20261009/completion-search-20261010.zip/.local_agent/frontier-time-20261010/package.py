"""Archive completed Agent-generated completion-search sources/all results.
Exclude transport/account/user inputs. Verify hashes and full histories/winning
reply replay from archive. This is recovery, not independent scientific validation.
"""
from pathlib import Path
import json,hashlib,zipfile,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
p=Path(__file__).resolve().parent.relative_to(Path.cwd().resolve());archive=Path('docs/archive/search_compression_20261009/completion-search-20261010.zip');index=archive.with_name(archive.stem+'-index.json');assert not archive.exists()
for name in('games','repeat','reply-audit','reencoding','handles','cost-probe'):assert json.loads((p/(name+'.json')).read_bytes())['complete'],name
files=sorted([*p.glob('*.py'),*p.glob('*.json')],key=lambda x:x.as_posix());members=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in files:
  data=f.read_bytes();path=f.as_posix();assert '/slack/'not in path;z.writestr(path,data);members.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(members)
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
 base=p.as_posix()+'/';audits=json.loads(z.read(base+'reply-audit.json'));cases={r['seed']:r for r in json.loads(z.read(base+'prospective-rules.json'))['rules']};replayed=0;witnesses=0
 for name in('games','repeat'):
  for game in json.loads(z.read(base+name+'.json'))['rows']:
   case=cases[game['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
   for a in case['route'][:4]:s.submit(action_from_dict(a))
   assert record_value(s.state)==game['initial']
   for step in game['steps']:
    s.submit(action_from_dict(step['action']));raw=record_value(s.state);assert raw==step['state'];key=hashlib.sha256(json.dumps(raw,sort_keys=True,separators=(',',':')).encode()).hexdigest();saved=audits['audits'][key];assert saved['state']==raw and saved['complete'];replayed+=1
    for w in saved['witnesses']:
     nxt=apply_action(s.state,action_from_dict(w['action']),c);assert record_value(nxt.terminal_status)==w['terminal']and nxt.terminal_status.winner==1-step['side'];witnesses+=1
prereq=Path('docs/archive/search_compression_20261009/root-order-transfer-20261010.zip');assert prereq.exists()
write_record(index,dict(scope=__doc__,base_commit='f95674cee40e1554c7d438e928475c71869925a1',archive=archive.as_posix(),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,uncompressed_bytes=sum(m['bytes']for m in members),members=members,prerequisites=[dict(path=prereq.as_posix(),sha256=hashlib.sha256(prereq.read_bytes()).hexdigest(),index='docs/archive/search_compression_20261009/root-order-transfer-20261010-index.json')],verification=dict(member_hashes=len(members),game_states=replayed,winning_reply_occurrences=witnesses),qualifications=['initial wall-clock batch overlaps two short Agent diagnostics; fixed repeat has no concurrent Agent experiment but OS/timing variability remains','repeat has exposed rules and dependent trajectories, not new independent validation','visited AB nodes and public frontier successors are unlike counters; actual internal transition calls counted separately','frontier V1/V2/V3 are research-only, no product/default/training; declarations/restarts excluded','original encodings and timings preserved; semantic bool/history and handle checks are finite scoped controls']))
analysis=json.loads((p/'analysis.json').read_bytes());relation=json.loads((p/'reencoding.json').read_bytes());handles=json.loads((p/'handles.json').read_bytes());audit=json.loads((p/'reply-audit.json').read_bytes());cost=json.loads((p/'cost-probe.json').read_bytes())
write_record(Path('docs/research/data/completion_search_20261010.json'),dict(scope='Scoped search-route comparison, not strength/default or shared-model validation',archive_index=index.as_posix(),analysis=analysis,reply_audit=dict(rows=len(audit['rows']),unique_full_states=len(audit['audits']),cache_hits=audit['cache_hits'],actual_reply_transitions=audit['transitions'],seconds=audit['seconds'],positive_rows=[r for r in audit['rows']if r['immediate_loss_witnesses']]),reencoding=dict(signature_check=json.loads((p/'reencoding-analysis.json').read_bytes()),roots=len(relation['rows']),calls=sum(len(r['arms'])for r in relation['rows']),full_state_transition_pairs=relation['public_transitions']//2,history_record_pairs=relation['history_record_pairs'],seconds=relation['seconds']),handles=dict(calls=len(handles['rows']),full_child_pairs=handles['full_child_pairs'],exact_signature_matches=sum(r['exact_signature_match']for r in handles['rows']),old_search_seconds=sum(r['old_seconds']for r in handles['rows']),new_search_seconds=sum(r['stats']['seconds']for r in handles['rows']),rows=handles['rows']),cost_probe=cost,verification=dict(replayed_full_states=replayed,winning_reply_occurrences=witnesses)))
print(len(members),archive.stat().st_size,replayed,witnesses)
