"""New completion-interface semantic check, not a rerun of old Position-only
input assay: replay complete routes on2164-2167 at opening0/4/8 under inverse
bool guard/initial/reset/set coding, then match full-history states and every
one-step successor. Compare cold AB D2max512/q0/no root scan and fixed512
successor frontier, Unit/v3, under both equivalent encodings:96calls.
Question: does the new frontier preserve this supported encoding relation,
including terminal/repetition/history facts, or leak raw numeric aux coding?
Only no-trigger global bool expire_next_turn with equality guards and set_bool
is claimed. No general equivalence theorem, fit/default or equal-count cost.
Expected<8min;900sec cost checkpoint. After timed repeat, no concurrent search.
"""
from pathlib import Path
import sys,json,copy,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/root-order-transfer-20261010'))]
from frontier import choose
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'reencoding.json';assert not out.exists();d=json.loads((p/'prospective-rules.json').read_bytes());assert json.loads((p/'repeat.json').read_bytes())['complete']
write_record(p/'reencoding-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),rules_sha256=hashlib.sha256((p/'prospective-rules.json').read_bytes()).hexdigest(),openings=[0,4,8],calls=96))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[];start=time.perf_counter();transitions=0;history_pairs=0
def equivalent(a,b,mapping,inverse):
 global history_pairs
 old=record_value(a.position);new=record_value(b.position);old.pop('ruleset_fingerprint');new.pop('ruleset_fingerprint');new['aux_state']=[(key,1-value)for key,value in new['aux_state']];old['aux_state']=[(key,value)for key,value in old['aux_state']];assert old==new
 assert a.ply_count==b.ply_count and a.terminal_status==b.terminal_status and len(a.history)==len(b.history)
 for h,k in zip(a.history,b.history):
  assert(h.actor,h.action_signature,h.gave_check)==(k.actor,k.action_signature,k.gave_check)
  assert mapping.setdefault(h.position_key,k.position_key)==k.position_key and inverse.setdefault(k.position_key,h.position_key)==h.position_key;history_pairs+=1
 assert sorted((mapping[k],v)for k,v in a.repetition_counts)==sorted(b.repetition_counts)
for case in d['rules']:
 rr=copy.deepcopy(case['rules']);c=compile_ruleset_for_execution(ruleset_from_dict(rr));eng=semantic_engine_for(c);assert not eng.ir.triggers
 assert all(s.value_kind=='bool'and s.scope=='global'and s.lifetime=='expire_next_turn'for s in eng.ir.aux_slots)
 for action in rr['semantic_actions']:
  for guard in action.get('slot_guards',[]):assert guard.get('comparison','eq')=='eq';guard['value']=1-guard['value']
  for slot in action.get('aux_state',[]):slot['initial']=1-slot['initial']
  for effect in action['effects']:
   assert effect['kind']not in('clear_right','clear_token')
   if effect['kind']=='set_bool':effect['value']=1-effect['value']
 cc=compile_ruleset_for_execution(ruleset_from_dict(rr));profiles=[build_semantic_opportunity_profile(x,cfg)[0]for x in(c,cc)];assert dict(profiles[0].board_value_by_type)==dict(profiles[1].board_value_by_type)and dict(profiles[0].hand_value_by_base_type)==dict(profiles[1].hand_value_by_base_type)
 for opening in(0,4,8):
  sessions=[GameSession(x)for x in(c,cc)]
  for s in sessions:
   for a in case['route'][:opening]:s.submit(action_from_dict(a))
  mapping={};inverse={};equivalent(sessions[0].state,sessions[1].state,mapping,inverse);acts=[sorted(legal_actions(s.state,x),key=str)for s,x in zip(sessions,(c,cc))];assert[ action_to_dict(a)for a in acts[0]]==[action_to_dict(a)for a in acts[1]]
  for a,b in zip(*acts):equivalent(apply_action(sessions[0].state,a,c),apply_action(sessions[1].state,b,cc),mapping,inverse);transitions+=2
  row=dict(seed=case['seed'],opening=opening,root_actions=len(acts[0]),equivalent_full_history=True,history_key_bijection_size=len(mapping),arms=[]);rows.append(row)
  for kind in('unit','v3'):
   for method in('ab','frontier'):
    for encoding,(compiled,profile,s)in enumerate(zip((c,cc),profiles,sessions)):
     assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<900
     class Leaf(UnitEvaluator):
      def __init__(self):self.ev=Evaluator(compiled,profile,cfg)
      def evaluate(self,state):return super().evaluate(state)if kind=='unit'else self.ev.evaluate(state)
     before=s.state;leaf=Leaf();tick=time.perf_counter()
     if method=='frontier':a,stats=choose(before,compiled,leaf,512)
     else:
      dec=AlphaBetaPlayer(compiled,evaluator_override=leaf,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,dec);a=dec.action;stats=record_value(dec)
     assert s.state==before and a in acts[encoding];row['arms'].append(dict(leaf=kind,method=method,encoding=encoding,action=action_to_dict(a),stats=stats,seconds=time.perf_counter()-tick))
  write_record(out,dict(scope=__doc__,rows=rows,complete=False,public_transitions=transitions,history_record_pairs=history_pairs,seconds=time.perf_counter()-start))
  print(case['seed'],opening,len(acts[0]),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,public_transitions=transitions,history_record_pairs=history_pairs,seconds=time.perf_counter()-start))
