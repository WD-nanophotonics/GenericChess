"""Describe every fixed algorithm/leaf/owner cell and same-condition repeat.
Costs and changes are descriptive; duplicate paths are not independent samples,
ongoing64 differs from true draw, and technical aborts are not ongoing64.
"""
from pathlib import Path
import json,collections,statistics,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;datasets={name:json.loads((p/(name+'.json')).read_bytes())for name in('games','repeat')};assert all(d['complete']and len(d['rows'])==16 for d in datasets.values())
def summarize(d):
 outcomes=collections.Counter();events=collections.Counter();methods={};cells=[]
 for r in d['rows']:
  t=r['terminal'];events[t['status']]+=1
  if r['abort']is not None:label='technical_unknown'
  elif t['status']=='ongoing':assert len(r['steps'])==64;label='ongoing64'
  elif t['status']=='no_contest':label='restart_unsupported'
  elif t['winner']is None:label='rule_draw'
  else:label=r['methods'][t['winner']]+'_win'
  outcomes[label]+=1;cells.append(dict(seed=r['seed'],leaf=r['leaf'],methods=r['methods'],plies=len(r['steps']),terminal=t,label=label,seconds=r['seconds']))
 for method in('ab','frontier'):
  ss=[s for r in d['rows']for s in r['steps']if s['method']==method];methods[method]=dict(calls=len(ss),call_seconds=sum(s['seconds']for s in ss),median_seconds=statistics.median(s['seconds']for s in ss),max_seconds=max(s['seconds']for s in ss),above1p05=sum(s['seconds']>1.05 for s in ss),work_units='visited alpha-beta nodes'if method=='ab'else'materialized Core successors',work=sum(s['stats']['nodes']if method=='ab'else s['stats']['transitions']for s in ss),completed_depth_counts=dict(collections.Counter(s['stats']['completed_depth']for s in ss))if method=='ab'else None,root_resolution_counts=dict(collections.Counter(str(s['stats'].get('root_outcome',s['stats'].get('outcome')))for s in ss))if method=='frontier'else None)
 signatures=collections.Counter(json.dumps([s['action']for s in r['steps']],sort_keys=True)for r in d['rows'])
 return dict(seconds=d['seconds'],plies=sum(len(r['steps'])for r in d['rows']),outcomes=dict(outcomes),events=dict(events),methods=methods,cells=cells,distinct_action_trajectories=len(signatures),duplicate_multiplicities=sorted(signatures.values()))
mapping=lambda d:{(r['seed'],r['leaf'],tuple(r['methods'])):r for r in d['rows']};a=mapping(datasets['games']);b=mapping(datasets['repeat']);pairs=[]
for key,x in a.items():
 y=b[key];assert x['initial']==y['initial'];first=next((i for i,(old,new)in enumerate(zip(x['steps'],y['steps']))if old['action']!=new['action']),None)
 pairs.append(dict(seed=key[0],leaf=key[1],methods=key[2],first_action_divergence=first,plies=[len(x['steps']),len(y['steps'])],terminal_changed=x['terminal']!=y['terminal'],terminals=[x['terminal'],y['terminal']],ab_nodes=[sum(s['stats']['nodes']for s in r['steps']if s['method']=='ab')for r in(x,y)],frontier_successors=[sum(s['stats']['transitions']for s in r['steps']if s['method']=='frontier')for r in(x,y)]))
write_record(p/'analysis.json',dict(scope=__doc__,source=Path(__file__).read_text(),batches={n:summarize(d)for n,d in datasets.items()},pairs=pairs,qualified_initial_cpu_overlap=True,no_fit_or_default=True,no_independent_repeat=True))
print([(n,d['seconds'],sum(len(r['steps'])for r in d['rows']))for n,d in datasets.items()]);print('changed',sum(r['first_action_divergence']is not None for r in pairs),'terminal_changed',sum(r['terminal_changed']for r in pairs))
