from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'reencoding.json').read_bytes());assert d['complete'];pairs=[]
fields=('nodes','qnodes','score','principal_variation','completed_depth','selective_depth','termination_reason','evaluation_calls','legal_actions_generated','successors_materialized','tt_probes','tt_hits','beta_cutoffs')
for row in d['rows']:
 for kind in('unit','v3'):
  for method in('ab','frontier'):
   old=next(r for r in row['arms']if r['leaf']==kind and r['method']==method and r['encoding']==0);new=next(r for r in row['arms']if r['leaf']==kind and r['method']==method and r['encoding']==1)
   keys=fields if method=='ab'else tuple(k for k in old['stats']if k!='seconds');same=old['action']==new['action']and all(old['stats'][k]==new['stats'][k]for k in keys)
   pairs.append(dict(seed=row['seed'],opening=row['opening'],leaf=kind,method=method,choice_work_value_match=same,comparison_fields=keys))
write_record(p/'reencoding-analysis.json',dict(source=Path(__file__).read_text(),pairs=pairs,matches=sum(r['choice_work_value_match']for r in pairs),full_history_root_checks=len(d['rows']),public_transition_pairs=d['public_transitions']//2,history_record_pairs=d['history_record_pairs']))
print(len(pairs),sum(r['choice_work_value_match']for r in pairs),d['public_transitions']//2)
