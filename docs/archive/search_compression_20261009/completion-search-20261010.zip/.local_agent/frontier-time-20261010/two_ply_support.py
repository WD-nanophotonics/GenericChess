"""Qualify the repeated2166two-ply trajectory using one full root/reply check,
not independent algorithm victories. Whether already locally forced changes
interpretation of the pilot's outcome support. No new search/fit/budget.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'two-ply-support.json';assert not out.exists();case=next(r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']if r['seed']==202610082166);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for a in case['route'][:4]:s.submit(action_from_dict(a))
rows=[];count=0;start=time.perf_counter()
for a in legal_actions(s.state,c):
 child=apply_action(s.state,a,c);count+=1;w=[];replies=0
 if not child.terminal_status.is_terminal:
  for reply in legal_actions(child,c):
   nxt=apply_action(child,reply,c);count+=1;replies+=1
   if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-s.state.position.side_to_move:w.append(action_to_dict(reply))
 rows.append(dict(action=action_to_dict(a),terminal=record_value(child.terminal_status),replies=replies,witnesses=w))
write_record(out,dict(scope=__doc__,source=Path(__file__).read_text(),parent=record_value(s.state),rows=rows,root_actions=len(rows),all_root_next_reply_losses=all(r['witnesses']for r in rows),transitions=count,seconds=time.perf_counter()-start))
print(len(rows),sum(bool(r['witnesses'])for r in rows),count)
