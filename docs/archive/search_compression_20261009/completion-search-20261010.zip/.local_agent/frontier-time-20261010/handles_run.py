"""24 fixed512 calls using existing Core successor handles, all12original
2164-2167 opening0/4/8 roots x Unit/v3. Compare EXACT choice, completion,
children values and work with the already declared original-encoding assay;
do not rerun the baseline or extend its budget. Before search, every root
handle materialization matches public apply_action full history/terminal/state.
Question: is repeated public validation a concrete cost issue removable through
the supported API without changing this frontier's decisions or semantics?
Research-only, no product speed/default/strength claim. Expected<5min,600sec
checkpoint; execute after timed-repeat and reencoding batches finish.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path(__file__).parent)]
from frontier_handles import choose
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.lazy_transitions import legal_successor_handles,materialize_legal_successor
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'handles.json';assert not out.exists();d=json.loads((p/'prospective-rules.json').read_bytes());baseline=json.loads((p/'reencoding.json').read_bytes());assert baseline['complete'];cases={r['seed']:r for r in d['rules']};cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
write_record(p/'handles-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),frontier_source=Path(p/'frontier_handles.py').read_text(),cases=[(r['seed'],r['opening'])for r in baseline['rows']],calls=24))
rows=[];start=time.perf_counter();child_pairs=0
for root in baseline['rows']:
 case=cases[root['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:root['opening']]:s.submit(action_from_dict(a))
 profile,_=build_semantic_opportunity_profile(c,cfg)
 for h in legal_successor_handles(s.state,c):assert materialize_legal_successor(s.state,h,c)[0]==apply_action(s.state,h.action,c);child_pairs+=1
 for kind in('unit','v3'):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<600
  class Leaf(UnitEvaluator):
   def __init__(self):self.ev=Evaluator(c,profile,cfg)
   def evaluate(self,state):return super().evaluate(state)if kind=='unit'else self.ev.evaluate(state)
  a,stats=choose(s.state,c,Leaf(),512);old=next(r for r in root['arms']if r['leaf']==kind and r['method']=='frontier'and r['encoding']==0);same=action_to_dict(a)==old['action']and{ k:v for k,v in stats.items()if k!='seconds'}=={k:v for k,v in old['stats'].items()if k!='seconds'}
  rows.append(dict(seed=case['seed'],opening=root['opening'],leaf=kind,action=action_to_dict(a),stats=stats,old_seconds=old['seconds'],exact_signature_match=same));write_record(out,dict(scope=__doc__,rows=rows,complete=False,full_child_pairs=child_pairs,seconds=time.perf_counter()-start));print(case['seed'],root['opening'],kind,same,round(old['seconds'],3),round(stats['seconds'],3),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,full_child_pairs=child_pairs,seconds=time.perf_counter()-start))
