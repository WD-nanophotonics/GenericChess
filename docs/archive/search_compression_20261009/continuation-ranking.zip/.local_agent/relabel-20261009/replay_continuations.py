"""Replay actual terminal diagnostic; no rerun/extension of frozen games.
All stored moves must be legal, final full state/terminal must match.
At the losing side's last move, compare fixed Unit/old model, D2/20knodes/5sec/q0.
Enumerate exactly the observed winning reply after each chosen action; that is
one concrete threat check, not exhaustive defense coverage or a strength claim.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
p=Path('.local_agent/eval-features-20261009');dest=Path(__file__).parent
plan=json.loads((p/'compression-fresh-declaration.json').read_bytes());r=json.loads((dest/'paired-continuations.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules']));enc=SparsePositionEncoder(c);types=non_anchor_type_ids(c);m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
rows=[];before_last=None;observed_reply=None
for g in r['games']:
    s=GameSession(c);root=next(x for x in plan['roots']if x['seed']==g['seed'])
    for a in root['route']:s.submit(action_from_dict(a))
    assert record_value(s.state)==g['initial']
    for i,move in enumerate(g['moves']):
        assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
        if g['observed_terminal']and i==len(g['moves'])-2:before_last=s.state;witnesses=s._search_history_witnesses;observed_reply=g['moves'][-1]['action'];observed_choice=move['action']
        a=action_from_dict(move['action']);assert a in s.legal_actions();s.submit(a);assert record_value(s.state.terminal_status)==move['terminal']
    assert record_value(s.state)==g['final'];rows.append(dict(seed=g['seed'],owner=g['learned_owner'],legal_moves=len(g['moves']),terminal=record_value(s.state.terminal_status),censored=g['censored']))
assert before_last is not None
class Eval:
    def __init__(self,learned):self.learned=learned
    def evaluate(self,state):
        v=1000*sum(material_features(state.position,types,perspective=0).array())
        if self.learned:v+=float(m.predict(enc.dense(state.position)[None,:])[0])
        return v if state.position.side_to_move==0 else-v
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
cells=[]
for name in('unit','learned'):
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
    s=GameSession(c);s._state=before_last;s._search_history_witnesses=witnesses
    player=AlphaBetaPlayer(c,evaluator_override=Eval(name=='learned'),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);s.submit(d.action)
    threat=action_from_dict(observed_reply);legal=threat in s.legal_actions();terminal=None
    if legal:s.submit(threat);terminal=record_value(s.state.terminal_status)
    cells.append(dict(method=name,decision=record_value(d),seconds=elapsed,observed_reply_legal=legal,terminal_after_observed_reply=terminal,changed_from_actual_unit_choice=action_to_dict(d.action)!=observed_choice))
write_record(dest/'continuation-replay.json',dict(scope=__doc__,games=rows,observed_root=record_value(before_last),observed_choice=observed_choice,observed_reply=observed_reply,cells=cells))
print('legal replay moves',sum(x['legal_moves']for x in rows),'diagnostic',[(x['method'],x['decision']['completed_depth'],x['observed_reply_legal'],x['terminal_after_observed_reply'])for x in cells])
