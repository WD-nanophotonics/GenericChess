"""Predeclared twelve paired same-rule continuations; outcomes, not teacher labels.
Six fresh roots0910..15, each learned-owner0 and learned-owner1, max48new plies.
Both existing Core searches D3/20knodes/1sec/q0/no TT/order/native/root tactics.
Complete original rule/state/history preserved, fixed model, no refit or Elo claim.
Truncated games remain censored, never draws; no result-driven extension.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path('.local_agent/eval-features-20261009');dest=Path(__file__).parent
decl=json.loads((p/'compression-fresh-declaration.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));types=non_anchor_type_ids(c);enc=SparsePositionEncoder(c)
m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
declaration=dest/'continuation-declaration.json';out=dest/'paired-continuations.json'
assert not declaration.exists()and not out.exists()
write_record(declaration,dict(scope=__doc__,model_sha256=hashlib.sha256((p/'compression-model.json').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((p/'compression-fresh-declaration.json').read_bytes()).hexdigest(),games=[dict(seed=r['seed'],route=r['route'],learned_owner=o)for r in decl['roots']for o in (0,1)],run_checkpoint_seconds=900,recording='every8plies and every game; no model selection from outcomes'))
class Eval:
    def __init__(self,learned):self.learned=learned;self.calls=0;self.seconds=0
    def evaluate(self,state):
        tick=time.perf_counter();v=1000*sum(material_features(state.position,types,perspective=0).array())
        if self.learned:v+=float(m.predict(enc.dense(state.position)[None,:])[0])
        self.calls+=1;self.seconds+=time.perf_counter()-tick
        return v if state.position.side_to_move==0 else -v
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
report=dict(scope=__doc__,declaration_sha256=hashlib.sha256(declaration.read_bytes()).hexdigest(),games=[],complete=False)
start=time.perf_counter()
for root in decl['roots']:
    for owner in ((0,1)if root['seed']%2==0 else(1,0)):
        s=GameSession(c)
        for a in root['route']:s.submit(action_from_dict(a))
        row=dict(seed=root['seed'],learned_owner=owner,initial=record_value(s.state),moves=[]);report['games'].append(row)
        for ply in range(48):
            if s.state.terminal_status.is_terminal:break
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            assert not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
            assert time.perf_counter()-start<900
            actor=s.state.position.side_to_move;e=Eval(actor==owner)
            player=AlphaBetaPlayer(c,evaluator_override=e,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
            before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick
            validate_pv(s,d);assert s.state==before
            assert d.action in s.legal_actions()
            s.submit(d.action)
            row['moves'].append(dict(actor=actor,policy='learned'if actor==owner else'unit',action=action_to_dict(d.action),depth=d.completed_depth,score=d.score,reason=d.reason,seconds=elapsed,leaf_calls=e.calls,leaf_seconds=e.seconds,terminal=record_value(s.state.terminal_status),owner0_unit=1000*sum(material_features(s.state.position,types,perspective=0).array())))
            if(ply+1)%8==0:write_record(out,report)
        row['final']=record_value(s.state);row['observed_terminal']=s.state.terminal_status.is_terminal
        row['censored']=not row['observed_terminal'];row['learned_result']=None if row['censored']else('draw'if s.state.terminal_status.winner is None else'win'if s.state.terminal_status.winner==owner else'loss')
        write_record(out,report);print(root['seed'],owner,len(row['moves']),row['learned_result'],flush=True)
report.update(complete=True,seconds=time.perf_counter()-start)
write_record(out,report)
