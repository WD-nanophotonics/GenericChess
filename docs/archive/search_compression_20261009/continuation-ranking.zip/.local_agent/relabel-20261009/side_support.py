"""Declared side-to-move counterfactual on four boards, fresh empty-history contexts.
Not played positions/holdout/WDL; isolates the current single-side training scope.
Four preselected children (0902/0,0902/2,0903/5,0904/1), both side flags; UnitD2
2048nodes/1sec/q0 Core targets and unchanged owner0 predictor, no fitting.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,hashlib
from dataclasses import replace
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.position import GameState
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import TerminalResult,TerminalStatus,terminal_result
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path('.local_agent/eval-features-20261009');dest=Path(__file__).parent
decl=json.loads((p/'prospective-target-declaration.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));enc=SparsePositionEncoder(c);types=non_anchor_type_ids(c)
m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
selection=[(2026100902,0),(2026100902,2),(2026100903,5),(2026100904,1)]
plan=dict(scope=__doc__,selection=selection,model_sha256=hashlib.sha256((p/'compression-model.json').read_bytes()).hexdigest(),history='Ply0, one repetition occurrence, no preceding history; full saved Position/aux from declared child. Counterfactual, not played trace.')
assert not (dest/'side-support.json').exists();write_record(dest/'side-declaration.json',plan)
class Unit:
    def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
rows=[]
for seed,index in selection:
    root=next(r for r in decl['roots']if r['seed']==seed);s=GameSession(c)
    for a in root['route']:s.submit(action_from_dict(a))
    child=apply_action(s.state,action_from_dict(root['children'][index]['action']),c);row=dict(seed=seed,index=index,cells=[])
    for side in (0,1):
        pos=replace(child.position,side_to_move=side);key=position_identity_key(pos,c)
        state=GameState(pos,0,((key,1),),TerminalResult(TerminalStatus.ONGOING),())
        state=replace(state,terminal_status=terminal_result(state,c));x=enc.dense(pos)
        cell=dict(side=side,state=record_value(state),model_owner0=float(m.predict(x[None,:])[0])+1000*sum(material_features(pos,types,perspective=0).array()))
        if state.terminal_status.is_terminal:cell['terminal_excluded']=True
        else:
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            cs=GameSession(c);cs._state=state;cs._search_history_witnesses=(pos,)
            player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
            tick=time.perf_counter();d=player.choose_action(cs,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(cs,d)
            cell.update(known=d.completed_depth==2,owner0_teacher=d.score if side==0 else-d.score,seconds=elapsed,decision=record_value(d))
        row['cells'].append(cell)
    row['model_difference']=row['cells'][1]['model_owner0']-row['cells'][0]['model_owner0']
    row['teacher_difference']=row['cells'][1]['owner0_teacher']-row['cells'][0]['owner0_teacher']if all(cell.get('known')for cell in row['cells'])else None
    rows.append(row)
write_record(dest/'side-support.json',dict(scope=__doc__,rows=rows,cache_array_bytes=sum(a.nbytes for a in m._prediction_arrays),limits='Fixed single-side training; this is a scope diagnostic, not a retuning target or exact-calibration gate. Unknown teacher differences retained.'))
print([(r['seed'],r['index'],r['model_difference'],r['teacher_difference'])for r in rows])
