"""Recover completed ranking summary from immutable checkpoints; NO FITS."""
from pathlib import Path
import os
for k in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'ranking-result.json';assert not out.exists();selection=json.loads((p/'ranking-selection.json').read_bytes());failure=json.loads((p/'ranking-serialization-failure.json').read_bytes());times={x['method']:x['seconds']for x in failure['fits']}
with np.load(p/'ranking-selected-inputs.npz',allow_pickle=False)as data:inputs={name:data[key].copy()for name,key in(('position','position'),('position_pairs','position_pairs'))};y=data['targets'].copy();r=data['roots'].copy();g=data['groups'].copy();sign=data['signs'].copy();ci=data['children'].copy();b=data['baseline'].copy()
train=g=='train';train_roots=list(dict.fromkeys(r[train]));models=[]
for name,xx in inputs.items():
 checkpoint=p/f'ranking-model-{name}.json';m=json.loads(checkpoint.read_bytes());col=np.asarray(m['columns']);mean=np.asarray(m['mean']);scale=np.asarray(m['scale']);w=np.asarray(m['weights']);z=(xx[:,col]-mean)/scale;pred=z@w
 assert np.array_equal(mean,xx[train][:,col].mean(axis=0))and np.array_equal(scale,xx[train][:,col].std(axis=0))
 diffs=[];pw=[];counts={}
 for key in train_roots:
  idx=np.flatnonzero((r==key)&train);ss=sign[idx[0]];t=ss*y[idx];best=np.flatnonzero(t==t.max());other=np.flatnonzero(t<t.max());count=len(best)*len(other);counts[str(key)]=count
  for a in best:
   for bb in other:diffs.append(ss*(z[idx[a]]-z[idx[bb]]));pw.append(1/(len(train_roots)*count))
 d=np.asarray(diffs);pw=np.asarray(pw)
 def obj(ww):return float(np.sum(pw*np.maximum(1-d@ww,0))+.5*.0001*np.sum(ww*ww))
 rows=[]
 for key in dict.fromkeys(r):
  mask=r==key;ss=sign[mask][0];v=ss*pred[mask];t=ss*y[mask];unit=ss*b[mask];chosen=np.flatnonzero(v==v.max());greedy=np.flatnonzero(unit==unit.max())
  rows.append(dict(root=str(key),group=str(g[mask][0]),children=int(mask.sum()),chosen_indices=ci[mask][chosen].tolist(),teacher_regret=float(np.mean(t.max()-t[chosen])),unit_greedy_regret=float(np.mean(t.max()-t[greedy])),teacher_best_fraction=float(np.mean(t[chosen]==t.max()))))
 models.append(dict(method=name,fit_seconds=times[name],dimension=xx.shape[1],train_variable_columns=len(col),train_roots=len(train_roots),train_children=int(train.sum()),pair_counts=counts,initial_objective=obj(np.random.default_rng(2026100949).normal(0,.001,len(col))),final_objective=obj(w),rows=rows,model_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest()))
write_record(out,dict(scope=__doc__,status='TWO_FIXED_FITS_COMPLETE_NOT_DEPLOYED',models=models,oracle_checks=4,gradient_check=True,summary_recovered_without_refitting=True,limits='Conditional material/teacher-disagreement screen. No resampling/refit/report selection, numeric leaf deployment, natural-distribution or universal benefit claim; original failed producer preserved.'))
print([(m['method'],m['train_children'],m['train_variable_columns'],m['final_objective'],[(r['root'],r['teacher_regret'])for r in m['rows']])for m in models])
