"""Public CompactNonlinearResidual cache versus preserved legacy arithmetic."""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import json,time,sys,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from scripts.research_record import write_record
p=Path('.local_agent/eval-features-20261009');dest=Path(__file__).parent
payload=json.loads((p/'compression-model.json').read_bytes())['model']
tick=time.perf_counter();m=CompactNonlinearResidual.from_dict(payload);construction=time.perf_counter()-tick
data=np.load(p/'compression-inputs.npz',allow_pickle=False);x=data['features'].copy();data.close()
def legacy(features):
    normalized=(features-np.asarray(m.input_mean))/np.asarray(m.input_scale)
    hidden=np.tanh(normalized@np.asarray(m.hidden_weights).T+np.asarray(m.hidden_bias))
    return (hidden@np.asarray(m.output_weights)+m.output_bias)*m.target_scale
tick=time.perf_counter();warm=m.predict(x);first=time.perf_counter()-tick
assert np.array_equal(warm,legacy(x)) and m.to_dict()==payload
rows=[]
for rep in range(5):
    for name in (('legacy','cached')if rep%2==0 else ('cached','legacy')):
        tick=time.perf_counter();pred=np.array([(legacy if name=='legacy'else m.predict)(row[None,:])[0]for row in x]);elapsed=time.perf_counter()-tick
        reference=np.array([legacy(row[None,:])[0]for row in x])
        assert np.array_equal(pred,reference)
        rows.append(dict(rep=rep,method=name,calls=len(x),seconds=elapsed))
write_record(dest/'cache-cost.json',dict(scope=__doc__,model_sha256=hashlib.sha256((p/'compression-model.json').read_bytes()).hexdigest(),construction_seconds=construction,first_batch_seconds=first,bit_identical_batch=True,bit_identical_individual=True,serialization_unchanged=True,rows=rows,
    medians={name:float(np.median([row['seconds']for row in rows if row['method']==name]))for name in ('legacy','cached')},limits='Stored vectors, one-thread env requested; not actual Position/search cost or Native parse cost. No changed fitted weights.'))
print('verified identical, median seconds', {name:float(np.median([row['seconds']for row in rows if row['method']==name]))for name in ('legacy','cached')})
