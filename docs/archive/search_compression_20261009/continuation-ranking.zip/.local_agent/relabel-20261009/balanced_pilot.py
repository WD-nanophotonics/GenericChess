"""Fresh side-balanced finite-teacher development pilot, two fixed ablations.
Eight new legal random trajectories0920..27, alternating7/8plies;4train/2dev/2report.
All legal successors declared before teacher scores; UnitD2/2048nodes/1sec/q0.
Full state/history used by teacher; sparse Position inputs omit history explicitly.
Fixed width16/600epochs/seed0932/.0001/.01. Same train rows, side-aware versus
side-blind input only; no sweep/tuning from dev/report. Same exposed rule only.
Whole target collection checkpoint600sec; unknown labels never become zero/draw.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,random,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.learning.nonlinear import fit_compact_residual,CompactNonlinearResidual
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path('.local_agent/eval-features-20261009');dest=Path(__file__).parent
rule=json.loads((p/'prospective-target-declaration.json').read_bytes())['rules'];c=compile_ruleset_for_execution(ruleset_from_dict(rule));types=non_anchor_type_ids(c);enc=SparsePositionEncoder(c)
planpath=dest/'balanced-pilot-declaration.json';out=dest/'balanced-pilot-targets.json';assert not planpath.exists()and not out.exists()
roots=[];sessions=[]
for i,seed in enumerate(range(2026100920,2026100928)):
    s=GameSession(c);rng=random.Random(seed);route=[];length=7+i%2
    for ply in range(length):
        if s.state.terminal_status.is_terminal:break
        acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True))
        if not acts:break
        a=rng.choice(acts);route.append(action_to_dict(a));s.submit(a)
    acts=[]if s.state.terminal_status.is_terminal else sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True))
    roots.append(dict(seed=seed,group='train'if i<4 else'dev'if i<6 else'report',route=route,state=record_value(s.state),side=s.state.position.side_to_move,missing=len(route)!=length or s.state.terminal_status.is_terminal,children=[action_to_dict(a)for a in acts]));sessions.append(s)
plan=dict(scope=__doc__,rules=rule,roots=roots,width=16,epochs=600,regularization=.0001,learning_rate=.01,fit_seed=2026100932,decision='Does side information improve finite-value compression after adding genuine reachable support for both sides?',estimated_cost='All declared child calls <=1sec,600sec checkpoint; two sub-second/small fixed fits; no>1hour run',cheaper_alternative='Four artificial side pairs already isolate unsupported current model, but cannot test fresh learned generalization.',limits='History missing from input; same exposed rule, not WDL/true utility/unknown-rule transfer. Exact ties uniformly weighted. No report-based selection.')
write_record(planpath,plan)
class Unit:
    def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
start=time.perf_counter();report=dict(scope=__doc__,declaration_sha256=hashlib.sha256(planpath.read_bytes()).hexdigest(),roots=[],complete=False);features=[];y=[];base=[];groups=[];ids=[];indices=[];sides=[]
for root,s in zip(roots,sessions):
    row=dict(seed=root['seed'],group=root['group'],root_side=root['side'],children=[]);report['roots'].append(row)
    for j,action in enumerate(root['children']):
        assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
        child=apply_action(s.state,action_from_dict(action),c);material=1000*sum(material_features(child.position,types,perspective=0).array());cell=dict(index=j,action=action,known=False,baseline=material,side=child.position.side_to_move)
        if time.perf_counter()-start>=600:cell['reason']='whole_run_cost_checkpoint'
        elif child.terminal_status.is_terminal:cell.update(known=True,owner0_target=terminal_score(child.terminal_status,0,0),terminal=True,seconds=0)
        else:
            cs=GameSession(c);cs._state=child;cs._search_history_witnesses=s._search_history_witnesses+(child.position,)
            player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(cs,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(cs,d)
            cell.update(known=d.completed_depth==2,owner0_target=d.score if child.position.side_to_move==0 else-d.score,seconds=elapsed,decision=record_value(d))
        row['children'].append(cell)
        if cell['known']:
            features.append(enc.dense(child.position));y.append(cell['owner0_target']-material);base.append(material);groups.append(root['group']);ids.append(root['seed']);indices.append(j);sides.append(child.position.side_to_move)
    write_record(out,report);print(root['seed'],root['side'],sum(x['known']for x in row['children']),len(row['children']),flush=True)
report.update(complete=True,seconds=time.perf_counter()-start);write_record(out,report)
x=np.asarray(features);y=np.asarray(y);g=np.asarray(groups);r=np.asarray(ids);b=np.asarray(base);sid=np.asarray(sides);train=g=='train'
np.savez_compressed(dest/'balanced-pilot-inputs.npz',features=x,targets=y,groups=g,roots=r,baseline=b,child_indices=np.asarray(indices),sides=sid)
assert set(sid[train])=={0,1}
results=[]
for name in ('aware','blind'):
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
    xx=x.copy()
    if name=='blind':xx[:,enc.side_offset:enc.side_offset+2]=x[train,enc.side_offset:enc.side_offset+2].mean(axis=0)
    tick=time.perf_counter();m=fit_compact_residual(xx[train],y[train],width=16,regularization=.0001,seed=2026100932,epochs=600,learning_rate=.01);elapsed=time.perf_counter()-tick
    write_record(dest/f'balanced-model-{name}.json',dict(model=m.to_dict(),declaration_sha256=report['declaration_sha256'],scope='Same exposed rule, Position input omits history. '+name))
    pred=m.predict(xx)+b;teacher=y+b;rr=[]
    for root,row in zip(roots,report['roots']):
        mask=r==root['seed'];v=pred[mask];t=teacher[mask];bb=b[mask];sign=1 if root['side']==0 else-1
        known=len(v)==len(root['children'])and len(v)>0
        choices=np.flatnonzero(sign*v==np.max(sign*v))if len(v)else[];greedy=np.flatnonzero(sign*bb==np.max(sign*bb))if len(v)else[]
        rr.append(dict(seed=root['seed'],group=root['group'],root_side=root['side'],known=known,declared=len(root['children']),complete=int(mask.sum()),chosen_indices=np.asarray(indices)[mask][choices].tolist(),teacher_regret=float(np.mean(np.max(sign*t)-sign*t[choices]))if known else None,unit_greedy_regret=float(np.mean(np.max(sign*t)-sign*t[greedy]))if known else None,residual_mse=float(np.mean((pred[mask]-teacher[mask])**2))if len(v)else None))
    results.append(dict(method=name,fit_seconds=elapsed,train_rows=int(train.sum()),train_side_counts={str(side):int(np.sum(sid[train]==side))for side in(0,1)},rows=rr))
write_record(dest/'balanced-pilot-result.json',dict(scope=__doc__,models=results,decision='Keep both fixed results; no selected deployment/default or retuning. Opposite outcomes determine whether side support deserves next actual-caller test.'))
print([(row['method'],row['fit_seconds'],[(x['seed'],x['teacher_regret'])for x in row['rows']])for row in results])

