"""Two frozen linear ranking fits on teacher-selected conditional roots.
Position versus Position+existing relative-pair counts; no search deployment.
All root teacher-optimal/nonoptimal pairs, margin1 hinge, equal total root weight.
Train-only normalization/variable columns.300Adam steps,.01lr,.0001L2,seed0949.
Neither dev/report labels nor old report groups train or select hyperparameters.
"""
from pathlib import Path
import os
for k in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent;plan=json.loads((p/'ranking-declaration.json').read_bytes());selection=json.loads((p/'ranking-selection.json').read_bytes());assert not(p/'ranking-result.json').exists() and not(p/'ranking-model-position.json').exists() and not(p/'ranking-model-position_pairs.json').exists()
assert selection['screen_sha256']==hashlib.sha256((p/'ranking-screen.json').read_bytes()).hexdigest()
selected={(r['seed'],r['ply'])for r in selection['roots']if r['selected']};train_roots=[r for r in selection['roots']if r['selected']and r['group']=='train']
if not train_roots:
 write_record(p/'ranking-result.json',dict(scope=__doc__,status='NO_SELECTED_TRAIN_ROOT_NO_FIT',selected_roots=len(selected),limits='No resampling or zero-label substitute; retain screen denominator.'));raise SystemExit(0)
c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules']));enc=SparsePositionEncoder(c);ids=enc.type_index;nt=2*len(enc.types);width=c.board_shape.width;height=c.board_shape.height;dxn=2*width-1;dyn=2*height-1;pair_dimension=nt*nt*dxn*dyn
features=[];pairs=[];roots=[];groups=[];signs=[];child_indices=[];targets=[];base=[];pair_oracle_checks=0
screen=json.loads((p/'ranking-screen.json').read_bytes())
for root in plan['roots']:
 if(root['seed'],root['ply'])not in selected:continue
 s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 ref=next(r for r in screen['roots']if(r['seed'],r['ply'])==(root['seed'],root['ply']));assert all(x['known']for x in ref['children'])
 for j,a in enumerate(root['children']):
  child=apply_action(s.state,action_from_dict(a),c);pos=child.position;actors=np.asarray([(sq%width,sq//width,v.owner*len(enc.types)+ids[v.current_type_id])for sq,v in enumerate(pos.board)if v],dtype=np.intp)
  dx=actors[None,:,0]-actors[:,None,0]+width-1;dy=actors[None,:,1]-actors[:,None,1]+height-1;ix=(((actors[:,None,2]*nt+actors[None,:,2])*dxn+dx)*dyn+dy);ix,counts=np.unique(ix[~np.eye(len(actors),dtype=bool)],return_counts=True)
  pp=np.zeros(pair_dimension);pp[ix]=counts
  if pair_oracle_checks<4:
   oracle={}
   for ia,(xa,ya,ta)in enumerate(actors):
    for ib,(xb,yb,tb)in enumerate(actors):
     if ia==ib:continue
     key=int(((ta*nt+tb)*dxn+xb-xa+width-1)*dyn+yb-ya+height-1);oracle[key]=oracle.get(key,0)+1
   assert oracle==dict(zip(ix.tolist(),counts.tolist()));pair_oracle_checks+=1
  features.append(enc.dense(pos));pairs.append(pp);roots.append(f"{root['seed']}/{root['ply']}");groups.append(root['group']);signs.append(1 if root['side']==0 else-1);child_indices.append(j);targets.append(ref['children'][j]['owner0_target']);base.append(ref['children'][j]['baseline'])
x=np.asarray(features);xp=np.concatenate((x,np.asarray(pairs)),axis=1);y=np.asarray(targets);b=np.asarray(base);r=np.asarray(roots);g=np.asarray(groups);sign=np.asarray(signs);ci=np.asarray(child_indices);train=g=='train'
np.savez_compressed(p/'ranking-selected-inputs.npz',position=x,position_pairs=xp,targets=y,roots=r,groups=g,signs=sign,children=ci,baseline=b)
write_record(p/'ranking-fit-declaration.json',dict(scope=__doc__,screen_sha256=selection['screen_sha256'],selection_sha256=hashlib.sha256((p/'ranking-selection.json').read_bytes()).hexdigest(),input_sha256=hashlib.sha256((p/'ranking-selected-inputs.npz').read_bytes()).hexdigest(),initialization='fixed normal(.0,.001),seed0949; no candidate prediction before selection',fit_checkpoint_seconds=120,meaning='Pure root-rank output; never a numeric search leaf or calibrated utility.',inputs='Position preserves all its stated fields; pair features appended, not replacing base/hand/promoted/aux/side fields. History still omitted.'))
def objective(d,w,pw,reg=.0001):
 margin=1-d@w;active=margin>0
 loss=float(np.sum(pw*np.maximum(margin,0))+.5*reg*np.sum(w*w))
 grad=-(pw*active)@d+reg*w
 return loss,grad
# Small finite-difference check of the actual hinge gradient away from boundaries.
toy=np.array([[1.,2.,-1.],[-2.,.3,1.],[.2,-1.,2.]]);tw=np.array([.1,.2,-.1]);pw=np.array([.2,.3,.5]);loss,grad=objective(toy,tw,pw)
for j in range(3):
 delta=np.zeros(3);delta[j]=1e-6
 numeric=(objective(toy,tw+delta,pw)[0]-objective(toy,tw-delta,pw)[0])/2e-6;assert abs(numeric-grad[j])<1e-7
models=[]
for name,xx in(('position',x),('position_pairs',xp)):
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
 columns=np.flatnonzero(np.ptp(xx[train],axis=0)>0);mean=xx[train][:,columns].mean(axis=0);scale=xx[train][:,columns].std(axis=0);z=(xx[:,columns]-mean)/scale
 diffs=[];weights=[];pair_count_by_root={}
 for key in dict.fromkeys(r[train]):
  idx=np.flatnonzero((r==key)&train);ss=sign[idx[0]];t=ss*y[idx];best=np.flatnonzero(t==t.max());other=np.flatnonzero(t<t.max());count=len(best)*len(other);assert count>0
  for a in best:
   for bb in other:diffs.append(ss*(z[idx[a]]-z[idx[bb]]));weights.append(1/(len(train_roots)*count))
  pair_count_by_root[key]=count
 d=np.asarray(diffs);pw=np.asarray(weights);assert abs(pw.sum()-1)<1e-12
 w=np.random.default_rng(2026100949).normal(0,.001,len(columns));m=np.zeros_like(w);v=np.zeros_like(w);initial,_=objective(d,w,pw);tick=time.perf_counter()
 for step in range(1,301):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  assert time.perf_counter()-tick<120,'fit checkpoint, retain incomplete state/no automatic retry'
  value,grad=objective(d,w,pw);m=.9*m+.1*grad;v=.999*v+.001*grad*grad;w-=.01*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
 elapsed=time.perf_counter()-tick;final,_=objective(d,w,pw);prediction=z@w
 payload=dict(kind='offline_linear_root_ranking_owner0',scope='Same rule, conditional screened domain; no calibrated leaf value',ruleset_fingerprint=c.ruleset_fingerprint,feature_kind=name,declaration_sha256=selection['declaration_sha256'],columns=columns.tolist(),mean=mean.tolist(),scale=scale.tolist(),weights=w.tolist(),input_dimension=xx.shape[1]);write_record(p/f'ranking-model-{name}.json',payload)
 restored=json.loads((p/f'ranking-model-{name}.json').read_bytes());assert np.array_equal(prediction,((xx[:,restored['columns']]-np.asarray(restored['mean']))/np.asarray(restored['scale']))@np.asarray(restored['weights']))
 rows=[]
 for key in dict.fromkeys(r):
  mask=r==key;ss=sign[mask][0];vv=ss*prediction[mask];tt=ss*y[mask];unit=ss*b[mask];chosen=np.flatnonzero(vv==vv.max());greedy=np.flatnonzero(unit==unit.max())
  rows.append(dict(root=str(key),group=str(g[mask][0]),children=int(mask.sum()),chosen_indices=ci[mask][chosen].tolist(),teacher_regret=float(np.mean(tt.max()-tt[chosen])),unit_greedy_regret=float(np.mean(tt.max()-tt[greedy])),teacher_best_fraction=float(np.mean(tt[chosen]==tt.max()))))
 models.append(dict(method=name,fit_seconds=elapsed,dimension=xx.shape[1],train_variable_columns=len(columns),train_roots=len(train_roots),train_children=int(train.sum()),pair_counts=pair_count_by_root,initial_objective=initial,final_objective=final,rows=rows));print(name,elapsed,[(rr['root'],rr['teacher_regret'])for rr in rows],flush=True)
write_record(p/'ranking-result.json',dict(scope=__doc__,status='TWO_FIXED_FITS_COMPLETE_NOT_DEPLOYED',models=models,oracle_checks=pair_oracle_checks,gradient_check=True,limits='All results conditional on material/teacher-disagreement screen, root/trajectory dependence retained. No fresh sampling/refit/selection from report, no numeric leaf deployment or universal benefit claim.'))
