"""Actual learned-search relabel control, D2/20000nodes/5sec, six roots.
No fitting/defaults; incomplete cells retained, complete minimax scores compared.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import json,time,runpy,sys
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.learning.features import material_features,non_anchor_type_ids
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
# Runs the finite legality/input verification first, in this offline control only.
scope=runpy.run_path(str(Path(__file__).with_name('relabel_control.py')))
globals().update({k:scope[k]for k in ('c','nc','e','ne','perm','m','decl','mapping','rename','GameSession','action_from_dict','action_to_dict')})
out=Path(__file__).with_name('relabel-search.json');assert not out.exists()
w=np.asarray(m.hidden_weights)/np.asarray(m.input_scale)[None,:];offset=np.asarray(m.hidden_bias)-w@np.asarray(m.input_mean);ow=np.asarray(m.output_weights)
class Evaluator:
    def __init__(self,compiled,encoder,remap):self.compiled=compiled;self.encoder=encoder;self.remap=remap;self.types=non_anchor_type_ids(compiled)
    def evaluate(self,state):
        x=self.encoder.dense(state.position)
        if self.remap:x=x[perm]
        v=1000*sum(material_features(state.position,self.types,perspective=0).array())
        v+=float((np.tanh(w@x+offset)@ow+m.output_bias)*m.target_scale)
        return v if state.position.side_to_move==0 else -v
    def capture_order_value(self,moving,captured):return 0 if self.compiled.support.type_metadata[captured.current_type_id].is_anchor else 10000
rows=[]
for i,root in enumerate(decl['roots']):
    row=dict(seed=root['seed'],calls=[])
    for name in (('old','renamed')if i%2==0 else ('renamed','old')):
        compiled,encoder=(c,e)if name=='old'else(nc,ne);s=GameSession(compiled)
        for a in root['route']:s.submit(action_from_dict(a if name=='old'else rename(a)))
        assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
        player=AlphaBetaPlayer(compiled,evaluator_override=Evaluator(compiled,encoder,name!='old'),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False))
        before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=20000,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));seconds=time.perf_counter()-tick
        validate_pv(s,d);assert before==s.state
        row['calls'].append(dict(name=name,seconds=seconds,decision=record_value(d),action=action_to_dict(d.action)))
    old=next(x for x in row['calls']if x['name']=='old');new=next(x for x in row['calls']if x['name']=='renamed')
    row['known']=all(x['decision']['completed_depth']==2 for x in row['calls'])
    row['mapped_action_equal']=rename(old['action'])==new['action'];row['score_difference']=new['decision']['score']-old['decision']['score']
    if row['known']:assert abs(row['score_difference'])<1e-9
    rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False));print(root['seed'],row['known'],row['mapped_action_equal'],row['score_difference'],flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,limits='Pure symbolic rename, fixed parameters, no changed-capability transfer or arbitrary tie-policy invariance.'))
