"""Post-result algebraic diagnosis of two retained rank errors; no fit/search.
Root0946/7 and0949/16 chosen after failures: exposed diagnostic, not validation.
Decompose selected-vs-teacher-best linear rank margins by actual feature blocks,
including ignored train-constant support. Components explain this fixed model's
arithmetic; counts alone do not prove the generalization cause.
"""
from pathlib import Path
import sys,json
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent;plan=json.loads((p/'ranking-declaration.json').read_bytes());enc=SparsePositionEncoder(compile_ruleset_for_execution(ruleset_from_dict(plan['rules'])));screen=json.loads((p/'ranking-screen.json').read_bytes())
with np.load(p/'ranking-selected-inputs.npz',allow_pickle=False)as data:inputs={n:data[k].copy()for n,k in(('position','position'),('position_pairs','position_pairs'))};y=data['targets'].copy();roots=data['roots'].copy();groups=data['groups'].copy();signs=data['signs'].copy();indices=data['children'].copy()
blocks=[('current_board',0,enc.hand_offset),('hand',enc.hand_offset,enc.side_offset),('side',enc.side_offset,enc.dynamic_offset),('dynamic',enc.dynamic_offset,enc.dynamic_offset+3),('aux',enc.dynamic_offset+3,enc.base_offset),('base_board',enc.base_offset,enc.promoted_offset),('promoted',enc.promoted_offset,enc.dimension),('pairs',enc.dimension,inputs['position_pairs'].shape[1])];rows=[]
for name,xx in inputs.items():
 m=json.loads((p/f'ranking-model-{name}.json').read_bytes());col=np.asarray(m['columns']);mean=np.asarray(m['mean']);scale=np.asarray(m['scale']);w=np.asarray(m['weights']);pred=((xx[:,col]-mean)/scale)@w
 for key in('2026100946/7','2026100949/16'):
  mask=roots==key;loc=np.flatnonzero(mask);ss=signs[loc[0]];tt=ss*y[loc];vv=ss*pred[loc];bad=loc[np.flatnonzero(vv==vv.max())[0]];good=loc[np.flatnonzero(tt==tt.max())[0]];diff=ss*(xx[bad,col]-xx[good,col])/scale*w;parts={label:float(diff[(col>=lo)&(col<hi)].sum())for label,lo,hi in blocks};assert abs(sum(parts.values())-ss*(pred[bad]-pred[good]))<1e-10
  unsupported=np.ptp(xx[groups=='train'],axis=0)==0;meanraw=xx[groups=='train'][0];ref=next(r for r in screen['roots']if f"{r['seed']}/{r['ply']}"==key)
  rows.append(dict(method=name,root=key,chosen_child=int(indices[bad]),teacher_best_child=int(indices[good]),chosen_action=ref['children'][indices[bad]]['action'],teacher_best_action=ref['children'][indices[good]]['action'],teacher_regret=float(tt.max()-ss*y[bad]),bad_minus_best_rank=float(ss*(pred[bad]-pred[good])),rank_components=parts,novel_train_constant_channels_chosen=int(np.count_nonzero(unsupported&(xx[bad]!=meanraw))),novel_train_constant_channels_best=int(np.count_nonzero(unsupported&(xx[good]!=meanraw)))))
write_record(p/'ranking-error-analysis.json',dict(scope=__doc__,rows=rows,limits='No new targets, model changes, ranking calibration or inference that unused channels caused the failure. Both actual actions retain complete semantic identity.'))
print(json.dumps(rows,indent=2))
