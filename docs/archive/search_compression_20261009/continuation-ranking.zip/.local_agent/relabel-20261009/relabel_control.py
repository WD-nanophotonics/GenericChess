"""Pure symbolic type rename and mechanical feature remap, not new-rule transfer."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution,lower_legacy_to_ir
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path('.local_agent/eval-features-20261009');decl=json.loads((p/'prospective-target-declaration.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));e=SparsePositionEncoder(c)
mapping={t:'RENAMED_'+str(len(e.types)-i)for i,t in enumerate(e.types)}
def rename(x):
    if isinstance(x,dict):return {mapping.get(k,k):rename(v)for k,v in x.items()}
    if isinstance(x,list):return [rename(v)for v in x]
    return mapping.get(x,x)if isinstance(x,str)else x
nc=compile_ruleset_for_execution(ruleset_from_dict(rename(decl['rules'])));ne=SparsePositionEncoder(nc)
def signature(obj,skip):
    row=record_value(obj)
    return json.dumps({k:v for k,v in row.items()if k not in skip},sort_keys=True)
for gid,geometry in c.ir.geometry.items():
    want=rename(record_value(geometry));want.pop('geometry_id')
    matches=[ngid for ngid,ng in nc.ir.geometry.items()if signature(ng,('geometry_id',))==json.dumps(want,sort_keys=True)]
    if len(matches)>1:
        users=[op for op in c.ir.patterns if gid in op.geometry_ids]
        compatible={ngid for op in users for npattern in nc.ir.patterns
            if tuple(mapping.get(t,t)for t in op.type_ids)==npattern.type_ids
            for ngid in npattern.geometry_ids}
        matches=[ngid for ngid in matches if ngid in compatible]
    assert len(matches)==1,(gid,want.get('atom_source'),[(key,record_value(value).get('atom_source'))for key,value in nc.ir.geometry.items()])
    mapping[gid]=matches[0]
legacy=lower_legacy_to_ir(c._legacy_compiled)
nlegacy=lower_legacy_to_ir(nc._legacy_compiled)
for pattern in legacy.patterns:
    want=rename(record_value(pattern));want.pop('pattern_id');want.pop('name')
    matches=[np.pattern_id for np in nlegacy.patterns if signature(np,('pattern_id','name'))==json.dumps(want,sort_keys=True)]
    assert len(matches)==1,(pattern.pattern_id,want)
    mapping[pattern.pattern_id]=matches[0]
for pattern in c.ir.patterns:
    want=rename(record_value(pattern));want.pop('pattern_id');want.pop('name')
    matches=[np.pattern_id for np in nc.ir.patterns if signature(np,('pattern_id','name'))==json.dumps(want,sort_keys=True)]
    assert len(matches)==1,(pattern.pattern_id,want)
    mapping[pattern.pattern_id]=matches[0]
assert e.dimension==ne.dimension and e.fingerprint!=ne.fingerprint
assert [(k[1],kind,initial)for _,k,kind,initial in e.aux_slots]==[(k[1],kind,initial)for _,k,kind,initial in ne.aux_slots]
perm=np.arange(e.dimension);area=e.shape.area;nt=len(e.types)
for owner in (0,1):
    for i,t in enumerate(e.types):
        j=ne.type_index[mapping[t]]
        for offset in (0,e.base_offset):
            a=offset+(owner*nt+i)*area;b=offset+(owner*nt+j)*area
            perm[a:a+area]=np.arange(b,b+area)
        perm[e.hand_offset+owner*nt+i]=ne.hand_offset+owner*nt+j
original=[];remapped=[];legal_counts=[];guards=0
for root in decl['roots']:
    s=GameSession(c);ns=GameSession(nc)
    for a in root['route']:s.submit(action_from_dict(a));ns.submit(action_from_dict(rename(a)))
    old={json.dumps(rename(action_to_dict(a)),sort_keys=True)for a in s.legal_actions()}
    new={json.dumps(action_to_dict(a),sort_keys=True)for a in ns.legal_actions()}
    assert old==new;legal_counts.append(len(old))
    try:e.dense(ns.state.position)
    except ValueError:guards+=1
    else:raise AssertionError('foreign fingerprint accepted')
    for item in root['children']:
        child=apply_action(s.state,action_from_dict(item['action']),c)
        nchild=apply_action(ns.state,action_from_dict(rename(item['action'])),nc)
        x=e.dense(child.position);nx=ne.dense(nchild.position)[perm]
        assert np.array_equal(x,nx)
        original.append(x);remapped.append(nx)
m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
assert np.array_equal(m.predict(np.asarray(original)),m.predict(np.asarray(remapped)))
write_record(Path(__file__).parent/'relabel-control.json',dict(scope=__doc__,mapping=mapping,old_fingerprint=e.fingerprint,new_fingerprint=ne.fingerprint,
    legal_counts=legal_counts,exact_feature_and_prediction_matches=len(original),foreign_fingerprint_rejections=guards,
    limits='Declared pure rename only; no changed capabilities or learned cross-rule representation. No search/tie-order or whole-history equivalence claim.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
print('exact renamed feature/prediction matches',len(original),'guards',guards)
