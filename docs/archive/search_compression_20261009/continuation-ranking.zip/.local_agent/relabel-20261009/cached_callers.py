"""24 balanced actual Core callers: original versus cached public arithmetic.
Same immutable fitted weights,6 original roots,2 repetitions,D3/20knodes/1sec/q0.
No model selection, no new default. Timing changes can change completed depth.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path('.local_agent/eval-features-20261009');dest=Path(__file__).parent
plan=json.loads((p/'prospective-target-declaration.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules']));types=non_anchor_type_ids(c);enc=SparsePositionEncoder(c)
m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model']);m.predict(np.zeros((1,enc.dimension)))
out=dest/'cached-callers.json';assert not out.exists()
write_record(dest/'cached-callers-declaration.json',dict(scope=__doc__,roots=plan['roots'],model_sha256=hashlib.sha256((p/'compression-model.json').read_bytes()).hexdigest(),cost='24one-second calls; no tuning or budget extension'))
def legacy(x):
    normalized=(x-np.asarray(m.input_mean))/np.asarray(m.input_scale)
    hidden=np.tanh(normalized@np.asarray(m.hidden_weights).T+np.asarray(m.hidden_bias))
    return (hidden@np.asarray(m.output_weights)+m.output_bias)*m.target_scale
class Eval:
    def __init__(self,name):self.name=name;self.calls=0;self.seconds=0
    def evaluate(self,state):
        tick=time.perf_counter();x=enc.dense(state.position)[None,:]
        v=1000*sum(material_features(state.position,types,perspective=0).array())+float((legacy if self.name=='legacy'else m.predict)(x)[0]);self.seconds+=time.perf_counter()-tick;self.calls+=1
        return v if state.position.side_to_move==0 else -v
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
rows=[]
for rep in range(2):
    for i,root in enumerate(plan['roots']):
        for name in (('legacy','cached')if(i+rep)%2==0 else('cached','legacy')):
            assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
            s=GameSession(c)
            for a in root['route']:s.submit(action_from_dict(a))
            e=Eval(name);player=AlphaBetaPlayer(c,evaluator_override=e,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;tick=time.perf_counter()
            d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick
            validate_pv(s,d);assert s.state==before
            rows.append(dict(rep=rep,seed=root['seed'],method=name,seconds=elapsed,leaf_seconds=e.seconds,leaf_calls=e.calls,decision=record_value(d),action=action_to_dict(d.action)))
            write_record(out,dict(scope=__doc__,rows=rows,complete=False))
write_record(out,dict(scope=__doc__,rows=rows,complete=True,cache_array_bytes=sum(x.nbytes for x in m._prediction_arrays)))
print([(n,sum(r['leaf_calls']for r in rows if r['method']==n),sum(r['leaf_seconds']for r in rows if r['method']==n))for n in ('legacy','cached')])

