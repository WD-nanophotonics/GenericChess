"""Actual caller diagnostic for two frozen side-balanced ablations and controls.
Eight predeclared roots, Unit/old72/aware154/blind154, D3/20knodes/1sec/q0.
Fixed cyclic method order, all completions/caps included; no model selection or
report fitting. FiniteD2 child regret is compression only, not deeper utility.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;old=Path('.local_agent/eval-features-20261009');plan=json.loads((p/'balanced-pilot-declaration.json').read_bytes());targets=json.loads((p/'balanced-pilot-targets.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules']));enc=SparsePositionEncoder(c);types=non_anchor_type_ids(c)
models={name:CompactNonlinearResidual.from_dict(json.loads((p/f'balanced-model-{name}.json').read_bytes())['model'])for name in('aware','blind')};models['old72']=CompactNonlinearResidual.from_dict(json.loads((old/'compression-model.json').read_bytes())['model'])
with np.load(p/'balanced-pilot-inputs.npz',allow_pickle=False)as data:mean=data['features'][data['groups']=='train',enc.side_offset:enc.side_offset+2].mean(axis=0)
methods=('unit','old72','aware','blind');out=p/'balanced-callers.json';assert not out.exists();rows=[]
class Eval:
    def __init__(self,name):self.name=name;self.calls=0;self.seconds=0
    def evaluate(self,state):
        tick=time.perf_counter();v=1000*sum(material_features(state.position,types,perspective=0).array())
        if self.name!='unit':
            x=enc.dense(state.position)
            if self.name=='blind':x[enc.side_offset:enc.side_offset+2]=mean
            v+=float(models[self.name].predict(x[None,:])[0])
        self.seconds+=time.perf_counter()-tick;self.calls+=1
        return v if state.position.side_to_move==0 else-v
    def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
for i,root in enumerate(plan['roots']):
    ref=next(r for r in targets['roots']if r['seed']==root['seed']);sign=1 if root['side']==0 else-1;known=all(x['known']for x in ref['children']);best=max(sign*x['owner0_target']for x in ref['children'])if known else None
    for name in methods[i%4:]+methods[:i%4]:
        assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
        s=GameSession(c)
        for a in root['route']:s.submit(action_from_dict(a))
        e=Eval(name);player=AlphaBetaPlayer(c,evaluator_override=e,use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);assert before==s.state
        a=action_to_dict(d.action);child=next(x for x in ref['children']if x['action']==a)
        rows.append(dict(seed=root['seed'],group=root['group'],side=root['side'],method=name,seconds=elapsed,leaf_calls=e.calls,leaf_seconds=e.seconds,decision=record_value(d),teacher_regret=best-sign*child['owner0_target']if known else None));write_record(out,dict(scope=__doc__,rows=rows,complete=False))
write_record(out,dict(scope=__doc__,rows=rows,complete=True));print([(n,[(r['seed'],r['decision']['completed_depth'],r['teacher_regret'])for r in rows if r['method']==n])for n in methods])
