"""Summarize frozen support and all model comparisons, without fitting/search."""
from pathlib import Path
import sys,json,itertools,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from scripts.research_record import write_record
p=Path(__file__).parent;old=Path('.local_agent/eval-features-20261009')
with np.load(p/'balanced-pilot-inputs.npz',allow_pickle=False)as d:x=d['features'].copy();y=d['targets'].copy();b=d['baseline'].copy();g=d['groups'].copy();r=d['roots'].copy();s=d['sides'].copy()
with np.load(old/'compression-inputs.npz',allow_pickle=False)as d:oldhash={hashlib.sha256(row.tobytes()).hexdigest()for row in d['features']}
hashes={name:{hashlib.sha256(row.tobytes()).hexdigest()for row in x[g==name]}for name in('train','dev','report')}
models={name:CompactNonlinearResidual.from_dict(json.loads((p/f'balanced-model-{name}.json').read_bytes())['model'])for name in('aware','blind')};models['old72']=CompactNonlinearResidual.from_dict(json.loads((old/'compression-model.json').read_bytes())['model'])
# Side offset is from the fixed encoder declaration, not a hard-coded model axis.
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.position_features import SparsePositionEncoder
plan=json.loads((p/'balanced-pilot-declaration.json').read_bytes());enc=SparsePositionEncoder(compile_ruleset_for_execution(ruleset_from_dict(plan['rules'])))
mean=x[g=='train',enc.side_offset:enc.side_offset+2].mean(axis=0);stats=[]
for name,m in models.items():
 xx=x.copy()
 if name=='blind':xx[:,enc.side_offset:enc.side_offset+2]=mean
 pred=m.predict(xx);rows=[]
 for root in plan['roots']:
  mask=r==root['seed'];t=(y+b)[mask];v=(pred+b)[mask];sign=1 if root['side']==0 else-1
  strict=[(i,j)for i in range(len(t))for j in range(i+1,len(t))if t[i]!=t[j]]
  good=sum(np.sign(v[i]-v[j])==np.sign(t[i]-t[j])for i,j in strict);tie=sum(v[i]==v[j]for i,j in strict)
  extreme=np.abs(t)>1e8;ordinary=~extreme
  rows.append(dict(seed=root['seed'],group=root['group'],strict_teacher_pairs=len(strict),correct_pairs=int(good),tied_predictions=int(tie),wrong_pairs=int(len(strict)-good-tie),teacher_mate_scale_children=int(extreme.sum()),ordinary_mse=float(np.mean((v[ordinary]-t[ordinary])**2))if ordinary.any()else None,chosen_regret=float(np.mean(np.max(sign*t)-sign*t[sign*v==np.max(sign*v)]))))
 stats.append(dict(method=name,rows=rows))
a=json.loads((p/'cached-callers.json').read_bytes());pair_checks=[]
for rep in(0,1):
 for seed in range(2026100902,2026100908):
  aa=next(z for z in a['rows']if z['rep']==rep and z['seed']==seed and z['method']=='legacy');bb=next(z for z in a['rows']if z['rep']==rep and z['seed']==seed and z['method']=='cached')
  equal=aa['action']==bb['action']and aa['decision']['score']==bb['decision']['score'];assert equal
  pair_checks.append(dict(rep=rep,seed=seed,equal_action_and_score=equal,legacy_nodes=aa['decision']['nodes'],cached_nodes=bb['decision']['nodes']))
report=dict(scope=__doc__,shape=list(x.shape),old_overlap=len(oldhash&set.union(*hashes.values())),cross_group_intersections={a+'-'+b:len(hashes[a]&hashes[b])for a,b in itertools.combinations(hashes,2)},no_statistical_independence_claim=True,comparisons=stats,cached_actual_complete_pairs=pair_checks,limits='Top-choice zero regret can coexist with poor pair ranking; ordinary MSE is separately reported, mate-scale failures retained. No changes to primary metric, data, model or outcomes.')
write_record(p/'support-summary.json',report);print(json.dumps(report,indent=2))

