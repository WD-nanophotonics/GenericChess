"""Immediate-hole diagnostic for every selected child of the declared shallow
route batch, including ongoing and terminal games. No game/result selection.
Compare methods' actual next-reply win exposures; forced/duplicate exposures
are not avoidable-error rates. No WDL/holdout admission gate, score fitting or
complete all-root search. Cache only identical full GameState/history.
Expected<15min from prior63787transition558second audit;2400sec checkpoint.
This independent bounded diagnostic is not splitting a preplanned long run.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'reply-audit.json';assert not out.exists();datasets={n:json.loads((p/(n+'.json')).read_bytes())for n in('games',)};assert all(d['complete']for d in datasets.values());cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};rows=[];audits={};transitions=0;cache_hits=0;start=time.perf_counter();complete=True
write_record(p/'audit-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),input_sha256={n:hashlib.sha256((p/(n+'.json')).read_bytes()).hexdigest()for n in datasets},total_plies=sum(len(r['steps'])for d in datasets.values()for r in d['rows'])))
def save(done):write_record(out,dict(scope=__doc__,rows=rows,audits=audits,complete=done,transitions=transitions,cache_hits=cache_hits,seconds=time.perf_counter()-start))
for name,d in datasets.items():
 for game in d['rows']:
  case=cases[game['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
  for a in case['route'][:4]:s.submit(action_from_dict(a))
  for step in game['steps']:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
   if time.perf_counter()-start>2400:complete=False;break
   s.submit(action_from_dict(step['action']));state=record_value(s.state);assert state==step['state'];key=hashlib.sha256(json.dumps(state,sort_keys=True,separators=(',',':')).encode()).hexdigest()
   if key in audits:assert audits[key]['state']==state;cache_hits+=1
   else:
    replies=0;w=[]
    if not s.state.terminal_status.is_terminal:
     for reply in legal_actions(s.state,c):
      nxt=apply_action(s.state,reply,c);transitions+=1;replies+=1
      if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-step['side']:w.append(dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status)))
    audits[key]=dict(state=state,replies=replies,witnesses=w,complete=True)
   rows.append(dict(batch=name,seed=game['seed'],leaf=game['leaf'],methods=game['methods'],ply=step['ply'],mover=step['side'],method=step['method'],state_key=key,immediate_loss_witnesses=len(audits[key]['witnesses'])))
   if len(rows)%16==0:save(False)
  if not complete:break
  print(name,game['seed'],game['leaf'],game['methods'],len(game['steps']),transitions,cache_hits,flush=True)
 if not complete:break
save(complete)
