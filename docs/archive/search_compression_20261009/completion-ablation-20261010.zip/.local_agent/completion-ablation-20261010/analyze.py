"""Describe fixed completion and cost conditions without pooling them into Elo.
Whole trajectories/rules remain dependent; ongoing64 differs from true draws and
technical unknown. Backed heuristic mate scores need not be resolved outcomes.
"""
from pathlib import Path
import sys,json,collections,statistics
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'games.json').read_bytes());assert d['complete']and len(d['rows'])==32
def summary(rows):
 events=collections.Counter();by_leaf={};methods={};cells=[]
 for r in rows:
  t=r['terminal']
  if r['abort']is not None:label='technical_unknown'
  elif t['status']=='ongoing':assert len(r['steps'])==64;label='ongoing64'
  elif t['status']=='no_contest':label='unsupported_restart'
  elif t['winner']is None:label='rule_draw'
  else:label='completion_on_win'if r['completion_by_owner'][t['winner']]else'completion_off_win'
  events[label]+=1;by_leaf.setdefault(r['leaf'],collections.Counter())[label]+=1
  cells.append(dict(seed=r['seed'],leaf=r['leaf'],owners=r['completion_by_owner'],target=r['seconds_target'],plies=len(r['steps']),terminal=t,label=label,seconds=r['seconds']))
 for enabled in(True,False):
  ss=[s for r in rows for s in r['steps']if s['completion']==enabled]
  methods[str(enabled)]=dict(calls=len(ss),transitions=sum(s['stats']['transitions']for s in ss),generations=sum(s['stats']['generations']for s in ss),evaluations=sum(s['stats']['evaluations']for s in ss),terminals=sum(s['stats']['terminals']for s in ss),call_seconds=sum(s['seconds']for s in ss),median_seconds=statistics.median(s['seconds']for s in ss),max_seconds=max(s['seconds']for s in ss),resolved_roots=sum(s['stats']['root_outcome']is not None for s in ss),structural_exhaustions=sum(s['stats']['structural_exhaustion']for s in ss),unresolved_extreme_child_occurrences=sum(abs(c['value'])==10**8 and c['outcome']is None for s in ss for c in s['stats']['root_child_records']))
 paths=collections.Counter(json.dumps([s['action']for s in r['steps']],sort_keys=True)for r in rows)
 return dict(cells=cells,outcomes=dict(events),by_leaf={k:dict(v)for k,v in by_leaf.items()},methods=methods,plies=sum(len(r['steps'])for r in rows),distinct_action_trajectories=len(paths),path_multiplicities=sorted(paths.values()))
one={(r['seed'],r['leaf'],tuple(r['completion_by_owner'])):r for r in d['rows']if r['seconds_target']==1.0};two={(r['seed'],r['leaf'],tuple(r['completion_by_owner'])):r for r in d['rows']if r['seconds_target']==2.0};pairs=[]
for key,a in one.items():
 b=two[key];assert a['initial']==b['initial'];first=next((i for i,(x,y)in enumerate(zip(a['steps'],b['steps']))if x['action']!=y['action']),None)
 pairs.append(dict(seed=key[0],leaf=key[1],owners=key[2],first_action_divergence=first,event_changed=a['terminal']!=b['terminal'],plies=[len(a['steps']),len(b['steps'])],terminals=[a['terminal'],b['terminal']]))
write_record(p/'analysis.json',dict(scope=__doc__,source=Path(__file__).read_text(),seconds=d['seconds'],conditions={str(t):summary([r for r in d['rows']if r['seconds_target']==t])for t in(1.0,2.0)},cost_pairs=pairs,no_default=True,no_training=True,no_independent_time_repeat=True))
print('seconds',d['seconds'],'time-change cells',sum(r['event_changed']for r in pairs))
for t in(1.0,2.0):print(t,summary([r for r in d['rows']if r['seconds_target']==t])['outcomes'])
