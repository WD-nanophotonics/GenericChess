"""All three current-side winning nonterminal resolutions: a D3 premise change.
Compare the installed cold maxD3/q0 under each same original1/2second target,
common Unit/v3 leaf, full original histories. Includes all three cached deeper wins as exposed attribution,
no outcome selection, training, admission proof or product/default change.
Cached frontier outcomes are not independently certified WDL; new Core calls
and old frontier timings are unpaired. Opposite findings change whether deep
completion adds signal beyond this cheaper supported route. Expected<1min. No original game condition is changed.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;assert not(p/'winning-depth3.json').exists();d=json.loads((p/'games.json').read_bytes());cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};targets=[(g,st)for g in d['rows']for st in g['steps']if st['completion']and st['stats']['root_outcome']is not None and st['state']['terminal_status']['status']=='ongoing'and st['stats']['root_outcome']==(1 if st['side']==0 else -1)];assert len(targets)==3
write_record(p/'winning-depth3-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),targets=[dict(seed=g['seed'],leaf=g['leaf'],owners=g['completion_by_owner'],target=g['seconds_target'],ply=st['ply'])for g,st in targets]))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[];started=time.perf_counter()
for g,st in targets:
 case=cases[g['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for raw in case['route'][:4]:s.submit(action_from_dict(raw))
 for step in g['steps'][:st['ply']]:s.submit(action_from_dict(step['action']))
 profile,_=build_semantic_opportunity_profile(c,cfg)
 class Leaf(UnitEvaluator):
  def __init__(self):self.ev=Evaluator(c,profile,cfg)
  def evaluate(self,state):return super().evaluate(state)if g['leaf']=='unit'else self.ev.evaluate(state)
 pl=AlphaBetaPlayer(c,evaluator_override=Leaf(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));root=s.state;tick=time.perf_counter();dec=pl.choose_action(s,SearchLimits(max_depth=3,max_time_seconds=g['seconds_target'],quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,dec);elapsed=time.perf_counter()-tick;assert s.state==root
 child=apply_action(root,dec.action,c)
 rows.append(dict(seed=g['seed'],leaf=g['leaf'],owners=g['completion_by_owner'],target=g['seconds_target'],ply=st['ply'],side=st['side'],root=record_value(root),frontier_action=st['action'],frontier_stats=st['stats'],core_decision=record_value(dec),core_caller_seconds=elapsed,core_child=record_value(child),actions_equal=action_to_dict(dec.action)==st['action']))
 print(g['seed'],g['leaf'],g['seconds_target'],st['ply'],st['stats']['root_outcome'],dec.score,dec.completed_depth,dec.selective_depth,round(elapsed,4),rows[-1]['actions_equal'],flush=True)
write_record(p/'winning-depth3.json',dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-started,complete=True))
