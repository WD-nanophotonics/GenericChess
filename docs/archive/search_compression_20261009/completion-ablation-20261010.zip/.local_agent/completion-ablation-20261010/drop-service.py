"""Scoped conditional drop-service information/cost probe.
Reuse all five2151ply3 exposed safe/adverse candidates unchanged. Current-hand
count and existing board attack flags cannot describe a silent hand deployment;
ask whether legal checking-drop options distinguish the saved immediate mate
witnesses, and what existing full-state interface work that information costs.
Generate legal handles, materialize only semantic drops, then use semantic
in_check authority. No learned utility, fitted coefficients, new playing patch
or promise that any checking drop mates. Full history/aux/stock retained.
Expected<3min, no concurrent timed games. This is a read-only diagnostic, not a
cheap leaf implementation or generalized feature admission framework.
"""
from pathlib import Path
import sys,json,time,collections
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict,SemanticDropMove
from generic_chess.core.transition import apply_action
from generic_chess.core.lazy_transitions import legal_successor_handles,materialize_legal_successor
from generic_chess.core.semantic_executor import semantic_engine_for,SemanticEngine
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;assert not(p/'drop-service.json').exists();old=Path('.local_agent/hand-discount-20261010');g=next(r for r in json.loads((old/'games.json').read_bytes())['rows']if r['seed']==202610082151 and r['policies']==['unit','v3']);case=next(r for r in json.loads((old/'prospective-rules.json').read_bytes())['rules']if r['seed']==g['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for raw in case['route'][:4]:s.submit(action_from_dict(raw))
for st in g['steps'][:3]:s.submit(action_from_dict(st['action']))
ties=json.loads((old/'d1-ties.json').read_bytes());rows=[];engine=semantic_engine_for(c);start=time.perf_counter()
write_record(p/'drop-service-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),selection=[r['index']for r in ties['rows']],root=record_value(s.state),prerequisite='docs/archive/search_compression_20261009/hand-discount-20261010.zip'))
original=SemanticEngine._transition
for r in ties['rows']:
 child=apply_action(s.state,action_from_dict(r['action']),c);owner=child.position.side_to_move;counter=[0]
 def counted(self,*a,**k):counter[0]+=1;return original(self,*a,**k)
 SemanticEngine._transition=counted;tick=time.perf_counter()
 try:
  handles=legal_successor_handles(child,c);gen_seconds=time.perf_counter()-tick;gen_transitions=counter[0];drops=[];by_pattern=collections.Counter();checks=collections.Counter()
  for h in handles:
   if not isinstance(h.action,SemanticDropMove):continue
   end=materialize_legal_successor(child,h,c)[0];delivers_check=engine.in_check(end.position,1-owner);key=h.action.pattern_id+'|'+h.action.base_type_id;by_pattern[key]+=1;checks[key]+=int(delivers_check);drops.append(dict(action=action_to_dict(h.action),delivers_check=delivers_check,terminal=record_value(end.terminal_status)))
 finally:SemanticEngine._transition=original
 rows.append(dict(index=r['index'],root_action=r['action'],child=record_value(child),current_hand=record_value(child.position.hands[owner]),auxiliary=record_value(child.position.aux_state),legal_actions=len(handles),drops=drops,drop_counts=dict(by_pattern),checking_drop_counts=dict(checks),saved_immediate_win_witnesses=r['witnesses'],generation_seconds=gen_seconds,generation_transitions=gen_transitions,feature_seconds=time.perf_counter()-tick,semantic_transitions=counter[0]))
 print(r['index'],len(handles),dict(by_pattern),dict(checks),len(r['witnesses']),counter[0],flush=True)
write_record(p/'drop-service.json',dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True,compiled_drop_actions=[record_value(a)for a in case['rules']['semantic_actions']if any(e['kind']=='remove_from_hand'for e in a['effects'])]))
