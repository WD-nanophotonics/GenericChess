"""Exposed2172v3 opening: one2second ON/OFF opening choice differs.
Predeclared512/4096/16384 successor budgets test logical work versus time cut.
Both10second ceilings, full state/common leaf/canonical handles; no gain or fit.
Possible same choices defer semantic attribution; differing choices retain a
specific completion-policy signal without independent utility claim.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path(__file__).parent)]
from frontier import choose
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import write_record
p=Path(__file__).parent;assert not(p/'fixed-attribution.json').exists();case=next(r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']if r['seed']==202610082172);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for raw in case['route'][:4]:s.submit(action_from_dict(raw))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);prof,_=build_semantic_opportunity_profile(c,cfg);leaf=Evaluator(c,prof,cfg)
write_record(p/'fixed-attribution-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),budgets=[512,4096,16384],seconds_cap=10))
rows=[]
for limit in(512,4096,16384):
 arms=[]
 for enabled in(True,False):
  a,stats=choose(s.state,c,leaf,limit,10,enabled);arms.append(dict(completion=enabled,action=action_to_dict(a),stats=stats))
 rows.append(dict(limit=limit,arms=arms));print(limit,arms[0]['action']==arms[1]['action'],[(a['stats']['transitions'],a['stats']['root_outcome'],a['stats']['selected_child_value'])for a in arms],flush=True)
write_record(p/'fixed-attribution.json',dict(scope=__doc__,rows=rows))
