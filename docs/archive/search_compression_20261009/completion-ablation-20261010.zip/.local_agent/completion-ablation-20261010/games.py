"""Predeclared32 matched completion-ON/OFF games on frozen2172-2175.
Unit/v3 common leaf on both sides; owner assignments swapped; opening4;
64ply external observation is ongoing, not draw. Same handles/canonical policy,
no TT, no learning, full generated promotion/drop/aux/history. Conditions1second
then2seconds are frozen before any game; no result-driven budget extension.
Both conditions form one information-cost study, expected<55min from prior
984second/881ply pilot; worst64ply overhead monitored at checkpoints. If revised
expectation exceeds1hour, consult dot necessity before continuing that long run;
do not split it to evade consultation. No concurrent Agent computation.
Unknown: does propagated completion/skipping affect decisions beyond exact
terminal leaf scores? Compare event paths and actual costs, not Elo or universal
values. OFF structural exhaustion prevents terminal-only re-expansion loops.
Preserve caps/aborts/all adverse outcomes. Actual job checkpoint3500seconds.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path(__file__).parent)]
from frontier import choose
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'games.json';assert not out.exists()
d=json.loads((p/'prospective-rules.json').read_bytes())
write_record(p/'declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),frontier_source=(p/'frontier.py').read_text(),rules_sha256=hashlib.sha256((p/'prospective-rules.json').read_bytes()).hexdigest(),seconds=[1.0,2.0],leaf=['unit','v3'],assignments=[[True,False],[False,True]],games=32,max_plies=64,expected_minutes=55))
assert json.loads((p/'controls.json').read_bytes())['passed']
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
rows=[];started=time.perf_counter()
for seconds in(1.0,2.0):
 for case in d['rules']:
  c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg)
  for leaf_kind in('unit','v3'):
   class Leaf(UnitEvaluator):
    def __init__(self):self.ev=Evaluator(c,profile,cfg)
    def evaluate(self,state):return super().evaluate(state)if leaf_kind=='unit'else self.ev.evaluate(state)
   for enabled in((True,False),(False,True)):
    s=GameSession(c)
    for a in case['route'][:4]:s.submit(action_from_dict(a))
    row=dict(seed=case['seed'],leaf=leaf_kind,seconds_target=seconds,completion_by_owner=enabled,initial=record_value(s.state),steps=[],complete=False,abort=None);rows.append(row);tick=time.perf_counter()
    for ply in range(64):
     if s.state.terminal_status.is_terminal:break
     assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-started<3500
     side=s.state.position.side_to_move;before=s.state;call=time.perf_counter();action,stats=choose(before,c,Leaf(),1000000,seconds,enabled[side]);elapsed=time.perf_counter()-call;assert s.state==before
     if action is None:row['abort']='empty_frontier';break
     assert action in s.legal_actions();s.submit(action)
     row['steps'].append(dict(ply=ply,side=side,completion=enabled[side],action=action_to_dict(action),stats=stats,seconds=elapsed,state=record_value(s.state)))
     if ply%16==0:write_record(out,dict(scope=__doc__,complete=False,rows=rows,seconds=time.perf_counter()-started))
    row.update(complete=True,seconds=time.perf_counter()-tick,terminal=record_value(s.state.terminal_status));write_record(out,dict(scope=__doc__,complete=False,rows=rows,seconds=time.perf_counter()-started));print(seconds,case['seed'],leaf_kind,enabled,len(row['steps']),row['terminal'],round(row['seconds'],2),flush=True)
write_record(out,dict(scope=__doc__,complete=True,rows=rows,seconds=time.perf_counter()-started))
