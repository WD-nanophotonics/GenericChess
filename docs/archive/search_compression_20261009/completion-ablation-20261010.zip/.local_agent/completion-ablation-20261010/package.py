"""Purpose-specific completion ablation and shallow route recovery.
Only Agent-generated sources/rules/observations; no transport/user/account data.
Verify exact member hashes, replay every saved full state including history,
and replay positive selected-child reply witnesses. Recovery is not independent
scientific validation or restoration of unexposed qualification.
"""
from pathlib import Path
import sys,json,hashlib,zipfile
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
folders=[Path('.local_agent/completion-ablation-20261010'),Path('.local_agent/shallow-completion-20261010')]
archive=Path('docs/archive/search_compression_20261009/completion-ablation-20261010.zip');assert not archive.exists();members=[]
files=sorted(f for p in folders for f in p.iterdir()if f.suffix in('.py','.json','.md') and f.name!='segment_review.md')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in files:
  raw=f.read_bytes();name=f.as_posix();assert '/slack/'not in name and not f.is_absolute();z.writestr(name,raw);members.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
states=0;witnesses=0;attribution_witnesses=0;core_controls=0
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
 for p in folders:
  pref=p.as_posix()+'/';data=json.loads(z.read(pref+'games.json'));assert data['complete'];cases={r['seed']:r for r in json.loads(z.read(pref+'prospective-rules.json'))['rules']};reply_audits=json.loads(z.read(pref+'reply-audit.json'))['audits']if pref+'reply-audit.json'in z.namelist()else{}
  for g in data['rows']:
   case=cases[g['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
   for raw in case['route'][:4]:s.submit(action_from_dict(raw))
   assert record_value(s.state)==g['initial']
   for st in g['steps']:
    s.submit(action_from_dict(st['action']));raw=record_value(s.state);assert raw==st['state'];states+=1
    if reply_audits:
     key=hashlib.sha256(json.dumps(raw,sort_keys=True,separators=(',',':')).encode()).hexdigest();a=reply_audits[key];assert a['state']==raw
     for w in a['witnesses']:
      end=apply_action(s.state,action_from_dict(w['action']),c);assert record_value(end.terminal_status)==w['terminal'];witnesses+=1
   assert record_value(s.state.terminal_status)==g['terminal']
  if p==folders[0]:
   for r in json.loads(z.read(pref+'attribution.json'))['rows']:
    g=next(g for g in data['rows']if g['seed']==r['seed']and g['leaf']==r['leaf']and g['completion_by_owner']==r['owners']and g['seconds_target']==r['selected'][0]['target'])
    case=cases[r['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
    for raw in case['route'][:4]:s.submit(action_from_dict(raw))
    for st in g['steps'][:r['ply']]:s.submit(action_from_dict(st['action']))
    assert record_value(s.state)==r['state']
    for choice in r['selected']:
     nxt=apply_action(s.state,action_from_dict(choice['action']),c)
     for w in choice['opponent_win_witnesses']:
      end=apply_action(nxt,action_from_dict(w['action']),c);assert record_value(end.terminal_status)==w['terminal'];witnesses+=1;attribution_witnesses+=1
   for filename in('resolved-parent-core.json','winning-depth3.json'):
    for r in json.loads(z.read(pref+filename))['rows']:
     g=next(g for g in data['rows']if g['seed']==r['seed']and g['leaf']==r['leaf']and g['completion_by_owner']==r['owners']and g['seconds_target']==r['target']);case=cases[r['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));game=GameSession(c)
     for raw in case['route'][:4]:game.submit(action_from_dict(raw))
     for st in g['steps'][:r['ply']]:game.submit(action_from_dict(st['action']))
     assert record_value(game.state)==r['root'];assert record_value(apply_action(game.state,action_from_dict(r['core_decision']['action']),c))==r['core_child']
     core_controls+=1
drop_children=0;drop_options=0
from generic_chess.core.semantic_executor import semantic_engine_for
with zipfile.ZipFile(archive)as z,zipfile.ZipFile(archive.with_name('hand-discount-20261010.zip'))as prior:
 pref=folders[0].as_posix()+'/';service=json.loads(z.read(pref+'drop-service.json'));oldpref='.local_agent/hand-discount-20261010/';oldgames=json.loads(prior.read(oldpref+'games.json'));oldrules=json.loads(prior.read(oldpref+'prospective-rules.json'));g=next(g for g in oldgames['rows']if g['seed']==202610082151 and g['policies']==['unit','v3']);case=next(c for c in oldrules['rules']if c['seed']==g['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));game=GameSession(c)
 for raw in case['route'][:4]:game.submit(action_from_dict(raw))
 for st in g['steps'][:3]:game.submit(action_from_dict(st['action']))
 assert record_value(game.state)==json.loads(z.read(pref+'drop-service-declaration.json'))['root']
 engine=semantic_engine_for(c)
 for r in service['rows']:
  child=apply_action(game.state,action_from_dict(r['root_action']),c);assert record_value(child)==r['child'];drop_children+=1
  for d in r['drops']:
   end=apply_action(child,action_from_dict(d['action']),c);assert record_value(end.terminal_status)==d['terminal'];assert engine.in_check(end.position,1-child.position.side_to_move)==d['delivers_check'];drop_options+=1
prereq=[]
for name in('completion-search-20261010','handle-time-20261010','hand-discount-20261010'):
 f=archive.with_name(name+'.zip');prereq.append(dict(path=f.as_posix(),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
index=archive.with_name(archive.stem+'-index.json')
write_record(index,dict(scope=__doc__,base_commit='1f5b533eab6afa35f5626ffcd9d953a60fed4428',archive=archive.as_posix(),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=members,prerequisites=prereq,verification=dict(member_hashes=len(members),full_game_states=states,selected_reply_witness_occurrences=witnesses,resolved_parent_core_children=core_controls,drop_service_children=drop_children,drop_option_replays=drop_options)))
write_record(Path('docs/research/data/completion_ablation_20261010.json'),dict(scope=__doc__,archive_index=index.as_posix(),ablation=json.loads((folders[0]/'analysis.json').read_bytes()),shallow=json.loads((folders[1]/'analysis.json').read_bytes()),shallow_reply_summary={k:v for k,v in json.loads((folders[1]/'reply-analysis.json').read_bytes()).items()if k!='positive_rows'},winning_depth3=dict(rows=[dict(seed=r['seed'],leaf=r['leaf'],target=r['target'],ply=r['ply'],completed_depth=r['core_decision']['completed_depth'],score=r['core_decision']['score'],caller_seconds=r['core_caller_seconds'],actions_equal=r['actions_equal'])for r in json.loads((folders[0]/'winning-depth3.json').read_bytes())['rows']]),resolution_cost_scale=dict(rows=[dict(seed=r['seed'],leaf=r['leaf'],ply=r['ply'],limit=r['limit'],transitions=r['stats']['transitions'],outcome=r['stats']['root_outcome'],caller_seconds=r['caller_seconds'],actions_equal=r['actions_equal'])for r in json.loads((folders[0]/'resolution-cost-scale.json').read_bytes())['rows']]),resolved_parent_core=dict(rows=[dict(seed=r['seed'],leaf=r['leaf'],target=r['target'],ply=r['ply'],side=r['side'],frontier_outcome=r['frontier_stats']['root_outcome'],frontier_seconds=r['frontier_stats']['seconds'],core_score=r['core_decision']['score'],core_depth=r['core_decision']['completed_depth'],core_selective_depth=r['core_decision']['selective_depth'],core_caller_seconds=r['core_caller_seconds'],actions_equal=r['actions_equal'])for r in json.loads((folders[0]/'resolved-parent-core.json').read_bytes())['rows']]),drop_service=dict(rows=[dict(index=r['index'],legal_actions=r['legal_actions'],drop_counts=r['drop_counts'],checking_drop_counts=r['checking_drop_counts'],saved_win_witnesses=len(r['saved_immediate_win_witnesses']),generation_seconds=r['generation_seconds'],generation_transitions=r['generation_transitions'],feature_seconds=r['feature_seconds'],semantic_transitions=r['semantic_transitions'])for r in json.loads((folders[0]/'drop-service.json').read_bytes())['rows']]),attribution_summary=dict(parents=len(json.loads((folders[0]/'attribution.json').read_bytes())['rows']),positive_reply_occurrences=attribution_witnesses),full_state_replay=states))
print('members',len(members),'bytes',archive.stat().st_size,'states',states,'witnesses',witnesses)
