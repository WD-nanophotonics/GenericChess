"""All three winning-resolution gaps: fixed128/512/2048-successor cost scale.
Measure the same fixed-work frontier under each same original1/2second target,
common Unit/v3 leaf, full original histories. Includes all three cached deeper wins as exposed attribution,
no outcome selection, training, admission proof or product/default change.
No selected policy or exposed-label fit; all work caps retained. This is a
local cost-scale diagnostic, not prospective playing validation or equal AB nodes. Opposite findings change whether deep
completion adds signal beyond this cheaper supported route. Expected<1min. No original game condition is changed.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path(__file__).parent)]
from frontier import choose
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;assert not(p/'resolution-cost-scale.json').exists();d=json.loads((p/'games.json').read_bytes());cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};targets=[(g,st)for g in d['rows']for st in g['steps']if st['completion']and st['stats']['root_outcome']is not None and st['state']['terminal_status']['status']=='ongoing'and st['stats']['root_outcome']==(1 if st['side']==0 else -1)];assert len(targets)==3
write_record(p/'resolution-cost-scale-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),budgets=[128,512,2048],targets=[dict(seed=g['seed'],leaf=g['leaf'],owners=g['completion_by_owner'],target=g['seconds_target'],ply=st['ply'])for g,st in targets]))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[];started=time.perf_counter()
for g,st in targets:
 case=cases[g['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for raw in case['route'][:4]:s.submit(action_from_dict(raw))
 for step in g['steps'][:st['ply']]:s.submit(action_from_dict(step['action']))
 profile,_=build_semantic_opportunity_profile(c,cfg)
 class Leaf(UnitEvaluator):
  def __init__(self):self.ev=Evaluator(c,profile,cfg)
  def evaluate(self,state):return super().evaluate(state)if g['leaf']=='unit'else self.ev.evaluate(state)
 leaf=Leaf();root=s.state
 for limit in(128,512,2048):
  tick=time.perf_counter();action,stats=choose(root,c,leaf,limit,g['seconds_target'],True);elapsed=time.perf_counter()-tick;assert s.state==root
  rows.append(dict(seed=g['seed'],leaf=g['leaf'],owners=g['completion_by_owner'],target=g['seconds_target'],ply=st['ply'],side=st['side'],limit=limit,action=action_to_dict(action),stats=stats,caller_seconds=elapsed,actions_equal=action_to_dict(action)==st['action']))
  print(g['seed'],g['leaf'],st['ply'],limit,stats['transitions'],stats['root_outcome'],round(elapsed,4),rows[-1]['actions_equal'],flush=True)
write_record(p/'resolution-cost-scale.json',dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-started,complete=True))
