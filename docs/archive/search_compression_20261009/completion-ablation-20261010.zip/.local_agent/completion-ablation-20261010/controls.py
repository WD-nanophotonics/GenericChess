"""Finite bookkeeping controls for a new terminal-preserving OFF ablation.
Then compare ON against saved old512 Unit/v3 signatures at the2169opening4
common parent; no label fit, product patch, or unchanged full-cohort rerun.
"""
from pathlib import Path
import sys,json,time
from types import SimpleNamespace as NS
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path(__file__).parent)]
import frontier as f
from scripts.research_record import write_record
p=Path(__file__).parent
write_record(p/'study-plan.json',dict(scope='Before controls/outcomes:32fixed2172-2175 games, common Unit/v3 leaves, swapped ON/OFF owners,1/2second predeclared resource curve,64ply ongoing; expected<55min total job; no result-dependent changes.',game_source=(p/'games.py').read_text(),frontier_source=(p/'frontier.py').read_text()))
saved=f.legal_successor_handles,f.materialize_legal_successor,f.action_to_dict
class Leaf:
 def evaluate(self,s):return s.value
def state(name,side=0,winner=None,terminal=False,value=0):return NS(name=name,position=NS(side_to_move=side),terminal_status=NS(is_terminal=terminal,winner=winner),value=value)
rows=[]
try:
 f.action_to_dict=lambda a:dict(edge=a)
 def run(edges,root,limit,enabled):
  f.legal_successor_handles=lambda s,c:tuple(NS(action=a,child=b)for a,b in edges.get(s.name,()))
  f.materialize_legal_successor=lambda s,h,c:(h.child,h.child.name)
  return f.choose(root,NS(declarations=()),Leaf(),limit,10,enabled)
 for side in(0,1):
  root=state('root',side);win=state('win',1-side,winner=side,terminal=True);unknown=[state('u'+str(i),i%2)for i in range(10)];edges={'root':[('a-win',win),('b-unknown',unknown[0])]}
  for a,b in zip(unknown,unknown[1:]):edges[a.name]=[('next',b)]
  a,on=run(edges,root,8,True);b,off=run(edges,root,8,False);assert a==b=='a-win'and on['root_outcome']==(1 if side==0 else -1)and off['root_outcome']is None and off['transitions']==8;rows.append(dict(case='existential-win',side=side,on=on,off=off))
 for side in(0,1):
  root=state('root',side);loss=state('loss',1-side,winner=1-side,terminal=True);edges={'root':[('a-loss',loss),('b-loss',loss)]}
  a,on=run(edges,root,8,True);b,off=run(edges,root,8,False);assert a==b and off['structural_exhaustion']and off['transitions']==2 and on['root_outcome']==(-1 if side==0 else 1);rows.append(dict(case='all-terminal-loss-no-spin',side=side,on=on,off=off))
 root=state('root');loss=state('loss',1,winner=1,terminal=True);unknown=state('unknown',1);edges={'root':[('a-loss',loss),('b-unknown',unknown)]}
 for enabled in(True,False):
  _,stats=run(edges,root,1,enabled);assert stats['root_outcome']is None and not stats['root_fully_expanded'];rows.append(dict(case='partial-loss-is-not-proof',completion=enabled,stats=stats))
finally:f.legal_successor_handles,f.materialize_legal_successor,f.action_to_dict=saved
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from test_rectangular_search_override import UnitEvaluator
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
prior=Path('.local_agent/frontier-time-20261010');case=next(r for r in json.loads((prior/'prospective-rules.json').read_bytes())['rules']if r['seed']==202610082165)
# The old saved handle-control parent is2165, not the newer2169game parent.
# Use it only to verify ON source parity; the current question's2169parent
# remains in the current prior rules and is measured separately below.
checks=[]
for source,seed in((prior,202610082165),(Path('.local_agent/handle-time-20261010'),202610082169)):
 case=next(r for r in json.loads((source/'prospective-rules.json').read_bytes())['rules']if r['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 profile,_=build_semantic_opportunity_profile(c,cfg)
 for kind in('unit','v3'):
  class Eval(UnitEvaluator):
   def __init__(self):self.ev=Evaluator(c,profile,cfg)
   def evaluate(self,state):return super().evaluate(state)if kind=='unit'else self.ev.evaluate(state)
  arms=[]
  for enabled in(True,False):
   a,stats=f.choose(s.state,c,Eval(),512,10,enabled);arms.append(dict(completion=enabled,action=action_to_dict(a),stats=stats))
  if seed==202610082165:
   old=next(r for r in json.loads((prior/'handles.json').read_bytes())['rows']if r['seed']==seed and r['opening']==4 and r['leaf']==kind)
   assert arms[0]['action']==old['action']and all(arms[0]['stats'][k]==v for k,v in old['stats'].items()if k!='seconds')
  checks.append(dict(seed=seed,leaf=kind,arms=arms))
write_record(p/'controls.json',dict(scope=__doc__,source=Path(__file__).read_text(),passed=True,finite_controls=rows,common_parent_calls=checks))
print('six finite controls and eight actual common-parent calls passed')
