"""Selected common-parent attribution, exposed development scope.
Compare ON/OFF first choices at identical openings, plus earliest first common
parent where1/2second trajectories diverge. Probe root immediate terminal wins
and actual selected-child opponent immediate wins; absence is next-reply-only,
not an all-defense/WDL certificate. Preserve full state/history. No fitting.
This discriminates immediate stop savings from deeper/partial heuristic signal.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.lazy_transitions import legal_successor_handles,materialize_legal_successor
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;assert not(p/'attribution.json').exists();d=json.loads((p/'games.json').read_bytes());assert d['complete'];cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};idx={(r['seed'],r['leaf'],r['seconds_target'],tuple(r['completion_by_owner'])):r for r in d['rows']};rows=[];started=time.perf_counter();transitions=0
write_record(p/'attribution-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),input_sha256=hashlib.sha256((p/'games.json').read_bytes()).hexdigest(),selection='all16same-opening arm pairs and all earliest common time-divergence parents',expected_minutes=5))
def inspect(a,b,ply,kind):
 global transitions
 case=cases[a['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for raw in case['route'][:4]:s.submit(action_from_dict(raw))
 for x,y in zip(a['steps'][:ply],b['steps'][:ply]):assert x['action']==y['action'];s.submit(action_from_dict(x['action']))
 state=s.state;owner=state.position.side_to_move;children={};wins=[]
 for h in legal_successor_handles(state,c):
  nxt=materialize_legal_successor(state,h,c)[0];transitions+=1;raw=action_to_dict(h.action);children[json.dumps(raw,sort_keys=True)]=nxt
  if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==owner:wins.append(raw)
 chosen=[]
 for g in(a,b):
  st=g['steps'][ply];nxt=children[json.dumps(st['action'],sort_keys=True)];w=[];count=0
  assert record_value(nxt)==st['state']
  if not nxt.terminal_status.is_terminal:
   for h in legal_successor_handles(nxt,c):
    end=materialize_legal_successor(nxt,h,c)[0];transitions+=1;count+=1
    if end.terminal_status.is_terminal and end.terminal_status.winner==1-owner:w.append(dict(action=action_to_dict(h.action),terminal=record_value(end.terminal_status)))
  chosen.append(dict(completion=st['completion'],target=g['seconds_target'],action=st['action'],stats=st['stats'],terminal=record_value(nxt.terminal_status),reply_count=count,opponent_win_witnesses=w))
 rows.append(dict(kind=kind,seed=a['seed'],leaf=a['leaf'],owners=a['completion_by_owner'],ply=ply,state=record_value(state),root_immediate_wins=wins,selected=chosen))
for seed in cases:
 for leaf in('unit','v3'):
  for seconds in(1.0,2.0):inspect(idx[(seed,leaf,seconds,(True,False))],idx[(seed,leaf,seconds,(False,True))],0,'opening_arm_pair')
  for owners in((True,False),(False,True)):
   a=idx[(seed,leaf,1.0,owners)];b=idx[(seed,leaf,2.0,owners)];first=next((i for i,(x,y)in enumerate(zip(a['steps'],b['steps']))if x['action']!=y['action']),None)
   if first is not None:inspect(a,b,first,'first_time_divergence')
  print(seed,leaf,len(rows),transitions,flush=True)
write_record(p/'attribution.json',dict(scope=__doc__,rows=rows,transitions=transitions,seconds=time.perf_counter()-started,complete=True))
