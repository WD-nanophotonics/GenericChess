"""Root TT-priority intervention on2151ply3; no increased budget or label fitting.
Only the root ordering TT move is omitted, retaining TT lookup/storage and all
child ordering. Research-only monkeypatch, no installed product change.
Decision: does previous D1 move promotion account for D2coverage/loss?
All three existing arms get same512/D2/q0 budget, both adverse outcomes retained.
Three existing leaf arms at coldCore512nodes/D2/q0/root-scanoff/Unitordering.
Observe each actual ply1 invocation/action/window/completion against saved original controls. Decision: how much of D2 really finishes,
and does fixed Unit ordering mean the same TT-guided root order? A raw returned
window-bound score is not necessarily an exact full-child value. Under3min.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.ordering import MoveOrderer
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
p=Path('.local_agent/hand-discount-20261010');ctrl=json.loads((p/'parent-controls-fixed.json').read_bytes());case=next(r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']if r['seed']==202610082151);g=next(r for r in json.loads((p/'games.json').read_bytes())['rows']if r['seed']==case['seed'] and r['policies']==['unit','v3']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for a in case['route'][:4]:s.submit(action_from_dict(a))
for step in g['steps'][:3]:s.submit(action_from_dict(step['action']))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);prof,_=build_semantic_opportunity_profile(c,cfg);original=search.negamax;rows=[];trace=[]
original_order=MoveOrderer.order
def neutral_root(self,state,actions,evaluator,depth,tt_move,prev_action,tuning):
 return original_order(self,state,actions,evaluator,depth,None if prev_action is None else tt_move,prev_action,tuning)
MoveOrderer.order=neutral_root
def observer(state,depth,alpha,beta,ply,ctx,prev_action=None,node_key=None,pv_node=True):
 row=None
 if ply==1:
  row=dict(depth=depth,action=action_to_dict(prev_action),alpha=alpha,beta=beta,nodes_before=ctx.stats.nodes,complete=False);trace.append(row)
 try:
  result=original(state,depth,alpha,beta,ply,ctx,prev_action,node_key,pv_node)
 except search.SearchAborted:
  if row is not None:row['nodes_after']=ctx.stats.nodes
  raise
 if row is not None:row.update(complete=True,score=result.score,nodes_after=ctx.stats.nodes)
 return result
search.negamax=observer;start=time.perf_counter()
try:
 for kind in ('unit','v3','v3_hand_board'):
  class Leaf(UnitEvaluator):
   def __init__(self):self.ev=Evaluator(c,replace(prof,hand_value_by_base_type=dict(prof.board_value_by_type)) if kind=='v3_hand_board'else prof,cfg)
   def evaluate(self,state):return super().evaluate(state) if kind=='unit' else self.ev.evaluate(state)
  trace=[];leaf=Leaf();pl=AlphaBetaPlayer(c,evaluator_override=leaf,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));assert before==s.state
  old=next(r['decision']for r in ctrl['rows']if r['seed']==case['seed']and r['root_actions']==126 and r['policy']==kind);new=record_value(dec)
  child=apply_action(before,dec.action,c);w=[];reply_count=0
  if not child.terminal_status.is_terminal:
   for reply in legal_actions(child,c):
    reply_count+=1;nxt=apply_action(child,reply,c)
    if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-before.position.side_to_move:w.append(action_to_dict(reply))
  rows.append(dict(policy=kind,decision=new,trace=trace,witnesses=w,replies=reply_count));print(kind,[(dep,sum(x['depth']==dep and x['complete']for x in trace))for dep in (0,1)],flush=True)
finally:
 search.negamax=original
 MoveOrderer.order=original_order
write_record(Path('docs/research/data/root_tt_neutral_probe_20261010.json'),dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,source=Path(__file__).read_text(),fixed_limits_preserved=True,prerequisite_archive="docs/archive/search_compression_20261009/hand-discount-20261010.zip"))
