"""Package completed Agent-generated root-order/semantic relation evidence only.
No Slack, ledger, user input or credential members. Verify bytes and public
history replay from archive rather than claim recovery from a successful zip.
"""
from pathlib import Path
import json,hashlib,zipfile,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
p=Path(__file__).parent;archive=Path('docs/archive/search_compression_20261009/root-order-transfer-20261010.zip');index=archive.with_name(archive.stem+'-index.json');assert not archive.exists()
files=sorted([*p.glob('*.py'),*p.glob('*.json')]+[Path('.local_agent')/name for name in ('hand-relation-probe-20261010.py','hand-relation-cohort-20261010.py','root-tt-neutral-probe-20261010.py','hand-drop-q1-probe-20261010.py','hand-drop-q1-declaration-20261010.json')],key=lambda x:x.as_posix())
members=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in files:
  data=f.read_bytes();path=f.as_posix();assert path.startswith('.local_agent/')and '/slack/'not in path;z.writestr(path,data);members.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(members)
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
 base=p.as_posix()+'/';games=json.loads(z.read(base+'games.json'));audits=json.loads(z.read(base+'reply-audit.json'));cases={r['seed']:r for r in json.loads(z.read(base+'prospective-rules.json'))['rules']};replayed=0;witnesses=0
 assert games['complete']and audits['complete']
 for game in games['rows']:
  case=cases[game['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
  for a in case['route'][:4]:s.submit(action_from_dict(a))
  assert record_value(s.state)==game['initial']
  for step in game['steps']:
   s.submit(action_from_dict(step['action']));raw=record_value(s.state);assert raw==step['state'];key=hashlib.sha256(json.dumps(raw,sort_keys=True,separators=(',',':')).encode()).hexdigest();saved=audits['audits'][key];assert saved['state']==raw and saved['complete'];replayed+=1
   for w in saved['witnesses']:
    nxt=apply_action(s.state,action_from_dict(w['action']),c);assert record_value(nxt.terminal_status)==w['terminal']and nxt.terminal_status.winner==1-step['side'];witnesses+=1
 prereq=Path('docs/archive/search_compression_20261009/hand-discount-20261010.zip');data=prereq.read_bytes()
write_record(index,dict(scope=__doc__,base_commit='f95674cee40e1554c7d438e928475c71869925a1',archive=archive.as_posix(),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,uncompressed_bytes=sum(m['bytes']for m in members),members=members,prerequisites=[dict(path=prereq.as_posix(),sha256=hashlib.sha256(data).hexdigest(),index='docs/archive/search_compression_20261009/hand-discount-20261010-index.json')],public_probe_records=['docs/research/data/'+n for n in ('hand_relation_probe_20261010.json','hand_relation_cohort_20261010.json','root_tt_neutral_probe_20261010.json','hand_drop_q1_probe_20261010.json')],verification=dict(member_hashes=len(members),game_states=replayed,winning_reply_occurrences=witnesses),qualifications=['roots-import-failure.py is pre-label import failure; repaired producer adds tests fixture paths','reply_audit.py does not reuse prior roots despite its docstring;235new unique states/162within-batch hits','15q1choices are all unchanged; earlier checkpoint broad choice wording is qualified','three distinct selected-loss parents have all-root next-reply mate; only2161ply7 has immediate-safe alternatives','root-order intervention and frontier prototype are research-only; no default or equal-count-cost claim']))
print(len(members),archive.stat().st_size,replayed,witnesses)
