"""Finite decision-changing root-support diagnostic, not full WDL: all legal
root choices at the four distinct immediate-loss parents and two first common
divergence parents in the16game factorial. At each child enumerate opponent
replies until first real mating witness, or exhaust replies to establish only
absence of an immediate witness. No search budget extension/fit/new game.
Question: are changed trajectories associated with avoidable local choices,
or all-root immediate losses? This changes attribution, not default/strength.
Expected<35min,2700sec interruptible checkpoint. Six fixed full-history parents,
all actions, retain partial if checkpoint exceeded. No user data/holdout.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'choice-audit.json';assert not out.exists();games=json.loads((p/'games.json').read_bytes())['rows'];audit=json.loads((p/'reply-audit.json').read_bytes());assert audit['complete'];cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};targets=[]
for r in audit['rows']:
 if r['immediate_loss_witnesses']:targets.append(dict(seed=r['seed'],ordering=r['ordering'],policies=r['policies'],ply=r['ply'],purpose='immediate_loss'))
for r in json.loads((p/'divergences.json').read_bytes())['pairs']:
 if r['first_divergence']is not None:targets.append(dict(seed=r['seed'],ordering='original',policies=r['policies'],ply=r['first_divergence'],purpose='first_divergence'))
parents={}
for r in targets:
 g=next(g for g in games if g['seed']==r['seed']and g['ordering']==r['ordering']and g['policies']==r['policies']);state=g['initial']if r['ply']==0 else g['steps'][r['ply']-1]['state'];key=hashlib.sha256(json.dumps(state,sort_keys=True,separators=(',',':')).encode()).hexdigest();parents.setdefault(key,dict(seed=r['seed'],state=state,aliases=[]))['aliases'].append(r)
assert len(parents)==6
write_record(p/'choice-audit-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),parents=parents,games_sha256=hashlib.sha256((p/'games.json').read_bytes()).hexdigest()))
rows=[];transitions=0;start=time.perf_counter();complete=True
def save(done):write_record(out,dict(scope=__doc__,rows=rows,complete=done,transitions=transitions,seconds=time.perf_counter()-start))
for key,r in parents.items():
 case=cases[r['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);alias=r['aliases'][0];g=next(g for g in games if g['seed']==r['seed']and g['ordering']==alias['ordering']and g['policies']==alias['policies'])
 for a in case['route'][:4]+[step['action']for step in g['steps'][:alias['ply']]]:s.submit(action_from_dict(a))
 assert record_value(s.state)==r['state'];before=s.state;actions=sorted(legal_actions(before,c),key=str);row=dict(key=key,seed=r['seed'],aliases=r['aliases'],parent=r['state'],root_actions=len(actions),children=[],complete=False);rows.append(row)
 for action in actions:
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  if time.perf_counter()-start>2700:complete=False;break
  child=apply_action(before,action,c);transitions+=1;witness=None;replies=0;exhausted=True
  if not child.terminal_status.is_terminal:
   for reply in legal_actions(child,c):
    nxt=apply_action(child,reply,c);transitions+=1;replies+=1
    if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-before.position.side_to_move:witness=dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status));exhausted=False;break
  row['children'].append(dict(action=action_to_dict(action),terminal=record_value(child.terminal_status),opponent_mating_witness=witness,replies_examined=replies,replies_exhausted=exhausted))
  if len(row['children'])%8==0:save(False)
 row['complete']=len(row['children'])==len(actions);save(False);print(r['seed'],alias['ply'],len(actions),len(row['children']),sum(x['opponent_mating_witness']is not None for x in row['children']),transitions,round(time.perf_counter()-start,3),flush=True)
 if not complete:break
save(complete)
