"""Scoped completion-aware best-first minimax feasibility, no product/default.
Public full GameState transitions; no board-only TT, no training, no fabricated
terminal at budget/horizon. Node score is heuristic owner0; resolved outcome is
separate and comes only from actual terminal/valid existential or all-child
backup. Partial expansion never proves an all-child result. No declarations in
these fixed generated rules; declaration/restart interfaces are excluded here.
512 materialized successors/call, which is NOT the same work unit as alpha-beta
visited nodes. Report transitions/evaluations/generation/time/bytes separately;
usefulness needs matched-cost comparison later, not proof from a changed move.
Root-first best unresolved path, canonical tie order, one leaf expansion per
iteration. This is a finite prototype motivated by Cohen-Solal's completion
method, not a reimplementation/parity or general completeness claim.
"""
from dataclasses import dataclass,field
import json,time
from generic_chess.core.actions import action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value
MATE=10**8
@dataclass
class Node:
 state: object
 value: int
 outcome: int|None=None
 children: list=field(default_factory=list)
 actions: list|None=None
 expanded: bool=False

def choose(state,compiled,evaluator,limit=512):
 assert not getattr(compiled,'declarations',())
 stats=dict(transitions=0,evaluations=0,generations=0,iterations=0,terminals=0,partial_expansions=0)
 def node(s):
  if s.terminal_status.is_terminal:
   stats['terminals']+=1;w=s.terminal_status.winner;out=0 if w is None else 1 if w==0 else -1
   return Node(s,out*MATE,out)
  stats['evaluations']+=1;v=evaluator.evaluate(s);return Node(s,v if s.position.side_to_move==0 else -v)
 def backup(n):
  if not n.children:return
  side=n.state.position.side_to_move;win=1 if side==0 else -1
  wins=[x for _,x in n.children if x.outcome==win]
  if wins:n.outcome=win;n.value=win*MATE;return
  if n.expanded and all(x.outcome is not None for _,x in n.children):
   n.outcome=(max if side==0 else min)(x.outcome for _,x in n.children);n.value=n.outcome*MATE;return
  # The estimate from a partial frontier is never a resolved outcome.
  n.value=(max if side==0 else min)(x.value for _,x in n.children)
 def preference(n,x):
  sign=1 if n.state.position.side_to_move==0 else -1
  return (sign*(x.outcome if x.outcome is not None else 0),sign*x.value)
 root=node(state);started=time.perf_counter()
 while root.outcome is None and stats['transitions']<limit:
  path=[root];n=root
  while n.expanded and n.children:
   candidates=[pair for pair in n.children if pair[1].outcome is None]
   if not candidates:backup(n);break
   _,n=max(candidates,key=lambda pair:preference(n,pair[1]));path.append(n)
  if n.outcome is not None:
   for parent in reversed(path[:-1]):backup(parent)
   continue
  if n.actions is None:
   n.actions=sorted(legal_actions(n.state,compiled),key=str);stats['generations']+=1
  # Core terminal is authority; an unexpected empty ongoing node is an error,
  # not a synthetic draw or heuristic resolution.
  assert n.actions
  for action in n.actions[len(n.children):]:
   if stats['transitions']>=limit:stats['partial_expansions']+=1;break
   child=node(apply_action(n.state,action,compiled));stats['transitions']+=1;n.children.append((action,child))
   # A real current-player winning child is enough, including partial expansion.
   if child.outcome==(1 if n.state.position.side_to_move==0 else -1):break
  n.expanded=len(n.children)==len(n.actions)
  for parent in reversed(path):backup(parent)
  stats['iterations']+=1
 if not root.children:return None,dict(stats,seconds=time.perf_counter()-started,outcome=root.outcome)
 action,child=max(root.children,key=lambda pair:preference(root,pair[1]))
 stats.update(seconds=time.perf_counter()-started,root_outcome=root.outcome,root_fully_expanded=root.expanded,selected_child_outcome=child.outcome,selected_child_value=child.value,root_children=len(root.children),root_resolved_children=sum(x.outcome is not None for _,x in root.children),root_child_records=[dict(action=action_to_dict(a),outcome=x.outcome,value=x.value,fully_expanded=x.expanded,children=len(x.children))for a,x in root.children])
 return action,stats
