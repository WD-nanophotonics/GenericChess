"""Completion-aware frontier feasibility, 34 fixed calls at512 materialized
successors: all five exposed hand-law parents and12 already frozen2160-2163
opening0/4/8 roots, Unit/v3. No fit/default or added old alpha-beta budget.
Decision: does an explicitly resolved frontier expose drop threats that fixed
depth misses, and at what actual end-to-end cost?512successors differs from
512alpha-beta nodes; report both without equal-cost claims. Full GameState,
public Core legality/transition, real terminal only; no TT/training/declarations.
Expected<15min,1800sec interruptible batch checkpoint. Retain every failure.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path(__file__).parent)]
from frontier import choose
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'frontier.json';assert not out.exists()
old=json.loads(Path('docs/research/data/hand_drop_q1_probe_20261010.json').read_bytes());hg=json.loads(Path('.local_agent/hand-discount-20261010/games.json').read_bytes())['rows'];hr={r['seed']:r for r in json.loads(Path('.local_agent/hand-discount-20261010/prospective-rules.json').read_bytes())['rules']}
nr={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};roots=json.loads((p/'roots.json').read_bytes())['rows'];targets=[]
for key,r in old['parents'].items():
 g=next(g for g in hg if g['seed']==r['seed'] and g['policies']==list(r['policies']))
 targets.append(dict(key=key,seed=r['seed'],rules=hr[r['seed']]['rules'],route=hr[r['seed']]['route'][:4]+[x['action']for x in g['steps'][:r['ply']]],parent=r['state'],scope='exposed_hand_parent'))
for r in roots:
 if r['leaf']=='unit' and r['ordering']=='original':targets.append(dict(key=f"{r['seed']}/{r['opening']}",seed=r['seed'],rules=nr[r['seed']]['rules'],route=nr[r['seed']]['route'][:r['opening']],parent=r['parent'],scope='already_root_exposed'))
assert len(targets)==17
write_record(p/'frontier-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),frontier_source=Path(p/'frontier.py').read_text(),parent_keys=[r['key']for r in targets],calls=34,limit=512))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[];start=time.perf_counter();audit_transitions=0
for r in targets:
 c=compile_ruleset_for_execution(ruleset_from_dict(r['rules']));s=GameSession(c)
 for a in r['route']:s.submit(action_from_dict(a))
 assert record_value(s.state)==r['parent'];profile,_=build_semantic_opportunity_profile(c,cfg)
 for kind in ('unit','v3'):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<1800
  class Leaf(UnitEvaluator):
   def __init__(self):self.ev=Evaluator(c,profile,cfg)
   def evaluate(self,state):return super().evaluate(state)if kind=='unit'else self.ev.evaluate(state)
  before=s.state;action,stats=choose(before,c,Leaf(),512);assert s.state==before and action in legal_actions(before,c)
  child=apply_action(before,action,c);audit_transitions+=1;w=[];replies=0
  if not child.terminal_status.is_terminal:
   for reply in legal_actions(child,c):
    nxt=apply_action(child,reply,c);replies+=1;audit_transitions+=1
    if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-before.position.side_to_move:w.append(dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status)))
  rows.append(dict(parent_key=r['key'],seed=r['seed'],scope=r['scope'],leaf=kind,parent=r['parent'],action=action_to_dict(action),child=record_value(child),stats=stats,replies=replies,witnesses=w));write_record(out,dict(scope=__doc__,rows=rows,complete=False,seconds=time.perf_counter()-start,audit_transitions=audit_transitions));print(r['key'],kind,stats['transitions'],stats['root_outcome'],len(w),round(stats['seconds'],3),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start,audit_transitions=audit_transitions))
