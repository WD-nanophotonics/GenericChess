"""Fixed matched common-parent attribution control; adapted from original root producer, not its prospective claim."""
"""Prospective48root factorial, four frozen new rules2160-2163/opening0,4,8.
Unit/v3 leaf prices by original/neutral-root TT priority. Core cold D2max512,
10sec safety margin,q0/hard8,Unit capture ordering,no root scan. Neutral only
omits TT move in ROOT ordering; child TT/probes/storage remain. No fit/default.
Audit all selected children for immediate terminal loss, not all-root proof.
Decision: is neutral scheduling consistently useful or only raises partial
coverage on an exposed parent? Record unchanged/adverse calls, ties not gains.
Expected<8min;600sec cost checkpoint, no continuation at a larger node budget.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.ordering import MoveOrderer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
import generic_chess.ai.alphabeta.search as search
p=Path(__file__).parent;out=p/'common-parents.json';assert not out.exists();d=json.loads((p/'prospective-rules.json').read_bytes());target=json.loads((p/'choice-audit.json').read_bytes());assert target['complete'];parents=[r for r in target['rows']if any(a['purpose']=='first_divergence'for a in r['aliases'])or r['aliases'][0]['ply']==7]
write_record(p/'common-parent-declaration.json',dict(scope='12coldCore D2max512/q0/Unitordering original versus neutral root priority at both common divergences and avoidable2161ply7. No fit/default or old cap extension.',source=Path(__file__).read_text(),targets=[r['key']for r in parents],calls=12))
original_order=MoveOrderer.order;original_search=search.negamax;trace=[];mode='original'
def order(self,state,actions,evaluator,depth,tt_move,prev_action,tuning):
 return original_order(self,state,actions,evaluator,depth,None if mode=='neutral' and prev_action is None else tt_move,prev_action,tuning)
def observer(state,depth,alpha,beta,ply,ctx,prev_action=None,node_key=None,pv_node=True):
 row=None
 if ply==1:row=dict(depth=depth,action=action_to_dict(prev_action),alpha=alpha,beta=beta,nodes_before=ctx.stats.nodes,complete=False);trace.append(row)
 try:r=original_search(state,depth,alpha,beta,ply,ctx,prev_action,node_key,pv_node)
 except search.SearchAborted:
  if row is not None:row['nodes_after']=ctx.stats.nodes
  raise
 if row is not None:row.update(complete=True,score=r.score,nodes_after=ctx.stats.nodes)
 return r
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[];transitions=0;start=time.perf_counter()
MoveOrderer.order=order;search.negamax=observer
try:
 for r in parents:
  case=next(x for x in d['rules']if x['seed']==r['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg)
  for opening in (r['aliases'][0]['ply'],):
   alias=r['aliases'][0];game=next(g for g in json.loads((p/'games.json').read_bytes())['rows']if g['seed']==r['seed']and g['ordering']==alias['ordering']and g['policies']==alias['policies']);s=GameSession(c)
   for raw in case['route'][:4]+[x['action']for x in game['steps'][:opening]]:s.submit(action_from_dict(raw))
   assert record_value(s.state)==r['parent']
   before=s.state;actions=legal_actions(before,c)
   for kind in ('unit','v3'):
    class Leaf(UnitEvaluator):
     def __init__(self):self.ev=Evaluator(c,profile,cfg)
     def evaluate(self,state):return super().evaluate(state)if kind=='unit'else self.ev.evaluate(state)
    for mode in ('original','neutral'):
     assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<600
     trace=[];pl=AlphaBetaPlayer(c,evaluator_override=Leaf(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));seconds=time.perf_counter()-tick;validate_pv(s,dec);assert before==s.state
     child=apply_action(before,dec.action,c);transitions+=1;w=[];replies=0
     if not child.terminal_status.is_terminal:
      for reply in legal_actions(child,c):
       nxt=apply_action(child,reply,c);transitions+=1;replies+=1
       if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-before.position.side_to_move:w.append(action_to_dict(reply))
     rows.append(dict(seed=case['seed'],opening=opening,leaf=kind,ordering=mode,parent=record_value(before),root_actions=len(actions),decision=record_value(dec),trace=trace,child=record_value(child),witnesses=w,replies=replies,seconds=seconds));write_record(out,dict(scope=__doc__,rows=rows,transitions=transitions,seconds=time.perf_counter()-start,complete=False));print(case['seed'],opening,kind,mode,dec.completed_depth,len(w),flush=True)
finally:MoveOrderer.order=original_order;search.negamax=original_search
write_record(out,dict(scope=__doc__,rows=rows,transitions=transitions,seconds=time.perf_counter()-start,complete=True))
