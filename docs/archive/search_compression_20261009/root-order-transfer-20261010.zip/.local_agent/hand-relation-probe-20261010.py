"""Check whether existing semantic attack/defense relations distinguish five audited ties.
Exposed diagnostic, no score change/model/fit; reuse all safe/adverse top children.
Both owner check flags use the existing semantic authority. Cost is descriptive,
not a caller speed comparison; failure to separate selects a different cheap
relation, not an all-defense proof gate. Exact parent/action provenance retained.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.learning.features import tactical_interaction_features
from scripts.research_record import record_value,write_record
p=Path('.local_agent/hand-discount-20261010');g=next(r for r in json.loads((p/'games.json').read_bytes())['rows']if r['seed']==202610082151 and r['policies']==['unit','v3']);case=next(r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']if r['seed']==g['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for a in case['route'][:4]:s.submit(action_from_dict(a))
for step in g['steps'][:3]:s.submit(action_from_dict(step['action']))
ties=json.loads((p/'d1-ties.json').read_bytes());engine=semantic_engine_for(c);rows=[];start=time.perf_counter()
for r in ties['rows']:
 child=apply_action(s.state,action_from_dict(r['action']),c);flags=[engine.in_check(child.position,owner)for owner in (0,1)];t0=time.perf_counter();features=tactical_interaction_features(child.position,c);elapsed=time.perf_counter()-t0;rows.append(dict(index=r['index'],action=r['action'],owner_check_flags=flags,features=features,feature_seconds=elapsed,immediate_loss_witnesses=len(r['witnesses'])))
out=dict(scope=__doc__,source=Path(__file__).read_text(),parent_sha256=hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True,separators=(',',':')).encode()).hexdigest(),seed=g['seed'],policies=g['policies'],ply=3,prerequisite_archive='docs/archive/search_compression_20261009/hand-discount-20261010.zip',rows=rows,seconds=time.perf_counter()-start,transitions=5,no_training=True)
write_record(Path('docs/research/data/hand_relation_probe_20261010.json'),out);print(rows)
