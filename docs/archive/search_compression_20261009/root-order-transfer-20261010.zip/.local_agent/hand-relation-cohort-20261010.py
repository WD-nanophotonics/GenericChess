"""Exposed descriptive assay of existing semantic relation input on all275plies.
Reuse saved full-state immediate-terminal audits, no new labels or coefficient
fit. A fixed descriptive alarm is ANY hanging current piece of the prior mover;
it is not a mate classifier or evaluator. Include terminal states separately.
Compare bulk attacked_squares to point authority on occupied squares, record
extraction work/time. No legacy anchor approximation or history substitution.
Decision: does the five-child separation survive the existing entire cohort,
and is the signal narrow enough to warrant an independent caller experiment?
"""
from pathlib import Path
import sys,json,time,hashlib
from collections import Counter
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.learning.features import tactical_interaction_features
from scripts.research_record import record_value,write_record
p=Path('.local_agent/hand-discount-20261010');out=Path('docs/research/data/hand_relation_cohort_20261010.json');assert not out.exists()
games=json.loads((p/'games.json').read_bytes());audit=json.loads((p/'reply-audit.json').read_bytes());cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};rows=[];cache={};points=0;bulk_calls=0;start=time.perf_counter()
for g in games['rows']:
 c=compile_ruleset_for_execution(ruleset_from_dict(cases[g['seed']]['rules']));e=semantic_engine_for(c);s=GameSession(c)
 for a in cases[g['seed']]['route'][:4]:s.submit(action_from_dict(a))
 for step in g['steps']:
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  s.submit(action_from_dict(step['action']));assert record_value(s.state)==step['state'];key=hashlib.sha256(json.dumps(record_value(s.state),sort_keys=True,separators=(',',':')).encode()).hexdigest()
  if key not in cache:
   tick=time.perf_counter();f=tactical_interaction_features(s.state.position,c);feature_seconds=time.perf_counter()-tick
   tick=time.perf_counter();maps=[e.attacked_squares(s.state.position,owner)for owner in (0,1)];bulk_seconds=time.perf_counter()-tick;bulk_calls+=2
   for square,piece in enumerate(s.state.position.board):
    if piece is None:continue
    for owner in (0,1):
     assert (square in maps[owner])==e.is_square_attacked(s.state.position,square,owner);points+=1
   cache[key]=dict(features=f,feature_seconds=feature_seconds,bulk_seconds=bulk_seconds)
  data=cache[key];mover=step['side'];hang=sum(v for k,v in data['features'].items()if k.startswith('hanging_by_type:'+str(mover)+':'));a=audit['audits'][key];assert a['state']==step['state']
  rows.append(dict(seed=g['seed'],policies=g['policies'],ply=step['ply'],mover=mover,state_key=key,hanging=hang,alarm=hang>0,immediate_loss=bool(a['witnesses']),terminal=s.state.terminal_status.is_terminal))
 counts=Counter((r['terminal'],r['alarm'],r['immediate_loss'])for r in rows)
 print(g['seed'],g['policies'],len(rows),dict(counts),flush=True)
summary=[dict(terminal=k[0],alarm=k[1],immediate_loss=k[2],count=v)for k,v in sorted(counts.items())]
write_record(out,dict(scope=__doc__,source=Path(__file__).read_text(),base_commit='f95674cee40e1554c7d438e928475c71869925a1',prerequisite_archive='docs/archive/search_compression_20261009/hand-discount-20261010.zip',games_sha256=hashlib.sha256((p/'games.json').read_bytes()).hexdigest(),audit_sha256=hashlib.sha256((p/'reply-audit.json').read_bytes()).hexdigest(),rows=rows,states=cache,summary=summary,point_queries=points,bulk_calls=bulk_calls,seconds=time.perf_counter()-start,complete=True,no_training=True))
