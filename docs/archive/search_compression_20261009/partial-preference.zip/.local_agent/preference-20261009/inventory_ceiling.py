"""Exposed input ceiling, not a fitted predictor or changed primary metric.
Within each complete frozen frontier, group children by exact signed current
and base inventories, both hand inventories, per-owner promoted counts and side.
Any mathematically count-only rank must tie each class. Best class mean provides
a descriptive per-root lower bound on uniform-tie regret. Type IDs only identify
inventory equivalence for this audit, never model features. Missing roots remain
unknown; no fitted class scores, default changes or retraining.
"""
from pathlib import Path
import sys,json,collections,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
p=Path(__file__).parent;plan=json.loads((p/'declaration.json').read_bytes());data=json.loads((p/'result.json').read_bytes());assert data['complete'];compiled=[compile_ruleset_for_execution(ruleset_from_dict(r))for r in plan['rules']];fits=json.loads((p/'fit-result.json').read_bytes())['results'];rows=[];start=time.perf_counter()
def signature(pos):
 current=collections.Counter();base=collections.Counter();promoted=[0,0]
 for piece in pos.board:
  if piece is not None:
   sign=1 if piece.owner==0 else-1;current[piece.current_type_id]+=sign;base[piece.base_type_id]+=sign;promoted[piece.owner]+=piece.promoted
 return (tuple(sorted((k,v)for k,v in current.items()if v)),tuple(sorted((k,v)for k,v in base.items()if v)),tuple(pos.hands[0].counts),tuple(pos.hands[1].counts),tuple(promoted),pos.side_to_move)
for i,(root,ref)in enumerate(zip(plan['roots'],data['rows'])):
 c=compiled[root['rule_index']];s=GameSession(c)
 for raw in root['route']:s.submit(action_from_dict(raw))
 groups=collections.defaultdict(list)
 for j,raw in enumerate(root['children']):groups[signature(apply_action(s.state,action_from_dict(raw),c).position)].append(j)
 row=dict(root=ref['root'],group=root['group'],known=ref['known'],actions=len(root['children']),inventory_classes=len(groups),class_indices=list(groups.values()))
 if ref['known']:
  ss=1 if root['side']==0 else-1;targets=[ss*r['owner0_target']for r in ref['children']];best=max(targets);means=[sum(targets[j]for j in ids)/len(ids)for ids in groups.values()];row['oracle_uniform_class_regret']=best-max(means);row['conflicting_classes']=sum(len({targets[j]for j in ids})>1 for ids in groups.values());row['class_teacher_ranges']=[max(targets[j]for j in ids)-min(targets[j]for j in ids)for ids in groups.values()];model=[]
  for method,result in fits.items():
   if'rows'not in result:continue
   metric=result['rows'][i];chosen=set(metric['chosen']);partial=[ids for ids in groups.values()if chosen.intersection(ids)and not set(ids).issubset(chosen)];closure=set(j for ids in groups.values()if chosen.intersection(ids)for j in ids);regret=sum(best-targets[j]for j in closure)/len(closure);model.append(dict(method=method,actual_regret=metric['regret'],uniform_class_closure_regret=regret,partial_tie_classes=len(partial),below_inventory_ceiling=metric['regret']+1e-9<row['oracle_uniform_class_regret']))
  row['models']=model
 rows.append(row)
write_record(p/'inventory-ceiling.json',dict(scope=__doc__,seconds=time.perf_counter()-start,rows=rows,limits='Post-result descriptive oracle, richer than shared descriptor aliases and unconstrained compared with linear prices. It is a lower bound for inventory-only ranks with uniform exact class ties, not achievable learned utility or universal price truth. Actual model results stay unchanged; FP partial ties diagnosed separately.'))
summary=[]
for g in ('train','dev','report'):
 group=[r for r in rows if r['group']==g]
 summary.append(dict(group=g,roots=len(group),known=sum(r['known']for r in group),positive_ceiling=sum(r.get('oracle_uniform_class_regret',0)>0 for r in group)))
print(json.dumps(summary,indent=2))
