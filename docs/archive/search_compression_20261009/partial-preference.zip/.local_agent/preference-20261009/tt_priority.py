"""Existing-ordering versus structural TT-first, separate from frozen teachers.
Sixteen preselected first two trajectories per rule,2balanced repeats of CoreD3
2048/8192nodes5sec/q0. Unit leaves unchanged; capture scale500/10000 is a fixed negative-control factor. Only structural
TT priority differs. One process, old source snapshot and isolated candidate
method; product remains untouched until evidence/review. Expected5-12minutes.
All caps retained. Compare completed score/PV and finite-reference choices,
not number of changed choices as gains. No tuning or training.
"""
from pathlib import Path
import sys,json,time,inspect,textwrap
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import ordering
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;plan=json.loads((p/'declaration.json').read_bytes());data=json.loads((p/'result.json').read_bytes());assert data['complete'];indices=[0,1,2,3,16,17,18,19,32,33,34,35,48,49,50,51];original=ordering.MoveOrderer.order;source=textwrap.dedent(inspect.getsource(original));oldline='return sorted(actions, key=lambda a: (priority(a), str(a)))';assert oldline in source;newsource=source.replace(oldline,'return sorted(actions, key=lambda a: (a != tt_move, priority(a), str(a)))');namespace=ordering.__dict__.copy();exec(newsource,namespace);candidate=namespace['order'];assert not(p/'tt-priority.json').exists();(p/'old-order-method.py').write_bytes(source.encode());(p/'candidate-order-method.py').write_bytes(newsource.encode());write_record(p/'tt-priority-declaration.json',dict(scope=__doc__,indices=indices,repeats=2,old_source='old-order-method.py',candidate_source='candidate-order-method.py'));rows=[]
for i in indices:
 root=plan['roots'][i];ref=data['rows'][i];c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules'][root['rule_index']]));types=non_anchor_type_ids(c);s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 class Unit:
  def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
  def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else capture_scale
 for capture_scale in(500,10000):
  for nodes in(2048,8192):
   for rep in range(2):
    for name in(('old','structural')if(i+rep)%2==0 else('structural','old')):
     assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];ordering.MoveOrderer.order=original if name=='old'else candidate;player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=True,use_ordering=True,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=nodes,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);j=next(j for j,a in enumerate(root['children'])if a==action_to_dict(d.action));ss=1 if root['side']==0 else-1;regret=max(ss*x['owner0_target']for x in ref['children'])-ss*ref['children'][j]['owner0_target']if ref['known']else None;rows.append(dict(root=ref['root'],capture_scale=capture_scale,nodes=nodes,rep=rep,method=name,seconds=elapsed,regret=regret,decision=record_value(d)))
    pair=rows[-2:]
    if all(r['decision']['completed_depth']==3 for r in pair):assert pair[0]['decision']['score']==pair[1]['decision']['score']
    print(ref['root'],capture_scale,nodes,rep,[(r['method'],r['decision']['completed_depth'],r['regret'],r['seconds'])for r in pair],flush=True)
 write_record(p/'tt-priority.json',dict(scope=__doc__,complete=False,rows=rows))
ordering.MoveOrderer.order=original;write_record(p/'tt-priority.json',dict(scope=__doc__,complete=True,rows=rows,limits='All old teacher configurations remain unchanged. Only TT stage priority repaired; nonTT order same. Warm process compiled rule cache, cold players/TT and balanced order. Local resource curve not strength/default budget adoption.'))
