"""Exposed cost attribution control, no fitting or teacher replacement.
Preselected first trajectory7/16 for each of four rules,8roots. Cold childD2
Core2048nodes1sec TT+ordering versus original lexical/noTT references. Same
depth/evaluator/full-history carrier; keep capped differences and exact-score
comparisons only when both complete. Expected5-10min,900sec checkpoint.
Question: does the apparent cost advantage of partial root preferences merely
reflect an unnecessarily expensive lexical full-reference baseline?
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;plan=json.loads((p/'declaration.json').read_bytes());indices=[0,1,16,17,32,33,48,49];assert not(p/'ordered-reference.json').exists();write_record(p/'ordered-reference-declaration.json',dict(scope=__doc__,indices=indices,fit=False));out=dict(scope=__doc__,complete=False,rows=[]);start=time.perf_counter()
for i in indices:
 root=plan['roots'][i];c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules'][root['rule_index']]));s=GameSession(c);types=non_anchor_type_ids(c)
 for raw in root['route']:s.submit(action_from_dict(raw))
 class Unit:
  def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
  def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
 row=dict(root=f"{root['seed']}/{root['ply']}",index=i,children=[])
 for j,raw in enumerate(root['children']):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];child=apply_action(s.state,action_from_dict(raw),c);cell=dict(index=j,known=False)
  if time.perf_counter()-start>=900:cell['reason']='cost_checkpoint'
  elif child.terminal_status.is_terminal:cell.update(known=True,owner0_target=terminal_score(child.terminal_status,0,0),seconds=0)
  else:
   cs=GameSession(c);cs._state=child;cs._search_history_witnesses=s._search_history_witnesses+(child.position,);player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=True,use_ordering=True,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(cs,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(cs,d);cell.update(known=d.completed_depth==2,owner0_target=d.score*(1 if child.position.side_to_move==0 else-1),seconds=time.perf_counter()-tick,decision=record_value(d))
  row['children'].append(cell)
 out['rows'].append(row);write_record(p/'ordered-reference.json',out);print(row['root'],sum(a['known']for a in row['children']),len(row['children']),flush=True)
out.update(complete=True,seconds=time.perf_counter()-start);write_record(p/'ordered-reference.json',out)
