"""Fixed same-input rank fits; only full versus certified partial labels vary.
No architecture expansion, candidate selection, exposed-report refits or numeric
leaf deployment. Train mean/std from ALL legal train children (labels irrelevant),
same268 count axes and seed/300Adam/.01/.0001/margin1. Root-balanced usable pairs.
Full uses complete root best versus lower; partial uses certified optimal versus
inferior only, NEVER unknown negatives or a single chosen-as-only-positive label.
Evaluate all roots with complete finite references, unselected zeros included.
"""
from pathlib import Path
import os
for key in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path('.local_agent/interaction-20261009')))
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
p=Path(__file__).parent;plan=json.loads((p/'declaration.json').read_bytes());fd=p/'fit-declaration.json'
if '--declare'in sys.argv:
 assert not fd.exists();write_record(fd,dict(scope=__doc__,declaration_sha256=hashlib.sha256((p/'declaration.json').read_bytes()).hexdigest(),methods=['full','partial2048','partial8192'],seed=2026100951,epochs=300,learning_rate=.01,regularization=.0001,margin=1,model_selection=False,deadline_seconds=120));print('Frozen prior to candidate outputs');raise SystemExit
assert fd.exists()and not(p/'fit-result.json').exists();decl=json.loads(fd.read_bytes());assert decl['declaration_sha256']==hashlib.sha256((p/'declaration.json').read_bytes()).hexdigest();data=json.loads((p/'result.json').read_bytes());assert data['complete']
compiled=[compile_ruleset_for_execution(ruleset_from_dict(r))for r in plan['rules']];encoders=[InteractionProjection(c)for c in compiled];countcols=list(range(66))+list(range(396,462))+list(range(792,924))+[924,930,936,937];xs=[];slices=[];groups=[]
for root in plan['roots']:
 c=compiled[root['rule_index']];e=encoders[root['rule_index']];s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 first=len(xs)
 for raw in root['children']:xs.append(e.encode(apply_action(s.state,action_from_dict(raw),c).position)[countcols]);groups.append(root['group'])
 slices.append((first,len(xs)))
x=np.asarray(xs);train=np.asarray(groups)=='train';cols=np.flatnonzero(np.ptp(x[train],axis=0)>0);mean=x[train][:,cols].mean(0);scale=x[train][:,cols].std(0);z=(x[:,cols]-mean)/scale;results={}
np.savez_compressed(p/'inputs.npz',features=x,groups=np.asarray(groups),slices=np.asarray(slices))
for method in decl['methods']:
 batches=[];usable=[]
 for i,(root,row)in enumerate(zip(plan['roots'],data['rows'])):
  if root['group']!='train':continue
  if method=='full':
   if not row['known']:continue
   target=np.asarray([a['owner0_target']*(1 if root['side']==0 else-1)for a in row['children']]);best=np.flatnonzero(target==target.max());other=np.flatnonzero(target<target.max())
  else:
   part=next(t for t in row['partial']if t['nodes']==int(method[7:]));best=np.asarray([t['index']for t in part['cells']if t['classification']=='CERTIFIED_OPTIMAL'],dtype=int);other=np.asarray([t['index']for t in part['cells']if t['classification']=='CERTIFIED_INFERIOR'],dtype=int)
  if not len(best)or not len(other):continue
  offset=slices[i][0];aa=np.repeat(best,len(other))+offset;bb=np.tile(other,len(best))+offset;diff=(1 if root['side']==0 else-1)*(z[aa]-z[bb]);batches.append(diff);usable.append(dict(root=row['root'],pairs=len(diff),positive=len(best),negative=len(other)))
 if not batches:results[method]=dict(status='NO_USABLE_PAIRS',usable_roots=[]);continue
 diff=np.concatenate(batches);pw=np.concatenate([np.full(len(d),1/(len(batches)*len(d)))for d in batches]);rng=np.random.default_rng(decl['seed']);w=rng.normal(0,.001,len(cols));mom=np.zeros_like(w);vel=np.zeros_like(w);tick=time.perf_counter()
 for step in range(1,301):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-tick<120
  grad=-(pw*(1-diff@w>0))@diff+.0001*w;mom=.9*mom+.1*grad;vel=.999*vel+.001*grad*grad;w-=.01*(mom/(1-.9**step))/(np.sqrt(vel/(1-.999**step))+1e-8)
 model=dict(kind=method,columns=cols.tolist(),mean=mean.tolist(),scale=scale.tolist(),weights=w.tolist(),count_columns=countcols);write_record(p/(method+'-model.json'),model);prediction=z@w;metrics=[]
 for i,(root,row)in enumerate(zip(plan['roots'],data['rows'])):
  lo,hi=slices[i];ss=1 if root['side']==0 else-1;v=ss*prediction[lo:hi];chosen=np.flatnonzero(v==v.max()).tolist()if len(v)else[];target=np.asarray([ss*a.get('owner0_target',0)for a in row['children']]);regret=float(np.mean(target.max()-target[chosen]))if row['known']else None;metrics.append(dict(root=row['root'],group=root['group'],chosen=chosen,regret=regret,known=row['known']))
 restored=json.loads((p/(method+'-model.json')).read_bytes());assert np.array_equal(prediction,((x[:,restored['columns']]-restored['mean'])/restored['scale'])@restored['weights']);results[method]=dict(seconds=time.perf_counter()-tick,usable_roots=usable,variable_columns=len(cols),zero_pair_weight=float(pw[np.all(diff==0,axis=1)].sum()),rows=metrics)
write_record(p/'fit-result.json',dict(scope=__doc__,results=results,limits='Four exposed full rules, frozen fresh whole trajectories, same common train normalization/input. Partial/root coverage differs and is reported, no report refitting/default/price-usefulness claim.'));print(json.dumps({k:{a:b for a,b in v.items()if a!='rows'}for k,v in results.items()},indent=2))
