"""Whole-denominator partial-reference audit; no reruns or result filtering."""
from pathlib import Path
import json,collections,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'declaration.json').read_bytes());r=json.loads((p/'result.json').read_bytes());assert r['complete'];assert len(d['roots'])==len(r['rows']);groups=[]
for ri in range(4):
 rows=[row for row in r['rows']if row['rule_index']==ri];children=[a for row in rows for a in row['children']];group=dict(rule_index=ri,roots=len(rows),children=len(children),complete_roots=sum(row['known']for row in rows),known_children=sum(a['known']for a in children),reference_seconds=sum(a.get('seconds',0)for a in children),partial=[])
 for budget in(2048,8192):
  parts=[next(t for t in row['partial']if t['nodes']==budget)for row in rows];cells=[c for t in parts for c in t['cells']];errors=[];known_bounds=0;usable=0;certified_unchecked=0
  for row,part in zip(rows,parts):
   classes=collections.Counter(c['classification']for c in part['cells']);usable+=bool(classes['CERTIFIED_OPTIMAL']and classes['CERTIFIED_INFERIOR'])
   for c in part['cells']:
    known_bounds+=('reference_root_score'in c and('lower'in c or'upper'in c));certified_unchecked+=c['classification']!='UNKNOWN'and'reference_root_score'not in c
   if row['known']and not part.get('missing')and part['decision']['completed_depth']==3:
    best=max(c['reference_root_score']for c in part['cells']);assert part['decision']['score']==best,(row['root'],budget,best,part['decision']['score'])
   errors.append(dict(root=row['root'],complete_reference=row['known'],root_depth=part.get('decision',{}).get('completed_depth'),classes=dict(classes),unknown_reasons=dict(collections.Counter('noncompleted_root'if part.get('decision',{}).get('completed_depth')!=3 else'no_entry'if'entry_depth'not in c and c.get('source')!='terminal'else'wrong_depth'if c.get('source')=='TT'and c['entry_depth']!=2 else'one_sided_or_cooptimal_bound'for c in part['cells']if c['classification']=='UNKNOWN'))))
  group['partial'].append(dict(nodes=budget,seconds=sum(t.get('seconds',0)+t.get('probe_seconds',0)for t in parts),completed_D3=sum(t.get('decision',{}).get('completed_depth')==3 for t in parts),usable_pair_roots=usable,classes=dict(collections.Counter(c['classification']for c in cells)),known_bound_checks=known_bounds,certified_without_complete_child_reference=certified_unchecked,rows=errors))
 groups.append(group)
write_record(p/'audit.json',dict(scope=__doc__,groups=groups,batch_seconds=r['seconds'],limits='Bounds independently compared only where child finite references complete; rest retain unchecked denominator. Completed root/complete frontier equality checked. Unknown ties are not negatives. Four exposed rules, no natural/unknown-rule distribution or WDL claim.'))
print(json.dumps([{k:v for k,v in g.items()if k!='partial'}|{'partial':[{k:v for k,v in t.items()if k!='rows'}for t in g['partial']]}for g in groups],indent=2))
