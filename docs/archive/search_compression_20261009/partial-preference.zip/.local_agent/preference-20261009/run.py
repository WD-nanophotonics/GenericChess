"""Prospective partial preference coverage, not another architecture expansion.
32fresh whole trajectories1600..1631 on four unchanged full generated rules,
roots7/16. Freeze all actions/routes before queries. Existing Unit Core D3
TT+order2048/8192node5sec versus full childD2 lexical2048node1sec.
Exact depth2 entries only; incomplete root yields no preference labels.
Check qualified bounds against every complete reference; partial reference
cannot certify best-root regret. No fitting/selection during measurement.
Decision: whether partial preferences deliver useful cross-rule coverage/cost,
and which missing actions remain unknown. Expected30-45minutes,3000sec cost
checkpoint, no long run or worker. All caps, zero roots and original rules kept.
"""
from pathlib import Path
import sys,json,random,time,hashlib,collections
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.transposition import score_from_tt
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.evaluation.config import MATE_THRESHOLD
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not(p/'declaration.json').exists()
rules=[r['rules']for r in json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases']];compiled=[compile_ruleset_for_execution(ruleset_from_dict(r))for r in rules];roots=[]
for i,seed in enumerate(range(2026101600,2026101632)):
 ri=i//8;s=GameSession(compiled[ri]);rng=random.Random(seed);route=[]
 for ply in range(17):
  acts=[]if s.state.terminal_status.is_terminal else sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True))
  if ply in(7,16):roots.append(dict(rule_index=ri,seed=seed,ply=ply,group='train'if ri<2 else'dev'if ri==2 else'report',route=route.copy(),state=record_value(s.state),side=s.state.position.side_to_move,missing=len(route)!=ply,children=[action_to_dict(a)for a in acts]))
  if ply<16 and acts:a=rng.choice(acts);route.append(action_to_dict(a));s.submit(a)
decl=dict(scope=__doc__,rules=rules,roots=roots,partial_budgets=[2048,8192],full_child_nodes=2048,full_child_seconds=1,checkpoint_seconds=3000,training='None; subsequent fit would require a new frozen plan, not changed teacher targets.')
write_record(p/'declaration.json',decl);start=time.perf_counter();out=dict(scope=__doc__,declaration_sha256=hashlib.sha256((p/'declaration.json').read_bytes()).hexdigest(),complete=False,rows=[])
def check_stop():
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
for root in roots:
 c=compiled[root['rule_index']];types=non_anchor_type_ids(c);s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 class Unit:
  def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
  def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
 row=dict(root=f"{root['seed']}/{root['ply']}",rule_index=root['rule_index'],group=root['group'],partial=[],children=[])
 for nodes in(2048,8192):
  check_stop();cells=[]
  if not root['children']or time.perf_counter()-start>=3000:row['partial'].append(dict(nodes=nodes,missing=True,cells=cells));continue
  player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=True,use_ordering=True,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=nodes,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);runtime=SearchPathRuntime(s.state,c,history_witnesses=s._search_witnesses);tick=time.perf_counter()
  for j,raw in enumerate(root['children']):
   a=action_from_dict(raw);child=apply_action(s.state,a,c);cell=dict(index=j,classification='UNKNOWN')
   with runtime.pushed(a):entry=player._tt.probe(runtime.search_key())if runtime.tt_eligible else None
   if child.terminal_status.is_terminal:cell.update(source='terminal',lower=terminal_score(child.terminal_status,root['side'],1),upper=terminal_score(child.terminal_status,root['side'],1))
   elif entry is not None:
    value=-score_from_tt(entry.score,1);cell.update(source='TT',entry_depth=entry.depth,entry_bound=entry.bound.name,root_value=value)
    if entry.depth==2:
     if entry.bound.name=='EXACT':cell.update(lower=value,upper=value)
     elif entry.bound.name=='LOWER':cell['upper']=value
     elif entry.bound.name=='UPPER':cell['lower']=value
   if d.completed_depth==3:
    if cell.get('upper',float('inf'))<d.score:cell['classification']='CERTIFIED_INFERIOR'
    elif cell.get('lower',-float('inf'))==d.score:cell['classification']='CERTIFIED_OPTIMAL'
   cells.append(cell)
  runtime.assert_balanced();row['partial'].append(dict(nodes=nodes,seconds=elapsed,probe_seconds=time.perf_counter()-tick,decision=record_value(d),cells=cells))
 for j,raw in enumerate(root['children']):
  check_stop();child=apply_action(s.state,action_from_dict(raw),c);cell=dict(index=j,known=False,baseline=Unit().evaluate(child)*(1 if child.position.side_to_move==0 else-1))
  if time.perf_counter()-start>=3000:cell['reason']='cost_checkpoint'
  elif child.terminal_status.is_terminal:cell.update(known=True,owner0_target=terminal_score(child.terminal_status,0,0),seconds=0)
  else:
   cs=GameSession(c);cs._state=child;cs._search_history_witnesses=s._search_history_witnesses+(child.position,);player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(cs,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(cs,d);cell.update(known=d.completed_depth==2,owner0_target=d.score*(1 if child.position.side_to_move==0 else-1),seconds=time.perf_counter()-tick,decision=record_value(d))
  if cell['known']:
   target=cell['owner0_target']*(1 if root['side']==0 else-1);target=target-1 if target>=MATE_THRESHOLD else target+1 if target<=-MATE_THRESHOLD else target
   for part in row['partial']:
    if part.get('missing'):continue
    bound=part['cells'][j];bound['reference_root_score']=target
    if 'lower'in bound:assert bound['lower']<=target,(row['root'],nodes,j,'lower',bound,target)
    if 'upper'in bound:assert bound['upper']>=target,(row['root'],nodes,j,'upper',bound,target)
    if bound['classification']=='CERTIFIED_INFERIOR':assert target<part['decision']['score']
    if bound['classification']=='CERTIFIED_OPTIMAL':assert target==part['decision']['score']
  row['children'].append(cell)
 row['known']=bool(row['children'])and all(x['known']for x in row['children']);out['rows'].append(row);write_record(p/'result.json',out)
 print(row['root'],len(row['children']),row['known'],[(x['nodes'],x.get('decision',{}).get('completed_depth'),dict(collections.Counter(a['classification']for a in x['cells'])))for x in row['partial']],flush=True)
out.update(complete=True,seconds=time.perf_counter()-start);write_record(p/'result.json',out);print('complete',out['seconds'],flush=True)

