def order(
    self,
    state: GameState,
    actions: list[Action],
    evaluator: Evaluator,
    depth: int,
    tt_move: Action | None,
    prev_action: Action | None,
    tuning: SearchTuning,
) -> list[Action]:
    n = state.position.board_shape
    side = state.position.side_to_move
    killers = self._killers.get(depth, [])
    counter = self.countermove_for(prev_action) if tuning.use_countermove else None

    def priority(action: Action) -> int:
        if tt_move is not None and action == tt_move:
            return -1000
        if action_is_board(action):
            occupant = state.position.board[square_to_index(action_target_square(action), n)]
            if occupant is not None and occupant.owner != side:
                mover = state.position.board[square_to_index(action_source_square(action), n)]
                return -100 - evaluator.capture_order_value(mover, occupant)
            if action_promotion_target_id(action) is not None:
                return -60
        if counter is not None and action == counter:
            return -40
        if action in killers:
            return -30
        return -min(self.history_value(side, action), 20)

    return sorted(actions, key=lambda a: (priority(a), str(a)))
