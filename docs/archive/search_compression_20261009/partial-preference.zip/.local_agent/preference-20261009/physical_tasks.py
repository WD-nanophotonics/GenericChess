"""Exposed read-only target distinction: frozen Unit-compression constants versus
independent existing ordinary-removal rewards. No task labels fitted, no new
search/task/candidate selection; all four8x8rules, all common slots/zeros,
original equal-slot then17background weighting. Unpromoted same-base focal
replacement keeps other inventory terms fixed. Not generalization or strength.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import combinations
import json,sys,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path('.local_agent/interaction-20261009')))
from prototype import actor_vectors
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.research_record import write_record
p=Path('.local_agent/preference-20261009');q=Path('.local_agent/qfrontier-20261009');plan=json.loads((p/'declaration.json').read_bytes());decl=json.loads((q/'transfer-declaration.json').read_bytes());tasks=json.loads((q/'reply8-task.json').read_bytes());models={n:json.loads((p/(n+'-model.json')).read_bytes()) for n in ('full','partial2048','partial8192')};out=p/'physical-tasks.json';assert not out.exists()
files=[p/(n+'-model.json') for n in models]+[q/'transfer-declaration.json',q/'reply8-task.json'];write_record(p/'physical-task-declaration.json',dict(scope=__doc__,inputs={f.as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in files},methods=list(models)+['generic_v2','semantic_v3','blind'],fit=False,all_rules=True))
rows=[]
for raw,frozen,rules in zip(tasks['rules'],decl['rules'],plan['rules']):
 assert raw['complete'] and raw['seed']==frozen['seed'];c=compile_ruleset_for_execution(ruleset_from_dict(rules));assert c.ruleset_fingerprint==frozen['fingerprint'];actors=actor_vectors(c);types=raw['types'];tables=dict(frozen['prices'])
 for name,m in models.items():
  w=np.zeros(938);globalcols=np.asarray(m['count_columns'])[m['columns']];w[globalcols]=np.asarray(m['weights'])/m['scale'];tables[name]={t:float(actors[t]@w[:66]+actors[t]@w[396:462]) for t in types}
 tables['blind']={t:0 for t in types};chosen={n:[t for t in types if table[t]==max(table[t] for t in types)] for n,table in tables.items()};cell=defaultdict(dict)
 for r in raw['cells']:cell[(r['ply'],r['source'])][r['type']]=r
 assert all(sorted(v)==types for v in cell.values());row=dict(seed=raw['seed'],types=types,tables=tables,chosen=chosen,slots=len(cell),missing=0,summary={})
 for field in ('immediate','task'):
  bg=defaultdict(list)
  for (ply,source),values in cell.items():
   u={t:v[field] for t,v in values.items()};top={n:F(max(u.values()))-sum((F(u[t]) for t in ts),F())/len(ts) for n,ts in chosen.items()};pairs={}
   for n,table in tables.items():
    losses=[]
    for a,b in combinations(types,2):
     pick=[a] if table[a]>table[b] else [b] if table[b]>table[a] else [a,b];losses.append(F(max(u[a],u[b]))-sum((F(u[t]) for t in pick),F())/len(pick))
    pairs[n]=sum(losses,F())/len(losses)
   bg[ply].append((top,pairs))
  assert len(bg)==17
  row['summary'][field]={name:{metric:sum((sum((slot[i][name] for slot in slots),F())/len(slots) for slots in bg.values()),F())/len(bg) for i,metric in enumerate(('top_loss','pair_loss'))} for name in tables}
 rows.append(row)
write_record(out,dict(scope=__doc__,rules=rows,limits='Signed uncalibrated learned coefficients are diagnostic fixed ranks, not adopted prices. Exposed physical tasks never become heldout labels. No numeric leaf/default change; all source records and failure strata retained.'))
print([(r['seed'],r['chosen'],r['summary']) for r in rows])
