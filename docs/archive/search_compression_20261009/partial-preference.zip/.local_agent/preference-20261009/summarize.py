"""Read-only denominator/cost summaries; no refits or search."""
from pathlib import Path
import json, statistics
from collections import Counter
p=Path(__file__).parent
def read(name):return json.loads((p/name).read_bytes())
audit=read('audit.json');data=read('result.json');plan=read('declaration.json')
summary={'scope':__doc__,'full_seconds':sum(g['reference_seconds'] for g in audit['groups']), 'partial':{}}
for nodes in (2048,8192):
 parts=[next(a for a in g['partial'] if a['nodes']==nodes) for g in audit['groups']]
 summary['partial'][str(nodes)]={k:sum(a[k] for a in parts) for k in ('seconds','completed_D3','usable_pair_roots','certified_without_complete_child_reference')}
 summary['partial'][str(nodes)]['classes']=dict(sum((Counter(a['classes']) for a in parts),Counter()))
ordered=read('ordered-reference.json');assert ordered['complete'];summary['ordered_control']=[]
for row in ordered['rows']:
 old=data['rows'][row['index']]['children'];both=[(a,b) for a,b in zip(old,row['children']) if a['known'] and b['known']]
 differences=[(a['index'],a['owner0_target'],b['owner0_target']) for a,b in both if a['owner0_target']!=b['owner0_target']]
 assert not differences,differences
 summary['ordered_control'].append(dict(root=row['root'],children=len(old),old_complete=sum(a['known'] for a in old),ordered_complete=sum(a['known'] for a in row['children']),both_complete=len(both),old_seconds=sum(a.get('seconds',0) for a in old),ordered_seconds=sum(a.get('seconds',0) for a in row['children']),score_differences=differences))
if (p/'callers.json').exists():
 calls=read('callers.json')
 if calls['complete']:
  summary['callers']={}
  for method in ('unit','full','partial2048','partial8192'):
   rows=[r for r in calls['rank_rows'] if r['method']==method]
   summary['callers'][method]=dict(calls=len(rows),seconds=sum(r['seconds'] for r in rows),median_seconds=statistics.median(r['seconds'] for r in rows),groups={g:dict(known=sum(r['regret'] is not None for r in rows if r['group']==g),positive=sum(r['regret'] is not None and r['regret']>0 for r in rows if r['group']==g),regrets=[r['regret'] for r in rows if r['group']==g and r['rep']==0]) for g in ('train','dev','report')})
  sr=calls['search_rows'];summary['matched_search']=dict(calls=len(sr),seconds=sum(r['seconds'] for r in sr),groups={g:dict(known=sum(r['regret'] is not None for r in sr if r['group']==g),positive=sum(r['regret'] is not None and r['regret']>0 for r in sr if r['group']==g)) for g in ('train','dev','report')})
if (p/'tt-priority.json').exists():
 tt=read('tt-priority.json')
 if tt['complete']:
  summary['tt_priority']=[]
  for scale in (500,10000):
   for nodes in (2048,8192):
    cell=dict(scale=scale,nodes=nodes,methods={})
    for method in ('old','structural'):
     rs=[r for r in tt['rows'] if r['capture_scale']==scale and r['nodes']==nodes and r['method']==method]
     cell['methods'][method]=dict(calls=len(rs),seconds=sum(r['seconds'] for r in rs),completed_D3=sum(r['decision']['completed_depth']==3 for r in rs),known=sum(r['regret'] is not None for r in rs),positive=sum(r['regret'] is not None and r['regret']>0 for r in rs),nodes=sum(r['decision']['nodes'] for r in rs))
    summary['tt_priority'].append(cell)
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
