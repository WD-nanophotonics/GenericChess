"""Actual legal-root callers for frozen same-input teacher-source fits.
Two balanced repetitions of Unit/full/partial2048/partial8192 root ranking;
only available fixed fits, all complete/zero/unknown denominators retained.
Unit existing TT/orderD3 at median full rank caller time provides scoped cost
control; original2048/8192search curves remain separately available. Rank scores
are never numeric leaves. No global-batch/actual-caller tie equivalence assumed.
"""
from pathlib import Path
import os
for k in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,statistics
import numpy as np
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path('.local_agent/interaction-20261009')))
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;plan=json.loads((p/'declaration.json').read_bytes());data=json.loads((p/'result.json').read_bytes());fits=json.loads((p/'fit-result.json').read_bytes());models={};compiled=[];setup=[];out=p/'callers.json';assert not out.exists()
for name,result in fits['results'].items():
 if'rows'not in result:continue
 m=json.loads((p/(name+'-model.json')).read_bytes())
 for field in('mean','scale','weights','columns','count_columns'):m[field]=np.asarray(m[field])
 models[name]=m
for rules in plan['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(rules));tick=time.perf_counter();e=InteractionProjection(c);setup.append(dict(seconds=time.perf_counter()-tick,table_bytes=sum(a.nbytes for a in e.board.values())));compiled.append((c,e))
write_record(p/'caller-declaration.json',dict(scope=__doc__,setup=setup,methods=['unit']+list(models),repetitions=2,matched='Existing CoreD3 TT/order20knodes at median full-model caller time, full semantics; no extra seconds assigned only to candidate.'))
rows=[];search=[]
for i,(root,ref)in enumerate(zip(plan['roots'],data['rows'])):
 if not root['children']:continue
 c,e=compiled[root['rule_index']];types=non_anchor_type_ids(c);s=GameSession(c)
 for raw in root['route']:s.submit(action_from_dict(raw))
 ss=1 if root['side']==0 else-1;best=max(ss*x['owner0_target']for x in ref['children'])if ref['known']else None
 for rep in range(2):
  methods=['unit']+list(models);shift=(i+rep)%len(methods)
  for name in methods[shift:]+methods[:shift]:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];tick=time.perf_counter();acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True));assert [action_to_dict(a)for a in acts]==root['children'];children=[apply_action(s.state,a,c)for a in acts];score_tick=time.perf_counter()
   if name=='unit':scores=np.asarray([1000*sum(material_features(ch.position,types,perspective=0).array())for ch in children])
   else:
    m=models[name];x=np.asarray([e.encode(ch.position)[m['count_columns']]for ch in children]);scores=((x[:,m['columns']]-m['mean'])/m['scale'])@m['weights']
   chosen=np.flatnonzero(ss*scores==np.max(ss*scores)).tolist();rows.append(dict(root=ref['root'],group=root['group'],method=name,rep=rep,seconds=time.perf_counter()-tick,scoring_seconds=time.perf_counter()-score_tick,chosen=chosen,regret=None if best is None else float(np.mean([best-ss*ref['children'][j]['owner0_target']for j in chosen]))))
 cost=statistics.median(r['seconds']for r in rows if r['root']==ref['root']and r['method']=='full')
 class Unit:
  def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
  def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
 player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=True,use_ordering=True,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=cost,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);j=next(j for j,a in enumerate(root['children'])if a==action_to_dict(d.action));search.append(dict(root=ref['root'],group=root['group'],limit=cost,seconds=time.perf_counter()-tick,regret=None if best is None else best-ss*ref['children'][j]['owner0_target'],decision=record_value(d)));write_record(out,dict(scope=__doc__,complete=False,rank_rows=rows,search_rows=search));print(ref['root'],cost,flush=True)
write_record(out,dict(scope=__doc__,complete=True,rank_rows=rows,search_rows=search,limits='Original ordering unchanged, full semantics retained. Local time-matched actual cost not a universal fairness guarantee; cold players, warm compiled rules. Numeric rank not a leaf. Actual global/root batch FP choices differ if observed, never overwrite original frozen fit metrics.'))
