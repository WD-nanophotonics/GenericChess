"""Retain denominators/caps; selected-action net is not an oracle or strength."""
from pathlib import Path
import json,collections,statistics
p=Path(__file__).parent
c=json.loads((p/'callers.json').read_bytes());s=json.loads((p/'selected-actions.json').read_bytes())
assert c['complete'] and s['complete']
rows=[]
for cr,sr in zip(c['rules'],s['rules']):
 for q in (0,2):
  for leaf in ('v3','initial_source_capture','finite16_capture'):
   cs=[x for x in cr['calls'] if x['q']==q and x['leaf']==leaf]
   counts=collections.Counter();delta=collections.Counter();changed=0
   for root in sr['roots']:
    values={x['leaf']:x['net'] for x in root['decisions'] if x['q']==q}
    a,b=values[leaf],values['v3']
    delta['UNKNOWN' if a is None or b is None else 'better' if a>b else 'worse' if a<b else 'tie']+=1
    sameply=[x for x in cr['calls'] if x['ply']==root['ply'] and x['q']==q]
    decisions={x['leaf']:x['decision']['action'] for x in sameply}
    changed+=decisions[leaf]!=decisions['v3']
   for x in cs:counts[x['decision']['termination_reason']]+=1
   rows.append(dict(seed=cr['seed'],q=q,leaf=leaf,roots=len(cs),completed=sum(x['complete'] for x in cs),termination=dict(counts),selected_net_vs_v3=dict(delta),changed_choices=changed,seconds=sum(x['seconds'] for x in cs)))
r=dict(scope=__doc__,rows=rows,roots=sum(len(x['roots']) for x in s['rules']),calls=sum(len(x['calls']) for x in c['rules']),selected_transitions=sum(x['transitions'] for row in s['rules'] for x in row['roots']),selected_seconds=s['seconds'])
(p/'analysis.json').write_bytes((json.dumps(r,indent=2)+'\n').encode())
print(json.dumps(r,indent=2))
