"""Semantic type relabel control for frozen finite16 tables, no labels/refit.
Reuse frozen rules, mechanically rename declared type symbols everywhere in the
serialized schema, then recompute raw tables under the same explicit law.
Kernel/H1 consistency is representation evidence, not utility or natural law.
"""
from pathlib import Path
import sys,json,textwrap,hashlib,subprocess
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/finite-law-20261009'))]
from finite_law import collect
from generic_chess.ai.evaluation.semantic import _path_union
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
import numpy as np

p=Path(__file__).parent;out=p/'relabel-control.json';assert not out.exists()
d=json.loads((p/'declaration.json').read_bytes());source=(p/'run.py').read_text()
block=source[source.index(' initial=GameSession(c)'):source.index(" tables['blind']")]
fn='def compute(c):\n types=sorted(t.type_id for t in c.piece_types if not t.is_anchor)\n tables={}\n'+block+'\n return tables\n'
ns=dict(globals());exec(fn,ns);compute=ns['compute'];rows=[]
def rename(raw,mapping):
 if isinstance(raw,str):return mapping.get(raw,raw)
 if isinstance(raw,list):return [rename(x,mapping) for x in raw]
 if isinstance(raw,dict):return {mapping.get(k,k):rename(v,mapping) for k,v in raw.items()}
 return raw
for case in d['rules']:
 original=compile_ruleset_for_execution(ruleset_from_dict(case['rules']))
 mapping={t.type_id:'anonymous_'+str(i) for i,t in enumerate(reversed(original.piece_types))}
 renamed=compile_ruleset_for_execution(ruleset_from_dict(rename(case['rules'],mapping)))
 tables=compute(renamed);checks=0
 for name,table in tables.items():
  for t in case['types']:assert abs(table[mapping[t]]-case['tables'][name][t])<1e-11;checks+=1
 rows.append(dict(seed=case['seed'],checks=checks,renamed_fingerprint=renamed.ruleset_fingerprint))
out.write_bytes((json.dumps(dict(scope=__doc__,rows=rows,checks=sum(r['checks'] for r in rows),horizon=16),indent=2)+'\n').encode());print(rows)
