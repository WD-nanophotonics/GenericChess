from pathlib import Path
import sys,json,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'same-rank.json';assert not out.exists();plan=json.loads((p/'next-projection-declaration.json').read_bytes());d=json.loads((p/'declaration.json').read_bytes());refs=json.loads((p/'frozen-reference.json').read_bytes());m=json.loads(Path('.local_agent/preference-20261009/partial2048-model.json').read_bytes());w=np.zeros(938);w[np.asarray(m['count_columns'])[m['columns']]]=np.asarray(m['weights'])/m['scale'];rows=[]
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);encoder=InteractionProjection(c)
 for ply in range(len(case['route'])+1):
  rp=next((x for x in plan['roots'] if x['seed']==case['seed'] and x['ply']==ply),None)
  if rp:
   owner=s.state.position.side_to_move;sign=1 if owner==0 else -1;children=[];legal={json.dumps(record_value(a),sort_keys=True):a for a in s.legal_actions()}
   for raw in rp['actions']:
    child=apply_action(s.state,legal[json.dumps(raw,sort_keys=True)],c);x=encoder.encode(child.position);full=sign*float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights']);proxy=sign*sum((1 if a.owner==0 else -1)*float(encoder.actors[a.current_type_id]@(w[:66]+w[396:462])) for a in child.position.board if a is not None);terminal=record_value(child.terminal_status)
    children.append(dict(action=raw,full=full,proxy=proxy,terminal=terminal))
   # This carrier cohort has no terminal selected-child priority exception;
   # retain all statuses and reject silently numeric-ranking terminal values.
   assert all(x['terminal']['status']=='ongoing' for x in children), 'terminal requires separate priority, no numeric comparison'
   chosen={name:[i for i,x in enumerate(children) if x[name]==max(v[name] for v in children)] for name in ('full','proxy')};rows.append(dict(seed=case['seed'],ply=ply,children=children,chosen=chosen,changed=chosen['full']!=chosen['proxy']))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
write_record(out,dict(scope=plan,rows=rows,complete=True,changed=sum(r['changed'] for r in rows),limitations='Same direct ranker only; no D2leaf performance inference, fitting, model promotion or strength.'))
print(dict(roots=len(rows),changed=sum(r['changed'] for r in rows)))
