"""Exposed failure diagnosis under matched completed D2, NOT frozen test extension.
All six observed q0-adverse roots plus six earliest q0-tie controls frozen before
new calls. Three old leaf tables, same unit order/hand prices/q0/Core/coldTT.
D2/10seconds each, no node cap; keep every UNKNOWN. Upper estimate6minutes,
interruptible per root; no training/table/horizon/refit. Determine whether
original incomplete D3 comparisons alone explain the selected-action loss.
"""
from pathlib import Path
from dataclasses import replace
import json,sys,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'matched-depth.json';assert not out.exists()
d=json.loads((p/'declaration.json').read_bytes());prices=json.loads((p/'caller-declaration.json').read_bytes());bad=json.loads((p/'attribution.json').read_bytes());old=json.loads((p/'selected-actions.json').read_bytes())
adverse={(r['seed'],r['ply']) for r in bad['rows'] if r['q']==0}
controls=[(r['seed'],x['ply']) for r in old['rules'] for x in r['roots'] if (r['seed'],x['ply']) not in adverse][:6]
selected=adverse|set(controls);write_record(p/'matched-depth-declaration.json',dict(scope=__doc__,adverse=sorted(adverse),controls=controls))
report=dict(scope=__doc__,rows=[],complete=False);start=time.perf_counter();cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for case,pr in zip(d['rules'],prices['profiles']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);profile,_=build_semantic_opportunity_profile(c,cfg);unit=pr['ordering'];anchors={t.type_id for t in c.piece_types if t.is_anchor}
 def count(st,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in st.position.board)+sum(n for t,n in st.position.hands[owner].counts if t not in anchors)
 class FixedOrder:
  def __init__(self,leaf):self.leaf=leaf
  def evaluate(self,st):return self.leaf.evaluate(st)
  def capture_order_value(self,moving,captured):return unit[captured.current_type_id]*10-unit[moving.current_type_id]//10
  def type_value(self,t):return unit[t]
 for ply in range(len(case['route'])+1):
  if (case['seed'],ply) in selected:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;owner=before.position.side_to_move;rr=dict(seed=case['seed'],ply=ply,adverse=(case['seed'],ply) in adverse,arms=[]);report['rows'].append(rr)
   for name,board in pr['leaf_board'].items():
    evaluator=FixedOrder(Evaluator(c,replace(profile,board_value_by_type=board),cfg));player=AlphaBetaPlayer(c,evaluator_override=evaluator,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=2,max_time_seconds=10,max_nodes=None,quiescence_max_depth=0,quiescence_hard_max_depth=0));seconds=time.perf_counter()-t;validate_pv(s,decision);assert before==s.state
    net=None;transitions=0
    if decision.action is not None:
     child=apply_action(before,decision.action,c);transitions+=1;gain=count(before,1-owner)-count(child,1-owner);losses=[]
     for reply in legal_actions(child,c):after=apply_action(child,reply,c);transitions+=1;losses.append(count(child,owner)-count(after,owner))
     net=gain-max([0]+losses)
    rr['arms'].append(dict(leaf=name,decision=record_value(decision),seconds=seconds,net=net,transitions=transitions))
   write_record(out,report);print(case['seed'],ply,round(time.perf_counter()-start,2),flush=True)
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
report.update(complete=True,seconds=time.perf_counter()-start);write_record(out,report)
