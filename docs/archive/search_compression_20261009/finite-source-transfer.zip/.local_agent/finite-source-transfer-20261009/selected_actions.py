"""New-cohort selected-action net diagnostic, not a full oracle or strength.
All68frozen roots/6fixed arms retained. Evaluate union of actually chosen legal
actions plus all legal opponent replies; ordinary board+hand removal net only.
No virtual-stop root optimum or unchosen negative labels. Per-root10sec/10000
transitions checkpoint, preserve UNKNOWN/caps. Expected<12min, no new search.
"""
from pathlib import Path
import json,sys,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'selected-actions.json';assert not out.exists()
d=json.loads((p/'declaration.json').read_bytes());calls=json.loads((p/'callers.json').read_bytes());assert calls['complete']
write_record(p/'selected-declaration.json',dict(scope=__doc__,caller_sha256=hashlib.sha256((p/'callers.json').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
report=dict(scope=__doc__,rules=[],complete=False);start=time.perf_counter()
def key(raw):return json.dumps(raw,sort_keys=True)
class Checkpoint(Exception):pass
for case,caller in zip(d['rules'],calls['rules']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};row=dict(seed=case['seed'],roots=[]);report['rules'].append(row)
 def ordinary(state,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in state.position.board)+sum(n for t,n in state.position.hands[owner].counts if t not in anchors)
 for ply in range(len(case['route'])+1):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;owner=before.position.side_to_move;rr=dict(ply=ply,actions=[],decisions=[],transitions=0);row['roots'].append(rr);t=time.perf_counter()
  arms=[x for x in caller['calls'] if x['ply']==ply];assert len(arms)==6
  chosen={key(x['decision']['action']) for x in arms if x['decision']['action'] is not None};lookup={};legal={key(record_value(a)):a for a in s.legal_actions()}
  def tick():
   rr['transitions']+=1
   if rr['transitions']>10000 or time.perf_counter()-t>10:raise Checkpoint()
  try:
   for k in sorted(chosen):
    child=apply_action(before,legal[k],c);tick();gain=ordinary(before,1-owner)-ordinary(child,1-owner);replies=legal_actions(child,c);losses=[]
    for reply in replies:after=apply_action(child,reply,c);tick();losses.append(ordinary(child,owner)-ordinary(after,owner))
    r=dict(action=record_value(legal[k]),gain=gain,worst_loss=max([0]+losses),net=gain-max([0]+losses),replies=len(replies));lookup[k]=r;rr['actions'].append(r)
  except Checkpoint:rr['failure']='selected-action cost checkpoint'
  for x in arms:
   a=x['decision']['action'];v=lookup.get(key(a));rr['decisions'].append(dict(leaf=x['leaf'],q=x['q'],search_completed=x['complete'],net=None if v is None else v['net']))
  rr['seconds']=time.perf_counter()-t;assert s.state==before
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 row['complete']=True;write_record(out,report);print(case['seed'],sum(x['transitions'] for x in row['roots']),round(time.perf_counter()-start,2),flush=True)
report.update(complete=True,seconds=time.perf_counter()-start);write_record(out,report)
