"""Frozen learned constant proxy is not the full frozen state predictor.
No fitting. Reuse12complete teacher roots and union selected actions only.
Separate mechanical current=base projection, other model state terms, and
median/rounding/clipping deployment; preserve exact affine reconstruction.
"""
from pathlib import Path
import sys,json
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'constant-projection-audit.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());ref=json.loads((p/'frozen-reference.json').read_bytes());m=json.loads(Path('.local_agent/preference-20261009/partial2048-model.json').read_bytes());w=np.zeros(938);selected=np.asarray(m['count_columns'])[m['columns']];w[selected]=np.asarray(m['weights'])/m['scale'];intercept=-float((np.asarray(m['mean'])/m['scale'])@np.asarray(m['weights']));rows=[]
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);encoder=InteractionProjection(c)
 for ply in range(len(case['route'])+1):
  r=next((r for r in ref['rows'] if r['seed']==case['seed'] and r['ply']==ply),None)
  if r:
   raws={json.dumps(a['decision']['action'],sort_keys=True) for a in r['arms']};actions={json.dumps(record_value(a),sort_keys=True):a for a in s.legal_actions()}
   for raw in sorted(raws):
    child=apply_action(s.state,actions[raw],c);x=encoder.encode(child.position);board=float(x[:66]@w[:66]+x[396:462]@w[396:462]);proxy=sum((1 if a.owner==0 else -1)*float(encoder.actors[a.current_type_id]@(w[:66]+w[396:462])) for a in child.position.board if a is not None);correction=sum((1 if a.owner==0 else -1)*float((encoder.actors[a.base_type_id]-encoder.actors[a.current_type_id])@w[396:462]) for a in child.position.board if a is not None);assert abs(board-proxy-correction)<1e-9
    other=float(x@w)-board;original=float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights']);assert abs(original-board-other-intercept)<1e-9
    rows.append(dict(seed=case['seed'],ply=ply,action=json.loads(raw),base_current_mismatches=sum(a is not None and a.current_type_id!=a.base_type_id for a in child.position.board),static_raw_board=proxy,actual_model_board=board,base_correction=correction,hand_promoted_side_terms=other,intercept=intercept,original_model_prediction=original))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
write_record(out,dict(scope=__doc__,rows=rows,checks=len(rows),nonzero_base_correction=sum(abs(x['base_correction'])>1e-9 for x in rows),limitations='This audit neither runs the original predictor in search nor claims its utility. Derived constant/current-board proxy and old common hands omit full model state terms; deploy normalization is another approximation.'))
print(dict(checks=len(rows),nonzero_base_correction=sum(abs(x['base_correction'])>1e-9 for x in rows)))
