"""Prospective finite-source physical reward check; new premise, not a closure rerun.
Four new frozen seeds2110..2113. Compare v2/v3, initial-source capture/total,
and finite16step average capture/total under explicit uniform-other-cell
proposal/accept-or-stay IID kernel. Equal initial ordinary slots, same old
density law; full rule carriers preserved but projection omits drop/transform,
safety/history/opponent control. Neither kernel nor H16 is rule-identified.
All rules/routes/tables frozen before task labels; no fitting/seed replacement.
H1 must reproduce initial candidate. Outcomes change whether this scoped source
candidate merits a later actual-use check; adverse outcomes stop that expansion.
Expected<5min; original per-rule120sec/100000transition checkpoints retained.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from dataclasses import replace
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
import json,sys,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('.local_agent/interaction-20261009')),str(Path('.local_agent/finite-law-20261009'))]
from finite_law import collect
from generic_chess.ai.evaluation.semantic import _path_union
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import write_record
p=Path('.local_agent/finite-source-transfer-20261009');assert not(p/'declaration.json').exists();frozen=[];compiled=[];fixtures=weird_rulesets();models={}
for seed in (202610082110,202610082111,202610082112,202610082113):
 generated=generate_game(GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));base_drop=fixtures[1].semantic_actions[0];base_quiet=fixtures[2].semantic_actions[0]
 drop=replace(base_drop,type_ids=('P',),replace_selector=replace(base_drop.replace_selector,type_ids=('P',)),slot_guards=(RuleSlotGuard(slot_name='temp_right',value=0),));effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id='P')) if e.kind=='set_current_type' else e for e in base_quiet.effects);quiet=replace(base_quiet,type_ids=('X',),target_relation='empty',effects=effects);rules=replace(generated.ruleset,semantic_actions=(drop,quiet));c=compile_ruleset_for_execution(rules);s=GameSession(c);route=[]
 for ply in range(16):
  if s.state.terminal_status.is_terminal:break
  acts=s.legal_actions()
  if not acts:break
  def key(a):
   raw=action_to_dict(a);capture=False
   if hasattr(a,'to_square'):
    piece=s.state.position.board[a.to_square.rank*8+a.to_square.file];capture=piece is not None and piece.owner!=s.state.position.side_to_move
   return (0 if raw.get('pattern_id','').startswith('sem_01_') else 1 if raw.get('pattern_id','').startswith('sem_00_') else 2 if capture else 3,json.dumps(raw,sort_keys=True))
  a=min(acts,key=key);route.append(action_to_dict(a));s.submit(a)
 types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);v2=build_ruleset_profile(c,EvaluationConfig());v3,scope=build_semantic_opportunity_profile(c,EvaluationConfig());tables={n:{t:v.board_value_by_type[t] for t in types} for n,v in [('generic_v2',v2),('semantic_v3',v3)]}
 # Changed-prior candidates frozen before task labels; no task-source fitting.
 initial=GameSession(c).state.position;A=c.board_shape.area;initial_sources=[x.owner*A+i for i,x in enumerate(initial.board) if x and x.current_type_id in types];cfg=EvaluationConfig();tables['initial_source_capture']={};tables['initial_source_total']={};tables['finite16_capture']={};tables['finite16_total']={}
 for t in types:
  edges=collect(c,c.ir,t,cfg)[0];cap=quiet=0.
  for rho,w in zip(cfg.density_points,cfg.density_weights):
   cap+=w*sum(_path_union(ev,rho)*rho/2 for i in initial_sources for ev in edges['target_enemy'][i].values())/len(initial_sources)
   quiet+=w*sum(_path_union(ev,rho)*(1-rho) for i in initial_sources for ev in edges['target_empty'][i].values())/len(initial_sources)
  tables['initial_source_capture'][t]=cap;tables['initial_source_total'][t]=cap+quiet
  finitecap=finitetotal=h1_cap_sum=h1_total_sum=0.
  for rho,w in zip(cfg.density_points,cfg.density_weights):
   kernel=np.zeros((2*A,2*A));capture=np.zeros(2*A);total=np.zeros(2*A)
   for i in range(2*A):
    owner=i//A
    for kind,occupancy in [('target_empty',1-rho),('target_enemy',rho/2)]:
     for target,ev in edges[kind][i].items():
      probability=_path_union(ev,rho)*occupancy
      kernel[i,owner*A+target]+=probability/(A-1)
      total[i]+=probability
      if kind=='target_enemy':capture[i]+=probability
    assert kernel[i].sum()<=1+1e-12
    kernel[i,i]+=1-kernel[i].sum()
   dist=np.zeros(2*A);dist[initial_sources]=1/len(initial_sources)
   h1cap=float(dist@capture);h1total=float(dist@total)
   h1_cap_sum+=w*h1cap;h1_total_sum+=w*h1total
   mean_cap=mean_total=0.
   for step in range(16):
    mean_cap+=float(dist@capture)/16;mean_total+=float(dist@total)/16
    dist=dist@kernel;assert abs(dist.sum()-1)<1e-11 and dist.min()>=-1e-12
   finitecap+=w*mean_cap;finitetotal+=w*mean_total
  assert abs(h1_cap_sum-cap)<1e-11 and abs(h1_total_sum-cap-quiet)<1e-11
  tables['finite16_capture'][t]=finitecap;tables['finite16_total'][t]=finitetotal

 tables['blind']={t:0 for t in types};frozen.append(dict(seed=seed,rules=ruleset_to_dict(rules),route=route,types=types,tables=tables,fingerprint=c.ruleset_fingerprint,v3_exclusions={t:scope['types'][t]['excluded'] for t in types}));compiled.append(c)
write_record(p/'declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),models={n:hashlib.sha256(Path(f'.local_agent/preference-20261009/{n}-model.json').read_bytes()).hexdigest() for n in models},rules=frozen));out=dict(scope=__doc__,complete=False,rules=[])
for case,c in zip(frozen,compiled):
 start=time.perf_counter();s=GameSession(c);engine=semantic_engine_for(c);anchors={t.type_id for t in c.piece_types if t.is_anchor};row=dict(seed=case['seed'],cells=[],backgrounds=[],transitions=0,complete=False);out['rules'].append(row)
 def count(pos,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in pos.board)+sum(n for t,n in pos.hands[owner].counts if t not in anchors)
 try:
  for ply in range(len(case['route'])+1):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];pos=s.state.position;side=pos.side_to_move;slots=[i for i,x in enumerate(pos.board) if x is not None and x.owner==side and x.current_type_id not in anchors];row['backgrounds'].append(dict(ply=ply,side=side,slots=len(slots),terminal=s.state.terminal_status.is_terminal))
   for source in slots:
    for t in case['types']:
     if time.perf_counter()-start>=120 or row['transitions']>=100000:raise RuntimeError('declared cost checkpoint')
     board=list(pos.board);board[source]=Piece(side,t,t,False);cp=replace(pos,board=tuple(board));before=count(cp,1-side);rewards=[]
     for action,binding in engine.iter_legal_action_bindings(cp):
      if action.source!=source:continue
      child=engine._transition(cp,action,binding);rewards.append(before-count(child,1-side));row['transitions']+=1
     row['cells'].append(dict(ply=ply,source=source,type=t,task=max([0]+rewards)))
   if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
  row['complete']=True
 except Exception as exc:row['failure']=dict(kind=type(exc).__name__,message=str(exc))
 row['seconds']=time.perf_counter()-start
 if row['complete']:
  slots=defaultdict(dict)
  for r in row['cells']:slots[(r['ply'],r['source'])][r['type']]=r['task']
  assert all(sorted(u)==case['types'] for u in slots.values());bg=defaultdict(list)
  for (ply,_),u in slots.items():
   losses={}
   for name,table in case['tables'].items():
    top=[t for t in case['types'] if table[t]==max(table.values())];pairs=[]
    for a,b in combinations(case['types'],2):
     selected=[a] if table[a]>table[b] else [b] if table[b]>table[a] else [a,b];pairs.append(F(max(u[a],u[b]))-sum((F(u[t]) for t in selected),F())/len(selected))
    losses[name]=dict(top=F(max(u.values()))-sum((F(u[t]) for t in top),F())/len(top),pair=sum(pairs,F())/len(pairs))
   bg[ply].append(losses)
  row['summary']={n:{k:sum((sum((r[n][k] for r in rs),F())/len(rs) for rs in bg.values()),F())/len(bg) for k in ('top','pair')} for n in case['tables']};row['slots']=len(slots);row['all_zero_slots']=sum(not any(v.values()) for v in slots.values());row['empty_backgrounds']=[b['ply'] for b in row['backgrounds'] if not b['slots']];row['chosen']={n:[t for t in case['types'] if table[t]==max(table.values())] for n,table in case['tables'].items()}
 write_record(p/'result.json',out);print(row['seed'],row['complete'],row['seconds'],row.get('summary'),flush=True)
out['complete']=all(r['complete'] for r in out['rules']);out['limits']='Four finite16source candidates frozen before independent new-rule physical labels, within existing generator/mechanism family, not unknown-rule universe or natural distribution. Complete physical reward excludes anchor/history/response utility; all generated semantics retained in execution. No training, numeric leaf/default or strength claim.';write_record(p/'result.json',out)
