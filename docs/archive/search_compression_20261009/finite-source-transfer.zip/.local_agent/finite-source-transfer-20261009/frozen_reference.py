"""Exposed12root frozen-constant comparison with unrelated Unit D2 teacher.
No fit of these labels; keep old models/coefficients, all original failed calls.
Full state/promotion/drop/aux/history and terminal priority use product reference.
Teacher20sec/100000transition checkpoint per root; incomplete front UNKNOWN,
never certify a partial maximum. Existing three D2 candidates reused; one old
partial2048 count-derived constant table added, common unit ordering/old hands.
Upper planned teacher4min + candidate2min; no large training/extra workers.
"""
from pathlib import Path
from dataclasses import replace
from statistics import median
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009'))]
from prototype import actor_vectors
from test_rectangular_search_override import UnitEvaluator
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig,MAX_STATIC_EVAL
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'frozen-reference.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());old=json.loads((p/'matched-depth.json').read_bytes());prices=json.loads((p/'caller-declaration.json').read_bytes());modelp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(modelp.read_bytes());w=np.zeros(938);w[np.asarray(m['count_columns'])[m['columns']]]=np.asarray(m['weights'])/m['scale'];prepared=[];declaration=[]
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for case,pr in zip(d['rules'],prices['profiles']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg);actors=actor_vectors(c);raw={t:float(a@w[:66]+a@w[396:462]) for t,a in actors.items() if t!='K'};scale=median(raw.values());board={t.type_id:0 if t.is_anchor else max(1,min(MAX_STATIC_EVAL,round(1000*raw[t.type_id]/scale))) if scale>0 else 1 for t in c.piece_types};prepared.append((c,profile,board,pr));declaration.append(dict(seed=case['seed'],raw=raw,median=scale,board=board,root_plies=[r['ply'] for r in old['rows'] if r['seed']==case['seed']]))
write_record(p/'frozen-reference-declaration.json',dict(scope=__doc__,model_sha256=hashlib.sha256(modelp.read_bytes()).hexdigest(),roots=declaration,limits='Teacher20sec/100000transitions per root. Learned callerD2/10sec, common q0. No label-driven changes.'))
original=search.legal_successors;rows=[];start=time.perf_counter()
class Cost(Exception):pass
for case,(c,profile,board,pr) in zip(d['rules'],prepared):
 s=GameSession(c)
 class FixedOrder:
  def __init__(self):self.leaf=Evaluator(c,replace(profile,board_value_by_type=board),cfg)
  def evaluate(self,state):return self.leaf.evaluate(state)
  def capture_order_value(self,moving,captured):return pr['ordering'][captured.current_type_id]*10-pr['ordering'][moving.current_type_id]//10
  def type_value(self,t):return pr['ordering'][t]
 for ply in range(len(case['route'])+1):
  existing=next((r for r in old['rows'] if r['seed']==case['seed'] and r['ply']==ply),None)
  if existing:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;row=dict(seed=case['seed'],ply=ply,adverse=existing['adverse'],teacher=[],complete=False,transitions=0);t=time.perf_counter()
   def check():
    if time.perf_counter()-t>20 or row['transitions']>100000:raise Cost()
   def successors(state,compiled):
    check()
    for a,child in original(state,compiled):row['transitions']+=1;check();yield a,child
   search.legal_successors=successors
   try:
    for action,child in successors(before,c):
     score,_=search.reference_minimax(child,1,UnitEvaluator(),c,ply=1);check();row['teacher'].append(dict(action=record_value(action),score=-score))
    row['complete']=True
   except Cost:row['failure']='Teacher cost checkpoint, partial front is UNKNOWN'
   finally:search.legal_successors=original
   row['teacher_seconds']=time.perf_counter()-t
   player=AlphaBetaPlayer(c,evaluator_override=FixedOrder(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t2=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=2,max_time_seconds=10,max_nodes=None,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,decision);assert before==s.state;row['arms']=[dict(leaf=a['leaf'],decision=a['decision']) for a in existing['arms']]+[dict(leaf='frozen_partial2048',decision=record_value(decision))];row['caller_seconds']=time.perf_counter()-t2
   lookup={json.dumps(x['action'],sort_keys=True):x['score'] for x in row['teacher']};best=max(lookup.values()) if row['complete'] and lookup else None
   for a in row['arms']:
    score=lookup.get(json.dumps(a['decision']['action'],sort_keys=True));a['reference_loss']=None if best is None or score is None else best-score;a['optimal_hit']=None if a['reference_loss'] is None else a['reference_loss']==0
   rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False));print(case['seed'],ply,row['complete'],row['transitions'],round(time.perf_counter()-start,2),flush=True)
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
write_record(out,dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start,limitations='Reference is fixed Unit D2, not true value, exhaustive WDL or strength. Roots selected by old failures; no fitting or generalization claim. Full state does not mean full utility.'))
