"""Read-only relative archive restoration and independent exact record checks.
Run with archive,index,fresh destination. This verifies recorded task arithmetic,
not reproduction of machine timings, independent utility or full oracle truth.
"""
from pathlib import Path,PurePosixPath
from fractions import Fraction as F
from itertools import combinations
import json,sys,zipfile,hashlib,collections
archive,index,destination=map(Path,sys.argv[1:4]);assert not destination.exists()
spec=json.loads(index.read_bytes());assert hashlib.sha256(archive.read_bytes()).hexdigest()==spec['archive_sha256']
destination.mkdir(parents=True);root=destination.resolve();verified=0
with zipfile.ZipFile(archive) as z:
 for item in spec['members']:
  name=item['path'];rel=PurePosixPath(name);assert not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
  target=(root/name).resolve();assert target.is_relative_to(root)
  data=z.read(name);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);verified+=1
p=root/'.local_agent/finite-source-transfer-20261009';fractions=selected_pairs=0
if p.exists():
 d=json.loads((p/'declaration.json').read_bytes());r=json.loads((p/'result.json').read_bytes());s=json.loads((p/'selected-actions.json').read_bytes())
 for case,result in zip(d['rules'],r['rules']):
  slots=collections.defaultdict(dict)
  for cell in result['cells']:slots[(cell['ply'],cell['source'])][cell['type']]=cell['task']
  for method,table in case['tables'].items():
   bg=collections.defaultdict(list)
   for (ply,source),reward in slots.items():
    top=[t for t in case['types'] if table[t]==max(table.values())];toploss=F(max(reward.values()))-sum((F(reward[t]) for t in top),F())/len(top)
    pairloss=[]
    for a,b in combinations(case['types'],2):
     chosen=[a] if table[a]>table[b] else [b] if table[b]>table[a] else [a,b]
     pairloss.append(F(max(reward[a],reward[b]))-sum((F(reward[t]) for t in chosen),F())/len(chosen))
    bg[ply].append((toploss,sum(pairloss,F())/len(pairloss)))
   for k,label in enumerate(('top','pair')):
    actual=sum((sum((v[k] for v in rows),F())/len(rows) for rows in bg.values()),F())/len(bg)
    assert str(actual)==result['summary'][method][label];fractions+=1
 for row in s['rules']:
  for rr in row['roots']:
   for action in rr['actions']:assert action['net']==action['gain']-action['worst_loss']
   assert len(rr['decisions'])==6;selected_pairs+=6
reference_arms=0
if (p/'frozen-reference.json').exists():
 ref=json.loads((p/'frozen-reference.json').read_bytes())
 for row in ref['rows']:
  assert row['complete'];lookup={json.dumps(x['action'],sort_keys=True):x['score'] for x in row['teacher']};best=max(lookup.values())
  for arm in row['arms']:
   actual=best-lookup[json.dumps(arm['decision']['action'],sort_keys=True)];assert actual==arm['reference_loss'];assert arm['optimal_hit']==(actual==0);reference_arms+=1
print(json.dumps(dict(relative_members=verified,exact_fractions=fractions,selected_arm_records=selected_pairs,reference_arm_arithmetic=reference_arms,root_containment=True,raw_hashes=True)))
