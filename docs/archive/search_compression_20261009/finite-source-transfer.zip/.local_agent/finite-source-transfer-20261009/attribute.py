"""Explain retained adverse selected actions; no refit or unchosen oracle."""
from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import record_value
p=Path(__file__).parent;d=json.loads((p/'declaration.json').read_bytes());calls=json.loads((p/'callers.json').read_bytes());sel=json.loads((p/'selected-actions.json').read_bytes());prices=json.loads((p/'caller-declaration.json').read_bytes())
rows=[];transitions=0
def key(x):return json.dumps(x,sort_keys=True)
for case,cr,sr,pr in zip(d['rules'],calls['rules'],sel['rules'],prices['profiles']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);anchors={t.type_id for t in c.piece_types if t.is_anchor}
 def ordinary(st,owner):return sum(x is not None and x.owner==owner and x.current_type_id not in anchors for x in st.position.board)+sum(n for t,n in st.position.hands[owner].counts if t not in anchors)
 for rr in sr['roots']:
  before=s.state;owner=before.position.side_to_move
  for q in (0,2):
   net={x['leaf']:x['net'] for x in rr['decisions'] if x['q']==q};baseline=net['v3']
   adverse=[leaf for leaf,n in net.items() if n is not None and baseline is not None and n<baseline]
   if adverse:
    selections={x['leaf']:x for x in cr['calls'] if x['ply']==rr['ply'] and x['q']==q}
    r=dict(seed=case['seed'],ply=rr['ply'],q=q,arms=[])
    for leaf in ['v3']+adverse:
     call=selections[leaf];raw=call['decision']['action'];a=next(a for a in s.legal_actions() if key(record_value(a))==key(raw));child=apply_action(before,a,c);transitions+=1
     gain=ordinary(before,1-owner)-ordinary(child,1-owner);replies=[]
     for reply in legal_actions(child,c):
      after=apply_action(child,reply,c);transitions+=1;loss=ordinary(child,owner)-ordinary(after,owner);replies.append((loss,record_value(reply)))
     worst=max([0]+[x[0] for x in replies]);assert gain-worst==net[leaf]
     r['arms'].append(dict(leaf=leaf,action=raw,gain=gain,worst_ordinary_loss=worst,net=net[leaf],worst_reply=next((a for n,a in replies if n==worst),None),completed_depth=call['decision']['completed_depth'],stop=call['decision']['termination_reason'],leaf_board=pr['leaf_board'][leaf],search_score=call['decision']['score']))
    rows.append(r)
  if rr['ply']<len(case['route']):s.submit(action_from_dict(case['route'][rr['ply']]))
r=dict(scope=__doc__,rows=rows,root_q_pairs=len(rows),transitions=transitions,limitations='Selected actions only; own/enemy ordinary count is a different target from static price score. Capped decisions do not establish full-depth search or strength. No coefficient/horizon change.')
(p/'attribution.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(dict(root_q_pairs=len(rows),transitions=transitions,examples=rows[:1]),indent=2))
