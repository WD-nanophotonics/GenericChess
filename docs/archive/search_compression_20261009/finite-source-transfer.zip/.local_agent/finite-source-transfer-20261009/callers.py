"""Scoped leaf-only numerical finite16-source interface/cost comparison.
All68frozen actual route roots,3leafs(v3,initial capture,finite16 capture)xq0/q2.
Cold TT/Core, D3,2048nodes/2seconds; q2hard8, fixed unit ordering for all.
Dynamics disabled; HAND prices identical oldv3 across all arms. Source board
scores receive existing median1000/rounding/clipping; raw task selectors stay
unchanged. Root/history/state preserved; replay every PV. Choices are sensitivity,
not strength or new price validation. No new teacher/refit/model selection.
Declared upper bound408callsx2seconds~=14min plus preparation/replay, under1hour.
Useful outcomes: caps/overhead/PV errors determine whether this simple candidate
is feasible as a future scoped comparator; existing task gains cannot prove it.
"""
from pathlib import Path
from dataclasses import replace
from statistics import median
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig,MAX_STATIC_EVAL
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'callers.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);prepared=[];frozen=[]
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,scope=build_semantic_opportunity_profile(c,cfg);profiles={'v3':profile};unit={t.type_id:0 if t.is_anchor else 1000 for t in c.piece_types}
 for name in ['initial_source_capture','finite16_capture']:
  raw=case['tables'][name];scale=median(raw.values());board={t.type_id:0 if t.is_anchor else max(1,min(MAX_STATIC_EVAL,round(1000*raw[t.type_id]/scale))) if scale>0 else 1 for t in c.piece_types};profiles[name]=replace(profile,board_value_by_type=board)
 prepared.append((c,profiles,unit));frozen.append(dict(seed=case['seed'],leaf_board={n:dict(pr.board_value_by_type) for n,pr in profiles.items()},shared_hand=dict(profile.hand_value_by_base_type),ordering=unit))
write_record(p/'caller-declaration.json',dict(scope=__doc__,input_sha256=hashlib.sha256((p/'declaration.json').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),profiles=frozen))
report=dict(scope=__doc__,rules=[],complete=False);allstart=time.perf_counter()
for case,(c,profiles,unit) in zip(d['rules'],prepared):
 s=GameSession(c);row=dict(seed=case['seed'],calls=[],roots=0,complete=False);report['rules'].append(row)
 class FixedOrder:
  def __init__(self,leaf):self.leaf=leaf;self.scorings=0;self.order_queries=0
  def evaluate(self,state):self.scorings+=1;return self.leaf.evaluate(state)
  def capture_order_value(self,moving,captured):self.order_queries+=1;return unit[captured.current_type_id]*10-unit[moving.current_type_id]//10
  def type_value(self,t):self.order_queries+=1;return unit[t]
 for ply in range(len(case['route'])+1):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;row['roots']+=1
  names=list(profiles) if ply%2==0 else list(reversed(profiles))
  for name in names:
   for q in ([0,2] if ply%2==0 else [2,0]):
    ev=FixedOrder(Evaluator(c,profiles[name],cfg));player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False));start=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=2048,max_time_seconds=2,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0));seconds=time.perf_counter()-start;validate_pv(s,decision);assert s.state==before
    row['calls'].append(dict(ply=ply,leaf=name,q=q,complete=decision.completed_depth==3,seconds=seconds,scorings=ev.scorings,ordering_queries=ev.order_queries,decision=record_value(decision)))
  write_record(out,report)
  print(case['seed'],ply,'calls',len(row['calls']),'elapsed',round(time.perf_counter()-allstart,2),flush=True)
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 row['complete']=True;write_record(out,report)
report['complete']=True;report['seconds']=time.perf_counter()-allstart;write_record(out,report)
