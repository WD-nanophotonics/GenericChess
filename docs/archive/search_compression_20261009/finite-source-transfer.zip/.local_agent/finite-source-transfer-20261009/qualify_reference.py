"""Qualify Unit D2 full front; bounded D3 pilot addresses beyond-depth uncertainty.
No coefficient fit. First adverse2111ply0 and first nonterminal control2110ply0
preselected, D3teacher40seconds/300000transitions each; partial front UNKNOWN.
Opposite horizon outcomes affect whether short target stability merits a new
target, not whether to refit source horizon. All original D2 tables unchanged.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from test_rectangular_search_override import UnitEvaluator
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'reference-qualification.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());refs=json.loads((p/'frozen-reference.json').read_bytes());rows=[];pilots=[]
class Cost(Exception):pass
original=search.legal_successors
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for ply in range(len(case['route'])+1):
  ref=next((r for r in refs['rows'] if r['seed']==case['seed'] and r['ply']==ply),None)
  if ref:
   before=s.state;player=AlphaBetaPlayer(c,evaluator_override=UnitEvaluator(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=None,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,decision);assert s.state==before
   best=max(x['score'] for x in ref['teacher']);lookup={json.dumps(x['action'],sort_keys=True):x['score'] for x in ref['teacher']};assert decision.completed_depth==2 and decision.score==best and lookup[json.dumps(record_value(decision.action),sort_keys=True)]==best;rows.append(dict(seed=case['seed'],ply=ply,decision=record_value(decision),teacher_best=best))
   if ply==0:
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];r=dict(seed=case['seed'],ply=ply,teacher=[],transitions=0,complete=False);t=time.perf_counter()
    def successors(state,compiled):
     if time.perf_counter()-t>40 or r['transitions']>300000:raise Cost()
     for a,child in original(state,compiled):
      r['transitions']+=1
      if time.perf_counter()-t>40 or r['transitions']>300000:raise Cost()
      yield a,child
    search.legal_successors=successors
    try:
     for a,child in successors(before,c):
      score,_=search.reference_minimax(child,2,UnitEvaluator(),c,ply=1);r['teacher'].append(dict(action=record_value(a),score=-score))
     r['complete']=True
    except Cost:r['failure']='D3cost checkpoint; partial optimum UNKNOWN'
    finally:search.legal_successors=original
    r['seconds']=time.perf_counter()-t;pilots.append(r);print(case['seed'],'D3',r['complete'],r['transitions'],round(r['seconds'],2),flush=True)
   write_record(out,dict(scope=__doc__,unit_d2_callers=rows,d3_pilots=pilots,complete=False))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
write_record(out,dict(scope=__doc__,unit_d2_callers=rows,d3_pilots=pilots,complete=True))
