"""One existing-interface transfer check, not another game/strength assay.
Two existing cannon rectangles7x5/9x10 at lexical ply0/2/4, all legal handle
children equal public complete states; Unit fixed64 original vs handle frontier
choices/value/resolution/work must agree. Actual history remains included.
Decision: a mismatch would block widening this prototype beyond square hybrids.
Expected<2min;300sec interruptible checkpoint. Execute after timed games, never
concurrently. No new product API, task definition, fit or Native claim.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/root-order-transfer-20261010')),str(Path('.local_agent/frontier-time-20261010'))]
from frontier import choose
from frontier_handles import choose as handle_choose
from test_rectangular_search_override import rectangular_cannon,UnitEvaluator
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from generic_chess.core.lazy_transitions import legal_successor_handles,materialize_legal_successor
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert json.loads((p/'games.json').read_bytes())['complete']
out=p/'rectangle-transfer.json';assert not out.exists()
write_record(p/'rectangle-transfer-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),shapes=[[7,5],[9,10]],plies=[0,2,4],calls=12,successors=64))
rows=[];pairs=0;tick=time.perf_counter()
for shape in((7,5),(9,10)):
 rules=rectangular_cannon(*shape);c=compile_ruleset_for_execution(rules);s=GameSession(c)
 for ply in range(5):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-tick<300
  if s.state.terminal_status.is_terminal:break
  if ply in(0,2,4):
   for h in legal_successor_handles(s.state,c):assert materialize_legal_successor(s.state,h,c)[0]==apply_action(s.state,h.action,c);pairs+=1
   a,x=choose(s.state,c,UnitEvaluator(),64);b,y=handle_choose(s.state,c,UnitEvaluator(),64)
   same=a==b and {k:v for k,v in x.items()if k!='seconds'}=={k:v for k,v in y.items()if k!='seconds'}
   rows.append(dict(shape=shape,ply=ply,rules=ruleset_to_dict(rules),state=record_value(s.state),original_action=action_to_dict(a),handle_action=action_to_dict(b),original=x,handles=y,exact=same))
  if ply<4:s.submit(min(s.legal_actions(),key=str))
write_record(out,dict(scope=__doc__,rows=rows,full_child_pairs=pairs,complete=True,seconds=time.perf_counter()-tick))
print('roots',len(rows),'matches',sum(r['exact']for r in rows),'full_child_pairs',pairs,'seconds',time.perf_counter()-tick)
