"""Archive the predeclared handle-time pilot, preserving all generated outcomes.
Full-state replay is recovery verification, not independent playing validation.
Agent-generated sources/rules/results only; no transport or account records.
"""
from pathlib import Path
import sys,json,hashlib,zipfile
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
p=Path(__file__).resolve().parent.relative_to(Path.cwd().resolve())
archive=Path('docs/archive/search_compression_20261009/handle-time-20261010.zip')
assert not archive.exists()
d=json.loads((p/'games.json').read_bytes());assert d['complete']and len(d['rows'])==16
files=sorted([*p.glob('*.py'),*p.glob('*.json')]);members=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for f in files:
  raw=f.read_bytes();name=f.as_posix();assert '/slack/'not in name
  z.writestr(name,raw);members.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
 cases={r['seed']:r for r in json.loads(z.read(p.as_posix()+'/prospective-rules.json'))['rules']};states=0
 for game in json.loads(z.read(p.as_posix()+'/games.json'))['rows']:
  case=cases[game['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
  for a in case['route'][:4]:s.submit(action_from_dict(a))
  assert record_value(s.state)==game['initial']
  for step in game['steps']:
   s.submit(action_from_dict(step['action']));assert record_value(s.state)==step['state'];states+=1
  assert record_value(s.state.terminal_status)==game['terminal']
prior=Path('docs/archive/search_compression_20261009/completion-search-20261010.zip');assert prior.exists()
index=archive.with_name(archive.stem+'-index.json')
write_record(index,dict(scope=__doc__,base_commit='f95674cee40e1554c7d438e928475c71869925a1',archive=archive.as_posix(),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=members,prerequisites=[dict(path=prior.as_posix(),sha256=hashlib.sha256(prior.read_bytes()).hexdigest())],verification=dict(member_hashes=len(members),full_game_states=states),qualifications=['No independent selected-reply audit for this batch; terminal events alone do not identify avoidable errors','New rule seeds mean previous public-apply games are not paired implementation controls','Common target is not strict latency; report measured overruns and unlike work units','No product/default/training change']))
write_record(Path('docs/research/data/handle_time_20261010.json'),dict(scope=__doc__,archive_index=index.as_posix(),analysis=json.loads((p/'analysis.json').read_bytes()),full_state_replay=states))
print(len(members),archive.stat().st_size,states)
