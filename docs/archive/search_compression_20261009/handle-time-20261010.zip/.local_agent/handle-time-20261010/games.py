"""Prospective16 one-second EXISTING-HANDLE algorithm games on four new frozen2168-2171 rules.
Two leaf prices Unit/v3; same leaf BOTH sides, alpha-beta versus frontier in
both owner assignments. Opening4,64ply external horizon not draw, full Core
history/promotion/drop/auxiliary semantics. Alpha-beta cold maxD8/q0/hard8,
one-second target with no node cap. Frontier separate resolution/heuristics,
one-second target checked between public operations; no TT, no fabricated draws.
Report actual elapsed/overruns and work units separately, not equal-node claims.
Decision: does completion-aware search offer useful affordable behavior beyond
exposed-parent separation? Not Elo/default proof, training or old-cap extension.
Fixed premise change: existing verified handles remove redundant semantic work; prior adverse wall-clock outcomes stay intact. No game or success criterion selection. Expected<35min;2700sec interruptible checkpoint. Preserve all adverse/censored
games, empty frontier and raw costs. No post-result rules/filter/budget changes.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path(__file__).parent)]
from frontier_time import choose
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'games.json';assert not out.exists();assert json.loads((Path('.local_agent/frontier-time-20261010')/'preflight.json').read_bytes())['passed'];d=json.loads((p/'prospective-rules.json').read_bytes());cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
write_record(p/'declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(),frontier_source=Path(p/'frontier_time.py').read_text(),rules_sha256=hashlib.sha256((p/'prospective-rules.json').read_bytes()).hexdigest(),arms=['unit','v3'],assignments=[['ab','frontier'],['frontier','ab']],games=16,seconds=1.0,max_plies=64))
rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg)
 for kind in ('unit','v3'):
  class Leaf(UnitEvaluator):
   def __init__(self):self.ev=Evaluator(c,profile,cfg)
   def evaluate(self,state):return super().evaluate(state)if kind=='unit'else self.ev.evaluate(state)
  for methods in (('ab','frontier'),('frontier','ab')):
   s=GameSession(c)
   for a in case['route'][:4]:s.submit(action_from_dict(a))
   leaf=Leaf();pl=AlphaBetaPlayer(c,evaluator_override=leaf,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));row=dict(seed=case['seed'],leaf=kind,methods=methods,initial=record_value(s.state),steps=[],complete=False,abort=None);rows.append(row);tick=time.perf_counter()
   for ply in range(64):
    if s.state.terminal_status.is_terminal:break
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<2700
    before=s.state;side=before.position.side_to_move;method=methods[side];call_start=time.perf_counter()
    if method=='frontier':action,stats=choose(before,c,leaf,1000000,1.0)
    else:
     pl._tt.clear();decision=pl.choose_action(s,SearchLimits(max_depth=8,max_time_seconds=1.0,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,decision);action=decision.action;stats=record_value(decision)
    seconds=time.perf_counter()-call_start;assert s.state==before
    if action is None:row['abort']='empty_frontier_or_decision';break
    assert action in s.legal_actions();s.submit(action);row['steps'].append(dict(ply=ply,side=side,method=method,seconds=seconds,stats=stats,action=action_to_dict(action),state=record_value(s.state)))
    if ply%8==0:write_record(out,dict(scope=__doc__,rows=rows,complete=False,seconds=time.perf_counter()-start))
   row.update(complete=True,seconds=time.perf_counter()-tick,terminal=record_value(s.state.terminal_status),classification='TERMINAL'if s.state.terminal_status.is_terminal else 'CENSORED');write_record(out,dict(scope=__doc__,rows=rows,complete=False,seconds=time.perf_counter()-start));print(case['seed'],kind,methods,len(row['steps']),row['terminal'],round(row['seconds'],3),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
