"""Describe all predeclared16 handle-time games; unlike-work counters and time overruns remain separate. Ongoing64 is not draw; aborts are unknown. New rules differ from the earlier public-apply batch, so its win count is not a paired implementation-speed ablation."""
from pathlib import Path
import json,collections,statistics,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'games.json').read_bytes());assert d['complete']and len(d['rows'])==16
def summarize(d):
 outcomes=collections.Counter();events=collections.Counter();methods={};cells=[]
 for r in d['rows']:
  t=r['terminal'];events[t['status']]+=1
  if r['abort']is not None:label='technical_unknown'
  elif t['status']=='ongoing':assert len(r['steps'])==64;label='ongoing64'
  elif t['status']=='no_contest':label='restart_unsupported'
  elif t['winner']is None:label='rule_draw'
  else:label=r['methods'][t['winner']]+'_win'
  outcomes[label]+=1;cells.append(dict(seed=r['seed'],leaf=r['leaf'],methods=r['methods'],plies=len(r['steps']),terminal=t,label=label,seconds=r['seconds']))
 for method in('ab','frontier'):
  ss=[s for r in d['rows']for s in r['steps']if s['method']==method];methods[method]=dict(calls=len(ss),call_seconds=sum(s['seconds']for s in ss),median_seconds=statistics.median(s['seconds']for s in ss),max_seconds=max(s['seconds']for s in ss),above1p05=sum(s['seconds']>1.05 for s in ss),work_units='visited alpha-beta nodes'if method=='ab'else'materialized Core successors',work=sum(s['stats']['nodes']if method=='ab'else s['stats']['transitions']for s in ss),completed_depth_counts=dict(collections.Counter(s['stats']['completed_depth']for s in ss))if method=='ab'else None,root_resolution_counts=dict(collections.Counter(str(s['stats'].get('root_outcome',s['stats'].get('outcome')))for s in ss))if method=='frontier'else None)
 signatures=collections.Counter(json.dumps([s['action']for s in r['steps']],sort_keys=True)for r in d['rows'])
 return dict(seconds=d['seconds'],plies=sum(len(r['steps'])for r in d['rows']),outcomes=dict(outcomes),events=dict(events),methods=methods,cells=cells,distinct_action_trajectories=len(signatures),duplicate_multiplicities=sorted(signatures.values()))
write_record(p/'analysis.json',dict(scope=__doc__,summary=summarize(d),no_default=True,no_exposed_fitting=True))
print(json.dumps(summarize(d),ensure_ascii=False))
