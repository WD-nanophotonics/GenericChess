"""Describe ALL actual resolutions against already saved cold Core calls
at identical full-state/leaf roots across swapped owners. No additional search,
outcome selection, label refit or missing-match inference. Terminal versus
nonterminal selected child and current-mover outcome remain distinct.
"""
from pathlib import Path
import sys,json,hashlib,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
from generic_chess.ai.evaluation.config import MATE_THRESHOLD
p=Path(__file__).parent;d=json.loads((p/'games.json').read_bytes());assert d['complete'];index=collections.defaultdict(list);resolved=[]
def key(g,state):return hashlib.sha256(json.dumps([g['seed'],g['leaf'],state],sort_keys=True,separators=(',',':')).encode()).hexdigest()
for g in d['rows']:
 before=g['initial']
 for st in g['steps']:
  k=key(g,before)
  if st['method']=='ab':index[k].append(dict(seed=g['seed'],leaf=g['leaf'],methods=g['methods'],ply=st['ply'],stats=st['stats'],action=st['action'],caller_seconds=st['seconds']))
  elif st['stats']['route']=='resolved_prepass':
   out=st['stats']['prepass'].get('root_outcome',st['stats']['prepass'].get('outcome'));mover_out=out*(1 if st['side']==0 else -1)
   resolved.append(dict(key=k,seed=g['seed'],leaf=g['leaf'],methods=g['methods'],ply=st['ply'],side=st['side'],owner0_outcome=out,mover_outcome=mover_out,selected_child_terminal=st['state']['terminal_status'],selected_action=st['action'],prepass_transitions=st['stats']['prepass']['transitions'],prepass_caller_seconds=st['stats']['prepass_caller_seconds']))
  before=st['state']
for r in resolved:
 r['saved_core_matches']=index[r['key']]
 for m in r['saved_core_matches']:
  score=m['stats']['score'];m['same_action']=m['action']==r['selected_action'];m['mate_range']=abs(score)>=MATE_THRESHOLD;m['same_mover_mate_sign']=m['mate_range']and((1 if score>0 else -1)==r['mover_outcome'])
r=dict(scope=__doc__,resolutions=len(resolved),selected_terminal=sum(x['selected_child_terminal']['status']!='ongoing'for x in resolved),nonterminal_mover_win=sum(x['selected_child_terminal']['status']=='ongoing'and x['mover_outcome']==1 for x in resolved),nonterminal_mover_loss=sum(x['selected_child_terminal']['status']=='ongoing'and x['mover_outcome']==-1 for x in resolved),matched_resolution_roots=sum(bool(x['saved_core_matches'])for x in resolved),rows=resolved,complete=True)
write_record(p/'saved-resolution-match.json',r);print(json.dumps({k:v for k,v in r.items()if k not in('rows','scope')}));print([(x['seed'],x['leaf'],x['ply'],x['mover_outcome'],[(m['stats']['completed_depth'],m['stats']['score'],m['same_mover_mate_sign'])for m in x['saved_core_matches']])for x in resolved])
