"""Research-only fixed allocation, no installed engine changes.
Prepass root resolution has authority only from full-state actual terminals.
Unknown prepass estimates never alter Core ordering, TT or evaluator.
"""
import time
from frontier import choose
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
from scripts.unfamiliar_search import validate_pv

def choose_combined(session,compiled,evaluator,player,total=2.0):
 started=time.perf_counter();before=session.state
 action,pre=choose(before,compiled,evaluator,512,min(.2,total))
 elapsed=time.perf_counter()-started
 remaining=max(0.0,total-elapsed)
 outcome=pre.get('root_outcome',pre.get('outcome'))
 stats=dict(prepass=pre,prepass_caller_seconds=elapsed,core_allowance_seconds=remaining,core=None)
 if outcome is not None:
  stats['route']='resolved_prepass'
 elif remaining>0:
  player._tt.clear()
  decision=player.choose_action(session,SearchLimits(max_depth=6,max_time_seconds=remaining,quiescence_max_depth=0,quiescence_hard_max_depth=8))
  validate_pv(session,decision);action=decision.action;stats['core']=record_value(decision);stats['route']='residual_core'
 else:
  stats['route']='budget_exhausted_prepass_fallback'
 assert session.state==before
 stats['caller_seconds']=time.perf_counter()-started
 return action,stats
