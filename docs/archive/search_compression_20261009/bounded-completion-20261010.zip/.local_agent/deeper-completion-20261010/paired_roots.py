"""Fixed every eighth actual parent, selected before outcomes. Cold paired calls
separate allocation opportunity cost from different game trajectories. Same full
history cache only, both results retained, no fitting or whole-root certification.
Expected<20min,3000sec cost checkpoint; all selected-child replies only local
immediate terminal witnesses, not avoidability/WDL/Elo. Same total2sec budget.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path(__file__).parent)]
from combined import choose_combined
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'paired-roots.json';assert not out.exists();d=json.loads((p/'games.json').read_bytes());assert d['complete'];cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
write_record(p/'paired-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(encoding='utf-8'),input_sha256=hashlib.sha256((p/'games.json').read_bytes()).hexdigest(),selection='ply%8==0, all trajectories, cache identical full history and leaf only',max_depth=6,seconds=2.0))
rows=[];cache={};start=time.perf_counter();complete=True
for g in d['rows']:
 case=cases[g['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg)
 class Leaf(UnitEvaluator):
  def __init__(self):self.ev=Evaluator(c,profile,cfg)
  def evaluate(self,st):return super().evaluate(st)if g['leaf']=='unit'else self.ev.evaluate(st)
 leaf=Leaf();player=AlphaBetaPlayer(c,evaluator_override=leaf,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));s=GameSession(c)
 for raw in case['route'][:4]:s.submit(action_from_dict(raw))
 for st in g['steps']:
  if st['ply']%8==0:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
   if time.perf_counter()-start>3000:complete=False;break
   root=record_value(s.state);key=hashlib.sha256(json.dumps([g['seed'],g['leaf'],root],sort_keys=True,separators=(',',':')).encode()).hexdigest()
   if key not in cache:
    pair=[];before=s.state
    order=('ab','combined')if len(cache)%2==0 else('combined','ab')
    for method in order:
     tick=time.perf_counter()
     if method=='combined':a,stats=choose_combined(s,c,leaf,player,2.0)
     else:
      player._tt.clear();decision=player.choose_action(s,SearchLimits(max_depth=6,max_time_seconds=2.0,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,decision);a=decision.action;stats=record_value(decision)
     call_seconds=time.perf_counter()-tick;assert s.state==before;assert a in s.legal_actions()
     child=apply_action(s.state,a,c);w=[];replies=0;tick=time.perf_counter()
     if not child.terminal_status.is_terminal:
      for reply in legal_actions(child,c):
       nxt=apply_action(child,reply,c);replies+=1
       if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-before.position.side_to_move:w.append(dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status)))
     pair.append(dict(method=method,action=action_to_dict(a),stats=stats,caller_seconds=call_seconds,child=record_value(child),replies=replies,witnesses=w,audit_seconds=time.perf_counter()-tick))
    pair.sort(key=lambda r:0 if r['method']=='ab'else 1)
    cache[key]=dict(seed=g['seed'],leaf=g['leaf'],root=root,call_order=order,choices=pair)
   rows.append(dict(seed=g['seed'],leaf=g['leaf'],methods=g['methods'],ply=st['ply'],key=key));write_record(out,dict(scope=__doc__,rows=rows,parents=cache,complete=False,seconds=time.perf_counter()-start))
  s.submit(action_from_dict(st['action']));assert record_value(s.state)==st['state']
 if not complete:break
 print(g['seed'],g['leaf'],g['methods'],'rows',len(rows),'unique',len(cache),'seconds',round(time.perf_counter()-start,2),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,parents=cache,complete=complete,seconds=time.perf_counter()-start))
