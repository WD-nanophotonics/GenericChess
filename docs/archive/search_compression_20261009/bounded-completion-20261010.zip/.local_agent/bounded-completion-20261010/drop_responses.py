"""Exposed response-support diagnostic, no score/fit/default. Ask which actual
legal response distinguishes the same checking drop on safe/adverse children.
Use all five saved children and same common A[5,7] drop, all full histories.
Measure streamed first response and full actual responses separately; absence of
responses relies on Core terminal authority, never check counts alone.
Expected<1min; run after timed jobs so extraction cannot contaminate timings.
"""
from pathlib import Path
import sys,json,time,hashlib,collections
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.core.lazy_transitions import iter_legal_successor_handles,materialize_legal_successor
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'drop-responses.json';assert not out.exists();old=Path('.local_agent/hand-discount-20261010');src=Path('.local_agent/completion-ablation-20261010/drop-service.json');data=json.loads(src.read_bytes());game=next(g for g in json.loads((old/'games.json').read_bytes())['rows']if g['seed']==202610082151 and g['policies']==['unit','v3']);case=next(c for c in json.loads((old/'prospective-rules.json').read_bytes())['rules']if c['seed']==game['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for raw in case['route'][:4]:s.submit(action_from_dict(raw))
for st in game['steps'][:3]:s.submit(action_from_dict(st['action']))
rows=[];start=time.perf_counter()
for r in data['rows']:
 child=apply_action(s.state,action_from_dict(r['root_action']),c);assert record_value(child)==r['child'];drop=next(d['action']for d in r['drops']if d['action']['base_type_id']=='A'and d['action']['to']==[5,7]);tick=time.perf_counter();nxt=apply_action(child,action_from_dict(drop),c);drop_seconds=time.perf_counter()-tick;tick=time.perf_counter();iterator=iter_legal_successor_handles(nxt,c);first=next(iterator,None);first_seconds=time.perf_counter()-tick;handles=[]if first is None else[first];handles.extend(iterator);responses=[]
 for h in handles:
  end=materialize_legal_successor(nxt,h,c)[0];responses.append(dict(action=action_to_dict(h.action),state=record_value(end),terminal=record_value(end.terminal_status)))
 if nxt.terminal_status.is_terminal:assert not handles
 rows.append(dict(index=r['index'],drop=drop,state_after_drop=record_value(nxt),drop_terminal=record_value(nxt.terminal_status),first_response=None if first is None else action_to_dict(first.action),first_response_seconds=first_seconds,drop_caller_seconds=drop_seconds,full_response_seconds=time.perf_counter()-tick,responses=responses))
 print(r['index'],record_value(nxt.terminal_status),'responses',len(responses),'first',rows[-1]['first_response'],flush=True)
write_record(out,dict(scope=__doc__,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),rows=rows,seconds=time.perf_counter()-start,complete=True))
