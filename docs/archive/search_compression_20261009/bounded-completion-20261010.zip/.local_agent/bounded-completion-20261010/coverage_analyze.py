"""Whole frozen prospective cohort's saved prepass coverage, no reruns/refits.
Root/reply/deeper materialized successors are disjoint accounting levels.
Tie records describe heuristic concentration, never independent move utility.
This asks whether a new coverage premise is motivated before any new policy.
"""
from pathlib import Path
import sys,json,collections,hashlib
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;source=p/'games.json';d=json.loads(source.read_bytes());assert d['complete']
groups={};rows=[]
for g in d['rows']:
 for st in g['steps']:
  if st['method']!='combined':continue
  pre=st['stats']['prepass'];children=pre.get('root_child_records',[]);sign=1 if st['side']==0 else -1
  rank=lambda r:(sign*r['outcome']if r['outcome']is not None else 0,sign*r['value'])
  best=max(map(rank,children))if children else None;ties=[r for r in children if rank(r)==best]
  root=len(children);reply=sum(r['children']for r in children);deeper=pre['transitions']-root-reply;assert deeper>=0
  row=dict(seed=g['seed'],leaf=g['leaf'],methods=g['methods'],ply=st['ply'],route=st['stats']['route'],root_complete=pre.get('root_fully_expanded',False),root_children=root,reply_branches=sum(r['children']>0 for r in children),reply_children=reply,deeper_children=deeper,total_successors=pre['transitions'],top_ties=len(ties),top_ties_without_reply_expansion=sum(r['children']==0 for r in ties))
  rows.append(row);key=g['leaf']+':'+row['route'];a=groups.setdefault(key,collections.Counter());a['calls']+=1;a['root_complete']+=row['root_complete'];a['root_successors']+=root;a['reply_successors']+=reply;a['deeper_successors']+=deeper;a['no_reply_branch']+=row['reply_branches']==0;a['one_reply_branch']+=row['reply_branches']==1;a['multiple_reply_branches']+=row['reply_branches']>1;a['ties_multiple']+=len(ties)>1;a['tied_top_with_unexpanded_branch']+=len(ties)>1 and row['top_ties_without_reply_expansion']>0
write_record(p/'coverage-analysis.json',dict(scope=__doc__,input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),groups={k:dict(v)for k,v in groups.items()},rows=rows))
print(json.dumps({k:dict(v)for k,v in groups.items()}))
