"""Exposed mechanism control, ALL four paired resolved shortcuts, no reruns of
games or fitted policy. New premise: shipped root-tactical is ON by default and
already early-returns an actual current-side CHECKMATE child. Original paired
OFF results/conditions remain immutable. Use each cohort's maxD2/D6 and q0,
same2sec target/leaf/full histories; this is not a full product-q4 benchmark.
Expected<1min; execute after timed audits, no extra workers/default changes.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'root-default-controls.json';assert not out.exists();folders=[p,Path('.local_agent/deeper-completion-20261010')];rows=[];start=time.perf_counter()
write_record(p/'root-default-declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(encoding='utf-8'),selection='All paired resolved_prepass roots, both declared cohorts; no omitted shortcut',input_sha256={q.name:hashlib.sha256((q/'paired-roots.json').read_bytes()).hexdigest()for q in folders},shipped_root_tactical=SearchTuning().use_root_tactical))
for folder,depth in zip(folders,(2,6)):
 pairs=json.loads((folder/'paired-roots.json').read_bytes());games=json.loads((folder/'games.json').read_bytes());cases={r['seed']:r for r in json.loads((folder/'prospective-rules.json').read_bytes())['rules']}
 for key,parent in pairs['parents'].items():
  if parent['choices'][1]['stats']['route']!='resolved_prepass':continue
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];loc=next(r for r in pairs['rows']if r['key']==key);game=next(g for g in games['rows']if g['seed']==loc['seed']and g['leaf']==loc['leaf']and g['methods']==loc['methods']);case=cases[game['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
  for a in case['route'][:4]:s.submit(action_from_dict(a))
  for st in game['steps'][:loc['ply']]:s.submit(action_from_dict(st['action']))
  assert record_value(s.state)==parent['root'];before=s.state;cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profile,_=build_semantic_opportunity_profile(c,cfg)
  class Leaf(UnitEvaluator):
   def __init__(self):self.ev=Evaluator(c,profile,cfg)
   def evaluate(self,st):return super().evaluate(st)if game['leaf']=='unit'else self.ev.evaluate(st)
  player=AlphaBetaPlayer(c,evaluator_override=Leaf(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=True));tick=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=depth,max_time_seconds=2.0,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,decision);seconds=time.perf_counter()-tick;assert s.state==before;child=apply_action(before,decision.action,c)
  rows.append(dict(cohort=folder.name,key=key,seed=game['seed'],leaf=game['leaf'],ply=loc['ply'],root=record_value(before),action=action_to_dict(decision.action),child=record_value(child),stats=record_value(decision),caller_seconds=seconds,old_off_core=parent['choices'][0],old_combined=parent['choices'][1]));print(folder.name,game['seed'],loc['ply'],decision.termination_reason,round(seconds,6),record_value(child.terminal_status),flush=True)
assert len(rows)==4;write_record(out,dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
