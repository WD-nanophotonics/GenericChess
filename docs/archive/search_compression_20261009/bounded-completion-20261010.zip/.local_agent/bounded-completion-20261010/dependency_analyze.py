"""Keep action-sequence repetition separate from full-state repetition.
Leaf/method crossover rows share four rule samples; unique paths are not
independent trials or training samples. No outcomes or conditions changed.
"""
from pathlib import Path
import sys,json,hashlib,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'games.json').read_bytes());assert d['complete'];full={};strata={};rows=[]
for g in d['rows']:
 key=hashlib.sha256(json.dumps([g['seed'],g['initial'],[s['state']for s in g['steps']]],sort_keys=True,separators=(',',':')).encode()).hexdigest();full.setdefault(key,[]).append([g['seed'],g['leaf'],g['methods']]);strata.setdefault((g['seed'],g['leaf']),set()).add(key);rows.append(dict(seed=g['seed'],leaf=g['leaf'],methods=g['methods'],full_path_key=key))
r=dict(scope=__doc__,rule_samples=len({g['seed']for g in d['rows']}),cells=len(d['rows']),unique_full_history_paths=len(full),multiplicities=sorted(len(v)for v in full.values()),full_path_groups=full,within_rule_leaf_distinct_paths=[dict(seed=k[0],leaf=k[1],paths=len(v))for k,v in strata.items()],rows=rows)
write_record(p/'dependency-analysis.json',r);print(json.dumps({k:v for k,v in r.items()if k not in('rows','full_path_groups','scope')}))
