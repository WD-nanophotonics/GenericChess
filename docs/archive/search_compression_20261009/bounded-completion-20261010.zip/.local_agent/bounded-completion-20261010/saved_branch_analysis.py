"""Changed question on exposed saved trials: where was root-relative work spent?
No search rerun, cap extension, source intervention or exposed policy fitting.
Root child counts reveal only first reply layer, not full tree depth/work.
"""
from pathlib import Path
import sys,json,hashlib,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;source=Path('.local_agent/completion-ablation-20261010/resolution-cost-scale.json');d=json.loads(source.read_bytes());rows=[]
for r in d['rows']:
 st=r['stats'];cs=st['root_child_records'];side=r['side'];sign=1 if side==0 else -1
 def pref(x):return(sign*(x['outcome']if x['outcome']is not None else 0),sign*x['value'])
 best=max(map(pref,cs));selected=next((i,x)for i,x in enumerate(cs)if x['action']==r['action'])
 expanded=[dict(index=i,action=x['action'],reply_children=x['children'],fully_expanded=x['fully_expanded'],outcome=x['outcome'],value=x['value'])for i,x in enumerate(cs)if x['children']]
 rows.append(dict(seed=r['seed'],leaf=r['leaf'],ply=r['ply'],side=side,cap=r['limit'],root_children=len(cs),root_complete=st['root_fully_expanded'],root_outcome=st['root_outcome'],transitions=st['transitions'],generations=st['generations'],iterations=st['iterations'],expanded_root_branches=expanded,first_reply_child_total=sum(x['children']for x in cs),deeper_or_other_transitions=st['transitions']-len(cs)-sum(x['children']for x in cs),selected_root_index=selected[0],selected_reply_children=selected[1]['children'],selected_value=selected[1]['value'],best_priority_ties=sum(pref(x)==best for x in cs),seconds=r['caller_seconds']))
write_record(p/'saved-branch-analysis.json',dict(scope=__doc__,source=source.as_posix(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),rows=rows,complete=True))
for r in rows:print(r['seed'],r['ply'],r['cap'],'root',r['root_children'],'branches',len(r['expanded_root_branches']),'first-replies',r['first_reply_child_total'],'deeper',r['deeper_or_other_transitions'],'ties',r['best_priority_ties'],'chosen',r['selected_root_index'],r['selected_reply_children'])
