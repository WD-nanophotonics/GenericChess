"""Predeclared16 fresh2180-2183 comparison: cold Core versus fixed completion
prepass(512successors,.2sec target) plus residual cold Core, total2sec target.
Prepass is one tenth of total as an engineering allocation,512 is the existing
generic prototype cap, neither optimized on exposed winning roots. Only resolved
root outcomes override Core; unknown heuristics never reorder or warm Core.
Both use maxD2/q0, same Unit/v3 leaves, both owners, opening4, external64ply.
Caller prepass elapsed including serialization is deducted from Core allowance.
One public operation/PV validation may overrun; actual outer elapsed is reported.
Unknown: can useful terminal signal justify residual-depth opportunity cost?
Either favorable or adverse cells change route priority; all retained, no fitting.
Full promotion/drop/aux/history; declarations/restarts excluded in this scoped
cohort. Expected<40min;3200sec job checkpoint and stop check perply. No product
change/extra workers/outcome-selected extensions/Elo/ongoing-as-draw.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path(__file__).parent)]
from combined import choose_combined
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'games.json';assert not out.exists();assert json.loads((Path('.local_agent/completion-ablation-20261010')/'games.json').read_bytes())['complete'];d=json.loads((p/'prospective-rules.json').read_bytes());cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
write_record(p/'declaration.json',dict(scope=__doc__,source=Path(__file__).read_text(encoding='utf-8'),combined_source=(p/'combined.py').read_text(encoding='utf-8'),prepass_seconds=.2,prepass_successors=512,frontier_source=Path(p/'frontier.py').read_text(encoding='utf-8'),rules_sha256=hashlib.sha256((p/'prospective-rules.json').read_bytes()).hexdigest(),arms=['unit','v3'],assignments=[['ab','combined'],['combined','ab']],games=16,seconds=2.0,max_plies=64,ab_max_depth=2,expected_minutes=40))
rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,_=build_semantic_opportunity_profile(c,cfg)
 for kind in ('unit','v3'):
  class Leaf(UnitEvaluator):
   def __init__(self):self.ev=Evaluator(c,profile,cfg)
   def evaluate(self,state):return super().evaluate(state)if kind=='unit'else self.ev.evaluate(state)
  for methods in (('ab','combined'),('combined','ab')):
   s=GameSession(c)
   for a in case['route'][:4]:s.submit(action_from_dict(a))
   leaf=Leaf();pl=AlphaBetaPlayer(c,evaluator_override=leaf,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));row=dict(seed=case['seed'],leaf=kind,methods=methods,initial=record_value(s.state),steps=[],complete=False,abort=None);rows.append(row);tick=time.perf_counter()
   for ply in range(64):
    if s.state.terminal_status.is_terminal:break
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<3200
    before=s.state;side=before.position.side_to_move;method=methods[side];call_start=time.perf_counter()
    if method=='combined':action,stats=choose_combined(s,c,leaf,pl,2.0)
    else:
     pl._tt.clear();decision=pl.choose_action(s,SearchLimits(max_depth=2,max_time_seconds=2.0,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,decision);action=decision.action;stats=record_value(decision)
    seconds=time.perf_counter()-call_start;assert s.state==before
    if action is None:row['abort']='empty_frontier_or_decision';break
    assert action in s.legal_actions();s.submit(action);row['steps'].append(dict(ply=ply,side=side,method=method,seconds=seconds,stats=stats,action=action_to_dict(action),state=record_value(s.state)))
    if ply%8==0:write_record(out,dict(scope=__doc__,rows=rows,complete=False,seconds=time.perf_counter()-start))
   row.update(complete=True,seconds=time.perf_counter()-tick,terminal=record_value(s.state.terminal_status),classification='TERMINAL'if s.state.terminal_status.is_terminal else 'CENSORED');write_record(out,dict(scope=__doc__,rows=rows,complete=False,seconds=time.perf_counter()-start));print(case['seed'],kind,methods,len(row['steps']),row['terminal'],round(row['seconds'],3),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
