"""Recovery of fixed allocation/depth-scope experiments, only Agent sources/data.
No raw Slack/account/private inputs. Replay saved full histories and actual
reply witnesses from the final ZIP, not a working file. Recovery is not an
independent WDL/scientific certificate or renewed unexposed qualification.
"""
from pathlib import Path
import sys,json,hashlib,zipfile
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
folders=[Path('.local_agent/bounded-completion-20261010'),Path('.local_agent/deeper-completion-20261010')]
archive=Path('docs/archive/search_compression_20261009/bounded-completion-20261010.zip');index=archive.with_name(archive.stem+'-index.json');verify_only='--verify-only'in sys.argv
if verify_only:
 saved=json.loads(index.read_bytes());members=saved['members'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==saved['archive_sha256']
 for q in saved['prerequisites']:assert hashlib.sha256(Path(q['path']).read_bytes()).hexdigest()==q['sha256']
else:
 assert not archive.exists();members=[]
 files=sorted(f for p in folders for f in p.iterdir()if f.suffix in('.py','.json','.md')and f.name not in('prepare.py','segment_review.md','allocation_report.md'))
 for p in folders:
  assert json.loads((p/'games.json').read_bytes())['complete']
  for name in('paired-roots.json','reply-audit.json'):
   if(p/name).exists():assert json.loads((p/name).read_bytes())['complete']
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for f in files:
   raw=f.read_bytes();name=f.as_posix();assert not f.is_absolute()and '/slack/'not in name;z.writestr(name,raw);members.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
states=0;witnesses=0;pair_children=0;pair_witnesses=0;default_children=0;default_seen=set()
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
 defaults={(r['cohort'],r['key']):r for r in json.loads(z.read(folders[0].as_posix()+'/root-default-controls.json'))['rows']}
 for p in folders:
  pref=p.as_posix()+'/';data=json.loads(z.read(pref+'games.json'));cases={r['seed']:r for r in json.loads(z.read(pref+'prospective-rules.json'))['rules']};audits=json.loads(z.read(pref+'reply-audit.json'))['audits']if pref+'reply-audit.json'in z.namelist()else{};pairs=json.loads(z.read(pref+'paired-roots.json'))if pref+'paired-roots.json'in z.namelist()else dict(parents={})
  for g in data['rows']:
   c=compile_ruleset_for_execution(ruleset_from_dict(cases[g['seed']]['rules']));s=GameSession(c)
   for raw in cases[g['seed']]['route'][:4]:s.submit(action_from_dict(raw))
   assert record_value(s.state)==g['initial']
   for st in g['steps']:
    key=hashlib.sha256(json.dumps([g['seed'],g['leaf'],record_value(s.state)],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if key in pairs['parents']:
     parent=pairs['parents'][key];assert parent['root']==record_value(s.state)
     dk=(p.name,key)
     if dk in defaults:
      control=defaults[dk];assert control['root']==record_value(s.state);child=apply_action(s.state,action_from_dict(control['action']),c);assert record_value(child)==control['child'];default_children+=1;default_seen.add(dk)
     for choice in parent['choices']:
      child=apply_action(s.state,action_from_dict(choice['action']),c);assert record_value(child)==choice['child'];pair_children+=1
      for w in choice['witnesses']:
       end=apply_action(child,action_from_dict(w['action']),c);assert record_value(end.terminal_status)==w['terminal'];pair_witnesses+=1
    s.submit(action_from_dict(st['action']));raw=record_value(s.state);assert raw==st['state'];states+=1
    if audits:
     a=audits[hashlib.sha256(json.dumps(raw,sort_keys=True,separators=(',',':')).encode()).hexdigest()];assert a['state']==raw
     for w in a['witnesses']:
      end=apply_action(s.state,action_from_dict(w['action']),c);assert record_value(end.terminal_status)==w['terminal'];witnesses+=1
   assert record_value(s.state.terminal_status)==g['terminal']
 assert default_seen==set(defaults)
prereq=Path('docs/archive/search_compression_20261009/completion-ablation-20261010.zip');hand=prereq.with_name('hand-discount-20261010.zip');index=archive.with_name(archive.stem+'-index.json')
with zipfile.ZipFile(hand)as h,zipfile.ZipFile(prereq)as a,zipfile.ZipFile(archive)as z:
 old='.local_agent/hand-discount-20261010/';game=next(g for g in json.loads(h.read(old+'games.json'))['rows']if g['seed']==202610082151 and g['policies']==['unit','v3']);case=next(r for r in json.loads(h.read(old+'prospective-rules.json'))['rules']if r['seed']==game['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for raw in case['route'][:4]:s.submit(action_from_dict(raw))
 for step in game['steps'][:3]:s.submit(action_from_dict(step['action']));assert record_value(s.state)==step['state']
 roots={r['index']:r for r in json.loads(a.read('.local_agent/completion-ablation-20261010/drop-service.json'))['rows']};dropstates=0;responses=0
 for r in json.loads(z.read(folders[0].as_posix()+'/drop-responses.json'))['rows']:
  child=apply_action(s.state,action_from_dict(roots[r['index']]['root_action']),c);assert record_value(child)==roots[r['index']]['child'];nxt=apply_action(child,action_from_dict(r['drop']),c);assert record_value(nxt)==r['state_after_drop'];dropstates+=1
  for response in r['responses']:
   end=apply_action(nxt,action_from_dict(response['action']),c);assert record_value(end)==response['state'];responses+=1
verification=dict(member_hashes=len(members),full_game_states=states,selected_reply_witness_occurrences=witnesses,paired_child_occurrences=pair_children,paired_reply_witness_occurrences=pair_witnesses,drop_states=dropstates,actual_drop_responses=responses,default_control_unique_roots=len(defaults),default_control_child_occurrences=default_children)
if verify_only:
 assert verification==saved['verification'];print('existing archive replay verified without rewriting frozen data',verification);sys.exit(0)
write_record(index,dict(scope=__doc__,base_commit='b236c79ab7d11b2f234af4e099eb8b4208149f26',archive=archive.as_posix(),archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=members,prerequisites=[dict(path=q.as_posix(),sha256=hashlib.sha256(q.read_bytes()).hexdigest())for q in(prereq,hand)],verification=verification))
cohorts={}
for p in folders:
 cohort=dict(games=json.loads((p/'analysis.json').read_bytes()))
 for name,filename in(('paired','paired-analysis.json'),('reply','reply-analysis.json')):
  cohort[name]={k:v for k,v in json.loads((p/filename).read_bytes()).items()if k!='positive_rows'}if(p/filename).exists()else dict(status='predeclared_not_run',scope='No diagnostic result claimed; continue from saved sources/memo')
 for name,filename in(('coverage','coverage-analysis.json'),('dependency','dependency-analysis.json'),('work','work-analysis.json'),('resolutions','saved-resolution-match.json'),('paired_cost_routes','paired-cost-routes.json')):
  cohort[name]={k:v for k,v in json.loads((p/filename).read_bytes()).items()if k not in('rows','full_path_groups')}
 cohorts[p.name]=cohort
data=dict(scope=__doc__,archive_index=index.as_posix(),cohorts=cohorts,saved_branch_analysis=json.loads((folders[0]/'saved-branch-analysis.json').read_bytes()),drop_responses={k:v for k,v in json.loads((folders[0]/'drop-responses.json').read_bytes()).items()if k!='rows'},full_state_replay=states)
write_record(Path('docs/research/data/bounded_completion_20261010.json'),data)
print('verified archive members',len(members),'states',states,'reply witnesses',witnesses,'pairedchildren',pair_children,'pairedwitnesses',pair_witnesses)
