# Coverage alternative: decision boundary

The fresh saved-tree coverage counts motivate checking selection effort, not
assuming more breadth is always better. Allis, van der Meulen and van den Herik,
*Proof-number search* (1994), DOI10.1016/0004-3702(94)90004-3, directly targets
game-theoretic resolution rather than interim minimax scores and accounts for
the number of nodes needed to establish/refute a result in nonuniform trees.
Primary abstract: https://www.sciencedirect.com/science/article/pii/0004370294900043
Accessed2026-10-10; only the accessible abstract was inspected, not full paper
implementation details. Do not infer its empirical gain on these rules.

Inference for this prototype: unresolved-child priority based only on outcome
and heuristic value supplies no estimate of proof effort. Increasing512 to2048
can therefore remain concentrated even when an untouched tied branch is cheaper.
Conversely, uniformly allocating replies to every root can waste the same budget
if most branches require many defenses; root breadth alone is not a utility metric.

Defer adding a proof-number algorithm/default. The immediate decision remains
the already-declared same-parent allocation comparison. If it shows no useful
increment, retain conditional response support as Main; a future coverage probe
must measure actual root/reply/deeper work and resolution under identical leaf/
successor conditions, not claim improvement merely from visiting more branches.
No independent WDL, full generic coverage, hidden-label fit or training follows.
