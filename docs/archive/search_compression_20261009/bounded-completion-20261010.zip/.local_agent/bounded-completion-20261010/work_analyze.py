"""Actual recorded public/runtime work, not nodes mislabeled as transition cost.
Native/terminal internal semantic pushes were not instrumented in these games;
the saved materialization/generation/cache/scoring counters retain their names.
Caller time includes the wrapper and PV validation, game-record bytes separate.
"""
from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;src=p/'games.json';d=json.loads(src.read_bytes());assert d['complete'];groups={}
keys=('nodes','qnodes','evaluation_calls','evaluation_seconds','legal_actions_generated','legal_generation_calls','legal_generation_seconds','ordering_calls','ordering_seconds','successor_handles_created','successors_materialized','successors_searched','position_key_cache_hits','position_keys_computed','terminal_cache_hits','terminal_results_computed','tt_probes','tt_hits','tt_cutoffs')
for method in('ab','combined'):
 stats=[s['stats']if method=='ab'else s['stats']['core']for g in d['rows']for s in g['steps']if s['method']==method];stats=[s for s in stats if s is not None]
 groups[method]=dict(core_calls=len(stats),sums={k:sum(s[k]for s in stats)for k in keys},termination_reasons=dict(collections.Counter(s['termination_reason']for s in stats)))
r=dict(scope=__doc__,core=groups,game_json_bytes=src.stat().st_size,prepass_scope='Materialized full-state successors/evaluations/generations retained in analysis.json; terminal internal transition count unmeasured, no inferred count.',complete=True)
write_record(p/'work-analysis.json',r);print(json.dumps(r))
