"""Describe every selected-child reply diagnostic. Positive rows and unique
complete states are separate; no forced/avoidable error rate or independent
holdout claim. Preserve method/leaf/resource/actual completed-depth context.
"""
from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'reply-audit.json').read_bytes());assert d['complete'];games=json.loads((p/'games.json').read_bytes());idx={(g['seed'],g['leaf'],tuple(g['methods'])):g for g in games['rows']};positive=[]
for r in d['rows']:
 if not r['immediate_loss_witnesses']:continue
 g=idx[(r['seed'],r['leaf'],tuple(r['methods']))];st=g['steps'][r['ply']];positive.append(dict(seed=r['seed'],leaf=r['leaf'],methods=r['methods'],ply=r['ply'],mover=r['mover'],method=r['method'],state_key=r['state_key'],witnesses=r['immediate_loss_witnesses'],stats=st['stats']))
result=dict(scope=__doc__,path_rows=len(d['rows']),unique_full_states=len(d['audits']),cache_hits=d['cache_hits'],transitions=d['transitions'],seconds=d['seconds'],positive_path_rows=len(positive),unique_positive_states=sum(bool(a['witnesses'])for a in d['audits'].values()),positive_by_method=dict(collections.Counter(r['method']for r in positive)),positive_by_leaf=dict(collections.Counter(r['leaf']for r in positive)),positive_rows=positive)
write_record(p/'reply-analysis.json',result);print(json.dumps({k:v for k,v in result.items()if k!='positive_rows'}));print([(r['seed'],r['leaf'],r['method'],r['ply'],r['stats'].get('completed_depth'),r['stats'].get('root_outcome'))for r in positive])
