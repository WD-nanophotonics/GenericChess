"""Common-parent allocation diagnostic, no whole-root WDL or Elo.
Count each identical full-history/leaf parent once, retain all sampled paths.
Opposing next-reply witnesses concern selected children only. Absence is a
one-step local observation, not overall safety or proof of optimality.
"""
from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'paired-roots.json').read_bytes());assert d['complete'];counter=collections.Counter();depths=collections.Counter();routes=collections.Counter();rows=[];costs=collections.Counter();replies=collections.Counter()
for key,r in d['parents'].items():
 a,b=r['choices'];assert a['method']=='ab'and b['method']=='combined';same=a['action']==b['action'];counter['same_action'if same else'different_action']+=1
 sa=bool(a['witnesses']);sb=bool(b['witnesses']);counter[f'immediate_exposure_ab{int(sa)}_combined{int(sb)}']+=1
 da=a['stats']['completed_depth'];db=None if b['stats']['core']is None else b['stats']['core']['completed_depth'];depths[str((da,db))]+=1;routes[b['stats']['route']]+=1
 costs['ab']+=a['caller_seconds'];costs['combined']+=b['caller_seconds'];costs['prepass']+=b['stats']['prepass_caller_seconds'];replies['ab']+=a['replies'];replies['combined']+=b['replies']
 rows.append(dict(key=key,seed=r['seed'],leaf=r['leaf'],actions_equal=same,ab_depth=da,combined_depth=db,route=b['stats']['route'],root_outcome=b['stats']['prepass'].get('root_outcome',b['stats']['prepass'].get('outcome')),ab_exposure=sa,combined_exposure=sb,ab_seconds=a['caller_seconds'],combined_seconds=b['caller_seconds']))
r=dict(scope=__doc__,unique_parents=len(d['parents']),path_rows=len(d['rows']),summary=dict(counter),depth_pairs=dict(depths),routes=dict(routes),caller_seconds=dict(costs),reply_transitions=dict(replies),seconds=d['seconds'],rows=rows,complete=True)
write_record(p/'paired-analysis.json',r);print(json.dumps({k:v for k,v in r.items()if k not in('rows','scope')}))
