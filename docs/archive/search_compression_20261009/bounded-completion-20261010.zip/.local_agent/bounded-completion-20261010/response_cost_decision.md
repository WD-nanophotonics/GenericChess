# Conditional response support: placement question

The old safe drop's actual drop application costs8.861ms and finding its
first actual response another.4355ms; the complete response pass costs5.7904ms.
Those are separate boundaries: drop application already includes terminal
authority, so the terminal shortcut in the four losing states is not a free
drop-safety feature. All costs are local exposed-state measurements.

The freshD2 baseline records.501978sec for124996evaluation calls, an average
about4.02microseconds for these cheap leaves. This compares different contexts
and boundaries, not a measured deployment ratio or an additive runtime model.
It nevertheless gives a concrete cost objection to calling a complete drop/
response scan at every leaf without reuse. More informative semantics alone
does not establish a useful evaluator at the same caller budget.

The next placement question should be whether an untrained response-support
descriptor can reuse already materialized semantic children at a root/frontier,
and distinguish response mechanisms without a new whole-front pass. Record
actual handles/transitions/cache/evaluation cost and full-state preservation.
If independent extra semantic transitions dominate, retain it as a diagnostic,
not a ubiquitous learned leaf input. No old labels are fitted, no cheapness or
playing gain is presumed, and no training/production adapter is launched here.
