"""Describe all fixed cells and caller costs; no default/strength claim.
Ongoing64, technical unknown and real draws are kept distinct. Mixed trajectories
do not support paired-speed estimates. Completed Core depth and resolved prepass
outcomes stay separate, as do successor work units and alpha-beta nodes.
"""
from pathlib import Path
import sys,json,collections,statistics
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'games.json').read_bytes());assert d['complete']and len(d['rows'])==16
outcomes=collections.Counter();events=collections.Counter();cells=[];methods={}
for g in d['rows']:
 t=g['terminal'];events[t['status']]+=1
 if g['abort']:label='technical_unknown'
 elif t['status']=='ongoing':assert len(g['steps'])==64;label='ongoing64'
 elif t['status']=='no_contest':label='restart_unsupported'
 elif t['winner']is None:label='rule_draw'
 else:label=g['methods'][t['winner']]+'_win'
 outcomes[label]+=1;cells.append(dict(seed=g['seed'],leaf=g['leaf'],methods=g['methods'],plies=len(g['steps']),terminal=t,label=label,seconds=g['seconds']))
for method in('ab','combined'):
 ss=[s for g in d['rows']for s in g['steps']if s['method']==method];core=[s['stats']if method=='ab'else s['stats']['core']for s in ss];core=[s for s in core if s is not None];pre=[s['stats']['prepass']for s in ss]if method=='combined'else[]
 methods[method]=dict(calls=len(ss),call_seconds=sum(s['seconds']for s in ss),median_seconds=statistics.median(s['seconds']for s in ss),max_seconds=max(s['seconds']for s in ss),above2p05=sum(s['seconds']>2.05 for s in ss),core_calls=len(core),core_depth_counts=dict(collections.Counter(s['completed_depth']for s in core)),core_nodes=sum(s['nodes']for s in core),core_successors=sum(s['successors_materialized']for s in core),core_evaluations=sum(s['evaluation_calls']for s in core),prepass_calls=len(pre),prepass_transitions=sum(s['transitions']for s in pre),prepass_generations=sum(s['generations']for s in pre),prepass_evaluations=sum(s['evaluations']for s in pre),prepass_caller_seconds=sum(s['stats']['prepass_caller_seconds']for s in ss)if method=='combined'else 0,route_counts=dict(collections.Counter(s['stats']['route']for s in ss))if method=='combined'else{},prepass_resolutions=dict(collections.Counter(str(s.get('root_outcome',s.get('outcome')))for s in pre)))
sig=collections.Counter(json.dumps([s['action']for s in g['steps']],sort_keys=True)for g in d['rows']);r=dict(scope=__doc__,summary=dict(seconds=d['seconds'],plies=sum(len(g['steps'])for g in d['rows']),outcomes=dict(outcomes),events=dict(events),methods=methods,cells=cells,distinct_action_trajectories=len(sig),duplicate_multiplicities=sorted(sig.values())),no_default=True,no_exposed_fitting=True)
write_record(p/'analysis.json',r);print(json.dumps(r['summary'],ensure_ascii=False))
