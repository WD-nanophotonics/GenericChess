"""Finite budget accounting controls; no policy efficacy claims."""
import sys,json,time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path[:0]=[str(Path.cwd()),str(Path(__file__).parent)]
import combined
from scripts.research_record import write_record
rows=[]
class Player:
 def __init__(self):self._tt={'old':1};self.calls=[]
 def choose_action(self,s,limits):
  self.calls.append(limits);return SimpleNamespace(action='core',value=0)
s=SimpleNamespace(state='unchanged')
for resolution,delay,total in ((None,.012,.1),(1,.012,.1),(0,.012,.1),(-1,.012,.1),(None,.015,.005)):
 def pre(*args):time.sleep(delay);return 'frontier',{'root_outcome':resolution}
 p=Player()
 with patch.object(combined,'choose',pre),patch.object(combined,'validate_pv',lambda *a:None),patch.object(combined,'record_value',lambda x:dict(action=x.action,value=x.value)):
  a,r=combined.choose_combined(s,None,None,p,total)
 assert r['prepass_caller_seconds']>=delay
 assert abs(r['core_allowance_seconds']-max(0,total-r['prepass_caller_seconds']))<1e-9
 if resolution is not None:assert a=='frontier' and not p.calls
 elif total<delay:assert a=='frontier' and not p.calls
 else:assert a=='core' and len(p.calls)==1 and not p._tt
 assert s.state=='unchanged'
 rows.append(dict(resolution=resolution,delay=delay,total=total,action=a,stats=r))
write_record(Path(__file__).parent/'controls.json',dict(scope=__doc__,rows=rows,complete=True))
print('5 finite accounting controls pass; sleeps only simulate measured prepass overhead')
