Source decision, not new experimental outcome:

The timed prototype and combined caller retain real GameState children and
existing identity-bound legal handles. Completion wins come from a real winning
terminal descendant under existential current-side backup; loss/draw requires
complete expansion and resolved children. Partial heuristic values are not proof.
The unknown-prepass branch uses a cold Core TT and the same leaf, and discards
prepass heuristics. Its actual outer prepass time, including stats serialization,
is deducted from the Core time allowance. Core/PV cooperative operations can
overrun; the two-second value is a target, not strict interrupt latency.

The scope excludes declarations/restarts and makes no finite-completeness claim
for unrestricted generated histories. Resolution and heuristic scores remain
separate. The observed old tied actions involve different actors, so no state
merging follows just from a matching target square or leaf value.

Primary-source relevance to the tie concentration question: Cohen-Solal and
Cazenave2025 section3.2 says restarting full backpropagation from the root can
change search under ties/transpositions. This prototype already restarts at the
root but uses a stable canonical tie, without its learned leaves/TT/safe decision.
Their empirical comparison therefore does not predict a benefit here. The2026
completeness work assumes finite state structure and establishes eventual
resolution, not two-second root coverage or generic history-state finiteness.
These are reasons to measure coverage/cost, not require a new proof before tests.
https://arxiv.org/html/2505.04525v1
https://arxiv.org/html/2603.24572v1
