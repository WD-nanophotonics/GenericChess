"""Separate resolved shortcuts from unknown-call opportunity cost on ALL paired
parents. Existing Core mate signs versus prepass outcomes are recorded, not
inferred from missing calls. No searches, selective extensions or new labels.
"""
from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
from generic_chess.ai.evaluation.config import MATE_THRESHOLD
p=Path(__file__).parent;d=json.loads((p/'paired-roots.json').read_bytes());assert d['complete'];groups={};resolved=[]
for key,r in d['parents'].items():
 a,b=r['choices'];assert a['method']=='ab'and b['method']=='combined';route=b['stats']['route'];c=groups.setdefault(route,collections.Counter());c['parents']+=1;c['ab_seconds']+=a['caller_seconds'];c['combined_seconds']+=b['caller_seconds'];c['prepass_seconds']+=b['stats']['prepass_caller_seconds']
 if route=='resolved_prepass':
  side=r['root']['position']['side_to_move'];out=b['stats']['prepass'].get('root_outcome',b['stats']['prepass'].get('outcome'));mover=out*(1 if side==0 else -1);score=a['stats']['score'];resolved.append(dict(key=key,seed=r['seed'],leaf=r['leaf'],mover_outcome=mover,selected_child_terminal=b['child']['terminal_status'],ab_score=score,ab_depth=a['stats']['completed_depth'],same_mate_sign=abs(score)>=MATE_THRESHOLD and (1 if score>0 else -1)==mover,actions_equal=a['action']==b['action'],successors=b['stats']['prepass']['transitions']))
v=dict(scope=__doc__,groups={k:dict(v)for k,v in groups.items()},resolved=resolved,complete=True);write_record(p/'paired-cost-routes.json',v);print(json.dumps(v))
