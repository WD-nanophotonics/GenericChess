"""Predeclared paired small affine event fits, fresh rules and fixed budget.
Signed269 versus signed+unsigned401. Neither model is selected or deployed.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection,actor_vectors
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
p=Path(__file__).parent;load=lambda n:json.loads((p/n).read_bytes());decl=load('declaration.json');games=load('signal-games.json');assert games['complete'] and len(games['rows'])==16;assert not (p/'fit-result.json').exists();cases={r['seed']:r for r in load('signal-declaration.json')['rules']};cols=list(range(66))+list(range(396,462))+list(range(792,924))+[924,930,936,937];x=[];context=[];records=[];labels=[];weights=[];start=time.perf_counter()
for gi,row in enumerate(games['rows']):
 assert row['complete'] and row['policies']==['unit','unit'];term=row['terminal'];assert term['status']!='ongoing' or len(row['steps'])==96;label=3 if term['status']=='ongoing' else 2 if term['winner'] is None else 0 if term['winner']==0 else 1;group=next(k for k in ('train','dev','report') if row['seed'] in decl[k]);case=cases[row['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));e=InteractionProjection(c);actors=actor_vectors(c);s=GameSession(c)
 for a in case['route'][:row['opening']]:s.submit(action_from_dict(a))
 lo=len(x)
 for i in range(min(13,len(row['steps']))):
  if i in decl['snapshot_plies']:
   assert not s.state.terminal_status.is_terminal;pos=s.state.position;u=np.zeros(132)
   for v in pos.board:
    if v is not None:u[:66]+=actors[v.current_type_id];u[66:]+=actors[v.base_type_id]
   x.append(np.r_[e.encode(pos)[cols],(96-i)/96]);context.append(u);labels.append(label);records.append(dict(game=gi,seed=row['seed'],opening=row['opening'],snapshot=i,group=group,label=label))
  s.submit(action_from_dict(row['steps'][i]['action']))
 assert len(x)>lo;weights.extend([1/(len(x)-lo)]*(len(x)-lo))
x=np.asarray(x);xx=np.c_[x,context];y=np.eye(4)[labels];weight=np.asarray(weights);train=np.asarray([r['group']=='train' for r in records]);wt=weight[train]/weight[train].sum();prior=wt@y[train];models={};preds={};cost={};baseline=np.tile(prior,(len(x),1))
def softmax(a):
 exp=np.exp(a-a.max(1,keepdims=True));return exp/exp.sum(1,keepdims=True)
for arm,features in (('signed269',x),('context401',xx)):
 chosen=np.flatnonzero(np.ptp(features[train],axis=0)>0);mean=features[train][:,chosen].mean(0);scale=features[train][:,chosen].std(0);z=np.c_[(features[:,chosen]-mean)/scale,np.ones(len(x))];w=np.zeros((z.shape[1],4));mom=np.zeros_like(w);vel=np.zeros_like(w);tick=time.perf_counter()
 for step in range(1,301):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-tick<120
  pred=softmax(z[train]@w);grad=z[train].T@(wt[:,None]*(pred-y[train]))+.0001*np.r_[w[:-1],np.zeros((1,4))];mom=.9*mom+.1*grad;vel=.999*vel+.001*grad*grad;w-=.01*(mom/(1-.9**step))/(np.sqrt(vel/(1-.999**step))+1e-8)
 preds[arm]=softmax(z@w);models[arm]=dict(columns=chosen.tolist(),mean=mean.tolist(),scale=scale.tolist(),weights=w.tolist(),input_axes=features.shape[1],train_variable_axes=len(chosen),count_columns=cols);cost[arm]=time.perf_counter()-tick
metrics={}
for group in ('train','dev','report')+tuple(str(s) for s in sorted(cases)):
 mask=np.asarray([r['group']==group if group in ('train','dev','report') else r['seed']==int(group) for r in records]);ww=weight[mask]/weight[mask].sum();metrics[group]=dict(games=len({r['game'] for r,k in zip(records,mask) if k}),samples=int(mask.sum()),labels=(ww@y[mask]).tolist())
 for arm,pr in list(preds.items())+[('prior',baseline)]:metrics[group][arm]=dict(brier=float(ww@np.square(pr[mask]-y[mask]).sum(1)),log_loss=float(ww@(-np.log(np.maximum(pr[mask],1e-12))*y[mask]).sum(1)))
(p/'models.json').write_text(json.dumps(models,indent=2)+'\n',encoding='utf-8');rest=load('models.json')
for arm,features in (('signed269',x),('context401',xx)):
 m=rest[arm];assert np.array_equal(preds[arm],softmax(np.c_[(features[:,m['columns']]-m['mean'])/m['scale'],np.ones(len(x))]@m['weights']))
np.savez_compressed(p/'inputs.npz',signed=x,context=xx,labels=np.asarray(labels),weights=weight,prior=prior,**preds)
out=dict(scope=__doc__,complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration_sha256=hashlib.sha256((p/'declaration.json').read_bytes()).hexdigest(),seconds=time.perf_counter()-start,fit_seconds=cost,metrics=metrics,rows=records,log_floor=1e-12,limits=decl['limits']);(p/'fit-result.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:metrics[k] for k in ('train','dev','report')},indent=2))
