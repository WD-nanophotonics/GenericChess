"""Freeze a small finite-policy event predictor before new labels.
Four outputs are owner0 win/loss/draw before declared external horizon, or
no terminal event yet. The last class is NOT an eventual draw or WDL label.
All Unit/Unit teacher policies use original full state/history and same limits.
Count inputs are scoped approximations, not complete auxiliary/history encoding.
No search leaf deployment, exposed-label refit, model selection or default.
"""
from pathlib import Path
import json,hashlib
p=Path('.local_agent/policy-event-20261010');p.mkdir(exist_ok=False)
base=Path('.local_agent/return-signal-20261010')
s=(base/'freeze.py').read_text().replace('four new full rules/routes','eight new full rules/routes').replace('Seeds2122-2125','Seeds2126-2133').replace('(202610082122,202610082123,202610082124,202610082125)','tuple(range(202610082126,202610082134))')
(p/'freeze.py').write_text(s)
s=(base/'games.py').read_text().replace('Four new frozen rules2122-2125','Eight new frozen rules2126-2133').replace("for kinds in (('unit','unit'),('full','unit'),('unit','full')):","for kinds in (('unit','unit'),):").replace("policies=[['unit','unit'],['full','unit'],['unit','full']]","policies=[['unit','unit']]")
(p/'games.py').write_text(s)
plan=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),train=list(range(202610082126,202610082130)),dev=[202610082130,202610082131],report=[202610082132,202610082133],teacher='Unit/Unit Core D2/512nodes/.25sec/q0/hard8, original history',max_plies=96,snapshot_plies=[0,4,8,12],classes=['owner0_win','owner0_loss','draw','no_event_yet'],features='existing268count axes plus remaining external plies/96; excludes latent aux/geometry/history interactions',fit=dict(seed=2026101020,epochs=300,learning_rate=.01,regularization=.0001),weighting='equal games within split, equal sampled nonterminal states per game',baseline='training game-balanced class prior',metrics='four-class Brier and log loss, all games and per-rule; no model selection',budget='generation expected<12min; fit<2min; interruptible user-stop checks; no extra worker')
(p/'fit-declaration.json').write_bytes((json.dumps(plan,indent=2)+'\n').encode());print('Prospective eight-rule split and finite-event target frozen; no new outcome read')
