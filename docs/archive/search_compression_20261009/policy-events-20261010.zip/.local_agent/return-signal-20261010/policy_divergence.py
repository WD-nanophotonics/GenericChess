"""Locate first action divergences and actual bounded-search completeness.
These are resource-sensitive teacher trajectories, not causal strength tests.
"""
from pathlib import Path
import json
from collections import Counter
p=Path(__file__).parent;load=lambda n:json.loads((p/n).read_bytes());a=load('signal-games.json');b=load('resource-games.json');assert a['complete'] and b['complete'];key=lambda r:(r['seed'],r['opening'],tuple(r['policies']));old={key(r):r for r in a['rows']};rows=[];groups={}
for name,data in (('cheap',a),('resource',b)):
 steps=[s for r in data['rows'] for s in r['steps']];groups[name]=dict(plies=len(steps),completed_depth=dict(Counter(s['decision']['completed_depth'] for s in steps)),termination_reason=dict(Counter(s['decision']['termination_reason'] for s in steps)))
for r in b['rows']:
 x=old[key(r)];div=next((i for i,(s,t) in enumerate(zip(x['steps'],r['steps'])) if s['action']!=t['action']),None);item=dict(seed=r['seed'],opening=r['opening'],policies=r['policies'],same_terminal=x['terminal']==r['terminal'],common_prefix_plies=div if div is not None else min(len(x['steps']),len(r['steps'])))
 if div is not None:
  for name,ds in (('cheap',x['steps'][div]),('resource',r['steps'][div])):item[name]={k:ds['decision'][k] for k in ('action','score','completed_depth','termination_reason','nodes','evaluation_calls')}
 rows.append(item)
out=dict(scope=__doc__,search_observations=groups,pairs=rows,first_action_divergences=sum('cheap' in r for r in rows),limits='Changed resource changes permitted depth, nodes, wall time and warm-TT trajectory. No separate identification of depth versus time/caching, no action goodness claim.')
(p/'policy-divergence.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='pairs'},indent=2))
