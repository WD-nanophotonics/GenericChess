"""Matched bounded-policy event sensitivity; retain every declared cell and cap."""
from pathlib import Path
import json
from collections import Counter
p=Path(__file__).parent
cheap=json.loads((p/'analysis.json').read_bytes())
data=json.loads((p/'resource-games.json').read_bytes());assert data['complete'] and len(data['rows'])==24
def key(r):return (r['seed'],r['opening'],tuple(r['policies']))
def label(t):return 'no_event_yet' if t['status']=='ongoing' else 'draw' if t['winner'] is None else 'owner0_win' if t['winner']==0 else 'owner0_loss'
curves=[]
for h in (24,48,96):
 status=Counter();cost=Counter();paths=set()
 for r in data['rows']:
  assert r['complete'];steps=r['steps'][:h];term=steps[-1]['state']['terminal_status'] if steps else r['initial']['terminal_status'];status[term['status']]+=1
  if term['status']!='ongoing':paths.add(json.dumps([r['seed'],r['opening'],[s['action'] for s in steps]],sort_keys=True))
  for s in steps:
   for n in ('nodes','qnodes','evaluation_calls','evaluation_seconds','legal_generation_calls','legal_generation_seconds'):cost[n]+=s['decision'][n]
  cost['played_plies']+=len(steps)
 curves.append(dict(plies=h,status=dict(status),distinct_terminal_trajectories=len(paths),costs=dict(cost)))
old={key(r):r for r in cheap['rows']};pairs=[];changes=Counter()
for r in data['rows']:
 a=old[key(r)];before=label(a['terminal']);after=label(r['terminal']);changes[before+' -> '+after]+=1
 pairs.append(dict(seed=r['seed'],opening=r['opening'],policies=r['policies'],cheap=before,resource=after,changed=before!=after,cheap_plies=a['plies'],resource_plies=len(r['steps']),resource_terminal=r['terminal']))
out=dict(scope=__doc__,games=24,seconds=data['seconds'],curves=curves,matched_event_transitions=dict(changes),changed_cells=sum(r['changed'] for r in pairs),pairs=pairs,limits='Exposed matched diagnostic, no policy selection, WDL or strength inference. Terminal time and bounded teacher caches/time change with resource. Costs are descriptive local measurements, categories not disjoint.')
(p/'resource-analysis.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:out[k] for k in ('seconds','curves','matched_event_transitions','changed_cells')},indent=2))
