"""Exploratory matched-resource terminal sensitivity, not strength or model selection.
Four new frozen rules2122-2125, original openings0/4, three policy pairs each:
Unit/Unit, Full/Unit, Unit/Full. Up to96 additional legal plies per game.
CommonD4/8192nodes/1sec/q0/Unit ordering; no NNUE/refit/default changes.
Only actual terminal status gives reward. Ply caps are CENSORED, never draws.
Question: can cheap full-rule trajectories provide terminal rather than
Unit-compression labels? Keep policy dependence, early-terminal openings,
all failures/zeros and costs. Expected<45min; same four rules and all24cells, no winning-policy selection, no outcome-based extension.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib,statistics
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009')),str(Path('.local_agent/predictor-transfer-20261009'))]
from ledger import FrozenLedger
from test_rectangular_search_override import UnitEvaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'resource-games.json';assert not out.exists();d=json.loads((p/'signal-declaration.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes())
write_record(p/'resource-game-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules_sha256=hashlib.sha256((p/'signal-declaration.json').read_bytes()).hexdigest(),model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),openings=[0,4],policies=[['unit','unit'],['full','unit'],['unit','full']],max_plies=96,observation_checkpoints=[24,48,96],limits=dict(depth=4,nodes=8192,seconds=1,q=0,qhard=8),no_training=True))
rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));ledger=FrozenLedger(c,m);scale=100/statistics.median(abs(ledger.current[t]+ledger.base[t]) for t in ledger.current if not c.support.type_metadata[t].is_anchor)
 class Leaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind
  def evaluate(self,state):
   if self.kind=='unit':return super().evaluate(state)
   raw=round(scale*ledger.full(state.position)*(1 if state.position.side_to_move==0 else -1));return max(-500000,min(500000,raw))
 for opening in (0,4):
  for kinds in (('unit','unit'),('full','unit'),('unit','full')):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
   s=GameSession(c)
   for raw in case['route'][:opening]:s.submit(action_from_dict(raw))
   row=dict(seed=case['seed'],opening=opening,policies=kinds,initial=record_value(s.state),steps=[],complete=False);t=time.perf_counter();players=[AlphaBetaPlayer(c,evaluator_override=Leaf(k),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)) for k in kinds]
   for ply in range(96):
    if s.state.terminal_status.is_terminal:break
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
    before=s.state;side=before.position.side_to_move;tick=time.perf_counter();decision=players[side].choose_action(s,SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,decision);assert s.state==before
    assert decision.action is not None
    s.submit(decision.action);row['steps'].append(dict(ply=ply,side=side,decision=record_value(decision),action=action_to_dict(decision.action),seconds=time.perf_counter()-tick,state=record_value(s.state)))
   term=s.state.terminal_status;row.update(complete=True,seconds=time.perf_counter()-t,terminal=record_value(term),classification='TERMINAL' if term.is_terminal else 'CENSORED',owner0_reward=(0 if term.winner is None else 1 if term.winner==0 else -1) if term.is_terminal else None);rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
   print(case['seed'],opening,kinds,len(row['steps']),row['classification'],row['terminal'],round(row['seconds'],3),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True))
