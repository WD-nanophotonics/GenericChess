"""Preserve prospective denominators, actual terminals and external-censor curves."""
from pathlib import Path
import json,hashlib
from collections import Counter
p=Path(__file__).parent;d=json.loads((p/'signal-games.json').read_bytes());assert d['complete']
rows=d['rows'];assert len(rows)==24
def curve(h):
 status=Counter();cost=Counter();terminal_keys=set()
 for r in rows:
  steps=r['steps'][:h];term=r['initial']['terminal_status'] if not steps else steps[-1]['state']['terminal_status']
  k=term['status'];status[k]+=1
  if k!='ongoing':terminal_keys.add(json.dumps([r['seed'],r['opening'],[s['action'] for s in steps]],sort_keys=True))
  for s in steps:
   for name in ('nodes','qnodes','evaluation_calls','evaluation_seconds','legal_generation_calls','legal_generation_seconds'):cost[name]+=s['decision'][name]
  cost['played_plies']+=len(steps)
 return dict(plies=h,status=dict(status),distinct_terminal_trajectories=len(terminal_keys),costs=dict(cost))
for r in rows:
 assert r['complete']
 t=r['terminal'];assert (t['status']=='ongoing')==(r['owner0_reward'] is None)
 if r['owner0_reward'] is not None:assert r['owner0_reward']==(0 if t['winner'] is None else 1 if t['winner']==0 else -1)
out=dict(scope=__doc__,games=24,seconds=d['seconds'],curves=[curve(h) for h in (24,48,96)],rows=[{k:r[k] for k in ('seed','opening','policies','terminal','owner0_reward','classification','seconds')}|{'plies':len(r['steps'])} for r in rows],producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(p/'analysis.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps({k:out[k] for k in ('games','seconds','curves')},indent=2))
