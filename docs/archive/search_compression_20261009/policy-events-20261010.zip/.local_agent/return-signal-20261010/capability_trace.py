"""Trace one supported pooled-input alias to existing compiled dependencies.
This is a resolved provenance table, not a feature encoder, legality replacement
or utility improvement. Keep region and precondition linked instead of pooling
each independently. It does not cover all rule effects/history semantics.
"""
from pathlib import Path
import sys,json
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import actor_vectors
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.research_record import record_value
p=Path(__file__).parent;old=json.loads(Path('.local_agent/capability-transfer-20261010/geometry-pooling.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));actors=actor_vectors(c);slots={s.slot_id:s for s in c.ir.aux_slots};rows=[]
for pat in c.ir.patterns:
 if not pat.slot_guards or not pat.square_zone_guards:continue
 guards=[dict(comparison=g.comparison,value=g.value,slot=record_value(slots[g.slot_id])) for g in pat.slot_guards]
 regions=[dict(square_ref=record_value(g.square_ref),relation=g.relation,owner_relative=g.owner_relative,squares=list(c.ir.zones[g.spatial.zone_id].squares)) for g in pat.square_zone_guards]
 effects=record_value(pat.effects)
 rows.append(dict(pattern_id=pat.pattern_id,actor_descriptors=[actors[t].tolist() for t in pat.type_ids],guards=guards,regions=regions,effects=effects,other_state_guards=record_value(pat.guards),target=record_value(pat.target)))
assert len(rows)==2 and rows[0]['actor_descriptors']==rows[1]['actor_descriptors'] and rows[0]['regions']!=rows[1]['regions']
for gate_row in old['rows']:
 active=[r for r in rows if all(g['comparison']=='eq' and g['value']==gate_row['gate'] for g in r['guards'])];assert len(active)==1
 destinations={a['to'][1]*8+a['to'][0] for a in gate_row['drops']};region=set(active[0]['regions'][0]['squares']);assert destinations==region
out=dict(scope=__doc__,rows=rows,original_264_alias=True,active_linked_regions_distinguish=True,actual_four_drop_destinations_verified_per_gate=True,decision='Retain pattern-to-precondition-to-region/effect linkage in any future scoped adapter; no extra model or task backlog.')
(p/'capability-trace.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print('Two actual enabled patterns retain distinct four-square regions; actor descriptors equal')
