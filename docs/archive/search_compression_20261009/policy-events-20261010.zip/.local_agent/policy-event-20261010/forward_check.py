"""Replay every actual game state and verify four-head folding, no search fit."""
from pathlib import Path
import sys,json,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009')),str(Path('.local_agent/predictor-transfer-20261009'))]
from fold import EventLedger,probabilities
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from scripts.research_record import record_value
p=Path(__file__).parent;load=lambda n:json.loads((p/n).read_bytes());m=load('model.json');plan=load('signal-declaration.json');data=load('signal-games.json');assert data['complete'];assert not (p/'forward-check.json').exists();cases={c['seed']:c for c in plan['rules']};checked=0;error=0;prob_error=0;start=time.perf_counter();snapshots=[];keys=[];wanted={(r['game'],r['snapshot']) for r in load('fit-result.json')['rows']}
for gi,row in enumerate(data['rows']):
 case=cases[row['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));e=InteractionProjection(c);ledger=EventLedger(c,m);s=GameSession(c)
 for a in case['route'][:row['opening']]:s.submit(action_from_dict(a))
 assert record_value(s.state)==row['initial']
 for i,step in enumerate(row['steps']):
  if (gi,i) in wanted:snapshots.append(np.r_[e.encode(s.state.position),(96-i)/96]);keys.append((gi,i))
  x=np.r_[e.encode(s.state.position)[m['count_columns']],(96-i)/96];z=np.r_[(x[m['columns']]-m['mean'])/m['scale'],1];a=z@np.asarray(m['weights']);b=ledger.logits(s.state.position,96-i);error=max(error,float(np.abs(a-b).max()));prob_error=max(prob_error,float(np.abs(probabilities(a)-probabilities(b)).max()));checked+=1
  s.submit(action_from_dict(step['action']));assert record_value(s.state)==step['state']
 assert record_value(s.state.terminal_status)==row['terminal']
assert error<1e-10 and prob_error<1e-10
assert keys==[(r['game'],r['snapshot']) for r in load('fit-result.json')['rows']]
np.savez_compressed(p/'full-snapshot-inputs.npz',features=np.asarray(snapshots))
out=dict(scope=__doc__,states_checked=checked,max_logit_error=error,max_probability_error=prob_error,seconds=time.perf_counter()-start,model_sha256=hashlib.sha256((p/'model.json').read_bytes()).hexdigest(),all_full_state_history_replays_match=True,limits='Numerical equivalence only; unknown eventual WDL remains unknown; no utility or performance claim.')
(p/'forward-check.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(out,indent=2))
