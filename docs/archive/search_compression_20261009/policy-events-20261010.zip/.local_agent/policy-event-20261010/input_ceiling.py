"""Post-result exact numerical alias floor for the declared four-event task.
Descriptive unconstrained class oracle, not a fitted deployed predictor, linear
capacity bound, new validation score or invitation to fit exposed report labels.
Exact float bytes only; near-equal ungrouped inputs can hide further aliases.
Spatial moments are existing features, not full aux/history/rule representation.
"""
from pathlib import Path
import json
import numpy as np
p=Path(__file__).parent;result=json.loads((p/'fit-result.json').read_bytes());a=np.load(p/'inputs.npz');full=np.load(p/'full-snapshot-inputs.npz')['features'];y=np.eye(4)[a['labels']];rows=result['rows'];out=[]
for scope in ('all','train','dev','report'):
 mask=np.asarray([scope=='all' or r['group']==scope for r in rows]);weights=a['weights'][mask];weights/=weights.sum()
 for name,x in (('count_remaining',a['features']),('moments_remaining',full)):
  groups={}
  for i,v in enumerate(x[mask]):groups.setdefault(v.tobytes(),[]).append(i)
  floor=0;conflicts=[]
  for ids in groups.values():
   w=weights[ids];target=y[mask][ids];prob=(w[:,None]*target).sum(0)/w.sum();floor+=float(w@np.square(target-prob).sum(1))
   if len({int(a['labels'][mask][i]) for i in ids})>1:conflicts.append(dict(rows=[int(np.flatnonzero(mask)[i]) for i in ids],labels=a['labels'][mask][ids].tolist(),weight=float(w.sum())))
  out.append(dict(scope=scope,input=name,rows=int(mask.sum()),distinct_exact_vectors=len(groups),empirical_brier_floor=floor,conflicting_groups=conflicts))
assert not (p/'input-ceiling.json').exists();(p/'input-ceiling.json').write_bytes((json.dumps(dict(scope=__doc__,rows=out),indent=2)+'\n').encode());print(json.dumps([{k:v for k,v in r.items() if k!='conflicting_groups'}|{'conflicts':len(r['conflicting_groups'])} for r in out],indent=2))
