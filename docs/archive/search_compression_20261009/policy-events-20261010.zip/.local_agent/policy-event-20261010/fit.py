"""Small predeclared four-class finite-policy event fit; not WDL or leaf utility."""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
p=Path(__file__).parent;load=lambda name:json.loads((p/name).read_bytes())
decl=load('fit-declaration.json');data=load('signal-games.json');assert data['complete'] and len(data['rows'])==16
assert not (p/'fit-result.json').exists()
rules={r['seed']:r for r in load('signal-declaration.json')['rules']};cols=list(range(66))+list(range(396,462))+list(range(792,924))+[924,930,936,937]
xs=[];labels=[];records=[];weights=[]
for gi,row in enumerate(data['rows']):
 assert row['policies']==['unit','unit'] and row['complete']
 if row['terminal']['status']=='ongoing':assert len(row['steps'])==96
 c=compile_ruleset_for_execution(ruleset_from_dict(rules[row['seed']]['rules']));e=InteractionProjection(c);s=GameSession(c)
 for a in rules[row['seed']]['route'][:row['opening']]:s.submit(action_from_dict(a))
 term=row['terminal'];label=3 if term['status']=='ongoing' else 2 if term['winner'] is None else 0 if term['winner']==0 else 1
 group=next(k for k in ('train','dev','report') if row['seed'] in decl[k]);lo=len(xs)
 for i in range(min(13,len(row['steps']))):
  assert not s.state.terminal_status.is_terminal
  if i in decl['snapshot_plies']:
   xs.append(np.r_[e.encode(s.state.position)[cols],(96-i)/96]);labels.append(label);records.append(dict(game=gi,seed=row['seed'],opening=row['opening'],snapshot=i,group=group,label=label))
  s.submit(action_from_dict(row['steps'][i]['action']))
 assert len(xs)>lo
 weights.extend([1/(len(xs)-lo)]*(len(xs)-lo))
x=np.asarray(xs);y=np.eye(4)[labels];wgt=np.asarray(weights);train=np.asarray([r['group']=='train' for r in records]);chosen=np.flatnonzero(np.ptp(x[train],axis=0)>0);mean=x[train][:,chosen].mean(0);scale=x[train][:,chosen].std(0);z=np.c_[((x[:,chosen]-mean)/scale),np.ones(len(x))];wt=wgt[train]/wgt[train].sum();prior=wt@y[train];w=np.zeros((z.shape[1],4));mom=np.zeros_like(w);vel=np.zeros_like(w);tick=time.perf_counter()
def softmax(scores):
 a=np.exp(scores-scores.max(1,keepdims=True));return a/a.sum(1,keepdims=True)
for step in range(1,301):
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-tick<120
 pred=softmax(z[train]@w);grad=z[train].T@(wt[:,None]*(pred-y[train]))+.0001*np.r_[w[:-1],np.zeros((1,4))];mom=.9*mom+.1*grad;vel=.999*vel+.001*grad*grad;w-=.01*(mom/(1-.9**step))/(np.sqrt(vel/(1-.999**step))+1e-8)
prediction=softmax(z@w);baseline=np.tile(prior,(len(x),1));metrics={}
for group in ('train','dev','report')+tuple(str(seed) for seed in sorted(rules)):
 mask=np.asarray([r['group']==group if group in ('train','dev','report') else r['seed']==int(group) for r in records]);pw=wgt[mask]/wgt[mask].sum();metrics[group]=dict(games=len({r['game'] for r,keep in zip(records,mask) if keep}),samples=int(mask.sum()),labels=(pw@y[mask]).tolist())
 for name,pr in (('model',prediction),('prior',baseline)):
  metrics[group][name]=dict(brier=float(pw@np.square(pr[mask]-y[mask]).sum(1)),log_loss=float(pw@(-np.log(np.maximum(pr[mask],1e-12))*y[mask]).sum(1)))
model=dict(scope=__doc__,columns=chosen.tolist(),mean=mean.tolist(),scale=scale.tolist(),weights=w.tolist(),count_columns=cols,classes=decl['classes'],declaration_sha256=hashlib.sha256((p/'fit-declaration.json').read_bytes()).hexdigest())
(p/'model.json').write_bytes((json.dumps(model,indent=2)+'\n').encode());rest=load('model.json');assert np.array_equal(prediction,softmax(np.c_[(x[:,rest['columns']]-rest['mean'])/rest['scale'],np.ones(len(x))]@np.asarray(rest['weights'])))
np.savez_compressed(p/'inputs.npz',features=x,labels=np.asarray(labels),weights=wgt,predictions=prediction,prior=prior)
out=dict(scope=__doc__,complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seconds=time.perf_counter()-tick,metrics=metrics,rows=records,probability_log_floor=1e-12,initialization='deterministic zeros; no stochastic seed used',limitations='Rule-disjoint exploratory split; finite96ply teacher event only. No terminal event yet is not draw or eventual WDL. Count/remaining inputs omit aux/spatial/history/teacher TT memory, all retained in executor. Labels belong to bounded time-limited teacher algorithm with warm per-player TT, not exact stationary policy. No model selection, refit or search deployment.')
(p/'fit-result.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(metrics,indent=2))
