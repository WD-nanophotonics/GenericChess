"""Descriptive scoring-discard cost; exact work controls, no utility inference."""
from pathlib import Path
import json,statistics
from collections import Counter
p=Path(__file__).parent;d=json.loads((p/'forward-callers.json').read_bytes());assert d['complete'] and len(d['rows'])==48
groups={};fields=['action','score','pv','completed_depth','termination_reason','nodes','qnodes','evaluation_calls','legal_generation_calls']
for r in d['rows']:groups.setdefault((r['seed'],r['opening']),{})[r['arm']]=r
rows=[]
for k,v in groups.items():
 base=v['unit'];others=[]
 for arm in ('encoder_discard','folded_discard'):
  r=v[arm];a=base['decision'];b=r['decision'];others.append(dict(arm=arm,signature_equal=all(a.get(f)==b.get(f) for f in fields),differences=[f for f in fields if a.get(f)!=b.get(f)],wall_ratio=r['seconds']/base['seconds'],scoring_seconds=b['evaluation_seconds']))
 rows.append(dict(seed=k[0],opening=k[1],comparisons=others))
arms={}
for arm in ('unit','encoder_discard','folded_discard'):
 rs=[r for r in d['rows'] if r['arm']==arm];arms[arm]=dict(calls=len(rs),seconds=sum(r['seconds'] for r in rs),evaluation_seconds=sum(r['decision']['evaluation_seconds'] for r in rs),nodes=sum(r['decision']['nodes'] for r in rs),evaluation_calls=sum(r['decision']['evaluation_calls'] for r in rs),stops=dict(Counter(r['decision']['termination_reason'] for r in rs)))
out=dict(scope=__doc__,arms=arms,pairs=rows,matched_work_pairs=sum(c['signature_equal'] for r in rows for c in r['comparisons']),median_wall_ratios={arm:statistics.median(c['wall_ratio'] for r in rows for c in r['comparisons'] if c['arm']==arm) for arm in ('encoder_discard','folded_discard')},limits='Cold rotated-arm local timings; categories overlap, constructor not benchmarked, probabilities discarded. Hypothetical96remaining fixed for cost, no live target/leaf semantics or playing gain.')
(p/'caller-analysis.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in out.items() if k!='pairs'},indent=2))
