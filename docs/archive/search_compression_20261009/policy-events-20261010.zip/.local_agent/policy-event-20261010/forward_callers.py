"""Matched scoring-discard event-predictor overhead, no numeric leaf adoption.
Sixteen new rule/opening roots, three cold Core arms; Unit leaves/order remain.
D4/2048nodes/10sec/q0/hard8. Scores are extracted then discarded. No value,
strength or generic-history sufficiency claim. Expected<10min, keep all caps.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009')),str(Path('.local_agent/predictor-transfer-20261009'))]
from fold import EventLedger,probabilities
from prototype import InteractionProjection
from test_rectangular_search_override import UnitEvaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;m=json.loads((p/'model.json').read_bytes());plan=json.loads((p/'signal-declaration.json').read_bytes());out=p/'forward-callers.json';assert not out.exists();write_record(p/'forward-caller-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),model_sha256=hashlib.sha256((p/'model.json').read_bytes()).hexdigest(),arms=['unit','encoder_discard','folded_discard'],openings=[0,4],remaining_horizon=96,limits=dict(depth=4,nodes=2048,seconds=10,q=0,qhard=8)))
rows=[];start=time.perf_counter()
for case in plan['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));e=InteractionProjection(c);ledger=EventLedger(c,m)
 class Leaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind
  def evaluate(self,state):
   if self.kind=='encoder_discard':
    x=np.r_[e.encode(state.position)[m['count_columns']],1];z=np.r_[(x[m['columns']]-m['mean'])/m['scale'],1];probabilities(z@np.asarray(m['weights']))
   elif self.kind=='folded_discard':probabilities(ledger.logits(state.position,96))
   return super().evaluate(state)
 for opening in (0,4):
  s=GameSession(c)
  for a in case['route'][:opening]:s.submit(action_from_dict(a))
  arms=['unit','encoder_discard','folded_discard'];shift=(case['seed']+opening)%3;arms=arms[shift:]+arms[:shift]
  for arm in arms:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;player=AlphaBetaPlayer(c,evaluator_override=Leaf(arm),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=2048,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,decision);assert before==s.state
   rows.append(dict(seed=case['seed'],opening=opening,arm=arm,seconds=time.perf_counter()-tick,decision=record_value(decision)));write_record(out,dict(scope=__doc__,rows=rows,complete=False));print(case['seed'],opening,arm,decision.completed_depth,decision.termination_reason,flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True))
