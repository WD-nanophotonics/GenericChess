"""Diagnose balanced signed-count context loss without fitting exposed labels.
Append untrained unsigned current/base mechanical actor totals (132 axes).
This asks whether the observed cross-rule exact alias loses rule/stock context,
not whether these axes improve prediction. All auxiliary/history exclusions
remain. Verify type-name renaming on actual recorded early trajectories.
"""
from pathlib import Path
import sys,json,time
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import actor_vectors
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
p=Path(__file__).parent;load=lambda n:json.loads((p/n).read_bytes());plan=load('signal-declaration.json');games=load('signal-games.json');fit=load('fit-result.json');old=np.load(p/'inputs.npz');wanted={(r['game'],r['snapshot']) for r in fit['rows']};cases={r['seed']:r for r in plan['rules']};features=[];keys=[];max_error=0;start=time.perf_counter()
def remap(x,names):
 if isinstance(x,str):return names.get(x,x)
 if isinstance(x,list):return [remap(v,names) for v in x]
 if isinstance(x,dict):return {remap(k,names):remap(v,names) for k,v in x.items()}
 return x
def encode(pos,actors):
 x=np.zeros(132)
 for v in pos.board:
  if v is not None:x[:66]+=actors[v.current_type_id];x[66:]+=actors[v.base_type_id]
 return x
def actionkey(a,names):
 r=remap(action_to_dict(a),names);return json.dumps({k:v for k,v in r.items() if k not in ('pattern_id','geometry_id')},sort_keys=True)
for gi,row in enumerate(games['rows']):
 case=cases[row['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));names={t['type_id']:'Renamed_'+t['type_id'] for t in case['rules']['piece_types']};reverse={v:k for k,v in names.items()};rc=compile_ruleset_for_execution(ruleset_from_dict(remap(case['rules'],names)));s=GameSession(c);rs=GameSession(rc);aa=actor_vectors(c);bb=actor_vectors(rc)
 def submit(a):
  k=actionkey(a,{});matches=[b for b in rs.legal_actions() if actionkey(b,reverse)==k];assert len(matches)==1;s.submit(a);rs.submit(matches[0]);assert s.state.terminal_status==rs.state.terminal_status
 for raw in case['route'][:row['opening']]:submit(action_from_dict(raw))
 for i in range(min(13,len(row['steps']))):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<120
  if (gi,i) in wanted:
   a=encode(s.state.position,aa);b=encode(rs.state.position,bb);max_error=max(max_error,float(np.abs(a-b).max()));assert np.allclose(a,b,atol=1e-12,rtol=0);features.append(a);keys.append((gi,i))
  submit(action_from_dict(row['steps'][i]['action']))
assert keys==[(r['game'],r['snapshot']) for r in fit['rows']]
x=np.c_[old['features'],features];groups={}
for i,v in enumerate(x):groups.setdefault(v.tobytes(),[]).append(i)
w=old['weights']/old['weights'].sum();y=np.eye(4)[old['labels']];floor=0;conflicts=[]
for ids in groups.values():
 ww=w[ids];prob=(ww[:,None]*y[ids]).sum(0)/ww.sum();floor+=float(ww@np.square(y[ids]-prob).sum(1))
 if len(set(old['labels'][ids]))>1:conflicts.append(ids)
original=next(r for r in load('input-ceiling.json')['rows'] if r['scope']=='all' and r['input']=='count_remaining')['conflicting_groups'];alias=[]
for g in original:
 ids=g['rows'];alias.append(dict(records=[fit['rows'][i] for i in ids],signed_input_equal=all(np.array_equal(old['features'][ids[0]],old['features'][i]) for i in ids),unsigned_distinct=len({np.asarray(features[i]).tobytes() for i in ids}),unsigned_l2=[[float(np.linalg.norm(features[i]-features[j])) for j in ids] for i in ids]))
np.savez_compressed(p/'context-inputs.npz',features=np.asarray(features))
out=dict(scope=__doc__,rows=len(features),augmented_axes=401,distinct_exact_vectors=len(groups),empirical_brier_floor=floor,conflicting_groups=conflicts,old_aliases=alias,type_rename_max_error=max_error,actual_early_trajectory_renames_checked=True,seconds=time.perf_counter()-start,decision='Untrained rule/stock context probe only; no new model, refit or utility deployment. Lack of exact aliases does not imply learnability or complete semantics.')
assert not (p/'context-alias.json').exists();(p/'context-alias.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out,indent=2))
