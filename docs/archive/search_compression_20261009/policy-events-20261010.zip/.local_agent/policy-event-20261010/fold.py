"""Exact offline folding of four frozen affine event logits, not utility."""
import numpy as np
from ledger import FrozenLedger
class EventLedger:
 def __init__(self,c,m):
  self.heads=[];self.extra=[];ix=np.asarray(m['columns']);mu=np.asarray(m['mean']);sc=np.asarray(m['scale']);w=np.asarray(m['weights']);mask=ix<268
  assert all(i<=268 for i in ix)
  for h in range(4):
   self.heads.append(FrozenLedger(c,dict(columns=ix[mask],mean=mu[mask],scale=sc[mask],weights=w[:-1,h][mask],count_columns=m['count_columns'])))
   ti=np.flatnonzero(ix==268);self.extra.append((float(w[-1,h]),float(w[ti[0],h]/sc[ti[0]]) if len(ti) else 0,float(mu[ti[0]]) if len(ti) else 0))
 def logits(self,pos,remaining):return np.asarray([head.full(pos)+bias+weight*(remaining/96-mean) for head,(bias,weight,mean) in zip(self.heads,self.extra)])
def probabilities(logits):
 a=np.exp(logits-np.max(logits));return a/a.sum()
