"""Untrained rule-conditioned spatial moments. No generated labels or live model.

Mechanical 66-axis actor descriptors retain the prior explicit-target scope.
The projection keeps current/base actors separately, base hands, promoted
moments and side. It is not injective: precise guards/auxiliary semantics and
history are omitted from shared numerical axes. Full Position encoding and
GameState remain separate carriers; this is not permission to discard them.
"""
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0, str(Path.cwd()))
sys.path.insert(0, str(Path('.local_agent/sharing-20261009')))
from rule_counts import descriptors, AXES
from scripts.position_features import SparsePositionEncoder

def actor_vectors(c):
    old, _ = descriptors(c)
    keep = [i for i in range(20) if AXES[i] != 'promotion_targets'] + [35, 36]
    base = {}
    for tid, values in old.items():
        drops = [p for p in c.ir.patterns if tid in p.type_ids and
                 any(c.ir.geometry[g].kind == 'drop' for g in p.geometry_ids)]
        possible = any(any(mask) for mask in c.support.drop_allowed.get(tid, ())) and any(
            not any(g.aggregation == 'count' and g.comparison == 'lt' and g.value <= 0
                    for g in p.guards) for p in drops)
        base[tid] = np.concatenate((values[keep], [float(possible and not
                                      c.support.type_metadata[tid].is_anchor)]))
    result = {}
    for tid in old:
        targets = set(c.support.type_metadata[tid].promotion_target_ids)
        for p in c.ir.patterns:
            if tid not in p.type_ids:
                continue
            for e in p.effects:
                if e.kind == 'set_current_type' and e.type_ref is not None and e.type_ref.kind == 'explicit':
                    targets.add(e.type_ref.type_id)
        values = np.asarray([base[t] for t in sorted(targets)])
        result[tid] = np.concatenate((base[tid], values.mean(0) if len(values) else np.zeros(22),
                                      values.max(0) if len(values) else np.zeros(22)))
    return result

class InteractionProjection:
    dimension = 938  # 2 actor identities * 6 moments * 66 + 2 hands * 66 + 12 promoted + 2 side
    def __init__(self, c):
        self.fingerprint = c.ruleset_fingerprint
        self.shape = c.board_shape
        self.actors = actor_vectors(c)
        self.carrier = SparsePositionEncoder(c)
        # Lookup assembled once, not once per search leaf. Owner-relative y,
        # owner-signed terms, without numeric type IDs or symbol names as axes.
        self.board = {}
        self.promoted = {}
        for owner in (0, 1):
            for square in range(self.shape.area):
                x = 2 * (square % self.shape.width) / max(1, self.shape.width - 1) - 1
                y = 2 * (square // self.shape.width) / max(1, self.shape.height - 1) - 1
                if owner == 1:
                    y = -y
                moments = np.array([1, x, y, x*x, y*y, x*y])
                sign = 1 if owner == 0 else -1
                self.promoted[owner, square] = moments
                for tid, actor in self.actors.items():
                    self.board[owner, square, tid] = (sign * np.outer(moments, actor)).reshape(-1)
    def encode(self, position):
        if position.ruleset_fingerprint != self.fingerprint or position.board_shape != self.shape:
            raise ValueError('wrong compiled carrier')
        result = np.zeros(self.dimension)
        for square, piece in enumerate(position.board):
            if piece is None:
                continue
            result[:396] += self.board[piece.owner, square, piece.current_type_id]
            result[396:792] += self.board[piece.owner, square, piece.base_type_id]
            if piece.promoted:
                begin = 924 + 6 * piece.owner
                result[begin:begin+6] += self.promoted[piece.owner, square]
        for owner, hand in enumerate(position.hands):
            for tid, count in hand.counts:
                result[792+66*owner:858+66*owner] += count*self.actors[tid]
        result[936+position.side_to_move] = 1
        return result
