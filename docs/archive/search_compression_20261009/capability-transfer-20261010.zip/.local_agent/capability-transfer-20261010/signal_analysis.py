"""Summarize actual terminals and paired policy divergence, without imputation."""
from pathlib import Path
import json
from collections import Counter
p=Path(__file__).parent
d=json.loads((p/'signal-games.json').read_bytes());assert d['complete']
rows=d['rows'];assert len(rows)==12
counts=Counter();costs=Counter();details=[]
for r in rows:
 assert r['complete']
 status=r['terminal']['status'];reward=r['owner0_reward']
 if r['classification']=='CENSORED':assert status=='ongoing' and reward is None
 else:assert status!='ongoing' and reward==(0 if r['terminal']['winner'] is None else 1 if r['terminal']['winner']==0 else -1)
 counts[status]+=1
 for s in r['steps']:
  for k in ('nodes','qnodes','evaluation_calls','evaluation_seconds','legal_generation_calls','legal_generation_seconds'):costs[k]+=s['decision'][k]
 details.append({k:r[k] for k in ('seed','opening','policies','classification','terminal','owner0_reward','seconds')}|{'plies':len(r['steps'])})
paired=[]
for seed in sorted({r['seed'] for r in rows}):
 for opening in (0,4):
  a=next(r for r in rows if r['seed']==seed and r['opening']==opening and r['policies']==['unit','unit'])
  b=next(r for r in rows if r['seed']==seed and r['opening']==opening and r['policies']==['unit','full'])
  first=next((i for i,(x,y) in enumerate(zip(a['steps'],b['steps'])) if x['action']!=y['action']),None)
  paired.append(dict(seed=seed,opening=opening,first_action_divergence=first,shared_prefix_plies=min(len(a['steps']),len(b['steps'])) if first is None else first,unit_status=a['terminal']['status'],full_owner1_status=b['terminal']['status'],actions=None if first is None else [a['steps'][first]['action'],b['steps'][first]['action']]))
out=dict(scope=__doc__,games=12,played_plies=sum(len(r['steps']) for r in rows),seconds=d['seconds'],status_counts=dict(counts),costs=dict(costs),rows=details,paired=paired,decision='No fit: immediate mate labels repeat one opening, repetition labels depend on policy, and five external cuts are unknown. Declare a fresh signal/sampling premise before training; no rank-score bootstrap or ongoing=draw imputation.')
(p/'signal-summary.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
print(json.dumps(out,indent=2))
