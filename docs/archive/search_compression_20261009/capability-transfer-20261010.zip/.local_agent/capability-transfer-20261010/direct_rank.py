"""Read-only original-route direct ranks; uncalibrated score and rounded scale.
Reuse34existing full-history UnitD2references, no labels regenerated/refitted.
Terminal wins/losses have priority; draws0, same prior wrapper convention.
Exact and1e-8qualified ties are retained, no favorable tie chosen after outcome.
Full-quarter/full/full-four differ by positive scale before rounding only;
rounding can add ties. Conditional symmetry remains a separate scoped model.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,statistics
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('.local_agent/interaction-20261009')),str(Path('.local_agent/predictor-transfer-20261009'))]
from ledger import FrozenLedger
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'direct-rank.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());m=json.loads(Path('.local_agent/preference-20261009/partial2048-model.json').read_bytes());refs=json.loads((p/'original-reference.json').read_bytes());rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));ledger=FrozenLedger(c,m);scale=100/statistics.median(abs(ledger.current[t]+ledger.base[t]) for t in ledger.current if not c.support.type_metadata[t].is_anchor);s=GameSession(c)
 for ply in range(len(case['route'])+1):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  rr=next(r for r in refs['rows'] if (r['seed'],r['ply'])==(case['seed'],ply));owner=s.state.position.side_to_move;sign=1 if owner==0 else -1;cells=[]
  for r in rr['children']:
   a=action_from_dict(r['action']);ch=apply_action(s.state,a,c);term=ch.terminal_status;raw=sign*ledger.full(ch.position);sym=sign*ledger.symmetric(ch.position);priority=1 if term.is_terminal and term.winner==owner else -1 if term.is_terminal and term.winner is not None else 0
   values=dict(full=raw,symmetric=sym,full_quarter_rounded=round(.25*scale*raw),full_rounded=round(scale*raw),full_four_rounded=round(4*scale*raw))
   if term.is_terminal and term.winner is None:values={k:0 for k in values}
   cells.append(dict(action=r['action'],teacher=r['teacher'],priority=priority,values=values,terminal=record_value(term)))
  best=max(z['teacher'] for z in cells);arms={}
  for name in cells[0]['values']:
   pr=max(z['priority'] for z in cells);hi=max(z['values'][name] for z in cells if z['priority']==pr);qualified=[i for i,z in enumerate(cells) if z['priority']==pr and abs(z['values'][name]-hi)<=1e-8];exact=[i for i,z in enumerate(cells) if (z['priority'],z['values'][name])==(pr,hi)];loss=[best-cells[i]['teacher'] for i in qualified];arms[name]=dict(exact_chosen=exact,qualified_chosen=qualified,losses=loss,all_optimal=all(x==0 for x in loss),any_optimal=any(x==0 for x in loss))
  rows.append(dict(seed=case['seed'],ply=ply,scale=scale,arms=arms,children=cells));
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
summary={a:dict(all_optimal=sum(r['arms'][a]['all_optimal'] for r in rows),any_optimal=sum(r['arms'][a]['any_optimal'] for r in rows),roots=len(rows)) for a in rows[0]['arms']}
write_record(out,dict(scope=__doc__,rows=rows,summary=summary,seconds=time.perf_counter()-start,complete=True));print(summary)
