"""Untrained finite bool-guarded drop capability probe, not full generic input.

Axes use existing mechanical actor descriptors, not names or slot ordinals.
Two owners x (current / passive expiry reset) x66 axes. Weight by actual
base hand stock. Passive reset is a declared no-aux-effect counterfactual,
not prediction of every real action. Other guard/effect/history semantics
remain in full RuleSet/GameState; excluded patterns are counted explicitly.
This records possible inventory/precondition support, not legal move count,
mobility, calibrated utility, or a proposed live evaluation patch.
"""
import numpy as np
from prototype import actor_vectors

class BoolDropCapability:
    def __init__(self,c):
        self.c=c
        self.actors=actor_vectors(c)
        self.slots={s.slot_id:s for s in c.ir.aux_slots}
        self.patterns=[];self.excluded=[]
        for p in c.ir.patterns:
            if not p.slot_guards:continue
            if not any(c.ir.geometry[g].kind=='drop' for g in p.geometry_ids):
                self.excluded.append((p.pattern_id,'non-drop'));continue
            if any(g.square_ref is not None or self.slots[g.slot_id].value_kind!='bool'
                   or g.comparison not in ('eq','ne','lt','le','gt','ge') for g in p.slot_guards):
                self.excluded.append((p.pattern_id,'non-bool or unsupported comparison'));continue
            self.patterns.append(p)
    @staticmethod
    def compare(a,op,b):
        if op=='eq':return a==b
        if op=='ne':return a!=b
        if op=='lt':return a<b
        if op=='le':return a<=b
        if op=='gt':return a>b
        if op=='ge':return a>=b
        raise ValueError(op)
    def permission(self,pos,p,owner,reset):
        aux=dict(pos.aux_state)
        for g in p.slot_guards:
            slot=self.slots[g.slot_id];key=(slot.slot_id,-1 if slot.scope=='global' else owner)
            value=slot.initial if reset and slot.lifetime=='expire_next_turn' else aux.get(key,slot.initial)
            if not self.compare(value,g.comparison,g.value):return False
        return True
    def encode(self,pos):
        if pos.ruleset_fingerprint!=self.c.ruleset_fingerprint:raise ValueError('wrong carrier')
        x=np.zeros((2,2,66))
        for owner,h in enumerate(pos.hands):
            inventory=dict(h.counts)
            for phase in (0,1):
                for p in self.patterns:
                    if self.permission(pos,p,owner,phase):
                        for t in p.type_ids:x[owner,phase]+=inventory.get(t,0)*self.actors[t]
        return x.reshape(-1)
