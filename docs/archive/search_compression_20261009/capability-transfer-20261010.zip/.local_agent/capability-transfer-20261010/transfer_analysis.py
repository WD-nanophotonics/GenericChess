"""Recompute prospective gate contrasts by canonical action identity."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'result.json').read_bytes());assert d['complete'];rows=[]
key=lambda a:json.dumps(a['action'],sort_keys=True)
for seed,ply,life in sorted({(r['seed'],r['ply'],r['lifetime']) for r in d['rows']}):
 aa,bb=[next(r for r in d['rows'] if (r['seed'],r['ply'],r['lifetime'],r['gate'])==(seed,ply,life,g)) for g in (0,1)]
 A={key(a):a for a in aa['children']};B={key(a):a for a in bb['children']};common=sorted(A.keys()&B.keys());diff=[dict(action=A[k]['action'],teacher=[A[k]['teacher'],B[k]['teacher']],features_equal=A[k]['feature']==B[k]['feature']) for k in common if A[k]['teacher']!=B[k]['teacher']]
 maxima=[max(a['teacher'] for a in r['children']) for r in (aa,bb)];opts=[{key(a) for a in r['children'] if a['teacher']==best} for r,best in zip((aa,bb),maxima)]
 rows.append(dict(seed=seed,ply=ply,lifetime=life,complete=aa['complete'] and bb['complete'],root_features_equal=aa['root_feature']==bb['root_feature'],legal_sets_equal=A.keys()==B.keys(),common_actions=len(common),differences=diff,teacher_best=maxima,optimal_sets_equal=opts[0]==opts[1]))
write_record(p/'transfer-recomputed.json',dict(scope='Prospective same-rule gate contrasts; zero eligible2119 retained in target-declaration. Complete finite UnitD2, not true value or training.',fronts=len(d['rows']),transitions=sum(r['transitions'] for r in d['rows']),seconds=d['seconds'],rows=rows))
old=json.loads((p/'analysis.json').read_bytes());new=json.loads((p/'transfer-recomputed.json').read_bytes());assert old==new
print('All original transfer arithmetic matches')
