"""Original frozen route full-history UnitD2 reference, all34 roots.
This is a new bounded diagnostic for actual leaf callers, not a stronger
certificate requirement, refit, or extension of their frozen resource budget.
Unlike the gate/lifetime counterfactual fronts, states retain original history.
All legal children; per front20sec/100000transitions, partials remain UNKNOWN.
Expected under5min; changing finite errors versus sensitivity selects next check.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from test_rectangular_search_override import UnitEvaluator
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'original-reference.json';assert not out.exists()
d=json.loads((p/'declaration.json').read_bytes())
write_record(p/'original-reference-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),population='all original34 roots, without score selection',depth=2,seconds=20,transitions=100000))
class Cost(Exception):pass
original=search.legal_successors;rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for ply in range(len(case['route'])+1):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  before=s.state;row=dict(seed=case['seed'],ply=ply,root=record_value(before),children=[],transitions=0,complete=False);t=time.perf_counter()
  def check():
   if time.perf_counter()-t>20 or row['transitions']>100000:raise Cost()
  def successors(state,compiled):
   check()
   for a,ch in original(state,compiled):row['transitions']+=1;check();yield a,ch
  search.legal_successors=successors
  try:
   for a,ch in successors(before,c):
    score,_=search.reference_minimax(ch,1,UnitEvaluator(),c,ply=1);check();row['children'].append(dict(action=action_to_dict(a),teacher=-score))
   row['complete']=True
  except Cost:row['failure']='partial front UNKNOWN'
  finally:search.legal_successors=original
  assert s.state==before;row['seconds']=time.perf_counter()-t;rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
  print(case['seed'],ply,len(row['children']),row['complete'],round(row['seconds'],3),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True))
