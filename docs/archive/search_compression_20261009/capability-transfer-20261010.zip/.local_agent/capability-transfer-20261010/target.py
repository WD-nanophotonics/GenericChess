"""Changed-premise finite auxiliary target: expiry versus persistent right.
Predeclared2114parents4/10 of the two observed gate-enabled immediate Pdrops;
two lifetimes xcurrent gate0/1 =8fresh canonical full-history roots.
Same full board/base/hands/side, correctly rebound to each compiled fingerprint.
Compare all legal children and UnitD2 target;20sec/100000transition checkpoint.
This is exposed mechanistic diagnosis, not prospective utility gain or fitting.
Question: can equal current legal masks hide different next-reply capabilities,
which the original count predictor/folded equivalent cannot represent?
Only slot lifetime changes, no material reward/target/geometry modifications.
"""
from pathlib import Path
from dataclasses import replace
import os
for k in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"):os.environ[k]="1"
import sys,json,time,hashlib,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from test_rectangular_search_override import UnitEvaluator
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record,record_value

p=Path(__file__).parent;out=p/'result.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());prepared=[];eligible=[]
for case in d['rules']:
 rules=ruleset_from_dict(case['rules']);originalc=compile_ruleset_for_execution(rules);s=GameSession(originalc);positions={}
 for ply in range(len(case['route'])+1):
  pos=s.state.position
  if dict(pos.hands[1-pos.side_to_move].counts).get('P',0)>0:positions[ply]=pos
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 variants=[]
 for lifetime in ('expire_next_turn','persistent'):
  changed=replace(rules,semantic_actions=tuple(replace(a,aux_state=tuple(replace(slot,lifetime=lifetime) if slot.name=='temp_right' else slot for slot in a.aux_state)) for a in rules.semantic_actions));c=compile_ruleset_for_execution(changed);variants.append((lifetime,changed,c,InteractionProjection(c)))
 eligible.append(dict(seed=case['seed'],plies=list(positions),rules=[dict(lifetime=life,rules=ruleset_to_dict(r)) for life,r,c,e in variants]));prepared.append((case['seed'],positions,variants))
write_record(p/'target-declaration.json',dict(scope='Prospective all-opponent-Pstock roots, same-rule gates and lifetime counterfactuals; fresh histories explicit; no fit or generic utility claim.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),eligibility=eligible,front_limit_seconds=20,front_limit_transitions=100000,expected_minutes=10))
def fresh(pos,c):
 key=repetition_identity_key(pos,c);counts=((key,1),);h=(HistoryRecord(key,-1,'',False),);return GameState(pos,0,counts,semantic_engine_for(c).terminal_result(pos,0,counts,h),h)
class Cost(Exception):pass
original=search.legal_successors;rows=[];start=time.perf_counter()
for seed,positions,variants in prepared:
 for ply,pos in positions.items():
  for life,rules,c,enc in variants:
   for gate in (0,1):
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
    aux=dict(pos.aux_state);aux[(0,-1)]=gate;st=fresh(replace(pos,ruleset_fingerprint=c.ruleset_fingerprint,aux_state=tuple(sorted(aux.items()))),c);row=dict(seed=seed,ply=ply,gate=gate,lifetime=life,children=[],transitions=0,complete=False,root_feature=enc.encode(st.position).tolist());t=time.perf_counter()
    def check():
     if time.perf_counter()-t>20 or row['transitions']>100000:raise Cost()
    def successors(state,compiled):
     check()
     for a,ch in original(state,compiled):row['transitions']+=1;check();yield a,ch
    search.legal_successors=successors
    try:
     for a,ch in successors(st,c):
      score,_=search.reference_minimax(ch,1,UnitEvaluator(),c,ply=1);check();row['children'].append(dict(action=action_to_dict(a),teacher=-score,feature=enc.encode(ch.position).tolist(),aux=record_value(ch.position.aux_state),terminal=record_value(ch.terminal_status)))
     row['complete']=True
    except Cost:row['failure']='partial front UNKNOWN'
    finally:search.legal_successors=original
    row['seconds']=time.perf_counter()-t;rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
  print(seed,ply,'fronts',len(rows),'seconds',round(time.perf_counter()-start,2),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True,limits='Finite UnitD2 target, fresh-history counterfactual not opening reachability. Existing full semantic executor, no exposed fitting.'))
