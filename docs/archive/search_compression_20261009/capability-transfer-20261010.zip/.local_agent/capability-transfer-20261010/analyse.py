"""Read-only action-linked accounting; preserve partial/complete denominators."""
from pathlib import Path
import json,collections,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record,record_value
from generic_chess.core.actions import action_from_dict
p=Path(__file__).parent
def key(a):return json.dumps(a,sort_keys=True,separators=(',',':'))
def analysis():
 calls=json.loads((p/'callers.json').read_bytes());refs=json.loads((p/'original-reference.json').read_bytes())
 assert calls['complete'] and refs['complete']
 rows=list(calls['rows'])
 for name in ('leaf-controls.json','q1-callers.json'):
  control=p/name
  if control.exists():
   other=json.loads(control.read_bytes())
   if other['complete']:rows=rows+other['rows']
 R={(r['seed'],r['ply']):r for r in refs['rows']};arms={};linked=[]
 for r in rows:
  ref=R[(r['seed'],r['ply'])];d=r['decision'];labels={key(record_value(action_from_dict(c['action']))):c['teacher'] for c in ref['children']};chosen=key(d['action']);regret=None
  if ref['complete'] and labels:
   assert chosen in labels
   regret=max(labels.values())-labels[chosen]
  row=dict(seed=r['seed'],ply=r['ply'],qdepth=r['qdepth'],arm=r['arm'],reference_complete=ref['complete'],regret=regret,action=d['action'],score=d['score'],decision=d,seconds=r['seconds'],leaf_calls=r['leaf_calls'],clips=r['clips']);linked.append(row)
  group=arms.setdefault((r['arm'],r['qdepth']),dict(calls=0,complete_reference=0,finite_errors=0,total_regret=0,depths=collections.Counter(),stops=collections.Counter(),seconds=0,leaf_calls=0,clips=0,work=collections.Counter()))
  group['calls']+=1;group['seconds']+=r['seconds'];group['leaf_calls']+=r['leaf_calls'];group['clips']+=r['clips']
  group['depths'][d['completed_depth']]+=1;group['stops'][d['termination_reason']]+=1
  for metric in ('nodes','qnodes','evaluation_calls','evaluation_seconds','legal_generation_calls','legal_generation_seconds','in_check_qnodes','qsearch_check_hard_limit_aborts','qsearch_budget_aborts'):
   group['work'][metric]+=d[metric]
  if regret is not None:group['complete_reference']+=1;group['finite_errors']+=regret>0;group['total_regret']+=regret
 groups=[dict(arm=a,qdepth=q,**v) for (a,q),v in sorted(arms.items())]
 pairs=[]
 for seed,ply in sorted(R):
  for q in sorted({r['qdepth'] for r in linked}):
   rr={r['arm']:r for r in linked if (r['seed'],r['ply'],r['qdepth'])==(seed,ply,q)}
   pairs.append(dict(seed=seed,ply=ply,qdepth=q,distinct_actions=len({key(r['action']) for r in rr.values()}),arms={a:dict(action=r['action'],regret=r['regret'],score=r['score']) for a,r in rr.items()}))
 result=dict(scope='All original route roots with original history. UnitD2 descriptive finite task, not true utility or utility calibration; rank-score leaf controls exploratory. Original counterfactual gates never substituted for route state.',reference_fronts=len(R),reference_complete=sum(r['complete'] for r in R.values()),reference_transitions=sum(r['transitions'] for r in R.values()),reference_seconds=refs['seconds'],groups=groups,pairs=pairs,linked=linked,complete=True)
 write_record(p/'caller-analysis.json',result)
 print(json.dumps({k:result[k] for k in ('reference_fronts','reference_complete','reference_transitions','reference_seconds','groups')},indent=2))
if __name__=='__main__':analysis()
