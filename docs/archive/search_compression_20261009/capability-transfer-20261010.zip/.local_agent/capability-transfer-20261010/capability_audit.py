"""Untrained capability input and equivalent slot/type representation controls.
Original exposed61aliases are diagnosis only; no coefficients or learning.
Check renamed slot, inert sorted-before slot, renamed P type with remapped full
Position against source carriers. Keep all public legal/child semantics, scopes.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009'))]
from capability import BoolDropCapability
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict,RuleAuxState
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.position import Hands
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'capability-audit.json';assert not out.exists();old=Path('.local_agent/predictor-transfer-20261009');d=json.loads((old/'declaration.json').read_bytes());case=next(r for r in d['rules'] if r['seed']==202610082114);rules=ruleset_from_dict(case['rules']);original=compile_ruleset_for_execution(rules);session=GameSession(original);positions={}
for ply in range(11):
 if ply in (4,10):positions[ply]=session.state.position
 if ply<10:session.submit(action_from_dict(case['route'][ply]))
write_record(p/'capability-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),feature_sha256=hashlib.sha256((p/'capability.py').read_bytes()).hexdigest(),population='Existing exposed2114parents4/10, two gates/two lifetimes; all original common-child labels. No fitting.',renames=['slot name','inert slot shifts active slot ordinal','P type rename']))
def fresh(pos,c):
 key=repetition_identity_key(pos,c);counts=((key,1),);h=(HistoryRecord(key,-1,'',False),);return GameState(pos,0,counts,semantic_engine_for(c).terminal_result(pos,0,counts,h),h)
def actionkey(a):
 r=action_to_dict(a);r={k:v for k,v in r.items() if k not in ('pattern_id','geometry_id')}
 if r.get('base_type_id')=='Z':r['base_type_id']='P'
 if r.get('actor_type_id')=='Z':r['actor_type_id']='P'
 if r.get('promotion_target_id')=='Z':r['promotion_target_id']='P'
 return json.dumps(r,sort_keys=True)
def rename(x):
 if isinstance(x,str):return {'P':'Z','temp_right':'zz_main'}.get(x,x)
 if isinstance(x,list):return [rename(v) for v in x]
 if isinstance(x,dict):return {rename(k):rename(v) for k,v in x.items()}
 return x
rows=[];start=time.perf_counter();source=json.loads((old/'lifetime.json').read_bytes())
for lifetime in ('expire_next_turn','persistent'):
 r=replace(rules,semantic_actions=tuple(replace(a,aux_state=tuple(replace(slot,lifetime=lifetime) if slot.name=='temp_right' else slot for slot in a.aux_state)) for a in rules.semantic_actions));c=compile_ruleset_for_execution(r);cap=BoolDropCapability(c);renamed=ruleset_from_dict(rename(ruleset_to_dict(r)));first=renamed.semantic_actions[0];renamed=replace(renamed,semantic_actions=(replace(first,aux_state=(RuleAuxState('aa_unused','bool','global','persistent',0),)+first.aux_state),)+renamed.semantic_actions[1:]);rc=compile_ruleset_for_execution(renamed);rcap=BoolDropCapability(rc)
 for ply,pos in positions.items():
  states=[];features=[]
  for gate in (0,1):
   aux=dict(pos.aux_state);aux[(0,-1)]=gate;state=fresh(replace(pos,ruleset_fingerprint=c.ruleset_fingerprint,aux_state=tuple(sorted(aux.items()))),c);states.append(state);features.append(cap.encode(state.position))
   board=tuple(None if v is None else replace(v,base_type_id='Z' if v.base_type_id=='P' else v.base_type_id,current_type_id='Z' if v.current_type_id=='P' else v.current_type_id) for v in pos.board);hands=tuple(Hands(tuple(('Z' if tid=='P' else tid,n) for tid,n in h.counts)) for h in pos.hands);rpos=replace(state.position,ruleset_fingerprint=rc.ruleset_fingerprint,board=board,hands=hands,aux_state=(((0,-1),0),((1,-1),gate)));rstate=fresh(rpos,rc);assert np.allclose(features[-1],rcap.encode(rpos),atol=1e-12,rtol=0)
   acts={actionkey(a):a for a in legal_actions(state,c)};racts={actionkey(a):a for a in legal_actions(rstate,rc)};assert acts.keys()==racts.keys();checked=0
   for key,a in acts.items():
    child=apply_action(state,a,c);rchild=apply_action(rstate,racts[key],rc);assert np.allclose(cap.encode(child.position),rcap.encode(rchild.position),atol=1e-12,rtol=0);assert child.terminal_status==rchild.terminal_status;checked+=1
   guardchecks=0
   for owner in (0,1):
    for pat in cap.patterns:
     assert cap.permission(state.position,pat,owner,False)==all(semantic_engine_for(c)._slot_guard_holds(g,state.position,None,owner) for g in pat.slot_guards);guardchecks+=1
   rows.append(dict(lifetime=lifetime,ply=ply,gate=gate,features=features[-1].tolist(),rename_max_error=float(np.max(np.abs(features[-1]-rcap.encode(rpos)))),legal_actions=len(acts),children_checked=checked,guard_conjunction_checks=guardchecks,excluded=cap.excluded))
  aa,bb=[next(rr for rr in source['rows'] if rr['lifetime']==lifetime and rr['ply']==ply and rr['gate']==g) for g in (0,1)];key=lambda a:json.dumps(a['action'],sort_keys=True);A={key(a):a for a in aa['children']};B={key(a):a for a in bb['children']};conflicts=[k for k in A.keys()&B.keys() if A[k]['teacher']!=B[k]['teacher']];separated=0
  for k in conflicts:
   original_actions=[action_from_dict(a['action']) for a in (A[k],B[k])];children=[apply_action(st,a,c) for st,a in zip(states,original_actions)];separated+=not np.array_equal(cap.encode(children[0].position),cap.encode(children[1].position))
  rows.append(dict(lifetime=lifetime,ply=ply,target_conflicts=len(conflicts),capability_separated=separated,root_capability_difference=float(np.linalg.norm(features[0]-features[1]))))
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True,limits='264untrained scoped bool-drop axes; may alias pattern geometry/effects, square tokens, auxiliary updates, history and position interactions. Full generic domain retained in executor; no utility conclusion.'))
print([(r['lifetime'],r['ply'],r['target_conflicts'],r['capability_separated']) for r in rows if 'target_conflicts' in r])
