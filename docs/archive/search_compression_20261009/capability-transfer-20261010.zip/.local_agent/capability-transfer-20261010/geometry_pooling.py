"""One finite counterexample to actor-only capability pooling, no utility fit.
Two supported bool-gated drop patterns for the same actor, disjoint regions.
One pattern enabled in either gate state, so pooled actor/permission descriptors
alias while actual supported legal destination sets differ. Scope includes
existing state/square-zone guards; no new generic modeling framework.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('.local_agent/interaction-20261009'))]
from capability import BoolDropCapability
from rule_semantics_ir_fixtures import nifu_ruleset
from generic_chess.rules.schema import RuleAuxState,RuleSlotGuard,RuleSquareZoneGuard,RuleSpatialSelector,RuleSquareRef,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.position import Hands,GameState,HistoryRecord
from generic_chess.session.session import GameSession
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import action_to_dict
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'geometry-pooling.json';assert not out.exists();rules=nifu_ruleset();base=rules.semantic_actions[0];actions=[]
for gate,file in ((0,1),(1,6)):
 zone=RuleSquareZoneGuard(square_ref=RuleSquareRef('target'),spatial=RuleSpatialSelector(kind='zone',zone_squares=tuple((file,r) for r in (2,3,4,5))),owner_relative=False)
 actions.append(replace(base,name='drop_left' if gate==0 else 'drop_right',slot_guards=(RuleSlotGuard('switch',value=gate),),aux_state=(RuleAuxState('switch','bool','global','persistent',0),),square_zone_guards=(zone,)))
rules=replace(rules,semantic_actions=tuple(actions));c=compile_ruleset_for_execution(rules);cap=BoolDropCapability(c);s=GameSession(c);rows=[]
for gate in (0,1):
 pos=replace(s.state.position,hands=(Hands((('P',1),)),Hands()),aux_state=(((0,-1),gate),));key=repetition_identity_key(pos,c);h=(HistoryRecord(key,-1,'',False),);st=GameState(pos,0,((key,1),),semantic_engine_for(c).terminal_result(pos,0,((key,1),),h),h);acts=[action_to_dict(a) for a in legal_actions(st,c)];rows.append(dict(gate=gate,features=cap.encode(pos).tolist(),drops=[a for a in acts if a['kind']=='semantic_drop'],legal_count=len(acts)))
assert rows[0]['features']==rows[1]['features'];assert {tuple(a['to']) for a in rows[0]['drops']}!={tuple(a['to']) for a in rows[1]['drops']}
write_record(out,dict(scope=__doc__,rules=ruleset_to_dict(rules),rows=rows,complete=True,limits='Input alias of supported capability/geometry only; no target-label conflict or improvement claim. Stop treating actor-only pooled264axis probe as generic input.'))
print([(r['gate'],r['legal_count'],[a['to'] for a in r['drops']]) for r in rows])
