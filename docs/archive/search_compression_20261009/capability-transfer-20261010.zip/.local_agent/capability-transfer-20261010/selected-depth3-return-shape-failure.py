"""Selected-action D3 horizon diagnosis, not a complete-root certificate.
Two observed q0-adverse parents2118ply11/2119ply16. Union of existing
Unit/full/v3 choices only, frozen before new D3 labels; original histories.
Compare Unit/full selected values: if ordering reverses, D2 discrepancy alone
does not favor a representation change. Otherwise retain this local error.
20sec/100000transitions per child, UNKNOWNs retained; expected<2min.
No fitting, whole-root optimum assertion, extra depth ladder or cap extension.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from test_rectangular_search_override import UnitEvaluator
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'selected-depth3.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());calls=json.loads((p/'callers.json').read_bytes());key=lambda a:json.dumps(a,sort_keys=True);targets=[]
for seed,ply in ((202610082118,11),(202610082119,16)):
 arms={r['arm']:r['decision']['action'] for r in calls['rows'] if (r['seed'],r['ply'],r['qdepth'])==(seed,ply,0)};targets.append(dict(seed=seed,ply=ply,arms=arms))
write_record(p/'selected-depth3-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),targets=targets))
class Cost(Exception):pass
original=search.legal_successors;rows=[];start=time.perf_counter()
for target in targets:
 case=next(c for c in d['rules'] if c['seed']==target['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for raw in case['route'][:target['ply']]:s.submit(action_from_dict(raw))
 legal={key(record_value(a)):a for a in s.legal_actions()}
 for k in sorted({key(a) for a in target['arms'].values()}):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  a=legal[k];ch=apply_action(s.state,a,c);row=dict(seed=target['seed'],ply=target['ply'],action=action_to_dict(a),arms=[name for name,raw in target['arms'].items() if key(raw)==k],transitions=0,complete=False);t=time.perf_counter()
  def check():
   if time.perf_counter()-t>20 or row['transitions']>100000:raise Cost()
  def successors(state,compiled):
   check()
   for a2,ch2 in original(state,compiled):row['transitions']+=1;check();yield a2,ch2
  search.legal_successors=successors
  try:
   score,pv=search.reference_minimax(ch,2,UnitEvaluator(),c,ply=1);check();row.update(teacher=-score,reply_pv=[action_to_dict(z) for z in pv],complete=True)
  except Cost:row['failure']='selected D3 value UNKNOWN'
  finally:search.legal_successors=original
  row['seconds']=time.perf_counter()-t;rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True));print(rows)
