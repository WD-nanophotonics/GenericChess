"""Exposed decision diagnostic: intermediate q1 at fixed public budgets.
All34 original roots, same3 leaves/Unit ordering/D4/8192nodes/5sec/qhard8.
Old q0/q2 records remain frozen. q1 retains full in-check evasions and hard
abort semantics; no capture-only switch or legality shortcut. Chosen after
q2 all-timeout/D1 mate-allowing observations; not an independent validation,
default tuning or generalized superiority result. Does modest noisy depth
restore root coverage and reduce immediate mate holes across leaves?
Expected<10min; unknown/caps retained; no refit or budget expansion.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib,statistics
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009')),str(Path('.local_agent/predictor-transfer-20261009'))]
from ledger import FrozenLedger
from test_rectangular_search_override import UnitEvaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'q1-callers.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());prepared=[];profiles=[];cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));ledger=FrozenLedger(c,m);den=statistics.median(abs(ledger.current[t]+ledger.base[t]) for t in ledger.current if not c.support.type_metadata[t].is_anchor);assert den>0;profile,scope=build_semantic_opportunity_profile(c,cfg);prepared.append((c,ledger,100/den,Evaluator(c,profile,cfg)));profiles.append(dict(seed=case['seed'],scale=100/den,current=ledger.current,base=ledger.base,hand=ledger.hand,config=record_value(cfg)))
write_record(p/'q1-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),profiles=profiles,root_selection='All34 frozen route roots; no score-dependent selection.',ordering='Fixed inherited Unit capture ordering in all arms.',limits=dict(depth=4,nodes=8192,seconds=5,qdepths=[1],qhard=8)))
rows=[];start=time.perf_counter()
for case,(c,ledger,scale,v3) in zip(d['rules'],prepared):
 s=GameSession(c)
 class Leaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind;self.clips=0;self.calls=0
  def evaluate(self,state):
   self.calls+=1
   if self.kind=='unit':return super().evaluate(state)
   if self.kind=='v3':return v3.evaluate(state)
   raw=round(scale*ledger.full(state.position)*(1 if state.position.side_to_move==0 else -1));self.clips+=abs(raw)>500000;return max(-500000,min(500000,raw))
 for ply in range(len(case['route'])+1):
  for q in (1,):
   arms=['unit','full','v3'];offset=(ply+q//2)%3;arms=arms[offset:]+arms[:offset]
   for kind in arms:
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;ev=Leaf(kind);player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8));sec=time.perf_counter()-t;validate_pv(s,decision);assert s.state==before;rows.append(dict(seed=case['seed'],ply=ply,qdepth=q,arm=kind,seconds=sec,leaf_calls=ev.calls,clips=ev.clips,decision=record_value(decision)));write_record(out,dict(scope=__doc__,rows=rows,complete=False))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
  print(case['seed'],ply,len(rows),round(time.perf_counter()-start,2),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True))
