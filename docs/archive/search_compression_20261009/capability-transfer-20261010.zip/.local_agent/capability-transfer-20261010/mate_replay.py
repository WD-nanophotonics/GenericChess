"""Independent full-history replay of three exposed q2 adverse parents.
No teacher recursion: submit actual chosen action, enumerate actual responses,
record terminal mating replies. Unit/full/v3 chosen actions retained separately.
Reference best is finite UnitD2 only; legal mate replay is narrower evidence.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd())]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'mate-replay.json';assert not out.exists()
d=json.loads((p/'declaration.json').read_bytes());ref=json.loads((p/'original-reference.json').read_bytes());calls=json.loads((p/'callers.json').read_bytes());case=next(c for c in d['rules'] if c['seed']==202610082118);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);rows=[];start=time.perf_counter()
for ply in range(16):
 if ply in (11,13,15):
  before=s.state;rr=next(r for r in ref['rows'] if (r['seed'],r['ply'])==(case['seed'],ply));legal=s.legal_actions();raw={json.dumps(record_value(a),sort_keys=True):a for a in legal}
  for arm in ('unit','full','v3'):
   r=next(r for r in calls['rows'] if (r['seed'],r['ply'],r['qdepth'],r['arm'])==(case['seed'],ply,2,arm));a=raw[json.dumps(r['decision']['action'],sort_keys=True)];child=apply_action(before,a,c);responses=[];successors=0
   # Use public Core action generation from the full carrier, not a new session's history.
   from generic_chess.core.movegen import legal_actions
   for reply in legal_actions(child,c):
    grand=apply_action(child,reply,c);successors+=1
    if grand.terminal_status.is_terminal:responses.append(dict(action=action_to_dict(reply),terminal=record_value(grand.terminal_status)))
   teacher=next(z['teacher'] for z in rr['children'] if z['action']==action_to_dict(a));rows.append(dict(seed=case['seed'],ply=ply,arm=arm,action=action_to_dict(a),teacher=teacher,best_reference=max(z['teacher'] for z in rr['children']),responses_examined=successors,terminal_responses=responses,chosen_terminal=record_value(child.terminal_status)))
  assert s.state==before
 if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True))
print([(r['ply'],r['arm'],r['teacher'],len(r['terminal_responses'])) for r in rows])
