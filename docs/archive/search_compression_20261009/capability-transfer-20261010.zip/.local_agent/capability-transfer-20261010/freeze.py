"""Prospective frozen-predictor/proxy same-protocol transfer, no fitting.
Two new seeds2114/2115, existing8x8hybrid/guarded-drop/temporal-transform family.
Freeze rules, routes and model before any numeric child score or teacher label.
All17route roots per rule and all actual legal children; full GameState carrier.
Same one-ply direct ranker: original affine predictor vs raw current-board proxy
vs staticv3 material baseline (dynamic terms disabled). Terminal wins/losses use
priority ahead of nonterminals; terminal draw uses0, reported separately.
Raw scales are only used WITHIN each scorer; no cross-model leaf conversion.
Expected<5min, per-root20sec/10000transition checkpoint, retain UNKNOWNs.
Changed choices prove sensitivity only. No new training/default/strength claim.
"""
from pathlib import Path
from dataclasses import replace
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'result.json';assert not (p/"declaration.json").exists();modelpath=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(modelpath.read_bytes());w=np.zeros(938);w[np.asarray(m['count_columns'])[m['columns']]]=np.asarray(m['weights'])/m['scale'];cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);frozen=[];prepared=[];fixtures=weird_rulesets()
for seed in (202610082118,202610082119):
 generated=generate_game(GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));base_drop=fixtures[1].semantic_actions[0];base_quiet=fixtures[2].semantic_actions[0];drop=replace(base_drop,type_ids=('P',),replace_selector=replace(base_drop.replace_selector,type_ids=('P',)),slot_guards=(RuleSlotGuard(slot_name='temp_right',value=0),));effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id='P')) if e.kind=='set_current_type' else e for e in base_quiet.effects);quiet=replace(base_quiet,type_ids=('X',),target_relation='empty',effects=effects);rules=replace(generated.ruleset,semantic_actions=(drop,quiet));c=compile_ruleset_for_execution(rules);s=GameSession(c);route=[]
 for ply in range(16):
  if s.state.terminal_status.is_terminal:break
  acts=s.legal_actions()
  if not acts:break
  def order(a):
   raw=action_to_dict(a);capture=False
   if hasattr(a,'to_square'):
    piece=s.state.position.board[a.to_square.rank*8+a.to_square.file];capture=piece is not None and piece.owner!=s.state.position.side_to_move
   return (0 if raw.get('pattern_id','').startswith('sem_01_') else 1 if raw.get('pattern_id','').startswith('sem_00_') else 2 if capture else 3,json.dumps(raw,sort_keys=True))
  a=min(acts,key=order);route.append(action_to_dict(a));s.submit(a)
 profile,scope=build_semantic_opportunity_profile(c,cfg);encoder=InteractionProjection(c);prepared.append((c,encoder,Evaluator(c,profile,cfg)));frozen.append(dict(seed=seed,rules=ruleset_to_dict(rules),route=route,v3_board=dict(profile.board_value_by_type),v3_hand=dict(profile.hand_value_by_base_type),fingerprint=c.ruleset_fingerprint))
write_record(p/'declaration.json',dict(scope=__doc__,base_commit='05892276ae0ca69bb44c1a6c2b20bcf7706db644',model_sha256=hashlib.sha256(modelpath.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules=frozen))
print([(c["seed"],len(c["route"])) for c in frozen])
