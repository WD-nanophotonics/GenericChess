"""Offline exact folding of this frozen count-only affine model; no fitting.
Current/base actor tables, separate owner hands, promoted counts, side/bias.
Reject any nonzero omitted spatial coefficient. History/aux input limitations
are those of the original numerical predictor, not deleted from GameState.
Antisymmetric folding equals(F(P)-F(TP))/2 for the declared owner/rotation T;
numerical equivalence never proves T is a legal symmetry of arbitrary rules.
This is research forward code, not a live numeric-leaf adapter/default.
"""
import numpy as np
from prototype import actor_vectors
class FrozenLedger:
 def __init__(self,c,m):
  w=np.zeros(938);w[np.asarray(m['count_columns'])[m['columns']]]=np.asarray(m['weights'])/m['scale']
  assert not np.any(w[66:396]) and not np.any(w[462:792]) and not np.any(w[925:930]) and not np.any(w[931:936])
  actors=actor_vectors(c);self.current={t:float(a@w[:66]) for t,a in actors.items()};self.base={t:float(a@w[396:462]) for t,a in actors.items()};self.hand=[{t:float(a@w[792+66*i:858+66*i]) for t,a in actors.items()} for i in (0,1)];self.promoted=[float(w[924]),float(w[930])];self.side=[float(w[936]),float(w[937])];self.bias=-float((np.asarray(m['mean'])/m['scale'])@m['weights']);self.fingerprint=c.ruleset_fingerprint;self.shape=c.board_shape
 def full(self,pos):
  if pos.ruleset_fingerprint!=self.fingerprint or pos.board_shape!=self.shape:raise ValueError('wrong compiled carrier')
  value=self.bias+self.side[pos.side_to_move]
  for p in pos.board:
   if p is not None:value+=(1 if p.owner==0 else -1)*(self.current[p.current_type_id]+self.base[p.base_type_id])+self.promoted[p.owner]*p.promoted
  for owner,h in enumerate(pos.hands):
   for t,n in h.counts:value+=n*self.hand[owner][t]
  return value
 def symmetric(self,pos):
  if pos.ruleset_fingerprint!=self.fingerprint or pos.board_shape!=self.shape:raise ValueError('wrong compiled carrier')
  value=(self.side[pos.side_to_move]-self.side[1-pos.side_to_move])/2
  for p in pos.board:
   if p is not None:value+=(1 if p.owner==0 else -1)*(self.current[p.current_type_id]+self.base[p.base_type_id])+p.promoted*(self.promoted[p.owner]-self.promoted[1-p.owner])/2
  for owner,h in enumerate(pos.hands):
   for t,n in h.counts:value+=n*(self.hand[owner][t]-self.hand[1-owner][t])/2
  return value
