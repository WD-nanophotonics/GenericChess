"""Pure symbolic type rename and mechanical feature remap, not new-rule transfer."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.nonlinear import CompactNonlinearResidual
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent;decl=json.loads((p/'prospective-target-declaration.json').read_bytes())
c=compile_ruleset_for_execution(ruleset_from_dict(decl['rules']));e=SparsePositionEncoder(c)
mapping={t:'RENAMED_'+str(len(e.types)-i)for i,t in enumerate(e.types)}
def rename(x):
    if isinstance(x,dict):return {mapping.get(k,k):rename(v)for k,v in x.items()}
    if isinstance(x,list):return [rename(v)for v in x]
    return mapping.get(x,x)if isinstance(x,str)else x
nc=compile_ruleset_for_execution(ruleset_from_dict(rename(decl['rules'])));ne=SparsePositionEncoder(nc)
assert e.dimension==ne.dimension and e.fingerprint!=ne.fingerprint
assert [(k[1],kind,initial)for _,k,kind,initial in e.aux_slots]==[(k[1],kind,initial)for _,k,kind,initial in ne.aux_slots]
perm=np.arange(e.dimension);area=e.shape.area;nt=len(e.types)
for owner in (0,1):
    for i,t in enumerate(e.types):
        j=ne.type_index[mapping[t]]
        for offset in (0,e.base_offset):
            a=offset+(owner*nt+i)*area;b=offset+(owner*nt+j)*area
            perm[a:a+area]=np.arange(b,b+area)
        perm[e.hand_offset+owner*nt+i]=ne.hand_offset+owner*nt+j
original=[];remapped=[];legal_counts=[];guards=0
for root in decl['roots']:
    s=GameSession(c);ns=GameSession(nc)
    for a in root['route']:s.submit(action_from_dict(a));ns.submit(action_from_dict(rename(a)))
    old={json.dumps(rename(action_to_dict(a)),sort_keys=True)for a in s.legal_actions()}
    new={json.dumps(action_to_dict(a),sort_keys=True)for a in ns.legal_actions()}
    assert old==new;legal_counts.append(len(old))
    try:e.dense(ns.state.position)
    except ValueError:guards+=1
    else:raise AssertionError('foreign fingerprint accepted')
    for item in root['children']:
        child=apply_action(s.state,action_from_dict(item['action']),c)
        nchild=apply_action(ns.state,action_from_dict(rename(item['action'])),nc)
        x=e.dense(child.position);nx=ne.dense(nchild.position)[perm]
        assert np.array_equal(x,nx)
        original.append(x);remapped.append(nx)
m=CompactNonlinearResidual.from_dict(json.loads((p/'compression-model.json').read_bytes())['model'])
assert np.array_equal(m.predict(np.asarray(original)),m.predict(np.asarray(remapped)))
write_record(p/'compression-relabel.json',dict(scope=__doc__,mapping=mapping,old_fingerprint=e.fingerprint,new_fingerprint=ne.fingerprint,
    legal_counts=legal_counts,exact_feature_and_prediction_matches=len(original),foreign_fingerprint_rejections=guards,
    limits='Declared pure rename only; no changed capabilities or learned cross-rule representation. No search/tie-order or whole-history equivalence claim.',producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
print('exact renamed feature/prediction matches',len(original),'guards',guards)
