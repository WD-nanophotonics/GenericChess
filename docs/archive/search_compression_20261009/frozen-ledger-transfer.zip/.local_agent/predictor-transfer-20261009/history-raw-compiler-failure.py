"""Actual frozen predictor on existing legal repetition4 knight-cycle control.
Changed premise is actual frozen weights and guarded direct rank, not another
untrained input-alias proof. Complete GameState/verified history retained.
Compare identical Positions at plies3/7/11 and4/8/12; numerical rank prediction
may alias while terminal-aware execution need not. No fitted/default repair.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'history.json';assert not out.exists();mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());old=Path('.local_agent/eval-features-20261009/history-probe.json');route=json.loads(old.read_bytes())['route'];c=compile_semantic_ruleset(replace(build_western_chess_ruleset(),repetition_limit=4));encoder=InteractionProjection(c);s=GameSession(c);roots=[];snapshots={}
write_record(p/'history-declaration.json',dict(scope=__doc__,model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),existing_route_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),root_plies=[3,7,11],snapshot_plies=[4,8,12]))
def score(position):
 x=encoder.encode(position);return float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights'])
for ply in range(13):
 if ply in (3,7,11):
  owner=s.state.position.side_to_move;sign=1 if owner==0 else -1;children=[]
  for a in sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True)):
   ch=apply_action(s.state,a,c);term=ch.terminal_status;raw=sign*score(ch.position);priority=1 if term.is_terminal and term.winner==owner else -1 if term.is_terminal and term.winner is not None else 0
   children.append(dict(action=action_to_dict(a),raw=raw,guarded=0 if term.is_terminal else raw,priority=priority,terminal=record_value(term)))
  chosen={k:[i for i,v in enumerate(children) if (v['priority'] if k=='guarded' else 0,v[k])==max((z['priority'] if k=='guarded' else 0,z[k]) for z in children)] for k in ('raw','guarded')}
  roots.append(dict(ply=ply,children=children,chosen=chosen));snapshots[ply]=s.state
 if ply in (4,8,12):snapshots[ply]=s.state
 if ply<12:s.submit(action_from_dict(route[ply]))
assert snapshots[3].position==snapshots[7].position==snapshots[11].position
assert snapshots[4].position==snapshots[8].position==snapshots[12].position
assert [v['action'] for v in roots[0]['children']]==[v['action'] for v in roots[2]['children']]
assert [v['raw'] for v in roots[0]['children']]==[v['raw'] for v in roots[2]['children']]
write_record(out,dict(scope=__doc__,roots=roots,states=[dict(ply=i,raw_owner0=score(st.position),terminal=record_value(st.terminal_status),history_length=len(st.history)) for i,st in snapshots.items()],numerical_alias=True,complete=True,limits='Declared repetition4 western fixture; numerical history blindness does not prove full search/wrapper blindness or necessity of learned history feature. Not a transfer/strength test.'))
print([(r['ply'],len(r['children']),r['chosen'],sum(v['terminal']['status']!='ongoing' for v in r['children'])) for r in roots])
