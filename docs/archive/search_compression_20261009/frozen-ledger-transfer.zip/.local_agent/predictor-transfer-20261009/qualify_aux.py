"""Independent replay of the observed lifecycle continuation, not training."""
from pathlib import Path
from dataclasses import replace
import sys,json
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'aux-qualification.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());case=d['rules'][0];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for a in case['route'][:4]:s.submit(action_from_dict(a))
position=s.state.position;life=json.loads((p/'lifetime.json').read_bytes());witness=next(r for r in life['comparisons'] if r['ply']==4 and r['gate']==1)['differences'][0]['action'];decl=json.loads((p/'lifetime-declaration.json').read_bytes());rows=[]
for variant in decl['rules']:
 cc=compile_ruleset_for_execution(ruleset_from_dict(variant['rules']));aux=dict(position.aux_state);aux[(0,-1)]=1;pos=replace(position,ruleset_fingerprint=cc.ruleset_fingerprint,aux_state=tuple(sorted(aux.items())));key=repetition_identity_key(pos,cc);history=(HistoryRecord(key,-1,'',False),);counts=((key,1),);st=GameState(pos,0,counts,semantic_engine_for(cc).terminal_result(pos,0,counts,history),history);action=action_from_dict(witness);assert action in legal_actions(st,cc);child=apply_action(st,action,cc);drops=[a for a in legal_actions(child,cc) if action_to_dict(a).get('kind')=='semantic_drop' and action_to_dict(a).get('base_type_id')=='P' and action_to_dict(a).get('to')==[1,2]]
 row=dict(lifetime=variant['lifetime'],action=witness,child_aux=record_value(child.position.aux_state),winning_reply_present=bool(drops))
 if drops:
  end=apply_action(child,drops[0],cc);assert end.terminal_status.is_terminal and end.terminal_status.winner==1 and not legal_actions(end,cc) and semantic_engine_for(cc).in_check(end.position,0);row.update(reply=action_to_dict(drops[0]),end=record_value(end.terminal_status),legal_replies=0,loser_in_check=True)
 rows.append(row)
assert rows[0]['winning_reply_present'] and not rows[1]['winning_reply_present'];write_record(out,dict(scope=__doc__,rows=rows,complete=True));print(rows)
