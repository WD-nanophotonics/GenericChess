"""Independent cold UnitD2 public callers validate all34 full-reference fronts.
No new horizon or fitted score, all roots and PV/legal checks retained.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from test_rectangular_search_override import UnitEvaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'qualification.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());ref=json.loads((p/'reference.json').read_bytes());rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for ply in range(len(case['route'])+1):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  before=s.state;player=AlphaBetaPlayer(c,evaluator_override=UnitEvaluator(),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=None,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,decision);assert s.state==before
  rr=next(r for r in ref['rows'] if r['seed']==case['seed'] and r['ply']==ply);lookup={json.dumps(v['action'],sort_keys=True):v['score'] for v in rr['teacher']};assert decision.completed_depth==2 and decision.score==rr['best'] and lookup[json.dumps(action_to_dict(decision.action),sort_keys=True)]==rr['best']
  rows.append(dict(seed=case['seed'],ply=ply,decision=record_value(decision),teacher_best=rr['best']));write_record(out,dict(scope=__doc__,rows=rows,complete=False))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 print(case['seed'],round(time.perf_counter()-start,2),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True))
