"""Frozen predictor role-exchange diagnosis, no fitting or deployment.
Predeclared180degree rotation+owner swap, hand/side/per-owner auxiliary swap,
square auxiliary rotation. All34 original Positions, explicit fresh-history
counterfactuals on BOTH sides; not replacement for the full original routes.
Test legal-action mapping and one-transition/full Position/terminal equivalence
before comparing ranks. Retain failures; no assumption all generated rules
are role-symmetric. Inapplicable roots are reported, never counted as model bias.
Numerical diagnostic includes fixed algebraic antisymmetrization
(F(P)-F(TP))/2, no labels, fitted coefficients or model/default promotion.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'symmetry.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());tol=1e-8
write_record(p/'symmetry-declaration.json',dict(scope=__doc__,model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),tolerance=tol,roots=[(r['seed'],i) for r in d['rules'] for i in range(len(r['route'])+1)]))
def flip(pos):
 shape=pos.board_shape;board=tuple(None if v is None else replace(v,owner=1-v.owner) for v in reversed(pos.board));aux=tuple(sorted(((slot,owner if owner==-1 else 1-owner),(shape.width-1-v[0],shape.height-1-v[1]) if isinstance(v,tuple) else v) for ((slot,owner),v) in pos.aux_state));return replace(pos,board=board,hands=tuple(reversed(pos.hands)),side_to_move=1-pos.side_to_move,aux_state=aux)
def flip_action(raw,shape):
 result=dict(raw)
 for k in ('from','to'):
  if result.get(k) is not None:result[k]=[shape.width-1-raw[k][0],shape.height-1-raw[k][1]]
 return result
def fresh(pos,c):
 key=repetition_identity_key(pos,c);counts=((key,1),);history=(HistoryRecord(key,-1,'',False),);term=semantic_engine_for(c).terminal_result(pos,0,counts,history);return GameState(pos,0,counts,term,history)
rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);enc=InteractionProjection(c);engine=semantic_engine_for(c)
 def raw(pos):
  x=enc.encode(pos);return float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights'])
 for ply in range(len(case['route'])+1):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  pos=s.state.position;mirror=flip(pos);assert flip(mirror)==pos;left=fresh(pos,c);right=fresh(mirror,c);acts=legal_actions(left,c);other={json.dumps(action_to_dict(a),sort_keys=True):a for a in legal_actions(right,c)};mapped=[json.dumps(flip_action(action_to_dict(a),c.board_shape),sort_keys=True) for a in acts];row=dict(seed=case['seed'],ply=ply,legal_equivalent=set(mapped)==set(other),children=[],complete=False)
  if row['legal_equivalent']:
   for a,mapped_key in zip(acts,mapped):
    lc=apply_action(left,a,c);rc=apply_action(right,other[mapped_key],c);lt=lc.terminal_status;rt=rc.terminal_status;equivalent=flip(lc.position)==rc.position and lt.status==rt.status and (None if lt.winner is None else 1-lt.winner)==rt.winner;sign=1 if pos.side_to_move==0 else -1;lv=sign*raw(lc.position);rv=-sign*raw(rc.position);sym=sign*(raw(lc.position)-raw(flip(lc.position)))/2;priority=1 if lt.is_terminal and lt.winner==pos.side_to_move else -1 if lt.is_terminal and lt.winner is not None else 0
    row['children'].append(dict(action=action_to_dict(a),position_terminal_equivalent=equivalent,left_raw=lv,right_raw=rv,symmetric_raw=sym,priority=priority,terminal=record_value(lt),left=0 if lt.is_terminal else lv,right=0 if rt.is_terminal else rv,symmetric=0 if lt.is_terminal else sym))
   row['complete']=all(v['position_terminal_equivalent'] for v in row['children'])
   if row['complete']:
    priority=max(v['priority'] for v in row['children']);row['chosen']={k:[i for i,v in enumerate(row['children']) if v['priority']==priority and abs(v[k]-max(z[k] for z in row['children'] if z['priority']==priority))<=tol] for k in ('left','right','symmetric')};row['rank_equivalent']=row['chosen']['left']==row['chosen']['right']
  rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 print(case['seed'],round(time.perf_counter()-start,2),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True,qualified=sum(r['complete'] for r in rows),rank_changed=sum(r['complete'] and not r['rank_equivalent'] for r in rows),limits='One-ply fresh-history equivalence only; no original-route history is flattened in the preceding transfer/reference experiment. Raw bias/intercept values are not calibrated utility.'))
