"""Fixed Unit D2 reference for all34 frozen direct-rank roots, no fitting.
Target question: do the13 full/proxy choice differences have short-target
consequences? All roots retained, terminal-equal ties qualified separately.
20sec/100000 transitions per root; partial front UNKNOWN, no automatic extension.
Raw rank scales stay separate from teacher utility. Expected under5min.
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from test_rectangular_search_override import UnitEvaluator
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'reference.json';assert not out.exists()
d=json.loads((p/'declaration.json').read_bytes());rank=json.loads((p/'result.json').read_bytes())
write_record(p/'reference-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rank_sha256=hashlib.sha256((p/'result.json').read_bytes()).hexdigest(),roots=[(c['seed'],r['ply']) for c in rank['rules'] for r in c['roots']],terminal_qualification='All same-outcome terminal wins/losses tie: ranking value0; draws0. Preserve original executed raw values.'))
class Cost(Exception):pass
original=search.legal_successors;rows=[];start=time.perf_counter()
for case,rc in zip(d['rules'],rank['rules']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for rp in rc['roots']:
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  before=s.state;t=time.perf_counter();row=dict(seed=case['seed'],ply=rp['ply'],teacher=[],transitions=0,complete=False)
  def check():
   if time.perf_counter()-t>20 or row['transitions']>100000:raise Cost()
  def successors(state,compiled):
   check()
   for a,ch in original(state,compiled):row['transitions']+=1;check();yield a,ch
  search.legal_successors=successors
  try:
   for a,ch in successors(before,c):
    score,_=search.reference_minimax(ch,1,UnitEvaluator(),c,ply=1);check();row['teacher'].append(dict(action=action_to_dict(a),score=-score))
   row['complete']=True
  except Cost:row['failure']='Partial reference front UNKNOWN'
  finally:search.legal_successors=original
  assert s.state==before
  row['seconds']=time.perf_counter()-t
  qualified={k:[i for i,v in enumerate(rp['children']) if (v['priority'],0 if v['terminal']['status']!='ongoing' else v['values'][k])==max((z['priority'],0 if z['terminal']['status']!='ongoing' else z['values'][k]) for z in rp['children'])] for k in ('full','proxy','v3')}
  row['qualified_chosen']=qualified
  lookup={json.dumps(v['action'],sort_keys=True):v['score'] for v in row['teacher']};best=max(lookup.values()) if row['complete'] else None
  row['best']=best;row['arms']={}
  for k,ids in qualified.items():
   scores=[lookup.get(json.dumps(rp['children'][i]['action'],sort_keys=True)) for i in ids]
   row['arms'][k]=dict(scores=scores,losses=None if best is None or any(v is None for v in scores) else [best-v for v in scores])
  rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
  if rp['ply']<len(case['route']):s.submit(action_from_dict(case['route'][rp['ply']]))
 print(case['seed'],round(time.perf_counter()-start,2),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start,limits='Fixed Unit D2 only; exposed development target, no learned-model generalization or true WDL/strength claim. Best/worst selected tie scores retained, no favored tie-break.'))
