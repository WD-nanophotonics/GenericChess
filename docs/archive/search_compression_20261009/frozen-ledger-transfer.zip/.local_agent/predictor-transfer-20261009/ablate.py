"""Exposed deterministic frozen-weight decomposition, not fitting/selection.
All34 roots and3128actual children; proxy+base-correction, proxy+hand,
proxy+promotion, full-minus-each component. Side/intercept root constants.
Exact ties and fixed1e-8 numerical-tolerance ties reported separately;
tolerance only guards floating reconstruction, not favorable action selection.
Reuse fixed Unit D2 labels; claims limited to these original weights/targets.
"""
from pathlib import Path
import sys,json,hashlib,time
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'ablation.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());old=json.loads((p/'result.json').read_bytes());ref=json.loads((p/'reference.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());w=np.zeros(938);w[np.asarray(m['count_columns'])[m['columns']]]=np.asarray(m['weights'])/m['scale'];intercept=-float((np.asarray(m['mean'])/m['scale'])@m['weights']);tol=1e-8
write_record(p/'ablation-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),reference_sha256=hashlib.sha256((p/'reference.json').read_bytes()).hexdigest(),tolerance=tol,spatial_weights_nonzero=int(np.count_nonzero(w[66:396])+np.count_nonzero(w[462:792]))))
assert not np.any(w[66:396]) and not np.any(w[462:792])
rows=[];start=time.perf_counter()
for case,rc in zip(d['rules'],old['rules']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);encoder=InteractionProjection(c)
 for rp in rc['roots']:
  sign=1 if s.state.position.side_to_move==0 else -1;children=[]
  for raw in rp['children']:
   a=action_from_dict(raw['action']);assert a in s.legal_actions();ch=apply_action(s.state,a,c);x=encoder.encode(ch.position)
   proxy=sign*sum((1 if a.owner==0 else -1)*float(encoder.actors[a.current_type_id]@(w[:66]+w[396:462])) for a in ch.position.board if a is not None)
   base=sign*sum((1 if a.owner==0 else -1)*float((encoder.actors[a.base_type_id]-encoder.actors[a.current_type_id])@w[396:462]) for a in ch.position.board if a is not None)
   hand=sign*float(x[792:924]@w[792:924]);prom=sign*float(x[924:936]@w[924:936]);side=sign*float(x[936:]@w[936:]);full=sign*float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights']);error=full-(proxy+base+hand+prom+side+sign*intercept)
   assert abs(error)<tol and abs(full-raw['values']['full'])<tol if raw['terminal']['status']=='ongoing' else abs(error)<tol
   scores=dict(full=full,proxy=proxy,proxy_base=proxy+base,proxy_hand=proxy+hand,proxy_promoted=proxy+prom,no_base=full-base,no_hand=full-hand,no_promoted=full-prom)
   if ch.terminal_status.is_terminal:scores={k:0. for k in scores}
   children.append(dict(action=raw['action'],priority=raw['priority'],components=dict(proxy=proxy,base_correction=base,hand=hand,promoted=prom,side=side,intercept=sign*intercept),reconstruction_error=error,scores=scores))
  rr=next(r for r in ref['rows'] if r['seed']==case['seed'] and r['ply']==rp['ply']);lookup={json.dumps(v['action'],sort_keys=True):v['score'] for v in rr['teacher']};arms={}
  for name in children[0]['scores']:
   priority=max(v['priority'] for v in children);best=max(v['scores'][name] for v in children if v['priority']==priority);ids=[i for i,v in enumerate(children) if v['priority']==priority and v['scores'][name]==best];near=[i for i,v in enumerate(children) if v['priority']==priority and abs(v['scores'][name]-best)<=tol]
   losses=lambda chosen:[rr['best']-lookup[json.dumps(children[i]['action'],sort_keys=True)] for i in chosen]
   arms[name]=dict(chosen=ids,tolerant_chosen=near,losses=losses(ids),tolerant_losses=losses(near))
  rows.append(dict(seed=case['seed'],ply=rp['ply'],children=children,arms=arms))
  if rp['ply']<len(case['route']):s.submit(action_from_dict(case['route'][rp['ply']]))
summary={k:dict(exact_alloptimal=sum(all(v==0 for v in r['arms'][k]['losses']) for r in rows),tolerant_alloptimal=sum(all(v==0 for v in r['arms'][k]['tolerant_losses']) for r in rows),tolerant_anyoptimal=sum(any(v==0 for v in r['arms'][k]['tolerant_losses']) for r in rows),tolerant_matches_full=sum(r['arms'][k]['tolerant_chosen']==r['arms']['full']['tolerant_chosen'] for r in rows)) for k in rows[0]['arms']}
write_record(out,dict(scope=__doc__,rows=rows,summary=summary,seconds=time.perf_counter()-start,max_error=max(abs(ch['reconstruction_error']) for r in rows for ch in r['children']),complete=True));print(summary,flush=True)
