"""Exact folded forward qualification and actual caller overhead, scoped.
First replay all3128children and mirror-score folding; no new labels/refits.
Then eight predeclared roots2114/2115 plies0/4/8/12, q0/q2, five extraction
arms(unit,encode,ledger,symencode,symledger), two cyclic order-balanced rounds.
All160calls use Unit leaf/Unit ordering and discard extracted model scores;
fresh player/TT D3/512nodes/5sec/hard8. Measure same-work signatures/caps,
leaf extraction time/count, setup separately. Not model-strength evidence.
No concurrent CPU experiment during these calls. Expected<10min.
"""
from pathlib import Path
from dataclasses import replace
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from ledger import FrozenLedger
from test_rectangular_search_override import UnitEvaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'ledger-cost.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());rank=json.loads((p/'result.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());arms=['unit','encode','ledger','symencode','symledger'];rows=[];validation=[];prepared=[];setup=[];tol=1e-8
write_record(p/'ledger-cost-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),ledger_sha256=hashlib.sha256((p/'ledger.py').read_bytes()).hexdigest(),model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),roots=[(case['seed'],i) for case in d['rules'] for i in (0,4,8,12)],arms=arms,rounds=2,reference_scope='Scoring output discarded at leaves, Unit objective unchanged; exact analytic representation does not add input information.'))
def flip(pos):
 sh=pos.board_shape;aux=tuple(sorted(((slot,owner if owner==-1 else 1-owner),(sh.width-1-v[0],sh.height-1-v[1]) if isinstance(v,tuple) else v) for ((slot,owner),v) in pos.aux_state));return replace(pos,board=tuple(None if v is None else replace(v,owner=1-v.owner) for v in reversed(pos.board)),hands=tuple(reversed(pos.hands)),side_to_move=1-pos.side_to_move,aux_state=aux)
for case,rc in zip(d['rules'],rank['rules']):
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));t=time.perf_counter();enc=InteractionProjection(c);encode_setup=time.perf_counter()-t;t=time.perf_counter();ledger=FrozenLedger(c,m);ledger_setup=time.perf_counter()-t;setup.append(dict(seed=case['seed'],encode_seconds=encode_setup,ledger_seconds=ledger_setup));prepared.append((c,enc,ledger));s=GameSession(c)
 def raw(pos):
  x=enc.encode(pos);return float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights'])
 for rp in rc['roots']:
  errors=[];symerrors=[]
  for ch in rp['children']:
   pos=apply_action(s.state,action_from_dict(ch['action']),c).position;errors.append(abs(raw(pos)-ledger.full(pos)));symerrors.append(abs((raw(pos)-raw(flip(pos)))/2-ledger.symmetric(pos)))
  assert max(errors)<tol and max(symerrors)<tol;validation.append(dict(seed=case['seed'],ply=rp['ply'],children=len(errors),max_error=max(errors),max_sym_error=max(symerrors)))
  if rp['ply']<len(case['route']):s.submit(action_from_dict(case['route'][rp['ply']]))
write_record(p/'ledger-validation.json',dict(scope=__doc__,rows=validation,complete=True))
start=time.perf_counter()
for case,(c,enc,ledger) in zip(d['rules'],prepared):
 s=GameSession(c)
 def raw(pos):
  x=enc.encode(pos);return float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights'])
 class Discarded(UnitEvaluator):
  def __init__(self,kind):self.kind=kind;self.count=0;self.seconds=0.
  def evaluate(self,state):
   t=time.perf_counter();pos=state.position
   if self.kind=='encode':raw(pos)
   elif self.kind=='ledger':ledger.full(pos)
   elif self.kind=='symencode':(raw(pos)-raw(flip(pos)))/2
   elif self.kind=='symledger':ledger.symmetric(pos)
   self.seconds+=time.perf_counter()-t;self.count+=1;return super().evaluate(state)
 for ply in range(len(case['route'])+1):
  if ply in (0,4,8,12):
   for q in (0,2):
    for rep in range(2):
     offset=(ply//4+q//2+rep)%5;order=arms[offset:]+arms[:offset]
     for kind in order:
      assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;ev=Discarded(kind);player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=512,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8));seconds=time.perf_counter()-t;validate_pv(s,decision);assert before==s.state;rows.append(dict(seed=case['seed'],ply=ply,qdepth=q,round=rep,kind=kind,seconds=seconds,extraction_count=ev.count,extraction_seconds=ev.seconds,decision=record_value(decision)));write_record(out,dict(scope=__doc__,rows=rows,setup=setup,complete=False))
   print(case['seed'],ply,len(rows),round(time.perf_counter()-start,2),flush=True)
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
write_record(out,dict(scope=__doc__,rows=rows,setup=setup,complete=True,seconds=time.perf_counter()-start))
