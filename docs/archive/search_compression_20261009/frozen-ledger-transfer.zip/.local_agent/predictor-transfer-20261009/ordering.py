"""204 cold public caller controls: Unit leaf fixed, only ordering varies.
34existing roots x3frozen heuristics xq0/q2, D3/2048nodes/2sec/hard8.
Unit, board-only frozen proxy, board+base+hand ledger capture heuristic.
Heuristic projects ordinary remove-target/capture-to-own-base-hand effects;
it omits action-specific promotion/auxiliary/remote effects. Not a full model
deployment, calibrated leaf score, general rule-capture law or strength test.
Each call fresh player/TT, cyclic arm order balances root/query execution order.
All caps and actual effort retained. Expected<10min, no batch extension/refit.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib,numpy as np
from statistics import median
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009'))]
from test_rectangular_search_override import UnitEvaluator
from prototype import actor_vectors
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'ordering.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());w=np.zeros(938);w[np.asarray(m['count_columns'])[m['columns']]]=np.asarray(m['weights'])/m['scale'];rows=[];profiles=[];prepared=[]
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));actors=actor_vectors(c);current={t:float(v@w[:66]) for t,v in actors.items()};base={t:float(v@w[396:462]) for t,v in actors.items()};hands=[{t:float(v@w[792+66*owner:858+66*owner]) for t,v in actors.items()} for owner in (0,1)];proxy={t:current[t]+base[t] for t in actors};scale=median(abs(v) for t,v in proxy.items() if not c.support.type_metadata[t].is_anchor);assert scale>0;prepared.append((c,current,base,hands,proxy,scale));profiles.append(dict(seed=case['seed'],current=current,base=base,hands=hands,proxy=proxy,scale=scale))
write_record(p/'ordering-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),profiles=profiles,arms=['unit','proxy','ledger'],limits=dict(depth=3,nodes=2048,seconds=2,qdepths=[0,2],qhard=8),frozen_condition='Same Unit leaf, public Core authority, cold TT/orderer; changed ordering only.'))
start=time.perf_counter()
for case,(c,current,base,hands,proxy,scale) in zip(d['rules'],prepared):
 s=GameSession(c)
 class OrderLeaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind
  def type_value(self,t):return round(1000*proxy[t]/scale)
  def capture_order_value(self,moving,captured):
   if self.kind=='unit':return super().capture_order_value(moving,captured)
   if self.kind=='proxy':gain=proxy[captured.current_type_id];risk=proxy[moving.current_type_id]
   else:gain=current[captured.current_type_id]+base[captured.base_type_id]+(1 if moving.owner==0 else -1)*hands[moving.owner][captured.base_type_id];risk=current[moving.current_type_id]+base[moving.base_type_id]
   return round(1000*(10*gain-risk/10)/scale)
 for ply in range(len(case['route'])+1):
  for q in (0,2):
   arms=['unit','proxy','ledger'];offset=(ply+q//2)%3;arms=arms[offset:]+arms[:offset]
   for kind in arms:
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;player=AlphaBetaPlayer(c,evaluator_override=OrderLeaf(kind),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=2048,max_time_seconds=2,quiescence_max_depth=q,quiescence_hard_max_depth=8));seconds=time.perf_counter()-t;validate_pv(s,decision);assert s.state==before;rows.append(dict(seed=case['seed'],ply=ply,qdepth=q,ordering=kind,seconds=seconds,decision=record_value(decision)));write_record(out,dict(scope=__doc__,rows=rows,complete=False))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
  if ply%4==0:print(case['seed'],ply,len(rows),round(time.perf_counter()-start,2),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
