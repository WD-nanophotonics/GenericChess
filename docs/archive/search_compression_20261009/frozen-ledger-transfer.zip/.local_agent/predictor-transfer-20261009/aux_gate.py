"""Auxiliary gate with observed eligible P hand stock, changed old premise.
All12eligible actual route Positions in2114/2115 selected by P inventory only,
before gate counterfactual outcomes. Declare globaltemp_right slot0 set0/1;
each side fresh canonical full history, not claimed reachable opening.
Full frozen predictor and ledger omit numerical auxiliary input; direct rank
still receives authoritative legal mask and terminal guard. Compare fixedUnitD2
fronts20sec/100000transitions each, report terminal roots/UNKNOWNs, all ties.
Question: does this consequence require a numerical aux feature, or is observed
effect only the legal/terminal interface? No fitting/default or tactical patch.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from test_rectangular_search_override import UnitEvaluator
from ledger import FrozenLedger
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'aux-gate.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());prepared=[];qualification=[]
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);assert len(c.ir.aux_slots)==1 and c.ir.aux_slots[0].scope=='global' and c.ir.aux_slots[0].value_kind=='bool';positions=[]
 for ply in range(len(case['route'])+1):
  if s.state.position.hands[s.state.position.side_to_move].count('P')>0:positions.append((ply,s.state.position));qualification.append(dict(seed=case['seed'],ply=ply,Pstock=s.state.position.hands[s.state.position.side_to_move].count('P')))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 prepared.append((case,c,positions))
write_record(p/'aux-gate-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),eligibility=qualification,slot=(0,-1),values=[0,1]))
def fresh(pos,c):
 key=repetition_identity_key(pos,c);counts=((key,1),);history=(HistoryRecord(key,-1,'',False),);return GameState(pos,0,counts,semantic_engine_for(c).terminal_result(pos,0,counts,history),history)
class Cost(Exception):pass
original=search.legal_successors;rows=[];start=time.perf_counter()
for case,c,positions in prepared:
 enc=InteractionProjection(c);ledger=FrozenLedger(c,m)
 def raw(pos):
  x=enc.encode(pos);return float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights'])
 for ply,pos in positions:
  pair=dict(seed=case['seed'],ply=ply,sides=[]);features=[]
  for gate in (0,1):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];aux=dict(pos.aux_state);aux[(0,-1)]=gate;st=fresh(replace(pos,aux_state=tuple(sorted(aux.items()))),c);features.append(enc.encode(st.position));row=dict(gate=gate,root_raw=raw(st.position),root_terminal=record_value(st.terminal_status),children=[],complete=False,transitions=0);t=time.perf_counter();sign=1 if pos.side_to_move==0 else -1
   def check():
    if time.perf_counter()-t>20 or row['transitions']>100000:raise Cost()
   def successors(state,compiled):
    check()
    for a,ch in original(state,compiled):row['transitions']+=1;check();yield a,ch
   search.legal_successors=successors
   try:
    if st.terminal_status.is_terminal:row['root_teacher']=search.terminal_score(st.terminal_status,pos.side_to_move,0)
    else:
     for a,ch in successors(st,c):
      score,_=search.reference_minimax(ch,1,UnitEvaluator(),c,ply=1);check();term=ch.terminal_status;priority=1 if term.is_terminal and term.winner==pos.side_to_move else -1 if term.is_terminal and term.winner is not None else 0
      row['children'].append(dict(action=action_to_dict(a),teacher=-score,priority=priority,full=0 if term.is_terminal else sign*raw(ch.position),symmetric=0 if term.is_terminal else sign*ledger.symmetric(ch.position),terminal=record_value(term)))
    row['complete']=True
   except Cost:row['failure']='partial front UNKNOWN'
   finally:search.legal_successors=original
   row['seconds']=time.perf_counter()-t
   if row['complete'] and row['children']:
    best=max(v['teacher'] for v in row['children']);row['root_teacher']=best;pr=max(v['priority'] for v in row['children']);row['arms']={}
    for k in ('full','symmetric'):
     bv=max(v[k] for v in row['children'] if v['priority']==pr);ids=[i for i,v in enumerate(row['children']) if v['priority']==pr and abs(v[k]-bv)<1e-8];row['arms'][k]=dict(chosen=ids,losses=[best-row['children'][i]['teacher'] for i in ids])
   row['drop_actions']=sum(v['action']['kind']=='semantic_drop' for v in row['children']);pair['sides'].append(row)
  pair['numerical_features_alias']=np.array_equal(*features);assert pair['numerical_features_alias'];rows.append(pair);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
 print(case['seed'],round(time.perf_counter()-start,2),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True,limitations='Fresh gate counterfactuals, UnitD2 target only; full numerical input alias is not proof whole legal/terminal/search system aliases or aux features improve utility.'))
