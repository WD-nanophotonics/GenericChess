"""Finite paired structure control, not full-game symmetry/true utility.
All34declared pairs, independently fresh full-history carriers on each side.
Two UnitD2full fronts per pair,20sec/100000transitions each; partial UNKNOWN.
Compare mapped all-child scores/optima in SIDE-TO-MOVE perspective (same sign);
owner0-fixed perspective changes sign because side also swaps. Original/full
and fixed antisymmetric predictor use same direct rank/tolerance1e-8; all ties
and new losses retained. No labels fitted; no new model/default promotion.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib,time,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from test_rectangular_search_override import UnitEvaluator
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'paired-reference.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());sym=json.loads((p/'symmetry.json').read_bytes());mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());tol=1e-8
write_record(p/'paired-reference-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),symmetry_sha256=hashlib.sha256((p/'symmetry.json').read_bytes()).hexdigest(),reference='Independent Unit D2, no previous root history transplanted or cleared',roots=[(r['seed'],r['ply']) for r in sym['rows']]))
def flip(pos):
 sh=pos.board_shape;aux=tuple(sorted(((slot,owner if owner==-1 else 1-owner),(sh.width-1-v[0],sh.height-1-v[1]) if isinstance(v,tuple) else v) for ((slot,owner),v) in pos.aux_state));return replace(pos,board=tuple(None if v is None else replace(v,owner=1-v.owner) for v in reversed(pos.board)),hands=tuple(reversed(pos.hands)),side_to_move=1-pos.side_to_move,aux_state=aux)
def mirror_action(raw,shape):
 raw=dict(raw)
 for k in ('from','to'):
  if raw.get(k) is not None:raw[k]=[shape.width-1-raw[k][0],shape.height-1-raw[k][1]]
 return raw
def fresh(pos,c):
 key=repetition_identity_key(pos,c);counts=((key,1),);history=(HistoryRecord(key,-1,'',False),);term=semantic_engine_for(c).terminal_result(pos,0,counts,history);return GameState(pos,0,counts,term,history)
class Cost(Exception):pass
original=search.legal_successors;rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);enc=InteractionProjection(c)
 def raw(pos):
  x=enc.encode(pos);return float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights'])
 for ply in range(len(case['route'])+1):
  rr=dict(seed=case['seed'],ply=ply,sides=[])
  for side,pos in enumerate((s.state.position,flip(s.state.position))):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];st=fresh(pos,c);row=dict(side=side,children=[],transitions=0,complete=False);t=time.perf_counter()
   def check():
    if time.perf_counter()-t>20 or row['transitions']>100000:raise Cost()
   def successors(state,compiled):
    check()
    for a,ch in original(state,compiled):row['transitions']+=1;check();yield a,ch
   search.legal_successors=successors
   try:
    for a,ch in successors(st,c):
     score,_=search.reference_minimax(ch,1,UnitEvaluator(),c,ply=1);check();term=ch.terminal_status;sign=1 if pos.side_to_move==0 else -1;priority=1 if term.is_terminal and term.winner==pos.side_to_move else -1 if term.is_terminal and term.winner is not None else 0;fv=sign*raw(ch.position);sv=sign*(raw(ch.position)-raw(flip(ch.position)))/2
     row['children'].append(dict(action=action_to_dict(a),teacher=-score,teacher_owner0=-score*sign,priority=priority,full=0 if term.is_terminal else fv,symmetric=0 if term.is_terminal else sv))
    row['complete']=True
   except Cost:row['failure']='partial front UNKNOWN'
   finally:search.legal_successors=original
   row['seconds']=time.perf_counter()-t
   if row['complete']:
    best=max(v['teacher'] for v in row['children']);priority=max(v['priority'] for v in row['children']);row['teacher_best']=best;row['teacher_chosen']=[i for i,v in enumerate(row['children']) if v['teacher']==best];row['arms']={}
    for k in ('full','symmetric'):
     numeric=max(v[k] for v in row['children'] if v['priority']==priority);ids=[i for i,v in enumerate(row['children']) if v['priority']==priority and abs(v[k]-numeric)<=tol];row['arms'][k]=dict(chosen=ids,losses=[best-row['children'][i]['teacher'] for i in ids])
   rr['sides'].append(row)
  if all(r['complete'] for r in rr['sides']):
   left,right=rr['sides'];lookup={json.dumps(v['action'],sort_keys=True):v for v in right['children']};rr['d2_equivalent']=all(json.dumps(mirror_action(v['action'],c.board_shape),sort_keys=True) in lookup and v['teacher']==lookup[json.dumps(mirror_action(v['action'],c.board_shape),sort_keys=True)]['teacher'] and v['teacher_owner0']==-lookup[json.dumps(mirror_action(v['action'],c.board_shape),sort_keys=True)]['teacher_owner0'] for v in left['children']) and len(left['children'])==len(right['children'])
  rows.append(rr);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 print(case['seed'],round(time.perf_counter()-start,2),flush=True)
summary={k:dict(alloptimal=sum(all(v==0 for v in side['arms'][k]['losses']) for r in rows for side in r['sides'] if side['complete']),anyoptimal=sum(any(v==0 for v in side['arms'][k]['losses']) for r in rows for side in r['sides'] if side['complete'])) for k in ('full','symmetric')}
write_record(out,dict(scope=__doc__,rows=rows,summary=summary,complete=True,seconds=time.perf_counter()-start,d2_equivalent=sum(r.get('d2_equivalent',False) for r in rows),limitations='Independent finite target correspondence; not full game automorphism, new fitted model, calibrated numeric leaf or utility/strength guarantee.'))
print(summary,flush=True)
