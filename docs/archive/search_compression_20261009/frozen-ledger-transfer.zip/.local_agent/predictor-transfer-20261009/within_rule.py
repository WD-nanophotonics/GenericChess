"""Read-only exposed within-rule gate/input alias audit; no fitting."""
from pathlib import Path
import json
p=Path(__file__).parent;d=json.loads((p/'lifetime.json').read_bytes());rows=[]
for life in ('expire_next_turn','persistent'):
 for ply in (4,10):
  sides=[next(r for r in d['rows'] if r['lifetime']==life and r['ply']==ply and r['gate']==g) for g in (0,1)]
  key=lambda c:json.dumps(c['action'],sort_keys=True)
  a,b=[{key(c):c for c in r['children']} for r in sides];common=set(a)&set(b)
  conflicts=[dict(action=a[k]['action'],targets=[a[k]['teacher'],b[k]['teacher']],same_feature=a[k]['feature']==b[k]['feature'],same_prediction=a[k]['raw']==b[k]['raw']) for k in sorted(common) if a[k]['teacher']!=b[k]['teacher']]
  assert all(c['same_feature'] and c['same_prediction'] for c in conflicts)
  rows.append(dict(lifetime=life,ply=ply,common_actions=len(common),conflicts=conflicts))
out=p/'within-rule-alias-recomputed.json';assert not out.exists();out.write_text(json.dumps(dict(scope=__doc__,rows=rows),indent=2)+'\n',encoding='utf-8')
print([(r['lifetime'],r['ply'],len(r['conflicts'])) for r in rows])
