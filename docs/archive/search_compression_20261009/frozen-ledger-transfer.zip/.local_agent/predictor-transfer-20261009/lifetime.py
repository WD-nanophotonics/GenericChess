"""Changed-premise finite auxiliary target: expiry versus persistent right.
Predeclared2114parents4/10 of the two observed gate-enabled immediate Pdrops;
two lifetimes xcurrent gate0/1 =8fresh canonical full-history roots.
Same full board/base/hands/side, correctly rebound to each compiled fingerprint.
Compare all legal children and UnitD2 target;20sec/100000transition checkpoint.
This is exposed mechanistic diagnosis, not prospective utility gain or fitting.
Question: can equal current legal masks hide different next-reply capabilities,
which the original count predictor/folded equivalent cannot represent?
Only slot lifetime changes, no material reward/target/geometry modifications.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib,numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
from test_rectangular_search_override import UnitEvaluator
import generic_chess.ai.alphabeta.search as search
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.position import GameState,HistoryRecord
from generic_chess.core.identity import repetition_identity_key
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'lifetime.json';assert not out.exists();d=json.loads((p/'declaration.json').read_bytes());case=next(r for r in d['rules'] if r['seed']==202610082114);oldrules=ruleset_from_dict(case['rules']);originalc=compile_ruleset_for_execution(oldrules);s=GameSession(originalc);positions={}
for ply in range(11):
 if ply in (4,10):positions[ply]=s.state.position
 if ply<10:s.submit(action_from_dict(case['route'][ply]))
variants=[]
for lifetime in ('expire_next_turn','persistent'):
 rules=replace(oldrules,semantic_actions=tuple(replace(a,aux_state=tuple(replace(slot,lifetime=lifetime) if slot.name=='temp_right' else slot for slot in a.aux_state)) for a in oldrules.semantic_actions));c=compile_ruleset_for_execution(rules);variants.append((lifetime,rules,c,InteractionProjection(c)))
mp=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(mp.read_bytes());write_record(p/'lifetime-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),model_sha256=hashlib.sha256(mp.read_bytes()).hexdigest(),parents=[4,10],rules=[dict(lifetime=life,rules=ruleset_to_dict(rules)) for life,rules,c,e in variants],gates=[0,1]))
def fresh(pos,c):
 key=repetition_identity_key(pos,c);counts=((key,1),);h=(HistoryRecord(key,-1,'',False),);return GameState(pos,0,counts,semantic_engine_for(c).terminal_result(pos,0,counts,h),h)
class Cost(Exception):pass
original=search.legal_successors;rows=[];start=time.perf_counter()
for ply,pos in positions.items():
 for gate in (0,1):
  for life,rules,c,enc in variants:
   aux=dict(pos.aux_state);aux[(0,-1)]=gate;st=fresh(replace(pos,ruleset_fingerprint=c.ruleset_fingerprint,aux_state=tuple(sorted(aux.items()))),c);sign=1 if pos.side_to_move==0 else -1;row=dict(ply=ply,gate=gate,lifetime=life,children=[],transitions=0,complete=False,root_feature=enc.encode(st.position).tolist());t=time.perf_counter()
   def raw(position):
    x=enc.encode(position);return float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights'])
   def check():
    if time.perf_counter()-t>20 or row['transitions']>100000:raise Cost()
   def successors(state,compiled):
    check()
    for a,ch in original(state,compiled):row['transitions']+=1;check();yield a,ch
   search.legal_successors=successors
   try:
    for a,ch in successors(st,c):
     score,_=search.reference_minimax(ch,1,UnitEvaluator(),c,ply=1);check();row['children'].append(dict(action=action_to_dict(a),teacher=-score,raw=sign*raw(ch.position),feature=enc.encode(ch.position).tolist(),aux=record_value(ch.position.aux_state),terminal=record_value(ch.terminal_status)))
    row['complete']=True
   except Cost:row['failure']='partial front UNKNOWN'
   finally:search.legal_successors=original
   row['seconds']=time.perf_counter()-t;rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
comparisons=[]
for ply in positions:
 for gate in (0,1):
  a=next(r for r in rows if r['ply']==ply and r['gate']==gate and r['lifetime']=='expire_next_turn');b=next(r for r in rows if r['ply']==ply and r['gate']==gate and r['lifetime']=='persistent');la={json.dumps(v['action'],sort_keys=True):v for v in a['children']};lb={json.dumps(v['action'],sort_keys=True):v for v in b['children']};common=set(la)&set(lb);diff=[dict(action=la[k]['action'],scores=[la[k]['teacher'],lb[k]['teacher']],raw=[la[k]['raw'],lb[k]['raw']],features_equal=la[k]['feature']==lb[k]['feature'],aux=[la[k]['aux'],lb[k]['aux']]) for k in sorted(common) if la[k]['teacher']!=lb[k]['teacher']];comparisons.append(dict(ply=ply,gate=gate,root_features_equal=a['root_feature']==b['root_feature'],legal_sets_equal=set(la)==set(lb),common=len(common),complete=a['complete'] and b['complete'],differences=diff))
write_record(out,dict(scope=__doc__,rows=rows,comparisons=comparisons,seconds=time.perf_counter()-start,complete=True,limits='Equal vectors with different finite labels restrict this predictor input, not all constants/models or true value. Full RuleSet/GameState must stay available to executor; no enlarged learning architecture follows.'))
print([(r['ply'],r['gate'],r['legal_sets_equal'],r['root_features_equal'],len(r['differences']),sum(v['features_equal'] for v in r['differences'])) for r in comparisons])
