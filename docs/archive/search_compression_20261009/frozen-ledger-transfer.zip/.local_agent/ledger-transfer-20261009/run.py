"""Prospective frozen-predictor/proxy same-protocol transfer, no fitting.
Two new seeds2116/2117, existing8x8hybrid/guarded-drop/temporal-transform family.
Freeze rules, routes and model before any numeric child score or teacher label.
All17route roots per rule and all actual legal children; full GameState carrier.
Same one-ply direct ranker: original affine predictor vs raw current-board proxy
vs staticv3 material baseline (dynamic terms disabled). Terminal wins/losses use
priority ahead of nonterminals; terminal draw uses0, reported separately.
Fixed antisymmetry is the declared owner/rotation projection, not assumed legal.
All terminal same-outcome values0, no new training or fitted choice.
Raw scales are only used WITHIN each scorer; no cross-model leaf conversion.
Expected<5min, per-root20sec/10000transition checkpoint, retain UNKNOWNs.
Changed choices prove sensitivity only. No new training/default/strength claim.
"""
from pathlib import Path
from dataclasses import replace
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('.local_agent/interaction-20261009'))]
from prototype import InteractionProjection
sys.path.insert(0,str(Path('.local_agent/predictor-transfer-20261009')))
from ledger import FrozenLedger
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'result.json';assert not out.exists();modelpath=Path('.local_agent/preference-20261009/partial2048-model.json');m=json.loads(modelpath.read_bytes());w=np.zeros(938);w[np.asarray(m['count_columns'])[m['columns']]]=np.asarray(m['weights'])/m['scale'];cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);frozen=[];prepared=[];fixtures=weird_rulesets()
for seed in (202610082116,202610082117):
 generated=generate_game(GeneratorConfig(seed=seed,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));base_drop=fixtures[1].semantic_actions[0];base_quiet=fixtures[2].semantic_actions[0];drop=replace(base_drop,type_ids=('P',),replace_selector=replace(base_drop.replace_selector,type_ids=('P',)),slot_guards=(RuleSlotGuard(slot_name='temp_right',value=0),));effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id='P')) if e.kind=='set_current_type' else e for e in base_quiet.effects);quiet=replace(base_quiet,type_ids=('X',),target_relation='empty',effects=effects);rules=replace(generated.ruleset,semantic_actions=(drop,quiet));c=compile_ruleset_for_execution(rules);s=GameSession(c);route=[]
 for ply in range(16):
  if s.state.terminal_status.is_terminal:break
  acts=s.legal_actions()
  if not acts:break
  def order(a):
   raw=action_to_dict(a);capture=False
   if hasattr(a,'to_square'):
    piece=s.state.position.board[a.to_square.rank*8+a.to_square.file];capture=piece is not None and piece.owner!=s.state.position.side_to_move
   return (0 if raw.get('pattern_id','').startswith('sem_01_') else 1 if raw.get('pattern_id','').startswith('sem_00_') else 2 if capture else 3,json.dumps(raw,sort_keys=True))
  a=min(acts,key=order);route.append(action_to_dict(a));s.submit(a)
 profile,scope=build_semantic_opportunity_profile(c,cfg);encoder=InteractionProjection(c);prepared.append((c,encoder,Evaluator(c,profile,cfg),FrozenLedger(c,m)));frozen.append(dict(seed=seed,rules=ruleset_to_dict(rules),route=route,v3_board=dict(profile.board_value_by_type),v3_hand=dict(profile.hand_value_by_base_type),fingerprint=c.ruleset_fingerprint))
write_record(p/'declaration.json',dict(scope=__doc__,base_commit='724e2e72abc734bb93cefbecfca704dbd05d3bf2',model_sha256=hashlib.sha256(modelpath.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules=frozen))
report=dict(scope=__doc__,rules=[],complete=False);start=time.perf_counter()
class Cost(Exception):pass
for case,(c,encoder,v3,ledger) in zip(frozen,prepared):
 s=GameSession(c);rr=dict(seed=case['seed'],roots=[]);report['rules'].append(rr)
 for ply in range(len(case['route'])+1):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];before=s.state;owner=before.position.side_to_move;sign=1 if owner==0 else -1;t=time.perf_counter();row=dict(ply=ply,children=[],complete=False,transitions=0);rr['roots'].append(row)
  try:
   acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True));row['legal_actions']=len(acts)
   for a in acts:
    if time.perf_counter()-t>20 or row['transitions']>=10000:raise Cost()
    child=apply_action(before,a,c);row['transitions']+=1;x=encoder.encode(child.position);full=sign*float(((x[m['count_columns']][m['columns']]-m['mean'])/m['scale'])@m['weights']);proxy=sign*sum((1 if a.owner==0 else -1)*float(encoder.actors[a.current_type_id]@(w[:66]+w[396:462])) for a in child.position.board if a is not None);v3value=float(v3.evaluate(child))*(1 if child.position.side_to_move==owner else -1);terminal=child.terminal_status
    priority=1 if terminal.is_terminal and terminal.winner==owner else -1 if terminal.is_terminal and terminal.winner is not None else 0
    values=dict(full=full,proxy=proxy,v3=v3value,symmetric=sign*ledger.symmetric(child.position))
    if terminal.is_terminal:values={k:0. for k in values}
    row['children'].append(dict(action=action_to_dict(a),values=values,priority=priority,terminal=record_value(terminal),base_mismatches=sum(a is not None and a.current_type_id!=a.base_type_id for a in child.position.board)))
   row['chosen']={name:[i for i,x in enumerate(row['children']) if (x['priority'],x['values'][name])==max((v['priority'],v['values'][name]) for v in row['children'])] for name in ('full','proxy','v3','symmetric')} if acts else {n:[] for n in ('full','proxy','v3','symmetric')};row['complete']=True
  except Cost:row['failure']='root cost checkpoint; rankings UNKNOWN'
  row['seconds']=time.perf_counter()-t;assert before==s.state;write_record(out,report)
  if ply<len(case['route']):s.submit(action_from_dict(case['route'][ply]))
 print(case['seed'],len(rr['roots']),round(time.perf_counter()-start,2),flush=True)
report.update(complete=True,seconds=time.perf_counter()-start);write_record(out,report)
