"""Small next-route audit: explicit current-type effect target is rule information.
Change Xquiet's targetPtoC, replay only a common existing legal prefix and one
shared action. No training/new teacher/default changes or board transplantation.
"""
from pathlib import Path
import sys,json,copy
import numpy as np
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path('.local_agent/sharing-20261009')))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from scripts.research_record import write_record,record_value
from rule_counts import descriptors
p=Path('.local_agent');out=p/'effect-target-20261009.json';assert not out.exists();plan=json.loads((p/'sharing-20261009/rule-declaration.json').read_bytes());raw=plan['rule_descriptors'][0]['rules'];changed=copy.deepcopy(raw);effect=next(e for e in changed['semantic_actions'][1]['effects']if e['kind']=='set_current_type');assert effect['type_ref']==dict(kind='explicit',type_id='P');effect['type_ref']['type_id']='C'
c=compile_ruleset_for_execution(ruleset_from_dict(raw));nc=compile_ruleset_for_execution(ruleset_from_dict(changed));v,_=descriptors(c);nv,_=descriptors(nc);equal={t:bool(np.array_equal(v[t],nv[t]))for t in v};s=GameSession(c);ns=GameSession(nc);root=next(r for r in plan['roots']if r['rule_index']==0 and r['ply']==16);witness=None
for ply in range(17):
 assert s.state.position.board==ns.state.position.board and s.state.position.hands==ns.state.position.hands and s.state.position.aux_state==ns.state.position.aux_state
 old={json.dumps(action_to_dict(a),sort_keys=True):a for a in s.legal_actions()};new={json.dumps(action_to_dict(a),sort_keys=True):a for a in ns.legal_actions()};matching=[key for key in old.keys()&new.keys()if json.loads(key).get('pattern_id','').startswith('sem_01_')]
 if matching:
  key=sorted(matching)[0];before=record_value(s.state);s.submit(old[key]);ns.submit(new[key]);different=[i for i,(a,b)in enumerate(zip(s.state.position.board,ns.state.position.board))if a!=b];assert different
  witness=dict(ply=ply,action=json.loads(key),before=before,after_original=record_value(s.state),after_changed=record_value(ns.state),different_board_squares=different);break
 if ply==16:break
 key=json.dumps(root['route'][ply],sort_keys=True);assert key in old and key in new;s.submit(old[key]);ns.submit(new[key])
assert witness is not None
write_record(out,dict(scope=__doc__,original_rules=raw,changed_rules=changed,descriptor_equal=equal,witness=witness,limits='Typed effect destination changes an actual common action outcome. Count of type-change effects is insufficient rule information; this is not a value estimate or proof that all prior approximations fail. Future shared state/rule input must preserve target mechanics, not arbitrary type IDs.'))
print(dict(descriptor_equal=equal,ply=witness['ply'],different_squares=witness['different_board_squares']))
