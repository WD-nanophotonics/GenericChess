"""Untrained typed-target relation prototype; numeric names/IDs are not features.
Resolve explicit current-type effects and declared promotion targets into the
same22behavior axes, deduplicate targets, append mean/max target descriptors.
Other references/state/history remain explicit omissions. No price/utility claim.
"""
from pathlib import Path
import sys,json
import numpy as np
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path('.local_agent/sharing-20261009')))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.research_record import write_record
from rule_counts import descriptors,AXES
p=Path('.local_agent');out=p/'effect-relation-20261009.json';assert not out.exists();probe=json.loads((p/'effect-target-20261009.json').read_bytes());dup=json.loads((p/'sharing-20261009/rule-duplicate-control.json').read_bytes());keep=[i for i in range(20)if AXES[i]!='promotion_targets']+[35,36];results={}
for name,raw in(('original',probe['original_rules']),('changed_target',probe['changed_rules']),('duplicate',dup['changed_rules'])):
 c=compile_ruleset_for_execution(ruleset_from_dict(raw));old,_=descriptors(c);base={};scope={}
 for tid in old:
  drops=[pattern for pattern in c.ir.patterns if tid in pattern.type_ids and any(c.ir.geometry[g].kind=='drop'for g in pattern.geometry_ids)];enabled=any(any(mask)for mask in c.support.drop_allowed.get(tid,()))and any(not any(g.aggregation=='count'and g.comparison=='lt'and g.value<=0 for g in pattern.guards)for pattern in drops)
  base[tid]=np.concatenate((old[tid][keep],[float(enabled and not c.support.type_metadata[tid].is_anchor)]))
 vectors={}
 for tid in old:
  targets=set(c.support.type_metadata[tid].promotion_target_ids);unknown=[]
  for pattern in c.ir.patterns:
   if tid not in pattern.type_ids:continue
   for effect in pattern.effects:
    if effect.kind!='set_current_type':continue
    if effect.type_ref is not None and effect.type_ref.kind=='explicit':targets.add(effect.type_ref.type_id)
    else:unknown.append(pattern.pattern_id)
  values=np.asarray([base[t]for t in sorted(targets)]);mean=values.mean(axis=0)if len(values)else np.zeros(22);maximum=values.max(axis=0)if len(values)else np.zeros(22);vectors[tid]=np.concatenate((base[tid],mean,maximum)).tolist();scope[tid]=dict(resolved_targets=sorted(targets),unknown_type_refs=unknown)
 results[name]=dict(vectors=vectors,scope=scope)
assert results['original']['vectors']==results['duplicate']['vectors'];changed=[t for t in old if results['original']['vectors'][t]!=results['changed_target']['vectors'][t]];assert changed==['X']
write_record(out,dict(scope=__doc__,actor_dimension=66,variants=results,duplicate_equal=True,target_change_distinguished=changed,trained=False,limits='Mean/max is an explicit approximation, not optimal promotion utility. Implicit source/base references, conditional selection, drop/auxiliary history relations and actor splitting still need scoped treatment. No model/training/live interface/default change.'))
print(dict(actor_dimension=66,duplicate_equal=True,target_change_distinguished=changed,trained=False))
