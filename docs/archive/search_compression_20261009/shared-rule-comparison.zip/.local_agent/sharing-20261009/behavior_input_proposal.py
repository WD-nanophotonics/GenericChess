"""Untrained scoped repair of two observed descriptor defects.
Keep opportunity/mask/finite-horizon axes, omit syntactic counts/target cardinality.
Append drop-not-statically-disabled Boolean: empty masks or every active drop
pattern has a count<0guard imply disabled. Other predicates remain unknown.
This upper possibility bound is not legal mobility, complete guard encoding,
calibrated utility or authorization to shrink the full generated rule target.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.research_record import write_record
from rule_counts import descriptors,AXES
p=Path(__file__).parent;assert not(p/'behavior-input-proposal.json').exists();probe=json.loads((p/'guard-operand-probe.json').read_bytes());duplicate=json.loads((p/'rule-duplicate-control.json').read_bytes());keep=[i for i in range(20)if AXES[i]!='promotion_targets']+[35,36];axes=[AXES[i]for i in keep]+['drop_not_statically_disabled'];variants={}
for name,rules in (('original',probe['original_rules']),('duplicate',duplicate['changed_rules']),('disabled',probe['changed_rules'])):
 c=compile_ruleset_for_execution(ruleset_from_dict(rules));old,scope=descriptors(c);vectors={};bounds={}
 for tid in old:
  patterns=[pattern for pattern in c.ir.patterns if tid in pattern.type_ids and any(c.ir.geometry[g].kind=='drop'for g in pattern.geometry_ids)]
  impossible=[pattern.pattern_id for pattern in patterns if any(guard.aggregation=='count'and guard.comparison=='lt'and guard.value<=0 for guard in pattern.guards)]
  masks=c.support.drop_allowed.get(tid,());enabled=any(any(mask)for mask in masks)and any(pattern.pattern_id not in impossible for pattern in patterns)
  if c.support.type_metadata[tid].is_anchor:enabled=False
  vectors[tid]=np.concatenate((old[tid][keep],[float(enabled)]));bounds[tid]=dict(active_drop_patterns=len(patterns),statically_false_count_guards=impossible,upper_possibility=enabled,unknown='Remaining state/slot/path/zone predicates and effect operands are not proved satisfiable.')
 variants[name]=dict(vectors={tid:v.tolist()for tid,v in vectors.items()},bounds=bounds)
assert variants['original']['vectors']==variants['duplicate']['vectors'];different=[tid for tid in old if variants['original']['vectors'][tid]!=variants['disabled']['vectors'][tid]];assert different==['P']
write_record(p/'behavior-input-proposal.json',dict(scope=__doc__,axes=axes,input_dimension_per_actor=len(axes),variants=variants,duplicate_vectors_equal=True,disabled_different_types=different,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limits='No training/model/default change; two concrete controls only. Precise guards, promotion actors/base identity, declaration and history still need explicit treatment. Numeric type/game IDs absent. Do not claim complete generic encoding or utility from passing these controls.'))
print(json.dumps(dict(axes=len(axes),duplicate_equal=True,disabled_changes=different,trained=False)))
