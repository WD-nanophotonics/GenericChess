"""One concrete static-input alias: immediate legal drop-mate availability.
Two saved children only, public GameSession outcomes with full rule/history.
Measure complete immediate successors and costs, not new training/deployment.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not(p/'drop-context-probe.json').exists();plan=json.loads((p/'rule-declaration.json').read_bytes());alias=json.loads((p/'rule-aliases.json').read_bytes())['witness'];root=next(r for r in plan['roots']if f"{r['seed']}/{r['ply']}"==alias['root']);c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));s=GameSession(c)
for a in root['route']:s.submit(action_from_dict(a))
rows=[]
for index in alias['indices']:
 child=GameSession(c);child._state=s.state;child._search_history_witnesses=s._search_history_witnesses;child.submit(action_from_dict(root['children'][index]));owner=child.state.position.side_to_move;tick=time.perf_counter();actions=child.legal_actions();cells=[]
 for a in actions:
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];branch=GameSession(c);branch._state=child.state;branch._search_history_witnesses=child._search_history_witnesses;branch.submit(a);cells.append(dict(action=action_to_dict(a),terminal=record_value(branch.state.terminal_status)))
 seconds=time.perf_counter()-tick;wins=[r for r in cells if r['terminal']['winner']==owner];rows.append(dict(child_index=index,side=owner,legal_actions=len(actions),seconds=seconds,immediate_wins=wins,all_outcomes=cells))
write_record(p/'drop-context-probe.json',dict(scope=__doc__,root=alias['root'],rows=rows,limits='Two deliberately selected same-static-input witnesses, not a sample benefit or ready evaluator. Extra full legal/successor work is measured; live search already owns it, do not repeat it blindly at every leaf. Any future feature must preserve rule/drop/history semantics and compare full caller cost.'))
print([(r['child_index'],r['legal_actions'],r['seconds'],r['immediate_wins'])for r in rows])
