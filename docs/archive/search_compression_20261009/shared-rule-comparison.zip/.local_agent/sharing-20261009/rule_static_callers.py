"""Exposed development comparison: fixed rule-derived constant prices in search.
All24 frozen roots across four rules, Unit/generic-v2/semantic-v3, two balanced repeats.
Same CoreD3/20000nodes/1second/q0, noTT/order/disk/native/root tactics. Static
board and base-hand terms only; no learned rank outputs as calibrated leaves.
Report finite-Unit teacher regret, actual completion/cost, not price optimum/Elo.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'rule-static-callers.json';assert not out.exists();plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());roots=screen['roots'];compiled=[];profile_rows=[]
for row in plan['rule_descriptors']:
 c=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));tick=time.perf_counter();v2=build_ruleset_profile(c._legacy_compiled,EvaluationConfig());v2secs=time.perf_counter()-tick;tick=time.perf_counter();v3,scope=build_semantic_opportunity_profile(c,EvaluationConfig());v3secs=time.perf_counter()-tick
 ordinary=[t for t,m in c.support.type_metadata.items()if not m.is_anchor];unit={t:1000 if t in ordinary else 0 for t in c.support.type_metadata};profiles={'unit':(unit,unit),'v2':(v2.board_value_by_type,v2.hand_value_by_base_type),'v3':(v3.board_value_by_type,v3.hand_value_by_base_type)};compiled.append((c,profiles));profile_rows.append(dict(seed=row['seed'],profiles=profiles,profile_seconds={'v2':v2secs,'v3':v3secs},v3_scope=scope))
write_record(p/'rule-static-declaration.json',dict(scope=__doc__,rules=profile_rows,conditions=dict(depth=3,nodes=20000,seconds=1,q=0,ordering=False,TT=False),roots=[dict(rule_index=r['rule_index'],seed=r['seed'],ply=r['ply'])for r in roots],exposure='Four exposed rules, full existing denominator, no refit/extra labels/default change; preserve unknown references.'))
rows=[]
for i,ref in enumerate(roots):
 root=next(r for r in plan['roots']if(r['seed'],r['ply'])==(ref['seed'],ref['ply']));c,profiles=compiled[root['rule_index']];s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 sign=1 if root['side']==0 else-1;best=max(sign*x['owner0_target']for x in ref['children'])if ref['known']else None
 for rep in range(2):
  names=('unit','v2','v3');shift=(i+rep)%3
  for name in names[shift:]+names[:shift]:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
   board,hand=profiles[name]
   class Static:
    def evaluate(self,state):
     pos=state.position;own=pos.side_to_move
     value=sum((1 if v.owner==own else-1)*board[v.current_type_id]for v in pos.board if v)
     return value+sum((1 if o==own else-1)*count*hand[t]for o,h in enumerate(pos.hands)for t,count in h.counts)
    def capture_order_value(self,moving,captured):return board[captured.current_type_id]
   player=AlphaBetaPlayer(c,evaluator_override=Static(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));seconds=time.perf_counter()-tick;validate_pv(s,d);assert s.state==before
   chosen=next(x for x in ref['children']if x['action']==action_to_dict(d.action));rows.append(dict(seed=root['seed'],ply=root['ply'],group=root['group'],method=name,rep=rep,seconds=seconds,teacher_regret=None if best is None else best-sign*chosen['owner0_target'],decision=record_value(d)));write_record(out,dict(scope=__doc__,rows=rows,complete=False));print(root['seed'],root['ply'],name,rep,d.completed_depth,rows[-1]['teacher_regret'],flush=True)
write_record(out,dict(scope=__doc__,rows=rows,complete=True,limits='Teacher is finite Unit search, so agreement is not true utility; profile guard/excluded scope in declaration. Tables change leaves only, fixed lexical ordering. Signed rank fit never deployed.'))
