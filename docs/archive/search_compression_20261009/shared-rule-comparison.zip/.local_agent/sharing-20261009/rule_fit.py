"""One frozen rule-conditioned linear root-rank fit; no numeric leaf deployment.
Two complete generated rules train, third dev, fourth report. Same300Adam
budget and candidate-blind conditional screening. No report-driven selection.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
from rule_counts import AXES
p=Path(__file__).parent;assert not(p/'rule-model.json').exists()and not(p/'rule-result.json').exists()
selection=json.loads((p/'rule-selection.json').read_bytes());plan=json.loads((p/'rule-declaration.json').read_bytes())
assert selection['screen_sha256']==hashlib.sha256((p/'rule-screen.json').read_bytes()).hexdigest()
chosen={f"{r['seed']}/{r['ply']}":r for r in selection['roots']if r['selected']}
with np.load(p/'rule-screen-inputs.npz',allow_pickle=False)as data:
 keep=np.asarray([r in chosen for r in data['root_ids']]);x=data['features'][keep];y=data['targets'][keep];r=data['root_ids'][keep];g=data['groups'][keep];ci=data['child_indices'][keep];base=data['baseline'][keep]
sign=np.asarray([1 if next(a for a in plan['roots']if f"{a['seed']}/{a['ply']}"==key)['side']==0 else -1 for key in r]);train=g=='train';train_roots=list(dict.fromkeys(r[train]))
if not train_roots:
 write_record(p/'rule-result.json',dict(status='NO_TRAIN_ROOT_NO_FIT',scope=__doc__,denominator=selection['roots']));raise SystemExit(0)
col=np.flatnonzero(np.ptp(x[train],axis=0)>0);mean=x[train][:,col].mean(axis=0);scale=x[train][:,col].std(axis=0);z=(x[:,col]-mean)/scale
write_record(p/'rule-fit-declaration.json',dict(scope=__doc__,selection_sha256=hashlib.sha256((p/'rule-selection.json').read_bytes()).hexdigest(),input_sha256=hashlib.sha256((p/'rule-screen-inputs.npz').read_bytes()).hexdigest(),axes=AXES,fit=plan['ranking_fit'],calibration='Signed rank coefficients; no nonnegativity/calibration or numerical search binding.',dimension=x.shape[1],variable_columns=col.tolist()))
d=[];pw=[];pair_counts={}
for key in train_roots:
 idx=np.flatnonzero((r==key)&train);ss=sign[idx[0]];t=ss*y[idx];best=np.flatnonzero(t==t.max());other=np.flatnonzero(t<t.max());count=len(best)*len(other);assert count>0;pair_counts[str(key)]=count
 for a in best:
  for b in other:d.append(ss*(z[idx[a]]-z[idx[b]]));pw.append(1/(len(train_roots)*count))
d=np.asarray(d);pw=np.asarray(pw);assert abs(pw.sum()-1)<1e-12
w=np.random.default_rng(2026100949).normal(0,.001,len(col));m=np.zeros_like(w);v=np.zeros_like(w);tick=time.perf_counter()
for step in range(1,301):
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-tick<120
 margin=1-d@w;grad=-(pw*(margin>0))@d+.0001*w;m=.9*m+.1*grad;v=.999*v+.001*grad*grad;w-=.01*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
elapsed=time.perf_counter()-tick;prediction=z@w
model=dict(kind='offline_shared_rule_constant_rank_owner0',axes=AXES,columns=col.tolist(),mean=mean.tolist(),scale=scale.tolist(),weights=w.tolist(),input_dimension=x.shape[1],declaration_sha256=selection['declaration_sha256']);write_record(p/'rule-model.json',model)
restored=json.loads((p/'rule-model.json').read_bytes());assert np.array_equal(prediction,((x[:,restored['columns']]-restored['mean'])/restored['scale'])@restored['weights'])
fullw=np.zeros(x.shape[1]);fullw[col]=w/scale;offset=float(-mean@(w/scale));tables=[]
for row in plan['rule_descriptors']:
 tables.append(dict(seed=row['seed'],types={tid:dict(board_rank=float(np.asarray(vec)@fullw[:len(AXES)]),hand_rank=float(np.asarray(vec)@fullw[len(AXES):]))for tid,vec in row['vectors'].items()}))
rows=[]
for key in dict.fromkeys(r):
 idx=np.flatnonzero(r==key);ss=sign[idx[0]];vv=ss*prediction[idx];tt=ss*y[idx];a=np.flatnonzero(vv==vv.max());greedy=ss*base[idx]==np.max(ss*base[idx]);rows.append(dict(root=str(key),rule_index=chosen[key]['rule_index'],group=str(g[idx[0]]),children=len(idx),chosen_children=ci[idx][a].tolist(),teacher_regret=float(np.mean(tt.max()-tt[a])),material_regret=float(np.mean(tt.max()-tt[greedy]))))
assert np.allclose(prediction,x@fullw+offset,rtol=1e-12,atol=1e-12)
write_record(p/'rule-result.json',dict(scope=__doc__,status='ONE_FIXED_SHARED_FIT_NOT_DEPLOYED',fit_seconds=elapsed,dimension=x.shape[1],variable_columns=len(col),train_roots=len(train_roots),train_children=int(train.sum()),pair_counts=pair_counts,train_pair_zero_fraction=float(np.sum(pw[np.all(d==0,axis=1)])),rows=rows,derived_rank_tables=tables,offset=offset,restored_predictions_exact=True,table_algebra_checked=True,limits='Exposed rules, fresh whole trajectory groups; conditional on screen. Pure rank, incomplete mechanics representation, no unseen-rule generality or calibrated value. No default modification, no report refit.'))
print(json.dumps(dict(seconds=elapsed,train_roots=len(train_roots),rows=rows),indent=2))
