"""Exposed conditional-root resource curve, no training or frozen-test extension.
Unit CoreD3/20knodes/q0 at.2sec, median observed Position rank cost,1sec.
Seven existing teacher-screened roots. All limits frozen before baseline calls.
Compare finite teacher regret and actual elapsed/completion; rank is root-only,
not numeric leaf evaluation. Exact threshold match is local timing, not universal.
"""
from pathlib import Path
import sys,json,time,statistics
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;plan=json.loads((p/'ranking-declaration.json').read_bytes());screen=json.loads((p/'ranking-screen.json').read_bytes());rank=json.loads((p/'ranking-root-callers.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules']));types=non_anchor_type_ids(c);selected=[r for r in screen['roots']if r['selected']];out=p/'ranking-unit-curve.json';assert not out.exists()
limits=[dict(seed=r['seed'],ply=r['ply'],seconds=statistics.median(x['seconds']for x in rank['rows']if x['method']=='position'and(x['seed'],x['ply'])==(r['seed'],r['ply'])))for r in selected];write_record(p/'ranking-unit-curve-declaration.json',dict(scope=__doc__,roots=limits,other_limits=[.2,1.],exposure='Screen/candidate outcomes already inspected. Separate fixed development baseline diagnostic, not a report holdout or changed frozen outcome test.'))
class Unit:
 def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
 def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
rows=[]
for i,ref in enumerate(selected):
 root=next(x for x in plan['roots']if(x['seed'],x['ply'])==(ref['seed'],ref['ply']));s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 ss=1 if root['side']==0 else-1;best=max(ss*x['owner0_target']for x in ref['children']);cost=next(x['seconds']for x in limits if(x['seed'],x['ply'])==(ref['seed'],ref['ply']));cells=[('short',.2),('rank_matched',cost),('one_second',1.)]
 for name,limit in cells[i%3:]+cells[:i%3]:
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
  player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=limit,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);assert s.state==before;a=action_to_dict(d.action);child=next(x for x in ref['children']if x['action']==a)
  rows.append(dict(seed=root['seed'],ply=root['ply'],group=root['group'],kind=name,limit_seconds=limit,seconds=elapsed,teacher_regret=best-ss*child['owner0_target'],decision=record_value(d)));write_record(out,dict(scope=__doc__,rows=rows,complete=False))
write_record(out,dict(scope=__doc__,rows=rows,complete=True));print([(x['seed'],x['ply'],x['kind'],x['decision']['completed_depth'],x['teacher_regret'])for x in rows])
