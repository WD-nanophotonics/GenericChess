"""Existing Core ordering+TT on all four-rule frozen frontiers, Unit leaves.
Two fixed repeats, D3/20knodes/1second/q0, no native/disk/root tactics.
Compare prior balanced lexical Unit calls at exactly these declared limits;
controls occur sequentially, so timing is developmental not blinded strength.
No learned ordering/leaf, new label, default switch or report-driven tuning.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'search-reuse-control.json';assert not out.exists();plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());compiled=[compile_ruleset_for_execution(ruleset_from_dict(r['rules']))for r in plan['rule_descriptors']]
write_record(p/'search-reuse-declaration.json',dict(scope=__doc__,conditions=dict(depth=3,nodes=20000,seconds=1,q=0,ordering=True,TT=True,root_tactical=False,native=False,disk=False),baseline='rule-static-callers.json Unit two fixed balanced repeats, noTT/noordering; same depth/nodes/time/q',limits='Cold per-call player/TT, existing compiler caches shared within process; no cross-root learned parameters. Full original root states/routes/witnesses unchanged.'))
rows=[]
for rep in range(2):
 for i in (range(len(plan['roots']))if rep==0 else reversed(range(len(plan['roots'])))):
  root=plan['roots'][i];ref=screen['roots'][i];c=compiled[root['rule_index']];types=non_anchor_type_ids(c);s=GameSession(c)
  for a in root['route']:s.submit(action_from_dict(a))
  class Unit:
   def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
   def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
  player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=True,use_ordering=True,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);assert s.state==before;ss=1 if root['side']==0 else-1;chosen=next(x for x in ref['children']if x['action']==action_to_dict(d.action));regret=None if not ref['known']else max(ss*x['owner0_target']for x in ref['children'])-ss*chosen['owner0_target'];rows.append(dict(seed=root['seed'],ply=root['ply'],rule_index=root['rule_index'],group=root['group'],rep=rep,seconds=elapsed,teacher_regret=regret,decision=record_value(d)));write_record(out,dict(scope=__doc__,complete=False,rows=rows));print(root['seed'],root['ply'],rep,d.completed_depth,regret,flush=True)
write_record(out,dict(scope=__doc__,complete=True,rows=rows,limits='Finite Unit target, dependent/exposed contexts, sequential timing. TT/order tested together, not isolated attribution. Different tie choice or deeper completion alone is not utility gain. No default modification.'))
