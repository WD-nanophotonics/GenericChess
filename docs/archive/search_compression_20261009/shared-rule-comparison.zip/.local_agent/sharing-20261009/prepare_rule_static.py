"""Mechanical reuse of fixed static search producer, not another model protocol."""
from pathlib import Path
p=Path(__file__).parent;s=(p/'static_callers.py').read_text()
s=s.replace('All seven fresh selected roots','All24 frozen roots across four rules').replace("out=p/'static-callers.json'","out=p/'rule-static-callers.json'")
a=s.index("plan=json.loads((p/'ranking-declaration.json')");b=s.index('rows=[]',a)
s=s[:a]+'''plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());roots=screen['roots'];compiled=[];profile_rows=[]
for row in plan['rule_descriptors']:
 c=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));tick=time.perf_counter();v2=build_ruleset_profile(c._legacy_compiled,EvaluationConfig());v2secs=time.perf_counter()-tick;tick=time.perf_counter();v3,scope=build_semantic_opportunity_profile(c,EvaluationConfig());v3secs=time.perf_counter()-tick
 ordinary=[t for t,m in c.support.type_metadata.items()if not m.is_anchor];unit={t:1000 if t in ordinary else 0 for t in c.support.type_metadata};profiles={'unit':(unit,unit),'v2':(v2.board_value_by_type,v2.hand_value_by_base_type),'v3':(v3.board_value_by_type,v3.hand_value_by_base_type)};compiled.append((c,profiles));profile_rows.append(dict(seed=row['seed'],profiles=profiles,profile_seconds={'v2':v2secs,'v3':v3secs},v3_scope=scope))
write_record(p/'rule-static-declaration.json',dict(scope=__doc__,rules=profile_rows,conditions=dict(depth=3,nodes=20000,seconds=1,q=0,ordering=False,TT=False),roots=[dict(rule_index=r['rule_index'],seed=r['seed'],ply=r['ply'])for r in roots],exposure='Four exposed rules, full existing denominator, no refit/extra labels/default change; preserve unknown references.'))
'''+s[b:]
s=s.replace("s=GameSession(c)\n for a","c,profiles=compiled[root['rule_index']];s=GameSession(c)\n for a")
s=s.replace("best=max(sign*x['owner0_target']for x in ref['children'])","best=max(sign*x['owner0_target']for x in ref['children'])if ref['known']else None")
s=s.replace("teacher_regret=best-sign*chosen['owner0_target']","teacher_regret=None if best is None else best-sign*chosen['owner0_target']")
assert not(p/'rule_static_callers.py').exists();(p/'rule_static_callers.py').write_bytes(s.encode())
