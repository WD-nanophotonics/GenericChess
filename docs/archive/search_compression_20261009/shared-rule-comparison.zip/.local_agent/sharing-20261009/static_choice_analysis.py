"""Explain opposite static-price effects from saved balanced caller decisions.
No refit/new teacher/default change. Reconstruct actual PV states and decompose
board/hand leaf scores. Finite Unit target is not independent real utility.
"""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not(p/'static-choice-analysis.json').exists();plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());calls=json.loads((p/'rule-static-callers.json').read_bytes());profiles=json.loads((p/'rule-static-declaration.json').read_bytes());rows=[]
for seed,ply in ((2026101101,16),(2026101110,7)):
 root=next(r for r in plan['roots']if(r['seed'],r['ply'])==(seed,ply));ref=next(r for r in screen['roots']if(r['seed'],r['ply'])==(seed,ply));c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));tables=profiles['rules'][root['rule_index']]['profiles'];methods=[]
 for method in ('unit','v2','v3'):
  call=next(x for x in calls['rows']if(x['seed'],x['ply'],x['method'],x['rep'])==(seed,ply,method,0));decision=call['decision'];s=GameSession(c)
  for a in root['route']:s.submit(action_from_dict(a))
  board,hand=tables[method];states=[]
  for a in decision['principal_variation']:
   legal=next(candidate for candidate in s.legal_actions()if record_value(candidate)==a)
   s.submit(legal);pos=s.state.position;ss=1 if root['side']==0 else-1;terms={}
   for v in pos.board:
    if v:
     key=f'board/{v.owner}/{v.current_type_id}';terms[key]=terms.get(key,0)+ss*(1 if v.owner==0 else-1)*board[v.current_type_id]
   for owner,h in enumerate(pos.hands):
    for tid,count in h.counts:terms[f'hand/{owner}/{tid}']=ss*(1 if owner==0 else-1)*count*hand[tid]
   states.append(dict(action=action_to_dict(legal),board_hand_root_score=sum(terms.values()),terms=terms,terminal=record_value(s.state.terminal_status)))
  methods.append(dict(method=method,decision=decision,teacher_regret=call['teacher_regret'],pv_states=states))
 rows.append(dict(seed=seed,ply=ply,group=root['group'],rule_index=root['rule_index'],tables=tables,teacher_targets=[dict(action=x['action'],target=x['owner0_target'])for x in ref['children']],methods=methods))
write_record(p/'static-choice-analysis.json',dict(scope=__doc__,rows=rows,limits='Two post-result diagnostic roots, no causal isolation of target validity. Lexical move order fixed, leaf prices change; actual completion/counts retained. Opposite effects prevent blanket deployment/gain claim.'))
print([(r['seed'],[(m['method'],m['teacher_regret'],m['decision']['score'],m['decision']['completed_depth'])for m in r['methods']])for r in rows])
