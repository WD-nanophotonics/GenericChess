"""Exposed diagnostic: shared per-rule board/current and hand/base counts.
Already observed root reports are not a fresh holdout. Fit train roots only once
with the same root-weighted hinge budget; measure a constant-only input contrast
to sparse coordinate memorization. No human prices, default or numeric leaf use.
"""
from pathlib import Path
import os
for key in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent;assert not(p/'constant-model.json').exists();plan=json.loads((p/'ranking-declaration.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules']));enc=SparsePositionEncoder(c);nt=len(enc.types);area=enc.shape.area
with np.load(p/'ranking-selected-inputs.npz',allow_pickle=False)as d:
 x=d['position'].copy();y=d['targets'].copy();r=d['roots'].copy();g=d['groups'].copy();sg=d['signs'].copy();ci=d['children'].copy();base=d['baseline'].copy()
board=x[:,:enc.hand_offset].reshape((-1,2,nt,area)).sum(axis=3);hand=x[:,enc.hand_offset:enc.side_offset].reshape((-1,2,nt));ordinary=[i for i,t in enumerate(enc.types)if not c.support.type_metadata[t].is_anchor]
xx=np.concatenate((board[:,0,ordinary]-board[:,1,ordinary],hand[:,0,ordinary]-hand[:,1,ordinary]),axis=1)
assert np.array_equal(1000*xx.sum(axis=1),base)
train=g=='train';train_roots=list(dict.fromkeys(r[train]));col=np.flatnonzero(np.ptp(xx[train],axis=0)>0);mean=xx[train][:,col].mean(axis=0);scale=xx[train][:,col].std(axis=0);z=(xx[:,col]-mean)/scale
write_record(p/'constant-declaration.json',dict(scope=__doc__,inputs='Owner0 current board counts and base hand counts, anchors excluded; no spatial/rule-general weights.',ordinary_types=[enc.types[i]for i in ordinary],fit='same300Adam/.01/.0001/0949, equal-root optimal-lower margin1, train-only columns/normalization; no positivity/price calibration claim.',exposure='Development diagnosis after report results inspected; train only, one fit, no holdout restoration.',comparison='Does a cheap static count scorer retain useful teacher choices? Exact count collisions diagnose information loss, not reject all fixed prices.',inputs_sha256=hashlib.sha256((p/'ranking-selected-inputs.npz').read_bytes()).hexdigest()))
diffs=[];pw=[];contradictions=[]
for key in train_roots:
 idx=np.flatnonzero((r==key)&train);ss=sg[idx[0]];t=ss*y[idx];best=np.flatnonzero(t==t.max());other=np.flatnonzero(t<t.max());count=len(best)*len(other)
 for a in best:
  for b in other:diffs.append(ss*(z[idx[a]]-z[idx[b]]));pw.append(1/(len(train_roots)*count))
for key in dict.fromkeys(r):
 idx=np.flatnonzero(r==key);ss=sg[idx[0]];seen={};pairs=0;maxdiff=0;witness=None
 for j in idx:
  sig=xx[j].tobytes()
  for k in seen.get(sig,[]):
   diff=abs(y[j]-y[k])
   if diff:pairs+=1;maxdiff=max(maxdiff,float(diff));witness=witness or [int(ci[k]),int(ci[j])]
  seen.setdefault(sig,[]).append(j)
 contradictions.append(dict(root=str(key),group=str(g[idx[0]]),contradictory_pairs=pairs,max_teacher_difference=maxdiff,first_children=witness))
d=np.asarray(diffs);pw=np.asarray(pw);w=np.random.default_rng(2026100949).normal(0,.001,len(col));m=np.zeros_like(w);v=np.zeros_like(w);tick=time.perf_counter()
for step in range(1,301):
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 margin=1-d@w;grad=-(pw*(margin>0))@d+.0001*w;m=.9*m+.1*grad;v=.999*v+.001*grad*grad;w-=.01*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
elapsed=time.perf_counter()-tick;prediction=z@w;model=dict(kind='offline_linear_constant_root_rank_owner0',columns=col.tolist(),mean=mean.tolist(),scale=scale.tolist(),weights=w.tolist(),ordinary_types=[enc.types[i]for i in ordinary],ruleset_fingerprint=c.ruleset_fingerprint);write_record(p/'constant-model.json',model)
rows=[]
for key in dict.fromkeys(r):
 idx=np.flatnonzero(r==key);ss=sg[idx[0]];vv=ss*prediction[idx];tt=ss*y[idx];chosen=np.flatnonzero(vv==vv.max());unit=ss*base[idx];greedy=unit==unit.max();rows.append(dict(root=str(key),group=str(g[idx[0]]),chosen_children=ci[idx][chosen].tolist(),teacher_regret=float(np.mean(tt.max()-tt[chosen])),material_regret=float(np.mean(tt.max()-tt[greedy]))))
write_record(p/'constant-result.json',dict(scope=__doc__,fit_seconds=elapsed,dimension=xx.shape[1],variable_columns=len(col),rows=rows,count_collisions=contradictions,train_pair_zero_fraction=float(np.sum(pw[np.all(d==0,axis=1)])),limits='Signed unconstrained rank coefficients are not calibrated/nonnegative prices; one exposed-rule/count prototype. Incompatible labels at identical inputs prevent exact target recovery, not approximate usefulness. No report-driven refit or numerical search binding.'))
print(json.dumps(dict(fit_seconds=elapsed,dimension=xx.shape[1],variable=len(col),zero_pairs=float(np.sum(pw[np.all(d==0,axis=1)])),rows=rows),indent=2))
