"""Actual root-only rank selection with full semantic legal children.
Selected conditional roots only; material/Position/Position+pairs, three balanced
repeats. No numeric leaf binding, deeper search or model selection from reports.
Measure full legal-frontier generation+state transitions+feature extraction+score.
"""
from pathlib import Path
import os
for k in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent;plan=json.loads((p/'ranking-declaration.json').read_bytes());selection=json.loads((p/'ranking-selection.json').read_bytes());fitted=json.loads((p/'ranking-result.json').read_bytes());assert fitted['status']=='TWO_FIXED_FITS_COMPLETE_NOT_DEPLOYED';out=p/'ranking-root-callers.json';assert not out.exists()
c=compile_ruleset_for_execution(ruleset_from_dict(plan['rules']));enc=SparsePositionEncoder(c);types=non_anchor_type_ids(c);nt=2*len(enc.types);width=c.board_shape.width;height=c.board_shape.height;dxn=2*width-1;dyn=2*height-1;pairdim=nt*nt*27
models={name:json.loads((p/f'ranking-model-{name}.json').read_bytes())for name in('position','position_pairs')};arrays={name:(np.asarray(v['columns']),np.asarray(v['mean']),np.asarray(v['scale']),np.asarray(v['weights']))for name,v in models.items()};screen=json.loads((p/'ranking-screen.json').read_bytes());rows=[];selected={(r['seed'],r['ply'])for r in selection['roots']if r['selected']}
for i,root in enumerate([x for x in plan['roots']if(x['seed'],x['ply'])in selected]):
 ref=next(x for x in screen['roots']if(x['seed'],x['ply'])==(root['seed'],root['ply']));ss=1 if root['side']==0 else-1;best=max(ss*x['owner0_target']for x in ref['children'])
 s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 before=s.state
 for rep in range(3):
  names=('material','position','position_pairs');shift=(rep+i)%3
  for name in names[shift:]+names[:shift]:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
   tick=time.perf_counter();acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True));legal_seconds=time.perf_counter()-tick;assert[action_to_dict(a)for a in acts]==root['children'];vals=[];feature_seconds=0;transition_seconds=0
   for a in acts:
    tt=time.perf_counter();child=apply_action(s.state,a,c);transition_seconds+=time.perf_counter()-tt;tt=time.perf_counter()
    if name=='material':value=1000*sum(material_features(child.position,types,perspective=0).array())
    else:
     xx=enc.dense(child.position)
     if name=='position_pairs':
      actors=np.asarray([(sq%width,sq//width,v.owner*len(enc.types)+enc.type_index[v.current_type_id])for sq,v in enumerate(child.position.board)if v],dtype=np.intp);dx=actors[None,:,0]-actors[:,None,0];dy=actors[None,:,1]-actors[:,None,1];distance=np.maximum(np.abs(dx),np.abs(dy));band=np.where(distance<=1,0,np.where(distance<=2,1,2));ix=(((actors[:,None,2]*nt+actors[None,:,2])*3+np.sign(dx)+1)*3+np.sign(dy)+1)*3+band;ix,counts=np.unique(ix[~np.eye(len(actors),dtype=bool)],return_counts=True);pp=np.zeros(pairdim);pp[ix]=counts;xx=np.concatenate((xx,pp))
     col,mean,scale,w=arrays[name];value=float(((xx[col]-mean)/scale)@w)
    feature_seconds+=time.perf_counter()-tt;vals.append(ss*value)
   chosen=np.flatnonzero(vals==np.max(vals));targets=[ss*ref['children'][j]['owner0_target']for j in chosen]
   assert s.state==before
   rows.append(dict(seed=root['seed'],ply=root['ply'],group=root['group'],method=name,rep=rep,actions=len(acts),chosen_indices=chosen.tolist(),teacher_regret=float(np.mean(best-np.asarray(targets))),seconds=time.perf_counter()-tick,legal_seconds=legal_seconds,transition_seconds=transition_seconds,feature_score_seconds=feature_seconds));write_record(out,dict(scope=__doc__,rows=rows,complete=False))
write_record(out,dict(scope=__doc__,rows=rows,complete=True,limits='Local small root-only policy, conditional screening, not search strength or calibrated values. All three methods regenerate legal frontiers; models/data unchanged.'))
print([(n,sum(r['seconds']for r in rows if r['method']==n),sum(r['feature_score_seconds']for r in rows if r['method']==n))for n in('material','position','position_pairs')])
