"""Existing CoreD1 on the two concrete drop-context witnesses.
Same complete rule/history, unit leaves, no feature learning or new labels.
Measure whether an existing generic search answers the proposed feature question.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not(p/'drop-search-control.json').exists();plan=json.loads((p/'rule-declaration.json').read_bytes());alias=json.loads((p/'rule-aliases.json').read_bytes())['witness'];root=next(r for r in plan['roots']if f"{r['seed']}/{r['ply']}"==alias['root']);c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));types=non_anchor_type_ids(c);s=GameSession(c)
for a in root['route']:s.submit(action_from_dict(a))
class Unit:
 def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
 def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
rows=[]
for rep in range(2):
 for index in alias['indices'][::1 if rep==0 else -1]:
  child=GameSession(c);child._state=s.state;child._search_history_witnesses=s._search_history_witnesses;child.submit(action_from_dict(root['children'][index]));player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();decision=player.choose_action(child,SearchLimits(max_depth=1,max_nodes=2048,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(child,decision);rows.append(dict(index=index,rep=rep,seconds=elapsed,decision=record_value(decision)))
write_record(p/'drop-search-control.json',dict(scope=__doc__,rows=rows,limits='Two post-result diagnostic states. D1 cost is local actual cost, not strength or unseen-rule evidence. Do not build a learned threat feature that simply duplicates this work without a measurable cost/signal advantage.'))
print([(r['index'],r['rep'],r['seconds'],r['decision']['score'],r['decision']['completed_depth'])for r in rows])
