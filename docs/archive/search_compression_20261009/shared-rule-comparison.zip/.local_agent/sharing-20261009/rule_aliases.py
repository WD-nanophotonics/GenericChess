"""Post-fit information-loss diagnosis; no new labels, fit or holdout claims.
Exact shared-input collisions within retained complete child frontiers. Compare
full board/base/hand/aux fields for one adverse training-root witness.
"""
from pathlib import Path
import sys,json
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;assert not(p/'rule-aliases.json').exists();plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());rows=[];witness=None
with np.load(p/'rule-screen-inputs.npz',allow_pickle=False)as data:
 x=data['features'];y=data['targets'];ids=data['root_ids'];ci=data['child_indices']
 for root,ref in zip(plan['roots'],screen['roots']):
  if not ref['known']:continue
  key=f"{root['seed']}/{root['ply']}";idx=np.flatnonzero(ids==key);seen={};count=0;maximum=0;pair=None
  for j in idx:
   sig=x[j].tobytes()
   for k in seen.get(sig,[]):
    difference=abs(y[j]-y[k])
    if difference:
     count+=1
     if difference>maximum:maximum=float(difference);pair=(int(ci[k]),int(ci[j]))
   seen.setdefault(sig,[]).append(j)
  rows.append(dict(root=key,group=root['group'],rule_index=root['rule_index'],children=len(idx),different_target_same_input_pairs=count,max_difference=maximum,children_pair=pair))
  if root['group']=='train'and pair is not None and witness is None:
   c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));s=GameSession(c)
   for a in root['route']:s.submit(action_from_dict(a))
   aa,bb=pair;a=apply_action(s.state,action_from_dict(root['children'][aa]),c);b=apply_action(s.state,action_from_dict(root['children'][bb]),c)
   witness=dict(root=key,indices=pair,actions=[root['children'][aa],root['children'][bb]],targets=[ref['children'][aa]['owner0_target'],ref['children'][bb]['owner0_target']],states=[record_value(a),record_value(b)],same_hands=a.position.hands==b.position.hands,same_aux=a.position.aux_state==b.position.aux_state,different_board_squares=[i for i,(pa,pb)in enumerate(zip(a.position.board,b.position.board))if pa!=pb])
write_record(p/'rule-aliases.json',dict(scope=__doc__,rows=rows,witness=witness,limits='Static input cannot recover all contextual root choices. This does not reject static prices as leaves inside legal/terminal-aware search or authorize state/history deletion. Mates/finite outcomes stay separate in summaries.'))
print(json.dumps(dict(rows=rows,witness=None if witness is None else{k:v for k,v in witness.items()if k!='states'}),indent=2))
