"""New shared rule/count input on previously verified auxiliary-name permutation.
No type/layout-ID features, no retraining, no bypass of fingerprint-bound callers.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from scripts.research_record import write_record
from rule_counts import descriptors,encode
p=Path(__file__).parent;assert not(p/'rule-symbol-control.json').exists()
decl=json.loads((p/'aux-symbol-declaration.json').read_bytes());c=compile_semantic_ruleset(ruleset_from_dict(decl['original_rules']));nc=compile_semantic_ruleset(ruleset_from_dict(decl['renamed_rules']));v,scope=descriptors(c);nv,nsc=descriptors(nc)
assert v.keys()==nv.keys();assert all(np.array_equal(v[t],nv[t])for t in v)
mapping={a.pattern_id:b.pattern_id for a,b in zip(c.ir.patterns,nc.ir.patterns)};s=GameSession(c);ns=GameSession(nc);rows=[]
for ply in range(8):
 x=encode(s.state.position,v);nx=encode(ns.state.position,nv);assert np.array_equal(x,nx);rows.append(dict(ply=ply,input_equal=True,dimension=len(x)))
 if ply<7:
  fr,to=decl['route'][ply];a=next(a for a in s.legal_actions()if action_to_dict(a).get('from')==fr and action_to_dict(a).get('to')==to);na=action_to_dict(a)
  if 'pattern_id'in na:na['pattern_id']=mapping[na['pattern_id']]
  s.submit(a);ns.submit(action_from_dict(na))
write_record(p/'rule-symbol-control.json',dict(scope=__doc__,descriptor_equality=True,rows=rows,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limits='Same mechanics only; does not establish complete encoding, type split/additivity or unfamiliar-rule utility. Existing legal-map evidence retained separately.'))
print('8 exact input equalities; rule descriptor equality')
