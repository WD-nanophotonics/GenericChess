"""Scoped mechanical rule-conditioned constant input, offline research only.
Shared axes derive from compiled opportunity curves, masks and typed mechanism
counts. Sum signed current-board and base-hand descriptors; no type/game IDs or
coordinates. Guard counts do not encode predicates/effect operands completely;
on-board base/promotion state and history are deliberately absent approximations.
Full rules/GameState remain with the legal generator and teacher, never altered.
"""
import numpy as np
from generic_chess.ai.evaluation.semantic import semantic_opportunity
from generic_chess.ai.evaluation.config import EvaluationConfig

AXES=('bias','quiet0','capture0','quiet125','capture125','quiet25','capture25',
      'quiet375','capture375','quiet5','capture5','quiet_endpoints','capture_endpoints',
      'drop0','drop1','promotion_targets','promotion_mask0','promotion_mask1',
      'forced0','forced1','patterns','state_guards','slot_guards','zone_guards',
      'path_guards','effects','capture_to_hand','remove_from_game','type_change',
      'postconditions','invariants','excluded_fraction','bool_slots','square_slots',
      'expiring_slots','repetition_limit','max_ply')

def descriptors(c):
 types=tuple(sorted(c.support.type_metadata));area=c.board_shape.area;vectors={};scopes={}
 for tid in types:
  if c.support.type_metadata[tid].is_anchor:
   vectors[tid]=np.zeros(len(AXES));continue
  opp=semantic_opportunity(c,tid,EvaluationConfig());patterns=[p for p in c.ir.patterns if tid in p.type_ids]
  row=[1.]
  for curve in opp['curves']:row.extend((curve['quiet']/area,curve['capture']/area))
  row.extend((opp['quiet_endpoints']/(area*area),opp['capture_endpoints']/(area*area)))
  drops=c.support.drop_allowed.get(tid,((False,)*area,)*2);row.extend(sum(mask)/area for mask in drops)
  meta=c.support.type_metadata[tid];row.append(len(meta.promotion_target_ids))
  masks=c.support.promotion_allowed.get(tid,(frozenset(),frozenset()));row.extend(len(mask)/(area*area)for mask in masks)
  forced=c.support.promotion_forced.get(tid,(frozenset(),frozenset()));row.extend(len(mask)/area for mask in forced)
  effects=[e for p in patterns for e in p.effects]
  row.extend((len(patterns),sum(len(p.guards)for p in patterns),sum(len(p.slot_guards)for p in patterns),sum(len(p.square_zone_guards)for p in patterns),sum(len(p.path)for p in patterns),len(effects),sum(e.disposition=='capture_to_hand'for e in effects),sum(e.disposition=='remove_from_game'for e in effects),sum(e.kind=='set_current_type'for e in effects),sum(len(p.postconditions)for p in patterns),sum(len(p.invariants)for p in patterns),len(opp['excluded'])/max(1,len(patterns)),sum(s.value_kind=='bool'for s in c.ir.aux_slots),sum(s.value_kind=='square_or_none'for s in c.ir.aux_slots),sum(s.lifetime=='expire_next_turn'for s in c.ir.aux_slots),min(c.repetition_limit,1000)/1000,min(c.max_ply,1000)/1000))
  assert len(row)==len(AXES);vectors[tid]=np.asarray(row,dtype=np.float64);scopes[tid]=dict(included=opp['included'],excluded=opp['excluded'],opportunity_signature=opp['signature'])
 return vectors,scopes

def encode(position,vectors):
 board=np.zeros(len(AXES));hand=np.zeros(len(AXES))
 for piece in position.board:
  if piece:board+=(1 if piece.owner==0 else-1)*vectors[piece.current_type_id]
 for owner,h in enumerate(position.hands):
  for tid,count in h.counts:hand+=(1 if owner==0 else-1)*count*vectors[tid]
 return np.concatenate((board,hand))
