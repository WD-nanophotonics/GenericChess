"""Fixed full-denominator shared-rule rank callers and matched Unit search.
All24 frozen roots, including zero material-regret roots; no refit or resampling.
Root-only Unit/v2/v3/shared-rule rank, three balanced repeats. Matched Unit
CoreD3/20knodes/q0 at median actual learned root cost and fixed1second.
Pure rank never becomes numerical search leaf; all legal child states preserved.
"""
from pathlib import Path
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import sys,json,time,statistics
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
from rule_counts import encode
p=Path(__file__).parent;assert not(p/'rule-callers.json').exists();plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());model=json.loads((p/'rule-model.json').read_bytes());compiled=[];rows=[];curves=[];setup=[]
for row in plan['rule_descriptors']:
 c=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));vv={tid:np.asarray(value)for tid,value in row['vectors'].items()};tick=time.perf_counter();v2=build_ruleset_profile(c._legacy_compiled,EvaluationConfig());v2sec=time.perf_counter()-tick;tick=time.perf_counter();v3,scope=build_semantic_opportunity_profile(c,EvaluationConfig());v3sec=time.perf_counter()-tick
 unit={tid:0 if meta.is_anchor else 1000 for tid,meta in c.support.type_metadata.items()};profiles={'unit':(unit,unit),'v2':(v2.board_value_by_type,v2.hand_value_by_base_type),'v3':(v3.board_value_by_type,v3.hand_value_by_base_type)};compiled.append((c,vv,profiles));setup.append(dict(seed=row['seed'],v2_seconds=v2sec,v3_seconds=v3sec,v3_scope=scope))
write_record(p/'rule-caller-declaration.json',dict(scope=__doc__,setup=setup,normalization='frozen train-only model fields',exposure='Independent cost/whole-denominator diagnostic after fixed screen/fit; no changed fit outcome or holdout restoration.',limits='Finite Unit teacher, exposed rules, retained incomplete references, not WDL/Elo. Timing includes actual public legal/transition calls and scoring, setup separate.'))
for i,root in enumerate(plan['roots']):
 c,vv,profiles=compiled[root['rule_index']];s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 ref=screen['roots'][i];assert (root['seed'],root['ply'])==(ref['seed'],ref['ply']);ss=1 if root['side']==0 else-1
 if not root['children']:
  rows.append(dict(seed=root['seed'],ply=root['ply'],rule_index=root['rule_index'],group=root['group'],status='NO_LEGAL_ROOT'));continue
 best=max(ss*x['owner0_target']for x in ref['children'])if ref['known']else None
 for rep in range(3):
  methods=('unit','v2','v3','rule_rank');shift=(i+rep)%4
  for name in methods[shift:]+methods[:shift]:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
   tick=time.perf_counter();acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True));assert [action_to_dict(a)for a in acts]==root['children'];children=[apply_action(s.state,a,c)for a in acts];score_tick=time.perf_counter()
   if name=='rule_rank':
    x=np.asarray([encode(child.position,vv)for child in children]);scores=((x[:,model['columns']]-model['mean'])/model['scale'])@model['weights']
   else:
    board,hand=profiles[name];scores=np.asarray([sum((1 if v.owner==0 else-1)*board[v.current_type_id]for v in child.position.board if v)+sum((1 if o==0 else-1)*count*hand[t]for o,h in enumerate(child.position.hands)for t,count in h.counts)for child in children])
   score_seconds=time.perf_counter()-score_tick;chosen=np.flatnonzero(ss*scores==np.max(ss*scores));elapsed=time.perf_counter()-tick
   regret=None if best is None else float(np.mean([best-ss*ref['children'][j]['owner0_target']for j in chosen]));rows.append(dict(seed=root['seed'],ply=root['ply'],rule_index=root['rule_index'],group=root['group'],method=name,rep=rep,seconds=elapsed,score_seconds=score_seconds,chosen_children=chosen.tolist(),teacher_regret=regret,selected=ref['selected']))
 cost=statistics.median(a['seconds']for a in rows if a.get('method')=='rule_rank'and(a['seed'],a['ply'])==(root['seed'],root['ply']));types=non_anchor_type_ids(c)
 class Unit:
  def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
  def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
 for name,seconds in (('rank_matched',cost),('one_second',1.)):
  player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;tick=time.perf_counter();decision=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,decision);assert before==s.state
  chosen=next(j for j,a in enumerate(root['children'])if a==action_to_dict(decision.action));curves.append(dict(seed=root['seed'],ply=root['ply'],rule_index=root['rule_index'],group=root['group'],kind=name,limit_seconds=seconds,seconds=elapsed,teacher_regret=None if best is None else best-ss*ref['children'][chosen]['owner0_target'],selected=ref['selected'],decision=record_value(decision)))
 write_record(p/'rule-callers.json',dict(scope=__doc__,complete=False,rank_rows=rows,search_rows=curves));print(root['seed'],root['ply'],'matched limit',cost,flush=True)
write_record(p/'rule-callers.json',dict(scope=__doc__,complete=True,rank_rows=rows,search_rows=curves,limits='Root-only ties averaged; search selects one supported action. Rank-matched timing is observed local median not universal fairness guarantee. All zeros/unknowns retained; no numeric learned leaves.'))
