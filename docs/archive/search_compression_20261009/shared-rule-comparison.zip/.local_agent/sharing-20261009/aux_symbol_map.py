"""Mechanical auxiliary-symbol/action-label rename on the existing Western fixture.
Reverse five slot-name identities and rename action debug names, no rule change.
Replay seven fixed legal plies through double steps and castling; compare full
legal actions and Position channels under typed compile-time slot permutation.
No training, changed prices, unsafe fingerprint reuse or generic transfer claim.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.schema import ruleset_to_dict,ruleset_from_dict
from generic_chess.rules.compiler import compile_semantic_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'aux-symbol-map.json';assert not out.exists()
rule=build_western_chess_ruleset();raw=ruleset_to_dict(rule)
names=sorted({slot.name for a in rule.semantic_actions for slot in a.aux_state})
mapping={name:f'SLOT_{len(names)-i:02d}'for i,name in enumerate(names)}
def rename(x):
 if isinstance(x,dict):return {k:rename(v)for k,v in x.items()}
 if isinstance(x,list):return [rename(v)for v in x]
 return mapping.get(x,x)if isinstance(x,str)else x
nr=rename(raw)
for i,a in enumerate(nr['semantic_actions']):a['name']=f'LABEL_{len(nr["semantic_actions"])-i:02d}'
c=compile_semantic_ruleset(rule);nc=compile_semantic_ruleset(ruleset_from_dict(nr));e=SparsePositionEncoder(c);ne=SparsePositionEncoder(nc)
slotmap={i:sorted(mapping.values()).index(mapping[name])for i,name in enumerate(names)}
assert set(slotmap.values())==set(range(5))
actionmap={a.pattern_id:b.pattern_id for a,b in zip(c.ir.patterns,nc.ir.patterns)}
assert len(c.ir.patterns)==len(nc.ir.patterns) and e.dimension==ne.dimension
def action_map(a):
 d=action_to_dict(a)
 if 'pattern_id'in d:d['pattern_id']=actionmap[d['pattern_id']]
 return d
perm=np.arange(e.dimension)
for offset,(sid,owner),kind,initial in e.aux_slots:
 noff,nkey,nkind,ninitial=next(x for x in ne.aux_slots if x[1]==(slotmap[sid],owner))
 assert kind==nkind and initial==ninitial
 size=1 if kind=='bool'else 3;perm[offset:offset+size]=np.arange(noff,noff+size)
route=[((4,1),(4,3)),((4,6),(4,4)),((6,0),(5,2)),((1,7),(2,5)),((5,0),(2,3)),((6,7),(5,5)),((4,0),(6,0))]
write_record(p/'aux-symbol-declaration.json',dict(scope=__doc__,original_rules=raw,renamed_rules=nr,slot_map=slotmap,route=route,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
s=GameSession(c);ns=GameSession(nc);rows=[];guards=0
for ply in range(8):
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 x=e.dense(s.state.position);nx=ne.dense(ns.state.position);assert np.array_equal(x,nx[perm])
 assert s.state.position.board==ns.state.position.board and s.state.position.hands==ns.state.position.hands
 expected=tuple(sorted((((slotmap[k[0]],k[1]),v)for k,v in s.state.position.aux_state)))
 assert expected==ns.state.position.aux_state
 old=sorted(json.dumps(action_map(a),sort_keys=True)for a in s.legal_actions());new=sorted(json.dumps(action_to_dict(a),sort_keys=True)for a in ns.legal_actions());assert old==new
 try:e.dense(ns.state.position)
 except ValueError:guards+=1
 else:raise AssertionError('foreign rule bypassed')
 rows.append(dict(ply=ply,legal_count=len(old),raw_equal=bool(np.array_equal(x,nx)),remapped_equal=True,aux_old=record_value(s.state.position.aux_state),aux_new=record_value(ns.state.position.aux_state),terminal=record_value(s.state.terminal_status)))
 if ply<7:
  fr,to=route[ply];a=next(a for a in s.legal_actions()if tuple(action_to_dict(a).get('from',()))==fr and tuple(action_to_dict(a).get('to',()))==to)
  s.submit(a);ns.submit(action_from_dict(action_map(a)))
assert any(not r['raw_equal']for r in rows)
write_record(out,dict(scope=__doc__,slot_map=slotmap,action_map=actionmap,rows=rows,foreign_layout_rejections=guards,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limits='Pure name equivalence only, unchanged action declaration order. History keys correctly remain fingerprint-bound; no scalar descriptor sufficiency, unseen-rule transfer or new predictor.'))
print(json.dumps(dict(slots=slotmap,rows=[(r['ply'],r['legal_count'],r['raw_equal'],r['remapped_equal'])for r in rows],guards=guards)))
