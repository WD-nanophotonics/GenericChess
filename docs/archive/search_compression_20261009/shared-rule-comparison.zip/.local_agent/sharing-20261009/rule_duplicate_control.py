"""Development redundancy probe for raw syntactic descriptor counts.
Duplicate one guarded Pdrop with identical guards/effects as an augment action.
Compare projected full physical successor sets along an existing16ply trajectory;
extra public action identity is retained and reported, not hidden in product.
This finite evidence tests representation sensitivity, not universal equivalence.
"""
from pathlib import Path
import sys,json,copy,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record,record_value
from rule_counts import descriptors,encode,AXES
p=Path(__file__).parent;assert not(p/'rule-duplicate-control.json').exists();decl=json.loads((p/'rule-declaration.json').read_bytes());raw=decl['rule_descriptors'][0]['rules'];changed=copy.deepcopy(raw);extra=copy.deepcopy(changed['semantic_actions'][0]);extra['name']='redundant_identical_guarded_drop';extra['composition']='augment';extra['replace_selector']=None;changed['semantic_actions'].append(extra)
c=compile_ruleset_for_execution(ruleset_from_dict(raw));nc=compile_ruleset_for_execution(ruleset_from_dict(changed));v,_=descriptors(c);nv,_=descriptors(nc);s=GameSession(c);ns=GameSession(nc);root=next(r for r in decl['roots']if r['rule_index']==0 and r['ply']==16);rows=[]
def physical(state):
 pos=state.position
 return json.dumps(record_value(dict(board=pos.board,hands=pos.hands,aux=pos.aux_state,side=pos.side_to_move,ply=state.ply_count,terminal=state.terminal_status)),sort_keys=True)
for ply in range(17):
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert physical(s.state)==physical(ns.state)
 aa=s.legal_actions();bb=ns.legal_actions();aset={physical(apply_action(s.state,a,c))for a in aa};bset={physical(apply_action(ns.state,a,nc))for a in bb};assert aset==bset
 rows.append(dict(ply=ply,legal_old=len(aa),legal_new=len(bb),unique_successors=len(aset),physical_successors_equal=True,input_difference=(encode(ns.state.position,nv)-encode(s.state.position,v)).tolist()))
 if ply<16:s.submit(action_from_dict(root['route'][ply]));ns.submit(action_from_dict(root['route'][ply]))
diff={tid:{AXES[j]:float(nv[tid][j]-v[tid][j])for j in np.flatnonzero(nv[tid]!=v[tid])}for tid in v if not np.array_equal(v[tid],nv[tid])}
write_record(p/'rule-duplicate-control.json',dict(scope=__doc__,original_rules=raw,changed_rules=changed,route=root['route'],descriptor_changes=diff,rows=rows,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limits='Same projected full physical successor sets at17observed states; action identities/counts differ, no complete rule-equivalence proof. Descriptor raw pattern/effect counts are representation-sensitive. No relabelled production state, model refit or data replacement.'))
print(json.dumps(dict(changes=diff,states=len(rows),extra_actions=sum(r['legal_new']-r['legal_old']for r in rows),different_inputs=sum(any(r['input_difference'])for r in rows)),indent=2))
