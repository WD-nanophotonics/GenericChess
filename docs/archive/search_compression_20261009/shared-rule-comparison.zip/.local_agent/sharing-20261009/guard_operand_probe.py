"""Concrete shared-descriptor blind spot: Pdrop capacity3 versus impossible0.
Same full generated rule, one typed count guard value changes. Replay a common
legal prefix only; stop before any action invalid under the changed rule.
No board transplantation, train/teacher labels, model selection or default change.
"""
from pathlib import Path
import sys,json,copy
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict,action_from_dict
from scripts.research_record import write_record
from rule_counts import descriptors,AXES
p=Path(__file__).parent;assert not(p/'guard-operand-probe.json').exists();plan=json.loads((p/'rule-declaration.json').read_bytes());raw=plan['rule_descriptors'][0]['rules'];changed=copy.deepcopy(raw);guard=changed['semantic_actions'][0]['state_guards'][0];assert guard['aggregation']=='count'and guard['comparison']=='lt'and guard['value']==3;guard['value']=0
c=compile_ruleset_for_execution(ruleset_from_dict(raw));nc=compile_ruleset_for_execution(ruleset_from_dict(changed));v,_=descriptors(c);nv,_=descriptors(nc);assert all(np.array_equal(v[t],nv[t])for t in v)
root=next(r for r in plan['roots']if r['rule_index']==0 and r['ply']==16);s=GameSession(c);ns=GameSession(nc);rows=[];stopped_before=None
for ply in range(17):
 assert s.state.position.board==ns.state.position.board and s.state.position.hands==ns.state.position.hands and s.state.position.aux_state==ns.state.position.aux_state
 old={json.dumps(action_to_dict(a),sort_keys=True)for a in s.legal_actions()};new={json.dumps(action_to_dict(a),sort_keys=True)for a in ns.legal_actions()};assert new<=old
 removed=[json.loads(a)for a in sorted(old-new)];assert all(a['kind']=='semantic_drop'and a['base_type_id']=='P'for a in removed)
 rows.append(dict(ply=ply,legal_old=len(old),legal_new=len(new),removed=removed))
 if ply<16:
  a=root['route'][ply]
  if json.dumps(a,sort_keys=True)not in new:stopped_before=ply;break
  s.submit(action_from_dict(a));ns.submit(action_from_dict(a))
assert any(r['removed']for r in rows)
write_record(p/'guard-operand-probe.json',dict(scope=__doc__,axes=AXES,original_rules=raw,changed_rules=changed,descriptor_equal=True,rows=rows,stopped_before=stopped_before,limits='A disabled guarded drop has the same descriptor as usable stock because the predicate operand is absent. Existing full executor correctly distinguishes them. Behavior-only filtering of syntactic counts fixes tested redundancy but does not repair this missing rule information. Not a complete value/utility proof.'))
print(json.dumps(dict(states=len(rows),removed_drop_options=sum(len(r['removed'])for r in rows),stopped_before=stopped_before,descriptor_equal=True)))
