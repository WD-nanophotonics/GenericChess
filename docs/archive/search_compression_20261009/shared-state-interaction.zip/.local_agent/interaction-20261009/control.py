"""Post-result semantic/cost check, no fit or prediction-quality claim."""
from pathlib import Path
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'control.json';assert not out.exists()
old=Path('.local_agent/sharing-20261009');plan=json.loads((old/'rule-declaration.json').read_bytes());alias=json.loads((old/'rule-aliases.json').read_bytes())['witness']
root=next(r for r in plan['roots']if f"{r['seed']}/{r['ply']}"==alias['root'])
raw=plan['rule_descriptors'][root['rule_index']]['rules'];c=compile_ruleset_for_execution(ruleset_from_dict(raw));tick=time.perf_counter();encoder=InteractionProjection(c);prepare=time.perf_counter()-tick
s=GameSession(c)
for a in root['route']:s.submit(action_from_dict(a))
children=[]
for index in alias['indices']:
 child=GameSession(c);child._state=s.state;child._search_history_witnesses=s._search_history_witnesses;child.submit(action_from_dict(root['children'][index]));children.append(child)
vectors=[encoder.encode(x.state.position)for x in children];assert not np.array_equal(*vectors)
rows=[]
for label,call in [('projection',encoder.encode),('full_Position_carrier',encoder.carrier.encode)]:
 for rep in range(3):
  tick=time.perf_counter()
  for _ in range(1000):
   for child in children:call(child.state.position)
  rows.append(dict(label=label,rep=rep,seconds=time.perf_counter()-tick,calls=2000))
dup=json.loads((old/'rule-duplicate-control.json').read_bytes())['changed_rules'];dupc=compile_ruleset_for_execution(ruleset_from_dict(dup));dupe=InteractionProjection(dupc)
assert all(np.array_equal(encoder.actors[t],dupe.actors[t])for t in encoder.actors)
probe=json.loads(Path('.local_agent/effect-target-20261009.json').read_bytes());te=InteractionProjection(compile_ruleset_for_execution(ruleset_from_dict(probe['changed_rules'])))
changed=[t for t in encoder.actors if not np.array_equal(encoder.actors[t],te.actors[t])];assert changed==['X']
write_record(out,dict(scope=__doc__,dimension=encoder.dimension,prepare_seconds=prepare,table_bytes=sum(a.nbytes for a in encoder.board.values()),alias_root=alias['root'],indices=alias['indices'],changed_axes=np.flatnonzero(vectors[0]!=vectors[1]).tolist(),cost=rows,duplicate_actor_equal=True,changed_target=changed,limits='Separates two exposed positions, no learned mate knowledge. Exact guard operands, aux and history omitted from projection; full carriers retained separately. No fit/default change.'))
print(dict(dimension=encoder.dimension,prepare_seconds=prepare,changed_axes=int(np.count_nonzero(vectors[0]!=vectors[1])),cost=rows))
