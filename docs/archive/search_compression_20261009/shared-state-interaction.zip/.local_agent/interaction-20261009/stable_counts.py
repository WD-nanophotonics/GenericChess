"""Exposed arithmetic diagnostic only: integer inventory then stable summation.
No refit; original evaluation/fit records remain authoritative frozen results.
"""
from pathlib import Path
import sys,json,math,collections,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'stable-counts.json';assert not out.exists();plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());tables=json.loads((p/'count-tables.json').read_bytes())['records'];rows=[]
for root,ref in zip(plan['roots'],screen['roots']):
 c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));table=tables[root['rule_index']];s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 states=[apply_action(s.state,action_from_dict(a),c).position for a in root['children']]
 def score(pos):
  current=collections.Counter((v.owner,v.current_type_id)for v in pos.board if v);base=collections.Counter((v.owner,v.base_type_id)for v in pos.board if v);promoted=collections.Counter(v.owner for v in pos.board if v and v.promoted)
  terms=[table['offset'],table['side'][pos.side_to_move]]
  for counter,field in [(current,'current'),(base,'base')]:
   terms.extend((1 if o==0 else-1)*count*table['tables'][t][field]for(o,t),count in counter.items())
  terms.extend(promoted[o]*table['promoted'][o]for o in(0,1))
  terms.extend(count*table['tables'][t]['hands'][o]for o,h in enumerate(pos.hands)for t,count in h.counts)
  value=math.fsum(terms);assert value==math.fsum(reversed(terms));return value
 tick=time.perf_counter();values=np.asarray([score(pos)for pos in states]);elapsed=time.perf_counter()-tick;ss=1 if root['side']==0 else-1;chosen=np.flatnonzero(ss*values==np.max(ss*values)).tolist()if len(values)else[];best=max(ss*z['owner0_target']for z in ref['children'])if ref['known']else None;regret=None if best is None else float(np.mean([best-ss*ref['children'][i]['owner0_target']for i in chosen]));original=next(x for x in table['choices']if x['root']==f"{root['seed']}/{root['ply']}")
  # No label-dependent tolerance or tie choice is introduced.
 rows.append(dict(root=original['root'],group=root['group'],known=ref['known'],selected=ref['selected'],chosen=chosen,regret=regret,original_affine_chosen=original['direct'],affine_equal=chosen==original['direct'],states=len(states),score_seconds=elapsed))
write_record(out,dict(scope=__doc__,rows=rows,limits='Post-result diagnostic, not new report performance or numerical leaf deployment. Determinism is inventory/term-order scope, not complete semantic equivalence. Table coefficient dot products still rounded. Full carrier/anchor/aux/history omissions remain.'))
print([(r['root'],r['regret'],r['affine_equal'])for r in rows if r['selected']or not r['affine_equal']])
