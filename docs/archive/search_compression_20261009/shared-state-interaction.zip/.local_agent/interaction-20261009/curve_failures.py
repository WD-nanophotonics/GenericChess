"""Explain resource curve disagreements from frozen actions/PVs, no search rerun."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'curve-failures.json';assert not out.exists();curve=json.loads((p/'search-curve.json').read_bytes());plan=json.loads(Path('.local_agent/sharing-20261009/rule-declaration.json').read_bytes());screen=json.loads(Path('.local_agent/sharing-20261009/rule-screen.json').read_bytes());rows=[]
from generic_chess.core.actions import action_from_dict
for i,root in enumerate(plan['roots']):
 rid=f"{root['seed']}/{root['ply']}";ref=screen['roots'][i]
 for rep in(0,1):
  pair=[next(r for r in curve['rows']if r['root']==rid and r['rep']==rep and r['node_budget']==512 and r['reuse']==reuse)for reuse in(False,True)]
  if any(r['regret']is None for r in pair)or pair[0]['regret']==pair[1]['regret']:continue
  c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));s=GameSession(c)
  for a in root['route']:s.submit(action_from_dict(a))
  outcomes=[]
  for r in pair:
   branch=GameSession(c);branch._state=s.state;branch._search_history_witnesses=s._search_history_witnesses;states=[]
   for raw in r['decision']['principal_variation']:
    a=next(a for a in branch.legal_actions()if record_value(a)==raw);branch.submit(a);states.append(record_value(branch.state))
   chosen=next(cell for cell in ref['children']if record_value(action_from_dict(cell['action']))==r['decision']['action'])
   outcomes.append(dict(reuse=r['reuse'],completed_depth=r['decision']['completed_depth'],score=r['decision']['score'],regret=r['regret'],child_D2_owner0_target=chosen['owner0_target'],pv_states=states))
  higher=[dict(budget=r['node_budget'],reuse=r['reuse'],depth=r['decision']['completed_depth'],regret=r['regret'],score=r['decision']['score'])for r in curve['rows']if r['root']==rid and r['rep']==rep and r['node_budget']in(2048,8192)]
  rows.append(dict(root=rid,rep=rep,low_budget=outcomes,higher_budget=higher))
write_record(out,dict(scope=__doc__,rows=rows,limits='Reference is childD2/rootD3 finite Unit, not game utility. Low-budget completed-depth/PV differences diagnose horizon and tie effects; TT/order combined, no causal separation or default promotion. Public legal replay exact, no old search reruns.'))
print([(r['root'],r['rep'],[(v['reuse'],v['completed_depth'],v['regret'])for v in r['low_budget']])for r in rows])
