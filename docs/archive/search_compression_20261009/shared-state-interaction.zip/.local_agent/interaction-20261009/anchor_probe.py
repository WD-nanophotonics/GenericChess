"""Exposed semantic projection diagnostic, frozen fit is not changed."""
from pathlib import Path
import sys,json
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'anchor-probe.json';assert not out.exists()
plan=json.loads(Path('.local_agent/sharing-20261009/rule-declaration.json').read_bytes());witness=None
for root in plan['roots']:
 c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));e=InteractionProjection(c);s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 children=[]
 for a in s.legal_actions():
  branch=GameSession(c);branch._state=s.state;branch._search_history_witnesses=s._search_history_witnesses;branch.submit(a)
  if branch.state.terminal_status.is_terminal:continue
  changed=[(old,new)for old,new in zip(s.state.position.board,branch.state.position.board)if old!=new]
  if len(changed)!=2:continue
  if not all(piece is None or c.support.type_metadata[piece.current_type_id].is_anchor for pair in changed for piece in pair):continue
  children.append((a,branch,e.encode(branch.state.position)))
 for i,(a,one,vec)in enumerate(children):
  for b,two,other in children[i+1:]:
   if np.array_equal(vec,other) and one.state.position.board!=two.state.position.board:
    witness=dict(root=f"{root['seed']}/{root['ply']}",rule_index=root['rule_index'],actions=[action_to_dict(a),action_to_dict(b)],positions=[record_value(one.state.position),record_value(two.state.position)],projection_equal=True,full_carrier_equal=np.array_equal(e.carrier.dense(one.state.position),e.carrier.dense(two.state.position)))
    break
  if witness:break
 if witness:break
assert witness and not witness['full_carrier_equal']
write_record(out,dict(scope=__doc__,witness=witness,limits='Anchor descriptor zero inherits piece-value convention, inappropriate for complete state representation. This diagnostic does not modify the already-frozen938 fit or reuse report labels. Full GameSession/Position still distinguish, no claim target values differ. Next untrained repair needs explicit anchor channels.'))
print(dict(root=witness['root'],projection_equal=True,full_carrier_equal=False))
