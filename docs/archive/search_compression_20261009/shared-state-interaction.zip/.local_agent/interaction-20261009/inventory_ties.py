"""Audit exact inventory classes after result; no refit or favorable filtering.
Original fit/caller outputs remain frozen. This measures whether alleged
count-only choice gains depend on floating reassociation within identical counts.
"""
from pathlib import Path
import sys,json,collections
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'inventory-ties.json';assert not out.exists();plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());m=json.loads((p/'count-model.json').read_bytes());tables=json.loads((p/'count-tables.json').read_bytes());rows=[]
with np.load(p/'rule-screen-inputs.npz',allow_pickle=False)as data:
 for root,ref in zip(plan['roots'],screen['roots']):
  c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));types=tuple(sorted(c.support.type_metadata));s=GameSession(c)
  for a in root['route']:s.submit(action_from_dict(a))
  classes=collections.defaultdict(list)
  for i,a in enumerate(root['children']):
   pos=apply_action(s.state,action_from_dict(a),c).position
   current=collections.Counter((v.owner,v.current_type_id)for v in pos.board if v);base=collections.Counter((v.owner,v.base_type_id)for v in pos.board if v);promoted=collections.Counter(v.owner for v in pos.board if v and v.promoted)
   key=tuple(current[o,t]for o in(0,1)for t in types)+tuple(base[o,t]for o in(0,1)for t in types)+tuple(pos.hands[o].count(t)for o in(0,1)for t in types)+(promoted[0],promoted[1],pos.side_to_move);classes[key].append(i)
  rid=f"{root['seed']}/{root['ply']}";mask=data['root_ids']==rid;x=data['features'][mask];indices=data['child_indices'][mask];pred=((x[:,m['columns']]-m['mean'])/m['scale'])@m['weights'];lookup=dict(zip(indices.tolist(),pred.tolist()));groups=[]
  for members in classes.values():
   known=[i for i in members if i in lookup]
   if len(known)<2:continue
   v=np.asarray([lookup[i]for i in known]);targets=[ref['children'][i]['owner0_target']for i in known];groups.append(dict(children=known,score_spread=float(np.ptp(v)),teacher_spread=max(targets)-min(targets)))
  row=dict(root=rid,group=root['group'],known=ref['known'],selected=ref['selected'],inventory_classes=len(classes),multi_classes=groups)
  if ref['known']:
   ss=1 if root['side']==0 else-1;vv=np.asarray([lookup[i]for i in range(len(root['children']))]);best=ss*vv==np.max(ss*vv);selected=np.flatnonzero(best).tolist();members=sorted({j for group in classes.values()if any(i in selected for i in group)for j in group});tt=np.asarray([ss*z['owner0_target']for z in ref['children']]);row.update(original_chosen=selected,original_regret=float(np.mean(tt.max()-tt[best])),same_inventory_closure=members,inventory_closure_regret=float(np.mean(tt.max()-tt[members])))
  rows.append(row)
write_record(out,dict(scope=__doc__,rows=rows,limits='Inventory closure is a post-result diagnostic of count-class ties, not a replacement fit or deployed tie policy. Classes still omit auxiliary/history and spatial state. Original model/default/results unchanged; report labels only quantify already-exposed arithmetic sensitivity.'))
print([(r['root'],r.get('original_regret'),r.get('inventory_closure_regret'))for r in rows if r['selected']])
