"""Post-result train-range diagnostic, no candidate selection or refit."""
from pathlib import Path
import sys,json
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'input-range.json';assert not out.exists();m=json.loads((p/'anchored_relu-model.json').read_bytes());result=json.loads((p/'fit-result.json').read_bytes())['results']['anchored_relu'];selected={r['root']for r in result['rows']};rows=[]
with np.load(p/'rule-screen-inputs.npz',allow_pickle=False)as d:
 keep=np.asarray([s in selected for s in d['root_ids']]);x=d['features'][keep][:,m['columns']];roots=d['root_ids'][keep];groups=d['groups'][keep];indices=d['child_indices'][keep];train=groups=='train';low=x[train].min(0);high=x[train].max(0);span=high-low;assert np.all(span>0)
 for row in result['rows']:
  if row['group']=='train':continue
  mask=roots==row['root'];xx=x[mask];outside=(xx<low)|(xx>high);distance=np.maximum(np.maximum((low-xx)/span,(xx-high)/span),0);chosen=np.isin(indices[mask],row['chosen']);rows.append(dict(root=row['root'],group=row['group'],regret=row['regret'],children=len(xx),variable_axes=len(low),outside_axes_max=int(outside.sum(1).max()),outside_span_max=float(distance.max()),chosen_outside_axes=outside.sum(1)[chosen].tolist(),chosen_outside_span=distance.max(1)[chosen].tolist()))
write_record(out,dict(scope=__doc__,rows=rows,limits='Range departure is descriptive, neither causal failure explanation nor proof that more samples help. No clipping, tuned features, report refit or restored holdout qualification.'))
print(rows)
