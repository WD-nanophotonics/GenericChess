"""Actual full root scorers and matching Unit resource, frozen fits unchanged."""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,statistics
import numpy as np
sys.path.insert(0,str(Path.cwd()))
sys.path.insert(0,str(Path('.local_agent/interaction-20261009')))
from anchor_repair import AnchoredProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'callers.json';assert not out.exists();plan=json.loads((p/'rule-declaration.json').read_bytes());screen=json.loads((p/'rule-screen.json').read_bytes());fits=json.loads((p/'fit-result.json').read_bytes());assert fits.get('results')
models={};setup=[];compiled=[]
for name in ('count','anchored_linear','anchored_relu'):
 m=json.loads((p/(name+'-model.json')).read_bytes());m['columns']=np.asarray(m['columns']);m['mean']=np.asarray(m['mean']);m['scale']=np.asarray(m['scale'])
 for field in ('weights','w1','b1','w2'):
  if field in m:m[field]=np.asarray(m[field])
 models[name]=m
for row in plan['rule_descriptors']:
 c=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));tick=time.perf_counter();e=AnchoredProjection(c);setup.append(dict(seed=row['seed'],seconds=time.perf_counter()-tick,table_bytes=sum(v.nbytes for v in e.projection.board.values())));compiled.append((c,e))
write_record(p/'caller-declaration.json',dict(scope=__doc__,setup=setup,methods=['unit','count','anchored_linear','anchored_relu'],repeats=3,matched='UnitCoreD3/20knodes/q0 at median anchored ReLU actual root time and1sec',limits='Same full legality/transitions; model setup separate; pure rank no leaf. Root-only callers do not override direct terminals; terminal authority retained in reference/Core. Local time-matched cost, not universal fairness.'))
rows=[];search=[]
for i,root in enumerate(plan['roots']):
 c,e=compiled[root['rule_index']];types=non_anchor_type_ids(c);s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 ref=screen['roots'][i];ss=1 if root['side']==0 else-1;best=max(ss*x['owner0_target']for x in ref['children'])if ref['known']else None
 if not root['children']:
  rows.append(dict(root=f"{root['seed']}/{root['ply']}",status='NO_LEGAL_ROOT'));continue
 for rep in range(3):
  methods=('unit','count','anchored_linear','anchored_relu');shift=(i+rep)%4
  for name in methods[shift:]+methods[:shift]:
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
   tick=time.perf_counter();acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True));assert [action_to_dict(a)for a in acts]==root['children'];children=[apply_action(s.state,a,c)for a in acts];score_tick=time.perf_counter()
   if name=='unit':scores=np.asarray([1000*sum(material_features(ch.position,types,perspective=0).array())for ch in children])
   else:
    m=models[name];xx=np.asarray([e.encode(ch.position)for ch in children]);z=(xx[:,m['columns']]-m['mean'])/m['scale'];scores=np.maximum(z@m['w1']+m['b1'],0)@m['w2']if name=='anchored_relu'else z@m['weights']
   scoring=time.perf_counter()-score_tick;chosen=np.flatnonzero(ss*scores==np.max(ss*scores));elapsed=time.perf_counter()-tick;regret=None if best is None else float(np.mean([best-ss*ref['children'][j]['owner0_target']for j in chosen]));rows.append(dict(root=f"{root['seed']}/{root['ply']}",group=root['group'],method=name,rep=rep,seconds=elapsed,score_seconds=scoring,chosen=chosen.tolist(),regret=regret,selected=ref['selected']))
 cost=statistics.median(r['seconds']for r in rows if r.get('method')=='anchored_relu'and r['root']==f"{root['seed']}/{root['ply']}")
 class Unit:
  def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
  def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
 for name,seconds in [('matched',cost),('one_second',1.)]:
  player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=20000,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);assert s.state==before;index=next(j for j,a in enumerate(root['children'])if a==action_to_dict(d.action));search.append(dict(root=f"{root['seed']}/{root['ply']}",group=root['group'],method=name,seconds=elapsed,limit=seconds,regret=None if best is None else best-ss*ref['children'][index]['owner0_target'],decision=record_value(d)))
 write_record(out,dict(scope=__doc__,complete=False,rank_rows=rows,search_rows=search));print(i,root['seed'],root['ply'],cost,flush=True)
write_record(out,dict(scope=__doc__,complete=True,rank_rows=rows,search_rows=search,limits='All zero/capped denominator roots retained; exposed finite Unit target, not WDL/Elo. No model selection or numeric leaf deployment. Affine conversion can change roundoff tie membership; fit and actual caller metrics recorded separately.'))
