"""Prospective anchor/nonlinear comparison:16fresh whole trajectories1400..1415.
All original four complete generated rules, roots7/16, whole-rule groups unchanged.
Count linear vs anchored linear vs same anchored input width16 ReLU. Three fixed
300step margin1 root-balanced fits, same train-only normalization and regularizer.
Question: can an actual small joint-state evaluator earn benefit over the cheap
count baseline, after retaining observed anchor state? Linear vs ReLU isolates
architecture on identical input. No old report fitting, tuning or model selection.
UnitD2/2048node/1sec/q0 references;1500sec batch checkpoint, all caps and zero roots
remain. Single run estimated15-25min, no>1hour job. Aux/history/precise guard scope
omitted from shared projection but full Position/GameSession teacher preserved.
"""
from pathlib import Path
import os
for k in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,random,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import terminal_score
from generic_chess.ai.limits import SearchLimits
from scripts.position_features import SparsePositionEncoder
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;old=Path('.local_agent/eval-features-20261009');out=p/'rule-screen.json';declpath=p/'rule-declaration.json';assert not out.exists()and not declpath.exists()
sys.path.insert(0,str(Path('.local_agent/interaction-20261009')))
from anchor_repair import AnchoredProjection
from rule_counts import descriptors,AXES
rule_rows=json.loads(Path('.local_agent/generated8-20261008/transfer.json').read_bytes())['cases'];compiled=[];descriptor_rows=[]
for row in rule_rows:
 cc=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));vv,ss=descriptors(cc);compiled.append((cc,AnchoredProjection(cc)));descriptor_rows.append(dict(seed=row['seed'],rules=row['rules'],axes=AXES,vectors={tid:value.tolist() for tid,value in vv.items()},scopes=ss))
roots=[];sessions=[]
for i,seed in enumerate(range(2026101400,2026101416)):
 ri=i//4;c,vectors=compiled[ri];s=GameSession(c);rng=random.Random(seed);route=[]
 for ply in range(17):
  if ply in(7,16):
   acts=[]if s.state.terminal_status.is_terminal else sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True))
   roots.append(dict(rule_index=ri,seed=seed,ply=ply,group='train'if i<8 else'dev'if i<12 else'report',route=route.copy(),state=record_value(s.state),side=s.state.position.side_to_move,missing=s.state.terminal_status.is_terminal or len(route)!=ply,children=[action_to_dict(a)for a in acts]));sessions.append((s.state,s._search_history_witnesses,ri))
  if ply==16:break
  if s.state.terminal_status.is_terminal:continue
  acts=sorted(s.legal_actions(),key=lambda a:json.dumps(action_to_dict(a),sort_keys=True))
  if not acts:continue
  a=rng.choice(acts);route.append(action_to_dict(a));s.submit(a)
plan=dict(scope=__doc__,rule_descriptors=descriptor_rows,roots=roots,ranking_fit=dict(kind='three frozen rank fits: count linear, anchored linear, anchored width16 ReLU; no model selection',inputs=['268 count-only subset', '1066 anchored moments linear', '1066 anchored moments width16 ReLU rank'],loss='margin1 hinge, teacher-optimal vs strictly lower, each root total weight equal',hidden_width=16,epochs=300,learning_rate=.01,regularization=.0001,seed=2026100949,normalization='train-only mean/std; keep only train-variable columns; no model selection'),cost='32 complete frontiers,<=1500sec cost checkpoint; one fixed small fit; incremental value is conditional-input decision; no>1hour run',limits='Four exposed rules; projection retains on-board current/base/promoted/side; omits auxiliary/history and precise conditional guard/effect references; full states/rules preserved for teacher. Shared axes are approximate, not full rule encoding. No WDL/Elo/unknown-rule claim. No report tuning/resampling.')
write_record(declpath,plan)
class Unit:
 def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
 def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
start=time.perf_counter();report=dict(scope=__doc__,declaration_sha256=hashlib.sha256(declpath.read_bytes()).hexdigest(),roots=[],complete=False);features=[];targets=[];bases=[];ids=[];groups=[];children=[]
for root,(state,witness,ri)in zip(roots,sessions):
 c,vectors=compiled[ri];types=non_anchor_type_ids(c)
 row=dict(rule_index=ri,seed=root['seed'],ply=root['ply'],group=root['group'],side=root['side'],children=[]);report['roots'].append(row)
 for j,a in enumerate(root['children']):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
  child=apply_action(state,action_from_dict(a),c);b=1000*sum(material_features(child.position,types,perspective=0).array());cell=dict(index=j,action=a,baseline=b,known=False)
  if time.perf_counter()-start>=1500:cell['reason']='whole_run_cost_checkpoint'
  elif child.terminal_status.is_terminal:cell.update(known=True,owner0_target=terminal_score(child.terminal_status,0,0),terminal=True,seconds=0)
  else:
   cs=GameSession(c);cs._state=child;cs._search_history_witnesses=witness+(child.position,);player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();d=player.choose_action(cs,SearchLimits(max_depth=2,max_nodes=2048,max_time_seconds=1,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(cs,d);cell.update(known=d.completed_depth==2,owner0_target=d.score if child.position.side_to_move==0 else-d.score,seconds=elapsed,decision=record_value(d))
  row['children'].append(cell)
  if cell['known']:features.append(vectors.encode(child.position));targets.append(cell['owner0_target']);bases.append(b);ids.append(f"{root['seed']}/{root['ply']}");groups.append(root['group']);children.append(j)
 known=len(row['children'])>0 and all(x['known']for x in row['children']);sign=1 if root['side']==0 else-1
 if known:
  bb=np.asarray([x['baseline']for x in row['children']]);t=np.asarray([x['owner0_target']for x in row['children']]);chosen=sign*bb==np.max(sign*bb);regret=float(np.mean(np.max(sign*t)-sign*t[chosen]))
 else:regret=None
 row.update(known=known,material_greedy_regret=regret,selected=known and regret>0)
 write_record(out,report);print(root['seed'],root['ply'],known,len(row['children']),regret,flush=True)
report.update(complete=True,seconds=time.perf_counter()-start);write_record(out,report)
np.savez_compressed(p/'rule-screen-inputs.npz',features=np.asarray(features),targets=np.asarray(targets),baseline=np.asarray(bases),root_ids=np.asarray(ids),groups=np.asarray(groups),child_indices=np.asarray(children))
write_record(p/'rule-selection.json',dict(scope='Teacher/material only selection, committed before any rank candidate is fitted/predicted.',declaration_sha256=report['declaration_sha256'],screen_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),roots=[dict(rule_index=r['rule_index'],seed=r['seed'],ply=r['ply'],group=r['group'],known=r['known'],selected=r['selected'],material_greedy_regret=r['material_greedy_regret'],children=len(r['children']))for r in report['roots']],limits='Conditional screening domain; all unselected/capped denominators retained. No natural-distribution or independence claim.'))
print('complete',report['seconds'],'selected',sum(r['selected']for r in report['roots']))
