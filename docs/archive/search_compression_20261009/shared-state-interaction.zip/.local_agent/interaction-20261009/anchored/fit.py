"""Three prospectively fixed ranks: count, anchored linear, anchored ReLU16."""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'fit-result.json';assert not out.exists();selection=json.loads((p/'rule-selection.json').read_bytes());plan=json.loads((p/'rule-declaration.json').read_bytes());assert selection['screen_sha256']==hashlib.sha256((p/'rule-screen.json').read_bytes()).hexdigest();chosen={f"{r['seed']}/{r['ply']}":r for r in selection['roots']if r['selected']}
with np.load(p/'rule-screen-inputs.npz',allow_pickle=False)as d:
 keep=np.asarray([r in chosen for r in d['root_ids']]);x=d['features'][keep];y=d['targets'][keep];roots=d['root_ids'][keep];groups=d['groups'][keep];ci=d['child_indices'][keep];baseline=d['baseline'][keep]
train=groups=='train';train_roots=list(dict.fromkeys(roots[train]))
if not train_roots:
 write_record(out,dict(status='NO_TRAIN_ROOT_NO_FIT',denominator=selection['roots']));raise SystemExit(0)
sign=np.asarray([1 if next(r for r in plan['roots']if f"{r['seed']}/{r['ply']}"==key)['side']==0 else-1 for key in roots]);count_columns=list(range(66))+list(range(396,462))+list(range(792,924))+[924,930,936,937]
write_record(p/'fit-declaration.json',dict(scope=__doc__,declaration_sha256=selection['declaration_sha256'],input_sha256=hashlib.sha256((p/'rule-screen-inputs.npz').read_bytes()).hexdigest(),fit=plan['ranking_fit'],count_columns=count_columns,candidates=['count','anchored_linear','anchored_relu'],relu_init='normal0/.03 weights, zero hidden bias, seed2026100949; Adam .01, .0001 matrix regularizer;300steps',no_model_selection=True))
results={}
for name,columns in [('count',count_columns),('anchored_linear',range(1066)),('anchored_relu',range(1066))]:
 columns=np.asarray(list(columns));col=columns[np.ptp(x[train][:,columns],axis=0)>0];mean=x[train][:,col].mean(0);scale=x[train][:,col].std(0);z=(x[:,col]-mean)/scale;a=[];b=[];pw=[];sslist=[]
 for key in train_roots:
  idx=np.flatnonzero((roots==key)&train);ss=sign[idx[0]];t=ss*y[idx];best=np.flatnonzero(t==t.max());other=np.flatnonzero(t<t.max());n=len(best)*len(other);assert n>0
  for aa in best:
   for bb in other:a.append(idx[aa]);b.append(idx[bb]);pw.append(1/(len(train_roots)*n));sslist.append(ss)
 a=np.asarray(a);b=np.asarray(b);pw=np.asarray(pw);sslist=np.asarray(sslist);rng=np.random.default_rng(2026100949);tick=time.perf_counter()
 if name!='anchored_relu':
  diff=sslist[:,None]*(z[a]-z[b]);w=rng.normal(0,.001,len(col));mom=np.zeros_like(w);vel=np.zeros_like(w)
  for step in range(1,301):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-tick<120
   grad=-(pw*(1-diff@w>0))@diff+.0001*w;mom=.9*mom+.1*grad;vel=.999*vel+.001*grad*grad;w-=.01*(mom/(1-.9**step))/(np.sqrt(vel/(1-.999**step))+1e-8)
  prediction=z@w;parameters=dict(weights=w.tolist());zero=float(pw[np.all(diff==0,axis=1)].sum())
 else:
  ids=np.flatnonzero(train);local={int(v):i for i,v in enumerate(ids)};la=np.asarray([local[int(i)]for i in a]);lb=np.asarray([local[int(i)]for i in b]);zz=z[train];params=[rng.normal(0,.03,(len(col),16)),np.zeros(16),rng.normal(0,.03,16)];mom=[np.zeros_like(v)for v in params];vel=[np.zeros_like(v)for v in params]
  for step in range(1,301):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-tick<120
   w1,b1,w2=params;hidden=np.maximum(zz@w1+b1,0);scores=hidden@w2;active=1-sslist*(scores[la]-scores[lb])>0;ds=np.zeros(len(zz));np.add.at(ds,la,-pw*sslist*active);np.add.at(ds,lb,pw*sslist*active);dh=ds[:,None]*w2*(hidden>0);grads=[zz.T@dh+.0001*w1,dh.sum(0),hidden.T@ds+.0001*w2]
   for i,grad in enumerate(grads):mom[i]=.9*mom[i]+.1*grad;vel[i]=.999*vel[i]+.001*grad*grad;params[i]-=.01*(mom[i]/(1-.9**step))/(np.sqrt(vel[i]/(1-.999**step))+1e-8)
  w1,b1,w2=params;prediction=np.maximum(z@w1+b1,0)@w2;parameters=dict(w1=w1.tolist(),b1=b1.tolist(),w2=w2.tolist());zero=float(pw[np.all(z[a]==z[b],axis=1)].sum())
 elapsed=time.perf_counter()-tick;model=dict(kind=name,columns=col.tolist(),mean=mean.tolist(),scale=scale.tolist(),dimension=1066,**parameters);write_record(p/(name+'-model.json'),model);m=json.loads((p/(name+'-model.json')).read_bytes());zr=(x[:,m['columns']]-m['mean'])/m['scale'];restored=np.maximum(zr@m['w1']+m['b1'],0)@m['w2']if name=='anchored_relu'else zr@m['weights'];assert np.array_equal(prediction,restored);rows=[]
 for key in dict.fromkeys(roots):
  idx=np.flatnonzero(roots==key);ss=sign[idx[0]];rank=ss*prediction[idx];target=ss*y[idx];best=rank==rank.max();bm=ss*baseline[idx]==np.max(ss*baseline[idx]);rows.append(dict(root=str(key),group=str(groups[idx[0]]),chosen=ci[idx][best].tolist(),regret=float(np.mean(target.max()-target[best])),material_regret=float(np.mean(target.max()-target[bm]))))
 results[name]=dict(seconds=elapsed,variable_columns=len(col),train_roots=len(train_roots),train_children=int(train.sum()),zero_pair_weight=zero,rows=rows,exact_restore=True)
write_record(out,dict(scope=__doc__,results=results,denominator=selection['roots'],limits='Prospective fresh whole trajectories on four exposed rules; no report fitting or selection. ReLU is a scoped joint-state rank, not calibrated utility or full generated-domain coverage. Aux/history/precise predicates omitted; complete GameSession teacher remains. No default change.'));print(json.dumps(results,indent=2))
