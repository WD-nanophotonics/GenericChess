"""Two frozen small rank fits; no old labels, tuning or calibrated leaf use."""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'fit-result.json';assert not out.exists()
selection=json.loads((p/'rule-selection.json').read_bytes());plan=json.loads((p/'rule-declaration.json').read_bytes())
assert selection['screen_sha256']==hashlib.sha256((p/'rule-screen.json').read_bytes()).hexdigest()
chosen={f"{r['seed']}/{r['ply']}":r for r in selection['roots']if r['selected']}
with np.load(p/'rule-screen-inputs.npz',allow_pickle=False)as d:
 keep=np.asarray([r in chosen for r in d['root_ids']]);x=d['features'][keep];y=d['targets'][keep];roots=d['root_ids'][keep];groups=d['groups'][keep];ci=d['child_indices'][keep];baseline=d['baseline'][keep]
train=groups=='train';train_roots=list(dict.fromkeys(roots[train]))
if not train_roots:
 write_record(out,dict(status='NO_TRAIN_ROOT_NO_FIT',denominator=selection['roots']));raise SystemExit(0)
sign=np.asarray([1 if next(r for r in plan['roots']if f"{r['seed']}/{r['ply']}"==key)['side']==0 else -1 for key in roots])
count_columns=list(range(66))+list(range(396,462))+list(range(792,924))+[924,930,936,937]
assert len(count_columns)==268
write_record(p/'fit-declaration.json',dict(scope=__doc__,declaration_sha256=selection['declaration_sha256'],input_sha256=hashlib.sha256((p/'rule-screen-inputs.npz').read_bytes()).hexdigest(),fit=plan['ranking_fit'],count_columns=count_columns,candidates=['count','moments'],no_model_selection=True))
results={}
for name,columns in [('count',count_columns),('moments',list(range(938)))]:
 columns=np.asarray(columns);col=columns[np.ptp(x[train][:,columns],axis=0)>0];mean=x[train][:,col].mean(0);scale=x[train][:,col].std(0);z=(x[:,col]-mean)/scale;diff=[];pw=[];counts={}
 for key in train_roots:
  idx=np.flatnonzero((roots==key)&train);ss=sign[idx[0]];t=ss*y[idx];best=np.flatnonzero(t==t.max());other=np.flatnonzero(t<t.max());n=len(best)*len(other);assert n>0;counts[str(key)]=n
  for a in best:
   for b in other:diff.append(ss*(z[idx[a]]-z[idx[b]]));pw.append(1/(len(train_roots)*n))
 diff=np.asarray(diff);pw=np.asarray(pw);w=np.random.default_rng(2026100949).normal(0,.001,len(col));m=np.zeros_like(w);v=np.zeros_like(w);tick=time.perf_counter()
 for step in range(1,301):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-tick<120
  grad=-(pw*(1-diff@w>0))@diff+.0001*w;m=.9*m+.1*grad;v=.999*v+.001*grad*grad;w-=.01*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
 elapsed=time.perf_counter()-tick;prediction=z@w
 model=dict(kind='untrained-before-this-fixed-fit shared actor rank',columns=col.tolist(),mean=mean.tolist(),scale=scale.tolist(),weights=w.tolist(),dimension=938,candidate=name);write_record(p/(name+'-model.json'),model)
 restored=json.loads((p/(name+'-model.json')).read_bytes());assert np.array_equal(prediction,((x[:,restored['columns']]-restored['mean'])/restored['scale'])@restored['weights'])
 rows=[]
 for key in dict.fromkeys(roots):
  idx=np.flatnonzero(roots==key);ss=sign[idx[0]];rank=ss*prediction[idx];target=ss*y[idx];a=rank==rank.max();b=ss*baseline[idx]==np.max(ss*baseline[idx]);rows.append(dict(root=str(key),group=str(groups[idx[0]]),chosen=ci[idx][a].tolist(),regret=float(np.mean(target.max()-target[a])),material_regret=float(np.mean(target.max()-target[b]))))
 results[name]=dict(seconds=elapsed,variable_columns=len(col),train_roots=len(train_roots),train_children=int(train.sum()),zero_pair_weight=float(pw[np.all(diff==0,axis=1)].sum()),rows=rows,exact_restore=True)
write_record(out,dict(scope=__doc__,results=results,denominator=selection['roots'],limits='Four exposed rules, fresh trajectories, teacher-screened conditional domain. No report fit or hyperparameter selection. Pure rank is not numerical leaf utility; aux/history and precise predicates still omitted. Full GameSession teacher unchanged.'))
print(json.dumps(results,indent=2))
