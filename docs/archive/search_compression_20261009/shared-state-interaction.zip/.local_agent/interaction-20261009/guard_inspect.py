from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'guard-operands.json';assert not out.exists();plan=json.loads(Path('.local_agent/sharing-20261009/rule-declaration.json').read_bytes());rows=[]
for r in plan['rule_descriptors']:
 c=compile_ruleset_for_execution(ruleset_from_dict(r['rules']))
 for pattern in c.ir.patterns:
  for g in pattern.guards:rows.append(dict(seed=r['seed'],types=pattern.type_ids,guard=record_value(g),zones=record_value(c.ir.zones)))
write_record(out,dict(rows=rows,scope='Existing typed capacity predicate operands, no labels or fit.'))
print(json.dumps(rows,indent=2))
