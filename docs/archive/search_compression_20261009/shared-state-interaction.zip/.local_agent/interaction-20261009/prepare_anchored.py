"""New prospective cohort: corrected anchors and genuine nonlinear joint state.
Prior report fits stay intact; none of their labels enters these fits.
"""
from pathlib import Path
p=Path(__file__).parent;q=p/'anchored';q.mkdir(exist_ok=True)
source=(p/'screen.py').read_text().replace('range(2026101200,2026101216)','range(2026101400,2026101416)')
source=source.replace('from prototype import InteractionProjection', "sys.path.insert(0,str(Path('.local_agent/interaction-20261009')))\nfrom anchor_repair import AnchoredProjection")
source=source.replace('InteractionProjection(cc)','AnchoredProjection(cc)')
source=source.replace("['938 shared actor spatial moments', '268 count-only subset, same current/base/hand/promoted/side information']", "['268 count-only subset', '1066 anchored moments linear', '1066 anchored moments width16 ReLU rank']")
source=source.replace("kind='two fixed linear owner0 rank fits, frozen moments vs count ablation; experimental only'", "kind='three frozen rank fits: count linear, anchored linear, anchored width16 ReLU; no model selection'")
start=source.index('"""');end=source.index('"""',start+3)+3
source='''"""Prospective anchor/nonlinear comparison:16fresh whole trajectories1400..1415.
All original four complete generated rules, roots7/16, whole-rule groups unchanged.
Count linear vs anchored linear vs same anchored input width16 ReLU. Three fixed
300step margin1 root-balanced fits, same train-only normalization and regularizer.
Question: can an actual small joint-state evaluator earn benefit over the cheap
count baseline, after retaining observed anchor state? Linear vs ReLU isolates
architecture on identical input. No old report fitting, tuning or model selection.
UnitD2/2048node/1sec/q0 references;1500sec batch checkpoint, all caps and zero roots
remain. Single run estimated15-25min, no>1hour job. Aux/history/precise guard scope
omitted from shared projection but full Position/GameSession teacher preserved.
"""'''+source[end:]
source=source.replace("epochs=300,learning_rate=.01", "hidden_width=16,epochs=300,learning_rate=.01")
target=q/'screen.py';assert not target.exists();target.write_text(source,encoding='utf-8')
