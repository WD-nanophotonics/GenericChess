"""Same full-root cost protocol for three frozen anchored-cohort fits."""
from pathlib import Path
p=Path(__file__).parent;q=p/'anchored'
source=(p/'callers.py').read_text()
source=source.replace('from prototype import InteractionProjection', "sys.path.insert(0,str(Path('.local_agent/interaction-20261009')))\nfrom anchor_repair import AnchoredProjection")
source=source.replace('InteractionProjection(c)','AnchoredProjection(c)')
source=source.replace("models={};setup=[];compiled=[]", "models={};setup=[];compiled=[]")
start=source.index("for name in ('count','moments'):");end=source.index("for row in plan['rule_descriptors']:",start)
source=source[:start]+'''for name in ('count','anchored_linear','anchored_relu'):
 m=json.loads((p/(name+'-model.json')).read_bytes());m['columns']=np.asarray(m['columns']);m['mean']=np.asarray(m['mean']);m['scale']=np.asarray(m['scale'])
 for field in ('weights','w1','b1','w2'):
  if field in m:m[field]=np.asarray(m[field])
 models[name]=m
'''+source[end:]
source=source.replace('e.board.values()', 'e.projection.board.values()')
source=source.replace("methods=['unit','count','moments']", "methods=['unit','count','anchored_linear','anchored_relu']")
source=source.replace("methods=('unit','count','moments');shift=(i+rep)%3", "methods=('unit','count','anchored_linear','anchored_relu');shift=(i+rep)%4")
source=source.replace("w,offset=models[name];scores=np.asarray([e.encode(ch.position)@w+offset for ch in children])", "m=models[name];xx=np.asarray([e.encode(ch.position)for ch in children]);z=(xx[:,m['columns']]-m['mean'])/m['scale'];scores=np.maximum(z@m['w1']+m['b1'],0)@m['w2']if name=='anchored_relu'else z@m['weights']")
source=source.replace("r.get('method')=='moments'", "r.get('method')=='anchored_relu'")
source=source.replace('median moments actual root time','median anchored ReLU actual root time')
target=q/'callers.py';assert not target.exists();target.write_text(source,encoding='utf-8')
