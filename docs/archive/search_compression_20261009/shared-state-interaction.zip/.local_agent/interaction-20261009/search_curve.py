"""Frozen node/resource curves: existing TT/order vs lexical Unit search.
All24 old four-rule roots, four node budgets, two balanced repeats per mode.
No price change, new teacher or labels, no report-driven resource extension.
Question: does reuse actually buy a cheaper finite decision, not merely nodes?
384calls <=5sec each; anticipated10-30min, total40min cost checkpoint.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.learning.features import material_features,non_anchor_type_ids
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'search-curve.json';assert not out.exists()
old=Path('.local_agent/sharing-20261009');plan=json.loads((old/'rule-declaration.json').read_bytes());screen=json.loads((old/'rule-screen.json').read_bytes());compiled=[compile_ruleset_for_execution(ruleset_from_dict(r['rules']))for r in plan['rule_descriptors']]
budgets=[128,512,2048,8192]
write_record(p/'search-curve-declaration.json',dict(scope=__doc__,conditions=dict(depth=3,node_budgets=budgets,seconds=5,q=0,root_tactical=False,native=False,disk=False),methods=['lexical/noTT','order+TT'],repeats=2,all_roots=24,calls=384,limits='Same node/time conditions. Frozen earlier finite UnitD2 teachers; incomplete teachers UNKNOWN. Caches cold per-call player, compiled caches process-shared. TT and order together, sequential timing. No strength/default claim.'))
rows=[];started=time.perf_counter()
for rep in range(2):
 for i in (range(len(plan['roots']))if rep==0 else reversed(range(len(plan['roots'])))):
  root=plan['roots'][i];ref=screen['roots'][i];c=compiled[root['rule_index']];types=non_anchor_type_ids(c);s=GameSession(c)
  for a in root['route']:s.submit(action_from_dict(a))
  class Unit:
   def evaluate(self,state):return 1000*sum(material_features(state.position,types,perspective=state.position.side_to_move).array())
   def capture_order_value(self,moving,captured):return 0 if c.support.type_metadata[captured.current_type_id].is_anchor else 10000
  for budget in (budgets if rep==0 else reversed(budgets)):
   for reuse in ([False,True]if rep==0 else[True,False]):
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']and not json.loads(Path('.local_agent/slack.json').read_bytes())['stopped']
    row=dict(root=f"{root['seed']}/{root['ply']}",rule_index=root['rule_index'],group=root['group'],rep=rep,node_budget=budget,reuse=reuse)
    if time.perf_counter()-started>=2400:row.update(known=False,reason='whole_run_cost_checkpoint')
    else:
     player=AlphaBetaPlayer(c,evaluator_override=Unit(),use_tt=reuse,use_ordering=reuse,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));before=s.state;tick=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=budget,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-tick;validate_pv(s,d);assert s.state==before;ss=1 if root['side']==0 else-1;chosen=next(x for x in ref['children']if x['action']==action_to_dict(d.action));regret=None if not ref['known']else max(ss*x['owner0_target']for x in ref['children'])-ss*chosen['owner0_target'];row.update(known=True,seconds=elapsed,regret=regret,decision=record_value(d))
    rows.append(row);write_record(out,dict(scope=__doc__,complete=False,rows=rows))
  print(rep,row['root'],len(rows),round(time.perf_counter()-started,3),flush=True)
write_record(out,dict(scope=__doc__,complete=True,seconds=time.perf_counter()-started,rows=rows,limits='Resource/result curve on exposed prior finite teachers, not calibrated utility. Unknown references remain None. Changed tie/depth/TT nodes alone are not gains. No fit/default change, no extensions after adverse outcomes.'))
