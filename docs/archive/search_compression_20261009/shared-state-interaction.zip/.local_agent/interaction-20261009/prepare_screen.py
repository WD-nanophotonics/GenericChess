"""Freeze changed-premise shared moments vs its count-only ablation.
No prior report labels or candidate predictions in the prospective declaration.
"""
from pathlib import Path
p=Path(__file__).parent
source=Path('.local_agent/sharing-20261009/rule_screen.py').read_text()
source=source.replace('range(2026101100,2026101112)', 'range(2026101200,2026101216)')
source=source.replace('ri=i//3', 'ri=i//4')
source=source.replace("if i<6 else'dev'if i<9", "if i<8 else'dev'if i<12")
source=source.replace("from rule_counts import descriptors,encode,AXES", "from prototype import InteractionProjection\nfrom rule_counts import descriptors,AXES")
source=source.replace('compiled.append((cc,vv))', 'compiled.append((cc,InteractionProjection(cc)))')
source=source.replace('features.append(encode(child.position,vectors))', 'features.append(vectors.encode(child.position))')
source=source.replace('>=600', '>=1500')
source=source.replace("['shared rule-conditioned board/hand counts']", "['938 shared actor spatial moments', '268 count-only subset, same current/base/hand/promoted/side information']")
source=source.replace("kind='linear owner0 root-ranking, experimental only'", "kind='two fixed linear owner0 rank fits, frozen moments vs count ablation; experimental only'")
source=source.replace('24 complete frontiers,<=600sec target checkpoint', '32 complete frontiers,<=1500sec cost checkpoint')
source=source.replace('constant descriptor scope omits on-board base/promoted/history, precise guards/effect operands', 'projection retains on-board current/base/promoted/side; omits auxiliary/history and precise conditional guard/effect references')
start=source.index('"""');end=source.index('"""',start+3)+3
source='''"""Prospective frozen actor-moment comparison on four exposed full rules.
16 fresh whole trajectories seeds1200..1215, roots7/16. First two rules train,
third dev, fourth report. Full legal candidates before UnitD2/2048node/1sec/q0
labels. All unknowns and material-zero roots retained, no old report reuse.
938 moment projection versus its268 count-only subset, equal300Adam/margin1.
Decision: does cheap position/rule interaction improve conditional root choices
over the same actor descriptors without coordinates? No calibrated leaf or
unseen-rule/strength claim. Estimated15-25min single run, interruptible checkpoint.
"""'''+source[end:]
target=p/'screen.py';assert not target.exists();target.write_text(source,encoding='utf-8')
