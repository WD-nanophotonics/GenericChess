"""Retain denominators and resource/result curves; no new fit or selected subset."""
from pathlib import Path
import sys,json,statistics
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
from generic_chess.ai.evaluation.config import MATE_THRESHOLD
p=Path(__file__).parent;out=p/'summary.json';assert not out.exists();screen=json.loads((p/'rule-screen.json').read_bytes());callers=json.loads((p/'callers.json').read_bytes());curve=json.loads((p/'search-curve.json').read_bytes());assert screen['complete']and callers['complete']and curve['complete'];cells=[c for r in screen['roots']for c in r['children']];known=sum(c['known']for c in cells);selected=[r for r in screen['roots']if r['selected']];rows=[]
for budget in(128,512,2048,8192):
 for reuse in(False,True):
  rr=[r for r in curve['rows']if r['node_budget']==budget and r['reuse']==reuse and r['known']];reg=[r['regret']for r in rr if r['regret']is not None];rows.append(dict(node_budget=budget,reuse=reuse,calls=len(rr),known_teacher_calls=len(reg),zero_regret=sum(v==0 for v in reg),positive_regret=sum(v>0 for v in reg),mate_scale_regret=sum(v>=MATE_THRESHOLD for v in reg),D2plus=sum(r['decision']['completed_depth']>=2 for r in rr),D3=sum(r['decision']['completed_depth']>=3 for r in rr),nodes=sum(r['decision']['nodes']for r in rr),seconds=sum(r['seconds']for r in rr),actual_pushes=sum(r['decision']['successors_materialized']for r in rr),evaluations=sum(r['decision']['evaluation_calls']for r in rr)))
whole=[]
for name in('unit','count','moments'):
 for group in('train','dev','report'):
  rr=[r for r in callers['rank_rows']if r.get('method')==name and r['group']==group and r['rep']==0];knownr=[r for r in rr if r['regret']is not None];whole.append(dict(method=name,group=group,roots=len(rr),known=len(knownr),regrets=[dict(root=r['root'],regret=r['regret'],selected=r['selected'])for r in knownr],seconds=sum(r['seconds']for r in rr),score_seconds=sum(r['score_seconds']for r in rr)))
write_record(out,dict(roots=len(screen['roots']),children=len(cells),complete_children=known,unknown_children=len(cells)-known,complete_roots=sum(r['known']for r in screen['roots']),selected_roots=len(selected),zero_roots=sum(r['known']and not r['selected']for r in screen['roots']),teacher_seconds=screen['seconds'],rank_calls=len(callers['rank_rows']),search_calls=len(callers['search_rows']),whole_denominator=whole,resource_curve=rows,resource_seconds=curve['seconds'],limits='Development/exposed four rules; whole trajectories split. Separate mate-scale from ordinary regret, all unknowns kept. No defaults or strength claims. Search TT/order together, per-call player cold, compiler process cache warm. Count factoring and inventory closure are post-result arithmetic diagnostics only.'))
print(json.dumps(dict(roots=len(screen['roots']),children=len(cells),unknown_children=len(cells)-known,selected=len(selected),resource_curve=rows),indent=2))
