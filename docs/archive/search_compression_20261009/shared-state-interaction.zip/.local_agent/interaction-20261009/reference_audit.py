"""Inventory omitted binding references, not an encoding completeness certificate."""
from pathlib import Path
import sys,json,collections
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'reference-audit.json';assert not out.exists()
plan=json.loads(Path('.local_agent/sharing-20261009/rule-declaration.json').read_bytes());rows=[]
for row in plan['rule_descriptors']:
 c=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));refs=[]
 for pattern in c.ir.patterns:
  for e in pattern.effects:
   if e.type_ref is not None:refs.append(dict(pattern=pattern.pattern_id,role='effect',kind=e.kind,reference=record_value(e.type_ref)))
  for g in pattern.guards:
   if g.type_ref is not None:refs.append(dict(pattern=pattern.pattern_id,role='predicate',kind=g.aggregation,reference=record_value(g.type_ref)))
 rows.append(dict(seed=row['seed'],references=refs,count_by_role_kind=dict(collections.Counter(x['role']+':'+x['reference']['kind']for x in refs))))
write_record(out,dict(scope=__doc__,rows=rows,limits='Actor moment encoding resolves explicit set_current_type effects and metadata promotion target sets only. Predicates compare current/base fields under action binding; numeric counts of references cannot replace operands. Full executor still owns actual legal/state transitions.'))
print([dict(seed=r['seed'],counts=r['count_by_role_kind'])for r in rows])
