"""Factor the frozen count rank into rule tables; no refit/numeric leaf."""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'count-tables.json';assert not out.exists();plan=json.loads((p/'rule-declaration.json').read_bytes());m=json.loads((p/'count-model.json').read_bytes());w=np.zeros(938);w[m['columns']]=np.asarray(m['weights'])/m['scale'];offset=float(-np.asarray(m['mean'])@(np.asarray(m['weights'])/m['scale']));records=[]
for ri,rules in enumerate(plan['rule_descriptors']):
 c=compile_ruleset_for_execution(ruleset_from_dict(rules['rules']));e=InteractionProjection(c);tables={t:dict(current=float(v@w[:66]),base=float(v@w[396:462]),hands=[float(v@w[792:858]),float(v@w[858:924])])for t,v in e.actors.items()}
 def score(position):
  value=offset+w[936+position.side_to_move]
  for piece in position.board:
   if piece is not None:
    sign=1 if piece.owner==0 else -1;value+=sign*(tables[piece.current_type_id]['current']+tables[piece.base_type_id]['base'])
    if piece.promoted:value+=w[924+6*piece.owner]
  for owner,h in enumerate(position.hands):
   for t,count in h.counts:value+=count*tables[t]['hands'][owner]
  return value
 states=[];roots=[]
 for root in plan['roots']:
  if root['rule_index']!=ri:continue
  s=GameSession(c)
  for a in root['route']:s.submit(action_from_dict(a))
  children=[apply_action(s.state,action_from_dict(a),c).position for a in root['children']];begin=len(states);states.extend(children);roots.append((root,begin,len(states)))
 direct=np.asarray([e.encode(pos)@w+offset for pos in states]);factored=np.asarray([score(pos)for pos in states]);assert np.allclose(direct,factored,rtol=1e-12,atol=1e-10)
 choices=[]
 for root,lo,hi in roots:
  if lo==hi:continue
  sign=1 if root['side']==0 else -1;a=sign*direct[lo:hi];b=sign*factored[lo:hi];aa=np.flatnonzero(a==a.max()).tolist();bb=np.flatnonzero(b==b.max()).tolist();choices.append(dict(root=f"{root['seed']}/{root['ply']}",direct=aa,factored=bb,equal=aa==bb))
 costs=[]
 for rep in range(3):
  for name,call in [('direct',lambda pos:e.encode(pos)@w+offset),('factored',score)][::1 if rep%2==0 else-1]:
   tick=time.perf_counter()
   for _ in range(10):
    for state in states:call(state)
   costs.append(dict(rep=rep,method=name,calls=10*len(states),seconds=time.perf_counter()-tick))
 records.append(dict(rule=rules['seed'],states=len(states),tables=tables,offset=offset,promoted=[float(w[924]),float(w[930])],side=[float(w[936]),float(w[937])],max_absolute_score_difference=float(np.max(abs(direct-factored))),choices=choices,cost=costs))
write_record(out,dict(scope=__doc__,records=records,limits='Count rank algebra only; signed uncalibrated values are not material prices. Floating reassociation can change exact tie membership; every mismatch retained, no tolerance used to force choice agreement. No model/train/default change; scoring timing excludes public legal/transition work and setup.'))
print([(r['rule'],r['states'],r['max_absolute_score_difference'],sum(not c['equal']for c in r['choices']))for r in records])
