"""Check actual four-rule descriptor collisions after observed dev failure.
No new labels, fit or board transplantation; only original initial sessions.
"""
from pathlib import Path
import sys,json
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'descriptor-collisions.json';assert not out.exists();plan=json.loads((p/'rule-declaration.json').read_bytes());cases=[]
for row in plan['rule_descriptors']:
 c=compile_ruleset_for_execution(ruleset_from_dict(row['rules']));e=InteractionProjection(c);s=GameSession(c);actions=[action_to_dict(a)for a in s.legal_actions()];cases.append((row,c,e,actions))
collisions=[]
for i,(r,c,e,acts)in enumerate(cases):
 for r2,c2,e2,acts2 in cases[i+1:]:
  for t,v in e.actors.items():
   if c.support.type_metadata[t].is_anchor:continue
   for tt,vv in e2.actors.items():
    if not np.array_equal(v,vv):continue
    one=r['rules']['piece_types'];two=r2['rules']['piece_types'];one=next(a for a in one if a['type_id']==t);two=next(a for a in two if a['type_id']==tt)
    if one['movement_atoms']!=two['movement_atoms']:collisions.append(dict(rules=[r['seed'],r2['seed']],types=[t,tt],same_actor_vector=True,atoms=[one['movement_atoms'],two['movement_atoms']],initial_legal_sets_equal=sorted(map(lambda x:json.dumps(x,sort_keys=True),acts))==sorted(map(lambda x:json.dumps(x,sort_keys=True),acts2))))
write_record(out,dict(scope=__doc__,collisions=collisions,limits='Different atom text alone is not a behavioral difference; initial full legal-set distinction is a ruleset-level fact, not attribution to one colliding actor. No transplanted state, model or label change. A zero collision result does not prove representation completeness.'))
print(dict(collisions=len(collisions),rules=[[r['seed'],len(a)]for r,c,e,a in cases]))
