"""Untrained repair: anchors remain state information even at zero material price."""
from pathlib import Path
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from prototype import InteractionProjection
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from scripts.research_record import write_record

class AnchoredProjection:
    def __init__(self,c):
        self.projection=InteractionProjection(c)
        self.anchors={t for t,m in c.support.type_metadata.items()if m.is_anchor}
        self.area=c.board_shape.area
        self.dimension=938+2*self.area
    def encode(self,position):
        result=np.zeros(self.dimension);result[:938]=self.projection.encode(position)
        for square,piece in enumerate(position.board):
            if piece is not None and piece.current_type_id in self.anchors:
                result[938+piece.owner*self.area+square]=1
        return result

if __name__=='__main__':
 p=Path(__file__).parent;out=p/'anchor-repair.json';assert not out.exists();probe=json.loads((p/'anchor-probe.json').read_bytes())['witness'];plan=json.loads(Path('.local_agent/sharing-20261009/rule-declaration.json').read_bytes());root=next(r for r in plan['roots']if f"{r['seed']}/{r['ply']}"==probe['root']);c=compile_ruleset_for_execution(ruleset_from_dict(plan['rule_descriptors'][root['rule_index']]['rules']));e=AnchoredProjection(c);s=GameSession(c)
 for a in root['route']:s.submit(action_from_dict(a))
 children=[]
 for a in probe['actions']:
  branch=GameSession(c);branch._state=s.state;branch._search_history_witnesses=s._search_history_witnesses;branch.submit(action_from_dict(a));children.append(branch)
 rows=[e.encode(child.state.position)for child in children];assert np.array_equal(rows[0][:938],rows[1][:938]);assert not np.array_equal(*rows)
 tick=time.perf_counter()
 for _ in range(1000):
  for child in children:e.encode(child.state.position)
 elapsed=time.perf_counter()-tick
 write_record(out,dict(scope=__doc__,dimension=e.dimension,root=probe['root'],changed_anchor_axes=np.flatnonzero(rows[0]!=rows[1]).tolist(),calls=2000,seconds=elapsed,trained=False,limits='Shape-specific exact anchor occupancy preserves this witness; multiple identical anchors can still share occupancy and auxiliary/history semantics remain omitted. No fit, learned benefit or frozen experiment modification.'))
 print(dict(dimension=e.dimension,changed_anchor_axes=np.flatnonzero(rows[0]!=rows[1]).tolist(),microseconds=elapsed/2000*1e6,trained=False))
