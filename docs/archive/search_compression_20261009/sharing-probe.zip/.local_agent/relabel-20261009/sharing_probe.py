"""Train-only support probe for a changed sharing premise; NO FIT/LABEL QUERY.
Pool existing ordered relative displacements by sign(dx),sign(dy), and fixed
Chebyshev distance1/2/3plus. Keep all original Position fields alongside it.
This finite coarse comparator aliases geometry and is not full-rule encoding.
Support/size may justify a fresh pilot, never reuse current report groups to fit.
"""
from pathlib import Path
import sys,json,time
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent;plan=json.loads((p/'ranking-declaration.json').read_bytes());enc=SparsePositionEncoder(compile_ruleset_for_execution(ruleset_from_dict(plan['rules'])));nt=2*len(enc.types);width=enc.shape.width;height=enc.shape.height;dxn=2*width-1;dyn=2*height-1;fine_dim=nt*nt*dxn*dyn;coarse_dim=nt*nt*27
with np.load(p/'ranking-selected-inputs.npz',allow_pickle=False)as d:
 train=d['groups']=='train';pos=d['position'][train].copy();fine=d['position_pairs'][train,enc.dimension:].copy()
assert fine.shape==(202,fine_dim)
raw=np.arange(fine_dim);dy=raw%dyn-height+1;dx=(raw//dyn)%dxn-width+1;pair=raw//(dxn*dyn);distance=np.maximum(np.abs(dx),np.abs(dy));band=np.where(distance<=1,0,np.where(distance<=2,1,2));mapping=((pair*3+np.sign(dx)+1)*3+np.sign(dy)+1)*3+band
coarse=np.zeros((len(pos),coarse_dim));rows,cols=np.nonzero(fine);tick=time.perf_counter();np.add.at(coarse,(rows,mapping[cols]),fine[rows,cols]);seconds=time.perf_counter()-tick
assert np.array_equal(fine.sum(axis=1),coarse.sum(axis=1))
for j in range(4):
 board=pos[j,:enc.hand_offset].reshape((nt,enc.shape.area));actors=[(sq%width,sq//width,t)for t,sq in np.argwhere(board>0)];oracle=np.zeros(coarse_dim)
 for i,(xa,ya,ta)in enumerate(actors):
  for k,(xb,yb,tb)in enumerate(actors):
   if i==k:continue
   ddx=xb-xa;ddy=yb-ya;dist=max(abs(ddx),abs(ddy));band=0 if dist<=1 else 1 if dist<=2 else 2;key=int((((ta*nt+tb)*3+np.sign(ddx)+1)*3+np.sign(ddy)+1)*3+band);oracle[key]+=1
 assert np.array_equal(oracle,coarse[j])
report=dict(scope=__doc__,train_rows=len(pos),position_dimension=enc.dimension,position_variable_columns=int((np.ptp(pos,axis=0)>0).sum()),fine_pair_dimension=fine_dim,coarse_pair_dimension=coarse_dim,fine_pair_variable_columns=int((np.ptp(fine,axis=0)>0).sum()),coarse_pair_variable_columns=int((np.ptp(coarse,axis=0)>0).sum()),fine_bytes=fine.nbytes,coarse_bytes=coarse.nbytes,stored_histogram_pool_seconds=seconds,independent_actor_checks=4,exact_pair_totals=True,no_targets_or_report_rows_read=True,decision='Possible fresh-data parameter-sharing comparator only; no accuracy/latency claim or training. Relative histograms augment existing fields; history/rule-condition issues remain. Do not refit exposed current report cohorts.',limits='Fixed sign/distance pooling aliases distinct displacements; cannot establish full-domain sufficiency. Stored-vector pooling excludes actual state extraction, legality, search and deployment.')
write_record(p/'sharing-probe.json',report);print(json.dumps(report,indent=2))
