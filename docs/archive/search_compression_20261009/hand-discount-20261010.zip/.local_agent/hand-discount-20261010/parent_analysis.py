"""Summarize equal-condition parent diagnostics without trajectory or price-gain claims."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'parent-controls.json').read_bytes());assert d['complete']
groups=[]
for key,parent in d['parents'].items():
 rows=[r for r in d['rows'] if r['parent_key']==key];assert len(rows)==3
 groups.append(dict(seed=parent['seed'],aliases=parent['aliases'],root_actions=rows[0]['root_actions'],arms=[dict(policy=r['policy'],action=r['decision']['action'],score=r['decision']['score'],nodes=r['decision']['nodes'],depth=r['decision']['completed_depth'],stop=r['decision']['termination_reason'],evals=r['decision']['evaluation_calls'],replies=r['replies'],immediate_loss_witnesses=len(r['witnesses']))for r in rows]))
v=dict(scope=__doc__,parents=len(groups),calls=len(d['rows']),transitions=d['transitions'],seconds=d['seconds'],groups=groups,decision='Equal-hand does not remove2151local failures. Unit avoids one v3loss by completingD2 at same512limit; on two other full-history parents all arms retainD1loss. Investigate finite-root coverage/cost with unchanged prices before treating discount removal as a general remedy; no budget extension/default/fit.')
write_record(p/'parent-analysis.json',v);print(json.dumps(v))
