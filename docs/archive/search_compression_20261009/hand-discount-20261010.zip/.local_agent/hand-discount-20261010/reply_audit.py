"""Selected-child immediate-terminal audit of all10declared hand-law games.
Every executed child enters, including all ongoing games; repeated identical
full-history states within the same RuleSet reuse one exact reply audit.
Both zero/adverse counts retained. No root all-defense proof, fitting or WDL.
Expected<15min,900sec cost checkpoint; partial output remains explicitly
incomplete if reached. Decision: is equal-board/hand merely changing trajectories,
or does a new-rule local price failure warrant further hand-law work?
"""
from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'reply-audit.json';assert not out.exists();d=json.loads((p/'games.json').read_bytes());assert d['complete'] and len(d['rows'])==10
cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};rows=[];audits={};transitions=0;cache_hits=0;start=time.perf_counter();complete=True
write_record(p/'reply-audit-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),games_sha256=hashlib.sha256((p/'games.json').read_bytes()).hexdigest(),total_plies=sum(len(r['steps'])for r in d['rows']),identity='sha256 canonical complete recorded GameState, including fingerprint and history'))
def save(done):write_record(out,dict(scope=__doc__,rows=rows,audits=audits,complete=done,transitions=transitions,cache_hits=cache_hits,seconds=time.perf_counter()-start))
for game in d['rows']:
 case=cases[game['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in game['steps']:
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  if time.perf_counter()-start>900:complete=False;break
  s.submit(action_from_dict(step['action']));state=record_value(s.state);assert state==step['state'];key=hashlib.sha256(json.dumps(state,sort_keys=True,separators=(',',':')).encode()).hexdigest()
  if key in audits:
   assert audits[key]['state']==state;cache_hits+=1
  else:
   replies=0;witnesses=[]
   if not s.state.terminal_status.is_terminal:
    for reply in legal_actions(s.state,c):
     child=apply_action(s.state,reply,c);transitions+=1;replies+=1
     if child.terminal_status.is_terminal and child.terminal_status.winner==1-step['side']:witnesses.append(dict(action=action_to_dict(reply),terminal=record_value(child.terminal_status)))
   audits[key]=dict(state=state,replies=replies,witnesses=witnesses,complete=True)
  row=dict(seed=game['seed'],policies=game['policies'],ply=step['ply'],mover=step['side'],policy=game['policies'][step['side']],state_key=key,terminal=record_value(s.state.terminal_status),selected_action=step['action'],depth=step['decision']['completed_depth'],stop=step['decision']['termination_reason'],immediate_loss_witnesses=len(audits[key]['witnesses']));rows.append(row)
  if len(rows)%16==0:save(False)
 if not complete:break
 print(game['seed'],game['policies'],len(game['steps']),sum(bool(r['immediate_loss_witnesses'])for r in rows if r['seed']==game['seed']and r['policies']==game['policies']),transitions,cache_hits,flush=True)
save(complete)
