"""Whole declared cohort accounting, no report fitting or independent-sample claim."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
import json,hashlib
from collections import Counter
from scripts.research_record import write_record
p=Path(__file__).parent
d=json.loads((p/'games.json').read_bytes());a=json.loads((p/'reply-audit.json').read_bytes())
assert d['complete'] and a['complete'] and len(d['rows'])==10
assert len(a['rows'])==sum(len(g['steps']) for g in d['rows'])
rows=[];pairs=[]
for g in d['rows']:
 q=[r for r in a['rows'] if r['seed']==g['seed'] and r['policies']==g['policies']]
 assert len(q)==len(g['steps'])
 ds=[s['decision'] for s in g['steps']]
 rows.append(dict(seed=g['seed'],policies=g['policies'],plies=len(ds),terminal=g['terminal'],classification=g['classification'],seconds=g['seconds'],holes=[r['ply'] for r in q if r['immediate_loss_witnesses']],depth=dict(Counter(x['completed_depth'] for x in ds)),stop=dict(Counter(x['termination_reason'] for x in ds)),nodes=sum(x['nodes'] for x in ds),qnodes=sum(x['qnodes'] for x in ds),evaluation_calls=sum(x['evaluation_calls'] for x in ds),legal_generation_calls=sum(x['legal_generation_calls'] for x in ds),legal_actions_generated=sum(x['legal_actions_generated'] for x in ds),successors_materialized=sum(x['successors_materialized'] for x in ds),tt_hits=sum(x['tt_hits'] for x in ds)))
for seed in sorted({g['seed'] for g in d['rows']}):
 for old,new in ((['unit','v3'],['unit','v3_hand_board']),(['v3','unit'],['v3_hand_board','unit'])):
  x=next(g for g in d['rows'] if g['seed']==seed and g['policies']==old);y=next(g for g in d['rows'] if g['seed']==seed and g['policies']==new)
  div=next((i for i,(s,t) in enumerate(zip(x['steps'],y['steps'])) if s['action']!=t['action']),None)
  pairs.append(dict(seed=seed,old=old,new=new,first_divergence=div,common_parent=(x['initial'] if div==0 else x['steps'][div-1]['state']) if div is not None else None,old_plies=len(x['steps']),new_plies=len(y['steps']),old_terminal=x['terminal'],new_terminal=y['terminal'],same_actions_to_shorter_end=div is None,identical_trajectory=div is None and len(x['steps'])==len(y['steps'])))
v=dict(scope=__doc__,games=10,plies=sum(x['plies'] for x in rows),game_seconds=d['seconds'],audit_seconds=a['seconds'],audit_physical_transitions=a['transitions'],audit_unique_full_states=len(a['audits']),audit_cache_hits=a['cache_hits'],audit_logical_rows=len(a['rows']),rows=rows,pairs=pairs,decision='No hand-price default:2150changes trajectories without immediate witnesses;2151all arms retain local loss. Compare first-divergence common parents at unchanged512conditions, not trajectory totals as price gains.',input_hashes={n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ('games.json','reply-audit.json','prospective-rules.json')})
write_record(p/'analysis.json',v)
print(json.dumps({k:v[k] for k in ('games','plies','game_seconds','audit_seconds','audit_physical_transitions','audit_unique_full_states','audit_cache_hits','decision')}))
print(json.dumps([{k:r[k] for k in ('seed','policies','plies','holes','depth','stop','nodes')}for r in rows]))
print(json.dumps([{k:v for k,v in r.items() if k!='common_parent'} for r in pairs]))
