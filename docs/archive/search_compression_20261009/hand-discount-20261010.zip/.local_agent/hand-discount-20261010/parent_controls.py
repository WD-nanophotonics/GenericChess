"""Matched first-divergence and immediate-hole parent controls, all five distinct
parents from the completed275ply cohort. Unit/v3/v3_hand_board each coldCore
D2max512nodes/10sec/q0/hard8/Unitordering/root-scanOFF. Enumerate only selected
child replies; not all root defense, fitting, WDL or game extension. Expected<5min,
300sec cost checkpoint. Decision: separate hand-driven first choices from
policy-dependent trajectories and persistent budget-limited local failures.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'parent-controls.json';assert not out.exists()
games=json.loads((p/'games.json').read_bytes())['rows'];analysis=json.loads((p/'analysis.json').read_bytes());audit=json.loads((p/'reply-audit.json').read_bytes());cases={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};targets={}
for pair in analysis['pairs']:
 if pair['first_divergence'] is not None:
  g=next(g for g in games if g['seed']==pair['seed'] and g['policies']==pair['old']);targets[(g['seed'],tuple(g['policies']),pair['first_divergence'])]='first_divergence'
for r in audit['rows']:
 if r['immediate_loss_witnesses']:targets[(r['seed'],tuple(r['policies']),r['ply'])]='selected_hole'
# Deduplicate only equal complete parents; retain target aliases.
parents={}
for (seed,kinds,ply),purpose in targets.items():
 g=next(g for g in games if g['seed']==seed and g['policies']==list(kinds));state=g['initial'] if ply==0 else g['steps'][ply-1]['state'];key=hashlib.sha256(json.dumps(state,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 parents.setdefault(key,dict(seed=seed,policies=kinds,ply=ply,state=state,aliases=[]))['aliases'].append(dict(policies=kinds,ply=ply,purpose=purpose))
write_record(p/'parent-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),parent_keys=list(parents),aliases=targets.__len__(),arms=['unit','v3','v3_hand_board'],games_sha256=hashlib.sha256((p/'games.json').read_bytes()).hexdigest()))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[];transitions=0;start=time.perf_counter()
for key,r in parents.items():
 c=compile_ruleset_for_execution(ruleset_from_dict(cases[r['seed']]['rules']));s=GameSession(c)
 for raw in cases[r['seed']]['route'][:4]:s.submit(action_from_dict(raw))
 g=next(g for g in games if g['seed']==r['seed'] and g['policies']==list(r['policies']))
 for step in g['steps'][:r['ply']]:s.submit(action_from_dict(step['action']))
 assert record_value(s.state)==r['state'];profile,_=build_semantic_opportunity_profile(c,cfg);before=s.state;root_count=len(legal_actions(before,c))
 for kind in ('unit','v3','v3_hand_board'):
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused'];assert time.perf_counter()-start<300
  leaf=UnitEvaluator() if kind=='unit' else Evaluator(c,replace(profile,hand_value_by_base_type=dict(profile.board_value_by_type)) if kind=='v3_hand_board' else profile,cfg)
  pl=AlphaBetaPlayer(c,evaluator_override=leaf,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,dec);assert s.state==before
  child=apply_action(before,dec.action,c);transitions+=1;w=[];reply_count=0
  if not child.terminal_status.is_terminal:
   for reply in legal_actions(child,c):
    nxt=apply_action(child,reply,c);transitions+=1;reply_count+=1
    if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-before.position.side_to_move:w.append(dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status)))
  rows.append(dict(parent_key=key,seed=r['seed'],aliases=r['aliases'],policy=kind,root_actions=root_count,decision=record_value(dec),child=record_value(child),replies=reply_count,witnesses=w))
 write_record(out,dict(scope=__doc__,parents=parents,rows=rows,complete=False,transitions=transitions,seconds=time.perf_counter()-start))
 print(r['seed'],r['ply'],root_count,[(x['policy'],x['decision']['completed_depth'],len(x['witnesses']))for x in rows[-3:]],flush=True)
write_record(out,dict(scope=__doc__,parents=parents,rows=rows,complete=True,transitions=transitions,seconds=time.perf_counter()-start))
