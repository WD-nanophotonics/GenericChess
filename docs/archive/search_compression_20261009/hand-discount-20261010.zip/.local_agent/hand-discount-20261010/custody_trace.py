"""Whole275action custody decomposition of saved full-state trajectories.
Separate current-type board and base-type hand deltas in the acting owner's
frame, using the frozen maps. No replay, new labels, fitted coefficients or
conservation assumption for transforms/promotion/captures. All zeroes retained.
Decision: which observed ordinary-drop bonuses actually follow the0.9hand
convention, rather than changing type/ownership or conditional permission?
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;games=json.loads((p/'games.json').read_bytes())['rows'];rules={r['seed']:r for r in json.loads((p/'prospective-rules.json').read_bytes())['rules']};rows=[];start=time.perf_counter()
def terms(pos,board,hand,side):
 b=sum((1 if piece['owner']==side else -1)*board[piece['current_type_id']] for piece in pos['board'] if piece is not None)
 h=sum((1 if owner==side else -1)*n*hand[t] for owner,stock in enumerate(pos['hands']) for t,n in stock['counts'])
 return b,h
for g in games:
 before=g['initial']
 for step in g['steps']:
  case=rules[g['seed']];after=step['state'];side=step['side'];arms={}
  for k,b,h in (('unit',{t:0 if t=='K' else 100 for t in case['v3_board']},{t:0 if t=='K' else 100 for t in case['v3_hand']}),('v3',case['v3_board'],case['v3_hand']),('v3_hand_board',case['v3_board'],case['v3_board'])):
   old=terms(before['position'],b,h,side);new=terms(after['position'],b,h,side);arms[k]=dict(board_delta=new[0]-old[0],hand_delta=new[1]-old[1],total_delta=sum(new)-sum(old))
  action=step['action'];is_drop='base_type_id' in action and 'from_square' not in action
  rows.append(dict(seed=g['seed'],policies=g['policies'],ply=step['ply'],side=side,action=action,is_drop=is_drop,terminal=after['terminal_status'],arms=arms))
  before=after
v=dict(scope=__doc__,rows=rows,actions=len(rows),drops=sum(r['is_drop'] for r in rows),positive_v3_drop_deltas=sum(r['is_drop'] and r['arms']['v3']['total_delta']>0 for r in rows),nonzero_flat_drop_deltas=sum(r['is_drop'] and r['arms']['v3_hand_board']['total_delta']!=0 for r in rows),seconds=time.perf_counter()-start)
write_record(p/'custody-trace.json',v);print(json.dumps({k:v for k,v in v.items() if k!='rows'}))
