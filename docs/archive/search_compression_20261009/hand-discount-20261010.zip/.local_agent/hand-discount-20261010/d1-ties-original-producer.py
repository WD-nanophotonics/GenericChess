"""Exposed2151ply3 D1tie attribution, not a development gate or price fit.
All126root children are scored under the three frozen leaf maps; enumerate
immediate replies ONLY to their union of highest-D1 ties plus the previously
selected UnitD2 action. Opposite outcomes select: all top ties losing -> static
material ranking lacks this immediate safety distinction; mixed ties -> tie
selection remains a plausible local cause. Neither implies a default remedy.
No larger search/game budget, WDL or human-label read. Expected<8min,600sec
cost checkpoint; all zero/adverse/tied members retained.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action,legal_successors
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'d1-ties.json';assert not out.exists();control=json.loads((p/'parent-controls.json').read_bytes());r=next(row for row in control['parents'].values()if row['seed']==202610082151 and row['ply']==3);case=next(row for row in json.loads((p/'prospective-rules.json').read_bytes())['rules']if row['seed']==202610082151);g=next(game for game in json.loads((p/'games.json').read_bytes())['rows']if game['seed']==r['seed'] and game['policies']==list(r['policies']));c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
for a in case['route'][:4]:s.submit(action_from_dict(a))
for step in g['steps'][:3]:s.submit(action_from_dict(step['action']))
assert record_value(s.state)==r['state'];cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profile,_=build_semantic_opportunity_profile(c,cfg);leaves={'unit':UnitEvaluator(),'v3':Evaluator(c,profile,cfg),'v3_hand_board':Evaluator(c,replace(profile,hand_value_by_base_type=dict(profile.board_value_by_type)),cfg)};children=list(legal_successors(s.state,c));scores=[{k:-leaf.evaluate(ch)for k,leaf in leaves.items()}for a,ch in children];maxima={k:max(x[k]for x in scores)for k in leaves};unit=next(x['decision']['action'] for x in control['rows']if x['seed']==r['seed'] and x['policy']=='unit' and x['root_actions']==126);indices=[i for i,(a,ch)in enumerate(children)if action_to_dict(a)==unit or any(scores[i][k]==maxima[k]for k in leaves)]
write_record(p/'d1-ties-declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),parent=r['state'],root_actions=len(children),maxima=maxima,selected_indices=indices,top_sizes={k:sum(x[k]==maxima[k]for x in scores)for k in leaves},scores=scores))
rows=[];transitions=len(children);start=time.perf_counter();complete=True
for i in indices:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 if time.perf_counter()-start>600:complete=False;break
 a,ch=children[i];w=[];n=0
 if not ch.terminal_status.is_terminal:
  for reply in legal_actions(ch,c):
   nxt=apply_action(ch,reply,c);transitions+=1;n+=1
   if nxt.terminal_status.is_terminal and nxt.terminal_status.winner==1-s.state.position.side_to_move:w.append(dict(action=action_to_dict(reply),terminal=record_value(nxt.terminal_status)))
 rows.append(dict(index=i,action=action_to_dict(a),scores=scores[i],top_for=[k for k in leaves if scores[i][k]==maxima[k]],unit_D2_selected=action_to_dict(a)==unit,replies=n,witnesses=w));write_record(out,dict(scope=__doc__,rows=rows,complete=False,expected=len(indices),transitions=transitions,seconds=time.perf_counter()-start))
write_record(out,dict(scope=__doc__,rows=rows,complete=complete,expected=len(indices),transitions=transitions,seconds=time.perf_counter()-start));print(dict(complete=complete,rows=len(rows),top_sizes={k:sum(x[k]==maxima[k]for x in scores)for k in leaves},top_holes={k:sum(k in x['top_for'] and bool(x['witnesses'])for x in rows)for k in leaves},transitions=transitions,seconds=time.perf_counter()-start))
