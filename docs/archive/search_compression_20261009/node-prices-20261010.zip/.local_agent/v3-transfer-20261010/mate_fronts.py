"""Posthoc all-action immediate-exposure fronts at every prospective mating game.
Each root is the loser-to-move parent2plies before its recorded checkmate.
Question: are observed losses already locally forced, or did bounded leaf
selection leave an available action with no immediate winning enemy reply?
All root actions and all replies, including zero witnesses and terminal children.
One-reply safety is not long-term safety/WDL; dependence/selection is explicit.
No fitted scores, budget extension, success threshold or product change.
Expected<30min;1800sec cost checkpoint retains unfinished action/front UNKNOWN.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.search import terminal_score
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;assert not (p/'mate-fronts.json').exists()
d=json.loads((p/'games.json').read_bytes());assert d['complete'];games=[r for r in d['rows'] if r['terminal']['status']=='checkmate'];cases={r['seed']:r for r in json.loads((p/'signal-declaration.json').read_bytes())['rules']}
write_record(p/'mate-front-declaration.json',dict(scope=__doc__,roots=[dict(seed=r['seed'],policies=r['policies'],ply=len(r['steps'])-2) for r in games],cost_checkpoint_seconds=1800,selection='All prospective checkmates; no selected favorable rule or action.'))
rows=[];start=time.perf_counter();transitions=0;done=True
for g in games:
 case=cases[g['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in g['steps'][:-2]:s.submit(action_from_dict(step['action']))
 state=s.state;side=state.position.side_to_move;selected=g['steps'][-2]['action'];assert side==1-g['terminal']['winner'];acts=s.legal_actions()
 cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);profile,scope=build_semantic_opportunity_profile(c,cfg);ev=Evaluator(c,profile,cfg)
 excluded={r['pattern']:r['reasons'] for t in scope['types'].values() for r in t['excluded']}
 row=dict(seed=g['seed'],policies=g['policies'],ply=len(g['steps'])-2,mover=side,selected=selected,parent=record_value(state),selected_decision=g['steps'][-2]['decision'],legal_actions=len(acts),actions=[],complete=False)
 for a in acts:
  if time.perf_counter()-start>1800:done=False;break
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  child=apply_action(state,a,c);transitions+=1;raw=action_to_dict(a);static_score=ev.evaluate(child)*(1 if child.position.side_to_move==side else -1)
  score=terminal_score(child.terminal_status,side,1) if child.terminal_status.is_terminal else static_score
  rr=dict(action=raw,selected=raw==selected,terminal=record_value(child.terminal_status),static_child_parent_score=static_score,terminal_aware_child_parent_score=score,price_exclusions=excluded.get(raw.get('pattern_id'),[]),replies=0,witnesses=[],complete=False)
  if not child.terminal_status.is_terminal:
   for reply in legal_actions(child,c):
    if time.perf_counter()-start>1800:done=False;break
    t=apply_action(child,reply,c);transitions+=1;rr['replies']+=1
    if t.terminal_status.is_terminal and t.terminal_status.winner==1-side:rr['witnesses'].append(dict(action=action_to_dict(reply),terminal=record_value(t.terminal_status)))
  rr['complete']=done;row['actions'].append(rr)
  if not done:break
 row['complete']=done and len(row['actions'])==len(acts);rows.append(row);write_record(p/'mate-fronts.json',dict(scope=__doc__,rows=rows,complete=False,transitions=transitions,seconds=time.perf_counter()-start))
 print(g['seed'],g['policies'],len(row['actions']),len(acts),sum(r['complete'] and not r['witnesses'] and r['terminal']['status']=='ongoing' for r in row['actions']),row['complete'],flush=True)
 if not done:break
write_record(p/'mate-fronts.json',dict(scope=__doc__,rows=rows,complete=done,transitions=transitions,seconds=time.perf_counter()-start))
