"""Posthoc4arm control at all8first prospective crossed-policy departures.
Same full parent reached by the shared Unit prefix; no game extended or label fit.
Unit100/Unit1000 isolate positive scale; uniform1000board/900hand isolates hand
discount from v3 relative type prices. Cold D2/512/10sec/q0, fixed Unit ordering.
Question: is the first changed action evidence of relative type prices or a
uniform custody convention? Choice agreement is attribution, not utility gain.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;assert not (p/'first-departures.json').exists()
cases={r['seed']:r for r in json.loads((p/'signal-declaration.json').read_bytes())['rules']};games=json.loads((p/'games.json').read_bytes())['rows'];anal=json.loads((p/'analysis.json').read_bytes())['rows'];base={r['seed']:r for r in games if r['policies']==['unit','unit']}
roots=[r for r in anal if r['policies']!=['unit','unit']];assert len(roots)==8 and all(r['first_divergence'] is not None for r in roots)
write_record(p/'first-departure-declaration.json',dict(scope=__doc__,roots=[dict(seed=r['seed'],policies=r['policies'],ply=r['first_divergence']) for r in roots],arms=['unit100','unit1000','uniform_hand900','v3'],limits=dict(depth=2,nodes=512,seconds=10,q=0,qhard=8)))
rows=[];start=time.perf_counter();cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for r in roots:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 case=cases[r['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in base[r['seed']]['steps'][:r['first_divergence']]:s.submit(action_from_dict(step['action']))
 profile,_=build_semantic_opportunity_profile(c,cfg)
 class Leaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind;self.ev=Evaluator(c,profile,cfg)
  def evaluate(self,state):
   if self.kind=='v3':return self.ev.evaluate(state)
   if self.kind=='unit100':return super().evaluate(state)
   if self.kind=='unit1000':return 10*super().evaluate(state)
   board=sum((1000 if piece.owner==0 else -1000) for piece in state.position.board if piece is not None and piece.current_type_id!='K')
   hand=sum((900 if owner==0 else -900)*sum(n for _,n in h.counts) for owner,h in enumerate(state.position.hands));return (board+hand)*(1 if state.position.side_to_move==0 else -1)
 arms=[]
 for kind in ('unit100','unit1000','uniform_hand900','v3'):
  before=s.state;pl=AlphaBetaPlayer(c,evaluator_override=Leaf(kind),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();dec=pl.choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,dec);assert s.state==before
  arms.append(dict(policy=kind,decision=record_value(dec),seconds=time.perf_counter()-tick))
 assert action_to_dict(action_from_dict(arms[0]['decision']['action']))==base[r['seed']]['steps'][r['first_divergence']]['action']
 crossed=next(g for g in games if g['seed']==r['seed'] and g['policies']==r['policies']);assert arms[-1]['decision']['action']==crossed['steps'][r['first_divergence']]['action']
 rows.append(dict(seed=r['seed'],source_policies=r['policies'],ply=r['first_divergence'],parent=record_value(s.state),arms=arms));write_record(p/'first-departures.json',dict(scope=__doc__,rows=rows,complete=False))
write_record(p/'first-departures.json',dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
print([(r['seed'],r['source_policies'],r['arms'][0]['decision']['action']==r['arms'][1]['decision']['action'],r['arms'][2]['decision']['action']==r['arms'][3]['decision']['action']) for r in rows])
