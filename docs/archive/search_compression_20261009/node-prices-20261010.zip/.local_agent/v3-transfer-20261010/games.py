"""Frozen v3/Unit crossed finite-event diagnostic on prospective rules2142-2145.
Opening4, twelve cells, cold per-move TT D2/512/10sec/q0/hard8/96plies.
Leaf only changes; Unit capture ordering always. Rebuild current v3 profiles
and assert exact agreement with saved tables before games. Full execution
promotion/drop/aux/history preserved; disabled dynamics, declared v3 exclusions.
No fit, default, strength claim or outcome-based budget extension.
Question: do static rule prices change adverse finite events under the qualified
node policy? Compare same-rule prospective Unit/Unit, retain both intervention
sides, all caps and unknown ongoing outcomes. Expected<15min from236sec crossed and197sec repeated Unit
controls;1200sec batch cost checkpoint, technical interruptions not ongoing96.
"""
from pathlib import Path
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,hashlib,statistics
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product')),str(Path('.local_agent/interaction-20261009')),str(Path('.local_agent/predictor-transfer-20261009'))]
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from test_rectangular_search_override import UnitEvaluator
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'games.json';assert not out.exists();d=json.loads(Path('.local_agent/v3-transfer-20261010/signal-declaration.json').read_bytes())
write_record(p/'declaration.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rules_sha256=hashlib.sha256(Path('.local_agent/v3-transfer-20261010/signal-declaration.json').read_bytes()).hexdigest(),openings=[4],policies=[['unit','unit'],['unit','v3'],['v3','unit']],max_plies=96,limits=dict(depth=2,nodes=512,seconds=10,q=0,qhard=8),no_training=True,batch_cost_checkpoint_seconds=1200))
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)

rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,scope=build_semantic_opportunity_profile(c,cfg)
 assert dict(profile.board_value_by_type)==case['v3_board'] and dict(profile.hand_value_by_base_type)==case['v3_hand']
 class Leaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind;self.v3=Evaluator(c,profile,cfg)
  def evaluate(self,state):return super().evaluate(state) if self.kind=='unit' else self.v3.evaluate(state)
 for opening,repeat in ((4,0),):
  for kinds in (('unit','unit'),('unit','v3'),('v3','unit')):
   assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
   s=GameSession(c)
   for raw in case['route'][:opening]:s.submit(action_from_dict(raw))
   row=dict(seed=case['seed'],opening=opening,repeat=repeat,policies=kinds,initial=record_value(s.state),profile=record_value(profile),profile_scope=record_value(scope),steps=[],complete=False);t=time.perf_counter();players=[AlphaBetaPlayer(c,evaluator_override=Leaf(k),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)) for k in kinds]
   for ply in range(96):
    if s.state.terminal_status.is_terminal:break
    assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
    assert time.perf_counter()-start<1200
    before=s.state;side=before.position.side_to_move;tick=time.perf_counter();players[side]._tt.clear();decision=players[side].choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,decision);assert s.state==before
    assert decision.action is not None
    s.submit(decision.action);row['steps'].append(dict(ply=ply,side=side,decision=record_value(decision),action=action_to_dict(decision.action),seconds=time.perf_counter()-tick,state=record_value(s.state)))
   term=s.state.terminal_status;row.update(complete=True,seconds=time.perf_counter()-t,terminal=record_value(term),classification='TERMINAL' if term.is_terminal else 'CENSORED',owner0_reward=(0 if term.winner is None else 1 if term.winner==0 else -1) if term.is_terminal else None);rows.append(row);write_record(out,dict(scope=__doc__,rows=rows,complete=False))
   print(case['seed'],opening,kinds,len(row['steps']),row['classification'],row['terminal'],round(row['seconds'],3),flush=True)
write_record(out,dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True))
