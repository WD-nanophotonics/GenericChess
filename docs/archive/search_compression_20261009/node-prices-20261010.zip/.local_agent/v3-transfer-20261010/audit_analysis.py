"""Recompute full chosen-child and all-action frontier denominators."""
from pathlib import Path
from collections import Counter
import json,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'mate-audit.json').read_bytes());assert d['complete'] and len(d['rows'])==587
rows=[]
for seed,policies in sorted(set((r['seed'],tuple(r['policies'])) for r in d['rows'])):
 rr=[r for r in d['rows'] if r['seed']==seed and tuple(r['policies'])==policies]
 rows.append(dict(seed=seed,policies=policies,selected_children=len(rr),terminal_children=sum(r['terminal']['status']!='ongoing' for r in rr),replies=sum(r['replies'] for r in rr),loss_holes=[dict(ply=r['ply'],mover=r['mover'],policy=r['mover_policy'],depth=r['decision_depth'],stop=r['decision_stop'],witnesses=len(r['witnesses'])) for r in rr if r['witnesses']]))
write_record(p/'mate-audit-analysis.json',dict(scope=d['scope'],rows=rows,complete=True,selected_children=len(d['rows']),reply_transitions=d['transitions'],seconds=d['seconds'],witness_roots=sum(bool(r['witnesses']) for r in d['rows']),holes_by_policy=dict(Counter(r['mover_policy'] for r in d['rows'] if r['witnesses'])),limits='Full denominator; dependent selected trajectories; zero means no immediate winning reply, not eventual safety.'))
if (p/'mate-fronts.json').exists():
 f=json.loads((p/'mate-fronts.json').read_bytes());rows=[]
 for r in f['rows']:
  actions=[a for a in r['actions'] if a['complete']]
  def safe(a):return not a['witnesses'] and not (a['terminal']['status']!='ongoing' and a['terminal']['winner']==1-r['mover'])
  selected=next((a for a in actions if a['selected']),None);best=max((a['terminal_aware_child_parent_score'] for a in actions),default=None);ties=[a for a in actions if a['terminal_aware_child_parent_score']==best]
  rows.append(dict(seed=r['seed'],policies=r['policies'],ply=r['ply'],mover_policy=r['policies'][r['mover']],complete=r['complete'],legal_actions=r['legal_actions'],audited_actions=len(actions),immediate_loss_actions=sum(not safe(a) for a in actions),no_immediate_loss_actions=sum(safe(a) for a in actions),selected_witnesses=None if selected is None else len(selected['witnesses']),selected_price_exclusions=None if selected is None else selected['price_exclusions'],selected_depth=r['selected_decision']['completed_depth'],selected_stop=r['selected_decision']['termination_reason'],static_top_ties=len(ties),static_top_immediate_losses=sum(not safe(a) for a in ties),selected_static_score=None if selected is None else selected['static_child_parent_score'],best_no_immediate_loss_score=max((a['terminal_aware_child_parent_score'] for a in actions if safe(a)),default=None),replies=sum(a['replies'] for a in actions)))
 write_record(p/'mate-front-analysis.json',dict(scope=f['scope'],rows=rows,complete=f['complete'],transitions=f['transitions'],seconds=f['seconds'],limits='Posthoc selected mating parents, not independent validation. Zero surviving one-reply action proves only local immediate exposure; nonzero does not prove eventual survival. Static tie sets and actual bounded search choices differ. Unfinished actions are UNKNOWN, not safe/loss.'))
 print(json.dumps(rows,indent=2))
