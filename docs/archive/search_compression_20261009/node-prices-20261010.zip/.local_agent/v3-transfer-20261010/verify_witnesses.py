"""Independent replay of saved actual immediate-loss witnesses, not full timing reproduction."""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from scripts.research_record import write_record
p=Path(__file__).parent
cases={r['seed']:r for r in json.loads((p/'signal-declaration.json').read_bytes())['rules']}
d=json.loads((p/'mate-audit.json').read_bytes());games=json.loads((p/'games.json').read_bytes())['rows'];rows=[]
for r in d['rows']:
 if not r['witnesses']:continue
 case=cases[r['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);g=next(g for g in games if g['seed']==r['seed'] and g['policies']==r['policies'])
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in g['steps'][:r['ply']+1]:s.submit(action_from_dict(step['action']))
 for w in r['witnesses']:
  a=action_from_dict(w['action']);assert a in s.legal_actions();t=apply_action(s.state,a,c);assert t.terminal_status.is_terminal and t.terminal_status.winner==1-r['mover']
 rows.append(dict(seed=r['seed'],policies=r['policies'],ply=r['ply'],witnesses=len(r['witnesses'])))
assert len(rows)==7
write_record(p/'witness-recovery.json',dict(rows=rows,verified=True,limits='All saved fresh chosen-child winning witnesses replayed; not all frontier transitions or timings reproduced.'))
print(rows)
