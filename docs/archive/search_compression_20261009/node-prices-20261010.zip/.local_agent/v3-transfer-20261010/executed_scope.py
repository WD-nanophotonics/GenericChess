"""Post-hoc trace of all executed actions in the prospective12game cohort.
Retain actual promotion/current/base/hand/aux effects and v3 pattern exclusion
provenance. This tests coverage, not an alternative utility label or WDL.
"""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;d=json.loads((p/'games.json').read_bytes());assert d['complete']
cases={r['seed']:r for r in json.loads(Path('.local_agent/v3-transfer-20261010/signal-declaration.json').read_bytes())['rules']}
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);rows=[]
for game in d['rows']:
 case=cases[game['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));profile,scope=build_semantic_opportunity_profile(c,cfg);ev=Evaluator(c,profile,cfg);s=GameSession(c)
 for raw in case['route'][:4]:s.submit(action_from_dict(raw))
 excluded={x['pattern']:x['reasons'] for r in scope['types'].values() for x in r['excluded']}
 events=[]
 for st in game['steps']:
  before=s.state;action=action_from_dict(st['action']);s.submit(action);assert record_value(s.state)==st['state'];after=s.state
  pattern=st['action'].get('pattern_id');special=pattern and pattern.startswith(('sem_00_','sem_01_'))
  aux_changed=before.position.aux_state!=after.position.aux_state
  if special or aux_changed or st['action'].get('promotion_target_id') is not None:
   events.append(dict(ply=st['ply'],side=st['side'],mover_policy=game['policies'][st['side']],action=st['action'],excluded_reasons=excluded.get(pattern,[]),aux_changed=aux_changed,parent_score=ev.evaluate(before),child_score_parent_frame=-ev.evaluate(after),before=record_value(before),after=record_value(after)))
 rows.append(dict(seed=game['seed'],policies=game['policies'],events=events,all_plies=len(game['steps'])))
write_record(p/'executed-scope.json',dict(scope=__doc__,rows=rows))
print([(r['seed'],r['policies'],len(r['events'])) for r in rows])
