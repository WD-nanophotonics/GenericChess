"""Position-only eligibility control at all3actual Xtransform children.
The global temp_right flag guards Pdrop with value0; its debug name is not a
benefit/owner label. Compare observed flag1 against0, first with actual stock,
then with one synthetic P in current side's hand. No search, history/value
counterfactual or claim that synthetic positions are reachable. All6pairs fixed;
compare full legal actions and exact guarded Pdrop subsets, including zeros.
Question: does the observed omitted slot change current eligibility, or only
interact with stock absent at those states? This guides one input premise,
not automatic feature expansion or training.
"""
from pathlib import Path
from dataclasses import replace
import json,sys,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.semantic_executor import semantic_engine_for,iter_semantic_public_actions
from generic_chess.core.position import Hands
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;assert not (p/'slot-eligibility.json').exists();events=json.loads((p/'executed-scope.json').read_bytes())['rows'];games=json.loads((p/'games.json').read_bytes())['rows'];cases={r['seed']:r for r in json.loads((p/'signal-declaration.json').read_bytes())['rules']}
roots=[(r,e) for r in events for e in r['events'] if e['action'].get('pattern_id','').startswith('sem_01_')];assert len(roots)==3
write_record(p/'slot-eligibility-declaration.json',dict(scope=__doc__,roots=[dict(seed=r['seed'],policies=r['policies'],ply=e['ply']) for r,e in roots],variants=['actual_hand_stock','add_one_P_to_side_to_move_hand'],slot_values=[0,1]))
rows=[];start=time.perf_counter()
for r,e in roots:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 c=compile_ruleset_for_execution(ruleset_from_dict(cases[r['seed']]['rules']));s=GameSession(c);g=next(g for g in games if g['seed']==r['seed'] and g['policies']==r['policies'])
 for a in cases[r['seed']]['route'][:4]:s.submit(action_from_dict(a))
 for step in g['steps'][:e['ply']+1]:s.submit(action_from_dict(step['action']))
 assert record_value(s.state)==e['after'];pos=s.state.position;assert len(pos.aux_state)==1 and pos.aux_state[0][1]==1;side=pos.side_to_move
 counts=dict(pos.hands[side].counts);assert counts.get('P',0)==0;synthetic={**counts,'P':1};hh=list(pos.hands);hh[side]=Hands(tuple(sorted(synthetic.items())))
 for name,hands in [('actual_hand_stock',pos.hands),('add_one_P_to_side_to_move_hand',tuple(hh))]:
  variants=[]
  for flag in (0,1):
   altered=replace(pos,hands=hands,aux_state=((pos.aux_state[0][0],flag),));engine=semantic_engine_for(c);assert engine is not None;acts=[action_to_dict(a) for a in iter_semantic_public_actions(engine,altered)];drop=[a for a in acts if a.get('pattern_id','').startswith('sem_00_')]
   variants.append(dict(flag=flag,position=record_value(altered),legal_actions=acts,Pdrops=drop))
  a,b=variants;rows.append(dict(seed=r['seed'],policies=r['policies'],ply=e['ply'],variant=name,side=side,variants=variants,all_actions_equal=sorted(json.dumps(x,sort_keys=True) for x in a['legal_actions'])==sorted(json.dumps(x,sort_keys=True) for x in b['legal_actions']),Pdrop_counts=[len(x['Pdrops']) for x in variants]))
write_record(p/'slot-eligibility.json',dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start));print([(r['seed'],r['variant'],r['Pdrop_counts'],r['all_actions_equal']) for r in rows])
