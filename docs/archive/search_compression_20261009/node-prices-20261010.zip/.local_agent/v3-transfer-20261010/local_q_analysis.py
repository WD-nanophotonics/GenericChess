"""Recompute every matched local q arm; no favorable-root selection."""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent
d=json.loads((p/'local-q-controls.json').read_bytes());assert d['complete'] and len(d['rows'])==7
rows=[]
for r in d['rows']:
 arms=[]
 for a in r['arms']:
  x=a['decision'];t=a['child_terminal']
  f=json.loads((p/'mate-fronts.json').read_bytes());root=next(z for z in f['rows'] if z['seed']==r['seed'] and z['policies']==r['source_policies'])
  loss=bool(a['immediate_loss_witnesses']) or (t['status']!='ongoing' and t['winner']==1-root['mover'])
  arms.append(dict(policy=a['policy'],q=a['q'],depth=x['completed_depth'],nodes=x['nodes'],qnodes=x.get('qnodes'),stop=x['termination_reason'],immediate_loss=loss,witnesses=a['immediate_loss_witnesses'],seconds=a['seconds']))
 rows.append(dict(seed=r['seed'],policies=r['source_policies'],ply=r['ply'],arms=arms,unit_q_choice_changed=r['arms'][0]['action']!=r['arms'][2]['action'],v3_q_choice_changed=r['arms'][1]['action']!=r['arms'][3]['action']))
write_record(p/'local-q-analysis.json',dict(scope=d['scope'],rows=rows,calls=28,seconds=d['seconds'],loss_counts={str((k,q)):sum(a['immediate_loss'] for r in rows for a in r['arms'] if a['policy']==k and a['q']==q)for k in ('unit','v3')for q in (0,1)},limits='Selected exposed mating parents; immediate labels only, no long-term survival/default/strength inference.'))
print(json.dumps(rows,indent=2))
