"""Complete prospective4rule/12cell comparison; no post-outcome selection."""
from pathlib import Path
from collections import Counter
import sys,json
sys.path.insert(0,str(Path.cwd()))
from scripts.research_record import write_record
p=Path(__file__).parent;d=json.loads((p/'games.json').read_bytes());assert d['complete'] and len(d['rows'])==12
def label(r):
 t=r['terminal'];return 'ongoing96' if t['status']=='ongoing' else 'draw' if t['winner'] is None else 'owner0_win' if t['winner']==0 else 'owner0_loss'
base={r['seed']:r for r in d['rows'] if r['policies']==['unit','unit']};rows=[]
for r in d['rows']:
 b=base[r['seed']];assert r['initial']==b['initial']
 div=next((i for i,(x,y) in enumerate(zip(b['steps'],r['steps'])) if x['action']!=y['action']),None)
 rows.append(dict(seed=r['seed'],policies=r['policies'],baseline_event=label(b),event=label(r),winner=r['terminal']['winner'],plies=len(r['steps']),first_divergence=div,seconds=r['seconds'],nodes=sum(s['decision']['nodes'] for s in r['steps']),evaluations=sum(s['decision']['evaluation_calls'] for s in r['steps']),depths=dict(Counter(s['decision']['completed_depth'] for s in r['steps'])),stops=dict(Counter(s['decision']['termination_reason'] for s in r['steps']))))
out=dict(scope=__doc__,rows=rows,plies=sum(r['plies'] for r in rows),seconds=d['seconds'],event_changes=sum(r['event']!=r['baseline_event'] for r in rows),events_by_policy={str(k):dict(Counter(label(r) for r in d['rows'] if tuple(r['policies'])==k)) for k in (('unit','unit'),('unit','v3'),('v3','unit'))},limits='Four prospective rules, deterministic chosen openings, dependent intervention trajectories and capped-depth policies; no default, strength or universal utility inference. No model trained or outcome-selected extension.')
write_record(p/'analysis.json',out);print(json.dumps(out,indent=2))
