"""Frozen actual one-reply terminal audit of all12prospective2142-2145 Unit/Unit and crossed trajectories. All selected-action child states enter,
not only finished games; terminal children are distinguished. No search/budget
extension or WDL inference. Record every legal opponent reply count and concrete
immediate losing witnesses, including zero-witness states. No invented censor draws.
Question: do event changes include observable immediate-mate holes rather than
only changed choices? Expected<30min from existing Core transition timings;
1800sec cost checkpoint saves partial UNKNOWN frontier if reached.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;assert not (p/'mate-audit.json').exists()
d=json.loads(Path('.local_agent/v3-transfer-20261010/signal-declaration.json').read_bytes());cases={r['seed']:r for r in d['rules']}
new=json.loads((p/'games.json').read_bytes());assert new['complete'] and len(new['rows'])==12
games=new['rows'];rows=[];transitions=0;start=time.perf_counter()
write_record(p/'mate-audit-declaration.json',dict(scope=__doc__,games=[dict(seed=r['seed'],policies=r['policies'],plies=len(r['steps'])) for r in games],success='diagnostic witnesses only; no pass threshold',old_frozen_games_unchanged=True))
done=True
for game in games:
 case=cases[game['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in game['steps']:
  if time.perf_counter()-start>1800:done=False;break
  assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
  s.submit(action_from_dict(step['action']));assert record_value(s.state)==step['state']
  st=s.state;root=dict(seed=game['seed'],policies=game['policies'],ply=step['ply'],mover=step['side'],mover_policy=game['policies'][step['side']],selected_action=step['action'],decision_depth=step['decision']['completed_depth'],decision_stop=step['decision']['termination_reason'],terminal=record_value(st.terminal_status),replies=0,witnesses=[],complete=True)
  if not st.terminal_status.is_terminal:
   for a in legal_actions(st,c):
    child=apply_action(st,a,c);transitions+=1;root['replies']+=1
    if child.terminal_status.is_terminal and child.terminal_status.winner==1-step['side']:
     root['witnesses'].append(dict(action=action_to_dict(a),terminal=record_value(child.terminal_status),state=record_value(child)))
  rows.append(root)
  if len(rows)%16==0:write_record(p/'mate-audit.json',dict(scope=__doc__,rows=rows,complete=False,transitions=transitions,seconds=time.perf_counter()-start))
 if not done:break
 print(game['seed'],game['policies'],len(game['steps']),sum(bool(r['witnesses']) for r in rows if r['seed']==game['seed'] and r['policies']==game['policies']),flush=True)
write_record(p/'mate-audit.json',dict(scope=__doc__,rows=rows,complete=done,transitions=transitions,seconds=time.perf_counter()-start))
