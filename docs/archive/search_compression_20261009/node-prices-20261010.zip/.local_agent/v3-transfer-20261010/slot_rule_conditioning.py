"""Three fixed synthetic-stock positions crossed with eq0/eq1 rule guards.
Question: does raw sparse Position equality determine action eligibility across
rules? Both fingerprints remain distinct; existing encoder already prohibits
cross-rule weight reuse. This is one premise for a shared behavioral input,
not a defect in that scoped encoder, training target, reachable-state utility,
or permission to strip generated semantics. No outcome-selected states.
"""
from pathlib import Path
from dataclasses import replace
import json,sys,copy
import numpy as np
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.semantic_executor import semantic_engine_for,iter_semantic_public_actions
from scripts.position_features import SparsePositionEncoder
from scripts.research_record import write_record
p=Path(__file__).parent;assert not (p/'slot-rule-conditioning.json').exists()
cases={r['seed']:r for r in json.loads((p/'signal-declaration.json').read_bytes())['rules']}
events=json.loads((p/'executed-scope.json').read_bytes())['rows'];games=json.loads((p/'games.json').read_bytes())['rows']
roots=[(r,e)for r in events for e in r['events']if e['action'].get('pattern_id','').startswith('sem_01_')];assert len(roots)==3
write_record(p/'slot-rule-declaration.json',dict(scope=__doc__,roots=[dict(seed=r['seed'],policies=r['policies'],ply=e['ply'])for r,e in roots],guard_values=[0,1],slot_values=[0,1],synthetic_hand='one P added to side to move'))
rows=[]
for r,e in roots:
 case=cases[r['seed']];c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);g=next(g for g in games if g['seed']==r['seed']and g['policies']==r['policies'])
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in g['steps'][:e['ply']+1]:s.submit(action_from_dict(step['action']))
 pos=s.state.position;hh=list(pos.hands);hh[pos.side_to_move]=hh[pos.side_to_move].add('P');pos=replace(pos,hands=tuple(hh));arms=[];features=[]
 for guard in (0,1):
  rule=copy.deepcopy(case['rules']);rule['semantic_actions'][0]['slot_guards'][0]['value']=guard;cc=compile_ruleset_for_execution(ruleset_from_dict(rule));enc=SparsePositionEncoder(cc);af=[];counts=[]
  for flag in (0,1):
   pp=replace(pos,ruleset_fingerprint=cc.ruleset_fingerprint,aux_state=((pos.aux_state[0][0],flag),));af.append(enc.dense(pp));aa=[action_to_dict(a)for a in iter_semantic_public_actions(semantic_engine_for(cc),pp)];counts.append(sum(a.get('pattern_id','').startswith('sem_00_')for a in aa))
  features.append(af);arms.append(dict(guard=guard,fingerprint=cc.ruleset_fingerprint,Pdrop_counts=counts))
 rows.append(dict(seed=r['seed'],policies=r['policies'],ply=e['ply'],arms=arms,numeric_sparse_equal_by_flag=[bool(np.array_equal(features[0][j],features[1][j]))for j in (0,1)],fingerprints_distinct=arms[0]['fingerprint']!=arms[1]['fingerprint']))
write_record(p/'slot-rule-conditioning.json',dict(scope=__doc__,rows=rows,complete=True));print(rows)
