"""Fixed dormant declaration diagnostic on first exposed rule2122.
Add unused nonpromotable X clone ZD with no initial stock/drop mask/semantic
targets or spawn source. No claim of universal equivalence: compare all legal
physical successors at the16 original reachable route prefixes, price raw curves
and normalization. Selection fixed before observation. No training/default.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time
sys.path[:0]=[str(Path.cwd())]
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;assert not (p/'dormant.json').exists()
case=json.loads(Path('.local_agent/return-signal-20261010/signal-declaration.json').read_bytes())['rules'][0]
rules=ruleset_from_dict(case['rules']);pt=next(t for t in rules.piece_types if t.type_id=='X')
clone=replace(pt,type_id='ZD',name='Dormant clone',is_promotable=False,promotion_target_ids=())
changed=replace(rules,piece_types=rules.piece_types+(clone,),drop_allowed={**rules.drop_allowed,'ZD':((False,)*64,)*2})
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
start=time.perf_counter();cs=[compile_ruleset_for_execution(r) for r in (rules,changed)]
profiles=[build_semantic_opportunity_profile(c,cfg) for c in cs];sessions=[GameSession(c) for c in cs];evs=[Evaluator(c,p[0],cfg) for c,p in zip(cs,profiles)]
rows=[]
for i in range(len(case['route'])+1):
 actions=[s.legal_actions() for s in sessions]
 def physical(s,a):
  child=GameSession(s.compiled);child._state=s.state;child.submit(a)
  return json.dumps(record_value(child.state.position),sort_keys=True)
 sets=[sorted(physical(s,a) for a in aa) for s,aa in zip(sessions,actions)]
 assert sets[0]==sets[1]
 rows.append(dict(prefix=i,legal_counts=list(map(len,actions)),physical_successors_equal=True,scores=[e.evaluate(s.state) for e,s in zip(evs,sessions)]))
 if i<len(case['route']):
  for s in sessions:s.submit(action_from_dict(case['route'][i]))
write_record(p/'dormant.json',dict(scope=__doc__,rules=ruleset_to_dict(changed),profiles=[record_value(x[0]) for x in profiles],scopes=[x[1] for x in profiles],rows=rows,seconds=time.perf_counter()-start))
print('reachable prefixes',len(rows),'scores',[(r['prefix'],r['scores']) for r in rows])
