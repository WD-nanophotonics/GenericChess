"""Predeclared scope trace: all four fixed opening4 roots, all Pdrop/X transform
actions available there; retain empty sets too. Compare actual inventory effects
and static score deltas with included/excluded profile pattern provenance.
No label fit or utility claim; operational slot semantics remain authoritative.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd())]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;assert not (p/'scope-trace.json').exists()
d=json.loads(Path('.local_agent/return-signal-20261010/signal-declaration.json').read_bytes())
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
rows=[];start=time.perf_counter()
for case in d['rules']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 profile,scope=build_semantic_opportunity_profile(c,cfg);ev=Evaluator(c,profile,cfg)
 initial=s.state;actions=s.legal_actions();special=[]
 for a in actions:
  raw=action_to_dict(a)
  if not raw.get('pattern_id','').startswith(('sem_00_','sem_01_')):continue
  child=GameSession(c);child._state=initial;child.submit(a)
  special.append(dict(action=raw,before=record_value(initial),after=record_value(child.state),parent_score=ev.evaluate(initial),child_score_parent_frame=-ev.evaluate(child.state)))
 rows.append(dict(seed=case['seed'],profile=record_value(profile),scope=scope,legal_count=len(actions),special=special,patterns=record_value([pat for pat in c.ir.patterns if pat.pattern_id.startswith(('sem_00_','sem_01_'))])))
write_record(p/'scope-trace.json',dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start))
print([(r['seed'],r['legal_count'],len(r['special'])) for r in rows])
