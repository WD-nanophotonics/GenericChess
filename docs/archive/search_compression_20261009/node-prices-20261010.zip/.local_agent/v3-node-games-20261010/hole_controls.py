"""Fixed-root control of all3observed immediate mate holes, selected posthoc.
Same actual parent/history and cold D2/512/10sec/q0 Unit ordering for Unit/v3.
Enumerate actual opponent replies of each chosen child, including no witnesses.
Question: would v3 at the same state avoid a documented Unit immediate loss,
or do different trajectories explain the absence of v3 holes? This is a
dependent exposed diagnostic, not a prospective gain estimate or WDL claim.
"""
from pathlib import Path
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;assert not (p/'hole-controls.json').exists()
holes=[r for r in json.loads((p/'mate-audit.json').read_bytes())['rows'] if r['witnesses']];assert len(holes)==3
base=json.loads(Path('.local_agent/return-signal-20261010/node-repeats.json').read_bytes())['rows']
games=[r for r in base if r['repeat']==0]+json.loads((p/'games.json').read_bytes())['rows']
cases={r['seed']:r for r in json.loads(Path('.local_agent/return-signal-20261010/signal-declaration.json').read_bytes())['rules']}
write_record(p/'hole-control-declaration.json',dict(scope=__doc__,roots=[dict(seed=r['seed'],policies=r['policies'],ply=r['ply']) for r in holes],limits=dict(depth=2,nodes=512,seconds=10,q=0,qhard=8),no_old_record_extension=True))
rows=[];start=time.perf_counter();cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for h in holes:
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 case=cases[h['seed']];game=next(r for r in games if r['seed']==h['seed'] and r['policies']==h['policies']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
 for a in case['route'][:4]:s.submit(action_from_dict(a))
 for step in game['steps'][:h['ply']]:s.submit(action_from_dict(step['action']))
 profile,scope=build_semantic_opportunity_profile(c,cfg)
 class Leaf(UnitEvaluator):
  def __init__(self,kind):self.kind=kind;self.ev=Evaluator(c,profile,cfg)
  def evaluate(self,state):return super().evaluate(state) if self.kind=='unit' else self.ev.evaluate(state)
 arms=[]
 for kind in ('unit','v3'):
  before=s.state;player=AlphaBetaPlayer(c,evaluator_override=Leaf(kind),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter()
  dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,dec);assert s.state==before
  if kind=='unit':assert action_to_dict(dec.action)==h['selected_action']
  child=apply_action(before,dec.action,c);witnesses=[];replies=0
  if not child.terminal_status.is_terminal:
   for a in legal_actions(child,c):
    replies+=1;t=apply_action(child,a,c)
    if t.terminal_status.is_terminal and t.terminal_status.winner==1-h['mover']:witnesses.append(dict(action=action_to_dict(a),terminal=record_value(t.terminal_status)))
  arms.append(dict(policy=kind,decision=record_value(dec),selected_child=record_value(child),replies=replies,witnesses=witnesses,seconds=time.perf_counter()-tick))
 rows.append(dict(seed=h['seed'],source_policies=h['policies'],source_ply=h['ply'],parent=record_value(before),arms=arms));write_record(p/'hole-controls.json',dict(scope=__doc__,rows=rows,complete=False))
write_record(p/'hole-controls.json',dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
print([(r['seed'],r['source_ply'],[(a['policy'],a['decision']['completed_depth'],len(a['witnesses'])) for a in r['arms']]) for r in rows])
