"""All-child preference control on17fixed prefixes, no search-budget extension.
Question: does dormant-type normalization merely rescale, or change ties/orders?
Enumerate physical successor multiset including terminal status, all pairs;
compare original/dormant/fixed-map static scores in the same parent frame.
No utility gain, universal equivalence or independent validation claim.
"""
from pathlib import Path
from dataclasses import replace
import json,sys,time
sys.path.insert(0,str(Path.cwd()))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;assert not (p/'dormant-preferences.json').exists()
d=json.loads((p/'dormant.json').read_bytes());case=json.loads(Path('.local_agent/return-signal-20261010/signal-declaration.json').read_bytes())['rules'][0]
cs=[compile_ruleset_for_execution(ruleset_from_dict(r)) for r in (case['rules'],d['rules'])];ss=[GameSession(c) for c in cs]
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
profiles=[build_semantic_opportunity_profile(c,cfg)[0] for c in cs]
fixed=replace(profiles[1],board_value_by_type={**profiles[1].board_value_by_type,**profiles[0].board_value_by_type},hand_value_by_base_type={**profiles[1].hand_value_by_base_type,**profiles[0].hand_value_by_base_type})
evs=[Evaluator(cs[0],profiles[0],cfg),Evaluator(cs[1],profiles[1],cfg),Evaluator(cs[1],fixed,cfg)]
def child(s,a):
 t=GameSession(s.compiled);t._state=s.state;t.submit(a);return t
def physical(t):
 raw=record_value(t.state.position);raw.pop('ruleset_fingerprint');return json.dumps(dict(position=raw,terminal=record_value(t.state.terminal_status)),sort_keys=True)
def score(ev,t,side):return ev.evaluate(t.state)*(1 if t.state.position.side_to_move==side else -1)
def sign(x):return (x>0)-(x<0)
rows=[];start=time.perf_counter()
for prefix in range(len(case['route'])+1):
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 side=ss[0].state.position.side_to_move
 children=[[child(s,a) for a in s.legal_actions()] for s in ss]
 ordered=[sorted(tt,key=physical) for tt in children];assert [physical(t) for t in ordered[0]]==[physical(t) for t in ordered[1]]
 scores=[[score(evs[0],a,side),score(evs[1],b,side),score(evs[2],b,side)] for a,b in zip(*ordered)]
 assert all(v[0]==v[2] for v in scores)
 pairs=0;inversions=0;tie_created=0;tie_broken=0;examples=[]
 for i,a in enumerate(scores):
  for j,b in enumerate(scores[:i]):
   pairs+=1;x=sign(a[0]-b[0]);y=sign(a[1]-b[1])
   if x!=y:
    inversions+=bool(x*y==-1);tie_created+=bool(x and not y);tie_broken+=bool(y and not x)
    if len(examples)<4:examples.append(dict(i=i,j=j,scores=[a,b],orders=[x,y]))
 rows.append(dict(prefix=prefix,legal_children=len(scores),scores=scores,pairs=pairs,inversions=inversions,tie_created=tie_created,tie_broken=tie_broken,examples=examples,fixed_maps_restore=True))
 if prefix<len(case['route']):
  a=action_from_dict(case['route'][prefix]);target=physical(child(ss[0],a));matches=[b for b in ss[1].legal_actions() if physical(child(ss[1],b))==target];assert matches
  ss[0].submit(a);ss[1].submit(matches[0])
write_record(p/'dormant-preferences.json',dict(scope=__doc__,rows=rows,seconds=time.perf_counter()-start,complete=True,totals={k:sum(r[k] for r in rows) for k in ('legal_children','pairs','inversions','tie_created','tie_broken')}))
print({k:sum(r[k] for r in rows) for k in ('legal_children','pairs','inversions','tie_created','tie_broken')})
