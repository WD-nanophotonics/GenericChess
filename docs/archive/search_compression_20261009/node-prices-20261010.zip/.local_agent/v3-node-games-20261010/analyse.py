"""All eight crossed cells against first published Unit repeat, no strength claim."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()))
from collections import Counter
from scripts.research_record import write_record
p=Path(__file__).parent
d=json.loads((p/'games.json').read_bytes());assert d['complete'] and len(d['rows'])==8
old=json.loads(Path('.local_agent/return-signal-20261010/node-repeats.json').read_bytes());base={r['seed']:r for r in old['rows'] if r['repeat']==0}
def label(r):
 t=r['terminal'];return 'ongoing96' if t['status']=='ongoing' else 'draw' if t['winner'] is None else 'owner0_win' if t['winner']==0 else 'owner0_loss'
rows=[]
for r in d['rows']:
 b=base[r['seed']];assert r['initial']==b['initial']
 div=next((i for i,(x,y) in enumerate(zip(b['steps'],r['steps'])) if x['action']!=y['action']),None)
 steps=r['steps'];v3_owner=r['policies'].index('v3')
 rows.append(dict(seed=r['seed'],policies=r['policies'],v3_owner=v3_owner,baseline_event=label(b),event=label(r),winner=r['terminal']['winner'],plies=len(steps),baseline_plies=len(b['steps']),first_divergence=div,seconds=r['seconds'],nodes=sum(s['decision']['nodes'] for s in steps),evaluation_calls=sum(s['decision']['evaluation_calls'] for s in steps),depths=dict(Counter(s['decision']['completed_depth'] for s in steps)),stops=dict(Counter(s['decision']['termination_reason'] for s in steps))))
out=dict(scope=__doc__,rows=rows,seconds=d['seconds'],plies=sum(r['plies'] for r in rows),event_changes=sum(r['baseline_event']!=r['event'] for r in rows),action_divergences=sum(r['first_divergence'] is not None for r in rows),limits='Four exposed rules/two intervention sides; dependent baselines, capped depths, no Elo or causal price gain from event changes. TT cold; Unit ordering; wall headroom checked by actual stop reasons.')
write_record(p/'analysis.json',out);print(json.dumps(out,indent=2))
