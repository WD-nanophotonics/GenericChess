"""Predeclared51call control at all17prefixes of exposed2122 route.
Original v3, dormant v3, dormant compilation with original price maps;
Unit ordering, cold TT D2/512/10sec/q0/hard8. No budget extension/games/fit.
Compare chosen physical successor/terminal and actual work; root legal successor
multisets already agree. Fixed-price arm separates table normalization from
compiled IDs/order effects. No universal rule-equivalence or price-utility claim.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time
sys.path[:0]=[str(Path.cwd()),str(Path('tests')),str(Path('tests/product'))]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from test_rectangular_search_override import UnitEvaluator
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;assert not (p/'dormant-callers.json').exists()
d=json.loads((p/'dormant.json').read_bytes());case=json.loads(Path('.local_agent/return-signal-20261010/signal-declaration.json').read_bytes())['rules'][0]
cs=[compile_ruleset_for_execution(ruleset_from_dict(r)) for r in (case['rules'],d['rules'])];ss=[GameSession(c) for c in cs]
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
profiles=[build_semantic_opportunity_profile(c,cfg)[0] for c in cs]
fixed=replace(profiles[1],board_value_by_type={**profiles[1].board_value_by_type,**profiles[0].board_value_by_type},hand_value_by_base_type={**profiles[1].hand_value_by_base_type,**profiles[0].hand_value_by_base_type})
class Leaf(UnitEvaluator):
 def __init__(self,c,profile):self.ev=Evaluator(c,profile,cfg)
 def evaluate(self,state):return self.ev.evaluate(state)
def physical(s,a):
 child=GameSession(s.compiled);child._state=s.state;child.submit(a)
 raw=record_value(child.state.position);raw.pop('ruleset_fingerprint')
 return dict(position=raw,terminal=record_value(child.state.terminal_status))
write_record(p/'dormant-caller-declaration.json',dict(scope=__doc__,arms=['original','dormant','fixed_maps'],limits=dict(depth=2,nodes=512,seconds=10,q=0,qhard=8)))
rows=[];start=time.perf_counter()
for prefix in range(len(case['route'])+1):
 assert not json.loads(Path('.local_agent/rollout.json').read_bytes())['user_paused']
 arms=[]
 for name,s,profile in [('original',ss[0],profiles[0]),('dormant',ss[1],profiles[1]),('fixed_maps',ss[1],fixed)]:
  player=AlphaBetaPlayer(s.compiled,evaluator_override=Leaf(s.compiled,profile),use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));tick=time.perf_counter();before=s.state
  dec=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=512,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=8));validate_pv(s,dec);assert s.state==before
  arms.append(dict(arm=name,decision=record_value(dec),chosen=physical(s,dec.action),seconds=time.perf_counter()-tick))
 rows.append(dict(prefix=prefix,arms=arms));write_record(p/'dormant-callers.json',dict(scope=__doc__,rows=rows,complete=False))
 if prefix<len(case['route']):
  chosen=action_from_dict(case['route'][prefix]);target=physical(ss[0],chosen);matches=[a for a in ss[1].legal_actions() if physical(ss[1],a)==target];assert matches
  ss[0].submit(chosen);ss[1].submit(matches[0])
write_record(p/'dormant-callers.json',dict(scope=__doc__,rows=rows,complete=True,seconds=time.perf_counter()-start))
print('calls',len(rows)*3,'table choice changes',sum(r['arms'][0]['chosen']!=r['arms'][1]['chosen'] for r in rows),'fixed-map changes',sum(r['arms'][0]['chosen']!=r['arms'][2]['chosen'] for r in rows))
