from pathlib import Path
import sys,json,hashlib
from unittest.mock import patch
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/validated-binding-20261011';ns={};exec(compile((B/'probe.py').read_text(),str(B/'probe.py'),'exec'),ns)
nl=ns['nl'];ValidatedProvider=ns['ValidatedProvider'];CASES=ns['CASES'];prep=ns['prep'];CoreBoard=ns['CoreBoard'];write=ns['write_record'];outcome=ns['outcome']
r=dict(complete=False,controls=[],scope='Synthetic allocator fault after validation; non-strict automatic fallback differs. No claim of real MemoryError frequency. Public ordinary provider unchanged.')
for name in ('chess-middle','shogi-drop'):
 case=next(c for c in CASES if c['id']==name);c,_=prep(case)
 for arm in ('eager','validated'):
  p=(ValidatedProvider if arm=='validated' else nl.NativeSemanticLegalityProvider).try_create(c,strict=False);assert p;b=CoreBoard(case,c,provider=p)
  def fail(*args,**kwargs):raise MemoryError('synthetic-binding-allocation')
  with patch.object(p.engine,'_make_binding',side_effect=fail):
   actions=b.actions();error=outcome(lambda:b.push(actions[0][1]))
  if error is None:b.pop()
  assert b.restored()
  if arm=='eager':assert b.runtime.legal_provider_fallbacks==1 and error is None
  else:assert b.runtime.legal_provider_fallbacks==0 and error==['MemoryError','synthetic-binding-allocation']
  b.push(actions[0][1]);b.pop();assert b.restored()
  r['controls'].append(dict(root=name,arm=arm,error=error,fallbacks=b.runtime.legal_provider_fallbacks,operational_failures=b.runtime.legal_provider_operational_failures,restored=True,retry=True))
r.update(complete=True,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write(B/'runtime-controls.json',r);print(json.dumps(r,indent=2))
