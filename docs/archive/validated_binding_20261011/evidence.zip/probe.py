from pathlib import Path
import ast,inspect,textwrap,sys,time,hashlib,json
from dataclasses import replace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta import native_legality as nl
from generic_chess.core.semantic_executor import SemanticEngine
from scripts.search_backend_comparison import CASES,CoreBoard,supported_search
from scripts.reserve_refresh_diagnostic import stopped
from scripts.research_record import write_record
B=ROOT/'.local_agent/validated-binding-20261011'
counts=dict(validated=0,forced=0)
original=textwrap.dedent(inspect.getsource(SemanticEngine._make_binding_from_action))
tree=ast.parse(original);tree.body[0].name='_validated_args'
class Split(ast.NodeTransformer):
 def visit_Call(self,node):
  self.generic_visit(node)
  if isinstance(node.func,ast.Attribute) and node.func.attr=='_make_binding':
   node.func=ast.Name(id='binding_args',ctx=ast.Load())
  return node
tree=Split().visit(tree);ast.fix_missing_locations(tree)
validated_source=ast.unparse(tree)
def binding_args(*args):return args
ns=dict(SemanticEngine._make_binding_from_action.__globals__,binding_args=binding_args)
exec(compile(tree,'<validated-binding-args>','exec'),ns)
validate=ns['_validated_args']
class ValidatedPair:
 __slots__=('engine','action','args','checkpoint','value')
 def __init__(self,engine,action,args,checkpoint):
  self.engine=engine;self.action=action;self.args=args;self.checkpoint=checkpoint;self.value=None;counts['validated']+=1
 def __iter__(self):
  if self.value is None:
   if self.checkpoint:self.checkpoint()
   self.value=(self.action,self.engine._make_binding(*self.args));counts['forced']+=1
   if self.checkpoint:self.checkpoint()
  return iter(self.value)
source=textwrap.dedent(inspect.getsource(nl.NativeSemanticLegalityProvider.__call__))
anchor="        binding = self.engine._make_binding_from_action(\n            position, semantic_action, pattern\n        )"
assert source.count(anchor)==1
source=source.replace(anchor,'        args = validate(self.engine, position, semantic_action, pattern)\n        lazy = ValidatedPair(self.engine,semantic_action,args,checkpoint)').replace('pairs.append((public, (semantic_action, binding)))','pairs.append((public, lazy))')
ns2=dict(nl.__dict__,validate=validate,ValidatedPair=ValidatedPair);exec(compile(source,'<early-validated-provider>','exec'),ns2)
class ValidatedProvider(nl.NativeSemanticLegalityProvider):__call__=ns2['__call__']
def prep(case):
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
 return c,CoreBoard(case,c)
def outcome(fn):
 try:fn();return None
 except Exception as e:return [type(e).__name__,str(e)]
def main():
 start=time.perf_counter();r=dict(complete=False,declaration=(B/'plan.md').read_text(),validation_source=validated_source,provider_source=source,roots=[],errors=[],rows=[])
 for case in CASES:
  stopped();assert time.perf_counter()-start<120
  c,b=prep(case);p=nl.NativeSemanticLegalityProvider.try_create(c,strict=True);q=ValidatedProvider.try_create(c,strict=True);assert p and q
  eager=p(b.initial.position,b.initial.ply_count);lazy=q(b.initial.position,b.initial.ply_count)
  assert len(eager)==len(lazy)
  for (public,(a,eb)),(public2,lp) in zip(eager,lazy):
   assert public==public2 and tuple(lp)==(a,eb)
   b.push(public);b.pop();assert b.restored()
   pattern=p.pattern_by_id[a.pattern_id]
   for label,bad in [('geometry-none',replace(a,geometry_id=None)),('geometry-unknown',replace(a,geometry_id='INVALID')),('actor-none',replace(a,actor_type=None)),('actor-mismatch',replace(a,actor_type='INVALID')),('target-unreachable',replace(a,target=1000)),('source-empty',replace(a,source=next((i for i,x in enumerate(b.initial.position.board) if x is None),a.source)))]:
    x=outcome(lambda:p.engine._make_binding_from_action(b.initial.position,bad,pattern));y=outcome(lambda:validate(q.engine,b.initial.position,bad,pattern))
    assert x==y,(case['id'],label,x,y)
    r['errors'].append(dict(root=case['id'],control=label,error=x))
  r['roots'].append(dict(root=case['id'],actions=len(eager),restored=b.restored()))
  write_record(B/'probe.json',r)
 for name in ('chess-middle','shogi-drop'):
  case=next(c for c in CASES if c['id']==name);c,b=prep(case)
  for arm in ('eager','validated','validated','eager'):
   stopped();assert time.perf_counter()-start<120
   p=(ValidatedProvider if arm=='validated' else nl.NativeSemanticLegalityProvider).try_create(c,strict=True);assert p;p._metrics_local.public_cache={};counts.update(validated=0,forced=0)
   b=CoreBoard(case,c);v=supported_search(b,2,30,100000,provider=p);assert b.restored();r['rows'].append(dict(root=name,arm=arm,counts=dict(counts),**v));write_record(B/'probe.json',r);print(name,arm,v['wall_seconds'],dict(counts),flush=True)
 r.update(complete=True,elapsed_seconds=time.perf_counter()-start,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(B/'probe.json',r)
if __name__=='__main__':main()
