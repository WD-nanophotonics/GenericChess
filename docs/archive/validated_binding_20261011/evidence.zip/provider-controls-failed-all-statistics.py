from pathlib import Path
import sys,hashlib,json,inspect
from dataclasses import replace
from unittest.mock import patch
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));B=ROOT/'.local_agent/validated-binding-20261011'
ns={};exec(compile((B/'probe.py').read_text(),str(B/'probe.py'),'exec'),ns)
nl=ns['nl'];ValidatedProvider=ns['ValidatedProvider'];CASES=ns['CASES'];prep=ns['prep'];outcome=ns['outcome'];validate=ns['validate'];write_record=ns['write_record']
from generic_chess.native.semantic import pack_position,transient_legal_actions
r=dict(complete=False,scope='Provider-stage packed-output controls. Original decode/call path, early predicate checks; synthetic bad native returns. Not a claim of real malformed DLL output.',controls=[],allocation=[],memory=[],signature_checks=[])
for name in ('chess-middle','shogi-drop'):
 case=next(c for c in CASES if c['id']==name);c,b=prep(case);e=nl.NativeSemanticLegalityProvider.try_create(c,strict=True);v=ValidatedProvider.try_create(c,strict=True);assert e and v
 raw=tuple(int(x) for x in transient_legal_actions(e.native_rules,pack_position(e.native_rules,e._state_only_payload(b.initial.position,b.initial.ply_count))))
 controls=[('invalid-kind',(raw[0]&~(15<<32))|(1<<32)),('invalid-target',(raw[0]&~255)|255),('invalid-pattern',(raw[0]&~(255<<36))|(255<<36)),('invalid-geometry',(raw[0]&~(4095<<44))|(4095<<44)),('invalid-actor',(raw[0]&~(255<<56))|(255<<56)),('invalid-base',(raw[0]&~(255<<24))|(255<<24)),('invalid-promotion',(raw[0]&~(255<<16))|(254<<16))]
 # Structural constraints in binding beyond packed syntax checks.
 a=e._decode_action(raw[0],b.initial.position);pat=e.pattern_by_id[a.pattern_id]
 candidates=[]
 for gid in e.geometry_ids:
  ix=e.geometry_ids.index(gid);packed=(raw[0]&~(4095<<44))|(ix<<44)
  try:decoded=e._decode_action(packed,b.initial.position)
  except Exception:continue
  err=outcome(lambda:e.engine._make_binding_from_action(b.initial.position,decoded,e.pattern_by_id[decoded.pattern_id]))
  if err is not None:candidates.append((gid,packed,err))
 for i,(gid,packed,err) in enumerate(candidates[:4]):controls.append(('binding-rule-'+str(i),packed))
 for label,bad in controls:
  # Good output first ensures an unsearched later malformed row still fails before returning.
  with patch('generic_chess.native.semantic.transient_legal_actions',return_value=(raw[0],bad)):
   x=outcome(lambda:e(b.initial.position,b.initial.ply_count));y=outcome(lambda:v(b.initial.position,b.initial.ply_count))
  assert x is not None and x==y,(name,label,x,y)
  r['controls'].append(dict(root=name,control=label,eager_error=x,validated_error=y,stage='provider-call'))
 # A synthetic allocator failure intentionally remains a different stage.
 def fail(*args,**kwargs):raise MemoryError('synthetic-binding-allocation')
 with patch.object(e.engine,'_make_binding',side_effect=fail),patch.object(v.engine,'_make_binding',side_effect=fail):
  x=outcome(lambda:e(b.initial.position,b.initial.ply_count));pairs=v(b.initial.position,b.initial.ply_count);y=outcome(lambda:tuple(pairs[0][1]));assert x==y==['MemoryError','synthetic-binding-allocation']
  r['allocation'].append(dict(root=name,error=x,eager_stage='provider-call',validated_stage='materialization',transparent_exception_contract=False))
 eager=e(b.initial.position,b.initial.ply_count);pairs=v(b.initial.position,b.initial.ply_count)
 def gross(pairs,deferred):
  total=sys.getsizeof(pairs)
  for public,pair in pairs:
   total+=sys.getsizeof((public,pair))+sys.getsizeof(pair)
   if deferred:
    total+=sys.getsizeof(pair.args)
    if pair.value is not None:total+=sys.getsizeof(pair.value)+sys.getsizeof(pair.value[1])
   else:total+=sys.getsizeof(pair[1])
  return total
 before=gross(pairs,True)
 for public,pair in pairs:tuple(pair)
 r['memory'].append(dict(root=name,actions=len(eager),eager_gross=gross(eager,False),validated_unforced_gross=before,validated_forced_gross=gross(pairs,True),scope='owned containers only; borrowed parent/pattern/path/semantic action/engine/checkpoint excluded; not RSS; args retains entire immutable position'))
for root in ('chess-middle','shogi-drop'):
 rows=[x for x in json.loads((B/'probe.json').read_text())['rows'] if x['root']==root]
 sig=lambda x:json.dumps({k:x[k] for k in ('move','score','pv','reason','statistics','node_definition')},sort_keys=True)
 assert len(set(sig(x) for x in rows))==1
 r['signature_checks'].append(dict(root=root,cells=len(rows),equal=True))
r.update(complete=True,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());write_record(B/'provider-controls.json',r);print(json.dumps(r,indent=2))
