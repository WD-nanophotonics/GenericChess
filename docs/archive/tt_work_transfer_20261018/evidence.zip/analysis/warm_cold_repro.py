from pathlib import Path
import json,sys,time
from copy import copy
R=Path.cwd();sys.path.insert(0,str(R));D=R/'.local_agent/tt-work-transfer-20261018'
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.ai.limits import SearchLimits

def decode(a):
 k=dict(a);k['to_square']=Square(**k['to_square'])
 if 'from_square'in k:k['from_square']=Square(**k['from_square']);return SemanticBoardMove(**k)
 return SemanticDropMove(**k)
models={r['checkpoint_id']:r['checkpoint']for r in json.loads((D/'models.json').read_bytes())['rows']};queries=[json.loads(l)for l in (D/'queries.jsonl').read_text(encoding='utf8').splitlines()];roots=json.loads((D/'roots.json').read_bytes())['rows'];mismatches=json.loads((D/'reader-result.json').read_bytes())['score_leaf_mismatches'];rows=[];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(json.loads((D/'rule-411008.json').read_bytes())));n=compile_native_semantic_rules(c)
for mismatch in mismatches:
 slot=mismatch['slot'];q=[q for q in queries if q['slot']==slot];cp=LearnableMaterialCheckpoint.from_dict(models[q[0]['checkpoint_id']]);root=GameSession.replay(c,deserialize_game_record(json.dumps(next(r['record']for r in roots if r['rule']==411008 and r['family']==451002))))
 parent=copy(root)
 for item in q[:2]:parent.submit(decode(item['committed']))
 for mode,mb,exact,warm in [('warm4',4,False,True),('cold4',4,False,False),('cold0',0,False,False),('warm4_exact',4,True,True)]:
  for name in ('rollout','advisor','slack'):
   flags=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
  engine=SemanticSearchEngine(c,n,checkpoint=cp,tt_megabytes=mb);limits=SearchLimits(max_depth=8,max_nodes=131072,max_time_seconds=2.,quiescence_max_depth=0);seed=None
  if warm:
   seed=engine.search(root,limits,root_window_pruning=exact)
  result=engine.search(parent,limits,root_window_pruning=exact);leaf=copy(parent)
  for a in result.decision_line:
   if isinstance(a,str):leaf.declare(a)
   else:leaf.submit(a)
  if leaf.result.status.value=='ongoing':
   value=sum((1 if x.owner==0 else-1)*round(cp.board_weights.get(x.current_type_id,0)*256)for x in leaf.state.position.board if x is not None)+sum((leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t))*round(w*256)for t,w in cp.hand_weights.items())
  else:value=0 if leaf.result.winner is None else (100000000-len(result.decision_line))*(1 if leaf.result.winner==0 else-1)
  rows.append(dict(slot=slot,mode=mode,score=result.score,pv_white_value=value,pv=record_value(result.decision_line),depth=result.completed_depth,nodes=result.nodes,reason=result.termination_reason,tt_hits=result.tt_hits,tt_cutoffs=result.tt_cutoffs,seed_score=None if seed is None else seed.score,seed_depth=None if seed is None else seed.completed_depth,root_window_pruning=exact));print({k:v for k,v in rows[-1].items()if k!='pv'},flush=True)
write_json(D/'warm-cold-repro-result.json',dict(status='COMPLETE',rows=rows,scope='Posthoc eight new bounded diagnostic parent queries plus four cache-seeding queries; no fitness rerun. Public API explicitly does not promise literalPVleafscore equality in cached selective mode.'))
