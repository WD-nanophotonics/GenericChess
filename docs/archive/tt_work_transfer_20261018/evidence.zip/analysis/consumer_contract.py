"""Independent recorded-request/model/work accounting against the frozen plan."""
from pathlib import Path
from collections import Counter
import json,sys,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/tt-work-transfer-20261018';p=json.loads((D/'plan.json').read_bytes());done=json.loads((D/'result.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['slots'];models={(x['rule'],x['label']):x for x in json.loads((D/'models.json').read_bytes())['rows']};games={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};counts=Counter();totals=Counter();started=time.perf_counter()
for line in(D/'queries.jsonl').open(encoding='utf-8'):
 q=json.loads(line);rule,family,label,owner,foe=slots[q['slot']];candidate=q['actor']==owner;assert candidate==q['candidate_turn'];expected=p['budgets'][label.split('@')[1]]if candidate else dict(depth=2,nodes=8192,seconds=2.)
 assert (q['requested_depth'],q['requested_nodes'],q['requested_seconds'])==(expected['depth'],expected['nodes'],expected['seconds'])
 m=models[rule,label]if candidate else models[rule,'unit'if foe=='uniform'else'foe_random99031'];assert q['checkpoint_id']==m['checkpoint_id'];assert 0<=q['completed_depth']<=expected['depth'];assert q['nodes']<=expected['nodes'];assert q['caller_seconds']>=0 and q['kernel_seconds']>=0
 if 'tt_modes'in p:assert q['tt_megabytes']==(p['tt_modes'][label.split('@')[1]]if candidate else 0)
 counts[q['slot']]+=1;totals['nodes']+=q['nodes'];totals['queries']+=1;totals['candidate_queries']+=candidate;totals['fixedfoe_queries']+=not candidate
for slot,g in games.items():assert counts[slot]==g['queries'];assert g['checkpoint_id']==models[g['rule'],g['label']]['checkpoint_id']
assert totals['nodes']==done['nodes']and totals['queries']==done['queries']
q=dict(status='PASS_ALL_RECORDED_REQUESTS_MODEL_BINDINGS_AND_WORK_SUMS',counts=dict(totals),slots=len(games),slots_with_queries=len(counts),source_plan_parameters_exact=True,actual_foe_unchanged=True,seconds=time.perf_counter()-started,scope='Independentdata comparison of requestedlimits/candidate-role/checkpointIDs/nodesums versusfrozenplan+modelbank. Native executesrequest perexecutedproducer; this isnot proof ofin-kernelcounterimplementation/equalwork or genericTTsafety. ReturnedTTprobes/hits areNOTlogged; absentstats notzero. ExistingseparateCorePVreaderownsfullstate/valuechecks.')
write_json(D/'consumer-contract-result.json',q);print(q,flush=True)
