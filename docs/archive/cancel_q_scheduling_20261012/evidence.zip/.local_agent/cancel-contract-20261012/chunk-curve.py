"""Predeclared chunk-size delivery/cancellation quantum comparison, Core q4."""
import sys,runpy,json,time,inspect,textwrap
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/aux-quiet-20261012/filtered-transfer-producer.py'))
p=m['p'];ns=m['ns'];sm=m['search_module'];Runtime=m['SearchPathRuntime'];Player=m['AlphaBetaPlayer'];Limits=m['SearchLimits'];Tuning=m['SearchTuning'];Probe=m['QuietActionProbe'];write=m['write_record'];record=m['record_value'];legal=m['legal'];order=m['order'];Batch=m['BatchLegal'];Ev=m['CountedSemanticEvaluator']
from generic_chess.rules.schema import ruleset_from_dict
c=m['compile_ruleset_for_execution'](ruleset_from_dict(json.loads((ROOT/'.local_agent/aux-quiet-20261012/active-mixed-premise.json').read_text())[0]['rules']))
sample=json.loads((ROOT/'.local_agent/aux-quiet-20261012/active-mixed-premise.json').read_text())[0];assert sample['seed']==1091
s=p.GameSession(c)
for _ in range(4):
 aa=s.legal_actions();aux=[a for a in aa if 'promotion_grants_one_turn_right' in a.pattern_id];s.submit(aux[0] if aux else sorted(aa,key=repr)[0])
assert record(s.state)==sample['state'] and record(s._search_witnesses)==sample['witnesses']
ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
def run(out):
 out.mkdir(parents=True,exist_ok=True);assert not (out/'declaration.json').exists()
 write(out/'declaration.json',dict(question='Does batch32 or batch1 improve actual full q4 delivery enough to justify their different uncancellable work quantum versus batch8?',root=1091,chunk_sizes=[1,8,32],budgets=[1,16,64,256],orders=['1,8,32','32,8,1'],calls=24,max_depth=12,max_nodes=1000000,q=4,hardq=8,pvs=True,quiet='existing full mechanical board+drop guards',decision='Compare completed depth/q, actual node counts, restored root and observed maximum Native chunk time. No threshold-tuning or new kernel; fixed complete D2 later checks semantic parity.',expected_search_seconds=2022,expected_total_minutes=36,scope='One exposed active aux root; same lexical full logical collection, native semantic evaluator and Core q/history authority, research-only cache, ordinary concurrent load; TT per new player and original caps unchanged. Timed primitive wrapper adds common call overhead; maxima not worst-case guarantee.'))
 write(out/'sample.json',sample)
 original=sm._quiescence_runtime;src=textwrap.dedent(inspect.getsource(original)).replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)');src=src.replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
 oldsubset=ns.transient_legal_subset;oldattach=Runtime.attach_stats;rows=[]
 try:
  for seconds in [1,16,64,256]:
   for repeat,chunks in enumerate([[1,8,32],[32,8,1]]):
    for size in chunks:
     p.rr.stopped();counts=Counter();legal.__globals__['counts']=counts;Batch.__iter__.__globals__['BATCH_SIZE']=size;probe=Probe(shadow=False);namespace=dict(sm.__dict__,lazy_legal=legal,lazy_order=order,quiet_drop_probe=probe);exec(compile(src,'<research-chunk-curve>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];rtrows=[];times=dict(calls=0,total=0.0,max=0.0,max_candidates=0)
     def subset(*args,**kwargs):
      t=time.perf_counter()
      try:return oldsubset(*args,**kwargs)
      finally:
       elapsed=time.perf_counter()-t;times['calls']+=1;times['total']+=elapsed;times['max']=max(times['max'],elapsed);times['max_candidates']=max(times['max_candidates'],len(args[2]))
     def attach(rt,stats):
      v=oldattach(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return v
     ns.transient_legal_subset=subset;Runtime.attach_stats=attach
     try:
      ev=Ev(c,profile,ec,backend='native');player=Player(c,evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=Tuning(use_pvs=True));t=time.perf_counter();value=player.choose_action(s,Limits(max_depth=12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
      for rt,saved in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==saved
      rows.append(dict(seconds_budget=seconds,order=repeat,chunk=size,seconds=elapsed,decision=record(value),counts=dict(counts),probe=dict(probe.counts),quantum=times,root_restored=True,actual_legality=dict(fallbacks=rtrows[0][0].legal_provider_fallbacks,failures=rtrows[0][0].legal_provider_operational_failures),availability=player.native_legality_provider.availability_metrics))
      write(out/'result.json',dict(complete=False,rows=rows));print(seconds,repeat,size,round(elapsed,3),value.completed_depth,value.score,value.nodes,value.qnodes,round(times['max'],6),flush=True)
     finally:Runtime.attach_stats=oldattach;ns.transient_legal_subset=oldsubset
 finally:sm._quiescence_runtime=original;Runtime.attach_stats=oldattach;ns.transient_legal_subset=oldsubset
 write(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':run(Path(sys.argv[1]))
