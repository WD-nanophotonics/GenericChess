"""Observed warm empty-PV contract with the existing explicit full-PV flag."""
import sys,runpy,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
m=runpy.run_path(str(ROOT/'.local_agent/aux-quiet-20261012/transfer-producer.py'));p=m['p'];out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
from rule_semantics_ir_fixtures import uchifuzume_ruleset
c=m['compile_ruleset_for_execution'](uchifuzume_ruleset());s=p.GameSession(c);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
m['write_record'](out/'declaration.json',dict(question='Is observed warm S4 emptyPV cancellation corruption or the existing explicit full-PV contract?',calls=6,modes=[False,True],depth=2,q=4,hardq=8,tt=True,scope='Unmodified product Core caller, fresh player per fullPVflag, three cold/warm D2 calls; finite S4 value/action and root. Not a performance cohort or a new cache patch.'))
rows=[]
for full in [False,True]:
 ev=m['CountedSemanticEvaluator'](c,profile,ec,backend='native');player=m['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=m['SearchTuning'](use_pvs=True,require_full_pv=full))
 for repeat in range(3):
  t=time.perf_counter();before=m['record_value'](s.state);r=player.choose_action(s,m['SearchLimits'](max_depth=2,max_nodes=100000,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8));assert m['record_value'](s.state)==before and r.completed_depth==2 and r.score==0 and r.action in s.legal_actions()
  if full:assert len(r.principal_variation)==2
  rows.append(dict(full_pv=full,repeat=repeat,seconds=time.perf_counter()-t,decision=m['record_value'](r),root_restored=True));print(full,repeat,r.score,len(r.principal_variation),flush=True)
m['write_record'](out/'result.json',dict(complete=True,rows=rows))
