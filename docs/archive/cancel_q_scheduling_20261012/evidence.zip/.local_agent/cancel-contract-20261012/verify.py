"""Completed experiment accounting; fails if a declared long curve is unfinished."""
import json,hashlib
from pathlib import Path
b=Path(__file__).resolve().parent
read=lambda p:json.loads((b/p).read_text(encoding='utf-8-sig'))
summary={}
for path,n in [('caller-cancel-v2/result.json',45),('caller-cancel-v3-tt/result.json',45),('q4-profile/result.json',None),('text-reuse/result.json',4),('warm-pv-contract/result.json',6),('pvs-fixed-1090/result.json',4),('pvs-fixed-1091/result.json',4),('chunk-fixed/result.json',6),('chunk-curve/result.json',24),('pvs-delivery-1091/result.json',16)]:
 x=read(path);assert x['complete'],path
 if n is not None:assert len(x['rows'])==n
 if 'rows'in x:assert all(r.get('root_restored',True) for r in x['rows']),path
 summary[path]=dict(complete=True,rows=n,sha256=hashlib.sha256((b/path).read_bytes()).hexdigest())
for path in ['caller-cancel-v2/result.json','caller-cancel-v3-tt/result.json']:
 rr=read(path)['rows'];assert sum(x.get('decision',{}).get('termination_reason')=='cancelled' for x in rr)==25;assert sum('uncovered'in x for x in rr)==2
for root in ['1090','1091']:
 rr=read('pvs-fixed-'+root+'/result.json')['rows'];d=rr[0]['decision'];assert all((r['decision']['action'],r['decision']['score'],r['decision']['principal_variation'],r['decision']['completed_depth'])==(d['action'],d['score'],d['principal_variation'],2) for r in rr)
rr=read('nested-root/result.json');assert not rr['complete'] and len(rr['rows'])==20
assert all(r['selected_child_value']==r['result']['score'] and r['root_restored'] for r in rr['rows'])
rr=read('direct-v2/result.json');assert rr['complete'];assert sum('skipped'not in x for x in rr['rows'])==6 and sum('skipped'in x for x in rr['rows'])==2
summary['accounting']=dict(search_rows=175,scope='90caller+1profile+4text+6warmPV+20savedNested+8fixedPVS+6fixedChunk+24chunk+16PVScurve; top-level rows, not total physical search calls/recursive entries; six direct contract cells and exclusions separate; failed original prefixes retained separately',direct_cells=6,direct_exclusions=2,cancelled_rows=50,unreached_cancel_rows=4,nested_complete_rows=20,nested_failed_unsaved_returns=1)
# Search data and timing/stop distinctions are summarized, never replaced.
for name in ['chunk-curve','pvs-delivery-1091']:
 rr=read(name+'/result.json')['rows'];cells=[]
 for r in rr:
  d=r['decision'];assert r['actual_legality']['fallbacks']==0 and r['actual_legality']['failures']==0
  cells.append({k:r[k] for k in ['order','seconds_budget','seconds']} | {'arm':r.get('chunk',r.get('pvs')),'D':d['completed_depth'],'q':d['result_ordinary_qdepth'],'score':d['score'],'source':d['result_source'],'stop':d['termination_reason'],'main':d['nodes'],'qnodes':d['qnodes'],'quantum':r.get('quantum')})
 summary[name]=cells
(b/'verification.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary['accounting'],indent=2));print(json.dumps(summary['chunk-curve'],indent=1));print(json.dumps(summary['pvs-delivery-1091'],indent=1))
