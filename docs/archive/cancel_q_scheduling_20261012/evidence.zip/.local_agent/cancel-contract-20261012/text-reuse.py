"""Measured immutable lexical-text reuse; no product cache or legality reuse."""
import sys,runpy,inspect,textwrap,time,json
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/chunk-curve.py'));sm=m['sm'];Runtime=m['Runtime'];legal=m['legal'];Batch=m['Batch'];p=m['p'];ns=m['ns'];out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
m['write'](out/'declaration.json',dict(question='Does reusing immutable lexical text remove enough of observed1M candidate formatting calls to change the next transport choice?',root=1091,calls=4,orders=['base,text','text,base'],depth=2,nodes=100000,seconds=60,q=4,hardq=8,chunk=8,decision='Require exact full decision/main/q/check counts and root first; cost gain only within one exposed root, no product integration for trivial savings',premise='Actual q4 cProfile constructor3.83s/21.12, str0.707s/680643, hash1.82 inclusive; profile times overlap and do not predict additive speedup',scope='one bounded per-provider2048 lexical-text dict keyed by packed syntax; complete current-position legality and decoding/binding unchanged, public cache unchanged. No child/geometry/history/legal cache reuse.'))
base=Batch.__mro__[1];original_init=base.__init__;init_src=textwrap.dedent(inspect.getsource(original_init));init_src=init_src.replace('    for packed in raw:\n',"    texts=getattr(self.provider._metrics_local,'research_text_cache',None)\n    if texts is None:texts={};self.provider._metrics_local.research_text_cache=texts\n    for packed in raw:\n").replace('        self.rows.append((str(public),public,packed,None))',"        label=texts.get(packed)\n        if label is None:\n            label=str(public)\n            if len(texts)>=2048:texts.clear()\n            texts[packed]=label\n        self.rows.append((label,public,packed,None))")
namespace=dict(original_init.__globals__);exec(compile(init_src,'<research-text-cache>','exec'),namespace);text_init=namespace['__init__'];original=sm._quiescence_runtime;oldattach=Runtime.attach_stats;rows=[]
src=textwrap.dedent(inspect.getsource(original)).replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)').replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
try:
 reference=None
 for repeat,variants in enumerate([['base','text'],['text','base']]):
  for variant in variants:
   p.rr.stopped();base.__init__=original_init if variant=='base' else text_init;counts=Counter();legal.__globals__['counts']=counts;Batch.__iter__.__globals__['BATCH_SIZE']=8;probe=m['Probe'](shadow=False);namespace=dict(sm.__dict__,lazy_legal=legal,lazy_order=m['order'],quiet_drop_probe=probe);exec(compile(src,'<research-text-q4>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];rtrows=[]
   def attach(rt,stats):
    v=oldattach(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return v
   Runtime.attach_stats=attach;ev=m['Ev'](m['c'],m['profile'],m['ec'],backend='native');player=m['Player'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=m['Tuning'](use_pvs=True));t=time.perf_counter();r=player.choose_action(m['s'],m['Limits'](max_depth=2,max_nodes=100000,max_time_seconds=60,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
   for rt,saved in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==saved
   assert r.completed_depth==2;signature=(r.action,r.score,r.principal_variation,r.nodes,r.qnodes)
   if reference is None:reference=signature
   else:assert signature==reference
   rows.append(dict(order=repeat,variant=variant,seconds=elapsed,decision=m['record'](r),counts=dict(counts),probe=dict(probe.counts),root_restored=True));m['write'](out/'result.json',dict(complete=False,rows=rows));print(repeat,variant,round(elapsed,4),r.score,r.nodes,r.qnodes,flush=True)
finally:base.__init__=original_init;sm._quiescence_runtime=original;Runtime.attach_stats=oldattach
m['write'](out/'result.json',dict(complete=True,rows=rows))
