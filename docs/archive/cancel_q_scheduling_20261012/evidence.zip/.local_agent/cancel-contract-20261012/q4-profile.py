"""One existing q4 caller profile to select the remaining measured seam."""
import runpy,sys,time,cProfile,pstats,inspect,textwrap
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
m=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/chunk-curve.py'));sm=m['sm'];Runtime=m['Runtime'];ns=m['ns'];legal=m['legal'];Batch=m['Batch'];p=m['p'];out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
m['write'](out/'declaration.json',dict(question='After supported lazy transport, which actual q4 caller costs remain?',root=1091,chunk=8,calls=1,maxD=2,node_limit=100000,time_limit=60,q=4,hardq=8,pvs=True,scope='cProfile intrusive inclusive times overlap; not latency comparison or additive attainable savings; source-defined existing caller, no binary profile file'))
original=sm._quiescence_runtime;oldattach=Runtime.attach_stats;counts=Counter();legal.__globals__['counts']=counts;Batch.__iter__.__globals__['BATCH_SIZE']=8;probe=m['Probe'](shadow=False)
src=textwrap.dedent(inspect.getsource(original)).replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)').replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n');namespace=dict(sm.__dict__,lazy_legal=legal,lazy_order=m['order'],quiet_drop_probe=probe);exec(compile(src,'<research-profile-q4>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];rtrows=[]
def attach(rt,stats):
 v=oldattach(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return v
Runtime.attach_stats=attach
try:
 ev=m['Ev'](m['c'],m['profile'],m['ec'],backend='native');player=m['Player'](m['c'],evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=m['Tuning'](use_pvs=True));prof=cProfile.Profile();t=time.perf_counter();decision=prof.runcall(player.choose_action,m['s'],m['Limits'](max_depth=2,max_nodes=100000,max_time_seconds=60,quiescence_max_depth=4,quiescence_hard_max_depth=8));elapsed=time.perf_counter()-t
 for rt,saved in rtrows:rt.assert_balanced();assert p.runtime_state(rt)==saved
 stats=pstats.Stats(prof);rows=[]
 for (file,line,name),(cc,nc,tt,ct,callers) in stats.stats.items():
  if file.startswith(str(ROOT)):file=str(Path(file).relative_to(ROOT))
  elif not file.startswith('<'):file=Path(file).name
  rows.append(dict(file=file,line=line,name=name,primitive_calls=cc,calls=nc,self_seconds=tt,inclusive_seconds=ct))
 rows.sort(key=lambda x:x['inclusive_seconds'],reverse=True)
 m['write'](out/'result.json',dict(complete=True,seconds=elapsed,decision=m['record'](decision),counts=dict(counts),probe=dict(probe.counts),functions=rows,root_restored=True))
 print(round(elapsed,3),decision.completed_depth,decision.score,decision.nodes,decision.qnodes,flush=True)
finally:sm._quiescence_runtime=original;Runtime.attach_stats=oldattach
