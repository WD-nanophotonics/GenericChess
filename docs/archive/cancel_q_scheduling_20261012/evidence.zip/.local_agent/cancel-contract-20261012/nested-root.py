"""Finite nested legality/pawn-drop exact-root extension, existing q0 API."""
import sys,runpy,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from scripts.research_record import write_record,record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native import semantic as ns
from generic_chess.session.session import GameSession
from scripts.search_backend_comparison import CASES,CoreBoard
from types import SimpleNamespace
from rule_semantics_ir_fixtures import uchifuzume_ruleset
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does optional corrected root strategy retain same-depth independently verified value on nested S4 and standard Shogi drops?',cases=['s4','shogi-drop'],depths=[1,2,3],tt=[0,1],calls=24,scope='Existing material-only q0, two exposed supported roots; original full window counterpart and selected-child full TT0 proof; no q4 extrapolation/default/UI change',cost='under one minute expected, bounded depth3 max1000000nodes/time30 each'))
rows=[]
for key in ['s4','shogi-drop']:
 if key=='s4':c=compile_ruleset_for_execution(uchifuzume_ruleset());s=GameSession(c)
 else:
  c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));core=CoreBoard(next(x for x in CASES if x['id']==key),c);s=SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses)
 provider=NativeSemanticLegalityProvider.try_create(c,strict=True);nr=provider.native_rules;pos=pack_semantic_search_position(c,nr,s);before=ns.snapshot(nr,pos);vals={tid:100*(i+1) for i,tid in enumerate(nr.type_ids)}
 for depth in [1,2,3]:
  for tt in [0,1]:
   pair=[]
   for mode in [False,True]:
    t=time.perf_counter();r=ns.semantic_iterative_search(nr,pos,depth,board_values=vals,hand_values=vals,tt_megabytes=tt,root_window_pruning=mode,max_nodes=1000000,max_time_seconds=30);assert r['completed_depth']==depth;assert ns.snapshot(nr,pos)==before
    child=ns.make_checked(nr,pos,r['best_action'])
    if depth==1:verify=-ns.evaluate(nr,child,board_values=tuple(vals[x] for x in nr.type_ids),hand_values=tuple(vals[x] for x in nr.type_ids))
    else:verify=-ns.semantic_iterative_search(nr,child,depth-1,board_values=vals,hand_values=vals,tt_megabytes=0,_root_ply_offset=1)['score']
    # Terminal child uses mate scale; these rows are nonterminal or exact independently searched.
    assert verify==r['score'],(key,depth,verify,r['score'])
    pair.append(r);rows.append(dict(case=key,depth=depth,tt=tt,exact_root=mode,seconds=time.perf_counter()-t,result=record_value(r),selected_child_value=verify,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows))
   assert (pair[0]['score'],pair[0]['best_action'],pair[0]['principal_variation'])==(pair[1]['score'],pair[1]['best_action'],pair[1]['principal_variation'])
   print(key,depth,tt,pair[1]['score'],pair[1]['root_tie_refinements'],flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
