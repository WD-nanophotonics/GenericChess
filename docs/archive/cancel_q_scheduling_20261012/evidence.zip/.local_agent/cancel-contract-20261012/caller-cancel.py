"""Actual choose_action cancellation through supported q4 chunk consumer."""
import sys,runpy,inspect,textwrap,time
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
m=runpy.run_path(str(ROOT/'.local_agent/aux-quiet-20261012/filtered-transfer-producer.py'))
rootmod=runpy.run_path(str(ROOT/'.local_agent/cancel-contract-20261012/cancel-producer-v2.py'))
p=m['p'];ns=m['ns'];sm=m['search_module'];Runtime=m['SearchPathRuntime'];write=m['write_record'];record=m['record_value'];legal=m['legal'];order=m['order'];Batch=m['BatchLegal']
from generic_chess.ai.cancellation import CancellationToken
from types import SimpleNamespace
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);assert not(out/'declaration.json').exists()
write(out/'declaration.json',dict(question='Does actual q4 budget cancellation restore root/cache and retain the last complete iteration when arriving after Native chunk completion?',cases=['ep','aux0','s4'],chunks=[1,8,32],cancel_after_chunks=[1,2,8],calls=27,plus='three uncancelled baseline and three same-player retries',scope='Actual AlphaBetaPlayer and CancellationToken; only research q function substitutes existing BatchLegal/quiet guards. Full Core main/history/check/TT; original q4/hardq8, maxD2/node100000/time30. No product interface/default change.',decision='Every cancelled result must be legal and same completed prior iteration, full root/history/cache and fresh same-player result match full D2. Empty/no chunk rows explicitly uncovered.'))
original=sm._quiescence_runtime;src=textwrap.dedent(inspect.getsource(original)).replace('_runtime_legal_actions(ctx, ctx.checkpoint)','lazy_legal(ctx, ctx.checkpoint)').replace('_order_qactions(state, actions, ply, ctx)','lazy_order(state, actions, ply, ctx)');src=src.replace('    for action in ordered:\n','    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        if quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n');oldsubset=ns.transient_legal_subset;oldattach=Runtime.attach_stats;rows=[]
try:
 for name,c,state,witnesses in rootmod['roots']():
  if name not in ['ep','aux0','s4']:continue
  s=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses)
  ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
  reference=None
  for size in [1,8,32]:
   for target in [None,1,2,8]:
    counts=Counter();legal.__globals__['counts']=counts;Batch.__iter__.__globals__['BATCH_SIZE']=size;probe=m['QuietActionProbe'](shadow=False);namespace=dict(sm.__dict__,lazy_legal=legal,lazy_order=order,quiet_drop_probe=probe);exec(compile(src,'<research-q-cancel>','exec'),namespace);sm._quiescence_runtime=namespace['_quiescence_runtime'];token=CancellationToken();chunks=[0];rtrows=[]
    def subset(*a,**kw):
     result=oldsubset(*a,**kw);chunks[0]+=1
     if target is not None and chunks[0]==target:token.cancel()
     return result
    def attach(rt,stats):
     v=oldattach(rt,stats);rtrows.append((rt,p.runtime_state(rt)));return v
    ns.transient_legal_subset=subset;Runtime.attach_stats=attach
    ev=m['CountedSemanticEvaluator'](c,profile,ec,backend='native');player=m['AlphaBetaPlayer'](c,evaluator_override=ev,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=m['SearchTuning'](use_pvs=True));limits=m['SearchLimits'](max_depth=2,max_nodes=100000,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8);t=time.perf_counter();value=player.choose_action(s,limits,cancel_token=token)
    for rt,before in rtrows:
     rt.assert_balanced();assert p.runtime_state(rt)==before
     assert isinstance(rt._legal_cache,tuple) and set(rt._legal_cache)==set(rt._bindings)
    r=dict(case=name,chunk=size,target=target,chunks=chunks[0],decision=record(value),seconds=time.perf_counter()-t,root_restored=True,root_cache_complete=True)
    if target is None:
     signature=(value.action,value.score,value.principal_variation,value.completed_depth,value.nodes,value.qnodes)
     if reference is None:reference=signature
     else:assert signature==reference
    elif token.is_cancelled():
     assert value.termination_reason=='cancelled';assert value.completed_depth<2
     assert value.action in rtrows[0][0]._legal_cache
     # Returned prior completed q0 first iteration, not a partial new q4 claim.
     prior=player.choose_action(s,m['SearchLimits'](max_depth=value.completed_depth or 1,max_nodes=100000,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
     if value.completed_depth:assert (value.action,value.score,value.principal_variation)==(prior.action,prior.score,prior.principal_variation)
    else:r['uncovered']='target chunk not reached'
    rows.append(r);write(out/'result.json',dict(complete=False,rows=rows));print(name,size,target,chunks[0],value.completed_depth,value.termination_reason,flush=True)
   # Same player after actual cancellation, new token and same complete D2.
   ns.transient_legal_subset=oldsubset
   retry=player.choose_action(s,limits)
   assert (retry.action,retry.score,retry.principal_variation,retry.completed_depth)==reference[:4]
   rows.append(dict(case=name,chunk=size,retry=True,decision=record(retry),root_restored=all(p.runtime_state(rt)==before for rt,before in rtrows)))
finally:sm._quiescence_runtime=original;ns.transient_legal_subset=oldsubset;Runtime.attach_stats=oldattach
write(out/'result.json',dict(complete=True,rows=rows))
