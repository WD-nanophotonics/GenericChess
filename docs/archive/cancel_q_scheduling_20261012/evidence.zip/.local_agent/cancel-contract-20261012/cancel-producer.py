"""Finite cancellation/cache contract on the existing research BatchLegal."""
import sys,runpy,json
from pathlib import Path
from types import SimpleNamespace
from collections import Counter
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from scripts.research_record import write_record,record_value
from scripts.full_q_refresh_comparison import runtime_state
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native import semantic as ns
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess.session.session import GameSession
from generic_chess.core.pieces import Piece
from rule_semantics_ir_fixtures import weird_rulesets,uchifuzume_ruleset
m=runpy.run_path(str(ROOT/'.local_agent/aux-quiet-20261012/transfer-producer.py'));Batch=m['BatchLegal']
class Abort(Exception):pass
class Gate:
 def __init__(self):self.calls=0;self.at=2
 def __call__(self):
  self.calls+=1
  if self.calls==self.at:raise Abort('declared checkpoint cancellation')
def roots():
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));b=CoreBoard(next(x for x in CASES if x['id']=='chess-ep'),c)
 yield 'ep',c,b.initial,b.witnesses
 rules=weird_rulesets()[2];board=[list(r) for r in rules.initial_position];board[1][0]=Piece(0,'R','R');rules=replace(rules,initial_position=tuple(tuple(r) for r in board));c=compile_ruleset_for_execution(rules);s=GameSession(c)
 yield 'aux0',c,s.state,tuple(s._search_witnesses)
 s.submit(next(a for a in s.legal_actions() if 'promotion_grants_one_turn_right' in a.pattern_id))
 yield 'aux1',c,s.state,tuple(s._search_witnesses)
 c=compile_ruleset_for_execution(uchifuzume_ruleset());s=GameSession(c)
 yield 's4',c,s.state,tuple(s._search_witnesses)
def main(out):
 out.mkdir(parents=True,exist_ok=True);assert not (out/'declaration.json').exists()
 write_record(out/'declaration.json',dict(question='Does cancelled chunk enumeration retain full logical legality and Core bindings on retry/push/pop?',cases=['ep','aux0','aux1','s4'],chunks=[1,8],abort='second chunk checkpoint after first valid/rejected batch; then before cached action push transition',scope='Research BatchLegal, owned runtime only; eager Native+Core reference; no product cache representation change',decision='Reject partial prefix and stale binding reuse; exact restoration before implementation decision',cost='finite cases, under one minute expected'))
 rows=[]
 for name,c,state,witnesses in roots():
  provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
  oracle=SearchPathRuntime.from_state(state,c,history_witnesses=witnesses,legal_binding_provider=provider);full=tuple(sorted(oracle.legal_actions(),key=str));bindings=dict(oracle._bindings)
  for size in [1,8]:
   Batch.__iter__.__globals__['BATCH_SIZE']=size
   gate=Gate();rt=SearchPathRuntime.from_state(state,c,history_witnesses=witnesses,legal_binding_provider=provider);before=runtime_state(rt);ctx=SimpleNamespace(runtime=rt,checkpoint=gate,compiled=c,stats=SearchStatistics());counts=Counter();collection=Batch(ctx,counts);rt._legal_cache=collection;rt._bindings=collection.bindings;native_before=ns.snapshot(provider.native_rules,collection.native)
   try:tuple(collection);raise AssertionError('expected cancellation')
   except Abort:pass
   prefix=len(collection.valid);assert prefix>0 and prefix<len(collection.rows)
   assert runtime_state(rt)==before and ns.snapshot(provider.native_rules,collection.native)==native_before
   gate.at=-1;retried=tuple(rt.legal_actions());assert retried==full and rt._bindings==bindings
   assert all(a in collection for a in full);assert len(collection.valid)==len(collection.rows)
   for action in full:
    with rt.pushed(action):
     with oracle.pushed(action):assert runtime_state(rt)==runtime_state(oracle)
    assert runtime_state(rt)==before and rt._legal_cache is collection and rt._bindings is collection.bindings
   if full:
    gate.at=gate.calls+1
    try:rt.push(full[0],checkpoint=gate);raise AssertionError('expected transition cancellation')
    except Abort:pass
    assert runtime_state(rt)==before and rt._legal_cache is collection and rt._bindings==bindings
    gate.at=-1
    with rt.pushed(full[0]):pass
   rt.assert_balanced();oracle.assert_balanced()
   rows.append(dict(case=name,chunk=size,candidates=len(collection.rows),prefix=prefix,legal=len(full),counts=dict(counts),restored=True,bindings_exact=True,retry_complete=True))
   print(name,size,prefix,len(full),flush=True)
 write_record(out/'result.json',dict(complete=True,rows=rows))
if __name__=='__main__':main(Path(sys.argv[1]))
