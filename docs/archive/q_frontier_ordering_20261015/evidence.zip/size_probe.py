from pathlib import Path
import json,hashlib,subprocess,sysconfig,time
root=Path.cwd();b=root/'.local_agent/q-order-20261015/wide-codec';src=root/'generic_chess/_native';assert not(b/'size-results.json').exists();rows=[];source=r'''#include <stdio.h>
#include "native_semantic_state.h"
int main(void) {
 printf("{\"capacity\":%d,\"piece_bytes\":%zu,\"legacy_position_bytes\":%zu,\"legacy_rules_bytes\":%zu,\"semantic_position_bytes\":%zu,\"semantic_payload_bytes\":%zu,\"semantic_rules_bytes\":%zu}\n",GC_MAX_SQUARES,sizeof(GCPiece),sizeof(GCPosition),sizeof(GCRules),sizeof(GCSemanticPosition),sizeof(GCSemanticBoardPayload),sizeof(GCSemanticRules));
 return 0;
}
''';(b/'sizes.c').write_bytes(source.encode());start=time.perf_counter()
for cap in [256,512,1024]:
 out=b/('headers'+str(cap));out.mkdir(exist_ok=True);hashes={}
 for name in ['native_types.h','native_semantic_rules.h','native_semantic_state.h']:
  s=(src/name).read_text(encoding='utf-8')
  if name=='native_types.h':s=s.replace('#define GC_MAX_SQUARES 256','#define GC_MAX_SQUARES '+str(cap),1)
  data=s.encode();(out/name).write_bytes(data);hashes[name]=hashlib.sha256(data).hexdigest()
 exe=b/('size'+str(cap)+'.exe');cmd=[str(root/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-O2','-I'+str(out),'-I'+sysconfig.get_paths()['include'],str(b/'sizes.c'),'-o',str(exe)];r=subprocess.run(cmd,capture_output=True,timeout=60);(b/('build'+str(cap)+'-private.txt')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace');r=subprocess.run([str(exe)],capture_output=True,timeout=10);assert r.returncode==0;d=json.loads(r.stdout);d['header_sha256']=hashes;rows.append(d);print({k:v for k,v in d.items()if k!='header_sha256'},flush=True)
base=rows[0]
for row in rows:row['semantic_position_delta_bytes']=row['semantic_position_bytes']-base['semantic_position_bytes'];row['context_22_positions_delta_bytes']=22*row['semantic_position_delta_bytes']
(b/'size-results.json').write_bytes((json.dumps(dict(complete=True,rows=rows,seconds=time.perf_counter()-start,scope='Compiledsizeof-only executables withcopiedheaders at256/512/1024. Nocompiledengineexecution, nocapabilityorperformanceclaim. Globalmacrochanges legacystructsizesaswell: preferseparatesemanticcapacity/versionedABI ifpursued. FullSHAhistory4words unchanged; these arenotboardbitsets. Extra22position storage is illustrativemain12+hard8+2,notuniversalpeakmemory.'),indent=2)+'\n').encode())
