def build_prospective_wide_payload(semantic):
    """Lower ``CompiledSemanticRuleset.ir + .support`` into a deterministic
    numeric native payload (ADR-017).

    Authorities are exactly ``semantic.ir`` and ``semantic.support``;
    ``_legacy_compiled``, high-level RuleSet and movement atoms are never
    consulted.  The payload is the static closure of the frozen semantic IR
    v2 and must be exactly reconstructable from the C-owned capsule.
    """
    if getattr(semantic, "no_progress_draw", None) is not None:
        raise NativeUnsupportedRuleError(
            "native execution does not support no-progress draw rules"
        )
    ir = semantic.ir
    support = semantic.support
    fingerprint = support.ruleset_fingerprint
    n = support.board_size

    _validate(
        not getattr(semantic, "pass_enabled", False),
        "coordinate-free pass actions are unsupported by native semantic execution",
        fingerprint,
    )

    _validate(
        not any(pattern.square_zone_guards for pattern in ir.patterns),
        "square zone guards are unsupported by native semantic execution",
        fingerprint,
    )

    _validate(
        isinstance(n, int) and 1 <= n <= 32 and n * n <= 1024,
        "semantic board size out of native range",
        fingerprint,
    )
    _validate(ir.ir_version == 2, "unsupported semantic IR version", fingerprint)
    _validate(
        support.max_ply <= GC_SEM_MAX_PLY,
        f"max_ply {support.max_ply} exceeds native semantic limit {GC_SEM_MAX_PLY}",
        fingerprint,
    )
    _validate(
        1 <= support.repetition_limit <= 0xFFFFFFFF,
        f"repetition_limit {support.repetition_limit} outside native u32 range",
        fingerprint,
    )

    type_ids = tuple(sorted(support.type_metadata))
    pattern_ids = tuple(p.pattern_id for p in ir.patterns)
    geometry_ids = tuple(sorted(ir.geometry))
    zone_ids = list(sorted(ir.zones))
    declaration_zone_keys = {}
    zone_squares = {zid: tuple(ir.zones[zid].squares) for zid in zone_ids}
    for declaration in ir.declarations:
        for zone_id, zone in sorted(declaration.zones.items()):
            key = f"decl:{declaration.declaration_id}:{zone_id}"
            declaration_zone_keys[(declaration.declaration_id, zone_id)] = key
            zone_ids.append(key)
            zone_squares[key] = tuple(zone.squares)
    zone_ids = tuple(zone_ids)
    _validate(len(type_ids) <= GC_SEM_MAX_TYPES, "too many semantic types", fingerprint)
    _validate(
        len(pattern_ids) <= GC_SEM_MAX_PATTERNS,
        "too many semantic patterns",
        fingerprint,
    )
    _validate(
        len(geometry_ids) <= GC_SEM_MAX_GEOMETRIES,
        f"too many semantic geometries (limit {GC_SEM_MAX_GEOMETRIES})",
        fingerprint,
    )
    _validate(
        len(ir.aux_slots) <= GC_SEM_MAX_AUX_SLOTS,
        "too many semantic aux slots",
        fingerprint,
    )
    type_map = {tid: i for i, tid in enumerate(type_ids)}
    geometry_map = {gid: i for i, gid in enumerate(geometry_ids)}
    zone_map = {zid: i for i, zid in enumerate(zone_ids)}

    # ---- support section
    types = []
    for tid in type_ids:
        meta = support.type_metadata[tid]
        types.append(
            {
                "is_anchor": 1 if meta.is_anchor else 0,
                "is_promotable": 1 if meta.is_promotable else 0,
                "promo_targets": [type_map[t] for t in meta.promotion_target_ids],
            }
        )

    promo_allowed = []
    for tid in type_ids:
        pairs = []
        for owner in (0, 1):
            pairs.append(
                sorted(
                    (f.rank * n + f.file) << 16 | (t.rank * n + t.file)
                    for f, t in support.promotion_allowed.get(tid, ((), ()))[owner]
                )
            )
        promo_allowed.append(pairs)

    promo_forced = []
    for tid in type_ids:
        forced = []
        for owner in (0, 1):
            forced.append(
                sorted(
                    s.rank * n + s.file
                    for s in support.promotion_forced.get(tid, (frozenset(), frozenset()))[owner]
                )
            )
        promo_forced.append(forced)

    alive_promo = []
    for tid in type_ids:
        meta = support.type_metadata[tid]
        per_type = []
        for owner in (0, 1):
            masks = []
            for sq in range(n * n):
                mask = 0
                for j, ptid in enumerate(meta.promotion_target_ids):
                    if support.empty_mobility.get(ptid, ((), ()))[owner][sq]:
                        mask |= 1 << j
                masks.append(mask)
            per_type.append(masks)
        alive_promo.append(per_type)

    drop_mask = []
    for tid in type_ids:
        per_type = []
        for owner in (0, 1):
            mask = support.drop_allowed.get(tid, ((), ()))[owner]
            per_type.append([i for i, ok in enumerate(mask) if ok])
        drop_mask.append(per_type)

    # ---- IR section
    geometries = []
    for gid in geometry_ids:
        geo = ir.geometry[gid]
        atom_source = None
        if geo.atom_source is not None:
            atom_source = [type_map[geo.atom_source[0]], geo.atom_source[1]]
        paths = []
        for owner in ("0", "1"):
            per_source = []
            for source in sorted(geo.paths.get(owner, {})):
                path = geo.paths[owner][source]
                if path:
                    per_source.append([source, list(path)])
            paths.append(per_source)
        geometries.append(
            {
                "kind": _sem_enum(_SEM_GEOMETRY_CODES, geo.kind, "geometry kind", fingerprint),
                "min_steps": geo.min_steps,
                "atom_source": atom_source,
                "paths": paths,
            }
        )

    zones = [{"squares": list(zone_squares[zid])} for zid in zone_ids]

    aux_slots = []
    for slot in ir.aux_slots:
        initial = slot.initial
        if slot.value_kind == "square_or_none" and initial is not None:
            initial = [initial[0], initial[1]]
        aux_slots.append(
            {
                "slot_id": slot.slot_id,
                "value_kind": _sem_enum(_SEM_AUX_VALUE_CODES, slot.value_kind, "aux value kind", fingerprint),
                "scope": _sem_enum(_SEM_AUX_SCOPE_CODES, slot.scope, "aux scope", fingerprint),
                "lifetime": _sem_enum(_SEM_AUX_LIFETIME_CODES, slot.lifetime, "aux lifetime", fingerprint),
                "initial": initial,
            }
        )

    triggers = []
    for t in ir.triggers:
        triggers.append(
            {
                "slot_id": t.slot_id,
                "event": _sem_enum(_SEM_TRIGGER_EVENT_CODES, t.event, "trigger event", fingerprint),
                "square_ref": _sem_square_ref(t.square_ref, n, fingerprint),
                "owner": _sem_enum(_SEM_OWNER_CODES, t.owner, "trigger owner", fingerprint),
            }
        )

    patterns = []
    for p in ir.patterns:
        _validate(
            len(p.effects) <= GC_SEM_MAX_EFFECTS,
            f"pattern {p.pattern_id}: too many effects",
            fingerprint,
        )

        for inv in p.invariants:
            if inv.kind == "squares_not_attacked":
                _validate(
                    len(inv.square_refs) <= GC_SEM_MAX_INVARIANT_REFS,
                    f"pattern {p.pattern_id}: too many invariant refs",
                    fingerprint,
                )
        for pc in p.postconditions:
            if pc.max_stratum not in ("S0", "S1", "S2", "S3"):
                raise NativeUnsupportedRuleError(
                    f"postcondition probe stratum {pc.max_stratum} exceeds S3 "
                    f"(ruleset fingerprint {fingerprint}, "
                    f"native schema {NATIVE_SCHEMA_VERSION})"
                )
        patterns.append(
            {
                "type_indices": [type_map[t] for t in p.type_ids],
                "geometry_indices": [geometry_map[g] for g in p.geometry_ids],
                "target": _sem_enum(_SEM_TARGET_CODES, p.target.kind, "target kind", fingerprint),
                "path": [_sem_path_predicate(pp, fingerprint) for pp in p.path],
                "guards": [
                    _sem_state_guard(g, n, type_map, zone_map, fingerprint)
                    for g in p.guards
                ],
                "slot_guards": [
                    _sem_slot_guard(sg, n, fingerprint) for sg in p.slot_guards
                ],
                "effects": [_sem_effect(e, n, type_map, fingerprint) for e in p.effects],
                "invariants": [_sem_invariant(inv, n, fingerprint) for inv in p.invariants],
                "postconditions": [
                    _sem_postcondition(pc, fingerprint) for pc in p.postconditions
                ],
                "promotion_mode": _sem_enum(
                    _SEM_PROMOTION_MODE_CODES, p.promotion_mode, "promotion mode", fingerprint
                ),
                "explicit_promotion_type": (
                    type_map[p.explicit_promotion_type]
                    if p.explicit_promotion_type is not None
                    else None
                ),
                "cost": _sem_enum(_SEM_COST_CODES, p.cost_class, "cost class", fingerprint),
                "stratum": _sem_enum(_SEM_STRATUM_CODES, p.stratum, "stratum", fingerprint),
            }
        )

    automatic_adjudications = []
    for adjudication in support.automatic_adjudications:
        _validate(
            adjudication.outcome == "NO_CONTEST",
            f"unsupported automatic adjudication outcome {adjudication.outcome!r}",
            fingerprint,
        )
        _validate(
            adjudication.continuation_policy == "threshold_actor_continuous_check",
            f"unsupported automatic adjudication policy {adjudication.continuation_policy!r}",
            fingerprint,
        )
        automatic_adjudications.append(
            {
                "adjudication_id": adjudication.adjudication_id,
                "trigger_ply": adjudication.trigger_ply,
                "outcome": _sem_enum(
                    _SEM_OUTCOME_CODES, adjudication.outcome,
                    "automatic adjudication outcome", fingerprint,
                ),
                "continuation_policy": 0,
            }
        )
    _validate(
        len(automatic_adjudications) <= GC_SEM_MAX_AUTOMATIC_ADJUDICATIONS,
        "too many automatic adjudications",
        fingerprint,
    )

    declarations = []
    for declaration in ir.declarations:
        declaration_map = dict(zone_map)
        for zone_id in declaration.zones:
            declaration_map[zone_id] = zone_map[
                declaration_zone_keys[(declaration.declaration_id, zone_id)]
            ]
        declarations.append(
            _sem_declaration(
                declaration, n, type_map, declaration_map, fingerprint
            )
        )

    payload = {
        "semantic_payload_version": SEMANTIC_PAYLOAD_VERSION,
        "fingerprint": fingerprint,
        "board_size": n,
        "repetition_limit": support.repetition_limit,
        "stalemate_result": _sem_enum({"draw": 0, "loss": 1}, support.stalemate_result, "stalemate result", fingerprint),
        "repetition_policy": _sem_enum(
            _SEM_REPETITION_POLICY_CODES,
            support.repetition_policy,
            "repetition policy",
            fingerprint,
        ),
        "automatic_adjudication_ply": (
            support.automatic_adjudications[0].trigger_ply
            if support.automatic_adjudications
            else None
        ),
        "automatic_adjudications": automatic_adjudications,
        "max_ply": support.max_ply,
        # Runtime identity is the Python semantic_position_key JSON.  It
        # contains public type IDs, so the Native executor must own this
        # stable mapping instead of relying on a Python wrapper at runtime.
        "type_ids": list(type_ids),
        "types": types,
        "promo_allowed": promo_allowed,
        "promo_forced": promo_forced,
        "alive_promo": alive_promo,
        "drop_mask": drop_mask,
        "geometries": geometries,
        "zones": zones,
        "aux_slots": aux_slots,
        "triggers": triggers,
        "patterns": patterns,
        "declarations": declarations,
    }

    estimated = (
        # C-owned uint16 capture counts and per-type pattern subsequences.
        GC_SEM_MAX_TYPES * (1 + GC_SEM_MAX_PATTERNS) * 2
        + 65
        + len(types) * 16
        + sum(
            (len(pairs[0]) + len(pairs[1])) * 4
            + (len(forced[0]) + len(forced[1])) * 2
            + (len(drop[0]) + len(drop[1])) * 2
            for pairs, forced, drop in zip(promo_allowed, promo_forced, drop_mask)
        )
        + len(type_ids) * 2 * n * n * 8
        + sum(
            (len(o0) + len(o1)) * (4 + 2 * sum(len(e) for e in o0 + o1))
            for g in geometries
            for o0, o1 in [tuple(g["paths"])]
        )
        + sum(len(z["squares"]) * 2 for z in zones)
        + len(aux_slots) * 24
        + len(triggers) * 40
        + len(patterns) * 96
    )

    report = NativeSemanticCompilationReport(
        ruleset_fingerprint=fingerprint,
        ir_version=ir.ir_version,
        semantic_payload_version=SEMANTIC_PAYLOAD_VERSION,
        native_schema_version=NATIVE_SCHEMA_VERSION,
        board_squares=n * n,
        type_count=len(type_ids),
        pattern_count=len(pattern_ids),
        geometry_count=len(geometry_ids),
        zone_count=len(zone_ids),
        aux_slot_count=len(aux_slots),
        trigger_count=len(triggers),
        declaration_count=len(declarations),
        estimated_bytes=estimated,
        native_executable=False,
    )
    report = replace(report, native_executable=_native_payload_is_executable(payload, report))
    return payload, report
