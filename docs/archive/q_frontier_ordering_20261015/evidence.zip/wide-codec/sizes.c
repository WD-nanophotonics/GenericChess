#include <stdio.h>
#include "native_semantic_state.h"
int main(void) {
 printf("{\"capacity\":%d,\"piece_bytes\":%zu,\"legacy_position_bytes\":%zu,\"legacy_rules_bytes\":%zu,\"semantic_position_bytes\":%zu,\"semantic_payload_bytes\":%zu,\"semantic_rules_bytes\":%zu}\n",GC_MAX_SQUARES,sizeof(GCPiece),sizeof(GCPosition),sizeof(GCRules),sizeof(GCSemanticPosition),sizeof(GCSemanticBoardPayload),sizeof(GCSemanticRules));
 return 0;
}
