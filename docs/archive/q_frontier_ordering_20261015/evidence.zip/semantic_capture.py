from pathlib import Path
b=Path('.local_agent/q-order-20261015');exec(compile((b/'common_capture.py').read_text(encoding='utf-8'),str(b/'common_capture.py'),'exec'));cases=semantic_cases();assert not(b/'capture-semantic-rows.json').exists();write_record(b/'capture-semantic-declaration.json',dict(question='Does the same complete frontier hint preserve finite result/controls and reducework on actualpromotion/drop/aux/offtarget/compound/checkedneutral fixtures?',cohort=[c[0] for c in cases],conditions='Same fullplayed histories/staticvectors/mainD2/q4hard8/8s cap/TT0/plainmainorder; twooppositeorders plain/hint; preservecensors; no fitting.',cost='9roots*4*8=288s upper,360sfuse; independent semantic qualification alongside frozenfreshcurve, ordinaryconcurrency disclosed.'))
rows=[]
for case in cases:
 for order in range(2):
  for arm in (['hint','capture']if order==0 else['capture','hint']):
   rows.append(dict(root=case[0],order=order,arm=arm,**query(case,arm,2,None,8)));print(case[0],order,arm,rows[-1].get('result',{}).get('termination_reason'),flush=True)
write_record(b/'capture-semantic-rows.json',dict(complete=True,rows=rows));print('COMPLETE',len(rows))
