import subprocess,sys,json,time
from pathlib import Path
b=Path('.local_agent/q-order-20261015');start=time.perf_counter()
with(b/'branch-out-private.txt').open('w')as out,(b/'branch-err-private.txt').open('w')as err:
 try:r=subprocess.run([sys.executable,str(b/'branches.py')],stdout=out,stderr=err,timeout=1100);d=dict(exit_code=r.returncode,fuse_hit=False)
 except subprocess.TimeoutExpired:d=dict(exit_code=None,fuse_hit=True)
d['seconds']=time.perf_counter()-start;(b/'branch-exit.json').write_bytes((json.dumps(d,indent=2)+'\n').encode());print(d)
