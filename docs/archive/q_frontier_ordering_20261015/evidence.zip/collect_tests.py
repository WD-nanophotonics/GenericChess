from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
import pytest,json,hashlib
b=Path('.local_agent/q-order-20261015')
class Collector:
 def pytest_collection_finish(self,session):
  ids=[x.nodeid for x in session.items];(b/'collected-tests.json').write_bytes((json.dumps(dict(count=len(ids),nodeids_sha256=hashlib.sha256('\n'.join(ids).encode()).hexdigest(),scope='Collectiononly, no repeatedtestexecution.'),indent=2)+'\n').encode())
raise SystemExit(pytest.main(['--collect-only','-q','-p','no:cacheprovider'],plugins=[Collector()]))
