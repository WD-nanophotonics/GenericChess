from pathlib import Path
b=Path('.local_agent/q-order-20261015');exec(compile((b/'common_capture.py').read_text(encoding='utf-8'),str(b/'common_capture.py'),'exec'))
from types import SimpleNamespace
from dataclasses import replace
from scripts import search_backend_comparison as ref
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import snapshot
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
spec=importlib.util.spec_from_file_location('generic_chess._native_core',b/'production.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods['production']=m
out=b/'builtin';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists();cases=[x for x in ref.CASES if x['id']in['chess-middle','chess-ep','shogi-middle','shogi-drop']];write_record(out/'declaration.json',dict(question='Does actualcounterlessproduction q ordering transfer to existing Chess/Shogi EP/middle/richdrop publicAPI consumers?',base='d7fd6bec545b16d61123c87462291114ef9faa63',cases=cases,conditions='FreshanalysisFEN/SFEN withcomplete actualwitnesses, notfakeGameRecord. NEW frozenpure rulederived staticboard/current+hand/base profiles, nohuman/exposed-labelfitting. Installedoldvsproductioncounterlesscapture;TT64MiB/ordercacheoff/plainmain, rootwindowexact,q4hard8;fixedD2/6s then4/16s mainmax12,twooppositeorders. Engineconstruct/packing/PV insidecaller;sharedrule/profile prepoutside. FullPVchecked viaCore.',cost='4roots*4armordercalls*(6+4+16)=416s queryupper+setup,480sfuse; independentconsumercostquestion,notanextendedfailedgenericbudget.',scope='Builtinsareexistingexposeddevelopmentcontrols,notnewunexposedvalidation, humanpriceproof/Elo/WDL orUIdefaultswitch. Counterlessactualcandidate source/schema, installedoldbinary notchanged.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),images={k:hashlib.sha256(Path(mods[k].__file__).read_bytes()).hexdigest()for k in ['installed','production']}))
cache=EvaluationProfileCache(use_disk=False);cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);compiled={};roots=[];setup=[]
for case in cases:
 game=case['game']
 if game not in compiled:compiled[game]=compile_ruleset_for_execution(build_builtin_ruleset({'chess':'western_chess','shogi':'standard_shogi'}[game]))
 c=compiled[game];board=ref.CoreBoard(case,c);session=SimpleNamespace(compiled=c,state=board.initial,_search_witnesses=board.witnesses,result=board.initial.terminal_status);prof,_=cache.get_or_build(c,cfg);v,h=prof.board_value_by_type,prof.hand_value_by_base_type;nr=compile_native_semantic_rules(c);snap=snapshot(nr,pack_semantic_search_position(c,nr,session));assert snap['history_exact']and snap['history_events_exact'];setup.append(dict(root=case['id'],profile=record_value(prof),state=record_value(session.state),witnesses=record_value(session._search_witnesses),native_snapshot=snap));roots.append((case['id'],c,session,v,h))
write_record(out/'setup.json',dict(complete=True,rows=setup));rows=[];start=time.perf_counter()
for mode,seconds,depth in [('fixed',6,2),('resource',4,12),('resource',16,12)]:
 for name,c,s,v,h in roots:
  for order in range(2):
   for arm in (['installed','production']if order==0 else['production','installed']):
    p.rr.stopped();native._MODULE=mods[arm];before=s.state,s._search_witnesses;t=time.perf_counter();e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=v,hand_values=h,tt_megabytes=64,ordering_cache_enabled=False);prep=time.perf_counter()-t;ans=e.search(s,SearchLimits(max_depth=depth,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True);caller=time.perf_counter()-t;assert before==(s.state,s._search_witnesses);st=s.state
    for action in ans.principal_variation:assert action in legal_actions(st,c);st=apply_action(st,action,c)
    row=dict(root=name,mode=mode,seconds=seconds,order=order,arm=arm,result=record_value(ans),caller_seconds=caller,prepare_seconds=prep,root_unchanged=True,full_pv_legal=True);rows.append(row)
    with(out/'rows.jsonl').open('a',encoding='utf-8')as f:f.write(json.dumps(row)+'\n');f.flush()
    print(name,mode,seconds,order,arm,ans.completed_depth,ans.termination_reason,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,producer_seconds=time.perf_counter()-start));print('COMPLETE',len(rows),flush=True)
