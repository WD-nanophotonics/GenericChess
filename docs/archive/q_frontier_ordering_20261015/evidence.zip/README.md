# q frontier ordering evidence

Reviewed Agent scientific source, frozen generated inputs, experimental rows,
negative/censored cases and technical summaries only. No binary, raw Slack,
account/private user input, host logs or test temporary trees are published.

Base is sandbox d7fd6bec545b16d61123c87462291114ef9faa63. Work in an ISOLATED
checkout; never install into another Agent's checkout or running calculation.
Extract this record under .local_agent/q-order-20261015. Dependency is prior
q_fact_reuse_20261015/evidence.zip SHA256
f17a5adfe339b1f105f4ad9c445202f6883bca077228dc67030b18cfef788f1a,
under .local_agent/q-cost-20261014; its README binds the earlier neutral-order
and full-backend archives used by semantic_cases/common helpers. Dependencies
are immutable Agent scientific records already in Git, not local-path access.

Native snapshots are complete native_module.c files using unchanged tracked
companion C/headers. Final build.py uses cwd, current compatible Python/Zig and
Q_ORDER_ARM=plain|hint|capture|production with NATIVE_BUILD_OUT pointing to a
fresh private output. Binary hashes bind observations but cross-path/compiler
byte-identical builds are not promised. Base Native must be built/retained at
d7fd before the old-installed controls; build the final production image
privately and close all processes before replacing the installed binary.
Production C removes private counters and renames capture helpers only.

To rerun, preserve these immutable results. Use a separate checkout with final
scripts/C and frozen samples/setup inputs at their original relative paths;
do not overwrite rows/declarations (drivers intentionally refuse). Historical
create/build_first/collect_tests_first and wide_payload_first files preserve
pre-query failures/prose corrections, not recommended replay entry points.
Source-building full-production tests read the actual selected product C;
compiler-final.py and regression-test.py reflect the later metadata-only fix.
A full2557 production run passed before adding the two new report regressions;
41 related checks passed after them, not one full2559 run.

Geometry estimated_bytes is rough numeric payload accounting, not C owned or
peak memory. The correction changes report numbers, not runtime payload hashes.
Prospective wide payloads remain non-executable and actual C/Python reject18.
The63bit codec model/compiled sizeof-only executables are not a wide engine;
raw uint64 JSON integers require an exact-integer reader (e.g. Python).
Do not reinterpret old stateless raw codec contracts or use bit63 for squares.
No task-domain narrowing: Native32 would be a finite scope extension while the
complete generator has no maximum board size and Core fallback stays required.

1137 recorded searches and72 unsupported declines. Codec/scalar/sizeof/compile-
only checks and repeated tests are separate. Same fixed depth means same finite
objective, not same tree; resource counters include unfinished next iterations.
No WDL/strength, uniform speedup or independent whole-game validation claim.
Parallel bounded PRIMARY computations and normal other-project load are part
of timing scope; no exclusivity or auxiliary pause. Local date2026-10-15 JST,
UTC segment start2026-10-14T16:37:24.147914+00:00; native heartbeat stays PAUSED.
