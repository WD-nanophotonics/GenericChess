from pathlib import Path
b=Path('.local_agent/q-order-20261015');exec(compile((b/'common_capture.py').read_text(encoding='utf-8'),str(b/'common_capture.py'),'exec'))
import random
from dataclasses import replace
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.config import EvaluationConfig
out=b/'capture_fresh';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists();seeds=list(range(3001,3009));sizes=[4,8,12,16]*2;sizes[-1]=18
write_record(out/'declaration.json',dict(question='Does leafprice-independent binarycapture-first q ordering reduce actual checked work or improve useful caller delivery under same requestedq4?' ,base='d7fd6bec545b16d61123c87462291114ef9faa63',seeds=seeds,sizes=sizes,root_plies=[0,8],selection='bilateral_random/hybridtrue,Random(seed+7000) reprsortedlegalwalk; freezeallbeforequeries,noresampleearlyterminal,18 explicit',conditions='Same frozenrule-derived board/current+hand/base staticvalues; no dynamic/humanfitting; fullplayedstate/history; plain/capture privateinstrumented completeNative;TT0/plainorder/mainmax12,q4hard8; sharedcompile/profile outsidecaller,constructeachengine insidecaller; fixedD2/6s thenresource4/16s,twooppositeorders;timeconditionapplieskernel,caller actualrecorded includingpacking/PV/setup.',cost='16roots*4arms-ordercalls*(6+4+16)=1664s querycap upper pluscommonsetup/disk; expected<29min singleproducer1900sfuse. Unsupported18 skips queries; q-hard earlytermination can reduceactualcost. Not>1h, noartificialsplit/extraworker/fees.',decision='Anyclosedfixeddepth scoremismatch diagnoses; hard/timecensored unknownnotextended. Depthgainonlywithactualretainedqpolicy; allchangedactions eligible latercommonfiniteobjectivecheck notstrength. No defaultadoption fromtiming alone.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((b/'capture-native_module.c').read_bytes()).hexdigest(),images={k:hashlib.sha256(Path(v.__file__).read_bytes()).hexdigest()for k,v in mods.items()}))
cache=EvaluationProfileCache(use_disk=False);cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);samples=[];setup=[];start=time.perf_counter()
for seed,size in zip(seeds,sizes):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));raw=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);prof,_=cache.get_or_build(c,cfg);setup.append(dict(seed=seed,profile=record_value(prof)));s=GameSession(c);rng=random.Random(seed+7000);walk=[]
 for ply in range(9):
  actions=tuple(s.legal_actions())
  if ply in [0,8]:samples.append(dict(name=f'{seed}-ply{ply}',seed=seed,ruleset=json.loads(serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk.copy(),included=bool(actions),game_record=record_value(s.to_record()),legal_count=len(actions)))
  if ply==8:break
  if not actions:samples.append(dict(seed=seed,unavailable_ply=8,terminal_at=ply,resampled=False));break
  action=rng.choice(sorted(actions,key=repr));walk.append(record_value(action));s.submit(action)
 print('Frozen',seed,size,flush=True)
write_record(out/'samples.json',dict(complete=True,samples=samples,setup=setup,common_preparation_seconds=time.perf_counter()-start));print('Done',len(samples),flush=True)
