from pathlib import Path
import sys,importlib.util
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));import generic_chess.native as n
spec=importlib.util.spec_from_file_location('generic_chess._native_core',ROOT/'.local_agent/q-order-20261015/hint.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);n._MODULE=m
import pytest
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--basetemp=.local_agent/q-order-20261015/hint-guards','tests/product/test_native_semantic_qsearch.py','tests/product/test_native_terminal_declaration_priority.py','tests/product/test_no_contest_search.py']))
