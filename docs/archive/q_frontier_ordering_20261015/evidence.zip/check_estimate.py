from pathlib import Path
b=Path('.local_agent/q-order-20261015');exec(compile((b/'common_capture.py').read_text(encoding='utf-8'),str(b/'common_capture.py'),'exec'))
import generic_chess.native.compiler as nc
out=b/'wide-codec';old_results=json.loads((out/'payload-results.json').read_text());control={str(x['seed']):x for x in old_results['rows']};rows=[]
for case in generated_cases(b/'fresh/samples.json')+generated_cases(b/'capture_fresh/samples.json'):
 name,c,s,v,h=case;seed=name.split('-')[0]
 if not name.endswith('ply0')or seed not in ['2911','3007']:continue
 payload,report=nc.build_semantic_compile_payload(c);sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert sha==control[seed]['payload_sha256'];rows.append(dict(seed=int(seed),board_size=c.support.board_size,payload_sha256=sha,payload_unchanged=True,old_estimated_bytes=control[seed]['prospective_report']['estimated_bytes'],new_estimated_bytes=report.estimated_bytes))
for seed in ['2912','3008']:
 payload=json.loads((out/('prospective18-'+seed+'.json')).read_text());old_geom=sum((len(a)+len(z))*(4+2*sum(len(e)for e in a+z))for g in payload['geometries']for a,z in [g['paths']]);new_geom=sum(4+2*len(squares)for g in payload['geometries']for owner in g['paths']for source,squares in owner);rows.append(dict(seed=int(seed),board_size=18,old_estimated_bytes=control[seed]['prospective_report']['estimated_bytes'],corrected_logical_estimate=control[seed]['prospective_report']['estimated_bytes']-old_geom+new_geom,old_geometry_term=old_geom,new_geometry_term=new_geom,still_native_executable=False,scope='Arithmeticcorrectiontoalreadyfrozenprospectivepayload only; notcurrentNative18activation.'))
write_record(out/'estimate-correction.json',dict(complete=True,rows=rows,old_tests_failed=2,new_focused_tests_passed=41,new_regressions=2,scope='Logicalnumericpayloadestimate, NOTCallocatedbytes ormemorysafetybound. Publicpayloadhashes for2supported12x12rulesunchanged. No semantic/search/ABI changes fromestimatefix. Oldprospectivereports/source retainoriginalbytes/limits, corrections separate.'));print(json.dumps(rows,indent=2))
