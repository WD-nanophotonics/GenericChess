from pathlib import Path
import json,random,itertools,hashlib,sys,time
sys.path.insert(0,str(Path.cwd()))
import generic_chess.native as native
b=Path('.local_agent/q-order-20261015');out=b/'wide-codec';out.mkdir(exist_ok=True);write=lambda name,d:(out/name).write_bytes((json.dumps(d,indent=2)+'\n').encode());assert not(out/'declaration.json').exists();write('declaration.json',dict(question='Can a widerboard action identity fituint64 without colliding withactualNative declaration tag orshrinking supportedtype/pattern/geometry semantics?',observed='Everyfrozen18Nativecontrol declines. CurrentGC_MAX_TYPES64 butrawactorcodec8bits; highestbit63isGC_SEM_DECL_ACTION_TAG. Anunversionedbitreclaim isnotlicensedbysizeguardchange.',method='Source-mask audit; actualcurrentCrawpack/unpack foractorboundaries; rejectnaivecoordhighbits62/63 bycounterexample. ProspectiveVERSIONEDdense63bit model supports32x32,all64types,256patterns,4096geometries,promotion-none/drop identity; structuraldisjointmaskproof plusfiniteboundary/randomchecks. No Nativeboard18 execution orABIchange.',cost='Atmost300000 scalarcodecroundtrips,30s internalcompute bound; no engine searches/training ornewworkers. Oppositeoutcomeschange nextchoice betweenwideintredesign vscompactversionedcarrier+state-capacityaudit.',scope='Generator board_size hasno upperbound; finiteNative32wouldremainascopeextensionwithcompleteCorefallback,nota reductionofthegenericprojecttarget. Preservepromotion/drop/aux/history; codecdoesnotproveenginecoverage.'))
m=native._module();cprobes=[]
for actor in [0,63,64,255]:
 fields=dict(to=7,**{'from':2},promotion=255,base=3,kind=2,pattern=12,geometry=1023,actor_current=actor);raw=m.semantic_action_pack(fields);decoded=m.semantic_action_unpack(raw);assert decoded==fields;cprobes.append(dict(fields=fields,packed=raw,decoded=decoded))
# Temptingbutwrong: reclaimactor8->6 upperbitsfor two9thcoordinatebits.
naive=(255<<16)|(1<<24)|(2<<32)|(1<<63)
collision=dict(proposed_from=256,proposed_to=0,proposed_actor=0,packed=naive,actual_current_raw_C_decode=m.semantic_action_unpack(naive),source_declaration_tag=1<<63,classified_as_declaration_by_current_search=bool(naive&(1<<63)))
assert collision['classified_as_declaration_by_current_search'];write('current-C-boundaries.json',dict(raw_codec_probes=cprobes,naive_collision=collision,scope='StatelessrawCcodecprobes,notactualNative18search. Sourceclassifierbitproof fromnative_module.c tag/is_declaration action; notexecutedquery.'))
fields=[('to',10),('from',10),('promotion',7),('base',6),('kind',4),('pattern',8),('geometry',12),('actor_current',6)];layout=[];shift=0;union=0
for name,width in fields:
 mask=((1<<width)-1)<<shift;assert not union&mask;union|=mask;layout.append((name,width,shift));shift+=width
assert shift==63 and union==(1<<63)-1
limits={k:(1<<w)-1 for k,w,_ in layout}
def pack(d):
 for k in limits:assert type(d[k])is int and 0<=d[k]<=limits[k]
 assert d['kind']in[2,3]
 if d['kind']==3:assert d['from']==1023
 return sum(d[k]<<s for k,w,s in layout)
def unpack(raw):
 assert 0<=raw<1<<63
 d={k:(raw>>s)&((1<<w)-1)for k,w,s in layout};assert d['kind']in[2,3]
 if d['kind']==3:assert d['from']==1023
 return d
start=time.perf_counter();count=0;digest=hashlib.sha256()
for to,fr,prom,base,pat,geo,actor in itertools.product([0,255,256,323,511,1023],[0,255,256,323,511,1023],[0,63,127],[0,63],[0,255],[0,4095],[0,63]):
 d=dict(to=to,**{'from':fr},promotion=prom,base=base,kind=2,pattern=pat,geometry=geo,actor_current=actor);raw=pack(d);assert unpack(raw)==d;digest.update(raw.to_bytes(8,'little'));count+=1
rng=random.Random(20261015)
for i in range(100000):
 d={k:rng.randrange(limits[k]+1)for k in limits};d['kind']=rng.choice([2,3]);d['promotion']=rng.choice(list(range(64))+[127]);
 if d['kind']==3:d['from']=1023
 raw=pack(d);assert unpack(raw)==d;digest.update(raw.to_bytes(8,'little'));count+=1
 assert time.perf_counter()-start<30
for decl in range(16):
 try:unpack((1<<63)|decl)
 except AssertionError:pass
 else:raise AssertionError('declaration incorrectlydecoded asboard/drop')
write('model-results.json',dict(complete=True,model_version='PROSPECTIVE_ONLY_V2_NOT_PRODUCT',bits=shift,layout=[dict(field=k,width=w,shift=s)for k,w,s in layout],structural_proof='Boundedfieldmasksdisjoint/coverbits0..62; concatenationisinjectiveanddecodinginverse. Bit63clear forboard/drop, explicitdeclarationsseparate. This arithmeticfact isnotanengineproof.',finite_roundtrips=count,sequence_sha256=digest.hexdigest(),random_seed=20261015,seconds=time.perf_counter()-start,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),decision='Rejectunversionedsparsehighbitpatch: concrete declaration-tag collision andrawactorcontract. uint64 itself neednotbeabandoned: versioneddense63bitcarrier fits32x32/64types withtag. Nextassessstatecapacities andversiondispatch,notguard-only patch. Nativecurrent18stillunsupported;no productionABI/domainchange.'))
print('COMPLETE',count,round(time.perf_counter()-start,3))
