from pathlib import Path
b=Path('.local_agent/q-order-20261015');exec(compile((b/'common_capture.py').read_text(encoding='utf-8'),str(b/'common_capture.py'),'exec'))
out=b/'tt_fresh';assert not(out/'rows.json').exists();rows=[];start=time.perf_counter()
write_record(out/'execution-plan.json',dict(question='Does q frontier ordering remain useful/compatible under persistent default64MiB mainTT, cold/warm calls and q1/q4 switching?',selection='ALL8actualplayedroots from4newfrozenrules3101-3104; no18ruleinthisTTcohort, noresampling. Samefullhistory/staticvectors.',conditions='Plain/capture binarypriceblindqorder; TT64MiB,orderingcacheoff/plainmainorder, exactrootwindow. D2/6s/q1orq4hard8, twooppositearmorders. coldq1 onindependentnewengine then newpersistentengine coldq4/warmq4/switchq1/returnq4. No profilechanges duringsequence, no result-drivenextensions.',cost='8roots*2arms*2orders*5calls*6s=960s querycapupper+setup,1100sfuse; one64MiBTTengine atatime, noextraAgent orfees. Differentpremise fromTT0,notlongrunsplitting.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
for case in generated_cases(out/'samples.json'):
 name,c,s,v,h=case
 for order in range(2):
  for arm in (['plain','capture']if order==0 else['capture','plain']):
   native._MODULE=mods[arm]
   for phase,q in [('coldq1',1),('coldq4',4),('warmq4',4),('switchq1',1),('returnq4',4)]:
    p.rr.stopped();before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter()
    try:
     if phase in ['coldq1','coldq4']:e=None;e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=v,hand_values=h,tt_megabytes=64,ordering_cache_enabled=False)
     prep=time.perf_counter()-t;ans=e.search(s,SearchLimits(max_depth=2,max_time_seconds=6,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True);row=dict(root=name,order=order,arm=arm,phase=phase,requested_q=q,result=record_value(ans),private_counts={k:last_raw[arm][k]for k in ['private_q_candidates','private_q_attempts','private_q_legal','private_q_noisy']},caller_seconds=time.perf_counter()-t,prepare_seconds=prep,root_unchanged=before==(s.state,s.to_record(),s._search_witnesses));assert row['root_unchanged']
    except NativeUnsupportedRuleError as error:row=dict(root=name,order=order,arm=arm,phase=phase,requested_q=q,unsupported=str(error))
    rows.append(row)
    with(out/'rows.jsonl').open('a',encoding='utf-8')as f:f.write(json.dumps(row)+'\n');f.flush()
    print(name,order,arm,phase,row.get('result',{}).get('completed_depth'),row.get('result',{}).get('termination_reason'),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,producer_seconds=time.perf_counter()-start));print('COMPLETE',len(rows),time.perf_counter()-start,flush=True)
