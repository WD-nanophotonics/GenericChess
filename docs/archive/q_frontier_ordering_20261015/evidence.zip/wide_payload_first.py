from pathlib import Path
b=Path('.local_agent/q-order-20261015');exec(compile((b/'common_capture.py').read_text(encoding='utf-8'),str(b/'common_capture.py'),'exec'))
import inspect
import generic_chess.native.compiler as nc
out=b/'wide-codec';assert not(out/'payload-results.json').exists();source=inspect.getsource(nc.build_semantic_compile_payload);old='isinstance(n, int) and 1 <= n <= 16 and n * n <= 256';assert source.count(old)==1;wide=source.replace('def build_semantic_compile_payload(','def build_prospective_wide_payload(',1).replace(old,'isinstance(n, int) and 1 <= n <= 32 and n * n <= 1024',1);(out/'prospective_payload_builder.py').write_bytes(wide.encode());ns=dict(nc.__dict__);exec(compile(wide,str(out/'prospective_payload_builder.py'),'exec'),ns);builder=ns['build_prospective_wide_payload'];cases=generated_cases(b/'fresh/samples.json')+generated_cases(b/'capture_fresh/samples.json');selected={}
for case in cases:
 name,c,s,v,h=case
 if name.split('-')[0]in['2911','2912','3007','3008']:selected.setdefault(name.split('-')[0],case)
rows=[]
for seed,case in sorted(selected.items()):
 name,c,s,v,h=case;before=record_value(s.state),s.to_record(),s._search_witnesses;t=time.perf_counter();payload,report=builder(c);seconds=time.perf_counter()-t;row=dict(seed=int(seed),board_size=c.support.board_size,lowering_seconds=seconds,prospective_report=record_value(report),payload_sha256=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest(),payload_bytes=len(json.dumps(payload).encode()),state_unchanged=before==(record_value(s.state),s.to_record(),s._search_witnesses));assert row['state_unchanged'];assert payload['fingerprint']==c.support.ruleset_fingerprint
 if c.support.board_size<=16:
  ordinary,ordinary_report=nc.build_semantic_compile_payload(c);assert ordinary==payload and ordinary_report==report;row['ordinary16_payload_identical']=True
 else:
  assert not report.native_executable
  try:nc.build_semantic_compile_payload(c)
  except NativeUnsupportedRuleError as error:row['current_python_rejection']=str(error)
  else:raise AssertionError('Currentwideguard unexpectedlyaccepted')
  try:native._module().compile_semantic_rules(payload)
  except(ValueError,RuntimeError)as error:row['current_C_rejection']=str(error)
  else:raise AssertionError('CurrentCwideguard unexpectedlyaccepted')
  write_record(out/('prospective18-'+seed+'.json'),payload)
 rows.append(row)
write_record(out/'payload-results.json',dict(complete=True,rows=rows,source_sha256=hashlib.sha256(source.encode()).hexdigest(),private_builder_sha256=hashlib.sha256(wide.encode()).hexdigest(),difference='Onlyfunctionname anddeclaredboardbound inprivatefunctioncopy. _native_payload_is_executable remainscurrentstrict<=256, so widepayloadreportfalse. No monkeypatch/productcompilermutation orsearch withunsupportedpayload.',decision='Two16controls byte-equivalenttoofficiallowering; if18lowerswithallfields, focusnextprivatefeasibility onversionedcodecandsemanticstatecapacity,notruleprojections. CurrentC/Pythonreject18stillpreserved. Completegeneratedtargetnotlimitedto32;Corefallback remains required.',scope='Payloadcompile-onlyexperiment with4existingfrozenrulefamilies. Not Nativewideexecution/perft/correctness ormeasuredallocationcost. Existingreportestimated_bytesisheuristic, notsizeof/peakmemory.'));print(json.dumps(rows,indent=2))
