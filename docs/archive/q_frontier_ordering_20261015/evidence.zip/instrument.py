from pathlib import Path
b=Path('.local_agent/q-order-20261015');exec(compile((b/'common.py').read_text(encoding='utf-8'),str(b/'common.py'),'exec'))
assert not(b/'instrument-rows.json').exists();cases=generated_cases(old/'generic-q4/samples.json')+semantic_cases();write_record(b/'instrument-declaration.json',dict(question='Does matched private instrumentation preserve the installed canonical q kernel at fixed visitedwork?',cohort='ALL32 prior2601-2616 playedroots+9complete semantic fixtures,18declines explicit',limits='mainmax3,total4096visits,q4hard8,time5s,twoorders installed/plain. Notfreshvalidation andnotorderinggain. Concurrent frozenfreshproducer permitted; timingnotcompared.',cost='Atmost41roots*4*5=820s caps,1000sfuse; noextension',keys=['score','action','declaration_id','principal_variation','decision_line','nodes','qnodes','completed_depth','selective_depth','termination_reason','result_ordinary_qdepth','result_check_hard_qdepth','transition_count','legal_generation_count']));rows=[]
for case in cases:
 for order in range(2):
  for arm in (['installed','plain']if order==0 else['plain','installed']):
   row=dict(root=case[0],order=order,arm=arm,**query(case,arm,3,4096,5));rows.append(row);print(case[0],order,arm,row.get('result',{}).get('termination_reason'),flush=True)
write_record(b/'instrument-rows.json',dict(complete=True,rows=rows));keys=json.loads((b/'instrument-declaration.json').read_text())['keys'];pairs=[]
for root,order in sorted({(r['root'],r['order'])for r in rows}):
 pair={r['arm']:r for r in rows if (r['root'],r['order'])==(root,order)};a,z=pair['installed'],pair['plain']
 if'result'not in a:continue
 pairs.append(dict(root=root,order=order,diff=[k for k in keys if a['result'][k]!=z['result'][k]],time_censored=any(r['result']['termination_reason']=='time_budget'for r in [a,z])))
out=dict(complete=True,actual_queries=sum('result'in x for x in rows),declines=sum('unsupported'in x for x in rows),pairs=pairs,uncensored_exact=sum(not x['diff']and not x['time_censored']for x in pairs),unexpected=[x for x in pairs if x['diff']and not x['time_censored']]);write_record(b/'instrument-summary.json',out);print('COMPLETE',out['actual_queries'],out['uncensored_exact'],out['unexpected']);assert not out['unexpected']
