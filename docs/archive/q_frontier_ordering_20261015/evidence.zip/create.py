from pathlib import Path
import json,hashlib
b=Path('.local_agent/q-order-20261015');s=Path('generic_chess/_native/native_module.c').read_text(encoding='utf-8');(b/'base-native_module.c').write_bytes(s.encode());s=s.replace('    unsigned qdepth_limit;','    uint64_t private_q_candidates, private_q_attempts, private_q_legal, private_q_noisy;\n    unsigned qdepth_limit;',1)
a=s.index('static int gc_semantic_quiescence(');z=s.index('static int gc_semantic_iterative_negamax(',a);q=s[a:z];q=q.replace('    ctx->legal_generation_count++;','    ctx->legal_generation_count++;\n    ctx->private_q_candidates+=actions.count;',1);q=q.replace('        int made=gc_semantic_runtime_make_checked_status','        ctx->private_q_attempts++;\n        int made=gc_semantic_runtime_make_checked_status',1);q=q.replace('ctx->transition_count++;legal++;','ctx->transition_count++;legal++;ctx->private_q_legal++;',1);q=q.replace('        if(!noisy)continue;','        if(!noisy)continue;\n        ctx->private_q_noisy++;',1);s=s[:a]+q+s[z:];s=s.replace('        gc_semantic_set_u64(out, "ordering_cache_hits", cache_hits) != 0 ||','        gc_semantic_set_u64(out, "private_q_candidates", ctx.private_q_candidates) != 0 ||\n        gc_semantic_set_u64(out, "private_q_attempts", ctx.private_q_attempts) != 0 ||\n        gc_semantic_set_u64(out, "private_q_legal", ctx.private_q_legal) != 0 ||\n        gc_semantic_set_u64(out, "private_q_noisy", ctx.private_q_noisy) != 0 ||\n        gc_semantic_set_u64(out, "ordering_cache_hits", cache_hits) != 0 ||',1);(b/'plain-native_module.c').write_bytes(s.encode())
helper='''/* Private experiment: coarse ordering hints only, never legality/noise filtering. */
static int gc_private_q_hint_compare(const void *left,const void *right) {
 const GCSemanticOrderedAction *a=left,*b=right;
 if(a->mover_score!=b->mover_score)return a->mover_score>b->mover_score?-1:1;
 return(a->action>b->action)-(a->action<b->action);
}
static int gc_private_q_order(GCSemanticIterativeContext *ctx,
    GCSemanticPosition *pos,GCSemanticActionBuffer *actions) {
 if(actions->count<2)return 1;
 GCSemanticOrderedAction *ordered=calloc(actions->count,sizeof(*ordered));
 if(!ordered){ctx->control=4;return 0;}
 unsigned cells=ctx->rules->board_size*ctx->rules->board_size;
 for(size_t i=0;i<actions->count;i++) {
  if(!gc_semantic_iterative_check_budget(ctx,1)){free(ordered);return 0;}
  uint64_t action=actions->data[i];
  unsigned target=GC_ACTION_TO(action),promo=GC_ACTION_PROMO(action);
  unsigned actor=(action>>GC_ACTION_ACTOR_CURRENT_SHIFT)&GC_ACTION_ACTOR_CURRENT_MASK;
  double score=0.0,actor_value=actor<ctx->rules->type_count?ctx->profile.board[actor]:0;
  if(GC_ACTION_KIND(action)==GC_ACTION_KIND_SEMANTIC_BOARD && target<cells &&
     pos->board[target].occupied && pos->board[target].owner!=pos->side_to_move)
   score=1.0e12+10.0*ctx->profile.board[pos->board[target].current_type]-actor_value;
  else if(promo<ctx->rules->type_count && ctx->profile.board[promo]>actor_value)
   score=1.0e9+ctx->profile.board[promo]-actor_value;
  ordered[i].action=action;ordered[i].mover_score=score;
 }
 qsort(ordered,actions->count,sizeof(*ordered),gc_private_q_hint_compare);
 for(size_t i=0;i<actions->count;i++)actions->data[i]=ordered[i].action;
 free(ordered);return 1;
}
'''
a=s.index('static int gc_semantic_quiescence(');s=s[:a]+helper+s[a:];a=s.index('static int gc_semantic_quiescence(');z=s.index('static int gc_semantic_iterative_negamax(',a);q=s[a:z];old='    if(actions.count>1)qsort(actions.data,actions.count,sizeof(uint64_t),gc_semantic_canonical_action_compare);';assert q.count(old)==1;q=q.replace(old,'    if(!gc_private_q_order(ctx,pos,&actions)){gc_semantic_action_buffer_free(&actions);return 0;}');s=s[:a]+q+s[z:];(b/'hint-native_module.c').write_bytes(s.encode())
build=Path('scripts/build_native_zig.py').read_text(encoding='utf-8');build=build.replace('command.extend(str(p) for p in sorted((ROOT / "generic_chess/_native").glob("*.c")))','command.extend(str(p) for p in sorted((ROOT / "generic_chess/_native").glob("*.c")) if p.name != "native_module.c")\n    command.append(str(ROOT / ".local_agent/q-order-20261015" / (os.environ["Q_ORDER_ARM"]+"-native_module.c")))');assert 'Q_ORDER_ARM'in build;(b/'build.py').write_bytes(build.encode())
(b/'source-binding.json').write_bytes((json.dumps(dict(base_sha='d7fd6bec545b16d61123c87462291114ef9faa63',source_sha256={f:hashlib.sha256((b/f).read_bytes()).hexdigest()for f in ['base-native_module.c','plain-native_module.c','hint-native_module.c']},scope='Private paired instrumentation samefields inbotharms; hintonlyqorder,allcandidateactions preserved/fullchecked same semantics. Directcapture/promotion field hints incomplete on genericmechanics, not noise classification or reduction. No mainordering/profile/default/API/TTchange.'),indent=2)+'\n').encode())
