"""Predeclared2x2 scheduling/representation interaction on existing EP/generated2000/2001.
Full/verified root x bare/2048 immutable syntax cache; fresh per call, two reversed
orders, fixed4096 entries and1second/D12/100000 shared limits. Full semantic
position/history and live legal frontier retained. No new labels or reference
budget; compare fixed work signatures within each algorithm, timed completion
separately. Expected below1min. Decision: combine orthogonal changes only if cache
preserves fixed traces and helps this corrected scheduler, not a product adoption.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('python_root_scheduling.py'))}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('start=perf_counter()\ntry:')[0],ns)
from scripts.research_record import record_value
from generic_chess.native.semantic import public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
factory_ns=ns['ns'];CachedSyntax=factory_ns['CachedSyntax'];NativeBoard=ns['NativeBoard']
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
output=Path(__file__).with_name('scheduler-syntax-interaction.json')
def save():output.write_text(json.dumps(report,indent=2)+'\n')
start=perf_counter()
try:
 for name,factory,values in factory_ns['factories'][3:]:
  arms=[(mode,cls) for mode in ('full','verified') for cls in (NativeBoard,CachedSyntax)]
  for kind in ('fixed','timed'):
   for repeat,order in enumerate((arms,list(reversed(arms)))):
    for mode,cls in order:
     for flag in ('rollout','advisor','slack'):
      f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
     core=factory();t=perf_counter();board=cls(core,values);setup=perf_counter()-t
     r=ns['iterative'](board,mode,30 if kind=='fixed' else 1,4096 if kind=='fixed' else 100000)
     state=core.initial
     for raw in r['pv']:
      action=public_action(board.native,raw);assert action in legal_actions(state,core.compiled);state=apply_action(state,action,core.compiled)
     r.update(case=name,kind=kind,repeat=repeat,backend=cls.__name__,setup_seconds=setup,pv_legal=True,root_restored=board.restored() and core.restored())
     assert r['root_restored']
     if cls is CachedSyntax:r['cache']=dict(entries=len(board.syntax),hits=board.hits,misses=board.misses,clears=board.clears,shallow_bytes=sys.getsizeof(board.syntax)+sum(sys.getsizeof(k)+sys.getsizeof(v)+sys.getsizeof(v[0]) for k,v in board.syntax.items()))
     report['rows'].append(record_value(r));save();print(name,kind,repeat,mode,cls.__name__,r['completed_depth'],round(r['wall_seconds'],3),flush=True)
  for mode in ('full','verified'):
   rows=[x for x in report['rows'] if x['case']==name and x['kind']=='fixed' and x['mode']==mode]
   signature=lambda x:(x['move'],x['score'],x['pv'],x['completed_depth'],x['work'],[(i['move'],i['score'],i['pv'],i['work'],i['candidates']) for i in x['iterations']])
   assert all(signature(x)==signature(rows[0]) for x in rows)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
