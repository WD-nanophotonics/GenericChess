"""36 predeclared finite-D3 controls over six existing supported roots.
Full, deliberately unsafe and exact-verified root windows; two reversed root
traversals; same lexical interior, material, history and packed canonical key.
Each100000entries/30sec fuse shared by any verification. UNKNOWN retained if
capped, no extra search on a capped arm. Chosen-child independentD2 control only
for completed rows, same100000/30sec cap and root-relative mate convention.
This is new exposed feasibility development, not extension of frozen teachers,
strength or product-C repair. Expected under3min, interruptible each call.
"""
from pathlib import Path
from types import SimpleNamespace
from time import perf_counter
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py')}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from scripts.root_bound_diagnostic import root_search
from scripts.search_backend_comparison import minimal_ab
from generic_chess.native.semantic import public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value
out=Path(__file__).with_name('feasibility.json')
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),algorithm_sha256=hashlib.sha256((ROOT/'scripts/root_bound_diagnostic.py').read_bytes()).hexdigest(),rows=[],complete=False)
def save():out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
start=perf_counter()
try:
 for name,factory,values in ns['factories']:
  for reverse,modes in ((False,('full','unsafe','verified')),(True,('verified','unsafe','full'))):
   for mode in modes:
    for f in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{f}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    core=factory();board=NativeBoard(core,values)
    row=root_search(board,3,mode=mode,reverse=reverse,canonical_key=int,node_limit=100000,seconds=30)
    state=core.initial
    for raw in row['pv']:
     move=public_action(board.native,raw);assert move in legal_actions(state,core.compiled);state=apply_action(state,move,core.compiled)
    if row['completed_depth'] and row['action'] is not None:
     board.push(row['action']);child_root=board.position
     try:
      childview=SimpleNamespace(actions=board.actions,push=board.push,pop=board.pop,
          terminal=lambda ply:board.terminal(ply+1),evaluate=board.evaluate,
          restored=lambda:len(board.stack)==2 and board.position is child_root)
      child=minimal_ab(childview,2,seconds=30,node_limit=100000)
      row['child_reference']=child
      row['selected_value_matches']=None if child['reason']!='completed_depth' else row['score']==-child['score']
     finally:board.pop()
    assert board.restored() and core.restored()
    row.update(case=name,mode=mode,reverse=reverse,pv_legal=True)
    report['rows'].append(record_value(row));save();print(name,mode,reverse,row['move'],row['score'],row['work']['nodes'],row.get('selected_value_matches'),flush=True)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
