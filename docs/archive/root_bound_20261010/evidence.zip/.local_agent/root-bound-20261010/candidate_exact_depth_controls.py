"""Actual isolated exact-root C candidate controls; active product is unchanged.
Predeclare6existing roots, D3/100000entries/30s shared fuse, full/narrow windows,
TT0/64 and two repeated calls on the same persistent engine. Add TT0 min/max
root-action hints (24calls) to change traversal without changing canonical key.
Full Python root values/actions are existing finite-development references, not
new labels or frozen-budget extension. Normalized mate constant differs1e9/1e8.
Every returned PV is Core-legal; actual compiled root snapshot is unchanged.
Expected<2min, no extra workers. No guard bypass in active production imports:
the experimental C entry is called directly only inside this isolated process.
"""
from pathlib import Path
import sys,importlib.util,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
binary=next(Path(__file__).with_name('candidate-exact-depth').glob('_native_core*.pyd'))
spec=importlib.util.spec_from_file_location('generic_chess._native_core',binary);kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
import generic_chess.native as native
native._MODULE=kernel
ns={'__file__':str(ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py')}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native.semantic import public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
reference=json.loads(Path(__file__).with_name('feasibility.json').read_bytes())
expected={r['case']:r for r in reference['rows'] if r['mode']=='full' and not r['reverse']}
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),reference_sha256=hashlib.sha256(Path(__file__).with_name('feasibility.json').read_bytes()).hexdigest(),rows=[],complete=False)
output=Path(__file__).with_name('candidate-exact-depth-controls.json')
def save():output.write_text(json.dumps(report,indent=2)+'\n')
def stopped():
 for flag in ('rollout','advisor','slack'):
  f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
def evaluate(name,core,board,engine,window,tt,repeat,hint):
 stopped();r=dict(kernel.semantic_engine_search(engine._capsule,board.position,3,100000,30,None,hint,window,False))
 state=core.initial
 for action in r['principal_variation']:
  move=public_action(board.native,int(action));assert move in legal_actions(state,core.compiled);state=apply_action(state,move,core.compiled)
 assert board.restored();r.update(case=name,window=window,tt=tt,repeat=repeat,hint=hint,pv_legal=True,root_restored=True,move=core.label(public_action(board.native,r['best_action'])))
 wanted=expected[name];score=wanted['score'];normalized=score if abs(score)<100000000 else (1 if score>0 else -1)*(100000000-(1000000000-abs(score)))
 r['expected_score']=normalized;r['expected_action']=wanted['action'];r['exact_reference_match']=r['score']==normalized and r['best_action']==wanted['action']
 report['rows'].append(r);save();print(name,window,tt,repeat,hint,r['move'],r['score'],r['nodes'],r['exact_reference_match'],flush=True)
 # Preserve all declared cells, including mismatches/caps/errors.
start=perf_counter()
try:
 for name,factory,values in ns['factories']:
  for tt in (0,64):
   for window in (False,True):
    core=factory();board=NativeBoard(core,values);engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=tt)
    for repeat in (0,1):evaluate(name,core,board,engine,window,tt,repeat,None)
  for hint_kind in ('min','max'):
   for window in (False,True):
    core=factory();board=NativeBoard(core,values);hint=(min if hint_kind=='min' else max)(raw for _,raw in board.actions())
    engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=0)
    evaluate(name,core,board,engine,window,0,0,hint)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
