"""Change the premise explicitly: root AND interior traversal order.
All four direction combinations on existing EP D3, full/unsafe/verified, same
100000/30sec shared caps. No outcome-driven permutation search or teacher fit.
Question: does equal-bound replacement depend on the concrete interior frontier?
"""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CoreBoard,CASES,VALUES
from scripts.native_backend_bridge import NativeBoard
from scripts.root_bound_diagnostic import root_search
rows=[]
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
for root_reverse in (False,True):
 for interior_reverse in (False,True):
  for mode in ('full','unsafe','verified'):
   core=CoreBoard(CASES[3],c);board=NativeBoard(core,VALUES['chess'])
   r=root_search(board,3,mode=mode,reverse=root_reverse,reverse_interior=interior_reverse,canonical_key=int)
   r.update(mode=mode,root_reverse=root_reverse,interior_reverse=interior_reverse)
   rows.append(r);print(mode,root_reverse,interior_reverse,r['move'],r['score'],r['work']['nodes'],flush=True)
Path(__file__).with_name('order-premise.json').write_bytes((json.dumps(dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows),indent=2)+'\n').encode())
