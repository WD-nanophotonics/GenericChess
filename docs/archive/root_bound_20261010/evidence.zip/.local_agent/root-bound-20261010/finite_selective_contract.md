# Finite control versus selective search

Retrieved2026-10-10 from pinned Stockfish17.1 source:
https://raw.githubusercontent.com/official-stockfish/Stockfish/sf_17.1/src/search.cpp

The non-PV TT cutoff uses stored depth exceeding a threshold derived from
requested depth, combined with bound and cut-node conditions (lines640-661).
The same implementation applies singular extensions and late-move reductions
(lines1009-1130). This is primary evidence for a selective search implementation,
not proof that every reported completed depth denotes a uniform material-only
finite-horizon minimax value. Inference: our strict no-TT/q0 finite controls and
mature-engine overall references have distinct contracts. The observed local
warm-TT disagreements therefore motivate attribution controls, not a universal
claim that deeper cached entries are illegitimate in useful engines.

For our exact finite diagnostic, different-depth heuristic scores are not
bounds on the requested horizon: the existing middle control has V1=200,
V2=-100,V3=100. Candidate equality isolates that mismatch, but rule/evaluator,
history, q/extensions, mate-distance normalization and completion remain relevant.
Do not describe old warm64 results as uniform VD or as useless playing decisions.
No third-party source copied into this archive; no mature-engine tests rerun.
