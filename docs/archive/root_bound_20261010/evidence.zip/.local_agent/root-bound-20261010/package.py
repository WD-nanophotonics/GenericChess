from pathlib import Path
import hashlib,json,re,zipfile
root=Path.cwd();d=root/'.local_agent/root-bound-20261010'
# Explicit purpose selection, never collect local transport/question/binaries/tests' temp files.
files=[p for p in d.iterdir() if p.is_file() and p.suffix in ('.py','.json','.md','.log')]
for folder in ('candidate','candidate-exact-depth','candidate-observed','candidate-product'):
 files += [p for p in (d/folder).rglob('*') if p.is_file() and (p.suffix in ('.c','.h','.py') or p.name=='baseline_native_module.c.txt')]
extra=['scripts/root_bound_diagnostic.py','tests/development/test_root_bound_diagnostic.py','scripts/native_backend_bridge.py','scripts/search_backend_comparison.py','scripts/research_record.py','.local_agent/native-terminal-20261010/syntax_ablation.py','.local_agent/native-terminal-20261010/bridge_assay.py','.local_agent/generated6-20261008/coverage.json','.local_agent/search-attribution-20261010/utility.json']
files += [root/f for f in extra];files=sorted(set(files))
blobs={p.relative_to(root).as_posix():p.read_bytes() for p in files}
for name,data in blobs.items():
 assert '/slack/' not in name and not re.search(rb'(xox[baprs]-[A-Za-z0-9-]+|\b[CU]0[A-Z0-9]{9}\b|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+[.]com)',data),name
 assert not any(part in name for part in ('dot-question','.pyd','.pdb'))
archive=root/'docs/archive/root_bound_20261010/evidence.zip';archive.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in blobs.items():z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(blobs)
 for name,data in blobs.items():assert z.read(name)==data
index=dict(schema=1,base_commit='70a1744fecd3a4b0314bfc4ea253341b2c64d520',scope='Agent-produced exposed development, exact contender verification, finite/selective cache contract and supported backend costs. No user-private inputs, raw Slack/account records, credentials or binaries.',archive=archive.relative_to(root).as_posix(),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in blobs.items()},source_boundaries=dict(active='Product/kernel restored to base; defaultOFF and ON guard unchanged. Only new root diagnostic and its tests are active development sources.',algorithm='algorithm-before-order matches first feasibility exact source; algorithm-executed preserves subsequent execution source. Tracked source normalizes trailing CRLF only; same behavior retested.',executed_candidates='First candidate plus exact-depth and metrics-only variants actually built/imported/tested separately; final product differs and failed fresh import. Hashes in build JSON. Not deployed.',blocked_product='candidate-product contains only final source/wrappers/tests; final Windows App Control failure preserved. No candidate automatic installation or security workaround. Terminal-v5 separate.',source_closure='Candidate folders include exact C/H dependencies; runner factories/generated roots/frozen utility inputs included. Remaining tracked dependencies pinned to base; recover into isolated checkout only.'),counts=dict(feasibility=36,order_audit=12,first_C_declared=72,second_C_declared=72,interruption_tie_cancel=6,warm_depth=48,python_scheduling=48,syntax_interaction=48,profiles=4,pv_leaf=12,transient_calls=24,transient_states=3974,successor_calls=24,corrected_backend=52,corrected_fixed=26,corrected_resource_capped=26),validation=json.loads((d/'validation.json').read_bytes()),decisions=dict(candidate='Deferred final deployment; public ON remains guarded.',transient='Scoped diagnostic retained, no product adoption/full-domain claim.',successor='Reject tested128 capacity: wall worsens14.6-40.0percent, depth unchanged.',backend='Same corrected algorithm retains distinct backend completion/cost; precise finite utility plus unknown coverage only.',next='Remaining terminal/frontier costs and semantic transfer; approved kernel execution needed before considering ON.'))
(root/'docs/research/data/root_bound_20261010.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(members=len(blobs),archive_bytes=archive.stat().st_size,sha256=index['archive_sha256'])))
