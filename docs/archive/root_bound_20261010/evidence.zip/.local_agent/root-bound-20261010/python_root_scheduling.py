"""Supported full Native state plus Python root-scheduling comparison.
Six existing roots, full/verified exact-canonical root modes, same lexical interior,
material/q0/noTT/fullhistory. Fixed4096 entry shared cap then1second/D12/100000
shared fuse; two fresh reverse arm orders per root. Same named entry metric is
not the same visited work. No dynamic features, evaluator fit or new teacher.
Iterations share ORIGINAL remaining time/nodes, completed results publish only
after full root scan. Before D1 completion use the same first-legal fallback.
All partial candidates/costs kept, no silent cap growth. Expected<1min.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py')}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.root_bound_diagnostic import root_search
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),algorithm_sha256=hashlib.sha256((ROOT/'scripts/root_bound_diagnostic.py').read_bytes()).hexdigest(),rows=[],complete=False)
output=Path(__file__).with_name('python-root-scheduling.json')
def save():output.write_text(json.dumps(report,indent=2)+'\n')
def iterative(board,mode,seconds,limit):
 first=board.actions()[0];start=perf_counter();total={};iterations=[];completed=None
 for depth in range(1,13):
  remaining=limit-total.get('nodes',0);left=seconds-(perf_counter()-start)
  r=root_search(board,depth,mode=mode,canonical_key=int,node_limit=remaining,seconds=left)
  for k,v in r['work'].items():total[k]=total.get(k,0)+v
  iterations.append(r)
  if r['completed_depth']==0:break
  completed=r
 elapsed=perf_counter()-start
 assert total['nodes']<=limit and board.restored()
 return dict(mode=mode,move=completed['move'] if completed else first[0],action=completed['action'] if completed else first[1],score=completed['score'] if completed else None,pv=completed['pv'] if completed else (first[1],),completed_depth=completed['completed_depth'] if completed else 0,used_fallback=completed is None,iterations=iterations,work=total,wall_seconds=elapsed,cap_nodes=limit,cap_seconds=seconds)
start=perf_counter()
try:
 for name,factory,values in ns['factories']:
  for kind in ('fixed','timed'):
   for repeat,order in enumerate((('full','verified'),('verified','full'))):
    for mode in order:
     for flag in ('rollout','advisor','slack'):
      f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
     core=factory();board=NativeBoard(core,values);r=iterative(board,mode,30 if kind=='fixed' else 1,4096 if kind=='fixed' else 100000)
     state=core.initial
     for raw in r['pv']:
      move=public_action(board.native,raw);assert move in legal_actions(state,core.compiled);state=apply_action(state,move,core.compiled)
     assert board.restored() and core.restored();r.update(case=name,kind=kind,repeat=repeat,pv_legal=True,root_restored=True)
     report['rows'].append(record_value(r));save();print(name,kind,repeat,mode,r['completed_depth'],r['work']['nodes'],r['move'],flush=True)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
