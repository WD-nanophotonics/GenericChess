"""Posthoc semantic audit of all12 frozen order-premise rows; no changed runs.
Selected-child independent completeD2 uses root-relative mate and same100000/30s
cap. All PV actions are replayed through Core legality. False report is retained.
"""
from pathlib import Path
from types import SimpleNamespace
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CoreBoard,CASES,VALUES,minimal_ab
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
input_path=Path(__file__).with_name('order-premise.json');source=json.loads(input_path.read_bytes());rows=[]
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
for row in source['rows']:
 core=CoreBoard(CASES[3],c);board=NativeBoard(core,VALUES['chess']);state=core.initial
 for raw in row['pv']:
  move=public_action(board.native,raw);assert move in legal_actions(state,c);state=apply_action(state,move,c)
 board.push(row['action']);child_root=board.position
 try:
  view=SimpleNamespace(actions=board.actions,push=board.push,pop=board.pop,terminal=lambda ply:board.terminal(ply+1),evaluate=board.evaluate,restored=lambda:len(board.stack)==2 and board.position is child_root)
  result=minimal_ab(view,2,seconds=30,node_limit=100000)
 finally:board.pop()
 assert board.restored() and result['reason']=='completed_depth'
 rows.append(dict(mode=row['mode'],root_reverse=row['root_reverse'],interior_reverse=row['interior_reverse'],move=row['move'],reported=row['score'],exact_selected_child=-result['score'],match=row['score']==-result['score'],pv_legal=True,reference=result))
print([(r['mode'],r['root_reverse'],r['interior_reverse'],r['move'],r['match']) for r in rows])
Path(__file__).with_name('order-audit.json').write_text(json.dumps(dict(declaration=__doc__,input_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')
