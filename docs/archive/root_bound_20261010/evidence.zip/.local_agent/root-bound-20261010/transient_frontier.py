"""Existing transient-frontier API crossed with corrected Python root scheduler.
Question: does omitting unused trial child key/history construction in legal
frontier improve actual completion? Real pushes still use make_checked full-state,
terminal unchanged full-history; no terminal reconstruction, board-only key,
C build, TT, declaration, feature or q change. Scoped EP/generated2000/2001.
First every-child D2 Core/Native full-state audit. Same verified scheduler/cache,
fixed4096 sharedentries and1sec/100000/D12, two reversed orders. Predicted<1min;
any fixed signature mismatch rejects, all timed adverse/unknown retained.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('python_root_scheduling.py'))}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('start=perf_counter()\ntry:')[0],ns)
fns=ns['ns'];CachedSyntax=fns['CachedSyntax']
from generic_chess.native.semantic import transient_legal_actions,public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.native_backend_bridge import audit_native_tree
from scripts.research_record import record_value
class TransientSyntax(CachedSyntax):
 def actions(self):
  result=[]
  for raw in transient_legal_actions(self.native,self.position):
   entry=self.syntax.get(raw)
   if entry is None:
    self.misses+=1;entry=(self.label(public_action(self.native,raw)),raw)
    if len(self.syntax)>=2048:self.syntax.clear();self.clears+=1
    self.syntax[raw]=entry
   else:self.hits+=1
   result.append(entry)
  return sorted(result,key=lambda x:x[0])
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),audits=[],rows=[],complete=False)
output=Path(__file__).with_name('transient-frontier.json')
def save():output.write_text(json.dumps(report,indent=2)+'\n')
start=perf_counter()
try:
 for name,factory,values in fns['factories'][3:]:
  core=factory();board=TransientSyntax(core,values);states=audit_native_tree(core,board,2);report['audits'].append(dict(case=name,states=states));save()
  for kind in ('fixed','timed'):
   for repeat,order in enumerate(((CachedSyntax,TransientSyntax),(TransientSyntax,CachedSyntax))):
    for cls in order:
     for flag in ('rollout','advisor','slack'):
      f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
     core=factory();board=cls(core,values);r=ns['iterative'](board,'verified',30 if kind=='fixed' else 1,4096 if kind=='fixed' else 100000)
     state=core.initial
     for raw in r['pv']:
      action=public_action(board.native,raw);assert action in legal_actions(state,core.compiled);state=apply_action(state,action,core.compiled)
     r.update(case=name,kind=kind,repeat=repeat,backend=cls.__name__,pv_legal=True,root_restored=board.restored() and core.restored(),cache=dict(entries=len(board.syntax),hits=board.hits,misses=board.misses,clears=board.clears))
     assert r['root_restored'];report['rows'].append(record_value(r));save();print(name,kind,repeat,cls.__name__,r['completed_depth'],round(r['wall_seconds'],3),flush=True)
  rows=[x for x in report['rows'] if x['case']==name and x['kind']=='fixed']
  signature=lambda x:(x['move'],x['score'],x['pv'],x['completed_depth'],x['work'],[(i['move'],i['score'],i['pv'],i['work'],i['candidates']) for i in x['iterations']])
  assert all(signature(x)==signature(rows[0]) for x in rows)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
