"""Actual C shared-budget interruption, true ties and cancel/recovery controls.
Metrics-only candidate differs from exact-depth candidate by4uint64 counters.
For EP/generated2000, record complete D3 last contender-rescan entry, then cap
that same cold TT0 run at entry+1; require incompleteD3 and exact previousD2
score/action/PV. No cap expansion. Chess zero-material D1 with maximum packed
root hint establishes a genuine tie requiring canonical replacement. Pre-cancel
then recovery verifies original root remains usable. Scoped q0/material only.
"""
from pathlib import Path
import sys,importlib.util,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
binary=next(Path(__file__).with_name('candidate-observed').glob('_native_core*.pyd'))
spec=importlib.util.spec_from_file_location('generic_chess._native_core',binary);kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
import generic_chess.native as native
native._MODULE=kernel
ns={'__file__':str(ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py')}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native.semantic import public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
rows=[]
def run(factory,values,depth,cap=100000,tt=0,flag=None,hint=None):
 core=factory();board=NativeBoard(core,values);engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=tt)
 r=dict(kernel.semantic_engine_search(engine._capsule,board.position,depth,cap,30,flag,hint,True,False))
 state=core.initial
 for action in r['principal_variation']:
  move=public_action(board.native,int(action));assert move in legal_actions(state,core.compiled);state=apply_action(state,move,core.compiled)
 assert board.restored();r.update(pv_legal=True,root_restored=True,cap=cap)
 return r
for name,factory,values in ns['factories']:
 if name not in ('chess-ep','generated-202610082000-ply3'):continue
 full=run(factory,values,3);previous=run(factory,values,2)
 assert full['completed_depth']==3 and full['last_root_verification_depth']==3
 cap=full['last_root_verification_start_nodes']+1
 partial=run(factory,values,3,cap)
 assert partial['nodes']==cap and partial['termination_reason']=='node_budget'
 assert partial['last_root_verification_depth']==3 and partial['completed_depth']==2
 assert (partial['score'],partial['best_action'],partial['principal_variation'])==(previous['score'],previous['best_action'],previous['principal_variation'])
 rows.append(dict(case=name,complete=full,previous=previous,interrupted=partial));print(name,cap,full['nodes'],partial['completed_depth'],flush=True)
name,factory,values=ns['factories'][0];zero={k:0 for k in values}
board=NativeBoard(factory(),zero);small=min(raw for _,raw in board.actions());large=max(raw for _,raw in board.actions())
for tt in (0,64):
 tied=run(factory,zero,1,tt=tt,hint=large)
 assert tied['best_action']==small and tied['score']==0 and tied['root_verifications']>0
 rows.append(dict(case='true-canonical-tie',tt=tt,minimum=small,maximum=large,result=tied))
 flag=kernel.create_cancel_flag();kernel.request_cancel(flag)
 cancelled=run(factory,zero,3,tt=tt,flag=flag)
 assert cancelled['termination_reason']=='cancelled' and cancelled['completed_depth']==0
 recovered=run(factory,zero,1,tt=tt,hint=large)
 assert recovered['score']==0 and recovered['best_action']==small
 rows.append(dict(case='pre-cancel-recovery',tt=tt,cancelled=cancelled,recovered=recovered))
Path(__file__).with_name('candidate-interruption.json').write_text(json.dumps(dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),rows=rows,complete=True),indent=2)+'\n')
print('C interrupted rescan and true ties passed',len(rows))
