"""Replay saved warm-depth PVs only; no new search or oracle budget.
48 existing complete calls. Retain actual PV length/terminal and actual material
leaf even when the declared uniform horizon is ineligible; distinguish literal
PV score consistency from finite-horizon eligibility. Legal PV reconstruction is
not a max/all-defense proof. Decision: is warm cache merely different depth, or
also an observed selected-line/report mismatch? Full histories and mate convention.
"""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py')}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import public_action,guarded_actions
from scripts.research_record import record_value
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
source=Path(__file__).with_name('restored-warm-depth.json');data=json.loads(source.read_bytes());factories={n:(f,v) for n,f,v in ns['factories']};rows=[]
for r in data['rows']:
 f,v=factories[r['case']];core=f();board=NativeBoard(core,v);state=core.initial;ply=0
 for saved in r['principal_variation']:
  raw=next(x for x in guarded_actions(board.native,board.position) if record_value(public_action(board.native,x))==saved)
  move=public_action(board.native,raw);assert move in legal_actions(state,core.compiled);state=apply_action(state,move,core.compiled);board.push(raw);ply+=1
 terminal=board.terminal(ply);leaf=terminal if terminal is not None else board.evaluate()
 if abs(leaf)>100000000:leaf=(1 if leaf>0 else -1)*(100000000-(1000000000-abs(leaf)))
 actual=leaf*(-1 if ply%2 else 1)
 while len(board.stack)>1:board.pop()
 assert board.restored()
 rows.append(dict(case=r['case'],tt=r['tt'],sequence_index=r['sequence_index'],requested_depth=r['requested_depth'],completed_depth=r['completed_depth'],score=r['score'],pv_length=ply,pv_terminal=terminal is not None,pv_leaf_root_value=actual,literal_leaf_match=actual==r['score'],finite_horizon_eligible=terminal is not None or ply==r['completed_depth'],pv_legal=True,root_restored=True))
out=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),rows=rows,complete=True)
Path(__file__).with_name('warm-pv-replay.json').write_text(json.dumps(out,indent=2)+'\n')
print('rows',len(rows),'literal mismatches',sum(not r['literal_leaf_match'] for r in rows),'horizon ineligible',sum(not r['finite_horizon_eligible'] for r in rows));print([r for r in rows if not r['literal_leaf_match']])
