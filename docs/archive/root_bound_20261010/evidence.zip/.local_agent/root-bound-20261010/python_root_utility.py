from pathlib import Path
import json,hashlib
source=Path('.local_agent/root-bound-20261010/python-root-scheduling.json');x=json.loads(source.read_bytes())
p=Path('.local_agent/search-attribution-20261010/utility.json');u=json.loads(p.read_bytes());known={(r['case'],r['move']):r['finite_D4_regret'] for r in u['rows'] if r.get('finite_D4_regret') is not None}
rows=[dict(case=r['case'],kind=r['kind'],repeat=r['repeat'],mode=r['mode'],move=r['move'],completed_depth=r['completed_depth'],finite_D4_regret=known.get((r['case'],r['move']))) for r in x['rows']]
Path('.local_agent/root-bound-20261010/python-root-utility.json').write_text(json.dumps(dict(basis='Reaggregation only; frozen utility data, unmatched/generated UNKNOWN, no teacher/cap growth',input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),utility_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')
print('Known',len([r for r in rows if r['finite_D4_regret'] is not None]),'of',len(rows));print([(r['kind'],r['mode'],r['move'],r['finite_D4_regret']) for r in rows if r['case']=='chess-ep'])
