"""Restored supported product: explicit deep-to-shallow warm TT semantics.
Three existing roots middle/EP/generated2000, material/q0/absent features/fullOFF.
For each, independent full Native-state/Python reference at D1,D2,D3; same100000
entry/30s fuse. Native persistent TT0/64 searches depth sequence3,1,2,3 twice;
all48calls and mismatches retained. Completed depth is an execution metric, not
assumed finite-depth value under the restored old TT rule. No frozen extension,
fit or new labels. Bounded expected<1min; installed v4, no new binary execution.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py')}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from scripts.root_bound_diagnostic import root_search
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.unfamiliar_search import validate_pv
from dataclasses import asdict
from scripts.research_record import record_value
from generic_chess.native import _module
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(Path(_module().__file__).read_bytes()).hexdigest(),references=[],rows=[],complete=False)
output=Path(__file__).with_name('restored-warm-depth.json')
def save():output.write_text(json.dumps(report,indent=2)+'\n')
start=perf_counter()
try:
 for name,factory,values in ns['factories']:
  if name not in ('chess-middle','chess-ep','generated-202610082000-ply3'):continue
  refs={}
  for depth in (1,2,3):
   board=NativeBoard(factory(),values);r=root_search(board,depth,mode='full',canonical_key=int,node_limit=100000,seconds=30)
   refs[depth]=r;report['references'].append(dict(case=name,depth=depth,reference=r));save()
  for tt in (0,64):
   core=factory();board=NativeBoard(core,values);engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=tt)
   session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
   for index,depth in enumerate((3,1,2,3,3,1,2,3)):
    for flag in ('rollout','advisor','slack'):
     f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
    result=engine.search(session,SearchLimits(max_depth=depth,max_nodes=100000,max_time_seconds=30,quiescence_max_depth=0),root_window_pruning=False)
    validate_pv(session,result);assert board.restored() and session.state==core.initial
    row=record_value(asdict(result));ref=refs[depth];score=ref['score'];expected=score if abs(score)<100000000 else (1 if score>0 else -1)*(100000000-(1000000000-abs(score)))
    row.update(case=name,tt=tt,sequence_index=index,requested_depth=depth,move=core.label(result.action),expected_move=ref['move'],expected_score=expected,finite_match=result.score==expected and core.label(result.action)==ref['move'],pv_legal=True,root_restored=True)
    report['rows'].append(row);save();print(name,tt,index,depth,row['move'],row['score'],row['finite_match'],flush=True)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
