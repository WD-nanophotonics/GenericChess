"""Profile corrected root scheduler, same4096 entry cap, no timed conclusions.
Existing EP/generated2000; bare versus immutable syntax reuse. cProfile overhead
is measured workload evidence, not production throughput. Count calls and direct
C time separately; do not sum inclusive times. Decision: locate remaining
conversion/frontier/terminal/replay costs before another interface investment.
"""
from pathlib import Path
import sys,json,cProfile,pstats,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('python_root_scheduling.py'))}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('start=perf_counter()\ntry:')[0],ns)
from scripts.research_record import record_value
fns=ns['ns'];rows=[]
for name,factory,values in [fns['factories'][3],fns['factories'][4]]:
 for cls in (ns['NativeBoard'],fns['CachedSyntax']):
  board=cls(factory(),values);p=cProfile.Profile();r=p.runcall(ns['iterative'],board,'verified',30,4096)
  s=pstats.Stats(p)
  calls=[dict(file=f[0],line=f[1],name=f[2],primitive_calls=v[0],total_calls=v[1],direct_seconds=v[2],inclusive_seconds=v[3]) for f,v in s.stats.items()]
  calls.sort(key=lambda x:x['direct_seconds'],reverse=True)
  rows.append(record_value(dict(case=name,backend=cls.__name__,result=r,profile_total_seconds=s.total_tt,calls=calls)))
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,complete=True)
Path(__file__).with_name('verified-profile.json').write_text(json.dumps(report,indent=2)+'\n')
for r in rows:print(r['case'],r['backend'],r['result']['completed_depth'],[(x['name'],round(x['direct_seconds'],3),x['total_calls']) for x in r['calls'][:8]])
