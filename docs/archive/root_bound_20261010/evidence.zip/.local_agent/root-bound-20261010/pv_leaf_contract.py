"""Current supported full-root Native PV-leaf consistency, not an oracle extension.
Six existing roots, D4/100000entry/30s fuse, TT0 or fresh64, fullOFF/material/q0.
Replay entire returned PV on Native fullstate and Core legality. If terminal or
PV length equals completed depth, compare the actual root-relative leaf value
with reported score; shorter nonterminal lines UNKNOWN. Retain all caps/errors.
This cheaply tests selected line/value relation; it does not prove all defenses,
optimal choice or general search validity. No changed teacher/sample budget.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py')}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import semantic_iterative_search,public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=Path(__file__).with_name('pv-leaf-contract.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n')
start=perf_counter()
try:
 for name,factory,values in ns['factories']:
  for tt in (0,64):
   for flag in ('rollout','advisor','slack'):
    f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
   core=factory();board=NativeBoard(core,values)
   r=semantic_iterative_search(board.native,board.position,4,max_nodes=100000,max_time_seconds=30,board_values=values,hand_values=values,tt_megabytes=tt,root_window_pruning=False)
   state=core.initial;ply=0
   try:
    for raw in r['principal_variation']:
     move=public_action(board.native,raw);assert move in legal_actions(state,core.compiled);state=apply_action(state,move,core.compiled)
     board.push(raw);ply+=1
    terminal=board.terminal(ply)
    if terminal is not None or ply==r['completed_depth']:
     leaf=terminal if terminal is not None else board.evaluate()
     if abs(leaf)>100000000:leaf=(1 if leaf>0 else -1)*(100000000-(1000000000-abs(leaf)))
     actual=leaf*(-1 if ply%2 else 1);matches=actual==r['score']
    else:actual=None;matches=None
   finally:
    while len(board.stack)>1:board.pop()
   assert board.restored();r.update(case=name,tt=tt,pv_leaf_root_value=actual,pv_value_match=matches,pv_legal=True,root_restored=True)
   report['rows'].append(r);save();print(name,tt,r['completed_depth'],r['termination_reason'],r['score'],actual,matches,flush=True)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
