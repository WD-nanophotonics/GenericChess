"""Isolated source candidate for exact root replacements; never overwrites product.
Changed premise is the experimentally reproduced root-bound defect, not a build
retry of terminal-v5. Root contender verification uses existing shared context,
full PV window and pv_replay=1 (no TT probe); all potential replacements, not
only ties, are verified. Interrupted iteration remains uncommitted by existing
outer loop. Replay mismatch at root is an error, not a false completed score.
This candidate is NOT accepted unless a fresh actual import/test succeeds.
"""
from pathlib import Path
import json,hashlib,subprocess,sys,sysconfig,os
ROOT=Path(__file__).resolve().parents[2];out=Path(__file__).with_name('candidate-exact-depth');out.mkdir(exist_ok=True)
original=ROOT/'generic_chess/_native/native_module.c';source=original.read_text()
needle='''        if (!found || score > best || prefer_equal) {
            found = 1;
            best = score;'''
replacement='''        /* A narrowed root child may return only a bound. Canonical equal
         * replacement cannot promote that bound to an exact incumbent. Verify
         * every contender before installation, using this SAME budget/context.
         * pv_replay disables TT probes throughout this independent full pass. */
        if (ply == 0 && ctx->root_window_pruning && !root_first_child &&
            found && (score > best || prefer_equal)) {
            branch = gc_semantic_iterative_negamax(
                ctx, ply + 1, depth - 1, -GC_SEMANTIC_PROBE_INF,
                GC_SEMANTIC_PROBE_INF, 1, 1);
            if (ctx->control != 0) break;
            score = -branch;
            prefer_equal = score == best &&
                ((!gc_semantic_is_declaration_action(best_action) &&
                  gc_semantic_is_declaration_action(action)) ||
                 (!gc_semantic_is_declaration_action(action) &&
                  !gc_semantic_is_declaration_action(best_action) &&
                  action < best_action));
        }
        if (!found || score > best || prefer_equal) {
            found = 1;
            best = score;'''
assert source.count(needle)==1;source=source.replace(needle,replacement)
needle2='''        (void)branch;
        ctx->pv_table[(size_t)ply * ctx->pv_stride] = best_action;'''
replace2='''        if (ply == 0 && -branch != best) {
            /* Do not commit a root score contradicted by its exact PV replay.
             * Existing outer iteration rollback retains the last completion. */
            ctx->control = 4;
            return 0;
        }
        ctx->pv_table[(size_t)ply * ctx->pv_stride] = best_action;'''
assert source.count(needle2)==1;source=source.replace(needle2,replace2)
assert source.count('if (!pv_node && stored_depth >= (int)depth)')==1
source=source.replace('if (!pv_node && stored_depth >= (int)depth)', 'if (!pv_node && stored_depth == (int)depth)')
for p in (ROOT/'generic_chess/_native').iterdir():
 if p.suffix in ('.c','.h'): (out/p.name).write_bytes(p.read_bytes())
(out/'native_module.c').write_text(source,encoding='utf-8',newline='\n')
(out/'baseline_native_module.c.txt').write_bytes(original.read_bytes())
binary=out/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
command=[str(ROOT/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython'+str(sys.version_info.major)+str(sys.version_info.minor)]
command += [str(p) for p in sorted(out.glob('*.c'))]+['-o',str(binary)]
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.gc_zig_cache'))
r=subprocess.run(command,capture_output=True,text=True,env=env,timeout=180)
record=dict(declaration=__doc__,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),baseline_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((out/'native_module.c').read_bytes()).hexdigest(),command=command,build_returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.c')},installed_source_unchanged=hashlib.sha256(original.read_bytes()).hexdigest()==hashlib.sha256((out/'baseline_native_module.c.txt').read_bytes()).hexdigest())
if r.returncode==0:
 record['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();record['binary_bytes']=binary.stat().st_size
 code='import importlib.util; p='+repr(str(binary))+'; s=importlib.util.spec_from_file_location("generic_chess._native_core",p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); print("ACTUAL_IMPORT_OK")'
 imported=subprocess.run([sys.executable,'-c',code],capture_output=True,text=True,timeout=20)
 record['import_returncode']=imported.returncode;record['import_stdout']=imported.stdout;record['import_stderr']=imported.stderr
Path(__file__).with_name('candidate-exact-depth-build.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('command','sources')},indent=2))
