"""Bounded full immutable successor reuse for corrected Native-state scheduler.
New premise: repeated iterative/verification paths can reuse actual complete child
capsules, keyed by the exact parent capsule and raw action, not board-only digest.
Cache retains keys so identities cannot be recycled;128 entries, clear-on-full,
fresh per call. A position is53920 C bytes, so retained unique capsules and shallow
Python bytes are reported (allocator/process overhead excluded). Baseline0 versus
128 is a memory/result tradeoff, not equal-memory proof. Real first miss uses
make_checked with complete history; no terminal/q/frontier/price changes. Existing
EP/generated2000/2001; D2 every-child state/history audit then fixed4096 and1sec
with two reverse orders. No labels/oracle/cap expansion. Expected<1min. Decision:
retain only if fixed signatures equal and real transition reduction aids cost.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('transient_frontier.py'))}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
TransientSyntax=ns['TransientSyntax'];fns=ns['fns']
from generic_chess.native.semantic import make_checked,search_runtime_sizes,public_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.native_backend_bridge import audit_native_tree
from scripts.research_record import record_value
class SuccessorReuse(TransientSyntax):
 def __init__(self,*args):
  super().__init__(*args);self.successors={};self.successor_hits=0;self.successor_misses=0;self.successor_clears=0
 def push(self,raw):
  key=(self.position,raw);child=self.successors.get(key)
  if child is None:
   self.successor_misses+=1;child=make_checked(self.native,self.position,raw)
   if len(self.successors)>=128:self.successors.clear();self.successor_clears+=1
   self.successors[key]=child
  else:self.successor_hits+=1
  self.stack.append(child)
 def reuse_cost(self):
  capsules=set(self.stack)
  for (parent,raw),child in self.successors.items():capsules.update((parent,child))
  return dict(limit_entries=128,entries=len(self.successors),hits=self.successor_hits,misses=self.successor_misses,clears=self.successor_clears,retained_capsules=len(capsules),retained_position_C_bytes=len(capsules)*search_runtime_sizes()['position_bytes'],shallow_Python_bytes=sys.getsizeof(self.successors)+sum(sys.getsizeof(k)+sys.getsizeof(v) for k,v in self.successors.items()))
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),audits=[],rows=[],complete=False)
output=Path(__file__).with_name('successor-reuse.json')
def save():output.write_text(json.dumps(report,indent=2)+'\n')
start=perf_counter()
try:
 for name,factory,values in fns['factories'][3:]:
  core=factory();board=SuccessorReuse(core,values);report['audits'].append(dict(case=name,states=audit_native_tree(core,board,2),cache=board.reuse_cost()));save()
  for kind in ('fixed','timed'):
   for repeat,order in enumerate(((TransientSyntax,SuccessorReuse),(SuccessorReuse,TransientSyntax))):
    for cls in order:
     for flag in ('rollout','advisor','slack'):
      f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
     core=factory();board=cls(core,values);r=ns['ns']['iterative'](board,'verified',30 if kind=='fixed' else 1,4096 if kind=='fixed' else 100000)
     state=core.initial
     for raw in r['pv']:
      action=public_action(board.native,raw);assert action in legal_actions(state,core.compiled);state=apply_action(state,action,core.compiled)
     r.update(case=name,kind=kind,repeat=repeat,backend=cls.__name__,pv_legal=True,root_restored=board.restored() and core.restored(),actual_make_checked=board.successor_misses if cls is SuccessorReuse else r['work']['pushes'])
     if cls is SuccessorReuse:r['reuse']=board.reuse_cost()
     assert r['root_restored'];report['rows'].append(record_value(r));save();print(name,kind,repeat,cls.__name__,r['completed_depth'],r['actual_make_checked'],round(r['wall_seconds'],3),flush=True)
  rows=[x for x in report['rows'] if x['case']==name and x['kind']=='fixed']
  sig=lambda x:(x['move'],x['score'],x['pv'],x['completed_depth'],x['work'],[(i['move'],i['score'],i['pv'],i['work'],i['candidates']) for i in x['iterations']])
  assert all(sig(x)==sig(rows[0]) for x in rows)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
