"""Same corrected root scheduler across supported backend adapters.
Existing Chess middle/promotion/EP: Core, Native transient+immutable syntax,
python-chess; Shogi tactic/drop: Core,cshogi strict history (Native no-move-loss
unsupported). Common lexical interior and root canonical labels, material/q0/noTT,
full histories. Fix4096 entries with30s fuse versus1second/D12/100000; two reverse
orders. Complete previous iterations only; first-legal fallback ifD1 incomplete.
Node metric identical here but real backend transition/query costs distinct.
No mature-engine or new utility/oracle calls. Estimated below2min. Decision:
can corrected scheduler/cheaper Native frontier close specialized completion gap,
or does backend remain a separate investment? Retain adverse and timed jitter.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
ns={'__file__':str(Path(__file__).with_name('transient_frontier.py'))}
exec(Path(ns['__file__']).read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.search_backend_comparison import CASES,CoreBoard,ChessBoard,ShogiBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.root_bound_diagnostic import root_search
from scripts.research_record import record_value
TransientSyntax=ns['TransientSyntax']
def iterative(board,seconds,limit):
 first=board.actions()[0];keys={move:label for label,move in board.actions()};start=perf_counter();total={};completed=None;iterations=[]
 for depth in range(1,13):
  r=root_search(board,depth,mode='verified',canonical_key=keys.__getitem__,node_limit=limit-total.get('nodes',0),seconds=seconds-(perf_counter()-start))
  for k,v in r['work'].items():total[k]=total.get(k,0)+v
  iterations.append(r)
  if not r['completed_depth']:break
  completed=r
 move=completed['move'] if completed else first[0];pv=completed['pv'] if completed else (first[1],)
 labels=[]
 for action in pv:
  frontier={m:l for l,m in board.actions()};assert action in frontier;labels.append(frontier[action]);board.push(action)
 for _ in pv:board.pop()
 assert total['nodes']<=limit and board.restored()
 return dict(move=move,score=completed['score'] if completed else None,pv_labels=labels,completed_depth=completed['completed_depth'] if completed else 0,work=total,wall_seconds=perf_counter()-start,cap_nodes=limit,cap_seconds=seconds,iterations=iterations,pv_legal=True,root_restored=True)
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
output=Path(__file__).with_name('corrected-backend-continuation.json')
previous=Path(__file__).with_name('corrected-backend-comparison.json')
report['rows']=json.loads(previous.read_bytes())['rows']
report['previous_attempt_sha256']=hashlib.sha256(previous.read_bytes()).hexdigest()
report['continuation']='Original36 Chess calls retained; only original16 Shogi cells resume after correcting builtin catalog name. No rerun or extra cells.'
def save():output.write_text(json.dumps(report,indent=2)+'\n')
start=perf_counter()
try:
 for case in [CASES[i] for i in (5,7)]:
  compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  def core():return CoreBoard(case,compiled)
  factories=[('Core',core),('Specialized',lambda:ChessBoard(case) if case['game']=='chess' else ShogiBoard(case))]
  if case['game']=='chess':factories.insert(1,('NativeTransient',lambda:TransientSyntax(core(),ns['fns']['VALUES']['chess'])))
  for kind in ('fixed','timed'):
   for repeat,order in enumerate((factories,list(reversed(factories)))):
    for backend,factory in order:
     for flag in ('rollout','advisor','slack'):
      f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
     t=perf_counter();board=factory();setup=perf_counter()-t;r=iterative(board,30 if kind=='fixed' else 1,4096 if kind=='fixed' else 100000)
     r.update(case=case['id'],kind=kind,repeat=repeat,backend=backend,setup_seconds=setup);report['rows'].append(record_value(r));save();print(case['id'],kind,repeat,backend,r['completed_depth'],round(r['wall_seconds'],3),flush=True)
  rows=[r for r in report['rows'] if r['case']==case['id'] and r['kind']=='fixed']
  signature=lambda r:(r['move'],r['score'],r['pv_labels'],r['completed_depth'],r['work'],[(i['move'],i['score'],i['work'],[(c['label'],c['score'],c['bound'],c.get('exact_score'),c['installed']) for c in i['candidates']]) for i in r['iterations']])
  assert all(signature(r)==signature(rows[0]) for r in rows)
 report['complete']=True
finally:report['seconds']=perf_counter()-start;save()
