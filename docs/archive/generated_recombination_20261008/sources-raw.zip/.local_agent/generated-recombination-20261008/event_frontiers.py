import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;src=p/'transfer.json';prior=json.loads(src.read_bytes());out=p/'event-frontiers.json';assert not out.exists();started=time.perf_counter()
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration':'Final12ply searches have expired aux. Cover ALL observed set1, first reset0 after set1, and guarded-drop events in the existing four-seed route, not select by score. Compare public Core vsNative legality with fixedNative evaluation,TT/order on,depth2,8192nodes/5sec. Preserve fullhistory/PV and fallback counts. No timing superiority claim. <=16calls/60sec.','cases':[]};write_record(out,r)
try:
 for old in prior['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c);cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');previous_aux=0
  for event in old['route']:
   assert time.perf_counter()-started<60
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   s.submit(action_from_dict(event['action']));aux=dict(s.state.position.aux_state).get((0,-1),0);kind='active' if aux else 'expired' if previous_aux else 'guarded_drop' if event['action'].get('pattern_id','').startswith('sem_00_') else None;previous_aux=aux
   if kind is None:continue
   case={'seed':old['seed'],'ply':s.state.ply_count,'event':kind,'history_length':len(s.state.history),'aux':record_value(s.state.position.aux_state),'searches':[]};r['cases'].append(case);write_record(out,r)
   for native in (False,True):
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=native,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);case['searches'].append({'native':native,'wall_seconds':time.perf_counter()-t,'decision':record_value(d)});write_record(out,r)
   a,b=[x['decision'] for x in case['searches']];case['equal']={key:a[key]==b[key] for key in ('action','score','completed_depth','principal_variation','nodes')};assert all(case['equal'].values());assert b['native_legality_fallbacks']==0
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
print(json.dumps({'events':[(x['seed'],x['ply'],x['event']) for x in r['cases']],'seconds':r['seconds']}))
