import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/generated_recombination_20261008';dest.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((p/'transfer.json').read_bytes());events=json.loads((p/'event-frontiers.json').read_bytes());assert r['complete'] and events['complete'];assert r['producer_sha256']==sha((p/'transfer.py').read_bytes());assert events['producer_sha256']==sha((p/'event_frontiers.py').read_bytes())
summary={'complete':True,'producer_sha256':sha(Path(__file__).read_bytes()),'input_sha256':{'transfer.json':sha((p/'transfer.json').read_bytes()),'event-frontiers.json':sha((p/'event-frontiers.json').read_bytes())},'seeds':[x['seed'] for x in r['cases']],'rows':[],'event_frontiers':events,'scope':'Four fresh generated4x4hybrid games with explicitly recombined supported X-drop guard and X-to-P quiet expiry. Deterministic capture/semantic/drop coverage route is not a play-strength population. All labels are synthetic, exposed development.','archive':'../../archive/generated_recombination_20261008/index.json'}
for x in r['cases']:
 summary['rows'].append({'seed':x['seed'],'compile_failure':x.get('compile_failure'),'frontier_ply':x.get('frontier_ply'),'legal_actions':x.get('legal_actions'),'route_actions':len(x['route']),'active_aux_events':sum(any(y[1]==1 for y in e['aux']) for e in x['route']),'guarded_drops':sum(e['action'].get('pattern_id','').startswith('sem_00_') for e in x['route']),'reference':x.get('reference'),'searches':[{k:z[k] for k in ('depth','repeat','wall_seconds')}|{'score':z['decision']['score'],'nodes':z['decision']['nodes'],'completed_depth':z['decision']['completed_depth'],'native_legality_fallbacks':z['decision']['native_legality_fallbacks']} for z in x['searches']]})
files=sorted(x for x in p.iterdir() if x.suffix in ('.py','.json'))+[root/'tests/rule_semantics_ir_fixtures.py'];archive=dest/'sources-raw.zip';assert not archive.exists();members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();body=f.read_bytes();z.writestr(name,body);members.append({'path':name,'bytes':len(body),'sha256':sha(body)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for x in members:assert sha((Path(tmp)/x['path']).read_bytes())==x['sha256']
index={'base_commit':'2f40bd85911eb0c70dd91ee3047f385ebc373f46','archive_sha256':sha(archive.read_bytes()),'members':members,'extracted_rehashed':True,'excluded':'User/private inputs, Slack/account records, credentials and active workflow state.'}
(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());(root/'docs/research/data/generated_recombination_20261008.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());print({'members':len(members),'seeds':len(r['cases']),'events':len(events['cases'])})
