"""Reproducible finite typed/presence assay for direct nonboard delta."""
import sys,importlib.util
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('d',B/'direct_nonboard_delta.py');d=importlib.util.module_from_spec(s);s.loader.exec_module(d)
from test_runtime_aux_identity import _compiled
from generic_chess.core.transition import initial_state
from scripts.research_record import write_record
c=_compiled();p=initial_state(c).position;fn=d.make_delta(c)
variants=((),(((99,-1),None),),(((99,-1),0),),(((99,-1),False),),(((99,-1),(1,2)),),(((99,-1),(True,2)),),(((0,-1),1),),(((0,-1),True),))
rows=[]
for i,left in enumerate(variants):
 for j,right in enumerate(variants):
  a=replace(p,aux_state=left);b=replace(p,aux_state=right);h=d.r._full_runtime_hash(a,c);expected=d.r._full_runtime_hash(b,c)
  assert d.baseline(a,b,c,h)==expected and fn(a,b,c,h)==expected
  rows.append(dict(before=i,after=j,exact=True))
write_record(B/'direct-delta-typed-reproduction.json',dict(complete=True,typed_presence_pairs=len(rows),scope='Fresh reproducible64crossed default/typed foreign/presence controls; prior64receipt retained separately.',rows=rows))
print(len(rows),'typed exact')
