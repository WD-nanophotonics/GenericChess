"""Private terminal availability via existing transient packed frontier.
Core keeps all terminal precedence/history; Native is only an existence oracle
inside its declared ply scope. No decoded frontier reuse or product change.
"""
from collections import Counter
from generic_chess.core import search_runtime as r
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic import pack_position,transient_legal_actions
baseline=r.terminal_from_search_runtime
class Probe:
 def __init__(self,compiled):
  self.compiled=compiled;self.provider=NativeSemanticLegalityProvider.try_create(compiled,strict=True);self.counts=Counter()
 def terminal(self,runtime,checkpoint=None):
  if runtime.compiled is not self.compiled:return baseline(runtime,checkpoint)
  engine=r.semantic_engine_for(self.compiled);provider=self.provider
  if engine is None or provider is None or not provider.supports_position(runtime.position,runtime.ply_count):
   self.counts['capability_fallback']+=1;return baseline(runtime,checkpoint)
  old=engine.has_legal_action;had='has_legal_action' in engine.__dict__
  def available(position,checkpoint=None):
   if position is not runtime.position:return old(position,checkpoint=checkpoint)
   if checkpoint is not None:checkpoint()
   raw=transient_legal_actions(provider.native_rules,pack_position(provider.native_rules,provider._state_only_payload(position,runtime.ply_count)))
   if checkpoint is not None:checkpoint()
   self.counts['native_calls']+=1;self.counts['packed_actions']+=len(raw)
   if raw:return True
   self.counts['empty_frontiers']+=1
   return bool(engine.pass_is_legal(position,checkpoint=checkpoint))
  engine.has_legal_action=available
  try:return baseline(runtime,checkpoint)
  finally:
   if had:engine.has_legal_action=old
   else:del engine.has_legal_action
