"""Actual provider fallback before/after support access repair, same pureIR."""
import sys,ast,json,subprocess,time
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product')]
from test_runtime_aux_identity import _compiled,_imported
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider as P
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import legal_actions
from scripts.research_record import write_record
source=subprocess.check_output(['git','show','808be9c39dffca680ed48c811dc7ce5e915eeef4:generic_chess/ai/alphabeta/native_legality.py'],text=True)
tree=ast.parse(source);node=next(v for v in tree.body if isinstance(v,ast.ClassDef) and v.name=='NativeSemanticLegalityProvider');method=next(v for v in node.body if isinstance(v,ast.FunctionDef) and v.name=='supports_position');ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),'pinned-support-method','exec'),ns)
fixed=P.supports_position;out=dict(complete=False,baseline_sha='808be9c39dffca680ed48c811dc7ce5e915eeef4',scope='Pure compiled semantic IR actual runtime provider. Only support access method swapped; exact frontier oracle and branch/fallback/exception counted. No timing claim.',rows=[])
try:
 for strict in (False,True):
  for repaired in (False,True):
   c=_compiled();s=_imported(c,(((0,-1),False),));provider=P.try_create(c,strict=strict);assert provider is not None
   rt=SearchPathRuntime.from_state(s,c,history_witnesses=(s.position,),legal_binding_provider=provider);P.supports_position=fixed if repaired else ns['supports_position'];error=None
   try:actions=rt.legal_actions();assert set(actions)==set(legal_actions(s,c))
   except AttributeError as exc:error=type(exc).__name__
   row=dict(strict=strict,repaired=repaired,error=error,calls=rt.legal_provider_calls,fallbacks=rt.legal_provider_fallbacks,operational_failures=rt.legal_provider_operational_failures,active=rt._legal_provider_active);out['rows'].append(row)
   if repaired:assert error is None and row['calls']==1 and row['fallbacks']==0
   elif strict:assert error=='AttributeError'
   else:assert row['fallbacks']==1 and row['operational_failures']==1 and not row['active']
   rt.assert_balanced()
 out['complete']=True
finally:P.supports_position=fixed;write_record(Path('.local_agent/availability-core-20261011/provider-pure-ir-control.json'),out)
print(out['rows'])
