"""Independent public child/full-hash checks for direct nonboard deltas."""
import sys,time,importlib.util
from pathlib import Path
from dataclasses import replace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('d',B/'direct_nonboard_delta.py');d=importlib.util.module_from_spec(s);s.loader.exec_module(d)
from generic_chess.core.pieces import Piece
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.core.transition import legal_successors
from generic_chess.core.actions import action_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from rule_semantics_ir_fixtures import weird_rulesets
from scripts.research_record import write_record,record_value
from scripts.reserve_refresh_diagnostic import stopped
import pytest
def main():
 start=time.perf_counter();fixtures=weird_rulesets();rows=[[None]*8 for _ in range(8)]
 for owner,tid,f,r in ((0,'K',4,0),(1,'K',7,7),(0,'R',0,0),(0,'R',0,1),(0,'R',0,2),(0,'R',1,1),(1,'R',1,3),(1,'R',1,4)):rows[r][f]=Piece(owner,tid,tid)
 compiled=compile_ruleset_for_execution(replace(fixtures[2],initial_position=tuple(map(tuple,rows)),semantic_actions=(fixtures[1].semantic_actions[0],fixtures[2].semantic_actions[0]),drop_allowed={'R':((True,)*64,)*2,'TP':((False,)*64,)*2}))
 route=(((1,1),(1,3),False),((7,7),(6,7),False),((1,3),(1,4),False),((6,7),(5,7),False),((0,0),(1,1),True),((5,7),(4,7),False),(None,(0,0),False),((4,7),(3,7),False))
 out=dict(complete=False,scope='Same retained recombined8ply lifecycle; independent public child/terminal and unmodified full hash; no cache/token memo.',public_children=0,rows=[])
 fn=d.make_delta(compiled);d.r._semantic_component_diff_hash=fn;game=GameSession(compiled)
 try:
  for ply in range(9):
   stopped();assert time.perf_counter()-start<120;rt=SearchPathRuntime.from_state(game.state,compiled,history_witnesses=game._search_witnesses);pairs=legal_successors(game.state,compiled);assert tuple(a for a,_ in pairs)==rt.legal_actions();before=rt.search_key()
   for action,child in pairs:
    with rt.pushed(action):
     assert rt.position==child.position and rt.terminal_status==child.terminal_status
     assert rt.runtime_hash==d.r._full_runtime_hash(child.position,compiled)
    assert rt.position is game.state.position and rt.search_key()==before;out['public_children']+=1
   rt.assert_balanced();out['rows'].append(dict(ply=ply,legal=len(pairs),hand=record_value(game.state.position.hands),aux=record_value(game.state.position.aux_state)))
   if ply==8:break
   source,target,semantic=route[ply]
   def selected(a):
    if (a.to_square.file,a.to_square.rank)!=target:return False
    if source is None:return hasattr(a,'base_type_id')
    return hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source and a.pattern_id.startswith('sem_')==semantic
   action,=[a for a,_ in pairs if selected(a)];out['rows'][-1]['selected']=action_to_dict(action);game.submit(action)
  # Fixture-local factories only for correctness tests; not the measured caller.
  factories={}
  def dispatch(parent,child,c,current):
   if id(c) not in factories:factories[id(c)]=d.make_delta(c)
   return factories[id(c)](parent,child,c,current)
  d.r._semantic_component_diff_hash=dispatch
  out['typed_test_exit']=int(pytest.main(['tests/product/test_runtime_aux_identity.py','tests/product/test_semantic_trial_checkpoint.py','-q','-p','no:cacheprovider','--basetemp',str(B/'direct-delta-test-temp')]))
  assert out['typed_test_exit']==0;out['complete']=True
 finally:d.r._semantic_component_diff_hash=d.baseline;out['seconds']=time.perf_counter()-start;write_record(B/'direct-delta-semantics.json',out)
 print(out['complete'],out['public_children'],flush=True)
if __name__=='__main__':main()
