"""Private direct nonboard delta, no token memo or changed board footprint."""
from generic_chess.core import search_runtime as r
baseline=r._semantic_component_diff_hash
def make_delta(compiled):
 engine=r.semantic_engine_for(compiled)
 if engine is None:return baseline
 defaults=tuple(((slot.slot_id,owner),slot.initial) for slot in engine.ir.aux_slots for owner in ((-1,) if slot.scope=='global' else (0,1)))
 covered=frozenset(address for address,_ in defaults)
 def delta(parent,child,c,current):
  if c is not compiled:return baseline(parent,child,c,current)
  value=current
  def change(address,old,new):
   nonlocal value
   value=r._xor(value,r._component_token(address,old));value=r._xor(value,r._component_token(address,new))
  for index,(left,right) in enumerate(zip(parent.board,child.board)):
   if left is right:continue
   old=r._component_map_cell(parent,index);new=r._component_map_cell(child,index)
   if old!=new:change(('board',index),old,new)
  if parent.side_to_move!=child.side_to_move:change(('side',),parent.side_to_move,child.side_to_move)
  for owner,(old,new) in enumerate(zip(parent.hands,child.hands)):
   if old.counts!=new.counts:change(('hand',owner),old.counts,new.counts)
  if parent.aux_state is child.aux_state:return value
  before=dict(parent.aux_state);after=dict(child.aux_state)
  for address,default in defaults:
   old=before.get(address,default);new=after.get(address,default)
   if not r._aux_value_equal(old,new):change(('aux',address),old,new)
  for address in before.keys()|after.keys():
   if address in covered:continue
   old=before.get(address);new=after.get(address)
   if (address in before)!=(address in after) or not r._aux_value_equal(old,new):
    if address in before:value=r._xor(value,r._component_token(('aux_unknown',address),old))
    if address in after:value=r._xor(value,r._component_token(('aux_unknown',address),new))
  return value
 return delta
