import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
def mod(name,file):
 s=importlib.util.spec_from_file_location(name,B/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=mod('caller','installed_control.py');n=mod('probe','native_terminal_probe.py')
def main():
 start=time.perf_counter();out=dict(complete=False,scope='Existing transient packed full frontier used only as Core terminal availability predicate; Core history/terminal precedence retained.8oldroots/2opposite fixed512node pairs, and old quiet completedD2/2opposite pairs. No TT/decoded frontier cache.180sec fuse; capability fallback counted.',rows=[],setup=[])
 c.write_record(B/'native-terminal-control.json',out)
 for case in c.CASES:
  compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=c.CoreBoard(case,compiled);e=c.w.weighted(compiled,c.VALUES[case['game']]);t=time.perf_counter();probe=n.Probe(compiled);out['setup'].append(dict(root=case['id'],seconds=time.perf_counter()-t,available=probe.provider is not None));assert probe.provider is not None
  for completed in ((False,True) if case['id']=='chess-middle' else (False,)):
   for repeat in range(2):
    pair=[]
    for active in ((False,True) if repeat==0 else (True,False)):
     c.stopped();assert time.perf_counter()-start<180;probe.counts.clear();n.r.terminal_from_search_runtime=probe.terminal if active else n.baseline;s=c.GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;t=time.perf_counter()
     try:v=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,c.SearchLimits(max_depth=2 if completed else 4,max_nodes=32768 if completed else 512,max_time_seconds=30 if completed else 10,quiescence_max_depth=4,quiescence_hard_max_depth=8))
     finally:n.r.terminal_from_search_runtime=n.baseline
     assert s.state is board.initial
     if completed:assert v.completed_depth==2
     value=c.record_value(v);pair.append(c.clean(value));out['rows'].append(dict(root=case['id'],completed_control=completed,repeat=repeat,candidate=active,wall=time.perf_counter()-t,probe_counts=dict(probe.counts),decision=value))
    assert pair[0]==pair[1]
   c.write_record(B/'native-terminal-control.json',out);print(case['id'],completed,'exact',flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;c.write_record(B/'native-terminal-control.json',out)
if __name__=='__main__':main()
