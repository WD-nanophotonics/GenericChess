"""Pinned support-access route ledger; counts only, no speed claim."""
import ast,sys,subprocess,time,importlib.util
from pathlib import Path
from collections import Counter
from types import SimpleNamespace
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product'),str(Path(__file__).parent)]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('transfer',B/'physical_transfer.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t);c=t.c
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider as P
from generic_chess.core.search_runtime import SearchPathRuntime as R
from generic_chess.core.semantic_executor import SemanticEngine as E
source=subprocess.check_output(['git','show','808be9c39dffca680ed48c811dc7ce5e915eeef4:generic_chess/ai/alphabeta/native_legality.py'],text=True)
cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name==P.__name__);m=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='supports_position');ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[m],type_ignores=[])),'pinned-support','exec'),ns)
fixed=P.supports_position;oldcreate=P.try_create.__func__;oldcall=P.__call__;oldfront=R.legal_actions;olditer=E.iter_legal_action_bindings;counts=Counter();depth=0

def create(cls,*a,**k):
 counts['provider_creation_attempts']+=1;k['strict']=True
 p=oldcreate(cls,*a,**k);counts['provider_created']+=int(p is not None);return p

def support(self,*a):
 counts['capability_checks']+=1
 try:v=selected(self,*a)
 except Exception:counts['capability_exceptions']+=1;raise
 counts['capability_rejects']+=int(not v);return v

def call(self,*a,**k):
 counts['actual_native_calls']+=1;return oldcall(self,*a,**k)

def frontier(self,*a,**k):
 global depth
 depth+=1
 try:return oldfront(self,*a,**k)
 finally:depth-=1

def core(self,*a,**k):
 counts['core_frontier_calls' if depth else 'core_other_generator_calls']+=1
 yield from olditer(self,*a,**k)

start=time.perf_counter();out=dict(complete=False,baseline_sha='808be9c39dffca680ed48c811dc7ce5e915eeef4',scope='Actual provider route counts. Original completedD2 weighted Chess root plus existing512node mixed-rich-hand; old/repaired support access only. All providers strict within support. No wall-clock speed evidence: auxiliary may be working on same machine. No q/evaluation/history defaults changed.',rows=[])
compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess'));board=c.CoreBoard(c.CASES[0],compiled);items=[('chess-middle',compiled,board.initial,board.witnesses,c.cm.w.weighted(compiled,c.VALUES['chess']),2,32768)]
a=t._compiled();compiled=t.SearchSemanticCompiled(ir=a.ir,_legacy_compiled=a._legacy_compiled,support=a.support);pos=t._simultaneous(compiled);cfg=t.EvaluationConfig();e=t.Evaluator(compiled,t.build_ruleset_profile(compiled,cfg),cfg);items.append(('mixed-rich-hand',compiled,t._state(compiled,pos),(pos,),e,4,512))
try:
 P.try_create=classmethod(create);P.supports_position=support;P.__call__=call;R.legal_actions=frontier;E.iter_legal_action_bindings=core
 for name,compiled,state,witnesses,e,maxdepth,nodes in items:
  pair=[]
  for repaired in (False,True):
   c.stopped();assert time.perf_counter()-start<180;counts=Counter();selected=fixed if repaired else ns['supports_position'];session=SimpleNamespace(state=state,compiled=compiled,_search_witnesses=witnesses)
   d=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(session,c.SearchLimits(max_depth=maxdepth,max_nodes=nodes,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   assert session.state is state and not depth;v=c.record_value(d);pair.append((c.cm.clean(v),dict(counts)));assert not counts['capability_exceptions'];out['rows'].append(dict(root=name,repaired=repaired,legacy_top_max_ply=hasattr(compiled,'max_ply'),decision=v,route_counts=dict(counts)))
  assert pair[0]==pair[1];print(name,'exact route/work',pair[0][1],flush=True)
 out['complete']=True
finally:
 P.try_create=classmethod(oldcreate);P.supports_position=fixed;P.__call__=oldcall;R.legal_actions=oldfront;E.iter_legal_action_bindings=olditer;c.write_record(B/'provider-route-ledger.json',out)
