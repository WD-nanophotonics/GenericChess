"""New physical-stage outcome attribution on existing drop/mixed roots."""
import sys,time,importlib.util
from pathlib import Path
from types import SimpleNamespace
from collections import Counter
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests'),str(Path.cwd()/'tests/product'),str(Path(__file__).parent)]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('physical',B/'physical_outcome.py');x=importlib.util.module_from_spec(s);s.loader.exec_module(x)
c=x.c;p=x.p
from semantic_profile_adapter import SearchSemanticCompiled
from test_f24c_mixed_mechanic_certification import _compiled
from test_f24c_mixed_mechanic_certification_r1 import _simultaneous,_state
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
def main():
 start=time.perf_counter();out=dict(complete=False,scope='Physical selected-seam nested exclusive costs by actual noisy-child outcome.2existing roots drop/mixed;2opposite plain/instrumented pairs each;512nodes,maxdepth4,time30,q4/hard8,180second fuse. Unlike Chess completedD2, capped search can have incomplete iterations; completion tags retained. Instrumentation overhead measured, not added to saving. No unrelated default changes.',rows=[])
 compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('standard_shogi'));case=next(v for v in c.CASES if v['id']=='shogi-drop');board=c.CoreBoard(case,compiled);items=[('shogi-drop',compiled,board.initial,board.witnesses,c.cm.w.weighted(compiled,c.VALUES['shogi']))]
 source=_compiled();compiled=SearchSemanticCompiled(ir=source.ir,_legacy_compiled=source._legacy_compiled,support=source.support);pos=_simultaneous(compiled);cfg=EvaluationConfig();e=Evaluator(compiled,build_ruleset_profile(compiled,cfg),cfg);items.append(('mixed-rich-hand',compiled,_state(compiled,pos),(pos,),e))
 for name,compiled,state,witnesses,e in items:
  for order in range(2):
   pair=[]
   for measured in ((False,True) if order==0 else (True,False)):
    c.stopped();assert time.perf_counter()-start<180;p.stack=[];p.pending={};p.totals=Counter();p.peak=0;c.iteration=c.qlevel=0;c.counts=Counter();x.calls=[];x.outside=Counter();x.install(measured);session=SimpleNamespace(state=state,compiled=compiled,_search_witnesses=witnesses);t=time.perf_counter()
    try:v=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(session,c.SearchLimits(max_depth=4,max_nodes=512,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    finally:x.install(False)
    assert not x.calls and not p.stack and not p.pending and session.state is state;value=c.record_value(v);pair.append(c.cm.clean(value));out['rows'].append(dict(root=name,order=order,measured=measured,wall=time.perf_counter()-t,decision=value,outside_formal_push=dict(x.outside),stages=[dict(iteration=i,qphase=q,outcome=o,metric=k,value=v,completed_iteration=(0<i<=value['completed_depth'])) for (i,q,o,k),v in sorted(p.totals.items())]))
   assert pair[0]==pair[1]
  c.write_record(B/'physical-transfer.json',out);print(name,'exact',flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;c.write_record(B/'physical-transfer.json',out)
if __name__=='__main__':main()
