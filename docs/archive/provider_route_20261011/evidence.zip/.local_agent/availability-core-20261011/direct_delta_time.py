import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
def mod(name,file):
 s=importlib.util.spec_from_file_location(name,B/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
c=mod('caller','installed_control.py');d=mod('delta','direct_nonboard_delta.py')
def run():
 start=time.perf_counter();out=dict(complete=False,scope='Predeclared three old roots: quiet completed-work root, adverse fixed-work tactic, and drop gain.1/4seconds,2opposite pairs each; no changed evaluator/q/history/backend or node cap; no token memo.24calls,180second fuse.',rows=[])
 c.write_record(B/'direct-delta-time.json',out)
 for case in c.CASES:
  if case['id'] not in ('chess-middle','chess-tactic','shogi-drop'):continue
  compiled=c.compile_ruleset_for_execution(c.build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'));board=c.CoreBoard(case,compiled);e=c.w.weighted(compiled,c.VALUES[case['game']]);fn=d.make_delta(compiled)
  for seconds in (1,4):
   for repeat in range(2):
    for active in ((False,True) if repeat==0 else (True,False)):
     c.stopped();assert time.perf_counter()-start<180;d.r._semantic_component_diff_hash=fn if active else d.baseline;s=c.GameSession(compiled);s._state=board.initial;s._search_history_witnesses=board.witnesses;t=time.perf_counter()
     try:v=c.AlphaBetaPlayer(compiled,evaluator_override=e,use_native_semantic_legality=True,use_disk_cache=False).choose_action(s,c.SearchLimits(max_depth=4,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8))
     finally:d.r._semantic_component_diff_hash=d.baseline
     assert s.state is board.initial;out['rows'].append(dict(root=case['id'],budget=seconds,repeat=repeat,candidate=active,wall=time.perf_counter()-t,decision=c.record_value(v)))
   c.write_record(B/'direct-delta-time.json',out);print(case['id'],seconds,flush=True)
 out['complete']=True;out['seconds']=time.perf_counter()-start;c.write_record(B/'direct-delta-time.json',out)
if __name__=='__main__':run()
