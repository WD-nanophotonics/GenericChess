"""Semantic/cancellation checks for private packed availability predicate."""
import sys,time,importlib.util
from pathlib import Path
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
B=Path(__file__).parent
s=importlib.util.spec_from_file_location('n',B/'native_terminal_probe.py');n=importlib.util.module_from_spec(s);s.loader.exec_module(n)
from scripts.research_record import write_record
import pytest
probes={}
def dispatch(runtime,checkpoint=None):
 key=id(runtime.compiled)
 if key not in probes:probes[key]=n.Probe(runtime.compiled)
 return probes[key].terminal(runtime,checkpoint)
def main():
 start=time.perf_counter();out=dict(complete=False,scope='Existing terminal boundary/history/trial regressions run with private dispatcher; unsupported compiler/ply states count Core fallback; Core adjudication remains unchanged.')
 n.r.terminal_from_search_runtime=dispatch
 try:
  out['pytest_exit']=int(pytest.main(['tests/product/test_native_legality_terminal_boundary.py','tests/product/test_generic_ply_adjudication.py','tests/product/test_generic_consecutive_action_adjudication.py','tests/product/test_semantic_trial_checkpoint.py','tests/product/test_runtime_aux_identity.py','-q','-p','no:cacheprovider','--basetemp',str(B/'native-probe-test-temp')]))
  out['counts']=[dict(provider=p.provider is not None,counts=dict(p.counts)) for p in probes.values()];out['complete']=out['pytest_exit']==0
 finally:n.r.terminal_from_search_runtime=n.baseline;out['seconds']=time.perf_counter()-start;write_record(B/'native-terminal-semantics.json',out)
 assert out['complete']
if __name__=='__main__':main()
