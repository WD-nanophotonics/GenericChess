from pathlib import Path
import sys,json,hashlib,zipfile,subprocess,re
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";D=R/"docs/archive/tt_demotion_20261016"
assert json.loads((P/"product-full-tests-final.json").read_bytes())["returncode"]==0
assert json.loads((P/"consumer-replay-final.json").read_bytes())["physical_games"]==60
assert json.loads((P/"product-binding-results.json").read_bytes())["complete"]
assert hashlib.sha256((R/"generic_chess/_native/native_module.c").read_bytes()).hexdigest()=="39230230e1f51e44c158b4bbfebe23e3721211c56e897916a5cfe65d1144fd17"
files={}
def add(name,data):
 text=data.decode("utf-8-sig")
 for value,label in [(str(R),"<PROJECT>"),(str(Path.home()),"<USER>")]:
  for old in [value,value.replace("\\","/"),json.dumps(value)[1:-1]]:text=text.replace(old,label)
 text=text.replace("pytest-of-"+Path.home().name,"pytest-of-USER")
 files[name]=text.replace("\r\n","\n").encode()
def scientific(f):
 return f.suffix in(".json",".jsonl",".py",".patch")and not any(x in f.name for x in["-private","-partial","recovery","closing","segment-quality","publication-verified","outgoing","send-","delivery-"])
for f in sorted(P.iterdir()):
 if f.is_file()and scientific(f):add("research/"+f.name,f.read_bytes())
for folder in["roots","finite","witness_finite","prospective"]:
 for f in sorted((P/folder).rglob("*")):
  if f.is_file()and "__pycache__"not in f.parts and scientific(f):add("research/"+f.relative_to(P).as_posix(),f.read_bytes())
for folder in["baseline_source","normal_source","key_source","retain_source","clean_source","profile_source","witness_source","shadow_source"]:
 for f in sorted((P/folder).iterdir()):
  if f.suffix in(".c",".h"):add("variants/"+folder+"/"+f.name,f.read_bytes())
for rel in subprocess.check_output(["git","ls-files","generic_chess","scripts"],text=True).splitlines():
 if Path(rel).suffix in(".py",".c",".h"):add("source/"+rel,(R/rel).read_bytes())
for rel in["pyproject.toml","tests/development/test_native_internal_error.py"]:
 add("source/"+rel,(R/rel).read_bytes())
for f in R.glob("LICENSE*"):
 if f.is_file():add("source/"+f.name,f.read_bytes())
add("research/normal-consumer-replay.json",(P/"consumer-replay-final.json").read_bytes())
add("research/producer-dependencies.json",json.dumps(dict(prior_fixed_sha="cd30db453003ebc0b6c40373287071a27c0a548d",prior_capsule="docs/archive/check_only_20261016/evidence.zip",scope="Producer helper paths refer to prior frozen private recipes; provenance, not automatic campaign replay. Newconsumer self-contained with source/research; no new studysearch/game/proof. Newtestfixture source is provenance; source-only consumer is not a fulltest rerun."),indent=2).encode())
for name,data in files.items():
 text=data.decode()
 assert not re.search(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",text),(name,"email")
 assert not re.search(r"\bsk-[A-Za-z0-9]{24,}|\bxox[bp]-[A-Za-z0-9-]{12,}|\bghp_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}",text),(name,"credential")
 for sep in ["/",chr(92),chr(92)*2]:
  assert "Users"+sep+Path.home().name not in text,(name,"privatepath")
D.mkdir(parents=True,exist_ok=True);assert not(D/"evidence.zip").exists(),"Never replace sealed evidence"
with zipfile.ZipFile(D/"evidence.zip","w",zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(D/"evidence.zip")as z:
 assert z.testzip()is None
 for name,data in files.items():assert z.read(name)==data
manifest=dict(source_base=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),product_module_sha256=hashlib.sha256((R/"generic_chess/_native/native_module.c").read_bytes()).hexdigest(),archive_sha256=hashlib.sha256((D/"evidence.zip").read_bytes()).hexdigest(),archive_bytes=(D/"evidence.zip").stat().st_size,member_count=len(files),members=[dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in sorted(files.items())],scope="Full actual final normal source, eight private variant source snapshots and all scientific plans/inputs/receipts/failures. Publication copies sanitize host paths only. No binary, raw Slack/account/credential/private-original/pytest-temp archives. Finalreport/reproduction/session/publication receipts outside immutable ZIP.")
(D/"manifest.json").write_bytes(json.dumps(manifest,indent=2).encode());print("PACKAGE_SEALED",len(files),manifest["archive_bytes"],manifest["archive_sha256"],flush=True)
