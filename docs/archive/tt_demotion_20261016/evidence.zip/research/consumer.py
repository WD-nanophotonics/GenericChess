"""Search-disabled consumer. Run from product source root; pass evidence directory."""
from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=Path(sys.argv[1])if len(sys.argv)>1 else R/'.local_agent/tt-demotion-20261016'
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.ir import CompiledSemanticRuleset
class Adapter(CompiledSemanticRuleset):
 __slots__=()
 def __getattr__(self,name):return getattr(self._legacy_compiled,name)
 @property
 def semantic(self):return self
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import iter_legal_actions
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine,_module
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from scripts.research_record import record_value
assert Path(nc.__file__).resolve().is_relative_to(R.resolve())
assert Path(_module().__file__).resolve().is_relative_to(R.resolve())
assert Path(compile_legacy_ruleset_for_semantic_execution.__code__.co_filename).resolve().is_relative_to(R.resolve())
def forbidden(*a,**kw):raise AssertionError('Search forbidden in receipt consumer')
SemanticSearchEngine.search=forbidden;_module().semantic_engine_search=forbidden
def read(p):return json.loads((B/p).read_bytes())
def action(d):
 if d is None:return None
 if not d:return PassAction()
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def digest(state):return hashlib.sha256(json.dumps(record_value(state),sort_keys=True).encode()).hexdigest()
cache={};root_states=set();counts=dict(root_loads=0,queries=0,pv_edges=0,physical_games=0,physical_edges=0,one_reply_receipts=0,selected_choice_edges=0)
def load(root):
 key=str(root)
 if key not in cache:
  d=read('roots/'+key+'.json');raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=Adapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=nc.compile_native_semantic_rules(c);cache[key]=(d,c,nr);counts['root_loads']+=1
 d,c,nr=cache[key];s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])))
 assert record_value(s.state)==d['state']and digest(s.state)==d['before_sha256']
 root_states.add(digest(s.state));return s,nr
def compare(s,nr,state,np,witnesses):
 snap=sem.snapshot(nr,np);exp=expected_snapshot(state.position,nr,s.compiled)
 for k in('board','hands','aux_state','side'):assert record_value(snap[k])==record_value(exp[k])
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(w,s.compiled))for w in witnesses]
 assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
def query(s,nr,r,limit=1000000):
 assert r['nodes']>=0 and r['qnodes']>=0 and r['nodes']+r['qnodes']<=limit
 st=s.state;np=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses)
 chosen=action(r['action']);assert chosen is None or chosen in s.legal_actions()
 line=[action(a)for a in r['principal_variation']];had_pv=bool(line)
 if line:assert line[0]==chosen
 if not line and chosen is not None:line=[chosen]
 for a in line:
  np=sem.make_checked(nr,np,pack_semantic_action(nr,st.position,a));st=apply_action(st,a,s.compiled);w.append(st.position);compare(s,nr,st,np,w);counts['pv_edges']+=int(had_pv);counts['selected_choice_edges']+=int(not had_pv)
 if r.get('immediate_win')and r.get('result_source')=='verified_root_child':assert len(line)==1 and st.terminal_status.winner==s.state.position.side_to_move
 counts['queries']+=1
 return st,np


start=time.perf_counter()
for name,prefix in [("results.json","child"),("retain-results.json","retain-child"),("same-depth-results.json","same-child")]:
 data=read(name);assert data["complete"]
 journal={"results.json":"rows.jsonl","retain-results.json":"retain-rows.jsonl","same-depth-results.json":"same-depth-rows.jsonl"}[name]
 assert data["rows"]==[json.loads(x)for x in(B/journal).read_text(encoding="utf-8").splitlines()]
 for row in data["rows"]:
  rid="node-"+str(row["root"])if row["phase"]=="parent"else prefix+"-"+str(row["root"])+"-"+(str(row["order"])+"-"if "order"in row else"")+row["arm"]
  s,nr=load(rid);assert digest(s.state)==row["before_sha256"];query(s,nr,row["result"])
  assert not row["raw"]["private_demotion_overflow"]
for folder in ("finite","witness_finite"):
 for row in read(folder+"/qualification.json")["rows"]:
  s,nr=load("../"+folder+"/roots/"+str(row["seed"]));query(s,nr,row["result"]);assert digest(s.state)==row["before_sha256"]
for name in ("profile-results.json","witness-results.json"):
 data=read(name);assert data["complete"]
 for row in data["rows"]:
  s,nr=load("../finite/roots/"+str(row["seed"]));query(s,nr,row["result"]);assert digest(s.state)==row["before_sha256"]
data=read("prospective/results.json");assert data["complete"]and len(data["rows"])==256
for row in data["rows"]:
 if "result"not in row:continue
 s,nr=load("../prospective/roots/"+str(row["seed"]));query(s,nr,row["result"],8192 if row["budget"]=="fixed"else 1000000);assert digest(s.state)==row["before_sha256"]
for name in ("curve-results.json","shadow-results.json"):
 data=read(name);assert data["complete"]
 for row in data["rows"]:
  if "result"not in row:continue
  s,nr=load("../prospective/roots/"+str(row["seed"]));query(s,nr,row["result"]);assert digest(s.state)==row["before_sha256"]
for folder in ("finite","witness_finite"):
 data=read(folder+"/divergence-results.json");assert data["complete"];seen=set()
 for row in data["rows"]:
  if row["kind"]!="FIRST_ACTION_DIFFERENCE":continue
  s,nr=load("../"+folder+"/divergence-roots/"+row["root_id"])
  for act,key in zip(row["actions"],row["diagnostic_keys"]):
   if key in seen:continue
   seen.add(key);ac=action(act);child=apply_action(s.state,ac,s.compiled);np=pack_semantic_search_position(s.compiled,nr,s);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));compare(s,nr,child,np,list(s._search_witnesses)+[child.position]);counts["diagnostic_choice_edges"]=counts.get("diagnostic_choice_edges",0)+1
   dg=data["diagnostics"][key];observed=[]
   for witness in dg.get("rows",[]):
    reply=action(witness["action"]);after=apply_action(child,reply,s.compiled);assert record_value(after.terminal_status)==witness["terminal"];observed.append(reply);counts["one_reply_receipts"]+=1
   if dg.get("complete"):assert set(observed)==set(iter_legal_actions(child,s.compiled))
if (B/"finite/completion.json").exists():
 done=read("finite/completion.json");plan=read("finite/plan.json");assert done["complete"]and len(done["games"])==36
 for g in done["games"]:
  if "result"not in g:continue
  s,nr=load("../finite/roots/"+str(g["seed"]));path="finite/game-"+str(g["seed"])+"-"+g["mode"];game=read(path+".json");assert game["complete"]
  assert game["rows"]==[json.loads(x)for x in(B/(path+".jsonl")).read_text(encoding="utf-8").splitlines()]
  w=list(s._search_witnesses);np=pack_semantic_search_position(s.compiled,nr,s)
  for row in game["rows"]:
   assert digest(s.state)==row["before_sha256"]
   assert row["actor"]==s.state.position.side_to_move and len(row["phases"])<=1
   cell=g["mode"][0]if g["mode"]!="A_control"and row["actor"]==int(g["mode"][-1])else"A"
   assert row["owner"]==cell and row["tt_megabytes"]==16 and row["objective"]=="disabled_q0"
   for ph in row["phases"]:
    r=ph["result"];query(s,nr,r)
    assert row["selected"]==r and ph["q"]==0
    assert row["total_nodes"]==ph["used_total_nodes"]==r["nodes"]+r["qnodes"]<=1000000
    assert r["tt_allocated_bytes"]==11534336
    if r["completed_depth"]:assert(r["result_ordinary_qdepth"],r["result_check_hard_qdepth"])==(0,0)
   if "action"not in row:assert not row["execution_allowed"];continue
   assert row["execution_allowed"]and row["action"]==row["selected"]["action"]and not row["cancelled"]and row["caller_seconds"]<1.
   ac=action(row["action"]);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));s.submit(ac);w.append(s.state.position);compare(s,nr,s.state,np,w)
   assert digest(s.state)==row["after_sha256"]and record_value(s.result)==row["actual_terminal"];counts["physical_edges"]+=1
  assert record_value(s.state)==game["state"]and record_value(s.result)==game["result"];counts["physical_games"]+=1
if (B/"witness_finite/completion.json").exists():
 done=read("witness_finite/completion.json");plan=read("witness_finite/plan.json");assert done["complete"]and len(done["games"])==24
 for g in done["games"]:
  if "result"not in g:continue
  s,nr=load("../witness_finite/roots/"+str(g["seed"]));path="witness_finite/game-"+str(g["seed"])+"-"+g["mode"];game=read(path+".json");assert game["complete"]
  assert game["rows"]==[json.loads(x)for x in(B/(path+".jsonl")).read_text(encoding="utf-8").splitlines()]
  w=list(s._search_witnesses);np=pack_semantic_search_position(s.compiled,nr,s)
  for row in game["rows"]:
   assert digest(s.state)==row["before_sha256"]
   assert row["actor"]==s.state.position.side_to_move and len(row["phases"])<=1
   cell=g["mode"][0]if g["mode"]!="A_control"and row["actor"]==int(g["mode"][-1])else"A"
   assert row["owner"]==cell and row["tt_megabytes"]==16 and row["objective"]=="disabled_q0"
   for ph in row["phases"]:
    r=ph["result"];query(s,nr,r)
    assert row["selected"]==r and ph["q"]==0
    assert row["total_nodes"]==ph["used_total_nodes"]==r["nodes"]+r["qnodes"]<=1000000
    assert r["tt_allocated_bytes"]==11534336
    if r["completed_depth"]:assert(r["result_ordinary_qdepth"],r["result_check_hard_qdepth"])==(0,0)
   if "action"not in row:assert not row["execution_allowed"];continue
   assert row["execution_allowed"]and row["action"]==row["selected"]["action"]and not row["cancelled"]and row["caller_seconds"]<1.
   ac=action(row["action"]);np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,ac));s.submit(ac);w.append(s.state.position);compare(s,nr,s.state,np,w)
   assert digest(s.state)==row["after_sha256"]and record_value(s.result)==row["actual_terminal"];counts["physical_edges"]+=1
  assert record_value(s.state)==game["state"]and record_value(s.result)==game["result"];counts["physical_games"]+=1
data=read("product-binding-results.json");assert data["complete"]and len(data["rows"])==62
for row in data["rows"]:
 assert row["matched_frozen_private"]
 s,nr=load("../prospective/roots/"+str(row["seed"]));query(s,nr,row["result"],8192);assert digest(s.state)==row["before_sha256"]
counts.update(complete=True,unique_full_root_states=len(root_states),seconds=time.perf_counter()-start,search_forbidden=True,scope="Shared Core/compiler normal Native full-state/history receipt replay. No search/game/proof execution or independent WDL/all-domain claim; private variants are provenance.")
(B/"consumer-replay-final.json").write_bytes(json.dumps(counts,indent=2).encode());print("CONSUMER_PASS",counts,flush=True)
