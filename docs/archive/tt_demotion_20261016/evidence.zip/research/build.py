from pathlib import Path
import json,shutil,hashlib,sysconfig,sys,subprocess,time
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";B=R/".local_agent/check-only-20261016"
plan=dict(question="Do newer-generation same-full-key stores actually demote deeper entries in q0 parentD4 -> childD2 reuse?",basis="Both normal and lookup-tag104call, plus matched156call studies saved zero nodes; generation demotion remains an unmeasured source inference.",scope="PRIVATE two module images normal/keytag, per-table counter only; exact q0/history/mode unchanged, no AUX solver or product API/default edits",max_queries=104,whole_seconds=300,expected_seconds=60,sequence="13parents x2images x(parentD4,warmchildD2,freshchildD2)=78; reserved ceiling104, no extra search for instrument checks",counter="exact accepted same-key depth decreases indexed olddepth,newdepth,oldgeneration,newgeneration 0..7; overflow separately counted; pertable cumulative, not global",decision="Only observed material demotions justify ONE retention ablation; otherwise stop route and attribute wideq0 stage cost.")
(P/"plan.json").write_text(json.dumps(plan,indent=2),encoding="utf-8")
for arm,base in [("normal",R/"generic_chess/_native"),("key",B/"key_policy_source")]:
 S=P/(arm+"_source");S.mkdir(exist_ok=True)
 for f in base.iterdir():
  if f.suffix in (".c",".h"):shutil.copyfile(f,S/f.name)
 h=S/"native_tt.h";s=h.read_text(encoding="utf-8-sig");anchor="} GCSemanticTable;";assert s.count(anchor)==1;s=s.replace(anchor,"    uint64_t demotions[8][8][8][8];\n    uint64_t demotion_overflow;\n"+anchor);h.write_bytes(s.encode())
 c=S/"native_tt.c";s=c.read_text(encoding="utf-8-sig");anchor="    if (target->occupied && replaced_out != NULL) *replaced_out = 1;";assert s.count(anchor)==1
 inject="""    if (target->occupied && gc_semantic_tt_key_match(target, position, context) &&
        depth >= 0 && depth < target->depth) {
        unsigned od = target->depth, nd = (unsigned)depth;
        unsigned og = target->generation, ng = tt->generation;
        if (od < 8 && nd < 8 && og < 8 && ng < 8)
            tt->demotions[od][nd][og][ng]++;
        else tt->demotion_overflow++;
    }
"""
 s=s.replace(anchor,inject+anchor);c.write_bytes(s.encode())
 c=S/"native_module.c";s=c.read_text(encoding="utf-8-sig")
 anchor="    PyObject *training_trace = ctx.trace_enabled";assert s.count(anchor)==1
 inject="""    /* PRIVATE per-table exact same-key depth-demotion histogram. */
    if (out && ctx.tt) {
        PyObject *hist = PyList_New(0);
        if (!hist) { Py_DECREF(out); out = NULL; }
        if (hist) {
            for (int od=0; od<8; od++) for (int nd=0; nd<8; nd++)
            for (int og=0; og<8; og++) for (int ng=0; ng<8; ng++) {
                uint64_t count = ctx.tt->demotions[od][nd][og][ng];
                if (!count) continue;
                PyObject *row = Py_BuildValue("(iiiiK)",od,nd,og,ng,count);
                if (!row || PyList_Append(hist,row) != 0) {
                    Py_XDECREF(row); Py_DECREF(hist); hist=NULL; break;
                }
                Py_DECREF(row);
            }
            if (hist && (PyDict_SetItemString(out,"private_demotions",hist) != 0 ||
                gc_semantic_set_u64(out,"private_demotion_overflow",ctx.tt->demotion_overflow) != 0)) {
                Py_DECREF(out); out=NULL;
            }
            Py_XDECREF(hist);
        }
    }
    if (!out) {
        Py_DECREF(best_action_obj); Py_DECREF(pv);
        free(ctx.stack); free(ctx.pv_table); free(ctx.pv_length); free(ctx.trace_rows);
        if (ctx.tt != borrowed_tt) gc_semantic_tt_free(ctx.tt);
        gc_semantic_profile_free(&profile); gc_semantic_profile_free(&ordering_profile);
        return NULL;
    }
"""
 # No allocation error is injected in this private measurement; all returned results must include histogram.
 s=s.replace(anchor,inject+anchor);c.write_bytes(s.encode())
 cmd=[str(R/".venv/Lib/site-packages/ziglang/zig.exe"),"cc","-target","x86_64-windows-gnu","-shared","-O2","-I"+sysconfig.get_path("include"),"-I"+str(S),"-L"+str(Path(sys.base_prefix)/"libs"),"-lpython312",*[str(f)for f in S.glob("*.c")],"-o",str(P/(arm+"_native_core.pyd"))]
 t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
 (P/(arm+"-build.json")).write_text(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()},command=cmd),indent=2),encoding="utf-8")
 print("BUILD",arm,r.returncode,r.stderr[-500:],flush=True)
 if r.returncode:sys.exit(r.returncode)
