from pathlib import Path
import json,shutil,subprocess,sys,sysconfig,time,hashlib
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";S=P/"profile_source";S.mkdir(exist_ok=True)
plan=dict(question="Which normal q0 kernel stage dominates wide work after adjacent reuse yields only3percent same-depth reduction?",inputs="All12 frozen finite roots; no new generations or games",max_queries=48,nodes=4096,seconds=3,depth=3,whole_seconds=240,expected_seconds=45,decision="One dominant measured stage can justify a later small candidate; no optimization/default adoption from counts alone.",measurement="Exclusive main terminal/generation/ordering/traversal sections; fullhistory child digest is a nested subset of checked traversal/PV. PV reconstruction time overlaps those stages, never sum it into partition. Runtime existing scoped audit measures all checked commits, no global crossprocess state.")
(P/"profile-plan.json").write_text(json.dumps(plan,indent=2),encoding="utf-8")
for f in(R/"generic_chess/_native").iterdir():
 if f.suffix in(".c",".h"):shutil.copyfile(f,S/f.name)
h=S/"native_semantic_runtime.h";s=h.read_text(encoding="utf-8-sig").replace("} GCSemanticRuntimeAudit;","    uint64_t private_hash_ns;\n} GCSemanticRuntimeAudit;");h.write_bytes(s.encode())
c=S/"native_semantic_runtime.c";s=c.read_text(encoding="utf-8-sig").replace('#include "native_semantic_runtime.h"','#include "native_semantic_runtime.h"\n#include "native_clock.h"')
mark="if(!gc_semantic_position_key_digest(r,&work,digest))return -1;";assert s.count(mark)==1
s=s.replace(mark,"uint64_t phstart=gc_monotonic_ns();int phok=gc_semantic_position_key_digest(r,&work,digest);if(gc_runtime_audit)gc_runtime_audit->private_hash_ns+=gc_monotonic_ns()-phstart;if(!phok)return -1;");c.write_bytes(s.encode())
c=S/"native_module.c";s=c.read_text(encoding="utf-8-sig");mark="    uint32_t tt_iteration_generation;";assert s.count(mark)==1;s=s.replace(mark,"    uint64_t private_stage[5];\n    GCSemanticRuntimeAudit private_audit;\n"+mark)
idx=s.index("static int gc_semantic_iterative_negamax(")
helpers="""/* PRIVATE attribution on existing single-search contract. */
static int private_main_terminal(GCSemanticIterativeContext *ctx,const GCSemanticPosition *p,int *w,const uint64_t *known) {
 uint64_t t=gc_monotonic_ns(); int r=gc_semantic_terminal_status_known(ctx->rules,p,w,known);
 ctx->private_stage[0]+=gc_monotonic_ns()-t; return r;
}
static int private_main_generate(GCSemanticIterativeContext *ctx,const GCSemanticPosition *p,GCSemanticActionBuffer *a) {
 uint64_t t=gc_monotonic_ns();int r=gc_semantic_generate_candidate_buffer(ctx->rules,p,a);
 ctx->private_stage[1]+=gc_monotonic_ns()-t;return r;
}
static int private_main_history(GCSemanticIterativeContext *ctx,GCSemanticPosition *p,GCSemanticActionBuffer *a) {
 uint64_t t=gc_monotonic_ns();int r=gc_semantic_history_order(ctx,p,a);
 ctx->private_stage[2]+=gc_monotonic_ns()-t;return r;
}
static int private_main_order(GCSemanticIterativeContext *ctx,GCSemanticPosition *p,uint32_t ply,uint32_t depth,GCSemanticActionBuffer *a) {
 uint64_t t=gc_monotonic_ns();int r=gc_semantic_order_actions(ctx,p,ply,depth,a);
 ctx->private_stage[2]+=gc_monotonic_ns()-t;return r;
}
static int private_main_make(GCSemanticIterativeContext *ctx,GCSemanticPosition *child,const GCSemanticPosition *p,uint64_t a) {
 uint64_t t=gc_monotonic_ns();int r=gc_semantic_runtime_make_checked_status(child,ctx->rules,p,a);
 ctx->private_stage[3]+=gc_monotonic_ns()-t;return r;
}
"""
s=s[:idx]+helpers+s[idx:];start=s.index("static int gc_semantic_iterative_negamax(");end=s.index("static int gc_semantic_iterative_fallback(",start);part=s[start:end]
part=part.replace("gc_semantic_terminal_status_known(ctx->rules, position, &winner, known)","private_main_terminal(ctx, position, &winner, known)")
part=part.replace("gc_semantic_generate_candidate_buffer(ctx->rules, position, &actions)","private_main_generate(ctx, position, &actions)")
part=part.replace("gc_semantic_history_order(ctx, position, &actions)","private_main_history(ctx, position, &actions)")
part=part.replace("gc_semantic_order_actions(ctx, position, ply, depth, &actions)","private_main_order(ctx, position, ply, depth, &actions)")
mark="gc_semantic_runtime_make_checked_status(\n            child, ctx->rules, position, action)";assert part.count(mark)==1;part=part.replace(mark,"private_main_make(ctx, child, position, action)")
mark="gc_semantic_runtime_make_checked(\n                best_child, ctx->rules, position, best_action)";assert part.count(mark)==1;part=part.replace(mark,"(private_main_make(ctx, best_child, position, best_action) > 0)")
mark="""        int branch = gc_semantic_iterative_negamax(
            ctx, ply + 1, depth - 1, -GC_SEMANTIC_PROBE_INF,
            GC_SEMANTIC_PROBE_INF, 1, 1);"""
assert part.count(mark)==1;part=part.replace(mark,"        uint64_t private_pv_start=gc_monotonic_ns();\n"+mark+"\n        if (!pv_replay) ctx->private_stage[4]+=gc_monotonic_ns()-private_pv_start;")
s=s[:start]+part+s[end:]
mark="    Py_BEGIN_ALLOW_THREADS\n    for (uint32_t depth = 1; depth <= max_depth; depth++) {";assert s.count(mark)==1;s=s.replace(mark,"    gc_semantic_runtime_audit_start(&ctx.private_audit);\n"+mark)
mark="    Py_END_ALLOW_THREADS\n    const char *reason = immediate_win";assert s.count(mark)==1;s=s.replace(mark,"    gc_semantic_runtime_audit_stop();\n"+mark)
mark='        gc_semantic_set_u64(out, "ordering_cache_hits", cache_hits) != 0 ||';assert s.count(mark)==1
extra="".join('        gc_semantic_set_u64(out, "private_stage_'+str(i)+'", ctx.private_stage['+str(i)+']) != 0 ||\n'for i in range(5))
extra+='        gc_semantic_set_u64(out, "private_hash_ns", ctx.private_audit.private_hash_ns) != 0 ||\n        gc_semantic_set_u64(out, "private_hash_calls", ctx.private_audit.child_canonical_key_computations) != 0 ||\n'
s=s.replace(mark,extra+mark);c.write_bytes(s.encode())
cmd=[str(R/".venv/Lib/site-packages/ziglang/zig.exe"),"cc","-target","x86_64-windows-gnu","-shared","-O2","-I"+sysconfig.get_path("include"),"-I"+str(S),"-L"+str(Path(sys.base_prefix)/"libs"),"-lpython312",*[str(f)for f in S.glob("*.c")],"-o",str(P/"profile_native_core.pyd")]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(P/"profile-build.json").write_text(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,command=cmd,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()}),indent=2),encoding="utf-8");print("PROFILE_BUILD",r.returncode,r.stderr[-1500:]);sys.exit(r.returncode)
