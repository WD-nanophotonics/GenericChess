from pathlib import Path
import sys,json,time,importlib.util,os
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";F=P/"prospective";sys.path[:0]=[str(R),str(R/".local_agent/residual-q4-20261016")]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;spec=importlib.util.spec_from_file_location("curve_witness._native_core",P/"witness_native_core.pyd");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
inputs=[x for x in json.loads((F/"plan.json").read_bytes())["inputs"]if x["n"]>=12]
plan=dict(question="Does the measured q0 availability cost saving cross a practical full-D4 completion threshold on wide rules, beyond the unchanged quarter-second retained actions?",changed_premise="Prospective124fixed-work equal queries show4-9percent widecaller savings but62quartersecondwallpairs have zero deeper/action change. A resource curve can distinguish a real completion threshold from only cheap kernel work, changing whether to continue local microoptimization or shift toward broader search allocation/generation diagnostics.",inputs=inputs,seconds_caps=[1,4,16],depth=4,nodes=1000000,orders=[["normal","witness"],["witness","normal"]],max_queries=192,whole_seconds=1800,expected_seconds=1000,scope="EXPOSED16existing wide prospective families, bothorders/caps predeclared; no newgames/labels/independent validation or defaultq/price policy. No Core/AUXsolver. Sameexactq0/fullhistory/profiles; allpartialdepths/atomicovershoots/UNKNOWN kept.",decision="At jointly completedD4 require identicalscore/action/fullPV. Count actualcompletion/cost within each cap, retain regressions; depth/completion is interface capability, not strength/WDL. If practical gains remain small, stop this microoptimization route after qualification instead of making new local speed patches.")
a.write_record(P/"curve-plan.json",plan);rows=[];start=time.perf_counter();journal=P/"curve-rows.jsonl";journal.open("x").close()
for case in inputs:
 for cap in plan["seconds_caps"]:
  for order,names in enumerate(plan["orders"]):
   for name in names:
    p.stopped();row=dict(**case,cap=cap,order=order,arm=name)
    if time.perf_counter()-start>=plan["whole_seconds"]:row["kind"]="WHOLE_CAP_NOT_STARTED_UNKNOWN"
    else:
     d=json.loads((F/"roots"/(str(case["seed"])+".json")).read_bytes());ir=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d["ruleset"])));c=a.p.SearchMetadataAdapter(ir=ir.ir,_legacy_compiled=ir._legacy_compiled,support=ir.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d["game_record"])));nr=a.nc.compile_native_semantic_rules(c,backend_module=p.m if name=="normal"else m)
     e=a.SemanticSearchEngine(c,nr,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=16,ordering_cache_enabled=False);before=p.digest(s);t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=4,max_nodes=1000000,max_time_seconds=cap,quiescence_max_depth=0),root_window_pruning=True)
     row.update(kind="ACTUAL_QUERY",result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r),before_sha256=before);assert before==p.digest(s)
    rows.append(row)
    with journal.open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush();os.fsync(f.fileno())
   aa,bb=rows[-2:]
   if"result"in aa and"result"in bb and aa["result"]["completed_depth"]==bb["result"]["completed_depth"]:
    for k in["score","action","principal_variation","completed_depth"]:assert aa["result"][k]==bb["result"][k],(case,cap,order,k)
   print("CURVE",case,cap,order,[(x.get("result",{}).get("completed_depth"),round(x.get("seconds",0),4))for x in rows[-2:]],flush=True)
a.write_record(P/"curve-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("CURVE_CLOSED",len(rows),time.perf_counter()-start,flush=True)
