from pathlib import Path
import shutil,json,hashlib,subprocess,sys,sysconfig,time
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";S=P/"retain_source";S.mkdir(exist_ok=True)
rows=json.loads((P/"results.json").read_bytes())["rows"];assert len(rows)==78
assert rows==[json.loads(s)for s in(P/"rows.jsonl").read_text(encoding="utf-8").splitlines()]
summary=dict(queries=len(rows),seconds=json.loads((P/"results.json").read_bytes())["seconds"],normal_demotion=sum(t[4]for r in rows if r["arm"]=="normal"and r["phase"]=="warm"for t in r["raw"]["private_demotions"]),key_demotion=sum(t[4]for r in rows if r["arm"]=="key"and r["phase"]=="warm"for t in r["raw"]["private_demotions"]),warm_fresh_equal_nodes=26)
(P/"counter-summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
plan=dict(question="Does refusing any shallower same-key store in exact-root q0 now save useful adjacent work?",changed_premise=summary,arms=["key","retain"],parents=list(range(13)),orders=[["key","retain"],["retain","key"]],phases=["parentD4","warmchildD2","freshchildD2"],max_queries=156,whole_seconds=300,expected_seconds=60,nodes=1000000,seconds=3,scope="Private retention only enabled for exact-root/q0 context, complete history keys unchanged; no defaults/AUXsolver",decision="Reject complete score/action/PV mismatch; no work gain stops route, no game solely for more hits. Time descriptive under shared host; potential cheaper retained entry cannot substitute original exact finite horizon.")
(P/"retention-plan.json").write_text(json.dumps(plan,indent=2),encoding="utf-8")
for f in(P/"key_source").iterdir():shutil.copyfile(f,S/f.name)
c=S/"native_tt.h";s=c.read_text(encoding="utf-8-sig").replace("    uint64_t demotion_overflow;","    uint64_t demotion_overflow;\n    int retain_deeper;");c.write_bytes(s.encode())
c=S/"native_tt.c";s=c.read_text(encoding="utf-8-sig");mark="        if (entry->occupied && gc_semantic_tt_key_match(entry, position, context)) {";assert s.count(mark)==1
# Only the store branch, never mutate const probe.
idx=s.index(mark,s.index("int gc_semantic_tt_store("));idx+=len(mark);s=s[:idx]+"\n            if (tt->retain_deeper && depth < entry->depth) return 0;"+s[idx:];c.write_bytes(s.encode())
c=S/"native_module.c";s=c.read_text(encoding="utf-8-sig");mark="    gc_semantic_context_seed(position, ctx.history_context[0]);";assert s.count(mark)==1;s=s.replace(mark,"    if (ctx.tt) ctx.tt->retain_deeper = ctx.root_window_pruning && qdepth == 0;\n"+mark);c.write_bytes(s.encode())
cmd=[str(R/".venv/Lib/site-packages/ziglang/zig.exe"),"cc","-target","x86_64-windows-gnu","-shared","-O2","-I"+sysconfig.get_path("include"),"-I"+str(S),"-L"+str(Path(sys.base_prefix)/"libs"),"-lpython312",*[str(f)for f in S.glob("*.c")],"-o",str(P/"retain_native_core.pyd")]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(P/"retain-build.json").write_text(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,command=cmd,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()}),indent=2),encoding="utf-8");print(summary);print("RETAIN_BUILD",r.returncode,r.stderr[-1000:]);sys.exit(r.returncode)
