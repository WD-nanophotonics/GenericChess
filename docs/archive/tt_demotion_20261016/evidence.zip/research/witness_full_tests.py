from pathlib import Path
import sys,importlib.util,json,time,subprocess,uuid
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";sys.path.insert(0,str(R))
if len(sys.argv)>1 and sys.argv[1]=="child":
 import generic_chess.native as native
 spec=importlib.util.spec_from_file_location("fullqualified._native_core",P/"witness_native_core.pyd");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
 import pytest
 sys.exit(pytest.main(["-q","-p","no:cacheprovider","--basetemp",sys.argv[2]]))
dest=P/("pytest-witness-"+uuid.uuid4().hex[:8]);assert not dest.exists()and dest.resolve().is_relative_to(P.resolve())
t=time.perf_counter();r=subprocess.run([sys.executable,str(Path(__file__).resolve()),"child",str(dest)],capture_output=True,text=True,timeout=600)
(P/"witness-full-tests.json").write_text(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,scope="All configured active pytest layers in isolated private witness module process; normal binary unchanged. Actual count follows captured summary; not independent source-only/othermachine qualification."),indent=2),encoding="utf-8");print(r.stdout[-4500:]);print(r.stderr[-1000:]);sys.exit(r.returncode)
