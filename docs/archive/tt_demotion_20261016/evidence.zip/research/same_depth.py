from pathlib import Path
import sys,json,time,importlib.util,os
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";B=R/".local_agent/check-only-20261016";sys.path[:0]=[str(R),str(R/".local_agent/residual-q4-20261016")]
import probe as p
from generic_chess.session.serialization import deserialize_game_record,serialize_game_record
a=p.a;mods={};raws={}
for name in ("key","retain"):
 spec=importlib.util.spec_from_file_location("demotion_"+name+"._native_core",P/(name+"_native_core.pyd"));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
 fn=m.semantic_engine_search
 def capture(*args,_fn=fn,_name=name,**kwargs):
  out=_fn(*args,**kwargs);raws[_name]=a.record_value(out);return out
 m.semantic_engine_search=capture
rows=[];start=time.perf_counter();journal=P/"same-depth-rows.jsonl";journal.open("x").close();(P/"roots").mkdir(exist_ok=True)
for ordinal in range(26):
 i=ordinal%13
 for name in (("key","retain")if ordinal<13 else("retain","key")):
  p.stopped();d=json.loads((B/"roots"/("node-"+str(i)+".json")).read_bytes());ir=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d["ruleset"])));c=a.p.SearchMetadataAdapter(ir=ir.ir,_legacy_compiled=ir._legacy_compiled,support=ir.support)
  s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d["game_record"])));nr=a.nc.compile_native_semantic_rules(c,backend_module=mods[name])
  def engine():return a.SemanticSearchEngine(c,nr,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=16,ordering_cache_enabled=False)
  def query(e,depth,phase):
   assert time.perf_counter()-start<300
   before=p.digest(s);t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=depth,max_nodes=1000000,max_time_seconds=3,quiescence_max_depth=0),root_window_pruning=True)
   raw=raws[name];assert "private_demotions"in raw and not raw["private_demotion_overflow"]
   row=dict(root=i,order=ordinal//13,arm=name,phase=phase,result=a.record_value(r),raw=raw,seconds=time.perf_counter()-t,before_sha256=before,pv_edges=a.audit(s,nr,r))
   assert before==p.digest(s);rows.append(row)
   with journal.open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row,allow_nan=False)+"\n");f.flush();os.fsync(f.fileno())
   return r
  e=engine();r=query(e,4,"parent")
  assert r.completed_depth==4 and len(r.principal_variation)>=2
  for ac in r.principal_variation[:2]:s.submit(ac)
  assert s.result.status.value=="ongoing"
  a.write_record(P/"roots"/("same-child-"+str(i)+"-"+str(ordinal//13)+"-"+name+".json"),dict(ruleset=d["ruleset"],game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=p.digest(s),board_values=d["board_values"],hand_values=d["hand_values"]))
  w=query(e,4,"warm");f=query(engine(),4,"fresh")
  assert w.completed_depth==f.completed_depth==4
  for field in ("score","action","principal_variation","completed_depth"):assert a.record_value(getattr(w,field))==a.record_value(getattr(f,field)),field
  print("DEMOTION",i,name,"hist",rows[-2]["raw"]["private_demotions"],"nodes",w.nodes,f.nodes,flush=True)
a.write_record(P/"same-depth-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("CLOSED",len(rows),time.perf_counter()-start,flush=True)
