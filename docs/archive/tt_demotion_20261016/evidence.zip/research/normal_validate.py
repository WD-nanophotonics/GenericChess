from pathlib import Path
import sys,json,time,subprocess,uuid
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";dest=P/("pytest-product-"+uuid.uuid4().hex[:8]);assert not dest.exists()and dest.resolve().is_relative_to(P.resolve())
cmd=[sys.executable,"-m","pytest","-o","addopts=","-q","-p","no:cacheprovider","--basetemp",str(dest)]
t=time.perf_counter()
try:
 r=subprocess.run(cmd,capture_output=True,timeout=900);out=dict(returncode=r.returncode,stdout=r.stdout.decode("utf-8",errors="replace"),stderr=r.stderr.decode("utf-8",errors="replace"),timed_out=False)
except subprocess.TimeoutExpired as exc:
 out=dict(returncode=124,stdout=(exc.stdout or b"").decode("utf-8",errors="replace"),stderr=(exc.stderr or b"").decode("utf-8",errors="replace"),timed_out=True,actual_timeout_seconds=900)
out.update(command=cmd,seconds=time.perf_counter()-t,scope="Actual rebuilt installed product Native full active regression, exact stdout/exit preserved; no private module injection.")
(P/"product-full-tests.json").write_text(json.dumps(out,indent=2),encoding="utf-8");print(out["stdout"][-5000:]);print(out["stderr"][-1000:]);sys.exit(out["returncode"])
