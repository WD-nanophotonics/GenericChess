from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";F=P/"prospective";sys.path[:0]=[str(F),str(R),str(R/".local_agent/residual-q4-20261016")]
import shadow_loader as g
a=g.a;spec=importlib.util.spec_from_file_location("attribution._native_core",P/"shadow_native_core.pyd");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);fn=m.semantic_engine_search;observed={}
def capture(*args,**kwargs):
 out=fn(*args,**kwargs);observed.clear();observed.update(a.record_value(out));return out
m.semantic_engine_search=capture;rows=[];start=time.perf_counter()-(time.time()-1792104509.5490425);journal=P/"shadow-rows.jsonl";journal.open("x").close()
for case in [x for x in json.loads((F/"plan.json").read_bytes())["inputs"]if x["n"]>=12]:
 for order,names in enumerate([["normal","shadow"],["shadow","normal"]]):
  s,nr,d=g.load(case["seed"])
  for name in names:
   g.p.stopped();assert time.perf_counter()-start<300
   n=nr if name=="normal"else a.nc.compile_native_semantic_rules(s.compiled,backend_module=m)
   e=a.SemanticSearchEngine(s.compiled,n,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=16,ordering_cache_enabled=False)
   t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=5,max_nodes=32768,max_time_seconds=10,quiescence_max_depth=0),root_window_pruning=True)
   row=dict(seed=case["seed"],n=case["n"],order=order,arm=name,result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,n,r),before_sha256=g.p.digest(s))
   if name=="shadow":row["metrics"]={k:v for k,v in observed.items()if k.startswith("shadow_")};assert row["metrics"]["shadow_allocated_bytes"]>0
   rows.append(row)
   with journal.open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n")
  r1,r2=[x["result"]for x in rows[-2:]]
  assert {k:v for k,v in r1.items()if k!="elapsed_seconds"}=={k:v for k,v in r2.items()if k!="elapsed_seconds"},(case,order)
  print("PROFILE",case,order,rows[-2]["result"]["nodes"],rows[-1]["result"]["nodes"],flush=True)
a.write_record(P/"shadow-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("PROFILE_CLOSED",len(rows),time.perf_counter()-start,flush=True)
