from pathlib import Path
import json,random,statistics
P=Path(__file__).resolve().parent;F=P/"prospective";d=json.loads((F/"results.json").read_bytes());rows=d["rows"];assert d["complete"]and len(rows)==256
byboard={}
for n in[4,8,12,16]:
 rr=[r for r in rows if r["n"]==n and r["kind"]=="ACTUAL_QUERY"];fixed=[r for r in rr if r["budget"]=="fixed"];wall=[r for r in rr if r["budget"]=="wall"];families=[]
 for seed in sorted({r["seed"]for r in fixed}):
  ss=[r for r in fixed if r["seed"]==seed];families.append(dict(seed=seed,normal=sum(r["seconds"]for r in ss if r["arm"]=="normal"),witness=sum(r["seconds"]for r in ss if r["arm"]=="witness")))
 ratios=[];rng=random.Random(20261016+n)
 for _ in range(10000):
  draw=rng.choices(families,k=len(families));ratios.append(sum(f["witness"]for f in draw)/sum(f["normal"]for f in draw))
 paired=[]
 for seed in sorted({r["seed"]for r in wall}):
  for order in[0,1]:
   pair={r["arm"]:r["result"]for r in wall if r["seed"]==seed and r["order"]==order}
   a,b=pair["normal"],pair["witness"];paired.append(dict(seed=seed,order=order,depth_delta=b["completed_depth"]-a["completed_depth"],same_action=a["action"]==b["action"],same_score=a["score"]==b["score"]))
 byboard[n]=dict(actual_families=len(families),fixed_queries=len(fixed),fixed_caller_ratio=sum(f["witness"]for f in families)/sum(f["normal"]for f in families),family_bootstrap95=[sorted(ratios)[249],sorted(ratios)[9749]],adverse_families=[f["seed"]for f in families if f["witness"]>f["normal"]],families=families,wall_pairs=len(paired),wall_deeper=sum(x["depth_delta"]>0 for x in paired),wall_same=sum(x["depth_delta"]==0 for x in paired),wall_shallower=sum(x["depth_delta"]<0 for x in paired),wall_action_changes=sum(not x["same_action"]for x in paired),pairs=paired)
out=dict(complete=True,planned_slots=256,actual_queries=sum(r["kind"]=="ACTUAL_QUERY"for r in rows),missing=[{k:v for k,v in r.items()if k!="result"}for r in rows if r["kind"]!="ACTUAL_QUERY"],seconds=d["seconds"],by_board=byboard,scope="31of32newfamilies,9317actualterminalbeforeply8 leaves8slots. Fixed-work124callsallnon-timeequal;62wallpairscompareactualretaineddepths/actions, notstrength. Exploratory10000fixedseed ordinaryfamilybootstrap, no sequential/popuIation guarantee; smallboardcalleroverhead/concurrentload retained.")
(F/"summary.json").write_text(json.dumps(out,indent=2),encoding="utf-8");print(json.dumps({n:{k:v for k,v in x.items()if k not in["families","pairs"]}for n,x in byboard.items()},indent=2))
