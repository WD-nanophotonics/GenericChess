from pathlib import Path
import json,shutil,subprocess,sys,sysconfig,time,hashlib
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";S=P/"shadow_source";S.mkdir(exist_ok=True)
plan=dict(question="Are full-path TT keys missing materially reusable NONLEAF cross-order states even where repetition cannot affect the remaining finite q0 horizon?",changed_premise="Adjacent retention measuredonly3percent sameD4 work and36games onlyLOSS->UNKNOWN, no additionalWIN. Exact fullpath contexts suppress cross-order transpositions; do not blindly weaken history keys or duplicate AUX solver.",hypothesis="On a complete exact history with side flipping each edge, max digest multiplicity M plus ceil(remainingdepth/2) below repetition_limit excludes a repetition threshold before the q0 horizon. Automatic adjudication must be absent; samepositiondigest+historylen+remainingdepth preserves state/ply-sensitive declarations/maxply. This is a source-supported candidate condition, NOT all-domain equivalence proof or score adoption.",source_reads=["native_semantic_runtime.c automatic_status/make_mode/stateguards/declaration ply_limit","native_module.c terminal priority/repetition/native exact-depthTT probe","native_semantic_rules.h declarations/automatic records"],measure="Per-search bounded4096slot shadow tracks same full positiondigest/historylen/depth but different fullpath context, separately safe/nonleaf/leaf. Full original histories and actual TT are unchanged. M propagated from exact rootmax and actual current repetitions; q0exact only.",inputs="ALL16exposed wide prospective roots",max_queries=64,nodes=32768,depth=5,seconds=10,whole_seconds=300,expected_seconds=100,decision="If safe nonleaf opportunities are negligible, stop before implementing a cache rewrite; material opportunities justify one later scoped guard/control only. Counters lowerbound bounded shadow and visits, not independent states, actual savedwork or valid policy equivalence.",scope="PRIVATE measurement only, no cachedscore/cutoff substitution, fullhistory/aux/promotion/drop kept, no product/AUX/default/price changes.")
(P/"shadow-plan.json").write_text(json.dumps(plan,indent=2),encoding="utf-8")
for f in(P/"baseline_source").iterdir():shutil.copyfile(f,S/f.name)
c=S/"native_module.c";s=c.read_text(encoding="utf-8-sig");end=s.index("} GCSemanticIterativeContext;");start=s.rfind("typedef struct {",0,end)
typedef="""typedef struct {
 uint64_t digest[4], context[4]; uint16_t history_len, depth;
 uint8_t occupied, safe;
} PrivateShadowEntry;

"""
s=s[:start]+typedef+s[start:]
mark="    uint32_t tt_iteration_generation;";assert s.count(mark)==1;s=s.replace(mark,"    PrivateShadowEntry *private_shadow;\n    uint16_t private_max[GC_SEM_MAX_PLY+1];\n    uint64_t shadow_visits, shadow_cross_path, shadow_safe_nonleaf, shadow_safe_leaf, shadow_repeated, shadow_collisions, shadow_allocated_bytes;\n"+mark)
end=s.index("} GCSemanticIterativeContext;")+len("} GCSemanticIterativeContext;")
helper="""
static void private_shadow_max(GCSemanticIterativeContext *ctx,const GCSemanticPosition *p,unsigned ply) {
 if (!ctx->private_shadow) return;
 if (!p->history_exact || !p->history_events_exact || p->history_len != p->ply+1 || !p->history_len) {
  ctx->private_max[ply]=UINT16_MAX;return;
 }
 unsigned m=ply ? ctx->private_max[ply-1] : 0;
 if (!ply) {
  for(unsigned i=0;i<p->history_len;i++) { unsigned n=0;
   for(unsigned j=0;j<p->history_len;j++) if(!memcmp(p->history_digest[i],p->history_digest[j],32)) n++;
   if(n>m)m=n;
  }
 } else {
  unsigned n=0;for(unsigned j=0;j<p->history_len;j++)
   if(!memcmp(p->history_digest[p->history_len-1],p->history_digest[j],32))n++;
  if(n>m)m=n;
 }
 ctx->private_max[ply]=(uint16_t)m;
}
static void private_shadow_visit(GCSemanticIterativeContext *ctx,const GCSemanticPosition *p,unsigned ply,unsigned depth,int pv_node,int pv_replay) {
 if (!ctx->private_shadow || pv_node || pv_replay || !p->history_len) return;
 ctx->shadow_visits++;
 const uint64_t *d=p->history_digest[p->history_len-1];
 size_t index=(size_t)(d[0]^d[1]^((uint64_t)p->history_len<<16)^((uint64_t)depth*UINT64_C(0x9e3779b97f4a7c15)))&4095;
 PrivateShadowEntry *e=&ctx->private_shadow[index];
 int safe=ctx->rules->automatic_adjudication_count==0 &&
  ctx->private_max[ply] != UINT16_MAX &&
  (unsigned)ctx->private_max[ply]+(depth+1)/2 < ctx->rules->repetition_limit;
 if(e->occupied && e->history_len==p->history_len && e->depth==depth && !memcmp(e->digest,d,32)) {
  if(memcmp(e->context,ctx->history_context[ply],32)) {
   ctx->shadow_cross_path++;
   if(safe&&e->safe) {if(depth)ctx->shadow_safe_nonleaf++;else ctx->shadow_safe_leaf++;}
  }else ctx->shadow_repeated++;
 } else {
  if(e->occupied)ctx->shadow_collisions++;
  memcpy(e->digest,d,32);memcpy(e->context,ctx->history_context[ply],32);
  e->history_len=p->history_len;e->depth=(uint16_t)depth;e->occupied=1;e->safe=(uint8_t)safe;
 }
}
"""
s=s[:end]+helper+s[end:]
mark="    GCSemanticPosition *position = &ctx->stack[ply];";idx=s.index(mark,s.index("static int gc_semantic_iterative_negamax("))+len(mark);s=s[:idx]+"\n    private_shadow_max(ctx, position, ply);"+s[idx:]
mark="    if (ctx->tt != NULL && !pv_replay) {";idx=s.index(mark,s.index("static int gc_semantic_iterative_negamax("));s=s[:idx]+"    private_shadow_visit(ctx, position, ply, depth, pv_node, pv_replay);\n"+s[idx:]
mark="    memcpy(&ctx.stack[0], position, sizeof(GCSemanticPosition));";assert s.count(mark)==1;s=s.replace(mark,"    if (ctx.root_window_pruning && qdepth==0) ctx.private_shadow=calloc(4096,sizeof(PrivateShadowEntry)); ctx.shadow_allocated_bytes=ctx.private_shadow ? 4096*sizeof(PrivateShadowEntry) : 0;\n"+mark)
start=s.index("static PyObject *gc_semantic_iterative_search(");end=s.index("static PyObject *gc_semantic_search_runtime_sizes(",start);part=s[start:end].replace("free(ctx.stack);","free(ctx.private_shadow); free(ctx.stack);");s=s[:start]+part+s[end:]
mark='        gc_semantic_set_u64(out, "ordering_cache_hits", cache_hits) != 0 ||';assert s.count(mark)==1
extra="".join('        gc_semantic_set_u64(out, "'+name+'", ctx.'+name+') != 0 ||\n'for name in["shadow_visits","shadow_cross_path","shadow_safe_nonleaf","shadow_safe_leaf","shadow_repeated","shadow_collisions","shadow_allocated_bytes"])
s=s.replace(mark,extra+mark);c.write_bytes(s.encode())
cmd=[str(R/".venv/Lib/site-packages/ziglang/zig.exe"),"cc","-target","x86_64-windows-gnu","-shared","-O2","-I"+sysconfig.get_path("include"),"-I"+str(S),"-L"+str(Path(sys.base_prefix)/"libs"),"-lpython312",*[str(f)for f in S.glob("*.c")],"-o",str(P/"shadow_native_core.pyd")]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(P/"shadow-build.json").write_text(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,command=cmd,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()}),indent=2),encoding="utf-8");print("SHADOW_BUILD",r.returncode,r.stderr[-1500:]);sys.exit(r.returncode)
