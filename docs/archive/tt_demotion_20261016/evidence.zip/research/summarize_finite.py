from pathlib import Path
import json,random,statistics,collections,sys
P=Path(__file__).resolve().parent/sys.argv[1];done=json.loads((P/"completion.json").read_bytes());plan=json.loads((P/"plan.json").read_bytes());assert done["complete"]and len(done["games"])==plan["max_games"];by={(g["seed"],g["mode"]):g for g in done["games"]}
def cat(g,role):
 if "result"not in g or g["result"]["status"]=="ongoing":return"UNKNOWN"
 w=g["result"]["winner"];return"DRAW"if w is None else"WIN"if w==role else"LOSS"
value={"WIN":1,"LOSS":-1,"DRAW":0,"UNKNOWN":0};roles=[];families=[];counts={cell:collections.Counter()for cell in"AB"}
for case in plan["inputs"]:
 fr=[]
 for role in[0,1]:
  cats={cell:cat(by[(case["seed"],"A_control"if cell=="A"else"B_role"+str(role))],role)for cell in"AB"}
  for cell,v in cats.items():counts[cell][v]+=1
  row=dict(**case,role=role,categories=cats,delta=value[cats["B"]]-value[cats["A"]]);roles.append(row);fr.append(row)
 families.append(dict(**case,delta=sum(r["delta"]for r in fr)/2))
rng=random.Random(20261016+plan["max_games"]);samples=[]
for _ in range(10000):
 draw=[]
 for n in[4,8,12,16]:
  ff=[f for f in families if f["n"]==n];draw.extend(rng.choices(ff,k=len(ff)))
 samples.append(statistics.mean(f["delta"]for f in draw))
cost={cell:dict(game_seconds=0.,candidate_call_seconds=0.,opponent_call_seconds=0.,queries=0,nodes=0,qnodes=0,tt_hits=0,tt_cutoffs=0)for cell in"AB"};termination=collections.Counter();refusals=[];edges=0
for g in done["games"]:
 if"result"not in g:continue
 cell=g["mode"][0];game=json.loads((P/("game-"+str(g["seed"])+"-"+g["mode"]+".json")).read_bytes());cost[cell]["game_seconds"]+=g["seconds"];edges+=g["edges"]
 for row in game["rows"]:
  assert row["owner"]==("B"if cell=="B"and row["actor"]==int(g["mode"][-1])else"A")
  cost[cell]["candidate_call_seconds"if cell=="B"and row["owner"]=="B"else"opponent_call_seconds"]+=row["actual_call_seconds"]
  if not row["execution_allowed"]:refusals.append(dict(seed=g["seed"],mode=g["mode"],ply=row["ply"],owner=row["owner"],caller_seconds=row["caller_seconds"]))
  for ph in row["phases"]:
   r=ph["result"];cost[cell]["queries"]+=1
   for key in["nodes","qnodes","tt_hits","tt_cutoffs"]:cost[cell][key]+=r[key]
   termination[row["owner"]+":"+r["termination_reason"]]+=1
out=dict(complete=True,planned_slots=plan["max_games"],physical_games=sum("result"in g for g in done["games"]),missing=[g for g in done["games"]if"result"not in g],cells={k:dict(v)for k,v in counts.items()},net_delta=sum(r["delta"]for r in roles),mean_delta=statistics.mean(r["delta"]for r in roles),family_stratified_bootstrap95=[sorted(samples)[249],sorted(samples)[9749]],roles=roles,families=families,transitions=dict(collections.Counter(r["categories"]["A"]+"->"+r["categories"]["B"]for r in roles)),cost=cost,termination=dict(termination),refusals=refusals,physical_edges=edges,batch_seconds=done["seconds"],scope="FixednormalA opponent; separate persistent table pergame/player. All paired roles clustered by predeclaredfamily. UNKNOWN separate; coding0 only finite W-L statistic, not imputed draw/WDL. Ordinary10000sample exploratory family-stratified bootstrap, no sequential/population or all-domain guarantee. Aphysicalcontrol once/Btworoles, unequal raw gamecount. game_seconds exclude init/finalfullJSON; batch includes prior such costs but excludes finalsummary write/preparation/archive.")
(P/"summary.json").write_text(json.dumps(out,indent=2),encoding="utf-8");print("FINITE_SUMMARY",{k:v for k,v in out.items()if k not in["roles","families"]},flush=True)
