from pathlib import Path
import json,shutil,subprocess,sys,sysconfig,time,hashlib
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";S=P/"witness_source";S.mkdir(exist_ok=True)
plan=dict(question="Can rechecking a per-search same-ply physical reply witness reduce the measured q0 terminal availability cost while preserving full terminal/history authority?",changed_premise="Actual48fixed-work source attribution: main terminal25-35percent on12/16boards, hash24-39percent, PVless1percent. Existing q helper already fully rechecks hint; no new memoized terminal result.",scope="PRIVATE exact-root q0 only; arrays per context reset eachsearch. Always validate witness on actualposition; full repetition/PENDING/maxply/declaration priority unchanged. No default/API/price/solver/history reduction.",decision="Reject complete finite score/action/fullPV mismatch or uncontrolled regression; assess all balanced roots not favorablecase. No timed-game strength claim.",max_queries=144,whole_seconds=300,expected_seconds=60)
(P/"witness-plan.json").write_text(json.dumps(plan,indent=2),encoding="utf-8")
for f in(R/"generic_chess/_native").iterdir():
 if f.suffix in(".c",".h"):shutil.copyfile(f,S/f.name)
c=S/"native_module.c";s=c.read_text(encoding="utf-8-sig")
mark="""static int gc_semantic_terminal_status_known(const GCSemanticRules *rules,
                                       const GCSemanticPosition *position,
                                       int *winner_out, const uint64_t *known) {"""
assert s.count(mark)==1
s=s.replace(mark,mark.replace("gc_semantic_terminal_status_known(","gc_semantic_terminal_status_supplied(").replace("const uint64_t *known)","const uint64_t *known, int availability)"))
mark="    int has_action = gc_semantic_has_guarded_action(rules, position, &ok);";assert s.count(mark)==1;s=s.replace(mark,"    int has_action = availability >= 0 ? availability : gc_semantic_has_guarded_action(rules, position, &ok);")
idx=s.index("static int gc_semantic_terminal_status(const GCSemanticRules *rules,")
wrapper="""static int gc_semantic_terminal_status_known(const GCSemanticRules *rules,
 const GCSemanticPosition *position, int *winner_out, const uint64_t *known) {
 return gc_semantic_terminal_status_supplied(rules,position,winner_out,known,-1);
}

"""
s=s[:idx]+wrapper+s[idx:]
mark="    uint32_t tt_iteration_generation;";assert s.count(mark)==1;s=s.replace(mark,"    uint64_t private_reply_hint[GC_SEM_MAX_PLY+1];\n    int private_reply_have[GC_SEM_MAX_PLY+1];\n"+mark)
mark="    int terminal = gc_semantic_terminal_status_known(ctx->rules, position, &winner, known);";assert s.count(mark)==1
s=s.replace(mark,"""    int terminal;
    if (ctx->root_window_pruning && ctx->qdepth_limit == 0) {
        int ok = 1;
        int available = gc_quiet_reply_available(ctx->rules, position, &ok,
            &ctx->private_reply_hint[ply], &ctx->private_reply_have[ply]);
        terminal = ok ? gc_semantic_terminal_status_supplied(
            ctx->rules, position, &winner, known, available) : -1;
    } else terminal = gc_semantic_terminal_status_known(ctx->rules, position, &winner, known);""")
c.write_bytes(s.encode())
cmd=[str(R/".venv/Lib/site-packages/ziglang/zig.exe"),"cc","-target","x86_64-windows-gnu","-shared","-O2","-I"+sysconfig.get_path("include"),"-I"+str(S),"-L"+str(Path(sys.base_prefix)/"libs"),"-lpython312",*[str(f)for f in S.glob("*.c")],"-o",str(P/"witness_native_core.pyd")]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(P/"witness-build.json").write_text(json.dumps(dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t,command=cmd,source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in S.iterdir()}),indent=2),encoding="utf-8");print("WITNESS_BUILD",r.returncode,r.stderr[-1500:]);sys.exit(r.returncode)
