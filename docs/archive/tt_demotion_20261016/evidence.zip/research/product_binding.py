from pathlib import Path
import sys,json,time
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";F=P/"prospective";sys.path[:0]=[str(R),str(R/".local_agent/residual-q4-20261016")]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;old=json.loads((F/"results.json").read_bytes())["rows"];target={(r["seed"],r["order"]):r["result"]for r in old if r["kind"]=="ACTUAL_QUERY"and r["budget"]=="fixed"and r["arm"]=="witness"}
plan=dict(question="Does the rebuilt actual product preserve the counter-free witness prototype's finite results after naming/comments cleanup?",expected_queries=62,depth=4,nodes=8192,seconds=3,whole_seconds=300,expected_seconds=45,scope="Binding/qualification only, already exposed roots; no new strength/independent validation claim.")
a.write_record(P/"product-binding-plan.json",plan);rows=[];start=time.perf_counter()
for seed,order in sorted(target):
 p.stopped();assert time.perf_counter()-start<300;d=json.loads((F/"roots"/(str(seed)+".json")).read_bytes());ir=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d["ruleset"])));c=a.p.SearchMetadataAdapter(ir=ir.ir,_legacy_compiled=ir._legacy_compiled,support=ir.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d["game_record"])));nr=a.nc.compile_native_semantic_rules(c);e=a.SemanticSearchEngine(c,nr,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=16,ordering_cache_enabled=False)
 before=p.digest(s);t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=4,max_nodes=8192,max_time_seconds=3,quiescence_max_depth=0),root_window_pruning=True);rv=a.record_value(r)
 assert{k:v for k,v in rv.items()if k!="elapsed_seconds"}=={k:v for k,v in target[(seed,order)].items()if k!="elapsed_seconds"},(seed,order)
 rows.append(dict(seed=seed,order=order,result=rv,seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r),before_sha256=before,matched_frozen_private=True));assert p.digest(s)==before
a.write_record(P/"product-binding-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("PRODUCT_BINDING",len(rows),time.perf_counter()-start,flush=True)
