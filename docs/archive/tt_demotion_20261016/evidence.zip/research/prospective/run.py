from pathlib import Path
import sys,json,time,importlib.util,os
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";F=P/"prospective";sys.path[:0]=[str(R),str(R/".local_agent/residual-q4-20261016")]
import probe as p
from generic_chess.session.serialization import deserialize_game_record
a=p.a;spec=importlib.util.spec_from_file_location("prospective_witness._native_core",P/"witness_native_core.pyd");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=json.loads((F/"plan.json").read_bytes());assert json.loads((F/"input-manifest.json").read_bytes())["search_queries"]==0
rows=[];start=time.perf_counter();journal=F/"rows.jsonl";journal.open("x").close()
for case in plan["inputs"]:
 for budget in plan["budgets"]:
  for order,names in enumerate(plan["orders"]):
   for name in names:
    p.stopped();row=dict(**case,budget=budget["kind"],order=order,arm=name)
    path=F/"roots"/(str(case["seed"])+".json")
    if not path.exists():row["kind"]="ACTUAL_INPUT_TERMINAL_TAIL_NO_SEARCH"
    elif time.perf_counter()-start>=plan["whole_seconds"]:row["kind"]="WHOLE_CAP_NOT_STARTED_UNKNOWN"
    else:
     d=json.loads(path.read_bytes());ir=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d["ruleset"])));c=a.p.SearchMetadataAdapter(ir=ir.ir,_legacy_compiled=ir._legacy_compiled,support=ir.support)
     s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d["game_record"])));nr=a.nc.compile_native_semantic_rules(c,backend_module=p.m if name=="normal"else m)
     e=a.SemanticSearchEngine(c,nr,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=16,ordering_cache_enabled=False)
     before=p.digest(s);t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=budget["depth"],max_nodes=budget["nodes"],max_time_seconds=budget["seconds"],quiescence_max_depth=0),root_window_pruning=True)
     row.update(kind="ACTUAL_QUERY",result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nr,r),before_sha256=before);assert before==p.digest(s)
    rows.append(row)
    with journal.open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush();os.fsync(f.fileno())
   aa,bb=rows[-2:]
   if "result"in aa and "result"in bb:
    ra,rb=aa["result"],bb["result"]
    if budget["kind"]=="fixed":assert{k:v for k,v in ra.items()if k!="elapsed_seconds"}=={k:v for k,v in rb.items()if k!="elapsed_seconds"},(case,order)
    elif ra["completed_depth"]==rb["completed_depth"]and ra["completed_depth"]>0:
     for k in("score","action","principal_variation","completed_depth"):assert ra[k]==rb[k],(case,order,k)
   print("TRANSFER",case,budget["kind"],order,[r.get("result",{}).get("completed_depth")for r in rows[-2:]],flush=True)
a.write_record(F/"results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("TRANSFER_CLOSED",len(rows),time.perf_counter()-start,flush=True)
