from pathlib import Path
import json,sys,time,hashlib,importlib.util
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";F=P/"witness_finite";sys.path[:0]=[str(F),str(R),str(R/".local_agent/residual-q4-20261016")]
import games as g
a=g.a;rows=[];start=time.perf_counter();plan=dict(question="Does the counter-free candidate preserve complete cold finite objectives on all8 fresh rule roots before timed games?",orders=[["A","B"],["B","A"]],depth=2,nodes=1000000,seconds=3,max_queries=32,whole_seconds=240,expected_seconds=60,decision="Abort on complete score/action/PV mismatch, retain incomplete pairs and all inputs; no cap extension/replacement")
a.write_record(F/"qualification-plan.json",plan)
for case in json.loads((F/"plan.json").read_bytes())["inputs"]:
 for order,names in enumerate(plan["orders"]):
  s,nr,d=g.load(case["seed"])
  for name in names:
   g.p.stopped();assert time.perf_counter()-start<240
   n=nr if name=="A"else a.nc.compile_native_semantic_rules(s.compiled,backend_module=g.pilot);e=a.SemanticSearchEngine(s.compiled,n,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=16,ordering_cache_enabled=False)
   before=g.p.digest(s);t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=2,max_nodes=1000000,max_time_seconds=3,quiescence_max_depth=0),root_window_pruning=True)
   rows.append(dict(seed=case["seed"],n=case["n"],order=order,arm=name,result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,n,r),before_sha256=before));assert g.p.digest(s)==before
   a.write_record(F/"qualification-partial.json",dict(complete=False,rows=rows))
  aa,bb=rows[-2:];ra,rb=aa["result"],bb["result"]
  if ra["completed_depth"]==rb["completed_depth"]==2:
   for key in("score","action","principal_variation","completed_depth"):assert ra[key]==rb[key],(case,key)
  print("QUAL",case,order,ra["completed_depth"],rb["completed_depth"],flush=True)
a.write_record(F/"qualification.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start))
a.write_record(F/"binding.json",dict(plan_sha256=hashlib.sha256((F/"plan.json").read_bytes()).hexdigest(),candidate_source_hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in(P/"witness_source").iterdir()},candidate_image_sha256=hashlib.sha256((P/"witness_native_core.pyd").read_bytes()).hexdigest(),normal_source_sha256=hashlib.sha256((R/"generic_chess/_native/native_module.c").read_bytes()).hexdigest(),qualified=len(rows)))
print("QUAL_CLOSED",len(rows),time.perf_counter()-start,flush=True)
