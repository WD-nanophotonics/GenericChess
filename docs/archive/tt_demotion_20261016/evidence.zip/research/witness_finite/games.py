from pathlib import Path
import sys,json,time,hashlib,importlib.util,os
R=Path.cwd();P=R/'.local_agent/tt-demotion-20261016/witness_finite';O=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(O)]
import probe as p
from policy_games import physical
from generic_chess.session.serialization import deserialize_game_record
a=p.a
def append_row(path,row):
 with path.open('a',encoding='utf-8',newline='\n')as f:
  f.write(json.dumps(row,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
spec=importlib.util.spec_from_file_location('finite_check_only._native_core',P.parent/'witness_native_core.pyd');pilot=importlib.util.module_from_spec(spec);spec.loader.exec_module(pilot)
def load(seed):
 d=json.loads((P/'roots'/f'{seed}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));assert p.digest(s)==d['before_sha256'];nr=a.nc.compile_native_semantic_rules(c,backend_module=p.m);return s,nr,d
def schedule(s,nr,bv,hv,q,token,tt,e):
 start=time.perf_counter();deadline=start+1.
 allowance=deadline-time.perf_counter()-.05
 if allowance<=0:return dict(phases=[],selected=None,selected_source=None,total_nodes=0,caller_seconds=time.perf_counter()-start,execution_allowed=False,cancelled=token.is_cancelled()),None
 r=e.search(s,a.SearchLimits(max_depth=16,max_nodes=1000000,max_time_seconds=allowance,quiescence_max_depth=q,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True,stop_on_immediate_win=True)
 rec=a.record_value(r);row=dict(phases=[dict(q=q,result=rec,allowance=allowance,used_total_nodes=r.nodes+r.qnodes)],selected=rec,selected_source='physical_win'if p.physical(r)else f'single_q{q}',total_nodes=r.nodes+r.qnodes,cancelled=token.is_cancelled())
 row['caller_seconds']=time.perf_counter()-start;row['execution_allowed']=r.action is not None and not token.is_cancelled()and time.perf_counter()<deadline
 return row,r
def run(case,mode,plan,start):
 s,nr,d=load(case['seed']);nrs={0:nr,1:a.nc.compile_native_semantic_rules(s.compiled,backend_module=pilot)};t=time.perf_counter();rows=[];kind=None;token=a.CancellationToken();path=P/f"game-{case['seed']}-{mode}.json";journal=path.with_suffix(".jsonl");journal.open("x").close();engines={actor:a.SemanticSearchEngine(s.compiled,nrs[1 if mode!='A_control' and actor==int(mode[-1])else 0],board_values=d['board_values'],hand_values=d['hand_values'],tt_megabytes=16,ordering_cache_enabled=False)for actor in(0,1)}
 for ply in range(plan['horizon']):
  p.stopped()
  if s.result.status.value!='ongoing':kind='ACTUAL_RULE_TERMINAL';break
  if time.perf_counter()-start>=plan['whole_seconds']:kind='WHOLE_CAP_UNKNOWN';break
  if time.perf_counter()-t>=plan['game_seconds']:kind='GAME_CAP_UNKNOWN';break
  actor=s.state.position.side_to_move;cell=mode[0] if mode!='A_control'and actor==int(mode[-1])else'A';q=0;tt=plan['cells'][cell]['tt_megabytes'];before=p.digest(s);outer=time.perf_counter();row,r=schedule(s,nrs[int(cell=='B')],d['board_values'],d['hand_values'],q,token,tt,engines[actor]);row.update(actual_call_seconds=time.perf_counter()-outer,ply=ply,actor=actor,owner=cell,tt_megabytes=tt,objective=plan['cells'][cell]['objective'],before_sha256=before)
  if not row['execution_allowed']:rows.append(row);append_row(journal,row);kind='CALLER_NO_ACTION_UNKNOWN';break
  action=r.action;row['action']=a.record_value(action);at=time.perf_counter();physical(s,nr,action);row.update(after_sha256=p.digest(s),actual_terminal=a.record_value(s.result),physical_audit_seconds=time.perf_counter()-at);rows.append(row)
  append_row(journal,row)
 kind=kind or('ACTUAL_RULE_TERMINAL'if s.result.status.value!='ongoing'else'PLY_CAP_UNKNOWN')
 out=dict(complete=True,case=case,mode=mode,rows=rows,kind=kind,result=a.record_value(s.result),state=a.record_value(s.state),seconds=time.perf_counter()-t)
 a.write_record(path,out);print('GAME',case,mode,kind,len(rows),out['result']['status'],out['result']['winner'],round(out['seconds'],3),flush=True);return out
if __name__=='__main__':
 plan=json.loads((P/'plan.json').read_bytes());assert json.loads((P/'input-manifest.json').read_bytes())['search_queries']==0
 assert hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest()==plan['source_sha256']
 start=time.perf_counter();games=[]
 for case in plan['inputs']:
  for mode in plan['orders'][case['seed']%2]:
   if not(P/'roots'/f"{case['seed']}.json").exists():games.append(dict(**case,mode=mode,kind='MISSING_INPUT_UNKNOWN'));continue
   if time.perf_counter()-start>=plan['whole_seconds']:games.append(dict(**case,mode=mode,kind='NOT_STARTED_WHOLE_CAP_UNKNOWN'));continue
   out=run(case,mode,plan,start);games.append(dict(**case,mode=mode,kind=out['kind'],result=out['result'],edges=sum('action'in r for r in out['rows']),seconds=out['seconds']));a.write_record(P/'completion-partial.json',dict(complete=False,games=games,seconds=time.perf_counter()-start))
 a.write_record(P/'completion.json',dict(complete=True,games=games,seconds=time.perf_counter()-start));print('ALL_CLOSED',len(games),time.perf_counter()-start,flush=True)
