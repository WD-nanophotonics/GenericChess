from pathlib import Path
import sys,json,time,importlib.util,os
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";F=P/"finite";sys.path[:0]=[str(F),str(R),str(R/".local_agent/residual-q4-20261016")]
import games as g
a=g.a;spec=importlib.util.spec_from_file_location("witness._native_core",P/"witness_native_core.pyd");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=dict(inputs=json.loads((F/"plan.json").read_bytes())["inputs"],conditions=[dict(q=0,exact=True),dict(q=0,exact=False),dict(q=1,exact=True)],orders=[["normal","witness"],["witness","normal"]],nodes=4096,depth=3,seconds=3,whole_seconds=300,max_queries=144,expected_seconds=60,decision="All non-time fields must match at identical completed/fixed-work outcomes; inactive modes test gating. Caller ratio descriptive shared-host; no game/strength inference.")
a.write_record(P/"witness-control-plan.json",plan);rows=[];start=time.perf_counter();journal=P/"witness-rows.jsonl";journal.open("x").close()
for case in plan["inputs"]:
 for cfg in plan["conditions"]:
  for order,names in enumerate(plan["orders"]):
   s,nr,d=g.load(case["seed"])
   for name in names:
    g.p.stopped();assert time.perf_counter()-start<300
    n=nr if name=="normal"else a.nc.compile_native_semantic_rules(s.compiled,backend_module=m)
    e=a.SemanticSearchEngine(s.compiled,n,board_values=d["board_values"],hand_values=d["hand_values"],tt_megabytes=16,ordering_cache_enabled=False)
    before=g.p.digest(s);t=time.perf_counter();r=e.search(s,a.SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=3,quiescence_max_depth=cfg["q"],quiescence_hard_max_depth=8),root_window_pruning=cfg["exact"])
    row=dict(**case,**cfg,order=order,arm=name,result=a.record_value(r),seconds=time.perf_counter()-t,pv_edges=a.audit(s,n,r),before_sha256=before);assert before==g.p.digest(s);rows.append(row)
    with journal.open("a",encoding="utf-8",newline="\n")as f:f.write(json.dumps(row)+"\n");f.flush();os.fsync(f.fileno())
   aa,bb=[x["result"]for x in rows[-2:]];assert{k:v for k,v in aa.items()if k!="elapsed_seconds"}=={k:v for k,v in bb.items()if k!="elapsed_seconds"},(case,cfg,order)
   print("WITNESS",case,cfg,order,aa["completed_depth"],aa["termination_reason"],flush=True)
a.write_record(P/"witness-results.json",dict(complete=True,rows=rows,seconds=time.perf_counter()-start));print("WITNESS_CLOSED",len(rows),time.perf_counter()-start,flush=True)
