from pathlib import Path
import json
P=Path(__file__).resolve().parent
items=[
 dict(issue="Windows command length206 during raw Slack save",impact="Second original not saved by failed command; in-memory original retained",fix="Exclusive-create fragments and a NEW assembled JSON-valid complete original; all older originals kept",resolved=True),
 dict(issue="Auto-review rejected overwriting raw evidence with an incomplete fragment",impact="One local save refused, no Slack send or data publication occurred",fix="Used new exclusive-create fragments/complete files preserving all evidence; actual standing private-save grant retained, no bypass/reconsent",resolved=True),
 dict(issue="Retention source-count guard expected two exact anchors but found one",impact="Assertion before retention compiler/query",fix="Scope store-branch exact anchor; build only after guard correction",resolved=True),
 dict(issue="Private test launcher missing project sys.path",impact="47passed/10import failures in initial57check run",fix="Distinct repaired launcher/receipt;57actual checks pass",resolved=True),
 dict(issue="Two profiling wrapper const warnings",impact="Unused initial private build only, zero profilequeries",fix="Correct signatures before all48profile controls; warning receipt kept",resolved=True),
 dict(issue="Derived witness summary read before producer close",impact="FileNotFound before summary mutation",fix="Read only completed144query output",resolved=True),
 dict(issue="Final reader draft lacked whitespace in conditional token",impact="py_compile rejection before new replay",fix="Correct token before execution; earlier438receipt preserved",resolved=True),
 dict(issue="Shadow ambiguous games import",impact="Zeroqueries, empty first journal",fix="Explicit owned loader; original emptyjournal retained and original300clock includes repair using disclosed creation-time approximation",resolved=True),
 dict(issue="Non-escalated Git read reported not a worktree",impact="Read-only command failed",fix="Authorized supported escalation confirms sandbox clean/nonbare; no Git configuration/security changes or SAC attribution",resolved=True),
 dict(issue="First rebuilt product full suite2685passed/2failed",impact="Fault fixture counted only original availability consumer; new path was not injected/counted",fix="Instrument both actual availability consumers; add plain and learned coverage, preserve every original serializer/error/retained-depth/root/recovery assertion;13targeted pass",resolved=True),
 dict(issue="Targeted repair first used old OS pytest temp root",impact="13setup errors WinError5 at pytest-of-user directory",fix="New verified project-owned basetemp; no OS/security change or unconfirmed SAC attribution",resolved=True),
 dict(issue="Overly broad fixture-signature edit",impact="Second targeted run9passed/4setup errors; new nested tests already passed",fix="Restore original first-test signature; final13tests pass, distinct receipts retained",resolved=True),
 dict(issue="Oversized recovery memo draft",impact="Size assertion before filewrite",fix="Shortened current executable memo within2048bytes; no clockreset",resolved=True)]
(P/"failures.json").write_text(json.dumps(dict(issues=items,current_blocker=False,scope="Actual observed failures and corrections, not hypothetical warnings; final full regression separately captured"),indent=2),encoding="utf-8")
