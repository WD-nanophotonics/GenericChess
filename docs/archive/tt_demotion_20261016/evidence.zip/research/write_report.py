from pathlib import Path
import json,re,hashlib
R=Path.cwd();P=R/".local_agent/tt-demotion-20261016";D=R/"docs/research"
def read(name):return json.loads((P/name).read_bytes())
tests=read("product-full-tests-final.json");assert tests["returncode"]==0;passed=int(re.search(r"(\d+) passed",tests["stdout"]).group(1))
consumer=read("consumer-replay-final.json");assert consumer["complete"]and consumer["queries"]==3126 and consumer["physical_games"]==60
summary=dict(product=dict(source_sha256=hashlib.sha256((R/"generic_chess/_native/native_module.c").read_bytes()).hexdigest(),image_sha256=hashlib.sha256((R/"generic_chess/_native_core.cp312-win_amd64.pyd").read_bytes()).hexdigest(),scope="Checked same-ply physical reply reuse only for existing exact-root disabled-q0; complete original histories/terminal priority. NoTT/key/q/API/price/defaultflag/UI change."),mechanism=read("mechanism-summary.json"),demotion=read("counter-summary.json"),tt_finite=read("finite/summary.json"),source_cost=read("profile-summary.json"),witness_controls=read("witness-summary.json"),prospective=read("prospective/summary.json"),witness_finite=read("witness_finite/summary.json"),curve=read("curve-summary.json"),shadow=read("shadow-summary.json"),qualification=dict(actual_product_full_passed=passed,product_full_seconds=tests["seconds"],initial_product_full=dict(passed=2685,failed=2,reason="Old fixture injected/counted only original availability consumer"),required_error_tests_final=13,private_retention_focused=57,private_witness_focused=81,private_preflight_full=2687,private_preflight_limit="Fault-build fixture then compiled unchanged baseline repository source; actual-product qualification separate.",product_binding_queries=62),consumer=consumer,failures=read("failures.json"),aux66=dict(revision="6c9533a332e646a4b136428f17075ffa047ffd63",report_sha256=hashlib.sha256((P/"aux66-report.md").read_bytes()).hexdigest(),tier="Fixed report read only; no final solver/learning source/test/game/proof execution/adoption",assessment="Useful pooled prices within modifiedKRN4/balancedopponents/equal-proof conditions; no stable universalprice/fullgenerateddomain or sharedworkunit claim."))
(R/"docs/research/data/tt_demotion_20261016.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
text=f"""# Depth retention and checked terminal availability — 2026-10-16

Science is OPEN. PRIMARY owns sandbox backend work; DEV_AUX retains its separate
sidemission solver/learning lane. PUBLIC enables Dot/Chat source and evidence access.

## Delivered decision

Ship checked same-ply reply reuse in existing exact-root, disabled-q0 Native search.
Each search owns bounded per-ply hint arrays. The existing reply helper validates
the hinted action against the actual complete position through the same S0–S4
authority; an invalid hint falls back to generation, and errors propagate.
Only physical availability is supplied to terminal adjudication. Full repetition,
continuous-check events, PENDING/outcomes, rule ply limits, declarations,
promotion/drop/auxiliary state and original histories retain their authority.

The original terminal entry remains a wrapper requesting its own availability.
Non-exact and enabled-q callers keep that route. APIs/result fields/prices/TT keys/
q and default flags/UI are unchanged. Product C SHA256:
{summary['product']['source_sha256']}.
Rebuilt local image SHA256:
{summary['product']['image_sha256']}; binary excluded from Git.

Lookup-tag/deeper-retention stays private. Its finite panel adds no WIN and changes
one LOSS to UNKNOWN. The later context shadow supplies no cached score/key change.

## Demotion mechanism and finite consequences

Thirteen EXPOSED parent/two-PV-move roots are method diagnostics, not independent
validation. Baseline normal C is1c855ae56e946ec6cb8e57f60a36a18cb75cfec2ee8061047469f3e0bee3fac3.
Exact q0 search keeps full state/history and current-depth score bounds.

|Closed diagnostic|Calls|Result|
|---|---:|---|
|Same-key counter D4parent→D2child|78|Normal0demotions; lookup-tag1,237:1,224 depth1→0 and13 depth2→1, generation5→6|
|One shallower-store refusal, reversed image orders|156|Retained warm D2 nodes9,466/fresh13,572=.697465;26/26 lower|
|Same D4 target after two PV moves|156|Retained1,416,818/fresh1,460,590=.970031;18lower/8higher|

All complete cross-image scores/actions/full PVs match. Key identity alone saves
effectively no same-D4 work:1,460,580/1,460,590. Matched remaining-depth savings
do not describe practical same-target cost.

The fresh12-family36-game panel has three4/8/12/16 families each. A=normal;
B=lookup-tag+retention, a JOINT pipeline contrast. Fixed normalA opponents,
separate new TT per game/player retained within the game, same1s/1M main+q/
.05s reserve/D16/64-extra-ply/120s game ceilings and original3300s batch cap.
Requested16MiB allocates11MiB. All36 slots/1,195 edges close, no caller refusals.

Across24 role pairs A=11W11L2UNKNOWN, B=11W10L3UNKNOWN. Sole outcome change
LOSS→UNKNOWN; finite W−L delta+1/24, exploratory family-stratified interval[0,.125].
UNKNOWN stays separate;0 is only the finite statistic coding, never imputed DRAW.
A's12games cost371.137s; B's24 cost767.663s: unequal game counts/paths, not a pure
speed ratio or strength claim. All24 paired paths yield6first divergences/
12distinct complete no-one-ply-win frontiers; no deeper safety/WDL follows.

## Source cost and availability transfer

A48-call normal/profile fixed-work contrast preserves every non-time field.
At12/16boards terminal fractions are.245/.352, generation.100/.189,
ordering.036/.067 and checked traversal.565/.367. Full child hashing is a
NESTED subset,.390/.241. PV reconstruction overlaps those categories and is
.0083/.0077; do not sum it or hashing into an exclusive partition.
Material/TT/budget/declaration/other control remain residual.

Profile/normal caller overhead is1.609/1.163/1.060/1.039 by4/8/12/16.
This is attribution, not faster code. It motivates reusing an already checked
physical-reply helper, without discarding hashes, histories or PV fields.

Counter-free witness144 active/inactive calls preserve all non-time fields,
including enabled-q/legacy guards. Active caller ratios.976/.965/.957/.783;
inactive ratios remain near1.

A protocol frozen BEFORE inputs/search declares32new families/256slots.
Root9317 is terminal before the requested walk root: its8slots remain absent,
no replacement. All248 actual queries are retained;124fixed-work calls match
every non-time field. All62quarter-second pairs retain the same depths/actions.

|Board|Observed families|Caller ratio|Exploratory family bootstrap95%|
|---|---:|---:|---|
|4|8|.984643|[.978618,.991054]|
|8|7|.966245|[.953417,.975881]|
|12|8|.957030|[.941200,.971973]|
|16|8|.909096|[.844516,.958722]|

Adverse4board family9212 is retained. These small ordinary paired-bootstrap
development intervals are not sequential/universal noise guarantees.
Generator initial auxiliary state is empty; full auxiliary mechanisms remain
in semantic qualification and the complete-domain target.

A distinct new8-family24-game witness panel closes703edges. Both arms are
7W7L2UNKNOWN, no caller refusal. Its16paired paths yield2first divergences/
4complete no-one-ply-win frontiers. B439.022s versus twice A226.303s includes
different path lengths, not isolated kernel speed. Observed category/empirical
interval equality is not population equivalence or stronger search.

## Wider completion curve

All192declared calls reuse EXPOSED16wide roots, targetD4,1Mnodes,1/4/16s caps,
two image orders. At12boards both arms finishD4 in12/16pairs at1s and16/16at4/16s.
At16boards normal/candidate D4 counts are0/2 at1s,6/6at4s,16/16at16s.

Candidate retains greater depth four times at1s, none smaller; two actions change.
This is completion capability, not independently better decisions. All joint
finite scores/actions/PVs match; joint-complete caller ratios about.935–.951.
Maximum caller-over-cap.016322s includes packing/features and atomic checks;
no hard-deadline promise. Curve queries submit no moves; game callers separately
refuse an expired outer clock.

## Bounded next context question

A64-call unchanged-TT shadow uses4,096 representative digest/history-length/
remaining-depth slots per search. Every non-time result matches; actual allocation
288KiB per counter call. Across32counter calls:1,047,424visits,134,118cross-path
observations,12,048candidate-safe NONLEAF and122,070leaf observations.
769,878replacements make this a bounded LOWER-BOUND sample, not independent
positions, actual cache hits or saved work.

Candidate condition: exact coherent history, finite q0, no automatic adjudication,
M+ceil(remaining depth/2)<repetition_limit. M is maximum digest multiplicity;
normal side flipping bounds recurrence. Equal full digest/absolute history length
must preserve all physical/auxiliary and ply-sensitive declaration/max-ply inputs.
Continuous-check outcomes require a repetition threshold, proposed excluded here.
This source-supported hypothesis is not all-domain cache equivalence or permission
to remove full histories. No score, terminal result or TT key is substituted.

Next capture one REAL same-state/different-history pair from existing inputs,
replay both complete records and compare small finite continuations before one
optional scoped cache prototype. The full original history and every unsupported
route remain intact. No generic prover/mandatory WDL framework is introduced.

## Actual tests, failures and reproducibility

Actual rebuilt product: **{passed} full active tests pass**. Thirteen required-error
tests cover plain/learned ordering and both availability consumers, preserving
all original serializer/error/retained-depth/root/retry assertions. Four new
parametrized cases explain the full-suite increase. Sixty-two installed-product
fixed-work calls match the frozen private prototype in all non-time fields.

Private preflight2687full/81focused and retention57focused checks overlap.
Its source-building fault fixture still compiled then-current baseline source.
The first ACTUAL-product run exposed two missed instrumentation paths
(2685pass/2fail). Both real consumers are now injected/counted; no assertion is
weakened. The old OS pytest temp root then gave WinError5; a new owned project
temp root resolves it, without machine security changes/SAC speculation.
An overbroad argument edit caused four setup errors and was corrected.
All failed/final receipts remain. Other pre-query import/guard/const-warning/
reader-syntax/raw-save failures and corrections remain in failures.json.
No current consent/OS blocker is inferred.

Final normal search-disabled consumer verifies {consumer['queries']} query receipts,
{consumer['pv_edges']} PV edges,60games/1,898physical edges,438literal replies,
16diagnostic choices and85unique full roots. It checks board/hands/aux/side,
terminals, full digest/event histories, physical transitions, lossless journals
and original budgets. Search is forbidden. Core/compiler/host are shared;
this is not independent rule/WDL validation. Extracted-source rebuild/replay
is separately recorded in the archive publication receipt.

[Structured data](data/tt_demotion_20261016.json) and
[immutable source/evidence/reproduction](../archive/tt_demotion_20261016/README.md)
retain every scientific slot/plan, failed outcome and final executed private
variant. Initial unused pre-query builds are not claimed as separately retained
source snapshots. Publication copies sanitize host paths; exact raw transport/
account originals stay ignored. Final report/replay/session/delivery records
are outside the sealed ZIP.

## Coordination

Closing roots are empty after1792092794.124699; PRIMARY has14unchanged replies.
The complete AUX64 thread has4replies including66delivery1792104854.801789.
Fixed6c9533a report is read: pooled TRAIN price usefulness/equal-proof followup
is relevant within modifiedKRN4; exact/universal ratios and full generated-domain
transfer remain open. No final AUX solver/learning source/tests/games/proofs
are executed/adopted here, no work-unit pooling or cross-checkout write.
AUX has not independently executed this new backend. No duplicate worker,
routine acknowledgement or imported two-hour authority. Fixed-version delivery
enables Dot review without a publication/receipt gate.
"""
(D/"DEPTH_RETENTION_AND_CHECKED_AVAILABILITY_20261016.md").write_text(text,encoding="utf-8");print("REPORT_WRITTEN",passed,consumer["queries"])
