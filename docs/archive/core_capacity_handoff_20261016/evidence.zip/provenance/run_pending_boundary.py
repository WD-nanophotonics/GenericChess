from pathlib import Path
from dataclasses import replace
import sys,json,time,ast,traceback
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from conftest import make_ruleset
from generic_chess import RuleAutomaticAdjudication
from generic_chess.core.pieces import PieceType
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native import SemanticSearchEngine,semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value,write_record
node=next(n for n in ast.parse((P/'run_portability.py').read_text()).body if isinstance(n,ast.ClassDef)and n.name=='Mixed');exec(compile(ast.Module(body=[node],type_ignores=[]),'<same Mixed>','exec'))
plan={'question':'Can actual complete continuously-checking records remain ONGOING beyond rule max and Native capacity, with explicitCore identical3+9 continuation?', 'changed_premise':'Previousfullcapacity PENDING used transport-only editedhistory, and actualmax2048 compile refusal occurred beforestateimport. Buildone declared4board rule withactualrookcheck/kingevasion4cycle, trigger1,max3,rep10000. Noforgedcounts/history/privateinjection.', 'prefixes':[1020,1021,1022,1023,1024,1025],'max_ply':3,'repetition':10000,'trigger':1,'depth':1,'q':0,'nodes':4096,'seconds':3,'whole_seconds':120,'expected_seconds':5,'decision':'ActualCore fullstate/typedPV/feature behavior plus preciseNative supported/refused boundaries; noall-domain orforceproofclaim.'}
write_record(P/'pending-plan.json',plan);start=time.perf_counter();rows=[]
k=PieceType('K','Anchor',(LeapAtom((1,0)),LeapAtom((-1,0))),is_anchor=True)
r=PieceType('R','Checker',(RayAtom((0,1)),LeapAtom((1,0)),LeapAtom((-1,0))))
rules=replace(make_ruleset(4,[k,r],['..k.','.R..','....','K...'],max_ply=3,repetition_limit=10000),automatic_adjudications=(RuleAutomaticAdjudication('opaque',1),))
x=compile_legacy_ruleset_for_semantic_execution(rules);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c);nr=compile_native_semantic_rules(c);bv={'K':0,'R':100};cycle=((1,2,2,2),(2,3,1,3),(2,2,1,2),(1,3,2,3))
def coords(a):return (a.from_square.file,a.from_square.rank,a.to_square.file,a.to_square.rank)
for ply in range(1026):
 for name in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 assert time.perf_counter()-start<120
 if ply in plan['prefixes']:
  assert not s.state.terminal_status.is_terminal
  before=record_value(s.state);row={'prefix':ply,'state':before,'record':json.loads(serialize_game_record(s.to_record())),'features':{'dynamic':reference_features(c,s.state.position),'control9':localized_control_features(s.state.position,c)}}
  lim=SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0)
  t=time.perf_counter();core=AlphaBetaPlayer(c,evaluator_override=Mixed(c,bv,bv),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,lim);row.update(core=record_value(core),core_seconds=time.perf_counter()-t)
  state=s.state;edges=[]
  for action in core.principal_variation:state=apply_action(state,action,c);edges.append({'action':record_value(action),'state':record_value(state)})
  row['pv_edges']=edges
  try:
   t=time.perf_counter();packed=pack_semantic_search_position(c,nr,s);row['native_terminal']=sem.terminal_status(nr,packed)
   native=SemanticSearchEngine(c,nr,board_values=bv,hand_values=bv,dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False).search(s,lim,root_window_pruning=True);row.update(native=record_value(native),native_seconds=time.perf_counter()-t)
  except Exception as e:row.update(native_error=type(e).__name__+': '+str(e),native_traceback=traceback.format_exc())
  assert record_value(s.state)==before;rows.append(row);write_record(P/f'pending-{ply}.json',row);print('PENDING',ply,core.score,row.get('native',{}).get('score'),row.get('native_error'),flush=True)
 if ply<1025:
  want=cycle[ply%4];action=next(a for a in s.legal_actions()if coords(a)==want);s.submit(action)
write_record(P/'pending-results.json',{'complete':True,'rows':rows,'ruleset':record_value(rules),'seconds':time.perf_counter()-start,'scope':'Actualpublic1025actionrecord, checker evidence and everyfullstate retained. No transportfabrication; chosenline notforcedfrontier oroptimalWDL.'})
