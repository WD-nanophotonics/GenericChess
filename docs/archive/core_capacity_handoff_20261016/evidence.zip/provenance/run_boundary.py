from pathlib import Path
import sys,json,time,ast,traceback
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from test_native_q_history_deferral import cycle,checked_replay
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value,write_record
bvs={'K':0,'Z':0,'F':20,'G':100}
node=next(n for n in ast.parse((P/'run_capacity.py').read_text()).body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and getattr(n.value.func,'id',None)=='exec') if False else None
tree=ast.parse((R/'.local_agent/local-control-20261016/complete_finite_alias.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='Mixed');exec(compile(ast.Module(body=[node],type_ignores=[]),'<same Mixed>','exec'))
plan={'question':'Does actual supported1024 ordinaryrule terminal remain distinct from storage refusal with mixed3+9 search near capacity?', 'prefixes':[1021,1022,1023,1024],'max_ply':1024,'repetition':10000,'depths':[1,2],'q':[0,1],'qhard':4,'seconds':3,'nodes':4096,'planned_queries':32,'whole_seconds':120,'changed_premise':'Previousmax2048 is refused atcompile evenprefix0. This uses admittedmax1024 with actual legalrecords, ordinaryMAX_PLY is a legitimate draw, not artificialcapacity adjudication. No stateinjection or newpolicy.', 'decision':'Onlyactualfinite mismatch/wrongcapacityclassification justifies productrepair. Costs notstrength, no automaticfallbackclaim.'}
write_record(P/'boundary-plan.json',plan);rows=[];roots=[];start=time.perf_counter()
with(P/'boundary-queries.jsonl').open('x',encoding='utf-8')as log:
 for prefix in plan['prefixes']:
  s=cycle(max_ply=1024,repetition=10000,prefix=prefix);x=s.compiled;c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,s.to_record());nr=compile_native_semantic_rules(c);before=record_value(s.state)
  roots.append({'prefix':prefix,'record':json.loads(serialize_game_record(s.to_record())),'state':before})
  for depth in plan['depths']:
   for q in plan['q']:
    for arm in('core','native'):
     for name in('rollout','advisor','slack'):
      f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
     assert time.perf_counter()-start<120;t=time.perf_counter();z={'prefix':prefix,'depth':depth,'q':q,'arm':arm}
     try:
      lim=SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=3,quiescence_max_depth=q,quiescence_hard_max_depth=4 if q else 0)
      if arm=='core':r=AlphaBetaPlayer(c,evaluator_override=Mixed(c),use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,lim)
      else:r=SemanticSearchEngine(c,nr,board_values=bvs,hand_values=bvs,dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False).search(s,lim,root_window_pruning=True)
      z.update(kind='ACTUAL_QUERY',result=record_value(r),seconds=time.perf_counter()-t)
      assert record_value(s.state)==before
      st=s.state;edges=[]
      for a in r.principal_variation:st=apply_action(st,a,c);edges.append({'action':record_value(a),'state':record_value(st)})
      z['pv_edges']=edges;z['unchanged_root']=True
     except Exception as e:z.update(kind='ACTUAL_FAILURE',error=type(e).__name__+': '+str(e),traceback=traceback.format_exc())
     rows.append(z);log.write(json.dumps(z)+'\n');log.flush()
write_record(P/'boundary-results.json',{'complete':True,'roots':roots,'rows':rows,'seconds':time.perf_counter()-start});print('BOUNDARY',[(z['prefix'],z['depth'],z['q'],z['arm'],z.get('result',{}).get('score'),z.get('error'))for z in rows],flush=True)
