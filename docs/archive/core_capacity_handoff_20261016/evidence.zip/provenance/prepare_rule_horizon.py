from pathlib import Path
import shutil,json,sys,subprocess,os,hashlib
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016';S=P/'rule-horizon-source'
plan={'question':'Is long-rule admission distinct from Native storage, so bounded Native work can preserve2048rule semantics without increasing1024storage?',
 'changed_premise':'ActualexplicitCoreworks on completehistory but freshsameobjective generatedpanel haswideCoreD1/D2censors whileNative completesD3. Currentcompilerrejectsmax2048 evenprefix0. Sourceinventory showsrulemaxstoredUINT16 separatefrom1024fixedposition/historyarrays; no array maygrow orhistorytruncate.',
 'scope':'PRIVATEfeasibilityonly, no productionadmission/defaultchange, no speculativecapacityincrease, no AUXsolver/learning. ExistingCorealwaysreference for unsupportedpastcapacity. Existingmax1024normalcompiledkernelunchanged.',
 'changes':['privateCparseraccept1..65535rulemax','searchcapacitypreflightalsoapplieswhenrulemaxexceedsstorage','privatePythonpayloadvalidatorallowsrulemaxUINT16 onlyinsidecompile/finallyrestoresnormalconstant'],
 'evidence_plan':'Usealreadyexposed24generatedroots identicalcomplete8plyrecords andsame3+9: privateNative2048 vsstoredNative1024finiteD3 completeobjectives/fields; actualrule2048 fullprefix0/1020..1025 andmax1024/PENDINGcontrols. Atstorage boundary mustexplicitlyrefusebeforesearch, notMAX_PLY/emptyfrontier; rejectUINT16overflow; runtimeposition/undo bytecountsunchanged.',
 'caps':{'build_seconds':180,'actual_queries_max':150,'per_query_seconds':12,'whole_seconds':1800,'expected_seconds':300},
 'decision':'Onlyfeasibilityandcostdiagnosis; counterexampleblocksadoption. Broadengineeringandproductionadmissionneedexplicitqualification/oldkernelcompatibility beyondthisprivatepilot. Do notrenameorrefillbaseline144slots.'}
(P/'rule-horizon-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
S.mkdir(exist_ok=False);(S/'generic_chess').mkdir();(S/'scripts').mkdir()
shutil.copytree(R/'generic_chess/_native',S/'generic_chess/_native')
shutil.copyfile(R/'scripts/build_native_zig.py',S/'scripts/build_native_zig.py')
p=S/'generic_chess/_native/native_semantic_rules.c';s=p.read_text();old='if (max_ply < 1 || max_ply > GC_SEM_MAX_PLY) {';assert s.count(old)==1;s=s.replace(old,'if (max_ply < 1) {');p.write_bytes(s.encode())
p=S/'generic_chess/_native/native_module.c';s=p.read_text();old='if (rules->automatic_adjudication_count &&\n        (unsigned long)position->ply + extra_plies > GC_SEM_MAX_PLY) {';assert s.count(old)==1;s=s.replace(old,'if ((rules->automatic_adjudication_count || rules->max_ply > GC_SEM_MAX_PLY) &&\n        (unsigned long)position->ply + extra_plies > GC_SEM_MAX_PLY) {');p.write_bytes(s.encode())
manifest={str(p.relative_to(S)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in S.rglob('*')if p.is_file()}
(P/'rule-horizon-source-manifest.json').write_bytes(json.dumps(manifest,indent=2).encode())
env=dict(os.environ,ZIG=str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),NATIVE_BUILD_OUT=str(P/'rule_horizon_native_core.pyd'),ZIG_GLOBAL_CACHE_DIR=str(P/'rule-horizon-zig-cache'))
t=subprocess.run([sys.executable,str(S/'scripts/build_native_zig.py')],env=env,cwd=R,timeout=180,capture_output=True,text=True)
(P/'rule-horizon-build-log.txt').write_bytes((t.stdout+t.stderr).encode());print(t.stdout,t.stderr);t.check_returncode()
