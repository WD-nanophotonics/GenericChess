from pathlib import Path
import sys,json,time,ast
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from scripts.research_record import record_value,write_record
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from test_native_q_history_deferral import cycle
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
node=next(n for n in ast.parse((P/'run_portability.py').read_text()).body if isinstance(n,ast.ClassDef)and n.name=='Mixed');exec(compile(ast.Module(body=[node],type_ignores=[]),'<same Mixed>','exec'))
plan={'question':'Does existing Core player preserve fullhistory/evaluator when optional Native legality crosses its newly explicit storage boundary?', 'changed_premise':'Longruleadmission nowallowsNativeSemanticLegalityProvider construction; min(rulemax,storage) guard qualifies onlysource/supports_position sofar. NeedactualCore runtime crossing1024without confusing state-onlyNativefrontier with historyterminal authority.', 'prefixes':[512,1022,1023,1024,1025],'providers':[False,True],'q':[0,1],'depth':3,'nodes':4096,'seconds':3,'whole_seconds':120,'expected_seconds':5,'planned_queries':20,'scope':'Existing4boardactualrecords, same3+9frozen235/first1last-1callback, no automaticfullNativefallback/newAPI/learning orAUXexecution. Actualprovider metrics separate fromsemantic agreement.'}
write_record(P/'hybrid-plan.json',plan);start=time.perf_counter();rows=[];roots=[];bv={'K':0,'Z':0,'F':20,'G':100}
for prefix in plan['prefixes']:
 s=cycle(max_ply=2048,repetition=10000,prefix=prefix);x=s.compiled;c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,s.to_record());before=record_value(s.state);roots.append({'prefix':prefix,'record':json.loads(serialize_game_record(s.to_record())),'state':before})
 for q in(0,1):
  pair=[]
  for provider in(False,True):
   for name in('rollout','advisor','slack'):
    flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
   assert time.perf_counter()-start<120;e=AlphaBetaPlayer(c,evaluator_override=Mixed(c,bv,bv),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=provider,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();r=e.choose_action(s,SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=3,quiescence_max_depth=q,quiescence_hard_max_depth=4 if q else 0));z={'prefix':prefix,'q':q,'provider_requested':provider,'provider_created':e.native_legality_provider is not None,'result':record_value(r),'caller_seconds':time.perf_counter()-t};state=s.state;edges=[]
   for a in r.principal_variation:state=apply_action(state,a,c);edges.append({'action':record_value(a),'state':record_value(state)})
   z['pv_edges']=edges;assert record_value(s.state)==before;assert r.completed_depth==3;assert r.native_legality_operational_failures==0;pair.append(z);rows.append(z)
  for field in('score','action','principal_variation'):assert pair[0]['result'][field]==pair[1]['result'][field]
write_record(P/'hybrid-results.json',{'complete':True,'roots':roots,'rows':rows,'seconds':time.perf_counter()-start,'scope':plan['scope']});print('HYBRID',[(z['prefix'],z['q'],z['provider_requested'],z['result']['native_legality_calls'],z['result']['native_legality_fallbacks'])for z in rows],flush=True)
