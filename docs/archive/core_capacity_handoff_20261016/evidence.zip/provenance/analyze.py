from pathlib import Path
import json,statistics,collections
P=Path('.local_agent/core-capacity-20261016');d=json.loads((P/'portability-results.json').read_bytes());rows=d['rows'];groups=collections.defaultdict(dict)
for r in rows:groups[(r['seed'],r['budget'])][r['arm']]=r
same=[];reference=[];differences=[]
for key,g in groups.items():
 a,b=g['core1024'],g['core2048']
 if a['result']['completed_depth']==b['result']['completed_depth']==3:
  same.append({'seed':key[0],'budget':key[1],'score_equal':a['result']['score']==b['result']['score'],'action_equal':a['result']['action']==b['result']['action'],'pv_equal':a['result']['principal_variation']==b['result']['principal_variation']})
 n=g['native1024']
 if n['result']['completed_depth']==a['result']['completed_depth']==3:
  z={'seed':key[0],'budget':key[1],'native_score':n['result']['score'],'core_score':a['result']['score'],'score_equal':n['result']['score']==a['result']['score'],'core_native_caller_ratio':a['caller_seconds']/n['caller_seconds']}
  reference.append(z)
  if not z['score_equal']:differences.append(z)
summary=[]
for board in(4,8,12,16):
 for budget in(2,12):
  s={'board':board,'budget':budget,'planned_families':6,'actual_families':len({r['seed']for r in rows if r['board']==board}),'arms':{}}
  for arm in('native1024','core1024','core2048'):
   rr=[r for r in rows if r['board']==board and r['budget']==budget and r['arm']==arm]
   s['arms'][arm]={'queries':len(rr),'d3_complete':sum(r['result']['completed_depth']==3 for r in rr),'retained_depths':dict(collections.Counter(r['result']['completed_depth']for r in rr)),'caller_seconds':sum(r['caller_seconds']for r in rr)}
  summary.append(s)
out={'complete':True,'planned_slots':144,'actual_query_receipts':len(rows),'missing_actual_tail_slots':144-len(rows),'actual_terminal_tails':[r for r in d['roots']if r['kind']=='ACTUAL_TERMINAL_TAIL'],'actual_batch_seconds':d['seconds'],'summary':summary,'core_horizon_joint_d3':same,'native_core_joint_d3':reference,'raw_score_differences':differences,'limits':'Core pure callback duplicates mechanical legal generation and differs in searchimplementation/order/mate scale. Finite completedobjective agreement is not strength, automaticfallback or whole-generateddomain proof. 2/12scurves retaincensors/actualtails and concurrenthostload. Datasetnew beforeinputs; privatehorizon extensionusesexposedroots, separatetier.'}
(P/'analysis.json').write_bytes(json.dumps(out,indent=2).encode());print(json.dumps({'core_horizon_joint':len(same),'core_horizon_mismatches':[r for r in same if not(r['score_equal']and r['action_equal']and r['pv_equal'])],'native_core_joint':len(reference),'raw_score_differences':differences},indent=2))
