from pathlib import Path
import json, sys, time, ast
R=Path.cwd(); P=R/'.local_agent/core-capacity-20261016'
sys.path[:0]=[str(R/'tests/product'),str(R/'tests'),str(R)]
from test_native_q_history_deferral import cycle, checked_replay
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
from generic_chess.native import SemanticSearchEngine, semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from scripts.research_record import record_value, write_record
bvs={'K':0,'Z':0,'F':20,'G':100}
tree=ast.parse((R/'.local_agent/local-control-20261016/complete_finite_alias.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Mixed')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<prior Mixed exact class>','exec'))
plan=json.loads((R/'docs/research/data/core_capacity_followup_plan_20261016.json').read_bytes())
write_record(P/'plan.json',plan)
out=[]; start=time.perf_counter()
for prefix in (0,1024):
 for name in ('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes()); assert not(f.get('stopped')or f.get('user_paused'))
 s=cycle(max_ply=2048,repetition=10000,prefix=prefix)
 old=s.compiled;c=SearchMetadataAdapter(ir=old.ir,_legacy_compiled=old._legacy_compiled,support=old.support)
 s=GameSession.replay(c,s.to_record()); before=record_value(s.state)
 assert not s.state.terminal_status.is_terminal
 lim=SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0)
 ev=Mixed(c); features={'dynamic':reference_features(c,s.state.position),'localized':localized_control_features(s.state.position,c)}
 try:
  t=time.perf_counter();nr=compile_native_semantic_rules(c)
  native=SemanticSearchEngine(c,nr,board_values=bvs,hand_values=bvs,dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False).search(s,lim,root_window_pruning=True)
  native_result={'result':record_value(native),'seconds':time.perf_counter()-t}
  checked_replay(s,nr,native)
 except Exception as e:
  native_result={'error_type':type(e).__name__,'error':str(e),'seconds':time.perf_counter()-t}
 t=time.perf_counter();core=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,use_native_semantic_availability=False,use_native_semantic_check=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,lim)
 core_seconds=time.perf_counter()-t
 assert core.completed_depth==1 and core.action in s.legal_actions()
 state=s.state;edges=[]
 for action in core.principal_variation:
  state=apply_action(state,action,c);edges.append({'action':record_value(action),'state':record_value(state)})
 assert record_value(s.state)==before
 row={'prefix':prefix,'record':json.loads(serialize_game_record(s.to_record())),'state':before,'features':record_value(features),'root_eval':ev.evaluate(s.state),'native':native_result,'core':record_value(core),'core_seconds':core_seconds,'pv_edges':edges,'unchanged_root':True}
 out.append(row); write_record(P/f'case-{prefix}.json',row)
 assert time.perf_counter()-start<plan['whole_seconds']
assert out[0]['features']==out[1]['features'] and out[0]['state']['position']==out[1]['state']['position']
write_record(P/'results.json',{'complete':True,'rows':out,'seconds':time.perf_counter()-start,'scope':'Explicit existing Core consumer, not automatic product fallback; no truncation or AUX execution.'})
print(json.dumps({'seconds':time.perf_counter()-start,'cases':[{k:r[k] for k in ('prefix','root_eval','core_seconds','native')} for r in out]},default=str))
