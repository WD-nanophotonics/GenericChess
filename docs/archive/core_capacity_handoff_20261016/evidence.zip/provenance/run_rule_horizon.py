from pathlib import Path
import sys,json,time,importlib.util,traceback,copy
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from scripts.research_record import record_value,write_record
from scripts.full_q_refresh_comparison import SearchMetadataAdapter
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine,semantic as sem
from generic_chess.native import compiler as nc
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from test_native_q_history_deferral import cycle
plan=json.loads((P/'rule-horizon-plan.json').read_bytes());assert(P/'portability-results.json').exists()
spec=importlib.util.spec_from_file_location('private_rule_horizon._native_core',P/'rule_horizon_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def compile_private(c):
 # Scoped payload-admission research only. Restore production constant even on error.
 old=nc.GC_SEM_MAX_PLY
 try:
  nc.GC_SEM_MAX_PLY=65535
  return nc.compile_native_semantic_rules(c,backend_module=m)
 finally:nc.GC_SEM_MAX_PLY=old
def compiled(r):
 x=compile_legacy_ruleset_for_semantic_execution(r)
 return SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support)
def stop():
 for name in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 assert time.perf_counter()-start<1800
base=json.loads((P/'portability-results.json').read_bytes());rows=[];capacity=[];start=time.perf_counter()
assert m.semantic_search_runtime_sizes()==__import__('generic_chess.native',fromlist=['_module'])._module().semantic_search_runtime_sizes()
with(P/'rule-horizon-queries.jsonl').open('x',encoding='utf-8')as log:
 for root in base['roots']:
  if root['kind']!='ACTUAL_ROOT':continue
  stop();d=json.loads((P/'portability-roots'/f"{root['seed']}.json").read_bytes());c=compiled(deserialize_ruleset(json.dumps(d['rulesets']['2048'])));s=GameSession.replay(c,deserialize_game_record(json.dumps(d['records']['2048'])));before=record_value(s.state);nr=compile_private(c)
  for budget in(2,12):
   stop();z={'seed':root['seed'],'board':root['board'],'budget':budget,'arm':'private_native2048'};t=time.perf_counter()
   try:
    e=SemanticSearchEngine(c,nr,board_values=d['board_values'],hand_values=d['hand_values'],dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False)
    r=e.search(s,SearchLimits(max_depth=3,max_nodes=131072,max_time_seconds=budget,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True)
    z.update(kind='ACTUAL_QUERY',result=record_value(r),caller_seconds=time.perf_counter()-t);assert record_value(s.state)==before
    state=s.state;edges=[]
    for action in r.principal_variation:state=apply_action(state,action,c);edges.append({'action':record_value(action),'state':record_value(state)})
    z.update(root_unchanged=True,pv_edges=edges)
   except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
   rows.append(z);log.write(json.dumps(z)+'\n');log.flush();print('LONGRULE',root['seed'],budget,z['kind'],z.get('result',{}).get('completed_depth'),round(time.perf_counter()-start,2),flush=True)
 for prefix in(0,1020,1021,1022,1023,1024,1025):
  stop();s=cycle(max_ply=2048,repetition=10000,prefix=prefix);x=s.compiled;c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession.replay(c,s.to_record());nr=compile_private(c);z={'prefix':prefix,'state':record_value(s.state),'record':record_value(s.to_record())}
  try:
   p=pack_semantic_search_position(c,nr,s);z['native_terminal']=sem.terminal_status(nr,p);e=SemanticSearchEngine(c,nr,tt_megabytes=0);r=e.search(s,SearchLimits(max_depth=1,max_nodes=4096,max_time_seconds=3,quiescence_max_depth=0,quiescence_hard_max_depth=0));z['result']=record_value(r)
  except Exception as exc:z['error']=type(exc).__name__+': '+str(exc)
  capacity.append(z);print('LONGCAP',prefix,z.get('error'),flush=True)
payload,nreport=nc.build_semantic_compile_payload(compiled(deserialize_ruleset(json.dumps(json.loads(next((P/'portability-roots').glob('*.json')).read_bytes())['rulesets']['1024']))))
invalid=[]
for value in(0,65536):
 try:m.compile_semantic_rules(dict(payload,max_ply=value))
 except Exception as exc:invalid.append({'max_ply':value,'error':type(exc).__name__+': '+str(exc)})
 else:raise AssertionError('UINT16invalidaccepted')
write_record(P/'rule-horizon-results.json',{'complete':True,'rows':rows,'capacity':capacity,'invalid_rules':invalid,'runtime_sizes':m.semantic_search_runtime_sizes(),'seconds':time.perf_counter()-start,'scope':plan['scope'],'production_constant_restored':nc.GC_SEM_MAX_PLY==1024})
