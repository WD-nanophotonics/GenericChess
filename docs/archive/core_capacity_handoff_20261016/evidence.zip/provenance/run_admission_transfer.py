from pathlib import Path
from dataclasses import replace
import sys,json,time,random,importlib.util,traceback
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,generate_game,GeneratorConfig,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.core.transition import apply_action
plan=json.loads((P/'admission-plan.json').read_bytes());start=time.perf_counter();rows=[];roots=[];rd=P/'admission-roots';rd.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('old_horizon._native_core',P/'baseline_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def stop():
 for name in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 assert time.perf_counter()-start<600
with(P/'admission-queries.jsonl').open('x',encoding='utf-8')as log:
 for idx,case in enumerate(plan['cases']):
  root=dict(case);t=time.perf_counter()
  try:
   stop();g=generate_game(GeneratorConfig(seed=case['seed'],board_size=case['board'],setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));sessions={};rules={}
   for horizon in(1024,2048):
    rules[horizon]=replace(g.ruleset,max_ply=horizon);x=compile_legacy_ruleset_for_semantic_execution(rules[horizon]);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c);rng=random.Random(case['seed']+700000)
    for j in range(8):
     if s.state.terminal_status.is_terminal:break
     aa=sorted(s.legal_actions(),key=repr)
     if not aa:break
     s.submit(rng.choice(aa))
    sessions[horizon]=s
   s=sessions[1024];v=build_ruleset_profile(s.compiled,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()};states={h:record_value(z.state)for h,z in sessions.items()}
   a=record_value(sessions[1024].state.position);b=record_value(sessions[2048].state.position);a.pop('ruleset_fingerprint');b.pop('ruleset_fingerprint');assert a==b
   assert[r.action_signature for r in s.state.history]==[r.action_signature for r in sessions[2048].state.history]
   root.update(kind='ACTUAL_ROOT',actual_ply=s.state.ply_count,terminal=record_value(s.state.terminal_status),acquisition_seconds=time.perf_counter()-t);roots.append(root)
   write_record(rd/f"{case['seed']}.json",{'case':case,'rulesets':{h:json.loads(serialize_ruleset(z))for h,z in rules.items()},'records':{h:json.loads(serialize_game_record(z.to_record()))for h,z in sessions.items()},'states':states,'board_values':bv,'hand_values':hv})
   if s.state.terminal_status.is_terminal or s.state.ply_count<8:root['kind']='ACTUAL_TERMINAL_TAIL';continue
   nrs={'old_native1024':compile_native_semantic_rules(sessions[1024].compiled,backend_module=m),'candidate_native2048':compile_native_semantic_rules(sessions[2048].compiled)}
   for rep in range(2):
    pair=[]
    for arm in(plan['arms']if(idx+rep)%2==0 else list(reversed(plan['arms']))):
     stop();h=1024 if arm=='old_native1024'else 2048;ss=sessions[h];z=dict(**case,arm=arm,rep=rep);tq=time.perf_counter()
     try:
      e=SemanticSearchEngine(ss.compiled,nrs[arm],board_values=bv,hand_values=hv,dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False)
      r=e.search(ss,SearchLimits(max_depth=3,max_nodes=131072,max_time_seconds=4,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True);z.update(kind='ACTUAL_QUERY',result=record_value(r),caller_seconds=time.perf_counter()-tq);assert record_value(ss.state)==states[h]
      state=ss.state;edges=[]
      for action in r.principal_variation:state=apply_action(state,action,ss.compiled);edges.append({'action':record_value(action),'state':record_value(state)})
      z.update(root_unchanged=True,pv_edges=edges)
     except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
     rows.append(z);pair.append(z);log.write(json.dumps(z)+'\n');log.flush();print('ADMISSION',case['seed'],rep,arm,z['kind'],z.get('result',{}).get('completed_depth'),round(time.perf_counter()-start,2),flush=True)
    if len(pair)==2 and all(z['kind']=='ACTUAL_QUERY'and z['result']['completed_depth']==3 for z in pair):assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
  except Exception as exc:root.update(kind='ACTUAL_ROOT_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc());print('ROOTFAIL',case,root['error'],flush=True)
  write_record(P/'admission-progress.json',{'complete':False,'roots':roots,'queries':len(rows)})
write_record(P/'admission-results.json',{'complete':True,'roots':roots,'rows':rows,'planned_slots':64,'actual_queries':sum(r['kind']=='ACTUAL_QUERY'for r in rows),'seconds':time.perf_counter()-start,'scope':plan['scope']});print('DONE',len(rows),time.perf_counter()-start,flush=True)
