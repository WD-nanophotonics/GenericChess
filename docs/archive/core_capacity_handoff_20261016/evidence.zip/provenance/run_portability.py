from pathlib import Path
from dataclasses import replace
import sys,json,time,random,traceback
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from scripts.full_q_refresh_comparison import SearchMetadataAdapter,compile_legacy_ruleset_for_semantic_execution,generate_game,GeneratorConfig,EvaluationConfig,build_ruleset_profile,GameSession,SearchLimits
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
from generic_chess.core.transition import apply_action
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from test_native_dynamic_feature_views import reference_features
from generic_chess.learning.features import localized_control_features
plan={'question':'Does explicit existing Core preserve the same mixed objective when ONLY rule horizon exceeds Native admission, and what finite completion cost is actually paid?',
 'changed_premise':'Two actual long forced-cycle records succeeded under explicitCore, but a unique-action4board specification does not establish transfer or cost on generated choices. Compare TWOmaxhorizons on identical freshgenerated mechanics and actual8plyrecord, Native admitted1024 reference plus pureCore1024 andCore2048. FiniteD3 frontier stays farbelow BOTHlimits, so objective must agree when complete; q0/TT0 samecallback.',
 'cases':[{'board':b,'seed':121000+b*100+i}for b in(4,8,12,16)for i in range(1,7)],'seconds':[2,12],'depth':3,'nodes':131072,'arms':['native1024','core1024','core2048'],'planned_slots':144,'whole_seconds':1800,'expected_seconds':600,
 'scope':'Development transfer, not all-domain/equalstrength or automaticfallback. Promotion/drop/aux/completehistory retained, staticruleprices frozenshared, mechanical3+9untrainedweights235/first1last-1. Actualtails/failures/missing/UNKNOWN retained; no replacement/extension/newlearner or AUXexecution.',
 'decision':'If completefinite objectives differ, diagnose before claiming portability. If explicitCore remains slow/censored, describe cost rather than silentmaterial substitution, no newAPI or largerNativecapacity based on this alone. No unchangedfusion/outline rerun.'}
write_record(P/'portability-plan.json',plan);start=time.perf_counter();rows=[];roots=[];rd=P/'portability-roots';rd.mkdir(exist_ok=False)
def stop():
 for name in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/f'{name}.json').read_bytes())
  if f.get('stopped')or f.get('user_paused'):raise RuntimeError('USER_STOP')
 if time.perf_counter()-start>plan['whole_seconds']:raise TimeoutError('WHOLE_CAP')
class Mixed:
 def __init__(self,c,bv,hv):self.c=c;self.bv=bv;self.hv=hv
 def evaluate(self,state):
  p=state.position;side=p.side_to_move
  mat=sum((1 if x.owner==side else -1)*self.bv[x.current_type_id]for x in p.board if x is not None)+sum((1 if o==side else -1)*self.hv[t]*n for o,h in enumerate(p.hands)for t,n in h.items())
  f=reference_features(self.c,p);v=localized_control_features(p,self.c)
  return max(-90000000,min(90000000,mat+(1 if side==0 else -1)*(sum(w*x for w,x in zip((2,3,5),f))+v[0]-v[-1])))
 def type_value(self,t):return self.bv[t]
 def capture_order_value(self,m,c):return 10*self.bv[c.current_type_id]-self.bv[m.current_type_id]
with(P/'portability-queries.jsonl').open('x',encoding='utf-8')as log:
 for idx,case in enumerate(plan['cases']):
  root=dict(case);t=time.perf_counter()
  try:
   stop();g=generate_game(GeneratorConfig(seed=case['seed'],board_size=case['board'],setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32));sessions={};rules={}
   for horizon in(1024,2048):
    rules[horizon]=replace(g.ruleset,max_ply=horizon);x=compile_legacy_ruleset_for_semantic_execution(rules[horizon]);c=SearchMetadataAdapter(ir=x.ir,_legacy_compiled=x._legacy_compiled,support=x.support);s=GameSession(c);rng=random.Random(case['seed']+700000)
    for j in range(8):
     if s.state.terminal_status.is_terminal:break
     aa=sorted(s.legal_actions(),key=repr)
     if not aa:break
     s.submit(rng.choice(aa))
    sessions[horizon]=s
   s=sessions[1024];v=build_ruleset_profile(s.compiled,EvaluationConfig());bv={k:int(round(x))for k,x in v.board_value_by_type.items()};hv={k:int(round(x))for k,x in v.hand_value_by_base_type.items()}
   states={h:record_value(z.state)for h,z in sessions.items()}
   a=record_value(sessions[1024].state.position);b=record_value(sessions[2048].state.position);a.pop('ruleset_fingerprint');b.pop('ruleset_fingerprint');assert a==b
   assert [r.action_signature for r in s.state.history]==[r.action_signature for r in sessions[2048].state.history]
   root.update(kind='ACTUAL_ROOT',actual_ply=s.state.ply_count,terminal=record_value(s.state.terminal_status),acquisition_seconds=time.perf_counter()-t)
   write_record(rd/f"{case['seed']}.json",{'case':case,'rulesets':{h:json.loads(serialize_ruleset(z))for h,z in rules.items()},'records':{h:json.loads(serialize_game_record(z.to_record()))for h,z in sessions.items()},'states':states,'board_values':bv,'hand_values':hv})
   roots.append(root)
   if s.state.terminal_status.is_terminal or s.state.ply_count<8:
    root['kind']='ACTUAL_TERMINAL_TAIL';continue
   nr=compile_native_semantic_rules(s.compiled)
   for bi,budget in enumerate(plan['seconds']):
    arms=plan['arms']if(idx+bi)%2==0 else list(reversed(plan['arms']))
    for arm in arms:
     stop();h=2048 if arm=='core2048' else 1024;ss=sessions[h];z=dict(**case,arm=arm,budget=budget);tq=time.perf_counter()
     try:
      lim=SearchLimits(max_depth=3,max_nodes=131072,max_time_seconds=budget,quiescence_max_depth=0,quiescence_hard_max_depth=0)
      if arm=='native1024':e=SemanticSearchEngine(ss.compiled,nr,board_values=bv,hand_values=hv,dynamic_values=(2,3,5),localized_control_values=(1,0,0,0,0,0,0,0,-1),tt_megabytes=0,ordering_cache_enabled=False);r=e.search(ss,lim,root_window_pruning=True)
      else:e=AlphaBetaPlayer(ss.compiled,evaluator_override=Mixed(ss.compiled,bv,hv),use_tt=False,use_ordering=False,use_disk_cache=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False));r=e.choose_action(ss,lim)
      z.update(kind='ACTUAL_QUERY',result=record_value(r),caller_seconds=time.perf_counter()-tq)
      assert record_value(ss.state)==states[h]
      state=ss.state;edges=[]
      for action in r.principal_variation:
       state=apply_action(state,action,ss.compiled);edges.append({'action':record_value(action),'state':record_value(state)})
      z['pv_edges']=edges;z['root_unchanged']=True
     except Exception as exc:z.update(kind='ACTUAL_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc())
     rows.append(z);log.write(json.dumps(z)+'\n');log.flush();print('QUERY',case['seed'],arm,budget,z['kind'],z.get('result',{}).get('completed_depth'),round(time.perf_counter()-start,2),flush=True)
  except Exception as exc:
   root.update(kind='ACTUAL_ROOT_FAILURE',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc());roots.append(root);print('ROOTFAIL',case,root['error'],flush=True)
  write_record(P/'portability-progress.json',{'complete':False,'roots':roots,'query_receipts':len(rows)})
write_record(P/'portability-results.json',{'complete':True,'roots':roots,'rows':rows,'planned_slots':144,'actual_queries':sum(r['kind']=='ACTUAL_QUERY'for r in rows),'seconds':time.perf_counter()-start,'scope':plan['scope']})
print('DONE',len(rows),time.perf_counter()-start,flush=True)
