from pathlib import Path
import json,collections
P=Path('.local_agent/core-capacity-20261016');b=json.loads((P/'portability-results.json').read_bytes());d=json.loads((P/'rule-horizon-results.json').read_bytes());old={(r['seed'],r['budget']):r for r in b['rows']if r['arm']=='native1024'};pairs=[];mismatches=[]
for r in d['rows']:
 o=old[r['seed'],r['budget']];joint=r['result']['completed_depth']==o['result']['completed_depth']==3
 z={'seed':r['seed'],'board':r['board'],'budget':r['budget'],'joint_d3':joint,'old_depth':o['result']['completed_depth'],'private_depth':r['result']['completed_depth']}
 if joint:
  diff={k:[o['result'].get(k),r['result'].get(k)]for k in set(o['result'])|set(r['result'])if k!='elapsed_seconds'and o['result'].get(k)!=r['result'].get(k)}
  z['non_time_differences']=diff;z['private2048_old1024_caller_ratio']=r['caller_seconds']/o['caller_seconds']
  if diff:mismatches.append(z)
 pairs.append(z)
out={'complete':True,'private_query_receipts':len(d['rows']),'joint_d3':sum(z['joint_d3']for z in pairs),'non_time_mismatches':mismatches,'pairs':pairs,'capacity':[{'prefix':r['prefix'],'status':r['state']['terminal_status'],'error':r.get('error'),'has_result':'result'in r}for r in d['capacity']],'runtime_sizes':d['runtime_sizes'],'production_constant_restored':d['production_constant_restored'],'seconds':d['seconds'],'scope':'Exposed same-root private feasibility; NOT production admission/capacity change, prospective transfer or strength. Preserves all original 144slots/failures/censors.'}
(P/'rule-horizon-analysis.json').write_bytes(json.dumps(out,indent=2).encode());print(json.dumps({k:v for k,v in out.items()if k!='pairs'},indent=2))
