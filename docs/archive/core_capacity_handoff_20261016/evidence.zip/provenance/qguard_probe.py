"""Private changed-premise followup: cost of a provably impossible threshold."""
from pathlib import Path
import sys,json,shutil,os,subprocess,importlib.util,time
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016';sys.path[:0]=[str(R),str(R/'tests'),str(R/'tests/product')]
from scripts.research_record import write_record,record_value
from test_native_q_history_deferral import cycle,checked_replay
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.limits import SearchLimits
plan={'question':'Does q-history repetition multiplicity scanning have meaningful actualcaller cost when the configuredthreshold exceeds the entire retainedhistory?', 'changed_premise':'Newlongruleadmission makes real512/900ply high-threshold records usable without increasingstorage. Cqguard still does nestedhistorymultiplicityscan although M<=history_len<R-1 proves the existinggate. Needactualcostbeforemoreengineering; doNOTrerunoldqgames orclaimstrength.', 'prefixes':[0,128,512,900],'profiles':['static','mixed'],'repetitions':4,'arms':['normal','private_early_bound'],'depth':3,'qdepth':1,'qhard':4,'nodes':4096,'seconds':3,'whole_seconds':300,'expected_seconds':30,'planned_queries':64,'scope':'Existing4boardrealcyclicspecification, max2048/repetition10000. Privateone-comparison qguard only after existingautomatic/history/capacity checks; no productadoption fromthispilot, no changedterminal/feature/default/AIpolicy.', 'decision':'Ifcallerbenefitnegligible, stop. Anycompletefinite/non-time mismatch blocks. Ifmateriallycheaper, nextcompareordinarythresholdcheapcontrols andmatchedrealconsumerbeforeadoption; no unchangedbroadqcampaign.'}
write_record(P/'qguard-plan.json',plan);S=P/'qguard-source';(S/'generic_chess').mkdir(parents=True,exist_ok=False);(S/'scripts').mkdir();shutil.copytree(R/'generic_chess/_native',S/'generic_chess/_native');shutil.copyfile(R/'scripts/build_native_zig.py',S/'scripts/build_native_zig.py')
p=S/'generic_chess/_native/native_module.c';s=p.read_text();needle='unsigned int forbidden = rules->repetition_limit - 1;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    if (position->history_len < forbidden) return 1;');p.write_bytes(s.encode())
env=dict(os.environ,ZIG=str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),NATIVE_BUILD_OUT=str(P/'qguard_native_core.pyd'),ZIG_GLOBAL_CACHE_DIR=str(P/'qguard-zig-cache'))
t=time.perf_counter();r=subprocess.run([sys.executable,str(S/'scripts/build_native_zig.py')],env=env,timeout=180,capture_output=True,text=True);(P/'qguard-build-log.txt').write_bytes((r.stdout+r.stderr).encode());r.check_returncode()
spec=importlib.util.spec_from_file_location('qguard._native_core',P/'qguard_native_core.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);rows=[];bv={'K':0,'Z':0,'F':20,'G':100}
with(P/'qguard-queries.jsonl').open('x',encoding='utf-8')as log:
 for prefix in plan['prefixes']:
  s=cycle(max_ply=2048,repetition=10000,prefix=prefix);nrs={'normal':compile_native_semantic_rules(s.compiled),'private_early_bound':compile_native_semantic_rules(s.compiled,backend_module=m)};before=record_value(s.state)
  for pi,profile in enumerate(plan['profiles']):
   for rep in range(4):
    pair=[]
    for arm in(plan['arms']if(rep+pi)%2==0 else list(reversed(plan['arms']))):
     for name in('rollout','advisor','slack'):
      flags=json.loads((R/'.local_agent'/f'{name}.json').read_bytes());assert not(flags.get('stopped')or flags.get('user_paused'))
     assert time.perf_counter()-t<300
     e=SemanticSearchEngine(s.compiled,nrs[arm],board_values=bv,hand_values=bv,dynamic_values=(2,3,5)if profile=='mixed'else None,localized_control_values=(1,0,0,0,0,0,0,0,-1)if profile=='mixed'else None,tt_megabytes=0,ordering_cache_enabled=False)
     tq=time.perf_counter();r=e.search(s,SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=3,quiescence_max_depth=1,quiescence_hard_max_depth=4),root_window_pruning=True);z={'prefix':prefix,'profile':profile,'rep':rep,'arm':arm,'result':record_value(r),'caller_seconds':time.perf_counter()-tq};checked_replay(s,nrs[arm],r);assert record_value(s.state)==before;pair.append(z);rows.append(z);log.write(json.dumps(z)+'\n');log.flush()
    assert{k:v for k,v in pair[0]['result'].items()if k!='elapsed_seconds'}=={k:v for k,v in pair[1]['result'].items()if k!='elapsed_seconds'}
write_record(P/'qguard-results.json',{'complete':True,'rows':rows,'seconds':time.perf_counter()-t,'scope':plan['scope']});print('QGUARD',len(rows),time.perf_counter()-t,flush=True)
