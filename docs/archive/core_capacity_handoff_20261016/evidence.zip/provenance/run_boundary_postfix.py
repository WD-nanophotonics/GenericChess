from pathlib import Path
p=Path('.local_agent/core-capacity-20261016')
source=(p/'run_boundary.py').read_text().replace("P/'boundary-", "P/'postfix-boundary-")
exec(compile(source, '<postfix boundary exact same protocol, distinct outputs>', 'exec'))
