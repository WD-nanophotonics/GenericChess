from pathlib import Path
import os,sys,subprocess,json,time
R=Path.cwd();P=R/'.local_agent/core-capacity-20261016'
env=dict(os.environ,ZIG=str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),NATIVE_BUILD_OUT=str(P/'rule_horizon_native_core.pyd'),ZIG_GLOBAL_CACHE_DIR=str(P/'rule-horizon-zig-cache'))
t=time.perf_counter();r=subprocess.run([sys.executable,str(P/'rule-horizon-source/scripts/build_native_zig.py')],env=env,cwd=R,timeout=180,capture_output=True,text=True)
(P/'rule-horizon-build-retry-log.txt').write_bytes((r.stdout+r.stderr).encode());print(r.stdout,r.stderr)
(P/'rule-horizon-build-retry.json').write_bytes(json.dumps({'exit_code':r.returncode,'seconds':time.perf_counter()-t,'reason':'Sandbox AccessDenied reading Python libs; authorized normal escalation, no machine security changes.'},indent=2).encode());r.check_returncode()
