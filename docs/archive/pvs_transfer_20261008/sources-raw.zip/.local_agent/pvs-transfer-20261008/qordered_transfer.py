import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'qordered-transfer.json';assert not out.exists();src=root/'.local_agent/generated8-20261008/transfer.json';source=json.loads(src.read_bytes());assert source['complete'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'search_source_sha256':sha(root/'generic_chess/ai/alphabeta/search.py'),'input_sha256':sha(src),'declaration':'Changed premise: existing ordered-qsearch on seed2200 completes same q4D2 score while reducing runtime pushes25853->6106; not PVS/default change. Test ALL original four8x8roots2100..2103 as another fixed exposed transfer cohort, default versus existing ordered-qsearch only, PVSoff/Native attack+legality/TT+ordering/root_tacticaloff/q4hard8,D2/8192totalnodes/20sec,2rotated cold repeats16calls<=330sec. Decide transfer of lazy noisy-classification savings with common completed-depth score/legality preserved; keep all failures, no resource asymmetry/price tuning or default promotion.','cases':[]};write_record(out,r)
try:
 for old in source['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':old['seed'],'searches':[]};r['cases'].append(case)
  for repeat in (0,1):
   for ordered in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-started<330 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    observed=[]
    def capture_stats():
     value=SearchStatistics();observed.append(value);return value
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=ordered));t=time.perf_counter()
    with patch('generic_chess.ai.alphabeta.player.SearchStatistics',capture_stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=20,quiescence_max_depth=4,quiescence_hard_max_depth=8))
    wall=time.perf_counter()-t;validate_pv(s,d);case['searches'].append({'ordered_qsearch':ordered,'repeat':repeat,'wall_seconds':wall,'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','native_legality_calls')},'decision':record_value(d)});write_record(out,r)
    assert d.native_legality_fallbacks==0
  print(old['seed'],[(x['ordered_qsearch'],x['decision']['completed_depth'],x['decision']['score'],x['runtime_work']['runtime_pushes'],round(x['wall_seconds'],3)) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
