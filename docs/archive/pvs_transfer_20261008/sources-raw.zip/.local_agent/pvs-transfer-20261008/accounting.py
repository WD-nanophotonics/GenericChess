import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/(sys.argv[1]+'.json');assert not out.exists();src=p/'transfer.json';source=json.loads(src.read_bytes());assert source['complete'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'search_source_sha256':sha(root/'generic_chess/ai/alphabeta/search.py'),'input_sha256':sha(src),'declaration':'Observed q4 runtime generation calls lack cost. Two actual roots2200/2205,baseline/PVS Native,TT/order/root_tacticaloff,q4hard8,D2/4096totalnodes without wall cap,4calls<=100sec. Independent runtime.legal_actions wrapper counts attempts/time; capture stats object for runtime work instead of broadening decision API. Before/after telemetry repair must retain exact action/score/main+qnodes/depth/PV; no speed claim or new options.','cases':[]};write_record(out,r)
original=SearchPathRuntime.legal_actions
try:
 for seed in (202610082200,202610082205):
  old=next(x for x in source['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':seed,'searches':[]};r['cases'].append(case)
  for pvs in (False,True):
   assert time.perf_counter()-started<100 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   observed={'calls':0,'seconds':0};stats=[]
   def counted(self,*args,**kwargs):
    observed['calls']+=1;t=time.perf_counter()
    try:return original(self,*args,**kwargs)
    finally:observed['seconds']+=time.perf_counter()-t
   from generic_chess.ai.alphabeta.statistics import SearchStatistics
   def capture_stats():
    value=SearchStatistics();stats.append(value);return value
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_pvs=pvs));t=time.perf_counter()
   with patch.object(SearchPathRuntime,'legal_actions',counted),patch('generic_chess.ai.alphabeta.player.SearchStatistics',capture_stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   wall=time.perf_counter()-t;validate_pv(s,d);case['searches'].append({'pvs':pvs,'wall_seconds':wall,'actual_generation':observed,'runtime_work':{k:getattr(stats[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','runtime_peak_depth','native_legality_calls')},'decision':record_value(d)});write_record(out,r)
  print(seed,[(x['pvs'],x['actual_generation'],x['decision']['legal_generation_seconds'],x['decision']['nodes'],x['decision']['qnodes']) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
