import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'extension.json';assert not out.exists();src=p/'transfer.json';source=json.loads(src.read_bytes());assert source['complete'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'declaration':'Changed premise: fresh seed2205 baseline32768node depth3 capped while existing PVS completes. Separately declared fair65536nodes/40sec D3 for BOTH methods, two rotated cold repeats,<=4calls/170sec. Determines whether completed same-depth score agrees; keep originalcap unknown and no holdout restoration/default change. Also replay actual returned one-ply win at seed2203 and use existing default root_tactical at SAME32768nodes/20sec,2cold calls, no new optimization. Distinguish diagnostic root-scan-off cap from a solved production caller.','cases':[]};write_record(out,r)
try:
 for seed in (202610082205,202610082203):
  old=next(x for x in source['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':seed,'searches':[]};r['cases'].append(case)
  if seed==202610082203:
   old_d=old['searches'][0]['decision']
   # Decision dataclass records use semantic field names, not action_to_dict.
   from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
   from generic_chess.core.coordinates import Square
   data=old_d['action'];target=Square(**data['to_square'])
   a=SemanticBoardMove(data['pattern_id'],data['geometry_id'],data['actor_type_id'],Square(**data['from_square']),target,data.get('promotion_target_id')) if 'from_square' in data else SemanticDropMove(data['pattern_id'],data['geometry_id'],data['base_type_id'],target)
   child=apply_action(s.state,a,c);assert child.terminal_status.is_terminal and child.terminal_status.winner==s.state.position.side_to_move
   case['prior_action_terminal']=record_value(child.terminal_status)
  for repeat in (0,1):
   for pvs in ((False,True) if repeat==0 else (True,False)) if seed==202610082205 else (False,):
    assert time.perf_counter()-started<175 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    tactical=seed==202610082203;player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=tactical,use_pvs=pvs));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=32768 if tactical else 65536,max_time_seconds=20 if tactical else 40,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);case['searches'].append({'pvs':pvs,'root_tactical':tactical,'repeat':repeat,'wall_seconds':time.perf_counter()-t,'decision':record_value(d)});write_record(out,r)
    if tactical:assert d.termination_reason=='root_immediate_win' and d.score==999999999
  print(seed,[(x['pvs'],x['decision']['completed_depth'],x['decision']['nodes'],x['decision']['score'],x['decision']['termination_reason']) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
