import sys,json,time,hashlib,cProfile,pstats
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'qintervention.json';assert not out.exists();src=p/'transfer.json';source=json.loads(src.read_bytes());assert source['complete'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'search_source_sha256':sha(root/'generic_chess/ai/alphabeta/search.py'),'input_sha256':sha(src),'declaration':'Observed q4 work exceeds explicit generation/leaf costs; main-only successor counters are not total work. Profile first q-capped root2200 at fixedD2/4096nodes without wall timer (profiling cost is not speed comparison). Then existing use_ordered_qsearch alone on2200/2205, baseline/PVSoff,Native,TT/order,q4hard8,D2/4096totalnodes/20sec,two rotated cold repeats8calls<=240sec. Test whether lazy noisy classification avoids irrelevant quiet probes before cutoffs. Retain caps, completed common-depth scores and runtime pushes; no new option/cache/default or price tuning.','cases':[]};write_record(out,r)
def signature(d):return tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation'))
try:
 for seed in (202610082200,202610082205):
  old=next(x for x in source['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':seed,'searches':[]};r['cases'].append(case)
  def run(ordered,wall_limit):
   observed=[]
   def capture_stats():
    value=SearchStatistics();observed.append(value);return value
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=ordered));t=time.perf_counter()
   with patch('generic_chess.ai.alphabeta.player.SearchStatistics',capture_stats):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=wall_limit,quiescence_max_depth=4,quiescence_hard_max_depth=8))
   wall=time.perf_counter()-t;validate_pv(s,d);return {'ordered_qsearch':ordered,'wall_seconds':wall,'decision':record_value(d),'runtime_work':{k:getattr(observed[0],k) for k in ('runtime_pushes','runtime_pops','runtime_depth_balanced','native_legality_calls')}}
  if seed==202610082200:
   profile=cProfile.Profile();profile.enable();result=run(False,None);profile.disable();stats=pstats.Stats(profile);functions=[]
   for (filename,line,function),(cc,nc,tt,ct,callers) in stats.stats.items():functions.append({'file':Path(filename).name,'line':line,'function':function,'primitive_calls':cc,'calls':nc,'exclusive_seconds':tt,'nested_cumulative_seconds':ct})
   r['profile']={'decision':result,'functions_by_exclusive':sorted(functions,key=lambda x:x['exclusive_seconds'],reverse=True)[:20],'functions_by_nested':sorted(functions,key=lambda x:x['nested_cumulative_seconds'],reverse=True)[:20],'scope':'Nested times overlap, not additive; fixed nodes/profile overhead not a speed measurement.'};reference=json.loads((p/'accounting-after.json').read_bytes())['cases'][0]['searches'][0]['decision'];assert signature(result['decision'])==signature(reference)
  for repeat in (0,1):
   for ordered in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-started<240 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    result=run(ordered,20);result['repeat']=repeat;case['searches'].append(result);write_record(out,r)
  print(seed,[(x['ordered_qsearch'],x['decision']['completed_depth'],x['decision']['nodes'],x['decision']['qnodes'],x['runtime_work']['runtime_pushes'],round(x['wall_seconds'],3)) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
