import json, hashlib, zipfile, tempfile
from pathlib import Path
root=Path.cwd(); p=Path(__file__).parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
read=lambda n:json.loads((p/(n+'.json')).read_bytes())
summary=read('summary'); transfer=read('qordered-transfer')
assert summary['complete'] and transfer['complete']
summary['ordered_qsearch_transfer']=[]
signature=lambda d:tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation'))
for case in transfer['cases']:
 row={'seed':case['seed'],'methods':[]}
 for mode in (False,True):
  xs=[x for x in case['searches'] if x['ordered_qsearch']==mode]
  z=xs[0]['decision']
  row['methods'].append({'ordered':mode,'completed_depths':[x['decision']['completed_depth'] for x in xs],'scores':[x['decision']['score'] for x in xs],'nodes':[x['decision']['nodes'] for x in xs],'qnodes':[x['decision']['qnodes'] for x in xs],'runtime_pushes':[x['runtime_work']['runtime_pushes'] for x in xs],'seconds':[x['wall_seconds'] for x in xs],'termination':[x['decision']['termination_reason'] for x in xs],'cold_signature_equal':signature(xs[0]['decision'])==signature(xs[1]['decision'])})
  assert all(x['runtime_work']['runtime_depth_balanced'] for x in xs)
 a,b=row['methods']; depths=a['completed_depths']+b['completed_depths']
 row['retained_same_depth_score_equal']=len(set(a['scores']+b['scores']))==1 if len(set(depths))==1 else None
 if row['retained_same_depth_score_equal'] is not None:assert row['retained_same_depth_score_equal']
 summary['ordered_qsearch_transfer'].append(row)
summary['finalizer_sha256']=sha(Path(__file__))
summary['qordered_transfer_input_sha256']=sha(p/'qordered-transfer.json')
summary['limits'].append('Ordered-qsearch transfer is four previously exposed roots, not fresh independent generalization. Compare only common completed depths; capped partial counts can vary.')
dest=root/'docs/archive/pvs_transfer_20261008';dest.mkdir(parents=True,exist_ok=True);archive=dest/'sources-raw.zip';assert not archive.exists()
producers={'transfer':'run','extension':'extend','analysis':'analyze','qtransfer':'qtransfer','accounting-before':'accounting','accounting-after':'accounting','qintervention':'qintervention','qordered-transfer':'qordered_transfer','summary':'summary'}
for name,producer in producers.items():
 d=read(name);assert d['complete'];assert d['producer_sha256']==sha(p/(producer+'.py'))
for n,h in read('analysis')['inputs'].items():assert sha(p/(n+'.json'))==h
for n,h in read('summary')['inputs'].items():assert sha(p/(n+'.json'))==h
files=sorted(x for x in p.iterdir() if x.suffix in ('.py','.json'))
files += [root/'tests/rule_semantics_ir_fixtures.py',root/'tests/product/test_search_generation_accounting.py',root/'generic_chess/ai/alphabeta/search.py',root/'generic_chess/ai/alphabeta/statistics.py',root/'generic_chess/ai/limits.py',root/'.local_agent/generated8-20261008/transfer.json']
members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();z.writestr(name,f.read_bytes());members.append({'path':name,'bytes':f.stat().st_size,'sha256':sha(f)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for m in members:assert sha(Path(tmp)/m['path'])==m['sha256']
index={'base_commit':'ea934db19a9e39218e9a690f150a1d33286d31c7','archive_sha256':sha(archive),'extracted_rehashed':True,'members':members,'excluded':'User/private inputs, Slack/account records, credentials and active workflow state.'}
(dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
result={'complete':True,'scope':'Fixed synthetic development comparisons; existing options unchanged. Fresh PVS transfer, q4 cost qualification, telemetry repair and existing lazy-qsearch intervention. Not material-price or playing-strength validation.','archive':'../../archive/pvs_transfer_20261008/index.json','archive_sha256':index['archive_sha256'],'analysis':summary}
(root/'docs/research/data/pvs_transfer_20261008.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({'members':len(members),'bytes':archive.stat().st_size,'ordered_transfer':summary['ordered_qsearch_transfer']},indent=2))
