import sys,json,time,hashlib
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'qtransfer.json';assert not out.exists();src=p/'transfer.json';source=json.loads(src.read_bytes());assert source['complete'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'declaration':'Changed premise: all prior paired PVS generated-rule observations fixedq0. Examine existing q4/hard8 contract on first fresh PVS regression2200 and first extra-completion2205, not a new cohort or strength claim. BOTH baseline/PVS get identicalD3/32768totalnodes/20sec, Native legality/attack,TT/order,root tacticaloff remains fixed;2rotated cold repeats,8calls<=170sec. Determines whether cost/completion conclusions survive quiescent leaf work. Keep all caps/partial/PV/no-fallback counters; no default, price, resource-asymmetric or qsearch policy change.','cases':[]};write_record(out,r)
try:
 for seed in (202610082200,202610082205):
  old=next(x for x in source['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for step in old['route']:s.submit(action_from_dict(step['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'seed':seed,'searches':[]};r['cases'].append(case)
  for repeat in (0,1):
   for pvs in ((False,True) if repeat==0 else (True,False)):
    assert time.perf_counter()-started<170 and not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_pvs=pvs));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=32768,max_time_seconds=20,quiescence_max_depth=4,quiescence_hard_max_depth=8));validate_pv(s,d);case['searches'].append({'pvs':pvs,'repeat':repeat,'wall_seconds':time.perf_counter()-t,'decision':record_value(d)});write_record(out,r)
    assert d.native_legality_fallbacks==0
  print(seed,[(x['pvs'],x['decision']['completed_depth'],x['decision']['nodes'],x['decision']['qnodes'],x['decision']['score'],x['decision']['termination_reason']) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
