import json,hashlib,statistics
from pathlib import Path
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();names=('analysis','qtransfer','accounting-before','accounting-after','qintervention');data={n:json.loads((p/(n+'.json')).read_bytes()) for n in names};assert all(x['complete'] for x in data.values())
r={'complete':True,'producer_sha256':sha(Path(__file__)),'inputs':{n:sha(p/(n+'.json')) for n in names},'q0':data['analysis'],'q4':[],'accounting':[],'ordered_qsearch':[],'profile':data['qintervention']['profile']}
signature=lambda d:tuple(json.dumps(d[k],sort_keys=True) for k in ('action','score','nodes','qnodes','completed_depth','principal_variation'))
for case in data['qtransfer']['cases']:
 row={'seed':case['seed'],'methods':[]};r['q4'].append(row)
 for mode in (False,True):
  xs=[x for x in case['searches'] if x['pvs']==mode];row['methods'].append({'pvs':mode,'depths':[x['decision']['completed_depth'] for x in xs],'scores':[x['decision']['score'] for x in xs],'main_nodes':[x['decision']['nodes'] for x in xs],'qnodes':[x['decision']['qnodes'] for x in xs],'seconds':[x['wall_seconds'] for x in xs],'termination':[x['decision']['termination_reason'] for x in xs]})
for before,after in zip(data['accounting-before']['cases'],data['accounting-after']['cases']):
 for a,b in zip(before['searches'],after['searches']):
  assert signature(a['decision'])==signature(b['decision']);assert a['runtime_work']==b['runtime_work'];assert a['actual_generation']['calls']==b['actual_generation']['calls']
  r['accounting'].append({'seed':before['seed'],'pvs':a['pvs'],'decision_and_runtime_work_exact':True,'main_nodes':b['decision']['nodes'],'qnodes':b['decision']['qnodes'],'before_reported_seconds':a['decision']['legal_generation_seconds'],'after_reported_seconds':b['decision']['legal_generation_seconds'],'actual_runtime_calls_including_cached_validation':b['actual_generation']['calls'],'actual_runtime_seconds_including_cached_validation':b['actual_generation']['seconds'],'reported_explicit_search_generation_requests':b['decision']['legal_generation_calls'],'runtime_work':b['runtime_work']})
for case in data['qintervention']['cases']:
 row={'seed':case['seed'],'methods':[]};r['ordered_qsearch'].append(row)
 for mode in (False,True):
  xs=[x for x in case['searches'] if x['ordered_qsearch']==mode]
  stable=signature(xs[0]['decision'])==signature(xs[1]['decision']);z=xs[0]['decision'];row['methods'].append({'ordered':mode,'cold_signature_repeat_equal':stable,'completed_depth':z['completed_depth'],'score':z['score'],'nodes':z['nodes'],'qnodes':z['qnodes'],'runtime_pushes':[x['runtime_work']['runtime_pushes'] for x in xs],'wall_seconds':[x['wall_seconds'] for x in xs],'termination':[x['decision']['termination_reason'] for x in xs]})
 a,b=row['methods'];row['completed_same_depth_score_equal']=a['score']==b['score'] if a['completed_depth']==b['completed_depth'] else None
 if row['completed_same_depth_score_equal'] is not None:assert row['completed_same_depth_score_equal']
r['limits']=['q4 uses the same heuristic/explicit qdepth4hard8 policy, not exact full-game WDL. q0 cost conclusions do not transfer automatically.','Time-capped unfinished iterations have variable partial node counts; only retained completed-depth scores are interpreted.','Product generation timing now counts explicit search root/main/q/TT-PV requests, not all cached runtime validation calls. Main-only successor counters remain explicitly qualified.','Profile is instrumented and nested times overlap, not a speed comparator.','Accounting repair changes telemetry only; four actual fixed-node replay signatures and runtime work agree.','Ordered-qsearch experiment changes only an existing opt-in ordering/classification option, not price/default/policy. Costs and failed caps all retained.']
(p/'summary.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps({'accounting':r['accounting'],'ordered':r['ordered_qsearch']},indent=2))
