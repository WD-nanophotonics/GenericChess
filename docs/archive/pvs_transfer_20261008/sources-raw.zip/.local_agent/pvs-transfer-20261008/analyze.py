import json,hashlib,statistics
from pathlib import Path
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();d=json.loads((p/'transfer.json').read_bytes());extension=json.loads((p/'extension.json').read_bytes());assert d['complete'] and extension['complete']
sig=lambda x:tuple(json.dumps(x[k],sort_keys=True) for k in ('action','score','nodes','completed_depth','principal_variation'))
r={'complete':True,'producer_sha256':sha(Path(__file__)),'inputs':{'transfer':sha(p/'transfer.json'),'extension':sha(p/'extension.json')},'seconds':d['seconds'],'rows':[],'extensions':[]}
for case in d['cases']:
 row={'seed':case['seed'],'terminal':case.get('terminal'),'legal_actions':case.get('legal_actions'),'reference':case.get('reference'),'methods':[]};r['rows'].append(row)
 if not case['searches']:continue
 modes={mode:[x for x in case['searches'] if x['pvs']==mode] for mode in (False,True)}
 for mode,xs in modes.items():
  assert sig(xs[0]['decision'])==sig(xs[1]['decision']);z=xs[0]['decision']
  row['methods'].append({'pvs':mode,'completed_depth':z['completed_depth'],'nodes':z['nodes'],'score':z['score'],'termination':z['termination_reason'],'evaluation_calls':z['evaluation_calls'],'pvs_researches':z['pvs_researches'],'wall_seconds':[x['wall_seconds'] for x in xs]})
 a,b=(modes[mode][0]['decision'] for mode in (False,True));common=a['completed_depth']==b['completed_depth'];row['common_depth_score_equal']=a['score']==b['score'] if common else None
 if common:assert a['score']==b['score']
 row['same_action_at_common_depth']=a['action']==b['action'] if common else None
 row['pvs_node_ratio_if_both_complete']=b['nodes']/a['nodes'] if a['completed_depth']==b['completed_depth']==3 else None
 row['pvs_wall_ratio_if_both_complete']=statistics.mean(x['wall_seconds'] for x in modes[True])/statistics.mean(x['wall_seconds'] for x in modes[False]) if a['completed_depth']==b['completed_depth']==3 else None
for case in extension['cases']:
 row={'seed':case['seed'],'prior_action_terminal':case.get('prior_action_terminal'),'methods':[]};r['extensions'].append(row)
 for mode in sorted({x['pvs'] for x in case['searches']}):
  xs=[x for x in case['searches'] if x['pvs']==mode];assert sig(xs[0]['decision'])==sig(xs[1]['decision']);z=xs[0]['decision'];row['methods'].append({'pvs':mode,'root_tactical':xs[0]['root_tactical'],'nodes':z['nodes'],'completed_depth':z['completed_depth'],'score':z['score'],'termination':z['termination_reason'],'wall_seconds':[x['wall_seconds'] for x in xs]})
 if len(row['methods'])==2:assert row['methods'][0]['score']==row['methods'][1]['score'] and all(x['completed_depth']==3 for x in row['methods'])
r['limits']=['All eight predeclared fresh synthetic8x8rules retained, not independent real playing-strength games.','Root tactical scan deliberately off in PVS isolation, q0, Native attack and legality, TT/order. Existing options/defaults unchanged.','Five baseline and seven PVS depth3 completions at32768nodes/20sec; missing scores remain unknown.','PVS node/wall regressions on easy roots prohibit a universal speedup claim.','Seed2203 immediate win is independently replayed; existing default root scan solves it, no cache/flag/product patch added.','Separate fair65536-node40sec extension only seed2205; seed2207 baseline requested-depth score still unknown at originalcap.','Core depth2 references that fail their original20k-leaf10sec checkpoint remain unknown.']
(p/'analysis.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in r.items() if k not in ('rows','limits')},indent=2))
