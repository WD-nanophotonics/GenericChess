import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/pvs_transfer_20261008'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
trace=json.loads((p/'hard-trace.json').read_bytes());assert trace['complete'] and trace['producer_sha256']==sha(p/'hard_trace.py')
files=[p/'hard-trace.json',p/'hard_trace.py',Path(__file__),root/'generic_chess/ai/alphabeta/statistics.py',root/'tests/product/test_lazy_successors.py']
archive=dest/'hard-trace-supplement.zip';assert not archive.exists();members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  name=f.relative_to(root).as_posix();z.writestr(name,f.read_bytes());members.append({'path':name,'bytes':f.stat().st_size,'sha256':sha(f)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for m in members:assert sha(Path(tmp)/m['path'])==m['sha256']
index={'base_archive':'index.json','archive_sha256':sha(archive),'members':members,'extracted_rehashed':True,'scope':'Actual hard-check path; final statistics comment and root-accounting assertion. No further production behavior changes.'}
(dest/'hard-trace-index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
target=root/'docs/research/data/pvs_transfer_20261008.json';data=json.loads(target.read_bytes());data['hard_trace']={'seed':trace['seed'],'termination':trace['decision']['termination_reason'],'retained_depth':trace['decision']['completed_depth'],'score':trace['decision']['score'],'path_deepest_first':[{'ply':f['ply'],'qdepth':f['qdepth'],'in_check':f['in_check'],'terminal':f['terminal']} for f in trace['frames_deepest_first']],'repeated_position_pairs':trace['repeated_position_pairs'],'scope':'Exception-unwind diagnostic, not timing comparison. Position equality alone is not complete repetition semantics. Actual depth8 in-check ongoing state; no limit/default change.','supplement_index':'../../archive/pvs_transfer_20261008/hard-trace-index.json','archive_sha256':index['archive_sha256']}
target.write_bytes((json.dumps(data,indent=2)+'\n').encode());print({'supplement_members':len(members),'bytes':archive.stat().st_size})
