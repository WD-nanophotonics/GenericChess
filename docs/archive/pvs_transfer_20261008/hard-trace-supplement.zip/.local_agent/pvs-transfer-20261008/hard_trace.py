import sys,json,time,hashlib
from pathlib import Path
from unittest.mock import patch
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.alphabeta import search
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'hard-trace.json';assert not out.exists()
src=root/'.local_agent/generated8-20261008/transfer.json';old=json.loads(src.read_bytes())['cases'][0]
c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
for step in old['route']:s.submit(action_from_dict(step['action']))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0)
ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native')
original=search._quiescence_runtime;frames=[];positions=[]
def traced(alpha,beta,ply,qdepth,ctx):
 try:return original(alpha,beta,ply,qdepth,ctx)
 except search.SearchAborted as exc:
  if str(exc)=='qsearch_check_hard_limit':
   position=ctx.runtime.position;positions.append(position)
   frames.append({'ply':ply,'qdepth':qdepth,'position':record_value(position),'in_check':semantic_engine_for(c).in_check(position,position.side_to_move),'terminal':record_value(ctx.runtime.terminal_status),'history_tail':[{'actor':h.actor,'action_signature':h.action_signature,'gave_check':h.gave_check} for h in ctx.runtime.history[-11:]]})
  raise
player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=True,tuning=SearchTuning(use_root_tactical=False,use_ordered_qsearch=True))
t=time.perf_counter()
with patch.object(search,'_quiescence_runtime',traced):d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=20,quiescence_max_depth=4,quiescence_hard_max_depth=8))
validate_pv(s,d)
assert d.termination_reason=='qsearch_check_hard_limit' and frames
r={'complete':True,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'declaration':'One diagnostic replay of first ordered-qsearch hard-depth failure2100 under unchanged conditions. Capture exception-unwind qpath, public position/check/terminal and action/check history. Not a timing comparator or budget extension. Does the hard stop describe an actual nonterminal check path or an apparent loop/executor inconsistency?','seed':old['seed'],'decision':record_value(d),'seconds':time.perf_counter()-t,'frames_deepest_first':frames,'repeated_position_pairs':[(i,j) for i in range(len(positions)) for j in range(i) if positions[i]==positions[j]],'limits':'Position equality alone is not full repetition history. No extra horizon or altered hard-limit/default.'}
write_record(out,r)
print(json.dumps({'depth':d.completed_depth,'score':d.score,'termination':d.termination_reason,'frames':[(f['ply'],f['qdepth'],f['in_check'],f['terminal']) for f in frames],'repeated':r['repeated_position_pairs']}))
