"""Post-repair Core cost ceiling and actual externally requested cancellation.
Ordinary Chess middle/high-branch Shogi drop. Two separate1024node/q2 profiles,
mutually exclusive direct-time categories (not sums of inclusive spans). The
direct geometry fraction bounds only those measured table/query bodies under
instrumentation, not whole attack elimination or guaranteed deployment speed.
Cancellation uses the real product token; a lightweight timer only sets the
flag, never searches/writes/project work. Single search writer. Before/after,
two reversed repeats, .03/.1/.3sec requested delay (24calls), q2/coldTT/order.
Measure actual request timestamp, return latency, maximum observed poll interval
and node balance. Intended timer delay is not assumed real-time scheduling.
Perf-counter instrumentation adds overhead; report scope, no responsiveness SLA.
Projected<1min. Run serially after atlas assay, no different polling frequency.
"""
from pathlib import Path
import sys,json,hashlib,cProfile,pstats,threading
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import generic_chess.ai.alphabeta.search as search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from scripts.search_backend_comparison import CASES,CoreBoard,Material
from scripts.research_record import record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
folder=Path(__file__).parent;namespace=dict(search.__dict__)
exec((folder/'checkpoint_before.py').read_text(encoding='utf-8'),namespace)
before=namespace['checkpoint'];after=search._Context.checkpoint
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),profiles=[],cancellation=[],complete=False)
out=folder/'cost-cancel.json'
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
class ObservedToken(CancellationToken):
 def __init__(self):super().__init__();self.requested=None;self.last_poll=None;self.max_gap=0;self.polls=0
 def cancel(self):self.requested=perf_counter();super().cancel()
 def is_cancelled(self):
  t=perf_counter()
  if self.last_poll is not None:self.max_gap=max(self.max_gap,t-self.last_poll)
  self.last_poll=t;self.polls+=1
  return super().is_cancelled()
def run(core,token=None,nodes=1024):
 stats=SearchStatistics();material=Material(core.game)
 action,score,pv,reason=search.run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=12,max_nodes=nodes,max_time_seconds=60,quiescence_max_depth=2,quiescence_hard_max_depth=12),token,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
 assert core.restored()
 return dict(move=core.label(action),score=score,pv=[core.label(a) for a in pv],reason=reason,statistics=asdict(stats))
def category(row):
 name=row['name'];file=row['file']
 if name in ('check','checkpoint','_checkpoint','<built-in method time.monotonic>'):return 'budget_callback_clock'
 if name.startswith('geometry_'):return 'geometry_query_body'
 if name in ('is_square_attacked','in_check','_sources_by_owner_type'):return 'attack_dispatch_body'
 if 'search_runtime.py' in file or name.startswith('_semantic_component'):return 'state_history_body'
 if name in ('_guards_hold','_path_holds','_make_binding','_resolve_square_ref'):return 'shared_semantic_predicate_body'
 return 'other'
start=perf_counter()
try:
 for case in (CASES[0],CASES[7]):
  search._Context.checkpoint=after
  c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
  core=CoreBoard(case,c);p=cProfile.Profile();r=p.runcall(run,core);s=pstats.Stats(p)
  calls=[dict(file=k[0],line=k[1],name=k[2],calls=v[1],direct_seconds=v[2],inclusive_seconds=v[3]) for k,v in s.stats.items()]
  groups={}
  for row in calls:groups[category(row)]=groups.get(category(row),0)+row['direct_seconds']
  assert abs(sum(groups.values())-s.total_tt)<1e-5
  f=groups.get('geometry_query_body',0)/s.total_tt
  report['profiles'].append(dict(case=case['id'],result=record_value(r),profile_total=s.total_tt,calls=calls,direct_groups=groups,geometry_direct_fraction=f,ideal_geometry_body_removal_profile_ceiling=1/(1-f)));save()
  for delay in (.03,.1,.3):
   for repeat,order in enumerate((('before','after'),('after','before'))):
    for mode in order:
     for flag in ('rollout','advisor','slack'):
      flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
     search._Context.checkpoint=before if mode=='before' else after
     core=CoreBoard(case,c);token=ObservedToken();timer=threading.Timer(delay,token.cancel);timer.daemon=True
     t=perf_counter();timer.start()
     try:r=run(core,token,1000000);end=perf_counter()
     finally:timer.cancel();timer.join()
     assert r['reason']=='cancelled' and token.requested is not None
     report['cancellation'].append(dict(case=case['id'],backend=mode,repeat=repeat,intended_delay=delay,actual_request_delay=token.requested-t,request_to_return_seconds=end-token.requested,max_observed_poll_gap_seconds=token.max_gap,polls=token.polls,result=record_value(r)));save()
 report['complete']=True
finally:
 search._Context.checkpoint=after
 report['wall_seconds']=perf_counter()-start;save()
print([(r['case'],r['geometry_direct_fraction'],r['ideal_geometry_body_removal_profile_ceiling']) for r in report['profiles']]);print('cancelled',len(report['cancellation']))
