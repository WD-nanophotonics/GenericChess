"""Align Native minimal iterative D1-D3 with product cumulative D1-D3 work.
Six short calls (3same roots x2 repeats), unchanged1million/30sec/q0 material.
Previous one-shotD3 rows retained; this separates iteration overhead from the
remaining scheduling/tie/node-definition differences, not a PV-isolated cause.
"""
from pathlib import Path
import json,hashlib
folder=Path(__file__).parent;f=folder/'native_fixed_work.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8').split('\nreport=dict')[0],ns)
from scripts.bounded_root_scheduler import iterative_root_search
rows=[]
for name,factory,values in ns['ns']['factories'][3:]:
 for repeat in range(2):
  core=factory();board=ns['NativeBoard'](core,values)
  r=iterative_root_search(board,seconds=30,node_limit=1000000,max_depth=3)
  assert r['completed_depth']==3 and board.restored()
  rows.append(ns['record_value'](dict(case=name,repeat=repeat,result=r)))
out=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows,complete=True)
(folder/'native-iterative-work.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print([(r['case'],r['result']['work']['nodes'],round(r['result']['caller_seconds'],3)) for r in rows])
