"""Purpose archive of Agent-authored research only; no transport or binaries."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[2];folder=Path(__file__).parent
paths=[p for p in folder.iterdir() if p.is_file() and p.suffix in ('.py','.json','.md')]
extra=['.local_agent/native-terminal-20261010/syntax_ablation.py','.local_agent/native-terminal-20261010/bridge_assay.py','.local_agent/generated6-20261008/coverage.json','scripts/bounded_root_scheduler.py','scripts/root_bound_diagnostic.py','scripts/native_backend_bridge.py','scripts/search_backend_comparison.py','scripts/research_record.py','generic_chess/ai/alphabeta/search.py','generic_chess/ai/alphabeta/statistics.py','generic_chess/ai/alphabeta/native_legality.py','generic_chess/core/semantic_executor.py','generic_chess/core/search_runtime.py','generic_chess/native/semantic_engine.py','generic_chess/_native/native_module.c','tests/product/test_search_semantic_checkpoint.py','tests/development/test_bounded_root_scheduler.py']
paths += [ROOT/p for p in extra]
assert all(p.is_file() and '.local_agent/slack' not in p.as_posix() and p.name!='dot-question.txt' for p in paths)
target=ROOT/'docs/archive/terminal_frontier_20261010/evidence.zip';target.parent.mkdir(parents=True,exist_ok=True)
members={}
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p in sorted(set(paths)):
  data=p.read_bytes();name=p.relative_to(ROOT).as_posix()
  members[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest());archive.writestr(name,data)
with zipfile.ZipFile(target) as archive:
 assert len(archive.namelist())==len(members)
 for name,meta in members.items():assert hashlib.sha256(archive.read(name)).hexdigest()==meta['sha256']
index=dict(schema=1,base_commit='2b5faa9235d8fa00911de5e78ab51a05b7e5e6ac',scope='Agent-authored exposed development; supported installed Native v4 and Core callback repair. No raw Slack/account/outgoing content, user-private input or binary.',archive=target.relative_to(ROOT).as_posix(),archive_bytes=target.stat().st_size,archive_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=members,summary=json.loads((folder/'final-summary.json').read_bytes()),failures='Entire overlapped timing sets ineligible; exact source failures retained. Final candidate C remains blocked/restored, not retried.',validation='101 focused checks passed before archival; tested publisher reruns relevant targets.')
(ROOT/'docs/research/data/terminal_frontier_20261010.json').write_bytes((json.dumps(index,indent=2)+'\n').encode('utf-8'))
print(len(members),target.stat().st_size,index['archive_sha256'])
