"""Terminal-prefix changed-premise comparison on Core DFS path.
Earlier qfrontier checks do not certify this separate SearchPathRuntime path.
Here terminal discards first-binding generator; later legal_actions starts again.
Prototype reuses only that exact frame prefix, not history or terminal results.
EP/generated2000/2001; matched4096entry+30s and1sec+100k/D12; two reversed orders,
24calls. No Native kernel, cache enlargement, price fitting or oracle growth.
Check every D2 child state/history/terminal/evaluation/action list first against
Core baseline and installed Native, including real pushes. Estimated<2minutes.
Fixed work/action/PV mismatch rejects, all timed adversity retained.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from prefix_probe import PrefixBoard
from scripts.bounded_root_scheduler import iterative_root_search
from scripts.native_backend_bridge import NativeBoard,audit_native_tree
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.research_record import record_value
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),probe_sha256=hashlib.sha256(Path(__file__).with_name('prefix_probe.py').read_bytes()).hexdigest(),audits=[],rows=[],complete=False)
out=Path(__file__).with_name('prefix-comparison.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
start=perf_counter()
try:
 for name,factory,values in ns['factories'][3:]:
  core=factory();prefix=PrefixBoard(core);native=NativeBoard(factory(),values)
  with prefix.active():states=audit_native_tree(prefix,native,2)
  report['audits'].append(dict(case=name,states=states,prefix_started=prefix.started,prefix_resumed=prefix.resumed));save()
  for kind in ('fixed','timed'):
   for repeat,order in enumerate((('Core','Prefix'),('Prefix','Core'))):
    for backend in order:
     for flag in ('rollout','advisor','slack'):
      f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
     core=factory();board=core if backend=='Core' else PrefixBoard(core)
     if backend=='Core':r=iterative_root_search(board,seconds=30 if kind=='fixed' else 1,node_limit=4096 if kind=='fixed' else 100000)
     else:
      with board.active():r=iterative_root_search(board,seconds=30 if kind=='fixed' else 1,node_limit=4096 if kind=='fixed' else 100000)
      r['prefix_stats']=dict(started=board.started,resumed=board.resumed,hits=board.prefix_hits,discarded=board.discarded,live_entries=len(board.entries))
     r.update(case=name,backend=backend,kind=kind,repeat=repeat);report['rows'].append(record_value(r));save()
     print(name,kind,repeat,backend,r['completed_depth'],round(r['caller_seconds'],3),r['move'],flush=True)
  rows=[x for x in report['rows'] if x['case']==name and x['kind']=='fixed']
  signature=lambda x:(x['move'],x['score'],x['pv_labels'],x['completed_depth'],x['work'],[(i['move'],i['score'],i['work'],i['candidates']) for i in x['iterations']])
  assert all(signature(x)==signature(rows[0]) for x in rows)
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
