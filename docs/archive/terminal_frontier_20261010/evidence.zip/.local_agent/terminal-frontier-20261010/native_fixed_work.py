"""Native fixed-D3 work distinction, 3 existing roots x2 algorithms x2reversed
passes=12 calls. Same installed terminal/transition backend and material/q0,
TT0/full-rootOFF versus lexical verified minimal. 1million/30sec safety fuse.
No phase-isolated causal claim: node definitions, tie/PV scheduling differ.
Expected<30sec. Tests whether extra recorded entries remain at same horizon;
does not establish that all entries are PV replay or that fewer means better.
"""
from pathlib import Path
import sys,json,hashlib
from dataclasses import asdict
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from scripts.root_bound_diagnostic import root_search
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.research_record import record_value
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
for name,factory,values in ns['factories'][3:]:
 for repeat,order in enumerate((('minimal','product'),('product','minimal'))):
  for mode in order:
   for flag in ('rollout','advisor','slack'):
    flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
   core=factory();board=NativeBoard(core,values)
   if mode=='minimal':
    t=perf_counter();r=root_search(board,3,mode='verified',node_limit=1000000,seconds=30);wall=perf_counter()-t
    assert r['completed_depth']==3
    r['action']=None;r['pv']=[]
   else:
    engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=0)
    session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
    t=perf_counter();result=engine.search(session,SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=30,quiescence_max_depth=0),root_window_pruning=False);wall=perf_counter()-t
    assert result.completed_depth==3 and session.state==core.initial
    r=asdict(result)
   assert board.restored()
   report['rows'].append(record_value(dict(case=name,repeat=repeat,backend=mode,result=r,caller_seconds=wall)))
report['complete']=True
Path(__file__).with_name('native-fixed-work.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print([(r['case'],r['backend'],r['result'].get('nodes',r['result'].get('work',{}).get('nodes')),round(r['caller_seconds'],3)) for r in report['rows']])
