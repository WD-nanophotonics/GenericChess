# Scoped conclusions and advisor adoption

Fresh technical request received a complete advisor reply. Adopt its demand to
separate removable direct costs, actual repairs and repeated scheduling; retain
full-Native PV work as a hypothesis. The advisor did not independently execute
these new experiments. No workflow, budget, duration or direction rule changes.
Raw transport and outgoing request text remain local and outside this archive.

Installed Core checkpoint dispatch fusion preserves every real semantic poll,
live deadline and node/cancel/time precedence. Forty q2 fixed-work calls retain
exact decisions/PVs/non-time counters, with local mean reductions4.49–12.60%.
The96 common-time calls are48 pairs, not independent strength samples; EPq0
at4seconds completesD4 instead ofD3 in both reversed passes. Other differences
are retained in final-summary; q0/q2 evaluation processes remain distinct.
The simpler inline method is selected over the faster closure prototype to avoid
new per-context architecture. Deterministic and actual cancellation controls
pass;24 externally requested cancels have post-repair maximum observed request
to return1.108ms. Poll gaps/timer scheduling/instrumentation are descriptive,
not a responsiveness SLA. No safety/poll frequency weakening or new worker.

Two disjoint post-repair profiles place geometry query bodies at6.375%/2.213%
of instrumented total. Removing those bodies perfectly would only bound that
scoped profile at1.068x/1.023x, not all attack logic or deployment throughput.
Compile-owned compatibility atlas preserves3974 full states and9928 all-square
pseudoattack queries, but reduces fixed cost only1.27–1.97%; no measured timed
completion improvement. Defer metadata integration. Terminal-prefix reuse is
5–11% slower; reject. Authoritative terminal/history logic must stay intact.

Native training trace is not a cheap phase profiler:8 coldD3 calls preserve
score/action/PV/depth/nodes/cutoffs but trace costs3.29–4.09x caller time. It
retains4096 rows versus25824/41620 raw events and has no PV-research phase tag.
The188719802-byte JSON contains repeated generated trace features; its recording
cost is itself evidence. Do not equate rows/events with unique states or derive
PV scheduling causality. Keep trace OFF for comparisons. A supported future
phase measurement must isolate counters without this feature materialization;
the blocked final kernel is not retried or claimed deployed.

The120 serial algorithm curves and24 factor calls/12 separate profiles keep
initialization/caller/kernel/validation and unlike node definitions explicit.
Thin diagnostic polls at visits, whereas product polls inside semantics; its
time advantage does not isolate algorithm quality or equivalent cancellation.
The32 Shogi resource curves expose100k censorship;500k consumes the1second but
adds no completion/choice on these two roots. Preserve original52 controls.
Minimal/product ordering, Native packed ties, mate scales and cache policy differ.
Mature engines remain references; no Elo, label fitting, new teacher or default
algorithm change. Existing Native full-window/PV source is explanatory evidence,
not a measured isolated cause of every depth difference.

First algorithm/factor runs accidentally overlapped. Entire first timing sets
are ineligible, retained with exact sources. Both were repeated serially under
the same predeclared settings; no favorable subset chosen. Earlier packed-action
and prefix-source failures also remain. Current source pins include exact old
checkpoint implementation and the first executed closure prototype. UI unchanged.

Twelve fixed-D3 full/minimal Native calls plus six minimal iterative calls retain
the cumulative-work distinction: iterative minimal1944/2027/2112 entries versus
full-product25824/41620/68505. Both finishD3; same terminal/transition backend,
material/q0, no TT. Full product caller about0.90/1.03/1.50sec versus minimal
iterative0.14/0.12/0.18sec. Entries are different algorithm counters, not equal
primitive work. No count ratio is a phase cost or a universal speedup. The
one-shot diagnostic uses a different canonical tie key from the iterative public
label key, so its2475/1882/2219 entries do not isolate iteration overhead.
The iterative script's stated aim of separating that overhead is only partly
met; ordering/tie/scheduling remain confounded. Mate scales differ1e9/1e8;
normalize mate distance, never compare raw integers as a finite-score defect.
This is evidence to investigate scheduling under the same backend, not a mandate
to replace supported search or disable PV correctness. No new binary follows.
