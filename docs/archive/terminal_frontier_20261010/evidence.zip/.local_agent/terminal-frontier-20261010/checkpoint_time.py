"""Installed callback repair common-time consequence, no oracle extension.
Chess middle/EP, Shogi tactic/drop, generated2000/2001. Each before/after Core
product q0 andq2,1/4seconds,1million nodes,maxD12,qhard12, two reversed passes:
96calls. Complete decisions/first latencies/actual work/exit causes; q0/q2 distinct
evaluation processes, not equal-leaf price gains. Frozen oldD4 lookup optional,
unknowns explicit. No success-standard change, default qsearch change or new
teacher. Projected about4minutes and root overhead; interruptible each call.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import generic_chess.ai.alphabeta.search as search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.search_backend_comparison import CASES,CoreBoard,Material,VALUES
from scripts.research_record import record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
factories=[]
for case in [CASES[i] for i in (0,3,5,7)]:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
 factories.append((case['id'],lambda case=case,c=c:CoreBoard(case,c),VALUES[case['game']]))
factories+=ns['factories'][4:]
folder=Path(__file__).parent;namespace=dict(search.__dict__)
exec((folder/'checkpoint_before.py').read_text(encoding='utf-8'),namespace)
before=namespace['checkpoint'];after=search._Context.checkpoint
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),before_sha256=hashlib.sha256((folder/'checkpoint_before.py').read_bytes()).hexdigest(),after_source_sha256=hashlib.sha256(Path(search.__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=folder/'checkpoint-time.json'
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
start=perf_counter()
try:
 for name,factory,values in factories:
  for q in (0,2):
   for seconds in (1,4):
    for repeat,order in enumerate((('before','after'),('after','before'))):
     for mode in order:
      for flag in ('rollout','advisor','slack'):
       flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
      search._Context.checkpoint=before if mode=='before' else after
      core=factory();stats=SearchStatistics();material=Material('chess');material.values=values;t=perf_counter()
      action,score,pv,reason=search.run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=q,quiescence_hard_max_depth=12),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
      wall=perf_counter()-t;assert core.restored()
      row=dict(case=name,q=q,seconds=seconds,backend=mode,repeat=repeat,move=core.label(action),score=score,pv=[core.label(a) for a in pv],reason=reason,statistics=asdict(stats),wall_seconds=wall)
      report['rows'].append(record_value(row));save();print(name,q,seconds,repeat,mode,stats.completed_depth,round(wall,3),flush=True)
 report['complete']=True
finally:
 search._Context.checkpoint=after
 report['wall_seconds']=perf_counter()-start;save()
