"""Narrow cancellation recovery audit of the rejected prefix prototype.
Three existing roots. Open terminal prefix under callback A; resume under
callback B which raises on third checkpoint. Partial frontier must not become
runtime cache; restore using callback C and compare full actions/terminals and
child state restoration to baseline. No timing benefit or full-domain claim.
"""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from prefix_probe import PrefixBoard
import generic_chess.core.search_runtime as runtime_module
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
class Interrupted(Exception):pass
rows=[]
for name,factory,values in ns['factories'][3:]:
 baseline=factory();board=PrefixBoard(factory());counts=dict(A=0,B=0,C=0)
 def a():counts['A']+=1
 def b():
  counts['B']+=1
  if counts['B']==3:raise Interrupted()
 def c():counts['C']+=1
 with board.active():
  board.runtime.terminal_status=runtime_module.terminal_from_search_runtime(board.runtime,checkpoint=a)
  opened=counts['A'];board.runtime._legal_cache=None
  interrupted=False
  try:board.runtime.legal_actions(checkpoint=b)
  except Interrupted:interrupted=True
  assert interrupted and counts['A']==opened and board.runtime._legal_cache is None
  board.runtime.terminal_status=runtime_module.terminal_from_search_runtime(board.runtime,checkpoint=c)
  recovered=board.runtime.legal_actions(checkpoint=c)
  assert set(recovered)==set(baseline.runtime.legal_actions())
  move=board.actions()[0][1];board.push(move);board.pop()
  assert board.restored()
 rows.append(dict(case=name,callbacks=counts,interrupted=interrupted,discarded=board.discarded,root_restored=True,actions=len(recovered)))
Path(__file__).with_name('prefix-recovery.json').write_text(json.dumps(dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows),indent=2)+'\n',encoding='utf-8')
print(rows)
