"""Interactive fixed-work and interruption comparison of two dispatch designs.
The first assay's fixed-node mode deliberately has no deadline; it cannot test
interactive dispatch savings. Here baseline/inline/closure all receive4096 nodes
and60seconds, on EP/generated2000/2001, two reversed passes (18calls). All fixed
score/action/PV/work/counters must match. Inline avoids per-context closure/property;
prefer it if benefit is comparable, not an automatic tune of search or prices.
Also compare actual cancel-after5/500/50000 polls in EP search: same callback
count, root result/work and unwind. No throttling or more search budget.
Projected<2min; run only after previous assay completes, no overlapping timing.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from contextlib import nullcontext
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from checkpoint_callback import active,FusedContext,InlineContext
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
from scripts.search_backend_comparison import Material
import generic_chess.ai.alphabeta.search as search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),callback_sha256=hashlib.sha256(Path(__file__).with_name('checkpoint_callback.py').read_bytes()).hexdigest(),rows=[],cancellation=[],complete=False)
out=Path(__file__).with_name('checkpoint-variants.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
class Cancel:
 def __init__(self,threshold):self.threshold=threshold;self.polls=0
 def is_cancelled(self):self.polls+=1;return self.polls>=self.threshold
def run(factory,values,cls,token=None):
 core=factory();material=Material('chess');material.values=values;stats=SearchStatistics();t=perf_counter()
 with active(cls) if cls else nullcontext():
  action,score,pv,reason=search.run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=12,max_nodes=4096,max_time_seconds=60,quiescence_max_depth=0,quiescence_hard_max_depth=0),token,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
 assert core.restored()
 return dict(move=core.label(action),score=score,pv=[core.label(a) for a in pv],reason=reason,statistics=asdict(stats),wall_seconds=perf_counter()-t)
def signature(r):
 s={k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
 return r['move'],r['score'],r['pv'],r['reason'],s
start=perf_counter()
try:
 modes=[('baseline',None),('inline',InlineContext),('closure',FusedContext)]
 for name,factory,values in ns['factories'][3:]:
  for repeat,order in enumerate((modes,list(reversed(modes)))):
   for mode,cls in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    row=run(factory,values,cls);row.update(case=name,backend=mode,repeat=repeat);report['rows'].append(record_value(row));save()
    print(name,repeat,mode,round(row['wall_seconds'],3),flush=True)
  rows=[r for r in report['rows'] if r['case']==name];assert all(signature(r)==signature(rows[0]) for r in rows)
 name,factory,values=ns['factories'][3]
 for threshold in (5,500,50000):
  batch=[]
  for mode,cls in modes:
   token=Cancel(threshold);row=run(factory,values,cls,token);row.update(case=name,backend=mode,threshold=threshold,polls=token.polls);report['cancellation'].append(record_value(row));batch.append(row);save()
  assert all(signature(r)==signature(batch[0]) and r['polls']==batch[0]['polls'] for r in batch)
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
