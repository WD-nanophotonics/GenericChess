# Terminal/frontier decision, measured scope
The installed v4 terminal performs full candidate-buffer construction then stops
at the first checked legal child. Its availability probe explicitly clears ply
and history; public terminal validates exact history, then uses the original
history for repetition, continuous check, automatic adjudication and max ply.
A real-position transient action list cannot replace that availability witness
at a cutoff. No-move terminal precedence must remain intact; Native no-move-loss
is separately unsupported. No new binary is built or retried in this segment.

Six fixed4096-entry profiles use the same corrected lexical scheduler. Native
queries terminal4096 times but a full frontier only331-413 times (including
preflight/PV validation); most terminal work is at leaves. Direct C terminal
cost is the largest Native hotspot in all3controls. This supports improving
the first-action terminal path, not blindly materializing all leaf frontiers.
A subsequent source audit corrects the initial Core-prefix assumption: Core's
terminal iterator stops at one binding and is discarded; its later runtime
legal_actions starts a new stream. The old qfrontier observation belonged to a
different search path and cannot establish reuse here. Test a frame-local Core
prefix prototype without changing adjudication, providers or product defaults.
A future joint query must (1) retain exact history authority, (2) request full
frontier only at expandable nodes, (3) certify legality independent of history
cutoff and then apply unchanged adjudication precedence, (4) preserve cancellation,
(5) measure actual calls and total caller cost. No measured speedup follows
from a source-level proposal. The final product C block remains unresolved;
short Python/specialized attribution continues independently.
