"""Summarize completed scoped evidence; immutable experiment outputs untouched."""
from pathlib import Path
import json,hashlib,zipfile,statistics
ROOT=Path(__file__).resolve().parents[2];folder=Path(__file__).parent
def read(name):return json.loads((folder/name).read_bytes())
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
def grouped(rows,keys):
 groups={}
 for row in rows:groups.setdefault(tuple(row[k] for k in keys),[]).append(row)
 return groups
out={}
for file,base,candidate,keys in [('checkpoint-transfer.json','before','after',['case']),('attack-assay.json','baseline','atlas',['case'])]:
 data=read(file);assert data['complete'];rows=data['rows']
 if file=='attack-assay.json':rows=[r for r in rows if r['seconds'] is None]
 summaries=[]
 for key,group in grouped(rows,keys).items():
  times={arm:statistics.mean(r['wall_seconds'] for r in group if r['backend']==arm) for arm in (base,candidate)}
  summaries.append(dict(case=key[0],mean_seconds=times,local_reduction=1-times[candidate]/times[base]))
 out[file]=dict(rows=len(data['rows']),groups=summaries)
 if 'audits' in data:out[file]['audits']=data['audits']
data=read('checkpoint-time.json');assert data['complete'];pairs=[]
for key,group in grouped(data['rows'],['case','q','seconds','repeat']).items():
 a=next(r for r in group if r['backend']=='before');b=next(r for r in group if r['backend']=='after')
 pairs.append(dict(case=key[0],q=key[1],seconds=key[2],repeat=key[3],depth_before=a['statistics']['completed_depth'],depth_after=b['statistics']['completed_depth'],move_before=a['move'],move_after=b['move'],exit_before=a['reason'],exit_after=b['reason']))
out['time_pairs']=pairs
data=read('cost-cancel.json');assert data['complete']
out['cost_profiles']=[{k:r[k] for k in ('case','profile_total','direct_groups','geometry_direct_fraction','ideal_geometry_body_removal_profile_ceiling')} for r in data['profiles']]
out['cancellation']={arm:dict(calls=len(rows),max_request_to_return=max(r['request_to_return_seconds'] for r in rows),max_observed_poll_gap=max(r['max_observed_poll_gap_seconds'] for r in rows)) for arm,rows in ((arm,[r for r in data['cancellation'] if r['backend']==arm]) for arm in ('before','after'))}
data=read('trace-scope.json');assert data['complete'];summaries=[]
for key,rows in grouped(data['rows'],['case']).items():
 signatures=[tuple(r['result'][k] if k not in ('action','principal_variation') else json.dumps(r['result'][k],sort_keys=True) for k in ('score','action','principal_variation','completed_depth','nodes','qnodes','termination_reason','beta_cutoffs')) for r in rows]
 assert all(s==signatures[0] for s in signatures)
 times={str(arm):statistics.mean(r['caller_seconds'] for r in rows if r['trace']==arm) for arm in (False,True)}
 first=next(r for r in rows if r['trace'])['result']
 summaries.append(dict(case=key[0],times=times,trace_ratio=times['True']/times['False'],trace_count=first['training_trace_count'],trace_raw_count=first['training_trace_raw_count'],trace_row_fields=sorted(first['training_trace'][0])))
out['trace_scope']=summaries
write(folder/'final-summary.json',out)
print(json.dumps({k:v for k,v in out.items() if k!='time_pairs'},indent=2))
