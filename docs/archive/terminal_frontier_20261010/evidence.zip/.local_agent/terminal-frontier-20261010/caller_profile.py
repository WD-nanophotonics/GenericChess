"""Complete Native caller profile, material-only supported q0/TT0/D3.
Six existing roots. Is returned leaf-feature/replay overhead material relative
to raw kernel? No feature suppression before measurement. One cProfile call
per root; report direct costs and kernel elapsed separately, not an equal-time
algorithm comparison. No new labels or binary, projected<20seconds.
"""
from pathlib import Path
import sys,json,cProfile,pstats,hashlib
from dataclasses import asdict
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.research_record import record_value
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=Path(__file__).with_name('caller-profile.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
start=perf_counter()
try:
 for name,factory,values in ns['factories']:
  for flag in ('rollout','advisor','slack'):
   f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
  core=factory();board=NativeBoard(core,values)
  engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=0)
  session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
  p=cProfile.Profile();r=p.runcall(engine.search,session,SearchLimits(max_depth=3,max_nodes=100000,max_time_seconds=30,quiescence_max_depth=0),root_window_pruning=False)
  stats=pstats.Stats(p)
  calls=[dict(file=k[0],line=k[1],name=k[2],primitive_calls=v[0],calls=v[1],direct_seconds=v[2],inclusive_seconds=v[3]) for k,v in stats.stats.items()]
  calls.sort(key=lambda v:v['direct_seconds'],reverse=True)
  assert session.state==core.initial and board.restored()
  report['rows'].append(record_value(dict(case=name,result=asdict(r),profile_seconds=stats.total_tt,calls=calls)));save()
  print(name,round(r.elapsed_seconds,4),round(stats.total_tt,4),[(c['name'],round(c['direct_seconds'],4),c['calls']) for c in calls[:5]],flush=True)
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
