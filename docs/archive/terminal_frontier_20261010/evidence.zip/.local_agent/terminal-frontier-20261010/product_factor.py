"""Does product overhead or order/TT explain the observed completion deficit?
Existing EP/generated2000/2001; Core product q0, tactical/PVS/aspiration OFF,
TTxordering four cells. Two reversed repeats atD3/1million/60s fuse. One separately
instrumented cProfile per cell/root; report profiling separately, not throughput.
FiniteD3 full-window score parity (completed cells only), actual pushes/generation/
ordering/TT/callback costs. Same evaluator, full history and declared options.
Product un-ordered order=str(action), unlike thin lexical public labels; never
claim exact traversal equality. No automatic default adoption from a faster cell.
Projected under6minutes, no extension of frozen tests or new oracle.
"""
from pathlib import Path
import sys,json,hashlib,cProfile,pstats
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
from scripts.search_backend_comparison import Material
from generic_chess.ai.alphabeta.search import run_root_search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],profiles=[],complete=False)
out=Path(__file__).with_name('product-factor.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def run(factory,values,tt,ordering):
 core=factory();material=Material('chess');material.values=values;stats=SearchStatistics();start=perf_counter()
 action,score,pv,reason=run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=60,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=tt,use_ordering=ordering,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
 wall=perf_counter()-start
 assert core.restored()
 return dict(move=core.label(action),score=score,pv=[core.label(a) for a in pv],reason=reason,wall_seconds=wall,statistics=asdict(stats))
start=perf_counter()
try:
 for name,factory,values in ns['factories'][3:]:
  cells=[(False,False),(False,True),(True,False),(True,True)]
  for repeat,order in enumerate((cells,list(reversed(cells)))):
   for tt,ordering in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    r=run(factory,values,tt,ordering);r.update(case=name,repeat=repeat,tt=tt,ordering=ordering);report['rows'].append(record_value(r));save()
    print(name,repeat,tt,ordering,r['reason'],round(r['wall_seconds'],3),r['statistics']['nodes'],r['score'],flush=True)
  for tt,ordering in cells:
   p=cProfile.Profile();r=p.runcall(run,factory,values,tt,ordering);stats=pstats.Stats(p)
   calls=[dict(file=k[0],line=k[1],name=k[2],calls=v[1],direct_seconds=v[2],inclusive_seconds=v[3]) for k,v in stats.stats.items()]
   calls.sort(key=lambda x:x['direct_seconds'],reverse=True)
   report['profiles'].append(dict(case=name,tt=tt,ordering=ordering,result=record_value(r),profile_total_seconds=stats.total_tt,calls=calls));save()
  completed=[r for r in report['rows'] if r['case']==name and r['reason']=='completed_depth']
  report.setdefault('finite_scores',{})[name]=dict(completed=len(completed),scores=sorted(set(r['score'] for r in completed)))
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
