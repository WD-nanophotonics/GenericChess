"""Existing Native trace observability: two roots, D3/TT0/q0/OFF, two reversed
passes with trace OFF/ON (8 calls). Does the existing training trace expose
PV re-search work? Preserve signatures/counters, measure trace overhead; no new
binary, kernel patch, oracle or claim about isolated scheduling causality.
Expected <30 seconds. This tests observability, not a trace default change.
"""
from pathlib import Path
import sys,json,hashlib
from dataclasses import asdict
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.research_record import record_value
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
for name,factory,values in (ns['factories'][3],ns['factories'][4]):
 for repeat,order in enumerate(((False,True),(True,False))):
  for trace in order:
   for flag in ('rollout','advisor','slack'):
    flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
   core=factory();board=NativeBoard(core,values)
   engine=SemanticSearchEngine(core.compiled,board.native,board_values=values,hand_values=values,tt_megabytes=0)
   session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
   t=perf_counter();r=engine.search(session,SearchLimits(max_depth=3,max_nodes=100000,max_time_seconds=30,quiescence_max_depth=0),root_window_pruning=False,trace_enabled=trace);wall=perf_counter()-t
   assert session.state==core.initial and board.restored()
   report['rows'].append(record_value(dict(case=name,repeat=repeat,trace=trace,result=asdict(r),caller_seconds=wall)))
report['complete']=True
Path(__file__).with_name('trace-scope.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print([(r['case'],r['trace'],r['result']['training_trace_count'],r['caller_seconds']) for r in report['rows']])
