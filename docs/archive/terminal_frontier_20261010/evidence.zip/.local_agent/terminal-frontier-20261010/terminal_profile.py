"""Predeclared terminal/frontier cost attribution on supported existing roots.
EP and generated2000/2001, corrected verified scheduler, fixed4096 entries;
Core and Native transient syntax, one instrumented call each. cProfile direct
C cost only, inclusive times never added. Profile overhead is not throughput.
No new binary, no weaker history/terminal query and no new teacher. Decide if
joint endpoint would attack measured duplicate query work or a guessed hotspot.
Projected <20s. Retain partial failure and count actual calls/work/depth.
"""
from pathlib import Path
import sys,json,hashlib,cProfile,pstats
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
source=ROOT/'.local_agent/root-bound-20261010/transient_frontier.py'
ns={'__file__':str(source)}
exec(source.read_text(encoding='utf-8-sig').split('report=dict')[0],ns)
from scripts.research_record import record_value
common=ROOT/'.local_agent/root-bound-20261010/corrected_backend_comparison.py'
common_ns={'__file__':str(common)}
exec(common.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],common_ns)
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=Path(__file__).with_name('terminal-profile.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
start=perf_counter()
try:
 for name,factory,values in ns['fns']['factories'][3:]:
  for label in ('Core','NativeTransient'):
   for flag in ('rollout','advisor','slack'):
    f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
   core=factory();board=core if label=='Core' else ns['TransientSyntax'](core,values)
   profile=cProfile.Profile();r=profile.runcall(common_ns['iterative'],board,30,4096)
   stats=pstats.Stats(profile)
   calls=[dict(file=k[0],line=k[1],name=k[2],primitive_calls=v[0],calls=v[1],direct_seconds=v[2],inclusive_seconds=v[3]) for k,v in stats.stats.items()]
   calls.sort(key=lambda v:v['direct_seconds'],reverse=True)
   assert board.restored() and core.restored()
   report['rows'].append(record_value(dict(case=name,backend=label,result=r,profile_seconds=stats.total_tt,calls=calls)))
   save();print(name,label,r['completed_depth'],[(c['name'],round(c['direct_seconds'],4),c['calls']) for c in calls[:5]],flush=True)
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
