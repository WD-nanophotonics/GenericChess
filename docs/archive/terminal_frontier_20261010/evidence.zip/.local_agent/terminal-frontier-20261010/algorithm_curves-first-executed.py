"""Predeclared completion/caller curves, not a playing-strength assay.
Existing Chess EP, Shogi drop, generated2000/2001 ply3. Corrected lexical minimal
Core, identical minimal Native-state (supported rules only), specialized minimal
(familiar games only), supported Core TT/order/q0, supported Native legality/Core
TT/order/q0, full Native TT0/q0/OFF (supported rules only). No unsupported fallback.
Common .25/1/4sec and1million numeric fuse, two reversed passes, maxD12. Numeric
nodes differ by algorithm and are not equal work. Preparation lies within minimal
timer; product caller time includes its preflight and validation, kernel separately.
Use no new labels/oracle; output choices/completion/PV and observed exit reasons.
If a larger fuse binds, report censoring rather than extending this batch. No
default/price change or warm-table claim. Expected about4minutes, interruptible
each call, fixed cohort and costs before observing outcomes.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
from scripts.search_backend_comparison import CASES,CoreBoard,ChessBoard,ShogiBoard,VALUES,supported_search,Material
from scripts.bounded_root_scheduler import iterative_root_search
from scripts.native_backend_bridge import NativeBoard
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native import _module
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
from scripts.research_record import record_value
factories=list(ns['factories'][3:]);case=CASES[7]
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'))
factories.insert(1,(case['id'],lambda:CoreBoard(case,c),VALUES['shogi']))
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(Path(_module().__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=Path(__file__).with_name('algorithm-curves.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
start=perf_counter()
try:
 for name,factory,values in factories:
  familiar=next((v for v in CASES if v['id']==name),None)
  modes=['minimal_core','product_core','product_native_legality']
  if name!='shogi-drop':modes+=['minimal_native_state','product_native_full']
  if familiar:modes+=['minimal_specialized']
  for seconds in (.25,1,4):
   for repeat,order in enumerate((modes,list(reversed(modes)))):
    for mode in order:
     for flag in ('rollout','advisor','slack'):
      flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
     t=perf_counter();core=factory()
     material=Material('chess');material.values=values;core.material=material
     provider=None
     if mode=='product_native_legality':
      provider=NativeSemanticLegalityProvider.try_create(core.compiled,strict=True);assert provider is not None
     if mode=='minimal_native_state':board=NativeBoard(core,values)
     elif mode=='minimal_specialized':board=ChessBoard(familiar) if familiar['game']=='chess' else ShogiBoard(familiar)
     else:board=core
     if mode=='product_native_full':
      adapter=NativeBoard(core,values)
      engine=SemanticSearchEngine(core.compiled,adapter.native,board_values=values,hand_values=values,tt_megabytes=0)
      session=GameSession(core.compiled);session._state=core.initial;session._search_history_witnesses=core.witnesses
     setup=perf_counter()-t;t=perf_counter()
     if mode.startswith('minimal_'):
      row=iterative_root_search(board,seconds=seconds,node_limit=1000000,max_depth=12)
     elif mode=='product_native_full':
      result=engine.search(session,SearchLimits(max_depth=12,max_nodes=1000000,max_time_seconds=seconds,quiescence_max_depth=0),root_window_pruning=False)
      row=dict(result=asdict(result),move=None if result.action is None else core.label(result.action),score=result.score,completed_depth=result.completed_depth,exit_cause=result.termination_reason,pv_labels=[core.label(a) for a in result.principal_variation],kernel_seconds=result.elapsed_seconds,root_restored=session.state==core.initial)
     else:
      row=supported_search(core,12,seconds,1000000,provider)
      row['completed_depth']=row['statistics']['completed_depth']
      row['exit_cause']=row['reason'];row['root_restored']=core.restored()
     caller=perf_counter()-t
     assert row['root_restored']
     # Validate returned action/PV outside the product timing, as a separate cost.
     if not mode.startswith('minimal_'):
      vt=perf_counter();pushed=0
      try:
       for label in row.get('pv_labels',row.get('pv',[])):
        actions=dict(core.actions());assert label in actions;core.push(actions[label]);pushed+=1
      finally:
       for _ in range(pushed):core.pop()
      row['external_validation_seconds']=perf_counter()-vt
      assert core.restored()
     row.update(case=name,backend=mode,repeat=repeat,cap_seconds=seconds,cap_nodes=1000000,setup_seconds=setup,total_caller_seconds=caller)
     report['rows'].append(record_value(row));save()
     print(name,seconds,repeat,mode,row['completed_depth'],round(caller,3),row['move'],flush=True)
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
