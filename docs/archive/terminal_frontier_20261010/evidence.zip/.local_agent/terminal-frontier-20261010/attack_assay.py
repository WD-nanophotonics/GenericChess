"""Static compatibility atlas, one changed premise and one decision.
EP/generated2000/2001. Audit every D2 complete child against baselineNative
(3974states), plus all squares/both owners pseudo-attack at root/allD1children.
Then fixed4096/60sec and1/4sec/1million, q0 cold supported Core product, two
reversed passes=36calls. Compare all non-time stats, decisions/PV/root restoration.
No generated rule cohort/price/oracle growth, no all-rule certificate gate.
Construction time/metadata bytes reported; not charged per SemanticEngine.
Possible savings warrant a future compile-owned implementation, not a global
cache or this monkeypatch. Negative result rejects premise at this scope.
Projected<4min, upper bounded call budget, run only after prior time batch.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from contextlib import nullcontext
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from attack_compatibility import active
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
from scripts.search_backend_comparison import Material
from scripts.native_backend_bridge import NativeBoard,audit_native_tree
from generic_chess.core.semantic_executor import SemanticEngine
import generic_chess.ai.alphabeta.search as search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
folder=Path(__file__).parent
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),prototype_sha256=hashlib.sha256((folder/'attack_compatibility.py').read_bytes()).hexdigest(),rows=[],audits=[],complete=False)
out=folder/'attack-assay.json'
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def signature(r):return r['move'],r['score'],r['pv'],r['reason'],{k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
start=perf_counter()
try:
 for name,factory,values in ns['factories'][3:]:
  core=factory();positions=[core.runtime.position]
  for _,move in core.actions():
   core.push(move);positions.append(core.runtime.position);core.pop()
  engine=SemanticEngine(core.compiled)
  expected=[tuple(engine.is_square_attacked(p,s,o) for o in (0,1) for s in range(len(p.board))) for p in positions]
  t=perf_counter()
  with active(core.compiled) as metadata:
   construction=perf_counter()-t
   actual=[tuple(engine.is_square_attacked(p,s,o) for o in (0,1) for s in range(len(p.board))) for p in positions]
   assert actual==expected
   states=audit_native_tree(core,NativeBoard(factory(),values),2)
  report['audits'].append(dict(case=name,states=states,attack_queries=sum(len(x) for x in actual),construction_seconds=construction,metadata=metadata));save()
  for seconds in (None,1,4):
   for repeat,order in enumerate((('baseline','atlas'),('atlas','baseline'))):
    for mode in order:
     for flag in ('rollout','advisor','slack'):
      flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
     core=factory();stats=SearchStatistics();material=Material('chess');material.values=values
     t=perf_counter()
     with active(core.compiled) if mode=='atlas' else nullcontext():
      construction=perf_counter()-t;t=perf_counter()
      action,score,pv,reason=search.run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=12,max_nodes=4096 if seconds is None else 1000000,max_time_seconds=60 if seconds is None else seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
      wall=perf_counter()-t
     assert core.restored()
     row=dict(case=name,seconds=seconds,backend=mode,repeat=repeat,move=core.label(action),score=score,pv=[core.label(a) for a in pv],reason=reason,statistics=asdict(stats),wall_seconds=wall,construction_seconds=construction)
     report['rows'].append(record_value(row));save();print(name,seconds,repeat,mode,round(wall,3),stats.completed_depth,flush=True)
  rows=[r for r in report['rows'] if r['case']==name and r['seconds'] is None];assert all(signature(r)==signature(rows[0]) for r in rows)
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
