# Search-result consumer audit

The public Native result exposes an estimate, completed iteration depth and a
legally replayable continuation. The old warm64 D2 replay already demonstrated
that these do not certify a literal PV leaf value or a finite full-width horizon.
This segment clarifies that contract in the result docstring only; it changes no
score, depth, cache, player or guard.

Current selfplay does not use result.score as a winner label. It replays the PV
through Core and constructs leaf material/dynamic features, then computes its
normalized evaluator value. The terminal outcome comes from the played session;
a max-ply stop remains a bootstrap situation. Arena retains result.score as a
search metric but reads winner from session.result. Therefore a supposed
score-as-outcome repair would solve a defect that is not present in these callers.
Neither caller turns PV legality into an independently verified terminal proof.

Six instrumented cold TT0/q0/D3 Native calls retain the original state. The
returned leaf dynamic feature call occurs once per call and costs0.000187–
0.000864sec directly. Product wrapper overhead is relatively visible in the
short promotion call, but is dominated by public replay/validation rather than
that direct feature call. No feature-suppression API is justified by this audit.
Profile inclusive costs overlap; they must not be summed. Kernel elapsed is
separate from complete caller time, and cProfile totals are not raw throughput.

Sources: generic_chess/native/semantic_engine.py, learning/selfplay.py and
learning/arena.py pinned to the segment base; the only result source change is
the docstring. Earlier warm replay is in root_bound_20261010, not rerun or refit.
