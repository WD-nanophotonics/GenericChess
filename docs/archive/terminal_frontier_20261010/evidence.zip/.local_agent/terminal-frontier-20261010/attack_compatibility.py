"""Scoped compile-lifetime geometry compatibility, not an attack/state cache.
Changed premise versus rejected constructor filtering: build the immutable atlas
once for the supplied compiled rule, outside all per-operation engine instances.
Keep pattern/type/source/compatible-geometry order and state/slot/path guards;
all S0/S1 patterns participate including S4-bearing patterns. Missing/drop/type-
incompatible geometries are exactly the original static skips. A poll remains
before every real geometry/path work unit; skipped units have no blocking work.
One context/local owner; no global identity cache or product adoption here.
"""
from contextlib import contextmanager
import inspect,textwrap,sys
import generic_chess.core.semantic_executor as executor
original=executor.SemanticEngine.is_square_attacked
source=textwrap.dedent(inspect.getsource(original))
needle='''                for gid in pattern.geometry_ids:
                    _checkpoint(checkpoint)
                    geometry = self.ir.geometry.get(gid)
                    if geometry is None or geometry.kind == "drop":
                        continue
                    if (
                        geometry.atom_source is not None
                        and geometry.atom_source[0] != tid
                    ):
                        continue
'''
assert source.count(needle)==1
template=source.replace(needle,'''                for gid, geometry in _compatible_geometry(pattern, tid):
                    _checkpoint(checkpoint)
''')
@contextmanager
def active(compiled):
 atlas={}
 for pattern in compiled.ir.patterns:
  for tid in pattern.type_ids:
   atlas[(pattern.pattern_id,tid)]=tuple((gid,g) for gid in pattern.geometry_ids if (g:=compiled.ir.geometry.get(gid)) is not None and g.kind!='drop' and (g.atom_source is None or g.atom_source[0]==tid))
 namespace=dict(executor.__dict__,_compatible_geometry=lambda pattern,tid:atlas[(pattern.pattern_id,tid)])
 exec(template,namespace);patched=namespace['is_square_attacked']
 def dispatched(engine,*args,**kwargs):
  return (patched if engine.semantic is compiled else original)(engine,*args,**kwargs)
 saved=executor.SemanticEngine.is_square_attacked;executor.SemanticEngine.is_square_attacked=dispatched
 try:yield dict(entries=len(atlas),compatible_geometries=sum(map(len,atlas.values())),shallow_bytes=sys.getsizeof(atlas)+sum(sys.getsizeof(k)+sys.getsizeof(v)+sum(sys.getsizeof(pair) for pair in v) for k,v in atlas.items()))
 finally:executor.SemanticEngine.is_square_attacked=saved
