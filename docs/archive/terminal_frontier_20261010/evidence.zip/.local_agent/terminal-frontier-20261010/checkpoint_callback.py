"""Scoped callback dispatch fusion: retain every checkpoint and abort precedence.
Subclass context owns one per-context callback. Node/q totals stay live; deadline
and cancellation read the budget live (reserve scheduling can change deadline).
No polling throttle, cached time, early budget return or fixed-state capture.
Default product stays unchanged until measured semantics/cancellation evidence.
"""
from contextlib import contextmanager
import generic_chess.ai.alphabeta.search as search
OriginalContext=search._Context
class FusedContext(OriginalContext):
 __slots__=('_semantic_checkpoint',)
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  budget=self.budget;stats=self.stats
  def check():
   if budget._max_nodes is not None and stats.nodes+stats.qnodes>=budget._max_nodes:
    raise search.SearchAborted('node_limit')
   if budget._cancel is not None and budget._cancel.is_cancelled():
    raise search.SearchAborted('cancelled')
   if budget._deadline is not None and search.time.monotonic()>=budget._deadline:
    raise search.SearchAborted('time_limit')
  self._semantic_checkpoint=check
 @property
 def checkpoint(self):return self._semantic_checkpoint
class InlineContext(OriginalContext):
 __slots__=()
 def checkpoint(self):
  budget=self.budget
  if budget._max_nodes is not None and self.stats.nodes+self.stats.qnodes>=budget._max_nodes:
   raise search.SearchAborted('node_limit')
  if budget._interactive:
   if budget._cancel is not None and budget._cancel.is_cancelled():
    raise search.SearchAborted('cancelled')
   if budget._deadline is not None and search.time.monotonic()>=budget._deadline:
    raise search.SearchAborted('time_limit')
@contextmanager
def active(cls=FusedContext):
 original=search._Context;search._Context=cls
 try:yield
 finally:search._Context=original
