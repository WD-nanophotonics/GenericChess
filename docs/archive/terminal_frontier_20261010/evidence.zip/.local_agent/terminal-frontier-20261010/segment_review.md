# Actual segment chain and limitations

Original ID97631c59-1a5c-4a49-a350-7ed8d161b546/start08:23:55.685037UTC
retained after compact. Phase chain: terminal/frontier profile -> common Shogi
resource curves -> exact-history prefix reuse negative -> caller/PV contract ->
serial algorithm/factor recovery -> callback dispatch alternatives -> installed
q2 transfer ->96 common-time controls -> fresh dot review/adoption -> compile-owned
atlas and current disjoint cost ceiling ->24 real cancellation latencies ->
existing trace observability/cost -> same-backend fixed and cumulative D3 work ->
source/failure closure and reviewed tested publication.

All original memo tasks produced concrete decisions and were replaced with three
executable alternatives. Counter/iteration/tie/cancellation semantics are explicit.
Overlapped timers ineligible as whole sets, exact failed sources retained; all
subsequent performance runs serial. No label fitting, frozen oracle extension,
new worker, C security workaround or UI mutation. Trace188.7MB raw recording cost
is exposed; archive compresses it without dropping adverse rows. Advisor review
is advice, not independent reproduction or publishing approval. Tests and docs
are checkpoints, not an early finish basis. Science remains OPEN.
Normal safe checkpoint after >=60 elapsed minutes; actual ending receipt owns
time/reason. No idle wait or App uptime guarantee; validator does not establish
research quality. Publication success and exact SHA are recorded separately.
