"""Scoped Core terminal-prefix reuse; no product changes.
Keeps one suspended S0-S4 legality stream per live DFS frame. Terminal consumes
one binding, expanded node resumes it. Full terminal adjudication is unchanged.
Real pushes/history stay SearchPathRuntime. Generator checkpoint indirection
uses the current caller, not the checkpoint that originally opened the stream.
Cancel/error discards incomplete prefix so recovery regenerates safely. Pop and
failed push discard child entries; exact Position identity guards each frame.
Single-writer context hook selects only this instance; baseline runtimes retain
original terminal behavior. Native provider/legacy paths are outside this probe.
"""
from contextlib import contextmanager
from pathlib import Path
import inspect
import generic_chess.core.search_runtime as runtime_module
import generic_chess.core.terminal as terminal_module
from generic_chess.core.semantic_executor import _semantic_public_action
from generic_chess.core.movegen import _pass_action_is_legal
from generic_chess.core.actions import PassAction

ORIGINAL_TERMINAL=runtime_module.terminal_from_search_runtime
source=inspect.getsource(ORIGINAL_TERMINAL)
needle='has_legal = engine.has_legal_action(position, checkpoint=checkpoint)'
assert source.count(needle)==1
source=source.replace(needle,'has_legal = _prefix_probe(runtime, engine, checkpoint)')

def _probe(runtime,engine,checkpoint):
    return runtime._prefix_owner._available(runtime,engine,checkpoint)
namespace=dict(terminal_module.__dict__,_prefix_probe=_probe)
exec(source,namespace)
PREFIX_TERMINAL=namespace['terminal_from_search_runtime']

class PrefixBoard:
    def __init__(self,core):
        self.core=core;self.runtime=core.runtime;self.entries={}
        self.original_legal=self.runtime.legal_actions
        self.runtime.legal_actions=self._legal_actions
        self.runtime._prefix_owner=self
        self.started=0;self.resumed=0;self.prefix_hits=0;self.discarded=0
    def __getattr__(self,key):return getattr(self.core,key)
    def _available(self,runtime,engine,checkpoint):
        depth=runtime.depth
        entry=self.entries.get(depth)
        if entry is None:
            holder=[checkpoint]
            def current_checkpoint():
                if holder[0] is not None:holder[0]()
            entry=dict(position=runtime.position,engine=engine,holder=holder,
                iterator=engine.iter_legal_action_bindings(runtime.position,checkpoint=current_checkpoint),prefix=[],exhausted=False,pass_legal=False)
            self.entries[depth]=entry;self.started+=1
        assert entry['position'] is runtime.position
        entry['holder'][0]=checkpoint
        if entry['prefix']:self.prefix_hits+=1;return True
        try:
            semantic,binding=next(entry['iterator'])
        except StopIteration:
            entry['exhausted']=True
            entry['pass_legal']=_pass_action_is_legal(runtime.position,runtime.compiled,checkpoint)
            return entry['pass_legal']
        except BaseException:
            self.entries.pop(depth,None);self.discarded+=1;raise
        entry['prefix'].append((_semantic_public_action(engine,semantic),(semantic,binding)))
        return True
    def _legal_actions(self,checkpoint=None):
        runtime=self.runtime
        if runtime._legal_cache is not None:return runtime._legal_cache
        entry=self.entries.get(runtime.depth)
        if entry is None or runtime.terminal_status.is_terminal:
            return self.original_legal(checkpoint)
        assert entry['position'] is runtime.position
        entry['holder'][0]=checkpoint
        if checkpoint is not None:checkpoint()
        self.resumed+=1
        try:
            if not entry['exhausted']:
                for semantic,binding in entry['iterator']:
                    entry['prefix'].append((_semantic_public_action(entry['engine'],semantic),(semantic,binding)))
                entry['exhausted']=True
                entry['pass_legal']=_pass_action_is_legal(runtime.position,runtime.compiled,checkpoint)
            actions=[action for action,_ in entry['prefix']]
            bindings=dict(entry['prefix'])
            if entry['pass_legal']:actions.append(PassAction())
            if checkpoint is not None:checkpoint()
        except BaseException:
            self.entries.pop(runtime.depth,None);self.discarded+=1;raise
        runtime._bindings=bindings
        runtime._legal_cache=tuple(actions)
        return runtime._legal_cache
    def push(self,action):
        try:self.core.push(action)
        finally:self.entries={d:e for d,e in self.entries.items() if d<=self.runtime.depth}
    def pop(self):
        self.core.pop();self.entries={d:e for d,e in self.entries.items() if d<=self.runtime.depth}
    @contextmanager
    def active(self):
        saved=runtime_module.terminal_from_search_runtime
        def dispatched(runtime,checkpoint=None):
            if getattr(runtime,'_prefix_owner',None) is self:
                return PREFIX_TERMINAL(runtime,checkpoint)
            return saved(runtime,checkpoint)
        runtime_module.terminal_from_search_runtime=dispatched
        try:yield self
        finally:runtime_module.terminal_from_search_runtime=saved
