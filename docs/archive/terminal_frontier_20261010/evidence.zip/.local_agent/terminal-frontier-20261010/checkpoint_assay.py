"""Predeclared same-checkpoint fusion comparison after serial timings finish.
EP/generated2000/2001 existing controls, Core product material/q0/TT/order cold.
Fixed4096/D12 (no time cap) and timed1/4sec/1million/D12, two reversed passes:
36 actual calls. Fixed signatures/statistical counts/PV equal except timing.
Interactive traces independently assert check count, node/cancel/time precedence,
live deadline changes and cancelled push unwind. No dropped semantic callbacks.
Failure rejects this fusion. Completion/choices reported, not presumed strength.
Projected under3min, no binary/labels/training/frozen test growth.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from contextlib import nullcontext
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).parent))
from checkpoint_callback import active,FusedContext,OriginalContext
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
from scripts.search_backend_comparison import Material
import generic_chess.ai.alphabeta.search as search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),callback_sha256=hashlib.sha256(Path(__file__).with_name('checkpoint_callback.py').read_bytes()).hexdigest(),rows=[],contract=[],complete=False)
out=Path(__file__).with_name('checkpoint-assay.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
start=perf_counter()
try:
 # Same fake monotonic stream/cancel checks, precedence and live budget mutations.
 class Cancel:
  def __init__(self):self.calls=0;self.cancelled=False
  def is_cancelled(self):self.calls+=1;return self.cancelled
 saved_clock=search.time.monotonic
 for cls in (OriginalContext,FusedContext):
  token=Cancel();clock=[0];calls=[0]
  def now():calls[0]+=1;return clock[0]
  search.time.monotonic=now
  stats=SearchStatistics();budget=search._Budget(SearchLimits(max_nodes=10,max_time_seconds=5),token)
  ctx=cls(None,None,None,stats,budget,SearchTuning(),True,True,0,0,None)
  events=[]
  for nodes,cancelled,time in [(0,False,0),(9,False,4),(10,True,6),(9,True,6),(9,False,6),(9,False,4)]:
   stats.nodes=nodes;token.cancelled=cancelled;clock[0]=time
   try:ctx.checkpoint();events.append('ok')
   except search.SearchAborted as e:events.append(str(e))
  budget._deadline=10;ctx.checkpoint();events.append('extended_live_deadline_ok')
  report['contract'].append(dict(context=cls.__name__,events=events,cancel_calls=token.calls,clock_calls=calls[0]));save()
 search.time.monotonic=saved_clock
 assert {json.dumps({k:v for k,v in r.items() if k!='context'},sort_keys=True) for r in report['contract']}.__len__()==1
 for name,factory,values in ns['factories'][3:]:
  for seconds in (None,1,4):
   for repeat,order in enumerate((('baseline','fused'),('fused','baseline'))):
    for backend in order:
     for flag in ('rollout','advisor','slack'):
      flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
     core=factory();material=Material('chess');material.values=values;stats=SearchStatistics();t=perf_counter()
     with active() if backend=='fused' else nullcontext():
      action,score,pv,reason=search.run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=12,max_nodes=4096 if seconds is None else 1000000,max_time_seconds=seconds,quiescence_max_depth=0,quiescence_hard_max_depth=0),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
     wall=perf_counter()-t;assert core.restored()
     row=dict(case=name,backend=backend,repeat=repeat,seconds=seconds,move=core.label(action),score=score,pv=[core.label(a) for a in pv],reason=reason,statistics=asdict(stats),wall_seconds=wall)
     report['rows'].append(record_value(row));save();print(name,seconds,repeat,backend,stats.completed_depth,round(wall,3),flush=True)
  rows=[r for r in report['rows'] if r['case']==name and r['seconds'] is None]
  def signature(r):
   s={k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
   return r['move'],r['score'],r['pv'],r['reason'],s
  assert all(signature(r)==signature(rows[0]) for r in rows)
 report['complete']=True
finally:
 search.time.monotonic=saved_clock
 report['wall_seconds']=perf_counter()-start;save()
