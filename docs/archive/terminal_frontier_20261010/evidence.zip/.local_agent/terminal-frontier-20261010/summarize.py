"""Summaries of complete outputs; no performance run or new labels."""
from pathlib import Path
import json,hashlib,statistics
folder=Path(__file__).resolve().parent;root=folder.parents[1]
def read(name):return json.loads((folder/name).read_bytes())
def save(name,value):(folder/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
# Retain the exact first callback source as imported by checkpoint_assay.
source=(folder/'checkpoint_callback.py').read_text(encoding='utf-8')
first=source[:source.index('class InlineContext')]+source[source.index('@contextmanager',source.index('class InlineContext')):]
first=first.replace('def active(cls=FusedContext):','def active():').replace('search._Context=cls','search._Context=FusedContext')
data=first.encode();assert hashlib.sha256(data).hexdigest()==read('checkpoint-assay.json')['callback_sha256']
(folder/'checkpoint_callback-first-executed.py').write_bytes(data)
prefix=read('prefix-comparison.json');summary=[]
for name in sorted({r['case'] for r in prefix['rows']}):
 group=[r for r in prefix['rows'] if r['case']==name]
 walls={b:statistics.mean(r['caller_seconds'] for r in group if r['kind']=='fixed' and r['backend']==b) for b in ('Core','Prefix')}
 summary.append(dict(case=name,fixed_mean=walls,ratio_prefix_to_core=walls['Prefix']/walls['Core'],prefix_counts=[r['prefix_stats'] for r in group if r['backend']=='Prefix'],timed=[dict(backend=r['backend'],repeat=r['repeat'],depth=r['completed_depth'],move=r['move']) for r in group if r['kind']=='timed']))
save('prefix-summary.json',summary)
curves=read('algorithm-curves.json');assert curves['complete'];rows=curves['rows'];summary=[]
for name in sorted({r['case'] for r in rows}):
 for sec in (.25,1,4):
  group=[r for r in rows if r['case']==name and r['cap_seconds']==sec]
  summary.append(dict(case=name,seconds=sec,backends={b:[dict(depth=r['completed_depth'],move=r['move'],score=r['score'],exit=r['exit_cause'],caller=r['total_caller_seconds'],nodes=r.get('work',r.get('statistics',r.get('result',{}))).get('nodes'),kernel=r.get('kernel_seconds')) for r in group if r['backend']==b] for b in sorted({r['backend'] for r in group})}))
save('algorithm-summary.json',dict(rows=len(rows),groups=summary,cooperative_scope='Minimal checks at visits;Core product passes cooperative polls through semantic work;not identical cancellation granularity. Nodes differ by algorithm. All first overlapped timings ineligible.'))
factor=read('product-factor.json');assert factor['complete'];summary=[]
for name in sorted({r['case'] for r in factor['rows']}):
 summary.append(dict(case=name,cells=[dict(tt=t,ordering=o,mean_seconds=statistics.mean(r['wall_seconds'] for r in factor['rows'] if r['case']==name and r['tt']==t and r['ordering']==o),nodes=[r['statistics']['nodes'] for r in factor['rows'] if r['case']==name and r['tt']==t and r['ordering']==o],scores=[r['score'] for r in factor['rows'] if r['case']==name and r['tt']==t and r['ordering']==o]) for t,o in [(False,False),(False,True),(True,False),(True,True)]],callback_profiles=[dict(tt=r['tt'],ordering=r['ordering'],profile_total=r['profile_total_seconds'],calls=[v for v in r['calls'] if v['name'] in ('check','checkpoint','_checkpoint','<built-in method time.monotonic>')]) for r in factor['profiles'] if r['case']==name]))
save('factor-summary.json',dict(rows=len(factor['rows']),profiles=len(factor['profiles']),groups=summary))
print('summarized',len(rows),'serial algorithm rows;',len(prefix['rows']),'prefix rows;',len(factor['rows']),'factor rows')
