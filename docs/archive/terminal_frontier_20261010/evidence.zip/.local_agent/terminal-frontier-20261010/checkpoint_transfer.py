"""Actual product before/after callback transfer, independently scoped.
All eight existing Chess/Shogi roots plus two generated roots, q2,1024nodes and
60second safety fuse, maxD12/TT/order cold; two reversed passes=40calls. No frozen
oracle extension. Node exits must retain action/score/PV/all non-time counters;
any time exits are retained but cannot certify fixed-work parity. Rules/state,
history/declarations/cancel locations unchanged. Compare before exact method
source with installed inline implementation. Expected<6min, upper40min; no
extra workers or machine-wide load, interruptible each call. Useful outcome:
adopt measured dispatch saving only with unchanged semantics; reject mismatch.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
import generic_chess.ai.alphabeta.search as search
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.search_backend_comparison import CASES,CoreBoard,Material,VALUES
from scripts.research_record import record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
f=ROOT/'.local_agent/native-terminal-20261010/syntax_ablation.py';ns={'__file__':str(f)}
exec(f.read_text(encoding='utf-8-sig').split('\nreport=dict')[0],ns)
factories=[]
for case in CASES:
 c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
 factories.append((case['id'],lambda case=case,c=c:CoreBoard(case,c),VALUES[case['game']]))
factories+=ns['factories'][4:]
folder=Path(__file__).parent;namespace=dict(search.__dict__)
exec((folder/'checkpoint_before.py').read_text(encoding='utf-8'),namespace)
before=namespace['checkpoint'];after=search._Context.checkpoint
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),before_sha256=hashlib.sha256((folder/'checkpoint_before.py').read_bytes()).hexdigest(),after_source_sha256=hashlib.sha256(Path(search.__file__).read_bytes()).hexdigest(),rows=[],complete=False)
out=folder/'checkpoint-transfer.json'
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def signature(r):
 return r['move'],r['score'],r['pv'],r['reason'],{k:v for k,v in r['statistics'].items() if 'seconds' not in k and not k.startswith('time_to_')}
start=perf_counter()
try:
 for name,factory,values in factories:
  for repeat,order in enumerate((('before','after'),('after','before'))):
   for mode in order:
    for flag in ('rollout','advisor','slack'):
     flags=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(flags.get('user_paused') or flags.get('stopped'))
    search._Context.checkpoint=before if mode=='before' else after
    core=factory();stats=SearchStatistics();material=Material('chess');material.values=values;t=perf_counter()
    action,score,pv,reason=search.run_root_search(core.initial,core.compiled,material,TranspositionTable(max_entries=65536),SearchLimits(max_depth=12,max_nodes=1024,max_time_seconds=60,quiescence_max_depth=2,quiescence_hard_max_depth=12),None,stats,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False),_history_witnesses=core.witnesses)
    wall=perf_counter()-t;assert core.restored()
    row=dict(case=name,backend=mode,repeat=repeat,move=core.label(action),score=score,pv=[core.label(a) for a in pv],reason=reason,statistics=asdict(stats),wall_seconds=wall)
    report['rows'].append(record_value(row));save();print(name,repeat,mode,round(wall,3),stats.completed_depth,reason,flush=True)
  rows=[r for r in report['rows'] if r['case']==name]
  if all(r['reason']!='time_limit' for r in rows):assert all(signature(r)==signature(rows[0]) for r in rows),name
 report['complete']=True
finally:
 search._Context.checkpoint=after
 report['wall_seconds']=perf_counter()-start;save()
