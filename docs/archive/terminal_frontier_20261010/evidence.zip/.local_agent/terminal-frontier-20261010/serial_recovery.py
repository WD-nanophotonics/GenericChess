"""Retain first concurrent timing attempts and rerun both batches serially.
The first factor started while algorithm curves were still running. Timing/
completion comparisons from both first outputs are ineligible; all retained.
Second run uses the same predeclared cases/caps/orders. Factor summary filters
the actual completed_depth reason (first filter erroneously used depth_limit).
No output selection based on speed or successful result.
"""
from pathlib import Path
import subprocess,sys,json
folder=Path(__file__).resolve().parent
for name in ('algorithm-curves.json','product-factor.json'):
 (folder/name).rename(folder/(name.removesuffix('.json')+'-overlapped.json'))
for name in ('algorithm_curves.py','product_factor.py'):
 (folder/(name.removesuffix('.py')+'-first-executed.py')).write_bytes((folder/name).read_bytes())
p=folder/'product_factor.py'
p.write_bytes(p.read_bytes().replace(b"r['reason']=='depth_limit'",b"r['reason']=='completed_depth'"))
for name in ('algorithm_curves.py','product_factor.py'):
 subprocess.run([sys.executable,str(folder/name)],check=True)
(folder/'serial-recovery.json').write_text(json.dumps(dict(declaration=__doc__,both_serial_complete=True),indent=2)+'\n',encoding='utf-8')
