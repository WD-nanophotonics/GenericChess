"""Resource curves on existing Shogi tactic/drop, predeclared before results.
Core and strict-history cshogi; same lexical verified scheduler/material/q0/noTT.
Both backends receive each (0.25s,1s)x(100000,500000entry) condition; two reversed
arm orders.32 calls. Timer includes root preparation; PV validation outside the
search budget is counted separately in total caller time. The old52 frozen
controls and old finiteD4 reference are untouched, not retroactively extended.
Unknown: does100k censor completion/usefulness or merely unused time? Opposite
results choose pure-time comparison versus retaining cheap fuse. Projected<1min,
interruptible between calls, no one-arm extension, new labels, training or games.
"""
from pathlib import Path
import sys,json,hashlib
from time import perf_counter
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.bounded_root_scheduler import iterative_root_search
from scripts.search_backend_comparison import CASES,CoreBoard,ShogiBoard
from scripts.research_record import record_value
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
report=dict(declaration=__doc__,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),algorithm_sha256=hashlib.sha256((ROOT/'scripts/root_bound_diagnostic.py').read_bytes()).hexdigest(),caller_sha256=hashlib.sha256((ROOT/'scripts/bounded_root_scheduler.py').read_bytes()).hexdigest(),rows=[],complete=False)
out=Path(__file__).with_name('resource-curves.json')
def save():out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
start=perf_counter()
try:
 compiled=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'))
 for case in [CASES[i] for i in (5,7)]:
  for seconds in (.25,1.):
   for cap in (100000,500000):
    for repeat,order in enumerate((('Core','Specialized'),('Specialized','Core'))):
     for backend in order:
      for flag in ('rollout','advisor','slack'):
       f=json.loads((ROOT/'.local_agent'/f'{flag}.json').read_bytes());assert not(f.get('user_paused') or f.get('stopped'))
      t=perf_counter();board=CoreBoard(case,compiled) if backend=='Core' else ShogiBoard(case);setup=perf_counter()-t
      r=iterative_root_search(board,seconds=seconds,node_limit=cap)
      r.update(case=case['id'],backend=backend,repeat=repeat,setup_seconds=setup)
      report['rows'].append(record_value(r));save()
      print(case['id'],seconds,cap,repeat,backend,r['completed_depth'],r['exit_cause'],r['work']['nodes'],r['move'],round(r['caller_seconds'],3),flush=True)
 report['complete']=True
finally:report['wall_seconds']=perf_counter()-start;save()
