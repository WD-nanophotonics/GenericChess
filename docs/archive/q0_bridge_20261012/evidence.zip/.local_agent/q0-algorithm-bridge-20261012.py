import sys,json,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/q0-algorithm-bridge-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists();write_record(out/'declaration.json',dict(question='After canonical repair, is Core PVS alone the remaining advantage on a defined lexical q0 consumer?',calls=6,source='09f4edb0',root='generated1091 samefrozenfullhistory/table',depth=3,q=0,tt=False,nodes=1000000,seconds=64,arms=['Native_exact_q0','Core_AB_lexical','Core_PVS_lexical'],orders=['forward','reverse'],scope='AllfixedD3/Material/fullhistory/fresh noTT; Core arms differonlyuse_pvs. Nativeencoded candidate order/completecanonicalpass differs Corestrlex andmetadata, so not exactwork kernel comparison. Separate actualnode/legal/transition counts. No newroots/capraise/UI/API/q4 orbenchmarkexclusivity.'))
d=json.loads((ROOT/'tests/development/data/native_q0_aux_pv_1091.json').read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(d['rules'])));s=GameSession(c)
for h in d['state']['history'][1:]:s.submit(action_from_dict(json.loads(h['action_signature'])))
class Frozen:
 def evaluate(self,s):
  p=s.position;v=[0,0]
  for pc in p.board:
   if pc:v[pc.owner]+=d['board'][pc.current_type_id]
  for side,h in enumerate(p.hands):
   for tid,n in h.counts:v[side]+=d['hand'][tid]*n
  return v[p.side_to_move]-v[1-p.side_to_move]
 def type_value(self,tid):return d['board'][tid]
 def capture_order_value(self,a,b):return 10*self.type_value(b.current_type_id)-self.type_value(a.current_type_id)
provider=NativeSemanticLegalityProvider.try_create(c,strict=True);rows=[]
for order,arms in enumerate([['Native_exact_q0','Core_AB_lexical','Core_PVS_lexical'],['Core_PVS_lexical','Core_AB_lexical','Native_exact_q0']]):
 for arm in arms:
  e=SemanticSearchEngine(c,provider.native_rules,board_values=d['board'],hand_values=d['hand'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=0) if arm.startswith('Native') else AlphaBetaPlayer(c,evaluator_override=Frozen(),use_tt=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs='PVS' in arm));before=s.state;w=s._search_witnesses;t=time.perf_counter();lim=SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=64,quiescence_max_depth=0);r=e.search(s,lim,root_window_pruning=True) if arm.startswith('Native') else e.choose_action(s,lim);sec=time.perf_counter()-t;assert r.completed_depth==3;ss=before
  for a in r.principal_variation:assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
  assert s.state is before and s._search_witnesses is w;rows.append(dict(arm=arm,order=order,seconds=sec,result=record_value(r),root_restored=True,pv_legal=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(arm,order,round(sec,4),r.score,r.nodes,flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
