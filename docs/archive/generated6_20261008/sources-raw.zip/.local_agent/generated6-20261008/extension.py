import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'extension.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'fixture_sha256':sha(root/'tests/rule_semantics_ir_fixtures.py'),'declaration':'Four fresh generator seeds202610082000..2003,6x6 bilateral_random/hybrid, existing simple generator filters. Recombine known zone-capacity P-drop with consumed temp_right eq0 guard and expiring quiet current-type change on generatedX->P; no assumed chess movement/strength.12public plies, deterministic coverage policy capture>semantic>drop>remaining with lexical ties; stop terminal/noactions, retain event zeros. Final reached frontier: independent bounded Coredepth2 reference4000leaf/3sec and paired Core/Native legality with fixed Native-semantic evaluator search depth2/3 each2cold repeats8192nodes/5sec. <=32searchcalls/300sec. No price selection/defaults, no human data or additional workers. Detect compile/parity/history/interface failures, not playing performance.','cases':[]};write_record(out,r)
r['declaration']='Cost extension, not original frozen5sec test: same generated6seed2003 at originalply12 and semantic-firstply16, full public history, fixed evaluator/TT/order/q0 and8192nodes. Give BOTH Core/Native10sec, two cold repeats each (8calls <=90sec). Independently bounded full-Core minimaxdepth2 for two original reference-capped roots seed2001/2003,20000eval/10sec. Outcomes determine wall-cap versus semantic discrepancy; no defaults or price tuning. Preserve originalcaps.'
r['cases']=[]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.actions import action_from_dict
try:
 for source_name in ('transfer','coverage'):
  source=json.loads((p/(source_name+'.json')).read_bytes());old=next(x for x in source['cases'] if x['seed']==202610082003);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for e in old['route']:s.submit(action_from_dict(e['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');case={'source':source_name,'input_sha256':sha(p/(source_name+'.json')),'searches':[]};r['cases'].append(case)
  for native in (False,True):
   for repeat in (0,1):
    assert time.perf_counter()-started<90
    assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=native,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=8192,max_time_seconds=10,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);case['searches'].append({'native':native,'repeat':repeat,'wall_seconds':time.perf_counter()-t,'decision':record_value(d)});write_record(out,r)
  ds=[x['decision'] for x in case['searches']];case['all_equal']={key:all(x[key]==ds[0][key] for x in ds) for key in ('action','score','nodes','completed_depth','principal_variation')};assert all(case['all_equal'].values());print(source_name,[(x['native'],x['decision']['completed_depth'],x['decision']['nodes'],x['wall_seconds']) for x in case['searches']],flush=True)
 r['references']=[];source=json.loads((p/'transfer.json').read_bytes())
 for seed in (202610082001,202610082003):
  old=next(x for x in source['cases'] if x['seed']==seed);c=compile_ruleset_for_execution(ruleset_from_dict(old['rules']));s=GameSession(c)
  for e in old['route']:s.submit(action_from_dict(e['action']))
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);ev=SemanticAttackEvaluator(c,build_ruleset_profile(c,cfg),cfg,backend='native');counted=CountedEvaluator(ev,seconds=10,evaluations=20000);t=time.perf_counter();row={'seed':seed,'complete':False};r['references'].append(row)
  try:
   score,action=reference_minimax(s.state,2,counted,c);row.update(complete=True,score=score,action=record_value(action));prior=old['searches'][0]['decision'];assert score==prior['score']
  except ReferenceLimit as exc:row['failure']=str(exc)
  row.update(seconds=time.perf_counter()-t,leaf_evaluations=counted.calls);write_record(out,r)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
