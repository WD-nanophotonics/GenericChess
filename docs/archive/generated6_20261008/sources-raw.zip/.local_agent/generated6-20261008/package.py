import json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path.cwd();p=Path(__file__).parent;dest=root/'docs/archive/generated6_20261008';dest.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
analysis=json.loads((p/'analysis.json').read_bytes());assert analysis['complete']
for name,digest in analysis['inputs'].items():assert sha((p/(name+'.json')).read_bytes())==digest
files=sorted(x for x in p.iterdir() if x.suffix in ('.py','.json'))+[root/'tests/rule_semantics_ir_fixtures.py'];members=[];archive=dest/'sources-raw.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  body=f.read_bytes();name=f.relative_to(root).as_posix();z.writestr(name,body);members.append({'path':name,'bytes':len(body),'sha256':sha(body)})
with tempfile.TemporaryDirectory(dir=p) as tmp:
 with zipfile.ZipFile(archive) as z:z.extractall(tmp)
 for x in members:assert sha((Path(tmp)/x['path']).read_bytes())==x['sha256']
index={'base_commit':'55eb7cdaae205e2c2f1bc50e0ecf9f7082c6a9c6','archive_sha256':sha(archive.read_bytes()),'members':members,'extracted_rehashed':True,'excluded':'User/private inputs, raw Slack/accounts, credentials and active workflow state.'}
(dest/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
summary={'complete':True,'producer_sha256':sha(Path(__file__).read_bytes()),'scope':'Four predeclared fresh6x6 hybrid seeds; original capture-first route and separately declared semantic-first coverage extension. Exposed synthetic development only; all terminals, missing coverage and original caps preserved. Same Native attack evaluator, TT/order on,q0,8192nodes; Core/Native legality varied alone.','archive':'../../archive/generated6_20261008/index.json','analysis':analysis,'event_count':len(json.loads((p/'event-frontiers.json').read_bytes())['cases']),'extension':json.loads((p/'extension.json').read_bytes()),'cost_profile':json.loads((p/'profile.json').read_bytes())}
(root/'docs/research/data/generated6_20261008.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print({'members':len(members),'bytes':archive.stat().st_size})
