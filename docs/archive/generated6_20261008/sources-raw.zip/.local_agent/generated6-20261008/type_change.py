import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict,RuleTypeRef,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict,action_to_dict
from generic_chess.core.transition import legal_successors
from generic_chess.core.movegen import legal_actions
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;src=p/'coverage.json';out=p/'type-change.json';assert not out.exists();prior=json.loads(src.read_bytes());start=time.perf_counter();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'input_sha256':sha(src),'declaration':'All first actual X-to-P events from generated6 coverage (seed2000/2003ply1). Compare identical declared quiet action/slot/geometry with effect destination P versus X; retain both rules and all opponent legal replies. Enumerate actual surviving actor continuations at moved square, capture endpoints and current/base type. Count eager Core successors constructed. Compare generic-v1 and opt-in semantic-opportunity raw/profile/scope, not material utility or strength. Two roots<=500reply transitions/60sec, no new law, table tuning, lookahead coordinate or product change.','cases':[]};write_record(out,r)
try:
 for old in prior['cases']:
  found=next(((i,e) for i,e in enumerate(old['route']) if e['action'].get('pattern_id','').startswith('sem_01_')),None)
  if found is None:continue
  i,event=found;definition=ruleset_from_dict(old['rules']);row={'seed':old['seed'],'event_ply':i+1,'action':event['action'],'variants':[]};r['cases'].append(row)
  for target_type in ('P','X'):
   quiet=definition.semantic_actions[1];effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id=target_type)) if e.kind=='set_current_type' else e for e in quiet.effects);changed=replace(definition,semantic_actions=(definition.semantic_actions[0],replace(quiet,effects=effects)));c=compile_ruleset_for_execution(changed);s=GameSession(c)
   for e in old['route'][:i]:s.submit(action_from_dict(e['action']))
   a=action_from_dict(event['action']);assert a in s.legal_actions();s.submit(a);square=a.to_square;idx=square.rank*6+square.file;actor=s.state.position.board[idx];owner=actor.owner
   cfg=EvaluationConfig();profile=build_ruleset_profile(c,cfg);semantic,scope=build_semantic_opportunity_profile(c,cfg)
   v={'target_type':target_type,'rules':ruleset_to_dict(changed),'actor':record_value(actor),'legacy_raw':{t:x.raw_capability_score for t,x in profile.piece_profiles.items()},'legacy_values':dict(profile.board_value_by_type),'semantic_raw':{t:x.raw_capability_score for t,x in semantic.piece_profiles.items()},'semantic_values':dict(semantic.board_value_by_type),'semantic_X_scope':scope['types']['X'],'replies':[]};row['variants'].append(v)
   pairs=legal_successors(s.state,c);v['actual_reply_successors_constructed']=len(pairs);assert len(pairs)<=500
   for reply,child in pairs:
    assert time.perf_counter()-start<60
    assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
    piece=child.position.board[idx];survives=piece is not None and piece.owner==owner and piece.base_type_id==actor.base_type_id
    actions=[x for x in legal_actions(child,c) if getattr(x,'from_square',None)==square] if survives and not child.terminal_status.is_terminal else []
    captures=[x for x in actions if child.position.board[x.to_square.rank*6+x.to_square.file] is not None and child.position.board[x.to_square.rank*6+x.to_square.file].owner!=owner]
    v['replies'].append({'action':action_to_dict(reply),'terminal':record_value(child.terminal_status),'actor_survives':survives,'actor_current_type':piece.current_type_id if survives else None,'actor_actions':[action_to_dict(x) for x in actions],'actor_captures':[action_to_dict(x) for x in captures]})
   write_record(out,r)
  a,b=row['variants'];row['legacy_raw_equal']=a['legacy_raw']==b['legacy_raw'];row['legacy_values_equal']=a['legacy_values']==b['legacy_values'];row['semantic_raw_equal']=a['semantic_raw']==b['semantic_raw'];row['semantic_values_equal']=a['semantic_values']==b['semantic_values'];assert all(row[k] for k in ('legacy_raw_equal','legacy_values_equal','semantic_raw_equal','semantic_values_equal'))
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
for x in r['cases']:print(x['seed'],[(v['target_type'],v['actual_reply_successors_constructed'],sum(len(y['actor_actions']) for y in v['replies']),sum(len(y['actor_captures']) for y in v['replies'])) for v in x['variants']])
