import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from rule_semantics_ir_fixtures import weird_rulesets
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict,RuleTypeRef,RuleSlotGuard
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_to_dict
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,ReferenceLimit,validate_pv
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'coverage.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();started=time.perf_counter()
r={'complete':False,'producer_sha256':sha(Path(__file__)),'fixture_sha256':sha(root/'tests/rule_semantics_ir_fixtures.py'),'declaration':'Four fresh generator seeds202610082000..2003,6x6 bilateral_random/hybrid, existing simple generator filters. Recombine known zone-capacity P-drop with consumed temp_right eq0 guard and expiring quiet current-type change on generatedX->P; no assumed chess movement/strength.Separate coverage extension declared after original cohort. Same four6x6rules;16public plies, semantic-board>guarded-Pdrop>capture>other with lexical ties; all zero/terminal routes retained; stop terminal/noactions, retain event zeros. Final reached frontier: independent bounded Coredepth2 reference4000leaf/3sec and paired Core/Native legality with fixed Native-semantic evaluator search depth2/3 each2cold repeats8192nodes/5sec. <=32searchcalls/300sec. No price selection/defaults, no human data or additional workers. Detect compile/parity/history/interface failures, not playing performance.','cases':[]};write_record(out,r)
fixtures=weird_rulesets();base_drop=fixtures[1].semantic_actions[0];base_quiet=fixtures[2].semantic_actions[0]
try:
 for seed in range(202610082000,202610082004):
  assert time.perf_counter()-started<300
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  generated=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='bilateral_random',allow_hybrid=True))
  drop=replace(base_drop,type_ids=('P',),replace_selector=replace(base_drop.replace_selector,type_ids=('P',)),slot_guards=(RuleSlotGuard(slot_name='temp_right',value=0),))
  effects=tuple(replace(e,type_ref=RuleTypeRef(kind='explicit',type_id='P')) if e.kind=='set_current_type' else e for e in base_quiet.effects)
  quiet=replace(base_quiet,type_ids=('X',),target_relation='empty',effects=effects)
  definition=replace(generated.ruleset,semantic_actions=(drop,quiet));case={'seed':seed,'generated_report':record_value(generated.generation_report),'rules':ruleset_to_dict(definition),'route':[],'searches':[]};r['cases'].append(case);write_record(out,r)
  try:c=compile_ruleset_for_execution(definition)
  except Exception as exc:case['compile_failure']=repr(exc);write_record(out,r);continue
  s=GameSession(c)
  for ply in range(16):
   if s.state.terminal_status.is_terminal:break
   actions=s.legal_actions()
   if not actions:break
   def priority(a):
    d=action_to_dict(a);kind=d['kind'];target=d.get('to');capture=False
    if hasattr(a,'to_square'):
     target_piece=s.state.position.board[a.to_square.rank*6+a.to_square.file];capture=target_piece is not None and target_piece.owner!=s.state.position.side_to_move
    return (0 if d.get('pattern_id','').startswith('sem_01_') else 1 if d.get('pattern_id','').startswith('sem_00_') else 2 if capture else 3,json.dumps(d,sort_keys=True))
   a=min(actions,key=priority);before=s.state;s.submit(a);case['route'].append({'action':action_to_dict(a),'history_length':len(s.state.history),'hands':record_value(s.state.position.hands),'aux':record_value(s.state.position.aux_state),'terminal':record_value(s.state.terminal_status)})
  case['frontier_ply']=s.state.ply_count;case['terminal']=record_value(s.state.terminal_status);case['legal_actions']=len(s.legal_actions()) if not s.state.terminal_status.is_terminal else 0
  if s.state.terminal_status.is_terminal:write_record(out,r);continue
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0);profile=build_ruleset_profile(c,cfg);ev=SemanticAttackEvaluator(c,profile,cfg,backend='native');case['table']=dict(profile.board_value_by_type)
  counted=CountedEvaluator(ev,seconds=3,evaluations=4000);t=time.perf_counter();reference={'complete':False}
  try:score,a=reference_minimax(s.state,2,counted,c);reference.update(complete=True,score=score,action=record_value(a))
  except ReferenceLimit as exc:reference['failure']=str(exc)
  reference.update(seconds=time.perf_counter()-t,leaf_evaluations=counted.calls);case['reference']=reference;write_record(out,r)
  for depth in (2,3):
   for native in (False,True):
    for repeat in (0,1):
     assert time.perf_counter()-started<300
     player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,use_native_semantic_legality=native,tuning=SearchTuning(use_root_tactical=False));t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));validate_pv(s,d);item={'depth':depth,'native':native,'repeat':repeat,'wall_seconds':time.perf_counter()-t,'decision':record_value(d)};case['searches'].append(item);write_record(out,r)
     if depth==2 and reference['complete'] and d.completed_depth==2:assert d.score==reference['score']
     if native:assert d.native_legality_fallbacks==0
  print(seed,case['frontier_ply'],case['legal_actions'],[(x['depth'],x['native'],x['decision']['completed_depth'],x['decision']['score'],x['decision']['termination_reason']) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-started;write_record(out,r)
