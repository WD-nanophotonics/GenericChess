import json,hashlib
from pathlib import Path
p=Path(__file__).parent;out=p/'analysis.json';assert not out.exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
records={k:json.loads((p/(k+'.json')).read_bytes()) for k in ('transfer','coverage','event-frontiers','extension','type-change','profile')}
assert all(r['complete'] for r in records.values())
r={'complete':True,'producer_sha256':sha(Path(__file__)),'inputs':{k:sha(p/(k+'.json')) for k in records},'search_rows':[],'transformation_rows':[]}
for name in ('transfer','coverage'):
 for c in records[name]['cases']:
  if not c['searches']:
   r['search_rows'].append({'route':name,'seed':c['seed'],'terminal':c['terminal'],'ply':c['frontier_ply'],'no_search':True});continue
  for depth in (2,3):
   ss=[x for x in c['searches'] if x['depth']==depth];complete=[x for x in ss if x['decision']['completed_depth']==depth]
   keys=('action','score','nodes','completed_depth','principal_variation')
   equality={k:all(x['decision'][k]==complete[0]['decision'][k] for x in complete) for k in keys};assert all(equality.values())
   modes={str(mode):{'completed':sum(x['decision']['completed_depth']==depth for x in ss if x['native']==mode),'nodes':[x['decision']['nodes'] for x in ss if x['native']==mode],'wall_seconds':[x['wall_seconds'] for x in ss if x['native']==mode],'scores':[x['decision']['score'] for x in ss if x['native']==mode],'termination':[x['decision']['termination_reason'] for x in ss if x['native']==mode]} for mode in (False,True)}
   r['search_rows'].append({'route':name,'seed':c['seed'],'depth':depth,'legal_actions':c['legal_actions'],'completed_parity':equality,'modes':modes})
for c in records['type-change']['cases']:
 a,b=c['variants'];key=lambda x:json.dumps(x['action'],sort_keys=True);left={key(x):x for x in a['replies']};right={key(x):x for x in b['replies']};common=sorted(left.keys()&right.keys());rows=[]
 for k in common:
  x,y=left[k],right[k]
  # Endpoint counts are a stated finite observable, not physical successor
  # equivalence or permission to merge public action/history identities.
  endpoint=lambda acts:{tuple(z['to']) for z in acts}
  ax,ay=endpoint(x['actor_actions']),endpoint(y['actor_actions']);cx,cy=endpoint(x['actor_captures']),endpoint(y['actor_captures'])
  rows.append({'reply':x['action'],'survives':[x['actor_survives'],y['actor_survives']],'terminal':[x['terminal'],y['terminal']],'action_binding_counts':[len(x['actor_actions']),len(y['actor_actions'])],'move_endpoints':[len(ax),len(ay)],'capture_endpoints':[len(cx),len(cy)],'move_endpoint_sets_equal':ax==ay,'capture_endpoint_sets_equal':cx==cy,'P_only_move':sorted(ax-ay),'X_only_move':sorted(ay-ax),'P_only_capture':sorted(cx-cy),'X_only_capture':sorted(cy-cx)})
 r['transformation_rows'].append({'seed':c['seed'],'P_only_reply_count':len(left.keys()-right.keys()),'X_only_reply_count':len(right.keys()-left.keys()),'common_replies':len(common),'move_difference_count':sum(not x['move_endpoint_sets_equal'] for x in rows),'capture_difference_count':sum(not x['capture_endpoint_sets_equal'] for x in rows),'rows':rows})
(out).write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'search_cells':len(r['search_rows']),'transformation':[{k:v for k,v in x.items() if k!='rows'} for x in r['transformation_rows']]},indent=2))
