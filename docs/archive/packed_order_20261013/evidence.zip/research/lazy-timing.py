from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent
exec((OUT/'replay.py').read_text().split('rows=[];tables=[]')[0],globals())
from generic_chess.native.semantic import candidate_actions,make_checked
# The exact private adapter inspected/counted above; no private C trace/counter DLL.
s=(OUT/'counter-verify.py').read_text();exec(s[s.index('class Candidate(Packed):'):s.index('rows=[]\nfor case')],globals())
rows=[]
for case in [c for c in CASES if c['game']=='chess']:
 core=CoreBoard(case,compile_ruleset_for_execution(build_builtin_ruleset('western_chess')))
 for pair,order in enumerate([['guarded','lazy','lazy_cached'],['lazy_cached','lazy','guarded']]):
  for arm in order:
   b=Packed(core,VALUES['chess']) if arm=='guarded' else Candidate(core,cache=arm=='lazy_cached')
   r=minimal_ab(b,4,seconds=60,node_limit=1000000);assert r['reason']=='completed_depth';rows.append(dict(case=case['id'],pair=pair,arm=arm,result=r,adapter={k:getattr(b,k,None) for k in ('attempts','rejects','labels','label_hits')}));(OUT/'lazy-timing.json').write_text(json.dumps(rows,indent=2)+'\n');print(case['id'],pair,arm,round(r['wall_seconds'],4),flush=True)
# Frozen whole-work equality, not matching elapsed observations.
for cid in {x['case'] for x in rows}:
 cells=[x['result'] for x in rows if x['case']==cid];ref=cells[0];assert all((r['move'],r['score'],r['work'])==(ref['move'],ref['score'],ref['work']) for r in cells)
