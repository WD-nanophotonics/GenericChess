from pathlib import Path
import sys,sysconfig,os,subprocess,importlib.util,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent;src=ROOT/'generic_chess/_native';binary=OUT/('old_kernel/_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));binary.parent.mkdir(exist_ok=True)
spec=importlib.util.find_spec('ziglang');zig=Path(spec.origin).parent/'zig.exe'
cmd=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(OUT/'before-module.c' if x.name=='native_module.c' else OUT/'before-runtime.c' if x.name=='native_semantic_runtime.c' else x) for x in sorted(src.glob('*.c'))]+['-o',str(binary)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(OUT/'old-zig-cache')));assert built.returncode==0,built.stderr
spec=importlib.util.spec_from_file_location('old_test._native_core',binary);kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
import generic_chess.native as native
native._MODULE=kernel
import pytest,xml.etree.ElementTree as ET
with (OUT/'old-regression-private.log').open('w',encoding='utf-8') as f:
 from contextlib import redirect_stdout,redirect_stderr
 with redirect_stdout(f),redirect_stderr(f):code=pytest.main(['tests/product/test_native_semantic_probe_search.py::test_fixed_probe_selected_action_has_exact_root_value','-q','-p','no:cacheprovider','--basetemp',str(OUT/'pytest-old-regression'),'--junitxml',str(OUT/'old-regression-private.xml')])
s=ET.parse(OUT/'old-regression-private.xml').getroot();counts={k:sum(int(x.get(k,0)) for x in s.iter('testsuite')) for k in ('tests','failures','errors','skipped')};result=dict(exit_code=code,counts=counts,expectation='Both new actual selected-root-action regressions must fail original source; original source retained.');(OUT/'old-regression.json').write_text(json.dumps(result,indent=2)+'\n');print(result);assert counts==dict(tests=2,failures=2,errors=0,skipped=0)
