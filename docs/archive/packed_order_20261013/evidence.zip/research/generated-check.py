import sys,json,time,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.session.session import GameSession
from generic_chess.rules.serialization import serialize_ruleset
from scripts.full_q_refresh_comparison import compile_legacy_ruleset_for_semantic_execution,SearchMetadataAdapter
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import fixed_depth_search,public_action
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
OUT=Path(__file__).parent
write_record(OUT/'generated-declaration.json',dict(seeds=list(range(2026101311,2026101315)),board_size=4,root_plies=8,depth=3,root_seconds=120,batch_seconds=600,goal='Validate fixed-depth error/tie repair on four predeclared complete-history generated rules, independent Core exhaustive root values; exposed development not population/holdout. No rerun or extension of censored roots.'))
rows=[];samples=[];start=time.perf_counter()
for seed in range(2026101311,2026101315):
 config=GeneratorConfig(seed=seed,board_size=4,setup_preset='bilateral_random',allow_hybrid=True);g=generate_game(config);raw=compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);ss=GameSession(c);rng=random.Random(seed+9000)
 for _ in range(8):
  acts=sorted(ss.legal_actions(),key=repr)
  if not acts:break
  ss.submit(rng.choice(acts))
 sample=dict(seed=seed,config=record_value(config),rules=json.loads(serialize_ruleset(g.ruleset)),state=record_value(ss.state),history_witnesses=record_value(ss._search_witnesses));samples.append(sample);write_record(OUT/'generated-samples.json',samples)
 if ss.state.terminal_status.is_terminal:rows.append(dict(seed=seed,skipped='terminal after predeclared prefix'));write_record(OUT/'generated-root-audit.json',rows);continue
 r=compile_native_semantic_rules(c);position=pack_semantic_search_position(c,r,ss);profile=build_ruleset_profile(c,EvaluationConfig());bv=profile.board_value_by_type;hv=profile.hand_value_by_base_type
 t=time.perf_counter();visits=0;promotions=drops=0
 def exact(state,left):
  global visits,promotions,drops
  visits+=1
  if time.perf_counter()-t>120 or time.perf_counter()-start>600:raise TimeoutError('predeclared Core exhaustive fuse')
  term=state.terminal_status
  if term.is_terminal:return 0 if term.winner is None else 1000000 if term.winner==state.position.side_to_move else -1000000
  if left==0:
   side=state.position.side_to_move
   return sum((1 if x.owner==side else -1)*bv[x.current_type_id] for x in state.position.board if x)+sum((1 if i==side else -1)*hv[tid]*count for i,h in enumerate(state.position.hands) for tid,count in h.items())
  best=-1000000000
  for a in legal_actions(state,c):
   if getattr(a,'promotion_target_id',None) is not None:promotions+=1
   if not hasattr(a,'from_square'):drops+=1
   best=max(best,-exact(apply_action(state,a,c),left-1))
  return best
 try:
  values=[]
  for a in ss.legal_actions():values.append(dict(action=record_value(a),raw=pack_semantic_action(r,ss.state.position,a),value=-exact(apply_action(ss.state,a,c),2)))
  result=fixed_depth_search(r,position,3,board_values=bv,hand_values=hv);best=max(x['value'] for x in values);optimal=min(x['raw'] for x in values if x['value']==best)
  assert result['score']==best and result['best_action']==optimal,(seed,result,best,optimal)
  rows.append(dict(seed=seed,values=values,result=result,core_exhaustive_visits=visits,core_seconds=time.perf_counter()-t,observed_promotions=promotions,observed_drops=drops,history_length=len(ss.state.history),match=True))
 except TimeoutError as e:rows.append(dict(seed=seed,censored=str(e),core_exhaustive_visits=visits,seconds=time.perf_counter()-t))
 write_record(OUT/'generated-root-audit.json',rows);print(seed,rows[-1].get('match'),visits,round(time.perf_counter()-t,2),flush=True)
