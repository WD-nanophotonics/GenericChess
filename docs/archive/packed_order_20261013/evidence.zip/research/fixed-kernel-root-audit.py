from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import fixed_depth_search,guarded_actions,make_checked,public_action
OUT=Path(__file__).parent;rows=[]
# Predeclared all eight existing cases at D3; all legal root children D2.
for case in CASES:
 core=CoreBoard(case,compile_ruleset_for_execution(build_builtin_ruleset({'chess':'western_chess','shogi':'standard_shogi'}[case['game']])))
 board=NativeBoard(core,VALUES[case['game']]);v=board.values
 start=perf_counter();root=fixed_depth_search(board.native,board.position,3,board_values=v,hand_values=v)
 children=[]
 for label,raw in board.actions():
  child=make_checked(board.native,board.position,raw)
  found=fixed_depth_search(board.native,child,2,board_values=v,hand_values=v)
  children.append(dict(raw=raw,label=label,exact_score=-found['score'],nodes=found['nodes']))
 best=max(x['exact_score'] for x in children);optimal=[x for x in children if x['exact_score']==best]
 chosen=next((x for x in children if x['raw']==root['best_action']),None)
 row=dict(case=case,root=root,children=children,max_score=best,chosen=chosen,canonical=min(x['raw'] for x in optimal),selected_is_optimal=chosen is not None and chosen['exact_score']==best,seconds=perf_counter()-start)
 rows.append(row);(OUT/'fixed-kernel-root-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(case['id'],'score',root['score'],'max',best,'chosen',chosen,'optimal',row['selected_is_optimal'],flush=True)
