from pathlib import Path
import sys,json,time,importlib.metadata
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import guarded_actions,public_action
OUT=Path(__file__).parent;decl=json.loads((OUT/'declaration.json').read_text())
class PackedBoard(NativeBoard):
 def actions(self):return [(self.label(public_action(self.native,r)),r) for r in sorted(guarded_actions(self.native,self.position))]
rows=[]
for cid in decl['cases']:
 case=next(c for c in CASES if c['id']==cid)
 compiled=compile_ruleset_for_execution(build_builtin_ruleset({'chess':'western_chess','shogi':'standard_shogi'}[case['game']]))
 core=CoreBoard(case,compiled)
 def create(arm):
  if arm=='specialist_lexical':return ChessBoard(case) if case['game']=='chess' else ShogiBoard(case)
  return (NativeBoard if arm=='native_lexical' else PackedBoard)(core,VALUES[case['game']])
 for pair,order in enumerate(decl['orders']):
  for arm in order:
   b=create(arm);result=minimal_ab(b,decl['depth'],seconds=decl['seconds_per_call'],node_limit=decl['nodes_per_call'])
   rows.append(dict(case=cid,pair=pair,arm=arm,trace=False,result=result));(OUT/'fixed-depth.json').write_text(json.dumps(rows,indent=2)+'\n')
   print(cid,pair,arm,result['reason'],result['work']['nodes'],round(result['wall_seconds'],3),flush=True)
 for arm in decl['arms']:
  result=minimal_ab(create(arm),decl['depth'],seconds=decl['seconds_per_call'],node_limit=decl['nodes_per_call'],trace=True)
  rows.append(dict(case=cid,pair=None,arm=arm,trace=True,result=result));(OUT/'fixed-depth.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(cid,'trace',arm,result['reason'],result['work']['nodes'],round(result['wall_seconds'],3),flush=True)
(OUT/'versions.json').write_text(json.dumps({n:importlib.metadata.version(n) for n in ('python-chess','chess','cshogi')},indent=2))
