import importlib.util,pytest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import generic_chess.native as native
p=Path('.local_agent/packed-order-20261013/final_kernel/_native_core.cp312-win_amd64.pyd')
spec=importlib.util.spec_from_file_location('final_test._native_core',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
raise SystemExit(pytest.main(sys.argv[1:]))
