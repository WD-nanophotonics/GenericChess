from pathlib import Path
import sys,json,hashlib,time,importlib.metadata
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from scripts.native_backend_bridge import NativeBoard,audit_native_tree
from generic_chess.native.semantic import unpack_action
OUT=Path(__file__).parent
rows=[]
for case in CASES:
 c=CoreBoard(case,compile_ruleset_for_execution(build_builtin_ruleset({'chess':'western_chess','shogi':'standard_shogi'}[case['game']])))
 n=NativeBoard(c,VALUES[case['game']]);s=ChessBoard(case) if case['game']=='chess' else ShogiBoard(case)
 start=perf_counter();nodes=audit_pair(c,s,1);native_nodes=audit_native_tree(c,n,1)
 fronts=[]
 def walk(left,ply):
  if n.terminal(ply) is not None:return
  a=n.actions();b=s.actions();assert len({x[0] for x in a})==len(a)
  assert [x[0] for x in a]==[x[0] for x in b]
  packed=sorted(a,key=lambda x:x[1]);fronts.append(dict(ply=ply,count=len(a),same_order=a==packed,lexical=[x[0] for x in a],packed=[dict(label=l,raw=r,fields=unpack_action(r)) for l,r in packed]))
  if left:
   for (_,am),(_,bm) in zip(a,b):
    n.push(am);s.push(bm)
    try:walk(left-1,ply+1)
    finally:s.pop();n.pop()
 walk(1,0);assert n.restored() and s.restored()
 row=dict(case=case,core_specialist_states=nodes,core_native_states=native_nodes,history_length=len(c.witnesses),frontiers=fronts,audit_seconds=perf_counter()-start)
 rows.append(row);(OUT/'frontier-audit.json').write_text(json.dumps(dict(source='94aea9b3394ee6b416c1d840f24801a92e91f1a2',scope='existing eight exposed builtin cases; full children of each root; not complete generated domain',rows=rows),indent=2)+chr(10))
 print(case['id'],nodes,native_nodes,len(fronts),sum(not f['same_order'] for f in fronts),flush=True)
