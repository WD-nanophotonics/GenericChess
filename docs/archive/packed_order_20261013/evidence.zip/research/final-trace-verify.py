from pathlib import Path
import sys,sysconfig,os,subprocess,importlib.util,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
OUT=Path(__file__).parent;src=ROOT/'generic_chess/_native';mod=(src/'native_module.c').read_text()
start=mod.index('static GCSemanticProbeSearch gc_semantic_probe_negamax(');end=mod.index('static PyObject *gc_semantic_probe_search(',start);part=mod[start:end]
part=part.replace('    result.nodes = 1;', '    result.nodes = 1; gc_test_word(10);gc_test_word(depth);')
part=part.replace('        return result;\n    }\n    if (depth == 0) return result;', '        gc_test_word(11);gc_test_word((uint64_t)(int64_t)result.score);return result;\n    }\n    if (depth == 0) {gc_test_word(11);gc_test_word((uint64_t)(int64_t)result.score);return result;}')
part=part.replace('        GCSemanticProbeSearch branch = gc_semantic_probe_negamax', '        gc_test_word(12);gc_test_word(raw);\n        GCSemanticProbeSearch branch = gc_semantic_probe_negamax')
part=part.replace('        int score = -branch.score;', '        int score = -branch.score;gc_test_word(13);gc_test_word((uint64_t)(int64_t)score);')
helper=r"""
static uint64_t gc_test_trace=14695981039346656037ull,gc_test_words=0;
static void gc_test_word(uint64_t v){gc_test_words++;for(int i=0;i<8;i++){gc_test_trace^=v&255u;gc_test_trace*=1099511628211ull;v>>=8;}}
static PyObject *gc_test_trace_reset(PyObject*self,PyObject*args){(void)self;(void)args;gc_test_trace=14695981039346656037ull;gc_test_words=0;Py_RETURN_NONE;}
static PyObject *gc_test_trace_read(PyObject*self,PyObject*args){(void)self;(void)args;return Py_BuildValue("(KK)",gc_test_trace,gc_test_words);}
"""
mod=mod[:start]+helper+part+mod[end:]
needle='    {"semantic_make_checked", gc_semantic_make_checked, METH_VARARGS,'
mod=mod.replace(needle,'    {"test_trace_reset",gc_test_trace_reset,METH_NOARGS,"Private trace"},\n    {"test_trace_read",gc_test_trace_read,METH_NOARGS,"Private trace"},\n'+needle)
(OUT/'final-trace-native_module.c').write_text(mod)
spec=importlib.util.find_spec('ziglang');zig=Path(spec.origin).parent/'zig.exe';binary=OUT/('final_trace/_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
binary.parent.mkdir(exist_ok=True)
cmd=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(OUT/'final-trace-native_module.c' if x.name=='native_module.c' else x) for x in sorted(src.glob('*.c'))]+['-o',str(binary)]
built=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(OUT/'trace-zig-cache')));assert built.returncode==0,built.stderr
spec=importlib.util.spec_from_file_location('trace_test._native_core',binary);kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
import generic_chess.native as native
native._MODULE=kernel
# Use the same owned adapter definitions without rerunning timed experiments.
src_adapter=(OUT/'replay.py').read_text();exec(src_adapter[:src_adapter.index('rows=[];tables=[]')],globals())
def traced(b,depth,table):
 h=14695981039346656037;words=0;nodes=0
 def emit(v):
  nonlocal h,words
  words+=1;v&=(1<<64)-1
  for i in range(8):h=((h^(v&255))*1099511628211)&((1<<64)-1);v>>=8
 def visit(left,alpha,beta,ply):
  nonlocal nodes
  nodes+=1;emit(10);emit(left);t=b.terminal(ply)
  if t is not None or left==0:
   value=t if t is not None else b.evaluate();emit(11);emit(value);return value
  entry=table[tuple(b.path)];rawmap={x['label']:x['raw'] for x in entry};best=-2000000000
  for label,action in b.actions():
   emit(12);emit(rawmap[label]);b.push(action)
   try:score=-visit(left-1,-beta,-alpha,ply+1)
   finally:b.pop()
   emit(13);emit(score);best=max(best,score);alpha=max(alpha,best)
   if alpha>=beta:break
  return best
 score=visit(depth,-2000000000,2000000000,0);assert b.restored();return dict(hash=h,words=words,nodes=nodes,score=score)
rows=[]
for item in json.loads((OUT/'replay-tables.json').read_text()):
 case=item['case'];table={tuple(x['path']):x['actions'] for x in item['frontiers']};core=CoreBoard(case,compile_ruleset_for_execution(build_builtin_ruleset('western_chess')));n=NativeBoard(core,VALUES['chess'])
 kernel.test_trace_reset();r=fixed_depth_search(n.native,n.position,4,board_values=n.values,hand_values=n.values);digest,words=kernel.test_trace_read()
 observed=dict(hash=digest,words=words,nodes=r['nodes'],score=r['score'])
 reference=traced(Replay(ChessBoard(case),table),4,table);assert observed==reference,(case,observed,reference)
 rows.append(dict(case=case['id'],observed=observed,independent_specialist=reference,scope='Private instrumented binary trace only; timing uses clean production binary. FNV64+wordcount checks complete visited actions/leaves/window scores; not cryptographic identity proof.'))
 (OUT/'final-c-trace-verification.json').write_text(json.dumps(rows,indent=2)+'\n');print(case['id'],observed,flush=True)
