from pathlib import Path
import sys,json,importlib.util
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent
import generic_chess.native as native
sp=importlib.util.spec_from_file_location('final_generated._native_core',OUT/'final_kernel/_native_core.cp312-win_amd64.pyd');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m
from scripts.full_q_refresh_comparison import compile_legacy_ruleset_for_semantic_execution,SearchMetadataAdapter
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import fixed_depth_search
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import record_value,write_record
import random
old={x['seed']:x for x in json.loads((OUT/'generated-root-audit.json').read_text())};rows=[]
for sample in json.loads((OUT/'generated-samples.json').read_text()):
 seed=sample['seed'];raw=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(sample['rules']));c=SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);ss=GameSession(c);rng=random.Random(seed+9000)
 for _ in range(8):
  a=sorted(ss.legal_actions(),key=repr)
  if not a:break
  ss.submit(rng.choice(a))
 assert record_value(ss.state)==sample['state'] and record_value(ss._search_witnesses)==sample['history_witnesses']
 if 'skipped' in old[seed]:assert ss.state.terminal_status.is_terminal;rows.append(dict(seed=seed,skipped='same predeclared terminal root'));continue
 r=compile_native_semantic_rules(c);pos=pack_semantic_search_position(c,r,ss);profile=build_ruleset_profile(c,EvaluationConfig());res=fixed_depth_search(r,pos,3,board_values=profile.board_value_by_type,hand_values=profile.hand_value_by_base_type);assert record_value(res)==old[seed]['result'];rows.append(dict(seed=seed,match_existing_independent_core_oracle=True,result=res,history_length=len(ss.state.history)))
write_record(OUT/'final-generated-verification.json',rows);print(rows)
