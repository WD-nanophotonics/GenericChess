from pathlib import Path
import sys,sysconfig,os,subprocess,importlib.util,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));OUT=Path(__file__).parent;src=ROOT/'generic_chess/_native'
spec=importlib.util.find_spec('ziglang');zig=Path(spec.origin).parent/'zig.exe';modules={}
for arm,file in [('direct_child','direct-child-module.c'),('leaf_eval','leaf-eval-module.c')]:
 binary=OUT/(arm+'/_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));binary.parent.mkdir(exist_ok=True)
 cmd=[str(zig),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(src),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(OUT/file if x.name=='native_module.c' else OUT/'trusted-status-runtime.c' if x.name=='native_semantic_runtime.c' and arm=='trusted_status_sorted' else x) for x in sorted(src.glob('*.c'))]+['-o',str(binary)];built=subprocess.run(cmd,capture_output=True,text=True,timeout=180,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(OUT/(arm+'-zig-cache'))));assert built.returncode==0,built.stderr
 spec=importlib.util.spec_from_file_location(arm+'._native_core',binary);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);modules[arm]=m
import generic_chess.native as native
from scripts.search_backend_comparison import *
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import fixed_depth_search,snapshot
rows=[]
for case in [c for c in CASES if c['game']=='chess']:
 core=CoreBoard(case,compile_ruleset_for_execution(build_builtin_ruleset('western_chess')))
 for pair,order in enumerate([['direct_child','leaf_eval'],['leaf_eval','direct_child']]):
  for arm in order:
   native._MODULE=modules[arm];b=NativeBoard(core,VALUES['chess']);before=snapshot(b.native,b.position);t=perf_counter();r=fixed_depth_search(b.native,b.position,4,board_values=b.values,hand_values=b.values);elapsed=perf_counter()-t;assert before==snapshot(b.native,b.position);rows.append(dict(case=case['id'],pair=pair,arm=arm,result=r,seconds=elapsed,parent_restored=True));(OUT/'leaf-eval-timing.json').write_text(json.dumps(rows,indent=2)+'\n');print(case['id'],pair,arm,round(elapsed,4),flush=True)
for cid in {x['case'] for x in rows}:
 rr=[x['result'] for x in rows if x['case']==cid];assert all(r==rr[0] for r in rr)
