from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import fixed_depth_search,make_checked
OUT=Path(__file__).parent;rows=[]
for case in CASES:
 if case['game']!='chess':continue
 compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
 core=CoreBoard(case,compiled);n=NativeBoard(core,VALUES['chess']);s=ChessBoard(case)
 def exact(left,ply):
  t=s.terminal(ply)
  if t is not None:return 0 if t==0 else (1000000 if t>0 else -1000000)
  if left==0:return s.evaluate()
  best=-1000000000
  for label,m in s.actions():
   s.push(m)
   try:v=-exact(left-1,ply+1)
   finally:s.pop()
   best=max(best,v)
  return best
 expected={}
 for label,m in s.actions():
  s.push(m)
  try:expected[label]=-exact(2,1)
  finally:s.pop()
 observed=fixed_depth_search(n.native,n.position,3,board_values=n.values,hand_values=n.values)
 children=[]
 for label,raw in n.actions():
  result=fixed_depth_search(n.native,make_checked(n.native,n.position,raw),2,board_values=n.values,hand_values=n.values)
  assert -result['score']==expected[label],(case['id'],label,result['score'],expected[label])
  children.append(dict(label=label,raw=raw,value=expected[label]))
 best=max(expected.values());canonical=min(x['raw'] for x in children if x['value']==best)
 assert observed['score']==best and observed['best_action']==canonical
 rows.append(dict(case=case,root=observed,children=children,reference='python-chess exhaustive full D3 tree with project draw policy, constant +/-1M mate matching fixed API; no alpha-beta, TT or q',restored=n.restored() and s.restored()))
 (OUT/'independent-root-values.json').write_text(json.dumps(rows,indent=2)+'\n');print(case['id'],len(children),'all child values and canonical argmax agree',flush=True)
