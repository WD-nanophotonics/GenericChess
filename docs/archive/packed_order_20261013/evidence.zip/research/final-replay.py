from pathlib import Path
import sys,json,time,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import *
from scripts.native_backend_bridge import NativeBoard
from generic_chess.native.semantic import fixed_depth_search,public_action
OUT=Path(__file__).parent
class Packed(NativeBoard):
 def actions(self):return sorted(super().actions(),key=lambda x:x[1])
 def terminal(self,ply):
  t=super().terminal(ply)
  return None if t is None else 0 if t==0 else (1000000 if t>0 else -1000000)
class Collector(Packed):
 def __init__(self,core,case):
  super().__init__(core,VALUES[case['game']]);self.other=ChessBoard(case);self.path=[];self.table={};self.push_labels={};self.checked=0
 def terminal(self,ply):
  self.checked+=1;t=super().terminal(ply);u=self.other.terminal(ply);u=None if u is None else 0 if u==0 else (1000000 if u>0 else -1000000)
  assert t==u,(self.path,t,u);return t
 def evaluate(self):
  v=super().evaluate();assert v==self.other.evaluate();return v
 def actions(self):
  a=super().actions();b=self.other.actions();assert sorted(l for l,_ in a)==[l for l,_ in b]
  entry=[dict(label=l,raw=r) for l,r in a];key=tuple(self.path)
  assert key not in self.table or self.table[key]==entry
  self.table[key]=entry;self.push_labels.update({r:l for l,r in a});return a
 def push(self,raw):
  label=self.push_labels[raw];super().push(raw);self.other.board.push_uci(label);self.path.append(label)
 def pop(self):self.path.pop();self.other.pop();super().pop()
 def restored(self):return super().restored() and self.other.restored() and not self.path
class Replay:
 def __init__(self,inner,table):self.inner=inner;self.table=table;self.path=[];self.label_stack=[];self.action_labels={};self.projection_seconds=0;self.lookups=0
 def actions(self):
  a=self.inner.actions();t=perf_counter();entry=self.table[tuple(self.path)];d=dict(a);assert set(d)=={x['label'] for x in entry}
  out=[(x['label'],d[x['label']]) for x in entry];self.action_labels[tuple(self.path)]={m:l for l,m in out};self.lookups+=1;self.projection_seconds+=perf_counter()-t;return out
 def push(self,action):
  label=self.action_labels[tuple(self.path)][action];self.inner.push(action);self.path.append(label)
 def pop(self):self.path.pop();self.inner.pop()
 def terminal(self,ply):
  t=self.inner.terminal(ply);return None if t is None else 0 if t==0 else (1000000 if t>0 else -1000000)
 def evaluate(self):return self.inner.evaluate()
 def restored(self):return self.inner.restored() and not self.path
rows=[];tables=[]
# Final clean production-source kernel without overwriting the running cap assay DLL.
import importlib.util
import generic_chess.native as native
sp=importlib.util.spec_from_file_location('final_replay._native_core',OUT/'final_kernel/_native_core.cp312-win_amd64.pyd');mm=importlib.util.module_from_spec(sp);sp.loader.exec_module(mm);native._MODULE=mm
for case in [c for c in CASES if c['game']=='chess']:
 compiled=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));core=CoreBoard(case,compiled)
 c=Collector(core,case);t=perf_counter();reference=minimal_ab(c,4,seconds=60,node_limit=1000000,trace=True)
 assert reference['reason']=='completed_depth'
 tables.append(dict(case=case,frontiers=[dict(path=list(k),actions=v) for k,v in c.table.items()],reference=reference,checked=c.checked,construction_seconds=perf_counter()-t));(OUT/'final-replay-tables.json').write_text(json.dumps(tables,indent=2)+'\n')
 for pair,order in enumerate([['native','specialist','c_fixed'],['c_fixed','specialist','native']]):
  for arm in order:
   if arm=='c_fixed':
    b=NativeBoard(core,VALUES['chess']);t=perf_counter();r=fixed_depth_search(b.native,b.position,4,board_values=b.values,hand_values=b.values);r['wall_seconds']=perf_counter()-t
    assert r['nodes']==reference['work']['nodes'] and r['score']==reference['score'];label=b.label(public_action(b.native,r['best_action']));assert label==reference['move'];r['move']=label
   else:
    inner=NativeBoard(core,VALUES['chess']) if arm=='native' else ChessBoard(case);b=Replay(inner,c.table);r=minimal_ab(b,4,seconds=60,node_limit=1000000,trace=False);assert (r['move'],r['score'],r['work'])==(reference['move'],reference['score'],reference['work']);r['order_table_projection_seconds']=b.projection_seconds;r['order_table_lookups']=b.lookups
   rows.append(dict(case=case['id'],pair=pair,arm=arm,result=r));(OUT/'final-replay-timing.json').write_text(json.dumps(rows,indent=2)+'\n');print(case['id'],pair,arm,r.get('nodes',r.get('work',{}).get('nodes')),round(r['wall_seconds'],4),flush=True)
 for arm in ('native','specialist'):
  b=Replay(NativeBoard(core,VALUES['chess']) if arm=='native' else ChessBoard(case),c.table);r=minimal_ab(b,4,seconds=60,node_limit=1000000,trace=True);assert r['trace_sha256']==reference['trace_sha256'];rows.append(dict(case=case['id'],pair=None,arm=arm,trace=True,result=r));(OUT/'final-replay-timing.json').write_text(json.dumps(rows,indent=2)+'\n')
