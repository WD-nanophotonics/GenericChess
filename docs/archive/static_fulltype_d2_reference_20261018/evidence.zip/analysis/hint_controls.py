"""Existing root_order_hint selected-PV stress control; no new policy."""
from pathlib import Path
from copy import copy
import json,sys,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
D=R/'.local_agent/static-fulltype-d2-reference-20261018';I=R/'.local_agent/playability-filter-20261018';U=R/'.local_agent/filter-search-inputs-20261018';p=json.loads((D/'hint-control-plan.json').read_bytes());gs={g['key']:g for g in map(json.loads,(I/'generations.jsonl').read_bytes().splitlines())};pts={(v['slot'],v['filter'],v['target_prefix']):v for v in map(json.loads,(I/'points.jsonl').read_bytes().splitlines())};refs={(v['slot'],v['filter'],v['prefix']):v for v in map(json.loads,(D/'roots.jsonl').read_bytes().splitlines())};old={(v['slot'],v['filter'],v['prefix']):v for v in map(json.loads,(U/'queries.jsonl').read_bytes().splitlines())};began=time.perf_counter();rows=[];queries=0
assert not(D/'hint-control-result.json').exists()
for item in p['selected']:
 assert time.perf_counter()-began<120
 for name in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 key=item['slot'],item['filter'],item['prefix'];g=gs[item['key']];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']));s=GameSession.replay(c,deserialize_game_record(json.dumps(pts[key]['record'])));assert s.state.position.side_to_move==0;n=compile_native_semantic_rules(c);weights={t.type_id:0. if t.is_anchor else 1. for t in c.piece_types};cp=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='unfitted-complete-type-Unit-input-diagnostic',board_weights=weights,hand_weights=weights,material_scale=256,value_scale=10.,reference_median=1.);assert cp.checkpoint_id==old[key]['checkpoint_id'];aa=sorted(s.legal_actions(),key=repr);trials=[]
 for label,hint in [('none',None),('first',aa[item['first_optimal_index']]),('last',aa[item['last_optimal_index']])]:
  engine=SemanticSearchEngine(c,n,checkpoint=cp,tt_megabytes=0);r=engine.search(s,SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=.5,quiescence_max_depth=0),root_order_hint=hint,root_window_pruning=False);queries+=1;assert r.completed_depth==2 and not r.used_fallback;idx=aa.index(r.action);assert idx in refs[key]['optimal_indices'][2]and r.score==refs[key]['best_values'][2];leaf=copy(s)
  for a in r.decision_line:leaf.submit(a)
  types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);phi=[sum((1 if x.owner==0 else-1)for x in leaf.state.position.board if x and x.current_type_id==t)for t in types]+[leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t)for t in types];terminal=leaf.result.status.value!='ongoing';nonzero=not terminal and any(phi)
  if hint is not None:assert r.root_hint_legal and r.root_hint_apply_count>0
  trials.append(dict(mode=label,hint=record_value(hint),reported_hint_legal=r.root_hint_legal,hint_apply_count=r.root_hint_apply_count,action=record_value(r.action),PV=record_value(r.decision_line),score=r.score,completed_depth=r.completed_depth,nodes=r.nodes,leaf_phi=phi,terminal_leaf=terminal,own_gradient_nonzero=nonzero))
 rows.append(dict(**item,trials=trials,action_changed=any(t['action']!=trials[0]['action']for t in trials[1:]),PV_changed=any(t['PV']!=trials[0]['PV']for t in trials[1:]),leaf_phi_changed=any(t['leaf_phi']!=trials[0]['leaf_phi']for t in trials[1:]),own_gradient_availability_changed=any(t['own_gradient_nonzero']!=trials[0]['own_gradient_nonzero']for t in trials[1:])))
assert queries==27;result=dict(status='PASS_EXISTING_HINT_STRESS_CONTROL',queries=queries,contexts=len(rows),contexts_action_changed=sum(r['action_changed']for r in rows),contexts_PV_changed=sum(r['PV_changed']for r in rows),contexts_leaf_phi_changed=sum(r['leaf_phi_changed']for r in rows),contexts_availability_changed=sum(r['own_gradient_availability_changed']for r in rows),rows=rows,seconds=time.perf_counter()-began,scope='POSTHOC9tiedfullcontextstresscases/27newNativequeries, freshengineTT0D2, allreferenceintegeroptimal andactualPVCorelegal. No claimallhints/fullsearchstability/policyutility/traininggain. Envelopes donotimplyactualalgorithmnondeterminism; no API/default/tiepolicychange.');write_json(D/'hint-control-result.json',result);print('HINT_CONTROL',queries,[(k,result[k])for k in ['contexts_action_changed','contexts_PV_changed','contexts_leaf_phi_changed','contexts_availability_changed']],flush=True)
