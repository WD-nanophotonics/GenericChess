"""Bind original Native receipts to independently rebuilt action/value arrays."""
from pathlib import Path
from collections import Counter
import sys,json
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/static-fulltype-d2-reference-20261018';S=R/'.local_agent/static-input-objective-20261018';U=R/'.local_agent/filter-search-inputs-20261018';I=R/'.local_agent/playability-filter-20261018';sq={(q['slot'],q['filter'],q['prefix']):q for q in map(json.loads,(S/'queries.jsonl').read_bytes().splitlines())};uq={(q['slot'],q['filter'],q['prefix']):q for q in map(json.loads,(U/'queries.jsonl').read_bytes().splitlines())};pts={(p['slot'],p['filter'],p['target_prefix']):p for p in map(json.loads,(I/'points.jsonl').read_bytes().splitlines())};counts=Counter();defects=[]
for line in(D/'roots.jsonl').open(encoding='utf8'):
 r=json.loads(line);key=r['slot'],r['filter'],r['prefix'];point=pts[key]
 for model,queries,j,field in [('static',sq,1,'static_chosen_index'),('Unit',uq,2,'unit_chosen_index')]:
  q=queries[key];assert q['root_state_sha256']==point['root_state_sha256'];counts[model+'_bound_roots']+=1
  if r['status']=='TERMINAL_ROOT':assert q['status']=='TERMINAL_ROOT';continue
  if r['status']!='COMPLETE_ROOT':continue
  assert q['status']=='USABLE_NATIVE_RETURN'and q['completed_depth']==2 and not q['used_fallback'];idx=r['root_actions'].index(q['chosen_action']);assert idx==r[field]
  expected=r['best_values'][j];score_ok=q['score']==expected;action_ok=idx in r['optimal_indices'][j]
  if not score_ok or not action_ok:defects.append(dict(slot=key[0],filter=key[1],prefix=key[2],model=model,score=q['score'],expected=expected,action_optimal=action_ok))
  counts[model+'_complete_D2_bindings']+=1;counts[model+'_score_mismatches']+=not score_ok;counts[model+'_nonoptimal_actions']+=not action_ok
write_json(D/'native-receipt-binding.json',dict(status='PASS_ALL_EXECUTED_NATIVE_RECEIPT_BINDINGS'if not defects else'ACTUAL_MISMATCHES',counts=dict(counts),defects=defects,scope='EachreturnedcompleteRoot Nativeaction/index/rootstateID/depth/fallback/score boundtoindependentlycheckedarrays, bothstaticandUnit. Owners0 fullrecordscope validatedinCore reader; noNativequeryrerun, no cached/generalPV/WDLclaim.'));assert not defects;print('NATIVE_BINDING_PASS',dict(counts),flush=True)
