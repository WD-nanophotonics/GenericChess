"""Reconstruct preserved scale-control arithmetic from sealed complete frontiers."""
from pathlib import Path
import json,gzip,sys
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/static-fulltype-d2-reference-20261018';controls=json.loads((D/'scale-control-result.json').read_bytes());by={(x['slot'],x['filter'],x['prefix']):x for x in controls['rows']};found=[]
with gzip.open(D/'frontiers.jsonl.gz','rt',encoding='utf8')as ff,(D/'roots.jsonl').open(encoding='utf8')as rr:
 for line in rr:
  r=json.loads(line);f=json.loads(next(ff));key=r['slot'],r['filter'],r['prefix']
  if key not in by:continue
  x=by[key];assert x['root_actions']==r['root_actions'];av=[];maxordinary=0
  for terminal,branch in f['forest']:
   if terminal:
    flag,z,v=branch;assert flag;value=z*(100000000-1)
   else:
    values=[]
    for flag,z,v in branch:
     if flag:value=z*(100000000-2)
     else:value=sum(a*b for a,b in zip(v,f['raw']));maxordinary=max(maxordinary,abs(value))
     values.append(value)
    value=min(values)
   av.append(value)
  best=max(av);opts=[i for i,v in enumerate(av)if v==best];assert opts==r['optimal_indices'][0]==x['optimal_indices'][2];assert maxordinary<90000000
  for q in x['controls']:
   idx=r['root_actions'].index(q['action']);j=1 if q['scale']==256 else 0;assert idx in r['optimal_indices'][j];assert q['integer_score']==(r['best_values'][1]if q['scale']==256 else best)
  found.append(dict(slot=key[0],filter=key[1],prefix=key[2],scale1000_best=best,max_abs_ordinary1000=maxordinary,controls_mathematically_consistent=True))
assert len(found)==2;write_json(D/'scale-frontier-check.json',dict(status='PASS_PRESERVED_FOUR_NATIVE_CONTROL_RECORDS_FRONTIER_ARITHMETIC',rows=found,Native_queries_rerun=0,scope='Checksrecordedcontrolactions/score againstallsealedleaves/objectives, notnewNative execution/binaryidentity ornewdefault. Material-onlyscale1000 andactualterminalbands/ordinarybounds; owners0.'));print('SCALE_FRONTIER_CHECK',len(found),flush=True)
