"""Complete registered D2 reference statistics; capped/unstarted roots stay UNKNOWN."""
from pathlib import Path
from collections import Counter,defaultdict
import json,sys,statistics,hashlib
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/static-fulltype-d2-reference-20261018';I=R/'.local_agent/playability-filter-20261018';done=json.loads((D/'result.json').read_bytes());assert done['status']in('COMPLETE','PARTIAL_LIMIT','ERROR');pts={(p['slot'],p['filter'],p['target_prefix']):p for p in map(json.loads,(I/'points.jsonl').read_bytes().splitlines())};rows=[json.loads(l)for l in(D/'roots.jsonl').read_bytes().splitlines()];seen=set();groups=defaultdict(Counter);regrets=[];witnesses=[];tot=Counter();contexts=set();regret_contexts=set()
for r in rows:
 key=r['slot'],r['filter'],r['prefix'];assert key not in seen;seen.add(key);p=pts[key];g=groups[p['size'],p['setup'],p['symmetry'],p['target_prefix'],p['filter']];g['returned']+=1;g[r['status']]+=1;tot[r['status']]+=1
 context=hashlib.sha256(json.dumps([r['ruleset_fingerprint'],p['record'],r.get('checkpoint_id')],sort_keys=True,separators=(',',':')).encode()).hexdigest();contexts.add(context)
 if r['status']!='COMPLETE_ROOT':continue
 for dest,flag in [('static_integer_nonoptimal',not r['static_integer_optimal']),('Unit_integer_nonoptimal',not r['unit_integer_optimal']),('static_integer_score_mismatch',not r['static_integer_score_equal']),('Unit_integer_score_mismatch',not r['Unit_integer_score_equal']),('static_exact_regret',r['static_exact_regret']>0),('quantized_optimalsets_differ',not r['exact_vs_quant_sets_equal']),('quantized_exactsets_disjoint',r['exact_vs_quant_sets_disjoint']),('static_Unit_exactsets_disjoint',r['static_vs_Unit_sets_disjoint'])]:g[dest]+=flag;tot[dest]+=flag
 if r['static_exact_regret']>0:
  regrets.append(r['static_exact_regret']/256000.);regret_contexts.add(context)
  if len(witnesses)<16:witnesses.append(dict(slot=r['slot'],filter=r['filter'],prefix=r['prefix'],key=r['key'],regret_numerator=r['static_exact_regret'],regret_material_units=r['static_exact_regret']/256000.,exact_quant_disjoint=r['exact_vs_quant_sets_disjoint']))
for key,p in pts.items():
 if key not in seen:groups[p['size'],p['setup'],p['symmetry'],p['target_prefix'],p['filter']]['UNRECORDED_UNKNOWN']+=1;tot['UNRECORDED_UNKNOWN']+=1
assert len(seen)==done['returned_points'];assert len(pts)==4599
summary=dict(status='DERIVED_EXECUTED_ROOTS_ONLY',producer_status=done['status'],counts=dict(tot),distinct_exact_returned_rule_record_checkpoint_contexts=len(contexts),distinct_positive_regret_contexts=len(regret_contexts),observations_are_not_unique_or_independent=True,rows=[dict(size=k[0],setup=k[1],symmetry=k[2],prefix=k[3],filter=k[4],counts=dict(v))for k,v in sorted(groups.items())],positive_regret=dict(n=len(regrets),max=max(regrets,default=0),median=statistics.median(regrets)if regrets else None),first16_regret_witnesses=witnesses,scope='Integer/rational fullD2preferences only atCOMPLETEexecutedroots. Nonzeroexactregret isquantizedchoice effect, notWDL/utility/trainingharm. Allcapped/unstarted remainUNKNOWN;3generationfailurepairs notsuccess. Denominators andregimes explicit; no populationestimate.');write_json(D/'analysis.json',summary);print('REFERENCE_ANALYSIS',dict(tot),summary['positive_regret'],flush=True)
