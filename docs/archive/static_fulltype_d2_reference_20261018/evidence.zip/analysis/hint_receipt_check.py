"""Pure-Core replay and binding of preserved hint controls, no Native query."""
from pathlib import Path
from collections import Counter
from copy import copy
import sys,json
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=R/'.local_agent/static-fulltype-d2-reference-20261018';I=R/'.local_agent/playability-filter-20261018';g={x['key']:x for x in map(json.loads,(I/'generations.jsonl').read_bytes().splitlines())};pts={(x['slot'],x['filter'],x['target_prefix']):x for x in map(json.loads,(I/'points.jsonl').read_bytes().splitlines())};refs={(x['slot'],x['filter'],x['prefix']):x for x in map(json.loads,(D/'roots.jsonl').read_bytes().splitlines())};p=json.loads((D/'hint-control-plan.json').read_bytes());res=json.loads((D/'hint-control-result.json').read_bytes());counts=Counter()
def decode(raw):
 d=dict(raw);d['to_square']=Square(**d['to_square'])
 if 'from_square'in d:d['from_square']=Square(**d['from_square']);return SemanticBoardMove(**d)
 return SemanticDropMove(**d)
for entry in res['rows']:
 key=entry['slot'],entry['filter'],entry['prefix'];plan=next(x for x in p['selected']if(x['slot'],x['filter'],x['prefix'])==key);c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g[entry['key']]['rules']));base=GameSession.replay(c,deserialize_game_record(json.dumps(pts[key]['record'])));assert base.state.position.side_to_move==0;ref=refs[key];types=sorted(t.type_id for t in c.piece_types if not t.is_anchor)
 for trial in entry['trials']:
  assert trial['completed_depth']==2 and trial['score']==ref['best_values'][2];idx=ref['root_actions'].index(trial['action']);assert idx in ref['optimal_indices'][2]
  if trial['mode']=='none':assert trial['hint']is None
  else:
   assert trial['hint']==ref['root_actions'][plan['first_optimal_index'if trial['mode']=='first'else'last_optimal_index']];assert trial['reported_hint_legal']and trial['hint_apply_count']>0
  s=copy(base)
  for a in trial['PV']:s.submit(decode(a));counts['Core_PV_edges']+=1
  term=s.result.status.value!='ongoing';v=[sum((1 if pc.owner==0 else-1)for pc in s.state.position.board if pc and pc.current_type_id==t)for t in types]+[s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t)for t in types];assert term==trial['terminal_leaf']and v==trial['leaf_phi'];assert trial['own_gradient_nonzero']==(not term and any(v));counts['preserved_query_records']+=1
 for field,record in [('action','action_changed'),('PV','PV_changed'),('leaf_phi','leaf_phi_changed'),('own_gradient_nonzero','own_gradient_availability_changed')]:assert entry[record]==any(x[field]!=entry['trials'][0][field]for x in entry['trials'][1:])
 counts['full_contexts']+=1
assert counts['full_contexts']==9 and counts['preserved_query_records']==27;write_json(D/'hint-control-check.json',dict(status='PASS_PRESERVED_HINT_RECORDS_CORE_REPLAY_AND_BINDING',counts=dict(counts),new_Native_queries=0,scope='Recorded27hint trials CorePV/feature/action/score/planbinding, notnewNativehintapplication orall-contextstability proof. Actualhint applycounts are preservedbackendreports.'));print('HINT_RECORDS_CHECK',dict(counts),flush=True)
