"""Full Core D2 static-precision reference; no Native, training or generation."""
from pathlib import Path
from collections import Counter
from copy import copy
import sys,json,time,hashlib,gzip,traceback
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=R/'.local_agent/static-fulltype-d2-reference-20261018';S=R/'.local_agent/static-input-objective-20261018';I=R/'.local_agent/playability-filter-20261018';U=R/'.local_agent/filter-search-inputs-20261018';P=json.loads((D/'plan.json').read_bytes());began=time.perf_counter();counts=Counter();rows=[];status='COMPLETE';why=None;cache={};active=None;c=None;own_edges=0
assert not(D/'started.json').exists();write_json(D/'started.json',dict(plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
gens={g['key']:g for g in map(json.loads,(I/'generations.jsonl').read_bytes().splitlines())};pts={(p['slot'],p['filter'],p['target_prefix']):p for p in map(json.loads,(I/'points.jsonl').read_bytes().splitlines())};queries={(q['slot'],q['filter'],q['prefix']):q for q in map(json.loads,(S/'queries.jsonl').read_bytes().splitlines())};uq={(q['slot'],q['filter'],q['prefix']):q for q in map(json.loads,(U/'queries.jsonl').read_bytes().splitlines())};coverage={x['key']:x for x in json.loads((S/'coverage-result.json').read_bytes())['rows']};models={x['key']:x['checkpoint']for x in json.loads((S/'static-models.json').read_bytes())['rows']}
class RootCap(Exception):pass

def poll():
 if time.perf_counter()-began>P['limits']['global_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 if counts['Core_edges']>=P['limits']['max_total_core_edges']:raise TimeoutError('FROZEN_EDGE_CAP')
 for name in ('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/(name+'.json')).read_bytes());
  if z.get('stopped')or z.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')

def submit(s,a):
 global own_edges
 if own_edges>=P['limits']['max_per_root_edges']:raise RootCap('PER_ROOT_EDGE_CAP')
 if counts['Core_edges']%128==0:poll()
 ch=copy(s);ch.submit(a);own_edges+=1;counts['Core_edges']+=1;return ch

def leaf(s,distance):
 b=Counter()
 for pc in s.state.position.board:
  if pc is not None:b['board',pc.current_type_id]+=1 if pc.owner==0 else-1
 v=[b[k,t]if k=='board'else s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t)for k,t in channels];end=s.result.status.value!='ongoing'
 if end:
  assert s.result.declaration_outcome not in('NO_CONTEST','RESTART');z=0 if s.result.winner is None else 1 if s.result.winner==0 else-1;value=z*(100000000-distance);vals=(value*1000,value,value);record=[1,z,v]
 else:
  vals=(sum(x*w for x,w in zip(v,raw))*256,sum(x*w for x,w in zip(v,quant)),sum(v)*256);record=[0,0,v]
 counts['evaluated_leaves']+=1;return vals,record

def decode(a):
 from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
 from generic_chess.core.coordinates import Square
 d=dict(a);d['to_square']=Square(**d['to_square'])
 if 'from_square'in d:d['from_square']=Square(**d['from_square']);return SemanticBoardMove(**d)
 return SemanticDropMove(**d)
try:
 with gzip.open(D/'frontiers.jsonl.gz','xt',encoding='utf8',compresslevel=6)as front,(D/'roots.jsonl').open('x',encoding='utf8')as log:
  for pair_index,(slot,prefix)in enumerate(P['schedule']):
   for filtered in ((False,True)if pair_index%2==0 else(True,False)):
    poll();key=(slot,filtered,prefix);point=pts.get(key)
    if point is None:counts['unavailable_generation_points']+=1;continue
    tick=time.perf_counter();q=queries[key];unit=uq[key];g=gens[point['key']];cp=models[point['key']];meta=coverage[point['key']];fp=meta['ruleset_fingerprint']
    if fp not in cache:
     cache[fp]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))
    c=cache[fp];s=GameSession.replay(c,deserialize_game_record(json.dumps(point['record'])));types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);channels=[(kind,t)for kind in('board','hand')for t in types];raw=[meta['profile_board_values'if k=='board'else'profile_hand_values'][t]for k,t in channels];quant=[round(cp['board_weights'if k=='board'else'hand_weights'][t]*256)for k,t in channels];own_edges=0;row=dict(slot=slot,filter=filtered,prefix=prefix,key=point['key'],ruleset_fingerprint=fp,channels=channels,checkpoint_id=q['checkpoint_id'],status='TERMINAL_ROOT',Core_edges=0);forest=[];actionvals=[]
    if s.result.status.value=='ongoing':
     aa=sorted(s.legal_actions(),key=repr);side=s.state.position.side_to_move;assert aa
     try:
      for a in aa:
       child=submit(s,a)
       if child.result.status.value!='ongoing':vv,rec=leaf(child,1);forest.append([1,rec]);actionvals.append(vv)
       else:
        bb=sorted(child.legal_actions(),key=repr);assert bb;replyvals=[];fr=[]
        for b in bb:v,rec=leaf(submit(child,b),2);replyvals.append(v);fr.append(rec)
        backup=max if child.state.position.side_to_move==0 else min;vv=tuple(backup(v[j]for v in replyvals)for j in range(3));forest.append([0,fr]);actionvals.append(vv)
      backup=max if side==0 else min;best=[backup(v[j]for v in actionvals)for j in range(3)];opts=[[i for i,v in enumerate(actionvals)if v[j]==best[j]]for j in range(3)];si=aa.index(decode(q['chosen_action']));ui=aa.index(decode(unit['chosen_action']));row.update(status='COMPLETE_ROOT',root_actions=record_value(aa),action_values=actionvals,best_values=best,optimal_indices=opts,static_chosen_index=si,unit_chosen_index=ui,static_integer_optimal=si in opts[1],static_exact_optimal=si in opts[0],unit_integer_optimal=ui in opts[2],static_exact_regret=(best[0]-actionvals[si][0])*(1 if side==0 else-1),static_integer_score_equal=q['score']*(1 if side==0 else-1)==best[1],Unit_integer_score_equal=unit['score']*(1 if side==0 else-1)==best[2],exact_vs_quant_sets_equal=opts[0]==opts[1],exact_vs_quant_sets_disjoint=not set(opts[0])&set(opts[1]),static_vs_Unit_sets_disjoint=not set(opts[0])&set(opts[2]))
     except RootCap as exc:row.update(status='UNKNOWN_ROOT_CAP',reason=str(exc));forest=[]
    row.update(Core_edges=own_edges,seconds=time.perf_counter()-tick);front.write(json.dumps(dict(slot=slot,filter=filtered,prefix=prefix,channels=channels,raw=raw,quant=quant,status=row['status'],forest=forest),separators=(',',':'))+'\n');log.write(json.dumps(row,separators=(',',':'))+'\n');front.flush();log.flush();rows.append(row);counts[row['status']]+=1
    if len(rows)%64==0:print('REFERENCED',len(rows),'edges',counts['Core_edges'],'sec',round(time.perf_counter()-began,2),flush=True)
    if (D/'frontiers.jsonl.gz').stat().st_size>P['limits']['max_compressed_bytes']:raise TimeoutError('FROZEN_OUTPUT_CAP')
except BaseException as exc:status='PARTIAL_LIMIT'if isinstance(exc,(TimeoutError,InterruptedError))else'ERROR';why=repr(exc);traceback.print_exc()
result=dict(status=status,reason=why,planned_saved_points=4599,returned_points=len(rows),unstarted_saved_points=4599-len(rows),counts=dict(counts),seconds=time.perf_counter()-began,scope='ExecutedcompleteCoreD2trees only; capped/unstartedUNKNOWN,3generationrefusalsunavailable. Threeexactarithmeticobjectives/fullrootoptimalsets, Nativequeriesnotrerun. NoWDL/traininggain/externalrulesauthority/populationclaim.');write_json(D/'result.json',result);print('REFERENCE_CLOSED',json.dumps(result),flush=True)
