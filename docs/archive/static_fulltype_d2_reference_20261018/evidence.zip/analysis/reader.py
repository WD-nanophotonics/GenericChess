"""Independent frontier arithmetic plus full-root and bounded Core path controls."""
from pathlib import Path
from collections import Counter
from copy import copy
import json,sys,time,gzip,os,hashlib
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
D=R/'.local_agent/static-fulltype-d2-reference-20261018';S=R/'.local_agent/static-input-objective-20261018';I=R/'.local_agent/playability-filter-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',str(R)));began=time.perf_counter();counts=Counter();cache={};full_witnesses=[];witness_contexts=set()
result=json.loads((D/'result.json').read_bytes());assert result['returned_points']>0;gs={g['key']:g for g in map(json.loads,(I/'generations.jsonl').read_bytes().splitlines())};pts={(p['slot'],p['filter'],p['target_prefix']):p for p in map(json.loads,(I/'points.jsonl').read_bytes().splitlines())};cp={m['key']:m['checkpoint']for m in json.loads((S/'static-models.json').read_bytes())['rows']};met={m['key']:m for m in json.loads((S/'coverage-result.json').read_bytes())['rows']};query={(q['slot'],q['filter'],q['prefix']):q for q in map(json.loads,(S/'queries.jsonl').read_bytes().splitlines())}

def poll():
 assert time.perf_counter()-began<1200,'READER_CAP'
 for n in ('rollout','advisor','slack'):
  x=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not(x.get('stopped')or x.get('user_paused')),'EXPLICIT_STOP'

def vector(s,channels):
 b=Counter()
 for pc in s.state.position.board:
  if pc:b['board',pc.current_type_id]+=1 if pc.owner==0 else-1
 return[b[k,t]if k=='board'else s.state.position.hands[0].count(t)-s.state.position.hands[1].count(t)for k,t in channels]

def eval_leaf(rec,dist,raw,quant):
 terminal,z,v=rec
 assert len(v)==len(raw)==len(quant)and terminal in(0,1)and z in(-1,0,1)
 if terminal:
  w=z*(100000000-dist);return(w*1000,w,w)
 assert z==0;return(sum(x*w for x,w in zip(v,raw))*256,sum(x*w for x,w in zip(v,quant)),sum(v)*256)

def actual_leaf(s,rec,channels):
 terminal=s.result.status.value!='ongoing';z=0 if not terminal or s.result.winner is None else 1 if s.result.winner==0 else-1;assert [int(terminal),z,vector(s,channels)]==rec;counts['semantic_leaf_controls']+=1

def child(s,a):
 ch=copy(s);ch.submit(a);counts['semantic_checked_edges']+=1;return ch
with gzip.open(D/'frontiers.jsonl.gz','rt',encoding='utf8')as ff,(D/'roots.jsonl').open(encoding='utf8')as rr:
 for line in rr:
  poll();row=json.loads(line);fr=json.loads(next(ff));key=row['slot'],row['filter'],row['prefix'];assert all(row[k]==fr[k]for k in ('slot','filter','prefix','channels','status'));point=pts[key];finger=row['ruleset_fingerprint'];m=met[point['key']];p=cp[point['key']]
  if finger not in cache:cache[finger]=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(gs[point['key']]['rules']))
  c=cache[finger];s=GameSession.replay(c,deserialize_game_record(json.dumps(point['record'])));counts['full_root_history_replays']+=1;channels=[(k,t)for k in('board','hand')for t in sorted(t.type_id for t in c.piece_types if not t.is_anchor)];assert [list(v)for v in channels]==row['channels'];raw=[m['profile_board_values'if k=='board'else'profile_hand_values'][t]for k,t in channels];quant=[round(p['board_weights'if k=='board'else'hand_weights'][t]*256)for k,t in channels];assert fr['raw']==raw and fr['quant']==quant
  if row['status']=='TERMINAL_ROOT':assert s.result.status.value!='ongoing'and not fr['forest'];counts['terminal_roots']+=1;continue
  if row['status']!='COMPLETE_ROOT':assert row['status']=='UNKNOWN_ROOT_CAP';counts['unknown_roots']+=1;continue
  assert s.result.status.value=='ongoing';assert s.state.position.side_to_move==0;aa=sorted(s.legal_actions(),key=repr);assert record_value(aa)==row['root_actions'];assert len(aa)==len(fr['forest']);side=s.state.position.side_to_move;av=[]
  for terminal,branch in fr['forest']:
   if terminal:vals=eval_leaf(branch,1,raw,quant);counts['frontier_leaves']+=1
   else:
    assert branch;vv=[eval_leaf(x,2,raw,quant)for x in branch];op=min if side==0 else max;vals=tuple(op(x[j]for x in vv)for j in range(3));counts['frontier_leaves']+=len(branch)
   av.append(vals)
  assert [list(v)for v in av]==row['action_values'];op=max if side==0 else min;best=[op(x[j]for x in av)for j in range(3)];opts=[[i for i,x in enumerate(av)if x[j]==best[j]]for j in range(3)];assert best==row['best_values']and opts==row['optimal_indices'];si=row['static_chosen_index'];ui=row['unit_chosen_index'];assert row['static_integer_optimal']==(si in opts[1]);assert row['static_exact_optimal']==(si in opts[0]);assert row['unit_integer_optimal']==(ui in opts[2]);assert row['static_exact_regret']==(best[0]-av[si][0])*(1 if side==0 else-1);assert row['static_integer_score_equal']==(query[key]['score']*(1 if side==0 else-1)==best[1]);assert row['exact_vs_quant_sets_equal']==(opts[0]==opts[1]);assert row['exact_vs_quant_sets_disjoint']==(not set(opts[0])&set(opts[1]));assert row['static_vs_Unit_sets_disjoint']==(not set(opts[0])&set(opts[2]));counts['complete_root_arithmetic']+=1
  context=hashlib.sha256(json.dumps([row['ruleset_fingerprint'],point['record'],row['checkpoint_id']],sort_keys=True,separators=(',',':')).encode()).hexdigest();new_witness=row['static_exact_regret']>0 and context not in witness_contexts and len(full_witnesses)<8
  exhaustive=counts['complete_root_arithmetic']<=96 or new_witness
  if new_witness:full_witnesses.append(dict(slot=key[0],filter=key[1],prefix=key[2],full_context_sha256=context,regret_numerator=row['static_exact_regret']));witness_contexts.add(context)
  indices=range(len(aa))if exhaustive else sorted({0,len(aa)//2,len(aa)-1})
  for i in indices:
   ch=child(s,aa[i]);terminal,branch=fr['forest'][i];assert bool(terminal)==(ch.result.status.value!='ongoing')
   if terminal:actual_leaf(ch,branch,channels)
   else:
    bb=sorted(ch.legal_actions(),key=repr);assert len(bb)==len(branch)
    for j in (range(len(bb))if exhaustive else sorted({0,len(bb)//2,len(bb)-1})):actual_leaf(child(ch,bb[j]),branch[j],channels)
  counts['exhaustively_replayed_roots'if exhaustive else'sampled_path_roots']+=1
  if counts['complete_root_arithmetic']%128==0:print('READ',counts['complete_root_arithmetic'],dict(counts),round(time.perf_counter()-began,2),flush=True)
 assert next(ff,None)is None
assert counts['full_root_history_replays']==result['returned_points'];write_json(D/'reader-result.json',dict(status='PASS_ALL_FRONTIER_ARITHMETIC_AND_DECLARED_CORE_CONTROLS',counts=dict(counts),exhaustive_regret_witnesses=full_witnesses,seconds=time.perf_counter()-began,scope='ALLreturnedroot histories/rootlegalactionsets andallcompressedfrontier exactbackups; first96complete roots +first8DISTINCTfullcontextregretwitnesses exhaustiveCorecontrols, otherroots first/middle/last branches/replies only. Notallleafsemantic independentreplay, externalrulesauthority, WDL or oldNativequeryrerun. Allcapped/unstartedrootsUNKNOWN.'));print('READER_DONE',dict(counts),time.perf_counter()-began,flush=True)
