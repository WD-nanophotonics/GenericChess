"""Posthoc optimal-continuation input envelopes from complete D2 frontiers."""
from pathlib import Path
from collections import Counter,defaultdict
from math import tanh,sqrt
import sys,json,gzip,hashlib
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/static-fulltype-d2-reference-20261018';S=R/'.local_agent/static-input-objective-20261018';U=R/'.local_agent/filter-search-inputs-20261018';I=R/'.local_agent/playability-filter-20261018';points={(v['slot'],v['filter'],v['target_prefix']):v for v in map(json.loads,(I/'points.jsonl').read_bytes().splitlines())};cp={m['key']:m['checkpoint']for m in json.loads((S/'static-models.json').read_bytes())['rows']};sq={(q['slot'],q['filter'],q['prefix']):q for q in map(json.loads,(S/'queries.jsonl').read_bytes().splitlines())};uq={(q['slot'],q['filter'],q['prefix']):q for q in map(json.loads,(U/'queries.jsonl').read_bytes().splitlines())};counts=Counter();rows=[]
def val(rec,dist,raw,quant,j):
 t,z,v=rec
 if t:
  x=z*(100000000-dist);return x*1000 if j==0 else x
 if j==0:return sum(x*w for x,w in zip(v,raw))*256
 if j==1:return sum(x*w for x,w in zip(v,quant))
 return sum(v)*256
with gzip.open(D/'frontiers.jsonl.gz','rt',encoding='utf8')as ff,(D/'roots.jsonl').open(encoding='utf8')as rr:
 for line in rr:
  root=json.loads(line);f=json.loads(next(ff));assert all(root[k]==f[k]for k in('slot','filter','prefix','status'));key=root['slot'],root['filter'],root['prefix'];out=dict(slot=key[0],filter=key[1],prefix=key[2],key=root['key'],status=root['status'],models=[])
  if root['status']=='TERMINAL_ROOT':
   for j,name in enumerate(['exact_static','quantized_static','Unit']):out['models'].append(dict(name=name,must_nonzero=False,could_nonzero=False,minimum_gradient_l2=0.,maximum_gradient_l2=0.,optimal_continuations=0,distinct_optimal_feature_terminal_vectors=0))
   counts['terminal_roots']+=1
  elif root['status']=='COMPLETE_ROOT':
   p=cp[root['key']];coeff=[p['board_weights'if k=='board'else'hand_weights'][t]for k,t in root['channels']]
   for j,name in enumerate(['exact_static','quantized_static','Unit']):
    norms=[];features=set();opta=root['optimal_indices'][j]
    for ai in opta:
     terminal,branch=f['forest'][ai]
     if terminal:active=[branch]
     else:
      values=[val(r,2,f['raw'],f['quant'],j)for r in branch];best=min(values);active=[r for r,v in zip(branch,values)if v==best]
     for t,z,v in active:
      features.add((t,z,tuple(v)))
      if t:norm=0.
      else:
       prediction=tanh((sum(v)if j==2 else sum(x*w for x,w in zip(v,coeff)))/10);norm=(1-prediction*prediction)/10*sqrt(sum(x*x for x in v))
      norms.append(norm)
    assert norms;lo=min(norms);hi=max(norms);descriptor=dict(name=name,must_nonzero=lo>0,could_nonzero=hi>0,minimum_gradient_l2=lo,maximum_gradient_l2=hi,optimal_root_actions=len(opta),optimal_continuations=len(norms),distinct_optimal_feature_terminal_vectors=len(features));out['models'].append(descriptor);counts[name+'_must_nonzero']+=lo>0;counts[name+'_could_nonzero']+=hi>0;counts[name+'_tie_dependent_zero_nonzero']+=lo==0 and hi>0
    if j in(1,2):
     selected=bool((sq if j==1 else uq)[key]['gradient_nonzero']);assert int(lo>0)<=int(selected)<=int(hi>0),(key,name,selected,lo,hi)
   counts['complete_roots']+=1
  else:counts['UNKNOWN_ROOT_CAP']+=1
  for descriptor in out['models']:
   name=descriptor['name'];cpid=(uq if name=='Unit'else sq)[key]['checkpoint_id'];descriptor['full_context_sha256']=hashlib.sha256(json.dumps([root['ruleset_fingerprint'],points[key]['record'],cpid,name],sort_keys=True,separators=(',',':')).encode()).hexdigest()
  rows.append(out)
 assert next(ff,None)is None
assert counts['complete_roots']+counts['terminal_roots']+counts['UNKNOWN_ROOT_CAP']==len(rows)
by={(r['slot'],r['filter'],r['prefix']):r for r in rows};paired=[]
for prefix in(0,4,16):
 for name in('exact_static','quantized_static','Unit'):
  c=Counter();terms=Counter();contexts={}
  for slot in range(768):
   a,b=by.get((slot,False,prefix)),by.get((slot,True,prefix))
   if not a or not b or not a['models']or not b['models']:continue
   x=next(v for v in a['models']if v['name']==name);y=next(v for v in b['models']if v['name']==name)
   for sign,z in[(-1,x),(1,y)]:
    h=z['full_context_sha256'];terms[h]+=sign
    if h in contexts:assert (contexts[h]['must_nonzero'],contexts[h]['could_nonzero'])==(z['must_nonzero'],z['could_nonzero'])
    contexts[h]=z
   c['both_returned_pairs']+=1;c['off_must']+=x['must_nonzero'];c['off_could']+=x['could_nonzero'];c['on_must']+=y['must_nonzero'];c['on_could']+=y['could_nonzero']
  lo=hi=0
  for h,v in terms.items():
   a,b=int(contexts[h]['must_nonzero']),int(contexts[h]['could_nonzero']);lo+=v*(a if v>=0 else b);hi+=v*(b if v>=0 else a)
  paired.append(dict(prefix=prefix,model=name,counts=dict(c),coupled_full_context_filter_increment_envelope=[lo,hi],zero_combined_contexts=sum(v==0 for v in terms.values()),coupling_assumption='Samefullrule/history/model deterministiccontinuationselection; combine sharedcoefficientsbeforebounds. This doesnotclaim every crosscontext endpointchoice isrealizable byonealgorithm.',uncoupled_filter_increment_envelope=[c['on_must']-c['off_could'],c['on_could']-c['off_must']],scope='Pairedcompletedsubmeasure only; notwholeplannedpanel/population. Threegenerationfailuresunavailable, allmissing/capUNKNOWN.'))
write_json(D/'tie-envelope-result.json',dict(status='POSTHOC_COMPLETE_CONTINUATION_ENVELOPES',counts=dict(counts),rows=rows,paired_completed=paired,scope='LiteraloptimalD2continuations underdeclaredroot/opponentobjectives; owners0/evenprefixinputs. Per-typeparametersindependent,anchorsfixed. Conditionalrawpredictorderivatives, NOTsubgradient/searchderivativeornewtiepolicy. No inferenceoflearning/utilitygain fromfeatures. Intervals reflecttiedcontinuations, notsamplingconfidence; capped/unstartedUNKNOWN.'));print('TIE_ENVELOPES',dict(counts),flush=True)
