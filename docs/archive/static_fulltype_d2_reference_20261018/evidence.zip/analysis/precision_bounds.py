"""Finite-tree quantization bounds; reference input, no new game/search."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import sys,json,gzip
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/static-fulltype-d2-reference-20261018';S=R/'.local_agent/static-input-objective-20261018';cp={r['key']:r['checkpoint']for r in json.loads((S/'static-models.json').read_bytes())['rows']};counts=Counter();rows=[]
with gzip.open(D/'frontiers.jsonl.gz','rt',encoding='utf8')as ff,(D/'roots.jsonl').open(encoding='utf8')as rr:
 for line in rr:
  root=json.loads(line);front=json.loads(next(ff));assert all(root[k]==front[k]for k in('slot','filter','prefix','status'))
  if root['status']!='COMPLETE_ROOT':continue
  n=len(front['raw']);max_abs=[0]*n;action_bounds=[]
  for terminal,branch in front['forest']:
   err=0
   for flag,z,v in [branch]if terminal else branch:
    if flag:continue
    assert z==0;f=sum(x*w for x,w in zip(v,front['raw']))*256;g=sum(x*w for x,w in zip(v,front['quant']))*1000;err=max(err,abs(f-g));max_abs=[max(x,abs(y))for x,y in zip(max_abs,v)]
   action_bounds.append(err)
  eps=max(action_bounds,default=0);gap=root['static_exact_regret'];assert abs(root['best_values'][0]-1000*root['best_values'][1])<=eps;assert 0<=gap<=2*eps
  p=cp[root['key']];delta=[abs(Fraction.from_float(p['board_weights'if k=='board'else'hand_weights'][t])-Fraction(w,1000))for(k,t),w in zip(root['channels'],front['raw'])];coefficient_bound=sum(a*b for a,b in zip(max_abs,delta));u=Fraction(1,2**53);gamma=2*n*u/(1-2*n*u);absolute_sum_bound=sum(a*abs(Fraction.from_float(p['board_weights'if k=='board'else'hand_weights'][t]))for a,(k,t)in zip(max_abs,root['channels']));arithmetic_bound=gamma*absolute_sum_bound;binary_bound=coefficient_bound+arithmetic_bound;regret_units=Fraction(gap,256000);strict_survives_float=gap>0 and regret_units>2*binary_bound
  if gap>0:assert strict_survives_float,'POSITIVE_RATIONAL_REGRET_NOT_PROVED_FLOATROBUST'
  # Saved ongoing inputs have even full prefixes and owner0 to move.
  ui=root['unit_chosen_index'];unit_action_regret=root['best_values'][0]-root['action_values'][ui][0];assert unit_action_regret>=0;robust_unit_difference=unit_action_regret>2*eps
  counts['complete_roots']+=1;counts['positive_quant_choice_regret']+=gap>0;counts['positive_regret_float_robust']+=strict_survives_float;counts['Unit_choice_static_regret']+=unit_action_regret>0;counts['Unit_choice_gap_larger_than_twice_precision_error']+=robust_unit_difference
  rows.append(dict(slot=root['slot'],filter=root['filter'],prefix=root['prefix'],leaf_error_numerator=eps,quant_choice_regret_numerator=gap,Unit_choice_static_regret_numerator=unit_action_regret,per_action_error_bounds=action_bounds,binary_coefficient_bound_numerator=binary_bound.numerator,binary_coefficient_bound_denominator=binary_bound.denominator,positive_regret_float_robust=strict_survives_float,Unit_choice_gap_larger_than_twice_precision_error=robust_unit_difference))
 assert next(ff,None)is None
write_json(D/'precision-bounds.json',dict(status='PASS_FINITE_TREE_ERROR_AND_FLOAT_ROUNDOFF_BOUNDS',counts=dict(counts),rows=rows,scale='Nativeinteger*1000 /256000 =materialweightunits',derivation='Minandmaxare1-Lipschitz underleafsupnorm. Thus eachrootvalueerror<=eps andquantizedoptimalaction exactregret<=2eps. Binarymaterialdot-product error uses coefficientrepresentation plus gamma_2n*sum(maxabsfeature_i*abs(floatcoef_i)), u=2^-53, finiteIEEE round-to-nearest multiply/add model. Positivegaps>2bound surviveboth. Minmaxselection addsno arithmeticerror beyond leafvalues.',scope='SamefinitecompleteD2tree/terminalconstants only; no statementaboutqsearch/deeperTT/selectivebudget/utility/WDL/traininggain orrawmovementcapabilities. Doesnotbound allfuturelearningupdates, onlythisprofilematerialdot-product representation, not tanh orfuturequeries. Independentsemantic replay scope remains inreader-result.'));print('PRECISION_BOUNDS',dict(counts),flush=True)
