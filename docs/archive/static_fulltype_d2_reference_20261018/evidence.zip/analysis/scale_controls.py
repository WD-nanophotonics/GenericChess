"""Two posthoc full-context precision controls; independent Fraction Core trees."""
from pathlib import Path
from copy import copy
from collections import Counter
from fractions import Fraction
import sys,json,time
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
D=R/'.local_agent/static-fulltype-d2-reference-20261018';S=R/'.local_agent/static-input-objective-20261018';I=R/'.local_agent/playability-filter-20261018';p=json.loads((D/'scale-control-plan.json').read_bytes());gens={g['key']:g for g in map(json.loads,(I/'generations.jsonl').read_bytes().splitlines())};pts={(x['slot'],x['filter'],x['target_prefix']):x for x in map(json.loads,(I/'points.jsonl').read_bytes().splitlines())};models={x['key']:x['checkpoint']for x in json.loads((S/'static-models.json').read_bytes())['rows']};metadata={x['key']:x for x in json.loads((S/'coverage-result.json').read_bytes())['rows']};start=time.perf_counter();counts=Counter();rows=[]
assert not(D/'scale-control-result.json').exists()
def poll():
 assert time.perf_counter()-start<p['limits']['global_seconds'],'CONTROL_CAP';assert counts['Core_edges']<p['limits']['max_Core_edges'],'EDGE_CAP'
 for n in('rollout','advisor','slack'):
  z=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(z.get('stopped')or z.get('user_paused'))
def move(s,a):
 poll();x=copy(s);x.submit(a);counts['Core_edges']+=1;return x
for w in p['witnesses']:
 poll();g=gens[w['key']];c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']));point=pts[w['slot'],w['filter'],w['prefix']];s=GameSession.replay(c,deserialize_game_record(json.dumps(point['record'])));meta=metadata[w['key']];types=sorted(t.type_id for t in c.piece_types if not t.is_anchor);ch=[(k,t)for k in('board','hand')for t in types];raw=[meta['profile_board_values'if k=='board'else'profile_hand_values'][t]for k,t in ch];weights=[Fraction(v,1000)for v in raw];q256=[round(models[w['key']]['board_weights'if k=='board'else'hand_weights'][t]*256)for k,t in ch];maxordinary=0
 def value(node,dist):
  global maxordinary
  if node.result.status.value!='ongoing':
   assert node.result.declaration_outcome not in('NO_CONTEST','RESTART');z=0 if node.result.winner is None else 1 if node.result.winner==0 else-1;m=z*(100000000-dist);return(Fraction(m,256),m,m)
  b=Counter()
  for pc in node.state.position.board:
   if pc:b['board',pc.current_type_id]+=1 if pc.owner==0 else-1
  v=[b[k,t]if k=='board'else node.state.position.hands[0].count(t)-node.state.position.hands[1].count(t)for k,t in ch];vv=(sum((x*f for x,f in zip(v,weights)),Fraction()),sum(x*f for x,f in zip(v,q256)),sum(x*f for x,f in zip(v,raw)));maxordinary=max(maxordinary,abs(vv[1]),abs(vv[2]));assert maxordinary<90000000;return vv
 aa=sorted(s.legal_actions(),key=repr);av=[]
 for a in aa:
  child=move(s,a)
  if child.result.status.value!='ongoing':av.append(value(child,1))
  else:
   vals=[value(move(child,b),2)for b in sorted(child.legal_actions(),key=repr)];op=max if child.state.position.side_to_move==0 else min;av.append(tuple(op(x[j]for x in vals)for j in range(3)))
 op=max if s.state.position.side_to_move==0 else min;best=[op(x[j]for x in av)for j in range(3)];opts=[[i for i,x in enumerate(av)if x[j]==best[j]]for j in range(3)];assert opts[0]==opts[2];native=compile_native_semantic_rules(c);controls=[]
 for scale,j in((256,1),(1000,2)):
  d=dict(models[w['key']]);d['material_scale']=scale;cp=LearnableMaterialCheckpoint.from_dict(d);engine=SemanticSearchEngine(c,native,checkpoint=cp,tt_megabytes=0);r=engine.search(s,SearchLimits(max_depth=2,max_nodes=32768,max_time_seconds=.5,quiescence_max_depth=0),root_window_pruning=False);assert r.completed_depth==2 and not r.used_fallback;idx=aa.index(r.action);assert idx in opts[j];assert r.score*(1 if s.state.position.side_to_move==0 else-1)==best[j];regret=(best[0]-av[idx][0])*(1 if s.state.position.side_to_move==0 else-1);counts['Native_queries']+=1;controls.append(dict(scale=scale,checkpoint_id=cp.checkpoint_id,action=record_value(r.action),integer_score=r.score,completed_depth=r.completed_depth,nodes=r.nodes,kernel_seconds=r.elapsed_seconds,exact_preNative_optimal=idx in opts[0],exact_preNative_regret_numerator=regret.numerator,exact_preNative_regret_denominator=regret.denominator))
 rows.append(dict(key=w['key'],slot=w['slot'],filter=w['filter'],prefix=w['prefix'],full_context_sha256=w['full_context_sha256'],root_actions=record_value(aa),optimal_indices=opts,max_abs_ordinary_integer_leaf_value=maxordinary,core_fraction_best=[dict(numerator=Fraction(v).numerator,denominator=Fraction(v).denominator)for v in best],controls=controls))
write_json(D/'scale-control-result.json',dict(status='PASS_EXISTING_SCALE_OPTION_TWO_POSTHOC_CONTEXTS',counts=dict(counts),rows=rows,seconds=time.perf_counter()-start,scope='Two POSTHOCselecteddistinctfullcontextFractionCoreD2 controls+4newNativequeries. Existingmaterial-onlyscale1000 exactlyrepresentspre-Nativeintegerprofiletableshere; no newAPI/default/precisionutility/futurebudget/complete-domain claim. Differentmatebandnormalizations not numericallycompared; allordinaryfrontiers below90Mstaticband. Cachedsource/score/WDLnotinferred.'));print('SCALE_CONTROL_PASS',dict(counts),[(v['key'],v['prefix'],[(q['scale'],q['exact_preNative_optimal'])for q in v['controls']])for v in rows],flush=True)
