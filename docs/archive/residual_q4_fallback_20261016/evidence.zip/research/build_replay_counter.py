from pathlib import Path
import json,hashlib,shutil,subprocess,sysconfig,time,sys
R=Path.cwd();B=R/'.local_agent/residual-q4-20261016';S=B/'replay_counter_source';S.mkdir(exist_ok=True)
base=R/'generic_chess/_native/native_module.c';assert hashlib.sha256(base.read_bytes()).hexdigest()=='1c855ae56e946ec6cb8e57f60a36a18cb75cfec2ee8061047469f3e0bee3fac3'
for p in (R/'generic_chess/_native').iterdir():
 if p.suffix in('.c','.h'):shutil.copyfile(p,S/p.name)
p=S/'native_module.c';s=p.read_text(encoding='utf-8-sig')
mark='    uint64_t beta_cutoffs;';assert s.count(mark)==1
s=s.replace(mark,mark+'\n    uint64_t probe_replay_total,probe_replay_q,probe_replay_ns,probe_replay_sections,probe_replay_aborted;\n    unsigned probe_replay_nesting;')
mark='''        int branch = gc_semantic_iterative_negamax(
            ctx, ply + 1, depth - 1, -GC_SEMANTIC_PROBE_INF,
            GC_SEMANTIC_PROBE_INF, 1, 1);
        if (ctx->control != 0) return 0;''';assert s.count(mark)==1
s=s.replace(mark,'''        int probe_outer = ctx->probe_replay_nesting == 0;
        uint64_t probe_before=ctx->nodes, probe_q_before=ctx->qnodes;
        uint64_t probe_start=probe_outer?gc_monotonic_ns():0;
        ctx->probe_replay_nesting++;
        int branch = gc_semantic_iterative_negamax(
            ctx, ply + 1, depth - 1, -GC_SEMANTIC_PROBE_INF,
            GC_SEMANTIC_PROBE_INF, 1, 1);
        ctx->probe_replay_nesting--;
        if (probe_outer) {
            ctx->probe_replay_sections++;
            ctx->probe_replay_total+=ctx->nodes-probe_before;
            ctx->probe_replay_q+=ctx->qnodes-probe_q_before;
            ctx->probe_replay_ns+=gc_monotonic_ns()-probe_start;
            if(ctx->control)ctx->probe_replay_aborted++;
        }
        if (ctx->control != 0) return 0;''')
mark='    PyObject *training_trace = ctx.trace_enabled';assert s.count(mark)==1
inject='    if ('+' ||\n        '.join('gc_semantic_set_u64(out, "'+f+'", ctx.'+f+') != 0' for f in['probe_replay_total','probe_replay_q','probe_replay_ns','probe_replay_sections','probe_replay_aborted'])+''') {
        Py_DECREF(out); Py_DECREF(best_action_obj); Py_DECREF(pv);
        free(ctx.stack); free(ctx.pv_table); free(ctx.pv_length); free(ctx.trace_rows);
        if (ctx.tt != borrowed_tt) gc_semantic_tt_free(ctx.tt);
        gc_semantic_profile_free(&profile); gc_semantic_profile_free(&ordering_profile);
        return NULL;
    }
'''
s=s.replace(mark,inject+mark);p.write_bytes(s.encode())
plan=dict(question='Do inclusive canonical reconstruction sections dominate actual unrequested hardstop cost?',cases=[0,1],conditions=[dict(q=0,depth=3),dict(q=4,depth=2)],nodes=1000000,seconds=8,orders=[['normal','counter'],['counter','normal']],max_queries=16,whole_seconds=180,
scope='Two exposed roots, counters time outermost reconstruction recursion including nested scalar/q descendants; excludes initial best-child checked-edge setup. No authority removal/TT/algorithm change; compare complete non-time fields and retained histories. Concurrent games are timing interpretation limit.',
decision='If sections minor, reject canonical removal/optimization as next premise. If dominant, inspect exact source before considering any preserved-authority reuse; no automatic adoption.',
source_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),counter_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),expected_seconds=60,cheaper='Source review cannot attribute actual aborted iteration cost.')
(B/'replay-counter-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(p)for p in S.glob('*.c')],'-o',str(B/'replay_counter_native_core.pyd')]
start=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
(B/'replay-build-private.json').write_bytes(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-start),indent=2).encode())
print('BUILD',r.returncode,time.perf_counter()-start,r.stderr[-1000:]);sys.exit(r.returncode)
