from pathlib import Path
import sys,json,time,random,traceback,hashlib
R=Path.cwd();B=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(R/'.local_agent/reserve-allocation-20261015')]
import allocation as a
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
plan=json.loads((B/'wide-plan.json').read_bytes());start=time.perf_counter();manifest=[]
D=B/'wide-inputs';D.mkdir(exist_ok=True)
for case in plan['inputs']:
 a.p.rr.stopped();t=time.perf_counter();seed=case['seed'];row=dict(**case,roots=[],walk=[],terminal_tail=None)
 try:
  game=generate_game(GeneratorConfig(seed=seed,board_size=case['n'],**plan['generator']));row['ruleset']=json.loads(serialize_ruleset(game.ruleset));raw=a.p.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession(c);rng=random.Random(seed+39000)
  for ply in range(9):
   a.p.rr.stopped()
   if s.result.status.value!='ongoing':row['terminal_tail']=dict(ply=ply,state=a.record_value(s.state),walk=row['walk'].copy());break
   if ply in plan['roots']:row['roots'].append(dict(ply=ply,state=a.record_value(s.state),walk=row['walk'].copy(),legal_count=len(s.legal_actions())))
   if ply==8:break
   acts=tuple(s.legal_actions());act=rng.choice(sorted(acts,key=repr));s.submit(act);row['walk'].append(a.record_value(act))
  row['state']='INPUTS_FROZEN_NO_SEARCH'
 except Exception as e:row.update(state='GENERATION_OR_INPUT_FAILURE',error=repr(e),traceback=traceback.format_exc())
 row['input_seconds']=time.perf_counter()-t;a.write_record(D/f'{seed}.json',row);manifest.append(dict(seed=seed,n=case['n'],state=row['state'],roots=len(row['roots']),sha256=hashlib.sha256((D/f'{seed}.json').read_bytes()).hexdigest(),input_seconds=row['input_seconds']));print(seed,case['n'],row['state'],len(row['roots']),round(row['input_seconds'],3),flush=True)
a.write_record(B/'wide-input-manifest.json',dict(complete=True,inputs=manifest,seconds=time.perf_counter()-start,search_queries=0,plan_sha256=hashlib.sha256((B/'wide-plan.json').read_bytes()).hexdigest()));print('FROZEN_ALL',time.perf_counter()-start,flush=True)
