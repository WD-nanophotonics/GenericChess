from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)];import probe as p
a=p.a;plan=json.loads((P/'static-cap-plan.json').read_bytes());spec=importlib.util.spec_from_file_location('static_cap._native_core',P/'static_cap_native_core.pyd');cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap);raws={};mods=dict(q4=p.m,q0=p.m,static_cap=cap)
for name,m in [('normal',p.m),('static_cap',cap)]:
 orig=m.semantic_engine_search
 def wrapper(*args,_orig=orig,_name=name,**kw):
  x=_orig(*args,**kw);raws[_name]=x;return x
 m.semantic_engine_search=wrapper
start=time.perf_counter();rows=[];missing=[];diags={}
for ci in plan['cases']:
 s,_,bv,hv=p.load(ci);nrs={name:a.nc.compile_native_semantic_rules(s.compiled,backend_module=m)for name,m in mods.items()}
 for budget in plan['caller_budgets']:
  for order,names in enumerate(plan['orders']):
   for name in names:
    p.stopped()
    if time.perf_counter()-start>=plan['whole_seconds']:missing.append(dict(case_index=ci,budget=budget,order=order,arm=name,kind='WHOLE_CAP_NOT_STARTED'));continue
    t=time.perf_counter();e=a.SemanticSearchEngine(s.compiled,nrs[name],board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
    allowance=budget-(time.perf_counter()-t)-.02
    r=e.search(s,a.SearchLimits(max_depth=plan['depth'],max_nodes=plan['nodes'],max_time_seconds=allowance,quiescence_max_depth=0 if name=='q0'else 4,quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True)
    wall=time.perf_counter()-t;row=dict(case_index=ci,budget=budget,order=order,arm=name,objective='disabled_q'if name=='q0'else'ordinary4_check8_static_horizon_NOT_original_q4'if name=='static_cap'else'original_q4_hard_abort',result=a.record_value(r),raw=a.record_value(raws['static_cap'if name=='static_cap'else'normal']),caller_seconds=wall,execution_allowed=r.action is not None and wall<budget,pv_edges=a.audit(s,nrs[name],r))
    key=str(ci)+':'+repr(r.action)
    if key not in diags:diags[key]=a.diagnosis(s,r.action)
    row['diagnostic_key']=key;rows.append(row);p.save('static-cap-results.json',dict(complete=False,rows=rows,missing=missing,diagnostics=diags,seconds=time.perf_counter()-start))
    print(ci,budget,order,name,r.completed_depth,r.termination_reason,row['raw'].get('probe_static_cap_leaves'),diags[key]['kind'],round(wall,3),flush=True)
p.save('static-cap-results.json',dict(complete=True,rows=rows,missing=missing,diagnostics=diags,seconds=time.perf_counter()-start));print('ALL_STATIC_CLOSED',len(rows),len(missing),time.perf_counter()-start,flush=True)
