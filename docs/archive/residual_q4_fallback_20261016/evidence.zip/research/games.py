from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)]
import probe as p
a=p.a
def state_hash(s):return p.digest(s)
def physical(s,nr,action):
 old=s.state;np=a.pack_semantic_search_position(s.compiled,nr,s)
 np=a.sem.make_checked(nr,np,a.pack_semantic_action(nr,old.position,action));s.submit(action);snap=a.sem.snapshot(nr,np);exp=a.expected_snapshot(s.state.position,nr,s.compiled)
 for key in('board','hands','aux_state','side'):assert a.record_value(snap[key])==a.record_value(exp[key])
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(a.position_identity_key(w,s.compiled))for w in s._search_witnesses]
 assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in s.state.history)
 assert a.sem.terminal_status(nr,np)==dict(status=s.result.status.value,winner=s.result.winner)
def run_game(case,mode,load,path,plan,start,*,forced=None):
 s,nr,bv,hv=load();initial_actor=s.state.position.side_to_move;token=a.CancellationToken();t=time.perf_counter();rows=[];kind=None
 for ply in range(plan['horizon']):
  p.stopped()
  if s.result.status.value!='ongoing':kind='ACTUAL_RULE_TERMINAL';break
  if time.perf_counter()-start>=plan['whole_seconds']:kind='WHOLE_CAP_UNKNOWN';break
  if time.perf_counter()-t>=plan['game_seconds']:kind='GAME_CAP_UNKNOWN';break
  actor=s.state.position.side_to_move;owner=mode if actor==initial_actor else'q4';before=state_hash(s)
  if ply==0 and forced is not None:
   action=next(ac for ac in s.legal_actions()if a.record_value(ac)==forced);row=dict(ply=ply,actor=actor,owner='FORCED_SELECTED_ACTION',before_sha256=before,action=a.record_value(action),execution_allowed=True)
  else:
   row,r,objs=p.schedule(s,nr,bv,hv,owner,token=token);row.update(ply=ply,actor=actor,owner=owner,before_sha256=before)
   if not row['execution_allowed']:rows.append(row);kind='CALLER_NO_ACTION_UNKNOWN';break
   action=r.action;row['action']=a.record_value(action)
  phys=time.perf_counter();physical(s,nr,action);row.update(after_sha256=state_hash(s),actual_terminal=a.record_value(s.result),physical_audit_seconds=time.perf_counter()-phys);rows.append(row)
  a.write_record(path.with_name(path.stem+'-partial.json'),dict(complete=False,case=case,mode=mode,initial_actor=initial_actor,rows=rows,seconds=time.perf_counter()-t))
  print(case,mode,ply,owner,row.get('selected_source'),s.result.status.value,flush=True)
 kind=kind or('ACTUAL_RULE_TERMINAL'if s.result.status.value!='ongoing'else'PLY_CAP_UNKNOWN')
 out=dict(complete=True,case=case,mode=mode,initial_actor=initial_actor,rows=rows,kind=kind,result=a.record_value(s.result),state=a.record_value(s.state),seconds=time.perf_counter()-t)
 a.write_record(path,out);print('GAME_DONE',case,mode,kind,len(rows),out['result'],out['seconds'],flush=True);return out
if __name__=='__main__':
 plan=json.loads((P/'continuation-plan.json').read_bytes());probe=json.loads((P/'results.json').read_bytes());assert probe['complete'];start=time.perf_counter();games=[]
 for ci in range(3):
  # All distinct original-order selected actions; identical continuation q4 for BOTH actors.
  actions=[]
  for mode in['q4','lazy_backup','upfront_cap2']:
   row=next(r for r in probe['rows']if r['case_index']==ci and r['order']==0 and r['mode']==mode);ac=row['selected']['action']
   old=next((x for x in actions if x['action']==ac),None)
   if old:old['origins'].append(mode)
   else:actions.append(dict(action=ac,origins=[mode]))
  for j,entry in enumerate(actions):
   path=P/f'continuation-{ci}-{j}.json';out=run_game(ci,'q4',lambda:p.load(ci),path,plan,start,forced=entry['action']);games.append(dict(case_index=ci,index=j,origins=entry['origins'],kind=out['kind'],initial_actor=out['initial_actor'],result=out['result'],edges=len(out['rows']),seconds=out['seconds']))
 a.write_record(P/'continuation-completion.json',dict(complete=True,games=games,seconds=time.perf_counter()-start));print('ALL_CLOSED',len(games),time.perf_counter()-start,flush=True)
