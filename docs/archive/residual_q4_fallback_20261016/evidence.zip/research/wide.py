from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)];import probe as p
from generic_chess.session.serialization import serialize_game_record
a=p.a;plan=json.loads((P/'wide-plan.json').read_bytes());start=time.perf_counter();rows=[];missing=[]
p.save('wide-producer-binding.json',dict(plan_sha256=hashlib.sha256((P/'wide-plan.json').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),query_count_at_binding=0))
for entry in plan['inputs']:
 seed=entry['seed'];data=json.loads((P/'wide-inputs'/f'{seed}.json').read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(data['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=a.nc.compile_native_semantic_rules(c,backend_module=p.m);profile=a.p.build_ruleset_profile(c,a.p.EvaluationConfig());bv={t:int(round(v))for t,v in profile.board_value_by_type.items()};hv={t:int(round(v))for t,v in profile.hand_value_by_base_type.items()}
 for ply in plan['roots']:
  root=next((r for r in data['roots']if r['ply']==ply),None)
  if root is not None:
   s=a.GameSession(c)
   for act in root['walk']:s.submit(next(ac for ac in s.legal_actions()if a.record_value(ac)==act))
   assert a.record_value(s.state)==root['state'];rootid=f'wide-{seed}-{ply}';before=p.digest(s)
   record=dict(root_id=rootid,ruleset=data['ruleset'],game_record=json.loads(serialize_game_record(s.to_record())),state=a.record_value(s.state),before_sha256=before,board_values=bv,hand_values=hv)
   (P/'roots'/f'{rootid}.json').write_bytes(json.dumps(record,indent=2).encode())
  for order,modes in enumerate(plan['orders']):
   for mode in modes:
    p.stopped()
    if root is None or time.perf_counter()-start>=plan['whole_seconds']:missing.append(dict(seed=seed,n=entry['n'],ply=ply,order=order,mode=mode,kind='TERMINAL_TAIL_MISSING_ROOT'if root is None else'WHOLE_CAP_NOT_STARTED'));continue
    t=time.perf_counter();row,r,objs=p.schedule(s,nr,bv,hv,mode);row.update(actual_call_seconds=time.perf_counter()-t,root_id=rootid,seed=seed,n=entry['n'],ply=ply,order=order,before_sha256=before);row['phase_pv_edges']=[a.audit(s,nr,r)for r in objs];rows.append(row)
    print(seed,ply,order,mode,row['selected_source'],[(ph['result']['completed_depth'],ph['result']['termination_reason'])for ph in row['phases']],round(row['actual_call_seconds'],3),flush=True)
  p.save('wide-results-partial.json',dict(complete=False,rows=rows,missing=missing,seconds=time.perf_counter()-start))
p.save('wide-results.json',dict(complete=True,rows=rows,missing=missing,seconds=time.perf_counter()-start));print('WIDE_CLOSED',len(rows),len(missing),time.perf_counter()-start,flush=True)
