from pathlib import Path
import sys,json,shutil,hashlib,sysconfig,subprocess,time
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';S=P/'static_cap_source';S.mkdir(exist_ok=True)
for x in(R/'generic_chess/_native').iterdir():
 if x.suffix in('.c','.h'):shutil.copyfile(x,S/x.name)
f=S/'native_module.c';s=f.read_text(encoding='utf-8-sig');mark='    uint64_t beta_cutoffs;';assert s.count(mark)==1;s=s.replace(mark,mark+'\n    uint64_t probe_static_cap_leaves;')
mark='    if(check && qdepth>=ctx->qhard_depth){ctx->control=5;return 0;}';assert s.count(mark)==1
s=s.replace(mark,'''    if(check && qdepth>=ctx->qhard_depth){
        ctx->probe_static_cap_leaves++;
        int horizon=gc_semantic_probe_material(ctx->rules,pos,&ctx->profile,NULL);
        return neutral && horizon<0?0:horizon;
    }''')
mark='    PyObject *training_trace = ctx.trace_enabled';assert s.count(mark)==1
s=s.replace(mark,'''    if (gc_semantic_set_u64(out,"probe_static_cap_leaves",ctx.probe_static_cap_leaves)!=0) {
        Py_DECREF(out);Py_DECREF(best_action_obj);Py_DECREF(pv);
        free(ctx.stack);free(ctx.pv_table);free(ctx.pv_length);free(ctx.trace_rows);
        if(ctx.tt!=borrowed_tt)gc_semantic_tt_free(ctx.tt);
        gc_semantic_profile_free(&profile);gc_semantic_profile_free(&ordering_profile);
        return NULL;
    }
'''+mark);f.write_bytes(s.encode())
plan=dict(question='Does static truncation of nonterminal checked q-cap nodes make bounded search finish, or just move the same cost to time censoring?',changed_premise='Inclusive reconstruction is negligible in actual q4 hardstops; hardcap interrupts whole requested iteration. Explicit alternative changes search horizon, never rule terminal authority.',
scope='PRIVATE DIFFERENT OBJECTIVE. Full terminal/declaration/history checks precede approximate finite material leaf. Do not label as completed original requested q4/hard8 or compare scores across objectives. No product/default/API change or WDL claim.',
cases=[0,1],arms=['q4','static_cap','q0'],orders=[['q4','static_cap','q0'],['q0','static_cap','q4']],caller_budgets=[1.,8.],depth=16,nodes=1000000,ordinary_q=4,hard_q=8,whole_seconds=180,expected_seconds=100,max_queries=24,cheaper='18caller and16counter queries already show completion/cost; do not answer a changed leaf horizon.',
base_sha256=hashlib.sha256((R/'generic_chess/_native/native_module.c').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(f.read_bytes()).hexdigest())
(P/'static-cap-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
cmd=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_path('include'),'-I'+str(S),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312',*[str(x)for x in S.glob('*.c')],'-o',str(P/'static_cap_native_core.pyd')]
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(P/'static-cap-build-private.json').write_bytes(json.dumps(dict(returncode=r.returncode,command=cmd,stdout=r.stdout,stderr=r.stderr,seconds=time.perf_counter()-t),indent=2).encode());print('BUILD',r.returncode,time.perf_counter()-t,r.stderr[-800:]);sys.exit(r.returncode)
