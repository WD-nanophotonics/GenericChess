"""Search-disabled consumer. Run from product source root; pass evidence directory."""
from pathlib import Path
import sys,json,time,hashlib
R=Path.cwd();sys.path.insert(0,str(R));B=Path(sys.argv[1])if len(sys.argv)>1 else R/'.local_agent/residual-q4-20261016'
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.rules.ir import CompiledSemanticRuleset
class Adapter(CompiledSemanticRuleset):
 __slots__=()
 def __getattr__(self,name):return getattr(self._legacy_compiled,name)
 @property
 def semantic(self):return self
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.session.session import GameSession
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove,PassAction
from generic_chess.core.coordinates import Square
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import iter_legal_actions
from generic_chess.native import compiler as nc,semantic as sem,SemanticSearchEngine,_module
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import expected_snapshot,pack_semantic_action
from scripts.research_record import record_value
assert Path(nc.__file__).resolve().is_relative_to(R.resolve())
assert Path(_module().__file__).resolve().is_relative_to(R.resolve())
assert Path(compile_legacy_ruleset_for_semantic_execution.__code__.co_filename).resolve().is_relative_to(R.resolve())
def forbidden(*a,**kw):raise AssertionError('Search forbidden in receipt consumer')
SemanticSearchEngine.search=forbidden;_module().semantic_engine_search=forbidden
def read(p):return json.loads((B/p).read_bytes())
def action(d):
 if d is None:return None
 if not d:return PassAction()
 if 'from_square'in d:return SemanticBoardMove(d['pattern_id'],d['geometry_id'],d['actor_type_id'],Square(**d['from_square']),Square(**d['to_square']),d['promotion_target_id'])
 return SemanticDropMove(d['pattern_id'],d['geometry_id'],d['base_type_id'],Square(**d['to_square']))
def digest(state):return hashlib.sha256(json.dumps(record_value(state),sort_keys=True).encode()).hexdigest()
cache={};counts=dict(roots=0,queries=0,pv_edges=0,physical_games=0,physical_edges=0,one_reply_receipts=0)
def load(root):
 key=str(root)
 if key not in cache:
  d=read('roots/'+key+'.json');raw=compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(d['ruleset'])));c=Adapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);nr=nc.compile_native_semantic_rules(c);cache[key]=(d,c,nr);counts['roots']+=1
 d,c,nr=cache[key];s=GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])))
 assert record_value(s.state)==d['state']and digest(s.state)==d['before_sha256']
 return s,nr
def compare(s,nr,state,np,witnesses):
 snap=sem.snapshot(nr,np);exp=expected_snapshot(state.position,nr,s.compiled)
 for k in('board','hands','aux_state','side'):assert record_value(snap[k])==record_value(exp[k])
 assert [''.join(f'{v:016x}'for v in h)for h in snap['history']]==[str(position_identity_key(w,s.compiled))for w in witnesses]
 assert snap['history_events']==tuple((255 if e.actor<0 else e.actor,bool(e.gave_check))for e in state.history)
 assert sem.terminal_status(nr,np)==dict(status=state.terminal_status.status.value,winner=state.terminal_status.winner)
def query(s,nr,r,limit=1000000):
 assert r['nodes']>=0 and r['qnodes']>=0 and r['nodes']+r['qnodes']<=limit
 st=s.state;np=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses)
 chosen=action(r['action']);assert chosen is None or chosen in s.legal_actions()
 line=[action(a)for a in r['principal_variation']]
 if line:assert line[0]==chosen
 if not line and chosen is not None:line=[chosen]
 for a in line:
  np=sem.make_checked(nr,np,pack_semantic_action(nr,st.position,a));st=apply_action(st,a,s.compiled);w.append(st.position);compare(s,nr,st,np,w);counts['pv_edges']+=1
 if r.get('immediate_win')and r.get('result_source')=='verified_root_child':assert len(line)==1 and st.terminal_status.winner==s.state.position.side_to_move
 counts['queries']+=1
def requested(r):return r['result_source']=='main_iteration'and r['completed_depth']>=2 and(r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==(4,8)
def win(r):return r['immediate_win']and r['result_source']=='verified_root_child'
def scheduler(s,nr,row,cap=1000000,budget=1.):
 used=0;chosen=None;source=None;mode=row['mode'];phases=row['phases']
 for i,p in enumerate(phases):
  r=p['result'];query(s,nr,r,cap-used);used+=r['nodes']+r['qnodes'];assert used==p['used_total_nodes']
  if i==0:chosen=r;source='q4_initial'if p['q']==4 else'disabled_only'if mode=='q0_only'else'upfront_disabled_initial'
  if win(r):chosen=r;source='physical_win'
  elif requested(r):chosen=r;source='requested_q4'
  elif i==1 and mode=='lazy_backup'and r['result_source']=='main_iteration'and r['completed_depth']>=2 and(r['result_ordinary_qdepth'],r['result_check_hard_qdepth'])==(0,0):chosen=r;source='disabled_backup'
  if i==1 and mode=='lazy_backup':
   first=phases[0]['result'];assert first['termination_reason']=='qsearch_check_hard_limit'and not requested(first)and not win(first)and p['q']==0
  if i+1<len(phases):assert not win(r)and not requested(r)
 assert chosen==row['selected']and source==row['selected_source']and used==row['total_nodes']and used<=cap
 if row['execution_allowed']:assert chosen is not None and chosen['action']is not None and not row['cancelled']and row['caller_seconds']<budget
start=time.perf_counter();probe=read('results.json');assert probe['complete']
for row in probe['rows']:
 s,nr=load(row['case_index']);assert digest(s.state)==row['before_sha256'];scheduler(s,nr,row)
for key,d in probe['diagnostics'].items():
 ci=int(key.split(':',1)[0]);s,nr=load(ci);row=next(r for r in probe['rows']if r['diagnostic_key']==key);act=action(row['selected']['action']);child=apply_action(s.state,act,s.compiled)
 if d['kind']=='SELECTED_CHILD_TERMINAL':assert child.terminal_status.is_terminal;continue
 observed=[]
 for witness in d['rows']:
  ac=action(witness['action']);after=apply_action(child,ac,s.compiled);assert record_value(after.terminal_status)==witness['terminal'];observed.append(ac);counts['one_reply_receipts']+=1
 if d['complete']:assert set(observed)==set(iter_legal_actions(child,s.compiled))
 if d['winning_reply']is not None:
  after=apply_action(child,action(d['winning_reply']),s.compiled);assert after.terminal_status.winner==child.position.side_to_move
counter=read('replay-counter-results.json');assert counter['complete']and not counter['mismatches']
for row in counter['rows']:
 s,nr=load(row['case_index']);query(s,nr,row['result'])
static=read('static-cap-results.json');assert static['complete']and len(static['rows'])+len(static['missing'])==24
for row in static['rows']:
 s,nr=load(row['case_index']);query(s,nr,row['result'])
 if row['arm']=='static_cap':assert 'NOT_original_q4'in row['objective']and row['raw']['probe_static_cap_leaves']>0
controls=read('control-results.json');assert controls['complete']and len(controls['logic_checks'])==9
for row in controls['actual_timer_cancellations']:
 s,nr=load(row['case_index']);scheduler(s,nr,row['row']);assert not row['row']['execution_allowed']and row['row']['cancelled']
def game(path,root,mode):
 out=read(path);assert out['complete'];s,nr=load(root);np=pack_semantic_search_position(s.compiled,nr,s);w=list(s._search_witnesses)
 for row in out['rows']:
  assert digest(s.state)==row['before_sha256']
  if 'phases'in row:
   scheduler(s,nr,row)
   if mode!='q4':
    owner=('q0_only'if mode.startswith('q0')else'lazy_backup'if mode.startswith('lazy')else'upfront_cap2')if row['actor']==int(mode[-1])else'q4'
    assert row['owner']==owner
  if 'action'not in row:assert not row['execution_allowed'];continue
  assert row['execution_allowed'];act=action(row['action'])
  if 'selected'in row:assert row['action']==row['selected']['action']
  np=sem.make_checked(nr,np,pack_semantic_action(nr,s.state.position,act));s.submit(act);w.append(s.state.position);compare(s,nr,s.state,np,w)
  assert digest(s.state)==row['after_sha256']and record_value(s.result)==row['actual_terminal'];counts['physical_edges']+=1
 assert record_value(s.state)==out['state']and record_value(s.result)==out['result'];counts['physical_games']+=1
done=read('continuation-completion.json');assert done['complete']
for g in done['games']:game(f"continuation-{g['case_index']}-{g['index']}.json",g['case_index'],'q4')
if (B/'policy-completion.json').exists():
 done=read('policy-completion.json');assert done['complete']and len(done['games'])==40
 for g in done['games']:
  if g['kind'].startswith(('MISSING','NOT_STARTED')):continue
  game(f"policy-{g['seed']}-{g['mode']}.json",g['seed'],g['mode'])

node=read('node-results.json');np=read('node-plan.json');assert node['complete']and not node['mismatches']and len(node['rows'])+len(node['missing'])==np['planned_callers']
for row in node['rows']:
 s,nr=load(row['root_id']);assert digest(s.state)==row['before_sha256'];scheduler(s,nr,row,cap=np['node_cap'],budget=np['caller_budget']);assert row['actual_call_seconds']>=row['caller_seconds']
wide=read('wide-results.json');assert wide['complete']and len(wide['rows'])+len(wide['missing'])==64
for row in wide['rows']:
 s,nr=load(row['root_id']);assert digest(s.state)==row['before_sha256'];scheduler(s,nr,row);assert row['actual_call_seconds']>=row['caller_seconds']
if (B/'q0-completion.json').exists():
 done=read('q0-completion.json');assert done['complete']and len(done['games'])==16
 for g in done['games']:
  if 'result'not in g:continue
  game(f"q0-{g['seed']}-role{g['role']}.json",g['seed'],g['mode'])

result=dict(complete=True,unique_root_states=len({d['before_sha256']for d,c,nr in cache.values()}),**counts,seconds=time.perf_counter()-start,search_disabled=True,scope='Actual normal Core/Native literal transitions, complete physical histories and phase PV receipts. Shared compiler, no optimal-value or independent rules implementation claim.')
(B/'consumer-replay.json').write_bytes(json.dumps(result,indent=2).encode());print('PASS',result,flush=True)
