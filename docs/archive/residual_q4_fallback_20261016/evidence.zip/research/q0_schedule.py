from probe import *
def schedule(s,nr,bv,hv,mode,*,token=None,clock=time.perf_counter,factory=a.SemanticSearchEngine,after_phase=None):
 token=token or a.CancellationToken();start=clock();deadline=start+1.;used=0;phases=[];selected=None;source=None;objs=[]
 qs=[0]if mode=='q0_only'else[0,4]if mode=='upfront_cap2'else[4,0]if mode=='lazy_backup'else[4]
 for i,q in enumerate(qs):
  if token.is_cancelled()or deadline-clock()<=.02 or used>=1000000:break
  if i==1 and mode=='lazy_backup'and not(phases[0]['result']['termination_reason']=='qsearch_check_hard_limit'and not requested(objs[0])and not physical(objs[0])):break
  t=clock();engine=factory(s.compiled,nr,board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
  allowance=deadline-clock()-.02
  if mode=='upfront_cap2'and i==0:allowance=min(allowance,.25-(clock()-t))
  if allowance<=0:break
  r=engine.search(s,a.SearchLimits(max_depth=2 if mode=='upfront_cap2'and i==0 else 16,max_nodes=1000000-used,max_time_seconds=allowance,quiescence_max_depth=q,quiescence_hard_max_depth=8),cancel_token=token,root_window_pruning=True,stop_on_immediate_win=True)
  used+=r.nodes+r.qnodes;objs.append(r)
  phases.append(dict(q=q,result=a.record_value(r),phase_seconds=clock()-t,allowance=allowance,remaining_seconds=deadline-clock(),used_total_nodes=used))
  if i==0:selected=r;source='q4_initial'if q==4 else'disabled_only'if mode=='q0_only'else'upfront_disabled_initial'
  if physical(r):selected=r;source='physical_win'
  elif requested(r):selected=r;source='requested_q4'
  elif i==1 and mode=='lazy_backup'and backup(r):selected=r;source='disabled_backup'
  if after_phase:after_phase(i,r,token)
  if physical(r)or requested(r)or token.is_cancelled()or clock()>=deadline:break
  # A cap2 first result may be retained if the second phase does not complete q4.
 seconds=clock()-start
 out=dict(mode=mode,phases=phases,selected=None if selected is None else a.record_value(selected),selected_source=source,caller_seconds=seconds,total_nodes=used,overrun_seconds=max(0,seconds-1.),cancelled=token.is_cancelled(),execution_allowed=selected is not None and selected.action is not None and not token.is_cancelled()and clock()<deadline)
 return out,selected,objs
