"""Summarize all fixed slots. UNKNOWN is a separate category, never an actual draw."""
from pathlib import Path
from collections import Counter
import json,math,random,hashlib
P=Path('.local_agent/residual-q4-20261016')
def read(f):return json.loads((P/f).read_bytes())
def status(g,actor):
 r=g.get('result')
 if not r or r['status']=='ongoing':return'UNKNOWN'
 if r['winner']is None:return'DRAW'
 return'WIN'if r['winner']==actor else'LOSS'
def small(row):
 r=row.get('selected')or{}
 return dict(source=row.get('selected_source'),depth=r.get('completed_depth'),retained_ordinary=r.get('result_ordinary_qdepth'),retained_check=r.get('result_check_hard_qdepth'),reason=r.get('termination_reason'),caller=row.get('caller_seconds'),action=row.get('action'))
def actions(g):return[r['action']for r in g['rows']if'action'in r]
def first_difference(base,var,role):
 for b,v in zip(base['rows'],var['rows']):
  if b['before_sha256']!=v['before_sha256']:return dict(kind='NONCOMMON_STATE',ply=v['ply'])
  if b.get('action')!=v.get('action'):return dict(kind='ACTION_DIFFERENCE'if'action'in b and'action'in v else'EXECUTION_DIFFERENCE',ply=v['ply'],actor=v['actor'],is_candidate_actor=v['actor']==role,baseline=small(b),candidate=small(v),before_sha256=v['before_sha256'])
 return dict(kind='IDENTICAL_PHYSICAL_PATH'if actions(base)==actions(var)else'COMMON_PREFIX_DIFFERENT_LENGTH',common_rows=min(len(base['rows']),len(var['rows'])))
def bootstrap(family_values):
 rng=random.Random(20261016);n=len(family_values)
 if n==0:return None
 vals=sorted(sum(rng.choice(family_values)for _ in range(n))/n for _ in range(5000))
 return[vals[int(.025*4999)],vals[int(.975*4999)]]
probe=read('results.json');assert probe['complete']
out=dict(source_commit='e583f0a7772d2d19498e6db5ba26075f951b235f',product_change=False,initial_callers=len(probe['rows']),initial_phase_queries=sum(len(r['phases'])for r in probe['rows']),initial_seconds=probe['seconds'],initial_by_root=[],controls=dict(deterministic=len(read('control-results.json')['logic_checks']),actual_timer_cancellations=2))
for ci in range(3):
 rr=[r for r in probe['rows']if r['case_index']==ci];out['initial_by_root'].append(dict(case_index=ci,rows=[dict(order=r['order'],mode=r['mode'],source=r['selected_source'],completed_depth=r['selected']['completed_depth'],retained_policy=[r['selected']['result_ordinary_qdepth'],r['selected']['result_check_hard_qdepth']],caller_seconds=r['caller_seconds'],total_main_plus_q_nodes=r['total_nodes'],diagnostic=probe['diagnostics'][r['diagnostic_key']]['kind'],execution_allowed=r['execution_allowed'])for r in rr]))
counter=read('replay-counter-results.json');assert not counter['mismatches']
out['reconstruction']=dict(queries=len(counter['rows']),non_time_mismatches=counter['mismatches'],seconds=counter['seconds'],rows=[])
for r in counter['rows']:
 if r['arm']!='counter':continue
 raw=r['raw'];total=r['result']['nodes']+r['result']['qnodes'];out['reconstruction']['rows'].append(dict(case_index=r['case_index'],q=r['condition']['q'],order=r['order'],replay_sections=raw['probe_replay_sections'],replay_visits=raw['probe_replay_total'],replay_qvisits=raw['probe_replay_q'],all_visits=total,visit_fraction=raw['probe_replay_total']/total,replay_seconds=raw['probe_replay_ns']/1e9,caller_seconds=r['seconds'],caller_fraction=raw['probe_replay_ns']/1e9/r['seconds'],aborted_sections=raw['probe_replay_aborted']))
done=read('continuation-completion.json');out['forced_actions']=done;out['forced_actions']['scope']='Seven distinct selected actions from three exposed roots. Identical q4 continuation for both actors. Actual conditional events, not original policy comparison, independent WDL or strength.'
cap=read('static-cap-results.json');assert cap['complete']
out['static_horizon']=dict(queries=len(cap['rows']),missing=cap['missing'],seconds=cap['seconds'],rows=[dict(case_index=r['case_index'],budget=r['budget'],order=r['order'],arm=r['arm'],objective=r['objective'],depth=r['result']['completed_depth'],reason=r['result']['termination_reason'],static_cap_leaves=r['raw'].get('probe_static_cap_leaves'),caller_seconds=r['caller_seconds'],diagnostic=cap['diagnostics'][r['diagnostic_key']]['kind'])for r in cap['rows']],decision='Changed approximate horizon does not restore original requested q4. At1second neither hardstop root gets deeper retained iteration. At8seconds only second root reaches changed-objectiveD2; no immediate safety or utility gain established. No product/default adoption.')
if(P/'policy-completion.json').exists():
 done=read('policy-completion.json');assert done['complete']and len(done['games'])==40
 out['prospective_policy']=dict(planned_games=40,planned_families=8,actual_games=sum('result'in g for g in done['games']),missing=[g for g in done['games']if'result'not in g],seconds=done['seconds'],physical_edges=sum(g.get('edges',0)for g in done['games']),by_policy={},game_cost_scope='Physical baseline played once per family and reused for both role comparisons; pairs are correlated. Whole/game cost includes scientific recording. Caller cost excludes Core/audit/file saves. Changed trajectories are not same-work speed comparisons.')
 for policy in['lazy','upfront']:
  counts=Counter();bc=Counter();trans=Counter();pairs=[];family_deltas=[];allcalls=[];prefix_displaced=[];known_delta=0
  for seed in range(8311,8319):
   meta=next(g for g in done['games']if g['seed']==seed and g['mode']=='q4');base=read(f'policy-{seed}-q4.json')if'result'in meta else None;fd=0
   for role in[0,1]:
    mode=f'{policy}_role{role}';vm=next(g for g in done['games']if g['seed']==seed and g['mode']==mode);var=read(f'policy-{seed}-{mode}.json')if'result'in vm else None
    bs=status(meta,role);vs=status(vm,role);bc[bs]+=1;counts[vs]+=1;trans[bs+'->'+vs]+=1
    payoff={'WIN':1,'LOSS':-1,'DRAW':0,'UNKNOWN':0};delta=payoff[vs]-payoff[bs];fd+=delta
    pair=dict(seed=seed,role=role,baseline=bs,candidate=vs,finite_event_delta=delta,baseline_kind=meta['kind'],candidate_kind=vm['kind'])
    if base and var:
     pair['first_difference']=first_difference(base,var,role);pair['baseline_seconds']=base['seconds'];pair['candidate_seconds']=var['seconds'];pair['same_path']=actions(base)==actions(var)
     allcalls.extend(r for r in var['rows']if'phases'in r)
     for b,v in zip(base['rows'],var['rows']):
      if b['before_sha256']!=v['before_sha256']:break
      if v['actor']==role and b.get('selected_source')=='requested_q4'and v.get('selected_source')not in('requested_q4','physical_win'):
       prefix_displaced.append(dict(seed=seed,role=role,ply=v['ply'],baseline=small(b),candidate=small(v)))
      if b.get('action')!=v.get('action'):break
    pairs.append(pair)
   family_deltas.append(fd/2)
  hist=Counter(r.get('selected_source')for r in allcalls);phases=[ph for r in allcalls for ph in r['phases']];terms=Counter(ph['result']['termination_reason']for ph in phases)
  out['prospective_policy']['by_policy'][policy]=dict(planned_role_comparisons=16,baseline_counts={k:bc[k]for k in('WIN','LOSS','DRAW','UNKNOWN')},candidate_counts={k:counts[k]for k in('WIN','LOSS','DRAW','UNKNOWN')},transitions=dict(trans),finite_event_net_delta=sum(p['finite_event_delta']for p in pairs),mean_delta_per_role=sum(family_deltas)/8,family_bootstrap_95=bootstrap(family_deltas),bootstrap_scope='5000 resamples of eight families, both dependent roles kept together. Descriptive development interval; not randomized-causal inference, WDL or population strength.',pairs=pairs,common_prefix_requested_displacements=prefix_displaced,selected_sources=dict(hist),phase_termination_reasons=dict(terms),actual_phase_queries=len(phases),caller_seconds=sum(r['caller_seconds']for r in allcalls),main_nodes=sum(ph['result']['nodes']for ph in phases),qnodes=sum(ph['result']['qnodes']for ph in phases),two_phase_callers=sum(len(r['phases'])==2 for r in allcalls),executed_backups=sum(r.get('selected_source')=='disabled_backup'and r.get('execution_allowed')for r in allcalls),execution_disallowed=sum(not r.get('execution_allowed')for r in allcalls))
 out['prospective_policy']['baseline_actual_games']=[dict(seed=g['seed'],result=g.get('result'),kind=g['kind'],seconds=g.get('seconds'),edges=g.get('edges'))for g in done['games']if g['mode']=='q4']

node=read('node-results.json');np=read('node-plan.json');assert node['complete']and not node['mismatches']
out['fixed_node_controls']=dict(parents=len(np['parents']),planned_callers=np['planned_callers'],actual_callers=len(node['rows']),phase_queries=sum(len(r['phases'])for r in node['rows']),missing=node['missing'],first_q4_non_time_mismatches=node['mismatches'],seconds=node['seconds'],time_censored_phases=sum(ph['result']['termination_reason']=='time_budget'for r in node['rows']for ph in r['phases']),by_mode={})
for mode in['q4','lazy_backup','upfront_cap2']:
 rows=[r for r in node['rows']if r['mode']==mode];out['fixed_node_controls']['by_mode'][mode]=dict(callers=len(rows),selected_sources=dict(Counter(r['selected_source']for r in rows)),selected_depths=dict(Counter(r['selected']['completed_depth']for r in rows)),actual_outer_seconds=sum(r['actual_call_seconds']for r in rows),total_main_plus_q=sum(r['total_nodes']for r in rows),action_differences_from_q4=sum(r['selected']['action']!=next(b['selected']['action']for b in node['rows']if b['root_id']==r['root_id']and b['order']==r['order']and b['mode']=='q4')for r in rows))
wide=read('wide-results.json');assert wide['complete']
out['larger_boards']=dict(callers=len(wide['rows']),missing=wide['missing'],phase_queries=sum(len(r['phases'])for r in wide['rows']),seconds=wide['seconds'],by_board_mode=[])
for n in[12,16]:
 for mode in['q4','lazy_backup']:
  rows=[r for r in wide['rows']if r['n']==n and r['mode']==mode];out['larger_boards']['by_board_mode'].append(dict(n=n,mode=mode,callers=len(rows),selected_sources=dict(Counter(r['selected_source']for r in rows)),retained_depths=dict(Counter(r['selected']['completed_depth']for r in rows)),phase_reasons=dict(Counter(ph['result']['termination_reason']for r in rows for ph in r['phases'])),execution_disallowed=sum(not r['execution_allowed']for r in rows),max_actual_outer_seconds=max(r['actual_call_seconds']for r in rows),action_differences_from_q4=sum(r['selected']['action']!=next(b['selected']['action']for b in wide['rows']if b['seed']==r['seed']and b['ply']==r['ply']and b['order']==r['order']and b['mode']=='q4')for r in rows)))
if(P/'q0-completion.json').exists():
 qdone=read('q0-completion.json');assert qdone['complete']and len(qdone['games'])==16
 counts=Counter();bc=Counter();trans=Counter();pairs=[];families=[];calls=[];cost=0
 old=read('policy-completion.json')
 for seed in range(8311,8319):
  bm=next(g for g in old['games']if g['seed']==seed and g['mode']=='q4');base=read(f'policy-{seed}-q4.json');fd=0
  for role in[0,1]:
   meta=next(g for g in qdone['games']if g['seed']==seed and g['role']==role);bs=status(bm,role);vs=status(meta,role);bc[bs]+=1;counts[vs]+=1;trans[bs+'->'+vs]+=1;payoff={'WIN':1,'LOSS':-1,'DRAW':0,'UNKNOWN':0};delta=payoff[vs]-payoff[bs];fd+=delta;pair=dict(seed=seed,role=role,baseline=bs,candidate=vs,finite_event_delta=delta,candidate_kind=meta['kind'])
   if'result'in meta:
    var=read(f'q0-{seed}-role{role}.json');pair['first_difference']=first_difference(base,var,role);pair['candidate_seconds']=var['seconds'];pair['baseline_seconds']=base['seconds'];calls.extend(r for r in var['rows']if'phases'in r);cost+=var['seconds']
   pairs.append(pair)
  families.append(fd/2)
 out['q0_component']=dict(scope='Posthoc EXPOSED component baseline on all original eight families/two roles, existing q4 control reused. Not new validation or changed old outcomes.',planned_games=16,actual_games=sum('result'in g for g in qdone['games']),missing=[g for g in qdone['games']if'result'not in g],seconds=qdone['seconds'],physical_edges=sum(g.get('edges',0)for g in qdone['games']),baseline_counts={k:bc[k]for k in('WIN','LOSS','DRAW','UNKNOWN')},candidate_counts={k:counts[k]for k in('WIN','LOSS','DRAW','UNKNOWN')},transitions=dict(trans),finite_event_net_delta=sum(p['finite_event_delta']for p in pairs),mean_delta_per_role=sum(families)/8,family_bootstrap_95=bootstrap(families),pairs=pairs,actual_phase_queries=sum(len(r['phases'])for r in calls),actual_game_seconds=cost,selected_sources=dict(Counter(r['selected_source']for r in calls)),execution_disallowed=sum(not r['execution_allowed']for r in calls))

out['measurement_scope']=read('measurement-scope.json')
out['limits']=['UNKNOWN contributes zero only to observed finite W-L statistic, not a draw or missing-outcome imputation. All categorical transitions remain explicit.','No cross-objective score selection, price changes, cap extensions, human labels, extra agents or AUX write/solver duplication.','Normal Native source unchanged; counters and changed-horizon image are private explicit-backend diagnostics.','Own concurrent diagnostics overlap some prospective callers; frozen caps remain, clocks are environment-specific.','Full source-only receipt replay is separate from search/game rerun and independent rules/WDL validation.']
(P/'summary.json').write_bytes(json.dumps(out,indent=2).encode());print(json.dumps({k:v for k,v in out.items()if k not in('initial_by_root','forced_actions','reconstruction','static_horizon','prospective_policy')},indent=2))
if 'prospective_policy'in out:print('POLICY',json.dumps({k:{x:y for x,y in v.items()if x not in('pairs','common_prefix_requested_displacements')}for k,v in out['prospective_policy']['by_policy'].items()},indent=2))
