from pathlib import Path
import json,sys,time
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)]
import probe as p
import node_schedule as n
from generic_chess.session.serialization import deserialize_game_record
a=p.a;plan=json.loads((P/'node-plan.json').read_bytes());start=time.perf_counter();rows=[];missing=[];mismatches=[]
for parent in plan['parents']:
 d=json.loads((P/'roots'/f"{parent['root_id']}.json").read_bytes());raw=a.p.compile_legacy_ruleset_for_semantic_execution(a.deserialize_ruleset(json.dumps(d['ruleset'])));c=a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=a.GameSession.replay(c,deserialize_game_record(json.dumps(d['game_record'])));assert p.digest(s)==parent['before_sha256'];nr=a.nc.compile_native_semantic_rules(c,backend_module=p.m)
 for order,modes in enumerate(plan['orders']):
  for mode in modes:
   p.stopped()
   if time.perf_counter()-start>=plan['whole_seconds']:missing.append(dict(root_id=parent['root_id'],mode=mode,order=order,kind='WHOLE_CAP_NOT_STARTED'));continue
   outer=time.perf_counter();row,r,objs=n.schedule(s,nr,d['board_values'],d['hand_values'],mode);actual_call_seconds=time.perf_counter()-outer;row.update(actual_call_seconds=actual_call_seconds,root_id=parent['root_id'],order=order,before_sha256=parent['before_sha256'],node_cap=plan['node_cap'],caller_budget=plan['caller_budget']);row['phase_pv_edges']=[a.audit(s,nr,ob)for ob in objs];assert row['total_nodes']<=plan['node_cap'];rows.append(row)
   print(parent['root_id'],order,mode,[(ph['result']['completed_depth'],ph['result']['termination_reason'])for ph in row['phases']],row['selected_source'],round(row['caller_seconds'],3),flush=True)
  pair=[x for x in rows if x['root_id']==parent['root_id']and x['order']==order and x['mode']in('q4','lazy_backup')]
  if len(pair)==2:
   rr=[x['phases'][0]['result']for x in pair if x['phases']]
   if len(rr)==2 and all(r['termination_reason']!='time_budget'for r in rr):
    clean=[{k:v for k,v in r.items()if 'elapsed'not in k}for r in rr]
    if clean[0]!=clean[1]:mismatches.append(dict(root_id=parent['root_id'],order=order,keys=[k for k in clean[0]if clean[0][k]!=clean[1][k]]))
  p.save('node-results-partial.json',dict(complete=False,rows=rows,missing=missing,mismatches=mismatches,seconds=time.perf_counter()-start))
p.save('node-results.json',dict(complete=True,rows=rows,missing=missing,mismatches=mismatches,seconds=time.perf_counter()-start));print('NODES_ALL_CLOSED',len(rows),len(missing),mismatches,time.perf_counter()-start,flush=True)
