from pathlib import Path
import sys,json,hashlib
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)]
import probe as p
import policy_games as pg
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.serialization import serialize_game_record
D=P/'roots';D.mkdir(exist_ok=True)
for name,loader in [(str(i),lambda i=i:p.load(i))for i in range(3)]+[(str(seed),lambda seed=seed:pg.load_new(seed))for seed in range(8311,8319)]:
 s,nr,bv,hv=loader()
 out=dict(root_id=name,ruleset=json.loads(((p.B/'fresh-inputs/6311.json')if name in('0','1')else(p.a.O/'transfer-inputs/4323.json')if name=='2'else(P/'policy-inputs'/f'{name}.json')).read_bytes())['ruleset'],game_record=json.loads(serialize_game_record(s.to_record())),state=p.a.record_value(s.state),before_sha256=p.digest(s),board_values=bv,hand_values=hv)
 (D/f'{name}.json').write_bytes(json.dumps(out,indent=2).encode());print(name,len(s._search_witnesses),p.digest(s))
