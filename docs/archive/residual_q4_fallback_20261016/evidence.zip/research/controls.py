from pathlib import Path
import sys,json,time,threading
from dataclasses import dataclass
from types import SimpleNamespace
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)];import probe as p
@dataclass
class Result:
 action:str|None='A'
 completed_depth:int=1
 result_source:str='main_iteration'
 result_ordinary_qdepth:int=0
 result_check_hard_qdepth:int=0
 immediate_win:bool=False
 termination_reason:str='qsearch_check_hard_limit'
 nodes:int=10
 qnodes:int=20
 score:int=999999
class Clock:
 def __init__(self):self.t=0.
 def __call__(self):return self.t
checks=[]
def run(label,results,mode='lazy_backup',after=None,dt=.1):
 clock=Clock();limits=[]
 class Engine:
  def __init__(self,*args,**kw):pass
  def search(self,s,lim,**kw):
   limits.append(lim);clock.t+=dt;return results[len(limits)-1]
 row,chosen,objs=p.schedule(SimpleNamespace(compiled=None),None,{}, {},mode,clock=clock,factory=Engine,after_phase=after)
 checks.append(dict(label=label,row=row,passed=True));return row,chosen,limits
r,c,ls=run('requested_policy_survives_later_hardstop',[Result(completed_depth=2,result_ordinary_qdepth=4,result_check_hard_qdepth=8)]);assert len(ls)==1 and r['selected_source']=='requested_q4'
r,c,ls=run('actual_residual_main_plus_q_deducted',[Result(nodes=400000,qnodes=599990),Result(action='B',completed_depth=2,nodes=5,qnodes=0,score=-999999)]);assert ls[1].max_nodes==10 and r['total_nodes']==999995 and c.action=='B'and r['selected_source']=='disabled_backup'
r,c,ls=run('time_expired_first_is_not_hardstop_trigger',[Result(termination_reason='time_budget')]);assert len(ls)==1 and c.action=='A'
r,c,ls=run('physical_win_D0_not_partial_policy',[Result(completed_depth=0,result_source='verified_root_child',immediate_win=True)]);assert len(ls)==1 and r['selected_source']=='physical_win'
r,c,ls=run('cancel_between_phases_forbids_execution',[Result()],after=lambda i,r,t:t.cancel());assert len(ls)==1 and r['cancelled']and not r['execution_allowed']
r,c,ls=run('outer_atomic_overrun_forbids_execution',[Result()],dt=1.2);assert len(ls)==1 and not r['execution_allowed']and r['overrun_seconds']>0
r,c,ls=run('total_nodes_exhaustion_forbids_second',[Result(nodes=100,qnodes=999900)]);assert len(ls)==1 and r['total_nodes']==1000000
r,c,ls=run('upfront_retains_reserve_if_requested_incomplete',[Result(action='A',completed_depth=2),Result(action='B')],mode='upfront_cap2');assert len(ls)==2 and c.action=='A'
r,c,ls=run('upfront_requested_completion_overrides_reserve',[Result(action='A',completed_depth=2),Result(action='B',completed_depth=2,result_ordinary_qdepth=4,result_check_hard_qdepth=8)],mode='upfront_cap2');assert c.action=='B'and r['selected_source']=='requested_q4'
native=[]
for ci in[0,1]:
 s,nr,bv,hv=p.load(ci);before=p.digest(s);token=p.a.CancellationToken();timer=threading.Timer(.02,token.cancel);timer.start()
 try:row,r,objs=p.schedule(s,nr,bv,hv,'lazy_backup',token=token)
 finally:timer.cancel();timer.join()
 assert row['cancelled']and not row['execution_allowed']and len(row['phases'])==1 and p.digest(s)==before
 row['phase_pv_edges']=[p.a.audit(s,nr,r)for r in objs];native.append(dict(case_index=ci,row=row))
p.save('control-results.json',dict(complete=True,logic_checks=checks,actual_timer_cancellations=native,scope='Nine deterministic outer-scheduler fault/selection controls plus two actual Native20ms cancellations. Timer reaches actual running search, not instruction-exact injection. Not full product rerun.'))
print('PASS',len(checks),len(native))
