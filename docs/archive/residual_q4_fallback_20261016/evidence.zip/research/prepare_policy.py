from pathlib import Path
import sys,json,time,hashlib,random
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)]
import probe as p
from generic_chess.generation.generator import generate_game
from generic_chess.generation.config import GeneratorConfig
from generic_chess.rules.serialization import serialize_ruleset
plan=dict(question='Does conditional q4-first disabled-q backup change actual finite fixed-opponent outcomes per total cost on newly generated roots?',selection='Eight generator seeds8311..8318, board8, bilateral_random/hybrid/32attempts, canonical sorted Random(seed+29000) walk8; keep all failures/terminal tails with no replacements. No search-based root filtering.',
modes=['q4','lazy_role0','upfront_role0','upfront_role1','lazy_role1'],horizon=64,game_seconds=120,whole_seconds=2700,estimated_seconds=1800,max_games=40,common_caller_seconds=1.,common_nodes=1000000,margin=.02,source_commit='e583f0a7772d2d19498e6db5ba26075f951b235f',
comparison='Single baseline actual game per root reused as fixed-opponent control for both candidate roles. Each other game changes only indicated actor schedule; opponent q4 always. This is method diagnosis, not Elo/default/unique-WDL/independent holdout claim.',
unknown='Missing planned roots/games, run limits, no actionable result and nonterminal horizon stay UNKNOWN. No extensions or substitutions.',
decision='Retain lazy as research-only unless both finite consequence and totalcost support it. Upfront comparator can protect exposed time-negative control but previously displaced requested q; no universal policy.',
cost='Expected30min, hard45min/one process; no >1hour run, no extraAgent/fees. Cheaper initial18queries already show residual completion but cannot measure finite event consequences.',
generator=dict(setup_preset='bilateral_random',allow_hybrid=True,max_generation_attempts=32),seeds=list(range(8311,8319)))
p.save('policy-plan.json',plan);D=P/'policy-inputs';D.mkdir(exist_ok=True);start=time.perf_counter();inputs=[]
for seed in plan['seeds']:
 p.stopped();t=time.perf_counter();row=dict(seed=seed,walk=[],root=None,terminal_tail=None)
 try:
  game=generate_game(GeneratorConfig(seed=seed,board_size=8,**plan['generator']));row['ruleset']=json.loads(serialize_ruleset(game.ruleset));raw=p.a.p.compile_legacy_ruleset_for_semantic_execution(game.ruleset);c=p.a.p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=p.a.GameSession(c);rng=random.Random(seed+29000)
  for ply in range(9):
   if s.result.status.value!='ongoing':row['terminal_tail']=dict(ply=ply,state=p.a.record_value(s.state));break
   if ply==8:row['root']=dict(ply=ply,state=p.a.record_value(s.state),walk=row['walk'].copy());break
   act=rng.choice(sorted(s.legal_actions(),key=repr));s.submit(act);row['walk'].append(p.a.record_value(act))
  row['state']='FROZEN_NO_SEARCH'
 except Exception as e:row.update(state='INPUT_FAILURE',error=repr(e))
 row['input_seconds']=time.perf_counter()-t;path=D/f'{seed}.json';path.write_bytes(json.dumps(row,indent=2).encode());inputs.append(dict(seed=seed,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),state=row['state'],has_root=row['root']is not None,input_seconds=row['input_seconds']));print(seed,row['state'],row['root']is not None,round(row['input_seconds'],4),flush=True)
p.save('policy-input-manifest.json',dict(complete=True,search_queries=0,inputs=inputs,seconds=time.perf_counter()-start,plan_sha256=hashlib.sha256((P/'policy-plan.json').read_bytes()).hexdigest()))
