from pathlib import Path
import json,sys,hashlib,inspect
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)];import probe as p;import policy_games as pg
from generic_chess.session.serialization import serialize_game_record
done=json.loads((P/'policy-completion.json').read_bytes());assert done['complete']and len(done['games'])==40
parents={};comparisons=[]
for seed in range(8311,8319):
 bpath=P/f'policy-{seed}-q4.json'
 if not bpath.exists():continue
 base=json.loads(bpath.read_bytes())
 for policy in['lazy','upfront']:
  for role in[0,1]:
   path=P/f'policy-{seed}-{policy}_role{role}.json'
   if not path.exists():continue
   var=json.loads(path.read_bytes());prefix=[]
   for b,v in zip(base['rows'],var['rows']):
    assert b['before_sha256']==v['before_sha256']
    if b.get('action')!=v.get('action'):
     key=b['before_sha256'];parent=parents.setdefault(key,dict(root_id='node-'+str(len(parents)),seed=seed,ply=b['ply'],before_sha256=key,baseline_prefix=prefix.copy(),references=[]))
     parent['references'].append(dict(policy=policy,role=role,first_actor=v['actor'],candidate_owner=v['owner'],baseline_action=b.get('action'),candidate_action=v.get('action')));break
    if 'action'in b:prefix.append(b['action'])
   else:comparisons.append(dict(seed=seed,policy=policy,role=role,kind='NO_DIFFERENT_ACTION_AT_COMMON_PREFIX'))
for key,parent in parents.items():
 s,nr,bv,hv=pg.load_new(parent['seed'])
 for act in parent['baseline_prefix']:s.submit(next(a for a in s.legal_actions()if p.a.record_value(a)==act))
 assert p.digest(s)==key
 rules=json.loads((P/'policy-inputs'/f"{parent['seed']}.json").read_bytes())['ruleset']
 record=dict(root_id=parent['root_id'],ruleset=rules,game_record=json.loads(serialize_game_record(s.to_record())),state=p.a.record_value(s.state),before_sha256=key,board_values=bv,hand_values=hv)
 (P/'roots'/f"{parent['root_id']}.json").write_bytes(json.dumps(record,indent=2).encode())
plan=dict(question='Do all first physical action divergences from the prospective policy run persist under a shared fixed total-node budget, or are they timing-mediated?',scope='EXPOSED mechanism controls on ALL common-prefix first divergences across both methods/roles, no outcome filtering. No new games, untouched validation or WDL. Missing/identical paths retained.',changed_premise='Clock-limited game outcomes alone cannot distinguish scheduler changes from different partial trees under concurrent load. An opposite fixed-work result would restrict causal algorithm attribution.',
parents=list(parents.values()),no_action_difference=comparisons,orders=[['q4','lazy_backup','upfront_cap2'],['upfront_cap2','lazy_backup','q4']],node_cap=65536,caller_budget=6.,margin=.02,upfront_depth=2,upfront_wall_cap=.25,depth=16,q=4,hard_q=8,whole_seconds=600,expected_seconds=180,planned_callers=len(parents)*6,selection='Requested q4/physical win priority and same cancellation; total main+q shared across phases. No score comparisons. Keep any actual time censors, including .25s upfront reserve, and do not call those deterministic fixed-work results.',
cheaper='Existing first-divergence source receipts locate the intervention but do not remove clock-censoring; no additional outcome games are needed.')
(P/'node-plan.json').write_bytes(json.dumps(plan,indent=2).encode())
src=inspect.getsource(p.schedule)
src=src.replace('deadline=start+1.;','deadline=start+6.;').replace('1000000','65536').replace('max(0,seconds-1.)','max(0,seconds-6.)')
assert 'deadline=start+6.;'in src
header="from probe import *\n"
(P/'node_schedule.py').write_bytes((header+src).encode())
plan['producer_sha256']=hashlib.sha256((P/'node_controls.py').read_bytes()).hexdigest();plan['scheduler_sha256']=hashlib.sha256((P/'node_schedule.py').read_bytes()).hexdigest();(P/'node-plan.json').write_bytes(json.dumps(plan,indent=2).encode());print('FROZEN',len(parents),plan['planned_callers'],len(comparisons))
