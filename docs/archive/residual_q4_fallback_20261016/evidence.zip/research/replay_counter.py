from pathlib import Path
import sys,json,time,importlib.util
R=Path.cwd();P=R/'.local_agent/residual-q4-20261016';sys.path[:0]=[str(R),str(P)]
import probe as p
a=p.a;plan=json.loads((P/'replay-counter-plan.json').read_bytes())
spec=importlib.util.spec_from_file_location('replay_counter._native_core',P/'replay_counter_native_core.pyd');counter=importlib.util.module_from_spec(spec);spec.loader.exec_module(counter)
mods=dict(normal=p.m,counter=counter);raws={}
for name,m in mods.items():
 orig=m.semantic_engine_search
 def wrap(*args,_orig=orig,_name=name,**kw):
  x=_orig(*args,**kw);raws[_name]=x;return x
 m.semantic_engine_search=wrap
rows=[];mismatches=[];start=time.perf_counter()
for ci in plan['cases']:
 s,_,bv,hv=p.load(ci);nrs={name:a.nc.compile_native_semantic_rules(s.compiled,backend_module=m)for name,m in mods.items()}
 for co in plan['conditions']:
  for order,names in enumerate(plan['orders']):
   for name in names:
    p.stopped()
    if time.perf_counter()-start>=plan['whole_seconds']:raise TimeoutError('frozen counter cap')
    t=time.perf_counter();e=a.SemanticSearchEngine(s.compiled,nrs[name],board_values=bv,hand_values=hv,tt_megabytes=0,ordering_cache_enabled=False)
    r=e.search(s,a.SearchLimits(max_depth=co['depth'],max_nodes=plan['nodes'],max_time_seconds=plan['seconds'],quiescence_max_depth=co['q'],quiescence_hard_max_depth=8),root_window_pruning=True,stop_on_immediate_win=True)
    row=dict(case_index=ci,condition=co,order=order,arm=name,result=a.record_value(r),raw=a.record_value(raws[name]),seconds=time.perf_counter()-t,pv_edges=a.audit(s,nrs[name],r));rows.append(row)
    print(ci,co,order,name,r.completed_depth,r.termination_reason,row['raw'].get('probe_replay_total'),row['raw'].get('probe_replay_ns'),round(row['seconds'],4),flush=True)
   pair=rows[-2:];vals=[{k:v for k,v in z['result'].items()if 'elapsed'not in k}for z in pair]
   if vals[0]!=vals[1]:mismatches.append(dict(case_index=ci,condition=co,order=order,keys=[k for k in vals[0]if vals[0][k]!=vals[1][k]]))
p.save('replay-counter-results.json',dict(complete=True,rows=rows,mismatches=mismatches,seconds=time.perf_counter()-start));print('DONE',len(rows),mismatches,time.perf_counter()-start,flush=True)
