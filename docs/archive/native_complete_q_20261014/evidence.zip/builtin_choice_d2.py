from pathlib import Path
import sys,json,time,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from scripts import search_backend_comparison as ref
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta import search
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
base=ROOT/'.local_agent/neutral-order-20261014';out=base/'builtin-choice-D2';out.mkdir(exist_ok=True)
d=json.loads((base/'builtin-q4/rows.json').read_text(encoding='utf-8'));assert d['complete'];assert not(out/'rows.json').exists()
selection={}
for r in d['rows']:
 if r['mode']!='resource' or r['result']['action'] is None:continue
 key=(r['root'],json.dumps(r['result']['action'],sort_keys=True));selection.setdefault(key,dict(root=r['root'],action=r['result']['action'],origins=[]))['origins'].append(dict(seconds=r['seconds'],order=r['order'],arm=r['arm'],depth=r['result']['completed_depth'],retained_ordinary_qdepth=r['result']['result_ordinary_qdepth']))
write_record(out/'declaration.json',dict(question='Do actualdifferentbudget choices retain same/different commonD2-q4 objective under independentliteralCore continuation?',selection='ALL distinctselectedboardactions acrossall4roots/resource16+64/twoorders/botharms, nofavorablefilter',common_objective='FixedrootD2: afterselectedaction literalCore negamaxD1 withordinaryq4/hard8 andphasealreadycompleteTrue; rootrelativeply1, same frozenVALUES staticboard/hand. NoNativeprovider/TT/order/tactical. This isapproxqfiniteobjective, NOTWDL/winrates/completeallrootmaxset.',cost='Eachdistinctbranch20s or100000totalvisits, noextension. Expected<3min onejob, external300sfuse if<=12unique; abortbeforeotherwise. Anycensor UNKNOWN. Decision: conditionalrank/ties vsrootissue canchangeusefulnessclaim, notentrygateforCcapability.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=list(selection.values())))
assert len(selection)<=12
compiled={g:compile_ruleset_for_execution(build_builtin_ruleset(n)) for g,n in [('chess','western_chess'),('shogi','standard_shogi')]};roots={}
for case in ref.CASES:
 if case['id'] not in {x[0]for x in selection}:continue
 c=compiled[case['game']];b=ref.CoreBoard(case,c);roots[case['id']]=(c,b,ref.Material(case['game']))
rows=[]
for (name,_),item in selection.items():
 p.rr.stopped();c,b,ev=roots[name];a,=[a for a in legal_actions(b.initial,c) if record_value(a)==item['action']];child=apply_action(b.initial,a,c);rt=SearchPathRuntime.from_state(child,c,history_witnesses=b.witnesses+(child.position,));stats=SearchStatistics();rt.attach_stats(stats);lim=SearchLimits(max_time_seconds=20,max_nodes=100000,quiescence_max_depth=4,quiescence_hard_max_depth=8);ctx=search._Context(c,ev,TranspositionTable(),stats,search._Budget(lim,None),SearchTuning(use_root_tactical=False),False,False,4,8,None,runtime=rt,first_main_iteration_complete=True);start=time.perf_counter()
 try:
  answer=search.negamax(rt.state,1,-search.INF,search.INF,1,ctx);row=dict(**item,complete=True,root_value=-answer.score,child_answer=record_value(answer))
 except search.SearchAborted as error:row=dict(**item,complete=False,unknown_reason=str(error))
 finally:rt.assert_balanced()
 row.update(seconds=time.perf_counter()-start,nodes=stats.nodes,qnodes=stats.qnodes,runtime_balanced=True);rows.append(row);write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,row.get('root_value'),row.get('unknown_reason'),round(row['seconds'],3),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))

