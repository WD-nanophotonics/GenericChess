from pathlib import Path
import sys,json,time,hashlib,importlib.util
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
import generic_chess.native as native
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
base=ROOT/'.local_agent/neutral-order-20261014';out=base/'q-hard-retry';out.mkdir(exist_ok=True)
data=json.loads((base/'generic-q4/samples.json').read_text(encoding='utf-8'));prior=json.loads((base/'generic-q4/rows.json').read_text(encoding='utf-8'));assert prior['complete'];assert not(out/'declaration.json').exists()
hard={r['root']for r in prior['rows']if r.get('result',{}).get('termination_reason')=='qsearch_check_hard_limit' and r['arm']=='FullNativeQ'}
unsupported={r['root']for r in prior['rows']if 'unsupported'in r};allnames=sorted(x['name']for x in data['samples']if x.get('included'));controls=[n for n in allnames if n not in hard|unsupported][:2];names=sorted(hard|unsupported|set(controls))
assert len(names)<=32
spec=importlib.util.spec_from_file_location('generic_chess._native_core',base/'q_candidate2.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
write_record(out/'declaration.json',dict(question='Can a private interface spend the remaining caller budget on Core only after Native q-hard censorship, instead of treating it as final?',selection='ALL uniqueNativeq-hard roots fromclosedgenericdataset +ALLunsupported18 +first2lexicalnontriggercontrols. Exposeddiagnosticcohort, notnewholdout orweightfit.',hard=sorted(hard),unsupported=sorted(unsupported),controls=controls,roots=names,methods=['Core','Native','RetryOnHard'],resource='cooperative1/4s remaining-caller allocation, startbeforeconstructor, subtractactualtimebeforeeachsearch; finalPV/uninterruptiblefallbackcanovershoot, actualcallerwallreported. BothTT0/orderoff/q4hard8/main12, samefrozenstaticprofile/fullGameRecord; directcontrolsre-runbecausecallerresourcecondition differsfromprior kernelbudget, nottimingcleanup.',selection_rule='Core retry onlyifNativehardlimit andtimeleft, orcompileknownunsupported; retainNative positiveMate estimate conservatively. ReplaceNative resultonlywithgreateruniform completeddepth, Core main_iteration source andcompatible/higherordinaryqpolicy; otherwisekeepNative. No WDLclaim, noerrorhiding, no newpublicoption/default/TTsharing.',cost=f'{len(names)}roots*3methods*2budgets*2orders: callerupper~{30*len(names)}s +cooperativeoverhead, external1200sfuse, oneproducer; possibleoutcomes changewhethera backendfallbackprototypeisworthfurtherindependentvalidation.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),prior_rows_sha256=hashlib.sha256((base/'generic-q4/rows.json').read_bytes()).hexdigest(),DLL_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()))
profiles={r['seed']:r['profile']for r in data['setup']};cases=[]
class Static:
 def __init__(self,z):self.v=z['board_value_by_type'];self.h=z['hand_value_by_base_type']
 def evaluate(self,st):
  z=st.position;side=z.side_to_move
  return sum((1 if x.owner==side else -1)*self.v[x.current_type_id]for x in z.board if x)+sum((1 if side==owner else -1)*self.h[tid]*n for owner,h in enumerate(z.hands)for tid,n in h.items())
 def type_value(self,tid):return self.v[tid]
 def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
for x in data['samples']:
 if x.get('name') not in names:continue
 raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 for av in x['walk']:
  a,=[a for a in s.legal_actions()if record_value(a)==av];s.submit(a)
 assert record_value(s.state)==x['state'];cases.append((x['name'],c,s,Static(profiles[x['seed']])))
rows=[]
for seconds in [1,4]:
 for order in range(2):
  for name,c,s,ev in (cases if order==0 else list(reversed(cases))):
   for method in (['Core','Native','RetryOnHard']if order==0 else ['RetryOnHard','Native','Core']):
    p.rr.stopped();before=s.state,s.to_record(),s._search_witnesses;start=time.perf_counter();calls=[];decline=None;selected=None;selected_from=None
    def run(arm):
     p.rr.stopped();t=time.perf_counter()
     if arm=='Core':e=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_check=True,use_native_semantic_availability=True,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True))
     else:e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=ev.v,hand_values=ev.h,tt_megabytes=0,ordering_cache_enabled=False)
     backend=('CoreNativeprovider' if e.native_legality_provider else 'CoreFALLBACK') if arm=='Core' else 'FullNativeq4candidate2'
     left=max(0.,seconds-(time.perf_counter()-start));lim=SearchLimits(max_depth=12,max_time_seconds=left,quiescence_max_depth=4,quiescence_hard_max_depth=8)
     d=e.choose_action(s,lim)if arm=='Core'else e.search(s,lim,root_window_pruning=True)
     if d.termination_reason=='internal_error':raise RuntimeError('Native internalerror mustnotbe hiddenbyfallback')
     calls.append(dict(arm=arm,actual_backend=backend,allocated_search_seconds=left,caller_seconds=time.perf_counter()-t,result=record_value(d)));return d
    if method=='Core':selected=run('Core');selected_from='Core'
    else:
     try:selected=run('Native');selected_from='Native'
     except NativeUnsupportedRuleError as error:decline=str(error)
     if method=='RetryOnHard' and (selected is None or selected.termination_reason=='qsearch_check_hard_limit') and (selected is None or selected.score<50_000_000) and time.perf_counter()-start<seconds:
      alternative=run('Core')
      if selected is None or (alternative.completed_depth>selected.completed_depth and alternative.result_source=='main_iteration' and (selected.result_ordinary_qdepth is None or alternative.result_ordinary_qdepth>=selected.result_ordinary_qdepth)):
       selected=alternative;selected_from='Core'
    assert before==(s.state,s.to_record(),s._search_witnesses)
    row=dict(root=name,seconds=seconds,order=order,method=method,caller_seconds=time.perf_counter()-start,calls=calls,native_unsupported=decline,selected_from=selected_from,result=None if selected is None else record_value(selected),root_unchanged=True);rows.append(row);write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,seconds,order,method,selected_from,None if selected is None else selected.completed_depth,len(calls),round(row['caller_seconds'],3),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))

