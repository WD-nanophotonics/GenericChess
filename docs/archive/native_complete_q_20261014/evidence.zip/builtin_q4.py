from pathlib import Path
import sys,json,time,hashlib,importlib.util
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from types import SimpleNamespace
from scripts import search_backend_comparison as ref
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native import SemanticSearchEngine
import generic_chess.native as native
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import snapshot
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
base=ROOT/'.local_agent/neutral-order-20261014';out=base/'builtin-q4';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
spec=importlib.util.spec_from_file_location('generic_chess._native_core',base/'q_candidate2.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
names=['chess-middle','chess-ep','shogi-middle','shogi-drop'];cases=[x for x in ref.CASES if x['id'] in names]
write_record(out/'declaration.json',dict(question='Does fullstate C q4/hard8 capability change useful completion versus supportedCore+Nativeproviders on existing Chess/Shogi middle,EP andrichdrop?',base='85954ff8a57207a8e32d45f32b846bce32568417 plus boundedq candidate2',premise='PubliccompleteNativepreviouslydeclinednonzeroq. Candidateq1smoke+144fixed andq4fixed144calls:68/60 supportedclosedscorepairs match. Newbackend capability, not oldunchangedcurve.',cases=cases,values=ref.VALUES,conditions='Actualsameflat frozenarbitraryweighted staticmaterial board/current hand/base; no dynamic/spatial/learned terms. CoreuseTTFalse/orderFalse/rootTacticalFalse, actualNativelegality/check/availability requested andrecorded. FullNativeTT0/ordercacheoff/rootwindowexact. q4/hard8 firstiterordinary0 reserve disclosed. maxmain12 fixedD2 before resource16/64seconds twooppositeorders. No nodecap.',scope='Methods/comparators/schedules differ; notpureCfactor orElo/WDL. FEN/SFEN declaredfreshanalysisroots and completeplayedwitnesses retained; nofakeGameRecord fromdefaultsetup. Corepublic PV andNativePVreplay completeinputhistory included. No task-domain shrink, UI/defaultbackend untouched.',cost='16fixedcalls <=160s plus32resourcecalls <=1280s; oneproducer external1620sfuse expected~23min, noextraAgent/fee. Incrementalinformation: whetherdefaultq4 capablereference justifies nextactualinterface comparison, not moreq0microoptimization.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),DLL_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()))
compiled={g:compile_ruleset_for_execution(build_builtin_ruleset(n)) for g,n in [('chess','western_chess'),('shogi','standard_shogi')]}
setup=[];roots=[]
for case in cases:
 c=compiled[case['game']];b=ref.CoreBoard(case,c);s=SimpleNamespace(compiled=c,state=b.initial,_search_witnesses=b.witnesses,result=b.initial.terminal_status)
 nr=compile_native_semantic_rules(c);snap=snapshot(nr,pack_semantic_search_position(c,nr,s));assert snap['history_exact'] and snap['history_events_exact'] and len(snap['history'])==len(b.initial.history)
 setup.append(dict(case=case['id'],ruleset_fingerprint=c.ruleset_fingerprint,state=record_value(s.state),witnesses=record_value(s._search_witnesses),native_snapshot=snap,initial_material=b.evaluate()))
 roots.append((case,c,s))
write_record(out/'setup.json',dict(complete=True,rows=setup));rows=[]
for mode,seconds,depth in [('fixed',10,2),('resource',16,12),('resource',64,12)]:
 for case,c,s in roots:
  for order in range(2):
   for arm in (('CoreNative','FullNativeQ') if order==0 else ('FullNativeQ','CoreNative')):
    # Existing project stop check, no second writer.
    p.rr.stopped()
    before=s.state,s._search_witnesses;t=time.perf_counter();ev=ref.Material(case['game'])
    lim=SearchLimits(max_depth=depth,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8)
    if arm=='CoreNative':
     player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_check=True,use_native_semantic_availability=True,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));prep=time.perf_counter()-t
     d=player.choose_action(s,lim);backend='Core Nativeprovider' if player.native_legality_provider else 'Core FALLBACK'
    else:
     engine=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=ref.VALUES[case['game']],hand_values=ref.VALUES[case['game']],tt_megabytes=0,ordering_cache_enabled=False);prep=time.perf_counter()-t
     d=engine.search(s,lim,root_window_pruning=True);backend='CompleteNativeq4candidate2'
    assert before==(s.state,s._search_witnesses)
    st=s.state
    for a in d.principal_variation:assert a in legal_actions(st,c);st=apply_action(st,a,c)
    rows.append(dict(root=case['id'],mode=mode,seconds=seconds,order=order,arm=arm,actual_backend=backend,prepare_seconds=prep,caller_seconds=time.perf_counter()-t,result=record_value(d),root_unchanged=True));write_record(out/'rows.json',dict(complete=False,rows=rows))
    print(case['id'],mode,seconds,order,arm,d.completed_depth,d.score,d.termination_reason,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))

