from pathlib import Path
import json
b=Path('.local_agent/neutral-order-20261014/q-prototype');d=json.loads((b/'fixed/rows.json').read_text(encoding='utf-8'));rows=d['rows'];pairs=[]
def norm(v):return v if abs(v)<50000000 else (1 if v>0 else -1)*(1000000000-(100000000-abs(v)))
for key in sorted({(r['root'],r['depth'],r['order']) for r in rows}):
 p={r['arm']:r for r in rows if (r['root'],r['depth'],r['order'])==key}
 if set(p)!= {'Core','NativeQ'}:continue
 if any('unsupported'in x for x in p.values()):continue
 a=p['Core']['result'];z=p['NativeQ']['result']
 complete=a['completed_depth']==key[1] and z['completed_depth']==key[1]
 pairs.append(dict(root=key[0],depth=key[1],order=key[2],complete=complete,score_equal=a['score']==norm(z['score']),core_score=a['score'],native_score=z['score'],core_reason=a['termination_reason'],native_reason=z['termination_reason'],core_depth=a['completed_depth'],native_depth=z['completed_depth']))
summary=dict(complete=d['complete'],actual_queries=sum('result'in r for r in rows),pairs=pairs,completed_pairs=sum(p['complete']for p in pairs),closed_mismatches=[p for p in pairs if p['complete'] and not p['score_equal']]);(b/'fixed/summary.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items() if k!='pairs'})

