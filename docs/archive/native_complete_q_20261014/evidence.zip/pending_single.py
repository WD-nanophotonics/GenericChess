from pathlib import Path
import sys,time,json,importlib.util
base=Path.cwd()/'.local_agent/neutral-order-20261014'
old=Path.cwd()/'.local_agent/full-backend-20261014';ns={'__file__':str(old/'compare.py'),'__name__':'loader'};exec(compile((old/'compare.py').read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(old/'compare.py'),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
import generic_chess.native as native
spec=importlib.util.spec_from_file_location('generic_chess._native_core',base/'q_candidate.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
name,c,s=next(x for x in load_cases() if x[0]=='2402-ply8');ev=Material(c);e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=ev.v,hand_values=ev.v,tt_megabytes=0,ordering_cache_enabled=False)
print('START NativeQ2402-ply8 D2 q4/hard8/10seconds',flush=True);t=time.perf_counter()
d=e.search(s,SearchLimits(max_depth=2,max_time_seconds=10,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True)
write_record(base/'pending-single-result.json',dict(complete=True,seconds=time.perf_counter()-t,result=record_value(d)));print(d.score,d.completed_depth,d.termination_reason,flush=True)

