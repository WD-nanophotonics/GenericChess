from pathlib import Path
import hashlib,json
base=Path('.local_agent/neutral-order-20261014');srcp=Path('generic_chess/_native/native_module.c');src=srcp.read_text(encoding='utf-8');(base/'pre-q-native_module.c').write_bytes(src.encode())
py=Path('generic_chess/native/semantic_engine.py');(base/'pre-q-semantic_engine.py').write_bytes(py.read_bytes())
def rep(a,b):
 global src
 assert src.count(a)==1,(a[:100],src.count(a))
 src=src.replace(a,b)
proto=(base/'q-prototype/native_module.c').read_text(encoding='utf-8');q=proto[proto.index('/* Private q1/hard4'):proto.index('static int gc_semantic_iterative_negamax(GCSemanticIterativeContext *ctx,')]
q=q.replace('/* Private q1/hard4 feasibility only. Full checked semantic transitions. */','/* Generic noisy extension: complete checked state/history, no reduced rules. */').replace('gc_private_inventory_changed','gc_semantic_inventory_changed').replace('gc_private_q','gc_semantic_quiescence').replace('private_qnodes','qnodes').replace('private_qordinary','ordinary_qdepth')
q=q.replace('qdepth>=4','qdepth>=ctx->qhard_depth')
needle='''    GCSemanticActionBuffer actions;gc_semantic_action_buffer_init(&actions);'''
assert q.count(needle)==1
q=q.replace(needle,'''    if(ctx->qnode_limit != UINT64_MAX && ctx->qnodes >= ctx->qnode_limit){
        ctx->control=6;return 0;
    }
    GCSemanticActionBuffer actions;gc_semantic_action_buffer_init(&actions);''')
rep('static int gc_semantic_iterative_negamax(GCSemanticIterativeContext *ctx,',q+'\nstatic int gc_semantic_iterative_negamax(GCSemanticIterativeContext *ctx,')
rep('    uint64_t nodes;\n    uint64_t max_nodes;', '    uint64_t nodes; /* total budget visits: main plus q */\n    uint64_t qnodes;\n    uint64_t qnode_limit;\n    unsigned qdepth_limit;\n    unsigned ordinary_qdepth;\n    unsigned qhard_depth;\n    uint64_t max_nodes;')
rep('        if (leaf_neutral > 0 && score < 0) score = 0;\n        gc_semantic_tt_store_node', '''        if (ctx->qdepth_limit > 0) {
            score = gc_semantic_quiescence(ctx, ply, 0, alpha, beta);
            if (ctx->control) return 0;
        }
        if (leaf_neutral > 0 && score < 0) score = 0;
        gc_semantic_tt_store_node''')
rep('    int ordering_min_depth = 1;\n    if (!PyArg_ParseTuple(args, "OOI|OOOOOOOOOIIOIOOOOOOOOIiiOO",','    int ordering_min_depth = 1;\n    unsigned int qdepth = 0, qhard_depth = 0;\n    PyObject *qmax_nodes_obj = Py_None;\n    if (!PyArg_ParseTuple(args, "OOI|OOOOOOOOOIIOIOOOOOOOOIiiOOIIO",')
rep('                          &policy_values, &trace_enabled_obj)) return NULL;','                          &policy_values, &trace_enabled_obj, &qdepth, &qhard_depth,\n                          &qmax_nodes_obj)) return NULL;')
needle='''    if (root_ply_offset > 1) {'''
rep(needle,'''    if (qdepth > qhard_depth || qhard_depth > GC_SEM_MAX_PLY ||
        (qdepth > 0 && max_depth > GC_SEM_MAX_PLY - qhard_depth)) {
        PyErr_SetString(PyExc_ValueError, "semantic q depths exceed the bounded search stack");
        return NULL;
    }
    uint64_t qnode_limit = UINT64_MAX;
    if (qmax_nodes_obj != Py_None) {
        qnode_limit = PyLong_AsUnsignedLongLong(qmax_nodes_obj);
        if (PyErr_Occurred()) return NULL;
    }
'''+needle)
rep('    ctx.max_nodes = max_nodes;','    ctx.qdepth_limit = qdepth;\n    ctx.qhard_depth = qhard_depth;\n    ctx.qnode_limit = qnode_limit;\n    ctx.max_nodes = max_nodes;')
rep('size_t levels = (size_t)max_depth + 2;','size_t levels = (size_t)max_depth + 2 + (qdepth > 0 ? qhard_depth : 0);')
rep('    Py_BEGIN_ALLOW_THREADS\n    for (uint32_t depth = 1; depth <= max_depth; depth++) {','''    uint64_t root_context_seed[4];
    memcpy(root_context_seed, ctx.history_context[0], sizeof(root_context_seed));
    Py_BEGIN_ALLOW_THREADS
    for (uint32_t depth = 1; depth <= max_depth; depth++) {
        ctx.ordinary_qdepth = depth == 1 ? 0 : qdepth;
        memcpy(ctx.history_context[0], root_context_seed, sizeof(root_context_seed));
        if (qdepth > 0) {
            /* First-iteration ordinary-q0 reserve and later q extensions have
             * different finite objectives, including across warm engine calls. */
            ctx.history_context[0][2] ^= UINT64_C(0x717365617263682d) ^ qdepth;
            ctx.history_context[0][3] ^= ((uint64_t)qhard_depth << 32) ^
                ((uint64_t)ctx.ordinary_qdepth << 16) ^ UINT64_C(0x72657365727665);
        }''')
rep('    else if (ctx.control == 4) reason = "internal_error";','    else if (ctx.control == 4) reason = "internal_error";\n    else if (ctx.control == 5) reason = "qsearch_check_hard_limit";\n    else if (ctx.control == 6) reason = "qsearch_budget";')
rep('"nodes", ctx.nodes,\n        "completed_depth"','"nodes", ctx.nodes - ctx.qnodes,\n        "completed_depth"')
rep('"qnodes", (uint64_t)0,','"qnodes", ctx.qnodes,')
rep('    PyObject *trace_enabled = Py_False;\n    if (!PyArg_ParseTuple(args, "OOI|OOOOOO",','    PyObject *trace_enabled = Py_False;\n    unsigned int qdepth = 0, qhard_depth = 0;\n    PyObject *qmax_nodes = Py_None;\n    if (!PyArg_ParseTuple(args, "OOI|OOOOOOIIO",')
rep('                          &trace_enabled)) return NULL;','                          &trace_enabled, &qdepth, &qhard_depth, &qmax_nodes)) return NULL;')
rep('PyObject *call_args = PyTuple_New(29);','PyObject *call_args = PyTuple_New(32);')
rep('    engine->busy = 1;\n    PyObject *result = gc_semantic_iterative_search(','''    PyTuple_SET_ITEM(call_args, 29, PyLong_FromUnsignedLong(qdepth));
    PyTuple_SET_ITEM(call_args, 30, PyLong_FromUnsignedLong(qhard_depth));
    Py_INCREF(qmax_nodes); PyTuple_SET_ITEM(call_args, 31, qmax_nodes);
    engine->busy = 1;
    PyObject *result = gc_semantic_iterative_search(''')
rep('    Py_INCREF(gc_native_error);\n    PyModule_AddObject(module, "NativeActionError", gc_native_error);','''    Py_INCREF(gc_native_error);
    PyModule_AddObject(module, "NativeActionError", gc_native_error);
    if (PyModule_AddIntConstant(module, "SEMANTIC_QSEARCH_VERSION", 1) < 0) {
        Py_DECREF(module);
        return NULL;
    }''')
srcp.write_bytes(src.encode())
t=py.read_text(encoding='utf-8');old='''        if limits.quiescence_max_depth != 0 or limits.quiescence_max_nodes not in (None, 0):
            raise ValueError("SemanticSearchEngine does not implement qsearch")'''
new='''        for name in ("quiescence_max_depth", "quiescence_hard_max_depth"):
            value = getattr(limits, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a non-negative integer")
        if limits.quiescence_max_nodes is not None and (
            isinstance(limits.quiescence_max_nodes, bool)
            or not isinstance(limits.quiescence_max_nodes, int)
            or limits.quiescence_max_nodes < 0
        ):
            raise ValueError("quiescence_max_nodes must be a non-negative integer")
        q_args = ()
        if limits.quiescence_max_depth > 0:
            if getattr(_module(), "SEMANTIC_QSEARCH_VERSION", 0) < 1:
                raise ValueError("SemanticSearchEngine qsearch requires a rebuilt Native kernel")
            if limits.max_depth + limits.quiescence_hard_max_depth > GC_SEM_MAX_PLY:
                raise ValueError("main and hard q depth exceed the bounded Native stack")
            q_args = (limits.quiescence_max_depth, limits.quiescence_hard_max_depth,
                      limits.quiescence_max_nodes)'''
assert t.count(old)==1;t=t.replace(old,new)
needle='''                trace_enabled,
            ))''';assert t.count(needle)==1;t=t.replace(needle,'''                trace_enabled,
                *q_args,
            ))''');py.write_bytes(t.encode())
(base/'q-candidate-source.json').write_text(json.dumps(dict(base='85954ff8a57207a8e32d45f32b846bce32568417',scope='Candidateonly untilvalidation; q0legacycall retains no appendedargs, oldkernelnonzeroqexplicitrebuilderror. No defaultbackend/UI switch. qfirstreserve/normal/configTTcontext separated; allcheckedsemanticstate/history. PendingCoreq4,coldwarmTT,hard/qnode/total/cancel/PV checks.',C_sha256=hashlib.sha256(src.encode()).hexdigest()),indent=2)+'\n')
print('candidate written; needs build+verification')

