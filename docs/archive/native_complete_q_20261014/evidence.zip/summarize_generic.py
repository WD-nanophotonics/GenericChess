from pathlib import Path
import json,collections
b=Path('.local_agent/neutral-order-20261014/generic-q4');d=json.loads((b/'rows.json').read_text(encoding='utf-8'));rows=d['rows'];pairs=[]
def norm(v):return v if abs(v)<50000000 else (1 if v>0 else -1)*(1000000000-(100000000-abs(v)))
for key in sorted({(r['root'],r['mode'],r['seconds'],r['order']) for r in rows}):
 p={r['arm']:r for r in rows if (r['root'],r['mode'],r['seconds'],r['order'])==key}
 if set(p)!={'CoreNative','FullNativeQ'} or any('unsupported'in x for x in p.values()):continue
 a,z=p['CoreNative']['result'],p['FullNativeQ']['result']
 core_decl=None if a.get('declaration') is None else a['declaration']['declaration_id']
 closed=key[1]=='fixed' and a['completed_depth']==z['completed_depth']==2
 sameq=a.get('result_ordinary_qdepth') is not None and (a.get('result_ordinary_qdepth'),a.get('result_check_hard_qdepth'))==(z.get('result_ordinary_qdepth'),z.get('result_check_hard_qdepth'))
 pairs.append(dict(root=key[0],mode=key[1],seconds=key[2],order=key[3],closed_D2=closed,core_depth=a['completed_depth'],native_depth=z['completed_depth'],core_ordinary=a.get('result_ordinary_qdepth'),native_ordinary=z.get('result_ordinary_qdepth'),same_retained_qpolicy=sameq,core_source=a.get('result_source'),core_score=a['score'],native_score=z['score'],same_score=a['score']==norm(z['score']),same_action_declaration=a['action']==z['action'] and core_decl==z.get('declaration_id'),relation='deeper'if z['completed_depth']>a['completed_depth']else'shallower'if z['completed_depth']<a['completed_depth']else'same',core_reason=a['termination_reason'],native_reason=z['termination_reason']))
fixed=[p for p in pairs if p['mode']=='fixed'];res=[p for p in pairs if p['mode']=='resource']
s=dict(complete=d['complete'],durable_rows=len(rows),actual_recorded_queries=sum('result'in r for r in rows),unsupported_cells=sum('unsupported'in r for r in rows),fixed_pairs=len(fixed),closed_D2_pairs=sum(x['closed_D2']for x in fixed),closed_D2_mismatches=[x for x in fixed if x['closed_D2'] and (not x['same_score'] or not x['same_retained_qpolicy'])],resource_pairs=len(res),resource_depth=dict(collections.Counter(x['relation']for x in res)),resource_same_action_declaration=sum(x['same_action_declaration']for x in res),resource_same_retained_qpolicy=sum(x['same_retained_qpolicy']for x in res),actual_backends=dict(collections.Counter(r['actual_backend']for r in rows if 'actual_backend'in r)),pairs=pairs)
(b/'summary.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8');print({k:v for k,v in s.items() if k not in ['pairs','actual_backends']})

