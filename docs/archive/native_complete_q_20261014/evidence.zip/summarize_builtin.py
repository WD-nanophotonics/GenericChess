from pathlib import Path
import json,collections
b=Path('.local_agent/neutral-order-20261014')
d=json.loads((b/'builtin-q4/rows.json').read_text(encoding='utf-8'));assert d['complete'];rows=d['rows'];pairs=[]
def norm(v):return v if abs(v)<50000000 else (1 if v>0 else -1)*(1000000000-(100000000-abs(v)))
for key in sorted({(x['root'],x['mode'],x['seconds'],x['order'])for x in rows}):
 p={x['arm']:x for x in rows if (x['root'],x['mode'],x['seconds'],x['order'])==key};assert set(p)=={'CoreNative','FullNativeQ'}
 a,z=p['CoreNative']['result'],p['FullNativeQ']['result'];sameq=a['result_ordinary_qdepth']==z['result_ordinary_qdepth'] and a['result_check_hard_qdepth']==z['result_check_hard_qdepth'];pairs.append(dict(root=key[0],mode=key[1],seconds=key[2],order=key[3],core_depth=a['completed_depth'],native_depth=z['completed_depth'],core_ordinary=a['result_ordinary_qdepth'],native_ordinary=z['result_ordinary_qdepth'],same_retained_qpolicy=sameq,core_score=a['score'],native_score=z['score'],same_score=a['score']==norm(z['score']),same_action=a['action']==z['action'],relation='deeper'if z['completed_depth']>a['completed_depth']else'shallower'if z['completed_depth']<a['completed_depth']else'same',core_reason=a['termination_reason'],native_reason=z['termination_reason']))
fixed=[x for x in pairs if x['mode']=='fixed'];res=[x for x in pairs if x['mode']=='resource'];summary=dict(complete=True,actual_queries=len(rows),fixed_pairs=len(fixed),fixed_both_D2_complete=sum(x['core_depth']==x['native_depth']==2 for x in fixed),fixed_closed_mismatches=[x for x in fixed if x['core_depth']==x['native_depth']==2 and not x['same_score']],resource_pairs=len(res),resource_depth=dict(collections.Counter(x['relation']for x in res)),resource_same_action=sum(x['same_action']for x in res),resource_same_retained_qpolicy=sum(x['same_retained_qpolicy']for x in res),actual_backends=dict(collections.Counter(x['actual_backend']for x in rows)),pairs=pairs)
assert not summary['fixed_closed_mismatches'];(b/'builtin-q4/summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
choice=json.loads((b/'builtin-choice-D2/rows.json').read_text(encoding='utf-8'));assert choice['complete'] and all(x['complete']for x in choice['rows']);print({k:v for k,v in summary.items() if k not in ['pairs','actual_backends']});print('choices',[(x['root'],x['root_value'])for x in choice['rows']])

