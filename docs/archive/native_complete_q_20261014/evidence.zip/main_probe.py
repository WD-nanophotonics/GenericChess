from pathlib import Path
import json,sys,time
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from dataclasses import replace
from conftest import make_ruleset,king_type
from test_no_contest_search import neutral,compile_session,Constant
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/neutral-order-20261014'
write_record(out/'main-declaration.json',dict(question='Is stale chat suggestion already resolved in current Core? Node1/completeD1/pre-cancel actualchoice/stopreason/declaredoutcome.',base='85954ff8a57207a8e32d45f32b846bce32568417',cost='12queries<10s; no sourceedit if current behavior correct',conditions='2outcomes,TT0/1,3conditions, exact existing4x4 royal fixture. No fallback rule changes.'))
rows=[]
for outcome in ['NO_CONTEST','RESTART']:
 for tt in [False,True]:
  rules=replace(make_ruleset(4,[king_type()],lines=['...k','....','....','K...']),declarations=(neutral(0,outcome),))
  for mode in ['node1','complete','pre-cancel']:
   s=compile_session(rules);before=s.state,s.to_record(),s._search_witnesses;token=CancellationToken()
   if mode=='pre-cancel':token.cancel()
   d=AlphaBetaPlayer(s.compiled,evaluator_override=Constant(1),use_tt=tt,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,SearchLimits(max_depth=1,max_nodes=1 if mode=='node1' else None,max_time_seconds=5,quiescence_max_depth=0),cancel_token=token)
   assert before==(s.state,s.to_record(),s._search_witnesses)
   assert d.choice_kind=='DECLARATION' and d.score==0 and d.declaration.outcome==outcome
   assert d.termination_reason=={'node1':'node_limit','pre-cancel':'cancelled','complete':'completed_depth'}[mode]
   row=dict(outcome=outcome,tt=tt,mode=mode,decision=record_value(d),root_unchanged=True,actual_declaration_result=record_value(s.declare(d.declaration.declaration_id)));rows.append(row)
write_record(out/'main-rows.json',dict(complete=True,actual_queries=len(rows),rows=rows))
print('Main closed12queries correct; stale task resolved, no sourceedit.')

