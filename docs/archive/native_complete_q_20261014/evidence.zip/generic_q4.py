from pathlib import Path
import sys,json,time,random,hashlib,importlib.util
from dataclasses import replace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.native import SemanticSearchEngine
import generic_chess.native as native
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from generic_chess.session.session import GameSession
base=ROOT/'.local_agent/neutral-order-20261014';out=base/'generic-q4';out.mkdir(exist_ok=True);mode=sys.argv[1] if len(sys.argv)>1 else 'prepare'
spec=importlib.util.spec_from_file_location('generic_chess._native_core',base/'q_candidate2.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
seeds=list(range(2601,2617));sizes=[4,8,12,16]*4;sizes[-1]=18
if mode=='prepare':
 assert not(out/'declaration.json').exists()
 write_record(out/'declaration.json',dict(question='Does bounded completeNative q4/hard8 generalize to prospectively generated unfamiliar rules with actualrule-derived static leaves and fullplayedhistory?',seeds=seeds,sizes=sizes,root_plies=[0,8],selection='bilateral_random,allow_hybridTrue,Random(seed+7000),reprsortedlegalwalk; no resampling earlyterminal. Freeze allrules/profiles/states/records before anyquery. Do not shrink18control.',base='85954ff8a57207a8e32d45f32b846bce32568417 pluscandidate2genericq',conditions='Identicalactualstaticrule-profileboard/current+hand/base,scale1,dynamicterms0; CoreNativeprovidersrequested andactualfallbackrecorded. BothTT0/orderoff,rootTacticaloff; Cfullrootwindowexact. q4/hard8,firstiterationordinary0reserve tracked inactualresult. FixedD2/5s then1/4s,maxmain12,twooppositearmorders. No node/qnodecap.',cost='Upper32roots*4calls*(5+1+4)=1280s callerplussetup/disk, expected<22min singleproducer under1500sfuse. No extraAgent/fee orsplitlongrunavoidance. Changedpremise:newactualcompleteNativeqcapability, notrerunoldq0curves.',decision='AnyclosedmatchedD2scoremismatch requiresdiagnosis beforecapability claim; unsupported,hard/timebudget andunavailable roots explicit. Resource depths compareonlyactualretainedqpolicy, not WDL/Elo/purebackendfactor. Independentfrozenprototype q1/q4 controls alreadyclosed; usergenericfulltargetunchanged.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),C_source_sha256=hashlib.sha256((base/'candidate2-native_module.c').read_bytes()).hexdigest(),Python_source_sha256=hashlib.sha256((base/'candidate2-semantic_engine.py').read_bytes()).hexdigest(),DLL_sha256=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()))
 cache=EvaluationProfileCache(use_disk=False);cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);samples=[];setup=[]
 for seed,size in zip(seeds,sizes):
  p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));raw=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);prof,_=cache.get_or_build(c,cfg);setup.append(dict(seed=seed,profile=record_value(prof)));s=GameSession(c);rng=random.Random(seed+7000);walk=[]
  for ply in range(9):
   actions=tuple(s.legal_actions())
   if ply in [0,8]:samples.append(dict(name=f'{seed}-ply{ply}',seed=seed,ruleset=json.loads(serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk.copy(),included=bool(actions),game_record=record_value(s.to_record()),legal_count=len(actions)))
   if ply==8:break
   if not actions:samples.append(dict(seed=seed,unavailable_ply=8,terminal_at=ply,resampled=False));break
   a=rng.choice(sorted(actions,key=repr));walk.append(record_value(a));s.submit(a)
 write_record(out/'samples.json',dict(complete=True,samples=samples,setup=setup));print('Prepared',len(samples),'records',flush=True)
else:
 from generic_chess.rules.serialization import deserialize_ruleset
 assert not(out/'rows.json').exists();data=json.loads((out/'samples.json').read_text(encoding='utf-8'));profiles={x['seed']:x['profile'] for x in data['setup']};cases=[];rows=[]
 class Static:
  def __init__(self,profile):self.v=profile['board_value_by_type'];self.h=profile['hand_value_by_base_type']
  def evaluate(self,st):
   pos=st.position;side=pos.side_to_move
   return sum((1 if z.owner==side else -1)*self.v[z.current_type_id] for z in pos.board if z)+sum((1 if owner==side else -1)*self.h[tid]*count for owner,hand in enumerate(pos.hands) for tid,count in hand.items())
  def type_value(self,tid):return self.v[tid]
  def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
 for x in data['samples']:
  if not x.get('included'):continue
  raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
  for av in x['walk']:
   a,=[a for a in s.legal_actions() if record_value(a)==av];s.submit(a)
  assert record_value(s.state)==x['state'] and record_value(s.to_record())==x['game_record'];cases.append((x['name'],c,s,Static(profiles[x['seed']])))
 for mode,seconds,depth in [('fixed',5,2),('resource',1,12),('resource',4,12)]:
  for name,c,s,ev in cases:
   for order in range(2):
    for arm in (('CoreNative','FullNativeQ') if order==0 else ('FullNativeQ','CoreNative')):
     p.rr.stopped();before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter();lim=SearchLimits(max_depth=depth,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8)
     try:
      if arm=='CoreNative':
       player=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_check=True,use_native_semantic_availability=True,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));prep=time.perf_counter()-t;d=player.choose_action(s,lim);backend='CoreNativeprovider' if player.native_legality_provider else 'CoreFALLBACK'
      else:
       e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=ev.v,hand_values=ev.h,tt_megabytes=0,ordering_cache_enabled=False);prep=time.perf_counter()-t;d=e.search(s,lim,root_window_pruning=True);backend='CompleteNativeq4candidate2'
      row=dict(root=name,mode=mode,seconds=seconds,order=order,arm=arm,result=record_value(d),caller_seconds=time.perf_counter()-t,prepare_seconds=prep,actual_backend=backend,root_unchanged=before==(s.state,s.to_record(),s._search_witnesses));assert row['root_unchanged']
     except NativeUnsupportedRuleError as error:row=dict(root=name,mode=mode,seconds=seconds,order=order,arm=arm,unsupported=str(error),actual_searches=0)
     rows.append(row);write_record(out/'rows.json',dict(complete=False,rows=rows));print(name,mode,seconds,order,arm,row.get('result',{}).get('completed_depth'),row.get('result',{}).get('score'),row.get('result',{}).get('termination_reason'),flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows))

