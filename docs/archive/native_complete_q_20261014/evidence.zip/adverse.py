from pathlib import Path
import sys,json,time,hashlib
b=Path('.local_agent/neutral-order-20261014');old=Path('.local_agent/full-backend-20261014')
ns={'__name__':'load','__file__':str(old/'compare.py')};exec(compile((old/'compare.py').read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(old/'compare.py'),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
x=next(x for x in json.loads((old/'ordering-transfer/samples.json').read_text(encoding='utf-8'))['samples'] if x.get('name')=='2505-ply0')
r=deserialize_ruleset(json.dumps(x['ruleset']));raw=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=p.GameSession(c)
assert record_value(s.state)==x['state']
rows=[];t=time.perf_counter()
for a in s.legal_actions():
 child=apply_action(s.state,a,c);rows.append(dict(action=record_value(a),terminal=record_value(child.terminal_status)))
actual=json.loads((old/'cheap-C/transfer/rows.json').read_text(encoding='utf-8'))['rows'];chosen=[a for a in actual if a['root']=='2505-ply0' and 'decision'in a]
for row in chosen:
 z=next(z for z in rows if z['action']==row['decision']['action']);assert z['terminal']['winner']==0 and z['terminal']['status']=='checkmate'
costs=[]
for row in actual:
 if row['root']=='2503-ply0' and row.get('fixed'):
  costs.append({k:row[k] for k in ['arm','order','prepare_seconds','caller_seconds']}|dict(search_after_prepare_seconds=row['caller_seconds']-row['prepare_seconds'],nodes=row['decision']['nodes']))
write_record(b/'adverse-attribution.json',dict(complete=True,actual_Core_transitions=len(rows),seconds=time.perf_counter()-t,root='2505-ply0',all12_retained_choices_actual_mate_in_one=True,certificate=rows,caller_outlier_decomposition=costs,decision='2shallower cheap pairs alreadychoose actualM1, no loss ofrootchoice/terminaldistance inthisroot. Keep rawratio6.813:0.204s preparation versus normal0.006s is recorded, attribution uncertainty not proof of scheduler cause. No retimed curve. Allfixed searchnodes490 identical, no evidence treegrowth causing outlier. Native q0-onlycompletekernel still lacksqsearch, useful next fullstate feasibility question.'))
print('certificate closed',len(rows), 'transitions')


