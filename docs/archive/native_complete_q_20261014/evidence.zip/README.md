# Complete Native q evidence

Immutable Agent-written scientific source/data; no raw Slack, account, host logs,
receipts, binary images, credentials or private user inputs. Extract members
under .local_agent/neutral-order-20261014 in an ISOLATED checkout. Base helpers
and played fixtures come from docs/archive/full_native_q0_20261014/evidence.zip
SHA256 71bb744ba055eadc45de01a04ffec49894490e205a6ad2bfa823aeb06e53cfa1.
Follow its README dependency paths, including root-transfer semantic samples and
native-payload fallback-real-loss. Do not replace another Agent's files.

Main product source is fixed a76214d0d361425a162c02a780673b3789484e97.
Pre-q C/Python source is85954ff8a57207a8e32d45f32b846bce32568417.
For each private image use its FULL preserved C snapshot with tracked companion
C/headers/build tools in an isolated checkout and a custom output path. Binary
hashes bind original observations; binaries are deliberately excluded here.
q-prototype/native_module.c is initial hardcoded q1/hard4, TT0 only, public q0
argument is a carrier. Its nodes INCLUDES qnodes; do not add them again.
Candidate1 and candidate2 use parametric q4/hard8; nodes is main-only. Candidate2
adds retained-policy metadata and avoids redundant scalar evaluation. Source
hashes are provided for each image; product differs only API documentation from
candidate2. build-q-source-first.py is actual initial builder; build_q_source.py
is later readability cleanup. Builders expect PRE-q base, not current C; do not
apply string edits blindly to current product. Unsafe source deliberately lacks
q TT isolation; two actual regression failures are expected, never install it.
Wrong first test fixture is failed assumption evidence, not the active test.

Original q4 declaration and first29 durable rows are preserved. Missing process/
handle/exit after08:29UTC, recovered12:58:06.9588885UTC, cause UNKNOWN. Single
pending-call reproduction exit0/5.2116s under20s fuse; only remaining predeclared
cells resumed, exit0/258.136889s under900s fuse. No timing factor is inferred
across the269.0326min unknown gap. No crash/SAC cause established.

Closed producer exits0: builtin48 calls1181.790689s/1620s external fuse;
literal chosen-action7 calls18.5497985s/300s fuse; generated372 successful+12
explicit unsupported cells1282.1609551s/1500s fuse; retry132decisions/146 internal
searches325.977911s/1200s fuse. Fuses not hit. Initial producer's unknown physical
attempts excluded:884 durable recorded search calls is a lower bound, not an
exhaustive physical count.38 adverse literal transitions and tests excluded.

All scripts/JSON preserve original declared budgets and exposed/finite scope.
Setup FEN/SFEN are fresh analysis roots, not invented default-start GameRecords.
Generated played roots retain real records/witnesses. q completion and depth
are not WDL or generic strength. Retry remains private, no public default.
q_work_bound.py reads existing records: conditional codepath count bound only,
not all physical transitions, timing fraction or established savings. Original
summarize_retry.py has an overbroad negative-pair sentence; q_work_bound.py
corrects that summary to the actual limited benefit and caller overshoot.
