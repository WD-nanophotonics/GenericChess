from pathlib import Path
import json
b=Path('.local_agent/neutral-order-20261014')
rows=json.loads((b/'generic-q4/rows.json').read_text(encoding='utf-8'))['rows'];out=[]
for r in rows:
 if r['arm']!='FullNativeQ' or 'result'not in r:continue
 z=r['result'];visits=z['nodes']+z['qnodes'];trials=z['transition_count'];lower=max(0,trials-visits-1)
 out.append(dict(root=r['root'],mode=r['mode'],seconds=r['seconds'],order=r['order'],main_nodes=z['nodes'],qnodes=z['qnodes'],outer_checked_transitions=trials,nonrecursive_checked_lower_bound=lower,lower_bound_fraction=lower/trials if trials else 0.,depth=z['completed_depth'],reason=z['termination_reason']))
s=dict(complete=True,scope='Supportedcandidate2/plainorder/TT0 completeNative queries only. Transitioncounter excludesnestedterminal/availability andcanonicalPV replay, so notallphysicalwork. Boundmax(0,T-mainnodes-qnodes-1): countedrecursiveedges requirevisits; mainleaf-to-q duplicatevisits androot/canonicalreplay onlyloosenthebound; atmostonefinalcheckededge canabortbeforeavisit. Withplainorder/TT0 no discardedmainorderingtrials; excesssuccessfulcheckedchildren areq-candidateclassification withoutrecursion. Conditional codepathcountbound, NOTtimefraction/speedup/wastedsemanticproof.',query_count=len(out),positive_lower_bound_queries=sum(x['nonrecursive_checked_lower_bound']>0 for x in out),total_outer_checked=sum(x['outer_checked_transitions']for x in out),total_nonrecursive_lower_bound=sum(x['nonrecursive_checked_lower_bound']for x in out),rows=out)
(b/'q-work-bound.json').write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8')
p=b/'q-hard-retry/summary.json';d=json.loads(p.read_text(encoding='utf-8'));d['scope']=d['scope'].replace('Timingvariesandnegativepair remains.','Timingvaries,20of22secondsearches donotimproveuniformdepth; callerovershoot retained.');wr=json.loads((b/'q-hard-retry/rows.json').read_text(encoding='utf-8'))['rows'];worst=max(wr,key=lambda x:x['caller_seconds']-x['seconds']);d['worst_caller_overshoot_case']={k:worst[k]for k in ['root','method','seconds','order','caller_seconds']};p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print({k:v for k,v in s.items()if k not in ['rows','scope']});print('worst',d['worst_caller_overshoot_case']);print('top',sorted(out,key=lambda x:x['nonrecursive_checked_lower_bound'],reverse=True)[:2])

