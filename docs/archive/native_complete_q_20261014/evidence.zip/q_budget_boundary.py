from pathlib import Path
import sys,json,time
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.search_backend_comparison import Material,VALUES
from scripts.research_record import record_value,write_record
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));s=GameSession(c);ev=Material('chess');before=s.state,s.to_record(),s._search_witnesses
lim=SearchLimits(max_depth=1,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8,quiescence_max_nodes=1);rows=[]
for arm in ['Core','Native']:
 t=time.perf_counter()
 if arm=='Core':d=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=False,tuning=SearchTuning(use_root_tactical=False)).choose_action(s,lim)
 else:d=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=VALUES['chess'],hand_values=VALUES['chess'],tt_megabytes=0).search(s,lim,root_window_pruning=True)
 assert d.completed_depth==1 and d.qnodes>1 and d.result_ordinary_qdepth==0 and d.termination_reason in ['completed','completed_depth']
 assert before==(s.state,s.to_record(),s._search_witnesses)
 rows.append(dict(arm=arm,result=record_value(d),seconds=time.perf_counter()-t,root_unchanged=True))
write_record(ROOT/'.local_agent/neutral-order-20261014/q-budget-boundary.json',dict(complete=True,actual_queries=2,source='a76214d0;Dot source claim1791983916 now locally verified',decision='RetainCore expansion-check semantics; document that qnodebudget isnot strictqvisit ceiling. Total max_nodes remains allvisitcap, time/cancel remainindependent. No Cbudgetpolicychange.',rows=rows));print([(r['arm'],r['result']['qnodes'],r['result']['completed_depth'])for r in rows])

