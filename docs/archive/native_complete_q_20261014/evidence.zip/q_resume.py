from pathlib import Path
import sys,json,time,hashlib,importlib.util
old=Path.cwd()/'.local_agent/full-backend-20261014';ns={'__file__':str(old/'compare.py'),'__name__':'loader'};exec(compile((old/'compare.py').read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(old/'compare.py'),'exec'),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
import generic_chess.native as native
out=Path.cwd()/'.local_agent/neutral-order-20261014/q-prototype';mode=sys.argv[1] if len(sys.argv)>1 else 'q4fixed';target=out/mode;target.mkdir(exist_ok=True);assert (target/'rows.json').exists()
spec=importlib.util.spec_from_file_location('generic_chess._native_core',out.parent/'q_candidate.pyd');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
modules={'Core':native._module(),'NativeQ':candidate}
decl=dict(question='Can one private complete-state C q4/hard8 extension match actual Core q semantics and avoid q0-only capability gap?',base='85954ff8a57207a8e32d45f32b846bce32568417',scope='Candidate boundedparametricq4/hard8 throughactual publicSearchLimits; source/DLL pinned. TT0,flat100/0 sameboard/hand,no ordering/root tactical,firstiterationordinaryq0reserve andmandatorycheckevasions; laterordinaryq4. Everyactualchild/fullhistory checked; noisyactualenemyremoval/materialinventory/terminal/check, notmetadata. MainPVonly, qsuffix notclaimed.',cases='same frozen original19roots (no18support shrink),no newselection onoutcomes',budget='smoke2semanticroots D1,D2/5s oneorder; fixedallroots D1,D2/10s twoorders; maxmain2,qhard8 so<=10totalplies. No nodecaps. Expected<15min, max~25min oneboundedproducer, no extraAgent/fee. C hardlimit explicit censored notstaticfallback.',decision='Any completed fixeddepth scoremismatch diagnoses before capability claim; hard/timebudget kept UNKNOWN. Matching scores notactionvalue/maxset/strength, comparetotalcaller/counters separately. Do notdeploy/publicq4 flag or TT use.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),DLLs={a:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for a,m in modules.items()})
assert (target/'declaration.json').exists()
rows=json.loads((target/'rows.json').read_text(encoding='utf-8'))['rows'];done={(r['root'],r['depth'],r['order'],r['arm']) for r in rows};cases=load_cases()
if mode=='smoke':cases=[x for x in cases if x[0] in ['drop_after_actual_capture','checked_NO_CONTEST']]
for name,c,s in cases:
 for depth in [1,2]:
  for order in range(1 if mode=='smoke' else 2):
   for arm in (('Core','NativeQ') if order==0 else ('NativeQ','Core')):
    if (name,depth,order,arm) in done:continue
    p.rr.stopped();native._MODULE=modules[arm];before=s.state,s.to_record(),s._search_witnesses;ev=Material(c);t=time.perf_counter()
    try:
     lim=SearchLimits(max_depth=depth,max_time_seconds=5 if mode=='smoke' else 10,quiescence_max_depth=4,quiescence_hard_max_depth=8)
     if arm=='Core':d=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True)).choose_action(s,lim)
     else:
      nr=compile_native_semantic_rules(c);engine=SemanticSearchEngine(c,nr,board_values=ev.v,hand_values=ev.v,tt_megabytes=0,ordering_cache_enabled=False)
      # Explicit carrier for PRIVATE hardcoded-q image. Not a public q0 result.
      d=engine.search(s,lim,root_window_pruning=True)
     row=dict(root=name,depth=depth,order=order,arm=arm,result=record_value(d),caller_seconds=time.perf_counter()-t,root_unchanged=before==(s.state,s.to_record(),s._search_witnesses),actual_module_sha256=decl['DLLs'][arm]);assert row['root_unchanged']
    except NativeUnsupportedRuleError as error:row=dict(root=name,depth=depth,order=order,arm=arm,unsupported=str(error),actual_searches=0)
    rows.append(row);write_record(target/'rows.json',dict(complete=False,rows=rows));print(name,depth,order,arm,row.get('result',{}).get('score'),row.get('result',{}).get('completed_depth'),row.get('result',{}).get('termination_reason'),flush=True)
native._MODULE=modules['Core'];write_record(target/'rows.json',dict(complete=True,rows=rows))

