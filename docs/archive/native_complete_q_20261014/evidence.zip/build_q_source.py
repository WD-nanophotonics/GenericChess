from pathlib import Path
import json,hashlib
out=Path('.local_agent/neutral-order-20261014/q-prototype');out.mkdir(exist_ok=True)
src=Path('generic_chess/_native/native_module.c').read_text(encoding='utf-8')
q=r'''
/* Private q1/hard4 feasibility only. Full checked semantic transitions. */
static int gc_private_inventory_changed(const GCSemanticRules *rules,
        const GCSemanticPosition *a, const GCSemanticPosition *b) {
    int delta[2][GC_MAX_TYPES] = {{0}};
    unsigned cells = rules->board_size * rules->board_size;
    for (unsigned i=0;i<cells;i++) {
        const GCPiece *x=&a->board[i], *y=&b->board[i];
        if(x->occupied) delta[x->owner][x->current_type]++;
        if(y->occupied) delta[y->owner][y->current_type]--;
    }
    for(unsigned owner=0;owner<2;owner++)
        for(unsigned t=0;t<rules->type_count;t++)
            if(delta[owner][t]+a->hand_counts[owner][t]-b->hand_counts[owner][t])return 1;
    return 0;
}
static int gc_private_q(GCSemanticIterativeContext *ctx,uint32_t ply,
                       unsigned qdepth,int alpha,int beta) {
    if(!gc_semantic_iterative_check_budget(ctx,0))return 0;
    ctx->nodes++;ctx->private_qnodes++;
    if(ply>ctx->selective_depth)ctx->selective_depth=ply;
    GCSemanticPosition *pos=&ctx->stack[ply];
    int winner=-1;
    const uint64_t *known=(ply>0 && pos->history_exact && pos->history_len>0)
        ?pos->history_digest[pos->history_len-1]:NULL;
    int terminal=gc_semantic_terminal_status_known(ctx->rules,pos,&winner,known);
    if(terminal<0){ctx->control=4;return 0;}
    if(terminal)return gc_semantic_iterative_terminal_score(winner,pos->side_to_move,ctx->root_ply_offset+ply);
    uint64_t claim=0;
    int winning=gc_semantic_declaration_win(ctx->rules,pos,ctx->root_ply_offset+ply,&claim);
    if(winning<0){ctx->control=4;return 0;}
    if(winning)return GC_SEMANTIC_WIN_SCORE-(ctx->root_ply_offset+ply);
    int neutral=gc_semantic_declaration_neutral(ctx->rules,pos,&claim);
    if(neutral<0){ctx->control=4;return 0;}
    if(neutral && alpha<0)alpha=0;
    int check=gc_semantic_runtime_in_check(ctx->rules,pos,pos->side_to_move);
    if(check<0){ctx->control=4;return 0;}
    if(check && qdepth>=4){ctx->control=5;return 0;}
    if(!check){
        int stand=gc_semantic_probe_material(ctx->rules,pos,&ctx->profile,NULL);
        if(stand>=beta)return neutral && stand<0 ? 0:stand;
        if(stand>alpha)alpha=stand;
        if(qdepth>=ctx->private_qordinary)return alpha;
    }
    GCSemanticActionBuffer actions;gc_semantic_action_buffer_init(&actions);
    if(!gc_semantic_generate_candidate_buffer(ctx->rules,pos,&actions)){
        gc_semantic_action_buffer_free(&actions);ctx->control=4;return 0;
    }
    ctx->legal_generation_count++;
    if(actions.count>1)qsort(actions.data,actions.count,sizeof(uint64_t),gc_semantic_canonical_action_compare);
    int parent_enemies=0,legal=0;
    unsigned cells=ctx->rules->board_size*ctx->rules->board_size;
    for(unsigned i=0;i<cells;i++)if(pos->board[i].occupied && pos->board[i].owner!=pos->side_to_move)parent_enemies++;
    for(size_t i=0;i<actions.count;i++){
        if(!gc_semantic_iterative_check_budget(ctx,1)){gc_semantic_action_buffer_free(&actions);return 0;}
        GCSemanticPosition *child=&ctx->stack[ply+1];
        int made=gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);
        if(made<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}
        if(!made)continue;
        ctx->transition_count++;legal++;
        int noisy=check;
        if(!noisy){
            int enemies=0;
            for(unsigned j=0;j<cells;j++)if(child->board[j].occupied && child->board[j].owner!=pos->side_to_move)enemies++;
            noisy=enemies<parent_enemies || gc_private_inventory_changed(ctx->rules,pos,child);
            if(!noisy){
                int child_winner=-1;
                int ended=gc_semantic_terminal_status_known(ctx->rules,child,&child_winner,child->history_digest[child->history_len-1]);
                if(ended<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}
                noisy=ended!=0;
            }
            if(!noisy){
                int child_check=gc_semantic_runtime_in_check(ctx->rules,child,child->side_to_move);
                if(child_check<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}
                noisy=child_check;
            }
        }
        if(!noisy)continue;
        int score=-gc_private_q(ctx,ply+1,qdepth+1,-beta,-alpha);
        if(ctx->control){gc_semantic_action_buffer_free(&actions);return 0;}
        if(score>=beta){gc_semantic_action_buffer_free(&actions);return score;}
        if(score>alpha)alpha=score;
    }
    gc_semantic_action_buffer_free(&actions);
    if(check && !legal){ctx->control=4;return 0;}
    return alpha;
}
'''
assert 'GC_SEMANTIC_WIN_SCORE' not in src
# Existing terminal evaluator defines exact units, avoid inventing another constant.
q=q.replace('GC_SEMANTIC_WIN_SCORE-(ctx->root_ply_offset+ply)','gc_semantic_iterative_terminal_score(pos->side_to_move,pos->side_to_move,ctx->root_ply_offset+ply)')
marker='static int gc_semantic_iterative_negamax(GCSemanticIterativeContext *ctx,'
assert src.count(marker)==1
src=src.replace(marker,q+'\n'+marker)
src=src.replace('    uint64_t nodes;\n    uint64_t max_nodes;', '    uint64_t nodes;\n    uint64_t private_qnodes;\n    unsigned private_qordinary;\n    uint64_t max_nodes;')
needle='''        if (leaf_neutral > 0 && score < 0) score = 0;
        gc_semantic_tt_store_node'''
assert src.count(needle)==1
src=src.replace(needle,'''        score = gc_private_q(ctx, ply, 0, alpha, beta);
        if (ctx->control) return 0;
        if (leaf_neutral > 0 && score < 0) score = 0;
        gc_semantic_tt_store_node''')
src=src.replace('ctx.pv_stride = max_depth + 1;','ctx.pv_stride = max_depth + 5;')
src=src.replace('size_t levels = (size_t)max_depth + 2;','size_t levels = (size_t)max_depth + 6;')
src=src.replace('        ctx.root_iteration_attempted[depth] = 1;','        ctx.private_qordinary = depth == 1 ? 0 : 1;\n        ctx.root_iteration_attempted[depth] = 1;')
src=src.replace('else if (ctx.control == 4) reason = "internal_error";','else if (ctx.control == 4) reason = "internal_error";\n    else if (ctx.control == 5) reason = "qsearch_check_hard_limit";')
src=src.replace('"qnodes", (uint64_t)0,','"qnodes", ctx.private_qnodes,')
(out/'native_module.c').write_bytes(src.encode('utf-8'))
build=Path('.local_agent/full-backend-20261014/cheap-C/build.py').read_text(encoding='utf-8').replace('.local_agent/full-backend-20261014/cheap-C/native_module.c','.local_agent/neutral-order-20261014/q-prototype/native_module.c')
(out/'build.py').write_bytes(build.encode())
(out/'source-binding.json').write_text(json.dumps(dict(
 base='85954ff8a57207a8e32d45f32b846bce32568417',
 candidate_C_sha256=hashlib.sha256(src.encode()).hexdigest(),
 scope='Private hardcodedq1/hard4;firstiterationordinary0,later1;TT0only,maxdepth<=8. Fullcheckedsemanticchildren/history; callerq0carrier explicitly notactualq0. No publicflag/default/ABI or qPV suffix.'
),indent=2)+'\n')

print('privateq source',len(src))

