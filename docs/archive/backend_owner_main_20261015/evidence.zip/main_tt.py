from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
spec=importlib.util.spec_from_file_location('mainowner._native_core',next(b.glob('main_binary*.pyd')));profilemodule=importlib.util.module_from_spec(spec);spec.loader.exec_module(profilemodule)
class Bridge(V2Boundary):
 def semantic_engine_search(self,*args):
  out=self.kernel.semantic_engine_search(*args);self.last={k:out.get(k,0)for k in ['scan_profile_ns','scan_profile_calls','q_checked_profile_ns']};return out
bridges={'existingV2':Bridge(wide),'mainV2':Bridge(profilemodule)}
compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
inputs=json.loads((prior/'qualification-inputs.json').read_text(encoding='utf-8'))['rows']+[x for x in json.loads((prior/'fresh/samples.json').read_text(encoding='utf-8'))['samples']if x['included']]+[x for x in json.loads((b/'new32-inputs.json').read_text())['samples']if x['included']]
inputs=[x for x in inputs if x.get('source_dataset')=='semantic' or str(x['name']).startswith('3602-')]
rows=[];start=time.monotonic()
def save(complete=False,error=None):
 (b/'main-tt-results.json').write_bytes((json.dumps({'complete':complete,'rows':rows,'seconds':time.monotonic()-start,'error':error})+'\n').encode())
try:
 for x in inputs:
  c,s=case(x);v={tid:0 if mt.is_anchor else 100 for tid,mt in c.support.type_metadata.items()};acts=sorted(s.legal_actions(),key=repr);before=record_value(s.to_record());hints=[acts[0],acts[-1]]if acts else[None,None]
  for arm,bridge in bridges.items():
   nr=compilers[arm](c);warm=SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=1,ordering_cache_enabled=False)
   todo=[(0,hints[0],True,True),(0,hints[1],True,True),(4,hints[0],True,True),(4,hints[1],True,True),(0,None,True,True)]+[(q,None,False,w)for q in [0,4]for w in [False,True]]
   for index,(q,hint,usewarm,window)in enumerate(todo):
    p.rr.stopped()
    if time.monotonic()-start>900:raise TimeoutError('declared900sTTqualifierfuse')
    e=warm if usewarm else SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False)
    r=e.search(s,SearchLimits(max_depth=2,max_time_seconds=3,quiescence_max_depth=q),root_order_hint=hint,root_window_pruning=window);assert record_value(s.to_record())==before;st=s.state
    for a in r.principal_variation:assert a in legal_actions(st,c);st=apply_action(st,a,c)
    rows.append({'root':x['name'],'n':c.board_size,'arm':arm,'index':index,'q':q,'warmTT1':usewarm,'rootwindow':window,'hint':record_value(hint),'result':record_value(r),'pv_legal':True});save()
   warm.clear_tt();assert warm.tt_info()['occupied_entries']==0
  print(x['name'],len(rows),flush=True)
 save(True);print('COMPLETE',len(rows),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
