from pathlib import Path
import sys,json,inspect,importlib.util,time,hashlib,random,traceback,threading
from types import SimpleNamespace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
import generic_chess.native as native
import generic_chess.native.compiler as nc
from generic_chess.native import semantic as sem
from generic_chess.native.mirror import pack_semantic_action,expected_snapshot
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
b=ROOT/'.local_agent/backend-owner-20261015';prior=ROOT/'.local_agent/wide-interface-20261015'
installed=native._module();spec=importlib.util.spec_from_file_location('ownerwide._native_core',next(prior.glob('_native_core*.pyd')));wide=importlib.util.module_from_spec(spec);spec.loader.exec_module(wide)
class V2Boundary:
 # Public Python dictionaries keep their existing no-promotion/drop sentinels;
 # raw C V1/V2 layouts and capsule names stay distinct and reject mixed input.
 def __getattr__(self,name):return getattr(wide,name)
 def semantic_action_pack(self,fields):
  f=dict(fields)
  if f['promotion']==255:f['promotion']=127
  if f['kind']==3:f['from']=1023
  return wide.semantic_action_pack(f)
 def semantic_action_unpack(self,code):
  f=wide.semantic_action_unpack(code)
  if f['promotion']==127:f['promotion']=255
  if f['kind']==3:f['from']=255
  return f
boundary=V2Boundary();ns=dict(nc.__dict__);ns.update(_module=lambda:boundary,native_available=lambda:True,SEMANTIC_PAYLOAD_VERSION=5)
source=inspect.getsource(nc._native_payload_is_executable).replace('report.board_squares <= 256','report.board_squares <= 1024');exec(source,ns)
source=inspect.getsource(nc.build_semantic_compile_payload).replace('1 <= n <= 16 and n * n <= 256','1 <= n <= 32 and n * n <= 1024');exec(source,ns)
exec(inspect.getsource(nc.compile_native_semantic_rules),ns);compilewide=ns['compile_native_semantic_rules']

def case(x):
 if x.get('recipe'):
  from test_no_contest_search import defender_root
  s=defender_root();action,=[a for a in s.legal_actions() if record_value(a)==x['attack']];s.submit(action);c=s.compiled
 else:
  r=deserialize_ruleset(json.dumps(x['ruleset']))
  if r.semantic_actions:c=compile_ruleset_for_execution(r)
  else:
   raw=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
  s=GameSession(c)
  if x.get('walk') is not None:walk=x['walk']
  else:walk=[record_value(a)for a in deserialize_game_record(json.dumps(x['game_record'])).actions]
  for value in walk:
   a,=[a for a in s.legal_actions() if record_value(a)==value];s.submit(a)
 assert record_value(s.state)==x['state'],x['name']
 return c,s

def check(c,s,nr,pos):
 snap=sem.snapshot(nr,pos);expected=expected_snapshot(s.state.position,nr,c)
 for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(expected[k]),k
 assert snap['ply']==s.state.ply_count
 assert sem.position_key(nr,pos)==str(position_identity_key(s.state.position,c))
 assert snap['history_exact'] and snap['history_events_exact']
 assert len(snap['history'])==len(s._search_witnesses)==len(s.state.history)
 assert [''.join(f'{v:016x}' for v in h)for h in snap['history']]==[str(position_identity_key(w,c))for w in s._search_witnesses]
 assert snap['history_events']==tuple((255 if x.actor<0 else x.actor,bool(x.gave_check))for x in s.state.history)
 return snap

result=b/'coexist-results.json';previous=json.loads(result.read_text(encoding='utf-8'))if result.exists()else {};rows=previous.get('rows',[]);calls=previous.get('calls',[]);rejects=previous.get('rejects',[]);prior_seconds=previous.get('seconds',0);start=time.monotonic();completed={x['root']for x in rows};print('RESUME',len(completed),len(calls),'priorseconds',prior_seconds,flush=True)
def save(complete=False,error=None):
 result.write_bytes((json.dumps({'complete':complete,'rows':rows,'calls':calls,'rejects':rejects,'seconds':time.monotonic()-start+prior_seconds,'default_unchanged':native._MODULE is installed,'error':error},indent=2)+'\n').encode())
def fuse():
 if time.monotonic()-start+prior_seconds>1200:raise TimeoutError('declared1200s total qualifier fuse')
 p.rr.stopped();assert native._MODULE is installed
try:
 inputs=json.loads((prior/'qualification-inputs.json').read_text(encoding='utf-8'))['rows']+[x for x in json.loads((prior/'fresh/samples.json').read_text(encoding='utf-8'))['samples']if x['included']]
 for x in inputs:
  if x['name']in completed:continue
  fuse();c,s=case(x);before=record_value(s.to_record());v={tid:0 if mt.is_anchor else 100 for tid,mt in c.support.type_metadata.items()};contexts=[]
  for version,compiler in [('V1',nc.compile_native_semantic_rules),('V2',compilewide)]:
   try:nr=compiler(c)
   except nc.NativeUnsupportedRuleError as e:
    assert version=='V1' and c.board_size>16;rejects.append({'root':x['name'],'kind':'capacity','version':version,'error':str(e)});continue
   assert nr.backend_module is (installed if version=='V1' else boundary)
   pos=pack_semantic_search_position(c,nr,s);snap=check(c,s,nr,pos);codes=sem.guarded_actions(nr,pos);decoded=tuple(sem.public_action(nr,z)for z in codes);assert set(decoded)==set(s.legal_actions());assert all(pack_semantic_action(nr,s.state.position,a)==z for a,z in zip(decoded,codes))
   # At most six deterministic branches, with promotion/drop branches first.
   preferred=sorted(zip(decoded,codes),key=lambda az:(0 if getattr(az[0],'promotion_target_id',None)is not None or az[0].__class__.__name__=='SemanticDropMove' else 1,repr(az[0])))[:6]
   child_checks=0
   for a,z in preferred:
    child=sem.make_checked(nr,pos,z);childstate=apply_action(s.state,a,c);childsession=SimpleNamespace(state=childstate,_search_witnesses=(*s._search_witnesses,childstate.position));check(c,childsession,nr,child);child_checks+=1
   assert record_value(s.to_record())==before and sem.snapshot(nr,pos)==snap
   engine=SemanticSearchEngine(c,nr,board_values=v,hand_values=v,tt_megabytes=1,ordering_cache_enabled=False)
   contexts.append((version,nr,pos,engine));rows.append({'root':x['name'],'n':c.board_size,'version':version,'full_legal_count':len(codes),'checked_children':child_checks,'history_entries':len(snap['history']),'owner_correct':True})
  for q in [0,4,0]:
   for version,nr,pos,e in (contexts if q!=4 else contexts[::-1]):
    fuse();t=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_time_seconds=2,quiescence_max_depth=q),root_window_pruning=True);assert record_value(s.to_record())==before
    state=s.state
    for a in r.principal_variation:assert a in legal_actions(state,c);state=apply_action(state,a,c)
    calls.append({'root':x['name'],'n':c.board_size,'version':version,'q':q,'seconds':time.perf_counter()-t,'result':record_value(r),'pv_legal':True,'owner_correct':True});save()
  if len(contexts)==2:
   _,a,ap,ae=contexts[0];_,d,dp,de=contexts[1]
   for label,fn in [('V1rules_toV2',lambda:wide.semantic_position_snapshot(a.capsule,dp)),('V2rules_toV1',lambda:installed.semantic_position_snapshot(d.capsule,ap)),('V1pos_toV2',lambda:wide.semantic_position_snapshot(d.capsule,ap)),('V2pos_toV1',lambda:installed.semantic_position_snapshot(a.capsule,dp)),('V1engine_toV2',lambda:wide.semantic_engine_tt_info(ae._capsule)),('V2engine_toV1',lambda:installed.semantic_engine_tt_info(de._capsule))]:
    try:fn()
    except ValueError as error:rejects.append({'root':x['name'],'kind':'mixed-capsule','case':label,'rejected':str(error)})
    else:raise AssertionError(label)
  for version,nr,pos,e in contexts:
   e.clear_tt();assert e.tt_info()['occupied_entries']==0
  print(x['name'],c.board_size,'contexts',len(contexts),'calls',len(calls),flush=True);save()
 # Actual during-search and pre-cancel plus same-object reuse on last wide case.
 version,nr,pos,e=contexts[-1]
 for when in ['before','during']:
  token=CancellationToken();timer=None
  if when=='before':token.cancel()
  else:timer=threading.Timer(.02,token.cancel);timer.start()
  try:r=e.search(s,SearchLimits(max_depth=12,max_time_seconds=3,quiescence_max_depth=4),token)
  finally:
   if timer is not None:timer.cancel();timer.join()
  assert r.termination_reason=='cancelled';calls.append({'root':x['name'],'kind':when+'cancel','version':version,'result':record_value(r)})
  r=e.search(s,SearchLimits(max_depth=2,max_time_seconds=3,quiescence_max_depth=0));calls.append({'root':x['name'],'kind':'reuse','version':version,'result':record_value(r)})
  assert r.completed_depth==2
 save(True);print('COMPLETE',len(rows),len(calls),len(rejects),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
