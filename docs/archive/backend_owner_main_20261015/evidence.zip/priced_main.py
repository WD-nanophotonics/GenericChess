from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
spec=importlib.util.spec_from_file_location('mainowner._native_core',next(b.glob('main_binary*.pyd')));profilemodule=importlib.util.module_from_spec(spec);spec.loader.exec_module(profilemodule)
class Bridge(V2Boundary):
 def semantic_engine_search(self,*args):
  out=self.kernel.semantic_engine_search(*args);self.last={k:out.get(k,0)for k in ['scan_profile_ns','scan_profile_calls','q_checked_profile_ns']};return out
bridges={'existingV2':Bridge(wide),'mainV2':Bridge(profilemodule)}
compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
inputs=json.loads((prior/'qualification-inputs.json').read_text(encoding='utf-8'))['rows']+[x for x in json.loads((prior/'fresh/samples.json').read_text(encoding='utf-8'))['samples']if x['included']]+[x for x in json.loads((b/'new32-inputs.json').read_text())['samples']if x['included']]
inputs=[x for x in inputs if x['name'].endswith('-ply0')]
out=b/'priced-main-results.json';previous=json.loads(out.read_text(encoding='utf-8'));rows=previous['rows'];prior_seconds=previous['seconds'];start=time.monotonic();completed={x['root']for x in rows}
def save(complete=False,error=None):
 (b/'priced-main-results.json').write_bytes((json.dumps({'complete':complete,'rows':rows,'seconds':time.monotonic()-start+prior_seconds,'error':error,'default_unchanged':native._MODULE is installed})+'\n').encode())
try:
 for x in inputs:
  if x['name']in completed:continue
  c,s=case(x);profile=p.build_ruleset_profile(c,p.EvaluationConfig());raw_board=profile.board_value_by_type;raw_hand=profile.hand_value_by_base_type;v={tid:int(round(value))for tid,value in raw_board.items()};h={tid:int(round(value))for tid,value in raw_hand.items()};before=record_value(s.to_record());rules={name:compilers[name](c)for name in bridges}
  for q in [4]:
   for order in [0,1]:
    for arm in (list(bridges)if order==0 else list(bridges)[::-1]):
     p.rr.stopped();assert native._MODULE is installed
     if time.monotonic()-start+prior_seconds>360:raise TimeoutError('declared1200s profilefuse')
     t=time.perf_counter();e=SemanticSearchEngine(c,rules[arm],board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);r=e.search(s,SearchLimits(max_depth=2,max_time_seconds=3,quiescence_max_depth=q),root_window_pruning=True);rows.append({'root':x['name'],'n':c.board_size,'order':order,'q':q,'arm':arm,'caller_seconds':time.perf_counter()-t,'result':record_value(r),'profile':dict(bridges[arm].last),'board_values':v,'hand_values':h,'rounding':'round to existing integer Native profile, samebotharms'});assert record_value(s.to_record())==before;save()
  print(x['name'],len(rows),flush=True)
 save(True);print('COMPLETE',len(rows),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
