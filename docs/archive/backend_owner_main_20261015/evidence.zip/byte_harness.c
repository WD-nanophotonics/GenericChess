#include "native_semantic_key.h"
#include "native_sha256.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int baseline_key(const GCSemanticRules*,const GCSemanticPosition*,char[65]);
int candidate_key(const GCSemanticRules*,const GCSemanticPosition*,char[65]);
static unsigned char captured[262144],original[262144]; static size_t length;
void gc_sha256_init(GCSha256 *ctx){(void)ctx;length=0;}
void gc_sha256_update(GCSha256 *ctx,const uint8_t *data,size_t len){(void)ctx;assert(length+len<=sizeof(captured));memcpy(captured+length,data,len);length+=len;}
void gc_sha256_final(GCSha256 *ctx,uint8_t digest[32]){(void)ctx;memset(digest,0,32);}
void gc_sha256_hex(const uint8_t digest[32],char out[65]){(void)digest;memset(out,'0',64);out[64]=0;}
#undef assert
#define assert(c) do { if(!(c)){fprintf(stderr,"ASSERT line %d: %s\n",__LINE__,#c);exit(2);} } while(0)
static unsigned rng=15015;
static unsigned draw(void){rng=rng*1664525u+1013904223u;return rng;}
static size_t checks,total_bytes;
static void check(GCSemanticRules*r,GCSemanticPosition*p){char hex[65];int a=baseline_key(r,p,hex);assert(a);size_t n=length;memcpy(original,captured,n);int z=candidate_key(r,p,hex);if(!(z&&n==length&&!memcmp(original,captured,n))){fprintf(stderr,"byte mismatch check=%zu n=%zu length=%zu nboard=%u z=%d\n",checks,n,length,r->board_size,z);for(size_t i=0;i<n&&i<length;i++)if(original[i]!=captured[i]){fprintf(stderr,"firstdiff %zu old=%u new=%u\n",i,original[i],captured[i]);break;}exit(3);}checks++;total_bytes+=n;}
int main(void){GCSemanticRules *r=calloc(1,sizeof(*r));assert(r);GCSemanticPosition *p=calloc(1,sizeof(*p));assert(p);char*ids[]={"K","A\"\\\n","é","😀"};r->type_ids=ids;r->type_count=4;memset(r->fingerprint,'a',64);r->fingerprint[64]=0;r->aux_slot_count=8;r->aux_slots=calloc(8,sizeof(*r->aux_slots));assert(r->aux_slots);
for(unsigned a=0;a<8;a++){r->aux_slots[a].slot_id=a;r->aux_slots[a].scope=a%2;for(unsigned o=0;o<3;o++){p->aux[a][o].kind=a%2;p->aux[a][o].has_value=a%3!=0;p->aux[a][o].bool_value=(int32_t)draw();p->aux[a][o].square=0;}}
r->board_size=4;
for(unsigned mask=0;mask<65536;mask++){for(unsigned i=0;i<16;i++){p->board[i].occupied=(mask>>i)&1;p->board[i].base_type=i%4;p->board[i].current_type=(i+1)%4;p->board[i].owner=i%2;p->board[i].promoted=i%2;}p->side_to_move=mask%2;check(r,p);}
unsigned sizes[]={8,12,16,18,24,32};
for(unsigned ni=0;ni<6;ni++){r->board_size=(uint8_t)sizes[ni];unsigned cells=sizes[ni]*sizes[ni];for(unsigned k=0;k<2048;k++){
memset(p->board,0,sizeof(p->board));unsigned density=k%8;
for(unsigned i=0;i<cells;i++){p->board[i].occupied=k==0?0:k==1?1:(draw()%8<density);p->board[i].base_type=draw()%4;p->board[i].current_type=draw()%4;p->board[i].owner=draw()%2;p->board[i].promoted=draw()%2;}
for(unsigned o=0;o<2;o++)for(unsigned t=0;t<4;t++)p->hand_counts[o][t]=(uint16_t)(draw()%65536);
for(unsigned a=0;a<8;a++)for(unsigned o=0;o<3;o++)p->aux[a][o].square=(uint16_t)(draw()%cells);
p->side_to_move=k%2;check(r,p);
}}
free(p);free(r->aux_slots);free(r);printf("{\"checks\":%zu,\"canonical_bytes_compared\":%zu,\"equal\":true,\"scope\":\"Actual compiled old/new key functions with SHA-update byte interception; not SHA algorithm validation or legal-game reachability\"}\n",checks,total_bytes);return 0;}
