from pathlib import Path
import sys,json,uuid
ROOT=Path.cwd();b=(ROOT/'.local_agent/backend-owner-20261015').resolve();private=(ROOT/'.local_agent').resolve();key=uuid.uuid4().hex;reads=[]
allowed_flags={private/x for x in ['rollout.json','advisor.json','slack.json','session.json']}
def audit(event,args):
 if event!='open' or not args or not isinstance(args[0],(str,bytes)):return
 p=Path(args[0]).resolve()
 if p.is_relative_to(private):
  if not p.is_relative_to(b) and p not in allowed_flags:raise RuntimeError('unarchived private input read: '+str(p))
  reads.append(str(p.relative_to(private)))
sys.addaudithook(audit)
exec(compile((b/'owned_replay_common.py').read_text(encoding='utf-8'),'<owned_replay_common>','exec'))
rows=[];declines=[]
inputs=json.loads((prior/'qualification-inputs.json').read_text(encoding='utf-8'))['rows']+[x for x in json.loads((prior/'fresh/samples.json').read_text(encoding='utf-8'))['samples']if x['included']]+[x for x in json.loads((b/'new32-inputs.json').read_text(encoding='utf-8'))['samples']if x['included']]
for x in inputs:
 c,s=case(x)
 for version,compiler in [('V1',nc.compile_native_semantic_rules),('V2',compilewide)]:
  try:nr=compiler(c)
  except nc.NativeUnsupportedRuleError:
   assert version=='V1'and c.board_size>16;declines.append(x['name']);continue
  np=pack_semantic_search_position(c,nr,s);check(c,s,nr,np);codes=sem.guarded_actions(nr,np);decoded=tuple(sem.public_action(nr,a)for a in codes);assert set(decoded)==set(s.legal_actions());assert all(pack_semantic_action(nr,s.state.position,a)==z for a,z in zip(decoded,codes));count=0
  for a,z in sorted(zip(decoded,codes),key=lambda item:repr(item[0]))[:6]:
   state=apply_action(s.state,a,c);check(c,SimpleNamespace(state=state,_search_witnesses=(*s._search_witnesses,state.position)),nr,sem.make_checked(nr,np,z));count+=1
  rows.append({'root':x['name'],'n':c.board_size,'version':version,'actions':len(codes),'checked_edges':count});print(x['name'],version,len(codes),flush=True)
assert native._MODULE is installed
out={'complete':True,'rows':rows,'capacity_declines':declines,'default_unchanged':True,'all_other_private_reads_rejected':True,'private_inputs_read':sorted(set(reads)),'scope':'Actual local self-contained source/input replay; no resource curves rerun or pristine machine dependency installation claimed.'};(b/('verification-'+key+'.json')).write_bytes((json.dumps(out,indent=2)+'\n').encode());print('REPLAY',key,'contexts',len(rows),'actions',sum(x['actions']for x in rows),'edges',sum(x['checked_edges']for x in rows))
