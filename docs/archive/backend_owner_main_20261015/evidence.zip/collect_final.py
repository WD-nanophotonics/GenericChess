from pathlib import Path
import sys,pytest,json,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
b=ROOT/'.local_agent/backend-owner-20261015'
class R:
 def pytest_collection_finish(self,session):self.nodes=[x.nodeid for x in session.items]
r=R();code=pytest.main(['--collect-only','-q','-p','no:cacheprovider'],plugins=[r]);old=json.loads((b/'full-suite.json').read_text());new=[x for x in r.nodes if any(k in x for k in ['test_new_engine_uses_existing_rules_owner_after_default_changes','test_capability_checks_follow_bound_owner_not_default','test_compile_metadata_uses_same_captured_backend'])];base=[x for x in r.nodes if x not in new];assert len(new)==4;assert hashlib.sha256(json.dumps(base).encode()).hexdigest()==old['nodeids_sha256'];(b/'final-coverage.json').write_bytes((json.dumps({'collection_exit':int(code),'final_collected':len(r.nodes),'unique':len(set(r.nodes)),'full_actual_passed':old['passed'],'new_separately_passed_nodeids':new,'prior_node_hash_exactly_matches_final_collection_minus_new4':True,'final_nodeids_sha256':hashlib.sha256(json.dumps(r.nodes).encode()).hexdigest(),'qualification':'2580actualfull+4additional newly authored actual checks, production source unchanged. Not a claim a single2584fullrun executed.'},indent=2)+'\n').encode());print('COVERAGE',len(r.nodes),len(new));raise SystemExit(code)
