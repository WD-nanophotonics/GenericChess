from pathlib import Path
import sys,importlib.util,json,time,pytest
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')];b=ROOT/'.local_agent/backend-owner-20261015'
import generic_chess.native as native
assert native._MODULE is None # process startup selection, no existing capsule rerouting
spec=importlib.util.spec_from_file_location('candidate._native_core',next(b.glob('main_v1*.pyd')));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);native._MODULE=module
class R:
 def __init__(self):self.passed=[];self.failed=[]
 def pytest_collection_finish(self,session):self.nodes=[x.nodeid for x in session.items]
 def pytest_runtest_logreport(self,r):
  if r.when=='call'and r.passed:self.passed.append(r.nodeid)
  if r.failed:self.failed.append({'node':r.nodeid,'phase':r.when,'failure':str(r.longrepr)})
r=R();start=time.perf_counter();targets=['tests/product/test_native_semantic_qsearch.py','tests/product/test_native_terminal_policy_support.py','tests/product/test_no_contest_search.py','tests/product/test_completed_root_win.py','tests/product/test_h50b2e_semantic_search_engine.py','tests/product/test_h50b2a_semantic_native_search.py','tests/product/test_native_semantic_backend_owner.py'];code=pytest.main(['-q','-p','no:cacheprovider',*targets],plugins=[r]);(b/'main-v1-guards.json').write_bytes((json.dumps({'exit':int(code),'collected':len(r.nodes),'passed':len(r.passed),'failures':r.failed,'seconds':time.perf_counter()-start,'startup_image':'privateV1 mainbinary only; product C unchanged'},indent=2)+'\n').encode());raise SystemExit(code)
