"""An existing semantic object keeps the kernel that created its capsules."""
import pytest
import generic_chess.native as native
from generic_chess.native import semantic as sem
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.mirror import pack_semantic_action
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
from test_native_semantic_qsearch import fixture, Material

pytestmark = pytest.mark.skipif(not native.native_available(), reason="Native unavailable")

class WrongDefault:
    def __getattr__(self, name):
        raise AssertionError("operation escaped its rules backend: " + name)

@pytest.mark.parametrize("path", ["state", "engine", "iterative", "cancel"])
def test_compiled_semantic_objects_keep_creating_backend(monkeypatch, path):
    session = fixture()
    nr = compile_native_semantic_rules(session.compiled)
    engine = SemanticSearchEngine(session.compiled, nr, board_values=Material.values,
        hand_values=Material.values, tt_megabytes=1, ordering_cache_enabled=False)
    pos = pack_semantic_search_position(session.compiled, nr, session)
    action = session.legal_actions()[0]
    code = pack_semantic_action(nr, session.state.position, action)
    before = sem.snapshot(nr, pos)
    monkeypatch.setattr(native, "_MODULE", WrongDefault())
    if path == "state":
        again = pack_semantic_search_position(session.compiled, nr, session)
        assert sem.snapshot(nr, again) == before
        assert sem.public_action(nr, code) == action
        assert pack_semantic_action(nr, session.state.position, action) == code
        assert code in sem.guarded_actions(nr, pos)
        assert sem.make_unmake_roundtrip(nr, pos, code)["ok"]
    elif path == "iterative":
        result = sem.semantic_iterative_search(nr, pos, 2,
            board_values=Material.values, hand_values=Material.values,
            max_time_seconds=5, root_window_pruning=True)
        assert result["completed_depth"] == 2
        assert sem.public_action(nr, result["best_action"]) in session.legal_actions()
    else:
        token = CancellationToken() if path == "cancel" else None
        if token is not None:
            token.cancel()
        result = engine.search(session, SearchLimits(max_depth=2, max_time_seconds=5,
            quiescence_max_depth=1), token, root_window_pruning=True)
        if token is not None:
            assert result.stop_reason == "cancelled"
        else:
            assert result.completed_depth == 2
            assert result.action in session.legal_actions()
        engine.clear_tt()
        assert engine.tt_info()["occupied_entries"] == 0
    assert sem.snapshot(nr, pos) == before
