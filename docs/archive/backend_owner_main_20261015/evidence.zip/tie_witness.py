from pathlib import Path
import sys,importlib.util,json,time,pytest
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')];b=ROOT/'.local_agent/backend-owner-20261015'
import generic_chess.native as native
assert native._MODULE is None # process startup selection, no existing capsule rerouting
spec=importlib.util.spec_from_file_location('candidate._native_core',next(b.glob('main_v1*.pyd')));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);native._MODULE=module
sys.path.insert(0,str(ROOT/'tests/development'))
from test_native_root_tie_refinement import ep
from generic_chess.native import semantic as sem
rows=[]
for profile in ['material','zero']:
 for tt in [0,1,64]:
  nr,pos,values=ep()
  if profile=='zero':values={tid:0 for tid in nr.type_ids}
  raw=sem.semantic_iterative_search(nr,pos,3,board_values=values,hand_values=values,tt_megabytes=tt,root_window_pruning=True);rows.append({'profile':profile,'tt':tt,'score':raw['score'],'refinements':raw['root_tie_refinements'],'aborts':raw['root_tie_aborts']})
(b/'main-tie-witness.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print(rows)
