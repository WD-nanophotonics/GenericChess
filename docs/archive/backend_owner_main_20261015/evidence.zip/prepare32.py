from pathlib import Path
import sys,subprocess,time,json
b=Path('.local_agent/backend-owner-20261015');plan=json.loads((b/'new32-plan.json').read_text());rows=[];samples=[];start=time.perf_counter()
for seed in plan['seeds']:
 t=time.perf_counter()
 try:
  r=subprocess.run([sys.executable,str(b/'prepare32_one.py'),str(seed)],capture_output=True,text=True,timeout=45);(b/f'new32-prepare-{seed}.log').write_bytes((r.stdout+r.stderr).encode());row={'seed':seed,'exit':r.returncode,'status':'complete'if r.returncode==0 else'failed','seconds':time.perf_counter()-t}
 except subprocess.TimeoutExpired as e:row={'seed':seed,'status':'45s_censored','seconds':time.perf_counter()-t};(b/f'new32-prepare-{seed}.log').write_bytes((e.stdout or b'')+(e.stderr or b''))
 p=b/f'new32-input-{seed}.json'
 if p.exists():data=json.loads(p.read_text(encoding='utf-8'));samples+=data['samples'];row['saved_roots']=len(data['samples'])
 else:row['saved_roots']=0
 rows.append(row);(b/'new32-inputs.json').write_bytes((json.dumps({'complete':False,'samples':samples,'preparation':rows,'seconds':time.perf_counter()-start})+'\n').encode());print(row,flush=True)
(b/'new32-inputs.json').write_bytes((json.dumps({'complete':True,'samples':samples,'preparation':rows,'seconds':time.perf_counter()-start})+'\n').encode())
