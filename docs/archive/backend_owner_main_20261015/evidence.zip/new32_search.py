from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
class Material:
 def __init__(self,c):self.v={tid:0 if mt.is_anchor else 100 for tid,mt in c.support.type_metadata.items()}
 def type_value(self,tid):return self.v[tid]
 def evaluate(self,state):
  side=state.position.side_to_move
  return sum((1 if x.owner==side else -1)*self.v[x.current_type_id]for x in state.position.board if x)+sum((1 if o==side else -1)*self.v[tid]*n for o,h in enumerate(state.position.hands)for tid,n in h.items())
 def capture_order_value(self,moving,captured):return 10*self.v[captured.current_type_id]-self.v[moving.current_type_id]
plan=json.loads((b/'new32-search-plan.json').read_text());data=json.loads((b/'new32-inputs.json').read_text());assert data['complete'];assert not(b/'new32-search-results.json').exists();rows=[];qualified=[];start=time.monotonic()
def save(complete=False,error=None):
 (b/'new32-search-results.json').write_bytes((json.dumps({'complete':complete,'rows':rows,'qualified':qualified,'seconds':time.monotonic()-start,'error':error,'default_unchanged':native._MODULE is installed})+'\n').encode())
try:
 for x in data['samples']:
  if not x['included']:continue
  c,s=case(x);before=record_value(s.to_record());nr=compilewide(c);pos=pack_semantic_search_position(c,nr,s);snap=check(c,s,nr,pos);codes=sem.guarded_actions(nr,pos);decoded=tuple(sem.public_action(nr,z)for z in codes);assert set(decoded)==set(s.legal_actions());assert all(pack_semantic_action(nr,s.state.position,a)==z for a,z in zip(decoded,codes))
  children=[]
  for a,z in sorted(zip(decoded,codes),key=lambda az:(0 if getattr(az[0],'promotion_target_id',None)is not None or az[0].__class__.__name__=='SemanticDropMove'else 1,repr(az[0])))[:6]:
   child=sem.make_checked(nr,pos,z);state=apply_action(s.state,a,c);check(c,SimpleNamespace(state=state,_search_witnesses=(*s._search_witnesses,state.position)),nr,child);children.append(record_value(a))
  assert sem.snapshot(nr,pos)==snap;qualified.append({'root':x['name'],'actions':len(codes),'checked_children':children,'full_history':len(snap['history']),'type_count':len(nr.type_ids),'max_promotion_targets':max(len(t['promo_targets'])for t in ns['build_semantic_compile_payload'](c)[0]['types'])});save()
  ev=Material(c)
  for config in plan['modes']:
   for order in [0,1]:
    for arm in (plan['arms']if order==0 else plan['arms'][::-1]):
     p.rr.stopped();assert native._MODULE is installed
     if time.monotonic()-start>1200:raise TimeoutError('original1200s total fuse')
     limits=SearchLimits(max_depth=8,max_time_seconds=config['seconds'],quiescence_max_depth=config['q'],quiescence_hard_max_depth=8);t=time.perf_counter()
     if arm=='boundV2':
      e=SemanticSearchEngine(c,nr,board_values=ev.v,hand_values=ev.v,tt_megabytes=0,ordering_cache_enabled=False);prep=time.perf_counter()-t;r=e.search(s,limits,root_window_pruning=True);backend='bound private V2/semantic1024'
     else:
      e=AlphaBetaPlayer(c,evaluator_override=ev,use_tt=False,use_disk_cache=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_native_semantic_check=True,tuning=SearchTuning(use_root_tactical=False,require_full_pv=True));assert e.native_legality_provider is None;prep=time.perf_counter()-t;r=e.choose_action(s,limits);backend='Core unsupported V1 fallback'
     rows.append({'root':x['name'],'n':32,'q':config['q'],'seconds':config['seconds'],'order':order,'arm':arm,'backend':backend,'preparation_seconds':prep,'caller_seconds':time.perf_counter()-t,'result':record_value(r)})
     assert record_value(s.to_record())==before
     state=s.state
     for a in r.principal_variation:assert a in legal_actions(state,c);state=apply_action(state,a,c)
     save();print(x['name'],config,order,arm,'depth',r.completed_depth,'q',r.result_ordinary_qdepth,r.termination_reason,flush=True)
 save(True);print('COMPLETE',len(qualified),len(rows),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
