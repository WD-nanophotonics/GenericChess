from pathlib import Path
exec(compile(Path('.local_agent/backend-owner-20261015/owned_common.py').read_text(encoding='utf-8'),'<owned_common>','exec'))
spec=importlib.util.spec_from_file_location('mainowner._native_core',next(b.glob('main_binary*.pyd')));profilemodule=importlib.util.module_from_spec(spec);spec.loader.exec_module(profilemodule)
class Bridge(V2Boundary):
 def semantic_engine_search(self,*args):
  out=self.kernel.semantic_engine_search(*args);self.last={k:out.get(k,0)for k in ['scan_profile_ns','scan_profile_calls','q_checked_profile_ns']};return out
bridges={'existingV2':Bridge(wide),'mainV2':Bridge(profilemodule)}
compilers={}
for name,bridge in bridges.items():
 space=dict(ns);space['_module']=lambda bridge=bridge:bridge;exec(inspect.getsource(nc.compile_native_semantic_rules),space);compilers[name]=space['compile_native_semantic_rules']
inputs=json.loads((prior/'qualification-inputs.json').read_text(encoding='utf-8'))['rows']+[x for x in json.loads((prior/'fresh/samples.json').read_text(encoding='utf-8'))['samples']if x['included']]+[x for x in json.loads((b/'new32-inputs.json').read_text())['samples']if x['included']]
rows=[];start=time.monotonic()
def save(complete=False,error=None):
 (b/'main-resource-results.json').write_bytes((json.dumps({'complete':complete,'rows':rows,'seconds':time.monotonic()-start,'error':error,'default_unchanged':native._MODULE is installed})+'\n').encode())
try:
 for x in inputs:
  c,s=case(x);v={tid:0 if mt.is_anchor else 100 for tid,mt in c.support.type_metadata.items()};before=record_value(s.to_record());rules={name:compilers[name](c)for name in bridges}
  for seconds in [2,8]:
   for order in [0,1]:
    for arm in (list(bridges)if order==0 else list(bridges)[::-1]):
     p.rr.stopped();assert native._MODULE is installed
     if time.monotonic()-start>1800:raise TimeoutError('declared1800s resourcefuse')
     t=time.perf_counter();e=SemanticSearchEngine(c,rules[arm],board_values=v,hand_values=v,tt_megabytes=0,ordering_cache_enabled=False);r=e.search(s,SearchLimits(max_depth=12,max_time_seconds=seconds,quiescence_max_depth=4),root_window_pruning=True);rows.append({'root':x['name'],'n':c.board_size,'order':order,'q':4,'seconds':seconds,'arm':arm,'caller_seconds':time.perf_counter()-t,'result':record_value(r),'profile':dict(bridges[arm].last)});assert record_value(s.to_record())==before;save()
  print(x['name'],len(rows),flush=True)
 save(True);print('COMPLETE',len(rows),time.monotonic()-start,flush=True)
except BaseException:save(False,traceback.format_exc());raise
