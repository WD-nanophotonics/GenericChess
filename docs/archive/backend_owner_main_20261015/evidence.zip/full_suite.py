from pathlib import Path
import sys,time,json,hashlib,pytest
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
b=ROOT/'.local_agent/backend-owner-20261015';started=time.perf_counter()
class Records:
 def __init__(self):self.nodes=[];self.passed=[];self.failed=[]
 def pytest_collection_finish(self,session):self.nodes=[x.nodeid for x in session.items]
 def pytest_runtest_logreport(self,report):
  if report.when=='call' and report.passed:self.passed.append(report.nodeid)
  if report.failed:self.failed.append({'nodeid':report.nodeid,'when':report.when,'longrepr':str(report.longrepr)})
r=Records();code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(b/'full-temp')],plugins=[r]);(b/'full-suite.json').write_bytes((json.dumps({'exit':int(code),'seconds':time.perf_counter()-started,'collected':len(r.nodes),'unique':len(set(r.nodes)),'passed':len(r.passed),'failed':r.failed,'nodeids_sha256':hashlib.sha256(json.dumps(r.nodes).encode()).hexdigest()},indent=2)+'\n').encode());raise SystemExit(code)
