from pathlib import Path
import sys,json,inspect,importlib.util,time,hashlib,random,traceback,threading
from types import SimpleNamespace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.identity import position_identity_key
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
import generic_chess.native as native
import generic_chess.native.compiler as nc
from generic_chess.native import semantic as sem
from generic_chess.native.mirror import pack_semantic_action,expected_snapshot
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
b=ROOT/'.local_agent/backend-owner-20261015';prior=b/'frozen_inputs'
installed=native._module();spec=importlib.util.spec_from_file_location('ownerwide._native_core',next(b.glob('baseline_v2*.pyd')));wide=importlib.util.module_from_spec(spec);spec.loader.exec_module(wide)
class V2Boundary:
 # Public Python dictionaries keep their existing no-promotion/drop sentinels;
 # raw C V1/V2 layouts and capsule names stay distinct and reject mixed input.
 def __init__(self,kernel=wide):self.kernel=kernel
 def __getattr__(self,name):return getattr(self.kernel,name)
 def semantic_action_pack(self,fields):
  f=dict(fields)
  if f['promotion']==255:f['promotion']=127
  if f['kind']==3:f['from']=1023
  return self.kernel.semantic_action_pack(f)
 def semantic_action_unpack(self,code):
  f=self.kernel.semantic_action_unpack(code)
  if f['promotion']==127:f['promotion']=255
  if f['kind']==3:f['from']=255
  return f
boundary=V2Boundary();ns=dict(nc.__dict__);ns.update(_module=lambda:boundary,native_available=lambda:True,SEMANTIC_PAYLOAD_VERSION=5)
source=inspect.getsource(nc._native_payload_is_executable).replace('report.board_squares <= 256','report.board_squares <= 1024');exec(source,ns)
source=inspect.getsource(nc.build_semantic_compile_payload).replace('1 <= n <= 16 and n * n <= 256','1 <= n <= 32 and n * n <= 1024');exec(source,ns)
exec(inspect.getsource(nc.compile_native_semantic_rules),ns);compilewide=ns['compile_native_semantic_rules']

def case(x):
 if x.get('recipe'):
  from test_no_contest_search import defender_root
  s=defender_root();action,=[a for a in s.legal_actions() if record_value(a)==x['attack']];s.submit(action);c=s.compiled
 else:
  r=deserialize_ruleset(json.dumps(x['ruleset']))
  if r.semantic_actions:c=compile_ruleset_for_execution(r)
  else:
   raw=p.compile_legacy_ruleset_for_semantic_execution(r);c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
  s=GameSession(c)
  if x.get('walk') is not None:walk=x['walk']
  else:walk=[record_value(a)for a in deserialize_game_record(json.dumps(x['game_record'])).actions]
  for value in walk:
   a,=[a for a in s.legal_actions() if record_value(a)==value];s.submit(a)
 assert record_value(s.state)==x['state'],x['name']
 return c,s

def check(c,s,nr,pos):
 snap=sem.snapshot(nr,pos);expected=expected_snapshot(s.state.position,nr,c)
 for k in ['board','hands','aux_state','side']:assert record_value(snap[k])==record_value(expected[k]),k
 assert snap['ply']==s.state.ply_count
 assert sem.position_key(nr,pos)==str(position_identity_key(s.state.position,c))
 assert snap['history_exact'] and snap['history_events_exact']
 assert len(snap['history'])==len(s._search_witnesses)==len(s.state.history)
 assert [''.join(f'{v:016x}' for v in h)for h in snap['history']]==[str(position_identity_key(w,c))for w in s._search_witnesses]
 assert snap['history_events']==tuple((255 if x.actor<0 else x.actor,bool(x.gave_check))for x in s.state.history)
 return snap

