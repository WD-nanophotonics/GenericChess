from pathlib import Path
import sys,importlib.util,json,time,pytest
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')];b=ROOT/'.local_agent/backend-owner-20261015'
import generic_chess.native as native
assert native._MODULE is None # process startup selection, no existing capsule rerouting
spec=importlib.util.spec_from_file_location('candidate._native_core',next(b.glob('scoped_v1*.pyd')));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);native._MODULE=module
class R:
 def __init__(self):self.passed=[];self.failed=[]
 def pytest_collection_finish(self,session):self.nodes=[x.nodeid for x in session.items]
 def pytest_runtest_logreport(self,report):
  if report.when=='call'and report.passed:self.passed.append(report.nodeid)
  if report.failed:self.failed.append({'node':report.nodeid,'phase':report.when,'failure':str(report.longrepr)})
r=R();start=time.perf_counter();targets=[];code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(b/'full-scoped-temp'),*targets],plugins=[r]);(b/'scoped-v1-full.json').write_bytes((json.dumps({'exit':int(code),'collected':len(r.nodes),'passed':len(r.passed),'failures':r.failed,'seconds':time.perf_counter()-start,'startup_image':'privateV1 mainbinary only; product C unchanged'},indent=2)+'\n').encode());raise SystemExit(code)
