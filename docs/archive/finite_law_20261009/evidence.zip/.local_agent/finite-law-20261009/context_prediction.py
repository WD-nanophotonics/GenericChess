"""Predeclared development check on frozen6x6 routes, no parameter fitting.

Decision: is a fixed-stock law worth general profile replacement? Compare raw
supported endpoint-count prediction at actual actor sources, not material utility.
Population all original four routes, root through recorded final ply. Include
terminal states as geometric contexts; report them, never legal mobility/WDL.
Three laws: old fixed mixture, current-stock uniform finite, matched independent.
Primary observable per-actor quiet/capture endpoint absolute error; no threshold
is chosen after results, no extra games/generated samples or default changes.
"""
from finite_law import *
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from statistics import mean
def main():
 p=Path(__file__).parent;inputpath=ROOT/'.local_agent/generated6-20261008/coverage.json';inp=json.loads(inputpath.read_bytes());cfg=EvaluationConfig();out=[];start=time.perf_counter()
 for case in inp['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));A=c.board_shape.area;g=GameSession(c)
  edges={pt.type_id:collect(c,c.ir,pt.type_id,cfg)[0] for pt in c.piece_types if not pt.is_anchor}
  for ply in range(len(case['route'])+1):
   board=g.state.position.board;stock=tuple(sum(x is not None and x.owner==o for x in board) for o in (0,1));occupied={i for i,x in enumerate(board) if x is not None}
   assert min(stock)>=1
   for src,actor in enumerate(board):
    if actor is None or actor.current_type_id not in edges:continue
    row=dict(seed=case['seed'],ply=ply,source=src,owner=actor.owner,type=actor.current_type_id,stock=stock,terminal=g.state.terminal_status.is_terminal,counts={})
    for kind in ('target_empty','target_enemy'):
     bucket=edges[actor.current_type_id][kind][actor.owner*A+src];actual=0;pred=dict(old_mixture=0.,finite=F(0),matched_independent=0.)
     n=sum(stock)-1;d=n/(A-1);tc=A-sum(stock) if kind=='target_empty' else stock[1-actor.owner];M=n-int(kind=='target_enemy')
     for target,events in bucket.items():
      assert target!=src and all(src not in a|b and target not in a|b for a,b,_ in events)
      relation=board[target] is None if kind=='target_empty' else board[target] is not None and board[target].owner!=actor.owner
      actual+=int(relation and any(not occupied&cl and (k is None or len(occupied&cells)==k) for cl,cells,k in events))
      if tc:pred['finite']+=F(tc,A-1)*union(canon(events),A-2,M)
      pred['matched_independent']+=sem._path_union(events,d)*tc/(A-1)
      pred['old_mixture']+=sum(w*sem._path_union(events,density)*(1-density if kind=='target_empty' else density/2) for w,density in zip(cfg.density_weights,cfg.density_points))
     row['counts'][kind]=dict(actual=actual,predicted={k:float(v) for k,v in pred.items()})
    out.append(row)
   if ply<len(case['route']):g.submit(action_from_dict(case['route'][ply]['action']))
 summary=[]
 for seed in sorted({r['seed'] for r in out}):
  rows=[r for r in out if r['seed']==seed];summary.append(dict(seed=seed,positions=len({r['ply'] for r in rows}),actor_observations=len(rows),terminal_contexts=len({r['ply'] for r in rows if r['terminal']}),mae={kind:{law:mean(abs(r['counts'][kind]['predicted'][law]-r['counts'][kind]['actual']) for r in rows) for law in ('old_mixture','finite','matched_independent')} for kind in ('target_empty','target_enemy')}))
 result=dict(complete=True,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(inputpath.read_bytes()).hexdigest(),summary=summary,rows=out,seconds=time.perf_counter()-start,scope=__doc__)
 (p/'context-prediction.json').write_bytes(json.dumps(result,indent=2,sort_keys=True).encode());print(json.dumps(summary,indent=2));print('seconds',result['seconds'])
if __name__=='__main__':main()
