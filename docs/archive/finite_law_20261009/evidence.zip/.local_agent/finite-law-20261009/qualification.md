# Conditional finite-stock occupancy, development diagnostic

This law fixes initial owner on-board stock and averages hypothetical source
replacement/equal source-owner mass. It does not infer a unique rule-law, legal
reachable population, future promotion/custody utility, material prices or WDL.
Same supported endpoint subset/exclusions as semantic-opportunity-v1; raw
quiet/capture, normalization and conditional law are reported separately.
No default/evaluator/profile API changes. No human labels/holdout reads/fitting.

Exact construction: after fixing an own source, target-empty mass is
(A-n0-n1)/(A-1), target-enemy mass is n_other/(A-1). After conditioning the
target, N=A-2 cells have M=n0+n1-1 occupied for quiet or M=n0+n1-2 for enemy.
For a constrained assignment over u cells with r occupied, its mass is
C(N-u,M-r)/C(N,M). Joint count/clear intersections count assignments including
shared cells, then inclusion-exclusion unions endpoint alternatives. No
independence assumption between overlapping paths. Existing12-event limit stays.

378 subset controls enumerate all M-subsets for N2..8 and nine overlapping/
contradictory/redundant event families.40 independently colored controls over
582 full source-conditioned layouts verify target/path conditioning and unequal
owner stocks.15 capped/enumerated ray controls agree exactly and saturate at the
finite-board boundary under three stocks. These prove these finite controls,
not all execution semantics or a universal utility.

Advisor's fixed-stock joint-law objection adopted: uniform six layouts gives
one enemy-conditioned ray endpoint1/6 and cannon2/3; a two-layout correlated
law gives1/2 and0 at identical stock3/1 and identical1/2 square marginals.
Actual Core capture eligibility agrees on12 analysis positions. A6 abstract
cells are embedded in a supported4x4 board, other10 always empty in both laws;
these are anchor-free analysis states, not legal game positions or a full16-cell
uniform law. Initial6x1 attempt was rejected by minimum board size, a subsequent
initial setup by anchor legality, and legal-action comparison by anchor effects;
final scope deliberately uses capture eligibility to match the claimed observable.

Canonical Chess/Shogi and four existing generated6x6 rules are descriptive
outputs, not a preferred-ratio search. Fixed stock primarily selects density;
matched independent marginals are close. Chess B/N crosses between selected
sparse/dense stock contexts; neither ordering is universal price evidence.

A separately declared prediction check reuses68 frozen route contexts and1256
actual non-anchor actor-source observations. The observable is supported raw
endpoint count, including terminal contexts as geometry, never legal mobility.
Finite law improves quiet MAE in3/4 rules but worsens capture MAE inall4. No
fitting/threshold/result-driven extension. Current-stock finite and matched-
independent predictions are very close. Do not promote a material table or
expand this law comparison merely to repair ratios. A later task needs a
specific predictive/deployment question and independently justified context law.

Execution failures retained here: first finite-law producer read initial_position
from IR rather than compiled executable; corrected before any completed record.
Prediction producer first used Piece.type_id rather than current_type_id;
corrected before any completed record. No overwritten successful comparison.
Producer hashes refer to the final successful sources. Exact data/inputs archived.
