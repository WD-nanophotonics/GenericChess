"""Existing format1 manifests; explicit purpose-separated Agent-only members."""
from pathlib import Path
import json,hashlib,zipfile,re
root=Path.cwd();base=root/'.local_agent';sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads((root/p).read_bytes())
def archive(label,files):
 dest=root/'docs/archive'/label;dest.mkdir(parents=True,exist_ok=True);z=dest/'evidence.zip';assert not z.exists();records=[]
 with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zz:
  for file in files:
   file=Path(file);body=(root/file).read_bytes()
   if file.suffix in ('.py','.json','.md','.txt'):
    assert not re.search(rb'xox[baprs]-[A-Za-z0-9-]+|xapp-[A-Za-z0-9-]+|BEGIN [A-Z ]*PRIVATE KEY|icy'+b'woods|C0C6'+b'L21UU20|U0C6'+b'G6AU6MQ',body),file
   member=file.as_posix();zz.writestr(member,body);records.append(dict(member=member,original=member,bytes=len(body),sha256=sha(body)))
 extracted=base/('extracted-'+label);assert not extracted.exists();extracted.mkdir()
 with zipfile.ZipFile(z) as zz:
  assert zz.testzip() is None
  for member in zz.namelist():assert (extracted/member).resolve().is_relative_to(extracted.resolve())
  zz.extractall(extracted)
 for record in records:
  b=(extracted/record['member']).read_bytes();assert len(b)==record['bytes'] and sha(b)==record['sha256']
 index=dict(format=1,scope='Agent-generated sources/results only; no private/user input/raw Slack/account/credentials. Explicit derived failure summary omits personal absolute-path tracebacks; original retained locally.',base_product_sha='af8ed2c62f4c87a17e7fe33d2e2df3a65fd3af2e',members=records,member_count=len(records),archive_sha256=sha(z.read_bytes()),archive_bytes=z.stat().st_size,total_uncompressed_bytes=sum(r['bytes'] for r in records),extracted_hashes_verified=True,recovery='Extract into an isolated checkout; verify member hashes. Restore only selected original relative input/producer paths, never overlay the live checkout wholesale. Product patch is in Git delivery; producer/product hashes identify exact version. Deferred unexecuted pilot is historical, not a runnable claim.')
 (dest/'index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(label,index['member_count'],index['archive_bytes']);return index
def files(folder,names):return ['.local_agent/'+folder+'/'+x for x in names]
finite=archive('finite_law_20261009',files('finite-law-20261009',['finite_law.py','finite-law.json','law_controls.py','law_controls.json','context_prediction.py','context-prediction.json','qualification.md','package_evidence.py'])+['.local_agent/generated6-20261008/coverage.json','tests/product/test_semantic_ray_equivalence.py','tests/rule_semantics_ir_fixtures.py'])
query=archive('query_transfer_20261009',files('query-transfer-20261009',['declaration.json','event_query_replay.py','event-query-replay.json','event-query-analysis.json','pattern-filter-declaration.json','pattern_filter_pilot.py','pattern-filter-decision.json','membership-declaration.json','membership_pilot.py','membership-pilot.json','membership-analysis.json','membership_product_replay.py','membership-product-replay.json','membership-product-analysis.json','membership_authority6.py','membership-authority6.json'])+['.local_agent/generated6-20261008/coverage.json','.local_agent/generated6-20261008/event-frontiers.json','.local_agent/qsemantics-20261008/fresh-reuse.json','.local_agent/pawn-bias-20261008/semantic-executor-before.py','tests/product/test_geometry_target_query.py'])
rect=archive('rect_search_20261009',files('rect-search-20261009',['rect_probe.py','rect-before-summary.json','rect_after.py','rect-after.json','rect_qpilot.py','rect-qpilot.json','full-tests.txt','final-focused-tests.txt'])+['tests/product/test_rectangular_search_override.py','tests/rule_semantics_ir_fixtures.py'])
f=read('.local_agent/finite-law-20261009/finite-law.json');controls=read('.local_agent/finite-law-20261009/law_controls.json');predict=read('.local_agent/finite-law-20261009/context-prediction.json')
f.pop('cache',None);f.update(recovery='docs/archive/finite_law_20261009/index.json',archive_sha256=finite['archive_sha256'],controls={k:v for k,v in controls.items() if k!='producer_sha256'},actual_context_prediction={'summary':predict['summary'],'actor_observations':len(predict['rows']),'scope':predict['scope']},decision='Keep conditional diagnostic, not general profile/default. Fixed stock does not fix spatial law; no material utility claim. Canonical comparison completed cheaply before advisor objection read; no further cross-game expansion adopted.')
(root/'docs/research/data/finite_law_20261009.json').write_bytes((json.dumps(f,indent=2)+'\n').encode())
q=dict(scope='Existing exposed6x6 event-query transfer and small membership-miss fast path. Exact semantics/work; local timing only, no strength/default/price/cache claim.',recovery='docs/archive/query_transfer_20261009/index.json',archive_sha256=query['archive_sha256'],event_transfer=read('.local_agent/query-transfer-20261009/event-query-analysis.json'),membership=read('.local_agent/query-transfer-20261009/membership-analysis.json'),product=read('.local_agent/query-transfer-20261009/membership-product-analysis.json'),authority6=read('.local_agent/query-transfer-20261009/membership-authority6.json'),pattern_filter=read('.local_agent/query-transfer-20261009/pattern-filter-decision.json'))
(root/'docs/research/data/query_transfer_20261009.json').write_bytes((json.dumps(q,indent=2)+'\n').encode())
after=read('.local_agent/rect-search-20261009/rect-after.json');qp=read('.local_agent/rect-search-20261009/rect-qpilot.json')
rr=dict(scope='Public Core rectangular search with caller-owned unit evaluator; no generated default price/Native rectangle/strength claim. Custom override profile property nowNone, cache-hitFalse.',recovery='docs/archive/rect_search_20261009/index.json',archive_sha256=rect['archive_sha256'],before=read('.local_agent/rect-search-20261009/rect-before-summary.json'),after=after,qfollowup=qp,validation='1667full active regressions pass; final Native size guard/new test additionally covered by final-focused-tests.txt.14rectangle tests pass; relevant publication tests will rerun against final commit.')
(root/'docs/research/data/rect_search_20261009.json').write_bytes((json.dumps(rr,indent=2)+'\n').encode())
