"""Independent colored enumeration, matched-marginal and actual endpoint controls."""
from finite_law import *
from dataclasses import replace
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.rules.schema import RuleSet,RuleSemanticAction,RuleGeometrySpec,RulePathConstraint,RuleActionEffect,RuleSquareRef
from generic_chess.core.semantic_executor import SemanticEngine
from test_semantic_ray_equivalence import ray_family
from rule_semantics_ir_fixtures import _king_type

def colored_controls():
    cases=layouts=0
    events=canon(((frozenset({1}),frozenset({1,2,3}),1),(frozenset(),frozenset({2,3}),1)))
    for A in (6,7):
      for stock in ((1,1),(2,2),(3,1),(1,3),(3,3)):
       for owner in (0,1):
        cells=set(range(1,A));allboards=[]
        for friends in combinations(cells,stock[owner]-1):
         for enemy in combinations(cells-set(friends),stock[1-owner]):
          allboards.append((set(friends),set(enemy)))
        layouts+=len(allboards)
        for kind in ('target_empty','target_enemy'):
         target=A-1
         truth=F(sum((target not in f|e if kind=='target_empty' else target in e) and any(not (f|e)&cl and (k is None or len((f|e)&counted)==k) for cl,counted,k in events) for f,e in allboards),len(allboards))
         targetcount=A-sum(stock) if kind=='target_empty' else stock[1-owner]
         M=sum(stock)-1-int(kind=='target_enemy')
         predicted=F(targetcount,A-1)*union(events,A-2,M) if targetcount else F(0)
         assert truth==predicted,(A,stock,owner,kind,truth,predicted)
         cases+=1
    return dict(cases=cases,colored_layouts=layouts)

def fixed_stock_joint_witness():
    actions=[]
    for tid,predicate in (('R','path_clear'),('C','path_count_eq')):
      actions.append(RuleSemanticAction(name=tid+'_capture',type_ids=(tid,),geometry=RuleGeometrySpec(kind='ray',direction=(1,0),min_steps=3,max_steps=3),target_relation='enemy',composition='augment',path_constraints=(RulePathConstraint(predicate,count=1) if tid=='C' else RulePathConstraint(predicate),),effects=(RuleActionEffect('remove',square_ref=RuleSquareRef('target'),piece_owner='opponent'),RuleActionEffect('move',from_ref=RuleSquareRef('source'),to_ref=RuleSquareRef('target')))))
    initial=((Piece(0,'C','C'),None,None,None),(Piece(0,'K','K'),Piece(0,'W','W'),None,None),(None,)*4,(None,None,None,Piece(1,'K','K')))
    definition=RuleSet(board_size=4,piece_types=(_king_type(),)+tuple(PieceType(t,t,()) for t in ('R','C','W')),initial_position=initial,drop_allowed={t:((False,)*16,)*2 for t in ('R','C','W')},semantic_actions=tuple(actions))
    c=compile_ruleset_for_execution(definition);e=SemanticEngine(c);base=e._initial_position();rows=[]
    for blockers in combinations((1,2,4,5),2):
     answers={}
     for actor in ('R','C'):
      board=[None]*16;board[0]=Piece(0,actor,actor);board[3]=Piece(1,'W','W')
      board[blockers[0]]=Piece(0,'W','W');board[blockers[1]]=Piece(0,'W','W')
      pos=replace(base,board=tuple(board),side_to_move=0)
      answers[actor]=e.is_square_attacked(pos,3,0)
      assert answers[actor]==(len(set(blockers)&{1,2})==(0 if actor=='R' else 1))
     rows.append(dict(blockers=blockers,answers=answers))
    laws={'uniform':rows,'correlated':[r for r in rows if set(r['blockers']) in ({1,2},{4,5})]}
    result={}
    for name,ls in laws.items():
     result[name]=dict(stock=[3,1],marginals={str(x):str(F(sum(x in r['blockers'] for r in ls),len(ls))) for x in (1,2,4,5)},capture={t:str(F(sum(r['answers'][t] for r in ls),len(ls))) for t in ('R','C')})
    assert result['uniform']['marginals']==result['correlated']['marginals']
    assert result['uniform']['capture']=={'R':'1/6','C':'2/3'}
    assert result['correlated']['capture']=={'R':'1/2','C':'0'}
    return dict(layouts=rows,laws=result,actual_Core_positions=12,abstract_area=6,product_embedding_area=16,scope='six active cells embedded in4x4 because height1 unsupported; other10 always empty in both laws. Anchor-free analysis positions; actual capture eligibility, not legal anchor safety. Single enemy-conditioned endpoint; same exact inventory/marginals, different joint law; not whole-piece price or full16-cell uniform law')

def matched_independent(c,stock):
    ir=c.ir;A=c.board_shape.area;cfg=EvaluationConfig();result={}
    for pt in c.piece_types:
     edges,_,_=collect(c,ir,pt.type_id,cfg);vals={k:0. for k in edges}
     for kind,buckets in edges.items():
      for i,bucket in enumerate(buckets):
       owner=i//A;d=(sum(stock)-1)/(A-1)
       target=(A-sum(stock))/(A-1) if kind=='target_empty' else stock[1-owner]/(A-1)
       vals[kind]+=sum(sem._path_union(paths,d)*target for paths in bucket.values())/(2*A)
     result[pt.type_id]=dict(quiet=vals['target_empty'],capture=vals['target_enemy'],raw=sum(vals.values()))
    return result

def stock_comparison():
    out={}
    for name,build,stocks in [('chess',build_western_chess_ruleset,((2,2),(8,8),(16,16),(24,24),(32,32))),('shogi',build_standard_shogi_ruleset,((2,2),(10,10),(20,20),(30,30),(40,40)))]:
     c=compile_ruleset_for_execution(build());rows=[]
     for stock in stocks:
      exact=measure(c,stock);independent=matched_independent(c,stock)
      rows.append(dict(stock=stock,finite={t:{k:r[k] for k in ('quiet','capture','raw','exact_raw')} for t,r in exact['types'].items()},matched_independent=independent))
     out[name]=rows
    return out

def encoding_controls():
    rows=[]
    for stock in ((1,1),(6,6),(12,12)):
      previous=None
      for length in (1,2,3,4,5):
       a=measure(ray_family(length,False),stock)['types']['C'];b=measure(ray_family(length,True),stock)['types']['C']
       assert a['exact_raw']==b['exact_raw']
       if previous is not None:assert a['raw']>=previous['raw']
       if length==5:assert a['exact_raw']==previous['exact_raw']
       rows.append(dict(stock=stock,length=length,raw=a['exact_raw'],quiet=a['quiet'],capture=a['capture']))
       previous=a
    return rows

if __name__=='__main__':
    t=time.perf_counter();out=dict(colored_controls=colored_controls(),fixed_stock_joint_witness=fixed_stock_joint_witness(),stock_comparison=stock_comparison(),encoding_controls=encoding_controls(),scope='development conditional-law controls; no unique-law, price, strength or deployment claim',complete=True)
    out['seconds']=time.perf_counter()-t;out['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    Path(__file__).with_suffix('.json').write_bytes(json.dumps(out,indent=2,sort_keys=True).encode());print(out['seconds'],out['colored_controls'],out['fixed_stock_joint_witness']['laws'])
