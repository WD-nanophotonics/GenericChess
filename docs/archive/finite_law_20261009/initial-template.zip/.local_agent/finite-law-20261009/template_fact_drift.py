"""Qualify apparent initial-template improvement by changed relevant board facts.
Same1256actors; reference unchanged. Initial exactness and unchanged capture facts
are tautological, not prediction success. For every supported endpoint compare
initial/current enemy truth and path-open truth; group any change versus none,
and actual-zero/nonzero. No thresholds, fits, new samples or numerical changes.
Question: does improvement survive changed facts/nonzero observations, or only
reproduce initial/local unchanged geometry? <=60sec mechanical enumeration.
"""
from finite_law import *
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from scripts.research_record import write_record
from statistics import mean
p=Path(__file__).parent;out=p/'template-fact-drift.json';assert not out.exists();prior=json.loads((p/'initial-template.json').read_bytes());lookup={(r['seed'],r['ply'],r['source']):r for r in prior['rows']};inp=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes());rows=[];start=time.perf_counter()
for case in inp['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));g=GameSession(c);initial=g.state.position.board;A=c.board_shape.area;initial_occ={i for i,x in enumerate(initial) if x is not None};edges={pt.type_id:collect(c,c.ir,pt.type_id,EvaluationConfig())[0] for pt in c.piece_types if not pt.is_anchor}
 for ply in range(len(case['route'])+1):
  assert time.perf_counter()-start<60;board=g.state.position.board;actual_occ={i for i,x in enumerate(board) if x is not None}
  for source,actor in enumerate(board):
   if actor is None or actor.current_type_id not in edges:continue
   z=lookup[(case['seed'],ply,source)];diff_target=diff_path=0;actual_count=initial_count=0
   for target,events in edges[actor.current_type_id]['target_enemy'][actor.owner*A+source].items():
    e0=initial[target] is not None and initial[target].owner!=actor.owner;e1=board[target] is not None and board[target].owner!=actor.owner
    def open_(occ):return any(not occ&cl and (k is None or len(occ&cells)==k) for cl,cells,k in events)
    p0=open_(initial_occ-{source});p1=open_(actual_occ-{source});diff_target+=e0!=e1;diff_path+=p0!=p1;initial_count+=e0 and p0;actual_count+=e1 and p1
   assert initial_count==z['initial_template'] and actual_count==z['actual']
   rows.append(dict(z,target_truth_changes=diff_target,path_truth_changes=diff_path))
  if ply<len(case['route']):g.submit(action_from_dict(case['route'][ply]['action']))
assert len(rows)==1256
summary=[]
for seed in sorted({r['seed'] for r in rows}):
 for group,accept in [('unchanged_facts',lambda r:not(r['target_truth_changes'] or r['path_truth_changes'])),('changed_facts',lambda r:bool(r['target_truth_changes'] or r['path_truth_changes'])),('changed_nonzero',lambda r:bool(r['target_truth_changes'] or r['path_truth_changes']) and r['actual']>0),('changed_zero',lambda r:bool(r['target_truth_changes'] or r['path_truth_changes']) and r['actual']==0)]:
  z=[r for r in rows if r['seed']==seed and accept(r)]
  summary.append(dict(seed=seed,group=group,n=len(z),mae={k:mean(abs(r[k]-r['actual']) for r in z) if z else None for k in ('finite','initial_template')},exact_template=sum(r['initial_template']==r['actual'] for r in z)))
write_record(out,dict(complete=True,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256((p/'initial-template.json').read_bytes()).hexdigest(),rows=rows,summary=summary,seconds=time.perf_counter()-start));print(json.dumps(summary,indent=2))
