"""Frozen initial-layout reference versus uniform-stock count diagnostic.
Decision: does retaining declared initial spatial structure offer useful raw
capture prediction, or is its utility lost after actual actions? Reuse same
68contexts/1256actors; no new sample, law sweep, parameter fitting or material
price claim. Chosen reference is the unmodified initial board from each RuleSet;
for every actual source/type, exclude that source from initial occupied cells,
place a hypothetical actor, and count enemy endpoints with actual event paths
on that fixed template. This substitution is an opportunity task, not a legal
position or conserved-stock distribution. Targets/types belong to the actual
actor; no actual enemy layout is read by the predictor. Descriptive comparison
on exposed routes grouped by initial vs successor and source initially own vs
other; exact counts/rule identities kept, no holdout restoration/default change.
Incremental cost <=60sec plus records; one writer, no search, seeds or worker.
"""
from finite_law import *
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from scripts.research_record import write_record
from statistics import mean
p=Path(__file__).parent;out=p/'initial-template.json';assert not out.exists()
prior=json.loads((p/'error-localization.json').read_bytes());lookup={(r['seed'],r['ply'],r['source']):r for r in prior['rows']};inp=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes());rows=[];start=time.perf_counter()
for case in inp['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));g=GameSession(c);initial=g.state.position.board;A=c.board_shape.area;occupied={i for i,x in enumerate(initial) if x is not None};edges={pt.type_id:collect(c,c.ir,pt.type_id,EvaluationConfig())[0] for pt in c.piece_types if not pt.is_anchor}
 for ply in range(len(case['route'])+1):
  assert time.perf_counter()-start<60
  for source,actor in enumerate(g.state.position.board):
   if actor is None or actor.current_type_id not in edges:continue
   z=lookup[(case['seed'],ply,source)];assert actor.current_type_id==z['type'];counts=0;occ=occupied-{source}
   for target,events in edges[actor.current_type_id]['target_enemy'][actor.owner*A+source].items():
    enemy=initial[target] is not None and initial[target].owner!=actor.owner
    clear=any(not occ&cl and (k is None or len(occ&cells)==k) for cl,cells,k in events)
    counts+=int(enemy and clear)
   rows.append(dict(z,initial_template=counts,initial_source_own=initial[source] is not None and initial[source].owner==actor.owner))
  if ply<len(case['route']):g.submit(action_from_dict(case['route'][ply]['action']))
assert len(rows)==len(prior['rows'])==1256
summary=[]
for seed in sorted({r['seed'] for r in rows}):
 for group,accept in [('all',lambda r:True),('initial',lambda r:r['ply']==0),('successors',lambda r:r['ply']>0),('source_initially_own',lambda r:r['initial_source_own']),('source_not_initially_own',lambda r:not r['initial_source_own'])]:
  z=[r for r in rows if r['seed']==seed and accept(r)]
  summary.append(dict(seed=seed,group=group,n=len(z),mae={k:mean(abs(r[k]-r['actual']) for r in z) if z else None for k in ('finite','initial_template')},exact_template=sum(r['initial_template']==r['actual'] for r in z)))
write_record(out,dict(complete=True,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputs={name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ('error-localization.json',)},rows=rows,summary=summary,seconds=time.perf_counter()-start));print(json.dumps(summary,indent=2))
