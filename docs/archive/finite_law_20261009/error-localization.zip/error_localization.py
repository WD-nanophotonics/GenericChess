"""Localize fixed-stock capture error, without changing laws or adding samples.

Same68 frozen contexts/1256 actors. Two diagnostic ORACLES: supply actual target
relation but keep finite path law; supply actual path event but keep finite target
marginal. Neither is a rule-only estimator/material utility/legal mobility. No
fitting, thresholds, new games, profile/default or extension of earlier tests.
The decision is whether a next diagnostic should address endpoint population or
joint path structure; oracle error alone cannot identify a causal repair.
"""
from finite_law import *
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from statistics import mean

def main():
 p=Path(__file__).parent;out=p/'error-localization.json';assert not out.exists()
 inp=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes());cfg=EvaluationConfig();rows=[];start=time.perf_counter()
 for case in inp['cases']:
  c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));g=GameSession(c);A=c.board_shape.area
  edges={pt.type_id:collect(c,c.ir,pt.type_id,cfg)[0] for pt in c.piece_types if not pt.is_anchor}
  for ply in range(len(case['route'])+1):
   assert time.perf_counter()-start<60
   board=g.state.position.board;stock=tuple(sum(x is not None and x.owner==o for x in board) for o in (0,1));occupied={i for i,x in enumerate(board) if x is not None}
   for source,actor in enumerate(board):
    if actor is None or actor.current_type_id not in edges:continue
    kind='target_enemy';bucket=edges[actor.current_type_id][kind][actor.owner*A+source];M=sum(stock)-2;target_mass=F(stock[1-actor.owner],A-1)
    actual=0;finite=target_oracle=path_oracle=F(0)
    for target,events in bucket.items():
     enemy=board[target] is not None and board[target].owner!=actor.owner
     path_event=any(not occupied&cl and (k is None or len(occupied&cells)==k) for cl,cells,k in events)
     probability=union(canon(events),A-2,M)
     actual+=int(enemy and path_event);finite+=target_mass*probability;target_oracle+=int(enemy)*probability;path_oracle+=target_mass*int(path_event)
    rows.append(dict(seed=case['seed'],ply=ply,source=source,type=actor.current_type_id,actual=actual,finite=float(finite),target_oracle=float(target_oracle),path_oracle=float(path_oracle)))
   if ply<len(case['route']):g.submit(action_from_dict(case['route'][ply]['action']))
 summary=[dict(seed=seed,actors=len(z:=[r for r in rows if r['seed']==seed]),mae={name:mean(abs(r[name]-r['actual']) for r in z) for name in ('finite','target_oracle','path_oracle')}) for seed in sorted({r['seed'] for r in rows})]
 result=dict(complete=True,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),summary=summary,rows=rows,seconds=time.perf_counter()-start)
 (p/'error-localization.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
