"""Describe frozen endpoint errors by rule/actor, without refitting laws.

Group all1256 existing observations by(seed,type), reporting actual-zero fraction,
MAE and signed bias. Explanatory witness is largest finite absolute capture error
(lexical seed/ply/source tie break), not an independent test. Reconstruct its
original route and all endpoint events, proving same aggregate counts. Decide
whether an actor-specific numerical correction is warranted or spatial endpoint
structure must be kept explicit. No additional games, density or sample sweep.
"""
from finite_law import *
from generic_chess.session.session import GameSession
from generic_chess.core.actions import action_from_dict
from statistics import mean
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'type-localization.json';assert not out.exists()
prior=json.loads((p/'error-localization.json').read_bytes());rows=prior['rows'];groups=[]
for seed,kind in sorted({(r['seed'],r['type']) for r in rows}):
 z=[r for r in rows if (r['seed'],r['type'])==(seed,kind)]
 groups.append(dict(seed=seed,type=kind,n=len(z),actual_zero=sum(r['actual']==0 for r in z),actual_mean=mean(r['actual'] for r in z),mae={k:mean(abs(r[k]-r['actual']) for r in z) for k in ('finite','target_oracle','path_oracle')},signed_bias=mean(r['finite']-r['actual'] for r in z)))
w=min(rows,key=lambda r:(-abs(r['finite']-r['actual']),r['seed'],r['ply'],r['source']))
inp=json.loads((ROOT/'.local_agent/generated6-20261008/coverage.json').read_bytes());case=next(x for x in inp['cases'] if x['seed']==w['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));g=GameSession(c)
for step in case['route'][:w['ply']]:g.submit(action_from_dict(step['action']))
board=g.state.position.board;source=w['source'];actor=board[source];A=c.board_shape.area;stock=tuple(sum(x is not None and x.owner==o for x in board) for o in (0,1));occupied={i for i,x in enumerate(board) if x is not None}
bucket=collect(c,c.ir,actor.current_type_id,EvaluationConfig())[0]['target_enemy'][actor.owner*A+source];targets=[]
for target,events in bucket.items():
 enemy=board[target] is not None and board[target].owner!=actor.owner;path_event=any(not occupied&cl and (k is None or len(occupied&cells)==k) for cl,cells,k in events);prob=union(canon(events),A-2,sum(stock)-2)
 targets.append(dict(target=target,occupant=None if board[target] is None else dict(owner=board[target].owner,type=board[target].current_type_id),enemy=enemy,path_open=path_event,finite_path=str(prob),finite_capture=float(F(stock[1-actor.owner],A-1)*prob),events=[dict(clear=sorted(cl),count_cells=sorted(cells),count_eq=k) for cl,cells,k in events]))
assert sum(r['enemy'] and r['path_open'] for r in targets)==w['actual']
assert abs(sum(r['finite_capture'] for r in targets)-w['finite'])<1e-12
write_record(out,dict(complete=True,declaration=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256((p/'error-localization.json').read_bytes()).hexdigest(),groups=groups,witness=dict(original=w,owner=actor.owner,stock=stock,targets=targets)))
print(json.dumps(groups,indent=2));print('witness',w,'owner',actor.owner,'stock',stock,'endpoints',len(targets),'enemy',sum(r['enemy'] for r in targets),'open',sum(r['path_open'] for r in targets))
