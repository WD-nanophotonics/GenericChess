"""Read-only full-history draw diagnostics; never rewrite frozen game outcomes."""
import sys,json,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'.local_agent/certificate_source/python-chess')]
import chess
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'draw-audit.json';assert not out.exists();start=time.perf_counter()
report=dict(complete=False,scope='Post-hoc diagnostics of completed frozen streams, not rescored WDL. Library automatic draw and hypothetical first available draw claim are separate; no actual claim was issued. Insufficient-material detector is not an exhaustive proof of all dead positions.',fide_source='https://handbook.fide.com/chapter/E012023',library_sha256=hashlib.sha256((ROOT/'.local_agent/certificate_source/python-chess/chess/__init__.py').read_bytes()).hexdigest(),core_rules_sha256=hashlib.sha256((ROOT/'generic_chess/rules/western_chess.py').read_bytes()).hexdigest(),core_contract=dict(repetition_limit=100000,max_ply=1000,stalemate_result='draw'),groups={})
for mode in ('price','original'):
 raw=(p/(mode+'.json')).read_bytes();v=json.loads(raw);assert v['complete'] and len(v['games'])==12;rows=[]
 for gi,g in enumerate(v['games']):
  b=chess.Board(g['initial_fen']);first_auto=first_claim=None
  history=g['opening_uci']+[r['move'] for r in g['moves']]
  for ply in range(len(history)+1):
   if not b.is_checkmate():
    if first_auto is None:
     z=b.outcome(claim_draw=False)
     if z is not None and z.winner is None:first_auto=dict(ply=ply,termination=z.termination.name,fen=b.fen(en_passant='fen'))
    if first_claim is None:
     reason='FIFTY_MOVES' if b.can_claim_fifty_moves() else 'THREEFOLD_REPETITION' if b.can_claim_threefold_repetition() else None
     if reason:first_claim=dict(ply=ply,termination=reason,fen=b.fen(en_passant='fen'))
   if ply<len(history):assert chess.Move.from_uci(history[ply]) in b.legal_moves;b.push_uci(history[ply])
  rows.append(dict(index=gi,id=g['id'],table=g['table'],candidate_color=g['candidate_color'],fixture_end=g['end'],fixture_winner=g['winner'],fixture_finished=g['finished'],first_supported_automatic_draw=first_auto,first_hypothetical_claim=first_claim,continued_after_auto=first_auto is not None and first_auto['ply']<len(history),continued_after_claim=first_claim is not None and first_claim['ply']<len(history)))
 report['groups'][mode]=dict(source_sha256=hashlib.sha256(raw).hexdigest(),games=rows,automatic_draw_streams=sum(r['first_supported_automatic_draw'] is not None for r in rows),claim_available_streams=sum(r['first_hypothetical_claim'] is not None for r in rows),finished_after_auto=sum(r['fixture_finished'] and r['continued_after_auto'] for r in rows),finished_after_claim=sum(r['fixture_finished'] and r['continued_after_claim'] for r in rows))
 write_record(out,report)
report.update(complete=True,wall_seconds=time.perf_counter()-start);write_record(out,report);print(json.dumps({m:{k:v for k,v in z.items() if k not in ('games','source_sha256')} for m,z in report['groups'].items()}))
