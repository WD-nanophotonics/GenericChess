"""Archive complete fixed-setting feedback, not strength certification."""
import sys,json,hashlib,zipfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record
p=Path(__file__).parent;a=ROOT/'docs/archive/development_see_opening_20261007';out=ROOT/'docs/research/data/chess_see_opening_20261007.json';assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest();decl=json.loads((p/'declaration.json').read_bytes());assert sha((p/'games.py').read_bytes())==decl['producer_sha256'];assert sha((p/'replay.py').read_bytes())==decl['replay_sha256']
files=[p/n for n in ('declaration.json','suite.json','draw-audit.json')];groups={}
draw_audit=json.loads((p/'draw-audit.json').read_bytes());assert draw_audit['complete']
for mode in ('price','original'):
 v=json.loads((p/(mode+'.json')).read_bytes());r=json.loads((p/(mode+'-replay.json')).read_bytes());assert v['complete'] and r['complete'] and len(r['games'])==12 and not r['errors']
 methods={}
 for g in r['games']:
  z=methods.setdefault(g['table'],dict(wins=0,losses=0,draws=0,unfinished=0));z['unfinished' if not g['finished'] else 'draws' if g['winner'] is None else 'wins' if g['winner']==g['candidate_color'] else 'losses']+=1
 groups[mode]=dict(methods=methods,cells=r['games'],wall_seconds=v['wall_seconds'],recording_cost_before_final_save=v['recording_cost_before_final_save'],replay=dict(streams=12,played_plies=r['played_plies'],prefix_plies=r['prefix_plies'],mismatches=0))
 files.extend(p/n for n in (mode+'.json',mode+'-replay.json'))
totals={k:{metric:sum(x[metric] for x in g['methods'].values()) for metric in ('wins','losses','draws','unfinished')} for k,g in groups.items()}
# The old feedback saturation branch is not this experiment's decision rule.
# Preserve matched cell outcomes, without adding a result-dependent cutoff.
paired=[]
def outcome(g):
 return 'unfinished' if not g['finished'] else 'draw' if g['winner'] is None else 'win' if g['winner']==g['candidate_color'] else 'loss'
for left,right in zip(groups['price']['cells'],groups['original']['cells']):
 assert (left['id'],left['table'],left['candidate_color'])==(right['id'],right['table'],right['candidate_color'])
 paired.append(dict(id=left['id'],table=left['table'],candidate_color=left['candidate_color'],price=outcome(left),original=outcome(right),price_plies=left['plies'],original_plies=right['plies']))
a.mkdir(exist_ok=True);entries={};sources={}
def archive(path,items,target):
 assert not path.exists()
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f,n in items:
   b=f.read_bytes();assert not re.search(rb'[A-Za-z]:[\\/]+Users[\\/]+',b) and not re.search(rb'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}',b);z.writestr(n,b);target[n]=dict(bytes=len(b),sha256=sha(b))
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None and set(z.namelist())==set(target)
  for n,h in target.items():assert sha(z.read(n))==h['sha256']
archive(a/'raw.zip',[(f,f.name) for f in files],entries)
upstream=ROOT/'.local_agent/mature-search/Fairy-Stockfish-9f778da667f6e07dae1e85d3e2ea204fc6dee94d'
archive(a/'sources.zip',[(p/n,'see-opening-20261007/'+n) for n in ('games.py','replay.py','collect.py','draw-audit.py')]+[(ROOT/'scripts/chess_development.py','shared-chess_development.py'),(ROOT/'scripts/research_record.py','shared-research_record.py'),(ROOT/'generic_chess/rules/western_chess.py','shared-western_chess.py'),(upstream/'src/position.cpp','pinned-position.cpp'),(upstream/'Copying.txt','upstream-Copying.txt'),(ROOT/'.local_agent/mature-search/material-variants.ini','material-variants.ini'),(p/'suite.json','suite.json')],sources)
summary=dict(scope='Fixed2400option exposed development feedback; native price/original arithmetic-only SEE contrast at identical conditions. Option label not measured Elo, limited play can be stochastic. No human/exposed-label fitting, tier fishing, coefficient/default/Elo/holdout claim.',parent_sha='9c1c9d671c0092ada0f622ece850f2538e571eb3',declaration=decl,groups=groups,totals=totals,paired_cells=paired,raw_entries=entries,sources=sources,raw_archive=a.relative_to(ROOT).as_posix()+'/raw.zip',sources_archive=a.relative_to(ROOT).as_posix()+'/sources.zip',raw_zip_sha256=sha((a/'raw.zip').read_bytes()),sources_zip_sha256=sha((a/'sources.zip').read_bytes()),production_changes='None; two isolated binaries, same half-risk leaf/search/defaults. SEE LVA ordering and thresholds unchanged; not a generic SEE repair',public_push='Standing user authorization; actual publication verified separately after commit and push')
summary.update(draw_audit=draw_audit,interpretation='Separate24cells at two new6ply prefixes, all outcomes retained. Conditions otherwise match prior24; stochastic exposed development feedback, no tier/weight/default/strength/Elo/holdout claim. Draw diagnostics do not retrospectively alter fixture outcomes; future policy is separate.')
write_record(out,summary);write_record(a/'index.json',dict(raw_entries=entries,sources=sources,portable_sha256=sha(out.read_bytes())));print(json.dumps(dict(totals=totals,replay={k:g['replay'] for k,g in groups.items()},sha256=sha(out.read_bytes()))))
