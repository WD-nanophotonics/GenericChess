"""Scoped actual q0 consumer on active drop-prohibition and generated auxiliary state."""
import sys,json,time
from pathlib import Path
from dataclasses import replace
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.core.position import Hands,GameState,HistoryRecord
from generic_chess.core.pieces import Piece
from generic_chess.core.identity import position_identity_key
from generic_chess.core.terminal import terminal_result,TerminalResult,TerminalStatus
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import write_record,record_value
from rule_semantics_ir_fixtures import uchifuzume_ruleset
out=ROOT/'.local_agent/q0-consumer-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does corrected existing whole-C q0 Material consumer actually support unfamiliar auxiliary/history and activeS4 drops, and what completes versus Core under fixedwork/equal-time?',roots=['activeS4','generated1091'],fixed_depth=2,budgets=[1,16,64],calls=32,depth=12,nodes=1000000,q=0,hardq=0,scope='8fixedD2 controls Native/Core q0 (same frozen rule-derived board/hand tables; TT0);24timecells same actual q0 Native exactrootoptin/TT1 vs Core PVS/TTfresh. Engines unequal algorithm/TT representation, not pure scheduling ratio. Complete legalPV/fullhistory; explicit constructor/request decline, terminal scores not unit-aligned. No q4 substitute/full-domain proof/default/UI. Fixed reverseorders, source exposed not holdout, no addedroots/caps. Total declared timebudget648seconds plus fixedcalls128seconds<=13minutes; ordinary concurrent load.'))
roots={};rules=uchifuzume_ruleset();c=compile_ruleset_for_execution(rules);pos=GameSession(c).state.position;board=[None]*64;board[5*8+6]=Piece(0,'K','K');board[6*8+6]=Piece(0,'P','P');board[7*8+7]=Piece(1,'K','K');pos=replace(pos,board=tuple(board),hands=(Hands((('P',1),)),Hands.empty()));key=position_identity_key(pos,c);state=GameState(pos,0,((key,1),),TerminalResult(TerminalStatus.ONGOING),history=(HistoryRecord(key,-1,'',False),));state=replace(state,terminal_status=terminal_result(state,c));roots['activeS4']=(rules,c,SimpleNamespace(compiled=c,state=state,_search_witnesses=(pos,),result=SimpleNamespace(status=SimpleNamespace(value='ongoing'))))
sample=json.loads((ROOT/'.local_agent/aux-quiet-20261012/active-mixed-premise.json').read_bytes())[0];rules=ruleset_from_dict(sample['rules']);c=compile_ruleset_for_execution(rules);s=GameSession(c)
for _ in range(4):
 aa=s.legal_actions();aux=[a for a in aa if 'promotion_grants_one_turn_right' in a.pattern_id];s.submit(aux[0] if aux else sorted(aa,key=repr)[0])
assert record_value(s.state)==sample['state'] and record_value(s._search_witnesses)==sample['witnesses'];roots['generated1091']=(rules,c,s)
class Frozen:
 def __init__(self,board,hand):self.board=board;self.hand=hand
 def evaluate(self,state):
  p=state.position;v=[0,0]
  for pc in p.board:
   if pc:v[pc.owner]+=self.board[pc.current_type_id]
  for side,h in enumerate(p.hands):
   for tid,count in h.counts:v[side]+=self.hand[tid]*count
  return v[p.side_to_move]-v[1-p.side_to_move]
 def capture_order_value(self,tid,**kw):return self.board[tid]
rows=[];inputs={}
for name,(rules,c,s) in roots.items():
 profile=build_ruleset_profile(c,EvaluationConfig());provider=NativeSemanticLegalityProvider.try_create(c,strict=True);assert provider
 bv=dict(profile.board_value_by_type);hv=dict(profile.hand_value_by_base_type);inputs[name]=dict(rules=serialize_ruleset(rules),state=record_value(s.state),witnesses=record_value(s._search_witnesses),board=bv,hand=hv,native_types=list(provider.native_rules.type_ids));write_record(out/'inputs.json',inputs)
 for kind,budgets in [('fixed',[16]),('delivery',[1,16,64])]:
  for sec in budgets:
   for repeat,arms in enumerate([['native','core'],['core','native']]):
    for arm in arms:
     frozen=Frozen(bv,hv);saved=record_value(s.state);setup=time.perf_counter()
     try:
      if arm=='native':engine=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=0 if kind=='fixed' else 1)
      else:engine=AlphaBetaPlayer(c,evaluator_override=frozen,use_tt=kind!='fixed',use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=kind!='fixed'))
      setup=time.perf_counter()-setup;t=time.perf_counter();limits=SearchLimits(max_depth=2 if kind=='fixed' else 12,max_nodes=1000000,max_time_seconds=sec,quiescence_max_depth=0,quiescence_hard_max_depth=0)
      r=engine.search(s,limits,root_window_pruning=kind!='fixed') if arm=='native' else engine.choose_action(s,limits);elapsed=time.perf_counter()-t
      assert record_value(s.state)==saved
      state=s.state
      for action in r.principal_variation:assert action in legal_actions(state,c);state=apply_action(state,action,c)
      assert r.action in legal_actions(s.state,c);payload=record_value(r);row=dict(root=name,kind=kind,budget=sec,order=repeat,arm=arm,setup_seconds=setup,caller_seconds=elapsed,result=payload,declined=False,root_restored=True,pv_legal=True,pv_terminal=record_value(state.terminal_status),literal_pv_material=frozen.evaluate(state),history_length=len(s.state.history),aux=record_value(s.state.position.aux_state))
     except (ValueError,RuntimeError,NotImplementedError) as e:
      row=dict(root=name,kind=kind,budget=sec,order=repeat,arm=arm,declined=True,error=type(e).__name__,message=str(e));assert record_value(s.state)==saved
     rows.append(row);write_record(out/'result.json',dict(complete=False,rows=rows));print(name,kind,sec,repeat,arm,row.get('declined'),row.get('caller_seconds'),row.get('result',{}).get('completed_depth'),row.get('result',{}).get('score'),flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
