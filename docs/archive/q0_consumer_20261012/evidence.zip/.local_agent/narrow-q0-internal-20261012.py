import sys,os,json,time,sysconfig,importlib.util
from pathlib import Path
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CoreBoard,CASES,VALUES
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.native import semantic as ns
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.audit_lichess_complete_children import uci
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/narrow-q0-20261012/internal-comparison';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists();write_record(out/'declaration.json',dict(question='Does an actual smaller-action falseUPPER tie inside the final selectedrootbranch corrupt finalPV despite retainedfullreplay?',calls=8,setup=['TT0','coldTT1','reversewarmTT1'],parent_moves='e2e4 a7a6 e4e5',root_forced_legal='d7d5',internal_first='f1d3',depth=4,warmdepth=4,seconds=64,nodes=1000000,q=0,scope='Private clonedsameABI bodies forceonly one alreadylegal rootmove andcontrolledply1 order, no productchange/newpositiongenerator. Falseequal classifier independently fullwindowre-searches affected candidate with TTtemporarilyNULL/pv_replayTRUE thenrestores exactchildPV, recordsbound versusactualscore; itswork counted, notperformance evidence. TTtablesindependentperbinary/setup, reverse-order warmcall declared; allqueriesmustcomplete, no caprescue. Eight queries includes twowarmcalls. FinalPV samefullbaseline canonical constrainedorder, not allrootoptimum.'))
c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'));case=dict(next(x for x in CASES if x['id']=='chess-ep'));case['moves']='e2e4 a7a6 e4e5';core=CoreBoard(case,c);session=SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));rows=[]
for arm in ['baseline','narrow']:
 spec=importlib.util.spec_from_file_location('internal_'+arm+'._native_core',ROOT/'.local_agent/narrow-q0-20261012'/('internal-'+arm)/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);native._MODULE=mod
 for setup in ['TT0','coldTT1','reversewarmTT1']:
  provider=NativeSemanticLegalityProvider.try_create(c,strict=True);engine=SemanticSearchEngine(c,provider.native_rules,board_values=VALUES['chess'],hand_values=VALUES['chess'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=0 if setup=='TT0' else 1);old=mod.semantic_engine_search;rawrows=[]
  def capture(*a):r=old(*a);rawrows.append(dict(r));return r
  mod.semantic_engine_search=capture
  try:
   if setup=='reversewarmTT1':
    os.environ['GC_RESEARCH_REVERSE_ORDER']='1';warm=engine.search(session,SearchLimits(max_depth=4,max_nodes=1000000,max_time_seconds=64,quiescence_max_depth=0),root_window_pruning=True);del os.environ['GC_RESEARCH_REVERSE_ORDER'];rows.append(dict(arm=arm,setup='reversewarm_preparation',result=record_value(warm),raw=rawrows[-1]));rawrows=[]
   r=engine.search(session,SearchLimits(max_depth=4,max_nodes=1000000,max_time_seconds=64,quiescence_max_depth=0),root_window_pruning=True);assert r.completed_depth==4;assert core.initial==session.state;state=core.initial;labels=[]
   for a in r.principal_variation:assert a in legal_actions(state,c);labels.append(uci(a));state=apply_action(state,a,c)
   raw=rawrows[-1];rows.append(dict(arm=arm,setup=setup,result=record_value(r),false_equal_count=raw['false_equal_count'],false_bound=raw['false_bound_shifted']-1000000000,false_exact=raw['false_exact_shifted']-1000000000,false_old=uci(ns.public_action(provider.native_rules,raw['false_old_action'])) if raw['false_equal_count'] else None,false_new=uci(ns.public_action(provider.native_rules,raw['false_new_action'])) if raw['false_equal_count'] else None,PV=labels,pv_legal=True,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(arm,setup,r.score,labels,raw['false_equal_count'],rows[-1]['false_old'],rows[-1]['false_new'],rows[-1]['false_bound'],rows[-1]['false_exact'],flush=True)
  finally:mod.semantic_engine_search=old;os.environ.pop('GC_RESEARCH_REVERSE_ORDER',None)
write_record(out/'result.json',dict(complete=True,rows=rows))
