import sys,json,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.coordinates import Square
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/narrow-q0-20261012/PV-difference';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists();write_record(out/'declaration.json',dict(question='Is actual generated1091D4 PVchange a tied continuation or inferior line under the same two-ply residual Material criterion?',calls=4,root='saved commonprefix2 from actual baseline/advancedPV',arms=['baseline_PV_action','advanced_PV_action'],authority=['Native_q0','Core_q0'],remaining_parent_depth=2,forced_child_depth=1,nodes=1000000,seconds=64,q=0,tt=False,scope='Independent fullwindow branch valuation on exact savedhistory, no rerun oldroot/capraise orselectionbylabels. Both actualPVfullCore-replayed andliteral leafscore separately recorded. Only diagnoses exposedPVdifference, not universalcanonicalpolicy/WDL. Advancedvariants remainnotadopted pendingactualmeaning.'))
inp=json.loads((ROOT/'.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes())['generated1091'];c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(inp['rules'])))
def pos(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)
def action(a):
 a=dict(a)
 for k in ['from_square','to_square']:
  if k in a:a[k]=Square(**a[k])
 return SemanticBoardMove(**a) if 'from_square' in a else SemanticDropMove(**a)
d=inp['state'];state=GameState(pos(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));witnesses=tuple(pos(p) for p in inp['witnesses']);r=json.loads((ROOT/'.local_agent/narrow-q0-20261012/root-canonical-comparison/result.json').read_bytes())['rows'];rs=[x for x in r if x['root']=='generated1091' and x['depth']==4 and x['order']==0];pvs={x['arm']:x['result']['principal_variation'] for x in rs};assert pvs['baseline'][:2]==pvs['root-canonical'][:2]
class Frozen:
 def evaluate(self,s):
  p=s.position;v=[0,0]
  for pc in p.board:
   if pc:v[pc.owner]+=inp['board'][pc.current_type_id]
  for side,h in enumerate(p.hands):
   for tid,n in h.counts:v[side]+=inp['hand'][tid]*n
  return v[p.side_to_move]-v[1-p.side_to_move]
 def type_value(self,tid):return inp['board'][tid]
 def capture_order_value(self,a,b):return 10*self.type_value(b.current_type_id)-self.type_value(a.current_type_id)
leaf=Frozen();pvleaf={}
for name,pv in pvs.items():
 ss=state
 for a in pv:a=action(a);assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
 pvleaf[name]=leaf.evaluate(ss)
for a in pvs['baseline'][:2]:state=apply_action(state,action(a),c);witnesses+= (state.position,)
provider=NativeSemanticLegalityProvider.try_create(c,strict=True);rows=[]
for name,pv in pvs.items():
 a=action(pv[2]);assert a in legal_actions(state,c);child=apply_action(state,a,c);s=SimpleNamespace(compiled=c,state=child,_search_witnesses=witnesses+(child.position,),result=SimpleNamespace(status=SimpleNamespace(value='ongoing')))
 for backend in ['native','core']:
  engine=SemanticSearchEngine(c,provider.native_rules,board_values=inp['board'],hand_values=inp['hand'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=0) if backend=='native' else AlphaBetaPlayer(c,evaluator_override=leaf,use_tt=False,use_ordering=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=False));limits=SearchLimits(max_depth=1,max_nodes=1000000,max_time_seconds=64,quiescence_max_depth=0);t=time.perf_counter();r=engine.search(s,limits) if backend=='native' else engine.choose_action(s,limits);assert r.completed_depth==1;rows.append(dict(branch=name,backend=backend,score_at_common_parent=-r.score,seconds=time.perf_counter()-t,result=record_value(r),child=record_value(child),witnesses=record_value(s._search_witnesses),root_restored=s.state==child));print(name,backend,-r.score,flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows,literal_PV_leaf_values=pvleaf,common_parent=record_value(state),scope='Only independent complete sameMaterial residualbranches determine whether PV actions tie; productionunchanged sofar.'))
