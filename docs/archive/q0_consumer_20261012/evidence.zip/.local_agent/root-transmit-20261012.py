"""One saved-parent checking-drop inclusion change propagated to its original root."""
import sys,json,time,inspect,textwrap,hashlib
from pathlib import Path
from types import SimpleNamespace
from collections import Counter
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,Material
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.actions import SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.full_q_refresh_comparison import runtime_state
from scripts.quiet_action_probe import QuietActionProbe
from scripts.research_record import write_record,record_value
out=ROOT/'.local_agent/root-transmit-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
w=json.loads((ROOT/'.local_agent/public-transfer-20261012/checking-scope-witness/witness.json').read_bytes());a=dict(w['action']);a['to_square']=Square(**a['to_square']);extra=SemanticDropMove(**a)
write_record(out/'declaration.json',dict(question='Does the local700-to900 saved-parent change alter the original shogi-drop fullD2/q4 root value or optimal action set?',root='shogi-drop',calls=6,scope='Two publicPVS iterative calls and four exact fullwindow whole-root calls (Native/Core authority x2 inclusionarms). Saved exposed exact position+entire history predicate, qstart0 only, addONLY saved R@a9 at that parent. Other nodescapture-only, alllegalcheck evasions unchanged. TT disabled/fresh perarm, same frozenMaterial/order/caps/fullhistory. Exactscan evaluates EVERY rootbranch fullwindow at depth1/ply1 with same parentD2 q4 context, no childphase reset. Each8192totalnodes/64s/hard8, anyabort leaves whole-rootvalue/setunknown. No capraise/newroots/generalizedselector/UI/default. Direct fixed-depth totals are not iteration-deliverycost; no strength/WDL.',depth=2,q=4,hardq=8,nodes=8192,seconds=64,tt=False))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));core=CoreBoard(next(x for x in CASES if x['id']=='shogi-drop'),c);original=sm._quiescence_runtime;oldattach=SearchPathRuntime.attach_stats;rows=[]
class Inclusion:
 def __init__(self,enabled):self.enabled=enabled;self.counts=Counter();self.windows=[]
 def match(self,ctx,ply,qdepth,alpha,beta):
  rt=ctx.runtime
  if qdepth!=0 or len(rt.history)!=len(w['parent']['history']):return False
  if record_value(rt.position)!=w['parent']['position']:return False
  if record_value(tuple(rt.history))!=w['parent']['history']:return False
  self.counts['exact_parent_visits']+=1;self.windows.append(dict(alpha=alpha,beta=beta,ply=ply,qdepth=qdepth,ordinary_q=sm._ordinary_qdepth_limit(ctx)))
  return True
 def retain(self,match,action):
  if match and action==extra:
   self.counts['target_action_visited']+=1
   if self.enabled:self.counts['target_action_included']+=1;return True
  return False
try:
 for method,backend in [('public','native'),('exact','native'),('exact','core')]:
  for arm in ['capture_only','plus_one']:
   inclusion=Inclusion(arm=='plus_one');probe=QuietActionProbe();src=textwrap.dedent(inspect.getsource(original))
   src=src.replace('    for action in ordered:\n','    target_parent = inclusion.match(ctx,ply,qdepth,alpha,beta)\n    proof_engine = quiet_drop_probe.prepare(ctx)\n    for action in ordered:\n        extra_included = inclusion.retain(target_parent,action)\n        if not extra_included and quiet_drop_probe.exclude(ctx,action,proof_engine,parent_enemies,parent_inventory):\n            continue\n')
   src=src.replace('capture_only=ctx.tuning.use_capture_only_qsearch,','capture_only=ctx.tuning.use_capture_only_qsearch and not extra_included,')
   ns=dict(sm.__dict__,inclusion=inclusion,quiet_drop_probe=probe);exec(compile(src,'<one-exact-parent-inclusion>','exec'),ns);sm._quiescence_runtime=ns['_quiescence_runtime'];rts=[]
   def attach(rt,stats):
    v=oldattach(rt,stats);rts.append((rt,runtime_state(rt)));return v
   SearchPathRuntime.attach_stats=attach;t=time.perf_counter();branches=[];complete=True;reason='complete'
   if method=='public':
    p=AlphaBetaPlayer(c,evaluator_override=Material('shogi'),use_tt=False,use_native_semantic_legality=True,use_native_semantic_availability=True,use_disk_cache=False,tuning=SearchTuning(use_pvs=True,use_ordered_qsearch=True,use_capture_only_qsearch=True))
    r=p.choose_action(SimpleNamespace(compiled=c,state=core.initial,_search_witnesses=core.witnesses),SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=64,quiescence_max_depth=4,quiescence_hard_max_depth=8));complete=r.completed_depth==2;reason=r.termination_reason;payload=record_value(r);stats=None
   else:
    provider=NativeSemanticLegalityProvider.try_create(c,strict=True) if backend=='native' else None
    rt=SearchPathRuntime.from_state(core.initial,c,history_witnesses=core.witnesses,legal_binding_provider=provider,availability_provider=provider.has_legal_action if provider else None);stats=SearchStatistics();rt.attach_stats(stats)
    ctx=sm._Context(c,Material('shogi'),TranspositionTable(max_entries=0),stats,sm._Budget(SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=64,quiescence_max_depth=4,quiescence_hard_max_depth=8),None),SearchTuning(use_pvs=True,use_ordered_qsearch=True,use_capture_only_qsearch=True),False,True,4,8,None,runtime=rt,first_main_iteration_complete=True)
    actions=rt.legal_actions(ctx.checkpoint);stats.nodes=1
    try:
     for action in sorted(actions,key=str):
      ctx.checkpoint()
      with rt.pushed(action,checkpoint=ctx.checkpoint):child=sm.negamax(rt.state,1,-sm.INF,sm.INF,1,ctx,prev_action=action)
      branches.append(dict(action=record_value(action),label=str(action),score=-child.score,pv=record_value((action,)+child.pv)))
    except sm.SearchAborted as e:complete=False;reason=str(e)
    value=max(b['score'] for b in branches) if complete else None;optimal=sorted(b['label'] for b in branches if b['score']==value) if complete else None
    payload=dict(root_value=value,optimal_actions=optimal,legal_root_actions=len(actions),finished_root_actions=len(branches),branches=branches,stats=record_value(stats))
   for rt,before in rts:rt.assert_balanced();assert runtime_state(rt)==before
   rows.append(dict(method=method,backend=backend,arm=arm,complete=complete,reason=reason,seconds=time.perf_counter()-t,result=payload,inclusion_counts=dict(inclusion.counts),windows=inclusion.windows,quiet_counts=dict(probe.counts),root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(method,backend,arm,complete,reason,payload.get('root_value',payload.get('score')),dict(inclusion.counts),rows[-1]['seconds'],flush=True)
   sm._quiescence_runtime=original;SearchPathRuntime.attach_stats=oldattach
finally:sm._quiescence_runtime=original;SearchPathRuntime.attach_stats=oldattach
write_record(out/'result.json',dict(complete=True,rows=rows))
