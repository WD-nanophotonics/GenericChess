import sys,sysconfig,importlib.util
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import generic_chess.native as native
p=ROOT/'.local_agent/narrow-q0-20261012/sorted-replay'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));spec=importlib.util.spec_from_file_location('research._native_core',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);native._MODULE=m
import pytest
raise SystemExit(pytest.main(['-q','tests/development/test_native_root_tie_refinement.py','tests/product/test_h50b2e_semantic_search_engine.py','tests/product/test_native_evaluator_binding.py','-p','no:cacheprovider','--basetemp=.local_agent/pytest-sorted-q0-20261012a']))
