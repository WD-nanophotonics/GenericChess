import sys,json,hashlib,zipfile
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from scripts.research_record import write_record,record_value
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.coordinates import Square
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action

def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)
def state(d):return GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']))
def action(a):
 a=dict(a)
 for k in ['from_square','to_square']:
  if k in a:a[k]=Square(**a[k])
 return SemanticBoardMove(**a) if 'from_square' in a else SemanticDropMove(**a)
inputs=json.loads((ROOT/'.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes());roots={k:(compile_ruleset_for_execution(ruleset_from_dict(json.loads(d['rules']))),state(d['state'])) for k,d in inputs.items()};files=[ROOT/'.local_agent/q0-consumer-20261012/result.json',ROOT/'.local_agent/q0-consumer-resumed-20261012/result.json',ROOT/'.local_agent/q0-order-consumer-resumed-20261012/result.json',ROOT/'.local_agent/q0-order-consumer-auxresumed-20261012/result.json']+[ROOT/'.local_agent/narrow-q0-20261012'/x/'result.json' for x in ['comparison','sorted-comparison','canonical-comparison','root-canonical-comparison']];calls=0;pva=0
for p in files:
 d=json.loads(p.read_bytes())
 for r in d['rows']:
  assert not r.get('declined',False);c,ss=roots[r['root']];pv=r['result']['principal_variation'];assert r.get('root_restored');assert r['result']['qnodes']==0
  for a in pv:a=action(a);assert a in legal_actions(ss,c);ss=apply_action(ss,a,c);pva+=1
  calls+=1
pairs=json.loads((ROOT/'.local_agent/narrow-q0-20261012/fixed-triplet-verification.json').read_bytes());assert len(pairs['advanced_PV_mismatches'])==4;assert all(r['score_equal'] and r['action_equal'] for r in pairs['pairs'])
local=json.loads((ROOT/'.local_agent/narrow-q0-20261012/PV-difference/result.json').read_bytes());assert [r['score_at_common_parent'] for r in local['rows']]==[-4912,-4912,-2514,-2514]
write_record(ROOT/'.local_agent/narrow-q0-20261012/verification.json',dict(q0_root_calls=calls,independent_PV_actions=pva,fixed_pairs=len(pairs['pairs']),advanced_PV_mismatches=4,diagnosed='Both Core/Native independently value oldline residual-4912/newline-2514; meaningful correction, nottie. Allrootvalues/actions unchanged in48fixedpairs. Productionregression binds observedactualPV defect. Whole4cappedrootsetsunknown. Interpreter/serializer/testpath errors retained separately; no erasedfailure.',internal_false_equal_actual_setups=12,scope='Four internal variants each3actualTTsetups trigger100UPPER/exact0; forcedrootbranchqueriesnotwhole-rootoptima. Onephasewarm preparationeachvariantseparate.'))
print('verified',calls,'q0rootcalls',pva,'PV actions')
