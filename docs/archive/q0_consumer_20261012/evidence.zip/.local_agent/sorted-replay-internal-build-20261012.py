import os,sys,sysconfig,subprocess,json,time,hashlib
from pathlib import Path
ROOT=Path.cwd();out=ROOT/'.local_agent/narrow-q0-20261012';inp=json.loads((out/'internal-tie-input.json').read_bytes());rows=[]
for name in ['sorted-replay']:
 src=(out/name/'native_module.c').read_text();src=src.replace('    uint64_t replay_nodes;','    uint64_t replay_nodes;\n    uint64_t false_equal_count;\n    int false_bound, false_exact;\n    uint64_t false_old_action, false_new_action;')
 needle='    size_t i;\n    uint64_t legal_child_index = 0;';assert src.count(needle)==1
 inject=f'''    if (ply == 1) {{
        if (getenv("GC_RESEARCH_REVERSE_ORDER") != NULL) {{
            for (size_t j=0; j<actions.count/2; j++) {{
                uint64_t a=actions.data[j]; actions.data[j]=actions.data[actions.count-1-j]; actions.data[actions.count-1-j]=a;
            }}
        }} else {{
            for (size_t j=0; j<actions.count; j++) if (actions.data[j] == UINT64_C({inp['inner_first']})) {{
                uint64_t a=actions.data[0]; actions.data[0]=actions.data[j]; actions.data[j]=a; break;
            }}
        }}
    }}
'''+needle
 src=src.replace(needle,inject);src=src.replace('        if (gc_semantic_is_declaration_action(action)) continue;',f'        if (gc_semantic_is_declaration_action(action)) continue;\n        if (ply == 0 && action != UINT64_C({inp["root_forced"]})) continue;')
 needle='        int score = -branch;\n        /* A later narrowed root child';assert src.count(needle)==1
 check='''        int score = -branch;
        /* Diagnostic-only exact classification, restore child PV; no score adoption. */
        if (!pv_replay && ply == 1 && found && score == best && action < best_action) {
            uint64_t saved_pv[GC_SEM_MAX_PLY+1];
            uint16_t saved_len=ctx->pv_length[ply+1];
            memcpy(saved_pv,&ctx->pv_table[(size_t)(ply+1)*ctx->pv_stride],sizeof(uint64_t)*saved_len);
            GCSemanticTable *saved_tt=ctx->tt;ctx->tt=NULL;
            int exact=-gc_semantic_iterative_negamax(ctx,ply+1,depth-1,-GC_SEMANTIC_PROBE_INF,GC_SEMANTIC_PROBE_INF,1,1);
            ctx->tt=saved_tt;
            ctx->pv_length[ply+1]=saved_len;
            memcpy(&ctx->pv_table[(size_t)(ply+1)*ctx->pv_stride],saved_pv,sizeof(uint64_t)*saved_len);
            if (ctx->control != 0) break;
            if (exact < best) {
                ctx->false_equal_count++;ctx->false_bound=score;ctx->false_exact=exact;
                ctx->false_old_action=best_action;ctx->false_new_action=action;
            }
        }
        /* A later narrowed root child'''
 src=src.replace(needle,check);marker='"s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K,s:K}",';assert src.count(marker)==1;src=src.replace(marker,'"'+','.join(['s:K']*18)+'}",')
 src=src.replace('        "replay_nodes", ctx.replay_nodes,','        "replay_nodes", ctx.replay_nodes,\n        "false_equal_count", ctx.false_equal_count,\n        "false_bound_shifted", (uint64_t)(1000000000+ctx.false_bound),\n        "false_exact_shifted", (uint64_t)(1000000000+ctx.false_exact),\n        "false_old_action", ctx.false_old_action,\n        "false_new_action", ctx.false_new_action,')
 d=out/('internal-'+name);d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text(src);binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));args=[str(ROOT/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(ROOT/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython'+str(sys.version_info.major)+str(sys.version_info.minor)]+[str(p if f.name=='native_module.c' else f) for f in sorted((ROOT/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)];t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr[-1000:];rows.append(dict(variant=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));print(rows[-1],flush=True)
(out/'internal-build-summary.json').write_text(json.dumps(rows,indent=2))
