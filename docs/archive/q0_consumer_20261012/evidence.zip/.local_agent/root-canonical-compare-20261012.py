"""Isolated same-ABI nonroot AB-window variants, equal fixed controls and budgets."""
import sys,json,time,importlib.util,sysconfig
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import generic_chess.native as native
from generic_chess import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/narrow-q0-20261012/root-canonical-comparison';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Is nonroot all-PV fullwindow an actual search scheduling cost, with canonical replay held unchanged?',variants=['baseline','root-canonical'],calls=32,roots=['activeS4','generated1091'],fixed_depths=[2,3,4],fixed_seconds=64,delivery=16,maxdepth=12,nodes=1000000,q=0,tt_MiB=1,exact_root=True,scope='Two private sameABI binaries instrument only replaynodes. Rootcanonical mode additionally defers intermediate nonrootnormal canonicalreplay until the completedrootselectedbranch canonicalpass, retainingallroot tie fullrefinements. Originalreturnedscore ignores intermediate replayvalue. SortedcanonicalAB fullcoverage, originalTT/horizon/history. Rootboundtie preserved. No claim fromnodecountalone.32freshcalls, reverseorders, frozen Material leaf/no orderingcheckpoint. Fixedcap incompletion remains unknown; no capraise/default/UI/API/q4. Productsource/binary untouched. Finite depth4 may hitcap and no rescue. Approxworst <15min, no extraagents.'))
modules={}
for name in ['baseline','root-canonical']:
 spec=importlib.util.spec_from_file_location('variant_'+name+'._native_core',ROOT/'.local_agent/narrow-q0-20261012'/name/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX')));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);modules[name]=mod
inputs=json.loads((ROOT/'.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes());rows=[]
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)
for name,inp in inputs.items():
 c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(inp['rules'])));d=inp['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));witnesses=tuple(position(x) for x in inp['witnesses']);s=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));assert record_value(state)==d
 for depth in [2,3,4,12]:
  for repeat,arms in enumerate([['baseline','root-canonical'],['root-canonical','baseline']]):
   for arm in arms:
    native._MODULE=modules[arm];provider=NativeSemanticLegalityProvider.try_create(c,strict=True);engine=SemanticSearchEngine(c,provider.native_rules,board_values=inp['board'],hand_values=inp['hand'],dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1);rawrows=[];old=modules[arm].semantic_engine_search
    def counted(*args):
     r=old(*args);rawrows.append(dict(r));return r
    modules[arm].semantic_engine_search=counted;saved=record_value(state);t=time.perf_counter()
    try:r=engine.search(s,SearchLimits(max_depth=depth,max_nodes=1000000,max_time_seconds=16 if depth==12 else 64,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True)
    finally:modules[arm].semantic_engine_search=old
    elapsed=time.perf_counter()-t;assert record_value(state)==saved;ss=state
    for a in r.principal_variation:assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
    raw=rawrows[0];rows.append(dict(root=name,depth=depth,order=repeat,arm=arm,seconds=elapsed,result=record_value(r),replay_nodes=raw['replay_nodes'],normal_nodes=raw['nodes']-raw['replay_nodes'],tie_refinements=raw['root_tie_refinements'],tie_aborts=raw['root_tie_aborts'],pv_legal=True,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(name,depth,repeat,arm,round(elapsed,3),r.completed_depth,r.score,r.nodes,raw['replay_nodes'],flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows))
