import json,sys,hashlib
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess.core.actions import action_from_dict
from generic_chess.core.coordinates import Square
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.research_record import record_value,write_record
p=ROOT/'.local_agent/root-transmit-20261012';data=json.loads((p/'result.json').read_bytes());c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));core=CoreBoard(next(x for x in CASES if x['id']=='shogi-drop'),c)
def action(a):
 a=dict(a)
 for key in ('from_square','to_square'):
  if key in a:a[key]=Square(**a[key])
 return SemanticBoardMove(**a) if 'from_square' in a else SemanticDropMove(**a)
count=0
for r in data['rows']:
 pvs=[r['result']['principal_variation']] if r['method']=='public' else [b['pv'] for b in r['result']['branches']]
 for pv in pvs:
  state=core.initial
  for a in pv:
   a=action(a);assert a in legal_actions(state,c);state=apply_action(state,a,c);count+=1
 assert r['root_restored'];assert r['inclusion_counts']['exact_parent_visits']==1
 if r['arm']=='plus_one':assert r['inclusion_counts']['target_action_included']==1
public=[r for r in data['rows'] if r['method']=='public'];assert all(r['complete'] and r['result']['completed_depth']==2 and r['result']['score']==900 for r in public);assert public[0]['result']['action']==public[1]['result']['action'] and public[0]['result']['principal_variation']==public[1]['result']['principal_variation']
exact=[r for r in data['rows'] if r['method']=='exact'];assert all(not r['complete'] and r['reason']=='node_limit' and r['result']['legal_root_actions']==163 and r['result']['finished_root_actions']==21 and r['result']['root_value'] is None and r['result']['optimal_actions'] is None for r in exact)
assert all(r['result']['branches'][0]['score']==700 and r['result']['branches'][0]['label']=='legacy_006:g11:e1-d1' for r in exact)
assert exact[0]['result']['branches']==exact[2]['result']['branches'] and exact[1]['result']['branches']==exact[3]['result']['branches']
write_record(p/'verification.json',dict(public_complete_same_value_action_PV=True,partial_whole_root_calls=4,completed_branch_prefix_per_call=21,total_root_actions=163,independent_PV_actions=count,affected_king_branch_values=[r['result']['branches'][0]['score'] for r in exact],reply_change=[r['result']['branches'][0]['pv'][1] for r in exact],scope='Whole argmax member sets remain unenumerated due fixed8192cap. Public completed root result900 unchanged. Complete affected fullwindow branch700 unchanged; its minimizing reply changes. Exact fullhistory predicate confines intervention to this firstking action; local parent900 can be avoided by the opponent, and remains strictlybelow selected root900. No rootdecision gain demonstrated.',correction='Checkpoint said161rootactions; actual frozen results163. No overwritten raw results.',source_sha256=hashlib.sha256((ROOT/'.local_agent/root-transmit-20261012.py').read_bytes()).hexdigest()))
print('verified',count,'PV actions; four incomplete sets remain unknown; affected completedbranch700')
