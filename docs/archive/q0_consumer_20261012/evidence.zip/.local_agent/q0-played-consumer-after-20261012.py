"""Six actual played turns: fresh/reused/warm q0 consumer and measured caller phases."""
import sys,json,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from generic_chess import compile_ruleset_for_execution,build_builtin_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.core.position import GameState,HistoryRecord,Hands,Position
from generic_chess.core.pieces import Piece
from generic_chess.core.terminal import TerminalResult,TerminalStatus
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.native import semantic_engine as se,semantic as ns
from generic_chess.native import _module
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from scripts.search_backend_comparison import CoreBoard,CASES,VALUES
from scripts.research_record import record_value,write_record
out=ROOT/'.local_agent/q0-played-consumer-after-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='After the actual canonical-replay source repair, does six-turn q0 contract still preserve fresh/reuse/warm decisions and what residual caller cost remains?',roots=['generated1091','shogi-middle'],turns=6,arms=['fresh','reuse','warm_same_root'],calls=36,depth=3,nodes=1000000,seconds=16,q=0,tt_MiB=1,exact_root=True,scope='Actual playedtrajectory chosen by reuse arm after canonicalfresh parity. At each turn all3arms same fullhistory/rules/frozenleaf. Alternating fresh/reuse order; warm same-root separate from cross-turnTT. Ordinary concurrent load; phased timing instrument changes caller only, no claims fromnanosecondnoise. Stop ifterminal/noACTION; no newq4/default/UI/API, no strictgain fromchosenmove.' ))
inputs=json.loads((ROOT/'.local_agent/q0-consumer-resumed-20261012/inputs.json').read_bytes())['generated1091']
def position(d):
 d=dict(d);d['board']=tuple(Piece(**p) if p else None for p in d['board']);d['hands']=tuple(Hands(tuple(tuple(x) for x in h['counts'])) for h in d['hands']);d['aux_state']=tuple((tuple(k),tuple(v) if isinstance(v,list) else v) for k,v in d['aux_state']);return Position(**d)
roots={};c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(inputs['rules'])));d=inputs['state'];state=GameState(position(d['position']),d['ply_count'],tuple(tuple(x) for x in d['repetition_counts']),TerminalResult(TerminalStatus(d['terminal_status']['status']),**{k:v for k,v in d['terminal_status'].items() if k!='status'}),tuple(HistoryRecord(**h) for h in d['history']));roots['generated1091']=(c,state,tuple(position(x) for x in inputs['witnesses']),inputs['board'],inputs['hand']);c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));core=CoreBoard(next(x for x in CASES if x['id']=='shogi-middle'),c);roots['shogi-middle']=(c,core.initial,core.witnesses,VALUES['shogi'],VALUES['shogi']);rows=[];paths={}
for name,(c,state,witnesses,bv,hv) in roots.items():
 provider=NativeSemanticLegalityProvider.try_create(c,strict=True);t=time.perf_counter();persistent=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1);setup=time.perf_counter()-t;paths[name]=dict(initial=record_value(state),initial_witnesses=record_value(witnesses),setup_seconds=setup,turns=[])
 for turn in range(6):
  if state.terminal_status.is_terminal:paths[name]['early_terminal']=record_value(state.terminal_status);break
  s=SimpleNamespace(compiled=c,state=state,_search_witnesses=witnesses,result=SimpleNamespace(status=SimpleNamespace(value='ongoing')));results={};saved=record_value(state)
  for arm in (['fresh','reuse','warm_same_root'] if turn%2==0 else ['reuse','fresh','warm_same_root']):
   t=time.perf_counter();engine=SemanticSearchEngine(c,provider.native_rules,board_values=bv,hand_values=hv,dynamic_values=(0,0,0),evaluator_scale=1,tt_megabytes=1) if arm=='fresh' else persistent;constructor=time.perf_counter()-t;phase={};before=engine.tt_info();oldpack=se.pack_semantic_search_position;oldapply=se.apply_action;oldfeatures=ns.dynamic_features;mod=_module();oldsearch=mod.semantic_engine_search
   def timed(label,fn):
    def call(*a,**kw):
     t=time.perf_counter()
     try:return fn(*a,**kw)
     finally:phase[label]=phase.get(label,0)+time.perf_counter()-t
    return call
   se.pack_semantic_search_position=timed('pack',oldpack);se.apply_action=timed('Core_PV_validation',oldapply);ns.dynamic_features=timed('returned_features',oldfeatures);mod.semantic_engine_search=timed('kernel_call',oldsearch);t=time.perf_counter()
   try:r=engine.search(s,SearchLimits(max_depth=3,max_nodes=1000000,max_time_seconds=16,quiescence_max_depth=0,quiescence_hard_max_depth=0),root_window_pruning=True)
   finally:se.pack_semantic_search_position=oldpack;se.apply_action=oldapply;ns.dynamic_features=oldfeatures;mod.semantic_engine_search=oldsearch
   elapsed=time.perf_counter()-t;assert record_value(state)==saved;assert r.completed_depth==3;ss=state
   for a in r.principal_variation:assert a in legal_actions(ss,c);ss=apply_action(ss,a,c)
   assert r.action in legal_actions(state,c);results[arm]=r;rows.append(dict(root=name,turn=turn,arm=arm,history_length=len(state.history),constructor_seconds=constructor,caller_seconds=elapsed,phase=phase,result=record_value(r),tt_before=before,tt_after=engine.tt_info(),root_restored=True,pv_legal=True));write_record(out/'result.json',dict(complete=False,rows=rows,paths=paths));print(name,turn,arm,round(elapsed,4),r.score,r.nodes,r.tt_hits,r.tt_cutoffs,flush=True)
  a=results['reuse'];assert all((r.score,r.action,r.principal_variation)==(a.score,a.action,a.principal_variation) for r in results.values());new=apply_action(state,a.action,c);paths[name]['turns'].append(dict(before=record_value(state),action=record_value(a.action),after=record_value(new),same_fresh_reuse_warm=True));state=new;witnesses=tuple(witnesses)+(state.position,)
write_record(out/'result.json',dict(complete=True,rows=rows,paths=paths))
