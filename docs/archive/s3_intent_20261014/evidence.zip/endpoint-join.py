from pathlib import Path
import sys,time,random,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core import semantic_executor as se
D=Path('.local_agent/s3-intent-20261014')
write_record(D/'endpoint-join-declaration.json',dict(question='Does changing the existing static sourcegroup join to current board actor enumeration save actual scalar cost without a newrule/position cache?',seed=2026101994,size=24,prefix=8,rng_offset=19000,states=4,owners=[0,1],callback_modes=['none','monotonic'],repeats=100,orders=2,search_calls=0,scope='Existing endpoint metadata209112rows, not absent metadata. Pure query-local scan, original binding/path/guards/order; malformed shape completeoriginalfallback. Finite prototype only, not fullsearch/error/cancel qualification.'))
g=p.generate_game(p.GeneratorConfig(seed=2026101994,board_size=24,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(2026101994+19000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
assert c._incoming_attack_paths is None and c._incoming_attack_endpoints is not None
def query(e,pos,square,owner,checkpoint=None):
 e._ensure_match(pos)
 if len(pos.board)!=e.support.board_shape.area:return e.is_square_attacked(pos,square,owner,checkpoint)
 se._checkpoint(checkpoint)
 key=str(owner);groups=e.semantic._incoming_attack_endpoints.get((key,square),{});selected=[]
 for source,piece in enumerate(pos.board):
  if piece is None or piece.owner!=owner:continue
  typed=groups.get(source)
  if typed is None:continue
  se._checkpoint(checkpoint)
  selected.extend((rank,pattern,source,piece.current_type_id,gid,end) for rank,pattern,gid,end in typed.get(piece.current_type_id,()))
 selected.sort(key=lambda x:x[0])
 for rank,pattern,source,tid,gid,end in selected:
  se._checkpoint(checkpoint);piece=pos.board[source];geom=e.ir.geometry[gid]
  path=() if geom.kind=='leap' else tuple(geom.paths[key][source][:end])
  b=e._make_binding(pattern,gid,tid,piece,source,square,None,path,pos)
  if e._path_holds(pattern.path,pos,b,owner,checkpoint=checkpoint) and e._guards_hold(pattern,pos,b,owner,checkpoint=checkpoint):return True
 return False
rows=[]
for state_no in range(4):
 p.rr.stopped();pos=s.state.position;e=se.SemanticEngine(c)
 for owner in [0,1]:
  target=se._own_anchor(pos,e.support,1-owner)
  expected=e.is_square_attacked(pos,target,owner)
  assert query(e,pos,target,owner)==expected
  trials=[]
  for callback_mode in ['none','monotonic']:
   checkpoint=None if callback_mode=='none' else time.monotonic
   for rep in range(2):
    for arm in (['sourcegroup','board_join'] if rep==0 else ['board_join','sourcegroup']):
     t=time.perf_counter()
     for _ in range(100):
      actual=e.is_square_attacked(pos,target,owner,checkpoint) if arm=='sourcegroup' else query(e,pos,target,owner,checkpoint)
      assert actual==expected
     trials.append(dict(callback=callback_mode,rep=rep,arm=arm,seconds=time.perf_counter()-t))
  rows.append(dict(state_no=state_no,owner=owner,target=target,existing_sourcegroups=len(c._incoming_attack_endpoints.get((str(owner),target),{})),actual_enemy_actors=sum(piece is not None and piece.owner==owner for piece in pos.board),value_equal=True,trials=trials))
 if state_no<3:s.submit(sorted(s.legal_actions(),key=repr)[0])
write_record(D/'endpoint-join-rows.json',dict(complete=True,rows=rows,search_calls=0,scope='Existing metadata transient boardjoin, all scalar values agree on8anchor queries/4playedstates. Callcount arithmetic notdirectmeasured; no speedfactor/fullquery/cancel/error/domain proof or production adoption.'))
print('endpointjoin',len(rows))
