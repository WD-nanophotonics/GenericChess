from pathlib import Path
import sys,random,time,cProfile,pstats,json,hashlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from contextlib import nullcontext
import before as baseline
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/s3-intent-20261014');out=D/'profile-2';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does actual supported full-frontier intent restrict setup to exhausted consumers and remove the measured broad setup cost? Attribute same original1962 fixed4096 caller.',seed=2026101962,size=20,prefix=8,rng_offset=16000,q=0,maxdepth=6,maxnodes=4096,seconds_ceiling=64,orders=2,planned_calls=4,fuse=400,expected_minutes=1,scope='cProfile perturbs wallcost, not speed evidence; compare exact public non-time/work and record actual callers/functions. Original counterbalanced, no new backend/labels.',candidate_private_sha=hashlib.sha256((D/'before.py').read_bytes()).hexdigest()))
g=p.generate_game(p.GeneratorConfig(seed=2026101962,board_size=20,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(2026101962+16000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec);before=s.to_record();rows=[];start=time.perf_counter()
for rep in range(2):
 for arm in (['original','candidate'] if rep==0 else ['candidate','original']):
  p.rr.stopped();assert time.perf_counter()-start<400
  player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);prof=cProfile.Profile()
  t=time.perf_counter()
  with baseline.before() if arm=='original' else nullcontext():
   prof.enable();d=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=4096,max_time_seconds=64,quiescence_max_depth=0,quiescence_hard_max_depth=8));prof.disable();stats={}
  wall=time.perf_counter()-t;assert before==s.to_record()
  prof.dump_stats(str(out/f'{arm}-{rep}-private.pstats'))
  functions=[]
  for (filename,line,name),(cc,nc,tt,ct,callers) in pstats.Stats(prof).stats.items():
   if any(x in filename for x in ['semantic_executor','search_runtime','alphabeta']) or name in ['sorted','get']:
    functions.append(dict(file=Path(filename).name,line=line,name=name,primitive_calls=cc,total_calls=nc,self_seconds=tt,cumulative_seconds=ct))
  functions.sort(key=lambda row:row['cumulative_seconds'],reverse=True)
  rows.append(dict(rep=rep,arm=arm,decision=record_value(d),profile_wall=wall,private_stats=stats,functions=functions,history_restored=True))
  write_record(out/'rows.json',dict(complete=False,rows=rows));print(arm,rep,wall,d.completed_depth,d.nodes,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start))
