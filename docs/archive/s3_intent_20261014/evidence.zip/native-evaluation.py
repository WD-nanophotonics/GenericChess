from pathlib import Path
import sys,random,time,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/s3-intent-20261014');out=D/'native-evaluation';out.mkdir(exist_ok=True)
assert not (out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Is remaining dynamic attack-map cost reducible with already supported public SemanticAttackEvaluator Native backend on aligned generated legacy rules, rather than a new evaluator/engine?',seeds=[2026101991,2026101992],sizes=[8,12],prefix=8,rng_offset=19000,q=[0,4],orders=2,arms=['legacy_core_evaluator','semantic_native_evaluator'],max_depth=6,max_nodes=4096,seconds_ceiling=32,planned_calls=16,fuse=900,expected_minutes=3,scope='Existing exposed roots from S3plane, not untouchedholdout. Only8/12Native supported,18/24excludedfromthiscomponent notgenerictarget. Sameweights/staticprofiles/history/corelegality; first verify actual maps andscores Coresemantic/Native/legacy through4playedstates. Failure/value mismatch disqualifies purecost interpretation, preserveallerrors, no resample/pricefit/default/UI changes.'))
rows=[];maps=[];unavailable=[];start=time.perf_counter()
for seed,size in zip([2026101991,2026101992],[8,12]):
 p.rr.stopped();assert time.perf_counter()-start<900
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
 c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support)
 s=p.GameSession(c);rng=random.Random(seed+19000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);legacy=p.Evaluator(c,profile,ec)
 try:native=SemanticAttackEvaluator(c,profile,ec,backend='native');core=SemanticAttackEvaluator(c,profile,ec,backend='core')
 except (ValueError,RuntimeError,NotImplementedError) as exc:
  unavailable.append(dict(seed=seed,error_type=type(exc).__name__,error=str(exc),unexecuted=8));continue
 trial=p.GameSession.from_record(s.to_record(),c) if hasattr(p.GameSession,'from_record') else None
 # Keep original complete history session and restore after finite map walk by undo.
 walk=[]
 for ply in range(4):
  m0=legacy._attack_maps(s.state);m1=core._attack_maps(s.state);m2=native._attack_maps(s.state)
  scores=[ev.evaluate(s.state) for ev in [legacy,core,native]]
  assert m0==m1==m2 and scores[0]==scores[1]==scores[2],(seed,ply,scores)
  maps.append(dict(seed=seed,ply=ply,all_maps_scores_equal=True))
  if ply<3:
   a=sorted(s.legal_actions(),key=repr)[0];walk.append(a);s.submit(a)
 for _ in walk:s.undo()
 initial=s.to_record()
 for q in [0,4]:
  for rep in range(2):
   for arm in (['legacy_core_evaluator','semantic_native_evaluator'] if rep==0 else ['semantic_native_evaluator','legacy_core_evaluator']):
    p.rr.stopped();assert time.perf_counter()-start<900
    ev=legacy if arm=='legacy_core_evaluator' else native
    player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
    t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=4096,max_time_seconds=32,quiescence_max_depth=q,quiescence_hard_max_depth=8));wall=time.perf_counter()-t
    assert initial==s.to_record()
    rows.append(dict(seed=seed,size=size,q=q,rep=rep,arm=arm,wall=wall,decision=record_value(d),native_legality_provider=player.native_legality_provider is not None,history_restored=True))
    write_record(out/'rows.json',dict(complete=False,rows=rows,maps=maps,unavailable=unavailable))
    print(seed,q,rep,arm,round(wall,3),d.completed_depth,d.nodes,d.qnodes,d.termination_reason,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,maps=maps,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
