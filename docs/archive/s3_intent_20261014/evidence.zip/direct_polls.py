from pathlib import Path
import sys,inspect,re
from contextlib import contextmanager
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
ORIGINAL=se.SemanticEngine.is_square_attacked
source=inspect.getsource(ORIGINAL)
# Preserve each exact optional callback point and its exception; only omit
# the intervening pure forwarding Python frame. No batching or cached budget.
source=re.sub(r'^(\s*)_checkpoint\(checkpoint\)$',lambda m:m[1]+'if checkpoint is not None:\n'+m[1]+'    checkpoint()',source,flags=re.M)
ns=dict(ORIGINAL.__globals__)
exec(compile('class Private:\n'+source,'private-scalar-direct-polls','exec'),ns)
CANDIDATE=ns['Private'].is_square_attacked
@contextmanager
def installed():
 se.SemanticEngine.is_square_attacked=CANDIDATE
 try:yield
 finally:se.SemanticEngine.is_square_attacked=ORIGINAL
