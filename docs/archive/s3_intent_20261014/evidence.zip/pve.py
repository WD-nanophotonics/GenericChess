from pathlib import Path
import sys,time,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from contextlib import nullcontext
import before as baseline
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
D=Path('.local_agent/s3-intent-20261014')
write_record(D/'pve-declaration.json',dict(seed=2026101965,size=24,prefix=0,q=[0,4],moves_each=2,arms=['original','candidate'],max_depth=2,max_nodes=256,max_time_seconds=16,planned_calls=8,fuse=200,expected_minutes=1,question='Does supported full-frontier binding reuse preserve actual public PVE choice/submission on complete Core metadata-absent generated rules?',scope='Known exposed24root; actual public player plus GameSession submit; no Native expansion, strength or UI code claim.'))
g=p.generate_game(p.GeneratorConfig(seed=2026101965,board_size=24,setup_preset='bilateral_random',allow_hybrid=True))
c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support)
assert c._incoming_attack_paths is None and c._incoming_attack_endpoints is None
ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
rows=[];start=time.perf_counter()
for q in [0,4]:
 for arm in ['original','candidate']:
  s=p.GameSession(c)
  for turn in range(2):
   p.rr.stopped();assert time.perf_counter()-start<200
   before=s.to_record()
   player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
   with baseline.before() if arm=='original' else nullcontext():
    d=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=256,max_time_seconds=16,quiescence_max_depth=q,quiescence_hard_max_depth=8))
    assert s.to_record()==before and d.action in s.legal_actions()
    s.submit(d.action)
   rows.append(dict(q=q,arm=arm,turn=turn,decision=record_value(d),actual_provider=player.native_legality_provider is not None,submitted=True,history_restored_before_submission=True,after=record_value(s.state)))
   print(q,arm,turn,d.completed_depth,d.termination_reason,flush=True)
write_record(D/'pve-rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start,actual_calls=len(rows)))
