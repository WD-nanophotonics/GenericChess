from pathlib import Path
import sys,inspect
from contextlib import contextmanager
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.core import attacks
from generic_chess.ai.evaluation import evaluator
ORIGINAL=attacks.pseudo_attacks
source=inspect.getsource(ORIGINAL)
source=source.replace("    attacked: set[Square] = set()","    canonical_shape = type(n) is int and n > 0 and len(position.board) == n * n\n    attacked: set[Square] = set()")
source=source.replace("        square = index_to_square(idx, n)","        if not canonical_shape:\n            index_to_square(idx, n)")
ns=dict(ORIGINAL.__globals__);exec(compile(source,'private-unused-source-coordinate','exec'),ns);CANDIDATE=ns['pseudo_attacks']
@contextmanager
def installed():
 attacks.pseudo_attacks=CANDIDATE;evaluator.pseudo_attacks=CANDIDATE
 try:yield
 finally:attacks.pseudo_attacks=ORIGINAL;evaluator.pseudo_attacks=ORIGINAL
