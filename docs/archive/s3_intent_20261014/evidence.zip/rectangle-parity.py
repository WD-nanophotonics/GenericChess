from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));sys.path.insert(0,str(ROOT/'tests/product'))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core import semantic_executor as se
from generic_chess.session.session import GameSession
from test_rectangular_public_semantic_execution import _public_9x10_facing_generals_ruleset,_toy_horse_leg_ruleset
from scripts.research_record import write_record
D=Path('.local_agent/s3-intent-20261014');rows=[]
defs=[('facing',_public_9x10_facing_generals_ruleset())]+[(f'horse-{owner}',_toy_horse_leg_ruleset(blocked_owner=owner)) for owner in [None,0,1]]
for name,definition in defs:
 c=compile_ruleset_for_execution(definition);s=GameSession(c);e=se.SemanticEngine(c)
 assert len(s.state.position.board)==90
 for ply in range(4):
  pos=s.state.position;before=tuple(e.iter_legal_action_bindings(pos));after=tuple(e.iter_legal_action_bindings(pos,full_frontier=True))
  assert before==after
  assert [e._transition(pos,a,b) for a,b in before]==[e._transition(pos,a,b) for a,b in after]
  rows.append(dict(fixture=name,ply=ply,shape=[9,10],eligible=e._capture_reads_local_board(),actions=len(before),complete_order_and_child_equal=True))
  if not before or s.state.terminal_status.is_terminal:break
  s.submit(sorted(s.legal_actions(),key=repr)[0])
write_record(D/'rectangle-parity.json',dict(complete=True,rows=rows,search_calls=0,scope='4actual executable9x10DSL fixtures including facing capture zone guards and quiet horse-leg guard, through4plies. No Xiangqi human-reference/holdout, completegame or Native support claim.'))
print(len(rows),[(r['fixture'],r['eligible'],r['actions']) for r in rows if r['ply']==0])
