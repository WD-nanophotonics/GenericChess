from pathlib import Path
import sys,time,random,statistics,json
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from generic_chess.core import semantic_executor as se
from generic_chess.rules.ir import geometry_paths_to
D=Path('.local_agent/s3-intent-20261014')
write_record(D/'target-schedule-declaration.json',dict(question='Can a purely rule-derived per-target source schedule remove actual24Core scalar dispatch cost without caching positions/check truth?',seed=2026101994,size=24,prefix=8,rng_offset=19000,states=4,owners=[0,1],repeats=100,orders=2,max_rows_per_target=8000,search_calls=0,scope='Build only actualqueriedanchor targets from complete immutableIR; all original guards/binding/Piece/path order retained. Not integrated cache/metadata or fullsearch qualification. Coldconstruction and warmcost distinct; no post-result budgetextension.'))
g=p.generate_game(p.GeneratorConfig(seed=2026101994,board_size=24,setup_preset='bilateral_random',allow_hybrid=True));c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support);s=p.GameSession(c);rng=random.Random(2026101994+19000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
assert c._incoming_attack_paths is None and c._incoming_attack_endpoints is None
def build(engine,owner,target):
 grouped={};rank=0
 for pattern in engine._patterns:
  if pattern.target.kind!='target_enemy':continue
  for tid in pattern.type_ids:
   for source in range(len(s.state.position.board)):
    for gid in pattern.geometry_ids:
     geometry=engine.ir.geometry.get(gid)
     if geometry is None or geometry.kind=='drop' or geometry.atom_source is not None and geometry.atom_source[0]!=tid:continue
     for path in geometry_paths_to(geometry,str(owner),source,target):
      if rank>=8000:return None,rank
      grouped.setdefault(source,{}).setdefault(tid,[]).append((rank,pattern,tid,source,gid,path));rank+=1
 return grouped,rank
def query(engine,position,target,owner,schedule,checkpoint=None):
 engine._ensure_match(position);selected=[]
 for source,typed in schedule.items():
  se._checkpoint(checkpoint);piece=position.board[source]
  if piece is not None and piece.owner==owner:selected.extend(typed.get(piece.current_type_id,()))
 selected.sort(key=lambda x:x[0])
 for rank,pattern,tid,source,gid,path in selected:
  se._checkpoint(checkpoint);piece=position.board[source]
  binding=engine._make_binding(pattern,gid,tid,piece,source,target,None,path,position)
  if engine._path_holds(pattern.path,position,binding,owner,checkpoint=checkpoint) and engine._guards_hold(pattern,position,binding,owner,checkpoint=checkpoint):return True
 return False
rows=[]
for state_no in range(4):
 pos=s.state.position;e=se.SemanticEngine(c)
 for owner in [0,1]:
  target=se._own_anchor(pos,e.support,1-owner)
  t=time.perf_counter();schedule,entry_count=build(e,owner,target);cold=time.perf_counter()-t
  assert schedule is not None
  expected=e.is_square_attacked(pos,target,owner);assert query(e,pos,target,owner,schedule)==expected
  trials=[]
  for rep in range(2):
   for arm in (['source','target_schedule'] if rep==0 else ['target_schedule','source']):
    t=time.perf_counter()
    for _ in range(100):
     actual=e.is_square_attacked(pos,target,owner) if arm=='source' else query(e,pos,target,owner,schedule)
     assert actual==expected
    trials.append(dict(rep=rep,arm=arm,seconds=time.perf_counter()-t))
  rows.append(dict(state_no=state_no,owner=owner,target=target,rows=entry_count,source_groups=len(schedule),cold_seconds=cold,actual_value_equal=True,trials=trials))
 if state_no<3:s.submit(sorted(s.legal_actions(),key=repr)[0])
write_record(D/'target-schedule-rows.json',dict(complete=True,rows=rows,actual_search_calls=0,actual_scalar_queries=8*401,scope='One exposed24ruleset/4actual states/8anchor targets; rule-only prototype, no persistentstate/score/checkcache. No fullsearch/cancellation/guarderror/resource/production qualification.'))
print(json.dumps(rows))
