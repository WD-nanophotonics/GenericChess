from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));sys.path.insert(0,str(ROOT/'tests/product'))
from dataclasses import replace
from generic_chess.core import semantic_executor as se
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from test_compiled_endpoint_fallback import DEFINITIONS
from scripts.research_record import write_record
D=Path('.local_agent/s3-intent-20261014')
rows=[];transitions=0;changed_cells=0;start=time.perf_counter()
for no,definition in enumerate(DEFINITIONS):
 original=compile_ruleset_for_execution(definition)
 for mode in ['installed','complete_source_fallback']:
  c=original if mode=='installed' else replace(original)
  if mode!='installed':
   for field in ['_incoming_attack_paths','_incoming_attack_sources','_incoming_attack_endpoints']:
    object.__setattr__(c,field,None)
  s=GameSession(c);e=se.SemanticEngine(c)
  for ply in range(4):
   pos=s.state.position
   before=tuple(e.iter_legal_action_bindings(pos))
   after=tuple(e.iter_legal_action_bindings(pos,full_frontier=True))
   assert before==after
   ctx=e._own_anchor_safety(pos,se._sources_by_owner_type(pos),None) if e._capture_reads_local_board() else None
   skipped=0;fallback=0
   for p in e._patterns:
    for a,b in e._iter_candidates(p,pos):
     written=set()
     try:child=e._transition(pos,a,b,written_squares=written)
     except RuntimeError:continue
     assert child==e._transition(pos,a,b)
     changed={i for i,(x,y) in enumerate(zip(pos.board,child.board)) if x!=y}
     assert changed<=written
     transitions+=1;changed_cells+=len(changed)
     old=e._trial_child_if_s3_legal(p,pos,a,b)
     new=e._trial_child_if_s3_legal(p,pos,a,b,safety=ctx)
     assert old==new
     if ctx is not None:
      if ctx.unchanged(child,written,e.support):
       assert ctx.checked==e.in_check(child,pos.side_to_move);skipped+=1
      else:fallback+=1
   rows.append(dict(fixture=no,mode=mode,ply=ply,actions=len(before),eligible=e._capture_reads_local_board(),reusable_child_checks=skipped,required_child_checks=fallback,ordered_S4_and_child_equal=True))
   if not before or s.state.terminal_status.is_terminal:break
   s.submit(sorted(s.legal_actions(),key=repr)[0])
write_record(D/'complete-route-audit.json',dict(complete=True,rows=rows,actual_transitions=transitions,actual_changed_cells=changed_cells,search_calls=0,elapsed_seconds=time.perf_counter()-start,scope='12actual grammar fixtures through4plies both installed metadata and complete source fallback; includes illegal candidates in actual write/child checks. Optional safety scoped guard-free, all original invariants/S4 retained. No claimed complete domain proof.'))
print(len(rows),transitions,changed_cells,time.perf_counter()-start)
