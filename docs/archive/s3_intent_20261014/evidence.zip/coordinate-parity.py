from pathlib import Path
import sys,json,random
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));sys.path.insert(0,str(ROOT/'tests/product'))
from dataclasses import replace
from generic_chess.rules.compiler import compile_ruleset_for_execution
import unused_coordinate as candidate
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record
from test_compiled_endpoint_fallback import DEFINITIONS
D=Path('.local_agent/s3-intent-20261014')
rows=[]
for fixture,definition in enumerate(DEFINITIONS):
 original=compile_ruleset_for_execution(definition)
 c=p.SearchMetadataAdapter(ir=original.ir,_legacy_compiled=original._legacy_compiled,support=original.support)
 s=p.GameSession(c);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
 for ply in range(4):
  pos=s.state.position;maps=tuple(candidate.ORIGINAL(pos,side,c) for side in (0,1));score=ev.evaluate(s.state)
  with candidate.installed():
   assert tuple(candidate.CANDIDATE(pos,side,c) for side in (0,1))==maps
   assert ev.evaluate(s.state)==score
  rows.append(dict(fixture=fixture,ply=ply,all_owner_maps_and_actual_score_equal=True))
  if s.state.terminal_status.is_terminal:break
  acts=sorted(s.legal_actions(),key=repr)
  if not acts:break
  s.submit(acts[0])
write_record(D/'coordinate-parity.json',dict(complete=True,rows=rows,searches=0,scope='Unchanged legacy geometry evaluator only; no semantic attack authority or weight substitution. All12fixturemaps plus actual configured scores; includes guardedrules but evaluates same declared legacy authority. Noncanonical shape retains originalindex call.'))
print(len(rows))
