from pathlib import Path
import sys,importlib.util
from contextlib import contextmanager
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as se
from generic_chess.core.search_runtime import SearchPathRuntime
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path)
 m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
D=Path(__file__).parent
OLD=load('generic_chess.core._s3_before_executor',D/'semantic_executor.py')
OLDR=load('generic_chess.core._s3_before_runtime',D/'search_runtime.py')
CURRENT=se.SemanticEngine
METHOD=SearchPathRuntime.legal_actions
@contextmanager
def before():
 se.SemanticEngine=OLD.SemanticEngine
 SearchPathRuntime.legal_actions=OLDR.SearchPathRuntime.legal_actions
 try:yield
 finally:
  se.SemanticEngine=CURRENT;SearchPathRuntime.legal_actions=METHOD
