"""Retain all declared caller rows; warm, cold and reuse costs stay separate."""
import json,math
from pathlib import Path
B=Path(__file__).parent
v=json.loads((B/'compiled-effect-shared-control.json').read_text(encoding='utf-8'));assert v['complete']
setup={r['root']:r['seconds'] for r in v['setup']};rows=[]
for kind in ('fixed','completed'):
 for root in sorted({r['root'] for r in v[kind]}):
  records=[r for r in v[kind] if r['root']==root]
  pairs=[]
  for repeat in sorted({r['repeat'] for r in records}):
   pair={r['candidate']:r for r in records if r['repeat']==repeat};a=pair[False]['wall'];c=pair[True]['wall'];pairs.append(dict(repeat=repeat,baseline=a,candidate=c,warm_ratio=c/a,candidate_one_call_cold=c+setup[root],one_call_cold_ratio=(c+setup[root])/a))
  baseline=sum(r['baseline'] for r in pairs);candidate=sum(r['candidate'] for r in pairs);saving=(baseline-candidate)/len(pairs)
  rows.append(dict(condition=kind,root=root,pairs=pairs,setup_seconds=setup[root],warm_aggregate_ratio=candidate/baseline,candidate_reuse_batch_with_one_setup_ratio=(candidate+setup[root])/baseline,estimated_calls_to_amortize=math.ceil(setup[root]/saving) if saving>0 else None))
slot=json.loads((B/'shared-template-slot.json').read_text(encoding='utf-8'));assert slot['exit']==0 and slot['within_slot']
out=dict(rows=rows,slot_seconds=slot['seconds'],setup_scope='Separate original rules compilation outside both caller timers; prototype prepare timed separately. Cold hypothetical one-call adds prototype setup. Reuse batch charges it once, not zero. Break-even is descriptive arithmetic from this finite mean, not independent guarantee or forecast.',decision='PENDING_REVIEW actual caller/setup rows under the original declaration. No result-driven repeats; shared shape template is a new premise requiring a new declaration.',unchanged='Product semantic executor/backend/q/evaluation/UI defaults; totalcost includes engineering/token overhead without an exported exact token count.')
(B/'shared-template-cost-analysis.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print([(r['condition'],r['root'],round(r['warm_aggregate_ratio'],3),round(r['candidate_reuse_batch_with_one_setup_ratio'],3),r['estimated_calls_to_amortize']) for r in rows])
