"""Scoped broader-domain Unit/static work curve, reusing the existing complete-session runner."""
from pathlib import Path
import sys,json,time,random,hashlib,traceback,subprocess
from dataclasses import asdict
from collections import Counter
ROOT=Path.cwd();D=ROOT/'.local_agent/root-window-wall-20261018';START=time.monotonic();sys.path.insert(0,str(ROOT))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
P=json.loads((D/'plan.json').read_bytes());compiled={};native={};models={};roots={};rules={};games=[];counts=Counter();status='COMPLETE';reason=current=None
assert not(D/'producer-source.json').exists()and not(D/'games.jsonl').exists()
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 if time.monotonic()-START>=P['limits']['global_cap_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for name in ['rollout','advisor','slack']:
  q=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if q.get('stopped')or q.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')
def reward(s,owner):
 if s.result.status.value=='ongoing':return None
 return 0 if s.result.winner is None else 1 if s.result.winner==owner else-1
profiles=[model+'@'+budget for model in P['candidate_models']for budget in P['budgets']]
slots=[(seed*100+size,fam,label,owner,foe_model,mode)for seed in P['seeds']for size in P['board_sizes']for fam in P['families']for label in profiles for owner in P['candidate_owners']for foe_model in P['foe_models']for mode in P['window_modes']];assert len(slots)==P['planned_physical'];random.Random(P['random_order_seed']).shuffle(slots)
write_json(D/'slots.json',dict(slots=slots));write_json(D/'producer-source.json',dict(producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),base_sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),scope='New rule-static SAMEcheckpoint exact-root-window utilitycomparison onnew6/8rules; no old fitness or AUX training.'))
try:
 with(D/'generation.jsonl').open('x',encoding='utf8')as genlog:
  for seed in P['seeds']:
   for size in P['board_sizes']:
    poll();tick=time.perf_counter();gs=seed*100+size;cfg=GeneratorConfig(seed=seed,board_size=size,setup_preset='classic_like'if seed%2 else'free_random',movement_symmetry='bilateral'if(seed//2)%2 else'none',allow_hybrid=True,max_generation_attempts=P['max_generation_attempts'],require_no_opening_win_in_one=False);row=dict(rule=gs,seed=seed,size=size,config=asdict(cfg));rules[gs]=row
    try:g=generate_game(cfg)
    except GenerationError as exc:
     row.update(status='GENERATION_REFUSAL',error=str(exc),generation_seconds=time.perf_counter()-tick);genlog.write(json.dumps(row,separators=(',',':'))+'\n');genlog.flush();counts['generation_refusals']+=1;continue
    row['generation_seconds']=time.perf_counter()-tick;tick=time.perf_counter();c=compile_legacy_ruleset_for_semantic_execution(g.ruleset);compiled[gs]=c;row.update(rules=ruleset_to_dict(g.ruleset),fingerprint=c.ruleset_fingerprint,types=sorted(c.types_by_id),compile_seconds=time.perf_counter()-tick);tick=time.perf_counter();profile=build_ruleset_profile(c,EvaluationConfig());assert set(profile.board_value_by_type)==set(profile.hand_value_by_base_type)==set(c.types_by_id);anchors={t.type_id for t in c.piece_types if t.is_anchor}
    for label in P['model_inputs']:
     board={t:0. if t in anchors else 1. if label=='unit'else profile.board_value_by_type[t]/1000 for t in c.types_by_id};hand={t:0. if t in anchors else 1. if label=='unit'else profile.hand_value_by_base_type[t]/1000 for t in c.types_by_id};models[gs,label]=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='full-type-'+label,board_weights=board,hand_weights=hand,material_scale=256,value_scale=10.,reference_median=1.)
    row['profile_seconds']=time.perf_counter()-tick;tick=time.perf_counter()
    try:native[gs]=compile_native_semantic_rules(c);row.update(status='SUPPORTED')
    except NativeUnsupportedRuleError as exc:row.update(status='NATIVE_REFUSAL',error=str(exc));counts['native_refusals']+=1
    row['native_compile_seconds']=time.perf_counter()-tick;genlog.write(json.dumps(row,separators=(',',':'))+'\n');genlog.flush();counts['generated_rules']+=1
    for fam in P['families']:
     poll();tick=time.perf_counter();s=GameSession(c);rng=random.Random(gs*1000000+fam)
     for _ in range(P['prefix']):
      if s.result.status.value!='ongoing':break
      aa=sorted(s.legal_actions(),key=repr);assert aa;s.submit(aa[rng.randrange(len(aa))])
     roots[gs,fam]=dict(rule=gs,family=fam,record=json.loads(serialize_game_record(s.to_record())),state_sha256=digest(s.state),witnesses_sha256=digest(s._search_witnesses),prefix_completed=s.state.ply_count,result=record_value(s.result),prefix_seconds=time.perf_counter()-tick)
 write_json(D/'roots.json',dict(rows=list(roots.values()),planned_roots=P['planned_roots'],scope='No replacement/terminal filtering; two prefix families per rule are not independent rules.'));write_json(D/'models.json',dict(rows=[dict(rule=gs,label=label,checkpoint_id=cp.checkpoint_id,checkpoint=cp.to_dict())for(gs,label),cp in models.items()],scope=P['objective']));counts['prepared_roots']=len(roots)
 with(D/'queries.jsonl').open('x',encoding='utf8')as qlog,(D/'games.jsonl').open('x',encoding='utf8')as glog:
  for slot,(gs,fam,label,owner,foe_model,mode)in enumerate(slots):
   poll();game_start=time.perf_counter();row=rules[gs];root=roots.get((gs,fam));current=dict(slot=slot,rule=gs,seed=row['seed'],size=row['size'],family=fam,label=label,candidate_owner=owner,foe=foe_model,window=mode,root_state_sha256=root['state_sha256']if root else None);localnodes=localqueries=0;caller=kernel=0.;ending='HORIZON_UNKNOWN'
   if row['status']!='SUPPORTED':
    current.update(ending=row['status']+'_UNKNOWN',reward=None,queries=0,nodes=0,record=None,result=None,game_seconds=time.perf_counter()-game_start);games.append(current);glog.write(json.dumps(current,separators=(',',':'))+'\n');glog.flush();current=None;continue
   c=compiled[gs];s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));assert digest(s.state)==root['state_sha256']and digest(s._search_witnesses)==root['witnesses_sha256'];candidate=models[gs,label.split('@')[0]];unit=models[gs,foe_model];tick=time.perf_counter();engines={owner:SemanticSearchEngine(c,native[gs],checkpoint=candidate,tt_megabytes=0),1-owner:SemanticSearchEngine(c,native[gs],checkpoint=unit,tt_megabytes=0)};engine_init=time.perf_counter()-tick
   try:
    for relative_ply in range(P['horizon_after_prefix']):
     poll()
     if s.result.status.value!='ongoing':ending='ACTUAL_TERMINAL';break
     if P['limits']['global_cap_seconds']-(time.monotonic()-START)<1.:raise TimeoutError('FROZEN_GLOBAL_CAP_BEFORE_FULL_QUERY')
     before=(s.state,s.to_record(),s.history,s._search_witnesses);beforehash=digest(s.state);side=s.state.position.side_to_move;lim=P['budgets'][label.split('@')[1]]if side==owner else P['foe'];tick=time.perf_counter();r=engines[side].search(s,SearchLimits(max_depth=lim['depth'],max_nodes=lim['nodes'],max_time_seconds=lim['seconds'],quiescence_max_depth=0),root_window_pruning=mode if side==owner else False);assert r.root_window_pruning==(mode if side==owner else False);elapsed=time.perf_counter()-tick;assert before==(s.state,s.to_record(),s.history,s._search_witnesses);localnodes+=r.nodes;localqueries+=1;counts['nodes']+=r.nodes;counts['queries']+=1;caller+=elapsed;kernel+=r.elapsed_seconds;commit=None
     if r.completed_depth<1 or r.used_fallback:ending='SEARCH_LIMIT_UNKNOWN'
     elif r.declaration_id is not None:s.declare(r.declaration_id);commit=r.declaration_id
     elif r.action is None:ending='NO_ACTION_UNKNOWN'
     else:assert r.action in s.legal_actions();s.submit(r.action);commit=record_value(r.action)
     qlog.write(json.dumps(dict(slot=slot,relative_ply=relative_ply,actor=side,checkpoint_id=(candidate if side==owner else unit).checkpoint_id,before_sha256=beforehash,after_sha256=digest(s.state),returned_action=record_value(r.action),committed=commit,declaration_id=r.declaration_id,decision_line=record_value(r.decision_line),requested_depth=lim['depth'],requested_nodes=lim['nodes'],requested_seconds=lim['seconds'],candidate_turn=side==owner,root_window_pruning=mode if side==owner else False,completed_depth=r.completed_depth,selective_depth=r.selective_depth,nodes=r.nodes,qnodes=r.qnodes,used_fallback=r.used_fallback,cause=r.termination_reason,score=r.score,kernel_seconds=r.elapsed_seconds,caller_seconds=elapsed),separators=(',',':'))+'\n');qlog.flush()
     if ending in ['SEARCH_LIMIT_UNKNOWN','NO_ACTION_UNKNOWN']:break
    if s.result.status.value!='ongoing':ending='ACTUAL_TERMINAL'
   except(TimeoutError,InterruptedError)as exc:ending='INTERRUPTED_UNKNOWN';reason=repr(exc);status='INTERRUPTED'
   fresh=GameSession.replay(c,s.to_record());assert(fresh.state,fresh.history,fresh._search_witnesses,fresh.result)==(s.state,s.history,s._search_witnesses,s.result)
   current.update(ending=ending,result=record_value(s.result),reward=reward(s,owner),record=json.loads(serialize_game_record(s.to_record())),final_state_sha256=digest(s.state),final_witnesses_sha256=digest(s._search_witnesses),nodes=localnodes,queries=localqueries,relative_plies=s.state.ply_count-root['prefix_completed'],caller_seconds=caller,kernel_seconds=kernel,engine_init_seconds=engine_init,game_seconds=time.perf_counter()-game_start,full_replay_equal=True);games.append(current);glog.write(json.dumps(current,separators=(',',':'))+'\n');glog.flush();current=None
   if len(games)%8==0:print('CLOSED_GAMES',len(games),'queries',counts['queries'],'seconds',round(time.monotonic()-START,3),flush=True)
   if qlog.tell()+glog.tell()>P['limits']['max_output_bytes']:status='INTERRUPTED';reason='FROZEN_OUTPUT_CAP';break
   if status!='COMPLETE':break
except BaseException as exc:status='INTERRUPTED'if isinstance(exc,(TimeoutError,InterruptedError))else'ERROR';reason=repr(exc);traceback.print_exc()
result=dict(status=status,reason=reason,planned_physical=P['planned_physical'],returned_physical=len(games),unstarted_physical=P['planned_physical']-len(games),counts=dict(counts),actual_terminal=sum(g.get('ending')=='ACTUAL_TERMINAL'for g in games),unknown=sum(g['reward']is None for g in games),seconds=time.monotonic()-START,current_unclosed_slot=current,scope=P['estimand']);write_json(D/'result.json',result);print('CLOSED',json.dumps(result),flush=True)
