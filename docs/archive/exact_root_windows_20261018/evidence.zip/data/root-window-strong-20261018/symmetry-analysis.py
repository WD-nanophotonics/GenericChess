"""Observed symmetric stronger-control role duplicates, not independent trajectories."""
from pathlib import Path
from collections import defaultdict,Counter
import json,sys
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/root-window-strong-20261018';games=list(map(json.loads,(D/'games.jsonl').read_bytes().splitlines()));queries=defaultdict(list);groups=defaultdict(dict);counts=Counter()
for q in map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()):queries[q['slot']].append(q)
for g in games:groups[g['rule'],g['family'],g['window']][g['candidate_owner']]=g
fields=['before_sha256','after_sha256','actor','checkpoint_id','returned_action','committed','declaration_id','decision_line','completed_depth','nodes','qnodes','score','cause','root_window_pruning']
for (gs,fam,mode),arms in groups.items():
 assert set(arms)=={0,1};a,b=arms[0],arms[1];counts['true_role_pairs'if mode else'false_role_pairs']+=1
 same=a['record']==b['record']and a['final_state_sha256']==b['final_state_sha256']
 if mode:
  assert same
  aa=queries[a['slot']];bb=queries[b['slot']];assert len(aa)==len(bb)
  assert all({f:x[f]for f in fields}=={f:y[f]for f in fields}for x,y in zip(aa,bb))
  assert(a['reward']is None and b['reward']is None)or a['reward']==-b['reward']
  counts['identical_true_full_trajectories']+=1;counts['linked_true_query_pairs']+=len(aa)
 else:counts['identical_false_full_trajectories']+=same
write_json(D/'symmetry-analysis.json',dict(status='OBSERVED_TRUE_CONTROL_ROLE_SYMMETRY',counts=dict(counts),scope='Truecandidate versusfixedTruefoe isidenticalstaticprofile/D8/8192/q0TT0 onbothsides. All32observedrolepairs duplicateonefulltrajectory (64actualruns), rewardsopposite orbothUNKNOWN. Actualcosts retained; not64independentnewtrajectories. Maincontrast measuresFalseunderperformance againstTruecontrol, not a positiveTrue-selfplayrawadvantage. UNKNOWNbounds unchanged, nofuturebeyondhorizonproof. No newqueries/games.'))
print('STRONG_SYMMETRY',dict(counts))
