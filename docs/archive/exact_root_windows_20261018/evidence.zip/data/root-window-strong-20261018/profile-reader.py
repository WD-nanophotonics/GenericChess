"""Rebuild prospective full-typed static and Unit inputs, without search."""
from pathlib import Path
import sys,json,time,os
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.learning.material import LearnableMaterialCheckpoint
D=R/'.local_agent/root-window-strong-20261018';rows=json.loads((D/'models.json').read_bytes())['rows'];mods={(r['rule'],r['label']):r for r in rows};start=time.perf_counter();count=rules=0
for gr in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines()):
 for name in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 if 'rules'not in gr:continue
 c=compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(gr['rules']));p=build_ruleset_profile(c,EvaluationConfig());anchors={t.type_id for t in c.piece_types if t.is_anchor};gs=gr['rule'];a=mods[gs,'rule_static_v2']['checkpoint'];u=mods[gs,'unit']['checkpoint']
 for t in c.types_by_id:
  assert a['board_weights'][t]==p.board_value_by_type[t]/1000 and a['hand_weights'][t]==p.hand_value_by_base_type[t]/1000;assert u['board_weights'][t]==u['hand_weights'][t]==(0 if t in anchors else 1);count+=1
 for label in('rule_static_v2','unit'):
  r=mods[gs,label];cp=LearnableMaterialCheckpoint.from_dict(r['checkpoint']);cp.validate_ruleset(c);assert cp.checkpoint_id==r['checkpoint_id']
 rules+=1
write_json(D/'profile-reader-result.json',dict(status='PASS_RULE_ONLY_FULL_TYPED_INPUTS',rules=rules,types=count,checkpoints=len(rows),seconds=time.perf_counter()-start,scope='Rebuildallstatic coefficients/Unit andcheckpointids/fingerprints fromsavedfullrules; bothmodearms shareONEstaticcheckpoint perrule. No generation, Nativequeries, games, training or independentexternalruleauthority.'))
print('ROOT_WINDOW_PROFILE_INPUT_PASS',rules,count,time.perf_counter()-start)
