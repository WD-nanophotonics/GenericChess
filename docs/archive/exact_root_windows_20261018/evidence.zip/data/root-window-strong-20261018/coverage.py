"""Actual saved action/terminal coverage; no claim of all-domain exercise."""
from pathlib import Path
from collections import Counter
import json,sys
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=Path(__file__).resolve().parent
gs=list(map(json.loads,(D/'games.jsonl').read_bytes().splitlines()));qs=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));roots=json.loads((D/'roots.json').read_bytes())['rows'];types=Counter();chosen=Counter();pv=Counter()
def kind(a):
 if isinstance(a,str):return'declaration'
 if 'from_square'not in a:return'drop'
 if a.get('promotion_target_id')is not None:return'promotion'
 return'board'
for q in qs:
 if q['committed']is not None:chosen[kind(q['committed'])]+=1
 for a in q['decision_line']:pv[kind(a)]+=1
for r in map(json.loads,(D/'generation.jsonl').read_bytes().splitlines()):
 if 'rules'in r:
  types[str(r['size'])]+=len(r['rules']['piece_types'])
write_json(D/'coverage.json',dict(status='SAVED_RECEIPT_COVERAGE',physical_games=len(gs),closed_terminal_prefix_cells=sum(g['queries']==0 and g['ending']=='ACTUAL_TERMINAL'for g in gs),queries=len(qs),chosen_actions=dict(chosen),PV_actions=dict(pv),board_physical_games=dict(Counter(g['size']for g in gs)),declared_rule_types_by_board=dict(types),root_statuses=dict(Counter(r['result']['status']for r in roots)),endings=dict(Counter(g['ending']for g in gs)),terminal_reasons=dict(Counter(g['result']['status']for g in gs if g['result']and g['ending']=='ACTUAL_TERMINAL')),scope='Countsactualsavedcommits/PV androot/finalresult. Promotion/drop/rules/historyretained, not proofthatallpossibleauxiliarymechanisms orcompletegenerateddomain wereexercised. No newgeneration/query/game orfiltering.'))
print('COVERAGE',len(gs),dict(chosen))
