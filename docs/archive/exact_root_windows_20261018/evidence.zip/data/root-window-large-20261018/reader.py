"""Rebuild large-rule inputs and full parent/PV receipts without search."""
from pathlib import Path
from collections import Counter
from copy import copy
import json,sys,time,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=R/'.local_agent/root-window-large-20261018';P=json.loads((D/'plan.json').read_bytes());start=time.perf_counter();counts=Counter();grs=list(map(json.loads,(D/'generation.jsonl').read_bytes().splitlines()));compiled={g['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(g['rules']))for g in grs if 'rules'in g};mods={(r['rule'],r['label']):r for r in json.loads((D/'models.json').read_bytes())['rows']};roots={(r['rule'],r['family']):r for r in json.loads((D/'roots.json').read_bytes())['rows']};slots=json.loads((D/'slots.json').read_bytes())['slots'];qs=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));arms={}
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
def poll():
 assert time.perf_counter()-start<300,'READER_CAP'
 for name in('rollout','advisor','slack'):
  f=json.loads((Path(os.environ.get('GC_REPLAY_STOP_ROOT',R))/'.local_agent'/(name+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
for gs,c in compiled.items():
 poll();v=build_ruleset_profile(c,EvaluationConfig());m=mods[gs,'rule_static_v2'];cp=LearnableMaterialCheckpoint.from_dict(m['checkpoint']);cp.validate_ruleset(c);assert cp.checkpoint_id==m['checkpoint_id']
 for t in c.types_by_id:assert cp.board_weights[t]==v.board_value_by_type[t]/1000 and cp.hand_weights[t]==v.hand_value_by_base_type[t]/1000;counts['typed_coefficients']+=1
 counts['profiles']+=1
seen=set()
for q in qs:
 poll();idx=q['slot'];assert idx not in seen;seen.add(idx);gs,fam,budget,mode=slots[idx];assert[gs,fam,budget,mode]==[q['rule'],q['family'],q['budget'],q['mode']];counts['returned']+=1
 if q['status']!='SEARCH_RETURNED':counts[q['status']]+=1;continue
 root=roots[gs,fam];c=compiled[gs];s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));assert digest(s.state)==q['parent_state_sha256']==root['state_sha256'];assert digest(s._search_witnesses)==root['witnesses_sha256'];assert q['parent_unchanged']and q['root_window']==mode;cp=mods[gs,'rule_static_v2']['checkpoint'];assert q['checkpoint_id']==mods[gs,'rule_static_v2']['checkpoint_id'];assert q['qnodes']==0
 if P['budgets'][budget]['nodes']is not None:assert q['nodes']<=P['budgets'][budget]['nodes']
 leaf=copy(s)
 for raw in q['decision_line']:
  a=decode(raw)
  if isinstance(a,str):leaf.declare(a)
  else:leaf.submit(a);counts['PV_core_edges']+=1
 if q['depth']>=1 and not q['fallback']:
  assert q['decision_line']and q['decision_line'][0]==(q['declaration_id']or q['action'])
  if leaf.result.status.value=='ongoing':
   value=sum((1 if pc.owner==0 else-1)*round(cp['board_weights'][pc.current_type_id]*256)for pc in leaf.state.position.board if pc is not None)+sum((leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t))*round(w*256)for t,w in cp['hand_weights'].items())
  else:value=0 if leaf.result.winner is None else(100000000-len(q['decision_line']))*(1 if leaf.result.winner==0 else-1)
  assert value==q['score']*(1 if s.state.position.side_to_move==0 else-1);counts['usable_return']+=1
 else:counts['D0_or_fallback_UNKNOWN']+=1
 counts['queries']+=1;counts['nodes']+=q['nodes']
 key=str(gs%100)+'_'+budget+'_'+str(mode);aa=arms.setdefault(key,dict(observed=0,usable=0,nodes=0,caller_seconds=0.,kernel_seconds=0.,depths=Counter(),causes=Counter()))
 aa['observed']+=1;aa['usable']+=int(q['depth']>=1 and not q['fallback']);aa['nodes']+=q['nodes'];aa['caller_seconds']+=q['caller_seconds'];aa['kernel_seconds']+=q['kernel_seconds'];aa['depths'][q['depth']]+=1;aa['causes'][q['cause']]+=1
done=json.loads((D/'result.json').read_bytes());assert len(qs)==done['returned']and counts['nodes']==done['counts']['nodes']
for size in P['board_sizes']:
 for budget in P['budgets']:
  for mode in P['modes']:
   k=str(size)+'_'+budget+'_'+str(mode);a=arms.setdefault(k,dict(observed=0,usable=0,nodes=0,caller_seconds=0.,kernel_seconds=0.,depths={},causes={}));a.update(planned=8,unobserved_or_refused_UNKNOWN=8-a['observed'])
write_json(D/'reader-result.json',dict(status='PASS_SAVED_LARGER_BOARD_INPUTS_AND_CORE_PV',counts=dict(counts),seconds=time.perf_counter()-start,scope='Allsavedfullroots/history/witnesses/checkpointids/staticcoefficients/PV/value/declaredbudget checked; no Native/generation/newgame. LiteralPVvalues not deeperoptimality/WDL/utility orall-domainproof. Plannedrefusals/D0/missingneverfilled.'))
write_json(D/'analysis.json',dict(status='LARGER_BOARD_OPERATIONAL_GATE',arms=arms,planned=96,returned=len(qs),missing=96-len(qs),producer_seconds=done['seconds'],scope='4linkedseedblocks/12newfullrules/24parents,10/12/16boards. Conditionaladmission/completion/paidwork only, notlarger-boardutility/default/whole-domainguarantee. Nodecaps andkerneldeadline differentestimands; allfailuresretained.'))
print('LARGE_READER',dict(counts),time.perf_counter()-start)
