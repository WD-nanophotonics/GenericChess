"""Scoped broader-domain Unit/static work curve, reusing the existing complete-session runner."""
from pathlib import Path
import sys,json,time,random,hashlib,traceback,subprocess
from dataclasses import asdict
from collections import Counter
ROOT=Path.cwd();D=ROOT/'.local_agent/root-window-large-20261018';START=time.monotonic();sys.path.insert(0,str(ROOT))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.generation.config import GeneratorConfig,GenerationError
from generic_chess.generation.generator import generate_game
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import serialize_game_record,deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
P=json.loads((D/'plan.json').read_bytes());compiled={};native={};models={};roots={};rules={};games=[];counts=Counter();status='COMPLETE';reason=current=None
assert not(D/'producer-source.json').exists()and not(D/'games.jsonl').exists()
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 if time.monotonic()-START>=P['limits']['global_cap_seconds']:raise TimeoutError('FROZEN_GLOBAL_CAP')
 for name in ['rollout','advisor','slack']:
  q=json.loads((ROOT/'.local_agent'/(name+'.json')).read_bytes())
  if q.get('stopped')or q.get('user_paused'):raise InterruptedError('EXPLICIT_STOP')
def reward(s,owner):
 if s.result.status.value=='ongoing':return None
 return 0 if s.result.winner is None else 1 if s.result.winner==owner else-1
P.setdefault('max_generation_attempts',16);P.setdefault('model_inputs',['rule_static_v2']);P.setdefault('objective','Completefulltypedstaticprofile, no modelintervention.');P.setdefault('limits',dict(global_cap_seconds=P['global_seconds'],max_output_bytes=P['max_output_bytes']))
slots=[(seed*100+size,fam,budget,mode)for seed in P['seeds']for size in P['board_sizes']for fam in P['families']for budget in P['budgets']for mode in P['modes']];assert len(slots)==96;random.Random(P['random_order_seed']).shuffle(slots);write_json(D/'slots.json',dict(slots=slots))
write_json(D/'producer-source.json',dict(producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),base_sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),scope='NEWlargerboardfullstateadmission/workgate, notfitness ortraining.'))
try:
 with(D/'generation.jsonl').open('x',encoding='utf8')as genlog:
  for seed in P['seeds']:
   for size in P['board_sizes']:
    poll();tick=time.perf_counter();gs=seed*100+size;cfg=GeneratorConfig(seed=seed,board_size=size,setup_preset='classic_like'if seed%2 else'free_random',movement_symmetry='bilateral'if(seed//2)%2 else'none',allow_hybrid=True,max_generation_attempts=P['max_generation_attempts'],require_no_opening_win_in_one=False);row=dict(rule=gs,seed=seed,size=size,config=asdict(cfg));rules[gs]=row
    try:g=generate_game(cfg)
    except GenerationError as exc:
     row.update(status='GENERATION_REFUSAL',error=str(exc),generation_seconds=time.perf_counter()-tick);genlog.write(json.dumps(row,separators=(',',':'))+'\n');genlog.flush();counts['generation_refusals']+=1;continue
    row['generation_seconds']=time.perf_counter()-tick;tick=time.perf_counter();c=compile_legacy_ruleset_for_semantic_execution(g.ruleset);compiled[gs]=c;row.update(rules=ruleset_to_dict(g.ruleset),fingerprint=c.ruleset_fingerprint,types=sorted(c.types_by_id),compile_seconds=time.perf_counter()-tick);tick=time.perf_counter();profile=build_ruleset_profile(c,EvaluationConfig());assert set(profile.board_value_by_type)==set(profile.hand_value_by_base_type)==set(c.types_by_id);anchors={t.type_id for t in c.piece_types if t.is_anchor}
    for label in P['model_inputs']:
     board={t:0. if t in anchors else 1. if label=='unit'else profile.board_value_by_type[t]/1000 for t in c.types_by_id};hand={t:0. if t in anchors else 1. if label=='unit'else profile.hand_value_by_base_type[t]/1000 for t in c.types_by_id};models[gs,label]=LearnableMaterialCheckpoint(ruleset_fingerprint=c.ruleset_fingerprint,evaluation_profile_version='full-type-'+label,board_weights=board,hand_weights=hand,material_scale=256,value_scale=10.,reference_median=1.)
    row['profile_seconds']=time.perf_counter()-tick;tick=time.perf_counter()
    try:native[gs]=compile_native_semantic_rules(c);row.update(status='SUPPORTED')
    except NativeUnsupportedRuleError as exc:row.update(status='NATIVE_REFUSAL',error=str(exc));counts['native_refusals']+=1
    row['native_compile_seconds']=time.perf_counter()-tick;genlog.write(json.dumps(row,separators=(',',':'))+'\n');genlog.flush();counts['generated_rules']+=1
    for fam in P['families']:
     poll();tick=time.perf_counter();s=GameSession(c);rng=random.Random(gs*1000000+fam)
     for _ in range(P['prefix']):
      if s.result.status.value!='ongoing':break
      aa=sorted(s.legal_actions(),key=repr);assert aa;s.submit(aa[rng.randrange(len(aa))])
     roots[gs,fam]=dict(rule=gs,family=fam,record=json.loads(serialize_game_record(s.to_record())),state_sha256=digest(s.state),witnesses_sha256=digest(s._search_witnesses),prefix_completed=s.state.ply_count,result=record_value(s.result),prefix_seconds=time.perf_counter()-tick)
 write_json(D/'roots.json',dict(rows=list(roots.values()),planned_roots=P['planned_roots'],scope='No replacement/terminal filtering; two prefix families per rule are not independent rules.'));write_json(D/'models.json',dict(rows=[dict(rule=gs,label=label,checkpoint_id=cp.checkpoint_id,checkpoint=cp.to_dict())for(gs,label),cp in models.items()],scope=P['objective']));counts['prepared_roots']=len(roots)
 with(D/'queries.jsonl').open('x',encoding='utf8')as log,(D/'attempts.jsonl').open('x',encoding='utf8')as attempts:
  for slot,(gs,fam,budget,mode)in enumerate(slots):
   poll();current=dict(slot=slot,rule=gs,family=fam,budget=budget,mode=mode);attempts.write(json.dumps(current)+'\n');attempts.flush();row=rules[gs];root=roots.get((gs,fam));q=dict(current,status=row['status']+'_UNKNOWN'if row['status']!='SUPPORTED'else'TERMINAL_NO_SEARCH'if root['result']['status']!='ongoing'else'SEARCH_RETURNED',parent_state_sha256=root['state_sha256']if root else None)
   if q['status']=='SEARCH_RETURNED':
    c=compiled[gs];s=GameSession.replay(c,deserialize_game_record(json.dumps(root['record'])));cp=models[gs,'rule_static_v2'];before=(s.state,s.to_record(),s.history,s._search_witnesses);tick=time.perf_counter();e=SemanticSearchEngine(c,native[gs],checkpoint=cp,tt_megabytes=0);init=time.perf_counter()-tick;lim=P['budgets'][budget];tick=time.perf_counter()
    r=e.search(s,SearchLimits(max_depth=lim['depth'],max_nodes=lim['nodes'],max_time_seconds=lim['seconds'],quiescence_max_depth=0),root_window_pruning=mode);elapsed=time.perf_counter()-tick
    q.update(checkpoint_id=cp.checkpoint_id,action=record_value(r.action),declaration_id=r.declaration_id,decision_line=record_value(r.decision_line),score=r.score,depth=r.completed_depth,nodes=r.nodes,qnodes=r.qnodes,cause=r.termination_reason,fallback=r.used_fallback,kernel_seconds=r.elapsed_seconds,caller_seconds=elapsed,engine_init_seconds=init,parent_unchanged=before==(s.state,s.to_record(),s.history,s._search_witnesses),root_window=r.root_window_pruning)
    del e
   log.write(json.dumps(q,separators=(',',':'))+'\n');log.flush();counts['returned_queries']+=1;counts[q['status']]+=1;counts['nodes']+=q.get('nodes',0);current=None
   if q['status']=='SEARCH_RETURNED':assert q['parent_unchanged']and q['root_window']==mode
   assert log.tell()<P['limits']['max_output_bytes'],'FROZEN_OUTPUT_CAP'
   if counts['returned_queries']%16==0:print('LARGE_QUERIES',dict(counts),round(time.monotonic()-START,3),flush=True)
except BaseException as exc:status='INTERRUPTED'if isinstance(exc,(TimeoutError,InterruptedError))else'ERROR';reason=repr(exc);traceback.print_exc()
out=dict(status=status,reason=reason,planned=96,returned=counts['returned_queries'],missing=96-counts['returned_queries'],counts=dict(counts),current_unclosed=current,seconds=time.monotonic()-START,scope=P['scope']);write_json(D/'result.json',out);print('LARGE_CLOSED',out,flush=True)
