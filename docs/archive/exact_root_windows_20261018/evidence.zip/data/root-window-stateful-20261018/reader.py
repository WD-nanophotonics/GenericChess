"""Search-disabled persistent consumer receipt reader."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=R/'.local_agent/root-window-stateful-20261018';I=R/'.local_agent/rank-ratio-d2-20261018';M=R/'.local_agent/empty-mobility-utility-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',R));start=time.perf_counter();counts=Counter()
ctxs=json.loads((I/'contexts.json').read_bytes())['rows'];refs={r['context']:r for r in map(json.loads,(I/'roots.jsonl').read_bytes().splitlines())if r['status']=='COMPLETE'};mods={(r['rule'],r['label']):r['checkpoint']for r in json.loads((M/'models.json').read_bytes())['rows']};compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(M/'generation.jsonl').read_bytes().splitlines())}
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
rows=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));assert len(rows)==192
for idx,q in enumerate(rows):
 assert time.perf_counter()-start<120 and q['slot']==idx
 for n in('rollout','advisor','slack'):
  f=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 ctx=ctxs[q['context']];c=compiled[ctx['rule']];s=GameSession.replay(c,deserialize_game_record(json.dumps(ctx['record'])));assert digest(s.state)==q['state_sha256']==ctx['state_sha256'] and q['parent_unchanged']
 cp=mods[ctx['rule'],q['model']];parsed=LearnableMaterialCheckpoint.from_dict(cp);parsed.validate_ruleset(c);assert parsed.checkpoint_id==q['checkpoint_id'];assert q['qnodes']==0 and q['nodes']<=32768;leaf=copy(s)
 for raw in q['decision_line']:
  a=decode(raw)
  if isinstance(a,str):leaf.declare(a)
  else:leaf.submit(a);counts['PV_edges']+=1
 if q['stage']=='pre_cancel_true_D2':
  assert q['cause']=='cancelled'and q['depth']==0;counts['pre_cancel']+=1
 elif q['requested_depth']==2:
  assert q['depth']==2 and not q['fallback'];ref=refs[q['context']];j=1 if q['model']=='rule_static_v2'else 3
  assert ref['root_actions'].index(q['action'])in ref['optimal_indices'][j]
  assert q['score']*(1 if s.state.position.side_to_move==0 else-1)==ref['best_values'][j];counts['exact_D2']+=1
 else:counts['warm_deeper_partial_or_complete']+=1
 if q['stage']!='pre_cancel_true_D2'and q['requested_depth']==2:
  assert q['decision_line'][0]==(q['declaration_id']or q['action'])
  value=(sum((1 if p.owner==0 else-1)*round(cp['board_weights'][p.current_type_id]*256)for p in leaf.state.position.board if p is not None)+sum((leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t))*round(w*256)for t,w in cp['hand_weights'].items()))if leaf.result.status.value=='ongoing'else(0 if leaf.result.winner is None else(100000000-len(q['decision_line']))*(1 if leaf.result.winner==0 else-1))
  assert value==q['score']*(1 if s.state.position.side_to_move==0 else-1);counts['exact_leaf']+=1
 counts['queries']+=1;counts['nodes']+=q['nodes']
done=json.loads((D/'result.json').read_bytes());assert counts['nodes']==done['counts']['nodes']and done['status']=='COMPLETE'
write_json(D/'reader-result.json',dict(status='PASS_STATEFUL_ROOT_WINDOW_CONSUMER',counts=dict(counts),seconds=time.perf_counter()-start,scope='All192 receipts/fullparents/PV legality,120exactD2 optima+leaf values,24deterministicprecancels.48warmD8 calls only PVlegal/work/context, not D8optimality or literalPVscorepromise. Allrealhistory unchanged, no Native search rerun.'))
print('STATEFUL_READER',dict(counts),time.perf_counter()-start)
