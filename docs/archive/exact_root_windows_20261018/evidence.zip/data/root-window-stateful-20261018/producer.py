"""Frozen persistent exact-root-window consumer control; raw receipts precede assertions."""
from pathlib import Path
import sys,json,time,hashlib
from collections import Counter
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
from generic_chess.ai.cancellation import CancellationToken
D=R/'.local_agent/root-window-stateful-20261018';I=R/'.local_agent/rank-ratio-d2-20261018';M=R/'.local_agent/empty-mobility-utility-20261018'
P=json.loads((D/'plan.json').read_bytes());B=json.loads((R/'.local_agent/root-window-budget-20261018/plan.json').read_bytes());start=time.perf_counter();counts=Counter();status='COMPLETE';error=None
assert not(D/'queries.jsonl').exists()
for name,sha in B['source_inputs'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha
contexts=json.loads((I/'contexts.json').read_bytes())['rows'];refs={r['context']:r for r in map(json.loads,(I/'roots.jsonl').read_bytes().splitlines())if r['status']=='COMPLETE'}
compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(M/'generation.jsonl').read_bytes().splitlines())}
native={gs:compile_native_semantic_rules(c)for gs,c in compiled.items()}
models={(r['rule'],r['label']):LearnableMaterialCheckpoint.from_dict(r['checkpoint'])for r in json.loads((M/'models.json').read_bytes())['rows']if r['label']in P['base_profiles']}
def digest(x):return hashlib.sha256(json.dumps(record_value(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.perf_counter()-start<P['global_seconds'],'FROZEN_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
try:
 with(D/'queries.jsonl').open('x',encoding='utf8')as log,(D/'attempts.jsonl').open('x',encoding='utf8')as attempts:
  for cid in B['contexts']:
   ctx=contexts[cid];gs=ctx['rule'];c=compiled[gs];s=GameSession.replay(c,deserialize_game_record(json.dumps(ctx['record'])));assert digest(s.state)==ctx['state_sha256']
   for base in P['base_profiles']:
    other=next(x for x in P['base_profiles']if x!=base);e=None
    for step,name in enumerate(P['stages']):
     poll()
     if step in(0,1):e=SemanticSearchEngine(c,native[gs],checkpoint=models[gs,base],tt_megabytes=4)
     if step==5:e.bind_checkpoint(models[gs,other])
     model=other if step>=5 else base;mode=step!=1;depth=8 if step in(1,3)else 2;token=None
     if step==6:token=CancellationToken();token.cancel()
     before=(s.state,s.to_record(),s.history,s._search_witnesses);slot=counts['queries'];attempts.write(json.dumps(dict(slot=slot,context=cid,base=base,stage=name))+'\n');attempts.flush();tick=time.perf_counter()
     r=e.search(s,SearchLimits(max_depth=depth,max_nodes=32768,max_time_seconds=.5,quiescence_max_depth=0),token,root_window_pruning=mode)
     elapsed=time.perf_counter()-tick
     row=dict(slot=slot,context=cid,rule=gs,base=base,model=model,checkpoint_id=models[gs,model].checkpoint_id,stage=name,root_window=mode,requested_depth=depth,state_sha256=digest(s.state),action=record_value(r.action),declaration_id=r.declaration_id,decision_line=record_value(r.decision_line),score=r.score,depth=r.completed_depth,nodes=r.nodes,qnodes=r.qnodes,cause=r.termination_reason,fallback=r.used_fallback,kernel_seconds=r.elapsed_seconds,caller_seconds=elapsed,tt_info=record_value(e.tt_info()),parent_unchanged=before==(s.state,s.to_record(),s.history,s._search_witnesses))
     log.write(json.dumps(row,separators=(',',':'))+'\n');log.flush();counts['queries']+=1;counts['nodes']+=r.nodes
     assert row['parent_unchanged']and r.root_window_pruning==mode
     if step==6:
      assert r.termination_reason=='cancelled'and r.completed_depth==0;counts['pre_cancel_pass']+=1
     elif depth==2:
      ref=refs[cid];j=1 if model=='rule_static_v2'else 3;assert r.completed_depth==2 and not r.used_fallback
      assert r.score*(1 if s.state.position.side_to_move==0 else-1)==ref['best_values'][j]
      assert row['action']in ref['root_actions']and ref['root_actions'].index(row['action'])in ref['optimal_indices'][j];counts['exact_D2_pass']+=1
     else:counts['warm_calls']+=1
     if step==0:del e;e=None
     assert log.tell()<P['max_output_bytes'],'FROZEN_OUTPUT_CAP'
    del e
except BaseException as exc:status='ERROR';error=repr(exc)
write_json(D/'result.json',dict(status=status,error=error,counts=dict(counts),seconds=time.perf_counter()-start,planned=192,missing=192-counts['queries'],scope='12posthoclinkedfullparents/2profiles; no newgames/training, exactD2 reference and deterministic pre-cancel contract, not all-domain utility/deeperoptimality.'))
print('STATEFUL_CLOSED',status,error,dict(counts),time.perf_counter()-start,flush=True)
