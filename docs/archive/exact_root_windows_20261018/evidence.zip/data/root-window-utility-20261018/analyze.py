"""All planned cells, paired reward bounds and linked-seed descriptive envelopes."""
from pathlib import Path
from collections import Counter
import json,sys,random,hashlib
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
D=R/'.local_agent/root-window-utility-20261018';p=json.loads((D/'plan.json').read_bytes());result=json.loads((D/'result.json').read_bytes());slots=json.loads((D/'slots.json').read_bytes())['slots'];games={g['slot']:g for g in map(json.loads,(D/'games.jsonl').read_bytes().splitlines())};rows=[]
for idx,(gs,fam,label,owner,foe,mode)in enumerate(slots):
 g=games.get(idx)
 if g is not None:assert[gs,fam,label,owner,foe,mode]==[g['rule'],g['family'],g['label'],g['candidate_owner'],g['foe'],g['window']]
 rows.append(dict(slot=idx,rule=gs,seed=gs//100,size=gs%100,family=fam,owner=owner,foe=foe,mode=mode,budget=label.split('@')[1],reward=None if g is None else g['reward'],game=g))
assert len(rows)==p['planned_physical']==512 and len(games)==result['returned_physical']
def bounds(rr):
 n=len(rr);u=sum(r['reward']is None for r in rr);k=sum(r['reward']for r in rr if r['reward']is not None)
 return dict(planned=n,observed=sum(r['game']is not None for r in rr),W=sum(r['reward']==1 for r in rr),D=sum(r['reward']==0 for r in rr),L=sum(r['reward']==-1 for r in rr),UNKNOWN=u,reward_bounds=[(k-u)/n,(k+u)/n],nodes=sum((r['game']or{}).get('nodes',0)for r in rr),game_seconds=sum((r['game']or{}).get('game_seconds',0)for r in rr))
def contrast(rr):
 a={(r['rule'],r['family'],r['owner']):r for r in rr if r['mode']};b={(r['rule'],r['family'],r['owner']):r for r in rr if not r['mode']};assert a.keys()==b.keys();n=len(a);lo=hi=0
 for k in a:
  x=a[k]['reward'];y=b[k]['reward'];lo+=(-1 if x is None else x)-(1 if y is None else y);hi+=(1 if x is None else x)-(-1 if y is None else y)
 return[lo/n,hi/n]
contrasts={}
for budget in p['budgets']:
 for foe in p['foe_models']:
  rr=[r for r in rows if r['budget']==budget and r['foe']==foe];seeds=p['seeds'];per={s:contrast([r for r in rr if r['seed']==s])for s in seeds};rng=random.Random(2026101813);boot=[]
  for _ in range(10000):
   sample=[rng.choice(seeds)for __ in seeds];boot.append([sum(per[s][i]for s in sample)/len(sample)for i in(0,1)])
  contrasts[budget+'_'+foe]=dict(arms={str(mode):bounds([r for r in rr if r['mode']==mode])for mode in(False,True)},true_minus_false=contrast(rr),per_seed=per,by_board={str(size):contrast([r for r in rr if r['size']==size])for size in p['board_sizes']},descriptive_linked_seed_envelope=[sorted(x[0]for x in boot)[249],sorted(x[1]for x in boot)[9749]])
qq=list(map(json.loads,(D/'queries.jsonl').read_bytes().splitlines()));assert sum(q['nodes']for q in qq)==result['counts']['nodes'];work={}
for budget in p['budgets']:
 for mode in(False,True):
  ids={r['slot']for r in rows if r['budget']==budget and r['mode']==mode};qs=[q for q in qq if q['slot']in ids];work[budget+'_'+str(mode)]={side:dict(queries=len(v),nodes=sum(q['nodes']for q in v),caller_seconds=sum(q['caller_seconds']for q in v),kernel_seconds=sum(q['kernel_seconds']for q in v),depths=dict(Counter(q['completed_depth']for q in v)),causes=dict(Counter(q['cause']for q in v)))for side,v in[(side,[q for q in qs if q['candidate_turn']==(side=='candidate')])for side in('candidate','foe')]}
write_json(D/'analysis.json',dict(status='PASS_PLANNED_ROOT_WINDOW_UTILITY_ARITHMETIC',contrasts=contrasts,work=work,producer_seconds=result['seconds'],planned=len(rows),returned=len(games),missing=len(rows)-len(games),queries=len(qq),nodes=result['counts']['nodes'],scope='Eightlinkedseedblocks with2boards/2families/bothroles/twofixedfoes. Candidate SAMEstaticcheckpoint, only rootwindowtoggle; foesalwaysFalse. Everymissing/unclosed/horizonLIMIT UNKNOWN, actualdraw0 only. Descriptive10000seedresamples not populationconfidence/independentgames. Equaldeclarednodecaps/.5s, actualcosts differ; no puredepth/equalwall/WDL/default orall-domainclaim. No oldtailrefill, learner/fitnessrerun.'))
print(json.dumps(dict(contrasts=contrasts,work=work,queries=len(qq)),indent=2))
