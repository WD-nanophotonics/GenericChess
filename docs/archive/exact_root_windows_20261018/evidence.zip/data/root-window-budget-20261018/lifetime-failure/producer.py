"""Bounded existing-root-window diagnostic on complete saved CoreD2 references."""
from pathlib import Path
from collections import Counter
import sys,json,time,hashlib,random,os
R=Path.cwd();sys.path.insert(0,str(R))
from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.native import _module
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic_engine import SemanticSearchEngine
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.ai.limits import SearchLimits
D=R/'.local_agent/root-window-budget-20261018';I=R/'.local_agent/rank-ratio-d2-20261018';M=R/'.local_agent/empty-mobility-utility-20261018';P=json.loads((D/'plan.json').read_bytes());assert not(D/'started.json').exists();start=time.perf_counter()
write_json(D/'started.json',dict(started_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),pid=os.getpid(),plan_sha256=hashlib.sha256((D/'plan.json').read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
counts=Counter();status='COMPLETE';reason=None
for name,sha in P['source_inputs'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha
contexts=json.loads((I/'contexts.json').read_bytes())['rows'];refs={r['context']:r for r in map(json.loads,(I/'roots.jsonl').read_bytes().splitlines())if r['status']=='COMPLETE'};gsset={contexts[i]['rule']for i in P['contexts']}
compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(M/'generation.jsonl').read_bytes().splitlines())if r['rule']in gsset};native={gs:compile_native_semantic_rules(c)for gs,c in compiled.items()}
models={(r['rule'],r['label']):LearnableMaterialCheckpoint.from_dict(r['checkpoint'])for r in json.loads((M/'models.json').read_bytes())['rows']if r['rule']in gsset and r['label']in P['models']}
slots=[(i,m,n,w)for i in P['contexts']for m in P['models']for n in P['caps']for w in P['root_window_modes']];assert len(slots)==192;random.Random(P['random_order_seed']).shuffle(slots);write_json(D/'slots.json',dict(slots=slots));backend=_module()
write_json(D/'backend.json',dict(capabilities=backend.native_capabilities(),binary_basename=Path(backend.__file__).name,binary_sha256=hashlib.sha256(Path(backend.__file__).read_bytes()).hexdigest()))
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def poll():
 assert time.perf_counter()-start<P['global_seconds'],'FROZEN_GLOBAL_CAP'
 for n in('rollout','advisor','slack'):
  f=json.loads((R/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused')),'EXPLICIT_STOP'
try:
 with(D/'queries.jsonl').open('x',encoding='utf8')as log:
  for slot,(idx,model,cap,mode)in enumerate(slots):
   poll();ctx=contexts[idx];gs=ctx['rule'];c=compiled[gs];cp=models[gs,model];cp.validate_ruleset(c);s=GameSession.replay(c,deserialize_game_record(json.dumps(ctx['record'])));assert digest(s.state)==ctx['state_sha256'];before=(s.state,s.to_record(),s.history,s._search_witnesses);tick=time.perf_counter();e=SemanticSearchEngine(c,native[gs],checkpoint=cp,tt_megabytes=0);init=time.perf_counter()-tick
   try:
    tick=time.perf_counter();r=e.search(s,SearchLimits(max_depth=2,max_nodes=cap,max_time_seconds=.5,quiescence_max_depth=0),root_window_pruning=mode);elapsed=time.perf_counter()-tick;assert before==(s.state,s.to_record(),s.history,s._search_witnesses);assert r.root_window_pruning==mode
   finally:e.close()
   row=dict(slot=slot,context=idx,rule=gs,model=model,checkpoint_id=cp.checkpoint_id,nodecap=cap,root_window=mode,state_sha256=digest(s.state),action=record_value(r.action),declaration_id=r.declaration_id,decision_line=record_value(r.decision_line),score=r.score,depth=r.completed_depth,nodes=r.nodes,qnodes=r.qnodes,cause=r.termination_reason,fallback=r.used_fallback,kernel_seconds=r.elapsed_seconds,caller_seconds=elapsed,engine_init_seconds=init)
   if r.completed_depth==2 and not r.used_fallback:
    q=1 if model=='rule_static_v2' else 3;ref=refs[idx];expected=ref['best_values'][q]*(1 if s.state.position.side_to_move==0 else-1);chosen=ref['root_actions'].index(record_value(r.action))if record_value(r.action)in ref['root_actions']else None
    row.update(expected_D2_score=expected,chosen_ref_index=chosen,complete_D2_score_equal=r.score==expected,complete_D2_action_optimal=chosen in ref['optimal_indices'][q]);counts['completed_D2']+=1;counts['complete_D2_mismatch']+=not(row['complete_D2_score_equal']and row['complete_D2_action_optimal'])
   else:counts['D2_UNRESOLVED']+=1
   counts['queries']+=1;counts['nodes']+=r.nodes;log.write(json.dumps(row,separators=(',',':'))+'\n');log.flush()
   if counts['queries']%32==0:print('ROOT_WINDOW_QUERIES',counts['queries'],dict(counts),round(time.perf_counter()-start,3),flush=True)
   assert log.tell()<P['max_output_bytes'],'FROZEN_OUTPUT_CAP'
except BaseException as exc:status='PARTIAL_LIMIT'if any(x in str(exc)for x in('CAP','STOP'))else'ERROR';reason=repr(exc)
write_json(D/'result.json',dict(status=status,reason=reason,planned_queries=192,returned=counts['queries'],missing=192-counts['queries'],counts=dict(counts),seconds=time.perf_counter()-start,scope=P['scope']));print('ROOT_WINDOW_CLOSED',status,reason,dict(counts),time.perf_counter()-start,flush=True)
