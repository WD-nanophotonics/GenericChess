"""Search-free full Core/PV/optimum and planned missing-slot accounting."""
from pathlib import Path
from copy import copy
from collections import Counter
import sys,json,time,hashlib,os
R=Path.cwd();sys.path.insert(0,str(R));from tools.local_agent.common import write_json
from scripts.research_record import record_value
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_legacy_ruleset_for_semantic_execution
from generic_chess.learning.material import LearnableMaterialCheckpoint
from generic_chess.session.session import GameSession
from generic_chess.session.serialization import deserialize_game_record
from generic_chess.core.actions import SemanticBoardMove,SemanticDropMove
from generic_chess.core.coordinates import Square
D=R/'.local_agent/root-window-budget-20261018';I=R/'.local_agent/rank-ratio-d2-20261018';M=R/'.local_agent/empty-mobility-utility-20261018';STOP=Path(os.environ.get('GC_REPLAY_STOP_ROOT',R));start=time.perf_counter();counts=Counter();ctxs=json.loads((I/'contexts.json').read_bytes())['rows'];refs={r['context']:r for r in map(json.loads,(I/'roots.jsonl').read_bytes().splitlines())if r['status']=='COMPLETE'};mods={(r['rule'],r['label']):r['checkpoint']for r in json.loads((M/'models.json').read_bytes())['rows']};compiled={r['rule']:compile_legacy_ruleset_for_semantic_execution(ruleset_from_dict(r['rules']))for r in map(json.loads,(M/'generation.jsonl').read_bytes().splitlines())};slots=json.loads((D/'slots.json').read_bytes())['slots'];qs={q['slot']:q for q in map(json.loads,(D/'queries.jsonl').read_bytes().splitlines())}
def digest(v):return hashlib.sha256(json.dumps(record_value(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def decode(a):
 if isinstance(a,str):return a
 a=dict(a);a['to_square']=Square(**a['to_square'])
 if 'from_square'in a:a['from_square']=Square(**a['from_square']);return SemanticBoardMove(**a)
 return SemanticDropMove(**a)
for idx,q in qs.items():
 assert time.perf_counter()-start<120
 for n in('rollout','advisor','slack'):
  f=json.loads((STOP/'.local_agent'/(n+'.json')).read_bytes());assert not(f.get('stopped')or f.get('user_paused'))
 cid,model,cap,mode=slots[idx];assert[cid,model,cap,mode]==[q['context'],q['model'],q['nodecap'],q['root_window']];ctx=ctxs[cid];c=compiled[ctx['rule']];s=GameSession.replay(c,deserialize_game_record(json.dumps(ctx['record'])));assert digest(s.state)==ctx['state_sha256']==q['state_sha256'];cp=mods[ctx['rule'],model];parsed=LearnableMaterialCheckpoint.from_dict(cp);parsed.validate_ruleset(c);assert parsed.checkpoint_id==q['checkpoint_id'];assert q['qnodes']==0 and 0<=q['depth']<=2 and q['nodes']<=cap;leaf=copy(s)
 for raw in q['decision_line']:
  a=decode(raw)
  if isinstance(a,str):leaf.declare(a)
  else:leaf.submit(a);counts['PV_edges']+=1
 if q['depth']>=1 and not q['fallback']:
  assert q['decision_line']and q['decision_line'][0]==(q['declaration_id']or q['action'])
  if leaf.result.status.value=='ongoing':
   value=sum((1 if p.owner==0 else-1)*round(cp['board_weights'][p.current_type_id]*256)for p in leaf.state.position.board if p is not None)+sum((leaf.state.position.hands[0].count(t)-leaf.state.position.hands[1].count(t))*round(w*256)for t,w in cp['hand_weights'].items());counts['ordinary_PV']+=1
  else:value=0 if leaf.result.winner is None else(100000000-len(q['decision_line']))*(1 if leaf.result.winner==0 else-1);counts['terminal_PV']+=1
  assert value==q['score']*(1 if s.state.position.side_to_move==0 else-1)
 if q['depth']==2 and not q['fallback']:
  j=1 if model=='rule_static_v2' else 3;ref=refs[cid];chosen=ref['root_actions'].index(q['action']);assert chosen in ref['optimal_indices'][j];assert q['score']*(1 if s.state.position.side_to_move==0 else-1)==ref['best_values'][j];counts['exact_D2_checked']+=1
 counts['queries']+=1;counts['nodes']+=q['nodes']
done=json.loads((D/'result.json').read_bytes());assert counts['queries']==done['returned']==191 and counts['nodes']==done['counts']['nodes'];assert set(range(192))-qs.keys()=={0}
write_json(D/'reader-result.json',dict(status='PASS_ALL_PERSISTED_ROOT_WINDOW_RECEIPTS',counts=dict(counts),lost_slot_unknown=[0],unobserved_paid_nodes=None,seconds=time.perf_counter()-start,scope='All191persistedfullparent/checkpoint/PV/quantizedscore/129completeD2optimums; lostslot0 remainsUNKNOWN/unobservedpaidcost, norequery. OriginalcappedCoretree untouched. SameCore, notexternalrules/WDL/deeperoptimality/utilityclaim.'))
by={(q['context'],q['model'],q['nodecap'],q['root_window']):q for q in qs.values()};arms={};pairs={}
for cap in[128,1024,8192,32768]:
 for mode in(False,True):
  qq=[q for q in qs.values()if q['nodecap']==cap and q['root_window']==mode];complete=sum(q['depth']==2 and not q['fallback']for q in qq);missing=24-len(qq);arms[str(cap)+'_'+str(mode)]=dict(planned=24,observed=len(qq),missing_UNKNOWN=missing,D2_complete=complete,D2_complete_fraction_bounds=[complete/24,(complete+missing)/24],observed_nodes=sum(q['nodes']for q in qq),observed_caller_seconds=sum(q['caller_seconds']for q in qq),depths=dict(Counter(q['depth']for q in qq)))
 pp=[(q,by[q['context'],q['model'],cap,True])for q in qs.values()if q['nodecap']==cap and not q['root_window']and(q['context'],q['model'],cap,True)in by];both=[(a,b)for a,b in pp if a['depth']==b['depth']==2];d2=lambda q:int(q['depth']==2 and not q['fallback']);lo=sum(d2(b)-d2(a)for a,b in pp);missing=24-len(pp)
 pairs[str(cap)]=dict(matched=len(pp),unobserved_pairs=missing,complete_D2_gain_count_bounds=[lo-missing,lo+missing],both_complete=len(both),both_complete_action_differences=sum(a['action']!=b['action']for a,b in both),both_complete_node_ratio_true_over_false=sum(b['nodes']for a,b in both)/sum(a['nodes']for a,b in both)if both else None,matched_nodes_false=sum(a['nodes']for a,b in pp),matched_nodes_true=sum(b['nodes']for a,b in pp))
write_json(D/'analysis.json',dict(status='PASS_PLANNED_ROOT_WINDOW_COST_AND_SEMANTICS',arms=arms,paired=pairs,observed=191,planned=192,unobserved_paid_nodes=None,original_elapsed_with_repair_not_pure_compute=True,scope='12linkedselectedCorecontexts/2profiles, not96independentcases; onepasssubmillisecondtimingsdescriptive. Pairednodes/capcompletion, notactionquality/utility/default orwhole-domainwinner. Lostslot0UNKNOWN, nozero-costorfailedcompletionimputation.'))
print('READER',dict(counts));print(json.dumps(dict(arms=arms,pairs=pairs),indent=2))
