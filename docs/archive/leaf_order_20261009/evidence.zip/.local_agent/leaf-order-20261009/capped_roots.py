"""Localization on frozen capped game roots, not extension of old game results.
Four roots, each both leaf models q0/q2,D2,4096nodes/10sec, freshTT/unitordering.
Question: is censoring a q2 resource cost rather than price/build failure?
References q0 fullwidth4096scorings/5sec; unknown on actual reference fuse.
Old2sec pilot cells retain censorship and are never upgraded or overwritten.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv,CountedEvaluator,ReferenceLimit
from scripts.research_record import record_value,write_record
folder=Path(__file__).parent;out=folder/'capped-roots.json';assert not out.exists();source=json.loads((folder/'paired-games.json').read_bytes());result=dict(scope=__doc__,complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256((folder/'paired-games.json').read_bytes()).hexdigest(),roots=[])
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
class FixedOrder:
 def __init__(self,leaf,unit):self.leaf=leaf;self.unit=unit;self.scorings=0
 def evaluate(self,state):self.scorings+=1;return self.leaf.evaluate(state)
 def capture_order_value(self,moving,captured):return self.unit[captured.current_type_id]*10-self.unit[moving.current_type_id]//10
 def type_value(self,tid):return self.unit[tid]
for case in source['cases']:
 for gi,game in enumerate(case['games']):
  if game.get('censored')!='search_incomplete':continue
  compiled=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));session=GameSession(compiled)
  for step in game['plies'][:-1]:session.submit(next(a for a in session.legal_actions() if record_value(a)==step['decision']['action']))
  assert len(session.history)==game['played_plies'];before=session.state;profile,scope=build_semantic_opportunity_profile(compiled,config);unit=case['values']['unit'];profiles={'unit':replace(profile,board_value_by_type=unit,hand_value_by_base_type=unit),'v3':profile}
  row=dict(seed=case['seed'],size=case['size'],game=gi,root=record_value(before),references=[],calls=[]);result['roots'].append(row);write_record(out,result)
  for model,p in profiles.items():
   leaf=Evaluator(compiled,p,config);counted=CountedEvaluator(leaf)
   try:
    score,action=reference_minimax(before,2,counted,compiled);ref=dict(model=model,complete=True,score=score,action=record_value(action),scorings=counted.calls)
   except ReferenceLimit:ref=dict(model=model,complete=False,scorings=counted.calls)
   row['references'].append(ref)
   for q in (0,2):
    ev=FixedOrder(leaf,unit);player=AlphaBetaPlayer(compiled,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
    start=time.perf_counter();decision=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=10,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0));seconds=time.perf_counter()-start
    validate_pv(session,decision);assert session.state==before
    complete=decision.completed_depth==2
    if not q and complete and ref['complete']:assert decision.score==ref['score']
    row['calls'].append(dict(model=model,q=q,complete=complete,scorings=ev.scorings,seconds=seconds,decision=record_value(decision)));write_record(out,result)
    print(case['seed'],gi,model,q,complete,decision.termination_reason,decision.nodes,decision.qnodes,round(seconds,3),flush=True)
result['complete']=True;write_record(out,result)
