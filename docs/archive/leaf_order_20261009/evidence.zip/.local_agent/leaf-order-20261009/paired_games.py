"""Exposed generated-rule price-hole pilot, not Elo or price validation.
Unknown: can v3 versus unit leaf prices expose a concrete exchange/search failure
at matched ordering and resources on existing seed7/21,size4/6 rules?
Freeze eight games (paired colors),32plies; D2 q2hard8,4096totalnodes/2sec,
fresh player/TT each ply, fixed unit ordering, no dynamic/root tactical terms,
Core legality. A capped search ends that game as censored, never a win/draw.
No result-driven extension. Negative/tie/sensitivity results do not fit prices.
Validate each actual PV/root and action; save after each ply for interruption.
"""
from pathlib import Path
from dataclasses import replace
import sys,time,json,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
from generic_chess.session.result import SessionStatus
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
folder=Path(__file__).parent;out=folder/'paired-games.json';assert not out.exists()
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
limits=SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=2,quiescence_hard_max_depth=8)
result=dict(declaration=__doc__,complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=[])
write_record(out,result);started=time.perf_counter()
class FixedOrder:
 def __init__(self,leaf,unit):self.leaf=leaf;self.unit=unit;self.scorings=0
 def evaluate(self,state):self.scorings+=1;return self.leaf.evaluate(state)
 def capture_order_value(self,moving,captured):return self.unit[captured.current_type_id]*10-self.unit[moving.current_type_id]//10
 def type_value(self,tid):return self.unit[tid]
for n in (4,6):
 for seed in (7,21):
  definition=generate_game(GeneratorConfig(seed=seed,board_size=n,setup_preset='bilateral_random',allow_hybrid=True)).ruleset
  compiled=compile_ruleset_for_execution(definition);v3,scope=build_semantic_opportunity_profile(compiled,config)
  unit={t:0 if meta.is_anchor else 1000 for t,meta in compiled.types_by_id.items()}
  profiles={'v3':v3,'unit':replace(v3,board_value_by_type=unit,hand_value_by_base_type=unit)}
  case=dict(size=n,seed=seed,rules=ruleset_to_dict(definition),fingerprint=compiled.ruleset_fingerprint,values=dict(v3=v3.board_value_by_type,unit=unit),games=[]);result['cases'].append(case);write_record(out,result)
  for first in ('v3','unit'):
   models=(first,'unit' if first=='v3' else 'v3');session=GameSession(compiled)
   game=dict(models=models,initial=record_value(session.state),plies=[]);case['games'].append(game);write_record(out,result)
   for ply in range(32):
    for flag in ('rollout','slack'):
     flags=json.loads((root/f'.local_agent/{flag}.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
    if session.result.status!=SessionStatus.ONGOING:break
    before=session.state;model=models[before.position.side_to_move];leaf=Evaluator(compiled,profiles[model],config);ev=FixedOrder(leaf,unit)
    player=AlphaBetaPlayer(compiled,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
    start=time.perf_counter();decision=player.choose_action(session,limits);seconds=time.perf_counter()-start
    validate_pv(session,decision);assert session.state==before
    row=dict(ply=ply,model=model,decision=record_value(decision),scorings=ev.scorings,seconds=seconds,complete=decision.completed_depth==2,root_owner0_scores={name:Evaluator(compiled,p,config).evaluate(before)*(-1 if before.position.side_to_move else 1) for name,p in profiles.items()})
    game['plies'].append(row)
    if decision.completed_depth<2:
     game['censored']='search_incomplete';write_record(out,result);break
    assert decision.action is not None;session.submit(decision.action);row['after']=record_value(session.state);write_record(out,result)
   game['result']=record_value(session.result);game['played_plies']=len(session.history)
   if session.result.status==SessionStatus.ONGOING and 'censored' not in game:game['censored']='pilot_ply_limit'
   write_record(out,result);print(n,seed,models,game['played_plies'],game.get('censored'),game['result'],flush=True)
result['complete']=True;result['seconds']=time.perf_counter()-started;write_record(out,result)
