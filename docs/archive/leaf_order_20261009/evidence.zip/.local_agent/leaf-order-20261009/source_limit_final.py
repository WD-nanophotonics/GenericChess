"""Exact rational stationary/rate checks for the declared source kernels.
Decision: would a much longer horizon remove proposal dependence? No new law.
Same frozen4x5 connected region geometry; reward=.75*geometric degree.
For any positive bridge probability, eventual entry is certain in the reachable
chain, while an impossible bridge never enters. Infinite-horizon limits can
therefore lose the useful finite-horizon continuity at a vanishing bridge.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
from fractions import Fraction as F
import hashlib
from scripts.research_record import write_record
folder=Path(__file__).parent
nodes=[r*5+f for r in range(5) for f in range(1,5)]
adj={s:[r*5+f for f,r in ((s%5-1,s//5),(s%5+1,s//5),(s%5,s//5-1),(s%5,s//5+1)) if 1<=f<5 and 0<=r<5] for s in nodes}
deg={s:len(adj[s]) for s in nodes};degree_sum=sum(deg.values());degree_square_sum=sum(v*v for v in deg.values());rows=[]
for name in ('global24','local_geometry'):
 pi={s:F(1,len(nodes)) if name=='global24' else F(deg[s],degree_sum) for s in nodes}
 matrix={s:{t:F(3,4)/(24 if name=='global24' else deg[s]) if t in adj[s] else F(0) for t in nodes} for s in nodes}
 for s in nodes:matrix[s][s]=1-sum(matrix[s].values())
 assert sum(pi.values())==1
 for t in nodes:assert sum(pi[s]*matrix[s][t] for s in nodes)==pi[t]
 for s in nodes:
  for t in nodes:assert pi[s]*matrix[s][t]==pi[t]*matrix[t][s]
 mean=sum(pi[s]*F(3,4)*deg[s] for s in nodes)
 expected_entry={str(k):str(F(4,3)*(24 if name=='global24' else 1)*(2+2**k)) for k in (0,4,8,12,16)}
 rows.append(dict(kernel=name,stationary_mean=str(mean),stationary_mean_decimal=float(mean),expected_proposals_to_region=expected_entry))
result=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),nodes=len(nodes),degree_sum=degree_sum,degree_square_sum=degree_square_sum,stationarity_checks=40,detailed_balance_checks=800,rows=rows)
write_record(folder/'source-limit-final.json',result);print(result)
