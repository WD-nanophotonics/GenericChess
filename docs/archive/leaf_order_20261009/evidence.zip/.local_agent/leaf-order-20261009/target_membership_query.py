"""Prototype target-directed legacy pseudo-attack query, no pruning or cache.
Same Leap/Ray tables, owner frame and first-blocker inclusion as pseudo_attacks.
Stop as soon as the requested square is found rather than build every attack.
"""
from generic_chess.core.errors import ensure_ruleset_match
from generic_chess.core.coordinates import square_to_index
from generic_chess.core.movement import LeapAtom

def target_membership_query(position, square, by_player, compiled):
 ensure_ruleset_match(position,compiled)
 n=compiled.board_size
 for idx,piece in enumerate(position.board):
  if piece is None or piece.owner!=by_player:continue
  tid=piece.current_type_id;atoms=compiled.types_by_id[tid].movement_atoms
  leap_row=compiled.leap_targets[tid][by_player][idx];ray_row=compiled.ray_paths[tid][by_player][idx]
  for atom_index,atom in enumerate(atoms):
   if isinstance(atom,LeapAtom):
    if square in leap_row[atom_index]:return True
   else:
    path=ray_row[atom_index]
    if square not in path:continue
    for target in path:
     if target==square:return True
     if position.board[square_to_index(target,n)] is not None:break
 return False
