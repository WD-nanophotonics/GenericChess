"""Proposal-rate sensitivity of a finite-source surrogate, not a price law.
Two declared target proposals, same projected occupancy events, rewards and root.
The local proposal includes the bridge even when contradictory guards block it;
no positive-probability support is used to renormalize proposal probabilities.
"""
from pathlib import Path
import sys,types,time,hashlib
root=Path.cwd();folder=root/'.local_agent/leaf-order-20261009';sys.path[:0]=[str(root),str(root/'tests')]
base=root/'docs/archive/semantic_zones_20261009/evidence.zip'
import zipfile
with zipfile.ZipFile(base) as z:fixture=z.read('rare_bridge.py')
ns={'__file__':'<frozen_rare_bridge>'};exec(compile(fixture.decode().split('rows=[];positions=0')[0],'<frozen_rare_bridge>','exec'),ns)
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
start=time.perf_counter();rows=[]
for k in (None,0,4,8,12,16):
 compiled=ns['compile_ruleset_for_execution'](ns['definition'](k));m=ns['m'];m.semantic_opportunity(compiled,'X',EvaluationConfig(density_points=(.5,),density_weights=(1.,)));edges=m.observed_edges
 for kernel in ('global24','local_geometry'):
  matrix=[[0.]*25 for _ in range(25)];rewards=[]
  for source in range(25):
   # Independent coordinate oracle for possible geometry, including rare bridge.
   f,r=source%5,source//5
   targets=([source+5] if f==0 and r<2 else [11] if source==10 else [rr*5+ff for ff,rr in ((f-1,r),(f+1,r),(f,r-1),(f,r+1)) if 1<=ff<5 and 0<=rr<5] if f else [])
   denominator=24 if kernel=='global24' else max(1,len(targets))
   reward=0.
   for kind in edges:
    for target,events in edges[kind][source].items():
     assert target in targets
     p=m._path_union(events,.5)*(.5 if kind=='target_empty' else .25)
     reward+=p;matrix[source][target]+=p/denominator
   matrix[source][source]=1-sum(matrix[source]);assert matrix[source][source]>=0
   rewards.append(reward)
  d=[1.]+[0.]*24;aggregate=[1.,0.,0.,0.];q=.75/(24 if kernel=='global24' else 1);b=q*(0 if k is None else .5**k);total=0.;records=[]
  for h in range(1,257):
   assert abs(sum(d[i] for i in range(25) if i%5)-aggregate[3])<1e-12
   total+=sum(p*r for p,r in zip(d,rewards))
   if h in (1,8,32,128,256):records.append(dict(horizon=h,mean=total/h,region_mass=aggregate[3]))
   d=[sum(d[s]*matrix[s][t] for s in range(25)) for t in range(25)]
   a0,a1,a2,arrived=aggregate;aggregate=[a0*(1-q),a1*(1-q)+a0*q,a2*(1-b)+a1*q,arrived+a2*b]
  rows.append(dict(guards=k,kernel=kernel,records=records))
write_record(folder/'source-rate.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(fixture).hexdigest(),aggregate_checks=3072,rows=rows,seconds=time.perf_counter()-start))
print([(r['guards'],r['kernel'],r['records'][-1]) for r in rows])
