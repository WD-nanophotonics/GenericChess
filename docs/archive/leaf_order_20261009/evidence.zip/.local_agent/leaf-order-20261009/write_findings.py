"""Publish concise Agent-owned findings into their existing purpose layers."""
from pathlib import Path
import re

def append(path, text):
    p=Path(path); before=p.read_text(encoding='utf-8')
    assert text.splitlines()[1] not in before
    p.write_bytes((before.rstrip()+'\n'+text+'\n').encode('utf-8'))

p=Path('docs/research/GEOMETRY_OCCUPANCY.md')
s=p.read_text(encoding='utf-8')
s,n1=re.subn(r'\.9681[^\n;]*?1\.0005', '.9681 to1.0005', s)
s,n2=re.subn(r'\.9639[^\n,]*?1\.0070', '.9639 to1.0070', s)
assert n1==n2==1
p.write_bytes(s.encode('utf-8'))
append(p, '''
## Fixed-order leaves, finite source laws and inert custody

The fixed-order internal-Xiangqi exchange separates leaf prices from ordering:
unit ordering is fixed for both unit/v3 leaves, Core D2, q0/q2hard8,
8192nodes/5seconds, two cold repeats per cell. All8calls complete and restore
roots/PVs. Full-width q0 scores are unit0 versusv3-1428; q2 scores both0.
The v3 capture/recapture contrast is1428 then-2126. A changed choice or horizon
response demonstrates sensitivity, not an improvement or a calibrated price.

A declared finite-source model uses the same reward but two proposal kernels:
uniform24other cells versus uniform local geometry, with blocked proposals
retaining their probability.3072 finite-horizon aggregate controls pass.
For the connected20-cell region, exact stationary means differ:93/40=2.325
versus303/124=2.4435483871;40stationarity and800detailed-balance checks pass.
A16-empty-guard bridge has expected first entry2097216 versus87384proposals.
Positive bridges eventually enter; an impossible bridge never does. Longer
horizons do not identify a natural source law and can restore a rare-bridge
discontinuity. No new default law or longer compute campaign follows.

Partial-profile controls remain explicit: a temporal transform changes material
0 to-1604 while auxiliary state changes; a four-cell compound shift keeps1000.
Their effects are excluded. Nifu/no-mate drops can retain identical candidate
tables because drop legality/utility is not projected. Reversing compiled
patterns on Chess/Shogi/internal-Xiangqi/cannon under default and non-dyadic
density laws gives8exact profile/curve/signature matches; no rounding rewrite.

An actual no-drop/no-declaration8x8 rule exposes inert custody credit: two
captured victims both have current typeR but promoted basesP/Q; old v3 hands
give257/900 while the board opportunity values areP286/Q1000/R3286. Under
matched fixed ordering,8D1/D2 old-scale/zero-hand calls agree with same-evaluator
full-width minimax. D1 credit disappears with zero-hand; D2 remains-3286.
This is a known useless-stock coefficient, not a tactical-strength claim.

The opt-in builder now labels a narrowly proved subset
`semantic-opportunity-v3-inert-hand`: zero hand coefficient only if all drop
masks are false, declarations/auxiliary mechanisms are absent, and every
remaining executable pattern is within the known simple board projection.
Dead all-drop patterns may be ignored only under those false masks. Unknown
guards/effects retain the legacy, explicitly unvalidated hand scale. A proposed
legacy-only predicate was rejected locally: the same public lowering gave0
versus900. The final typed IR/support predicate agrees without the inspection
handle. Raw board curves/normalization do not change; default evaluation/cache
does not invoke this opt-in candidate. Real hands, keys and history stay intact.

No-drop alone is insufficient. An actual optional include_hands declaration
crosses LOSS(score0) to WIN(score1) after the same capture and reply, while
remove_from_game stays LOSS on the identical physical board. Dot independently
located this published-baseline dependency; the local Agent executed the
counterexample and new product controls. Any declaration conservatively excludes
zero-hand classification. General hand utility remains unresolved.

Exact producers, failed preflights, partial outputs and final controls:
[leaf/source/custody index](data/leaf_order_20261009.json) and
[recovery manifest](../archive/leaf_order_20261009/index.json).
''')

append('docs/research/UNFAMILIAR_RULE_SEARCH.md', '''
## Legacy target queries and capture-disposition repair

A frozen8-game development pilot uses4rules (4x4/6x6,seeds7/21), paired colors,
fixed unit ordering, D2q2hard8,4096nodes/2seconds per move, cold Core. Four small
games end in1/5plies with opener wins; four6x6 games censor after3/4playedplies.
Incomplete D2 is never scored as a draw/win. Existing playability filters do
not ensure informative game length. No population-strength inference follows.

At the four exact capped roots,16new matched4096node/10second q0/q2 calls
complete;8q0 scores equal full-width references. q0 costs.031-.119seconds,
q2.663-3.034seconds with568-2588qnodes. The original2second cells stay censored.
Leaf-dependent tree size differs; this is not price quality. Profiling locates
legacy legal/attack-query work rather than leaf scoring as the main cost.

Core is_square_attacked now queries the requested compiled target directly
instead of constructing a full pseudo-attack map. Leap tables and ordered ray
paths preserve owner frames, current types, pinned pseudo-attacks and protection
of the first occupied square. The unchanged pseudo_attacks remains the oracle;
no qsupport/pruning, ordering, terminal, cancellation or budget policy changes.
On34actual positions,1808all-square/owner queries agree.32cold AB/BA q2caller
controls retain every nontiming decision/work field and query count; median
new/old wall ratio.5637 is a local43.63% reduction, not universal performance.
16final-product callers agree. Constructed8/16board ray cases also agree, with
speed ratios varying greatly; the blocked16case is only modestly faster.

Prospective fixed seeds100..107 at6x6 yield181actual root successors, no strict
unit/v3 leaf-delta ordering inversion, so the declared selection remains empty.
No replacement seeds or tie-split-as-gain interpretation.189actual root/child
positions pass13608full-map attack queries. On the first4no-immediate-win roots,
16old/product D3q0/D2q2 calls retain all nontiming fields. Short timings are
descriptive only. Native remains unavailable/unaccepted; this is Core work.

The custody pilot also caught a real execution defect: legacy Core always added
captured base type to hand even when compiled capture_disposition was
remove_from_game. The shared immutable/search-path transition now honors that
field. Promoted-base captures for both owners, child hash/reply push-pop and
root restoration are tested under both dispositions. Legacy Native cannot
represent removal: its compiler/payload boundary explicitly rejects the rule
before loading, rather than silently applying capture-to-hand. Semantic Native
is a separate existing route; no DLL was rebuilt or security control bypassed.

Recovery, frozen caps, failures, actual callers and product source pins:
[leaf/order/search index](data/leaf_order_20261009.json) and
[archive manifest](../archive/leaf_order_20261009/index.json).
''')

p=Path('docs/research/LOCAL_MAINLINE.md');s=p.read_text(encoding='utf-8')
needle='## Current evidence and decisions\n'
new='''
- Fixed-order internal-Xiangqi leaf pilots separate sensitivity from ordering;
  finite-source kernels retain different stationary laws and rare-bridge limits.
  Do not replace the source law or infer calibrated prices from q-horizon choices.
- The inert-custody pilot repairs legacy remove_from_game execution and removes
  ghost hand credit in a proved simple no-drop/no-declaration IR subset only.
  Optional hand-weighted declaration controls exclude broader zero-hand claims;
  keys/history and default evaluation stay intact. Next: find a discriminating
  supported price diagnostic beyond trivial openings, not a generic utility proof.
- Legacy target queries preserve actual callers/work with local43.63% median
  q2wall reduction;189prospective contexts pass attack equivalence. Frozen
  paired games are trivial/censored and opening strict-inversion selection is
  empty. Native remains unaccepted. Route exact evidence via leaf_order_20261009.
'''
assert new not in s;s=s.replace(needle,needle+new,1)
s=s.replace('GEOMETRY_OCCUPANCY.md and its data/archive index.',
            'GEOMETRY_OCCUPANCY.md and its data/archive index.',1)
s=s.replace('data/geometry_occupancy_20261009.json|','data/geometry_occupancy_20261009.json; leaf_order_20261009.json|')
p.write_bytes(s.encode('utf-8'))
print('Updated three current research documents; repaired two observed mojibake ranges only.')
