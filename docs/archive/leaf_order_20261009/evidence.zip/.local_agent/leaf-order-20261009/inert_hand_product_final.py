"""Rule-aware inert-custody diagnostic, not universal hand utility.
One valid8x8 legacy rule: all drop masks false, empty promotion masks, no hand
predicates/declarations, same current R victims with different promoted bases.
Compare capture_to_hand/remove_from_game and a supplied zero-hand control.
Board transitions/legal continuations should ignore inert custody here; existing
v3 hand scaling may still rank equal-current-type captures differently.
Do not generalize to rules with drops, hand guards or hand-scoring objectives.
"""
from pathlib import Path
from dataclasses import replace
import sys,time,hashlib,json
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from conftest import make_ruleset,king_type,T
from generic_chess.core.movement import LeapAtom,RayAtom
from generic_chess.core.pieces import Piece
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import CountedEvaluator,validate_pv
from scripts.research_record import record_value,write_record
folder=Path(__file__).parent;out=folder/'inert-hand-product-final.json';assert not out.exists()
types=[king_type(),T('R',*[RayAtom(v) for v in ((1,0),(-1,0),(0,1),(0,-1))]),T('P',LeapAtom((0,1)),is_promotable=True,targets=('R',)),T('Q',*[LeapAtom(v) for v in ((1,1),(-1,1),(1,-1),(-1,-1))],is_promotable=True,targets=('R',))]
definition=make_ruleset(8,types,drop_all={t.type_id:(False,)*64 for t in types if not t.is_anchor})
rows=[[None]*8 for _ in range(8)];rows[0][0]=Piece(0,'K','K');rows[7][7]=Piece(1,'K','K');rows[3][3]=Piece(0,'R','R');rows[3][1]=Piece(1,'P','R',True);rows[3][5]=Piece(1,'Q','R',True);definition=replace(definition,initial_position=tuple(map(tuple,rows)))
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0);result=dict(scope=__doc__,complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=[]);all_children=[]
for disposition in ('capture_to_hand','remove_from_game'):
 rule=replace(definition,capture_disposition=disposition);c=compile_ruleset_for_execution(rule);s=GameSession(c);before=s.state;p,scope=build_semantic_opportunity_profile(c,config);old_hands=json.loads((folder/'inert-custody-final.json').read_bytes())['cases'][0]['hand_values'];models={'old_scale':replace(p,hand_value_by_base_type=old_hands),'product':p};assert scope['hand_policy']=='zero_proved_inert' and all(v==0 for v in p.hand_value_by_base_type.values());evs={name:Evaluator(c,profile,config) for name,profile in models.items()}
 row=dict(disposition=disposition,rules=ruleset_to_dict(rule),board_values=p.board_value_by_type,hand_values=p.hand_value_by_base_type,captures=[],calls=[]);result['cases'].append(row);children={}
 for a in s.legal_actions():
  child=apply_action(before,a,c)
  if sum(x is not None for x in child.position.board)==4:
   assert child.position.hands[0].total()==(1 if disposition=='capture_to_hand' else 0)
   replies=__import__('generic_chess.core.movegen',fromlist=['legal_actions']).legal_actions(child,c)
   row['captures'].append(dict(action=record_value(a),hands=record_value(child.position.hands),scores_owner0={name:-ev.evaluate(child) for name,ev in evs.items()},replies=record_value(replies),board=record_value(child.position.board)))
   children[str(a)]=(child,replies)
 assert len(row['captures'])==2;all_children.append((c,children));assert s.state==before
 unit={t:0 if pt.is_anchor else 1000 for t,pt in c.types_by_id.items()}
 class FixedOrder:
  def __init__(self,leaf):self.leaf=leaf
  def evaluate(self,state):return self.leaf.evaluate(state)
  def capture_order_value(self,moving,captured):return unit[captured.current_type_id]*10-unit[moving.current_type_id]//10
  def type_value(self,tid):return unit[tid]
 for model,ev in evs.items():
  for depth in (1,2):
   counted=CountedEvaluator(ev);score,action=reference_minimax(before,depth,counted,c)
   player=AlphaBetaPlayer(c,evaluator_override=FixedOrder(ev),use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False));dec=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
   assert dec.completed_depth==depth and dec.score==score;validate_pv(s,dec);assert s.state==before
   row['calls'].append(dict(model=model,depth=depth,reference=dict(score=score,action=record_value(action),scorings=counted.calls),decision=record_value(dec)))
 write_record(out,result);print(disposition,row['board_values'],row['hand_values'],[(r['scores_owner0'],r['action']) for r in row['captures']],[(r['model'],r['depth'],r['decision']['score']) for r in row['calls']],flush=True)
# Same physical board replies under both custody dispositions, all actual replies.
transitions=0
(ca,aa),(cb,bb)=all_children;assert aa.keys()==bb.keys()
for key in aa:
 a,ra=aa[key];b,rb=bb[key];assert a.position.board==b.position.board and ra==rb
 for reply in ra:
  x=apply_action(a,reply,ca);y=apply_action(b,reply,cb);transitions+=2
  assert x.position.board==y.position.board and x.terminal_status==y.terminal_status
result['actual_reply_transition_checks']=transitions;result['complete']=True;write_record(out,result)
