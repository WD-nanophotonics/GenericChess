"""All-square parity and small cost comparison on frozen actual game positions.
Two target-query algorithms, unchanged old full-map oracle. Four AB/BA blocks;
20 repetitions of the same finite query list per timing, not an unseen test.
"""
from pathlib import Path
import sys,json,time,hashlib,statistics
root=Path.cwd();sys.path[:0]=[str(root),str(Path(__file__).parent)]
from target_query import target_query
from target_membership_query import target_membership_query
from generic_chess.core.attacks import pseudo_attacks,is_square_attacked
from generic_chess.core.coordinates import index_to_square
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from scripts.research_record import record_value,write_record
folder=Path(__file__).parent;source=json.loads((folder/'paired-games.json').read_bytes());queries=[];positions=0
for case in source['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']))
 for game in case['games']:
  session=GameSession(c);states=[session.state]
  for row in game['plies']:
   if not row['complete']:break
   session.submit(next(a for a in session.legal_actions() if record_value(a)==row['decision']['action']));assert record_value(session.state)==row['after'];states.append(session.state)
  for st in states:
   positions+=1
   for owner in (0,1):
    expected=pseudo_attacks(st.position,owner,c)
    for i in range(case['size']**2):
     square=index_to_square(i,case['size']);answer=square in expected
     assert target_query(st.position,square,owner,c)==answer
     assert target_membership_query(st.position,square,owner,c)==answer
     queries.append((st.position,square,owner,c,answer))
functions=dict(old=is_square_attacked,target=target_query,membership=target_membership_query);timings={k:[] for k in functions}
for block in range(4):
 for name in (list(functions) if block%2==0 else list(reversed(functions))):
  fn=functions[name];start=time.perf_counter();truths=0
  for repeat in range(20):
   for pos,square,owner,c,answer in queries:truths+=fn(pos,square,owner,c)
  timings[name].append(time.perf_counter()-start)
  assert truths==20*sum(q[-1] for q in queries)
result=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256((folder/'paired-games.json').read_bytes()).hexdigest(),positions=positions,queries=len(queries),true_queries=sum(q[-1] for q in queries),timings=timings,medians={k:statistics.median(v) for k,v in timings.items()})
write_record(folder/'target-query-probe.json',result);print(result)
