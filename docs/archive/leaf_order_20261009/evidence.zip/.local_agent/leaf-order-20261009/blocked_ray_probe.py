"""Bounded false-query stress: one blocked four-ray actor on8/16boards.
Constructed cost cases, not population performance. Old full map remains oracle.
"""
from pathlib import Path
import sys,time,json,hashlib,statistics
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests'),str(Path(__file__).parent)]
from dataclasses import replace
from conftest import make_compiled,king_type,T
from generic_chess.core.pieces import Piece
from generic_chess.core.movement import RayAtom,LeapAtom
from generic_chess.core.transition import initial_state
from generic_chess.core.coordinates import Square
import generic_chess.core.attacks as attacks
from target_query import target_query
from target_membership_query import target_membership_query
from scripts.research_record import write_record
folder=Path(__file__).parent;ns=vars(attacks).copy();exec((folder/'old_legacy_attack_query.py').read_text(),ns);old=ns['is_square_attacked'];rows=[]
for n in (8,16):
 c=make_compiled(n,[king_type(),T('R',*[RayAtom(d) for d in ((1,0),(-1,0),(0,1),(0,-1))]),T('P',LeapAtom((1,0)))])
 for blocked in (False,True):
  board=[None]*(n*n);m=n//2;board[m*n+m]=Piece(0,'R','R');board[0]=Piece(0,'K','K');board[-1]=Piece(1,'K','K')
  if blocked:
   for df,dr in ((1,0),(-1,0),(0,1),(0,-1)):board[(m+dr)*n+m+df]=Piece(1,'P','P')
  position=replace(initial_state(c).position,board=tuple(board));target=Square(m,n-1);expected=target in attacks.pseudo_attacks(position,0,c);timings={k:[] for k in ('old','target','membership')}
  for repeat in range(4):
   funcs=dict(old=old,target=target_query,membership=target_membership_query)
   for name in (list(funcs) if repeat%2==0 else list(reversed(funcs))):
    fn=funcs[name];assert fn(position,target,0,c)==expected;start=time.perf_counter()
    answers=sum(fn(position,target,0,c) for _ in range(10000));timings[name].append(time.perf_counter()-start);assert answers==10000*expected
  rows.append(dict(size=n,blocked=blocked,expected=expected,timings=timings,medians={k:statistics.median(v) for k,v in timings.items()}));print(rows[-1])
write_record(folder/'blocked-ray-probe.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows))
