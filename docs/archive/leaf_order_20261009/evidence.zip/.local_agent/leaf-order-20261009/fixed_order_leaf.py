"""Exposed internal-Xiangqi leaf-price sensitivity with fixed unit ordering.
Unknown: can leaf prices alter a genuine preflighted exchange independently of
ordering prices? D2 q0/q2 same8192nodes/5sec, q2hard8, two cold repeats.
All dynamics disabled, Core legality, same root/TT/policy and unit ordering.
Changed moves/scores/work are sensitivity, not material or strength validation.
"""
from pathlib import Path
from dataclasses import replace
import sys,time,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv,CountedEvaluator
from scripts.research_record import record_value,write_record
folder=root/'.local_agent/leaf-order-20261009';out=folder/'fixed-order-leaf.json';assert not out.exists()
compiled=compile_ruleset_for_execution(build_xiangqi_diagnostic_ruleset());session=GameSession(compiled);before=session.state
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
profile,scope=build_semantic_opportunity_profile(compiled,config)
unit={t:0 if meta.is_anchor else 1000 for t,meta in compiled.support.type_metadata.items()}
profiles={'unit':replace(profile,board_value_by_type=unit,hand_value_by_base_type=unit),'v3':profile}
class FixedOrder:
 def __init__(self,leaf):self.leaf=leaf;self.scorings=0;self.capture_prices=0;self.type_prices=0
 def evaluate(self,state):self.scorings+=1;return self.leaf.evaluate(state)
 def capture_order_value(self,moving,captured):
  self.capture_prices+=1;return unit[captured.current_type_id]*10-unit[moving.current_type_id]//10
 def type_value(self,tid):self.type_prices+=1;return unit[tid]
record=dict(scope=__doc__,complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),root_fingerprint=compiled.ruleset_fingerprint,leaf_values={n:dict(p.board_value_by_type) for n,p in profiles.items()},ordering_values=unit,references=[],forced=[],calls=[])
write_record(out,record)
# Preflight actual H capture, not action labels or proxy geometry.
root_actions=legal_actions(before,compiled);captures=[];transitions=0
for action in root_actions:
 child=apply_action(before,action,compiled);transitions+=1
 count=lambda st:sum(p is not None and p.owner==1 and p.current_type_id=='H' for p in st.position.board)
 if count(before)-count(child)==1:captures.append((action,child))
assert len(captures)==2
record['preflight']={'root_actions':len(root_actions),'actual_transitions':transitions,'captures':record_value([a for a,c in captures])}
for name,p in profiles.items():
 leaf=Evaluator(compiled,p,config);counted=CountedEvaluator(leaf)
 start=time.perf_counter();score,action=reference_minimax(before,2,counted,compiled)
 record['references'].append(dict(leaf=name,score=score,action=record_value(action),scorings=counted.calls,seconds=time.perf_counter()-start))
 for capture,child in captures:
  counted=CountedEvaluator(leaf);value,response=reference_minimax(child,1,counted,compiled)
  record['forced'].append(dict(leaf=name,capture=record_value(capture),root_value=-value,response=record_value(response),scorings=counted.calls))
 for q in (0,2):
  signatures=[]
  for repeat in range(2):
   evaluator=FixedOrder(leaf);player=AlphaBetaPlayer(compiled,evaluator_override=evaluator,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
   decision=player.choose_action(session,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=5,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
   validate_pv(session,decision);assert session.state==before
   result=dict(leaf=name,q=q,repeat=repeat,complete=decision.completed_depth==2,decision=record_value(decision),actual_scoring_calls=evaluator.scorings,capture_price_calls=evaluator.capture_prices,type_price_calls=evaluator.type_prices)
   record['calls'].append(result);write_record(out,record)
   if result['complete'] and q==0:assert decision.score==score
   signatures.append((record_value(decision.action),decision.score,decision.completed_depth,decision.nodes,decision.qnodes))
  assert signatures[0]==signatures[1]
record['complete']=True;write_record(out,record)
print(dict(references=[(x['leaf'],x['score']) for x in record['references']],forced=[(x['leaf'],x['root_value']) for x in record['forced']],calls=[(x['leaf'],x['q'],x['decision']['score'],x['decision']['nodes'],x['decision']['qnodes'],x['complete']) for x in record['calls']]))
