"""No-drop is not a sufficient certificate of inert custody.
One existing legacy rule mechanism: a declaration reads captured base stock.
Same legal capture and board reply, same physical board under both dispositions,
but include_hands distinguishes a WIN claim from LOSS. No valuation fitting.
"""
from pathlib import Path
import sys, json, hashlib
from dataclasses import replace
root=Path.cwd(); sys.path[:0]=[str(root), str(root/'tests')]
from generic_chess.rules.schema import (ruleset_from_dict, RuleDeclaration,
    RuleDeclarationOutcomeBand, RuleWeightedMaterialMetric, RuleSpatialSelector)
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import action_from_dict
from generic_chess.core.declarations import assess_declaration
from scripts.research_record import record_value, write_record
folder=Path(__file__).parent; out=folder/'custody-declaration-final.json'; assert not out.exists()
frozen=json.loads((folder/'inert-custody-final.json').read_bytes())
base=ruleset_from_dict(frozen['cases'][0]['rules'])
claim=RuleDeclaration(declaration_id='custody_claim',owner=0,require_not_in_check=False,
    weighted_metric=RuleWeightedMaterialMetric(owner='self',compare_field='base',
        weights={'P':1,'Q':1},spatial=RuleSpatialSelector('zone',zone_squares=((0,0),)),
        include_hands=True),outcome_bands=(RuleDeclarationOutcomeBand(1,'WIN'),),
    failure_outcome='LOSS')
from generic_chess.core.actions import BoardMove
from generic_chess.core.coordinates import Square
a=frozen['cases'][0]['captures'][0]['action']
capture=BoardMove(Square(**a['from_square']),Square(**a['to_square']),a['promotion_target_id'])
result={'scope':__doc__,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':[]}
positions=[]; common_reply=None
for disposition in ('capture_to_hand','remove_from_game'):
    c=compile_ruleset_for_execution(replace(base,capture_disposition=disposition,declarations=(claim,)))
    s=GameSession(c); before=assess_declaration(s.state,c,'custody_claim')
    child=apply_action(s.state,capture,c)
    replies=legal_actions(child,c)
    if common_reply is None: common_reply=sorted(replies,key=str)[0]
    assert common_reply in replies
    after=apply_action(child,common_reply,c)
    assessment=assess_declaration(after,c,'custody_claim')
    assert before.outcome=='LOSS' and assessment.outcome==('WIN' if disposition=='capture_to_hand' else 'LOSS')
    positions.append(after.position)
    result['cases'].append(dict(disposition=disposition,before=record_value(before),
        capture=record_value(capture),reply=record_value(common_reply),after=record_value(assessment),
        hands=record_value(after.position.hands)))
assert positions[0].board==positions[1].board
result['complete']=True;write_record(out,result)
print([(r['disposition'],r['after']) for r in result['cases']])
