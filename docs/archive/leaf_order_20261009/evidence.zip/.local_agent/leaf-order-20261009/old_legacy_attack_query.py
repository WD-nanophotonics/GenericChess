def is_square_attacked(
    position: Position, square: Square, by_player: int, compiled: "CompiledRuleSet"
) -> bool:
    ensure_ruleset_match(position, compiled)
    return square in pseudo_attacks(position, by_player, compiled)
