"""Actual same-work Core q2 callers for target-query prototype.
Four frozen capped roots x two leaves x old/new x two AB/BA repeats=32calls.
D2,4096nodes/10sec,q2hard8,freshTT,fixedunitordering; no q/pruning policy edit.
Instrumentation counts actual target query calls during choose_action only.
PV replay after restoring old query, root/history must remain unchanged.
Compare every nontiming decision field and actual query count within each cell.
"""
from pathlib import Path
from dataclasses import replace
from unittest.mock import patch
import sys,json,time,hashlib
root=Path.cwd();folder=Path(__file__).parent;sys.path[:0]=[str(root),str(folder)]
from target_membership_query import target_membership_query
import generic_chess.core.attacks as attacks
import generic_chess.core.movegen as movegen
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
out=folder/'target-query-callers.json';assert not out.exists();source=json.loads((folder/'paired-games.json').read_bytes());old=attacks.is_square_attacked
record=dict(scope=__doc__,complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256((folder/'paired-games.json').read_bytes()).hexdigest(),calls=[])
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
class FixedOrder:
 def __init__(self,leaf,unit):self.leaf=leaf;self.unit=unit
 def evaluate(self,state):return self.leaf.evaluate(state)
 def capture_order_value(self,moving,captured):return self.unit[captured.current_type_id]*10-self.unit[moving.current_type_id]//10
 def type_value(self,tid):return self.unit[tid]
def signature(decision):return {k:v for k,v in record_value(decision).items() if 'seconds' not in k and not k.startswith('time_to_')}
for case in source['cases']:
 for gi,game in enumerate(case['games']):
  if game.get('censored')!='search_incomplete':continue
  c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c)
  for row in game['plies'][:-1]:s.submit(next(a for a in s.legal_actions() if record_value(a)==row['decision']['action']))
  before=s.state;history=s.history;profile,_=build_semantic_opportunity_profile(c,config);unit=case['values']['unit'];profiles={'unit':replace(profile,board_value_by_type=unit,hand_value_by_base_type=unit),'v3':profile}
  for model,p in profiles.items():
   signatures=[]
   for repeat in range(2):
    for version in (('old','target') if repeat==0 else ('target','old')):
     fn=old if version=='old' else target_membership_query;count=[0]
     def counted(*args):count[0]+=1;return fn(*args)
     ev=FixedOrder(Evaluator(c,p,config),unit);player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False))
     start=time.perf_counter()
     with patch.object(attacks,'is_square_attacked',counted),patch.object(movegen,'is_square_attacked',counted):
      decision=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=4096,max_time_seconds=10,quiescence_max_depth=2,quiescence_hard_max_depth=8))
     seconds=time.perf_counter()-start
     assert decision.completed_depth==2;validate_pv(s,decision);assert s.state==before and s.history==history
     signatures.append((signature(decision),count[0]));record['calls'].append(dict(seed=case['seed'],game=gi,leaf=model,repeat=repeat,version=version,decision=record_value(decision),actual_target_queries=count[0],seconds=seconds));write_record(out,record)
     print(case['seed'],gi,model,repeat,version,count[0],round(seconds,3),flush=True)
   assert all(sig==signatures[0] for sig in signatures)
record['complete']=True;write_record(out,record)
