"""Transfer legacy target query to a fixed fresh generated batch.
Use all181root successors from seeds100..107 for all-square old-map parity.
Actual calls on first4no-immediate-win roots100/102/104/106: unit evaluation,
fixed Core policy, fresh TT; old/product at D3q0 and D2q2hard8,4096nodes/10sec.
Matched complete cells compare every nontiming decision/work field. Caps remain
unknown, not upgraded. This is interface/cost transfer, not price validation.
"""
from pathlib import Path
from dataclasses import replace
from unittest.mock import patch
import sys,json,time,hashlib
root=Path.cwd();folder=Path(__file__).parent;sys.path[:0]=[str(root),str(root/'tests')]
import generic_chess.core.attacks as attacks
import generic_chess.core.movegen as movegen
from generic_chess.core.coordinates import index_to_square
from generic_chess.core.transition import apply_action
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from tests.product.test_rectangular_search_override import UnitEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.unfamiliar_search import validate_pv
from scripts.research_record import record_value,write_record
source=json.loads((folder/'opening-preflight.json').read_bytes());old_ns=vars(attacks).copy();exec((folder/'old_legacy_attack_query.py').read_text(),old_ns);old=old_ns['is_square_attacked'];product=attacks.is_square_attacked
out=folder/'query-transfer.json';assert not out.exists();result=dict(scope=__doc__,complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256((folder/'opening-preflight.json').read_bytes()).hexdigest(),positions=0,actual_root_transitions=0,queries=0,calls=[]);write_record(out,result)
def sig(decision):return {k:v for k,v in record_value(decision).items() if 'seconds' not in k and not k.startswith('time_to_')}
selected=[r['seed'] for r in source['cases'] if not r['immediate_wins']][:4]
for case in source['cases']:
 c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);before=s.state
 children=[apply_action(before,a,c) for a in s.legal_actions()];result['actual_root_transitions']+=len(children)
 for state in [before]+children:
  result['positions']+=1
  for owner in (0,1):
   expected=attacks.pseudo_attacks(state.position,owner,c)
   for i in range(36):
    square=index_to_square(i,6);assert product(state.position,square,owner,c)==(square in expected);result['queries']+=1
 if case['seed'] not in selected:continue
 for depth,q in ((3,0),(2,2)):
  pair=[]
  for version,fn in (('old',old),('product',product)):
   player=AlphaBetaPlayer(c,evaluator_override=UnitEvaluator(),use_native_semantic_legality=False,use_disk_cache=False,tuning=SearchTuning(use_root_tactical=False));start=time.perf_counter()
   with patch.object(attacks,'is_square_attacked',fn),patch.object(movegen,'is_square_attacked',fn):
    decision=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=10,quiescence_max_depth=q,quiescence_hard_max_depth=8 if q else 0))
   seconds=time.perf_counter()-start;validate_pv(s,decision);assert s.state==before;complete=decision.completed_depth==depth
   row=dict(seed=case['seed'],depth=depth,q=q,version=version,complete=complete,decision=record_value(decision),seconds=seconds);result['calls'].append(row);pair.append(row);write_record(out,result)
   print(case['seed'],depth,q,version,complete,decision.termination_reason,round(seconds,3),flush=True)
  if all(r['complete'] for r in pair):assert sig(pair[0]['decision'])==sig(pair[1]['decision'])
result['complete']=True;write_record(out,result)
