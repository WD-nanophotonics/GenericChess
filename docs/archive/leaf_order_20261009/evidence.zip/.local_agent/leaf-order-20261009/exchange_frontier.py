"""Frozen-rule capture/recapture diagnostic, not selected validation or WDL.
Use only frozen seeds100..107 with no immediate root win. Inspect every actual
root capture and every legal reply, retaining same-square recaptures. Fixed unit
and v3 material/control conditions; no new seeds, deeper proof or strength claim.
Stop after4096actual transitions as a cost checkpoint; report incomplete scope.
The question is whether equal-unit exchanges conceal different current-type
price contrasts. A tie split is the intended sensitivity diagnostic, not gain.
"""
from pathlib import Path
from dataclasses import replace
import sys,json,time,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.actions import action_target_square
from generic_chess.core.coordinates import square_to_index
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
folder=Path(__file__).parent;out=folder/'exchange-frontier.json';assert not out.exists()
frozen=json.loads((folder/'opening-preflight.json').read_bytes())
result=dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),complete=False,transitions=0,root_captures=0,rows=[])
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
start=time.perf_counter(); capped=False
for case in frozen['cases']:
    if case['immediate_wins']: continue
    c=compile_ruleset_for_execution(ruleset_from_dict(case['rules']));s=GameSession(c);before=s.state
    p,scope=build_semantic_opportunity_profile(c,config)
    unit={t:0 if pt.is_anchor else 1000 for t,pt in c.types_by_id.items()}
    evs={'unit':Evaluator(c,replace(p,board_value_by_type=unit,hand_value_by_base_type=unit),config),'v3':Evaluator(c,p,config)}
    bases={name:ev.evaluate(before) for name,ev in evs.items()}
    for action in s.legal_actions():
        if result['transitions']>=4096: capped=True;break
        child=apply_action(before,action,c);result['transitions']+=1
        target=action_target_square(action)
        if target is None:continue
        index=square_to_index(target,c.board_size)
        victim=before.position.board[index]
        if victim is None or victim.owner==before.position.side_to_move:continue
        result['root_captures']+=1
        if child.terminal_status.is_terminal:continue
        for reply in legal_actions(child,c):
            if result['transitions']>=4096: capped=True;break
            after=apply_action(child,reply,c);result['transitions']+=1
            if action_target_square(reply)!=target:continue
            if after.position.board[index] is None or after.position.board[index].owner!=1:continue
            delta={name:ev.evaluate(after)-bases[name] for name,ev in evs.items()}
            result['rows'].append(dict(seed=case['seed'],capture=record_value(action),reply=record_value(reply),
                victim=record_value(victim),capturer=record_value(child.position.board[index]),
                delta=delta,terminal=record_value(after.terminal_status)))
        if capped:break
    assert s.state==before
    if capped:break
result.update(complete=not capped,seconds=time.perf_counter()-start,
    equal_unit_nonzero_v3=sum(r['delta']['unit']==0 and r['delta']['v3']!=0 for r in result['rows']))
write_record(out,result)
print({k:v for k,v in result.items() if k not in ('rows','scope')})
print(result['rows'][:5])
