"""Lowered IR analysis carrier must not give inert stock representation credit.
Two preliminary interactive attempts failed before observation: unqualified test
import, then compile_semantic_ruleset correctly rejecting an empty action DSL.
This producer uses the existing public legacy lowering and typed support, not
a fabricated semantic action or production execution-route change.
"""
from pathlib import Path
import sys, hashlib
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
from tests.product.test_inert_hand_profile import definition
from generic_chess.rules.compiler import compile_ruleset_for_execution, compile_semantic_ir, _build_semantic_support
from generic_chess.rules.ir import CompiledSemanticRuleset
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from scripts.research_record import write_record
a=compile_ruleset_for_execution(definition())
b=CompiledSemanticRuleset(ir=compile_semantic_ir(a),support=_build_semantic_support(a))
p,ps=build_semantic_opportunity_profile(a,EvaluationConfig());q,qs=build_semantic_opportunity_profile(b,EvaluationConfig())
write_record(Path(__file__).with_name('inert-hand-encoding-final.json'),dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),same_fingerprint=a.ruleset_fingerprint==b.ruleset_fingerprint,board_equal=p.board_value_by_type==q.board_value_by_type,legacy_hand=p.hand_value_by_base_type,lowered_ir_hand=q.hand_value_by_base_type,legacy_scope=ps['hand_policy'],lowered_scope=qs['hand_policy'],decision='Shared typed IR no-reader predicate now agrees across equivalent lowering; no execution/identity merging.'))
print(p.hand_value_by_base_type,q.hand_value_by_base_type)

assert p == q and ps["hand_policy"] == qs["hand_policy"] == "zero_proved_inert"
