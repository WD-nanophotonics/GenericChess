"""Audit explicit v3 exclusions on frozen temporal/compound rectangles and drops.
No utility support is inferred from successful public execution. No new default.
"""
from pathlib import Path
import sys,json,zipfile,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.session.session import GameSession
from scripts.research_record import record_value,write_record
from rule_semantics_ir_fixtures import nifu_ruleset,uchifuzume_ruleset
folder=Path(__file__).parent;rows=[]
with zipfile.ZipFile('docs/archive/rect_search_20261009/effect-transfer.zip') as z:
 frozen=z.read('.local_agent/rect-search-20261009/rect-effect-transfer.json')
 cases=json.loads(frozen)['cases']
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for label,definition,frozen_case in [(c['label'],ruleset_from_dict(c['rules']),c) for c in cases]+[('nifu',nifu_ruleset(),None),('uchifuzume',uchifuzume_ruleset(),None)]:
 compiled=compile_ruleset_for_execution(definition);profile,scope=build_semantic_opportunity_profile(compiled,config)
 row=dict(label=label,board_values=profile.board_value_by_type,hand_values=profile.hand_value_by_base_type,scope=scope,drop={t:dict(freedom=p.drop_freedom_ratio,mobility=p.drop_mobility) for t,p in profile.piece_profiles.items()})
 if frozen_case:
  session=GameSession(compiled);before=session.state;ev=Evaluator(compiled,profile,config)
  action=next(a for a in session.legal_actions() if record_value(a)==frozen_case['effect']);session.submit(action)
  assert record_value(session.state)==frozen_case['after']
  row['actual_effect']=dict(action=record_value(action),before_score=ev.evaluate(before),after_owner0_score=ev.evaluate(session.state)*(-1 if session.state.position.side_to_move else 1),changed_cells=sum(a!=b for a,b in zip(before.position.board,session.state.position.board)),aux_changed=before.position.aux_state!=session.state.position.aux_state)
 rows.append(row)
write_record(folder/'scope-audit.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),frozen_transfer_sha256=hashlib.sha256(frozen).hexdigest(),rows=rows))
for r in rows:
 print(r['label'],r['board_values'],r.get('actual_effect'),[(t,len(s['included_patterns']),s['excluded_patterns']) for t,s in r['scope']['types'].items()])
