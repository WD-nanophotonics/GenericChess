"""Prospective fixed eight-rule opening preflight for targeted development.
Seeds100..107,size6, existing bilateral_random/hybrid generator and filters.
No replacement seeds. Enumerate all actual root successors; report immediate
terminal wins and pairwise ordering of unit/v3 material leaf deltas. A strict
inversion is more informative than a tie split. At most first two no-mate-in-one
strict-inversion roots qualify for a later declared comparison. If fewer than
2 exist, keep fewer; no fallback or sample extension. This deliberately exposed
selection can diagnose prices but cannot estimate population strength.
"""
from pathlib import Path
import sys,time,hashlib,json
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from dataclasses import replace
from generic_chess.generation.config import GeneratorConfig
from generic_chess.generation.generator import generate_game
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from scripts.research_record import record_value,write_record
folder=Path(__file__).parent;out=folder/'opening-preflight.json';assert not out.exists();start=time.perf_counter();result=dict(scope=__doc__,complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=[])
config=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
for seed in range(100,108):
 flags=json.loads((root/'.local_agent/rollout.json').read_bytes());assert not flags.get('user_paused') and not flags.get('stopped')
 generated=generate_game(GeneratorConfig(seed=seed,board_size=6,setup_preset='bilateral_random',allow_hybrid=True));definition=generated.ruleset;c=compile_ruleset_for_execution(definition);s=GameSession(c);before=s.state;profile,scope=build_semantic_opportunity_profile(c,config);unit={t:0 if pt.is_anchor else 1000 for t,pt in c.types_by_id.items()};profiles={'unit':replace(profile,board_value_by_type=unit,hand_value_by_base_type=unit),'v3':profile};evs={n:Evaluator(c,p,config) for n,p in profiles.items()};bases={n:ev.evaluate(before) for n,ev in evs.items()}
 row=dict(seed=seed,rules=ruleset_to_dict(definition),generation=record_value(generated.generation_report),fingerprint=c.ruleset_fingerprint,values={n:p.board_value_by_type for n,p in profiles.items()},successors=[]);result['cases'].append(row)
 for action in s.legal_actions():
  child=apply_action(before,action,c)
  row['successors'].append(dict(action=record_value(action),terminal=record_value(child.terminal_status),delta={n:-ev.evaluate(child)-bases[n] for n,ev in evs.items()}))
 assert s.state==before
 row['immediate_wins']=sum(z['terminal']['winner']==0 for z in row['successors'])
 inversions=[];splits=[]
 for i,a in enumerate(row['successors']):
  for j,b in enumerate(row['successors'][:i]):
   du=a['delta']['unit']-b['delta']['unit'];dv=a['delta']['v3']-b['delta']['v3']
   if du*dv<0:inversions.append([j,i])
   elif du==0 and dv!=0:splits.append([j,i])
 row['strict_inversions']=inversions;row['unit_tie_splits']=splits;write_record(out,result)
 print(seed,len(row['successors']),row['immediate_wins'],len(inversions),len(splits),flush=True)
result['selected_seeds']=[r['seed'] for r in result['cases'] if r['immediate_wins']==0 and r['strict_inversions']][:2];result['complete']=True;result['seconds']=time.perf_counter()-start;write_record(out,result)
print('selected',result['selected_seeds'])
