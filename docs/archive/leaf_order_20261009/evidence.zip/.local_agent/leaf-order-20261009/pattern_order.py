"""Equivalent compiled pattern ordering under default/non-dyadic density laws.
Only reverse final pattern order, preserve every event/ID/geometry/effect.
Compare event signatures, actual curves and final board/hand tables separately;
a tiny roundoff difference is not a material failure or permission to tune.
"""
from pathlib import Path
from dataclasses import replace
import sys,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/'tests')]
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from tests.product.test_rectangular_search_override import rectangular_cannon
from scripts.research_record import write_record
folder=Path(__file__).parent;rows=[]
for name,definition in [('Chess',build_western_chess_ruleset()),('Shogi',build_standard_shogi_ruleset()),('internalXi',build_xiangqi_diagnostic_ruleset()),('rectangleC',rectangular_cannon(7,5))]:
 c=compile_ruleset_for_execution(definition);reverse=replace(c,ir=replace(c.ir,patterns=tuple(reversed(c.ir.patterns))))
 for law,config in [('default',EvaluationConfig()),('non_dyadic',EvaluationConfig(density_points=(.1,.3,.7),density_weights=(.2,.3,.5)))]:
  a,sa=build_semantic_opportunity_profile(c,config);b,sb=build_semantic_opportunity_profile(reverse,config)
  assert all(sa['types'][t]['signature']==sb['types'][t]['signature'] for t in sa['types'])
  raw_delta=max(abs(sa['types'][t]['raw']-sb['types'][t]['raw']) for t in sa['types'])
  curve_delta=max(abs(x[key]-y[key]) for t in sa['types'] for x,y in zip(sa['types'][t]['curves'],sb['types'][t]['curves']) for key in ('quiet','capture','total'))
  rows.append(dict(rule=name,law=law,raw_max_delta=raw_delta,curve_max_delta=curve_delta,board_equal=a.board_value_by_type==b.board_value_by_type,hand_equal=a.hand_value_by_base_type==b.hand_value_by_base_type,profiles=[dict(board=p.board_value_by_type,hand=p.hand_value_by_base_type) for p in (a,b)]))
  print(rows[-1])
write_record(folder/'pattern-order.json',dict(scope=__doc__,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows))
