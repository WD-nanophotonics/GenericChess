from view3 import *
import pytest
from scripts.research_record import write_record
stats={}
with installed('view',stats=stats):
 result=pytest.main(['-p','no:cacheprovider','-q','tests/product/test_semantic_hand_borrow.py','tests/product/test_semantic_trial_checkpoint.py','tests/product/test_phase19b3_s4_executor.py','tests/product/test_compiled_transition_triggers.py','tests/product/test_search_semantic_checkpoint.py'])
write_record(D/'prototype-tests-v3.json',dict(exit_code=int(result),stats=stats,scope='Existing observed semantic/cancel/S4/trigger tests run with private view installed; direct child paths remain baseline. Actual view counters quantify coverage.'))
raise SystemExit(result)
