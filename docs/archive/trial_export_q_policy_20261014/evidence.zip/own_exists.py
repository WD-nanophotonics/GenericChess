from pathlib import Path
import sys,ast,contextlib
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as m
from generic_chess.core.pieces import Piece
D=Path(__file__).resolve().parent
old_sources=m._sources_by_owner_type

def own_sources(position):
 if type(position.board) is not tuple or type(position.side_to_move) is not int:return old_sources(position)
 indexed={};side=position.side_to_move
 for source,piece in enumerate(position.board):
  if piece is None:continue
  if type(piece) is not Piece or type(piece.owner) is not int or type(piece.current_type_id) is not str:return old_sources(position)
  if piece.owner==side:indexed.setdefault((piece.owner,piece.current_type_id),[]).append((source,piece))
 return {key:tuple(value) for key,value in indexed.items()}

@contextlib.contextmanager
def installed(arm):
 if arm=='baseline':yield;return
 assert arm=='own-exists'
 cls=m.SemanticEngine;old_has=cls.has_legal_action
 tree=ast.parse((ROOT/'generic_chess/core/semantic_executor.py').read_text(encoding='utf-8'))
 engine=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SemanticEngine')
 definitions=[n for n in engine.body if isinstance(n,ast.FunctionDef) and n.name in ['iter_legal_action_bindings','has_legal_action']]
 for definition in definitions:
  if definition.name=='has_legal_action':
   for n in ast.walk(definition):
    if isinstance(n,ast.Attribute) and n.attr=='iter_legal_actions':n.attr='_private_short_bindings'
 ns=dict(m.__dict__);ns['_sources_by_owner_type']=own_sources
 exec(compile(ast.fix_missing_locations(ast.Module(body=definitions,type_ignores=[])),'private_own_sources_exist','exec'),ns)
 cls._private_short_bindings=ns['iter_legal_action_bindings'];cls.has_legal_action=ns['has_legal_action']
 try:yield
 finally:cls.has_legal_action=old_has;delattr(cls,'_private_short_bindings')
