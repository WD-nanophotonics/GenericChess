from view4 import *
import time,json
from scripts.research_record import write_record
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
import random,hashlib
out=D/'fixed-v4-8192';out.mkdir(exist_ok=True)
assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(seeds=[2026102015,2026102016,2026102017,2026102018],sizes=[8,12,18,24],q=[0,4],nodes=8192,depth=6,seconds=240,orders=2,planned_calls=32,scope='exposed development; same complete Core and evaluation; baseline vs private typed transaction export view; q0 and q4 separate; nonempty generated hands; original product untouched'))
rows=[];samples=[];unavailable=[];start=time.perf_counter()
for seed,size in zip([2026102015,2026102016,2026102017,2026102018],[8,12,18,24]):
 p.rr.stopped();g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
 c0=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=c0.ir,_legacy_compiled=c0._legacy_compiled,support=c0.support)
 s=p.GameSession(c);rng=random.Random(seed+31000);walk=[]
 try:
  for _ in range(8):
   acts=sorted(s.legal_actions(),key=repr)
   if not acts or s.result.status.value!='ongoing':raise ValueError('prefix unavailable')
   a=rng.choice(acts);walk.append(record_value(a));s.submit(a)
  if s.result.status.value!='ongoing':raise ValueError('rootterminal')
 except (ValueError,RuntimeError,NotImplementedError) as exc:
  unavailable.append(dict(seed=seed,size=size,error_type=type(exc).__name__,error=str(exc),unexecuted_cells=8,resampled=False))
  write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable));continue
 ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec);ev=p.Evaluator(c,profile,ec)
 samples.append(dict(seed=seed,size=size,ruleset=json.loads(p.serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk,evaluation_config=record_value(ec),profile=record_value(profile)))
 write_record(out/'samples.json',dict(samples=samples,unavailable=unavailable))
 before=(s.state,s.to_record(),s._search_witnesses)
 for q in (0,4):
  for rep in range(2):
   for arm in (('baseline','view') if rep==0 else ('view','baseline')):
    p.rr.stopped();assert time.perf_counter()-start<3300
    t=time.perf_counter()
    player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev)
    preparation=time.perf_counter()-t;t=time.perf_counter()
    with installed(arm):
     d=player.choose_action(s,SearchLimits(max_depth=6,max_nodes=8192,max_time_seconds=240,quiescence_max_depth=q,quiescence_hard_max_depth=8))
    wall=time.perf_counter()-t;assert before==(s.state,s.to_record(),s._search_witnesses)
    child=s.state
    for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
    rows.append(dict(seed=seed,size=size,q=q,rep=rep,arm=arm,wall=wall,prepare_seconds=preparation,decision=record_value(d),full_history_restored=True,pv_core_legal=True))
    write_record(out/'rows.json',dict(complete=False,rows=rows,unavailable=unavailable))
    print(seed,size,q,rep,arm,round(wall,4),d.completed_depth,d.nodes,d.qnodes,flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,unavailable=unavailable,elapsed_seconds=time.perf_counter()-start))
