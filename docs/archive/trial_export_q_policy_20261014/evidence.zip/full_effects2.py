from view2 import *
sys.path.insert(0,str(ROOT/'tests'))
import phase19b3_s4_fixtures as f
import rule_semantics_ir_fixtures as r
from generic_chess.rules.compiler import compile_semantic_ruleset
from scripts.research_record import write_record
from collections import Counter
out=D/'full-effects-shadow-v2-final';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Observe every actual transition before S3 rejection, including auxiliary state, nested S4 reply and deferred view fallback',fixtures=['opponent_checked_perspective','nested_s4_option_b','full_child_state','multiple_replies','restricted_finish','forbidden_no_reply_drop','castling','en_passant','nifu','uchifuzume'],view_version=2,source_sha=__import__('hashlib').sha256((D/'view2.py').read_bytes()).hexdigest(),scope='finite custom mechanism fixtures, not full generated-domain proof'))
rows=[];original_transition=m.SemanticEngine._transition
for name in ['opponent_checked_perspective','nested_s4_option_b','full_child_state','multiple_replies','restricted_finish','forbidden_no_reply_drop','castling','en_passant','nifu','uchifuzume']:
 factory=getattr(f if hasattr(f,name+'_ruleset') else r,name+'_ruleset');compiled=compile_semantic_ruleset(factory());engine=m.SemanticEngine(compiled)
 if name=='opponent_checked_perspective':parents=[f.opponent_checked_reply_checked_position(engine.support),f.opponent_checked_mover_checked_position(engine.support)]
 elif hasattr(f,name+'_position'):parents=[getattr(f,name+'_position')(engine.support)]
 else:parents=[engine._initial_position()]
 for parent in parents:
  expected=tuple(engine.iter_legal_action_bindings(parent,full_frontier=True));counts=Counter()
  with installed('view',stats=counts):
   current=m.SemanticEngine._transition
   def transition(self,position,action,binding,*args,**kwargs):
    child=current(self,position,action,binding,*args,**kwargs)
    full=physical(child)
    expected_child=original_transition(self,position,action,binding)
    assert full==expected_child,(name,action,full,expected_child)
    counts['all_inner_transition_pairs']+=1
    if binding.pattern.postconditions:
     assert type(child) is Position;counts['S4_physical_children']+=1
    return child
   m.SemanticEngine._transition=transition
   try:actual=tuple(engine.iter_legal_action_bindings(parent,full_frontier=True));assert actual==expected
   finally:m.SemanticEngine._transition=current
  rows.append(dict(fixture=name,actions=len(actual),counts=dict(counts)))
  write_record(out/'rows.json',dict(complete=False,rows=rows))
write_record(out/'rows.json',dict(complete=True,rows=rows,all_inner_transition_pairs=sum(x['counts'].get('all_inner_transition_pairs',0) for x in rows)))
print('full effects',len(rows),sum(x['counts'].get('all_inner_transition_pairs',0) for x in rows))
