from view4 import *
import random,time,json,zipfile,hashlib
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
from generic_chess.core.terminal import TerminalStatus
out=D/'q-policy-witness';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does lowerq completion change immediate mating-reply exposure on the existing1455 finite witness?',seed=2026101455,size=8,prefix=8,rng_offset=13000,arms=['q4','q1'],seconds=16,orders=2,planned_calls=4,backend='forced originalCore, noNative; geometric default-v2 evaluation botharms',scope='Known exposed terminal witness, not newholdout; newpolicyq1 vsq4 and different backend/evaluation from historicalNative ordering. Do not reuse old scores or attribute to soleqdepth acrossold/new. FullCore reply enumeration after each selectedmove, no WDL/generalstrength claim.',no_defaults_changed=True))
g=p.generate_game(p.GeneratorConfig(seed=2026101455,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));src=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=src.ir,_legacy_compiled=src._legacy_compiled,support=src.support);s=p.GameSession(c);rng=random.Random(2026101455+13000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
with zipfile.ZipFile(ROOT/'docs/archive/ordinary_q_ordering_20261013/evidence.zip') as z:old=json.loads(z.read('science/forced1455/sample.json'))
assert record_value(s.state)==old['state'] and record_value(s._search_witnesses)==old['witnesses'], 'current generator/root differs from frozen1455; do not relabel'
write_record(out/'sample.json',dict(state=record_value(s.state),witnesses=record_value(s._search_witnesses),exact_frozen_sample_equal=True))
before=(s.state,s.to_record(),s._search_witnesses);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec);rows=[]
for rep in range(2):
 for arm in (['q4','q1'] if rep==0 else ['q1','q4']):
  p.rr.stopped();t=time.perf_counter();player=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev);prep=time.perf_counter()-t
  d=player.choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=max(.001,16-prep),quiescence_max_depth=(4 if arm=='q4' else 1),quiescence_hard_max_depth=8));total=time.perf_counter()-t
  assert before==(s.state,s.to_record(),s._search_witnesses);assert d.action in s.legal_actions()
  child=s.state
  for a in d.principal_variation:assert a in legal_actions(child,c);child=apply_action(child,a,c)
  after=apply_action(s.state,d.action,c);replies=tuple(legal_actions(after,c));mates=[]
  for a in replies:
   result=apply_action(after,a,c)
   if result.terminal_status.status is TerminalStatus.CHECKMATE and result.terminal_status.winner==1-s.state.position.side_to_move:mates.append(record_value(a))
  rows.append(dict(rep=rep,arm=arm,decision=record_value(d),total_caller_wall=total,prepare_seconds=prep,full_history_restored=True,pv_core_legal=True,opponent_replies=len(replies),immediate_opponent_mating_replies=mates))
  write_record(out/'rows.json',dict(complete=False,rows=rows));print(arm,rep,d.completed_depth,d.result_ordinary_qdepth,'mates',len(mates),'replies',len(replies),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows))
