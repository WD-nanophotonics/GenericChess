from view2 import *
from dataclasses import replace
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.rules.xiangqi_diagnostic import build_xiangqi_diagnostic_ruleset
from generic_chess.core.transition import initial_state
from generic_chess.core.keys import semantic_position_key
from scripts.research_record import write_record
import json,random,hashlib
out=D/'shadow-v2-final';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Actual inner S3 ephemeral work view vs exact original full child, not external-only replay',games=['western_chess','standard_shogi','xiangqi_diagnostic','generated12','generated18','generated24'],hand_cases=['empty','canonical','descending','duplicatezero','listfallback'],complete_effects=True,view_scope='full unfiltered typed parent; no S4; only own_anchor_safe invariants; check fallback physical; direct APIs untouched',source_sha=hashlib.sha256((D/'view2.py').read_bytes()).hexdigest()))
oldtrial=m.SemanticEngine._trial_child_if_s3_legal
rows=[];total=0;views=0;declines=0
for game in ['western_chess','standard_shogi','xiangqi_diagnostic','generated12','generated18','generated24']:
 if game.startswith('generated'):
  from scripts import full_q_refresh_comparison as p
  size=int(game[9:]);seed={12:2026102016,18:2026102017,24:2026102018}[size]
  g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
 else:c=compile_ruleset_for_execution(build_xiangqi_diagnostic_ruleset() if game=='xiangqi_diagnostic' else build_builtin_ruleset(game))
 root=initial_state(c).position
 for counts in [(),(('R',2),),(('R',2),('P',1)),(('R',2),('P',0),('R',1)),[]]:
  position=replace(root,hands=(Hands(counts),Hands((('P',1),('R',2)))))
  counts_local={'trials':0,'views':0,'illegal':0};stats={}
  def observer(engine,pattern,parent,action,binding,child,args,kwargs):
   global total,views,declines
   token=pending.set(False)
   try:expected=oldtrial(engine,pattern,parent,action,binding,*args,**kwargs)
   finally:pending.reset(token)
   actual=physical(child)
   assert actual==expected,(game,counts,action,actual,expected)
   if actual is not None:assert semantic_position_key(actual,engine.support,engine.ir.aux_slots)==semantic_position_key(expected,engine.support,engine.ir.aux_slots)
   counts_local['trials']+=1;total+=1
   if child is None:counts_local['illegal']+=1;declines+=1
   elif isinstance(child,m._WorkingPosition):counts_local['views']+=1;views+=1
  engine=m.semantic_engine_for(c)
  expected=tuple(engine.iter_legal_action_bindings(position,full_frontier=True))
  with installed('view',observer,stats):
   actual=tuple(engine.iter_legal_action_bindings(position,full_frontier=True))
   assert actual==expected
   if actual:
    a,b=actual[0];assert type(engine._transition(position,a,b)) is Position
  rows.append(dict(game=game,counts=counts,actions=len(actual),**counts_local,stats=stats))
  write_record(out/'rows.json',dict(complete=False,rows=rows))
write_record(out/'rows.json',dict(complete=True,rows=rows,paired_inner_trials=total,returned_views=views,illegal=declines))
print('shadow',total,views,declines,len(rows))
