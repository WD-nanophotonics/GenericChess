from view4 import *
import json,random
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.core.movegen import legal_actions
from generic_chess.core.transition import apply_action
out=D/'q-policy-witness';rows=json.loads((out/'rows.json').read_text(encoding='utf-8'))['rows']
g=p.generate_game(p.GeneratorConfig(seed=2026101455,board_size=8,setup_preset='bilateral_random',allow_hybrid=True));base=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=base.ir,_legacy_compiled=base._legacy_compiled,support=base.support);s=p.GameSession(c);rng=random.Random(2026101455+13000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
assert record_value(s.state)==json.loads((out/'sample.json').read_text(encoding='utf-8'))['state']
answers=[];seen=set()
for row in rows:
 action_record=row['decision']['action'];tag=json.dumps(action_record,sort_keys=True)
 if tag in seen:continue
 seen.add(tag);a=next(a for a in s.legal_actions() if record_value(a)==action_record);child=apply_action(s.state,a,c);replies=[]
 for reply in legal_actions(child,c):
  result=apply_action(child,reply,c)
  replies.append(dict(action=record_value(reply),terminal=record_value(result.terminal_status),ply_count=result.ply_count,history=record_value(result.history)))
 wins=[r for r in replies if r['terminal']['winner']==1-s.state.position.side_to_move]
 answers.append(dict(selected_action=action_record,child_terminal=record_value(child.terminal_status),all_legal_replies=len(replies),all_immediate_opponent_winning_terminals=wins,replies=replies))
write_record(out/'all-immediate-terminals.json',dict(complete=True,root_halfmove_limit=2,remaining_after_selected_action=1,actions=answers,scope='Complete opponent next-reply terminal enumeration including history; proves an available winningreply or absence of any immediate winningreply. Does not prove q1 root forcedwin, longterm safety or fullH-WDL. No compared evaluator/search score supplies labels.'))
print([(a['all_legal_replies'],len(a['all_immediate_opponent_winning_terminals'])) for a in answers])
