from view4 import *
import random,time,json
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
out=D/'actual-drop-kernel';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Do actual descendant legal drops have the same physical-export kernel saving as board/capture roots?',seeds=[2026102016,2026102017,2026102018],sizes=[12,18,24],capture_search=dict(nodes=1024,seconds=30,q=4,depth=6),selection='first2 actually legal S3 drops with prepared safety, no S4; no replacement if absent',repeats=2000,orders=2,scope='3 instrumented actual search calls are sample capture, not ordinary throughput;24 kernel cells expected; complete hand/aux semantics and full child equality.'))
rows=[];captures=[]
for seed,size in zip([2026102016,2026102017,2026102018],[12,18,24]):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support);s=p.GameSession(c);rng=random.Random(seed+31000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 before=(s.state,s.to_record(),s._search_witnesses);samples=[];old=m.SemanticEngine._trial_child_if_s3_legal
 def trial(self,pattern,parent,action,binding,*args,**kwargs):
  child=old(self,pattern,parent,action,binding,*args,**kwargs)
  if len(samples)<2 and child is not None and action.source is None and not pattern.postconditions and kwargs.get('safety') is not None:samples.append((self,parent,action,binding,kwargs['safety']))
  return child
 m.SemanticEngine._trial_child_if_s3_legal=trial
 ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
 try:d=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev).choose_action(s,SearchLimits(max_depth=6,max_nodes=1024,max_time_seconds=30,quiescence_max_depth=4,quiescence_hard_max_depth=8))
 finally:m.SemanticEngine._trial_child_if_s3_legal=old
 assert before==(s.state,s.to_record(),s._search_witnesses)
 captures.append(dict(seed=seed,size=size,samples=len(samples),decision=record_value(d),full_history_restored=True,positions=[dict(parent=record_value(parent),action=record_value(a),pattern_id=b.pattern.pattern_id) for e,parent,a,b,safety in samples]))
 write_record(out/'capture-rows.json',dict(complete=False,rows=captures))
 for i,(e,parent,a,b,safety) in enumerate(samples):
  expected=old(e,b.pattern,parent,a,b,safety=safety)
  for rep in range(2):
   for arm in (['baseline','view'] if rep==0 else ['view','baseline']):
    p.rr.stopped()
    with installed(arm):
     token=frontier.set([parent,None])
     try:
      fn=e._trial_child_if_s3_legal if arm=='baseline' else e._private_view_trial
      assert physical(fn(b.pattern,parent,a,b,safety=safety))==expected
      t=time.perf_counter()
      for _ in range(2000):fn(b.pattern,parent,a,b,safety=safety)
      wall=time.perf_counter()-t
     finally:frontier.reset(token)
    rows.append(dict(seed=seed,size=size,index=i,rep=rep,arm=arm,seconds=wall,repeats=2000,complete_child_equal=True));write_record(out/'rows.json',dict(complete=False,rows=rows))
write_record(out/'capture-rows.json',dict(complete=True,rows=captures));write_record(out/'rows.json',dict(complete=True,rows=rows));print('actual drop',len(captures),sum(x['samples'] for x in captures),len(rows))
