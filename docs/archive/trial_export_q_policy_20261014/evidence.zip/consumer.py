from view import *
import random,time,json
from collections import Counter
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.limits import SearchLimits
out=D/'consumer-attribution';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Disjoint actual S3 consumers: full frontier vs terminal existence vs S4 reply vs ordinary filtered routes.',seed=2026102017,board_size=18,prefix=8,rng_offset=31000,seconds=16,nodes=None,depth=12,q=4,hardq=8,scope='One actual instrumented Core search, next step begun. Counts not ordinary throughput/profilertime, no positioncache or default change. Dynamic route context is reset around each generator next; no stack walk or inferred intent from counts. Concurrent normal load allowed; instrumented counters are not throughput.'))
g=p.generate_game(p.GeneratorConfig(seed=2026102017,board_size=18,setup_preset='bilateral_random',allow_hybrid=True));cc=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);c=p.SearchMetadataAdapter(ir=cc.ir,_legacy_compiled=cc._legacy_compiled,support=cc.support)
s=p.GameSession(c);rng=random.Random(2026102017+31000)
for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
before=(s.state,s.to_record(),s._search_witnesses);ec=p.EvaluationConfig();ev=p.Evaluator(c,p.build_ruleset_profile(c,ec),ec)
import contextvars
counts=Counter();mode=contextvars.ContextVar('consumer_mode',default='direct');olditer=m.SemanticEngine.iter_legal_action_bindings;oldtrial=m.SemanticEngine._trial_child_if_s3_legal;oldterminal=m.SemanticEngine.terminal_result;oldexists=m.SemanticEngine._exists_s3_reply

def iterator(self,position,*args,**kwargs):
 inner=olditer(self,position,*args,**kwargs)
 label='full' if kwargs.get('full_frontier',False) else mode.get()
 if label=='direct':label='ordinary_or_filtered'
 while True:
  t=mode.set(label)
  try:
   try:item=next(inner)
   except StopIteration:return
  finally:mode.reset(t)
  yield item

def trials(self,pattern,*args,**kwargs):
 label=mode.get();safety=kwargs.get('safety') is not None
 counts[label+(':safety' if safety else ':no_safety')]+=1
 counts[label+':S4' if pattern.postconditions else label+':noS4']+=1
 return oldtrial(self,pattern,*args,**kwargs)

def terminal(self,*args,**kwargs):
 counts['terminal_calls']+=1;t=mode.set('terminal_exists')
 try:return oldterminal(self,*args,**kwargs)
 finally:mode.reset(t)

def exists(self,*args,**kwargs):
 counts['S4_reply_calls']+=1;t=mode.set('S4_exists')
 try:return oldexists(self,*args,**kwargs)
 finally:mode.reset(t)
m.SemanticEngine.iter_legal_action_bindings=iterator;m.SemanticEngine._trial_child_if_s3_legal=trials;m.SemanticEngine.terminal_result=terminal;m.SemanticEngine._exists_s3_reply=exists
try:
 d=AlphaBetaPlayer(c,use_disk_cache=False,use_native_semantic_legality=False,evaluator_override=ev).choose_action(s,SearchLimits(max_depth=12,max_nodes=None,max_time_seconds=16,quiescence_max_depth=4,quiescence_hard_max_depth=8))
finally:
 m.SemanticEngine.iter_legal_action_bindings=olditer;m.SemanticEngine._trial_child_if_s3_legal=oldtrial;m.SemanticEngine.terminal_result=oldterminal;m.SemanticEngine._exists_s3_reply=oldexists
assert before==(s.state,s.to_record(),s._search_witnesses)
write_record(out/'rows.json',dict(complete=True,rows=[dict(counts=dict(counts),decision=record_value(d),full_history_restored=True)]));print(dict(counts))
