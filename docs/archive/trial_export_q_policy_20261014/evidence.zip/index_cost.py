from own_exists import *
from dataclasses import replace
import time,random,json
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
out=D/'own-index-cost';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Is eager own-side source indexing actually cheaper than existing fullowner grouping for existence?',seeds=[2026102015,2026102016,2026102017,2026102018],sizes=[8,12,18,24],sides=[0,1],repeats=5000,orders=2,scope='Primitive source-index only; hypothetical side flips do not claim game-state/history equivalence; malformed inputs preserve original fallback. Wholecaller follows only if primitive supports it.'))
rows=[]
for seed,size in zip([2026102015,2026102016,2026102017,2026102018],[8,12,18,24]):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);rng=random.Random(seed+31000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 for side in (0,1):
  parent=replace(s.state.position,side_to_move=side);expected={k:v for k,v in old_sources(parent).items() if k[0]==side};assert own_sources(parent)==expected
  for rep in range(2):
   for arm in (['baseline','own-exists'] if rep==0 else ['own-exists','baseline']):
    p.rr.stopped();fn=old_sources if arm=='baseline' else own_sources;t=time.perf_counter()
    for _ in range(5000):fn(parent)
    elapsed=time.perf_counter()-t;rows.append(dict(seed=seed,size=size,side=side,rep=rep,arm=arm,seconds=elapsed,repeats=5000,own_index_equal=True))
write_record(out/'rows.json',dict(complete=True,rows=rows))
pairs=[]
for b in rows:
 if b['arm']!='baseline':continue
 c=next(x for x in rows if x['arm']=='own-exists' and all(x[k]==b[k] for k in ['seed','size','side','rep']))
 pairs.append(dict(seed=b['seed'],size=b['size'],side=b['side'],rep=b['rep'],ratio=c['seconds']/b['seconds']))
write_record(out/'analysis.json',dict(pairs=pairs,decision='wholecaller only if primitive supports changed consumer',scope='same finite source index outputs; ordinary load, no speed/strength/general gain claim'))
print('index',len(rows),min(x['ratio'] for x in pairs),max(x['ratio'] for x in pairs))
