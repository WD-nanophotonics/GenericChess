from view import *
from dataclasses import replace
import importlib.util,json
from scripts.research_record import write_record
spec=importlib.util.spec_from_file_location('hand_cases',ROOT/'tests/product/test_semantic_hand_borrow.py');cases=importlib.util.module_from_spec(spec);spec.loader.exec_module(cases)
out=D/'lifecycle';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Required faults, noncanonical inputs, reentrant direct API and S4 fallback under actual full-frontier candidate',faults=['RuntimeError','ValueError','BaseException'],ordered_capture='promoted base capture -> consume -> move',no_product_changes=True))
rows=[]
for arm in ['baseline','view']:
 for fault_cls in [RuntimeError,ValueError,BaseException]:
  engine,parent,action,binding=cases.ordered_capture();pattern=replace(binding.pattern,invariants=(),postconditions=());binding=replace(binding,pattern=pattern)
  oldc=m.SemanticEngine._iter_candidates;olde=m._apply_effect;captured=[False];fault=fault_cls('actual caller fault after hand capture')
  def candidates(self,pat,pos,*args,**kw):
   if pos is parent and pat.pattern_id==pattern.pattern_id:yield action,binding
  def effect(e,*args):
   olde(e,*args)
   if e.kind=='remove':captured[0]=True
  def checkpoint():
   if captured[0]:raise fault
  m.SemanticEngine._iter_candidates=candidates;m._apply_effect=effect
  try:
   with installed(arm):
    try:tuple(engine.iter_legal_action_bindings(parent,checkpoint=checkpoint,full_frontier=True))
    except BaseException as exc:assert exc is fault
    else:raise AssertionError('fault swallowed')
   assert parent.hands==(Hands(),Hands())
  finally:m.SemanticEngine._iter_candidates=oldc;m._apply_effect=olde
  rows.append(dict(arm=arm,control='fault_after_actual_hand_credit',exception=fault_cls.__name__,same_exception=True))
 # An injected complete ordered action must execute all effects even when no invariant consumes the physical child.
 engine,parent,action,binding=cases.ordered_capture();pattern=replace(binding.pattern,invariants=(),postconditions=());binding=replace(binding,pattern=pattern)
 expected=engine._transition(parent,action,binding);originalc=m.SemanticEngine._iter_candidates;seen=[];nested=[False];checkpoints=[0]
 def candidates(self,pat,pos,*args,**kw):
  if pos is parent and pat.pattern_id==pattern.pattern_id:yield action,binding
 def observe(self,pat,pos,act,bind,child,args,kwargs):
  if child is not None:
   assert (child.materialize() if isinstance(child,TrialView) else child)==expected
   seen.append(isinstance(child,TrialView))
 def checkpoint():
  checkpoints[0]+=1
  if not nested[0]:
   nested[0]=True
   assert type(engine._transition(parent,action,binding)) is Position
   inner=tuple(engine.iter_legal_action_bindings(parent,full_frontier=True));assert len(inner)==1
 m.SemanticEngine._iter_candidates=candidates
 try:
  with installed(arm,observe):
   pairs=tuple(engine.iter_legal_action_bindings(parent,checkpoint=checkpoint,full_frontier=True));assert len(pairs)==1
   assert type(engine._transition(parent,action,binding)) is Position
  assert active.get() is False and pending.get() is False and frontier.get() is None
 finally:m.SemanticEngine._iter_candidates=originalc
 rows.append(dict(arm=arm,control='reentrant_complete_effects_direct_api',checkpoint_calls=checkpoints[0],view_observations=seen))
 # Invalid falsy inputs stay on original path, retain TypeError rather than normalize to empty.
 for bad in [None,0,False]:
  engine,parent,action,binding=cases.quiet();parent=replace(parent,hands=(Hands(bad),Hands()))
  with installed(arm):
   try:tuple(engine.iter_legal_action_bindings(parent,full_frontier=True))
   except TypeError:pass
   else:raise AssertionError('bad hand accepted')
  rows.append(dict(arm=arm,control='invalid_falsy_fallback',value=bad,TypeError_preserved=True))
write_record(out/'rows.json',dict(complete=True,rows=rows))
assert [r['checkpoint_calls'] for r in rows if 'checkpoint_calls' in r]==[16,16] or len(set(r['checkpoint_calls'] for r in rows if 'checkpoint_calls' in r))==1
print('lifecycle',len(rows),[r for r in rows if 'checkpoint_calls' in r])
