import sys
from view2 import typed,D,ROOT,m,Position,contextlib,contextvars,ast
from generic_chess.core.position import Hands
frontier=contextvars.ContextVar('private_factory_frontier',default=None)
active=contextvars.ContextVar('compat_unused',default=False)
pending=contextvars.ContextVar('compat_unused2',default=False)
ORIGINAL_EXPORT=m._WorkingPosition.to_position
class ViewWork(m._WorkingPosition):
 def to_position(self,aux,fingerprint):
  self._trial_aux=aux;self._trial_fingerprint=fingerprint
  return self
class TrackedViewWork(ViewWork):
 def __init__(self,position,support,written):
  super().__init__(position,support);self.written=written
 def set_piece(self,idx,piece):
  super().set_piece(idx,piece);self.written.add(idx)
def physical(child):
 return ORIGINAL_EXPORT(child,child._trial_aux,child._trial_fingerprint) if isinstance(child,ViewWork) else child
@contextlib.contextmanager
def installed(arm,observer=None,stats=None):
 if arm=='baseline':yield;return
 assert arm=='view'
 cls=m.SemanticEngine;old_iter=cls.iter_legal_action_bindings;old_trial=cls._trial_child_if_s3_legal;old_check=cls.in_check
 tree=ast.parse((ROOT/'generic_chess/core/semantic_executor.py').read_text(encoding='utf-8'))
 engine_ast=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SemanticEngine')
 wanted=['iter_legal_action_bindings','_trial_child_if_s3_legal','_transition']
 definitions=[n for n in engine_ast.body if isinstance(n,ast.FunctionDef) and n.name in wanted]
 for definition in definitions:
  if definition.name=='iter_legal_action_bindings':
   for n in ast.walk(definition):
    if isinstance(n,ast.Attribute) and n.attr=='_trial_child_if_s3_legal':n.attr='_private_view_trial'
  elif definition.name=='_trial_child_if_s3_legal':
   for n in ast.walk(definition):
    if isinstance(n,ast.Attribute) and n.attr=='_transition':n.attr='_private_view_transition'
    elif isinstance(n,ast.Attribute) and n.attr=='in_check':n.attr='_private_view_check'
  else:
   for n in ast.walk(definition):
    if isinstance(n,ast.Name) and n.id=='_WorkingPosition':n.id='ViewWork'
    elif isinstance(n,ast.Name) and n.id=='_TrackedWorkingPosition':n.id='TrackedViewWork'
 namespace=dict(m.__dict__);namespace.update(ViewWork=ViewWork,TrackedViewWork=TrackedViewWork)
 exec(compile(ast.fix_missing_locations(ast.Module(body=definitions,type_ignores=[])),'private_complete_transition_factory','exec'),namespace)
 private_trial=namespace['_trial_child_if_s3_legal'];source_iter=namespace['iter_legal_action_bindings']
 def check(self,position,*args,**kwargs):
  if isinstance(position,ViewWork):
   if stats is not None:stats['materialized_for_check']=stats.get('materialized_for_check',0)+1
   position=physical(position)
  return old_check(self,position,*args,**kwargs)
 def trial(self,pattern,position,action,binding,*args,**kwargs):
  holder=frontier.get()
  eligible=holder is not None and holder[0] is position and not pattern.postconditions and all(i.kind=='own_anchor_safe' for i in pattern.invariants)
  if eligible:
   if holder[1] is None:holder[1]=typed(position,self.support)
   eligible=holder[1] and (action.promotion_target_id is None or type(action.promotion_target_id) is str) and all(e.piece_type_ref is None or e.piece_type_ref.type_id is None or type(e.piece_type_ref.type_id) is str for e in pattern.effects)
  child=(private_trial if eligible else old_trial)(self,pattern,position,action,binding,*args,**kwargs)
  if stats is not None:stats['trial_factory' if eligible else 'trial_physical_fallback']=stats.get('trial_factory' if eligible else 'trial_physical_fallback',0)+1
  if observer is not None:observer(self,pattern,position,action,binding,child,args,kwargs)
  return child
 def iterate(self,position,*args,**kwargs):
  inner=source_iter(self,position,*args,**kwargs)
  full=kwargs.get('full_frontier',False) and kwargs.get('source') is None and kwargs.get('target') is None
  holder=[position,None] if full else None
  while True:
   token=frontier.set(holder)
   try:
    try:item=next(inner)
    except StopIteration:return
   finally:frontier.reset(token)
   yield item
 cls._private_view_trial=trial;cls._private_view_transition=namespace['_transition'];cls._private_view_check=check;cls.iter_legal_action_bindings=iterate
 try:yield
 finally:
  cls.iter_legal_action_bindings=old_iter
  for name in ('_private_view_trial','_private_view_transition','_private_view_check'):delattr(cls,name)
