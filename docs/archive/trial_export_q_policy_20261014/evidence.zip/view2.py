from pathlib import Path
import sys,contextlib,contextvars,ast
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.core import semantic_executor as m
from generic_chess.core.position import Position,Hands
from generic_chess.core.pieces import Piece
D=Path(__file__).resolve().parent
frontier=contextvars.ContextVar('private_export_frontier',default=None)
active=contextvars.ContextVar('private_trial_export',default=False)
pending=contextvars.ContextVar('private_trial_call',default=False)
ORIGINAL_EXPORT=m._WorkingPosition.to_position
class TrialView:
 __slots__=('work','board','hands','side_to_move','ruleset_fingerprint','aux_state','board_width','board_height','_position')
 def __init__(self,work,aux,fingerprint):
  self.work=work;self.board=work.board
  self.hands=(Hands(tuple(sorted(work.hands[0].items()))),Hands(tuple(sorted(work.hands[1].items()))))
  self.side_to_move=work.side;self.ruleset_fingerprint=fingerprint;self.aux_state=aux
  self.board_width=work.shape.width if work.shape.width!=work.shape.height else None
  self.board_height=work.shape.height if work.shape.width!=work.shape.height else None
  self._position=None
 def materialize(self):
  if self._position is None:
   self._position=Position(tuple(self.board),self.hands,self.side_to_move,self.ruleset_fingerprint,self.aux_state,self.board_width,self.board_height)
  return self._position

def typed(position,support):
 if type(position) is not Position or type(position.board) is not tuple or len(position.board)!=support.board_shape.area or type(position.side_to_move) is not int or position.side_to_move not in (0,1):return False
 if any(p is not None and (type(p) is not Piece or type(p.owner) is not int or p.owner not in (0,1) or type(p.base_type_id) is not str or type(p.current_type_id) is not str or type(p.promoted) is not bool) for p in position.board):return False
 if type(position.hands) is not tuple or len(position.hands)!=2:return False
 if any(type(h) is not Hands or type(h.counts) is not tuple or any(type(v) is not tuple or len(v)!=2 or type(v[0]) is not str or type(v[1]) is not int for v in h.counts) for h in position.hands):return False
 # Original aux dict/sort and all transitions still execute without any skip.
 return True

@contextlib.contextmanager
def installed(arm,observer=None,stats=None):
 if arm=='baseline':yield;return
 assert arm=='view'
 cls=m.SemanticEngine;old_iter=cls.iter_legal_action_bindings;old_trial=cls._trial_child_if_s3_legal;old_check=cls.in_check;old_transition=cls._transition
 old_export=m._WorkingPosition.to_position;old_init=m._WorkingPosition.__init__
 tree=ast.parse((ROOT/'generic_chess/core/semantic_executor.py').read_text(encoding='utf-8'))
 engine_class=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SemanticEngine')
 iterator_ast=next(n for n in engine_class.body if isinstance(n,ast.FunctionDef) and n.name=='iter_legal_action_bindings')
 for n in ast.walk(iterator_ast):
  if isinstance(n,ast.Attribute) and n.attr=='_trial_child_if_s3_legal':n.attr='_private_view_trial'
 namespace=dict(m.__dict__)
 exec(compile(ast.fix_missing_locations(ast.Module(body=[iterator_ast],type_ignores=[])),'private_full_frontier_view','exec'),namespace)
 source_iter=namespace['iter_legal_action_bindings']
 def init(work,position,support):
  old_init(work,position,support)
  holder=active.get()
  if holder and holder[0] is None:holder[0]=work
 def export(work,aux,fingerprint):
  holder=active.get()
  if holder and holder[0] is work:
   if stats is not None:stats['view_exports']=stats.get('view_exports',0)+1
   work._trial_aux=aux;work._trial_fingerprint=fingerprint
   return work
  return old_export(work,aux,fingerprint)
 def check(self,position,*args,**kwargs):
  if isinstance(position,m._WorkingPosition):
   if stats is not None:stats['materialized_for_check']=stats.get('materialized_for_check',0)+1
   position=ORIGINAL_EXPORT(position,position._trial_aux,position._trial_fingerprint)
  return old_check(self,position,*args,**kwargs)
 def trial(self,pattern,position,action,binding,*args,**kwargs):
  holder=frontier.get()
  eligible=holder is not None and holder[0] is position and not pattern.postconditions and all(i.kind=='own_anchor_safe' for i in pattern.invariants)
  if eligible:
   if holder[1] is None:holder[1]=typed(position,self.support)
   eligible=holder[1] and (action.promotion_target_id is None or type(action.promotion_target_id) is str) and all(e.piece_type_ref is None or e.piece_type_ref.type_id is None or type(e.piece_type_ref.type_id) is str for e in pattern.effects)
  token=pending.set(bool(eligible))
  try:child=old_trial(self,pattern,position,action,binding,*args,**kwargs)
  finally:pending.reset(token)
  if observer is not None:observer(self,pattern,position,action,binding,child,args,kwargs)
  return child
 def transition(self,position,action,binding,*args,**kwargs):
  consume=pending.set(False);token=active.set([None] if consume.old_value is not contextvars.Token.MISSING and consume.old_value else False)
  try:return old_transition(self,position,action,binding,*args,**kwargs)
  finally:active.reset(token);pending.reset(consume)
 def iterate(self,position,*args,**kwargs):
  inner=source_iter(self,position,*args,**kwargs)
  full=kwargs.get('full_frontier',False) and kwargs.get('source') is None and kwargs.get('target') is None
  holder=[position,None] if full else None
  while True:
   token=frontier.set(holder)
   try:
    try:item=next(inner)
    except StopIteration:return
   finally:frontier.reset(token)
   yield item
 cls.iter_legal_action_bindings=iterate;cls._private_view_trial=trial;cls.in_check=check;cls._transition=transition;m._WorkingPosition.to_position=export;m._WorkingPosition.__init__=init
 try:yield
 finally:
  cls.iter_legal_action_bindings=old_iter;delattr(cls,'_private_view_trial');cls.in_check=old_check;cls._transition=old_transition;m._WorkingPosition.to_position=old_export;m._WorkingPosition.__init__=old_init

# Typed no-S4 transaction only: no mutable work escapes the internal full-frontier iterator.
def physical(child):
 if isinstance(child,m._WorkingPosition):return ORIGINAL_EXPORT(child,child._trial_aux,child._trial_fingerprint)
 return child
