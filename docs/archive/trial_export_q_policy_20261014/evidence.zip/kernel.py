from view4 import *
import random,time,json,hashlib
from scripts import full_q_refresh_comparison as p
from scripts.research_record import write_record,record_value
out=D/'trial-kernel-cost';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Is physical export kernel saving real but cancelled by full caller dispatch?',seeds=[2026102016,2026102017,2026102018],sizes=[12,18,24],prefix=8,rng_offset=31000,cases='first2 legal no-S4 bindings in each actual drop/capture/board category; no resampling',repeats=2000,orders=2,total_ceiling_seconds=240,scope='S3 kernel with same prepared safety; complete effects and required checks; no S4 skipped from whole search. Kernel results cannot establish caller gain. Sources/malformed/direct-callback qualifiers separate.'))
rows=[];start=time.perf_counter()
for seed,size in zip([2026102016,2026102017,2026102018],[12,18,24]):
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True));c=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset);s=p.GameSession(c);rng=random.Random(seed+31000)
 for _ in range(8):s.submit(rng.choice(sorted(s.legal_actions(),key=repr)))
 e=m.semantic_engine_for(c);parent=s.state.position;safety=e._own_anchor_safety(parent,m._sources_by_owner_type(parent),None)
 chosen={k:[] for k in ['drop','capture','board']}
 for a,b in e.iter_legal_action_bindings(parent,full_frontier=True):
  if b.pattern.postconditions:continue
  key='drop' if a.source is None else 'capture' if any(x.kind=='remove' for x in b.pattern.effects) else 'board'
  if len(chosen[key])<2:chosen[key].append((a,b))
 write_record(out/(str(size)+'-cases.json'),dict(seed=seed,size=size,state=record_value(s.state),cases=[dict(category=k,action=record_value(a),pattern_id=b.pattern.pattern_id) for k,v in chosen.items() for a,b in v]))
 for key,cases in chosen.items():
  for index,(a,b) in enumerate(cases):
   expected=e._trial_child_if_s3_legal(b.pattern,parent,a,b,safety=safety)
   for rep in range(2):
    for arm in (['baseline','view'] if rep==0 else ['view','baseline']):
     p.rr.stopped();assert time.perf_counter()-start<240
     with installed(arm):
      token=frontier.set([parent,None])
      try:
       fn=e._trial_child_if_s3_legal if arm=='baseline' else e._private_view_trial
       actual=fn(b.pattern,parent,a,b,safety=safety);assert physical(actual)==expected
       t=time.perf_counter()
       for _ in range(2000):fn(b.pattern,parent,a,b,safety=safety)
       wall=time.perf_counter()-t
      finally:frontier.reset(token)
     rows.append(dict(seed=seed,size=size,category=key,index=index,rep=rep,arm=arm,repeats=2000,seconds=wall,complete_child_equal=True))
     write_record(out/'rows.json',dict(complete=False,rows=rows))
write_record(out/'rows.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start));print('kernel cells',len(rows),round(time.perf_counter()-start,3))
