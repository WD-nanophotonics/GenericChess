"""Same legacy atoms, different semantic captures: explicit price sensitivity."""
import sys,json,time,hashlib,importlib.util
from pathlib import Path
from dataclasses import replace
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from rule_semantics_ir_fixtures import cannon_ruleset
from generic_chess.core.pieces import Piece,PieceType
from generic_chess.core.movement import RayAtom
from generic_chess.rules.schema import ruleset_to_dict,ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from scripts.unfamiliar_search import run_rule
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'cannon-mixture.json';assert not out.exists();start=time.perf_counter();base=cannon_ruleset();atoms=tuple(RayAtom(d) for d in ((1,0),(-1,0),(0,1),(0,-1)))
board=[[None]*8 for _ in range(8)]
for owner,tid,file,rank in ((0,'K',0,0),(1,'K',7,7),(0,'C',3,3),(0,'R',3,4),(0,'R',5,2),(1,'R',3,5),(1,'C',5,5),(1,'R',4,5)):board[rank][file]=Piece(owner,tid,tid)
definition=replace(base,piece_types=base.piece_types+(PieceType('R','R',atoms),),drop_allowed={**base.drop_allowed,'R':((False,)*64,(False,)*64)},initial_position=tuple(tuple(x) for x in board));cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0,hand_weight=0)
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration='One predeclared8entity cannon/rook familiar-mechanic mixture, two counterpart recapture opportunities. Both types have identical legacy orthogonal rays; actual semantic cannon capture requires exactly one screen. Same static-only config and hand_weight0 isolates board values; legal captured hands/drop rules remain real and unchanged, no full custody valuation. Compare old legacy and optional v1 projection in the existing run_rule, depth2,4096nodes/5sec,2cold repeats per plain/public. Full Core static minimax and isolated legal capture continuations; table-induced sensitivity only, not WDL, true material reference or playing improvement. Type-ID alias is a numerical invariance check, not a new holdout.',definition=ruleset_to_dict(definition),controls=[],isolated_captures=[])
write_record(out,r)
c=compile_ruleset_for_execution(definition);session=GameSession(c);profiles={'baseline':build_ruleset_profile(c,cfg),'candidate':build_semantic_opportunity_profile(c,cfg)[0]}
for label,prof in profiles.items():
 ev=Evaluator(c,prof,cfg)
 for action in session.legal_actions():
  v=record_value(action)
  if (v.get('from_square'),v.get('to_square')) not in (({'file':3,'rank':3},{'file':3,'rank':5}),({'file':5,'rank':2},{'file':5,'rank':5})):continue
  child=apply_action(session.state,action,c);score,_=reference_minimax(child,1,ev,c);r['isolated_captures'].append(dict(control=label,action=v,own_two_ply_value=-score))
 filename='cannon-mixture-'+label+'.json';report=run_rule(p/filename,ruleset_to_dict(definition),depth=2,semantic_candidate=label=='candidate',evaluation_config=cfg)
 r['controls'].append(dict(label=label,path=filename,sha256=hashlib.sha256((p/filename).read_bytes()).hexdigest(),values=report['board_values'],reference=report['reference'],repeat_equal=report['repeat_equal'],calls=[dict(control=x['control'],complete=x['complete'],reference_equal=x['reference_score_equal'],decision=x['decision']) for x in report['searches']]));write_record(out,r)
def rename(v):
 if isinstance(v,dict):return {('Z' if k=='C' else k):rename(x) for k,x in v.items()}
 if isinstance(v,list):return [rename(x) for x in v]
 return 'Z' if v=='C' else v
alias=compile_ruleset_for_execution(ruleset_from_dict(rename(ruleset_to_dict(definition))));other,scope=build_semantic_opportunity_profile(alias,cfg);prof=profiles['candidate'];assert {('Z' if k=='C' else k):v for k,v in prof.board_value_by_type.items()}==other.board_value_by_type
score,action=reference_minimax(GameSession(alias).state,2,Evaluator(alias,other,cfg),alias);assert score==r['controls'][1]['reference']['score'];r['alias']=dict(values=dict(other.board_value_by_type),score=score,numerical_equal=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print(r['isolated_captures'],[(x['label'],x['values'],x['reference']['score']) for x in r['controls']],flush=True)
