"""Predeclared new layouts separate frozen table and attack-map sensitivity."""
import sys,json,time,hashlib,random
from pathlib import Path
from dataclasses import replace
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict,ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.transition import apply_action
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'layout-cohort.json';assert not out.exists()
source=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json'
base=ruleset_from_dict(json.loads(source.read_bytes())['definition'])
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'declaration':'Before outcomes:12attempts seed202610081000..1011; fixed anchors0,0 and7,7,6same original C/R identities at distinct uniform inner6x6 squares. Compile with existing product safety validation; reject failures without replacement. All accepted layouts, including any immediate-win roots, retained and labeled. Cross frozen legacy/candidate static tables xlegacy/semantic Native maps xstatic/default dynamic2,5 xdepth2/3. Promotion/hand0, coldTT/order/root-tacticaloff/q0,4096nodes/2sec each,600sec batch checkpoint; equal budgets, capped depth unknown. All legal PVs checked. No search output selects population/prices/weights; asks whether map-confounding and price sensitivity persist beyond toy root, not which table is stronger. Native attack construction mode independent of Native legality provider.',
 'cases':[]}
start=time.perf_counter();write_record(out,r)
try:
 for seed in range(202610081000,202610081012):
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  cells=random.Random(seed).sample([(x,y) for x in range(1,7) for y in range(1,7)],6)
  board=[[None]*8 for _ in range(8)];board[0][0]=Piece(0,'K','K');board[7][7]=Piece(1,'K','K')
  for (owner,tid),(x,y) in zip(((0,'C'),(0,'R'),(0,'R'),(1,'R'),(1,'C'),(1,'R')),cells):board[y][x]=Piece(owner,tid,tid)
  definition=replace(base,initial_position=tuple(tuple(row) for row in board))
  item={'seed':seed,'definition':ruleset_to_dict(definition),'searches':[]};r['cases'].append(item)
  try:c=compile_ruleset_for_execution(definition);s=GameSession(c)
  except ValueError as exc:
   item.update(accepted=False,rejection=str(exc));write_record(out,r);print(seed,'rejected',str(exc),flush=True);continue
  item['accepted']=True;item['opening_actions']=len(s.legal_actions())
  item['immediate_wins']=[record_value(a) for a in s.legal_actions() if (lambda t:t.is_terminal and t.winner==0)(apply_action(s.state,a,c).terminal_status)]
  for dynamic in (False,True):
   cfg=EvaluationConfig(dynamic_mobility_weight=2 if dynamic else 0,anchor_escape_weight=5 if dynamic else 0,promotion_potential_weight=0,hand_weight=0)
   profiles=[build_ruleset_profile(c,cfg),build_semantic_opportunity_profile(c,cfg)[0]]
   item['prices']=[dict(x.board_value_by_type) for x in profiles]
   for table,profile in enumerate(profiles):
    for authority in ('legacy','semantic'):
     ev=Evaluator(c,profile,cfg) if authority=='legacy' else SemanticAttackEvaluator(c,profile,cfg,backend='native')
     for depth in (2,3):
      assert time.perf_counter()-start<600,'cohort cost checkpoint'
      player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False))
      t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-t
      validate_pv(s,d)
      item['searches'].append({'dynamic':dynamic,'table':table,'authority':authority,'depth':depth,'seconds':elapsed,'decision':record_value(d)})
     write_record(out,r)
  print(seed,'accepted',len(item['searches']),'complete',sum(x['decision']['completed_depth']==x['depth'] for x in item['searches']),flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
