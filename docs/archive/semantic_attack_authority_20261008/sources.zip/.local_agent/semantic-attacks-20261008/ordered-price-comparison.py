"""Fixed semantic map/search conditions; separate score and ordering tables."""
import sys,json,time,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'ordered-price-comparison.json';assert not out.exists()
source=p/'layout-cohort.json';cohort=json.loads(source.read_bytes());ablation=json.loads((p/'search-ablation.json').read_bytes())
class FixedOrderingEvaluator(SemanticAttackEvaluator):
 def __init__(self,c,profile,cfg,ordering):
  super().__init__(c,profile,cfg,backend='native');self.ordering=ordering
 def capture_order_value(self,moving,captured):return self.ordering.capture_order_value(moving,captured)
 def type_value(self,tid):return self.ordering.type_value(tid)
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'declaration':'Adaptive development followup declared before new outcomes:ALL12original layouts, fixed Native semantic attacks, dynamic2/5,hand/promotion0,TT/orderon/root-tacticaloff/q0,4096nodes/2sec,depth3,freshplayers. Three controls perroot:oldtable/oldorder,candidatetable/oldorder,candidatetable/candidateorder. Total36calls,180sec batchcheckpoint. Static ordering prices separated from leaf prices; TT/history updates may naturally differ with scores under identical policy. Completed candidate controls must agree on score, legal PV always checked. Oldtable output must reproduce prior ablation where complete. Incomplete depths unknown, no price selection/strength claim.', 'cases':[]}
start=time.perf_counter();write_record(out,r)
try:
 for item in cohort['cases']:
  if not item['accepted']:continue
  c=compile_ruleset_for_execution(ruleset_from_dict(item['definition']));s=GameSession(c)
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0)
  profiles=[build_ruleset_profile(c,cfg),build_semantic_opportunity_profile(c,cfg)[0]]
  order=Evaluator(c,profiles[0],cfg);case={'seed':item['seed'],'searches':[]};r['cases'].append(case)
  for label,table,own_order in (('old',0,False),('candidate-fixed-order',1,False),('candidate-own-order',1,True)):
   assert time.perf_counter()-start<180,'comparison cost checkpoint'
   assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
   ev=SemanticAttackEvaluator(c,profiles[table],cfg,backend='native') if own_order else FixedOrderingEvaluator(c,profiles[table],cfg,order)
   player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=True,use_ordering=True,tuning=SearchTuning(use_root_tactical=False))
   t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=3,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-t
   validate_pv(s,d);row={'label':label,'seconds':elapsed,'decision':record_value(d)};case['searches'].append(row)
   if label=='old' and d.completed_depth==3:
    prior=next(x['decision'] for a in ablation['cases'] if a['seed']==item['seed'] for x in a['searches'] if x['tt'] and x['order'] and x['depth']==3)
    assert all(row['decision'][k]==prior[k] for k in ('action','score','nodes','completed_depth','principal_variation'))
   write_record(out,r)
  ca,cb=case['searches'][1:]
  if ca['decision']['completed_depth']==cb['decision']['completed_depth']==3:assert ca['decision']['score']==cb['decision']['score']
  print(item['seed'],[(x['label'],x['decision']['completed_depth'],x['decision']['score'],x['decision']['nodes']) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
