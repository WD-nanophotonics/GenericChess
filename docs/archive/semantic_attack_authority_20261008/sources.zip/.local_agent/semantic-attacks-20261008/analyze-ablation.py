import sys,json,hashlib,statistics
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.research_record import write_record
p=Path(__file__).parent;source=p/'search-ablation.json';r=json.loads(source.read_bytes());assert r['complete']
result={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'calls':96,'settings':[], 'paired_ordering_nodes':[],
 'qualification':'One postdeclared cohort at same4096nodes/2sec; cold players, fixed old static table and Native semantic dynamic maps. Completed-depth scores agree wherever comparable; selected tie actions may differ. The capped records stay unknown, not WDL/strength evidence or a universal speed/TT-dominance claim.'}
for tt,order in ((False,False),(True,False),(False,True),(True,True)):
 for depth in (3,4):
  rows=[x for c in r['cases'] for x in c['searches'] if (x['tt'],x['order'],x['depth'])==(tt,order,depth)]
  complete=[x for x in rows if x['decision']['completed_depth']==depth]
  result['settings'].append({'tt':tt,'order':order,'depth':depth,'calls':len(rows),'complete':len(complete),
   'total_seconds':sum(x['seconds'] for x in rows),'nodes_completed_median':statistics.median(x['decision']['nodes'] for x in complete) if complete else None,
   'native_fallbacks':sum(x['decision']['native_legality_fallbacks'] for x in rows)})
for case in r['cases']:
 cells={(x['tt'],x['order'],x['depth']):x for x in case['searches']}
 a,b=(cells[tt,True,3]['decision'] for tt in (False,True));assert a['completed_depth']==b['completed_depth']==3;assert a['score']==b['score']
 result['paired_ordering_nodes'].append({'seed':case['seed'],'ordering_only':a['nodes'],'tt_and_ordering':b['nodes'],'ratio':b['nodes']/a['nodes']})
result['tt_ordering_depth3_node_ratio_median']=statistics.median(x['ratio'] for x in result['paired_ordering_nodes'])
write_record(p/'search-ablation-analysis.json',result);print(result['settings']);print('TT/order paired ratio',result['tt_ordering_depth3_node_ratio_median'])
