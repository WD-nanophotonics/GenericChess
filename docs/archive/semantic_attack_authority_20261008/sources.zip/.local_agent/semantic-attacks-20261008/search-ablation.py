"""Same new semantic layouts, fixed table/evaluator, existing search switches."""
import sys,json,time,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'search-ablation.json';assert not out.exists()
source=p/'layout-cohort.json';cohort=json.loads(source.read_bytes());assert cohort['complete']
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'declaration':'Postdeclared search-cost followup on ALL12frozen prospective layouts, no acceptance re-selection. Fixed old staticC/R1000/1000, semantic Native attack maps, dynamic2/5 and hand/promotion0. Cross existing TT-only,order-only,both,neither xdepth3/4,96fresh-player calls total. Same4096nodes/2sec/q0/root-tacticaloff/Nativelegalityon,480sec wholecheckpoint. No altered old trials, prices, evaluator, budget or success criterion. Matched completed scores must agree; legal PV checked, tied actions allowed. Capped results unknown. Decision: choose stable existing search configuration for future price comparisons, not claim new strength.', 'cases':[]}
start=time.perf_counter();write_record(out,r)
try:
 for item in cohort['cases']:
  if not item['accepted']:continue
  assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
  c=compile_ruleset_for_execution(ruleset_from_dict(item['definition']));s=GameSession(c)
  cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0)
  profile=build_ruleset_profile(c,cfg);ev=SemanticAttackEvaluator(c,profile,cfg,backend='native')
  case={'seed':item['seed'],'searches':[]};r['cases'].append(case)
  for tt,order in ((False,False),(True,False),(False,True),(True,True)):
   for depth in (3,4):
    assert time.perf_counter()-start<480,'ablation cost checkpoint'
    player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=tt,use_ordering=order,tuning=SearchTuning(use_root_tactical=False))
    t=time.perf_counter();d=player.choose_action(s,SearchLimits(max_depth=depth,max_nodes=4096,max_time_seconds=2,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-t
    validate_pv(s,d)
    row={'tt':tt,'order':order,'depth':depth,'seconds':elapsed,'decision':record_value(d)};case['searches'].append(row)
    if not tt and not order and depth==3:
     old=next(x['decision'] for x in item['searches'] if x['table']==0 and x['authority']=='semantic' and x['dynamic'] and x['depth']==3)
     if old['completed_depth']==d.completed_depth==depth:
      assert old['action']==row['decision']['action'] and old['score']==d.score and old['nodes']==d.nodes
   write_record(out,r)
  for depth in (3,4):
   complete=[x['decision']['score'] for x in case['searches'] if x['depth']==depth and x['decision']['completed_depth']==depth]
   assert len(set(complete))<=1,(item['seed'],depth,complete)
  print(item['seed'],[(x['tt'],x['order'],x['depth'],x['decision']['completed_depth'],x['decision']['nodes']) for x in case['searches']],flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
