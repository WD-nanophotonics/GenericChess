"""A behavioral increment bound for this nested, nonnegative endpoint family."""
import json,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.research_record import write_record
p=Path(__file__).parent;source=p/'consistency-and-decomposition.json'
r=json.loads(source.read_bytes());rows=[]
for a,b in zip(r['family'],r['family'][1:]):
 # Event count includes2owners,25sources and2target relations; divide100
 # to obtain added endpoints per owner/source for either relation.
 delta=(b['endpoint_path_events']-a['endpoint_path_events'])/100
 change=b['raw']-a['raw']
 assert -1e-12<=change<=delta+1e-12
 rows.append({'from':a['length'],'to':b['length'],
 'added_endpoints_per_source':delta,'raw_delta':change,
 'C_production_integer_delta':b['board_values']['C']-a['board_values']['C'],
 'N_production_integer_delta':b['board_values']['N']-a['board_values']['N']})
write_record(p/'stability-analysis.json',{
 'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'argument':'For this nested family, extending L leaves every old endpoint/path event unchanged and adds D endpoints per owner/source. At density d, an added endpoint contributes P(path-clear)*(1-d+d/2), in[0,1]. Therefore raw increment is in[0,D] under these nonnegative unit-sum density weights. This is a finite opportunity bound, not general material or win-rate continuity. Fixed-reference scaling multiplies the bound by1000/.72. Production median uses both C and N and therefore reprices unchanged N; integer changes alone must not be called N capability changes.',
 'increments':rows,'no_refit':True})
print(rows)
