"""All observed frozen table-choice changes: tie breaking or strict tradeoff?"""
import sys,json,hashlib,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.transition import apply_action
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.search import reference_minimax
from scripts.research_record import write_record,record_value
p=Path(__file__).parent;out=p/'choice-cross-score.json';assert not out.exists()
source=p/'layout-cohort.json';cohort=json.loads(source.read_bytes());analysis=json.loads((p/'layout-analysis.json').read_bytes())
changed=[x for x in analysis['table_pairs'] if x['action_changed']]
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'declaration':'Postdeclared localization, ALL three completed table-choice changes from frozen12layout cohort, all depth2. For each selected action evaluate actual child with full one-ply Core minimax under both fixed tables and SAME map authority/config as original cell. Sixaction checks per duplicate static contexts retained; this measures own-evaluator opportunity cost, not strength, independent labels or new population.60sec batchcheckpoint. No parameter changes.', 'cases':[]}
start=time.perf_counter()
for pair in changed:
 assert time.perf_counter()-start<60,'cross-score checkpoint'
 item=next(x for x in cohort['cases'] if x['seed']==pair['seed']);c=compile_ruleset_for_execution(ruleset_from_dict(item['definition']));s=GameSession(c)
 cfg=EvaluationConfig(dynamic_mobility_weight=2 if pair['dynamic'] else 0,anchor_escape_weight=5 if pair['dynamic'] else 0,promotion_potential_weight=0,hand_weight=0)
 profiles=[build_ruleset_profile(c,cfg),build_semantic_opportunity_profile(c,cfg)[0]]
 rows=[next(x for x in item['searches'] if x['dynamic']==pair['dynamic'] and x['authority']==pair['authority'] and x['depth']==2 and x['table']==table) for table in (0,1)]
 actions=[next(a for a in s.legal_actions() if record_value(a)==x['decision']['action']) for x in rows]
 values=[]
 for table,profile in enumerate(profiles):
  ev=Evaluator(c,profile,cfg) if pair['authority']=='legacy' else SemanticAttackEvaluator(c,profile,cfg)
  scores=[-reference_minimax(apply_action(s.state,a,c),1,ev,c)[0] for a in actions]
  assert scores[table]==rows[table]['decision']['score']
  assert max(scores)==scores[table]
  values.append(scores)
 r['cases'].append({'pair':pair,'actions':list(map(record_value,actions)),'own_root_scores_by_table_then_action':values,
  'candidate_action_loss_under_baseline':values[0][0]-values[0][1],
  'baseline_action_loss_under_candidate':values[1][1]-values[1][0]})
 write_record(out,r)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
print([(x['pair']['dynamic'],x['pair']['authority'],x['candidate_action_loss_under_baseline'],x['baseline_action_loss_under_candidate']) for x in r['cases']])
