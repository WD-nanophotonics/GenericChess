"""Frozen-table x attack-authority x dynamic-feature developer comparison."""
import sys,json,time,hashlib
from pathlib import Path
from dataclasses import replace
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.coordinates import index_to_square
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
import generic_chess.ai.evaluation.evaluator as em
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.search import reference_minimax
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'factorial.json';assert not out.exists()
source=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json'
frozen=json.loads(source.read_bytes());c=compile_ruleset_for_execution(ruleset_from_dict(frozen['definition']))
original=em.pseudo_attacks;engine=semantic_engine_for(c)
def semantic_attacks(position,owner,compiled):
 return frozenset(index_to_square(i,position.board_shape) for i in engine.attacked_squares(position,owner))
class MapEvaluator(em.Evaluator):
 def __init__(self,profile,config,semantic):
  super().__init__(c,profile,config);self.semantic=semantic
 def evaluate(self,state):
  old=em.pseudo_attacks
  try:
   em.pseudo_attacks=semantic_attacks if self.semantic else original
   return super().evaluate(state)
  finally:em.pseudo_attacks=old
cfg=EvaluationConfig(dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0,hand_weight=0)
profiles=[build_ruleset_profile(c,cfg),build_semantic_opportunity_profile(c,cfg)[0]]
sessions=[('root',GameSession(c))]
for name,source_square,target in (('C-capture',(3,3),(3,5)),('R-capture',(5,2),(5,5))):
 s=GameSession(c);a,=[a for a in s.legal_actions() if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source_square and (a.to_square.file,a.to_square.rank)==target];s.submit(a);sessions.append((name,s))
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'declaration':'Prospectively fixed existing cannon/rook exchange and both existing actual capture children. Cross two unchanged static price tables x legacy/semantic attack authority x static/mobility-only/anchor-only/both features x depth2/3. Hand/promotion weights0, cold players, TT/order/root-tactical off, q0,16384nodes/5sec each. All96calls planned; depth2 full Core minimax score/action-set reference per cell, bounded batch600sec with partial preserved. New map changes only S0/S1 attack provider; existing anchor-escape geometry remains approximate. Each mode retains actual transitions, independent Native legality and PV checks. No human fitting/price selection/strength claim. Static cells must reproduce unchanged outputs. Local monkeypatch restored after every evaluate.',
 'prices':[dict(x.board_value_by_type) for x in profiles],'cases':[]}
start=time.perf_counter();write_record(out,r)
try:
 for name,session in sessions:
  for table,profile in enumerate(profiles):
   for features,mobility,anchor in (('static',0,0),('mobility',2,0),('anchor',0,5),('both',2,5)):
    config=replace(cfg,dynamic_mobility_weight=mobility,anchor_escape_weight=anchor)
    for semantic in (False,True):
     ev=MapEvaluator(profile,config,semantic)
     reference=None
     for depth in (2,3):
      assert time.perf_counter()-start<600,'factorial cost checkpoint'
      assert not json.loads((root/'.local_agent/rollout.json').read_bytes())['user_paused']
      player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=False,use_ordering=False,
       tuning=SearchTuning(use_root_tactical=False))
      t=time.perf_counter();d=player.choose_action(session,SearchLimits(max_depth=depth,max_nodes=16384,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0))
      validate_pv(session,d)
      if depth==2:
       rt=time.perf_counter();score,action=reference_minimax(session.state,2,ev,c)
       reference={'score':score,'action':record_value(action),'seconds':time.perf_counter()-rt}
       assert d.completed_depth==2 and d.score==score
      row={'root':name,'table':table,'features':features,'semantic':semantic,'depth':depth,
       'root_eval':ev.evaluate(session.state),'decision':record_value(d),'seconds':time.perf_counter()-t,
       'reference':reference if depth==2 else None}
      r['cases'].append(row);write_record(out,r)
      print(name,table,features,semantic,depth,d.completed_depth,d.score,d.nodes,flush=True)
 r['complete']=True
finally:
 em.pseudo_attacks=original;r['seconds']=time.perf_counter()-start;write_record(out,r)
