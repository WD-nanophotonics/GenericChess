"""Same-state bulk query cost, with and without actual full-history import."""
import sys,json,hashlib,time,statistics
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.mirror import NativeSemanticPositionMirror
from generic_chess.native.semantic import attacked_squares,is_square_attacked
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'native-cost.json';assert not out.exists()
mix=json.loads((root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json').read_bytes())['definition']
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'declaration':'Three fixed supported rules, initial plus8lexical actual plies. Match both-owner full maps before timing. Four methods:Corebulk,Native scalar queries,Nativebulk prepacked,Nativebulk with fresh full-history mirror import on every state. Three rotated-order paired batches,100cycles through9states. No caches across calls beyond immutable compiled rules/prepacked comparator.90sec total checkpoint, retain partial. Counts owner-targets not legal actions; no strength inference.', 'cases':[]}
start=time.perf_counter()
try:
 for name,definition in (('western',build_western_chess_ruleset()),('shogi',build_standard_shogi_ruleset()),('mixture',ruleset_from_dict(mix))):
  c=compile_ruleset_for_execution(definition);s=GameSession(c);states=[s.state]
  for i in range(8):
   if s.state.terminal_status.is_terminal:break
   s.submit(sorted(s.legal_actions(),key=repr)[0]);states.append(s.state)
  e=semantic_engine_for(c);nr=compile_native_semantic_rules(c)
  packed=[NativeSemanticPositionMirror.from_state(c,nr,x,history_certified=True).position for x in states]
  def core(i):return tuple(e.attacked_squares(states[i].position,o) for o in (0,1))
  def scalar(i):return tuple(frozenset(j for j in range(len(states[i].position.board)) if is_square_attacked(nr,packed[i],j,o)) for o in (0,1))
  def bulk(i):return tuple(attacked_squares(nr,packed[i],o) for o in (0,1))
  def imported(i):
   pos=NativeSemanticPositionMirror.from_state(c,nr,states[i],history_certified=True).position
   return tuple(attacked_squares(nr,pos,o) for o in (0,1))
  methods={'core':core,'native-scalar':scalar,'native-bulk':bulk,'native-import-bulk':imported}
  expected=[core(i) for i in range(len(states))]
  for label,fn in methods.items():assert [fn(i) for i in range(len(states))]==expected,label
  item={'name':name,'states':len(states),'timing':[],'all_maps_equal':True}
  labels=list(methods)
  for repeat in range(3):
   batch={}
   for label in labels[repeat:]+labels[:repeat]:
    t=time.perf_counter();checksum=0
    for cycle in range(100):
     assert time.perf_counter()-start<90,'cost checkpoint'
     checksum+=sum(sum(map(len,methods[label](i))) for i in range(len(states)))
    batch[label]={'seconds':time.perf_counter()-t,'both_owner_maps':100*len(states),'checksum':checksum}
   item['timing'].append(batch)
  r['cases'].append(item);write_record(out,r)
  print(name,{label:statistics.median(b[label]['seconds'] for b in item['timing']) for label in labels},flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
