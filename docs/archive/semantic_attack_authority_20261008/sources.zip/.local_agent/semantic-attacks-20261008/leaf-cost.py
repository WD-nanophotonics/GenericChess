"""Same-state attack-authority cost; paired order and explicit score changes."""
import sys,json,hashlib,time,statistics,importlib.util
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.core.semantic_executor import semantic_engine_for
from generic_chess.core.coordinates import index_to_square
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
import generic_chess.ai.evaluation.evaluator as em
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'leaf-cost.json';assert not out.exists()
old=em.pseudo_attacks
mix=json.loads((root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json').read_bytes())['definition']
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 declaration='Three fixed supported rules: dense Western/Shogi starts and existing cannon mixture,8lexical actual plies each. Same original static table/config, vary only attack provider. Three paired batches alternating old/new order,100cycles through9states. Scores are permitted to change; save each score. Measure leaf-only total including local provider substitution, no rule-analysis profile-build time or strength claim.90sec batch checkpoint and partial retained.',cases=[])
start=time.perf_counter()
try:
 for name,definition in (('western',build_western_chess_ruleset()),('shogi',build_standard_shogi_ruleset()),('mixture',ruleset_from_dict(mix))):
  c=compile_ruleset_for_execution(definition);s=GameSession(c);states=[s.state];engine=semantic_engine_for(c)
  for i in range(8):
   if s.state.terminal_status.is_terminal:break
   s.submit(sorted(s.legal_actions(),key=repr)[0]);states.append(s.state)
  def new(position,owner,compiled):return frozenset(index_to_square(i,position.board_shape) for i in engine.attacked_squares(position,owner))
  ev=em.Evaluator(c,build_ruleset_profile(c,EvaluationConfig()),EvaluationConfig())
  item={'name':name,'states':len(states),'scores':{},'timing':[]}
  for label,provider in (('legacy',old),('semantic',new)):
   em.pseudo_attacks=provider;item['scores'][label]=[ev.evaluate(x) for x in states]
  for repeat in range(3):
   times={}
   for label in (('legacy','semantic') if repeat%2==0 else ('semantic','legacy')):
    em.pseudo_attacks=old if label=='legacy' else new;t=time.perf_counter();checksum=0
    for cycle in range(100):
     assert time.perf_counter()-start<90,'leaf cost checkpoint'
     checksum+=sum(ev.evaluate(x) for x in states)
    times[label]={'seconds':time.perf_counter()-t,'evaluations':100*len(states),'checksum':checksum}
   item['timing'].append(times)
  r['cases'].append(item);write_record(out,r)
  print(name,statistics.median(x['semantic']['seconds']/x['legacy']['seconds'] for x in item['timing']),flush=True)
 r['complete']=True
finally:em.pseudo_attacks=old;r['seconds']=time.perf_counter()-start;write_record(out,r)
