import json,hashlib
from pathlib import Path
p=Path(__file__).parent;source=p/'factorial.json';r=json.loads(source.read_bytes())
assert r['complete'] and len(r['cases'])==96
pairs={}
for row in r['cases']:
 key=(row['root'],row['table'],row['features'],row['depth'])
 pairs.setdefault(key,{})[row['semantic']]=row
summary=[]
for key,cells in pairs.items():
 before,after=(cells[x]['decision'] for x in (False,True))
 sig=('action','score','nodes','qnodes','completed_depth','principal_variation')
 same=all(before[k]==after[k] for k in sig)
 if key[2]=='static':assert same
 assert all(d['completed_depth']==key[3] and d['native_legality_fallbacks']==0 for d in (before,after))
 summary.append(dict(root=key[0],table=key[1],features=key[2],depth=key[3],
  delta_score=after['score']-before['score'],action_changed=after['action']!=before['action'],
  exact_signature_equal=same,nodes_before=before['nodes'],nodes_after=after['nodes'],
  elapsed_before=before['elapsed_seconds'],elapsed_after=after['elapsed_seconds']))
result=dict(producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),calls=96,
 complete_depth_calls=96,core_depth2_references=48,
 static_pairs=sum(x['features']=='static' for x in summary),
 dynamic_pairs=sum(x['features']!='static' for x in summary),
 changed_score_pairs=sum(x['delta_score']!=0 for x in summary),
 changed_action_pairs=sum(x['action_changed'] for x in summary),pairs=summary,
 qualification='Exact score parity to Core at48depth2cells, not independent value validation. Raw row.seconds includes reference work; timing analysis uses decision.elapsed_seconds, with coarse platform clock. No universal speed claim or changed price/default.')
(p/'factorial-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k not in ('pairs','qualification')})
print('changed actions',[(x['root'],x['table'],x['features'],x['depth']) for x in summary if x['action_changed']])
