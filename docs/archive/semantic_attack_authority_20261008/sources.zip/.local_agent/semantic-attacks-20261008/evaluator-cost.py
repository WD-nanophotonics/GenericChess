"""End-to-end production evaluator cost with current-state Native imports."""
import sys,json,hashlib,time,statistics
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.standard_shogi import build_standard_shogi_ruleset
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.evaluator import Evaluator
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from scripts.research_record import write_record
p=Path(__file__).parent;out=p/'evaluator-cost.json';assert not out.exists()
mix=json.loads((root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json').read_bytes())['definition']
prior={x['name']:x for x in json.loads((p/'leaf-cost.json').read_bytes())['cases']}
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'declaration':'Same initial+8actual lexical plies on Western/Shogi/frozen mixture, original static profiles/default weights. Compare untouched legacy, semantic Core and semantic Native. Current Native packs board/hand/aux on each evaluate, no history/mirror/cache. Five rotated-order paired batches,200cycles through9states. Each saved score must match prior legacy/semantic leaf-cost result.90sec checkpoint, partial retained. Local costs only; no universal speed/strength/price inference.', 'cases':[]}
start=time.perf_counter()
try:
 for name,definition in (('western',build_western_chess_ruleset()),('shogi',build_standard_shogi_ruleset()),('mixture',ruleset_from_dict(mix))):
  c=compile_ruleset_for_execution(definition);s=GameSession(c);states=[s.state]
  for i in range(8):
   if s.state.terminal_status.is_terminal:break
   s.submit(sorted(s.legal_actions(),key=repr)[0]);states.append(s.state)
  cfg=EvaluationConfig();profile=build_ruleset_profile(c,cfg)
  methods={'legacy':Evaluator(c,profile,cfg),'core':SemanticAttackEvaluator(c,profile,cfg),'native':SemanticAttackEvaluator(c,profile,cfg,backend='native')}
  item={'name':name,'states':len(states),'scores':{},'timing':[]}
  for label,ev in methods.items():
   scores=[ev.evaluate(x) for x in states];assert scores==prior[name]['scores']['legacy' if label=='legacy' else 'semantic'];item['scores'][label]=scores
  labels=list(methods)
  for repeat in range(5):
   batch={};offset=repeat%len(labels)
   for label in labels[offset:]+labels[:offset]:
    t=time.perf_counter();checksum=0
    for cycle in range(200):
     assert time.perf_counter()-start<90,'cost checkpoint'
     checksum+=sum(methods[label].evaluate(x) for x in states)
    batch[label]={'seconds':time.perf_counter()-t,'evaluations':200*len(states),'checksum':checksum}
   item['timing'].append(batch)
  r['cases'].append(item);write_record(out,r)
  print(name,{label:statistics.median(b[label]['seconds'] for b in item['timing']) for label in labels},flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
