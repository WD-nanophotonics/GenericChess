import json,hashlib,statistics,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts.research_record import write_record
p=Path(__file__).parent;source=p/'layout-cohort.json';r=json.loads(source.read_bytes())
assert r['complete'] and len(r['cases'])==12
summary={'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'attempted':12,'accepted':sum(x['accepted'] for x in r['cases']),'rejected':[],
 'calls':0,'complete_depth_calls':0,'native_fallbacks':0,'immediate_win_roots':0,'static_controls':[],'table_pairs':[],'map_pairs':[]}
sig=('action','score','nodes','qnodes','completed_depth','principal_variation')
for item in r['cases']:
 if not item['accepted']:summary['rejected'].append({'seed':item['seed'],'reason':item['rejection']});continue
 summary['immediate_win_roots']+=bool(item['immediate_wins'])
 cells={(x['dynamic'],x['table'],x['authority'],x['depth']):x for x in item['searches']}
 summary['calls']+=len(cells);summary['complete_depth_calls']+=sum(x['decision']['completed_depth']==x['depth'] for x in cells.values())
 summary['native_fallbacks']+=sum(x['decision']['native_legality_fallbacks'] for x in cells.values())
 for dynamic in (False,True):
  for authority in ('legacy','semantic'):
   for depth in (2,3):
    a,b=[cells[dynamic,t,authority,depth]['decision'] for t in (0,1)]
    complete=a['completed_depth']==b['completed_depth']==depth
    summary['table_pairs'].append({'seed':item['seed'],'dynamic':dynamic,'authority':authority,'depth':depth,'complete':complete,'score_delta':b['score']-a['score'] if complete else None,'action_changed':a['action']!=b['action'] if complete else None})
  for table in (0,1):
   for depth in (2,3):
    a,b=[cells[dynamic,table,authority,depth]['decision'] for authority in ('legacy','semantic')]
    complete=a['completed_depth']==b['completed_depth']==depth
    row={'seed':item['seed'],'dynamic':dynamic,'table':table,'depth':depth,'complete':complete,'score_delta':b['score']-a['score'] if complete else None,'action_changed':a['action']!=b['action'] if complete else None}
    summary['map_pairs'].append(row)
    if not dynamic:
     if complete:assert all(a[k]==b[k] for k in sig)
     summary['static_controls'].append({'seed':item['seed'],'table':table,'depth':depth,'complete':complete,'equal_if_complete':True if complete else None})
for name in ('table_pairs','map_pairs'):
 complete=[x for x in summary[name] if x['complete']]
 summary[name+'_counts']={'pairs':len(summary[name]),'complete':len(complete),'action_changes':sum(x['action_changed'] for x in complete),'score_changes':sum(x['score_delta']!=0 for x in complete)}
 for depth in (2,3):
  for dynamic in (False,True):
   rows=[x for x in complete if x['depth']==depth and x['dynamic']==dynamic]
   summary[name+'_counts'][str((depth,dynamic))]={'complete':len(rows),'action_changes':sum(x['action_changed'] for x in rows),'score_changes':sum(x['score_delta']!=0 for x in rows)}
summary['qualification']='Prospective synthetic placements with two frozen tables, exposed development. Action changes need not imply strict improvement: root best-action ties were not enumerated. Capped depth3 cells unknown; no adaptive completion or material/strength claim.'
write_record(p/'layout-analysis.json',summary)
print({k:v for k,v in summary.items() if k not in ('static_controls','table_pairs','map_pairs','qualification')})
