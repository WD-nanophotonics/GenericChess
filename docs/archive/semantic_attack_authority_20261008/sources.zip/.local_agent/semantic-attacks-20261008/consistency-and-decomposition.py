"""Advisor-selected finite family plus mechanism explanation, no new price law."""
import sys, json, hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'tests'),str(root/'tests/product')]
from test_semantic_ray_equivalence import measure_family
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from scripts.research_record import write_record
p=Path(__file__).parent
dependency=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json'
c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(dependency.read_bytes())['definition']))
cfg=EvaluationConfig()
profile,scope=build_semantic_opportunity_profile(c,cfg)
components={}
for tid in ('C','R'):
 row=scope['types'][tid]
 components[tid]={'quiet':sum(w*x['quiet'] for w,x in zip(cfg.density_weights,row['curves'])),
  'capture':sum(w*x['capture'] for w,x in zip(cfg.density_weights,row['curves'])),
  'raw':row['raw'],'curves':row['curves'],'board_value':profile.board_value_by_type[tid]}
assert components['C']['quiet']==components['R']['quiet']
ordered=json.loads((p/'ordered-price-comparison.json').read_bytes())
assert ordered['complete']
comparisons=[]
for case in ordered['cases']:
 old,fixed,own=[x['decision'] for x in case['searches']]
 assert all(x['completed_depth']==3 for x in (old,fixed,own))
 comparisons.append({'seed':case['seed'],'old_score':old['score'],
 'candidate_score':fixed['score'],'price_action_changed':old['action']!=fixed['action'],
 'order_action_changed':fixed['action']!=own['action'],
 'old_nodes':old['nodes'],'candidate_fixed_order_nodes':fixed['nodes'],
 'candidate_own_order_nodes':own['nodes']})
record={'declaration':'Finite5x5 board ray L1..5, two supported equivalent encodings, explicit intermediate path_clear. Fixed density law and N reference. abs tolerance1e-12 declared in regression. Production median values separately reported. Actual Core executor250 positions per L plus every owner/source geometry/path census. This finite nonnegative opportunity objective is not win-rate monotonicity. Followup: explain existing cannon/rook raw decomposition under unchanged default law, no refit or new search.',
 'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'test_source_sha256':hashlib.sha256((root/'tests/product/test_semantic_ray_equivalence.py').read_bytes()).hexdigest(),
 'dependency_sha256':hashlib.sha256(dependency.read_bytes()).hexdigest(),
 'family':measure_family(),'cannon_rook_decomposition':components,
 'ordered_comparison':comparisons,
 'timing_qualification':'Ordered comparison overlaps regression load; wall times are excluded from cost claims.'}
assert not any(x['price_action_changed'] or x['order_action_changed'] for x in comparisons)
write_record(p/'consistency-and-decomposition.json',record)
print(json.dumps({'family':record['family'],'components':components,'score_changes':sum(x['old_score']!=x['candidate_score'] for x in comparisons)},indent=2))
