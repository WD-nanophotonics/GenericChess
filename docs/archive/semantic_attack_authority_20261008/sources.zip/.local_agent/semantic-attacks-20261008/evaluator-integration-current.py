"""Public opt-in evaluator parity against prior frozen factorial outputs."""
import sys,json,time,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.evaluation.config import EvaluationConfig
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.semantic import build_semantic_opportunity_profile
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.limits import SearchLimits
from scripts.research_record import record_value,write_record
from scripts.unfamiliar_search import validate_pv
p=Path(__file__).parent;out=p/'evaluator-integration-current.json';assert not out.exists()
source=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json'
c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(source.read_bytes())['definition']))
cfg=EvaluationConfig(dynamic_mobility_weight=2,anchor_escape_weight=5,promotion_potential_weight=0,hand_weight=0)
profiles=[build_ruleset_profile(c,cfg),build_semantic_opportunity_profile(c,cfg)[0]]
sessions=[('root',GameSession(c))]
for name,source_square,target in (('C-capture',(3,3),(3,5)),('R-capture',(5,2),(5,5))):
 s=GameSession(c);a,=[a for a in s.legal_actions() if hasattr(a,'from_square') and (a.from_square.file,a.from_square.rank)==source_square and (a.to_square.file,a.to_square.rank)==target];s.submit(a);sessions.append((name,s))
prior=json.loads((p/'factorial.json').read_bytes())
frozen={(x['root'],x['table'],x['depth']):x for x in prior['cases'] if x['semantic'] and x['features']=='both'}
r={'complete':False,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'frozen_sha256':hashlib.sha256((p/'factorial.json').read_bytes()).hexdigest(),
 'declaration':'Existing3roots x2unchangedtables xCore/Native opt-in dynamic-map evaluator xdepth2/3. All24calls. ColdTT/off/order/off/root-tactical/off/q0,16384nodes/5sec each,300sec batchcheckpoint. Compare exact action/score/nodes/PV/completeddepth to prior semantic factorial cells; only provider/integration changes. Native packs current board/hand/aux per leaf; no repetition authority; no mirror cache, no defaults or price tuning. Native search legality independent of evaluation backend.', 'cases':[]}
start=time.perf_counter();write_record(out,r)
try:
 for name,session in sessions:
  for table,profile in enumerate(profiles):
   for backend in ('core','native'):
    ev=SemanticAttackEvaluator(c,profile,cfg,backend=backend)
    for depth in (2,3):
     assert time.perf_counter()-start<300,'integration cost checkpoint'
     player=AlphaBetaPlayer(c,use_disk_cache=False,evaluator_override=ev,use_tt=False,use_ordering=False,tuning=SearchTuning(use_root_tactical=False))
     t=time.perf_counter();d=player.choose_action(session,SearchLimits(max_depth=depth,max_nodes=16384,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-t
     validate_pv(session,d);decision=record_value(d);expected=frozen[name,table,depth]['decision']
     compared=('action','score','nodes','qnodes','completed_depth','principal_variation')
     for key in compared:
      assert decision[key]==expected[key],(name,table,backend,depth,key,decision[key],expected[key])
     r['cases'].append({'root':name,'table':table,'backend':backend,'depth':depth,'decision':decision,'seconds':elapsed,'frozen_fields_equal':list(compared)});write_record(out,r)
     print(name,table,backend,depth,d.score,elapsed,flush=True)
 r['complete']=True
finally:r['seconds']=time.perf_counter()-start;write_record(out,r)
