"""Explicit synthetic-source allowlist; extract and rehash before delivery."""
import hashlib,json,sys,sysconfig,platform,zipfile,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=Path(__file__).parent
dest=root/'docs/archive/semantic_attack_authority_20261008';dest.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
# This one experiment directory is Agent-produced; do not scan workflow state,
# Slack, user documents or other project paths.
files=[x for x in p.iterdir() if x.is_file() and x.suffix in ('.py','.json','.c','.txt')]
dependencies=[root/x for x in (
 '.local_agent/semantic-candidate-20261008/cannon-mixture.json',
 '.local_agent/semantic-candidate-20261008/cannon-mixture.py',
 'tests/rule_semantics_ir_fixtures.py', 'tests/product/test_semantic_ray_equivalence.py',
 'tests/product/test_semantic_attack_map.py',
 'generic_chess/core/semantic_executor.py','generic_chess/native/semantic.py',
 'generic_chess/native/compiler.py','generic_chess/native/mirror.py',
 'generic_chess/ai/evaluation/evaluator.py','generic_chess/ai/evaluation/semantic_attacks.py',
 'generic_chess/ai/evaluation/semantic.py','scripts/research_record.py',
 'scripts/unfamiliar_search.py','scripts/build_native_zig.py')]
dependencies+=sorted((root/'generic_chess/_native').glob('*.c'))
dependencies+=sorted((root/'generic_chess/_native').glob('*.h'))
files=list(dict.fromkeys(files+dependencies));members=[]
for package,predicate in (('sources.zip',lambda x:x.suffix in ('.py','.c','.h')),
                           ('raw.zip',lambda x:x.suffix not in ('.py','.c','.h'))):
 with zipfile.ZipFile(dest/package,'w',zipfile.ZIP_DEFLATED) as z:
  for path in files:
   if predicate(path):
    rel=path.relative_to(root).as_posix();z.write(path,rel)
    members.append({'original_path':rel,'package':package,'bytes':path.stat().st_size,'sha256':sha(path)})
verified=0
with tempfile.TemporaryDirectory(prefix='semantic-attack-extract-',dir=root/'.local_agent') as td:
 for name in ('sources.zip','raw.zip'):
  with zipfile.ZipFile(dest/name) as z:z.extractall(td)
 for m in members:
  assert sha(Path(td)/m['original_path'])==m['sha256'];verified+=1
pins=[]
for path in files:
 if path.suffix!='.json' or path.parent!=p:continue
 data=json.loads(path.read_bytes())
 if isinstance(data,dict) and 'producer_sha256' in data:
  matches=[x.relative_to(root).as_posix() for x in files if x.suffix=='.py' and sha(x)==data['producer_sha256']]
  assert matches,(path.name,'producer pin not preserved')
  pins.append({'record':path.relative_to(root).as_posix(),'producer_sha256':data['producer_sha256'],'matching_sources':matches})
binary=next((root/'generic_chess').glob('_native_core*.pyd'))
zig=root/'.venv/Lib/site-packages/ziglang/zig.exe'
metadata={'python':sys.version,'platform':platform.platform(),'extension_suffix':sysconfig.get_config_var('EXT_SUFFIX'),
 'binary_sha256':sha(binary),'binary_bytes':binary.stat().st_size,'binary_included':False,
 'zig_version':subprocess.check_output([str(zig),'version'],text=True).strip(),
 'build':'scripts/build_native_zig.py; Zig cc x86_64-windows-gnu -shared -O2; CPython312',
 'pin_scope':'Current delivery snapshot/build; historical target-scan and failed evaluator sources separately preserved. Not a retroactive claim that every earlier experiment ran final sources.'}
write_record(dest/'index.json',{'base_sha':'fcdacafe9d1fbacdfbad12b292e6d948d182a39a',
 'scope':'Only Agent-generated synthetic experiments and required source snapshots. No binaries/private input/raw Slack/account/workflow state.',
 'members':members,'extracted_verified_members':verified,'producer_pins':pins,'native_build':metadata,
 'packages':{name:sha(dest/name) for name in ('sources.zip','raw.zip')}})
facts=json.loads((p/'consistency-and-decomposition.json').read_bytes())
write_record(root/'docs/research/data/semantic_attack_authority_20261008.json',{
 'archive':'../../archive/semantic_attack_authority_20261008/index.json',
 'semantics':'Explicit S0/S1 Core/Native bulk attack authority, not legal mobility; defaults unchanged. Current-position Native packing does not import repetition history.',
 'factorial':{'calls':96,'core_references':48,'static_controls':12,'dynamic_score_changes':21,'dynamic_action_changes':6},
 'prospective_layouts':{'seeds':list(range(202610081000,202610081012)),'calls':192,'complete':114,'capped_unknown':78,
 'depth2_dynamic_map_action_changes':'9/24','depth2_dynamic_table_action_changes':'1/24; only legacy maps',
 'static_table_change':'One existing tie, duplicated under two map authorities; no strength evidence'},
 'ordering_ablation':json.loads((p/'search-ablation-analysis.json').read_bytes()),
 'ordered_price_comparison':facts['ordered_comparison'],
 'finite_equivalence_family':facts['family'],
 'behavioral_stability':json.loads((p/'stability-analysis.json').read_bytes()),
 'cannon_rook_decomposition':facts['cannon_rook_decomposition'],
 'native_full_eval_cost_scope':'Paired27states/three rules/five batches:Native/Core about0.347/0.425/0.416; Native/legacy about1.395/1.258/1.479. All cohorts persisted, final atomic replacement failed:complete flag remains false. No universal acceleration.',
 'failures':['Initial target-scan Native bulk is slow; preserved sources.','First evaluator full-history mirror fails on actual RuntimeSearchState; partial preserved.','evaluator-cost final WinError5, complete=false; no retroactive repair.','78 original depth3 caps remain unknown.','Ordered36-call wall clocks overlap full regression; excluded from fair timing claims.'],
 'validation':'1580full suite before new finite-family test;57focused final including family. No independent material-price/strength claim.',
 'source_hashes':{m['original_path']:m['sha256'] for m in members if m['package']=='sources.zip'}})
print(json.dumps({'members_verified':verified,'producer_pins':len(pins),'native_build':metadata,'packages':{name:(dest/name).stat().st_size for name in ('sources.zip','raw.zip')}},indent=2))
