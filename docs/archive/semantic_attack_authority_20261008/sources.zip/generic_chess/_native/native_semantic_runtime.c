#include "native_semantic_runtime.h"

#include <string.h>

static GCSemanticRuntimeAudit *gc_runtime_audit = NULL;
static int gc_runtime_transient = 0;

/* A semantic position reserves history storage for every possible ply.  Search
 * only observes entries below history_len, so copying that unused tail for
 * every edge is pure memory-bandwidth cost.  Keep the public ABI unchanged,
 * but copy exactly the live state and the append-only history prefix. */
static void copy_live_position(GCSemanticPosition *dst,
                               const GCSemanticPosition *src) {
    size_t fixed_bytes = offsetof(GCSemanticPosition, history_lo);
    size_t history_bytes = (size_t)src->history_len;
    memcpy(dst, src, fixed_bytes);
    memcpy(dst->history_lo, src->history_lo, sizeof(uint64_t) * history_bytes);
    memcpy(dst->history_hi, src->history_hi, sizeof(uint64_t) * history_bytes);
    memcpy(dst->history_digest, src->history_digest,
           sizeof(src->history_digest[0]) * history_bytes);
    memcpy(dst->history_actor, src->history_actor, sizeof(uint8_t) * history_bytes);
    memcpy(dst->history_gave_check, src->history_gave_check,
           sizeof(uint8_t) * history_bytes);
    memcpy(&dst->history_len, &src->history_len,
           sizeof(GCSemanticPosition) - offsetof(GCSemanticPosition, history_len));
}

void gc_semantic_runtime_audit_start(GCSemanticRuntimeAudit *audit) {
    gc_runtime_audit = audit;
}

void gc_semantic_runtime_audit_stop(void) {
    gc_runtime_audit = NULL;
}

void gc_semantic_runtime_history_mode_start(void) {
    gc_runtime_transient = 1;
}

void gc_semantic_runtime_history_mode_stop(void) {
    gc_runtime_transient = 0;
}

static int gc_semantic_runtime_make_mode(GCSemanticPosition *child,
                                         const GCSemanticRules *rules,
                                         const GCSemanticPosition *parent,
                                         uint64_t action,
                                         int include_postconditions);

static uint16_t action_to(uint64_t a) { return (uint16_t)(a & 0xffu); }
static uint16_t action_from(uint64_t a) { return (uint16_t)((a >> 8) & 0xffu); }
static uint16_t action_promo(uint64_t a) { return (uint16_t)((a >> 16) & 0xffu); }
static uint16_t action_base(uint64_t a) { return (uint16_t)((a >> 24) & 0xffu); }
static uint8_t action_kind(uint64_t a) { return (uint8_t)((a >> 32) & 0xfu); }
static uint16_t action_pattern(uint64_t a) { return (uint16_t)((a >> 36) & 0xffu); }
static uint16_t action_geometry(uint64_t a) { return (uint16_t)((a >> 44) & 0xfffu); }
static uint16_t action_current(uint64_t a) { return (uint16_t)((a >> 56) & 0xffu); }

static int pattern_has_type(const GCSemPattern *p, uint16_t type) {
    for (uint8_t i = 0; i < p->type_count; i++) if (p->type_indices[i] == type) return 1;
    return 0;
}
static const GCSemAuxSlot *slot_meta(const GCSemanticRules *r, uint16_t id, uint8_t *index) {
    for (uint8_t i = 0; i < r->aux_slot_count; i++) if (r->aux_slots[i].slot_id == id) { if (index) *index = i; return &r->aux_slots[i]; }
    return NULL;
}
static void reset_aux_value(const GCSemAuxSlot *slot, GCSemAuxValue *value, uint8_t board_size) {
    memset(value, 0, sizeof(*value));
    value->kind = slot->value_kind;
    if (slot->initial_kind == 1) { value->has_value = 1; value->bool_value = slot->initial_int; }
    else if (slot->initial_kind == 2) { value->has_value = 1; value->square = (uint16_t)(slot->initial_rank * board_size + slot->initial_file); }
}
static int path_entry(const GCSemGeometry *g, uint8_t owner, uint16_t source, const GCSemPathEntry **out) {
    const GCSemPathOwner *paths = &g->paths[owner];
    for (uint16_t i = 0; i < paths->count; i++) if (paths->entries[i].source == source) { *out = &paths->entries[i]; return 1; }
    return 0;
}
static int target_ok(uint8_t target, const GCPiece *cell, uint8_t side) {
    if (target == 0) return !cell->occupied;
    if (target == 1) return cell->occupied && cell->owner != side;
    if (target == 2) return cell->occupied && cell->owner == side;
    return target == 3;
}
static int path_ok(const GCSemPattern *p, const GCSemPathEntry *e, uint16_t target_index, const GCSemanticPosition *pos, uint8_t side) {
    int count = 0, first = -1, last = -1;
    for (uint16_t i = 0; i < target_index; i++) { const GCPiece *piece = &pos->board[e->squares[i]]; if (!piece->occupied) continue; count++; if (first < 0) first = piece->owner == side ? 0 : 1; last = piece->owner == side ? 0 : 1; }
    for (uint8_t i = 0; i < p->path_count; i++) { const GCSemPathPredicate *q=&p->path[i]; if(q->kind==0 && count!=0)return 0; if(q->kind==1 && (!q->has_count || count!=q->count))return 0; if(q->kind==2 && ((!q->has_lo||count<q->lo)||(!q->has_hi||count>q->hi)))return 0; if(q->kind==3&&q->owner_filter!=2&&first!=(int)q->owner_filter)return 0; if(q->kind==4&&q->owner_filter!=2&&last!=(int)q->owner_filter)return 0; }
    return 1;
}
static int resolve_square(const GCSemSquareRef *ref, const GCSemanticRules *r, const GCSemanticPosition *unused, const GCSemanticPosition *pos, uint8_t side, uint16_t source, uint16_t target, uint16_t *out) {
    (void)unused;
    if (!ref || !out) return 0;
    int base = -1;
    if (ref->kind == 0) base = source;
    else if (ref->kind == 1) base = target;
    else if (ref->kind == 2 && ref->has_square) {
        int file = ref->square % r->board_size, rank = ref->square / r->board_size;
        if (ref->owner_relative && side == 1) { file = r->board_size - 1 - file; rank = r->board_size - 1 - rank; }
        base = rank * r->board_size + file;
    }
    else if ((ref->kind == 3 || ref->kind == 4) && ref->has_offset) {
        base = ref->kind == 3 ? source : target;
        int file = base % r->board_size, rank = base / r->board_size;
        int df = ref->offset_df, dr = ref->offset_dr;
        if (ref->owner_relative && side == 1) { df = -df; dr = -dr; }
        file += df; rank += dr;
        if (file < 0 || rank < 0 || file >= r->board_size || rank >= r->board_size) return 0;
        base = rank * r->board_size + file;
    } else if (ref->kind == 5 && ref->has_step) {
        int sf = source % r->board_size, sr = source / r->board_size;
        int tf = target % r->board_size, tr = target / r->board_size;
        int df = (tf > sf) - (tf < sf), dr = (tr > sr) - (tr < sr);
        int file = sf + df * ((int)ref->step + 1);
        int rank = sr + dr * ((int)ref->step + 1);
        if (file < 0 || rank < 0 || file >= r->board_size || rank >= r->board_size) return 0;
        base = rank * r->board_size + file;
    } else if (ref->kind == 6 && ref->has_slot) {
        uint8_t index = 0; const GCSemAuxSlot *slot = slot_meta(r, ref->slot_id, &index); if (!slot) return 0;
        uint8_t owner_index = slot->scope == 1 ? (uint8_t)(side + 1) : 0;
        const GCSemAuxValue *value = &pos->aux[index][owner_index];
        if (!value->has_value || value->kind != 1) return 0;
        base = value->square;
    } else return 0;
    if (base < 0 || base >= r->board_size * r->board_size) return 0;
    *out = (uint16_t)base; return 1;
}
static int resolve_type(const GCSemTypeRef *ref, uint16_t base, uint16_t current, uint16_t *out) {
    if (!ref || !out) return 0;
    if (ref->kind == 0) *out = base;
    else if (ref->kind == 1) *out = current;
    else if (ref->kind == 2 && ref->has_type) *out = ref->type_index;
    else return 0;
    return 1;
}
static int promotion_action_ok(const GCSemanticRules *r, const GCSemPattern *pattern, uint8_t side, uint16_t base, uint8_t promoted, uint16_t source, uint16_t target, uint16_t promo) {
    if (pattern->promotion_mode == 0) return promo == 255;
    if (pattern->promotion_mode == 2) return pattern->has_explicit_promotion && promo == pattern->explicit_promotion_type;
    if (pattern->promotion_mode != 1 || base >= r->type_count) return 0;
    if (promoted) return promo == 255;
    if (!r->types[base].is_promotable) return promo == 255;
    uint32_t pair = ((uint32_t)source << 16) | target; int allowed = 0;
    const GCSemPairList *pairs = &r->promo_allowed[base][side];
    for (uint16_t i=0;i<pairs->count;i++) if (pairs->pairs[i] == pair) { allowed=1; break; }
    if (!allowed) return promo == 255;
    int forced = 0; const GCSemSquareList *forced_squares=&r->promo_forced[base][side];
    for (uint16_t i=0;i<forced_squares->count;i++) if (forced_squares->squares[i] == target) { forced=1; break; }
    uint64_t alive = r->alive_promo[base][side][target]; int target_allowed = 0;
    for (uint8_t i=0;i<r->types[base].promo_target_count;i++) if ((alive & (1ull<<i)) && r->types[base].promo_targets[i] == promo) { target_allowed=1; break; }
    if (promo == 255) return !forced;
    return target_allowed;
}
static uint8_t promotion_choices(const GCSemanticRules *r, const GCSemPattern *pattern, uint8_t side, uint16_t base, uint8_t promoted, uint16_t source, uint16_t target, uint16_t *out) {
    if (!out) return 0;
    if (pattern->promotion_mode == 0) { out[0] = 255; return 1; }
    if (pattern->promotion_mode == 2) { if (!pattern->has_explicit_promotion) return 0; out[0] = pattern->explicit_promotion_type; return 1; }
    if (pattern->promotion_mode != 1 || base >= r->type_count) return 0;
    if (promoted) { out[0] = 255; return 1; }
    if (!r->types[base].is_promotable) { out[0] = 255; return 1; }
    uint32_t pair = ((uint32_t)source << 16) | target; int allowed = 0;
    const GCSemPairList *pairs = &r->promo_allowed[base][side];
    for (uint16_t i = 0; i < pairs->count; i++) if (pairs->pairs[i] == pair) { allowed = 1; break; }
    if (!allowed) { out[0] = 255; return 1; }
    int forced = 0; const GCSemSquareList *forced_squares = &r->promo_forced[base][side];
    for (uint16_t i = 0; i < forced_squares->count; i++) if (forced_squares->squares[i] == target) { forced = 1; break; }
    uint64_t alive = r->alive_promo[base][side][target]; uint8_t count = 0;
    if (!forced) out[count++] = 255;
    for (uint8_t i = 0; i < r->types[base].promo_target_count && count < GC_MAX_PROMO_TARGETS + 1; i++)
        if ((alive & (1ull << i)) != 0) out[count++] = r->types[base].promo_targets[i];
    return count;
}
static int owner_ok(uint8_t owner_code, uint8_t piece_owner, uint8_t side) { return owner_code == 2 || (owner_code == 0 ? piece_owner == side : piece_owner != side); }
static int resolve_square(const GCSemSquareRef *ref, const GCSemanticRules *r, const GCSemanticPosition *unused, const GCSemanticPosition *pos, uint8_t side, uint16_t source, uint16_t target, uint16_t *out);
static int compare_value(uint8_t comparison, int value, int expected) {
    if (comparison == 0) return value == expected;
    if (comparison == 1) return value != expected;
    if (comparison == 2) return value < expected;
    if (comparison == 3) return value <= expected;
    if (comparison == 4) return value > expected;
    if (comparison == 5) return value >= expected;
    return 0;
}
static int spatial_holds(const GCSemSpatial *spatial, const GCSemanticRules *r, const GCSemanticPosition *pos, uint8_t side, uint16_t source, uint16_t target, uint16_t square) {
    if (!spatial) return 1;
    if (spatial->kind == 5) {
        if (!spatial->has_zone || spatial->zone_index >= r->zone_count) return 0;
        const GCSemZone *zone = &r->zones[spatial->zone_index];
        for (uint16_t i = 0; i < zone->count; i++) if (zone->squares[i] == square) return 1;
        return 0;
    }
    if (spatial->refs_count == 0) return 1;
    uint16_t ref_square = 0;
    if (!resolve_square(&spatial->refs[0], r, NULL, pos, side, source, target, &ref_square)) return 0;
    int sf = square % r->board_size, sr = square / r->board_size;
    int rf = ref_square % r->board_size, rr = ref_square / r->board_size;
    if (spatial->kind == 0) return sf == rf;
    if (spatial->kind == 1) return sr == rr;
    if (spatial->kind == 2) return square == ref_square;
    if (spatial->kind == 3) return (sf-rf >= -1 && sf-rf <= 1 && sr-rr >= -1 && sr-rr <= 1);
    if (spatial->kind == 4 && spatial->refs_count == 2) {
        uint16_t other_square = 0;
        if (!resolve_square(&spatial->refs[1], r, NULL, pos, side, source, target, &other_square)) return 0;
        int of = other_square % r->board_size, orank = other_square / r->board_size;
        int df = of - rf, dr = orank - rr, af = df < 0 ? -df : df, ar = dr < 0 ? -dr : dr;
        int g = af, h = ar;
        while (h != 0) { int t = g % h; g = h; h = t; }
        if (g <= 1) return 0;
        int step_f = df / g, step_r = dr / g;
        for (int k = 1; k < g; k++) if (sf == rf + k * step_f && sr == rr + k * step_r) return 1;
        return 0;
    }
    return 0;
}
static int state_guards_hold(const GCSemanticRules *r, const GCSemanticPosition *pos, const GCSemPattern *pattern, uint8_t side, uint16_t source, uint16_t target, uint16_t action_base_type, uint16_t action_current_type) {
    for (uint8_t gi = 0; gi < pattern->guard_count; gi++) {
        const GCSemStateGuard *g=&pattern->guards[gi]; if (g->location != 0) return 0;
        int count=0;
        uint16_t subject = 0;
        if (g->has_subject_ref && !resolve_square(&g->subject_ref, r, NULL, pos, side, source, target, &subject)) return 0;
        uint16_t first = g->has_subject_ref ? subject : 0;
        uint16_t last = g->has_subject_ref ? (uint16_t)(subject + 1) : (uint16_t)(r->board_size*r->board_size);
        for (uint16_t sq=first;sq<last;sq++) { const GCPiece *piece=&pos->board[sq]; if(!piece->occupied || !owner_ok(g->owner,piece->owner,side))continue; uint16_t want=0; if(g->type_ref.kind==0)want=action_base_type; else if(g->type_ref.kind==1)want=action_current_type; else if(g->type_ref.kind==2&&g->type_ref.has_type)want=g->type_ref.type_index; else if(g->type_ref.kind==3)want=piece->current_type; else return 0; uint16_t actual=g->compare_field==0?piece->base_type:piece->current_type; if(g->type_ref.kind!=3 && actual!=want)continue; if(g->promoted==0 && !piece->promoted)continue; if(g->promoted==1 && piece->promoted)continue; if(g->promoted>2)return 0; if(!spatial_holds(&g->spatial,r,pos,side,source,target,sq))continue; count++; }
        int predicate = g->aggregation == 0 ? count > 0 : compare_value(g->comparison,count,g->value); if (!predicate) return 0;
    }
    return 1;
}

static int declaration_guard_holds(const GCSemanticRules *r,
                                   const GCSemanticPosition *pos,
                                   const GCSemStateGuard *g,
                                   uint8_t side) {
    if (g->location != 0) return 0;
    uint16_t subject = 0;
    if (g->has_subject_ref &&
        !resolve_square(&g->subject_ref, r, NULL, pos, side, 0, 0, &subject))
        return 0;
    uint16_t first = g->has_subject_ref ? subject : 0;
    uint16_t last = g->has_subject_ref
        ? (uint16_t)(subject + 1)
        : (uint16_t)(r->board_size * r->board_size);
    int count = 0;
    for (uint16_t sq = first; sq < last; sq++) {
        const GCPiece *piece = &pos->board[sq];
        if (!piece->occupied || !owner_ok(g->owner, piece->owner, side)) continue;
        if (g->type_ref.kind == 2) {
            uint16_t actual = g->compare_field == 0
                ? piece->base_type : piece->current_type;
            if (!g->type_ref.has_type || actual != g->type_ref.type_index)
                continue;
        } else if (g->type_ref.kind != 3) {
            return 0;
        }
        if (g->promoted == 0 && !piece->promoted) continue;
        if (g->promoted == 1 && piece->promoted) continue;
        if (g->promoted > 2) return 0;
        if (!spatial_holds(&g->spatial, r, pos, side, 0, 0, sq)) continue;
        count++;
    }
    int value = g->aggregation == 0 ? (count ? 1 : 0) : count;
    return compare_value(g->comparison, value, g->value);
}

static int declaration_metric_holds(const GCSemanticRules *r,
                                    const GCSemanticPosition *pos,
                                    const GCSemDeclarationMetric *metric,
                                    uint8_t side,
                                    int64_t *score_out) {
    int64_t score = 0;
    for (uint16_t sq = 0; sq < r->board_size * r->board_size; sq++) {
        const GCPiece *piece = &pos->board[sq];
        if (!piece->occupied || !owner_ok(metric->owner, piece->owner, side))
            continue;
        if (metric->has_spatial &&
            !spatial_holds(&metric->spatial, r, pos, side, 0, 0, sq))
            continue;
        uint16_t type = metric->compare_field == 0
            ? piece->base_type : piece->current_type;
        if (type >= r->type_count) return 0;
        score += metric->weights[type];
    }
    if (metric->include_hands) {
        for (uint8_t owner = 0; owner < 2; owner++) {
            if (!owner_ok(metric->owner, owner, side)) continue;
            for (uint16_t type = 0; type < r->type_count; type++)
                score += (int64_t)metric->weights[type] *
                         pos->hand_counts[owner][type];
        }
    }
    *score_out = score;
    return 1;
}

int gc_semantic_runtime_assess_declaration(
    const GCSemanticRules *rules,
    const GCSemanticPosition *position,
    const char *declaration_id,
    GCSemanticDeclarationAssessment *out) {
    if (!rules || !position || !declaration_id || !out) return 0;
    const GCSemDeclaration *declaration = NULL;
    for (uint8_t i = 0; i < rules->declaration_count; i++) {
        if (strcmp(rules->declarations[i].declaration_id, declaration_id) == 0) {
            declaration = &rules->declarations[i];
            break;
        }
    }
    if (!declaration) return -1;
    uint8_t actor = position->side_to_move;
    if (declaration->owner != actor) return -2;
    int64_t score = 0;
    out->has_weighted_score = declaration->has_metric;
    out->weighted_score = 0;
    if (declaration->has_metric &&
        !declaration_metric_holds(rules, position, &declaration->metric,
                                  actor, &score)) return 0;
    out->weighted_score = score;
    int valid = 1;
    for (uint8_t i = 0; i < declaration->state_guard_count; i++) {
        if (!declaration_guard_holds(rules, position,
                                     &declaration->state_guards[i], actor)) {
            valid = 0;
            break;
        }
    }
    if (valid && declaration->require_not_in_check &&
        gc_semantic_runtime_in_check(rules, position, actor)) valid = 0;
    if (valid && declaration->has_ply_limit && position->ply >= declaration->ply_limit)
        valid = 0;
    uint8_t outcome = declaration->failure_outcome;
    if (valid) {
        for (uint8_t i = 0; i < declaration->outcome_band_count; i++) {
            if (declaration->has_metric &&
                score >= declaration->outcome_bands[i].threshold) {
                outcome = declaration->outcome_bands[i].outcome;
                break;
            }
        }
    }
    out->outcome = outcome;
    return 1;
}

static int slot_guards_hold(const GCSemanticRules *r, const GCSemanticPosition *pos, const GCSemPattern *pattern, uint8_t side, uint16_t source, uint16_t target) {
    for (uint8_t i=0;i<pattern->slot_guard_count;i++) { const GCSemSlotGuard *g=&pattern->slot_guards[i]; uint8_t index=0; const GCSemAuxSlot *slot=slot_meta(r,g->slot_id,&index); if(!slot)return 0; uint8_t owner_index=slot->scope==1?(uint8_t)(side+1):0; const GCSemAuxValue *value=&pos->aux[index][owner_index]; if(g->has_square_ref){uint16_t expected=0;if(!resolve_square(&g->square_ref,r,NULL,pos,side,source,target,&expected))return 0;int equal=value->has_value&&value->kind==1&&value->square==expected;if(g->comparison==0&&!equal)return 0;if(g->comparison==1&&equal)return 0;}else{int actual=value->has_value?value->bool_value:0;if(!value->has_value&&g->has_value&&g->value!=0&&g->comparison==0)return 0;if(g->has_value&&!compare_value(g->comparison,actual,g->value))return 0;} }
    return 1;
}
static int semantic_attacked_by(const GCSemanticRules *r, const GCSemanticPosition *pos, uint16_t target_square, uint8_t attacker) {
    if (gc_runtime_audit) gc_runtime_audit->attack_check_calls++;
    if (target_square >= r->board_size * r->board_size) return 0;
    for (uint16_t pi=0; pi<r->pattern_count; pi++) {
        const GCSemPattern *pattern=&r->patterns[pi];
        /* Semantic pseudo-attack is capture eligibility only.  Keep this
         * identical to SemanticEngine.is_square_attacked: target_any and
         * target_empty patterns never contribute attack truth. */
        if (pattern->target != 1) continue;
        for (uint8_t gi=0; gi<pattern->geometry_count; gi++) {
            uint16_t gid=pattern->geometry_indices[gi]; if(gid>=r->geometry_count)continue;
            const GCSemGeometry *geo=&r->geometries[gid]; if(geo->kind==2)continue;
            const GCSemPathOwner *paths=&geo->paths[attacker];
            for (uint16_t si=0; si<r->board_size*r->board_size; si++) {
                const GCPiece *actor=&pos->board[si]; if(!actor->occupied||actor->owner!=attacker||!pattern_has_type(pattern,actor->current_type))continue;
                if(geo->has_atom_source&&geo->atom_source_type!=actor->current_type)continue;
                const GCSemPathEntry *entry=NULL;if(!path_entry(geo,attacker,si,&entry))continue;
                for(uint16_t ti=0;ti<entry->count;ti++)if(entry->squares[ti]==target_square){uint16_t start=geo->min_steps>0?(uint16_t)(geo->min_steps-1):0;if(ti<start)continue;if(!path_ok(pattern,entry,ti,pos,attacker))continue;if(!state_guards_hold(r,pos,pattern,attacker,si,target_square,actor->base_type,actor->current_type))continue;if(!slot_guards_hold(r,pos,pattern,attacker,si,target_square))continue;return 1;}
            }
        }
    }
    return 0;
}

/* Exact action-witness semantics: the actor now at action.target must be the
 * piece attacking the reply-side anchor.  This is deliberately narrower than
 * semantic_attacked_by/in_check so discovered or pre-existing checks do not
 * satisfy action_delivers_check. */
static int semantic_action_delivers_check(const GCSemanticRules *r,
                                          const GCSemanticPosition *child,
                                          uint16_t actor_source,
                                          uint8_t actor_side) {
    if (!r || !child || actor_source >= r->board_size * r->board_size) return 0;
    uint16_t anchor = 0;
    int has_anchor = 0;
    for (uint16_t sq = 0; sq < r->board_size * r->board_size; sq++) {
        const GCPiece *piece = &child->board[sq];
        if (piece->occupied && piece->owner == (uint8_t)(1 - actor_side) &&
            r->types[piece->current_type].is_anchor) {
            anchor = sq;
            has_anchor = 1;
            break;
        }
    }
    if (!has_anchor) return 0;
    const GCPiece *actor = &child->board[actor_source];
    if (!actor->occupied || actor->owner != actor_side) return 0;
    for (uint16_t pi = 0; pi < r->pattern_count; pi++) {
        const GCSemPattern *pattern = &r->patterns[pi];
        if (pattern->target != 1 || !pattern_has_type(pattern, actor->current_type)) continue;
        for (uint8_t gi = 0; gi < pattern->geometry_count; gi++) {
            uint16_t gid = pattern->geometry_indices[gi];
            if (gid >= r->geometry_count) continue;
            const GCSemGeometry *geo = &r->geometries[gid];
            if (geo->kind == 2) continue;
            if (geo->has_atom_source && geo->atom_source_type != actor->current_type) continue;
            const GCSemPathEntry *entry = NULL;
            if (!path_entry(geo, actor_side, actor_source, &entry)) continue;
            for (uint16_t ti = 0; ti < entry->count; ti++) {
                if (entry->squares[ti] != anchor) continue;
                uint16_t start = geo->min_steps > 0 ? (uint16_t)(geo->min_steps - 1) : 0;
                if (ti < start) continue;
                if (!target_ok(pattern->target, &child->board[anchor], actor_side)) continue;
                if (!path_ok(pattern, entry, ti, child, actor_side)) continue;
                if (!state_guards_hold(r, child, pattern, actor_side,
                                       actor_source, anchor,
                                       actor->base_type, actor->current_type)) continue;
                if (!slot_guards_hold(r, child, pattern, actor_side,
                                      actor_source, anchor)) continue;
                return 1;
            }
        }
    }
    return 0;
}
static int invariants_hold(const GCSemanticRules *r, const GCSemanticPosition *parent, const GCSemanticPosition *child, const GCSemPattern *pattern, uint8_t side, uint16_t source, uint16_t target) {
    for(uint8_t i=0;i<pattern->invariant_count;i++) {
        const GCSemInvariant *inv=&pattern->invariants[i];
        if(inv->kind==0) {
            for(uint16_t sq=0;sq<r->board_size*r->board_size;sq++) if(child->board[sq].occupied&&child->board[sq].owner==side&&r->types[child->board[sq].current_type].is_anchor&&semantic_attacked_by(r,child,sq,1-side)) return 0;
        } else if(inv->kind==1) {
            for(uint16_t j=0;j<inv->refs_count;j++){uint16_t sq=0;if(!resolve_square(&inv->refs[j],r,NULL,parent,side,source,target,&sq))return 0;if(semantic_attacked_by(r,child,sq,1-side))return 0;}
        } else return 0;
    }
    return 1;
}
static int trigger_event_fires(const GCSemanticRules *r, const GCSemanticPosition *pre, const GCSemPattern *pattern, const GCSemTrigger *trigger, uint8_t side, uint8_t perspective, uint16_t source, uint16_t target) {
    uint16_t trigger_square = 0;
    if (!resolve_square(&trigger->square_ref, r, NULL, pre, perspective, source, target, &trigger_square)) return 0;
    for (uint8_t i = 0; i < pattern->effect_count; i++) {
        const GCSemEffect *effect = &pattern->effects[i];
        uint16_t effect_square = 0;
        if (trigger->event == 0 && (effect->kind == 0 || effect->kind == 9) &&
            resolve_square(&effect->from_ref, r, NULL, pre, perspective, source, target, &effect_square) && effect_square == trigger_square) {
            const GCPiece *piece = &pre->board[effect_square];
            if (piece->occupied && owner_ok(trigger->owner, piece->owner, perspective)) return 1;
        }
        if (trigger->event == 1 && effect->kind == 1 &&
            resolve_square(&effect->square_ref, r, NULL, pre, perspective, source, target, &effect_square) && effect_square == trigger_square) {
            const GCPiece *piece = &pre->board[effect_square];
            if (piece->occupied && owner_ok(trigger->owner, piece->owner, perspective)) return 1;
        }
    }
    return 0;
}

static int validate_action(const GCSemanticRules *r, const GCSemanticPosition *p, uint64_t a, const GCSemPattern **pattern_out, const GCSemGeometry **geo_out, uint16_t *source_out, uint16_t *target_out) {
    uint8_t kind=action_kind(a), side=p->side_to_move; uint16_t pattern_i=action_pattern(a), gid=action_geometry(a), source=action_from(a), target=action_to(a), base=action_base(a), current=action_current(a), promo=action_promo(a);
    if ((kind != GC_ACTION_KIND_SEMANTIC_BOARD && kind != GC_ACTION_KIND_SEMANTIC_DROP) || pattern_i >= r->pattern_count || gid >= r->geometry_count || target >= r->board_size*r->board_size) return 0;
    const GCSemPattern *pattern=&r->patterns[pattern_i]; const GCSemGeometry *geo=&r->geometries[gid]; int owns_geo=0; for(uint8_t i=0;i<pattern->geometry_count;i++)if(pattern->geometry_indices[i]==gid)owns_geo=1; if(!owns_geo)return 0;
    if (kind == GC_ACTION_KIND_SEMANTIC_DROP) {
        if (geo->kind != 2 || source != 255 || base >= r->type_count || current >= r->type_count || current != base || !pattern_has_type(pattern, base) || p->board[target].occupied || p->hand_counts[side][base] == 0) return 0;
        const GCSemSquareList *mask=&r->drop_mask[base][side]; int allowed=0; for(uint16_t i=0;i<mask->count;i++)if(mask->squares[i]==target)allowed=1; if(!allowed)return 0;
    } else {
        if (geo->kind == 2 || source >= r->board_size*r->board_size || source == target) return 0;
        const GCPiece *piece=&p->board[source]; if(!piece->occupied || piece->owner!=side || piece->base_type!=base || piece->current_type!=current || !pattern_has_type(pattern,current))return 0;
        if (geo->has_atom_source && geo->atom_source_type != current) return 0;
        const GCSemPathEntry *entry=NULL; if(!path_entry(geo,side,source,&entry))return 0; int found=-1; for(uint16_t i=0;i<entry->count;i++)if(entry->squares[i]==target){found=i;break;} if(found<0)return 0;
        uint16_t start=geo->min_steps>0?(uint16_t)(geo->min_steps-1):0; if((uint16_t)found<start || !target_ok(pattern->target,&p->board[target],side) || !path_ok(pattern,entry,(uint16_t)found,p,side))return 0;
    }
    if (!promotion_action_ok(r, pattern, side, base, kind == GC_ACTION_KIND_SEMANTIC_BOARD ? p->board[source].promoted : 0, source, target, promo)) return 0;
    if (!state_guards_hold(r, p, pattern, side, source, target, base, current) || !slot_guards_hold(r, p, pattern, side, source, target)) return 0;
    if(pattern_out)*pattern_out=pattern; if(geo_out)*geo_out=geo; if(source_out)*source_out=source; if(target_out)*target_out=target; return 1;
}

static int apply_effect(const GCSemanticRules *r, GCSemanticPosition *work, const GCSemanticPosition *pre, const GCSemPattern *unused_pattern, const GCSemEffect *effect, uint8_t side, uint16_t source, uint16_t target, uint16_t action_base_type, uint16_t action_current_type) {
    uint16_t from=0,to=0,square=0,tid=0; GCPiece piece;
    if(effect->kind==0 || effect->kind==9) { if(!resolve_square(&effect->from_ref,r,NULL,pre,side,source,target,&from)||!resolve_square(&effect->to_ref,r,NULL,pre,side,source,target,&to)||!work->board[from].occupied||work->board[to].occupied)return 0; piece=work->board[from]; if(effect->has_piece_type_ref&&!resolve_type(&effect->piece_type_ref,piece.base_type,piece.current_type,&tid))return 0; if(effect->has_piece_type_ref&&piece.base_type!=tid&&piece.current_type!=tid)return 0; if(!owner_ok(effect->piece_owner,piece.owner,side))return 0; work->board[from].occupied=0; work->board[to]=piece; return 1; }
    if(effect->kind==1) { if(!resolve_square(&effect->square_ref,r,NULL,pre,side,source,target,&square)||!work->board[square].occupied)return 0; piece=work->board[square]; if(r->types[piece.current_type].is_anchor)return 0; if(effect->has_piece_type_ref&&!resolve_type(&effect->piece_type_ref,piece.base_type,piece.current_type,&tid))return 0; if(effect->has_piece_type_ref&&piece.base_type!=tid&&piece.current_type!=tid)return 0; if(!owner_ok(effect->piece_owner,piece.owner,side))return 0; if(effect->has_disposition&&effect->disposition==0){if(work->hand_counts[side][piece.base_type]>=GC_MAX_HAND)return 0;work->hand_counts[side][piece.base_type]++;} work->board[square].occupied=0; return 1; }
    if(effect->kind==2) { if(!effect->has_piece_type_ref||!resolve_type(&effect->piece_type_ref,action_base_type,action_current_type,&tid)||work->hand_counts[side][tid]<effect->count)return 0; work->hand_counts[side][tid]-=effect->count; return 1; }
    if(effect->kind==3) { if(!resolve_square(&effect->to_ref,r,NULL,pre,side,source,target,&to)||work->board[to].occupied||!effect->has_piece_type_ref)return 0; if(!resolve_type(&effect->piece_type_ref,action_base_type,action_current_type,&tid)||tid>=r->type_count)return 0; memset(&work->board[to],0,sizeof(GCPiece));work->board[to].occupied=1;work->board[to].owner=side;work->board[to].base_type=tid;work->board[to].current_type=tid;return 1; }
    if(effect->kind==4) { if(!resolve_square(&effect->square_ref,r,NULL,pre,side,source,target,&square)||!work->board[square].occupied||!effect->has_type_ref||!resolve_type(&effect->type_ref,work->board[square].base_type,work->board[square].current_type,&tid)||tid>=r->type_count)return 0;work->board[square].current_type=tid;work->board[square].promoted=tid!=work->board[square].base_type;return 1; }
    return effect->kind>=5 && effect->kind<=8;
}

static uint64_t pack_semantic_action(uint16_t to, uint16_t from, uint16_t promo, uint16_t base, uint16_t current, uint8_t kind, uint16_t pattern, uint16_t geometry) {
    return ((uint64_t)to) | ((uint64_t)from << 8) | ((uint64_t)promo << 16) |
        ((uint64_t)base << 24) | ((uint64_t)kind << 32) |
        ((uint64_t)pattern << 36) | ((uint64_t)geometry << 44) |
        ((uint64_t)current << 56);
}

static int semantic_has_s3_reply(const GCSemanticRules *r, const GCSemanticPosition *position) {
    uint8_t side = position->side_to_move;
    for (uint16_t pi=0; pi<r->pattern_count; pi++) {
        const GCSemPattern *pattern=&r->patterns[pi];
        for (uint8_t gi=0; gi<pattern->geometry_count; gi++) {
            uint16_t gid=pattern->geometry_indices[gi]; if(gid>=r->geometry_count)continue;
            const GCSemGeometry *geo=&r->geometries[gid];
            if (geo->kind == 2) {
                for (uint8_t ti=0; ti<pattern->type_count; ti++) { uint16_t base=pattern->type_indices[ti]; if(base>=r->type_count||position->hand_counts[side][base]==0)continue; const GCSemSquareList *mask=&r->drop_mask[base][side]; for(uint16_t mi=0;mi<mask->count;mi++){uint16_t to=mask->squares[mi];if(position->board[to].occupied)continue;uint64_t action=pack_semantic_action(to,255,255,base,base,GC_ACTION_KIND_SEMANTIC_DROP,pi,gid);GCSemanticPosition child;if(gc_semantic_runtime_make_mode(&child,r,position,action,0))return 1;} }
            } else {
                const GCSemPathOwner *paths=&geo->paths[side];
        for(uint16_t source=0;source<r->board_size*r->board_size;source++){const GCPiece *piece=&position->board[source];if(!piece->occupied||piece->owner!=side||!pattern_has_type(pattern,piece->current_type))continue;if(geo->has_atom_source&&geo->atom_source_type!=piece->current_type)continue;const GCSemPathEntry *entry=NULL;if(!path_entry(geo,side,source,&entry))continue;uint16_t start=geo->min_steps>0?(uint16_t)(geo->min_steps-1):0;for(uint16_t ti=start;ti<entry->count;ti++){uint16_t to=entry->squares[ti];if(!target_ok(pattern->target,&position->board[to],side)||!path_ok(pattern,entry,ti,position,side))continue;if(!state_guards_hold(r,position,pattern,side,source,to,piece->base_type,piece->current_type)||!slot_guards_hold(r,position,pattern,side,source,to))continue;uint16_t promos[GC_MAX_PROMO_TARGETS+1];uint8_t promo_count=promotion_choices(r,pattern,side,piece->base_type,piece->promoted,source,to,promos);for(uint8_t promo_i=0;promo_i<promo_count;promo_i++){uint64_t action=pack_semantic_action(to,source,promos[promo_i],piece->base_type,piece->current_type,GC_ACTION_KIND_SEMANTIC_BOARD,pi,gid);GCSemanticPosition child;if(gc_semantic_runtime_make_mode(&child,r,position,action,0))return 1;}}}
            }
        }
    }
    return 0;
}

static int postconditions_hold(const GCSemanticRules *r, const GCSemanticPosition *child, const GCSemPattern *pattern, uint8_t actor_side, uint16_t actor_source) {
    if (gc_runtime_audit && pattern->postcondition_count > 0) gc_runtime_audit->s4_count++;
    int has_action_checked=0, has_checked=0, has_no_reply=0;
    for(uint8_t i=0;i<pattern->postcondition_count;i++){
        if(pattern->postconditions[i].kind==0)has_checked=1;
        else if(pattern->postconditions[i].kind==1)has_no_reply=1;
        else if(pattern->postconditions[i].kind==2)has_action_checked=1;
        else return 0;
    }
    if(!has_action_checked&&!has_checked&&!has_no_reply)return 1;
    if(has_action_checked && !semantic_action_delivers_check(r, child, actor_source, actor_side)) return 1;
    int opponent_checked=0;
    for(uint16_t sq=0;sq<r->board_size*r->board_size;sq++)if(child->board[sq].occupied&&child->board[sq].owner==(uint8_t)(1-actor_side)&&r->types[child->board[sq].current_type].is_anchor&&semantic_attacked_by(r,child,sq,actor_side)){opponent_checked=1;break;}
    if(has_checked&&!opponent_checked)return 1;
    if(has_no_reply) {
        if (gc_runtime_audit) gc_runtime_audit->nested_reply_count++;
        if (semantic_has_s3_reply(r,child)) return 1;
    }
    return 0;
}

static int gc_semantic_runtime_make_mode(GCSemanticPosition *child, const GCSemanticRules *r, const GCSemanticPosition *parent, uint64_t action, int include_postconditions) {
    if (gc_runtime_audit) gc_runtime_audit->s3_trial_count++;
    if(!child||!r||!parent||parent->ply>=r->max_ply)return 0; const GCSemPattern *pattern=NULL; const GCSemGeometry *geo=NULL; uint16_t source=0,target=0; if(!validate_action(r,parent,action,&pattern,&geo,&source,&target))return 0; (void)geo;
    GCSemanticPosition work;
    copy_live_position(&work, parent);
    uint8_t side=parent->side_to_move;
    for (uint8_t i = 0; i < r->aux_slot_count; i++) if (r->aux_slots[i].lifetime == 1) {
        reset_aux_value(&r->aux_slots[i], &work.aux[i][0], r->board_size);
        if (r->aux_slots[i].scope == 1) {
            reset_aux_value(&r->aux_slots[i], &work.aux[i][1], r->board_size);
            reset_aux_value(&r->aux_slots[i], &work.aux[i][2], r->board_size);
        }
    }
    uint16_t action_base_type=action_base(action), action_current_type=action_current(action);
    for(uint8_t i=0;i<pattern->effect_count;i++) if(!apply_effect(r,&work,parent,NULL,&pattern->effects[i],side,source,target,action_base_type,action_current_type)) return 0;
    uint16_t promo=action_promo(action); if(promo!=255&&action_kind(action)==GC_ACTION_KIND_SEMANTIC_BOARD&&work.board[target].occupied){work.board[target].current_type=promo;work.board[target].promoted=1;}
    if (!invariants_hold(r, parent, &work, pattern, side, source, target)) return 0;
    for (uint16_t i = 0; i < r->trigger_count; i++) {
        const GCSemTrigger *trigger = &r->triggers[i];
        uint8_t slot_index = 0; const GCSemAuxSlot *slot = slot_meta(r, trigger->slot_id, &slot_index); if (!slot) return 0;
        uint8_t first = slot->scope == 1 ? 1 : 0, last = slot->scope == 1 ? 2 : 0;
        for (uint8_t owner_index = first; owner_index <= last; owner_index++) {
            uint8_t perspective = slot->scope == 1 ? (uint8_t)(owner_index - 1) : side;
            if (!trigger_event_fires(r, parent, pattern, trigger, side, perspective, source, target)) continue;
            work.aux[slot_index][owner_index].kind = slot->value_kind;
            work.aux[slot_index][owner_index].has_value = 1;
            work.aux[slot_index][owner_index].supplied = 1;
            work.aux[slot_index][owner_index].bool_value = 0;
        }
    }
    for(uint8_t i=0;i<pattern->effect_count;i++){const GCSemEffect *e=&pattern->effects[i];if(e->kind<5||e->kind>8)continue;uint8_t slot_index=0;const GCSemAuxSlot *slot=slot_meta(r,e->slot_id,&slot_index);if(!slot)return 0;uint8_t owner_index=slot->scope==1?(uint8_t)(side+1):0;GCSemAuxValue *v=&work.aux[slot_index][owner_index];v->kind=slot->value_kind;v->has_value=1;v->supplied=1;if(e->kind==5)v->bool_value=e->has_value?e->value:0;else if(e->kind==6)v->bool_value=0;else if(e->kind==7){uint16_t sq;if(!resolve_square(&e->square_ref,r,NULL,parent,side,source,target,&sq))return 0;v->square=sq;}else v->has_value=0;}
    work.side_to_move=1-side;work.ply=parent->ply+1;if(include_postconditions&&!postconditions_hold(r,&work,pattern,side,target))return 0;if(gc_runtime_transient){copy_live_position(child,&work);return 1;}if(work.history_len>=GC_SEM_MAX_PLY+1)return 0;if(gc_runtime_audit)gc_runtime_audit->child_canonical_key_computations++;char digest[65];if(!gc_semantic_position_key_digest(r,&work,digest))return 0;uint64_t words[4]={0,0,0,0};for(int w=0;w<4;w++){for(int i=0;i<16;i++){char c=digest[w*16+i];uint8_t n=(uint8_t)(c>='0'&&c<='9'?c-'0':c-'a'+10);words[w]=(words[w]<<4)|n;}}work.history_lo[work.history_len]=words[0];work.history_hi[work.history_len]=words[1];memcpy(work.history_digest[work.history_len],words,sizeof(words));work.history_actor[work.history_len]=side;work.history_gave_check[work.history_len]=(uint8_t)gc_semantic_runtime_in_check(r,&work,1-side);work.history_exact=parent->history_exact;if(gc_runtime_audit)gc_runtime_audit->history_appends++;work.history_len++;copy_live_position(child,&work);return 1;
}

int gc_semantic_runtime_make_checked(GCSemanticPosition *child, const GCSemanticRules *r, const GCSemanticPosition *parent, uint64_t action) {
    return gc_semantic_runtime_make_mode(child, r, parent, action, 1);
}

int gc_semantic_runtime_action_delivers_check_debug(
    const GCSemanticRules *r, const GCSemanticPosition *parent, uint64_t action) {
    if (!r || !parent) return 0;
    GCSemanticPosition child;
    if (!gc_semantic_runtime_make_mode(&child, r, parent, action, 0)) return 0;
    return semantic_action_delivers_check(r, &child, action_to(action), parent->side_to_move);
}

int gc_semantic_runtime_in_check(const GCSemanticRules *r, const GCSemanticPosition *position, uint8_t side) {
    if (!r || !position || side > 1) return 0;
    for (uint16_t sq = 0; sq < r->board_size * r->board_size; sq++) {
        const GCPiece *piece = &position->board[sq];
        if (piece->occupied && piece->owner == side && piece->current_type < r->type_count && r->types[piece->current_type].is_anchor)
            return semantic_attacked_by(r, position, sq, (uint8_t)(1 - side));
    }
    return 0;
}

int gc_semantic_runtime_is_square_attacked(const GCSemanticRules *r,
                                           const GCSemanticPosition *position,
                                           uint16_t square,
                                           uint8_t by_owner) {
    if (!r || !position || by_owner > 1 || square >= r->board_size * r->board_size) return 0;
    return semantic_attacked_by(r, position, square, by_owner);
}

void gc_semantic_runtime_attacked_squares(const GCSemanticRules *r,
                                         const GCSemanticPosition *pos,
                                         uint8_t attacker,
                                         uint8_t out[GC_MAX_SQUARES]) {
    memset(out, 0, GC_MAX_SQUARES);
    if (!r || !pos || attacker > 1) return;
    for (uint16_t pi = 0; pi < r->pattern_count; ++pi) {
        const GCSemPattern *pattern = &r->patterns[pi];
        if (pattern->target != 1) continue;
        for (uint8_t gi = 0; gi < pattern->geometry_count; ++gi) {
            uint16_t gid = pattern->geometry_indices[gi];
            if (gid >= r->geometry_count) continue;
            const GCSemGeometry *geo = &r->geometries[gid];
            if (geo->kind == 2) continue;
            for (uint16_t source = 0; source < r->board_size * r->board_size; ++source) {
                const GCPiece *actor = &pos->board[source];
                if (!actor->occupied || actor->owner != attacker ||
                    !pattern_has_type(pattern, actor->current_type)) continue;
                if (geo->has_atom_source && geo->atom_source_type != actor->current_type) continue;
                const GCSemPathEntry *entry = NULL;
                if (!path_entry(geo, attacker, source, &entry)) continue;
                uint16_t start = geo->min_steps > 0 ? (uint16_t)(geo->min_steps - 1) : 0;
                for (uint16_t ti = start; ti < entry->count; ++ti) {
                    uint16_t target = entry->squares[ti];
                    if (out[target]) continue;
                    if (!path_ok(pattern, entry, ti, pos, attacker)) continue;
                    if (!state_guards_hold(r, pos, pattern, attacker, source, target,
                                           actor->base_type, actor->current_type)) continue;
                    if (!slot_guards_hold(r, pos, pattern, attacker, source, target)) continue;
                    out[target] = 1;
                }
            }
        }
    }
}

int gc_semantic_runtime_make_trusted(GCSemanticPosition *position, const GCSemanticRules *rules, uint64_t action, GCSemanticUndo *undo) {
    if (!position || !rules || !undo) return 0;
    GCSemanticPosition child;
    if (!gc_semantic_runtime_make_checked(&child, rules, position, action)) return 0;
    undo->saved = *position;
    *position = child;
    return 1;
}

void gc_semantic_runtime_unmake(GCSemanticPosition *position, const GCSemanticUndo *undo) {
    if (position && undo) *position = undo->saved;
}
