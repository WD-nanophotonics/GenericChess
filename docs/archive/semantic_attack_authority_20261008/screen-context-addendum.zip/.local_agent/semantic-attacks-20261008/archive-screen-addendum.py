import sys,json,hashlib,zipfile,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from scripts.research_record import write_record
p=Path(__file__).parent;dest=root/'docs/archive/semantic_attack_authority_20261008'
files=[p/name for name in ('screen-correlation.py','screen-correlation.json',
 'screen-reply.py','screen-reply.json','archive-screen-addendum.py')]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
package=dest/'screen-context-addendum.zip';members=[]
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  rel=f.relative_to(root).as_posix();z.write(f,rel)
  members.append({'original_path':rel,'bytes':f.stat().st_size,'sha256':sha(f)})
with tempfile.TemporaryDirectory(prefix='screen-extract-',dir=root/'.local_agent') as td:
 with zipfile.ZipFile(package) as z:z.extractall(td)
 for m in members:assert sha(Path(td)/m['original_path'])==m['sha256']
for name in ('screen-correlation','screen-reply'):
 assert json.loads((p/(name+'.json')).read_bytes())['producer_sha256']==sha(p/(name+'.py'))
write_record(dest/'screen-context-index.json',{'package':package.name,'package_sha256':sha(package),
 'members':members,'extracted_verified_members':len(members),'producer_pins_verified':2,
 'dependency':'Existing initial sources/raw packages contain cannon-mixture.json and required source closure. Restore in isolation atdb838cdccfc4e74016474f9bb0f4e26245884e7b. No raw Slack/private inputs or binaries.'})
compact=root/'docs/research/data/semantic_attack_authority_20261008.json'
r=json.loads(compact.read_bytes());a=json.loads((p/'screen-correlation.json').read_bytes());b=json.loads((p/'screen-reply.json').read_bytes())
r['screen_context_counterexample']={'archive_index':'../../archive/semantic_attack_authority_20261008/screen-context-index.json',
 'premise':'Two screen cells each marginal occupancy.5, same owner/type marginals, fixed source/target and anchors.',
 'fixed_target_probability':a['source_capture_probability'],
 'uniform_legal_reply_probability':b['mean_capture_after_reply'],
 'actual_reply_transitions':b['actual_reply_transitions'],
 'scope':'Eight initial Core source-specific legal capture checks; Native full maps separately match, not source attribution. Uniform legal reply within each cell then equal initial-cell weights; source loss retained as zero, enemy target tracked after movement. No selected material/behavior law, WDL or human fitting. Correlation can reverse relative conditional opportunity even after this declared response.'}
write_record(compact,r)
print({'members_verified':len(members),'reply_transitions':b['actual_reply_transitions']})
