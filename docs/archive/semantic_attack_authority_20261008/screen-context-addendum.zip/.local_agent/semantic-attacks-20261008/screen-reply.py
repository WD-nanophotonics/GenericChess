"""One declared uniform legal opponent reply, retaining actor-loss outcomes."""
import sys,json,hashlib,itertools
from dataclasses import replace
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from scripts.research_record import write_record
p=Path(__file__).parent;source=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json'
c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(source.read_bytes())['definition']))
engine=SemanticEngine(c);template=GameSession(c).state.position;rows=[]
for actor in ('C','R'):
 for bits in itertools.product((0,1),repeat=2):
  board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K')
  board[24]=Piece(0,actor,actor);board[27]=Piece(1,'R','R')
  for square,occupied in zip((25,26),bits):
   if occupied:board[square]=Piece(0,'C','C')
  position=replace(template,board=tuple(board),side_to_move=1)
  replies=engine.legal_actions(position);outcomes=[]
  for reply in replies:
   child=engine.apply(position,reply)
   alive=child.board[24] is not None and child.board[24].owner==0
   targets=[i for i,piece in enumerate(child.board) if piece is not None and piece.owner==1 and piece.current_type_id=='R']
   assert len(targets)==1
   available=alive and any(a.source==24 and a.target==targets[0] for a in engine.legal_actions(child))
   outcomes.append({'reply':repr(reply),'source_alive':alive,'target':targets[0],
    'source_capture_available':bool(available)})
  assert replies
  rows.append({'actor':actor,'screens':bits,'replies':len(replies),
   'capture_probability':sum(x['source_capture_available'] for x in outcomes)/len(outcomes),
   'survival_probability':sum(x['source_alive'] for x in outcomes)/len(outcomes),'outcomes':outcomes})
  print(actor,bits,rows[-1]['replies'],rows[-1]['capture_probability'],flush=True)
laws={'correlated':[(0,0),(1,1)],'anti_correlated':[(0,1),(1,0)],
 'independent':list(itertools.product((0,1),repeat=2))}
means={name:{actor:sum(x['capture_probability'] for x in rows
 if x['actor']==actor and tuple(x['screens']) in masks)/len(masks)
 for actor in ('C','R')} for name,masks in laws.items()}
write_record(p/'screen-reply.json',{'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'dependency_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'declaration':'Changed premise after fixed-target screen witness: same eight initial cells, now opponent to move and uniformly choose one legal Core action within each cell. Then ask whether surviving source at24 has a legal capture of the unique enemyR at its actual new square. Retain source losses as zero, not conditional survival filtering. Initial context laws stay equal-mask weights; do not pool unequal action counts across cells. No favorable response selection, search or material fit; this declared behavior law is not uniquely implied by rules. Max512reply transitions; stop if exhausted rather than extend.',
 'actual_reply_transitions':sum(x['replies'] for x in rows),'rows':rows,
 'mean_capture_after_reply':means,'scope':'One-ply conditional future capture, not WDL/utility/material price or independent deployment.'})
assert sum(x['replies'] for x in rows)<=512
print(means)
