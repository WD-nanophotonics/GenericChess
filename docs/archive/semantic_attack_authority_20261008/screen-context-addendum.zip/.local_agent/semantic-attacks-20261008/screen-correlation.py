"""Same occupancy marginals, different screen dependence: no density fitting."""
import sys,json,hashlib,itertools
from dataclasses import replace
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.core.semantic_executor import SemanticEngine
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.semantic import pack_current_position,attacked_squares
from scripts.research_record import write_record
p=Path(__file__).parent;source=root/'.local_agent/semantic-candidate-20261008/cannon-mixture.json'
c=compile_ruleset_for_execution(ruleset_from_dict(json.loads(source.read_bytes())['definition']))
engine=SemanticEngine(c);native=compile_native_semantic_rules(c);template=GameSession(c).state.position
rows=[]
for actor in ('C','R'):
 for bits in itertools.product((0,1),repeat=2):
  board=[None]*64;board[0]=Piece(0,'K','K');board[63]=Piece(1,'K','K')
  board[24]=Piece(0,actor,actor);board[27]=Piece(1,'R','R')
  for square,occupied in zip((25,26),bits):
   if occupied:board[square]=Piece(0,'C','C')
  position=replace(template,board=tuple(board),side_to_move=0)
  actions=[a for a in engine.legal_actions(position) if a.source==24 and a.target==27]
  core=engine.is_square_attacked(position,27,0)
  packed=pack_current_position(native,position,ply_count=0)
  actual_native=27 in attacked_squares(native,packed,0)
  # Other friendly screen actors can attack27 too! Query actor-only authority
  # using scalar path geometry rather than attributing the whole map to24.
  # Here screens are C: an adjacent screen can itself supply another screen.
  # Full-map parity is still checked; source-specific evidence is legal actions.
  assert core==actual_native
  expected=sum(bits)==(1 if actor=='C' else 0)
  assert bool(actions)==expected
  rows.append({'actor':actor,'screens':bits,'source_capture_legal':bool(actions),
    'full_map_core_native_agree':True,'full_map_target_attacked':core})
laws={'correlated':[(0,0),(1,1)],'anti_correlated':[(0,1),(1,0)],
 'independent':list(itertools.product((0,1),repeat=2))}
results={name:{actor:sum(x['source_capture_legal'] for x in rows
 if x['actor']==actor and tuple(x['screens']) in masks)/len(masks)
 for actor in ('C','R')} for name,masks in laws.items()}
assert results=={'correlated':{'C':0.,'R':.5},'anti_correlated':{'C':1.,'R':0.},'independent':{'C':.5,'R':.25}}
write_record(p/'screen-correlation.json',{'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'dependency_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'declaration':'Changed premise after C/R quiet-dominance localization: conditional endpoint capture with fixed actor/target, two friendly screen cells each marginal occupancy.5. Correlated00/11, anti-correlated01/10, independentall4. Freeze these laws before8Core legal-capture checks; Native only full attack-map parity, not source-attribution. No material fitting/price change, no extra search. Other cells identical, endpoints excluded from marginal-density claim.',
 'rows':rows,'laws':laws,'source_capture_probability':results,
 'conclusion':'Same per-cell owner/type marginals do not determine screen dependence or relative conditional capture opportunity. Independent density law gives neither correlation extreme. This does not select a deployed behavior/context law or refute a declared independent proxy; it identifies a concrete missing assumption to test next.'})
print(results)
