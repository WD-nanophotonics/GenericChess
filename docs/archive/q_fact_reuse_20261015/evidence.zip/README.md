# Native q fact-reuse evidence

Only reviewed Agent scientific sources/generated inputs/results and technical
summaries. No raw Slack/account/private user inputs, host logs, receipts,
credentials, test temporary trees or binary images are published.

Extract under .local_agent/q-cost-20261014 in an ISOLATED checkout based on
sandbox a75012717b5659a9c4f5ae1e644661428e3dd430. Native source files are complete
snapshots; build_* scripts use the tracked companion C/headers and installed
compatible Python/Zig, custom NATIVE_BUILD_OUT. Do not install another Agent's
checkout. Original image SHA256 binds observations; binaries are intentionally
excluded. Rebuilt binary byte identity is not promised across build paths/tools.
The shipped C is exactly reuse-native_module.c; Python evaluator/API unchanged.

Dependency: prior docs/archive/native_complete_q_20261014/evidence.zip SHA256
b5a895513424fa80f2191c2a6886e64466e681a66a55afb3e2aa151e1a4a7ff3, extract
under .local_agent/neutral-order-20261014. Its README gives prior immutable
full-backend archive SHA71bb744ba055eadc45de01a04ffec49894490e205a6ad2bfa823aeb06e53cfa1
and actual played semantic/fallback fixtures. All helper imports are relative
project paths, not claims Dot can read PRIMARY local files.

build_q_cost.py is the exact instrumentation builder, originally one directory
above this evidence directory; its internal output paths are unchanged.
counts/timed modules are private instrumentation only. Counters measure actual
outer q components; timed transition/terminal include internal work and clock
overhead. No production profiling API added. No persistent facts/cache/TT change.

Count probes150recorded+10declines; fixed156+8declines; rawimport24successful+
8expectedlegacy refusals; fresh352+32declines, plus23 independent finite branches.
qpolicy and its all-action branch totals are in the compact index/summaries.
All recorded caps/declarations and censors remain unchanged. Same-work scores/
PVs/counters agree; timing samples and shallow finite-objective labels are not
WDL or guaranteed stronger play. The20ms aggregate is posthoc scale sensitivity,
ALL78pairs/negative/tiny cases are retained. Source/code/debug checks are not
new independent games or new unexposed validation.

Raw-import first driver fails before any search (tuple versus list cell carrier),
then only representation is corrected. Other source-prep/transport failures are
summarized in failures.json with no false engine-failure attribution. Exact raw
local originals remain private. AUX49 assessment is PRIMARY's report reading/
arithmetic, not raw policy/oracle/training reproduction. CHAT comment was against
old source; current b904 fix and six current regressions already cover it.

UTC start2026-10-14 corresponds to local23:41; final local research date is
2026-10-15 Asia/Tokyo. Native inspection automation stays PAUSED; user separately
resumed this research. No new Agent, workers, scheduler or learning jobs.
