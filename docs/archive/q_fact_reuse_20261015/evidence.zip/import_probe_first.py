from pathlib import Path
b=Path('.local_agent/q-cost-20261014');exec(compile((b/'common.py').read_text(encoding='utf-8'),str(b/'common.py'),'exec'))
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import snapshot,pack_position
selected=[x for x in semantic_cases()if x[0]in ['transformed_live_aux','checked_NO_CONTEST']];assert len(selected)==2
assert not(b/'import-declaration.json').exists();write_record(b/'import-declaration.json',dict(question='Does local fresh-event reuse accidentally trust imported legacy/inexact or stale root check facts?',cases=[x[0]for x in selected],carriers=['full6','digest4','legacy2','flipped-root-last-event6'],q=[1,4],conditions='Actual rawC call below publicfullhistory transport; sameperrulepurestatic values;D2,maxnodes16384,5s cap,TT0,fullrootwindow; comparefullbase/reuse outputexcludingtiming,expectedlegacy2 refusal retained. Rawpack explicitly doesnot authenticate reachability; flippedroot eventisadversarialcallerinput notgameevidence.',decision='Anyincompatiblebase/reuse fulltuple/error classchange diagnosesbefore shipping; fresh children mustown newevents, olderinexact historiesliteralfallback.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
rows=[]
for name,c,s,v,h in selected:
 for mode in ['full6','digest4','legacy2','flipped-root-last-event6']:
  for q in [1,4]:
   for arm in ['base','reuse']:
    p.rr.stopped();native._MODULE=mods[arm];e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);packed=pack_semantic_search_position(c,e._native_rules,s);snap=snapshot(e._native_rules,packed)
    hist=[list(a)+[ev[0],int(ev[1])]for a,ev in zip(snap['history'],snap['history_events'])]
    if mode=='digest4':hist=[x[:4]for x in hist]
    elif mode=='legacy2':hist=[x[:2]for x in hist]
    elif mode=='flipped-root-last-event6':hist[-1][-1]=1-hist[-1][-1]
    pos=pack_position(e._native_rules,dict(board=snap['board'],hands=snap['hands'],side=snap['side'],ply=snap['ply'],aux_state=s.state.position.aux_state,history=hist));before=snapshot(e._native_rules,pos);t=time.perf_counter()
    try:r=mods[arm].semantic_engine_search(e._capsule,pos,2,16384,5.0,None,None,True,False,q,8,None);row=dict(result=record_value(r))
    except (ValueError,RuntimeError)as error:row=dict(error_type=type(error).__name__,error=str(error))
    assert snapshot(e._native_rules,pos)==before;rows.append(dict(root=name,mode=mode,q=q,arm=arm,input_snapshot=before,**row,seconds=time.perf_counter()-t,root_unchanged=True));print(name,mode,q,arm,row.get('error_type'),row.get('result',{}).get('completed_depth'),flush=True)
write_record(b/'import-rows.json',dict(complete=True,rows=rows))
