from pathlib import Path
b=Path('.local_agent/q-cost-20261014');ns={'__name__':'not_run','__file__':str(b/'qgrid.py')};src=(b/'qgrid.py').read_text(encoding='utf-8');exec(compile(src.split("if mode=='run':")[0],str(b/'qgrid.py'),'exec'),ns);globals().update({k:v for k,v in ns.items()if not k.startswith('__')})
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.ai.alphabeta import search
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
out=b/'q2transfer';d=json.loads((out/'rows.json').read_text());assert d['complete'];assert not(out/'branch-rows.json').exists();selection={}
for row in d['rows']:
 r=row.get('result',{});a=r.get('action')
 if a is None:continue
 key=row['root'],json.dumps(a,sort_keys=True);selection.setdefault(key,dict(root=row['root'],action=a,origins=[]))['origins'].append(dict(seconds=row['seconds'],order=row['order'],requested_q=row['requested_q'],retained_q=r['result_ordinary_qdepth'],depth=r['completed_depth']))
assert len(selection)<=48,len(selection);write_record(out/'branch-declaration.json',dict(question='Do deliveredq1/q2/q4 chosenactions differ under a common literalCore finite objective?',selection='ALLdistinctboardactions acrossallpilotmethods/budgets/orders;declared5newrulepilot fixedbeforeqqueries; no winnerfilter',objective='RootD2: chosenaction thenliteralCore negamaxD1,ordinaryq4/hard8,first_main_iteration_completeTrue,rootrelativeply1. Identicalstaticboard/current+hand/base. TT/order/nativeproviders/tacticaloff. Approxfiniteobjective,notWDL/allrootmaxset.',cost='10s/50000totalvisits perdistinctbranch,max48/600sexternalfuse; noextension,censorUNKNOWN',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),branches=list(selection.values())))
class Static:
 def __init__(self,v,h):self.v=v;self.h=h
 def evaluate(self,st):
  pos=st.position;side=pos.side_to_move
  return sum((1 if x.owner==side else-1)*self.v[x.current_type_id]for x in pos.board if x)+sum((1 if o==side else-1)*self.h[t]*n for o,hand in enumerate(pos.hands)for t,n in hand.items())
 def type_value(self,t):return self.v[t]
 def capture_order_value(self,m,c):return 10*self.v[c.current_type_id]-self.v[m.current_type_id]
cases={x[0]:x for x in pilot_cases()};rows=[]
for _,item in selection.items():
 p.rr.stopped();name,c,s,v,h=cases[item['root']];a,=[a for a in legal_actions(s.state,c)if record_value(a)==item['action']];child=apply_action(s.state,a,c);rt=SearchPathRuntime.from_state(child,c,history_witnesses=s._search_witnesses+(child.position,));stats=SearchStatistics();rt.attach_stats(stats);lim=SearchLimits(max_time_seconds=10,max_nodes=50000,quiescence_max_depth=4,quiescence_hard_max_depth=8);ctx=search._Context(c,Static(v,h),TranspositionTable(),stats,search._Budget(lim,None),SearchTuning(use_root_tactical=False),False,False,4,8,None,runtime=rt,first_main_iteration_complete=True);start=time.perf_counter()
 try:
  answer=search.negamax(rt.state,1,-search.INF,search.INF,1,ctx);r=dict(**item,complete=True,root_value=-answer.score,child_answer=record_value(answer))
 except search.SearchAborted as error:r=dict(**item,complete=False,unknown_reason=str(error))
 finally:rt.assert_balanced()
 r.update(seconds=time.perf_counter()-start,nodes=stats.nodes,qnodes=stats.qnodes,runtime_balanced=True);rows.append(r);write_record(out/'branch-rows.json',dict(complete=False,rows=rows));print(name,r.get('root_value'),r.get('unknown_reason'),round(r['seconds'],3),flush=True)
write_record(out/'branch-rows.json',dict(complete=True,rows=rows))
