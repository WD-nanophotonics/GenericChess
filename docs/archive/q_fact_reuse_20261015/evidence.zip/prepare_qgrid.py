from pathlib import Path
b=Path('.local_agent/q-cost-20261014')
exec(compile((b/'common.py').read_text(encoding='utf-8'), str(b/'common.py'), 'exec'))
import random
from dataclasses import replace
from generic_chess.rules.serialization import serialize_ruleset
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.evaluation.config import EvaluationConfig
out = b/'q2transfer'
out.mkdir(exist_ok=True)
assert not (out/'declaration.json').exists()
seeds = list(range(2801,2806))
sizes = [4,8,12,16,18]
write_record(out/'declaration.json', dict(
 question='Can explicit q2 improve the finite-decision compromise between mixed q1 and q4 on new full-rule families?',
 premise='Previous q1 pilot completes deeper20/20 but common finite labels6positive/4negative/6tie/4unknown; no uniform q downgrade is supported. Changed prospective rules before any new policy query.',
 seeds=seeds,sizes=sizes,queried_root_plies=[8],saved_root_plies=[0,8],requested_q=[1,2,4],
 selection='Bilateral random/hybrid true, Random(seed+7000), reprsorted legal walk. Freeze rules/static profiles/actual played history before querying. No resampling early terminal;18 explicit.',
 conditions='Same completeNative fact-reuse kernel, TT0/plainorder, same per-rule static board/current and hand/base vectors. Explicit q1/q2/q4 allhard8, mainmax12,4/16s,forward/reversed q orders; actual retained q metadata; no silent downgrade or crosspolicy-score strength claim.',
 prediction='If q2 supplies noninferior common literalCoreD2/q4 choices versus both endpoints on this scoped cohort while completing requested q2 where q4 retains0, prioritize a larger independent route comparison. Mixed/negative/unknown outcomes keep policy explicit; no defaults or adaptive fit.',
 cost='At most4supportedroots*6queries*(4+16)=480s plus common setup;600s external fuse. Follow all distinct selected actions with literalCoreD2/q4,10s/50000visits each,max48/600s fuse. Combined expected<20min; no >1h job split, extraAgent, fees or training.',
 source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),C_source_sha256=hashlib.sha256((b/'reuse-native_module.c').read_bytes()).hexdigest()))
cache=EvaluationProfileCache(use_disk=False)
cfg=replace(EvaluationConfig(),dynamic_mobility_weight=0,anchor_escape_weight=0,promotion_potential_weight=0)
samples=[];setup=[]
for seed,size in zip(seeds,sizes):
 p.rr.stopped()
 g=p.generate_game(p.GeneratorConfig(seed=seed,board_size=size,setup_preset='bilateral_random',allow_hybrid=True))
 raw=p.compile_legacy_ruleset_for_semantic_execution(g.ruleset)
 c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support)
 prof,_=cache.get_or_build(c,cfg);setup.append(dict(seed=seed,profile=record_value(prof)))
 s=GameSession(c);rng=random.Random(seed+7000);walk=[]
 for ply in range(9):
  actions=tuple(s.legal_actions())
  if ply in [0,8]:
   samples.append(dict(name=f'{seed}-ply{ply}',seed=seed,ruleset=json.loads(serialize_ruleset(g.ruleset)),state=record_value(s.state),walk=walk.copy(),included=bool(actions),game_record=record_value(s.to_record()),legal_count=len(actions)))
  if ply==8:break
  if not actions:
   samples.append(dict(seed=seed,unavailable_ply=8,terminal_at=ply,resampled=False));break
  action=rng.choice(sorted(actions,key=repr));walk.append(record_value(action));s.submit(action)
 print('Frozen',seed,size,flush=True)
write_record(out/'samples.json',dict(complete=True,samples=samples,setup=setup))
