from pathlib import Path
import json,hashlib
b=Path('.local_agent/q-cost-20261014');s=(b/'base-native_module.c').read_text(encoding='utf-8');a=s.index('static int gc_semantic_quiescence(');z=s.index('static int gc_semantic_iterative_negamax(',a);q=s[a:z]
q=q.replace('unsigned qdepth,int alpha,int beta) {','unsigned qdepth,int alpha,int beta,\n                       int known_terminal,int known_winner) {',1)
q=q.replace('int winner=-1;','int winner=known_winner;',1).replace('int terminal=gc_semantic_terminal_status_known(ctx->rules,pos,&winner,known);','int terminal=known_terminal>=0 ? known_terminal : gc_semantic_terminal_status_known(ctx->rules,pos,&winner,known);',1)
q=q.replace('int check=gc_semantic_runtime_in_check(ctx->rules,pos,pos->side_to_move);','''/* Only a fresh fully checked edge owns this last gave-check event.
     * Imported roots and incomplete event histories retain the literal query. */
    int check=(ply>0 && pos->history_events_exact &&
               pos->history_len==ctx->stack[ply-1].history_len+1)
        ? pos->history_gave_check[pos->history_len-1]
        : gc_semantic_runtime_in_check(ctx->rules,pos,pos->side_to_move);''',1)
a1=q.index('        int noisy=check;');z1=q.index('        if(!noisy)continue;',a1)
q=q[:a1]+'''        int noisy=check,child_terminal=-1,child_winner=-1;
        if(!noisy){
            int enemies=0;
            for(unsigned j=0;j<cells;j++)if(child->board[j].occupied && child->board[j].owner!=pos->side_to_move)enemies++;
            noisy=enemies<parent_enemies || gc_semantic_inventory_changed(ctx->rules,pos,child);
            if(!noisy){
                int child_check=(child->history_events_exact &&
                    child->history_len==pos->history_len+1)
                    ? child->history_gave_check[child->history_len-1]
                    : gc_semantic_runtime_in_check(ctx->rules,child,child->side_to_move);
                if(child_check<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}
                noisy=child_check;
            }
            if(!noisy){
                child_terminal=gc_semantic_terminal_status_known(ctx->rules,child,&child_winner,child->history_digest[child->history_len-1]);
                if(child_terminal<0){ctx->control=4;gc_semantic_action_buffer_free(&actions);return 0;}
                noisy=child_terminal!=0;
            }
        }
'''+q[z1:]
q=q.replace('gc_semantic_quiescence(ctx,ply+1,qdepth+1,-beta,-alpha)','gc_semantic_quiescence(ctx,ply+1,qdepth+1,-beta,-alpha,child_terminal,child_winner)',1)
s=s[:a]+q+s[z:];s=s.replace('gc_semantic_quiescence(ctx, ply, 0, alpha, beta)','gc_semantic_quiescence(ctx, ply, 0, alpha, beta, -1, -1)',1)
(b/'reuse-native_module.c').write_bytes(s.encode());build=(b/'build_counts.py').read_text().replace('counts-native_module.c','reuse-native_module.c');(b/'build_reuse.py').write_bytes(build.encode())
(b/'reuse-source.json').write_bytes((json.dumps(dict(base_sha='a75012717b5659a9c4f5ae1e644661428e3dd430',base_sha256=hashlib.sha256((b/'base-native_module.c').read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256(s.encode()).hexdigest(),scope='Private source only: reuse existing fresh fullchecked child gave_check event at qentry/classification, checkevent first shortcircuit before quietterminal classifier, pass actual computed terminal+winner for immediate recursion. No persistentcache/TT/API/default change. Importedroot/inexactevents literalfallback. Terminal stillfirst at recursiveadjudication; no droppedstate/history.'),indent=2)+'\n').encode())
