from pathlib import Path
import sys,importlib.util,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));import generic_chess.native as n
spec=importlib.util.spec_from_file_location('generic_chess._native_core',ROOT/'.local_agent/q-cost-20261014/reuse.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);n._MODULE=m
import pytest
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--basetemp=.local_agent/q-cost-20261014/full-reuse']))
