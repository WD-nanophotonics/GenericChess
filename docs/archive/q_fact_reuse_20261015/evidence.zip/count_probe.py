from pathlib import Path
import sys,json,time,hashlib,importlib.util
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));b=ROOT/'.local_agent/q-cost-20261014';old=ROOT/'.local_agent/neutral-order-20261014'
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.ai.limits import SearchLimits
import generic_chess.native as native
base=native._module();mods={'base':base}
for name in ['counts','timed']:
 spec=importlib.util.spec_from_file_location('generic_chess._native_core',b/(name+'.pyd'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods[name]=m
class Tap:
 def __init__(self,m):self.m=m;self.last=None
 def __getattr__(self,k):return getattr(self.m,k)
 def semantic_engine_search(self,*a):self.last=self.m.semantic_engine_search(*a);return self.last
mods={k:Tap(v)for k,v in mods.items()}
data=json.loads((old/'generic-q4/samples.json').read_text(encoding='utf-8'));profiles={x['seed']:x['profile']for x in data['setup']}
assert not(b/'count-declaration.json').exists();write_record(b/'count-declaration.json',dict(question='Is nonrecursive q classification costly enough to favor exact terminal/check reuse or check-first classification over ordering?',base='a75012717b5659a9c4f5ae1e644661428e3dd430',cohort='ALL32 frozen generated2601-2616 playedroots,18decline explicit, noresample',conditions='All same actual rule-derived static board/current andhand/base; TT0/orderoff; q4/hard8,maxmain12,maxnodes1024,5s externalsearchcap. Bothorders base/counts thenonetimed perroot. Main+q visited work bound; hard/time censorspreserved. Timer scopefirst7components isexclusive except nested work insidefullchecked/terminal; notallCwork and noCPUexclusivity.',expected='32*5calls <=800s caller caps; practical~fewminutes, external1000sfuse. No single>1h run; noextraAgent.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),images={k:hashlib.sha256(Path(v.m.__file__).read_bytes()).hexdigest()for k,v in mods.items()}))
rows=[]
for x in data['samples']:
 if not x.get('included'):continue
 p.rr.stopped();raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
 for av in x['walk']:
  action,=[a for a in s.legal_actions()if record_value(a)==av];s.submit(action)
 assert record_value(s.state)==x['state'];prof=profiles[x['seed']]
 for order,arms in [(0,['base','counts']),(1,['counts','base']),(2,['timed'])]:
  for arm in arms:
   p.rr.stopped();native._MODULE=mods[arm];before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter()
   try:
    e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=prof['board_value_by_type'],hand_values=prof['hand_value_by_base_type'],tt_megabytes=0,ordering_cache_enabled=False)
    d=e.search(s,SearchLimits(max_depth=12,max_nodes=1024,max_time_seconds=5,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True)
    row=dict(root=x['name'],arm=arm,order=order,result=record_value(d),caller_seconds=time.perf_counter()-t,profile_calls=mods[arm].last.get('private_q_calls'),profile_ns=mods[arm].last.get('private_q_ns'),root_unchanged=before==(s.state,s.to_record(),s._search_witnesses));assert row['root_unchanged']
   except NativeUnsupportedRuleError as error:row=dict(root=x['name'],arm=arm,order=order,unsupported=str(error),actual_searches=0)
   rows.append(row);write_record(b/'count-rows.json',dict(complete=False,rows=rows));print(x['name'],arm,order,row.get('result',{}).get('completed_depth'),row.get('result',{}).get('termination_reason'),flush=True)
write_record(b/'count-rows.json',dict(complete=True,rows=rows));native._MODULE=base
