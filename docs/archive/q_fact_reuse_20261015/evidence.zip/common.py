from pathlib import Path
import sys,json,time,hashlib,importlib.util
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'tests/product')]
b=ROOT/'.local_agent/q-cost-20261014';old=ROOT/'.local_agent/neutral-order-20261014'
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value,write_record
from generic_chess.rules.serialization import deserialize_ruleset
from generic_chess.session.session import GameSession
from generic_chess.native import SemanticSearchEngine
from generic_chess.native.compiler import compile_native_semantic_rules,NativeUnsupportedRuleError
from generic_chess.ai.limits import SearchLimits
import generic_chess.native as native
base=native._module();spec=importlib.util.spec_from_file_location('generic_chess._native_core',b/'reuse.pyd');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);mods={'base':base,'reuse':m}
def generated_cases(path):
 data=json.loads(path.read_text(encoding='utf-8'));profiles={x['seed']:x['profile']for x in data['setup']};out=[]
 for x in data['samples']:
  if not x.get('included'):continue
  raw=p.compile_legacy_ruleset_for_semantic_execution(deserialize_ruleset(json.dumps(x['ruleset'])));c=p.SearchMetadataAdapter(ir=raw.ir,_legacy_compiled=raw._legacy_compiled,support=raw.support);s=GameSession(c)
  for av in x['walk']:
   action,=[a for a in s.legal_actions()if record_value(a)==av];s.submit(action)
  assert record_value(s.state)==x['state']and record_value(s.to_record())==x['game_record'];pr=profiles[x['seed']];out.append((x['name'],c,s,pr['board_value_by_type'],pr['hand_value_by_base_type']))
 return out
def semantic_cases():
 oldpath=ROOT/'.local_agent/full-backend-20261014';ns={'__file__':str(oldpath/'compare.py'),'__name__':'loader'};exec(compile((oldpath/'compare.py').read_text(encoding='utf-8').split("if mode=='prepare':")[0],str(oldpath/'compare.py'),'exec'),ns)
 return [(name,c,s,ns['Material'](c).v,ns['Material'](c).v)for name,c,s in ns['load_cases']()if not name[0].isdigit()]
def query(case,arm,depth,nodes,seconds):
 name,c,s,v,h=case;p.rr.stopped();native._MODULE=mods[arm];before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter()
 try:
  e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False);prep=time.perf_counter()-t;d=e.search(s,SearchLimits(max_depth=depth,max_nodes=nodes,max_time_seconds=seconds,quiescence_max_depth=4,quiescence_hard_max_depth=8),root_window_pruning=True)
  row=dict(result=record_value(d),caller_seconds=time.perf_counter()-t,prepare_seconds=prep,root_unchanged=before==(s.state,s.to_record(),s._search_witnesses));assert row['root_unchanged'];return row
 except NativeUnsupportedRuleError as error:return dict(unsupported=str(error),actual_searches=0)
