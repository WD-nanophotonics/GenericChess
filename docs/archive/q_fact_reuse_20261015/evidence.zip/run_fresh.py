from pathlib import Path
b=Path('.local_agent/q-cost-20261014');exec(compile((b/'common.py').read_text(encoding='utf-8'),str(b/'common.py'),'exec'))
out=b/'fresh';assert not(out/'rows.json').exists()and not(out/'rows.jsonl').exists();cases=generated_cases(out/'samples.json');rows=[];start=time.perf_counter()
for mode,seconds,depth in [('fixed',5,2),('resource',1,12),('resource',4,12),('resource',16,12)]:
 for case in cases:
  for order in range(2):
   for arm in (['base','reuse']if order==0 else['reuse','base']):
    row=dict(root=case[0],mode=mode,seconds=seconds,order=order,arm=arm,**query(case,arm,depth,None,seconds));rows.append(row)
    with (out/'rows.jsonl').open('a',encoding='utf-8')as f:f.write(json.dumps(row)+'\n');f.flush()
    print(case[0],mode,seconds,order,arm,row.get('result',{}).get('completed_depth'),row.get('result',{}).get('termination_reason'),flush=True)
write_record(out/'rows.json',dict(complete=True,rows=rows,producer_seconds=time.perf_counter()-start));print('COMPLETE',len(rows),time.perf_counter()-start,flush=True)
