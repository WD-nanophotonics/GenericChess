from pathlib import Path
b=Path('.local_agent/q-cost-20261014');exec(compile((b/'common.py').read_text(encoding='utf-8'),str(b/'common.py'),'exec'))
assert not(b/'fixed-declaration.json').exists();write_record(b/'fixed-declaration.json',dict(question='Can exact freshlychecked event/terminal reuse reduce same q4 work cost without changing supported decisions/control?',base='a75012717b5659a9c4f5ae1e644661428e3dd430',cohort='ALL32 existinggenerated roots plusALL9 nonnumeric semantic/checkedNC fixtures from prior fullbackend;18 explicit',conditions='Base/reuse same node cap16384, mainmax3,q4/hard8,8s cap,two oppositeorders; TT0/plainorder,actualsamepurestaticleafvector,fullhistory. Fixed visit/tree/PV tuples mustmatch excepttimecensored; no budgetextensions.',cost='Upper41roots*4*8s=1312s plussetup; single1800sfuse, noextraAgent, below1hr. Test58actualguards already pass.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),images={k:hashlib.sha256(Path(v.__file__).read_bytes()).hexdigest()for k,v in mods.items()}));cases=generated_cases(old/'generic-q4/samples.json')+semantic_cases();rows=[]
for case in cases:
 for order in range(2):
  for arm in (['base','reuse']if order==0 else['reuse','base']):
   r=dict(root=case[0],order=order,arm=arm,**query(case,arm,3,16384,8));rows.append(r);write_record(b/'fixed-rows.json',dict(complete=False,rows=rows));print(case[0],order,arm,r.get('result',{}).get('completed_depth'),r.get('result',{}).get('termination_reason'),flush=True)
write_record(b/'fixed-rows.json',dict(complete=True,rows=rows))
