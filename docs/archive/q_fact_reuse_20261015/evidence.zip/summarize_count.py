from pathlib import Path
import json,math,statistics
b=Path('.local_agent/q-cost-20261014');d=json.loads((b/'count-rows.json').read_text());assert d['complete'];rows=d['rows'];pairs=[]
keys=['score','action','declaration_id','principal_variation','decision_line','nodes','qnodes','completed_depth','selective_depth','termination_reason','result_ordinary_qdepth','result_check_hard_qdepth','transition_count','legal_generation_count']
for root in sorted({x['root']for x in rows}):
 for order in [0,1]:
  p={x['arm']:x for x in rows if x['root']==root and x['order']==order}
  if 'result'not in p['base']:continue
  a,z=p['base'],p['counts'];diff=[k for k in keys if a['result'].get(k)!=z['result'].get(k)];pairs.append(dict(root=root,order=order,diff=diff,counts_caller_ratio=z['caller_seconds']/a['caller_seconds']))
t=[x for x in rows if x['arm']=='timed'and'result'in x];calls=[sum(x['profile_calls'][i]for x in t)for i in range(12)];ns=[sum(x['profile_ns'][i]for x in t)for i in range(7)];elapsed=sum(x['result']['elapsed_seconds']for x in t);names=json.loads((b/'source-manifest.json').read_text())['count_names'];out=dict(complete=True,actual_queries=sum('result'in x for x in rows),unsupported_cells=sum('unsupported'in x for x in rows),samework_pairs=len(pairs),different_pairs=[x for x in pairs if x['diff']],count_only_caller_geomean=math.exp(statistics.mean(math.log(x['counts_caller_ratio'])for x in pairs)),count_names=names,timed_calls=calls,timed_nanoseconds=ns,timed_kernel_seconds=elapsed,component_kernel_fractions=[v/1e9/elapsed for v in ns],pairs=pairs,scope='Timer perturbation and ordinary load; first7 disjoint top-level q components only, fullchecked/terminal include internal work. Not allCwork, no universalfactor. Samework main+q caps/no timecensored tuples required for ratios.');(b/'count-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='pairs'},indent=2))
