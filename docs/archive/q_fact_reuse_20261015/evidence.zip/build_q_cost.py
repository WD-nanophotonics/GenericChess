from pathlib import Path
import json,hashlib
b=Path('.local_agent/q-cost-20261014');b.mkdir(exist_ok=True)
s=Path('generic_chess/_native/native_module.c').read_text(encoding='utf-8');(b/'base-native_module.c').write_bytes(s.encode());(b/'base-semantic_engine.py').write_bytes(Path('generic_chess/native/semantic_engine.py').read_bytes())
for timed in [False,True]:
 src=s.replace('uint64_t qnodes;','uint64_t qnodes;\n    uint64_t private_q_calls[12], private_q_ns[7];',1)
 a=src.index('static int gc_semantic_quiescence(');z=src.index('static int gc_semantic_iterative_negamax(',a);q=src[a:z]
 def wrap(stmt,k):
  assert stmt in q,stmt
  return ('uint64_t qt'+str(k)+'=gc_monotonic_ns();' if timed else '')+stmt+'ctx->private_q_calls['+str(k)+']++;'+('ctx->private_q_ns['+str(k)+']+=gc_monotonic_ns()-qt'+str(k)+';'if timed else'')
 for stmt,k in [('int terminal=gc_semantic_terminal_status_known(ctx->rules,pos,&winner,known);',0),('int check=gc_semantic_runtime_in_check(ctx->rules,pos,pos->side_to_move);',1),('int made=gc_semantic_runtime_make_checked_status(child,ctx->rules,pos,actions.data[i]);',2),('noisy=enemies<parent_enemies || gc_semantic_inventory_changed(ctx->rules,pos,child);',3),('int ended=gc_semantic_terminal_status_known(ctx->rules,child,&child_winner,child->history_digest[child->history_len-1]);',4),('int child_check=gc_semantic_runtime_in_check(ctx->rules,child,child->side_to_move);',5)]:q=q.replace(stmt,wrap(stmt,k),1)
 q=q.replace('if(!gc_semantic_generate_candidate_buffer(ctx->rules,pos,&actions)){','uint64_t qt6=gc_monotonic_ns();\n    if(!gc_semantic_generate_candidate_buffer(ctx->rules,pos,&actions)){',1)if timed else q
 q=q.replace('ctx->legal_generation_count++;','ctx->legal_generation_count++;ctx->private_q_calls[6]++;'+('ctx->private_q_ns[6]+=gc_monotonic_ns()-qt6;'if timed else''),1)
 q=q.replace('for(size_t i=0;i<actions.count;i++){','ctx->private_q_calls[7]++;ctx->private_q_calls[8]+=actions.count;\n    for(size_t i=0;i<actions.count;i++){',1).replace('ctx->transition_count++;legal++;','ctx->transition_count++;legal++;ctx->private_q_calls[9]++;',1).replace('int score=-gc_semantic_quiescence','ctx->private_q_calls[10]++;if(check)ctx->private_q_calls[11]++;\n        int score=-gc_semantic_quiescence',1)
 src=src[:a]+q+src[z:]
 needle='    PyObject *training_trace = ctx.trace_enabled';assert needle in src
 export='''    PyObject *private_calls=PyList_New(12),*private_ns=PyList_New(7);
    if(!private_calls || !private_ns){Py_XDECREF(private_calls);Py_XDECREF(private_ns);Py_DECREF(out);return NULL;}
    for(int pi=0;pi<12;pi++)PyList_SET_ITEM(private_calls,pi,PyLong_FromUnsignedLongLong(ctx.private_q_calls[pi]));
    for(int pi=0;pi<7;pi++)PyList_SET_ITEM(private_ns,pi,PyLong_FromUnsignedLongLong(ctx.private_q_ns[pi]));
    PyDict_SetItemString(out,"private_q_calls",private_calls);PyDict_SetItemString(out,"private_q_ns",private_ns);
    Py_DECREF(private_calls);Py_DECREF(private_ns);
'''
 src=src.replace(needle,export+needle,1);name='timed'if timed else'counts';(b/(name+'-native_module.c')).write_bytes(src.encode())
 build=Path('.local_agent/neutral-order-20261014/q-prototype/build.py').read_text(encoding='utf-8').replace('.local_agent/neutral-order-20261014/q-prototype/native_module.c','.local_agent/q-cost-20261014/'+name+'-native_module.c');(b/('build_'+name+'.py')).write_bytes(build.encode())
(b/'source-manifest.json').write_bytes((json.dumps(dict(base_sha='a75012717b5659a9c4f5ae1e644661428e3dd430',sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in b.glob('*.c')},count_names=['entry_terminal','entry_check','checked_make','inventory_predicate','classification_terminal','classification_check','candidate_generation','expanded_q_nodes','generated_candidate_sum','successful_q_checked','q_recursions','checked_evasion_recursions'],nanoseconds_for_first7=True,scope='Private noninstalled instrumentation only. Timer overhead exists; count-only paired work comparison validates semantics. Full checked/history remains; no defaultchange.'),indent=2)+'\n').encode())
