from pathlib import Path
b=Path('.local_agent/q-cost-20261014')
exec(compile((b/'common.py').read_text(encoding='utf-8'), str(b/'common.py'), 'exec'))
out=b/'q2transfer'
mode=sys.argv[1] if len(sys.argv)>1 else 'run'
def pilot_cases():
 return [x for x in generated_cases(out/'samples.json') if x[0].endswith('-ply8')]
if mode=='run':
 assert not (out/'rows.jsonl').exists()
 write_record(out/'execution-binding.json',dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),common_sha256=hashlib.sha256((b/'common.py').read_bytes()).hexdigest(),image_sha256=hashlib.sha256(Path(mods['reuse'].__file__).read_bytes()).hexdigest()))
 rows=[];start=time.perf_counter();native._MODULE=mods['reuse']
 for name,c,s,v,h in pilot_cases():
  for seconds in [4,16]:
   for order in range(2):
    for q in ([1,2,4] if order==0 else [4,2,1]):
     p.rr.stopped();before=s.state,s.to_record(),s._search_witnesses;t=time.perf_counter()
     try:
      e=SemanticSearchEngine(c,compile_native_semantic_rules(c),board_values=v,hand_values=h,tt_megabytes=0,ordering_cache_enabled=False)
      prep=time.perf_counter()-t
      d=e.search(s,SearchLimits(max_depth=12,max_time_seconds=seconds,quiescence_max_depth=q,quiescence_hard_max_depth=8),root_window_pruning=True)
      row=dict(root=name,seconds=seconds,order=order,requested_q=q,result=record_value(d),prepare_seconds=prep,caller_seconds=time.perf_counter()-t,root_unchanged=before==(s.state,s.to_record(),s._search_witnesses));assert row['root_unchanged']
     except NativeUnsupportedRuleError as error:
      row=dict(root=name,seconds=seconds,order=order,requested_q=q,unsupported=str(error),actual_searches=0)
     rows.append(row)
     with (out/'rows.jsonl').open('a',encoding='utf-8') as f:
      f.write(json.dumps(row)+'\n');f.flush()
     print(name,seconds,order,q,row.get('result',{}).get('completed_depth'),row.get('result',{}).get('result_ordinary_qdepth'),row.get('result',{}).get('termination_reason'),flush=True)
 write_record(out/'rows.json',dict(complete=True,rows=rows,producer_seconds=time.perf_counter()-start))
 print('COMPLETE',len(rows),time.perf_counter()-start,flush=True)
