from pathlib import Path
import json
b=Path('.local_agent/q-cost-20261014');d=json.loads((b/'import-rows.json').read_text());assert d['complete'];rows=d['rows'];pairs=[]
for key in sorted({(r['root'],r['mode'],r['q'])for r in rows}):
 p={r['arm']:r for r in rows if(r['root'],r['mode'],r['q'])==key};a,z=p['base'],p['reuse']
 if 'result'in a:
  diff=[k for k in a['result']if k!='elapsed_nanoseconds'and a['result'][k]!=z['result'][k]];assert not diff,(key,diff)
 else:assert (a['error_type'],a['error'])==(z['error_type'],z['error'])
 pairs.append(dict(root=key[0],mode=key[1],q=key[2],same=True,error='error'in a))
out=dict(complete=True,raw_C_call_attempts=len(rows),successful_searches=sum('result'in r for r in rows),expected_legacy_transport_refusals=sum('error'in r for r in rows),matching_pairs=len(pairs),all_input_capsules_unchanged=all(r['root_unchanged']for r in rows),pairs=pairs,scope='Two fullplayedsemantic roots, notallrawimports; adversarialflippedroot eventisprovidedtransport notauthenticgamehistory. Full/digest-only legitimatecapabilities preserved; projectedtwo-wordterminalrefusals unchanged. Beforefirstsearch packingdriverfailure zeroqueries separatelypreserved.')
(b/'import-summary.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print({k:v for k,v in out.items()if k!='pairs'})
