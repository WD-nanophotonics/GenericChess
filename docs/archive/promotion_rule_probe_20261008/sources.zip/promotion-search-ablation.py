"""Observed finite-outcome search cost controls; no product behavior changes."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'promotion-law-completed.json').read_bytes();old=json.loads(raw);out=p/'promotion-search-ablation.json';assert not out.exists();started=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='All8 prior roots xqueen-only/all-choices x4/8/12plies x3 ablations: ordering-only, proof-only, both. Same200000calls/30sec cell ceilings, serial, no selected outcomes dropped. Geometric ordering uses mean empty-board target mobility, not human prices. Proven terminal +/-1 results persist only within one exact3piece rule/root; stored upper bound on forced-win plies allows reuse when requested horizon>=bound. Zero results are never sufficient-depth reusable. Occupancy projection is restricted to this declared no-aux, repetition100000/maxply1000 horizon<=12 subset. Output is finite outcome plus a legal representative terminal line, not a full all-defense certificate or generic score-cache contract.',rows=[])
write_record(out,r)
class Fuse(RuntimeError):pass
for original in old['rows']:
 if original['mode'] not in ('queen_only','all_choices'):continue
 c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));n=compile_native_semantic_rules(c);root=pack_semantic_search_position(c,n,GameSession(c))
 mobility={tid:sum(len(x) for x in c.empty_mobility[tid][0])/64 for tid in c.types_by_id}
 for ablation in ('ordering_only','proof_only','both'):
  proof={};row=dict(context=original['context'],mode=original['mode'],ablation=ablation,target_empty_mobility=mobility,cells=[]);r['rows'].append(row)
  for depth in (4,8,12):
   assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
   cell=dict(depth=depth,complete=False,calls=0,transitions=0,cache_hits=0,proof_hits=0,terminal_nodes=0,extreme_cutoffs=0);cache={};t=time.perf_counter()
   def solve(pos,left):
    cell['calls']+=1
    if cell['calls']%1000==0:assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
    if cell['calls']>200000 or time.perf_counter()-t>30:raise Fuse()
    v=snapshot(n,pos);state_key=(tuple((i,*x) for i,x in enumerate(v['board']) if x is not None),v['side']);key=(state_key,left)
    if key in cache:cell['cache_hits']+=1;return cache[key]
    if ablation!='ordering_only' and state_key in proof and proof[state_key][2]<=left:cell['proof_hits']+=1;return proof[state_key]
    terminal=terminal_status(n,pos)
    if terminal['status']!='ongoing':
     cell['terminal_nodes']+=1;value=0 if terminal['winner'] is None else (1 if terminal['winner']==0 else -1);result=(value,(),0 if value else None);cache[key]=result
     if value and ablation!='ordering_only':proof[state_key]=result
     return result
    if left==0:cache[key]=(0,(),None);return cache[key]
    maximize=v['side']==0;best=-2 if maximize else 2;line=();children=[]
    def ordering(a):
     pub=public_action(n,a);tid=pub.promotion_target_id
     return (tid is None,-mobility[tid] if tid is not None and ablation!='proof_only' else 0,str(pub))
    aa=sorted(guarded_actions(n,pos),key=ordering);assert aa
    for a in aa:
     cell['transitions']+=1;value,tail,distance=solve(make_checked(n,pos,a),left-1);children.append((value,distance))
     if (maximize and value>best) or (not maximize and value<best):best=value;line=(record_value(public_action(n,a)),)+tail
     if best==(1 if maximize else -1):cell['extreme_cutoffs']+=1;break
    distance=None
    if best:
     winner=0 if best==1 else 1
     if v['side']==winner:distance=1+min(d for val,d in children if val==best)
     else:assert all(val==best and d is not None for val,d in children);distance=1+max(d for val,d in children)
     assert distance<=left
    result=(best,line,distance);cache[key]=result
    if best and ablation!='ordering_only' and (state_key not in proof or distance<proof[state_key][2]):proof[state_key]=result
    return result
   try:
    value,line,distance=solve(root,depth);cell.update(complete=True,value=value,principal_line=line,forced_win_ply_upper_bound=distance)
    prior=next(x for x in original['cells'] if x['depth']==depth);assert not prior['complete'] or prior['value']==value
    # Actual replay ends at the claimed winner whenever outcome is nonzero.
    pos=root
    for v in line:pos=make_checked(n,pos,next(a for a in guarded_actions(n,pos) if record_value(public_action(n,a))==v))
    if value:terminal=terminal_status(n,pos);assert terminal['winner']==(0 if value==1 else 1)
   except Fuse:cell.update(value=None,principal_line=None,forced_win_ply_upper_bound=None)
   cell.update(seconds=time.perf_counter()-t,cache_entries=len(cache),proof_entries=len(proof));row['cells'].append(cell);write_record(out,r);print(original['context'],original['mode'],ablation,depth,cell['complete'],cell['value'],cell['calls'],cell['proof_hits'],cell['seconds'],flush=True)
r.update(complete=True,seconds=time.perf_counter()-started);write_record(out,r)
