"""Observed underpromotion mechanism, independently localized in Core."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'promotion-law-completed.json').read_bytes();src=json.loads(raw);searchraw=(p/'promotion-public-search.json').read_bytes();searched=json.loads(searchraw);row=next(x for x in src['rows'] if x['context']==5 and x['mode']=='all_choices');c=compile_ruleset_for_execution(ruleset_from_dict(row['definition']));out=p/'underpromotion-core.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),search_sha256=hashlib.sha256(searchraw).hexdigest(),declaration='Exposed localization of public-search context5 positive mate, not an independent holdout. Compare all four owner promotion choices at the same actual two-ply prefix, then plain Core force-win search at exactly5plies with own promotions restricted separately to B/N/R/Q and full choices. Opponent always keeps every legal action; false is inability to force a win within5 under that own subpolicy, not infinite-game WDL. Same100000calls/30sec checkpoint per policy, serial; no unchanged failed extension.',counterfactuals=[],policies=[])
pv=next(x for x in searched['rows'] if x['context']==5)['cells'][0]['decision']['principal_variation'];state=initial_state(c)
for v in pv[:2]:state=apply_action(state,next(a for a in legal_actions(state,c) if record_value(a)==v),c)
for tid in ('B','N','R','Q'):
 a=next(a for a in legal_actions(state,c) if a.promotion_target_id==tid);child=apply_action(state,a,c);r['counterfactuals'].append(dict(target=tid,action=record_value(a),terminal=record_value(child.terminal_status),opponent_legal_actions=len(legal_actions(child,c))))
class Fuse(RuntimeError):pass
for tid in ('B','N','R','Q',None):
 t=time.perf_counter();item=dict(own_promotion=tid or 'all',calls=0,transitions=0,terminal_wins=0);strategy={}
 def solve(state,left):
  item['calls']+=1
  if item['calls']>100000 or time.perf_counter()-t>30:raise Fuse()
  if item['calls']%1000==0:assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
  terminal=state.terminal_status
  if terminal.status.value!='ongoing':
   if terminal.winner==0:item['terminal_wins']+=1
   return terminal.winner==0
  if left==0:return False
  aa=tuple(legal_actions(state,c));assert aa
  if state.position.side_to_move==0:
   if tid is not None:aa=tuple(a for a in aa if a.promotion_target_id in (None,tid))
   for a in aa:
    item['transitions']+=1
    if solve(apply_action(state,a,c),left-1):strategy[str(record_value(state.position))]=record_value(a);return True
   return False
  for a in aa:
   item['transitions']+=1
   if not solve(apply_action(state,a,c),left-1):return False
  return True
 try:item.update(complete=True,win_within5=solve(initial_state(c),5))
 except Fuse:item.update(complete=False,win_within5=None)
 item.update(seconds=time.perf_counter()-t);r['policies'].append(item);write_record(out,r);print(item,flush=True)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r);print(r['counterfactuals'],flush=True)
