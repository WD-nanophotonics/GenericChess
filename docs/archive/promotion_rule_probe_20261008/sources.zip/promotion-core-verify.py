"""Independently verify the three produced full-game winning strategies."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.transition import initial_state,apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.native.compiler import compile_native_semantic_rules
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'promotion-subpolicy.json').read_bytes();src=json.loads(raw);assert src['complete'];started=time.perf_counter();out=p/'promotion-core-verify.json';assert not out.exists()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='Verify every produced winning strategy with independent Core legality and terminal execution; own player follows one saved action and opponent branches over ALL legal actions. This is a narrow finite winning bound, not a broad price validation gate. Reuse verified occupancy/side/remaining only in the explicitly no-aux, no-repetition-in8plies subset.',rows=[])
for row in src['rows']:
 if row['subpolicy_win'] is not True:continue
 c=compile_ruleset_for_execution(ruleset_from_dict(row['definition']));n=compile_native_semantic_rules(c);ids={v:i for i,v in enumerate(n.type_ids)};book=row['winning_policy'];seen=set();result=dict(context=row['context'],core_calls=0,core_transitions=0,terminal_wins=0,cache_hits=0,opponent_branches=0,owner_actions=0);t=time.perf_counter()
 def verify(state,left):
  result['core_calls']+=1
  assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
  assert not state.position.aux_state
  if state.terminal_status.status.value!='ongoing':assert state.terminal_status.winner==0;result['terminal_wins']+=1;return
  assert left>0
  key=json.dumps([[[i,ids[x.base_type_id],ids[x.current_type_id],x.owner,int(x.promoted)] for i,x in enumerate(state.position.board) if x is not None],state.position.side_to_move,left],separators=(',',':'))
  if key in seen:result['cache_hits']+=1;return
  aa=tuple(legal_actions(state,c));assert aa
  if state.position.side_to_move==0:
   chosen=book[key];aa=tuple(a for a in aa if record_value(a)==chosen);assert len(aa)==1;result['owner_actions']+=1
  else:result['opponent_branches']+=len(aa)
  for a in aa:result['core_transitions']+=1;verify(apply_action(state,a,c),left-1)
  seen.add(key)
 verify(initial_state(c),8);result.update(verified=True,seconds=time.perf_counter()-t);r['rows'].append(result);write_record(out,r);print(result,flush=True)
r.update(complete=True,seconds=time.perf_counter()-started);write_record(out,r)
