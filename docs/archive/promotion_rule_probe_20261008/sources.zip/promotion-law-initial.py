"""Scoped supported legal-rule promotion intervention, not a price table."""
import sys,json,time,hashlib
from dataclasses import replace
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.western_chess import build_western_chess_ruleset
from generic_chess.rules.schema import ruleset_to_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.core.pieces import Piece
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;out=p/'promotion-law.json';assert not out.exists();started=time.perf_counter()
contexts=[dict(own_king=(4,4),enemy_king=(7,7),pawn=(f,rank)) for rank in (5,6) for f in (1,3,5)]+[dict(own_king=(5,5),enemy_king=(7,7),pawn=x) for x in ((5,6),(6,5))]
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),declaration=dict(question='Does an explicit promotion rule change finite winning capability in one predeclared legal-anchor context population?',contexts=contexts,modes=['immobile','no_promotion','queen_only','all_choices'],horizons=[4,8,12],utility='Terminal owner0 win+1,owner1 win-1, draw/ongoing horizon0. No human material coefficients. Finite winning capability, not a universal price.',rules='Canonical Western movement/anchor legality/promotion choices/capture removal on8x8, sparse3entity synthetic roots. Remove castling,double-step,en-passant patterns; no pass. Thus supported derivative, not full historical Chess or virtual pass task.',cache='Exact occupancy/side/remaining cache within a single root/rule; no bound/deeper reuse. Pattern subset has no aux actions. repetition100000/maxply1000 cannot trigger in12plies, so history-independent projection is valid ONLY here. Terminal anchors remain actual legality. Extreme win/loss cutoffs only, otherwise all child values exact.',cost='Serial96cells, equal200000visited calls/30sec checkpoint per root/mode/horizon, interruption per1000calls; incomplete unknown. Cache resets each horizon. Initial4/8/12 declaration before outcome; never infer WDL of uncompleted full game.'),rows=[])
write_record(out,r)
class Fuse(RuntimeError):pass
base=build_western_chess_ruleset()
for ci,ctx in enumerate(contexts):
 for mode in r['declaration']['modes']:
  assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
  rows=[[None]*8 for _ in range(8)]
  for owner,tid,key in ((0,'K','own_king'),(1,'K','enemy_king'),(0,'P','pawn')):
   f,rank=ctx[key];assert rows[rank][f] is None;rows[rank][f]=Piece(owner,tid,tid)
  actions=tuple(a for a in base.semantic_actions if not(a.name.startswith('castle_') or a.name.startswith('en_passant_') or a.name=='pawn_double_step') and not(mode=='immobile' and a.name.startswith('pawn_')))
  types=tuple(replace(t,promotion_target_ids=('Q',)) if t.type_id=='P' and mode=='queen_only' else t for t in base.piece_types)
  definition=replace(base,initial_position=tuple(tuple(x) for x in rows),piece_types=types,semantic_actions=actions,promotion_allowed=base.promotion_allowed if mode in ('queen_only','all_choices') else {},promotion_forced=base.promotion_forced if mode in ('queen_only','all_choices') else {})
  c=compile_ruleset_for_execution(definition);n=compile_native_semantic_rules(c);session=GameSession(c);root=pack_semantic_search_position(c,n,session)
  assert terminal_status(n,root)['status']=='ongoing';assert not snapshot(n,root)['aux_state']
  row=dict(context=ci,mode=mode,definition=ruleset_to_dict(definition),fingerprint=c.ruleset_fingerprint,cells=[]);r['rows'].append(row);write_record(out,r)
  for depth in r['declaration']['horizons']:
   t=time.perf_counter();cache={};cell=dict(depth=depth,complete=False,calls=0,transitions=0,cache_hits=0,terminal_nodes=0,extreme_cutoffs=0)
   def solve(pos,left):
    cell['calls']+=1
    if cell['calls']%1000==0:assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
    if cell['calls']>200000 or time.perf_counter()-t>30:raise Fuse()
    v=snapshot(n,pos);key=(tuple((i,*x) for i,x in enumerate(v['board']) if x is not None),v['side'],left)
    if key in cache:cell['cache_hits']+=1;return cache[key]
    terminal=terminal_status(n,pos)
    if terminal['status']!='ongoing':
     cell['terminal_nodes']+=1;value=0 if terminal['winner'] is None else (1 if terminal['winner']==0 else -1);cache[key]=(value,());return cache[key]
    if left==0:cache[key]=(0,());return cache[key]
    maximize=v['side']==0;best=-2 if maximize else 2;line=()
    aa=sorted(guarded_actions(n,pos),key=lambda a:(public_action(n,a).promotion_target_id is None,str(public_action(n,a))))
    assert aa
    for a in aa:
     cell['transitions']+=1;value,tail=solve(make_checked(n,pos,a),left-1)
     if (maximize and value>best) or (not maximize and value<best):best=value;line=(record_value(public_action(n,a)),)+tail
     if best==(1 if maximize else -1):cell['extreme_cutoffs']+=1;break
    cache[key]=(best,line);return cache[key]
   try:value,line=solve(root,depth);cell.update(complete=True,value=value,principal_line=line)
   except Fuse:cell.update(value=None,principal_line=None)
   cell.update(seconds=time.perf_counter()-t,cache_entries=len(cache));row['cells'].append(cell);write_record(out,r);print(ci,mode,depth,cell['complete'],cell['value'],cell['calls'],cell['seconds'],flush=True)
r.update(complete=True,seconds=time.perf_counter()-started);write_record(out,r)
