"""One-sided action-subset win proofs in the full promotion game."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native.adapter import pack_semantic_search_position
from generic_chess.native.semantic import guarded_actions,public_action,make_checked,snapshot,terminal_status
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'promotion-law-completed.json').read_bytes();src=json.loads(raw);out=p/'promotion-subpolicy.json';assert not out.exists();started=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='All8 original full-choice roots, horizon8, same200000calls/30sec ceilings. Native full promotion rules for both players. Restrict ONLY owner0 promotion choices to Q, retain all other owner0 actions and every opponent action; no restriction of enemy defenses. Proving terminal owner0 win in this subpolicy gives a valid lower bound+1 in the full game. False is not full-game draw/loss. Same declared history-independent3piece subset, not a product TT/score change. Store winning strategy as state/remaining->selected legal owner0 action; losing replies retain complete legal branching.',rows=[])
write_record(out,r)
class Fuse(RuntimeError):pass
for original in src['rows']:
 if original['mode']!='all_choices':continue
 assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
 c=compile_ruleset_for_execution(ruleset_from_dict(original['definition']));n=compile_native_semantic_rules(c);root=pack_semantic_search_position(c,n,GameSession(c));cache={};policy={};t=time.perf_counter();row=dict(context=original['context'],definition=original['definition'],calls=0,transitions=0,cache_hits=0,opponent_actions_pruned=0);r['rows'].append(row)
 def key(v,left):return json.dumps([[[i,*x] for i,x in enumerate(v['board']) if x is not None],v['side'],left],separators=(',',':'))
 def solve(pos,left):
  row['calls']+=1
  if row['calls']%1000==0:assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
  if row['calls']>200000 or time.perf_counter()-t>30:raise Fuse()
  v=snapshot(n,pos);k=key(v,left)
  if k in cache:row['cache_hits']+=1;return cache[k]
  terminal=terminal_status(n,pos)
  if terminal['status']!='ongoing':cache[k]=terminal['winner']==0;return cache[k]
  if left==0:cache[k]=False;return False
  aa=sorted(guarded_actions(n,pos),key=lambda a:(public_action(n,a).promotion_target_id is None,str(public_action(n,a))))
  if v['side']==0:
   aa=[a for a in aa if public_action(n,a).promotion_target_id in (None,'Q')]
   for a in aa:
    row['transitions']+=1
    if solve(make_checked(n,pos,a),left-1):cache[k]=True;policy[k]=record_value(public_action(n,a));return True
   cache[k]=False;return False
  assert aa
  for a in aa:
   row['transitions']+=1
   if not solve(make_checked(n,pos,a),left-1):cache[k]=False;return False
  cache[k]=True;return True
 try:winning=solve(root,8);row.update(complete=True,subpolicy_win=winning,full_game_lower_bound=1 if winning else None,winning_policy=policy if winning else {})
 except Fuse:row.update(complete=False,subpolicy_win=None,full_game_lower_bound=None,winning_policy={})
 row.update(seconds=time.perf_counter()-t,cache_entries=len(cache));write_record(out,r);print(original['context'],row['complete'],row['subpolicy_win'],row['calls'],len(row['winning_policy']),row['seconds'],flush=True)
r.update(complete=True,seconds=time.perf_counter()-started);write_record(out,r)
