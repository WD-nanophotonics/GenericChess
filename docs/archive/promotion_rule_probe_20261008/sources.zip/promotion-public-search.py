"""Existing public search/orderer comparison on the predeclared promotion roots."""
import sys,json,time,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from generic_chess.rules.schema import ruleset_from_dict
from generic_chess.rules.compiler import compile_ruleset_for_execution
from generic_chess.session.session import GameSession
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.evaluation.profile import build_ruleset_profile
from generic_chess.ai.evaluation.config import EvaluationConfig,MATE_THRESHOLD
from generic_chess.ai.evaluation.cache import EvaluationProfileCache
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from scripts.research_record import record_value,write_record
p=Path(__file__).parent;raw=(p/'promotion-law-completed.json').read_bytes();src=json.loads(raw);out=p/'promotion-public-search.json';assert not out.exists();start=time.perf_counter()
r=dict(complete=False,producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=hashlib.sha256(raw).hexdigest(),declaration='All8 original full-choice roots x2 existing orderers x4096/16384node ceilings x2 cold repeats, target main depth8,5sec/q0, no root tactical fallback. Same zero nonterminal evaluator and generic-v1 capture/type ordering tables in every cell; terminal score remains product mate-distance score. Staged switch affects several action stages, so bundled cost comparison is NOT isolated promotion attribution. Equal node/time ceilings, full state/history and existing sufficient-depth TT semantics. Compare completed depth/score/action and legal PV, not universal speed or material prices.',rows=[])
class ZeroEvaluator:
 def __init__(self,profile):self.profile=profile
 def evaluate(self,state):return 0
 def type_value(self,tid):return self.profile.board_value_by_type[tid]
 def capture_order_value(self,mover,victim):return self.type_value(victim.current_type_id)*10-self.type_value(mover.current_type_id)//10
for row in src['rows']:
 if row['mode']!='all_choices':continue
 c=compile_ruleset_for_execution(ruleset_from_dict(row['definition']));session=GameSession(c);cache=EvaluationProfileCache(use_disk=False);profile=cache.get_or_build(c,EvaluationConfig())[0];evaluator=ZeroEvaluator(profile);item=dict(context=row['context'],fingerprint=c.ruleset_fingerprint,cells=[]);r['rows'].append(item)
 for ceiling in (4096,16384):
  for staged in (False,True):
   signatures=[]
   for repeat in range(2):
    assert not json.loads((ROOT/'.local_agent/rollout.json').read_bytes()).get('user_paused')
    player=AlphaBetaPlayer(c,use_disk_cache=False,profile_cache=cache,evaluator_override=evaluator,tt_max_entries=20000,tuning=SearchTuning(use_root_tactical=False,use_staged_move_picker=staged));t=time.perf_counter()
    decision=player.choose_action(session,SearchLimits(max_depth=8,max_nodes=ceiling,max_time_seconds=5,quiescence_max_depth=0,quiescence_hard_max_depth=0));elapsed=time.perf_counter()-t
    assert decision.action in session.legal_actions();state=session.state
    for a in decision.principal_variation:assert a in legal_actions(state,c);state=apply_action(state,a,c)
    cell=dict(ceiling=ceiling,staged=staged,repeat=repeat,seconds=elapsed,decision=record_value(decision),principal_line_legal=True,positive_mate=decision.score>MATE_THRESHOLD,pv_terminal=record_value(state.terminal_status));item['cells'].append(cell);signatures.append((record_value(decision.action),decision.score,decision.completed_depth,decision.nodes,decision.termination_reason));write_record(out,r);print(row['context'],ceiling,staged,repeat,decision.completed_depth,decision.score,decision.nodes,decision.termination_reason,elapsed,flush=True)
   assert signatures[0]==signatures[1],(row['context'],ceiling,staged,signatures)
r.update(complete=True,seconds=time.perf_counter()-start);write_record(out,r)
