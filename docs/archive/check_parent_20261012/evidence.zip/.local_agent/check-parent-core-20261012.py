"""Dot-selected local parent counterfactual; add exactly one checking drop."""
import sys,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.search_backend_comparison import CASES,CoreBoard,Material
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.core.actions import action_from_dict,SemanticDropMove
from generic_chess.core.coordinates import Square
from generic_chess.core.transition import apply_action
from generic_chess.core.movegen import legal_actions
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.alphabeta.tuning import SearchTuning
from generic_chess.ai.alphabeta.transposition import TranspositionTable
from generic_chess.ai.alphabeta.quiescence import noisy_child,enemy_board_count,material_inventory
from generic_chess.ai.alphabeta.native_legality import NativeSemanticLegalityProvider
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from scripts.full_q_refresh_comparison import runtime_state
from scripts.research_record import write_record,record_value
out=ROOT/'.local_agent/check-parent-core-20261012';out.mkdir(exist_ok=True);assert not(out/'declaration.json').exists()
write_record(out/'declaration.json',dict(question='Does adding only the verified nonterminal checkingdrop change the saved parent q choice?',calls=2,arms=['capture_only','capture_only_plus_one'],main_remaining_depth=0,q_start_depth=0,q=4,hardq=8,nodes=8192,seconds=64,leaf='same frozenMaterial',backend='independent Core legality/check/availability authority; Native providers disabled',tt='fresh isolated table, disabled scores',scope='Saved exposed parent, controlled standalone fullwindow q comparison. Original online alpha/beta/qoffset were not serialized, so no original-window value reproduction claim. Explicit same mainremaining0/q4/hard8 in botharms; all legal check evasions by originalq function, all descendant inclusion capture-only. Parent standpat is an explicit continuation option. Anyhardabort leaves parentvalue/argmax unknown, no capraise. Not rootdecision or strength.'))
c=compile_ruleset_for_execution(build_builtin_ruleset('standard_shogi'));core=CoreBoard(next(x for x in CASES if x['id']=='shogi-drop'),c);state=core.initial;witnesses=list(core.witnesses);w=json.loads((ROOT/'.local_agent/public-transfer-20261012/checking-scope-witness/witness.json').read_bytes())
for entry in w['parent']['history'][len(state.history):]:
 a=action_from_dict(json.loads(entry['action_signature']));assert a in legal_actions(state,c);state=apply_action(state,a,c);witnesses.append(state.position)
assert record_value(state.position)==w['parent']['position']
a=dict(w['action']);a['to_square']=Square(**a['to_square']);extra=SemanticDropMove(**a);ev=Material('shogi');rows=[]
for arm in ['capture_only','capture_only_plus_one']:
 provider=None
 rt=SearchPathRuntime.from_state(state,c,history_witnesses=tuple(witnesses),legal_binding_provider=provider,availability_provider=None);before=runtime_state(rt);stats=SearchStatistics();rt.attach_stats(stats);limits=SearchLimits(max_nodes=8192,max_time_seconds=64,quiescence_max_depth=4,quiescence_hard_max_depth=8);budget=sm._Budget(limits,None)
 ctx=sm._Context(c,ev,TranspositionTable(max_entries=0),stats,budget,SearchTuning(use_capture_only_qsearch=True,use_ordered_qsearch=True),False,True,4,8,None,runtime=rt,first_main_iteration_complete=True)
 assert not rt.terminal_status.is_terminal and not rt.in_check(rt.position.side_to_move)
 side=rt.position.side_to_move;enemies=enemy_board_count(rt.position,side);inventory=material_inventory(rt.position);values=[dict(action='stand_pat',score=ev.evaluate(rt.state))];included=[];t=time.perf_counter();stats.qnodes=1;complete=True;reason='complete'
 try:
  for act in sm._order_qactions(rt.state,rt.legal_actions(ctx.checkpoint),0,ctx):
   ctx.checkpoint()
   with rt.pushed(act,checkpoint=ctx.checkpoint):
    retain=noisy_child(act,rt.state,side,enemies,inventory,lambda:rt.in_check(1-side),capture_only=True)
    if not retain and not (arm=='capture_only_plus_one' and act==extra):continue
    included.append(str(act));score=-sm._quiescence_runtime(-sm.INF,sm.INF,1,1,ctx);values.append(dict(action=str(act),score=score))
 except sm.SearchAborted as e:complete=False;reason=str(e)
 rt.assert_balanced();assert runtime_state(rt)==before
 best=max(x['score'] for x in values) if complete else None;optimal=sorted(x['action'] for x in values if x['score']==best) if complete else None
 rows.append(dict(arm=arm,complete=complete,reason=reason,seconds=time.perf_counter()-t,parent_value=best,parent_optimal_continuation_set=optimal,included=included,branch_values=values if complete else None,nodes=stats.nodes,qnodes=stats.qnodes,legal_calls=stats.legal_generation_calls,root_restored=True));write_record(out/'result.json',dict(complete=False,rows=rows));print(arm,complete,reason,best,optimal,stats.qnodes,flush=True)
write_record(out/'result.json',dict(complete=True,rows=rows,comparison='Only completed parent values/sets comparable; anyincomplete arm inconclusive.'))