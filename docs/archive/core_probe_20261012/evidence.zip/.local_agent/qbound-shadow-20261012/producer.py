"""Actual Core-owned caller: semantic attack backend and legality attribution."""
import argparse, hashlib, json, random, sys, time
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from scripts import full_q_refresh_comparison as p
from scripts.research_record import record_value, write_record
from generic_chess.ai.evaluation.semantic_attacks import SemanticAttackEvaluator
from generic_chess.ai.alphabeta.player import AlphaBetaPlayer
from generic_chess.ai.alphabeta import player as pm
from generic_chess.ai.alphabeta.statistics import SearchStatistics
from generic_chess.ai.limits import SearchLimits
from generic_chess.core.search_runtime import SearchPathRuntime
from generic_chess.native import semantic as ns
from scripts.native_core_availability import NativeCoreAvailability
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from scripts.search_backend_comparison import CASES,CoreBoard
from generic_chess.ai.alphabeta import search as sm
from generic_chess.ai.alphabeta.transposition import score_to_tt
from collections import Counter
oldq=sm._quiescence_runtime
bounds={};windows=Counter();qc=Counter();examples=[]
def shadow_q(alpha,beta,ply,qdepth,ctx):
    qc['calls']+=1
    key=None
    candidate_hit=None
    calls_before=qc['calls']
    if ctx.runtime.tt_eligible and not ctx.runtime.terminal_status.is_terminal:
        key=(ctx.runtime.search_key(),qdepth,sm._ordinary_qdepth_limit(ctx),ctx.qhard_depth_limit)
        qc['eligible']+=1
        windows[(key,alpha,beta)]+=1
        if key in bounds:
            qc['repeated_key']+=1
            low,high=bounds[key]
            a,b=score_to_tt(alpha,ply),score_to_tt(beta,ply)
            if low is not None and high is not None and low==high:
                qc['exact_hit']+=1;candidate_hit='exact'
            elif low is not None and low>=b:
                qc['lower_cutoff']+=1;candidate_hit='lower'
            elif high is not None and high<=a:
                qc['upper_cutoff']+=1;candidate_hit='upper'
    result=oldq(alpha,beta,ply,qdepth,ctx)
    if key is not None:
        value=score_to_tt(result,ply)
        low,high=bounds.get(key,(None,None))
        if result<=alpha:high=value if high is None else min(high,value)
        elif result>=beta:low=value if low is None else max(low,value)
        else:
            low=value if low is None else max(low,value)
            high=value if high is None else min(high,value)
        assert low is None or high is None or low<=high,('inconsistent q bounds',low,high)
        if key not in bounds and len(bounds)>=20000:
            qc['capacity_rejected']+=1
        else:bounds[key]=(low,high)
    if candidate_hit is not None and len(examples)<64:
        examples.append(dict(kind=candidate_hit,subtree_qcalls=qc['calls']-calls_before+1,qdepth=qdepth,alpha=alpha,beta=beta,result=result))
    return result

class CountedSemanticEvaluator(SemanticAttackEvaluator):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.score_calls=self.map_calls=0
    def evaluate(self,state):
        self.score_calls+=1;return super().evaluate(state)
    def _attack_maps(self,state):
        self.map_calls+=1;return super()._attack_maps(state)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args()
    b=Path(args.output);b.mkdir(parents=True,exist_ok=True)
    if (b/'declaration.json').exists():raise RuntimeError('frozen output exists')
    modes=[('shadow',True)]
    declaration=dict(question='Do full-history q-bound keys reveal usable repeated scheduling unlike the old exact-window diagnostic?' ,roots=['shogi-drop'],modes=modes,orders=1,depths=[64],q=4,hardq=8,nodes=8192,seconds=64,calls=1,expected_seconds='Maximum64searchseconds plus setup, expectedunder3min; interruptible',decision='Every original recursive query executes; eligible full-history intervals reveal potential exact or bound cutoffs. No skipping, default change or causal time saving is claimed. Pursue only substantial compatible repeated work.',scope='Single Shogi rich-drop root; Native semantic attack evaluator and legal/availability primitives, Core check/history/TT. 8192 nodes, depth2, q4/hard8,64seconds; observed scope only.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    write_record(b/'declaration.json',declaration)
    roots=[];samples=[]
    for case_id in ('shogi-drop',):
        case=next(x for x in CASES if x['id']==case_id)
        c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess' if case['game']=='chess' else 'standard_shogi'))
        core=CoreBoard(case,c);ec=p.EvaluationConfig();profile=p.build_ruleset_profile(c,ec)
        s=SimpleNamespace(state=core.initial,_search_witnesses=core.witnesses,legal_actions=core.runtime.legal_actions)
        roots.append((case_id,c,ec,profile,s));samples.append(dict(case=case,initial=record_value(s.state),witnesses=record_value(core.witnesses),profile=record_value(profile),config=record_value(ec)))
    write_record(b/'samples.json',samples)
    runtimes=[];captured=[];old_attach=SearchPathRuntime.attach_stats;old_stats=pm.SearchStatistics
    imports=queries=0;old_pack=ns.pack_current_position;old_attack=ns.attacked_squares
    def pack(*a,**kw):
        nonlocal imports;imports+=1;return old_pack(*a,**kw)
    def attack(*a,**kw):
        nonlocal queries;queries+=1;return old_attack(*a,**kw)
    def attach(rt,stats):
        v=old_attach(rt,stats);runtimes.append((rt,p.runtime_state(rt)));return v
    def factory():
        v=SearchStatistics();captured.append(v);return v
    rows=[];start=time.perf_counter()
    try:
        sm._quiescence_runtime=shadow_q;SearchPathRuntime.attach_stats=attach;pm.SearchStatistics=factory;ns.pack_current_position=pack;ns.attacked_squares=attack
        for seed,c,ec,profile,s in roots:
            legal=set(s.legal_actions());saved=s.state
            for depth in declaration['depths']:
                for order in range(1):
                    for backend,native in (modes if order==0 else list(reversed(modes))):
                        p.rr.stopped();runtimes.clear();captured.clear();imports=queries=0
                        t=time.perf_counter();ev=CountedSemanticEvaluator(c,profile,ec,backend='native');availability=NativeCoreAvailability(c) if native else None;check=None;player=AlphaBetaPlayer(c,evaluator_override=ev,use_native_semantic_legality=True,use_disk_cache=False,availability_provider=None if availability is None else availability.for_position)
                        value=player.choose_action(s,SearchLimits(max_depth=2,max_nodes=8192,max_time_seconds=depth,quiescence_max_depth=4,quiescence_hard_max_depth=8))
                        elapsed=time.perf_counter()-t
                        assert len(runtimes)==len(captured)==1
                        rt,snapshot=runtimes[0];rt.assert_balanced();assert p.runtime_state(rt)==snapshot and s.state==saved and value.action in legal
                        row=dict(seed=seed,budget_seconds=depth,depth_requested=2,order=order,attack_backend='native',native_legal_requested=True,availability_mode=backend,availability_counts=None if availability is None else dict(calls=availability.calls,imports=availability.imports,queries=availability.queries,fallbacks=availability.fallbacks,payload_seconds=availability.payload_seconds,query_seconds=availability.query_seconds),provider_created=player.native_legality_provider is not None,caller_seconds=elapsed,score_calls=ev.score_calls,map_calls=ev.map_calls,actual_attack_imports=imports,actual_attack_queries=queries,decision=record_value(value),stats=record_value(captured[0]),root_restored=True)
                        rows.append(row);write_record(b/'result.json',dict(complete=False,rows=rows));print(seed,depth,order,backend,native,value.completed_depth,value.termination_reason,round(elapsed,3),value.score,flush=True)
    finally:
        sm._quiescence_runtime=oldq;SearchPathRuntime.attach_stats=old_attach;pm.SearchStatistics=old_stats;ns.pack_current_position=old_pack;ns.attacked_squares=old_attack
    write_record(b/'result.json',dict(complete=True,rows=rows,elapsed_seconds=time.perf_counter()-start,q_shadow=dict(qc),unique_keys=len(bounds),unique_windows=len(windows),exact_window_repetitions=sum(v-1 for v in windows.values()),examples=examples,scope='Potential skipped subtrees may overlap; never sum them as independent savings. Observer continues every original query.'))
if __name__=='__main__':main()
