"""Finite availability primitive semantics: actual states, cutoff independence."""
from dataclasses import replace
import pytest
from generic_chess import build_builtin_ruleset,compile_ruleset_for_execution
from generic_chess.native import native_available
from generic_chess.native.compiler import compile_native_semantic_rules
from generic_chess.native import semantic as ns
from generic_chess.core.semantic_executor import semantic_engine_for
from scripts.search_backend_comparison import CASES,CoreBoard
from scripts.native_core_availability import NativeCoreAvailability
pytestmark=pytest.mark.skipif(not native_available(),reason='native extension unavailable')

@pytest.mark.parametrize('mode',['decline','native','malformed','exception'])
def test_instance_check_contract_and_push_rollback(mode):
    from scripts.full_q_refresh_comparison import runtime_state
    from scripts.native_core_check import NativeCoreCheck
    c=compile_ruleset_for_execution(build_builtin_ruleset('western_chess'))
    rt=CoreBoard(next(x for x in CASES if x['id']=='chess-ep'),c).runtime
    native=NativeCoreCheck(c);calls=[]
    def provider(position,side,checkpoint=None):
        calls.append((position,side))
        if mode=='decline':return None
        if mode=='malformed':return 1
        if mode=='exception':raise RuntimeError('check interrupted')
        return native.for_position(position,side,checkpoint=checkpoint)
    rt.check_provider=provider;saved=runtime_state(rt);action=rt.legal_actions()[0]
    if mode in ('malformed','exception'):
        with pytest.raises(TypeError if mode=='malformed' else RuntimeError):rt.push(action)
    else:
        rt.push(action)
        try:
            assert rt.in_check(rt.position.side_to_move)==semantic_engine_for(c).in_check(rt.position,rt.position.side_to_move)
            assert rt._frames[-1].child_in_check==semantic_engine_for(c).in_check(rt.position,rt.position.side_to_move)
        finally:rt.pop()
    assert calls and runtime_state(rt)==saved
    rt.assert_balanced()
