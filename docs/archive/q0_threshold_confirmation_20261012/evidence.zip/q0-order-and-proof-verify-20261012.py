import sys,json
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-order-delivery-20261012';d=json.loads((p/'result.json').read_bytes());assert d['complete'];rows=d['rows'];assert len(rows)==16;fields=['score','action','principal_variation','completed_depth'];summary=[]
for root in ['generated1091-turn2','Shogi0','seed2026101202-ply0','seed2026101204-ply0']:
 cells=[x for x in rows if x['root']==root]
 for arm in ['baseline','canonical_root']:
  a,b=[x for x in cells if x['arm']==arm];assert all(a['result'][k]==b['result'][k] for k in fields)
 a=next(x for x in cells if x['arm']=='baseline' and x['order']==0);b=next(x for x in cells if x['arm']=='canonical_root' and x['order']==0)
 same_depth=a['result']['completed_depth']==b['result']['completed_depth']
 if same_depth:assert all(a['result'][k]==b['result'][k] for k in fields)
 summary.append(dict(root=root,baseline_depth=a['result']['completed_depth'],candidate_depth=b['result']['completed_depth'],baseline_score=a['result']['score'],candidate_score=b['result']['score'],same_depth_fulltuple=same_depth,baseline_nodes=a['result']['nodes'],candidate_nodes=b['result']['nodes'],phase=[{k:v for k,v in x['raw'].items() if k.startswith('phase_')} for x in [a,b]]))
write_record(p/'verification.json',dict(calls=16,reverse_fulltuple_pairs=8,root_summary=summary,depth_changes=dict(gains=1,losses=1,unchanged=2),decision='Reject uniformroot-onlycanonicalordering: samebudget actualcompletionloss despitefewerattemptedvisits; no default/UI/codeadoption or exposedroot selector. Differentdepth score/action isnotstrengthgain.',all_pv_legal_root_restored=True,all_selected_pass_values_match=True))
print(summary)
p=R/'.local_agent/q0-proof-compose-20261012/consumer';d=json.loads((p/'result.json').read_bytes());assert len(d)==16;assert sum(x['result']['termination_reason']=='proven_immediate_win' for x in d)==3
write_record(p/'composition-verification.json',dict(calls=16,actual_provenwinning_submissions=3,non_immediate_control_not_shortcut=True,pre_cancelled_no_submit=4,node_budget_fallback_submit=4,scope='Currentf1ea productioncanonical plusguardedproof composition, no duringproofinjection or UI/default/publicpolicyclaim.'))
