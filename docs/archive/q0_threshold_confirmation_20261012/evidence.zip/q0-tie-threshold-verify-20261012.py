import sys,json
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));from scripts.research_record import write_record
p=R/'.local_agent/q0-tie-threshold-20261012';d=json.loads((p/'run/result.json').read_bytes());assert d['complete'];rows=d['rows'];assert len(rows)==12;fields=['score','action','principal_variation','completed_depth'];summary=[]
for depth in [4,5]:
 ref=next(x for x in rows if x['depth']==depth and x['order']==0 and x['arm']=='baseline')
 for order in [0,1]:
  for arm in ['baseline','threshold0','threshold1']:
   x=next(x for x in rows if x['depth']==depth and x['order']==order and x['arm']==arm);assert all(x['result'][k]==ref['result'][k] for k in fields);assert x['raw']['research_pv_mismatches']==0
 summary.append(dict(depth=depth,baseline_nodes=ref['result']['nodes'],threshold0_nodes=next(x['result']['nodes'] for x in rows if x['depth']==depth and x['order']==0 and x['arm']=='threshold0'),threshold1_nodes=next(x['result']['nodes'] for x in rows if x['depth']==depth and x['order']==0 and x['arm']=='threshold1')))
write_record(p/'verification.json',dict(calls=12,all_complete_fulltuples_equal=True,selected_pass_consistency=True,summary=summary,next_choice='threshold1: sameobservedwork/output as0 on thisroot, preserves existingPVnode entry noTTscorecut; further finite/actualnegative controls needed. No publicadoption.',argument='Earlierparent UPPER==best giveschild true>=-best; integerwindow[-best,-best+1] fail-low giveschild true<=-best, so equality. Failurehigh meansstrictlylosing, do notcompare threshold bound asparent improvement.'))
print(summary)
