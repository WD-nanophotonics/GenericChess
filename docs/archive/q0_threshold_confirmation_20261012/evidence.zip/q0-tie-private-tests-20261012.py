import sys,json,importlib.util,sysconfig,time
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R));import generic_chess.native as native
from scripts.research_record import write_record
p=R/'.local_agent/q0-tie-threshold-20261012/threshold1'/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'));sp=importlib.util.spec_from_file_location('pytest_trace._native_core',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);native._MODULE=m
import pytest
args=['-q','-p','no:cacheprovider','--basetemp=.local_agent/pytest-q0-tie-private-20261012','tests/development/test_native_q0_canonical_replay.py','tests/development/test_native_root_tie_refinement.py','tests/product/test_h50b2e_semantic_search_engine.py','tests/product/test_native_evaluator_binding.py','tests/product/test_f106_min_remaining_depth_ordering.py'];t=time.perf_counter();code=pytest.main(args);write_record(R/'.local_agent/q0-tie-threshold-20261012/private-tests.json',dict(exit_code=code,seconds=time.perf_counter()-t,targets=args,private_module=True));sys.exit(code)
