import sys,os,sysconfig,subprocess,time,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R))
from scripts.research_record import write_record
out=R/'.local_agent/q0-proof-threshold-compose-20261012';out.mkdir(exist_ok=True)
s=(R/'generic_chess/_native/native_module.c').read_text(encoding='utf-8')
a='    int used_fallback = 0;\n    uint64_t start_ns'
assert s.count(a)==1
v=s.replace(a,'    int used_fallback = 0;\n    int proven_immediate_win = 0;\n    uint64_t start_ns')
a='        memcpy(completed_pv, ctx.pv_table,\n               sizeof(uint64_t) * completed_len);\n    }'
b='''        memcpy(completed_pv, ctx.pv_table,
               sizeof(uint64_t) * completed_len);
        /* Private scoped caller policy: actual selected ordinary child wins.
         * Rebuild it instead of depending on recursion stack lifetime. */
        if (ctx.root_window_pruning && depth == 1 && completed_len == 1 &&
            !gc_semantic_is_declaration_action(completed_action)) {
            if (!gc_semantic_iterative_check_budget(&ctx, 1)) break;
            GCSemanticPosition *child = &ctx.stack[1];
            int winner = -1;
            if (!gc_semantic_runtime_make_checked(child, ctx.rules,
                                                 &ctx.stack[0], completed_action)) {
                ctx.control = 4;
                break;
            }
            int terminal = gc_semantic_terminal_status(ctx.rules, child, &winner);
            if (terminal < 0) { ctx.control = 4; break; }
            if (!gc_semantic_iterative_check_budget(&ctx, 1)) break;
            if (terminal > 0 && winner == ctx.stack[0].side_to_move) {
                proven_immediate_win = 1;
                break;
            }
        }
    }'''
assert v.count(a)==1;v=v.replace(a,b)
a='    const char *reason = "completed";';assert v.count(a)==1
v=v.replace(a,'    const char *reason = proven_immediate_win ? "proven_immediate_win" : "completed";')
write_record(out/'build-declaration.json',dict(base='f1ea1d3870302777de6b56ae4cd62a17d7bf7bb0 plus current tested threshold source',question='Can actual one-ply terminal proof avoid repeated winning deepening while preserving canonical selected move and full state?',scope='Private composition oncurrent productioncanonicalreconstruction, forcebudget/cancel checksbeforeafterproof. Explicitcaller stop goal versusfixedhorizon baseline; no public/default/UI/enum/training changes. Four savedroots/currentcanonical composition. Actualnative cancel injection afterterminal proof beforeacceptance whenctx.cancel!=NULL; stage pre_cancel alone is not thiscoverage. SamepersistentTT retrywith noflag versuscoldguarded; no OS/UIcallback latency claim. Fresh checked child and actual terminal winner, no score certificate/declaration shortcut/default UI adoption. Excludes deeper forced wins. Public reason preserved truthfully in private output.'))
rows=[]
v=v.replace('            if (terminal < 0)', '            if (ctx.cancel != NULL) gc_cancel_flag_request(ctx.cancel);\n            if (terminal < 0)')
for name,src in [('proof_injected',v)]:
 d=out/name;d.mkdir(exist_ok=True);p=d/'native_module.c';p.write_text(src,encoding='utf-8',newline='\n');binary=d/('_native_core'+sysconfig.get_config_var('EXT_SUFFIX'))
 args=[str(R/'.venv/Lib/site-packages/ziglang/zig.exe'),'cc','-target','x86_64-windows-gnu','-shared','-O2','-I'+sysconfig.get_paths()['include'],'-I'+str(R/'generic_chess/_native'),'-L'+str(Path(sys.base_prefix)/'libs'),'-lpython312']+[str(p if f.name=='native_module.c' else f) for f in sorted((R/'generic_chess/_native').glob('*.c'))]+['-o',str(binary)]
 t=time.perf_counter();r=subprocess.run(args,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.gc_zig_cache')),capture_output=True,text=True,timeout=180);(d/'compiler-private.txt').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr[-1000:]
 rows.append(dict(arm=name,seconds=time.perf_counter()-t,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));print(name,'built',flush=True)
write_record(out/'build.json',rows)
