class NativeQ0UITestPlayer:
    """Explicit local test profile: integer material Native q0, not Core q4."""
    backend_label = "Native q0 exact-root; material only; current tested sandbox"
    def __init__(self, compiled, profile):
        from ..ai.alphabeta.native_legality import NativeSemanticLegalityProvider
        from ..native.semantic_engine import SemanticSearchEngine
        from ..learning.material import LearnableMaterialCheckpoint
        self.compiled = compiled
        provider = NativeSemanticLegalityProvider.try_create(compiled, strict=True)
        if provider is None:
            raise RuntimeError("Native q0 test profile is unavailable for this ruleset")
        ordering = LearnableMaterialCheckpoint.from_profile(compiled, profile, dynamic_weights={})
        self.engine = SemanticSearchEngine(compiled, provider.native_rules,
            board_values=profile.board_value_by_type, hand_values=profile.hand_value_by_base_type,
            dynamic_values=(0,0,0), evaluator_scale=1, tt_megabytes=1,
            ordering_checkpoint=ordering, ordering_min_depth=2)
    def choose_action(self, session, limits, *, cancel_token=None, **kw):
        from ..ai.decision import PlayerDecision
        if limits.quiescence_max_depth != 0 or limits.quiescence_hard_max_depth != 0:
            raise ValueError("Explicit Native q0 UI test requires visibly configured q0 limits")
        r=self.engine.search(session, limits, cancel_token=cancel_token, root_window_pruning=True)
        if r.declaration_id is not None:
            raise RuntimeError("Native declaration UI adapter is outside this test profile")
        return PlayerDecision(action=r.action,score=r.score,principal_variation=r.principal_variation,
            completed_depth=r.completed_depth,selective_depth=r.selective_depth,nodes=r.nodes,qnodes=r.qnodes,
            elapsed_seconds=r.elapsed_seconds,tt_probes=r.tt_probes,tt_hits=r.tt_hits,tt_cutoffs=r.tt_cutoffs,
            beta_cutoffs=r.beta_cutoffs,evaluation_profile_cache_hit=False,termination_reason=r.termination_reason,
            result_source="native_q0_ui_test",result_ordinary_qdepth=0,result_check_hard_qdepth=0)

def create_ui_player(compiled, *, use_disk_cache=True):
    import os
    from .material_values import human_material_profile
    from ..ai.evaluation.config import EvaluationConfig
    from ..rules.ir import CompiledSemanticRuleset
    profile=human_material_profile(compiled,EvaluationConfig())
    if (os.environ.get("GENERIC_CHESS_UI_SEARCH")=="native-q0"
            and profile is not None and isinstance(compiled,CompiledSemanticRuleset)
            and not compiled.declarations):
        return NativeQ0UITestPlayer(compiled,profile)
    player=create_core_ui_player(compiled,use_disk_cache=use_disk_cache)
    player.backend_label="Core q4/hard8; frozen UI profile (Native q0 test not applicable)"
    return player
